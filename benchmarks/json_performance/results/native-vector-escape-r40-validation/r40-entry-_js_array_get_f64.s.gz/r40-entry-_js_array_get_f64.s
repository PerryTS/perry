
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/native-vector-escape-r40/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007c2650 <_js_array_get_f64>:
1007c2650:     	sub	sp, sp, #0x70
1007c2654:     	stp	x26, x25, [sp, #0x20]
1007c2658:     	stp	x24, x23, [sp, #0x30]
1007c265c:     	stp	x22, x21, [sp, #0x40]
1007c2660:     	stp	x20, x19, [sp, #0x50]
1007c2664:     	stp	x29, x30, [sp, #0x60]
1007c2668:     	add	x29, sp, #0x60
1007c266c:     	mov	x19, x1
1007c2670:     	mov	x22, x0
1007c2674:     	lsr	x25, x0, #51
1007c2678:     	mov	x20, x0
1007c267c:     	cmp	x25, #0xfff
1007c2680:     	b.lo	0x1007c269c <_js_array_get_f64+0x4c>
1007c2684:     	mov	w8, #0x7ffc             ; =32764
1007c2688:     	cmp	x8, x22, lsr #48
1007c268c:     	b.ne	0x1007c2698 <_js_array_get_f64+0x48>
1007c2690:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007c2694:     	b	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c2698:     	and	x20, x22, #0xffffffffffff
1007c269c:     	lsr	x8, x20, #3
1007c26a0:     	cmp	x8, #0x200
1007c26a4:     	b.ls	0x1007c26dc <_js_array_get_f64+0x8c>
1007c26a8:     	ldurb	w8, [x20, #-0x8]
1007c26ac:     	cmp	w8, #0x9
1007c26b0:     	b.ne	0x1007c26dc <_js_array_get_f64+0x8c>
1007c26b4:     	ldr	w8, [x20, #0x4]
1007c26b8:     	mov	w9, #0x5841             ; =22593
1007c26bc:     	movk	w9, #0x4c5a, lsl #16
1007c26c0:     	cmp	w8, w9
1007c26c4:     	b.ne	0x1007c26dc <_js_array_get_f64+0x8c>
1007c26c8:     	mov	x0, x20
1007c26cc:     	mov	x1, x19
1007c26d0:     	bl	0x10068b804 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007c26d4:     	fmov	d0, x0
1007c26d8:     	b	0x1007c2d4c <_js_array_get_f64+0x6fc>
1007c26dc:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c26e0:     	b.lo	0x1007c2790 <_js_array_get_f64+0x140>
1007c26e4:     	tst	x20, #0xffff800000000000
1007c26e8:     	mov	w8, #0x1000             ; =4096
1007c26ec:     	ccmp	x20, x8, #0x0, eq
1007c26f0:     	b.lo	0x1007c2790 <_js_array_get_f64+0x140>
1007c26f4:     	ldurb	w24, [x20, #-0x8]
1007c26f8:     	ldurh	w23, [x20, #-0x6]
1007c26fc:     	cmp	w24, #0xa
1007c2700:     	b.gt	0x1007c28a8 <_js_array_get_f64+0x258>
1007c2704:     	cmp	w24, #0x2
1007c2708:     	b.eq	0x1007c2930 <_js_array_get_f64+0x2e0>
1007c270c:     	cmp	w24, #0x8
1007c2710:     	b.ne	0x1007c2798 <_js_array_get_f64+0x148>
1007c2714:     	mov	x0, x20
1007c2718:     	bl	0x100307b68 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007c271c:     	cbz	w0, 0x1007c29c0 <_js_array_get_f64+0x370>
1007c2720:     	mov	x22, #0x1               ; =1
1007c2724:     	movk	x22, #0x7ffc, lsl #48
1007c2728:     	lsr	x8, x20, #51
1007c272c:     	cmp	x8, #0xfff
1007c2730:     	b.lo	0x1007c2744 <_js_array_get_f64+0xf4>
1007c2734:     	mov	w8, #0x7ffc             ; =32764
1007c2738:     	cmp	x8, x20, lsr #48
1007c273c:     	b.eq	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c2740:     	and	x20, x20, #0xffffffffffff
1007c2744:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c2748:     	b.lo	0x1007c2768 <_js_array_get_f64+0x118>
1007c274c:     	tst	x20, #0xffff800000000000
1007c2750:     	mov	w8, #0x1000             ; =4096
1007c2754:     	ccmp	x20, x8, #0x0, eq
1007c2758:     	b.lo	0x1007c2768 <_js_array_get_f64+0x118>
1007c275c:     	ldurb	w8, [x20, #-0x8]
1007c2760:     	cmp	w8, #0x2
1007c2764:     	b.eq	0x1007c3034 <_js_array_get_f64+0x9e4>
1007c2768:     	cbz	x20, 0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c276c:     	mov	x0, x20
1007c2770:     	mov	x1, x19
1007c2774:     	bl	0x100307d18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007c2778:     	cmp	w0, #0x1
1007c277c:     	b.ne	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c2780:     	ldr	x8, [x20, #0x8]
1007c2784:     	ubfiz	x9, x1, #4, #32
1007c2788:     	ldr	x22, [x8, x9]
1007c278c:     	b	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c2790:     	mov	w23, #0x0               ; =0
1007c2794:     	mov	w24, #0x0               ; =0
1007c2798:     	mov	x21, x22
1007c279c:     	cmp	x25, #0xfff
1007c27a0:     	b.lo	0x1007c27b8 <_js_array_get_f64+0x168>
1007c27a4:     	mov	w8, #0x7ffc             ; =32764
1007c27a8:     	cmp	x8, x22, lsr #48
1007c27ac:     	b.eq	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c27b0:     	ands	x21, x22, #0xffffffffffff
1007c27b4:     	b.eq	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c27b8:     	and	x8, x21, #0xfffffffffff00000
1007c27bc:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007c27c0:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007c27c4:     	cmp	x9, x10
1007c27c8:     	ccmp	x8, #0x0, #0x4, lo
1007c27cc:     	b.eq	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c27d0:     	tst	x21, #0x3
1007c27d4:     	ccmp	x21, #0x7, #0x0, eq
1007c27d8:     	b.ls	0x1007c2a88 <_js_array_get_f64+0x438>
1007c27dc:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c27e0:     	ldr	x8, [x8, #0x48]
1007c27e4:     	cmn	x8, #0x1
1007c27e8:     	b.eq	0x1007c29d8 <_js_array_get_f64+0x388>
1007c27ec:     	mrs	x9, TPIDRRO_EL0
1007c27f0:     	and	x9, x9, #0xfffffffffffffff8
1007c27f4:     	ldr	x0, [x9, x8, lsl #3]
1007c27f8:     	cbz	x0, 0x1007c29d8 <_js_array_get_f64+0x388>
1007c27fc:     	lsr	x1, x21, #20
1007c2800:     	ldr	x8, [x0, #0x10]
1007c2804:     	ldrb	w9, [x8]
1007c2808:     	cmp	w9, #0x2
1007c280c:     	b.ne	0x1007c29f0 <_js_array_get_f64+0x3a0>
1007c2810:     	ldrb	w9, [x8, #0x88]
1007c2814:     	tbz	w9, #0x0, 0x1007c2834 <_js_array_get_f64+0x1e4>
1007c2818:     	ldr	x9, [x8, #0x80]
1007c281c:     	cmp	x9, x1
1007c2820:     	b.ne	0x1007c2834 <_js_array_get_f64+0x1e4>
1007c2824:     	ldp	x9, x10, [x8, #0x60]
1007c2828:     	cmp	x9, x21
1007c282c:     	ccmp	x10, x21, #0x0, ls
1007c2830:     	b.hi	0x1007c29d0 <_js_array_get_f64+0x380>
1007c2834:     	ldrb	w9, [x8, #0xb8]
1007c2838:     	cbz	w9, 0x1007c2858 <_js_array_get_f64+0x208>
1007c283c:     	ldr	x9, [x8, #0xb0]
1007c2840:     	cmp	x9, x1
1007c2844:     	b.ne	0x1007c2858 <_js_array_get_f64+0x208>
1007c2848:     	ldp	x9, x10, [x8, #0x90]
1007c284c:     	cmp	x9, x21
1007c2850:     	ccmp	x10, x21, #0x0, ls
1007c2854:     	b.hi	0x1007c2e98 <_js_array_get_f64+0x848>
1007c2858:     	ldrb	w9, [x8, #0xe8]
1007c285c:     	cbz	w9, 0x1007c287c <_js_array_get_f64+0x22c>
1007c2860:     	ldr	x9, [x8, #0xe0]
1007c2864:     	cmp	x9, x1
1007c2868:     	b.ne	0x1007c287c <_js_array_get_f64+0x22c>
1007c286c:     	ldp	x9, x10, [x8, #0xc0]
1007c2870:     	cmp	x9, x21
1007c2874:     	ccmp	x10, x21, #0x0, ls
1007c2878:     	b.hi	0x1007c2f80 <_js_array_get_f64+0x930>
1007c287c:     	ldrb	w9, [x8, #0x118]
1007c2880:     	cbz	w9, 0x1007c2a50 <_js_array_get_f64+0x400>
1007c2884:     	ldr	x9, [x8, #0x110]
1007c2888:     	cmp	x9, x1
1007c288c:     	b.ne	0x1007c2a50 <_js_array_get_f64+0x400>
1007c2890:     	ldp	x9, x10, [x8, #0xf0]
1007c2894:     	cmp	x9, x21
1007c2898:     	ccmp	x10, x21, #0x0, ls
1007c289c:     	b.ls	0x1007c2a50 <_js_array_get_f64+0x400>
1007c28a0:     	add	x9, x8, #0xf0
1007c28a4:     	b	0x1007c2f84 <_js_array_get_f64+0x934>
1007c28a8:     	cmp	w24, #0xb
1007c28ac:     	b.eq	0x1007c2948 <_js_array_get_f64+0x2f8>
1007c28b0:     	cmp	w24, #0xc
1007c28b4:     	b.ne	0x1007c2798 <_js_array_get_f64+0x148>
1007c28b8:     	mov	x0, x20
1007c28bc:     	bl	0x10030d8f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007c28c0:     	cbz	w0, 0x1007c29c8 <_js_array_get_f64+0x378>
1007c28c4:     	mov	x22, #0x1               ; =1
1007c28c8:     	movk	x22, #0x7ffc, lsl #48
1007c28cc:     	lsr	x8, x20, #51
1007c28d0:     	cmp	x8, #0xfff
1007c28d4:     	b.lo	0x1007c28e8 <_js_array_get_f64+0x298>
1007c28d8:     	mov	w8, #0x7ffc             ; =32764
1007c28dc:     	cmp	x8, x20, lsr #48
1007c28e0:     	b.eq	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c28e4:     	and	x20, x20, #0xffffffffffff
1007c28e8:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c28ec:     	b.lo	0x1007c290c <_js_array_get_f64+0x2bc>
1007c28f0:     	tst	x20, #0xffff800000000000
1007c28f4:     	mov	w8, #0x1000             ; =4096
1007c28f8:     	ccmp	x20, x8, #0x0, eq
1007c28fc:     	b.lo	0x1007c290c <_js_array_get_f64+0x2bc>
1007c2900:     	ldurb	w8, [x20, #-0x8]
1007c2904:     	cmp	w8, #0x2
1007c2908:     	b.eq	0x1007c304c <_js_array_get_f64+0x9fc>
1007c290c:     	cbz	x20, 0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c2910:     	mov	x0, x20
1007c2914:     	mov	x1, x19
1007c2918:     	bl	0x10030f570 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007c291c:     	cmp	w0, #0x1
1007c2920:     	b.ne	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c2924:     	ldr	x8, [x20, #0x8]
1007c2928:     	ldr	x22, [x8, w1, uxtw #3]
1007c292c:     	b	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c2930:     	mov	x0, x22
1007c2934:     	mov	x1, x19
1007c2938:     	bl	0x10054b4cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007c293c:     	tbnz	w0, #0x0, 0x1007c2d44 <_js_array_get_f64+0x6f4>
1007c2940:     	mov	w24, #0x2               ; =2
1007c2944:     	b	0x1007c2798 <_js_array_get_f64+0x148>
1007c2948:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c294c:     	add	x8, x8, #0xec0
1007c2950:     	ldaprb	w8, [x8]
1007c2954:     	cbz	w8, 0x1007c29b8 <_js_array_get_f64+0x368>
1007c2958:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c295c:     	add	x8, x8, #0x58
1007c2960:     	ldapr	x8, [x8]
1007c2964:     	cmp	x20, x8
1007c2968:     	b.lo	0x1007c29b8 <_js_array_get_f64+0x368>
1007c296c:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2970:     	add	x8, x8, #0x60
1007c2974:     	ldapr	x8, [x8]
1007c2978:     	cmp	x20, x8
1007c297c:     	b.hi	0x1007c29b8 <_js_array_get_f64+0x368>
1007c2980:     	mov	x0, x20
1007c2984:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2988:     	tbz	w0, #0x0, 0x1007c29b8 <_js_array_get_f64+0x368>
1007c298c:     	add	x0, sp, #0x8
1007c2990:     	mov	x1, x20
1007c2994:     	bl	0x1002a746c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007c2998:     	ldr	x8, [sp, #0x8]
1007c299c:     	cbz	x8, 0x1007c2fc4 <_js_array_get_f64+0x974>
1007c29a0:     	cmp	x8, #0x1
1007c29a4:     	b.ne	0x1007c3008 <_js_array_get_f64+0x9b8>
1007c29a8:     	ldr	d0, [sp, #0x10]
1007c29ac:     	scvtf	d1, w19
1007c29b0:     	bl	0x100820bf4 <_js_dyn_index_get>
1007c29b4:     	b	0x1007c2d44 <_js_array_get_f64+0x6f4>
1007c29b8:     	mov	w24, #0xb               ; =11
1007c29bc:     	b	0x1007c2798 <_js_array_get_f64+0x148>
1007c29c0:     	mov	w24, #0x8               ; =8
1007c29c4:     	b	0x1007c2798 <_js_array_get_f64+0x148>
1007c29c8:     	mov	w24, #0xc               ; =12
1007c29cc:     	b	0x1007c2798 <_js_array_get_f64+0x148>
1007c29d0:     	add	x9, x8, #0x60
1007c29d4:     	b	0x1007c2f84 <_js_array_get_f64+0x934>
1007c29d8:     	bl	0x100b440bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007c29dc:     	lsr	x1, x21, #20
1007c29e0:     	ldr	x8, [x0, #0x10]
1007c29e4:     	ldrb	w9, [x8]
1007c29e8:     	cmp	w9, #0x2
1007c29ec:     	b.eq	0x1007c2810 <_js_array_get_f64+0x1c0>
1007c29f0:     	ldr	x9, [x8, #0x8]
1007c29f4:     	ldr	x10, [x8, #0x28]
1007c29f8:     	sub	x9, x1, x9
1007c29fc:     	cmp	x9, x10
1007c2a00:     	b.hs	0x1007c2a44 <_js_array_get_f64+0x3f4>
1007c2a04:     	ldr	x10, [x8, #0x20]
1007c2a08:     	mov	w11, #0x28              ; =40
1007c2a0c:     	madd	x9, x9, x11, x10
1007c2a10:     	ldr	x10, [x9]
1007c2a14:     	ldr	x11, [x8, #0x10]
1007c2a18:     	cmp	x10, x11
1007c2a1c:     	b.ne	0x1007c2a50 <_js_array_get_f64+0x400>
1007c2a20:     	ldp	x10, x11, [x9, #0x8]
1007c2a24:     	cmp	x10, x21
1007c2a28:     	ccmp	x11, x21, #0x0, ls
1007c2a2c:     	b.ls	0x1007c2a50 <_js_array_get_f64+0x400>
1007c2a30:     	ldr	x10, [x8, #0x30]
1007c2a34:     	add	x10, x10, #0x1
1007c2a38:     	str	x10, [x8, #0x30]
1007c2a3c:     	add	x8, x9, #0x21
1007c2a40:     	b	0x1007c2f94 <_js_array_get_f64+0x944>
1007c2a44:     	ldr	x9, [x8, #0x58]
1007c2a48:     	add	x9, x9, #0x1
1007c2a4c:     	str	x9, [x8, #0x58]
1007c2a50:     	ldr	x9, [x8, #0x38]
1007c2a54:     	add	x9, x9, #0x1
1007c2a58:     	str	x9, [x8, #0x38]
1007c2a5c:     	mov	x0, x21
1007c2a60:     	bl	0x100521208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007c2a64:     	and	w8, w0, #0xff
1007c2a68:     	cbz	w8, 0x1007c2a88 <_js_array_get_f64+0x438>
1007c2a6c:     	ldurb	w8, [x21, #-0x8]
1007c2a70:     	ldurb	w9, [x21, #-0x7]
1007c2a74:     	mov	w10, #0x82              ; =130
1007c2a78:     	and	w9, w9, w10
1007c2a7c:     	cmp	w9, #0x2
1007c2a80:     	ccmp	w8, #0x1, #0x0, eq
1007c2a84:     	b.eq	0x1007c2b58 <_js_array_get_f64+0x508>
1007c2a88:     	mov	x0, x21
1007c2a8c:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2a90:     	cbz	x0, 0x1007c2ab8 <_js_array_get_f64+0x468>
1007c2a94:     	ldrb	w9, [x0]
1007c2a98:     	cmp	w9, #0x1
1007c2a9c:     	b.ne	0x1007c2ad4 <_js_array_get_f64+0x484>
1007c2aa0:     	ldrsb	w8, [x0, #0x1]
1007c2aa4:     	tbnz	w8, #0x1f, 0x1007c2b80 <_js_array_get_f64+0x530>
1007c2aa8:     	ldp	w10, w9, [x21]
1007c2aac:     	cmp	w10, w9
1007c2ab0:     	b.hi	0x1007c2c0c <_js_array_get_f64+0x5bc>
1007c2ab4:     	b	0x1007c2c24 <_js_array_get_f64+0x5d4>
1007c2ab8:     	mov	x25, x0
1007c2abc:     	mov	x0, x21
1007c2ac0:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2ac4:     	tbz	w0, #0x0, 0x1007c2b10 <_js_array_get_f64+0x4c0>
1007c2ac8:     	mov	x0, #0x0                ; =0
1007c2acc:     	mov	x8, x25
1007c2ad0:     	b	0x1007c2bfc <_js_array_get_f64+0x5ac>
1007c2ad4:     	mov	x8, x0
1007c2ad8:     	cmp	w9, #0x1
1007c2adc:     	b.eq	0x1007c2bfc <_js_array_get_f64+0x5ac>
1007c2ae0:     	cmp	w9, #0x9
1007c2ae4:     	b.ne	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2ae8:     	ldr	w8, [x21, #0x4]
1007c2aec:     	mov	w9, #0x5841             ; =22593
1007c2af0:     	movk	w9, #0x4c5a, lsl #16
1007c2af4:     	cmp	w8, w9
1007c2af8:     	b.ne	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2afc:     	mov	x0, x21
1007c2b00:     	bl	0x100378910 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007c2b04:     	cbz	x0, 0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2b08:     	mov	x21, x0
1007c2b0c:     	b	0x1007c2c40 <_js_array_get_f64+0x5f0>
1007c2b10:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2b14:     	add	x8, x8, #0xec0
1007c2b18:     	ldaprb	w8, [x8]
1007c2b1c:     	cbz	w8, 0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2b20:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2b24:     	add	x8, x8, #0x58
1007c2b28:     	ldapr	x8, [x8]
1007c2b2c:     	cmp	x8, x21
1007c2b30:     	b.hi	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2b34:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2b38:     	add	x8, x8, #0x60
1007c2b3c:     	ldapr	x8, [x8]
1007c2b40:     	cmp	x8, x21
1007c2b44:     	b.lo	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2b48:     	mov	x0, x21
1007c2b4c:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2b50:     	tbnz	w0, #0x0, 0x1007c2ac8 <_js_array_get_f64+0x478>
1007c2b54:     	b	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2b58:     	ldr	w8, [x21]
1007c2b5c:     	mov	w9, #0xe100             ; =57600
1007c2b60:     	movk	w9, #0x5f5, lsl #16
1007c2b64:     	orr	w9, w9, #0x1
1007c2b68:     	cmp	w8, w9
1007c2b6c:     	b.hs	0x1007c2a88 <_js_array_get_f64+0x438>
1007c2b70:     	ldr	w9, [x21, #0x4]
1007c2b74:     	cmp	w8, w9
1007c2b78:     	b.ls	0x1007c2c40 <_js_array_get_f64+0x5f0>
1007c2b7c:     	b	0x1007c2a88 <_js_array_get_f64+0x438>
1007c2b80:     	mov	x25, x0
1007c2b84:     	ldr	x21, [x0, #0x8]
1007c2b88:     	mov	x0, x21
1007c2b8c:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2b90:     	cbz	x0, 0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2b94:     	ldrb	w8, [x0]
1007c2b98:     	cmp	w8, #0x1
1007c2b9c:     	b.ne	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2ba0:     	ldrsb	w8, [x0, #0x1]
1007c2ba4:     	tbz	w8, #0x1f, 0x1007c2aa8 <_js_array_get_f64+0x458>
1007c2ba8:     	mov	w26, #0x1               ; =1
1007c2bac:     	ldr	x21, [x0, #0x8]
1007c2bb0:     	mov	x0, x21
1007c2bb4:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2bb8:     	cbz	x0, 0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2bbc:     	ldrb	w8, [x0]
1007c2bc0:     	cmp	w8, #0x1
1007c2bc4:     	b.ne	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2bc8:     	cmp	w26, #0x3f
1007c2bcc:     	b.hi	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2bd0:     	add	w26, w26, #0x1
1007c2bd4:     	ldrsb	w8, [x0, #0x1]
1007c2bd8:     	tbnz	w8, #0x1f, 0x1007c2bac <_js_array_get_f64+0x55c>
1007c2bdc:     	str	x21, [x25, #0x8]
1007c2be0:     	ldrb	w8, [x25, #0x1]
1007c2be4:     	orr	w9, w8, #0x80
1007c2be8:     	mov	x8, x25
1007c2bec:     	strb	w9, [x25, #0x1]
1007c2bf0:     	ldrb	w9, [x0]
1007c2bf4:     	cmp	w9, #0x1
1007c2bf8:     	b.ne	0x1007c2ae0 <_js_array_get_f64+0x490>
1007c2bfc:     	ldp	w10, w9, [x21]
1007c2c00:     	cmp	w10, w9
1007c2c04:     	b.ls	0x1007c2c24 <_js_array_get_f64+0x5d4>
1007c2c08:     	cbz	x8, 0x1007c2c34 <_js_array_get_f64+0x5e4>
1007c2c0c:     	ldr	w8, [x0, #0x4]
1007c2c10:     	ubfiz	x9, x9, #3, #32
1007c2c14:     	add	x9, x9, #0x10
1007c2c18:     	cmp	x9, x8
1007c2c1c:     	b.eq	0x1007c2c40 <_js_array_get_f64+0x5f0>
1007c2c20:     	b	0x1007c2c34 <_js_array_get_f64+0x5e4>
1007c2c24:     	mov	w8, #0xe100             ; =57600
1007c2c28:     	movk	w8, #0x5f5, lsl #16
1007c2c2c:     	cmp	w10, w8
1007c2c30:     	b.ls	0x1007c2c40 <_js_array_get_f64+0x5f0>
1007c2c34:     	mov	x0, x21
1007c2c38:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2c3c:     	tbz	w0, #0x0, 0x1007c2cf0 <_js_array_get_f64+0x6a0>
1007c2c40:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2c44:     	add	x8, x8, #0xec0
1007c2c48:     	ldaprb	w8, [x8]
1007c2c4c:     	cbz	w8, 0x1007c2c94 <_js_array_get_f64+0x644>
1007c2c50:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2c54:     	add	x8, x8, #0x58
1007c2c58:     	ldapr	x8, [x8]
1007c2c5c:     	cmp	x21, x8
1007c2c60:     	b.lo	0x1007c2c94 <_js_array_get_f64+0x644>
1007c2c64:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2c68:     	add	x8, x8, #0x60
1007c2c6c:     	ldapr	x8, [x8]
1007c2c70:     	cmp	x21, x8
1007c2c74:     	b.hi	0x1007c2c94 <_js_array_get_f64+0x644>
1007c2c78:     	mov	x0, x21
1007c2c7c:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2c80:     	tbz	w0, #0x0, 0x1007c2c94 <_js_array_get_f64+0x644>
1007c2c84:     	mov	x0, x21
1007c2c88:     	mov	x1, x19
1007c2c8c:     	bl	0x100900908 <_js_typed_array_get>
1007c2c90:     	b	0x1007c2d44 <_js_array_get_f64+0x6f4>
1007c2c94:     	mov	x0, x21
1007c2c98:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2c9c:     	tbz	w0, #0x0, 0x1007c2cc4 <_js_array_get_f64+0x674>
1007c2ca0:     	mov	x0, x21
1007c2ca4:     	mov	x1, x19
1007c2ca8:     	bl	0x1005893dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007c2cac:     	and	w8, w1, #0xff
1007c2cb0:     	ucvtf	d0, w8
1007c2cb4:     	fmov	x8, d0
1007c2cb8:     	tst	w0, #0x1
1007c2cbc:     	csel	x22, x8, xzr, ne
1007c2cc0:     	b	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c2cc4:     	cmp	x21, x20
1007c2cc8:     	b.eq	0x1007c2d70 <_js_array_get_f64+0x720>
1007c2ccc:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007c2cd0:     	b.lo	0x1007c2d68 <_js_array_get_f64+0x718>
1007c2cd4:     	tst	x21, #0xffff800000000000
1007c2cd8:     	mov	w8, #0x1000             ; =4096
1007c2cdc:     	ccmp	x21, x8, #0x0, eq
1007c2ce0:     	b.lo	0x1007c2d68 <_js_array_get_f64+0x718>
1007c2ce4:     	ldurb	w24, [x21, #-0x8]
1007c2ce8:     	ldurh	w23, [x21, #-0x6]
1007c2cec:     	b	0x1007c2d70 <_js_array_get_f64+0x720>
1007c2cf0:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2cf4:     	add	x8, x8, #0xec0
1007c2cf8:     	ldaprb	w8, [x8]
1007c2cfc:     	cbz	w8, 0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2d00:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2d04:     	add	x8, x8, #0x58
1007c2d08:     	ldapr	x8, [x8]
1007c2d0c:     	cmp	x21, x8
1007c2d10:     	b.lo	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2d14:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2d18:     	add	x8, x8, #0x60
1007c2d1c:     	ldapr	x8, [x8]
1007c2d20:     	cmp	x21, x8
1007c2d24:     	b.hi	0x1007c2d34 <_js_array_get_f64+0x6e4>
1007c2d28:     	mov	x0, x21
1007c2d2c:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2d30:     	tbnz	w0, #0x0, 0x1007c2c40 <_js_array_get_f64+0x5f0>
1007c2d34:     	mov	x0, x22
1007c2d38:     	mov	x1, x19
1007c2d3c:     	bl	0x10054b4cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007c2d40:     	tbz	w0, #0x0, 0x1007c3018 <_js_array_get_f64+0x9c8>
1007c2d44:     	fmov	x22, d0
1007c2d48:     	fmov	d0, x22
1007c2d4c:     	ldp	x29, x30, [sp, #0x60]
1007c2d50:     	ldp	x20, x19, [sp, #0x50]
1007c2d54:     	ldp	x22, x21, [sp, #0x40]
1007c2d58:     	ldp	x24, x23, [sp, #0x30]
1007c2d5c:     	ldp	x26, x25, [sp, #0x20]
1007c2d60:     	add	sp, sp, #0x70
1007c2d64:     	ret
1007c2d68:     	mov	w23, #0x0               ; =0
1007c2d6c:     	mov	w24, #0x0               ; =0
1007c2d70:     	cmp	w24, #0x1
1007c2d74:     	b.ne	0x1007c2f28 <_js_array_get_f64+0x8d8>
1007c2d78:     	tbz	w23, #0xa, 0x1007c2f28 <_js_array_get_f64+0x8d8>
1007c2d7c:     	adrp	x8, 0x100b69000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data15grapheme_extend7OFFSETS+0x1a5>
1007c2d80:     	add	x8, x8, #0xb0c
1007c2d84:     	cmp	w19, #0x3e8
1007c2d88:     	b.lo	0x1007c2e00 <_js_array_get_f64+0x7b0>
1007c2d8c:     	mov	x9, #0x0                ; =0
1007c2d90:     	mov	w11, #0x1759            ; =5977
1007c2d94:     	movk	w11, #0xd1b7, lsl #16
1007c2d98:     	mov	w12, #0x2710            ; =10000
1007c2d9c:     	mov	w13, #0x147b            ; =5243
1007c2da0:     	mov	w14, #0x64              ; =100
1007c2da4:     	add	x15, sp, #0x8
1007c2da8:     	mov	w16, #0x967f            ; =38527
1007c2dac:     	movk	w16, #0x98, lsl #16
1007c2db0:     	mov	x10, x19
1007c2db4:     	mov	x17, x10
1007c2db8:     	umull	x10, w10, w11
1007c2dbc:     	lsr	x10, x10, #45
1007c2dc0:     	msub	w0, w10, w12, w17
1007c2dc4:     	ubfx	w1, w0, #2, #14
1007c2dc8:     	mul	w1, w1, w13
1007c2dcc:     	lsr	w1, w1, #17
1007c2dd0:     	msub	w0, w1, w14, w0
1007c2dd4:     	add	x2, x15, x9
1007c2dd8:     	ldrh	w1, [x8, w1, uxtw #1]
1007c2ddc:     	strh	w1, [x2, #0x6]
1007c2de0:     	and	x0, x0, #0xffff
1007c2de4:     	ldrh	w0, [x8, x0, lsl #1]
1007c2de8:     	strh	w0, [x2, #0x8]
1007c2dec:     	sub	x9, x9, #0x4
1007c2df0:     	cmp	w17, w16
1007c2df4:     	b.hi	0x1007c2db4 <_js_array_get_f64+0x764>
1007c2df8:     	add	x9, x9, #0xa
1007c2dfc:     	b	0x1007c2e08 <_js_array_get_f64+0x7b8>
1007c2e00:     	mov	w9, #0xa                ; =10
1007c2e04:     	mov	x10, x19
1007c2e08:     	cmp	w10, #0x9
1007c2e0c:     	b.ls	0x1007c2e40 <_js_array_get_f64+0x7f0>
1007c2e10:     	sub	x9, x9, #0x2
1007c2e14:     	ubfx	w11, w10, #2, #14
1007c2e18:     	mov	w12, #0x147b            ; =5243
1007c2e1c:     	mul	w11, w11, w12
1007c2e20:     	lsr	w11, w11, #17
1007c2e24:     	mov	w12, #0x64              ; =100
1007c2e28:     	msub	w10, w11, w12, w10
1007c2e2c:     	and	x10, x10, #0xffff
1007c2e30:     	ldrh	w10, [x8, x10, lsl #1]
1007c2e34:     	add	x12, sp, #0x8
1007c2e38:     	strh	w10, [x12, x9]
1007c2e3c:     	mov	x10, x11
1007c2e40:     	cbz	w19, 0x1007c2e78 <_js_array_get_f64+0x828>
1007c2e44:     	cbnz	w10, 0x1007c2e78 <_js_array_get_f64+0x828>
1007c2e48:     	cmp	x9, #0xa
1007c2e4c:     	b.ne	0x1007c2ea0 <_js_array_get_f64+0x850>
1007c2e50:     	mov	w23, #0x1               ; =1
1007c2e54:     	add	x0, sp, #0x8
1007c2e58:     	mov	x1, x21
1007c2e5c:     	mov	w2, #0x1                ; =1
1007c2e60:     	mov	x3, #0x0                ; =0
1007c2e64:     	bl	0x1005b57bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007c2e68:     	ldr	x8, [sp, #0x8]
1007c2e6c:     	mov	w20, #0x1               ; =1
1007c2e70:     	cbnz	x8, 0x1007c2ef0 <_js_array_get_f64+0x8a0>
1007c2e74:     	b	0x1007c2f28 <_js_array_get_f64+0x8d8>
1007c2e78:     	sub	x23, x9, #0x1
1007c2e7c:     	ubfiz	w10, w10, #1, #4
1007c2e80:     	add	x8, x8, x10
1007c2e84:     	ldrb	w8, [x8, #0x1]
1007c2e88:     	add	x10, sp, #0x8
1007c2e8c:     	strb	w8, [x10, x23]
1007c2e90:     	mov	w8, #0xb                ; =11
1007c2e94:     	b	0x1007c2ea8 <_js_array_get_f64+0x858>
1007c2e98:     	add	x9, x8, #0x90
1007c2e9c:     	b	0x1007c2f84 <_js_array_get_f64+0x934>
1007c2ea0:     	mov	w8, #0xa                ; =10
1007c2ea4:     	mov	x23, x9
1007c2ea8:     	sub	x22, x8, x9
1007c2eac:     	mov	x0, x22
1007c2eb0:     	mov	w1, #0x1                ; =1
1007c2eb4:     	bl	0x100b63f48 <_mi_malloc_aligned>
1007c2eb8:     	cbz	x0, 0x1007c3064 <_js_array_get_f64+0xa14>
1007c2ebc:     	mov	x20, x0
1007c2ec0:     	add	x8, sp, #0x8
1007c2ec4:     	add	x1, x8, x23
1007c2ec8:     	mov	x2, x22
1007c2ecc:     	bl	0x100b66b6c <_writev+0x100b66b6c>
1007c2ed0:     	add	x0, sp, #0x8
1007c2ed4:     	mov	x1, x21
1007c2ed8:     	mov	x2, x20
1007c2edc:     	mov	x3, x22
1007c2ee0:     	bl	0x1005b57bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007c2ee4:     	ldr	w8, [sp, #0x8]
1007c2ee8:     	tbz	w8, #0x0, 0x1007c2f20 <_js_array_get_f64+0x8d0>
1007c2eec:     	mov	w23, #0x0               ; =0
1007c2ef0:     	mov	x22, #0x1               ; =1
1007c2ef4:     	movk	x22, #0x7ffc, lsl #48
1007c2ef8:     	ldr	x0, [sp, #0x10]
1007c2efc:     	cbz	x0, 0x1007c2fb4 <_js_array_get_f64+0x964>
1007c2f00:     	cbz	x21, 0x1007c2fa4 <_js_array_get_f64+0x954>
1007c2f04:     	lsr	x8, x21, #52
1007c2f08:     	cmp	x8, #0x7fe
1007c2f0c:     	b.hi	0x1007c2fa8 <_js_array_get_f64+0x958>
1007c2f10:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007c2f14:     	bfxil	x8, x21, #0, #48
1007c2f18:     	mov	x21, x8
1007c2f1c:     	b	0x1007c2fa8 <_js_array_get_f64+0x958>
1007c2f20:     	mov	x0, x20
1007c2f24:     	bl	0x100b63cc0 <_mi_free>
1007c2f28:     	ldr	w8, [x21]
1007c2f2c:     	cmp	w19, w8
1007c2f30:     	b.hs	0x1007c2f70 <_js_array_get_f64+0x920>
1007c2f34:     	ldr	w8, [x21, #0x4]
1007c2f38:     	cmp	w19, w8
1007c2f3c:     	b.hs	0x1007c2f60 <_js_array_get_f64+0x910>
1007c2f40:     	add	x8, x21, w19, uxtw #3
1007c2f44:     	ldr	x22, [x8, #0x8]
1007c2f48:     	mov	x8, #0x1                ; =1
1007c2f4c:     	movk	x8, #0x7ffc, lsl #48
1007c2f50:     	add	x8, x8, #0xf
1007c2f54:     	cmp	x22, x8
1007c2f58:     	b.ne	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c2f5c:     	b	0x1007c2f70 <_js_array_get_f64+0x920>
1007c2f60:     	mov	x0, x21
1007c2f64:     	mov	x1, x19
1007c2f68:     	bl	0x10052d8c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007c2f6c:     	tbnz	w0, #0x0, 0x1007c2d44 <_js_array_get_f64+0x6f4>
1007c2f70:     	mov	x0, x21
1007c2f74:     	mov	x1, x19
1007c2f78:     	bl	0x1006cb930 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007c2f7c:     	b	0x1007c2d44 <_js_array_get_f64+0x6f4>
1007c2f80:     	add	x9, x8, #0xc0
1007c2f84:     	ldr	x10, [x8, #0x30]
1007c2f88:     	add	x10, x10, #0x1
1007c2f8c:     	str	x10, [x8, #0x30]
1007c2f90:     	add	x8, x9, #0x19
1007c2f94:     	ldrb	w8, [x8]
1007c2f98:     	cmp	w8, #0xff
1007c2f9c:     	b.ne	0x1007c2a68 <_js_array_get_f64+0x418>
1007c2fa0:     	b	0x1007c2a5c <_js_array_get_f64+0x40c>
1007c2fa4:     	add	x21, x22, #0x1
1007c2fa8:     	fmov	d0, x21
1007c2fac:     	bl	0x10070177c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007c2fb0:     	mov	x22, x0
1007c2fb4:     	tbnz	w23, #0x0, 0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c2fb8:     	mov	x0, x20
1007c2fbc:     	bl	0x100b63cc0 <_mi_free>
1007c2fc0:     	b	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c2fc4:     	ldr	x20, [sp, #0x10]
1007c2fc8:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2fcc:     	ldr	x8, [x8, #0xed8]
1007c2fd0:     	cbz	x8, 0x1007c2fe8 <_js_array_get_f64+0x998>
1007c2fd4:     	mov	x0, x20
1007c2fd8:     	bl	0x10013cc40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007c2fdc:     	tbz	w0, #0x0, 0x1007c2fe8 <_js_array_get_f64+0x998>
1007c2fe0:     	mov	x0, x20
1007c2fe4:     	bl	0x1002c1840 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007c2fe8:     	tbnz	w19, #0x1f, 0x1007c3008 <_js_array_get_f64+0x9b8>
1007c2fec:     	ldr	w8, [x20]
1007c2ff0:     	cmp	w19, w8
1007c2ff4:     	b.hs	0x1007c3008 <_js_array_get_f64+0x9b8>
1007c2ff8:     	mov	w1, w19
1007c2ffc:     	mov	x0, x20
1007c3000:     	bl	0x1002a7acc <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007c3004:     	b	0x1007c2d44 <_js_array_get_f64+0x6f4>
1007c3008:     	mov	x8, #0x1                ; =1
1007c300c:     	movk	x8, #0x7ffc, lsl #48
1007c3010:     	mov	x22, x8
1007c3014:     	b	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c3018:     	mov	x0, x22
1007c301c:     	bl	0x100b4c630 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007c3020:     	cmp	x0, #0x1
1007c3024:     	b.ne	0x1007c2690 <_js_array_get_f64+0x40>
1007c3028:     	mov	x0, x19
1007c302c:     	bl	0x100b4c650 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007c3030:     	b	0x1007c2d44 <_js_array_get_f64+0x6f4>
1007c3034:     	mov	x0, x20
1007c3038:     	mov	w1, #0x0                ; =0
1007c303c:     	bl	0x100b4ebc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007c3040:     	mov	x20, x0
1007c3044:     	cbnz	x0, 0x1007c276c <_js_array_get_f64+0x11c>
1007c3048:     	b	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c304c:     	mov	x0, x20
1007c3050:     	mov	w1, #0x1                ; =1
1007c3054:     	bl	0x100b4ebc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007c3058:     	mov	x20, x0
1007c305c:     	cbnz	x0, 0x1007c2910 <_js_array_get_f64+0x2c0>
1007c3060:     	b	0x1007c2d48 <_js_array_get_f64+0x6f8>
1007c3064:     	mov	w0, #0x1                ; =1
1007c3068:     	mov	x1, x22
1007c306c:     	bl	0x100b17040 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
