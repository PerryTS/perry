; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/native-vector-escape-r40/candidate-ir-native/test_json_template_capture/.perry-trace/llvm/test_json_template_capture_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@test_json_template_capture_ts_.str.0 = private unnamed_addr constant [134 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/test_json_template_capture.ts\00"
@test_json_template_capture_ts_.str.0.bytes = private unnamed_addr constant [6 x i8] c"value\00"
@test_json_template_capture_ts_.str.1.bytes = private unnamed_addr constant [9 x i8] c"expected\00"
@test_json_template_capture_ts_.str.2.bytes = private unnamed_addr constant [3 x i8] c"id\00"
@test_json_template_capture_ts_.str.3.bytes = private unnamed_addr constant [5 x i8] c"name\00"
@test_json_template_capture_ts_.str.4.bytes = private unnamed_addr constant [107 x i8] c"{\22padding\22:\22enough-padding-to-enter-the-small-object-template-path\22,\22items\22:[\22alpha-value\22,2,true],\22id\22:7}\00"
@test_json_template_capture_ts_.str.5.bytes = private unnamed_addr constant [108 x i8] c"{\22padding\22:\22another-padding-to-enter-the-small-object-template-path\22,\22items\22:[\22beta-value\22,false,3],\22id\22:8}\00"
@test_json_template_capture_ts_.str.6.bytes = private unnamed_addr constant [110 x i8] c"{\22padding\22:\22different-padding-to-enter-the-small-object-template-path\22,\22items\22:[\22gamma-value\22,4,null],\22id\22:9}\00"
@test_json_template_capture_ts_.str.7.bytes = private unnamed_addr constant [105 x i8] c"{\22padding\22:\22enough-padding-to-enter-the-small-object-template-path\22,\22items\22:[\22new\22,3],\22nested\22:{\22id\22:1}}\00"
@test_json_template_capture_ts_.str.8.bytes = private unnamed_addr constant [32 x i8] c"rejected capture changed output\00"
@test_json_template_capture_ts_.str.9.bytes = private unnamed_addr constant [6 x i8] c"items\00"
@test_json_template_capture_ts_.str.10.bytes = private unnamed_addr constant [8 x i8] c"changed\00"
@test_json_template_capture_ts_.str.11.bytes = private unnamed_addr constant [5 x i8] c"push\00"
@test_json_template_capture_ts_.str.12.bytes = private unnamed_addr constant [7 x i8] c"length\00"
@test_json_template_capture_ts_.str.13.bytes = private unnamed_addr constant [32 x i8] c"cached mutable array was shared\00"
@test_json_template_capture_ts_.str.14.bytes = private unnamed_addr constant [24 x i8] c"cached template changed\00"
@test_json_template_capture_ts_.str.15.bytes = private unnamed_addr constant [10 x i8] c"pressure-\00"
@test_json_template_capture_ts_.str.16.bytes = private unnamed_addr constant [23 x i8] c"retained value changed\00"
@test_json_template_capture_ts_.str.17.bytes = private unnamed_addr constant [6 x i8] c"saved\00"
@test_json_template_capture_ts_.str.18.bytes = private unnamed_addr constant [5 x i8] c"done\00"
@perry_class_keys_packed_test_json_template_capture_ts__0 = private unnamed_addr constant [16 x i8] c"value\00expected\00\00"
@perry_class_keys_packed_test_json_template_capture_ts__1 = private unnamed_addr constant [9 x i8] c"id\00name\00\00"
@test_json_template_capture_ts_.str.1 = private unnamed_addr constant [33 x i8] c"new __AnonShape_a0fce79cb5df4a18\00"
@test_json_template_capture_ts_.str.2 = private unnamed_addr constant [33 x i8] c"new __AnonShape_570a27fd5b93ea38\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_test_json_template_capture_ts = internal global i32 0
@perry_class_keys_test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18 = internal global i64 0
@perry_class_shape_id_test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18 = global i32 0
@perry_class_header_image_test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18 = internal global <2 x i64> zeroinitializer
@perry_class_keys_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38 = internal global i64 0
@perry_class_shape_id_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38 = global i32 0
@perry_class_header_image_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38 = internal global <2 x i64> zeroinitializer
@perry_ic_test_json_template_capture_ts__6 = private global ptr null
@perry_ic_test_json_template_capture_ts__8 = private global ptr null
@perry_ic_test_json_template_capture_ts__11 = private global ptr null
@perry_ic_test_json_template_capture_ts__13 = private global ptr null
@perry_ic_test_json_template_capture_ts__15 = private global ptr null
@perry_ic_test_json_template_capture_ts__16 = private global ptr null
@perry_ic_test_json_template_capture_ts__19 = private global ptr null
@perry_ic_test_json_template_capture_ts__22 = private global ptr null
@perry_ic_test_json_template_capture_ts__23 = private global ptr null
@perry_ic_test_json_template_capture_ts__29 = private global ptr null
@perry_ic_test_json_template_capture_ts__32 = private global ptr null
@perry_ic_test_json_template_capture_ts__33 = private global ptr null
@perry_ic_test_json_template_capture_ts__34 = private global ptr null
@perry_concat_site_test_json_template_capture_ts__17 = private global [32 x i64] zeroinitializer
@test_json_template_capture_ts_.str.0.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.1.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.2.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.3.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.4.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.5.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.6.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.7.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.8.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.9.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.10.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.11.dispatch = private unnamed_addr constant { i32, i32, i64, ptr } { i32 4, i32 0, i64 7818252312440358301, ptr @test_json_template_capture_ts_.str.11.bytes }
@test_json_template_capture_ts_.str.11.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.12.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.13.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.14.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.15.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.16.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.17.handle = internal global double 0.000000e+00
@test_json_template_capture_ts_.str.18.handle = internal global double 0.000000e+00
@perry_typed_shape_mask_test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18 = private unnamed_addr constant [1 x i64] [i64 3]
@perry_typed_shape_raw_f64_mask_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38 = private unnamed_addr constant [1 x i64] [i64 1]
@perry_typed_shape_mask_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38 = private unnamed_addr constant [1 x i64] [i64 2]

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_6()

declare double @__ic_decl_8()

declare double @__ic_decl_11()

declare double @__ic_decl_13()

declare double @__ic_decl_15()

declare double @__ic_decl_19()

declare double @__ic_decl_22()

declare double @__ic_decl_29()

declare double @__ic_decl_32()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define double @test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18_constructor(double %this_arg, double %arg10, double %arg11) #6 gc "statepoint-example" {
entry.0:
  %r8 = load i32, ptr @perry_class_shape_id_test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg10 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg11 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #7
  %r5 = bitcast i64 %r5.rs4o to double
  %r6.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r6.rs4o = call i64 asm "", "=r,0"(i64 %r6.rs4i) #7
  %r6 = bitcast i64 %r6.rs4o to double
  %r10 = bitcast double %r5 to i64
  %r11 = and i64 %r10, 281474976710655
  %r12 = load double, ptr @test_json_template_capture_ts_.str.0.handle, align 8
  %r13 = bitcast double %r12 to i64
  %r14 = and i64 %r13, 281474976710655
  %r15 = bitcast double %r6 to i64
  %r16 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r17 = icmp eq i8 %r16, 0
  %r18 = lshr i64 %r10, 48
  %r19 = icmp eq i64 %r18, 32765
  %r20 = icmp ugt i64 %r11, 1048575
  %r21 = and i1 %r19, %r20
  %r22 = and i1 %r21, %r17
  br i1 %r22, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.14
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r230.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r230.rs4o = call i64 asm "", "=r,0"(i64 %r230.rs4i) #7
  %r230 = bitcast i64 %r230.rs4o to double
  %r231 = bitcast double %r230 to i64
  %r232 = and i64 %r231, 281474976710655
  %r53 = inttoptr i64 %r232 to ptr
  %r226.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r226.rs4o = call i64 asm "", "=r,0"(i64 %r226.rs4i) #7
  %r226 = bitcast i64 %r226.rs4o to double
  %r227 = bitcast double %r226 to i64
  %r228 = and i64 %r227, 281474976710655
  %r229 = inttoptr i64 %r228 to ptr
  %r54 = getelementptr i8, ptr %r229, i64 16
  %r55 = getelementptr double, ptr %r54, i64 0
  %r56 = ptrtoint ptr %r55 to i64
  %r225.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r225.rs4o = call i64 asm "", "=r,0"(i64 %r225.rs4i) #7
  %r225 = bitcast i64 %r225.rs4o to double
  store double %r225, ptr %r55, align 8
  %r224.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r224.rs4o = call i64 asm "", "=r,0"(i64 %r224.rs4i) #7
  %r224 = bitcast i64 %r224.rs4o to double
  %r57 = bitcast double %r224 to i64
  %r222.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r222.rs4o = call i64 asm "", "=r,0"(i64 %r222.rs4i) #7
  %r222 = bitcast i64 %r222.rs4o to double
  %r223 = bitcast double %r222 to i64
  %r58 = lshr i64 %r223, 48
  %r59 = icmp eq i64 %r58, 0
  %r220.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r220.rs4o = call i64 asm "", "=r,0"(i64 %r220.rs4i) #7
  %r220 = bitcast i64 %r220.rs4o to double
  %r221 = bitcast double %r220 to i64
  %r60 = icmp uge i64 %r221, 4096
  %r61 = and i1 %r59, %r60
  %r62 = icmp eq i64 %r58, 32765
  %r63 = icmp eq i64 %r58, 32767
  %r64 = icmp eq i64 %r58, 32762
  %r65 = or i1 %r62, %r63
  %r66 = or i1 %r65, %r64
  %r67 = or i1 %r66, %r61
  br i1 %r67, label %class_field_set.gc_bookkeeping.7, label %class_field_set.gc_bookkeeping.done.8

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r214.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r214.rs4o = call i64 asm "", "=r,0"(i64 %r214.rs4i) #7
  %r214 = bitcast i64 %r214.rs4o to double
  %r215 = bitcast double %r214 to i64
  %r216.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r216.rs4o = call i64 asm "", "=r,0"(i64 %r216.rs4i) #7
  %r216 = bitcast i64 %r216.rs4o to double
  %r217 = load double, ptr @test_json_template_capture_ts_.str.0.handle, align 8
  %r218 = bitcast double %r217 to i64
  %r219 = and i64 %r218, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6060382687846203392, i64 %r215, i64 %r219, double %r216, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s1) ]
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s1, %rs4gc.s1)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.gc_bookkeeping.done.8, %class_field_set.fallback.3
  %.02 = phi ptr addrspace(1) [ %rs4gc.s1, %class_field_set.gc_bookkeeping.done.8 ], [ %rs4gc.s1.relocated, %class_field_set.fallback.3 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %class_field_set.gc_bookkeeping.done.8 ], [ %rs4gc.s3.relocated, %class_field_set.fallback.3 ]
  %r81.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r81.rs4o = call i64 asm "", "=r,0"(i64 %r81.rs4i) #7
  %r81 = bitcast i64 %r81.rs4o to double
  %r82.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r82.rs4o = call i64 asm "", "=r,0"(i64 %r82.rs4i) #7
  %r82 = bitcast i64 %r82.rs4o to double
  %r84 = bitcast double %r81 to i64
  %r85 = and i64 %r84, 281474976710655
  %r86 = load double, ptr @test_json_template_capture_ts_.str.1.handle, align 8
  %r87 = bitcast double %r86 to i64
  %r88 = and i64 %r87, 281474976710655
  %r89 = bitcast double %r82 to i64
  %r90 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r91 = icmp eq i8 %r90, 0
  %r92 = lshr i64 %r84, 48
  %r93 = icmp eq i64 %r92, 32765
  %r94 = icmp ugt i64 %r85, 1048575
  %r95 = and i1 %r93, %r94
  %r96 = and i1 %r95, %r91
  br i1 %r96, label %class_field_inline.deref.15, label %class_field_inline.guardcall.16

class_field_inline.deref.5:                       ; preds = %entry.0
  %r23 = inttoptr i64 %r11 to ptr
  %r24 = getelementptr i8, ptr %r23, i64 -8
  %r25 = load i8, ptr %r24, align 1
  %r26 = icmp eq i8 %r25, 2
  %r27 = getelementptr i8, ptr %r23, i64 -7
  %r28 = load i8, ptr %r27, align 1
  %r29 = and i8 %r28, -128
  %r30 = icmp eq i8 %r29, 0
  %r31 = getelementptr i8, ptr %r23, i64 -6
  %r32 = load i16, ptr %r31, align 2
  %r33 = getelementptr i8, ptr %r23, i64 0
  %r34 = load i32, ptr %r33, align 4
  %r35 = icmp eq i32 %r34, 1
  %r36 = getelementptr i8, ptr %r23, i64 4
  %r37 = load i32, ptr %r36, align 4
  %r38 = icmp eq i32 %r37, %r8
  %r39 = and i1 %r26, %r30
  %r40 = and i1 %r39, %r35
  %r41 = and i1 %r40, %r38
  %r42 = and i16 %r32, 3072
  %r43 = icmp eq i16 %r42, 0
  %r44 = and i1 %r41, %r43
  %r45 = and i16 %r32, 1
  %r46 = icmp eq i16 %r45, 0
  %r47 = and i1 %r44, %r46
  %r48 = and i16 %r32, 128
  %r49 = icmp eq i16 %r48, 0
  %r50 = and i1 %r47, %r49
  br i1 %r50, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r51 = call i32 @js_typed_feedback_class_field_set_guard(i64 6060382687846203392, double %r5, i32 1, i32 %r8, i64 %r14, i32 0, double %r6, i32 0) #7
  %r52 = icmp ne i32 %r51, 0
  br i1 %r52, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.gc_bookkeeping.7:                 ; preds = %class_field_set.fast.2
  %r213.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r213.rs4o = call i64 asm "", "=r,0"(i64 %r213.rs4i) #7
  %r213 = bitcast i64 %r213.rs4o to double
  call void @js_string_addref_if_heap_string(double %r213) #7
  %r210.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r210.rs4o = call i64 asm "", "=r,0"(i64 %r210.rs4i) #7
  %r210 = bitcast i64 %r210.rs4o to double
  %r211 = bitcast double %r210 to i64
  %r212 = and i64 %r211, 281474976710655
  %r68 = inttoptr i64 %r212 to ptr
  %r206.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r206.rs4o = call i64 asm "", "=r,0"(i64 %r206.rs4i) #7
  %r206 = bitcast i64 %r206.rs4o to double
  %r207 = bitcast double %r206 to i64
  %r208 = and i64 %r207, 281474976710655
  %r209 = inttoptr i64 %r208 to ptr
  %r69 = getelementptr i8, ptr %r209, i64 -6
  %r70 = load i16, ptr %r69, align 2
  %r71 = and i16 %r70, -12288
  %r72 = icmp eq i16 %r71, -28672
  br i1 %r72, label %class_field_set.layout_note.done.10, label %class_field_set.layout_note.9

class_field_set.gc_bookkeeping.done.8:            ; preds = %class_field_set.barrier.11, %class_field_set.layout_note.done.10, %class_field_set.fast.2
  br label %class_field_set.merge.4

class_field_set.layout_note.9:                    ; preds = %class_field_set.gc_bookkeeping.7
  %r201.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r201.rs4o = call i64 asm "", "=r,0"(i64 %r201.rs4i) #7
  %r201 = bitcast i64 %r201.rs4o to double
  %r202 = bitcast double %r201 to i64
  %r203 = and i64 %r202, 281474976710655
  %r204.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r204.rs4o = call i64 asm "", "=r,0"(i64 %r204.rs4i) #7
  %r204 = bitcast i64 %r204.rs4o to double
  %r205 = bitcast double %r204 to i64
  call void @js_gc_note_slot_layout(i64 %r203, i32 0, i64 %r205) #7
  br label %class_field_set.layout_note.done.10

class_field_set.layout_note.done.10:              ; preds = %class_field_set.layout_note.9, %class_field_set.gc_bookkeeping.7
  %r198.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r198.rs4o = call i64 asm "", "=r,0"(i64 %r198.rs4i) #7
  %r198 = bitcast i64 %r198.rs4o to double
  %r199 = bitcast double %r198 to i64
  %r200 = and i64 %r199, 281474976710655
  %r73 = sub nsw i64 %r200, 7
  %r74 = inttoptr i64 %r73 to ptr
  %r75 = load i8, ptr %r74, align 1
  %r76 = and i8 %r75, 32
  %r77 = icmp ne i8 %r76, 0
  %r78 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r79 = icmp ne i32 %r78, 0
  %r80 = or i1 %r77, %r79
  br i1 %r80, label %class_field_set.barrier.11, label %class_field_set.gc_bookkeeping.done.8

class_field_set.barrier.11:                       ; preds = %class_field_set.layout_note.done.10
  %r194.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r194.rs4o = call i64 asm "", "=r,0"(i64 %r194.rs4i) #7
  %r194 = bitcast i64 %r194.rs4o to double
  %r195 = bitcast double %r194 to i64
  %r196.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r196.rs4o = call i64 asm "", "=r,0"(i64 %r196.rs4i) #7
  %r196 = bitcast i64 %r196.rs4o to double
  %r197 = bitcast double %r196 to i64
  call void @js_write_barrier_slot(i64 %r195, i64 %r56, i64 %r197) #7
  br label %class_field_set.gc_bookkeeping.done.8

class_field_set.fast.12:                          ; preds = %class_field_inline.guardcall.16, %class_field_inline.deref.15
  %r191.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r191.rs4o = call i64 asm "", "=r,0"(i64 %r191.rs4i) #7
  %r191 = bitcast i64 %r191.rs4o to double
  %r192 = bitcast double %r191 to i64
  %r193 = and i64 %r192, 281474976710655
  %r127 = inttoptr i64 %r193 to ptr
  %r187.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r187.rs4o = call i64 asm "", "=r,0"(i64 %r187.rs4i) #7
  %r187 = bitcast i64 %r187.rs4o to double
  %r188 = bitcast double %r187 to i64
  %r189 = and i64 %r188, 281474976710655
  %r190 = inttoptr i64 %r189 to ptr
  %r128 = getelementptr i8, ptr %r190, i64 16
  %r129 = getelementptr double, ptr %r128, i64 1
  %r130 = ptrtoint ptr %r129 to i64
  %r186.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r186.rs4o = call i64 asm "", "=r,0"(i64 %r186.rs4i) #7
  %r186 = bitcast i64 %r186.rs4o to double
  store double %r186, ptr %r129, align 8
  %r185.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r185.rs4o = call i64 asm "", "=r,0"(i64 %r185.rs4i) #7
  %r185 = bitcast i64 %r185.rs4o to double
  %r131 = bitcast double %r185 to i64
  %r183.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r183.rs4o = call i64 asm "", "=r,0"(i64 %r183.rs4i) #7
  %r183 = bitcast i64 %r183.rs4o to double
  %r184 = bitcast double %r183 to i64
  %r132 = lshr i64 %r184, 48
  %r133 = icmp eq i64 %r132, 0
  %r181.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r181.rs4o = call i64 asm "", "=r,0"(i64 %r181.rs4i) #7
  %r181 = bitcast i64 %r181.rs4o to double
  %r182 = bitcast double %r181 to i64
  %r134 = icmp uge i64 %r182, 4096
  %r135 = and i1 %r133, %r134
  %r136 = icmp eq i64 %r132, 32765
  %r137 = icmp eq i64 %r132, 32767
  %r138 = icmp eq i64 %r132, 32762
  %r139 = or i1 %r136, %r137
  %r140 = or i1 %r139, %r138
  %r141 = or i1 %r140, %r135
  br i1 %r141, label %class_field_set.gc_bookkeeping.17, label %class_field_set.gc_bookkeeping.done.18

class_field_set.fallback.13:                      ; preds = %class_field_inline.guardcall.16
  %r175.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r175.rs4o = call i64 asm "", "=r,0"(i64 %r175.rs4i) #7
  %r175 = bitcast i64 %r175.rs4o to double
  %r176 = bitcast double %r175 to i64
  %r177.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r177.rs4o = call i64 asm "", "=r,0"(i64 %r177.rs4i) #7
  %r177 = bitcast i64 %r177.rs4o to double
  %r178 = load double, ptr @test_json_template_capture_ts_.str.1.handle, align 8
  %r179 = bitcast double %r178 to i64
  %r180 = and i64 %r179, 281474976710655
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6060382687846203393, i64 %r176, i64 %r180, double %r177, i32 0, i32 0)
  br label %class_field_set.merge.14

class_field_set.merge.14:                         ; preds = %class_field_set.gc_bookkeeping.done.18, %class_field_set.fallback.13
  br label %standalone.ctor.return.after.1

class_field_inline.deref.15:                      ; preds = %class_field_set.merge.4
  %r97 = inttoptr i64 %r85 to ptr
  %r98 = getelementptr i8, ptr %r97, i64 -8
  %r99 = load i8, ptr %r98, align 1
  %r100 = icmp eq i8 %r99, 2
  %r101 = getelementptr i8, ptr %r97, i64 -7
  %r102 = load i8, ptr %r101, align 1
  %r103 = and i8 %r102, -128
  %r104 = icmp eq i8 %r103, 0
  %r105 = getelementptr i8, ptr %r97, i64 -6
  %r106 = load i16, ptr %r105, align 2
  %r107 = getelementptr i8, ptr %r97, i64 0
  %r108 = load i32, ptr %r107, align 4
  %r109 = icmp eq i32 %r108, 1
  %r110 = getelementptr i8, ptr %r97, i64 4
  %r111 = load i32, ptr %r110, align 4
  %r112 = icmp eq i32 %r111, %r8
  %r113 = and i1 %r100, %r104
  %r114 = and i1 %r113, %r109
  %r115 = and i1 %r114, %r112
  %r116 = and i16 %r106, 3072
  %r117 = icmp eq i16 %r116, 0
  %r118 = and i1 %r115, %r117
  %r119 = and i16 %r106, 1
  %r120 = icmp eq i16 %r119, 0
  %r121 = and i1 %r118, %r120
  %r122 = and i16 %r106, 128
  %r123 = icmp eq i16 %r122, 0
  %r124 = and i1 %r121, %r123
  br i1 %r124, label %class_field_set.fast.12, label %class_field_inline.guardcall.16

class_field_inline.guardcall.16:                  ; preds = %class_field_inline.deref.15, %class_field_set.merge.4
  %r125 = call i32 @js_typed_feedback_class_field_set_guard(i64 6060382687846203393, double %r81, i32 1, i32 %r8, i64 %r88, i32 1, double %r82, i32 0) #7
  %r126 = icmp ne i32 %r125, 0
  br i1 %r126, label %class_field_set.fast.12, label %class_field_set.fallback.13

class_field_set.gc_bookkeeping.17:                ; preds = %class_field_set.fast.12
  %r174.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r174.rs4o = call i64 asm "", "=r,0"(i64 %r174.rs4i) #7
  %r174 = bitcast i64 %r174.rs4o to double
  call void @js_string_addref_if_heap_string(double %r174) #7
  %r171.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r171.rs4o = call i64 asm "", "=r,0"(i64 %r171.rs4i) #7
  %r171 = bitcast i64 %r171.rs4o to double
  %r172 = bitcast double %r171 to i64
  %r173 = and i64 %r172, 281474976710655
  %r142 = inttoptr i64 %r173 to ptr
  %r167.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r167.rs4o = call i64 asm "", "=r,0"(i64 %r167.rs4i) #7
  %r167 = bitcast i64 %r167.rs4o to double
  %r168 = bitcast double %r167 to i64
  %r169 = and i64 %r168, 281474976710655
  %r170 = inttoptr i64 %r169 to ptr
  %r143 = getelementptr i8, ptr %r170, i64 -6
  %r144 = load i16, ptr %r143, align 2
  %r145 = and i16 %r144, -12288
  %r146 = icmp eq i16 %r145, -28672
  br i1 %r146, label %class_field_set.layout_note.done.20, label %class_field_set.layout_note.19

class_field_set.gc_bookkeeping.done.18:           ; preds = %class_field_set.barrier.21, %class_field_set.layout_note.done.20, %class_field_set.fast.12
  br label %class_field_set.merge.14

class_field_set.layout_note.19:                   ; preds = %class_field_set.gc_bookkeeping.17
  %r162.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r162.rs4o = call i64 asm "", "=r,0"(i64 %r162.rs4i) #7
  %r162 = bitcast i64 %r162.rs4o to double
  %r163 = bitcast double %r162 to i64
  %r164 = and i64 %r163, 281474976710655
  %r165.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r165.rs4o = call i64 asm "", "=r,0"(i64 %r165.rs4i) #7
  %r165 = bitcast i64 %r165.rs4o to double
  %r166 = bitcast double %r165 to i64
  call void @js_gc_note_slot_layout(i64 %r164, i32 1, i64 %r166) #7
  br label %class_field_set.layout_note.done.20

class_field_set.layout_note.done.20:              ; preds = %class_field_set.layout_note.19, %class_field_set.gc_bookkeeping.17
  %r159.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r159.rs4o = call i64 asm "", "=r,0"(i64 %r159.rs4i) #7
  %r159 = bitcast i64 %r159.rs4o to double
  %r160 = bitcast double %r159 to i64
  %r161 = and i64 %r160, 281474976710655
  %r147 = sub nsw i64 %r161, 7
  %r148 = inttoptr i64 %r147 to ptr
  %r149 = load i8, ptr %r148, align 1
  %r150 = and i8 %r149, 32
  %r151 = icmp ne i8 %r150, 0
  %r152 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r153 = icmp ne i32 %r152, 0
  %r154 = or i1 %r151, %r153
  br i1 %r154, label %class_field_set.barrier.21, label %class_field_set.gc_bookkeeping.done.18

class_field_set.barrier.21:                       ; preds = %class_field_set.layout_note.done.20
  %r155.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r155.rs4o = call i64 asm "", "=r,0"(i64 %r155.rs4i) #7
  %r155 = bitcast i64 %r155.rs4o to double
  %r156 = bitcast double %r155 to i64
  %r157.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r157.rs4o = call i64 asm "", "=r,0"(i64 %r157.rs4i) #7
  %r157 = bitcast i64 %r157.rs4o to double
  %r158 = bitcast double %r157 to i64
  call void @js_write_barrier_slot(i64 %r156, i64 %r130, i64 %r158) #7
  br label %class_field_set.gc_bookkeeping.done.18
}

; Function Attrs: optsize
define double @test_json_template_capture_ts____AnonShape_570a27fd5b93ea38_constructor(double %this_arg, double %arg14, double %arg15) #6 gc "statepoint-example" {
entry.0:
  %r8 = load i32, ptr @perry_class_shape_id_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg14 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg15 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #7
  %r5 = bitcast i64 %r5.rs4o to double
  %r6.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r6.rs4o = call i64 asm "", "=r,0"(i64 %r6.rs4i) #7
  %r6 = bitcast i64 %r6.rs4o to double
  %r10 = bitcast double %r5 to i64
  %r11 = and i64 %r10, 281474976710655
  %r12 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r13 = bitcast double %r12 to i64
  %r14 = and i64 %r13, 281474976710655
  %r15 = bitcast double %r6 to i64
  %r16 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r17 = icmp eq i8 %r16, 0
  %r18 = lshr i64 %r10, 48
  %r19 = icmp eq i64 %r18, 32765
  %r20 = icmp ugt i64 %r11, 1048575
  %r21 = and i1 %r19, %r20
  %r22 = and i1 %r21, %r17
  br i1 %r22, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.9
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r187.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r187.rs4o = call i64 asm "", "=r,0"(i64 %r187.rs4i) #7
  %r187 = bitcast i64 %r187.rs4o to double
  %r188 = bitcast double %r187 to i64
  %r189 = and i64 %r188, 281474976710655
  %r59 = inttoptr i64 %r189 to ptr
  %r183.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r183.rs4o = call i64 asm "", "=r,0"(i64 %r183.rs4i) #7
  %r183 = bitcast i64 %r183.rs4o to double
  %r184 = bitcast double %r183 to i64
  %r185 = and i64 %r184, 281474976710655
  %r186 = inttoptr i64 %r185 to ptr
  %r60 = getelementptr i8, ptr %r186, i64 16
  %r61 = getelementptr double, ptr %r60, i64 0
  %r182.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r182.rs4o = call i64 asm "", "=r,0"(i64 %r182.rs4i) #7
  %r182 = bitcast i64 %r182.rs4o to double
  %r62 = call double @js_array_numeric_value_to_raw_f64(double %r182) #7
  store double %r62, ptr %r61, align 8
  br label %class_field_set.merge.4

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r176.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r176.rs4o = call i64 asm "", "=r,0"(i64 %r176.rs4i) #7
  %r176 = bitcast i64 %r176.rs4o to double
  %r177 = bitcast double %r176 to i64
  %r178.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r178.rs4o = call i64 asm "", "=r,0"(i64 %r178.rs4i) #7
  %r178 = bitcast i64 %r178.rs4o to double
  %r179 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r180 = bitcast double %r179 to i64
  %r181 = and i64 %r180, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6060382687846203394, i64 %r177, i64 %r181, double %r178, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s1) ]
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s1, %rs4gc.s1)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.fallback.3, %class_field_set.fast.2
  %.02 = phi ptr addrspace(1) [ %rs4gc.s1, %class_field_set.fast.2 ], [ %rs4gc.s1.relocated, %class_field_set.fallback.3 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %class_field_set.fast.2 ], [ %rs4gc.s3.relocated, %class_field_set.fallback.3 ]
  %r63.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r63.rs4o = call i64 asm "", "=r,0"(i64 %r63.rs4i) #7
  %r63 = bitcast i64 %r63.rs4o to double
  %r64.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r64.rs4o = call i64 asm "", "=r,0"(i64 %r64.rs4i) #7
  %r64 = bitcast i64 %r64.rs4o to double
  %r66 = bitcast double %r63 to i64
  %r67 = and i64 %r66, 281474976710655
  %r68 = load double, ptr @test_json_template_capture_ts_.str.3.handle, align 8
  %r69 = bitcast double %r68 to i64
  %r70 = and i64 %r69, 281474976710655
  %r71 = bitcast double %r64 to i64
  %r72 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r73 = icmp eq i8 %r72, 0
  %r74 = lshr i64 %r66, 48
  %r75 = icmp eq i64 %r74, 32765
  %r76 = icmp ugt i64 %r67, 1048575
  %r77 = and i1 %r75, %r76
  %r78 = and i1 %r77, %r73
  br i1 %r78, label %class_field_inline.deref.10, label %class_field_inline.guardcall.11

class_field_inline.deref.5:                       ; preds = %entry.0
  %r23 = inttoptr i64 %r11 to ptr
  %r24 = getelementptr i8, ptr %r23, i64 -8
  %r25 = load i8, ptr %r24, align 1
  %r26 = icmp eq i8 %r25, 2
  %r27 = getelementptr i8, ptr %r23, i64 -7
  %r28 = load i8, ptr %r27, align 1
  %r29 = and i8 %r28, -128
  %r30 = icmp eq i8 %r29, 0
  %r31 = getelementptr i8, ptr %r23, i64 -6
  %r32 = load i16, ptr %r31, align 2
  %r33 = getelementptr i8, ptr %r23, i64 0
  %r34 = load i32, ptr %r33, align 4
  %r35 = icmp eq i32 %r34, 2
  %r36 = getelementptr i8, ptr %r23, i64 4
  %r37 = load i32, ptr %r36, align 4
  %r38 = icmp eq i32 %r37, %r8
  %r39 = and i1 %r26, %r30
  %r40 = and i1 %r39, %r35
  %r41 = and i1 %r40, %r38
  %r42 = and i16 %r32, 3072
  %r43 = icmp eq i16 %r42, 0
  %r44 = and i1 %r41, %r43
  %r45 = and i16 %r32, 4096
  %r46 = icmp ne i16 %r45, 0
  %r47 = and i1 %r44, %r46
  %r48 = and i16 %r32, 1
  %r49 = icmp eq i16 %r48, 0
  %r50 = and i1 %r47, %r49
  %r51 = and i16 %r32, 128
  %r52 = icmp eq i16 %r51, 0
  %r53 = and i1 %r50, %r52
  %r54 = and i64 %r15, 9218868437227405312
  %r55 = icmp ne i64 %r54, 9218868437227405312
  %r56 = and i1 %r53, %r55
  br i1 %r56, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r57 = call i32 @js_typed_feedback_class_field_set_guard(i64 6060382687846203394, double %r5, i32 2, i32 %r8, i64 %r14, i32 0, double %r6, i32 1) #7
  %r58 = icmp ne i32 %r57, 0
  br i1 %r58, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.fast.7:                           ; preds = %class_field_inline.guardcall.11, %class_field_inline.deref.10
  %r173.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r173.rs4o = call i64 asm "", "=r,0"(i64 %r173.rs4i) #7
  %r173 = bitcast i64 %r173.rs4o to double
  %r174 = bitcast double %r173 to i64
  %r175 = and i64 %r174, 281474976710655
  %r109 = inttoptr i64 %r175 to ptr
  %r169.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r169.rs4o = call i64 asm "", "=r,0"(i64 %r169.rs4i) #7
  %r169 = bitcast i64 %r169.rs4o to double
  %r170 = bitcast double %r169 to i64
  %r171 = and i64 %r170, 281474976710655
  %r172 = inttoptr i64 %r171 to ptr
  %r110 = getelementptr i8, ptr %r172, i64 16
  %r111 = getelementptr double, ptr %r110, i64 1
  %r112 = ptrtoint ptr %r111 to i64
  %r168.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r168.rs4o = call i64 asm "", "=r,0"(i64 %r168.rs4i) #7
  %r168 = bitcast i64 %r168.rs4o to double
  store double %r168, ptr %r111, align 8
  %r167.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r167.rs4o = call i64 asm "", "=r,0"(i64 %r167.rs4i) #7
  %r167 = bitcast i64 %r167.rs4o to double
  %r113 = bitcast double %r167 to i64
  %r165.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r165.rs4o = call i64 asm "", "=r,0"(i64 %r165.rs4i) #7
  %r165 = bitcast i64 %r165.rs4o to double
  %r166 = bitcast double %r165 to i64
  %r114 = lshr i64 %r166, 48
  %r115 = icmp eq i64 %r114, 0
  %r163.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r163.rs4o = call i64 asm "", "=r,0"(i64 %r163.rs4i) #7
  %r163 = bitcast i64 %r163.rs4o to double
  %r164 = bitcast double %r163 to i64
  %r116 = icmp uge i64 %r164, 4096
  %r117 = and i1 %r115, %r116
  %r118 = icmp eq i64 %r114, 32765
  %r119 = icmp eq i64 %r114, 32767
  %r120 = icmp eq i64 %r114, 32762
  %r121 = or i1 %r118, %r119
  %r122 = or i1 %r121, %r120
  %r123 = or i1 %r122, %r117
  br i1 %r123, label %class_field_set.gc_bookkeeping.12, label %class_field_set.gc_bookkeeping.done.13

class_field_set.fallback.8:                       ; preds = %class_field_inline.guardcall.11
  %r157.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r157.rs4o = call i64 asm "", "=r,0"(i64 %r157.rs4i) #7
  %r157 = bitcast i64 %r157.rs4o to double
  %r158 = bitcast double %r157 to i64
  %r159.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r159.rs4o = call i64 asm "", "=r,0"(i64 %r159.rs4i) #7
  %r159 = bitcast i64 %r159.rs4o to double
  %r160 = load double, ptr @test_json_template_capture_ts_.str.3.handle, align 8
  %r161 = bitcast double %r160 to i64
  %r162 = and i64 %r161, 281474976710655
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6060382687846203395, i64 %r158, i64 %r162, double %r159, i32 0, i32 0)
  br label %class_field_set.merge.9

class_field_set.merge.9:                          ; preds = %class_field_set.gc_bookkeeping.done.13, %class_field_set.fallback.8
  br label %standalone.ctor.return.after.1

class_field_inline.deref.10:                      ; preds = %class_field_set.merge.4
  %r79 = inttoptr i64 %r67 to ptr
  %r80 = getelementptr i8, ptr %r79, i64 -8
  %r81 = load i8, ptr %r80, align 1
  %r82 = icmp eq i8 %r81, 2
  %r83 = getelementptr i8, ptr %r79, i64 -7
  %r84 = load i8, ptr %r83, align 1
  %r85 = and i8 %r84, -128
  %r86 = icmp eq i8 %r85, 0
  %r87 = getelementptr i8, ptr %r79, i64 -6
  %r88 = load i16, ptr %r87, align 2
  %r89 = getelementptr i8, ptr %r79, i64 0
  %r90 = load i32, ptr %r89, align 4
  %r91 = icmp eq i32 %r90, 2
  %r92 = getelementptr i8, ptr %r79, i64 4
  %r93 = load i32, ptr %r92, align 4
  %r94 = icmp eq i32 %r93, %r8
  %r95 = and i1 %r82, %r86
  %r96 = and i1 %r95, %r91
  %r97 = and i1 %r96, %r94
  %r98 = and i16 %r88, 3072
  %r99 = icmp eq i16 %r98, 0
  %r100 = and i1 %r97, %r99
  %r101 = and i16 %r88, 1
  %r102 = icmp eq i16 %r101, 0
  %r103 = and i1 %r100, %r102
  %r104 = and i16 %r88, 128
  %r105 = icmp eq i16 %r104, 0
  %r106 = and i1 %r103, %r105
  br i1 %r106, label %class_field_set.fast.7, label %class_field_inline.guardcall.11

class_field_inline.guardcall.11:                  ; preds = %class_field_inline.deref.10, %class_field_set.merge.4
  %r107 = call i32 @js_typed_feedback_class_field_set_guard(i64 6060382687846203395, double %r63, i32 2, i32 %r8, i64 %r70, i32 1, double %r64, i32 0) #7
  %r108 = icmp ne i32 %r107, 0
  br i1 %r108, label %class_field_set.fast.7, label %class_field_set.fallback.8

class_field_set.gc_bookkeeping.12:                ; preds = %class_field_set.fast.7
  %r156.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r156.rs4o = call i64 asm "", "=r,0"(i64 %r156.rs4i) #7
  %r156 = bitcast i64 %r156.rs4o to double
  call void @js_string_addref_if_heap_string(double %r156) #7
  %r153.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r153.rs4o = call i64 asm "", "=r,0"(i64 %r153.rs4i) #7
  %r153 = bitcast i64 %r153.rs4o to double
  %r154 = bitcast double %r153 to i64
  %r155 = and i64 %r154, 281474976710655
  %r124 = inttoptr i64 %r155 to ptr
  %r149.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r149.rs4o = call i64 asm "", "=r,0"(i64 %r149.rs4i) #7
  %r149 = bitcast i64 %r149.rs4o to double
  %r150 = bitcast double %r149 to i64
  %r151 = and i64 %r150, 281474976710655
  %r152 = inttoptr i64 %r151 to ptr
  %r125 = getelementptr i8, ptr %r152, i64 -6
  %r126 = load i16, ptr %r125, align 2
  %r127 = and i16 %r126, -12288
  %r128 = icmp eq i16 %r127, -28672
  br i1 %r128, label %class_field_set.layout_note.done.15, label %class_field_set.layout_note.14

class_field_set.gc_bookkeeping.done.13:           ; preds = %class_field_set.barrier.16, %class_field_set.layout_note.done.15, %class_field_set.fast.7
  br label %class_field_set.merge.9

class_field_set.layout_note.14:                   ; preds = %class_field_set.gc_bookkeeping.12
  %r144.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r144.rs4o = call i64 asm "", "=r,0"(i64 %r144.rs4i) #7
  %r144 = bitcast i64 %r144.rs4o to double
  %r145 = bitcast double %r144 to i64
  %r146 = and i64 %r145, 281474976710655
  %r147.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r147.rs4o = call i64 asm "", "=r,0"(i64 %r147.rs4i) #7
  %r147 = bitcast i64 %r147.rs4o to double
  %r148 = bitcast double %r147 to i64
  call void @js_gc_note_slot_layout(i64 %r146, i32 1, i64 %r148) #7
  br label %class_field_set.layout_note.done.15

class_field_set.layout_note.done.15:              ; preds = %class_field_set.layout_note.14, %class_field_set.gc_bookkeeping.12
  %r141.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r141.rs4o = call i64 asm "", "=r,0"(i64 %r141.rs4i) #7
  %r141 = bitcast i64 %r141.rs4o to double
  %r142 = bitcast double %r141 to i64
  %r143 = and i64 %r142, 281474976710655
  %r129 = sub nsw i64 %r143, 7
  %r130 = inttoptr i64 %r129 to ptr
  %r131 = load i8, ptr %r130, align 1
  %r132 = and i8 %r131, 32
  %r133 = icmp ne i8 %r132, 0
  %r134 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r135 = icmp ne i32 %r134, 0
  %r136 = or i1 %r133, %r135
  br i1 %r136, label %class_field_set.barrier.16, label %class_field_set.gc_bookkeeping.done.13

class_field_set.barrier.16:                       ; preds = %class_field_set.layout_note.done.15
  %r137.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r137.rs4o = call i64 asm "", "=r,0"(i64 %r137.rs4i) #7
  %r137 = bitcast i64 %r137.rs4o to double
  %r138 = bitcast double %r137 to i64
  %r139.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r139.rs4o = call i64 asm "", "=r,0"(i64 %r139.rs4i) #7
  %r139 = bitcast i64 %r139.rs4o to double
  %r140 = bitcast double %r139 to i64
  call void @js_write_barrier_slot(i64 %r138, i64 %r112, i64 %r140) #7
  br label %class_field_set.gc_bookkeeping.done.13
}

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_test_json_template_capture_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @test_json_template_capture_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" {
entry.0:
  %r644 = alloca [1 x double], align 8
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @test_json_template_capture_ts_.str.0, i32 133, i32 0, i32 0)
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token3 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token4 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_test_json_template_capture_ts, i32 0, i32 0, i32 0, i32 0)
  %r1532 = load <2 x i64>, ptr @perry_class_header_image_test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18, align 16
  %r1773 = load <2 x i64>, ptr @perry_class_header_image_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38, align 16
  %r2536 = load i32, ptr @perry_class_shape_id_test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18, align 4
  %r2 = load double, ptr @test_json_template_capture_ts_.str.4.handle, align 8
  %r3 = load double, ptr @test_json_template_capture_ts_.str.5.handle, align 8
  %r4 = load double, ptr @test_json_template_capture_ts_.str.6.handle, align 8
  br label %arena_state.init.1

arena_state.init.1:                               ; preds = %entry.0
  %r8 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r9 = icmp ne i64 %r8, -1
  br i1 %r9, label %arena_state.hot_tls.tsd.3, label %arena_state.hot_tls.slow.5

arena_state.ready.2:                              ; preds = %arena_state.hot_tls.resolved.7
  %r24 = getelementptr i8, ptr %r22, i64 8
  %r25 = load i64, ptr %r24, align 8
  %r26 = add i64 %r25, 40
  %r27 = getelementptr i8, ptr %r22, i64 16
  %r28 = load i64, ptr %r27, align 8
  %r29 = icmp ule i64 %r26, %r28
  br i1 %r29, label %arrlit.fast.8, label %arrlit.slow.9

arena_state.hot_tls.tsd.3:                        ; preds = %arena_state.init.1
  %r10 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #7
  %r11 = and i64 %r10, -8
  %r12 = shl i64 %r8, 3
  %r13 = add i64 %r11, %r12
  %r14 = inttoptr i64 %r13 to ptr
  %r15 = load ptr, ptr %r14, align 8
  %r16 = icmp ne ptr %r15, null
  br i1 %r16, label %arena_state.hot_tls.fast.4, label %arena_state.hot_tls.slow.5

arena_state.hot_tls.fast.4:                       ; preds = %arena_state.hot_tls.tsd.3
  %r17 = getelementptr i8, ptr %r15, i64 8
  %r18 = load ptr, ptr %r17, align 8
  %r19 = load ptr, ptr %r18, align 8
  %r20 = icmp ne ptr %r19, null
  br i1 %r20, label %arena_state.hot_tls.ready.6, label %arena_state.hot_tls.slow.5

arena_state.hot_tls.slow.5:                       ; preds = %arena_state.hot_tls.fast.4, %arena_state.hot_tls.tsd.3, %arena_state.init.1
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0)
  %r2133 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token5)
  br label %arena_state.hot_tls.resolved.7

arena_state.hot_tls.ready.6:                      ; preds = %arena_state.hot_tls.fast.4
  br label %arena_state.hot_tls.resolved.7

arena_state.hot_tls.resolved.7:                   ; preds = %arena_state.hot_tls.ready.6, %arena_state.hot_tls.slow.5
  %r5.1 = phi ptr [ %r18, %arena_state.hot_tls.ready.6 ], [ %r2133, %arena_state.hot_tls.slow.5 ]
  %r22 = phi ptr [ %r18, %arena_state.hot_tls.ready.6 ], [ %r2133, %arena_state.hot_tls.slow.5 ]
  br label %arena_state.ready.2

arrlit.fast.8:                                    ; preds = %arena_state.ready.2
  store i64 %r26, ptr %r24, align 8
  %r30 = load ptr, ptr %r22, align 8
  %r31 = getelementptr i8, ptr %r30, i64 %r25
  br label %arrlit.merge.10

arrlit.slow.9:                                    ; preds = %arena_state.ready.2
  %statepoint_token34 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r22, i64 40, i64 8, i32 0, i32 0)
  %r3241 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token34)
  br label %arrlit.merge.10

arrlit.merge.10:                                  ; preds = %arrlit.slow.9, %arrlit.fast.8
  %r33 = phi ptr [ %r31, %arrlit.fast.8 ], [ %r3241, %arrlit.slow.9 ]
  store i64 172872434177, ptr %r33, align 8
  %r34 = getelementptr i8, ptr %r33, i64 8
  store i64 12884901891, ptr %r34, align 8
  %r35 = getelementptr i8, ptr %r33, i64 8
  %r36 = ptrtoint ptr %r35 to i64
  %r37 = getelementptr inbounds nuw i8, ptr %r33, i64 16
  %r3597 = load double, ptr @test_json_template_capture_ts_.str.4.handle, align 8
  store double %r3597, ptr %r37, align 8
  %r3596 = load double, ptr @test_json_template_capture_ts_.str.4.handle, align 8
  call void @js_string_addref_if_heap_string(double %r3596) #7
  %r3595 = load double, ptr @test_json_template_capture_ts_.str.4.handle, align 8
  %r38 = bitcast double %r3595 to i64
  %r3593 = load double, ptr @test_json_template_capture_ts_.str.4.handle, align 8
  %r3594 = bitcast double %r3593 to i64
  call void @js_gc_note_slot_layout(i64 %r36, i32 0, i64 %r3594) #7
  %r39 = getelementptr inbounds nuw i8, ptr %r33, i64 24
  %r3592 = load double, ptr @test_json_template_capture_ts_.str.5.handle, align 8
  store double %r3592, ptr %r39, align 8
  %r3591 = load double, ptr @test_json_template_capture_ts_.str.5.handle, align 8
  call void @js_string_addref_if_heap_string(double %r3591) #7
  %r3590 = load double, ptr @test_json_template_capture_ts_.str.5.handle, align 8
  %r40 = bitcast double %r3590 to i64
  %r3588 = load double, ptr @test_json_template_capture_ts_.str.5.handle, align 8
  %r3589 = bitcast double %r3588 to i64
  call void @js_gc_note_slot_layout(i64 %r36, i32 1, i64 %r3589) #7
  %r41 = getelementptr inbounds nuw i8, ptr %r33, i64 32
  %r3587 = load double, ptr @test_json_template_capture_ts_.str.6.handle, align 8
  store double %r3587, ptr %r41, align 8
  %r3586 = load double, ptr @test_json_template_capture_ts_.str.6.handle, align 8
  call void @js_string_addref_if_heap_string(double %r3586) #7
  %r3585 = load double, ptr @test_json_template_capture_ts_.str.6.handle, align 8
  %r42 = bitcast double %r3585 to i64
  %r3583 = load double, ptr @test_json_template_capture_ts_.str.6.handle, align 8
  %r3584 = bitcast double %r3583 to i64
  call void @js_gc_note_slot_layout(i64 %r36, i32 2, i64 %r3584) #7
  %r43 = or i64 %r36, 9222527611924643840
  %r44 = bitcast i64 %r43 to double
  %rs4gc.b12 = bitcast double %r44 to i64
  %rs4gc.s12 = inttoptr i64 %rs4gc.b12 to ptr addrspace(1)
  %r45.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r45 = call i64 asm "", "=r,0"(i64 %r45.rs4i) #7
  %r46 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r47 = icmp ne i32 %r46, 0
  br i1 %r47, label %shadow.root.barrier.11, label %shadow.root.barrier.done.12

shadow.root.barrier.11:                           ; preds = %arrlit.merge.10
  call void @js_write_barrier_root_nanbox(i64 %r45) #7
  br label %shadow.root.barrier.done.12

shadow.root.barrier.done.12:                      ; preds = %shadow.root.barrier.11, %arrlit.merge.10
  %statepoint_token42 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s12) ]
  %r4943 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token42)
  %rs4gc.s12.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token42, i32 0, i32 0) ; (%rs4gc.s12, %rs4gc.s12)
  %r50 = or i64 %r4943, 9222527611924643840
  %r51 = bitcast i64 %r50 to double
  %rs4gc.b13 = bitcast double %r51 to i64
  %rs4gc.s13 = inttoptr i64 %rs4gc.b13 to ptr addrspace(1)
  %r52.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r52 = call i64 asm "", "=r,0"(i64 %r52.rs4i) #7
  %r53 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r54 = icmp ne i32 %r53, 0
  br i1 %r54, label %shadow.root.barrier.13, label %shadow.root.barrier.done.14

shadow.root.barrier.13:                           ; preds = %shadow.root.barrier.done.12
  call void @js_write_barrier_root_nanbox(i64 %r52) #7
  br label %shadow.root.barrier.done.14

shadow.root.barrier.done.14:                      ; preds = %shadow.root.barrier.13, %shadow.root.barrier.done.12
  %r55 = bitcast double %r51 to i64
  %r56 = and i64 %r55, 281474976710655
  call void @js_array_declare_all_pointer_elements(i64 %r56) #7
  br label %for.cond.15

for.cond.15:                                      ; preds = %for.update.17, %shadow.root.barrier.done.14
  %.0 = phi ptr addrspace(1) [ %rs4gc.s12.relocated, %shadow.root.barrier.done.14 ], [ %.43, %for.update.17 ]
  %r58.0 = phi i32 [ 0, %shadow.root.barrier.done.14 ], [ %r2337, %for.update.17 ]
  %r57.0 = phi ptr addrspace(1) [ null, %shadow.root.barrier.done.14 ], [ %.01180, %for.update.17 ]
  %r48.0.base = phi ptr addrspace(1) [ %rs4gc.s13, %shadow.root.barrier.done.14 ], [ %.151128, %for.update.17 ], !is_base_value !0
  %r48.0 = phi ptr addrspace(1) [ %rs4gc.s13, %shadow.root.barrier.done.14 ], [ %.151144, %for.update.17 ]
  %r5.2 = phi ptr [ %r5.1, %shadow.root.barrier.done.14 ], [ %r5.6, %for.update.17 ]
  %r60 = sitofp i32 %r58.0 to double
  %r61 = fcmp olt double %r60, 2.400000e+02
  %r62 = select i1 %r61, i64 9222246136947933188, i64 9222246136947933187
  %r63 = bitcast i64 %r62 to double
  %r64 = icmp eq i64 %r62, 9222246136947933188
  br i1 %r64, label %for.body.16, label %for.exit.18

for.body.16:                                      ; preds = %for.cond.15
  %r66.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r66.rs4o = call i64 asm "", "=r,0"(i64 %r66.rs4i) #7
  %r66 = bitcast i64 %r66.rs4o to double
  %r68 = sitofp i32 %r58.0 to double
  %r69 = fptosi double %r68 to i64
  %r71 = srem i64 %r69, 3
  %r72 = sitofp i64 %r71 to double
  %r73 = icmp eq i64 %r71, 0
  %r74 = fcmp olt double %r68, 0.000000e+00
  %r75 = and i1 %r73, %r74
  %r76 = fneg double %r72
  %r77 = select i1 %r75, double %r76, double %r72
  %r78 = fcmp oge double %r77, 0.000000e+00
  %r79 = fcmp ole double %r77, 0x41DFFFFFFFC00000
  %r80 = and i1 %r78, %r79
  %r81 = select i1 %r80, double %r77, double 0.000000e+00
  %r82 = fptosi double %r81 to i32
  %r83 = sitofp i32 %r82 to double
  %r84 = fcmp oeq double %r83, %r77
  %r85 = and i1 %r80, %r84
  %r86 = bitcast double %r77 to i64
  %r87 = lshr i64 %r86, 48
  %r88 = icmp eq i64 %r87, 32766
  %r89 = trunc i64 %r86 to i32
  %r90 = icmp sge i32 %r89, 0
  %r91 = and i1 %r88, %r90
  %r92 = or i1 %r85, %r91
  %r93 = select i1 %r88, i32 %r89, i32 %r82
  br i1 %r92, label %aidx.canonical.19, label %aidx.runtime_key.20

for.update.17:                                    ; preds = %gcpoll.done.484
  %r2337 = add i32 %r58.0, 1
  %r2338 = sitofp i32 %r58.0 to double
  %r2339 = sitofp i32 %r2337 to double
  br label %for.cond.15

for.exit.18:                                      ; preds = %for.cond.15
  br label %for.cond.485

aidx.canonical.19:                                ; preds = %for.body.16
  %r94 = bitcast double %r66 to i64
  %r95 = and i64 %r94, 281474976710655
  %r96 = lshr i64 %r94, 48
  %r97 = icmp eq i64 %r96, 32765
  %r98 = icmp ugt i64 %r95, 1048575
  %r99 = and i1 %r97, %r98
  br i1 %r99, label %aidx.dynamic.guard.deref.26, label %aidx.dynamic.fallback.23

aidx.runtime_key.20:                              ; preds = %for.body.16
  %r166 = bitcast double %r66 to i64
  %r167 = and i64 %r166, 281474976710655
  %statepoint_token44 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_array_get_index_or_string, i32 2, i32 0, i64 %r167, double %r77, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0, ptr addrspace(1) %r48.0.base, ptr addrspace(1) %.0, ptr addrspace(1) %r48.0) ]
  %r16845 = call double @llvm.experimental.gc.result.f64(token %statepoint_token44)
  %r57.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token44, i32 0, i32 0) ; (%r57.0, %r57.0)
  %r48.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token44, i32 1, i32 1) ; (%r48.0.base, %r48.0.base)
  %rs4gc.s12.relocated46 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token44, i32 2, i32 2) ; (%.0, %.0)
  %r48.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token44, i32 1, i32 3) ; (%r48.0.base, %r48.0)
  br label %aidx.dynamic_merge.21

aidx.dynamic_merge.21:                            ; preds = %aidx.dynamic.merge.25, %aidx.runtime_key.20
  %.11015 = phi ptr addrspace(1) [ %.21016, %aidx.dynamic.merge.25 ], [ %r48.0.relocated, %aidx.runtime_key.20 ]
  %.1974 = phi ptr addrspace(1) [ %.2975, %aidx.dynamic.merge.25 ], [ %r48.0.base.relocated, %aidx.runtime_key.20 ]
  %.1930 = phi ptr addrspace(1) [ %.2931, %aidx.dynamic.merge.25 ], [ %r57.0.relocated, %aidx.runtime_key.20 ]
  %.1 = phi ptr addrspace(1) [ %.2, %aidx.dynamic.merge.25 ], [ %rs4gc.s12.relocated46, %aidx.runtime_key.20 ]
  %r169 = phi double [ %r165, %aidx.dynamic.merge.25 ], [ %r16845, %aidx.runtime_key.20 ]
  %rs4gc.b15 = bitcast double %r169 to i64
  %rs4gc.s15 = inttoptr i64 %rs4gc.b15 to ptr addrspace(1)
  %r170 = bitcast double %r169 to i64
  %r171 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r172 = icmp ne i32 %r171, 0
  br i1 %r172, label %shadow.root.barrier.29, label %shadow.root.barrier.done.30

aidx.dynamic.fast.22:                             ; preds = %aidx.dynamic.guard.range.28
  %r155 = zext i32 %r93 to i64
  %r156 = shl nuw nsw i64 %r155, 3
  %r157 = add nuw nsw i64 %r156, 8
  %r158 = add i64 %r114, %r157
  %r159 = inttoptr i64 %r158 to ptr
  %r160 = load double, ptr %r159, align 8
  %r161 = bitcast double %r160 to i64
  %r162 = icmp eq i64 %r161, 9222246136947933200
  %r164 = select i1 %r162, double 0x7FFC000000000001, double %r160
  br label %aidx.dynamic.merge.25

aidx.dynamic.fallback.23:                         ; preds = %aidx.dynamic.guard.live.27, %aidx.dynamic.guard.deref.26, %aidx.canonical.19
  %r153 = sitofp i32 %r93 to double
  %statepoint_token47 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 6060382687846203396, double %r66, double %r153, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0, ptr addrspace(1) %r48.0.base, ptr addrspace(1) %.0, ptr addrspace(1) %r48.0) ]
  %r15448 = call double @llvm.experimental.gc.result.f64(token %statepoint_token47)
  %r57.0.relocated49 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token47, i32 0, i32 0) ; (%r57.0, %r57.0)
  %r48.0.base.relocated50 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token47, i32 1, i32 1) ; (%r48.0.base, %r48.0.base)
  %rs4gc.s12.relocated51 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token47, i32 2, i32 2) ; (%.0, %.0)
  %r48.0.relocated52 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token47, i32 1, i32 3) ; (%r48.0.base, %r48.0)
  br label %aidx.dynamic.merge.25

aidx.dynamic.guard.oob.24:                        ; preds = %aidx.dynamic.guard.range.28
  br label %aidx.dynamic.merge.25

aidx.dynamic.merge.25:                            ; preds = %aidx.dynamic.guard.oob.24, %aidx.dynamic.fallback.23, %aidx.dynamic.fast.22
  %.21016 = phi ptr addrspace(1) [ %r48.0, %aidx.dynamic.fast.22 ], [ %r48.0, %aidx.dynamic.guard.oob.24 ], [ %r48.0.relocated52, %aidx.dynamic.fallback.23 ]
  %.2975 = phi ptr addrspace(1) [ %r48.0.base, %aidx.dynamic.fast.22 ], [ %r48.0.base, %aidx.dynamic.guard.oob.24 ], [ %r48.0.base.relocated50, %aidx.dynamic.fallback.23 ]
  %.2931 = phi ptr addrspace(1) [ %r57.0, %aidx.dynamic.fast.22 ], [ %r57.0, %aidx.dynamic.guard.oob.24 ], [ %r57.0.relocated49, %aidx.dynamic.fallback.23 ]
  %.2 = phi ptr addrspace(1) [ %.0, %aidx.dynamic.fast.22 ], [ %.0, %aidx.dynamic.guard.oob.24 ], [ %rs4gc.s12.relocated51, %aidx.dynamic.fallback.23 ]
  %r165 = phi double [ %r164, %aidx.dynamic.fast.22 ], [ %r15448, %aidx.dynamic.fallback.23 ], [ 0x7FFC000000000001, %aidx.dynamic.guard.oob.24 ]
  br label %aidx.dynamic_merge.21

aidx.dynamic.guard.deref.26:                      ; preds = %aidx.canonical.19
  %r100 = bitcast double %r66 to i64
  %r101 = and i64 %r100, 281474976710655
  %r102 = sub nsw i64 %r101, 8
  %r103 = inttoptr i64 %r102 to ptr
  %r104 = load i8, ptr %r103, align 1
  %r105 = icmp eq i8 %r104, 1
  %r106 = sub nsw i64 %r101, 7
  %r107 = inttoptr i64 %r106 to ptr
  %r108 = load i8, ptr %r107, align 1
  %r109 = and i8 %r108, -128
  %r110 = icmp ne i8 %r109, 0
  %r111 = inttoptr i64 %r101 to ptr
  %r112 = load i64, ptr %r111, align 8
  %r113 = and i1 %r105, %r110
  %r114 = select i1 %r113, i64 %r112, i64 %r101
  %r115 = lshr i64 %r114, 48
  %r116 = icmp eq i64 %r115, 0
  %r117 = icmp ugt i64 %r114, 1048575
  %r118 = and i1 %r116, %r117
  br i1 %r118, label %aidx.dynamic.guard.live.27, label %aidx.dynamic.fallback.23

aidx.dynamic.guard.live.27:                       ; preds = %aidx.dynamic.guard.deref.26
  %r119 = sub nuw i64 %r114, 8
  %r120 = inttoptr i64 %r119 to ptr
  %r121 = load i8, ptr %r120, align 1
  %r122 = icmp eq i8 %r121, 1
  %r123 = sub nuw i64 %r114, 7
  %r124 = inttoptr i64 %r123 to ptr
  %r125 = load i8, ptr %r124, align 1
  %r126 = and i8 %r125, -128
  %r127 = icmp eq i8 %r126, 0
  %r128 = sub nuw i64 %r114, 6
  %r129 = inttoptr i64 %r128 to ptr
  %r130 = load i16, ptr %r129, align 2
  %r131 = and i16 %r130, 1024
  %r132 = icmp eq i16 %r131, 0
  %r133 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r134 = icmp eq i8 %r133, 0
  %r135 = inttoptr i64 %r114 to ptr
  %r136 = load i32, ptr %r135, align 4
  %r137 = getelementptr i8, ptr %r135, i64 4
  %r138 = load i32, ptr %r137, align 4
  %r139 = icmp slt i32 %r93, 0
  %r140 = icmp eq i1 %r139, false
  %r142 = icmp ule i32 %r136, 16000000
  %r143 = icmp ule i32 %r138, 16000000
  %r144 = icmp ule i32 %r136, %r138
  %r145 = and i1 %r122, %r127
  %r146 = and i1 %r145, %r132
  %r147 = and i1 %r146, %r134
  %r148 = and i1 %r147, %r140
  %r149 = and i1 %r148, %r142
  %r150 = and i1 %r149, %r143
  %r151 = and i1 %r150, %r144
  br i1 %r151, label %aidx.dynamic.guard.range.28, label %aidx.dynamic.fallback.23

aidx.dynamic.guard.range.28:                      ; preds = %aidx.dynamic.guard.live.27
  %r141 = icmp ult i32 %r93, %r136
  br i1 %r141, label %aidx.dynamic.fast.22, label %aidx.dynamic.guard.oob.24

shadow.root.barrier.29:                           ; preds = %aidx.dynamic_merge.21
  call void @js_write_barrier_root_nanbox(i64 %r170) #7
  br label %shadow.root.barrier.done.30

shadow.root.barrier.done.30:                      ; preds = %shadow.root.barrier.29, %aidx.dynamic_merge.21
  %r174.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r174.rs4o = call i64 asm "", "=r,0"(i64 %r174.rs4i) #7
  %r174 = bitcast i64 %r174.rs4o to double
  %statepoint_token53 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r174, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1930, ptr addrspace(1) %.1974, ptr addrspace(1) %rs4gc.s15, ptr addrspace(1) %.1, ptr addrspace(1) %.11015) ]
  %r17554 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token53)
  %r57.0.relocated55 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token53, i32 0, i32 0) ; (%.1930, %.1930)
  %r48.0.base.relocated56 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token53, i32 1, i32 1) ; (%.1974, %.1974)
  %rs4gc.s15.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token53, i32 2, i32 2) ; (%rs4gc.s15, %rs4gc.s15)
  %rs4gc.s12.relocated57 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token53, i32 3, i32 3) ; (%.1, %.1)
  %r48.0.relocated58 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token53, i32 1, i32 4) ; (%.1974, %.11015)
  %statepoint_token59 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r17554, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated55, ptr addrspace(1) %r48.0.base.relocated56, ptr addrspace(1) %rs4gc.s15.relocated, ptr addrspace(1) %rs4gc.s12.relocated57, ptr addrspace(1) %r48.0.relocated58) ]
  %r17660 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token59)
  %r57.0.relocated61 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 0, i32 0) ; (%r57.0.relocated55, %r57.0.relocated55)
  %r48.0.base.relocated62 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 1, i32 1) ; (%r48.0.base.relocated56, %r48.0.base.relocated56)
  %rs4gc.s15.relocated63 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 2, i32 2) ; (%rs4gc.s15.relocated, %rs4gc.s15.relocated)
  %rs4gc.s12.relocated64 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 3, i32 3) ; (%rs4gc.s12.relocated57, %rs4gc.s12.relocated57)
  %r48.0.relocated65 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 1, i32 4) ; (%r48.0.base.relocated56, %r48.0.relocated58)
  %r177 = bitcast i64 %r17660 to double
  %rs4gc.b16 = bitcast double %r177 to i64
  %rs4gc.s16 = inttoptr i64 %rs4gc.b16 to ptr addrspace(1)
  %r178.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r178 = call i64 asm "", "=r,0"(i64 %r178.rs4i) #7
  %r179 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r180 = icmp ne i32 %r179, 0
  br i1 %r180, label %shadow.root.barrier.31, label %shadow.root.barrier.done.32

shadow.root.barrier.31:                           ; preds = %shadow.root.barrier.done.30
  call void @js_write_barrier_root_nanbox(i64 %r178) #7
  br label %shadow.root.barrier.done.32

shadow.root.barrier.done.32:                      ; preds = %shadow.root.barrier.31, %shadow.root.barrier.done.30
  %r182 = load double, ptr @test_json_template_capture_ts_.str.7.handle, align 8
  %rs4gc.b17 = bitcast double %r182 to i64
  %rs4gc.s17 = inttoptr i64 %rs4gc.b17 to ptr addrspace(1)
  %r183.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r183 = call i64 asm "", "=r,0"(i64 %r183.rs4i) #7
  %r184 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r185 = icmp ne i32 %r184, 0
  br i1 %r185, label %shadow.root.barrier.33, label %shadow.root.barrier.done.34

shadow.root.barrier.33:                           ; preds = %shadow.root.barrier.done.32
  call void @js_write_barrier_root_nanbox(i64 %r183) #7
  br label %shadow.root.barrier.done.34

shadow.root.barrier.done.34:                      ; preds = %shadow.root.barrier.33, %shadow.root.barrier.done.32
  %r187.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r187.rs4o = call i64 asm "", "=r,0"(i64 %r187.rs4i) #7
  %r187 = bitcast i64 %r187.rs4o to double
  %statepoint_token66 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r187, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated61, ptr addrspace(1) %r48.0.base.relocated62, ptr addrspace(1) %rs4gc.s15.relocated63, ptr addrspace(1) %rs4gc.s12.relocated64, ptr addrspace(1) %r48.0.relocated65, ptr addrspace(1) %rs4gc.s16, ptr addrspace(1) %rs4gc.s17) ]
  %r18867 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token66)
  %r57.0.relocated68 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 0, i32 0) ; (%r57.0.relocated61, %r57.0.relocated61)
  %r48.0.base.relocated69 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 1, i32 1) ; (%r48.0.base.relocated62, %r48.0.base.relocated62)
  %rs4gc.s15.relocated70 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 2, i32 2) ; (%rs4gc.s15.relocated63, %rs4gc.s15.relocated63)
  %rs4gc.s12.relocated71 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 3, i32 3) ; (%rs4gc.s12.relocated64, %rs4gc.s12.relocated64)
  %r48.0.relocated72 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 1, i32 4) ; (%r48.0.base.relocated62, %r48.0.relocated65)
  %rs4gc.s16.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  %rs4gc.s17.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 6, i32 6) ; (%rs4gc.s17, %rs4gc.s17)
  %statepoint_token73 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r18867, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated68, ptr addrspace(1) %r48.0.base.relocated69, ptr addrspace(1) %rs4gc.s15.relocated70, ptr addrspace(1) %rs4gc.s12.relocated71, ptr addrspace(1) %r48.0.relocated72, ptr addrspace(1) %rs4gc.s16.relocated, ptr addrspace(1) %rs4gc.s17.relocated) ]
  %r18974 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token73)
  %r57.0.relocated75 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 0, i32 0) ; (%r57.0.relocated68, %r57.0.relocated68)
  %r48.0.base.relocated76 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 1, i32 1) ; (%r48.0.base.relocated69, %r48.0.base.relocated69)
  %rs4gc.s15.relocated77 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 2, i32 2) ; (%rs4gc.s15.relocated70, %rs4gc.s15.relocated70)
  %rs4gc.s12.relocated78 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 3, i32 3) ; (%rs4gc.s12.relocated71, %rs4gc.s12.relocated71)
  %r48.0.relocated79 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 1, i32 4) ; (%r48.0.base.relocated69, %r48.0.relocated72)
  %rs4gc.s16.relocated80 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 5, i32 5) ; (%rs4gc.s16.relocated, %rs4gc.s16.relocated)
  %rs4gc.s17.relocated81 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 6, i32 6) ; (%rs4gc.s17.relocated, %rs4gc.s17.relocated)
  %r190 = bitcast i64 %r18974 to double
  %rs4gc.b18 = bitcast double %r190 to i64
  %rs4gc.s18 = inttoptr i64 %rs4gc.b18 to ptr addrspace(1)
  %r191.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r191 = call i64 asm "", "=r,0"(i64 %r191.rs4i) #7
  %r192 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r193 = icmp ne i32 %r192, 0
  br i1 %r193, label %shadow.root.barrier.35, label %shadow.root.barrier.done.36

shadow.root.barrier.35:                           ; preds = %shadow.root.barrier.done.34
  call void @js_write_barrier_root_nanbox(i64 %r191) #7
  br label %shadow.root.barrier.done.36

shadow.root.barrier.done.36:                      ; preds = %shadow.root.barrier.35, %shadow.root.barrier.done.34
  %r194.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r194.rs4o = call i64 asm "", "=r,0"(i64 %r194.rs4i) #7
  %r194 = bitcast i64 %r194.rs4o to double
  %statepoint_token82 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r194, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated75, ptr addrspace(1) %r48.0.base.relocated76, ptr addrspace(1) %rs4gc.s15.relocated77, ptr addrspace(1) %rs4gc.s12.relocated78, ptr addrspace(1) %r48.0.relocated79, ptr addrspace(1) %rs4gc.s16.relocated80, ptr addrspace(1) %rs4gc.s17.relocated81) ]
  %r19583 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token82)
  %r57.0.relocated84 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token82, i32 0, i32 0) ; (%r57.0.relocated75, %r57.0.relocated75)
  %r48.0.base.relocated85 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token82, i32 1, i32 1) ; (%r48.0.base.relocated76, %r48.0.base.relocated76)
  %rs4gc.s15.relocated86 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token82, i32 2, i32 2) ; (%rs4gc.s15.relocated77, %rs4gc.s15.relocated77)
  %rs4gc.s12.relocated87 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token82, i32 3, i32 3) ; (%rs4gc.s12.relocated78, %rs4gc.s12.relocated78)
  %r48.0.relocated88 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token82, i32 1, i32 4) ; (%r48.0.base.relocated76, %r48.0.relocated79)
  %rs4gc.s16.relocated89 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token82, i32 5, i32 5) ; (%rs4gc.s16.relocated80, %rs4gc.s16.relocated80)
  %rs4gc.s17.relocated90 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token82, i32 6, i32 6) ; (%rs4gc.s17.relocated81, %rs4gc.s17.relocated81)
  %r196 = bitcast i64 %r19583 to double
  %r197.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17.relocated90 to i64
  %r197.rs4o = call i64 asm "", "=r,0"(i64 %r197.rs4i) #7
  %r197 = bitcast i64 %r197.rs4o to double
  %r198 = bitcast double %r197 to i64
  %r199 = icmp eq i64 %r19583, %r198
  br i1 %r199, label %streq.true.41, label %streq.tag.37

streq.tag.37:                                     ; preds = %shadow.root.barrier.done.36
  %r200 = lshr i64 %r19583, 48
  %r201 = lshr i64 %r198, 48
  %r202 = icmp eq i64 %r200, 32767
  %r203 = icmp eq i64 %r201, 32767
  %r204 = and i1 %r202, %r203
  br i1 %r204, label %streq.heap.38, label %streq.ssochk.39

streq.heap.38:                                    ; preds = %streq.tag.37
  %r205 = and i64 %r19583, 281474976710655
  %r206 = and i64 %r198, 281474976710655
  %r207 = icmp ugt i64 %r205, 4095
  %r208 = icmp ugt i64 %r206, 4095
  %r209 = and i1 %r207, %r208
  br i1 %r209, label %streq.heap.valid.44, label %streq.heap.slow.52

streq.ssochk.39:                                  ; preds = %streq.tag.37
  %r239 = icmp eq i64 %r200, 32761
  %r240 = icmp eq i64 %r201, 32761
  %r241 = and i1 %r239, %r240
  br i1 %r241, label %streq.false.42, label %streq.boxed.40

streq.boxed.40:                                   ; preds = %streq.ssochk.39
  %statepoint_token91 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r196, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated84, ptr addrspace(1) %r48.0.base.relocated85, ptr addrspace(1) %rs4gc.s15.relocated86, ptr addrspace(1) %rs4gc.s12.relocated87, ptr addrspace(1) %r48.0.relocated88, ptr addrspace(1) %rs4gc.s16.relocated89, ptr addrspace(1) %rs4gc.s17.relocated90) ]
  %r24292 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token91)
  %r57.0.relocated93 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 0, i32 0) ; (%r57.0.relocated84, %r57.0.relocated84)
  %r48.0.base.relocated94 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 1, i32 1) ; (%r48.0.base.relocated85, %r48.0.base.relocated85)
  %rs4gc.s15.relocated95 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 2, i32 2) ; (%rs4gc.s15.relocated86, %rs4gc.s15.relocated86)
  %rs4gc.s12.relocated96 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 3, i32 3) ; (%rs4gc.s12.relocated87, %rs4gc.s12.relocated87)
  %r48.0.relocated97 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 1, i32 4) ; (%r48.0.base.relocated85, %r48.0.relocated88)
  %rs4gc.s16.relocated98 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 5, i32 5) ; (%rs4gc.s16.relocated89, %rs4gc.s16.relocated89)
  %rs4gc.s17.relocated99 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 6, i32 6) ; (%rs4gc.s17.relocated90, %rs4gc.s17.relocated90)
  %r3582.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17.relocated99 to i64
  %r3582.rs4o = call i64 asm "", "=r,0"(i64 %r3582.rs4i) #7
  %r3582 = bitcast i64 %r3582.rs4o to double
  %statepoint_token100 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r3582, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated93, ptr addrspace(1) %r48.0.base.relocated94, ptr addrspace(1) %rs4gc.s15.relocated95, ptr addrspace(1) %rs4gc.s12.relocated96, ptr addrspace(1) %r48.0.relocated97, ptr addrspace(1) %rs4gc.s16.relocated98) ]
  %r243101 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token100)
  %r57.0.relocated102 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 0, i32 0) ; (%r57.0.relocated93, %r57.0.relocated93)
  %r48.0.base.relocated103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 1, i32 1) ; (%r48.0.base.relocated94, %r48.0.base.relocated94)
  %rs4gc.s15.relocated104 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 2, i32 2) ; (%rs4gc.s15.relocated95, %rs4gc.s15.relocated95)
  %rs4gc.s12.relocated105 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 3, i32 3) ; (%rs4gc.s12.relocated96, %rs4gc.s12.relocated96)
  %r48.0.relocated106 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 1, i32 4) ; (%r48.0.base.relocated94, %r48.0.relocated97)
  %rs4gc.s16.relocated107 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 5, i32 5) ; (%rs4gc.s16.relocated98, %rs4gc.s16.relocated98)
  %statepoint_token108 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r24292, i64 %r243101, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated102, ptr addrspace(1) %r48.0.base.relocated103, ptr addrspace(1) %rs4gc.s15.relocated104, ptr addrspace(1) %rs4gc.s12.relocated105, ptr addrspace(1) %r48.0.relocated106, ptr addrspace(1) %rs4gc.s16.relocated107) ]
  %r244109 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token108)
  %r57.0.relocated110 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 0, i32 0) ; (%r57.0.relocated102, %r57.0.relocated102)
  %r48.0.base.relocated111 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 1, i32 1) ; (%r48.0.base.relocated103, %r48.0.base.relocated103)
  %rs4gc.s15.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 2, i32 2) ; (%rs4gc.s15.relocated104, %rs4gc.s15.relocated104)
  %rs4gc.s12.relocated113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 3, i32 3) ; (%rs4gc.s12.relocated105, %rs4gc.s12.relocated105)
  %r48.0.relocated114 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 1, i32 4) ; (%r48.0.base.relocated103, %r48.0.relocated106)
  %rs4gc.s16.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 5, i32 5) ; (%rs4gc.s16.relocated107, %rs4gc.s16.relocated107)
  br label %streq.merge.43

streq.true.41:                                    ; preds = %streq.heap.middle.byte.51, %streq.heap.two.49, %streq.heap.one.47, %streq.heap.len.45, %shadow.root.barrier.done.36
  br label %streq.merge.43

streq.false.42:                                   ; preds = %streq.heap.middle.byte.51, %streq.heap.last.48, %streq.heap.first.46, %streq.heap.valid.44, %streq.ssochk.39
  br label %streq.merge.43

streq.merge.43:                                   ; preds = %streq.heap.slow.52, %streq.false.42, %streq.true.41, %streq.boxed.40
  %.01073 = phi ptr addrspace(1) [ %rs4gc.s16.relocated89, %streq.true.41 ], [ %rs4gc.s16.relocated89, %streq.false.42 ], [ %rs4gc.s16.relocated123, %streq.heap.slow.52 ], [ %rs4gc.s16.relocated115, %streq.boxed.40 ]
  %.01055 = phi ptr addrspace(1) [ %rs4gc.s15.relocated86, %streq.true.41 ], [ %rs4gc.s15.relocated86, %streq.false.42 ], [ %rs4gc.s15.relocated120, %streq.heap.slow.52 ], [ %rs4gc.s15.relocated112, %streq.boxed.40 ]
  %.31017 = phi ptr addrspace(1) [ %r48.0.relocated88, %streq.true.41 ], [ %r48.0.relocated88, %streq.false.42 ], [ %r48.0.relocated122, %streq.heap.slow.52 ], [ %r48.0.relocated114, %streq.boxed.40 ]
  %.3976 = phi ptr addrspace(1) [ %r48.0.base.relocated85, %streq.true.41 ], [ %r48.0.base.relocated85, %streq.false.42 ], [ %r48.0.base.relocated119, %streq.heap.slow.52 ], [ %r48.0.base.relocated111, %streq.boxed.40 ]
  %.3932 = phi ptr addrspace(1) [ %r57.0.relocated84, %streq.true.41 ], [ %r57.0.relocated84, %streq.false.42 ], [ %r57.0.relocated118, %streq.heap.slow.52 ], [ %r57.0.relocated110, %streq.boxed.40 ]
  %.3 = phi ptr addrspace(1) [ %rs4gc.s12.relocated87, %streq.true.41 ], [ %rs4gc.s12.relocated87, %streq.false.42 ], [ %rs4gc.s12.relocated121, %streq.heap.slow.52 ], [ %rs4gc.s12.relocated113, %streq.boxed.40 ]
  %r245 = phi i32 [ 1, %streq.true.41 ], [ 0, %streq.false.42 ], [ %r238117, %streq.heap.slow.52 ], [ %r244109, %streq.boxed.40 ]
  %r246 = icmp ne i32 %r245, 0
  %r247 = xor i1 %r246, true
  %r248 = select i1 %r247, i64 9222246136947933188, i64 9222246136947933187
  %r249 = bitcast i64 %r248 to double
  %r250 = icmp eq i64 %r248, 9222246136947933188
  br i1 %r250, label %if.then.53, label %if.else.54

streq.heap.valid.44:                              ; preds = %streq.heap.38
  %r210 = inttoptr i64 %r205 to ptr
  %r211 = inttoptr i64 %r206 to ptr
  %r212 = getelementptr inbounds nuw i8, ptr %r210, i64 4
  %r213 = getelementptr inbounds nuw i8, ptr %r211, i64 4
  %r214 = load i32, ptr %r212, align 4
  %r215 = load i32, ptr %r213, align 4
  %r216 = icmp eq i32 %r214, %r215
  br i1 %r216, label %streq.heap.len.45, label %streq.false.42

streq.heap.len.45:                                ; preds = %streq.heap.valid.44
  %r217 = icmp eq i32 %r214, 0
  br i1 %r217, label %streq.true.41, label %streq.heap.first.46

streq.heap.first.46:                              ; preds = %streq.heap.len.45
  %r218 = getelementptr inbounds nuw i8, ptr %r210, i64 20
  %r219 = getelementptr inbounds nuw i8, ptr %r211, i64 20
  %r220 = load i8, ptr %r218, align 1
  %r221 = load i8, ptr %r219, align 1
  %r222 = icmp eq i8 %r220, %r221
  br i1 %r222, label %streq.heap.one.47, label %streq.false.42

streq.heap.one.47:                                ; preds = %streq.heap.first.46
  %r223 = icmp eq i32 %r214, 1
  br i1 %r223, label %streq.true.41, label %streq.heap.last.48

streq.heap.last.48:                               ; preds = %streq.heap.one.47
  %r224 = zext i32 %r214 to i64
  %r225 = add nuw nsw i64 %r224, 19
  %r226 = getelementptr inbounds nuw i8, ptr %r210, i64 %r225
  %r227 = getelementptr inbounds nuw i8, ptr %r211, i64 %r225
  %r228 = load i8, ptr %r226, align 1
  %r229 = load i8, ptr %r227, align 1
  %r230 = icmp eq i8 %r228, %r229
  br i1 %r230, label %streq.heap.two.49, label %streq.false.42

streq.heap.two.49:                                ; preds = %streq.heap.last.48
  %r231 = icmp eq i32 %r214, 2
  br i1 %r231, label %streq.true.41, label %streq.heap.middle.50

streq.heap.middle.50:                             ; preds = %streq.heap.two.49
  %r232 = icmp eq i32 %r214, 3
  br i1 %r232, label %streq.heap.middle.byte.51, label %streq.heap.slow.52

streq.heap.middle.byte.51:                        ; preds = %streq.heap.middle.50
  %r233 = getelementptr inbounds nuw i8, ptr %r210, i64 21
  %r234 = getelementptr inbounds nuw i8, ptr %r211, i64 21
  %r235 = load i8, ptr %r233, align 1
  %r236 = load i8, ptr %r234, align 1
  %r237 = icmp eq i8 %r235, %r236
  br i1 %r237, label %streq.true.41, label %streq.false.42

streq.heap.slow.52:                               ; preds = %streq.heap.middle.50, %streq.heap.38
  %statepoint_token116 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r205, i64 %r206, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated84, ptr addrspace(1) %r48.0.base.relocated85, ptr addrspace(1) %rs4gc.s15.relocated86, ptr addrspace(1) %rs4gc.s12.relocated87, ptr addrspace(1) %r48.0.relocated88, ptr addrspace(1) %rs4gc.s16.relocated89) ]
  %r238117 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token116)
  %r57.0.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 0, i32 0) ; (%r57.0.relocated84, %r57.0.relocated84)
  %r48.0.base.relocated119 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 1, i32 1) ; (%r48.0.base.relocated85, %r48.0.base.relocated85)
  %rs4gc.s15.relocated120 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 2, i32 2) ; (%rs4gc.s15.relocated86, %rs4gc.s15.relocated86)
  %rs4gc.s12.relocated121 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 3, i32 3) ; (%rs4gc.s12.relocated87, %rs4gc.s12.relocated87)
  %r48.0.relocated122 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 1, i32 4) ; (%r48.0.base.relocated85, %r48.0.relocated88)
  %rs4gc.s16.relocated123 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 5, i32 5) ; (%rs4gc.s16.relocated89, %rs4gc.s16.relocated89)
  br label %streq.merge.43

if.then.53:                                       ; preds = %streq.merge.43
  %r251 = load double, ptr @test_json_template_capture_ts_.str.8.handle, align 8
  %statepoint_token124 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r251, i32 0, i32 0)
  %r252125 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token124)
  %r253 = or i64 %r252125, 9222527611924643840
  %r254 = bitcast i64 %r253 to double
  %statepoint_token126 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r254, i32 0, i32 0)
  unreachable

if.else.54:                                       ; preds = %streq.merge.43
  br label %if.merge.55

if.merge.55:                                      ; preds = %if.else.54
  %r256.rs4i = ptrtoint ptr addrspace(1) %.01055 to i64
  %r256.rs4o = call i64 asm "", "=r,0"(i64 %r256.rs4i) #7
  %r256 = bitcast i64 %r256.rs4o to double
  %statepoint_token127 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r256, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3932, ptr addrspace(1) %.3976, ptr addrspace(1) %.01055, ptr addrspace(1) %.3, ptr addrspace(1) %.31017, ptr addrspace(1) %.01073) ]
  %r257128 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token127)
  %r57.0.relocated129 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 0, i32 0) ; (%.3932, %.3932)
  %r48.0.base.relocated130 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 1, i32 1) ; (%.3976, %.3976)
  %rs4gc.s15.relocated131 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 2, i32 2) ; (%.01055, %.01055)
  %rs4gc.s12.relocated132 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 3, i32 3) ; (%.3, %.3)
  %r48.0.relocated133 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 1, i32 4) ; (%.3976, %.31017)
  %rs4gc.s16.relocated134 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 5, i32 5) ; (%.01073, %.01073)
  %statepoint_token135 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r257128, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated129, ptr addrspace(1) %r48.0.base.relocated130, ptr addrspace(1) %rs4gc.s15.relocated131, ptr addrspace(1) %rs4gc.s12.relocated132, ptr addrspace(1) %r48.0.relocated133, ptr addrspace(1) %rs4gc.s16.relocated134) ]
  %r258136 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token135)
  %r57.0.relocated137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 0, i32 0) ; (%r57.0.relocated129, %r57.0.relocated129)
  %r48.0.base.relocated138 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 1, i32 1) ; (%r48.0.base.relocated130, %r48.0.base.relocated130)
  %rs4gc.s15.relocated139 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 2, i32 2) ; (%rs4gc.s15.relocated131, %rs4gc.s15.relocated131)
  %rs4gc.s12.relocated140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 3, i32 3) ; (%rs4gc.s12.relocated132, %rs4gc.s12.relocated132)
  %r48.0.relocated141 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 1, i32 4) ; (%r48.0.base.relocated130, %r48.0.relocated133)
  %rs4gc.s16.relocated142 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 5, i32 5) ; (%rs4gc.s16.relocated134, %rs4gc.s16.relocated134)
  %r259 = bitcast i64 %r258136 to double
  %rs4gc.b19 = bitcast double %r259 to i64
  %rs4gc.s19 = inttoptr i64 %rs4gc.b19 to ptr addrspace(1)
  %r260.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r260 = call i64 asm "", "=r,0"(i64 %r260.rs4i) #7
  %r261 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r262 = icmp ne i32 %r261, 0
  br i1 %r262, label %shadow.root.barrier.56, label %shadow.root.barrier.done.57

shadow.root.barrier.56:                           ; preds = %if.merge.55
  call void @js_write_barrier_root_nanbox(i64 %r260) #7
  br label %shadow.root.barrier.done.57

shadow.root.barrier.done.57:                      ; preds = %shadow.root.barrier.56, %if.merge.55
  %r263.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16.relocated142 to i64
  %r263.rs4o = call i64 asm "", "=r,0"(i64 %r263.rs4i) #7
  %r263 = bitcast i64 %r263.rs4o to double
  %r264 = bitcast double %r263 to i64
  %r265 = and i64 %r264, 281474976710655
  %r266 = lshr i64 %r264, 48
  %r267 = and i64 %r266, 65533
  %r268 = icmp eq i64 %r267, 32765
  br i1 %r268, label %pget.recv_ok.59, label %pget.recv_other.63

pget.recv_sso.58:                                 ; preds = %pget.recv_other.63
  %r406 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r407 = bitcast double %r406 to i64
  %r408 = and i64 %r407, 281474976710655
  %statepoint_token143 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r264, i64 %r408, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated137, ptr addrspace(1) %r48.0.base.relocated138, ptr addrspace(1) %rs4gc.s15.relocated139, ptr addrspace(1) %rs4gc.s19, ptr addrspace(1) %rs4gc.s12.relocated140, ptr addrspace(1) %r48.0.relocated141, ptr addrspace(1) %rs4gc.s16.relocated142) ]
  %r409144 = call double @llvm.experimental.gc.result.f64(token %statepoint_token143)
  %r57.0.relocated145 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token143, i32 0, i32 0) ; (%r57.0.relocated137, %r57.0.relocated137)
  %r48.0.base.relocated146 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token143, i32 1, i32 1) ; (%r48.0.base.relocated138, %r48.0.base.relocated138)
  %rs4gc.s15.relocated147 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token143, i32 2, i32 2) ; (%rs4gc.s15.relocated139, %rs4gc.s15.relocated139)
  %rs4gc.s19.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token143, i32 3, i32 3) ; (%rs4gc.s19, %rs4gc.s19)
  %rs4gc.s12.relocated148 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token143, i32 4, i32 4) ; (%rs4gc.s12.relocated140, %rs4gc.s12.relocated140)
  %r48.0.relocated149 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token143, i32 1, i32 5) ; (%r48.0.base.relocated138, %r48.0.relocated141)
  %rs4gc.s16.relocated150 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token143, i32 6, i32 6) ; (%rs4gc.s16.relocated142, %rs4gc.s16.relocated142)
  br label %pget.recv_merge.62

pget.recv_ok.59:                                  ; preds = %shadow.root.barrier.done.57
  %r275 = icmp ugt i64 %r265, 1048575
  br i1 %r275, label %pic.recv_hdr.80, label %pic.miss.cold.77

pget.recv_bad.60:                                 ; preds = %pget.check_class_ref.64
  %r398 = icmp eq i64 %r264, 9222246136947933185
  %r399 = icmp eq i64 %r264, 9222246136947933186
  %r400 = or i1 %r398, %r399
  br i1 %r400, label %pget.throw_nullish.87, label %pget.recv_undef_return.88

pget.recv_class_ref.61:                           ; preds = %pget.check_class_ref.64
  %r271 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r272 = bitcast double %r271 to i64
  %r273 = and i64 %r272, 281474976710655
  %statepoint_token151 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6060382687846203397, i64 %r264, i64 %r273, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated137, ptr addrspace(1) %r48.0.base.relocated138, ptr addrspace(1) %rs4gc.s15.relocated139, ptr addrspace(1) %rs4gc.s19, ptr addrspace(1) %rs4gc.s12.relocated140, ptr addrspace(1) %r48.0.relocated141, ptr addrspace(1) %rs4gc.s16.relocated142) ]
  %r274152 = call double @llvm.experimental.gc.result.f64(token %statepoint_token151)
  %r57.0.relocated153 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 0, i32 0) ; (%r57.0.relocated137, %r57.0.relocated137)
  %r48.0.base.relocated154 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 1, i32 1) ; (%r48.0.base.relocated138, %r48.0.base.relocated138)
  %rs4gc.s15.relocated155 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 2, i32 2) ; (%rs4gc.s15.relocated139, %rs4gc.s15.relocated139)
  %rs4gc.s19.relocated156 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 3, i32 3) ; (%rs4gc.s19, %rs4gc.s19)
  %rs4gc.s12.relocated157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 4, i32 4) ; (%rs4gc.s12.relocated140, %rs4gc.s12.relocated140)
  %r48.0.relocated158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 1, i32 5) ; (%r48.0.base.relocated138, %r48.0.relocated141)
  %rs4gc.s16.relocated159 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 6, i32 6) ; (%rs4gc.s16.relocated142, %rs4gc.s16.relocated142)
  br label %pget.recv_merge.62

pget.recv_merge.62:                               ; preds = %pget.recv_undef_return.88, %pic.merge.79, %pget.recv_class_ref.61, %pget.recv_sso.58
  %.01077 = phi ptr addrspace(1) [ %.11078, %pic.merge.79 ], [ %rs4gc.s19.relocated, %pget.recv_sso.58 ], [ %rs4gc.s19.relocated156, %pget.recv_class_ref.61 ], [ %rs4gc.s19.relocated184, %pget.recv_undef_return.88 ]
  %.11074 = phi ptr addrspace(1) [ %.21075, %pic.merge.79 ], [ %rs4gc.s16.relocated150, %pget.recv_sso.58 ], [ %rs4gc.s16.relocated159, %pget.recv_class_ref.61 ], [ %rs4gc.s16.relocated187, %pget.recv_undef_return.88 ]
  %.11056 = phi ptr addrspace(1) [ %.21057, %pic.merge.79 ], [ %rs4gc.s15.relocated147, %pget.recv_sso.58 ], [ %rs4gc.s15.relocated155, %pget.recv_class_ref.61 ], [ %rs4gc.s15.relocated183, %pget.recv_undef_return.88 ]
  %.41018 = phi ptr addrspace(1) [ %.51019, %pic.merge.79 ], [ %r48.0.relocated149, %pget.recv_sso.58 ], [ %r48.0.relocated158, %pget.recv_class_ref.61 ], [ %r48.0.relocated186, %pget.recv_undef_return.88 ]
  %.4977 = phi ptr addrspace(1) [ %.5978, %pic.merge.79 ], [ %r48.0.base.relocated146, %pget.recv_sso.58 ], [ %r48.0.base.relocated154, %pget.recv_class_ref.61 ], [ %r48.0.base.relocated182, %pget.recv_undef_return.88 ]
  %.4933 = phi ptr addrspace(1) [ %.5934, %pic.merge.79 ], [ %r57.0.relocated145, %pget.recv_sso.58 ], [ %r57.0.relocated153, %pget.recv_class_ref.61 ], [ %r57.0.relocated181, %pget.recv_undef_return.88 ]
  %.4 = phi ptr addrspace(1) [ %.5, %pic.merge.79 ], [ %rs4gc.s12.relocated148, %pget.recv_sso.58 ], [ %rs4gc.s12.relocated157, %pget.recv_class_ref.61 ], [ %rs4gc.s12.relocated185, %pget.recv_undef_return.88 ]
  %r410 = phi double [ %r397, %pic.merge.79 ], [ %r405180, %pget.recv_undef_return.88 ], [ %r409144, %pget.recv_sso.58 ], [ %r274152, %pget.recv_class_ref.61 ]
  %r411 = load double, ptr @test_json_template_capture_ts_.str.10.handle, align 8
  %r412 = bitcast double %r411 to i64
  %r413 = bitcast double %r410 to i64
  %r414 = and i64 %r413, 281474976710655
  %r415 = and i64 %r413, -281474976710656
  %r416 = icmp eq i64 %r415, 9222527611924643840
  %r417 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r418 = icmp eq i64 %r417, 0
  %r419 = lshr i64 %r414, 3
  %r420 = and i64 %r419, 63
  %r421 = getelementptr [64 x i64], ptr @PERRY_TA_KIND_CACHE, i64 0, i64 %r420
  %r422 = load i64, ptr %r421, align 8
  %r423 = lshr i64 %r422, 8
  %r424 = icmp eq i64 %r423, %r414
  %r425 = and i64 %r422, 255
  %r426 = icmp ule i64 %r425, 7
  %r429 = and i1 %r416, %r418
  %r430 = and i1 %r429, %r424
  %r431 = and i1 %r430, %r426
  br i1 %r431, label %tav.set.fast.89, label %tav.set.slow.91

pget.recv_other.63:                               ; preds = %shadow.root.barrier.done.57
  %r269 = icmp eq i64 %r266, 32761
  br i1 %r269, label %pget.recv_sso.58, label %pget.check_class_ref.64

pget.check_class_ref.64:                          ; preds = %pget.recv_other.63
  %r270 = icmp eq i64 %r266, 32766
  br i1 %r270, label %pget.recv_class_ref.61, label %pget.recv_bad.60

pic.hit.65:                                       ; preds = %pic.token.81
  %r300 = getelementptr i64, ptr %r285, i64 1
  %r301 = load i64, ptr %r300, align 8
  %r302 = and i64 %r301, 1073741824
  %r303 = icmp ne i64 %r302, 0
  br i1 %r303, label %pic.hit.overflow.82, label %pic.hit.inline.83

pic.hit.live.66:                                  ; preds = %pic.hit.inline.83
  br label %pic.merge.79

pic.prefix.guard.67:                              ; preds = %pic.token.81
  %r316 = getelementptr i64, ptr %r285, i64 2
  %r317 = load i64, ptr %r316, align 8
  %r318 = icmp ne i64 %r317, 0
  br i1 %r318, label %pic.prefix.meta.68, label %pic.miss.76

pic.prefix.meta.68:                               ; preds = %pic.prefix.guard.67
  %r319 = add nuw nsw i64 %r265, 8
  %r320 = inttoptr i64 %r319 to ptr
  %r321 = load i64, ptr %r320, align 8
  %r322 = icmp ne i64 %r321, 0
  br i1 %r322, label %pic.prefix.token.69, label %pic.miss.76

pic.prefix.token.69:                              ; preds = %pic.prefix.meta.68
  %r323 = inttoptr i64 %r321 to ptr
  %r324 = getelementptr i64, ptr %r323, i64 6
  %r325 = load i64, ptr %r324, align 8
  %r326 = icmp eq i64 %r325, %r317
  br i1 %r326, label %pic.prefix.hit.70, label %pic.miss.76

pic.prefix.hit.70:                                ; preds = %pic.prefix.token.69
  %r327 = getelementptr i64, ptr %r285, i64 1
  %r328 = load i64, ptr %r327, align 8
  %r329 = shl i64 %r328, 3
  %r330 = add nuw nsw i64 %r265, 16
  %r331 = add i64 %r330, %r329
  %r332 = inttoptr i64 %r331 to ptr
  %r333 = load double, ptr %r332, align 8
  br label %pic.merge.79

pic.desc.classify.71:                             ; preds = %pic.recv_hdr.80
  %r289 = and i1 %r279, %r286
  br i1 %r289, label %pic.desc.prefix.guard.72, label %pic.miss.cold.77

pic.desc.prefix.guard.72:                         ; preds = %pic.desc.classify.71
  %r334 = getelementptr i64, ptr %r285, i64 2
  %r335 = load i64, ptr %r334, align 8
  %r336 = icmp ne i64 %r335, 0
  br i1 %r336, label %pic.desc.prefix.meta.73, label %pic.miss.cold.77

pic.desc.prefix.meta.73:                          ; preds = %pic.desc.prefix.guard.72
  %r337 = add nuw nsw i64 %r265, 8
  %r338 = inttoptr i64 %r337 to ptr
  %r339 = load i64, ptr %r338, align 8
  %r340 = icmp ne i64 %r339, 0
  br i1 %r340, label %pic.desc.prefix.token.74, label %pic.miss.cold.77

pic.desc.prefix.token.74:                         ; preds = %pic.desc.prefix.meta.73
  %r341 = inttoptr i64 %r339 to ptr
  %r342 = getelementptr i64, ptr %r341, i64 6
  %r343 = load i64, ptr %r342, align 8
  %r344 = icmp eq i64 %r343, %r335
  br i1 %r344, label %pic.desc.prefix.hit.75, label %pic.miss.cold.77

pic.desc.prefix.hit.75:                           ; preds = %pic.desc.prefix.token.74
  %r345 = getelementptr i64, ptr %r285, i64 1
  %r346 = load i64, ptr %r345, align 8
  %r347 = shl i64 %r346, 3
  %r348 = add nuw nsw i64 %r265, 16
  %r349 = add i64 %r348, %r347
  %r350 = inttoptr i64 %r349 to ptr
  %r351 = load double, ptr %r350, align 8
  br label %pic.merge.79

pic.miss.76:                                      ; preds = %pic.hit.inline.83, %pic.prefix.token.69, %pic.prefix.meta.68, %pic.prefix.guard.67
  %r352 = getelementptr i64, ptr %r285, i64 3
  %r353 = load i64, ptr %r352, align 8
  %r354 = icmp sgt i64 %r353, 0
  br i1 %r354, label %pic.ways.84, label %pic.miss.call.78

pic.miss.cold.77:                                 ; preds = %pic.desc.prefix.token.74, %pic.desc.prefix.meta.73, %pic.desc.prefix.guard.72, %pic.desc.classify.71, %pget.recv_ok.59
  br label %pic.miss.call.78

pic.miss.call.78:                                 ; preds = %pic.way.load.85, %pic.ways.84, %pic.miss.cold.77, %pic.miss.76
  %r393 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r394 = bitcast double %r393 to i64
  %r395 = and i64 %r394, 281474976710655
  %statepoint_token160 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r265, i64 %r395, ptr @perry_ic_test_json_template_capture_ts__6, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated137, ptr addrspace(1) %r48.0.base.relocated138, ptr addrspace(1) %rs4gc.s15.relocated139, ptr addrspace(1) %rs4gc.s19, ptr addrspace(1) %rs4gc.s12.relocated140, ptr addrspace(1) %r48.0.relocated141, ptr addrspace(1) %rs4gc.s16.relocated142) ]
  %r396161 = call double @llvm.experimental.gc.result.f64(token %statepoint_token160)
  %r57.0.relocated162 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 0, i32 0) ; (%r57.0.relocated137, %r57.0.relocated137)
  %r48.0.base.relocated163 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 1, i32 1) ; (%r48.0.base.relocated138, %r48.0.base.relocated138)
  %rs4gc.s15.relocated164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 2, i32 2) ; (%rs4gc.s15.relocated139, %rs4gc.s15.relocated139)
  %rs4gc.s19.relocated165 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 3, i32 3) ; (%rs4gc.s19, %rs4gc.s19)
  %rs4gc.s12.relocated166 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 4, i32 4) ; (%rs4gc.s12.relocated140, %rs4gc.s12.relocated140)
  %r48.0.relocated167 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 1, i32 5) ; (%r48.0.base.relocated138, %r48.0.relocated141)
  %rs4gc.s16.relocated168 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 6, i32 6) ; (%rs4gc.s16.relocated142, %rs4gc.s16.relocated142)
  br label %pic.merge.79

pic.merge.79:                                     ; preds = %pic.way.live.86, %pic.hit.overflow.82, %pic.miss.call.78, %pic.desc.prefix.hit.75, %pic.prefix.hit.70, %pic.hit.live.66
  %.11078 = phi ptr addrspace(1) [ %rs4gc.s19.relocated174, %pic.hit.overflow.82 ], [ %rs4gc.s19.relocated165, %pic.miss.call.78 ], [ %rs4gc.s19, %pic.way.live.86 ], [ %rs4gc.s19, %pic.hit.live.66 ], [ %rs4gc.s19, %pic.prefix.hit.70 ], [ %rs4gc.s19, %pic.desc.prefix.hit.75 ]
  %.21075 = phi ptr addrspace(1) [ %rs4gc.s16.relocated177, %pic.hit.overflow.82 ], [ %rs4gc.s16.relocated168, %pic.miss.call.78 ], [ %rs4gc.s16.relocated142, %pic.way.live.86 ], [ %rs4gc.s16.relocated142, %pic.hit.live.66 ], [ %rs4gc.s16.relocated142, %pic.prefix.hit.70 ], [ %rs4gc.s16.relocated142, %pic.desc.prefix.hit.75 ]
  %.21057 = phi ptr addrspace(1) [ %rs4gc.s15.relocated173, %pic.hit.overflow.82 ], [ %rs4gc.s15.relocated164, %pic.miss.call.78 ], [ %rs4gc.s15.relocated139, %pic.way.live.86 ], [ %rs4gc.s15.relocated139, %pic.hit.live.66 ], [ %rs4gc.s15.relocated139, %pic.prefix.hit.70 ], [ %rs4gc.s15.relocated139, %pic.desc.prefix.hit.75 ]
  %.51019 = phi ptr addrspace(1) [ %r48.0.relocated176, %pic.hit.overflow.82 ], [ %r48.0.relocated167, %pic.miss.call.78 ], [ %r48.0.relocated141, %pic.way.live.86 ], [ %r48.0.relocated141, %pic.hit.live.66 ], [ %r48.0.relocated141, %pic.prefix.hit.70 ], [ %r48.0.relocated141, %pic.desc.prefix.hit.75 ]
  %.5978 = phi ptr addrspace(1) [ %r48.0.base.relocated172, %pic.hit.overflow.82 ], [ %r48.0.base.relocated163, %pic.miss.call.78 ], [ %r48.0.base.relocated138, %pic.way.live.86 ], [ %r48.0.base.relocated138, %pic.hit.live.66 ], [ %r48.0.base.relocated138, %pic.prefix.hit.70 ], [ %r48.0.base.relocated138, %pic.desc.prefix.hit.75 ]
  %.5934 = phi ptr addrspace(1) [ %r57.0.relocated171, %pic.hit.overflow.82 ], [ %r57.0.relocated162, %pic.miss.call.78 ], [ %r57.0.relocated137, %pic.way.live.86 ], [ %r57.0.relocated137, %pic.hit.live.66 ], [ %r57.0.relocated137, %pic.prefix.hit.70 ], [ %r57.0.relocated137, %pic.desc.prefix.hit.75 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s12.relocated175, %pic.hit.overflow.82 ], [ %rs4gc.s12.relocated166, %pic.miss.call.78 ], [ %rs4gc.s12.relocated140, %pic.way.live.86 ], [ %rs4gc.s12.relocated140, %pic.hit.live.66 ], [ %rs4gc.s12.relocated140, %pic.prefix.hit.70 ], [ %rs4gc.s12.relocated140, %pic.desc.prefix.hit.75 ]
  %r397 = phi double [ %r313, %pic.hit.live.66 ], [ %r308170, %pic.hit.overflow.82 ], [ %r333, %pic.prefix.hit.70 ], [ %r351, %pic.desc.prefix.hit.75 ], [ %r390, %pic.way.live.86 ], [ %r396161, %pic.miss.call.78 ]
  br label %pget.recv_merge.62

pic.recv_hdr.80:                                  ; preds = %pget.recv_ok.59
  %r276 = sub nuw nsw i64 %r265, 8
  %r277 = inttoptr i64 %r276 to ptr
  %r278 = load i8, ptr %r277, align 1
  %r279 = icmp eq i8 %r278, 2
  %r280 = sub nuw nsw i64 %r265, 6
  %r281 = inttoptr i64 %r280 to ptr
  %r282 = load i16, ptr %r281, align 2
  %r283 = and i16 %r282, 2048
  %r284 = icmp eq i16 %r283, 0
  %r285 = load ptr, ptr @perry_ic_test_json_template_capture_ts__6, align 8
  %r286 = icmp ne ptr %r285, null
  %r287 = and i1 %r279, %r284
  %r288 = and i1 %r287, %r286
  br i1 %r288, label %pic.token.81, label %pic.desc.classify.71

pic.token.81:                                     ; preds = %pic.recv_hdr.80
  %r290 = add nuw nsw i64 %r265, 4
  %r291 = inttoptr i64 %r290 to ptr
  %r292 = load i32, ptr %r291, align 4
  %r293 = zext i32 %r292 to i64
  %r294 = or i64 %r293, 4611686018427387904
  %r295 = icmp ne i32 %r292, 0
  %r296 = getelementptr i64, ptr %r285, i64 0
  %r297 = load i64, ptr %r296, align 8
  %r298 = icmp eq i64 %r294, %r297
  %r299 = and i1 %r298, %r295
  br i1 %r299, label %pic.hit.65, label %pic.prefix.guard.67

pic.hit.overflow.82:                              ; preds = %pic.hit.65
  %r304 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r305 = bitcast double %r304 to i64
  %r306 = and i64 %r305, 281474976710655
  %r307 = trunc i64 %r301 to i32
  %statepoint_token169 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r265, i64 %r306, i32 %r307, ptr @perry_ic_test_json_template_capture_ts__6, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated137, ptr addrspace(1) %r48.0.base.relocated138, ptr addrspace(1) %rs4gc.s15.relocated139, ptr addrspace(1) %rs4gc.s19, ptr addrspace(1) %rs4gc.s12.relocated140, ptr addrspace(1) %r48.0.relocated141, ptr addrspace(1) %rs4gc.s16.relocated142) ]
  %r308170 = call double @llvm.experimental.gc.result.f64(token %statepoint_token169)
  %r57.0.relocated171 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 0, i32 0) ; (%r57.0.relocated137, %r57.0.relocated137)
  %r48.0.base.relocated172 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 1, i32 1) ; (%r48.0.base.relocated138, %r48.0.base.relocated138)
  %rs4gc.s15.relocated173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 2, i32 2) ; (%rs4gc.s15.relocated139, %rs4gc.s15.relocated139)
  %rs4gc.s19.relocated174 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 3, i32 3) ; (%rs4gc.s19, %rs4gc.s19)
  %rs4gc.s12.relocated175 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 4, i32 4) ; (%rs4gc.s12.relocated140, %rs4gc.s12.relocated140)
  %r48.0.relocated176 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 1, i32 5) ; (%r48.0.base.relocated138, %r48.0.relocated141)
  %rs4gc.s16.relocated177 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 6, i32 6) ; (%rs4gc.s16.relocated142, %rs4gc.s16.relocated142)
  br label %pic.merge.79

pic.hit.inline.83:                                ; preds = %pic.hit.65
  %r309 = shl i64 %r301, 3
  %r310 = add nuw nsw i64 %r265, 16
  %r311 = add i64 %r310, %r309
  %r312 = inttoptr i64 %r311 to ptr
  %r313 = load double, ptr %r312, align 8
  %r314 = bitcast double %r313 to i64
  %r315 = icmp eq i64 %r314, 9222246136947933200
  br i1 %r315, label %pic.miss.76, label %pic.hit.live.66

pic.ways.84:                                      ; preds = %pic.miss.76
  %r355 = getelementptr i64, ptr %r285, i64 4
  %r356 = load i64, ptr %r355, align 8
  %r357 = icmp eq i64 %r356, %r294
  %r358 = getelementptr i64, ptr %r285, i64 5
  %r359 = load i64, ptr %r358, align 8
  %r360 = select i1 %r357, i64 %r359, i64 0
  %r361 = getelementptr i64, ptr %r285, i64 6
  %r362 = load i64, ptr %r361, align 8
  %r363 = icmp eq i64 %r362, %r294
  %r364 = getelementptr i64, ptr %r285, i64 7
  %r365 = load i64, ptr %r364, align 8
  %r366 = select i1 %r363, i64 %r365, i64 0
  %r367 = getelementptr i64, ptr %r285, i64 8
  %r368 = load i64, ptr %r367, align 8
  %r369 = icmp eq i64 %r368, %r294
  %r370 = getelementptr i64, ptr %r285, i64 9
  %r371 = load i64, ptr %r370, align 8
  %r372 = select i1 %r369, i64 %r371, i64 0
  %r373 = getelementptr i64, ptr %r285, i64 10
  %r374 = load i64, ptr %r373, align 8
  %r375 = icmp eq i64 %r374, %r294
  %r376 = getelementptr i64, ptr %r285, i64 11
  %r377 = load i64, ptr %r376, align 8
  %r378 = select i1 %r375, i64 %r377, i64 0
  %r379 = or i1 %r357, %r363
  %r380 = select i1 %r357, i64 %r360, i64 %r366
  %r381 = or i1 %r369, %r375
  %r382 = select i1 %r369, i64 %r372, i64 %r378
  %r383 = or i1 %r379, %r381
  %r384 = select i1 %r379, i64 %r380, i64 %r382
  %r385 = and i1 %r295, %r383
  br i1 %r385, label %pic.way.load.85, label %pic.miss.call.78

pic.way.load.85:                                  ; preds = %pic.ways.84
  %r386 = shl i64 %r384, 3
  %r387 = add nuw nsw i64 %r265, 16
  %r388 = add i64 %r387, %r386
  %r389 = inttoptr i64 %r388 to ptr
  %r390 = load double, ptr %r389, align 8
  %r391 = bitcast double %r390 to i64
  %r392 = icmp eq i64 %r391, 9222246136947933200
  br i1 %r392, label %pic.miss.call.78, label %pic.way.live.86

pic.way.live.86:                                  ; preds = %pic.way.load.85
  br label %pic.merge.79

pget.throw_nullish.87:                            ; preds = %pget.recv_bad.60
  %r401 = zext i1 %r399 to i32
  %statepoint_token178 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r401, ptr @test_json_template_capture_ts_.str.9.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.88:                        ; preds = %pget.recv_bad.60
  %r402 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r403 = bitcast double %r402 to i64
  %r404 = and i64 %r403, 281474976710655
  %statepoint_token179 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r264, i64 %r404, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated137, ptr addrspace(1) %r48.0.base.relocated138, ptr addrspace(1) %rs4gc.s15.relocated139, ptr addrspace(1) %rs4gc.s19, ptr addrspace(1) %rs4gc.s12.relocated140, ptr addrspace(1) %r48.0.relocated141, ptr addrspace(1) %rs4gc.s16.relocated142) ]
  %r405180 = call double @llvm.experimental.gc.result.f64(token %statepoint_token179)
  %r57.0.relocated181 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 0, i32 0) ; (%r57.0.relocated137, %r57.0.relocated137)
  %r48.0.base.relocated182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 1, i32 1) ; (%r48.0.base.relocated138, %r48.0.base.relocated138)
  %rs4gc.s15.relocated183 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 2, i32 2) ; (%rs4gc.s15.relocated139, %rs4gc.s15.relocated139)
  %rs4gc.s19.relocated184 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 3, i32 3) ; (%rs4gc.s19, %rs4gc.s19)
  %rs4gc.s12.relocated185 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 4, i32 4) ; (%rs4gc.s12.relocated140, %rs4gc.s12.relocated140)
  %r48.0.relocated186 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 1, i32 5) ; (%r48.0.base.relocated138, %r48.0.relocated141)
  %rs4gc.s16.relocated187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 6, i32 6) ; (%rs4gc.s16.relocated142, %rs4gc.s16.relocated142)
  br label %pget.recv_merge.62

tav.set.fast.89:                                  ; preds = %pget.recv_merge.62
  %r434 = bitcast double %r410 to i64
  %r435 = and i64 %r434, 281474976710655
  %r436 = lshr i64 %r435, 3
  %r437 = and i64 %r436, 63
  %r438 = getelementptr [64 x i64], ptr @PERRY_TA_KIND_CACHE, i64 0, i64 %r437
  %r439 = load i64, ptr %r438, align 8
  %r440 = and i64 %r439, 255
  %r444 = inttoptr i64 %r435 to ptr
  %r445 = load i32, ptr %r444, align 4
  %r446 = zext i32 %r445 to i64
  %r447 = icmp ult i64 0, %r446
  %r448 = and i1 true, %r447
  br i1 %r448, label %tav.set.store.90, label %tav.set.slow.91

tav.set.store.90:                                 ; preds = %tav.set.fast.89
  %r449 = add nuw nsw i64 %r435, 16
  %r450 = fcmp uno double %r411, 0.000000e+00
  %r451 = call double @llvm.fabs.f64(double %r411)
  %r452 = fcmp oeq double %r451, 0x7FF0000000000000
  %r453 = or i1 %r450, %r452
  %r454 = select i1 %r453, double 0.000000e+00, double %r411
  %r455 = fptosi double %r454 to i64
  %r456 = trunc i64 %r455 to i32
  %r457 = icmp eq i64 %r440, 0
  br i1 %r457, label %tav.s.i8.93, label %tav.sd1.101

tav.set.slow.91:                                  ; preds = %tav.set.fast.89, %pget.recv_merge.62
  %statepoint_token188 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double, i32)) @js_dyn_index_set_strict, i32 4, i32 0, double %r410, double 0.000000e+00, double %r411, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4933, ptr addrspace(1) %.4977, ptr addrspace(1) %.11056, ptr addrspace(1) %.01077, ptr addrspace(1) %.4, ptr addrspace(1) %.41018, ptr addrspace(1) %.11074) ]
  %r57.0.relocated189 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 0, i32 0) ; (%.4933, %.4933)
  %r48.0.base.relocated190 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 1, i32 1) ; (%.4977, %.4977)
  %rs4gc.s15.relocated191 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 2, i32 2) ; (%.11056, %.11056)
  %rs4gc.s19.relocated192 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 3, i32 3) ; (%.01077, %.01077)
  %rs4gc.s12.relocated193 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 4, i32 4) ; (%.4, %.4)
  %r48.0.relocated194 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 1, i32 5) ; (%.4977, %.41018)
  %rs4gc.s16.relocated195 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 6, i32 6) ; (%.11074, %.11074)
  br label %tav.set.merge.92

tav.set.merge.92:                                 ; preds = %tav.s.f64.100, %tav.s.f32.99, %tav.s.u32.98, %tav.s.i32.97, %tav.s.u16.96, %tav.s.i16.95, %tav.s.u8.94, %tav.s.i8.93, %tav.set.slow.91
  %.21079 = phi ptr addrspace(1) [ %.01077, %tav.s.i8.93 ], [ %.01077, %tav.s.u8.94 ], [ %.01077, %tav.s.i16.95 ], [ %.01077, %tav.s.u16.96 ], [ %.01077, %tav.s.i32.97 ], [ %.01077, %tav.s.u32.98 ], [ %.01077, %tav.s.f32.99 ], [ %.01077, %tav.s.f64.100 ], [ %rs4gc.s19.relocated192, %tav.set.slow.91 ]
  %.31076 = phi ptr addrspace(1) [ %.11074, %tav.s.i8.93 ], [ %.11074, %tav.s.u8.94 ], [ %.11074, %tav.s.i16.95 ], [ %.11074, %tav.s.u16.96 ], [ %.11074, %tav.s.i32.97 ], [ %.11074, %tav.s.u32.98 ], [ %.11074, %tav.s.f32.99 ], [ %.11074, %tav.s.f64.100 ], [ %rs4gc.s16.relocated195, %tav.set.slow.91 ]
  %.31058 = phi ptr addrspace(1) [ %.11056, %tav.s.i8.93 ], [ %.11056, %tav.s.u8.94 ], [ %.11056, %tav.s.i16.95 ], [ %.11056, %tav.s.u16.96 ], [ %.11056, %tav.s.i32.97 ], [ %.11056, %tav.s.u32.98 ], [ %.11056, %tav.s.f32.99 ], [ %.11056, %tav.s.f64.100 ], [ %rs4gc.s15.relocated191, %tav.set.slow.91 ]
  %.61020 = phi ptr addrspace(1) [ %.41018, %tav.s.i8.93 ], [ %.41018, %tav.s.u8.94 ], [ %.41018, %tav.s.i16.95 ], [ %.41018, %tav.s.u16.96 ], [ %.41018, %tav.s.i32.97 ], [ %.41018, %tav.s.u32.98 ], [ %.41018, %tav.s.f32.99 ], [ %.41018, %tav.s.f64.100 ], [ %r48.0.relocated194, %tav.set.slow.91 ]
  %.6979 = phi ptr addrspace(1) [ %.4977, %tav.s.i8.93 ], [ %.4977, %tav.s.u8.94 ], [ %.4977, %tav.s.i16.95 ], [ %.4977, %tav.s.u16.96 ], [ %.4977, %tav.s.i32.97 ], [ %.4977, %tav.s.u32.98 ], [ %.4977, %tav.s.f32.99 ], [ %.4977, %tav.s.f64.100 ], [ %r48.0.base.relocated190, %tav.set.slow.91 ]
  %.6935 = phi ptr addrspace(1) [ %.4933, %tav.s.i8.93 ], [ %.4933, %tav.s.u8.94 ], [ %.4933, %tav.s.i16.95 ], [ %.4933, %tav.s.u16.96 ], [ %.4933, %tav.s.i32.97 ], [ %.4933, %tav.s.u32.98 ], [ %.4933, %tav.s.f32.99 ], [ %.4933, %tav.s.f64.100 ], [ %r57.0.relocated189, %tav.set.slow.91 ]
  %.6 = phi ptr addrspace(1) [ %.4, %tav.s.i8.93 ], [ %.4, %tav.s.u8.94 ], [ %.4, %tav.s.i16.95 ], [ %.4, %tav.s.u16.96 ], [ %.4, %tav.s.i32.97 ], [ %.4, %tav.s.u32.98 ], [ %.4, %tav.s.f32.99 ], [ %.4, %tav.s.f64.100 ], [ %rs4gc.s12.relocated193, %tav.set.slow.91 ]
  %r494.rs4i = ptrtoint ptr addrspace(1) %.31076 to i64
  %r494.rs4o = call i64 asm "", "=r,0"(i64 %r494.rs4i) #7
  %r494 = bitcast i64 %r494.rs4o to double
  %r495 = bitcast double %r494 to i64
  %r496 = and i64 %r495, 281474976710655
  %r497 = lshr i64 %r495, 48
  %r498 = and i64 %r497, 65533
  %r499 = icmp eq i64 %r498, 32765
  br i1 %r499, label %pget.recv_ok.108, label %pget.recv_other.112

tav.s.i8.93:                                      ; preds = %tav.set.store.90
  %r465 = add nuw nsw i64 %r449, 0
  %r466 = inttoptr i64 %r465 to ptr
  %r467 = trunc i32 %r456 to i8
  store i8 %r467, ptr %r466, align 1
  br label %tav.set.merge.92

tav.s.u8.94:                                      ; preds = %tav.sd1.101
  %r469 = add nuw nsw i64 %r449, 0
  %r470 = inttoptr i64 %r469 to ptr
  %r471 = trunc i32 %r456 to i8
  store i8 %r471, ptr %r470, align 1
  br label %tav.set.merge.92

tav.s.i16.95:                                     ; preds = %tav.sd2.102
  %r473 = add nuw nsw i64 %r449, 0
  %r474 = inttoptr i64 %r473 to ptr
  %r475 = trunc i32 %r456 to i16
  store i16 %r475, ptr %r474, align 2
  br label %tav.set.merge.92

tav.s.u16.96:                                     ; preds = %tav.sd3.103
  %r477 = add nuw nsw i64 %r449, 0
  %r478 = inttoptr i64 %r477 to ptr
  %r479 = trunc i32 %r456 to i16
  store i16 %r479, ptr %r478, align 2
  br label %tav.set.merge.92

tav.s.i32.97:                                     ; preds = %tav.sd4.104
  %r481 = add nuw nsw i64 %r449, 0
  %r482 = inttoptr i64 %r481 to ptr
  store i32 %r456, ptr %r482, align 4
  br label %tav.set.merge.92

tav.s.u32.98:                                     ; preds = %tav.sd5.105
  %r484 = add nuw nsw i64 %r449, 0
  %r485 = inttoptr i64 %r484 to ptr
  store i32 %r456, ptr %r485, align 4
  br label %tav.set.merge.92

tav.s.f32.99:                                     ; preds = %tav.sd6.106
  %r487 = add nuw nsw i64 %r449, 0
  %r488 = inttoptr i64 %r487 to ptr
  %r489 = fptrunc double %r411 to float
  store float %r489, ptr %r488, align 4
  br label %tav.set.merge.92

tav.s.f64.100:                                    ; preds = %tav.sd6.106
  %r491 = add nuw nsw i64 %r449, 0
  %r492 = inttoptr i64 %r491 to ptr
  store double %r411, ptr %r492, align 8
  br label %tav.set.merge.92

tav.sd1.101:                                      ; preds = %tav.set.store.90
  %r458 = icmp eq i64 %r440, 1
  br i1 %r458, label %tav.s.u8.94, label %tav.sd2.102

tav.sd2.102:                                      ; preds = %tav.sd1.101
  %r459 = icmp eq i64 %r440, 2
  br i1 %r459, label %tav.s.i16.95, label %tav.sd3.103

tav.sd3.103:                                      ; preds = %tav.sd2.102
  %r460 = icmp eq i64 %r440, 3
  br i1 %r460, label %tav.s.u16.96, label %tav.sd4.104

tav.sd4.104:                                      ; preds = %tav.sd3.103
  %r461 = icmp eq i64 %r440, 4
  br i1 %r461, label %tav.s.i32.97, label %tav.sd5.105

tav.sd5.105:                                      ; preds = %tav.sd4.104
  %r462 = icmp eq i64 %r440, 5
  br i1 %r462, label %tav.s.u32.98, label %tav.sd6.106

tav.sd6.106:                                      ; preds = %tav.sd5.105
  %r463 = icmp eq i64 %r440, 6
  br i1 %r463, label %tav.s.f32.99, label %tav.s.f64.100

pget.recv_sso.107:                                ; preds = %pget.recv_other.112
  %r637 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r638 = bitcast double %r637 to i64
  %r639 = and i64 %r638, 281474976710655
  %statepoint_token196 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r495, i64 %r639, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6935, ptr addrspace(1) %.6, ptr addrspace(1) %.6979, ptr addrspace(1) %.61020, ptr addrspace(1) %.31058, ptr addrspace(1) %.21079) ]
  %r640197 = call double @llvm.experimental.gc.result.f64(token %statepoint_token196)
  %r57.0.relocated198 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token196, i32 0, i32 0) ; (%.6935, %.6935)
  %rs4gc.s12.relocated199 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token196, i32 1, i32 1) ; (%.6, %.6)
  %r48.0.base.relocated200 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token196, i32 2, i32 2) ; (%.6979, %.6979)
  %r48.0.relocated201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token196, i32 2, i32 3) ; (%.6979, %.61020)
  %rs4gc.s15.relocated202 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token196, i32 4, i32 4) ; (%.31058, %.31058)
  %rs4gc.s19.relocated203 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token196, i32 5, i32 5) ; (%.21079, %.21079)
  br label %pget.recv_merge.111

pget.recv_ok.108:                                 ; preds = %tav.set.merge.92
  %r506 = icmp ugt i64 %r496, 1048575
  br i1 %r506, label %pic.recv_hdr.129, label %pic.miss.cold.126

pget.recv_bad.109:                                ; preds = %pget.check_class_ref.113
  %r629 = icmp eq i64 %r495, 9222246136947933185
  %r630 = icmp eq i64 %r495, 9222246136947933186
  %r631 = or i1 %r629, %r630
  br i1 %r631, label %pget.throw_nullish.136, label %pget.recv_undef_return.137

pget.recv_class_ref.110:                          ; preds = %pget.check_class_ref.113
  %r502 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r503 = bitcast double %r502 to i64
  %r504 = and i64 %r503, 281474976710655
  %statepoint_token204 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6060382687846203399, i64 %r495, i64 %r504, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6935, ptr addrspace(1) %.6, ptr addrspace(1) %.6979, ptr addrspace(1) %.61020, ptr addrspace(1) %.31058, ptr addrspace(1) %.21079) ]
  %r505205 = call double @llvm.experimental.gc.result.f64(token %statepoint_token204)
  %r57.0.relocated206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 0, i32 0) ; (%.6935, %.6935)
  %rs4gc.s12.relocated207 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 1, i32 1) ; (%.6, %.6)
  %r48.0.base.relocated208 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 2, i32 2) ; (%.6979, %.6979)
  %r48.0.relocated209 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 2, i32 3) ; (%.6979, %.61020)
  %rs4gc.s15.relocated210 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 4, i32 4) ; (%.31058, %.31058)
  %rs4gc.s19.relocated211 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 5, i32 5) ; (%.21079, %.21079)
  br label %pget.recv_merge.111

pget.recv_merge.111:                              ; preds = %pget.recv_undef_return.137, %pic.merge.128, %pget.recv_class_ref.110, %pget.recv_sso.107
  %.31080 = phi ptr addrspace(1) [ %.41081, %pic.merge.128 ], [ %rs4gc.s19.relocated203, %pget.recv_sso.107 ], [ %rs4gc.s19.relocated211, %pget.recv_class_ref.110 ], [ %rs4gc.s19.relocated243, %pget.recv_undef_return.137 ]
  %.41059 = phi ptr addrspace(1) [ %.51060, %pic.merge.128 ], [ %rs4gc.s15.relocated202, %pget.recv_sso.107 ], [ %rs4gc.s15.relocated210, %pget.recv_class_ref.110 ], [ %rs4gc.s15.relocated242, %pget.recv_undef_return.137 ]
  %.71021 = phi ptr addrspace(1) [ %.81022, %pic.merge.128 ], [ %r48.0.relocated201, %pget.recv_sso.107 ], [ %r48.0.relocated209, %pget.recv_class_ref.110 ], [ %r48.0.relocated241, %pget.recv_undef_return.137 ]
  %.7980 = phi ptr addrspace(1) [ %.8981, %pic.merge.128 ], [ %r48.0.base.relocated200, %pget.recv_sso.107 ], [ %r48.0.base.relocated208, %pget.recv_class_ref.110 ], [ %r48.0.base.relocated240, %pget.recv_undef_return.137 ]
  %.7936 = phi ptr addrspace(1) [ %.8937, %pic.merge.128 ], [ %r57.0.relocated198, %pget.recv_sso.107 ], [ %r57.0.relocated206, %pget.recv_class_ref.110 ], [ %r57.0.relocated238, %pget.recv_undef_return.137 ]
  %.7 = phi ptr addrspace(1) [ %.8, %pic.merge.128 ], [ %rs4gc.s12.relocated199, %pget.recv_sso.107 ], [ %rs4gc.s12.relocated207, %pget.recv_class_ref.110 ], [ %rs4gc.s12.relocated239, %pget.recv_undef_return.137 ]
  %r641 = phi double [ %r628, %pic.merge.128 ], [ %r636237, %pget.recv_undef_return.137 ], [ %r640197, %pget.recv_sso.107 ], [ %r505205, %pget.recv_class_ref.110 ]
  %r643 = or i64 ptrtoint (ptr @test_json_template_capture_ts_.str.11.dispatch to i64), 9221120237041090560
  %r645 = getelementptr double, ptr %r644, i64 0
  store double 9.900000e+01, ptr %r645, align 8
  %statepoint_token212 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, i64, ptr, i64)) @js_typed_feedback_native_call_method_by_id, i32 5, i32 0, i64 6060382687846203401, double %r641, i64 %r643, ptr %r644, i64 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.7936, ptr addrspace(1) %.7, ptr addrspace(1) %.7980, ptr addrspace(1) %.71021, ptr addrspace(1) %.41059, ptr addrspace(1) %.31080) ]
  %r57.0.relocated213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 0, i32 0) ; (%.7936, %.7936)
  %rs4gc.s12.relocated214 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 1, i32 1) ; (%.7, %.7)
  %r48.0.base.relocated215 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 2, i32 2) ; (%.7980, %.7980)
  %r48.0.relocated216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 2, i32 3) ; (%.7980, %.71021)
  %rs4gc.s15.relocated217 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 4, i32 4) ; (%.41059, %.41059)
  %rs4gc.s19.relocated218 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 5, i32 5) ; (%.31080, %.31080)
  %r647.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19.relocated218 to i64
  %r647.rs4o = call i64 asm "", "=r,0"(i64 %r647.rs4i) #7
  %r647 = bitcast i64 %r647.rs4o to double
  %r648 = bitcast double %r647 to i64
  %r649 = and i64 %r648, 281474976710655
  %r650 = lshr i64 %r648, 48
  %r651 = and i64 %r650, 65533
  %r652 = icmp eq i64 %r651, 32765
  br i1 %r652, label %pget.recv_ok.139, label %pget.recv_other.143

pget.recv_other.112:                              ; preds = %tav.set.merge.92
  %r500 = icmp eq i64 %r497, 32761
  br i1 %r500, label %pget.recv_sso.107, label %pget.check_class_ref.113

pget.check_class_ref.113:                         ; preds = %pget.recv_other.112
  %r501 = icmp eq i64 %r497, 32766
  br i1 %r501, label %pget.recv_class_ref.110, label %pget.recv_bad.109

pic.hit.114:                                      ; preds = %pic.token.130
  %r531 = getelementptr i64, ptr %r516, i64 1
  %r532 = load i64, ptr %r531, align 8
  %r533 = and i64 %r532, 1073741824
  %r534 = icmp ne i64 %r533, 0
  br i1 %r534, label %pic.hit.overflow.131, label %pic.hit.inline.132

pic.hit.live.115:                                 ; preds = %pic.hit.inline.132
  br label %pic.merge.128

pic.prefix.guard.116:                             ; preds = %pic.token.130
  %r547 = getelementptr i64, ptr %r516, i64 2
  %r548 = load i64, ptr %r547, align 8
  %r549 = icmp ne i64 %r548, 0
  br i1 %r549, label %pic.prefix.meta.117, label %pic.miss.125

pic.prefix.meta.117:                              ; preds = %pic.prefix.guard.116
  %r550 = add nuw nsw i64 %r496, 8
  %r551 = inttoptr i64 %r550 to ptr
  %r552 = load i64, ptr %r551, align 8
  %r553 = icmp ne i64 %r552, 0
  br i1 %r553, label %pic.prefix.token.118, label %pic.miss.125

pic.prefix.token.118:                             ; preds = %pic.prefix.meta.117
  %r554 = inttoptr i64 %r552 to ptr
  %r555 = getelementptr i64, ptr %r554, i64 6
  %r556 = load i64, ptr %r555, align 8
  %r557 = icmp eq i64 %r556, %r548
  br i1 %r557, label %pic.prefix.hit.119, label %pic.miss.125

pic.prefix.hit.119:                               ; preds = %pic.prefix.token.118
  %r558 = getelementptr i64, ptr %r516, i64 1
  %r559 = load i64, ptr %r558, align 8
  %r560 = shl i64 %r559, 3
  %r561 = add nuw nsw i64 %r496, 16
  %r562 = add i64 %r561, %r560
  %r563 = inttoptr i64 %r562 to ptr
  %r564 = load double, ptr %r563, align 8
  br label %pic.merge.128

pic.desc.classify.120:                            ; preds = %pic.recv_hdr.129
  %r520 = and i1 %r510, %r517
  br i1 %r520, label %pic.desc.prefix.guard.121, label %pic.miss.cold.126

pic.desc.prefix.guard.121:                        ; preds = %pic.desc.classify.120
  %r565 = getelementptr i64, ptr %r516, i64 2
  %r566 = load i64, ptr %r565, align 8
  %r567 = icmp ne i64 %r566, 0
  br i1 %r567, label %pic.desc.prefix.meta.122, label %pic.miss.cold.126

pic.desc.prefix.meta.122:                         ; preds = %pic.desc.prefix.guard.121
  %r568 = add nuw nsw i64 %r496, 8
  %r569 = inttoptr i64 %r568 to ptr
  %r570 = load i64, ptr %r569, align 8
  %r571 = icmp ne i64 %r570, 0
  br i1 %r571, label %pic.desc.prefix.token.123, label %pic.miss.cold.126

pic.desc.prefix.token.123:                        ; preds = %pic.desc.prefix.meta.122
  %r572 = inttoptr i64 %r570 to ptr
  %r573 = getelementptr i64, ptr %r572, i64 6
  %r574 = load i64, ptr %r573, align 8
  %r575 = icmp eq i64 %r574, %r566
  br i1 %r575, label %pic.desc.prefix.hit.124, label %pic.miss.cold.126

pic.desc.prefix.hit.124:                          ; preds = %pic.desc.prefix.token.123
  %r576 = getelementptr i64, ptr %r516, i64 1
  %r577 = load i64, ptr %r576, align 8
  %r578 = shl i64 %r577, 3
  %r579 = add nuw nsw i64 %r496, 16
  %r580 = add i64 %r579, %r578
  %r581 = inttoptr i64 %r580 to ptr
  %r582 = load double, ptr %r581, align 8
  br label %pic.merge.128

pic.miss.125:                                     ; preds = %pic.hit.inline.132, %pic.prefix.token.118, %pic.prefix.meta.117, %pic.prefix.guard.116
  %r583 = getelementptr i64, ptr %r516, i64 3
  %r584 = load i64, ptr %r583, align 8
  %r585 = icmp sgt i64 %r584, 0
  br i1 %r585, label %pic.ways.133, label %pic.miss.call.127

pic.miss.cold.126:                                ; preds = %pic.desc.prefix.token.123, %pic.desc.prefix.meta.122, %pic.desc.prefix.guard.121, %pic.desc.classify.120, %pget.recv_ok.108
  br label %pic.miss.call.127

pic.miss.call.127:                                ; preds = %pic.way.load.134, %pic.ways.133, %pic.miss.cold.126, %pic.miss.125
  %r624 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r625 = bitcast double %r624 to i64
  %r626 = and i64 %r625, 281474976710655
  %statepoint_token219 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r496, i64 %r626, ptr @perry_ic_test_json_template_capture_ts__8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6935, ptr addrspace(1) %.6, ptr addrspace(1) %.6979, ptr addrspace(1) %.61020, ptr addrspace(1) %.31058, ptr addrspace(1) %.21079) ]
  %r627220 = call double @llvm.experimental.gc.result.f64(token %statepoint_token219)
  %r57.0.relocated221 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 0, i32 0) ; (%.6935, %.6935)
  %rs4gc.s12.relocated222 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 1, i32 1) ; (%.6, %.6)
  %r48.0.base.relocated223 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 2, i32 2) ; (%.6979, %.6979)
  %r48.0.relocated224 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 2, i32 3) ; (%.6979, %.61020)
  %rs4gc.s15.relocated225 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 4, i32 4) ; (%.31058, %.31058)
  %rs4gc.s19.relocated226 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token219, i32 5, i32 5) ; (%.21079, %.21079)
  br label %pic.merge.128

pic.merge.128:                                    ; preds = %pic.way.live.135, %pic.hit.overflow.131, %pic.miss.call.127, %pic.desc.prefix.hit.124, %pic.prefix.hit.119, %pic.hit.live.115
  %.41081 = phi ptr addrspace(1) [ %rs4gc.s19.relocated234, %pic.hit.overflow.131 ], [ %rs4gc.s19.relocated226, %pic.miss.call.127 ], [ %.21079, %pic.way.live.135 ], [ %.21079, %pic.hit.live.115 ], [ %.21079, %pic.prefix.hit.119 ], [ %.21079, %pic.desc.prefix.hit.124 ]
  %.51060 = phi ptr addrspace(1) [ %rs4gc.s15.relocated233, %pic.hit.overflow.131 ], [ %rs4gc.s15.relocated225, %pic.miss.call.127 ], [ %.31058, %pic.way.live.135 ], [ %.31058, %pic.hit.live.115 ], [ %.31058, %pic.prefix.hit.119 ], [ %.31058, %pic.desc.prefix.hit.124 ]
  %.81022 = phi ptr addrspace(1) [ %r48.0.relocated232, %pic.hit.overflow.131 ], [ %r48.0.relocated224, %pic.miss.call.127 ], [ %.61020, %pic.way.live.135 ], [ %.61020, %pic.hit.live.115 ], [ %.61020, %pic.prefix.hit.119 ], [ %.61020, %pic.desc.prefix.hit.124 ]
  %.8981 = phi ptr addrspace(1) [ %r48.0.base.relocated231, %pic.hit.overflow.131 ], [ %r48.0.base.relocated223, %pic.miss.call.127 ], [ %.6979, %pic.way.live.135 ], [ %.6979, %pic.hit.live.115 ], [ %.6979, %pic.prefix.hit.119 ], [ %.6979, %pic.desc.prefix.hit.124 ]
  %.8937 = phi ptr addrspace(1) [ %r57.0.relocated229, %pic.hit.overflow.131 ], [ %r57.0.relocated221, %pic.miss.call.127 ], [ %.6935, %pic.way.live.135 ], [ %.6935, %pic.hit.live.115 ], [ %.6935, %pic.prefix.hit.119 ], [ %.6935, %pic.desc.prefix.hit.124 ]
  %.8 = phi ptr addrspace(1) [ %rs4gc.s12.relocated230, %pic.hit.overflow.131 ], [ %rs4gc.s12.relocated222, %pic.miss.call.127 ], [ %.6, %pic.way.live.135 ], [ %.6, %pic.hit.live.115 ], [ %.6, %pic.prefix.hit.119 ], [ %.6, %pic.desc.prefix.hit.124 ]
  %r628 = phi double [ %r544, %pic.hit.live.115 ], [ %r539228, %pic.hit.overflow.131 ], [ %r564, %pic.prefix.hit.119 ], [ %r582, %pic.desc.prefix.hit.124 ], [ %r621, %pic.way.live.135 ], [ %r627220, %pic.miss.call.127 ]
  br label %pget.recv_merge.111

pic.recv_hdr.129:                                 ; preds = %pget.recv_ok.108
  %r507 = sub nuw nsw i64 %r496, 8
  %r508 = inttoptr i64 %r507 to ptr
  %r509 = load i8, ptr %r508, align 1
  %r510 = icmp eq i8 %r509, 2
  %r511 = sub nuw nsw i64 %r496, 6
  %r512 = inttoptr i64 %r511 to ptr
  %r513 = load i16, ptr %r512, align 2
  %r514 = and i16 %r513, 2048
  %r515 = icmp eq i16 %r514, 0
  %r516 = load ptr, ptr @perry_ic_test_json_template_capture_ts__8, align 8
  %r517 = icmp ne ptr %r516, null
  %r518 = and i1 %r510, %r515
  %r519 = and i1 %r518, %r517
  br i1 %r519, label %pic.token.130, label %pic.desc.classify.120

pic.token.130:                                    ; preds = %pic.recv_hdr.129
  %r521 = add nuw nsw i64 %r496, 4
  %r522 = inttoptr i64 %r521 to ptr
  %r523 = load i32, ptr %r522, align 4
  %r524 = zext i32 %r523 to i64
  %r525 = or i64 %r524, 4611686018427387904
  %r526 = icmp ne i32 %r523, 0
  %r527 = getelementptr i64, ptr %r516, i64 0
  %r528 = load i64, ptr %r527, align 8
  %r529 = icmp eq i64 %r525, %r528
  %r530 = and i1 %r529, %r526
  br i1 %r530, label %pic.hit.114, label %pic.prefix.guard.116

pic.hit.overflow.131:                             ; preds = %pic.hit.114
  %r535 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r536 = bitcast double %r535 to i64
  %r537 = and i64 %r536, 281474976710655
  %r538 = trunc i64 %r532 to i32
  %statepoint_token227 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r496, i64 %r537, i32 %r538, ptr @perry_ic_test_json_template_capture_ts__8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6935, ptr addrspace(1) %.6, ptr addrspace(1) %.6979, ptr addrspace(1) %.61020, ptr addrspace(1) %.31058, ptr addrspace(1) %.21079) ]
  %r539228 = call double @llvm.experimental.gc.result.f64(token %statepoint_token227)
  %r57.0.relocated229 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token227, i32 0, i32 0) ; (%.6935, %.6935)
  %rs4gc.s12.relocated230 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token227, i32 1, i32 1) ; (%.6, %.6)
  %r48.0.base.relocated231 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token227, i32 2, i32 2) ; (%.6979, %.6979)
  %r48.0.relocated232 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token227, i32 2, i32 3) ; (%.6979, %.61020)
  %rs4gc.s15.relocated233 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token227, i32 4, i32 4) ; (%.31058, %.31058)
  %rs4gc.s19.relocated234 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token227, i32 5, i32 5) ; (%.21079, %.21079)
  br label %pic.merge.128

pic.hit.inline.132:                               ; preds = %pic.hit.114
  %r540 = shl i64 %r532, 3
  %r541 = add nuw nsw i64 %r496, 16
  %r542 = add i64 %r541, %r540
  %r543 = inttoptr i64 %r542 to ptr
  %r544 = load double, ptr %r543, align 8
  %r545 = bitcast double %r544 to i64
  %r546 = icmp eq i64 %r545, 9222246136947933200
  br i1 %r546, label %pic.miss.125, label %pic.hit.live.115

pic.ways.133:                                     ; preds = %pic.miss.125
  %r586 = getelementptr i64, ptr %r516, i64 4
  %r587 = load i64, ptr %r586, align 8
  %r588 = icmp eq i64 %r587, %r525
  %r589 = getelementptr i64, ptr %r516, i64 5
  %r590 = load i64, ptr %r589, align 8
  %r591 = select i1 %r588, i64 %r590, i64 0
  %r592 = getelementptr i64, ptr %r516, i64 6
  %r593 = load i64, ptr %r592, align 8
  %r594 = icmp eq i64 %r593, %r525
  %r595 = getelementptr i64, ptr %r516, i64 7
  %r596 = load i64, ptr %r595, align 8
  %r597 = select i1 %r594, i64 %r596, i64 0
  %r598 = getelementptr i64, ptr %r516, i64 8
  %r599 = load i64, ptr %r598, align 8
  %r600 = icmp eq i64 %r599, %r525
  %r601 = getelementptr i64, ptr %r516, i64 9
  %r602 = load i64, ptr %r601, align 8
  %r603 = select i1 %r600, i64 %r602, i64 0
  %r604 = getelementptr i64, ptr %r516, i64 10
  %r605 = load i64, ptr %r604, align 8
  %r606 = icmp eq i64 %r605, %r525
  %r607 = getelementptr i64, ptr %r516, i64 11
  %r608 = load i64, ptr %r607, align 8
  %r609 = select i1 %r606, i64 %r608, i64 0
  %r610 = or i1 %r588, %r594
  %r611 = select i1 %r588, i64 %r591, i64 %r597
  %r612 = or i1 %r600, %r606
  %r613 = select i1 %r600, i64 %r603, i64 %r609
  %r614 = or i1 %r610, %r612
  %r615 = select i1 %r610, i64 %r611, i64 %r613
  %r616 = and i1 %r526, %r614
  br i1 %r616, label %pic.way.load.134, label %pic.miss.call.127

pic.way.load.134:                                 ; preds = %pic.ways.133
  %r617 = shl i64 %r615, 3
  %r618 = add nuw nsw i64 %r496, 16
  %r619 = add i64 %r618, %r617
  %r620 = inttoptr i64 %r619 to ptr
  %r621 = load double, ptr %r620, align 8
  %r622 = bitcast double %r621 to i64
  %r623 = icmp eq i64 %r622, 9222246136947933200
  br i1 %r623, label %pic.miss.call.127, label %pic.way.live.135

pic.way.live.135:                                 ; preds = %pic.way.load.134
  br label %pic.merge.128

pget.throw_nullish.136:                           ; preds = %pget.recv_bad.109
  %r632 = zext i1 %r630 to i32
  %statepoint_token235 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r632, ptr @test_json_template_capture_ts_.str.9.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.137:                       ; preds = %pget.recv_bad.109
  %r633 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r634 = bitcast double %r633 to i64
  %r635 = and i64 %r634, 281474976710655
  %statepoint_token236 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r495, i64 %r635, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6935, ptr addrspace(1) %.6, ptr addrspace(1) %.6979, ptr addrspace(1) %.61020, ptr addrspace(1) %.31058, ptr addrspace(1) %.21079) ]
  %r636237 = call double @llvm.experimental.gc.result.f64(token %statepoint_token236)
  %r57.0.relocated238 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 0, i32 0) ; (%.6935, %.6935)
  %rs4gc.s12.relocated239 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 1, i32 1) ; (%.6, %.6)
  %r48.0.base.relocated240 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 2, i32 2) ; (%.6979, %.6979)
  %r48.0.relocated241 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 2, i32 3) ; (%.6979, %.61020)
  %rs4gc.s15.relocated242 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 4, i32 4) ; (%.31058, %.31058)
  %rs4gc.s19.relocated243 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 5, i32 5) ; (%.21079, %.21079)
  br label %pget.recv_merge.111

pget.recv_sso.138:                                ; preds = %pget.recv_other.143
  %r790 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r791 = bitcast double %r790 to i64
  %r792 = and i64 %r791, 281474976710655
  %statepoint_token244 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r648, i64 %r792, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated213, ptr addrspace(1) %rs4gc.s12.relocated214, ptr addrspace(1) %r48.0.base.relocated215, ptr addrspace(1) %r48.0.relocated216, ptr addrspace(1) %rs4gc.s15.relocated217, ptr addrspace(1) %rs4gc.s19.relocated218) ]
  %r793245 = call double @llvm.experimental.gc.result.f64(token %statepoint_token244)
  %r57.0.relocated246 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 0, i32 0) ; (%r57.0.relocated213, %r57.0.relocated213)
  %rs4gc.s12.relocated247 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 1, i32 1) ; (%rs4gc.s12.relocated214, %rs4gc.s12.relocated214)
  %r48.0.base.relocated248 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 2, i32 2) ; (%r48.0.base.relocated215, %r48.0.base.relocated215)
  %r48.0.relocated249 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 2, i32 3) ; (%r48.0.base.relocated215, %r48.0.relocated216)
  %rs4gc.s15.relocated250 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 4, i32 4) ; (%rs4gc.s15.relocated217, %rs4gc.s15.relocated217)
  %rs4gc.s19.relocated251 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 5, i32 5) ; (%rs4gc.s19.relocated218, %rs4gc.s19.relocated218)
  br label %pget.recv_merge.142

pget.recv_ok.139:                                 ; preds = %pget.recv_merge.111
  %r659 = icmp ugt i64 %r649, 1048575
  br i1 %r659, label %pic.recv_hdr.160, label %pic.miss.cold.157

pget.recv_bad.140:                                ; preds = %pget.check_class_ref.144
  %r782 = icmp eq i64 %r648, 9222246136947933185
  %r783 = icmp eq i64 %r648, 9222246136947933186
  %r784 = or i1 %r782, %r783
  br i1 %r784, label %pget.throw_nullish.167, label %pget.recv_undef_return.168

pget.recv_class_ref.141:                          ; preds = %pget.check_class_ref.144
  %r655 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r656 = bitcast double %r655 to i64
  %r657 = and i64 %r656, 281474976710655
  %statepoint_token252 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6060382687846203402, i64 %r648, i64 %r657, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated213, ptr addrspace(1) %rs4gc.s12.relocated214, ptr addrspace(1) %r48.0.base.relocated215, ptr addrspace(1) %r48.0.relocated216, ptr addrspace(1) %rs4gc.s15.relocated217, ptr addrspace(1) %rs4gc.s19.relocated218) ]
  %r658253 = call double @llvm.experimental.gc.result.f64(token %statepoint_token252)
  %r57.0.relocated254 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 0, i32 0) ; (%r57.0.relocated213, %r57.0.relocated213)
  %rs4gc.s12.relocated255 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 1, i32 1) ; (%rs4gc.s12.relocated214, %rs4gc.s12.relocated214)
  %r48.0.base.relocated256 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 2, i32 2) ; (%r48.0.base.relocated215, %r48.0.base.relocated215)
  %r48.0.relocated257 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 2, i32 3) ; (%r48.0.base.relocated215, %r48.0.relocated216)
  %rs4gc.s15.relocated258 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 4, i32 4) ; (%rs4gc.s15.relocated217, %rs4gc.s15.relocated217)
  %rs4gc.s19.relocated259 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 5, i32 5) ; (%rs4gc.s19.relocated218, %rs4gc.s19.relocated218)
  br label %pget.recv_merge.142

pget.recv_merge.142:                              ; preds = %pget.recv_undef_return.168, %pic.merge.159, %pget.recv_class_ref.141, %pget.recv_sso.138
  %.51082 = phi ptr addrspace(1) [ %.61083, %pic.merge.159 ], [ %rs4gc.s19.relocated251, %pget.recv_sso.138 ], [ %rs4gc.s19.relocated259, %pget.recv_class_ref.141 ], [ %rs4gc.s19.relocated284, %pget.recv_undef_return.168 ]
  %.61061 = phi ptr addrspace(1) [ %.71062, %pic.merge.159 ], [ %rs4gc.s15.relocated250, %pget.recv_sso.138 ], [ %rs4gc.s15.relocated258, %pget.recv_class_ref.141 ], [ %rs4gc.s15.relocated283, %pget.recv_undef_return.168 ]
  %.91023 = phi ptr addrspace(1) [ %.101024, %pic.merge.159 ], [ %r48.0.relocated249, %pget.recv_sso.138 ], [ %r48.0.relocated257, %pget.recv_class_ref.141 ], [ %r48.0.relocated282, %pget.recv_undef_return.168 ]
  %.9982 = phi ptr addrspace(1) [ %.10983, %pic.merge.159 ], [ %r48.0.base.relocated248, %pget.recv_sso.138 ], [ %r48.0.base.relocated256, %pget.recv_class_ref.141 ], [ %r48.0.base.relocated281, %pget.recv_undef_return.168 ]
  %.9938 = phi ptr addrspace(1) [ %.10939, %pic.merge.159 ], [ %r57.0.relocated246, %pget.recv_sso.138 ], [ %r57.0.relocated254, %pget.recv_class_ref.141 ], [ %r57.0.relocated279, %pget.recv_undef_return.168 ]
  %.9 = phi ptr addrspace(1) [ %.10, %pic.merge.159 ], [ %rs4gc.s12.relocated247, %pget.recv_sso.138 ], [ %rs4gc.s12.relocated255, %pget.recv_class_ref.141 ], [ %rs4gc.s12.relocated280, %pget.recv_undef_return.168 ]
  %r794 = phi double [ %r781, %pic.merge.159 ], [ %r789278, %pget.recv_undef_return.168 ], [ %r793245, %pget.recv_sso.138 ], [ %r658253, %pget.recv_class_ref.141 ]
  %r795 = bitcast double %r794 to i64
  %r796 = and i64 %r795, 281474976710655
  %r797 = lshr i64 %r795, 48
  %r798 = and i64 %r797, 65533
  %r799 = icmp eq i64 %r798, 32765
  br i1 %r799, label %pget.recv_ok.170, label %pget.recv_other.175

pget.recv_other.143:                              ; preds = %pget.recv_merge.111
  %r653 = icmp eq i64 %r650, 32761
  br i1 %r653, label %pget.recv_sso.138, label %pget.check_class_ref.144

pget.check_class_ref.144:                         ; preds = %pget.recv_other.143
  %r654 = icmp eq i64 %r650, 32766
  br i1 %r654, label %pget.recv_class_ref.141, label %pget.recv_bad.140

pic.hit.145:                                      ; preds = %pic.token.161
  %r684 = getelementptr i64, ptr %r669, i64 1
  %r685 = load i64, ptr %r684, align 8
  %r686 = and i64 %r685, 1073741824
  %r687 = icmp ne i64 %r686, 0
  br i1 %r687, label %pic.hit.overflow.162, label %pic.hit.inline.163

pic.hit.live.146:                                 ; preds = %pic.hit.inline.163
  br label %pic.merge.159

pic.prefix.guard.147:                             ; preds = %pic.token.161
  %r700 = getelementptr i64, ptr %r669, i64 2
  %r701 = load i64, ptr %r700, align 8
  %r702 = icmp ne i64 %r701, 0
  br i1 %r702, label %pic.prefix.meta.148, label %pic.miss.156

pic.prefix.meta.148:                              ; preds = %pic.prefix.guard.147
  %r703 = add nuw nsw i64 %r649, 8
  %r704 = inttoptr i64 %r703 to ptr
  %r705 = load i64, ptr %r704, align 8
  %r706 = icmp ne i64 %r705, 0
  br i1 %r706, label %pic.prefix.token.149, label %pic.miss.156

pic.prefix.token.149:                             ; preds = %pic.prefix.meta.148
  %r707 = inttoptr i64 %r705 to ptr
  %r708 = getelementptr i64, ptr %r707, i64 6
  %r709 = load i64, ptr %r708, align 8
  %r710 = icmp eq i64 %r709, %r701
  br i1 %r710, label %pic.prefix.hit.150, label %pic.miss.156

pic.prefix.hit.150:                               ; preds = %pic.prefix.token.149
  %r711 = getelementptr i64, ptr %r669, i64 1
  %r712 = load i64, ptr %r711, align 8
  %r713 = shl i64 %r712, 3
  %r714 = add nuw nsw i64 %r649, 16
  %r715 = add i64 %r714, %r713
  %r716 = inttoptr i64 %r715 to ptr
  %r717 = load double, ptr %r716, align 8
  br label %pic.merge.159

pic.desc.classify.151:                            ; preds = %pic.recv_hdr.160
  %r673 = and i1 %r663, %r670
  br i1 %r673, label %pic.desc.prefix.guard.152, label %pic.miss.cold.157

pic.desc.prefix.guard.152:                        ; preds = %pic.desc.classify.151
  %r718 = getelementptr i64, ptr %r669, i64 2
  %r719 = load i64, ptr %r718, align 8
  %r720 = icmp ne i64 %r719, 0
  br i1 %r720, label %pic.desc.prefix.meta.153, label %pic.miss.cold.157

pic.desc.prefix.meta.153:                         ; preds = %pic.desc.prefix.guard.152
  %r721 = add nuw nsw i64 %r649, 8
  %r722 = inttoptr i64 %r721 to ptr
  %r723 = load i64, ptr %r722, align 8
  %r724 = icmp ne i64 %r723, 0
  br i1 %r724, label %pic.desc.prefix.token.154, label %pic.miss.cold.157

pic.desc.prefix.token.154:                        ; preds = %pic.desc.prefix.meta.153
  %r725 = inttoptr i64 %r723 to ptr
  %r726 = getelementptr i64, ptr %r725, i64 6
  %r727 = load i64, ptr %r726, align 8
  %r728 = icmp eq i64 %r727, %r719
  br i1 %r728, label %pic.desc.prefix.hit.155, label %pic.miss.cold.157

pic.desc.prefix.hit.155:                          ; preds = %pic.desc.prefix.token.154
  %r729 = getelementptr i64, ptr %r669, i64 1
  %r730 = load i64, ptr %r729, align 8
  %r731 = shl i64 %r730, 3
  %r732 = add nuw nsw i64 %r649, 16
  %r733 = add i64 %r732, %r731
  %r734 = inttoptr i64 %r733 to ptr
  %r735 = load double, ptr %r734, align 8
  br label %pic.merge.159

pic.miss.156:                                     ; preds = %pic.hit.inline.163, %pic.prefix.token.149, %pic.prefix.meta.148, %pic.prefix.guard.147
  %r736 = getelementptr i64, ptr %r669, i64 3
  %r737 = load i64, ptr %r736, align 8
  %r738 = icmp sgt i64 %r737, 0
  br i1 %r738, label %pic.ways.164, label %pic.miss.call.158

pic.miss.cold.157:                                ; preds = %pic.desc.prefix.token.154, %pic.desc.prefix.meta.153, %pic.desc.prefix.guard.152, %pic.desc.classify.151, %pget.recv_ok.139
  br label %pic.miss.call.158

pic.miss.call.158:                                ; preds = %pic.way.load.165, %pic.ways.164, %pic.miss.cold.157, %pic.miss.156
  %r777 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r778 = bitcast double %r777 to i64
  %r779 = and i64 %r778, 281474976710655
  %statepoint_token260 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r649, i64 %r779, ptr @perry_ic_test_json_template_capture_ts__11, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated213, ptr addrspace(1) %rs4gc.s12.relocated214, ptr addrspace(1) %r48.0.base.relocated215, ptr addrspace(1) %r48.0.relocated216, ptr addrspace(1) %rs4gc.s15.relocated217, ptr addrspace(1) %rs4gc.s19.relocated218) ]
  %r780261 = call double @llvm.experimental.gc.result.f64(token %statepoint_token260)
  %r57.0.relocated262 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 0, i32 0) ; (%r57.0.relocated213, %r57.0.relocated213)
  %rs4gc.s12.relocated263 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 1, i32 1) ; (%rs4gc.s12.relocated214, %rs4gc.s12.relocated214)
  %r48.0.base.relocated264 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 2, i32 2) ; (%r48.0.base.relocated215, %r48.0.base.relocated215)
  %r48.0.relocated265 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 2, i32 3) ; (%r48.0.base.relocated215, %r48.0.relocated216)
  %rs4gc.s15.relocated266 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 4, i32 4) ; (%rs4gc.s15.relocated217, %rs4gc.s15.relocated217)
  %rs4gc.s19.relocated267 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 5, i32 5) ; (%rs4gc.s19.relocated218, %rs4gc.s19.relocated218)
  br label %pic.merge.159

pic.merge.159:                                    ; preds = %pic.way.live.166, %pic.hit.overflow.162, %pic.miss.call.158, %pic.desc.prefix.hit.155, %pic.prefix.hit.150, %pic.hit.live.146
  %.61083 = phi ptr addrspace(1) [ %rs4gc.s19.relocated275, %pic.hit.overflow.162 ], [ %rs4gc.s19.relocated267, %pic.miss.call.158 ], [ %rs4gc.s19.relocated218, %pic.way.live.166 ], [ %rs4gc.s19.relocated218, %pic.hit.live.146 ], [ %rs4gc.s19.relocated218, %pic.prefix.hit.150 ], [ %rs4gc.s19.relocated218, %pic.desc.prefix.hit.155 ]
  %.71062 = phi ptr addrspace(1) [ %rs4gc.s15.relocated274, %pic.hit.overflow.162 ], [ %rs4gc.s15.relocated266, %pic.miss.call.158 ], [ %rs4gc.s15.relocated217, %pic.way.live.166 ], [ %rs4gc.s15.relocated217, %pic.hit.live.146 ], [ %rs4gc.s15.relocated217, %pic.prefix.hit.150 ], [ %rs4gc.s15.relocated217, %pic.desc.prefix.hit.155 ]
  %.101024 = phi ptr addrspace(1) [ %r48.0.relocated273, %pic.hit.overflow.162 ], [ %r48.0.relocated265, %pic.miss.call.158 ], [ %r48.0.relocated216, %pic.way.live.166 ], [ %r48.0.relocated216, %pic.hit.live.146 ], [ %r48.0.relocated216, %pic.prefix.hit.150 ], [ %r48.0.relocated216, %pic.desc.prefix.hit.155 ]
  %.10983 = phi ptr addrspace(1) [ %r48.0.base.relocated272, %pic.hit.overflow.162 ], [ %r48.0.base.relocated264, %pic.miss.call.158 ], [ %r48.0.base.relocated215, %pic.way.live.166 ], [ %r48.0.base.relocated215, %pic.hit.live.146 ], [ %r48.0.base.relocated215, %pic.prefix.hit.150 ], [ %r48.0.base.relocated215, %pic.desc.prefix.hit.155 ]
  %.10939 = phi ptr addrspace(1) [ %r57.0.relocated270, %pic.hit.overflow.162 ], [ %r57.0.relocated262, %pic.miss.call.158 ], [ %r57.0.relocated213, %pic.way.live.166 ], [ %r57.0.relocated213, %pic.hit.live.146 ], [ %r57.0.relocated213, %pic.prefix.hit.150 ], [ %r57.0.relocated213, %pic.desc.prefix.hit.155 ]
  %.10 = phi ptr addrspace(1) [ %rs4gc.s12.relocated271, %pic.hit.overflow.162 ], [ %rs4gc.s12.relocated263, %pic.miss.call.158 ], [ %rs4gc.s12.relocated214, %pic.way.live.166 ], [ %rs4gc.s12.relocated214, %pic.hit.live.146 ], [ %rs4gc.s12.relocated214, %pic.prefix.hit.150 ], [ %rs4gc.s12.relocated214, %pic.desc.prefix.hit.155 ]
  %r781 = phi double [ %r697, %pic.hit.live.146 ], [ %r692269, %pic.hit.overflow.162 ], [ %r717, %pic.prefix.hit.150 ], [ %r735, %pic.desc.prefix.hit.155 ], [ %r774, %pic.way.live.166 ], [ %r780261, %pic.miss.call.158 ]
  br label %pget.recv_merge.142

pic.recv_hdr.160:                                 ; preds = %pget.recv_ok.139
  %r660 = sub nuw nsw i64 %r649, 8
  %r661 = inttoptr i64 %r660 to ptr
  %r662 = load i8, ptr %r661, align 1
  %r663 = icmp eq i8 %r662, 2
  %r664 = sub nuw nsw i64 %r649, 6
  %r665 = inttoptr i64 %r664 to ptr
  %r666 = load i16, ptr %r665, align 2
  %r667 = and i16 %r666, 2048
  %r668 = icmp eq i16 %r667, 0
  %r669 = load ptr, ptr @perry_ic_test_json_template_capture_ts__11, align 8
  %r670 = icmp ne ptr %r669, null
  %r671 = and i1 %r663, %r668
  %r672 = and i1 %r671, %r670
  br i1 %r672, label %pic.token.161, label %pic.desc.classify.151

pic.token.161:                                    ; preds = %pic.recv_hdr.160
  %r674 = add nuw nsw i64 %r649, 4
  %r675 = inttoptr i64 %r674 to ptr
  %r676 = load i32, ptr %r675, align 4
  %r677 = zext i32 %r676 to i64
  %r678 = or i64 %r677, 4611686018427387904
  %r679 = icmp ne i32 %r676, 0
  %r680 = getelementptr i64, ptr %r669, i64 0
  %r681 = load i64, ptr %r680, align 8
  %r682 = icmp eq i64 %r678, %r681
  %r683 = and i1 %r682, %r679
  br i1 %r683, label %pic.hit.145, label %pic.prefix.guard.147

pic.hit.overflow.162:                             ; preds = %pic.hit.145
  %r688 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r689 = bitcast double %r688 to i64
  %r690 = and i64 %r689, 281474976710655
  %r691 = trunc i64 %r685 to i32
  %statepoint_token268 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r649, i64 %r690, i32 %r691, ptr @perry_ic_test_json_template_capture_ts__11, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated213, ptr addrspace(1) %rs4gc.s12.relocated214, ptr addrspace(1) %r48.0.base.relocated215, ptr addrspace(1) %r48.0.relocated216, ptr addrspace(1) %rs4gc.s15.relocated217, ptr addrspace(1) %rs4gc.s19.relocated218) ]
  %r692269 = call double @llvm.experimental.gc.result.f64(token %statepoint_token268)
  %r57.0.relocated270 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 0, i32 0) ; (%r57.0.relocated213, %r57.0.relocated213)
  %rs4gc.s12.relocated271 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 1, i32 1) ; (%rs4gc.s12.relocated214, %rs4gc.s12.relocated214)
  %r48.0.base.relocated272 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 2, i32 2) ; (%r48.0.base.relocated215, %r48.0.base.relocated215)
  %r48.0.relocated273 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 2, i32 3) ; (%r48.0.base.relocated215, %r48.0.relocated216)
  %rs4gc.s15.relocated274 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 4, i32 4) ; (%rs4gc.s15.relocated217, %rs4gc.s15.relocated217)
  %rs4gc.s19.relocated275 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 5, i32 5) ; (%rs4gc.s19.relocated218, %rs4gc.s19.relocated218)
  br label %pic.merge.159

pic.hit.inline.163:                               ; preds = %pic.hit.145
  %r693 = shl i64 %r685, 3
  %r694 = add nuw nsw i64 %r649, 16
  %r695 = add i64 %r694, %r693
  %r696 = inttoptr i64 %r695 to ptr
  %r697 = load double, ptr %r696, align 8
  %r698 = bitcast double %r697 to i64
  %r699 = icmp eq i64 %r698, 9222246136947933200
  br i1 %r699, label %pic.miss.156, label %pic.hit.live.146

pic.ways.164:                                     ; preds = %pic.miss.156
  %r739 = getelementptr i64, ptr %r669, i64 4
  %r740 = load i64, ptr %r739, align 8
  %r741 = icmp eq i64 %r740, %r678
  %r742 = getelementptr i64, ptr %r669, i64 5
  %r743 = load i64, ptr %r742, align 8
  %r744 = select i1 %r741, i64 %r743, i64 0
  %r745 = getelementptr i64, ptr %r669, i64 6
  %r746 = load i64, ptr %r745, align 8
  %r747 = icmp eq i64 %r746, %r678
  %r748 = getelementptr i64, ptr %r669, i64 7
  %r749 = load i64, ptr %r748, align 8
  %r750 = select i1 %r747, i64 %r749, i64 0
  %r751 = getelementptr i64, ptr %r669, i64 8
  %r752 = load i64, ptr %r751, align 8
  %r753 = icmp eq i64 %r752, %r678
  %r754 = getelementptr i64, ptr %r669, i64 9
  %r755 = load i64, ptr %r754, align 8
  %r756 = select i1 %r753, i64 %r755, i64 0
  %r757 = getelementptr i64, ptr %r669, i64 10
  %r758 = load i64, ptr %r757, align 8
  %r759 = icmp eq i64 %r758, %r678
  %r760 = getelementptr i64, ptr %r669, i64 11
  %r761 = load i64, ptr %r760, align 8
  %r762 = select i1 %r759, i64 %r761, i64 0
  %r763 = or i1 %r741, %r747
  %r764 = select i1 %r741, i64 %r744, i64 %r750
  %r765 = or i1 %r753, %r759
  %r766 = select i1 %r753, i64 %r756, i64 %r762
  %r767 = or i1 %r763, %r765
  %r768 = select i1 %r763, i64 %r764, i64 %r766
  %r769 = and i1 %r679, %r767
  br i1 %r769, label %pic.way.load.165, label %pic.miss.call.158

pic.way.load.165:                                 ; preds = %pic.ways.164
  %r770 = shl i64 %r768, 3
  %r771 = add nuw nsw i64 %r649, 16
  %r772 = add i64 %r771, %r770
  %r773 = inttoptr i64 %r772 to ptr
  %r774 = load double, ptr %r773, align 8
  %r775 = bitcast double %r774 to i64
  %r776 = icmp eq i64 %r775, 9222246136947933200
  br i1 %r776, label %pic.miss.call.158, label %pic.way.live.166

pic.way.live.166:                                 ; preds = %pic.way.load.165
  br label %pic.merge.159

pget.throw_nullish.167:                           ; preds = %pget.recv_bad.140
  %r785 = zext i1 %r783 to i32
  %statepoint_token276 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r785, ptr @test_json_template_capture_ts_.str.9.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.168:                       ; preds = %pget.recv_bad.140
  %r786 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r787 = bitcast double %r786 to i64
  %r788 = and i64 %r787, 281474976710655
  %statepoint_token277 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r648, i64 %r788, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated213, ptr addrspace(1) %rs4gc.s12.relocated214, ptr addrspace(1) %r48.0.base.relocated215, ptr addrspace(1) %r48.0.relocated216, ptr addrspace(1) %rs4gc.s15.relocated217, ptr addrspace(1) %rs4gc.s19.relocated218) ]
  %r789278 = call double @llvm.experimental.gc.result.f64(token %statepoint_token277)
  %r57.0.relocated279 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 0, i32 0) ; (%r57.0.relocated213, %r57.0.relocated213)
  %rs4gc.s12.relocated280 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 1, i32 1) ; (%rs4gc.s12.relocated214, %rs4gc.s12.relocated214)
  %r48.0.base.relocated281 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 2, i32 2) ; (%r48.0.base.relocated215, %r48.0.base.relocated215)
  %r48.0.relocated282 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 2, i32 3) ; (%r48.0.base.relocated215, %r48.0.relocated216)
  %rs4gc.s15.relocated283 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 4, i32 4) ; (%rs4gc.s15.relocated217, %rs4gc.s15.relocated217)
  %rs4gc.s19.relocated284 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 5, i32 5) ; (%rs4gc.s19.relocated218, %rs4gc.s19.relocated218)
  br label %pget.recv_merge.142

pget.recv_sso.169:                                ; preds = %pget.recv_other.175
  %r938 = lshr i64 %r795, 40
  %r939 = and i64 %r938, 255
  %r940 = uitofp nneg i64 %r939 to double
  br label %pget.recv_merge.173

pget.recv_ok.170:                                 ; preds = %pget.recv_merge.142
  %r806 = icmp eq i64 %r797, 32767
  br i1 %r806, label %pget.strlen_heap.174, label %pget.recv_obj.177

pget.recv_bad.171:                                ; preds = %pget.check_class_ref.176
  %r930 = icmp eq i64 %r795, 9222246136947933185
  %r931 = icmp eq i64 %r795, 9222246136947933186
  %r932 = or i1 %r930, %r931
  br i1 %r932, label %pget.throw_nullish.200, label %pget.recv_undef_return.201

pget.recv_class_ref.172:                          ; preds = %pget.check_class_ref.176
  %r802 = load double, ptr @test_json_template_capture_ts_.str.12.handle, align 8
  %r803 = bitcast double %r802 to i64
  %r804 = and i64 %r803, 281474976710655
  %statepoint_token285 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6060382687846203404, i64 %r795, i64 %r804, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9938, ptr addrspace(1) %.9, ptr addrspace(1) %.9982, ptr addrspace(1) %.91023, ptr addrspace(1) %.61061, ptr addrspace(1) %.51082) ]
  %r805286 = call double @llvm.experimental.gc.result.f64(token %statepoint_token285)
  %r57.0.relocated287 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token285, i32 0, i32 0) ; (%.9938, %.9938)
  %rs4gc.s12.relocated288 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token285, i32 1, i32 1) ; (%.9, %.9)
  %r48.0.base.relocated289 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token285, i32 2, i32 2) ; (%.9982, %.9982)
  %r48.0.relocated290 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token285, i32 2, i32 3) ; (%.9982, %.91023)
  %rs4gc.s15.relocated291 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token285, i32 4, i32 4) ; (%.61061, %.61061)
  %rs4gc.s19.relocated292 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token285, i32 5, i32 5) ; (%.51082, %.51082)
  br label %pget.recv_merge.173

pget.recv_merge.173:                              ; preds = %pget.recv_undef_return.201, %pic.merge.192, %pget.strlen_heap.174, %pget.recv_class_ref.172, %pget.recv_sso.169
  %.71084 = phi ptr addrspace(1) [ %.51082, %pget.strlen_heap.174 ], [ %.81085, %pic.merge.192 ], [ %.51082, %pget.recv_sso.169 ], [ %rs4gc.s19.relocated292, %pget.recv_class_ref.172 ], [ %rs4gc.s19.relocated317, %pget.recv_undef_return.201 ]
  %.81063 = phi ptr addrspace(1) [ %.61061, %pget.strlen_heap.174 ], [ %.91064, %pic.merge.192 ], [ %.61061, %pget.recv_sso.169 ], [ %rs4gc.s15.relocated291, %pget.recv_class_ref.172 ], [ %rs4gc.s15.relocated316, %pget.recv_undef_return.201 ]
  %.111025 = phi ptr addrspace(1) [ %.91023, %pget.strlen_heap.174 ], [ %.121026, %pic.merge.192 ], [ %.91023, %pget.recv_sso.169 ], [ %r48.0.relocated290, %pget.recv_class_ref.172 ], [ %r48.0.relocated315, %pget.recv_undef_return.201 ]
  %.11984 = phi ptr addrspace(1) [ %.9982, %pget.strlen_heap.174 ], [ %.12985, %pic.merge.192 ], [ %.9982, %pget.recv_sso.169 ], [ %r48.0.base.relocated289, %pget.recv_class_ref.172 ], [ %r48.0.base.relocated314, %pget.recv_undef_return.201 ]
  %.11940 = phi ptr addrspace(1) [ %.9938, %pget.strlen_heap.174 ], [ %.12941, %pic.merge.192 ], [ %.9938, %pget.recv_sso.169 ], [ %r57.0.relocated287, %pget.recv_class_ref.172 ], [ %r57.0.relocated312, %pget.recv_undef_return.201 ]
  %.11 = phi ptr addrspace(1) [ %.9, %pget.strlen_heap.174 ], [ %.12, %pic.merge.192 ], [ %.9, %pget.recv_sso.169 ], [ %rs4gc.s12.relocated288, %pget.recv_class_ref.172 ], [ %rs4gc.s12.relocated313, %pget.recv_undef_return.201 ]
  %r946 = phi double [ %r929, %pic.merge.192 ], [ %r937311, %pget.recv_undef_return.201 ], [ %r940, %pget.recv_sso.169 ], [ %r805286, %pget.recv_class_ref.172 ], [ %r945, %pget.strlen_heap.174 ]
  %r947 = bitcast double %r946 to i64
  %r948 = lshr i64 %r947, 48
  %r949 = icmp eq i64 %r948, 32766
  %r950 = trunc i64 %r947 to i32
  %r951 = sitofp i32 %r950 to double
  %r952 = select i1 %r949, double %r951, double %r946
  %r959 = fcmp une double %r952, 3.000000e+00
  %r960 = select i1 %r959, i64 9222246136947933188, i64 9222246136947933187
  %r961 = bitcast i64 %r960 to double
  %r962 = icmp eq i64 %r960, 9222246136947933188
  br i1 %r962, label %logical.merge.203, label %logical.then.202

pget.strlen_heap.174:                             ; preds = %pget.recv_ok.170
  %r941 = icmp ult i64 %r796, 4096
  %r942 = inttoptr i64 %r796 to ptr
  %r943 = select i1 %r941, ptr @perry_null_guard_zero_test_json_template_capture_ts, ptr %r942
  %r944 = load i32, ptr %r943, align 4
  %r945 = uitofp i32 %r944 to double
  br label %pget.recv_merge.173

pget.recv_other.175:                              ; preds = %pget.recv_merge.142
  %r800 = icmp eq i64 %r797, 32761
  br i1 %r800, label %pget.recv_sso.169, label %pget.check_class_ref.176

pget.check_class_ref.176:                         ; preds = %pget.recv_other.175
  %r801 = icmp eq i64 %r797, 32766
  br i1 %r801, label %pget.recv_class_ref.172, label %pget.recv_bad.171

pget.recv_obj.177:                                ; preds = %pget.recv_ok.170
  %r807 = icmp ugt i64 %r796, 1048575
  br i1 %r807, label %pic.recv_hdr.193, label %pic.miss.cold.190

pic.hit.178:                                      ; preds = %pic.token.194
  %r832 = getelementptr i64, ptr %r817, i64 1
  %r833 = load i64, ptr %r832, align 8
  %r834 = and i64 %r833, 1073741824
  %r835 = icmp ne i64 %r834, 0
  br i1 %r835, label %pic.hit.overflow.195, label %pic.hit.inline.196

pic.hit.live.179:                                 ; preds = %pic.hit.inline.196
  br label %pic.merge.192

pic.prefix.guard.180:                             ; preds = %pic.token.194
  %r848 = getelementptr i64, ptr %r817, i64 2
  %r849 = load i64, ptr %r848, align 8
  %r850 = icmp ne i64 %r849, 0
  br i1 %r850, label %pic.prefix.meta.181, label %pic.miss.189

pic.prefix.meta.181:                              ; preds = %pic.prefix.guard.180
  %r851 = add nuw nsw i64 %r796, 8
  %r852 = inttoptr i64 %r851 to ptr
  %r853 = load i64, ptr %r852, align 8
  %r854 = icmp ne i64 %r853, 0
  br i1 %r854, label %pic.prefix.token.182, label %pic.miss.189

pic.prefix.token.182:                             ; preds = %pic.prefix.meta.181
  %r855 = inttoptr i64 %r853 to ptr
  %r856 = getelementptr i64, ptr %r855, i64 6
  %r857 = load i64, ptr %r856, align 8
  %r858 = icmp eq i64 %r857, %r849
  br i1 %r858, label %pic.prefix.hit.183, label %pic.miss.189

pic.prefix.hit.183:                               ; preds = %pic.prefix.token.182
  %r859 = getelementptr i64, ptr %r817, i64 1
  %r860 = load i64, ptr %r859, align 8
  %r861 = shl i64 %r860, 3
  %r862 = add nuw nsw i64 %r796, 16
  %r863 = add i64 %r862, %r861
  %r864 = inttoptr i64 %r863 to ptr
  %r865 = load double, ptr %r864, align 8
  br label %pic.merge.192

pic.desc.classify.184:                            ; preds = %pic.recv_hdr.193
  %r821 = and i1 %r811, %r818
  br i1 %r821, label %pic.desc.prefix.guard.185, label %pic.miss.cold.190

pic.desc.prefix.guard.185:                        ; preds = %pic.desc.classify.184
  %r866 = getelementptr i64, ptr %r817, i64 2
  %r867 = load i64, ptr %r866, align 8
  %r868 = icmp ne i64 %r867, 0
  br i1 %r868, label %pic.desc.prefix.meta.186, label %pic.miss.cold.190

pic.desc.prefix.meta.186:                         ; preds = %pic.desc.prefix.guard.185
  %r869 = add nuw nsw i64 %r796, 8
  %r870 = inttoptr i64 %r869 to ptr
  %r871 = load i64, ptr %r870, align 8
  %r872 = icmp ne i64 %r871, 0
  br i1 %r872, label %pic.desc.prefix.token.187, label %pic.miss.cold.190

pic.desc.prefix.token.187:                        ; preds = %pic.desc.prefix.meta.186
  %r873 = inttoptr i64 %r871 to ptr
  %r874 = getelementptr i64, ptr %r873, i64 6
  %r875 = load i64, ptr %r874, align 8
  %r876 = icmp eq i64 %r875, %r867
  br i1 %r876, label %pic.desc.prefix.hit.188, label %pic.miss.cold.190

pic.desc.prefix.hit.188:                          ; preds = %pic.desc.prefix.token.187
  %r877 = getelementptr i64, ptr %r817, i64 1
  %r878 = load i64, ptr %r877, align 8
  %r879 = shl i64 %r878, 3
  %r880 = add nuw nsw i64 %r796, 16
  %r881 = add i64 %r880, %r879
  %r882 = inttoptr i64 %r881 to ptr
  %r883 = load double, ptr %r882, align 8
  br label %pic.merge.192

pic.miss.189:                                     ; preds = %pic.hit.inline.196, %pic.prefix.token.182, %pic.prefix.meta.181, %pic.prefix.guard.180
  %r884 = getelementptr i64, ptr %r817, i64 3
  %r885 = load i64, ptr %r884, align 8
  %r886 = icmp sgt i64 %r885, 0
  br i1 %r886, label %pic.ways.197, label %pic.miss.call.191

pic.miss.cold.190:                                ; preds = %pic.desc.prefix.token.187, %pic.desc.prefix.meta.186, %pic.desc.prefix.guard.185, %pic.desc.classify.184, %pget.recv_obj.177
  br label %pic.miss.call.191

pic.miss.call.191:                                ; preds = %pic.way.load.198, %pic.ways.197, %pic.miss.cold.190, %pic.miss.189
  %r925 = load double, ptr @test_json_template_capture_ts_.str.12.handle, align 8
  %r926 = bitcast double %r925 to i64
  %r927 = and i64 %r926, 281474976710655
  %statepoint_token293 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r796, i64 %r927, ptr @perry_ic_test_json_template_capture_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9938, ptr addrspace(1) %.9, ptr addrspace(1) %.9982, ptr addrspace(1) %.91023, ptr addrspace(1) %.61061, ptr addrspace(1) %.51082) ]
  %r928294 = call double @llvm.experimental.gc.result.f64(token %statepoint_token293)
  %r57.0.relocated295 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token293, i32 0, i32 0) ; (%.9938, %.9938)
  %rs4gc.s12.relocated296 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token293, i32 1, i32 1) ; (%.9, %.9)
  %r48.0.base.relocated297 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token293, i32 2, i32 2) ; (%.9982, %.9982)
  %r48.0.relocated298 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token293, i32 2, i32 3) ; (%.9982, %.91023)
  %rs4gc.s15.relocated299 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token293, i32 4, i32 4) ; (%.61061, %.61061)
  %rs4gc.s19.relocated300 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token293, i32 5, i32 5) ; (%.51082, %.51082)
  br label %pic.merge.192

pic.merge.192:                                    ; preds = %pic.way.live.199, %pic.hit.overflow.195, %pic.miss.call.191, %pic.desc.prefix.hit.188, %pic.prefix.hit.183, %pic.hit.live.179
  %.81085 = phi ptr addrspace(1) [ %rs4gc.s19.relocated308, %pic.hit.overflow.195 ], [ %rs4gc.s19.relocated300, %pic.miss.call.191 ], [ %.51082, %pic.way.live.199 ], [ %.51082, %pic.hit.live.179 ], [ %.51082, %pic.prefix.hit.183 ], [ %.51082, %pic.desc.prefix.hit.188 ]
  %.91064 = phi ptr addrspace(1) [ %rs4gc.s15.relocated307, %pic.hit.overflow.195 ], [ %rs4gc.s15.relocated299, %pic.miss.call.191 ], [ %.61061, %pic.way.live.199 ], [ %.61061, %pic.hit.live.179 ], [ %.61061, %pic.prefix.hit.183 ], [ %.61061, %pic.desc.prefix.hit.188 ]
  %.121026 = phi ptr addrspace(1) [ %r48.0.relocated306, %pic.hit.overflow.195 ], [ %r48.0.relocated298, %pic.miss.call.191 ], [ %.91023, %pic.way.live.199 ], [ %.91023, %pic.hit.live.179 ], [ %.91023, %pic.prefix.hit.183 ], [ %.91023, %pic.desc.prefix.hit.188 ]
  %.12985 = phi ptr addrspace(1) [ %r48.0.base.relocated305, %pic.hit.overflow.195 ], [ %r48.0.base.relocated297, %pic.miss.call.191 ], [ %.9982, %pic.way.live.199 ], [ %.9982, %pic.hit.live.179 ], [ %.9982, %pic.prefix.hit.183 ], [ %.9982, %pic.desc.prefix.hit.188 ]
  %.12941 = phi ptr addrspace(1) [ %r57.0.relocated303, %pic.hit.overflow.195 ], [ %r57.0.relocated295, %pic.miss.call.191 ], [ %.9938, %pic.way.live.199 ], [ %.9938, %pic.hit.live.179 ], [ %.9938, %pic.prefix.hit.183 ], [ %.9938, %pic.desc.prefix.hit.188 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s12.relocated304, %pic.hit.overflow.195 ], [ %rs4gc.s12.relocated296, %pic.miss.call.191 ], [ %.9, %pic.way.live.199 ], [ %.9, %pic.hit.live.179 ], [ %.9, %pic.prefix.hit.183 ], [ %.9, %pic.desc.prefix.hit.188 ]
  %r929 = phi double [ %r845, %pic.hit.live.179 ], [ %r840302, %pic.hit.overflow.195 ], [ %r865, %pic.prefix.hit.183 ], [ %r883, %pic.desc.prefix.hit.188 ], [ %r922, %pic.way.live.199 ], [ %r928294, %pic.miss.call.191 ]
  br label %pget.recv_merge.173

pic.recv_hdr.193:                                 ; preds = %pget.recv_obj.177
  %r808 = sub nuw nsw i64 %r796, 8
  %r809 = inttoptr i64 %r808 to ptr
  %r810 = load i8, ptr %r809, align 1
  %r811 = icmp eq i8 %r810, 2
  %r812 = sub nuw nsw i64 %r796, 6
  %r813 = inttoptr i64 %r812 to ptr
  %r814 = load i16, ptr %r813, align 2
  %r815 = and i16 %r814, 2048
  %r816 = icmp eq i16 %r815, 0
  %r817 = load ptr, ptr @perry_ic_test_json_template_capture_ts__13, align 8
  %r818 = icmp ne ptr %r817, null
  %r819 = and i1 %r811, %r816
  %r820 = and i1 %r819, %r818
  br i1 %r820, label %pic.token.194, label %pic.desc.classify.184

pic.token.194:                                    ; preds = %pic.recv_hdr.193
  %r822 = add nuw nsw i64 %r796, 4
  %r823 = inttoptr i64 %r822 to ptr
  %r824 = load i32, ptr %r823, align 4
  %r825 = zext i32 %r824 to i64
  %r826 = or i64 %r825, 4611686018427387904
  %r827 = icmp ne i32 %r824, 0
  %r828 = getelementptr i64, ptr %r817, i64 0
  %r829 = load i64, ptr %r828, align 8
  %r830 = icmp eq i64 %r826, %r829
  %r831 = and i1 %r830, %r827
  br i1 %r831, label %pic.hit.178, label %pic.prefix.guard.180

pic.hit.overflow.195:                             ; preds = %pic.hit.178
  %r836 = load double, ptr @test_json_template_capture_ts_.str.12.handle, align 8
  %r837 = bitcast double %r836 to i64
  %r838 = and i64 %r837, 281474976710655
  %r839 = trunc i64 %r833 to i32
  %statepoint_token301 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r796, i64 %r838, i32 %r839, ptr @perry_ic_test_json_template_capture_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9938, ptr addrspace(1) %.9, ptr addrspace(1) %.9982, ptr addrspace(1) %.91023, ptr addrspace(1) %.61061, ptr addrspace(1) %.51082) ]
  %r840302 = call double @llvm.experimental.gc.result.f64(token %statepoint_token301)
  %r57.0.relocated303 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token301, i32 0, i32 0) ; (%.9938, %.9938)
  %rs4gc.s12.relocated304 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token301, i32 1, i32 1) ; (%.9, %.9)
  %r48.0.base.relocated305 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token301, i32 2, i32 2) ; (%.9982, %.9982)
  %r48.0.relocated306 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token301, i32 2, i32 3) ; (%.9982, %.91023)
  %rs4gc.s15.relocated307 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token301, i32 4, i32 4) ; (%.61061, %.61061)
  %rs4gc.s19.relocated308 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token301, i32 5, i32 5) ; (%.51082, %.51082)
  br label %pic.merge.192

pic.hit.inline.196:                               ; preds = %pic.hit.178
  %r841 = shl i64 %r833, 3
  %r842 = add nuw nsw i64 %r796, 16
  %r843 = add i64 %r842, %r841
  %r844 = inttoptr i64 %r843 to ptr
  %r845 = load double, ptr %r844, align 8
  %r846 = bitcast double %r845 to i64
  %r847 = icmp eq i64 %r846, 9222246136947933200
  br i1 %r847, label %pic.miss.189, label %pic.hit.live.179

pic.ways.197:                                     ; preds = %pic.miss.189
  %r887 = getelementptr i64, ptr %r817, i64 4
  %r888 = load i64, ptr %r887, align 8
  %r889 = icmp eq i64 %r888, %r826
  %r890 = getelementptr i64, ptr %r817, i64 5
  %r891 = load i64, ptr %r890, align 8
  %r892 = select i1 %r889, i64 %r891, i64 0
  %r893 = getelementptr i64, ptr %r817, i64 6
  %r894 = load i64, ptr %r893, align 8
  %r895 = icmp eq i64 %r894, %r826
  %r896 = getelementptr i64, ptr %r817, i64 7
  %r897 = load i64, ptr %r896, align 8
  %r898 = select i1 %r895, i64 %r897, i64 0
  %r899 = getelementptr i64, ptr %r817, i64 8
  %r900 = load i64, ptr %r899, align 8
  %r901 = icmp eq i64 %r900, %r826
  %r902 = getelementptr i64, ptr %r817, i64 9
  %r903 = load i64, ptr %r902, align 8
  %r904 = select i1 %r901, i64 %r903, i64 0
  %r905 = getelementptr i64, ptr %r817, i64 10
  %r906 = load i64, ptr %r905, align 8
  %r907 = icmp eq i64 %r906, %r826
  %r908 = getelementptr i64, ptr %r817, i64 11
  %r909 = load i64, ptr %r908, align 8
  %r910 = select i1 %r907, i64 %r909, i64 0
  %r911 = or i1 %r889, %r895
  %r912 = select i1 %r889, i64 %r892, i64 %r898
  %r913 = or i1 %r901, %r907
  %r914 = select i1 %r901, i64 %r904, i64 %r910
  %r915 = or i1 %r911, %r913
  %r916 = select i1 %r911, i64 %r912, i64 %r914
  %r917 = and i1 %r827, %r915
  br i1 %r917, label %pic.way.load.198, label %pic.miss.call.191

pic.way.load.198:                                 ; preds = %pic.ways.197
  %r918 = shl i64 %r916, 3
  %r919 = add nuw nsw i64 %r796, 16
  %r920 = add i64 %r919, %r918
  %r921 = inttoptr i64 %r920 to ptr
  %r922 = load double, ptr %r921, align 8
  %r923 = bitcast double %r922 to i64
  %r924 = icmp eq i64 %r923, 9222246136947933200
  br i1 %r924, label %pic.miss.call.191, label %pic.way.live.199

pic.way.live.199:                                 ; preds = %pic.way.load.198
  br label %pic.merge.192

pget.throw_nullish.200:                           ; preds = %pget.recv_bad.171
  %r933 = zext i1 %r931 to i32
  %statepoint_token309 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r933, ptr @test_json_template_capture_ts_.str.12.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.201:                       ; preds = %pget.recv_bad.171
  %r934 = load double, ptr @test_json_template_capture_ts_.str.12.handle, align 8
  %r935 = bitcast double %r934 to i64
  %r936 = and i64 %r935, 281474976710655
  %statepoint_token310 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r795, i64 %r936, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9938, ptr addrspace(1) %.9, ptr addrspace(1) %.9982, ptr addrspace(1) %.91023, ptr addrspace(1) %.61061, ptr addrspace(1) %.51082) ]
  %r937311 = call double @llvm.experimental.gc.result.f64(token %statepoint_token310)
  %r57.0.relocated312 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token310, i32 0, i32 0) ; (%.9938, %.9938)
  %rs4gc.s12.relocated313 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token310, i32 1, i32 1) ; (%.9, %.9)
  %r48.0.base.relocated314 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token310, i32 2, i32 2) ; (%.9982, %.9982)
  %r48.0.relocated315 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token310, i32 2, i32 3) ; (%.9982, %.91023)
  %rs4gc.s15.relocated316 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token310, i32 4, i32 4) ; (%.61061, %.61061)
  %rs4gc.s19.relocated317 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token310, i32 5, i32 5) ; (%.51082, %.51082)
  br label %pget.recv_merge.173

logical.then.202:                                 ; preds = %pget.recv_merge.173
  %r963.rs4i = ptrtoint ptr addrspace(1) %.71084 to i64
  %r963.rs4o = call i64 asm "", "=r,0"(i64 %r963.rs4i) #7
  %r963 = bitcast i64 %r963.rs4o to double
  %r964 = bitcast double %r963 to i64
  %r965 = and i64 %r964, 281474976710655
  %r966 = lshr i64 %r964, 48
  %r967 = and i64 %r966, 65533
  %r968 = icmp eq i64 %r967, 32765
  br i1 %r968, label %pget.recv_ok.205, label %pget.recv_other.209

logical.merge.203:                                ; preds = %streqlit.merge.289, %pget.recv_merge.173
  %.91086 = phi ptr addrspace(1) [ %.71084, %pget.recv_merge.173 ], [ %.101087, %streqlit.merge.289 ]
  %.101065 = phi ptr addrspace(1) [ %.81063, %pget.recv_merge.173 ], [ %.111066, %streqlit.merge.289 ]
  %.131027 = phi ptr addrspace(1) [ %.111025, %pget.recv_merge.173 ], [ %.141028, %streqlit.merge.289 ]
  %.13986 = phi ptr addrspace(1) [ %.11984, %pget.recv_merge.173 ], [ %.14987, %streqlit.merge.289 ]
  %.13942 = phi ptr addrspace(1) [ %.11940, %pget.recv_merge.173 ], [ %.14943, %streqlit.merge.289 ]
  %.13 = phi ptr addrspace(1) [ %.11, %pget.recv_merge.173 ], [ %.14, %streqlit.merge.289 ]
  %r1404 = phi double [ %r961, %pget.recv_merge.173 ], [ %r1402, %streqlit.merge.289 ]
  %r1405 = phi i1 [ true, %pget.recv_merge.173 ], [ %r1403, %streqlit.merge.289 ]
  br i1 %r1405, label %if.then.290, label %if.else.291

pget.recv_sso.204:                                ; preds = %pget.recv_other.209
  %r1106 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r1107 = bitcast double %r1106 to i64
  %r1108 = and i64 %r1107, 281474976710655
  %statepoint_token318 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r964, i64 %r1108, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11940, ptr addrspace(1) %.11, ptr addrspace(1) %.11984, ptr addrspace(1) %.111025, ptr addrspace(1) %.81063, ptr addrspace(1) %.71084) ]
  %r1109319 = call double @llvm.experimental.gc.result.f64(token %statepoint_token318)
  %r57.0.relocated320 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token318, i32 0, i32 0) ; (%.11940, %.11940)
  %rs4gc.s12.relocated321 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token318, i32 1, i32 1) ; (%.11, %.11)
  %r48.0.base.relocated322 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token318, i32 2, i32 2) ; (%.11984, %.11984)
  %r48.0.relocated323 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token318, i32 2, i32 3) ; (%.11984, %.111025)
  %rs4gc.s15.relocated324 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token318, i32 4, i32 4) ; (%.81063, %.81063)
  %rs4gc.s19.relocated325 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token318, i32 5, i32 5) ; (%.71084, %.71084)
  br label %pget.recv_merge.208

pget.recv_ok.205:                                 ; preds = %logical.then.202
  %r975 = icmp ugt i64 %r965, 1048575
  br i1 %r975, label %pic.recv_hdr.226, label %pic.miss.cold.223

pget.recv_bad.206:                                ; preds = %pget.check_class_ref.210
  %r1098 = icmp eq i64 %r964, 9222246136947933185
  %r1099 = icmp eq i64 %r964, 9222246136947933186
  %r1100 = or i1 %r1098, %r1099
  br i1 %r1100, label %pget.throw_nullish.233, label %pget.recv_undef_return.234

pget.recv_class_ref.207:                          ; preds = %pget.check_class_ref.210
  %r971 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r972 = bitcast double %r971 to i64
  %r973 = and i64 %r972, 281474976710655
  %statepoint_token326 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6060382687846203406, i64 %r964, i64 %r973, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11940, ptr addrspace(1) %.11, ptr addrspace(1) %.11984, ptr addrspace(1) %.111025, ptr addrspace(1) %.81063, ptr addrspace(1) %.71084) ]
  %r974327 = call double @llvm.experimental.gc.result.f64(token %statepoint_token326)
  %r57.0.relocated328 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 0, i32 0) ; (%.11940, %.11940)
  %rs4gc.s12.relocated329 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 1, i32 1) ; (%.11, %.11)
  %r48.0.base.relocated330 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 2, i32 2) ; (%.11984, %.11984)
  %r48.0.relocated331 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 2, i32 3) ; (%.11984, %.111025)
  %rs4gc.s15.relocated332 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 4, i32 4) ; (%.81063, %.81063)
  %rs4gc.s19.relocated333 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 5, i32 5) ; (%.71084, %.71084)
  br label %pget.recv_merge.208

pget.recv_merge.208:                              ; preds = %pget.recv_undef_return.234, %pic.merge.225, %pget.recv_class_ref.207, %pget.recv_sso.204
  %.111088 = phi ptr addrspace(1) [ %.121089, %pic.merge.225 ], [ %rs4gc.s19.relocated325, %pget.recv_sso.204 ], [ %rs4gc.s19.relocated333, %pget.recv_class_ref.207 ], [ %rs4gc.s19.relocated358, %pget.recv_undef_return.234 ]
  %.121067 = phi ptr addrspace(1) [ %.131068, %pic.merge.225 ], [ %rs4gc.s15.relocated324, %pget.recv_sso.204 ], [ %rs4gc.s15.relocated332, %pget.recv_class_ref.207 ], [ %rs4gc.s15.relocated357, %pget.recv_undef_return.234 ]
  %.151029 = phi ptr addrspace(1) [ %.161030, %pic.merge.225 ], [ %r48.0.relocated323, %pget.recv_sso.204 ], [ %r48.0.relocated331, %pget.recv_class_ref.207 ], [ %r48.0.relocated356, %pget.recv_undef_return.234 ]
  %.15988 = phi ptr addrspace(1) [ %.16989, %pic.merge.225 ], [ %r48.0.base.relocated322, %pget.recv_sso.204 ], [ %r48.0.base.relocated330, %pget.recv_class_ref.207 ], [ %r48.0.base.relocated355, %pget.recv_undef_return.234 ]
  %.15944 = phi ptr addrspace(1) [ %.16945, %pic.merge.225 ], [ %r57.0.relocated320, %pget.recv_sso.204 ], [ %r57.0.relocated328, %pget.recv_class_ref.207 ], [ %r57.0.relocated353, %pget.recv_undef_return.234 ]
  %.15 = phi ptr addrspace(1) [ %.16, %pic.merge.225 ], [ %rs4gc.s12.relocated321, %pget.recv_sso.204 ], [ %rs4gc.s12.relocated329, %pget.recv_class_ref.207 ], [ %rs4gc.s12.relocated354, %pget.recv_undef_return.234 ]
  %r1110 = phi double [ %r1097, %pic.merge.225 ], [ %r1105352, %pget.recv_undef_return.234 ], [ %r1109319, %pget.recv_sso.204 ], [ %r974327, %pget.recv_class_ref.207 ]
  %r1111 = bitcast double %r1110 to i64
  %r1112 = and i64 %r1111, 281474976710655
  %r1113 = and i64 %r1111, -281474976710656
  %r1114 = icmp eq i64 %r1113, 9222527611924643840
  %r1115 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r1116 = icmp eq i64 %r1115, 0
  %r1117 = icmp ugt i64 %r1112, 1048575
  %r1118 = icmp ult i64 %r1112, 140737488355328
  %r1119 = and i1 %r1117, %r1118
  %r1120 = and i1 %r1114, %r1116
  %r1121 = and i1 %r1120, %r1119
  br i1 %r1121, label %tav.get.brand.239, label %tav.get.slow.237

pget.recv_other.209:                              ; preds = %logical.then.202
  %r969 = icmp eq i64 %r966, 32761
  br i1 %r969, label %pget.recv_sso.204, label %pget.check_class_ref.210

pget.check_class_ref.210:                         ; preds = %pget.recv_other.209
  %r970 = icmp eq i64 %r966, 32766
  br i1 %r970, label %pget.recv_class_ref.207, label %pget.recv_bad.206

pic.hit.211:                                      ; preds = %pic.token.227
  %r1000 = getelementptr i64, ptr %r985, i64 1
  %r1001 = load i64, ptr %r1000, align 8
  %r1002 = and i64 %r1001, 1073741824
  %r1003 = icmp ne i64 %r1002, 0
  br i1 %r1003, label %pic.hit.overflow.228, label %pic.hit.inline.229

pic.hit.live.212:                                 ; preds = %pic.hit.inline.229
  br label %pic.merge.225

pic.prefix.guard.213:                             ; preds = %pic.token.227
  %r1016 = getelementptr i64, ptr %r985, i64 2
  %r1017 = load i64, ptr %r1016, align 8
  %r1018 = icmp ne i64 %r1017, 0
  br i1 %r1018, label %pic.prefix.meta.214, label %pic.miss.222

pic.prefix.meta.214:                              ; preds = %pic.prefix.guard.213
  %r1019 = add nuw nsw i64 %r965, 8
  %r1020 = inttoptr i64 %r1019 to ptr
  %r1021 = load i64, ptr %r1020, align 8
  %r1022 = icmp ne i64 %r1021, 0
  br i1 %r1022, label %pic.prefix.token.215, label %pic.miss.222

pic.prefix.token.215:                             ; preds = %pic.prefix.meta.214
  %r1023 = inttoptr i64 %r1021 to ptr
  %r1024 = getelementptr i64, ptr %r1023, i64 6
  %r1025 = load i64, ptr %r1024, align 8
  %r1026 = icmp eq i64 %r1025, %r1017
  br i1 %r1026, label %pic.prefix.hit.216, label %pic.miss.222

pic.prefix.hit.216:                               ; preds = %pic.prefix.token.215
  %r1027 = getelementptr i64, ptr %r985, i64 1
  %r1028 = load i64, ptr %r1027, align 8
  %r1029 = shl i64 %r1028, 3
  %r1030 = add nuw nsw i64 %r965, 16
  %r1031 = add i64 %r1030, %r1029
  %r1032 = inttoptr i64 %r1031 to ptr
  %r1033 = load double, ptr %r1032, align 8
  br label %pic.merge.225

pic.desc.classify.217:                            ; preds = %pic.recv_hdr.226
  %r989 = and i1 %r979, %r986
  br i1 %r989, label %pic.desc.prefix.guard.218, label %pic.miss.cold.223

pic.desc.prefix.guard.218:                        ; preds = %pic.desc.classify.217
  %r1034 = getelementptr i64, ptr %r985, i64 2
  %r1035 = load i64, ptr %r1034, align 8
  %r1036 = icmp ne i64 %r1035, 0
  br i1 %r1036, label %pic.desc.prefix.meta.219, label %pic.miss.cold.223

pic.desc.prefix.meta.219:                         ; preds = %pic.desc.prefix.guard.218
  %r1037 = add nuw nsw i64 %r965, 8
  %r1038 = inttoptr i64 %r1037 to ptr
  %r1039 = load i64, ptr %r1038, align 8
  %r1040 = icmp ne i64 %r1039, 0
  br i1 %r1040, label %pic.desc.prefix.token.220, label %pic.miss.cold.223

pic.desc.prefix.token.220:                        ; preds = %pic.desc.prefix.meta.219
  %r1041 = inttoptr i64 %r1039 to ptr
  %r1042 = getelementptr i64, ptr %r1041, i64 6
  %r1043 = load i64, ptr %r1042, align 8
  %r1044 = icmp eq i64 %r1043, %r1035
  br i1 %r1044, label %pic.desc.prefix.hit.221, label %pic.miss.cold.223

pic.desc.prefix.hit.221:                          ; preds = %pic.desc.prefix.token.220
  %r1045 = getelementptr i64, ptr %r985, i64 1
  %r1046 = load i64, ptr %r1045, align 8
  %r1047 = shl i64 %r1046, 3
  %r1048 = add nuw nsw i64 %r965, 16
  %r1049 = add i64 %r1048, %r1047
  %r1050 = inttoptr i64 %r1049 to ptr
  %r1051 = load double, ptr %r1050, align 8
  br label %pic.merge.225

pic.miss.222:                                     ; preds = %pic.hit.inline.229, %pic.prefix.token.215, %pic.prefix.meta.214, %pic.prefix.guard.213
  %r1052 = getelementptr i64, ptr %r985, i64 3
  %r1053 = load i64, ptr %r1052, align 8
  %r1054 = icmp sgt i64 %r1053, 0
  br i1 %r1054, label %pic.ways.230, label %pic.miss.call.224

pic.miss.cold.223:                                ; preds = %pic.desc.prefix.token.220, %pic.desc.prefix.meta.219, %pic.desc.prefix.guard.218, %pic.desc.classify.217, %pget.recv_ok.205
  br label %pic.miss.call.224

pic.miss.call.224:                                ; preds = %pic.way.load.231, %pic.ways.230, %pic.miss.cold.223, %pic.miss.222
  %r1093 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r1094 = bitcast double %r1093 to i64
  %r1095 = and i64 %r1094, 281474976710655
  %statepoint_token334 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r965, i64 %r1095, ptr @perry_ic_test_json_template_capture_ts__15, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11940, ptr addrspace(1) %.11, ptr addrspace(1) %.11984, ptr addrspace(1) %.111025, ptr addrspace(1) %.81063, ptr addrspace(1) %.71084) ]
  %r1096335 = call double @llvm.experimental.gc.result.f64(token %statepoint_token334)
  %r57.0.relocated336 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token334, i32 0, i32 0) ; (%.11940, %.11940)
  %rs4gc.s12.relocated337 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token334, i32 1, i32 1) ; (%.11, %.11)
  %r48.0.base.relocated338 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token334, i32 2, i32 2) ; (%.11984, %.11984)
  %r48.0.relocated339 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token334, i32 2, i32 3) ; (%.11984, %.111025)
  %rs4gc.s15.relocated340 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token334, i32 4, i32 4) ; (%.81063, %.81063)
  %rs4gc.s19.relocated341 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token334, i32 5, i32 5) ; (%.71084, %.71084)
  br label %pic.merge.225

pic.merge.225:                                    ; preds = %pic.way.live.232, %pic.hit.overflow.228, %pic.miss.call.224, %pic.desc.prefix.hit.221, %pic.prefix.hit.216, %pic.hit.live.212
  %.121089 = phi ptr addrspace(1) [ %rs4gc.s19.relocated349, %pic.hit.overflow.228 ], [ %rs4gc.s19.relocated341, %pic.miss.call.224 ], [ %.71084, %pic.way.live.232 ], [ %.71084, %pic.hit.live.212 ], [ %.71084, %pic.prefix.hit.216 ], [ %.71084, %pic.desc.prefix.hit.221 ]
  %.131068 = phi ptr addrspace(1) [ %rs4gc.s15.relocated348, %pic.hit.overflow.228 ], [ %rs4gc.s15.relocated340, %pic.miss.call.224 ], [ %.81063, %pic.way.live.232 ], [ %.81063, %pic.hit.live.212 ], [ %.81063, %pic.prefix.hit.216 ], [ %.81063, %pic.desc.prefix.hit.221 ]
  %.161030 = phi ptr addrspace(1) [ %r48.0.relocated347, %pic.hit.overflow.228 ], [ %r48.0.relocated339, %pic.miss.call.224 ], [ %.111025, %pic.way.live.232 ], [ %.111025, %pic.hit.live.212 ], [ %.111025, %pic.prefix.hit.216 ], [ %.111025, %pic.desc.prefix.hit.221 ]
  %.16989 = phi ptr addrspace(1) [ %r48.0.base.relocated346, %pic.hit.overflow.228 ], [ %r48.0.base.relocated338, %pic.miss.call.224 ], [ %.11984, %pic.way.live.232 ], [ %.11984, %pic.hit.live.212 ], [ %.11984, %pic.prefix.hit.216 ], [ %.11984, %pic.desc.prefix.hit.221 ]
  %.16945 = phi ptr addrspace(1) [ %r57.0.relocated344, %pic.hit.overflow.228 ], [ %r57.0.relocated336, %pic.miss.call.224 ], [ %.11940, %pic.way.live.232 ], [ %.11940, %pic.hit.live.212 ], [ %.11940, %pic.prefix.hit.216 ], [ %.11940, %pic.desc.prefix.hit.221 ]
  %.16 = phi ptr addrspace(1) [ %rs4gc.s12.relocated345, %pic.hit.overflow.228 ], [ %rs4gc.s12.relocated337, %pic.miss.call.224 ], [ %.11, %pic.way.live.232 ], [ %.11, %pic.hit.live.212 ], [ %.11, %pic.prefix.hit.216 ], [ %.11, %pic.desc.prefix.hit.221 ]
  %r1097 = phi double [ %r1013, %pic.hit.live.212 ], [ %r1008343, %pic.hit.overflow.228 ], [ %r1033, %pic.prefix.hit.216 ], [ %r1051, %pic.desc.prefix.hit.221 ], [ %r1090, %pic.way.live.232 ], [ %r1096335, %pic.miss.call.224 ]
  br label %pget.recv_merge.208

pic.recv_hdr.226:                                 ; preds = %pget.recv_ok.205
  %r976 = sub nuw nsw i64 %r965, 8
  %r977 = inttoptr i64 %r976 to ptr
  %r978 = load i8, ptr %r977, align 1
  %r979 = icmp eq i8 %r978, 2
  %r980 = sub nuw nsw i64 %r965, 6
  %r981 = inttoptr i64 %r980 to ptr
  %r982 = load i16, ptr %r981, align 2
  %r983 = and i16 %r982, 2048
  %r984 = icmp eq i16 %r983, 0
  %r985 = load ptr, ptr @perry_ic_test_json_template_capture_ts__15, align 8
  %r986 = icmp ne ptr %r985, null
  %r987 = and i1 %r979, %r984
  %r988 = and i1 %r987, %r986
  br i1 %r988, label %pic.token.227, label %pic.desc.classify.217

pic.token.227:                                    ; preds = %pic.recv_hdr.226
  %r990 = add nuw nsw i64 %r965, 4
  %r991 = inttoptr i64 %r990 to ptr
  %r992 = load i32, ptr %r991, align 4
  %r993 = zext i32 %r992 to i64
  %r994 = or i64 %r993, 4611686018427387904
  %r995 = icmp ne i32 %r992, 0
  %r996 = getelementptr i64, ptr %r985, i64 0
  %r997 = load i64, ptr %r996, align 8
  %r998 = icmp eq i64 %r994, %r997
  %r999 = and i1 %r998, %r995
  br i1 %r999, label %pic.hit.211, label %pic.prefix.guard.213

pic.hit.overflow.228:                             ; preds = %pic.hit.211
  %r1004 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r1005 = bitcast double %r1004 to i64
  %r1006 = and i64 %r1005, 281474976710655
  %r1007 = trunc i64 %r1001 to i32
  %statepoint_token342 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r965, i64 %r1006, i32 %r1007, ptr @perry_ic_test_json_template_capture_ts__15, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11940, ptr addrspace(1) %.11, ptr addrspace(1) %.11984, ptr addrspace(1) %.111025, ptr addrspace(1) %.81063, ptr addrspace(1) %.71084) ]
  %r1008343 = call double @llvm.experimental.gc.result.f64(token %statepoint_token342)
  %r57.0.relocated344 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 0, i32 0) ; (%.11940, %.11940)
  %rs4gc.s12.relocated345 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 1, i32 1) ; (%.11, %.11)
  %r48.0.base.relocated346 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 2, i32 2) ; (%.11984, %.11984)
  %r48.0.relocated347 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 2, i32 3) ; (%.11984, %.111025)
  %rs4gc.s15.relocated348 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 4, i32 4) ; (%.81063, %.81063)
  %rs4gc.s19.relocated349 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 5, i32 5) ; (%.71084, %.71084)
  br label %pic.merge.225

pic.hit.inline.229:                               ; preds = %pic.hit.211
  %r1009 = shl i64 %r1001, 3
  %r1010 = add nuw nsw i64 %r965, 16
  %r1011 = add i64 %r1010, %r1009
  %r1012 = inttoptr i64 %r1011 to ptr
  %r1013 = load double, ptr %r1012, align 8
  %r1014 = bitcast double %r1013 to i64
  %r1015 = icmp eq i64 %r1014, 9222246136947933200
  br i1 %r1015, label %pic.miss.222, label %pic.hit.live.212

pic.ways.230:                                     ; preds = %pic.miss.222
  %r1055 = getelementptr i64, ptr %r985, i64 4
  %r1056 = load i64, ptr %r1055, align 8
  %r1057 = icmp eq i64 %r1056, %r994
  %r1058 = getelementptr i64, ptr %r985, i64 5
  %r1059 = load i64, ptr %r1058, align 8
  %r1060 = select i1 %r1057, i64 %r1059, i64 0
  %r1061 = getelementptr i64, ptr %r985, i64 6
  %r1062 = load i64, ptr %r1061, align 8
  %r1063 = icmp eq i64 %r1062, %r994
  %r1064 = getelementptr i64, ptr %r985, i64 7
  %r1065 = load i64, ptr %r1064, align 8
  %r1066 = select i1 %r1063, i64 %r1065, i64 0
  %r1067 = getelementptr i64, ptr %r985, i64 8
  %r1068 = load i64, ptr %r1067, align 8
  %r1069 = icmp eq i64 %r1068, %r994
  %r1070 = getelementptr i64, ptr %r985, i64 9
  %r1071 = load i64, ptr %r1070, align 8
  %r1072 = select i1 %r1069, i64 %r1071, i64 0
  %r1073 = getelementptr i64, ptr %r985, i64 10
  %r1074 = load i64, ptr %r1073, align 8
  %r1075 = icmp eq i64 %r1074, %r994
  %r1076 = getelementptr i64, ptr %r985, i64 11
  %r1077 = load i64, ptr %r1076, align 8
  %r1078 = select i1 %r1075, i64 %r1077, i64 0
  %r1079 = or i1 %r1057, %r1063
  %r1080 = select i1 %r1057, i64 %r1060, i64 %r1066
  %r1081 = or i1 %r1069, %r1075
  %r1082 = select i1 %r1069, i64 %r1072, i64 %r1078
  %r1083 = or i1 %r1079, %r1081
  %r1084 = select i1 %r1079, i64 %r1080, i64 %r1082
  %r1085 = and i1 %r995, %r1083
  br i1 %r1085, label %pic.way.load.231, label %pic.miss.call.224

pic.way.load.231:                                 ; preds = %pic.ways.230
  %r1086 = shl i64 %r1084, 3
  %r1087 = add nuw nsw i64 %r965, 16
  %r1088 = add i64 %r1087, %r1086
  %r1089 = inttoptr i64 %r1088 to ptr
  %r1090 = load double, ptr %r1089, align 8
  %r1091 = bitcast double %r1090 to i64
  %r1092 = icmp eq i64 %r1091, 9222246136947933200
  br i1 %r1092, label %pic.miss.call.224, label %pic.way.live.232

pic.way.live.232:                                 ; preds = %pic.way.load.231
  br label %pic.merge.225

pget.throw_nullish.233:                           ; preds = %pget.recv_bad.206
  %r1101 = zext i1 %r1099 to i32
  %statepoint_token350 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1101, ptr @test_json_template_capture_ts_.str.9.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.234:                       ; preds = %pget.recv_bad.206
  %r1102 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r1103 = bitcast double %r1102 to i64
  %r1104 = and i64 %r1103, 281474976710655
  %statepoint_token351 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r964, i64 %r1104, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11940, ptr addrspace(1) %.11, ptr addrspace(1) %.11984, ptr addrspace(1) %.111025, ptr addrspace(1) %.81063, ptr addrspace(1) %.71084) ]
  %r1105352 = call double @llvm.experimental.gc.result.f64(token %statepoint_token351)
  %r57.0.relocated353 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token351, i32 0, i32 0) ; (%.11940, %.11940)
  %rs4gc.s12.relocated354 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token351, i32 1, i32 1) ; (%.11, %.11)
  %r48.0.base.relocated355 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token351, i32 2, i32 2) ; (%.11984, %.11984)
  %r48.0.relocated356 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token351, i32 2, i32 3) ; (%.11984, %.111025)
  %rs4gc.s15.relocated357 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token351, i32 4, i32 4) ; (%.81063, %.81063)
  %rs4gc.s19.relocated358 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token351, i32 5, i32 5) ; (%.71084, %.71084)
  br label %pget.recv_merge.208

tav.get.fast.235:                                 ; preds = %tav.get.brand.239
  %r1138 = bitcast double %r1110 to i64
  %r1139 = and i64 %r1138, 281474976710655
  %r1140 = add nuw nsw i64 %r1139, 8
  %r1141 = inttoptr i64 %r1140 to ptr
  %r1142 = load i8, ptr %r1141, align 1
  %r1143 = zext i8 %r1142 to i64
  %r1147 = inttoptr i64 %r1139 to ptr
  %r1148 = load i32, ptr %r1147, align 4
  %r1149 = zext i32 %r1148 to i64
  %r1150 = icmp ult i64 0, %r1149
  %r1151 = and i1 true, %r1150
  br i1 %r1151, label %tav.get.load.236, label %tav.get.slow.237

tav.get.load.236:                                 ; preds = %tav.get.fast.235
  %r1152 = add nuw nsw i64 %r1139, 16
  %r1153 = icmp eq i64 %r1143, 0
  br i1 %r1153, label %tav.k.i8.240, label %tav.kd1.248

tav.get.slow.237:                                 ; preds = %tav.get.brand.239, %tav.get.fast.235, %pget.recv_merge.208
  %r1204 = load ptr, ptr @perry_ic_test_json_template_capture_ts__16, align 8
  %r1205 = icmp ne ptr %r1204, null
  %r1206 = select i1 %r1205, ptr %r1204, ptr @perry_ic_test_json_template_capture_ts__16
  %r1207 = bitcast double %r1110 to i64
  %r1208 = and i64 %r1207, 281474976710655
  %r1209 = and i64 %r1207, -281474976710656
  %r1210 = icmp eq i64 %r1209, 9222527611924643840
  %r1211 = icmp uge i64 %r1208, 2199023255552
  %r1212 = icmp ult i64 %r1208, 140737488355328
  %r1215 = and i1 %r1210, %r1211
  %r1216 = and i1 %r1215, %r1212
  br i1 %r1216, label %arrlike.ic.header.255, label %arrlike.ic.miss.274

tav.get.merge.238:                                ; preds = %arrlike.elem.value.280, %arrlike.ic.miss.274, %arrlike.ic.spill_load.273, %arrlike.ic.inline.270, %arrlike.ic.array_load.258, %tav.k.f64.247, %tav.k.f32.246, %tav.k.u32.245, %tav.k.i32.244, %tav.k.u16.243, %tav.k.i16.242, %tav.k.u8.241, %tav.k.i8.240
  %.131090 = phi ptr addrspace(1) [ %.111088, %tav.k.i8.240 ], [ %.111088, %tav.k.u8.241 ], [ %.111088, %tav.k.i16.242 ], [ %.111088, %tav.k.u16.243 ], [ %.111088, %tav.k.i32.244 ], [ %.111088, %tav.k.u32.245 ], [ %.111088, %tav.k.f32.246 ], [ %.111088, %tav.k.f64.247 ], [ %.111088, %arrlike.ic.array_load.258 ], [ %rs4gc.s19.relocated366, %arrlike.ic.miss.274 ], [ %.111088, %arrlike.elem.value.280 ], [ %.111088, %arrlike.ic.inline.270 ], [ %.111088, %arrlike.ic.spill_load.273 ]
  %.141069 = phi ptr addrspace(1) [ %.121067, %tav.k.i8.240 ], [ %.121067, %tav.k.u8.241 ], [ %.121067, %tav.k.i16.242 ], [ %.121067, %tav.k.u16.243 ], [ %.121067, %tav.k.i32.244 ], [ %.121067, %tav.k.u32.245 ], [ %.121067, %tav.k.f32.246 ], [ %.121067, %tav.k.f64.247 ], [ %.121067, %arrlike.ic.array_load.258 ], [ %rs4gc.s15.relocated365, %arrlike.ic.miss.274 ], [ %.121067, %arrlike.elem.value.280 ], [ %.121067, %arrlike.ic.inline.270 ], [ %.121067, %arrlike.ic.spill_load.273 ]
  %.171031 = phi ptr addrspace(1) [ %.151029, %tav.k.i8.240 ], [ %.151029, %tav.k.u8.241 ], [ %.151029, %tav.k.i16.242 ], [ %.151029, %tav.k.u16.243 ], [ %.151029, %tav.k.i32.244 ], [ %.151029, %tav.k.u32.245 ], [ %.151029, %tav.k.f32.246 ], [ %.151029, %tav.k.f64.247 ], [ %.151029, %arrlike.ic.array_load.258 ], [ %r48.0.relocated364, %arrlike.ic.miss.274 ], [ %.151029, %arrlike.elem.value.280 ], [ %.151029, %arrlike.ic.inline.270 ], [ %.151029, %arrlike.ic.spill_load.273 ]
  %.17990 = phi ptr addrspace(1) [ %.15988, %tav.k.i8.240 ], [ %.15988, %tav.k.u8.241 ], [ %.15988, %tav.k.i16.242 ], [ %.15988, %tav.k.u16.243 ], [ %.15988, %tav.k.i32.244 ], [ %.15988, %tav.k.u32.245 ], [ %.15988, %tav.k.f32.246 ], [ %.15988, %tav.k.f64.247 ], [ %.15988, %arrlike.ic.array_load.258 ], [ %r48.0.base.relocated363, %arrlike.ic.miss.274 ], [ %.15988, %arrlike.elem.value.280 ], [ %.15988, %arrlike.ic.inline.270 ], [ %.15988, %arrlike.ic.spill_load.273 ]
  %.17946 = phi ptr addrspace(1) [ %.15944, %tav.k.i8.240 ], [ %.15944, %tav.k.u8.241 ], [ %.15944, %tav.k.i16.242 ], [ %.15944, %tav.k.u16.243 ], [ %.15944, %tav.k.i32.244 ], [ %.15944, %tav.k.u32.245 ], [ %.15944, %tav.k.f32.246 ], [ %.15944, %tav.k.f64.247 ], [ %.15944, %arrlike.ic.array_load.258 ], [ %r57.0.relocated361, %arrlike.ic.miss.274 ], [ %.15944, %arrlike.elem.value.280 ], [ %.15944, %arrlike.ic.inline.270 ], [ %.15944, %arrlike.ic.spill_load.273 ]
  %.17 = phi ptr addrspace(1) [ %.15, %tav.k.i8.240 ], [ %.15, %tav.k.u8.241 ], [ %.15, %tav.k.i16.242 ], [ %.15, %tav.k.u16.243 ], [ %.15, %tav.k.i32.244 ], [ %.15, %tav.k.u32.245 ], [ %.15, %tav.k.f32.246 ], [ %.15, %tav.k.f64.247 ], [ %.15, %arrlike.ic.array_load.258 ], [ %rs4gc.s12.relocated362, %arrlike.ic.miss.274 ], [ %.15, %arrlike.elem.value.280 ], [ %.15, %arrlike.ic.inline.270 ], [ %.15, %arrlike.ic.spill_load.273 ]
  %r1377 = phi double [ %r1166, %tav.k.i8.240 ], [ %r1172, %tav.k.u8.241 ], [ %r1178, %tav.k.i16.242 ], [ %r1184, %tav.k.u16.243 ], [ %r1189, %tav.k.i32.244 ], [ %r1194, %tav.k.u32.245 ], [ %r1199, %tav.k.f32.246 ], [ %r1203, %tav.k.f64.247 ], [ %r1260, %arrlike.elem.value.280 ], [ %r1288, %arrlike.ic.array_load.258 ], [ %r1358, %arrlike.ic.inline.270 ], [ %r1375, %arrlike.ic.spill_load.273 ], [ %r1376360, %arrlike.ic.miss.274 ]
  %r1378 = load double, ptr @test_json_template_capture_ts_.str.10.handle, align 8
  %r1379 = bitcast double %r1377 to i64
  %r1380 = bitcast double %r1378 to i64
  %r1381 = icmp eq i64 %r1379, %r1380
  br i1 %r1381, label %streqlit.true.287, label %streqlit.tag.282

tav.get.brand.239:                                ; preds = %pget.recv_merge.208
  %r1122 = bitcast double %r1110 to i64
  %r1123 = and i64 %r1122, 281474976710655
  %r1124 = sub nsw i64 %r1123, 8
  %r1125 = inttoptr i64 %r1124 to ptr
  %r1126 = load i8, ptr %r1125, align 1
  %r1127 = icmp eq i8 %r1126, 11
  %r1128 = add nuw nsw i64 %r1123, 8
  %r1129 = inttoptr i64 %r1128 to ptr
  %r1130 = load i8, ptr %r1129, align 1
  %r1131 = zext i8 %r1130 to i64
  %r1132 = icmp ule i64 %r1131, 8
  %r1135 = and i1 %r1127, %r1132
  br i1 %r1135, label %tav.get.fast.235, label %tav.get.slow.237

tav.k.i8.240:                                     ; preds = %tav.get.load.236
  %r1162 = add nuw nsw i64 %r1152, 0
  %r1163 = inttoptr i64 %r1162 to ptr
  %r1164 = load i8, ptr %r1163, align 1
  %r1165 = sext i8 %r1164 to i32
  %r1166 = sitofp i32 %r1165 to double
  br label %tav.get.merge.238

tav.k.u8.241:                                     ; preds = %tav.kd7.254, %tav.kd1.248
  %r1168 = add nuw nsw i64 %r1152, 0
  %r1169 = inttoptr i64 %r1168 to ptr
  %r1170 = load i8, ptr %r1169, align 1
  %r1171 = zext i8 %r1170 to i32
  %r1172 = uitofp nneg i32 %r1171 to double
  br label %tav.get.merge.238

tav.k.i16.242:                                    ; preds = %tav.kd2.249
  %r1174 = add nuw nsw i64 %r1152, 0
  %r1175 = inttoptr i64 %r1174 to ptr
  %r1176 = load i16, ptr %r1175, align 2
  %r1177 = sext i16 %r1176 to i32
  %r1178 = sitofp i32 %r1177 to double
  br label %tav.get.merge.238

tav.k.u16.243:                                    ; preds = %tav.kd3.250
  %r1180 = add nuw nsw i64 %r1152, 0
  %r1181 = inttoptr i64 %r1180 to ptr
  %r1182 = load i16, ptr %r1181, align 2
  %r1183 = zext i16 %r1182 to i32
  %r1184 = uitofp nneg i32 %r1183 to double
  br label %tav.get.merge.238

tav.k.i32.244:                                    ; preds = %tav.kd4.251
  %r1186 = add nuw nsw i64 %r1152, 0
  %r1187 = inttoptr i64 %r1186 to ptr
  %r1188 = load i32, ptr %r1187, align 4
  %r1189 = sitofp i32 %r1188 to double
  br label %tav.get.merge.238

tav.k.u32.245:                                    ; preds = %tav.kd5.252
  %r1191 = add nuw nsw i64 %r1152, 0
  %r1192 = inttoptr i64 %r1191 to ptr
  %r1193 = load i32, ptr %r1192, align 4
  %r1194 = uitofp i32 %r1193 to double
  br label %tav.get.merge.238

tav.k.f32.246:                                    ; preds = %tav.kd6.253
  %r1196 = add nuw nsw i64 %r1152, 0
  %r1197 = inttoptr i64 %r1196 to ptr
  %r1198 = load float, ptr %r1197, align 4
  %r1199 = fpext float %r1198 to double
  br label %tav.get.merge.238

tav.k.f64.247:                                    ; preds = %tav.kd7.254
  %r1201 = add nuw nsw i64 %r1152, 0
  %r1202 = inttoptr i64 %r1201 to ptr
  %r1203 = load double, ptr %r1202, align 8
  br label %tav.get.merge.238

tav.kd1.248:                                      ; preds = %tav.get.load.236
  %r1154 = icmp eq i64 %r1143, 1
  br i1 %r1154, label %tav.k.u8.241, label %tav.kd2.249

tav.kd2.249:                                      ; preds = %tav.kd1.248
  %r1155 = icmp eq i64 %r1143, 2
  br i1 %r1155, label %tav.k.i16.242, label %tav.kd3.250

tav.kd3.250:                                      ; preds = %tav.kd2.249
  %r1156 = icmp eq i64 %r1143, 3
  br i1 %r1156, label %tav.k.u16.243, label %tav.kd4.251

tav.kd4.251:                                      ; preds = %tav.kd3.250
  %r1157 = icmp eq i64 %r1143, 4
  br i1 %r1157, label %tav.k.i32.244, label %tav.kd5.252

tav.kd5.252:                                      ; preds = %tav.kd4.251
  %r1158 = icmp eq i64 %r1143, 5
  br i1 %r1158, label %tav.k.u32.245, label %tav.kd6.253

tav.kd6.253:                                      ; preds = %tav.kd5.252
  %r1159 = icmp eq i64 %r1143, 6
  br i1 %r1159, label %tav.k.f32.246, label %tav.kd7.254

tav.kd7.254:                                      ; preds = %tav.kd6.253
  %r1160 = icmp eq i64 %r1143, 7
  br i1 %r1160, label %tav.k.f64.247, label %tav.k.u8.241

arrlike.ic.header.255:                            ; preds = %tav.get.slow.237
  %r1222 = sub nuw nsw i64 %r1208, 8
  %r1223 = inttoptr i64 %r1222 to ptr
  %r1224 = load i8, ptr %r1223, align 1
  %r1226 = sub nuw nsw i64 %r1208, 7
  %r1227 = inttoptr i64 %r1226 to ptr
  %r1228 = load i8, ptr %r1227, align 1
  %r1229 = and i8 %r1228, -128
  %r1230 = icmp eq i8 %r1229, 0
  %r1231 = and i1 true, %r1230
  br i1 %r1231, label %arrlike.ic.brand.256, label %arrlike.ic.miss.274

arrlike.ic.brand.256:                             ; preds = %arrlike.ic.header.255
  %r1225 = icmp eq i8 %r1224, 1
  br i1 %r1225, label %arrlike.ic.array_guard.257, label %arrlike.elem.kind.275

arrlike.ic.array_guard.257:                       ; preds = %arrlike.ic.brand.256
  %r1263 = sub nuw nsw i64 %r1208, 6
  %r1264 = inttoptr i64 %r1263 to ptr
  %r1265 = load i16, ptr %r1264, align 2
  %r1266 = and i16 %r1265, 1024
  %r1267 = icmp eq i16 %r1266, 0
  %r1268 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1269 = icmp eq i8 %r1268, 0
  %r1270 = inttoptr i64 %r1208 to ptr
  %r1271 = load i32, ptr %r1270, align 4
  %r1272 = add nuw nsw i64 %r1208, 4
  %r1273 = inttoptr i64 %r1272 to ptr
  %r1274 = load i32, ptr %r1273, align 4
  %r1275 = zext i32 %r1271 to i64
  %r1276 = zext i32 %r1274 to i64
  %r1277 = icmp ult i64 0, %r1275
  %r1278 = icmp ule i64 %r1275, %r1276
  %r1279 = and i1 %r1267, %r1269
  %r1280 = and i1 %r1279, %r1277
  %r1281 = and i1 %r1280, %r1278
  br i1 %r1281, label %arrlike.ic.array_load.258, label %arrlike.ic.miss.274

arrlike.ic.array_load.258:                        ; preds = %arrlike.ic.array_guard.257
  %r1283 = getelementptr inbounds nuw i64, ptr %r1270, i64 1
  %r1284 = load double, ptr %r1283, align 8
  %r1285 = bitcast double %r1284 to i64
  %r1286 = icmp eq i64 %r1285, 9222246136947933200
  %r1288 = select i1 %r1286, double 0x7FFC000000000001, double %r1284
  br label %tav.get.merge.238

arrlike.ic.shape.259:                             ; preds = %arrlike.elem.store.277, %arrlike.elem.meta.276
  %r1290 = inttoptr i64 %r1208 to ptr
  %r1291 = load i32, ptr %r1290, align 4
  %r1292 = add nuw nsw i64 %r1208, 4
  %r1293 = inttoptr i64 %r1292 to ptr
  %r1294 = load i32, ptr %r1293, align 4
  %r1295 = zext i32 %r1291 to i64
  %r1296 = zext i32 %r1294 to i64
  %r1297 = shl nuw i64 %r1295, 32
  %r1298 = or i64 %r1297, %r1296
  %r1299 = getelementptr i64, ptr %r1206, i64 0
  %r1300 = load i64, ptr %r1299, align 8
  %r1301 = icmp ne i64 %r1300, 0
  %r1302 = and i1 true, %r1301
  br i1 %r1302, label %arrlike.ic.identity.260, label %arrlike.ic.miss.274

arrlike.ic.identity.260:                          ; preds = %arrlike.ic.shape.259
  %r1303 = and i64 %r1300, -9223372036854775808
  %0 = icmp slt i64 %r1300, 0
  br i1 %0, label %arrlike.ic.family_meta.262, label %arrlike.ic.exact.261

arrlike.ic.exact.261:                             ; preds = %arrlike.ic.identity.260
  %r1305 = icmp eq i64 %r1298, %r1300
  br i1 %r1305, label %arrlike.ic.bounds.264, label %arrlike.ic.miss.274

arrlike.ic.family_meta.262:                       ; preds = %arrlike.ic.identity.260
  %r1306 = add nuw nsw i64 %r1208, 8
  %r1307 = inttoptr i64 %r1306 to ptr
  %r1308 = load i64, ptr %r1307, align 8
  %r1309 = icmp ne i64 %r1308, 0
  br i1 %r1309, label %arrlike.ic.family_token.263, label %arrlike.ic.miss.274

arrlike.ic.family_token.263:                      ; preds = %arrlike.ic.family_meta.262
  %r1310 = inttoptr i64 %r1308 to ptr
  %r1311 = getelementptr i64, ptr %r1310, i64 6
  %r1312 = load i64, ptr %r1311, align 8
  %r1313 = icmp eq i64 %r1312, %r1300
  br i1 %r1313, label %arrlike.ic.bounds.264, label %arrlike.ic.miss.274

arrlike.ic.bounds.264:                            ; preds = %arrlike.ic.family_token.263, %arrlike.ic.exact.261
  %r1314 = getelementptr i64, ptr %r1204, i64 1
  %r1315 = load i64, ptr %r1314, align 8
  %r1316 = getelementptr i64, ptr %r1204, i64 2
  %r1317 = load i64, ptr %r1316, align 8
  %r1318 = getelementptr i64, ptr %r1204, i64 3
  %r1319 = load i64, ptr %r1318, align 8
  %r1320 = getelementptr i64, ptr %r1204, i64 4
  %r1321 = load i64, ptr %r1320, align 8
  %r1322 = icmp ult i64 %r1315, %r1321
  br i1 %r1322, label %arrlike.ic.length_inline.265, label %arrlike.ic.length_spill_meta.266

arrlike.ic.length_inline.265:                     ; preds = %arrlike.ic.bounds.264
  %r1323 = shl i64 %r1315, 3
  %r1324 = add i64 %r1323, 16
  %r1325 = add i64 %r1208, %r1324
  %r1326 = inttoptr i64 %r1325 to ptr
  %r1327 = load double, ptr %r1326, align 8
  br label %arrlike.ic.range.269

arrlike.ic.length_spill_meta.266:                 ; preds = %arrlike.ic.bounds.264
  %r1328 = add nuw nsw i64 %r1208, 8
  %r1329 = inttoptr i64 %r1328 to ptr
  %r1330 = load i64, ptr %r1329, align 8
  %r1331 = icmp ne i64 %r1330, 0
  br i1 %r1331, label %arrlike.ic.length_spill_ptr.267, label %arrlike.ic.miss.274

arrlike.ic.length_spill_ptr.267:                  ; preds = %arrlike.ic.length_spill_meta.266
  %r1332 = inttoptr i64 %r1330 to ptr
  %r1333 = getelementptr i64, ptr %r1332, i64 4
  %r1334 = load i64, ptr %r1333, align 8
  %r1335 = icmp ne i64 %r1334, 0
  %r1336 = select i1 %r1335, i64 %r1334, i64 %r1330
  %r1337 = inttoptr i64 %r1336 to ptr
  %r1338 = load i32, ptr %r1337, align 4
  %r1339 = zext i32 %r1338 to i64
  %r1340 = icmp ult i64 %r1315, %r1339
  %r1341 = and i1 %r1335, %r1340
  br i1 %r1341, label %arrlike.ic.length_spill_load.268, label %arrlike.ic.miss.274

arrlike.ic.length_spill_load.268:                 ; preds = %arrlike.ic.length_spill_ptr.267
  %r1342 = add nuw nsw i64 %r1315, 1
  %r1343 = getelementptr inbounds nuw i64, ptr %r1337, i64 %r1342
  %r1344 = load double, ptr %r1343, align 8
  br label %arrlike.ic.range.269

arrlike.ic.range.269:                             ; preds = %arrlike.ic.length_spill_load.268, %arrlike.ic.length_inline.265
  %r1345 = phi double [ %r1327, %arrlike.ic.length_inline.265 ], [ %r1344, %arrlike.ic.length_spill_load.268 ]
  %r1346 = fcmp olt double 0.000000e+00, %r1345
  %r1347 = icmp ult i64 0, %r1319
  %r1348 = and i1 %r1346, %r1347
  %r1349 = add nuw nsw i64 %r1317, 0
  %r1350 = icmp ult i64 %r1349, %r1321
  %r1351 = and i1 %r1348, %r1350
  %r1352 = xor i1 %r1350, true
  %r1353 = and i1 %r1348, %r1352
  br i1 %r1351, label %arrlike.ic.inline.270, label %arrlike.ic.spill_or_miss.281

arrlike.ic.inline.270:                            ; preds = %arrlike.ic.range.269
  %r1354 = shl i64 %r1349, 3
  %r1355 = add i64 %r1354, 16
  %r1356 = add i64 %r1208, %r1355
  %r1357 = inttoptr i64 %r1356 to ptr
  %r1358 = load double, ptr %r1357, align 8
  br label %tav.get.merge.238

arrlike.ic.spill.271:                             ; preds = %arrlike.ic.spill_or_miss.281
  %r1359 = add nuw nsw i64 %r1208, 8
  %r1360 = inttoptr i64 %r1359 to ptr
  %r1361 = load i64, ptr %r1360, align 8
  %r1362 = icmp ne i64 %r1361, 0
  br i1 %r1362, label %arrlike.ic.spill_ptr.272, label %arrlike.ic.miss.274

arrlike.ic.spill_ptr.272:                         ; preds = %arrlike.ic.spill.271
  %r1363 = inttoptr i64 %r1361 to ptr
  %r1364 = getelementptr i64, ptr %r1363, i64 4
  %r1365 = load i64, ptr %r1364, align 8
  %r1366 = icmp ne i64 %r1365, 0
  %r1367 = select i1 %r1366, i64 %r1365, i64 %r1361
  %r1368 = inttoptr i64 %r1367 to ptr
  %r1369 = load i32, ptr %r1368, align 4
  %r1370 = zext i32 %r1369 to i64
  %r1371 = icmp ult i64 %r1349, %r1370
  %r1372 = and i1 %r1366, %r1371
  br i1 %r1372, label %arrlike.ic.spill_load.273, label %arrlike.ic.miss.274

arrlike.ic.spill_load.273:                        ; preds = %arrlike.ic.spill_ptr.272
  %r1373 = add nuw nsw i64 %r1349, 1
  %r1374 = getelementptr inbounds nuw i64, ptr %r1368, i64 %r1373
  %r1375 = load double, ptr %r1374, align 8
  br label %tav.get.merge.238

arrlike.ic.miss.274:                              ; preds = %arrlike.ic.spill_or_miss.281, %arrlike.elem.load.279, %arrlike.elem.bounds.278, %arrlike.elem.kind.275, %arrlike.ic.spill_ptr.272, %arrlike.ic.spill.271, %arrlike.ic.length_spill_ptr.267, %arrlike.ic.length_spill_meta.266, %arrlike.ic.family_token.263, %arrlike.ic.family_meta.262, %arrlike.ic.exact.261, %arrlike.ic.shape.259, %arrlike.ic.array_guard.257, %arrlike.ic.header.255, %tav.get.slow.237
  %statepoint_token359 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r1110, double 0.000000e+00, ptr @perry_ic_test_json_template_capture_ts__16, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.15944, ptr addrspace(1) %.15, ptr addrspace(1) %.15988, ptr addrspace(1) %.151029, ptr addrspace(1) %.121067, ptr addrspace(1) %.111088) ]
  %r1376360 = call double @llvm.experimental.gc.result.f64(token %statepoint_token359)
  %r57.0.relocated361 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token359, i32 0, i32 0) ; (%.15944, %.15944)
  %rs4gc.s12.relocated362 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token359, i32 1, i32 1) ; (%.15, %.15)
  %r48.0.base.relocated363 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token359, i32 2, i32 2) ; (%.15988, %.15988)
  %r48.0.relocated364 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token359, i32 2, i32 3) ; (%.15988, %.151029)
  %rs4gc.s15.relocated365 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token359, i32 4, i32 4) ; (%.121067, %.121067)
  %rs4gc.s19.relocated366 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token359, i32 5, i32 5) ; (%.111088, %.111088)
  br label %tav.get.merge.238

arrlike.elem.kind.275:                            ; preds = %arrlike.ic.brand.256
  %r1232 = icmp eq i8 %r1224, 2
  br i1 %r1232, label %arrlike.elem.meta.276, label %arrlike.ic.miss.274

arrlike.elem.meta.276:                            ; preds = %arrlike.elem.kind.275
  %r1233 = add nuw nsw i64 %r1208, 8
  %r1234 = inttoptr i64 %r1233 to ptr
  %r1235 = load i64, ptr %r1234, align 8
  %r1236 = icmp ne i64 %r1235, 0
  br i1 %r1236, label %arrlike.elem.store.277, label %arrlike.ic.shape.259

arrlike.elem.store.277:                           ; preds = %arrlike.elem.meta.276
  %r1237 = inttoptr i64 %r1235 to ptr
  %r1238 = getelementptr i64, ptr %r1237, i64 12
  %r1239 = load i64, ptr %r1238, align 8
  %r1240 = icmp ne i64 %r1239, 0
  br i1 %r1240, label %arrlike.elem.bounds.278, label %arrlike.ic.shape.259

arrlike.elem.bounds.278:                          ; preds = %arrlike.elem.store.277
  %r1241 = sub i64 %r1239, 8
  %r1242 = inttoptr i64 %r1241 to ptr
  %r1243 = load i8, ptr %r1242, align 1
  %r1244 = icmp eq i8 %r1243, 1
  %r1245 = sub i64 %r1239, 7
  %r1246 = inttoptr i64 %r1245 to ptr
  %r1247 = load i8, ptr %r1246, align 1
  %r1248 = and i8 %r1247, -128
  %r1249 = icmp eq i8 %r1248, 0
  %r1250 = inttoptr i64 %r1239 to ptr
  %r1251 = load i32, ptr %r1250, align 4
  %r1252 = zext i32 %r1251 to i64
  %r1253 = icmp ult i64 0, %r1252
  %r1254 = and i1 %r1244, %r1249
  %r1255 = and i1 %r1254, %r1253
  br i1 %r1255, label %arrlike.elem.load.279, label %arrlike.ic.miss.274

arrlike.elem.load.279:                            ; preds = %arrlike.elem.bounds.278
  %r1257 = add i64 %r1239, 8
  %r1258 = add nuw nsw i64 %r1257, 0
  %r1259 = inttoptr i64 %r1258 to ptr
  %r1260 = load double, ptr %r1259, align 8
  %r1261 = bitcast double %r1260 to i64
  %r1262 = icmp eq i64 %r1261, 9222246136947933200
  br i1 %r1262, label %arrlike.ic.miss.274, label %arrlike.elem.value.280

arrlike.elem.value.280:                           ; preds = %arrlike.elem.load.279
  br label %tav.get.merge.238

arrlike.ic.spill_or_miss.281:                     ; preds = %arrlike.ic.range.269
  br i1 %r1353, label %arrlike.ic.spill.271, label %arrlike.ic.miss.274

streqlit.tag.282:                                 ; preds = %tav.get.merge.238
  %r1382 = lshr i64 %r1379, 48
  %r1383 = icmp eq i64 %r1382, 32767
  %r1384 = and i64 %r1379, 281474976710655
  %r1385 = icmp ugt i64 %r1384, 4095
  %r1386 = and i1 %r1383, %r1385
  br i1 %r1386, label %streqlit.len.283, label %streqlit.false.288

streqlit.len.283:                                 ; preds = %streqlit.tag.282
  %r1387 = inttoptr i64 %r1384 to ptr
  %r1388 = getelementptr inbounds nuw i8, ptr %r1387, i64 4
  %r1389 = load i32, ptr %r1388, align 4
  %r1390 = icmp eq i32 %r1389, 7
  br i1 %r1390, label %streqlit.b0.284, label %streqlit.false.288

streqlit.b0.284:                                  ; preds = %streqlit.len.283
  %r1391 = getelementptr inbounds nuw i8, ptr %r1387, i64 20
  %r1392 = load i8, ptr %r1391, align 1
  %r1393 = icmp eq i8 %r1392, 99
  br i1 %r1393, label %streqlit.bl.285, label %streqlit.false.288

streqlit.bl.285:                                  ; preds = %streqlit.b0.284
  %r1394 = getelementptr inbounds nuw i8, ptr %r1387, i64 26
  %r1395 = load i8, ptr %r1394, align 1
  %r1396 = icmp eq i8 %r1395, 100
  br i1 %r1396, label %streqlit.slow.286, label %streqlit.false.288

streqlit.slow.286:                                ; preds = %streqlit.bl.285
  %r1397 = and i64 %r1380, 281474976710655
  %statepoint_token367 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1384, i64 %r1397, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.17946, ptr addrspace(1) %.17, ptr addrspace(1) %.17990, ptr addrspace(1) %.171031, ptr addrspace(1) %.141069, ptr addrspace(1) %.131090) ]
  %r1398368 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token367)
  %r57.0.relocated369 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token367, i32 0, i32 0) ; (%.17946, %.17946)
  %rs4gc.s12.relocated370 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token367, i32 1, i32 1) ; (%.17, %.17)
  %r48.0.base.relocated371 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token367, i32 2, i32 2) ; (%.17990, %.17990)
  %r48.0.relocated372 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token367, i32 2, i32 3) ; (%.17990, %.171031)
  %rs4gc.s15.relocated373 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token367, i32 4, i32 4) ; (%.141069, %.141069)
  %rs4gc.s19.relocated374 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token367, i32 5, i32 5) ; (%.131090, %.131090)
  %r1399 = icmp ne i32 %r1398368, 0
  br label %streqlit.merge.289

streqlit.true.287:                                ; preds = %tav.get.merge.238
  br label %streqlit.merge.289

streqlit.false.288:                               ; preds = %streqlit.bl.285, %streqlit.b0.284, %streqlit.len.283, %streqlit.tag.282
  br label %streqlit.merge.289

streqlit.merge.289:                               ; preds = %streqlit.false.288, %streqlit.true.287, %streqlit.slow.286
  %.101087 = phi ptr addrspace(1) [ %.131090, %streqlit.true.287 ], [ %rs4gc.s19.relocated374, %streqlit.slow.286 ], [ %.131090, %streqlit.false.288 ]
  %.111066 = phi ptr addrspace(1) [ %.141069, %streqlit.true.287 ], [ %rs4gc.s15.relocated373, %streqlit.slow.286 ], [ %.141069, %streqlit.false.288 ]
  %.141028 = phi ptr addrspace(1) [ %.171031, %streqlit.true.287 ], [ %r48.0.relocated372, %streqlit.slow.286 ], [ %.171031, %streqlit.false.288 ]
  %.14987 = phi ptr addrspace(1) [ %.17990, %streqlit.true.287 ], [ %r48.0.base.relocated371, %streqlit.slow.286 ], [ %.17990, %streqlit.false.288 ]
  %.14943 = phi ptr addrspace(1) [ %.17946, %streqlit.true.287 ], [ %r57.0.relocated369, %streqlit.slow.286 ], [ %.17946, %streqlit.false.288 ]
  %.14 = phi ptr addrspace(1) [ %.17, %streqlit.true.287 ], [ %rs4gc.s12.relocated370, %streqlit.slow.286 ], [ %.17, %streqlit.false.288 ]
  %r1400 = phi i1 [ true, %streqlit.true.287 ], [ false, %streqlit.false.288 ], [ %r1399, %streqlit.slow.286 ]
  %r1401 = select i1 %r1400, i64 9222246136947933188, i64 9222246136947933187
  %r1402 = bitcast i64 %r1401 to double
  %r1403 = icmp eq i64 %r1401, 9222246136947933188
  br label %logical.merge.203

if.then.290:                                      ; preds = %logical.merge.203
  %r1406 = load double, ptr @test_json_template_capture_ts_.str.13.handle, align 8
  %statepoint_token375 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r1406, i32 0, i32 0)
  %r1407376 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token375)
  %r1408 = or i64 %r1407376, 9222527611924643840
  %r1409 = bitcast i64 %r1408 to double
  %statepoint_token377 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r1409, i32 0, i32 0)
  unreachable

if.else.291:                                      ; preds = %logical.merge.203
  br label %if.merge.292

if.merge.292:                                     ; preds = %if.else.291
  %r1411.rs4i = ptrtoint ptr addrspace(1) %.101065 to i64
  %r1411.rs4o = call i64 asm "", "=r,0"(i64 %r1411.rs4i) #7
  %r1411 = bitcast i64 %r1411.rs4o to double
  %statepoint_token378 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r1411, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13942, ptr addrspace(1) %.13, ptr addrspace(1) %.13986, ptr addrspace(1) %.131027, ptr addrspace(1) %.101065, ptr addrspace(1) %.91086) ]
  %r1412379 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token378)
  %r57.0.relocated380 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token378, i32 0, i32 0) ; (%.13942, %.13942)
  %rs4gc.s12.relocated381 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token378, i32 1, i32 1) ; (%.13, %.13)
  %r48.0.base.relocated382 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token378, i32 2, i32 2) ; (%.13986, %.13986)
  %r48.0.relocated383 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token378, i32 2, i32 3) ; (%.13986, %.131027)
  %rs4gc.s15.relocated384 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token378, i32 4, i32 4) ; (%.101065, %.101065)
  %rs4gc.s19.relocated385 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token378, i32 5, i32 5) ; (%.91086, %.91086)
  %statepoint_token386 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r1412379, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated380, ptr addrspace(1) %rs4gc.s12.relocated381, ptr addrspace(1) %r48.0.base.relocated382, ptr addrspace(1) %r48.0.relocated383, ptr addrspace(1) %rs4gc.s15.relocated384, ptr addrspace(1) %rs4gc.s19.relocated385) ]
  %r1413387 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token386)
  %r57.0.relocated388 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token386, i32 0, i32 0) ; (%r57.0.relocated380, %r57.0.relocated380)
  %rs4gc.s12.relocated389 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token386, i32 1, i32 1) ; (%rs4gc.s12.relocated381, %rs4gc.s12.relocated381)
  %r48.0.base.relocated390 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token386, i32 2, i32 2) ; (%r48.0.base.relocated382, %r48.0.base.relocated382)
  %r48.0.relocated391 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token386, i32 2, i32 3) ; (%r48.0.base.relocated382, %r48.0.relocated383)
  %rs4gc.s15.relocated392 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token386, i32 4, i32 4) ; (%rs4gc.s15.relocated384, %rs4gc.s15.relocated384)
  %rs4gc.s19.relocated393 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token386, i32 5, i32 5) ; (%rs4gc.s19.relocated385, %rs4gc.s19.relocated385)
  %r1414 = bitcast i64 %r1413387 to double
  %rs4gc.b20 = bitcast double %r1414 to i64
  %rs4gc.s20 = inttoptr i64 %rs4gc.b20 to ptr addrspace(1)
  %r1415.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r1415 = call i64 asm "", "=r,0"(i64 %r1415.rs4i) #7
  %r1416 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1417 = icmp ne i32 %r1416, 0
  br i1 %r1417, label %shadow.root.barrier.293, label %shadow.root.barrier.done.294

shadow.root.barrier.293:                          ; preds = %if.merge.292
  call void @js_write_barrier_root_nanbox(i64 %r1415) #7
  br label %shadow.root.barrier.done.294

shadow.root.barrier.done.294:                     ; preds = %shadow.root.barrier.293, %if.merge.292
  %r1418.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19.relocated393 to i64
  %r1418.rs4o = call i64 asm "", "=r,0"(i64 %r1418.rs4i) #7
  %r1418 = bitcast i64 %r1418.rs4o to double
  %statepoint_token394 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1418, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s20, ptr addrspace(1) %r57.0.relocated388, ptr addrspace(1) %rs4gc.s12.relocated389, ptr addrspace(1) %r48.0.base.relocated390, ptr addrspace(1) %r48.0.relocated391, ptr addrspace(1) %rs4gc.s15.relocated392, ptr addrspace(1) %rs4gc.s19.relocated393) ]
  %r1419395 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token394)
  %rs4gc.s20.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 0, i32 0) ; (%rs4gc.s20, %rs4gc.s20)
  %r57.0.relocated396 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 1, i32 1) ; (%r57.0.relocated388, %r57.0.relocated388)
  %rs4gc.s12.relocated397 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 2, i32 2) ; (%rs4gc.s12.relocated389, %rs4gc.s12.relocated389)
  %r48.0.base.relocated398 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 3, i32 3) ; (%r48.0.base.relocated390, %r48.0.base.relocated390)
  %r48.0.relocated399 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 3, i32 4) ; (%r48.0.base.relocated390, %r48.0.relocated391)
  %rs4gc.s15.relocated400 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 5, i32 5) ; (%rs4gc.s15.relocated392, %rs4gc.s15.relocated392)
  %rs4gc.s19.relocated401 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token394, i32 6, i32 6) ; (%rs4gc.s19.relocated393, %rs4gc.s19.relocated393)
  %r1420 = bitcast i64 %r1419395 to double
  %r1421.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15.relocated400 to i64
  %r1421.rs4o = call i64 asm "", "=r,0"(i64 %r1421.rs4i) #7
  %r1421 = bitcast i64 %r1421.rs4o to double
  %r1422 = bitcast double %r1421 to i64
  %r1423 = icmp eq i64 %r1419395, %r1422
  br i1 %r1423, label %streq.true.299, label %streq.tag.295

streq.tag.295:                                    ; preds = %shadow.root.barrier.done.294
  %r1424 = lshr i64 %r1419395, 48
  %r1425 = lshr i64 %r1422, 48
  %r1426 = icmp eq i64 %r1424, 32767
  %r1427 = icmp eq i64 %r1425, 32767
  %r1428 = and i1 %r1426, %r1427
  br i1 %r1428, label %streq.heap.296, label %streq.ssochk.297

streq.heap.296:                                   ; preds = %streq.tag.295
  %r1429 = and i64 %r1419395, 281474976710655
  %r1430 = and i64 %r1422, 281474976710655
  %statepoint_token402 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1429, i64 %r1430, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s20.relocated, ptr addrspace(1) %r57.0.relocated396, ptr addrspace(1) %rs4gc.s12.relocated397, ptr addrspace(1) %r48.0.base.relocated398, ptr addrspace(1) %r48.0.relocated399, ptr addrspace(1) %rs4gc.s15.relocated400, ptr addrspace(1) %rs4gc.s19.relocated401) ]
  %r1431403 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token402)
  %rs4gc.s20.relocated404 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token402, i32 0, i32 0) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  %r57.0.relocated405 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token402, i32 1, i32 1) ; (%r57.0.relocated396, %r57.0.relocated396)
  %rs4gc.s12.relocated406 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token402, i32 2, i32 2) ; (%rs4gc.s12.relocated397, %rs4gc.s12.relocated397)
  %r48.0.base.relocated407 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token402, i32 3, i32 3) ; (%r48.0.base.relocated398, %r48.0.base.relocated398)
  %r48.0.relocated408 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token402, i32 3, i32 4) ; (%r48.0.base.relocated398, %r48.0.relocated399)
  %rs4gc.s15.relocated409 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token402, i32 5, i32 5) ; (%rs4gc.s15.relocated400, %rs4gc.s15.relocated400)
  %rs4gc.s19.relocated410 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token402, i32 6, i32 6) ; (%rs4gc.s19.relocated401, %rs4gc.s19.relocated401)
  br label %streq.merge.301

streq.ssochk.297:                                 ; preds = %streq.tag.295
  %r1432 = icmp eq i64 %r1424, 32761
  %r1433 = icmp eq i64 %r1425, 32761
  %r1434 = and i1 %r1432, %r1433
  br i1 %r1434, label %streq.false.300, label %streq.boxed.298

streq.boxed.298:                                  ; preds = %streq.ssochk.297
  %statepoint_token411 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r1420, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s20.relocated, ptr addrspace(1) %r57.0.relocated396, ptr addrspace(1) %rs4gc.s12.relocated397, ptr addrspace(1) %r48.0.base.relocated398, ptr addrspace(1) %r48.0.relocated399, ptr addrspace(1) %rs4gc.s15.relocated400, ptr addrspace(1) %rs4gc.s19.relocated401) ]
  %r1435412 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token411)
  %rs4gc.s20.relocated413 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 0, i32 0) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  %r57.0.relocated414 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 1, i32 1) ; (%r57.0.relocated396, %r57.0.relocated396)
  %rs4gc.s12.relocated415 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 2, i32 2) ; (%rs4gc.s12.relocated397, %rs4gc.s12.relocated397)
  %r48.0.base.relocated416 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 3, i32 3) ; (%r48.0.base.relocated398, %r48.0.base.relocated398)
  %r48.0.relocated417 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 3, i32 4) ; (%r48.0.base.relocated398, %r48.0.relocated399)
  %rs4gc.s15.relocated418 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 5, i32 5) ; (%rs4gc.s15.relocated400, %rs4gc.s15.relocated400)
  %rs4gc.s19.relocated419 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token411, i32 6, i32 6) ; (%rs4gc.s19.relocated401, %rs4gc.s19.relocated401)
  %r3581.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15.relocated418 to i64
  %r3581.rs4o = call i64 asm "", "=r,0"(i64 %r3581.rs4i) #7
  %r3581 = bitcast i64 %r3581.rs4o to double
  %statepoint_token420 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r3581, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s20.relocated413, ptr addrspace(1) %r57.0.relocated414, ptr addrspace(1) %rs4gc.s12.relocated415, ptr addrspace(1) %r48.0.base.relocated416, ptr addrspace(1) %r48.0.relocated417, ptr addrspace(1) %rs4gc.s15.relocated418, ptr addrspace(1) %rs4gc.s19.relocated419) ]
  %r1436421 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token420)
  %rs4gc.s20.relocated422 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token420, i32 0, i32 0) ; (%rs4gc.s20.relocated413, %rs4gc.s20.relocated413)
  %r57.0.relocated423 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token420, i32 1, i32 1) ; (%r57.0.relocated414, %r57.0.relocated414)
  %rs4gc.s12.relocated424 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token420, i32 2, i32 2) ; (%rs4gc.s12.relocated415, %rs4gc.s12.relocated415)
  %r48.0.base.relocated425 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token420, i32 3, i32 3) ; (%r48.0.base.relocated416, %r48.0.base.relocated416)
  %r48.0.relocated426 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token420, i32 3, i32 4) ; (%r48.0.base.relocated416, %r48.0.relocated417)
  %rs4gc.s15.relocated427 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token420, i32 5, i32 5) ; (%rs4gc.s15.relocated418, %rs4gc.s15.relocated418)
  %rs4gc.s19.relocated428 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token420, i32 6, i32 6) ; (%rs4gc.s19.relocated419, %rs4gc.s19.relocated419)
  %statepoint_token429 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1435412, i64 %r1436421, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s20.relocated422, ptr addrspace(1) %r57.0.relocated423, ptr addrspace(1) %rs4gc.s12.relocated424, ptr addrspace(1) %r48.0.base.relocated425, ptr addrspace(1) %r48.0.relocated426, ptr addrspace(1) %rs4gc.s15.relocated427, ptr addrspace(1) %rs4gc.s19.relocated428) ]
  %r1437430 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token429)
  %rs4gc.s20.relocated431 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token429, i32 0, i32 0) ; (%rs4gc.s20.relocated422, %rs4gc.s20.relocated422)
  %r57.0.relocated432 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token429, i32 1, i32 1) ; (%r57.0.relocated423, %r57.0.relocated423)
  %rs4gc.s12.relocated433 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token429, i32 2, i32 2) ; (%rs4gc.s12.relocated424, %rs4gc.s12.relocated424)
  %r48.0.base.relocated434 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token429, i32 3, i32 3) ; (%r48.0.base.relocated425, %r48.0.base.relocated425)
  %r48.0.relocated435 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token429, i32 3, i32 4) ; (%r48.0.base.relocated425, %r48.0.relocated426)
  %rs4gc.s15.relocated436 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token429, i32 5, i32 5) ; (%rs4gc.s15.relocated427, %rs4gc.s15.relocated427)
  %rs4gc.s19.relocated437 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token429, i32 6, i32 6) ; (%rs4gc.s19.relocated428, %rs4gc.s19.relocated428)
  br label %streq.merge.301

streq.true.299:                                   ; preds = %shadow.root.barrier.done.294
  br label %streq.merge.301

streq.false.300:                                  ; preds = %streq.ssochk.297
  br label %streq.merge.301

streq.merge.301:                                  ; preds = %streq.false.300, %streq.true.299, %streq.boxed.298, %streq.heap.296
  %.01094 = phi ptr addrspace(1) [ %rs4gc.s20.relocated, %streq.true.299 ], [ %rs4gc.s20.relocated404, %streq.heap.296 ], [ %rs4gc.s20.relocated, %streq.false.300 ], [ %rs4gc.s20.relocated431, %streq.boxed.298 ]
  %.141091 = phi ptr addrspace(1) [ %rs4gc.s19.relocated401, %streq.true.299 ], [ %rs4gc.s19.relocated410, %streq.heap.296 ], [ %rs4gc.s19.relocated401, %streq.false.300 ], [ %rs4gc.s19.relocated437, %streq.boxed.298 ]
  %.151070 = phi ptr addrspace(1) [ %rs4gc.s15.relocated400, %streq.true.299 ], [ %rs4gc.s15.relocated409, %streq.heap.296 ], [ %rs4gc.s15.relocated400, %streq.false.300 ], [ %rs4gc.s15.relocated436, %streq.boxed.298 ]
  %.181032 = phi ptr addrspace(1) [ %r48.0.relocated399, %streq.true.299 ], [ %r48.0.relocated408, %streq.heap.296 ], [ %r48.0.relocated399, %streq.false.300 ], [ %r48.0.relocated435, %streq.boxed.298 ]
  %.18991 = phi ptr addrspace(1) [ %r48.0.base.relocated398, %streq.true.299 ], [ %r48.0.base.relocated407, %streq.heap.296 ], [ %r48.0.base.relocated398, %streq.false.300 ], [ %r48.0.base.relocated434, %streq.boxed.298 ]
  %.18947 = phi ptr addrspace(1) [ %r57.0.relocated396, %streq.true.299 ], [ %r57.0.relocated405, %streq.heap.296 ], [ %r57.0.relocated396, %streq.false.300 ], [ %r57.0.relocated432, %streq.boxed.298 ]
  %.18 = phi ptr addrspace(1) [ %rs4gc.s12.relocated397, %streq.true.299 ], [ %rs4gc.s12.relocated406, %streq.heap.296 ], [ %rs4gc.s12.relocated397, %streq.false.300 ], [ %rs4gc.s12.relocated433, %streq.boxed.298 ]
  %r1438 = phi i32 [ 1, %streq.true.299 ], [ 0, %streq.false.300 ], [ %r1431403, %streq.heap.296 ], [ %r1437430, %streq.boxed.298 ]
  %r1439 = icmp ne i32 %r1438, 0
  %r1440 = xor i1 %r1439, true
  %r1441 = select i1 %r1440, i64 9222246136947933188, i64 9222246136947933187
  %r1442 = bitcast i64 %r1441 to double
  %r1443 = icmp eq i64 %r1441, 9222246136947933188
  br i1 %r1443, label %logical.merge.303, label %logical.then.302

logical.then.302:                                 ; preds = %streq.merge.301
  %r1444.rs4i = ptrtoint ptr addrspace(1) %.01094 to i64
  %r1444.rs4o = call i64 asm "", "=r,0"(i64 %r1444.rs4i) #7
  %r1444 = bitcast i64 %r1444.rs4o to double
  %statepoint_token438 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1444, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01094, ptr addrspace(1) %.18947, ptr addrspace(1) %.18, ptr addrspace(1) %.18991, ptr addrspace(1) %.181032, ptr addrspace(1) %.151070, ptr addrspace(1) %.141091) ]
  %r1445439 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token438)
  %rs4gc.s20.relocated440 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token438, i32 0, i32 0) ; (%.01094, %.01094)
  %r57.0.relocated441 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token438, i32 1, i32 1) ; (%.18947, %.18947)
  %rs4gc.s12.relocated442 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token438, i32 2, i32 2) ; (%.18, %.18)
  %r48.0.base.relocated443 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token438, i32 3, i32 3) ; (%.18991, %.18991)
  %r48.0.relocated444 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token438, i32 3, i32 4) ; (%.18991, %.181032)
  %rs4gc.s15.relocated445 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token438, i32 5, i32 5) ; (%.151070, %.151070)
  %rs4gc.s19.relocated446 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token438, i32 6, i32 6) ; (%.141091, %.141091)
  %r1446 = bitcast i64 %r1445439 to double
  %r1447.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15.relocated445 to i64
  %r1447.rs4o = call i64 asm "", "=r,0"(i64 %r1447.rs4i) #7
  %r1447 = bitcast i64 %r1447.rs4o to double
  %r1448 = bitcast double %r1447 to i64
  %r1449 = icmp eq i64 %r1445439, %r1448
  br i1 %r1449, label %streq.true.308, label %streq.tag.304

logical.merge.303:                                ; preds = %streq.merge.310, %streq.merge.301
  %.11095 = phi ptr addrspace(1) [ %.01094, %streq.merge.301 ], [ %.21096, %streq.merge.310 ]
  %.151092 = phi ptr addrspace(1) [ %.141091, %streq.merge.301 ], [ %.161093, %streq.merge.310 ]
  %.161071 = phi ptr addrspace(1) [ %.151070, %streq.merge.301 ], [ %.171072, %streq.merge.310 ]
  %.191033 = phi ptr addrspace(1) [ %.181032, %streq.merge.301 ], [ %.201034, %streq.merge.310 ]
  %.19992 = phi ptr addrspace(1) [ %.18991, %streq.merge.301 ], [ %.20993, %streq.merge.310 ]
  %.19948 = phi ptr addrspace(1) [ %.18947, %streq.merge.301 ], [ %.20949, %streq.merge.310 ]
  %.19 = phi ptr addrspace(1) [ %.18, %streq.merge.301 ], [ %.20, %streq.merge.310 ]
  %r1470 = phi double [ %r1442, %streq.merge.301 ], [ %r1468, %streq.merge.310 ]
  %r1471 = phi i1 [ true, %streq.merge.301 ], [ %r1469, %streq.merge.310 ]
  br i1 %r1471, label %if.then.311, label %if.else.312

streq.tag.304:                                    ; preds = %logical.then.302
  %r1450 = lshr i64 %r1445439, 48
  %r1451 = lshr i64 %r1448, 48
  %r1452 = icmp eq i64 %r1450, 32767
  %r1453 = icmp eq i64 %r1451, 32767
  %r1454 = and i1 %r1452, %r1453
  br i1 %r1454, label %streq.heap.305, label %streq.ssochk.306

streq.heap.305:                                   ; preds = %streq.tag.304
  %r1455 = and i64 %r1445439, 281474976710655
  %r1456 = and i64 %r1448, 281474976710655
  %statepoint_token447 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1455, i64 %r1456, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s20.relocated440, ptr addrspace(1) %r57.0.relocated441, ptr addrspace(1) %rs4gc.s12.relocated442, ptr addrspace(1) %r48.0.base.relocated443, ptr addrspace(1) %r48.0.relocated444, ptr addrspace(1) %rs4gc.s15.relocated445, ptr addrspace(1) %rs4gc.s19.relocated446) ]
  %r1457448 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token447)
  %rs4gc.s20.relocated449 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 0, i32 0) ; (%rs4gc.s20.relocated440, %rs4gc.s20.relocated440)
  %r57.0.relocated450 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 1, i32 1) ; (%r57.0.relocated441, %r57.0.relocated441)
  %rs4gc.s12.relocated451 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 2, i32 2) ; (%rs4gc.s12.relocated442, %rs4gc.s12.relocated442)
  %r48.0.base.relocated452 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 3, i32 3) ; (%r48.0.base.relocated443, %r48.0.base.relocated443)
  %r48.0.relocated453 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 3, i32 4) ; (%r48.0.base.relocated443, %r48.0.relocated444)
  %rs4gc.s15.relocated454 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 5, i32 5) ; (%rs4gc.s15.relocated445, %rs4gc.s15.relocated445)
  %rs4gc.s19.relocated455 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token447, i32 6, i32 6) ; (%rs4gc.s19.relocated446, %rs4gc.s19.relocated446)
  br label %streq.merge.310

streq.ssochk.306:                                 ; preds = %streq.tag.304
  %r1458 = icmp eq i64 %r1450, 32761
  %r1459 = icmp eq i64 %r1451, 32761
  %r1460 = and i1 %r1458, %r1459
  br i1 %r1460, label %streq.false.309, label %streq.boxed.307

streq.boxed.307:                                  ; preds = %streq.ssochk.306
  %statepoint_token456 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r1446, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s20.relocated440, ptr addrspace(1) %r57.0.relocated441, ptr addrspace(1) %rs4gc.s12.relocated442, ptr addrspace(1) %r48.0.base.relocated443, ptr addrspace(1) %r48.0.relocated444, ptr addrspace(1) %rs4gc.s15.relocated445, ptr addrspace(1) %rs4gc.s19.relocated446) ]
  %r1461457 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token456)
  %rs4gc.s20.relocated458 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token456, i32 0, i32 0) ; (%rs4gc.s20.relocated440, %rs4gc.s20.relocated440)
  %r57.0.relocated459 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token456, i32 1, i32 1) ; (%r57.0.relocated441, %r57.0.relocated441)
  %rs4gc.s12.relocated460 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token456, i32 2, i32 2) ; (%rs4gc.s12.relocated442, %rs4gc.s12.relocated442)
  %r48.0.base.relocated461 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token456, i32 3, i32 3) ; (%r48.0.base.relocated443, %r48.0.base.relocated443)
  %r48.0.relocated462 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token456, i32 3, i32 4) ; (%r48.0.base.relocated443, %r48.0.relocated444)
  %rs4gc.s15.relocated463 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token456, i32 5, i32 5) ; (%rs4gc.s15.relocated445, %rs4gc.s15.relocated445)
  %rs4gc.s19.relocated464 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token456, i32 6, i32 6) ; (%rs4gc.s19.relocated446, %rs4gc.s19.relocated446)
  %r3580.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15.relocated463 to i64
  %r3580.rs4o = call i64 asm "", "=r,0"(i64 %r3580.rs4i) #7
  %r3580 = bitcast i64 %r3580.rs4o to double
  %statepoint_token465 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r3580, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s20.relocated458, ptr addrspace(1) %r57.0.relocated459, ptr addrspace(1) %rs4gc.s12.relocated460, ptr addrspace(1) %r48.0.base.relocated461, ptr addrspace(1) %r48.0.relocated462, ptr addrspace(1) %rs4gc.s15.relocated463, ptr addrspace(1) %rs4gc.s19.relocated464) ]
  %r1462466 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token465)
  %rs4gc.s20.relocated467 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token465, i32 0, i32 0) ; (%rs4gc.s20.relocated458, %rs4gc.s20.relocated458)
  %r57.0.relocated468 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token465, i32 1, i32 1) ; (%r57.0.relocated459, %r57.0.relocated459)
  %rs4gc.s12.relocated469 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token465, i32 2, i32 2) ; (%rs4gc.s12.relocated460, %rs4gc.s12.relocated460)
  %r48.0.base.relocated470 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token465, i32 3, i32 3) ; (%r48.0.base.relocated461, %r48.0.base.relocated461)
  %r48.0.relocated471 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token465, i32 3, i32 4) ; (%r48.0.base.relocated461, %r48.0.relocated462)
  %rs4gc.s15.relocated472 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token465, i32 5, i32 5) ; (%rs4gc.s15.relocated463, %rs4gc.s15.relocated463)
  %rs4gc.s19.relocated473 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token465, i32 6, i32 6) ; (%rs4gc.s19.relocated464, %rs4gc.s19.relocated464)
  %statepoint_token474 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1461457, i64 %r1462466, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s20.relocated467, ptr addrspace(1) %r57.0.relocated468, ptr addrspace(1) %rs4gc.s12.relocated469, ptr addrspace(1) %r48.0.base.relocated470, ptr addrspace(1) %r48.0.relocated471, ptr addrspace(1) %rs4gc.s15.relocated472, ptr addrspace(1) %rs4gc.s19.relocated473) ]
  %r1463475 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token474)
  %rs4gc.s20.relocated476 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token474, i32 0, i32 0) ; (%rs4gc.s20.relocated467, %rs4gc.s20.relocated467)
  %r57.0.relocated477 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token474, i32 1, i32 1) ; (%r57.0.relocated468, %r57.0.relocated468)
  %rs4gc.s12.relocated478 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token474, i32 2, i32 2) ; (%rs4gc.s12.relocated469, %rs4gc.s12.relocated469)
  %r48.0.base.relocated479 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token474, i32 3, i32 3) ; (%r48.0.base.relocated470, %r48.0.base.relocated470)
  %r48.0.relocated480 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token474, i32 3, i32 4) ; (%r48.0.base.relocated470, %r48.0.relocated471)
  %rs4gc.s15.relocated481 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token474, i32 5, i32 5) ; (%rs4gc.s15.relocated472, %rs4gc.s15.relocated472)
  %rs4gc.s19.relocated482 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token474, i32 6, i32 6) ; (%rs4gc.s19.relocated473, %rs4gc.s19.relocated473)
  br label %streq.merge.310

streq.true.308:                                   ; preds = %logical.then.302
  br label %streq.merge.310

streq.false.309:                                  ; preds = %streq.ssochk.306
  br label %streq.merge.310

streq.merge.310:                                  ; preds = %streq.false.309, %streq.true.308, %streq.boxed.307, %streq.heap.305
  %.21096 = phi ptr addrspace(1) [ %rs4gc.s20.relocated440, %streq.true.308 ], [ %rs4gc.s20.relocated449, %streq.heap.305 ], [ %rs4gc.s20.relocated440, %streq.false.309 ], [ %rs4gc.s20.relocated476, %streq.boxed.307 ]
  %.161093 = phi ptr addrspace(1) [ %rs4gc.s19.relocated446, %streq.true.308 ], [ %rs4gc.s19.relocated455, %streq.heap.305 ], [ %rs4gc.s19.relocated446, %streq.false.309 ], [ %rs4gc.s19.relocated482, %streq.boxed.307 ]
  %.171072 = phi ptr addrspace(1) [ %rs4gc.s15.relocated445, %streq.true.308 ], [ %rs4gc.s15.relocated454, %streq.heap.305 ], [ %rs4gc.s15.relocated445, %streq.false.309 ], [ %rs4gc.s15.relocated481, %streq.boxed.307 ]
  %.201034 = phi ptr addrspace(1) [ %r48.0.relocated444, %streq.true.308 ], [ %r48.0.relocated453, %streq.heap.305 ], [ %r48.0.relocated444, %streq.false.309 ], [ %r48.0.relocated480, %streq.boxed.307 ]
  %.20993 = phi ptr addrspace(1) [ %r48.0.base.relocated443, %streq.true.308 ], [ %r48.0.base.relocated452, %streq.heap.305 ], [ %r48.0.base.relocated443, %streq.false.309 ], [ %r48.0.base.relocated479, %streq.boxed.307 ]
  %.20949 = phi ptr addrspace(1) [ %r57.0.relocated441, %streq.true.308 ], [ %r57.0.relocated450, %streq.heap.305 ], [ %r57.0.relocated441, %streq.false.309 ], [ %r57.0.relocated477, %streq.boxed.307 ]
  %.20 = phi ptr addrspace(1) [ %rs4gc.s12.relocated442, %streq.true.308 ], [ %rs4gc.s12.relocated451, %streq.heap.305 ], [ %rs4gc.s12.relocated442, %streq.false.309 ], [ %rs4gc.s12.relocated478, %streq.boxed.307 ]
  %r1464 = phi i32 [ 1, %streq.true.308 ], [ 0, %streq.false.309 ], [ %r1457448, %streq.heap.305 ], [ %r1463475, %streq.boxed.307 ]
  %r1465 = icmp ne i32 %r1464, 0
  %r1466 = xor i1 %r1465, true
  %r1467 = select i1 %r1466, i64 9222246136947933188, i64 9222246136947933187
  %r1468 = bitcast i64 %r1467 to double
  %r1469 = icmp eq i64 %r1467, 9222246136947933188
  br label %logical.merge.303

if.then.311:                                      ; preds = %logical.merge.303
  %r1472 = load double, ptr @test_json_template_capture_ts_.str.14.handle, align 8
  %statepoint_token483 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r1472, i32 0, i32 0)
  %r1473484 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token483)
  %r1474 = or i64 %r1473484, 9222527611924643840
  %r1475 = bitcast i64 %r1474 to double
  %statepoint_token485 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r1475, i32 0, i32 0)
  unreachable

if.else.312:                                      ; preds = %logical.merge.303
  br label %if.merge.313

if.merge.313:                                     ; preds = %if.else.312
  %r1477 = sitofp i32 %r58.0 to double
  %r1478 = fptosi double %r1477 to i64
  %r1480 = srem i64 %r1478, 23
  %r1481 = sitofp i64 %r1480 to double
  %r1482 = icmp eq i64 %r1480, 0
  %r1483 = fcmp olt double %r1477, 0.000000e+00
  %r1484 = and i1 %r1482, %r1483
  %r1485 = fneg double %r1481
  %r1486 = select i1 %r1484, double %r1485, double %r1481
  %r1487 = fcmp oeq double %r1486, 0.000000e+00
  %r1488 = select i1 %r1487, i64 9222246136947933188, i64 9222246136947933187
  %r1489 = bitcast i64 %r1488 to double
  %r1490 = icmp eq i64 %r1488, 9222246136947933188
  br i1 %r1490, label %if.then.314, label %if.else.315

if.then.314:                                      ; preds = %if.merge.313
  %r1491.rs4i = ptrtoint ptr addrspace(1) %.151092 to i64
  %r1491.rs4o = call i64 asm "", "=r,0"(i64 %r1491.rs4i) #7
  %r1491 = bitcast i64 %r1491.rs4o to double
  %r1492 = bitcast double %r1491 to i64
  %rs4gc.s21 = inttoptr i64 %r1492 to ptr addrspace(1)
  %r1494.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r1494 = call i64 asm "", "=r,0"(i64 %r1494.rs4i) #7
  %r1495 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1496 = icmp ne i32 %r1495, 0
  br i1 %r1496, label %shadow.root.barrier.317, label %shadow.root.barrier.done.318

if.else.315:                                      ; preds = %if.merge.313
  br label %if.merge.316

if.merge.316:                                     ; preds = %apush.merge.354, %if.else.315
  %.31097 = phi ptr addrspace(1) [ %.91103, %apush.merge.354 ], [ %.11095, %if.else.315 ]
  %.21950 = phi ptr addrspace(1) [ %.27956, %apush.merge.354 ], [ %.19948, %if.else.315 ]
  %.21 = phi ptr addrspace(1) [ %.27, %apush.merge.354 ], [ %.19, %if.else.315 ]
  %r48.1.base = phi ptr addrspace(1) [ %r48.2.base, %apush.merge.354 ], [ %.19992, %if.else.315 ], !is_base_value !0
  %r48.1 = phi ptr addrspace(1) [ %r48.2, %apush.merge.354 ], [ %.191033, %if.else.315 ]
  %r5.3 = phi ptr [ %r5.4, %apush.merge.354 ], [ %r5.2, %if.else.315 ]
  %statepoint_token486 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31097, ptr addrspace(1) %.21950, ptr addrspace(1) %r48.1.base, ptr addrspace(1) %.21, ptr addrspace(1) %r48.1) ]
  %r1703487 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token486)
  %rs4gc.s20.relocated488 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token486, i32 0, i32 0) ; (%.31097, %.31097)
  %r57.0.relocated489 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token486, i32 1, i32 1) ; (%.21950, %.21950)
  %r48.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token486, i32 2, i32 2) ; (%r48.1.base, %r48.1.base)
  %rs4gc.s12.relocated490 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token486, i32 3, i32 3) ; (%.21, %.21)
  %r48.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token486, i32 2, i32 4) ; (%r48.1.base, %r48.1)
  %r1704 = or i64 %r1703487, 9222527611924643840
  %r1705 = bitcast i64 %r1704 to double
  %rs4gc.b22 = bitcast double %r1705 to i64
  %rs4gc.s22 = inttoptr i64 %rs4gc.b22 to ptr addrspace(1)
  %r1706.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r1706 = call i64 asm "", "=r,0"(i64 %r1706.rs4i) #7
  %r1707 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1708 = icmp ne i32 %r1707, 0
  br i1 %r1708, label %shadow.root.barrier.357, label %shadow.root.barrier.done.358

shadow.root.barrier.317:                          ; preds = %if.then.314
  call void @js_write_barrier_root_nanbox(i64 %r1494) #7
  br label %shadow.root.barrier.done.318

shadow.root.barrier.done.318:                     ; preds = %shadow.root.barrier.317, %if.then.314
  %r1497.rs4i = ptrtoint ptr addrspace(1) %.161071 to i64
  %r1497.rs4o = call i64 asm "", "=r,0"(i64 %r1497.rs4i) #7
  %r1497 = bitcast i64 %r1497.rs4o to double
  %r1498 = bitcast double %r1497 to i64
  %rs4gc.s23 = inttoptr i64 %r1498 to ptr addrspace(1)
  %r1500.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r1500 = call i64 asm "", "=r,0"(i64 %r1500.rs4i) #7
  %r1501 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1502 = icmp ne i32 %r1501, 0
  br i1 %r1502, label %shadow.root.barrier.319, label %shadow.root.barrier.done.320

shadow.root.barrier.319:                          ; preds = %shadow.root.barrier.done.318
  call void @js_write_barrier_root_nanbox(i64 %r1500) #7
  br label %shadow.root.barrier.done.320

shadow.root.barrier.done.320:                     ; preds = %shadow.root.barrier.319, %shadow.root.barrier.done.318
  %r1504 = icmp eq ptr %r5.2, null
  br i1 %r1504, label %arena_state.init.321, label %arena_state.ready.322

arena_state.init.321:                             ; preds = %shadow.root.barrier.done.320
  %r1505 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r1506 = icmp ne i64 %r1505, -1
  br i1 %r1506, label %arena_state.hot_tls.tsd.323, label %arena_state.hot_tls.slow.325

arena_state.ready.322:                            ; preds = %arena_state.hot_tls.resolved.327, %shadow.root.barrier.done.320
  %.01148 = phi ptr addrspace(1) [ %.11149, %arena_state.hot_tls.resolved.327 ], [ %rs4gc.s21, %shadow.root.barrier.done.320 ]
  %.01145 = phi ptr addrspace(1) [ %.11146, %arena_state.hot_tls.resolved.327 ], [ %rs4gc.s23, %shadow.root.barrier.done.320 ]
  %.41098 = phi ptr addrspace(1) [ %.51099, %arena_state.hot_tls.resolved.327 ], [ %.11095, %shadow.root.barrier.done.320 ]
  %.211035 = phi ptr addrspace(1) [ %.221036, %arena_state.hot_tls.resolved.327 ], [ %.191033, %shadow.root.barrier.done.320 ]
  %.21994 = phi ptr addrspace(1) [ %.22995, %arena_state.hot_tls.resolved.327 ], [ %.19992, %shadow.root.barrier.done.320 ]
  %.22951 = phi ptr addrspace(1) [ %.23952, %arena_state.hot_tls.resolved.327 ], [ %.19948, %shadow.root.barrier.done.320 ]
  %.22 = phi ptr addrspace(1) [ %.23, %arena_state.hot_tls.resolved.327 ], [ %.19, %shadow.root.barrier.done.320 ]
  %r5.4 = phi ptr [ %r5.5, %arena_state.hot_tls.resolved.327 ], [ %r5.2, %shadow.root.barrier.done.320 ]
  %r1520 = phi ptr [ %r5.2, %shadow.root.barrier.done.320 ], [ %r1519, %arena_state.hot_tls.resolved.327 ]
  %r1521 = getelementptr i8, ptr %r1520, i64 8
  %r1522 = load i64, ptr %r1521, align 8
  %r1523 = add i64 %r1522, 40
  %r1524 = getelementptr i8, ptr %r1520, i64 16
  %r1525 = load i64, ptr %r1524, align 8
  %r1526 = icmp ule i64 %r1523, %r1525
  br i1 %r1526, label %alloc.fast.328, label %alloc.slow.329

arena_state.hot_tls.tsd.323:                      ; preds = %arena_state.init.321
  %r1507 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #7
  %r1508 = and i64 %r1507, -8
  %r1509 = shl i64 %r1505, 3
  %r1510 = add i64 %r1508, %r1509
  %r1511 = inttoptr i64 %r1510 to ptr
  %r1512 = load ptr, ptr %r1511, align 8
  %r1513 = icmp ne ptr %r1512, null
  br i1 %r1513, label %arena_state.hot_tls.fast.324, label %arena_state.hot_tls.slow.325

arena_state.hot_tls.fast.324:                     ; preds = %arena_state.hot_tls.tsd.323
  %r1514 = getelementptr i8, ptr %r1512, i64 8
  %r1515 = load ptr, ptr %r1514, align 8
  %r1516 = load ptr, ptr %r1515, align 8
  %r1517 = icmp ne ptr %r1516, null
  br i1 %r1517, label %arena_state.hot_tls.ready.326, label %arena_state.hot_tls.slow.325

arena_state.hot_tls.slow.325:                     ; preds = %arena_state.hot_tls.fast.324, %arena_state.hot_tls.tsd.323, %arena_state.init.321
  %statepoint_token491 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11095, ptr addrspace(1) %.19948, ptr addrspace(1) %.19, ptr addrspace(1) %.19992, ptr addrspace(1) %.191033, ptr addrspace(1) %rs4gc.s23, ptr addrspace(1) %rs4gc.s21) ]
  %r1518492 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token491)
  %rs4gc.s20.relocated493 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token491, i32 0, i32 0) ; (%.11095, %.11095)
  %r57.0.relocated494 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token491, i32 1, i32 1) ; (%.19948, %.19948)
  %rs4gc.s12.relocated495 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token491, i32 2, i32 2) ; (%.19, %.19)
  %r48.0.base.relocated496 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token491, i32 3, i32 3) ; (%.19992, %.19992)
  %r48.0.relocated497 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token491, i32 3, i32 4) ; (%.19992, %.191033)
  %rs4gc.s23.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token491, i32 5, i32 5) ; (%rs4gc.s23, %rs4gc.s23)
  %rs4gc.s21.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token491, i32 6, i32 6) ; (%rs4gc.s21, %rs4gc.s21)
  br label %arena_state.hot_tls.resolved.327

arena_state.hot_tls.ready.326:                    ; preds = %arena_state.hot_tls.fast.324
  br label %arena_state.hot_tls.resolved.327

arena_state.hot_tls.resolved.327:                 ; preds = %arena_state.hot_tls.ready.326, %arena_state.hot_tls.slow.325
  %.11149 = phi ptr addrspace(1) [ %rs4gc.s21, %arena_state.hot_tls.ready.326 ], [ %rs4gc.s21.relocated, %arena_state.hot_tls.slow.325 ]
  %.11146 = phi ptr addrspace(1) [ %rs4gc.s23, %arena_state.hot_tls.ready.326 ], [ %rs4gc.s23.relocated, %arena_state.hot_tls.slow.325 ]
  %.51099 = phi ptr addrspace(1) [ %.11095, %arena_state.hot_tls.ready.326 ], [ %rs4gc.s20.relocated493, %arena_state.hot_tls.slow.325 ]
  %.221036 = phi ptr addrspace(1) [ %.191033, %arena_state.hot_tls.ready.326 ], [ %r48.0.relocated497, %arena_state.hot_tls.slow.325 ]
  %.22995 = phi ptr addrspace(1) [ %.19992, %arena_state.hot_tls.ready.326 ], [ %r48.0.base.relocated496, %arena_state.hot_tls.slow.325 ]
  %.23952 = phi ptr addrspace(1) [ %.19948, %arena_state.hot_tls.ready.326 ], [ %r57.0.relocated494, %arena_state.hot_tls.slow.325 ]
  %.23 = phi ptr addrspace(1) [ %.19, %arena_state.hot_tls.ready.326 ], [ %rs4gc.s12.relocated495, %arena_state.hot_tls.slow.325 ]
  %r5.5 = phi ptr [ %r1515, %arena_state.hot_tls.ready.326 ], [ %r1518492, %arena_state.hot_tls.slow.325 ]
  %r1519 = phi ptr [ %r1515, %arena_state.hot_tls.ready.326 ], [ %r1518492, %arena_state.hot_tls.slow.325 ]
  br label %arena_state.ready.322

alloc.fast.328:                                   ; preds = %arena_state.ready.322
  store i64 %r1523, ptr %r1521, align 8
  %r1527 = load ptr, ptr %r1520, align 8
  %r1528 = getelementptr i8, ptr %r1527, i64 %r1522
  br label %alloc.merge.330

alloc.slow.329:                                   ; preds = %arena_state.ready.322
  %statepoint_token498 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r1520, i64 40, i64 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41098, ptr addrspace(1) %.22951, ptr addrspace(1) %.22, ptr addrspace(1) %.21994, ptr addrspace(1) %.211035, ptr addrspace(1) %.01145, ptr addrspace(1) %.01148) ]
  %r1529499 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token498)
  %rs4gc.s20.relocated500 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 0, i32 0) ; (%.41098, %.41098)
  %r57.0.relocated501 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 1, i32 1) ; (%.22951, %.22951)
  %rs4gc.s12.relocated502 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 2, i32 2) ; (%.22, %.22)
  %r48.0.base.relocated503 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 3, i32 3) ; (%.21994, %.21994)
  %r48.0.relocated504 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 3, i32 4) ; (%.21994, %.211035)
  %rs4gc.s23.relocated505 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 5, i32 5) ; (%.01145, %.01145)
  %rs4gc.s21.relocated506 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token498, i32 6, i32 6) ; (%.01148, %.01148)
  br label %alloc.merge.330

alloc.merge.330:                                  ; preds = %alloc.slow.329, %alloc.fast.328
  %.21150 = phi ptr addrspace(1) [ %.01148, %alloc.fast.328 ], [ %rs4gc.s21.relocated506, %alloc.slow.329 ]
  %.21147 = phi ptr addrspace(1) [ %.01145, %alloc.fast.328 ], [ %rs4gc.s23.relocated505, %alloc.slow.329 ]
  %.61100 = phi ptr addrspace(1) [ %.41098, %alloc.fast.328 ], [ %rs4gc.s20.relocated500, %alloc.slow.329 ]
  %.231037 = phi ptr addrspace(1) [ %.211035, %alloc.fast.328 ], [ %r48.0.relocated504, %alloc.slow.329 ]
  %.23996 = phi ptr addrspace(1) [ %.21994, %alloc.fast.328 ], [ %r48.0.base.relocated503, %alloc.slow.329 ]
  %.24953 = phi ptr addrspace(1) [ %.22951, %alloc.fast.328 ], [ %r57.0.relocated501, %alloc.slow.329 ]
  %.24 = phi ptr addrspace(1) [ %.22, %alloc.fast.328 ], [ %rs4gc.s12.relocated502, %alloc.slow.329 ]
  %r1530 = phi ptr [ %r1528, %alloc.fast.328 ], [ %r1529499, %alloc.slow.329 ]
  store <2 x i64> %r1532, ptr %r1530, align 8
  %r1534 = getelementptr i8, ptr %r1530, i64 16
  store i64 0, ptr %r1534, align 8
  %r1535 = getelementptr i8, ptr %r1530, i64 24
  store i64 9222246136947933185, ptr %r1535, align 8
  %r1536 = getelementptr i8, ptr %r1530, i64 32
  store i64 9222246136947933185, ptr %r1536, align 8
  %r1537 = getelementptr i8, ptr %r1530, i64 8
  %r1538 = ptrtoint ptr %r1537 to i64
  %r1539 = load atomic i32, ptr @PERRY_PER_OBJECT_LAYOUTS_ANY monotonic, align 4
  %r1540 = icmp ne i32 %r1539, 0
  br i1 %r1540, label %layout_forget.young.331, label %layout_forget.done.334

layout_forget.young.331:                          ; preds = %alloc.merge.330
  %r1541 = load atomic i32, ptr @PERRY_YOUNG_LAYOUT_RECORDS monotonic, align 4
  %r1542 = icmp ne i32 %r1541, 0
  br i1 %r1542, label %layout_forget.sketch.332, label %layout_forget.done.334

layout_forget.sketch.332:                         ; preds = %layout_forget.young.331
  %r1543 = mul i64 %r1538, -7046029254386353131
  %r1544 = lshr i64 %r1543, 52
  %r1545 = lshr i64 %r1544, 6
  %r1546 = and i64 %r1544, 63
  %r1547 = shl nuw i64 1, %r1546
  %r1548 = getelementptr i64, ptr @PERRY_LAYOUT_ADDR_FILTER, i64 %r1545
  %r1549 = load atomic i64, ptr %r1548 monotonic, align 8
  %r1550 = and i64 %r1549, %r1547
  %r1551 = icmp ne i64 %r1550, 0
  br i1 %r1551, label %layout_forget.armed.333, label %layout_forget.done.334

layout_forget.armed.333:                          ; preds = %layout_forget.sketch.332
  call void @js_gc_forget_object_layout(i64 %r1538) #7
  br label %layout_forget.done.334

layout_forget.done.334:                           ; preds = %layout_forget.armed.333, %layout_forget.sketch.332, %layout_forget.young.331, %alloc.merge.330
  %rs4gc.s24 = inttoptr i64 %r1538 to ptr addrspace(1)
  %r1553.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r1553 = call i64 asm "", "=r,0"(i64 %r1553.rs4i) #7
  %r1554 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1555 = icmp ne i32 %r1554, 0
  br i1 %r1555, label %shadow.root.barrier.335, label %shadow.root.barrier.done.336

shadow.root.barrier.335:                          ; preds = %layout_forget.done.334
  call void @js_write_barrier_root_nanbox(i64 %r1553) #7
  br label %shadow.root.barrier.done.336

shadow.root.barrier.done.336:                     ; preds = %shadow.root.barrier.335, %layout_forget.done.334
  %r1556 = or i64 %r1538, 9222527611924643840
  %r1557 = bitcast i64 %r1556 to double
  %r1558.rs4i = ptrtoint ptr addrspace(1) %.21150 to i64
  %r1558 = call i64 asm "", "=r,0"(i64 %r1558.rs4i) #7
  %r1559 = bitcast i64 %r1558 to double
  %r1560.rs4i = ptrtoint ptr addrspace(1) %.21147 to i64
  %r1560 = call i64 asm "", "=r,0"(i64 %r1560.rs4i) #7
  %r1561 = bitcast i64 %r1560 to double
  %r1562 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r1563 = icmp eq i8 %r1562, 0
  br i1 %r1563, label %ctor_prologue.fast.337, label %ctor_prologue.slow.338

ctor_prologue.fast.337:                           ; preds = %shadow.root.barrier.done.336
  %r1564 = inttoptr i64 %r1538 to ptr
  %r1565 = getelementptr i8, ptr %r1564, i64 16
  %r1566 = bitcast double %r1557 to i64
  %r1567 = getelementptr double, ptr %r1565, i64 0
  store double %r1559, ptr %r1567, align 8
  %r1568 = ptrtoint ptr %r1567 to i64
  %r1569 = bitcast double %r1559 to i64
  %r1570 = lshr i64 %r1569, 48
  %r1571 = icmp eq i64 %r1570, 0
  %r1572 = icmp uge i64 %r1569, 4096
  %r1573 = and i1 %r1571, %r1572
  %r1574 = icmp eq i64 %r1570, 32765
  %r1575 = icmp eq i64 %r1570, 32767
  %r1576 = icmp eq i64 %r1570, 32762
  %r1577 = or i1 %r1574, %r1575
  %r1578 = or i1 %r1577, %r1576
  %r1579 = or i1 %r1578, %r1573
  br i1 %r1579, label %ctor_prologue.barrier.maybe.340, label %ctor_prologue.barrier.done.342

ctor_prologue.slow.338:                           ; preds = %shadow.root.barrier.done.336
  %statepoint_token507 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double)) @test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18_constructor, i32 3, i32 0, double %r1557, double %r1559, double %r1561, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61100, ptr addrspace(1) %.24953, ptr addrspace(1) %.24, ptr addrspace(1) %.23996, ptr addrspace(1) %.231037, ptr addrspace(1) %rs4gc.s24) ]
  %r1609508 = call double @llvm.experimental.gc.result.f64(token %statepoint_token507)
  %rs4gc.s20.relocated509 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 0, i32 0) ; (%.61100, %.61100)
  %r57.0.relocated510 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 1, i32 1) ; (%.24953, %.24953)
  %rs4gc.s12.relocated511 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 2, i32 2) ; (%.24, %.24)
  %r48.0.base.relocated512 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 3, i32 3) ; (%.23996, %.23996)
  %r48.0.relocated513 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 3, i32 4) ; (%.23996, %.231037)
  %rs4gc.s24.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token507, i32 5, i32 5) ; (%rs4gc.s24, %rs4gc.s24)
  br label %ctor_prologue.merge.339

ctor_prologue.merge.339:                          ; preds = %ctor_prologue.barrier.done.345, %ctor_prologue.slow.338
  %.01151 = phi ptr addrspace(1) [ %rs4gc.s24, %ctor_prologue.barrier.done.345 ], [ %rs4gc.s24.relocated, %ctor_prologue.slow.338 ]
  %.71101 = phi ptr addrspace(1) [ %.61100, %ctor_prologue.barrier.done.345 ], [ %rs4gc.s20.relocated509, %ctor_prologue.slow.338 ]
  %.241038 = phi ptr addrspace(1) [ %.231037, %ctor_prologue.barrier.done.345 ], [ %r48.0.relocated513, %ctor_prologue.slow.338 ]
  %.24997 = phi ptr addrspace(1) [ %.23996, %ctor_prologue.barrier.done.345 ], [ %r48.0.base.relocated512, %ctor_prologue.slow.338 ]
  %.25954 = phi ptr addrspace(1) [ %.24953, %ctor_prologue.barrier.done.345 ], [ %r57.0.relocated510, %ctor_prologue.slow.338 ]
  %.25 = phi ptr addrspace(1) [ %.24, %ctor_prologue.barrier.done.345 ], [ %rs4gc.s12.relocated511, %ctor_prologue.slow.338 ]
  %r1610 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.345 ], [ %r1609508, %ctor_prologue.slow.338 ]
  %r1611.rs4i = ptrtoint ptr addrspace(1) %.01151 to i64
  %r1611 = call i64 asm "", "=r,0"(i64 %r1611.rs4i) #7
  %r1612 = or i64 %r1611, 9222527611924643840
  %r1613 = bitcast i64 %r1612 to double
  %r1614 = bitcast double %r1610 to i64
  %r1615 = icmp eq i64 %r1614, 9222246136947933185
  br i1 %r1615, label %ctor_ret.merge.347, label %ctor_ret.override.346

ctor_prologue.barrier.maybe.340:                  ; preds = %ctor_prologue.fast.337
  %r1580 = sub i64 %r1538, 7
  %r1581 = inttoptr i64 %r1580 to ptr
  %r1582 = load i8, ptr %r1581, align 1
  %r1583 = and i8 %r1582, 32
  %r1584 = icmp ne i8 %r1583, 0
  %r1585 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1586 = icmp ne i32 %r1585, 0
  %r1587 = or i1 %r1584, %r1586
  br i1 %r1587, label %ctor_prologue.barrier.341, label %ctor_prologue.barrier.done.342

ctor_prologue.barrier.341:                        ; preds = %ctor_prologue.barrier.maybe.340
  call void @js_write_barrier_slot_validated_parent(i64 %r1538, i64 %r1568, i64 %r1569) #7
  br label %ctor_prologue.barrier.done.342

ctor_prologue.barrier.done.342:                   ; preds = %ctor_prologue.barrier.341, %ctor_prologue.barrier.maybe.340, %ctor_prologue.fast.337
  %r1588 = getelementptr double, ptr %r1565, i64 1
  store double %r1561, ptr %r1588, align 8
  %r1589 = ptrtoint ptr %r1588 to i64
  %r1590 = bitcast double %r1561 to i64
  %r1591 = lshr i64 %r1590, 48
  %r1592 = icmp eq i64 %r1591, 0
  %r1593 = icmp uge i64 %r1590, 4096
  %r1594 = and i1 %r1592, %r1593
  %r1595 = icmp eq i64 %r1591, 32765
  %r1596 = icmp eq i64 %r1591, 32767
  %r1597 = icmp eq i64 %r1591, 32762
  %r1598 = or i1 %r1595, %r1596
  %r1599 = or i1 %r1598, %r1597
  %r1600 = or i1 %r1599, %r1594
  br i1 %r1600, label %ctor_prologue.barrier.maybe.343, label %ctor_prologue.barrier.done.345

ctor_prologue.barrier.maybe.343:                  ; preds = %ctor_prologue.barrier.done.342
  %r1601 = sub i64 %r1538, 7
  %r1602 = inttoptr i64 %r1601 to ptr
  %r1603 = load i8, ptr %r1602, align 1
  %r1604 = and i8 %r1603, 32
  %r1605 = icmp ne i8 %r1604, 0
  %r1606 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1607 = icmp ne i32 %r1606, 0
  %r1608 = or i1 %r1605, %r1607
  br i1 %r1608, label %ctor_prologue.barrier.344, label %ctor_prologue.barrier.done.345

ctor_prologue.barrier.344:                        ; preds = %ctor_prologue.barrier.maybe.343
  call void @js_write_barrier_slot_validated_parent(i64 %r1538, i64 %r1589, i64 %r1590) #7
  br label %ctor_prologue.barrier.done.345

ctor_prologue.barrier.done.345:                   ; preds = %ctor_prologue.barrier.344, %ctor_prologue.barrier.maybe.343, %ctor_prologue.barrier.done.342
  br label %ctor_prologue.merge.339

ctor_ret.override.346:                            ; preds = %ctor_prologue.merge.339
  %statepoint_token514 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r1613, double %r1610, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.71101, ptr addrspace(1) %.25954, ptr addrspace(1) %.25, ptr addrspace(1) %.24997, ptr addrspace(1) %.241038) ]
  %r1616515 = call double @llvm.experimental.gc.result.f64(token %statepoint_token514)
  %rs4gc.s20.relocated516 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token514, i32 0, i32 0) ; (%.71101, %.71101)
  %r57.0.relocated517 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token514, i32 1, i32 1) ; (%.25954, %.25954)
  %rs4gc.s12.relocated518 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token514, i32 2, i32 2) ; (%.25, %.25)
  %r48.0.base.relocated519 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token514, i32 3, i32 3) ; (%.24997, %.24997)
  %r48.0.relocated520 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token514, i32 3, i32 4) ; (%.24997, %.241038)
  br label %ctor_ret.merge.347

ctor_ret.merge.347:                               ; preds = %ctor_ret.override.346, %ctor_prologue.merge.339
  %.81102 = phi ptr addrspace(1) [ %.71101, %ctor_prologue.merge.339 ], [ %rs4gc.s20.relocated516, %ctor_ret.override.346 ]
  %.251039 = phi ptr addrspace(1) [ %.241038, %ctor_prologue.merge.339 ], [ %r48.0.relocated520, %ctor_ret.override.346 ]
  %.25998 = phi ptr addrspace(1) [ %.24997, %ctor_prologue.merge.339 ], [ %r48.0.base.relocated519, %ctor_ret.override.346 ]
  %.26955 = phi ptr addrspace(1) [ %.25954, %ctor_prologue.merge.339 ], [ %r57.0.relocated517, %ctor_ret.override.346 ]
  %.26 = phi ptr addrspace(1) [ %.25, %ctor_prologue.merge.339 ], [ %rs4gc.s12.relocated518, %ctor_ret.override.346 ]
  %r1617 = phi double [ %r1613, %ctor_prologue.merge.339 ], [ %r1616515, %ctor_ret.override.346 ]
  %r1618 = bitcast double %r1617 to i64
  %r1619.rs4i = ptrtoint ptr addrspace(1) %.251039 to i64
  %r1619.rs4o = call i64 asm "", "=r,0"(i64 %r1619.rs4i) #7
  %r1619 = bitcast i64 %r1619.rs4o to double
  %r1620 = bitcast double %r1619 to i64
  %r1621 = and i64 %r1620, 281474976710655
  %r1622 = sub nsw i64 %r1621, 8
  %r1623 = inttoptr i64 %r1622 to ptr
  %r1624 = load i8, ptr %r1623, align 1
  %r1625 = icmp ne i8 %r1624, 1
  %r1626 = sub nsw i64 %r1621, 7
  %r1627 = inttoptr i64 %r1626 to ptr
  %r1628 = load i8, ptr %r1627, align 1
  %r1629 = and i8 %r1628, -128
  %r1630 = icmp ne i8 %r1629, 0
  %r1631 = or i1 %r1625, %r1630
  br i1 %r1630, label %apush.fwd.348, label %apush.elements.349

apush.fwd.348:                                    ; preds = %apush.elements.check.350, %ctor_ret.merge.347
  %statepoint_token521 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1621, double %r1617, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81102, ptr addrspace(1) %.26955, ptr addrspace(1) %.26) ]
  %r1658522 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token521)
  %rs4gc.s20.relocated523 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token521, i32 0, i32 0) ; (%.81102, %.81102)
  %r57.0.relocated524 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token521, i32 1, i32 1) ; (%.26955, %.26955)
  %rs4gc.s12.relocated525 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token521, i32 2, i32 2) ; (%.26, %.26)
  %r1659 = or i64 %r1658522, 9222527611924643840
  %r1660 = bitcast i64 %r1659 to double
  %rs4gc.b25 = bitcast double %r1660 to i64
  %rs4gc.s25 = inttoptr i64 %rs4gc.b25 to ptr addrspace(1)
  br label %apush.merge.354

apush.elements.349:                               ; preds = %ctor_ret.merge.347
  %r1633 = add nuw nsw i64 %r1621, 8
  %r1634 = inttoptr i64 %r1633 to ptr
  %r1635 = load i64, ptr %r1634, align 8
  %r1636 = icmp ne i64 %r1635, 0
  %r1637 = icmp eq i8 %r1624, 2
  %r1638 = and i1 %r1637, %r1636
  %r1639 = select i1 %r1638, i64 %r1635, i64 %r1621
  %r1640 = inttoptr i64 %r1639 to ptr
  %r1641 = getelementptr i64, ptr %r1640, i64 12
  %r1642 = load i64, ptr %r1641, align 8
  %r1643 = icmp ne i64 %r1642, 0
  %r1644 = and i1 %r1638, %r1643
  %r1645 = select i1 %r1644, i64 %r1642, i64 %r1621
  %r1632 = icmp eq i8 %r1624, 1
  br i1 %r1632, label %apush.nofwd.351, label %apush.elements.check.350

apush.elements.check.350:                         ; preds = %apush.elements.349
  %r1646 = icmp ne i64 %r1645, 0
  %r1647 = sub i64 %r1645, 8
  %r1648 = inttoptr i64 %r1647 to ptr
  %r1649 = load i8, ptr %r1648, align 1
  %r1650 = icmp eq i8 %r1649, 1
  %r1651 = sub i64 %r1645, 7
  %r1652 = inttoptr i64 %r1651 to ptr
  %r1653 = load i8, ptr %r1652, align 1
  %r1654 = and i8 %r1653, -128
  %r1655 = icmp eq i8 %r1654, 0
  %r1656 = and i1 %r1646, %r1650
  %r1657 = and i1 %r1656, %r1655
  br i1 %r1657, label %apush.nofwd.351, label %apush.fwd.348

apush.nofwd.351:                                  ; preds = %apush.elements.check.350, %apush.elements.349
  %r1661 = phi i64 [ %r1621, %apush.elements.349 ], [ %r1645, %apush.elements.check.350 ]
  %r1662 = sub i64 %r1661, 6
  %r1663 = inttoptr i64 %r1662 to ptr
  %r1664 = load i16, ptr %r1663, align 2
  %r1665 = and i16 %r1664, -2937
  %r1666 = icmp eq i16 %r1665, -24576
  %r1667 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1668 = icmp eq i8 %r1667, 0
  %r1669 = and i1 %r1666, %r1668
  %r1670 = icmp ult i64 %r1661, 4096
  %r1671 = inttoptr i64 %r1661 to ptr
  %r1672 = select i1 %r1670, ptr @perry_null_guard_zero_test_json_template_capture_ts, ptr %r1671
  %r1673 = load i32, ptr %r1672, align 4
  %r1674 = add i64 %r1661, 4
  %r1675 = inttoptr i64 %r1674 to ptr
  %r1676 = load i32, ptr %r1675, align 4
  %r1677 = icmp ult i32 %r1673, %r1676
  %r1678 = and i1 %r1677, %r1669
  br i1 %r1678, label %apush.inbounds.352, label %apush.realloc.353

apush.inbounds.352:                               ; preds = %apush.nofwd.351
  %r1679 = icmp ult i64 %r1661, 4096
  %r1680 = inttoptr i64 %r1661 to ptr
  %r1681 = select i1 %r1679, ptr @perry_null_guard_zero_test_json_template_capture_ts, ptr %r1680
  %r1682 = load i32, ptr %r1681, align 4
  %r1683 = zext i32 %r1682 to i64
  %r1684 = shl nuw nsw i64 %r1683, 3
  %r1685 = add nuw nsw i64 %r1684, 8
  %r1686 = add i64 %r1661, %r1685
  %r1687 = inttoptr i64 %r1686 to ptr
  store double %r1617, ptr %r1687, align 8
  call void @js_string_addref_if_heap_string(double %r1617) #7
  %r1688 = bitcast double %r1617 to i64
  %r1689 = sub i64 %r1661, 7
  %r1690 = inttoptr i64 %r1689 to ptr
  %r1691 = load i8, ptr %r1690, align 1
  %r1692 = and i8 %r1691, 32
  %r1693 = icmp ne i8 %r1692, 0
  %r1694 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1695 = icmp ne i32 %r1694, 0
  %r1696 = or i1 %r1693, %r1695
  br i1 %r1696, label %apush.barrier.355, label %apush.barrier.done.356

apush.realloc.353:                                ; preds = %apush.nofwd.351
  %statepoint_token526 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1621, double %r1617, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81102, ptr addrspace(1) %.26955, ptr addrspace(1) %.26) ]
  %r1699527 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token526)
  %rs4gc.s20.relocated528 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token526, i32 0, i32 0) ; (%.81102, %.81102)
  %r57.0.relocated529 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token526, i32 1, i32 1) ; (%.26955, %.26955)
  %rs4gc.s12.relocated530 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token526, i32 2, i32 2) ; (%.26, %.26)
  %r1700 = or i64 %r1699527, 9222527611924643840
  %r1701 = bitcast i64 %r1700 to double
  %rs4gc.b26 = bitcast double %r1701 to i64
  %rs4gc.s26 = inttoptr i64 %rs4gc.b26 to ptr addrspace(1)
  br label %apush.merge.354

apush.merge.354:                                  ; preds = %apush.barrier.done.356, %apush.realloc.353, %apush.fwd.348
  %.91103 = phi ptr addrspace(1) [ %rs4gc.s20.relocated523, %apush.fwd.348 ], [ %.81102, %apush.barrier.done.356 ], [ %rs4gc.s20.relocated528, %apush.realloc.353 ]
  %.27956 = phi ptr addrspace(1) [ %r57.0.relocated524, %apush.fwd.348 ], [ %.26955, %apush.barrier.done.356 ], [ %r57.0.relocated529, %apush.realloc.353 ]
  %.27 = phi ptr addrspace(1) [ %rs4gc.s12.relocated525, %apush.fwd.348 ], [ %.26, %apush.barrier.done.356 ], [ %rs4gc.s12.relocated530, %apush.realloc.353 ]
  %r48.2.base = phi ptr addrspace(1) [ %rs4gc.s25, %apush.fwd.348 ], [ %.25998, %apush.barrier.done.356 ], [ %rs4gc.s26, %apush.realloc.353 ], !is_base_value !0
  %r48.2 = phi ptr addrspace(1) [ %rs4gc.s25, %apush.fwd.348 ], [ %.251039, %apush.barrier.done.356 ], [ %rs4gc.s26, %apush.realloc.353 ]
  br label %if.merge.316

apush.barrier.355:                                ; preds = %apush.inbounds.352
  call void @js_write_barrier_slot_validated_parent(i64 %r1661, i64 %r1686, i64 %r1688) #7
  br label %apush.barrier.done.356

apush.barrier.done.356:                           ; preds = %apush.barrier.355, %apush.inbounds.352
  %r1697 = add i32 %r1682, 1
  %r1698 = inttoptr i64 %r1661 to ptr
  store i32 %r1697, ptr %r1698, align 4
  br label %apush.merge.354

shadow.root.barrier.357:                          ; preds = %if.merge.316
  call void @js_write_barrier_root_nanbox(i64 %r1706) #7
  br label %shadow.root.barrier.done.358

shadow.root.barrier.done.358:                     ; preds = %shadow.root.barrier.357, %if.merge.316
  %r1709 = bitcast double %r1705 to i64
  %r1710 = and i64 %r1709, 281474976710655
  call void @js_array_declare_all_pointer_elements(i64 %r1710) #7
  br label %for.cond.359

for.cond.359:                                     ; preds = %for.update.361, %shadow.root.barrier.done.358
  %.01129 = phi ptr addrspace(1) [ %r48.1.relocated, %shadow.root.barrier.done.358 ], [ %.81137, %for.update.361 ]
  %.01113 = phi ptr addrspace(1) [ %r48.1.base.relocated, %shadow.root.barrier.done.358 ], [ %.81121, %for.update.361 ]
  %.101104 = phi ptr addrspace(1) [ %rs4gc.s20.relocated488, %shadow.root.barrier.done.358 ], [ %.181112, %for.update.361 ]
  %.28957 = phi ptr addrspace(1) [ %r57.0.relocated489, %shadow.root.barrier.done.358 ], [ %.36965, %for.update.361 ]
  %.28 = phi ptr addrspace(1) [ %rs4gc.s12.relocated490, %shadow.root.barrier.done.358 ], [ %.36, %for.update.361 ]
  %r1711.0 = phi double [ 0.000000e+00, %shadow.root.barrier.done.358 ], [ %r1929, %for.update.361 ]
  %r1702.0.base = phi ptr addrspace(1) [ %rs4gc.s22, %shadow.root.barrier.done.358 ], [ %.01170, %for.update.361 ], !is_base_value !0
  %r1702.0 = phi ptr addrspace(1) [ %rs4gc.s22, %shadow.root.barrier.done.358 ], [ %.01171, %for.update.361 ]
  %r5.6 = phi ptr [ %r5.3, %shadow.root.barrier.done.358 ], [ %r5.7, %for.update.361 ]
  %r1713 = fcmp olt double %r1711.0, 8.000000e+01
  %r1714 = select i1 %r1713, i64 9222246136947933188, i64 9222246136947933187
  %r1715 = bitcast i64 %r1714 to double
  %r1716 = icmp eq i64 %r1714, 9222246136947933188
  br i1 %r1716, label %for.body.360, label %for.exit.362

for.body.360:                                     ; preds = %for.cond.359
  %r1718 = load double, ptr @test_json_template_capture_ts_.str.15.handle, align 8
  %r1720 = fcmp oge double %r1711.0, 0.000000e+00
  %r1721 = fcmp olt double %r1711.0, 3.200000e+01
  %r1722 = and i1 %r1720, %r1721
  br i1 %r1722, label %csite.chk.363, label %csite.plain.366

for.update.361:                                   ; preds = %gcpoll.done.404
  %r1929 = fadd double %r1711.0, 1.000000e+00
  br label %for.cond.359

for.exit.362:                                     ; preds = %for.cond.359
  %r1930.rs4i = ptrtoint ptr addrspace(1) %.28957 to i64
  %r1930.rs4o = call i64 asm "", "=r,0"(i64 %r1930.rs4i) #7
  %r1930 = bitcast i64 %r1930.rs4o to double
  %r1931 = bitcast double %r1930 to i64
  %rs4gc.s27 = inttoptr i64 %r1931 to ptr addrspace(1)
  %r1932.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r1932 = call i64 asm "", "=r,0"(i64 %r1932.rs4i) #7
  %r1933 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1934 = icmp ne i32 %r1933, 0
  br i1 %r1934, label %shadow.root.barrier.405, label %shadow.root.barrier.done.406

csite.chk.363:                                    ; preds = %for.body.360
  %r1723 = fptosi double %r1711.0 to i32
  %r1724 = sitofp i32 %r1723 to double
  %r1725 = fcmp oeq double %r1724, %r1711.0
  %r1726 = sext i32 %r1723 to i64
  %r1727 = getelementptr [32 x i64], ptr @perry_concat_site_test_json_template_capture_ts__17, i64 0, i64 %r1726
  %r1728 = load i64, ptr %r1727, align 8
  %r1729 = icmp ne i64 %r1728, 0
  %r1730 = and i1 %r1725, %r1729
  br i1 %r1730, label %csite.hit.364, label %csite.fill.365

csite.hit.364:                                    ; preds = %csite.chk.363
  %r1731 = bitcast i64 %r1728 to double
  br label %csite.merge.367

csite.fill.365:                                   ; preds = %csite.chk.363
  %r1732 = bitcast double %r1718 to i64
  %r1733 = and i64 %r1732, 281474976710655
  %statepoint_token531 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, double)) @js_string_concat_site_value, i32 3, i32 0, i64 ptrtoint (ptr @perry_concat_site_test_json_template_capture_ts__17 to i64), i64 %r1733, double %r1711.0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.101104, ptr addrspace(1) %.28957, ptr addrspace(1) %.01113, ptr addrspace(1) %.28, ptr addrspace(1) %r1702.0.base, ptr addrspace(1) %r1702.0, ptr addrspace(1) %.01129) ]
  %r1735532 = call double @llvm.experimental.gc.result.f64(token %statepoint_token531)
  %rs4gc.s20.relocated533 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token531, i32 0, i32 0) ; (%.101104, %.101104)
  %r57.0.relocated534 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token531, i32 1, i32 1) ; (%.28957, %.28957)
  %r48.1.base.relocated535 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token531, i32 2, i32 2) ; (%.01113, %.01113)
  %rs4gc.s12.relocated536 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token531, i32 3, i32 3) ; (%.28, %.28)
  %r1702.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token531, i32 4, i32 4) ; (%r1702.0.base, %r1702.0.base)
  %r1702.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token531, i32 4, i32 5) ; (%r1702.0.base, %r1702.0)
  %r48.1.relocated537 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token531, i32 2, i32 6) ; (%.01113, %.01129)
  br label %csite.merge.367

csite.plain.366:                                  ; preds = %for.body.360
  %r1736 = bitcast double %r1718 to i64
  %r1737 = and i64 %r1736, 281474976710655
  %statepoint_token538 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r1737, double %r1711.0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.101104, ptr addrspace(1) %.28957, ptr addrspace(1) %.01113, ptr addrspace(1) %.28, ptr addrspace(1) %r1702.0.base, ptr addrspace(1) %r1702.0, ptr addrspace(1) %.01129) ]
  %r1738539 = call double @llvm.experimental.gc.result.f64(token %statepoint_token538)
  %rs4gc.s20.relocated540 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token538, i32 0, i32 0) ; (%.101104, %.101104)
  %r57.0.relocated541 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token538, i32 1, i32 1) ; (%.28957, %.28957)
  %r48.1.base.relocated542 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token538, i32 2, i32 2) ; (%.01113, %.01113)
  %rs4gc.s12.relocated543 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token538, i32 3, i32 3) ; (%.28, %.28)
  %r1702.0.base.relocated544 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token538, i32 4, i32 4) ; (%r1702.0.base, %r1702.0.base)
  %r1702.0.relocated545 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token538, i32 4, i32 5) ; (%r1702.0.base, %r1702.0)
  %r48.1.relocated546 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token538, i32 2, i32 6) ; (%.01113, %.01129)
  br label %csite.merge.367

csite.merge.367:                                  ; preds = %csite.plain.366, %csite.fill.365, %csite.hit.364
  %.01158 = phi ptr addrspace(1) [ %r1702.0, %csite.hit.364 ], [ %r1702.0.relocated, %csite.fill.365 ], [ %r1702.0.relocated545, %csite.plain.366 ]
  %.01152 = phi ptr addrspace(1) [ %r1702.0.base, %csite.hit.364 ], [ %r1702.0.base.relocated, %csite.fill.365 ], [ %r1702.0.base.relocated544, %csite.plain.366 ]
  %.11130 = phi ptr addrspace(1) [ %.01129, %csite.hit.364 ], [ %r48.1.relocated537, %csite.fill.365 ], [ %r48.1.relocated546, %csite.plain.366 ]
  %.11114 = phi ptr addrspace(1) [ %.01113, %csite.hit.364 ], [ %r48.1.base.relocated535, %csite.fill.365 ], [ %r48.1.base.relocated542, %csite.plain.366 ]
  %.111105 = phi ptr addrspace(1) [ %.101104, %csite.hit.364 ], [ %rs4gc.s20.relocated533, %csite.fill.365 ], [ %rs4gc.s20.relocated540, %csite.plain.366 ]
  %.29958 = phi ptr addrspace(1) [ %.28957, %csite.hit.364 ], [ %r57.0.relocated534, %csite.fill.365 ], [ %r57.0.relocated541, %csite.plain.366 ]
  %.29 = phi ptr addrspace(1) [ %.28, %csite.hit.364 ], [ %rs4gc.s12.relocated536, %csite.fill.365 ], [ %rs4gc.s12.relocated543, %csite.plain.366 ]
  %r1739 = phi double [ %r1731, %csite.hit.364 ], [ %r1735532, %csite.fill.365 ], [ %r1738539, %csite.plain.366 ]
  %r1740 = bitcast double %r1739 to i64
  %rs4gc.s28 = inttoptr i64 %r1740 to ptr addrspace(1)
  %r1741.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r1741 = call i64 asm "", "=r,0"(i64 %r1741.rs4i) #7
  %r1742 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1743 = icmp ne i32 %r1742, 0
  br i1 %r1743, label %shadow.root.barrier.368, label %shadow.root.barrier.done.369

shadow.root.barrier.368:                          ; preds = %csite.merge.367
  call void @js_write_barrier_root_nanbox(i64 %r1741) #7
  br label %shadow.root.barrier.done.369

shadow.root.barrier.done.369:                     ; preds = %shadow.root.barrier.368, %csite.merge.367
  %r1745 = icmp eq ptr %r5.6, null
  br i1 %r1745, label %arena_state.init.370, label %arena_state.ready.371

arena_state.init.370:                             ; preds = %shadow.root.barrier.done.369
  %r1746 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r1747 = icmp ne i64 %r1746, -1
  br i1 %r1747, label %arena_state.hot_tls.tsd.372, label %arena_state.hot_tls.slow.374

arena_state.ready.371:                            ; preds = %arena_state.hot_tls.resolved.376, %shadow.root.barrier.done.369
  %.01166 = phi ptr addrspace(1) [ %.11167, %arena_state.hot_tls.resolved.376 ], [ %rs4gc.s28, %shadow.root.barrier.done.369 ]
  %.11159 = phi ptr addrspace(1) [ %.21160, %arena_state.hot_tls.resolved.376 ], [ %.01158, %shadow.root.barrier.done.369 ]
  %.11153 = phi ptr addrspace(1) [ %.21154, %arena_state.hot_tls.resolved.376 ], [ %.01152, %shadow.root.barrier.done.369 ]
  %.21131 = phi ptr addrspace(1) [ %.31132, %arena_state.hot_tls.resolved.376 ], [ %.11130, %shadow.root.barrier.done.369 ]
  %.21115 = phi ptr addrspace(1) [ %.31116, %arena_state.hot_tls.resolved.376 ], [ %.11114, %shadow.root.barrier.done.369 ]
  %.121106 = phi ptr addrspace(1) [ %.131107, %arena_state.hot_tls.resolved.376 ], [ %.111105, %shadow.root.barrier.done.369 ]
  %.30959 = phi ptr addrspace(1) [ %.31960, %arena_state.hot_tls.resolved.376 ], [ %.29958, %shadow.root.barrier.done.369 ]
  %.30 = phi ptr addrspace(1) [ %.31, %arena_state.hot_tls.resolved.376 ], [ %.29, %shadow.root.barrier.done.369 ]
  %r5.7 = phi ptr [ %r5.8, %arena_state.hot_tls.resolved.376 ], [ %r5.6, %shadow.root.barrier.done.369 ]
  %r1761 = phi ptr [ %r5.6, %shadow.root.barrier.done.369 ], [ %r1760, %arena_state.hot_tls.resolved.376 ]
  %r1762 = getelementptr i8, ptr %r1761, i64 8
  %r1763 = load i64, ptr %r1762, align 8
  %r1764 = add i64 %r1763, 40
  %r1765 = getelementptr i8, ptr %r1761, i64 16
  %r1766 = load i64, ptr %r1765, align 8
  %r1767 = icmp ule i64 %r1764, %r1766
  br i1 %r1767, label %alloc.fast.377, label %alloc.slow.378

arena_state.hot_tls.tsd.372:                      ; preds = %arena_state.init.370
  %r1748 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #7
  %r1749 = and i64 %r1748, -8
  %r1750 = shl i64 %r1746, 3
  %r1751 = add i64 %r1749, %r1750
  %r1752 = inttoptr i64 %r1751 to ptr
  %r1753 = load ptr, ptr %r1752, align 8
  %r1754 = icmp ne ptr %r1753, null
  br i1 %r1754, label %arena_state.hot_tls.fast.373, label %arena_state.hot_tls.slow.374

arena_state.hot_tls.fast.373:                     ; preds = %arena_state.hot_tls.tsd.372
  %r1755 = getelementptr i8, ptr %r1753, i64 8
  %r1756 = load ptr, ptr %r1755, align 8
  %r1757 = load ptr, ptr %r1756, align 8
  %r1758 = icmp ne ptr %r1757, null
  br i1 %r1758, label %arena_state.hot_tls.ready.375, label %arena_state.hot_tls.slow.374

arena_state.hot_tls.slow.374:                     ; preds = %arena_state.hot_tls.fast.373, %arena_state.hot_tls.tsd.372, %arena_state.init.370
  %statepoint_token547 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111105, ptr addrspace(1) %.29958, ptr addrspace(1) %.11114, ptr addrspace(1) %.29, ptr addrspace(1) %.01152, ptr addrspace(1) %.01158, ptr addrspace(1) %rs4gc.s28, ptr addrspace(1) %.11130) ]
  %r1759548 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token547)
  %rs4gc.s20.relocated549 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 0, i32 0) ; (%.111105, %.111105)
  %r57.0.relocated550 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 1, i32 1) ; (%.29958, %.29958)
  %r48.1.base.relocated551 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 2, i32 2) ; (%.11114, %.11114)
  %rs4gc.s12.relocated552 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 3, i32 3) ; (%.29, %.29)
  %r1702.0.base.relocated553 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 4, i32 4) ; (%.01152, %.01152)
  %r1702.0.relocated554 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 4, i32 5) ; (%.01152, %.01158)
  %rs4gc.s28.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 6, i32 6) ; (%rs4gc.s28, %rs4gc.s28)
  %r48.1.relocated555 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token547, i32 2, i32 7) ; (%.11114, %.11130)
  br label %arena_state.hot_tls.resolved.376

arena_state.hot_tls.ready.375:                    ; preds = %arena_state.hot_tls.fast.373
  br label %arena_state.hot_tls.resolved.376

arena_state.hot_tls.resolved.376:                 ; preds = %arena_state.hot_tls.ready.375, %arena_state.hot_tls.slow.374
  %.11167 = phi ptr addrspace(1) [ %rs4gc.s28, %arena_state.hot_tls.ready.375 ], [ %rs4gc.s28.relocated, %arena_state.hot_tls.slow.374 ]
  %.21160 = phi ptr addrspace(1) [ %.01158, %arena_state.hot_tls.ready.375 ], [ %r1702.0.relocated554, %arena_state.hot_tls.slow.374 ]
  %.21154 = phi ptr addrspace(1) [ %.01152, %arena_state.hot_tls.ready.375 ], [ %r1702.0.base.relocated553, %arena_state.hot_tls.slow.374 ]
  %.31132 = phi ptr addrspace(1) [ %.11130, %arena_state.hot_tls.ready.375 ], [ %r48.1.relocated555, %arena_state.hot_tls.slow.374 ]
  %.31116 = phi ptr addrspace(1) [ %.11114, %arena_state.hot_tls.ready.375 ], [ %r48.1.base.relocated551, %arena_state.hot_tls.slow.374 ]
  %.131107 = phi ptr addrspace(1) [ %.111105, %arena_state.hot_tls.ready.375 ], [ %rs4gc.s20.relocated549, %arena_state.hot_tls.slow.374 ]
  %.31960 = phi ptr addrspace(1) [ %.29958, %arena_state.hot_tls.ready.375 ], [ %r57.0.relocated550, %arena_state.hot_tls.slow.374 ]
  %.31 = phi ptr addrspace(1) [ %.29, %arena_state.hot_tls.ready.375 ], [ %rs4gc.s12.relocated552, %arena_state.hot_tls.slow.374 ]
  %r5.8 = phi ptr [ %r1756, %arena_state.hot_tls.ready.375 ], [ %r1759548, %arena_state.hot_tls.slow.374 ]
  %r1760 = phi ptr [ %r1756, %arena_state.hot_tls.ready.375 ], [ %r1759548, %arena_state.hot_tls.slow.374 ]
  br label %arena_state.ready.371

alloc.fast.377:                                   ; preds = %arena_state.ready.371
  store i64 %r1764, ptr %r1762, align 8
  %r1768 = load ptr, ptr %r1761, align 8
  %r1769 = getelementptr i8, ptr %r1768, i64 %r1763
  br label %alloc.merge.379

alloc.slow.378:                                   ; preds = %arena_state.ready.371
  %statepoint_token556 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r1761, i64 40, i64 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.121106, ptr addrspace(1) %.30959, ptr addrspace(1) %.21115, ptr addrspace(1) %.30, ptr addrspace(1) %.11153, ptr addrspace(1) %.11159, ptr addrspace(1) %.01166, ptr addrspace(1) %.21131) ]
  %r1770557 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token556)
  %rs4gc.s20.relocated558 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 0, i32 0) ; (%.121106, %.121106)
  %r57.0.relocated559 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 1, i32 1) ; (%.30959, %.30959)
  %r48.1.base.relocated560 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 2, i32 2) ; (%.21115, %.21115)
  %rs4gc.s12.relocated561 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 3, i32 3) ; (%.30, %.30)
  %r1702.0.base.relocated562 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 4, i32 4) ; (%.11153, %.11153)
  %r1702.0.relocated563 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 4, i32 5) ; (%.11153, %.11159)
  %rs4gc.s28.relocated564 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 6, i32 6) ; (%.01166, %.01166)
  %r48.1.relocated565 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 2, i32 7) ; (%.21115, %.21131)
  br label %alloc.merge.379

alloc.merge.379:                                  ; preds = %alloc.slow.378, %alloc.fast.377
  %.21168 = phi ptr addrspace(1) [ %.01166, %alloc.fast.377 ], [ %rs4gc.s28.relocated564, %alloc.slow.378 ]
  %.31161 = phi ptr addrspace(1) [ %.11159, %alloc.fast.377 ], [ %r1702.0.relocated563, %alloc.slow.378 ]
  %.31155 = phi ptr addrspace(1) [ %.11153, %alloc.fast.377 ], [ %r1702.0.base.relocated562, %alloc.slow.378 ]
  %.41133 = phi ptr addrspace(1) [ %.21131, %alloc.fast.377 ], [ %r48.1.relocated565, %alloc.slow.378 ]
  %.41117 = phi ptr addrspace(1) [ %.21115, %alloc.fast.377 ], [ %r48.1.base.relocated560, %alloc.slow.378 ]
  %.141108 = phi ptr addrspace(1) [ %.121106, %alloc.fast.377 ], [ %rs4gc.s20.relocated558, %alloc.slow.378 ]
  %.32961 = phi ptr addrspace(1) [ %.30959, %alloc.fast.377 ], [ %r57.0.relocated559, %alloc.slow.378 ]
  %.32 = phi ptr addrspace(1) [ %.30, %alloc.fast.377 ], [ %rs4gc.s12.relocated561, %alloc.slow.378 ]
  %r1771 = phi ptr [ %r1769, %alloc.fast.377 ], [ %r1770557, %alloc.slow.378 ]
  store <2 x i64> %r1773, ptr %r1771, align 8
  %r1775 = getelementptr i8, ptr %r1771, i64 16
  store i64 0, ptr %r1775, align 8
  %r1776 = getelementptr i8, ptr %r1771, i64 24
  store i64 9222246136947933185, ptr %r1776, align 8
  %r1777 = getelementptr i8, ptr %r1771, i64 32
  store i64 9222246136947933185, ptr %r1777, align 8
  %r1778 = getelementptr i8, ptr %r1771, i64 8
  %r1779 = ptrtoint ptr %r1778 to i64
  %r1780 = load atomic i32, ptr @PERRY_PER_OBJECT_LAYOUTS_ANY monotonic, align 4
  %r1781 = icmp ne i32 %r1780, 0
  br i1 %r1781, label %layout_forget.young.380, label %layout_forget.done.383

layout_forget.young.380:                          ; preds = %alloc.merge.379
  %r1782 = load atomic i32, ptr @PERRY_YOUNG_LAYOUT_RECORDS monotonic, align 4
  %r1783 = icmp ne i32 %r1782, 0
  br i1 %r1783, label %layout_forget.sketch.381, label %layout_forget.done.383

layout_forget.sketch.381:                         ; preds = %layout_forget.young.380
  %r1784 = mul i64 %r1779, -7046029254386353131
  %r1785 = lshr i64 %r1784, 52
  %r1786 = lshr i64 %r1785, 6
  %r1787 = and i64 %r1785, 63
  %r1788 = shl nuw i64 1, %r1787
  %r1789 = getelementptr i64, ptr @PERRY_LAYOUT_ADDR_FILTER, i64 %r1786
  %r1790 = load atomic i64, ptr %r1789 monotonic, align 8
  %r1791 = and i64 %r1790, %r1788
  %r1792 = icmp ne i64 %r1791, 0
  br i1 %r1792, label %layout_forget.armed.382, label %layout_forget.done.383

layout_forget.armed.382:                          ; preds = %layout_forget.sketch.381
  call void @js_gc_forget_object_layout(i64 %r1779) #7
  br label %layout_forget.done.383

layout_forget.done.383:                           ; preds = %layout_forget.armed.382, %layout_forget.sketch.381, %layout_forget.young.380, %alloc.merge.379
  %rs4gc.s29 = inttoptr i64 %r1779 to ptr addrspace(1)
  %r1793.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r1793 = call i64 asm "", "=r,0"(i64 %r1793.rs4i) #7
  %r1794 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1795 = icmp ne i32 %r1794, 0
  br i1 %r1795, label %shadow.root.barrier.384, label %shadow.root.barrier.done.385

shadow.root.barrier.384:                          ; preds = %layout_forget.done.383
  call void @js_write_barrier_root_nanbox(i64 %r1793) #7
  br label %shadow.root.barrier.done.385

shadow.root.barrier.done.385:                     ; preds = %shadow.root.barrier.384, %layout_forget.done.383
  %r1796 = or i64 %r1779, 9222527611924643840
  %r1797 = bitcast i64 %r1796 to double
  %r1798.rs4i = ptrtoint ptr addrspace(1) %.21168 to i64
  %r1798 = call i64 asm "", "=r,0"(i64 %r1798.rs4i) #7
  %r1799 = bitcast i64 %r1798 to double
  %r1800 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r1801 = icmp eq i8 %r1800, 0
  %r1802 = bitcast double %r1711.0 to i64
  %r1803 = and i64 %r1802, 9218868437227405312
  %r1804 = icmp ne i64 %r1803, 9218868437227405312
  %r1805 = and i1 %r1801, %r1804
  br i1 %r1805, label %ctor_prologue.fast.386, label %ctor_prologue.slow.387

ctor_prologue.fast.386:                           ; preds = %shadow.root.barrier.done.385
  %r1806 = inttoptr i64 %r1779 to ptr
  %r1807 = getelementptr i8, ptr %r1806, i64 16
  %r1808 = bitcast double %r1797 to i64
  %r1809 = getelementptr double, ptr %r1807, i64 0
  store double %r1711.0, ptr %r1809, align 8
  %r1810 = ptrtoint ptr %r1809 to i64
  %r1811 = bitcast double %r1711.0 to i64
  %r1812 = getelementptr double, ptr %r1807, i64 1
  store double %r1799, ptr %r1812, align 8
  %r1813 = ptrtoint ptr %r1812 to i64
  %r1814 = bitcast double %r1799 to i64
  %r1815 = lshr i64 %r1814, 48
  %r1816 = icmp eq i64 %r1815, 0
  %r1817 = icmp uge i64 %r1814, 4096
  %r1818 = and i1 %r1816, %r1817
  %r1819 = icmp eq i64 %r1815, 32765
  %r1820 = icmp eq i64 %r1815, 32767
  %r1821 = icmp eq i64 %r1815, 32762
  %r1822 = or i1 %r1819, %r1820
  %r1823 = or i1 %r1822, %r1821
  %r1824 = or i1 %r1823, %r1818
  br i1 %r1824, label %ctor_prologue.barrier.maybe.389, label %ctor_prologue.barrier.done.391

ctor_prologue.slow.387:                           ; preds = %shadow.root.barrier.done.385
  %statepoint_token566 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double)) @test_json_template_capture_ts____AnonShape_570a27fd5b93ea38_constructor, i32 3, i32 0, double %r1797, double %r1711.0, double %r1799, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.141108, ptr addrspace(1) %.32961, ptr addrspace(1) %.41117, ptr addrspace(1) %.32, ptr addrspace(1) %.31155, ptr addrspace(1) %.31161, ptr addrspace(1) %rs4gc.s29, ptr addrspace(1) %.41133) ]
  %r1833567 = call double @llvm.experimental.gc.result.f64(token %statepoint_token566)
  %rs4gc.s20.relocated568 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token566, i32 0, i32 0) ; (%.141108, %.141108)
  %r57.0.relocated569 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token566, i32 1, i32 1) ; (%.32961, %.32961)
  %r48.1.base.relocated570 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token566, i32 2, i32 2) ; (%.41117, %.41117)
  %rs4gc.s12.relocated571 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token566, i32 3, i32 3) ; (%.32, %.32)
  %r1702.0.base.relocated572 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token566, i32 4, i32 4) ; (%.31155, %.31155)
  %r1702.0.relocated573 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token566, i32 4, i32 5) ; (%.31155, %.31161)
  %rs4gc.s29.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token566, i32 6, i32 6) ; (%rs4gc.s29, %rs4gc.s29)
  %r48.1.relocated574 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token566, i32 2, i32 7) ; (%.41117, %.41133)
  br label %ctor_prologue.merge.388

ctor_prologue.merge.388:                          ; preds = %ctor_prologue.barrier.done.391, %ctor_prologue.slow.387
  %.01169 = phi ptr addrspace(1) [ %rs4gc.s29, %ctor_prologue.barrier.done.391 ], [ %rs4gc.s29.relocated, %ctor_prologue.slow.387 ]
  %.41162 = phi ptr addrspace(1) [ %.31161, %ctor_prologue.barrier.done.391 ], [ %r1702.0.relocated573, %ctor_prologue.slow.387 ]
  %.41156 = phi ptr addrspace(1) [ %.31155, %ctor_prologue.barrier.done.391 ], [ %r1702.0.base.relocated572, %ctor_prologue.slow.387 ]
  %.51134 = phi ptr addrspace(1) [ %.41133, %ctor_prologue.barrier.done.391 ], [ %r48.1.relocated574, %ctor_prologue.slow.387 ]
  %.51118 = phi ptr addrspace(1) [ %.41117, %ctor_prologue.barrier.done.391 ], [ %r48.1.base.relocated570, %ctor_prologue.slow.387 ]
  %.151109 = phi ptr addrspace(1) [ %.141108, %ctor_prologue.barrier.done.391 ], [ %rs4gc.s20.relocated568, %ctor_prologue.slow.387 ]
  %.33962 = phi ptr addrspace(1) [ %.32961, %ctor_prologue.barrier.done.391 ], [ %r57.0.relocated569, %ctor_prologue.slow.387 ]
  %.33 = phi ptr addrspace(1) [ %.32, %ctor_prologue.barrier.done.391 ], [ %rs4gc.s12.relocated571, %ctor_prologue.slow.387 ]
  %r1834 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.391 ], [ %r1833567, %ctor_prologue.slow.387 ]
  %r1835.rs4i = ptrtoint ptr addrspace(1) %.01169 to i64
  %r1835 = call i64 asm "", "=r,0"(i64 %r1835.rs4i) #7
  %r1836 = or i64 %r1835, 9222527611924643840
  %r1837 = bitcast i64 %r1836 to double
  %r1838 = bitcast double %r1834 to i64
  %r1839 = icmp eq i64 %r1838, 9222246136947933185
  br i1 %r1839, label %ctor_ret.merge.393, label %ctor_ret.override.392

ctor_prologue.barrier.maybe.389:                  ; preds = %ctor_prologue.fast.386
  %r1825 = sub i64 %r1779, 7
  %r1826 = inttoptr i64 %r1825 to ptr
  %r1827 = load i8, ptr %r1826, align 1
  %r1828 = and i8 %r1827, 32
  %r1829 = icmp ne i8 %r1828, 0
  %r1830 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1831 = icmp ne i32 %r1830, 0
  %r1832 = or i1 %r1829, %r1831
  br i1 %r1832, label %ctor_prologue.barrier.390, label %ctor_prologue.barrier.done.391

ctor_prologue.barrier.390:                        ; preds = %ctor_prologue.barrier.maybe.389
  call void @js_write_barrier_slot_validated_parent(i64 %r1779, i64 %r1813, i64 %r1814) #7
  br label %ctor_prologue.barrier.done.391

ctor_prologue.barrier.done.391:                   ; preds = %ctor_prologue.barrier.390, %ctor_prologue.barrier.maybe.389, %ctor_prologue.fast.386
  br label %ctor_prologue.merge.388

ctor_ret.override.392:                            ; preds = %ctor_prologue.merge.388
  %statepoint_token575 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r1837, double %r1834, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.151109, ptr addrspace(1) %.33962, ptr addrspace(1) %.51118, ptr addrspace(1) %.33, ptr addrspace(1) %.41156, ptr addrspace(1) %.41162, ptr addrspace(1) %.51134) ]
  %r1840576 = call double @llvm.experimental.gc.result.f64(token %statepoint_token575)
  %rs4gc.s20.relocated577 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token575, i32 0, i32 0) ; (%.151109, %.151109)
  %r57.0.relocated578 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token575, i32 1, i32 1) ; (%.33962, %.33962)
  %r48.1.base.relocated579 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token575, i32 2, i32 2) ; (%.51118, %.51118)
  %rs4gc.s12.relocated580 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token575, i32 3, i32 3) ; (%.33, %.33)
  %r1702.0.base.relocated581 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token575, i32 4, i32 4) ; (%.41156, %.41156)
  %r1702.0.relocated582 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token575, i32 4, i32 5) ; (%.41156, %.41162)
  %r48.1.relocated583 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token575, i32 2, i32 6) ; (%.51118, %.51134)
  br label %ctor_ret.merge.393

ctor_ret.merge.393:                               ; preds = %ctor_ret.override.392, %ctor_prologue.merge.388
  %.51163 = phi ptr addrspace(1) [ %.41162, %ctor_prologue.merge.388 ], [ %r1702.0.relocated582, %ctor_ret.override.392 ]
  %.51157 = phi ptr addrspace(1) [ %.41156, %ctor_prologue.merge.388 ], [ %r1702.0.base.relocated581, %ctor_ret.override.392 ]
  %.61135 = phi ptr addrspace(1) [ %.51134, %ctor_prologue.merge.388 ], [ %r48.1.relocated583, %ctor_ret.override.392 ]
  %.61119 = phi ptr addrspace(1) [ %.51118, %ctor_prologue.merge.388 ], [ %r48.1.base.relocated579, %ctor_ret.override.392 ]
  %.161110 = phi ptr addrspace(1) [ %.151109, %ctor_prologue.merge.388 ], [ %rs4gc.s20.relocated577, %ctor_ret.override.392 ]
  %.34963 = phi ptr addrspace(1) [ %.33962, %ctor_prologue.merge.388 ], [ %r57.0.relocated578, %ctor_ret.override.392 ]
  %.34 = phi ptr addrspace(1) [ %.33, %ctor_prologue.merge.388 ], [ %rs4gc.s12.relocated580, %ctor_ret.override.392 ]
  %r1841 = phi double [ %r1837, %ctor_prologue.merge.388 ], [ %r1840576, %ctor_ret.override.392 ]
  %r1842 = bitcast double %r1841 to i64
  %r1843.rs4i = ptrtoint ptr addrspace(1) %.51163 to i64
  %r1843.rs4o = call i64 asm "", "=r,0"(i64 %r1843.rs4i) #7
  %r1843 = bitcast i64 %r1843.rs4o to double
  %r1844 = bitcast double %r1843 to i64
  %r1845 = and i64 %r1844, 281474976710655
  %r1846 = sub nsw i64 %r1845, 8
  %r1847 = inttoptr i64 %r1846 to ptr
  %r1848 = load i8, ptr %r1847, align 1
  %r1849 = icmp ne i8 %r1848, 1
  %r1850 = sub nsw i64 %r1845, 7
  %r1851 = inttoptr i64 %r1850 to ptr
  %r1852 = load i8, ptr %r1851, align 1
  %r1853 = and i8 %r1852, -128
  %r1854 = icmp ne i8 %r1853, 0
  %r1855 = or i1 %r1849, %r1854
  br i1 %r1854, label %apush.fwd.394, label %apush.elements.395

apush.fwd.394:                                    ; preds = %apush.elements.check.396, %ctor_ret.merge.393
  %statepoint_token584 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1845, double %r1841, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.161110, ptr addrspace(1) %.34963, ptr addrspace(1) %.61119, ptr addrspace(1) %.34, ptr addrspace(1) %.61135) ]
  %r1882585 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token584)
  %rs4gc.s20.relocated586 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 0, i32 0) ; (%.161110, %.161110)
  %r57.0.relocated587 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 1, i32 1) ; (%.34963, %.34963)
  %r48.1.base.relocated588 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 2, i32 2) ; (%.61119, %.61119)
  %rs4gc.s12.relocated589 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 3, i32 3) ; (%.34, %.34)
  %r48.1.relocated590 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token584, i32 2, i32 4) ; (%.61119, %.61135)
  %r1883 = or i64 %r1882585, 9222527611924643840
  %r1884 = bitcast i64 %r1883 to double
  %rs4gc.b30 = bitcast double %r1884 to i64
  %rs4gc.s30 = inttoptr i64 %rs4gc.b30 to ptr addrspace(1)
  br label %apush.merge.400

apush.elements.395:                               ; preds = %ctor_ret.merge.393
  %r1857 = add nuw nsw i64 %r1845, 8
  %r1858 = inttoptr i64 %r1857 to ptr
  %r1859 = load i64, ptr %r1858, align 8
  %r1860 = icmp ne i64 %r1859, 0
  %r1861 = icmp eq i8 %r1848, 2
  %r1862 = and i1 %r1861, %r1860
  %r1863 = select i1 %r1862, i64 %r1859, i64 %r1845
  %r1864 = inttoptr i64 %r1863 to ptr
  %r1865 = getelementptr i64, ptr %r1864, i64 12
  %r1866 = load i64, ptr %r1865, align 8
  %r1867 = icmp ne i64 %r1866, 0
  %r1868 = and i1 %r1862, %r1867
  %r1869 = select i1 %r1868, i64 %r1866, i64 %r1845
  %r1856 = icmp eq i8 %r1848, 1
  br i1 %r1856, label %apush.nofwd.397, label %apush.elements.check.396

apush.elements.check.396:                         ; preds = %apush.elements.395
  %r1870 = icmp ne i64 %r1869, 0
  %r1871 = sub i64 %r1869, 8
  %r1872 = inttoptr i64 %r1871 to ptr
  %r1873 = load i8, ptr %r1872, align 1
  %r1874 = icmp eq i8 %r1873, 1
  %r1875 = sub i64 %r1869, 7
  %r1876 = inttoptr i64 %r1875 to ptr
  %r1877 = load i8, ptr %r1876, align 1
  %r1878 = and i8 %r1877, -128
  %r1879 = icmp eq i8 %r1878, 0
  %r1880 = and i1 %r1870, %r1874
  %r1881 = and i1 %r1880, %r1879
  br i1 %r1881, label %apush.nofwd.397, label %apush.fwd.394

apush.nofwd.397:                                  ; preds = %apush.elements.check.396, %apush.elements.395
  %r1885 = phi i64 [ %r1845, %apush.elements.395 ], [ %r1869, %apush.elements.check.396 ]
  %r1886 = sub i64 %r1885, 6
  %r1887 = inttoptr i64 %r1886 to ptr
  %r1888 = load i16, ptr %r1887, align 2
  %r1889 = and i16 %r1888, -2937
  %r1890 = icmp eq i16 %r1889, -24576
  %r1891 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1892 = icmp eq i8 %r1891, 0
  %r1893 = and i1 %r1890, %r1892
  %r1894 = icmp ult i64 %r1885, 4096
  %r1895 = inttoptr i64 %r1885 to ptr
  %r1896 = select i1 %r1894, ptr @perry_null_guard_zero_test_json_template_capture_ts, ptr %r1895
  %r1897 = load i32, ptr %r1896, align 4
  %r1898 = add i64 %r1885, 4
  %r1899 = inttoptr i64 %r1898 to ptr
  %r1900 = load i32, ptr %r1899, align 4
  %r1901 = icmp ult i32 %r1897, %r1900
  %r1902 = and i1 %r1901, %r1893
  br i1 %r1902, label %apush.inbounds.398, label %apush.realloc.399

apush.inbounds.398:                               ; preds = %apush.nofwd.397
  %r1903 = icmp ult i64 %r1885, 4096
  %r1904 = inttoptr i64 %r1885 to ptr
  %r1905 = select i1 %r1903, ptr @perry_null_guard_zero_test_json_template_capture_ts, ptr %r1904
  %r1906 = load i32, ptr %r1905, align 4
  %r1907 = zext i32 %r1906 to i64
  %r1908 = shl nuw nsw i64 %r1907, 3
  %r1909 = add nuw nsw i64 %r1908, 8
  %r1910 = add i64 %r1885, %r1909
  %r1911 = inttoptr i64 %r1910 to ptr
  store double %r1841, ptr %r1911, align 8
  call void @js_string_addref_if_heap_string(double %r1841) #7
  %r1912 = bitcast double %r1841 to i64
  %r1913 = sub i64 %r1885, 7
  %r1914 = inttoptr i64 %r1913 to ptr
  %r1915 = load i8, ptr %r1914, align 1
  %r1916 = and i8 %r1915, 32
  %r1917 = icmp ne i8 %r1916, 0
  %r1918 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1919 = icmp ne i32 %r1918, 0
  %r1920 = or i1 %r1917, %r1919
  br i1 %r1920, label %apush.barrier.401, label %apush.barrier.done.402

apush.realloc.399:                                ; preds = %apush.nofwd.397
  %statepoint_token591 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1845, double %r1841, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.161110, ptr addrspace(1) %.34963, ptr addrspace(1) %.61119, ptr addrspace(1) %.34, ptr addrspace(1) %.61135) ]
  %r1923592 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token591)
  %rs4gc.s20.relocated593 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token591, i32 0, i32 0) ; (%.161110, %.161110)
  %r57.0.relocated594 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token591, i32 1, i32 1) ; (%.34963, %.34963)
  %r48.1.base.relocated595 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token591, i32 2, i32 2) ; (%.61119, %.61119)
  %rs4gc.s12.relocated596 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token591, i32 3, i32 3) ; (%.34, %.34)
  %r48.1.relocated597 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token591, i32 2, i32 4) ; (%.61119, %.61135)
  %r1924 = or i64 %r1923592, 9222527611924643840
  %r1925 = bitcast i64 %r1924 to double
  %rs4gc.b31 = bitcast double %r1925 to i64
  %rs4gc.s31 = inttoptr i64 %rs4gc.b31 to ptr addrspace(1)
  br label %apush.merge.400

apush.merge.400:                                  ; preds = %apush.barrier.done.402, %apush.realloc.399, %apush.fwd.394
  %.71136 = phi ptr addrspace(1) [ %r48.1.relocated590, %apush.fwd.394 ], [ %.61135, %apush.barrier.done.402 ], [ %r48.1.relocated597, %apush.realloc.399 ]
  %.71120 = phi ptr addrspace(1) [ %r48.1.base.relocated588, %apush.fwd.394 ], [ %.61119, %apush.barrier.done.402 ], [ %r48.1.base.relocated595, %apush.realloc.399 ]
  %.171111 = phi ptr addrspace(1) [ %rs4gc.s20.relocated586, %apush.fwd.394 ], [ %.161110, %apush.barrier.done.402 ], [ %rs4gc.s20.relocated593, %apush.realloc.399 ]
  %.35964 = phi ptr addrspace(1) [ %r57.0.relocated587, %apush.fwd.394 ], [ %.34963, %apush.barrier.done.402 ], [ %r57.0.relocated594, %apush.realloc.399 ]
  %.35 = phi ptr addrspace(1) [ %rs4gc.s12.relocated589, %apush.fwd.394 ], [ %.34, %apush.barrier.done.402 ], [ %rs4gc.s12.relocated596, %apush.realloc.399 ]
  %r1702.1.base = phi ptr addrspace(1) [ %rs4gc.s30, %apush.fwd.394 ], [ %.51157, %apush.barrier.done.402 ], [ %rs4gc.s31, %apush.realloc.399 ], !is_base_value !0
  %r1702.1 = phi ptr addrspace(1) [ %rs4gc.s30, %apush.fwd.394 ], [ %.51163, %apush.barrier.done.402 ], [ %rs4gc.s31, %apush.realloc.399 ]
  %r1926 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1927 = icmp ne i32 %r1926, 0
  br i1 %r1927, label %gcpoll.403, label %gcpoll.done.404

apush.barrier.401:                                ; preds = %apush.inbounds.398
  call void @js_write_barrier_slot_validated_parent(i64 %r1885, i64 %r1910, i64 %r1912) #7
  br label %apush.barrier.done.402

apush.barrier.done.402:                           ; preds = %apush.barrier.401, %apush.inbounds.398
  %r1921 = add i32 %r1906, 1
  %r1922 = inttoptr i64 %r1885 to ptr
  store i32 %r1921, ptr %r1922, align 4
  br label %apush.merge.400

gcpoll.403:                                       ; preds = %apush.merge.400
  %statepoint_token598 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1702.1.base, ptr addrspace(1) %r1702.1, ptr addrspace(1) %.171111, ptr addrspace(1) %.35964, ptr addrspace(1) %.71120, ptr addrspace(1) %.35, ptr addrspace(1) %.71136) ]
  %r1702.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token598, i32 0, i32 0) ; (%r1702.1.base, %r1702.1.base)
  %r1702.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token598, i32 0, i32 1) ; (%r1702.1.base, %r1702.1)
  %rs4gc.s20.relocated599 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token598, i32 2, i32 2) ; (%.171111, %.171111)
  %r57.0.relocated600 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token598, i32 3, i32 3) ; (%.35964, %.35964)
  %r48.1.base.relocated601 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token598, i32 4, i32 4) ; (%.71120, %.71120)
  %rs4gc.s12.relocated602 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token598, i32 5, i32 5) ; (%.35, %.35)
  %r48.1.relocated603 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token598, i32 4, i32 6) ; (%.71120, %.71136)
  br label %gcpoll.done.404

gcpoll.done.404:                                  ; preds = %gcpoll.403, %apush.merge.400
  %.01171 = phi ptr addrspace(1) [ %r1702.1.relocated, %gcpoll.403 ], [ %r1702.1, %apush.merge.400 ]
  %.01170 = phi ptr addrspace(1) [ %r1702.1.base.relocated, %gcpoll.403 ], [ %r1702.1.base, %apush.merge.400 ]
  %.81137 = phi ptr addrspace(1) [ %r48.1.relocated603, %gcpoll.403 ], [ %.71136, %apush.merge.400 ]
  %.81121 = phi ptr addrspace(1) [ %r48.1.base.relocated601, %gcpoll.403 ], [ %.71120, %apush.merge.400 ]
  %.181112 = phi ptr addrspace(1) [ %rs4gc.s20.relocated599, %gcpoll.403 ], [ %.171111, %apush.merge.400 ]
  %.36965 = phi ptr addrspace(1) [ %r57.0.relocated600, %gcpoll.403 ], [ %.35964, %apush.merge.400 ]
  %.36 = phi ptr addrspace(1) [ %rs4gc.s12.relocated602, %gcpoll.403 ], [ %.35, %apush.merge.400 ]
  br label %for.update.361

shadow.root.barrier.405:                          ; preds = %for.exit.362
  call void @js_write_barrier_root_nanbox(i64 %r1932) #7
  br label %shadow.root.barrier.done.406

shadow.root.barrier.done.406:                     ; preds = %shadow.root.barrier.405, %for.exit.362
  %r1935.rs4i = ptrtoint ptr addrspace(1) %.101104 to i64
  %r1935.rs4o = call i64 asm "", "=r,0"(i64 %r1935.rs4i) #7
  %r1935 = bitcast i64 %r1935.rs4o to double
  %r1936 = bitcast double %r1935 to i64
  %r1937 = and i64 %r1936, 281474976710655
  %r1938 = lshr i64 %r1936, 48
  %r1939 = and i64 %r1938, 65533
  %r1940 = icmp eq i64 %r1939, 32765
  br i1 %r1940, label %pget.recv_ok.408, label %pget.recv_other.412

pget.recv_sso.407:                                ; preds = %pget.recv_other.412
  %r2078 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2079 = bitcast double %r2078 to i64
  %r2080 = and i64 %r2079, 281474976710655
  %statepoint_token604 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1936, i64 %r2080, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s27, ptr addrspace(1) %.01113, ptr addrspace(1) %.28, ptr addrspace(1) %r1702.0, ptr addrspace(1) %.01129, ptr addrspace(1) %r1702.0.base) ]
  %r2081605 = call double @llvm.experimental.gc.result.f64(token %statepoint_token604)
  %rs4gc.s27.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token604, i32 0, i32 0) ; (%rs4gc.s27, %rs4gc.s27)
  %r48.1.base.relocated606 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token604, i32 1, i32 1) ; (%.01113, %.01113)
  %rs4gc.s12.relocated607 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token604, i32 2, i32 2) ; (%.28, %.28)
  %r1702.0.relocated608 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token604, i32 5, i32 3) ; (%r1702.0.base, %r1702.0)
  %r48.1.relocated609 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token604, i32 1, i32 4) ; (%.01113, %.01129)
  %r1702.0.base.relocated610 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token604, i32 5, i32 5) ; (%r1702.0.base, %r1702.0.base)
  br label %pget.recv_merge.411

pget.recv_ok.408:                                 ; preds = %shadow.root.barrier.done.406
  %r1947 = icmp ugt i64 %r1937, 1048575
  br i1 %r1947, label %pic.recv_hdr.429, label %pic.miss.cold.426

pget.recv_bad.409:                                ; preds = %pget.check_class_ref.413
  %r2070 = icmp eq i64 %r1936, 9222246136947933185
  %r2071 = icmp eq i64 %r1936, 9222246136947933186
  %r2072 = or i1 %r2070, %r2071
  br i1 %r2072, label %pget.throw_nullish.436, label %pget.recv_undef_return.437

pget.recv_class_ref.410:                          ; preds = %pget.check_class_ref.413
  %r1943 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r1944 = bitcast double %r1943 to i64
  %r1945 = and i64 %r1944, 281474976710655
  %statepoint_token611 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6060382687846203410, i64 %r1936, i64 %r1945, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s27, ptr addrspace(1) %.01113, ptr addrspace(1) %.28, ptr addrspace(1) %r1702.0, ptr addrspace(1) %.01129, ptr addrspace(1) %r1702.0.base) ]
  %r1946612 = call double @llvm.experimental.gc.result.f64(token %statepoint_token611)
  %rs4gc.s27.relocated613 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 0, i32 0) ; (%rs4gc.s27, %rs4gc.s27)
  %r48.1.base.relocated614 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 1, i32 1) ; (%.01113, %.01113)
  %rs4gc.s12.relocated615 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 2, i32 2) ; (%.28, %.28)
  %r1702.0.relocated616 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 5, i32 3) ; (%r1702.0.base, %r1702.0)
  %r48.1.relocated617 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 1, i32 4) ; (%.01113, %.01129)
  %r1702.0.base.relocated618 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 5, i32 5) ; (%r1702.0.base, %r1702.0.base)
  br label %pget.recv_merge.411

pget.recv_merge.411:                              ; preds = %pget.recv_undef_return.437, %pic.merge.428, %pget.recv_class_ref.410, %pget.recv_sso.407
  %.01172 = phi ptr addrspace(1) [ %.11173, %pic.merge.428 ], [ %rs4gc.s27.relocated, %pget.recv_sso.407 ], [ %rs4gc.s27.relocated613, %pget.recv_class_ref.410 ], [ %rs4gc.s27.relocated638, %pget.recv_undef_return.437 ]
  %.61164 = phi ptr addrspace(1) [ %.71165, %pic.merge.428 ], [ %r1702.0.relocated608, %pget.recv_sso.407 ], [ %r1702.0.relocated616, %pget.recv_class_ref.410 ], [ %r1702.0.relocated641, %pget.recv_undef_return.437 ]
  %.91138 = phi ptr addrspace(1) [ %.101139, %pic.merge.428 ], [ %r48.1.relocated609, %pget.recv_sso.407 ], [ %r48.1.relocated617, %pget.recv_class_ref.410 ], [ %r48.1.relocated642, %pget.recv_undef_return.437 ]
  %.91122 = phi ptr addrspace(1) [ %.101123, %pic.merge.428 ], [ %r48.1.base.relocated606, %pget.recv_sso.407 ], [ %r48.1.base.relocated614, %pget.recv_class_ref.410 ], [ %r48.1.base.relocated639, %pget.recv_undef_return.437 ]
  %.37 = phi ptr addrspace(1) [ %.38, %pic.merge.428 ], [ %rs4gc.s12.relocated607, %pget.recv_sso.407 ], [ %rs4gc.s12.relocated615, %pget.recv_class_ref.410 ], [ %rs4gc.s12.relocated640, %pget.recv_undef_return.437 ]
  %r2082 = phi double [ %r2069, %pic.merge.428 ], [ %r2077637, %pget.recv_undef_return.437 ], [ %r2081605, %pget.recv_sso.407 ], [ %r1946612, %pget.recv_class_ref.410 ]
  %r2083 = bitcast double %r2082 to i64
  %rs4gc.s32 = inttoptr i64 %r2083 to ptr addrspace(1)
  %r2084.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s32 to i64
  %r2084 = call i64 asm "", "=r,0"(i64 %r2084.rs4i) #7
  %r2085 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2086 = icmp ne i32 %r2085, 0
  br i1 %r2086, label %shadow.root.barrier.438, label %shadow.root.barrier.done.439

pget.recv_other.412:                              ; preds = %shadow.root.barrier.done.406
  %r1941 = icmp eq i64 %r1938, 32761
  br i1 %r1941, label %pget.recv_sso.407, label %pget.check_class_ref.413

pget.check_class_ref.413:                         ; preds = %pget.recv_other.412
  %r1942 = icmp eq i64 %r1938, 32766
  br i1 %r1942, label %pget.recv_class_ref.410, label %pget.recv_bad.409

pic.hit.414:                                      ; preds = %pic.token.430
  %r1972 = getelementptr i64, ptr %r1957, i64 1
  %r1973 = load i64, ptr %r1972, align 8
  %r1974 = and i64 %r1973, 1073741824
  %r1975 = icmp ne i64 %r1974, 0
  br i1 %r1975, label %pic.hit.overflow.431, label %pic.hit.inline.432

pic.hit.live.415:                                 ; preds = %pic.hit.inline.432
  br label %pic.merge.428

pic.prefix.guard.416:                             ; preds = %pic.token.430
  %r1988 = getelementptr i64, ptr %r1957, i64 2
  %r1989 = load i64, ptr %r1988, align 8
  %r1990 = icmp ne i64 %r1989, 0
  br i1 %r1990, label %pic.prefix.meta.417, label %pic.miss.425

pic.prefix.meta.417:                              ; preds = %pic.prefix.guard.416
  %r1991 = add nuw nsw i64 %r1937, 8
  %r1992 = inttoptr i64 %r1991 to ptr
  %r1993 = load i64, ptr %r1992, align 8
  %r1994 = icmp ne i64 %r1993, 0
  br i1 %r1994, label %pic.prefix.token.418, label %pic.miss.425

pic.prefix.token.418:                             ; preds = %pic.prefix.meta.417
  %r1995 = inttoptr i64 %r1993 to ptr
  %r1996 = getelementptr i64, ptr %r1995, i64 6
  %r1997 = load i64, ptr %r1996, align 8
  %r1998 = icmp eq i64 %r1997, %r1989
  br i1 %r1998, label %pic.prefix.hit.419, label %pic.miss.425

pic.prefix.hit.419:                               ; preds = %pic.prefix.token.418
  %r1999 = getelementptr i64, ptr %r1957, i64 1
  %r2000 = load i64, ptr %r1999, align 8
  %r2001 = shl i64 %r2000, 3
  %r2002 = add nuw nsw i64 %r1937, 16
  %r2003 = add i64 %r2002, %r2001
  %r2004 = inttoptr i64 %r2003 to ptr
  %r2005 = load double, ptr %r2004, align 8
  br label %pic.merge.428

pic.desc.classify.420:                            ; preds = %pic.recv_hdr.429
  %r1961 = and i1 %r1951, %r1958
  br i1 %r1961, label %pic.desc.prefix.guard.421, label %pic.miss.cold.426

pic.desc.prefix.guard.421:                        ; preds = %pic.desc.classify.420
  %r2006 = getelementptr i64, ptr %r1957, i64 2
  %r2007 = load i64, ptr %r2006, align 8
  %r2008 = icmp ne i64 %r2007, 0
  br i1 %r2008, label %pic.desc.prefix.meta.422, label %pic.miss.cold.426

pic.desc.prefix.meta.422:                         ; preds = %pic.desc.prefix.guard.421
  %r2009 = add nuw nsw i64 %r1937, 8
  %r2010 = inttoptr i64 %r2009 to ptr
  %r2011 = load i64, ptr %r2010, align 8
  %r2012 = icmp ne i64 %r2011, 0
  br i1 %r2012, label %pic.desc.prefix.token.423, label %pic.miss.cold.426

pic.desc.prefix.token.423:                        ; preds = %pic.desc.prefix.meta.422
  %r2013 = inttoptr i64 %r2011 to ptr
  %r2014 = getelementptr i64, ptr %r2013, i64 6
  %r2015 = load i64, ptr %r2014, align 8
  %r2016 = icmp eq i64 %r2015, %r2007
  br i1 %r2016, label %pic.desc.prefix.hit.424, label %pic.miss.cold.426

pic.desc.prefix.hit.424:                          ; preds = %pic.desc.prefix.token.423
  %r2017 = getelementptr i64, ptr %r1957, i64 1
  %r2018 = load i64, ptr %r2017, align 8
  %r2019 = shl i64 %r2018, 3
  %r2020 = add nuw nsw i64 %r1937, 16
  %r2021 = add i64 %r2020, %r2019
  %r2022 = inttoptr i64 %r2021 to ptr
  %r2023 = load double, ptr %r2022, align 8
  br label %pic.merge.428

pic.miss.425:                                     ; preds = %pic.hit.inline.432, %pic.prefix.token.418, %pic.prefix.meta.417, %pic.prefix.guard.416
  %r2024 = getelementptr i64, ptr %r1957, i64 3
  %r2025 = load i64, ptr %r2024, align 8
  %r2026 = icmp sgt i64 %r2025, 0
  br i1 %r2026, label %pic.ways.433, label %pic.miss.call.427

pic.miss.cold.426:                                ; preds = %pic.desc.prefix.token.423, %pic.desc.prefix.meta.422, %pic.desc.prefix.guard.421, %pic.desc.classify.420, %pget.recv_ok.408
  br label %pic.miss.call.427

pic.miss.call.427:                                ; preds = %pic.way.load.434, %pic.ways.433, %pic.miss.cold.426, %pic.miss.425
  %r2065 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2066 = bitcast double %r2065 to i64
  %r2067 = and i64 %r2066, 281474976710655
  %statepoint_token619 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1937, i64 %r2067, ptr @perry_ic_test_json_template_capture_ts__19, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s27, ptr addrspace(1) %.01113, ptr addrspace(1) %.28, ptr addrspace(1) %r1702.0, ptr addrspace(1) %.01129, ptr addrspace(1) %r1702.0.base) ]
  %r2068620 = call double @llvm.experimental.gc.result.f64(token %statepoint_token619)
  %rs4gc.s27.relocated621 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token619, i32 0, i32 0) ; (%rs4gc.s27, %rs4gc.s27)
  %r48.1.base.relocated622 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token619, i32 1, i32 1) ; (%.01113, %.01113)
  %rs4gc.s12.relocated623 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token619, i32 2, i32 2) ; (%.28, %.28)
  %r1702.0.relocated624 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token619, i32 5, i32 3) ; (%r1702.0.base, %r1702.0)
  %r48.1.relocated625 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token619, i32 1, i32 4) ; (%.01113, %.01129)
  %r1702.0.base.relocated626 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token619, i32 5, i32 5) ; (%r1702.0.base, %r1702.0.base)
  br label %pic.merge.428

pic.merge.428:                                    ; preds = %pic.way.live.435, %pic.hit.overflow.431, %pic.miss.call.427, %pic.desc.prefix.hit.424, %pic.prefix.hit.419, %pic.hit.live.415
  %.11173 = phi ptr addrspace(1) [ %rs4gc.s27.relocated629, %pic.hit.overflow.431 ], [ %rs4gc.s27.relocated621, %pic.miss.call.427 ], [ %rs4gc.s27, %pic.way.live.435 ], [ %rs4gc.s27, %pic.hit.live.415 ], [ %rs4gc.s27, %pic.prefix.hit.419 ], [ %rs4gc.s27, %pic.desc.prefix.hit.424 ]
  %.71165 = phi ptr addrspace(1) [ %r1702.0.relocated632, %pic.hit.overflow.431 ], [ %r1702.0.relocated624, %pic.miss.call.427 ], [ %r1702.0, %pic.way.live.435 ], [ %r1702.0, %pic.hit.live.415 ], [ %r1702.0, %pic.prefix.hit.419 ], [ %r1702.0, %pic.desc.prefix.hit.424 ]
  %.101139 = phi ptr addrspace(1) [ %r48.1.relocated633, %pic.hit.overflow.431 ], [ %r48.1.relocated625, %pic.miss.call.427 ], [ %.01129, %pic.way.live.435 ], [ %.01129, %pic.hit.live.415 ], [ %.01129, %pic.prefix.hit.419 ], [ %.01129, %pic.desc.prefix.hit.424 ]
  %.101123 = phi ptr addrspace(1) [ %r48.1.base.relocated630, %pic.hit.overflow.431 ], [ %r48.1.base.relocated622, %pic.miss.call.427 ], [ %.01113, %pic.way.live.435 ], [ %.01113, %pic.hit.live.415 ], [ %.01113, %pic.prefix.hit.419 ], [ %.01113, %pic.desc.prefix.hit.424 ]
  %.38 = phi ptr addrspace(1) [ %rs4gc.s12.relocated631, %pic.hit.overflow.431 ], [ %rs4gc.s12.relocated623, %pic.miss.call.427 ], [ %.28, %pic.way.live.435 ], [ %.28, %pic.hit.live.415 ], [ %.28, %pic.prefix.hit.419 ], [ %.28, %pic.desc.prefix.hit.424 ]
  %r2069 = phi double [ %r1985, %pic.hit.live.415 ], [ %r1980628, %pic.hit.overflow.431 ], [ %r2005, %pic.prefix.hit.419 ], [ %r2023, %pic.desc.prefix.hit.424 ], [ %r2062, %pic.way.live.435 ], [ %r2068620, %pic.miss.call.427 ]
  br label %pget.recv_merge.411

pic.recv_hdr.429:                                 ; preds = %pget.recv_ok.408
  %r1948 = sub nuw nsw i64 %r1937, 8
  %r1949 = inttoptr i64 %r1948 to ptr
  %r1950 = load i8, ptr %r1949, align 1
  %r1951 = icmp eq i8 %r1950, 2
  %r1952 = sub nuw nsw i64 %r1937, 6
  %r1953 = inttoptr i64 %r1952 to ptr
  %r1954 = load i16, ptr %r1953, align 2
  %r1955 = and i16 %r1954, 2048
  %r1956 = icmp eq i16 %r1955, 0
  %r1957 = load ptr, ptr @perry_ic_test_json_template_capture_ts__19, align 8
  %r1958 = icmp ne ptr %r1957, null
  %r1959 = and i1 %r1951, %r1956
  %r1960 = and i1 %r1959, %r1958
  br i1 %r1960, label %pic.token.430, label %pic.desc.classify.420

pic.token.430:                                    ; preds = %pic.recv_hdr.429
  %r1962 = add nuw nsw i64 %r1937, 4
  %r1963 = inttoptr i64 %r1962 to ptr
  %r1964 = load i32, ptr %r1963, align 4
  %r1965 = zext i32 %r1964 to i64
  %r1966 = or i64 %r1965, 4611686018427387904
  %r1967 = icmp ne i32 %r1964, 0
  %r1968 = getelementptr i64, ptr %r1957, i64 0
  %r1969 = load i64, ptr %r1968, align 8
  %r1970 = icmp eq i64 %r1966, %r1969
  %r1971 = and i1 %r1970, %r1967
  br i1 %r1971, label %pic.hit.414, label %pic.prefix.guard.416

pic.hit.overflow.431:                             ; preds = %pic.hit.414
  %r1976 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r1977 = bitcast double %r1976 to i64
  %r1978 = and i64 %r1977, 281474976710655
  %r1979 = trunc i64 %r1973 to i32
  %statepoint_token627 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1937, i64 %r1978, i32 %r1979, ptr @perry_ic_test_json_template_capture_ts__19, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s27, ptr addrspace(1) %.01113, ptr addrspace(1) %.28, ptr addrspace(1) %r1702.0, ptr addrspace(1) %.01129, ptr addrspace(1) %r1702.0.base) ]
  %r1980628 = call double @llvm.experimental.gc.result.f64(token %statepoint_token627)
  %rs4gc.s27.relocated629 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 0, i32 0) ; (%rs4gc.s27, %rs4gc.s27)
  %r48.1.base.relocated630 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 1, i32 1) ; (%.01113, %.01113)
  %rs4gc.s12.relocated631 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 2, i32 2) ; (%.28, %.28)
  %r1702.0.relocated632 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 5, i32 3) ; (%r1702.0.base, %r1702.0)
  %r48.1.relocated633 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 1, i32 4) ; (%.01113, %.01129)
  %r1702.0.base.relocated634 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 5, i32 5) ; (%r1702.0.base, %r1702.0.base)
  br label %pic.merge.428

pic.hit.inline.432:                               ; preds = %pic.hit.414
  %r1981 = shl i64 %r1973, 3
  %r1982 = add nuw nsw i64 %r1937, 16
  %r1983 = add i64 %r1982, %r1981
  %r1984 = inttoptr i64 %r1983 to ptr
  %r1985 = load double, ptr %r1984, align 8
  %r1986 = bitcast double %r1985 to i64
  %r1987 = icmp eq i64 %r1986, 9222246136947933200
  br i1 %r1987, label %pic.miss.425, label %pic.hit.live.415

pic.ways.433:                                     ; preds = %pic.miss.425
  %r2027 = getelementptr i64, ptr %r1957, i64 4
  %r2028 = load i64, ptr %r2027, align 8
  %r2029 = icmp eq i64 %r2028, %r1966
  %r2030 = getelementptr i64, ptr %r1957, i64 5
  %r2031 = load i64, ptr %r2030, align 8
  %r2032 = select i1 %r2029, i64 %r2031, i64 0
  %r2033 = getelementptr i64, ptr %r1957, i64 6
  %r2034 = load i64, ptr %r2033, align 8
  %r2035 = icmp eq i64 %r2034, %r1966
  %r2036 = getelementptr i64, ptr %r1957, i64 7
  %r2037 = load i64, ptr %r2036, align 8
  %r2038 = select i1 %r2035, i64 %r2037, i64 0
  %r2039 = getelementptr i64, ptr %r1957, i64 8
  %r2040 = load i64, ptr %r2039, align 8
  %r2041 = icmp eq i64 %r2040, %r1966
  %r2042 = getelementptr i64, ptr %r1957, i64 9
  %r2043 = load i64, ptr %r2042, align 8
  %r2044 = select i1 %r2041, i64 %r2043, i64 0
  %r2045 = getelementptr i64, ptr %r1957, i64 10
  %r2046 = load i64, ptr %r2045, align 8
  %r2047 = icmp eq i64 %r2046, %r1966
  %r2048 = getelementptr i64, ptr %r1957, i64 11
  %r2049 = load i64, ptr %r2048, align 8
  %r2050 = select i1 %r2047, i64 %r2049, i64 0
  %r2051 = or i1 %r2029, %r2035
  %r2052 = select i1 %r2029, i64 %r2032, i64 %r2038
  %r2053 = or i1 %r2041, %r2047
  %r2054 = select i1 %r2041, i64 %r2044, i64 %r2050
  %r2055 = or i1 %r2051, %r2053
  %r2056 = select i1 %r2051, i64 %r2052, i64 %r2054
  %r2057 = and i1 %r1967, %r2055
  br i1 %r2057, label %pic.way.load.434, label %pic.miss.call.427

pic.way.load.434:                                 ; preds = %pic.ways.433
  %r2058 = shl i64 %r2056, 3
  %r2059 = add nuw nsw i64 %r1937, 16
  %r2060 = add i64 %r2059, %r2058
  %r2061 = inttoptr i64 %r2060 to ptr
  %r2062 = load double, ptr %r2061, align 8
  %r2063 = bitcast double %r2062 to i64
  %r2064 = icmp eq i64 %r2063, 9222246136947933200
  br i1 %r2064, label %pic.miss.call.427, label %pic.way.live.435

pic.way.live.435:                                 ; preds = %pic.way.load.434
  br label %pic.merge.428

pget.throw_nullish.436:                           ; preds = %pget.recv_bad.409
  %r2073 = zext i1 %r2071 to i32
  %statepoint_token635 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2073, ptr @test_json_template_capture_ts_.str.2.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.437:                       ; preds = %pget.recv_bad.409
  %r2074 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2075 = bitcast double %r2074 to i64
  %r2076 = and i64 %r2075, 281474976710655
  %statepoint_token636 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1936, i64 %r2076, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s27, ptr addrspace(1) %.01113, ptr addrspace(1) %.28, ptr addrspace(1) %r1702.0, ptr addrspace(1) %.01129, ptr addrspace(1) %r1702.0.base) ]
  %r2077637 = call double @llvm.experimental.gc.result.f64(token %statepoint_token636)
  %rs4gc.s27.relocated638 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token636, i32 0, i32 0) ; (%rs4gc.s27, %rs4gc.s27)
  %r48.1.base.relocated639 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token636, i32 1, i32 1) ; (%.01113, %.01113)
  %rs4gc.s12.relocated640 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token636, i32 2, i32 2) ; (%.28, %.28)
  %r1702.0.relocated641 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token636, i32 5, i32 3) ; (%r1702.0.base, %r1702.0)
  %r48.1.relocated642 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token636, i32 1, i32 4) ; (%.01113, %.01129)
  %r1702.0.base.relocated643 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token636, i32 5, i32 5) ; (%r1702.0.base, %r1702.0.base)
  br label %pget.recv_merge.411

shadow.root.barrier.438:                          ; preds = %pget.recv_merge.411
  call void @js_write_barrier_root_nanbox(i64 %r2084) #7
  br label %shadow.root.barrier.done.439

shadow.root.barrier.done.439:                     ; preds = %shadow.root.barrier.438, %pget.recv_merge.411
  %r2087.rs4i = ptrtoint ptr addrspace(1) %.61164 to i64
  %r2087.rs4o = call i64 asm "", "=r,0"(i64 %r2087.rs4i) #7
  %r2087 = bitcast i64 %r2087.rs4o to double
  %r2088 = bitcast double %r2087 to i64
  %r2089 = and i64 %r2088, 281474976710655
  %r2090 = lshr i64 %r2088, 48
  %r2091 = icmp eq i64 %r2090, 32765
  %r2092 = icmp ugt i64 %r2089, 1048575
  %r2093 = and i1 %r2091, %r2092
  br i1 %r2093, label %arr.guard.deref.444, label %arr.fallback.441

arr.fast.440:                                     ; preds = %arr.guard.range.446
  %r2152 = add i64 %r2108, 640
  %r2153 = inttoptr i64 %r2152 to ptr
  %r2154 = load double, ptr %r2153, align 8
  %r2155 = bitcast double %r2154 to i64
  %r2156 = icmp eq i64 %r2155, 9222246136947933200
  %r2158 = select i1 %r2156, double 0x7FFC000000000001, double %r2154
  br label %arr.merge.443

arr.fallback.441:                                 ; preds = %arr.guard.live.445, %arr.guard.deref.444, %shadow.root.barrier.done.439
  %statepoint_token644 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 6060382687846203412, double %r2087, double 7.900000e+01, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s32, ptr addrspace(1) %.01172, ptr addrspace(1) %.91122, ptr addrspace(1) %.37, ptr addrspace(1) %.91138) ]
  %r2148645 = call double @llvm.experimental.gc.result.f64(token %statepoint_token644)
  %rs4gc.s32.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token644, i32 0, i32 0) ; (%rs4gc.s32, %rs4gc.s32)
  %rs4gc.s27.relocated646 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token644, i32 1, i32 1) ; (%.01172, %.01172)
  %r48.1.base.relocated647 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token644, i32 2, i32 2) ; (%.91122, %.91122)
  %rs4gc.s12.relocated648 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token644, i32 3, i32 3) ; (%.37, %.37)
  %r48.1.relocated649 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token644, i32 2, i32 4) ; (%.91122, %.91138)
  br label %arr.merge.443

arr.guard.oob.442:                                ; preds = %arr.guard.range.446
  br label %arr.merge.443

arr.merge.443:                                    ; preds = %arr.guard.oob.442, %arr.fallback.441, %arr.fast.440
  %.01177 = phi ptr addrspace(1) [ %rs4gc.s32, %arr.fast.440 ], [ %rs4gc.s32, %arr.guard.oob.442 ], [ %rs4gc.s32.relocated, %arr.fallback.441 ]
  %.21174 = phi ptr addrspace(1) [ %.01172, %arr.fast.440 ], [ %.01172, %arr.guard.oob.442 ], [ %rs4gc.s27.relocated646, %arr.fallback.441 ]
  %.111140 = phi ptr addrspace(1) [ %.91138, %arr.fast.440 ], [ %.91138, %arr.guard.oob.442 ], [ %r48.1.relocated649, %arr.fallback.441 ]
  %.111124 = phi ptr addrspace(1) [ %.91122, %arr.fast.440 ], [ %.91122, %arr.guard.oob.442 ], [ %r48.1.base.relocated647, %arr.fallback.441 ]
  %.39 = phi ptr addrspace(1) [ %.37, %arr.fast.440 ], [ %.37, %arr.guard.oob.442 ], [ %rs4gc.s12.relocated648, %arr.fallback.441 ]
  %r2159 = phi double [ %r2158, %arr.fast.440 ], [ %r2148645, %arr.fallback.441 ], [ 0x7FFC000000000001, %arr.guard.oob.442 ]
  %r2160 = bitcast double %r2159 to i64
  %r2161 = and i64 %r2160, 281474976710655
  %r2162 = lshr i64 %r2160, 48
  %r2163 = and i64 %r2162, 65533
  %r2164 = icmp eq i64 %r2163, 32765
  br i1 %r2164, label %pget.recv_ok.448, label %pget.recv_other.452

arr.guard.deref.444:                              ; preds = %shadow.root.barrier.done.439
  %r2094 = bitcast double %r2087 to i64
  %r2095 = and i64 %r2094, 281474976710655
  %r2096 = sub nsw i64 %r2095, 8
  %r2097 = inttoptr i64 %r2096 to ptr
  %r2098 = load i8, ptr %r2097, align 1
  %r2099 = icmp eq i8 %r2098, 1
  %r2100 = sub nsw i64 %r2095, 7
  %r2101 = inttoptr i64 %r2100 to ptr
  %r2102 = load i8, ptr %r2101, align 1
  %r2103 = and i8 %r2102, -128
  %r2104 = icmp ne i8 %r2103, 0
  %r2105 = inttoptr i64 %r2095 to ptr
  %r2106 = load i64, ptr %r2105, align 8
  %r2107 = and i1 %r2099, %r2104
  %r2108 = select i1 %r2107, i64 %r2106, i64 %r2095
  %r2109 = lshr i64 %r2108, 48
  %r2110 = icmp eq i64 %r2109, 0
  %r2111 = icmp ugt i64 %r2108, 1048575
  %r2112 = and i1 %r2110, %r2111
  br i1 %r2112, label %arr.guard.live.445, label %arr.fallback.441

arr.guard.live.445:                               ; preds = %arr.guard.deref.444
  %r2113 = sub nuw i64 %r2108, 8
  %r2114 = inttoptr i64 %r2113 to ptr
  %r2115 = load i8, ptr %r2114, align 1
  %r2116 = icmp eq i8 %r2115, 1
  %r2117 = sub nuw i64 %r2108, 7
  %r2118 = inttoptr i64 %r2117 to ptr
  %r2119 = load i8, ptr %r2118, align 1
  %r2120 = and i8 %r2119, -128
  %r2121 = icmp eq i8 %r2120, 0
  %r2122 = sub nuw i64 %r2108, 6
  %r2123 = inttoptr i64 %r2122 to ptr
  %r2124 = load i16, ptr %r2123, align 2
  %r2125 = and i16 %r2124, 1024
  %r2126 = icmp eq i16 %r2125, 0
  %r2127 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2128 = icmp eq i8 %r2127, 0
  %r2129 = inttoptr i64 %r2108 to ptr
  %r2130 = load i32, ptr %r2129, align 4
  %r2131 = getelementptr i8, ptr %r2129, i64 4
  %r2132 = load i32, ptr %r2131, align 4
  %r2136 = icmp ule i32 %r2130, 16000000
  %r2137 = icmp ule i32 %r2132, 16000000
  %r2138 = icmp ule i32 %r2130, %r2132
  %r2139 = and i1 %r2116, %r2121
  %r2140 = and i1 %r2139, %r2126
  %r2141 = and i1 %r2140, %r2128
  %r2143 = and i1 %r2141, %r2136
  %r2144 = and i1 %r2143, %r2137
  %r2145 = and i1 %r2144, %r2138
  br i1 %r2145, label %arr.guard.range.446, label %arr.fallback.441

arr.guard.range.446:                              ; preds = %arr.guard.live.445
  %r2135 = icmp ult i32 79, %r2130
  br i1 %r2135, label %arr.fast.440, label %arr.guard.oob.442

pget.recv_sso.447:                                ; preds = %pget.recv_other.452
  %r2302 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2303 = bitcast double %r2302 to i64
  %r2304 = and i64 %r2303, 281474976710655
  %statepoint_token650 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2160, i64 %r2304, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111124, ptr addrspace(1) %.39, ptr addrspace(1) %.21174, ptr addrspace(1) %.01177, ptr addrspace(1) %.111140) ]
  %r2305651 = call double @llvm.experimental.gc.result.f64(token %statepoint_token650)
  %r48.1.base.relocated652 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 0, i32 0) ; (%.111124, %.111124)
  %rs4gc.s12.relocated653 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 1, i32 1) ; (%.39, %.39)
  %rs4gc.s27.relocated654 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 2, i32 2) ; (%.21174, %.21174)
  %rs4gc.s32.relocated655 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 3, i32 3) ; (%.01177, %.01177)
  %r48.1.relocated656 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token650, i32 0, i32 4) ; (%.111124, %.111140)
  br label %pget.recv_merge.451

pget.recv_ok.448:                                 ; preds = %arr.merge.443
  %r2171 = icmp ugt i64 %r2161, 1048575
  br i1 %r2171, label %pic.recv_hdr.469, label %pic.miss.cold.466

pget.recv_bad.449:                                ; preds = %pget.check_class_ref.453
  %r2294 = icmp eq i64 %r2160, 9222246136947933185
  %r2295 = icmp eq i64 %r2160, 9222246136947933186
  %r2296 = or i1 %r2294, %r2295
  br i1 %r2296, label %pget.throw_nullish.476, label %pget.recv_undef_return.477

pget.recv_class_ref.450:                          ; preds = %pget.check_class_ref.453
  %r2167 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2168 = bitcast double %r2167 to i64
  %r2169 = and i64 %r2168, 281474976710655
  %statepoint_token657 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6060382687846203413, i64 %r2160, i64 %r2169, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111124, ptr addrspace(1) %.39, ptr addrspace(1) %.21174, ptr addrspace(1) %.01177, ptr addrspace(1) %.111140) ]
  %r2170658 = call double @llvm.experimental.gc.result.f64(token %statepoint_token657)
  %r48.1.base.relocated659 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token657, i32 0, i32 0) ; (%.111124, %.111124)
  %rs4gc.s12.relocated660 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token657, i32 1, i32 1) ; (%.39, %.39)
  %rs4gc.s27.relocated661 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token657, i32 2, i32 2) ; (%.21174, %.21174)
  %rs4gc.s32.relocated662 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token657, i32 3, i32 3) ; (%.01177, %.01177)
  %r48.1.relocated663 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token657, i32 0, i32 4) ; (%.111124, %.111140)
  br label %pget.recv_merge.451

pget.recv_merge.451:                              ; preds = %pget.recv_undef_return.477, %pic.merge.468, %pget.recv_class_ref.450, %pget.recv_sso.447
  %.11178 = phi ptr addrspace(1) [ %.21179, %pic.merge.468 ], [ %rs4gc.s32.relocated655, %pget.recv_sso.447 ], [ %rs4gc.s32.relocated662, %pget.recv_class_ref.450 ], [ %rs4gc.s32.relocated684, %pget.recv_undef_return.477 ]
  %.31175 = phi ptr addrspace(1) [ %.41176, %pic.merge.468 ], [ %rs4gc.s27.relocated654, %pget.recv_sso.447 ], [ %rs4gc.s27.relocated661, %pget.recv_class_ref.450 ], [ %rs4gc.s27.relocated683, %pget.recv_undef_return.477 ]
  %.121141 = phi ptr addrspace(1) [ %.131142, %pic.merge.468 ], [ %r48.1.relocated656, %pget.recv_sso.447 ], [ %r48.1.relocated663, %pget.recv_class_ref.450 ], [ %r48.1.relocated685, %pget.recv_undef_return.477 ]
  %.121125 = phi ptr addrspace(1) [ %.131126, %pic.merge.468 ], [ %r48.1.base.relocated652, %pget.recv_sso.447 ], [ %r48.1.base.relocated659, %pget.recv_class_ref.450 ], [ %r48.1.base.relocated681, %pget.recv_undef_return.477 ]
  %.40 = phi ptr addrspace(1) [ %.41, %pic.merge.468 ], [ %rs4gc.s12.relocated653, %pget.recv_sso.447 ], [ %rs4gc.s12.relocated660, %pget.recv_class_ref.450 ], [ %rs4gc.s12.relocated682, %pget.recv_undef_return.477 ]
  %r2306 = phi double [ %r2293, %pic.merge.468 ], [ %r2301680, %pget.recv_undef_return.477 ], [ %r2305651, %pget.recv_sso.447 ], [ %r2170658, %pget.recv_class_ref.450 ]
  %r2307.rs4i = ptrtoint ptr addrspace(1) %.31175 to i64
  %r2307 = call i64 asm "", "=r,0"(i64 %r2307.rs4i) #7
  %r2308 = bitcast i64 %r2307 to double
  %r2309.rs4i = ptrtoint ptr addrspace(1) %.11178 to i64
  %r2309 = call i64 asm "", "=r,0"(i64 %r2309.rs4i) #7
  %r2310 = bitcast i64 %r2309 to double
  %r2311 = and i64 %r2307, -281474976710656
  %r2312 = icmp ult i64 %r2311, 9221401712017801216
  %r2313 = icmp ugt i64 %r2311, 9223090561878065152
  %r2314 = or i1 %r2312, %r2313
  %r2315 = and i64 %r2309, -281474976710656
  %r2316 = icmp ult i64 %r2315, 9221401712017801216
  %r2317 = icmp ugt i64 %r2315, 9223090561878065152
  %r2318 = or i1 %r2316, %r2317
  %r2319 = and i1 %r2314, %r2318
  %r2320 = bitcast double %r2306 to i64
  %r2321 = and i64 %r2320, -281474976710656
  %r2322 = icmp ult i64 %r2321, 9221401712017801216
  %r2323 = icmp ugt i64 %r2321, 9223090561878065152
  %r2324 = or i1 %r2322, %r2323
  %r2325 = and i1 %r2319, %r2324
  br i1 %r2325, label %guarded_add.numeric.478, label %guarded_add.dynamic.479

pget.recv_other.452:                              ; preds = %arr.merge.443
  %r2165 = icmp eq i64 %r2162, 32761
  br i1 %r2165, label %pget.recv_sso.447, label %pget.check_class_ref.453

pget.check_class_ref.453:                         ; preds = %pget.recv_other.452
  %r2166 = icmp eq i64 %r2162, 32766
  br i1 %r2166, label %pget.recv_class_ref.450, label %pget.recv_bad.449

pic.hit.454:                                      ; preds = %pic.token.470
  %r2196 = getelementptr i64, ptr %r2181, i64 1
  %r2197 = load i64, ptr %r2196, align 8
  %r2198 = and i64 %r2197, 1073741824
  %r2199 = icmp ne i64 %r2198, 0
  br i1 %r2199, label %pic.hit.overflow.471, label %pic.hit.inline.472

pic.hit.live.455:                                 ; preds = %pic.hit.inline.472
  br label %pic.merge.468

pic.prefix.guard.456:                             ; preds = %pic.token.470
  %r2212 = getelementptr i64, ptr %r2181, i64 2
  %r2213 = load i64, ptr %r2212, align 8
  %r2214 = icmp ne i64 %r2213, 0
  br i1 %r2214, label %pic.prefix.meta.457, label %pic.miss.465

pic.prefix.meta.457:                              ; preds = %pic.prefix.guard.456
  %r2215 = add nuw nsw i64 %r2161, 8
  %r2216 = inttoptr i64 %r2215 to ptr
  %r2217 = load i64, ptr %r2216, align 8
  %r2218 = icmp ne i64 %r2217, 0
  br i1 %r2218, label %pic.prefix.token.458, label %pic.miss.465

pic.prefix.token.458:                             ; preds = %pic.prefix.meta.457
  %r2219 = inttoptr i64 %r2217 to ptr
  %r2220 = getelementptr i64, ptr %r2219, i64 6
  %r2221 = load i64, ptr %r2220, align 8
  %r2222 = icmp eq i64 %r2221, %r2213
  br i1 %r2222, label %pic.prefix.hit.459, label %pic.miss.465

pic.prefix.hit.459:                               ; preds = %pic.prefix.token.458
  %r2223 = getelementptr i64, ptr %r2181, i64 1
  %r2224 = load i64, ptr %r2223, align 8
  %r2225 = shl i64 %r2224, 3
  %r2226 = add nuw nsw i64 %r2161, 16
  %r2227 = add i64 %r2226, %r2225
  %r2228 = inttoptr i64 %r2227 to ptr
  %r2229 = load double, ptr %r2228, align 8
  br label %pic.merge.468

pic.desc.classify.460:                            ; preds = %pic.recv_hdr.469
  %r2185 = and i1 %r2175, %r2182
  br i1 %r2185, label %pic.desc.prefix.guard.461, label %pic.miss.cold.466

pic.desc.prefix.guard.461:                        ; preds = %pic.desc.classify.460
  %r2230 = getelementptr i64, ptr %r2181, i64 2
  %r2231 = load i64, ptr %r2230, align 8
  %r2232 = icmp ne i64 %r2231, 0
  br i1 %r2232, label %pic.desc.prefix.meta.462, label %pic.miss.cold.466

pic.desc.prefix.meta.462:                         ; preds = %pic.desc.prefix.guard.461
  %r2233 = add nuw nsw i64 %r2161, 8
  %r2234 = inttoptr i64 %r2233 to ptr
  %r2235 = load i64, ptr %r2234, align 8
  %r2236 = icmp ne i64 %r2235, 0
  br i1 %r2236, label %pic.desc.prefix.token.463, label %pic.miss.cold.466

pic.desc.prefix.token.463:                        ; preds = %pic.desc.prefix.meta.462
  %r2237 = inttoptr i64 %r2235 to ptr
  %r2238 = getelementptr i64, ptr %r2237, i64 6
  %r2239 = load i64, ptr %r2238, align 8
  %r2240 = icmp eq i64 %r2239, %r2231
  br i1 %r2240, label %pic.desc.prefix.hit.464, label %pic.miss.cold.466

pic.desc.prefix.hit.464:                          ; preds = %pic.desc.prefix.token.463
  %r2241 = getelementptr i64, ptr %r2181, i64 1
  %r2242 = load i64, ptr %r2241, align 8
  %r2243 = shl i64 %r2242, 3
  %r2244 = add nuw nsw i64 %r2161, 16
  %r2245 = add i64 %r2244, %r2243
  %r2246 = inttoptr i64 %r2245 to ptr
  %r2247 = load double, ptr %r2246, align 8
  br label %pic.merge.468

pic.miss.465:                                     ; preds = %pic.hit.inline.472, %pic.prefix.token.458, %pic.prefix.meta.457, %pic.prefix.guard.456
  %r2248 = getelementptr i64, ptr %r2181, i64 3
  %r2249 = load i64, ptr %r2248, align 8
  %r2250 = icmp sgt i64 %r2249, 0
  br i1 %r2250, label %pic.ways.473, label %pic.miss.call.467

pic.miss.cold.466:                                ; preds = %pic.desc.prefix.token.463, %pic.desc.prefix.meta.462, %pic.desc.prefix.guard.461, %pic.desc.classify.460, %pget.recv_ok.448
  br label %pic.miss.call.467

pic.miss.call.467:                                ; preds = %pic.way.load.474, %pic.ways.473, %pic.miss.cold.466, %pic.miss.465
  %r2289 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2290 = bitcast double %r2289 to i64
  %r2291 = and i64 %r2290, 281474976710655
  %statepoint_token664 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2161, i64 %r2291, ptr @perry_ic_test_json_template_capture_ts__22, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111124, ptr addrspace(1) %.39, ptr addrspace(1) %.21174, ptr addrspace(1) %.01177, ptr addrspace(1) %.111140) ]
  %r2292665 = call double @llvm.experimental.gc.result.f64(token %statepoint_token664)
  %r48.1.base.relocated666 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token664, i32 0, i32 0) ; (%.111124, %.111124)
  %rs4gc.s12.relocated667 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token664, i32 1, i32 1) ; (%.39, %.39)
  %rs4gc.s27.relocated668 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token664, i32 2, i32 2) ; (%.21174, %.21174)
  %rs4gc.s32.relocated669 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token664, i32 3, i32 3) ; (%.01177, %.01177)
  %r48.1.relocated670 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token664, i32 0, i32 4) ; (%.111124, %.111140)
  br label %pic.merge.468

pic.merge.468:                                    ; preds = %pic.way.live.475, %pic.hit.overflow.471, %pic.miss.call.467, %pic.desc.prefix.hit.464, %pic.prefix.hit.459, %pic.hit.live.455
  %.21179 = phi ptr addrspace(1) [ %rs4gc.s32.relocated676, %pic.hit.overflow.471 ], [ %rs4gc.s32.relocated669, %pic.miss.call.467 ], [ %.01177, %pic.way.live.475 ], [ %.01177, %pic.hit.live.455 ], [ %.01177, %pic.prefix.hit.459 ], [ %.01177, %pic.desc.prefix.hit.464 ]
  %.41176 = phi ptr addrspace(1) [ %rs4gc.s27.relocated675, %pic.hit.overflow.471 ], [ %rs4gc.s27.relocated668, %pic.miss.call.467 ], [ %.21174, %pic.way.live.475 ], [ %.21174, %pic.hit.live.455 ], [ %.21174, %pic.prefix.hit.459 ], [ %.21174, %pic.desc.prefix.hit.464 ]
  %.131142 = phi ptr addrspace(1) [ %r48.1.relocated677, %pic.hit.overflow.471 ], [ %r48.1.relocated670, %pic.miss.call.467 ], [ %.111140, %pic.way.live.475 ], [ %.111140, %pic.hit.live.455 ], [ %.111140, %pic.prefix.hit.459 ], [ %.111140, %pic.desc.prefix.hit.464 ]
  %.131126 = phi ptr addrspace(1) [ %r48.1.base.relocated673, %pic.hit.overflow.471 ], [ %r48.1.base.relocated666, %pic.miss.call.467 ], [ %.111124, %pic.way.live.475 ], [ %.111124, %pic.hit.live.455 ], [ %.111124, %pic.prefix.hit.459 ], [ %.111124, %pic.desc.prefix.hit.464 ]
  %.41 = phi ptr addrspace(1) [ %rs4gc.s12.relocated674, %pic.hit.overflow.471 ], [ %rs4gc.s12.relocated667, %pic.miss.call.467 ], [ %.39, %pic.way.live.475 ], [ %.39, %pic.hit.live.455 ], [ %.39, %pic.prefix.hit.459 ], [ %.39, %pic.desc.prefix.hit.464 ]
  %r2293 = phi double [ %r2209, %pic.hit.live.455 ], [ %r2204672, %pic.hit.overflow.471 ], [ %r2229, %pic.prefix.hit.459 ], [ %r2247, %pic.desc.prefix.hit.464 ], [ %r2286, %pic.way.live.475 ], [ %r2292665, %pic.miss.call.467 ]
  br label %pget.recv_merge.451

pic.recv_hdr.469:                                 ; preds = %pget.recv_ok.448
  %r2172 = sub nuw nsw i64 %r2161, 8
  %r2173 = inttoptr i64 %r2172 to ptr
  %r2174 = load i8, ptr %r2173, align 1
  %r2175 = icmp eq i8 %r2174, 2
  %r2176 = sub nuw nsw i64 %r2161, 6
  %r2177 = inttoptr i64 %r2176 to ptr
  %r2178 = load i16, ptr %r2177, align 2
  %r2179 = and i16 %r2178, 2048
  %r2180 = icmp eq i16 %r2179, 0
  %r2181 = load ptr, ptr @perry_ic_test_json_template_capture_ts__22, align 8
  %r2182 = icmp ne ptr %r2181, null
  %r2183 = and i1 %r2175, %r2180
  %r2184 = and i1 %r2183, %r2182
  br i1 %r2184, label %pic.token.470, label %pic.desc.classify.460

pic.token.470:                                    ; preds = %pic.recv_hdr.469
  %r2186 = add nuw nsw i64 %r2161, 4
  %r2187 = inttoptr i64 %r2186 to ptr
  %r2188 = load i32, ptr %r2187, align 4
  %r2189 = zext i32 %r2188 to i64
  %r2190 = or i64 %r2189, 4611686018427387904
  %r2191 = icmp ne i32 %r2188, 0
  %r2192 = getelementptr i64, ptr %r2181, i64 0
  %r2193 = load i64, ptr %r2192, align 8
  %r2194 = icmp eq i64 %r2190, %r2193
  %r2195 = and i1 %r2194, %r2191
  br i1 %r2195, label %pic.hit.454, label %pic.prefix.guard.456

pic.hit.overflow.471:                             ; preds = %pic.hit.454
  %r2200 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2201 = bitcast double %r2200 to i64
  %r2202 = and i64 %r2201, 281474976710655
  %r2203 = trunc i64 %r2197 to i32
  %statepoint_token671 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2161, i64 %r2202, i32 %r2203, ptr @perry_ic_test_json_template_capture_ts__22, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111124, ptr addrspace(1) %.39, ptr addrspace(1) %.21174, ptr addrspace(1) %.01177, ptr addrspace(1) %.111140) ]
  %r2204672 = call double @llvm.experimental.gc.result.f64(token %statepoint_token671)
  %r48.1.base.relocated673 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token671, i32 0, i32 0) ; (%.111124, %.111124)
  %rs4gc.s12.relocated674 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token671, i32 1, i32 1) ; (%.39, %.39)
  %rs4gc.s27.relocated675 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token671, i32 2, i32 2) ; (%.21174, %.21174)
  %rs4gc.s32.relocated676 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token671, i32 3, i32 3) ; (%.01177, %.01177)
  %r48.1.relocated677 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token671, i32 0, i32 4) ; (%.111124, %.111140)
  br label %pic.merge.468

pic.hit.inline.472:                               ; preds = %pic.hit.454
  %r2205 = shl i64 %r2197, 3
  %r2206 = add nuw nsw i64 %r2161, 16
  %r2207 = add i64 %r2206, %r2205
  %r2208 = inttoptr i64 %r2207 to ptr
  %r2209 = load double, ptr %r2208, align 8
  %r2210 = bitcast double %r2209 to i64
  %r2211 = icmp eq i64 %r2210, 9222246136947933200
  br i1 %r2211, label %pic.miss.465, label %pic.hit.live.455

pic.ways.473:                                     ; preds = %pic.miss.465
  %r2251 = getelementptr i64, ptr %r2181, i64 4
  %r2252 = load i64, ptr %r2251, align 8
  %r2253 = icmp eq i64 %r2252, %r2190
  %r2254 = getelementptr i64, ptr %r2181, i64 5
  %r2255 = load i64, ptr %r2254, align 8
  %r2256 = select i1 %r2253, i64 %r2255, i64 0
  %r2257 = getelementptr i64, ptr %r2181, i64 6
  %r2258 = load i64, ptr %r2257, align 8
  %r2259 = icmp eq i64 %r2258, %r2190
  %r2260 = getelementptr i64, ptr %r2181, i64 7
  %r2261 = load i64, ptr %r2260, align 8
  %r2262 = select i1 %r2259, i64 %r2261, i64 0
  %r2263 = getelementptr i64, ptr %r2181, i64 8
  %r2264 = load i64, ptr %r2263, align 8
  %r2265 = icmp eq i64 %r2264, %r2190
  %r2266 = getelementptr i64, ptr %r2181, i64 9
  %r2267 = load i64, ptr %r2266, align 8
  %r2268 = select i1 %r2265, i64 %r2267, i64 0
  %r2269 = getelementptr i64, ptr %r2181, i64 10
  %r2270 = load i64, ptr %r2269, align 8
  %r2271 = icmp eq i64 %r2270, %r2190
  %r2272 = getelementptr i64, ptr %r2181, i64 11
  %r2273 = load i64, ptr %r2272, align 8
  %r2274 = select i1 %r2271, i64 %r2273, i64 0
  %r2275 = or i1 %r2253, %r2259
  %r2276 = select i1 %r2253, i64 %r2256, i64 %r2262
  %r2277 = or i1 %r2265, %r2271
  %r2278 = select i1 %r2265, i64 %r2268, i64 %r2274
  %r2279 = or i1 %r2275, %r2277
  %r2280 = select i1 %r2275, i64 %r2276, i64 %r2278
  %r2281 = and i1 %r2191, %r2279
  br i1 %r2281, label %pic.way.load.474, label %pic.miss.call.467

pic.way.load.474:                                 ; preds = %pic.ways.473
  %r2282 = shl i64 %r2280, 3
  %r2283 = add nuw nsw i64 %r2161, 16
  %r2284 = add i64 %r2283, %r2282
  %r2285 = inttoptr i64 %r2284 to ptr
  %r2286 = load double, ptr %r2285, align 8
  %r2287 = bitcast double %r2286 to i64
  %r2288 = icmp eq i64 %r2287, 9222246136947933200
  br i1 %r2288, label %pic.miss.call.467, label %pic.way.live.475

pic.way.live.475:                                 ; preds = %pic.way.load.474
  br label %pic.merge.468

pget.throw_nullish.476:                           ; preds = %pget.recv_bad.449
  %r2297 = zext i1 %r2295 to i32
  %statepoint_token678 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2297, ptr @test_json_template_capture_ts_.str.2.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.477:                       ; preds = %pget.recv_bad.449
  %r2298 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2299 = bitcast double %r2298 to i64
  %r2300 = and i64 %r2299, 281474976710655
  %statepoint_token679 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2160, i64 %r2300, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111124, ptr addrspace(1) %.39, ptr addrspace(1) %.21174, ptr addrspace(1) %.01177, ptr addrspace(1) %.111140) ]
  %r2301680 = call double @llvm.experimental.gc.result.f64(token %statepoint_token679)
  %r48.1.base.relocated681 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token679, i32 0, i32 0) ; (%.111124, %.111124)
  %rs4gc.s12.relocated682 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token679, i32 1, i32 1) ; (%.39, %.39)
  %rs4gc.s27.relocated683 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token679, i32 2, i32 2) ; (%.21174, %.21174)
  %rs4gc.s32.relocated684 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token679, i32 3, i32 3) ; (%.01177, %.01177)
  %r48.1.relocated685 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token679, i32 0, i32 4) ; (%.111124, %.111140)
  br label %pget.recv_merge.451

guarded_add.numeric.478:                          ; preds = %pget.recv_merge.451
  %r2326 = fadd double %r2310, %r2306
  %r2327 = fadd double %r2308, %r2326
  br label %guarded_add.merge.480

guarded_add.dynamic.479:                          ; preds = %pget.recv_merge.451
  %statepoint_token686 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r2310, double %r2306, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.121125, ptr addrspace(1) %.40, ptr addrspace(1) %.121141, ptr addrspace(1) %.31175) ]
  %r2328687 = call double @llvm.experimental.gc.result.f64(token %statepoint_token686)
  %r48.1.base.relocated688 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token686, i32 0, i32 0) ; (%.121125, %.121125)
  %rs4gc.s12.relocated689 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token686, i32 1, i32 1) ; (%.40, %.40)
  %r48.1.relocated690 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token686, i32 0, i32 2) ; (%.121125, %.121141)
  %rs4gc.s27.relocated691 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token686, i32 3, i32 3) ; (%.31175, %.31175)
  %r3578.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27.relocated691 to i64
  %r3578 = call i64 asm "", "=r,0"(i64 %r3578.rs4i) #7
  %r3579 = bitcast i64 %r3578 to double
  %statepoint_token692 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r3579, double %r2328687, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.1.base.relocated688, ptr addrspace(1) %rs4gc.s12.relocated689, ptr addrspace(1) %r48.1.relocated690) ]
  %r2329693 = call double @llvm.experimental.gc.result.f64(token %statepoint_token692)
  %r48.1.base.relocated694 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token692, i32 0, i32 0) ; (%r48.1.base.relocated688, %r48.1.base.relocated688)
  %rs4gc.s12.relocated695 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token692, i32 1, i32 1) ; (%rs4gc.s12.relocated689, %rs4gc.s12.relocated689)
  %r48.1.relocated696 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token692, i32 0, i32 2) ; (%r48.1.base.relocated688, %r48.1.relocated690)
  br label %guarded_add.merge.480

guarded_add.merge.480:                            ; preds = %guarded_add.dynamic.479, %guarded_add.numeric.478
  %.141143 = phi ptr addrspace(1) [ %.121141, %guarded_add.numeric.478 ], [ %r48.1.relocated696, %guarded_add.dynamic.479 ]
  %.141127 = phi ptr addrspace(1) [ %.121125, %guarded_add.numeric.478 ], [ %r48.1.base.relocated694, %guarded_add.dynamic.479 ]
  %.42 = phi ptr addrspace(1) [ %.40, %guarded_add.numeric.478 ], [ %rs4gc.s12.relocated695, %guarded_add.dynamic.479 ]
  %r2330 = phi double [ %r2327, %guarded_add.numeric.478 ], [ %r2329693, %guarded_add.dynamic.479 ]
  %rs4gc.b33 = bitcast double %r2330 to i64
  %rs4gc.s33 = inttoptr i64 %rs4gc.b33 to ptr addrspace(1)
  %r2331.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s33 to i64
  %r2331 = call i64 asm "", "=r,0"(i64 %r2331.rs4i) #7
  %r2332 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2333 = icmp ne i32 %r2332, 0
  br i1 %r2333, label %shadow.root.barrier.481, label %shadow.root.barrier.done.482

shadow.root.barrier.481:                          ; preds = %guarded_add.merge.480
  call void @js_write_barrier_root_nanbox(i64 %r2331) #7
  br label %shadow.root.barrier.done.482

shadow.root.barrier.done.482:                     ; preds = %shadow.root.barrier.481, %guarded_add.merge.480
  %r2334 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r2335 = icmp ne i32 %r2334, 0
  br i1 %r2335, label %gcpoll.483, label %gcpoll.done.484

gcpoll.483:                                       ; preds = %shadow.root.barrier.done.482
  %statepoint_token697 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s33, ptr addrspace(1) %.141127, ptr addrspace(1) %.141143, ptr addrspace(1) %.42) ]
  %rs4gc.s33.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token697, i32 0, i32 0) ; (%rs4gc.s33, %rs4gc.s33)
  %r48.1.base.relocated698 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token697, i32 1, i32 1) ; (%.141127, %.141127)
  %r48.1.relocated699 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token697, i32 1, i32 2) ; (%.141127, %.141143)
  %rs4gc.s12.relocated700 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token697, i32 3, i32 3) ; (%.42, %.42)
  br label %gcpoll.done.484

gcpoll.done.484:                                  ; preds = %gcpoll.483, %shadow.root.barrier.done.482
  %.01180 = phi ptr addrspace(1) [ %rs4gc.s33.relocated, %gcpoll.483 ], [ %rs4gc.s33, %shadow.root.barrier.done.482 ]
  %.151144 = phi ptr addrspace(1) [ %r48.1.relocated699, %gcpoll.483 ], [ %.141143, %shadow.root.barrier.done.482 ]
  %.151128 = phi ptr addrspace(1) [ %r48.1.base.relocated698, %gcpoll.483 ], [ %.141127, %shadow.root.barrier.done.482 ]
  %.43 = phi ptr addrspace(1) [ %rs4gc.s12.relocated700, %gcpoll.483 ], [ %.42, %shadow.root.barrier.done.482 ]
  br label %for.update.17

for.cond.485:                                     ; preds = %for.update.487, %for.exit.18
  %.01014 = phi ptr addrspace(1) [ %r48.0, %for.exit.18 ], [ %.401054, %for.update.487 ]
  %.0973 = phi ptr addrspace(1) [ %r48.0.base, %for.exit.18 ], [ %.401013, %for.update.487 ]
  %.0929 = phi ptr addrspace(1) [ %r57.0, %for.exit.18 ], [ %.51, %for.update.487 ]
  %r2340.0 = phi i32 [ 0, %for.exit.18 ], [ %r3346, %for.update.487 ]
  %r2342 = sitofp i32 %r2340.0 to double
  %r2343.rs4i = ptrtoint ptr addrspace(1) %.01014 to i64
  %r2343.rs4o = call i64 asm "", "=r,0"(i64 %r2343.rs4i) #7
  %r2343 = bitcast i64 %r2343.rs4o to double
  %r2344 = bitcast double %r2343 to i64
  %r2345 = and i64 %r2344, 281474976710655
  %r2346 = lshr i64 %r2344, 48
  %r2347 = and i64 %r2346, 65533
  %r2348 = icmp eq i64 %r2347, 32765
  %r2349 = icmp ugt i64 %r2345, 1048575
  %r2350 = and i1 %r2348, %r2349
  br i1 %r2350, label %plen.check_gc.489, label %plen.slow.491

for.body.486:                                     ; preds = %gcpoll.done.511
  %r2457.rs4i = ptrtoint ptr addrspace(1) %.281042 to i64
  %r2457.rs4o = call i64 asm "", "=r,0"(i64 %r2457.rs4i) #7
  %r2457 = bitcast i64 %r2457.rs4o to double
  %r2459 = bitcast double %r2457 to i64
  %r2460 = and i64 %r2459, 281474976710655
  %r2461 = lshr i64 %r2459, 48
  %r2462 = icmp eq i64 %r2461, 32765
  %r2463 = icmp ugt i64 %r2460, 1048575
  %r2464 = and i1 %r2462, %r2463
  br i1 %r2464, label %arr.guard.deref.516, label %arr.fallback.513

for.update.487:                                   ; preds = %gcpoll.done.677
  %r3346 = add i32 %r2340.0, 1
  %r3347 = sitofp i32 %r2340.0 to double
  %r3348 = sitofp i32 %r3346 to double
  br label %for.cond.485

for.exit.488:                                     ; preds = %gcpoll.done.511
  %statepoint_token701 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.281042, ptr addrspace(1) %.281001, ptr addrspace(1) %.39968) ]
  %r3349702 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token701)
  %r48.0.relocated703 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token701, i32 1, i32 0) ; (%.281001, %.281042)
  %r48.0.base.relocated704 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token701, i32 1, i32 1) ; (%.281001, %.281001)
  %r57.0.relocated705 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token701, i32 2, i32 2) ; (%.39968, %.39968)
  %rs4gc.s34 = inttoptr i64 %r3349702 to ptr addrspace(1)
  %r3350.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s34 to i64
  %r3350 = call i64 asm "", "=r,0"(i64 %r3350.rs4i) #7
  %r3351 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3352 = icmp ne i32 %r3351, 0
  br i1 %r3352, label %shadow.root.barrier.678, label %shadow.root.barrier.done.679

plen.check_gc.489:                                ; preds = %for.cond.485
  %r2351 = sub nuw nsw i64 %r2345, 8
  %r2352 = inttoptr i64 %r2351 to ptr
  %r2353 = load i8, ptr %r2352, align 1
  %r2354 = icmp eq i8 %r2353, 1
  %r2355 = icmp eq i8 %r2353, 3
  %r2356 = or i1 %r2354, %r2355
  %r2357 = sub nuw nsw i64 %r2345, 7
  %r2358 = inttoptr i64 %r2357 to ptr
  %r2359 = load i8, ptr %r2358, align 1
  %r2360 = and i8 %r2359, -128
  %r2361 = icmp eq i8 %r2360, 0
  %r2362 = and i1 %r2356, %r2361
  br i1 %r2362, label %plen.fast.490, label %plen.slow.491

plen.fast.490:                                    ; preds = %plen.check_gc.489
  %r2364 = inttoptr i64 %r2345 to ptr
  %r2365 = select i1 false, ptr @perry_null_guard_zero_test_json_template_capture_ts, ptr %r2364
  %r2366 = load i32, ptr %r2365, align 4
  %r2367 = uitofp i32 %r2366 to double
  br label %plen.merge.492

plen.slow.491:                                    ; preds = %plen.check_gc.489, %for.cond.485
  %r2368 = lshr i64 %r2344, 48
  %r2369 = icmp eq i64 %r2368, 32765
  %r2370 = icmp uge i64 %r2345, 2199023255552
  %r2371 = icmp ult i64 %r2345, 140737488355328
  %r2372 = and i1 %r2369, %r2370
  %r2373 = and i1 %r2372, %r2371
  %r2374 = load ptr, ptr @perry_ic_test_json_template_capture_ts__23, align 8
  br i1 %r2373, label %plen.ic.header.493, label %plen.ic.miss.505

plen.merge.492:                                   ; preds = %plen.ic.merge.506, %plen.fast.490
  %.261040 = phi ptr addrspace(1) [ %.01014, %plen.fast.490 ], [ %.271041, %plen.ic.merge.506 ]
  %.26999 = phi ptr addrspace(1) [ %.0973, %plen.fast.490 ], [ %.271000, %plen.ic.merge.506 ]
  %.37966 = phi ptr addrspace(1) [ %.0929, %plen.fast.490 ], [ %.38967, %plen.ic.merge.506 ]
  %r2449 = phi double [ %r2367, %plen.fast.490 ], [ %r2448, %plen.ic.merge.506 ]
  %r2450 = fcmp olt double %r2342, %r2449
  %r2451 = select i1 %r2450, i64 9222246136947933188, i64 9222246136947933187
  %r2452 = bitcast i64 %r2451 to double
  %r2454 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r2455 = icmp ne i32 %r2454, 0
  br i1 %r2455, label %gcpoll.510, label %gcpoll.done.511

plen.ic.header.493:                               ; preds = %plen.slow.491
  %r2376 = sub nuw nsw i64 %r2345, 8
  %r2377 = inttoptr i64 %r2376 to ptr
  %r2378 = load i8, ptr %r2377, align 1
  %r2379 = icmp eq i8 %r2378, 2
  %r2380 = sub nuw nsw i64 %r2345, 7
  %r2381 = inttoptr i64 %r2380 to ptr
  %r2382 = load i8, ptr %r2381, align 1
  %r2383 = and i8 %r2382, -128
  %r2384 = icmp eq i8 %r2383, 0
  %r2385 = and i1 %r2379, %r2384
  br i1 %r2385, label %plen.elem.meta.507, label %plen.ic.miss.505

plen.ic.shape.494:                                ; preds = %plen.elem.store.508, %plen.elem.meta.507
  %r2375 = icmp ne ptr %r2374, null
  br i1 %r2375, label %plen.ic.shape.probe.495, label %plen.ic.miss.505

plen.ic.shape.probe.495:                          ; preds = %plen.ic.shape.494
  %r2397 = inttoptr i64 %r2345 to ptr
  %r2398 = load i32, ptr %r2397, align 4
  %r2399 = add nuw nsw i64 %r2345, 4
  %r2400 = inttoptr i64 %r2399 to ptr
  %r2401 = load i32, ptr %r2400, align 4
  %r2402 = zext i32 %r2398 to i64
  %r2403 = zext i32 %r2401 to i64
  %r2404 = shl nuw i64 %r2402, 32
  %r2405 = or i64 %r2404, %r2403
  %r2406 = getelementptr i64, ptr %r2374, i64 0
  %r2407 = load i64, ptr %r2406, align 8
  %r2408 = icmp ne i64 %r2407, 0
  br i1 %r2408, label %plen.ic.identity.496, label %plen.ic.miss.505

plen.ic.identity.496:                             ; preds = %plen.ic.shape.probe.495
  %r2409 = and i64 %r2407, -9223372036854775808
  %1 = icmp slt i64 %r2407, 0
  br i1 %1, label %plen.ic.family_meta.498, label %plen.ic.exact.497

plen.ic.exact.497:                                ; preds = %plen.ic.identity.496
  %r2411 = icmp eq i64 %r2405, %r2407
  br i1 %r2411, label %plen.ic.slot.500, label %plen.ic.miss.505

plen.ic.family_meta.498:                          ; preds = %plen.ic.identity.496
  %r2412 = add nuw nsw i64 %r2345, 8
  %r2413 = inttoptr i64 %r2412 to ptr
  %r2414 = load i64, ptr %r2413, align 8
  %r2415 = icmp ne i64 %r2414, 0
  br i1 %r2415, label %plen.ic.family_token.499, label %plen.ic.miss.505

plen.ic.family_token.499:                         ; preds = %plen.ic.family_meta.498
  %r2416 = inttoptr i64 %r2414 to ptr
  %r2417 = getelementptr i64, ptr %r2416, i64 6
  %r2418 = load i64, ptr %r2417, align 8
  %r2419 = icmp eq i64 %r2418, %r2407
  br i1 %r2419, label %plen.ic.slot.500, label %plen.ic.miss.505

plen.ic.slot.500:                                 ; preds = %plen.ic.family_token.499, %plen.ic.exact.497
  %r2420 = getelementptr i64, ptr %r2374, i64 1
  %r2421 = load i64, ptr %r2420, align 8
  %r2422 = getelementptr i64, ptr %r2374, i64 2
  %r2423 = load i64, ptr %r2422, align 8
  %r2424 = icmp ult i64 %r2421, %r2423
  br i1 %r2424, label %plen.ic.inline.501, label %plen.ic.spill_meta.502

plen.ic.inline.501:                               ; preds = %plen.ic.slot.500
  %r2425 = shl i64 %r2421, 3
  %r2426 = add i64 %r2425, 16
  %r2427 = add i64 %r2345, %r2426
  %r2428 = inttoptr i64 %r2427 to ptr
  %r2429 = load double, ptr %r2428, align 8
  br label %plen.ic.merge.506

plen.ic.spill_meta.502:                           ; preds = %plen.ic.slot.500
  %r2430 = add nuw nsw i64 %r2345, 8
  %r2431 = inttoptr i64 %r2430 to ptr
  %r2432 = load i64, ptr %r2431, align 8
  %r2433 = icmp ne i64 %r2432, 0
  br i1 %r2433, label %plen.ic.spill_ptr.503, label %plen.ic.miss.505

plen.ic.spill_ptr.503:                            ; preds = %plen.ic.spill_meta.502
  %r2434 = inttoptr i64 %r2432 to ptr
  %r2435 = getelementptr i64, ptr %r2434, i64 4
  %r2436 = load i64, ptr %r2435, align 8
  %r2437 = icmp ne i64 %r2436, 0
  %r2438 = select i1 %r2437, i64 %r2436, i64 %r2432
  %r2439 = inttoptr i64 %r2438 to ptr
  %r2440 = load i32, ptr %r2439, align 4
  %r2441 = zext i32 %r2440 to i64
  %r2442 = icmp ult i64 %r2421, %r2441
  %r2443 = and i1 %r2437, %r2442
  br i1 %r2443, label %plen.ic.spill_load.504, label %plen.ic.miss.505

plen.ic.spill_load.504:                           ; preds = %plen.ic.spill_ptr.503
  %r2444 = add nuw nsw i64 %r2421, 1
  %r2445 = getelementptr inbounds nuw i64, ptr %r2439, i64 %r2444
  %r2446 = load double, ptr %r2445, align 8
  br label %plen.ic.merge.506

plen.ic.miss.505:                                 ; preds = %plen.ic.spill_ptr.503, %plen.ic.spill_meta.502, %plen.ic.family_token.499, %plen.ic.family_meta.498, %plen.ic.exact.497, %plen.ic.shape.probe.495, %plen.ic.shape.494, %plen.ic.header.493, %plen.slow.491
  %statepoint_token706 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r2343, ptr @perry_ic_test_json_template_capture_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0973, ptr addrspace(1) %.0929, ptr addrspace(1) %.01014) ]
  %r2447707 = call double @llvm.experimental.gc.result.f64(token %statepoint_token706)
  %r48.0.base.relocated708 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token706, i32 0, i32 0) ; (%.0973, %.0973)
  %r57.0.relocated709 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token706, i32 1, i32 1) ; (%.0929, %.0929)
  %r48.0.relocated710 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token706, i32 0, i32 2) ; (%.0973, %.01014)
  br label %plen.ic.merge.506

plen.ic.merge.506:                                ; preds = %plen.elem.length.509, %plen.ic.miss.505, %plen.ic.spill_load.504, %plen.ic.inline.501
  %.271041 = phi ptr addrspace(1) [ %.01014, %plen.elem.length.509 ], [ %.01014, %plen.ic.inline.501 ], [ %.01014, %plen.ic.spill_load.504 ], [ %r48.0.relocated710, %plen.ic.miss.505 ]
  %.271000 = phi ptr addrspace(1) [ %.0973, %plen.elem.length.509 ], [ %.0973, %plen.ic.inline.501 ], [ %.0973, %plen.ic.spill_load.504 ], [ %r48.0.base.relocated708, %plen.ic.miss.505 ]
  %.38967 = phi ptr addrspace(1) [ %.0929, %plen.elem.length.509 ], [ %.0929, %plen.ic.inline.501 ], [ %.0929, %plen.ic.spill_load.504 ], [ %r57.0.relocated709, %plen.ic.miss.505 ]
  %r2448 = phi double [ %r2396, %plen.elem.length.509 ], [ %r2429, %plen.ic.inline.501 ], [ %r2446, %plen.ic.spill_load.504 ], [ %r2447707, %plen.ic.miss.505 ]
  br label %plen.merge.492

plen.elem.meta.507:                               ; preds = %plen.ic.header.493
  %r2386 = add nuw nsw i64 %r2345, 8
  %r2387 = inttoptr i64 %r2386 to ptr
  %r2388 = load i64, ptr %r2387, align 8
  %r2389 = icmp ne i64 %r2388, 0
  br i1 %r2389, label %plen.elem.store.508, label %plen.ic.shape.494

plen.elem.store.508:                              ; preds = %plen.elem.meta.507
  %r2390 = inttoptr i64 %r2388 to ptr
  %r2391 = getelementptr i64, ptr %r2390, i64 12
  %r2392 = load i64, ptr %r2391, align 8
  %r2393 = icmp ne i64 %r2392, 0
  br i1 %r2393, label %plen.elem.length.509, label %plen.ic.shape.494

plen.elem.length.509:                             ; preds = %plen.elem.store.508
  %r2394 = inttoptr i64 %r2392 to ptr
  %r2395 = load i32, ptr %r2394, align 4
  %r2396 = uitofp i32 %r2395 to double
  br label %plen.ic.merge.506

gcpoll.510:                                       ; preds = %plen.merge.492
  %statepoint_token711 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.26999, ptr addrspace(1) %.37966, ptr addrspace(1) %.261040) ]
  %r48.0.base.relocated712 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token711, i32 0, i32 0) ; (%.26999, %.26999)
  %r57.0.relocated713 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token711, i32 1, i32 1) ; (%.37966, %.37966)
  %r48.0.relocated714 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token711, i32 0, i32 2) ; (%.26999, %.261040)
  br label %gcpoll.done.511

gcpoll.done.511:                                  ; preds = %gcpoll.510, %plen.merge.492
  %.281042 = phi ptr addrspace(1) [ %r48.0.relocated714, %gcpoll.510 ], [ %.261040, %plen.merge.492 ]
  %.281001 = phi ptr addrspace(1) [ %r48.0.base.relocated712, %gcpoll.510 ], [ %.26999, %plen.merge.492 ]
  %.39968 = phi ptr addrspace(1) [ %r57.0.relocated713, %gcpoll.510 ], [ %.37966, %plen.merge.492 ]
  %r2453 = icmp eq i64 %r2451, 9222246136947933188
  br i1 %r2453, label %for.body.486, label %for.exit.488

arr.fast.512:                                     ; preds = %arr.guard.range.518
  %r2520 = zext i32 %r2340.0 to i64
  %r2521 = shl nuw nsw i64 %r2520, 3
  %r2522 = add nuw nsw i64 %r2521, 8
  %r2523 = add i64 %r2479, %r2522
  %r2524 = inttoptr i64 %r2523 to ptr
  %r2525 = load double, ptr %r2524, align 8
  %r2526 = bitcast double %r2525 to i64
  %r2527 = icmp eq i64 %r2526, 9222246136947933200
  %r2529 = select i1 %r2527, double 0x7FFC000000000001, double %r2525
  br label %arr.merge.515

arr.fallback.513:                                 ; preds = %arr.guard.live.517, %arr.guard.deref.516, %for.body.486
  %r2518 = sitofp i32 %r2340.0 to double
  %statepoint_token715 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 6060382687846203416, double %r2457, double %r2518, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.281001, ptr addrspace(1) %.39968, ptr addrspace(1) %.281042) ]
  %r2519716 = call double @llvm.experimental.gc.result.f64(token %statepoint_token715)
  %r48.0.base.relocated717 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token715, i32 0, i32 0) ; (%.281001, %.281001)
  %r57.0.relocated718 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token715, i32 1, i32 1) ; (%.39968, %.39968)
  %r48.0.relocated719 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token715, i32 0, i32 2) ; (%.281001, %.281042)
  br label %arr.merge.515

arr.guard.oob.514:                                ; preds = %arr.guard.range.518
  br label %arr.merge.515

arr.merge.515:                                    ; preds = %arr.guard.oob.514, %arr.fallback.513, %arr.fast.512
  %.291043 = phi ptr addrspace(1) [ %.281042, %arr.fast.512 ], [ %.281042, %arr.guard.oob.514 ], [ %r48.0.relocated719, %arr.fallback.513 ]
  %.291002 = phi ptr addrspace(1) [ %.281001, %arr.fast.512 ], [ %.281001, %arr.guard.oob.514 ], [ %r48.0.base.relocated717, %arr.fallback.513 ]
  %.40969 = phi ptr addrspace(1) [ %.39968, %arr.fast.512 ], [ %.39968, %arr.guard.oob.514 ], [ %r57.0.relocated718, %arr.fallback.513 ]
  %r2530 = phi double [ %r2529, %arr.fast.512 ], [ %r2519716, %arr.fallback.513 ], [ 0x7FFC000000000001, %arr.guard.oob.514 ]
  %rs4gc.b35 = bitcast double %r2530 to i64
  %rs4gc.s35 = inttoptr i64 %rs4gc.b35 to ptr addrspace(1)
  %r2531 = bitcast double %r2530 to i64
  %r2532 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2533 = icmp ne i32 %r2532, 0
  br i1 %r2533, label %shadow.root.barrier.519, label %shadow.root.barrier.done.520

arr.guard.deref.516:                              ; preds = %for.body.486
  %r2465 = bitcast double %r2457 to i64
  %r2466 = and i64 %r2465, 281474976710655
  %r2467 = sub nsw i64 %r2466, 8
  %r2468 = inttoptr i64 %r2467 to ptr
  %r2469 = load i8, ptr %r2468, align 1
  %r2470 = icmp eq i8 %r2469, 1
  %r2471 = sub nsw i64 %r2466, 7
  %r2472 = inttoptr i64 %r2471 to ptr
  %r2473 = load i8, ptr %r2472, align 1
  %r2474 = and i8 %r2473, -128
  %r2475 = icmp ne i8 %r2474, 0
  %r2476 = inttoptr i64 %r2466 to ptr
  %r2477 = load i64, ptr %r2476, align 8
  %r2478 = and i1 %r2470, %r2475
  %r2479 = select i1 %r2478, i64 %r2477, i64 %r2466
  %r2480 = lshr i64 %r2479, 48
  %r2481 = icmp eq i64 %r2480, 0
  %r2482 = icmp ugt i64 %r2479, 1048575
  %r2483 = and i1 %r2481, %r2482
  br i1 %r2483, label %arr.guard.live.517, label %arr.fallback.513

arr.guard.live.517:                               ; preds = %arr.guard.deref.516
  %r2484 = sub nuw i64 %r2479, 8
  %r2485 = inttoptr i64 %r2484 to ptr
  %r2486 = load i8, ptr %r2485, align 1
  %r2487 = icmp eq i8 %r2486, 1
  %r2488 = sub nuw i64 %r2479, 7
  %r2489 = inttoptr i64 %r2488 to ptr
  %r2490 = load i8, ptr %r2489, align 1
  %r2491 = and i8 %r2490, -128
  %r2492 = icmp eq i8 %r2491, 0
  %r2493 = sub nuw i64 %r2479, 6
  %r2494 = inttoptr i64 %r2493 to ptr
  %r2495 = load i16, ptr %r2494, align 2
  %r2496 = and i16 %r2495, 1024
  %r2497 = icmp eq i16 %r2496, 0
  %r2498 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2499 = icmp eq i8 %r2498, 0
  %r2500 = inttoptr i64 %r2479 to ptr
  %r2501 = load i32, ptr %r2500, align 4
  %r2502 = getelementptr i8, ptr %r2500, i64 4
  %r2503 = load i32, ptr %r2502, align 4
  %r2504 = icmp slt i32 %r2340.0, 0
  %r2505 = icmp eq i1 %r2504, false
  %r2507 = icmp ule i32 %r2501, 16000000
  %r2508 = icmp ule i32 %r2503, 16000000
  %r2509 = icmp ule i32 %r2501, %r2503
  %r2510 = and i1 %r2487, %r2492
  %r2511 = and i1 %r2510, %r2497
  %r2512 = and i1 %r2511, %r2499
  %r2513 = and i1 %r2512, %r2505
  %r2514 = and i1 %r2513, %r2507
  %r2515 = and i1 %r2514, %r2508
  %r2516 = and i1 %r2515, %r2509
  br i1 %r2516, label %arr.guard.range.518, label %arr.fallback.513

arr.guard.range.518:                              ; preds = %arr.guard.live.517
  %r2506 = icmp ult i32 %r2340.0, %r2501
  br i1 %r2506, label %arr.fast.512, label %arr.guard.oob.514

shadow.root.barrier.519:                          ; preds = %arr.merge.515
  call void @js_write_barrier_root_nanbox(i64 %r2531) #7
  br label %shadow.root.barrier.done.520

shadow.root.barrier.done.520:                     ; preds = %shadow.root.barrier.519, %arr.merge.515
  %r2534.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r2534.rs4o = call i64 asm "", "=r,0"(i64 %r2534.rs4i) #7
  %r2534 = bitcast i64 %r2534.rs4o to double
  %r2538 = bitcast double %r2534 to i64
  %r2539 = and i64 %r2538, 281474976710655
  %r2540 = load double, ptr @test_json_template_capture_ts_.str.0.handle, align 8
  %r2541 = bitcast double %r2540 to i64
  %r2542 = and i64 %r2541, 281474976710655
  %r2543 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r2544 = icmp eq i8 %r2543, 0
  %r2545 = lshr i64 %r2538, 48
  %r2546 = icmp eq i64 %r2545, 32765
  %r2547 = icmp ugt i64 %r2539, 1048575
  %r2548 = and i1 %r2546, %r2547
  %r2549 = and i1 %r2548, %r2544
  br i1 %r2549, label %class_field_inline.deref.524, label %class_field_inline.guardcall.525

class_field_get.fast.521:                         ; preds = %class_field_inline.guardcall.525, %class_field_inline.deref.524
  %r3575.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r3575.rs4o = call i64 asm "", "=r,0"(i64 %r3575.rs4i) #7
  %r3575 = bitcast i64 %r3575.rs4o to double
  %r3576 = bitcast double %r3575 to i64
  %r3577 = and i64 %r3576, 281474976710655
  %r2574 = inttoptr i64 %r3577 to ptr
  %r3571.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r3571.rs4o = call i64 asm "", "=r,0"(i64 %r3571.rs4i) #7
  %r3571 = bitcast i64 %r3571.rs4o to double
  %r3572 = bitcast double %r3571 to i64
  %r3573 = and i64 %r3572, 281474976710655
  %r3574 = inttoptr i64 %r3573 to ptr
  %r2575 = getelementptr i8, ptr %r3574, i64 16
  %r2576 = getelementptr double, ptr %r2575, i64 0
  %r2577 = load double, ptr %r2576, align 8
  br label %class_field_get.merge.523

class_field_get.fallback.522:                     ; preds = %class_field_inline.guardcall.525
  %r3569.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r3569.rs4o = call i64 asm "", "=r,0"(i64 %r3569.rs4i) #7
  %r3569 = bitcast i64 %r3569.rs4o to double
  %r3570 = bitcast double %r3569 to i64
  %r2578 = icmp eq i64 %r3570, 9222246136947933185
  %r3567.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r3567.rs4o = call i64 asm "", "=r,0"(i64 %r3567.rs4i) #7
  %r3567 = bitcast i64 %r3567.rs4o to double
  %r3568 = bitcast double %r3567 to i64
  %r2579 = icmp eq i64 %r3568, 9222246136947933186
  %r2580 = or i1 %r2578, %r2579
  br i1 %r2580, label %class_field_get.throw_nullish.526, label %class_field_get.fallback_lookup.527

class_field_get.merge.523:                        ; preds = %class_field_get.fallback_lookup.527, %class_field_get.fast.521
  %.01181 = phi ptr addrspace(1) [ %rs4gc.s35, %class_field_get.fast.521 ], [ %rs4gc.s35.relocated728, %class_field_get.fallback_lookup.527 ]
  %.301044 = phi ptr addrspace(1) [ %.291043, %class_field_get.fast.521 ], [ %r48.0.relocated731, %class_field_get.fallback_lookup.527 ]
  %.301003 = phi ptr addrspace(1) [ %.291002, %class_field_get.fast.521 ], [ %r48.0.base.relocated729, %class_field_get.fallback_lookup.527 ]
  %.41970 = phi ptr addrspace(1) [ %.40969, %class_field_get.fast.521 ], [ %r57.0.relocated730, %class_field_get.fallback_lookup.527 ]
  %r2583 = phi double [ %r2577, %class_field_get.fast.521 ], [ %r2582727, %class_field_get.fallback_lookup.527 ]
  %statepoint_token720 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r2583, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01181, ptr addrspace(1) %.301003, ptr addrspace(1) %.41970, ptr addrspace(1) %.301044) ]
  %r2584721 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token720)
  %rs4gc.s35.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token720, i32 0, i32 0) ; (%.01181, %.01181)
  %r48.0.base.relocated722 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token720, i32 1, i32 1) ; (%.301003, %.301003)
  %r57.0.relocated723 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token720, i32 2, i32 2) ; (%.41970, %.41970)
  %r48.0.relocated724 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token720, i32 1, i32 3) ; (%.301003, %.301044)
  %r2585 = bitcast i64 %r2584721 to double
  %rs4gc.s36 = inttoptr i64 %r2584721 to ptr addrspace(1)
  %r2586.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s36 to i64
  %r2586 = call i64 asm "", "=r,0"(i64 %r2586.rs4i) #7
  %r2587 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2588 = icmp ne i32 %r2587, 0
  br i1 %r2588, label %shadow.root.barrier.528, label %shadow.root.barrier.done.529

class_field_inline.deref.524:                     ; preds = %shadow.root.barrier.done.520
  %r2550 = inttoptr i64 %r2539 to ptr
  %r2551 = getelementptr i8, ptr %r2550, i64 -8
  %r2552 = load i8, ptr %r2551, align 1
  %r2553 = icmp eq i8 %r2552, 2
  %r2554 = getelementptr i8, ptr %r2550, i64 -7
  %r2555 = load i8, ptr %r2554, align 1
  %r2556 = and i8 %r2555, -128
  %r2557 = icmp eq i8 %r2556, 0
  %r2558 = getelementptr i8, ptr %r2550, i64 -6
  %r2559 = load i16, ptr %r2558, align 2
  %r2560 = getelementptr i8, ptr %r2550, i64 0
  %r2561 = load i32, ptr %r2560, align 4
  %r2562 = icmp eq i32 %r2561, 1
  %r2563 = getelementptr i8, ptr %r2550, i64 4
  %r2564 = load i32, ptr %r2563, align 4
  %r2565 = icmp eq i32 %r2564, %r2536
  %r2566 = and i1 %r2553, %r2557
  %r2567 = and i1 %r2566, %r2562
  %r2568 = and i1 %r2567, %r2565
  %r2569 = and i16 %r2559, 3072
  %r2570 = icmp eq i16 %r2569, 0
  %r2571 = and i1 %r2568, %r2570
  br i1 %r2571, label %class_field_get.fast.521, label %class_field_inline.guardcall.525

class_field_inline.guardcall.525:                 ; preds = %class_field_inline.deref.524, %shadow.root.barrier.done.520
  %r2572 = call i32 @js_typed_feedback_class_field_get_guard(i64 6060382687846203417, double %r2534, i32 1, i32 %r2536, i64 %r2542, i32 0, i32 0) #7
  %r2573 = icmp ne i32 %r2572, 0
  br i1 %r2573, label %class_field_get.fast.521, label %class_field_get.fallback.522

class_field_get.throw_nullish.526:                ; preds = %class_field_get.fallback.522
  %r2581 = zext i1 %r2579 to i32
  %statepoint_token725 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2581, ptr @test_json_template_capture_ts_.str.0.bytes, i64 5, i32 0, i32 0)
  unreachable

class_field_get.fallback_lookup.527:              ; preds = %class_field_get.fallback.522
  %r3562.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r3562.rs4o = call i64 asm "", "=r,0"(i64 %r3562.rs4i) #7
  %r3562 = bitcast i64 %r3562.rs4o to double
  %r3563 = bitcast double %r3562 to i64
  %r3564 = load double, ptr @test_json_template_capture_ts_.str.0.handle, align 8
  %r3565 = bitcast double %r3564 to i64
  %r3566 = and i64 %r3565, 281474976710655
  %statepoint_token726 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3563, i64 %r3566, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35, ptr addrspace(1) %.291002, ptr addrspace(1) %.40969, ptr addrspace(1) %.291043) ]
  %r2582727 = call double @llvm.experimental.gc.result.f64(token %statepoint_token726)
  %rs4gc.s35.relocated728 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token726, i32 0, i32 0) ; (%rs4gc.s35, %rs4gc.s35)
  %r48.0.base.relocated729 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token726, i32 1, i32 1) ; (%.291002, %.291002)
  %r57.0.relocated730 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token726, i32 2, i32 2) ; (%.40969, %.40969)
  %r48.0.relocated731 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token726, i32 1, i32 3) ; (%.291002, %.291043)
  br label %class_field_get.merge.523

shadow.root.barrier.528:                          ; preds = %class_field_get.merge.523
  call void @js_write_barrier_root_nanbox(i64 %r2586) #7
  br label %shadow.root.barrier.done.529

shadow.root.barrier.done.529:                     ; preds = %shadow.root.barrier.528, %class_field_get.merge.523
  %r2589.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated to i64
  %r2589.rs4o = call i64 asm "", "=r,0"(i64 %r2589.rs4i) #7
  %r2589 = bitcast i64 %r2589.rs4o to double
  %r2591 = bitcast double %r2589 to i64
  %r2592 = and i64 %r2591, 281474976710655
  %r2593 = load double, ptr @test_json_template_capture_ts_.str.1.handle, align 8
  %r2594 = bitcast double %r2593 to i64
  %r2595 = and i64 %r2594, 281474976710655
  %r2596 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r2597 = icmp eq i8 %r2596, 0
  %r2598 = lshr i64 %r2591, 48
  %r2599 = icmp eq i64 %r2598, 32765
  %r2600 = icmp ugt i64 %r2592, 1048575
  %r2601 = and i1 %r2599, %r2600
  %r2602 = and i1 %r2601, %r2597
  br i1 %r2602, label %class_field_inline.deref.533, label %class_field_inline.guardcall.534

class_field_get.fast.530:                         ; preds = %class_field_inline.guardcall.534, %class_field_inline.deref.533
  %r3559.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated to i64
  %r3559.rs4o = call i64 asm "", "=r,0"(i64 %r3559.rs4i) #7
  %r3559 = bitcast i64 %r3559.rs4o to double
  %r3560 = bitcast double %r3559 to i64
  %r3561 = and i64 %r3560, 281474976710655
  %r2627 = inttoptr i64 %r3561 to ptr
  %r3555.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated to i64
  %r3555.rs4o = call i64 asm "", "=r,0"(i64 %r3555.rs4i) #7
  %r3555 = bitcast i64 %r3555.rs4o to double
  %r3556 = bitcast double %r3555 to i64
  %r3557 = and i64 %r3556, 281474976710655
  %r3558 = inttoptr i64 %r3557 to ptr
  %r2628 = getelementptr i8, ptr %r3558, i64 16
  %r2629 = getelementptr double, ptr %r2628, i64 1
  %r2630 = load double, ptr %r2629, align 8
  br label %class_field_get.merge.532

class_field_get.fallback.531:                     ; preds = %class_field_inline.guardcall.534
  %r3553.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated to i64
  %r3553.rs4o = call i64 asm "", "=r,0"(i64 %r3553.rs4i) #7
  %r3553 = bitcast i64 %r3553.rs4o to double
  %r3554 = bitcast double %r3553 to i64
  %r2631 = icmp eq i64 %r3554, 9222246136947933185
  %r3551.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated to i64
  %r3551.rs4o = call i64 asm "", "=r,0"(i64 %r3551.rs4i) #7
  %r3551 = bitcast i64 %r3551.rs4o to double
  %r3552 = bitcast double %r3551 to i64
  %r2632 = icmp eq i64 %r3552, 9222246136947933186
  %r2633 = or i1 %r2631, %r2632
  br i1 %r2633, label %class_field_get.throw_nullish.535, label %class_field_get.fallback_lookup.536

class_field_get.merge.532:                        ; preds = %class_field_get.fallback_lookup.536, %class_field_get.fast.530
  %.01187 = phi ptr addrspace(1) [ %rs4gc.s36, %class_field_get.fast.530 ], [ %rs4gc.s36.relocated, %class_field_get.fallback_lookup.536 ]
  %.11182 = phi ptr addrspace(1) [ %rs4gc.s35.relocated, %class_field_get.fast.530 ], [ %rs4gc.s35.relocated735, %class_field_get.fallback_lookup.536 ]
  %.311045 = phi ptr addrspace(1) [ %r48.0.relocated724, %class_field_get.fast.530 ], [ %r48.0.relocated738, %class_field_get.fallback_lookup.536 ]
  %.311004 = phi ptr addrspace(1) [ %r48.0.base.relocated722, %class_field_get.fast.530 ], [ %r48.0.base.relocated736, %class_field_get.fallback_lookup.536 ]
  %.42971 = phi ptr addrspace(1) [ %r57.0.relocated723, %class_field_get.fast.530 ], [ %r57.0.relocated737, %class_field_get.fallback_lookup.536 ]
  %r2636 = phi double [ %r2630, %class_field_get.fast.530 ], [ %r2635734, %class_field_get.fallback_lookup.536 ]
  %r2637.rs4i = ptrtoint ptr addrspace(1) %.01187 to i64
  %r2637 = call i64 asm "", "=r,0"(i64 %r2637.rs4i) #7
  %r2638 = bitcast i64 %r2637 to double
  %r2639 = bitcast double %r2636 to i64
  %r2640 = and i64 %r2637, 9221120237041090560
  %r2641 = icmp ne i64 %r2640, 9221120237041090560
  %r2642 = and i64 %r2639, 9221120237041090560
  %r2643 = icmp ne i64 %r2642, 9221120237041090560
  %r2644 = and i1 %r2641, %r2643
  br i1 %r2644, label %dyncmp.num.537, label %dyncmp.slow.538

class_field_inline.deref.533:                     ; preds = %shadow.root.barrier.done.529
  %r2603 = inttoptr i64 %r2592 to ptr
  %r2604 = getelementptr i8, ptr %r2603, i64 -8
  %r2605 = load i8, ptr %r2604, align 1
  %r2606 = icmp eq i8 %r2605, 2
  %r2607 = getelementptr i8, ptr %r2603, i64 -7
  %r2608 = load i8, ptr %r2607, align 1
  %r2609 = and i8 %r2608, -128
  %r2610 = icmp eq i8 %r2609, 0
  %r2611 = getelementptr i8, ptr %r2603, i64 -6
  %r2612 = load i16, ptr %r2611, align 2
  %r2613 = getelementptr i8, ptr %r2603, i64 0
  %r2614 = load i32, ptr %r2613, align 4
  %r2615 = icmp eq i32 %r2614, 1
  %r2616 = getelementptr i8, ptr %r2603, i64 4
  %r2617 = load i32, ptr %r2616, align 4
  %r2618 = icmp eq i32 %r2617, %r2536
  %r2619 = and i1 %r2606, %r2610
  %r2620 = and i1 %r2619, %r2615
  %r2621 = and i1 %r2620, %r2618
  %r2622 = and i16 %r2612, 3072
  %r2623 = icmp eq i16 %r2622, 0
  %r2624 = and i1 %r2621, %r2623
  br i1 %r2624, label %class_field_get.fast.530, label %class_field_inline.guardcall.534

class_field_inline.guardcall.534:                 ; preds = %class_field_inline.deref.533, %shadow.root.barrier.done.529
  %r2625 = call i32 @js_typed_feedback_class_field_get_guard(i64 6060382687846203418, double %r2589, i32 1, i32 %r2536, i64 %r2595, i32 1, i32 0) #7
  %r2626 = icmp ne i32 %r2625, 0
  br i1 %r2626, label %class_field_get.fast.530, label %class_field_get.fallback.531

class_field_get.throw_nullish.535:                ; preds = %class_field_get.fallback.531
  %r2634 = zext i1 %r2632 to i32
  %statepoint_token732 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2634, ptr @test_json_template_capture_ts_.str.1.bytes, i64 8, i32 0, i32 0)
  unreachable

class_field_get.fallback_lookup.536:              ; preds = %class_field_get.fallback.531
  %r3546.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated to i64
  %r3546.rs4o = call i64 asm "", "=r,0"(i64 %r3546.rs4i) #7
  %r3546 = bitcast i64 %r3546.rs4o to double
  %r3547 = bitcast double %r3546 to i64
  %r3548 = load double, ptr @test_json_template_capture_ts_.str.1.handle, align 8
  %r3549 = bitcast double %r3548 to i64
  %r3550 = and i64 %r3549, 281474976710655
  %statepoint_token733 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3547, i64 %r3550, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated, ptr addrspace(1) %r48.0.base.relocated722, ptr addrspace(1) %r57.0.relocated723, ptr addrspace(1) %rs4gc.s36, ptr addrspace(1) %r48.0.relocated724) ]
  %r2635734 = call double @llvm.experimental.gc.result.f64(token %statepoint_token733)
  %rs4gc.s35.relocated735 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token733, i32 0, i32 0) ; (%rs4gc.s35.relocated, %rs4gc.s35.relocated)
  %r48.0.base.relocated736 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token733, i32 1, i32 1) ; (%r48.0.base.relocated722, %r48.0.base.relocated722)
  %r57.0.relocated737 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token733, i32 2, i32 2) ; (%r57.0.relocated723, %r57.0.relocated723)
  %rs4gc.s36.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token733, i32 3, i32 3) ; (%rs4gc.s36, %rs4gc.s36)
  %r48.0.relocated738 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token733, i32 1, i32 4) ; (%r48.0.base.relocated722, %r48.0.relocated724)
  br label %class_field_get.merge.532

dyncmp.num.537:                                   ; preds = %class_field_get.merge.532
  %r2645 = fcmp oeq double %r2638, %r2636
  %r2646 = select i1 %r2645, i64 9222246136947933188, i64 9222246136947933187
  br label %dyncmp.merge.539

dyncmp.slow.538:                                  ; preds = %class_field_get.merge.532
  %statepoint_token739 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_eq, i32 2, i32 0, i64 %r2637, i64 %r2639, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11182, ptr addrspace(1) %.311004, ptr addrspace(1) %.42971, ptr addrspace(1) %.311045) ]
  %r2647740 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token739)
  %rs4gc.s35.relocated741 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token739, i32 0, i32 0) ; (%.11182, %.11182)
  %r48.0.base.relocated742 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token739, i32 1, i32 1) ; (%.311004, %.311004)
  %r57.0.relocated743 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token739, i32 2, i32 2) ; (%.42971, %.42971)
  %r48.0.relocated744 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token739, i32 1, i32 3) ; (%.311004, %.311045)
  br label %dyncmp.merge.539

dyncmp.merge.539:                                 ; preds = %dyncmp.slow.538, %dyncmp.num.537
  %.21183 = phi ptr addrspace(1) [ %.11182, %dyncmp.num.537 ], [ %rs4gc.s35.relocated741, %dyncmp.slow.538 ]
  %.321046 = phi ptr addrspace(1) [ %.311045, %dyncmp.num.537 ], [ %r48.0.relocated744, %dyncmp.slow.538 ]
  %.321005 = phi ptr addrspace(1) [ %.311004, %dyncmp.num.537 ], [ %r48.0.base.relocated742, %dyncmp.slow.538 ]
  %.43972 = phi ptr addrspace(1) [ %.42971, %dyncmp.num.537 ], [ %r57.0.relocated743, %dyncmp.slow.538 ]
  %r2648 = phi i64 [ %r2646, %dyncmp.num.537 ], [ %r2647740, %dyncmp.slow.538 ]
  %r2649 = icmp eq i64 %r2648, 9222246136947933188
  %r2650 = xor i1 %r2649, true
  %r2651 = select i1 %r2650, i64 9222246136947933188, i64 9222246136947933187
  %r2652 = bitcast i64 %r2651 to double
  %r2653 = icmp eq i64 %r2651, 9222246136947933188
  br i1 %r2653, label %if.then.540, label %if.else.541

if.then.540:                                      ; preds = %dyncmp.merge.539
  %r2654 = load double, ptr @test_json_template_capture_ts_.str.16.handle, align 8
  %statepoint_token745 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r2654, i32 0, i32 0)
  %r2655746 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token745)
  %r2656 = or i64 %r2655746, 9222527611924643840
  %r2657 = bitcast i64 %r2656 to double
  %statepoint_token747 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r2657, i32 0, i32 0)
  unreachable

if.else.541:                                      ; preds = %dyncmp.merge.539
  br label %if.merge.542

if.merge.542:                                     ; preds = %if.else.541
  %statepoint_token748 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 4, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21183, ptr addrspace(1) %.321005, ptr addrspace(1) %.43972, ptr addrspace(1) %.321046) ]
  %r2658749 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token748)
  %rs4gc.s35.relocated750 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token748, i32 0, i32 0) ; (%.21183, %.21183)
  %r48.0.base.relocated751 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token748, i32 1, i32 1) ; (%.321005, %.321005)
  %r57.0.relocated752 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token748, i32 2, i32 2) ; (%.43972, %.43972)
  %r48.0.relocated753 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token748, i32 1, i32 3) ; (%.321005, %.321046)
  %rs4gc.s37 = inttoptr i64 %r2658749 to ptr addrspace(1)
  %r2659.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s37 to i64
  %r2659 = call i64 asm "", "=r,0"(i64 %r2659.rs4i) #7
  %r2660 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2661 = icmp ne i32 %r2660, 0
  br i1 %r2661, label %shadow.root.barrier.543, label %shadow.root.barrier.done.544

shadow.root.barrier.543:                          ; preds = %if.merge.542
  call void @js_write_barrier_root_nanbox(i64 %r2659) #7
  br label %shadow.root.barrier.done.544

shadow.root.barrier.done.544:                     ; preds = %shadow.root.barrier.543, %if.merge.542
  %r2662 = load double, ptr @test_json_template_capture_ts_.str.17.handle, align 8
  %r2663.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s37 to i64
  %r2663 = call i64 asm "", "=r,0"(i64 %r2663.rs4i) #7
  %statepoint_token754 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r2663, double %r2662, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated750, ptr addrspace(1) %r48.0.base.relocated751, ptr addrspace(1) %r57.0.relocated752, ptr addrspace(1) %r48.0.relocated753) ]
  %r2664755 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token754)
  %rs4gc.s35.relocated756 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token754, i32 0, i32 0) ; (%rs4gc.s35.relocated750, %rs4gc.s35.relocated750)
  %r48.0.base.relocated757 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token754, i32 1, i32 1) ; (%r48.0.base.relocated751, %r48.0.base.relocated751)
  %r57.0.relocated758 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token754, i32 2, i32 2) ; (%r57.0.relocated752, %r57.0.relocated752)
  %r48.0.relocated759 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token754, i32 1, i32 3) ; (%r48.0.base.relocated751, %r48.0.relocated753)
  %rs4gc.s38 = inttoptr i64 %r2664755 to ptr addrspace(1)
  %r2665.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s38 to i64
  %r2665 = call i64 asm "", "=r,0"(i64 %r2665.rs4i) #7
  %r2666 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2667 = icmp ne i32 %r2666, 0
  br i1 %r2667, label %shadow.root.barrier.545, label %shadow.root.barrier.done.546

shadow.root.barrier.545:                          ; preds = %shadow.root.barrier.done.544
  call void @js_write_barrier_root_nanbox(i64 %r2665) #7
  br label %shadow.root.barrier.done.546

shadow.root.barrier.done.546:                     ; preds = %shadow.root.barrier.545, %shadow.root.barrier.done.544
  %r2669 = sitofp i32 %r2340.0 to double
  %r2670.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s38 to i64
  %r2670 = call i64 asm "", "=r,0"(i64 %r2670.rs4i) #7
  %statepoint_token760 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r2670, double %r2669, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated756, ptr addrspace(1) %r48.0.base.relocated757, ptr addrspace(1) %r57.0.relocated758, ptr addrspace(1) %r48.0.relocated759) ]
  %r2671761 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token760)
  %rs4gc.s35.relocated762 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token760, i32 0, i32 0) ; (%rs4gc.s35.relocated756, %rs4gc.s35.relocated756)
  %r48.0.base.relocated763 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token760, i32 1, i32 1) ; (%r48.0.base.relocated757, %r48.0.base.relocated757)
  %r57.0.relocated764 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token760, i32 2, i32 2) ; (%r57.0.relocated758, %r57.0.relocated758)
  %r48.0.relocated765 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token760, i32 1, i32 3) ; (%r48.0.base.relocated757, %r48.0.relocated759)
  %rs4gc.s39 = inttoptr i64 %r2671761 to ptr addrspace(1)
  %r2672.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s39 to i64
  %r2672 = call i64 asm "", "=r,0"(i64 %r2672.rs4i) #7
  %r2673 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2674 = icmp ne i32 %r2673, 0
  br i1 %r2674, label %shadow.root.barrier.547, label %shadow.root.barrier.done.548

shadow.root.barrier.547:                          ; preds = %shadow.root.barrier.done.546
  call void @js_write_barrier_root_nanbox(i64 %r2672) #7
  br label %shadow.root.barrier.done.548

shadow.root.barrier.done.548:                     ; preds = %shadow.root.barrier.547, %shadow.root.barrier.done.546
  %r2675.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated762 to i64
  %r2675.rs4o = call i64 asm "", "=r,0"(i64 %r2675.rs4i) #7
  %r2675 = bitcast i64 %r2675.rs4o to double
  %r2677 = bitcast double %r2675 to i64
  %r2678 = and i64 %r2677, 281474976710655
  %r2679 = load double, ptr @test_json_template_capture_ts_.str.0.handle, align 8
  %r2680 = bitcast double %r2679 to i64
  %r2681 = and i64 %r2680, 281474976710655
  %r2682 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r2683 = icmp eq i8 %r2682, 0
  %r2684 = lshr i64 %r2677, 48
  %r2685 = icmp eq i64 %r2684, 32765
  %r2686 = icmp ugt i64 %r2678, 1048575
  %r2687 = and i1 %r2685, %r2686
  %r2688 = and i1 %r2687, %r2683
  br i1 %r2688, label %class_field_inline.deref.552, label %class_field_inline.guardcall.553

class_field_get.fast.549:                         ; preds = %class_field_inline.guardcall.553, %class_field_inline.deref.552
  %r3543.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated762 to i64
  %r3543.rs4o = call i64 asm "", "=r,0"(i64 %r3543.rs4i) #7
  %r3543 = bitcast i64 %r3543.rs4o to double
  %r3544 = bitcast double %r3543 to i64
  %r3545 = and i64 %r3544, 281474976710655
  %r2713 = inttoptr i64 %r3545 to ptr
  %r3539.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated762 to i64
  %r3539.rs4o = call i64 asm "", "=r,0"(i64 %r3539.rs4i) #7
  %r3539 = bitcast i64 %r3539.rs4o to double
  %r3540 = bitcast double %r3539 to i64
  %r3541 = and i64 %r3540, 281474976710655
  %r3542 = inttoptr i64 %r3541 to ptr
  %r2714 = getelementptr i8, ptr %r3542, i64 16
  %r2715 = getelementptr double, ptr %r2714, i64 0
  %r2716 = load double, ptr %r2715, align 8
  br label %class_field_get.merge.551

class_field_get.fallback.550:                     ; preds = %class_field_inline.guardcall.553
  %r3537.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated762 to i64
  %r3537.rs4o = call i64 asm "", "=r,0"(i64 %r3537.rs4i) #7
  %r3537 = bitcast i64 %r3537.rs4o to double
  %r3538 = bitcast double %r3537 to i64
  %r2717 = icmp eq i64 %r3538, 9222246136947933185
  %r3535.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated762 to i64
  %r3535.rs4o = call i64 asm "", "=r,0"(i64 %r3535.rs4i) #7
  %r3535 = bitcast i64 %r3535.rs4o to double
  %r3536 = bitcast double %r3535 to i64
  %r2718 = icmp eq i64 %r3536, 9222246136947933186
  %r2719 = or i1 %r2717, %r2718
  br i1 %r2719, label %class_field_get.throw_nullish.554, label %class_field_get.fallback_lookup.555

class_field_get.merge.551:                        ; preds = %class_field_get.fallback_lookup.555, %class_field_get.fast.549
  %.01188 = phi ptr addrspace(1) [ %rs4gc.s39, %class_field_get.fast.549 ], [ %rs4gc.s39.relocated, %class_field_get.fallback_lookup.555 ]
  %.31184 = phi ptr addrspace(1) [ %rs4gc.s35.relocated762, %class_field_get.fast.549 ], [ %rs4gc.s35.relocated769, %class_field_get.fallback_lookup.555 ]
  %.331047 = phi ptr addrspace(1) [ %r48.0.relocated765, %class_field_get.fast.549 ], [ %r48.0.relocated772, %class_field_get.fallback_lookup.555 ]
  %.331006 = phi ptr addrspace(1) [ %r48.0.base.relocated763, %class_field_get.fast.549 ], [ %r48.0.base.relocated770, %class_field_get.fallback_lookup.555 ]
  %.44 = phi ptr addrspace(1) [ %r57.0.relocated764, %class_field_get.fast.549 ], [ %r57.0.relocated771, %class_field_get.fallback_lookup.555 ]
  %r2722 = phi double [ %r2716, %class_field_get.fast.549 ], [ %r2721768, %class_field_get.fallback_lookup.555 ]
  %r2723 = bitcast double %r2722 to i64
  %r2724 = and i64 %r2723, 281474976710655
  %r2725 = lshr i64 %r2723, 48
  %r2726 = and i64 %r2725, 65533
  %r2727 = icmp eq i64 %r2726, 32765
  br i1 %r2727, label %pget.recv_ok.557, label %pget.recv_other.561

class_field_inline.deref.552:                     ; preds = %shadow.root.barrier.done.548
  %r2689 = inttoptr i64 %r2678 to ptr
  %r2690 = getelementptr i8, ptr %r2689, i64 -8
  %r2691 = load i8, ptr %r2690, align 1
  %r2692 = icmp eq i8 %r2691, 2
  %r2693 = getelementptr i8, ptr %r2689, i64 -7
  %r2694 = load i8, ptr %r2693, align 1
  %r2695 = and i8 %r2694, -128
  %r2696 = icmp eq i8 %r2695, 0
  %r2697 = getelementptr i8, ptr %r2689, i64 -6
  %r2698 = load i16, ptr %r2697, align 2
  %r2699 = getelementptr i8, ptr %r2689, i64 0
  %r2700 = load i32, ptr %r2699, align 4
  %r2701 = icmp eq i32 %r2700, 1
  %r2702 = getelementptr i8, ptr %r2689, i64 4
  %r2703 = load i32, ptr %r2702, align 4
  %r2704 = icmp eq i32 %r2703, %r2536
  %r2705 = and i1 %r2692, %r2696
  %r2706 = and i1 %r2705, %r2701
  %r2707 = and i1 %r2706, %r2704
  %r2708 = and i16 %r2698, 3072
  %r2709 = icmp eq i16 %r2708, 0
  %r2710 = and i1 %r2707, %r2709
  br i1 %r2710, label %class_field_get.fast.549, label %class_field_inline.guardcall.553

class_field_inline.guardcall.553:                 ; preds = %class_field_inline.deref.552, %shadow.root.barrier.done.548
  %r2711 = call i32 @js_typed_feedback_class_field_get_guard(i64 6060382687846203419, double %r2675, i32 1, i32 %r2536, i64 %r2681, i32 0, i32 0) #7
  %r2712 = icmp ne i32 %r2711, 0
  br i1 %r2712, label %class_field_get.fast.549, label %class_field_get.fallback.550

class_field_get.throw_nullish.554:                ; preds = %class_field_get.fallback.550
  %r2720 = zext i1 %r2718 to i32
  %statepoint_token766 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2720, ptr @test_json_template_capture_ts_.str.0.bytes, i64 5, i32 0, i32 0)
  unreachable

class_field_get.fallback_lookup.555:              ; preds = %class_field_get.fallback.550
  %r3530.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated762 to i64
  %r3530.rs4o = call i64 asm "", "=r,0"(i64 %r3530.rs4i) #7
  %r3530 = bitcast i64 %r3530.rs4o to double
  %r3531 = bitcast double %r3530 to i64
  %r3532 = load double, ptr @test_json_template_capture_ts_.str.0.handle, align 8
  %r3533 = bitcast double %r3532 to i64
  %r3534 = and i64 %r3533, 281474976710655
  %statepoint_token767 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3531, i64 %r3534, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35.relocated762, ptr addrspace(1) %rs4gc.s39, ptr addrspace(1) %r48.0.base.relocated763, ptr addrspace(1) %r57.0.relocated764, ptr addrspace(1) %r48.0.relocated765) ]
  %r2721768 = call double @llvm.experimental.gc.result.f64(token %statepoint_token767)
  %rs4gc.s35.relocated769 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token767, i32 0, i32 0) ; (%rs4gc.s35.relocated762, %rs4gc.s35.relocated762)
  %rs4gc.s39.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token767, i32 1, i32 1) ; (%rs4gc.s39, %rs4gc.s39)
  %r48.0.base.relocated770 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token767, i32 2, i32 2) ; (%r48.0.base.relocated763, %r48.0.base.relocated763)
  %r57.0.relocated771 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token767, i32 3, i32 3) ; (%r57.0.relocated764, %r57.0.relocated764)
  %r48.0.relocated772 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token767, i32 2, i32 4) ; (%r48.0.base.relocated763, %r48.0.relocated765)
  br label %class_field_get.merge.551

pget.recv_sso.556:                                ; preds = %pget.recv_other.561
  %r2865 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2866 = bitcast double %r2865 to i64
  %r2867 = and i64 %r2866, 281474976710655
  %statepoint_token773 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2723, i64 %r2867, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31184, ptr addrspace(1) %.331006, ptr addrspace(1) %.44, ptr addrspace(1) %.01188, ptr addrspace(1) %.331047) ]
  %r2868774 = call double @llvm.experimental.gc.result.f64(token %statepoint_token773)
  %rs4gc.s35.relocated775 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token773, i32 0, i32 0) ; (%.31184, %.31184)
  %r48.0.base.relocated776 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token773, i32 1, i32 1) ; (%.331006, %.331006)
  %r57.0.relocated777 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token773, i32 2, i32 2) ; (%.44, %.44)
  %rs4gc.s39.relocated778 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token773, i32 3, i32 3) ; (%.01188, %.01188)
  %r48.0.relocated779 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token773, i32 1, i32 4) ; (%.331006, %.331047)
  br label %pget.recv_merge.560

pget.recv_ok.557:                                 ; preds = %class_field_get.merge.551
  %r2734 = icmp ugt i64 %r2724, 1048575
  br i1 %r2734, label %pic.recv_hdr.578, label %pic.miss.cold.575

pget.recv_bad.558:                                ; preds = %pget.check_class_ref.562
  %r2857 = icmp eq i64 %r2723, 9222246136947933185
  %r2858 = icmp eq i64 %r2723, 9222246136947933186
  %r2859 = or i1 %r2857, %r2858
  br i1 %r2859, label %pget.throw_nullish.585, label %pget.recv_undef_return.586

pget.recv_class_ref.559:                          ; preds = %pget.check_class_ref.562
  %r2730 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2731 = bitcast double %r2730 to i64
  %r2732 = and i64 %r2731, 281474976710655
  %statepoint_token780 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6060382687846203420, i64 %r2723, i64 %r2732, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31184, ptr addrspace(1) %.331006, ptr addrspace(1) %.44, ptr addrspace(1) %.01188, ptr addrspace(1) %.331047) ]
  %r2733781 = call double @llvm.experimental.gc.result.f64(token %statepoint_token780)
  %rs4gc.s35.relocated782 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token780, i32 0, i32 0) ; (%.31184, %.31184)
  %r48.0.base.relocated783 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token780, i32 1, i32 1) ; (%.331006, %.331006)
  %r57.0.relocated784 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token780, i32 2, i32 2) ; (%.44, %.44)
  %rs4gc.s39.relocated785 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token780, i32 3, i32 3) ; (%.01188, %.01188)
  %r48.0.relocated786 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token780, i32 1, i32 4) ; (%.331006, %.331047)
  br label %pget.recv_merge.560

pget.recv_merge.560:                              ; preds = %pget.recv_undef_return.586, %pic.merge.577, %pget.recv_class_ref.559, %pget.recv_sso.556
  %.11189 = phi ptr addrspace(1) [ %.21190, %pic.merge.577 ], [ %rs4gc.s39.relocated778, %pget.recv_sso.556 ], [ %rs4gc.s39.relocated785, %pget.recv_class_ref.559 ], [ %rs4gc.s39.relocated813, %pget.recv_undef_return.586 ]
  %.41185 = phi ptr addrspace(1) [ %.51186, %pic.merge.577 ], [ %rs4gc.s35.relocated775, %pget.recv_sso.556 ], [ %rs4gc.s35.relocated782, %pget.recv_class_ref.559 ], [ %rs4gc.s35.relocated810, %pget.recv_undef_return.586 ]
  %.341048 = phi ptr addrspace(1) [ %.351049, %pic.merge.577 ], [ %r48.0.relocated779, %pget.recv_sso.556 ], [ %r48.0.relocated786, %pget.recv_class_ref.559 ], [ %r48.0.relocated814, %pget.recv_undef_return.586 ]
  %.341007 = phi ptr addrspace(1) [ %.351008, %pic.merge.577 ], [ %r48.0.base.relocated776, %pget.recv_sso.556 ], [ %r48.0.base.relocated783, %pget.recv_class_ref.559 ], [ %r48.0.base.relocated811, %pget.recv_undef_return.586 ]
  %.45 = phi ptr addrspace(1) [ %.46, %pic.merge.577 ], [ %r57.0.relocated777, %pget.recv_sso.556 ], [ %r57.0.relocated784, %pget.recv_class_ref.559 ], [ %r57.0.relocated812, %pget.recv_undef_return.586 ]
  %r2869 = phi double [ %r2856, %pic.merge.577 ], [ %r2864809, %pget.recv_undef_return.586 ], [ %r2868774, %pget.recv_sso.556 ], [ %r2733781, %pget.recv_class_ref.559 ]
  %r2870.rs4i = ptrtoint ptr addrspace(1) %.11189 to i64
  %r2870 = call i64 asm "", "=r,0"(i64 %r2870.rs4i) #7
  %statepoint_token787 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r2870, double %r2869, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.341007, ptr addrspace(1) %.45, ptr addrspace(1) %.41185, ptr addrspace(1) %.341048) ]
  %r2871788 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token787)
  %r48.0.base.relocated789 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token787, i32 0, i32 0) ; (%.341007, %.341007)
  %r57.0.relocated790 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token787, i32 1, i32 1) ; (%.45, %.45)
  %rs4gc.s35.relocated791 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token787, i32 2, i32 2) ; (%.41185, %.41185)
  %r48.0.relocated792 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token787, i32 0, i32 3) ; (%.341007, %.341048)
  %rs4gc.s40 = inttoptr i64 %r2871788 to ptr addrspace(1)
  %r2872.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s40 to i64
  %r2872 = call i64 asm "", "=r,0"(i64 %r2872.rs4i) #7
  %r2873 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2874 = icmp ne i32 %r2873, 0
  br i1 %r2874, label %shadow.root.barrier.587, label %shadow.root.barrier.done.588

pget.recv_other.561:                              ; preds = %class_field_get.merge.551
  %r2728 = icmp eq i64 %r2725, 32761
  br i1 %r2728, label %pget.recv_sso.556, label %pget.check_class_ref.562

pget.check_class_ref.562:                         ; preds = %pget.recv_other.561
  %r2729 = icmp eq i64 %r2725, 32766
  br i1 %r2729, label %pget.recv_class_ref.559, label %pget.recv_bad.558

pic.hit.563:                                      ; preds = %pic.token.579
  %r2759 = getelementptr i64, ptr %r2744, i64 1
  %r2760 = load i64, ptr %r2759, align 8
  %r2761 = and i64 %r2760, 1073741824
  %r2762 = icmp ne i64 %r2761, 0
  br i1 %r2762, label %pic.hit.overflow.580, label %pic.hit.inline.581

pic.hit.live.564:                                 ; preds = %pic.hit.inline.581
  br label %pic.merge.577

pic.prefix.guard.565:                             ; preds = %pic.token.579
  %r2775 = getelementptr i64, ptr %r2744, i64 2
  %r2776 = load i64, ptr %r2775, align 8
  %r2777 = icmp ne i64 %r2776, 0
  br i1 %r2777, label %pic.prefix.meta.566, label %pic.miss.574

pic.prefix.meta.566:                              ; preds = %pic.prefix.guard.565
  %r2778 = add nuw nsw i64 %r2724, 8
  %r2779 = inttoptr i64 %r2778 to ptr
  %r2780 = load i64, ptr %r2779, align 8
  %r2781 = icmp ne i64 %r2780, 0
  br i1 %r2781, label %pic.prefix.token.567, label %pic.miss.574

pic.prefix.token.567:                             ; preds = %pic.prefix.meta.566
  %r2782 = inttoptr i64 %r2780 to ptr
  %r2783 = getelementptr i64, ptr %r2782, i64 6
  %r2784 = load i64, ptr %r2783, align 8
  %r2785 = icmp eq i64 %r2784, %r2776
  br i1 %r2785, label %pic.prefix.hit.568, label %pic.miss.574

pic.prefix.hit.568:                               ; preds = %pic.prefix.token.567
  %r2786 = getelementptr i64, ptr %r2744, i64 1
  %r2787 = load i64, ptr %r2786, align 8
  %r2788 = shl i64 %r2787, 3
  %r2789 = add nuw nsw i64 %r2724, 16
  %r2790 = add i64 %r2789, %r2788
  %r2791 = inttoptr i64 %r2790 to ptr
  %r2792 = load double, ptr %r2791, align 8
  br label %pic.merge.577

pic.desc.classify.569:                            ; preds = %pic.recv_hdr.578
  %r2748 = and i1 %r2738, %r2745
  br i1 %r2748, label %pic.desc.prefix.guard.570, label %pic.miss.cold.575

pic.desc.prefix.guard.570:                        ; preds = %pic.desc.classify.569
  %r2793 = getelementptr i64, ptr %r2744, i64 2
  %r2794 = load i64, ptr %r2793, align 8
  %r2795 = icmp ne i64 %r2794, 0
  br i1 %r2795, label %pic.desc.prefix.meta.571, label %pic.miss.cold.575

pic.desc.prefix.meta.571:                         ; preds = %pic.desc.prefix.guard.570
  %r2796 = add nuw nsw i64 %r2724, 8
  %r2797 = inttoptr i64 %r2796 to ptr
  %r2798 = load i64, ptr %r2797, align 8
  %r2799 = icmp ne i64 %r2798, 0
  br i1 %r2799, label %pic.desc.prefix.token.572, label %pic.miss.cold.575

pic.desc.prefix.token.572:                        ; preds = %pic.desc.prefix.meta.571
  %r2800 = inttoptr i64 %r2798 to ptr
  %r2801 = getelementptr i64, ptr %r2800, i64 6
  %r2802 = load i64, ptr %r2801, align 8
  %r2803 = icmp eq i64 %r2802, %r2794
  br i1 %r2803, label %pic.desc.prefix.hit.573, label %pic.miss.cold.575

pic.desc.prefix.hit.573:                          ; preds = %pic.desc.prefix.token.572
  %r2804 = getelementptr i64, ptr %r2744, i64 1
  %r2805 = load i64, ptr %r2804, align 8
  %r2806 = shl i64 %r2805, 3
  %r2807 = add nuw nsw i64 %r2724, 16
  %r2808 = add i64 %r2807, %r2806
  %r2809 = inttoptr i64 %r2808 to ptr
  %r2810 = load double, ptr %r2809, align 8
  br label %pic.merge.577

pic.miss.574:                                     ; preds = %pic.hit.inline.581, %pic.prefix.token.567, %pic.prefix.meta.566, %pic.prefix.guard.565
  %r2811 = getelementptr i64, ptr %r2744, i64 3
  %r2812 = load i64, ptr %r2811, align 8
  %r2813 = icmp sgt i64 %r2812, 0
  br i1 %r2813, label %pic.ways.582, label %pic.miss.call.576

pic.miss.cold.575:                                ; preds = %pic.desc.prefix.token.572, %pic.desc.prefix.meta.571, %pic.desc.prefix.guard.570, %pic.desc.classify.569, %pget.recv_ok.557
  br label %pic.miss.call.576

pic.miss.call.576:                                ; preds = %pic.way.load.583, %pic.ways.582, %pic.miss.cold.575, %pic.miss.574
  %r2852 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2853 = bitcast double %r2852 to i64
  %r2854 = and i64 %r2853, 281474976710655
  %statepoint_token793 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2724, i64 %r2854, ptr @perry_ic_test_json_template_capture_ts__29, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31184, ptr addrspace(1) %.331006, ptr addrspace(1) %.44, ptr addrspace(1) %.01188, ptr addrspace(1) %.331047) ]
  %r2855794 = call double @llvm.experimental.gc.result.f64(token %statepoint_token793)
  %rs4gc.s35.relocated795 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token793, i32 0, i32 0) ; (%.31184, %.31184)
  %r48.0.base.relocated796 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token793, i32 1, i32 1) ; (%.331006, %.331006)
  %r57.0.relocated797 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token793, i32 2, i32 2) ; (%.44, %.44)
  %rs4gc.s39.relocated798 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token793, i32 3, i32 3) ; (%.01188, %.01188)
  %r48.0.relocated799 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token793, i32 1, i32 4) ; (%.331006, %.331047)
  br label %pic.merge.577

pic.merge.577:                                    ; preds = %pic.way.live.584, %pic.hit.overflow.580, %pic.miss.call.576, %pic.desc.prefix.hit.573, %pic.prefix.hit.568, %pic.hit.live.564
  %.21190 = phi ptr addrspace(1) [ %rs4gc.s39.relocated805, %pic.hit.overflow.580 ], [ %rs4gc.s39.relocated798, %pic.miss.call.576 ], [ %.01188, %pic.way.live.584 ], [ %.01188, %pic.hit.live.564 ], [ %.01188, %pic.prefix.hit.568 ], [ %.01188, %pic.desc.prefix.hit.573 ]
  %.51186 = phi ptr addrspace(1) [ %rs4gc.s35.relocated802, %pic.hit.overflow.580 ], [ %rs4gc.s35.relocated795, %pic.miss.call.576 ], [ %.31184, %pic.way.live.584 ], [ %.31184, %pic.hit.live.564 ], [ %.31184, %pic.prefix.hit.568 ], [ %.31184, %pic.desc.prefix.hit.573 ]
  %.351049 = phi ptr addrspace(1) [ %r48.0.relocated806, %pic.hit.overflow.580 ], [ %r48.0.relocated799, %pic.miss.call.576 ], [ %.331047, %pic.way.live.584 ], [ %.331047, %pic.hit.live.564 ], [ %.331047, %pic.prefix.hit.568 ], [ %.331047, %pic.desc.prefix.hit.573 ]
  %.351008 = phi ptr addrspace(1) [ %r48.0.base.relocated803, %pic.hit.overflow.580 ], [ %r48.0.base.relocated796, %pic.miss.call.576 ], [ %.331006, %pic.way.live.584 ], [ %.331006, %pic.hit.live.564 ], [ %.331006, %pic.prefix.hit.568 ], [ %.331006, %pic.desc.prefix.hit.573 ]
  %.46 = phi ptr addrspace(1) [ %r57.0.relocated804, %pic.hit.overflow.580 ], [ %r57.0.relocated797, %pic.miss.call.576 ], [ %.44, %pic.way.live.584 ], [ %.44, %pic.hit.live.564 ], [ %.44, %pic.prefix.hit.568 ], [ %.44, %pic.desc.prefix.hit.573 ]
  %r2856 = phi double [ %r2772, %pic.hit.live.564 ], [ %r2767801, %pic.hit.overflow.580 ], [ %r2792, %pic.prefix.hit.568 ], [ %r2810, %pic.desc.prefix.hit.573 ], [ %r2849, %pic.way.live.584 ], [ %r2855794, %pic.miss.call.576 ]
  br label %pget.recv_merge.560

pic.recv_hdr.578:                                 ; preds = %pget.recv_ok.557
  %r2735 = sub nuw nsw i64 %r2724, 8
  %r2736 = inttoptr i64 %r2735 to ptr
  %r2737 = load i8, ptr %r2736, align 1
  %r2738 = icmp eq i8 %r2737, 2
  %r2739 = sub nuw nsw i64 %r2724, 6
  %r2740 = inttoptr i64 %r2739 to ptr
  %r2741 = load i16, ptr %r2740, align 2
  %r2742 = and i16 %r2741, 2048
  %r2743 = icmp eq i16 %r2742, 0
  %r2744 = load ptr, ptr @perry_ic_test_json_template_capture_ts__29, align 8
  %r2745 = icmp ne ptr %r2744, null
  %r2746 = and i1 %r2738, %r2743
  %r2747 = and i1 %r2746, %r2745
  br i1 %r2747, label %pic.token.579, label %pic.desc.classify.569

pic.token.579:                                    ; preds = %pic.recv_hdr.578
  %r2749 = add nuw nsw i64 %r2724, 4
  %r2750 = inttoptr i64 %r2749 to ptr
  %r2751 = load i32, ptr %r2750, align 4
  %r2752 = zext i32 %r2751 to i64
  %r2753 = or i64 %r2752, 4611686018427387904
  %r2754 = icmp ne i32 %r2751, 0
  %r2755 = getelementptr i64, ptr %r2744, i64 0
  %r2756 = load i64, ptr %r2755, align 8
  %r2757 = icmp eq i64 %r2753, %r2756
  %r2758 = and i1 %r2757, %r2754
  br i1 %r2758, label %pic.hit.563, label %pic.prefix.guard.565

pic.hit.overflow.580:                             ; preds = %pic.hit.563
  %r2763 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2764 = bitcast double %r2763 to i64
  %r2765 = and i64 %r2764, 281474976710655
  %r2766 = trunc i64 %r2760 to i32
  %statepoint_token800 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2724, i64 %r2765, i32 %r2766, ptr @perry_ic_test_json_template_capture_ts__29, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31184, ptr addrspace(1) %.331006, ptr addrspace(1) %.44, ptr addrspace(1) %.01188, ptr addrspace(1) %.331047) ]
  %r2767801 = call double @llvm.experimental.gc.result.f64(token %statepoint_token800)
  %rs4gc.s35.relocated802 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token800, i32 0, i32 0) ; (%.31184, %.31184)
  %r48.0.base.relocated803 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token800, i32 1, i32 1) ; (%.331006, %.331006)
  %r57.0.relocated804 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token800, i32 2, i32 2) ; (%.44, %.44)
  %rs4gc.s39.relocated805 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token800, i32 3, i32 3) ; (%.01188, %.01188)
  %r48.0.relocated806 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token800, i32 1, i32 4) ; (%.331006, %.331047)
  br label %pic.merge.577

pic.hit.inline.581:                               ; preds = %pic.hit.563
  %r2768 = shl i64 %r2760, 3
  %r2769 = add nuw nsw i64 %r2724, 16
  %r2770 = add i64 %r2769, %r2768
  %r2771 = inttoptr i64 %r2770 to ptr
  %r2772 = load double, ptr %r2771, align 8
  %r2773 = bitcast double %r2772 to i64
  %r2774 = icmp eq i64 %r2773, 9222246136947933200
  br i1 %r2774, label %pic.miss.574, label %pic.hit.live.564

pic.ways.582:                                     ; preds = %pic.miss.574
  %r2814 = getelementptr i64, ptr %r2744, i64 4
  %r2815 = load i64, ptr %r2814, align 8
  %r2816 = icmp eq i64 %r2815, %r2753
  %r2817 = getelementptr i64, ptr %r2744, i64 5
  %r2818 = load i64, ptr %r2817, align 8
  %r2819 = select i1 %r2816, i64 %r2818, i64 0
  %r2820 = getelementptr i64, ptr %r2744, i64 6
  %r2821 = load i64, ptr %r2820, align 8
  %r2822 = icmp eq i64 %r2821, %r2753
  %r2823 = getelementptr i64, ptr %r2744, i64 7
  %r2824 = load i64, ptr %r2823, align 8
  %r2825 = select i1 %r2822, i64 %r2824, i64 0
  %r2826 = getelementptr i64, ptr %r2744, i64 8
  %r2827 = load i64, ptr %r2826, align 8
  %r2828 = icmp eq i64 %r2827, %r2753
  %r2829 = getelementptr i64, ptr %r2744, i64 9
  %r2830 = load i64, ptr %r2829, align 8
  %r2831 = select i1 %r2828, i64 %r2830, i64 0
  %r2832 = getelementptr i64, ptr %r2744, i64 10
  %r2833 = load i64, ptr %r2832, align 8
  %r2834 = icmp eq i64 %r2833, %r2753
  %r2835 = getelementptr i64, ptr %r2744, i64 11
  %r2836 = load i64, ptr %r2835, align 8
  %r2837 = select i1 %r2834, i64 %r2836, i64 0
  %r2838 = or i1 %r2816, %r2822
  %r2839 = select i1 %r2816, i64 %r2819, i64 %r2825
  %r2840 = or i1 %r2828, %r2834
  %r2841 = select i1 %r2828, i64 %r2831, i64 %r2837
  %r2842 = or i1 %r2838, %r2840
  %r2843 = select i1 %r2838, i64 %r2839, i64 %r2841
  %r2844 = and i1 %r2754, %r2842
  br i1 %r2844, label %pic.way.load.583, label %pic.miss.call.576

pic.way.load.583:                                 ; preds = %pic.ways.582
  %r2845 = shl i64 %r2843, 3
  %r2846 = add nuw nsw i64 %r2724, 16
  %r2847 = add i64 %r2846, %r2845
  %r2848 = inttoptr i64 %r2847 to ptr
  %r2849 = load double, ptr %r2848, align 8
  %r2850 = bitcast double %r2849 to i64
  %r2851 = icmp eq i64 %r2850, 9222246136947933200
  br i1 %r2851, label %pic.miss.call.576, label %pic.way.live.584

pic.way.live.584:                                 ; preds = %pic.way.load.583
  br label %pic.merge.577

pget.throw_nullish.585:                           ; preds = %pget.recv_bad.558
  %r2860 = zext i1 %r2858 to i32
  %statepoint_token807 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2860, ptr @test_json_template_capture_ts_.str.2.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.586:                       ; preds = %pget.recv_bad.558
  %r2861 = load double, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  %r2862 = bitcast double %r2861 to i64
  %r2863 = and i64 %r2862, 281474976710655
  %statepoint_token808 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2723, i64 %r2863, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31184, ptr addrspace(1) %.331006, ptr addrspace(1) %.44, ptr addrspace(1) %.01188, ptr addrspace(1) %.331047) ]
  %r2864809 = call double @llvm.experimental.gc.result.f64(token %statepoint_token808)
  %rs4gc.s35.relocated810 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 0, i32 0) ; (%.31184, %.31184)
  %r48.0.base.relocated811 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 1, i32 1) ; (%.331006, %.331006)
  %r57.0.relocated812 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 2, i32 2) ; (%.44, %.44)
  %rs4gc.s39.relocated813 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 3, i32 3) ; (%.01188, %.01188)
  %r48.0.relocated814 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token808, i32 1, i32 4) ; (%.331006, %.331047)
  br label %pget.recv_merge.560

shadow.root.barrier.587:                          ; preds = %pget.recv_merge.560
  call void @js_write_barrier_root_nanbox(i64 %r2872) #7
  br label %shadow.root.barrier.done.588

shadow.root.barrier.done.588:                     ; preds = %shadow.root.barrier.587, %pget.recv_merge.560
  %r2875.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated791 to i64
  %r2875.rs4o = call i64 asm "", "=r,0"(i64 %r2875.rs4i) #7
  %r2875 = bitcast i64 %r2875.rs4o to double
  %r2877 = bitcast double %r2875 to i64
  %r2878 = and i64 %r2877, 281474976710655
  %r2879 = load double, ptr @test_json_template_capture_ts_.str.0.handle, align 8
  %r2880 = bitcast double %r2879 to i64
  %r2881 = and i64 %r2880, 281474976710655
  %r2882 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r2883 = icmp eq i8 %r2882, 0
  %r2884 = lshr i64 %r2877, 48
  %r2885 = icmp eq i64 %r2884, 32765
  %r2886 = icmp ugt i64 %r2878, 1048575
  %r2887 = and i1 %r2885, %r2886
  %r2888 = and i1 %r2887, %r2883
  br i1 %r2888, label %class_field_inline.deref.592, label %class_field_inline.guardcall.593

class_field_get.fast.589:                         ; preds = %class_field_inline.guardcall.593, %class_field_inline.deref.592
  %r3527.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated791 to i64
  %r3527.rs4o = call i64 asm "", "=r,0"(i64 %r3527.rs4i) #7
  %r3527 = bitcast i64 %r3527.rs4o to double
  %r3528 = bitcast double %r3527 to i64
  %r3529 = and i64 %r3528, 281474976710655
  %r2913 = inttoptr i64 %r3529 to ptr
  %r3523.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated791 to i64
  %r3523.rs4o = call i64 asm "", "=r,0"(i64 %r3523.rs4i) #7
  %r3523 = bitcast i64 %r3523.rs4o to double
  %r3524 = bitcast double %r3523 to i64
  %r3525 = and i64 %r3524, 281474976710655
  %r3526 = inttoptr i64 %r3525 to ptr
  %r2914 = getelementptr i8, ptr %r3526, i64 16
  %r2915 = getelementptr double, ptr %r2914, i64 0
  %r2916 = load double, ptr %r2915, align 8
  br label %class_field_get.merge.591

class_field_get.fallback.590:                     ; preds = %class_field_inline.guardcall.593
  %r3521.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated791 to i64
  %r3521.rs4o = call i64 asm "", "=r,0"(i64 %r3521.rs4i) #7
  %r3521 = bitcast i64 %r3521.rs4o to double
  %r3522 = bitcast double %r3521 to i64
  %r2917 = icmp eq i64 %r3522, 9222246136947933185
  %r3519.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated791 to i64
  %r3519.rs4o = call i64 asm "", "=r,0"(i64 %r3519.rs4i) #7
  %r3519 = bitcast i64 %r3519.rs4o to double
  %r3520 = bitcast double %r3519 to i64
  %r2918 = icmp eq i64 %r3520, 9222246136947933186
  %r2919 = or i1 %r2917, %r2918
  br i1 %r2919, label %class_field_get.throw_nullish.594, label %class_field_get.fallback_lookup.595

class_field_get.merge.591:                        ; preds = %class_field_get.fallback_lookup.595, %class_field_get.fast.589
  %.01191 = phi ptr addrspace(1) [ %rs4gc.s40, %class_field_get.fast.589 ], [ %rs4gc.s40.relocated, %class_field_get.fallback_lookup.595 ]
  %.361050 = phi ptr addrspace(1) [ %r48.0.relocated792, %class_field_get.fast.589 ], [ %r48.0.relocated820, %class_field_get.fallback_lookup.595 ]
  %.361009 = phi ptr addrspace(1) [ %r48.0.base.relocated789, %class_field_get.fast.589 ], [ %r48.0.base.relocated818, %class_field_get.fallback_lookup.595 ]
  %.47 = phi ptr addrspace(1) [ %r57.0.relocated790, %class_field_get.fast.589 ], [ %r57.0.relocated819, %class_field_get.fallback_lookup.595 ]
  %r2922 = phi double [ %r2916, %class_field_get.fast.589 ], [ %r2921817, %class_field_get.fallback_lookup.595 ]
  %r2923 = bitcast double %r2922 to i64
  %r2924 = and i64 %r2923, 281474976710655
  %r2925 = lshr i64 %r2923, 48
  %r2926 = and i64 %r2925, 65533
  %r2927 = icmp eq i64 %r2926, 32765
  br i1 %r2927, label %pget.recv_ok.597, label %pget.recv_other.601

class_field_inline.deref.592:                     ; preds = %shadow.root.barrier.done.588
  %r2889 = inttoptr i64 %r2878 to ptr
  %r2890 = getelementptr i8, ptr %r2889, i64 -8
  %r2891 = load i8, ptr %r2890, align 1
  %r2892 = icmp eq i8 %r2891, 2
  %r2893 = getelementptr i8, ptr %r2889, i64 -7
  %r2894 = load i8, ptr %r2893, align 1
  %r2895 = and i8 %r2894, -128
  %r2896 = icmp eq i8 %r2895, 0
  %r2897 = getelementptr i8, ptr %r2889, i64 -6
  %r2898 = load i16, ptr %r2897, align 2
  %r2899 = getelementptr i8, ptr %r2889, i64 0
  %r2900 = load i32, ptr %r2899, align 4
  %r2901 = icmp eq i32 %r2900, 1
  %r2902 = getelementptr i8, ptr %r2889, i64 4
  %r2903 = load i32, ptr %r2902, align 4
  %r2904 = icmp eq i32 %r2903, %r2536
  %r2905 = and i1 %r2892, %r2896
  %r2906 = and i1 %r2905, %r2901
  %r2907 = and i1 %r2906, %r2904
  %r2908 = and i16 %r2898, 3072
  %r2909 = icmp eq i16 %r2908, 0
  %r2910 = and i1 %r2907, %r2909
  br i1 %r2910, label %class_field_get.fast.589, label %class_field_inline.guardcall.593

class_field_inline.guardcall.593:                 ; preds = %class_field_inline.deref.592, %shadow.root.barrier.done.588
  %r2911 = call i32 @js_typed_feedback_class_field_get_guard(i64 6060382687846203422, double %r2875, i32 1, i32 %r2536, i64 %r2881, i32 0, i32 0) #7
  %r2912 = icmp ne i32 %r2911, 0
  br i1 %r2912, label %class_field_get.fast.589, label %class_field_get.fallback.590

class_field_get.throw_nullish.594:                ; preds = %class_field_get.fallback.590
  %r2920 = zext i1 %r2918 to i32
  %statepoint_token815 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2920, ptr @test_json_template_capture_ts_.str.0.bytes, i64 5, i32 0, i32 0)
  unreachable

class_field_get.fallback_lookup.595:              ; preds = %class_field_get.fallback.590
  %r3514.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated791 to i64
  %r3514.rs4o = call i64 asm "", "=r,0"(i64 %r3514.rs4i) #7
  %r3514 = bitcast i64 %r3514.rs4o to double
  %r3515 = bitcast double %r3514 to i64
  %r3516 = load double, ptr @test_json_template_capture_ts_.str.0.handle, align 8
  %r3517 = bitcast double %r3516 to i64
  %r3518 = and i64 %r3517, 281474976710655
  %statepoint_token816 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3515, i64 %r3518, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s40, ptr addrspace(1) %r48.0.base.relocated789, ptr addrspace(1) %r57.0.relocated790, ptr addrspace(1) %r48.0.relocated792) ]
  %r2921817 = call double @llvm.experimental.gc.result.f64(token %statepoint_token816)
  %rs4gc.s40.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token816, i32 0, i32 0) ; (%rs4gc.s40, %rs4gc.s40)
  %r48.0.base.relocated818 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token816, i32 1, i32 1) ; (%r48.0.base.relocated789, %r48.0.base.relocated789)
  %r57.0.relocated819 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token816, i32 2, i32 2) ; (%r57.0.relocated790, %r57.0.relocated790)
  %r48.0.relocated820 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token816, i32 1, i32 3) ; (%r48.0.base.relocated789, %r48.0.relocated792)
  br label %class_field_get.merge.591

pget.recv_sso.596:                                ; preds = %pget.recv_other.601
  %r3065 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r3066 = bitcast double %r3065 to i64
  %r3067 = and i64 %r3066, 281474976710655
  %statepoint_token821 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2923, i64 %r3067, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01191, ptr addrspace(1) %.361009, ptr addrspace(1) %.47, ptr addrspace(1) %.361050) ]
  %r3068822 = call double @llvm.experimental.gc.result.f64(token %statepoint_token821)
  %rs4gc.s40.relocated823 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token821, i32 0, i32 0) ; (%.01191, %.01191)
  %r48.0.base.relocated824 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token821, i32 1, i32 1) ; (%.361009, %.361009)
  %r57.0.relocated825 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token821, i32 2, i32 2) ; (%.47, %.47)
  %r48.0.relocated826 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token821, i32 1, i32 3) ; (%.361009, %.361050)
  br label %pget.recv_merge.600

pget.recv_ok.597:                                 ; preds = %class_field_get.merge.591
  %r2934 = icmp ugt i64 %r2924, 1048575
  br i1 %r2934, label %pic.recv_hdr.618, label %pic.miss.cold.615

pget.recv_bad.598:                                ; preds = %pget.check_class_ref.602
  %r3057 = icmp eq i64 %r2923, 9222246136947933185
  %r3058 = icmp eq i64 %r2923, 9222246136947933186
  %r3059 = or i1 %r3057, %r3058
  br i1 %r3059, label %pget.throw_nullish.625, label %pget.recv_undef_return.626

pget.recv_class_ref.599:                          ; preds = %pget.check_class_ref.602
  %r2930 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r2931 = bitcast double %r2930 to i64
  %r2932 = and i64 %r2931, 281474976710655
  %statepoint_token827 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6060382687846203423, i64 %r2923, i64 %r2932, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01191, ptr addrspace(1) %.361009, ptr addrspace(1) %.47, ptr addrspace(1) %.361050) ]
  %r2933828 = call double @llvm.experimental.gc.result.f64(token %statepoint_token827)
  %rs4gc.s40.relocated829 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token827, i32 0, i32 0) ; (%.01191, %.01191)
  %r48.0.base.relocated830 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token827, i32 1, i32 1) ; (%.361009, %.361009)
  %r57.0.relocated831 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token827, i32 2, i32 2) ; (%.47, %.47)
  %r48.0.relocated832 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token827, i32 1, i32 3) ; (%.361009, %.361050)
  br label %pget.recv_merge.600

pget.recv_merge.600:                              ; preds = %pget.recv_undef_return.626, %pic.merge.617, %pget.recv_class_ref.599, %pget.recv_sso.596
  %.11192 = phi ptr addrspace(1) [ %.21193, %pic.merge.617 ], [ %rs4gc.s40.relocated823, %pget.recv_sso.596 ], [ %rs4gc.s40.relocated829, %pget.recv_class_ref.599 ], [ %rs4gc.s40.relocated848, %pget.recv_undef_return.626 ]
  %.371051 = phi ptr addrspace(1) [ %.381052, %pic.merge.617 ], [ %r48.0.relocated826, %pget.recv_sso.596 ], [ %r48.0.relocated832, %pget.recv_class_ref.599 ], [ %r48.0.relocated851, %pget.recv_undef_return.626 ]
  %.371010 = phi ptr addrspace(1) [ %.381011, %pic.merge.617 ], [ %r48.0.base.relocated824, %pget.recv_sso.596 ], [ %r48.0.base.relocated830, %pget.recv_class_ref.599 ], [ %r48.0.base.relocated849, %pget.recv_undef_return.626 ]
  %.48 = phi ptr addrspace(1) [ %.49, %pic.merge.617 ], [ %r57.0.relocated825, %pget.recv_sso.596 ], [ %r57.0.relocated831, %pget.recv_class_ref.599 ], [ %r57.0.relocated850, %pget.recv_undef_return.626 ]
  %r3069 = phi double [ %r3056, %pic.merge.617 ], [ %r3064847, %pget.recv_undef_return.626 ], [ %r3068822, %pget.recv_sso.596 ], [ %r2933828, %pget.recv_class_ref.599 ]
  %r3070 = bitcast double %r3069 to i64
  %r3071 = and i64 %r3070, 281474976710655
  %r3072 = and i64 %r3070, -281474976710656
  %r3073 = icmp eq i64 %r3072, 9222527611924643840
  %r3074 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r3075 = icmp eq i64 %r3074, 0
  %r3076 = icmp ugt i64 %r3071, 1048575
  %r3077 = icmp ult i64 %r3071, 140737488355328
  %r3078 = and i1 %r3076, %r3077
  %r3079 = and i1 %r3073, %r3075
  %r3080 = and i1 %r3079, %r3078
  br i1 %r3080, label %tav.get.brand.631, label %tav.get.slow.629

pget.recv_other.601:                              ; preds = %class_field_get.merge.591
  %r2928 = icmp eq i64 %r2925, 32761
  br i1 %r2928, label %pget.recv_sso.596, label %pget.check_class_ref.602

pget.check_class_ref.602:                         ; preds = %pget.recv_other.601
  %r2929 = icmp eq i64 %r2925, 32766
  br i1 %r2929, label %pget.recv_class_ref.599, label %pget.recv_bad.598

pic.hit.603:                                      ; preds = %pic.token.619
  %r2959 = getelementptr i64, ptr %r2944, i64 1
  %r2960 = load i64, ptr %r2959, align 8
  %r2961 = and i64 %r2960, 1073741824
  %r2962 = icmp ne i64 %r2961, 0
  br i1 %r2962, label %pic.hit.overflow.620, label %pic.hit.inline.621

pic.hit.live.604:                                 ; preds = %pic.hit.inline.621
  br label %pic.merge.617

pic.prefix.guard.605:                             ; preds = %pic.token.619
  %r2975 = getelementptr i64, ptr %r2944, i64 2
  %r2976 = load i64, ptr %r2975, align 8
  %r2977 = icmp ne i64 %r2976, 0
  br i1 %r2977, label %pic.prefix.meta.606, label %pic.miss.614

pic.prefix.meta.606:                              ; preds = %pic.prefix.guard.605
  %r2978 = add nuw nsw i64 %r2924, 8
  %r2979 = inttoptr i64 %r2978 to ptr
  %r2980 = load i64, ptr %r2979, align 8
  %r2981 = icmp ne i64 %r2980, 0
  br i1 %r2981, label %pic.prefix.token.607, label %pic.miss.614

pic.prefix.token.607:                             ; preds = %pic.prefix.meta.606
  %r2982 = inttoptr i64 %r2980 to ptr
  %r2983 = getelementptr i64, ptr %r2982, i64 6
  %r2984 = load i64, ptr %r2983, align 8
  %r2985 = icmp eq i64 %r2984, %r2976
  br i1 %r2985, label %pic.prefix.hit.608, label %pic.miss.614

pic.prefix.hit.608:                               ; preds = %pic.prefix.token.607
  %r2986 = getelementptr i64, ptr %r2944, i64 1
  %r2987 = load i64, ptr %r2986, align 8
  %r2988 = shl i64 %r2987, 3
  %r2989 = add nuw nsw i64 %r2924, 16
  %r2990 = add i64 %r2989, %r2988
  %r2991 = inttoptr i64 %r2990 to ptr
  %r2992 = load double, ptr %r2991, align 8
  br label %pic.merge.617

pic.desc.classify.609:                            ; preds = %pic.recv_hdr.618
  %r2948 = and i1 %r2938, %r2945
  br i1 %r2948, label %pic.desc.prefix.guard.610, label %pic.miss.cold.615

pic.desc.prefix.guard.610:                        ; preds = %pic.desc.classify.609
  %r2993 = getelementptr i64, ptr %r2944, i64 2
  %r2994 = load i64, ptr %r2993, align 8
  %r2995 = icmp ne i64 %r2994, 0
  br i1 %r2995, label %pic.desc.prefix.meta.611, label %pic.miss.cold.615

pic.desc.prefix.meta.611:                         ; preds = %pic.desc.prefix.guard.610
  %r2996 = add nuw nsw i64 %r2924, 8
  %r2997 = inttoptr i64 %r2996 to ptr
  %r2998 = load i64, ptr %r2997, align 8
  %r2999 = icmp ne i64 %r2998, 0
  br i1 %r2999, label %pic.desc.prefix.token.612, label %pic.miss.cold.615

pic.desc.prefix.token.612:                        ; preds = %pic.desc.prefix.meta.611
  %r3000 = inttoptr i64 %r2998 to ptr
  %r3001 = getelementptr i64, ptr %r3000, i64 6
  %r3002 = load i64, ptr %r3001, align 8
  %r3003 = icmp eq i64 %r3002, %r2994
  br i1 %r3003, label %pic.desc.prefix.hit.613, label %pic.miss.cold.615

pic.desc.prefix.hit.613:                          ; preds = %pic.desc.prefix.token.612
  %r3004 = getelementptr i64, ptr %r2944, i64 1
  %r3005 = load i64, ptr %r3004, align 8
  %r3006 = shl i64 %r3005, 3
  %r3007 = add nuw nsw i64 %r2924, 16
  %r3008 = add i64 %r3007, %r3006
  %r3009 = inttoptr i64 %r3008 to ptr
  %r3010 = load double, ptr %r3009, align 8
  br label %pic.merge.617

pic.miss.614:                                     ; preds = %pic.hit.inline.621, %pic.prefix.token.607, %pic.prefix.meta.606, %pic.prefix.guard.605
  %r3011 = getelementptr i64, ptr %r2944, i64 3
  %r3012 = load i64, ptr %r3011, align 8
  %r3013 = icmp sgt i64 %r3012, 0
  br i1 %r3013, label %pic.ways.622, label %pic.miss.call.616

pic.miss.cold.615:                                ; preds = %pic.desc.prefix.token.612, %pic.desc.prefix.meta.611, %pic.desc.prefix.guard.610, %pic.desc.classify.609, %pget.recv_ok.597
  br label %pic.miss.call.616

pic.miss.call.616:                                ; preds = %pic.way.load.623, %pic.ways.622, %pic.miss.cold.615, %pic.miss.614
  %r3052 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r3053 = bitcast double %r3052 to i64
  %r3054 = and i64 %r3053, 281474976710655
  %statepoint_token833 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2924, i64 %r3054, ptr @perry_ic_test_json_template_capture_ts__32, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01191, ptr addrspace(1) %.361009, ptr addrspace(1) %.47, ptr addrspace(1) %.361050) ]
  %r3055834 = call double @llvm.experimental.gc.result.f64(token %statepoint_token833)
  %rs4gc.s40.relocated835 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token833, i32 0, i32 0) ; (%.01191, %.01191)
  %r48.0.base.relocated836 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token833, i32 1, i32 1) ; (%.361009, %.361009)
  %r57.0.relocated837 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token833, i32 2, i32 2) ; (%.47, %.47)
  %r48.0.relocated838 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token833, i32 1, i32 3) ; (%.361009, %.361050)
  br label %pic.merge.617

pic.merge.617:                                    ; preds = %pic.way.live.624, %pic.hit.overflow.620, %pic.miss.call.616, %pic.desc.prefix.hit.613, %pic.prefix.hit.608, %pic.hit.live.604
  %.21193 = phi ptr addrspace(1) [ %rs4gc.s40.relocated841, %pic.hit.overflow.620 ], [ %rs4gc.s40.relocated835, %pic.miss.call.616 ], [ %.01191, %pic.way.live.624 ], [ %.01191, %pic.hit.live.604 ], [ %.01191, %pic.prefix.hit.608 ], [ %.01191, %pic.desc.prefix.hit.613 ]
  %.381052 = phi ptr addrspace(1) [ %r48.0.relocated844, %pic.hit.overflow.620 ], [ %r48.0.relocated838, %pic.miss.call.616 ], [ %.361050, %pic.way.live.624 ], [ %.361050, %pic.hit.live.604 ], [ %.361050, %pic.prefix.hit.608 ], [ %.361050, %pic.desc.prefix.hit.613 ]
  %.381011 = phi ptr addrspace(1) [ %r48.0.base.relocated842, %pic.hit.overflow.620 ], [ %r48.0.base.relocated836, %pic.miss.call.616 ], [ %.361009, %pic.way.live.624 ], [ %.361009, %pic.hit.live.604 ], [ %.361009, %pic.prefix.hit.608 ], [ %.361009, %pic.desc.prefix.hit.613 ]
  %.49 = phi ptr addrspace(1) [ %r57.0.relocated843, %pic.hit.overflow.620 ], [ %r57.0.relocated837, %pic.miss.call.616 ], [ %.47, %pic.way.live.624 ], [ %.47, %pic.hit.live.604 ], [ %.47, %pic.prefix.hit.608 ], [ %.47, %pic.desc.prefix.hit.613 ]
  %r3056 = phi double [ %r2972, %pic.hit.live.604 ], [ %r2967840, %pic.hit.overflow.620 ], [ %r2992, %pic.prefix.hit.608 ], [ %r3010, %pic.desc.prefix.hit.613 ], [ %r3049, %pic.way.live.624 ], [ %r3055834, %pic.miss.call.616 ]
  br label %pget.recv_merge.600

pic.recv_hdr.618:                                 ; preds = %pget.recv_ok.597
  %r2935 = sub nuw nsw i64 %r2924, 8
  %r2936 = inttoptr i64 %r2935 to ptr
  %r2937 = load i8, ptr %r2936, align 1
  %r2938 = icmp eq i8 %r2937, 2
  %r2939 = sub nuw nsw i64 %r2924, 6
  %r2940 = inttoptr i64 %r2939 to ptr
  %r2941 = load i16, ptr %r2940, align 2
  %r2942 = and i16 %r2941, 2048
  %r2943 = icmp eq i16 %r2942, 0
  %r2944 = load ptr, ptr @perry_ic_test_json_template_capture_ts__32, align 8
  %r2945 = icmp ne ptr %r2944, null
  %r2946 = and i1 %r2938, %r2943
  %r2947 = and i1 %r2946, %r2945
  br i1 %r2947, label %pic.token.619, label %pic.desc.classify.609

pic.token.619:                                    ; preds = %pic.recv_hdr.618
  %r2949 = add nuw nsw i64 %r2924, 4
  %r2950 = inttoptr i64 %r2949 to ptr
  %r2951 = load i32, ptr %r2950, align 4
  %r2952 = zext i32 %r2951 to i64
  %r2953 = or i64 %r2952, 4611686018427387904
  %r2954 = icmp ne i32 %r2951, 0
  %r2955 = getelementptr i64, ptr %r2944, i64 0
  %r2956 = load i64, ptr %r2955, align 8
  %r2957 = icmp eq i64 %r2953, %r2956
  %r2958 = and i1 %r2957, %r2954
  br i1 %r2958, label %pic.hit.603, label %pic.prefix.guard.605

pic.hit.overflow.620:                             ; preds = %pic.hit.603
  %r2963 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r2964 = bitcast double %r2963 to i64
  %r2965 = and i64 %r2964, 281474976710655
  %r2966 = trunc i64 %r2960 to i32
  %statepoint_token839 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2924, i64 %r2965, i32 %r2966, ptr @perry_ic_test_json_template_capture_ts__32, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01191, ptr addrspace(1) %.361009, ptr addrspace(1) %.47, ptr addrspace(1) %.361050) ]
  %r2967840 = call double @llvm.experimental.gc.result.f64(token %statepoint_token839)
  %rs4gc.s40.relocated841 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token839, i32 0, i32 0) ; (%.01191, %.01191)
  %r48.0.base.relocated842 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token839, i32 1, i32 1) ; (%.361009, %.361009)
  %r57.0.relocated843 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token839, i32 2, i32 2) ; (%.47, %.47)
  %r48.0.relocated844 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token839, i32 1, i32 3) ; (%.361009, %.361050)
  br label %pic.merge.617

pic.hit.inline.621:                               ; preds = %pic.hit.603
  %r2968 = shl i64 %r2960, 3
  %r2969 = add nuw nsw i64 %r2924, 16
  %r2970 = add i64 %r2969, %r2968
  %r2971 = inttoptr i64 %r2970 to ptr
  %r2972 = load double, ptr %r2971, align 8
  %r2973 = bitcast double %r2972 to i64
  %r2974 = icmp eq i64 %r2973, 9222246136947933200
  br i1 %r2974, label %pic.miss.614, label %pic.hit.live.604

pic.ways.622:                                     ; preds = %pic.miss.614
  %r3014 = getelementptr i64, ptr %r2944, i64 4
  %r3015 = load i64, ptr %r3014, align 8
  %r3016 = icmp eq i64 %r3015, %r2953
  %r3017 = getelementptr i64, ptr %r2944, i64 5
  %r3018 = load i64, ptr %r3017, align 8
  %r3019 = select i1 %r3016, i64 %r3018, i64 0
  %r3020 = getelementptr i64, ptr %r2944, i64 6
  %r3021 = load i64, ptr %r3020, align 8
  %r3022 = icmp eq i64 %r3021, %r2953
  %r3023 = getelementptr i64, ptr %r2944, i64 7
  %r3024 = load i64, ptr %r3023, align 8
  %r3025 = select i1 %r3022, i64 %r3024, i64 0
  %r3026 = getelementptr i64, ptr %r2944, i64 8
  %r3027 = load i64, ptr %r3026, align 8
  %r3028 = icmp eq i64 %r3027, %r2953
  %r3029 = getelementptr i64, ptr %r2944, i64 9
  %r3030 = load i64, ptr %r3029, align 8
  %r3031 = select i1 %r3028, i64 %r3030, i64 0
  %r3032 = getelementptr i64, ptr %r2944, i64 10
  %r3033 = load i64, ptr %r3032, align 8
  %r3034 = icmp eq i64 %r3033, %r2953
  %r3035 = getelementptr i64, ptr %r2944, i64 11
  %r3036 = load i64, ptr %r3035, align 8
  %r3037 = select i1 %r3034, i64 %r3036, i64 0
  %r3038 = or i1 %r3016, %r3022
  %r3039 = select i1 %r3016, i64 %r3019, i64 %r3025
  %r3040 = or i1 %r3028, %r3034
  %r3041 = select i1 %r3028, i64 %r3031, i64 %r3037
  %r3042 = or i1 %r3038, %r3040
  %r3043 = select i1 %r3038, i64 %r3039, i64 %r3041
  %r3044 = and i1 %r2954, %r3042
  br i1 %r3044, label %pic.way.load.623, label %pic.miss.call.616

pic.way.load.623:                                 ; preds = %pic.ways.622
  %r3045 = shl i64 %r3043, 3
  %r3046 = add nuw nsw i64 %r2924, 16
  %r3047 = add i64 %r3046, %r3045
  %r3048 = inttoptr i64 %r3047 to ptr
  %r3049 = load double, ptr %r3048, align 8
  %r3050 = bitcast double %r3049 to i64
  %r3051 = icmp eq i64 %r3050, 9222246136947933200
  br i1 %r3051, label %pic.miss.call.616, label %pic.way.live.624

pic.way.live.624:                                 ; preds = %pic.way.load.623
  br label %pic.merge.617

pget.throw_nullish.625:                           ; preds = %pget.recv_bad.598
  %r3060 = zext i1 %r3058 to i32
  %statepoint_token845 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r3060, ptr @test_json_template_capture_ts_.str.9.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.626:                       ; preds = %pget.recv_bad.598
  %r3061 = load double, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  %r3062 = bitcast double %r3061 to i64
  %r3063 = and i64 %r3062, 281474976710655
  %statepoint_token846 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2923, i64 %r3063, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01191, ptr addrspace(1) %.361009, ptr addrspace(1) %.47, ptr addrspace(1) %.361050) ]
  %r3064847 = call double @llvm.experimental.gc.result.f64(token %statepoint_token846)
  %rs4gc.s40.relocated848 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token846, i32 0, i32 0) ; (%.01191, %.01191)
  %r48.0.base.relocated849 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token846, i32 1, i32 1) ; (%.361009, %.361009)
  %r57.0.relocated850 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token846, i32 2, i32 2) ; (%.47, %.47)
  %r48.0.relocated851 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token846, i32 1, i32 3) ; (%.361009, %.361050)
  br label %pget.recv_merge.600

tav.get.fast.627:                                 ; preds = %tav.get.brand.631
  %r3097 = bitcast double %r3069 to i64
  %r3098 = and i64 %r3097, 281474976710655
  %r3099 = add nuw nsw i64 %r3098, 8
  %r3100 = inttoptr i64 %r3099 to ptr
  %r3101 = load i8, ptr %r3100, align 1
  %r3102 = zext i8 %r3101 to i64
  %r3106 = inttoptr i64 %r3098 to ptr
  %r3107 = load i32, ptr %r3106, align 4
  %r3108 = zext i32 %r3107 to i64
  %r3109 = icmp ult i64 0, %r3108
  %r3110 = and i1 true, %r3109
  br i1 %r3110, label %tav.get.load.628, label %tav.get.slow.629

tav.get.load.628:                                 ; preds = %tav.get.fast.627
  %r3111 = add nuw nsw i64 %r3098, 16
  %r3112 = icmp eq i64 %r3102, 0
  br i1 %r3112, label %tav.k.i8.632, label %tav.kd1.640

tav.get.slow.629:                                 ; preds = %tav.get.brand.631, %tav.get.fast.627, %pget.recv_merge.600
  %r3163 = load ptr, ptr @perry_ic_test_json_template_capture_ts__33, align 8
  %r3164 = icmp ne ptr %r3163, null
  %r3165 = select i1 %r3164, ptr %r3163, ptr @perry_ic_test_json_template_capture_ts__33
  %r3166 = bitcast double %r3069 to i64
  %r3167 = and i64 %r3166, 281474976710655
  %r3168 = and i64 %r3166, -281474976710656
  %r3169 = icmp eq i64 %r3168, 9222527611924643840
  %r3170 = icmp uge i64 %r3167, 2199023255552
  %r3171 = icmp ult i64 %r3167, 140737488355328
  %r3174 = and i1 %r3169, %r3170
  %r3175 = and i1 %r3174, %r3171
  br i1 %r3175, label %arrlike.ic.header.647, label %arrlike.ic.miss.666

tav.get.merge.630:                                ; preds = %arrlike.elem.value.672, %arrlike.ic.miss.666, %arrlike.ic.spill_load.665, %arrlike.ic.inline.662, %arrlike.ic.array_load.650, %tav.k.f64.639, %tav.k.f32.638, %tav.k.u32.637, %tav.k.i32.636, %tav.k.u16.635, %tav.k.i16.634, %tav.k.u8.633, %tav.k.i8.632
  %.31194 = phi ptr addrspace(1) [ %.11192, %tav.k.i8.632 ], [ %.11192, %tav.k.u8.633 ], [ %.11192, %tav.k.i16.634 ], [ %.11192, %tav.k.u16.635 ], [ %.11192, %tav.k.i32.636 ], [ %.11192, %tav.k.u32.637 ], [ %.11192, %tav.k.f32.638 ], [ %.11192, %tav.k.f64.639 ], [ %.11192, %arrlike.ic.array_load.650 ], [ %rs4gc.s40.relocated861, %arrlike.ic.miss.666 ], [ %.11192, %arrlike.elem.value.672 ], [ %.11192, %arrlike.ic.inline.662 ], [ %.11192, %arrlike.ic.spill_load.665 ]
  %.391053 = phi ptr addrspace(1) [ %.371051, %tav.k.i8.632 ], [ %.371051, %tav.k.u8.633 ], [ %.371051, %tav.k.i16.634 ], [ %.371051, %tav.k.u16.635 ], [ %.371051, %tav.k.i32.636 ], [ %.371051, %tav.k.u32.637 ], [ %.371051, %tav.k.f32.638 ], [ %.371051, %tav.k.f64.639 ], [ %.371051, %arrlike.ic.array_load.650 ], [ %r48.0.relocated862, %arrlike.ic.miss.666 ], [ %.371051, %arrlike.elem.value.672 ], [ %.371051, %arrlike.ic.inline.662 ], [ %.371051, %arrlike.ic.spill_load.665 ]
  %.391012 = phi ptr addrspace(1) [ %.371010, %tav.k.i8.632 ], [ %.371010, %tav.k.u8.633 ], [ %.371010, %tav.k.i16.634 ], [ %.371010, %tav.k.u16.635 ], [ %.371010, %tav.k.i32.636 ], [ %.371010, %tav.k.u32.637 ], [ %.371010, %tav.k.f32.638 ], [ %.371010, %tav.k.f64.639 ], [ %.371010, %arrlike.ic.array_load.650 ], [ %r48.0.base.relocated859, %arrlike.ic.miss.666 ], [ %.371010, %arrlike.elem.value.672 ], [ %.371010, %arrlike.ic.inline.662 ], [ %.371010, %arrlike.ic.spill_load.665 ]
  %.50 = phi ptr addrspace(1) [ %.48, %tav.k.i8.632 ], [ %.48, %tav.k.u8.633 ], [ %.48, %tav.k.i16.634 ], [ %.48, %tav.k.u16.635 ], [ %.48, %tav.k.i32.636 ], [ %.48, %tav.k.u32.637 ], [ %.48, %tav.k.f32.638 ], [ %.48, %tav.k.f64.639 ], [ %.48, %arrlike.ic.array_load.650 ], [ %r57.0.relocated860, %arrlike.ic.miss.666 ], [ %.48, %arrlike.elem.value.672 ], [ %.48, %arrlike.ic.inline.662 ], [ %.48, %arrlike.ic.spill_load.665 ]
  %r3336 = phi double [ %r3125, %tav.k.i8.632 ], [ %r3131, %tav.k.u8.633 ], [ %r3137, %tav.k.i16.634 ], [ %r3143, %tav.k.u16.635 ], [ %r3148, %tav.k.i32.636 ], [ %r3153, %tav.k.u32.637 ], [ %r3158, %tav.k.f32.638 ], [ %r3162, %tav.k.f64.639 ], [ %r3219, %arrlike.elem.value.672 ], [ %r3247, %arrlike.ic.array_load.650 ], [ %r3317, %arrlike.ic.inline.662 ], [ %r3334, %arrlike.ic.spill_load.665 ], [ %r3335858, %arrlike.ic.miss.666 ]
  %r3337.rs4i = ptrtoint ptr addrspace(1) %.31194 to i64
  %r3337 = call i64 asm "", "=r,0"(i64 %r3337.rs4i) #7
  %statepoint_token852 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3337, double %r3336, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.391012, ptr addrspace(1) %.50, ptr addrspace(1) %.391053) ]
  %r3338853 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token852)
  %r48.0.base.relocated854 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token852, i32 0, i32 0) ; (%.391012, %.391012)
  %r57.0.relocated855 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token852, i32 1, i32 1) ; (%.50, %.50)
  %r48.0.relocated856 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token852, i32 0, i32 2) ; (%.391012, %.391053)
  %rs4gc.s41 = inttoptr i64 %r3338853 to ptr addrspace(1)
  %r3339.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s41 to i64
  %r3339 = call i64 asm "", "=r,0"(i64 %r3339.rs4i) #7
  %r3340 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3341 = icmp ne i32 %r3340, 0
  br i1 %r3341, label %shadow.root.barrier.674, label %shadow.root.barrier.done.675

tav.get.brand.631:                                ; preds = %pget.recv_merge.600
  %r3081 = bitcast double %r3069 to i64
  %r3082 = and i64 %r3081, 281474976710655
  %r3083 = sub nsw i64 %r3082, 8
  %r3084 = inttoptr i64 %r3083 to ptr
  %r3085 = load i8, ptr %r3084, align 1
  %r3086 = icmp eq i8 %r3085, 11
  %r3087 = add nuw nsw i64 %r3082, 8
  %r3088 = inttoptr i64 %r3087 to ptr
  %r3089 = load i8, ptr %r3088, align 1
  %r3090 = zext i8 %r3089 to i64
  %r3091 = icmp ule i64 %r3090, 8
  %r3094 = and i1 %r3086, %r3091
  br i1 %r3094, label %tav.get.fast.627, label %tav.get.slow.629

tav.k.i8.632:                                     ; preds = %tav.get.load.628
  %r3121 = add nuw nsw i64 %r3111, 0
  %r3122 = inttoptr i64 %r3121 to ptr
  %r3123 = load i8, ptr %r3122, align 1
  %r3124 = sext i8 %r3123 to i32
  %r3125 = sitofp i32 %r3124 to double
  br label %tav.get.merge.630

tav.k.u8.633:                                     ; preds = %tav.kd7.646, %tav.kd1.640
  %r3127 = add nuw nsw i64 %r3111, 0
  %r3128 = inttoptr i64 %r3127 to ptr
  %r3129 = load i8, ptr %r3128, align 1
  %r3130 = zext i8 %r3129 to i32
  %r3131 = uitofp nneg i32 %r3130 to double
  br label %tav.get.merge.630

tav.k.i16.634:                                    ; preds = %tav.kd2.641
  %r3133 = add nuw nsw i64 %r3111, 0
  %r3134 = inttoptr i64 %r3133 to ptr
  %r3135 = load i16, ptr %r3134, align 2
  %r3136 = sext i16 %r3135 to i32
  %r3137 = sitofp i32 %r3136 to double
  br label %tav.get.merge.630

tav.k.u16.635:                                    ; preds = %tav.kd3.642
  %r3139 = add nuw nsw i64 %r3111, 0
  %r3140 = inttoptr i64 %r3139 to ptr
  %r3141 = load i16, ptr %r3140, align 2
  %r3142 = zext i16 %r3141 to i32
  %r3143 = uitofp nneg i32 %r3142 to double
  br label %tav.get.merge.630

tav.k.i32.636:                                    ; preds = %tav.kd4.643
  %r3145 = add nuw nsw i64 %r3111, 0
  %r3146 = inttoptr i64 %r3145 to ptr
  %r3147 = load i32, ptr %r3146, align 4
  %r3148 = sitofp i32 %r3147 to double
  br label %tav.get.merge.630

tav.k.u32.637:                                    ; preds = %tav.kd5.644
  %r3150 = add nuw nsw i64 %r3111, 0
  %r3151 = inttoptr i64 %r3150 to ptr
  %r3152 = load i32, ptr %r3151, align 4
  %r3153 = uitofp i32 %r3152 to double
  br label %tav.get.merge.630

tav.k.f32.638:                                    ; preds = %tav.kd6.645
  %r3155 = add nuw nsw i64 %r3111, 0
  %r3156 = inttoptr i64 %r3155 to ptr
  %r3157 = load float, ptr %r3156, align 4
  %r3158 = fpext float %r3157 to double
  br label %tav.get.merge.630

tav.k.f64.639:                                    ; preds = %tav.kd7.646
  %r3160 = add nuw nsw i64 %r3111, 0
  %r3161 = inttoptr i64 %r3160 to ptr
  %r3162 = load double, ptr %r3161, align 8
  br label %tav.get.merge.630

tav.kd1.640:                                      ; preds = %tav.get.load.628
  %r3113 = icmp eq i64 %r3102, 1
  br i1 %r3113, label %tav.k.u8.633, label %tav.kd2.641

tav.kd2.641:                                      ; preds = %tav.kd1.640
  %r3114 = icmp eq i64 %r3102, 2
  br i1 %r3114, label %tav.k.i16.634, label %tav.kd3.642

tav.kd3.642:                                      ; preds = %tav.kd2.641
  %r3115 = icmp eq i64 %r3102, 3
  br i1 %r3115, label %tav.k.u16.635, label %tav.kd4.643

tav.kd4.643:                                      ; preds = %tav.kd3.642
  %r3116 = icmp eq i64 %r3102, 4
  br i1 %r3116, label %tav.k.i32.636, label %tav.kd5.644

tav.kd5.644:                                      ; preds = %tav.kd4.643
  %r3117 = icmp eq i64 %r3102, 5
  br i1 %r3117, label %tav.k.u32.637, label %tav.kd6.645

tav.kd6.645:                                      ; preds = %tav.kd5.644
  %r3118 = icmp eq i64 %r3102, 6
  br i1 %r3118, label %tav.k.f32.638, label %tav.kd7.646

tav.kd7.646:                                      ; preds = %tav.kd6.645
  %r3119 = icmp eq i64 %r3102, 7
  br i1 %r3119, label %tav.k.f64.639, label %tav.k.u8.633

arrlike.ic.header.647:                            ; preds = %tav.get.slow.629
  %r3181 = sub nuw nsw i64 %r3167, 8
  %r3182 = inttoptr i64 %r3181 to ptr
  %r3183 = load i8, ptr %r3182, align 1
  %r3185 = sub nuw nsw i64 %r3167, 7
  %r3186 = inttoptr i64 %r3185 to ptr
  %r3187 = load i8, ptr %r3186, align 1
  %r3188 = and i8 %r3187, -128
  %r3189 = icmp eq i8 %r3188, 0
  %r3190 = and i1 true, %r3189
  br i1 %r3190, label %arrlike.ic.brand.648, label %arrlike.ic.miss.666

arrlike.ic.brand.648:                             ; preds = %arrlike.ic.header.647
  %r3184 = icmp eq i8 %r3183, 1
  br i1 %r3184, label %arrlike.ic.array_guard.649, label %arrlike.elem.kind.667

arrlike.ic.array_guard.649:                       ; preds = %arrlike.ic.brand.648
  %r3222 = sub nuw nsw i64 %r3167, 6
  %r3223 = inttoptr i64 %r3222 to ptr
  %r3224 = load i16, ptr %r3223, align 2
  %r3225 = and i16 %r3224, 1024
  %r3226 = icmp eq i16 %r3225, 0
  %r3227 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3228 = icmp eq i8 %r3227, 0
  %r3229 = inttoptr i64 %r3167 to ptr
  %r3230 = load i32, ptr %r3229, align 4
  %r3231 = add nuw nsw i64 %r3167, 4
  %r3232 = inttoptr i64 %r3231 to ptr
  %r3233 = load i32, ptr %r3232, align 4
  %r3234 = zext i32 %r3230 to i64
  %r3235 = zext i32 %r3233 to i64
  %r3236 = icmp ult i64 0, %r3234
  %r3237 = icmp ule i64 %r3234, %r3235
  %r3238 = and i1 %r3226, %r3228
  %r3239 = and i1 %r3238, %r3236
  %r3240 = and i1 %r3239, %r3237
  br i1 %r3240, label %arrlike.ic.array_load.650, label %arrlike.ic.miss.666

arrlike.ic.array_load.650:                        ; preds = %arrlike.ic.array_guard.649
  %r3242 = getelementptr inbounds nuw i64, ptr %r3229, i64 1
  %r3243 = load double, ptr %r3242, align 8
  %r3244 = bitcast double %r3243 to i64
  %r3245 = icmp eq i64 %r3244, 9222246136947933200
  %r3247 = select i1 %r3245, double 0x7FFC000000000001, double %r3243
  br label %tav.get.merge.630

arrlike.ic.shape.651:                             ; preds = %arrlike.elem.store.669, %arrlike.elem.meta.668
  %r3249 = inttoptr i64 %r3167 to ptr
  %r3250 = load i32, ptr %r3249, align 4
  %r3251 = add nuw nsw i64 %r3167, 4
  %r3252 = inttoptr i64 %r3251 to ptr
  %r3253 = load i32, ptr %r3252, align 4
  %r3254 = zext i32 %r3250 to i64
  %r3255 = zext i32 %r3253 to i64
  %r3256 = shl nuw i64 %r3254, 32
  %r3257 = or i64 %r3256, %r3255
  %r3258 = getelementptr i64, ptr %r3165, i64 0
  %r3259 = load i64, ptr %r3258, align 8
  %r3260 = icmp ne i64 %r3259, 0
  %r3261 = and i1 true, %r3260
  br i1 %r3261, label %arrlike.ic.identity.652, label %arrlike.ic.miss.666

arrlike.ic.identity.652:                          ; preds = %arrlike.ic.shape.651
  %r3262 = and i64 %r3259, -9223372036854775808
  %2 = icmp slt i64 %r3259, 0
  br i1 %2, label %arrlike.ic.family_meta.654, label %arrlike.ic.exact.653

arrlike.ic.exact.653:                             ; preds = %arrlike.ic.identity.652
  %r3264 = icmp eq i64 %r3257, %r3259
  br i1 %r3264, label %arrlike.ic.bounds.656, label %arrlike.ic.miss.666

arrlike.ic.family_meta.654:                       ; preds = %arrlike.ic.identity.652
  %r3265 = add nuw nsw i64 %r3167, 8
  %r3266 = inttoptr i64 %r3265 to ptr
  %r3267 = load i64, ptr %r3266, align 8
  %r3268 = icmp ne i64 %r3267, 0
  br i1 %r3268, label %arrlike.ic.family_token.655, label %arrlike.ic.miss.666

arrlike.ic.family_token.655:                      ; preds = %arrlike.ic.family_meta.654
  %r3269 = inttoptr i64 %r3267 to ptr
  %r3270 = getelementptr i64, ptr %r3269, i64 6
  %r3271 = load i64, ptr %r3270, align 8
  %r3272 = icmp eq i64 %r3271, %r3259
  br i1 %r3272, label %arrlike.ic.bounds.656, label %arrlike.ic.miss.666

arrlike.ic.bounds.656:                            ; preds = %arrlike.ic.family_token.655, %arrlike.ic.exact.653
  %r3273 = getelementptr i64, ptr %r3163, i64 1
  %r3274 = load i64, ptr %r3273, align 8
  %r3275 = getelementptr i64, ptr %r3163, i64 2
  %r3276 = load i64, ptr %r3275, align 8
  %r3277 = getelementptr i64, ptr %r3163, i64 3
  %r3278 = load i64, ptr %r3277, align 8
  %r3279 = getelementptr i64, ptr %r3163, i64 4
  %r3280 = load i64, ptr %r3279, align 8
  %r3281 = icmp ult i64 %r3274, %r3280
  br i1 %r3281, label %arrlike.ic.length_inline.657, label %arrlike.ic.length_spill_meta.658

arrlike.ic.length_inline.657:                     ; preds = %arrlike.ic.bounds.656
  %r3282 = shl i64 %r3274, 3
  %r3283 = add i64 %r3282, 16
  %r3284 = add i64 %r3167, %r3283
  %r3285 = inttoptr i64 %r3284 to ptr
  %r3286 = load double, ptr %r3285, align 8
  br label %arrlike.ic.range.661

arrlike.ic.length_spill_meta.658:                 ; preds = %arrlike.ic.bounds.656
  %r3287 = add nuw nsw i64 %r3167, 8
  %r3288 = inttoptr i64 %r3287 to ptr
  %r3289 = load i64, ptr %r3288, align 8
  %r3290 = icmp ne i64 %r3289, 0
  br i1 %r3290, label %arrlike.ic.length_spill_ptr.659, label %arrlike.ic.miss.666

arrlike.ic.length_spill_ptr.659:                  ; preds = %arrlike.ic.length_spill_meta.658
  %r3291 = inttoptr i64 %r3289 to ptr
  %r3292 = getelementptr i64, ptr %r3291, i64 4
  %r3293 = load i64, ptr %r3292, align 8
  %r3294 = icmp ne i64 %r3293, 0
  %r3295 = select i1 %r3294, i64 %r3293, i64 %r3289
  %r3296 = inttoptr i64 %r3295 to ptr
  %r3297 = load i32, ptr %r3296, align 4
  %r3298 = zext i32 %r3297 to i64
  %r3299 = icmp ult i64 %r3274, %r3298
  %r3300 = and i1 %r3294, %r3299
  br i1 %r3300, label %arrlike.ic.length_spill_load.660, label %arrlike.ic.miss.666

arrlike.ic.length_spill_load.660:                 ; preds = %arrlike.ic.length_spill_ptr.659
  %r3301 = add nuw nsw i64 %r3274, 1
  %r3302 = getelementptr inbounds nuw i64, ptr %r3296, i64 %r3301
  %r3303 = load double, ptr %r3302, align 8
  br label %arrlike.ic.range.661

arrlike.ic.range.661:                             ; preds = %arrlike.ic.length_spill_load.660, %arrlike.ic.length_inline.657
  %r3304 = phi double [ %r3286, %arrlike.ic.length_inline.657 ], [ %r3303, %arrlike.ic.length_spill_load.660 ]
  %r3305 = fcmp olt double 0.000000e+00, %r3304
  %r3306 = icmp ult i64 0, %r3278
  %r3307 = and i1 %r3305, %r3306
  %r3308 = add nuw nsw i64 %r3276, 0
  %r3309 = icmp ult i64 %r3308, %r3280
  %r3310 = and i1 %r3307, %r3309
  %r3311 = xor i1 %r3309, true
  %r3312 = and i1 %r3307, %r3311
  br i1 %r3310, label %arrlike.ic.inline.662, label %arrlike.ic.spill_or_miss.673

arrlike.ic.inline.662:                            ; preds = %arrlike.ic.range.661
  %r3313 = shl i64 %r3308, 3
  %r3314 = add i64 %r3313, 16
  %r3315 = add i64 %r3167, %r3314
  %r3316 = inttoptr i64 %r3315 to ptr
  %r3317 = load double, ptr %r3316, align 8
  br label %tav.get.merge.630

arrlike.ic.spill.663:                             ; preds = %arrlike.ic.spill_or_miss.673
  %r3318 = add nuw nsw i64 %r3167, 8
  %r3319 = inttoptr i64 %r3318 to ptr
  %r3320 = load i64, ptr %r3319, align 8
  %r3321 = icmp ne i64 %r3320, 0
  br i1 %r3321, label %arrlike.ic.spill_ptr.664, label %arrlike.ic.miss.666

arrlike.ic.spill_ptr.664:                         ; preds = %arrlike.ic.spill.663
  %r3322 = inttoptr i64 %r3320 to ptr
  %r3323 = getelementptr i64, ptr %r3322, i64 4
  %r3324 = load i64, ptr %r3323, align 8
  %r3325 = icmp ne i64 %r3324, 0
  %r3326 = select i1 %r3325, i64 %r3324, i64 %r3320
  %r3327 = inttoptr i64 %r3326 to ptr
  %r3328 = load i32, ptr %r3327, align 4
  %r3329 = zext i32 %r3328 to i64
  %r3330 = icmp ult i64 %r3308, %r3329
  %r3331 = and i1 %r3325, %r3330
  br i1 %r3331, label %arrlike.ic.spill_load.665, label %arrlike.ic.miss.666

arrlike.ic.spill_load.665:                        ; preds = %arrlike.ic.spill_ptr.664
  %r3332 = add nuw nsw i64 %r3308, 1
  %r3333 = getelementptr inbounds nuw i64, ptr %r3327, i64 %r3332
  %r3334 = load double, ptr %r3333, align 8
  br label %tav.get.merge.630

arrlike.ic.miss.666:                              ; preds = %arrlike.ic.spill_or_miss.673, %arrlike.elem.load.671, %arrlike.elem.bounds.670, %arrlike.elem.kind.667, %arrlike.ic.spill_ptr.664, %arrlike.ic.spill.663, %arrlike.ic.length_spill_ptr.659, %arrlike.ic.length_spill_meta.658, %arrlike.ic.family_token.655, %arrlike.ic.family_meta.654, %arrlike.ic.exact.653, %arrlike.ic.shape.651, %arrlike.ic.array_guard.649, %arrlike.ic.header.647, %tav.get.slow.629
  %statepoint_token857 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r3069, double 0.000000e+00, ptr @perry_ic_test_json_template_capture_ts__33, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.371010, ptr addrspace(1) %.48, ptr addrspace(1) %.11192, ptr addrspace(1) %.371051) ]
  %r3335858 = call double @llvm.experimental.gc.result.f64(token %statepoint_token857)
  %r48.0.base.relocated859 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token857, i32 0, i32 0) ; (%.371010, %.371010)
  %r57.0.relocated860 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token857, i32 1, i32 1) ; (%.48, %.48)
  %rs4gc.s40.relocated861 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token857, i32 2, i32 2) ; (%.11192, %.11192)
  %r48.0.relocated862 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token857, i32 0, i32 3) ; (%.371010, %.371051)
  br label %tav.get.merge.630

arrlike.elem.kind.667:                            ; preds = %arrlike.ic.brand.648
  %r3191 = icmp eq i8 %r3183, 2
  br i1 %r3191, label %arrlike.elem.meta.668, label %arrlike.ic.miss.666

arrlike.elem.meta.668:                            ; preds = %arrlike.elem.kind.667
  %r3192 = add nuw nsw i64 %r3167, 8
  %r3193 = inttoptr i64 %r3192 to ptr
  %r3194 = load i64, ptr %r3193, align 8
  %r3195 = icmp ne i64 %r3194, 0
  br i1 %r3195, label %arrlike.elem.store.669, label %arrlike.ic.shape.651

arrlike.elem.store.669:                           ; preds = %arrlike.elem.meta.668
  %r3196 = inttoptr i64 %r3194 to ptr
  %r3197 = getelementptr i64, ptr %r3196, i64 12
  %r3198 = load i64, ptr %r3197, align 8
  %r3199 = icmp ne i64 %r3198, 0
  br i1 %r3199, label %arrlike.elem.bounds.670, label %arrlike.ic.shape.651

arrlike.elem.bounds.670:                          ; preds = %arrlike.elem.store.669
  %r3200 = sub i64 %r3198, 8
  %r3201 = inttoptr i64 %r3200 to ptr
  %r3202 = load i8, ptr %r3201, align 1
  %r3203 = icmp eq i8 %r3202, 1
  %r3204 = sub i64 %r3198, 7
  %r3205 = inttoptr i64 %r3204 to ptr
  %r3206 = load i8, ptr %r3205, align 1
  %r3207 = and i8 %r3206, -128
  %r3208 = icmp eq i8 %r3207, 0
  %r3209 = inttoptr i64 %r3198 to ptr
  %r3210 = load i32, ptr %r3209, align 4
  %r3211 = zext i32 %r3210 to i64
  %r3212 = icmp ult i64 0, %r3211
  %r3213 = and i1 %r3203, %r3208
  %r3214 = and i1 %r3213, %r3212
  br i1 %r3214, label %arrlike.elem.load.671, label %arrlike.ic.miss.666

arrlike.elem.load.671:                            ; preds = %arrlike.elem.bounds.670
  %r3216 = add i64 %r3198, 8
  %r3217 = add nuw nsw i64 %r3216, 0
  %r3218 = inttoptr i64 %r3217 to ptr
  %r3219 = load double, ptr %r3218, align 8
  %r3220 = bitcast double %r3219 to i64
  %r3221 = icmp eq i64 %r3220, 9222246136947933200
  br i1 %r3221, label %arrlike.ic.miss.666, label %arrlike.elem.value.672

arrlike.elem.value.672:                           ; preds = %arrlike.elem.load.671
  br label %tav.get.merge.630

arrlike.ic.spill_or_miss.673:                     ; preds = %arrlike.ic.range.661
  br i1 %r3312, label %arrlike.ic.spill.663, label %arrlike.ic.miss.666

shadow.root.barrier.674:                          ; preds = %tav.get.merge.630
  call void @js_write_barrier_root_nanbox(i64 %r3339) #7
  br label %shadow.root.barrier.done.675

shadow.root.barrier.done.675:                     ; preds = %shadow.root.barrier.674, %tav.get.merge.630
  %r3342.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s41 to i64
  %r3342 = call i64 asm "", "=r,0"(i64 %r3342.rs4i) #7
  %statepoint_token863 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r3342, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.base.relocated854, ptr addrspace(1) %r57.0.relocated855, ptr addrspace(1) %r48.0.relocated856) ]
  %r48.0.base.relocated864 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token863, i32 0, i32 0) ; (%r48.0.base.relocated854, %r48.0.base.relocated854)
  %r57.0.relocated865 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token863, i32 1, i32 1) ; (%r57.0.relocated855, %r57.0.relocated855)
  %r48.0.relocated866 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token863, i32 0, i32 2) ; (%r48.0.base.relocated854, %r48.0.relocated856)
  %r3343 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r3344 = icmp ne i32 %r3343, 0
  br i1 %r3344, label %gcpoll.676, label %gcpoll.done.677

gcpoll.676:                                       ; preds = %shadow.root.barrier.done.675
  %statepoint_token867 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.base.relocated864, ptr addrspace(1) %r57.0.relocated865, ptr addrspace(1) %r48.0.relocated866) ]
  %r48.0.base.relocated868 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token867, i32 0, i32 0) ; (%r48.0.base.relocated864, %r48.0.base.relocated864)
  %r57.0.relocated869 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token867, i32 1, i32 1) ; (%r57.0.relocated865, %r57.0.relocated865)
  %r48.0.relocated870 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token867, i32 0, i32 2) ; (%r48.0.base.relocated864, %r48.0.relocated866)
  br label %gcpoll.done.677

gcpoll.done.677:                                  ; preds = %gcpoll.676, %shadow.root.barrier.done.675
  %.401054 = phi ptr addrspace(1) [ %r48.0.relocated870, %gcpoll.676 ], [ %r48.0.relocated866, %shadow.root.barrier.done.675 ]
  %.401013 = phi ptr addrspace(1) [ %r48.0.base.relocated868, %gcpoll.676 ], [ %r48.0.base.relocated864, %shadow.root.barrier.done.675 ]
  %.51 = phi ptr addrspace(1) [ %r57.0.relocated869, %gcpoll.676 ], [ %r57.0.relocated865, %shadow.root.barrier.done.675 ]
  br label %for.update.487

shadow.root.barrier.678:                          ; preds = %for.exit.488
  call void @js_write_barrier_root_nanbox(i64 %r3350) #7
  br label %shadow.root.barrier.done.679

shadow.root.barrier.done.679:                     ; preds = %shadow.root.barrier.678, %for.exit.488
  %r3353 = load double, ptr @test_json_template_capture_ts_.str.18.handle, align 8
  %r3354.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s34 to i64
  %r3354 = call i64 asm "", "=r,0"(i64 %r3354.rs4i) #7
  %statepoint_token871 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3354, double %r3353, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.relocated703, ptr addrspace(1) %r48.0.base.relocated704, ptr addrspace(1) %r57.0.relocated705) ]
  %r3355872 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token871)
  %r48.0.relocated873 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token871, i32 1, i32 0) ; (%r48.0.base.relocated704, %r48.0.relocated703)
  %r48.0.base.relocated874 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token871, i32 1, i32 1) ; (%r48.0.base.relocated704, %r48.0.base.relocated704)
  %r57.0.relocated875 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token871, i32 2, i32 2) ; (%r57.0.relocated705, %r57.0.relocated705)
  %rs4gc.s42 = inttoptr i64 %r3355872 to ptr addrspace(1)
  %r3356.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s42 to i64
  %r3356 = call i64 asm "", "=r,0"(i64 %r3356.rs4i) #7
  %r3357 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3358 = icmp ne i32 %r3357, 0
  br i1 %r3358, label %shadow.root.barrier.680, label %shadow.root.barrier.done.681

shadow.root.barrier.680:                          ; preds = %shadow.root.barrier.done.679
  call void @js_write_barrier_root_nanbox(i64 %r3356) #7
  br label %shadow.root.barrier.done.681

shadow.root.barrier.done.681:                     ; preds = %shadow.root.barrier.680, %shadow.root.barrier.done.679
  %r3359.rs4i = ptrtoint ptr addrspace(1) %r57.0.relocated875 to i64
  %r3359.rs4o = call i64 asm "", "=r,0"(i64 %r3359.rs4i) #7
  %r3359 = bitcast i64 %r3359.rs4o to double
  %r3360.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s42 to i64
  %r3360 = call i64 asm "", "=r,0"(i64 %r3360.rs4i) #7
  %statepoint_token876 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3360, double %r3359, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.relocated873, ptr addrspace(1) %r48.0.base.relocated874) ]
  %r3361877 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token876)
  %r48.0.relocated878 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token876, i32 1, i32 0) ; (%r48.0.base.relocated874, %r48.0.relocated873)
  %r48.0.base.relocated879 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token876, i32 1, i32 1) ; (%r48.0.base.relocated874, %r48.0.base.relocated874)
  %rs4gc.s43 = inttoptr i64 %r3361877 to ptr addrspace(1)
  %r3362.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s43 to i64
  %r3362 = call i64 asm "", "=r,0"(i64 %r3362.rs4i) #7
  %r3363 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3364 = icmp ne i32 %r3363, 0
  br i1 %r3364, label %shadow.root.barrier.682, label %shadow.root.barrier.done.683

shadow.root.barrier.682:                          ; preds = %shadow.root.barrier.done.681
  call void @js_write_barrier_root_nanbox(i64 %r3362) #7
  br label %shadow.root.barrier.done.683

shadow.root.barrier.done.683:                     ; preds = %shadow.root.barrier.682, %shadow.root.barrier.done.681
  %r3365.rs4i = ptrtoint ptr addrspace(1) %r48.0.relocated878 to i64
  %r3365.rs4o = call i64 asm "", "=r,0"(i64 %r3365.rs4i) #7
  %r3365 = bitcast i64 %r3365.rs4o to double
  %r3366 = bitcast double %r3365 to i64
  %r3367 = and i64 %r3366, 281474976710655
  %r3368 = lshr i64 %r3366, 48
  %r3369 = and i64 %r3368, 65533
  %r3370 = icmp eq i64 %r3369, 32765
  %r3371 = icmp ugt i64 %r3367, 1048575
  %r3372 = and i1 %r3370, %r3371
  br i1 %r3372, label %plen.check_gc.684, label %plen.slow.686

plen.check_gc.684:                                ; preds = %shadow.root.barrier.done.683
  %r3373 = sub nuw nsw i64 %r3367, 8
  %r3374 = inttoptr i64 %r3373 to ptr
  %r3375 = load i8, ptr %r3374, align 1
  %r3376 = icmp eq i8 %r3375, 1
  %r3377 = icmp eq i8 %r3375, 3
  %r3378 = or i1 %r3376, %r3377
  %r3379 = sub nuw nsw i64 %r3367, 7
  %r3380 = inttoptr i64 %r3379 to ptr
  %r3381 = load i8, ptr %r3380, align 1
  %r3382 = and i8 %r3381, -128
  %r3383 = icmp eq i8 %r3382, 0
  %r3384 = and i1 %r3378, %r3383
  br i1 %r3384, label %plen.fast.685, label %plen.slow.686

plen.fast.685:                                    ; preds = %plen.check_gc.684
  %r3386 = inttoptr i64 %r3367 to ptr
  %r3387 = select i1 false, ptr @perry_null_guard_zero_test_json_template_capture_ts, ptr %r3386
  %r3388 = load i32, ptr %r3387, align 4
  %r3389 = uitofp i32 %r3388 to double
  br label %plen.merge.687

plen.slow.686:                                    ; preds = %plen.check_gc.684, %shadow.root.barrier.done.683
  %r3390 = lshr i64 %r3366, 48
  %r3391 = icmp eq i64 %r3390, 32765
  %r3392 = icmp uge i64 %r3367, 2199023255552
  %r3393 = icmp ult i64 %r3367, 140737488355328
  %r3394 = and i1 %r3391, %r3392
  %r3395 = and i1 %r3394, %r3393
  %r3396 = load ptr, ptr @perry_ic_test_json_template_capture_ts__34, align 8
  br i1 %r3395, label %plen.ic.header.688, label %plen.ic.miss.700

plen.merge.687:                                   ; preds = %plen.ic.merge.701, %plen.fast.685
  %.01195 = phi ptr addrspace(1) [ %rs4gc.s43, %plen.fast.685 ], [ %.11196, %plen.ic.merge.701 ]
  %r3471 = phi double [ %r3389, %plen.fast.685 ], [ %r3470, %plen.ic.merge.701 ]
  %r3472.rs4i = ptrtoint ptr addrspace(1) %.01195 to i64
  %r3472 = call i64 asm "", "=r,0"(i64 %r3472.rs4i) #7
  %statepoint_token880 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3472, double %r3471, i32 0, i32 0)
  %r3473881 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token880)
  %rs4gc.s44 = inttoptr i64 %r3473881 to ptr addrspace(1)
  %r3474.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s44 to i64
  %r3474 = call i64 asm "", "=r,0"(i64 %r3474.rs4i) #7
  %r3475 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3476 = icmp ne i32 %r3475, 0
  br i1 %r3476, label %shadow.root.barrier.705, label %shadow.root.barrier.done.706

plen.ic.header.688:                               ; preds = %plen.slow.686
  %r3398 = sub nuw nsw i64 %r3367, 8
  %r3399 = inttoptr i64 %r3398 to ptr
  %r3400 = load i8, ptr %r3399, align 1
  %r3401 = icmp eq i8 %r3400, 2
  %r3402 = sub nuw nsw i64 %r3367, 7
  %r3403 = inttoptr i64 %r3402 to ptr
  %r3404 = load i8, ptr %r3403, align 1
  %r3405 = and i8 %r3404, -128
  %r3406 = icmp eq i8 %r3405, 0
  %r3407 = and i1 %r3401, %r3406
  br i1 %r3407, label %plen.elem.meta.702, label %plen.ic.miss.700

plen.ic.shape.689:                                ; preds = %plen.elem.store.703, %plen.elem.meta.702
  %r3397 = icmp ne ptr %r3396, null
  br i1 %r3397, label %plen.ic.shape.probe.690, label %plen.ic.miss.700

plen.ic.shape.probe.690:                          ; preds = %plen.ic.shape.689
  %r3419 = inttoptr i64 %r3367 to ptr
  %r3420 = load i32, ptr %r3419, align 4
  %r3421 = add nuw nsw i64 %r3367, 4
  %r3422 = inttoptr i64 %r3421 to ptr
  %r3423 = load i32, ptr %r3422, align 4
  %r3424 = zext i32 %r3420 to i64
  %r3425 = zext i32 %r3423 to i64
  %r3426 = shl nuw i64 %r3424, 32
  %r3427 = or i64 %r3426, %r3425
  %r3428 = getelementptr i64, ptr %r3396, i64 0
  %r3429 = load i64, ptr %r3428, align 8
  %r3430 = icmp ne i64 %r3429, 0
  br i1 %r3430, label %plen.ic.identity.691, label %plen.ic.miss.700

plen.ic.identity.691:                             ; preds = %plen.ic.shape.probe.690
  %r3431 = and i64 %r3429, -9223372036854775808
  %3 = icmp slt i64 %r3429, 0
  br i1 %3, label %plen.ic.family_meta.693, label %plen.ic.exact.692

plen.ic.exact.692:                                ; preds = %plen.ic.identity.691
  %r3433 = icmp eq i64 %r3427, %r3429
  br i1 %r3433, label %plen.ic.slot.695, label %plen.ic.miss.700

plen.ic.family_meta.693:                          ; preds = %plen.ic.identity.691
  %r3434 = add nuw nsw i64 %r3367, 8
  %r3435 = inttoptr i64 %r3434 to ptr
  %r3436 = load i64, ptr %r3435, align 8
  %r3437 = icmp ne i64 %r3436, 0
  br i1 %r3437, label %plen.ic.family_token.694, label %plen.ic.miss.700

plen.ic.family_token.694:                         ; preds = %plen.ic.family_meta.693
  %r3438 = inttoptr i64 %r3436 to ptr
  %r3439 = getelementptr i64, ptr %r3438, i64 6
  %r3440 = load i64, ptr %r3439, align 8
  %r3441 = icmp eq i64 %r3440, %r3429
  br i1 %r3441, label %plen.ic.slot.695, label %plen.ic.miss.700

plen.ic.slot.695:                                 ; preds = %plen.ic.family_token.694, %plen.ic.exact.692
  %r3442 = getelementptr i64, ptr %r3396, i64 1
  %r3443 = load i64, ptr %r3442, align 8
  %r3444 = getelementptr i64, ptr %r3396, i64 2
  %r3445 = load i64, ptr %r3444, align 8
  %r3446 = icmp ult i64 %r3443, %r3445
  br i1 %r3446, label %plen.ic.inline.696, label %plen.ic.spill_meta.697

plen.ic.inline.696:                               ; preds = %plen.ic.slot.695
  %r3447 = shl i64 %r3443, 3
  %r3448 = add i64 %r3447, 16
  %r3449 = add i64 %r3367, %r3448
  %r3450 = inttoptr i64 %r3449 to ptr
  %r3451 = load double, ptr %r3450, align 8
  br label %plen.ic.merge.701

plen.ic.spill_meta.697:                           ; preds = %plen.ic.slot.695
  %r3452 = add nuw nsw i64 %r3367, 8
  %r3453 = inttoptr i64 %r3452 to ptr
  %r3454 = load i64, ptr %r3453, align 8
  %r3455 = icmp ne i64 %r3454, 0
  br i1 %r3455, label %plen.ic.spill_ptr.698, label %plen.ic.miss.700

plen.ic.spill_ptr.698:                            ; preds = %plen.ic.spill_meta.697
  %r3456 = inttoptr i64 %r3454 to ptr
  %r3457 = getelementptr i64, ptr %r3456, i64 4
  %r3458 = load i64, ptr %r3457, align 8
  %r3459 = icmp ne i64 %r3458, 0
  %r3460 = select i1 %r3459, i64 %r3458, i64 %r3454
  %r3461 = inttoptr i64 %r3460 to ptr
  %r3462 = load i32, ptr %r3461, align 4
  %r3463 = zext i32 %r3462 to i64
  %r3464 = icmp ult i64 %r3443, %r3463
  %r3465 = and i1 %r3459, %r3464
  br i1 %r3465, label %plen.ic.spill_load.699, label %plen.ic.miss.700

plen.ic.spill_load.699:                           ; preds = %plen.ic.spill_ptr.698
  %r3466 = add nuw nsw i64 %r3443, 1
  %r3467 = getelementptr inbounds nuw i64, ptr %r3461, i64 %r3466
  %r3468 = load double, ptr %r3467, align 8
  br label %plen.ic.merge.701

plen.ic.miss.700:                                 ; preds = %plen.ic.spill_ptr.698, %plen.ic.spill_meta.697, %plen.ic.family_token.694, %plen.ic.family_meta.693, %plen.ic.exact.692, %plen.ic.shape.probe.690, %plen.ic.shape.689, %plen.ic.header.688, %plen.slow.686
  %statepoint_token882 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r3365, ptr @perry_ic_test_json_template_capture_ts__34, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s43) ]
  %r3469883 = call double @llvm.experimental.gc.result.f64(token %statepoint_token882)
  %rs4gc.s43.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token882, i32 0, i32 0) ; (%rs4gc.s43, %rs4gc.s43)
  br label %plen.ic.merge.701

plen.ic.merge.701:                                ; preds = %plen.elem.length.704, %plen.ic.miss.700, %plen.ic.spill_load.699, %plen.ic.inline.696
  %.11196 = phi ptr addrspace(1) [ %rs4gc.s43, %plen.elem.length.704 ], [ %rs4gc.s43, %plen.ic.inline.696 ], [ %rs4gc.s43, %plen.ic.spill_load.699 ], [ %rs4gc.s43.relocated, %plen.ic.miss.700 ]
  %r3470 = phi double [ %r3418, %plen.elem.length.704 ], [ %r3451, %plen.ic.inline.696 ], [ %r3468, %plen.ic.spill_load.699 ], [ %r3469883, %plen.ic.miss.700 ]
  br label %plen.merge.687

plen.elem.meta.702:                               ; preds = %plen.ic.header.688
  %r3408 = add nuw nsw i64 %r3367, 8
  %r3409 = inttoptr i64 %r3408 to ptr
  %r3410 = load i64, ptr %r3409, align 8
  %r3411 = icmp ne i64 %r3410, 0
  br i1 %r3411, label %plen.elem.store.703, label %plen.ic.shape.689

plen.elem.store.703:                              ; preds = %plen.elem.meta.702
  %r3412 = inttoptr i64 %r3410 to ptr
  %r3413 = getelementptr i64, ptr %r3412, i64 12
  %r3414 = load i64, ptr %r3413, align 8
  %r3415 = icmp ne i64 %r3414, 0
  br i1 %r3415, label %plen.elem.length.704, label %plen.ic.shape.689

plen.elem.length.704:                             ; preds = %plen.elem.store.703
  %r3416 = inttoptr i64 %r3414 to ptr
  %r3417 = load i32, ptr %r3416, align 4
  %r3418 = uitofp i32 %r3417 to double
  br label %plen.ic.merge.701

shadow.root.barrier.705:                          ; preds = %plen.merge.687
  call void @js_write_barrier_root_nanbox(i64 %r3474) #7
  br label %shadow.root.barrier.done.706

shadow.root.barrier.done.706:                     ; preds = %shadow.root.barrier.705, %plen.merge.687
  %r3477.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s44 to i64
  %r3477 = call i64 asm "", "=r,0"(i64 %r3477.rs4i) #7
  %statepoint_token884 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r3477, i32 0, i32 0)
  %statepoint_token885 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token886 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token887 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token888 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token889 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.707

event_loop.header.707:                            ; preds = %event_loop.body_wait.712, %event_loop.body_check.711, %shadow.root.barrier.done.706
  %statepoint_token890 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r3482891 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token890)
  %r3483 = icmp ne i32 %r3482891, 0
  br i1 %r3483, label %event_loop.host_return.709, label %event_loop.check_pending.708

event_loop.check_pending.708:                     ; preds = %event_loop.header.707
  %statepoint_token892 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r3484893 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token892)
  %statepoint_token894 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r3485895 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token894)
  %statepoint_token896 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r3486897 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token896)
  %statepoint_token898 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r3487899 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token898)
  %statepoint_token900 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r3488901 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token900)
  %statepoint_token902 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r3489903 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token902)
  %r3490 = or i32 %r3484893, %r3485895
  %r3491 = or i32 %r3486897, %r3487899
  %r3492 = or i32 %r3491, %r3488901
  %r3493 = or i32 %r3490, %r3492
  %r3494 = or i32 %r3493, 0
  %r3495 = or i32 %r3494, %r3489903
  %r3496 = icmp ne i32 %r3495, 0
  br i1 %r3496, label %event_loop.body.710, label %event_loop.exit.713

event_loop.host_return.709:                       ; preds = %event_loop.header.707
  call void @js_typed_feedback_maybe_dump_trace() #7
  ret i32 0

event_loop.body.710:                              ; preds = %event_loop.check_pending.708
  %statepoint_token904 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token905 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.711

event_loop.body_check.711:                        ; preds = %event_loop.body.710
  %statepoint_token906 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r3498907 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token906)
  %statepoint_token908 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r3499909 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token908)
  %statepoint_token910 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r3500911 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token910)
  %statepoint_token912 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r3501913 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token912)
  %statepoint_token914 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r3502915 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token914)
  %statepoint_token916 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r3503917 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token916)
  %r3504 = or i32 %r3498907, %r3499909
  %r3505 = or i32 %r3500911, %r3501913
  %r3506 = or i32 %r3505, %r3502915
  %r3507 = or i32 %r3504, %r3506
  %r3508 = or i32 %r3507, 0
  %r3509 = or i32 %r3508, %r3503917
  %r3510 = icmp ne i32 %r3509, 0
  br i1 %r3510, label %event_loop.body_wait.712, label %event_loop.header.707

event_loop.body_wait.712:                         ; preds = %event_loop.body_check.711
  %statepoint_token918 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.707

event_loop.exit.713:                              ; preds = %event_loop.check_pending.708
  %statepoint_token919 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token920 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token921 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token922 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token923 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token924 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token925 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token926 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token927 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r3513928 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token927)
  call void @js_typed_feedback_maybe_dump_trace() #7
  ret i32 %r3513928
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_template_capture_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.0.bytes, i32 5)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @test_json_template_capture_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.1.bytes, i32 8)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @test_json_template_capture_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.2.bytes, i32 2)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @test_json_template_capture_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.3.bytes, i32 4)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @test_json_template_capture_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.4.bytes, i32 106)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @test_json_template_capture_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.5.bytes, i32 107)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @test_json_template_capture_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.6.bytes, i32 109)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @test_json_template_capture_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.7.bytes, i32 104)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @test_json_template_capture_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.7.handle to i64))
  %r25 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.8.bytes, i32 31)
  %r26 = call double @js_nanbox_string(i64 %r25)
  store double %r26, ptr @test_json_template_capture_ts_.str.8.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.8.handle to i64))
  %r28 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.9.bytes, i32 5)
  %r29 = call double @js_nanbox_string(i64 %r28)
  store double %r29, ptr @test_json_template_capture_ts_.str.9.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.9.handle to i64))
  %r31 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.10.bytes, i32 7)
  %r32 = call double @js_nanbox_string(i64 %r31)
  store double %r32, ptr @test_json_template_capture_ts_.str.10.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.10.handle to i64))
  %r34 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.11.bytes, i32 4)
  %r35 = call double @js_nanbox_string(i64 %r34)
  store double %r35, ptr @test_json_template_capture_ts_.str.11.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.11.handle to i64))
  %r37 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.12.bytes, i32 6)
  %r38 = call double @js_nanbox_string(i64 %r37)
  store double %r38, ptr @test_json_template_capture_ts_.str.12.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.12.handle to i64))
  %r40 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.13.bytes, i32 31)
  %r41 = call double @js_nanbox_string(i64 %r40)
  store double %r41, ptr @test_json_template_capture_ts_.str.13.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.13.handle to i64))
  %r43 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.14.bytes, i32 23)
  %r44 = call double @js_nanbox_string(i64 %r43)
  store double %r44, ptr @test_json_template_capture_ts_.str.14.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.14.handle to i64))
  %r46 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.15.bytes, i32 9)
  %r47 = call double @js_nanbox_string(i64 %r46)
  store double %r47, ptr @test_json_template_capture_ts_.str.15.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.15.handle to i64))
  %r49 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.16.bytes, i32 22)
  %r50 = call double @js_nanbox_string(i64 %r49)
  store double %r50, ptr @test_json_template_capture_ts_.str.16.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.16.handle to i64))
  %r52 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.17.bytes, i32 5)
  %r53 = call double @js_nanbox_string(i64 %r52)
  store double %r53, ptr @test_json_template_capture_ts_.str.17.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.17.handle to i64))
  %r55 = call i64 @js_string_from_bytes(ptr @test_json_template_capture_ts_.str.18.bytes, i32 4)
  %r56 = call double @js_nanbox_string(i64 %r55)
  store double %r56, ptr @test_json_template_capture_ts_.str.18.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_template_capture_ts_.str.18.handle to i64))
  call void @js_register_function_name_static(ptr @test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18_constructor, ptr @test_json_template_capture_ts_.str.1, i32 32)
  call void @js_register_function_name_static(ptr @test_json_template_capture_ts____AnonShape_570a27fd5b93ea38_constructor, ptr @test_json_template_capture_ts_.str.2, i32 32)
  %r58 = call i64 @js_build_class_keys_array(i32 1, i32 2, ptr @perry_class_keys_packed_test_json_template_capture_ts__0, i32 15)
  store i64 %r58, ptr @perry_class_keys_test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18, align 8
  call void @js_write_barrier_root_heap_word(i64 %r58)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18 to i64))
  %r60 = call i32 @js_gc_typed_shape_id_for_keys(i32 1, i64 %r58, i32 2, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18, i32 1)
  store i32 %r60, ptr @perry_class_shape_id_test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18, align 4
  %r61 = zext i32 %r60 to i64
  %r62 = shl nuw i64 %r61, 32
  %r63 = or i64 %r62, 1
  %r64 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r63, i32 1
  store <2 x i64> %r64, ptr @perry_class_header_image_test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18, align 8
  %r65 = call i64 @js_build_class_keys_array(i32 2, i32 2, ptr @perry_class_keys_packed_test_json_template_capture_ts__1, i32 8)
  store i64 %r65, ptr @perry_class_keys_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38, align 8
  call void @js_write_barrier_root_heap_word(i64 %r65)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38 to i64))
  %r67 = call i32 @js_gc_typed_shape_id_for_keys(i32 2, i64 %r65, i32 2, ptr @perry_typed_shape_raw_f64_mask_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38, i32 1, ptr @perry_typed_shape_mask_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38, i32 1)
  store i32 %r67, ptr @perry_class_shape_id_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38, align 4
  %r68 = zext i32 %r67 to i64
  %r69 = shl nuw i64 %r68, 32
  %r70 = or i64 %r69, 2
  %r71 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r70, i32 1
  store <2 x i64> %r71, ptr @perry_class_header_image_test_json_template_capture_ts____AnonShape_570a27fd5b93ea38, align 8
  call void @js_register_class_constructor(i64 1, i64 ptrtoint (ptr @test_json_template_capture_ts____AnonShape_a0fce79cb5df4a18_constructor to i64), i64 2, i64 0)
  call void @js_register_class_constructor(i64 2, i64 ptrtoint (ptr @test_json_template_capture_ts____AnonShape_570a27fd5b93ea38_constructor to i64), i64 2, i64 0)
  call void @js_register_class_id(i32 1)
  call void @js_register_class_id(i32 2)
  call void @js_register_anon_shape_class_id(i32 1)
  call void @js_register_anon_shape_class_id(i32 2)
  call void @js_register_class_length(i32 1, i32 2)
  call void @js_register_class_length(i32 2, i32 2)
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_template_capture_ts() #6 {
entry.0:
  call void @__perry_init_strings_test_json_template_capture_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { "gc-leaf-function" }

!0 = !{}
