
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/native-vector-escape-r40/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100848dd4 <_js_json_parse>:
100848dd4:     	stp	x29, x30, [sp, #-0x10]!
100848dd8:     	mov	x29, sp
100848ddc:     	cbz	x0, 0x100848e34 <_js_json_parse+0x60>
100848de0:     	ldr	w1, [x0, #0x4]
100848de4:     	cmp	w1, #0x2
100848de8:     	b.eq	0x100848df8 <_js_json_parse+0x24>
100848dec:     	cbz	w1, 0x100848e34 <_js_json_parse+0x60>
100848df0:     	ldrb	w8, [x0, #0x14]
100848df4:     	b	0x100848e18 <_js_json_parse+0x44>
100848df8:     	ldrb	w8, [x0, #0x14]
100848dfc:     	cmp	w8, #0x7b
100848e00:     	b.ne	0x100848e18 <_js_json_parse+0x44>
100848e04:     	ldrb	w8, [x0, #0x15]
100848e08:     	cmp	w8, #0x7d
100848e0c:     	b.ne	0x100848e24 <_js_json_parse+0x50>
100848e10:     	ldp	x29, x30, [sp], #0x10
100848e14:     	b	0x1004ef3c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100848e18:     	orr	w8, w8, #0x20
100848e1c:     	cmp	w8, #0x7b
100848e20:     	b.ne	0x100848e2c <_js_json_parse+0x58>
100848e24:     	ldp	x29, x30, [sp], #0x10
100848e28:     	b	0x100508b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
100848e2c:     	ldp	x29, x30, [sp], #0x10
100848e30:     	b	0x10050b2cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100848e34:     	adrp	x0, 0x100c7a000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x7194>
100848e38:     	add	x0, x0, #0x2fd
100848e3c:     	mov	w1, #0x1c               ; =28
100848e40:     	bl	0x10050b700 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
