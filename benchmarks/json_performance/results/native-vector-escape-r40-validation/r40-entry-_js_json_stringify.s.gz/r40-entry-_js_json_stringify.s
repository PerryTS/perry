
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/native-vector-escape-r40/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100849aec <_js_json_stringify>:
100849aec:     	sub	sp, sp, #0x80
100849af0:     	stp	d9, d8, [sp, #0x20]
100849af4:     	stp	x26, x25, [sp, #0x30]
100849af8:     	stp	x24, x23, [sp, #0x40]
100849afc:     	stp	x22, x21, [sp, #0x50]
100849b00:     	stp	x20, x19, [sp, #0x60]
100849b04:     	stp	x29, x30, [sp, #0x70]
100849b08:     	add	x29, sp, #0x70
100849b0c:     	mov	x21, x0
100849b10:     	mov.16b	v8, v0
100849b14:     	fmov	x19, d8
100849b18:     	and	x20, x19, #0xffff000000000000
100849b1c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100849b20:     	cmp	x20, x8
100849b24:     	b.ne	0x100849b4c <_js_json_stringify+0x60>
100849b28:     	and	x0, x19, #0xffffffffffff
100849b2c:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
100849b30:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100849b34:     	movk	x9, #0xffef, lsl #16
100849b38:     	cmp	x8, x9
100849b3c:     	b.hi	0x100849b4c <_js_json_stringify+0x60>
100849b40:     	ldr	w8, [x0, #0x4]
100849b44:     	cmp	w8, #0x40
100849b48:     	b.hs	0x100849bbc <_js_json_stringify+0xd0>
100849b4c:     	mov.16b	v0, v8
100849b50:     	bl	0x1004f0a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100849b54:     	tbz	w0, #0x0, 0x100849b60 <_js_json_stringify+0x74>
100849b58:     	mov	x23, x1
100849b5c:     	b	0x10084a0d0 <_js_json_stringify+0x5e4>
100849b60:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100849b64:     	cmp	x20, x8
100849b68:     	b.ne	0x100849bd0 <_js_json_stringify+0xe4>
100849b6c:     	ands	x19, x19, #0xffffffffffff
100849b70:     	b.eq	0x100849bd0 <_js_json_stringify+0xe4>
100849b74:     	mov	x0, x19
100849b78:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100849b7c:     	cbz	w0, 0x100849bd0 <_js_json_stringify+0xe4>
100849b80:     	ldurb	w8, [x19, #-0x8]
100849b84:     	cmp	w8, #0x9
100849b88:     	b.ne	0x100849bd0 <_js_json_stringify+0xe4>
100849b8c:     	ldr	w8, [x19, #0x4]
100849b90:     	mov	w9, #0x5841             ; =22593
100849b94:     	movk	w9, #0x4c5a, lsl #16
100849b98:     	cmp	w8, w9
100849b9c:     	b.ne	0x100849bd0 <_js_json_stringify+0xe4>
100849ba0:     	mov	x0, x19
100849ba4:     	bl	0x10068bc64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100849ba8:     	cbz	x0, 0x100849bd0 <_js_json_stringify+0xe4>
100849bac:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100849bb0:     	bfxil	x8, x0, #0, #48
100849bb4:     	fmov	d8, x8
100849bb8:     	b	0x100849bd0 <_js_json_stringify+0xe4>
100849bbc:     	bl	0x1004f5968 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100849bc0:     	tbnz	w0, #0x0, 0x100849b58 <_js_json_stringify+0x6c>
100849bc4:     	mov.16b	v0, v8
100849bc8:     	bl	0x1004f0a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100849bcc:     	tbnz	w0, #0x0, 0x100849b58 <_js_json_stringify+0x6c>
100849bd0:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849bd4:     	add	x0, x0, #0xd78
100849bd8:     	ldr	x8, [x0]
100849bdc:     	blr	x8
100849be0:     	mov	x19, x0
100849be4:     	ldr	w26, [x0]
100849be8:     	add	w8, w26, #0x1
100849bec:     	str	w8, [x0]
100849bf0:     	cbz	w26, 0x100849c60 <_js_json_stringify+0x174>
100849bf4:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849bf8:     	add	x0, x0, #0xd00
100849bfc:     	ldr	x8, [x0]
100849c00:     	blr	x8
100849c04:     	ldrb	w8, [x0, #0x20]
100849c08:     	cmp	w8, #0x1
100849c0c:     	b.ne	0x10084a1c4 <_js_json_stringify+0x6d8>
100849c10:     	ldr	x8, [x0]
100849c14:     	cbnz	x8, 0x10084a1d0 <_js_json_stringify+0x6e4>
100849c18:     	mov	x8, #-0x1               ; =-1
100849c1c:     	str	x8, [x0]
100849c20:     	ldr	x20, [x0, #0x18]
100849c24:     	ldr	x8, [x0, #0x8]
100849c28:     	cmp	x20, x8
100849c2c:     	b.eq	0x10084a0f4 <_js_json_stringify+0x608>
100849c30:     	ldr	x8, [x0, #0x10]
100849c34:     	mov	w9, #0x18               ; =24
100849c38:     	madd	x8, x20, x9, x8
100849c3c:     	mov	w9, #0x8                ; =8
100849c40:     	stp	xzr, x9, [x8]
100849c44:     	str	xzr, [x8, #0x10]
100849c48:     	add	x8, x20, #0x1
100849c4c:     	str	x8, [x0, #0x18]
100849c50:     	ldr	x8, [x0]
100849c54:     	add	x8, x8, #0x1
100849c58:     	str	x8, [x0]
100849c5c:     	b	0x100849cec <_js_json_stringify+0x200>
100849c60:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849c64:     	add	x0, x0, #0xdc0
100849c68:     	ldr	x8, [x0]
100849c6c:     	blr	x8
100849c70:     	strb	wzr, [x0]
100849c74:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849c78:     	add	x0, x0, #0xdf0
100849c7c:     	ldr	x8, [x0]
100849c80:     	blr	x8
100849c84:     	strb	wzr, [x0]
100849c88:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
100849c8c:     	ldr	w20, [x8, #0x5a8]
100849c90:     	cmp	w20, #0x300
100849c94:     	b.hs	0x10084a150 <_js_json_stringify+0x664>
100849c98:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
100849c9c:     	ldr	x8, [x8, #0x48]
100849ca0:     	cmn	x8, #0x1
100849ca4:     	b.eq	0x10084a140 <_js_json_stringify+0x654>
100849ca8:     	mrs	x9, TPIDRRO_EL0
100849cac:     	and	x9, x9, #0xfffffffffffffff8
100849cb0:     	ldr	x0, [x9, x8, lsl #3]
100849cb4:     	cbz	x0, 0x10084a140 <_js_json_stringify+0x654>
100849cb8:     	add	x8, x0, x20, lsl #3
100849cbc:     	ldr	x0, [x8, #0x1e8]
100849cc0:     	cbz	x0, 0x10084a150 <_js_json_stringify+0x664>
100849cc4:     	str	xzr, [x0]
100849cc8:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849ccc:     	add	x0, x0, #0xd90
100849cd0:     	ldr	x8, [x0]
100849cd4:     	blr	x8
100849cd8:     	ldrb	w8, [x0, #0x20]
100849cdc:     	cbnz	w8, 0x10084a1dc <_js_json_stringify+0x6f0>
100849ce0:     	ldr	x8, [x0]
100849ce4:     	cbnz	x8, 0x10084a204 <_js_json_stringify+0x718>
100849ce8:     	str	xzr, [x0, #0x18]
100849cec:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849cf0:     	add	x0, x0, #0xd30
100849cf4:     	ldr	x8, [x0]
100849cf8:     	blr	x8
100849cfc:     	mov	x20, x0
100849d00:     	ldrb	w8, [x0, #0x18]
100849d04:     	cmp	w8, #0x1
100849d08:     	b.ne	0x10084a160 <_js_json_stringify+0x674>
100849d0c:     	ldr	x8, [x0]
100849d10:     	mov	x9, #-0x1               ; =-1
100849d14:     	str	x9, [x0]
100849d18:     	cmn	x8, #0x2
100849d1c:     	b.eq	0x10084a210 <_js_json_stringify+0x724>
100849d20:     	cmn	x8, #0x1
100849d24:     	b.eq	0x100849d38 <_js_json_stringify+0x24c>
100849d28:     	add	x9, sp, #0x8
100849d2c:     	ldur	q0, [x0, #0x8]
100849d30:     	stur	q0, [x9, #0x8]
100849d34:     	b	0x100849d44 <_js_json_stringify+0x258>
100849d38:     	mov	x8, #0x0                ; =0
100849d3c:     	mov	w9, #0x1                ; =1
100849d40:     	stp	x9, xzr, [sp, #0x10]
100849d44:     	str	x8, [sp, #0x8]
100849d48:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849d4c:     	add	x0, x0, #0xd18
100849d50:     	ldr	x8, [x0]
100849d54:     	blr	x8
100849d58:     	ldrb	w8, [x0, #0x20]
100849d5c:     	cbnz	w8, 0x10084a190 <_js_json_stringify+0x6a4>
100849d60:     	ldr	x8, [x0]
100849d64:     	cbnz	x8, 0x10084a1b8 <_js_json_stringify+0x6cc>
100849d68:     	str	xzr, [x0, #0x18]
100849d6c:     	add	x1, sp, #0x8
100849d70:     	mov.16b	v0, v8
100849d74:     	mov	x0, x21
100849d78:     	bl	0x10050c444 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100849d7c:     	ldp	x21, x22, [sp, #0x10]
100849d80:     	cmp	w22, #0x80, lsl #12     ; =0x80000
100849d84:     	b.hs	0x100849e44 <_js_json_stringify+0x358>
100849d88:     	cmp	x22, #0x40
100849d8c:     	b.hs	0x100849f08 <_js_json_stringify+0x41c>
100849d90:     	ands	x9, x22, #0x38
100849d94:     	b.eq	0x100849db8 <_js_json_stringify+0x2cc>
100849d98:     	and	x8, x22, #0x38
100849d9c:     	neg	x8, x8
100849da0:     	mov	x10, x21
100849da4:     	ldr	x11, [x10], #0x8
100849da8:     	tst	x11, #0x8080808080808080
100849dac:     	b.ne	0x100849e2c <_js_json_stringify+0x340>
100849db0:     	adds	x8, x8, #0x8
100849db4:     	b.ne	0x100849da4 <_js_json_stringify+0x2b8>
100849db8:     	and	x8, x22, #0x7
100849dbc:     	cbz	x8, 0x100849f8c <_js_json_stringify+0x4a0>
100849dc0:     	add	x9, x21, x9
100849dc4:     	ldrsb	w10, [x9]
100849dc8:     	tbnz	w10, #0x1f, 0x100849e2c <_js_json_stringify+0x340>
100849dcc:     	cmp	x8, #0x1
100849dd0:     	b.eq	0x100849f8c <_js_json_stringify+0x4a0>
100849dd4:     	ldrsb	w10, [x9, #0x1]
100849dd8:     	tbnz	w10, #0x1f, 0x100849e2c <_js_json_stringify+0x340>
100849ddc:     	cmp	x8, #0x2
100849de0:     	b.eq	0x100849f8c <_js_json_stringify+0x4a0>
100849de4:     	ldrsb	w10, [x9, #0x2]
100849de8:     	tbnz	w10, #0x1f, 0x100849e2c <_js_json_stringify+0x340>
100849dec:     	cmp	x8, #0x3
100849df0:     	b.eq	0x100849f8c <_js_json_stringify+0x4a0>
100849df4:     	ldrsb	w10, [x9, #0x3]
100849df8:     	tbnz	w10, #0x1f, 0x100849e2c <_js_json_stringify+0x340>
100849dfc:     	cmp	x8, #0x4
100849e00:     	b.eq	0x100849f8c <_js_json_stringify+0x4a0>
100849e04:     	ldrsb	w10, [x9, #0x4]
100849e08:     	tbnz	w10, #0x1f, 0x100849e2c <_js_json_stringify+0x340>
100849e0c:     	cmp	x8, #0x5
100849e10:     	b.eq	0x100849f8c <_js_json_stringify+0x4a0>
100849e14:     	ldrsb	w10, [x9, #0x5]
100849e18:     	tbnz	w10, #0x1f, 0x100849e2c <_js_json_stringify+0x340>
100849e1c:     	cmp	x8, #0x6
100849e20:     	b.eq	0x100849f8c <_js_json_stringify+0x4a0>
100849e24:     	ldrsb	w8, [x9, #0x6]
100849e28:     	tbz	w8, #0x1f, 0x100849f8c <_js_json_stringify+0x4a0>
100849e2c:     	mov	x0, x21
100849e30:     	mov	x1, x22
100849e34:     	mov	x2, x22
100849e38:     	bl	0x1008e14c0 <_js_string_from_bytes_with_capacity>
100849e3c:     	mov	x23, x0
100849e40:     	b	0x10084a088 <_js_json_stringify+0x59c>
100849e44:     	and	x8, x22, #0x7fffffffffffffc0
100849e48:     	add	x8, x21, x8
100849e4c:     	mov	x9, x21
100849e50:     	ldp	q0, q1, [x9]
100849e54:     	ldp	q2, q3, [x9, #0x20]
100849e58:     	orr.16b	v0, v1, v0
100849e5c:     	orr.16b	v1, v2, v3
100849e60:     	orr.16b	v0, v0, v1
100849e64:     	umaxv.16b	b0, v0
100849e68:     	fmov	w10, s0
100849e6c:     	tbnz	w10, #0x7, 0x100849ecc <_js_json_stringify+0x3e0>
100849e70:     	add	x9, x9, #0x40
100849e74:     	cmp	x9, x8
100849e78:     	b.ne	0x100849e50 <_js_json_stringify+0x364>
100849e7c:     	ands	x9, x22, #0x30
100849e80:     	b.eq	0x100849ea4 <_js_json_stringify+0x3b8>
100849e84:     	mov	x10, x9
100849e88:     	mov	x11, x8
100849e8c:     	ldr	q0, [x11], #0x10
100849e90:     	umaxv.16b	b0, v0
100849e94:     	fmov	w12, s0
100849e98:     	tbnz	w12, #0x7, 0x100849ecc <_js_json_stringify+0x3e0>
100849e9c:     	subs	x10, x10, #0x10
100849ea0:     	b.ne	0x100849e8c <_js_json_stringify+0x3a0>
100849ea4:     	and	x10, x22, #0xf
100849ea8:     	cbz	x10, 0x100849ec4 <_js_json_stringify+0x3d8>
100849eac:     	add	x8, x8, x9
100849eb0:     	ldrsb	w9, [x8]
100849eb4:     	tbnz	w9, #0x1f, 0x100849ecc <_js_json_stringify+0x3e0>
100849eb8:     	add	x8, x8, #0x1
100849ebc:     	subs	x10, x10, #0x1
100849ec0:     	b.ne	0x100849eb0 <_js_json_stringify+0x3c4>
100849ec4:     	mov	w24, w22
100849ec8:     	b	0x100849f00 <_js_json_stringify+0x414>
100849ecc:     	mov	w24, w22
100849ed0:     	cbz	x24, 0x100849f00 <_js_json_stringify+0x414>
100849ed4:     	mov	x8, x21
100849ed8:     	ands	x9, x22, #0x3
100849edc:     	b.eq	0x100849ef8 <_js_json_stringify+0x40c>
100849ee0:     	mov	x8, x21
100849ee4:     	ldrsb	w10, [x8]
100849ee8:     	tbnz	w10, #0x1f, 0x100849ff0 <_js_json_stringify+0x504>
100849eec:     	add	x8, x8, #0x1
100849ef0:     	subs	x9, x9, #0x1
100849ef4:     	b.ne	0x100849ee4 <_js_json_stringify+0x3f8>
100849ef8:     	cmp	x24, #0x4
100849efc:     	b.hs	0x100849fbc <_js_json_stringify+0x4d0>
100849f00:     	mov	x25, x22
100849f04:     	b	0x10084a000 <_js_json_stringify+0x514>
100849f08:     	and	x8, x22, #0x7fffffffffffffc0
100849f0c:     	and	x8, x8, #0xffffffff0007ffff
100849f10:     	add	x8, x21, x8
100849f14:     	mov	x9, x21
100849f18:     	ldp	q0, q1, [x9]
100849f1c:     	ldp	q2, q3, [x9, #0x20]
100849f20:     	orr.16b	v0, v1, v0
100849f24:     	orr.16b	v1, v2, v3
100849f28:     	orr.16b	v0, v0, v1
100849f2c:     	umaxv.16b	b0, v0
100849f30:     	fmov	w10, s0
100849f34:     	tbnz	w10, #0x7, 0x100849e2c <_js_json_stringify+0x340>
100849f38:     	add	x9, x9, #0x40
100849f3c:     	cmp	x9, x8
100849f40:     	b.ne	0x100849f18 <_js_json_stringify+0x42c>
100849f44:     	ands	x9, x22, #0x30
100849f48:     	b.eq	0x100849f6c <_js_json_stringify+0x480>
100849f4c:     	mov	x10, x9
100849f50:     	mov	x11, x8
100849f54:     	ldr	q0, [x11], #0x10
100849f58:     	umaxv.16b	b0, v0
100849f5c:     	fmov	w12, s0
100849f60:     	tbnz	w12, #0x7, 0x100849e2c <_js_json_stringify+0x340>
100849f64:     	subs	x10, x10, #0x10
100849f68:     	b.ne	0x100849f54 <_js_json_stringify+0x468>
100849f6c:     	and	x10, x22, #0xf
100849f70:     	cbz	x10, 0x100849f8c <_js_json_stringify+0x4a0>
100849f74:     	add	x8, x8, x9
100849f78:     	ldrsb	w9, [x8]
100849f7c:     	tbnz	w9, #0x1f, 0x100849e2c <_js_json_stringify+0x340>
100849f80:     	add	x8, x8, #0x1
100849f84:     	subs	x10, x10, #0x1
100849f88:     	b.ne	0x100849f78 <_js_json_stringify+0x48c>
100849f8c:     	mov	x0, x22
100849f90:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100849f94:     	mov	x23, x0
100849f98:     	stp	w22, w22, [x0]
100849f9c:     	stp	wzr, wzr, [x0, #0xc]
100849fa0:     	str	w22, [x0, #0x8]
100849fa4:     	cbz	w22, 0x10084a088 <_js_json_stringify+0x59c>
100849fa8:     	and	x2, x22, #0x7ffff
100849fac:     	mov	x0, x1
100849fb0:     	mov	x1, x21
100849fb4:     	bl	0x100b66b6c <_writev+0x100b66b6c>
100849fb8:     	b	0x10084a088 <_js_json_stringify+0x59c>
100849fbc:     	add	x9, x21, x24
100849fc0:     	ldrsb	w10, [x8]
100849fc4:     	tbnz	w10, #0x1f, 0x100849ff0 <_js_json_stringify+0x504>
100849fc8:     	ldrsb	w10, [x8, #0x1]
100849fcc:     	tbnz	w10, #0x1f, 0x100849ff0 <_js_json_stringify+0x504>
100849fd0:     	ldrsb	w10, [x8, #0x2]
100849fd4:     	tbnz	w10, #0x1f, 0x100849ff0 <_js_json_stringify+0x504>
100849fd8:     	ldrsb	w10, [x8, #0x3]
100849fdc:     	tbnz	w10, #0x1f, 0x100849ff0 <_js_json_stringify+0x504>
100849fe0:     	add	x8, x8, #0x4
100849fe4:     	cmp	x8, x9
100849fe8:     	b.ne	0x100849fc0 <_js_json_stringify+0x4d4>
100849fec:     	b	0x100849f00 <_js_json_stringify+0x414>
100849ff0:     	mov	w1, w22
100849ff4:     	mov	x0, x21
100849ff8:     	bl	0x1005ed7e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
100849ffc:     	mov	x25, x0
10084a000:     	bl	0x1004f2bc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
10084a004:     	add	x0, x24, #0x14
10084a008:     	mov	w1, #0x3                ; =3
10084a00c:     	bl	0x10045ae40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
10084a010:     	mov	x23, x0
10084a014:     	stp	w25, w22, [x0]
10084a018:     	stp	wzr, wzr, [x0, #0xc]
10084a01c:     	str	w22, [x0, #0x8]
10084a020:     	add	x0, x0, #0x14
10084a024:     	mov	x1, x21
10084a028:     	mov	x2, x24
10084a02c:     	bl	0x100b66b6c <_writev+0x100b66b6c>
10084a030:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
10084a034:     	ldr	w21, [x8, #0x590]
10084a038:     	cmp	w21, #0x300
10084a03c:     	b.hs	0x10084a118 <_js_json_stringify+0x62c>
10084a040:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084a044:     	ldr	x8, [x8, #0x48]
10084a048:     	cmn	x8, #0x1
10084a04c:     	b.eq	0x10084a108 <_js_json_stringify+0x61c>
10084a050:     	mrs	x9, TPIDRRO_EL0
10084a054:     	and	x9, x9, #0xfffffffffffffff8
10084a058:     	ldr	x0, [x9, x8, lsl #3]
10084a05c:     	cbz	x0, 0x10084a108 <_js_json_stringify+0x61c>
10084a060:     	add	x8, x0, x21, lsl #3
10084a064:     	ldr	x0, [x8, #0x1e8]
10084a068:     	cbz	x0, 0x10084a118 <_js_json_stringify+0x62c>
10084a06c:     	ldr	x8, [x0]
10084a070:     	adds	x8, x8, x24
10084a074:     	csinv	x8, x8, xzr, lo
10084a078:     	str	x8, [x0]
10084a07c:     	lsr	x8, x8, #25
10084a080:     	cbz	x8, 0x10084a088 <_js_json_stringify+0x59c>
10084a084:     	bl	0x100461d74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
10084a088:     	ldp	x22, x21, [sp, #0x8]
10084a08c:     	ldrb	w8, [x20, #0x18]
10084a090:     	cmp	w8, #0x1
10084a094:     	b.ne	0x10084a170 <_js_json_stringify+0x684>
10084a098:     	ldp	x8, x0, [x20]
10084a09c:     	stp	x22, x21, [x20]
10084a0a0:     	str	xzr, [x20, #0x10]
10084a0a4:     	sub	x8, x8, #0x1
10084a0a8:     	cmn	x8, #0x2
10084a0ac:     	b.hs	0x10084a0b4 <_js_json_stringify+0x5c8>
10084a0b0:     	bl	0x100b63cc0 <_mi_free>
10084a0b4:     	cbz	w26, 0x10084a0c0 <_js_json_stringify+0x5d4>
10084a0b8:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084a0bc:     	b	0x10084a0c4 <_js_json_stringify+0x5d8>
10084a0c0:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084a0c4:     	ldr	w8, [x19]
10084a0c8:     	sub	w8, w8, #0x1
10084a0cc:     	str	w8, [x19]
10084a0d0:     	mov	x0, x23
10084a0d4:     	ldp	x29, x30, [sp, #0x70]
10084a0d8:     	ldp	x20, x19, [sp, #0x60]
10084a0dc:     	ldp	x22, x21, [sp, #0x50]
10084a0e0:     	ldp	x24, x23, [sp, #0x40]
10084a0e4:     	ldp	x26, x25, [sp, #0x30]
10084a0e8:     	ldp	d9, d8, [sp, #0x20]
10084a0ec:     	add	sp, sp, #0x80
10084a0f0:     	ret
10084a0f4:     	mov	x22, x0
10084a0f8:     	add	x0, x0, #0x8
10084a0fc:     	bl	0x100b40a10 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10084a100:     	mov	x0, x22
10084a104:     	b	0x100849c30 <_js_json_stringify+0x144>
10084a108:     	bl	0x100b440bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084a10c:     	add	x8, x0, x21, lsl #3
10084a110:     	ldr	x0, [x8, #0x1e8]
10084a114:     	cbnz	x0, 0x10084a06c <_js_json_stringify+0x580>
10084a118:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084a11c:     	add	x0, x0, #0x78
10084a120:     	bl	0x100b418dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084a124:     	ldr	x8, [x0]
10084a128:     	adds	x8, x8, x24
10084a12c:     	csinv	x8, x8, xzr, lo
10084a130:     	str	x8, [x0]
10084a134:     	lsr	x8, x8, #25
10084a138:     	cbnz	x8, 0x10084a084 <_js_json_stringify+0x598>
10084a13c:     	b	0x10084a088 <_js_json_stringify+0x59c>
10084a140:     	bl	0x100b440bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084a144:     	add	x8, x0, x20, lsl #3
10084a148:     	ldr	x0, [x8, #0x1e8]
10084a14c:     	cbnz	x0, 0x100849cc4 <_js_json_stringify+0x1d8>
10084a150:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084a154:     	add	x0, x0, #0x138
10084a158:     	bl	0x100b418dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084a15c:     	b	0x100849cc4 <_js_json_stringify+0x1d8>
10084a160:     	mov	x0, x20
10084a164:     	bl	0x100b23244 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084a168:     	cbnz	x0, 0x100849d0c <_js_json_stringify+0x220>
10084a16c:     	b	0x10084a210 <_js_json_stringify+0x724>
10084a170:     	mov	x0, x20
10084a174:     	bl	0x100b23244 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084a178:     	mov	x20, x0
10084a17c:     	cbnz	x0, 0x10084a098 <_js_json_stringify+0x5ac>
10084a180:     	cbz	x22, 0x10084a210 <_js_json_stringify+0x724>
10084a184:     	mov	x0, x21
10084a188:     	bl	0x100b63cc0 <_mi_free>
10084a18c:     	b	0x10084a210 <_js_json_stringify+0x724>
10084a190:     	cmp	w8, #0x2
10084a194:     	b.eq	0x10084a210 <_js_json_stringify+0x724>
10084a198:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084a19c:     	add	x1, x1, #0xef8
10084a1a0:     	mov	x22, x0
10084a1a4:     	bl	0x100a2511c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084a1a8:     	mov	x0, x22
10084a1ac:     	strb	wzr, [x22, #0x20]
10084a1b0:     	ldr	x8, [x22]
10084a1b4:     	cbz	x8, 0x100849d68 <_js_json_stringify+0x27c>
10084a1b8:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084a1bc:     	add	x0, x0, #0xdb8
10084a1c0:     	bl	0x100b173ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a1c4:     	bl	0x100b233a4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084a1c8:     	cbnz	x0, 0x100849c10 <_js_json_stringify+0x124>
10084a1cc:     	b	0x10084a210 <_js_json_stringify+0x724>
10084a1d0:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10084a1d4:     	add	x0, x0, #0x440
10084a1d8:     	bl	0x100b173ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a1dc:     	cmp	w8, #0x1
10084a1e0:     	b.ne	0x10084a210 <_js_json_stringify+0x724>
10084a1e4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084a1e8:     	add	x1, x1, #0x898
10084a1ec:     	mov	x20, x0
10084a1f0:     	bl	0x100a2511c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084a1f4:     	mov	x0, x20
10084a1f8:     	strb	wzr, [x20, #0x20]
10084a1fc:     	ldr	x8, [x20]
10084a200:     	cbz	x8, 0x100849ce8 <_js_json_stringify+0x1fc>
10084a204:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084a208:     	add	x0, x0, #0xd88
10084a20c:     	bl	0x100b173ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a210:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084a214:     	add	x0, x0, #0xc18
10084a218:     	bl	0x100b5d31c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
