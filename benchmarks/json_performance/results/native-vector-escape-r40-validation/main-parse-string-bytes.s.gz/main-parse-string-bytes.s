
benchmarks/json_performance/.work/compact-json-token-scan-r35/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>:
100245978:     	stp	x20, x19, [sp, #-0x20]!
10024597c:     	stp	x29, x30, [sp, #0x10]
100245980:     	add	x29, sp, #0x10
100245984:     	ldp	x2, x11, [x1, #0x68]
100245988:     	subs	x17, x11, x2
10024598c:     	b.hs	0x100245d74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3fc>
100245990:     	ldr	x12, [x1, #0x60]
100245994:     	ldrb	w8, [x12, x11]
100245998:     	cmp	w8, #0x22
10024599c:     	b.ne	0x100245d74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3fc>
1002459a0:     	mov	x14, #0x0               ; =0
1002459a4:     	add	x8, x11, #0x1
1002459a8:     	str	x8, [x1, #0x70]
1002459ac:     	sub	x16, x2, x8
1002459b0:     	add	x13, x12, x8
1002459b4:     	movi.16b	v1, #0x22
1002459b8:     	movi.16b	v2, #0x5c
1002459bc:     	movi.16b	v3, #0x20
1002459c0:     	add	x9, x14, #0x10
1002459c4:     	cmp	x9, x16
1002459c8:     	b.hi	0x100245a04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x8c>
1002459cc:     	ldr	q0, [x13, x14]
1002459d0:     	cmeq.16b	v4, v0, v1
1002459d4:     	cmeq.16b	v5, v0, v2
1002459d8:     	orr.16b	v4, v5, v4
1002459dc:     	cmhi.16b	v0, v3, v0
1002459e0:     	orr.16b	v0, v0, v4
1002459e4:     	addp.2d	d4, v0
1002459e8:     	fmov	x10, d4
1002459ec:     	mov	x14, x9
1002459f0:     	cbz	x10, 0x1002459c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x48>
1002459f4:     	umov.b	w10, v0[0]
1002459f8:     	cbz	w10, 0x100245aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x130>
1002459fc:     	mov	x10, #0x0               ; =0
100245a00:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245a04:     	mov	x4, #0x0                ; =0
100245a08:     	mov	x3, #0x101010101010101  ; =72340172838076673
100245a0c:     	movk	x3, #0x100
100245a10:     	sub	x10, x16, x14
100245a14:     	mov	x5, #-0x7f7f7f7f7f7f7f80 ; =-9187201950435737472
100245a18:     	mov	x6, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100245a1c:     	orr	x6, x6, #0x4444444444444444
100245a20:     	mov	x7, #0x2020202020202020 ; =2314885530818453536
100245a24:     	movk	x7, #0x201f
100245a28:     	mov	x9, x4
100245a2c:     	add	x4, x4, #0x8
100245a30:     	cmp	x4, x10
100245a34:     	b.hi	0x100245ab8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x140>
100245a38:     	add	x15, x13, x9
100245a3c:     	ldr	x15, [x15, x14]
100245a40:     	eor	x19, x15, #0x2222222222222222
100245a44:     	sub	x19, x3, x19
100245a48:     	orr	x19, x19, x15
100245a4c:     	bics	xzr, x5, x19
100245a50:     	b.ne	0x100245a78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x100>
100245a54:     	eor	x19, x15, x6
100245a58:     	sub	x19, x3, x19
100245a5c:     	orr	x19, x19, x15
100245a60:     	bics	xzr, x5, x19
100245a64:     	b.ne	0x100245a78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x100>
100245a68:     	sub	x19, x7, x15
100245a6c:     	orr	x19, x19, x15
100245a70:     	bics	xzr, x5, x19
100245a74:     	b.eq	0x100245a28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0xb0>
100245a78:     	cmn	x9, #0x8
100245a7c:     	b.eq	0x100245c0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x294>
100245a80:     	mov	x10, #0x0               ; =0
100245a84:     	and	w16, w15, #0xff
100245a88:     	cmp	w16, #0x22
100245a8c:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245a90:     	cmp	w16, #0x5c
100245a94:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245a98:     	cmp	w16, #0x20
100245a9c:     	b.hs	0x100245b0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x194>
100245aa0:     	mov	x10, #0x0               ; =0
100245aa4:     	b	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245aa8:     	umov.b	w10, v0[1]
100245aac:     	cbz	w10, 0x100245afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x184>
100245ab0:     	mov	w10, #0x1               ; =1
100245ab4:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245ab8:     	cmp	x9, x10
100245abc:     	b.hi	0x100245c34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2bc>
100245ac0:     	add	x10, x14, x9
100245ac4:     	add	x9, x17, x10
100245ac8:     	cmn	x9, #0x1
100245acc:     	b.eq	0x100245d74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3fc>
100245ad0:     	ldrb	w9, [x13, x10]
100245ad4:     	cmp	w9, #0x22
100245ad8:     	b.eq	0x100245d30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b8>
100245adc:     	cmp	w9, #0x5c
100245ae0:     	b.eq	0x100245d30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b8>
100245ae4:     	cmp	w9, #0x20
100245ae8:     	b.lo	0x100245d30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b8>
100245aec:     	add	x10, x10, #0x1
100245af0:     	cmp	x16, x10
100245af4:     	b.ne	0x100245ad0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x158>
100245af8:     	b	0x100245d74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3fc>
100245afc:     	umov.b	w10, v0[2]
100245b00:     	cbz	w10, 0x100245b34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x1bc>
100245b04:     	mov	w10, #0x2               ; =2
100245b08:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245b0c:     	ubfx	w16, w15, #8, #8
100245b10:     	mov	w10, #0x1               ; =1
100245b14:     	cmp	w16, #0x22
100245b18:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245b1c:     	cmp	w16, #0x5c
100245b20:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245b24:     	cmp	w16, #0x20
100245b28:     	b.hs	0x100245b44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x1cc>
100245b2c:     	mov	w10, #0x1               ; =1
100245b30:     	b	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245b34:     	umov.b	w10, v0[3]
100245b38:     	cbz	w10, 0x100245b6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x1f4>
100245b3c:     	mov	w10, #0x3               ; =3
100245b40:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245b44:     	ubfx	w16, w15, #16, #8
100245b48:     	mov	w10, #0x2               ; =2
100245b4c:     	cmp	w16, #0x22
100245b50:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245b54:     	cmp	w16, #0x5c
100245b58:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245b5c:     	cmp	w16, #0x20
100245b60:     	b.hs	0x100245b8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x214>
100245b64:     	mov	w10, #0x2               ; =2
100245b68:     	b	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245b6c:     	umov.b	w10, v0[4]
100245b70:     	cbz	w10, 0x100245b7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x204>
100245b74:     	mov	w10, #0x4               ; =4
100245b78:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245b7c:     	umov.b	w10, v0[5]
100245b80:     	cbz	w10, 0x100245bb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x23c>
100245b84:     	mov	w10, #0x5               ; =5
100245b88:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245b8c:     	lsr	w16, w15, #24
100245b90:     	mov	w10, #0x3               ; =3
100245b94:     	cmp	w16, #0x22
100245b98:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245b9c:     	cmp	w16, #0x5c
100245ba0:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245ba4:     	cmp	w16, #0x20
100245ba8:     	b.hs	0x100245bd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x25c>
100245bac:     	mov	w10, #0x3               ; =3
100245bb0:     	b	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245bb4:     	umov.b	w10, v0[6]
100245bb8:     	cbz	w10, 0x100245bc4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x24c>
100245bbc:     	mov	w10, #0x6               ; =6
100245bc0:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245bc4:     	umov.b	w10, v0[7]
100245bc8:     	cbz	w10, 0x100245bfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x284>
100245bcc:     	mov	w10, #0x7               ; =7
100245bd0:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245bd4:     	ubfx	x16, x15, #32, #8
100245bd8:     	mov	w10, #0x4               ; =4
100245bdc:     	cmp	w16, #0x22
100245be0:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245be4:     	cmp	w16, #0x5c
100245be8:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245bec:     	cmp	w16, #0x20
100245bf0:     	b.hs	0x100245c4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2d4>
100245bf4:     	mov	w10, #0x4               ; =4
100245bf8:     	b	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245bfc:     	umov.b	w10, v0[8]
100245c00:     	cbz	w10, 0x100245c24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2ac>
100245c04:     	mov	w10, #0x8               ; =8
100245c08:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245c0c:     	adrp	x3, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100245c10:     	add	x3, x3, #0xe8
100245c14:     	add	x1, x9, #0x8
100245c18:     	mov	x0, #-0x8               ; =-8
100245c1c:     	mov	x2, x10
100245c20:     	bl	0x100b129cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245c24:     	umov.b	w10, v0[9]
100245c28:     	cbz	w10, 0x100245c74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2fc>
100245c2c:     	mov	w10, #0x9               ; =9
100245c30:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245c34:     	adrp	x3, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100245c38:     	add	x3, x3, #0xd0
100245c3c:     	mov	x0, x9
100245c40:     	mov	x1, x10
100245c44:     	mov	x2, x10
100245c48:     	bl	0x100b129cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245c4c:     	ubfx	x16, x15, #40, #8
100245c50:     	mov	w10, #0x5               ; =5
100245c54:     	cmp	w16, #0x22
100245c58:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245c5c:     	cmp	w16, #0x5c
100245c60:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245c64:     	cmp	w16, #0x20
100245c68:     	b.hs	0x100245c94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x31c>
100245c6c:     	mov	w10, #0x5               ; =5
100245c70:     	b	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245c74:     	umov.b	w10, v0[10]
100245c78:     	cbz	w10, 0x100245c84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x30c>
100245c7c:     	mov	w10, #0xa               ; =10
100245c80:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245c84:     	umov.b	w10, v0[11]
100245c88:     	cbz	w10, 0x100245cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x344>
100245c8c:     	mov	w10, #0xb               ; =11
100245c90:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245c94:     	ubfx	x16, x15, #48, #8
100245c98:     	mov	w10, #0x6               ; =6
100245c9c:     	cmp	w16, #0x22
100245ca0:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245ca4:     	cmp	w16, #0x5c
100245ca8:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245cac:     	cmp	w16, #0x20
100245cb0:     	b.hs	0x100245cdc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x364>
100245cb4:     	mov	w10, #0x6               ; =6
100245cb8:     	b	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245cbc:     	umov.b	w10, v0[12]
100245cc0:     	cbz	w10, 0x100245ccc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x354>
100245cc4:     	mov	w10, #0xc               ; =12
100245cc8:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245ccc:     	umov.b	w10, v0[13]
100245cd0:     	cbz	w10, 0x100245d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x394>
100245cd4:     	mov	w10, #0xd               ; =13
100245cd8:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245cdc:     	lsr	x16, x15, #56
100245ce0:     	mov	w10, #0x7               ; =7
100245ce4:     	cmp	w16, #0x22
100245ce8:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245cec:     	cmp	w16, #0x5c
100245cf0:     	b.eq	0x100245d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x388>
100245cf4:     	lsr	x10, x15, #61
100245cf8:     	cbnz	x10, 0x100245d74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3fc>
100245cfc:     	mov	w10, #0x7               ; =7
100245d00:     	add	x9, x10, x9
100245d04:     	add	x10, x9, x14
100245d08:     	b	0x100245d30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b8>
100245d0c:     	umov.b	w10, v0[14]
100245d10:     	cbz	w10, 0x100245d1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3a4>
100245d14:     	mov	w10, #0xe               ; =14
100245d18:     	b	0x100245d28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3b0>
100245d1c:     	umov.b	w10, v0[15]
100245d20:     	cbz	w10, 0x100245d74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3fc>
100245d24:     	mov	w10, #0xf               ; =15
100245d28:     	add	x9, x10, x9
100245d2c:     	sub	x10, x9, #0x10
100245d30:     	add	x9, x10, x8
100245d34:     	cmp	x9, x2
100245d38:     	str	x9, [x1, #0x70]
100245d3c:     	b.hs	0x100245db0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x438>
100245d40:     	ldrb	w12, [x12, x9]
100245d44:     	cmp	w12, #0x22
100245d48:     	b.ne	0x100245d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3f4>
100245d4c:     	cmp	x9, x11
100245d50:     	b.ls	0x100245d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x424>
100245d54:     	add	x8, x9, #0x1
100245d58:     	str	x8, [x1, #0x70]
100245d5c:     	mov	x8, #-0x1               ; =-1
100245d60:     	stp	x8, x13, [x0]
100245d64:     	str	x10, [x0, #0x10]
100245d68:     	b	0x100245d80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x408>
100245d6c:     	cmp	w12, #0x20
100245d70:     	b.hs	0x100245d8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x414>
100245d74:     	strb	wzr, [x1, #0xd4]
100245d78:     	mov	x8, #-0x2               ; =-2
100245d7c:     	str	x8, [x0]
100245d80:     	ldp	x29, x30, [sp, #0x10]
100245d84:     	ldp	x20, x19, [sp], #0x20
100245d88:     	ret
100245d8c:     	mov	x2, x8
100245d90:     	ldp	x29, x30, [sp, #0x10]
100245d94:     	ldp	x20, x19, [sp], #0x20
100245d98:     	b	0x10024789c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow>
100245d9c:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245da0:     	add	x3, x3, #0x650
100245da4:     	mov	x0, x8
100245da8:     	mov	x1, x9
100245dac:     	bl	0x100b129cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245db0:     	adrp	x8, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245db4:     	add	x8, x8, #0x638
100245db8:     	mov	x0, x9
100245dbc:     	mov	x1, x2
100245dc0:     	mov	x2, x8
100245dc4:     	bl	0x100b1280c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
