
benchmarks/json_performance/.work/inert-spacer-r8/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008459c0 <_js_json_stringify_full>:
1008459c0:     	sub	sp, sp, #0x120
1008459c4:     	stp	d9, d8, [sp, #0xb0]
1008459c8:     	stp	x28, x27, [sp, #0xc0]
1008459cc:     	stp	x26, x25, [sp, #0xd0]
1008459d0:     	stp	x24, x23, [sp, #0xe0]
1008459d4:     	stp	x22, x21, [sp, #0xf0]
1008459d8:     	stp	x20, x19, [sp, #0x100]
1008459dc:     	stp	x29, x30, [sp, #0x110]
1008459e0:     	add	x29, sp, #0x110
1008459e4:     	mov.16b	v9, v2
1008459e8:     	mov.16b	v8, v0
1008459ec:     	fmov	x19, d8
1008459f0:     	fmov	x21, d1
1008459f4:     	fmov	x23, d9
1008459f8:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
1008459fc:     	add	x27, x21, x8
100845a00:     	add	x24, x23, x8
100845a04:     	cmp	x24, #0x3
100845a08:     	b.hi	0x100845a18 <_js_json_stringify_full+0x58>
100845a0c:     	cmp	x27, #0x2
100845a10:     	b.hs	0x100845a24 <_js_json_stringify_full+0x64>
100845a14:     	b	0x100845a78 <_js_json_stringify_full+0xb8>
100845a18:     	fcmp	d9, #0.0
100845a1c:     	ccmp	x27, #0x2, #0x2, eq
100845a20:     	b.lo	0x100845a78 <_js_json_stringify_full+0xb8>
100845a24:     	mov	x20, #0x1               ; =1
100845a28:     	movk	x20, #0x7ffc, lsl #48
100845a2c:     	cmp	x19, x20
100845a30:     	b.eq	0x100846d28 <_js_json_stringify_full+0x1368>
100845a34:     	and	x22, x19, #0xffff000000000000
100845a38:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845a3c:     	cmp	x22, x8
100845a40:     	b.ne	0x100845b24 <_js_json_stringify_full+0x164>
100845a44:     	and	x8, x19, #0xffffffffffff
100845a48:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100845a4c:     	b.lo	0x100845a64 <_js_json_stringify_full+0xa4>
100845a50:     	ldr	w8, [x8, #0xc]
100845a54:     	mov	w9, #0x4f53             ; =20307
100845a58:     	movk	w9, #0x434c, lsl #16
100845a5c:     	cmp	w8, w9
100845a60:     	b.eq	0x100846d28 <_js_json_stringify_full+0x1368>
100845a64:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845a68:     	cmp	x22, x8
100845a6c:     	b.ne	0x100845bac <_js_json_stringify_full+0x1ec>
100845a70:     	and	x0, x19, #0xffffffffffff
100845a74:     	b	0x100845bd4 <_js_json_stringify_full+0x214>
100845a78:     	mov	x8, #-0x2               ; =-2
100845a7c:     	movk	x8, #0x8003, lsl #48
100845a80:     	add	x8, x19, x8
100845a84:     	cmp	x8, #0x3
100845a88:     	b.hs	0x100845a9c <_js_json_stringify_full+0xdc>
100845a8c:     	adrp	x9, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
100845a90:     	add	x9, x9, #0x5d8
100845a94:     	ldr	x20, [x9, x8, lsl #3]
100845a98:     	b	0x100846d28 <_js_json_stringify_full+0x1368>
100845a9c:     	strb	wzr, [sp, #0x4c]
100845aa0:     	str	wzr, [sp, #0x48]
100845aa4:     	and	x8, x19, #0xffff000000000000
100845aa8:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845aac:     	cmp	x8, x9
100845ab0:     	b.eq	0x100845b50 <_js_json_stringify_full+0x190>
100845ab4:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845ab8:     	cmp	x8, x9
100845abc:     	b.ne	0x100846df8 <_js_json_stringify_full+0x1438>
100845ac0:     	ubfx	x10, x19, #40, #8
100845ac4:     	cbz	x10, 0x100845b14 <_js_json_stringify_full+0x154>
100845ac8:     	strb	w19, [sp, #0x48]
100845acc:     	cmp	x10, #0x1
100845ad0:     	b.eq	0x100845b14 <_js_json_stringify_full+0x154>
100845ad4:     	lsr	x9, x19, #8
100845ad8:     	strb	w9, [sp, #0x49]
100845adc:     	cmp	x10, #0x2
100845ae0:     	b.eq	0x100845b14 <_js_json_stringify_full+0x154>
100845ae4:     	lsr	x9, x19, #16
100845ae8:     	strb	w9, [sp, #0x4a]
100845aec:     	cmp	x10, #0x3
100845af0:     	b.eq	0x100845b14 <_js_json_stringify_full+0x154>
100845af4:     	lsr	x9, x19, #24
100845af8:     	strb	w9, [sp, #0x4b]
100845afc:     	cmp	x10, #0x4
100845b00:     	b.eq	0x100845b14 <_js_json_stringify_full+0x154>
100845b04:     	lsr	x9, x19, #32
100845b08:     	strb	w9, [sp, #0x4c]
100845b0c:     	cmp	x10, #0x5
100845b10:     	b.ne	0x100847634 <_js_json_stringify_full+0x1c74>
100845b14:     	add	x11, sp, #0x48
100845b18:     	cmp	w10, #0x3
100845b1c:     	b.ls	0x100845b68 <_js_json_stringify_full+0x1a8>
100845b20:     	b	0x100846df8 <_js_json_stringify_full+0x1438>
100845b24:     	lsr	x8, x19, #52
100845b28:     	cbnz	x8, 0x100845c5c <_js_json_stringify_full+0x29c>
100845b2c:     	and	x8, x19, #0x7
100845b30:     	cbz	x19, 0x100845bb8 <_js_json_stringify_full+0x1f8>
100845b34:     	cbnz	x8, 0x100845bb8 <_js_json_stringify_full+0x1f8>
100845b38:     	mov	x0, x19
100845b3c:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100845b40:     	mov	x8, x19
100845b44:     	tbnz	w0, #0x0, 0x100845a48 <_js_json_stringify_full+0x88>
100845b48:     	mov	x8, #0x0                ; =0
100845b4c:     	b	0x100845bb8 <_js_json_stringify_full+0x1f8>
100845b50:     	ands	x9, x19, #0xffffffffffff
100845b54:     	b.eq	0x100845a24 <_js_json_stringify_full+0x64>
100845b58:     	add	x11, x9, #0x14
100845b5c:     	ldr	w10, [x9, #0x4]
100845b60:     	cmp	w10, #0x3
100845b64:     	b.hi	0x100846df8 <_js_json_stringify_full+0x1438>
100845b68:     	stur	wzr, [sp, #0x81]
100845b6c:     	mov	w9, #0x22               ; =34
100845b70:     	strb	w9, [sp, #0x80]
100845b74:     	cbz	w10, 0x100845d54 <_js_json_stringify_full+0x394>
100845b78:     	add	x12, sp, #0x80
100845b7c:     	ldrb	w13, [x11]
100845b80:     	sxtb	w15, w13
100845b84:     	cmp	w13, #0xb
100845b88:     	b.le	0x100845d5c <_js_json_stringify_full+0x39c>
100845b8c:     	cmp	w13, #0x21
100845b90:     	b.gt	0x100845d7c <_js_json_stringify_full+0x3bc>
100845b94:     	cmp	w13, #0xc
100845b98:     	b.eq	0x100846a48 <_js_json_stringify_full+0x1088>
100845b9c:     	cmp	w13, #0xd
100845ba0:     	b.ne	0x100845d8c <_js_json_stringify_full+0x3cc>
100845ba4:     	mov	w15, #0x72              ; =114
100845ba8:     	b	0x100846a54 <_js_json_stringify_full+0x1094>
100845bac:     	lsr	x8, x19, #52
100845bb0:     	cbnz	x8, 0x100845c5c <_js_json_stringify_full+0x29c>
100845bb4:     	and	x8, x19, #0x7
100845bb8:     	cbz	x19, 0x100845c5c <_js_json_stringify_full+0x29c>
100845bbc:     	cbnz	x8, 0x100845c5c <_js_json_stringify_full+0x29c>
100845bc0:     	mov	x0, x19
100845bc4:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100845bc8:     	mov	x8, x0
100845bcc:     	mov	x0, x19
100845bd0:     	tbz	w8, #0x0, 0x100845c5c <_js_json_stringify_full+0x29c>
100845bd4:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100845bd8:     	b.lo	0x100845c5c <_js_json_stringify_full+0x29c>
100845bdc:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
100845be0:     	add	x8, x8, #0xfb0
100845be4:     	ldaprb	w8, [x8]
100845be8:     	cbz	w8, 0x100845c5c <_js_json_stringify_full+0x29c>
100845bec:     	lsr	x8, x0, #3
100845bf0:     	mov	x9, #0x7c15             ; =31765
100845bf4:     	movk	x9, #0x7f4a, lsl #16
100845bf8:     	movk	x9, #0x79b9, lsl #32
100845bfc:     	movk	x9, #0x9e37, lsl #48
100845c00:     	mul	x8, x8, x9
100845c04:     	lsr	x10, x8, #54
100845c08:     	lsr	x11, x8, #60
100845c0c:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
100845c10:     	add	x9, x9, #0xf30
100845c14:     	add	x11, x9, x11, lsl #3
100845c18:     	ldapr	x11, [x11]
100845c1c:     	lsr	x10, x11, x10
100845c20:     	tbz	w10, #0x0, 0x100845c5c <_js_json_stringify_full+0x29c>
100845c24:     	lsr	x10, x8, #44
100845c28:     	ubfx	x11, x8, #50, #4
100845c2c:     	add	x11, x9, x11, lsl #3
100845c30:     	ldapr	x11, [x11]
100845c34:     	lsr	x10, x11, x10
100845c38:     	tbz	w10, #0x0, 0x100845c5c <_js_json_stringify_full+0x29c>
100845c3c:     	lsr	x10, x8, #34
100845c40:     	ubfx	x8, x8, #40, #4
100845c44:     	add	x8, x9, x8, lsl #3
100845c48:     	ldapr	x8, [x8]
100845c4c:     	lsr	x8, x8, x10
100845c50:     	tbz	w8, #0x0, 0x100845c5c <_js_json_stringify_full+0x29c>
100845c54:     	bl	0x10034ca2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
100845c58:     	tbnz	w0, #0x0, 0x100846d28 <_js_json_stringify_full+0x1368>
100845c5c:     	cmp	x24, #0x3
100845c60:     	ccmp	x27, #0x2, #0x2, lo
100845c64:     	b.hs	0x100845c84 <_js_json_stringify_full+0x2c4>
100845c68:     	mov.16b	v0, v8
100845c6c:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100845c70:     	cmp	x0, #0x1
100845c74:     	b.ne	0x100845c84 <_js_json_stringify_full+0x2c4>
100845c78:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100845c7c:     	bfxil	x20, x1, #0, #48
100845c80:     	b	0x100846d28 <_js_json_stringify_full+0x1368>
100845c84:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845c88:     	cmp	x22, x8
100845c8c:     	b.ne	0x100845cdc <_js_json_stringify_full+0x31c>
100845c90:     	ands	x22, x19, #0xffffffffffff
100845c94:     	b.eq	0x100845cdc <_js_json_stringify_full+0x31c>
100845c98:     	mov	x0, x22
100845c9c:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100845ca0:     	cbz	w0, 0x100845cdc <_js_json_stringify_full+0x31c>
100845ca4:     	ldurb	w8, [x22, #-0x8]
100845ca8:     	cmp	w8, #0x9
100845cac:     	b.ne	0x100845cdc <_js_json_stringify_full+0x31c>
100845cb0:     	ldr	w8, [x22, #0x4]
100845cb4:     	mov	w9, #0x5841             ; =22593
100845cb8:     	movk	w9, #0x4c5a, lsl #16
100845cbc:     	cmp	w8, w9
100845cc0:     	b.ne	0x100845cdc <_js_json_stringify_full+0x31c>
100845cc4:     	mov	x0, x22
100845cc8:     	bl	0x10068825c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100845ccc:     	cbz	x0, 0x100845cdc <_js_json_stringify_full+0x31c>
100845cd0:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100845cd4:     	bfxil	x19, x0, #0, #48
100845cd8:     	fmov	d8, x19
100845cdc:     	mov	w8, #0x7ffd             ; =32765
100845ce0:     	cmp	x8, x23, lsr #48
100845ce4:     	b.ne	0x100845cf8 <_js_json_stringify_full+0x338>
100845ce8:     	and	x1, x23, #0xffffffffffff
100845cec:     	cmp	x1, #0x100, lsl #12     ; =0x100000
100845cf0:     	b.hs	0x100845d0c <_js_json_stringify_full+0x34c>
100845cf4:     	b	0x100845db4 <_js_json_stringify_full+0x3f4>
100845cf8:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
100845cfc:     	mov	x9, #0xfffffff00000     ; =281474975662080
100845d00:     	mov	x1, x23
100845d04:     	cmp	x8, x9
100845d08:     	b.hs	0x100845db4 <_js_json_stringify_full+0x3f4>
100845d0c:     	lsr	x8, x1, #47
100845d10:     	cbnz	x8, 0x100845db4 <_js_json_stringify_full+0x3f4>
100845d14:     	add	x0, sp, #0x80
100845d18:     	bl	0x10076e06c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
100845d1c:     	ldr	w8, [sp, #0x80]
100845d20:     	tbz	w8, #0x0, 0x100845db4 <_js_json_stringify_full+0x3f4>
100845d24:     	ldr	w8, [sp, #0x88]
100845d28:     	mov	w9, #-0xff30            ; =-65328
100845d2c:     	cmp	w8, w9
100845d30:     	b.eq	0x100845da8 <_js_json_stringify_full+0x3e8>
100845d34:     	mov	w9, #-0xff2f            ; =-65327
100845d38:     	cmp	w8, w9
100845d3c:     	b.ne	0x100845db4 <_js_json_stringify_full+0x3f4>
100845d40:     	mov.16b	v0, v9
100845d44:     	bl	0x10084827c <_js_jsvalue_to_string>
100845d48:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
100845d4c:     	bfxil	x23, x0, #0, #48
100845d50:     	b	0x100845db4 <_js_json_stringify_full+0x3f4>
100845d54:     	mov	w12, #0x1               ; =1
100845d58:     	b	0x100846a7c <_js_json_stringify_full+0x10bc>
100845d5c:     	cmp	w13, #0x8
100845d60:     	b.eq	0x100846a40 <_js_json_stringify_full+0x1080>
100845d64:     	cmp	w13, #0x9
100845d68:     	b.eq	0x100846a50 <_js_json_stringify_full+0x1090>
100845d6c:     	cmp	w13, #0xa
100845d70:     	b.ne	0x100845d8c <_js_json_stringify_full+0x3cc>
100845d74:     	mov	w15, #0x6e              ; =110
100845d78:     	b	0x100846a54 <_js_json_stringify_full+0x1094>
100845d7c:     	cmp	w13, #0x22
100845d80:     	b.eq	0x100846a54 <_js_json_stringify_full+0x1094>
100845d84:     	cmp	w13, #0x5c
100845d88:     	b.eq	0x100846a54 <_js_json_stringify_full+0x1094>
100845d8c:     	cmp	w15, #0x20
100845d90:     	b.lt	0x100846df8 <_js_json_stringify_full+0x1438>
100845d94:     	mov	w14, #0x0               ; =0
100845d98:     	add	x13, x12, #0x2
100845d9c:     	mov	w12, #0x2               ; =2
100845da0:     	mov	w16, #0x1               ; =1
100845da4:     	b	0x100846a6c <_js_json_stringify_full+0x10ac>
100845da8:     	mov.16b	v0, v9
100845dac:     	bl	0x10086f820 <_js_number_coerce>
100845db0:     	fmov	x23, d0
100845db4:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100845db8:     	add	x8, x23, x8
100845dbc:     	cmp	x8, #0x3
100845dc0:     	b.hs	0x100845dd8 <_js_json_stringify_full+0x418>
100845dc4:     	mov	x22, #0x0               ; =0
100845dc8:     	mov	w8, #0x1                ; =1
100845dcc:     	stp	xzr, x8, [sp, #0x10]
100845dd0:     	str	xzr, [sp, #0x20]
100845dd4:     	b	0x100846040 <_js_json_stringify_full+0x680>
100845dd8:     	and	x8, x23, #0xffff000000000000
100845ddc:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845de0:     	cmp	x8, x9
100845de4:     	b.eq	0x100845e08 <_js_json_stringify_full+0x448>
100845de8:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845dec:     	cmp	x8, x9
100845df0:     	b.ne	0x100845e94 <_js_json_stringify_full+0x4d4>
100845df4:     	and	x8, x23, #0xffffffffffff
100845df8:     	cmp	x8, #0x1, lsl #12       ; =0x1000
100845dfc:     	b.hs	0x100845edc <_js_json_stringify_full+0x51c>
100845e00:     	mov	x9, #0x0                ; =0
100845e04:     	b	0x100845ee4 <_js_json_stringify_full+0x524>
100845e08:     	strb	wzr, [sp, #0x4c]
100845e0c:     	str	wzr, [sp, #0x48]
100845e10:     	ubfx	x1, x23, #40, #8
100845e14:     	cbz	x1, 0x100845e64 <_js_json_stringify_full+0x4a4>
100845e18:     	strb	w23, [sp, #0x48]
100845e1c:     	cmp	x1, #0x1
100845e20:     	b.eq	0x100845e64 <_js_json_stringify_full+0x4a4>
100845e24:     	lsr	x8, x23, #8
100845e28:     	strb	w8, [sp, #0x49]
100845e2c:     	cmp	x1, #0x2
100845e30:     	b.eq	0x100845e64 <_js_json_stringify_full+0x4a4>
100845e34:     	lsr	x8, x23, #16
100845e38:     	strb	w8, [sp, #0x4a]
100845e3c:     	cmp	x1, #0x3
100845e40:     	b.eq	0x100845e64 <_js_json_stringify_full+0x4a4>
100845e44:     	lsr	x8, x23, #24
100845e48:     	strb	w8, [sp, #0x4b]
100845e4c:     	cmp	x1, #0x4
100845e50:     	b.eq	0x100845e64 <_js_json_stringify_full+0x4a4>
100845e54:     	lsr	x8, x23, #32
100845e58:     	strb	w8, [sp, #0x4c]
100845e5c:     	cmp	x1, #0x5
100845e60:     	b.ne	0x100847634 <_js_json_stringify_full+0x1c74>
100845e64:     	add	x8, sp, #0x80
100845e68:     	add	x0, sp, #0x48
100845e6c:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100845e70:     	ldr	w8, [sp, #0x80]
100845e74:     	ldp	x9, x22, [sp, #0x88]
100845e78:     	cmp	w8, #0x0
100845e7c:     	csinc	x23, x9, xzr, eq
100845e80:     	csel	x25, xzr, x22, ne
100845e84:     	tbz	x25, #0x3f, 0x100845fc4 <_js_json_stringify_full+0x604>
100845e88:     	mov	x0, #0x0                ; =0
100845e8c:     	mov	x1, x22
100845e90:     	bl	0x100b12200 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100845e94:     	add	x8, x20, #0x3
100845e98:     	cmp	x23, x8
100845e9c:     	b.eq	0x100845dc4 <_js_json_stringify_full+0x404>
100845ea0:     	fmov	d0, x23
100845ea4:     	fcvtzu	x8, d0
100845ea8:     	mov	w9, #0xa                ; =10
100845eac:     	cmp	x8, #0xa
100845eb0:     	csel	x3, x8, x9, lo
100845eb4:     	adrp	x1, 0x100c43000 <_PERRY_EMPTY_STRING+0x1bf4>
100845eb8:     	add	x1, x1, #0x59c
100845ebc:     	add	x0, sp, #0x80
100845ec0:     	mov	w2, #0x1                ; =1
100845ec4:     	bl	0x1002305f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
100845ec8:     	ldr	x22, [sp, #0x90]
100845ecc:     	str	x22, [sp, #0x20]
100845ed0:     	ldr	q0, [sp, #0x80]
100845ed4:     	str	q0, [sp, #0x10]
100845ed8:     	b	0x100846040 <_js_json_stringify_full+0x680>
100845edc:     	ldr	w22, [x8, #0x4]
100845ee0:     	add	x9, x8, #0x14
100845ee4:     	mov	x14, #0x0               ; =0
100845ee8:     	mov	x8, #0x0                ; =0
100845eec:     	cmp	x9, #0x0
100845ef0:     	csel	x24, xzr, x22, eq
100845ef4:     	csinc	x23, x9, xzr, ne
100845ef8:     	add	x9, x23, x24
100845efc:     	mov	w10, #0x1               ; =1
100845f00:     	mov	x11, x23
100845f04:     	b	0x100845f34 <_js_json_stringify_full+0x574>
100845f08:     	add	x12, x11, #0x2
100845f0c:     	bfi	w15, w13, #6, #5
100845f10:     	mov	x13, x15
100845f14:     	sub	x11, x25, x11
100845f18:     	add	x14, x11, x12
100845f1c:     	cmp	w13, #0x10, lsl #12     ; =0x10000
100845f20:     	cinc	x11, x10, hs
100845f24:     	add	x8, x11, x8
100845f28:     	mov	x11, x12
100845f2c:     	cmp	x8, #0xa
100845f30:     	b.hi	0x100845fec <_js_json_stringify_full+0x62c>
100845f34:     	cmp	x11, x9
100845f38:     	b.eq	0x100845f9c <_js_json_stringify_full+0x5dc>
100845f3c:     	mov	x25, x14
100845f40:     	mov	x12, x11
100845f44:     	ldrsb	w14, [x12], #0x1
100845f48:     	and	w13, w14, #0xff
100845f4c:     	tbz	w14, #0x1f, 0x100845f14 <_js_json_stringify_full+0x554>
100845f50:     	ldrb	w12, [x11, #0x1]
100845f54:     	and	w15, w12, #0x3f
100845f58:     	cmp	w13, #0xe0
100845f5c:     	b.lo	0x100845f08 <_js_json_stringify_full+0x548>
100845f60:     	and	w14, w13, #0x1f
100845f64:     	ldrb	w12, [x11, #0x2]
100845f68:     	and	w12, w12, #0x3f
100845f6c:     	orr	w15, w12, w15, lsl #6
100845f70:     	cmp	w13, #0xf0
100845f74:     	b.lo	0x100845f90 <_js_json_stringify_full+0x5d0>
100845f78:     	add	x12, x11, #0x4
100845f7c:     	ldrb	w13, [x11, #0x3]
100845f80:     	and	w13, w13, #0x3f
100845f84:     	orr	w13, w13, w15, lsl #6
100845f88:     	bfi	w13, w14, #18, #3
100845f8c:     	b	0x100845f14 <_js_json_stringify_full+0x554>
100845f90:     	add	x12, x11, #0x3
100845f94:     	orr	w13, w15, w14, lsl #12
100845f98:     	b	0x100845f14 <_js_json_stringify_full+0x554>
100845f9c:     	cbz	x24, 0x100846020 <_js_json_stringify_full+0x660>
100845fa0:     	mov	x0, x24
100845fa4:     	mov	w1, #0x1                ; =1
100845fa8:     	bl	0x100b5f0c8 <_mi_malloc_aligned>
100845fac:     	cbz	x0, 0x10084761c <_js_json_stringify_full+0x1c5c>
100845fb0:     	mov	x26, x0
100845fb4:     	mov	x1, x23
100845fb8:     	mov	x2, x24
100845fbc:     	bl	0x100b61cec <_writev+0x100b61cec>
100845fc0:     	b	0x100846028 <_js_json_stringify_full+0x668>
100845fc4:     	cbz	x25, 0x100846030 <_js_json_stringify_full+0x670>
100845fc8:     	mov	x0, x25
100845fcc:     	mov	w1, #0x1                ; =1
100845fd0:     	bl	0x100b5f0c8 <_mi_malloc_aligned>
100845fd4:     	cbz	x0, 0x100847628 <_js_json_stringify_full+0x1c68>
100845fd8:     	mov	x24, x0
100845fdc:     	mov	x1, x23
100845fe0:     	mov	x2, x25
100845fe4:     	bl	0x100b61cec <_writev+0x100b61cec>
100845fe8:     	b	0x100846038 <_js_json_stringify_full+0x678>
100845fec:     	cbz	x25, 0x100846020 <_js_json_stringify_full+0x660>
100845ff0:     	cmp	x25, x24
100845ff4:     	b.hs	0x100846a2c <_js_json_stringify_full+0x106c>
100845ff8:     	ldrsb	w8, [x23, x25]
100845ffc:     	cmn	w8, #0x40
100846000:     	b.ge	0x100846a30 <_js_json_stringify_full+0x1070>
100846004:     	adrp	x4, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846008:     	add	x4, x4, #0x270
10084600c:     	mov	x0, x23
100846010:     	mov	x1, x24
100846014:     	mov	x2, #0x0                ; =0
100846018:     	mov	x3, x25
10084601c:     	bl	0x100b12578 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
100846020:     	mov	x22, #0x0               ; =0
100846024:     	mov	w26, #0x1               ; =1
100846028:     	stp	x22, x26, [sp, #0x10]
10084602c:     	b	0x10084603c <_js_json_stringify_full+0x67c>
100846030:     	mov	x22, #0x0               ; =0
100846034:     	mov	w24, #0x1               ; =1
100846038:     	stp	x22, x24, [sp, #0x10]
10084603c:     	str	x22, [sp, #0x20]
100846040:     	cmp	x27, #0x2
100846044:     	b.lo	0x100846184 <_js_json_stringify_full+0x7c4>
100846048:     	and	x25, x21, #0xffff000000000000
10084604c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846050:     	cmp	x25, x8
100846054:     	b.ne	0x100846160 <_js_json_stringify_full+0x7a0>
100846058:     	and	x23, x21, #0xffffffffffff
10084605c:     	cmp	x23, #0x100, lsl #12    ; =0x100000
100846060:     	b.lo	0x100846184 <_js_json_stringify_full+0x7c4>
100846064:     	mov	x0, x23
100846068:     	bl	0x10050a640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
10084606c:     	tbnz	w0, #0x0, 0x100846184 <_js_json_stringify_full+0x7c4>
100846070:     	lsr	x8, x23, #51
100846074:     	cmp	x8, #0xfff
100846078:     	b.lo	0x100846090 <_js_json_stringify_full+0x6d0>
10084607c:     	mov	w8, #0x7ffc             ; =32764
100846080:     	cmp	x8, x23, lsr #48
100846084:     	b.eq	0x100846184 <_js_json_stringify_full+0x7c4>
100846088:     	ands	x23, x23, #0xffffffffffff
10084608c:     	b.eq	0x100846184 <_js_json_stringify_full+0x7c4>
100846090:     	and	x8, x23, #0xfffffffffff00000
100846094:     	lsr	x9, x23, #47
100846098:     	cmp	x9, #0x0
10084609c:     	ccmp	x8, #0x0, #0x4, eq
1008460a0:     	b.eq	0x100846184 <_js_json_stringify_full+0x7c4>
1008460a4:     	tst	x23, #0x3
1008460a8:     	ccmp	x23, #0x7, #0x0, eq
1008460ac:     	b.ls	0x10084724c <_js_json_stringify_full+0x188c>
1008460b0:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1008460b4:     	ldr	x8, [x8, #0x48]
1008460b8:     	cmn	x8, #0x1
1008460bc:     	b.eq	0x10084719c <_js_json_stringify_full+0x17dc>
1008460c0:     	mrs	x9, TPIDRRO_EL0
1008460c4:     	and	x9, x9, #0xfffffffffffffff8
1008460c8:     	ldr	x0, [x9, x8, lsl #3]
1008460cc:     	cbz	x0, 0x10084719c <_js_json_stringify_full+0x17dc>
1008460d0:     	lsr	x1, x23, #20
1008460d4:     	ldr	x8, [x0, #0x10]
1008460d8:     	ldrb	w9, [x8]
1008460dc:     	cmp	w9, #0x2
1008460e0:     	b.ne	0x1008471b4 <_js_json_stringify_full+0x17f4>
1008460e4:     	ldrb	w9, [x8, #0x88]
1008460e8:     	tbz	w9, #0x0, 0x100846108 <_js_json_stringify_full+0x748>
1008460ec:     	ldr	x9, [x8, #0x80]
1008460f0:     	cmp	x9, x1
1008460f4:     	b.ne	0x100846108 <_js_json_stringify_full+0x748>
1008460f8:     	ldp	x9, x10, [x8, #0x60]
1008460fc:     	cmp	x9, x23
100846100:     	ccmp	x10, x23, #0x0, ls
100846104:     	b.hi	0x100847194 <_js_json_stringify_full+0x17d4>
100846108:     	ldrb	w9, [x8, #0xb8]
10084610c:     	cbz	w9, 0x10084612c <_js_json_stringify_full+0x76c>
100846110:     	ldr	x9, [x8, #0xb0]
100846114:     	cmp	x9, x1
100846118:     	b.ne	0x10084612c <_js_json_stringify_full+0x76c>
10084611c:     	ldp	x9, x10, [x8, #0x90]
100846120:     	cmp	x9, x23
100846124:     	ccmp	x10, x23, #0x0, ls
100846128:     	b.hi	0x10084741c <_js_json_stringify_full+0x1a5c>
10084612c:     	ldrb	w9, [x8, #0xe8]
100846130:     	cbz	w9, 0x100846fd4 <_js_json_stringify_full+0x1614>
100846134:     	ldr	x9, [x8, #0xe0]
100846138:     	cmp	x9, x1
10084613c:     	b.ne	0x100846fd4 <_js_json_stringify_full+0x1614>
100846140:     	ldr	x9, [x8, #0xc0]
100846144:     	cmp	x9, x23
100846148:     	b.hi	0x100846fd4 <_js_json_stringify_full+0x1614>
10084614c:     	ldr	x9, [x8, #0xc8]
100846150:     	cmp	x9, x23
100846154:     	b.ls	0x100846fd4 <_js_json_stringify_full+0x1614>
100846158:     	add	x9, x8, #0xc0
10084615c:     	b	0x100847420 <_js_json_stringify_full+0x1a60>
100846160:     	lsr	x8, x21, #52
100846164:     	cbnz	x8, 0x100846184 <_js_json_stringify_full+0x7c4>
100846168:     	cbz	x21, 0x100846184 <_js_json_stringify_full+0x7c4>
10084616c:     	and	x8, x21, #0x7
100846170:     	cbnz	x8, 0x100846184 <_js_json_stringify_full+0x7c4>
100846174:     	mov	x0, x21
100846178:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084617c:     	mov	x23, x21
100846180:     	cbnz	w0, 0x10084605c <_js_json_stringify_full+0x69c>
100846184:     	mov	x25, #-0x1              ; =-1
100846188:     	str	x25, [sp, #0x30]
10084618c:     	mov	w24, #0x1               ; =1
100846190:     	cmp	x27, #0x1
100846194:     	cset	w8, hi
100846198:     	tst	w8, w24
10084619c:     	b.eq	0x100846210 <_js_json_stringify_full+0x850>
1008461a0:     	and	x23, x21, #0xffff000000000000
1008461a4:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008461a8:     	cmp	x23, x8
1008461ac:     	b.ne	0x1008461e8 <_js_json_stringify_full+0x828>
1008461b0:     	and	x8, x21, #0xffffffffffff
1008461b4:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1008461b8:     	b.lo	0x100846210 <_js_json_stringify_full+0x850>
1008461bc:     	ldr	w8, [x8, #0xc]
1008461c0:     	mov	w9, #0x4f53             ; =20307
1008461c4:     	movk	w9, #0x434c, lsl #16
1008461c8:     	cmp	w8, w9
1008461cc:     	b.ne	0x100846210 <_js_json_stringify_full+0x850>
1008461d0:     	and	x8, x21, #0xffffffffffff
1008461d4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008461d8:     	cmp	x23, x9
1008461dc:     	csel	x28, x8, x21, eq
1008461e0:     	mov	w27, #0x1               ; =1
1008461e4:     	b	0x100846214 <_js_json_stringify_full+0x854>
1008461e8:     	lsr	x8, x21, #52
1008461ec:     	cbnz	x8, 0x100846210 <_js_json_stringify_full+0x850>
1008461f0:     	mov	w27, #0x0               ; =0
1008461f4:     	cbz	x21, 0x100846214 <_js_json_stringify_full+0x854>
1008461f8:     	and	x8, x21, #0x7
1008461fc:     	cbnz	x8, 0x100846214 <_js_json_stringify_full+0x854>
100846200:     	mov	x0, x21
100846204:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846208:     	mov	x8, x21
10084620c:     	tbnz	w0, #0x0, 0x1008461b4 <_js_json_stringify_full+0x7f4>
100846210:     	mov	w27, #0x0               ; =0
100846214:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846218:     	add	x0, x0, #0xd78
10084621c:     	ldr	x8, [x0]
100846220:     	blr	x8
100846224:     	mov	x21, x0
100846228:     	ldr	w26, [x0]
10084622c:     	add	w8, w26, #0x1
100846230:     	str	w8, [x0]
100846234:     	cbz	w26, 0x1008462a4 <_js_json_stringify_full+0x8e4>
100846238:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084623c:     	add	x0, x0, #0xd00
100846240:     	ldr	x8, [x0]
100846244:     	blr	x8
100846248:     	ldrb	w8, [x0, #0x20]
10084624c:     	cmp	w8, #0x1
100846250:     	b.ne	0x10084748c <_js_json_stringify_full+0x1acc>
100846254:     	ldr	x8, [x0]
100846258:     	cbnz	x8, 0x100847498 <_js_json_stringify_full+0x1ad8>
10084625c:     	mov	x8, #-0x1               ; =-1
100846260:     	str	x8, [x0]
100846264:     	ldr	x23, [x0, #0x18]
100846268:     	ldr	x8, [x0, #0x8]
10084626c:     	cmp	x23, x8
100846270:     	b.eq	0x100846a08 <_js_json_stringify_full+0x1048>
100846274:     	ldr	x8, [x0, #0x10]
100846278:     	mov	w9, #0x18               ; =24
10084627c:     	madd	x8, x23, x9, x8
100846280:     	mov	w9, #0x8                ; =8
100846284:     	stp	xzr, x9, [x8]
100846288:     	str	xzr, [x8, #0x10]
10084628c:     	add	x8, x23, #0x1
100846290:     	str	x8, [x0, #0x18]
100846294:     	ldr	x8, [x0]
100846298:     	add	x8, x8, #0x1
10084629c:     	str	x8, [x0]
1008462a0:     	b	0x10084630c <_js_json_stringify_full+0x94c>
1008462a4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008462a8:     	add	x0, x0, #0xdc0
1008462ac:     	ldr	x8, [x0]
1008462b0:     	blr	x8
1008462b4:     	strb	wzr, [x0]
1008462b8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008462bc:     	add	x0, x0, #0xdf0
1008462c0:     	ldr	x8, [x0]
1008462c4:     	blr	x8
1008462c8:     	strb	wzr, [x0]
1008462cc:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1008462d0:     	ldr	w23, [x8, #0x5a8]
1008462d4:     	cmp	w23, #0x300
1008462d8:     	b.hs	0x100846da8 <_js_json_stringify_full+0x13e8>
1008462dc:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1008462e0:     	ldr	x8, [x8, #0x48]
1008462e4:     	cmn	x8, #0x1
1008462e8:     	b.eq	0x100846d98 <_js_json_stringify_full+0x13d8>
1008462ec:     	mrs	x9, TPIDRRO_EL0
1008462f0:     	and	x9, x9, #0xfffffffffffffff8
1008462f4:     	ldr	x0, [x9, x8, lsl #3]
1008462f8:     	cbz	x0, 0x100846d98 <_js_json_stringify_full+0x13d8>
1008462fc:     	add	x8, x0, x23, lsl #3
100846300:     	ldr	x0, [x8, #0x1e8]
100846304:     	cbz	x0, 0x100846da8 <_js_json_stringify_full+0x13e8>
100846308:     	str	xzr, [x0]
10084630c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846310:     	add	x0, x0, #0xd30
100846314:     	ldr	x8, [x0]
100846318:     	blr	x8
10084631c:     	mov	x23, x0
100846320:     	ldrb	w8, [x0, #0x18]
100846324:     	cmp	w8, #0x1
100846328:     	b.ne	0x100847440 <_js_json_stringify_full+0x1a80>
10084632c:     	ldr	x8, [x0]
100846330:     	mov	x9, #-0x1               ; =-1
100846334:     	str	x9, [x0]
100846338:     	cmn	x8, #0x2
10084633c:     	b.eq	0x1008475c8 <_js_json_stringify_full+0x1c08>
100846340:     	cmn	x8, #0x1
100846344:     	b.eq	0x100846418 <_js_json_stringify_full+0xa58>
100846348:     	add	x9, sp, #0x48
10084634c:     	ldur	q0, [x0, #0x8]
100846350:     	stur	q0, [x9, #0x8]
100846354:     	str	x8, [sp, #0x48]
100846358:     	tbz	w24, #0x0, 0x10084642c <_js_json_stringify_full+0xa6c>
10084635c:     	tbz	w27, #0x0, 0x100846514 <_js_json_stringify_full+0xb54>
100846360:     	bl	0x10028b418 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100846364:     	str	x0, [sp, #0x60]
100846368:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084636c:     	stp	x28, x8, [sp, #0x88]
100846370:     	mov	w8, #0x1                ; =1
100846374:     	str	x8, [sp, #0x80]
100846378:     	add	x0, sp, #0x80
10084637c:     	bl	0x10028b520 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100846380:     	mov	x22, x0
100846384:     	str	x0, [sp, #0x68]
100846388:     	mov	w0, #0x0                ; =0
10084638c:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846390:     	stp	xzr, xzr, [x0]
100846394:     	str	wzr, [x0, #0x10]
100846398:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10084639c:     	bfxil	x8, x0, #0, #48
1008463a0:     	fmov	d0, x8
1008463a4:     	bl	0x10020b124 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
1008463a8:     	mov	x19, x0
1008463ac:     	adrp	x24, 0x100f7c000 <_perry_global_worker_ts__1>
1008463b0:     	ldr	x8, [x24, #0x48]
1008463b4:     	cmn	x8, #0x1
1008463b8:     	b.eq	0x100846578 <_js_json_stringify_full+0xbb8>
1008463bc:     	mrs	x9, TPIDRRO_EL0
1008463c0:     	and	x9, x9, #0xfffffffffffffff8
1008463c4:     	ldr	x8, [x9, x8, lsl #3]
1008463c8:     	cbz	x8, 0x100846578 <_js_json_stringify_full+0xbb8>
1008463cc:     	ldr	x8, [x8, #0x19e8]
1008463d0:     	cbz	x8, 0x100846578 <_js_json_stringify_full+0xbb8>
1008463d4:     	ldr	x9, [x8]
1008463d8:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1008463dc:     	cmp	x9, x10
1008463e0:     	b.hs	0x100847514 <_js_json_stringify_full+0x1b54>
1008463e4:     	add	x10, x9, #0x1
1008463e8:     	str	x10, [x8]
1008463ec:     	ldr	x10, [x8, #0x18]
1008463f0:     	cmp	x19, x10
1008463f4:     	b.hs	0x100847520 <_js_json_stringify_full+0x1b60>
1008463f8:     	ldr	x10, [x8, #0x10]
1008463fc:     	mov	w11, #0x18              ; =24
100846400:     	madd	x10, x19, x11, x10
100846404:     	ldr	x11, [x10]
100846408:     	cbnz	x11, 0x100847580 <_js_json_stringify_full+0x1bc0>
10084640c:     	ldr	x0, [x10, #0x8]
100846410:     	str	x9, [x8]
100846414:     	b	0x100846580 <_js_json_stringify_full+0xbc0>
100846418:     	mov	x8, #0x0                ; =0
10084641c:     	mov	w9, #0x1                ; =1
100846420:     	stp	x9, xzr, [sp, #0x50]
100846424:     	str	x8, [sp, #0x48]
100846428:     	tbnz	w24, #0x0, 0x10084635c <_js_json_stringify_full+0x99c>
10084642c:     	cmp	x22, #0x0
100846430:     	cset	w6, ne
100846434:     	ldp	x0, x1, [sp, #0x38]
100846438:     	ldp	x3, x4, [sp, #0x18]
10084643c:     	add	x2, sp, #0x48
100846440:     	mov.16b	v0, v8
100846444:     	mov	x5, #0x0                ; =0
100846448:     	bl	0x100502e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
10084644c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846450:     	add	x0, x0, #0xd90
100846454:     	ldr	x8, [x0]
100846458:     	blr	x8
10084645c:     	ldrb	w8, [x0, #0x20]
100846460:     	cbnz	w8, 0x1008474a4 <_js_json_stringify_full+0x1ae4>
100846464:     	ldr	x8, [x0]
100846468:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10084646c:     	cmp	x8, x9
100846470:     	b.hs	0x1008474d4 <_js_json_stringify_full+0x1b14>
100846474:     	ldr	x9, [x0, #0x18]
100846478:     	cbz	x9, 0x100846484 <_js_json_stringify_full+0xac4>
10084647c:     	cbnz	x8, 0x1008474e0 <_js_json_stringify_full+0x1b20>
100846480:     	str	xzr, [x0, #0x18]
100846484:     	ldp	x0, x1, [sp, #0x50]
100846488:     	cmp	x1, #0x5
10084648c:     	b.hi	0x1008464f4 <_js_json_stringify_full+0xb34>
100846490:     	cbz	x1, 0x100846704 <_js_json_stringify_full+0xd44>
100846494:     	ldrsb	w8, [x0]
100846498:     	tbnz	w8, #0x1f, 0x1008464f4 <_js_json_stringify_full+0xb34>
10084649c:     	cmp	x1, #0x1
1008464a0:     	b.eq	0x1008464dc <_js_json_stringify_full+0xb1c>
1008464a4:     	ldrsb	w8, [x0, #0x1]
1008464a8:     	tbnz	w8, #0x1f, 0x1008464f4 <_js_json_stringify_full+0xb34>
1008464ac:     	cmp	x1, #0x2
1008464b0:     	b.eq	0x1008464dc <_js_json_stringify_full+0xb1c>
1008464b4:     	ldrsb	w8, [x0, #0x2]
1008464b8:     	tbnz	w8, #0x1f, 0x1008464f4 <_js_json_stringify_full+0xb34>
1008464bc:     	cmp	x1, #0x3
1008464c0:     	b.eq	0x1008464dc <_js_json_stringify_full+0xb1c>
1008464c4:     	ldrsb	w8, [x0, #0x3]
1008464c8:     	tbnz	w8, #0x1f, 0x1008464f4 <_js_json_stringify_full+0xb34>
1008464cc:     	cmp	x1, #0x4
1008464d0:     	b.eq	0x1008464dc <_js_json_stringify_full+0xb1c>
1008464d4:     	ldrsb	w8, [x0, #0x4]
1008464d8:     	tbnz	w8, #0x1f, 0x1008464f4 <_js_json_stringify_full+0xb34>
1008464dc:     	cmp	x1, #0x4
1008464e0:     	b.hs	0x100846844 <_js_json_stringify_full+0xe84>
1008464e4:     	mov	x10, #0x0               ; =0
1008464e8:     	mov	x9, #0x0                ; =0
1008464ec:     	mov	x8, x0
1008464f0:     	b	0x1008468d4 <_js_json_stringify_full+0xf14>
1008464f4:     	bl	0x100329e88 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
1008464f8:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
1008464fc:     	bfxil	x20, x0, #0, #48
100846500:     	ldp	x22, x0, [sp, #0x48]
100846504:     	ldrb	w8, [x23, #0x18]
100846508:     	cmp	w8, #0x1
10084650c:     	b.eq	0x100846910 <_js_json_stringify_full+0xf50>
100846510:     	b	0x100847470 <_js_json_stringify_full+0x1ab0>
100846514:     	mov	w0, #0x0                ; =0
100846518:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084651c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846520:     	bfxil	x8, x0, #0, #48
100846524:     	fmov	d1, x8
100846528:     	stp	xzr, xzr, [x0]
10084652c:     	str	wzr, [x0, #0x10]
100846530:     	mov.16b	v0, v8
100846534:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846538:     	mov.16b	v8, v0
10084653c:     	fmov	x24, d8
100846540:     	cmp	x24, x20
100846544:     	b.eq	0x10084678c <_js_json_stringify_full+0xdcc>
100846548:     	mov	w8, #0x7ffd             ; =32765
10084654c:     	cmp	x8, x24, lsr #48
100846550:     	b.ne	0x10084675c <_js_json_stringify_full+0xd9c>
100846554:     	and	x8, x24, #0xffffffffffff
100846558:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084655c:     	b.lo	0x100846780 <_js_json_stringify_full+0xdc0>
100846560:     	ldr	w8, [x8, #0xc]
100846564:     	mov	w9, #0x4f53             ; =20307
100846568:     	movk	w9, #0x434c, lsl #16
10084656c:     	cmp	w8, w9
100846570:     	b.ne	0x100846780 <_js_json_stringify_full+0xdc0>
100846574:     	b	0x10084678c <_js_json_stringify_full+0xdcc>
100846578:     	mov	x0, x19
10084657c:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846580:     	fmov	d1, x0
100846584:     	mov.16b	v0, v8
100846588:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
10084658c:     	mov.16b	v8, v0
100846590:     	ldr	x8, [x24, #0x48]
100846594:     	cmn	x8, #0x1
100846598:     	b.eq	0x1008465fc <_js_json_stringify_full+0xc3c>
10084659c:     	mrs	x9, TPIDRRO_EL0
1008465a0:     	and	x9, x9, #0xfffffffffffffff8
1008465a4:     	ldr	x8, [x9, x8, lsl #3]
1008465a8:     	cbz	x8, 0x1008465fc <_js_json_stringify_full+0xc3c>
1008465ac:     	ldr	x8, [x8, #0x19e8]
1008465b0:     	cbz	x8, 0x1008465fc <_js_json_stringify_full+0xc3c>
1008465b4:     	ldr	x9, [x8]
1008465b8:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1008465bc:     	cmp	x9, x10
1008465c0:     	b.hs	0x100847514 <_js_json_stringify_full+0x1b54>
1008465c4:     	add	x10, x9, #0x1
1008465c8:     	str	x10, [x8]
1008465cc:     	ldr	x10, [x8, #0x18]
1008465d0:     	cmp	x22, x10
1008465d4:     	b.hs	0x100847520 <_js_json_stringify_full+0x1b60>
1008465d8:     	ldr	x10, [x8, #0x10]
1008465dc:     	mov	w11, #0x18              ; =24
1008465e0:     	madd	x10, x22, x11, x10
1008465e4:     	ldr	x11, [x10]
1008465e8:     	cmp	x11, #0x1
1008465ec:     	b.ne	0x1008475e0 <_js_json_stringify_full+0x1c20>
1008465f0:     	ldr	x22, [x10, #0x8]
1008465f4:     	str	x9, [x8]
1008465f8:     	b	0x100846608 <_js_json_stringify_full+0xc48>
1008465fc:     	mov	x0, x22
100846600:     	bl	0x10013c298 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100846604:     	mov	x22, x0
100846608:     	ldr	x8, [x24, #0x48]
10084660c:     	cmn	x8, #0x1
100846610:     	b.eq	0x100846670 <_js_json_stringify_full+0xcb0>
100846614:     	mrs	x9, TPIDRRO_EL0
100846618:     	and	x9, x9, #0xfffffffffffffff8
10084661c:     	ldr	x8, [x9, x8, lsl #3]
100846620:     	cbz	x8, 0x100846670 <_js_json_stringify_full+0xcb0>
100846624:     	ldr	x8, [x8, #0x19e8]
100846628:     	cbz	x8, 0x100846670 <_js_json_stringify_full+0xcb0>
10084662c:     	ldr	x9, [x8]
100846630:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846634:     	cmp	x9, x10
100846638:     	b.hs	0x100847514 <_js_json_stringify_full+0x1b54>
10084663c:     	add	x10, x9, #0x1
100846640:     	str	x10, [x8]
100846644:     	ldr	x10, [x8, #0x18]
100846648:     	cmp	x19, x10
10084664c:     	b.hs	0x100847520 <_js_json_stringify_full+0x1b60>
100846650:     	ldr	x10, [x8, #0x10]
100846654:     	mov	w11, #0x18              ; =24
100846658:     	madd	x10, x19, x11, x10
10084665c:     	ldr	x11, [x10]
100846660:     	cbnz	x11, 0x100847580 <_js_json_stringify_full+0x1bc0>
100846664:     	ldr	x0, [x10, #0x8]
100846668:     	str	x9, [x8]
10084666c:     	b	0x100846678 <_js_json_stringify_full+0xcb8>
100846670:     	mov	x0, x19
100846674:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846678:     	fmov	d9, x0
10084667c:     	mov.16b	v0, v8
100846680:     	bl	0x1004ff434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100846684:     	mov.16b	v2, v0
100846688:     	mov	x0, x22
10084668c:     	mov.16b	v0, v9
100846690:     	mov.16b	v1, v8
100846694:     	bl	0x1004ff714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
100846698:     	str	d0, [sp, #0x70]
10084669c:     	fmov	x19, d0
1008466a0:     	cmp	x19, x20
1008466a4:     	b.ne	0x10084670c <_js_json_stringify_full+0xd4c>
1008466a8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008466ac:     	add	x0, x0, #0xd90
1008466b0:     	ldr	x8, [x0]
1008466b4:     	blr	x8
1008466b8:     	ldrb	w8, [x0, #0x20]
1008466bc:     	cbnz	w8, 0x1008475c0 <_js_json_stringify_full+0x1c00>
1008466c0:     	ldr	x8, [x0]
1008466c4:     	cbnz	x8, 0x100847610 <_js_json_stringify_full+0x1c50>
1008466c8:     	str	xzr, [x0, #0x18]
1008466cc:     	ldp	x22, x19, [sp, #0x48]
1008466d0:     	ldrb	w8, [x23, #0x18]
1008466d4:     	cmp	w8, #0x1
1008466d8:     	b.ne	0x100847558 <_js_json_stringify_full+0x1b98>
1008466dc:     	ldp	x8, x0, [x23]
1008466e0:     	stp	x22, x19, [x23]
1008466e4:     	str	xzr, [x23, #0x10]
1008466e8:     	sub	x8, x8, #0x1
1008466ec:     	cmn	x8, #0x2
1008466f0:     	b.hs	0x1008466f8 <_js_json_stringify_full+0xd38>
1008466f4:     	bl	0x100b5ee40 <_mi_free>
1008466f8:     	cbz	w26, 0x100846998 <_js_json_stringify_full+0xfd8>
1008466fc:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846700:     	b	0x10084699c <_js_json_stringify_full+0xfdc>
100846704:     	mov	x10, #0x0               ; =0
100846708:     	b	0x1008468f4 <_js_json_stringify_full+0xf34>
10084670c:     	add	x0, sp, #0x48
100846710:     	bl	0x100500470 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
100846714:     	tbnz	w0, #0x0, 0x100846750 <_js_json_stringify_full+0xd90>
100846718:     	mov	x0, x19
10084671c:     	bl	0x100327dec <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
100846720:     	cmp	x0, #0x1
100846724:     	b.ne	0x1008475d4 <_js_json_stringify_full+0x1c14>
100846728:     	add	x8, sp, #0x78
10084672c:     	add	x9, sp, #0x70
100846730:     	stp	x1, x8, [sp, #0x78]
100846734:     	str	x9, [sp, #0x88]
100846738:     	add	x8, sp, #0x48
10084673c:     	add	x9, sp, #0x10
100846740:     	stp	x8, x9, [sp, #0x90]
100846744:     	add	x0, sp, #0x68
100846748:     	add	x1, sp, #0x80
10084674c:     	bl	0x100143d90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
100846750:     	add	x0, sp, #0x60
100846754:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100846758:     	b	0x10084644c <_js_json_stringify_full+0xa8c>
10084675c:     	lsr	x8, x24, #52
100846760:     	cbnz	x8, 0x100846780 <_js_json_stringify_full+0xdc0>
100846764:     	cbz	x24, 0x100846780 <_js_json_stringify_full+0xdc0>
100846768:     	and	x8, x24, #0x7
10084676c:     	cbnz	x8, 0x100846780 <_js_json_stringify_full+0xdc0>
100846770:     	mov	x0, x24
100846774:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846778:     	mov	x8, x24
10084677c:     	tbnz	w0, #0x0, 0x100846558 <_js_json_stringify_full+0xb98>
100846780:     	mov	x0, x24
100846784:     	bl	0x100509494 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
100846788:     	tbz	w0, #0x0, 0x100846818 <_js_json_stringify_full+0xe58>
10084678c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846790:     	add	x0, x0, #0xd90
100846794:     	ldr	x8, [x0]
100846798:     	blr	x8
10084679c:     	ldrb	w8, [x0, #0x20]
1008467a0:     	cbnz	w8, 0x100847524 <_js_json_stringify_full+0x1b64>
1008467a4:     	ldr	x8, [x0]
1008467a8:     	cbnz	x8, 0x10084754c <_js_json_stringify_full+0x1b8c>
1008467ac:     	str	xzr, [x0, #0x18]
1008467b0:     	ldp	x22, x19, [sp, #0x48]
1008467b4:     	ldrb	w8, [x23, #0x18]
1008467b8:     	cmp	w8, #0x1
1008467bc:     	b.ne	0x100847500 <_js_json_stringify_full+0x1b40>
1008467c0:     	ldp	x8, x0, [x23]
1008467c4:     	stp	x22, x19, [x23]
1008467c8:     	str	xzr, [x23, #0x10]
1008467cc:     	sub	x8, x8, #0x1
1008467d0:     	cmn	x8, #0x2
1008467d4:     	b.hs	0x1008467dc <_js_json_stringify_full+0xe1c>
1008467d8:     	bl	0x100b5ee40 <_mi_free>
1008467dc:     	cbz	w26, 0x1008467fc <_js_json_stringify_full+0xe3c>
1008467e0:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
1008467e4:     	ldr	w8, [x21]
1008467e8:     	sub	w8, w8, #0x1
1008467ec:     	str	w8, [x21]
1008467f0:     	cmn	x25, #0x1
1008467f4:     	b.ne	0x1008469b8 <_js_json_stringify_full+0xff8>
1008467f8:     	b	0x1008469f4 <_js_json_stringify_full+0x1034>
1008467fc:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846800:     	ldr	w8, [x21]
100846804:     	sub	w8, w8, #0x1
100846808:     	str	w8, [x21]
10084680c:     	cmn	x25, #0x1
100846810:     	b.ne	0x1008469b8 <_js_json_stringify_full+0xff8>
100846814:     	b	0x1008469f4 <_js_json_stringify_full+0x1034>
100846818:     	cmp	x19, x24
10084681c:     	b.eq	0x100846828 <_js_json_stringify_full+0xe68>
100846820:     	mov.16b	v0, v8
100846824:     	bl	0x10050e86c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
100846828:     	cbz	x22, 0x100846db8 <_js_json_stringify_full+0x13f8>
10084682c:     	ldp	x1, x2, [sp, #0x18]
100846830:     	add	x0, sp, #0x48
100846834:     	mov.16b	v0, v8
100846838:     	mov	x3, #0x0                ; =0
10084683c:     	bl	0x100500f60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
100846840:     	b	0x100846dc8 <_js_json_stringify_full+0x1408>
100846844:     	and	x9, x1, #0x4
100846848:     	add	x8, x0, x9
10084684c:     	adrp	x10, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
100846850:     	ldr	q0, [x10, #0x8c0]
100846854:     	adrp	x10, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x337ba>
100846858:     	ldr	q2, [x10, #0x7c0]
10084685c:     	movi.2d	v1, #0000000000000000
100846860:     	movi.2d	v3, #0x000000000000ff
100846864:     	mov	w10, #0x4               ; =4
100846868:     	dup.2d	v4, x10
10084686c:     	mov	x10, x0
100846870:     	and	x11, x1, #0x4
100846874:     	movi.2d	v5, #0000000000000000
100846878:     	ldr	s6, [x10], #0x4
10084687c:     	ushll.8h	v6, v6, #0x0
100846880:     	ushll.4s	v6, v6, #0x0
100846884:     	ushll2.2d	v7, v6, #0x0
100846888:     	and.16b	v7, v7, v3
10084688c:     	ushll.2d	v6, v6, #0x0
100846890:     	and.16b	v6, v6, v3
100846894:     	shl.2d	v16, v0, #0x3
100846898:     	shl.2d	v17, v2, #0x3
10084689c:     	ushl.2d	v6, v6, v17
1008468a0:     	ushl.2d	v7, v7, v16
1008468a4:     	orr.16b	v1, v7, v1
1008468a8:     	orr.16b	v5, v6, v5
1008468ac:     	add.2d	v0, v0, v4
1008468b0:     	add.2d	v2, v2, v4
1008468b4:     	subs	x11, x11, #0x4
1008468b8:     	b.ne	0x100846878 <_js_json_stringify_full+0xeb8>
1008468bc:     	orr.16b	v0, v5, v1
1008468c0:     	mov	d1, v0[1]
1008468c4:     	orr.8b	v0, v0, v1
1008468c8:     	fmov	x10, d0
1008468cc:     	cmp	x1, x9
1008468d0:     	b.eq	0x1008468f4 <_js_json_stringify_full+0xf34>
1008468d4:     	add	x11, x0, x1
1008468d8:     	lsl	x9, x9, #3
1008468dc:     	ldrb	w12, [x8], #0x1
1008468e0:     	lsl	x12, x12, x9
1008468e4:     	orr	x10, x12, x10
1008468e8:     	add	x9, x9, #0x8
1008468ec:     	cmp	x8, x11
1008468f0:     	b.ne	0x1008468dc <_js_json_stringify_full+0xf1c>
1008468f4:     	orr	x8, x10, x1, lsl #40
1008468f8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008468fc:     	orr	x20, x8, x9
100846900:     	ldr	x22, [sp, #0x48]
100846904:     	ldrb	w8, [x23, #0x18]
100846908:     	cmp	w8, #0x1
10084690c:     	b.ne	0x100847470 <_js_json_stringify_full+0x1ab0>
100846910:     	ldp	x9, x8, [x23]
100846914:     	stp	x22, x0, [x23]
100846918:     	str	xzr, [x23, #0x10]
10084691c:     	sub	x9, x9, #0x1
100846920:     	cmn	x9, #0x2
100846924:     	b.hs	0x100846930 <_js_json_stringify_full+0xf70>
100846928:     	mov	x0, x8
10084692c:     	bl	0x100b5ee40 <_mi_free>
100846930:     	cbz	w26, 0x100846950 <_js_json_stringify_full+0xf90>
100846934:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846938:     	ldr	w8, [x21]
10084693c:     	sub	w8, w8, #0x1
100846940:     	str	w8, [x21]
100846944:     	cmn	x25, #0x1
100846948:     	b.ne	0x100846968 <_js_json_stringify_full+0xfa8>
10084694c:     	b	0x1008469f4 <_js_json_stringify_full+0x1034>
100846950:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846954:     	ldr	w8, [x21]
100846958:     	sub	w8, w8, #0x1
10084695c:     	str	w8, [x21]
100846960:     	cmn	x25, #0x1
100846964:     	b.eq	0x1008469f4 <_js_json_stringify_full+0x1034>
100846968:     	ldp	x19, x21, [sp, #0x38]
10084696c:     	cbz	x21, 0x1008469e8 <_js_json_stringify_full+0x1028>
100846970:     	add	x22, x19, #0x8
100846974:     	b	0x100846984 <_js_json_stringify_full+0xfc4>
100846978:     	add	x22, x22, #0x18
10084697c:     	subs	x21, x21, #0x1
100846980:     	b.eq	0x1008469e8 <_js_json_stringify_full+0x1028>
100846984:     	ldur	x8, [x22, #-0x8]
100846988:     	cbz	x8, 0x100846978 <_js_json_stringify_full+0xfb8>
10084698c:     	ldr	x0, [x22]
100846990:     	bl	0x100b5ee40 <_mi_free>
100846994:     	b	0x100846978 <_js_json_stringify_full+0xfb8>
100846998:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084699c:     	ldr	w8, [x21]
1008469a0:     	sub	w8, w8, #0x1
1008469a4:     	str	w8, [x21]
1008469a8:     	add	x0, sp, #0x60
1008469ac:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1008469b0:     	cmn	x25, #0x1
1008469b4:     	b.eq	0x1008469f4 <_js_json_stringify_full+0x1034>
1008469b8:     	ldp	x19, x21, [sp, #0x38]
1008469bc:     	cbz	x21, 0x1008469e8 <_js_json_stringify_full+0x1028>
1008469c0:     	add	x22, x19, #0x8
1008469c4:     	b	0x1008469d4 <_js_json_stringify_full+0x1014>
1008469c8:     	add	x22, x22, #0x18
1008469cc:     	subs	x21, x21, #0x1
1008469d0:     	b.eq	0x1008469e8 <_js_json_stringify_full+0x1028>
1008469d4:     	ldur	x8, [x22, #-0x8]
1008469d8:     	cbz	x8, 0x1008469c8 <_js_json_stringify_full+0x1008>
1008469dc:     	ldr	x0, [x22]
1008469e0:     	bl	0x100b5ee40 <_mi_free>
1008469e4:     	b	0x1008469c8 <_js_json_stringify_full+0x1008>
1008469e8:     	cbz	x25, 0x1008469f4 <_js_json_stringify_full+0x1034>
1008469ec:     	mov	x0, x19
1008469f0:     	bl	0x100b5ee40 <_mi_free>
1008469f4:     	ldr	x8, [sp, #0x10]
1008469f8:     	cbz	x8, 0x100846d28 <_js_json_stringify_full+0x1368>
1008469fc:     	ldr	x0, [sp, #0x18]
100846a00:     	bl	0x100b5ee40 <_mi_free>
100846a04:     	b	0x100846d28 <_js_json_stringify_full+0x1368>
100846a08:     	str	x22, [sp, #0x8]
100846a0c:     	mov	x22, x28
100846a10:     	mov	x28, x0
100846a14:     	add	x0, x0, #0x8
100846a18:     	bl	0x100b3bbd0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100846a1c:     	mov	x0, x28
100846a20:     	mov	x28, x22
100846a24:     	ldr	x22, [sp, #0x8]
100846a28:     	b	0x100846274 <_js_json_stringify_full+0x8b4>
100846a2c:     	b.ne	0x100846004 <_js_json_stringify_full+0x644>
100846a30:     	tbz	x25, #0x3f, 0x100846f34 <_js_json_stringify_full+0x1574>
100846a34:     	mov	x0, #0x0                ; =0
100846a38:     	mov	x1, x25
100846a3c:     	bl	0x100b12200 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100846a40:     	mov	w15, #0x62              ; =98
100846a44:     	b	0x100846a54 <_js_json_stringify_full+0x1094>
100846a48:     	mov	w15, #0x66              ; =102
100846a4c:     	b	0x100846a54 <_js_json_stringify_full+0x1094>
100846a50:     	mov	w15, #0x74              ; =116
100846a54:     	add	x13, x12, #0x3
100846a58:     	mov	w12, #0x5c              ; =92
100846a5c:     	strb	w12, [sp, #0x81]
100846a60:     	mov	w14, #0x1               ; =1
100846a64:     	mov	w12, #0x3               ; =3
100846a68:     	mov	w16, #0x2               ; =2
100846a6c:     	add	x17, sp, #0x80
100846a70:     	strb	w15, [x17, x16]
100846a74:     	cmp	w10, #0x1
100846a78:     	b.ne	0x100846ab4 <_js_json_stringify_full+0x10f4>
100846a7c:     	add	x10, sp, #0x80
100846a80:     	strb	w9, [x10, x12]
100846a84:     	add	x8, x12, #0x1
100846a88:     	cmp	x12, #0x3
100846a8c:     	b.hs	0x100846aa0 <_js_json_stringify_full+0x10e0>
100846a90:     	mov	x13, #0x0               ; =0
100846a94:     	mov	x11, #0x0               ; =0
100846a98:     	add	x9, sp, #0x80
100846a9c:     	b	0x100846cfc <_js_json_stringify_full+0x133c>
100846aa0:     	cmp	x12, #0xf
100846aa4:     	b.hs	0x100846ae4 <_js_json_stringify_full+0x1124>
100846aa8:     	mov	x11, #0x0               ; =0
100846aac:     	mov	x13, #0x0               ; =0
100846ab0:     	b	0x100846c58 <_js_json_stringify_full+0x1298>
100846ab4:     	ldrb	w16, [x11, #0x1]
100846ab8:     	sxtb	w15, w16
100846abc:     	cmp	w16, #0xb
100846ac0:     	b.le	0x100846d50 <_js_json_stringify_full+0x1390>
100846ac4:     	cmp	w16, #0x21
100846ac8:     	b.gt	0x100846d70 <_js_json_stringify_full+0x13b0>
100846acc:     	cmp	w16, #0xc
100846ad0:     	b.eq	0x100846de8 <_js_json_stringify_full+0x1428>
100846ad4:     	cmp	w16, #0xd
100846ad8:     	b.ne	0x100846d80 <_js_json_stringify_full+0x13c0>
100846adc:     	mov	w15, #0x72              ; =114
100846ae0:     	b	0x100846df4 <_js_json_stringify_full+0x1434>
100846ae4:     	and	x12, x8, #0xc
100846ae8:     	and	x11, x8, #0x10
100846aec:     	add	x13, sp, #0x80
100846af0:     	add	x9, x13, x11
100846af4:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5fb0>
100846af8:     	ldr	q0, [x14, #0x750]
100846afc:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5fb0>
100846b00:     	ldr	q1, [x14, #0x760]
100846b04:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5fb0>
100846b08:     	ldr	q2, [x14, #0x770]
100846b0c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5fb0>
100846b10:     	ldr	q3, [x14, #0x780]
100846b14:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5fb0>
100846b18:     	ldr	q4, [x14, #0x790]
100846b1c:     	movi.2d	v5, #0000000000000000
100846b20:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5fb0>
100846b24:     	ldr	q6, [x14, #0x7a0]
100846b28:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
100846b2c:     	ldr	q7, [x14, #0x8c0]
100846b30:     	mov	w14, #0x10              ; =16
100846b34:     	movi.2d	v16, #0000000000000000
100846b38:     	dup.2d	v17, x14
100846b3c:     	adrp	x14, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x337ba>
100846b40:     	ldr	q19, [x14, #0x7c0]
100846b44:     	and	x14, x8, #0x10
100846b48:     	movi.2d	v20, #0000000000000000
100846b4c:     	movi.2d	v18, #0000000000000000
100846b50:     	movi.2d	v23, #0000000000000000
100846b54:     	movi.2d	v21, #0000000000000000
100846b58:     	movi.2d	v24, #0000000000000000
100846b5c:     	movi.2d	v22, #0000000000000000
100846b60:     	ldr	q25, [x13], #0x10
100846b64:     	ushll.8h	v26, v25, #0x0
100846b68:     	ushll2.4s	v27, v26, #0x0
100846b6c:     	ushll2.2d	v28, v27, #0x0
100846b70:     	ushll2.8h	v25, v25, #0x0
100846b74:     	ushll.4s	v29, v25, #0x0
100846b78:     	ushll2.2d	v30, v29, #0x0
100846b7c:     	ushll.2d	v29, v29, #0x0
100846b80:     	ushll.2d	v27, v27, #0x0
100846b84:     	ushll.4s	v26, v26, #0x0
100846b88:     	ushll2.2d	v31, v26, #0x0
100846b8c:     	ushll2.4s	v25, v25, #0x0
100846b90:     	ushll.2d	v8, v25, #0x0
100846b94:     	ushll.2d	v26, v26, #0x0
100846b98:     	ushll2.2d	v25, v25, #0x0
100846b9c:     	shl.2d	v9, v0, #0x3
100846ba0:     	ushl.2d	v25, v25, v9
100846ba4:     	shl.2d	v9, v19, #0x3
100846ba8:     	ushl.2d	v26, v26, v9
100846bac:     	shl.2d	v9, v1, #0x3
100846bb0:     	ushl.2d	v8, v8, v9
100846bb4:     	shl.2d	v9, v7, #0x3
100846bb8:     	ushl.2d	v31, v31, v9
100846bbc:     	shl.2d	v9, v6, #0x3
100846bc0:     	ushl.2d	v27, v27, v9
100846bc4:     	shl.2d	v9, v3, #0x3
100846bc8:     	ushl.2d	v29, v29, v9
100846bcc:     	shl.2d	v9, v2, #0x3
100846bd0:     	ushl.2d	v30, v30, v9
100846bd4:     	shl.2d	v9, v4, #0x3
100846bd8:     	ushl.2d	v28, v28, v9
100846bdc:     	orr.16b	v18, v28, v18
100846be0:     	orr.16b	v21, v30, v21
100846be4:     	orr.16b	v23, v29, v23
100846be8:     	orr.16b	v20, v27, v20
100846bec:     	orr.16b	v5, v31, v5
100846bf0:     	orr.16b	v24, v8, v24
100846bf4:     	orr.16b	v16, v26, v16
100846bf8:     	orr.16b	v22, v25, v22
100846bfc:     	add.2d	v6, v6, v17
100846c00:     	add.2d	v7, v7, v17
100846c04:     	add.2d	v19, v19, v17
100846c08:     	add.2d	v4, v4, v17
100846c0c:     	add.2d	v3, v3, v17
100846c10:     	add.2d	v2, v2, v17
100846c14:     	add.2d	v1, v1, v17
100846c18:     	add.2d	v0, v0, v17
100846c1c:     	subs	x14, x14, #0x10
100846c20:     	b.ne	0x100846b60 <_js_json_stringify_full+0x11a0>
100846c24:     	orr.16b	v0, v16, v23
100846c28:     	orr.16b	v1, v20, v24
100846c2c:     	orr.16b	v0, v0, v1
100846c30:     	orr.16b	v1, v5, v21
100846c34:     	orr.16b	v2, v18, v22
100846c38:     	orr.16b	v1, v1, v2
100846c3c:     	orr.16b	v0, v0, v1
100846c40:     	mov	d1, v0[1]
100846c44:     	orr.8b	v0, v0, v1
100846c48:     	fmov	x13, d0
100846c4c:     	cmp	x8, x11
100846c50:     	b.eq	0x100846d1c <_js_json_stringify_full+0x135c>
100846c54:     	cbz	x12, 0x100846cfc <_js_json_stringify_full+0x133c>
100846c58:     	mov	x14, x11
100846c5c:     	and	x11, x8, #0x1c
100846c60:     	add	x15, sp, #0x80
100846c64:     	add	x9, x15, x11
100846c68:     	fmov	d0, x13
100846c6c:     	movi.2d	v1, #0000000000000000
100846c70:     	dup.2d	v3, x14
100846c74:     	adrp	x12, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
100846c78:     	ldr	q2, [x12, #0x8c0]
100846c7c:     	orr.16b	v2, v3, v2
100846c80:     	adrp	x12, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x337ba>
100846c84:     	ldr	q4, [x12, #0x7c0]
100846c88:     	orr.16b	v3, v3, v4
100846c8c:     	sub	x12, x14, x11
100846c90:     	add	x13, x15, x14
100846c94:     	movi.2d	v4, #0x000000000000ff
100846c98:     	mov	w14, #0x4               ; =4
100846c9c:     	dup.2d	v5, x14
100846ca0:     	ldr	s6, [x13], #0x4
100846ca4:     	ushll.8h	v6, v6, #0x0
100846ca8:     	ushll.4s	v6, v6, #0x0
100846cac:     	ushll2.2d	v7, v6, #0x0
100846cb0:     	and.16b	v7, v7, v4
100846cb4:     	ushll.2d	v6, v6, #0x0
100846cb8:     	and.16b	v6, v6, v4
100846cbc:     	shl.2d	v16, v2, #0x3
100846cc0:     	shl.2d	v17, v3, #0x3
100846cc4:     	ushl.2d	v6, v6, v17
100846cc8:     	ushl.2d	v7, v7, v16
100846ccc:     	orr.16b	v1, v7, v1
100846cd0:     	orr.16b	v0, v6, v0
100846cd4:     	add.2d	v2, v2, v5
100846cd8:     	add.2d	v3, v3, v5
100846cdc:     	adds	x12, x12, #0x4
100846ce0:     	b.ne	0x100846ca0 <_js_json_stringify_full+0x12e0>
100846ce4:     	orr.16b	v0, v0, v1
100846ce8:     	mov	d1, v0[1]
100846cec:     	orr.8b	v0, v0, v1
100846cf0:     	fmov	x13, d0
100846cf4:     	cmp	x8, x11
100846cf8:     	b.eq	0x100846d1c <_js_json_stringify_full+0x135c>
100846cfc:     	add	x10, x10, x8
100846d00:     	lsl	x11, x11, #3
100846d04:     	ldrb	w12, [x9], #0x1
100846d08:     	lsl	x12, x12, x11
100846d0c:     	orr	x13, x12, x13
100846d10:     	add	x11, x11, #0x8
100846d14:     	cmp	x9, x10
100846d18:     	b.ne	0x100846d04 <_js_json_stringify_full+0x1344>
100846d1c:     	orr	x8, x13, x8, lsl #40
100846d20:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100846d24:     	orr	x20, x8, x9
100846d28:     	mov	x0, x20
100846d2c:     	ldp	x29, x30, [sp, #0x110]
100846d30:     	ldp	x20, x19, [sp, #0x100]
100846d34:     	ldp	x22, x21, [sp, #0xf0]
100846d38:     	ldp	x24, x23, [sp, #0xe0]
100846d3c:     	ldp	x26, x25, [sp, #0xd0]
100846d40:     	ldp	x28, x27, [sp, #0xc0]
100846d44:     	ldp	d9, d8, [sp, #0xb0]
100846d48:     	add	sp, sp, #0x120
100846d4c:     	ret
100846d50:     	cmp	w16, #0x8
100846d54:     	b.eq	0x100846de0 <_js_json_stringify_full+0x1420>
100846d58:     	cmp	w16, #0x9
100846d5c:     	b.eq	0x100846df0 <_js_json_stringify_full+0x1430>
100846d60:     	cmp	w16, #0xa
100846d64:     	b.ne	0x100846d80 <_js_json_stringify_full+0x13c0>
100846d68:     	mov	w15, #0x6e              ; =110
100846d6c:     	b	0x100846df4 <_js_json_stringify_full+0x1434>
100846d70:     	cmp	w16, #0x22
100846d74:     	b.eq	0x100846df4 <_js_json_stringify_full+0x1434>
100846d78:     	cmp	w16, #0x5c
100846d7c:     	b.eq	0x100846df4 <_js_json_stringify_full+0x1434>
100846d80:     	cmp	w15, #0x20
100846d84:     	b.lt	0x100846df8 <_js_json_stringify_full+0x1438>
100846d88:     	add	x13, sp, #0x80
100846d8c:     	strb	w15, [x13, x12]
100846d90:     	add	x12, x12, #0x1
100846d94:     	b	0x100846efc <_js_json_stringify_full+0x153c>
100846d98:     	bl	0x100b3f27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100846d9c:     	add	x8, x0, x23, lsl #3
100846da0:     	ldr	x0, [x8, #0x1e8]
100846da4:     	cbnz	x0, 0x100846308 <_js_json_stringify_full+0x948>
100846da8:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846dac:     	add	x0, x0, #0x138
100846db0:     	bl	0x100b3ca9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100846db4:     	b	0x100846308 <_js_json_stringify_full+0x948>
100846db8:     	add	x1, sp, #0x48
100846dbc:     	mov.16b	v0, v8
100846dc0:     	mov	w0, #0x0                ; =0
100846dc4:     	bl	0x10050956c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100846dc8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846dcc:     	add	x0, x0, #0xdc0
100846dd0:     	ldr	x8, [x0]
100846dd4:     	blr	x8
100846dd8:     	strb	wzr, [x0]
100846ddc:     	b	0x10084644c <_js_json_stringify_full+0xa8c>
100846de0:     	mov	w15, #0x62              ; =98
100846de4:     	b	0x100846df4 <_js_json_stringify_full+0x1434>
100846de8:     	mov	w15, #0x66              ; =102
100846dec:     	b	0x100846df4 <_js_json_stringify_full+0x1434>
100846df0:     	mov	w15, #0x74              ; =116
100846df4:     	tbz	w14, #0x0, 0x100846ee8 <_js_json_stringify_full+0x1528>
100846df8:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846dfc:     	cmp	x8, x9
100846e00:     	b.eq	0x100846e48 <_js_json_stringify_full+0x1488>
100846e04:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846e08:     	cmp	x8, x9
100846e0c:     	b.ne	0x100845a24 <_js_json_stringify_full+0x64>
100846e10:     	and	x8, x19, #0xffffffffffff
100846e14:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
100846e18:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100846e1c:     	movk	x10, #0xffef, lsl #16
100846e20:     	cmp	x9, x10
100846e24:     	b.hi	0x100845a24 <_js_json_stringify_full+0x64>
100846e28:     	ldr	w8, [x8, #0x4]
100846e2c:     	cmp	w8, #0x40
100846e30:     	b.lo	0x100845a24 <_js_json_stringify_full+0x64>
100846e34:     	and	x0, x19, #0xffffffffffff
100846e38:     	bl	0x1004f2ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100846e3c:     	cmp	x0, #0x1
100846e40:     	b.ne	0x100845a24 <_js_json_stringify_full+0x64>
100846e44:     	b	0x100845c78 <_js_json_stringify_full+0x2b8>
100846e48:     	and	x25, x19, #0xffffffffffff
100846e4c:     	and	x0, x19, #0xffffffffffff
100846e50:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100846e54:     	cbz	x0, 0x100846e88 <_js_json_stringify_full+0x14c8>
100846e58:     	ldrb	w8, [x0]
100846e5c:     	cmp	w8, #0x2
100846e60:     	b.ne	0x100846e88 <_js_json_stringify_full+0x14c8>
100846e64:     	ldrsb	w8, [x0, #0x1]
100846e68:     	tbnz	w8, #0x1f, 0x100846e88 <_js_json_stringify_full+0x14c8>
100846e6c:     	ldrh	w8, [x0, #0x2]
100846e70:     	tbnz	w8, #0xb, 0x100846e88 <_js_json_stringify_full+0x14c8>
100846e74:     	ldr	w8, [x0, #0x4]
100846e78:     	cmp	w8, #0x18
100846e7c:     	b.lo	0x100846e88 <_js_json_stringify_full+0x14c8>
100846e80:     	ldr	w8, [x25]
100846e84:     	cbz	w8, 0x100846fb4 <_js_json_stringify_full+0x15f4>
100846e88:     	and	x0, x19, #0xffffffffffff
100846e8c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100846e90:     	cbz	x0, 0x100845a24 <_js_json_stringify_full+0x64>
100846e94:     	ldrb	w8, [x0]
100846e98:     	cmp	w8, #0x2
100846e9c:     	b.ne	0x100845a24 <_js_json_stringify_full+0x64>
100846ea0:     	ldrh	w8, [x0, #0x2]
100846ea4:     	tbnz	w8, #0xb, 0x100845a24 <_js_json_stringify_full+0x64>
100846ea8:     	ldr	w8, [x0, #0x4]
100846eac:     	cmp	w8, #0x18
100846eb0:     	b.lo	0x100845a24 <_js_json_stringify_full+0x64>
100846eb4:     	ldr	w8, [x25]
100846eb8:     	cbnz	w8, 0x100845a24 <_js_json_stringify_full+0x64>
100846ebc:     	mov	x22, x0
100846ec0:     	and	x0, x19, #0xffffffffffff
100846ec4:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
100846ec8:     	cbz	x0, 0x100847040 <_js_json_stringify_full+0x1680>
100846ecc:     	ldr	w20, [x0]
100846ed0:     	cmp	w20, #0x4
100846ed4:     	b.hi	0x100845a24 <_js_json_stringify_full+0x64>
100846ed8:     	ldr	w8, [x0, #0x4]
100846edc:     	cmp	w20, w8
100846ee0:     	b.hi	0x100845a24 <_js_json_stringify_full+0x64>
100846ee4:     	b	0x100847044 <_js_json_stringify_full+0x1684>
100846ee8:     	add	x14, sp, #0x80
100846eec:     	mov	w16, #0x5c              ; =92
100846ef0:     	strb	w16, [x14, x12]
100846ef4:     	add	x12, x12, #0x2
100846ef8:     	strb	w15, [x13, #0x1]
100846efc:     	cmp	w10, #0x2
100846f00:     	b.eq	0x100846a7c <_js_json_stringify_full+0x10bc>
100846f04:     	ldrb	w11, [x11, #0x2]
100846f08:     	sxtb	w10, w11
100846f0c:     	cmp	w11, #0xb
100846f10:     	b.le	0x100846f64 <_js_json_stringify_full+0x15a4>
100846f14:     	cmp	w11, #0x21
100846f18:     	b.gt	0x100846f84 <_js_json_stringify_full+0x15c4>
100846f1c:     	cmp	w11, #0xc
100846f20:     	b.eq	0x100847010 <_js_json_stringify_full+0x1650>
100846f24:     	cmp	w11, #0xd
100846f28:     	b.ne	0x100846f94 <_js_json_stringify_full+0x15d4>
100846f2c:     	mov	w10, #0x72              ; =114
100846f30:     	b	0x10084701c <_js_json_stringify_full+0x165c>
100846f34:     	mov	x0, x25
100846f38:     	mov	w1, #0x1                ; =1
100846f3c:     	bl	0x100b5f0c8 <_mi_malloc_aligned>
100846f40:     	mov	x26, x0
100846f44:     	mov	w0, #0x1                ; =1
100846f48:     	cbz	x26, 0x100846a38 <_js_json_stringify_full+0x1078>
100846f4c:     	mov	x0, x26
100846f50:     	mov	x1, x23
100846f54:     	mov	x2, x25
100846f58:     	bl	0x100b61cec <_writev+0x100b61cec>
100846f5c:     	mov	x22, x25
100846f60:     	b	0x100846028 <_js_json_stringify_full+0x668>
100846f64:     	cmp	w11, #0x8
100846f68:     	b.eq	0x100847008 <_js_json_stringify_full+0x1648>
100846f6c:     	cmp	w11, #0x9
100846f70:     	b.eq	0x100847018 <_js_json_stringify_full+0x1658>
100846f74:     	cmp	w11, #0xa
100846f78:     	b.ne	0x100846f94 <_js_json_stringify_full+0x15d4>
100846f7c:     	mov	w10, #0x6e              ; =110
100846f80:     	b	0x10084701c <_js_json_stringify_full+0x165c>
100846f84:     	cmp	w11, #0x22
100846f88:     	b.eq	0x10084701c <_js_json_stringify_full+0x165c>
100846f8c:     	cmp	w11, #0x5c
100846f90:     	b.eq	0x10084701c <_js_json_stringify_full+0x165c>
100846f94:     	cmp	x12, #0x3
100846f98:     	mov	w11, #0x20              ; =32
100846f9c:     	ccmp	w10, w11, #0x8, ls
100846fa0:     	b.lt	0x100846df8 <_js_json_stringify_full+0x1438>
100846fa4:     	add	x8, sp, #0x80
100846fa8:     	strb	w10, [x8, x12]
100846fac:     	add	x12, x12, #0x1
100846fb0:     	b	0x100846a7c <_js_json_stringify_full+0x10bc>
100846fb4:     	mov	x1, x0
100846fb8:     	and	x0, x19, #0xffffffffffff
100846fbc:     	mov	x22, x1
100846fc0:     	bl	0x1004f8e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
100846fc4:     	cmp	x0, #0x1
100846fc8:     	b.ne	0x1008470ec <_js_json_stringify_full+0x172c>
100846fcc:     	mov	x20, x1
100846fd0:     	b	0x100846d28 <_js_json_stringify_full+0x1368>
100846fd4:     	ldrb	w9, [x8, #0x118]
100846fd8:     	cbz	w9, 0x100847214 <_js_json_stringify_full+0x1854>
100846fdc:     	ldr	x9, [x8, #0x110]
100846fe0:     	cmp	x9, x1
100846fe4:     	b.ne	0x100847214 <_js_json_stringify_full+0x1854>
100846fe8:     	ldr	x9, [x8, #0xf0]
100846fec:     	cmp	x9, x23
100846ff0:     	b.hi	0x100847214 <_js_json_stringify_full+0x1854>
100846ff4:     	ldr	x9, [x8, #0xf8]
100846ff8:     	cmp	x9, x23
100846ffc:     	b.ls	0x100847214 <_js_json_stringify_full+0x1854>
100847000:     	add	x9, x8, #0xf0
100847004:     	b	0x100847420 <_js_json_stringify_full+0x1a60>
100847008:     	mov	w10, #0x62              ; =98
10084700c:     	b	0x10084701c <_js_json_stringify_full+0x165c>
100847010:     	mov	w10, #0x66              ; =102
100847014:     	b	0x10084701c <_js_json_stringify_full+0x165c>
100847018:     	mov	w10, #0x74              ; =116
10084701c:     	cmp	x12, #0x2
100847020:     	b.hi	0x100846df8 <_js_json_stringify_full+0x1438>
100847024:     	add	x8, sp, #0x80
100847028:     	add	x8, x8, x12
10084702c:     	add	x12, x12, #0x2
100847030:     	mov	w11, #0x5c              ; =92
100847034:     	strb	w11, [x8]
100847038:     	strb	w10, [x8, #0x1]
10084703c:     	b	0x100846a7c <_js_json_stringify_full+0x10bc>
100847040:     	mov	x20, #0x0               ; =0
100847044:     	ldr	w8, [x22, #0x4]
100847048:     	lsl	x9, x20, #3
10084704c:     	add	x9, x9, #0x18
100847050:     	cmp	x9, x8
100847054:     	b.hi	0x100845a24 <_js_json_stringify_full+0x64>
100847058:     	ldr	w8, [x25, #0x4]
10084705c:     	mov	w9, #-0x40000000        ; =-1073741824
100847060:     	cmp	w8, w9
100847064:     	csel	w8, w8, wzr, lt
100847068:     	mov	x22, x0
10084706c:     	mov	x0, x8
100847070:     	bl	0x1005e56e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100847074:     	mov	w9, #0x2                ; =2
100847078:     	cmp	w1, #0x2
10084707c:     	csel	w10, w1, w9, hi
100847080:     	tst	w0, #0x1
100847084:     	csel	x8, x10, x9, ne
100847088:     	cmp	x20, x8
10084708c:     	b.hi	0x100845a24 <_js_json_stringify_full+0x64>
100847090:     	cbz	x20, 0x100847450 <_js_json_stringify_full+0x1a90>
100847094:     	mov	x0, x22
100847098:     	mov	x1, x20
10084709c:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008470a0:     	tbz	w0, #0x0, 0x100845a24 <_js_json_stringify_full+0x64>
1008470a4:     	cmp	x20, #0x1
1008470a8:     	b.eq	0x1008474ec <_js_json_stringify_full+0x1b2c>
1008470ac:     	cmp	x20, #0x2
1008470b0:     	b.ne	0x1008475a8 <_js_json_stringify_full+0x1be8>
1008470b4:     	mov	x22, #0x0               ; =0
1008470b8:     	add	x25, x25, #0x10
1008470bc:     	mov	w8, #0x1                ; =1
1008470c0:     	mov	x26, x8
1008470c4:     	ldr	x1, [x25, x22, lsl #3]
1008470c8:     	add	x0, sp, #0x80
1008470cc:     	bl	0x1004efe14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
1008470d0:     	ldr	w8, [sp, #0x80]
1008470d4:     	cmn	w8, #0x1
1008470d8:     	b.ne	0x100847590 <_js_json_stringify_full+0x1bd0>
1008470dc:     	mov	w8, #0x0                ; =0
1008470e0:     	mov	w22, #0x1               ; =1
1008470e4:     	tbnz	w26, #0x0, 0x1008470c0 <_js_json_stringify_full+0x1700>
1008470e8:     	b	0x1008475a8 <_js_json_stringify_full+0x1be8>
1008470ec:     	and	x0, x19, #0xffffffffffff
1008470f0:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1008470f4:     	cbz	x0, 0x100847180 <_js_json_stringify_full+0x17c0>
1008470f8:     	ldr	w20, [x0]
1008470fc:     	cbz	w20, 0x100847180 <_js_json_stringify_full+0x17c0>
100847100:     	cmp	w20, #0x8
100847104:     	b.hi	0x100846e88 <_js_json_stringify_full+0x14c8>
100847108:     	ldr	w8, [x0, #0x4]
10084710c:     	cmp	w20, w8
100847110:     	b.hi	0x100846e88 <_js_json_stringify_full+0x14c8>
100847114:     	ldr	w8, [x22, #0x4]
100847118:     	lsl	x9, x20, #3
10084711c:     	add	x9, x9, #0x18
100847120:     	cmp	x9, x8
100847124:     	b.hi	0x100846e88 <_js_json_stringify_full+0x14c8>
100847128:     	ldr	w8, [x25, #0x4]
10084712c:     	mov	w9, #-0x40000000        ; =-1073741824
100847130:     	cmp	w8, w9
100847134:     	csel	w8, w8, wzr, lt
100847138:     	mov	x22, x0
10084713c:     	mov	x0, x8
100847140:     	bl	0x1005e56e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100847144:     	mov	w9, #0x2                ; =2
100847148:     	cmp	w1, #0x2
10084714c:     	csel	w10, w1, w9, hi
100847150:     	tst	w0, #0x1
100847154:     	csel	w8, w10, w9, ne
100847158:     	cmp	w20, w8
10084715c:     	b.hi	0x100846e88 <_js_json_stringify_full+0x14c8>
100847160:     	mov	x0, x22
100847164:     	mov	x1, x20
100847168:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084716c:     	cbz	w0, 0x100846e88 <_js_json_stringify_full+0x14c8>
100847170:     	and	x0, x19, #0xffffffffffff
100847174:     	mov	x1, x20
100847178:     	bl	0x1004f7f40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
10084717c:     	b	0x100847188 <_js_json_stringify_full+0x17c8>
100847180:     	and	x0, x19, #0xffffffffffff
100847184:     	bl	0x1004f8cc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
100847188:     	mov	x20, x1
10084718c:     	tbnz	w0, #0x0, 0x100846d28 <_js_json_stringify_full+0x1368>
100847190:     	b	0x100846e88 <_js_json_stringify_full+0x14c8>
100847194:     	add	x9, x8, #0x60
100847198:     	b	0x100847420 <_js_json_stringify_full+0x1a60>
10084719c:     	bl	0x100b3f27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008471a0:     	lsr	x1, x23, #20
1008471a4:     	ldr	x8, [x0, #0x10]
1008471a8:     	ldrb	w9, [x8]
1008471ac:     	cmp	w9, #0x2
1008471b0:     	b.eq	0x1008460e4 <_js_json_stringify_full+0x724>
1008471b4:     	ldr	x9, [x8, #0x8]
1008471b8:     	ldr	x10, [x8, #0x28]
1008471bc:     	sub	x9, x1, x9
1008471c0:     	cmp	x9, x10
1008471c4:     	b.hs	0x100847208 <_js_json_stringify_full+0x1848>
1008471c8:     	ldr	x10, [x8, #0x20]
1008471cc:     	mov	w11, #0x28              ; =40
1008471d0:     	madd	x9, x9, x11, x10
1008471d4:     	ldr	x10, [x9]
1008471d8:     	ldr	x11, [x8, #0x10]
1008471dc:     	cmp	x10, x11
1008471e0:     	b.ne	0x100847214 <_js_json_stringify_full+0x1854>
1008471e4:     	ldp	x10, x11, [x9, #0x8]
1008471e8:     	cmp	x10, x23
1008471ec:     	ccmp	x11, x23, #0x0, ls
1008471f0:     	b.ls	0x100847214 <_js_json_stringify_full+0x1854>
1008471f4:     	ldr	x10, [x8, #0x30]
1008471f8:     	add	x10, x10, #0x1
1008471fc:     	str	x10, [x8, #0x30]
100847200:     	add	x8, x9, #0x21
100847204:     	b	0x100847430 <_js_json_stringify_full+0x1a70>
100847208:     	ldr	x9, [x8, #0x58]
10084720c:     	add	x9, x9, #0x1
100847210:     	str	x9, [x8, #0x58]
100847214:     	ldr	x9, [x8, #0x38]
100847218:     	add	x9, x9, #0x1
10084721c:     	str	x9, [x8, #0x38]
100847220:     	mov	x0, x23
100847224:     	bl	0x10051e348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100847228:     	and	w8, w0, #0xff
10084722c:     	cbz	w8, 0x10084724c <_js_json_stringify_full+0x188c>
100847230:     	ldurb	w8, [x23, #-0x8]
100847234:     	ldurb	w9, [x23, #-0x7]
100847238:     	mov	w10, #0x82              ; =130
10084723c:     	and	w9, w9, w10
100847240:     	cmp	w9, #0x2
100847244:     	ccmp	w8, #0x1, #0x0, eq
100847248:     	b.eq	0x1008472e0 <_js_json_stringify_full+0x1920>
10084724c:     	mov	x0, x23
100847250:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847254:     	mov	x24, x0
100847258:     	cbz	x0, 0x100847284 <_js_json_stringify_full+0x18c4>
10084725c:     	ldrb	w8, [x24]
100847260:     	cmp	w8, #0x1
100847264:     	b.ne	0x1008472a4 <_js_json_stringify_full+0x18e4>
100847268:     	ldrsb	w8, [x24, #0x1]
10084726c:     	tbnz	w8, #0x1f, 0x100847308 <_js_json_stringify_full+0x1948>
100847270:     	mov	x0, x24
100847274:     	ldp	w9, w8, [x23]
100847278:     	cmp	w9, w8
10084727c:     	b.hi	0x10084738c <_js_json_stringify_full+0x19cc>
100847280:     	b	0x1008473a4 <_js_json_stringify_full+0x19e4>
100847284:     	mov	x0, x23
100847288:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10084728c:     	tbnz	w0, #0x0, 0x10084729c <_js_json_stringify_full+0x18dc>
100847290:     	mov	x0, x23
100847294:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100847298:     	tbz	w0, #0x0, 0x100846184 <_js_json_stringify_full+0x7c4>
10084729c:     	mov	x0, #0x0                ; =0
1008472a0:     	b	0x10084737c <_js_json_stringify_full+0x19bc>
1008472a4:     	mov	x0, x24
1008472a8:     	cmp	w8, #0x1
1008472ac:     	b.eq	0x10084737c <_js_json_stringify_full+0x19bc>
1008472b0:     	cmp	w8, #0x9
1008472b4:     	b.ne	0x100846184 <_js_json_stringify_full+0x7c4>
1008472b8:     	ldr	w8, [x23, #0x4]
1008472bc:     	mov	w9, #0x5841             ; =22593
1008472c0:     	movk	w9, #0x4c5a, lsl #16
1008472c4:     	cmp	w8, w9
1008472c8:     	b.ne	0x100846184 <_js_json_stringify_full+0x7c4>
1008472cc:     	mov	x0, x23
1008472d0:     	bl	0x1003759b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1008472d4:     	mov	x23, x0
1008472d8:     	cbnz	x0, 0x1008473cc <_js_json_stringify_full+0x1a0c>
1008472dc:     	b	0x100846184 <_js_json_stringify_full+0x7c4>
1008472e0:     	ldr	w8, [x23]
1008472e4:     	mov	w9, #0xe100             ; =57600
1008472e8:     	movk	w9, #0x5f5, lsl #16
1008472ec:     	orr	w9, w9, #0x1
1008472f0:     	cmp	w8, w9
1008472f4:     	b.hs	0x10084724c <_js_json_stringify_full+0x188c>
1008472f8:     	ldr	w9, [x23, #0x4]
1008472fc:     	cmp	w8, w9
100847300:     	b.ls	0x1008473cc <_js_json_stringify_full+0x1a0c>
100847304:     	b	0x10084724c <_js_json_stringify_full+0x188c>
100847308:     	ldr	x23, [x24, #0x8]
10084730c:     	mov	x0, x23
100847310:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847314:     	cbz	x0, 0x100846184 <_js_json_stringify_full+0x7c4>
100847318:     	ldrb	w8, [x0]
10084731c:     	cmp	w8, #0x1
100847320:     	b.ne	0x100846184 <_js_json_stringify_full+0x7c4>
100847324:     	ldrsb	w8, [x0, #0x1]
100847328:     	tbz	w8, #0x1f, 0x100847274 <_js_json_stringify_full+0x18b4>
10084732c:     	mov	w26, #0x1               ; =1
100847330:     	ldr	x23, [x0, #0x8]
100847334:     	mov	x0, x23
100847338:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084733c:     	cbz	x0, 0x100846184 <_js_json_stringify_full+0x7c4>
100847340:     	ldrb	w8, [x0]
100847344:     	cmp	w8, #0x1
100847348:     	b.ne	0x100846184 <_js_json_stringify_full+0x7c4>
10084734c:     	cmp	w26, #0x3f
100847350:     	b.hi	0x100846184 <_js_json_stringify_full+0x7c4>
100847354:     	add	w26, w26, #0x1
100847358:     	ldrsb	w8, [x0, #0x1]
10084735c:     	tbnz	w8, #0x1f, 0x100847330 <_js_json_stringify_full+0x1970>
100847360:     	str	x23, [x24, #0x8]
100847364:     	ldrb	w8, [x24, #0x1]
100847368:     	orr	w8, w8, #0x80
10084736c:     	strb	w8, [x24, #0x1]
100847370:     	ldrb	w8, [x0]
100847374:     	cmp	w8, #0x1
100847378:     	b.ne	0x1008472b0 <_js_json_stringify_full+0x18f0>
10084737c:     	ldp	w9, w8, [x23]
100847380:     	cmp	w9, w8
100847384:     	b.ls	0x1008473a4 <_js_json_stringify_full+0x19e4>
100847388:     	cbz	x24, 0x1008473b4 <_js_json_stringify_full+0x19f4>
10084738c:     	ldr	w9, [x0, #0x4]
100847390:     	ubfiz	x8, x8, #3, #32
100847394:     	add	x8, x8, #0x10
100847398:     	cmp	x8, x9
10084739c:     	b.eq	0x1008473cc <_js_json_stringify_full+0x1a0c>
1008473a0:     	b	0x1008473b4 <_js_json_stringify_full+0x19f4>
1008473a4:     	mov	w8, #0xe100             ; =57600
1008473a8:     	movk	w8, #0x5f5, lsl #16
1008473ac:     	cmp	w9, w8
1008473b0:     	b.ls	0x1008473cc <_js_json_stringify_full+0x1a0c>
1008473b4:     	mov	x0, x23
1008473b8:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1008473bc:     	tbnz	w0, #0x0, 0x1008473cc <_js_json_stringify_full+0x1a0c>
1008473c0:     	mov	x0, x23
1008473c4:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
1008473c8:     	tbz	w0, #0x0, 0x100846184 <_js_json_stringify_full+0x7c4>
1008473cc:     	ldp	w8, w9, [x23]
1008473d0:     	sub	w10, w9, #0x1
1008473d4:     	mov	w11, #0x270f            ; =9999
1008473d8:     	cmp	w10, w11
1008473dc:     	ccmp	w8, w9, #0x2, lo
1008473e0:     	b.hi	0x100846184 <_js_json_stringify_full+0x7c4>
1008473e4:     	and	x8, x21, #0xffffffffffff
1008473e8:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008473ec:     	cmp	x25, x9
1008473f0:     	csel	x1, x8, x21, eq
1008473f4:     	add	x0, sp, #0x30
1008473f8:     	bl	0x1004ffc78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
1008473fc:     	ldr	x25, [sp, #0x30]
100847400:     	cmn	x25, #0x1
100847404:     	cset	w24, eq
100847408:     	cmp	x27, #0x1
10084740c:     	cset	w8, hi
100847410:     	tst	w8, w24
100847414:     	b.ne	0x1008461a0 <_js_json_stringify_full+0x7e0>
100847418:     	b	0x100846210 <_js_json_stringify_full+0x850>
10084741c:     	add	x9, x8, #0x90
100847420:     	ldr	x10, [x8, #0x30]
100847424:     	add	x10, x10, #0x1
100847428:     	str	x10, [x8, #0x30]
10084742c:     	add	x8, x9, #0x19
100847430:     	ldrb	w8, [x8]
100847434:     	cmp	w8, #0xff
100847438:     	b.ne	0x10084722c <_js_json_stringify_full+0x186c>
10084743c:     	b	0x100847220 <_js_json_stringify_full+0x1860>
100847440:     	mov	x0, x23
100847444:     	bl	0x100b1e404 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847448:     	cbnz	x0, 0x10084632c <_js_json_stringify_full+0x96c>
10084744c:     	b	0x1008475c8 <_js_json_stringify_full+0x1c08>
100847450:     	and	x0, x19, #0xffffffffffff
100847454:     	bl	0x1004f7d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
100847458:     	mov	w0, w0
10084745c:     	mov	x20, #0x7d7b            ; =32123
100847460:     	movk	x20, #0x200, lsl #32
100847464:     	movk	x20, #0x7ff9, lsl #48
100847468:     	tbz	w0, #0x0, 0x100845a24 <_js_json_stringify_full+0x64>
10084746c:     	b	0x100846d28 <_js_json_stringify_full+0x1368>
100847470:     	mov	x19, x0
100847474:     	mov	x0, x23
100847478:     	bl	0x100b1e404 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084747c:     	mov	x23, x0
100847480:     	mov	x0, x19
100847484:     	cbnz	x23, 0x100846910 <_js_json_stringify_full+0xf50>
100847488:     	b	0x100847568 <_js_json_stringify_full+0x1ba8>
10084748c:     	bl	0x100b1e564 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100847490:     	cbnz	x0, 0x100846254 <_js_json_stringify_full+0x894>
100847494:     	b	0x1008475c8 <_js_json_stringify_full+0x1c08>
100847498:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10084749c:     	add	x0, x0, #0x440
1008474a0:     	bl	0x100b125ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008474a4:     	cmp	w8, #0x1
1008474a8:     	b.ne	0x1008475c8 <_js_json_stringify_full+0x1c08>
1008474ac:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008474b0:     	add	x1, x1, #0x998
1008474b4:     	mov	x19, x0
1008474b8:     	bl	0x100a202dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008474bc:     	mov	x0, x19
1008474c0:     	strb	wzr, [x19, #0x20]
1008474c4:     	ldr	x8, [x19]
1008474c8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1008474cc:     	cmp	x8, x9
1008474d0:     	b.lo	0x100846474 <_js_json_stringify_full+0xab4>
1008474d4:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008474d8:     	add	x0, x0, #0xea8
1008474dc:     	bl	0x100b125dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1008474e0:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008474e4:     	add	x0, x0, #0xec0
1008474e8:     	bl	0x100b125ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008474ec:     	and	x0, x19, #0xffffffffffff
1008474f0:     	bl	0x1004ef9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
1008474f4:     	mov	x20, x1
1008474f8:     	tbz	w0, #0x0, 0x100845a24 <_js_json_stringify_full+0x64>
1008474fc:     	b	0x100846d28 <_js_json_stringify_full+0x1368>
100847500:     	mov	x0, x23
100847504:     	bl	0x100b1e404 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847508:     	mov	x23, x0
10084750c:     	cbnz	x0, 0x1008467c0 <_js_json_stringify_full+0xe00>
100847510:     	b	0x100847568 <_js_json_stringify_full+0x1ba8>
100847514:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100847518:     	add	x0, x0, #0xd70
10084751c:     	bl	0x100b125dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100847520:     	bl	0x100b4b7d4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
100847524:     	cmp	w8, #0x2
100847528:     	b.eq	0x1008475c8 <_js_json_stringify_full+0x1c08>
10084752c:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847530:     	add	x1, x1, #0x998
100847534:     	mov	x19, x0
100847538:     	bl	0x100a202dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084753c:     	mov	x0, x19
100847540:     	strb	wzr, [x19, #0x20]
100847544:     	ldr	x8, [x19]
100847548:     	cbz	x8, 0x1008467ac <_js_json_stringify_full+0xdec>
10084754c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847550:     	add	x0, x0, #0xe90
100847554:     	bl	0x100b125ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847558:     	mov	x0, x23
10084755c:     	bl	0x100b1e404 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847560:     	mov	x23, x0
100847564:     	cbnz	x0, 0x1008466dc <_js_json_stringify_full+0xd1c>
100847568:     	cbz	x22, 0x1008475c8 <_js_json_stringify_full+0x1c08>
10084756c:     	mov	x0, x19
100847570:     	bl	0x100b5ee40 <_mi_free>
100847574:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847578:     	add	x0, x0, #0xc18
10084757c:     	bl	0x100b5849c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100847580:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0xbf4>
100847584:     	add	x0, x0, #0x330
100847588:     	mov	w1, #0xf                ; =15
10084758c:     	bl	0x100b4b79c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100847590:     	and	x0, x19, #0xffffffffffff
100847594:     	add	x2, sp, #0x80
100847598:     	mov	x1, x22
10084759c:     	bl	0x1004f01c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
1008475a0:     	tbnz	w0, #0x0, 0x100846fcc <_js_json_stringify_full+0x160c>
1008475a4:     	mov	w20, #0x2               ; =2
1008475a8:     	and	x0, x19, #0xffffffffffff
1008475ac:     	mov	x1, x20
1008475b0:     	bl	0x1004ee840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
1008475b4:     	mov	x20, x1
1008475b8:     	tbz	w0, #0x0, 0x100845a24 <_js_json_stringify_full+0x64>
1008475bc:     	b	0x100846d28 <_js_json_stringify_full+0x1368>
1008475c0:     	cmp	w8, #0x2
1008475c4:     	b.ne	0x1008475f0 <_js_json_stringify_full+0x1c30>
1008475c8:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1008475cc:     	add	x0, x0, #0xc18
1008475d0:     	bl	0x100b5849c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1008475d4:     	adrp	x0, 0x100f2b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x1d8>
1008475d8:     	add	x0, x0, #0x800
1008475dc:     	bl	0x100b12670 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
1008475e0:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0xbf4>
1008475e4:     	add	x0, x0, #0x67
1008475e8:     	mov	w1, #0xb                ; =11
1008475ec:     	bl	0x100b4b79c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
1008475f0:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008475f4:     	add	x1, x1, #0x998
1008475f8:     	mov	x19, x0
1008475fc:     	bl	0x100a202dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847600:     	mov	x0, x19
100847604:     	strb	wzr, [x19, #0x20]
100847608:     	ldr	x8, [x19]
10084760c:     	cbz	x8, 0x1008466c8 <_js_json_stringify_full+0xd08>
100847610:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847614:     	add	x0, x0, #0xe78
100847618:     	bl	0x100b125ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084761c:     	mov	w0, #0x1                ; =1
100847620:     	mov	x1, x24
100847624:     	bl	0x100b12200 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847628:     	mov	w0, #0x1                ; =1
10084762c:     	mov	x1, x22
100847630:     	bl	0x100b12200 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847634:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100847638:     	add	x2, x2, #0x3c8
10084763c:     	mov	w0, #0x5                ; =5
100847640:     	mov	w1, #0x5                ; =5
100847644:     	bl	0x100b1270c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
		...
