
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100848e54 <_js_json_parse>:
100848e54:     	stp	x29, x30, [sp, #-0x10]!
100848e58:     	mov	x29, sp
100848e5c:     	cbz	x0, 0x100848eb4 <_js_json_parse+0x60>
100848e60:     	ldr	w1, [x0, #0x4]
100848e64:     	cmp	w1, #0x2
100848e68:     	b.eq	0x100848e78 <_js_json_parse+0x24>
100848e6c:     	cbz	w1, 0x100848eb4 <_js_json_parse+0x60>
100848e70:     	ldrb	w8, [x0, #0x14]
100848e74:     	b	0x100848e98 <_js_json_parse+0x44>
100848e78:     	ldrb	w8, [x0, #0x14]
100848e7c:     	cmp	w8, #0x7b
100848e80:     	b.ne	0x100848e98 <_js_json_parse+0x44>
100848e84:     	ldrb	w8, [x0, #0x15]
100848e88:     	cmp	w8, #0x7d
100848e8c:     	b.ne	0x100848ea4 <_js_json_parse+0x50>
100848e90:     	ldp	x29, x30, [sp], #0x10
100848e94:     	b	0x1004ef3c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100848e98:     	orr	w8, w8, #0x20
100848e9c:     	cmp	w8, #0x7b
100848ea0:     	b.ne	0x100848eac <_js_json_parse+0x58>
100848ea4:     	ldp	x29, x30, [sp], #0x10
100848ea8:     	b	0x100508b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
100848eac:     	ldp	x29, x30, [sp], #0x10
100848eb0:     	b	0x10050b2cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100848eb4:     	adrp	x0, 0x100c7a000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x7114>
100848eb8:     	add	x0, x0, #0x37d
100848ebc:     	mov	w1, #0x1c               ; =28
100848ec0:     	bl	0x10050b700 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
