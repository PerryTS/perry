
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100849b6c <_js_json_stringify>:
100849b6c:     	sub	sp, sp, #0x80
100849b70:     	stp	d9, d8, [sp, #0x20]
100849b74:     	stp	x26, x25, [sp, #0x30]
100849b78:     	stp	x24, x23, [sp, #0x40]
100849b7c:     	stp	x22, x21, [sp, #0x50]
100849b80:     	stp	x20, x19, [sp, #0x60]
100849b84:     	stp	x29, x30, [sp, #0x70]
100849b88:     	add	x29, sp, #0x70
100849b8c:     	mov	x21, x0
100849b90:     	mov.16b	v8, v0
100849b94:     	fmov	x19, d8
100849b98:     	and	x20, x19, #0xffff000000000000
100849b9c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100849ba0:     	cmp	x20, x8
100849ba4:     	b.ne	0x100849bcc <_js_json_stringify+0x60>
100849ba8:     	and	x0, x19, #0xffffffffffff
100849bac:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
100849bb0:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100849bb4:     	movk	x9, #0xffef, lsl #16
100849bb8:     	cmp	x8, x9
100849bbc:     	b.hi	0x100849bcc <_js_json_stringify+0x60>
100849bc0:     	ldr	w8, [x0, #0x4]
100849bc4:     	cmp	w8, #0x40
100849bc8:     	b.hs	0x100849c3c <_js_json_stringify+0xd0>
100849bcc:     	mov.16b	v0, v8
100849bd0:     	bl	0x1004f0a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100849bd4:     	tbz	w0, #0x0, 0x100849be0 <_js_json_stringify+0x74>
100849bd8:     	mov	x23, x1
100849bdc:     	b	0x10084a150 <_js_json_stringify+0x5e4>
100849be0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100849be4:     	cmp	x20, x8
100849be8:     	b.ne	0x100849c50 <_js_json_stringify+0xe4>
100849bec:     	ands	x19, x19, #0xffffffffffff
100849bf0:     	b.eq	0x100849c50 <_js_json_stringify+0xe4>
100849bf4:     	mov	x0, x19
100849bf8:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100849bfc:     	cbz	w0, 0x100849c50 <_js_json_stringify+0xe4>
100849c00:     	ldurb	w8, [x19, #-0x8]
100849c04:     	cmp	w8, #0x9
100849c08:     	b.ne	0x100849c50 <_js_json_stringify+0xe4>
100849c0c:     	ldr	w8, [x19, #0x4]
100849c10:     	mov	w9, #0x5841             ; =22593
100849c14:     	movk	w9, #0x4c5a, lsl #16
100849c18:     	cmp	w8, w9
100849c1c:     	b.ne	0x100849c50 <_js_json_stringify+0xe4>
100849c20:     	mov	x0, x19
100849c24:     	bl	0x10068bc64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100849c28:     	cbz	x0, 0x100849c50 <_js_json_stringify+0xe4>
100849c2c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100849c30:     	bfxil	x8, x0, #0, #48
100849c34:     	fmov	d8, x8
100849c38:     	b	0x100849c50 <_js_json_stringify+0xe4>
100849c3c:     	bl	0x1004f5968 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100849c40:     	tbnz	w0, #0x0, 0x100849bd8 <_js_json_stringify+0x6c>
100849c44:     	mov.16b	v0, v8
100849c48:     	bl	0x1004f0a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100849c4c:     	tbnz	w0, #0x0, 0x100849bd8 <_js_json_stringify+0x6c>
100849c50:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849c54:     	add	x0, x0, #0xd78
100849c58:     	ldr	x8, [x0]
100849c5c:     	blr	x8
100849c60:     	mov	x19, x0
100849c64:     	ldr	w26, [x0]
100849c68:     	add	w8, w26, #0x1
100849c6c:     	str	w8, [x0]
100849c70:     	cbz	w26, 0x100849ce0 <_js_json_stringify+0x174>
100849c74:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849c78:     	add	x0, x0, #0xd00
100849c7c:     	ldr	x8, [x0]
100849c80:     	blr	x8
100849c84:     	ldrb	w8, [x0, #0x20]
100849c88:     	cmp	w8, #0x1
100849c8c:     	b.ne	0x10084a244 <_js_json_stringify+0x6d8>
100849c90:     	ldr	x8, [x0]
100849c94:     	cbnz	x8, 0x10084a250 <_js_json_stringify+0x6e4>
100849c98:     	mov	x8, #-0x1               ; =-1
100849c9c:     	str	x8, [x0]
100849ca0:     	ldr	x20, [x0, #0x18]
100849ca4:     	ldr	x8, [x0, #0x8]
100849ca8:     	cmp	x20, x8
100849cac:     	b.eq	0x10084a174 <_js_json_stringify+0x608>
100849cb0:     	ldr	x8, [x0, #0x10]
100849cb4:     	mov	w9, #0x18               ; =24
100849cb8:     	madd	x8, x20, x9, x8
100849cbc:     	mov	w9, #0x8                ; =8
100849cc0:     	stp	xzr, x9, [x8]
100849cc4:     	str	xzr, [x8, #0x10]
100849cc8:     	add	x8, x20, #0x1
100849ccc:     	str	x8, [x0, #0x18]
100849cd0:     	ldr	x8, [x0]
100849cd4:     	add	x8, x8, #0x1
100849cd8:     	str	x8, [x0]
100849cdc:     	b	0x100849d6c <_js_json_stringify+0x200>
100849ce0:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849ce4:     	add	x0, x0, #0xdc0
100849ce8:     	ldr	x8, [x0]
100849cec:     	blr	x8
100849cf0:     	strb	wzr, [x0]
100849cf4:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849cf8:     	add	x0, x0, #0xdf0
100849cfc:     	ldr	x8, [x0]
100849d00:     	blr	x8
100849d04:     	strb	wzr, [x0]
100849d08:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
100849d0c:     	ldr	w20, [x8, #0x5a8]
100849d10:     	cmp	w20, #0x300
100849d14:     	b.hs	0x10084a1d0 <_js_json_stringify+0x664>
100849d18:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
100849d1c:     	ldr	x8, [x8, #0x48]
100849d20:     	cmn	x8, #0x1
100849d24:     	b.eq	0x10084a1c0 <_js_json_stringify+0x654>
100849d28:     	mrs	x9, TPIDRRO_EL0
100849d2c:     	and	x9, x9, #0xfffffffffffffff8
100849d30:     	ldr	x0, [x9, x8, lsl #3]
100849d34:     	cbz	x0, 0x10084a1c0 <_js_json_stringify+0x654>
100849d38:     	add	x8, x0, x20, lsl #3
100849d3c:     	ldr	x0, [x8, #0x1e8]
100849d40:     	cbz	x0, 0x10084a1d0 <_js_json_stringify+0x664>
100849d44:     	str	xzr, [x0]
100849d48:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849d4c:     	add	x0, x0, #0xd90
100849d50:     	ldr	x8, [x0]
100849d54:     	blr	x8
100849d58:     	ldrb	w8, [x0, #0x20]
100849d5c:     	cbnz	w8, 0x10084a25c <_js_json_stringify+0x6f0>
100849d60:     	ldr	x8, [x0]
100849d64:     	cbnz	x8, 0x10084a284 <_js_json_stringify+0x718>
100849d68:     	str	xzr, [x0, #0x18]
100849d6c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849d70:     	add	x0, x0, #0xd30
100849d74:     	ldr	x8, [x0]
100849d78:     	blr	x8
100849d7c:     	mov	x20, x0
100849d80:     	ldrb	w8, [x0, #0x18]
100849d84:     	cmp	w8, #0x1
100849d88:     	b.ne	0x10084a1e0 <_js_json_stringify+0x674>
100849d8c:     	ldr	x8, [x0]
100849d90:     	mov	x9, #-0x1               ; =-1
100849d94:     	str	x9, [x0]
100849d98:     	cmn	x8, #0x2
100849d9c:     	b.eq	0x10084a290 <_js_json_stringify+0x724>
100849da0:     	cmn	x8, #0x1
100849da4:     	b.eq	0x100849db8 <_js_json_stringify+0x24c>
100849da8:     	add	x9, sp, #0x8
100849dac:     	ldur	q0, [x0, #0x8]
100849db0:     	stur	q0, [x9, #0x8]
100849db4:     	b	0x100849dc4 <_js_json_stringify+0x258>
100849db8:     	mov	x8, #0x0                ; =0
100849dbc:     	mov	w9, #0x1                ; =1
100849dc0:     	stp	x9, xzr, [sp, #0x10]
100849dc4:     	str	x8, [sp, #0x8]
100849dc8:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849dcc:     	add	x0, x0, #0xd18
100849dd0:     	ldr	x8, [x0]
100849dd4:     	blr	x8
100849dd8:     	ldrb	w8, [x0, #0x20]
100849ddc:     	cbnz	w8, 0x10084a210 <_js_json_stringify+0x6a4>
100849de0:     	ldr	x8, [x0]
100849de4:     	cbnz	x8, 0x10084a238 <_js_json_stringify+0x6cc>
100849de8:     	str	xzr, [x0, #0x18]
100849dec:     	add	x1, sp, #0x8
100849df0:     	mov.16b	v0, v8
100849df4:     	mov	x0, x21
100849df8:     	bl	0x10050c444 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100849dfc:     	ldp	x21, x22, [sp, #0x10]
100849e00:     	cmp	w22, #0x80, lsl #12     ; =0x80000
100849e04:     	b.hs	0x100849ec4 <_js_json_stringify+0x358>
100849e08:     	cmp	x22, #0x40
100849e0c:     	b.hs	0x100849f88 <_js_json_stringify+0x41c>
100849e10:     	ands	x9, x22, #0x38
100849e14:     	b.eq	0x100849e38 <_js_json_stringify+0x2cc>
100849e18:     	and	x8, x22, #0x38
100849e1c:     	neg	x8, x8
100849e20:     	mov	x10, x21
100849e24:     	ldr	x11, [x10], #0x8
100849e28:     	tst	x11, #0x8080808080808080
100849e2c:     	b.ne	0x100849eac <_js_json_stringify+0x340>
100849e30:     	adds	x8, x8, #0x8
100849e34:     	b.ne	0x100849e24 <_js_json_stringify+0x2b8>
100849e38:     	and	x8, x22, #0x7
100849e3c:     	cbz	x8, 0x10084a00c <_js_json_stringify+0x4a0>
100849e40:     	add	x9, x21, x9
100849e44:     	ldrsb	w10, [x9]
100849e48:     	tbnz	w10, #0x1f, 0x100849eac <_js_json_stringify+0x340>
100849e4c:     	cmp	x8, #0x1
100849e50:     	b.eq	0x10084a00c <_js_json_stringify+0x4a0>
100849e54:     	ldrsb	w10, [x9, #0x1]
100849e58:     	tbnz	w10, #0x1f, 0x100849eac <_js_json_stringify+0x340>
100849e5c:     	cmp	x8, #0x2
100849e60:     	b.eq	0x10084a00c <_js_json_stringify+0x4a0>
100849e64:     	ldrsb	w10, [x9, #0x2]
100849e68:     	tbnz	w10, #0x1f, 0x100849eac <_js_json_stringify+0x340>
100849e6c:     	cmp	x8, #0x3
100849e70:     	b.eq	0x10084a00c <_js_json_stringify+0x4a0>
100849e74:     	ldrsb	w10, [x9, #0x3]
100849e78:     	tbnz	w10, #0x1f, 0x100849eac <_js_json_stringify+0x340>
100849e7c:     	cmp	x8, #0x4
100849e80:     	b.eq	0x10084a00c <_js_json_stringify+0x4a0>
100849e84:     	ldrsb	w10, [x9, #0x4]
100849e88:     	tbnz	w10, #0x1f, 0x100849eac <_js_json_stringify+0x340>
100849e8c:     	cmp	x8, #0x5
100849e90:     	b.eq	0x10084a00c <_js_json_stringify+0x4a0>
100849e94:     	ldrsb	w10, [x9, #0x5]
100849e98:     	tbnz	w10, #0x1f, 0x100849eac <_js_json_stringify+0x340>
100849e9c:     	cmp	x8, #0x6
100849ea0:     	b.eq	0x10084a00c <_js_json_stringify+0x4a0>
100849ea4:     	ldrsb	w8, [x9, #0x6]
100849ea8:     	tbz	w8, #0x1f, 0x10084a00c <_js_json_stringify+0x4a0>
100849eac:     	mov	x0, x21
100849eb0:     	mov	x1, x22
100849eb4:     	mov	x2, x22
100849eb8:     	bl	0x1008e1540 <_js_string_from_bytes_with_capacity>
100849ebc:     	mov	x23, x0
100849ec0:     	b	0x10084a108 <_js_json_stringify+0x59c>
100849ec4:     	and	x8, x22, #0x7fffffffffffffc0
100849ec8:     	add	x8, x21, x8
100849ecc:     	mov	x9, x21
100849ed0:     	ldp	q0, q1, [x9]
100849ed4:     	ldp	q2, q3, [x9, #0x20]
100849ed8:     	orr.16b	v0, v1, v0
100849edc:     	orr.16b	v1, v2, v3
100849ee0:     	orr.16b	v0, v0, v1
100849ee4:     	umaxv.16b	b0, v0
100849ee8:     	fmov	w10, s0
100849eec:     	tbnz	w10, #0x7, 0x100849f4c <_js_json_stringify+0x3e0>
100849ef0:     	add	x9, x9, #0x40
100849ef4:     	cmp	x9, x8
100849ef8:     	b.ne	0x100849ed0 <_js_json_stringify+0x364>
100849efc:     	ands	x9, x22, #0x30
100849f00:     	b.eq	0x100849f24 <_js_json_stringify+0x3b8>
100849f04:     	mov	x10, x9
100849f08:     	mov	x11, x8
100849f0c:     	ldr	q0, [x11], #0x10
100849f10:     	umaxv.16b	b0, v0
100849f14:     	fmov	w12, s0
100849f18:     	tbnz	w12, #0x7, 0x100849f4c <_js_json_stringify+0x3e0>
100849f1c:     	subs	x10, x10, #0x10
100849f20:     	b.ne	0x100849f0c <_js_json_stringify+0x3a0>
100849f24:     	and	x10, x22, #0xf
100849f28:     	cbz	x10, 0x100849f44 <_js_json_stringify+0x3d8>
100849f2c:     	add	x8, x8, x9
100849f30:     	ldrsb	w9, [x8]
100849f34:     	tbnz	w9, #0x1f, 0x100849f4c <_js_json_stringify+0x3e0>
100849f38:     	add	x8, x8, #0x1
100849f3c:     	subs	x10, x10, #0x1
100849f40:     	b.ne	0x100849f30 <_js_json_stringify+0x3c4>
100849f44:     	mov	w24, w22
100849f48:     	b	0x100849f80 <_js_json_stringify+0x414>
100849f4c:     	mov	w24, w22
100849f50:     	cbz	x24, 0x100849f80 <_js_json_stringify+0x414>
100849f54:     	mov	x8, x21
100849f58:     	ands	x9, x22, #0x3
100849f5c:     	b.eq	0x100849f78 <_js_json_stringify+0x40c>
100849f60:     	mov	x8, x21
100849f64:     	ldrsb	w10, [x8]
100849f68:     	tbnz	w10, #0x1f, 0x10084a070 <_js_json_stringify+0x504>
100849f6c:     	add	x8, x8, #0x1
100849f70:     	subs	x9, x9, #0x1
100849f74:     	b.ne	0x100849f64 <_js_json_stringify+0x3f8>
100849f78:     	cmp	x24, #0x4
100849f7c:     	b.hs	0x10084a03c <_js_json_stringify+0x4d0>
100849f80:     	mov	x25, x22
100849f84:     	b	0x10084a080 <_js_json_stringify+0x514>
100849f88:     	and	x8, x22, #0x7fffffffffffffc0
100849f8c:     	and	x8, x8, #0xffffffff0007ffff
100849f90:     	add	x8, x21, x8
100849f94:     	mov	x9, x21
100849f98:     	ldp	q0, q1, [x9]
100849f9c:     	ldp	q2, q3, [x9, #0x20]
100849fa0:     	orr.16b	v0, v1, v0
100849fa4:     	orr.16b	v1, v2, v3
100849fa8:     	orr.16b	v0, v0, v1
100849fac:     	umaxv.16b	b0, v0
100849fb0:     	fmov	w10, s0
100849fb4:     	tbnz	w10, #0x7, 0x100849eac <_js_json_stringify+0x340>
100849fb8:     	add	x9, x9, #0x40
100849fbc:     	cmp	x9, x8
100849fc0:     	b.ne	0x100849f98 <_js_json_stringify+0x42c>
100849fc4:     	ands	x9, x22, #0x30
100849fc8:     	b.eq	0x100849fec <_js_json_stringify+0x480>
100849fcc:     	mov	x10, x9
100849fd0:     	mov	x11, x8
100849fd4:     	ldr	q0, [x11], #0x10
100849fd8:     	umaxv.16b	b0, v0
100849fdc:     	fmov	w12, s0
100849fe0:     	tbnz	w12, #0x7, 0x100849eac <_js_json_stringify+0x340>
100849fe4:     	subs	x10, x10, #0x10
100849fe8:     	b.ne	0x100849fd4 <_js_json_stringify+0x468>
100849fec:     	and	x10, x22, #0xf
100849ff0:     	cbz	x10, 0x10084a00c <_js_json_stringify+0x4a0>
100849ff4:     	add	x8, x8, x9
100849ff8:     	ldrsb	w9, [x8]
100849ffc:     	tbnz	w9, #0x1f, 0x100849eac <_js_json_stringify+0x340>
10084a000:     	add	x8, x8, #0x1
10084a004:     	subs	x10, x10, #0x1
10084a008:     	b.ne	0x100849ff8 <_js_json_stringify+0x48c>
10084a00c:     	mov	x0, x22
10084a010:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084a014:     	mov	x23, x0
10084a018:     	stp	w22, w22, [x0]
10084a01c:     	stp	wzr, wzr, [x0, #0xc]
10084a020:     	str	w22, [x0, #0x8]
10084a024:     	cbz	w22, 0x10084a108 <_js_json_stringify+0x59c>
10084a028:     	and	x2, x22, #0x7ffff
10084a02c:     	mov	x0, x1
10084a030:     	mov	x1, x21
10084a034:     	bl	0x100b66bec <_writev+0x100b66bec>
10084a038:     	b	0x10084a108 <_js_json_stringify+0x59c>
10084a03c:     	add	x9, x21, x24
10084a040:     	ldrsb	w10, [x8]
10084a044:     	tbnz	w10, #0x1f, 0x10084a070 <_js_json_stringify+0x504>
10084a048:     	ldrsb	w10, [x8, #0x1]
10084a04c:     	tbnz	w10, #0x1f, 0x10084a070 <_js_json_stringify+0x504>
10084a050:     	ldrsb	w10, [x8, #0x2]
10084a054:     	tbnz	w10, #0x1f, 0x10084a070 <_js_json_stringify+0x504>
10084a058:     	ldrsb	w10, [x8, #0x3]
10084a05c:     	tbnz	w10, #0x1f, 0x10084a070 <_js_json_stringify+0x504>
10084a060:     	add	x8, x8, #0x4
10084a064:     	cmp	x8, x9
10084a068:     	b.ne	0x10084a040 <_js_json_stringify+0x4d4>
10084a06c:     	b	0x100849f80 <_js_json_stringify+0x414>
10084a070:     	mov	w1, w22
10084a074:     	mov	x0, x21
10084a078:     	bl	0x1005ed7e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
10084a07c:     	mov	x25, x0
10084a080:     	bl	0x1004f2bc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
10084a084:     	add	x0, x24, #0x14
10084a088:     	mov	w1, #0x3                ; =3
10084a08c:     	bl	0x10045ae40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
10084a090:     	mov	x23, x0
10084a094:     	stp	w25, w22, [x0]
10084a098:     	stp	wzr, wzr, [x0, #0xc]
10084a09c:     	str	w22, [x0, #0x8]
10084a0a0:     	add	x0, x0, #0x14
10084a0a4:     	mov	x1, x21
10084a0a8:     	mov	x2, x24
10084a0ac:     	bl	0x100b66bec <_writev+0x100b66bec>
10084a0b0:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
10084a0b4:     	ldr	w21, [x8, #0x590]
10084a0b8:     	cmp	w21, #0x300
10084a0bc:     	b.hs	0x10084a198 <_js_json_stringify+0x62c>
10084a0c0:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084a0c4:     	ldr	x8, [x8, #0x48]
10084a0c8:     	cmn	x8, #0x1
10084a0cc:     	b.eq	0x10084a188 <_js_json_stringify+0x61c>
10084a0d0:     	mrs	x9, TPIDRRO_EL0
10084a0d4:     	and	x9, x9, #0xfffffffffffffff8
10084a0d8:     	ldr	x0, [x9, x8, lsl #3]
10084a0dc:     	cbz	x0, 0x10084a188 <_js_json_stringify+0x61c>
10084a0e0:     	add	x8, x0, x21, lsl #3
10084a0e4:     	ldr	x0, [x8, #0x1e8]
10084a0e8:     	cbz	x0, 0x10084a198 <_js_json_stringify+0x62c>
10084a0ec:     	ldr	x8, [x0]
10084a0f0:     	adds	x8, x8, x24
10084a0f4:     	csinv	x8, x8, xzr, lo
10084a0f8:     	str	x8, [x0]
10084a0fc:     	lsr	x8, x8, #25
10084a100:     	cbz	x8, 0x10084a108 <_js_json_stringify+0x59c>
10084a104:     	bl	0x100461d74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
10084a108:     	ldp	x22, x21, [sp, #0x8]
10084a10c:     	ldrb	w8, [x20, #0x18]
10084a110:     	cmp	w8, #0x1
10084a114:     	b.ne	0x10084a1f0 <_js_json_stringify+0x684>
10084a118:     	ldp	x8, x0, [x20]
10084a11c:     	stp	x22, x21, [x20]
10084a120:     	str	xzr, [x20, #0x10]
10084a124:     	sub	x8, x8, #0x1
10084a128:     	cmn	x8, #0x2
10084a12c:     	b.hs	0x10084a134 <_js_json_stringify+0x5c8>
10084a130:     	bl	0x100b63d40 <_mi_free>
10084a134:     	cbz	w26, 0x10084a140 <_js_json_stringify+0x5d4>
10084a138:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084a13c:     	b	0x10084a144 <_js_json_stringify+0x5d8>
10084a140:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084a144:     	ldr	w8, [x19]
10084a148:     	sub	w8, w8, #0x1
10084a14c:     	str	w8, [x19]
10084a150:     	mov	x0, x23
10084a154:     	ldp	x29, x30, [sp, #0x70]
10084a158:     	ldp	x20, x19, [sp, #0x60]
10084a15c:     	ldp	x22, x21, [sp, #0x50]
10084a160:     	ldp	x24, x23, [sp, #0x40]
10084a164:     	ldp	x26, x25, [sp, #0x30]
10084a168:     	ldp	d9, d8, [sp, #0x20]
10084a16c:     	add	sp, sp, #0x80
10084a170:     	ret
10084a174:     	mov	x22, x0
10084a178:     	add	x0, x0, #0x8
10084a17c:     	bl	0x100b40a90 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10084a180:     	mov	x0, x22
10084a184:     	b	0x100849cb0 <_js_json_stringify+0x144>
10084a188:     	bl	0x100b4413c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084a18c:     	add	x8, x0, x21, lsl #3
10084a190:     	ldr	x0, [x8, #0x1e8]
10084a194:     	cbnz	x0, 0x10084a0ec <_js_json_stringify+0x580>
10084a198:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084a19c:     	add	x0, x0, #0x78
10084a1a0:     	bl	0x100b4195c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084a1a4:     	ldr	x8, [x0]
10084a1a8:     	adds	x8, x8, x24
10084a1ac:     	csinv	x8, x8, xzr, lo
10084a1b0:     	str	x8, [x0]
10084a1b4:     	lsr	x8, x8, #25
10084a1b8:     	cbnz	x8, 0x10084a104 <_js_json_stringify+0x598>
10084a1bc:     	b	0x10084a108 <_js_json_stringify+0x59c>
10084a1c0:     	bl	0x100b4413c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084a1c4:     	add	x8, x0, x20, lsl #3
10084a1c8:     	ldr	x0, [x8, #0x1e8]
10084a1cc:     	cbnz	x0, 0x100849d44 <_js_json_stringify+0x1d8>
10084a1d0:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084a1d4:     	add	x0, x0, #0x138
10084a1d8:     	bl	0x100b4195c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084a1dc:     	b	0x100849d44 <_js_json_stringify+0x1d8>
10084a1e0:     	mov	x0, x20
10084a1e4:     	bl	0x100b232c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084a1e8:     	cbnz	x0, 0x100849d8c <_js_json_stringify+0x220>
10084a1ec:     	b	0x10084a290 <_js_json_stringify+0x724>
10084a1f0:     	mov	x0, x20
10084a1f4:     	bl	0x100b232c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084a1f8:     	mov	x20, x0
10084a1fc:     	cbnz	x0, 0x10084a118 <_js_json_stringify+0x5ac>
10084a200:     	cbz	x22, 0x10084a290 <_js_json_stringify+0x724>
10084a204:     	mov	x0, x21
10084a208:     	bl	0x100b63d40 <_mi_free>
10084a20c:     	b	0x10084a290 <_js_json_stringify+0x724>
10084a210:     	cmp	w8, #0x2
10084a214:     	b.eq	0x10084a290 <_js_json_stringify+0x724>
10084a218:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084a21c:     	add	x1, x1, #0xef8
10084a220:     	mov	x22, x0
10084a224:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084a228:     	mov	x0, x22
10084a22c:     	strb	wzr, [x22, #0x20]
10084a230:     	ldr	x8, [x22]
10084a234:     	cbz	x8, 0x100849de8 <_js_json_stringify+0x27c>
10084a238:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084a23c:     	add	x0, x0, #0xdb8
10084a240:     	bl	0x100b1746c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a244:     	bl	0x100b23424 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084a248:     	cbnz	x0, 0x100849c90 <_js_json_stringify+0x124>
10084a24c:     	b	0x10084a290 <_js_json_stringify+0x724>
10084a250:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10084a254:     	add	x0, x0, #0x440
10084a258:     	bl	0x100b1746c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a25c:     	cmp	w8, #0x1
10084a260:     	b.ne	0x10084a290 <_js_json_stringify+0x724>
10084a264:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084a268:     	add	x1, x1, #0x898
10084a26c:     	mov	x20, x0
10084a270:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084a274:     	mov	x0, x20
10084a278:     	strb	wzr, [x20, #0x20]
10084a27c:     	ldr	x8, [x20]
10084a280:     	cbz	x8, 0x100849d68 <_js_json_stringify+0x1fc>
10084a284:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084a288:     	add	x0, x0, #0xd88
10084a28c:     	bl	0x100b1746c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a290:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084a294:     	add	x0, x0, #0xc18
10084a298:     	bl	0x100b5d39c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
