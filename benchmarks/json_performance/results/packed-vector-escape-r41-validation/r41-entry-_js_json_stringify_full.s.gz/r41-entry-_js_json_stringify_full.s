
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/packed-vector-escape-r41/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010084a2c0 <_js_json_stringify_full>:
10084a2c0:     	sub	sp, sp, #0x120
10084a2c4:     	stp	d9, d8, [sp, #0xb0]
10084a2c8:     	stp	x28, x27, [sp, #0xc0]
10084a2cc:     	stp	x26, x25, [sp, #0xd0]
10084a2d0:     	stp	x24, x23, [sp, #0xe0]
10084a2d4:     	stp	x22, x21, [sp, #0xf0]
10084a2d8:     	stp	x20, x19, [sp, #0x100]
10084a2dc:     	stp	x29, x30, [sp, #0x110]
10084a2e0:     	add	x29, sp, #0x110
10084a2e4:     	mov.16b	v9, v2
10084a2e8:     	mov.16b	v8, v0
10084a2ec:     	fmov	x19, d8
10084a2f0:     	fmov	x21, d1
10084a2f4:     	fmov	x23, d9
10084a2f8:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
10084a2fc:     	add	x27, x21, x8
10084a300:     	add	x24, x23, x8
10084a304:     	fcmp	d2, #0.0
10084a308:     	ccmp	x24, #0x2, #0x0, ne
10084a30c:     	b.hi	0x10084a31c <_js_json_stringify_full+0x5c>
10084a310:     	cmp	x27, #0x2
10084a314:     	b.lo	0x10084a32c <_js_json_stringify_full+0x6c>
10084a318:     	b	0x10084a898 <_js_json_stringify_full+0x5d8>
10084a31c:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
10084a320:     	cmp	x23, x8
10084a324:     	ccmp	x27, #0x2, #0x2, eq
10084a328:     	b.hs	0x10084a898 <_js_json_stringify_full+0x5d8>
10084a32c:     	mov	x8, #-0x2               ; =-2
10084a330:     	movk	x8, #0x8003, lsl #48
10084a334:     	add	x8, x19, x8
10084a338:     	cmp	x8, #0x3
10084a33c:     	b.hs	0x10084a350 <_js_json_stringify_full+0x90>
10084a340:     	adrp	x9, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
10084a344:     	add	x9, x9, #0x5d8
10084a348:     	ldr	x20, [x9, x8, lsl #3]
10084a34c:     	b	0x10084b768 <_js_json_stringify_full+0x14a8>
10084a350:     	strb	wzr, [sp, #0x4c]
10084a354:     	str	wzr, [sp, #0x48]
10084a358:     	and	x8, x19, #0xffff000000000000
10084a35c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084a360:     	cmp	x8, x9
10084a364:     	b.eq	0x10084a3d8 <_js_json_stringify_full+0x118>
10084a368:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084a36c:     	cmp	x8, x9
10084a370:     	b.ne	0x10084a7d4 <_js_json_stringify_full+0x514>
10084a374:     	ubfx	x10, x19, #40, #8
10084a378:     	cbz	x10, 0x10084a3c8 <_js_json_stringify_full+0x108>
10084a37c:     	strb	w19, [sp, #0x48]
10084a380:     	cmp	x10, #0x1
10084a384:     	b.eq	0x10084a3c8 <_js_json_stringify_full+0x108>
10084a388:     	lsr	x9, x19, #8
10084a38c:     	strb	w9, [sp, #0x49]
10084a390:     	cmp	x10, #0x2
10084a394:     	b.eq	0x10084a3c8 <_js_json_stringify_full+0x108>
10084a398:     	lsr	x9, x19, #16
10084a39c:     	strb	w9, [sp, #0x4a]
10084a3a0:     	cmp	x10, #0x3
10084a3a4:     	b.eq	0x10084a3c8 <_js_json_stringify_full+0x108>
10084a3a8:     	lsr	x9, x19, #24
10084a3ac:     	strb	w9, [sp, #0x4b]
10084a3b0:     	cmp	x10, #0x4
10084a3b4:     	b.eq	0x10084a3c8 <_js_json_stringify_full+0x108>
10084a3b8:     	lsr	x9, x19, #32
10084a3bc:     	strb	w9, [sp, #0x4c]
10084a3c0:     	cmp	x10, #0x5
10084a3c4:     	b.ne	0x10084bf3c <_js_json_stringify_full+0x1c7c>
10084a3c8:     	add	x11, sp, #0x48
10084a3cc:     	cmp	w10, #0x3
10084a3d0:     	b.ls	0x10084a3f0 <_js_json_stringify_full+0x130>
10084a3d4:     	b	0x10084a7d4 <_js_json_stringify_full+0x514>
10084a3d8:     	ands	x9, x19, #0xffffffffffff
10084a3dc:     	b.eq	0x10084a898 <_js_json_stringify_full+0x5d8>
10084a3e0:     	add	x11, x9, #0x14
10084a3e4:     	ldr	w10, [x9, #0x4]
10084a3e8:     	cmp	w10, #0x3
10084a3ec:     	b.hi	0x10084a7d4 <_js_json_stringify_full+0x514>
10084a3f0:     	stur	wzr, [sp, #0x81]
10084a3f4:     	mov	w9, #0x22               ; =34
10084a3f8:     	strb	w9, [sp, #0x80]
10084a3fc:     	cbz	w10, 0x10084a434 <_js_json_stringify_full+0x174>
10084a400:     	add	x12, sp, #0x80
10084a404:     	ldrb	w13, [x11]
10084a408:     	sxtb	w15, w13
10084a40c:     	cmp	w13, #0xb
10084a410:     	b.le	0x10084a43c <_js_json_stringify_full+0x17c>
10084a414:     	cmp	w13, #0x21
10084a418:     	b.gt	0x10084a45c <_js_json_stringify_full+0x19c>
10084a41c:     	cmp	w13, #0xc
10084a420:     	b.eq	0x10084a490 <_js_json_stringify_full+0x1d0>
10084a424:     	cmp	w13, #0xd
10084a428:     	b.ne	0x10084a46c <_js_json_stringify_full+0x1ac>
10084a42c:     	mov	w15, #0x72              ; =114
10084a430:     	b	0x10084a49c <_js_json_stringify_full+0x1dc>
10084a434:     	mov	w12, #0x1               ; =1
10084a438:     	b	0x10084a4c4 <_js_json_stringify_full+0x204>
10084a43c:     	cmp	w13, #0x8
10084a440:     	b.eq	0x10084a488 <_js_json_stringify_full+0x1c8>
10084a444:     	cmp	w13, #0x9
10084a448:     	b.eq	0x10084a498 <_js_json_stringify_full+0x1d8>
10084a44c:     	cmp	w13, #0xa
10084a450:     	b.ne	0x10084a46c <_js_json_stringify_full+0x1ac>
10084a454:     	mov	w15, #0x6e              ; =110
10084a458:     	b	0x10084a49c <_js_json_stringify_full+0x1dc>
10084a45c:     	cmp	w13, #0x22
10084a460:     	b.eq	0x10084a49c <_js_json_stringify_full+0x1dc>
10084a464:     	cmp	w13, #0x5c
10084a468:     	b.eq	0x10084a49c <_js_json_stringify_full+0x1dc>
10084a46c:     	cmp	w15, #0x20
10084a470:     	b.lt	0x10084a7d4 <_js_json_stringify_full+0x514>
10084a474:     	mov	w14, #0x0               ; =0
10084a478:     	add	x13, x12, #0x2
10084a47c:     	mov	w12, #0x2               ; =2
10084a480:     	mov	w16, #0x1               ; =1
10084a484:     	b	0x10084a4b4 <_js_json_stringify_full+0x1f4>
10084a488:     	mov	w15, #0x62              ; =98
10084a48c:     	b	0x10084a49c <_js_json_stringify_full+0x1dc>
10084a490:     	mov	w15, #0x66              ; =102
10084a494:     	b	0x10084a49c <_js_json_stringify_full+0x1dc>
10084a498:     	mov	w15, #0x74              ; =116
10084a49c:     	add	x13, x12, #0x3
10084a4a0:     	mov	w12, #0x5c              ; =92
10084a4a4:     	strb	w12, [sp, #0x81]
10084a4a8:     	mov	w14, #0x1               ; =1
10084a4ac:     	mov	w12, #0x3               ; =3
10084a4b0:     	mov	w16, #0x2               ; =2
10084a4b4:     	add	x17, sp, #0x80
10084a4b8:     	strb	w15, [x17, x16]
10084a4bc:     	cmp	w10, #0x1
10084a4c0:     	b.ne	0x10084a4fc <_js_json_stringify_full+0x23c>
10084a4c4:     	add	x10, sp, #0x80
10084a4c8:     	strb	w9, [x10, x12]
10084a4cc:     	add	x8, x12, #0x1
10084a4d0:     	cmp	x12, #0x3
10084a4d4:     	b.hs	0x10084a4e8 <_js_json_stringify_full+0x228>
10084a4d8:     	mov	x13, #0x0               ; =0
10084a4dc:     	mov	x11, #0x0               ; =0
10084a4e0:     	add	x9, sp, #0x80
10084a4e4:     	b	0x10084a744 <_js_json_stringify_full+0x484>
10084a4e8:     	cmp	x12, #0xf
10084a4ec:     	b.hs	0x10084a52c <_js_json_stringify_full+0x26c>
10084a4f0:     	mov	x11, #0x0               ; =0
10084a4f4:     	mov	x13, #0x0               ; =0
10084a4f8:     	b	0x10084a6a0 <_js_json_stringify_full+0x3e0>
10084a4fc:     	ldrb	w16, [x11, #0x1]
10084a500:     	sxtb	w15, w16
10084a504:     	cmp	w16, #0xb
10084a508:     	b.le	0x10084a774 <_js_json_stringify_full+0x4b4>
10084a50c:     	cmp	w16, #0x21
10084a510:     	b.gt	0x10084a794 <_js_json_stringify_full+0x4d4>
10084a514:     	cmp	w16, #0xc
10084a518:     	b.eq	0x10084a7c4 <_js_json_stringify_full+0x504>
10084a51c:     	cmp	w16, #0xd
10084a520:     	b.ne	0x10084a7a4 <_js_json_stringify_full+0x4e4>
10084a524:     	mov	w15, #0x72              ; =114
10084a528:     	b	0x10084a7d0 <_js_json_stringify_full+0x510>
10084a52c:     	and	x12, x8, #0xc
10084a530:     	and	x11, x8, #0x10
10084a534:     	add	x13, sp, #0x80
10084a538:     	add	x9, x13, x11
10084a53c:     	adrp	x14, 0x100ca0000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5fb0>
10084a540:     	ldr	q0, [x14, #0x750]
10084a544:     	adrp	x14, 0x100ca0000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5fb0>
10084a548:     	ldr	q1, [x14, #0x760]
10084a54c:     	adrp	x14, 0x100ca0000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5fb0>
10084a550:     	ldr	q2, [x14, #0x770]
10084a554:     	adrp	x14, 0x100ca0000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5fb0>
10084a558:     	ldr	q3, [x14, #0x780]
10084a55c:     	adrp	x14, 0x100ca0000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5fb0>
10084a560:     	ldr	q4, [x14, #0x790]
10084a564:     	movi.2d	v5, #0000000000000000
10084a568:     	adrp	x14, 0x100ca0000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5fb0>
10084a56c:     	ldr	q6, [x14, #0x7a0]
10084a570:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
10084a574:     	ldr	q7, [x14, #0x8c0]
10084a578:     	mov	w14, #0x10              ; =16
10084a57c:     	movi.2d	v16, #0000000000000000
10084a580:     	dup.2d	v17, x14
10084a584:     	adrp	x14, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x338ba>
10084a588:     	ldr	q19, [x14, #0x6c0]
10084a58c:     	and	x14, x8, #0x10
10084a590:     	movi.2d	v20, #0000000000000000
10084a594:     	movi.2d	v18, #0000000000000000
10084a598:     	movi.2d	v23, #0000000000000000
10084a59c:     	movi.2d	v21, #0000000000000000
10084a5a0:     	movi.2d	v24, #0000000000000000
10084a5a4:     	movi.2d	v22, #0000000000000000
10084a5a8:     	ldr	q25, [x13], #0x10
10084a5ac:     	ushll.8h	v26, v25, #0x0
10084a5b0:     	ushll2.4s	v27, v26, #0x0
10084a5b4:     	ushll2.2d	v28, v27, #0x0
10084a5b8:     	ushll2.8h	v25, v25, #0x0
10084a5bc:     	ushll.4s	v29, v25, #0x0
10084a5c0:     	ushll2.2d	v30, v29, #0x0
10084a5c4:     	ushll.2d	v29, v29, #0x0
10084a5c8:     	ushll.2d	v27, v27, #0x0
10084a5cc:     	ushll.4s	v26, v26, #0x0
10084a5d0:     	ushll2.2d	v31, v26, #0x0
10084a5d4:     	ushll2.4s	v25, v25, #0x0
10084a5d8:     	ushll.2d	v8, v25, #0x0
10084a5dc:     	ushll.2d	v26, v26, #0x0
10084a5e0:     	ushll2.2d	v25, v25, #0x0
10084a5e4:     	shl.2d	v9, v0, #0x3
10084a5e8:     	ushl.2d	v25, v25, v9
10084a5ec:     	shl.2d	v9, v19, #0x3
10084a5f0:     	ushl.2d	v26, v26, v9
10084a5f4:     	shl.2d	v9, v1, #0x3
10084a5f8:     	ushl.2d	v8, v8, v9
10084a5fc:     	shl.2d	v9, v7, #0x3
10084a600:     	ushl.2d	v31, v31, v9
10084a604:     	shl.2d	v9, v6, #0x3
10084a608:     	ushl.2d	v27, v27, v9
10084a60c:     	shl.2d	v9, v3, #0x3
10084a610:     	ushl.2d	v29, v29, v9
10084a614:     	shl.2d	v9, v2, #0x3
10084a618:     	ushl.2d	v30, v30, v9
10084a61c:     	shl.2d	v9, v4, #0x3
10084a620:     	ushl.2d	v28, v28, v9
10084a624:     	orr.16b	v18, v28, v18
10084a628:     	orr.16b	v21, v30, v21
10084a62c:     	orr.16b	v23, v29, v23
10084a630:     	orr.16b	v20, v27, v20
10084a634:     	orr.16b	v5, v31, v5
10084a638:     	orr.16b	v24, v8, v24
10084a63c:     	orr.16b	v16, v26, v16
10084a640:     	orr.16b	v22, v25, v22
10084a644:     	add.2d	v6, v6, v17
10084a648:     	add.2d	v7, v7, v17
10084a64c:     	add.2d	v19, v19, v17
10084a650:     	add.2d	v4, v4, v17
10084a654:     	add.2d	v3, v3, v17
10084a658:     	add.2d	v2, v2, v17
10084a65c:     	add.2d	v1, v1, v17
10084a660:     	add.2d	v0, v0, v17
10084a664:     	subs	x14, x14, #0x10
10084a668:     	b.ne	0x10084a5a8 <_js_json_stringify_full+0x2e8>
10084a66c:     	orr.16b	v0, v16, v23
10084a670:     	orr.16b	v1, v20, v24
10084a674:     	orr.16b	v0, v0, v1
10084a678:     	orr.16b	v1, v5, v21
10084a67c:     	orr.16b	v2, v18, v22
10084a680:     	orr.16b	v1, v1, v2
10084a684:     	orr.16b	v0, v0, v1
10084a688:     	mov	d1, v0[1]
10084a68c:     	orr.8b	v0, v0, v1
10084a690:     	fmov	x13, d0
10084a694:     	cmp	x8, x11
10084a698:     	b.eq	0x10084a764 <_js_json_stringify_full+0x4a4>
10084a69c:     	cbz	x12, 0x10084a744 <_js_json_stringify_full+0x484>
10084a6a0:     	mov	x14, x11
10084a6a4:     	and	x11, x8, #0x1c
10084a6a8:     	add	x15, sp, #0x80
10084a6ac:     	add	x9, x15, x11
10084a6b0:     	fmov	d0, x13
10084a6b4:     	movi.2d	v1, #0000000000000000
10084a6b8:     	dup.2d	v3, x14
10084a6bc:     	adrp	x12, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
10084a6c0:     	ldr	q2, [x12, #0x8c0]
10084a6c4:     	orr.16b	v2, v3, v2
10084a6c8:     	adrp	x12, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x338ba>
10084a6cc:     	ldr	q4, [x12, #0x6c0]
10084a6d0:     	orr.16b	v3, v3, v4
10084a6d4:     	sub	x12, x14, x11
10084a6d8:     	add	x13, x15, x14
10084a6dc:     	movi.2d	v4, #0x000000000000ff
10084a6e0:     	mov	w14, #0x4               ; =4
10084a6e4:     	dup.2d	v5, x14
10084a6e8:     	ldr	s6, [x13], #0x4
10084a6ec:     	ushll.8h	v6, v6, #0x0
10084a6f0:     	ushll.4s	v6, v6, #0x0
10084a6f4:     	ushll2.2d	v7, v6, #0x0
10084a6f8:     	and.16b	v7, v7, v4
10084a6fc:     	ushll.2d	v6, v6, #0x0
10084a700:     	and.16b	v6, v6, v4
10084a704:     	shl.2d	v16, v2, #0x3
10084a708:     	shl.2d	v17, v3, #0x3
10084a70c:     	ushl.2d	v6, v6, v17
10084a710:     	ushl.2d	v7, v7, v16
10084a714:     	orr.16b	v1, v7, v1
10084a718:     	orr.16b	v0, v6, v0
10084a71c:     	add.2d	v2, v2, v5
10084a720:     	add.2d	v3, v3, v5
10084a724:     	adds	x12, x12, #0x4
10084a728:     	b.ne	0x10084a6e8 <_js_json_stringify_full+0x428>
10084a72c:     	orr.16b	v0, v0, v1
10084a730:     	mov	d1, v0[1]
10084a734:     	orr.8b	v0, v0, v1
10084a738:     	fmov	x13, d0
10084a73c:     	cmp	x8, x11
10084a740:     	b.eq	0x10084a764 <_js_json_stringify_full+0x4a4>
10084a744:     	add	x10, x10, x8
10084a748:     	lsl	x11, x11, #3
10084a74c:     	ldrb	w12, [x9], #0x1
10084a750:     	lsl	x12, x12, x11
10084a754:     	orr	x13, x12, x13
10084a758:     	add	x11, x11, #0x8
10084a75c:     	cmp	x9, x10
10084a760:     	b.ne	0x10084a74c <_js_json_stringify_full+0x48c>
10084a764:     	orr	x8, x13, x8, lsl #40
10084a768:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084a76c:     	orr	x20, x8, x9
10084a770:     	b	0x10084b768 <_js_json_stringify_full+0x14a8>
10084a774:     	cmp	w16, #0x8
10084a778:     	b.eq	0x10084a7bc <_js_json_stringify_full+0x4fc>
10084a77c:     	cmp	w16, #0x9
10084a780:     	b.eq	0x10084a7cc <_js_json_stringify_full+0x50c>
10084a784:     	cmp	w16, #0xa
10084a788:     	b.ne	0x10084a7a4 <_js_json_stringify_full+0x4e4>
10084a78c:     	mov	w15, #0x6e              ; =110
10084a790:     	b	0x10084a7d0 <_js_json_stringify_full+0x510>
10084a794:     	cmp	w16, #0x22
10084a798:     	b.eq	0x10084a7d0 <_js_json_stringify_full+0x510>
10084a79c:     	cmp	w16, #0x5c
10084a7a0:     	b.eq	0x10084a7d0 <_js_json_stringify_full+0x510>
10084a7a4:     	cmp	w15, #0x20
10084a7a8:     	b.lt	0x10084a7d4 <_js_json_stringify_full+0x514>
10084a7ac:     	add	x13, sp, #0x80
10084a7b0:     	strb	w15, [x13, x12]
10084a7b4:     	add	x12, x12, #0x1
10084a7b8:     	b	0x10084ad5c <_js_json_stringify_full+0xa9c>
10084a7bc:     	mov	w15, #0x62              ; =98
10084a7c0:     	b	0x10084a7d0 <_js_json_stringify_full+0x510>
10084a7c4:     	mov	w15, #0x66              ; =102
10084a7c8:     	b	0x10084a7d0 <_js_json_stringify_full+0x510>
10084a7cc:     	mov	w15, #0x74              ; =116
10084a7d0:     	tbz	w14, #0x0, 0x10084ad48 <_js_json_stringify_full+0xa88>
10084a7d4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084a7d8:     	cmp	x8, x9
10084a7dc:     	b.eq	0x10084a824 <_js_json_stringify_full+0x564>
10084a7e0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084a7e4:     	cmp	x8, x9
10084a7e8:     	b.ne	0x10084a898 <_js_json_stringify_full+0x5d8>
10084a7ec:     	and	x8, x19, #0xffffffffffff
10084a7f0:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
10084a7f4:     	mov	x10, #0x7fffffffffff    ; =140737488355327
10084a7f8:     	movk	x10, #0xffef, lsl #16
10084a7fc:     	cmp	x9, x10
10084a800:     	b.hi	0x10084a898 <_js_json_stringify_full+0x5d8>
10084a804:     	ldr	w8, [x8, #0x4]
10084a808:     	cmp	w8, #0x40
10084a80c:     	b.lo	0x10084a898 <_js_json_stringify_full+0x5d8>
10084a810:     	and	x0, x19, #0xffffffffffff
10084a814:     	bl	0x1004f5968 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
10084a818:     	cmp	x0, #0x1
10084a81c:     	b.ne	0x10084a898 <_js_json_stringify_full+0x5d8>
10084a820:     	b	0x10084a9e4 <_js_json_stringify_full+0x724>
10084a824:     	and	x25, x19, #0xffffffffffff
10084a828:     	and	x0, x19, #0xffffffffffff
10084a82c:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084a830:     	cbz	x0, 0x10084a864 <_js_json_stringify_full+0x5a4>
10084a834:     	ldrb	w8, [x0]
10084a838:     	cmp	w8, #0x2
10084a83c:     	b.ne	0x10084a864 <_js_json_stringify_full+0x5a4>
10084a840:     	ldrsb	w8, [x0, #0x1]
10084a844:     	tbnz	w8, #0x1f, 0x10084a864 <_js_json_stringify_full+0x5a4>
10084a848:     	ldrh	w8, [x0, #0x2]
10084a84c:     	tbnz	w8, #0xb, 0x10084a864 <_js_json_stringify_full+0x5a4>
10084a850:     	ldr	w8, [x0, #0x4]
10084a854:     	cmp	w8, #0x18
10084a858:     	b.lo	0x10084a864 <_js_json_stringify_full+0x5a4>
10084a85c:     	ldr	w8, [x25]
10084a860:     	cbz	w8, 0x10084b8bc <_js_json_stringify_full+0x15fc>
10084a864:     	and	x0, x19, #0xffffffffffff
10084a868:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084a86c:     	cbz	x0, 0x10084a898 <_js_json_stringify_full+0x5d8>
10084a870:     	ldrb	w8, [x0]
10084a874:     	cmp	w8, #0x2
10084a878:     	b.ne	0x10084a898 <_js_json_stringify_full+0x5d8>
10084a87c:     	ldrh	w8, [x0, #0x2]
10084a880:     	tbnz	w8, #0xb, 0x10084a898 <_js_json_stringify_full+0x5d8>
10084a884:     	ldr	w8, [x0, #0x4]
10084a888:     	cmp	w8, #0x18
10084a88c:     	b.lo	0x10084a898 <_js_json_stringify_full+0x5d8>
10084a890:     	ldr	w8, [x25]
10084a894:     	cbz	w8, 0x10084b860 <_js_json_stringify_full+0x15a0>
10084a898:     	mov	x20, #0x1               ; =1
10084a89c:     	movk	x20, #0x7ffc, lsl #48
10084a8a0:     	cmp	x19, x20
10084a8a4:     	b.eq	0x10084b768 <_js_json_stringify_full+0x14a8>
10084a8a8:     	and	x22, x19, #0xffff000000000000
10084a8ac:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a8b0:     	cmp	x22, x8
10084a8b4:     	b.ne	0x10084a8ec <_js_json_stringify_full+0x62c>
10084a8b8:     	and	x8, x19, #0xffffffffffff
10084a8bc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084a8c0:     	b.lo	0x10084a8d8 <_js_json_stringify_full+0x618>
10084a8c4:     	ldr	w8, [x8, #0xc]
10084a8c8:     	mov	w9, #0x4f53             ; =20307
10084a8cc:     	movk	w9, #0x434c, lsl #16
10084a8d0:     	cmp	w8, w9
10084a8d4:     	b.eq	0x10084b768 <_js_json_stringify_full+0x14a8>
10084a8d8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a8dc:     	cmp	x22, x8
10084a8e0:     	b.ne	0x10084a918 <_js_json_stringify_full+0x658>
10084a8e4:     	and	x0, x19, #0xffffffffffff
10084a8e8:     	b	0x10084a940 <_js_json_stringify_full+0x680>
10084a8ec:     	lsr	x8, x19, #52
10084a8f0:     	cbnz	x8, 0x10084a9c8 <_js_json_stringify_full+0x708>
10084a8f4:     	and	x8, x19, #0x7
10084a8f8:     	cbz	x19, 0x10084a924 <_js_json_stringify_full+0x664>
10084a8fc:     	cbnz	x8, 0x10084a924 <_js_json_stringify_full+0x664>
10084a900:     	mov	x0, x19
10084a904:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084a908:     	mov	x8, x19
10084a90c:     	tbnz	w0, #0x0, 0x10084a8bc <_js_json_stringify_full+0x5fc>
10084a910:     	mov	x8, #0x0                ; =0
10084a914:     	b	0x10084a924 <_js_json_stringify_full+0x664>
10084a918:     	lsr	x8, x19, #52
10084a91c:     	cbnz	x8, 0x10084a9c8 <_js_json_stringify_full+0x708>
10084a920:     	and	x8, x19, #0x7
10084a924:     	cbz	x19, 0x10084a9c8 <_js_json_stringify_full+0x708>
10084a928:     	cbnz	x8, 0x10084a9c8 <_js_json_stringify_full+0x708>
10084a92c:     	mov	x0, x19
10084a930:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084a934:     	mov	x8, x0
10084a938:     	mov	x0, x19
10084a93c:     	tbz	w8, #0x0, 0x10084a9c8 <_js_json_stringify_full+0x708>
10084a940:     	cmp	x0, #0x100, lsl #12     ; =0x100000
10084a944:     	b.lo	0x10084a9c8 <_js_json_stringify_full+0x708>
10084a948:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084a94c:     	add	x8, x8, #0xfb0
10084a950:     	ldaprb	w8, [x8]
10084a954:     	cbz	w8, 0x10084a9c8 <_js_json_stringify_full+0x708>
10084a958:     	lsr	x8, x0, #3
10084a95c:     	mov	x9, #0x7c15             ; =31765
10084a960:     	movk	x9, #0x7f4a, lsl #16
10084a964:     	movk	x9, #0x79b9, lsl #32
10084a968:     	movk	x9, #0x9e37, lsl #48
10084a96c:     	mul	x8, x8, x9
10084a970:     	lsr	x10, x8, #54
10084a974:     	lsr	x11, x8, #60
10084a978:     	adrp	x9, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084a97c:     	add	x9, x9, #0xf30
10084a980:     	add	x11, x9, x11, lsl #3
10084a984:     	ldapr	x11, [x11]
10084a988:     	lsr	x10, x11, x10
10084a98c:     	tbz	w10, #0x0, 0x10084a9c8 <_js_json_stringify_full+0x708>
10084a990:     	lsr	x10, x8, #44
10084a994:     	ubfx	x11, x8, #50, #4
10084a998:     	add	x11, x9, x11, lsl #3
10084a99c:     	ldapr	x11, [x11]
10084a9a0:     	lsr	x10, x11, x10
10084a9a4:     	tbz	w10, #0x0, 0x10084a9c8 <_js_json_stringify_full+0x708>
10084a9a8:     	lsr	x10, x8, #34
10084a9ac:     	ubfx	x8, x8, #40, #4
10084a9b0:     	add	x8, x9, x8, lsl #3
10084a9b4:     	ldapr	x8, [x8]
10084a9b8:     	lsr	x8, x8, x10
10084a9bc:     	tbz	w8, #0x0, 0x10084a9c8 <_js_json_stringify_full+0x708>
10084a9c0:     	bl	0x10034f4cc <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
10084a9c4:     	tbnz	w0, #0x0, 0x10084b768 <_js_json_stringify_full+0x14a8>
10084a9c8:     	cmp	x24, #0x3
10084a9cc:     	ccmp	x27, #0x2, #0x2, lo
10084a9d0:     	b.hs	0x10084a9f0 <_js_json_stringify_full+0x730>
10084a9d4:     	mov.16b	v0, v8
10084a9d8:     	bl	0x1004f0a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084a9dc:     	cmp	x0, #0x1
10084a9e0:     	b.ne	0x10084a9f0 <_js_json_stringify_full+0x730>
10084a9e4:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
10084a9e8:     	bfxil	x20, x1, #0, #48
10084a9ec:     	b	0x10084b768 <_js_json_stringify_full+0x14a8>
10084a9f0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a9f4:     	cmp	x22, x8
10084a9f8:     	b.ne	0x10084aa48 <_js_json_stringify_full+0x788>
10084a9fc:     	ands	x22, x19, #0xffffffffffff
10084aa00:     	b.eq	0x10084aa48 <_js_json_stringify_full+0x788>
10084aa04:     	mov	x0, x22
10084aa08:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084aa0c:     	cbz	w0, 0x10084aa48 <_js_json_stringify_full+0x788>
10084aa10:     	ldurb	w8, [x22, #-0x8]
10084aa14:     	cmp	w8, #0x9
10084aa18:     	b.ne	0x10084aa48 <_js_json_stringify_full+0x788>
10084aa1c:     	ldr	w8, [x22, #0x4]
10084aa20:     	mov	w9, #0x5841             ; =22593
10084aa24:     	movk	w9, #0x4c5a, lsl #16
10084aa28:     	cmp	w8, w9
10084aa2c:     	b.ne	0x10084aa48 <_js_json_stringify_full+0x788>
10084aa30:     	mov	x0, x22
10084aa34:     	bl	0x10068bc64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
10084aa38:     	cbz	x0, 0x10084aa48 <_js_json_stringify_full+0x788>
10084aa3c:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
10084aa40:     	bfxil	x19, x0, #0, #48
10084aa44:     	fmov	d8, x19
10084aa48:     	mov	w8, #0x7ffd             ; =32765
10084aa4c:     	cmp	x8, x23, lsr #48
10084aa50:     	b.ne	0x10084aa64 <_js_json_stringify_full+0x7a4>
10084aa54:     	and	x1, x23, #0xffffffffffff
10084aa58:     	cmp	x1, #0x100, lsl #12     ; =0x100000
10084aa5c:     	b.hs	0x10084aa78 <_js_json_stringify_full+0x7b8>
10084aa60:     	b	0x10084aacc <_js_json_stringify_full+0x80c>
10084aa64:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
10084aa68:     	mov	x9, #0xfffffff00000     ; =281474975662080
10084aa6c:     	mov	x1, x23
10084aa70:     	cmp	x8, x9
10084aa74:     	b.hs	0x10084aacc <_js_json_stringify_full+0x80c>
10084aa78:     	lsr	x8, x1, #47
10084aa7c:     	cbnz	x8, 0x10084aacc <_js_json_stringify_full+0x80c>
10084aa80:     	add	x0, sp, #0x80
10084aa84:     	bl	0x10077282c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
10084aa88:     	ldr	w8, [sp, #0x80]
10084aa8c:     	tbz	w8, #0x0, 0x10084aacc <_js_json_stringify_full+0x80c>
10084aa90:     	ldr	w8, [sp, #0x88]
10084aa94:     	mov	w9, #-0xff30            ; =-65328
10084aa98:     	cmp	w8, w9
10084aa9c:     	b.eq	0x10084aac0 <_js_json_stringify_full+0x800>
10084aaa0:     	mov	w9, #-0xff2f            ; =-65327
10084aaa4:     	cmp	w8, w9
10084aaa8:     	b.ne	0x10084aacc <_js_json_stringify_full+0x80c>
10084aaac:     	mov.16b	v0, v9
10084aab0:     	bl	0x10084cb7c <_js_jsvalue_to_string>
10084aab4:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
10084aab8:     	bfxil	x23, x0, #0, #48
10084aabc:     	b	0x10084aacc <_js_json_stringify_full+0x80c>
10084aac0:     	mov.16b	v0, v9
10084aac4:     	bl	0x100874120 <_js_number_coerce>
10084aac8:     	fmov	x23, d0
10084aacc:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
10084aad0:     	add	x8, x23, x8
10084aad4:     	cmp	x8, #0x3
10084aad8:     	b.hs	0x10084aaf0 <_js_json_stringify_full+0x830>
10084aadc:     	mov	x22, #0x0               ; =0
10084aae0:     	mov	w8, #0x1                ; =1
10084aae4:     	stp	xzr, x8, [sp, #0x10]
10084aae8:     	str	xzr, [sp, #0x20]
10084aaec:     	b	0x10084ada4 <_js_json_stringify_full+0xae4>
10084aaf0:     	and	x8, x23, #0xffff000000000000
10084aaf4:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084aaf8:     	cmp	x8, x9
10084aafc:     	b.eq	0x10084ab20 <_js_json_stringify_full+0x860>
10084ab00:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084ab04:     	cmp	x8, x9
10084ab08:     	b.ne	0x10084abac <_js_json_stringify_full+0x8ec>
10084ab0c:     	and	x8, x23, #0xffffffffffff
10084ab10:     	cmp	x8, #0x1, lsl #12       ; =0x1000
10084ab14:     	b.hs	0x10084abf4 <_js_json_stringify_full+0x934>
10084ab18:     	mov	x9, #0x0                ; =0
10084ab1c:     	b	0x10084abfc <_js_json_stringify_full+0x93c>
10084ab20:     	strb	wzr, [sp, #0x4c]
10084ab24:     	str	wzr, [sp, #0x48]
10084ab28:     	ubfx	x1, x23, #40, #8
10084ab2c:     	cbz	x1, 0x10084ab7c <_js_json_stringify_full+0x8bc>
10084ab30:     	strb	w23, [sp, #0x48]
10084ab34:     	cmp	x1, #0x1
10084ab38:     	b.eq	0x10084ab7c <_js_json_stringify_full+0x8bc>
10084ab3c:     	lsr	x8, x23, #8
10084ab40:     	strb	w8, [sp, #0x49]
10084ab44:     	cmp	x1, #0x2
10084ab48:     	b.eq	0x10084ab7c <_js_json_stringify_full+0x8bc>
10084ab4c:     	lsr	x8, x23, #16
10084ab50:     	strb	w8, [sp, #0x4a]
10084ab54:     	cmp	x1, #0x3
10084ab58:     	b.eq	0x10084ab7c <_js_json_stringify_full+0x8bc>
10084ab5c:     	lsr	x8, x23, #24
10084ab60:     	strb	w8, [sp, #0x4b]
10084ab64:     	cmp	x1, #0x4
10084ab68:     	b.eq	0x10084ab7c <_js_json_stringify_full+0x8bc>
10084ab6c:     	lsr	x8, x23, #32
10084ab70:     	strb	w8, [sp, #0x4c]
10084ab74:     	cmp	x1, #0x5
10084ab78:     	b.ne	0x10084bf3c <_js_json_stringify_full+0x1c7c>
10084ab7c:     	add	x8, sp, #0x80
10084ab80:     	add	x0, sp, #0x48
10084ab84:     	bl	0x10002dc18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10084ab88:     	ldr	w8, [sp, #0x80]
10084ab8c:     	ldp	x9, x22, [sp, #0x88]
10084ab90:     	cmp	w8, #0x0
10084ab94:     	csinc	x23, x9, xzr, eq
10084ab98:     	csel	x25, xzr, x22, ne
10084ab9c:     	tbz	x25, #0x3f, 0x10084acdc <_js_json_stringify_full+0xa1c>
10084aba0:     	mov	x0, #0x0                ; =0
10084aba4:     	mov	x1, x22
10084aba8:     	bl	0x100b170c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084abac:     	add	x8, x20, #0x3
10084abb0:     	cmp	x23, x8
10084abb4:     	b.eq	0x10084aadc <_js_json_stringify_full+0x81c>
10084abb8:     	fmov	d0, x23
10084abbc:     	fcvtzu	x8, d0
10084abc0:     	mov	w9, #0xa                ; =10
10084abc4:     	cmp	x8, #0xa
10084abc8:     	csel	x3, x8, x9, lo
10084abcc:     	adrp	x1, 0x100c48000 <_PERRY_EMPTY_STRING+0x1cf4>
10084abd0:     	add	x1, x1, #0x4e4
10084abd4:     	add	x0, sp, #0x80
10084abd8:     	mov	w2, #0x1                ; =1
10084abdc:     	bl	0x1002304f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
10084abe0:     	ldr	x22, [sp, #0x90]
10084abe4:     	str	x22, [sp, #0x20]
10084abe8:     	ldr	q0, [sp, #0x80]
10084abec:     	str	q0, [sp, #0x10]
10084abf0:     	b	0x10084ada4 <_js_json_stringify_full+0xae4>
10084abf4:     	ldr	w22, [x8, #0x4]
10084abf8:     	add	x9, x8, #0x14
10084abfc:     	mov	x14, #0x0               ; =0
10084ac00:     	mov	x8, #0x0                ; =0
10084ac04:     	cmp	x9, #0x0
10084ac08:     	csel	x24, xzr, x22, eq
10084ac0c:     	csinc	x23, x9, xzr, ne
10084ac10:     	add	x9, x23, x24
10084ac14:     	mov	w10, #0x1               ; =1
10084ac18:     	mov	x11, x23
10084ac1c:     	b	0x10084ac4c <_js_json_stringify_full+0x98c>
10084ac20:     	add	x12, x11, #0x2
10084ac24:     	bfi	w15, w13, #6, #5
10084ac28:     	mov	x13, x15
10084ac2c:     	sub	x11, x25, x11
10084ac30:     	add	x14, x11, x12
10084ac34:     	cmp	w13, #0x10, lsl #12     ; =0x10000
10084ac38:     	cinc	x11, x10, hs
10084ac3c:     	add	x8, x11, x8
10084ac40:     	mov	x11, x12
10084ac44:     	cmp	x8, #0xa
10084ac48:     	b.hi	0x10084ad04 <_js_json_stringify_full+0xa44>
10084ac4c:     	cmp	x11, x9
10084ac50:     	b.eq	0x10084acb4 <_js_json_stringify_full+0x9f4>
10084ac54:     	mov	x25, x14
10084ac58:     	mov	x12, x11
10084ac5c:     	ldrsb	w14, [x12], #0x1
10084ac60:     	and	w13, w14, #0xff
10084ac64:     	tbz	w14, #0x1f, 0x10084ac2c <_js_json_stringify_full+0x96c>
10084ac68:     	ldrb	w12, [x11, #0x1]
10084ac6c:     	and	w15, w12, #0x3f
10084ac70:     	cmp	w13, #0xe0
10084ac74:     	b.lo	0x10084ac20 <_js_json_stringify_full+0x960>
10084ac78:     	and	w14, w13, #0x1f
10084ac7c:     	ldrb	w12, [x11, #0x2]
10084ac80:     	and	w12, w12, #0x3f
10084ac84:     	orr	w15, w12, w15, lsl #6
10084ac88:     	cmp	w13, #0xf0
10084ac8c:     	b.lo	0x10084aca8 <_js_json_stringify_full+0x9e8>
10084ac90:     	add	x12, x11, #0x4
10084ac94:     	ldrb	w13, [x11, #0x3]
10084ac98:     	and	w13, w13, #0x3f
10084ac9c:     	orr	w13, w13, w15, lsl #6
10084aca0:     	bfi	w13, w14, #18, #3
10084aca4:     	b	0x10084ac2c <_js_json_stringify_full+0x96c>
10084aca8:     	add	x12, x11, #0x3
10084acac:     	orr	w13, w15, w14, lsl #12
10084acb0:     	b	0x10084ac2c <_js_json_stringify_full+0x96c>
10084acb4:     	cbz	x24, 0x10084ad38 <_js_json_stringify_full+0xa78>
10084acb8:     	mov	x0, x24
10084acbc:     	mov	w1, #0x1                ; =1
10084acc0:     	bl	0x100b63fc8 <_mi_malloc_aligned>
10084acc4:     	cbz	x0, 0x10084bf24 <_js_json_stringify_full+0x1c64>
10084acc8:     	mov	x26, x0
10084accc:     	mov	x1, x23
10084acd0:     	mov	x2, x24
10084acd4:     	bl	0x100b66bec <_writev+0x100b66bec>
10084acd8:     	b	0x10084ad40 <_js_json_stringify_full+0xa80>
10084acdc:     	cbz	x25, 0x10084ad94 <_js_json_stringify_full+0xad4>
10084ace0:     	mov	x0, x25
10084ace4:     	mov	w1, #0x1                ; =1
10084ace8:     	bl	0x100b63fc8 <_mi_malloc_aligned>
10084acec:     	cbz	x0, 0x10084bf30 <_js_json_stringify_full+0x1c70>
10084acf0:     	mov	x24, x0
10084acf4:     	mov	x1, x23
10084acf8:     	mov	x2, x25
10084acfc:     	bl	0x100b66bec <_writev+0x100b66bec>
10084ad00:     	b	0x10084ad9c <_js_json_stringify_full+0xadc>
10084ad04:     	cbz	x25, 0x10084ad38 <_js_json_stringify_full+0xa78>
10084ad08:     	cmp	x25, x24
10084ad0c:     	b.hs	0x10084b7b4 <_js_json_stringify_full+0x14f4>
10084ad10:     	ldrsb	w8, [x23, x25]
10084ad14:     	cmn	w8, #0x40
10084ad18:     	b.ge	0x10084b7b8 <_js_json_stringify_full+0x14f8>
10084ad1c:     	adrp	x4, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084ad20:     	add	x4, x4, #0x270
10084ad24:     	mov	x0, x23
10084ad28:     	mov	x1, x24
10084ad2c:     	mov	x2, #0x0                ; =0
10084ad30:     	mov	x3, x25
10084ad34:     	bl	0x100b17438 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
10084ad38:     	mov	x22, #0x0               ; =0
10084ad3c:     	mov	w26, #0x1               ; =1
10084ad40:     	stp	x22, x26, [sp, #0x10]
10084ad44:     	b	0x10084ada0 <_js_json_stringify_full+0xae0>
10084ad48:     	add	x14, sp, #0x80
10084ad4c:     	mov	w16, #0x5c              ; =92
10084ad50:     	strb	w16, [x14, x12]
10084ad54:     	add	x12, x12, #0x2
10084ad58:     	strb	w15, [x13, #0x1]
10084ad5c:     	cmp	w10, #0x2
10084ad60:     	b.eq	0x10084a4c4 <_js_json_stringify_full+0x204>
10084ad64:     	ldrb	w11, [x11, #0x2]
10084ad68:     	sxtb	w10, w11
10084ad6c:     	cmp	w11, #0xb
10084ad70:     	b.le	0x10084b840 <_js_json_stringify_full+0x1580>
10084ad74:     	cmp	w11, #0x21
10084ad78:     	b.gt	0x10084b88c <_js_json_stringify_full+0x15cc>
10084ad7c:     	cmp	w11, #0xc
10084ad80:     	b.eq	0x10084b918 <_js_json_stringify_full+0x1658>
10084ad84:     	cmp	w11, #0xd
10084ad88:     	b.ne	0x10084b89c <_js_json_stringify_full+0x15dc>
10084ad8c:     	mov	w10, #0x72              ; =114
10084ad90:     	b	0x10084b924 <_js_json_stringify_full+0x1664>
10084ad94:     	mov	x22, #0x0               ; =0
10084ad98:     	mov	w24, #0x1               ; =1
10084ad9c:     	stp	x22, x24, [sp, #0x10]
10084ada0:     	str	x22, [sp, #0x20]
10084ada4:     	cmp	x27, #0x2
10084ada8:     	b.lo	0x10084aee8 <_js_json_stringify_full+0xc28>
10084adac:     	and	x25, x21, #0xffff000000000000
10084adb0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084adb4:     	cmp	x25, x8
10084adb8:     	b.ne	0x10084aec4 <_js_json_stringify_full+0xc04>
10084adbc:     	and	x23, x21, #0xffffffffffff
10084adc0:     	cmp	x23, #0x100, lsl #12    ; =0x100000
10084adc4:     	b.lo	0x10084aee8 <_js_json_stringify_full+0xc28>
10084adc8:     	mov	x0, x23
10084adcc:     	bl	0x10050d500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
10084add0:     	tbnz	w0, #0x0, 0x10084aee8 <_js_json_stringify_full+0xc28>
10084add4:     	lsr	x8, x23, #51
10084add8:     	cmp	x8, #0xfff
10084addc:     	b.lo	0x10084adf4 <_js_json_stringify_full+0xb34>
10084ade0:     	mov	w8, #0x7ffc             ; =32764
10084ade4:     	cmp	x8, x23, lsr #48
10084ade8:     	b.eq	0x10084aee8 <_js_json_stringify_full+0xc28>
10084adec:     	ands	x23, x23, #0xffffffffffff
10084adf0:     	b.eq	0x10084aee8 <_js_json_stringify_full+0xc28>
10084adf4:     	and	x8, x23, #0xfffffffffff00000
10084adf8:     	lsr	x9, x23, #47
10084adfc:     	cmp	x9, #0x0
10084ae00:     	ccmp	x8, #0x0, #0x4, eq
10084ae04:     	b.eq	0x10084aee8 <_js_json_stringify_full+0xc28>
10084ae08:     	tst	x23, #0x3
10084ae0c:     	ccmp	x23, #0x7, #0x0, eq
10084ae10:     	b.ls	0x10084bb54 <_js_json_stringify_full+0x1894>
10084ae14:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084ae18:     	ldr	x8, [x8, #0x48]
10084ae1c:     	cmn	x8, #0x1
10084ae20:     	b.eq	0x10084baa4 <_js_json_stringify_full+0x17e4>
10084ae24:     	mrs	x9, TPIDRRO_EL0
10084ae28:     	and	x9, x9, #0xfffffffffffffff8
10084ae2c:     	ldr	x0, [x9, x8, lsl #3]
10084ae30:     	cbz	x0, 0x10084baa4 <_js_json_stringify_full+0x17e4>
10084ae34:     	lsr	x1, x23, #20
10084ae38:     	ldr	x8, [x0, #0x10]
10084ae3c:     	ldrb	w9, [x8]
10084ae40:     	cmp	w9, #0x2
10084ae44:     	b.ne	0x10084babc <_js_json_stringify_full+0x17fc>
10084ae48:     	ldrb	w9, [x8, #0x88]
10084ae4c:     	tbz	w9, #0x0, 0x10084ae6c <_js_json_stringify_full+0xbac>
10084ae50:     	ldr	x9, [x8, #0x80]
10084ae54:     	cmp	x9, x1
10084ae58:     	b.ne	0x10084ae6c <_js_json_stringify_full+0xbac>
10084ae5c:     	ldp	x9, x10, [x8, #0x60]
10084ae60:     	cmp	x9, x23
10084ae64:     	ccmp	x10, x23, #0x0, ls
10084ae68:     	b.hi	0x10084ba9c <_js_json_stringify_full+0x17dc>
10084ae6c:     	ldrb	w9, [x8, #0xb8]
10084ae70:     	cbz	w9, 0x10084ae90 <_js_json_stringify_full+0xbd0>
10084ae74:     	ldr	x9, [x8, #0xb0]
10084ae78:     	cmp	x9, x1
10084ae7c:     	b.ne	0x10084ae90 <_js_json_stringify_full+0xbd0>
10084ae80:     	ldp	x9, x10, [x8, #0x90]
10084ae84:     	cmp	x9, x23
10084ae88:     	ccmp	x10, x23, #0x0, ls
10084ae8c:     	b.hi	0x10084bd24 <_js_json_stringify_full+0x1a64>
10084ae90:     	ldrb	w9, [x8, #0xe8]
10084ae94:     	cbz	w9, 0x10084b8dc <_js_json_stringify_full+0x161c>
10084ae98:     	ldr	x9, [x8, #0xe0]
10084ae9c:     	cmp	x9, x1
10084aea0:     	b.ne	0x10084b8dc <_js_json_stringify_full+0x161c>
10084aea4:     	ldr	x9, [x8, #0xc0]
10084aea8:     	cmp	x9, x23
10084aeac:     	b.hi	0x10084b8dc <_js_json_stringify_full+0x161c>
10084aeb0:     	ldr	x9, [x8, #0xc8]
10084aeb4:     	cmp	x9, x23
10084aeb8:     	b.ls	0x10084b8dc <_js_json_stringify_full+0x161c>
10084aebc:     	add	x9, x8, #0xc0
10084aec0:     	b	0x10084bd28 <_js_json_stringify_full+0x1a68>
10084aec4:     	lsr	x8, x21, #52
10084aec8:     	cbnz	x8, 0x10084aee8 <_js_json_stringify_full+0xc28>
10084aecc:     	cbz	x21, 0x10084aee8 <_js_json_stringify_full+0xc28>
10084aed0:     	and	x8, x21, #0x7
10084aed4:     	cbnz	x8, 0x10084aee8 <_js_json_stringify_full+0xc28>
10084aed8:     	mov	x0, x21
10084aedc:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084aee0:     	mov	x23, x21
10084aee4:     	cbnz	w0, 0x10084adc0 <_js_json_stringify_full+0xb00>
10084aee8:     	mov	x25, #-0x1              ; =-1
10084aeec:     	str	x25, [sp, #0x30]
10084aef0:     	mov	w24, #0x1               ; =1
10084aef4:     	cmp	x27, #0x1
10084aef8:     	cset	w8, hi
10084aefc:     	tst	w8, w24
10084af00:     	b.eq	0x10084af74 <_js_json_stringify_full+0xcb4>
10084af04:     	and	x23, x21, #0xffff000000000000
10084af08:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084af0c:     	cmp	x23, x8
10084af10:     	b.ne	0x10084af4c <_js_json_stringify_full+0xc8c>
10084af14:     	and	x8, x21, #0xffffffffffff
10084af18:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084af1c:     	b.lo	0x10084af74 <_js_json_stringify_full+0xcb4>
10084af20:     	ldr	w8, [x8, #0xc]
10084af24:     	mov	w9, #0x4f53             ; =20307
10084af28:     	movk	w9, #0x434c, lsl #16
10084af2c:     	cmp	w8, w9
10084af30:     	b.ne	0x10084af74 <_js_json_stringify_full+0xcb4>
10084af34:     	and	x8, x21, #0xffffffffffff
10084af38:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084af3c:     	cmp	x23, x9
10084af40:     	csel	x28, x8, x21, eq
10084af44:     	mov	w27, #0x1               ; =1
10084af48:     	b	0x10084af78 <_js_json_stringify_full+0xcb8>
10084af4c:     	lsr	x8, x21, #52
10084af50:     	cbnz	x8, 0x10084af74 <_js_json_stringify_full+0xcb4>
10084af54:     	mov	w27, #0x0               ; =0
10084af58:     	cbz	x21, 0x10084af78 <_js_json_stringify_full+0xcb8>
10084af5c:     	and	x8, x21, #0x7
10084af60:     	cbnz	x8, 0x10084af78 <_js_json_stringify_full+0xcb8>
10084af64:     	mov	x0, x21
10084af68:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084af6c:     	mov	x8, x21
10084af70:     	tbnz	w0, #0x0, 0x10084af18 <_js_json_stringify_full+0xc58>
10084af74:     	mov	w27, #0x0               ; =0
10084af78:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084af7c:     	add	x0, x0, #0xd78
10084af80:     	ldr	x8, [x0]
10084af84:     	blr	x8
10084af88:     	mov	x21, x0
10084af8c:     	ldr	w26, [x0]
10084af90:     	add	w8, w26, #0x1
10084af94:     	str	w8, [x0]
10084af98:     	cbz	w26, 0x10084b008 <_js_json_stringify_full+0xd48>
10084af9c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084afa0:     	add	x0, x0, #0xd00
10084afa4:     	ldr	x8, [x0]
10084afa8:     	blr	x8
10084afac:     	ldrb	w8, [x0, #0x20]
10084afb0:     	cmp	w8, #0x1
10084afb4:     	b.ne	0x10084bd94 <_js_json_stringify_full+0x1ad4>
10084afb8:     	ldr	x8, [x0]
10084afbc:     	cbnz	x8, 0x10084bda0 <_js_json_stringify_full+0x1ae0>
10084afc0:     	mov	x8, #-0x1               ; =-1
10084afc4:     	str	x8, [x0]
10084afc8:     	ldr	x23, [x0, #0x18]
10084afcc:     	ldr	x8, [x0, #0x8]
10084afd0:     	cmp	x23, x8
10084afd4:     	b.eq	0x10084b790 <_js_json_stringify_full+0x14d0>
10084afd8:     	ldr	x8, [x0, #0x10]
10084afdc:     	mov	w9, #0x18               ; =24
10084afe0:     	madd	x8, x23, x9, x8
10084afe4:     	mov	w9, #0x8                ; =8
10084afe8:     	stp	xzr, x9, [x8]
10084afec:     	str	xzr, [x8, #0x10]
10084aff0:     	add	x8, x23, #0x1
10084aff4:     	str	x8, [x0, #0x18]
10084aff8:     	ldr	x8, [x0]
10084affc:     	add	x8, x8, #0x1
10084b000:     	str	x8, [x0]
10084b004:     	b	0x10084b070 <_js_json_stringify_full+0xdb0>
10084b008:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b00c:     	add	x0, x0, #0xdc0
10084b010:     	ldr	x8, [x0]
10084b014:     	blr	x8
10084b018:     	strb	wzr, [x0]
10084b01c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b020:     	add	x0, x0, #0xdf0
10084b024:     	ldr	x8, [x0]
10084b028:     	blr	x8
10084b02c:     	strb	wzr, [x0]
10084b030:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
10084b034:     	ldr	w23, [x8, #0x5a8]
10084b038:     	cmp	w23, #0x300
10084b03c:     	b.hs	0x10084b7d8 <_js_json_stringify_full+0x1518>
10084b040:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084b044:     	ldr	x8, [x8, #0x48]
10084b048:     	cmn	x8, #0x1
10084b04c:     	b.eq	0x10084b7c8 <_js_json_stringify_full+0x1508>
10084b050:     	mrs	x9, TPIDRRO_EL0
10084b054:     	and	x9, x9, #0xfffffffffffffff8
10084b058:     	ldr	x0, [x9, x8, lsl #3]
10084b05c:     	cbz	x0, 0x10084b7c8 <_js_json_stringify_full+0x1508>
10084b060:     	add	x8, x0, x23, lsl #3
10084b064:     	ldr	x0, [x8, #0x1e8]
10084b068:     	cbz	x0, 0x10084b7d8 <_js_json_stringify_full+0x1518>
10084b06c:     	str	xzr, [x0]
10084b070:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b074:     	add	x0, x0, #0xd30
10084b078:     	ldr	x8, [x0]
10084b07c:     	blr	x8
10084b080:     	mov	x23, x0
10084b084:     	ldrb	w8, [x0, #0x18]
10084b088:     	cmp	w8, #0x1
10084b08c:     	b.ne	0x10084bd48 <_js_json_stringify_full+0x1a88>
10084b090:     	ldr	x8, [x0]
10084b094:     	mov	x9, #-0x1               ; =-1
10084b098:     	str	x9, [x0]
10084b09c:     	cmn	x8, #0x2
10084b0a0:     	b.eq	0x10084bed0 <_js_json_stringify_full+0x1c10>
10084b0a4:     	cmn	x8, #0x1
10084b0a8:     	b.eq	0x10084b17c <_js_json_stringify_full+0xebc>
10084b0ac:     	add	x9, sp, #0x48
10084b0b0:     	ldur	q0, [x0, #0x8]
10084b0b4:     	stur	q0, [x9, #0x8]
10084b0b8:     	str	x8, [sp, #0x48]
10084b0bc:     	tbz	w24, #0x0, 0x10084b190 <_js_json_stringify_full+0xed0>
10084b0c0:     	tbz	w27, #0x0, 0x10084b278 <_js_json_stringify_full+0xfb8>
10084b0c4:     	bl	0x10028ddd8 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
10084b0c8:     	str	x0, [sp, #0x60]
10084b0cc:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084b0d0:     	stp	x28, x8, [sp, #0x88]
10084b0d4:     	mov	w8, #0x1                ; =1
10084b0d8:     	str	x8, [sp, #0x80]
10084b0dc:     	add	x0, sp, #0x80
10084b0e0:     	bl	0x10028dee0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
10084b0e4:     	mov	x22, x0
10084b0e8:     	str	x0, [sp, #0x68]
10084b0ec:     	mov	w0, #0x0                ; =0
10084b0f0:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084b0f4:     	stp	xzr, xzr, [x0]
10084b0f8:     	str	wzr, [x0, #0x10]
10084b0fc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10084b100:     	bfxil	x8, x0, #0, #48
10084b104:     	fmov	d0, x8
10084b108:     	bl	0x10020b024 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
10084b10c:     	mov	x19, x0
10084b110:     	adrp	x24, 0x100f84000 <_perry_global_worker_ts__1>
10084b114:     	ldr	x8, [x24, #0x48]
10084b118:     	cmn	x8, #0x1
10084b11c:     	b.eq	0x10084b2dc <_js_json_stringify_full+0x101c>
10084b120:     	mrs	x9, TPIDRRO_EL0
10084b124:     	and	x9, x9, #0xfffffffffffffff8
10084b128:     	ldr	x8, [x9, x8, lsl #3]
10084b12c:     	cbz	x8, 0x10084b2dc <_js_json_stringify_full+0x101c>
10084b130:     	ldr	x8, [x8, #0x19e8]
10084b134:     	cbz	x8, 0x10084b2dc <_js_json_stringify_full+0x101c>
10084b138:     	ldr	x9, [x8]
10084b13c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084b140:     	cmp	x9, x10
10084b144:     	b.hs	0x10084be1c <_js_json_stringify_full+0x1b5c>
10084b148:     	add	x10, x9, #0x1
10084b14c:     	str	x10, [x8]
10084b150:     	ldr	x10, [x8, #0x18]
10084b154:     	cmp	x19, x10
10084b158:     	b.hs	0x10084be28 <_js_json_stringify_full+0x1b68>
10084b15c:     	ldr	x10, [x8, #0x10]
10084b160:     	mov	w11, #0x18              ; =24
10084b164:     	madd	x10, x19, x11, x10
10084b168:     	ldr	x11, [x10]
10084b16c:     	cbnz	x11, 0x10084be88 <_js_json_stringify_full+0x1bc8>
10084b170:     	ldr	x0, [x10, #0x8]
10084b174:     	str	x9, [x8]
10084b178:     	b	0x10084b2e4 <_js_json_stringify_full+0x1024>
10084b17c:     	mov	x8, #0x0                ; =0
10084b180:     	mov	w9, #0x1                ; =1
10084b184:     	stp	x9, xzr, [sp, #0x50]
10084b188:     	str	x8, [sp, #0x48]
10084b18c:     	tbnz	w24, #0x0, 0x10084b0c0 <_js_json_stringify_full+0xe00>
10084b190:     	cmp	x22, #0x0
10084b194:     	cset	w6, ne
10084b198:     	ldp	x0, x1, [sp, #0x38]
10084b19c:     	ldp	x3, x4, [sp, #0x18]
10084b1a0:     	add	x2, sp, #0x48
10084b1a4:     	mov.16b	v0, v8
10084b1a8:     	mov	x5, #0x0                ; =0
10084b1ac:     	bl	0x100505a40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
10084b1b0:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b1b4:     	add	x0, x0, #0xd90
10084b1b8:     	ldr	x8, [x0]
10084b1bc:     	blr	x8
10084b1c0:     	ldrb	w8, [x0, #0x20]
10084b1c4:     	cbnz	w8, 0x10084bdac <_js_json_stringify_full+0x1aec>
10084b1c8:     	ldr	x8, [x0]
10084b1cc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10084b1d0:     	cmp	x8, x9
10084b1d4:     	b.hs	0x10084bddc <_js_json_stringify_full+0x1b1c>
10084b1d8:     	ldr	x9, [x0, #0x18]
10084b1dc:     	cbz	x9, 0x10084b1e8 <_js_json_stringify_full+0xf28>
10084b1e0:     	cbnz	x8, 0x10084bde8 <_js_json_stringify_full+0x1b28>
10084b1e4:     	str	xzr, [x0, #0x18]
10084b1e8:     	ldp	x0, x1, [sp, #0x50]
10084b1ec:     	cmp	x1, #0x5
10084b1f0:     	b.hi	0x10084b258 <_js_json_stringify_full+0xf98>
10084b1f4:     	cbz	x1, 0x10084b468 <_js_json_stringify_full+0x11a8>
10084b1f8:     	ldrsb	w8, [x0]
10084b1fc:     	tbnz	w8, #0x1f, 0x10084b258 <_js_json_stringify_full+0xf98>
10084b200:     	cmp	x1, #0x1
10084b204:     	b.eq	0x10084b240 <_js_json_stringify_full+0xf80>
10084b208:     	ldrsb	w8, [x0, #0x1]
10084b20c:     	tbnz	w8, #0x1f, 0x10084b258 <_js_json_stringify_full+0xf98>
10084b210:     	cmp	x1, #0x2
10084b214:     	b.eq	0x10084b240 <_js_json_stringify_full+0xf80>
10084b218:     	ldrsb	w8, [x0, #0x2]
10084b21c:     	tbnz	w8, #0x1f, 0x10084b258 <_js_json_stringify_full+0xf98>
10084b220:     	cmp	x1, #0x3
10084b224:     	b.eq	0x10084b240 <_js_json_stringify_full+0xf80>
10084b228:     	ldrsb	w8, [x0, #0x3]
10084b22c:     	tbnz	w8, #0x1f, 0x10084b258 <_js_json_stringify_full+0xf98>
10084b230:     	cmp	x1, #0x4
10084b234:     	b.eq	0x10084b240 <_js_json_stringify_full+0xf80>
10084b238:     	ldrsb	w8, [x0, #0x4]
10084b23c:     	tbnz	w8, #0x1f, 0x10084b258 <_js_json_stringify_full+0xf98>
10084b240:     	cmp	x1, #0x4
10084b244:     	b.hs	0x10084b5a8 <_js_json_stringify_full+0x12e8>
10084b248:     	mov	x10, #0x0               ; =0
10084b24c:     	mov	x9, #0x0                ; =0
10084b250:     	mov	x8, x0
10084b254:     	b	0x10084b638 <_js_json_stringify_full+0x1378>
10084b258:     	bl	0x10032c848 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
10084b25c:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
10084b260:     	bfxil	x20, x0, #0, #48
10084b264:     	ldp	x22, x0, [sp, #0x48]
10084b268:     	ldrb	w8, [x23, #0x18]
10084b26c:     	cmp	w8, #0x1
10084b270:     	b.eq	0x10084b674 <_js_json_stringify_full+0x13b4>
10084b274:     	b	0x10084bd78 <_js_json_stringify_full+0x1ab8>
10084b278:     	mov	w0, #0x0                ; =0
10084b27c:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084b280:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10084b284:     	bfxil	x8, x0, #0, #48
10084b288:     	fmov	d1, x8
10084b28c:     	stp	xzr, xzr, [x0]
10084b290:     	str	wzr, [x0, #0x10]
10084b294:     	mov.16b	v0, v8
10084b298:     	bl	0x1006ca734 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
10084b29c:     	mov.16b	v8, v0
10084b2a0:     	fmov	x24, d8
10084b2a4:     	cmp	x24, x20
10084b2a8:     	b.eq	0x10084b4f0 <_js_json_stringify_full+0x1230>
10084b2ac:     	mov	w8, #0x7ffd             ; =32765
10084b2b0:     	cmp	x8, x24, lsr #48
10084b2b4:     	b.ne	0x10084b4c0 <_js_json_stringify_full+0x1200>
10084b2b8:     	and	x8, x24, #0xffffffffffff
10084b2bc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084b2c0:     	b.lo	0x10084b4e4 <_js_json_stringify_full+0x1224>
10084b2c4:     	ldr	w8, [x8, #0xc]
10084b2c8:     	mov	w9, #0x4f53             ; =20307
10084b2cc:     	movk	w9, #0x434c, lsl #16
10084b2d0:     	cmp	w8, w9
10084b2d4:     	b.ne	0x10084b4e4 <_js_json_stringify_full+0x1224>
10084b2d8:     	b	0x10084b4f0 <_js_json_stringify_full+0x1230>
10084b2dc:     	mov	x0, x19
10084b2e0:     	bl	0x10013c270 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
10084b2e4:     	fmov	d1, x0
10084b2e8:     	mov.16b	v0, v8
10084b2ec:     	bl	0x1006ca734 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
10084b2f0:     	mov.16b	v8, v0
10084b2f4:     	ldr	x8, [x24, #0x48]
10084b2f8:     	cmn	x8, #0x1
10084b2fc:     	b.eq	0x10084b360 <_js_json_stringify_full+0x10a0>
10084b300:     	mrs	x9, TPIDRRO_EL0
10084b304:     	and	x9, x9, #0xfffffffffffffff8
10084b308:     	ldr	x8, [x9, x8, lsl #3]
10084b30c:     	cbz	x8, 0x10084b360 <_js_json_stringify_full+0x10a0>
10084b310:     	ldr	x8, [x8, #0x19e8]
10084b314:     	cbz	x8, 0x10084b360 <_js_json_stringify_full+0x10a0>
10084b318:     	ldr	x9, [x8]
10084b31c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084b320:     	cmp	x9, x10
10084b324:     	b.hs	0x10084be1c <_js_json_stringify_full+0x1b5c>
10084b328:     	add	x10, x9, #0x1
10084b32c:     	str	x10, [x8]
10084b330:     	ldr	x10, [x8, #0x18]
10084b334:     	cmp	x22, x10
10084b338:     	b.hs	0x10084be28 <_js_json_stringify_full+0x1b68>
10084b33c:     	ldr	x10, [x8, #0x10]
10084b340:     	mov	w11, #0x18              ; =24
10084b344:     	madd	x10, x22, x11, x10
10084b348:     	ldr	x11, [x10]
10084b34c:     	cmp	x11, #0x1
10084b350:     	b.ne	0x10084bee8 <_js_json_stringify_full+0x1c28>
10084b354:     	ldr	x22, [x10, #0x8]
10084b358:     	str	x9, [x8]
10084b35c:     	b	0x10084b36c <_js_json_stringify_full+0x10ac>
10084b360:     	mov	x0, x22
10084b364:     	bl	0x10013c198 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
10084b368:     	mov	x22, x0
10084b36c:     	ldr	x8, [x24, #0x48]
10084b370:     	cmn	x8, #0x1
10084b374:     	b.eq	0x10084b3d4 <_js_json_stringify_full+0x1114>
10084b378:     	mrs	x9, TPIDRRO_EL0
10084b37c:     	and	x9, x9, #0xfffffffffffffff8
10084b380:     	ldr	x8, [x9, x8, lsl #3]
10084b384:     	cbz	x8, 0x10084b3d4 <_js_json_stringify_full+0x1114>
10084b388:     	ldr	x8, [x8, #0x19e8]
10084b38c:     	cbz	x8, 0x10084b3d4 <_js_json_stringify_full+0x1114>
10084b390:     	ldr	x9, [x8]
10084b394:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084b398:     	cmp	x9, x10
10084b39c:     	b.hs	0x10084be1c <_js_json_stringify_full+0x1b5c>
10084b3a0:     	add	x10, x9, #0x1
10084b3a4:     	str	x10, [x8]
10084b3a8:     	ldr	x10, [x8, #0x18]
10084b3ac:     	cmp	x19, x10
10084b3b0:     	b.hs	0x10084be28 <_js_json_stringify_full+0x1b68>
10084b3b4:     	ldr	x10, [x8, #0x10]
10084b3b8:     	mov	w11, #0x18              ; =24
10084b3bc:     	madd	x10, x19, x11, x10
10084b3c0:     	ldr	x11, [x10]
10084b3c4:     	cbnz	x11, 0x10084be88 <_js_json_stringify_full+0x1bc8>
10084b3c8:     	ldr	x0, [x10, #0x8]
10084b3cc:     	str	x9, [x8]
10084b3d0:     	b	0x10084b3dc <_js_json_stringify_full+0x111c>
10084b3d4:     	mov	x0, x19
10084b3d8:     	bl	0x10013c270 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
10084b3dc:     	fmov	d9, x0
10084b3e0:     	mov.16b	v0, v8
10084b3e4:     	bl	0x1005023e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
10084b3e8:     	mov.16b	v2, v0
10084b3ec:     	mov	x0, x22
10084b3f0:     	mov.16b	v0, v9
10084b3f4:     	mov.16b	v1, v8
10084b3f8:     	bl	0x1005026c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
10084b3fc:     	str	d0, [sp, #0x70]
10084b400:     	fmov	x19, d0
10084b404:     	cmp	x19, x20
10084b408:     	b.ne	0x10084b470 <_js_json_stringify_full+0x11b0>
10084b40c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b410:     	add	x0, x0, #0xd90
10084b414:     	ldr	x8, [x0]
10084b418:     	blr	x8
10084b41c:     	ldrb	w8, [x0, #0x20]
10084b420:     	cbnz	w8, 0x10084bec8 <_js_json_stringify_full+0x1c08>
10084b424:     	ldr	x8, [x0]
10084b428:     	cbnz	x8, 0x10084bf18 <_js_json_stringify_full+0x1c58>
10084b42c:     	str	xzr, [x0, #0x18]
10084b430:     	ldp	x22, x19, [sp, #0x48]
10084b434:     	ldrb	w8, [x23, #0x18]
10084b438:     	cmp	w8, #0x1
10084b43c:     	b.ne	0x10084be60 <_js_json_stringify_full+0x1ba0>
10084b440:     	ldp	x8, x0, [x23]
10084b444:     	stp	x22, x19, [x23]
10084b448:     	str	xzr, [x23, #0x10]
10084b44c:     	sub	x8, x8, #0x1
10084b450:     	cmn	x8, #0x2
10084b454:     	b.hs	0x10084b45c <_js_json_stringify_full+0x119c>
10084b458:     	bl	0x100b63d40 <_mi_free>
10084b45c:     	cbz	w26, 0x10084b6fc <_js_json_stringify_full+0x143c>
10084b460:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b464:     	b	0x10084b700 <_js_json_stringify_full+0x1440>
10084b468:     	mov	x10, #0x0               ; =0
10084b46c:     	b	0x10084b658 <_js_json_stringify_full+0x1398>
10084b470:     	add	x0, sp, #0x48
10084b474:     	bl	0x1005030a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
10084b478:     	tbnz	w0, #0x0, 0x10084b4b4 <_js_json_stringify_full+0x11f4>
10084b47c:     	mov	x0, x19
10084b480:     	bl	0x10032a7ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
10084b484:     	cmp	x0, #0x1
10084b488:     	b.ne	0x10084bedc <_js_json_stringify_full+0x1c1c>
10084b48c:     	add	x8, sp, #0x78
10084b490:     	add	x9, sp, #0x70
10084b494:     	stp	x1, x8, [sp, #0x78]
10084b498:     	str	x9, [sp, #0x88]
10084b49c:     	add	x8, sp, #0x48
10084b4a0:     	add	x9, sp, #0x10
10084b4a4:     	stp	x8, x9, [sp, #0x90]
10084b4a8:     	add	x0, sp, #0x68
10084b4ac:     	add	x1, sp, #0x80
10084b4b0:     	bl	0x100143c90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
10084b4b4:     	add	x0, sp, #0x60
10084b4b8:     	bl	0x100166d7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
10084b4bc:     	b	0x10084b1b0 <_js_json_stringify_full+0xef0>
10084b4c0:     	lsr	x8, x24, #52
10084b4c4:     	cbnz	x8, 0x10084b4e4 <_js_json_stringify_full+0x1224>
10084b4c8:     	cbz	x24, 0x10084b4e4 <_js_json_stringify_full+0x1224>
10084b4cc:     	and	x8, x24, #0x7
10084b4d0:     	cbnz	x8, 0x10084b4e4 <_js_json_stringify_full+0x1224>
10084b4d4:     	mov	x0, x24
10084b4d8:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084b4dc:     	mov	x8, x24
10084b4e0:     	tbnz	w0, #0x0, 0x10084b2bc <_js_json_stringify_full+0xffc>
10084b4e4:     	mov	x0, x24
10084b4e8:     	bl	0x10050c36c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
10084b4ec:     	tbz	w0, #0x0, 0x10084b57c <_js_json_stringify_full+0x12bc>
10084b4f0:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b4f4:     	add	x0, x0, #0xd90
10084b4f8:     	ldr	x8, [x0]
10084b4fc:     	blr	x8
10084b500:     	ldrb	w8, [x0, #0x20]
10084b504:     	cbnz	w8, 0x10084be2c <_js_json_stringify_full+0x1b6c>
10084b508:     	ldr	x8, [x0]
10084b50c:     	cbnz	x8, 0x10084be54 <_js_json_stringify_full+0x1b94>
10084b510:     	str	xzr, [x0, #0x18]
10084b514:     	ldp	x22, x19, [sp, #0x48]
10084b518:     	ldrb	w8, [x23, #0x18]
10084b51c:     	cmp	w8, #0x1
10084b520:     	b.ne	0x10084be08 <_js_json_stringify_full+0x1b48>
10084b524:     	ldp	x8, x0, [x23]
10084b528:     	stp	x22, x19, [x23]
10084b52c:     	str	xzr, [x23, #0x10]
10084b530:     	sub	x8, x8, #0x1
10084b534:     	cmn	x8, #0x2
10084b538:     	b.hs	0x10084b540 <_js_json_stringify_full+0x1280>
10084b53c:     	bl	0x100b63d40 <_mi_free>
10084b540:     	cbz	w26, 0x10084b560 <_js_json_stringify_full+0x12a0>
10084b544:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b548:     	ldr	w8, [x21]
10084b54c:     	sub	w8, w8, #0x1
10084b550:     	str	w8, [x21]
10084b554:     	cmn	x25, #0x1
10084b558:     	b.ne	0x10084b71c <_js_json_stringify_full+0x145c>
10084b55c:     	b	0x10084b758 <_js_json_stringify_full+0x1498>
10084b560:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b564:     	ldr	w8, [x21]
10084b568:     	sub	w8, w8, #0x1
10084b56c:     	str	w8, [x21]
10084b570:     	cmn	x25, #0x1
10084b574:     	b.ne	0x10084b71c <_js_json_stringify_full+0x145c>
10084b578:     	b	0x10084b758 <_js_json_stringify_full+0x1498>
10084b57c:     	cmp	x19, x24
10084b580:     	b.eq	0x10084b58c <_js_json_stringify_full+0x12cc>
10084b584:     	mov.16b	v0, v8
10084b588:     	bl	0x10051172c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
10084b58c:     	cbz	x22, 0x10084b7e8 <_js_json_stringify_full+0x1528>
10084b590:     	ldp	x1, x2, [sp, #0x18]
10084b594:     	add	x0, sp, #0x48
10084b598:     	mov.16b	v0, v8
10084b59c:     	mov	x3, #0x0                ; =0
10084b5a0:     	bl	0x100503b1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
10084b5a4:     	b	0x10084b7f8 <_js_json_stringify_full+0x1538>
10084b5a8:     	and	x9, x1, #0x4
10084b5ac:     	add	x8, x0, x9
10084b5b0:     	adrp	x10, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4fb0>
10084b5b4:     	ldr	q0, [x10, #0x8c0]
10084b5b8:     	adrp	x10, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x338ba>
10084b5bc:     	ldr	q2, [x10, #0x6c0]
10084b5c0:     	movi.2d	v1, #0000000000000000
10084b5c4:     	movi.2d	v3, #0x000000000000ff
10084b5c8:     	mov	w10, #0x4               ; =4
10084b5cc:     	dup.2d	v4, x10
10084b5d0:     	mov	x10, x0
10084b5d4:     	and	x11, x1, #0x4
10084b5d8:     	movi.2d	v5, #0000000000000000
10084b5dc:     	ldr	s6, [x10], #0x4
10084b5e0:     	ushll.8h	v6, v6, #0x0
10084b5e4:     	ushll.4s	v6, v6, #0x0
10084b5e8:     	ushll2.2d	v7, v6, #0x0
10084b5ec:     	and.16b	v7, v7, v3
10084b5f0:     	ushll.2d	v6, v6, #0x0
10084b5f4:     	and.16b	v6, v6, v3
10084b5f8:     	shl.2d	v16, v0, #0x3
10084b5fc:     	shl.2d	v17, v2, #0x3
10084b600:     	ushl.2d	v6, v6, v17
10084b604:     	ushl.2d	v7, v7, v16
10084b608:     	orr.16b	v1, v7, v1
10084b60c:     	orr.16b	v5, v6, v5
10084b610:     	add.2d	v0, v0, v4
10084b614:     	add.2d	v2, v2, v4
10084b618:     	subs	x11, x11, #0x4
10084b61c:     	b.ne	0x10084b5dc <_js_json_stringify_full+0x131c>
10084b620:     	orr.16b	v0, v5, v1
10084b624:     	mov	d1, v0[1]
10084b628:     	orr.8b	v0, v0, v1
10084b62c:     	fmov	x10, d0
10084b630:     	cmp	x1, x9
10084b634:     	b.eq	0x10084b658 <_js_json_stringify_full+0x1398>
10084b638:     	add	x11, x0, x1
10084b63c:     	lsl	x9, x9, #3
10084b640:     	ldrb	w12, [x8], #0x1
10084b644:     	lsl	x12, x12, x9
10084b648:     	orr	x10, x12, x10
10084b64c:     	add	x9, x9, #0x8
10084b650:     	cmp	x8, x11
10084b654:     	b.ne	0x10084b640 <_js_json_stringify_full+0x1380>
10084b658:     	orr	x8, x10, x1, lsl #40
10084b65c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084b660:     	orr	x20, x8, x9
10084b664:     	ldr	x22, [sp, #0x48]
10084b668:     	ldrb	w8, [x23, #0x18]
10084b66c:     	cmp	w8, #0x1
10084b670:     	b.ne	0x10084bd78 <_js_json_stringify_full+0x1ab8>
10084b674:     	ldp	x9, x8, [x23]
10084b678:     	stp	x22, x0, [x23]
10084b67c:     	str	xzr, [x23, #0x10]
10084b680:     	sub	x9, x9, #0x1
10084b684:     	cmn	x9, #0x2
10084b688:     	b.hs	0x10084b694 <_js_json_stringify_full+0x13d4>
10084b68c:     	mov	x0, x8
10084b690:     	bl	0x100b63d40 <_mi_free>
10084b694:     	cbz	w26, 0x10084b6b4 <_js_json_stringify_full+0x13f4>
10084b698:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b69c:     	ldr	w8, [x21]
10084b6a0:     	sub	w8, w8, #0x1
10084b6a4:     	str	w8, [x21]
10084b6a8:     	cmn	x25, #0x1
10084b6ac:     	b.ne	0x10084b6cc <_js_json_stringify_full+0x140c>
10084b6b0:     	b	0x10084b758 <_js_json_stringify_full+0x1498>
10084b6b4:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b6b8:     	ldr	w8, [x21]
10084b6bc:     	sub	w8, w8, #0x1
10084b6c0:     	str	w8, [x21]
10084b6c4:     	cmn	x25, #0x1
10084b6c8:     	b.eq	0x10084b758 <_js_json_stringify_full+0x1498>
10084b6cc:     	ldp	x19, x21, [sp, #0x38]
10084b6d0:     	cbz	x21, 0x10084b74c <_js_json_stringify_full+0x148c>
10084b6d4:     	add	x22, x19, #0x8
10084b6d8:     	b	0x10084b6e8 <_js_json_stringify_full+0x1428>
10084b6dc:     	add	x22, x22, #0x18
10084b6e0:     	subs	x21, x21, #0x1
10084b6e4:     	b.eq	0x10084b74c <_js_json_stringify_full+0x148c>
10084b6e8:     	ldur	x8, [x22, #-0x8]
10084b6ec:     	cbz	x8, 0x10084b6dc <_js_json_stringify_full+0x141c>
10084b6f0:     	ldr	x0, [x22]
10084b6f4:     	bl	0x100b63d40 <_mi_free>
10084b6f8:     	b	0x10084b6dc <_js_json_stringify_full+0x141c>
10084b6fc:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b700:     	ldr	w8, [x21]
10084b704:     	sub	w8, w8, #0x1
10084b708:     	str	w8, [x21]
10084b70c:     	add	x0, sp, #0x60
10084b710:     	bl	0x100166d7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
10084b714:     	cmn	x25, #0x1
10084b718:     	b.eq	0x10084b758 <_js_json_stringify_full+0x1498>
10084b71c:     	ldp	x19, x21, [sp, #0x38]
10084b720:     	cbz	x21, 0x10084b74c <_js_json_stringify_full+0x148c>
10084b724:     	add	x22, x19, #0x8
10084b728:     	b	0x10084b738 <_js_json_stringify_full+0x1478>
10084b72c:     	add	x22, x22, #0x18
10084b730:     	subs	x21, x21, #0x1
10084b734:     	b.eq	0x10084b74c <_js_json_stringify_full+0x148c>
10084b738:     	ldur	x8, [x22, #-0x8]
10084b73c:     	cbz	x8, 0x10084b72c <_js_json_stringify_full+0x146c>
10084b740:     	ldr	x0, [x22]
10084b744:     	bl	0x100b63d40 <_mi_free>
10084b748:     	b	0x10084b72c <_js_json_stringify_full+0x146c>
10084b74c:     	cbz	x25, 0x10084b758 <_js_json_stringify_full+0x1498>
10084b750:     	mov	x0, x19
10084b754:     	bl	0x100b63d40 <_mi_free>
10084b758:     	ldr	x8, [sp, #0x10]
10084b75c:     	cbz	x8, 0x10084b768 <_js_json_stringify_full+0x14a8>
10084b760:     	ldr	x0, [sp, #0x18]
10084b764:     	bl	0x100b63d40 <_mi_free>
10084b768:     	mov	x0, x20
10084b76c:     	ldp	x29, x30, [sp, #0x110]
10084b770:     	ldp	x20, x19, [sp, #0x100]
10084b774:     	ldp	x22, x21, [sp, #0xf0]
10084b778:     	ldp	x24, x23, [sp, #0xe0]
10084b77c:     	ldp	x26, x25, [sp, #0xd0]
10084b780:     	ldp	x28, x27, [sp, #0xc0]
10084b784:     	ldp	d9, d8, [sp, #0xb0]
10084b788:     	add	sp, sp, #0x120
10084b78c:     	ret
10084b790:     	str	x22, [sp, #0x8]
10084b794:     	mov	x22, x28
10084b798:     	mov	x28, x0
10084b79c:     	add	x0, x0, #0x8
10084b7a0:     	bl	0x100b40a90 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10084b7a4:     	mov	x0, x28
10084b7a8:     	mov	x28, x22
10084b7ac:     	ldr	x22, [sp, #0x8]
10084b7b0:     	b	0x10084afd8 <_js_json_stringify_full+0xd18>
10084b7b4:     	b.ne	0x10084ad1c <_js_json_stringify_full+0xa5c>
10084b7b8:     	tbz	x25, #0x3f, 0x10084b810 <_js_json_stringify_full+0x1550>
10084b7bc:     	mov	x0, #0x0                ; =0
10084b7c0:     	mov	x1, x25
10084b7c4:     	bl	0x100b170c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084b7c8:     	bl	0x100b4413c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084b7cc:     	add	x8, x0, x23, lsl #3
10084b7d0:     	ldr	x0, [x8, #0x1e8]
10084b7d4:     	cbnz	x0, 0x10084b06c <_js_json_stringify_full+0xdac>
10084b7d8:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084b7dc:     	add	x0, x0, #0x138
10084b7e0:     	bl	0x100b4195c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084b7e4:     	b	0x10084b06c <_js_json_stringify_full+0xdac>
10084b7e8:     	add	x1, sp, #0x48
10084b7ec:     	mov.16b	v0, v8
10084b7f0:     	mov	w0, #0x0                ; =0
10084b7f4:     	bl	0x10050c444 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
10084b7f8:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b7fc:     	add	x0, x0, #0xdc0
10084b800:     	ldr	x8, [x0]
10084b804:     	blr	x8
10084b808:     	strb	wzr, [x0]
10084b80c:     	b	0x10084b1b0 <_js_json_stringify_full+0xef0>
10084b810:     	mov	x0, x25
10084b814:     	mov	w1, #0x1                ; =1
10084b818:     	bl	0x100b63fc8 <_mi_malloc_aligned>
10084b81c:     	mov	x26, x0
10084b820:     	mov	w0, #0x1                ; =1
10084b824:     	cbz	x26, 0x10084b7c0 <_js_json_stringify_full+0x1500>
10084b828:     	mov	x0, x26
10084b82c:     	mov	x1, x23
10084b830:     	mov	x2, x25
10084b834:     	bl	0x100b66bec <_writev+0x100b66bec>
10084b838:     	mov	x22, x25
10084b83c:     	b	0x10084ad40 <_js_json_stringify_full+0xa80>
10084b840:     	cmp	w11, #0x8
10084b844:     	b.eq	0x10084b910 <_js_json_stringify_full+0x1650>
10084b848:     	cmp	w11, #0x9
10084b84c:     	b.eq	0x10084b920 <_js_json_stringify_full+0x1660>
10084b850:     	cmp	w11, #0xa
10084b854:     	b.ne	0x10084b89c <_js_json_stringify_full+0x15dc>
10084b858:     	mov	w10, #0x6e              ; =110
10084b85c:     	b	0x10084b924 <_js_json_stringify_full+0x1664>
10084b860:     	mov	x22, x0
10084b864:     	and	x0, x19, #0xffffffffffff
10084b868:     	bl	0x10034a600 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084b86c:     	cbz	x0, 0x10084b948 <_js_json_stringify_full+0x1688>
10084b870:     	ldr	w20, [x0]
10084b874:     	cmp	w20, #0x4
10084b878:     	b.hi	0x10084a898 <_js_json_stringify_full+0x5d8>
10084b87c:     	ldr	w8, [x0, #0x4]
10084b880:     	cmp	w20, w8
10084b884:     	b.hi	0x10084a898 <_js_json_stringify_full+0x5d8>
10084b888:     	b	0x10084b94c <_js_json_stringify_full+0x168c>
10084b88c:     	cmp	w11, #0x22
10084b890:     	b.eq	0x10084b924 <_js_json_stringify_full+0x1664>
10084b894:     	cmp	w11, #0x5c
10084b898:     	b.eq	0x10084b924 <_js_json_stringify_full+0x1664>
10084b89c:     	cmp	x12, #0x3
10084b8a0:     	mov	w11, #0x20              ; =32
10084b8a4:     	ccmp	w10, w11, #0x8, ls
10084b8a8:     	b.lt	0x10084a7d4 <_js_json_stringify_full+0x514>
10084b8ac:     	add	x8, sp, #0x80
10084b8b0:     	strb	w10, [x8, x12]
10084b8b4:     	add	x12, x12, #0x1
10084b8b8:     	b	0x10084a4c4 <_js_json_stringify_full+0x204>
10084b8bc:     	mov	x1, x0
10084b8c0:     	and	x0, x19, #0xffffffffffff
10084b8c4:     	mov	x22, x1
10084b8c8:     	bl	0x1004fbb00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
10084b8cc:     	cmp	x0, #0x1
10084b8d0:     	b.ne	0x10084b9f4 <_js_json_stringify_full+0x1734>
10084b8d4:     	mov	x20, x1
10084b8d8:     	b	0x10084b768 <_js_json_stringify_full+0x14a8>
10084b8dc:     	ldrb	w9, [x8, #0x118]
10084b8e0:     	cbz	w9, 0x10084bb1c <_js_json_stringify_full+0x185c>
10084b8e4:     	ldr	x9, [x8, #0x110]
10084b8e8:     	cmp	x9, x1
10084b8ec:     	b.ne	0x10084bb1c <_js_json_stringify_full+0x185c>
10084b8f0:     	ldr	x9, [x8, #0xf0]
10084b8f4:     	cmp	x9, x23
10084b8f8:     	b.hi	0x10084bb1c <_js_json_stringify_full+0x185c>
10084b8fc:     	ldr	x9, [x8, #0xf8]
10084b900:     	cmp	x9, x23
10084b904:     	b.ls	0x10084bb1c <_js_json_stringify_full+0x185c>
10084b908:     	add	x9, x8, #0xf0
10084b90c:     	b	0x10084bd28 <_js_json_stringify_full+0x1a68>
10084b910:     	mov	w10, #0x62              ; =98
10084b914:     	b	0x10084b924 <_js_json_stringify_full+0x1664>
10084b918:     	mov	w10, #0x66              ; =102
10084b91c:     	b	0x10084b924 <_js_json_stringify_full+0x1664>
10084b920:     	mov	w10, #0x74              ; =116
10084b924:     	cmp	x12, #0x2
10084b928:     	b.hi	0x10084a7d4 <_js_json_stringify_full+0x514>
10084b92c:     	add	x8, sp, #0x80
10084b930:     	add	x8, x8, x12
10084b934:     	add	x12, x12, #0x2
10084b938:     	mov	w11, #0x5c              ; =92
10084b93c:     	strb	w11, [x8]
10084b940:     	strb	w10, [x8, #0x1]
10084b944:     	b	0x10084a4c4 <_js_json_stringify_full+0x204>
10084b948:     	mov	x20, #0x0               ; =0
10084b94c:     	ldr	w8, [x22, #0x4]
10084b950:     	lsl	x9, x20, #3
10084b954:     	add	x9, x9, #0x18
10084b958:     	cmp	x9, x8
10084b95c:     	b.hi	0x10084a898 <_js_json_stringify_full+0x5d8>
10084b960:     	ldr	w8, [x25, #0x4]
10084b964:     	mov	w9, #-0x40000000        ; =-1073741824
10084b968:     	cmp	w8, w9
10084b96c:     	csel	w8, w8, wzr, lt
10084b970:     	mov	x22, x0
10084b974:     	mov	x0, x8
10084b978:     	bl	0x1005e85a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084b97c:     	mov	w9, #0x2                ; =2
10084b980:     	cmp	w1, #0x2
10084b984:     	csel	w10, w1, w9, hi
10084b988:     	tst	w0, #0x1
10084b98c:     	csel	x8, x10, x9, ne
10084b990:     	cmp	x20, x8
10084b994:     	b.hi	0x10084a898 <_js_json_stringify_full+0x5d8>
10084b998:     	cbz	x20, 0x10084bd58 <_js_json_stringify_full+0x1a98>
10084b99c:     	mov	x0, x22
10084b9a0:     	mov	x1, x20
10084b9a4:     	bl	0x1004f2a80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084b9a8:     	tbz	w0, #0x0, 0x10084a898 <_js_json_stringify_full+0x5d8>
10084b9ac:     	cmp	x20, #0x1
10084b9b0:     	b.eq	0x10084bdf4 <_js_json_stringify_full+0x1b34>
10084b9b4:     	cmp	x20, #0x2
10084b9b8:     	b.ne	0x10084beb0 <_js_json_stringify_full+0x1bf0>
10084b9bc:     	mov	x22, #0x0               ; =0
10084b9c0:     	add	x25, x25, #0x10
10084b9c4:     	mov	w8, #0x1                ; =1
10084b9c8:     	mov	x26, x8
10084b9cc:     	ldr	x1, [x25, x22, lsl #3]
10084b9d0:     	add	x0, sp, #0x80
10084b9d4:     	bl	0x1004f2ad4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
10084b9d8:     	ldr	w8, [sp, #0x80]
10084b9dc:     	cmn	w8, #0x1
10084b9e0:     	b.ne	0x10084be98 <_js_json_stringify_full+0x1bd8>
10084b9e4:     	mov	w8, #0x0                ; =0
10084b9e8:     	mov	w22, #0x1               ; =1
10084b9ec:     	tbnz	w26, #0x0, 0x10084b9c8 <_js_json_stringify_full+0x1708>
10084b9f0:     	b	0x10084beb0 <_js_json_stringify_full+0x1bf0>
10084b9f4:     	and	x0, x19, #0xffffffffffff
10084b9f8:     	bl	0x10034a600 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084b9fc:     	cbz	x0, 0x10084ba88 <_js_json_stringify_full+0x17c8>
10084ba00:     	ldr	w20, [x0]
10084ba04:     	cbz	w20, 0x10084ba88 <_js_json_stringify_full+0x17c8>
10084ba08:     	cmp	w20, #0x8
10084ba0c:     	b.hi	0x10084a864 <_js_json_stringify_full+0x5a4>
10084ba10:     	ldr	w8, [x0, #0x4]
10084ba14:     	cmp	w20, w8
10084ba18:     	b.hi	0x10084a864 <_js_json_stringify_full+0x5a4>
10084ba1c:     	ldr	w8, [x22, #0x4]
10084ba20:     	lsl	x9, x20, #3
10084ba24:     	add	x9, x9, #0x18
10084ba28:     	cmp	x9, x8
10084ba2c:     	b.hi	0x10084a864 <_js_json_stringify_full+0x5a4>
10084ba30:     	ldr	w8, [x25, #0x4]
10084ba34:     	mov	w9, #-0x40000000        ; =-1073741824
10084ba38:     	cmp	w8, w9
10084ba3c:     	csel	w8, w8, wzr, lt
10084ba40:     	mov	x22, x0
10084ba44:     	mov	x0, x8
10084ba48:     	bl	0x1005e85a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084ba4c:     	mov	w9, #0x2                ; =2
10084ba50:     	cmp	w1, #0x2
10084ba54:     	csel	w10, w1, w9, hi
10084ba58:     	tst	w0, #0x1
10084ba5c:     	csel	w8, w10, w9, ne
10084ba60:     	cmp	w20, w8
10084ba64:     	b.hi	0x10084a864 <_js_json_stringify_full+0x5a4>
10084ba68:     	mov	x0, x22
10084ba6c:     	mov	x1, x20
10084ba70:     	bl	0x1004f2a80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084ba74:     	cbz	w0, 0x10084a864 <_js_json_stringify_full+0x5a4>
10084ba78:     	and	x0, x19, #0xffffffffffff
10084ba7c:     	mov	x1, x20
10084ba80:     	bl	0x1004fac40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
10084ba84:     	b	0x10084ba90 <_js_json_stringify_full+0x17d0>
10084ba88:     	and	x0, x19, #0xffffffffffff
10084ba8c:     	bl	0x1004fb9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
10084ba90:     	mov	x20, x1
10084ba94:     	tbz	w0, #0x0, 0x10084a864 <_js_json_stringify_full+0x5a4>
10084ba98:     	b	0x10084b768 <_js_json_stringify_full+0x14a8>
10084ba9c:     	add	x9, x8, #0x60
10084baa0:     	b	0x10084bd28 <_js_json_stringify_full+0x1a68>
10084baa4:     	bl	0x100b4413c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084baa8:     	lsr	x1, x23, #20
10084baac:     	ldr	x8, [x0, #0x10]
10084bab0:     	ldrb	w9, [x8]
10084bab4:     	cmp	w9, #0x2
10084bab8:     	b.eq	0x10084ae48 <_js_json_stringify_full+0xb88>
10084babc:     	ldr	x9, [x8, #0x8]
10084bac0:     	ldr	x10, [x8, #0x28]
10084bac4:     	sub	x9, x1, x9
10084bac8:     	cmp	x9, x10
10084bacc:     	b.hs	0x10084bb10 <_js_json_stringify_full+0x1850>
10084bad0:     	ldr	x10, [x8, #0x20]
10084bad4:     	mov	w11, #0x28              ; =40
10084bad8:     	madd	x9, x9, x11, x10
10084badc:     	ldr	x10, [x9]
10084bae0:     	ldr	x11, [x8, #0x10]
10084bae4:     	cmp	x10, x11
10084bae8:     	b.ne	0x10084bb1c <_js_json_stringify_full+0x185c>
10084baec:     	ldp	x10, x11, [x9, #0x8]
10084baf0:     	cmp	x10, x23
10084baf4:     	ccmp	x11, x23, #0x0, ls
10084baf8:     	b.ls	0x10084bb1c <_js_json_stringify_full+0x185c>
10084bafc:     	ldr	x10, [x8, #0x30]
10084bb00:     	add	x10, x10, #0x1
10084bb04:     	str	x10, [x8, #0x30]
10084bb08:     	add	x8, x9, #0x21
10084bb0c:     	b	0x10084bd38 <_js_json_stringify_full+0x1a78>
10084bb10:     	ldr	x9, [x8, #0x58]
10084bb14:     	add	x9, x9, #0x1
10084bb18:     	str	x9, [x8, #0x58]
10084bb1c:     	ldr	x9, [x8, #0x38]
10084bb20:     	add	x9, x9, #0x1
10084bb24:     	str	x9, [x8, #0x38]
10084bb28:     	mov	x0, x23
10084bb2c:     	bl	0x100521208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
10084bb30:     	and	w8, w0, #0xff
10084bb34:     	cbz	w8, 0x10084bb54 <_js_json_stringify_full+0x1894>
10084bb38:     	ldurb	w8, [x23, #-0x8]
10084bb3c:     	ldurb	w9, [x23, #-0x7]
10084bb40:     	mov	w10, #0x82              ; =130
10084bb44:     	and	w9, w9, w10
10084bb48:     	cmp	w9, #0x2
10084bb4c:     	ccmp	w8, #0x1, #0x0, eq
10084bb50:     	b.eq	0x10084bbe8 <_js_json_stringify_full+0x1928>
10084bb54:     	mov	x0, x23
10084bb58:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084bb5c:     	mov	x24, x0
10084bb60:     	cbz	x0, 0x10084bb8c <_js_json_stringify_full+0x18cc>
10084bb64:     	ldrb	w8, [x24]
10084bb68:     	cmp	w8, #0x1
10084bb6c:     	b.ne	0x10084bbac <_js_json_stringify_full+0x18ec>
10084bb70:     	ldrsb	w8, [x24, #0x1]
10084bb74:     	tbnz	w8, #0x1f, 0x10084bc10 <_js_json_stringify_full+0x1950>
10084bb78:     	mov	x0, x24
10084bb7c:     	ldp	w9, w8, [x23]
10084bb80:     	cmp	w9, w8
10084bb84:     	b.hi	0x10084bc94 <_js_json_stringify_full+0x19d4>
10084bb88:     	b	0x10084bcac <_js_json_stringify_full+0x19ec>
10084bb8c:     	mov	x0, x23
10084bb90:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10084bb94:     	tbnz	w0, #0x0, 0x10084bba4 <_js_json_stringify_full+0x18e4>
10084bb98:     	mov	x0, x23
10084bb9c:     	bl	0x1002a6908 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
10084bba0:     	tbz	w0, #0x0, 0x10084aee8 <_js_json_stringify_full+0xc28>
10084bba4:     	mov	x0, #0x0                ; =0
10084bba8:     	b	0x10084bc84 <_js_json_stringify_full+0x19c4>
10084bbac:     	mov	x0, x24
10084bbb0:     	cmp	w8, #0x1
10084bbb4:     	b.eq	0x10084bc84 <_js_json_stringify_full+0x19c4>
10084bbb8:     	cmp	w8, #0x9
10084bbbc:     	b.ne	0x10084aee8 <_js_json_stringify_full+0xc28>
10084bbc0:     	ldr	w8, [x23, #0x4]
10084bbc4:     	mov	w9, #0x5841             ; =22593
10084bbc8:     	movk	w9, #0x4c5a, lsl #16
10084bbcc:     	cmp	w8, w9
10084bbd0:     	b.ne	0x10084aee8 <_js_json_stringify_full+0xc28>
10084bbd4:     	mov	x0, x23
10084bbd8:     	bl	0x100378910 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
10084bbdc:     	mov	x23, x0
10084bbe0:     	cbnz	x0, 0x10084bcd4 <_js_json_stringify_full+0x1a14>
10084bbe4:     	b	0x10084aee8 <_js_json_stringify_full+0xc28>
10084bbe8:     	ldr	w8, [x23]
10084bbec:     	mov	w9, #0xe100             ; =57600
10084bbf0:     	movk	w9, #0x5f5, lsl #16
10084bbf4:     	orr	w9, w9, #0x1
10084bbf8:     	cmp	w8, w9
10084bbfc:     	b.hs	0x10084bb54 <_js_json_stringify_full+0x1894>
10084bc00:     	ldr	w9, [x23, #0x4]
10084bc04:     	cmp	w8, w9
10084bc08:     	b.ls	0x10084bcd4 <_js_json_stringify_full+0x1a14>
10084bc0c:     	b	0x10084bb54 <_js_json_stringify_full+0x1894>
10084bc10:     	ldr	x23, [x24, #0x8]
10084bc14:     	mov	x0, x23
10084bc18:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084bc1c:     	cbz	x0, 0x10084aee8 <_js_json_stringify_full+0xc28>
10084bc20:     	ldrb	w8, [x0]
10084bc24:     	cmp	w8, #0x1
10084bc28:     	b.ne	0x10084aee8 <_js_json_stringify_full+0xc28>
10084bc2c:     	ldrsb	w8, [x0, #0x1]
10084bc30:     	tbz	w8, #0x1f, 0x10084bb7c <_js_json_stringify_full+0x18bc>
10084bc34:     	mov	w26, #0x1               ; =1
10084bc38:     	ldr	x23, [x0, #0x8]
10084bc3c:     	mov	x0, x23
10084bc40:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084bc44:     	cbz	x0, 0x10084aee8 <_js_json_stringify_full+0xc28>
10084bc48:     	ldrb	w8, [x0]
10084bc4c:     	cmp	w8, #0x1
10084bc50:     	b.ne	0x10084aee8 <_js_json_stringify_full+0xc28>
10084bc54:     	cmp	w26, #0x3f
10084bc58:     	b.hi	0x10084aee8 <_js_json_stringify_full+0xc28>
10084bc5c:     	add	w26, w26, #0x1
10084bc60:     	ldrsb	w8, [x0, #0x1]
10084bc64:     	tbnz	w8, #0x1f, 0x10084bc38 <_js_json_stringify_full+0x1978>
10084bc68:     	str	x23, [x24, #0x8]
10084bc6c:     	ldrb	w8, [x24, #0x1]
10084bc70:     	orr	w8, w8, #0x80
10084bc74:     	strb	w8, [x24, #0x1]
10084bc78:     	ldrb	w8, [x0]
10084bc7c:     	cmp	w8, #0x1
10084bc80:     	b.ne	0x10084bbb8 <_js_json_stringify_full+0x18f8>
10084bc84:     	ldp	w9, w8, [x23]
10084bc88:     	cmp	w9, w8
10084bc8c:     	b.ls	0x10084bcac <_js_json_stringify_full+0x19ec>
10084bc90:     	cbz	x24, 0x10084bcbc <_js_json_stringify_full+0x19fc>
10084bc94:     	ldr	w9, [x0, #0x4]
10084bc98:     	ubfiz	x8, x8, #3, #32
10084bc9c:     	add	x8, x8, #0x10
10084bca0:     	cmp	x8, x9
10084bca4:     	b.eq	0x10084bcd4 <_js_json_stringify_full+0x1a14>
10084bca8:     	b	0x10084bcbc <_js_json_stringify_full+0x19fc>
10084bcac:     	mov	w8, #0xe100             ; =57600
10084bcb0:     	movk	w8, #0x5f5, lsl #16
10084bcb4:     	cmp	w9, w8
10084bcb8:     	b.ls	0x10084bcd4 <_js_json_stringify_full+0x1a14>
10084bcbc:     	mov	x0, x23
10084bcc0:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10084bcc4:     	tbnz	w0, #0x0, 0x10084bcd4 <_js_json_stringify_full+0x1a14>
10084bcc8:     	mov	x0, x23
10084bccc:     	bl	0x1002a6908 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
10084bcd0:     	tbz	w0, #0x0, 0x10084aee8 <_js_json_stringify_full+0xc28>
10084bcd4:     	ldp	w8, w9, [x23]
10084bcd8:     	sub	w10, w9, #0x1
10084bcdc:     	mov	w11, #0x270f            ; =9999
10084bce0:     	cmp	w10, w11
10084bce4:     	ccmp	w8, w9, #0x2, lo
10084bce8:     	b.hi	0x10084aee8 <_js_json_stringify_full+0xc28>
10084bcec:     	and	x8, x21, #0xffffffffffff
10084bcf0:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084bcf4:     	cmp	x25, x9
10084bcf8:     	csel	x1, x8, x21, eq
10084bcfc:     	add	x0, sp, #0x30
10084bd00:     	bl	0x1005028ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
10084bd04:     	ldr	x25, [sp, #0x30]
10084bd08:     	cmn	x25, #0x1
10084bd0c:     	cset	w24, eq
10084bd10:     	cmp	x27, #0x1
10084bd14:     	cset	w8, hi
10084bd18:     	tst	w8, w24
10084bd1c:     	b.ne	0x10084af04 <_js_json_stringify_full+0xc44>
10084bd20:     	b	0x10084af74 <_js_json_stringify_full+0xcb4>
10084bd24:     	add	x9, x8, #0x90
10084bd28:     	ldr	x10, [x8, #0x30]
10084bd2c:     	add	x10, x10, #0x1
10084bd30:     	str	x10, [x8, #0x30]
10084bd34:     	add	x8, x9, #0x19
10084bd38:     	ldrb	w8, [x8]
10084bd3c:     	cmp	w8, #0xff
10084bd40:     	b.ne	0x10084bb34 <_js_json_stringify_full+0x1874>
10084bd44:     	b	0x10084bb28 <_js_json_stringify_full+0x1868>
10084bd48:     	mov	x0, x23
10084bd4c:     	bl	0x100b232c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084bd50:     	cbnz	x0, 0x10084b090 <_js_json_stringify_full+0xdd0>
10084bd54:     	b	0x10084bed0 <_js_json_stringify_full+0x1c10>
10084bd58:     	and	x0, x19, #0xffffffffffff
10084bd5c:     	bl	0x1004faa70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
10084bd60:     	mov	w0, w0
10084bd64:     	mov	x20, #0x7d7b            ; =32123
10084bd68:     	movk	x20, #0x200, lsl #32
10084bd6c:     	movk	x20, #0x7ff9, lsl #48
10084bd70:     	tbz	w0, #0x0, 0x10084a898 <_js_json_stringify_full+0x5d8>
10084bd74:     	b	0x10084b768 <_js_json_stringify_full+0x14a8>
10084bd78:     	mov	x19, x0
10084bd7c:     	mov	x0, x23
10084bd80:     	bl	0x100b232c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084bd84:     	mov	x23, x0
10084bd88:     	mov	x0, x19
10084bd8c:     	cbnz	x23, 0x10084b674 <_js_json_stringify_full+0x13b4>
10084bd90:     	b	0x10084be70 <_js_json_stringify_full+0x1bb0>
10084bd94:     	bl	0x100b23424 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084bd98:     	cbnz	x0, 0x10084afb8 <_js_json_stringify_full+0xcf8>
10084bd9c:     	b	0x10084bed0 <_js_json_stringify_full+0x1c10>
10084bda0:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10084bda4:     	add	x0, x0, #0x440
10084bda8:     	bl	0x100b1746c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084bdac:     	cmp	w8, #0x1
10084bdb0:     	b.ne	0x10084bed0 <_js_json_stringify_full+0x1c10>
10084bdb4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084bdb8:     	add	x1, x1, #0x898
10084bdbc:     	mov	x19, x0
10084bdc0:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084bdc4:     	mov	x0, x19
10084bdc8:     	strb	wzr, [x19, #0x20]
10084bdcc:     	ldr	x8, [x19]
10084bdd0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10084bdd4:     	cmp	x8, x9
10084bdd8:     	b.lo	0x10084b1d8 <_js_json_stringify_full+0xf18>
10084bddc:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084bde0:     	add	x0, x0, #0xea8
10084bde4:     	bl	0x100b1749c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084bde8:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084bdec:     	add	x0, x0, #0xec0
10084bdf0:     	bl	0x100b1746c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084bdf4:     	and	x0, x19, #0xffffffffffff
10084bdf8:     	bl	0x1004f2680 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
10084bdfc:     	mov	x20, x1
10084be00:     	tbz	w0, #0x0, 0x10084a898 <_js_json_stringify_full+0x5d8>
10084be04:     	b	0x10084b768 <_js_json_stringify_full+0x14a8>
10084be08:     	mov	x0, x23
10084be0c:     	bl	0x100b232c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084be10:     	mov	x23, x0
10084be14:     	cbnz	x0, 0x10084b524 <_js_json_stringify_full+0x1264>
10084be18:     	b	0x10084be70 <_js_json_stringify_full+0x1bb0>
10084be1c:     	adrp	x0, 0x100efb000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
10084be20:     	add	x0, x0, #0xd70
10084be24:     	bl	0x100b1749c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084be28:     	bl	0x100b506d4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
10084be2c:     	cmp	w8, #0x2
10084be30:     	b.eq	0x10084bed0 <_js_json_stringify_full+0x1c10>
10084be34:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084be38:     	add	x1, x1, #0x898
10084be3c:     	mov	x19, x0
10084be40:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084be44:     	mov	x0, x19
10084be48:     	strb	wzr, [x19, #0x20]
10084be4c:     	ldr	x8, [x19]
10084be50:     	cbz	x8, 0x10084b510 <_js_json_stringify_full+0x1250>
10084be54:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084be58:     	add	x0, x0, #0xe90
10084be5c:     	bl	0x100b1746c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084be60:     	mov	x0, x23
10084be64:     	bl	0x100b232c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084be68:     	mov	x23, x0
10084be6c:     	cbnz	x0, 0x10084b440 <_js_json_stringify_full+0x1180>
10084be70:     	cbz	x22, 0x10084bed0 <_js_json_stringify_full+0x1c10>
10084be74:     	mov	x0, x19
10084be78:     	bl	0x100b63d40 <_mi_free>
10084be7c:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084be80:     	add	x0, x0, #0xc18
10084be84:     	bl	0x100b5d39c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084be88:     	adrp	x0, 0x100c47000 <_PERRY_EMPTY_STRING+0xcf4>
10084be8c:     	add	x0, x0, #0x278
10084be90:     	mov	w1, #0xf                ; =15
10084be94:     	bl	0x100b5069c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084be98:     	and	x0, x19, #0xffffffffffff
10084be9c:     	add	x2, sp, #0x80
10084bea0:     	mov	x1, x22
10084bea4:     	bl	0x1004f2e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
10084bea8:     	tbnz	w0, #0x0, 0x10084b8d4 <_js_json_stringify_full+0x1614>
10084beac:     	mov	w20, #0x2               ; =2
10084beb0:     	and	x0, x19, #0xffffffffffff
10084beb4:     	mov	x1, x20
10084beb8:     	bl	0x1004f1500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
10084bebc:     	mov	x20, x1
10084bec0:     	tbz	w0, #0x0, 0x10084a898 <_js_json_stringify_full+0x5d8>
10084bec4:     	b	0x10084b768 <_js_json_stringify_full+0x14a8>
10084bec8:     	cmp	w8, #0x2
10084becc:     	b.ne	0x10084bef8 <_js_json_stringify_full+0x1c38>
10084bed0:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084bed4:     	add	x0, x0, #0xc18
10084bed8:     	bl	0x100b5d39c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084bedc:     	adrp	x0, 0x100f33000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x130>
10084bee0:     	add	x0, x0, #0x8a8
10084bee4:     	bl	0x100b17530 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
10084bee8:     	adrp	x0, 0x100c46000 <_anon.3a0f55142d697dd4d6c50f8035b0d3d6.3+0x51c0>
10084beec:     	add	x0, x0, #0xf67
10084bef0:     	mov	w1, #0xb                ; =11
10084bef4:     	bl	0x100b5069c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084bef8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084befc:     	add	x1, x1, #0x898
10084bf00:     	mov	x19, x0
10084bf04:     	bl	0x100a2519c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084bf08:     	mov	x0, x19
10084bf0c:     	strb	wzr, [x19, #0x20]
10084bf10:     	ldr	x8, [x19]
10084bf14:     	cbz	x8, 0x10084b42c <_js_json_stringify_full+0x116c>
10084bf18:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084bf1c:     	add	x0, x0, #0xe78
10084bf20:     	bl	0x100b1746c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084bf24:     	mov	w0, #0x1                ; =1
10084bf28:     	mov	x1, x24
10084bf2c:     	bl	0x100b170c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084bf30:     	mov	w0, #0x1                ; =1
10084bf34:     	mov	x1, x22
10084bf38:     	bl	0x100b170c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084bf3c:     	adrp	x2, 0x100efc000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
10084bf40:     	add	x2, x2, #0x3c8
10084bf44:     	mov	w0, #0x5                ; =5
10084bf48:     	mov	w1, #0x5                ; =5
10084bf4c:     	bl	0x100b175cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
