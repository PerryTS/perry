
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/dominant-token-dispatch-r43/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100849f2c <_js_json_stringify>:
100849f2c:     	sub	sp, sp, #0x80
100849f30:     	stp	d9, d8, [sp, #0x20]
100849f34:     	stp	x26, x25, [sp, #0x30]
100849f38:     	stp	x24, x23, [sp, #0x40]
100849f3c:     	stp	x22, x21, [sp, #0x50]
100849f40:     	stp	x20, x19, [sp, #0x60]
100849f44:     	stp	x29, x30, [sp, #0x70]
100849f48:     	add	x29, sp, #0x70
100849f4c:     	mov	x21, x0
100849f50:     	mov.16b	v8, v0
100849f54:     	fmov	x19, d8
100849f58:     	and	x20, x19, #0xffff000000000000
100849f5c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100849f60:     	cmp	x20, x8
100849f64:     	b.ne	0x100849f8c <_js_json_stringify+0x60>
100849f68:     	and	x0, x19, #0xffffffffffff
100849f6c:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
100849f70:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100849f74:     	movk	x9, #0xffef, lsl #16
100849f78:     	cmp	x8, x9
100849f7c:     	b.hi	0x100849f8c <_js_json_stringify+0x60>
100849f80:     	ldr	w8, [x0, #0x4]
100849f84:     	cmp	w8, #0x40
100849f88:     	b.hs	0x100849ffc <_js_json_stringify+0xd0>
100849f8c:     	mov.16b	v0, v8
100849f90:     	bl	0x1004f0a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100849f94:     	tbz	w0, #0x0, 0x100849fa0 <_js_json_stringify+0x74>
100849f98:     	mov	x23, x1
100849f9c:     	b	0x10084a510 <_js_json_stringify+0x5e4>
100849fa0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100849fa4:     	cmp	x20, x8
100849fa8:     	b.ne	0x10084a010 <_js_json_stringify+0xe4>
100849fac:     	ands	x19, x19, #0xffffffffffff
100849fb0:     	b.eq	0x10084a010 <_js_json_stringify+0xe4>
100849fb4:     	mov	x0, x19
100849fb8:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100849fbc:     	cbz	w0, 0x10084a010 <_js_json_stringify+0xe4>
100849fc0:     	ldurb	w8, [x19, #-0x8]
100849fc4:     	cmp	w8, #0x9
100849fc8:     	b.ne	0x10084a010 <_js_json_stringify+0xe4>
100849fcc:     	ldr	w8, [x19, #0x4]
100849fd0:     	mov	w9, #0x5841             ; =22593
100849fd4:     	movk	w9, #0x4c5a, lsl #16
100849fd8:     	cmp	w8, w9
100849fdc:     	b.ne	0x10084a010 <_js_json_stringify+0xe4>
100849fe0:     	mov	x0, x19
100849fe4:     	bl	0x10068bc64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100849fe8:     	cbz	x0, 0x10084a010 <_js_json_stringify+0xe4>
100849fec:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100849ff0:     	bfxil	x8, x0, #0, #48
100849ff4:     	fmov	d8, x8
100849ff8:     	b	0x10084a010 <_js_json_stringify+0xe4>
100849ffc:     	bl	0x1004f5968 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
10084a000:     	tbnz	w0, #0x0, 0x100849f98 <_js_json_stringify+0x6c>
10084a004:     	mov.16b	v0, v8
10084a008:     	bl	0x1004f0a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084a00c:     	tbnz	w0, #0x0, 0x100849f98 <_js_json_stringify+0x6c>
10084a010:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084a014:     	add	x0, x0, #0xd78
10084a018:     	ldr	x8, [x0]
10084a01c:     	blr	x8
10084a020:     	mov	x19, x0
10084a024:     	ldr	w26, [x0]
10084a028:     	add	w8, w26, #0x1
10084a02c:     	str	w8, [x0]
10084a030:     	cbz	w26, 0x10084a0a0 <_js_json_stringify+0x174>
10084a034:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084a038:     	add	x0, x0, #0xd00
10084a03c:     	ldr	x8, [x0]
10084a040:     	blr	x8
10084a044:     	ldrb	w8, [x0, #0x20]
10084a048:     	cmp	w8, #0x1
10084a04c:     	b.ne	0x10084a604 <_js_json_stringify+0x6d8>
10084a050:     	ldr	x8, [x0]
10084a054:     	cbnz	x8, 0x10084a610 <_js_json_stringify+0x6e4>
10084a058:     	mov	x8, #-0x1               ; =-1
10084a05c:     	str	x8, [x0]
10084a060:     	ldr	x20, [x0, #0x18]
10084a064:     	ldr	x8, [x0, #0x8]
10084a068:     	cmp	x20, x8
10084a06c:     	b.eq	0x10084a534 <_js_json_stringify+0x608>
10084a070:     	ldr	x8, [x0, #0x10]
10084a074:     	mov	w9, #0x18               ; =24
10084a078:     	madd	x8, x20, x9, x8
10084a07c:     	mov	w9, #0x8                ; =8
10084a080:     	stp	xzr, x9, [x8]
10084a084:     	str	xzr, [x8, #0x10]
10084a088:     	add	x8, x20, #0x1
10084a08c:     	str	x8, [x0, #0x18]
10084a090:     	ldr	x8, [x0]
10084a094:     	add	x8, x8, #0x1
10084a098:     	str	x8, [x0]
10084a09c:     	b	0x10084a12c <_js_json_stringify+0x200>
10084a0a0:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084a0a4:     	add	x0, x0, #0xdc0
10084a0a8:     	ldr	x8, [x0]
10084a0ac:     	blr	x8
10084a0b0:     	strb	wzr, [x0]
10084a0b4:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084a0b8:     	add	x0, x0, #0xdf0
10084a0bc:     	ldr	x8, [x0]
10084a0c0:     	blr	x8
10084a0c4:     	strb	wzr, [x0]
10084a0c8:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
10084a0cc:     	ldr	w20, [x8, #0x5a8]
10084a0d0:     	cmp	w20, #0x300
10084a0d4:     	b.hs	0x10084a590 <_js_json_stringify+0x664>
10084a0d8:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084a0dc:     	ldr	x8, [x8, #0x48]
10084a0e0:     	cmn	x8, #0x1
10084a0e4:     	b.eq	0x10084a580 <_js_json_stringify+0x654>
10084a0e8:     	mrs	x9, TPIDRRO_EL0
10084a0ec:     	and	x9, x9, #0xfffffffffffffff8
10084a0f0:     	ldr	x0, [x9, x8, lsl #3]
10084a0f4:     	cbz	x0, 0x10084a580 <_js_json_stringify+0x654>
10084a0f8:     	add	x8, x0, x20, lsl #3
10084a0fc:     	ldr	x0, [x8, #0x1e8]
10084a100:     	cbz	x0, 0x10084a590 <_js_json_stringify+0x664>
10084a104:     	str	xzr, [x0]
10084a108:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084a10c:     	add	x0, x0, #0xd90
10084a110:     	ldr	x8, [x0]
10084a114:     	blr	x8
10084a118:     	ldrb	w8, [x0, #0x20]
10084a11c:     	cbnz	w8, 0x10084a61c <_js_json_stringify+0x6f0>
10084a120:     	ldr	x8, [x0]
10084a124:     	cbnz	x8, 0x10084a644 <_js_json_stringify+0x718>
10084a128:     	str	xzr, [x0, #0x18]
10084a12c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084a130:     	add	x0, x0, #0xd30
10084a134:     	ldr	x8, [x0]
10084a138:     	blr	x8
10084a13c:     	mov	x20, x0
10084a140:     	ldrb	w8, [x0, #0x18]
10084a144:     	cmp	w8, #0x1
10084a148:     	b.ne	0x10084a5a0 <_js_json_stringify+0x674>
10084a14c:     	ldr	x8, [x0]
10084a150:     	mov	x9, #-0x1               ; =-1
10084a154:     	str	x9, [x0]
10084a158:     	cmn	x8, #0x2
10084a15c:     	b.eq	0x10084a650 <_js_json_stringify+0x724>
10084a160:     	cmn	x8, #0x1
10084a164:     	b.eq	0x10084a178 <_js_json_stringify+0x24c>
10084a168:     	add	x9, sp, #0x8
10084a16c:     	ldur	q0, [x0, #0x8]
10084a170:     	stur	q0, [x9, #0x8]
10084a174:     	b	0x10084a184 <_js_json_stringify+0x258>
10084a178:     	mov	x8, #0x0                ; =0
10084a17c:     	mov	w9, #0x1                ; =1
10084a180:     	stp	x9, xzr, [sp, #0x10]
10084a184:     	str	x8, [sp, #0x8]
10084a188:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084a18c:     	add	x0, x0, #0xd18
10084a190:     	ldr	x8, [x0]
10084a194:     	blr	x8
10084a198:     	ldrb	w8, [x0, #0x20]
10084a19c:     	cbnz	w8, 0x10084a5d0 <_js_json_stringify+0x6a4>
10084a1a0:     	ldr	x8, [x0]
10084a1a4:     	cbnz	x8, 0x10084a5f8 <_js_json_stringify+0x6cc>
10084a1a8:     	str	xzr, [x0, #0x18]
10084a1ac:     	add	x1, sp, #0x8
10084a1b0:     	mov.16b	v0, v8
10084a1b4:     	mov	x0, x21
10084a1b8:     	bl	0x10050c44c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
10084a1bc:     	ldp	x21, x22, [sp, #0x10]
10084a1c0:     	cmp	w22, #0x80, lsl #12     ; =0x80000
10084a1c4:     	b.hs	0x10084a284 <_js_json_stringify+0x358>
10084a1c8:     	cmp	x22, #0x40
10084a1cc:     	b.hs	0x10084a348 <_js_json_stringify+0x41c>
10084a1d0:     	ands	x9, x22, #0x38
10084a1d4:     	b.eq	0x10084a1f8 <_js_json_stringify+0x2cc>
10084a1d8:     	and	x8, x22, #0x38
10084a1dc:     	neg	x8, x8
10084a1e0:     	mov	x10, x21
10084a1e4:     	ldr	x11, [x10], #0x8
10084a1e8:     	tst	x11, #0x8080808080808080
10084a1ec:     	b.ne	0x10084a26c <_js_json_stringify+0x340>
10084a1f0:     	adds	x8, x8, #0x8
10084a1f4:     	b.ne	0x10084a1e4 <_js_json_stringify+0x2b8>
10084a1f8:     	and	x8, x22, #0x7
10084a1fc:     	cbz	x8, 0x10084a3cc <_js_json_stringify+0x4a0>
10084a200:     	add	x9, x21, x9
10084a204:     	ldrsb	w10, [x9]
10084a208:     	tbnz	w10, #0x1f, 0x10084a26c <_js_json_stringify+0x340>
10084a20c:     	cmp	x8, #0x1
10084a210:     	b.eq	0x10084a3cc <_js_json_stringify+0x4a0>
10084a214:     	ldrsb	w10, [x9, #0x1]
10084a218:     	tbnz	w10, #0x1f, 0x10084a26c <_js_json_stringify+0x340>
10084a21c:     	cmp	x8, #0x2
10084a220:     	b.eq	0x10084a3cc <_js_json_stringify+0x4a0>
10084a224:     	ldrsb	w10, [x9, #0x2]
10084a228:     	tbnz	w10, #0x1f, 0x10084a26c <_js_json_stringify+0x340>
10084a22c:     	cmp	x8, #0x3
10084a230:     	b.eq	0x10084a3cc <_js_json_stringify+0x4a0>
10084a234:     	ldrsb	w10, [x9, #0x3]
10084a238:     	tbnz	w10, #0x1f, 0x10084a26c <_js_json_stringify+0x340>
10084a23c:     	cmp	x8, #0x4
10084a240:     	b.eq	0x10084a3cc <_js_json_stringify+0x4a0>
10084a244:     	ldrsb	w10, [x9, #0x4]
10084a248:     	tbnz	w10, #0x1f, 0x10084a26c <_js_json_stringify+0x340>
10084a24c:     	cmp	x8, #0x5
10084a250:     	b.eq	0x10084a3cc <_js_json_stringify+0x4a0>
10084a254:     	ldrsb	w10, [x9, #0x5]
10084a258:     	tbnz	w10, #0x1f, 0x10084a26c <_js_json_stringify+0x340>
10084a25c:     	cmp	x8, #0x6
10084a260:     	b.eq	0x10084a3cc <_js_json_stringify+0x4a0>
10084a264:     	ldrsb	w8, [x9, #0x6]
10084a268:     	tbz	w8, #0x1f, 0x10084a3cc <_js_json_stringify+0x4a0>
10084a26c:     	mov	x0, x21
10084a270:     	mov	x1, x22
10084a274:     	mov	x2, x22
10084a278:     	bl	0x1008e1900 <_js_string_from_bytes_with_capacity>
10084a27c:     	mov	x23, x0
10084a280:     	b	0x10084a4c8 <_js_json_stringify+0x59c>
10084a284:     	and	x8, x22, #0x7fffffffffffffc0
10084a288:     	add	x8, x21, x8
10084a28c:     	mov	x9, x21
10084a290:     	ldp	q0, q1, [x9]
10084a294:     	ldp	q2, q3, [x9, #0x20]
10084a298:     	orr.16b	v0, v1, v0
10084a29c:     	orr.16b	v1, v2, v3
10084a2a0:     	orr.16b	v0, v0, v1
10084a2a4:     	umaxv.16b	b0, v0
10084a2a8:     	fmov	w10, s0
10084a2ac:     	tbnz	w10, #0x7, 0x10084a30c <_js_json_stringify+0x3e0>
10084a2b0:     	add	x9, x9, #0x40
10084a2b4:     	cmp	x9, x8
10084a2b8:     	b.ne	0x10084a290 <_js_json_stringify+0x364>
10084a2bc:     	ands	x9, x22, #0x30
10084a2c0:     	b.eq	0x10084a2e4 <_js_json_stringify+0x3b8>
10084a2c4:     	mov	x10, x9
10084a2c8:     	mov	x11, x8
10084a2cc:     	ldr	q0, [x11], #0x10
10084a2d0:     	umaxv.16b	b0, v0
10084a2d4:     	fmov	w12, s0
10084a2d8:     	tbnz	w12, #0x7, 0x10084a30c <_js_json_stringify+0x3e0>
10084a2dc:     	subs	x10, x10, #0x10
10084a2e0:     	b.ne	0x10084a2cc <_js_json_stringify+0x3a0>
10084a2e4:     	and	x10, x22, #0xf
10084a2e8:     	cbz	x10, 0x10084a304 <_js_json_stringify+0x3d8>
10084a2ec:     	add	x8, x8, x9
10084a2f0:     	ldrsb	w9, [x8]
10084a2f4:     	tbnz	w9, #0x1f, 0x10084a30c <_js_json_stringify+0x3e0>
10084a2f8:     	add	x8, x8, #0x1
10084a2fc:     	subs	x10, x10, #0x1
10084a300:     	b.ne	0x10084a2f0 <_js_json_stringify+0x3c4>
10084a304:     	mov	w24, w22
10084a308:     	b	0x10084a340 <_js_json_stringify+0x414>
10084a30c:     	mov	w24, w22
10084a310:     	cbz	x24, 0x10084a340 <_js_json_stringify+0x414>
10084a314:     	mov	x8, x21
10084a318:     	ands	x9, x22, #0x3
10084a31c:     	b.eq	0x10084a338 <_js_json_stringify+0x40c>
10084a320:     	mov	x8, x21
10084a324:     	ldrsb	w10, [x8]
10084a328:     	tbnz	w10, #0x1f, 0x10084a430 <_js_json_stringify+0x504>
10084a32c:     	add	x8, x8, #0x1
10084a330:     	subs	x9, x9, #0x1
10084a334:     	b.ne	0x10084a324 <_js_json_stringify+0x3f8>
10084a338:     	cmp	x24, #0x4
10084a33c:     	b.hs	0x10084a3fc <_js_json_stringify+0x4d0>
10084a340:     	mov	x25, x22
10084a344:     	b	0x10084a440 <_js_json_stringify+0x514>
10084a348:     	and	x8, x22, #0x7fffffffffffffc0
10084a34c:     	and	x8, x8, #0xffffffff0007ffff
10084a350:     	add	x8, x21, x8
10084a354:     	mov	x9, x21
10084a358:     	ldp	q0, q1, [x9]
10084a35c:     	ldp	q2, q3, [x9, #0x20]
10084a360:     	orr.16b	v0, v1, v0
10084a364:     	orr.16b	v1, v2, v3
10084a368:     	orr.16b	v0, v0, v1
10084a36c:     	umaxv.16b	b0, v0
10084a370:     	fmov	w10, s0
10084a374:     	tbnz	w10, #0x7, 0x10084a26c <_js_json_stringify+0x340>
10084a378:     	add	x9, x9, #0x40
10084a37c:     	cmp	x9, x8
10084a380:     	b.ne	0x10084a358 <_js_json_stringify+0x42c>
10084a384:     	ands	x9, x22, #0x30
10084a388:     	b.eq	0x10084a3ac <_js_json_stringify+0x480>
10084a38c:     	mov	x10, x9
10084a390:     	mov	x11, x8
10084a394:     	ldr	q0, [x11], #0x10
10084a398:     	umaxv.16b	b0, v0
10084a39c:     	fmov	w12, s0
10084a3a0:     	tbnz	w12, #0x7, 0x10084a26c <_js_json_stringify+0x340>
10084a3a4:     	subs	x10, x10, #0x10
10084a3a8:     	b.ne	0x10084a394 <_js_json_stringify+0x468>
10084a3ac:     	and	x10, x22, #0xf
10084a3b0:     	cbz	x10, 0x10084a3cc <_js_json_stringify+0x4a0>
10084a3b4:     	add	x8, x8, x9
10084a3b8:     	ldrsb	w9, [x8]
10084a3bc:     	tbnz	w9, #0x1f, 0x10084a26c <_js_json_stringify+0x340>
10084a3c0:     	add	x8, x8, #0x1
10084a3c4:     	subs	x10, x10, #0x1
10084a3c8:     	b.ne	0x10084a3b8 <_js_json_stringify+0x48c>
10084a3cc:     	mov	x0, x22
10084a3d0:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084a3d4:     	mov	x23, x0
10084a3d8:     	stp	w22, w22, [x0]
10084a3dc:     	stp	wzr, wzr, [x0, #0xc]
10084a3e0:     	str	w22, [x0, #0x8]
10084a3e4:     	cbz	w22, 0x10084a4c8 <_js_json_stringify+0x59c>
10084a3e8:     	and	x2, x22, #0x7ffff
10084a3ec:     	mov	x0, x1
10084a3f0:     	mov	x1, x21
10084a3f4:     	bl	0x100b66fac <_writev+0x100b66fac>
10084a3f8:     	b	0x10084a4c8 <_js_json_stringify+0x59c>
10084a3fc:     	add	x9, x21, x24
10084a400:     	ldrsb	w10, [x8]
10084a404:     	tbnz	w10, #0x1f, 0x10084a430 <_js_json_stringify+0x504>
10084a408:     	ldrsb	w10, [x8, #0x1]
10084a40c:     	tbnz	w10, #0x1f, 0x10084a430 <_js_json_stringify+0x504>
10084a410:     	ldrsb	w10, [x8, #0x2]
10084a414:     	tbnz	w10, #0x1f, 0x10084a430 <_js_json_stringify+0x504>
10084a418:     	ldrsb	w10, [x8, #0x3]
10084a41c:     	tbnz	w10, #0x1f, 0x10084a430 <_js_json_stringify+0x504>
10084a420:     	add	x8, x8, #0x4
10084a424:     	cmp	x8, x9
10084a428:     	b.ne	0x10084a400 <_js_json_stringify+0x4d4>
10084a42c:     	b	0x10084a340 <_js_json_stringify+0x414>
10084a430:     	mov	w1, w22
10084a434:     	mov	x0, x21
10084a438:     	bl	0x1005ed7e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
10084a43c:     	mov	x25, x0
10084a440:     	bl	0x1004f2bc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
10084a444:     	add	x0, x24, #0x14
10084a448:     	mov	w1, #0x3                ; =3
10084a44c:     	bl	0x10045ae40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
10084a450:     	mov	x23, x0
10084a454:     	stp	w25, w22, [x0]
10084a458:     	stp	wzr, wzr, [x0, #0xc]
10084a45c:     	str	w22, [x0, #0x8]
10084a460:     	add	x0, x0, #0x14
10084a464:     	mov	x1, x21
10084a468:     	mov	x2, x24
10084a46c:     	bl	0x100b66fac <_writev+0x100b66fac>
10084a470:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
10084a474:     	ldr	w21, [x8, #0x590]
10084a478:     	cmp	w21, #0x300
10084a47c:     	b.hs	0x10084a558 <_js_json_stringify+0x62c>
10084a480:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084a484:     	ldr	x8, [x8, #0x48]
10084a488:     	cmn	x8, #0x1
10084a48c:     	b.eq	0x10084a548 <_js_json_stringify+0x61c>
10084a490:     	mrs	x9, TPIDRRO_EL0
10084a494:     	and	x9, x9, #0xfffffffffffffff8
10084a498:     	ldr	x0, [x9, x8, lsl #3]
10084a49c:     	cbz	x0, 0x10084a548 <_js_json_stringify+0x61c>
10084a4a0:     	add	x8, x0, x21, lsl #3
10084a4a4:     	ldr	x0, [x8, #0x1e8]
10084a4a8:     	cbz	x0, 0x10084a558 <_js_json_stringify+0x62c>
10084a4ac:     	ldr	x8, [x0]
10084a4b0:     	adds	x8, x8, x24
10084a4b4:     	csinv	x8, x8, xzr, lo
10084a4b8:     	str	x8, [x0]
10084a4bc:     	lsr	x8, x8, #25
10084a4c0:     	cbz	x8, 0x10084a4c8 <_js_json_stringify+0x59c>
10084a4c4:     	bl	0x100461d74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
10084a4c8:     	ldp	x22, x21, [sp, #0x8]
10084a4cc:     	ldrb	w8, [x20, #0x18]
10084a4d0:     	cmp	w8, #0x1
10084a4d4:     	b.ne	0x10084a5b0 <_js_json_stringify+0x684>
10084a4d8:     	ldp	x8, x0, [x20]
10084a4dc:     	stp	x22, x21, [x20]
10084a4e0:     	str	xzr, [x20, #0x10]
10084a4e4:     	sub	x8, x8, #0x1
10084a4e8:     	cmn	x8, #0x2
10084a4ec:     	b.hs	0x10084a4f4 <_js_json_stringify+0x5c8>
10084a4f0:     	bl	0x100b64100 <_mi_free>
10084a4f4:     	cbz	w26, 0x10084a500 <_js_json_stringify+0x5d4>
10084a4f8:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084a4fc:     	b	0x10084a504 <_js_json_stringify+0x5d8>
10084a500:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084a504:     	ldr	w8, [x19]
10084a508:     	sub	w8, w8, #0x1
10084a50c:     	str	w8, [x19]
10084a510:     	mov	x0, x23
10084a514:     	ldp	x29, x30, [sp, #0x70]
10084a518:     	ldp	x20, x19, [sp, #0x60]
10084a51c:     	ldp	x22, x21, [sp, #0x50]
10084a520:     	ldp	x24, x23, [sp, #0x40]
10084a524:     	ldp	x26, x25, [sp, #0x30]
10084a528:     	ldp	d9, d8, [sp, #0x20]
10084a52c:     	add	sp, sp, #0x80
10084a530:     	ret
10084a534:     	mov	x22, x0
10084a538:     	add	x0, x0, #0x8
10084a53c:     	bl	0x100b40e50 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10084a540:     	mov	x0, x22
10084a544:     	b	0x10084a070 <_js_json_stringify+0x144>
10084a548:     	bl	0x100b444fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084a54c:     	add	x8, x0, x21, lsl #3
10084a550:     	ldr	x0, [x8, #0x1e8]
10084a554:     	cbnz	x0, 0x10084a4ac <_js_json_stringify+0x580>
10084a558:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084a55c:     	add	x0, x0, #0x78
10084a560:     	bl	0x100b41d1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084a564:     	ldr	x8, [x0]
10084a568:     	adds	x8, x8, x24
10084a56c:     	csinv	x8, x8, xzr, lo
10084a570:     	str	x8, [x0]
10084a574:     	lsr	x8, x8, #25
10084a578:     	cbnz	x8, 0x10084a4c4 <_js_json_stringify+0x598>
10084a57c:     	b	0x10084a4c8 <_js_json_stringify+0x59c>
10084a580:     	bl	0x100b444fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084a584:     	add	x8, x0, x20, lsl #3
10084a588:     	ldr	x0, [x8, #0x1e8]
10084a58c:     	cbnz	x0, 0x10084a104 <_js_json_stringify+0x1d8>
10084a590:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084a594:     	add	x0, x0, #0x138
10084a598:     	bl	0x100b41d1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084a59c:     	b	0x10084a104 <_js_json_stringify+0x1d8>
10084a5a0:     	mov	x0, x20
10084a5a4:     	bl	0x100b23684 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084a5a8:     	cbnz	x0, 0x10084a14c <_js_json_stringify+0x220>
10084a5ac:     	b	0x10084a650 <_js_json_stringify+0x724>
10084a5b0:     	mov	x0, x20
10084a5b4:     	bl	0x100b23684 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084a5b8:     	mov	x20, x0
10084a5bc:     	cbnz	x0, 0x10084a4d8 <_js_json_stringify+0x5ac>
10084a5c0:     	cbz	x22, 0x10084a650 <_js_json_stringify+0x724>
10084a5c4:     	mov	x0, x21
10084a5c8:     	bl	0x100b64100 <_mi_free>
10084a5cc:     	b	0x10084a650 <_js_json_stringify+0x724>
10084a5d0:     	cmp	w8, #0x2
10084a5d4:     	b.eq	0x10084a650 <_js_json_stringify+0x724>
10084a5d8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084a5dc:     	add	x1, x1, #0xef8
10084a5e0:     	mov	x22, x0
10084a5e4:     	bl	0x100a2555c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084a5e8:     	mov	x0, x22
10084a5ec:     	strb	wzr, [x22, #0x20]
10084a5f0:     	ldr	x8, [x22]
10084a5f4:     	cbz	x8, 0x10084a1a8 <_js_json_stringify+0x27c>
10084a5f8:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084a5fc:     	add	x0, x0, #0xdb8
10084a600:     	bl	0x100b1782c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a604:     	bl	0x100b237e4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084a608:     	cbnz	x0, 0x10084a050 <_js_json_stringify+0x124>
10084a60c:     	b	0x10084a650 <_js_json_stringify+0x724>
10084a610:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10084a614:     	add	x0, x0, #0x440
10084a618:     	bl	0x100b1782c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a61c:     	cmp	w8, #0x1
10084a620:     	b.ne	0x10084a650 <_js_json_stringify+0x724>
10084a624:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084a628:     	add	x1, x1, #0x898
10084a62c:     	mov	x20, x0
10084a630:     	bl	0x100a2555c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084a634:     	mov	x0, x20
10084a638:     	strb	wzr, [x20, #0x20]
10084a63c:     	ldr	x8, [x20]
10084a640:     	cbz	x8, 0x10084a128 <_js_json_stringify+0x1fc>
10084a644:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084a648:     	add	x0, x0, #0xd88
10084a64c:     	bl	0x100b1782c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a650:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084a654:     	add	x0, x0, #0xc18
10084a658:     	bl	0x100b5d75c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
