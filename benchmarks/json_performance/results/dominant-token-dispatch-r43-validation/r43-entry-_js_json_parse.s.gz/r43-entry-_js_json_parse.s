
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/dominant-token-dispatch-r43/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100849214 <_js_json_parse>:
100849214:     	stp	x29, x30, [sp, #-0x10]!
100849218:     	mov	x29, sp
10084921c:     	cbz	x0, 0x100849274 <_js_json_parse+0x60>
100849220:     	ldr	w1, [x0, #0x4]
100849224:     	cmp	w1, #0x2
100849228:     	b.eq	0x100849238 <_js_json_parse+0x24>
10084922c:     	cbz	w1, 0x100849274 <_js_json_parse+0x60>
100849230:     	ldrb	w8, [x0, #0x14]
100849234:     	b	0x100849258 <_js_json_parse+0x44>
100849238:     	ldrb	w8, [x0, #0x14]
10084923c:     	cmp	w8, #0x7b
100849240:     	b.ne	0x100849258 <_js_json_parse+0x44>
100849244:     	ldrb	w8, [x0, #0x15]
100849248:     	cmp	w8, #0x7d
10084924c:     	b.ne	0x100849264 <_js_json_parse+0x50>
100849250:     	ldp	x29, x30, [sp], #0x10
100849254:     	b	0x1004ef3c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100849258:     	orr	w8, w8, #0x20
10084925c:     	cmp	w8, #0x7b
100849260:     	b.ne	0x10084926c <_js_json_parse+0x58>
100849264:     	ldp	x29, x30, [sp], #0x10
100849268:     	b	0x100508b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
10084926c:     	ldp	x29, x30, [sp], #0x10
100849270:     	b	0x10050b2d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100849274:     	adrp	x0, 0x100c7a000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x6d54>
100849278:     	add	x0, x0, #0x73d
10084927c:     	mov	w1, #0x1c               ; =28
100849280:     	bl	0x10050b708 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
