
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/dominant-token-dispatch-r43/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100845ac0 <_js_json_stringify_full>:
100845ac0:     	sub	sp, sp, #0x120
100845ac4:     	stp	d9, d8, [sp, #0xb0]
100845ac8:     	stp	x28, x27, [sp, #0xc0]
100845acc:     	stp	x26, x25, [sp, #0xd0]
100845ad0:     	stp	x24, x23, [sp, #0xe0]
100845ad4:     	stp	x22, x21, [sp, #0xf0]
100845ad8:     	stp	x20, x19, [sp, #0x100]
100845adc:     	stp	x29, x30, [sp, #0x110]
100845ae0:     	add	x29, sp, #0x110
100845ae4:     	mov.16b	v9, v2
100845ae8:     	mov.16b	v8, v0
100845aec:     	fmov	x19, d8
100845af0:     	fmov	x21, d1
100845af4:     	fmov	x23, d9
100845af8:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100845afc:     	add	x27, x21, x8
100845b00:     	add	x24, x23, x8
100845b04:     	fcmp	d2, #0.0
100845b08:     	ccmp	x24, #0x2, #0x0, ne
100845b0c:     	b.hi	0x100845b1c <_js_json_stringify_full+0x5c>
100845b10:     	cmp	x27, #0x2
100845b14:     	b.lo	0x100845b2c <_js_json_stringify_full+0x6c>
100845b18:     	b	0x100846098 <_js_json_stringify_full+0x5d8>
100845b1c:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
100845b20:     	cmp	x23, x8
100845b24:     	ccmp	x27, #0x2, #0x2, eq
100845b28:     	b.hs	0x100846098 <_js_json_stringify_full+0x5d8>
100845b2c:     	mov	x8, #-0x2               ; =-2
100845b30:     	movk	x8, #0x8003, lsl #48
100845b34:     	add	x8, x19, x8
100845b38:     	cmp	x8, #0x3
100845b3c:     	b.hs	0x100845b50 <_js_json_stringify_full+0x90>
100845b40:     	adrp	x9, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4eb0>
100845b44:     	add	x9, x9, #0x6d8
100845b48:     	ldr	x20, [x9, x8, lsl #3]
100845b4c:     	b	0x100846f68 <_js_json_stringify_full+0x14a8>
100845b50:     	strb	wzr, [sp, #0x4c]
100845b54:     	str	wzr, [sp, #0x48]
100845b58:     	and	x8, x19, #0xffff000000000000
100845b5c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845b60:     	cmp	x8, x9
100845b64:     	b.eq	0x100845bd8 <_js_json_stringify_full+0x118>
100845b68:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845b6c:     	cmp	x8, x9
100845b70:     	b.ne	0x100845fd4 <_js_json_stringify_full+0x514>
100845b74:     	ubfx	x10, x19, #40, #8
100845b78:     	cbz	x10, 0x100845bc8 <_js_json_stringify_full+0x108>
100845b7c:     	strb	w19, [sp, #0x48]
100845b80:     	cmp	x10, #0x1
100845b84:     	b.eq	0x100845bc8 <_js_json_stringify_full+0x108>
100845b88:     	lsr	x9, x19, #8
100845b8c:     	strb	w9, [sp, #0x49]
100845b90:     	cmp	x10, #0x2
100845b94:     	b.eq	0x100845bc8 <_js_json_stringify_full+0x108>
100845b98:     	lsr	x9, x19, #16
100845b9c:     	strb	w9, [sp, #0x4a]
100845ba0:     	cmp	x10, #0x3
100845ba4:     	b.eq	0x100845bc8 <_js_json_stringify_full+0x108>
100845ba8:     	lsr	x9, x19, #24
100845bac:     	strb	w9, [sp, #0x4b]
100845bb0:     	cmp	x10, #0x4
100845bb4:     	b.eq	0x100845bc8 <_js_json_stringify_full+0x108>
100845bb8:     	lsr	x9, x19, #32
100845bbc:     	strb	w9, [sp, #0x4c]
100845bc0:     	cmp	x10, #0x5
100845bc4:     	b.ne	0x10084773c <_js_json_stringify_full+0x1c7c>
100845bc8:     	add	x11, sp, #0x48
100845bcc:     	cmp	w10, #0x3
100845bd0:     	b.ls	0x100845bf0 <_js_json_stringify_full+0x130>
100845bd4:     	b	0x100845fd4 <_js_json_stringify_full+0x514>
100845bd8:     	ands	x9, x19, #0xffffffffffff
100845bdc:     	b.eq	0x100846098 <_js_json_stringify_full+0x5d8>
100845be0:     	add	x11, x9, #0x14
100845be4:     	ldr	w10, [x9, #0x4]
100845be8:     	cmp	w10, #0x3
100845bec:     	b.hi	0x100845fd4 <_js_json_stringify_full+0x514>
100845bf0:     	stur	wzr, [sp, #0x81]
100845bf4:     	mov	w9, #0x22               ; =34
100845bf8:     	strb	w9, [sp, #0x80]
100845bfc:     	cbz	w10, 0x100845c34 <_js_json_stringify_full+0x174>
100845c00:     	add	x12, sp, #0x80
100845c04:     	ldrb	w13, [x11]
100845c08:     	sxtb	w15, w13
100845c0c:     	cmp	w13, #0xb
100845c10:     	b.le	0x100845c3c <_js_json_stringify_full+0x17c>
100845c14:     	cmp	w13, #0x21
100845c18:     	b.gt	0x100845c5c <_js_json_stringify_full+0x19c>
100845c1c:     	cmp	w13, #0xc
100845c20:     	b.eq	0x100845c90 <_js_json_stringify_full+0x1d0>
100845c24:     	cmp	w13, #0xd
100845c28:     	b.ne	0x100845c6c <_js_json_stringify_full+0x1ac>
100845c2c:     	mov	w15, #0x72              ; =114
100845c30:     	b	0x100845c9c <_js_json_stringify_full+0x1dc>
100845c34:     	mov	w12, #0x1               ; =1
100845c38:     	b	0x100845cc4 <_js_json_stringify_full+0x204>
100845c3c:     	cmp	w13, #0x8
100845c40:     	b.eq	0x100845c88 <_js_json_stringify_full+0x1c8>
100845c44:     	cmp	w13, #0x9
100845c48:     	b.eq	0x100845c98 <_js_json_stringify_full+0x1d8>
100845c4c:     	cmp	w13, #0xa
100845c50:     	b.ne	0x100845c6c <_js_json_stringify_full+0x1ac>
100845c54:     	mov	w15, #0x6e              ; =110
100845c58:     	b	0x100845c9c <_js_json_stringify_full+0x1dc>
100845c5c:     	cmp	w13, #0x22
100845c60:     	b.eq	0x100845c9c <_js_json_stringify_full+0x1dc>
100845c64:     	cmp	w13, #0x5c
100845c68:     	b.eq	0x100845c9c <_js_json_stringify_full+0x1dc>
100845c6c:     	cmp	w15, #0x20
100845c70:     	b.lt	0x100845fd4 <_js_json_stringify_full+0x514>
100845c74:     	mov	w14, #0x0               ; =0
100845c78:     	add	x13, x12, #0x2
100845c7c:     	mov	w12, #0x2               ; =2
100845c80:     	mov	w16, #0x1               ; =1
100845c84:     	b	0x100845cb4 <_js_json_stringify_full+0x1f4>
100845c88:     	mov	w15, #0x62              ; =98
100845c8c:     	b	0x100845c9c <_js_json_stringify_full+0x1dc>
100845c90:     	mov	w15, #0x66              ; =102
100845c94:     	b	0x100845c9c <_js_json_stringify_full+0x1dc>
100845c98:     	mov	w15, #0x74              ; =116
100845c9c:     	add	x13, x12, #0x3
100845ca0:     	mov	w12, #0x5c              ; =92
100845ca4:     	strb	w12, [sp, #0x81]
100845ca8:     	mov	w14, #0x1               ; =1
100845cac:     	mov	w12, #0x3               ; =3
100845cb0:     	mov	w16, #0x2               ; =2
100845cb4:     	add	x17, sp, #0x80
100845cb8:     	strb	w15, [x17, x16]
100845cbc:     	cmp	w10, #0x1
100845cc0:     	b.ne	0x100845cfc <_js_json_stringify_full+0x23c>
100845cc4:     	add	x10, sp, #0x80
100845cc8:     	strb	w9, [x10, x12]
100845ccc:     	add	x8, x12, #0x1
100845cd0:     	cmp	x12, #0x3
100845cd4:     	b.hs	0x100845ce8 <_js_json_stringify_full+0x228>
100845cd8:     	mov	x13, #0x0               ; =0
100845cdc:     	mov	x11, #0x0               ; =0
100845ce0:     	add	x9, sp, #0x80
100845ce4:     	b	0x100845f44 <_js_json_stringify_full+0x484>
100845ce8:     	cmp	x12, #0xf
100845cec:     	b.hs	0x100845d2c <_js_json_stringify_full+0x26c>
100845cf0:     	mov	x11, #0x0               ; =0
100845cf4:     	mov	x13, #0x0               ; =0
100845cf8:     	b	0x100845ea0 <_js_json_stringify_full+0x3e0>
100845cfc:     	ldrb	w16, [x11, #0x1]
100845d00:     	sxtb	w15, w16
100845d04:     	cmp	w16, #0xb
100845d08:     	b.le	0x100845f74 <_js_json_stringify_full+0x4b4>
100845d0c:     	cmp	w16, #0x21
100845d10:     	b.gt	0x100845f94 <_js_json_stringify_full+0x4d4>
100845d14:     	cmp	w16, #0xc
100845d18:     	b.eq	0x100845fc4 <_js_json_stringify_full+0x504>
100845d1c:     	cmp	w16, #0xd
100845d20:     	b.ne	0x100845fa4 <_js_json_stringify_full+0x4e4>
100845d24:     	mov	w15, #0x72              ; =114
100845d28:     	b	0x100845fd0 <_js_json_stringify_full+0x510>
100845d2c:     	and	x12, x8, #0xc
100845d30:     	and	x11, x8, #0x10
100845d34:     	add	x13, sp, #0x80
100845d38:     	add	x9, x13, x11
100845d3c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5eb0>
100845d40:     	ldr	q0, [x14, #0x850]
100845d44:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5eb0>
100845d48:     	ldr	q1, [x14, #0x860]
100845d4c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5eb0>
100845d50:     	ldr	q2, [x14, #0x870]
100845d54:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5eb0>
100845d58:     	ldr	q3, [x14, #0x880]
100845d5c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5eb0>
100845d60:     	ldr	q4, [x14, #0x890]
100845d64:     	movi.2d	v5, #0000000000000000
100845d68:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5eb0>
100845d6c:     	ldr	q6, [x14, #0x8a0]
100845d70:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4eb0>
100845d74:     	ldr	q7, [x14, #0x9c0]
100845d78:     	mov	w14, #0x10              ; =16
100845d7c:     	movi.2d	v16, #0000000000000000
100845d80:     	dup.2d	v17, x14
100845d84:     	adrp	x14, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x336ba>
100845d88:     	ldr	q19, [x14, #0x8c0]
100845d8c:     	and	x14, x8, #0x10
100845d90:     	movi.2d	v20, #0000000000000000
100845d94:     	movi.2d	v18, #0000000000000000
100845d98:     	movi.2d	v23, #0000000000000000
100845d9c:     	movi.2d	v21, #0000000000000000
100845da0:     	movi.2d	v24, #0000000000000000
100845da4:     	movi.2d	v22, #0000000000000000
100845da8:     	ldr	q25, [x13], #0x10
100845dac:     	ushll.8h	v26, v25, #0x0
100845db0:     	ushll2.4s	v27, v26, #0x0
100845db4:     	ushll2.2d	v28, v27, #0x0
100845db8:     	ushll2.8h	v25, v25, #0x0
100845dbc:     	ushll.4s	v29, v25, #0x0
100845dc0:     	ushll2.2d	v30, v29, #0x0
100845dc4:     	ushll.2d	v29, v29, #0x0
100845dc8:     	ushll.2d	v27, v27, #0x0
100845dcc:     	ushll.4s	v26, v26, #0x0
100845dd0:     	ushll2.2d	v31, v26, #0x0
100845dd4:     	ushll2.4s	v25, v25, #0x0
100845dd8:     	ushll.2d	v8, v25, #0x0
100845ddc:     	ushll.2d	v26, v26, #0x0
100845de0:     	ushll2.2d	v25, v25, #0x0
100845de4:     	shl.2d	v9, v0, #0x3
100845de8:     	ushl.2d	v25, v25, v9
100845dec:     	shl.2d	v9, v19, #0x3
100845df0:     	ushl.2d	v26, v26, v9
100845df4:     	shl.2d	v9, v1, #0x3
100845df8:     	ushl.2d	v8, v8, v9
100845dfc:     	shl.2d	v9, v7, #0x3
100845e00:     	ushl.2d	v31, v31, v9
100845e04:     	shl.2d	v9, v6, #0x3
100845e08:     	ushl.2d	v27, v27, v9
100845e0c:     	shl.2d	v9, v3, #0x3
100845e10:     	ushl.2d	v29, v29, v9
100845e14:     	shl.2d	v9, v2, #0x3
100845e18:     	ushl.2d	v30, v30, v9
100845e1c:     	shl.2d	v9, v4, #0x3
100845e20:     	ushl.2d	v28, v28, v9
100845e24:     	orr.16b	v18, v28, v18
100845e28:     	orr.16b	v21, v30, v21
100845e2c:     	orr.16b	v23, v29, v23
100845e30:     	orr.16b	v20, v27, v20
100845e34:     	orr.16b	v5, v31, v5
100845e38:     	orr.16b	v24, v8, v24
100845e3c:     	orr.16b	v16, v26, v16
100845e40:     	orr.16b	v22, v25, v22
100845e44:     	add.2d	v6, v6, v17
100845e48:     	add.2d	v7, v7, v17
100845e4c:     	add.2d	v19, v19, v17
100845e50:     	add.2d	v4, v4, v17
100845e54:     	add.2d	v3, v3, v17
100845e58:     	add.2d	v2, v2, v17
100845e5c:     	add.2d	v1, v1, v17
100845e60:     	add.2d	v0, v0, v17
100845e64:     	subs	x14, x14, #0x10
100845e68:     	b.ne	0x100845da8 <_js_json_stringify_full+0x2e8>
100845e6c:     	orr.16b	v0, v16, v23
100845e70:     	orr.16b	v1, v20, v24
100845e74:     	orr.16b	v0, v0, v1
100845e78:     	orr.16b	v1, v5, v21
100845e7c:     	orr.16b	v2, v18, v22
100845e80:     	orr.16b	v1, v1, v2
100845e84:     	orr.16b	v0, v0, v1
100845e88:     	mov	d1, v0[1]
100845e8c:     	orr.8b	v0, v0, v1
100845e90:     	fmov	x13, d0
100845e94:     	cmp	x8, x11
100845e98:     	b.eq	0x100845f64 <_js_json_stringify_full+0x4a4>
100845e9c:     	cbz	x12, 0x100845f44 <_js_json_stringify_full+0x484>
100845ea0:     	mov	x14, x11
100845ea4:     	and	x11, x8, #0x1c
100845ea8:     	add	x15, sp, #0x80
100845eac:     	add	x9, x15, x11
100845eb0:     	fmov	d0, x13
100845eb4:     	movi.2d	v1, #0000000000000000
100845eb8:     	dup.2d	v3, x14
100845ebc:     	adrp	x12, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4eb0>
100845ec0:     	ldr	q2, [x12, #0x9c0]
100845ec4:     	orr.16b	v2, v3, v2
100845ec8:     	adrp	x12, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x336ba>
100845ecc:     	ldr	q4, [x12, #0x8c0]
100845ed0:     	orr.16b	v3, v3, v4
100845ed4:     	sub	x12, x14, x11
100845ed8:     	add	x13, x15, x14
100845edc:     	movi.2d	v4, #0x000000000000ff
100845ee0:     	mov	w14, #0x4               ; =4
100845ee4:     	dup.2d	v5, x14
100845ee8:     	ldr	s6, [x13], #0x4
100845eec:     	ushll.8h	v6, v6, #0x0
100845ef0:     	ushll.4s	v6, v6, #0x0
100845ef4:     	ushll2.2d	v7, v6, #0x0
100845ef8:     	and.16b	v7, v7, v4
100845efc:     	ushll.2d	v6, v6, #0x0
100845f00:     	and.16b	v6, v6, v4
100845f04:     	shl.2d	v16, v2, #0x3
100845f08:     	shl.2d	v17, v3, #0x3
100845f0c:     	ushl.2d	v6, v6, v17
100845f10:     	ushl.2d	v7, v7, v16
100845f14:     	orr.16b	v1, v7, v1
100845f18:     	orr.16b	v0, v6, v0
100845f1c:     	add.2d	v2, v2, v5
100845f20:     	add.2d	v3, v3, v5
100845f24:     	adds	x12, x12, #0x4
100845f28:     	b.ne	0x100845ee8 <_js_json_stringify_full+0x428>
100845f2c:     	orr.16b	v0, v0, v1
100845f30:     	mov	d1, v0[1]
100845f34:     	orr.8b	v0, v0, v1
100845f38:     	fmov	x13, d0
100845f3c:     	cmp	x8, x11
100845f40:     	b.eq	0x100845f64 <_js_json_stringify_full+0x4a4>
100845f44:     	add	x10, x10, x8
100845f48:     	lsl	x11, x11, #3
100845f4c:     	ldrb	w12, [x9], #0x1
100845f50:     	lsl	x12, x12, x11
100845f54:     	orr	x13, x12, x13
100845f58:     	add	x11, x11, #0x8
100845f5c:     	cmp	x9, x10
100845f60:     	b.ne	0x100845f4c <_js_json_stringify_full+0x48c>
100845f64:     	orr	x8, x13, x8, lsl #40
100845f68:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845f6c:     	orr	x20, x8, x9
100845f70:     	b	0x100846f68 <_js_json_stringify_full+0x14a8>
100845f74:     	cmp	w16, #0x8
100845f78:     	b.eq	0x100845fbc <_js_json_stringify_full+0x4fc>
100845f7c:     	cmp	w16, #0x9
100845f80:     	b.eq	0x100845fcc <_js_json_stringify_full+0x50c>
100845f84:     	cmp	w16, #0xa
100845f88:     	b.ne	0x100845fa4 <_js_json_stringify_full+0x4e4>
100845f8c:     	mov	w15, #0x6e              ; =110
100845f90:     	b	0x100845fd0 <_js_json_stringify_full+0x510>
100845f94:     	cmp	w16, #0x22
100845f98:     	b.eq	0x100845fd0 <_js_json_stringify_full+0x510>
100845f9c:     	cmp	w16, #0x5c
100845fa0:     	b.eq	0x100845fd0 <_js_json_stringify_full+0x510>
100845fa4:     	cmp	w15, #0x20
100845fa8:     	b.lt	0x100845fd4 <_js_json_stringify_full+0x514>
100845fac:     	add	x13, sp, #0x80
100845fb0:     	strb	w15, [x13, x12]
100845fb4:     	add	x12, x12, #0x1
100845fb8:     	b	0x10084655c <_js_json_stringify_full+0xa9c>
100845fbc:     	mov	w15, #0x62              ; =98
100845fc0:     	b	0x100845fd0 <_js_json_stringify_full+0x510>
100845fc4:     	mov	w15, #0x66              ; =102
100845fc8:     	b	0x100845fd0 <_js_json_stringify_full+0x510>
100845fcc:     	mov	w15, #0x74              ; =116
100845fd0:     	tbz	w14, #0x0, 0x100846548 <_js_json_stringify_full+0xa88>
100845fd4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100845fd8:     	cmp	x8, x9
100845fdc:     	b.eq	0x100846024 <_js_json_stringify_full+0x564>
100845fe0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845fe4:     	cmp	x8, x9
100845fe8:     	b.ne	0x100846098 <_js_json_stringify_full+0x5d8>
100845fec:     	and	x8, x19, #0xffffffffffff
100845ff0:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
100845ff4:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100845ff8:     	movk	x10, #0xffef, lsl #16
100845ffc:     	cmp	x9, x10
100846000:     	b.hi	0x100846098 <_js_json_stringify_full+0x5d8>
100846004:     	ldr	w8, [x8, #0x4]
100846008:     	cmp	w8, #0x40
10084600c:     	b.lo	0x100846098 <_js_json_stringify_full+0x5d8>
100846010:     	and	x0, x19, #0xffffffffffff
100846014:     	bl	0x1004f2ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100846018:     	cmp	x0, #0x1
10084601c:     	b.ne	0x100846098 <_js_json_stringify_full+0x5d8>
100846020:     	b	0x1008461e4 <_js_json_stringify_full+0x724>
100846024:     	and	x25, x19, #0xffffffffffff
100846028:     	and	x0, x19, #0xffffffffffff
10084602c:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100846030:     	cbz	x0, 0x100846064 <_js_json_stringify_full+0x5a4>
100846034:     	ldrb	w8, [x0]
100846038:     	cmp	w8, #0x2
10084603c:     	b.ne	0x100846064 <_js_json_stringify_full+0x5a4>
100846040:     	ldrsb	w8, [x0, #0x1]
100846044:     	tbnz	w8, #0x1f, 0x100846064 <_js_json_stringify_full+0x5a4>
100846048:     	ldrh	w8, [x0, #0x2]
10084604c:     	tbnz	w8, #0xb, 0x100846064 <_js_json_stringify_full+0x5a4>
100846050:     	ldr	w8, [x0, #0x4]
100846054:     	cmp	w8, #0x18
100846058:     	b.lo	0x100846064 <_js_json_stringify_full+0x5a4>
10084605c:     	ldr	w8, [x25]
100846060:     	cbz	w8, 0x1008470bc <_js_json_stringify_full+0x15fc>
100846064:     	and	x0, x19, #0xffffffffffff
100846068:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084606c:     	cbz	x0, 0x100846098 <_js_json_stringify_full+0x5d8>
100846070:     	ldrb	w8, [x0]
100846074:     	cmp	w8, #0x2
100846078:     	b.ne	0x100846098 <_js_json_stringify_full+0x5d8>
10084607c:     	ldrh	w8, [x0, #0x2]
100846080:     	tbnz	w8, #0xb, 0x100846098 <_js_json_stringify_full+0x5d8>
100846084:     	ldr	w8, [x0, #0x4]
100846088:     	cmp	w8, #0x18
10084608c:     	b.lo	0x100846098 <_js_json_stringify_full+0x5d8>
100846090:     	ldr	w8, [x25]
100846094:     	cbz	w8, 0x100847060 <_js_json_stringify_full+0x15a0>
100846098:     	mov	x20, #0x1               ; =1
10084609c:     	movk	x20, #0x7ffc, lsl #48
1008460a0:     	cmp	x19, x20
1008460a4:     	b.eq	0x100846f68 <_js_json_stringify_full+0x14a8>
1008460a8:     	and	x22, x19, #0xffff000000000000
1008460ac:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008460b0:     	cmp	x22, x8
1008460b4:     	b.ne	0x1008460ec <_js_json_stringify_full+0x62c>
1008460b8:     	and	x8, x19, #0xffffffffffff
1008460bc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1008460c0:     	b.lo	0x1008460d8 <_js_json_stringify_full+0x618>
1008460c4:     	ldr	w8, [x8, #0xc]
1008460c8:     	mov	w9, #0x4f53             ; =20307
1008460cc:     	movk	w9, #0x434c, lsl #16
1008460d0:     	cmp	w8, w9
1008460d4:     	b.eq	0x100846f68 <_js_json_stringify_full+0x14a8>
1008460d8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008460dc:     	cmp	x22, x8
1008460e0:     	b.ne	0x100846118 <_js_json_stringify_full+0x658>
1008460e4:     	and	x0, x19, #0xffffffffffff
1008460e8:     	b	0x100846140 <_js_json_stringify_full+0x680>
1008460ec:     	lsr	x8, x19, #52
1008460f0:     	cbnz	x8, 0x1008461c8 <_js_json_stringify_full+0x708>
1008460f4:     	and	x8, x19, #0x7
1008460f8:     	cbz	x19, 0x100846124 <_js_json_stringify_full+0x664>
1008460fc:     	cbnz	x8, 0x100846124 <_js_json_stringify_full+0x664>
100846100:     	mov	x0, x19
100846104:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846108:     	mov	x8, x19
10084610c:     	tbnz	w0, #0x0, 0x1008460bc <_js_json_stringify_full+0x5fc>
100846110:     	mov	x8, #0x0                ; =0
100846114:     	b	0x100846124 <_js_json_stringify_full+0x664>
100846118:     	lsr	x8, x19, #52
10084611c:     	cbnz	x8, 0x1008461c8 <_js_json_stringify_full+0x708>
100846120:     	and	x8, x19, #0x7
100846124:     	cbz	x19, 0x1008461c8 <_js_json_stringify_full+0x708>
100846128:     	cbnz	x8, 0x1008461c8 <_js_json_stringify_full+0x708>
10084612c:     	mov	x0, x19
100846130:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846134:     	mov	x8, x0
100846138:     	mov	x0, x19
10084613c:     	tbz	w8, #0x0, 0x1008461c8 <_js_json_stringify_full+0x708>
100846140:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100846144:     	b.lo	0x1008461c8 <_js_json_stringify_full+0x708>
100846148:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084614c:     	add	x8, x8, #0xfb0
100846150:     	ldaprb	w8, [x8]
100846154:     	cbz	w8, 0x1008461c8 <_js_json_stringify_full+0x708>
100846158:     	lsr	x8, x0, #3
10084615c:     	mov	x9, #0x7c15             ; =31765
100846160:     	movk	x9, #0x7f4a, lsl #16
100846164:     	movk	x9, #0x79b9, lsl #32
100846168:     	movk	x9, #0x9e37, lsl #48
10084616c:     	mul	x8, x8, x9
100846170:     	lsr	x10, x8, #54
100846174:     	lsr	x11, x8, #60
100846178:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084617c:     	add	x9, x9, #0xf30
100846180:     	add	x11, x9, x11, lsl #3
100846184:     	ldapr	x11, [x11]
100846188:     	lsr	x10, x11, x10
10084618c:     	tbz	w10, #0x0, 0x1008461c8 <_js_json_stringify_full+0x708>
100846190:     	lsr	x10, x8, #44
100846194:     	ubfx	x11, x8, #50, #4
100846198:     	add	x11, x9, x11, lsl #3
10084619c:     	ldapr	x11, [x11]
1008461a0:     	lsr	x10, x11, x10
1008461a4:     	tbz	w10, #0x0, 0x1008461c8 <_js_json_stringify_full+0x708>
1008461a8:     	lsr	x10, x8, #34
1008461ac:     	ubfx	x8, x8, #40, #4
1008461b0:     	add	x8, x9, x8, lsl #3
1008461b4:     	ldapr	x8, [x8]
1008461b8:     	lsr	x8, x8, x10
1008461bc:     	tbz	w8, #0x0, 0x1008461c8 <_js_json_stringify_full+0x708>
1008461c0:     	bl	0x10034ca2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
1008461c4:     	tbnz	w0, #0x0, 0x100846f68 <_js_json_stringify_full+0x14a8>
1008461c8:     	cmp	x24, #0x3
1008461cc:     	ccmp	x27, #0x2, #0x2, lo
1008461d0:     	b.hs	0x1008461f0 <_js_json_stringify_full+0x730>
1008461d4:     	mov.16b	v0, v8
1008461d8:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
1008461dc:     	cmp	x0, #0x1
1008461e0:     	b.ne	0x1008461f0 <_js_json_stringify_full+0x730>
1008461e4:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
1008461e8:     	bfxil	x20, x1, #0, #48
1008461ec:     	b	0x100846f68 <_js_json_stringify_full+0x14a8>
1008461f0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008461f4:     	cmp	x22, x8
1008461f8:     	b.ne	0x100846248 <_js_json_stringify_full+0x788>
1008461fc:     	ands	x22, x19, #0xffffffffffff
100846200:     	b.eq	0x100846248 <_js_json_stringify_full+0x788>
100846204:     	mov	x0, x22
100846208:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084620c:     	cbz	w0, 0x100846248 <_js_json_stringify_full+0x788>
100846210:     	ldurb	w8, [x22, #-0x8]
100846214:     	cmp	w8, #0x9
100846218:     	b.ne	0x100846248 <_js_json_stringify_full+0x788>
10084621c:     	ldr	w8, [x22, #0x4]
100846220:     	mov	w9, #0x5841             ; =22593
100846224:     	movk	w9, #0x4c5a, lsl #16
100846228:     	cmp	w8, w9
10084622c:     	b.ne	0x100846248 <_js_json_stringify_full+0x788>
100846230:     	mov	x0, x22
100846234:     	bl	0x100688364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100846238:     	cbz	x0, 0x100846248 <_js_json_stringify_full+0x788>
10084623c:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100846240:     	bfxil	x19, x0, #0, #48
100846244:     	fmov	d8, x19
100846248:     	mov	w8, #0x7ffd             ; =32765
10084624c:     	cmp	x8, x23, lsr #48
100846250:     	b.ne	0x100846264 <_js_json_stringify_full+0x7a4>
100846254:     	and	x1, x23, #0xffffffffffff
100846258:     	cmp	x1, #0x100, lsl #12     ; =0x100000
10084625c:     	b.hs	0x100846278 <_js_json_stringify_full+0x7b8>
100846260:     	b	0x1008462cc <_js_json_stringify_full+0x80c>
100846264:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
100846268:     	mov	x9, #0xfffffff00000     ; =281474975662080
10084626c:     	mov	x1, x23
100846270:     	cmp	x8, x9
100846274:     	b.hs	0x1008462cc <_js_json_stringify_full+0x80c>
100846278:     	lsr	x8, x1, #47
10084627c:     	cbnz	x8, 0x1008462cc <_js_json_stringify_full+0x80c>
100846280:     	add	x0, sp, #0x80
100846284:     	bl	0x10076e16c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
100846288:     	ldr	w8, [sp, #0x80]
10084628c:     	tbz	w8, #0x0, 0x1008462cc <_js_json_stringify_full+0x80c>
100846290:     	ldr	w8, [sp, #0x88]
100846294:     	mov	w9, #-0xff30            ; =-65328
100846298:     	cmp	w8, w9
10084629c:     	b.eq	0x1008462c0 <_js_json_stringify_full+0x800>
1008462a0:     	mov	w9, #-0xff2f            ; =-65327
1008462a4:     	cmp	w8, w9
1008462a8:     	b.ne	0x1008462cc <_js_json_stringify_full+0x80c>
1008462ac:     	mov.16b	v0, v9
1008462b0:     	bl	0x10084837c <_js_jsvalue_to_string>
1008462b4:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
1008462b8:     	bfxil	x23, x0, #0, #48
1008462bc:     	b	0x1008462cc <_js_json_stringify_full+0x80c>
1008462c0:     	mov.16b	v0, v9
1008462c4:     	bl	0x10086f920 <_js_number_coerce>
1008462c8:     	fmov	x23, d0
1008462cc:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
1008462d0:     	add	x8, x23, x8
1008462d4:     	cmp	x8, #0x3
1008462d8:     	b.hs	0x1008462f0 <_js_json_stringify_full+0x830>
1008462dc:     	mov	x22, #0x0               ; =0
1008462e0:     	mov	w8, #0x1                ; =1
1008462e4:     	stp	xzr, x8, [sp, #0x10]
1008462e8:     	str	xzr, [sp, #0x20]
1008462ec:     	b	0x1008465a4 <_js_json_stringify_full+0xae4>
1008462f0:     	and	x8, x23, #0xffff000000000000
1008462f4:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008462f8:     	cmp	x8, x9
1008462fc:     	b.eq	0x100846320 <_js_json_stringify_full+0x860>
100846300:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846304:     	cmp	x8, x9
100846308:     	b.ne	0x1008463ac <_js_json_stringify_full+0x8ec>
10084630c:     	and	x8, x23, #0xffffffffffff
100846310:     	cmp	x8, #0x1, lsl #12       ; =0x1000
100846314:     	b.hs	0x1008463f4 <_js_json_stringify_full+0x934>
100846318:     	mov	x9, #0x0                ; =0
10084631c:     	b	0x1008463fc <_js_json_stringify_full+0x93c>
100846320:     	strb	wzr, [sp, #0x4c]
100846324:     	str	wzr, [sp, #0x48]
100846328:     	ubfx	x1, x23, #40, #8
10084632c:     	cbz	x1, 0x10084637c <_js_json_stringify_full+0x8bc>
100846330:     	strb	w23, [sp, #0x48]
100846334:     	cmp	x1, #0x1
100846338:     	b.eq	0x10084637c <_js_json_stringify_full+0x8bc>
10084633c:     	lsr	x8, x23, #8
100846340:     	strb	w8, [sp, #0x49]
100846344:     	cmp	x1, #0x2
100846348:     	b.eq	0x10084637c <_js_json_stringify_full+0x8bc>
10084634c:     	lsr	x8, x23, #16
100846350:     	strb	w8, [sp, #0x4a]
100846354:     	cmp	x1, #0x3
100846358:     	b.eq	0x10084637c <_js_json_stringify_full+0x8bc>
10084635c:     	lsr	x8, x23, #24
100846360:     	strb	w8, [sp, #0x4b]
100846364:     	cmp	x1, #0x4
100846368:     	b.eq	0x10084637c <_js_json_stringify_full+0x8bc>
10084636c:     	lsr	x8, x23, #32
100846370:     	strb	w8, [sp, #0x4c]
100846374:     	cmp	x1, #0x5
100846378:     	b.ne	0x10084773c <_js_json_stringify_full+0x1c7c>
10084637c:     	add	x8, sp, #0x80
100846380:     	add	x0, sp, #0x48
100846384:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100846388:     	ldr	w8, [sp, #0x80]
10084638c:     	ldp	x9, x22, [sp, #0x88]
100846390:     	cmp	w8, #0x0
100846394:     	csinc	x23, x9, xzr, eq
100846398:     	csel	x25, xzr, x22, ne
10084639c:     	tbz	x25, #0x3f, 0x1008464dc <_js_json_stringify_full+0xa1c>
1008463a0:     	mov	x0, #0x0                ; =0
1008463a4:     	mov	x1, x22
1008463a8:     	bl	0x100b12300 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008463ac:     	add	x8, x20, #0x3
1008463b0:     	cmp	x23, x8
1008463b4:     	b.eq	0x1008462dc <_js_json_stringify_full+0x81c>
1008463b8:     	fmov	d0, x23
1008463bc:     	fcvtzu	x8, d0
1008463c0:     	mov	w9, #0xa                ; =10
1008463c4:     	cmp	x8, #0xa
1008463c8:     	csel	x3, x8, x9, lo
1008463cc:     	adrp	x1, 0x100c43000 <_PERRY_EMPTY_STRING+0x1af4>
1008463d0:     	add	x1, x1, #0x69c
1008463d4:     	add	x0, sp, #0x80
1008463d8:     	mov	w2, #0x1                ; =1
1008463dc:     	bl	0x1002305f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
1008463e0:     	ldr	x22, [sp, #0x90]
1008463e4:     	str	x22, [sp, #0x20]
1008463e8:     	ldr	q0, [sp, #0x80]
1008463ec:     	str	q0, [sp, #0x10]
1008463f0:     	b	0x1008465a4 <_js_json_stringify_full+0xae4>
1008463f4:     	ldr	w22, [x8, #0x4]
1008463f8:     	add	x9, x8, #0x14
1008463fc:     	mov	x14, #0x0               ; =0
100846400:     	mov	x8, #0x0                ; =0
100846404:     	cmp	x9, #0x0
100846408:     	csel	x24, xzr, x22, eq
10084640c:     	csinc	x23, x9, xzr, ne
100846410:     	add	x9, x23, x24
100846414:     	mov	w10, #0x1               ; =1
100846418:     	mov	x11, x23
10084641c:     	b	0x10084644c <_js_json_stringify_full+0x98c>
100846420:     	add	x12, x11, #0x2
100846424:     	bfi	w15, w13, #6, #5
100846428:     	mov	x13, x15
10084642c:     	sub	x11, x25, x11
100846430:     	add	x14, x11, x12
100846434:     	cmp	w13, #0x10, lsl #12     ; =0x10000
100846438:     	cinc	x11, x10, hs
10084643c:     	add	x8, x11, x8
100846440:     	mov	x11, x12
100846444:     	cmp	x8, #0xa
100846448:     	b.hi	0x100846504 <_js_json_stringify_full+0xa44>
10084644c:     	cmp	x11, x9
100846450:     	b.eq	0x1008464b4 <_js_json_stringify_full+0x9f4>
100846454:     	mov	x25, x14
100846458:     	mov	x12, x11
10084645c:     	ldrsb	w14, [x12], #0x1
100846460:     	and	w13, w14, #0xff
100846464:     	tbz	w14, #0x1f, 0x10084642c <_js_json_stringify_full+0x96c>
100846468:     	ldrb	w12, [x11, #0x1]
10084646c:     	and	w15, w12, #0x3f
100846470:     	cmp	w13, #0xe0
100846474:     	b.lo	0x100846420 <_js_json_stringify_full+0x960>
100846478:     	and	w14, w13, #0x1f
10084647c:     	ldrb	w12, [x11, #0x2]
100846480:     	and	w12, w12, #0x3f
100846484:     	orr	w15, w12, w15, lsl #6
100846488:     	cmp	w13, #0xf0
10084648c:     	b.lo	0x1008464a8 <_js_json_stringify_full+0x9e8>
100846490:     	add	x12, x11, #0x4
100846494:     	ldrb	w13, [x11, #0x3]
100846498:     	and	w13, w13, #0x3f
10084649c:     	orr	w13, w13, w15, lsl #6
1008464a0:     	bfi	w13, w14, #18, #3
1008464a4:     	b	0x10084642c <_js_json_stringify_full+0x96c>
1008464a8:     	add	x12, x11, #0x3
1008464ac:     	orr	w13, w15, w14, lsl #12
1008464b0:     	b	0x10084642c <_js_json_stringify_full+0x96c>
1008464b4:     	cbz	x24, 0x100846538 <_js_json_stringify_full+0xa78>
1008464b8:     	mov	x0, x24
1008464bc:     	mov	w1, #0x1                ; =1
1008464c0:     	bl	0x100b5f1c8 <_mi_malloc_aligned>
1008464c4:     	cbz	x0, 0x100847724 <_js_json_stringify_full+0x1c64>
1008464c8:     	mov	x26, x0
1008464cc:     	mov	x1, x23
1008464d0:     	mov	x2, x24
1008464d4:     	bl	0x100b61dec <_writev+0x100b61dec>
1008464d8:     	b	0x100846540 <_js_json_stringify_full+0xa80>
1008464dc:     	cbz	x25, 0x100846594 <_js_json_stringify_full+0xad4>
1008464e0:     	mov	x0, x25
1008464e4:     	mov	w1, #0x1                ; =1
1008464e8:     	bl	0x100b5f1c8 <_mi_malloc_aligned>
1008464ec:     	cbz	x0, 0x100847730 <_js_json_stringify_full+0x1c70>
1008464f0:     	mov	x24, x0
1008464f4:     	mov	x1, x23
1008464f8:     	mov	x2, x25
1008464fc:     	bl	0x100b61dec <_writev+0x100b61dec>
100846500:     	b	0x10084659c <_js_json_stringify_full+0xadc>
100846504:     	cbz	x25, 0x100846538 <_js_json_stringify_full+0xa78>
100846508:     	cmp	x25, x24
10084650c:     	b.hs	0x100846fb4 <_js_json_stringify_full+0x14f4>
100846510:     	ldrsb	w8, [x23, x25]
100846514:     	cmn	w8, #0x40
100846518:     	b.ge	0x100846fb8 <_js_json_stringify_full+0x14f8>
10084651c:     	adrp	x4, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846520:     	add	x4, x4, #0x270
100846524:     	mov	x0, x23
100846528:     	mov	x1, x24
10084652c:     	mov	x2, #0x0                ; =0
100846530:     	mov	x3, x25
100846534:     	bl	0x100b12678 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
100846538:     	mov	x22, #0x0               ; =0
10084653c:     	mov	w26, #0x1               ; =1
100846540:     	stp	x22, x26, [sp, #0x10]
100846544:     	b	0x1008465a0 <_js_json_stringify_full+0xae0>
100846548:     	add	x14, sp, #0x80
10084654c:     	mov	w16, #0x5c              ; =92
100846550:     	strb	w16, [x14, x12]
100846554:     	add	x12, x12, #0x2
100846558:     	strb	w15, [x13, #0x1]
10084655c:     	cmp	w10, #0x2
100846560:     	b.eq	0x100845cc4 <_js_json_stringify_full+0x204>
100846564:     	ldrb	w11, [x11, #0x2]
100846568:     	sxtb	w10, w11
10084656c:     	cmp	w11, #0xb
100846570:     	b.le	0x100847040 <_js_json_stringify_full+0x1580>
100846574:     	cmp	w11, #0x21
100846578:     	b.gt	0x10084708c <_js_json_stringify_full+0x15cc>
10084657c:     	cmp	w11, #0xc
100846580:     	b.eq	0x100847118 <_js_json_stringify_full+0x1658>
100846584:     	cmp	w11, #0xd
100846588:     	b.ne	0x10084709c <_js_json_stringify_full+0x15dc>
10084658c:     	mov	w10, #0x72              ; =114
100846590:     	b	0x100847124 <_js_json_stringify_full+0x1664>
100846594:     	mov	x22, #0x0               ; =0
100846598:     	mov	w24, #0x1               ; =1
10084659c:     	stp	x22, x24, [sp, #0x10]
1008465a0:     	str	x22, [sp, #0x20]
1008465a4:     	cmp	x27, #0x2
1008465a8:     	b.lo	0x1008466e8 <_js_json_stringify_full+0xc28>
1008465ac:     	and	x25, x21, #0xffff000000000000
1008465b0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008465b4:     	cmp	x25, x8
1008465b8:     	b.ne	0x1008466c4 <_js_json_stringify_full+0xc04>
1008465bc:     	and	x23, x21, #0xffffffffffff
1008465c0:     	cmp	x23, #0x100, lsl #12    ; =0x100000
1008465c4:     	b.lo	0x1008466e8 <_js_json_stringify_full+0xc28>
1008465c8:     	mov	x0, x23
1008465cc:     	bl	0x10050a640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
1008465d0:     	tbnz	w0, #0x0, 0x1008466e8 <_js_json_stringify_full+0xc28>
1008465d4:     	lsr	x8, x23, #51
1008465d8:     	cmp	x8, #0xfff
1008465dc:     	b.lo	0x1008465f4 <_js_json_stringify_full+0xb34>
1008465e0:     	mov	w8, #0x7ffc             ; =32764
1008465e4:     	cmp	x8, x23, lsr #48
1008465e8:     	b.eq	0x1008466e8 <_js_json_stringify_full+0xc28>
1008465ec:     	ands	x23, x23, #0xffffffffffff
1008465f0:     	b.eq	0x1008466e8 <_js_json_stringify_full+0xc28>
1008465f4:     	and	x8, x23, #0xfffffffffff00000
1008465f8:     	lsr	x9, x23, #47
1008465fc:     	cmp	x9, #0x0
100846600:     	ccmp	x8, #0x0, #0x4, eq
100846604:     	b.eq	0x1008466e8 <_js_json_stringify_full+0xc28>
100846608:     	tst	x23, #0x3
10084660c:     	ccmp	x23, #0x7, #0x0, eq
100846610:     	b.ls	0x100847354 <_js_json_stringify_full+0x1894>
100846614:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100846618:     	ldr	x8, [x8, #0x48]
10084661c:     	cmn	x8, #0x1
100846620:     	b.eq	0x1008472a4 <_js_json_stringify_full+0x17e4>
100846624:     	mrs	x9, TPIDRRO_EL0
100846628:     	and	x9, x9, #0xfffffffffffffff8
10084662c:     	ldr	x0, [x9, x8, lsl #3]
100846630:     	cbz	x0, 0x1008472a4 <_js_json_stringify_full+0x17e4>
100846634:     	lsr	x1, x23, #20
100846638:     	ldr	x8, [x0, #0x10]
10084663c:     	ldrb	w9, [x8]
100846640:     	cmp	w9, #0x2
100846644:     	b.ne	0x1008472bc <_js_json_stringify_full+0x17fc>
100846648:     	ldrb	w9, [x8, #0x88]
10084664c:     	tbz	w9, #0x0, 0x10084666c <_js_json_stringify_full+0xbac>
100846650:     	ldr	x9, [x8, #0x80]
100846654:     	cmp	x9, x1
100846658:     	b.ne	0x10084666c <_js_json_stringify_full+0xbac>
10084665c:     	ldp	x9, x10, [x8, #0x60]
100846660:     	cmp	x9, x23
100846664:     	ccmp	x10, x23, #0x0, ls
100846668:     	b.hi	0x10084729c <_js_json_stringify_full+0x17dc>
10084666c:     	ldrb	w9, [x8, #0xb8]
100846670:     	cbz	w9, 0x100846690 <_js_json_stringify_full+0xbd0>
100846674:     	ldr	x9, [x8, #0xb0]
100846678:     	cmp	x9, x1
10084667c:     	b.ne	0x100846690 <_js_json_stringify_full+0xbd0>
100846680:     	ldp	x9, x10, [x8, #0x90]
100846684:     	cmp	x9, x23
100846688:     	ccmp	x10, x23, #0x0, ls
10084668c:     	b.hi	0x100847524 <_js_json_stringify_full+0x1a64>
100846690:     	ldrb	w9, [x8, #0xe8]
100846694:     	cbz	w9, 0x1008470dc <_js_json_stringify_full+0x161c>
100846698:     	ldr	x9, [x8, #0xe0]
10084669c:     	cmp	x9, x1
1008466a0:     	b.ne	0x1008470dc <_js_json_stringify_full+0x161c>
1008466a4:     	ldr	x9, [x8, #0xc0]
1008466a8:     	cmp	x9, x23
1008466ac:     	b.hi	0x1008470dc <_js_json_stringify_full+0x161c>
1008466b0:     	ldr	x9, [x8, #0xc8]
1008466b4:     	cmp	x9, x23
1008466b8:     	b.ls	0x1008470dc <_js_json_stringify_full+0x161c>
1008466bc:     	add	x9, x8, #0xc0
1008466c0:     	b	0x100847528 <_js_json_stringify_full+0x1a68>
1008466c4:     	lsr	x8, x21, #52
1008466c8:     	cbnz	x8, 0x1008466e8 <_js_json_stringify_full+0xc28>
1008466cc:     	cbz	x21, 0x1008466e8 <_js_json_stringify_full+0xc28>
1008466d0:     	and	x8, x21, #0x7
1008466d4:     	cbnz	x8, 0x1008466e8 <_js_json_stringify_full+0xc28>
1008466d8:     	mov	x0, x21
1008466dc:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008466e0:     	mov	x23, x21
1008466e4:     	cbnz	w0, 0x1008465c0 <_js_json_stringify_full+0xb00>
1008466e8:     	mov	x25, #-0x1              ; =-1
1008466ec:     	str	x25, [sp, #0x30]
1008466f0:     	mov	w24, #0x1               ; =1
1008466f4:     	cmp	x27, #0x1
1008466f8:     	cset	w8, hi
1008466fc:     	tst	w8, w24
100846700:     	b.eq	0x100846774 <_js_json_stringify_full+0xcb4>
100846704:     	and	x23, x21, #0xffff000000000000
100846708:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084670c:     	cmp	x23, x8
100846710:     	b.ne	0x10084674c <_js_json_stringify_full+0xc8c>
100846714:     	and	x8, x21, #0xffffffffffff
100846718:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084671c:     	b.lo	0x100846774 <_js_json_stringify_full+0xcb4>
100846720:     	ldr	w8, [x8, #0xc]
100846724:     	mov	w9, #0x4f53             ; =20307
100846728:     	movk	w9, #0x434c, lsl #16
10084672c:     	cmp	w8, w9
100846730:     	b.ne	0x100846774 <_js_json_stringify_full+0xcb4>
100846734:     	and	x8, x21, #0xffffffffffff
100846738:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084673c:     	cmp	x23, x9
100846740:     	csel	x28, x8, x21, eq
100846744:     	mov	w27, #0x1               ; =1
100846748:     	b	0x100846778 <_js_json_stringify_full+0xcb8>
10084674c:     	lsr	x8, x21, #52
100846750:     	cbnz	x8, 0x100846774 <_js_json_stringify_full+0xcb4>
100846754:     	mov	w27, #0x0               ; =0
100846758:     	cbz	x21, 0x100846778 <_js_json_stringify_full+0xcb8>
10084675c:     	and	x8, x21, #0x7
100846760:     	cbnz	x8, 0x100846778 <_js_json_stringify_full+0xcb8>
100846764:     	mov	x0, x21
100846768:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084676c:     	mov	x8, x21
100846770:     	tbnz	w0, #0x0, 0x100846718 <_js_json_stringify_full+0xc58>
100846774:     	mov	w27, #0x0               ; =0
100846778:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084677c:     	add	x0, x0, #0xd78
100846780:     	ldr	x8, [x0]
100846784:     	blr	x8
100846788:     	mov	x21, x0
10084678c:     	ldr	w26, [x0]
100846790:     	add	w8, w26, #0x1
100846794:     	str	w8, [x0]
100846798:     	cbz	w26, 0x100846808 <_js_json_stringify_full+0xd48>
10084679c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008467a0:     	add	x0, x0, #0xd00
1008467a4:     	ldr	x8, [x0]
1008467a8:     	blr	x8
1008467ac:     	ldrb	w8, [x0, #0x20]
1008467b0:     	cmp	w8, #0x1
1008467b4:     	b.ne	0x100847594 <_js_json_stringify_full+0x1ad4>
1008467b8:     	ldr	x8, [x0]
1008467bc:     	cbnz	x8, 0x1008475a0 <_js_json_stringify_full+0x1ae0>
1008467c0:     	mov	x8, #-0x1               ; =-1
1008467c4:     	str	x8, [x0]
1008467c8:     	ldr	x23, [x0, #0x18]
1008467cc:     	ldr	x8, [x0, #0x8]
1008467d0:     	cmp	x23, x8
1008467d4:     	b.eq	0x100846f90 <_js_json_stringify_full+0x14d0>
1008467d8:     	ldr	x8, [x0, #0x10]
1008467dc:     	mov	w9, #0x18               ; =24
1008467e0:     	madd	x8, x23, x9, x8
1008467e4:     	mov	w9, #0x8                ; =8
1008467e8:     	stp	xzr, x9, [x8]
1008467ec:     	str	xzr, [x8, #0x10]
1008467f0:     	add	x8, x23, #0x1
1008467f4:     	str	x8, [x0, #0x18]
1008467f8:     	ldr	x8, [x0]
1008467fc:     	add	x8, x8, #0x1
100846800:     	str	x8, [x0]
100846804:     	b	0x100846870 <_js_json_stringify_full+0xdb0>
100846808:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084680c:     	add	x0, x0, #0xdc0
100846810:     	ldr	x8, [x0]
100846814:     	blr	x8
100846818:     	strb	wzr, [x0]
10084681c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846820:     	add	x0, x0, #0xdf0
100846824:     	ldr	x8, [x0]
100846828:     	blr	x8
10084682c:     	strb	wzr, [x0]
100846830:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100846834:     	ldr	w23, [x8, #0x5a8]
100846838:     	cmp	w23, #0x300
10084683c:     	b.hs	0x100846fd8 <_js_json_stringify_full+0x1518>
100846840:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100846844:     	ldr	x8, [x8, #0x48]
100846848:     	cmn	x8, #0x1
10084684c:     	b.eq	0x100846fc8 <_js_json_stringify_full+0x1508>
100846850:     	mrs	x9, TPIDRRO_EL0
100846854:     	and	x9, x9, #0xfffffffffffffff8
100846858:     	ldr	x0, [x9, x8, lsl #3]
10084685c:     	cbz	x0, 0x100846fc8 <_js_json_stringify_full+0x1508>
100846860:     	add	x8, x0, x23, lsl #3
100846864:     	ldr	x0, [x8, #0x1e8]
100846868:     	cbz	x0, 0x100846fd8 <_js_json_stringify_full+0x1518>
10084686c:     	str	xzr, [x0]
100846870:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846874:     	add	x0, x0, #0xd30
100846878:     	ldr	x8, [x0]
10084687c:     	blr	x8
100846880:     	mov	x23, x0
100846884:     	ldrb	w8, [x0, #0x18]
100846888:     	cmp	w8, #0x1
10084688c:     	b.ne	0x100847548 <_js_json_stringify_full+0x1a88>
100846890:     	ldr	x8, [x0]
100846894:     	mov	x9, #-0x1               ; =-1
100846898:     	str	x9, [x0]
10084689c:     	cmn	x8, #0x2
1008468a0:     	b.eq	0x1008476d0 <_js_json_stringify_full+0x1c10>
1008468a4:     	cmn	x8, #0x1
1008468a8:     	b.eq	0x10084697c <_js_json_stringify_full+0xebc>
1008468ac:     	add	x9, sp, #0x48
1008468b0:     	ldur	q0, [x0, #0x8]
1008468b4:     	stur	q0, [x9, #0x8]
1008468b8:     	str	x8, [sp, #0x48]
1008468bc:     	tbz	w24, #0x0, 0x100846990 <_js_json_stringify_full+0xed0>
1008468c0:     	tbz	w27, #0x0, 0x100846a78 <_js_json_stringify_full+0xfb8>
1008468c4:     	bl	0x10028b418 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
1008468c8:     	str	x0, [sp, #0x60]
1008468cc:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008468d0:     	stp	x28, x8, [sp, #0x88]
1008468d4:     	mov	w8, #0x1                ; =1
1008468d8:     	str	x8, [sp, #0x80]
1008468dc:     	add	x0, sp, #0x80
1008468e0:     	bl	0x10028b520 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
1008468e4:     	mov	x22, x0
1008468e8:     	str	x0, [sp, #0x68]
1008468ec:     	mov	w0, #0x0                ; =0
1008468f0:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1008468f4:     	stp	xzr, xzr, [x0]
1008468f8:     	str	wzr, [x0, #0x10]
1008468fc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846900:     	bfxil	x8, x0, #0, #48
100846904:     	fmov	d0, x8
100846908:     	bl	0x10020b124 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
10084690c:     	mov	x19, x0
100846910:     	adrp	x24, 0x100f7c000 <_perry_global_worker_ts__1>
100846914:     	ldr	x8, [x24, #0x48]
100846918:     	cmn	x8, #0x1
10084691c:     	b.eq	0x100846adc <_js_json_stringify_full+0x101c>
100846920:     	mrs	x9, TPIDRRO_EL0
100846924:     	and	x9, x9, #0xfffffffffffffff8
100846928:     	ldr	x8, [x9, x8, lsl #3]
10084692c:     	cbz	x8, 0x100846adc <_js_json_stringify_full+0x101c>
100846930:     	ldr	x8, [x8, #0x19e8]
100846934:     	cbz	x8, 0x100846adc <_js_json_stringify_full+0x101c>
100846938:     	ldr	x9, [x8]
10084693c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846940:     	cmp	x9, x10
100846944:     	b.hs	0x10084761c <_js_json_stringify_full+0x1b5c>
100846948:     	add	x10, x9, #0x1
10084694c:     	str	x10, [x8]
100846950:     	ldr	x10, [x8, #0x18]
100846954:     	cmp	x19, x10
100846958:     	b.hs	0x100847628 <_js_json_stringify_full+0x1b68>
10084695c:     	ldr	x10, [x8, #0x10]
100846960:     	mov	w11, #0x18              ; =24
100846964:     	madd	x10, x19, x11, x10
100846968:     	ldr	x11, [x10]
10084696c:     	cbnz	x11, 0x100847688 <_js_json_stringify_full+0x1bc8>
100846970:     	ldr	x0, [x10, #0x8]
100846974:     	str	x9, [x8]
100846978:     	b	0x100846ae4 <_js_json_stringify_full+0x1024>
10084697c:     	mov	x8, #0x0                ; =0
100846980:     	mov	w9, #0x1                ; =1
100846984:     	stp	x9, xzr, [sp, #0x50]
100846988:     	str	x8, [sp, #0x48]
10084698c:     	tbnz	w24, #0x0, 0x1008468c0 <_js_json_stringify_full+0xe00>
100846990:     	cmp	x22, #0x0
100846994:     	cset	w6, ne
100846998:     	ldp	x0, x1, [sp, #0x38]
10084699c:     	ldp	x3, x4, [sp, #0x18]
1008469a0:     	add	x2, sp, #0x48
1008469a4:     	mov.16b	v0, v8
1008469a8:     	mov	x5, #0x0                ; =0
1008469ac:     	bl	0x100502e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
1008469b0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008469b4:     	add	x0, x0, #0xd90
1008469b8:     	ldr	x8, [x0]
1008469bc:     	blr	x8
1008469c0:     	ldrb	w8, [x0, #0x20]
1008469c4:     	cbnz	w8, 0x1008475ac <_js_json_stringify_full+0x1aec>
1008469c8:     	ldr	x8, [x0]
1008469cc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1008469d0:     	cmp	x8, x9
1008469d4:     	b.hs	0x1008475dc <_js_json_stringify_full+0x1b1c>
1008469d8:     	ldr	x9, [x0, #0x18]
1008469dc:     	cbz	x9, 0x1008469e8 <_js_json_stringify_full+0xf28>
1008469e0:     	cbnz	x8, 0x1008475e8 <_js_json_stringify_full+0x1b28>
1008469e4:     	str	xzr, [x0, #0x18]
1008469e8:     	ldp	x0, x1, [sp, #0x50]
1008469ec:     	cmp	x1, #0x5
1008469f0:     	b.hi	0x100846a58 <_js_json_stringify_full+0xf98>
1008469f4:     	cbz	x1, 0x100846c68 <_js_json_stringify_full+0x11a8>
1008469f8:     	ldrsb	w8, [x0]
1008469fc:     	tbnz	w8, #0x1f, 0x100846a58 <_js_json_stringify_full+0xf98>
100846a00:     	cmp	x1, #0x1
100846a04:     	b.eq	0x100846a40 <_js_json_stringify_full+0xf80>
100846a08:     	ldrsb	w8, [x0, #0x1]
100846a0c:     	tbnz	w8, #0x1f, 0x100846a58 <_js_json_stringify_full+0xf98>
100846a10:     	cmp	x1, #0x2
100846a14:     	b.eq	0x100846a40 <_js_json_stringify_full+0xf80>
100846a18:     	ldrsb	w8, [x0, #0x2]
100846a1c:     	tbnz	w8, #0x1f, 0x100846a58 <_js_json_stringify_full+0xf98>
100846a20:     	cmp	x1, #0x3
100846a24:     	b.eq	0x100846a40 <_js_json_stringify_full+0xf80>
100846a28:     	ldrsb	w8, [x0, #0x3]
100846a2c:     	tbnz	w8, #0x1f, 0x100846a58 <_js_json_stringify_full+0xf98>
100846a30:     	cmp	x1, #0x4
100846a34:     	b.eq	0x100846a40 <_js_json_stringify_full+0xf80>
100846a38:     	ldrsb	w8, [x0, #0x4]
100846a3c:     	tbnz	w8, #0x1f, 0x100846a58 <_js_json_stringify_full+0xf98>
100846a40:     	cmp	x1, #0x4
100846a44:     	b.hs	0x100846da8 <_js_json_stringify_full+0x12e8>
100846a48:     	mov	x10, #0x0               ; =0
100846a4c:     	mov	x9, #0x0                ; =0
100846a50:     	mov	x8, x0
100846a54:     	b	0x100846e38 <_js_json_stringify_full+0x1378>
100846a58:     	bl	0x100329e88 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
100846a5c:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100846a60:     	bfxil	x20, x0, #0, #48
100846a64:     	ldp	x22, x0, [sp, #0x48]
100846a68:     	ldrb	w8, [x23, #0x18]
100846a6c:     	cmp	w8, #0x1
100846a70:     	b.eq	0x100846e74 <_js_json_stringify_full+0x13b4>
100846a74:     	b	0x100847578 <_js_json_stringify_full+0x1ab8>
100846a78:     	mov	w0, #0x0                ; =0
100846a7c:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846a80:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846a84:     	bfxil	x8, x0, #0, #48
100846a88:     	fmov	d1, x8
100846a8c:     	stp	xzr, xzr, [x0]
100846a90:     	str	wzr, [x0, #0x10]
100846a94:     	mov.16b	v0, v8
100846a98:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846a9c:     	mov.16b	v8, v0
100846aa0:     	fmov	x24, d8
100846aa4:     	cmp	x24, x20
100846aa8:     	b.eq	0x100846cf0 <_js_json_stringify_full+0x1230>
100846aac:     	mov	w8, #0x7ffd             ; =32765
100846ab0:     	cmp	x8, x24, lsr #48
100846ab4:     	b.ne	0x100846cc0 <_js_json_stringify_full+0x1200>
100846ab8:     	and	x8, x24, #0xffffffffffff
100846abc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846ac0:     	b.lo	0x100846ce4 <_js_json_stringify_full+0x1224>
100846ac4:     	ldr	w8, [x8, #0xc]
100846ac8:     	mov	w9, #0x4f53             ; =20307
100846acc:     	movk	w9, #0x434c, lsl #16
100846ad0:     	cmp	w8, w9
100846ad4:     	b.ne	0x100846ce4 <_js_json_stringify_full+0x1224>
100846ad8:     	b	0x100846cf0 <_js_json_stringify_full+0x1230>
100846adc:     	mov	x0, x19
100846ae0:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846ae4:     	fmov	d1, x0
100846ae8:     	mov.16b	v0, v8
100846aec:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846af0:     	mov.16b	v8, v0
100846af4:     	ldr	x8, [x24, #0x48]
100846af8:     	cmn	x8, #0x1
100846afc:     	b.eq	0x100846b60 <_js_json_stringify_full+0x10a0>
100846b00:     	mrs	x9, TPIDRRO_EL0
100846b04:     	and	x9, x9, #0xfffffffffffffff8
100846b08:     	ldr	x8, [x9, x8, lsl #3]
100846b0c:     	cbz	x8, 0x100846b60 <_js_json_stringify_full+0x10a0>
100846b10:     	ldr	x8, [x8, #0x19e8]
100846b14:     	cbz	x8, 0x100846b60 <_js_json_stringify_full+0x10a0>
100846b18:     	ldr	x9, [x8]
100846b1c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846b20:     	cmp	x9, x10
100846b24:     	b.hs	0x10084761c <_js_json_stringify_full+0x1b5c>
100846b28:     	add	x10, x9, #0x1
100846b2c:     	str	x10, [x8]
100846b30:     	ldr	x10, [x8, #0x18]
100846b34:     	cmp	x22, x10
100846b38:     	b.hs	0x100847628 <_js_json_stringify_full+0x1b68>
100846b3c:     	ldr	x10, [x8, #0x10]
100846b40:     	mov	w11, #0x18              ; =24
100846b44:     	madd	x10, x22, x11, x10
100846b48:     	ldr	x11, [x10]
100846b4c:     	cmp	x11, #0x1
100846b50:     	b.ne	0x1008476e8 <_js_json_stringify_full+0x1c28>
100846b54:     	ldr	x22, [x10, #0x8]
100846b58:     	str	x9, [x8]
100846b5c:     	b	0x100846b6c <_js_json_stringify_full+0x10ac>
100846b60:     	mov	x0, x22
100846b64:     	bl	0x10013c298 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100846b68:     	mov	x22, x0
100846b6c:     	ldr	x8, [x24, #0x48]
100846b70:     	cmn	x8, #0x1
100846b74:     	b.eq	0x100846bd4 <_js_json_stringify_full+0x1114>
100846b78:     	mrs	x9, TPIDRRO_EL0
100846b7c:     	and	x9, x9, #0xfffffffffffffff8
100846b80:     	ldr	x8, [x9, x8, lsl #3]
100846b84:     	cbz	x8, 0x100846bd4 <_js_json_stringify_full+0x1114>
100846b88:     	ldr	x8, [x8, #0x19e8]
100846b8c:     	cbz	x8, 0x100846bd4 <_js_json_stringify_full+0x1114>
100846b90:     	ldr	x9, [x8]
100846b94:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846b98:     	cmp	x9, x10
100846b9c:     	b.hs	0x10084761c <_js_json_stringify_full+0x1b5c>
100846ba0:     	add	x10, x9, #0x1
100846ba4:     	str	x10, [x8]
100846ba8:     	ldr	x10, [x8, #0x18]
100846bac:     	cmp	x19, x10
100846bb0:     	b.hs	0x100847628 <_js_json_stringify_full+0x1b68>
100846bb4:     	ldr	x10, [x8, #0x10]
100846bb8:     	mov	w11, #0x18              ; =24
100846bbc:     	madd	x10, x19, x11, x10
100846bc0:     	ldr	x11, [x10]
100846bc4:     	cbnz	x11, 0x100847688 <_js_json_stringify_full+0x1bc8>
100846bc8:     	ldr	x0, [x10, #0x8]
100846bcc:     	str	x9, [x8]
100846bd0:     	b	0x100846bdc <_js_json_stringify_full+0x111c>
100846bd4:     	mov	x0, x19
100846bd8:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846bdc:     	fmov	d9, x0
100846be0:     	mov.16b	v0, v8
100846be4:     	bl	0x1004ff434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100846be8:     	mov.16b	v2, v0
100846bec:     	mov	x0, x22
100846bf0:     	mov.16b	v0, v9
100846bf4:     	mov.16b	v1, v8
100846bf8:     	bl	0x1004ff714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
100846bfc:     	str	d0, [sp, #0x70]
100846c00:     	fmov	x19, d0
100846c04:     	cmp	x19, x20
100846c08:     	b.ne	0x100846c70 <_js_json_stringify_full+0x11b0>
100846c0c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846c10:     	add	x0, x0, #0xd90
100846c14:     	ldr	x8, [x0]
100846c18:     	blr	x8
100846c1c:     	ldrb	w8, [x0, #0x20]
100846c20:     	cbnz	w8, 0x1008476c8 <_js_json_stringify_full+0x1c08>
100846c24:     	ldr	x8, [x0]
100846c28:     	cbnz	x8, 0x100847718 <_js_json_stringify_full+0x1c58>
100846c2c:     	str	xzr, [x0, #0x18]
100846c30:     	ldp	x22, x19, [sp, #0x48]
100846c34:     	ldrb	w8, [x23, #0x18]
100846c38:     	cmp	w8, #0x1
100846c3c:     	b.ne	0x100847660 <_js_json_stringify_full+0x1ba0>
100846c40:     	ldp	x8, x0, [x23]
100846c44:     	stp	x22, x19, [x23]
100846c48:     	str	xzr, [x23, #0x10]
100846c4c:     	sub	x8, x8, #0x1
100846c50:     	cmn	x8, #0x2
100846c54:     	b.hs	0x100846c5c <_js_json_stringify_full+0x119c>
100846c58:     	bl	0x100b5ef40 <_mi_free>
100846c5c:     	cbz	w26, 0x100846efc <_js_json_stringify_full+0x143c>
100846c60:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846c64:     	b	0x100846f00 <_js_json_stringify_full+0x1440>
100846c68:     	mov	x10, #0x0               ; =0
100846c6c:     	b	0x100846e58 <_js_json_stringify_full+0x1398>
100846c70:     	add	x0, sp, #0x48
100846c74:     	bl	0x100500470 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
100846c78:     	tbnz	w0, #0x0, 0x100846cb4 <_js_json_stringify_full+0x11f4>
100846c7c:     	mov	x0, x19
100846c80:     	bl	0x100327dec <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
100846c84:     	cmp	x0, #0x1
100846c88:     	b.ne	0x1008476dc <_js_json_stringify_full+0x1c1c>
100846c8c:     	add	x8, sp, #0x78
100846c90:     	add	x9, sp, #0x70
100846c94:     	stp	x1, x8, [sp, #0x78]
100846c98:     	str	x9, [sp, #0x88]
100846c9c:     	add	x8, sp, #0x48
100846ca0:     	add	x9, sp, #0x10
100846ca4:     	stp	x8, x9, [sp, #0x90]
100846ca8:     	add	x0, sp, #0x68
100846cac:     	add	x1, sp, #0x80
100846cb0:     	bl	0x100143d90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
100846cb4:     	add	x0, sp, #0x60
100846cb8:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100846cbc:     	b	0x1008469b0 <_js_json_stringify_full+0xef0>
100846cc0:     	lsr	x8, x24, #52
100846cc4:     	cbnz	x8, 0x100846ce4 <_js_json_stringify_full+0x1224>
100846cc8:     	cbz	x24, 0x100846ce4 <_js_json_stringify_full+0x1224>
100846ccc:     	and	x8, x24, #0x7
100846cd0:     	cbnz	x8, 0x100846ce4 <_js_json_stringify_full+0x1224>
100846cd4:     	mov	x0, x24
100846cd8:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846cdc:     	mov	x8, x24
100846ce0:     	tbnz	w0, #0x0, 0x100846abc <_js_json_stringify_full+0xffc>
100846ce4:     	mov	x0, x24
100846ce8:     	bl	0x100509494 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
100846cec:     	tbz	w0, #0x0, 0x100846d7c <_js_json_stringify_full+0x12bc>
100846cf0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846cf4:     	add	x0, x0, #0xd90
100846cf8:     	ldr	x8, [x0]
100846cfc:     	blr	x8
100846d00:     	ldrb	w8, [x0, #0x20]
100846d04:     	cbnz	w8, 0x10084762c <_js_json_stringify_full+0x1b6c>
100846d08:     	ldr	x8, [x0]
100846d0c:     	cbnz	x8, 0x100847654 <_js_json_stringify_full+0x1b94>
100846d10:     	str	xzr, [x0, #0x18]
100846d14:     	ldp	x22, x19, [sp, #0x48]
100846d18:     	ldrb	w8, [x23, #0x18]
100846d1c:     	cmp	w8, #0x1
100846d20:     	b.ne	0x100847608 <_js_json_stringify_full+0x1b48>
100846d24:     	ldp	x8, x0, [x23]
100846d28:     	stp	x22, x19, [x23]
100846d2c:     	str	xzr, [x23, #0x10]
100846d30:     	sub	x8, x8, #0x1
100846d34:     	cmn	x8, #0x2
100846d38:     	b.hs	0x100846d40 <_js_json_stringify_full+0x1280>
100846d3c:     	bl	0x100b5ef40 <_mi_free>
100846d40:     	cbz	w26, 0x100846d60 <_js_json_stringify_full+0x12a0>
100846d44:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846d48:     	ldr	w8, [x21]
100846d4c:     	sub	w8, w8, #0x1
100846d50:     	str	w8, [x21]
100846d54:     	cmn	x25, #0x1
100846d58:     	b.ne	0x100846f1c <_js_json_stringify_full+0x145c>
100846d5c:     	b	0x100846f58 <_js_json_stringify_full+0x1498>
100846d60:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846d64:     	ldr	w8, [x21]
100846d68:     	sub	w8, w8, #0x1
100846d6c:     	str	w8, [x21]
100846d70:     	cmn	x25, #0x1
100846d74:     	b.ne	0x100846f1c <_js_json_stringify_full+0x145c>
100846d78:     	b	0x100846f58 <_js_json_stringify_full+0x1498>
100846d7c:     	cmp	x19, x24
100846d80:     	b.eq	0x100846d8c <_js_json_stringify_full+0x12cc>
100846d84:     	mov.16b	v0, v8
100846d88:     	bl	0x10050e86c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
100846d8c:     	cbz	x22, 0x100846fe8 <_js_json_stringify_full+0x1528>
100846d90:     	ldp	x1, x2, [sp, #0x18]
100846d94:     	add	x0, sp, #0x48
100846d98:     	mov.16b	v0, v8
100846d9c:     	mov	x3, #0x0                ; =0
100846da0:     	bl	0x100500f60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
100846da4:     	b	0x100846ff8 <_js_json_stringify_full+0x1538>
100846da8:     	and	x9, x1, #0x4
100846dac:     	add	x8, x0, x9
100846db0:     	adrp	x10, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4eb0>
100846db4:     	ldr	q0, [x10, #0x9c0]
100846db8:     	adrp	x10, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x336ba>
100846dbc:     	ldr	q2, [x10, #0x8c0]
100846dc0:     	movi.2d	v1, #0000000000000000
100846dc4:     	movi.2d	v3, #0x000000000000ff
100846dc8:     	mov	w10, #0x4               ; =4
100846dcc:     	dup.2d	v4, x10
100846dd0:     	mov	x10, x0
100846dd4:     	and	x11, x1, #0x4
100846dd8:     	movi.2d	v5, #0000000000000000
100846ddc:     	ldr	s6, [x10], #0x4
100846de0:     	ushll.8h	v6, v6, #0x0
100846de4:     	ushll.4s	v6, v6, #0x0
100846de8:     	ushll2.2d	v7, v6, #0x0
100846dec:     	and.16b	v7, v7, v3
100846df0:     	ushll.2d	v6, v6, #0x0
100846df4:     	and.16b	v6, v6, v3
100846df8:     	shl.2d	v16, v0, #0x3
100846dfc:     	shl.2d	v17, v2, #0x3
100846e00:     	ushl.2d	v6, v6, v17
100846e04:     	ushl.2d	v7, v7, v16
100846e08:     	orr.16b	v1, v7, v1
100846e0c:     	orr.16b	v5, v6, v5
100846e10:     	add.2d	v0, v0, v4
100846e14:     	add.2d	v2, v2, v4
100846e18:     	subs	x11, x11, #0x4
100846e1c:     	b.ne	0x100846ddc <_js_json_stringify_full+0x131c>
100846e20:     	orr.16b	v0, v5, v1
100846e24:     	mov	d1, v0[1]
100846e28:     	orr.8b	v0, v0, v1
100846e2c:     	fmov	x10, d0
100846e30:     	cmp	x1, x9
100846e34:     	b.eq	0x100846e58 <_js_json_stringify_full+0x1398>
100846e38:     	add	x11, x0, x1
100846e3c:     	lsl	x9, x9, #3
100846e40:     	ldrb	w12, [x8], #0x1
100846e44:     	lsl	x12, x12, x9
100846e48:     	orr	x10, x12, x10
100846e4c:     	add	x9, x9, #0x8
100846e50:     	cmp	x8, x11
100846e54:     	b.ne	0x100846e40 <_js_json_stringify_full+0x1380>
100846e58:     	orr	x8, x10, x1, lsl #40
100846e5c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100846e60:     	orr	x20, x8, x9
100846e64:     	ldr	x22, [sp, #0x48]
100846e68:     	ldrb	w8, [x23, #0x18]
100846e6c:     	cmp	w8, #0x1
100846e70:     	b.ne	0x100847578 <_js_json_stringify_full+0x1ab8>
100846e74:     	ldp	x9, x8, [x23]
100846e78:     	stp	x22, x0, [x23]
100846e7c:     	str	xzr, [x23, #0x10]
100846e80:     	sub	x9, x9, #0x1
100846e84:     	cmn	x9, #0x2
100846e88:     	b.hs	0x100846e94 <_js_json_stringify_full+0x13d4>
100846e8c:     	mov	x0, x8
100846e90:     	bl	0x100b5ef40 <_mi_free>
100846e94:     	cbz	w26, 0x100846eb4 <_js_json_stringify_full+0x13f4>
100846e98:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846e9c:     	ldr	w8, [x21]
100846ea0:     	sub	w8, w8, #0x1
100846ea4:     	str	w8, [x21]
100846ea8:     	cmn	x25, #0x1
100846eac:     	b.ne	0x100846ecc <_js_json_stringify_full+0x140c>
100846eb0:     	b	0x100846f58 <_js_json_stringify_full+0x1498>
100846eb4:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846eb8:     	ldr	w8, [x21]
100846ebc:     	sub	w8, w8, #0x1
100846ec0:     	str	w8, [x21]
100846ec4:     	cmn	x25, #0x1
100846ec8:     	b.eq	0x100846f58 <_js_json_stringify_full+0x1498>
100846ecc:     	ldp	x19, x21, [sp, #0x38]
100846ed0:     	cbz	x21, 0x100846f4c <_js_json_stringify_full+0x148c>
100846ed4:     	add	x22, x19, #0x8
100846ed8:     	b	0x100846ee8 <_js_json_stringify_full+0x1428>
100846edc:     	add	x22, x22, #0x18
100846ee0:     	subs	x21, x21, #0x1
100846ee4:     	b.eq	0x100846f4c <_js_json_stringify_full+0x148c>
100846ee8:     	ldur	x8, [x22, #-0x8]
100846eec:     	cbz	x8, 0x100846edc <_js_json_stringify_full+0x141c>
100846ef0:     	ldr	x0, [x22]
100846ef4:     	bl	0x100b5ef40 <_mi_free>
100846ef8:     	b	0x100846edc <_js_json_stringify_full+0x141c>
100846efc:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846f00:     	ldr	w8, [x21]
100846f04:     	sub	w8, w8, #0x1
100846f08:     	str	w8, [x21]
100846f0c:     	add	x0, sp, #0x60
100846f10:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100846f14:     	cmn	x25, #0x1
100846f18:     	b.eq	0x100846f58 <_js_json_stringify_full+0x1498>
100846f1c:     	ldp	x19, x21, [sp, #0x38]
100846f20:     	cbz	x21, 0x100846f4c <_js_json_stringify_full+0x148c>
100846f24:     	add	x22, x19, #0x8
100846f28:     	b	0x100846f38 <_js_json_stringify_full+0x1478>
100846f2c:     	add	x22, x22, #0x18
100846f30:     	subs	x21, x21, #0x1
100846f34:     	b.eq	0x100846f4c <_js_json_stringify_full+0x148c>
100846f38:     	ldur	x8, [x22, #-0x8]
100846f3c:     	cbz	x8, 0x100846f2c <_js_json_stringify_full+0x146c>
100846f40:     	ldr	x0, [x22]
100846f44:     	bl	0x100b5ef40 <_mi_free>
100846f48:     	b	0x100846f2c <_js_json_stringify_full+0x146c>
100846f4c:     	cbz	x25, 0x100846f58 <_js_json_stringify_full+0x1498>
100846f50:     	mov	x0, x19
100846f54:     	bl	0x100b5ef40 <_mi_free>
100846f58:     	ldr	x8, [sp, #0x10]
100846f5c:     	cbz	x8, 0x100846f68 <_js_json_stringify_full+0x14a8>
100846f60:     	ldr	x0, [sp, #0x18]
100846f64:     	bl	0x100b5ef40 <_mi_free>
100846f68:     	mov	x0, x20
100846f6c:     	ldp	x29, x30, [sp, #0x110]
100846f70:     	ldp	x20, x19, [sp, #0x100]
100846f74:     	ldp	x22, x21, [sp, #0xf0]
100846f78:     	ldp	x24, x23, [sp, #0xe0]
100846f7c:     	ldp	x26, x25, [sp, #0xd0]
100846f80:     	ldp	x28, x27, [sp, #0xc0]
100846f84:     	ldp	d9, d8, [sp, #0xb0]
100846f88:     	add	sp, sp, #0x120
100846f8c:     	ret
100846f90:     	str	x22, [sp, #0x8]
100846f94:     	mov	x22, x28
100846f98:     	mov	x28, x0
100846f9c:     	add	x0, x0, #0x8
100846fa0:     	bl	0x100b3bcd0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100846fa4:     	mov	x0, x28
100846fa8:     	mov	x28, x22
100846fac:     	ldr	x22, [sp, #0x8]
100846fb0:     	b	0x1008467d8 <_js_json_stringify_full+0xd18>
100846fb4:     	b.ne	0x10084651c <_js_json_stringify_full+0xa5c>
100846fb8:     	tbz	x25, #0x3f, 0x100847010 <_js_json_stringify_full+0x1550>
100846fbc:     	mov	x0, #0x0                ; =0
100846fc0:     	mov	x1, x25
100846fc4:     	bl	0x100b12300 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100846fc8:     	bl	0x100b3f37c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100846fcc:     	add	x8, x0, x23, lsl #3
100846fd0:     	ldr	x0, [x8, #0x1e8]
100846fd4:     	cbnz	x0, 0x10084686c <_js_json_stringify_full+0xdac>
100846fd8:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846fdc:     	add	x0, x0, #0x138
100846fe0:     	bl	0x100b3cb9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100846fe4:     	b	0x10084686c <_js_json_stringify_full+0xdac>
100846fe8:     	add	x1, sp, #0x48
100846fec:     	mov.16b	v0, v8
100846ff0:     	mov	w0, #0x0                ; =0
100846ff4:     	bl	0x10050956c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100846ff8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846ffc:     	add	x0, x0, #0xdc0
100847000:     	ldr	x8, [x0]
100847004:     	blr	x8
100847008:     	strb	wzr, [x0]
10084700c:     	b	0x1008469b0 <_js_json_stringify_full+0xef0>
100847010:     	mov	x0, x25
100847014:     	mov	w1, #0x1                ; =1
100847018:     	bl	0x100b5f1c8 <_mi_malloc_aligned>
10084701c:     	mov	x26, x0
100847020:     	mov	w0, #0x1                ; =1
100847024:     	cbz	x26, 0x100846fc0 <_js_json_stringify_full+0x1500>
100847028:     	mov	x0, x26
10084702c:     	mov	x1, x23
100847030:     	mov	x2, x25
100847034:     	bl	0x100b61dec <_writev+0x100b61dec>
100847038:     	mov	x22, x25
10084703c:     	b	0x100846540 <_js_json_stringify_full+0xa80>
100847040:     	cmp	w11, #0x8
100847044:     	b.eq	0x100847110 <_js_json_stringify_full+0x1650>
100847048:     	cmp	w11, #0x9
10084704c:     	b.eq	0x100847120 <_js_json_stringify_full+0x1660>
100847050:     	cmp	w11, #0xa
100847054:     	b.ne	0x10084709c <_js_json_stringify_full+0x15dc>
100847058:     	mov	w10, #0x6e              ; =110
10084705c:     	b	0x100847124 <_js_json_stringify_full+0x1664>
100847060:     	mov	x22, x0
100847064:     	and	x0, x19, #0xffffffffffff
100847068:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084706c:     	cbz	x0, 0x100847148 <_js_json_stringify_full+0x1688>
100847070:     	ldr	w20, [x0]
100847074:     	cmp	w20, #0x4
100847078:     	b.hi	0x100846098 <_js_json_stringify_full+0x5d8>
10084707c:     	ldr	w8, [x0, #0x4]
100847080:     	cmp	w20, w8
100847084:     	b.hi	0x100846098 <_js_json_stringify_full+0x5d8>
100847088:     	b	0x10084714c <_js_json_stringify_full+0x168c>
10084708c:     	cmp	w11, #0x22
100847090:     	b.eq	0x100847124 <_js_json_stringify_full+0x1664>
100847094:     	cmp	w11, #0x5c
100847098:     	b.eq	0x100847124 <_js_json_stringify_full+0x1664>
10084709c:     	cmp	x12, #0x3
1008470a0:     	mov	w11, #0x20              ; =32
1008470a4:     	ccmp	w10, w11, #0x8, ls
1008470a8:     	b.lt	0x100845fd4 <_js_json_stringify_full+0x514>
1008470ac:     	add	x8, sp, #0x80
1008470b0:     	strb	w10, [x8, x12]
1008470b4:     	add	x12, x12, #0x1
1008470b8:     	b	0x100845cc4 <_js_json_stringify_full+0x204>
1008470bc:     	mov	x1, x0
1008470c0:     	and	x0, x19, #0xffffffffffff
1008470c4:     	mov	x22, x1
1008470c8:     	bl	0x1004f8e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
1008470cc:     	cmp	x0, #0x1
1008470d0:     	b.ne	0x1008471f4 <_js_json_stringify_full+0x1734>
1008470d4:     	mov	x20, x1
1008470d8:     	b	0x100846f68 <_js_json_stringify_full+0x14a8>
1008470dc:     	ldrb	w9, [x8, #0x118]
1008470e0:     	cbz	w9, 0x10084731c <_js_json_stringify_full+0x185c>
1008470e4:     	ldr	x9, [x8, #0x110]
1008470e8:     	cmp	x9, x1
1008470ec:     	b.ne	0x10084731c <_js_json_stringify_full+0x185c>
1008470f0:     	ldr	x9, [x8, #0xf0]
1008470f4:     	cmp	x9, x23
1008470f8:     	b.hi	0x10084731c <_js_json_stringify_full+0x185c>
1008470fc:     	ldr	x9, [x8, #0xf8]
100847100:     	cmp	x9, x23
100847104:     	b.ls	0x10084731c <_js_json_stringify_full+0x185c>
100847108:     	add	x9, x8, #0xf0
10084710c:     	b	0x100847528 <_js_json_stringify_full+0x1a68>
100847110:     	mov	w10, #0x62              ; =98
100847114:     	b	0x100847124 <_js_json_stringify_full+0x1664>
100847118:     	mov	w10, #0x66              ; =102
10084711c:     	b	0x100847124 <_js_json_stringify_full+0x1664>
100847120:     	mov	w10, #0x74              ; =116
100847124:     	cmp	x12, #0x2
100847128:     	b.hi	0x100845fd4 <_js_json_stringify_full+0x514>
10084712c:     	add	x8, sp, #0x80
100847130:     	add	x8, x8, x12
100847134:     	add	x12, x12, #0x2
100847138:     	mov	w11, #0x5c              ; =92
10084713c:     	strb	w11, [x8]
100847140:     	strb	w10, [x8, #0x1]
100847144:     	b	0x100845cc4 <_js_json_stringify_full+0x204>
100847148:     	mov	x20, #0x0               ; =0
10084714c:     	ldr	w8, [x22, #0x4]
100847150:     	lsl	x9, x20, #3
100847154:     	add	x9, x9, #0x18
100847158:     	cmp	x9, x8
10084715c:     	b.hi	0x100846098 <_js_json_stringify_full+0x5d8>
100847160:     	ldr	w8, [x25, #0x4]
100847164:     	mov	w9, #-0x40000000        ; =-1073741824
100847168:     	cmp	w8, w9
10084716c:     	csel	w8, w8, wzr, lt
100847170:     	mov	x22, x0
100847174:     	mov	x0, x8
100847178:     	bl	0x1005e56e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084717c:     	mov	w9, #0x2                ; =2
100847180:     	cmp	w1, #0x2
100847184:     	csel	w10, w1, w9, hi
100847188:     	tst	w0, #0x1
10084718c:     	csel	x8, x10, x9, ne
100847190:     	cmp	x20, x8
100847194:     	b.hi	0x100846098 <_js_json_stringify_full+0x5d8>
100847198:     	cbz	x20, 0x100847558 <_js_json_stringify_full+0x1a98>
10084719c:     	mov	x0, x22
1008471a0:     	mov	x1, x20
1008471a4:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008471a8:     	tbz	w0, #0x0, 0x100846098 <_js_json_stringify_full+0x5d8>
1008471ac:     	cmp	x20, #0x1
1008471b0:     	b.eq	0x1008475f4 <_js_json_stringify_full+0x1b34>
1008471b4:     	cmp	x20, #0x2
1008471b8:     	b.ne	0x1008476b0 <_js_json_stringify_full+0x1bf0>
1008471bc:     	mov	x22, #0x0               ; =0
1008471c0:     	add	x25, x25, #0x10
1008471c4:     	mov	w8, #0x1                ; =1
1008471c8:     	mov	x26, x8
1008471cc:     	ldr	x1, [x25, x22, lsl #3]
1008471d0:     	add	x0, sp, #0x80
1008471d4:     	bl	0x1004efe14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
1008471d8:     	ldr	w8, [sp, #0x80]
1008471dc:     	cmn	w8, #0x1
1008471e0:     	b.ne	0x100847698 <_js_json_stringify_full+0x1bd8>
1008471e4:     	mov	w8, #0x0                ; =0
1008471e8:     	mov	w22, #0x1               ; =1
1008471ec:     	tbnz	w26, #0x0, 0x1008471c8 <_js_json_stringify_full+0x1708>
1008471f0:     	b	0x1008476b0 <_js_json_stringify_full+0x1bf0>
1008471f4:     	and	x0, x19, #0xffffffffffff
1008471f8:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1008471fc:     	cbz	x0, 0x100847288 <_js_json_stringify_full+0x17c8>
100847200:     	ldr	w20, [x0]
100847204:     	cbz	w20, 0x100847288 <_js_json_stringify_full+0x17c8>
100847208:     	cmp	w20, #0x8
10084720c:     	b.hi	0x100846064 <_js_json_stringify_full+0x5a4>
100847210:     	ldr	w8, [x0, #0x4]
100847214:     	cmp	w20, w8
100847218:     	b.hi	0x100846064 <_js_json_stringify_full+0x5a4>
10084721c:     	ldr	w8, [x22, #0x4]
100847220:     	lsl	x9, x20, #3
100847224:     	add	x9, x9, #0x18
100847228:     	cmp	x9, x8
10084722c:     	b.hi	0x100846064 <_js_json_stringify_full+0x5a4>
100847230:     	ldr	w8, [x25, #0x4]
100847234:     	mov	w9, #-0x40000000        ; =-1073741824
100847238:     	cmp	w8, w9
10084723c:     	csel	w8, w8, wzr, lt
100847240:     	mov	x22, x0
100847244:     	mov	x0, x8
100847248:     	bl	0x1005e56e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084724c:     	mov	w9, #0x2                ; =2
100847250:     	cmp	w1, #0x2
100847254:     	csel	w10, w1, w9, hi
100847258:     	tst	w0, #0x1
10084725c:     	csel	w8, w10, w9, ne
100847260:     	cmp	w20, w8
100847264:     	b.hi	0x100846064 <_js_json_stringify_full+0x5a4>
100847268:     	mov	x0, x22
10084726c:     	mov	x1, x20
100847270:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100847274:     	cbz	w0, 0x100846064 <_js_json_stringify_full+0x5a4>
100847278:     	and	x0, x19, #0xffffffffffff
10084727c:     	mov	x1, x20
100847280:     	bl	0x1004f7f40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
100847284:     	b	0x100847290 <_js_json_stringify_full+0x17d0>
100847288:     	and	x0, x19, #0xffffffffffff
10084728c:     	bl	0x1004f8cc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
100847290:     	mov	x20, x1
100847294:     	tbz	w0, #0x0, 0x100846064 <_js_json_stringify_full+0x5a4>
100847298:     	b	0x100846f68 <_js_json_stringify_full+0x14a8>
10084729c:     	add	x9, x8, #0x60
1008472a0:     	b	0x100847528 <_js_json_stringify_full+0x1a68>
1008472a4:     	bl	0x100b3f37c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008472a8:     	lsr	x1, x23, #20
1008472ac:     	ldr	x8, [x0, #0x10]
1008472b0:     	ldrb	w9, [x8]
1008472b4:     	cmp	w9, #0x2
1008472b8:     	b.eq	0x100846648 <_js_json_stringify_full+0xb88>
1008472bc:     	ldr	x9, [x8, #0x8]
1008472c0:     	ldr	x10, [x8, #0x28]
1008472c4:     	sub	x9, x1, x9
1008472c8:     	cmp	x9, x10
1008472cc:     	b.hs	0x100847310 <_js_json_stringify_full+0x1850>
1008472d0:     	ldr	x10, [x8, #0x20]
1008472d4:     	mov	w11, #0x28              ; =40
1008472d8:     	madd	x9, x9, x11, x10
1008472dc:     	ldr	x10, [x9]
1008472e0:     	ldr	x11, [x8, #0x10]
1008472e4:     	cmp	x10, x11
1008472e8:     	b.ne	0x10084731c <_js_json_stringify_full+0x185c>
1008472ec:     	ldp	x10, x11, [x9, #0x8]
1008472f0:     	cmp	x10, x23
1008472f4:     	ccmp	x11, x23, #0x0, ls
1008472f8:     	b.ls	0x10084731c <_js_json_stringify_full+0x185c>
1008472fc:     	ldr	x10, [x8, #0x30]
100847300:     	add	x10, x10, #0x1
100847304:     	str	x10, [x8, #0x30]
100847308:     	add	x8, x9, #0x21
10084730c:     	b	0x100847538 <_js_json_stringify_full+0x1a78>
100847310:     	ldr	x9, [x8, #0x58]
100847314:     	add	x9, x9, #0x1
100847318:     	str	x9, [x8, #0x58]
10084731c:     	ldr	x9, [x8, #0x38]
100847320:     	add	x9, x9, #0x1
100847324:     	str	x9, [x8, #0x38]
100847328:     	mov	x0, x23
10084732c:     	bl	0x10051e348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100847330:     	and	w8, w0, #0xff
100847334:     	cbz	w8, 0x100847354 <_js_json_stringify_full+0x1894>
100847338:     	ldurb	w8, [x23, #-0x8]
10084733c:     	ldurb	w9, [x23, #-0x7]
100847340:     	mov	w10, #0x82              ; =130
100847344:     	and	w9, w9, w10
100847348:     	cmp	w9, #0x2
10084734c:     	ccmp	w8, #0x1, #0x0, eq
100847350:     	b.eq	0x1008473e8 <_js_json_stringify_full+0x1928>
100847354:     	mov	x0, x23
100847358:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084735c:     	mov	x24, x0
100847360:     	cbz	x0, 0x10084738c <_js_json_stringify_full+0x18cc>
100847364:     	ldrb	w8, [x24]
100847368:     	cmp	w8, #0x1
10084736c:     	b.ne	0x1008473ac <_js_json_stringify_full+0x18ec>
100847370:     	ldrsb	w8, [x24, #0x1]
100847374:     	tbnz	w8, #0x1f, 0x100847410 <_js_json_stringify_full+0x1950>
100847378:     	mov	x0, x24
10084737c:     	ldp	w9, w8, [x23]
100847380:     	cmp	w9, w8
100847384:     	b.hi	0x100847494 <_js_json_stringify_full+0x19d4>
100847388:     	b	0x1008474ac <_js_json_stringify_full+0x19ec>
10084738c:     	mov	x0, x23
100847390:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100847394:     	tbnz	w0, #0x0, 0x1008473a4 <_js_json_stringify_full+0x18e4>
100847398:     	mov	x0, x23
10084739c:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
1008473a0:     	tbz	w0, #0x0, 0x1008466e8 <_js_json_stringify_full+0xc28>
1008473a4:     	mov	x0, #0x0                ; =0
1008473a8:     	b	0x100847484 <_js_json_stringify_full+0x19c4>
1008473ac:     	mov	x0, x24
1008473b0:     	cmp	w8, #0x1
1008473b4:     	b.eq	0x100847484 <_js_json_stringify_full+0x19c4>
1008473b8:     	cmp	w8, #0x9
1008473bc:     	b.ne	0x1008466e8 <_js_json_stringify_full+0xc28>
1008473c0:     	ldr	w8, [x23, #0x4]
1008473c4:     	mov	w9, #0x5841             ; =22593
1008473c8:     	movk	w9, #0x4c5a, lsl #16
1008473cc:     	cmp	w8, w9
1008473d0:     	b.ne	0x1008466e8 <_js_json_stringify_full+0xc28>
1008473d4:     	mov	x0, x23
1008473d8:     	bl	0x100375e50 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1008473dc:     	mov	x23, x0
1008473e0:     	cbnz	x0, 0x1008474d4 <_js_json_stringify_full+0x1a14>
1008473e4:     	b	0x1008466e8 <_js_json_stringify_full+0xc28>
1008473e8:     	ldr	w8, [x23]
1008473ec:     	mov	w9, #0xe100             ; =57600
1008473f0:     	movk	w9, #0x5f5, lsl #16
1008473f4:     	orr	w9, w9, #0x1
1008473f8:     	cmp	w8, w9
1008473fc:     	b.hs	0x100847354 <_js_json_stringify_full+0x1894>
100847400:     	ldr	w9, [x23, #0x4]
100847404:     	cmp	w8, w9
100847408:     	b.ls	0x1008474d4 <_js_json_stringify_full+0x1a14>
10084740c:     	b	0x100847354 <_js_json_stringify_full+0x1894>
100847410:     	ldr	x23, [x24, #0x8]
100847414:     	mov	x0, x23
100847418:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084741c:     	cbz	x0, 0x1008466e8 <_js_json_stringify_full+0xc28>
100847420:     	ldrb	w8, [x0]
100847424:     	cmp	w8, #0x1
100847428:     	b.ne	0x1008466e8 <_js_json_stringify_full+0xc28>
10084742c:     	ldrsb	w8, [x0, #0x1]
100847430:     	tbz	w8, #0x1f, 0x10084737c <_js_json_stringify_full+0x18bc>
100847434:     	mov	w26, #0x1               ; =1
100847438:     	ldr	x23, [x0, #0x8]
10084743c:     	mov	x0, x23
100847440:     	bl	0x10057a9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847444:     	cbz	x0, 0x1008466e8 <_js_json_stringify_full+0xc28>
100847448:     	ldrb	w8, [x0]
10084744c:     	cmp	w8, #0x1
100847450:     	b.ne	0x1008466e8 <_js_json_stringify_full+0xc28>
100847454:     	cmp	w26, #0x3f
100847458:     	b.hi	0x1008466e8 <_js_json_stringify_full+0xc28>
10084745c:     	add	w26, w26, #0x1
100847460:     	ldrsb	w8, [x0, #0x1]
100847464:     	tbnz	w8, #0x1f, 0x100847438 <_js_json_stringify_full+0x1978>
100847468:     	str	x23, [x24, #0x8]
10084746c:     	ldrb	w8, [x24, #0x1]
100847470:     	orr	w8, w8, #0x80
100847474:     	strb	w8, [x24, #0x1]
100847478:     	ldrb	w8, [x0]
10084747c:     	cmp	w8, #0x1
100847480:     	b.ne	0x1008473b8 <_js_json_stringify_full+0x18f8>
100847484:     	ldp	w9, w8, [x23]
100847488:     	cmp	w9, w8
10084748c:     	b.ls	0x1008474ac <_js_json_stringify_full+0x19ec>
100847490:     	cbz	x24, 0x1008474bc <_js_json_stringify_full+0x19fc>
100847494:     	ldr	w9, [x0, #0x4]
100847498:     	ubfiz	x8, x8, #3, #32
10084749c:     	add	x8, x8, #0x10
1008474a0:     	cmp	x8, x9
1008474a4:     	b.eq	0x1008474d4 <_js_json_stringify_full+0x1a14>
1008474a8:     	b	0x1008474bc <_js_json_stringify_full+0x19fc>
1008474ac:     	mov	w8, #0xe100             ; =57600
1008474b0:     	movk	w8, #0x5f5, lsl #16
1008474b4:     	cmp	w9, w8
1008474b8:     	b.ls	0x1008474d4 <_js_json_stringify_full+0x1a14>
1008474bc:     	mov	x0, x23
1008474c0:     	bl	0x1005891f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1008474c4:     	tbnz	w0, #0x0, 0x1008474d4 <_js_json_stringify_full+0x1a14>
1008474c8:     	mov	x0, x23
1008474cc:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
1008474d0:     	tbz	w0, #0x0, 0x1008466e8 <_js_json_stringify_full+0xc28>
1008474d4:     	ldp	w8, w9, [x23]
1008474d8:     	sub	w10, w9, #0x1
1008474dc:     	mov	w11, #0x270f            ; =9999
1008474e0:     	cmp	w10, w11
1008474e4:     	ccmp	w8, w9, #0x2, lo
1008474e8:     	b.hi	0x1008466e8 <_js_json_stringify_full+0xc28>
1008474ec:     	and	x8, x21, #0xffffffffffff
1008474f0:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008474f4:     	cmp	x25, x9
1008474f8:     	csel	x1, x8, x21, eq
1008474fc:     	add	x0, sp, #0x30
100847500:     	bl	0x1004ffc78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
100847504:     	ldr	x25, [sp, #0x30]
100847508:     	cmn	x25, #0x1
10084750c:     	cset	w24, eq
100847510:     	cmp	x27, #0x1
100847514:     	cset	w8, hi
100847518:     	tst	w8, w24
10084751c:     	b.ne	0x100846704 <_js_json_stringify_full+0xc44>
100847520:     	b	0x100846774 <_js_json_stringify_full+0xcb4>
100847524:     	add	x9, x8, #0x90
100847528:     	ldr	x10, [x8, #0x30]
10084752c:     	add	x10, x10, #0x1
100847530:     	str	x10, [x8, #0x30]
100847534:     	add	x8, x9, #0x19
100847538:     	ldrb	w8, [x8]
10084753c:     	cmp	w8, #0xff
100847540:     	b.ne	0x100847334 <_js_json_stringify_full+0x1874>
100847544:     	b	0x100847328 <_js_json_stringify_full+0x1868>
100847548:     	mov	x0, x23
10084754c:     	bl	0x100b1e504 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847550:     	cbnz	x0, 0x100846890 <_js_json_stringify_full+0xdd0>
100847554:     	b	0x1008476d0 <_js_json_stringify_full+0x1c10>
100847558:     	and	x0, x19, #0xffffffffffff
10084755c:     	bl	0x1004f7d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
100847560:     	mov	w0, w0
100847564:     	mov	x20, #0x7d7b            ; =32123
100847568:     	movk	x20, #0x200, lsl #32
10084756c:     	movk	x20, #0x7ff9, lsl #48
100847570:     	tbz	w0, #0x0, 0x100846098 <_js_json_stringify_full+0x5d8>
100847574:     	b	0x100846f68 <_js_json_stringify_full+0x14a8>
100847578:     	mov	x19, x0
10084757c:     	mov	x0, x23
100847580:     	bl	0x100b1e504 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847584:     	mov	x23, x0
100847588:     	mov	x0, x19
10084758c:     	cbnz	x23, 0x100846e74 <_js_json_stringify_full+0x13b4>
100847590:     	b	0x100847670 <_js_json_stringify_full+0x1bb0>
100847594:     	bl	0x100b1e664 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100847598:     	cbnz	x0, 0x1008467b8 <_js_json_stringify_full+0xcf8>
10084759c:     	b	0x1008476d0 <_js_json_stringify_full+0x1c10>
1008475a0:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1008475a4:     	add	x0, x0, #0x440
1008475a8:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008475ac:     	cmp	w8, #0x1
1008475b0:     	b.ne	0x1008476d0 <_js_json_stringify_full+0x1c10>
1008475b4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008475b8:     	add	x1, x1, #0x998
1008475bc:     	mov	x19, x0
1008475c0:     	bl	0x100a203dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008475c4:     	mov	x0, x19
1008475c8:     	strb	wzr, [x19, #0x20]
1008475cc:     	ldr	x8, [x19]
1008475d0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1008475d4:     	cmp	x8, x9
1008475d8:     	b.lo	0x1008469d8 <_js_json_stringify_full+0xf18>
1008475dc:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008475e0:     	add	x0, x0, #0xea8
1008475e4:     	bl	0x100b126dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1008475e8:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008475ec:     	add	x0, x0, #0xec0
1008475f0:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008475f4:     	and	x0, x19, #0xffffffffffff
1008475f8:     	bl	0x1004ef9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
1008475fc:     	mov	x20, x1
100847600:     	tbz	w0, #0x0, 0x100846098 <_js_json_stringify_full+0x5d8>
100847604:     	b	0x100846f68 <_js_json_stringify_full+0x14a8>
100847608:     	mov	x0, x23
10084760c:     	bl	0x100b1e504 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847610:     	mov	x23, x0
100847614:     	cbnz	x0, 0x100846d24 <_js_json_stringify_full+0x1264>
100847618:     	b	0x100847670 <_js_json_stringify_full+0x1bb0>
10084761c:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100847620:     	add	x0, x0, #0xd70
100847624:     	bl	0x100b126dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100847628:     	bl	0x100b4b8d4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
10084762c:     	cmp	w8, #0x2
100847630:     	b.eq	0x1008476d0 <_js_json_stringify_full+0x1c10>
100847634:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847638:     	add	x1, x1, #0x998
10084763c:     	mov	x19, x0
100847640:     	bl	0x100a203dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847644:     	mov	x0, x19
100847648:     	strb	wzr, [x19, #0x20]
10084764c:     	ldr	x8, [x19]
100847650:     	cbz	x8, 0x100846d10 <_js_json_stringify_full+0x1250>
100847654:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847658:     	add	x0, x0, #0xe90
10084765c:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847660:     	mov	x0, x23
100847664:     	bl	0x100b1e504 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847668:     	mov	x23, x0
10084766c:     	cbnz	x0, 0x100846c40 <_js_json_stringify_full+0x1180>
100847670:     	cbz	x22, 0x1008476d0 <_js_json_stringify_full+0x1c10>
100847674:     	mov	x0, x19
100847678:     	bl	0x100b5ef40 <_mi_free>
10084767c:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847680:     	add	x0, x0, #0xc18
100847684:     	bl	0x100b5859c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100847688:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0xaf4>
10084768c:     	add	x0, x0, #0x430
100847690:     	mov	w1, #0xf                ; =15
100847694:     	bl	0x100b4b89c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100847698:     	and	x0, x19, #0xffffffffffff
10084769c:     	add	x2, sp, #0x80
1008476a0:     	mov	x1, x22
1008476a4:     	bl	0x1004f01c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
1008476a8:     	tbnz	w0, #0x0, 0x1008470d4 <_js_json_stringify_full+0x1614>
1008476ac:     	mov	w20, #0x2               ; =2
1008476b0:     	and	x0, x19, #0xffffffffffff
1008476b4:     	mov	x1, x20
1008476b8:     	bl	0x1004ee840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
1008476bc:     	mov	x20, x1
1008476c0:     	tbz	w0, #0x0, 0x100846098 <_js_json_stringify_full+0x5d8>
1008476c4:     	b	0x100846f68 <_js_json_stringify_full+0x14a8>
1008476c8:     	cmp	w8, #0x2
1008476cc:     	b.ne	0x1008476f8 <_js_json_stringify_full+0x1c38>
1008476d0:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1008476d4:     	add	x0, x0, #0xc18
1008476d8:     	bl	0x100b5859c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1008476dc:     	adrp	x0, 0x100f2b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x1d8>
1008476e0:     	add	x0, x0, #0x800
1008476e4:     	bl	0x100b12770 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
1008476e8:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0xaf4>
1008476ec:     	add	x0, x0, #0x167
1008476f0:     	mov	w1, #0xb                ; =11
1008476f4:     	bl	0x100b4b89c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
1008476f8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008476fc:     	add	x1, x1, #0x998
100847700:     	mov	x19, x0
100847704:     	bl	0x100a203dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847708:     	mov	x0, x19
10084770c:     	strb	wzr, [x19, #0x20]
100847710:     	ldr	x8, [x19]
100847714:     	cbz	x8, 0x100846c2c <_js_json_stringify_full+0x116c>
100847718:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084771c:     	add	x0, x0, #0xe78
100847720:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847724:     	mov	w0, #0x1                ; =1
100847728:     	mov	x1, x24
10084772c:     	bl	0x100b12300 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847730:     	mov	w0, #0x1                ; =1
100847734:     	mov	x1, x22
100847738:     	bl	0x100b12300 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084773c:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100847740:     	add	x2, x2, #0x3c8
100847744:     	mov	w0, #0x5                ; =5
100847748:     	mov	w1, #0x5                ; =5
10084774c:     	bl	0x100b1280c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
