
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/dominant-token-dispatch-r43/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010084a680 <_js_json_stringify_full>:
10084a680:     	sub	sp, sp, #0x120
10084a684:     	stp	d9, d8, [sp, #0xb0]
10084a688:     	stp	x28, x27, [sp, #0xc0]
10084a68c:     	stp	x26, x25, [sp, #0xd0]
10084a690:     	stp	x24, x23, [sp, #0xe0]
10084a694:     	stp	x22, x21, [sp, #0xf0]
10084a698:     	stp	x20, x19, [sp, #0x100]
10084a69c:     	stp	x29, x30, [sp, #0x110]
10084a6a0:     	add	x29, sp, #0x110
10084a6a4:     	mov.16b	v9, v2
10084a6a8:     	mov.16b	v8, v0
10084a6ac:     	fmov	x19, d8
10084a6b0:     	fmov	x21, d1
10084a6b4:     	fmov	x23, d9
10084a6b8:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
10084a6bc:     	add	x27, x21, x8
10084a6c0:     	add	x24, x23, x8
10084a6c4:     	fcmp	d2, #0.0
10084a6c8:     	ccmp	x24, #0x2, #0x0, ne
10084a6cc:     	b.hi	0x10084a6dc <_js_json_stringify_full+0x5c>
10084a6d0:     	cmp	x27, #0x2
10084a6d4:     	b.lo	0x10084a6ec <_js_json_stringify_full+0x6c>
10084a6d8:     	b	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084a6dc:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
10084a6e0:     	cmp	x23, x8
10084a6e4:     	ccmp	x27, #0x2, #0x2, eq
10084a6e8:     	b.hs	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084a6ec:     	mov	x8, #-0x2               ; =-2
10084a6f0:     	movk	x8, #0x8003, lsl #48
10084a6f4:     	add	x8, x19, x8
10084a6f8:     	cmp	x8, #0x3
10084a6fc:     	b.hs	0x10084a710 <_js_json_stringify_full+0x90>
10084a700:     	adrp	x9, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4bf0>
10084a704:     	add	x9, x9, #0x998
10084a708:     	ldr	x20, [x9, x8, lsl #3]
10084a70c:     	b	0x10084bb28 <_js_json_stringify_full+0x14a8>
10084a710:     	strb	wzr, [sp, #0x4c]
10084a714:     	str	wzr, [sp, #0x48]
10084a718:     	and	x8, x19, #0xffff000000000000
10084a71c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084a720:     	cmp	x8, x9
10084a724:     	b.eq	0x10084a798 <_js_json_stringify_full+0x118>
10084a728:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084a72c:     	cmp	x8, x9
10084a730:     	b.ne	0x10084ab94 <_js_json_stringify_full+0x514>
10084a734:     	ubfx	x10, x19, #40, #8
10084a738:     	cbz	x10, 0x10084a788 <_js_json_stringify_full+0x108>
10084a73c:     	strb	w19, [sp, #0x48]
10084a740:     	cmp	x10, #0x1
10084a744:     	b.eq	0x10084a788 <_js_json_stringify_full+0x108>
10084a748:     	lsr	x9, x19, #8
10084a74c:     	strb	w9, [sp, #0x49]
10084a750:     	cmp	x10, #0x2
10084a754:     	b.eq	0x10084a788 <_js_json_stringify_full+0x108>
10084a758:     	lsr	x9, x19, #16
10084a75c:     	strb	w9, [sp, #0x4a]
10084a760:     	cmp	x10, #0x3
10084a764:     	b.eq	0x10084a788 <_js_json_stringify_full+0x108>
10084a768:     	lsr	x9, x19, #24
10084a76c:     	strb	w9, [sp, #0x4b]
10084a770:     	cmp	x10, #0x4
10084a774:     	b.eq	0x10084a788 <_js_json_stringify_full+0x108>
10084a778:     	lsr	x9, x19, #32
10084a77c:     	strb	w9, [sp, #0x4c]
10084a780:     	cmp	x10, #0x5
10084a784:     	b.ne	0x10084c2fc <_js_json_stringify_full+0x1c7c>
10084a788:     	add	x11, sp, #0x48
10084a78c:     	cmp	w10, #0x3
10084a790:     	b.ls	0x10084a7b0 <_js_json_stringify_full+0x130>
10084a794:     	b	0x10084ab94 <_js_json_stringify_full+0x514>
10084a798:     	ands	x9, x19, #0xffffffffffff
10084a79c:     	b.eq	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084a7a0:     	add	x11, x9, #0x14
10084a7a4:     	ldr	w10, [x9, #0x4]
10084a7a8:     	cmp	w10, #0x3
10084a7ac:     	b.hi	0x10084ab94 <_js_json_stringify_full+0x514>
10084a7b0:     	stur	wzr, [sp, #0x81]
10084a7b4:     	mov	w9, #0x22               ; =34
10084a7b8:     	strb	w9, [sp, #0x80]
10084a7bc:     	cbz	w10, 0x10084a7f4 <_js_json_stringify_full+0x174>
10084a7c0:     	add	x12, sp, #0x80
10084a7c4:     	ldrb	w13, [x11]
10084a7c8:     	sxtb	w15, w13
10084a7cc:     	cmp	w13, #0xb
10084a7d0:     	b.le	0x10084a7fc <_js_json_stringify_full+0x17c>
10084a7d4:     	cmp	w13, #0x21
10084a7d8:     	b.gt	0x10084a81c <_js_json_stringify_full+0x19c>
10084a7dc:     	cmp	w13, #0xc
10084a7e0:     	b.eq	0x10084a850 <_js_json_stringify_full+0x1d0>
10084a7e4:     	cmp	w13, #0xd
10084a7e8:     	b.ne	0x10084a82c <_js_json_stringify_full+0x1ac>
10084a7ec:     	mov	w15, #0x72              ; =114
10084a7f0:     	b	0x10084a85c <_js_json_stringify_full+0x1dc>
10084a7f4:     	mov	w12, #0x1               ; =1
10084a7f8:     	b	0x10084a884 <_js_json_stringify_full+0x204>
10084a7fc:     	cmp	w13, #0x8
10084a800:     	b.eq	0x10084a848 <_js_json_stringify_full+0x1c8>
10084a804:     	cmp	w13, #0x9
10084a808:     	b.eq	0x10084a858 <_js_json_stringify_full+0x1d8>
10084a80c:     	cmp	w13, #0xa
10084a810:     	b.ne	0x10084a82c <_js_json_stringify_full+0x1ac>
10084a814:     	mov	w15, #0x6e              ; =110
10084a818:     	b	0x10084a85c <_js_json_stringify_full+0x1dc>
10084a81c:     	cmp	w13, #0x22
10084a820:     	b.eq	0x10084a85c <_js_json_stringify_full+0x1dc>
10084a824:     	cmp	w13, #0x5c
10084a828:     	b.eq	0x10084a85c <_js_json_stringify_full+0x1dc>
10084a82c:     	cmp	w15, #0x20
10084a830:     	b.lt	0x10084ab94 <_js_json_stringify_full+0x514>
10084a834:     	mov	w14, #0x0               ; =0
10084a838:     	add	x13, x12, #0x2
10084a83c:     	mov	w12, #0x2               ; =2
10084a840:     	mov	w16, #0x1               ; =1
10084a844:     	b	0x10084a874 <_js_json_stringify_full+0x1f4>
10084a848:     	mov	w15, #0x62              ; =98
10084a84c:     	b	0x10084a85c <_js_json_stringify_full+0x1dc>
10084a850:     	mov	w15, #0x66              ; =102
10084a854:     	b	0x10084a85c <_js_json_stringify_full+0x1dc>
10084a858:     	mov	w15, #0x74              ; =116
10084a85c:     	add	x13, x12, #0x3
10084a860:     	mov	w12, #0x5c              ; =92
10084a864:     	strb	w12, [sp, #0x81]
10084a868:     	mov	w14, #0x1               ; =1
10084a86c:     	mov	w12, #0x3               ; =3
10084a870:     	mov	w16, #0x2               ; =2
10084a874:     	add	x17, sp, #0x80
10084a878:     	strb	w15, [x17, x16]
10084a87c:     	cmp	w10, #0x1
10084a880:     	b.ne	0x10084a8bc <_js_json_stringify_full+0x23c>
10084a884:     	add	x10, sp, #0x80
10084a888:     	strb	w9, [x10, x12]
10084a88c:     	add	x8, x12, #0x1
10084a890:     	cmp	x12, #0x3
10084a894:     	b.hs	0x10084a8a8 <_js_json_stringify_full+0x228>
10084a898:     	mov	x13, #0x0               ; =0
10084a89c:     	mov	x11, #0x0               ; =0
10084a8a0:     	add	x9, sp, #0x80
10084a8a4:     	b	0x10084ab04 <_js_json_stringify_full+0x484>
10084a8a8:     	cmp	x12, #0xf
10084a8ac:     	b.hs	0x10084a8ec <_js_json_stringify_full+0x26c>
10084a8b0:     	mov	x11, #0x0               ; =0
10084a8b4:     	mov	x13, #0x0               ; =0
10084a8b8:     	b	0x10084aa60 <_js_json_stringify_full+0x3e0>
10084a8bc:     	ldrb	w16, [x11, #0x1]
10084a8c0:     	sxtb	w15, w16
10084a8c4:     	cmp	w16, #0xb
10084a8c8:     	b.le	0x10084ab34 <_js_json_stringify_full+0x4b4>
10084a8cc:     	cmp	w16, #0x21
10084a8d0:     	b.gt	0x10084ab54 <_js_json_stringify_full+0x4d4>
10084a8d4:     	cmp	w16, #0xc
10084a8d8:     	b.eq	0x10084ab84 <_js_json_stringify_full+0x504>
10084a8dc:     	cmp	w16, #0xd
10084a8e0:     	b.ne	0x10084ab64 <_js_json_stringify_full+0x4e4>
10084a8e4:     	mov	w15, #0x72              ; =114
10084a8e8:     	b	0x10084ab90 <_js_json_stringify_full+0x510>
10084a8ec:     	and	x12, x8, #0xc
10084a8f0:     	and	x11, x8, #0x10
10084a8f4:     	add	x13, sp, #0x80
10084a8f8:     	add	x9, x13, x11
10084a8fc:     	adrp	x14, 0x100ca0000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5bf0>
10084a900:     	ldr	q0, [x14, #0xb10]
10084a904:     	adrp	x14, 0x100ca0000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5bf0>
10084a908:     	ldr	q1, [x14, #0xb20]
10084a90c:     	adrp	x14, 0x100ca0000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5bf0>
10084a910:     	ldr	q2, [x14, #0xb30]
10084a914:     	adrp	x14, 0x100ca0000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5bf0>
10084a918:     	ldr	q3, [x14, #0xb40]
10084a91c:     	adrp	x14, 0x100ca0000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5bf0>
10084a920:     	ldr	q4, [x14, #0xb50]
10084a924:     	movi.2d	v5, #0000000000000000
10084a928:     	adrp	x14, 0x100ca0000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5bf0>
10084a92c:     	ldr	q6, [x14, #0xb60]
10084a930:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4bf0>
10084a934:     	ldr	q7, [x14, #0xc80]
10084a938:     	mov	w14, #0x10              ; =16
10084a93c:     	movi.2d	v16, #0000000000000000
10084a940:     	dup.2d	v17, x14
10084a944:     	adrp	x14, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x334fa>
10084a948:     	ldr	q19, [x14, #0xa80]
10084a94c:     	and	x14, x8, #0x10
10084a950:     	movi.2d	v20, #0000000000000000
10084a954:     	movi.2d	v18, #0000000000000000
10084a958:     	movi.2d	v23, #0000000000000000
10084a95c:     	movi.2d	v21, #0000000000000000
10084a960:     	movi.2d	v24, #0000000000000000
10084a964:     	movi.2d	v22, #0000000000000000
10084a968:     	ldr	q25, [x13], #0x10
10084a96c:     	ushll.8h	v26, v25, #0x0
10084a970:     	ushll2.4s	v27, v26, #0x0
10084a974:     	ushll2.2d	v28, v27, #0x0
10084a978:     	ushll2.8h	v25, v25, #0x0
10084a97c:     	ushll.4s	v29, v25, #0x0
10084a980:     	ushll2.2d	v30, v29, #0x0
10084a984:     	ushll.2d	v29, v29, #0x0
10084a988:     	ushll.2d	v27, v27, #0x0
10084a98c:     	ushll.4s	v26, v26, #0x0
10084a990:     	ushll2.2d	v31, v26, #0x0
10084a994:     	ushll2.4s	v25, v25, #0x0
10084a998:     	ushll.2d	v8, v25, #0x0
10084a99c:     	ushll.2d	v26, v26, #0x0
10084a9a0:     	ushll2.2d	v25, v25, #0x0
10084a9a4:     	shl.2d	v9, v0, #0x3
10084a9a8:     	ushl.2d	v25, v25, v9
10084a9ac:     	shl.2d	v9, v19, #0x3
10084a9b0:     	ushl.2d	v26, v26, v9
10084a9b4:     	shl.2d	v9, v1, #0x3
10084a9b8:     	ushl.2d	v8, v8, v9
10084a9bc:     	shl.2d	v9, v7, #0x3
10084a9c0:     	ushl.2d	v31, v31, v9
10084a9c4:     	shl.2d	v9, v6, #0x3
10084a9c8:     	ushl.2d	v27, v27, v9
10084a9cc:     	shl.2d	v9, v3, #0x3
10084a9d0:     	ushl.2d	v29, v29, v9
10084a9d4:     	shl.2d	v9, v2, #0x3
10084a9d8:     	ushl.2d	v30, v30, v9
10084a9dc:     	shl.2d	v9, v4, #0x3
10084a9e0:     	ushl.2d	v28, v28, v9
10084a9e4:     	orr.16b	v18, v28, v18
10084a9e8:     	orr.16b	v21, v30, v21
10084a9ec:     	orr.16b	v23, v29, v23
10084a9f0:     	orr.16b	v20, v27, v20
10084a9f4:     	orr.16b	v5, v31, v5
10084a9f8:     	orr.16b	v24, v8, v24
10084a9fc:     	orr.16b	v16, v26, v16
10084aa00:     	orr.16b	v22, v25, v22
10084aa04:     	add.2d	v6, v6, v17
10084aa08:     	add.2d	v7, v7, v17
10084aa0c:     	add.2d	v19, v19, v17
10084aa10:     	add.2d	v4, v4, v17
10084aa14:     	add.2d	v3, v3, v17
10084aa18:     	add.2d	v2, v2, v17
10084aa1c:     	add.2d	v1, v1, v17
10084aa20:     	add.2d	v0, v0, v17
10084aa24:     	subs	x14, x14, #0x10
10084aa28:     	b.ne	0x10084a968 <_js_json_stringify_full+0x2e8>
10084aa2c:     	orr.16b	v0, v16, v23
10084aa30:     	orr.16b	v1, v20, v24
10084aa34:     	orr.16b	v0, v0, v1
10084aa38:     	orr.16b	v1, v5, v21
10084aa3c:     	orr.16b	v2, v18, v22
10084aa40:     	orr.16b	v1, v1, v2
10084aa44:     	orr.16b	v0, v0, v1
10084aa48:     	mov	d1, v0[1]
10084aa4c:     	orr.8b	v0, v0, v1
10084aa50:     	fmov	x13, d0
10084aa54:     	cmp	x8, x11
10084aa58:     	b.eq	0x10084ab24 <_js_json_stringify_full+0x4a4>
10084aa5c:     	cbz	x12, 0x10084ab04 <_js_json_stringify_full+0x484>
10084aa60:     	mov	x14, x11
10084aa64:     	and	x11, x8, #0x1c
10084aa68:     	add	x15, sp, #0x80
10084aa6c:     	add	x9, x15, x11
10084aa70:     	fmov	d0, x13
10084aa74:     	movi.2d	v1, #0000000000000000
10084aa78:     	dup.2d	v3, x14
10084aa7c:     	adrp	x12, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4bf0>
10084aa80:     	ldr	q2, [x12, #0xc80]
10084aa84:     	orr.16b	v2, v3, v2
10084aa88:     	adrp	x12, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x334fa>
10084aa8c:     	ldr	q4, [x12, #0xa80]
10084aa90:     	orr.16b	v3, v3, v4
10084aa94:     	sub	x12, x14, x11
10084aa98:     	add	x13, x15, x14
10084aa9c:     	movi.2d	v4, #0x000000000000ff
10084aaa0:     	mov	w14, #0x4               ; =4
10084aaa4:     	dup.2d	v5, x14
10084aaa8:     	ldr	s6, [x13], #0x4
10084aaac:     	ushll.8h	v6, v6, #0x0
10084aab0:     	ushll.4s	v6, v6, #0x0
10084aab4:     	ushll2.2d	v7, v6, #0x0
10084aab8:     	and.16b	v7, v7, v4
10084aabc:     	ushll.2d	v6, v6, #0x0
10084aac0:     	and.16b	v6, v6, v4
10084aac4:     	shl.2d	v16, v2, #0x3
10084aac8:     	shl.2d	v17, v3, #0x3
10084aacc:     	ushl.2d	v6, v6, v17
10084aad0:     	ushl.2d	v7, v7, v16
10084aad4:     	orr.16b	v1, v7, v1
10084aad8:     	orr.16b	v0, v6, v0
10084aadc:     	add.2d	v2, v2, v5
10084aae0:     	add.2d	v3, v3, v5
10084aae4:     	adds	x12, x12, #0x4
10084aae8:     	b.ne	0x10084aaa8 <_js_json_stringify_full+0x428>
10084aaec:     	orr.16b	v0, v0, v1
10084aaf0:     	mov	d1, v0[1]
10084aaf4:     	orr.8b	v0, v0, v1
10084aaf8:     	fmov	x13, d0
10084aafc:     	cmp	x8, x11
10084ab00:     	b.eq	0x10084ab24 <_js_json_stringify_full+0x4a4>
10084ab04:     	add	x10, x10, x8
10084ab08:     	lsl	x11, x11, #3
10084ab0c:     	ldrb	w12, [x9], #0x1
10084ab10:     	lsl	x12, x12, x11
10084ab14:     	orr	x13, x12, x13
10084ab18:     	add	x11, x11, #0x8
10084ab1c:     	cmp	x9, x10
10084ab20:     	b.ne	0x10084ab0c <_js_json_stringify_full+0x48c>
10084ab24:     	orr	x8, x13, x8, lsl #40
10084ab28:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084ab2c:     	orr	x20, x8, x9
10084ab30:     	b	0x10084bb28 <_js_json_stringify_full+0x14a8>
10084ab34:     	cmp	w16, #0x8
10084ab38:     	b.eq	0x10084ab7c <_js_json_stringify_full+0x4fc>
10084ab3c:     	cmp	w16, #0x9
10084ab40:     	b.eq	0x10084ab8c <_js_json_stringify_full+0x50c>
10084ab44:     	cmp	w16, #0xa
10084ab48:     	b.ne	0x10084ab64 <_js_json_stringify_full+0x4e4>
10084ab4c:     	mov	w15, #0x6e              ; =110
10084ab50:     	b	0x10084ab90 <_js_json_stringify_full+0x510>
10084ab54:     	cmp	w16, #0x22
10084ab58:     	b.eq	0x10084ab90 <_js_json_stringify_full+0x510>
10084ab5c:     	cmp	w16, #0x5c
10084ab60:     	b.eq	0x10084ab90 <_js_json_stringify_full+0x510>
10084ab64:     	cmp	w15, #0x20
10084ab68:     	b.lt	0x10084ab94 <_js_json_stringify_full+0x514>
10084ab6c:     	add	x13, sp, #0x80
10084ab70:     	strb	w15, [x13, x12]
10084ab74:     	add	x12, x12, #0x1
10084ab78:     	b	0x10084b11c <_js_json_stringify_full+0xa9c>
10084ab7c:     	mov	w15, #0x62              ; =98
10084ab80:     	b	0x10084ab90 <_js_json_stringify_full+0x510>
10084ab84:     	mov	w15, #0x66              ; =102
10084ab88:     	b	0x10084ab90 <_js_json_stringify_full+0x510>
10084ab8c:     	mov	w15, #0x74              ; =116
10084ab90:     	tbz	w14, #0x0, 0x10084b108 <_js_json_stringify_full+0xa88>
10084ab94:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084ab98:     	cmp	x8, x9
10084ab9c:     	b.eq	0x10084abe4 <_js_json_stringify_full+0x564>
10084aba0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084aba4:     	cmp	x8, x9
10084aba8:     	b.ne	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084abac:     	and	x8, x19, #0xffffffffffff
10084abb0:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
10084abb4:     	mov	x10, #0x7fffffffffff    ; =140737488355327
10084abb8:     	movk	x10, #0xffef, lsl #16
10084abbc:     	cmp	x9, x10
10084abc0:     	b.hi	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084abc4:     	ldr	w8, [x8, #0x4]
10084abc8:     	cmp	w8, #0x40
10084abcc:     	b.lo	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084abd0:     	and	x0, x19, #0xffffffffffff
10084abd4:     	bl	0x1004f5968 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
10084abd8:     	cmp	x0, #0x1
10084abdc:     	b.ne	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084abe0:     	b	0x10084ada4 <_js_json_stringify_full+0x724>
10084abe4:     	and	x25, x19, #0xffffffffffff
10084abe8:     	and	x0, x19, #0xffffffffffff
10084abec:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084abf0:     	cbz	x0, 0x10084ac24 <_js_json_stringify_full+0x5a4>
10084abf4:     	ldrb	w8, [x0]
10084abf8:     	cmp	w8, #0x2
10084abfc:     	b.ne	0x10084ac24 <_js_json_stringify_full+0x5a4>
10084ac00:     	ldrsb	w8, [x0, #0x1]
10084ac04:     	tbnz	w8, #0x1f, 0x10084ac24 <_js_json_stringify_full+0x5a4>
10084ac08:     	ldrh	w8, [x0, #0x2]
10084ac0c:     	tbnz	w8, #0xb, 0x10084ac24 <_js_json_stringify_full+0x5a4>
10084ac10:     	ldr	w8, [x0, #0x4]
10084ac14:     	cmp	w8, #0x18
10084ac18:     	b.lo	0x10084ac24 <_js_json_stringify_full+0x5a4>
10084ac1c:     	ldr	w8, [x25]
10084ac20:     	cbz	w8, 0x10084bc7c <_js_json_stringify_full+0x15fc>
10084ac24:     	and	x0, x19, #0xffffffffffff
10084ac28:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084ac2c:     	cbz	x0, 0x10084ac58 <_js_json_stringify_full+0x5d8>
10084ac30:     	ldrb	w8, [x0]
10084ac34:     	cmp	w8, #0x2
10084ac38:     	b.ne	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084ac3c:     	ldrh	w8, [x0, #0x2]
10084ac40:     	tbnz	w8, #0xb, 0x10084ac58 <_js_json_stringify_full+0x5d8>
10084ac44:     	ldr	w8, [x0, #0x4]
10084ac48:     	cmp	w8, #0x18
10084ac4c:     	b.lo	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084ac50:     	ldr	w8, [x25]
10084ac54:     	cbz	w8, 0x10084bc20 <_js_json_stringify_full+0x15a0>
10084ac58:     	mov	x20, #0x1               ; =1
10084ac5c:     	movk	x20, #0x7ffc, lsl #48
10084ac60:     	cmp	x19, x20
10084ac64:     	b.eq	0x10084bb28 <_js_json_stringify_full+0x14a8>
10084ac68:     	and	x22, x19, #0xffff000000000000
10084ac6c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084ac70:     	cmp	x22, x8
10084ac74:     	b.ne	0x10084acac <_js_json_stringify_full+0x62c>
10084ac78:     	and	x8, x19, #0xffffffffffff
10084ac7c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084ac80:     	b.lo	0x10084ac98 <_js_json_stringify_full+0x618>
10084ac84:     	ldr	w8, [x8, #0xc]
10084ac88:     	mov	w9, #0x4f53             ; =20307
10084ac8c:     	movk	w9, #0x434c, lsl #16
10084ac90:     	cmp	w8, w9
10084ac94:     	b.eq	0x10084bb28 <_js_json_stringify_full+0x14a8>
10084ac98:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084ac9c:     	cmp	x22, x8
10084aca0:     	b.ne	0x10084acd8 <_js_json_stringify_full+0x658>
10084aca4:     	and	x0, x19, #0xffffffffffff
10084aca8:     	b	0x10084ad00 <_js_json_stringify_full+0x680>
10084acac:     	lsr	x8, x19, #52
10084acb0:     	cbnz	x8, 0x10084ad88 <_js_json_stringify_full+0x708>
10084acb4:     	and	x8, x19, #0x7
10084acb8:     	cbz	x19, 0x10084ace4 <_js_json_stringify_full+0x664>
10084acbc:     	cbnz	x8, 0x10084ace4 <_js_json_stringify_full+0x664>
10084acc0:     	mov	x0, x19
10084acc4:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084acc8:     	mov	x8, x19
10084accc:     	tbnz	w0, #0x0, 0x10084ac7c <_js_json_stringify_full+0x5fc>
10084acd0:     	mov	x8, #0x0                ; =0
10084acd4:     	b	0x10084ace4 <_js_json_stringify_full+0x664>
10084acd8:     	lsr	x8, x19, #52
10084acdc:     	cbnz	x8, 0x10084ad88 <_js_json_stringify_full+0x708>
10084ace0:     	and	x8, x19, #0x7
10084ace4:     	cbz	x19, 0x10084ad88 <_js_json_stringify_full+0x708>
10084ace8:     	cbnz	x8, 0x10084ad88 <_js_json_stringify_full+0x708>
10084acec:     	mov	x0, x19
10084acf0:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084acf4:     	mov	x8, x0
10084acf8:     	mov	x0, x19
10084acfc:     	tbz	w8, #0x0, 0x10084ad88 <_js_json_stringify_full+0x708>
10084ad00:     	cmp	x0, #0x100, lsl #12     ; =0x100000
10084ad04:     	b.lo	0x10084ad88 <_js_json_stringify_full+0x708>
10084ad08:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084ad0c:     	add	x8, x8, #0xfb0
10084ad10:     	ldaprb	w8, [x8]
10084ad14:     	cbz	w8, 0x10084ad88 <_js_json_stringify_full+0x708>
10084ad18:     	lsr	x8, x0, #3
10084ad1c:     	mov	x9, #0x7c15             ; =31765
10084ad20:     	movk	x9, #0x7f4a, lsl #16
10084ad24:     	movk	x9, #0x79b9, lsl #32
10084ad28:     	movk	x9, #0x9e37, lsl #48
10084ad2c:     	mul	x8, x8, x9
10084ad30:     	lsr	x10, x8, #54
10084ad34:     	lsr	x11, x8, #60
10084ad38:     	adrp	x9, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084ad3c:     	add	x9, x9, #0xf30
10084ad40:     	add	x11, x9, x11, lsl #3
10084ad44:     	ldapr	x11, [x11]
10084ad48:     	lsr	x10, x11, x10
10084ad4c:     	tbz	w10, #0x0, 0x10084ad88 <_js_json_stringify_full+0x708>
10084ad50:     	lsr	x10, x8, #44
10084ad54:     	ubfx	x11, x8, #50, #4
10084ad58:     	add	x11, x9, x11, lsl #3
10084ad5c:     	ldapr	x11, [x11]
10084ad60:     	lsr	x10, x11, x10
10084ad64:     	tbz	w10, #0x0, 0x10084ad88 <_js_json_stringify_full+0x708>
10084ad68:     	lsr	x10, x8, #34
10084ad6c:     	ubfx	x8, x8, #40, #4
10084ad70:     	add	x8, x9, x8, lsl #3
10084ad74:     	ldapr	x8, [x8]
10084ad78:     	lsr	x8, x8, x10
10084ad7c:     	tbz	w8, #0x0, 0x10084ad88 <_js_json_stringify_full+0x708>
10084ad80:     	bl	0x10034f4cc <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
10084ad84:     	tbnz	w0, #0x0, 0x10084bb28 <_js_json_stringify_full+0x14a8>
10084ad88:     	cmp	x24, #0x3
10084ad8c:     	ccmp	x27, #0x2, #0x2, lo
10084ad90:     	b.hs	0x10084adb0 <_js_json_stringify_full+0x730>
10084ad94:     	mov.16b	v0, v8
10084ad98:     	bl	0x1004f0a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084ad9c:     	cmp	x0, #0x1
10084ada0:     	b.ne	0x10084adb0 <_js_json_stringify_full+0x730>
10084ada4:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
10084ada8:     	bfxil	x20, x1, #0, #48
10084adac:     	b	0x10084bb28 <_js_json_stringify_full+0x14a8>
10084adb0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084adb4:     	cmp	x22, x8
10084adb8:     	b.ne	0x10084ae08 <_js_json_stringify_full+0x788>
10084adbc:     	ands	x22, x19, #0xffffffffffff
10084adc0:     	b.eq	0x10084ae08 <_js_json_stringify_full+0x788>
10084adc4:     	mov	x0, x22
10084adc8:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084adcc:     	cbz	w0, 0x10084ae08 <_js_json_stringify_full+0x788>
10084add0:     	ldurb	w8, [x22, #-0x8]
10084add4:     	cmp	w8, #0x9
10084add8:     	b.ne	0x10084ae08 <_js_json_stringify_full+0x788>
10084addc:     	ldr	w8, [x22, #0x4]
10084ade0:     	mov	w9, #0x5841             ; =22593
10084ade4:     	movk	w9, #0x4c5a, lsl #16
10084ade8:     	cmp	w8, w9
10084adec:     	b.ne	0x10084ae08 <_js_json_stringify_full+0x788>
10084adf0:     	mov	x0, x22
10084adf4:     	bl	0x10068bc64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
10084adf8:     	cbz	x0, 0x10084ae08 <_js_json_stringify_full+0x788>
10084adfc:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
10084ae00:     	bfxil	x19, x0, #0, #48
10084ae04:     	fmov	d8, x19
10084ae08:     	mov	w8, #0x7ffd             ; =32765
10084ae0c:     	cmp	x8, x23, lsr #48
10084ae10:     	b.ne	0x10084ae24 <_js_json_stringify_full+0x7a4>
10084ae14:     	and	x1, x23, #0xffffffffffff
10084ae18:     	cmp	x1, #0x100, lsl #12     ; =0x100000
10084ae1c:     	b.hs	0x10084ae38 <_js_json_stringify_full+0x7b8>
10084ae20:     	b	0x10084ae8c <_js_json_stringify_full+0x80c>
10084ae24:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
10084ae28:     	mov	x9, #0xfffffff00000     ; =281474975662080
10084ae2c:     	mov	x1, x23
10084ae30:     	cmp	x8, x9
10084ae34:     	b.hs	0x10084ae8c <_js_json_stringify_full+0x80c>
10084ae38:     	lsr	x8, x1, #47
10084ae3c:     	cbnz	x8, 0x10084ae8c <_js_json_stringify_full+0x80c>
10084ae40:     	add	x0, sp, #0x80
10084ae44:     	bl	0x100772bec <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
10084ae48:     	ldr	w8, [sp, #0x80]
10084ae4c:     	tbz	w8, #0x0, 0x10084ae8c <_js_json_stringify_full+0x80c>
10084ae50:     	ldr	w8, [sp, #0x88]
10084ae54:     	mov	w9, #-0xff30            ; =-65328
10084ae58:     	cmp	w8, w9
10084ae5c:     	b.eq	0x10084ae80 <_js_json_stringify_full+0x800>
10084ae60:     	mov	w9, #-0xff2f            ; =-65327
10084ae64:     	cmp	w8, w9
10084ae68:     	b.ne	0x10084ae8c <_js_json_stringify_full+0x80c>
10084ae6c:     	mov.16b	v0, v9
10084ae70:     	bl	0x10084cf3c <_js_jsvalue_to_string>
10084ae74:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
10084ae78:     	bfxil	x23, x0, #0, #48
10084ae7c:     	b	0x10084ae8c <_js_json_stringify_full+0x80c>
10084ae80:     	mov.16b	v0, v9
10084ae84:     	bl	0x1008744e0 <_js_number_coerce>
10084ae88:     	fmov	x23, d0
10084ae8c:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
10084ae90:     	add	x8, x23, x8
10084ae94:     	cmp	x8, #0x3
10084ae98:     	b.hs	0x10084aeb0 <_js_json_stringify_full+0x830>
10084ae9c:     	mov	x22, #0x0               ; =0
10084aea0:     	mov	w8, #0x1                ; =1
10084aea4:     	stp	xzr, x8, [sp, #0x10]
10084aea8:     	str	xzr, [sp, #0x20]
10084aeac:     	b	0x10084b164 <_js_json_stringify_full+0xae4>
10084aeb0:     	and	x8, x23, #0xffff000000000000
10084aeb4:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084aeb8:     	cmp	x8, x9
10084aebc:     	b.eq	0x10084aee0 <_js_json_stringify_full+0x860>
10084aec0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084aec4:     	cmp	x8, x9
10084aec8:     	b.ne	0x10084af6c <_js_json_stringify_full+0x8ec>
10084aecc:     	and	x8, x23, #0xffffffffffff
10084aed0:     	cmp	x8, #0x1, lsl #12       ; =0x1000
10084aed4:     	b.hs	0x10084afb4 <_js_json_stringify_full+0x934>
10084aed8:     	mov	x9, #0x0                ; =0
10084aedc:     	b	0x10084afbc <_js_json_stringify_full+0x93c>
10084aee0:     	strb	wzr, [sp, #0x4c]
10084aee4:     	str	wzr, [sp, #0x48]
10084aee8:     	ubfx	x1, x23, #40, #8
10084aeec:     	cbz	x1, 0x10084af3c <_js_json_stringify_full+0x8bc>
10084aef0:     	strb	w23, [sp, #0x48]
10084aef4:     	cmp	x1, #0x1
10084aef8:     	b.eq	0x10084af3c <_js_json_stringify_full+0x8bc>
10084aefc:     	lsr	x8, x23, #8
10084af00:     	strb	w8, [sp, #0x49]
10084af04:     	cmp	x1, #0x2
10084af08:     	b.eq	0x10084af3c <_js_json_stringify_full+0x8bc>
10084af0c:     	lsr	x8, x23, #16
10084af10:     	strb	w8, [sp, #0x4a]
10084af14:     	cmp	x1, #0x3
10084af18:     	b.eq	0x10084af3c <_js_json_stringify_full+0x8bc>
10084af1c:     	lsr	x8, x23, #24
10084af20:     	strb	w8, [sp, #0x4b]
10084af24:     	cmp	x1, #0x4
10084af28:     	b.eq	0x10084af3c <_js_json_stringify_full+0x8bc>
10084af2c:     	lsr	x8, x23, #32
10084af30:     	strb	w8, [sp, #0x4c]
10084af34:     	cmp	x1, #0x5
10084af38:     	b.ne	0x10084c2fc <_js_json_stringify_full+0x1c7c>
10084af3c:     	add	x8, sp, #0x80
10084af40:     	add	x0, sp, #0x48
10084af44:     	bl	0x10002dc18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10084af48:     	ldr	w8, [sp, #0x80]
10084af4c:     	ldp	x9, x22, [sp, #0x88]
10084af50:     	cmp	w8, #0x0
10084af54:     	csinc	x23, x9, xzr, eq
10084af58:     	csel	x25, xzr, x22, ne
10084af5c:     	tbz	x25, #0x3f, 0x10084b09c <_js_json_stringify_full+0xa1c>
10084af60:     	mov	x0, #0x0                ; =0
10084af64:     	mov	x1, x22
10084af68:     	bl	0x100b17480 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084af6c:     	add	x8, x20, #0x3
10084af70:     	cmp	x23, x8
10084af74:     	b.eq	0x10084ae9c <_js_json_stringify_full+0x81c>
10084af78:     	fmov	d0, x23
10084af7c:     	fcvtzu	x8, d0
10084af80:     	mov	w9, #0xa                ; =10
10084af84:     	cmp	x8, #0xa
10084af88:     	csel	x3, x8, x9, lo
10084af8c:     	adrp	x1, 0x100c48000 <_PERRY_EMPTY_STRING+0x1934>
10084af90:     	add	x1, x1, #0x8a4
10084af94:     	add	x0, sp, #0x80
10084af98:     	mov	w2, #0x1                ; =1
10084af9c:     	bl	0x1002304f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
10084afa0:     	ldr	x22, [sp, #0x90]
10084afa4:     	str	x22, [sp, #0x20]
10084afa8:     	ldr	q0, [sp, #0x80]
10084afac:     	str	q0, [sp, #0x10]
10084afb0:     	b	0x10084b164 <_js_json_stringify_full+0xae4>
10084afb4:     	ldr	w22, [x8, #0x4]
10084afb8:     	add	x9, x8, #0x14
10084afbc:     	mov	x14, #0x0               ; =0
10084afc0:     	mov	x8, #0x0                ; =0
10084afc4:     	cmp	x9, #0x0
10084afc8:     	csel	x24, xzr, x22, eq
10084afcc:     	csinc	x23, x9, xzr, ne
10084afd0:     	add	x9, x23, x24
10084afd4:     	mov	w10, #0x1               ; =1
10084afd8:     	mov	x11, x23
10084afdc:     	b	0x10084b00c <_js_json_stringify_full+0x98c>
10084afe0:     	add	x12, x11, #0x2
10084afe4:     	bfi	w15, w13, #6, #5
10084afe8:     	mov	x13, x15
10084afec:     	sub	x11, x25, x11
10084aff0:     	add	x14, x11, x12
10084aff4:     	cmp	w13, #0x10, lsl #12     ; =0x10000
10084aff8:     	cinc	x11, x10, hs
10084affc:     	add	x8, x11, x8
10084b000:     	mov	x11, x12
10084b004:     	cmp	x8, #0xa
10084b008:     	b.hi	0x10084b0c4 <_js_json_stringify_full+0xa44>
10084b00c:     	cmp	x11, x9
10084b010:     	b.eq	0x10084b074 <_js_json_stringify_full+0x9f4>
10084b014:     	mov	x25, x14
10084b018:     	mov	x12, x11
10084b01c:     	ldrsb	w14, [x12], #0x1
10084b020:     	and	w13, w14, #0xff
10084b024:     	tbz	w14, #0x1f, 0x10084afec <_js_json_stringify_full+0x96c>
10084b028:     	ldrb	w12, [x11, #0x1]
10084b02c:     	and	w15, w12, #0x3f
10084b030:     	cmp	w13, #0xe0
10084b034:     	b.lo	0x10084afe0 <_js_json_stringify_full+0x960>
10084b038:     	and	w14, w13, #0x1f
10084b03c:     	ldrb	w12, [x11, #0x2]
10084b040:     	and	w12, w12, #0x3f
10084b044:     	orr	w15, w12, w15, lsl #6
10084b048:     	cmp	w13, #0xf0
10084b04c:     	b.lo	0x10084b068 <_js_json_stringify_full+0x9e8>
10084b050:     	add	x12, x11, #0x4
10084b054:     	ldrb	w13, [x11, #0x3]
10084b058:     	and	w13, w13, #0x3f
10084b05c:     	orr	w13, w13, w15, lsl #6
10084b060:     	bfi	w13, w14, #18, #3
10084b064:     	b	0x10084afec <_js_json_stringify_full+0x96c>
10084b068:     	add	x12, x11, #0x3
10084b06c:     	orr	w13, w15, w14, lsl #12
10084b070:     	b	0x10084afec <_js_json_stringify_full+0x96c>
10084b074:     	cbz	x24, 0x10084b0f8 <_js_json_stringify_full+0xa78>
10084b078:     	mov	x0, x24
10084b07c:     	mov	w1, #0x1                ; =1
10084b080:     	bl	0x100b64388 <_mi_malloc_aligned>
10084b084:     	cbz	x0, 0x10084c2e4 <_js_json_stringify_full+0x1c64>
10084b088:     	mov	x26, x0
10084b08c:     	mov	x1, x23
10084b090:     	mov	x2, x24
10084b094:     	bl	0x100b66fac <_writev+0x100b66fac>
10084b098:     	b	0x10084b100 <_js_json_stringify_full+0xa80>
10084b09c:     	cbz	x25, 0x10084b154 <_js_json_stringify_full+0xad4>
10084b0a0:     	mov	x0, x25
10084b0a4:     	mov	w1, #0x1                ; =1
10084b0a8:     	bl	0x100b64388 <_mi_malloc_aligned>
10084b0ac:     	cbz	x0, 0x10084c2f0 <_js_json_stringify_full+0x1c70>
10084b0b0:     	mov	x24, x0
10084b0b4:     	mov	x1, x23
10084b0b8:     	mov	x2, x25
10084b0bc:     	bl	0x100b66fac <_writev+0x100b66fac>
10084b0c0:     	b	0x10084b15c <_js_json_stringify_full+0xadc>
10084b0c4:     	cbz	x25, 0x10084b0f8 <_js_json_stringify_full+0xa78>
10084b0c8:     	cmp	x25, x24
10084b0cc:     	b.hs	0x10084bb74 <_js_json_stringify_full+0x14f4>
10084b0d0:     	ldrsb	w8, [x23, x25]
10084b0d4:     	cmn	w8, #0x40
10084b0d8:     	b.ge	0x10084bb78 <_js_json_stringify_full+0x14f8>
10084b0dc:     	adrp	x4, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084b0e0:     	add	x4, x4, #0x270
10084b0e4:     	mov	x0, x23
10084b0e8:     	mov	x1, x24
10084b0ec:     	mov	x2, #0x0                ; =0
10084b0f0:     	mov	x3, x25
10084b0f4:     	bl	0x100b177f8 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
10084b0f8:     	mov	x22, #0x0               ; =0
10084b0fc:     	mov	w26, #0x1               ; =1
10084b100:     	stp	x22, x26, [sp, #0x10]
10084b104:     	b	0x10084b160 <_js_json_stringify_full+0xae0>
10084b108:     	add	x14, sp, #0x80
10084b10c:     	mov	w16, #0x5c              ; =92
10084b110:     	strb	w16, [x14, x12]
10084b114:     	add	x12, x12, #0x2
10084b118:     	strb	w15, [x13, #0x1]
10084b11c:     	cmp	w10, #0x2
10084b120:     	b.eq	0x10084a884 <_js_json_stringify_full+0x204>
10084b124:     	ldrb	w11, [x11, #0x2]
10084b128:     	sxtb	w10, w11
10084b12c:     	cmp	w11, #0xb
10084b130:     	b.le	0x10084bc00 <_js_json_stringify_full+0x1580>
10084b134:     	cmp	w11, #0x21
10084b138:     	b.gt	0x10084bc4c <_js_json_stringify_full+0x15cc>
10084b13c:     	cmp	w11, #0xc
10084b140:     	b.eq	0x10084bcd8 <_js_json_stringify_full+0x1658>
10084b144:     	cmp	w11, #0xd
10084b148:     	b.ne	0x10084bc5c <_js_json_stringify_full+0x15dc>
10084b14c:     	mov	w10, #0x72              ; =114
10084b150:     	b	0x10084bce4 <_js_json_stringify_full+0x1664>
10084b154:     	mov	x22, #0x0               ; =0
10084b158:     	mov	w24, #0x1               ; =1
10084b15c:     	stp	x22, x24, [sp, #0x10]
10084b160:     	str	x22, [sp, #0x20]
10084b164:     	cmp	x27, #0x2
10084b168:     	b.lo	0x10084b2a8 <_js_json_stringify_full+0xc28>
10084b16c:     	and	x25, x21, #0xffff000000000000
10084b170:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084b174:     	cmp	x25, x8
10084b178:     	b.ne	0x10084b284 <_js_json_stringify_full+0xc04>
10084b17c:     	and	x23, x21, #0xffffffffffff
10084b180:     	cmp	x23, #0x100, lsl #12    ; =0x100000
10084b184:     	b.lo	0x10084b2a8 <_js_json_stringify_full+0xc28>
10084b188:     	mov	x0, x23
10084b18c:     	bl	0x10050d500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
10084b190:     	tbnz	w0, #0x0, 0x10084b2a8 <_js_json_stringify_full+0xc28>
10084b194:     	lsr	x8, x23, #51
10084b198:     	cmp	x8, #0xfff
10084b19c:     	b.lo	0x10084b1b4 <_js_json_stringify_full+0xb34>
10084b1a0:     	mov	w8, #0x7ffc             ; =32764
10084b1a4:     	cmp	x8, x23, lsr #48
10084b1a8:     	b.eq	0x10084b2a8 <_js_json_stringify_full+0xc28>
10084b1ac:     	ands	x23, x23, #0xffffffffffff
10084b1b0:     	b.eq	0x10084b2a8 <_js_json_stringify_full+0xc28>
10084b1b4:     	and	x8, x23, #0xfffffffffff00000
10084b1b8:     	lsr	x9, x23, #47
10084b1bc:     	cmp	x9, #0x0
10084b1c0:     	ccmp	x8, #0x0, #0x4, eq
10084b1c4:     	b.eq	0x10084b2a8 <_js_json_stringify_full+0xc28>
10084b1c8:     	tst	x23, #0x3
10084b1cc:     	ccmp	x23, #0x7, #0x0, eq
10084b1d0:     	b.ls	0x10084bf14 <_js_json_stringify_full+0x1894>
10084b1d4:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084b1d8:     	ldr	x8, [x8, #0x48]
10084b1dc:     	cmn	x8, #0x1
10084b1e0:     	b.eq	0x10084be64 <_js_json_stringify_full+0x17e4>
10084b1e4:     	mrs	x9, TPIDRRO_EL0
10084b1e8:     	and	x9, x9, #0xfffffffffffffff8
10084b1ec:     	ldr	x0, [x9, x8, lsl #3]
10084b1f0:     	cbz	x0, 0x10084be64 <_js_json_stringify_full+0x17e4>
10084b1f4:     	lsr	x1, x23, #20
10084b1f8:     	ldr	x8, [x0, #0x10]
10084b1fc:     	ldrb	w9, [x8]
10084b200:     	cmp	w9, #0x2
10084b204:     	b.ne	0x10084be7c <_js_json_stringify_full+0x17fc>
10084b208:     	ldrb	w9, [x8, #0x88]
10084b20c:     	tbz	w9, #0x0, 0x10084b22c <_js_json_stringify_full+0xbac>
10084b210:     	ldr	x9, [x8, #0x80]
10084b214:     	cmp	x9, x1
10084b218:     	b.ne	0x10084b22c <_js_json_stringify_full+0xbac>
10084b21c:     	ldp	x9, x10, [x8, #0x60]
10084b220:     	cmp	x9, x23
10084b224:     	ccmp	x10, x23, #0x0, ls
10084b228:     	b.hi	0x10084be5c <_js_json_stringify_full+0x17dc>
10084b22c:     	ldrb	w9, [x8, #0xb8]
10084b230:     	cbz	w9, 0x10084b250 <_js_json_stringify_full+0xbd0>
10084b234:     	ldr	x9, [x8, #0xb0]
10084b238:     	cmp	x9, x1
10084b23c:     	b.ne	0x10084b250 <_js_json_stringify_full+0xbd0>
10084b240:     	ldp	x9, x10, [x8, #0x90]
10084b244:     	cmp	x9, x23
10084b248:     	ccmp	x10, x23, #0x0, ls
10084b24c:     	b.hi	0x10084c0e4 <_js_json_stringify_full+0x1a64>
10084b250:     	ldrb	w9, [x8, #0xe8]
10084b254:     	cbz	w9, 0x10084bc9c <_js_json_stringify_full+0x161c>
10084b258:     	ldr	x9, [x8, #0xe0]
10084b25c:     	cmp	x9, x1
10084b260:     	b.ne	0x10084bc9c <_js_json_stringify_full+0x161c>
10084b264:     	ldr	x9, [x8, #0xc0]
10084b268:     	cmp	x9, x23
10084b26c:     	b.hi	0x10084bc9c <_js_json_stringify_full+0x161c>
10084b270:     	ldr	x9, [x8, #0xc8]
10084b274:     	cmp	x9, x23
10084b278:     	b.ls	0x10084bc9c <_js_json_stringify_full+0x161c>
10084b27c:     	add	x9, x8, #0xc0
10084b280:     	b	0x10084c0e8 <_js_json_stringify_full+0x1a68>
10084b284:     	lsr	x8, x21, #52
10084b288:     	cbnz	x8, 0x10084b2a8 <_js_json_stringify_full+0xc28>
10084b28c:     	cbz	x21, 0x10084b2a8 <_js_json_stringify_full+0xc28>
10084b290:     	and	x8, x21, #0x7
10084b294:     	cbnz	x8, 0x10084b2a8 <_js_json_stringify_full+0xc28>
10084b298:     	mov	x0, x21
10084b29c:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084b2a0:     	mov	x23, x21
10084b2a4:     	cbnz	w0, 0x10084b180 <_js_json_stringify_full+0xb00>
10084b2a8:     	mov	x25, #-0x1              ; =-1
10084b2ac:     	str	x25, [sp, #0x30]
10084b2b0:     	mov	w24, #0x1               ; =1
10084b2b4:     	cmp	x27, #0x1
10084b2b8:     	cset	w8, hi
10084b2bc:     	tst	w8, w24
10084b2c0:     	b.eq	0x10084b334 <_js_json_stringify_full+0xcb4>
10084b2c4:     	and	x23, x21, #0xffff000000000000
10084b2c8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084b2cc:     	cmp	x23, x8
10084b2d0:     	b.ne	0x10084b30c <_js_json_stringify_full+0xc8c>
10084b2d4:     	and	x8, x21, #0xffffffffffff
10084b2d8:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084b2dc:     	b.lo	0x10084b334 <_js_json_stringify_full+0xcb4>
10084b2e0:     	ldr	w8, [x8, #0xc]
10084b2e4:     	mov	w9, #0x4f53             ; =20307
10084b2e8:     	movk	w9, #0x434c, lsl #16
10084b2ec:     	cmp	w8, w9
10084b2f0:     	b.ne	0x10084b334 <_js_json_stringify_full+0xcb4>
10084b2f4:     	and	x8, x21, #0xffffffffffff
10084b2f8:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084b2fc:     	cmp	x23, x9
10084b300:     	csel	x28, x8, x21, eq
10084b304:     	mov	w27, #0x1               ; =1
10084b308:     	b	0x10084b338 <_js_json_stringify_full+0xcb8>
10084b30c:     	lsr	x8, x21, #52
10084b310:     	cbnz	x8, 0x10084b334 <_js_json_stringify_full+0xcb4>
10084b314:     	mov	w27, #0x0               ; =0
10084b318:     	cbz	x21, 0x10084b338 <_js_json_stringify_full+0xcb8>
10084b31c:     	and	x8, x21, #0x7
10084b320:     	cbnz	x8, 0x10084b338 <_js_json_stringify_full+0xcb8>
10084b324:     	mov	x0, x21
10084b328:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084b32c:     	mov	x8, x21
10084b330:     	tbnz	w0, #0x0, 0x10084b2d8 <_js_json_stringify_full+0xc58>
10084b334:     	mov	w27, #0x0               ; =0
10084b338:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b33c:     	add	x0, x0, #0xd78
10084b340:     	ldr	x8, [x0]
10084b344:     	blr	x8
10084b348:     	mov	x21, x0
10084b34c:     	ldr	w26, [x0]
10084b350:     	add	w8, w26, #0x1
10084b354:     	str	w8, [x0]
10084b358:     	cbz	w26, 0x10084b3c8 <_js_json_stringify_full+0xd48>
10084b35c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b360:     	add	x0, x0, #0xd00
10084b364:     	ldr	x8, [x0]
10084b368:     	blr	x8
10084b36c:     	ldrb	w8, [x0, #0x20]
10084b370:     	cmp	w8, #0x1
10084b374:     	b.ne	0x10084c154 <_js_json_stringify_full+0x1ad4>
10084b378:     	ldr	x8, [x0]
10084b37c:     	cbnz	x8, 0x10084c160 <_js_json_stringify_full+0x1ae0>
10084b380:     	mov	x8, #-0x1               ; =-1
10084b384:     	str	x8, [x0]
10084b388:     	ldr	x23, [x0, #0x18]
10084b38c:     	ldr	x8, [x0, #0x8]
10084b390:     	cmp	x23, x8
10084b394:     	b.eq	0x10084bb50 <_js_json_stringify_full+0x14d0>
10084b398:     	ldr	x8, [x0, #0x10]
10084b39c:     	mov	w9, #0x18               ; =24
10084b3a0:     	madd	x8, x23, x9, x8
10084b3a4:     	mov	w9, #0x8                ; =8
10084b3a8:     	stp	xzr, x9, [x8]
10084b3ac:     	str	xzr, [x8, #0x10]
10084b3b0:     	add	x8, x23, #0x1
10084b3b4:     	str	x8, [x0, #0x18]
10084b3b8:     	ldr	x8, [x0]
10084b3bc:     	add	x8, x8, #0x1
10084b3c0:     	str	x8, [x0]
10084b3c4:     	b	0x10084b430 <_js_json_stringify_full+0xdb0>
10084b3c8:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b3cc:     	add	x0, x0, #0xdc0
10084b3d0:     	ldr	x8, [x0]
10084b3d4:     	blr	x8
10084b3d8:     	strb	wzr, [x0]
10084b3dc:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b3e0:     	add	x0, x0, #0xdf0
10084b3e4:     	ldr	x8, [x0]
10084b3e8:     	blr	x8
10084b3ec:     	strb	wzr, [x0]
10084b3f0:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
10084b3f4:     	ldr	w23, [x8, #0x5a8]
10084b3f8:     	cmp	w23, #0x300
10084b3fc:     	b.hs	0x10084bb98 <_js_json_stringify_full+0x1518>
10084b400:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084b404:     	ldr	x8, [x8, #0x48]
10084b408:     	cmn	x8, #0x1
10084b40c:     	b.eq	0x10084bb88 <_js_json_stringify_full+0x1508>
10084b410:     	mrs	x9, TPIDRRO_EL0
10084b414:     	and	x9, x9, #0xfffffffffffffff8
10084b418:     	ldr	x0, [x9, x8, lsl #3]
10084b41c:     	cbz	x0, 0x10084bb88 <_js_json_stringify_full+0x1508>
10084b420:     	add	x8, x0, x23, lsl #3
10084b424:     	ldr	x0, [x8, #0x1e8]
10084b428:     	cbz	x0, 0x10084bb98 <_js_json_stringify_full+0x1518>
10084b42c:     	str	xzr, [x0]
10084b430:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b434:     	add	x0, x0, #0xd30
10084b438:     	ldr	x8, [x0]
10084b43c:     	blr	x8
10084b440:     	mov	x23, x0
10084b444:     	ldrb	w8, [x0, #0x18]
10084b448:     	cmp	w8, #0x1
10084b44c:     	b.ne	0x10084c108 <_js_json_stringify_full+0x1a88>
10084b450:     	ldr	x8, [x0]
10084b454:     	mov	x9, #-0x1               ; =-1
10084b458:     	str	x9, [x0]
10084b45c:     	cmn	x8, #0x2
10084b460:     	b.eq	0x10084c290 <_js_json_stringify_full+0x1c10>
10084b464:     	cmn	x8, #0x1
10084b468:     	b.eq	0x10084b53c <_js_json_stringify_full+0xebc>
10084b46c:     	add	x9, sp, #0x48
10084b470:     	ldur	q0, [x0, #0x8]
10084b474:     	stur	q0, [x9, #0x8]
10084b478:     	str	x8, [sp, #0x48]
10084b47c:     	tbz	w24, #0x0, 0x10084b550 <_js_json_stringify_full+0xed0>
10084b480:     	tbz	w27, #0x0, 0x10084b638 <_js_json_stringify_full+0xfb8>
10084b484:     	bl	0x10028ddd8 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
10084b488:     	str	x0, [sp, #0x60]
10084b48c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084b490:     	stp	x28, x8, [sp, #0x88]
10084b494:     	mov	w8, #0x1                ; =1
10084b498:     	str	x8, [sp, #0x80]
10084b49c:     	add	x0, sp, #0x80
10084b4a0:     	bl	0x10028dee0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
10084b4a4:     	mov	x22, x0
10084b4a8:     	str	x0, [sp, #0x68]
10084b4ac:     	mov	w0, #0x0                ; =0
10084b4b0:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084b4b4:     	stp	xzr, xzr, [x0]
10084b4b8:     	str	wzr, [x0, #0x10]
10084b4bc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10084b4c0:     	bfxil	x8, x0, #0, #48
10084b4c4:     	fmov	d0, x8
10084b4c8:     	bl	0x10020b024 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
10084b4cc:     	mov	x19, x0
10084b4d0:     	adrp	x24, 0x100f84000 <_perry_global_worker_ts__1>
10084b4d4:     	ldr	x8, [x24, #0x48]
10084b4d8:     	cmn	x8, #0x1
10084b4dc:     	b.eq	0x10084b69c <_js_json_stringify_full+0x101c>
10084b4e0:     	mrs	x9, TPIDRRO_EL0
10084b4e4:     	and	x9, x9, #0xfffffffffffffff8
10084b4e8:     	ldr	x8, [x9, x8, lsl #3]
10084b4ec:     	cbz	x8, 0x10084b69c <_js_json_stringify_full+0x101c>
10084b4f0:     	ldr	x8, [x8, #0x19e8]
10084b4f4:     	cbz	x8, 0x10084b69c <_js_json_stringify_full+0x101c>
10084b4f8:     	ldr	x9, [x8]
10084b4fc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084b500:     	cmp	x9, x10
10084b504:     	b.hs	0x10084c1dc <_js_json_stringify_full+0x1b5c>
10084b508:     	add	x10, x9, #0x1
10084b50c:     	str	x10, [x8]
10084b510:     	ldr	x10, [x8, #0x18]
10084b514:     	cmp	x19, x10
10084b518:     	b.hs	0x10084c1e8 <_js_json_stringify_full+0x1b68>
10084b51c:     	ldr	x10, [x8, #0x10]
10084b520:     	mov	w11, #0x18              ; =24
10084b524:     	madd	x10, x19, x11, x10
10084b528:     	ldr	x11, [x10]
10084b52c:     	cbnz	x11, 0x10084c248 <_js_json_stringify_full+0x1bc8>
10084b530:     	ldr	x0, [x10, #0x8]
10084b534:     	str	x9, [x8]
10084b538:     	b	0x10084b6a4 <_js_json_stringify_full+0x1024>
10084b53c:     	mov	x8, #0x0                ; =0
10084b540:     	mov	w9, #0x1                ; =1
10084b544:     	stp	x9, xzr, [sp, #0x50]
10084b548:     	str	x8, [sp, #0x48]
10084b54c:     	tbnz	w24, #0x0, 0x10084b480 <_js_json_stringify_full+0xe00>
10084b550:     	cmp	x22, #0x0
10084b554:     	cset	w6, ne
10084b558:     	ldp	x0, x1, [sp, #0x38]
10084b55c:     	ldp	x3, x4, [sp, #0x18]
10084b560:     	add	x2, sp, #0x48
10084b564:     	mov.16b	v0, v8
10084b568:     	mov	x5, #0x0                ; =0
10084b56c:     	bl	0x100505a40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
10084b570:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b574:     	add	x0, x0, #0xd90
10084b578:     	ldr	x8, [x0]
10084b57c:     	blr	x8
10084b580:     	ldrb	w8, [x0, #0x20]
10084b584:     	cbnz	w8, 0x10084c16c <_js_json_stringify_full+0x1aec>
10084b588:     	ldr	x8, [x0]
10084b58c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10084b590:     	cmp	x8, x9
10084b594:     	b.hs	0x10084c19c <_js_json_stringify_full+0x1b1c>
10084b598:     	ldr	x9, [x0, #0x18]
10084b59c:     	cbz	x9, 0x10084b5a8 <_js_json_stringify_full+0xf28>
10084b5a0:     	cbnz	x8, 0x10084c1a8 <_js_json_stringify_full+0x1b28>
10084b5a4:     	str	xzr, [x0, #0x18]
10084b5a8:     	ldp	x0, x1, [sp, #0x50]
10084b5ac:     	cmp	x1, #0x5
10084b5b0:     	b.hi	0x10084b618 <_js_json_stringify_full+0xf98>
10084b5b4:     	cbz	x1, 0x10084b828 <_js_json_stringify_full+0x11a8>
10084b5b8:     	ldrsb	w8, [x0]
10084b5bc:     	tbnz	w8, #0x1f, 0x10084b618 <_js_json_stringify_full+0xf98>
10084b5c0:     	cmp	x1, #0x1
10084b5c4:     	b.eq	0x10084b600 <_js_json_stringify_full+0xf80>
10084b5c8:     	ldrsb	w8, [x0, #0x1]
10084b5cc:     	tbnz	w8, #0x1f, 0x10084b618 <_js_json_stringify_full+0xf98>
10084b5d0:     	cmp	x1, #0x2
10084b5d4:     	b.eq	0x10084b600 <_js_json_stringify_full+0xf80>
10084b5d8:     	ldrsb	w8, [x0, #0x2]
10084b5dc:     	tbnz	w8, #0x1f, 0x10084b618 <_js_json_stringify_full+0xf98>
10084b5e0:     	cmp	x1, #0x3
10084b5e4:     	b.eq	0x10084b600 <_js_json_stringify_full+0xf80>
10084b5e8:     	ldrsb	w8, [x0, #0x3]
10084b5ec:     	tbnz	w8, #0x1f, 0x10084b618 <_js_json_stringify_full+0xf98>
10084b5f0:     	cmp	x1, #0x4
10084b5f4:     	b.eq	0x10084b600 <_js_json_stringify_full+0xf80>
10084b5f8:     	ldrsb	w8, [x0, #0x4]
10084b5fc:     	tbnz	w8, #0x1f, 0x10084b618 <_js_json_stringify_full+0xf98>
10084b600:     	cmp	x1, #0x4
10084b604:     	b.hs	0x10084b968 <_js_json_stringify_full+0x12e8>
10084b608:     	mov	x10, #0x0               ; =0
10084b60c:     	mov	x9, #0x0                ; =0
10084b610:     	mov	x8, x0
10084b614:     	b	0x10084b9f8 <_js_json_stringify_full+0x1378>
10084b618:     	bl	0x10032c848 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
10084b61c:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
10084b620:     	bfxil	x20, x0, #0, #48
10084b624:     	ldp	x22, x0, [sp, #0x48]
10084b628:     	ldrb	w8, [x23, #0x18]
10084b62c:     	cmp	w8, #0x1
10084b630:     	b.eq	0x10084ba34 <_js_json_stringify_full+0x13b4>
10084b634:     	b	0x10084c138 <_js_json_stringify_full+0x1ab8>
10084b638:     	mov	w0, #0x0                ; =0
10084b63c:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084b640:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10084b644:     	bfxil	x8, x0, #0, #48
10084b648:     	fmov	d1, x8
10084b64c:     	stp	xzr, xzr, [x0]
10084b650:     	str	wzr, [x0, #0x10]
10084b654:     	mov.16b	v0, v8
10084b658:     	bl	0x1006cab20 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
10084b65c:     	mov.16b	v8, v0
10084b660:     	fmov	x24, d8
10084b664:     	cmp	x24, x20
10084b668:     	b.eq	0x10084b8b0 <_js_json_stringify_full+0x1230>
10084b66c:     	mov	w8, #0x7ffd             ; =32765
10084b670:     	cmp	x8, x24, lsr #48
10084b674:     	b.ne	0x10084b880 <_js_json_stringify_full+0x1200>
10084b678:     	and	x8, x24, #0xffffffffffff
10084b67c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084b680:     	b.lo	0x10084b8a4 <_js_json_stringify_full+0x1224>
10084b684:     	ldr	w8, [x8, #0xc]
10084b688:     	mov	w9, #0x4f53             ; =20307
10084b68c:     	movk	w9, #0x434c, lsl #16
10084b690:     	cmp	w8, w9
10084b694:     	b.ne	0x10084b8a4 <_js_json_stringify_full+0x1224>
10084b698:     	b	0x10084b8b0 <_js_json_stringify_full+0x1230>
10084b69c:     	mov	x0, x19
10084b6a0:     	bl	0x10013c270 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
10084b6a4:     	fmov	d1, x0
10084b6a8:     	mov.16b	v0, v8
10084b6ac:     	bl	0x1006cab20 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
10084b6b0:     	mov.16b	v8, v0
10084b6b4:     	ldr	x8, [x24, #0x48]
10084b6b8:     	cmn	x8, #0x1
10084b6bc:     	b.eq	0x10084b720 <_js_json_stringify_full+0x10a0>
10084b6c0:     	mrs	x9, TPIDRRO_EL0
10084b6c4:     	and	x9, x9, #0xfffffffffffffff8
10084b6c8:     	ldr	x8, [x9, x8, lsl #3]
10084b6cc:     	cbz	x8, 0x10084b720 <_js_json_stringify_full+0x10a0>
10084b6d0:     	ldr	x8, [x8, #0x19e8]
10084b6d4:     	cbz	x8, 0x10084b720 <_js_json_stringify_full+0x10a0>
10084b6d8:     	ldr	x9, [x8]
10084b6dc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084b6e0:     	cmp	x9, x10
10084b6e4:     	b.hs	0x10084c1dc <_js_json_stringify_full+0x1b5c>
10084b6e8:     	add	x10, x9, #0x1
10084b6ec:     	str	x10, [x8]
10084b6f0:     	ldr	x10, [x8, #0x18]
10084b6f4:     	cmp	x22, x10
10084b6f8:     	b.hs	0x10084c1e8 <_js_json_stringify_full+0x1b68>
10084b6fc:     	ldr	x10, [x8, #0x10]
10084b700:     	mov	w11, #0x18              ; =24
10084b704:     	madd	x10, x22, x11, x10
10084b708:     	ldr	x11, [x10]
10084b70c:     	cmp	x11, #0x1
10084b710:     	b.ne	0x10084c2a8 <_js_json_stringify_full+0x1c28>
10084b714:     	ldr	x22, [x10, #0x8]
10084b718:     	str	x9, [x8]
10084b71c:     	b	0x10084b72c <_js_json_stringify_full+0x10ac>
10084b720:     	mov	x0, x22
10084b724:     	bl	0x10013c198 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
10084b728:     	mov	x22, x0
10084b72c:     	ldr	x8, [x24, #0x48]
10084b730:     	cmn	x8, #0x1
10084b734:     	b.eq	0x10084b794 <_js_json_stringify_full+0x1114>
10084b738:     	mrs	x9, TPIDRRO_EL0
10084b73c:     	and	x9, x9, #0xfffffffffffffff8
10084b740:     	ldr	x8, [x9, x8, lsl #3]
10084b744:     	cbz	x8, 0x10084b794 <_js_json_stringify_full+0x1114>
10084b748:     	ldr	x8, [x8, #0x19e8]
10084b74c:     	cbz	x8, 0x10084b794 <_js_json_stringify_full+0x1114>
10084b750:     	ldr	x9, [x8]
10084b754:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084b758:     	cmp	x9, x10
10084b75c:     	b.hs	0x10084c1dc <_js_json_stringify_full+0x1b5c>
10084b760:     	add	x10, x9, #0x1
10084b764:     	str	x10, [x8]
10084b768:     	ldr	x10, [x8, #0x18]
10084b76c:     	cmp	x19, x10
10084b770:     	b.hs	0x10084c1e8 <_js_json_stringify_full+0x1b68>
10084b774:     	ldr	x10, [x8, #0x10]
10084b778:     	mov	w11, #0x18              ; =24
10084b77c:     	madd	x10, x19, x11, x10
10084b780:     	ldr	x11, [x10]
10084b784:     	cbnz	x11, 0x10084c248 <_js_json_stringify_full+0x1bc8>
10084b788:     	ldr	x0, [x10, #0x8]
10084b78c:     	str	x9, [x8]
10084b790:     	b	0x10084b79c <_js_json_stringify_full+0x111c>
10084b794:     	mov	x0, x19
10084b798:     	bl	0x10013c270 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
10084b79c:     	fmov	d9, x0
10084b7a0:     	mov.16b	v0, v8
10084b7a4:     	bl	0x1005023e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
10084b7a8:     	mov.16b	v2, v0
10084b7ac:     	mov	x0, x22
10084b7b0:     	mov.16b	v0, v9
10084b7b4:     	mov.16b	v1, v8
10084b7b8:     	bl	0x1005026c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
10084b7bc:     	str	d0, [sp, #0x70]
10084b7c0:     	fmov	x19, d0
10084b7c4:     	cmp	x19, x20
10084b7c8:     	b.ne	0x10084b830 <_js_json_stringify_full+0x11b0>
10084b7cc:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b7d0:     	add	x0, x0, #0xd90
10084b7d4:     	ldr	x8, [x0]
10084b7d8:     	blr	x8
10084b7dc:     	ldrb	w8, [x0, #0x20]
10084b7e0:     	cbnz	w8, 0x10084c288 <_js_json_stringify_full+0x1c08>
10084b7e4:     	ldr	x8, [x0]
10084b7e8:     	cbnz	x8, 0x10084c2d8 <_js_json_stringify_full+0x1c58>
10084b7ec:     	str	xzr, [x0, #0x18]
10084b7f0:     	ldp	x22, x19, [sp, #0x48]
10084b7f4:     	ldrb	w8, [x23, #0x18]
10084b7f8:     	cmp	w8, #0x1
10084b7fc:     	b.ne	0x10084c220 <_js_json_stringify_full+0x1ba0>
10084b800:     	ldp	x8, x0, [x23]
10084b804:     	stp	x22, x19, [x23]
10084b808:     	str	xzr, [x23, #0x10]
10084b80c:     	sub	x8, x8, #0x1
10084b810:     	cmn	x8, #0x2
10084b814:     	b.hs	0x10084b81c <_js_json_stringify_full+0x119c>
10084b818:     	bl	0x100b64100 <_mi_free>
10084b81c:     	cbz	w26, 0x10084babc <_js_json_stringify_full+0x143c>
10084b820:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b824:     	b	0x10084bac0 <_js_json_stringify_full+0x1440>
10084b828:     	mov	x10, #0x0               ; =0
10084b82c:     	b	0x10084ba18 <_js_json_stringify_full+0x1398>
10084b830:     	add	x0, sp, #0x48
10084b834:     	bl	0x1005030a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
10084b838:     	tbnz	w0, #0x0, 0x10084b874 <_js_json_stringify_full+0x11f4>
10084b83c:     	mov	x0, x19
10084b840:     	bl	0x10032a7ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
10084b844:     	cmp	x0, #0x1
10084b848:     	b.ne	0x10084c29c <_js_json_stringify_full+0x1c1c>
10084b84c:     	add	x8, sp, #0x78
10084b850:     	add	x9, sp, #0x70
10084b854:     	stp	x1, x8, [sp, #0x78]
10084b858:     	str	x9, [sp, #0x88]
10084b85c:     	add	x8, sp, #0x48
10084b860:     	add	x9, sp, #0x10
10084b864:     	stp	x8, x9, [sp, #0x90]
10084b868:     	add	x0, sp, #0x68
10084b86c:     	add	x1, sp, #0x80
10084b870:     	bl	0x100143c90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
10084b874:     	add	x0, sp, #0x60
10084b878:     	bl	0x100166d7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
10084b87c:     	b	0x10084b570 <_js_json_stringify_full+0xef0>
10084b880:     	lsr	x8, x24, #52
10084b884:     	cbnz	x8, 0x10084b8a4 <_js_json_stringify_full+0x1224>
10084b888:     	cbz	x24, 0x10084b8a4 <_js_json_stringify_full+0x1224>
10084b88c:     	and	x8, x24, #0x7
10084b890:     	cbnz	x8, 0x10084b8a4 <_js_json_stringify_full+0x1224>
10084b894:     	mov	x0, x24
10084b898:     	bl	0x100511ff8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084b89c:     	mov	x8, x24
10084b8a0:     	tbnz	w0, #0x0, 0x10084b67c <_js_json_stringify_full+0xffc>
10084b8a4:     	mov	x0, x24
10084b8a8:     	bl	0x10050c374 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
10084b8ac:     	tbz	w0, #0x0, 0x10084b93c <_js_json_stringify_full+0x12bc>
10084b8b0:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b8b4:     	add	x0, x0, #0xd90
10084b8b8:     	ldr	x8, [x0]
10084b8bc:     	blr	x8
10084b8c0:     	ldrb	w8, [x0, #0x20]
10084b8c4:     	cbnz	w8, 0x10084c1ec <_js_json_stringify_full+0x1b6c>
10084b8c8:     	ldr	x8, [x0]
10084b8cc:     	cbnz	x8, 0x10084c214 <_js_json_stringify_full+0x1b94>
10084b8d0:     	str	xzr, [x0, #0x18]
10084b8d4:     	ldp	x22, x19, [sp, #0x48]
10084b8d8:     	ldrb	w8, [x23, #0x18]
10084b8dc:     	cmp	w8, #0x1
10084b8e0:     	b.ne	0x10084c1c8 <_js_json_stringify_full+0x1b48>
10084b8e4:     	ldp	x8, x0, [x23]
10084b8e8:     	stp	x22, x19, [x23]
10084b8ec:     	str	xzr, [x23, #0x10]
10084b8f0:     	sub	x8, x8, #0x1
10084b8f4:     	cmn	x8, #0x2
10084b8f8:     	b.hs	0x10084b900 <_js_json_stringify_full+0x1280>
10084b8fc:     	bl	0x100b64100 <_mi_free>
10084b900:     	cbz	w26, 0x10084b920 <_js_json_stringify_full+0x12a0>
10084b904:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b908:     	ldr	w8, [x21]
10084b90c:     	sub	w8, w8, #0x1
10084b910:     	str	w8, [x21]
10084b914:     	cmn	x25, #0x1
10084b918:     	b.ne	0x10084badc <_js_json_stringify_full+0x145c>
10084b91c:     	b	0x10084bb18 <_js_json_stringify_full+0x1498>
10084b920:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b924:     	ldr	w8, [x21]
10084b928:     	sub	w8, w8, #0x1
10084b92c:     	str	w8, [x21]
10084b930:     	cmn	x25, #0x1
10084b934:     	b.ne	0x10084badc <_js_json_stringify_full+0x145c>
10084b938:     	b	0x10084bb18 <_js_json_stringify_full+0x1498>
10084b93c:     	cmp	x19, x24
10084b940:     	b.eq	0x10084b94c <_js_json_stringify_full+0x12cc>
10084b944:     	mov.16b	v0, v8
10084b948:     	bl	0x10051172c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
10084b94c:     	cbz	x22, 0x10084bba8 <_js_json_stringify_full+0x1528>
10084b950:     	ldp	x1, x2, [sp, #0x18]
10084b954:     	add	x0, sp, #0x48
10084b958:     	mov.16b	v0, v8
10084b95c:     	mov	x3, #0x0                ; =0
10084b960:     	bl	0x100503b1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
10084b964:     	b	0x10084bbb8 <_js_json_stringify_full+0x1538>
10084b968:     	and	x9, x1, #0x4
10084b96c:     	add	x8, x0, x9
10084b970:     	adrp	x10, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4bf0>
10084b974:     	ldr	q0, [x10, #0xc80]
10084b978:     	adrp	x10, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x334fa>
10084b97c:     	ldr	q2, [x10, #0xa80]
10084b980:     	movi.2d	v1, #0000000000000000
10084b984:     	movi.2d	v3, #0x000000000000ff
10084b988:     	mov	w10, #0x4               ; =4
10084b98c:     	dup.2d	v4, x10
10084b990:     	mov	x10, x0
10084b994:     	and	x11, x1, #0x4
10084b998:     	movi.2d	v5, #0000000000000000
10084b99c:     	ldr	s6, [x10], #0x4
10084b9a0:     	ushll.8h	v6, v6, #0x0
10084b9a4:     	ushll.4s	v6, v6, #0x0
10084b9a8:     	ushll2.2d	v7, v6, #0x0
10084b9ac:     	and.16b	v7, v7, v3
10084b9b0:     	ushll.2d	v6, v6, #0x0
10084b9b4:     	and.16b	v6, v6, v3
10084b9b8:     	shl.2d	v16, v0, #0x3
10084b9bc:     	shl.2d	v17, v2, #0x3
10084b9c0:     	ushl.2d	v6, v6, v17
10084b9c4:     	ushl.2d	v7, v7, v16
10084b9c8:     	orr.16b	v1, v7, v1
10084b9cc:     	orr.16b	v5, v6, v5
10084b9d0:     	add.2d	v0, v0, v4
10084b9d4:     	add.2d	v2, v2, v4
10084b9d8:     	subs	x11, x11, #0x4
10084b9dc:     	b.ne	0x10084b99c <_js_json_stringify_full+0x131c>
10084b9e0:     	orr.16b	v0, v5, v1
10084b9e4:     	mov	d1, v0[1]
10084b9e8:     	orr.8b	v0, v0, v1
10084b9ec:     	fmov	x10, d0
10084b9f0:     	cmp	x1, x9
10084b9f4:     	b.eq	0x10084ba18 <_js_json_stringify_full+0x1398>
10084b9f8:     	add	x11, x0, x1
10084b9fc:     	lsl	x9, x9, #3
10084ba00:     	ldrb	w12, [x8], #0x1
10084ba04:     	lsl	x12, x12, x9
10084ba08:     	orr	x10, x12, x10
10084ba0c:     	add	x9, x9, #0x8
10084ba10:     	cmp	x8, x11
10084ba14:     	b.ne	0x10084ba00 <_js_json_stringify_full+0x1380>
10084ba18:     	orr	x8, x10, x1, lsl #40
10084ba1c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084ba20:     	orr	x20, x8, x9
10084ba24:     	ldr	x22, [sp, #0x48]
10084ba28:     	ldrb	w8, [x23, #0x18]
10084ba2c:     	cmp	w8, #0x1
10084ba30:     	b.ne	0x10084c138 <_js_json_stringify_full+0x1ab8>
10084ba34:     	ldp	x9, x8, [x23]
10084ba38:     	stp	x22, x0, [x23]
10084ba3c:     	str	xzr, [x23, #0x10]
10084ba40:     	sub	x9, x9, #0x1
10084ba44:     	cmn	x9, #0x2
10084ba48:     	b.hs	0x10084ba54 <_js_json_stringify_full+0x13d4>
10084ba4c:     	mov	x0, x8
10084ba50:     	bl	0x100b64100 <_mi_free>
10084ba54:     	cbz	w26, 0x10084ba74 <_js_json_stringify_full+0x13f4>
10084ba58:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084ba5c:     	ldr	w8, [x21]
10084ba60:     	sub	w8, w8, #0x1
10084ba64:     	str	w8, [x21]
10084ba68:     	cmn	x25, #0x1
10084ba6c:     	b.ne	0x10084ba8c <_js_json_stringify_full+0x140c>
10084ba70:     	b	0x10084bb18 <_js_json_stringify_full+0x1498>
10084ba74:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084ba78:     	ldr	w8, [x21]
10084ba7c:     	sub	w8, w8, #0x1
10084ba80:     	str	w8, [x21]
10084ba84:     	cmn	x25, #0x1
10084ba88:     	b.eq	0x10084bb18 <_js_json_stringify_full+0x1498>
10084ba8c:     	ldp	x19, x21, [sp, #0x38]
10084ba90:     	cbz	x21, 0x10084bb0c <_js_json_stringify_full+0x148c>
10084ba94:     	add	x22, x19, #0x8
10084ba98:     	b	0x10084baa8 <_js_json_stringify_full+0x1428>
10084ba9c:     	add	x22, x22, #0x18
10084baa0:     	subs	x21, x21, #0x1
10084baa4:     	b.eq	0x10084bb0c <_js_json_stringify_full+0x148c>
10084baa8:     	ldur	x8, [x22, #-0x8]
10084baac:     	cbz	x8, 0x10084ba9c <_js_json_stringify_full+0x141c>
10084bab0:     	ldr	x0, [x22]
10084bab4:     	bl	0x100b64100 <_mi_free>
10084bab8:     	b	0x10084ba9c <_js_json_stringify_full+0x141c>
10084babc:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084bac0:     	ldr	w8, [x21]
10084bac4:     	sub	w8, w8, #0x1
10084bac8:     	str	w8, [x21]
10084bacc:     	add	x0, sp, #0x60
10084bad0:     	bl	0x100166d7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
10084bad4:     	cmn	x25, #0x1
10084bad8:     	b.eq	0x10084bb18 <_js_json_stringify_full+0x1498>
10084badc:     	ldp	x19, x21, [sp, #0x38]
10084bae0:     	cbz	x21, 0x10084bb0c <_js_json_stringify_full+0x148c>
10084bae4:     	add	x22, x19, #0x8
10084bae8:     	b	0x10084baf8 <_js_json_stringify_full+0x1478>
10084baec:     	add	x22, x22, #0x18
10084baf0:     	subs	x21, x21, #0x1
10084baf4:     	b.eq	0x10084bb0c <_js_json_stringify_full+0x148c>
10084baf8:     	ldur	x8, [x22, #-0x8]
10084bafc:     	cbz	x8, 0x10084baec <_js_json_stringify_full+0x146c>
10084bb00:     	ldr	x0, [x22]
10084bb04:     	bl	0x100b64100 <_mi_free>
10084bb08:     	b	0x10084baec <_js_json_stringify_full+0x146c>
10084bb0c:     	cbz	x25, 0x10084bb18 <_js_json_stringify_full+0x1498>
10084bb10:     	mov	x0, x19
10084bb14:     	bl	0x100b64100 <_mi_free>
10084bb18:     	ldr	x8, [sp, #0x10]
10084bb1c:     	cbz	x8, 0x10084bb28 <_js_json_stringify_full+0x14a8>
10084bb20:     	ldr	x0, [sp, #0x18]
10084bb24:     	bl	0x100b64100 <_mi_free>
10084bb28:     	mov	x0, x20
10084bb2c:     	ldp	x29, x30, [sp, #0x110]
10084bb30:     	ldp	x20, x19, [sp, #0x100]
10084bb34:     	ldp	x22, x21, [sp, #0xf0]
10084bb38:     	ldp	x24, x23, [sp, #0xe0]
10084bb3c:     	ldp	x26, x25, [sp, #0xd0]
10084bb40:     	ldp	x28, x27, [sp, #0xc0]
10084bb44:     	ldp	d9, d8, [sp, #0xb0]
10084bb48:     	add	sp, sp, #0x120
10084bb4c:     	ret
10084bb50:     	str	x22, [sp, #0x8]
10084bb54:     	mov	x22, x28
10084bb58:     	mov	x28, x0
10084bb5c:     	add	x0, x0, #0x8
10084bb60:     	bl	0x100b40e50 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10084bb64:     	mov	x0, x28
10084bb68:     	mov	x28, x22
10084bb6c:     	ldr	x22, [sp, #0x8]
10084bb70:     	b	0x10084b398 <_js_json_stringify_full+0xd18>
10084bb74:     	b.ne	0x10084b0dc <_js_json_stringify_full+0xa5c>
10084bb78:     	tbz	x25, #0x3f, 0x10084bbd0 <_js_json_stringify_full+0x1550>
10084bb7c:     	mov	x0, #0x0                ; =0
10084bb80:     	mov	x1, x25
10084bb84:     	bl	0x100b17480 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084bb88:     	bl	0x100b444fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084bb8c:     	add	x8, x0, x23, lsl #3
10084bb90:     	ldr	x0, [x8, #0x1e8]
10084bb94:     	cbnz	x0, 0x10084b42c <_js_json_stringify_full+0xdac>
10084bb98:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084bb9c:     	add	x0, x0, #0x138
10084bba0:     	bl	0x100b41d1c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084bba4:     	b	0x10084b42c <_js_json_stringify_full+0xdac>
10084bba8:     	add	x1, sp, #0x48
10084bbac:     	mov.16b	v0, v8
10084bbb0:     	mov	w0, #0x0                ; =0
10084bbb4:     	bl	0x10050c44c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
10084bbb8:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084bbbc:     	add	x0, x0, #0xdc0
10084bbc0:     	ldr	x8, [x0]
10084bbc4:     	blr	x8
10084bbc8:     	strb	wzr, [x0]
10084bbcc:     	b	0x10084b570 <_js_json_stringify_full+0xef0>
10084bbd0:     	mov	x0, x25
10084bbd4:     	mov	w1, #0x1                ; =1
10084bbd8:     	bl	0x100b64388 <_mi_malloc_aligned>
10084bbdc:     	mov	x26, x0
10084bbe0:     	mov	w0, #0x1                ; =1
10084bbe4:     	cbz	x26, 0x10084bb80 <_js_json_stringify_full+0x1500>
10084bbe8:     	mov	x0, x26
10084bbec:     	mov	x1, x23
10084bbf0:     	mov	x2, x25
10084bbf4:     	bl	0x100b66fac <_writev+0x100b66fac>
10084bbf8:     	mov	x22, x25
10084bbfc:     	b	0x10084b100 <_js_json_stringify_full+0xa80>
10084bc00:     	cmp	w11, #0x8
10084bc04:     	b.eq	0x10084bcd0 <_js_json_stringify_full+0x1650>
10084bc08:     	cmp	w11, #0x9
10084bc0c:     	b.eq	0x10084bce0 <_js_json_stringify_full+0x1660>
10084bc10:     	cmp	w11, #0xa
10084bc14:     	b.ne	0x10084bc5c <_js_json_stringify_full+0x15dc>
10084bc18:     	mov	w10, #0x6e              ; =110
10084bc1c:     	b	0x10084bce4 <_js_json_stringify_full+0x1664>
10084bc20:     	mov	x22, x0
10084bc24:     	and	x0, x19, #0xffffffffffff
10084bc28:     	bl	0x10034a600 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084bc2c:     	cbz	x0, 0x10084bd08 <_js_json_stringify_full+0x1688>
10084bc30:     	ldr	w20, [x0]
10084bc34:     	cmp	w20, #0x4
10084bc38:     	b.hi	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084bc3c:     	ldr	w8, [x0, #0x4]
10084bc40:     	cmp	w20, w8
10084bc44:     	b.hi	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084bc48:     	b	0x10084bd0c <_js_json_stringify_full+0x168c>
10084bc4c:     	cmp	w11, #0x22
10084bc50:     	b.eq	0x10084bce4 <_js_json_stringify_full+0x1664>
10084bc54:     	cmp	w11, #0x5c
10084bc58:     	b.eq	0x10084bce4 <_js_json_stringify_full+0x1664>
10084bc5c:     	cmp	x12, #0x3
10084bc60:     	mov	w11, #0x20              ; =32
10084bc64:     	ccmp	w10, w11, #0x8, ls
10084bc68:     	b.lt	0x10084ab94 <_js_json_stringify_full+0x514>
10084bc6c:     	add	x8, sp, #0x80
10084bc70:     	strb	w10, [x8, x12]
10084bc74:     	add	x12, x12, #0x1
10084bc78:     	b	0x10084a884 <_js_json_stringify_full+0x204>
10084bc7c:     	mov	x1, x0
10084bc80:     	and	x0, x19, #0xffffffffffff
10084bc84:     	mov	x22, x1
10084bc88:     	bl	0x1004fbb00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
10084bc8c:     	cmp	x0, #0x1
10084bc90:     	b.ne	0x10084bdb4 <_js_json_stringify_full+0x1734>
10084bc94:     	mov	x20, x1
10084bc98:     	b	0x10084bb28 <_js_json_stringify_full+0x14a8>
10084bc9c:     	ldrb	w9, [x8, #0x118]
10084bca0:     	cbz	w9, 0x10084bedc <_js_json_stringify_full+0x185c>
10084bca4:     	ldr	x9, [x8, #0x110]
10084bca8:     	cmp	x9, x1
10084bcac:     	b.ne	0x10084bedc <_js_json_stringify_full+0x185c>
10084bcb0:     	ldr	x9, [x8, #0xf0]
10084bcb4:     	cmp	x9, x23
10084bcb8:     	b.hi	0x10084bedc <_js_json_stringify_full+0x185c>
10084bcbc:     	ldr	x9, [x8, #0xf8]
10084bcc0:     	cmp	x9, x23
10084bcc4:     	b.ls	0x10084bedc <_js_json_stringify_full+0x185c>
10084bcc8:     	add	x9, x8, #0xf0
10084bccc:     	b	0x10084c0e8 <_js_json_stringify_full+0x1a68>
10084bcd0:     	mov	w10, #0x62              ; =98
10084bcd4:     	b	0x10084bce4 <_js_json_stringify_full+0x1664>
10084bcd8:     	mov	w10, #0x66              ; =102
10084bcdc:     	b	0x10084bce4 <_js_json_stringify_full+0x1664>
10084bce0:     	mov	w10, #0x74              ; =116
10084bce4:     	cmp	x12, #0x2
10084bce8:     	b.hi	0x10084ab94 <_js_json_stringify_full+0x514>
10084bcec:     	add	x8, sp, #0x80
10084bcf0:     	add	x8, x8, x12
10084bcf4:     	add	x12, x12, #0x2
10084bcf8:     	mov	w11, #0x5c              ; =92
10084bcfc:     	strb	w11, [x8]
10084bd00:     	strb	w10, [x8, #0x1]
10084bd04:     	b	0x10084a884 <_js_json_stringify_full+0x204>
10084bd08:     	mov	x20, #0x0               ; =0
10084bd0c:     	ldr	w8, [x22, #0x4]
10084bd10:     	lsl	x9, x20, #3
10084bd14:     	add	x9, x9, #0x18
10084bd18:     	cmp	x9, x8
10084bd1c:     	b.hi	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084bd20:     	ldr	w8, [x25, #0x4]
10084bd24:     	mov	w9, #-0x40000000        ; =-1073741824
10084bd28:     	cmp	w8, w9
10084bd2c:     	csel	w8, w8, wzr, lt
10084bd30:     	mov	x22, x0
10084bd34:     	mov	x0, x8
10084bd38:     	bl	0x1005e85a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084bd3c:     	mov	w9, #0x2                ; =2
10084bd40:     	cmp	w1, #0x2
10084bd44:     	csel	w10, w1, w9, hi
10084bd48:     	tst	w0, #0x1
10084bd4c:     	csel	x8, x10, x9, ne
10084bd50:     	cmp	x20, x8
10084bd54:     	b.hi	0x10084ac58 <_js_json_stringify_full+0x5d8>
10084bd58:     	cbz	x20, 0x10084c118 <_js_json_stringify_full+0x1a98>
10084bd5c:     	mov	x0, x22
10084bd60:     	mov	x1, x20
10084bd64:     	bl	0x1004f2a80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084bd68:     	tbz	w0, #0x0, 0x10084ac58 <_js_json_stringify_full+0x5d8>
10084bd6c:     	cmp	x20, #0x1
10084bd70:     	b.eq	0x10084c1b4 <_js_json_stringify_full+0x1b34>
10084bd74:     	cmp	x20, #0x2
10084bd78:     	b.ne	0x10084c270 <_js_json_stringify_full+0x1bf0>
10084bd7c:     	mov	x22, #0x0               ; =0
10084bd80:     	add	x25, x25, #0x10
10084bd84:     	mov	w8, #0x1                ; =1
10084bd88:     	mov	x26, x8
10084bd8c:     	ldr	x1, [x25, x22, lsl #3]
10084bd90:     	add	x0, sp, #0x80
10084bd94:     	bl	0x1004f2ad4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
10084bd98:     	ldr	w8, [sp, #0x80]
10084bd9c:     	cmn	w8, #0x1
10084bda0:     	b.ne	0x10084c258 <_js_json_stringify_full+0x1bd8>
10084bda4:     	mov	w8, #0x0                ; =0
10084bda8:     	mov	w22, #0x1               ; =1
10084bdac:     	tbnz	w26, #0x0, 0x10084bd88 <_js_json_stringify_full+0x1708>
10084bdb0:     	b	0x10084c270 <_js_json_stringify_full+0x1bf0>
10084bdb4:     	and	x0, x19, #0xffffffffffff
10084bdb8:     	bl	0x10034a600 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084bdbc:     	cbz	x0, 0x10084be48 <_js_json_stringify_full+0x17c8>
10084bdc0:     	ldr	w20, [x0]
10084bdc4:     	cbz	w20, 0x10084be48 <_js_json_stringify_full+0x17c8>
10084bdc8:     	cmp	w20, #0x8
10084bdcc:     	b.hi	0x10084ac24 <_js_json_stringify_full+0x5a4>
10084bdd0:     	ldr	w8, [x0, #0x4]
10084bdd4:     	cmp	w20, w8
10084bdd8:     	b.hi	0x10084ac24 <_js_json_stringify_full+0x5a4>
10084bddc:     	ldr	w8, [x22, #0x4]
10084bde0:     	lsl	x9, x20, #3
10084bde4:     	add	x9, x9, #0x18
10084bde8:     	cmp	x9, x8
10084bdec:     	b.hi	0x10084ac24 <_js_json_stringify_full+0x5a4>
10084bdf0:     	ldr	w8, [x25, #0x4]
10084bdf4:     	mov	w9, #-0x40000000        ; =-1073741824
10084bdf8:     	cmp	w8, w9
10084bdfc:     	csel	w8, w8, wzr, lt
10084be00:     	mov	x22, x0
10084be04:     	mov	x0, x8
10084be08:     	bl	0x1005e85a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084be0c:     	mov	w9, #0x2                ; =2
10084be10:     	cmp	w1, #0x2
10084be14:     	csel	w10, w1, w9, hi
10084be18:     	tst	w0, #0x1
10084be1c:     	csel	w8, w10, w9, ne
10084be20:     	cmp	w20, w8
10084be24:     	b.hi	0x10084ac24 <_js_json_stringify_full+0x5a4>
10084be28:     	mov	x0, x22
10084be2c:     	mov	x1, x20
10084be30:     	bl	0x1004f2a80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084be34:     	cbz	w0, 0x10084ac24 <_js_json_stringify_full+0x5a4>
10084be38:     	and	x0, x19, #0xffffffffffff
10084be3c:     	mov	x1, x20
10084be40:     	bl	0x1004fac40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
10084be44:     	b	0x10084be50 <_js_json_stringify_full+0x17d0>
10084be48:     	and	x0, x19, #0xffffffffffff
10084be4c:     	bl	0x1004fb9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
10084be50:     	mov	x20, x1
10084be54:     	tbz	w0, #0x0, 0x10084ac24 <_js_json_stringify_full+0x5a4>
10084be58:     	b	0x10084bb28 <_js_json_stringify_full+0x14a8>
10084be5c:     	add	x9, x8, #0x60
10084be60:     	b	0x10084c0e8 <_js_json_stringify_full+0x1a68>
10084be64:     	bl	0x100b444fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084be68:     	lsr	x1, x23, #20
10084be6c:     	ldr	x8, [x0, #0x10]
10084be70:     	ldrb	w9, [x8]
10084be74:     	cmp	w9, #0x2
10084be78:     	b.eq	0x10084b208 <_js_json_stringify_full+0xb88>
10084be7c:     	ldr	x9, [x8, #0x8]
10084be80:     	ldr	x10, [x8, #0x28]
10084be84:     	sub	x9, x1, x9
10084be88:     	cmp	x9, x10
10084be8c:     	b.hs	0x10084bed0 <_js_json_stringify_full+0x1850>
10084be90:     	ldr	x10, [x8, #0x20]
10084be94:     	mov	w11, #0x28              ; =40
10084be98:     	madd	x9, x9, x11, x10
10084be9c:     	ldr	x10, [x9]
10084bea0:     	ldr	x11, [x8, #0x10]
10084bea4:     	cmp	x10, x11
10084bea8:     	b.ne	0x10084bedc <_js_json_stringify_full+0x185c>
10084beac:     	ldp	x10, x11, [x9, #0x8]
10084beb0:     	cmp	x10, x23
10084beb4:     	ccmp	x11, x23, #0x0, ls
10084beb8:     	b.ls	0x10084bedc <_js_json_stringify_full+0x185c>
10084bebc:     	ldr	x10, [x8, #0x30]
10084bec0:     	add	x10, x10, #0x1
10084bec4:     	str	x10, [x8, #0x30]
10084bec8:     	add	x8, x9, #0x21
10084becc:     	b	0x10084c0f8 <_js_json_stringify_full+0x1a78>
10084bed0:     	ldr	x9, [x8, #0x58]
10084bed4:     	add	x9, x9, #0x1
10084bed8:     	str	x9, [x8, #0x58]
10084bedc:     	ldr	x9, [x8, #0x38]
10084bee0:     	add	x9, x9, #0x1
10084bee4:     	str	x9, [x8, #0x38]
10084bee8:     	mov	x0, x23
10084beec:     	bl	0x100521208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
10084bef0:     	and	w8, w0, #0xff
10084bef4:     	cbz	w8, 0x10084bf14 <_js_json_stringify_full+0x1894>
10084bef8:     	ldurb	w8, [x23, #-0x8]
10084befc:     	ldurb	w9, [x23, #-0x7]
10084bf00:     	mov	w10, #0x82              ; =130
10084bf04:     	and	w9, w9, w10
10084bf08:     	cmp	w9, #0x2
10084bf0c:     	ccmp	w8, #0x1, #0x0, eq
10084bf10:     	b.eq	0x10084bfa8 <_js_json_stringify_full+0x1928>
10084bf14:     	mov	x0, x23
10084bf18:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084bf1c:     	mov	x24, x0
10084bf20:     	cbz	x0, 0x10084bf4c <_js_json_stringify_full+0x18cc>
10084bf24:     	ldrb	w8, [x24]
10084bf28:     	cmp	w8, #0x1
10084bf2c:     	b.ne	0x10084bf6c <_js_json_stringify_full+0x18ec>
10084bf30:     	ldrsb	w8, [x24, #0x1]
10084bf34:     	tbnz	w8, #0x1f, 0x10084bfd0 <_js_json_stringify_full+0x1950>
10084bf38:     	mov	x0, x24
10084bf3c:     	ldp	w9, w8, [x23]
10084bf40:     	cmp	w9, w8
10084bf44:     	b.hi	0x10084c054 <_js_json_stringify_full+0x19d4>
10084bf48:     	b	0x10084c06c <_js_json_stringify_full+0x19ec>
10084bf4c:     	mov	x0, x23
10084bf50:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10084bf54:     	tbnz	w0, #0x0, 0x10084bf64 <_js_json_stringify_full+0x18e4>
10084bf58:     	mov	x0, x23
10084bf5c:     	bl	0x1002a6908 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
10084bf60:     	tbz	w0, #0x0, 0x10084b2a8 <_js_json_stringify_full+0xc28>
10084bf64:     	mov	x0, #0x0                ; =0
10084bf68:     	b	0x10084c044 <_js_json_stringify_full+0x19c4>
10084bf6c:     	mov	x0, x24
10084bf70:     	cmp	w8, #0x1
10084bf74:     	b.eq	0x10084c044 <_js_json_stringify_full+0x19c4>
10084bf78:     	cmp	w8, #0x9
10084bf7c:     	b.ne	0x10084b2a8 <_js_json_stringify_full+0xc28>
10084bf80:     	ldr	w8, [x23, #0x4]
10084bf84:     	mov	w9, #0x5841             ; =22593
10084bf88:     	movk	w9, #0x4c5a, lsl #16
10084bf8c:     	cmp	w8, w9
10084bf90:     	b.ne	0x10084b2a8 <_js_json_stringify_full+0xc28>
10084bf94:     	mov	x0, x23
10084bf98:     	bl	0x100378910 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
10084bf9c:     	mov	x23, x0
10084bfa0:     	cbnz	x0, 0x10084c094 <_js_json_stringify_full+0x1a14>
10084bfa4:     	b	0x10084b2a8 <_js_json_stringify_full+0xc28>
10084bfa8:     	ldr	w8, [x23]
10084bfac:     	mov	w9, #0xe100             ; =57600
10084bfb0:     	movk	w9, #0x5f5, lsl #16
10084bfb4:     	orr	w9, w9, #0x1
10084bfb8:     	cmp	w8, w9
10084bfbc:     	b.hs	0x10084bf14 <_js_json_stringify_full+0x1894>
10084bfc0:     	ldr	w9, [x23, #0x4]
10084bfc4:     	cmp	w8, w9
10084bfc8:     	b.ls	0x10084c094 <_js_json_stringify_full+0x1a14>
10084bfcc:     	b	0x10084bf14 <_js_json_stringify_full+0x1894>
10084bfd0:     	ldr	x23, [x24, #0x8]
10084bfd4:     	mov	x0, x23
10084bfd8:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084bfdc:     	cbz	x0, 0x10084b2a8 <_js_json_stringify_full+0xc28>
10084bfe0:     	ldrb	w8, [x0]
10084bfe4:     	cmp	w8, #0x1
10084bfe8:     	b.ne	0x10084b2a8 <_js_json_stringify_full+0xc28>
10084bfec:     	ldrsb	w8, [x0, #0x1]
10084bff0:     	tbz	w8, #0x1f, 0x10084bf3c <_js_json_stringify_full+0x18bc>
10084bff4:     	mov	w26, #0x1               ; =1
10084bff8:     	ldr	x23, [x0, #0x8]
10084bffc:     	mov	x0, x23
10084c000:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084c004:     	cbz	x0, 0x10084b2a8 <_js_json_stringify_full+0xc28>
10084c008:     	ldrb	w8, [x0]
10084c00c:     	cmp	w8, #0x1
10084c010:     	b.ne	0x10084b2a8 <_js_json_stringify_full+0xc28>
10084c014:     	cmp	w26, #0x3f
10084c018:     	b.hi	0x10084b2a8 <_js_json_stringify_full+0xc28>
10084c01c:     	add	w26, w26, #0x1
10084c020:     	ldrsb	w8, [x0, #0x1]
10084c024:     	tbnz	w8, #0x1f, 0x10084bff8 <_js_json_stringify_full+0x1978>
10084c028:     	str	x23, [x24, #0x8]
10084c02c:     	ldrb	w8, [x24, #0x1]
10084c030:     	orr	w8, w8, #0x80
10084c034:     	strb	w8, [x24, #0x1]
10084c038:     	ldrb	w8, [x0]
10084c03c:     	cmp	w8, #0x1
10084c040:     	b.ne	0x10084bf78 <_js_json_stringify_full+0x18f8>
10084c044:     	ldp	w9, w8, [x23]
10084c048:     	cmp	w9, w8
10084c04c:     	b.ls	0x10084c06c <_js_json_stringify_full+0x19ec>
10084c050:     	cbz	x24, 0x10084c07c <_js_json_stringify_full+0x19fc>
10084c054:     	ldr	w9, [x0, #0x4]
10084c058:     	ubfiz	x8, x8, #3, #32
10084c05c:     	add	x8, x8, #0x10
10084c060:     	cmp	x8, x9
10084c064:     	b.eq	0x10084c094 <_js_json_stringify_full+0x1a14>
10084c068:     	b	0x10084c07c <_js_json_stringify_full+0x19fc>
10084c06c:     	mov	w8, #0xe100             ; =57600
10084c070:     	movk	w8, #0x5f5, lsl #16
10084c074:     	cmp	w9, w8
10084c078:     	b.ls	0x10084c094 <_js_json_stringify_full+0x1a14>
10084c07c:     	mov	x0, x23
10084c080:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10084c084:     	tbnz	w0, #0x0, 0x10084c094 <_js_json_stringify_full+0x1a14>
10084c088:     	mov	x0, x23
10084c08c:     	bl	0x1002a6908 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
10084c090:     	tbz	w0, #0x0, 0x10084b2a8 <_js_json_stringify_full+0xc28>
10084c094:     	ldp	w8, w9, [x23]
10084c098:     	sub	w10, w9, #0x1
10084c09c:     	mov	w11, #0x270f            ; =9999
10084c0a0:     	cmp	w10, w11
10084c0a4:     	ccmp	w8, w9, #0x2, lo
10084c0a8:     	b.hi	0x10084b2a8 <_js_json_stringify_full+0xc28>
10084c0ac:     	and	x8, x21, #0xffffffffffff
10084c0b0:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084c0b4:     	cmp	x25, x9
10084c0b8:     	csel	x1, x8, x21, eq
10084c0bc:     	add	x0, sp, #0x30
10084c0c0:     	bl	0x1005028ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
10084c0c4:     	ldr	x25, [sp, #0x30]
10084c0c8:     	cmn	x25, #0x1
10084c0cc:     	cset	w24, eq
10084c0d0:     	cmp	x27, #0x1
10084c0d4:     	cset	w8, hi
10084c0d8:     	tst	w8, w24
10084c0dc:     	b.ne	0x10084b2c4 <_js_json_stringify_full+0xc44>
10084c0e0:     	b	0x10084b334 <_js_json_stringify_full+0xcb4>
10084c0e4:     	add	x9, x8, #0x90
10084c0e8:     	ldr	x10, [x8, #0x30]
10084c0ec:     	add	x10, x10, #0x1
10084c0f0:     	str	x10, [x8, #0x30]
10084c0f4:     	add	x8, x9, #0x19
10084c0f8:     	ldrb	w8, [x8]
10084c0fc:     	cmp	w8, #0xff
10084c100:     	b.ne	0x10084bef4 <_js_json_stringify_full+0x1874>
10084c104:     	b	0x10084bee8 <_js_json_stringify_full+0x1868>
10084c108:     	mov	x0, x23
10084c10c:     	bl	0x100b23684 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084c110:     	cbnz	x0, 0x10084b450 <_js_json_stringify_full+0xdd0>
10084c114:     	b	0x10084c290 <_js_json_stringify_full+0x1c10>
10084c118:     	and	x0, x19, #0xffffffffffff
10084c11c:     	bl	0x1004faa70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
10084c120:     	mov	w0, w0
10084c124:     	mov	x20, #0x7d7b            ; =32123
10084c128:     	movk	x20, #0x200, lsl #32
10084c12c:     	movk	x20, #0x7ff9, lsl #48
10084c130:     	tbz	w0, #0x0, 0x10084ac58 <_js_json_stringify_full+0x5d8>
10084c134:     	b	0x10084bb28 <_js_json_stringify_full+0x14a8>
10084c138:     	mov	x19, x0
10084c13c:     	mov	x0, x23
10084c140:     	bl	0x100b23684 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084c144:     	mov	x23, x0
10084c148:     	mov	x0, x19
10084c14c:     	cbnz	x23, 0x10084ba34 <_js_json_stringify_full+0x13b4>
10084c150:     	b	0x10084c230 <_js_json_stringify_full+0x1bb0>
10084c154:     	bl	0x100b237e4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084c158:     	cbnz	x0, 0x10084b378 <_js_json_stringify_full+0xcf8>
10084c15c:     	b	0x10084c290 <_js_json_stringify_full+0x1c10>
10084c160:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10084c164:     	add	x0, x0, #0x440
10084c168:     	bl	0x100b1782c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084c16c:     	cmp	w8, #0x1
10084c170:     	b.ne	0x10084c290 <_js_json_stringify_full+0x1c10>
10084c174:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084c178:     	add	x1, x1, #0x898
10084c17c:     	mov	x19, x0
10084c180:     	bl	0x100a2555c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084c184:     	mov	x0, x19
10084c188:     	strb	wzr, [x19, #0x20]
10084c18c:     	ldr	x8, [x19]
10084c190:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10084c194:     	cmp	x8, x9
10084c198:     	b.lo	0x10084b598 <_js_json_stringify_full+0xf18>
10084c19c:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084c1a0:     	add	x0, x0, #0xea8
10084c1a4:     	bl	0x100b1785c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084c1a8:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084c1ac:     	add	x0, x0, #0xec0
10084c1b0:     	bl	0x100b1782c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084c1b4:     	and	x0, x19, #0xffffffffffff
10084c1b8:     	bl	0x1004f2680 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
10084c1bc:     	mov	x20, x1
10084c1c0:     	tbz	w0, #0x0, 0x10084ac58 <_js_json_stringify_full+0x5d8>
10084c1c4:     	b	0x10084bb28 <_js_json_stringify_full+0x14a8>
10084c1c8:     	mov	x0, x23
10084c1cc:     	bl	0x100b23684 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084c1d0:     	mov	x23, x0
10084c1d4:     	cbnz	x0, 0x10084b8e4 <_js_json_stringify_full+0x1264>
10084c1d8:     	b	0x10084c230 <_js_json_stringify_full+0x1bb0>
10084c1dc:     	adrp	x0, 0x100efb000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
10084c1e0:     	add	x0, x0, #0xd70
10084c1e4:     	bl	0x100b1785c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084c1e8:     	bl	0x100b50a94 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
10084c1ec:     	cmp	w8, #0x2
10084c1f0:     	b.eq	0x10084c290 <_js_json_stringify_full+0x1c10>
10084c1f4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084c1f8:     	add	x1, x1, #0x898
10084c1fc:     	mov	x19, x0
10084c200:     	bl	0x100a2555c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084c204:     	mov	x0, x19
10084c208:     	strb	wzr, [x19, #0x20]
10084c20c:     	ldr	x8, [x19]
10084c210:     	cbz	x8, 0x10084b8d0 <_js_json_stringify_full+0x1250>
10084c214:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084c218:     	add	x0, x0, #0xe90
10084c21c:     	bl	0x100b1782c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084c220:     	mov	x0, x23
10084c224:     	bl	0x100b23684 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084c228:     	mov	x23, x0
10084c22c:     	cbnz	x0, 0x10084b800 <_js_json_stringify_full+0x1180>
10084c230:     	cbz	x22, 0x10084c290 <_js_json_stringify_full+0x1c10>
10084c234:     	mov	x0, x19
10084c238:     	bl	0x100b64100 <_mi_free>
10084c23c:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084c240:     	add	x0, x0, #0xc18
10084c244:     	bl	0x100b5d75c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084c248:     	adrp	x0, 0x100c47000 <_PERRY_EMPTY_STRING+0x934>
10084c24c:     	add	x0, x0, #0x638
10084c250:     	mov	w1, #0xf                ; =15
10084c254:     	bl	0x100b50a5c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084c258:     	and	x0, x19, #0xffffffffffff
10084c25c:     	add	x2, sp, #0x80
10084c260:     	mov	x1, x22
10084c264:     	bl	0x1004f2e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
10084c268:     	tbnz	w0, #0x0, 0x10084bc94 <_js_json_stringify_full+0x1614>
10084c26c:     	mov	w20, #0x2               ; =2
10084c270:     	and	x0, x19, #0xffffffffffff
10084c274:     	mov	x1, x20
10084c278:     	bl	0x1004f1500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
10084c27c:     	mov	x20, x1
10084c280:     	tbz	w0, #0x0, 0x10084ac58 <_js_json_stringify_full+0x5d8>
10084c284:     	b	0x10084bb28 <_js_json_stringify_full+0x14a8>
10084c288:     	cmp	w8, #0x2
10084c28c:     	b.ne	0x10084c2b8 <_js_json_stringify_full+0x1c38>
10084c290:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084c294:     	add	x0, x0, #0xc18
10084c298:     	bl	0x100b5d75c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084c29c:     	adrp	x0, 0x100f33000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x118>
10084c2a0:     	add	x0, x0, #0x8c0
10084c2a4:     	bl	0x100b178f0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
10084c2a8:     	adrp	x0, 0x100c47000 <_PERRY_EMPTY_STRING+0x934>
10084c2ac:     	add	x0, x0, #0x327
10084c2b0:     	mov	w1, #0xb                ; =11
10084c2b4:     	bl	0x100b50a5c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084c2b8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084c2bc:     	add	x1, x1, #0x898
10084c2c0:     	mov	x19, x0
10084c2c4:     	bl	0x100a2555c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084c2c8:     	mov	x0, x19
10084c2cc:     	strb	wzr, [x19, #0x20]
10084c2d0:     	ldr	x8, [x19]
10084c2d4:     	cbz	x8, 0x10084b7ec <_js_json_stringify_full+0x116c>
10084c2d8:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084c2dc:     	add	x0, x0, #0xe78
10084c2e0:     	bl	0x100b1782c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084c2e4:     	mov	w0, #0x1                ; =1
10084c2e8:     	mov	x1, x24
10084c2ec:     	bl	0x100b17480 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084c2f0:     	mov	w0, #0x1                ; =1
10084c2f4:     	mov	x1, x22
10084c2f8:     	bl	0x100b17480 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084c2fc:     	adrp	x2, 0x100efc000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
10084c300:     	add	x2, x2, #0x3c8
10084c304:     	mov	w0, #0x5                ; =5
10084c308:     	mov	w1, #0x5                ; =5
10084c30c:     	bl	0x100b1798c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
