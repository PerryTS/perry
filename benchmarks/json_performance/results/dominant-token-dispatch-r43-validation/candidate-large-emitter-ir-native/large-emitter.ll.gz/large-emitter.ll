; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/dominant-token-dispatch-r43/candidate-large-emitter-ir-native/.perry-trace/llvm/test_json_large_string_emitters_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@test_json_large_string_emitters_ts_.str.0 = private unnamed_addr constant [94 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/test-files/test_json_large_string_emitters.ts\00"
@test_json_large_string_emitters_ts_.str.0.bytes = private unnamed_addr constant [1 x i8] zeroinitializer
@test_json_large_string_emitters_ts_.str.1.bytes = private unnamed_addr constant [32 x i8] c"line\0A\22quote\22\\tab\09\E6\9D\B1\E4\BA\AC\ED\95\9C\F0\9F\99\82\01\00"
@test_json_large_string_emitters_ts_.str.2.bytes = private unnamed_addr constant [5 x i8] c"-key\00"
@test_json_large_string_emitters_ts_.str.3.bytes = private unnamed_addr constant [5 x i8] c"tail\00"
@test_json_large_string_emitters_ts_.str.4.bytes = private unnamed_addr constant [4 x i8] c"end\00"
@test_json_large_string_emitters_ts_.str.5.bytes = private unnamed_addr constant [7 x i8] c"pretty\00"
@test_json_large_string_emitters_ts_.str.6.bytes = private unnamed_addr constant [5 x i8] c"keys\00"
@test_json_large_string_emitters_ts_.str.7.bytes = private unnamed_addr constant [2 x i8] c"\0A\00"
@test_json_large_string_emitters_ts_.str.8.bytes = private unnamed_addr constant [10 x i8] c"\0Areturned\00"
@test_json_large_string_emitters_ts_.str.9.bytes = private unnamed_addr constant [38 x i8] c"retained native-buffer output changed\00"
@test_json_large_string_emitters_ts_.str.10.bytes = private unnamed_addr constant [14 x i8] c"retained-full\00"
@test_json_large_string_emitters_ts_.str.11.bytes = private unnamed_addr constant [2 x i8] c"a\00"
@test_json_large_string_emitters_ts_.str.12.bytes = private unnamed_addr constant [9 x i8] c"boundary\00"
@test_json_large_string_emitters_ts_.str.13.bytes = private unnamed_addr constant [18 x i8] c"boundary-callback\00"
@test_json_large_string_emitters_ts_.str.14.bytes = private unnamed_addr constant [4 x i8] c"\ED\A0\80\00"
@test_json_large_string_emitters_ts_.str.15.bytes = private unnamed_addr constant [12 x i8] c"lone-pretty\00"
@test_json_large_string_emitters_ts_.str.16.bytes = private unnamed_addr constant [14 x i8] c"lone-callback\00"
@test_json_large_string_emitters_ts_.str.17.bytes = private unnamed_addr constant [7 x i8] c"length\00"
@test_json_large_string_emitters_ts_.str.18.bytes = private unnamed_addr constant [7 x i8] c"churn-\00"
@test_json_large_string_emitters_ts_.str.19.bytes = private unnamed_addr constant [7 x i8] c"{\22id\22:\00"
@test_json_large_string_emitters_ts_.str.20.bytes = private unnamed_addr constant [3 x i8] c"id\00"
@test_json_large_string_emitters_ts_.str.21.bytes = private unnamed_addr constant [2 x i8] c"}\00"
@test_json_large_string_emitters_ts_.str.22.bytes = private unnamed_addr constant [23 x i8] c"callback churn changed\00"
@test_json_large_string_emitters_ts_.str.23.bytes = private unnamed_addr constant [5 x i8] c"text\00"
@perry_class_keys_packed_test_json_large_string_emitters_ts__1 = private unnamed_addr constant [9 x i8] c"id\00text\00\00"
@perry_class_keys_packed_test_json_large_string_emitters_ts__2 = private unnamed_addr constant [6 x i8] c"text\00\00"
@test_json_large_string_emitters_ts_.str.1 = private unnamed_addr constant [4 x i8] c"run\00"
@test_json_large_string_emitters_ts_.str.2 = private unnamed_addr constant [33 x i8] c"new __AnonShape_a7449f8c3df3dc47\00"
@test_json_large_string_emitters_ts_.str.3 = private unnamed_addr constant [33 x i8] c"new __AnonShape_6ef7d34fbe1f1d2c\00"
@test_json_large_string_emitters_ts_.str.4 = private unnamed_addr constant [33 x i8] c"new __AnonShape_f0c6d3c63b1d92d3\00"
@test_json_large_string_emitters_ts_.str.5 = private unnamed_addr constant [1860 x i8] c"function run(): void {\0A    let large = '';\0A    for (let i = 0; i < 512; i++) large += 'line\\n\22quote\22\\\\tab\\t\E6\9D\B1\E4\BA\AC\ED\95\9C\F0\9F\99\82\\u0001';\0A    const longKey = large + '-key';\0A    const input: any = {};\0A    input[longKey] = large;\0A    input.tail = 'end';\0A    function allocating(key: string, value: any): any {\0A        if (key.length > 256 && typeof value === 'string') {\0A            const churn: any[] = [];\0A            for (let j = 0; j < 64; j++) churn.push({id: j, text: 'churn-' + j});\0A            const parsed: any = JSON.parse('{\22id\22:' + churn[63].id + '}');\0A            if (parsed.id !== 63) throw new Error('callback churn changed');\0A            return value + '\\nreturned';\0A        }\0A        return value;\0A    }\0A    console.log('pretty', JSON.stringify(input, null, 2));\0A    console.log('keys', JSON.stringify(input, [longKey, 'tail'], 2));\0A    const retained: string[] = [];\0A    for (let i = 0; i < 8; i++) {\0A        input[longKey] = large + '\\n' + i;\0A        retained.push(JSON.stringify(input, allocating, i % 2 === 0 ? 0 : 2));\0A    }\0A    for (let i = 0; i < retained.length; i++) {\0A        const parsed: any = JSON.parse(retained[i]);\0A        if (parsed[longKey] !== large + '\\n' + i + '\\nreturned' || parsed.tail !== 'end') {\0A            throw new Error('retained native-buffer output changed');\0A        }\0A        console.log('retained-full', i, retained[i]);\0A    }\0A    for (let n = 255; n <= 257; n++) {\0A        let text = '';\0A        for (let j = 0; j < n; j++) text += j % 3 === 0 ? '\\n' : 'a';\0A        console.log('boundary', n, JSON.stringify({text: text}, null, 2));\0A        console.log('boundary-callback', n, JSON.stringify({text: text}, allocating, 2));\0A    }\0A    const lone = large + '\\ud800';\0A    console.log('lone-pretty', JSON.stringify({text: lone}, null, 2));\0A    console.log('lone-callback', JSON.stringify({text: lone}, allocating, 2));\0A}\00"
@test_json_large_string_emitters_ts_.str.6 = private unnamed_addr constant [463 x i8] c"function allocating(key: string, value: any): any {\0A        if (key.length > 256 && typeof value === 'string') {\0A            const churn: any[] = [];\0A            for (let j = 0; j < 64; j++) churn.push({id: j, text: 'churn-' + j});\0A            const parsed: any = JSON.parse('{\22id\22:' + churn[63].id + '}');\0A            if (parsed.id !== 63) throw new Error('callback churn changed');\0A            return value + '\\nreturned';\0A        }\0A        return value;\0A    }\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_test_json_large_string_emitters_ts = internal global i32 0
@perry_class_keys_test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47 = internal global i64 0
@perry_class_shape_id_test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47 = global i32 0
@perry_class_header_image_test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47 = internal global <2 x i64> zeroinitializer
@perry_class_keys_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c = internal global i64 0
@perry_class_shape_id_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c = global i32 0
@perry_class_header_image_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c = internal global <2 x i64> zeroinitializer
@perry_class_keys_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3 = internal global i64 0
@perry_class_shape_id_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3 = global i32 0
@perry_class_header_image_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3 = internal global <2 x i64> zeroinitializer
@perry_ic_test_json_large_string_emitters_ts__0 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__1 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__1_poly_tail = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__2 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__3 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__4 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__5 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__6 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__7 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__8 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__9 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__10 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__12 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__14 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__17 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__21 = private global ptr null
@perry_ic_test_json_large_string_emitters_ts__23 = private global ptr null
@perry_concat_site_test_json_large_string_emitters_ts__18 = private global [32 x i64] zeroinitializer
@test_json_large_string_emitters_ts_.str.0.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.1.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.2.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.3.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.4.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.5.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.6.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.7.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.8.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.9.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.10.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.11.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.12.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.13.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.14.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.15.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.16.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.17.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.18.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.19.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.20.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.21.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.22.handle = internal global double 0.000000e+00
@test_json_large_string_emitters_ts_.str.23.handle = internal global double 0.000000e+00
@perry_typed_shape_raw_f64_mask_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c = private unnamed_addr constant [1 x i64] [i64 1]
@perry_typed_shape_mask_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c = private unnamed_addr constant [1 x i64] [i64 2]
@perry_typed_shape_mask_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3 = private unnamed_addr constant [1 x i64] [i64 1]

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_1()

declare double @__ic_decl_14()

declare double @__ic_decl_17()

declare double @__ic_decl_21()

declare double @__ic_decl_23()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define double @perry_fn_test_json_large_string_emitters_ts__run() #6 gc "statepoint-example" {
entry.0:
  %r62 = load i64, ptr @perry_class_keys_test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47, align 8
  %rs4gc.s5 = inttoptr i64 %r62 to ptr addrspace(1)
  %r65 = load i32, ptr @perry_class_shape_id_test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47, align 4
  %r92 = call ptr @perry_transition_cache_base() #7
  %r3443 = alloca [32 x double], align 8
  %r3830 = load i64, ptr @perry_class_keys_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, align 8
  %rs4gc.s9 = inttoptr i64 %r3830 to ptr addrspace(1)
  %r3833 = load i32, ptr @perry_class_shape_id_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, align 4
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr, i32)) @js_closure_alloc, i32 2, i32 0, ptr @perry_closure_test_json_large_string_emitters_ts__2, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s9, ptr addrspace(1) %rs4gc.s5) ]
  %r215 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s9, %rs4gc.s9)
  %rs4gc.s5.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s5, %rs4gc.s5)
  %r3 = or i64 %r215, 9222527611924643840
  %r4 = bitcast i64 %r3 to double
  %rs4gc.b13 = bitcast double %r4 to i64
  %rs4gc.s13 = inttoptr i64 %rs4gc.b13 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r5 = call i64 asm "", "=r,0"(i64 %r5.rs4i) #7
  %r6 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r7 = icmp ne i32 %r6, 0
  br i1 %r7, label %shadow.root.barrier.1, label %shadow.root.barrier.done.2

shadow.root.barrier.1:                            ; preds = %entry.0
  call void @js_write_barrier_root_nanbox(i64 %r5) #7
  br label %shadow.root.barrier.done.2

shadow.root.barrier.done.2:                       ; preds = %shadow.root.barrier.1, %entry.0
  %r9 = load double, ptr @test_json_large_string_emitters_ts_.str.0.handle, align 8
  %rs4gc.b14 = bitcast double %r9 to i64
  %rs4gc.s14 = inttoptr i64 %rs4gc.b14 to ptr addrspace(1)
  %r10.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r10 = call i64 asm "", "=r,0"(i64 %r10.rs4i) #7
  %r11 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r12 = icmp ne i32 %r11, 0
  br i1 %r12, label %shadow.root.barrier.3, label %shadow.root.barrier.done.4

shadow.root.barrier.3:                            ; preds = %shadow.root.barrier.done.2
  call void @js_write_barrier_root_nanbox(i64 %r10) #7
  br label %shadow.root.barrier.done.4

shadow.root.barrier.done.4:                       ; preds = %shadow.root.barrier.3, %shadow.root.barrier.done.2
  br label %for.cond.5

for.cond.5:                                       ; preds = %for.update.7, %shadow.root.barrier.done.4
  %.01365 = phi ptr addrspace(1) [ %rs4gc.s13, %shadow.root.barrier.done.4 ], [ %.21367, %for.update.7 ]
  %.01307 = phi ptr addrspace(1) [ %rs4gc.s5.relocated, %shadow.root.barrier.done.4 ], [ %.21309, %for.update.7 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s9.relocated, %shadow.root.barrier.done.4 ], [ %.2, %for.update.7 ]
  %r13.0 = phi i32 [ 0, %shadow.root.barrier.done.4 ], [ %r50, %for.update.7 ]
  %r8.0 = phi ptr addrspace(1) [ %rs4gc.s14, %shadow.root.barrier.done.4 ], [ %.01425, %for.update.7 ]
  %r15 = sitofp i32 %r13.0 to double
  %r16 = fcmp olt double %r15, 5.120000e+02
  %r17 = select i1 %r16, i64 9222246136947933188, i64 9222246136947933187
  %r18 = bitcast i64 %r17 to double
  %r19 = icmp eq i64 %r17, 9222246136947933188
  br i1 %r19, label %for.body.6, label %for.exit.8

for.body.6:                                       ; preds = %for.cond.5
  %r20.rs4i = ptrtoint ptr addrspace(1) %r8.0 to i64
  %r20.rs4o = call i64 asm "", "=r,0"(i64 %r20.rs4i) #7
  %r20 = bitcast i64 %r20.rs4o to double
  %r21 = load double, ptr @test_json_large_string_emitters_ts_.str.1.handle, align 8
  %r22 = bitcast double %r20 to i64
  %r23 = bitcast double %r21 to i64
  %r24 = lshr i64 %r22, 48
  %r25 = lshr i64 %r23, 48
  %r26 = icmp eq i64 %r24, 32767
  br i1 %r26, label %strapp.dheap.9, label %strapp.dother.14

for.update.7:                                     ; preds = %gcpoll.done.19
  %r50 = add i32 %r13.0, 1
  %r51 = sitofp i32 %r13.0 to double
  %r52 = sitofp i32 %r50 to double
  br label %for.cond.5

for.exit.8:                                       ; preds = %for.cond.5
  %r54.rs4i = ptrtoint ptr addrspace(1) %r8.0 to i64
  %r54.rs4o = call i64 asm "", "=r,0"(i64 %r54.rs4i) #7
  %r54 = bitcast i64 %r54.rs4o to double
  %r55 = load double, ptr @test_json_large_string_emitters_ts_.str.2.handle, align 8
  %statepoint_token16 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r54, double %r55, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0, ptr addrspace(1) %.01365, ptr addrspace(1) %.0, ptr addrspace(1) %.01307) ]
  %r5617 = call double @llvm.experimental.gc.result.f64(token %statepoint_token16)
  %r8.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 0, i32 0) ; (%r8.0, %r8.0)
  %rs4gc.s13.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 1, i32 1) ; (%.01365, %.01365)
  %rs4gc.s9.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 2, i32 2) ; (%.0, %.0)
  %rs4gc.s5.relocated19 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 3, i32 3) ; (%.01307, %.01307)
  %rs4gc.b15 = bitcast double %r5617 to i64
  %rs4gc.s15 = inttoptr i64 %rs4gc.b15 to ptr addrspace(1)
  %r57.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r57 = call i64 asm "", "=r,0"(i64 %r57.rs4i) #7
  %r58 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r59 = icmp ne i32 %r58, 0
  br i1 %r59, label %shadow.root.barrier.20, label %shadow.root.barrier.done.21

strapp.dheap.9:                                   ; preds = %for.body.6
  %r27 = icmp eq i64 %r25, 32767
  br i1 %r27, label %strapp.heap.10, label %strapp.rnotheap.11

strapp.heap.10:                                   ; preds = %strapp.dheap.9
  %r28 = and i64 %r22, 281474976710655
  %r29 = and i64 %r23, 281474976710655
  %statepoint_token20 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_string_append_known_heap, i32 2, i32 0, i64 %r28, i64 %r29, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01365, ptr addrspace(1) %.0, ptr addrspace(1) %.01307) ]
  %r3038 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token20)
  %rs4gc.s13.relocated39 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 0, i32 0) ; (%.01365, %.01365)
  %rs4gc.s9.relocated40 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 1, i32 1) ; (%.0, %.0)
  %rs4gc.s5.relocated41 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 2, i32 2) ; (%.01307, %.01307)
  %r31 = or i64 %r3038, 9223090561878065152
  %r32 = bitcast i64 %r31 to double
  br label %strapp.merge.15

strapp.rnotheap.11:                               ; preds = %strapp.dheap.9
  %r33 = icmp eq i64 %r25, 32761
  br i1 %r33, label %strapp.rsso.12, label %strapp.dynamic.13

strapp.rsso.12:                                   ; preds = %strapp.rnotheap.11
  %statepoint_token42 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r21, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01365, ptr addrspace(1) %.0, ptr addrspace(1) %.01307, ptr addrspace(1) %r8.0) ]
  %r34100 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token42)
  %rs4gc.s13.relocated101 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token42, i32 0, i32 0) ; (%.01365, %.01365)
  %rs4gc.s9.relocated102 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token42, i32 1, i32 1) ; (%.0, %.0)
  %rs4gc.s5.relocated103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token42, i32 2, i32 2) ; (%.01307, %.01307)
  %r8.0.relocated104 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token42, i32 3, i32 3) ; (%r8.0, %r8.0)
  %r35.rs4i = ptrtoint ptr addrspace(1) %r8.0.relocated104 to i64
  %r35.rs4o = call i64 asm "", "=r,0"(i64 %r35.rs4i) #7
  %r35 = bitcast i64 %r35.rs4o to double
  %r36 = bitcast double %r35 to i64
  %r37 = and i64 %r36, 281474976710655
  %statepoint_token105 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_string_append_known_heap, i32 2, i32 0, i64 %r37, i64 %r34100, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated101, ptr addrspace(1) %rs4gc.s9.relocated102, ptr addrspace(1) %rs4gc.s5.relocated103) ]
  %r38106 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token105)
  %rs4gc.s13.relocated107 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 0, i32 0) ; (%rs4gc.s13.relocated101, %rs4gc.s13.relocated101)
  %rs4gc.s9.relocated108 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 1, i32 1) ; (%rs4gc.s9.relocated102, %rs4gc.s9.relocated102)
  %rs4gc.s5.relocated109 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 2, i32 2) ; (%rs4gc.s5.relocated103, %rs4gc.s5.relocated103)
  %r39 = or i64 %r38106, 9223090561878065152
  %r40 = bitcast i64 %r39 to double
  br label %strapp.merge.15

strapp.dynamic.13:                                ; preds = %strapp.rnotheap.11
  %statepoint_token110 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r20, double %r21, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01365, ptr addrspace(1) %.0, ptr addrspace(1) %.01307) ]
  %r41111 = call double @llvm.experimental.gc.result.f64(token %statepoint_token110)
  %rs4gc.s13.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 0, i32 0) ; (%.01365, %.01365)
  %rs4gc.s9.relocated113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 1, i32 1) ; (%.0, %.0)
  %rs4gc.s5.relocated114 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 2, i32 2) ; (%.01307, %.01307)
  br label %strapp.merge.15

strapp.dother.14:                                 ; preds = %for.body.6
  %statepoint_token115 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r20, double %r21, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01365, ptr addrspace(1) %.0, ptr addrspace(1) %.01307) ]
  %r42116 = call double @llvm.experimental.gc.result.f64(token %statepoint_token115)
  %rs4gc.s13.relocated117 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token115, i32 0, i32 0) ; (%.01365, %.01365)
  %rs4gc.s9.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token115, i32 1, i32 1) ; (%.0, %.0)
  %rs4gc.s5.relocated119 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token115, i32 2, i32 2) ; (%.01307, %.01307)
  br label %strapp.merge.15

strapp.merge.15:                                  ; preds = %strapp.dother.14, %strapp.dynamic.13, %strapp.rsso.12, %strapp.heap.10
  %.11366 = phi ptr addrspace(1) [ %rs4gc.s13.relocated39, %strapp.heap.10 ], [ %rs4gc.s13.relocated107, %strapp.rsso.12 ], [ %rs4gc.s13.relocated112, %strapp.dynamic.13 ], [ %rs4gc.s13.relocated117, %strapp.dother.14 ]
  %.11308 = phi ptr addrspace(1) [ %rs4gc.s5.relocated41, %strapp.heap.10 ], [ %rs4gc.s5.relocated109, %strapp.rsso.12 ], [ %rs4gc.s5.relocated114, %strapp.dynamic.13 ], [ %rs4gc.s5.relocated119, %strapp.dother.14 ]
  %.1 = phi ptr addrspace(1) [ %rs4gc.s9.relocated40, %strapp.heap.10 ], [ %rs4gc.s9.relocated108, %strapp.rsso.12 ], [ %rs4gc.s9.relocated113, %strapp.dynamic.13 ], [ %rs4gc.s9.relocated118, %strapp.dother.14 ]
  %r43 = phi double [ %r32, %strapp.heap.10 ], [ %r40, %strapp.rsso.12 ], [ %r41111, %strapp.dynamic.13 ], [ %r42116, %strapp.dother.14 ]
  %rs4gc.b16 = bitcast double %r43 to i64
  %rs4gc.s16 = inttoptr i64 %rs4gc.b16 to ptr addrspace(1)
  %r44.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r44 = call i64 asm "", "=r,0"(i64 %r44.rs4i) #7
  %r45 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r46 = icmp ne i32 %r45, 0
  br i1 %r46, label %shadow.root.barrier.16, label %shadow.root.barrier.done.17

shadow.root.barrier.16:                           ; preds = %strapp.merge.15
  call void @js_write_barrier_root_nanbox(i64 %r44) #7
  br label %shadow.root.barrier.done.17

shadow.root.barrier.done.17:                      ; preds = %shadow.root.barrier.16, %strapp.merge.15
  %r47 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r48 = icmp ne i32 %r47, 0
  br i1 %r48, label %gcpoll.18, label %gcpoll.done.19

gcpoll.18:                                        ; preds = %shadow.root.barrier.done.17
  %statepoint_token120 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16, ptr addrspace(1) %.11366, ptr addrspace(1) %.1, ptr addrspace(1) %.11308) ]
  %rs4gc.s16.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 0, i32 0) ; (%rs4gc.s16, %rs4gc.s16)
  %rs4gc.s13.relocated121 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 1, i32 1) ; (%.11366, %.11366)
  %rs4gc.s9.relocated122 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 2, i32 2) ; (%.1, %.1)
  %rs4gc.s5.relocated123 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 3, i32 3) ; (%.11308, %.11308)
  br label %gcpoll.done.19

gcpoll.done.19:                                   ; preds = %gcpoll.18, %shadow.root.barrier.done.17
  %.01425 = phi ptr addrspace(1) [ %rs4gc.s16.relocated, %gcpoll.18 ], [ %rs4gc.s16, %shadow.root.barrier.done.17 ]
  %.21367 = phi ptr addrspace(1) [ %rs4gc.s13.relocated121, %gcpoll.18 ], [ %.11366, %shadow.root.barrier.done.17 ]
  %.21309 = phi ptr addrspace(1) [ %rs4gc.s5.relocated123, %gcpoll.18 ], [ %.11308, %shadow.root.barrier.done.17 ]
  %.2 = phi ptr addrspace(1) [ %rs4gc.s9.relocated122, %gcpoll.18 ], [ %.1, %shadow.root.barrier.done.17 ]
  br label %for.update.7

shadow.root.barrier.20:                           ; preds = %for.exit.8
  call void @js_write_barrier_root_nanbox(i64 %r57) #7
  br label %shadow.root.barrier.done.21

shadow.root.barrier.done.21:                      ; preds = %shadow.root.barrier.20, %for.exit.8
  %r63.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s5.relocated19 to i64
  %r63 = call i64 asm "", "=r,0"(i64 %r63.rs4i) #7
  %statepoint_token124 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 1, i32 0, i32 0, i64 %r63, i32 %r65, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated, ptr addrspace(1) %rs4gc.s15, ptr addrspace(1) %rs4gc.s13.relocated, ptr addrspace(1) %rs4gc.s9.relocated18) ]
  %r67125 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token124)
  %r8.0.relocated126 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token124, i32 0, i32 0) ; (%r8.0.relocated, %r8.0.relocated)
  %rs4gc.s15.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token124, i32 1, i32 1) ; (%rs4gc.s15, %rs4gc.s15)
  %rs4gc.s13.relocated127 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token124, i32 2, i32 2) ; (%rs4gc.s13.relocated, %rs4gc.s13.relocated)
  %rs4gc.s9.relocated128 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token124, i32 3, i32 3) ; (%rs4gc.s9.relocated18, %rs4gc.s9.relocated18)
  %rs4gc.s17 = inttoptr i64 %r67125 to ptr addrspace(1)
  %r69.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r69 = call i64 asm "", "=r,0"(i64 %r69.rs4i) #7
  %r70 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r71 = icmp ne i32 %r70, 0
  br i1 %r71, label %shadow.root.barrier.22, label %shadow.root.barrier.done.23

shadow.root.barrier.22:                           ; preds = %shadow.root.barrier.done.21
  call void @js_write_barrier_root_nanbox(i64 %r69) #7
  br label %shadow.root.barrier.done.23

shadow.root.barrier.done.23:                      ; preds = %shadow.root.barrier.22, %shadow.root.barrier.done.21
  %r72 = or i64 %r67125, 9222527611924643840
  %r73 = bitcast i64 %r72 to double
  %r74 = call double @test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47_constructor(double %r73) #7
  %r75.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r75 = call i64 asm "", "=r,0"(i64 %r75.rs4i) #7
  %r76 = or i64 %r75, 9222527611924643840
  %r77 = bitcast i64 %r76 to double
  call void @js_gc_init_typed_shape_layout(i64 %r75, i32 0, ptr null, i32 0, ptr null, i32 0) #7
  %r78 = bitcast double %r74 to i64
  %r79 = icmp eq i64 %r78, 9222246136947933185
  br i1 %r79, label %ctor_ret.merge.25, label %ctor_ret.override.24

ctor_ret.override.24:                             ; preds = %shadow.root.barrier.done.23
  %statepoint_token129 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r77, double %r74, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated126, ptr addrspace(1) %rs4gc.s15.relocated, ptr addrspace(1) %rs4gc.s13.relocated127, ptr addrspace(1) %rs4gc.s9.relocated128) ]
  %r80130 = call double @llvm.experimental.gc.result.f64(token %statepoint_token129)
  %r8.0.relocated131 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 0, i32 0) ; (%r8.0.relocated126, %r8.0.relocated126)
  %rs4gc.s15.relocated132 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 1, i32 1) ; (%rs4gc.s15.relocated, %rs4gc.s15.relocated)
  %rs4gc.s13.relocated133 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 2, i32 2) ; (%rs4gc.s13.relocated127, %rs4gc.s13.relocated127)
  %rs4gc.s9.relocated134 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 3, i32 3) ; (%rs4gc.s9.relocated128, %rs4gc.s9.relocated128)
  br label %ctor_ret.merge.25

ctor_ret.merge.25:                                ; preds = %ctor_ret.override.24, %shadow.root.barrier.done.23
  %.01426 = phi ptr addrspace(1) [ %rs4gc.s15.relocated, %shadow.root.barrier.done.23 ], [ %rs4gc.s15.relocated132, %ctor_ret.override.24 ]
  %.31368 = phi ptr addrspace(1) [ %rs4gc.s13.relocated127, %shadow.root.barrier.done.23 ], [ %rs4gc.s13.relocated133, %ctor_ret.override.24 ]
  %.01310 = phi ptr addrspace(1) [ %r8.0.relocated126, %shadow.root.barrier.done.23 ], [ %r8.0.relocated131, %ctor_ret.override.24 ]
  %.3 = phi ptr addrspace(1) [ %rs4gc.s9.relocated128, %shadow.root.barrier.done.23 ], [ %rs4gc.s9.relocated134, %ctor_ret.override.24 ]
  %r81 = phi double [ %r77, %shadow.root.barrier.done.23 ], [ %r80130, %ctor_ret.override.24 ]
  %rs4gc.b18 = bitcast double %r81 to i64
  %rs4gc.s18 = inttoptr i64 %rs4gc.b18 to ptr addrspace(1)
  %r82.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r82 = call i64 asm "", "=r,0"(i64 %r82.rs4i) #7
  %r83 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r84 = icmp ne i32 %r83, 0
  br i1 %r84, label %shadow.root.barrier.26, label %shadow.root.barrier.done.27

shadow.root.barrier.26:                           ; preds = %ctor_ret.merge.25
  call void @js_write_barrier_root_nanbox(i64 %r82) #7
  br label %shadow.root.barrier.done.27

shadow.root.barrier.done.27:                      ; preds = %shadow.root.barrier.26, %ctor_ret.merge.25
  %r85.rs4i = ptrtoint ptr addrspace(1) %.01426 to i64
  %r85.rs4o = call i64 asm "", "=r,0"(i64 %r85.rs4i) #7
  %r85 = bitcast i64 %r85.rs4o to double
  %r86.rs4i = ptrtoint ptr addrspace(1) %.01310 to i64
  %r86.rs4o = call i64 asm "", "=r,0"(i64 %r86.rs4i) #7
  %r86 = bitcast i64 %r86.rs4o to double
  %r87.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r87.rs4o = call i64 asm "", "=r,0"(i64 %r87.rs4i) #7
  %r87 = bitcast i64 %r87.rs4o to double
  %r88 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__0, align 8
  %r89 = icmp ne ptr %r88, null
  %r90 = select i1 %r89, ptr %r88, ptr @perry_ic_test_json_large_string_emitters_ts__0
  %r93 = bitcast double %r85 to i64
  %r94 = bitcast double %r86 to i64
  %r95 = bitcast double %r87 to i64
  %r96 = and i64 %r95, 281474976710655
  %r97 = lshr i64 %r95, 48
  %r98 = icmp eq i64 %r97, 32765
  %r99 = icmp ugt i64 %r96, 1048575
  %r100 = lshr i64 %r94, 48
  %r101 = icmp ne i64 %r100, 32765
  %r102 = icmp ne i64 %r100, 32767
  %r103 = icmp ne i64 %r100, 32762
  %r104 = and i1 %r101, %r102
  %r105 = and i1 %r104, %r103
  %r106 = icmp ne i64 %r93, 0
  %r107 = and i1 %r98, %r99
  %r108 = and i1 %r107, %r106
  br i1 %r108, label %put.dynic.guard.28, label %put.dynic.slow.46

put.dynic.guard.28:                               ; preds = %shadow.root.barrier.done.27
  %r109 = sub nuw nsw i64 %r96, 8
  %r110 = inttoptr i64 %r109 to ptr
  %r111 = load i8, ptr %r110, align 1
  %r112 = icmp eq i8 %r111, 2
  %r113 = sub nuw nsw i64 %r96, 7
  %r114 = inttoptr i64 %r113 to ptr
  %r115 = load i8, ptr %r114, align 1
  %r116 = and i8 %r115, -128
  %r117 = icmp eq i8 %r116, 0
  %r118 = sub nuw nsw i64 %r96, 6
  %r119 = inttoptr i64 %r118 to ptr
  %r120 = load i16, ptr %r119, align 2
  %r121 = and i16 %r120, 6535
  %r122 = icmp eq i16 %r121, 0
  %r123 = add nuw nsw i64 %r96, 0
  %r124 = inttoptr i64 %r123 to ptr
  %r125 = load i32, ptr %r124, align 4
  %r126 = icmp ne i32 %r125, 0
  %r127 = icmp ne i32 %r125, -2
  %r128 = and i16 %r120, 512
  %r129 = icmp ne i16 %r128, 0
  %r130 = or i1 %r126, %r129
  %r131 = add nuw nsw i64 %r96, 4
  %r132 = inttoptr i64 %r131 to ptr
  %r133 = load i32, ptr %r132, align 4
  %r134 = add i32 %r133, -2147483648
  %r135 = icmp ult i32 %r134, 1073741824
  %r136 = zext i32 %r133 to i64
  %r137 = or i64 %r136, 4611686018427387904
  %r138 = select i1 %r135, i64 %r137, i64 0
  %r139 = getelementptr i64, ptr %r90, i64 0
  %r140 = load i64, ptr %r139, align 8
  %r141 = icmp eq i64 %r138, %r140
  %r142 = icmp ne i64 %r138, 0
  %r143 = and i1 %r112, %r117
  %r144 = and i1 %r143, %r122
  %r145 = and i1 %r144, %r130
  %r146 = and i1 %r145, %r127
  %r147 = and i1 %r141, %r142
  %r148 = and i1 %r146, %r147
  br i1 %r148, label %put.dynic.ways.29, label %put.dynic.trans.gate.37

put.dynic.ways.29:                                ; preds = %put.dynic.guard.28
  %r150 = getelementptr i64, ptr %r88, i64 1
  %r151 = load i64, ptr %r150, align 8
  %r152 = getelementptr i64, ptr %r88, i64 2
  %r153 = load i64, ptr %r152, align 8
  %r154 = icmp eq i64 %r93, %r151
  br i1 %r154, label %put.dynic.store.32, label %put.dynic.way1.30

put.dynic.way1.30:                                ; preds = %put.dynic.ways.29
  %r155 = getelementptr i64, ptr %r88, i64 3
  %r156 = load i64, ptr %r155, align 8
  %r157 = getelementptr i64, ptr %r88, i64 4
  %r158 = load i64, ptr %r157, align 8
  %r159 = icmp eq i64 %r93, %r156
  br i1 %r159, label %put.dynic.store.32, label %put.dynic.way2.31

put.dynic.way2.31:                                ; preds = %put.dynic.way1.30
  %r160 = getelementptr i64, ptr %r88, i64 5
  %r161 = load i64, ptr %r160, align 8
  %r162 = getelementptr i64, ptr %r88, i64 6
  %r163 = load i64, ptr %r162, align 8
  %r164 = icmp eq i64 %r93, %r161
  br i1 %r164, label %put.dynic.store.32, label %put.dynic.trans.probe.38

put.dynic.store.32:                               ; preds = %put.dynic.way2.31, %put.dynic.way1.30, %put.dynic.ways.29
  %r165 = phi i64 [ %r153, %put.dynic.ways.29 ], [ %r158, %put.dynic.way1.30 ], [ %r163, %put.dynic.way2.31 ]
  %r166 = shl i64 %r165, 3
  %r167 = add i64 %r166, 16
  %r168 = inttoptr i64 %r96 to ptr
  %r169 = getelementptr inbounds i8, ptr %r168, i64 %r167
  %r170 = and i16 %r120, 1024
  %r171 = icmp ne i16 %r170, 0
  br i1 %r171, label %put.dynic.store.validate.33, label %put.dynic.store.dispatch.34

put.dynic.store.validate.33:                      ; preds = %put.dynic.store.32
  %r172 = load double, ptr %r169, align 8
  %r173 = bitcast double %r172 to i64
  %r174 = icmp eq i64 %r173, 9222246136947933200
  br i1 %r174, label %put.dynic.slow.46, label %put.dynic.store.dispatch.34

put.dynic.store.dispatch.34:                      ; preds = %put.dynic.store.validate.33, %put.dynic.store.32
  br i1 %r105, label %put.dynic.store.scalar.35, label %put.dynic.store.ref.36

put.dynic.store.scalar.35:                        ; preds = %put.dynic.store.dispatch.34
  store double %r86, ptr %r169, align 8
  br label %put.dynic.merge.47

put.dynic.store.ref.36:                           ; preds = %put.dynic.store.dispatch.34
  %r175 = trunc i64 %r165 to i32
  %r176 = shl i64 %r165, 3
  %r177 = add nuw nsw i64 %r96, 16
  %r178 = add i64 %r177, %r176
  %r179 = load double, ptr %r169, align 8
  %r180 = bitcast double %r179 to i64
  store double %r86, ptr %r169, align 8
  call void @js_string_addref_if_heap_string(double %r86) #7
  %r4712.rs4i = ptrtoint ptr addrspace(1) %.01310 to i64
  %r4712.rs4o = call i64 asm "", "=r,0"(i64 %r4712.rs4i) #7
  %r4712 = bitcast i64 %r4712.rs4o to double
  %r181 = bitcast double %r4712 to i64
  %r4707.rs4i = ptrtoint ptr addrspace(1) %.01310 to i64
  %r4707.rs4o = call i64 asm "", "=r,0"(i64 %r4707.rs4i) #7
  %r4707 = bitcast i64 %r4707.rs4o to double
  %r4708 = bitcast double %r4707 to i64
  %r4709.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r4709.rs4o = call i64 asm "", "=r,0"(i64 %r4709.rs4i) #7
  %r4709 = bitcast i64 %r4709.rs4o to double
  %r4710 = bitcast double %r4709 to i64
  %r4711 = and i64 %r4710, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4711, i32 %r175, i64 %r4708, i64 %r180) #7
  %r4703.rs4i = ptrtoint ptr addrspace(1) %.01310 to i64
  %r4703.rs4o = call i64 asm "", "=r,0"(i64 %r4703.rs4i) #7
  %r4703 = bitcast i64 %r4703.rs4o to double
  %r4704 = bitcast double %r4703 to i64
  %r4705.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r4705.rs4o = call i64 asm "", "=r,0"(i64 %r4705.rs4i) #7
  %r4705 = bitcast i64 %r4705.rs4o to double
  %r4706 = bitcast double %r4705 to i64
  call void @js_write_barrier_slot(i64 %r4706, i64 %r178, i64 %r4704) #7
  br label %put.dynic.merge.47

put.dynic.trans.gate.37:                          ; preds = %put.dynic.guard.28
  %r149 = and i1 %r146, %r142
  br i1 %r149, label %put.dynic.trans.probe.38, label %put.dynic.slow.46

put.dynic.trans.probe.38:                         ; preds = %put.dynic.trans.gate.37, %put.dynic.way2.31
  %r182 = lshr i64 %r93, 48
  %r183 = icmp eq i64 %r182, 32767
  %r184 = and i64 %r93, 281474976710655
  %r185 = icmp ugt i64 %r184, 1048575
  %r186 = and i16 %r120, -16384
  %r187 = icmp eq i16 %r186, 0
  %r188 = and i8 %r115, 32
  %r189 = icmp eq i8 %r188, 0
  %r190 = and i1 %r183, %r185
  %r191 = and i1 %r190, %r187
  %r192 = and i1 %r191, %r189
  br i1 %r192, label %put.dynic.trans.key.39, label %put.dynic.slow.46

put.dynic.trans.key.39:                           ; preds = %put.dynic.trans.probe.38
  %r193 = and i64 %r93, 281474976710655
  %r194 = add nuw nsw i64 %r193, 4
  %r195 = inttoptr i64 %r194 to ptr
  %r196 = load i32, ptr %r195, align 4
  %r197 = icmp uge i32 %r196, 6
  %r198 = icmp ule i32 %r196, 8
  %r199 = add nuw nsw i64 %r193, 20
  %r200 = inttoptr i64 %r199 to ptr
  %r201 = load i8, ptr %r200, align 1
  %r202 = sub i8 %r201, 48
  %r203 = icmp ult i8 %r202, 10
  %r204 = icmp eq i1 %r203, false
  %r205 = and i1 %r197, %r198
  %r206 = and i1 %r205, %r204
  br i1 %r206, label %put.dynic.trans.entry.40, label %put.dynic.slow.46

put.dynic.trans.entry.40:                         ; preds = %put.dynic.trans.key.39
  %r207 = add nuw nsw i64 %r193, 20
  %r208 = inttoptr i64 %r207 to ptr
  %r209 = load i64, ptr %r208, align 8
  %r210 = zext nneg i32 %r196 to i64
  %r211 = sub nuw nsw i64 8, %r210
  %r212 = shl nuw nsw i64 %r211, 3
  %r213 = lshr i64 -1, %r212
  %r214 = and i64 %r209, %r213
  %r216 = ptrtoint ptr %r92 to i64
  %r217 = zext i32 %r133 to i64
  %r218 = mul i64 %r217, -7046029254386353131
  %r219 = lshr i64 %r214, 3
  %r220 = mul i64 %r219, -4126379630918253789
  %r221 = xor i64 %r218, %r220
  %r222 = and i64 %r221, 16383
  %r223 = shl nuw nsw i64 %r222, 5
  %r224 = add i64 %r216, %r223
  %r225 = inttoptr i64 %r224 to ptr
  %r226 = load i64, ptr %r225, align 8
  %r227 = add i64 %r224, 8
  %r228 = inttoptr i64 %r227 to ptr
  %r229 = load i64, ptr %r228, align 8
  %r230 = add i64 %r224, 16
  %r231 = inttoptr i64 %r230 to ptr
  %r232 = load i32, ptr %r231, align 4
  %r233 = add i64 %r224, 20
  %r234 = inttoptr i64 %r233 to ptr
  %r235 = load i32, ptr %r234, align 4
  %r236 = add i64 %r224, 24
  %r237 = inttoptr i64 %r236 to ptr
  %r238 = load i32, ptr %r237, align 4
  %r239 = lshr i32 %r238, 24
  %r240 = and i32 %r238, 16777215
  %r241 = add i64 %r224, 28
  %r242 = inttoptr i64 %r241 to ptr
  %r243 = load i32, ptr %r242, align 4
  %r244 = icmp eq i64 %r226, %r214
  %r245 = icmp eq i32 %r239, %r196
  %r246 = icmp eq i32 %r232, %r133
  %r247 = icmp ne i64 %r229, 0
  %r248 = add nuw nsw i32 %r240, 1
  %r249 = icmp eq i32 %r243, %r248
  %r250 = zext nneg i32 %r240 to i64
  %r251 = and i64 %r94, 281474976710655
  %r252 = icmp eq i64 %r100, 32765
  %r253 = icmp eq i64 %r251, 0
  %r254 = and i1 %r252, %r253
  %r255 = select i1 %r254, i64 9222246136947933185, i64 %r94
  %r256 = bitcast i64 %r255 to double
  %r257 = and i1 %r244, %r245
  %r258 = and i1 %r257, %r246
  %r259 = and i1 %r258, %r247
  %r260 = and i1 %r259, %r249
  br i1 %r260, label %put.dynic.trans.nk.41, label %put.dynic.slow.46

put.dynic.trans.nk.41:                            ; preds = %put.dynic.trans.entry.40
  %r261 = inttoptr i64 %r229 to ptr
  %r262 = load i32, ptr %r261, align 4
  %r263 = icmp eq i32 %r262, %r248
  br i1 %r263, label %put.dynic.trans.dispatch.42, label %put.dynic.slow.46

put.dynic.trans.dispatch.42:                      ; preds = %put.dynic.trans.nk.41
  %r264 = icmp ult i64 %r250, 2
  br i1 %r264, label %put.dynic.trans.inline_ref.43, label %put.dynic.trans.ovf.44

put.dynic.trans.inline_ref.43:                    ; preds = %put.dynic.trans.dispatch.42
  %r265 = shl nuw nsw i64 %r250, 3
  %r266 = add nuw nsw i64 %r265, 16
  %r267 = add nuw nsw i64 %r96, %r266
  %r268 = inttoptr i64 %r267 to ptr
  %r269 = trunc nuw nsw i64 %r250 to i32
  %r270 = load double, ptr %r268, align 8
  %r271 = bitcast double %r270 to i64
  store double %r256, ptr %r268, align 8
  call void @js_string_addref_if_heap_string(double %r256) #7
  %r272 = bitcast double %r256 to i64
  %r4700.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r4700.rs4o = call i64 asm "", "=r,0"(i64 %r4700.rs4i) #7
  %r4700 = bitcast i64 %r4700.rs4o to double
  %r4701 = bitcast double %r4700 to i64
  %r4702 = and i64 %r4701, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4702, i32 %r269, i64 %r272, i64 %r271) #7
  %r4698.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r4698.rs4o = call i64 asm "", "=r,0"(i64 %r4698.rs4i) #7
  %r4698 = bitcast i64 %r4698.rs4o to double
  %r4699 = bitcast double %r4698 to i64
  call void @js_write_barrier_slot(i64 %r4699, i64 %r267, i64 %r272) #7
  br label %put.dynic.trans.stamp.45

put.dynic.trans.ovf.44:                           ; preds = %put.dynic.trans.dispatch.42
  %r273 = trunc nuw nsw i64 %r250 to i32
  %r274 = call i32 @js_transition_ic_spill_append(double %r87, i64 %r138, i32 %r273, double %r256) #7
  %r275 = icmp ne i32 %r274, 0
  br i1 %r275, label %put.dynic.trans.stamp.45, label %put.dynic.slow.46

put.dynic.trans.stamp.45:                         ; preds = %put.dynic.trans.ovf.44, %put.dynic.trans.inline_ref.43
  %r4695.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r4695.rs4o = call i64 asm "", "=r,0"(i64 %r4695.rs4i) #7
  %r4695 = bitcast i64 %r4695.rs4o to double
  %r4696 = bitcast double %r4695 to i64
  %r4697 = and i64 %r4696, 281474976710655
  %r276 = add nuw nsw i64 %r4697, 4
  %r277 = inttoptr i64 %r276 to ptr
  store i32 %r235, ptr %r277, align 4
  br label %put.dynic.merge.47

put.dynic.slow.46:                                ; preds = %put.dynic.trans.ovf.44, %put.dynic.trans.nk.41, %put.dynic.trans.entry.40, %put.dynic.trans.key.39, %put.dynic.trans.probe.38, %put.dynic.trans.gate.37, %put.dynic.store.validate.33, %shadow.root.barrier.done.27
  %statepoint_token135 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_large_string_emitters_ts__0, double %r87, double %r85, double %r86, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01310, ptr addrspace(1) %.01426, ptr addrspace(1) %.31368, ptr addrspace(1) %.3, ptr addrspace(1) %rs4gc.s18) ]
  %r278136 = call double @llvm.experimental.gc.result.f64(token %statepoint_token135)
  %r8.0.relocated137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 0, i32 0) ; (%.01310, %.01310)
  %rs4gc.s15.relocated138 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 1, i32 1) ; (%.01426, %.01426)
  %rs4gc.s13.relocated139 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 2, i32 2) ; (%.31368, %.31368)
  %rs4gc.s9.relocated140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 3, i32 3) ; (%.3, %.3)
  %rs4gc.s18.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 4, i32 4) ; (%rs4gc.s18, %rs4gc.s18)
  br label %put.dynic.merge.47

put.dynic.merge.47:                               ; preds = %put.dynic.slow.46, %put.dynic.trans.stamp.45, %put.dynic.store.ref.36, %put.dynic.store.scalar.35
  %.01460 = phi ptr addrspace(1) [ %rs4gc.s18.relocated, %put.dynic.slow.46 ], [ %rs4gc.s18, %put.dynic.store.scalar.35 ], [ %rs4gc.s18, %put.dynic.store.ref.36 ], [ %rs4gc.s18, %put.dynic.trans.stamp.45 ]
  %.11427 = phi ptr addrspace(1) [ %rs4gc.s15.relocated138, %put.dynic.slow.46 ], [ %.01426, %put.dynic.store.scalar.35 ], [ %.01426, %put.dynic.store.ref.36 ], [ %.01426, %put.dynic.trans.stamp.45 ]
  %.41369 = phi ptr addrspace(1) [ %rs4gc.s13.relocated139, %put.dynic.slow.46 ], [ %.31368, %put.dynic.store.scalar.35 ], [ %.31368, %put.dynic.store.ref.36 ], [ %.31368, %put.dynic.trans.stamp.45 ]
  %.11311 = phi ptr addrspace(1) [ %r8.0.relocated137, %put.dynic.slow.46 ], [ %.01310, %put.dynic.store.scalar.35 ], [ %.01310, %put.dynic.store.ref.36 ], [ %.01310, %put.dynic.trans.stamp.45 ]
  %.4 = phi ptr addrspace(1) [ %rs4gc.s9.relocated140, %put.dynic.slow.46 ], [ %.3, %put.dynic.store.scalar.35 ], [ %.3, %put.dynic.store.ref.36 ], [ %.3, %put.dynic.trans.stamp.45 ]
  %r279 = phi double [ %r86, %put.dynic.store.scalar.35 ], [ %r86, %put.dynic.store.ref.36 ], [ %r256, %put.dynic.trans.stamp.45 ], [ %r278136, %put.dynic.slow.46 ]
  %r280.rs4i = ptrtoint ptr addrspace(1) %.01460 to i64
  %r280.rs4o = call i64 asm "", "=r,0"(i64 %r280.rs4i) #7
  %r280 = bitcast i64 %r280.rs4o to double
  %r281 = load double, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  %r282 = load double, ptr @test_json_large_string_emitters_ts_.str.4.handle, align 8
  %r283 = bitcast double %r280 to i64
  %r284 = bitcast double %r281 to i64
  %r285 = and i64 %r284, 281474976710655
  %r286 = and i64 %r283, 281474976710655
  %r287 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__1, align 8
  %r288 = icmp ne ptr %r287, null
  %r289 = lshr i64 %r283, 48
  %r290 = icmp eq i64 %r289, 32765
  %r291 = icmp ugt i64 %r286, 1048575
  %r292 = and i1 %r290, %r291
  %r293 = and i1 %r292, %r288
  br i1 %r293, label %put.pic.guard.48, label %put.pic.miss.60

put.pic.guard.48:                                 ; preds = %put.dynic.merge.47
  %r294 = sub nuw nsw i64 %r286, 8
  %r295 = inttoptr i64 %r294 to ptr
  %r296 = load i8, ptr %r295, align 1
  %r297 = icmp eq i8 %r296, 2
  %r298 = sub nuw nsw i64 %r286, 7
  %r299 = inttoptr i64 %r298 to ptr
  %r300 = load i8, ptr %r299, align 1
  %r301 = and i8 %r300, -128
  %r302 = icmp eq i8 %r301, 0
  %r303 = sub nuw nsw i64 %r286, 6
  %r304 = inttoptr i64 %r303 to ptr
  %r305 = load i16, ptr %r304, align 2
  %r306 = and i16 %r305, 6535
  %r307 = icmp eq i16 %r306, 0
  %r308 = add nuw nsw i64 %r286, 0
  %r309 = inttoptr i64 %r308 to ptr
  %r310 = load i32, ptr %r309, align 4
  %r311 = icmp ne i32 %r310, 0
  %r312 = icmp ne i32 %r310, -2
  %r313 = and i16 %r305, 512
  %r314 = icmp ne i16 %r313, 0
  %r315 = or i1 %r311, %r314
  %r316 = add nuw nsw i64 %r286, 4
  %r317 = inttoptr i64 %r316 to ptr
  %r318 = load i32, ptr %r317, align 4
  %r319 = add i32 %r318, -2147483648
  %r320 = icmp ult i32 %r319, 1073741824
  %r321 = zext i32 %r318 to i64
  %r322 = or i64 %r321, 4611686018427387904
  %r323 = select i1 %r320, i64 %r322, i64 0
  %r324 = getelementptr i64, ptr %r287, i64 0
  %r325 = load i64, ptr %r324, align 8
  %r326 = icmp eq i64 %r323, %r325
  %r327 = icmp ne i64 %r323, 0
  %r328 = getelementptr i64, ptr %r287, i64 1
  %r329 = load i64, ptr %r328, align 8
  %r330 = and i1 true, %r297
  %r331 = and i1 %r330, %r302
  %r332 = and i1 %r331, %r307
  %r333 = and i1 %r332, %r315
  %r334 = and i1 %r333, %r312
  %r335 = and i1 %r334, %r326
  %r336 = and i1 %r335, %r327
  br i1 %r336, label %put.pic.hit.56, label %put.pic.fallback.52

put.pic.guard2.49:                                ; preds = %put.pic.fallback.52
  %r338 = getelementptr i64, ptr %r287, i64 2
  %r339 = load i64, ptr %r338, align 8
  %r340 = getelementptr i64, ptr %r287, i64 3
  %r341 = load i64, ptr %r340, align 8
  %r342 = icmp eq i64 %r323, %r339
  %r343 = and i1 true, %r297
  %r344 = and i1 %r343, %r302
  %r345 = and i1 %r344, %r307
  %r346 = and i1 %r345, %r315
  %r347 = and i1 %r346, %r312
  %r348 = and i1 %r347, %r342
  %r349 = and i1 %r348, %r327
  br i1 %r349, label %put.pic.hit.56, label %put.pic.dispatch3.53

put.pic.guard3.50:                                ; preds = %put.pic.dispatch3.53
  %r351 = getelementptr i64, ptr %r287, i64 4
  %r352 = load i64, ptr %r351, align 8
  %r353 = getelementptr i64, ptr %r287, i64 5
  %r354 = load i64, ptr %r353, align 8
  %r355 = icmp eq i64 %r323, %r352
  %r356 = and i1 true, %r297
  %r357 = and i1 %r356, %r302
  %r358 = and i1 %r357, %r307
  %r359 = and i1 %r358, %r315
  %r360 = and i1 %r359, %r312
  %r361 = and i1 %r360, %r355
  %r362 = and i1 %r361, %r327
  br i1 %r362, label %put.pic.hit.56, label %put.pic.dispatch4.54

put.pic.guard4.51:                                ; preds = %put.pic.dispatch4.54
  %r364 = getelementptr i64, ptr %r287, i64 6
  %r365 = load i64, ptr %r364, align 8
  %r366 = getelementptr i64, ptr %r287, i64 7
  %r367 = load i64, ptr %r366, align 8
  %r368 = icmp eq i64 %r323, %r365
  %r369 = and i1 true, %r297
  %r370 = and i1 %r369, %r302
  %r371 = and i1 %r370, %r307
  %r372 = and i1 %r371, %r315
  %r373 = and i1 %r372, %r312
  %r374 = and i1 %r373, %r368
  %r375 = and i1 %r374, %r327
  br i1 %r375, label %put.pic.hit.56, label %put.pic.dispatch5.55

put.pic.fallback.52:                              ; preds = %put.pic.guard.48
  %r337 = icmp eq i64 %r325, 0
  br i1 %r337, label %put.pic.miss.60, label %put.pic.guard2.49

put.pic.dispatch3.53:                             ; preds = %put.pic.guard2.49
  %r350 = icmp eq i64 %r339, 0
  br i1 %r350, label %put.pic.miss2.61, label %put.pic.guard3.50

put.pic.dispatch4.54:                             ; preds = %put.pic.guard3.50
  %r363 = icmp eq i64 %r352, 0
  br i1 %r363, label %put.pic.miss3.62, label %put.pic.guard4.51

put.pic.dispatch5.55:                             ; preds = %put.pic.guard4.51
  %r376 = icmp eq i64 %r365, 0
  br i1 %r376, label %put.pic.miss4.63, label %put.pic.tail.64

put.pic.hit.56:                                   ; preds = %put.pic.guard4.51, %put.pic.guard3.50, %put.pic.guard2.49, %put.pic.guard.48
  %r377 = phi i64 [ %r329, %put.pic.guard.48 ], [ %r341, %put.pic.guard2.49 ], [ %r354, %put.pic.guard3.50 ], [ %r367, %put.pic.guard4.51 ]
  %r378 = and i64 %r377, 1073741824
  %r379 = icmp ne i64 %r378, 0
  br i1 %r379, label %put.pic.hit.overflow.66, label %put.pic.hit.inline.67

put.pic.hit.validate.57:                          ; preds = %put.pic.hit.inline.67
  %r389 = load double, ptr %r386, align 8
  %r390 = bitcast double %r389 to i64
  %r391 = icmp eq i64 %r390, 9222246136947933200
  br i1 %r391, label %put.pic.deleted.59, label %put.pic.hit.store.58

put.pic.hit.store.58:                             ; preds = %put.pic.hit.inline.67, %put.pic.hit.validate.57
  %r392 = trunc i64 %r377 to i32
  store double %r282, ptr %r386, align 8
  %r393 = bitcast double %r282 to i64
  %r394 = lshr i64 %r393, 48
  %r395 = icmp eq i64 %r394, 0
  %r396 = icmp uge i64 %r393, 4096
  %r397 = and i1 %r395, %r396
  %r398 = icmp eq i64 %r394, 32765
  %r399 = icmp eq i64 %r394, 32767
  %r400 = icmp eq i64 %r394, 32762
  %r401 = or i1 %r398, %r399
  %r402 = or i1 %r401, %r400
  %r403 = or i1 %r402, %r397
  br i1 %r403, label %put.pic.gc_bookkeeping.68, label %put.pic.gc_bookkeeping.done.69

put.pic.deleted.59:                               ; preds = %put.pic.hit.validate.57
  %statepoint_token141 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r280, i64 %r285, double %r282, i32 1, ptr @perry_ic_test_json_large_string_emitters_ts__1, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11311, ptr addrspace(1) %.11427, ptr addrspace(1) %.41369, ptr addrspace(1) %.4, ptr addrspace(1) %.01460) ]
  %r412142 = call double @llvm.experimental.gc.result.f64(token %statepoint_token141)
  %r8.0.relocated143 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 0, i32 0) ; (%.11311, %.11311)
  %rs4gc.s15.relocated144 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 1, i32 1) ; (%.11427, %.11427)
  %rs4gc.s13.relocated145 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 2, i32 2) ; (%.41369, %.41369)
  %rs4gc.s9.relocated146 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 3, i32 3) ; (%.4, %.4)
  %rs4gc.s18.relocated147 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 4, i32 4) ; (%.01460, %.01460)
  br label %put.pic.merge.65

put.pic.miss.60:                                  ; preds = %put.pic.hit.overflow.66, %put.pic.fallback.52, %put.dynic.merge.47
  %.11461 = phi ptr addrspace(1) [ %rs4gc.s18.relocated196, %put.pic.hit.overflow.66 ], [ %.01460, %put.pic.fallback.52 ], [ %.01460, %put.dynic.merge.47 ]
  %.21428 = phi ptr addrspace(1) [ %rs4gc.s15.relocated193, %put.pic.hit.overflow.66 ], [ %.11427, %put.pic.fallback.52 ], [ %.11427, %put.dynic.merge.47 ]
  %.51370 = phi ptr addrspace(1) [ %rs4gc.s13.relocated194, %put.pic.hit.overflow.66 ], [ %.41369, %put.pic.fallback.52 ], [ %.41369, %put.dynic.merge.47 ]
  %.21312 = phi ptr addrspace(1) [ %r8.0.relocated192, %put.pic.hit.overflow.66 ], [ %.11311, %put.pic.fallback.52 ], [ %.11311, %put.dynic.merge.47 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s9.relocated195, %put.pic.hit.overflow.66 ], [ %.4, %put.pic.fallback.52 ], [ %.4, %put.dynic.merge.47 ]
  %r4690.rs4i = ptrtoint ptr addrspace(1) %.11461 to i64
  %r4690.rs4o = call i64 asm "", "=r,0"(i64 %r4690.rs4i) #7
  %r4690 = bitcast i64 %r4690.rs4o to double
  %r4691 = load double, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  %r4692 = bitcast double %r4691 to i64
  %r4693 = and i64 %r4692, 281474976710655
  %r4694 = load double, ptr @test_json_large_string_emitters_ts_.str.4.handle, align 8
  %statepoint_token148 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r4690, i64 %r4693, double %r4694, i32 1, ptr @perry_ic_test_json_large_string_emitters_ts__1, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21312, ptr addrspace(1) %.21428, ptr addrspace(1) %.51370, ptr addrspace(1) %.5, ptr addrspace(1) %.11461) ]
  %r413149 = call double @llvm.experimental.gc.result.f64(token %statepoint_token148)
  %r8.0.relocated150 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token148, i32 0, i32 0) ; (%.21312, %.21312)
  %rs4gc.s15.relocated151 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token148, i32 1, i32 1) ; (%.21428, %.21428)
  %rs4gc.s13.relocated152 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token148, i32 2, i32 2) ; (%.51370, %.51370)
  %rs4gc.s9.relocated153 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token148, i32 3, i32 3) ; (%.5, %.5)
  %rs4gc.s18.relocated154 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token148, i32 4, i32 4) ; (%.11461, %.11461)
  br label %put.pic.merge.65

put.pic.miss2.61:                                 ; preds = %put.pic.dispatch3.53
  %statepoint_token155 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r280, i64 %r285, double %r282, i32 1, ptr @perry_ic_test_json_large_string_emitters_ts__1, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11311, ptr addrspace(1) %.11427, ptr addrspace(1) %.41369, ptr addrspace(1) %.4, ptr addrspace(1) %.01460) ]
  %r414156 = call double @llvm.experimental.gc.result.f64(token %statepoint_token155)
  %r8.0.relocated157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 0, i32 0) ; (%.11311, %.11311)
  %rs4gc.s15.relocated158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 1, i32 1) ; (%.11427, %.11427)
  %rs4gc.s13.relocated159 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 2, i32 2) ; (%.41369, %.41369)
  %rs4gc.s9.relocated160 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 3, i32 3) ; (%.4, %.4)
  %rs4gc.s18.relocated161 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 4, i32 4) ; (%.01460, %.01460)
  br label %put.pic.merge.65

put.pic.miss3.62:                                 ; preds = %put.pic.dispatch4.54
  %statepoint_token162 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r280, i64 %r285, double %r282, i32 1, ptr @perry_ic_test_json_large_string_emitters_ts__1, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11311, ptr addrspace(1) %.11427, ptr addrspace(1) %.41369, ptr addrspace(1) %.4, ptr addrspace(1) %.01460) ]
  %r415163 = call double @llvm.experimental.gc.result.f64(token %statepoint_token162)
  %r8.0.relocated164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token162, i32 0, i32 0) ; (%.11311, %.11311)
  %rs4gc.s15.relocated165 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token162, i32 1, i32 1) ; (%.11427, %.11427)
  %rs4gc.s13.relocated166 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token162, i32 2, i32 2) ; (%.41369, %.41369)
  %rs4gc.s9.relocated167 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token162, i32 3, i32 3) ; (%.4, %.4)
  %rs4gc.s18.relocated168 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token162, i32 4, i32 4) ; (%.01460, %.01460)
  br label %put.pic.merge.65

put.pic.miss4.63:                                 ; preds = %put.pic.dispatch5.55
  %statepoint_token169 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r280, i64 %r285, double %r282, i32 1, ptr @perry_ic_test_json_large_string_emitters_ts__1, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11311, ptr addrspace(1) %.11427, ptr addrspace(1) %.41369, ptr addrspace(1) %.4, ptr addrspace(1) %.01460) ]
  %r416170 = call double @llvm.experimental.gc.result.f64(token %statepoint_token169)
  %r8.0.relocated171 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 0, i32 0) ; (%.11311, %.11311)
  %rs4gc.s15.relocated172 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 1, i32 1) ; (%.11427, %.11427)
  %rs4gc.s13.relocated173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 2, i32 2) ; (%.41369, %.41369)
  %rs4gc.s9.relocated174 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 3, i32 3) ; (%.4, %.4)
  %rs4gc.s18.relocated175 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 4, i32 4) ; (%.01460, %.01460)
  br label %put.pic.merge.65

put.pic.tail.64:                                  ; preds = %put.pic.dispatch5.55
  %statepoint_token176 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, i64, double, i32)) @js_put_value_set_ic_poly_tail, i32 5, i32 0, ptr @perry_ic_test_json_large_string_emitters_ts__1_poly_tail, double %r280, i64 %r285, double %r282, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11311, ptr addrspace(1) %.11427, ptr addrspace(1) %.41369, ptr addrspace(1) %.4, ptr addrspace(1) %.01460) ]
  %r417177 = call double @llvm.experimental.gc.result.f64(token %statepoint_token176)
  %r8.0.relocated178 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token176, i32 0, i32 0) ; (%.11311, %.11311)
  %rs4gc.s15.relocated179 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token176, i32 1, i32 1) ; (%.11427, %.11427)
  %rs4gc.s13.relocated180 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token176, i32 2, i32 2) ; (%.41369, %.41369)
  %rs4gc.s9.relocated181 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token176, i32 3, i32 3) ; (%.4, %.4)
  %rs4gc.s18.relocated182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token176, i32 4, i32 4) ; (%.01460, %.01460)
  br label %put.pic.merge.65

put.pic.merge.65:                                 ; preds = %put.pic.gc_bookkeeping.done.69, %put.pic.hit.overflow.66, %put.pic.tail.64, %put.pic.miss4.63, %put.pic.miss3.62, %put.pic.miss2.61, %put.pic.miss.60, %put.pic.deleted.59
  %.21462 = phi ptr addrspace(1) [ %rs4gc.s18.relocated196, %put.pic.hit.overflow.66 ], [ %rs4gc.s18.relocated154, %put.pic.miss.60 ], [ %rs4gc.s18.relocated147, %put.pic.deleted.59 ], [ %.01460, %put.pic.gc_bookkeeping.done.69 ], [ %rs4gc.s18.relocated161, %put.pic.miss2.61 ], [ %rs4gc.s18.relocated168, %put.pic.miss3.62 ], [ %rs4gc.s18.relocated175, %put.pic.miss4.63 ], [ %rs4gc.s18.relocated182, %put.pic.tail.64 ]
  %.31429 = phi ptr addrspace(1) [ %rs4gc.s15.relocated193, %put.pic.hit.overflow.66 ], [ %rs4gc.s15.relocated151, %put.pic.miss.60 ], [ %rs4gc.s15.relocated144, %put.pic.deleted.59 ], [ %.11427, %put.pic.gc_bookkeeping.done.69 ], [ %rs4gc.s15.relocated158, %put.pic.miss2.61 ], [ %rs4gc.s15.relocated165, %put.pic.miss3.62 ], [ %rs4gc.s15.relocated172, %put.pic.miss4.63 ], [ %rs4gc.s15.relocated179, %put.pic.tail.64 ]
  %.61371 = phi ptr addrspace(1) [ %rs4gc.s13.relocated194, %put.pic.hit.overflow.66 ], [ %rs4gc.s13.relocated152, %put.pic.miss.60 ], [ %rs4gc.s13.relocated145, %put.pic.deleted.59 ], [ %.41369, %put.pic.gc_bookkeeping.done.69 ], [ %rs4gc.s13.relocated159, %put.pic.miss2.61 ], [ %rs4gc.s13.relocated166, %put.pic.miss3.62 ], [ %rs4gc.s13.relocated173, %put.pic.miss4.63 ], [ %rs4gc.s13.relocated180, %put.pic.tail.64 ]
  %.31313 = phi ptr addrspace(1) [ %r8.0.relocated192, %put.pic.hit.overflow.66 ], [ %r8.0.relocated150, %put.pic.miss.60 ], [ %r8.0.relocated143, %put.pic.deleted.59 ], [ %.11311, %put.pic.gc_bookkeeping.done.69 ], [ %r8.0.relocated157, %put.pic.miss2.61 ], [ %r8.0.relocated164, %put.pic.miss3.62 ], [ %r8.0.relocated171, %put.pic.miss4.63 ], [ %r8.0.relocated178, %put.pic.tail.64 ]
  %.6 = phi ptr addrspace(1) [ %rs4gc.s9.relocated195, %put.pic.hit.overflow.66 ], [ %rs4gc.s9.relocated153, %put.pic.miss.60 ], [ %rs4gc.s9.relocated146, %put.pic.deleted.59 ], [ %.4, %put.pic.gc_bookkeeping.done.69 ], [ %rs4gc.s9.relocated160, %put.pic.miss2.61 ], [ %rs4gc.s9.relocated167, %put.pic.miss3.62 ], [ %rs4gc.s9.relocated174, %put.pic.miss4.63 ], [ %rs4gc.s9.relocated181, %put.pic.tail.64 ]
  %r418 = phi double [ %r282, %put.pic.gc_bookkeeping.done.69 ], [ %r282, %put.pic.hit.overflow.66 ], [ %r412142, %put.pic.deleted.59 ], [ %r413149, %put.pic.miss.60 ], [ %r414156, %put.pic.miss2.61 ], [ %r415163, %put.pic.miss3.62 ], [ %r416170, %put.pic.miss4.63 ], [ %r417177, %put.pic.tail.64 ]
  %statepoint_token183 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31313, ptr addrspace(1) %.31429, ptr addrspace(1) %.61371, ptr addrspace(1) %.6, ptr addrspace(1) %.21462) ]
  %r419184 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token183)
  %r8.0.relocated185 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 0, i32 0) ; (%.31313, %.31313)
  %rs4gc.s15.relocated186 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 1, i32 1) ; (%.31429, %.31429)
  %rs4gc.s13.relocated187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 2, i32 2) ; (%.61371, %.61371)
  %rs4gc.s9.relocated188 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 3, i32 3) ; (%.6, %.6)
  %rs4gc.s18.relocated189 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token183, i32 4, i32 4) ; (%.21462, %.21462)
  %rs4gc.s19 = inttoptr i64 %r419184 to ptr addrspace(1)
  %r420.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r420 = call i64 asm "", "=r,0"(i64 %r420.rs4i) #7
  %r421 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r422 = icmp ne i32 %r421, 0
  br i1 %r422, label %shadow.root.barrier.71, label %shadow.root.barrier.done.72

put.pic.hit.overflow.66:                          ; preds = %put.pic.hit.56
  %r380 = trunc i64 %r377 to i32
  %statepoint_token190 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (double, i64, i32, double)) @js_put_value_set_ic_overflow_store, i32 4, i32 0, double %r280, i64 %r323, i32 %r380, double %r282, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11311, ptr addrspace(1) %.11427, ptr addrspace(1) %.41369, ptr addrspace(1) %.4, ptr addrspace(1) %.01460) ]
  %r381191 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token190)
  %r8.0.relocated192 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token190, i32 0, i32 0) ; (%.11311, %.11311)
  %rs4gc.s15.relocated193 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token190, i32 1, i32 1) ; (%.11427, %.11427)
  %rs4gc.s13.relocated194 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token190, i32 2, i32 2) ; (%.41369, %.41369)
  %rs4gc.s9.relocated195 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token190, i32 3, i32 3) ; (%.4, %.4)
  %rs4gc.s18.relocated196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token190, i32 4, i32 4) ; (%.01460, %.01460)
  %r382 = icmp ne i32 %r381191, 0
  br i1 %r382, label %put.pic.merge.65, label %put.pic.miss.60

put.pic.hit.inline.67:                            ; preds = %put.pic.hit.56
  %r383 = shl i64 %r377, 3
  %r384 = add nuw nsw i64 %r286, 16
  %r385 = add i64 %r384, %r383
  %r386 = inttoptr i64 %r385 to ptr
  %r387 = and i16 %r305, 1024
  %r388 = icmp ne i16 %r387, 0
  br i1 %r388, label %put.pic.hit.validate.57, label %put.pic.hit.store.58

put.pic.gc_bookkeeping.68:                        ; preds = %put.pic.hit.store.58
  call void @js_string_addref_if_heap_string(double %r282) #7
  %r4685.rs4i = ptrtoint ptr addrspace(1) %.01460 to i64
  %r4685.rs4o = call i64 asm "", "=r,0"(i64 %r4685.rs4i) #7
  %r4685 = bitcast i64 %r4685.rs4o to double
  %r4686 = bitcast double %r4685 to i64
  %r4687 = and i64 %r4686, 281474976710655
  %r4688 = load double, ptr @test_json_large_string_emitters_ts_.str.4.handle, align 8
  %r4689 = bitcast double %r4688 to i64
  call void @js_gc_note_slot_layout(i64 %r4687, i32 %r392, i64 %r4689) #7
  %r4682.rs4i = ptrtoint ptr addrspace(1) %.01460 to i64
  %r4682.rs4o = call i64 asm "", "=r,0"(i64 %r4682.rs4i) #7
  %r4682 = bitcast i64 %r4682.rs4o to double
  %r4683 = bitcast double %r4682 to i64
  %r4684 = and i64 %r4683, 281474976710655
  %r404 = sub nsw i64 %r4684, 7
  %r405 = inttoptr i64 %r404 to ptr
  %r406 = load i8, ptr %r405, align 1
  %r407 = and i8 %r406, 32
  %r408 = icmp ne i8 %r407, 0
  %r409 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r410 = icmp ne i32 %r409, 0
  %r411 = or i1 %r408, %r410
  br i1 %r411, label %put.pic.barrier.70, label %put.pic.gc_bookkeeping.done.69

put.pic.gc_bookkeeping.done.69:                   ; preds = %put.pic.barrier.70, %put.pic.gc_bookkeeping.68, %put.pic.hit.store.58
  br label %put.pic.merge.65

put.pic.barrier.70:                               ; preds = %put.pic.gc_bookkeeping.68
  %r4678.rs4i = ptrtoint ptr addrspace(1) %.01460 to i64
  %r4678.rs4o = call i64 asm "", "=r,0"(i64 %r4678.rs4i) #7
  %r4678 = bitcast i64 %r4678.rs4o to double
  %r4679 = bitcast double %r4678 to i64
  %r4680 = load double, ptr @test_json_large_string_emitters_ts_.str.4.handle, align 8
  %r4681 = bitcast double %r4680 to i64
  call void @js_write_barrier_slot(i64 %r4679, i64 %r385, i64 %r4681) #7
  br label %put.pic.gc_bookkeeping.done.69

shadow.root.barrier.71:                           ; preds = %put.pic.merge.65
  call void @js_write_barrier_root_nanbox(i64 %r420) #7
  br label %shadow.root.barrier.done.72

shadow.root.barrier.done.72:                      ; preds = %shadow.root.barrier.71, %put.pic.merge.65
  %r423 = load double, ptr @test_json_large_string_emitters_ts_.str.5.handle, align 8
  %r424.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r424 = call i64 asm "", "=r,0"(i64 %r424.rs4i) #7
  %statepoint_token197 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r424, double %r423, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated185, ptr addrspace(1) %rs4gc.s15.relocated186, ptr addrspace(1) %rs4gc.s13.relocated187, ptr addrspace(1) %rs4gc.s9.relocated188, ptr addrspace(1) %rs4gc.s18.relocated189) ]
  %r425198 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token197)
  %r8.0.relocated199 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token197, i32 0, i32 0) ; (%r8.0.relocated185, %r8.0.relocated185)
  %rs4gc.s15.relocated200 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token197, i32 1, i32 1) ; (%rs4gc.s15.relocated186, %rs4gc.s15.relocated186)
  %rs4gc.s13.relocated201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token197, i32 2, i32 2) ; (%rs4gc.s13.relocated187, %rs4gc.s13.relocated187)
  %rs4gc.s9.relocated202 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token197, i32 3, i32 3) ; (%rs4gc.s9.relocated188, %rs4gc.s9.relocated188)
  %rs4gc.s18.relocated203 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token197, i32 4, i32 4) ; (%rs4gc.s18.relocated189, %rs4gc.s18.relocated189)
  %rs4gc.s20 = inttoptr i64 %r425198 to ptr addrspace(1)
  %r426.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r426 = call i64 asm "", "=r,0"(i64 %r426.rs4i) #7
  %r427 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r428 = icmp ne i32 %r427, 0
  br i1 %r428, label %shadow.root.barrier.73, label %shadow.root.barrier.done.74

shadow.root.barrier.73:                           ; preds = %shadow.root.barrier.done.72
  call void @js_write_barrier_root_nanbox(i64 %r426) #7
  br label %shadow.root.barrier.done.74

shadow.root.barrier.done.74:                      ; preds = %shadow.root.barrier.73, %shadow.root.barrier.done.72
  %r429.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated203 to i64
  %r429.rs4o = call i64 asm "", "=r,0"(i64 %r429.rs4i) #7
  %r429 = bitcast i64 %r429.rs4o to double
  %statepoint_token204 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r429, double 0x7FFC000000000002, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated199, ptr addrspace(1) %rs4gc.s15.relocated200, ptr addrspace(1) %rs4gc.s13.relocated201, ptr addrspace(1) %rs4gc.s9.relocated202, ptr addrspace(1) %rs4gc.s18.relocated203, ptr addrspace(1) %rs4gc.s20) ]
  %r430205 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token204)
  %r8.0.relocated206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 0, i32 0) ; (%r8.0.relocated199, %r8.0.relocated199)
  %rs4gc.s15.relocated207 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 1, i32 1) ; (%rs4gc.s15.relocated200, %rs4gc.s15.relocated200)
  %rs4gc.s13.relocated208 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 2, i32 2) ; (%rs4gc.s13.relocated201, %rs4gc.s13.relocated201)
  %rs4gc.s9.relocated209 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 3, i32 3) ; (%rs4gc.s9.relocated202, %rs4gc.s9.relocated202)
  %rs4gc.s18.relocated210 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 4, i32 4) ; (%rs4gc.s18.relocated203, %rs4gc.s18.relocated203)
  %rs4gc.s20.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token204, i32 5, i32 5) ; (%rs4gc.s20, %rs4gc.s20)
  %r431 = bitcast i64 %r430205 to double
  %r432.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20.relocated to i64
  %r432 = call i64 asm "", "=r,0"(i64 %r432.rs4i) #7
  %statepoint_token211 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r432, double %r431, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated206, ptr addrspace(1) %rs4gc.s15.relocated207, ptr addrspace(1) %rs4gc.s13.relocated208, ptr addrspace(1) %rs4gc.s9.relocated209, ptr addrspace(1) %rs4gc.s18.relocated210) ]
  %r433212 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token211)
  %r8.0.relocated213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 0, i32 0) ; (%r8.0.relocated206, %r8.0.relocated206)
  %rs4gc.s15.relocated214 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 1, i32 1) ; (%rs4gc.s15.relocated207, %rs4gc.s15.relocated207)
  %rs4gc.s13.relocated215 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 2, i32 2) ; (%rs4gc.s13.relocated208, %rs4gc.s13.relocated208)
  %rs4gc.s9.relocated216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 3, i32 3) ; (%rs4gc.s9.relocated209, %rs4gc.s9.relocated209)
  %rs4gc.s18.relocated217 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 4, i32 4) ; (%rs4gc.s18.relocated210, %rs4gc.s18.relocated210)
  %rs4gc.s21 = inttoptr i64 %r433212 to ptr addrspace(1)
  %r434.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r434 = call i64 asm "", "=r,0"(i64 %r434.rs4i) #7
  %r435 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r436 = icmp ne i32 %r435, 0
  br i1 %r436, label %shadow.root.barrier.75, label %shadow.root.barrier.done.76

shadow.root.barrier.75:                           ; preds = %shadow.root.barrier.done.74
  call void @js_write_barrier_root_nanbox(i64 %r434) #7
  br label %shadow.root.barrier.done.76

shadow.root.barrier.done.76:                      ; preds = %shadow.root.barrier.75, %shadow.root.barrier.done.74
  %r437.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r437 = call i64 asm "", "=r,0"(i64 %r437.rs4i) #7
  %statepoint_token218 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r437, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated213, ptr addrspace(1) %rs4gc.s15.relocated214, ptr addrspace(1) %rs4gc.s13.relocated215, ptr addrspace(1) %rs4gc.s9.relocated216, ptr addrspace(1) %rs4gc.s18.relocated217) ]
  %r8.0.relocated219 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 0, i32 0) ; (%r8.0.relocated213, %r8.0.relocated213)
  %rs4gc.s15.relocated220 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 1, i32 1) ; (%rs4gc.s15.relocated214, %rs4gc.s15.relocated214)
  %rs4gc.s13.relocated221 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 2, i32 2) ; (%rs4gc.s13.relocated215, %rs4gc.s13.relocated215)
  %rs4gc.s9.relocated222 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 3, i32 3) ; (%rs4gc.s9.relocated216, %rs4gc.s9.relocated216)
  %rs4gc.s18.relocated223 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 4, i32 4) ; (%rs4gc.s18.relocated217, %rs4gc.s18.relocated217)
  %statepoint_token224 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated219, ptr addrspace(1) %rs4gc.s15.relocated220, ptr addrspace(1) %rs4gc.s13.relocated221, ptr addrspace(1) %rs4gc.s9.relocated222, ptr addrspace(1) %rs4gc.s18.relocated223) ]
  %r438225 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token224)
  %r8.0.relocated226 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token224, i32 0, i32 0) ; (%r8.0.relocated219, %r8.0.relocated219)
  %rs4gc.s15.relocated227 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token224, i32 1, i32 1) ; (%rs4gc.s15.relocated220, %rs4gc.s15.relocated220)
  %rs4gc.s13.relocated228 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token224, i32 2, i32 2) ; (%rs4gc.s13.relocated221, %rs4gc.s13.relocated221)
  %rs4gc.s9.relocated229 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token224, i32 3, i32 3) ; (%rs4gc.s9.relocated222, %rs4gc.s9.relocated222)
  %rs4gc.s18.relocated230 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token224, i32 4, i32 4) ; (%rs4gc.s18.relocated223, %rs4gc.s18.relocated223)
  %rs4gc.s22 = inttoptr i64 %r438225 to ptr addrspace(1)
  %r439.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r439 = call i64 asm "", "=r,0"(i64 %r439.rs4i) #7
  %r440 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r441 = icmp ne i32 %r440, 0
  br i1 %r441, label %shadow.root.barrier.77, label %shadow.root.barrier.done.78

shadow.root.barrier.77:                           ; preds = %shadow.root.barrier.done.76
  call void @js_write_barrier_root_nanbox(i64 %r439) #7
  br label %shadow.root.barrier.done.78

shadow.root.barrier.done.78:                      ; preds = %shadow.root.barrier.77, %shadow.root.barrier.done.76
  %r442 = load double, ptr @test_json_large_string_emitters_ts_.str.6.handle, align 8
  %r443.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r443 = call i64 asm "", "=r,0"(i64 %r443.rs4i) #7
  %statepoint_token231 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r443, double %r442, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated226, ptr addrspace(1) %rs4gc.s15.relocated227, ptr addrspace(1) %rs4gc.s13.relocated228, ptr addrspace(1) %rs4gc.s9.relocated229, ptr addrspace(1) %rs4gc.s18.relocated230) ]
  %r444232 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token231)
  %r8.0.relocated233 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token231, i32 0, i32 0) ; (%r8.0.relocated226, %r8.0.relocated226)
  %rs4gc.s15.relocated234 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token231, i32 1, i32 1) ; (%rs4gc.s15.relocated227, %rs4gc.s15.relocated227)
  %rs4gc.s13.relocated235 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token231, i32 2, i32 2) ; (%rs4gc.s13.relocated228, %rs4gc.s13.relocated228)
  %rs4gc.s9.relocated236 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token231, i32 3, i32 3) ; (%rs4gc.s9.relocated229, %rs4gc.s9.relocated229)
  %rs4gc.s18.relocated237 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token231, i32 4, i32 4) ; (%rs4gc.s18.relocated230, %rs4gc.s18.relocated230)
  %rs4gc.s23 = inttoptr i64 %r444232 to ptr addrspace(1)
  %r445.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r445 = call i64 asm "", "=r,0"(i64 %r445.rs4i) #7
  %r446 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r447 = icmp ne i32 %r446, 0
  br i1 %r447, label %shadow.root.barrier.79, label %shadow.root.barrier.done.80

shadow.root.barrier.79:                           ; preds = %shadow.root.barrier.done.78
  call void @js_write_barrier_root_nanbox(i64 %r445) #7
  br label %shadow.root.barrier.done.80

shadow.root.barrier.done.80:                      ; preds = %shadow.root.barrier.79, %shadow.root.barrier.done.78
  %r448.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated237 to i64
  %r448.rs4o = call i64 asm "", "=r,0"(i64 %r448.rs4i) #7
  %r448 = bitcast i64 %r448.rs4o to double
  %r449.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15.relocated234 to i64
  %r449.rs4o = call i64 asm "", "=r,0"(i64 %r449.rs4i) #7
  %r449 = bitcast i64 %r449.rs4o to double
  %r450 = load double, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  br label %arena_state.init.81

arena_state.init.81:                              ; preds = %shadow.root.barrier.done.80
  %r454 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r455 = icmp ne i64 %r454, -1
  br i1 %r455, label %arena_state.hot_tls.tsd.83, label %arena_state.hot_tls.slow.85

arena_state.ready.82:                             ; preds = %arena_state.hot_tls.resolved.87
  %r470 = getelementptr i8, ptr %r468, i64 8
  %r471 = load i64, ptr %r470, align 8
  %r472 = add i64 %r471, 32
  %r473 = getelementptr i8, ptr %r468, i64 16
  %r474 = load i64, ptr %r473, align 8
  %r475 = icmp ule i64 %r472, %r474
  br i1 %r475, label %arrlit.fast.88, label %arrlit.slow.89

arena_state.hot_tls.tsd.83:                       ; preds = %arena_state.init.81
  %r456 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #7
  %r457 = and i64 %r456, -8
  %r458 = shl i64 %r454, 3
  %r459 = add i64 %r457, %r458
  %r460 = inttoptr i64 %r459 to ptr
  %r461 = load ptr, ptr %r460, align 8
  %r462 = icmp ne ptr %r461, null
  br i1 %r462, label %arena_state.hot_tls.fast.84, label %arena_state.hot_tls.slow.85

arena_state.hot_tls.fast.84:                      ; preds = %arena_state.hot_tls.tsd.83
  %r463 = getelementptr i8, ptr %r461, i64 8
  %r464 = load ptr, ptr %r463, align 8
  %r465 = load ptr, ptr %r464, align 8
  %r466 = icmp ne ptr %r465, null
  br i1 %r466, label %arena_state.hot_tls.ready.86, label %arena_state.hot_tls.slow.85

arena_state.hot_tls.slow.85:                      ; preds = %arena_state.hot_tls.fast.84, %arena_state.hot_tls.tsd.83, %arena_state.init.81
  %statepoint_token238 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated233, ptr addrspace(1) %rs4gc.s15.relocated234, ptr addrspace(1) %rs4gc.s13.relocated235, ptr addrspace(1) %rs4gc.s9.relocated236, ptr addrspace(1) %rs4gc.s18.relocated237, ptr addrspace(1) %rs4gc.s23) ]
  %r467239 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token238)
  %r8.0.relocated240 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 0, i32 0) ; (%r8.0.relocated233, %r8.0.relocated233)
  %rs4gc.s15.relocated241 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 1, i32 1) ; (%rs4gc.s15.relocated234, %rs4gc.s15.relocated234)
  %rs4gc.s13.relocated242 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 2, i32 2) ; (%rs4gc.s13.relocated235, %rs4gc.s13.relocated235)
  %rs4gc.s9.relocated243 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 3, i32 3) ; (%rs4gc.s9.relocated236, %rs4gc.s9.relocated236)
  %rs4gc.s18.relocated244 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 4, i32 4) ; (%rs4gc.s18.relocated237, %rs4gc.s18.relocated237)
  %rs4gc.s23.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 5, i32 5) ; (%rs4gc.s23, %rs4gc.s23)
  br label %arena_state.hot_tls.resolved.87

arena_state.hot_tls.ready.86:                     ; preds = %arena_state.hot_tls.fast.84
  br label %arena_state.hot_tls.resolved.87

arena_state.hot_tls.resolved.87:                  ; preds = %arena_state.hot_tls.ready.86, %arena_state.hot_tls.slow.85
  %.01480 = phi ptr addrspace(1) [ %rs4gc.s23, %arena_state.hot_tls.ready.86 ], [ %rs4gc.s23.relocated, %arena_state.hot_tls.slow.85 ]
  %.31463 = phi ptr addrspace(1) [ %rs4gc.s18.relocated237, %arena_state.hot_tls.ready.86 ], [ %rs4gc.s18.relocated244, %arena_state.hot_tls.slow.85 ]
  %.41430 = phi ptr addrspace(1) [ %rs4gc.s15.relocated234, %arena_state.hot_tls.ready.86 ], [ %rs4gc.s15.relocated241, %arena_state.hot_tls.slow.85 ]
  %.71372 = phi ptr addrspace(1) [ %rs4gc.s13.relocated235, %arena_state.hot_tls.ready.86 ], [ %rs4gc.s13.relocated242, %arena_state.hot_tls.slow.85 ]
  %.41314 = phi ptr addrspace(1) [ %r8.0.relocated233, %arena_state.hot_tls.ready.86 ], [ %r8.0.relocated240, %arena_state.hot_tls.slow.85 ]
  %.7 = phi ptr addrspace(1) [ %rs4gc.s9.relocated236, %arena_state.hot_tls.ready.86 ], [ %rs4gc.s9.relocated243, %arena_state.hot_tls.slow.85 ]
  %r468 = phi ptr [ %r464, %arena_state.hot_tls.ready.86 ], [ %r467239, %arena_state.hot_tls.slow.85 ]
  br label %arena_state.ready.82

arrlit.fast.88:                                   ; preds = %arena_state.ready.82
  store i64 %r472, ptr %r470, align 8
  %r476 = load ptr, ptr %r468, align 8
  %r477 = getelementptr i8, ptr %r476, i64 %r471
  br label %arrlit.merge.90

arrlit.slow.89:                                   ; preds = %arena_state.ready.82
  %statepoint_token245 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r468, i64 32, i64 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41314, ptr addrspace(1) %.41430, ptr addrspace(1) %.71372, ptr addrspace(1) %.7, ptr addrspace(1) %.31463, ptr addrspace(1) %.01480) ]
  %r478246 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token245)
  %r8.0.relocated247 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token245, i32 0, i32 0) ; (%.41314, %.41314)
  %rs4gc.s15.relocated248 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token245, i32 1, i32 1) ; (%.41430, %.41430)
  %rs4gc.s13.relocated249 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token245, i32 2, i32 2) ; (%.71372, %.71372)
  %rs4gc.s9.relocated250 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token245, i32 3, i32 3) ; (%.7, %.7)
  %rs4gc.s18.relocated251 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token245, i32 4, i32 4) ; (%.31463, %.31463)
  %rs4gc.s23.relocated252 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token245, i32 5, i32 5) ; (%.01480, %.01480)
  br label %arrlit.merge.90

arrlit.merge.90:                                  ; preds = %arrlit.slow.89, %arrlit.fast.88
  %.11481 = phi ptr addrspace(1) [ %.01480, %arrlit.fast.88 ], [ %rs4gc.s23.relocated252, %arrlit.slow.89 ]
  %.41464 = phi ptr addrspace(1) [ %.31463, %arrlit.fast.88 ], [ %rs4gc.s18.relocated251, %arrlit.slow.89 ]
  %.51431 = phi ptr addrspace(1) [ %.41430, %arrlit.fast.88 ], [ %rs4gc.s15.relocated248, %arrlit.slow.89 ]
  %.81373 = phi ptr addrspace(1) [ %.71372, %arrlit.fast.88 ], [ %rs4gc.s13.relocated249, %arrlit.slow.89 ]
  %.51315 = phi ptr addrspace(1) [ %.41314, %arrlit.fast.88 ], [ %r8.0.relocated247, %arrlit.slow.89 ]
  %.8 = phi ptr addrspace(1) [ %.7, %arrlit.fast.88 ], [ %rs4gc.s9.relocated250, %arrlit.slow.89 ]
  %r479 = phi ptr [ %r477, %arrlit.fast.88 ], [ %r478246, %arrlit.slow.89 ]
  store i64 138512695809, ptr %r479, align 8
  %r480 = getelementptr i8, ptr %r479, i64 8
  store i64 8589934594, ptr %r480, align 8
  %r481 = getelementptr i8, ptr %r479, i64 8
  %r482 = ptrtoint ptr %r481 to i64
  %r483 = getelementptr inbounds nuw i8, ptr %r479, i64 16
  %r4677.rs4i = ptrtoint ptr addrspace(1) %.51431 to i64
  %r4677.rs4o = call i64 asm "", "=r,0"(i64 %r4677.rs4i) #7
  %r4677 = bitcast i64 %r4677.rs4o to double
  store double %r4677, ptr %r483, align 8
  %r4676.rs4i = ptrtoint ptr addrspace(1) %.51431 to i64
  %r4676.rs4o = call i64 asm "", "=r,0"(i64 %r4676.rs4i) #7
  %r4676 = bitcast i64 %r4676.rs4o to double
  call void @js_string_addref_if_heap_string(double %r4676) #7
  %r4675.rs4i = ptrtoint ptr addrspace(1) %.51431 to i64
  %r4675.rs4o = call i64 asm "", "=r,0"(i64 %r4675.rs4i) #7
  %r4675 = bitcast i64 %r4675.rs4o to double
  %r484 = bitcast double %r4675 to i64
  %r4673.rs4i = ptrtoint ptr addrspace(1) %.51431 to i64
  %r4673.rs4o = call i64 asm "", "=r,0"(i64 %r4673.rs4i) #7
  %r4673 = bitcast i64 %r4673.rs4o to double
  %r4674 = bitcast double %r4673 to i64
  call void @js_gc_note_slot_layout(i64 %r482, i32 0, i64 %r4674) #7
  %r485 = getelementptr inbounds nuw i8, ptr %r479, i64 24
  %r4672 = load double, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  store double %r4672, ptr %r485, align 8
  %r4671 = load double, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  call void @js_string_addref_if_heap_string(double %r4671) #7
  %r4670 = load double, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  %r486 = bitcast double %r4670 to i64
  %r4668 = load double, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  %r4669 = bitcast double %r4668 to i64
  call void @js_gc_note_slot_layout(i64 %r482, i32 1, i64 %r4669) #7
  %r487 = or i64 %r482, 9222527611924643840
  %r488 = bitcast i64 %r487 to double
  %r4667.rs4i = ptrtoint ptr addrspace(1) %.41464 to i64
  %r4667.rs4o = call i64 asm "", "=r,0"(i64 %r4667.rs4i) #7
  %r4667 = bitcast i64 %r4667.rs4o to double
  %statepoint_token253 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4667, double %r488, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.51315, ptr addrspace(1) %.51431, ptr addrspace(1) %.81373, ptr addrspace(1) %.8, ptr addrspace(1) %.41464, ptr addrspace(1) %.11481) ]
  %r489254 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token253)
  %r8.0.relocated255 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token253, i32 0, i32 0) ; (%.51315, %.51315)
  %rs4gc.s15.relocated256 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token253, i32 1, i32 1) ; (%.51431, %.51431)
  %rs4gc.s13.relocated257 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token253, i32 2, i32 2) ; (%.81373, %.81373)
  %rs4gc.s9.relocated258 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token253, i32 3, i32 3) ; (%.8, %.8)
  %rs4gc.s18.relocated259 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token253, i32 4, i32 4) ; (%.41464, %.41464)
  %rs4gc.s23.relocated260 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token253, i32 5, i32 5) ; (%.11481, %.11481)
  %r490 = bitcast i64 %r489254 to double
  %r491.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23.relocated260 to i64
  %r491 = call i64 asm "", "=r,0"(i64 %r491.rs4i) #7
  %statepoint_token261 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r491, double %r490, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated255, ptr addrspace(1) %rs4gc.s15.relocated256, ptr addrspace(1) %rs4gc.s13.relocated257, ptr addrspace(1) %rs4gc.s9.relocated258, ptr addrspace(1) %rs4gc.s18.relocated259) ]
  %r492262 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token261)
  %r8.0.relocated263 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token261, i32 0, i32 0) ; (%r8.0.relocated255, %r8.0.relocated255)
  %rs4gc.s15.relocated264 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token261, i32 1, i32 1) ; (%rs4gc.s15.relocated256, %rs4gc.s15.relocated256)
  %rs4gc.s13.relocated265 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token261, i32 2, i32 2) ; (%rs4gc.s13.relocated257, %rs4gc.s13.relocated257)
  %rs4gc.s9.relocated266 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token261, i32 3, i32 3) ; (%rs4gc.s9.relocated258, %rs4gc.s9.relocated258)
  %rs4gc.s18.relocated267 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token261, i32 4, i32 4) ; (%rs4gc.s18.relocated259, %rs4gc.s18.relocated259)
  %rs4gc.s24 = inttoptr i64 %r492262 to ptr addrspace(1)
  %r493.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r493 = call i64 asm "", "=r,0"(i64 %r493.rs4i) #7
  %r494 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r495 = icmp ne i32 %r494, 0
  br i1 %r495, label %shadow.root.barrier.91, label %shadow.root.barrier.done.92

shadow.root.barrier.91:                           ; preds = %arrlit.merge.90
  call void @js_write_barrier_root_nanbox(i64 %r493) #7
  br label %shadow.root.barrier.done.92

shadow.root.barrier.done.92:                      ; preds = %shadow.root.barrier.91, %arrlit.merge.90
  %r496.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r496 = call i64 asm "", "=r,0"(i64 %r496.rs4i) #7
  %statepoint_token268 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r496, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated267, ptr addrspace(1) %r8.0.relocated263, ptr addrspace(1) %rs4gc.s15.relocated264, ptr addrspace(1) %rs4gc.s13.relocated265, ptr addrspace(1) %rs4gc.s9.relocated266) ]
  %rs4gc.s18.relocated269 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 0, i32 0) ; (%rs4gc.s18.relocated267, %rs4gc.s18.relocated267)
  %r8.0.relocated270 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 1, i32 1) ; (%r8.0.relocated263, %r8.0.relocated263)
  %rs4gc.s15.relocated271 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 2, i32 2) ; (%rs4gc.s15.relocated264, %rs4gc.s15.relocated264)
  %rs4gc.s13.relocated272 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 3, i32 3) ; (%rs4gc.s13.relocated265, %rs4gc.s13.relocated265)
  %rs4gc.s9.relocated273 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token268, i32 4, i32 4) ; (%rs4gc.s9.relocated266, %rs4gc.s9.relocated266)
  %statepoint_token274 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated269, ptr addrspace(1) %r8.0.relocated270, ptr addrspace(1) %rs4gc.s15.relocated271, ptr addrspace(1) %rs4gc.s13.relocated272, ptr addrspace(1) %rs4gc.s9.relocated273) ]
  %r498275 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token274)
  %rs4gc.s18.relocated276 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 0, i32 0) ; (%rs4gc.s18.relocated269, %rs4gc.s18.relocated269)
  %r8.0.relocated277 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 1, i32 1) ; (%r8.0.relocated270, %r8.0.relocated270)
  %rs4gc.s15.relocated278 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 2, i32 2) ; (%rs4gc.s15.relocated271, %rs4gc.s15.relocated271)
  %rs4gc.s13.relocated279 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 3, i32 3) ; (%rs4gc.s13.relocated272, %rs4gc.s13.relocated272)
  %rs4gc.s9.relocated280 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 4, i32 4) ; (%rs4gc.s9.relocated273, %rs4gc.s9.relocated273)
  %r499 = or i64 %r498275, 9222527611924643840
  %r500 = bitcast i64 %r499 to double
  %rs4gc.b25 = bitcast double %r500 to i64
  %rs4gc.s25 = inttoptr i64 %rs4gc.b25 to ptr addrspace(1)
  %r501.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r501 = call i64 asm "", "=r,0"(i64 %r501.rs4i) #7
  %r502 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r503 = icmp ne i32 %r502, 0
  br i1 %r503, label %shadow.root.barrier.93, label %shadow.root.barrier.done.94

shadow.root.barrier.93:                           ; preds = %shadow.root.barrier.done.92
  call void @js_write_barrier_root_nanbox(i64 %r501) #7
  br label %shadow.root.barrier.done.94

shadow.root.barrier.done.94:                      ; preds = %shadow.root.barrier.93, %shadow.root.barrier.done.92
  %r504.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15.relocated278 to i64
  %r504.rs4o = call i64 asm "", "=r,0"(i64 %r504.rs4i) #7
  %r504 = bitcast i64 %r504.rs4o to double
  %r505 = bitcast double %r504 to i64
  %rs4gc.s26 = inttoptr i64 %r505 to ptr addrspace(1)
  %r506.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r506 = call i64 asm "", "=r,0"(i64 %r506.rs4i) #7
  %r507 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r508 = icmp ne i32 %r507, 0
  br i1 %r508, label %shadow.root.barrier.95, label %shadow.root.barrier.done.96

shadow.root.barrier.95:                           ; preds = %shadow.root.barrier.done.94
  call void @js_write_barrier_root_nanbox(i64 %r506) #7
  br label %shadow.root.barrier.done.96

shadow.root.barrier.done.96:                      ; preds = %shadow.root.barrier.95, %shadow.root.barrier.done.94
  %r509.rs4i = ptrtoint ptr addrspace(1) %r8.0.relocated277 to i64
  %r509.rs4o = call i64 asm "", "=r,0"(i64 %r509.rs4i) #7
  %r509 = bitcast i64 %r509.rs4o to double
  %r510 = load double, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  %statepoint_token281 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r509, double %r510, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s25, ptr addrspace(1) %r8.0.relocated277, ptr addrspace(1) %rs4gc.s15.relocated278, ptr addrspace(1) %rs4gc.s13.relocated279, ptr addrspace(1) %rs4gc.s9.relocated280, ptr addrspace(1) %rs4gc.s18.relocated276, ptr addrspace(1) %rs4gc.s26) ]
  %r511282 = call double @llvm.experimental.gc.result.f64(token %statepoint_token281)
  %rs4gc.s25.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 0, i32 0) ; (%rs4gc.s25, %rs4gc.s25)
  %r8.0.relocated283 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 1, i32 1) ; (%r8.0.relocated277, %r8.0.relocated277)
  %rs4gc.s15.relocated284 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 2, i32 2) ; (%rs4gc.s15.relocated278, %rs4gc.s15.relocated278)
  %rs4gc.s13.relocated285 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 3, i32 3) ; (%rs4gc.s13.relocated279, %rs4gc.s13.relocated279)
  %rs4gc.s9.relocated286 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 4, i32 4) ; (%rs4gc.s9.relocated280, %rs4gc.s9.relocated280)
  %rs4gc.s18.relocated287 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 5, i32 5) ; (%rs4gc.s18.relocated276, %rs4gc.s18.relocated276)
  %rs4gc.s26.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token281, i32 6, i32 6) ; (%rs4gc.s26, %rs4gc.s26)
  %statepoint_token288 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r511282, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s25.relocated, ptr addrspace(1) %r8.0.relocated283, ptr addrspace(1) %rs4gc.s15.relocated284, ptr addrspace(1) %rs4gc.s13.relocated285, ptr addrspace(1) %rs4gc.s9.relocated286, ptr addrspace(1) %rs4gc.s18.relocated287, ptr addrspace(1) %rs4gc.s26.relocated) ]
  %r512289 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token288)
  %rs4gc.s25.relocated290 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token288, i32 0, i32 0) ; (%rs4gc.s25.relocated, %rs4gc.s25.relocated)
  %r8.0.relocated291 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token288, i32 1, i32 1) ; (%r8.0.relocated283, %r8.0.relocated283)
  %rs4gc.s15.relocated292 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token288, i32 2, i32 2) ; (%rs4gc.s15.relocated284, %rs4gc.s15.relocated284)
  %rs4gc.s13.relocated293 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token288, i32 3, i32 3) ; (%rs4gc.s13.relocated285, %rs4gc.s13.relocated285)
  %rs4gc.s9.relocated294 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token288, i32 4, i32 4) ; (%rs4gc.s9.relocated286, %rs4gc.s9.relocated286)
  %rs4gc.s18.relocated295 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token288, i32 5, i32 5) ; (%rs4gc.s18.relocated287, %rs4gc.s18.relocated287)
  %rs4gc.s26.relocated296 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token288, i32 6, i32 6) ; (%rs4gc.s26.relocated, %rs4gc.s26.relocated)
  %statepoint_token297 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r512289, double 0.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s25.relocated290, ptr addrspace(1) %r8.0.relocated291, ptr addrspace(1) %rs4gc.s15.relocated292, ptr addrspace(1) %rs4gc.s13.relocated293, ptr addrspace(1) %rs4gc.s9.relocated294, ptr addrspace(1) %rs4gc.s18.relocated295, ptr addrspace(1) %rs4gc.s26.relocated296) ]
  %r513298 = call double @llvm.experimental.gc.result.f64(token %statepoint_token297)
  %rs4gc.s25.relocated299 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token297, i32 0, i32 0) ; (%rs4gc.s25.relocated290, %rs4gc.s25.relocated290)
  %r8.0.relocated300 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token297, i32 1, i32 1) ; (%r8.0.relocated291, %r8.0.relocated291)
  %rs4gc.s15.relocated301 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token297, i32 2, i32 2) ; (%rs4gc.s15.relocated292, %rs4gc.s15.relocated292)
  %rs4gc.s13.relocated302 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token297, i32 3, i32 3) ; (%rs4gc.s13.relocated293, %rs4gc.s13.relocated293)
  %rs4gc.s9.relocated303 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token297, i32 4, i32 4) ; (%rs4gc.s9.relocated294, %rs4gc.s9.relocated294)
  %rs4gc.s18.relocated304 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token297, i32 5, i32 5) ; (%rs4gc.s18.relocated295, %rs4gc.s18.relocated295)
  %rs4gc.s26.relocated305 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token297, i32 6, i32 6) ; (%rs4gc.s26.relocated296, %rs4gc.s26.relocated296)
  %r514.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26.relocated305 to i64
  %r514 = call i64 asm "", "=r,0"(i64 %r514.rs4i) #7
  %r515 = bitcast i64 %r514 to double
  %r516.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated304 to i64
  %r516.rs4o = call i64 asm "", "=r,0"(i64 %r516.rs4i) #7
  %r516 = bitcast i64 %r516.rs4o to double
  %r517 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__2, align 8
  %r518 = icmp ne ptr %r517, null
  %r519 = select i1 %r518, ptr %r517, ptr @perry_ic_test_json_large_string_emitters_ts__2
  %r520 = bitcast double %r513298 to i64
  %r521 = bitcast double %r516 to i64
  %r522 = and i64 %r521, 281474976710655
  %r523 = lshr i64 %r521, 48
  %r524 = icmp eq i64 %r523, 32765
  %r525 = icmp ugt i64 %r522, 1048575
  %r526 = lshr i64 %r520, 48
  %r527 = icmp ne i64 %r526, 32765
  %r528 = icmp ne i64 %r526, 32767
  %r529 = icmp ne i64 %r526, 32762
  %r530 = and i1 %r527, %r528
  %r531 = and i1 %r530, %r529
  %r532 = icmp ne i64 %r514, 0
  %r533 = and i1 %r524, %r525
  %r534 = and i1 %r533, %r532
  br i1 %r534, label %put.dynic.guard.97, label %put.dynic.slow.115

put.dynic.guard.97:                               ; preds = %shadow.root.barrier.done.96
  %r535 = sub nuw nsw i64 %r522, 8
  %r536 = inttoptr i64 %r535 to ptr
  %r537 = load i8, ptr %r536, align 1
  %r538 = icmp eq i8 %r537, 2
  %r539 = sub nuw nsw i64 %r522, 7
  %r540 = inttoptr i64 %r539 to ptr
  %r541 = load i8, ptr %r540, align 1
  %r542 = and i8 %r541, -128
  %r543 = icmp eq i8 %r542, 0
  %r544 = sub nuw nsw i64 %r522, 6
  %r545 = inttoptr i64 %r544 to ptr
  %r546 = load i16, ptr %r545, align 2
  %r547 = and i16 %r546, 6535
  %r548 = icmp eq i16 %r547, 0
  %r549 = add nuw nsw i64 %r522, 0
  %r550 = inttoptr i64 %r549 to ptr
  %r551 = load i32, ptr %r550, align 4
  %r552 = icmp ne i32 %r551, 0
  %r553 = icmp ne i32 %r551, -2
  %r554 = and i16 %r546, 512
  %r555 = icmp ne i16 %r554, 0
  %r556 = or i1 %r552, %r555
  %r557 = add nuw nsw i64 %r522, 4
  %r558 = inttoptr i64 %r557 to ptr
  %r559 = load i32, ptr %r558, align 4
  %r560 = add i32 %r559, -2147483648
  %r561 = icmp ult i32 %r560, 1073741824
  %r562 = zext i32 %r559 to i64
  %r563 = or i64 %r562, 4611686018427387904
  %r564 = select i1 %r561, i64 %r563, i64 0
  %r565 = getelementptr i64, ptr %r519, i64 0
  %r566 = load i64, ptr %r565, align 8
  %r567 = icmp eq i64 %r564, %r566
  %r568 = icmp ne i64 %r564, 0
  %r569 = and i1 %r538, %r543
  %r570 = and i1 %r569, %r548
  %r571 = and i1 %r570, %r556
  %r572 = and i1 %r571, %r553
  %r573 = and i1 %r567, %r568
  %r574 = and i1 %r572, %r573
  br i1 %r574, label %put.dynic.ways.98, label %put.dynic.trans.gate.106

put.dynic.ways.98:                                ; preds = %put.dynic.guard.97
  %r576 = getelementptr i64, ptr %r517, i64 1
  %r577 = load i64, ptr %r576, align 8
  %r578 = getelementptr i64, ptr %r517, i64 2
  %r579 = load i64, ptr %r578, align 8
  %r580 = icmp eq i64 %r514, %r577
  br i1 %r580, label %put.dynic.store.101, label %put.dynic.way1.99

put.dynic.way1.99:                                ; preds = %put.dynic.ways.98
  %r581 = getelementptr i64, ptr %r517, i64 3
  %r582 = load i64, ptr %r581, align 8
  %r583 = getelementptr i64, ptr %r517, i64 4
  %r584 = load i64, ptr %r583, align 8
  %r585 = icmp eq i64 %r514, %r582
  br i1 %r585, label %put.dynic.store.101, label %put.dynic.way2.100

put.dynic.way2.100:                               ; preds = %put.dynic.way1.99
  %r586 = getelementptr i64, ptr %r517, i64 5
  %r587 = load i64, ptr %r586, align 8
  %r588 = getelementptr i64, ptr %r517, i64 6
  %r589 = load i64, ptr %r588, align 8
  %r590 = icmp eq i64 %r514, %r587
  br i1 %r590, label %put.dynic.store.101, label %put.dynic.trans.probe.107

put.dynic.store.101:                              ; preds = %put.dynic.way2.100, %put.dynic.way1.99, %put.dynic.ways.98
  %r591 = phi i64 [ %r579, %put.dynic.ways.98 ], [ %r584, %put.dynic.way1.99 ], [ %r589, %put.dynic.way2.100 ]
  %r592 = shl i64 %r591, 3
  %r593 = add i64 %r592, 16
  %r594 = inttoptr i64 %r522 to ptr
  %r595 = getelementptr inbounds i8, ptr %r594, i64 %r593
  %r596 = and i16 %r546, 1024
  %r597 = icmp ne i16 %r596, 0
  br i1 %r597, label %put.dynic.store.validate.102, label %put.dynic.store.dispatch.103

put.dynic.store.validate.102:                     ; preds = %put.dynic.store.101
  %r598 = load double, ptr %r595, align 8
  %r599 = bitcast double %r598 to i64
  %r600 = icmp eq i64 %r599, 9222246136947933200
  br i1 %r600, label %put.dynic.slow.115, label %put.dynic.store.dispatch.103

put.dynic.store.dispatch.103:                     ; preds = %put.dynic.store.validate.102, %put.dynic.store.101
  br i1 %r531, label %put.dynic.store.scalar.104, label %put.dynic.store.ref.105

put.dynic.store.scalar.104:                       ; preds = %put.dynic.store.dispatch.103
  store double %r513298, ptr %r595, align 8
  br label %put.dynic.merge.116

put.dynic.store.ref.105:                          ; preds = %put.dynic.store.dispatch.103
  %r601 = trunc i64 %r591 to i32
  %r602 = shl i64 %r591, 3
  %r603 = add nuw nsw i64 %r522, 16
  %r604 = add i64 %r603, %r602
  %r605 = load double, ptr %r595, align 8
  %r606 = bitcast double %r605 to i64
  store double %r513298, ptr %r595, align 8
  call void @js_string_addref_if_heap_string(double %r513298) #7
  %r607 = bitcast double %r513298 to i64
  %r4664.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated304 to i64
  %r4664.rs4o = call i64 asm "", "=r,0"(i64 %r4664.rs4i) #7
  %r4664 = bitcast i64 %r4664.rs4o to double
  %r4665 = bitcast double %r4664 to i64
  %r4666 = and i64 %r4665, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4666, i32 %r601, i64 %r607, i64 %r606) #7
  %r4662.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated304 to i64
  %r4662.rs4o = call i64 asm "", "=r,0"(i64 %r4662.rs4i) #7
  %r4662 = bitcast i64 %r4662.rs4o to double
  %r4663 = bitcast double %r4662 to i64
  call void @js_write_barrier_slot(i64 %r4663, i64 %r604, i64 %r607) #7
  br label %put.dynic.merge.116

put.dynic.trans.gate.106:                         ; preds = %put.dynic.guard.97
  %r575 = and i1 %r572, %r568
  br i1 %r575, label %put.dynic.trans.probe.107, label %put.dynic.slow.115

put.dynic.trans.probe.107:                        ; preds = %put.dynic.trans.gate.106, %put.dynic.way2.100
  %r608 = lshr i64 %r514, 48
  %r609 = icmp eq i64 %r608, 32767
  %r610 = and i64 %r514, 281474976710655
  %r611 = icmp ugt i64 %r610, 1048575
  %r612 = and i16 %r546, -16384
  %r613 = icmp eq i16 %r612, 0
  %r614 = and i8 %r541, 32
  %r615 = icmp eq i8 %r614, 0
  %r616 = and i1 %r609, %r611
  %r617 = and i1 %r616, %r613
  %r618 = and i1 %r617, %r615
  br i1 %r618, label %put.dynic.trans.key.108, label %put.dynic.slow.115

put.dynic.trans.key.108:                          ; preds = %put.dynic.trans.probe.107
  %r619 = and i64 %r514, 281474976710655
  %r620 = add nuw nsw i64 %r619, 4
  %r621 = inttoptr i64 %r620 to ptr
  %r622 = load i32, ptr %r621, align 4
  %r623 = icmp uge i32 %r622, 6
  %r624 = icmp ule i32 %r622, 8
  %r625 = add nuw nsw i64 %r619, 20
  %r626 = inttoptr i64 %r625 to ptr
  %r627 = load i8, ptr %r626, align 1
  %r628 = sub i8 %r627, 48
  %r629 = icmp ult i8 %r628, 10
  %r630 = icmp eq i1 %r629, false
  %r631 = and i1 %r623, %r624
  %r632 = and i1 %r631, %r630
  br i1 %r632, label %put.dynic.trans.entry.109, label %put.dynic.slow.115

put.dynic.trans.entry.109:                        ; preds = %put.dynic.trans.key.108
  %r633 = add nuw nsw i64 %r619, 20
  %r634 = inttoptr i64 %r633 to ptr
  %r635 = load i64, ptr %r634, align 8
  %r636 = zext nneg i32 %r622 to i64
  %r637 = sub nuw nsw i64 8, %r636
  %r638 = shl nuw nsw i64 %r637, 3
  %r639 = lshr i64 -1, %r638
  %r640 = and i64 %r635, %r639
  %r642 = ptrtoint ptr %r92 to i64
  %r643 = zext i32 %r559 to i64
  %r644 = mul i64 %r643, -7046029254386353131
  %r645 = lshr i64 %r640, 3
  %r646 = mul i64 %r645, -4126379630918253789
  %r647 = xor i64 %r644, %r646
  %r648 = and i64 %r647, 16383
  %r649 = shl nuw nsw i64 %r648, 5
  %r650 = add i64 %r642, %r649
  %r651 = inttoptr i64 %r650 to ptr
  %r652 = load i64, ptr %r651, align 8
  %r653 = add i64 %r650, 8
  %r654 = inttoptr i64 %r653 to ptr
  %r655 = load i64, ptr %r654, align 8
  %r656 = add i64 %r650, 16
  %r657 = inttoptr i64 %r656 to ptr
  %r658 = load i32, ptr %r657, align 4
  %r659 = add i64 %r650, 20
  %r660 = inttoptr i64 %r659 to ptr
  %r661 = load i32, ptr %r660, align 4
  %r662 = add i64 %r650, 24
  %r663 = inttoptr i64 %r662 to ptr
  %r664 = load i32, ptr %r663, align 4
  %r665 = lshr i32 %r664, 24
  %r666 = and i32 %r664, 16777215
  %r667 = add i64 %r650, 28
  %r668 = inttoptr i64 %r667 to ptr
  %r669 = load i32, ptr %r668, align 4
  %r670 = icmp eq i64 %r652, %r640
  %r671 = icmp eq i32 %r665, %r622
  %r672 = icmp eq i32 %r658, %r559
  %r673 = icmp ne i64 %r655, 0
  %r674 = add nuw nsw i32 %r666, 1
  %r675 = icmp eq i32 %r669, %r674
  %r676 = zext nneg i32 %r666 to i64
  %r677 = and i64 %r520, 281474976710655
  %r678 = icmp eq i64 %r526, 32765
  %r679 = icmp eq i64 %r677, 0
  %r680 = and i1 %r678, %r679
  %r681 = select i1 %r680, i64 9222246136947933185, i64 %r520
  %r682 = bitcast i64 %r681 to double
  %r683 = and i1 %r670, %r671
  %r684 = and i1 %r683, %r672
  %r685 = and i1 %r684, %r673
  %r686 = and i1 %r685, %r675
  br i1 %r686, label %put.dynic.trans.nk.110, label %put.dynic.slow.115

put.dynic.trans.nk.110:                           ; preds = %put.dynic.trans.entry.109
  %r687 = inttoptr i64 %r655 to ptr
  %r688 = load i32, ptr %r687, align 4
  %r689 = icmp eq i32 %r688, %r674
  br i1 %r689, label %put.dynic.trans.dispatch.111, label %put.dynic.slow.115

put.dynic.trans.dispatch.111:                     ; preds = %put.dynic.trans.nk.110
  %r690 = icmp ult i64 %r676, 2
  br i1 %r690, label %put.dynic.trans.inline_ref.112, label %put.dynic.trans.ovf.113

put.dynic.trans.inline_ref.112:                   ; preds = %put.dynic.trans.dispatch.111
  %r691 = shl nuw nsw i64 %r676, 3
  %r692 = add nuw nsw i64 %r691, 16
  %r693 = add nuw nsw i64 %r522, %r692
  %r694 = inttoptr i64 %r693 to ptr
  %r695 = trunc nuw nsw i64 %r676 to i32
  %r696 = load double, ptr %r694, align 8
  %r697 = bitcast double %r696 to i64
  store double %r682, ptr %r694, align 8
  call void @js_string_addref_if_heap_string(double %r682) #7
  %r698 = bitcast double %r682 to i64
  %r4659.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated304 to i64
  %r4659.rs4o = call i64 asm "", "=r,0"(i64 %r4659.rs4i) #7
  %r4659 = bitcast i64 %r4659.rs4o to double
  %r4660 = bitcast double %r4659 to i64
  %r4661 = and i64 %r4660, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4661, i32 %r695, i64 %r698, i64 %r697) #7
  %r4657.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated304 to i64
  %r4657.rs4o = call i64 asm "", "=r,0"(i64 %r4657.rs4i) #7
  %r4657 = bitcast i64 %r4657.rs4o to double
  %r4658 = bitcast double %r4657 to i64
  call void @js_write_barrier_slot(i64 %r4658, i64 %r693, i64 %r698) #7
  br label %put.dynic.trans.stamp.114

put.dynic.trans.ovf.113:                          ; preds = %put.dynic.trans.dispatch.111
  %r699 = trunc nuw nsw i64 %r676 to i32
  %r700 = call i32 @js_transition_ic_spill_append(double %r516, i64 %r564, i32 %r699, double %r682) #7
  %r701 = icmp ne i32 %r700, 0
  br i1 %r701, label %put.dynic.trans.stamp.114, label %put.dynic.slow.115

put.dynic.trans.stamp.114:                        ; preds = %put.dynic.trans.ovf.113, %put.dynic.trans.inline_ref.112
  %r4654.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated304 to i64
  %r4654.rs4o = call i64 asm "", "=r,0"(i64 %r4654.rs4i) #7
  %r4654 = bitcast i64 %r4654.rs4o to double
  %r4655 = bitcast double %r4654 to i64
  %r4656 = and i64 %r4655, 281474976710655
  %r702 = add nuw nsw i64 %r4656, 4
  %r703 = inttoptr i64 %r702 to ptr
  store i32 %r661, ptr %r703, align 4
  br label %put.dynic.merge.116

put.dynic.slow.115:                               ; preds = %put.dynic.trans.ovf.113, %put.dynic.trans.nk.110, %put.dynic.trans.entry.109, %put.dynic.trans.key.108, %put.dynic.trans.probe.107, %put.dynic.trans.gate.106, %put.dynic.store.validate.102, %shadow.root.barrier.done.96
  %statepoint_token306 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_large_string_emitters_ts__2, double %r516, double %r515, double %r513298, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s25.relocated299, ptr addrspace(1) %r8.0.relocated300, ptr addrspace(1) %rs4gc.s15.relocated301, ptr addrspace(1) %rs4gc.s13.relocated302, ptr addrspace(1) %rs4gc.s9.relocated303, ptr addrspace(1) %rs4gc.s18.relocated304) ]
  %r704307 = call double @llvm.experimental.gc.result.f64(token %statepoint_token306)
  %rs4gc.s25.relocated308 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token306, i32 0, i32 0) ; (%rs4gc.s25.relocated299, %rs4gc.s25.relocated299)
  %r8.0.relocated309 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token306, i32 1, i32 1) ; (%r8.0.relocated300, %r8.0.relocated300)
  %rs4gc.s15.relocated310 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token306, i32 2, i32 2) ; (%rs4gc.s15.relocated301, %rs4gc.s15.relocated301)
  %rs4gc.s13.relocated311 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token306, i32 3, i32 3) ; (%rs4gc.s13.relocated302, %rs4gc.s13.relocated302)
  %rs4gc.s9.relocated312 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token306, i32 4, i32 4) ; (%rs4gc.s9.relocated303, %rs4gc.s9.relocated303)
  %rs4gc.s18.relocated313 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token306, i32 5, i32 5) ; (%rs4gc.s18.relocated304, %rs4gc.s18.relocated304)
  br label %put.dynic.merge.116

put.dynic.merge.116:                              ; preds = %put.dynic.slow.115, %put.dynic.trans.stamp.114, %put.dynic.store.ref.105, %put.dynic.store.scalar.104
  %.01482 = phi ptr addrspace(1) [ %rs4gc.s25.relocated308, %put.dynic.slow.115 ], [ %rs4gc.s25.relocated299, %put.dynic.store.scalar.104 ], [ %rs4gc.s25.relocated299, %put.dynic.store.ref.105 ], [ %rs4gc.s25.relocated299, %put.dynic.trans.stamp.114 ]
  %.51465 = phi ptr addrspace(1) [ %rs4gc.s18.relocated313, %put.dynic.slow.115 ], [ %rs4gc.s18.relocated304, %put.dynic.store.scalar.104 ], [ %rs4gc.s18.relocated304, %put.dynic.store.ref.105 ], [ %rs4gc.s18.relocated304, %put.dynic.trans.stamp.114 ]
  %.61432 = phi ptr addrspace(1) [ %rs4gc.s15.relocated310, %put.dynic.slow.115 ], [ %rs4gc.s15.relocated301, %put.dynic.store.scalar.104 ], [ %rs4gc.s15.relocated301, %put.dynic.store.ref.105 ], [ %rs4gc.s15.relocated301, %put.dynic.trans.stamp.114 ]
  %.91374 = phi ptr addrspace(1) [ %rs4gc.s13.relocated311, %put.dynic.slow.115 ], [ %rs4gc.s13.relocated302, %put.dynic.store.scalar.104 ], [ %rs4gc.s13.relocated302, %put.dynic.store.ref.105 ], [ %rs4gc.s13.relocated302, %put.dynic.trans.stamp.114 ]
  %.61316 = phi ptr addrspace(1) [ %r8.0.relocated309, %put.dynic.slow.115 ], [ %r8.0.relocated300, %put.dynic.store.scalar.104 ], [ %r8.0.relocated300, %put.dynic.store.ref.105 ], [ %r8.0.relocated300, %put.dynic.trans.stamp.114 ]
  %.9 = phi ptr addrspace(1) [ %rs4gc.s9.relocated312, %put.dynic.slow.115 ], [ %rs4gc.s9.relocated303, %put.dynic.store.scalar.104 ], [ %rs4gc.s9.relocated303, %put.dynic.store.ref.105 ], [ %rs4gc.s9.relocated303, %put.dynic.trans.stamp.114 ]
  %r705 = phi double [ %r513298, %put.dynic.store.scalar.104 ], [ %r513298, %put.dynic.store.ref.105 ], [ %r682, %put.dynic.trans.stamp.114 ], [ %r704307, %put.dynic.slow.115 ]
  %r706.rs4i = ptrtoint ptr addrspace(1) %.51465 to i64
  %r706.rs4o = call i64 asm "", "=r,0"(i64 %r706.rs4i) #7
  %r706 = bitcast i64 %r706.rs4o to double
  %r707.rs4i = ptrtoint ptr addrspace(1) %.91374 to i64
  %r707.rs4o = call i64 asm "", "=r,0"(i64 %r707.rs4i) #7
  %r707 = bitcast i64 %r707.rs4o to double
  br label %ternary.then.117

ternary.then.117:                                 ; preds = %put.dynic.merge.116
  br label %ternary.merge.119

ternary.merge.119:                                ; preds = %ternary.then.117
  %statepoint_token314 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r706, double %r707, double 0.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61316, ptr addrspace(1) %.61432, ptr addrspace(1) %.91374, ptr addrspace(1) %.9, ptr addrspace(1) %.51465, ptr addrspace(1) %.01482) ]
  %r722315 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token314)
  %r8.0.relocated316 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 0, i32 0) ; (%.61316, %.61316)
  %rs4gc.s15.relocated317 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 1, i32 1) ; (%.61432, %.61432)
  %rs4gc.s13.relocated318 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 2, i32 2) ; (%.91374, %.91374)
  %rs4gc.s9.relocated319 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 3, i32 3) ; (%.9, %.9)
  %rs4gc.s18.relocated320 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 4, i32 4) ; (%.51465, %.51465)
  %rs4gc.s25.relocated321 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 5, i32 5) ; (%.01482, %.01482)
  %r723 = bitcast i64 %r722315 to double
  %r724 = bitcast i64 %r722315 to double
  %r725.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25.relocated321 to i64
  %r725.rs4o = call i64 asm "", "=r,0"(i64 %r725.rs4i) #7
  %r725 = bitcast i64 %r725.rs4o to double
  %r726 = bitcast double %r725 to i64
  %r727 = and i64 %r726, 281474976710655
  %r728 = sub nsw i64 %r727, 8
  %r729 = inttoptr i64 %r728 to ptr
  %r730 = load i8, ptr %r729, align 1
  %r731 = icmp ne i8 %r730, 1
  %r732 = sub nsw i64 %r727, 7
  %r733 = inttoptr i64 %r732 to ptr
  %r734 = load i8, ptr %r733, align 1
  %r735 = and i8 %r734, -128
  %r736 = icmp ne i8 %r735, 0
  %r737 = or i1 %r731, %r736
  br i1 %r736, label %apush.fwd.120, label %apush.elements.121

apush.fwd.120:                                    ; preds = %apush.elements.check.122, %ternary.merge.119
  %statepoint_token322 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r727, double %r724, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated320, ptr addrspace(1) %r8.0.relocated316, ptr addrspace(1) %rs4gc.s15.relocated317, ptr addrspace(1) %rs4gc.s13.relocated318, ptr addrspace(1) %rs4gc.s9.relocated319) ]
  %r764323 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token322)
  %rs4gc.s18.relocated324 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token322, i32 0, i32 0) ; (%rs4gc.s18.relocated320, %rs4gc.s18.relocated320)
  %r8.0.relocated325 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token322, i32 1, i32 1) ; (%r8.0.relocated316, %r8.0.relocated316)
  %rs4gc.s15.relocated326 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token322, i32 2, i32 2) ; (%rs4gc.s15.relocated317, %rs4gc.s15.relocated317)
  %rs4gc.s13.relocated327 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token322, i32 3, i32 3) ; (%rs4gc.s13.relocated318, %rs4gc.s13.relocated318)
  %rs4gc.s9.relocated328 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token322, i32 4, i32 4) ; (%rs4gc.s9.relocated319, %rs4gc.s9.relocated319)
  %r765 = or i64 %r764323, 9222527611924643840
  %r766 = bitcast i64 %r765 to double
  %rs4gc.b27 = bitcast double %r766 to i64
  %rs4gc.s27 = inttoptr i64 %rs4gc.b27 to ptr addrspace(1)
  br label %apush.merge.126

apush.elements.121:                               ; preds = %ternary.merge.119
  %r739 = add nuw nsw i64 %r727, 8
  %r740 = inttoptr i64 %r739 to ptr
  %r741 = load i64, ptr %r740, align 8
  %r742 = icmp ne i64 %r741, 0
  %r743 = icmp eq i8 %r730, 2
  %r744 = and i1 %r743, %r742
  %r745 = select i1 %r744, i64 %r741, i64 %r727
  %r746 = inttoptr i64 %r745 to ptr
  %r747 = getelementptr i64, ptr %r746, i64 12
  %r748 = load i64, ptr %r747, align 8
  %r749 = icmp ne i64 %r748, 0
  %r750 = and i1 %r744, %r749
  %r751 = select i1 %r750, i64 %r748, i64 %r727
  %r738 = icmp eq i8 %r730, 1
  br i1 %r738, label %apush.nofwd.123, label %apush.elements.check.122

apush.elements.check.122:                         ; preds = %apush.elements.121
  %r752 = icmp ne i64 %r751, 0
  %r753 = sub i64 %r751, 8
  %r754 = inttoptr i64 %r753 to ptr
  %r755 = load i8, ptr %r754, align 1
  %r756 = icmp eq i8 %r755, 1
  %r757 = sub i64 %r751, 7
  %r758 = inttoptr i64 %r757 to ptr
  %r759 = load i8, ptr %r758, align 1
  %r760 = and i8 %r759, -128
  %r761 = icmp eq i8 %r760, 0
  %r762 = and i1 %r752, %r756
  %r763 = and i1 %r762, %r761
  br i1 %r763, label %apush.nofwd.123, label %apush.fwd.120

apush.nofwd.123:                                  ; preds = %apush.elements.check.122, %apush.elements.121
  %r767 = phi i64 [ %r727, %apush.elements.121 ], [ %r751, %apush.elements.check.122 ]
  %r768 = sub i64 %r767, 6
  %r769 = inttoptr i64 %r768 to ptr
  %r770 = load i16, ptr %r769, align 2
  %r771 = and i16 %r770, 1031
  %r772 = icmp eq i16 %r771, 0
  %r773 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r774 = icmp eq i8 %r773, 0
  %r775 = and i1 %r772, %r774
  %r776 = icmp ult i64 %r767, 4096
  %r777 = inttoptr i64 %r767 to ptr
  %r778 = select i1 %r776, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r777
  %r779 = load i32, ptr %r778, align 4
  %r780 = add i64 %r767, 4
  %r781 = inttoptr i64 %r780 to ptr
  %r782 = load i32, ptr %r781, align 4
  %r783 = icmp ult i32 %r779, %r782
  %r784 = and i1 %r783, %r775
  br i1 %r784, label %apush.inbounds.124, label %apush.realloc.125

apush.inbounds.124:                               ; preds = %apush.nofwd.123
  %r785 = icmp ult i64 %r767, 4096
  %r786 = inttoptr i64 %r767 to ptr
  %r787 = select i1 %r785, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r786
  %r788 = load i32, ptr %r787, align 4
  %r789 = zext i32 %r788 to i64
  %r790 = shl nuw nsw i64 %r789, 3
  %r791 = add nuw nsw i64 %r790, 8
  %r792 = add i64 %r767, %r791
  %r793 = inttoptr i64 %r792 to ptr
  store double %r724, ptr %r793, align 8
  %r794 = lshr i64 %r722315, 48
  %r795 = icmp eq i64 %r794, 32765
  %r796 = and i16 %r770, -1920
  %r797 = icmp eq i16 %r796, -24576
  %r798 = and i1 %r795, %r797
  br i1 %r798, label %apush.pointer_layout.done.128, label %apush.pointer_layout.bookkeeping.127

apush.realloc.125:                                ; preds = %apush.nofwd.123
  %statepoint_token329 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r727, double %r724, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated320, ptr addrspace(1) %r8.0.relocated316, ptr addrspace(1) %rs4gc.s15.relocated317, ptr addrspace(1) %rs4gc.s13.relocated318, ptr addrspace(1) %rs4gc.s9.relocated319) ]
  %r809330 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token329)
  %rs4gc.s18.relocated331 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 0, i32 0) ; (%rs4gc.s18.relocated320, %rs4gc.s18.relocated320)
  %r8.0.relocated332 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 1, i32 1) ; (%r8.0.relocated316, %r8.0.relocated316)
  %rs4gc.s15.relocated333 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 2, i32 2) ; (%rs4gc.s15.relocated317, %rs4gc.s15.relocated317)
  %rs4gc.s13.relocated334 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 3, i32 3) ; (%rs4gc.s13.relocated318, %rs4gc.s13.relocated318)
  %rs4gc.s9.relocated335 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 4, i32 4) ; (%rs4gc.s9.relocated319, %rs4gc.s9.relocated319)
  %r810 = or i64 %r809330, 9222527611924643840
  %r811 = bitcast i64 %r810 to double
  %rs4gc.b28 = bitcast double %r811 to i64
  %rs4gc.s28 = inttoptr i64 %rs4gc.b28 to ptr addrspace(1)
  br label %apush.merge.126

apush.merge.126:                                  ; preds = %apush.barrier.done.130, %apush.realloc.125, %apush.fwd.120
  %.61466 = phi ptr addrspace(1) [ %rs4gc.s18.relocated324, %apush.fwd.120 ], [ %rs4gc.s18.relocated320, %apush.barrier.done.130 ], [ %rs4gc.s18.relocated331, %apush.realloc.125 ]
  %.71433 = phi ptr addrspace(1) [ %rs4gc.s15.relocated326, %apush.fwd.120 ], [ %rs4gc.s15.relocated317, %apush.barrier.done.130 ], [ %rs4gc.s15.relocated333, %apush.realloc.125 ]
  %.101375 = phi ptr addrspace(1) [ %rs4gc.s13.relocated327, %apush.fwd.120 ], [ %rs4gc.s13.relocated318, %apush.barrier.done.130 ], [ %rs4gc.s13.relocated334, %apush.realloc.125 ]
  %.71317 = phi ptr addrspace(1) [ %r8.0.relocated325, %apush.fwd.120 ], [ %r8.0.relocated316, %apush.barrier.done.130 ], [ %r8.0.relocated332, %apush.realloc.125 ]
  %.10 = phi ptr addrspace(1) [ %rs4gc.s9.relocated328, %apush.fwd.120 ], [ %rs4gc.s9.relocated319, %apush.barrier.done.130 ], [ %rs4gc.s9.relocated335, %apush.realloc.125 ]
  %r497.0 = phi ptr addrspace(1) [ %rs4gc.s27, %apush.fwd.120 ], [ %rs4gc.s25.relocated321, %apush.barrier.done.130 ], [ %rs4gc.s28, %apush.realloc.125 ]
  %r812.rs4i = ptrtoint ptr addrspace(1) %.71433 to i64
  %r812.rs4o = call i64 asm "", "=r,0"(i64 %r812.rs4i) #7
  %r812 = bitcast i64 %r812.rs4o to double
  %r813 = bitcast double %r812 to i64
  %rs4gc.s29 = inttoptr i64 %r813 to ptr addrspace(1)
  %r814.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r814 = call i64 asm "", "=r,0"(i64 %r814.rs4i) #7
  %r815 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r816 = icmp ne i32 %r815, 0
  br i1 %r816, label %shadow.root.barrier.131, label %shadow.root.barrier.done.132

apush.pointer_layout.bookkeeping.127:             ; preds = %apush.inbounds.124
  call void @js_string_addref_if_heap_string(double %r724) #7
  call void @js_gc_note_slot_layout(i64 %r767, i32 %r788, i64 %r722315) #7
  call void @js_array_note_numeric_write(i64 %r767, i64 %r722315) #7
  br label %apush.pointer_layout.done.128

apush.pointer_layout.done.128:                    ; preds = %apush.pointer_layout.bookkeeping.127, %apush.inbounds.124
  %r799 = sub i64 %r767, 7
  %r800 = inttoptr i64 %r799 to ptr
  %r801 = load i8, ptr %r800, align 1
  %r802 = and i8 %r801, 32
  %r803 = icmp ne i8 %r802, 0
  %r804 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r805 = icmp ne i32 %r804, 0
  %r806 = or i1 %r803, %r805
  br i1 %r806, label %apush.barrier.129, label %apush.barrier.done.130

apush.barrier.129:                                ; preds = %apush.pointer_layout.done.128
  call void @js_write_barrier_slot_validated_parent(i64 %r767, i64 %r792, i64 %r722315) #7
  br label %apush.barrier.done.130

apush.barrier.done.130:                           ; preds = %apush.barrier.129, %apush.pointer_layout.done.128
  %r807 = add i32 %r788, 1
  %r808 = inttoptr i64 %r767 to ptr
  store i32 %r807, ptr %r808, align 4
  br label %apush.merge.126

shadow.root.barrier.131:                          ; preds = %apush.merge.126
  call void @js_write_barrier_root_nanbox(i64 %r814) #7
  br label %shadow.root.barrier.done.132

shadow.root.barrier.done.132:                     ; preds = %shadow.root.barrier.131, %apush.merge.126
  %r817.rs4i = ptrtoint ptr addrspace(1) %.71317 to i64
  %r817.rs4o = call i64 asm "", "=r,0"(i64 %r817.rs4i) #7
  %r817 = bitcast i64 %r817.rs4o to double
  %r818 = load double, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  %statepoint_token336 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r817, double %r818, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.0, ptr addrspace(1) %.71317, ptr addrspace(1) %.71433, ptr addrspace(1) %.101375, ptr addrspace(1) %.10, ptr addrspace(1) %.61466, ptr addrspace(1) %rs4gc.s29) ]
  %r819337 = call double @llvm.experimental.gc.result.f64(token %statepoint_token336)
  %r497.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 0, i32 0) ; (%r497.0, %r497.0)
  %r8.0.relocated338 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 1, i32 1) ; (%.71317, %.71317)
  %rs4gc.s15.relocated339 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 2, i32 2) ; (%.71433, %.71433)
  %rs4gc.s13.relocated340 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 3, i32 3) ; (%.101375, %.101375)
  %rs4gc.s9.relocated341 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 4, i32 4) ; (%.10, %.10)
  %rs4gc.s18.relocated342 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 5, i32 5) ; (%.61466, %.61466)
  %rs4gc.s29.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 6, i32 6) ; (%rs4gc.s29, %rs4gc.s29)
  %statepoint_token343 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r819337, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.0.relocated, ptr addrspace(1) %r8.0.relocated338, ptr addrspace(1) %rs4gc.s15.relocated339, ptr addrspace(1) %rs4gc.s13.relocated340, ptr addrspace(1) %rs4gc.s9.relocated341, ptr addrspace(1) %rs4gc.s18.relocated342, ptr addrspace(1) %rs4gc.s29.relocated) ]
  %r820344 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token343)
  %r497.0.relocated345 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 0, i32 0) ; (%r497.0.relocated, %r497.0.relocated)
  %r8.0.relocated346 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 1, i32 1) ; (%r8.0.relocated338, %r8.0.relocated338)
  %rs4gc.s15.relocated347 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 2, i32 2) ; (%rs4gc.s15.relocated339, %rs4gc.s15.relocated339)
  %rs4gc.s13.relocated348 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 3, i32 3) ; (%rs4gc.s13.relocated340, %rs4gc.s13.relocated340)
  %rs4gc.s9.relocated349 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 4, i32 4) ; (%rs4gc.s9.relocated341, %rs4gc.s9.relocated341)
  %rs4gc.s18.relocated350 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 5, i32 5) ; (%rs4gc.s18.relocated342, %rs4gc.s18.relocated342)
  %rs4gc.s29.relocated351 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 6, i32 6) ; (%rs4gc.s29.relocated, %rs4gc.s29.relocated)
  %statepoint_token352 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r820344, double 1.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.0.relocated345, ptr addrspace(1) %r8.0.relocated346, ptr addrspace(1) %rs4gc.s15.relocated347, ptr addrspace(1) %rs4gc.s13.relocated348, ptr addrspace(1) %rs4gc.s9.relocated349, ptr addrspace(1) %rs4gc.s18.relocated350, ptr addrspace(1) %rs4gc.s29.relocated351) ]
  %r821353 = call double @llvm.experimental.gc.result.f64(token %statepoint_token352)
  %r497.0.relocated354 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 0, i32 0) ; (%r497.0.relocated345, %r497.0.relocated345)
  %r8.0.relocated355 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 1, i32 1) ; (%r8.0.relocated346, %r8.0.relocated346)
  %rs4gc.s15.relocated356 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 2, i32 2) ; (%rs4gc.s15.relocated347, %rs4gc.s15.relocated347)
  %rs4gc.s13.relocated357 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 3, i32 3) ; (%rs4gc.s13.relocated348, %rs4gc.s13.relocated348)
  %rs4gc.s9.relocated358 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 4, i32 4) ; (%rs4gc.s9.relocated349, %rs4gc.s9.relocated349)
  %rs4gc.s18.relocated359 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 5, i32 5) ; (%rs4gc.s18.relocated350, %rs4gc.s18.relocated350)
  %rs4gc.s29.relocated360 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 6, i32 6) ; (%rs4gc.s29.relocated351, %rs4gc.s29.relocated351)
  %r822.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29.relocated360 to i64
  %r822 = call i64 asm "", "=r,0"(i64 %r822.rs4i) #7
  %r823 = bitcast i64 %r822 to double
  %r824.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated359 to i64
  %r824.rs4o = call i64 asm "", "=r,0"(i64 %r824.rs4i) #7
  %r824 = bitcast i64 %r824.rs4o to double
  %r825 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__3, align 8
  %r826 = icmp ne ptr %r825, null
  %r827 = select i1 %r826, ptr %r825, ptr @perry_ic_test_json_large_string_emitters_ts__3
  %r828 = bitcast double %r821353 to i64
  %r829 = bitcast double %r824 to i64
  %r830 = and i64 %r829, 281474976710655
  %r831 = lshr i64 %r829, 48
  %r832 = icmp eq i64 %r831, 32765
  %r833 = icmp ugt i64 %r830, 1048575
  %r834 = lshr i64 %r828, 48
  %r835 = icmp ne i64 %r834, 32765
  %r836 = icmp ne i64 %r834, 32767
  %r837 = icmp ne i64 %r834, 32762
  %r838 = and i1 %r835, %r836
  %r839 = and i1 %r838, %r837
  %r840 = icmp ne i64 %r822, 0
  %r841 = and i1 %r832, %r833
  %r842 = and i1 %r841, %r840
  br i1 %r842, label %put.dynic.guard.133, label %put.dynic.slow.151

put.dynic.guard.133:                              ; preds = %shadow.root.barrier.done.132
  %r843 = sub nuw nsw i64 %r830, 8
  %r844 = inttoptr i64 %r843 to ptr
  %r845 = load i8, ptr %r844, align 1
  %r846 = icmp eq i8 %r845, 2
  %r847 = sub nuw nsw i64 %r830, 7
  %r848 = inttoptr i64 %r847 to ptr
  %r849 = load i8, ptr %r848, align 1
  %r850 = and i8 %r849, -128
  %r851 = icmp eq i8 %r850, 0
  %r852 = sub nuw nsw i64 %r830, 6
  %r853 = inttoptr i64 %r852 to ptr
  %r854 = load i16, ptr %r853, align 2
  %r855 = and i16 %r854, 6535
  %r856 = icmp eq i16 %r855, 0
  %r857 = add nuw nsw i64 %r830, 0
  %r858 = inttoptr i64 %r857 to ptr
  %r859 = load i32, ptr %r858, align 4
  %r860 = icmp ne i32 %r859, 0
  %r861 = icmp ne i32 %r859, -2
  %r862 = and i16 %r854, 512
  %r863 = icmp ne i16 %r862, 0
  %r864 = or i1 %r860, %r863
  %r865 = add nuw nsw i64 %r830, 4
  %r866 = inttoptr i64 %r865 to ptr
  %r867 = load i32, ptr %r866, align 4
  %r868 = add i32 %r867, -2147483648
  %r869 = icmp ult i32 %r868, 1073741824
  %r870 = zext i32 %r867 to i64
  %r871 = or i64 %r870, 4611686018427387904
  %r872 = select i1 %r869, i64 %r871, i64 0
  %r873 = getelementptr i64, ptr %r827, i64 0
  %r874 = load i64, ptr %r873, align 8
  %r875 = icmp eq i64 %r872, %r874
  %r876 = icmp ne i64 %r872, 0
  %r877 = and i1 %r846, %r851
  %r878 = and i1 %r877, %r856
  %r879 = and i1 %r878, %r864
  %r880 = and i1 %r879, %r861
  %r881 = and i1 %r875, %r876
  %r882 = and i1 %r880, %r881
  br i1 %r882, label %put.dynic.ways.134, label %put.dynic.trans.gate.142

put.dynic.ways.134:                               ; preds = %put.dynic.guard.133
  %r884 = getelementptr i64, ptr %r825, i64 1
  %r885 = load i64, ptr %r884, align 8
  %r886 = getelementptr i64, ptr %r825, i64 2
  %r887 = load i64, ptr %r886, align 8
  %r888 = icmp eq i64 %r822, %r885
  br i1 %r888, label %put.dynic.store.137, label %put.dynic.way1.135

put.dynic.way1.135:                               ; preds = %put.dynic.ways.134
  %r889 = getelementptr i64, ptr %r825, i64 3
  %r890 = load i64, ptr %r889, align 8
  %r891 = getelementptr i64, ptr %r825, i64 4
  %r892 = load i64, ptr %r891, align 8
  %r893 = icmp eq i64 %r822, %r890
  br i1 %r893, label %put.dynic.store.137, label %put.dynic.way2.136

put.dynic.way2.136:                               ; preds = %put.dynic.way1.135
  %r894 = getelementptr i64, ptr %r825, i64 5
  %r895 = load i64, ptr %r894, align 8
  %r896 = getelementptr i64, ptr %r825, i64 6
  %r897 = load i64, ptr %r896, align 8
  %r898 = icmp eq i64 %r822, %r895
  br i1 %r898, label %put.dynic.store.137, label %put.dynic.trans.probe.143

put.dynic.store.137:                              ; preds = %put.dynic.way2.136, %put.dynic.way1.135, %put.dynic.ways.134
  %r899 = phi i64 [ %r887, %put.dynic.ways.134 ], [ %r892, %put.dynic.way1.135 ], [ %r897, %put.dynic.way2.136 ]
  %r900 = shl i64 %r899, 3
  %r901 = add i64 %r900, 16
  %r902 = inttoptr i64 %r830 to ptr
  %r903 = getelementptr inbounds i8, ptr %r902, i64 %r901
  %r904 = and i16 %r854, 1024
  %r905 = icmp ne i16 %r904, 0
  br i1 %r905, label %put.dynic.store.validate.138, label %put.dynic.store.dispatch.139

put.dynic.store.validate.138:                     ; preds = %put.dynic.store.137
  %r906 = load double, ptr %r903, align 8
  %r907 = bitcast double %r906 to i64
  %r908 = icmp eq i64 %r907, 9222246136947933200
  br i1 %r908, label %put.dynic.slow.151, label %put.dynic.store.dispatch.139

put.dynic.store.dispatch.139:                     ; preds = %put.dynic.store.validate.138, %put.dynic.store.137
  br i1 %r839, label %put.dynic.store.scalar.140, label %put.dynic.store.ref.141

put.dynic.store.scalar.140:                       ; preds = %put.dynic.store.dispatch.139
  store double %r821353, ptr %r903, align 8
  br label %put.dynic.merge.152

put.dynic.store.ref.141:                          ; preds = %put.dynic.store.dispatch.139
  %r909 = trunc i64 %r899 to i32
  %r910 = shl i64 %r899, 3
  %r911 = add nuw nsw i64 %r830, 16
  %r912 = add i64 %r911, %r910
  %r913 = load double, ptr %r903, align 8
  %r914 = bitcast double %r913 to i64
  store double %r821353, ptr %r903, align 8
  call void @js_string_addref_if_heap_string(double %r821353) #7
  %r915 = bitcast double %r821353 to i64
  %r4651.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated359 to i64
  %r4651.rs4o = call i64 asm "", "=r,0"(i64 %r4651.rs4i) #7
  %r4651 = bitcast i64 %r4651.rs4o to double
  %r4652 = bitcast double %r4651 to i64
  %r4653 = and i64 %r4652, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4653, i32 %r909, i64 %r915, i64 %r914) #7
  %r4649.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated359 to i64
  %r4649.rs4o = call i64 asm "", "=r,0"(i64 %r4649.rs4i) #7
  %r4649 = bitcast i64 %r4649.rs4o to double
  %r4650 = bitcast double %r4649 to i64
  call void @js_write_barrier_slot(i64 %r4650, i64 %r912, i64 %r915) #7
  br label %put.dynic.merge.152

put.dynic.trans.gate.142:                         ; preds = %put.dynic.guard.133
  %r883 = and i1 %r880, %r876
  br i1 %r883, label %put.dynic.trans.probe.143, label %put.dynic.slow.151

put.dynic.trans.probe.143:                        ; preds = %put.dynic.trans.gate.142, %put.dynic.way2.136
  %r916 = lshr i64 %r822, 48
  %r917 = icmp eq i64 %r916, 32767
  %r918 = and i64 %r822, 281474976710655
  %r919 = icmp ugt i64 %r918, 1048575
  %r920 = and i16 %r854, -16384
  %r921 = icmp eq i16 %r920, 0
  %r922 = and i8 %r849, 32
  %r923 = icmp eq i8 %r922, 0
  %r924 = and i1 %r917, %r919
  %r925 = and i1 %r924, %r921
  %r926 = and i1 %r925, %r923
  br i1 %r926, label %put.dynic.trans.key.144, label %put.dynic.slow.151

put.dynic.trans.key.144:                          ; preds = %put.dynic.trans.probe.143
  %r927 = and i64 %r822, 281474976710655
  %r928 = add nuw nsw i64 %r927, 4
  %r929 = inttoptr i64 %r928 to ptr
  %r930 = load i32, ptr %r929, align 4
  %r931 = icmp uge i32 %r930, 6
  %r932 = icmp ule i32 %r930, 8
  %r933 = add nuw nsw i64 %r927, 20
  %r934 = inttoptr i64 %r933 to ptr
  %r935 = load i8, ptr %r934, align 1
  %r936 = sub i8 %r935, 48
  %r937 = icmp ult i8 %r936, 10
  %r938 = icmp eq i1 %r937, false
  %r939 = and i1 %r931, %r932
  %r940 = and i1 %r939, %r938
  br i1 %r940, label %put.dynic.trans.entry.145, label %put.dynic.slow.151

put.dynic.trans.entry.145:                        ; preds = %put.dynic.trans.key.144
  %r941 = add nuw nsw i64 %r927, 20
  %r942 = inttoptr i64 %r941 to ptr
  %r943 = load i64, ptr %r942, align 8
  %r944 = zext nneg i32 %r930 to i64
  %r945 = sub nuw nsw i64 8, %r944
  %r946 = shl nuw nsw i64 %r945, 3
  %r947 = lshr i64 -1, %r946
  %r948 = and i64 %r943, %r947
  %r950 = ptrtoint ptr %r92 to i64
  %r951 = zext i32 %r867 to i64
  %r952 = mul i64 %r951, -7046029254386353131
  %r953 = lshr i64 %r948, 3
  %r954 = mul i64 %r953, -4126379630918253789
  %r955 = xor i64 %r952, %r954
  %r956 = and i64 %r955, 16383
  %r957 = shl nuw nsw i64 %r956, 5
  %r958 = add i64 %r950, %r957
  %r959 = inttoptr i64 %r958 to ptr
  %r960 = load i64, ptr %r959, align 8
  %r961 = add i64 %r958, 8
  %r962 = inttoptr i64 %r961 to ptr
  %r963 = load i64, ptr %r962, align 8
  %r964 = add i64 %r958, 16
  %r965 = inttoptr i64 %r964 to ptr
  %r966 = load i32, ptr %r965, align 4
  %r967 = add i64 %r958, 20
  %r968 = inttoptr i64 %r967 to ptr
  %r969 = load i32, ptr %r968, align 4
  %r970 = add i64 %r958, 24
  %r971 = inttoptr i64 %r970 to ptr
  %r972 = load i32, ptr %r971, align 4
  %r973 = lshr i32 %r972, 24
  %r974 = and i32 %r972, 16777215
  %r975 = add i64 %r958, 28
  %r976 = inttoptr i64 %r975 to ptr
  %r977 = load i32, ptr %r976, align 4
  %r978 = icmp eq i64 %r960, %r948
  %r979 = icmp eq i32 %r973, %r930
  %r980 = icmp eq i32 %r966, %r867
  %r981 = icmp ne i64 %r963, 0
  %r982 = add nuw nsw i32 %r974, 1
  %r983 = icmp eq i32 %r977, %r982
  %r984 = zext nneg i32 %r974 to i64
  %r985 = and i64 %r828, 281474976710655
  %r986 = icmp eq i64 %r834, 32765
  %r987 = icmp eq i64 %r985, 0
  %r988 = and i1 %r986, %r987
  %r989 = select i1 %r988, i64 9222246136947933185, i64 %r828
  %r990 = bitcast i64 %r989 to double
  %r991 = and i1 %r978, %r979
  %r992 = and i1 %r991, %r980
  %r993 = and i1 %r992, %r981
  %r994 = and i1 %r993, %r983
  br i1 %r994, label %put.dynic.trans.nk.146, label %put.dynic.slow.151

put.dynic.trans.nk.146:                           ; preds = %put.dynic.trans.entry.145
  %r995 = inttoptr i64 %r963 to ptr
  %r996 = load i32, ptr %r995, align 4
  %r997 = icmp eq i32 %r996, %r982
  br i1 %r997, label %put.dynic.trans.dispatch.147, label %put.dynic.slow.151

put.dynic.trans.dispatch.147:                     ; preds = %put.dynic.trans.nk.146
  %r998 = icmp ult i64 %r984, 2
  br i1 %r998, label %put.dynic.trans.inline_ref.148, label %put.dynic.trans.ovf.149

put.dynic.trans.inline_ref.148:                   ; preds = %put.dynic.trans.dispatch.147
  %r999 = shl nuw nsw i64 %r984, 3
  %r1000 = add nuw nsw i64 %r999, 16
  %r1001 = add nuw nsw i64 %r830, %r1000
  %r1002 = inttoptr i64 %r1001 to ptr
  %r1003 = trunc nuw nsw i64 %r984 to i32
  %r1004 = load double, ptr %r1002, align 8
  %r1005 = bitcast double %r1004 to i64
  store double %r990, ptr %r1002, align 8
  call void @js_string_addref_if_heap_string(double %r990) #7
  %r1006 = bitcast double %r990 to i64
  %r4646.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated359 to i64
  %r4646.rs4o = call i64 asm "", "=r,0"(i64 %r4646.rs4i) #7
  %r4646 = bitcast i64 %r4646.rs4o to double
  %r4647 = bitcast double %r4646 to i64
  %r4648 = and i64 %r4647, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4648, i32 %r1003, i64 %r1006, i64 %r1005) #7
  %r4644.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated359 to i64
  %r4644.rs4o = call i64 asm "", "=r,0"(i64 %r4644.rs4i) #7
  %r4644 = bitcast i64 %r4644.rs4o to double
  %r4645 = bitcast double %r4644 to i64
  call void @js_write_barrier_slot(i64 %r4645, i64 %r1001, i64 %r1006) #7
  br label %put.dynic.trans.stamp.150

put.dynic.trans.ovf.149:                          ; preds = %put.dynic.trans.dispatch.147
  %r1007 = trunc nuw nsw i64 %r984 to i32
  %r1008 = call i32 @js_transition_ic_spill_append(double %r824, i64 %r872, i32 %r1007, double %r990) #7
  %r1009 = icmp ne i32 %r1008, 0
  br i1 %r1009, label %put.dynic.trans.stamp.150, label %put.dynic.slow.151

put.dynic.trans.stamp.150:                        ; preds = %put.dynic.trans.ovf.149, %put.dynic.trans.inline_ref.148
  %r4641.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated359 to i64
  %r4641.rs4o = call i64 asm "", "=r,0"(i64 %r4641.rs4i) #7
  %r4641 = bitcast i64 %r4641.rs4o to double
  %r4642 = bitcast double %r4641 to i64
  %r4643 = and i64 %r4642, 281474976710655
  %r1010 = add nuw nsw i64 %r4643, 4
  %r1011 = inttoptr i64 %r1010 to ptr
  store i32 %r969, ptr %r1011, align 4
  br label %put.dynic.merge.152

put.dynic.slow.151:                               ; preds = %put.dynic.trans.ovf.149, %put.dynic.trans.nk.146, %put.dynic.trans.entry.145, %put.dynic.trans.key.144, %put.dynic.trans.probe.143, %put.dynic.trans.gate.142, %put.dynic.store.validate.138, %shadow.root.barrier.done.132
  %statepoint_token361 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_large_string_emitters_ts__3, double %r824, double %r823, double %r821353, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.0.relocated354, ptr addrspace(1) %r8.0.relocated355, ptr addrspace(1) %rs4gc.s15.relocated356, ptr addrspace(1) %rs4gc.s13.relocated357, ptr addrspace(1) %rs4gc.s9.relocated358, ptr addrspace(1) %rs4gc.s18.relocated359) ]
  %r1012362 = call double @llvm.experimental.gc.result.f64(token %statepoint_token361)
  %r497.0.relocated363 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token361, i32 0, i32 0) ; (%r497.0.relocated354, %r497.0.relocated354)
  %r8.0.relocated364 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token361, i32 1, i32 1) ; (%r8.0.relocated355, %r8.0.relocated355)
  %rs4gc.s15.relocated365 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token361, i32 2, i32 2) ; (%rs4gc.s15.relocated356, %rs4gc.s15.relocated356)
  %rs4gc.s13.relocated366 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token361, i32 3, i32 3) ; (%rs4gc.s13.relocated357, %rs4gc.s13.relocated357)
  %rs4gc.s9.relocated367 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token361, i32 4, i32 4) ; (%rs4gc.s9.relocated358, %rs4gc.s9.relocated358)
  %rs4gc.s18.relocated368 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token361, i32 5, i32 5) ; (%rs4gc.s18.relocated359, %rs4gc.s18.relocated359)
  br label %put.dynic.merge.152

put.dynic.merge.152:                              ; preds = %put.dynic.slow.151, %put.dynic.trans.stamp.150, %put.dynic.store.ref.141, %put.dynic.store.scalar.140
  %.01483 = phi ptr addrspace(1) [ %r497.0.relocated363, %put.dynic.slow.151 ], [ %r497.0.relocated354, %put.dynic.store.scalar.140 ], [ %r497.0.relocated354, %put.dynic.store.ref.141 ], [ %r497.0.relocated354, %put.dynic.trans.stamp.150 ]
  %.71467 = phi ptr addrspace(1) [ %rs4gc.s18.relocated368, %put.dynic.slow.151 ], [ %rs4gc.s18.relocated359, %put.dynic.store.scalar.140 ], [ %rs4gc.s18.relocated359, %put.dynic.store.ref.141 ], [ %rs4gc.s18.relocated359, %put.dynic.trans.stamp.150 ]
  %.81434 = phi ptr addrspace(1) [ %rs4gc.s15.relocated365, %put.dynic.slow.151 ], [ %rs4gc.s15.relocated356, %put.dynic.store.scalar.140 ], [ %rs4gc.s15.relocated356, %put.dynic.store.ref.141 ], [ %rs4gc.s15.relocated356, %put.dynic.trans.stamp.150 ]
  %.111376 = phi ptr addrspace(1) [ %rs4gc.s13.relocated366, %put.dynic.slow.151 ], [ %rs4gc.s13.relocated357, %put.dynic.store.scalar.140 ], [ %rs4gc.s13.relocated357, %put.dynic.store.ref.141 ], [ %rs4gc.s13.relocated357, %put.dynic.trans.stamp.150 ]
  %.81318 = phi ptr addrspace(1) [ %r8.0.relocated364, %put.dynic.slow.151 ], [ %r8.0.relocated355, %put.dynic.store.scalar.140 ], [ %r8.0.relocated355, %put.dynic.store.ref.141 ], [ %r8.0.relocated355, %put.dynic.trans.stamp.150 ]
  %.11 = phi ptr addrspace(1) [ %rs4gc.s9.relocated367, %put.dynic.slow.151 ], [ %rs4gc.s9.relocated358, %put.dynic.store.scalar.140 ], [ %rs4gc.s9.relocated358, %put.dynic.store.ref.141 ], [ %rs4gc.s9.relocated358, %put.dynic.trans.stamp.150 ]
  %r1013 = phi double [ %r821353, %put.dynic.store.scalar.140 ], [ %r821353, %put.dynic.store.ref.141 ], [ %r990, %put.dynic.trans.stamp.150 ], [ %r1012362, %put.dynic.slow.151 ]
  %r1014.rs4i = ptrtoint ptr addrspace(1) %.71467 to i64
  %r1014.rs4o = call i64 asm "", "=r,0"(i64 %r1014.rs4i) #7
  %r1014 = bitcast i64 %r1014.rs4o to double
  %r1015.rs4i = ptrtoint ptr addrspace(1) %.111376 to i64
  %r1015.rs4o = call i64 asm "", "=r,0"(i64 %r1015.rs4i) #7
  %r1015 = bitcast i64 %r1015.rs4o to double
  br label %ternary.else.154

ternary.else.154:                                 ; preds = %put.dynic.merge.152
  br label %ternary.merge.155

ternary.merge.155:                                ; preds = %ternary.else.154
  %statepoint_token369 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1014, double %r1015, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81318, ptr addrspace(1) %.81434, ptr addrspace(1) %.111376, ptr addrspace(1) %.11, ptr addrspace(1) %.71467, ptr addrspace(1) %.01483) ]
  %r1030370 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token369)
  %r8.0.relocated371 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token369, i32 0, i32 0) ; (%.81318, %.81318)
  %rs4gc.s15.relocated372 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token369, i32 1, i32 1) ; (%.81434, %.81434)
  %rs4gc.s13.relocated373 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token369, i32 2, i32 2) ; (%.111376, %.111376)
  %rs4gc.s9.relocated374 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token369, i32 3, i32 3) ; (%.11, %.11)
  %rs4gc.s18.relocated375 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token369, i32 4, i32 4) ; (%.71467, %.71467)
  %r497.0.relocated376 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token369, i32 5, i32 5) ; (%.01483, %.01483)
  %r1031 = bitcast i64 %r1030370 to double
  %r1032 = bitcast i64 %r1030370 to double
  %r1033.rs4i = ptrtoint ptr addrspace(1) %r497.0.relocated376 to i64
  %r1033.rs4o = call i64 asm "", "=r,0"(i64 %r1033.rs4i) #7
  %r1033 = bitcast i64 %r1033.rs4o to double
  %r1034 = bitcast double %r1033 to i64
  %r1035 = and i64 %r1034, 281474976710655
  %r1036 = sub nsw i64 %r1035, 8
  %r1037 = inttoptr i64 %r1036 to ptr
  %r1038 = load i8, ptr %r1037, align 1
  %r1039 = icmp ne i8 %r1038, 1
  %r1040 = sub nsw i64 %r1035, 7
  %r1041 = inttoptr i64 %r1040 to ptr
  %r1042 = load i8, ptr %r1041, align 1
  %r1043 = and i8 %r1042, -128
  %r1044 = icmp ne i8 %r1043, 0
  %r1045 = or i1 %r1039, %r1044
  br i1 %r1044, label %apush.fwd.156, label %apush.elements.157

apush.fwd.156:                                    ; preds = %apush.elements.check.158, %ternary.merge.155
  %statepoint_token377 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1035, double %r1032, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated375, ptr addrspace(1) %r8.0.relocated371, ptr addrspace(1) %rs4gc.s15.relocated372, ptr addrspace(1) %rs4gc.s13.relocated373, ptr addrspace(1) %rs4gc.s9.relocated374) ]
  %r1072378 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token377)
  %rs4gc.s18.relocated379 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 0, i32 0) ; (%rs4gc.s18.relocated375, %rs4gc.s18.relocated375)
  %r8.0.relocated380 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 1, i32 1) ; (%r8.0.relocated371, %r8.0.relocated371)
  %rs4gc.s15.relocated381 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 2, i32 2) ; (%rs4gc.s15.relocated372, %rs4gc.s15.relocated372)
  %rs4gc.s13.relocated382 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 3, i32 3) ; (%rs4gc.s13.relocated373, %rs4gc.s13.relocated373)
  %rs4gc.s9.relocated383 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 4, i32 4) ; (%rs4gc.s9.relocated374, %rs4gc.s9.relocated374)
  %r1073 = or i64 %r1072378, 9222527611924643840
  %r1074 = bitcast i64 %r1073 to double
  %rs4gc.b30 = bitcast double %r1074 to i64
  %rs4gc.s30 = inttoptr i64 %rs4gc.b30 to ptr addrspace(1)
  br label %apush.merge.162

apush.elements.157:                               ; preds = %ternary.merge.155
  %r1047 = add nuw nsw i64 %r1035, 8
  %r1048 = inttoptr i64 %r1047 to ptr
  %r1049 = load i64, ptr %r1048, align 8
  %r1050 = icmp ne i64 %r1049, 0
  %r1051 = icmp eq i8 %r1038, 2
  %r1052 = and i1 %r1051, %r1050
  %r1053 = select i1 %r1052, i64 %r1049, i64 %r1035
  %r1054 = inttoptr i64 %r1053 to ptr
  %r1055 = getelementptr i64, ptr %r1054, i64 12
  %r1056 = load i64, ptr %r1055, align 8
  %r1057 = icmp ne i64 %r1056, 0
  %r1058 = and i1 %r1052, %r1057
  %r1059 = select i1 %r1058, i64 %r1056, i64 %r1035
  %r1046 = icmp eq i8 %r1038, 1
  br i1 %r1046, label %apush.nofwd.159, label %apush.elements.check.158

apush.elements.check.158:                         ; preds = %apush.elements.157
  %r1060 = icmp ne i64 %r1059, 0
  %r1061 = sub i64 %r1059, 8
  %r1062 = inttoptr i64 %r1061 to ptr
  %r1063 = load i8, ptr %r1062, align 1
  %r1064 = icmp eq i8 %r1063, 1
  %r1065 = sub i64 %r1059, 7
  %r1066 = inttoptr i64 %r1065 to ptr
  %r1067 = load i8, ptr %r1066, align 1
  %r1068 = and i8 %r1067, -128
  %r1069 = icmp eq i8 %r1068, 0
  %r1070 = and i1 %r1060, %r1064
  %r1071 = and i1 %r1070, %r1069
  br i1 %r1071, label %apush.nofwd.159, label %apush.fwd.156

apush.nofwd.159:                                  ; preds = %apush.elements.check.158, %apush.elements.157
  %r1075 = phi i64 [ %r1035, %apush.elements.157 ], [ %r1059, %apush.elements.check.158 ]
  %r1076 = sub i64 %r1075, 6
  %r1077 = inttoptr i64 %r1076 to ptr
  %r1078 = load i16, ptr %r1077, align 2
  %r1079 = and i16 %r1078, 1031
  %r1080 = icmp eq i16 %r1079, 0
  %r1081 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1082 = icmp eq i8 %r1081, 0
  %r1083 = and i1 %r1080, %r1082
  %r1084 = icmp ult i64 %r1075, 4096
  %r1085 = inttoptr i64 %r1075 to ptr
  %r1086 = select i1 %r1084, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r1085
  %r1087 = load i32, ptr %r1086, align 4
  %r1088 = add i64 %r1075, 4
  %r1089 = inttoptr i64 %r1088 to ptr
  %r1090 = load i32, ptr %r1089, align 4
  %r1091 = icmp ult i32 %r1087, %r1090
  %r1092 = and i1 %r1091, %r1083
  br i1 %r1092, label %apush.inbounds.160, label %apush.realloc.161

apush.inbounds.160:                               ; preds = %apush.nofwd.159
  %r1093 = icmp ult i64 %r1075, 4096
  %r1094 = inttoptr i64 %r1075 to ptr
  %r1095 = select i1 %r1093, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r1094
  %r1096 = load i32, ptr %r1095, align 4
  %r1097 = zext i32 %r1096 to i64
  %r1098 = shl nuw nsw i64 %r1097, 3
  %r1099 = add nuw nsw i64 %r1098, 8
  %r1100 = add i64 %r1075, %r1099
  %r1101 = inttoptr i64 %r1100 to ptr
  store double %r1032, ptr %r1101, align 8
  %r1102 = lshr i64 %r1030370, 48
  %r1103 = icmp eq i64 %r1102, 32765
  %r1104 = and i16 %r1078, -1920
  %r1105 = icmp eq i16 %r1104, -24576
  %r1106 = and i1 %r1103, %r1105
  br i1 %r1106, label %apush.pointer_layout.done.164, label %apush.pointer_layout.bookkeeping.163

apush.realloc.161:                                ; preds = %apush.nofwd.159
  %statepoint_token384 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1035, double %r1032, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated375, ptr addrspace(1) %r8.0.relocated371, ptr addrspace(1) %rs4gc.s15.relocated372, ptr addrspace(1) %rs4gc.s13.relocated373, ptr addrspace(1) %rs4gc.s9.relocated374) ]
  %r1117385 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token384)
  %rs4gc.s18.relocated386 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token384, i32 0, i32 0) ; (%rs4gc.s18.relocated375, %rs4gc.s18.relocated375)
  %r8.0.relocated387 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token384, i32 1, i32 1) ; (%r8.0.relocated371, %r8.0.relocated371)
  %rs4gc.s15.relocated388 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token384, i32 2, i32 2) ; (%rs4gc.s15.relocated372, %rs4gc.s15.relocated372)
  %rs4gc.s13.relocated389 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token384, i32 3, i32 3) ; (%rs4gc.s13.relocated373, %rs4gc.s13.relocated373)
  %rs4gc.s9.relocated390 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token384, i32 4, i32 4) ; (%rs4gc.s9.relocated374, %rs4gc.s9.relocated374)
  %r1118 = or i64 %r1117385, 9222527611924643840
  %r1119 = bitcast i64 %r1118 to double
  %rs4gc.b31 = bitcast double %r1119 to i64
  %rs4gc.s31 = inttoptr i64 %rs4gc.b31 to ptr addrspace(1)
  br label %apush.merge.162

apush.merge.162:                                  ; preds = %apush.barrier.done.166, %apush.realloc.161, %apush.fwd.156
  %.81468 = phi ptr addrspace(1) [ %rs4gc.s18.relocated379, %apush.fwd.156 ], [ %rs4gc.s18.relocated375, %apush.barrier.done.166 ], [ %rs4gc.s18.relocated386, %apush.realloc.161 ]
  %.91435 = phi ptr addrspace(1) [ %rs4gc.s15.relocated381, %apush.fwd.156 ], [ %rs4gc.s15.relocated372, %apush.barrier.done.166 ], [ %rs4gc.s15.relocated388, %apush.realloc.161 ]
  %.121377 = phi ptr addrspace(1) [ %rs4gc.s13.relocated382, %apush.fwd.156 ], [ %rs4gc.s13.relocated373, %apush.barrier.done.166 ], [ %rs4gc.s13.relocated389, %apush.realloc.161 ]
  %.91319 = phi ptr addrspace(1) [ %r8.0.relocated380, %apush.fwd.156 ], [ %r8.0.relocated371, %apush.barrier.done.166 ], [ %r8.0.relocated387, %apush.realloc.161 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s9.relocated383, %apush.fwd.156 ], [ %rs4gc.s9.relocated374, %apush.barrier.done.166 ], [ %rs4gc.s9.relocated390, %apush.realloc.161 ]
  %r497.1 = phi ptr addrspace(1) [ %rs4gc.s30, %apush.fwd.156 ], [ %r497.0.relocated376, %apush.barrier.done.166 ], [ %rs4gc.s31, %apush.realloc.161 ]
  %r1120.rs4i = ptrtoint ptr addrspace(1) %.91435 to i64
  %r1120.rs4o = call i64 asm "", "=r,0"(i64 %r1120.rs4i) #7
  %r1120 = bitcast i64 %r1120.rs4o to double
  %r1121 = bitcast double %r1120 to i64
  %rs4gc.s32 = inttoptr i64 %r1121 to ptr addrspace(1)
  %r1122.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s32 to i64
  %r1122 = call i64 asm "", "=r,0"(i64 %r1122.rs4i) #7
  %r1123 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1124 = icmp ne i32 %r1123, 0
  br i1 %r1124, label %shadow.root.barrier.167, label %shadow.root.barrier.done.168

apush.pointer_layout.bookkeeping.163:             ; preds = %apush.inbounds.160
  call void @js_string_addref_if_heap_string(double %r1032) #7
  call void @js_gc_note_slot_layout(i64 %r1075, i32 %r1096, i64 %r1030370) #7
  call void @js_array_note_numeric_write(i64 %r1075, i64 %r1030370) #7
  br label %apush.pointer_layout.done.164

apush.pointer_layout.done.164:                    ; preds = %apush.pointer_layout.bookkeeping.163, %apush.inbounds.160
  %r1107 = sub i64 %r1075, 7
  %r1108 = inttoptr i64 %r1107 to ptr
  %r1109 = load i8, ptr %r1108, align 1
  %r1110 = and i8 %r1109, 32
  %r1111 = icmp ne i8 %r1110, 0
  %r1112 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1113 = icmp ne i32 %r1112, 0
  %r1114 = or i1 %r1111, %r1113
  br i1 %r1114, label %apush.barrier.165, label %apush.barrier.done.166

apush.barrier.165:                                ; preds = %apush.pointer_layout.done.164
  call void @js_write_barrier_slot_validated_parent(i64 %r1075, i64 %r1100, i64 %r1030370) #7
  br label %apush.barrier.done.166

apush.barrier.done.166:                           ; preds = %apush.barrier.165, %apush.pointer_layout.done.164
  %r1115 = add i32 %r1096, 1
  %r1116 = inttoptr i64 %r1075 to ptr
  store i32 %r1115, ptr %r1116, align 4
  br label %apush.merge.162

shadow.root.barrier.167:                          ; preds = %apush.merge.162
  call void @js_write_barrier_root_nanbox(i64 %r1122) #7
  br label %shadow.root.barrier.done.168

shadow.root.barrier.done.168:                     ; preds = %shadow.root.barrier.167, %apush.merge.162
  %r1125.rs4i = ptrtoint ptr addrspace(1) %.91319 to i64
  %r1125.rs4o = call i64 asm "", "=r,0"(i64 %r1125.rs4i) #7
  %r1125 = bitcast i64 %r1125.rs4o to double
  %r1126 = load double, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  %statepoint_token391 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r1125, double %r1126, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.1, ptr addrspace(1) %.91319, ptr addrspace(1) %.91435, ptr addrspace(1) %.121377, ptr addrspace(1) %.12, ptr addrspace(1) %.81468, ptr addrspace(1) %rs4gc.s32) ]
  %r1127392 = call double @llvm.experimental.gc.result.f64(token %statepoint_token391)
  %r497.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 0, i32 0) ; (%r497.1, %r497.1)
  %r8.0.relocated393 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 1, i32 1) ; (%.91319, %.91319)
  %rs4gc.s15.relocated394 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 2, i32 2) ; (%.91435, %.91435)
  %rs4gc.s13.relocated395 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 3, i32 3) ; (%.121377, %.121377)
  %rs4gc.s9.relocated396 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 4, i32 4) ; (%.12, %.12)
  %rs4gc.s18.relocated397 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 5, i32 5) ; (%.81468, %.81468)
  %rs4gc.s32.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 6, i32 6) ; (%rs4gc.s32, %rs4gc.s32)
  %statepoint_token398 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r1127392, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.1.relocated, ptr addrspace(1) %r8.0.relocated393, ptr addrspace(1) %rs4gc.s15.relocated394, ptr addrspace(1) %rs4gc.s13.relocated395, ptr addrspace(1) %rs4gc.s9.relocated396, ptr addrspace(1) %rs4gc.s18.relocated397, ptr addrspace(1) %rs4gc.s32.relocated) ]
  %r1128399 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token398)
  %r497.1.relocated400 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 0, i32 0) ; (%r497.1.relocated, %r497.1.relocated)
  %r8.0.relocated401 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 1, i32 1) ; (%r8.0.relocated393, %r8.0.relocated393)
  %rs4gc.s15.relocated402 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 2, i32 2) ; (%rs4gc.s15.relocated394, %rs4gc.s15.relocated394)
  %rs4gc.s13.relocated403 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 3, i32 3) ; (%rs4gc.s13.relocated395, %rs4gc.s13.relocated395)
  %rs4gc.s9.relocated404 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 4, i32 4) ; (%rs4gc.s9.relocated396, %rs4gc.s9.relocated396)
  %rs4gc.s18.relocated405 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 5, i32 5) ; (%rs4gc.s18.relocated397, %rs4gc.s18.relocated397)
  %rs4gc.s32.relocated406 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 6, i32 6) ; (%rs4gc.s32.relocated, %rs4gc.s32.relocated)
  %statepoint_token407 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r1128399, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.1.relocated400, ptr addrspace(1) %r8.0.relocated401, ptr addrspace(1) %rs4gc.s15.relocated402, ptr addrspace(1) %rs4gc.s13.relocated403, ptr addrspace(1) %rs4gc.s9.relocated404, ptr addrspace(1) %rs4gc.s18.relocated405, ptr addrspace(1) %rs4gc.s32.relocated406) ]
  %r1129408 = call double @llvm.experimental.gc.result.f64(token %statepoint_token407)
  %r497.1.relocated409 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 0, i32 0) ; (%r497.1.relocated400, %r497.1.relocated400)
  %r8.0.relocated410 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 1, i32 1) ; (%r8.0.relocated401, %r8.0.relocated401)
  %rs4gc.s15.relocated411 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 2, i32 2) ; (%rs4gc.s15.relocated402, %rs4gc.s15.relocated402)
  %rs4gc.s13.relocated412 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 3, i32 3) ; (%rs4gc.s13.relocated403, %rs4gc.s13.relocated403)
  %rs4gc.s9.relocated413 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 4, i32 4) ; (%rs4gc.s9.relocated404, %rs4gc.s9.relocated404)
  %rs4gc.s18.relocated414 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 5, i32 5) ; (%rs4gc.s18.relocated405, %rs4gc.s18.relocated405)
  %rs4gc.s32.relocated415 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 6, i32 6) ; (%rs4gc.s32.relocated406, %rs4gc.s32.relocated406)
  %r1130.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s32.relocated415 to i64
  %r1130 = call i64 asm "", "=r,0"(i64 %r1130.rs4i) #7
  %r1131 = bitcast i64 %r1130 to double
  %r1132.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated414 to i64
  %r1132.rs4o = call i64 asm "", "=r,0"(i64 %r1132.rs4i) #7
  %r1132 = bitcast i64 %r1132.rs4o to double
  %r1133 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__4, align 8
  %r1134 = icmp ne ptr %r1133, null
  %r1135 = select i1 %r1134, ptr %r1133, ptr @perry_ic_test_json_large_string_emitters_ts__4
  %r1136 = bitcast double %r1129408 to i64
  %r1137 = bitcast double %r1132 to i64
  %r1138 = and i64 %r1137, 281474976710655
  %r1139 = lshr i64 %r1137, 48
  %r1140 = icmp eq i64 %r1139, 32765
  %r1141 = icmp ugt i64 %r1138, 1048575
  %r1142 = lshr i64 %r1136, 48
  %r1143 = icmp ne i64 %r1142, 32765
  %r1144 = icmp ne i64 %r1142, 32767
  %r1145 = icmp ne i64 %r1142, 32762
  %r1146 = and i1 %r1143, %r1144
  %r1147 = and i1 %r1146, %r1145
  %r1148 = icmp ne i64 %r1130, 0
  %r1149 = and i1 %r1140, %r1141
  %r1150 = and i1 %r1149, %r1148
  br i1 %r1150, label %put.dynic.guard.169, label %put.dynic.slow.187

put.dynic.guard.169:                              ; preds = %shadow.root.barrier.done.168
  %r1151 = sub nuw nsw i64 %r1138, 8
  %r1152 = inttoptr i64 %r1151 to ptr
  %r1153 = load i8, ptr %r1152, align 1
  %r1154 = icmp eq i8 %r1153, 2
  %r1155 = sub nuw nsw i64 %r1138, 7
  %r1156 = inttoptr i64 %r1155 to ptr
  %r1157 = load i8, ptr %r1156, align 1
  %r1158 = and i8 %r1157, -128
  %r1159 = icmp eq i8 %r1158, 0
  %r1160 = sub nuw nsw i64 %r1138, 6
  %r1161 = inttoptr i64 %r1160 to ptr
  %r1162 = load i16, ptr %r1161, align 2
  %r1163 = and i16 %r1162, 6535
  %r1164 = icmp eq i16 %r1163, 0
  %r1165 = add nuw nsw i64 %r1138, 0
  %r1166 = inttoptr i64 %r1165 to ptr
  %r1167 = load i32, ptr %r1166, align 4
  %r1168 = icmp ne i32 %r1167, 0
  %r1169 = icmp ne i32 %r1167, -2
  %r1170 = and i16 %r1162, 512
  %r1171 = icmp ne i16 %r1170, 0
  %r1172 = or i1 %r1168, %r1171
  %r1173 = add nuw nsw i64 %r1138, 4
  %r1174 = inttoptr i64 %r1173 to ptr
  %r1175 = load i32, ptr %r1174, align 4
  %r1176 = add i32 %r1175, -2147483648
  %r1177 = icmp ult i32 %r1176, 1073741824
  %r1178 = zext i32 %r1175 to i64
  %r1179 = or i64 %r1178, 4611686018427387904
  %r1180 = select i1 %r1177, i64 %r1179, i64 0
  %r1181 = getelementptr i64, ptr %r1135, i64 0
  %r1182 = load i64, ptr %r1181, align 8
  %r1183 = icmp eq i64 %r1180, %r1182
  %r1184 = icmp ne i64 %r1180, 0
  %r1185 = and i1 %r1154, %r1159
  %r1186 = and i1 %r1185, %r1164
  %r1187 = and i1 %r1186, %r1172
  %r1188 = and i1 %r1187, %r1169
  %r1189 = and i1 %r1183, %r1184
  %r1190 = and i1 %r1188, %r1189
  br i1 %r1190, label %put.dynic.ways.170, label %put.dynic.trans.gate.178

put.dynic.ways.170:                               ; preds = %put.dynic.guard.169
  %r1192 = getelementptr i64, ptr %r1133, i64 1
  %r1193 = load i64, ptr %r1192, align 8
  %r1194 = getelementptr i64, ptr %r1133, i64 2
  %r1195 = load i64, ptr %r1194, align 8
  %r1196 = icmp eq i64 %r1130, %r1193
  br i1 %r1196, label %put.dynic.store.173, label %put.dynic.way1.171

put.dynic.way1.171:                               ; preds = %put.dynic.ways.170
  %r1197 = getelementptr i64, ptr %r1133, i64 3
  %r1198 = load i64, ptr %r1197, align 8
  %r1199 = getelementptr i64, ptr %r1133, i64 4
  %r1200 = load i64, ptr %r1199, align 8
  %r1201 = icmp eq i64 %r1130, %r1198
  br i1 %r1201, label %put.dynic.store.173, label %put.dynic.way2.172

put.dynic.way2.172:                               ; preds = %put.dynic.way1.171
  %r1202 = getelementptr i64, ptr %r1133, i64 5
  %r1203 = load i64, ptr %r1202, align 8
  %r1204 = getelementptr i64, ptr %r1133, i64 6
  %r1205 = load i64, ptr %r1204, align 8
  %r1206 = icmp eq i64 %r1130, %r1203
  br i1 %r1206, label %put.dynic.store.173, label %put.dynic.trans.probe.179

put.dynic.store.173:                              ; preds = %put.dynic.way2.172, %put.dynic.way1.171, %put.dynic.ways.170
  %r1207 = phi i64 [ %r1195, %put.dynic.ways.170 ], [ %r1200, %put.dynic.way1.171 ], [ %r1205, %put.dynic.way2.172 ]
  %r1208 = shl i64 %r1207, 3
  %r1209 = add i64 %r1208, 16
  %r1210 = inttoptr i64 %r1138 to ptr
  %r1211 = getelementptr inbounds i8, ptr %r1210, i64 %r1209
  %r1212 = and i16 %r1162, 1024
  %r1213 = icmp ne i16 %r1212, 0
  br i1 %r1213, label %put.dynic.store.validate.174, label %put.dynic.store.dispatch.175

put.dynic.store.validate.174:                     ; preds = %put.dynic.store.173
  %r1214 = load double, ptr %r1211, align 8
  %r1215 = bitcast double %r1214 to i64
  %r1216 = icmp eq i64 %r1215, 9222246136947933200
  br i1 %r1216, label %put.dynic.slow.187, label %put.dynic.store.dispatch.175

put.dynic.store.dispatch.175:                     ; preds = %put.dynic.store.validate.174, %put.dynic.store.173
  br i1 %r1147, label %put.dynic.store.scalar.176, label %put.dynic.store.ref.177

put.dynic.store.scalar.176:                       ; preds = %put.dynic.store.dispatch.175
  store double %r1129408, ptr %r1211, align 8
  br label %put.dynic.merge.188

put.dynic.store.ref.177:                          ; preds = %put.dynic.store.dispatch.175
  %r1217 = trunc i64 %r1207 to i32
  %r1218 = shl i64 %r1207, 3
  %r1219 = add nuw nsw i64 %r1138, 16
  %r1220 = add i64 %r1219, %r1218
  %r1221 = load double, ptr %r1211, align 8
  %r1222 = bitcast double %r1221 to i64
  store double %r1129408, ptr %r1211, align 8
  call void @js_string_addref_if_heap_string(double %r1129408) #7
  %r1223 = bitcast double %r1129408 to i64
  %r4638.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated414 to i64
  %r4638.rs4o = call i64 asm "", "=r,0"(i64 %r4638.rs4i) #7
  %r4638 = bitcast i64 %r4638.rs4o to double
  %r4639 = bitcast double %r4638 to i64
  %r4640 = and i64 %r4639, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4640, i32 %r1217, i64 %r1223, i64 %r1222) #7
  %r4636.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated414 to i64
  %r4636.rs4o = call i64 asm "", "=r,0"(i64 %r4636.rs4i) #7
  %r4636 = bitcast i64 %r4636.rs4o to double
  %r4637 = bitcast double %r4636 to i64
  call void @js_write_barrier_slot(i64 %r4637, i64 %r1220, i64 %r1223) #7
  br label %put.dynic.merge.188

put.dynic.trans.gate.178:                         ; preds = %put.dynic.guard.169
  %r1191 = and i1 %r1188, %r1184
  br i1 %r1191, label %put.dynic.trans.probe.179, label %put.dynic.slow.187

put.dynic.trans.probe.179:                        ; preds = %put.dynic.trans.gate.178, %put.dynic.way2.172
  %r1224 = lshr i64 %r1130, 48
  %r1225 = icmp eq i64 %r1224, 32767
  %r1226 = and i64 %r1130, 281474976710655
  %r1227 = icmp ugt i64 %r1226, 1048575
  %r1228 = and i16 %r1162, -16384
  %r1229 = icmp eq i16 %r1228, 0
  %r1230 = and i8 %r1157, 32
  %r1231 = icmp eq i8 %r1230, 0
  %r1232 = and i1 %r1225, %r1227
  %r1233 = and i1 %r1232, %r1229
  %r1234 = and i1 %r1233, %r1231
  br i1 %r1234, label %put.dynic.trans.key.180, label %put.dynic.slow.187

put.dynic.trans.key.180:                          ; preds = %put.dynic.trans.probe.179
  %r1235 = and i64 %r1130, 281474976710655
  %r1236 = add nuw nsw i64 %r1235, 4
  %r1237 = inttoptr i64 %r1236 to ptr
  %r1238 = load i32, ptr %r1237, align 4
  %r1239 = icmp uge i32 %r1238, 6
  %r1240 = icmp ule i32 %r1238, 8
  %r1241 = add nuw nsw i64 %r1235, 20
  %r1242 = inttoptr i64 %r1241 to ptr
  %r1243 = load i8, ptr %r1242, align 1
  %r1244 = sub i8 %r1243, 48
  %r1245 = icmp ult i8 %r1244, 10
  %r1246 = icmp eq i1 %r1245, false
  %r1247 = and i1 %r1239, %r1240
  %r1248 = and i1 %r1247, %r1246
  br i1 %r1248, label %put.dynic.trans.entry.181, label %put.dynic.slow.187

put.dynic.trans.entry.181:                        ; preds = %put.dynic.trans.key.180
  %r1249 = add nuw nsw i64 %r1235, 20
  %r1250 = inttoptr i64 %r1249 to ptr
  %r1251 = load i64, ptr %r1250, align 8
  %r1252 = zext nneg i32 %r1238 to i64
  %r1253 = sub nuw nsw i64 8, %r1252
  %r1254 = shl nuw nsw i64 %r1253, 3
  %r1255 = lshr i64 -1, %r1254
  %r1256 = and i64 %r1251, %r1255
  %r1258 = ptrtoint ptr %r92 to i64
  %r1259 = zext i32 %r1175 to i64
  %r1260 = mul i64 %r1259, -7046029254386353131
  %r1261 = lshr i64 %r1256, 3
  %r1262 = mul i64 %r1261, -4126379630918253789
  %r1263 = xor i64 %r1260, %r1262
  %r1264 = and i64 %r1263, 16383
  %r1265 = shl nuw nsw i64 %r1264, 5
  %r1266 = add i64 %r1258, %r1265
  %r1267 = inttoptr i64 %r1266 to ptr
  %r1268 = load i64, ptr %r1267, align 8
  %r1269 = add i64 %r1266, 8
  %r1270 = inttoptr i64 %r1269 to ptr
  %r1271 = load i64, ptr %r1270, align 8
  %r1272 = add i64 %r1266, 16
  %r1273 = inttoptr i64 %r1272 to ptr
  %r1274 = load i32, ptr %r1273, align 4
  %r1275 = add i64 %r1266, 20
  %r1276 = inttoptr i64 %r1275 to ptr
  %r1277 = load i32, ptr %r1276, align 4
  %r1278 = add i64 %r1266, 24
  %r1279 = inttoptr i64 %r1278 to ptr
  %r1280 = load i32, ptr %r1279, align 4
  %r1281 = lshr i32 %r1280, 24
  %r1282 = and i32 %r1280, 16777215
  %r1283 = add i64 %r1266, 28
  %r1284 = inttoptr i64 %r1283 to ptr
  %r1285 = load i32, ptr %r1284, align 4
  %r1286 = icmp eq i64 %r1268, %r1256
  %r1287 = icmp eq i32 %r1281, %r1238
  %r1288 = icmp eq i32 %r1274, %r1175
  %r1289 = icmp ne i64 %r1271, 0
  %r1290 = add nuw nsw i32 %r1282, 1
  %r1291 = icmp eq i32 %r1285, %r1290
  %r1292 = zext nneg i32 %r1282 to i64
  %r1293 = and i64 %r1136, 281474976710655
  %r1294 = icmp eq i64 %r1142, 32765
  %r1295 = icmp eq i64 %r1293, 0
  %r1296 = and i1 %r1294, %r1295
  %r1297 = select i1 %r1296, i64 9222246136947933185, i64 %r1136
  %r1298 = bitcast i64 %r1297 to double
  %r1299 = and i1 %r1286, %r1287
  %r1300 = and i1 %r1299, %r1288
  %r1301 = and i1 %r1300, %r1289
  %r1302 = and i1 %r1301, %r1291
  br i1 %r1302, label %put.dynic.trans.nk.182, label %put.dynic.slow.187

put.dynic.trans.nk.182:                           ; preds = %put.dynic.trans.entry.181
  %r1303 = inttoptr i64 %r1271 to ptr
  %r1304 = load i32, ptr %r1303, align 4
  %r1305 = icmp eq i32 %r1304, %r1290
  br i1 %r1305, label %put.dynic.trans.dispatch.183, label %put.dynic.slow.187

put.dynic.trans.dispatch.183:                     ; preds = %put.dynic.trans.nk.182
  %r1306 = icmp ult i64 %r1292, 2
  br i1 %r1306, label %put.dynic.trans.inline_ref.184, label %put.dynic.trans.ovf.185

put.dynic.trans.inline_ref.184:                   ; preds = %put.dynic.trans.dispatch.183
  %r1307 = shl nuw nsw i64 %r1292, 3
  %r1308 = add nuw nsw i64 %r1307, 16
  %r1309 = add nuw nsw i64 %r1138, %r1308
  %r1310 = inttoptr i64 %r1309 to ptr
  %r1311 = trunc nuw nsw i64 %r1292 to i32
  %r1312 = load double, ptr %r1310, align 8
  %r1313 = bitcast double %r1312 to i64
  store double %r1298, ptr %r1310, align 8
  call void @js_string_addref_if_heap_string(double %r1298) #7
  %r1314 = bitcast double %r1298 to i64
  %r4633.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated414 to i64
  %r4633.rs4o = call i64 asm "", "=r,0"(i64 %r4633.rs4i) #7
  %r4633 = bitcast i64 %r4633.rs4o to double
  %r4634 = bitcast double %r4633 to i64
  %r4635 = and i64 %r4634, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4635, i32 %r1311, i64 %r1314, i64 %r1313) #7
  %r4631.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated414 to i64
  %r4631.rs4o = call i64 asm "", "=r,0"(i64 %r4631.rs4i) #7
  %r4631 = bitcast i64 %r4631.rs4o to double
  %r4632 = bitcast double %r4631 to i64
  call void @js_write_barrier_slot(i64 %r4632, i64 %r1309, i64 %r1314) #7
  br label %put.dynic.trans.stamp.186

put.dynic.trans.ovf.185:                          ; preds = %put.dynic.trans.dispatch.183
  %r1315 = trunc nuw nsw i64 %r1292 to i32
  %r1316 = call i32 @js_transition_ic_spill_append(double %r1132, i64 %r1180, i32 %r1315, double %r1298) #7
  %r1317 = icmp ne i32 %r1316, 0
  br i1 %r1317, label %put.dynic.trans.stamp.186, label %put.dynic.slow.187

put.dynic.trans.stamp.186:                        ; preds = %put.dynic.trans.ovf.185, %put.dynic.trans.inline_ref.184
  %r4628.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated414 to i64
  %r4628.rs4o = call i64 asm "", "=r,0"(i64 %r4628.rs4i) #7
  %r4628 = bitcast i64 %r4628.rs4o to double
  %r4629 = bitcast double %r4628 to i64
  %r4630 = and i64 %r4629, 281474976710655
  %r1318 = add nuw nsw i64 %r4630, 4
  %r1319 = inttoptr i64 %r1318 to ptr
  store i32 %r1277, ptr %r1319, align 4
  br label %put.dynic.merge.188

put.dynic.slow.187:                               ; preds = %put.dynic.trans.ovf.185, %put.dynic.trans.nk.182, %put.dynic.trans.entry.181, %put.dynic.trans.key.180, %put.dynic.trans.probe.179, %put.dynic.trans.gate.178, %put.dynic.store.validate.174, %shadow.root.barrier.done.168
  %statepoint_token416 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_large_string_emitters_ts__4, double %r1132, double %r1131, double %r1129408, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.1.relocated409, ptr addrspace(1) %r8.0.relocated410, ptr addrspace(1) %rs4gc.s15.relocated411, ptr addrspace(1) %rs4gc.s13.relocated412, ptr addrspace(1) %rs4gc.s9.relocated413, ptr addrspace(1) %rs4gc.s18.relocated414) ]
  %r1320417 = call double @llvm.experimental.gc.result.f64(token %statepoint_token416)
  %r497.1.relocated418 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 0, i32 0) ; (%r497.1.relocated409, %r497.1.relocated409)
  %r8.0.relocated419 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 1, i32 1) ; (%r8.0.relocated410, %r8.0.relocated410)
  %rs4gc.s15.relocated420 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 2, i32 2) ; (%rs4gc.s15.relocated411, %rs4gc.s15.relocated411)
  %rs4gc.s13.relocated421 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 3, i32 3) ; (%rs4gc.s13.relocated412, %rs4gc.s13.relocated412)
  %rs4gc.s9.relocated422 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 4, i32 4) ; (%rs4gc.s9.relocated413, %rs4gc.s9.relocated413)
  %rs4gc.s18.relocated423 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token416, i32 5, i32 5) ; (%rs4gc.s18.relocated414, %rs4gc.s18.relocated414)
  br label %put.dynic.merge.188

put.dynic.merge.188:                              ; preds = %put.dynic.slow.187, %put.dynic.trans.stamp.186, %put.dynic.store.ref.177, %put.dynic.store.scalar.176
  %.01484 = phi ptr addrspace(1) [ %r497.1.relocated418, %put.dynic.slow.187 ], [ %r497.1.relocated409, %put.dynic.store.scalar.176 ], [ %r497.1.relocated409, %put.dynic.store.ref.177 ], [ %r497.1.relocated409, %put.dynic.trans.stamp.186 ]
  %.91469 = phi ptr addrspace(1) [ %rs4gc.s18.relocated423, %put.dynic.slow.187 ], [ %rs4gc.s18.relocated414, %put.dynic.store.scalar.176 ], [ %rs4gc.s18.relocated414, %put.dynic.store.ref.177 ], [ %rs4gc.s18.relocated414, %put.dynic.trans.stamp.186 ]
  %.101436 = phi ptr addrspace(1) [ %rs4gc.s15.relocated420, %put.dynic.slow.187 ], [ %rs4gc.s15.relocated411, %put.dynic.store.scalar.176 ], [ %rs4gc.s15.relocated411, %put.dynic.store.ref.177 ], [ %rs4gc.s15.relocated411, %put.dynic.trans.stamp.186 ]
  %.131378 = phi ptr addrspace(1) [ %rs4gc.s13.relocated421, %put.dynic.slow.187 ], [ %rs4gc.s13.relocated412, %put.dynic.store.scalar.176 ], [ %rs4gc.s13.relocated412, %put.dynic.store.ref.177 ], [ %rs4gc.s13.relocated412, %put.dynic.trans.stamp.186 ]
  %.101320 = phi ptr addrspace(1) [ %r8.0.relocated419, %put.dynic.slow.187 ], [ %r8.0.relocated410, %put.dynic.store.scalar.176 ], [ %r8.0.relocated410, %put.dynic.store.ref.177 ], [ %r8.0.relocated410, %put.dynic.trans.stamp.186 ]
  %.13 = phi ptr addrspace(1) [ %rs4gc.s9.relocated422, %put.dynic.slow.187 ], [ %rs4gc.s9.relocated413, %put.dynic.store.scalar.176 ], [ %rs4gc.s9.relocated413, %put.dynic.store.ref.177 ], [ %rs4gc.s9.relocated413, %put.dynic.trans.stamp.186 ]
  %r1321 = phi double [ %r1129408, %put.dynic.store.scalar.176 ], [ %r1129408, %put.dynic.store.ref.177 ], [ %r1298, %put.dynic.trans.stamp.186 ], [ %r1320417, %put.dynic.slow.187 ]
  %r1322.rs4i = ptrtoint ptr addrspace(1) %.91469 to i64
  %r1322.rs4o = call i64 asm "", "=r,0"(i64 %r1322.rs4i) #7
  %r1322 = bitcast i64 %r1322.rs4o to double
  %r1323.rs4i = ptrtoint ptr addrspace(1) %.131378 to i64
  %r1323.rs4o = call i64 asm "", "=r,0"(i64 %r1323.rs4i) #7
  %r1323 = bitcast i64 %r1323.rs4o to double
  br label %ternary.then.189

ternary.then.189:                                 ; preds = %put.dynic.merge.188
  br label %ternary.merge.191

ternary.merge.191:                                ; preds = %ternary.then.189
  %statepoint_token424 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1322, double %r1323, double 0.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.101320, ptr addrspace(1) %.101436, ptr addrspace(1) %.131378, ptr addrspace(1) %.13, ptr addrspace(1) %.91469, ptr addrspace(1) %.01484) ]
  %r1338425 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token424)
  %r8.0.relocated426 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 0, i32 0) ; (%.101320, %.101320)
  %rs4gc.s15.relocated427 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 1, i32 1) ; (%.101436, %.101436)
  %rs4gc.s13.relocated428 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 2, i32 2) ; (%.131378, %.131378)
  %rs4gc.s9.relocated429 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 3, i32 3) ; (%.13, %.13)
  %rs4gc.s18.relocated430 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 4, i32 4) ; (%.91469, %.91469)
  %r497.1.relocated431 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token424, i32 5, i32 5) ; (%.01484, %.01484)
  %r1339 = bitcast i64 %r1338425 to double
  %r1340 = bitcast i64 %r1338425 to double
  %r1341.rs4i = ptrtoint ptr addrspace(1) %r497.1.relocated431 to i64
  %r1341.rs4o = call i64 asm "", "=r,0"(i64 %r1341.rs4i) #7
  %r1341 = bitcast i64 %r1341.rs4o to double
  %r1342 = bitcast double %r1341 to i64
  %r1343 = and i64 %r1342, 281474976710655
  %r1344 = sub nsw i64 %r1343, 8
  %r1345 = inttoptr i64 %r1344 to ptr
  %r1346 = load i8, ptr %r1345, align 1
  %r1347 = icmp ne i8 %r1346, 1
  %r1348 = sub nsw i64 %r1343, 7
  %r1349 = inttoptr i64 %r1348 to ptr
  %r1350 = load i8, ptr %r1349, align 1
  %r1351 = and i8 %r1350, -128
  %r1352 = icmp ne i8 %r1351, 0
  %r1353 = or i1 %r1347, %r1352
  br i1 %r1352, label %apush.fwd.192, label %apush.elements.193

apush.fwd.192:                                    ; preds = %apush.elements.check.194, %ternary.merge.191
  %statepoint_token432 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1343, double %r1340, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated430, ptr addrspace(1) %r8.0.relocated426, ptr addrspace(1) %rs4gc.s15.relocated427, ptr addrspace(1) %rs4gc.s13.relocated428, ptr addrspace(1) %rs4gc.s9.relocated429) ]
  %r1380433 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token432)
  %rs4gc.s18.relocated434 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token432, i32 0, i32 0) ; (%rs4gc.s18.relocated430, %rs4gc.s18.relocated430)
  %r8.0.relocated435 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token432, i32 1, i32 1) ; (%r8.0.relocated426, %r8.0.relocated426)
  %rs4gc.s15.relocated436 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token432, i32 2, i32 2) ; (%rs4gc.s15.relocated427, %rs4gc.s15.relocated427)
  %rs4gc.s13.relocated437 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token432, i32 3, i32 3) ; (%rs4gc.s13.relocated428, %rs4gc.s13.relocated428)
  %rs4gc.s9.relocated438 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token432, i32 4, i32 4) ; (%rs4gc.s9.relocated429, %rs4gc.s9.relocated429)
  %r1381 = or i64 %r1380433, 9222527611924643840
  %r1382 = bitcast i64 %r1381 to double
  %rs4gc.b33 = bitcast double %r1382 to i64
  %rs4gc.s33 = inttoptr i64 %rs4gc.b33 to ptr addrspace(1)
  br label %apush.merge.198

apush.elements.193:                               ; preds = %ternary.merge.191
  %r1355 = add nuw nsw i64 %r1343, 8
  %r1356 = inttoptr i64 %r1355 to ptr
  %r1357 = load i64, ptr %r1356, align 8
  %r1358 = icmp ne i64 %r1357, 0
  %r1359 = icmp eq i8 %r1346, 2
  %r1360 = and i1 %r1359, %r1358
  %r1361 = select i1 %r1360, i64 %r1357, i64 %r1343
  %r1362 = inttoptr i64 %r1361 to ptr
  %r1363 = getelementptr i64, ptr %r1362, i64 12
  %r1364 = load i64, ptr %r1363, align 8
  %r1365 = icmp ne i64 %r1364, 0
  %r1366 = and i1 %r1360, %r1365
  %r1367 = select i1 %r1366, i64 %r1364, i64 %r1343
  %r1354 = icmp eq i8 %r1346, 1
  br i1 %r1354, label %apush.nofwd.195, label %apush.elements.check.194

apush.elements.check.194:                         ; preds = %apush.elements.193
  %r1368 = icmp ne i64 %r1367, 0
  %r1369 = sub i64 %r1367, 8
  %r1370 = inttoptr i64 %r1369 to ptr
  %r1371 = load i8, ptr %r1370, align 1
  %r1372 = icmp eq i8 %r1371, 1
  %r1373 = sub i64 %r1367, 7
  %r1374 = inttoptr i64 %r1373 to ptr
  %r1375 = load i8, ptr %r1374, align 1
  %r1376 = and i8 %r1375, -128
  %r1377 = icmp eq i8 %r1376, 0
  %r1378 = and i1 %r1368, %r1372
  %r1379 = and i1 %r1378, %r1377
  br i1 %r1379, label %apush.nofwd.195, label %apush.fwd.192

apush.nofwd.195:                                  ; preds = %apush.elements.check.194, %apush.elements.193
  %r1383 = phi i64 [ %r1343, %apush.elements.193 ], [ %r1367, %apush.elements.check.194 ]
  %r1384 = sub i64 %r1383, 6
  %r1385 = inttoptr i64 %r1384 to ptr
  %r1386 = load i16, ptr %r1385, align 2
  %r1387 = and i16 %r1386, 1031
  %r1388 = icmp eq i16 %r1387, 0
  %r1389 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1390 = icmp eq i8 %r1389, 0
  %r1391 = and i1 %r1388, %r1390
  %r1392 = icmp ult i64 %r1383, 4096
  %r1393 = inttoptr i64 %r1383 to ptr
  %r1394 = select i1 %r1392, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r1393
  %r1395 = load i32, ptr %r1394, align 4
  %r1396 = add i64 %r1383, 4
  %r1397 = inttoptr i64 %r1396 to ptr
  %r1398 = load i32, ptr %r1397, align 4
  %r1399 = icmp ult i32 %r1395, %r1398
  %r1400 = and i1 %r1399, %r1391
  br i1 %r1400, label %apush.inbounds.196, label %apush.realloc.197

apush.inbounds.196:                               ; preds = %apush.nofwd.195
  %r1401 = icmp ult i64 %r1383, 4096
  %r1402 = inttoptr i64 %r1383 to ptr
  %r1403 = select i1 %r1401, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r1402
  %r1404 = load i32, ptr %r1403, align 4
  %r1405 = zext i32 %r1404 to i64
  %r1406 = shl nuw nsw i64 %r1405, 3
  %r1407 = add nuw nsw i64 %r1406, 8
  %r1408 = add i64 %r1383, %r1407
  %r1409 = inttoptr i64 %r1408 to ptr
  store double %r1340, ptr %r1409, align 8
  %r1410 = lshr i64 %r1338425, 48
  %r1411 = icmp eq i64 %r1410, 32765
  %r1412 = and i16 %r1386, -1920
  %r1413 = icmp eq i16 %r1412, -24576
  %r1414 = and i1 %r1411, %r1413
  br i1 %r1414, label %apush.pointer_layout.done.200, label %apush.pointer_layout.bookkeeping.199

apush.realloc.197:                                ; preds = %apush.nofwd.195
  %statepoint_token439 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1343, double %r1340, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated430, ptr addrspace(1) %r8.0.relocated426, ptr addrspace(1) %rs4gc.s15.relocated427, ptr addrspace(1) %rs4gc.s13.relocated428, ptr addrspace(1) %rs4gc.s9.relocated429) ]
  %r1425440 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token439)
  %rs4gc.s18.relocated441 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token439, i32 0, i32 0) ; (%rs4gc.s18.relocated430, %rs4gc.s18.relocated430)
  %r8.0.relocated442 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token439, i32 1, i32 1) ; (%r8.0.relocated426, %r8.0.relocated426)
  %rs4gc.s15.relocated443 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token439, i32 2, i32 2) ; (%rs4gc.s15.relocated427, %rs4gc.s15.relocated427)
  %rs4gc.s13.relocated444 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token439, i32 3, i32 3) ; (%rs4gc.s13.relocated428, %rs4gc.s13.relocated428)
  %rs4gc.s9.relocated445 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token439, i32 4, i32 4) ; (%rs4gc.s9.relocated429, %rs4gc.s9.relocated429)
  %r1426 = or i64 %r1425440, 9222527611924643840
  %r1427 = bitcast i64 %r1426 to double
  %rs4gc.b34 = bitcast double %r1427 to i64
  %rs4gc.s34 = inttoptr i64 %rs4gc.b34 to ptr addrspace(1)
  br label %apush.merge.198

apush.merge.198:                                  ; preds = %apush.barrier.done.202, %apush.realloc.197, %apush.fwd.192
  %.101470 = phi ptr addrspace(1) [ %rs4gc.s18.relocated434, %apush.fwd.192 ], [ %rs4gc.s18.relocated430, %apush.barrier.done.202 ], [ %rs4gc.s18.relocated441, %apush.realloc.197 ]
  %.111437 = phi ptr addrspace(1) [ %rs4gc.s15.relocated436, %apush.fwd.192 ], [ %rs4gc.s15.relocated427, %apush.barrier.done.202 ], [ %rs4gc.s15.relocated443, %apush.realloc.197 ]
  %.141379 = phi ptr addrspace(1) [ %rs4gc.s13.relocated437, %apush.fwd.192 ], [ %rs4gc.s13.relocated428, %apush.barrier.done.202 ], [ %rs4gc.s13.relocated444, %apush.realloc.197 ]
  %.111321 = phi ptr addrspace(1) [ %r8.0.relocated435, %apush.fwd.192 ], [ %r8.0.relocated426, %apush.barrier.done.202 ], [ %r8.0.relocated442, %apush.realloc.197 ]
  %.14 = phi ptr addrspace(1) [ %rs4gc.s9.relocated438, %apush.fwd.192 ], [ %rs4gc.s9.relocated429, %apush.barrier.done.202 ], [ %rs4gc.s9.relocated445, %apush.realloc.197 ]
  %r497.2 = phi ptr addrspace(1) [ %rs4gc.s33, %apush.fwd.192 ], [ %r497.1.relocated431, %apush.barrier.done.202 ], [ %rs4gc.s34, %apush.realloc.197 ]
  %r1428.rs4i = ptrtoint ptr addrspace(1) %.111437 to i64
  %r1428.rs4o = call i64 asm "", "=r,0"(i64 %r1428.rs4i) #7
  %r1428 = bitcast i64 %r1428.rs4o to double
  %r1429 = bitcast double %r1428 to i64
  %rs4gc.s35 = inttoptr i64 %r1429 to ptr addrspace(1)
  %r1430.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r1430 = call i64 asm "", "=r,0"(i64 %r1430.rs4i) #7
  %r1431 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1432 = icmp ne i32 %r1431, 0
  br i1 %r1432, label %shadow.root.barrier.203, label %shadow.root.barrier.done.204

apush.pointer_layout.bookkeeping.199:             ; preds = %apush.inbounds.196
  call void @js_string_addref_if_heap_string(double %r1340) #7
  call void @js_gc_note_slot_layout(i64 %r1383, i32 %r1404, i64 %r1338425) #7
  call void @js_array_note_numeric_write(i64 %r1383, i64 %r1338425) #7
  br label %apush.pointer_layout.done.200

apush.pointer_layout.done.200:                    ; preds = %apush.pointer_layout.bookkeeping.199, %apush.inbounds.196
  %r1415 = sub i64 %r1383, 7
  %r1416 = inttoptr i64 %r1415 to ptr
  %r1417 = load i8, ptr %r1416, align 1
  %r1418 = and i8 %r1417, 32
  %r1419 = icmp ne i8 %r1418, 0
  %r1420 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1421 = icmp ne i32 %r1420, 0
  %r1422 = or i1 %r1419, %r1421
  br i1 %r1422, label %apush.barrier.201, label %apush.barrier.done.202

apush.barrier.201:                                ; preds = %apush.pointer_layout.done.200
  call void @js_write_barrier_slot_validated_parent(i64 %r1383, i64 %r1408, i64 %r1338425) #7
  br label %apush.barrier.done.202

apush.barrier.done.202:                           ; preds = %apush.barrier.201, %apush.pointer_layout.done.200
  %r1423 = add i32 %r1404, 1
  %r1424 = inttoptr i64 %r1383 to ptr
  store i32 %r1423, ptr %r1424, align 4
  br label %apush.merge.198

shadow.root.barrier.203:                          ; preds = %apush.merge.198
  call void @js_write_barrier_root_nanbox(i64 %r1430) #7
  br label %shadow.root.barrier.done.204

shadow.root.barrier.done.204:                     ; preds = %shadow.root.barrier.203, %apush.merge.198
  %r1433.rs4i = ptrtoint ptr addrspace(1) %.111321 to i64
  %r1433.rs4o = call i64 asm "", "=r,0"(i64 %r1433.rs4i) #7
  %r1433 = bitcast i64 %r1433.rs4o to double
  %r1434 = load double, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  %statepoint_token446 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r1433, double %r1434, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.2, ptr addrspace(1) %.111321, ptr addrspace(1) %.111437, ptr addrspace(1) %.141379, ptr addrspace(1) %.14, ptr addrspace(1) %.101470, ptr addrspace(1) %rs4gc.s35) ]
  %r1435447 = call double @llvm.experimental.gc.result.f64(token %statepoint_token446)
  %r497.2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 0, i32 0) ; (%r497.2, %r497.2)
  %r8.0.relocated448 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 1, i32 1) ; (%.111321, %.111321)
  %rs4gc.s15.relocated449 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 2, i32 2) ; (%.111437, %.111437)
  %rs4gc.s13.relocated450 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 3, i32 3) ; (%.141379, %.141379)
  %rs4gc.s9.relocated451 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 4, i32 4) ; (%.14, %.14)
  %rs4gc.s18.relocated452 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 5, i32 5) ; (%.101470, %.101470)
  %rs4gc.s35.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 6, i32 6) ; (%rs4gc.s35, %rs4gc.s35)
  %statepoint_token453 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r1435447, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.2.relocated, ptr addrspace(1) %r8.0.relocated448, ptr addrspace(1) %rs4gc.s15.relocated449, ptr addrspace(1) %rs4gc.s13.relocated450, ptr addrspace(1) %rs4gc.s9.relocated451, ptr addrspace(1) %rs4gc.s18.relocated452, ptr addrspace(1) %rs4gc.s35.relocated) ]
  %r1436454 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token453)
  %r497.2.relocated455 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token453, i32 0, i32 0) ; (%r497.2.relocated, %r497.2.relocated)
  %r8.0.relocated456 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token453, i32 1, i32 1) ; (%r8.0.relocated448, %r8.0.relocated448)
  %rs4gc.s15.relocated457 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token453, i32 2, i32 2) ; (%rs4gc.s15.relocated449, %rs4gc.s15.relocated449)
  %rs4gc.s13.relocated458 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token453, i32 3, i32 3) ; (%rs4gc.s13.relocated450, %rs4gc.s13.relocated450)
  %rs4gc.s9.relocated459 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token453, i32 4, i32 4) ; (%rs4gc.s9.relocated451, %rs4gc.s9.relocated451)
  %rs4gc.s18.relocated460 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token453, i32 5, i32 5) ; (%rs4gc.s18.relocated452, %rs4gc.s18.relocated452)
  %rs4gc.s35.relocated461 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token453, i32 6, i32 6) ; (%rs4gc.s35.relocated, %rs4gc.s35.relocated)
  %statepoint_token462 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r1436454, double 3.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.2.relocated455, ptr addrspace(1) %r8.0.relocated456, ptr addrspace(1) %rs4gc.s15.relocated457, ptr addrspace(1) %rs4gc.s13.relocated458, ptr addrspace(1) %rs4gc.s9.relocated459, ptr addrspace(1) %rs4gc.s18.relocated460, ptr addrspace(1) %rs4gc.s35.relocated461) ]
  %r1437463 = call double @llvm.experimental.gc.result.f64(token %statepoint_token462)
  %r497.2.relocated464 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token462, i32 0, i32 0) ; (%r497.2.relocated455, %r497.2.relocated455)
  %r8.0.relocated465 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token462, i32 1, i32 1) ; (%r8.0.relocated456, %r8.0.relocated456)
  %rs4gc.s15.relocated466 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token462, i32 2, i32 2) ; (%rs4gc.s15.relocated457, %rs4gc.s15.relocated457)
  %rs4gc.s13.relocated467 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token462, i32 3, i32 3) ; (%rs4gc.s13.relocated458, %rs4gc.s13.relocated458)
  %rs4gc.s9.relocated468 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token462, i32 4, i32 4) ; (%rs4gc.s9.relocated459, %rs4gc.s9.relocated459)
  %rs4gc.s18.relocated469 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token462, i32 5, i32 5) ; (%rs4gc.s18.relocated460, %rs4gc.s18.relocated460)
  %rs4gc.s35.relocated470 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token462, i32 6, i32 6) ; (%rs4gc.s35.relocated461, %rs4gc.s35.relocated461)
  %r1438.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated470 to i64
  %r1438 = call i64 asm "", "=r,0"(i64 %r1438.rs4i) #7
  %r1439 = bitcast i64 %r1438 to double
  %r1440.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated469 to i64
  %r1440.rs4o = call i64 asm "", "=r,0"(i64 %r1440.rs4i) #7
  %r1440 = bitcast i64 %r1440.rs4o to double
  %r1441 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__5, align 8
  %r1442 = icmp ne ptr %r1441, null
  %r1443 = select i1 %r1442, ptr %r1441, ptr @perry_ic_test_json_large_string_emitters_ts__5
  %r1444 = bitcast double %r1437463 to i64
  %r1445 = bitcast double %r1440 to i64
  %r1446 = and i64 %r1445, 281474976710655
  %r1447 = lshr i64 %r1445, 48
  %r1448 = icmp eq i64 %r1447, 32765
  %r1449 = icmp ugt i64 %r1446, 1048575
  %r1450 = lshr i64 %r1444, 48
  %r1451 = icmp ne i64 %r1450, 32765
  %r1452 = icmp ne i64 %r1450, 32767
  %r1453 = icmp ne i64 %r1450, 32762
  %r1454 = and i1 %r1451, %r1452
  %r1455 = and i1 %r1454, %r1453
  %r1456 = icmp ne i64 %r1438, 0
  %r1457 = and i1 %r1448, %r1449
  %r1458 = and i1 %r1457, %r1456
  br i1 %r1458, label %put.dynic.guard.205, label %put.dynic.slow.223

put.dynic.guard.205:                              ; preds = %shadow.root.barrier.done.204
  %r1459 = sub nuw nsw i64 %r1446, 8
  %r1460 = inttoptr i64 %r1459 to ptr
  %r1461 = load i8, ptr %r1460, align 1
  %r1462 = icmp eq i8 %r1461, 2
  %r1463 = sub nuw nsw i64 %r1446, 7
  %r1464 = inttoptr i64 %r1463 to ptr
  %r1465 = load i8, ptr %r1464, align 1
  %r1466 = and i8 %r1465, -128
  %r1467 = icmp eq i8 %r1466, 0
  %r1468 = sub nuw nsw i64 %r1446, 6
  %r1469 = inttoptr i64 %r1468 to ptr
  %r1470 = load i16, ptr %r1469, align 2
  %r1471 = and i16 %r1470, 6535
  %r1472 = icmp eq i16 %r1471, 0
  %r1473 = add nuw nsw i64 %r1446, 0
  %r1474 = inttoptr i64 %r1473 to ptr
  %r1475 = load i32, ptr %r1474, align 4
  %r1476 = icmp ne i32 %r1475, 0
  %r1477 = icmp ne i32 %r1475, -2
  %r1478 = and i16 %r1470, 512
  %r1479 = icmp ne i16 %r1478, 0
  %r1480 = or i1 %r1476, %r1479
  %r1481 = add nuw nsw i64 %r1446, 4
  %r1482 = inttoptr i64 %r1481 to ptr
  %r1483 = load i32, ptr %r1482, align 4
  %r1484 = add i32 %r1483, -2147483648
  %r1485 = icmp ult i32 %r1484, 1073741824
  %r1486 = zext i32 %r1483 to i64
  %r1487 = or i64 %r1486, 4611686018427387904
  %r1488 = select i1 %r1485, i64 %r1487, i64 0
  %r1489 = getelementptr i64, ptr %r1443, i64 0
  %r1490 = load i64, ptr %r1489, align 8
  %r1491 = icmp eq i64 %r1488, %r1490
  %r1492 = icmp ne i64 %r1488, 0
  %r1493 = and i1 %r1462, %r1467
  %r1494 = and i1 %r1493, %r1472
  %r1495 = and i1 %r1494, %r1480
  %r1496 = and i1 %r1495, %r1477
  %r1497 = and i1 %r1491, %r1492
  %r1498 = and i1 %r1496, %r1497
  br i1 %r1498, label %put.dynic.ways.206, label %put.dynic.trans.gate.214

put.dynic.ways.206:                               ; preds = %put.dynic.guard.205
  %r1500 = getelementptr i64, ptr %r1441, i64 1
  %r1501 = load i64, ptr %r1500, align 8
  %r1502 = getelementptr i64, ptr %r1441, i64 2
  %r1503 = load i64, ptr %r1502, align 8
  %r1504 = icmp eq i64 %r1438, %r1501
  br i1 %r1504, label %put.dynic.store.209, label %put.dynic.way1.207

put.dynic.way1.207:                               ; preds = %put.dynic.ways.206
  %r1505 = getelementptr i64, ptr %r1441, i64 3
  %r1506 = load i64, ptr %r1505, align 8
  %r1507 = getelementptr i64, ptr %r1441, i64 4
  %r1508 = load i64, ptr %r1507, align 8
  %r1509 = icmp eq i64 %r1438, %r1506
  br i1 %r1509, label %put.dynic.store.209, label %put.dynic.way2.208

put.dynic.way2.208:                               ; preds = %put.dynic.way1.207
  %r1510 = getelementptr i64, ptr %r1441, i64 5
  %r1511 = load i64, ptr %r1510, align 8
  %r1512 = getelementptr i64, ptr %r1441, i64 6
  %r1513 = load i64, ptr %r1512, align 8
  %r1514 = icmp eq i64 %r1438, %r1511
  br i1 %r1514, label %put.dynic.store.209, label %put.dynic.trans.probe.215

put.dynic.store.209:                              ; preds = %put.dynic.way2.208, %put.dynic.way1.207, %put.dynic.ways.206
  %r1515 = phi i64 [ %r1503, %put.dynic.ways.206 ], [ %r1508, %put.dynic.way1.207 ], [ %r1513, %put.dynic.way2.208 ]
  %r1516 = shl i64 %r1515, 3
  %r1517 = add i64 %r1516, 16
  %r1518 = inttoptr i64 %r1446 to ptr
  %r1519 = getelementptr inbounds i8, ptr %r1518, i64 %r1517
  %r1520 = and i16 %r1470, 1024
  %r1521 = icmp ne i16 %r1520, 0
  br i1 %r1521, label %put.dynic.store.validate.210, label %put.dynic.store.dispatch.211

put.dynic.store.validate.210:                     ; preds = %put.dynic.store.209
  %r1522 = load double, ptr %r1519, align 8
  %r1523 = bitcast double %r1522 to i64
  %r1524 = icmp eq i64 %r1523, 9222246136947933200
  br i1 %r1524, label %put.dynic.slow.223, label %put.dynic.store.dispatch.211

put.dynic.store.dispatch.211:                     ; preds = %put.dynic.store.validate.210, %put.dynic.store.209
  br i1 %r1455, label %put.dynic.store.scalar.212, label %put.dynic.store.ref.213

put.dynic.store.scalar.212:                       ; preds = %put.dynic.store.dispatch.211
  store double %r1437463, ptr %r1519, align 8
  br label %put.dynic.merge.224

put.dynic.store.ref.213:                          ; preds = %put.dynic.store.dispatch.211
  %r1525 = trunc i64 %r1515 to i32
  %r1526 = shl i64 %r1515, 3
  %r1527 = add nuw nsw i64 %r1446, 16
  %r1528 = add i64 %r1527, %r1526
  %r1529 = load double, ptr %r1519, align 8
  %r1530 = bitcast double %r1529 to i64
  store double %r1437463, ptr %r1519, align 8
  call void @js_string_addref_if_heap_string(double %r1437463) #7
  %r1531 = bitcast double %r1437463 to i64
  %r4625.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated469 to i64
  %r4625.rs4o = call i64 asm "", "=r,0"(i64 %r4625.rs4i) #7
  %r4625 = bitcast i64 %r4625.rs4o to double
  %r4626 = bitcast double %r4625 to i64
  %r4627 = and i64 %r4626, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4627, i32 %r1525, i64 %r1531, i64 %r1530) #7
  %r4623.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated469 to i64
  %r4623.rs4o = call i64 asm "", "=r,0"(i64 %r4623.rs4i) #7
  %r4623 = bitcast i64 %r4623.rs4o to double
  %r4624 = bitcast double %r4623 to i64
  call void @js_write_barrier_slot(i64 %r4624, i64 %r1528, i64 %r1531) #7
  br label %put.dynic.merge.224

put.dynic.trans.gate.214:                         ; preds = %put.dynic.guard.205
  %r1499 = and i1 %r1496, %r1492
  br i1 %r1499, label %put.dynic.trans.probe.215, label %put.dynic.slow.223

put.dynic.trans.probe.215:                        ; preds = %put.dynic.trans.gate.214, %put.dynic.way2.208
  %r1532 = lshr i64 %r1438, 48
  %r1533 = icmp eq i64 %r1532, 32767
  %r1534 = and i64 %r1438, 281474976710655
  %r1535 = icmp ugt i64 %r1534, 1048575
  %r1536 = and i16 %r1470, -16384
  %r1537 = icmp eq i16 %r1536, 0
  %r1538 = and i8 %r1465, 32
  %r1539 = icmp eq i8 %r1538, 0
  %r1540 = and i1 %r1533, %r1535
  %r1541 = and i1 %r1540, %r1537
  %r1542 = and i1 %r1541, %r1539
  br i1 %r1542, label %put.dynic.trans.key.216, label %put.dynic.slow.223

put.dynic.trans.key.216:                          ; preds = %put.dynic.trans.probe.215
  %r1543 = and i64 %r1438, 281474976710655
  %r1544 = add nuw nsw i64 %r1543, 4
  %r1545 = inttoptr i64 %r1544 to ptr
  %r1546 = load i32, ptr %r1545, align 4
  %r1547 = icmp uge i32 %r1546, 6
  %r1548 = icmp ule i32 %r1546, 8
  %r1549 = add nuw nsw i64 %r1543, 20
  %r1550 = inttoptr i64 %r1549 to ptr
  %r1551 = load i8, ptr %r1550, align 1
  %r1552 = sub i8 %r1551, 48
  %r1553 = icmp ult i8 %r1552, 10
  %r1554 = icmp eq i1 %r1553, false
  %r1555 = and i1 %r1547, %r1548
  %r1556 = and i1 %r1555, %r1554
  br i1 %r1556, label %put.dynic.trans.entry.217, label %put.dynic.slow.223

put.dynic.trans.entry.217:                        ; preds = %put.dynic.trans.key.216
  %r1557 = add nuw nsw i64 %r1543, 20
  %r1558 = inttoptr i64 %r1557 to ptr
  %r1559 = load i64, ptr %r1558, align 8
  %r1560 = zext nneg i32 %r1546 to i64
  %r1561 = sub nuw nsw i64 8, %r1560
  %r1562 = shl nuw nsw i64 %r1561, 3
  %r1563 = lshr i64 -1, %r1562
  %r1564 = and i64 %r1559, %r1563
  %r1566 = ptrtoint ptr %r92 to i64
  %r1567 = zext i32 %r1483 to i64
  %r1568 = mul i64 %r1567, -7046029254386353131
  %r1569 = lshr i64 %r1564, 3
  %r1570 = mul i64 %r1569, -4126379630918253789
  %r1571 = xor i64 %r1568, %r1570
  %r1572 = and i64 %r1571, 16383
  %r1573 = shl nuw nsw i64 %r1572, 5
  %r1574 = add i64 %r1566, %r1573
  %r1575 = inttoptr i64 %r1574 to ptr
  %r1576 = load i64, ptr %r1575, align 8
  %r1577 = add i64 %r1574, 8
  %r1578 = inttoptr i64 %r1577 to ptr
  %r1579 = load i64, ptr %r1578, align 8
  %r1580 = add i64 %r1574, 16
  %r1581 = inttoptr i64 %r1580 to ptr
  %r1582 = load i32, ptr %r1581, align 4
  %r1583 = add i64 %r1574, 20
  %r1584 = inttoptr i64 %r1583 to ptr
  %r1585 = load i32, ptr %r1584, align 4
  %r1586 = add i64 %r1574, 24
  %r1587 = inttoptr i64 %r1586 to ptr
  %r1588 = load i32, ptr %r1587, align 4
  %r1589 = lshr i32 %r1588, 24
  %r1590 = and i32 %r1588, 16777215
  %r1591 = add i64 %r1574, 28
  %r1592 = inttoptr i64 %r1591 to ptr
  %r1593 = load i32, ptr %r1592, align 4
  %r1594 = icmp eq i64 %r1576, %r1564
  %r1595 = icmp eq i32 %r1589, %r1546
  %r1596 = icmp eq i32 %r1582, %r1483
  %r1597 = icmp ne i64 %r1579, 0
  %r1598 = add nuw nsw i32 %r1590, 1
  %r1599 = icmp eq i32 %r1593, %r1598
  %r1600 = zext nneg i32 %r1590 to i64
  %r1601 = and i64 %r1444, 281474976710655
  %r1602 = icmp eq i64 %r1450, 32765
  %r1603 = icmp eq i64 %r1601, 0
  %r1604 = and i1 %r1602, %r1603
  %r1605 = select i1 %r1604, i64 9222246136947933185, i64 %r1444
  %r1606 = bitcast i64 %r1605 to double
  %r1607 = and i1 %r1594, %r1595
  %r1608 = and i1 %r1607, %r1596
  %r1609 = and i1 %r1608, %r1597
  %r1610 = and i1 %r1609, %r1599
  br i1 %r1610, label %put.dynic.trans.nk.218, label %put.dynic.slow.223

put.dynic.trans.nk.218:                           ; preds = %put.dynic.trans.entry.217
  %r1611 = inttoptr i64 %r1579 to ptr
  %r1612 = load i32, ptr %r1611, align 4
  %r1613 = icmp eq i32 %r1612, %r1598
  br i1 %r1613, label %put.dynic.trans.dispatch.219, label %put.dynic.slow.223

put.dynic.trans.dispatch.219:                     ; preds = %put.dynic.trans.nk.218
  %r1614 = icmp ult i64 %r1600, 2
  br i1 %r1614, label %put.dynic.trans.inline_ref.220, label %put.dynic.trans.ovf.221

put.dynic.trans.inline_ref.220:                   ; preds = %put.dynic.trans.dispatch.219
  %r1615 = shl nuw nsw i64 %r1600, 3
  %r1616 = add nuw nsw i64 %r1615, 16
  %r1617 = add nuw nsw i64 %r1446, %r1616
  %r1618 = inttoptr i64 %r1617 to ptr
  %r1619 = trunc nuw nsw i64 %r1600 to i32
  %r1620 = load double, ptr %r1618, align 8
  %r1621 = bitcast double %r1620 to i64
  store double %r1606, ptr %r1618, align 8
  call void @js_string_addref_if_heap_string(double %r1606) #7
  %r1622 = bitcast double %r1606 to i64
  %r4620.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated469 to i64
  %r4620.rs4o = call i64 asm "", "=r,0"(i64 %r4620.rs4i) #7
  %r4620 = bitcast i64 %r4620.rs4o to double
  %r4621 = bitcast double %r4620 to i64
  %r4622 = and i64 %r4621, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4622, i32 %r1619, i64 %r1622, i64 %r1621) #7
  %r4618.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated469 to i64
  %r4618.rs4o = call i64 asm "", "=r,0"(i64 %r4618.rs4i) #7
  %r4618 = bitcast i64 %r4618.rs4o to double
  %r4619 = bitcast double %r4618 to i64
  call void @js_write_barrier_slot(i64 %r4619, i64 %r1617, i64 %r1622) #7
  br label %put.dynic.trans.stamp.222

put.dynic.trans.ovf.221:                          ; preds = %put.dynic.trans.dispatch.219
  %r1623 = trunc nuw nsw i64 %r1600 to i32
  %r1624 = call i32 @js_transition_ic_spill_append(double %r1440, i64 %r1488, i32 %r1623, double %r1606) #7
  %r1625 = icmp ne i32 %r1624, 0
  br i1 %r1625, label %put.dynic.trans.stamp.222, label %put.dynic.slow.223

put.dynic.trans.stamp.222:                        ; preds = %put.dynic.trans.ovf.221, %put.dynic.trans.inline_ref.220
  %r4615.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated469 to i64
  %r4615.rs4o = call i64 asm "", "=r,0"(i64 %r4615.rs4i) #7
  %r4615 = bitcast i64 %r4615.rs4o to double
  %r4616 = bitcast double %r4615 to i64
  %r4617 = and i64 %r4616, 281474976710655
  %r1626 = add nuw nsw i64 %r4617, 4
  %r1627 = inttoptr i64 %r1626 to ptr
  store i32 %r1585, ptr %r1627, align 4
  br label %put.dynic.merge.224

put.dynic.slow.223:                               ; preds = %put.dynic.trans.ovf.221, %put.dynic.trans.nk.218, %put.dynic.trans.entry.217, %put.dynic.trans.key.216, %put.dynic.trans.probe.215, %put.dynic.trans.gate.214, %put.dynic.store.validate.210, %shadow.root.barrier.done.204
  %statepoint_token471 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_large_string_emitters_ts__5, double %r1440, double %r1439, double %r1437463, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.2.relocated464, ptr addrspace(1) %r8.0.relocated465, ptr addrspace(1) %rs4gc.s15.relocated466, ptr addrspace(1) %rs4gc.s13.relocated467, ptr addrspace(1) %rs4gc.s9.relocated468, ptr addrspace(1) %rs4gc.s18.relocated469) ]
  %r1628472 = call double @llvm.experimental.gc.result.f64(token %statepoint_token471)
  %r497.2.relocated473 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token471, i32 0, i32 0) ; (%r497.2.relocated464, %r497.2.relocated464)
  %r8.0.relocated474 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token471, i32 1, i32 1) ; (%r8.0.relocated465, %r8.0.relocated465)
  %rs4gc.s15.relocated475 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token471, i32 2, i32 2) ; (%rs4gc.s15.relocated466, %rs4gc.s15.relocated466)
  %rs4gc.s13.relocated476 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token471, i32 3, i32 3) ; (%rs4gc.s13.relocated467, %rs4gc.s13.relocated467)
  %rs4gc.s9.relocated477 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token471, i32 4, i32 4) ; (%rs4gc.s9.relocated468, %rs4gc.s9.relocated468)
  %rs4gc.s18.relocated478 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token471, i32 5, i32 5) ; (%rs4gc.s18.relocated469, %rs4gc.s18.relocated469)
  br label %put.dynic.merge.224

put.dynic.merge.224:                              ; preds = %put.dynic.slow.223, %put.dynic.trans.stamp.222, %put.dynic.store.ref.213, %put.dynic.store.scalar.212
  %.01485 = phi ptr addrspace(1) [ %r497.2.relocated473, %put.dynic.slow.223 ], [ %r497.2.relocated464, %put.dynic.store.scalar.212 ], [ %r497.2.relocated464, %put.dynic.store.ref.213 ], [ %r497.2.relocated464, %put.dynic.trans.stamp.222 ]
  %.111471 = phi ptr addrspace(1) [ %rs4gc.s18.relocated478, %put.dynic.slow.223 ], [ %rs4gc.s18.relocated469, %put.dynic.store.scalar.212 ], [ %rs4gc.s18.relocated469, %put.dynic.store.ref.213 ], [ %rs4gc.s18.relocated469, %put.dynic.trans.stamp.222 ]
  %.121438 = phi ptr addrspace(1) [ %rs4gc.s15.relocated475, %put.dynic.slow.223 ], [ %rs4gc.s15.relocated466, %put.dynic.store.scalar.212 ], [ %rs4gc.s15.relocated466, %put.dynic.store.ref.213 ], [ %rs4gc.s15.relocated466, %put.dynic.trans.stamp.222 ]
  %.151380 = phi ptr addrspace(1) [ %rs4gc.s13.relocated476, %put.dynic.slow.223 ], [ %rs4gc.s13.relocated467, %put.dynic.store.scalar.212 ], [ %rs4gc.s13.relocated467, %put.dynic.store.ref.213 ], [ %rs4gc.s13.relocated467, %put.dynic.trans.stamp.222 ]
  %.121322 = phi ptr addrspace(1) [ %r8.0.relocated474, %put.dynic.slow.223 ], [ %r8.0.relocated465, %put.dynic.store.scalar.212 ], [ %r8.0.relocated465, %put.dynic.store.ref.213 ], [ %r8.0.relocated465, %put.dynic.trans.stamp.222 ]
  %.15 = phi ptr addrspace(1) [ %rs4gc.s9.relocated477, %put.dynic.slow.223 ], [ %rs4gc.s9.relocated468, %put.dynic.store.scalar.212 ], [ %rs4gc.s9.relocated468, %put.dynic.store.ref.213 ], [ %rs4gc.s9.relocated468, %put.dynic.trans.stamp.222 ]
  %r1629 = phi double [ %r1437463, %put.dynic.store.scalar.212 ], [ %r1437463, %put.dynic.store.ref.213 ], [ %r1606, %put.dynic.trans.stamp.222 ], [ %r1628472, %put.dynic.slow.223 ]
  %r1630.rs4i = ptrtoint ptr addrspace(1) %.111471 to i64
  %r1630.rs4o = call i64 asm "", "=r,0"(i64 %r1630.rs4i) #7
  %r1630 = bitcast i64 %r1630.rs4o to double
  %r1631.rs4i = ptrtoint ptr addrspace(1) %.151380 to i64
  %r1631.rs4o = call i64 asm "", "=r,0"(i64 %r1631.rs4i) #7
  %r1631 = bitcast i64 %r1631.rs4o to double
  br label %ternary.else.226

ternary.else.226:                                 ; preds = %put.dynic.merge.224
  br label %ternary.merge.227

ternary.merge.227:                                ; preds = %ternary.else.226
  %statepoint_token479 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1630, double %r1631, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.121322, ptr addrspace(1) %.121438, ptr addrspace(1) %.151380, ptr addrspace(1) %.15, ptr addrspace(1) %.111471, ptr addrspace(1) %.01485) ]
  %r1646480 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token479)
  %r8.0.relocated481 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token479, i32 0, i32 0) ; (%.121322, %.121322)
  %rs4gc.s15.relocated482 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token479, i32 1, i32 1) ; (%.121438, %.121438)
  %rs4gc.s13.relocated483 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token479, i32 2, i32 2) ; (%.151380, %.151380)
  %rs4gc.s9.relocated484 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token479, i32 3, i32 3) ; (%.15, %.15)
  %rs4gc.s18.relocated485 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token479, i32 4, i32 4) ; (%.111471, %.111471)
  %r497.2.relocated486 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token479, i32 5, i32 5) ; (%.01485, %.01485)
  %r1647 = bitcast i64 %r1646480 to double
  %r1648 = bitcast i64 %r1646480 to double
  %r1649.rs4i = ptrtoint ptr addrspace(1) %r497.2.relocated486 to i64
  %r1649.rs4o = call i64 asm "", "=r,0"(i64 %r1649.rs4i) #7
  %r1649 = bitcast i64 %r1649.rs4o to double
  %r1650 = bitcast double %r1649 to i64
  %r1651 = and i64 %r1650, 281474976710655
  %r1652 = sub nsw i64 %r1651, 8
  %r1653 = inttoptr i64 %r1652 to ptr
  %r1654 = load i8, ptr %r1653, align 1
  %r1655 = icmp ne i8 %r1654, 1
  %r1656 = sub nsw i64 %r1651, 7
  %r1657 = inttoptr i64 %r1656 to ptr
  %r1658 = load i8, ptr %r1657, align 1
  %r1659 = and i8 %r1658, -128
  %r1660 = icmp ne i8 %r1659, 0
  %r1661 = or i1 %r1655, %r1660
  br i1 %r1660, label %apush.fwd.228, label %apush.elements.229

apush.fwd.228:                                    ; preds = %apush.elements.check.230, %ternary.merge.227
  %statepoint_token487 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1651, double %r1648, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated485, ptr addrspace(1) %r8.0.relocated481, ptr addrspace(1) %rs4gc.s15.relocated482, ptr addrspace(1) %rs4gc.s13.relocated483, ptr addrspace(1) %rs4gc.s9.relocated484) ]
  %r1688488 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token487)
  %rs4gc.s18.relocated489 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token487, i32 0, i32 0) ; (%rs4gc.s18.relocated485, %rs4gc.s18.relocated485)
  %r8.0.relocated490 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token487, i32 1, i32 1) ; (%r8.0.relocated481, %r8.0.relocated481)
  %rs4gc.s15.relocated491 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token487, i32 2, i32 2) ; (%rs4gc.s15.relocated482, %rs4gc.s15.relocated482)
  %rs4gc.s13.relocated492 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token487, i32 3, i32 3) ; (%rs4gc.s13.relocated483, %rs4gc.s13.relocated483)
  %rs4gc.s9.relocated493 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token487, i32 4, i32 4) ; (%rs4gc.s9.relocated484, %rs4gc.s9.relocated484)
  %r1689 = or i64 %r1688488, 9222527611924643840
  %r1690 = bitcast i64 %r1689 to double
  %rs4gc.b36 = bitcast double %r1690 to i64
  %rs4gc.s36 = inttoptr i64 %rs4gc.b36 to ptr addrspace(1)
  br label %apush.merge.234

apush.elements.229:                               ; preds = %ternary.merge.227
  %r1663 = add nuw nsw i64 %r1651, 8
  %r1664 = inttoptr i64 %r1663 to ptr
  %r1665 = load i64, ptr %r1664, align 8
  %r1666 = icmp ne i64 %r1665, 0
  %r1667 = icmp eq i8 %r1654, 2
  %r1668 = and i1 %r1667, %r1666
  %r1669 = select i1 %r1668, i64 %r1665, i64 %r1651
  %r1670 = inttoptr i64 %r1669 to ptr
  %r1671 = getelementptr i64, ptr %r1670, i64 12
  %r1672 = load i64, ptr %r1671, align 8
  %r1673 = icmp ne i64 %r1672, 0
  %r1674 = and i1 %r1668, %r1673
  %r1675 = select i1 %r1674, i64 %r1672, i64 %r1651
  %r1662 = icmp eq i8 %r1654, 1
  br i1 %r1662, label %apush.nofwd.231, label %apush.elements.check.230

apush.elements.check.230:                         ; preds = %apush.elements.229
  %r1676 = icmp ne i64 %r1675, 0
  %r1677 = sub i64 %r1675, 8
  %r1678 = inttoptr i64 %r1677 to ptr
  %r1679 = load i8, ptr %r1678, align 1
  %r1680 = icmp eq i8 %r1679, 1
  %r1681 = sub i64 %r1675, 7
  %r1682 = inttoptr i64 %r1681 to ptr
  %r1683 = load i8, ptr %r1682, align 1
  %r1684 = and i8 %r1683, -128
  %r1685 = icmp eq i8 %r1684, 0
  %r1686 = and i1 %r1676, %r1680
  %r1687 = and i1 %r1686, %r1685
  br i1 %r1687, label %apush.nofwd.231, label %apush.fwd.228

apush.nofwd.231:                                  ; preds = %apush.elements.check.230, %apush.elements.229
  %r1691 = phi i64 [ %r1651, %apush.elements.229 ], [ %r1675, %apush.elements.check.230 ]
  %r1692 = sub i64 %r1691, 6
  %r1693 = inttoptr i64 %r1692 to ptr
  %r1694 = load i16, ptr %r1693, align 2
  %r1695 = and i16 %r1694, 1031
  %r1696 = icmp eq i16 %r1695, 0
  %r1697 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1698 = icmp eq i8 %r1697, 0
  %r1699 = and i1 %r1696, %r1698
  %r1700 = icmp ult i64 %r1691, 4096
  %r1701 = inttoptr i64 %r1691 to ptr
  %r1702 = select i1 %r1700, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r1701
  %r1703 = load i32, ptr %r1702, align 4
  %r1704 = add i64 %r1691, 4
  %r1705 = inttoptr i64 %r1704 to ptr
  %r1706 = load i32, ptr %r1705, align 4
  %r1707 = icmp ult i32 %r1703, %r1706
  %r1708 = and i1 %r1707, %r1699
  br i1 %r1708, label %apush.inbounds.232, label %apush.realloc.233

apush.inbounds.232:                               ; preds = %apush.nofwd.231
  %r1709 = icmp ult i64 %r1691, 4096
  %r1710 = inttoptr i64 %r1691 to ptr
  %r1711 = select i1 %r1709, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r1710
  %r1712 = load i32, ptr %r1711, align 4
  %r1713 = zext i32 %r1712 to i64
  %r1714 = shl nuw nsw i64 %r1713, 3
  %r1715 = add nuw nsw i64 %r1714, 8
  %r1716 = add i64 %r1691, %r1715
  %r1717 = inttoptr i64 %r1716 to ptr
  store double %r1648, ptr %r1717, align 8
  %r1718 = lshr i64 %r1646480, 48
  %r1719 = icmp eq i64 %r1718, 32765
  %r1720 = and i16 %r1694, -1920
  %r1721 = icmp eq i16 %r1720, -24576
  %r1722 = and i1 %r1719, %r1721
  br i1 %r1722, label %apush.pointer_layout.done.236, label %apush.pointer_layout.bookkeeping.235

apush.realloc.233:                                ; preds = %apush.nofwd.231
  %statepoint_token494 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1651, double %r1648, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated485, ptr addrspace(1) %r8.0.relocated481, ptr addrspace(1) %rs4gc.s15.relocated482, ptr addrspace(1) %rs4gc.s13.relocated483, ptr addrspace(1) %rs4gc.s9.relocated484) ]
  %r1733495 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token494)
  %rs4gc.s18.relocated496 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token494, i32 0, i32 0) ; (%rs4gc.s18.relocated485, %rs4gc.s18.relocated485)
  %r8.0.relocated497 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token494, i32 1, i32 1) ; (%r8.0.relocated481, %r8.0.relocated481)
  %rs4gc.s15.relocated498 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token494, i32 2, i32 2) ; (%rs4gc.s15.relocated482, %rs4gc.s15.relocated482)
  %rs4gc.s13.relocated499 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token494, i32 3, i32 3) ; (%rs4gc.s13.relocated483, %rs4gc.s13.relocated483)
  %rs4gc.s9.relocated500 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token494, i32 4, i32 4) ; (%rs4gc.s9.relocated484, %rs4gc.s9.relocated484)
  %r1734 = or i64 %r1733495, 9222527611924643840
  %r1735 = bitcast i64 %r1734 to double
  %rs4gc.b37 = bitcast double %r1735 to i64
  %rs4gc.s37 = inttoptr i64 %rs4gc.b37 to ptr addrspace(1)
  br label %apush.merge.234

apush.merge.234:                                  ; preds = %apush.barrier.done.238, %apush.realloc.233, %apush.fwd.228
  %.121472 = phi ptr addrspace(1) [ %rs4gc.s18.relocated489, %apush.fwd.228 ], [ %rs4gc.s18.relocated485, %apush.barrier.done.238 ], [ %rs4gc.s18.relocated496, %apush.realloc.233 ]
  %.131439 = phi ptr addrspace(1) [ %rs4gc.s15.relocated491, %apush.fwd.228 ], [ %rs4gc.s15.relocated482, %apush.barrier.done.238 ], [ %rs4gc.s15.relocated498, %apush.realloc.233 ]
  %.161381 = phi ptr addrspace(1) [ %rs4gc.s13.relocated492, %apush.fwd.228 ], [ %rs4gc.s13.relocated483, %apush.barrier.done.238 ], [ %rs4gc.s13.relocated499, %apush.realloc.233 ]
  %.131323 = phi ptr addrspace(1) [ %r8.0.relocated490, %apush.fwd.228 ], [ %r8.0.relocated481, %apush.barrier.done.238 ], [ %r8.0.relocated497, %apush.realloc.233 ]
  %.16 = phi ptr addrspace(1) [ %rs4gc.s9.relocated493, %apush.fwd.228 ], [ %rs4gc.s9.relocated484, %apush.barrier.done.238 ], [ %rs4gc.s9.relocated500, %apush.realloc.233 ]
  %r497.3 = phi ptr addrspace(1) [ %rs4gc.s36, %apush.fwd.228 ], [ %r497.2.relocated486, %apush.barrier.done.238 ], [ %rs4gc.s37, %apush.realloc.233 ]
  %r1736.rs4i = ptrtoint ptr addrspace(1) %.131439 to i64
  %r1736.rs4o = call i64 asm "", "=r,0"(i64 %r1736.rs4i) #7
  %r1736 = bitcast i64 %r1736.rs4o to double
  %r1737 = bitcast double %r1736 to i64
  %rs4gc.s38 = inttoptr i64 %r1737 to ptr addrspace(1)
  %r1738.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s38 to i64
  %r1738 = call i64 asm "", "=r,0"(i64 %r1738.rs4i) #7
  %r1739 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1740 = icmp ne i32 %r1739, 0
  br i1 %r1740, label %shadow.root.barrier.239, label %shadow.root.barrier.done.240

apush.pointer_layout.bookkeeping.235:             ; preds = %apush.inbounds.232
  call void @js_string_addref_if_heap_string(double %r1648) #7
  call void @js_gc_note_slot_layout(i64 %r1691, i32 %r1712, i64 %r1646480) #7
  call void @js_array_note_numeric_write(i64 %r1691, i64 %r1646480) #7
  br label %apush.pointer_layout.done.236

apush.pointer_layout.done.236:                    ; preds = %apush.pointer_layout.bookkeeping.235, %apush.inbounds.232
  %r1723 = sub i64 %r1691, 7
  %r1724 = inttoptr i64 %r1723 to ptr
  %r1725 = load i8, ptr %r1724, align 1
  %r1726 = and i8 %r1725, 32
  %r1727 = icmp ne i8 %r1726, 0
  %r1728 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1729 = icmp ne i32 %r1728, 0
  %r1730 = or i1 %r1727, %r1729
  br i1 %r1730, label %apush.barrier.237, label %apush.barrier.done.238

apush.barrier.237:                                ; preds = %apush.pointer_layout.done.236
  call void @js_write_barrier_slot_validated_parent(i64 %r1691, i64 %r1716, i64 %r1646480) #7
  br label %apush.barrier.done.238

apush.barrier.done.238:                           ; preds = %apush.barrier.237, %apush.pointer_layout.done.236
  %r1731 = add i32 %r1712, 1
  %r1732 = inttoptr i64 %r1691 to ptr
  store i32 %r1731, ptr %r1732, align 4
  br label %apush.merge.234

shadow.root.barrier.239:                          ; preds = %apush.merge.234
  call void @js_write_barrier_root_nanbox(i64 %r1738) #7
  br label %shadow.root.barrier.done.240

shadow.root.barrier.done.240:                     ; preds = %shadow.root.barrier.239, %apush.merge.234
  %r1741.rs4i = ptrtoint ptr addrspace(1) %.131323 to i64
  %r1741.rs4o = call i64 asm "", "=r,0"(i64 %r1741.rs4i) #7
  %r1741 = bitcast i64 %r1741.rs4o to double
  %r1742 = load double, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  %statepoint_token501 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r1741, double %r1742, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.3, ptr addrspace(1) %.131323, ptr addrspace(1) %.131439, ptr addrspace(1) %.161381, ptr addrspace(1) %.16, ptr addrspace(1) %.121472, ptr addrspace(1) %rs4gc.s38) ]
  %r1743502 = call double @llvm.experimental.gc.result.f64(token %statepoint_token501)
  %r497.3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token501, i32 0, i32 0) ; (%r497.3, %r497.3)
  %r8.0.relocated503 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token501, i32 1, i32 1) ; (%.131323, %.131323)
  %rs4gc.s15.relocated504 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token501, i32 2, i32 2) ; (%.131439, %.131439)
  %rs4gc.s13.relocated505 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token501, i32 3, i32 3) ; (%.161381, %.161381)
  %rs4gc.s9.relocated506 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token501, i32 4, i32 4) ; (%.16, %.16)
  %rs4gc.s18.relocated507 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token501, i32 5, i32 5) ; (%.121472, %.121472)
  %rs4gc.s38.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token501, i32 6, i32 6) ; (%rs4gc.s38, %rs4gc.s38)
  %statepoint_token508 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r1743502, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.3.relocated, ptr addrspace(1) %r8.0.relocated503, ptr addrspace(1) %rs4gc.s15.relocated504, ptr addrspace(1) %rs4gc.s13.relocated505, ptr addrspace(1) %rs4gc.s9.relocated506, ptr addrspace(1) %rs4gc.s18.relocated507, ptr addrspace(1) %rs4gc.s38.relocated) ]
  %r1744509 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token508)
  %r497.3.relocated510 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token508, i32 0, i32 0) ; (%r497.3.relocated, %r497.3.relocated)
  %r8.0.relocated511 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token508, i32 1, i32 1) ; (%r8.0.relocated503, %r8.0.relocated503)
  %rs4gc.s15.relocated512 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token508, i32 2, i32 2) ; (%rs4gc.s15.relocated504, %rs4gc.s15.relocated504)
  %rs4gc.s13.relocated513 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token508, i32 3, i32 3) ; (%rs4gc.s13.relocated505, %rs4gc.s13.relocated505)
  %rs4gc.s9.relocated514 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token508, i32 4, i32 4) ; (%rs4gc.s9.relocated506, %rs4gc.s9.relocated506)
  %rs4gc.s18.relocated515 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token508, i32 5, i32 5) ; (%rs4gc.s18.relocated507, %rs4gc.s18.relocated507)
  %rs4gc.s38.relocated516 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token508, i32 6, i32 6) ; (%rs4gc.s38.relocated, %rs4gc.s38.relocated)
  %statepoint_token517 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r1744509, double 4.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.3.relocated510, ptr addrspace(1) %r8.0.relocated511, ptr addrspace(1) %rs4gc.s15.relocated512, ptr addrspace(1) %rs4gc.s13.relocated513, ptr addrspace(1) %rs4gc.s9.relocated514, ptr addrspace(1) %rs4gc.s18.relocated515, ptr addrspace(1) %rs4gc.s38.relocated516) ]
  %r1745518 = call double @llvm.experimental.gc.result.f64(token %statepoint_token517)
  %r497.3.relocated519 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token517, i32 0, i32 0) ; (%r497.3.relocated510, %r497.3.relocated510)
  %r8.0.relocated520 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token517, i32 1, i32 1) ; (%r8.0.relocated511, %r8.0.relocated511)
  %rs4gc.s15.relocated521 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token517, i32 2, i32 2) ; (%rs4gc.s15.relocated512, %rs4gc.s15.relocated512)
  %rs4gc.s13.relocated522 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token517, i32 3, i32 3) ; (%rs4gc.s13.relocated513, %rs4gc.s13.relocated513)
  %rs4gc.s9.relocated523 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token517, i32 4, i32 4) ; (%rs4gc.s9.relocated514, %rs4gc.s9.relocated514)
  %rs4gc.s18.relocated524 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token517, i32 5, i32 5) ; (%rs4gc.s18.relocated515, %rs4gc.s18.relocated515)
  %rs4gc.s38.relocated525 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token517, i32 6, i32 6) ; (%rs4gc.s38.relocated516, %rs4gc.s38.relocated516)
  %r1746.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s38.relocated525 to i64
  %r1746 = call i64 asm "", "=r,0"(i64 %r1746.rs4i) #7
  %r1747 = bitcast i64 %r1746 to double
  %r1748.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated524 to i64
  %r1748.rs4o = call i64 asm "", "=r,0"(i64 %r1748.rs4i) #7
  %r1748 = bitcast i64 %r1748.rs4o to double
  %r1749 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__6, align 8
  %r1750 = icmp ne ptr %r1749, null
  %r1751 = select i1 %r1750, ptr %r1749, ptr @perry_ic_test_json_large_string_emitters_ts__6
  %r1752 = bitcast double %r1745518 to i64
  %r1753 = bitcast double %r1748 to i64
  %r1754 = and i64 %r1753, 281474976710655
  %r1755 = lshr i64 %r1753, 48
  %r1756 = icmp eq i64 %r1755, 32765
  %r1757 = icmp ugt i64 %r1754, 1048575
  %r1758 = lshr i64 %r1752, 48
  %r1759 = icmp ne i64 %r1758, 32765
  %r1760 = icmp ne i64 %r1758, 32767
  %r1761 = icmp ne i64 %r1758, 32762
  %r1762 = and i1 %r1759, %r1760
  %r1763 = and i1 %r1762, %r1761
  %r1764 = icmp ne i64 %r1746, 0
  %r1765 = and i1 %r1756, %r1757
  %r1766 = and i1 %r1765, %r1764
  br i1 %r1766, label %put.dynic.guard.241, label %put.dynic.slow.259

put.dynic.guard.241:                              ; preds = %shadow.root.barrier.done.240
  %r1767 = sub nuw nsw i64 %r1754, 8
  %r1768 = inttoptr i64 %r1767 to ptr
  %r1769 = load i8, ptr %r1768, align 1
  %r1770 = icmp eq i8 %r1769, 2
  %r1771 = sub nuw nsw i64 %r1754, 7
  %r1772 = inttoptr i64 %r1771 to ptr
  %r1773 = load i8, ptr %r1772, align 1
  %r1774 = and i8 %r1773, -128
  %r1775 = icmp eq i8 %r1774, 0
  %r1776 = sub nuw nsw i64 %r1754, 6
  %r1777 = inttoptr i64 %r1776 to ptr
  %r1778 = load i16, ptr %r1777, align 2
  %r1779 = and i16 %r1778, 6535
  %r1780 = icmp eq i16 %r1779, 0
  %r1781 = add nuw nsw i64 %r1754, 0
  %r1782 = inttoptr i64 %r1781 to ptr
  %r1783 = load i32, ptr %r1782, align 4
  %r1784 = icmp ne i32 %r1783, 0
  %r1785 = icmp ne i32 %r1783, -2
  %r1786 = and i16 %r1778, 512
  %r1787 = icmp ne i16 %r1786, 0
  %r1788 = or i1 %r1784, %r1787
  %r1789 = add nuw nsw i64 %r1754, 4
  %r1790 = inttoptr i64 %r1789 to ptr
  %r1791 = load i32, ptr %r1790, align 4
  %r1792 = add i32 %r1791, -2147483648
  %r1793 = icmp ult i32 %r1792, 1073741824
  %r1794 = zext i32 %r1791 to i64
  %r1795 = or i64 %r1794, 4611686018427387904
  %r1796 = select i1 %r1793, i64 %r1795, i64 0
  %r1797 = getelementptr i64, ptr %r1751, i64 0
  %r1798 = load i64, ptr %r1797, align 8
  %r1799 = icmp eq i64 %r1796, %r1798
  %r1800 = icmp ne i64 %r1796, 0
  %r1801 = and i1 %r1770, %r1775
  %r1802 = and i1 %r1801, %r1780
  %r1803 = and i1 %r1802, %r1788
  %r1804 = and i1 %r1803, %r1785
  %r1805 = and i1 %r1799, %r1800
  %r1806 = and i1 %r1804, %r1805
  br i1 %r1806, label %put.dynic.ways.242, label %put.dynic.trans.gate.250

put.dynic.ways.242:                               ; preds = %put.dynic.guard.241
  %r1808 = getelementptr i64, ptr %r1749, i64 1
  %r1809 = load i64, ptr %r1808, align 8
  %r1810 = getelementptr i64, ptr %r1749, i64 2
  %r1811 = load i64, ptr %r1810, align 8
  %r1812 = icmp eq i64 %r1746, %r1809
  br i1 %r1812, label %put.dynic.store.245, label %put.dynic.way1.243

put.dynic.way1.243:                               ; preds = %put.dynic.ways.242
  %r1813 = getelementptr i64, ptr %r1749, i64 3
  %r1814 = load i64, ptr %r1813, align 8
  %r1815 = getelementptr i64, ptr %r1749, i64 4
  %r1816 = load i64, ptr %r1815, align 8
  %r1817 = icmp eq i64 %r1746, %r1814
  br i1 %r1817, label %put.dynic.store.245, label %put.dynic.way2.244

put.dynic.way2.244:                               ; preds = %put.dynic.way1.243
  %r1818 = getelementptr i64, ptr %r1749, i64 5
  %r1819 = load i64, ptr %r1818, align 8
  %r1820 = getelementptr i64, ptr %r1749, i64 6
  %r1821 = load i64, ptr %r1820, align 8
  %r1822 = icmp eq i64 %r1746, %r1819
  br i1 %r1822, label %put.dynic.store.245, label %put.dynic.trans.probe.251

put.dynic.store.245:                              ; preds = %put.dynic.way2.244, %put.dynic.way1.243, %put.dynic.ways.242
  %r1823 = phi i64 [ %r1811, %put.dynic.ways.242 ], [ %r1816, %put.dynic.way1.243 ], [ %r1821, %put.dynic.way2.244 ]
  %r1824 = shl i64 %r1823, 3
  %r1825 = add i64 %r1824, 16
  %r1826 = inttoptr i64 %r1754 to ptr
  %r1827 = getelementptr inbounds i8, ptr %r1826, i64 %r1825
  %r1828 = and i16 %r1778, 1024
  %r1829 = icmp ne i16 %r1828, 0
  br i1 %r1829, label %put.dynic.store.validate.246, label %put.dynic.store.dispatch.247

put.dynic.store.validate.246:                     ; preds = %put.dynic.store.245
  %r1830 = load double, ptr %r1827, align 8
  %r1831 = bitcast double %r1830 to i64
  %r1832 = icmp eq i64 %r1831, 9222246136947933200
  br i1 %r1832, label %put.dynic.slow.259, label %put.dynic.store.dispatch.247

put.dynic.store.dispatch.247:                     ; preds = %put.dynic.store.validate.246, %put.dynic.store.245
  br i1 %r1763, label %put.dynic.store.scalar.248, label %put.dynic.store.ref.249

put.dynic.store.scalar.248:                       ; preds = %put.dynic.store.dispatch.247
  store double %r1745518, ptr %r1827, align 8
  br label %put.dynic.merge.260

put.dynic.store.ref.249:                          ; preds = %put.dynic.store.dispatch.247
  %r1833 = trunc i64 %r1823 to i32
  %r1834 = shl i64 %r1823, 3
  %r1835 = add nuw nsw i64 %r1754, 16
  %r1836 = add i64 %r1835, %r1834
  %r1837 = load double, ptr %r1827, align 8
  %r1838 = bitcast double %r1837 to i64
  store double %r1745518, ptr %r1827, align 8
  call void @js_string_addref_if_heap_string(double %r1745518) #7
  %r1839 = bitcast double %r1745518 to i64
  %r4612.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated524 to i64
  %r4612.rs4o = call i64 asm "", "=r,0"(i64 %r4612.rs4i) #7
  %r4612 = bitcast i64 %r4612.rs4o to double
  %r4613 = bitcast double %r4612 to i64
  %r4614 = and i64 %r4613, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4614, i32 %r1833, i64 %r1839, i64 %r1838) #7
  %r4610.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated524 to i64
  %r4610.rs4o = call i64 asm "", "=r,0"(i64 %r4610.rs4i) #7
  %r4610 = bitcast i64 %r4610.rs4o to double
  %r4611 = bitcast double %r4610 to i64
  call void @js_write_barrier_slot(i64 %r4611, i64 %r1836, i64 %r1839) #7
  br label %put.dynic.merge.260

put.dynic.trans.gate.250:                         ; preds = %put.dynic.guard.241
  %r1807 = and i1 %r1804, %r1800
  br i1 %r1807, label %put.dynic.trans.probe.251, label %put.dynic.slow.259

put.dynic.trans.probe.251:                        ; preds = %put.dynic.trans.gate.250, %put.dynic.way2.244
  %r1840 = lshr i64 %r1746, 48
  %r1841 = icmp eq i64 %r1840, 32767
  %r1842 = and i64 %r1746, 281474976710655
  %r1843 = icmp ugt i64 %r1842, 1048575
  %r1844 = and i16 %r1778, -16384
  %r1845 = icmp eq i16 %r1844, 0
  %r1846 = and i8 %r1773, 32
  %r1847 = icmp eq i8 %r1846, 0
  %r1848 = and i1 %r1841, %r1843
  %r1849 = and i1 %r1848, %r1845
  %r1850 = and i1 %r1849, %r1847
  br i1 %r1850, label %put.dynic.trans.key.252, label %put.dynic.slow.259

put.dynic.trans.key.252:                          ; preds = %put.dynic.trans.probe.251
  %r1851 = and i64 %r1746, 281474976710655
  %r1852 = add nuw nsw i64 %r1851, 4
  %r1853 = inttoptr i64 %r1852 to ptr
  %r1854 = load i32, ptr %r1853, align 4
  %r1855 = icmp uge i32 %r1854, 6
  %r1856 = icmp ule i32 %r1854, 8
  %r1857 = add nuw nsw i64 %r1851, 20
  %r1858 = inttoptr i64 %r1857 to ptr
  %r1859 = load i8, ptr %r1858, align 1
  %r1860 = sub i8 %r1859, 48
  %r1861 = icmp ult i8 %r1860, 10
  %r1862 = icmp eq i1 %r1861, false
  %r1863 = and i1 %r1855, %r1856
  %r1864 = and i1 %r1863, %r1862
  br i1 %r1864, label %put.dynic.trans.entry.253, label %put.dynic.slow.259

put.dynic.trans.entry.253:                        ; preds = %put.dynic.trans.key.252
  %r1865 = add nuw nsw i64 %r1851, 20
  %r1866 = inttoptr i64 %r1865 to ptr
  %r1867 = load i64, ptr %r1866, align 8
  %r1868 = zext nneg i32 %r1854 to i64
  %r1869 = sub nuw nsw i64 8, %r1868
  %r1870 = shl nuw nsw i64 %r1869, 3
  %r1871 = lshr i64 -1, %r1870
  %r1872 = and i64 %r1867, %r1871
  %r1874 = ptrtoint ptr %r92 to i64
  %r1875 = zext i32 %r1791 to i64
  %r1876 = mul i64 %r1875, -7046029254386353131
  %r1877 = lshr i64 %r1872, 3
  %r1878 = mul i64 %r1877, -4126379630918253789
  %r1879 = xor i64 %r1876, %r1878
  %r1880 = and i64 %r1879, 16383
  %r1881 = shl nuw nsw i64 %r1880, 5
  %r1882 = add i64 %r1874, %r1881
  %r1883 = inttoptr i64 %r1882 to ptr
  %r1884 = load i64, ptr %r1883, align 8
  %r1885 = add i64 %r1882, 8
  %r1886 = inttoptr i64 %r1885 to ptr
  %r1887 = load i64, ptr %r1886, align 8
  %r1888 = add i64 %r1882, 16
  %r1889 = inttoptr i64 %r1888 to ptr
  %r1890 = load i32, ptr %r1889, align 4
  %r1891 = add i64 %r1882, 20
  %r1892 = inttoptr i64 %r1891 to ptr
  %r1893 = load i32, ptr %r1892, align 4
  %r1894 = add i64 %r1882, 24
  %r1895 = inttoptr i64 %r1894 to ptr
  %r1896 = load i32, ptr %r1895, align 4
  %r1897 = lshr i32 %r1896, 24
  %r1898 = and i32 %r1896, 16777215
  %r1899 = add i64 %r1882, 28
  %r1900 = inttoptr i64 %r1899 to ptr
  %r1901 = load i32, ptr %r1900, align 4
  %r1902 = icmp eq i64 %r1884, %r1872
  %r1903 = icmp eq i32 %r1897, %r1854
  %r1904 = icmp eq i32 %r1890, %r1791
  %r1905 = icmp ne i64 %r1887, 0
  %r1906 = add nuw nsw i32 %r1898, 1
  %r1907 = icmp eq i32 %r1901, %r1906
  %r1908 = zext nneg i32 %r1898 to i64
  %r1909 = and i64 %r1752, 281474976710655
  %r1910 = icmp eq i64 %r1758, 32765
  %r1911 = icmp eq i64 %r1909, 0
  %r1912 = and i1 %r1910, %r1911
  %r1913 = select i1 %r1912, i64 9222246136947933185, i64 %r1752
  %r1914 = bitcast i64 %r1913 to double
  %r1915 = and i1 %r1902, %r1903
  %r1916 = and i1 %r1915, %r1904
  %r1917 = and i1 %r1916, %r1905
  %r1918 = and i1 %r1917, %r1907
  br i1 %r1918, label %put.dynic.trans.nk.254, label %put.dynic.slow.259

put.dynic.trans.nk.254:                           ; preds = %put.dynic.trans.entry.253
  %r1919 = inttoptr i64 %r1887 to ptr
  %r1920 = load i32, ptr %r1919, align 4
  %r1921 = icmp eq i32 %r1920, %r1906
  br i1 %r1921, label %put.dynic.trans.dispatch.255, label %put.dynic.slow.259

put.dynic.trans.dispatch.255:                     ; preds = %put.dynic.trans.nk.254
  %r1922 = icmp ult i64 %r1908, 2
  br i1 %r1922, label %put.dynic.trans.inline_ref.256, label %put.dynic.trans.ovf.257

put.dynic.trans.inline_ref.256:                   ; preds = %put.dynic.trans.dispatch.255
  %r1923 = shl nuw nsw i64 %r1908, 3
  %r1924 = add nuw nsw i64 %r1923, 16
  %r1925 = add nuw nsw i64 %r1754, %r1924
  %r1926 = inttoptr i64 %r1925 to ptr
  %r1927 = trunc nuw nsw i64 %r1908 to i32
  %r1928 = load double, ptr %r1926, align 8
  %r1929 = bitcast double %r1928 to i64
  store double %r1914, ptr %r1926, align 8
  call void @js_string_addref_if_heap_string(double %r1914) #7
  %r1930 = bitcast double %r1914 to i64
  %r4607.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated524 to i64
  %r4607.rs4o = call i64 asm "", "=r,0"(i64 %r4607.rs4i) #7
  %r4607 = bitcast i64 %r4607.rs4o to double
  %r4608 = bitcast double %r4607 to i64
  %r4609 = and i64 %r4608, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4609, i32 %r1927, i64 %r1930, i64 %r1929) #7
  %r4605.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated524 to i64
  %r4605.rs4o = call i64 asm "", "=r,0"(i64 %r4605.rs4i) #7
  %r4605 = bitcast i64 %r4605.rs4o to double
  %r4606 = bitcast double %r4605 to i64
  call void @js_write_barrier_slot(i64 %r4606, i64 %r1925, i64 %r1930) #7
  br label %put.dynic.trans.stamp.258

put.dynic.trans.ovf.257:                          ; preds = %put.dynic.trans.dispatch.255
  %r1931 = trunc nuw nsw i64 %r1908 to i32
  %r1932 = call i32 @js_transition_ic_spill_append(double %r1748, i64 %r1796, i32 %r1931, double %r1914) #7
  %r1933 = icmp ne i32 %r1932, 0
  br i1 %r1933, label %put.dynic.trans.stamp.258, label %put.dynic.slow.259

put.dynic.trans.stamp.258:                        ; preds = %put.dynic.trans.ovf.257, %put.dynic.trans.inline_ref.256
  %r4602.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated524 to i64
  %r4602.rs4o = call i64 asm "", "=r,0"(i64 %r4602.rs4i) #7
  %r4602 = bitcast i64 %r4602.rs4o to double
  %r4603 = bitcast double %r4602 to i64
  %r4604 = and i64 %r4603, 281474976710655
  %r1934 = add nuw nsw i64 %r4604, 4
  %r1935 = inttoptr i64 %r1934 to ptr
  store i32 %r1893, ptr %r1935, align 4
  br label %put.dynic.merge.260

put.dynic.slow.259:                               ; preds = %put.dynic.trans.ovf.257, %put.dynic.trans.nk.254, %put.dynic.trans.entry.253, %put.dynic.trans.key.252, %put.dynic.trans.probe.251, %put.dynic.trans.gate.250, %put.dynic.store.validate.246, %shadow.root.barrier.done.240
  %statepoint_token526 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_large_string_emitters_ts__6, double %r1748, double %r1747, double %r1745518, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.3.relocated519, ptr addrspace(1) %r8.0.relocated520, ptr addrspace(1) %rs4gc.s15.relocated521, ptr addrspace(1) %rs4gc.s13.relocated522, ptr addrspace(1) %rs4gc.s9.relocated523, ptr addrspace(1) %rs4gc.s18.relocated524) ]
  %r1936527 = call double @llvm.experimental.gc.result.f64(token %statepoint_token526)
  %r497.3.relocated528 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token526, i32 0, i32 0) ; (%r497.3.relocated519, %r497.3.relocated519)
  %r8.0.relocated529 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token526, i32 1, i32 1) ; (%r8.0.relocated520, %r8.0.relocated520)
  %rs4gc.s15.relocated530 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token526, i32 2, i32 2) ; (%rs4gc.s15.relocated521, %rs4gc.s15.relocated521)
  %rs4gc.s13.relocated531 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token526, i32 3, i32 3) ; (%rs4gc.s13.relocated522, %rs4gc.s13.relocated522)
  %rs4gc.s9.relocated532 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token526, i32 4, i32 4) ; (%rs4gc.s9.relocated523, %rs4gc.s9.relocated523)
  %rs4gc.s18.relocated533 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token526, i32 5, i32 5) ; (%rs4gc.s18.relocated524, %rs4gc.s18.relocated524)
  br label %put.dynic.merge.260

put.dynic.merge.260:                              ; preds = %put.dynic.slow.259, %put.dynic.trans.stamp.258, %put.dynic.store.ref.249, %put.dynic.store.scalar.248
  %.01486 = phi ptr addrspace(1) [ %r497.3.relocated528, %put.dynic.slow.259 ], [ %r497.3.relocated519, %put.dynic.store.scalar.248 ], [ %r497.3.relocated519, %put.dynic.store.ref.249 ], [ %r497.3.relocated519, %put.dynic.trans.stamp.258 ]
  %.131473 = phi ptr addrspace(1) [ %rs4gc.s18.relocated533, %put.dynic.slow.259 ], [ %rs4gc.s18.relocated524, %put.dynic.store.scalar.248 ], [ %rs4gc.s18.relocated524, %put.dynic.store.ref.249 ], [ %rs4gc.s18.relocated524, %put.dynic.trans.stamp.258 ]
  %.141440 = phi ptr addrspace(1) [ %rs4gc.s15.relocated530, %put.dynic.slow.259 ], [ %rs4gc.s15.relocated521, %put.dynic.store.scalar.248 ], [ %rs4gc.s15.relocated521, %put.dynic.store.ref.249 ], [ %rs4gc.s15.relocated521, %put.dynic.trans.stamp.258 ]
  %.171382 = phi ptr addrspace(1) [ %rs4gc.s13.relocated531, %put.dynic.slow.259 ], [ %rs4gc.s13.relocated522, %put.dynic.store.scalar.248 ], [ %rs4gc.s13.relocated522, %put.dynic.store.ref.249 ], [ %rs4gc.s13.relocated522, %put.dynic.trans.stamp.258 ]
  %.141324 = phi ptr addrspace(1) [ %r8.0.relocated529, %put.dynic.slow.259 ], [ %r8.0.relocated520, %put.dynic.store.scalar.248 ], [ %r8.0.relocated520, %put.dynic.store.ref.249 ], [ %r8.0.relocated520, %put.dynic.trans.stamp.258 ]
  %.17 = phi ptr addrspace(1) [ %rs4gc.s9.relocated532, %put.dynic.slow.259 ], [ %rs4gc.s9.relocated523, %put.dynic.store.scalar.248 ], [ %rs4gc.s9.relocated523, %put.dynic.store.ref.249 ], [ %rs4gc.s9.relocated523, %put.dynic.trans.stamp.258 ]
  %r1937 = phi double [ %r1745518, %put.dynic.store.scalar.248 ], [ %r1745518, %put.dynic.store.ref.249 ], [ %r1914, %put.dynic.trans.stamp.258 ], [ %r1936527, %put.dynic.slow.259 ]
  %r1938.rs4i = ptrtoint ptr addrspace(1) %.131473 to i64
  %r1938.rs4o = call i64 asm "", "=r,0"(i64 %r1938.rs4i) #7
  %r1938 = bitcast i64 %r1938.rs4o to double
  %r1939.rs4i = ptrtoint ptr addrspace(1) %.171382 to i64
  %r1939.rs4o = call i64 asm "", "=r,0"(i64 %r1939.rs4i) #7
  %r1939 = bitcast i64 %r1939.rs4o to double
  br label %ternary.then.261

ternary.then.261:                                 ; preds = %put.dynic.merge.260
  br label %ternary.merge.263

ternary.merge.263:                                ; preds = %ternary.then.261
  %statepoint_token534 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1938, double %r1939, double 0.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.141324, ptr addrspace(1) %.141440, ptr addrspace(1) %.171382, ptr addrspace(1) %.17, ptr addrspace(1) %.131473, ptr addrspace(1) %.01486) ]
  %r1954535 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token534)
  %r8.0.relocated536 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token534, i32 0, i32 0) ; (%.141324, %.141324)
  %rs4gc.s15.relocated537 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token534, i32 1, i32 1) ; (%.141440, %.141440)
  %rs4gc.s13.relocated538 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token534, i32 2, i32 2) ; (%.171382, %.171382)
  %rs4gc.s9.relocated539 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token534, i32 3, i32 3) ; (%.17, %.17)
  %rs4gc.s18.relocated540 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token534, i32 4, i32 4) ; (%.131473, %.131473)
  %r497.3.relocated541 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token534, i32 5, i32 5) ; (%.01486, %.01486)
  %r1955 = bitcast i64 %r1954535 to double
  %r1956 = bitcast i64 %r1954535 to double
  %r1957.rs4i = ptrtoint ptr addrspace(1) %r497.3.relocated541 to i64
  %r1957.rs4o = call i64 asm "", "=r,0"(i64 %r1957.rs4i) #7
  %r1957 = bitcast i64 %r1957.rs4o to double
  %r1958 = bitcast double %r1957 to i64
  %r1959 = and i64 %r1958, 281474976710655
  %r1960 = sub nsw i64 %r1959, 8
  %r1961 = inttoptr i64 %r1960 to ptr
  %r1962 = load i8, ptr %r1961, align 1
  %r1963 = icmp ne i8 %r1962, 1
  %r1964 = sub nsw i64 %r1959, 7
  %r1965 = inttoptr i64 %r1964 to ptr
  %r1966 = load i8, ptr %r1965, align 1
  %r1967 = and i8 %r1966, -128
  %r1968 = icmp ne i8 %r1967, 0
  %r1969 = or i1 %r1963, %r1968
  br i1 %r1968, label %apush.fwd.264, label %apush.elements.265

apush.fwd.264:                                    ; preds = %apush.elements.check.266, %ternary.merge.263
  %statepoint_token542 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1959, double %r1956, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated540, ptr addrspace(1) %r8.0.relocated536, ptr addrspace(1) %rs4gc.s15.relocated537, ptr addrspace(1) %rs4gc.s13.relocated538, ptr addrspace(1) %rs4gc.s9.relocated539) ]
  %r1996543 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token542)
  %rs4gc.s18.relocated544 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token542, i32 0, i32 0) ; (%rs4gc.s18.relocated540, %rs4gc.s18.relocated540)
  %r8.0.relocated545 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token542, i32 1, i32 1) ; (%r8.0.relocated536, %r8.0.relocated536)
  %rs4gc.s15.relocated546 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token542, i32 2, i32 2) ; (%rs4gc.s15.relocated537, %rs4gc.s15.relocated537)
  %rs4gc.s13.relocated547 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token542, i32 3, i32 3) ; (%rs4gc.s13.relocated538, %rs4gc.s13.relocated538)
  %rs4gc.s9.relocated548 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token542, i32 4, i32 4) ; (%rs4gc.s9.relocated539, %rs4gc.s9.relocated539)
  %r1997 = or i64 %r1996543, 9222527611924643840
  %r1998 = bitcast i64 %r1997 to double
  %rs4gc.b39 = bitcast double %r1998 to i64
  %rs4gc.s39 = inttoptr i64 %rs4gc.b39 to ptr addrspace(1)
  br label %apush.merge.270

apush.elements.265:                               ; preds = %ternary.merge.263
  %r1971 = add nuw nsw i64 %r1959, 8
  %r1972 = inttoptr i64 %r1971 to ptr
  %r1973 = load i64, ptr %r1972, align 8
  %r1974 = icmp ne i64 %r1973, 0
  %r1975 = icmp eq i8 %r1962, 2
  %r1976 = and i1 %r1975, %r1974
  %r1977 = select i1 %r1976, i64 %r1973, i64 %r1959
  %r1978 = inttoptr i64 %r1977 to ptr
  %r1979 = getelementptr i64, ptr %r1978, i64 12
  %r1980 = load i64, ptr %r1979, align 8
  %r1981 = icmp ne i64 %r1980, 0
  %r1982 = and i1 %r1976, %r1981
  %r1983 = select i1 %r1982, i64 %r1980, i64 %r1959
  %r1970 = icmp eq i8 %r1962, 1
  br i1 %r1970, label %apush.nofwd.267, label %apush.elements.check.266

apush.elements.check.266:                         ; preds = %apush.elements.265
  %r1984 = icmp ne i64 %r1983, 0
  %r1985 = sub i64 %r1983, 8
  %r1986 = inttoptr i64 %r1985 to ptr
  %r1987 = load i8, ptr %r1986, align 1
  %r1988 = icmp eq i8 %r1987, 1
  %r1989 = sub i64 %r1983, 7
  %r1990 = inttoptr i64 %r1989 to ptr
  %r1991 = load i8, ptr %r1990, align 1
  %r1992 = and i8 %r1991, -128
  %r1993 = icmp eq i8 %r1992, 0
  %r1994 = and i1 %r1984, %r1988
  %r1995 = and i1 %r1994, %r1993
  br i1 %r1995, label %apush.nofwd.267, label %apush.fwd.264

apush.nofwd.267:                                  ; preds = %apush.elements.check.266, %apush.elements.265
  %r1999 = phi i64 [ %r1959, %apush.elements.265 ], [ %r1983, %apush.elements.check.266 ]
  %r2000 = sub i64 %r1999, 6
  %r2001 = inttoptr i64 %r2000 to ptr
  %r2002 = load i16, ptr %r2001, align 2
  %r2003 = and i16 %r2002, 1031
  %r2004 = icmp eq i16 %r2003, 0
  %r2005 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2006 = icmp eq i8 %r2005, 0
  %r2007 = and i1 %r2004, %r2006
  %r2008 = icmp ult i64 %r1999, 4096
  %r2009 = inttoptr i64 %r1999 to ptr
  %r2010 = select i1 %r2008, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r2009
  %r2011 = load i32, ptr %r2010, align 4
  %r2012 = add i64 %r1999, 4
  %r2013 = inttoptr i64 %r2012 to ptr
  %r2014 = load i32, ptr %r2013, align 4
  %r2015 = icmp ult i32 %r2011, %r2014
  %r2016 = and i1 %r2015, %r2007
  br i1 %r2016, label %apush.inbounds.268, label %apush.realloc.269

apush.inbounds.268:                               ; preds = %apush.nofwd.267
  %r2017 = icmp ult i64 %r1999, 4096
  %r2018 = inttoptr i64 %r1999 to ptr
  %r2019 = select i1 %r2017, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r2018
  %r2020 = load i32, ptr %r2019, align 4
  %r2021 = zext i32 %r2020 to i64
  %r2022 = shl nuw nsw i64 %r2021, 3
  %r2023 = add nuw nsw i64 %r2022, 8
  %r2024 = add i64 %r1999, %r2023
  %r2025 = inttoptr i64 %r2024 to ptr
  store double %r1956, ptr %r2025, align 8
  %r2026 = lshr i64 %r1954535, 48
  %r2027 = icmp eq i64 %r2026, 32765
  %r2028 = and i16 %r2002, -1920
  %r2029 = icmp eq i16 %r2028, -24576
  %r2030 = and i1 %r2027, %r2029
  br i1 %r2030, label %apush.pointer_layout.done.272, label %apush.pointer_layout.bookkeeping.271

apush.realloc.269:                                ; preds = %apush.nofwd.267
  %statepoint_token549 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1959, double %r1956, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated540, ptr addrspace(1) %r8.0.relocated536, ptr addrspace(1) %rs4gc.s15.relocated537, ptr addrspace(1) %rs4gc.s13.relocated538, ptr addrspace(1) %rs4gc.s9.relocated539) ]
  %r2041550 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token549)
  %rs4gc.s18.relocated551 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token549, i32 0, i32 0) ; (%rs4gc.s18.relocated540, %rs4gc.s18.relocated540)
  %r8.0.relocated552 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token549, i32 1, i32 1) ; (%r8.0.relocated536, %r8.0.relocated536)
  %rs4gc.s15.relocated553 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token549, i32 2, i32 2) ; (%rs4gc.s15.relocated537, %rs4gc.s15.relocated537)
  %rs4gc.s13.relocated554 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token549, i32 3, i32 3) ; (%rs4gc.s13.relocated538, %rs4gc.s13.relocated538)
  %rs4gc.s9.relocated555 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token549, i32 4, i32 4) ; (%rs4gc.s9.relocated539, %rs4gc.s9.relocated539)
  %r2042 = or i64 %r2041550, 9222527611924643840
  %r2043 = bitcast i64 %r2042 to double
  %rs4gc.b40 = bitcast double %r2043 to i64
  %rs4gc.s40 = inttoptr i64 %rs4gc.b40 to ptr addrspace(1)
  br label %apush.merge.270

apush.merge.270:                                  ; preds = %apush.barrier.done.274, %apush.realloc.269, %apush.fwd.264
  %.141474 = phi ptr addrspace(1) [ %rs4gc.s18.relocated544, %apush.fwd.264 ], [ %rs4gc.s18.relocated540, %apush.barrier.done.274 ], [ %rs4gc.s18.relocated551, %apush.realloc.269 ]
  %.151441 = phi ptr addrspace(1) [ %rs4gc.s15.relocated546, %apush.fwd.264 ], [ %rs4gc.s15.relocated537, %apush.barrier.done.274 ], [ %rs4gc.s15.relocated553, %apush.realloc.269 ]
  %.181383 = phi ptr addrspace(1) [ %rs4gc.s13.relocated547, %apush.fwd.264 ], [ %rs4gc.s13.relocated538, %apush.barrier.done.274 ], [ %rs4gc.s13.relocated554, %apush.realloc.269 ]
  %.151325 = phi ptr addrspace(1) [ %r8.0.relocated545, %apush.fwd.264 ], [ %r8.0.relocated536, %apush.barrier.done.274 ], [ %r8.0.relocated552, %apush.realloc.269 ]
  %.18 = phi ptr addrspace(1) [ %rs4gc.s9.relocated548, %apush.fwd.264 ], [ %rs4gc.s9.relocated539, %apush.barrier.done.274 ], [ %rs4gc.s9.relocated555, %apush.realloc.269 ]
  %r497.4 = phi ptr addrspace(1) [ %rs4gc.s39, %apush.fwd.264 ], [ %r497.3.relocated541, %apush.barrier.done.274 ], [ %rs4gc.s40, %apush.realloc.269 ]
  %r2044.rs4i = ptrtoint ptr addrspace(1) %.151441 to i64
  %r2044.rs4o = call i64 asm "", "=r,0"(i64 %r2044.rs4i) #7
  %r2044 = bitcast i64 %r2044.rs4o to double
  %r2045 = bitcast double %r2044 to i64
  %rs4gc.s41 = inttoptr i64 %r2045 to ptr addrspace(1)
  %r2046.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s41 to i64
  %r2046 = call i64 asm "", "=r,0"(i64 %r2046.rs4i) #7
  %r2047 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2048 = icmp ne i32 %r2047, 0
  br i1 %r2048, label %shadow.root.barrier.275, label %shadow.root.barrier.done.276

apush.pointer_layout.bookkeeping.271:             ; preds = %apush.inbounds.268
  call void @js_string_addref_if_heap_string(double %r1956) #7
  call void @js_gc_note_slot_layout(i64 %r1999, i32 %r2020, i64 %r1954535) #7
  call void @js_array_note_numeric_write(i64 %r1999, i64 %r1954535) #7
  br label %apush.pointer_layout.done.272

apush.pointer_layout.done.272:                    ; preds = %apush.pointer_layout.bookkeeping.271, %apush.inbounds.268
  %r2031 = sub i64 %r1999, 7
  %r2032 = inttoptr i64 %r2031 to ptr
  %r2033 = load i8, ptr %r2032, align 1
  %r2034 = and i8 %r2033, 32
  %r2035 = icmp ne i8 %r2034, 0
  %r2036 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2037 = icmp ne i32 %r2036, 0
  %r2038 = or i1 %r2035, %r2037
  br i1 %r2038, label %apush.barrier.273, label %apush.barrier.done.274

apush.barrier.273:                                ; preds = %apush.pointer_layout.done.272
  call void @js_write_barrier_slot_validated_parent(i64 %r1999, i64 %r2024, i64 %r1954535) #7
  br label %apush.barrier.done.274

apush.barrier.done.274:                           ; preds = %apush.barrier.273, %apush.pointer_layout.done.272
  %r2039 = add i32 %r2020, 1
  %r2040 = inttoptr i64 %r1999 to ptr
  store i32 %r2039, ptr %r2040, align 4
  br label %apush.merge.270

shadow.root.barrier.275:                          ; preds = %apush.merge.270
  call void @js_write_barrier_root_nanbox(i64 %r2046) #7
  br label %shadow.root.barrier.done.276

shadow.root.barrier.done.276:                     ; preds = %shadow.root.barrier.275, %apush.merge.270
  %r2049.rs4i = ptrtoint ptr addrspace(1) %.151325 to i64
  %r2049.rs4o = call i64 asm "", "=r,0"(i64 %r2049.rs4i) #7
  %r2049 = bitcast i64 %r2049.rs4o to double
  %r2050 = load double, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  %statepoint_token556 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r2049, double %r2050, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.4, ptr addrspace(1) %.151325, ptr addrspace(1) %.151441, ptr addrspace(1) %.181383, ptr addrspace(1) %.18, ptr addrspace(1) %.141474, ptr addrspace(1) %rs4gc.s41) ]
  %r2051557 = call double @llvm.experimental.gc.result.f64(token %statepoint_token556)
  %r497.4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 0, i32 0) ; (%r497.4, %r497.4)
  %r8.0.relocated558 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 1, i32 1) ; (%.151325, %.151325)
  %rs4gc.s15.relocated559 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 2, i32 2) ; (%.151441, %.151441)
  %rs4gc.s13.relocated560 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 3, i32 3) ; (%.181383, %.181383)
  %rs4gc.s9.relocated561 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 4, i32 4) ; (%.18, %.18)
  %rs4gc.s18.relocated562 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 5, i32 5) ; (%.141474, %.141474)
  %rs4gc.s41.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token556, i32 6, i32 6) ; (%rs4gc.s41, %rs4gc.s41)
  %statepoint_token563 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r2051557, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.4.relocated, ptr addrspace(1) %r8.0.relocated558, ptr addrspace(1) %rs4gc.s15.relocated559, ptr addrspace(1) %rs4gc.s13.relocated560, ptr addrspace(1) %rs4gc.s9.relocated561, ptr addrspace(1) %rs4gc.s18.relocated562, ptr addrspace(1) %rs4gc.s41.relocated) ]
  %r2052564 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token563)
  %r497.4.relocated565 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token563, i32 0, i32 0) ; (%r497.4.relocated, %r497.4.relocated)
  %r8.0.relocated566 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token563, i32 1, i32 1) ; (%r8.0.relocated558, %r8.0.relocated558)
  %rs4gc.s15.relocated567 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token563, i32 2, i32 2) ; (%rs4gc.s15.relocated559, %rs4gc.s15.relocated559)
  %rs4gc.s13.relocated568 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token563, i32 3, i32 3) ; (%rs4gc.s13.relocated560, %rs4gc.s13.relocated560)
  %rs4gc.s9.relocated569 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token563, i32 4, i32 4) ; (%rs4gc.s9.relocated561, %rs4gc.s9.relocated561)
  %rs4gc.s18.relocated570 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token563, i32 5, i32 5) ; (%rs4gc.s18.relocated562, %rs4gc.s18.relocated562)
  %rs4gc.s41.relocated571 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token563, i32 6, i32 6) ; (%rs4gc.s41.relocated, %rs4gc.s41.relocated)
  %statepoint_token572 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r2052564, double 5.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.4.relocated565, ptr addrspace(1) %r8.0.relocated566, ptr addrspace(1) %rs4gc.s15.relocated567, ptr addrspace(1) %rs4gc.s13.relocated568, ptr addrspace(1) %rs4gc.s9.relocated569, ptr addrspace(1) %rs4gc.s18.relocated570, ptr addrspace(1) %rs4gc.s41.relocated571) ]
  %r2053573 = call double @llvm.experimental.gc.result.f64(token %statepoint_token572)
  %r497.4.relocated574 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token572, i32 0, i32 0) ; (%r497.4.relocated565, %r497.4.relocated565)
  %r8.0.relocated575 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token572, i32 1, i32 1) ; (%r8.0.relocated566, %r8.0.relocated566)
  %rs4gc.s15.relocated576 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token572, i32 2, i32 2) ; (%rs4gc.s15.relocated567, %rs4gc.s15.relocated567)
  %rs4gc.s13.relocated577 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token572, i32 3, i32 3) ; (%rs4gc.s13.relocated568, %rs4gc.s13.relocated568)
  %rs4gc.s9.relocated578 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token572, i32 4, i32 4) ; (%rs4gc.s9.relocated569, %rs4gc.s9.relocated569)
  %rs4gc.s18.relocated579 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token572, i32 5, i32 5) ; (%rs4gc.s18.relocated570, %rs4gc.s18.relocated570)
  %rs4gc.s41.relocated580 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token572, i32 6, i32 6) ; (%rs4gc.s41.relocated571, %rs4gc.s41.relocated571)
  %r2054.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s41.relocated580 to i64
  %r2054 = call i64 asm "", "=r,0"(i64 %r2054.rs4i) #7
  %r2055 = bitcast i64 %r2054 to double
  %r2056.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated579 to i64
  %r2056.rs4o = call i64 asm "", "=r,0"(i64 %r2056.rs4i) #7
  %r2056 = bitcast i64 %r2056.rs4o to double
  %r2057 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__7, align 8
  %r2058 = icmp ne ptr %r2057, null
  %r2059 = select i1 %r2058, ptr %r2057, ptr @perry_ic_test_json_large_string_emitters_ts__7
  %r2060 = bitcast double %r2053573 to i64
  %r2061 = bitcast double %r2056 to i64
  %r2062 = and i64 %r2061, 281474976710655
  %r2063 = lshr i64 %r2061, 48
  %r2064 = icmp eq i64 %r2063, 32765
  %r2065 = icmp ugt i64 %r2062, 1048575
  %r2066 = lshr i64 %r2060, 48
  %r2067 = icmp ne i64 %r2066, 32765
  %r2068 = icmp ne i64 %r2066, 32767
  %r2069 = icmp ne i64 %r2066, 32762
  %r2070 = and i1 %r2067, %r2068
  %r2071 = and i1 %r2070, %r2069
  %r2072 = icmp ne i64 %r2054, 0
  %r2073 = and i1 %r2064, %r2065
  %r2074 = and i1 %r2073, %r2072
  br i1 %r2074, label %put.dynic.guard.277, label %put.dynic.slow.295

put.dynic.guard.277:                              ; preds = %shadow.root.barrier.done.276
  %r2075 = sub nuw nsw i64 %r2062, 8
  %r2076 = inttoptr i64 %r2075 to ptr
  %r2077 = load i8, ptr %r2076, align 1
  %r2078 = icmp eq i8 %r2077, 2
  %r2079 = sub nuw nsw i64 %r2062, 7
  %r2080 = inttoptr i64 %r2079 to ptr
  %r2081 = load i8, ptr %r2080, align 1
  %r2082 = and i8 %r2081, -128
  %r2083 = icmp eq i8 %r2082, 0
  %r2084 = sub nuw nsw i64 %r2062, 6
  %r2085 = inttoptr i64 %r2084 to ptr
  %r2086 = load i16, ptr %r2085, align 2
  %r2087 = and i16 %r2086, 6535
  %r2088 = icmp eq i16 %r2087, 0
  %r2089 = add nuw nsw i64 %r2062, 0
  %r2090 = inttoptr i64 %r2089 to ptr
  %r2091 = load i32, ptr %r2090, align 4
  %r2092 = icmp ne i32 %r2091, 0
  %r2093 = icmp ne i32 %r2091, -2
  %r2094 = and i16 %r2086, 512
  %r2095 = icmp ne i16 %r2094, 0
  %r2096 = or i1 %r2092, %r2095
  %r2097 = add nuw nsw i64 %r2062, 4
  %r2098 = inttoptr i64 %r2097 to ptr
  %r2099 = load i32, ptr %r2098, align 4
  %r2100 = add i32 %r2099, -2147483648
  %r2101 = icmp ult i32 %r2100, 1073741824
  %r2102 = zext i32 %r2099 to i64
  %r2103 = or i64 %r2102, 4611686018427387904
  %r2104 = select i1 %r2101, i64 %r2103, i64 0
  %r2105 = getelementptr i64, ptr %r2059, i64 0
  %r2106 = load i64, ptr %r2105, align 8
  %r2107 = icmp eq i64 %r2104, %r2106
  %r2108 = icmp ne i64 %r2104, 0
  %r2109 = and i1 %r2078, %r2083
  %r2110 = and i1 %r2109, %r2088
  %r2111 = and i1 %r2110, %r2096
  %r2112 = and i1 %r2111, %r2093
  %r2113 = and i1 %r2107, %r2108
  %r2114 = and i1 %r2112, %r2113
  br i1 %r2114, label %put.dynic.ways.278, label %put.dynic.trans.gate.286

put.dynic.ways.278:                               ; preds = %put.dynic.guard.277
  %r2116 = getelementptr i64, ptr %r2057, i64 1
  %r2117 = load i64, ptr %r2116, align 8
  %r2118 = getelementptr i64, ptr %r2057, i64 2
  %r2119 = load i64, ptr %r2118, align 8
  %r2120 = icmp eq i64 %r2054, %r2117
  br i1 %r2120, label %put.dynic.store.281, label %put.dynic.way1.279

put.dynic.way1.279:                               ; preds = %put.dynic.ways.278
  %r2121 = getelementptr i64, ptr %r2057, i64 3
  %r2122 = load i64, ptr %r2121, align 8
  %r2123 = getelementptr i64, ptr %r2057, i64 4
  %r2124 = load i64, ptr %r2123, align 8
  %r2125 = icmp eq i64 %r2054, %r2122
  br i1 %r2125, label %put.dynic.store.281, label %put.dynic.way2.280

put.dynic.way2.280:                               ; preds = %put.dynic.way1.279
  %r2126 = getelementptr i64, ptr %r2057, i64 5
  %r2127 = load i64, ptr %r2126, align 8
  %r2128 = getelementptr i64, ptr %r2057, i64 6
  %r2129 = load i64, ptr %r2128, align 8
  %r2130 = icmp eq i64 %r2054, %r2127
  br i1 %r2130, label %put.dynic.store.281, label %put.dynic.trans.probe.287

put.dynic.store.281:                              ; preds = %put.dynic.way2.280, %put.dynic.way1.279, %put.dynic.ways.278
  %r2131 = phi i64 [ %r2119, %put.dynic.ways.278 ], [ %r2124, %put.dynic.way1.279 ], [ %r2129, %put.dynic.way2.280 ]
  %r2132 = shl i64 %r2131, 3
  %r2133 = add i64 %r2132, 16
  %r2134 = inttoptr i64 %r2062 to ptr
  %r2135 = getelementptr inbounds i8, ptr %r2134, i64 %r2133
  %r2136 = and i16 %r2086, 1024
  %r2137 = icmp ne i16 %r2136, 0
  br i1 %r2137, label %put.dynic.store.validate.282, label %put.dynic.store.dispatch.283

put.dynic.store.validate.282:                     ; preds = %put.dynic.store.281
  %r2138 = load double, ptr %r2135, align 8
  %r2139 = bitcast double %r2138 to i64
  %r2140 = icmp eq i64 %r2139, 9222246136947933200
  br i1 %r2140, label %put.dynic.slow.295, label %put.dynic.store.dispatch.283

put.dynic.store.dispatch.283:                     ; preds = %put.dynic.store.validate.282, %put.dynic.store.281
  br i1 %r2071, label %put.dynic.store.scalar.284, label %put.dynic.store.ref.285

put.dynic.store.scalar.284:                       ; preds = %put.dynic.store.dispatch.283
  store double %r2053573, ptr %r2135, align 8
  br label %put.dynic.merge.296

put.dynic.store.ref.285:                          ; preds = %put.dynic.store.dispatch.283
  %r2141 = trunc i64 %r2131 to i32
  %r2142 = shl i64 %r2131, 3
  %r2143 = add nuw nsw i64 %r2062, 16
  %r2144 = add i64 %r2143, %r2142
  %r2145 = load double, ptr %r2135, align 8
  %r2146 = bitcast double %r2145 to i64
  store double %r2053573, ptr %r2135, align 8
  call void @js_string_addref_if_heap_string(double %r2053573) #7
  %r2147 = bitcast double %r2053573 to i64
  %r4599.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated579 to i64
  %r4599.rs4o = call i64 asm "", "=r,0"(i64 %r4599.rs4i) #7
  %r4599 = bitcast i64 %r4599.rs4o to double
  %r4600 = bitcast double %r4599 to i64
  %r4601 = and i64 %r4600, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4601, i32 %r2141, i64 %r2147, i64 %r2146) #7
  %r4597.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated579 to i64
  %r4597.rs4o = call i64 asm "", "=r,0"(i64 %r4597.rs4i) #7
  %r4597 = bitcast i64 %r4597.rs4o to double
  %r4598 = bitcast double %r4597 to i64
  call void @js_write_barrier_slot(i64 %r4598, i64 %r2144, i64 %r2147) #7
  br label %put.dynic.merge.296

put.dynic.trans.gate.286:                         ; preds = %put.dynic.guard.277
  %r2115 = and i1 %r2112, %r2108
  br i1 %r2115, label %put.dynic.trans.probe.287, label %put.dynic.slow.295

put.dynic.trans.probe.287:                        ; preds = %put.dynic.trans.gate.286, %put.dynic.way2.280
  %r2148 = lshr i64 %r2054, 48
  %r2149 = icmp eq i64 %r2148, 32767
  %r2150 = and i64 %r2054, 281474976710655
  %r2151 = icmp ugt i64 %r2150, 1048575
  %r2152 = and i16 %r2086, -16384
  %r2153 = icmp eq i16 %r2152, 0
  %r2154 = and i8 %r2081, 32
  %r2155 = icmp eq i8 %r2154, 0
  %r2156 = and i1 %r2149, %r2151
  %r2157 = and i1 %r2156, %r2153
  %r2158 = and i1 %r2157, %r2155
  br i1 %r2158, label %put.dynic.trans.key.288, label %put.dynic.slow.295

put.dynic.trans.key.288:                          ; preds = %put.dynic.trans.probe.287
  %r2159 = and i64 %r2054, 281474976710655
  %r2160 = add nuw nsw i64 %r2159, 4
  %r2161 = inttoptr i64 %r2160 to ptr
  %r2162 = load i32, ptr %r2161, align 4
  %r2163 = icmp uge i32 %r2162, 6
  %r2164 = icmp ule i32 %r2162, 8
  %r2165 = add nuw nsw i64 %r2159, 20
  %r2166 = inttoptr i64 %r2165 to ptr
  %r2167 = load i8, ptr %r2166, align 1
  %r2168 = sub i8 %r2167, 48
  %r2169 = icmp ult i8 %r2168, 10
  %r2170 = icmp eq i1 %r2169, false
  %r2171 = and i1 %r2163, %r2164
  %r2172 = and i1 %r2171, %r2170
  br i1 %r2172, label %put.dynic.trans.entry.289, label %put.dynic.slow.295

put.dynic.trans.entry.289:                        ; preds = %put.dynic.trans.key.288
  %r2173 = add nuw nsw i64 %r2159, 20
  %r2174 = inttoptr i64 %r2173 to ptr
  %r2175 = load i64, ptr %r2174, align 8
  %r2176 = zext nneg i32 %r2162 to i64
  %r2177 = sub nuw nsw i64 8, %r2176
  %r2178 = shl nuw nsw i64 %r2177, 3
  %r2179 = lshr i64 -1, %r2178
  %r2180 = and i64 %r2175, %r2179
  %r2182 = ptrtoint ptr %r92 to i64
  %r2183 = zext i32 %r2099 to i64
  %r2184 = mul i64 %r2183, -7046029254386353131
  %r2185 = lshr i64 %r2180, 3
  %r2186 = mul i64 %r2185, -4126379630918253789
  %r2187 = xor i64 %r2184, %r2186
  %r2188 = and i64 %r2187, 16383
  %r2189 = shl nuw nsw i64 %r2188, 5
  %r2190 = add i64 %r2182, %r2189
  %r2191 = inttoptr i64 %r2190 to ptr
  %r2192 = load i64, ptr %r2191, align 8
  %r2193 = add i64 %r2190, 8
  %r2194 = inttoptr i64 %r2193 to ptr
  %r2195 = load i64, ptr %r2194, align 8
  %r2196 = add i64 %r2190, 16
  %r2197 = inttoptr i64 %r2196 to ptr
  %r2198 = load i32, ptr %r2197, align 4
  %r2199 = add i64 %r2190, 20
  %r2200 = inttoptr i64 %r2199 to ptr
  %r2201 = load i32, ptr %r2200, align 4
  %r2202 = add i64 %r2190, 24
  %r2203 = inttoptr i64 %r2202 to ptr
  %r2204 = load i32, ptr %r2203, align 4
  %r2205 = lshr i32 %r2204, 24
  %r2206 = and i32 %r2204, 16777215
  %r2207 = add i64 %r2190, 28
  %r2208 = inttoptr i64 %r2207 to ptr
  %r2209 = load i32, ptr %r2208, align 4
  %r2210 = icmp eq i64 %r2192, %r2180
  %r2211 = icmp eq i32 %r2205, %r2162
  %r2212 = icmp eq i32 %r2198, %r2099
  %r2213 = icmp ne i64 %r2195, 0
  %r2214 = add nuw nsw i32 %r2206, 1
  %r2215 = icmp eq i32 %r2209, %r2214
  %r2216 = zext nneg i32 %r2206 to i64
  %r2217 = and i64 %r2060, 281474976710655
  %r2218 = icmp eq i64 %r2066, 32765
  %r2219 = icmp eq i64 %r2217, 0
  %r2220 = and i1 %r2218, %r2219
  %r2221 = select i1 %r2220, i64 9222246136947933185, i64 %r2060
  %r2222 = bitcast i64 %r2221 to double
  %r2223 = and i1 %r2210, %r2211
  %r2224 = and i1 %r2223, %r2212
  %r2225 = and i1 %r2224, %r2213
  %r2226 = and i1 %r2225, %r2215
  br i1 %r2226, label %put.dynic.trans.nk.290, label %put.dynic.slow.295

put.dynic.trans.nk.290:                           ; preds = %put.dynic.trans.entry.289
  %r2227 = inttoptr i64 %r2195 to ptr
  %r2228 = load i32, ptr %r2227, align 4
  %r2229 = icmp eq i32 %r2228, %r2214
  br i1 %r2229, label %put.dynic.trans.dispatch.291, label %put.dynic.slow.295

put.dynic.trans.dispatch.291:                     ; preds = %put.dynic.trans.nk.290
  %r2230 = icmp ult i64 %r2216, 2
  br i1 %r2230, label %put.dynic.trans.inline_ref.292, label %put.dynic.trans.ovf.293

put.dynic.trans.inline_ref.292:                   ; preds = %put.dynic.trans.dispatch.291
  %r2231 = shl nuw nsw i64 %r2216, 3
  %r2232 = add nuw nsw i64 %r2231, 16
  %r2233 = add nuw nsw i64 %r2062, %r2232
  %r2234 = inttoptr i64 %r2233 to ptr
  %r2235 = trunc nuw nsw i64 %r2216 to i32
  %r2236 = load double, ptr %r2234, align 8
  %r2237 = bitcast double %r2236 to i64
  store double %r2222, ptr %r2234, align 8
  call void @js_string_addref_if_heap_string(double %r2222) #7
  %r2238 = bitcast double %r2222 to i64
  %r4594.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated579 to i64
  %r4594.rs4o = call i64 asm "", "=r,0"(i64 %r4594.rs4i) #7
  %r4594 = bitcast i64 %r4594.rs4o to double
  %r4595 = bitcast double %r4594 to i64
  %r4596 = and i64 %r4595, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4596, i32 %r2235, i64 %r2238, i64 %r2237) #7
  %r4592.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated579 to i64
  %r4592.rs4o = call i64 asm "", "=r,0"(i64 %r4592.rs4i) #7
  %r4592 = bitcast i64 %r4592.rs4o to double
  %r4593 = bitcast double %r4592 to i64
  call void @js_write_barrier_slot(i64 %r4593, i64 %r2233, i64 %r2238) #7
  br label %put.dynic.trans.stamp.294

put.dynic.trans.ovf.293:                          ; preds = %put.dynic.trans.dispatch.291
  %r2239 = trunc nuw nsw i64 %r2216 to i32
  %r2240 = call i32 @js_transition_ic_spill_append(double %r2056, i64 %r2104, i32 %r2239, double %r2222) #7
  %r2241 = icmp ne i32 %r2240, 0
  br i1 %r2241, label %put.dynic.trans.stamp.294, label %put.dynic.slow.295

put.dynic.trans.stamp.294:                        ; preds = %put.dynic.trans.ovf.293, %put.dynic.trans.inline_ref.292
  %r4589.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated579 to i64
  %r4589.rs4o = call i64 asm "", "=r,0"(i64 %r4589.rs4i) #7
  %r4589 = bitcast i64 %r4589.rs4o to double
  %r4590 = bitcast double %r4589 to i64
  %r4591 = and i64 %r4590, 281474976710655
  %r2242 = add nuw nsw i64 %r4591, 4
  %r2243 = inttoptr i64 %r2242 to ptr
  store i32 %r2201, ptr %r2243, align 4
  br label %put.dynic.merge.296

put.dynic.slow.295:                               ; preds = %put.dynic.trans.ovf.293, %put.dynic.trans.nk.290, %put.dynic.trans.entry.289, %put.dynic.trans.key.288, %put.dynic.trans.probe.287, %put.dynic.trans.gate.286, %put.dynic.store.validate.282, %shadow.root.barrier.done.276
  %statepoint_token581 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_large_string_emitters_ts__7, double %r2056, double %r2055, double %r2053573, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.4.relocated574, ptr addrspace(1) %r8.0.relocated575, ptr addrspace(1) %rs4gc.s15.relocated576, ptr addrspace(1) %rs4gc.s13.relocated577, ptr addrspace(1) %rs4gc.s9.relocated578, ptr addrspace(1) %rs4gc.s18.relocated579) ]
  %r2244582 = call double @llvm.experimental.gc.result.f64(token %statepoint_token581)
  %r497.4.relocated583 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token581, i32 0, i32 0) ; (%r497.4.relocated574, %r497.4.relocated574)
  %r8.0.relocated584 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token581, i32 1, i32 1) ; (%r8.0.relocated575, %r8.0.relocated575)
  %rs4gc.s15.relocated585 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token581, i32 2, i32 2) ; (%rs4gc.s15.relocated576, %rs4gc.s15.relocated576)
  %rs4gc.s13.relocated586 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token581, i32 3, i32 3) ; (%rs4gc.s13.relocated577, %rs4gc.s13.relocated577)
  %rs4gc.s9.relocated587 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token581, i32 4, i32 4) ; (%rs4gc.s9.relocated578, %rs4gc.s9.relocated578)
  %rs4gc.s18.relocated588 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token581, i32 5, i32 5) ; (%rs4gc.s18.relocated579, %rs4gc.s18.relocated579)
  br label %put.dynic.merge.296

put.dynic.merge.296:                              ; preds = %put.dynic.slow.295, %put.dynic.trans.stamp.294, %put.dynic.store.ref.285, %put.dynic.store.scalar.284
  %.01487 = phi ptr addrspace(1) [ %r497.4.relocated583, %put.dynic.slow.295 ], [ %r497.4.relocated574, %put.dynic.store.scalar.284 ], [ %r497.4.relocated574, %put.dynic.store.ref.285 ], [ %r497.4.relocated574, %put.dynic.trans.stamp.294 ]
  %.151475 = phi ptr addrspace(1) [ %rs4gc.s18.relocated588, %put.dynic.slow.295 ], [ %rs4gc.s18.relocated579, %put.dynic.store.scalar.284 ], [ %rs4gc.s18.relocated579, %put.dynic.store.ref.285 ], [ %rs4gc.s18.relocated579, %put.dynic.trans.stamp.294 ]
  %.161442 = phi ptr addrspace(1) [ %rs4gc.s15.relocated585, %put.dynic.slow.295 ], [ %rs4gc.s15.relocated576, %put.dynic.store.scalar.284 ], [ %rs4gc.s15.relocated576, %put.dynic.store.ref.285 ], [ %rs4gc.s15.relocated576, %put.dynic.trans.stamp.294 ]
  %.191384 = phi ptr addrspace(1) [ %rs4gc.s13.relocated586, %put.dynic.slow.295 ], [ %rs4gc.s13.relocated577, %put.dynic.store.scalar.284 ], [ %rs4gc.s13.relocated577, %put.dynic.store.ref.285 ], [ %rs4gc.s13.relocated577, %put.dynic.trans.stamp.294 ]
  %.161326 = phi ptr addrspace(1) [ %r8.0.relocated584, %put.dynic.slow.295 ], [ %r8.0.relocated575, %put.dynic.store.scalar.284 ], [ %r8.0.relocated575, %put.dynic.store.ref.285 ], [ %r8.0.relocated575, %put.dynic.trans.stamp.294 ]
  %.19 = phi ptr addrspace(1) [ %rs4gc.s9.relocated587, %put.dynic.slow.295 ], [ %rs4gc.s9.relocated578, %put.dynic.store.scalar.284 ], [ %rs4gc.s9.relocated578, %put.dynic.store.ref.285 ], [ %rs4gc.s9.relocated578, %put.dynic.trans.stamp.294 ]
  %r2245 = phi double [ %r2053573, %put.dynic.store.scalar.284 ], [ %r2053573, %put.dynic.store.ref.285 ], [ %r2222, %put.dynic.trans.stamp.294 ], [ %r2244582, %put.dynic.slow.295 ]
  %r2246.rs4i = ptrtoint ptr addrspace(1) %.151475 to i64
  %r2246.rs4o = call i64 asm "", "=r,0"(i64 %r2246.rs4i) #7
  %r2246 = bitcast i64 %r2246.rs4o to double
  %r2247.rs4i = ptrtoint ptr addrspace(1) %.191384 to i64
  %r2247.rs4o = call i64 asm "", "=r,0"(i64 %r2247.rs4i) #7
  %r2247 = bitcast i64 %r2247.rs4o to double
  br label %ternary.else.298

ternary.else.298:                                 ; preds = %put.dynic.merge.296
  br label %ternary.merge.299

ternary.merge.299:                                ; preds = %ternary.else.298
  %statepoint_token589 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r2246, double %r2247, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.161326, ptr addrspace(1) %.161442, ptr addrspace(1) %.191384, ptr addrspace(1) %.19, ptr addrspace(1) %.151475, ptr addrspace(1) %.01487) ]
  %r2262590 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token589)
  %r8.0.relocated591 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token589, i32 0, i32 0) ; (%.161326, %.161326)
  %rs4gc.s15.relocated592 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token589, i32 1, i32 1) ; (%.161442, %.161442)
  %rs4gc.s13.relocated593 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token589, i32 2, i32 2) ; (%.191384, %.191384)
  %rs4gc.s9.relocated594 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token589, i32 3, i32 3) ; (%.19, %.19)
  %rs4gc.s18.relocated595 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token589, i32 4, i32 4) ; (%.151475, %.151475)
  %r497.4.relocated596 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token589, i32 5, i32 5) ; (%.01487, %.01487)
  %r2263 = bitcast i64 %r2262590 to double
  %r2264 = bitcast i64 %r2262590 to double
  %r2265.rs4i = ptrtoint ptr addrspace(1) %r497.4.relocated596 to i64
  %r2265.rs4o = call i64 asm "", "=r,0"(i64 %r2265.rs4i) #7
  %r2265 = bitcast i64 %r2265.rs4o to double
  %r2266 = bitcast double %r2265 to i64
  %r2267 = and i64 %r2266, 281474976710655
  %r2268 = sub nsw i64 %r2267, 8
  %r2269 = inttoptr i64 %r2268 to ptr
  %r2270 = load i8, ptr %r2269, align 1
  %r2271 = icmp ne i8 %r2270, 1
  %r2272 = sub nsw i64 %r2267, 7
  %r2273 = inttoptr i64 %r2272 to ptr
  %r2274 = load i8, ptr %r2273, align 1
  %r2275 = and i8 %r2274, -128
  %r2276 = icmp ne i8 %r2275, 0
  %r2277 = or i1 %r2271, %r2276
  br i1 %r2276, label %apush.fwd.300, label %apush.elements.301

apush.fwd.300:                                    ; preds = %apush.elements.check.302, %ternary.merge.299
  %statepoint_token597 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2267, double %r2264, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated595, ptr addrspace(1) %r8.0.relocated591, ptr addrspace(1) %rs4gc.s15.relocated592, ptr addrspace(1) %rs4gc.s13.relocated593, ptr addrspace(1) %rs4gc.s9.relocated594) ]
  %r2304598 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token597)
  %rs4gc.s18.relocated599 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token597, i32 0, i32 0) ; (%rs4gc.s18.relocated595, %rs4gc.s18.relocated595)
  %r8.0.relocated600 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token597, i32 1, i32 1) ; (%r8.0.relocated591, %r8.0.relocated591)
  %rs4gc.s15.relocated601 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token597, i32 2, i32 2) ; (%rs4gc.s15.relocated592, %rs4gc.s15.relocated592)
  %rs4gc.s13.relocated602 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token597, i32 3, i32 3) ; (%rs4gc.s13.relocated593, %rs4gc.s13.relocated593)
  %rs4gc.s9.relocated603 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token597, i32 4, i32 4) ; (%rs4gc.s9.relocated594, %rs4gc.s9.relocated594)
  %r2305 = or i64 %r2304598, 9222527611924643840
  %r2306 = bitcast i64 %r2305 to double
  %rs4gc.b42 = bitcast double %r2306 to i64
  %rs4gc.s42 = inttoptr i64 %rs4gc.b42 to ptr addrspace(1)
  br label %apush.merge.306

apush.elements.301:                               ; preds = %ternary.merge.299
  %r2279 = add nuw nsw i64 %r2267, 8
  %r2280 = inttoptr i64 %r2279 to ptr
  %r2281 = load i64, ptr %r2280, align 8
  %r2282 = icmp ne i64 %r2281, 0
  %r2283 = icmp eq i8 %r2270, 2
  %r2284 = and i1 %r2283, %r2282
  %r2285 = select i1 %r2284, i64 %r2281, i64 %r2267
  %r2286 = inttoptr i64 %r2285 to ptr
  %r2287 = getelementptr i64, ptr %r2286, i64 12
  %r2288 = load i64, ptr %r2287, align 8
  %r2289 = icmp ne i64 %r2288, 0
  %r2290 = and i1 %r2284, %r2289
  %r2291 = select i1 %r2290, i64 %r2288, i64 %r2267
  %r2278 = icmp eq i8 %r2270, 1
  br i1 %r2278, label %apush.nofwd.303, label %apush.elements.check.302

apush.elements.check.302:                         ; preds = %apush.elements.301
  %r2292 = icmp ne i64 %r2291, 0
  %r2293 = sub i64 %r2291, 8
  %r2294 = inttoptr i64 %r2293 to ptr
  %r2295 = load i8, ptr %r2294, align 1
  %r2296 = icmp eq i8 %r2295, 1
  %r2297 = sub i64 %r2291, 7
  %r2298 = inttoptr i64 %r2297 to ptr
  %r2299 = load i8, ptr %r2298, align 1
  %r2300 = and i8 %r2299, -128
  %r2301 = icmp eq i8 %r2300, 0
  %r2302 = and i1 %r2292, %r2296
  %r2303 = and i1 %r2302, %r2301
  br i1 %r2303, label %apush.nofwd.303, label %apush.fwd.300

apush.nofwd.303:                                  ; preds = %apush.elements.check.302, %apush.elements.301
  %r2307 = phi i64 [ %r2267, %apush.elements.301 ], [ %r2291, %apush.elements.check.302 ]
  %r2308 = sub i64 %r2307, 6
  %r2309 = inttoptr i64 %r2308 to ptr
  %r2310 = load i16, ptr %r2309, align 2
  %r2311 = and i16 %r2310, 1031
  %r2312 = icmp eq i16 %r2311, 0
  %r2313 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2314 = icmp eq i8 %r2313, 0
  %r2315 = and i1 %r2312, %r2314
  %r2316 = icmp ult i64 %r2307, 4096
  %r2317 = inttoptr i64 %r2307 to ptr
  %r2318 = select i1 %r2316, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r2317
  %r2319 = load i32, ptr %r2318, align 4
  %r2320 = add i64 %r2307, 4
  %r2321 = inttoptr i64 %r2320 to ptr
  %r2322 = load i32, ptr %r2321, align 4
  %r2323 = icmp ult i32 %r2319, %r2322
  %r2324 = and i1 %r2323, %r2315
  br i1 %r2324, label %apush.inbounds.304, label %apush.realloc.305

apush.inbounds.304:                               ; preds = %apush.nofwd.303
  %r2325 = icmp ult i64 %r2307, 4096
  %r2326 = inttoptr i64 %r2307 to ptr
  %r2327 = select i1 %r2325, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r2326
  %r2328 = load i32, ptr %r2327, align 4
  %r2329 = zext i32 %r2328 to i64
  %r2330 = shl nuw nsw i64 %r2329, 3
  %r2331 = add nuw nsw i64 %r2330, 8
  %r2332 = add i64 %r2307, %r2331
  %r2333 = inttoptr i64 %r2332 to ptr
  store double %r2264, ptr %r2333, align 8
  %r2334 = lshr i64 %r2262590, 48
  %r2335 = icmp eq i64 %r2334, 32765
  %r2336 = and i16 %r2310, -1920
  %r2337 = icmp eq i16 %r2336, -24576
  %r2338 = and i1 %r2335, %r2337
  br i1 %r2338, label %apush.pointer_layout.done.308, label %apush.pointer_layout.bookkeeping.307

apush.realloc.305:                                ; preds = %apush.nofwd.303
  %statepoint_token604 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2267, double %r2264, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated595, ptr addrspace(1) %r8.0.relocated591, ptr addrspace(1) %rs4gc.s15.relocated592, ptr addrspace(1) %rs4gc.s13.relocated593, ptr addrspace(1) %rs4gc.s9.relocated594) ]
  %r2349605 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token604)
  %rs4gc.s18.relocated606 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token604, i32 0, i32 0) ; (%rs4gc.s18.relocated595, %rs4gc.s18.relocated595)
  %r8.0.relocated607 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token604, i32 1, i32 1) ; (%r8.0.relocated591, %r8.0.relocated591)
  %rs4gc.s15.relocated608 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token604, i32 2, i32 2) ; (%rs4gc.s15.relocated592, %rs4gc.s15.relocated592)
  %rs4gc.s13.relocated609 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token604, i32 3, i32 3) ; (%rs4gc.s13.relocated593, %rs4gc.s13.relocated593)
  %rs4gc.s9.relocated610 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token604, i32 4, i32 4) ; (%rs4gc.s9.relocated594, %rs4gc.s9.relocated594)
  %r2350 = or i64 %r2349605, 9222527611924643840
  %r2351 = bitcast i64 %r2350 to double
  %rs4gc.b43 = bitcast double %r2351 to i64
  %rs4gc.s43 = inttoptr i64 %rs4gc.b43 to ptr addrspace(1)
  br label %apush.merge.306

apush.merge.306:                                  ; preds = %apush.barrier.done.310, %apush.realloc.305, %apush.fwd.300
  %.161476 = phi ptr addrspace(1) [ %rs4gc.s18.relocated599, %apush.fwd.300 ], [ %rs4gc.s18.relocated595, %apush.barrier.done.310 ], [ %rs4gc.s18.relocated606, %apush.realloc.305 ]
  %.171443 = phi ptr addrspace(1) [ %rs4gc.s15.relocated601, %apush.fwd.300 ], [ %rs4gc.s15.relocated592, %apush.barrier.done.310 ], [ %rs4gc.s15.relocated608, %apush.realloc.305 ]
  %.201385 = phi ptr addrspace(1) [ %rs4gc.s13.relocated602, %apush.fwd.300 ], [ %rs4gc.s13.relocated593, %apush.barrier.done.310 ], [ %rs4gc.s13.relocated609, %apush.realloc.305 ]
  %.171327 = phi ptr addrspace(1) [ %r8.0.relocated600, %apush.fwd.300 ], [ %r8.0.relocated591, %apush.barrier.done.310 ], [ %r8.0.relocated607, %apush.realloc.305 ]
  %.20 = phi ptr addrspace(1) [ %rs4gc.s9.relocated603, %apush.fwd.300 ], [ %rs4gc.s9.relocated594, %apush.barrier.done.310 ], [ %rs4gc.s9.relocated610, %apush.realloc.305 ]
  %r497.5 = phi ptr addrspace(1) [ %rs4gc.s42, %apush.fwd.300 ], [ %r497.4.relocated596, %apush.barrier.done.310 ], [ %rs4gc.s43, %apush.realloc.305 ]
  %r2352.rs4i = ptrtoint ptr addrspace(1) %.171443 to i64
  %r2352.rs4o = call i64 asm "", "=r,0"(i64 %r2352.rs4i) #7
  %r2352 = bitcast i64 %r2352.rs4o to double
  %r2353 = bitcast double %r2352 to i64
  %rs4gc.s44 = inttoptr i64 %r2353 to ptr addrspace(1)
  %r2354.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s44 to i64
  %r2354 = call i64 asm "", "=r,0"(i64 %r2354.rs4i) #7
  %r2355 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2356 = icmp ne i32 %r2355, 0
  br i1 %r2356, label %shadow.root.barrier.311, label %shadow.root.barrier.done.312

apush.pointer_layout.bookkeeping.307:             ; preds = %apush.inbounds.304
  call void @js_string_addref_if_heap_string(double %r2264) #7
  call void @js_gc_note_slot_layout(i64 %r2307, i32 %r2328, i64 %r2262590) #7
  call void @js_array_note_numeric_write(i64 %r2307, i64 %r2262590) #7
  br label %apush.pointer_layout.done.308

apush.pointer_layout.done.308:                    ; preds = %apush.pointer_layout.bookkeeping.307, %apush.inbounds.304
  %r2339 = sub i64 %r2307, 7
  %r2340 = inttoptr i64 %r2339 to ptr
  %r2341 = load i8, ptr %r2340, align 1
  %r2342 = and i8 %r2341, 32
  %r2343 = icmp ne i8 %r2342, 0
  %r2344 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2345 = icmp ne i32 %r2344, 0
  %r2346 = or i1 %r2343, %r2345
  br i1 %r2346, label %apush.barrier.309, label %apush.barrier.done.310

apush.barrier.309:                                ; preds = %apush.pointer_layout.done.308
  call void @js_write_barrier_slot_validated_parent(i64 %r2307, i64 %r2332, i64 %r2262590) #7
  br label %apush.barrier.done.310

apush.barrier.done.310:                           ; preds = %apush.barrier.309, %apush.pointer_layout.done.308
  %r2347 = add i32 %r2328, 1
  %r2348 = inttoptr i64 %r2307 to ptr
  store i32 %r2347, ptr %r2348, align 4
  br label %apush.merge.306

shadow.root.barrier.311:                          ; preds = %apush.merge.306
  call void @js_write_barrier_root_nanbox(i64 %r2354) #7
  br label %shadow.root.barrier.done.312

shadow.root.barrier.done.312:                     ; preds = %shadow.root.barrier.311, %apush.merge.306
  %r2357.rs4i = ptrtoint ptr addrspace(1) %.171327 to i64
  %r2357.rs4o = call i64 asm "", "=r,0"(i64 %r2357.rs4i) #7
  %r2357 = bitcast i64 %r2357.rs4o to double
  %r2358 = load double, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  %statepoint_token611 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r2357, double %r2358, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.5, ptr addrspace(1) %.171327, ptr addrspace(1) %.171443, ptr addrspace(1) %.201385, ptr addrspace(1) %.20, ptr addrspace(1) %.161476, ptr addrspace(1) %rs4gc.s44) ]
  %r2359612 = call double @llvm.experimental.gc.result.f64(token %statepoint_token611)
  %r497.5.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 0, i32 0) ; (%r497.5, %r497.5)
  %r8.0.relocated613 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 1, i32 1) ; (%.171327, %.171327)
  %rs4gc.s15.relocated614 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 2, i32 2) ; (%.171443, %.171443)
  %rs4gc.s13.relocated615 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 3, i32 3) ; (%.201385, %.201385)
  %rs4gc.s9.relocated616 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 4, i32 4) ; (%.20, %.20)
  %rs4gc.s18.relocated617 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 5, i32 5) ; (%.161476, %.161476)
  %rs4gc.s44.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token611, i32 6, i32 6) ; (%rs4gc.s44, %rs4gc.s44)
  %statepoint_token618 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r2359612, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.5.relocated, ptr addrspace(1) %r8.0.relocated613, ptr addrspace(1) %rs4gc.s15.relocated614, ptr addrspace(1) %rs4gc.s13.relocated615, ptr addrspace(1) %rs4gc.s9.relocated616, ptr addrspace(1) %rs4gc.s18.relocated617, ptr addrspace(1) %rs4gc.s44.relocated) ]
  %r2360619 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token618)
  %r497.5.relocated620 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 0, i32 0) ; (%r497.5.relocated, %r497.5.relocated)
  %r8.0.relocated621 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 1, i32 1) ; (%r8.0.relocated613, %r8.0.relocated613)
  %rs4gc.s15.relocated622 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 2, i32 2) ; (%rs4gc.s15.relocated614, %rs4gc.s15.relocated614)
  %rs4gc.s13.relocated623 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 3, i32 3) ; (%rs4gc.s13.relocated615, %rs4gc.s13.relocated615)
  %rs4gc.s9.relocated624 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 4, i32 4) ; (%rs4gc.s9.relocated616, %rs4gc.s9.relocated616)
  %rs4gc.s18.relocated625 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 5, i32 5) ; (%rs4gc.s18.relocated617, %rs4gc.s18.relocated617)
  %rs4gc.s44.relocated626 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 6, i32 6) ; (%rs4gc.s44.relocated, %rs4gc.s44.relocated)
  %statepoint_token627 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r2360619, double 6.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.5.relocated620, ptr addrspace(1) %r8.0.relocated621, ptr addrspace(1) %rs4gc.s15.relocated622, ptr addrspace(1) %rs4gc.s13.relocated623, ptr addrspace(1) %rs4gc.s9.relocated624, ptr addrspace(1) %rs4gc.s18.relocated625, ptr addrspace(1) %rs4gc.s44.relocated626) ]
  %r2361628 = call double @llvm.experimental.gc.result.f64(token %statepoint_token627)
  %r497.5.relocated629 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 0, i32 0) ; (%r497.5.relocated620, %r497.5.relocated620)
  %r8.0.relocated630 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 1, i32 1) ; (%r8.0.relocated621, %r8.0.relocated621)
  %rs4gc.s15.relocated631 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 2, i32 2) ; (%rs4gc.s15.relocated622, %rs4gc.s15.relocated622)
  %rs4gc.s13.relocated632 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 3, i32 3) ; (%rs4gc.s13.relocated623, %rs4gc.s13.relocated623)
  %rs4gc.s9.relocated633 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 4, i32 4) ; (%rs4gc.s9.relocated624, %rs4gc.s9.relocated624)
  %rs4gc.s18.relocated634 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 5, i32 5) ; (%rs4gc.s18.relocated625, %rs4gc.s18.relocated625)
  %rs4gc.s44.relocated635 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token627, i32 6, i32 6) ; (%rs4gc.s44.relocated626, %rs4gc.s44.relocated626)
  %r2362.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s44.relocated635 to i64
  %r2362 = call i64 asm "", "=r,0"(i64 %r2362.rs4i) #7
  %r2363 = bitcast i64 %r2362 to double
  %r2364.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated634 to i64
  %r2364.rs4o = call i64 asm "", "=r,0"(i64 %r2364.rs4i) #7
  %r2364 = bitcast i64 %r2364.rs4o to double
  %r2365 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__8, align 8
  %r2366 = icmp ne ptr %r2365, null
  %r2367 = select i1 %r2366, ptr %r2365, ptr @perry_ic_test_json_large_string_emitters_ts__8
  %r2368 = bitcast double %r2361628 to i64
  %r2369 = bitcast double %r2364 to i64
  %r2370 = and i64 %r2369, 281474976710655
  %r2371 = lshr i64 %r2369, 48
  %r2372 = icmp eq i64 %r2371, 32765
  %r2373 = icmp ugt i64 %r2370, 1048575
  %r2374 = lshr i64 %r2368, 48
  %r2375 = icmp ne i64 %r2374, 32765
  %r2376 = icmp ne i64 %r2374, 32767
  %r2377 = icmp ne i64 %r2374, 32762
  %r2378 = and i1 %r2375, %r2376
  %r2379 = and i1 %r2378, %r2377
  %r2380 = icmp ne i64 %r2362, 0
  %r2381 = and i1 %r2372, %r2373
  %r2382 = and i1 %r2381, %r2380
  br i1 %r2382, label %put.dynic.guard.313, label %put.dynic.slow.331

put.dynic.guard.313:                              ; preds = %shadow.root.barrier.done.312
  %r2383 = sub nuw nsw i64 %r2370, 8
  %r2384 = inttoptr i64 %r2383 to ptr
  %r2385 = load i8, ptr %r2384, align 1
  %r2386 = icmp eq i8 %r2385, 2
  %r2387 = sub nuw nsw i64 %r2370, 7
  %r2388 = inttoptr i64 %r2387 to ptr
  %r2389 = load i8, ptr %r2388, align 1
  %r2390 = and i8 %r2389, -128
  %r2391 = icmp eq i8 %r2390, 0
  %r2392 = sub nuw nsw i64 %r2370, 6
  %r2393 = inttoptr i64 %r2392 to ptr
  %r2394 = load i16, ptr %r2393, align 2
  %r2395 = and i16 %r2394, 6535
  %r2396 = icmp eq i16 %r2395, 0
  %r2397 = add nuw nsw i64 %r2370, 0
  %r2398 = inttoptr i64 %r2397 to ptr
  %r2399 = load i32, ptr %r2398, align 4
  %r2400 = icmp ne i32 %r2399, 0
  %r2401 = icmp ne i32 %r2399, -2
  %r2402 = and i16 %r2394, 512
  %r2403 = icmp ne i16 %r2402, 0
  %r2404 = or i1 %r2400, %r2403
  %r2405 = add nuw nsw i64 %r2370, 4
  %r2406 = inttoptr i64 %r2405 to ptr
  %r2407 = load i32, ptr %r2406, align 4
  %r2408 = add i32 %r2407, -2147483648
  %r2409 = icmp ult i32 %r2408, 1073741824
  %r2410 = zext i32 %r2407 to i64
  %r2411 = or i64 %r2410, 4611686018427387904
  %r2412 = select i1 %r2409, i64 %r2411, i64 0
  %r2413 = getelementptr i64, ptr %r2367, i64 0
  %r2414 = load i64, ptr %r2413, align 8
  %r2415 = icmp eq i64 %r2412, %r2414
  %r2416 = icmp ne i64 %r2412, 0
  %r2417 = and i1 %r2386, %r2391
  %r2418 = and i1 %r2417, %r2396
  %r2419 = and i1 %r2418, %r2404
  %r2420 = and i1 %r2419, %r2401
  %r2421 = and i1 %r2415, %r2416
  %r2422 = and i1 %r2420, %r2421
  br i1 %r2422, label %put.dynic.ways.314, label %put.dynic.trans.gate.322

put.dynic.ways.314:                               ; preds = %put.dynic.guard.313
  %r2424 = getelementptr i64, ptr %r2365, i64 1
  %r2425 = load i64, ptr %r2424, align 8
  %r2426 = getelementptr i64, ptr %r2365, i64 2
  %r2427 = load i64, ptr %r2426, align 8
  %r2428 = icmp eq i64 %r2362, %r2425
  br i1 %r2428, label %put.dynic.store.317, label %put.dynic.way1.315

put.dynic.way1.315:                               ; preds = %put.dynic.ways.314
  %r2429 = getelementptr i64, ptr %r2365, i64 3
  %r2430 = load i64, ptr %r2429, align 8
  %r2431 = getelementptr i64, ptr %r2365, i64 4
  %r2432 = load i64, ptr %r2431, align 8
  %r2433 = icmp eq i64 %r2362, %r2430
  br i1 %r2433, label %put.dynic.store.317, label %put.dynic.way2.316

put.dynic.way2.316:                               ; preds = %put.dynic.way1.315
  %r2434 = getelementptr i64, ptr %r2365, i64 5
  %r2435 = load i64, ptr %r2434, align 8
  %r2436 = getelementptr i64, ptr %r2365, i64 6
  %r2437 = load i64, ptr %r2436, align 8
  %r2438 = icmp eq i64 %r2362, %r2435
  br i1 %r2438, label %put.dynic.store.317, label %put.dynic.trans.probe.323

put.dynic.store.317:                              ; preds = %put.dynic.way2.316, %put.dynic.way1.315, %put.dynic.ways.314
  %r2439 = phi i64 [ %r2427, %put.dynic.ways.314 ], [ %r2432, %put.dynic.way1.315 ], [ %r2437, %put.dynic.way2.316 ]
  %r2440 = shl i64 %r2439, 3
  %r2441 = add i64 %r2440, 16
  %r2442 = inttoptr i64 %r2370 to ptr
  %r2443 = getelementptr inbounds i8, ptr %r2442, i64 %r2441
  %r2444 = and i16 %r2394, 1024
  %r2445 = icmp ne i16 %r2444, 0
  br i1 %r2445, label %put.dynic.store.validate.318, label %put.dynic.store.dispatch.319

put.dynic.store.validate.318:                     ; preds = %put.dynic.store.317
  %r2446 = load double, ptr %r2443, align 8
  %r2447 = bitcast double %r2446 to i64
  %r2448 = icmp eq i64 %r2447, 9222246136947933200
  br i1 %r2448, label %put.dynic.slow.331, label %put.dynic.store.dispatch.319

put.dynic.store.dispatch.319:                     ; preds = %put.dynic.store.validate.318, %put.dynic.store.317
  br i1 %r2379, label %put.dynic.store.scalar.320, label %put.dynic.store.ref.321

put.dynic.store.scalar.320:                       ; preds = %put.dynic.store.dispatch.319
  store double %r2361628, ptr %r2443, align 8
  br label %put.dynic.merge.332

put.dynic.store.ref.321:                          ; preds = %put.dynic.store.dispatch.319
  %r2449 = trunc i64 %r2439 to i32
  %r2450 = shl i64 %r2439, 3
  %r2451 = add nuw nsw i64 %r2370, 16
  %r2452 = add i64 %r2451, %r2450
  %r2453 = load double, ptr %r2443, align 8
  %r2454 = bitcast double %r2453 to i64
  store double %r2361628, ptr %r2443, align 8
  call void @js_string_addref_if_heap_string(double %r2361628) #7
  %r2455 = bitcast double %r2361628 to i64
  %r4586.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated634 to i64
  %r4586.rs4o = call i64 asm "", "=r,0"(i64 %r4586.rs4i) #7
  %r4586 = bitcast i64 %r4586.rs4o to double
  %r4587 = bitcast double %r4586 to i64
  %r4588 = and i64 %r4587, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4588, i32 %r2449, i64 %r2455, i64 %r2454) #7
  %r4584.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated634 to i64
  %r4584.rs4o = call i64 asm "", "=r,0"(i64 %r4584.rs4i) #7
  %r4584 = bitcast i64 %r4584.rs4o to double
  %r4585 = bitcast double %r4584 to i64
  call void @js_write_barrier_slot(i64 %r4585, i64 %r2452, i64 %r2455) #7
  br label %put.dynic.merge.332

put.dynic.trans.gate.322:                         ; preds = %put.dynic.guard.313
  %r2423 = and i1 %r2420, %r2416
  br i1 %r2423, label %put.dynic.trans.probe.323, label %put.dynic.slow.331

put.dynic.trans.probe.323:                        ; preds = %put.dynic.trans.gate.322, %put.dynic.way2.316
  %r2456 = lshr i64 %r2362, 48
  %r2457 = icmp eq i64 %r2456, 32767
  %r2458 = and i64 %r2362, 281474976710655
  %r2459 = icmp ugt i64 %r2458, 1048575
  %r2460 = and i16 %r2394, -16384
  %r2461 = icmp eq i16 %r2460, 0
  %r2462 = and i8 %r2389, 32
  %r2463 = icmp eq i8 %r2462, 0
  %r2464 = and i1 %r2457, %r2459
  %r2465 = and i1 %r2464, %r2461
  %r2466 = and i1 %r2465, %r2463
  br i1 %r2466, label %put.dynic.trans.key.324, label %put.dynic.slow.331

put.dynic.trans.key.324:                          ; preds = %put.dynic.trans.probe.323
  %r2467 = and i64 %r2362, 281474976710655
  %r2468 = add nuw nsw i64 %r2467, 4
  %r2469 = inttoptr i64 %r2468 to ptr
  %r2470 = load i32, ptr %r2469, align 4
  %r2471 = icmp uge i32 %r2470, 6
  %r2472 = icmp ule i32 %r2470, 8
  %r2473 = add nuw nsw i64 %r2467, 20
  %r2474 = inttoptr i64 %r2473 to ptr
  %r2475 = load i8, ptr %r2474, align 1
  %r2476 = sub i8 %r2475, 48
  %r2477 = icmp ult i8 %r2476, 10
  %r2478 = icmp eq i1 %r2477, false
  %r2479 = and i1 %r2471, %r2472
  %r2480 = and i1 %r2479, %r2478
  br i1 %r2480, label %put.dynic.trans.entry.325, label %put.dynic.slow.331

put.dynic.trans.entry.325:                        ; preds = %put.dynic.trans.key.324
  %r2481 = add nuw nsw i64 %r2467, 20
  %r2482 = inttoptr i64 %r2481 to ptr
  %r2483 = load i64, ptr %r2482, align 8
  %r2484 = zext nneg i32 %r2470 to i64
  %r2485 = sub nuw nsw i64 8, %r2484
  %r2486 = shl nuw nsw i64 %r2485, 3
  %r2487 = lshr i64 -1, %r2486
  %r2488 = and i64 %r2483, %r2487
  %r2490 = ptrtoint ptr %r92 to i64
  %r2491 = zext i32 %r2407 to i64
  %r2492 = mul i64 %r2491, -7046029254386353131
  %r2493 = lshr i64 %r2488, 3
  %r2494 = mul i64 %r2493, -4126379630918253789
  %r2495 = xor i64 %r2492, %r2494
  %r2496 = and i64 %r2495, 16383
  %r2497 = shl nuw nsw i64 %r2496, 5
  %r2498 = add i64 %r2490, %r2497
  %r2499 = inttoptr i64 %r2498 to ptr
  %r2500 = load i64, ptr %r2499, align 8
  %r2501 = add i64 %r2498, 8
  %r2502 = inttoptr i64 %r2501 to ptr
  %r2503 = load i64, ptr %r2502, align 8
  %r2504 = add i64 %r2498, 16
  %r2505 = inttoptr i64 %r2504 to ptr
  %r2506 = load i32, ptr %r2505, align 4
  %r2507 = add i64 %r2498, 20
  %r2508 = inttoptr i64 %r2507 to ptr
  %r2509 = load i32, ptr %r2508, align 4
  %r2510 = add i64 %r2498, 24
  %r2511 = inttoptr i64 %r2510 to ptr
  %r2512 = load i32, ptr %r2511, align 4
  %r2513 = lshr i32 %r2512, 24
  %r2514 = and i32 %r2512, 16777215
  %r2515 = add i64 %r2498, 28
  %r2516 = inttoptr i64 %r2515 to ptr
  %r2517 = load i32, ptr %r2516, align 4
  %r2518 = icmp eq i64 %r2500, %r2488
  %r2519 = icmp eq i32 %r2513, %r2470
  %r2520 = icmp eq i32 %r2506, %r2407
  %r2521 = icmp ne i64 %r2503, 0
  %r2522 = add nuw nsw i32 %r2514, 1
  %r2523 = icmp eq i32 %r2517, %r2522
  %r2524 = zext nneg i32 %r2514 to i64
  %r2525 = and i64 %r2368, 281474976710655
  %r2526 = icmp eq i64 %r2374, 32765
  %r2527 = icmp eq i64 %r2525, 0
  %r2528 = and i1 %r2526, %r2527
  %r2529 = select i1 %r2528, i64 9222246136947933185, i64 %r2368
  %r2530 = bitcast i64 %r2529 to double
  %r2531 = and i1 %r2518, %r2519
  %r2532 = and i1 %r2531, %r2520
  %r2533 = and i1 %r2532, %r2521
  %r2534 = and i1 %r2533, %r2523
  br i1 %r2534, label %put.dynic.trans.nk.326, label %put.dynic.slow.331

put.dynic.trans.nk.326:                           ; preds = %put.dynic.trans.entry.325
  %r2535 = inttoptr i64 %r2503 to ptr
  %r2536 = load i32, ptr %r2535, align 4
  %r2537 = icmp eq i32 %r2536, %r2522
  br i1 %r2537, label %put.dynic.trans.dispatch.327, label %put.dynic.slow.331

put.dynic.trans.dispatch.327:                     ; preds = %put.dynic.trans.nk.326
  %r2538 = icmp ult i64 %r2524, 2
  br i1 %r2538, label %put.dynic.trans.inline_ref.328, label %put.dynic.trans.ovf.329

put.dynic.trans.inline_ref.328:                   ; preds = %put.dynic.trans.dispatch.327
  %r2539 = shl nuw nsw i64 %r2524, 3
  %r2540 = add nuw nsw i64 %r2539, 16
  %r2541 = add nuw nsw i64 %r2370, %r2540
  %r2542 = inttoptr i64 %r2541 to ptr
  %r2543 = trunc nuw nsw i64 %r2524 to i32
  %r2544 = load double, ptr %r2542, align 8
  %r2545 = bitcast double %r2544 to i64
  store double %r2530, ptr %r2542, align 8
  call void @js_string_addref_if_heap_string(double %r2530) #7
  %r2546 = bitcast double %r2530 to i64
  %r4581.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated634 to i64
  %r4581.rs4o = call i64 asm "", "=r,0"(i64 %r4581.rs4i) #7
  %r4581 = bitcast i64 %r4581.rs4o to double
  %r4582 = bitcast double %r4581 to i64
  %r4583 = and i64 %r4582, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4583, i32 %r2543, i64 %r2546, i64 %r2545) #7
  %r4579.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated634 to i64
  %r4579.rs4o = call i64 asm "", "=r,0"(i64 %r4579.rs4i) #7
  %r4579 = bitcast i64 %r4579.rs4o to double
  %r4580 = bitcast double %r4579 to i64
  call void @js_write_barrier_slot(i64 %r4580, i64 %r2541, i64 %r2546) #7
  br label %put.dynic.trans.stamp.330

put.dynic.trans.ovf.329:                          ; preds = %put.dynic.trans.dispatch.327
  %r2547 = trunc nuw nsw i64 %r2524 to i32
  %r2548 = call i32 @js_transition_ic_spill_append(double %r2364, i64 %r2412, i32 %r2547, double %r2530) #7
  %r2549 = icmp ne i32 %r2548, 0
  br i1 %r2549, label %put.dynic.trans.stamp.330, label %put.dynic.slow.331

put.dynic.trans.stamp.330:                        ; preds = %put.dynic.trans.ovf.329, %put.dynic.trans.inline_ref.328
  %r4576.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated634 to i64
  %r4576.rs4o = call i64 asm "", "=r,0"(i64 %r4576.rs4i) #7
  %r4576 = bitcast i64 %r4576.rs4o to double
  %r4577 = bitcast double %r4576 to i64
  %r4578 = and i64 %r4577, 281474976710655
  %r2550 = add nuw nsw i64 %r4578, 4
  %r2551 = inttoptr i64 %r2550 to ptr
  store i32 %r2509, ptr %r2551, align 4
  br label %put.dynic.merge.332

put.dynic.slow.331:                               ; preds = %put.dynic.trans.ovf.329, %put.dynic.trans.nk.326, %put.dynic.trans.entry.325, %put.dynic.trans.key.324, %put.dynic.trans.probe.323, %put.dynic.trans.gate.322, %put.dynic.store.validate.318, %shadow.root.barrier.done.312
  %statepoint_token636 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_large_string_emitters_ts__8, double %r2364, double %r2363, double %r2361628, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.5.relocated629, ptr addrspace(1) %r8.0.relocated630, ptr addrspace(1) %rs4gc.s15.relocated631, ptr addrspace(1) %rs4gc.s13.relocated632, ptr addrspace(1) %rs4gc.s9.relocated633, ptr addrspace(1) %rs4gc.s18.relocated634) ]
  %r2552637 = call double @llvm.experimental.gc.result.f64(token %statepoint_token636)
  %r497.5.relocated638 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token636, i32 0, i32 0) ; (%r497.5.relocated629, %r497.5.relocated629)
  %r8.0.relocated639 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token636, i32 1, i32 1) ; (%r8.0.relocated630, %r8.0.relocated630)
  %rs4gc.s15.relocated640 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token636, i32 2, i32 2) ; (%rs4gc.s15.relocated631, %rs4gc.s15.relocated631)
  %rs4gc.s13.relocated641 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token636, i32 3, i32 3) ; (%rs4gc.s13.relocated632, %rs4gc.s13.relocated632)
  %rs4gc.s9.relocated642 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token636, i32 4, i32 4) ; (%rs4gc.s9.relocated633, %rs4gc.s9.relocated633)
  %rs4gc.s18.relocated643 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token636, i32 5, i32 5) ; (%rs4gc.s18.relocated634, %rs4gc.s18.relocated634)
  br label %put.dynic.merge.332

put.dynic.merge.332:                              ; preds = %put.dynic.slow.331, %put.dynic.trans.stamp.330, %put.dynic.store.ref.321, %put.dynic.store.scalar.320
  %.01488 = phi ptr addrspace(1) [ %r497.5.relocated638, %put.dynic.slow.331 ], [ %r497.5.relocated629, %put.dynic.store.scalar.320 ], [ %r497.5.relocated629, %put.dynic.store.ref.321 ], [ %r497.5.relocated629, %put.dynic.trans.stamp.330 ]
  %.171477 = phi ptr addrspace(1) [ %rs4gc.s18.relocated643, %put.dynic.slow.331 ], [ %rs4gc.s18.relocated634, %put.dynic.store.scalar.320 ], [ %rs4gc.s18.relocated634, %put.dynic.store.ref.321 ], [ %rs4gc.s18.relocated634, %put.dynic.trans.stamp.330 ]
  %.181444 = phi ptr addrspace(1) [ %rs4gc.s15.relocated640, %put.dynic.slow.331 ], [ %rs4gc.s15.relocated631, %put.dynic.store.scalar.320 ], [ %rs4gc.s15.relocated631, %put.dynic.store.ref.321 ], [ %rs4gc.s15.relocated631, %put.dynic.trans.stamp.330 ]
  %.211386 = phi ptr addrspace(1) [ %rs4gc.s13.relocated641, %put.dynic.slow.331 ], [ %rs4gc.s13.relocated632, %put.dynic.store.scalar.320 ], [ %rs4gc.s13.relocated632, %put.dynic.store.ref.321 ], [ %rs4gc.s13.relocated632, %put.dynic.trans.stamp.330 ]
  %.181328 = phi ptr addrspace(1) [ %r8.0.relocated639, %put.dynic.slow.331 ], [ %r8.0.relocated630, %put.dynic.store.scalar.320 ], [ %r8.0.relocated630, %put.dynic.store.ref.321 ], [ %r8.0.relocated630, %put.dynic.trans.stamp.330 ]
  %.21 = phi ptr addrspace(1) [ %rs4gc.s9.relocated642, %put.dynic.slow.331 ], [ %rs4gc.s9.relocated633, %put.dynic.store.scalar.320 ], [ %rs4gc.s9.relocated633, %put.dynic.store.ref.321 ], [ %rs4gc.s9.relocated633, %put.dynic.trans.stamp.330 ]
  %r2553 = phi double [ %r2361628, %put.dynic.store.scalar.320 ], [ %r2361628, %put.dynic.store.ref.321 ], [ %r2530, %put.dynic.trans.stamp.330 ], [ %r2552637, %put.dynic.slow.331 ]
  %r2554.rs4i = ptrtoint ptr addrspace(1) %.171477 to i64
  %r2554.rs4o = call i64 asm "", "=r,0"(i64 %r2554.rs4i) #7
  %r2554 = bitcast i64 %r2554.rs4o to double
  %r2555.rs4i = ptrtoint ptr addrspace(1) %.211386 to i64
  %r2555.rs4o = call i64 asm "", "=r,0"(i64 %r2555.rs4i) #7
  %r2555 = bitcast i64 %r2555.rs4o to double
  br label %ternary.then.333

ternary.then.333:                                 ; preds = %put.dynic.merge.332
  br label %ternary.merge.335

ternary.merge.335:                                ; preds = %ternary.then.333
  %statepoint_token644 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r2554, double %r2555, double 0.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.181328, ptr addrspace(1) %.181444, ptr addrspace(1) %.211386, ptr addrspace(1) %.21, ptr addrspace(1) %.171477, ptr addrspace(1) %.01488) ]
  %r2570645 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token644)
  %r8.0.relocated646 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token644, i32 0, i32 0) ; (%.181328, %.181328)
  %rs4gc.s15.relocated647 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token644, i32 1, i32 1) ; (%.181444, %.181444)
  %rs4gc.s13.relocated648 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token644, i32 2, i32 2) ; (%.211386, %.211386)
  %rs4gc.s9.relocated649 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token644, i32 3, i32 3) ; (%.21, %.21)
  %rs4gc.s18.relocated650 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token644, i32 4, i32 4) ; (%.171477, %.171477)
  %r497.5.relocated651 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token644, i32 5, i32 5) ; (%.01488, %.01488)
  %r2571 = bitcast i64 %r2570645 to double
  %r2572 = bitcast i64 %r2570645 to double
  %r2573.rs4i = ptrtoint ptr addrspace(1) %r497.5.relocated651 to i64
  %r2573.rs4o = call i64 asm "", "=r,0"(i64 %r2573.rs4i) #7
  %r2573 = bitcast i64 %r2573.rs4o to double
  %r2574 = bitcast double %r2573 to i64
  %r2575 = and i64 %r2574, 281474976710655
  %r2576 = sub nsw i64 %r2575, 8
  %r2577 = inttoptr i64 %r2576 to ptr
  %r2578 = load i8, ptr %r2577, align 1
  %r2579 = icmp ne i8 %r2578, 1
  %r2580 = sub nsw i64 %r2575, 7
  %r2581 = inttoptr i64 %r2580 to ptr
  %r2582 = load i8, ptr %r2581, align 1
  %r2583 = and i8 %r2582, -128
  %r2584 = icmp ne i8 %r2583, 0
  %r2585 = or i1 %r2579, %r2584
  br i1 %r2584, label %apush.fwd.336, label %apush.elements.337

apush.fwd.336:                                    ; preds = %apush.elements.check.338, %ternary.merge.335
  %statepoint_token652 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2575, double %r2572, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated650, ptr addrspace(1) %r8.0.relocated646, ptr addrspace(1) %rs4gc.s15.relocated647, ptr addrspace(1) %rs4gc.s13.relocated648, ptr addrspace(1) %rs4gc.s9.relocated649) ]
  %r2612653 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token652)
  %rs4gc.s18.relocated654 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token652, i32 0, i32 0) ; (%rs4gc.s18.relocated650, %rs4gc.s18.relocated650)
  %r8.0.relocated655 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token652, i32 1, i32 1) ; (%r8.0.relocated646, %r8.0.relocated646)
  %rs4gc.s15.relocated656 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token652, i32 2, i32 2) ; (%rs4gc.s15.relocated647, %rs4gc.s15.relocated647)
  %rs4gc.s13.relocated657 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token652, i32 3, i32 3) ; (%rs4gc.s13.relocated648, %rs4gc.s13.relocated648)
  %rs4gc.s9.relocated658 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token652, i32 4, i32 4) ; (%rs4gc.s9.relocated649, %rs4gc.s9.relocated649)
  %r2613 = or i64 %r2612653, 9222527611924643840
  %r2614 = bitcast i64 %r2613 to double
  %rs4gc.b45 = bitcast double %r2614 to i64
  %rs4gc.s45 = inttoptr i64 %rs4gc.b45 to ptr addrspace(1)
  br label %apush.merge.342

apush.elements.337:                               ; preds = %ternary.merge.335
  %r2587 = add nuw nsw i64 %r2575, 8
  %r2588 = inttoptr i64 %r2587 to ptr
  %r2589 = load i64, ptr %r2588, align 8
  %r2590 = icmp ne i64 %r2589, 0
  %r2591 = icmp eq i8 %r2578, 2
  %r2592 = and i1 %r2591, %r2590
  %r2593 = select i1 %r2592, i64 %r2589, i64 %r2575
  %r2594 = inttoptr i64 %r2593 to ptr
  %r2595 = getelementptr i64, ptr %r2594, i64 12
  %r2596 = load i64, ptr %r2595, align 8
  %r2597 = icmp ne i64 %r2596, 0
  %r2598 = and i1 %r2592, %r2597
  %r2599 = select i1 %r2598, i64 %r2596, i64 %r2575
  %r2586 = icmp eq i8 %r2578, 1
  br i1 %r2586, label %apush.nofwd.339, label %apush.elements.check.338

apush.elements.check.338:                         ; preds = %apush.elements.337
  %r2600 = icmp ne i64 %r2599, 0
  %r2601 = sub i64 %r2599, 8
  %r2602 = inttoptr i64 %r2601 to ptr
  %r2603 = load i8, ptr %r2602, align 1
  %r2604 = icmp eq i8 %r2603, 1
  %r2605 = sub i64 %r2599, 7
  %r2606 = inttoptr i64 %r2605 to ptr
  %r2607 = load i8, ptr %r2606, align 1
  %r2608 = and i8 %r2607, -128
  %r2609 = icmp eq i8 %r2608, 0
  %r2610 = and i1 %r2600, %r2604
  %r2611 = and i1 %r2610, %r2609
  br i1 %r2611, label %apush.nofwd.339, label %apush.fwd.336

apush.nofwd.339:                                  ; preds = %apush.elements.check.338, %apush.elements.337
  %r2615 = phi i64 [ %r2575, %apush.elements.337 ], [ %r2599, %apush.elements.check.338 ]
  %r2616 = sub i64 %r2615, 6
  %r2617 = inttoptr i64 %r2616 to ptr
  %r2618 = load i16, ptr %r2617, align 2
  %r2619 = and i16 %r2618, 1031
  %r2620 = icmp eq i16 %r2619, 0
  %r2621 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2622 = icmp eq i8 %r2621, 0
  %r2623 = and i1 %r2620, %r2622
  %r2624 = icmp ult i64 %r2615, 4096
  %r2625 = inttoptr i64 %r2615 to ptr
  %r2626 = select i1 %r2624, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r2625
  %r2627 = load i32, ptr %r2626, align 4
  %r2628 = add i64 %r2615, 4
  %r2629 = inttoptr i64 %r2628 to ptr
  %r2630 = load i32, ptr %r2629, align 4
  %r2631 = icmp ult i32 %r2627, %r2630
  %r2632 = and i1 %r2631, %r2623
  br i1 %r2632, label %apush.inbounds.340, label %apush.realloc.341

apush.inbounds.340:                               ; preds = %apush.nofwd.339
  %r2633 = icmp ult i64 %r2615, 4096
  %r2634 = inttoptr i64 %r2615 to ptr
  %r2635 = select i1 %r2633, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r2634
  %r2636 = load i32, ptr %r2635, align 4
  %r2637 = zext i32 %r2636 to i64
  %r2638 = shl nuw nsw i64 %r2637, 3
  %r2639 = add nuw nsw i64 %r2638, 8
  %r2640 = add i64 %r2615, %r2639
  %r2641 = inttoptr i64 %r2640 to ptr
  store double %r2572, ptr %r2641, align 8
  %r2642 = lshr i64 %r2570645, 48
  %r2643 = icmp eq i64 %r2642, 32765
  %r2644 = and i16 %r2618, -1920
  %r2645 = icmp eq i16 %r2644, -24576
  %r2646 = and i1 %r2643, %r2645
  br i1 %r2646, label %apush.pointer_layout.done.344, label %apush.pointer_layout.bookkeeping.343

apush.realloc.341:                                ; preds = %apush.nofwd.339
  %statepoint_token659 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2575, double %r2572, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s18.relocated650, ptr addrspace(1) %r8.0.relocated646, ptr addrspace(1) %rs4gc.s15.relocated647, ptr addrspace(1) %rs4gc.s13.relocated648, ptr addrspace(1) %rs4gc.s9.relocated649) ]
  %r2657660 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token659)
  %rs4gc.s18.relocated661 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token659, i32 0, i32 0) ; (%rs4gc.s18.relocated650, %rs4gc.s18.relocated650)
  %r8.0.relocated662 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token659, i32 1, i32 1) ; (%r8.0.relocated646, %r8.0.relocated646)
  %rs4gc.s15.relocated663 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token659, i32 2, i32 2) ; (%rs4gc.s15.relocated647, %rs4gc.s15.relocated647)
  %rs4gc.s13.relocated664 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token659, i32 3, i32 3) ; (%rs4gc.s13.relocated648, %rs4gc.s13.relocated648)
  %rs4gc.s9.relocated665 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token659, i32 4, i32 4) ; (%rs4gc.s9.relocated649, %rs4gc.s9.relocated649)
  %r2658 = or i64 %r2657660, 9222527611924643840
  %r2659 = bitcast i64 %r2658 to double
  %rs4gc.b46 = bitcast double %r2659 to i64
  %rs4gc.s46 = inttoptr i64 %rs4gc.b46 to ptr addrspace(1)
  br label %apush.merge.342

apush.merge.342:                                  ; preds = %apush.barrier.done.346, %apush.realloc.341, %apush.fwd.336
  %.181478 = phi ptr addrspace(1) [ %rs4gc.s18.relocated654, %apush.fwd.336 ], [ %rs4gc.s18.relocated650, %apush.barrier.done.346 ], [ %rs4gc.s18.relocated661, %apush.realloc.341 ]
  %.191445 = phi ptr addrspace(1) [ %rs4gc.s15.relocated656, %apush.fwd.336 ], [ %rs4gc.s15.relocated647, %apush.barrier.done.346 ], [ %rs4gc.s15.relocated663, %apush.realloc.341 ]
  %.221387 = phi ptr addrspace(1) [ %rs4gc.s13.relocated657, %apush.fwd.336 ], [ %rs4gc.s13.relocated648, %apush.barrier.done.346 ], [ %rs4gc.s13.relocated664, %apush.realloc.341 ]
  %.191329 = phi ptr addrspace(1) [ %r8.0.relocated655, %apush.fwd.336 ], [ %r8.0.relocated646, %apush.barrier.done.346 ], [ %r8.0.relocated662, %apush.realloc.341 ]
  %.22 = phi ptr addrspace(1) [ %rs4gc.s9.relocated658, %apush.fwd.336 ], [ %rs4gc.s9.relocated649, %apush.barrier.done.346 ], [ %rs4gc.s9.relocated665, %apush.realloc.341 ]
  %r497.6 = phi ptr addrspace(1) [ %rs4gc.s45, %apush.fwd.336 ], [ %r497.5.relocated651, %apush.barrier.done.346 ], [ %rs4gc.s46, %apush.realloc.341 ]
  %r2660.rs4i = ptrtoint ptr addrspace(1) %.191445 to i64
  %r2660.rs4o = call i64 asm "", "=r,0"(i64 %r2660.rs4i) #7
  %r2660 = bitcast i64 %r2660.rs4o to double
  %r2661 = bitcast double %r2660 to i64
  %rs4gc.s47 = inttoptr i64 %r2661 to ptr addrspace(1)
  %r2662.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s47 to i64
  %r2662 = call i64 asm "", "=r,0"(i64 %r2662.rs4i) #7
  %r2663 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2664 = icmp ne i32 %r2663, 0
  br i1 %r2664, label %shadow.root.barrier.347, label %shadow.root.barrier.done.348

apush.pointer_layout.bookkeeping.343:             ; preds = %apush.inbounds.340
  call void @js_string_addref_if_heap_string(double %r2572) #7
  call void @js_gc_note_slot_layout(i64 %r2615, i32 %r2636, i64 %r2570645) #7
  call void @js_array_note_numeric_write(i64 %r2615, i64 %r2570645) #7
  br label %apush.pointer_layout.done.344

apush.pointer_layout.done.344:                    ; preds = %apush.pointer_layout.bookkeeping.343, %apush.inbounds.340
  %r2647 = sub i64 %r2615, 7
  %r2648 = inttoptr i64 %r2647 to ptr
  %r2649 = load i8, ptr %r2648, align 1
  %r2650 = and i8 %r2649, 32
  %r2651 = icmp ne i8 %r2650, 0
  %r2652 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2653 = icmp ne i32 %r2652, 0
  %r2654 = or i1 %r2651, %r2653
  br i1 %r2654, label %apush.barrier.345, label %apush.barrier.done.346

apush.barrier.345:                                ; preds = %apush.pointer_layout.done.344
  call void @js_write_barrier_slot_validated_parent(i64 %r2615, i64 %r2640, i64 %r2570645) #7
  br label %apush.barrier.done.346

apush.barrier.done.346:                           ; preds = %apush.barrier.345, %apush.pointer_layout.done.344
  %r2655 = add i32 %r2636, 1
  %r2656 = inttoptr i64 %r2615 to ptr
  store i32 %r2655, ptr %r2656, align 4
  br label %apush.merge.342

shadow.root.barrier.347:                          ; preds = %apush.merge.342
  call void @js_write_barrier_root_nanbox(i64 %r2662) #7
  br label %shadow.root.barrier.done.348

shadow.root.barrier.done.348:                     ; preds = %shadow.root.barrier.347, %apush.merge.342
  %r2665.rs4i = ptrtoint ptr addrspace(1) %.191329 to i64
  %r2665.rs4o = call i64 asm "", "=r,0"(i64 %r2665.rs4i) #7
  %r2665 = bitcast i64 %r2665.rs4o to double
  %r2666 = load double, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  %statepoint_token666 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r2665, double %r2666, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.191329, ptr addrspace(1) %.191445, ptr addrspace(1) %.221387, ptr addrspace(1) %.22, ptr addrspace(1) %r497.6, ptr addrspace(1) %.181478, ptr addrspace(1) %rs4gc.s47) ]
  %r2667667 = call double @llvm.experimental.gc.result.f64(token %statepoint_token666)
  %r8.0.relocated668 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 0, i32 0) ; (%.191329, %.191329)
  %rs4gc.s15.relocated669 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 1, i32 1) ; (%.191445, %.191445)
  %rs4gc.s13.relocated670 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 2, i32 2) ; (%.221387, %.221387)
  %rs4gc.s9.relocated671 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 3, i32 3) ; (%.22, %.22)
  %r497.6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 4, i32 4) ; (%r497.6, %r497.6)
  %rs4gc.s18.relocated672 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 5, i32 5) ; (%.181478, %.181478)
  %rs4gc.s47.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token666, i32 6, i32 6) ; (%rs4gc.s47, %rs4gc.s47)
  %statepoint_token673 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r2667667, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated668, ptr addrspace(1) %rs4gc.s15.relocated669, ptr addrspace(1) %rs4gc.s13.relocated670, ptr addrspace(1) %rs4gc.s9.relocated671, ptr addrspace(1) %r497.6.relocated, ptr addrspace(1) %rs4gc.s18.relocated672, ptr addrspace(1) %rs4gc.s47.relocated) ]
  %r2668674 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token673)
  %r8.0.relocated675 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token673, i32 0, i32 0) ; (%r8.0.relocated668, %r8.0.relocated668)
  %rs4gc.s15.relocated676 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token673, i32 1, i32 1) ; (%rs4gc.s15.relocated669, %rs4gc.s15.relocated669)
  %rs4gc.s13.relocated677 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token673, i32 2, i32 2) ; (%rs4gc.s13.relocated670, %rs4gc.s13.relocated670)
  %rs4gc.s9.relocated678 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token673, i32 3, i32 3) ; (%rs4gc.s9.relocated671, %rs4gc.s9.relocated671)
  %r497.6.relocated679 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token673, i32 4, i32 4) ; (%r497.6.relocated, %r497.6.relocated)
  %rs4gc.s18.relocated680 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token673, i32 5, i32 5) ; (%rs4gc.s18.relocated672, %rs4gc.s18.relocated672)
  %rs4gc.s47.relocated681 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token673, i32 6, i32 6) ; (%rs4gc.s47.relocated, %rs4gc.s47.relocated)
  %statepoint_token682 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r2668674, double 7.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated675, ptr addrspace(1) %rs4gc.s15.relocated676, ptr addrspace(1) %rs4gc.s13.relocated677, ptr addrspace(1) %rs4gc.s9.relocated678, ptr addrspace(1) %r497.6.relocated679, ptr addrspace(1) %rs4gc.s18.relocated680, ptr addrspace(1) %rs4gc.s47.relocated681) ]
  %r2669683 = call double @llvm.experimental.gc.result.f64(token %statepoint_token682)
  %r8.0.relocated684 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token682, i32 0, i32 0) ; (%r8.0.relocated675, %r8.0.relocated675)
  %rs4gc.s15.relocated685 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token682, i32 1, i32 1) ; (%rs4gc.s15.relocated676, %rs4gc.s15.relocated676)
  %rs4gc.s13.relocated686 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token682, i32 2, i32 2) ; (%rs4gc.s13.relocated677, %rs4gc.s13.relocated677)
  %rs4gc.s9.relocated687 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token682, i32 3, i32 3) ; (%rs4gc.s9.relocated678, %rs4gc.s9.relocated678)
  %r497.6.relocated688 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token682, i32 4, i32 4) ; (%r497.6.relocated679, %r497.6.relocated679)
  %rs4gc.s18.relocated689 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token682, i32 5, i32 5) ; (%rs4gc.s18.relocated680, %rs4gc.s18.relocated680)
  %rs4gc.s47.relocated690 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token682, i32 6, i32 6) ; (%rs4gc.s47.relocated681, %rs4gc.s47.relocated681)
  %r2670.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s47.relocated690 to i64
  %r2670 = call i64 asm "", "=r,0"(i64 %r2670.rs4i) #7
  %r2671 = bitcast i64 %r2670 to double
  %r2672.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated689 to i64
  %r2672.rs4o = call i64 asm "", "=r,0"(i64 %r2672.rs4i) #7
  %r2672 = bitcast i64 %r2672.rs4o to double
  %r2673 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__9, align 8
  %r2674 = icmp ne ptr %r2673, null
  %r2675 = select i1 %r2674, ptr %r2673, ptr @perry_ic_test_json_large_string_emitters_ts__9
  %r2676 = bitcast double %r2669683 to i64
  %r2677 = bitcast double %r2672 to i64
  %r2678 = and i64 %r2677, 281474976710655
  %r2679 = lshr i64 %r2677, 48
  %r2680 = icmp eq i64 %r2679, 32765
  %r2681 = icmp ugt i64 %r2678, 1048575
  %r2682 = lshr i64 %r2676, 48
  %r2683 = icmp ne i64 %r2682, 32765
  %r2684 = icmp ne i64 %r2682, 32767
  %r2685 = icmp ne i64 %r2682, 32762
  %r2686 = and i1 %r2683, %r2684
  %r2687 = and i1 %r2686, %r2685
  %r2688 = icmp ne i64 %r2670, 0
  %r2689 = and i1 %r2680, %r2681
  %r2690 = and i1 %r2689, %r2688
  br i1 %r2690, label %put.dynic.guard.349, label %put.dynic.slow.367

put.dynic.guard.349:                              ; preds = %shadow.root.barrier.done.348
  %r2691 = sub nuw nsw i64 %r2678, 8
  %r2692 = inttoptr i64 %r2691 to ptr
  %r2693 = load i8, ptr %r2692, align 1
  %r2694 = icmp eq i8 %r2693, 2
  %r2695 = sub nuw nsw i64 %r2678, 7
  %r2696 = inttoptr i64 %r2695 to ptr
  %r2697 = load i8, ptr %r2696, align 1
  %r2698 = and i8 %r2697, -128
  %r2699 = icmp eq i8 %r2698, 0
  %r2700 = sub nuw nsw i64 %r2678, 6
  %r2701 = inttoptr i64 %r2700 to ptr
  %r2702 = load i16, ptr %r2701, align 2
  %r2703 = and i16 %r2702, 6535
  %r2704 = icmp eq i16 %r2703, 0
  %r2705 = add nuw nsw i64 %r2678, 0
  %r2706 = inttoptr i64 %r2705 to ptr
  %r2707 = load i32, ptr %r2706, align 4
  %r2708 = icmp ne i32 %r2707, 0
  %r2709 = icmp ne i32 %r2707, -2
  %r2710 = and i16 %r2702, 512
  %r2711 = icmp ne i16 %r2710, 0
  %r2712 = or i1 %r2708, %r2711
  %r2713 = add nuw nsw i64 %r2678, 4
  %r2714 = inttoptr i64 %r2713 to ptr
  %r2715 = load i32, ptr %r2714, align 4
  %r2716 = add i32 %r2715, -2147483648
  %r2717 = icmp ult i32 %r2716, 1073741824
  %r2718 = zext i32 %r2715 to i64
  %r2719 = or i64 %r2718, 4611686018427387904
  %r2720 = select i1 %r2717, i64 %r2719, i64 0
  %r2721 = getelementptr i64, ptr %r2675, i64 0
  %r2722 = load i64, ptr %r2721, align 8
  %r2723 = icmp eq i64 %r2720, %r2722
  %r2724 = icmp ne i64 %r2720, 0
  %r2725 = and i1 %r2694, %r2699
  %r2726 = and i1 %r2725, %r2704
  %r2727 = and i1 %r2726, %r2712
  %r2728 = and i1 %r2727, %r2709
  %r2729 = and i1 %r2723, %r2724
  %r2730 = and i1 %r2728, %r2729
  br i1 %r2730, label %put.dynic.ways.350, label %put.dynic.trans.gate.358

put.dynic.ways.350:                               ; preds = %put.dynic.guard.349
  %r2732 = getelementptr i64, ptr %r2673, i64 1
  %r2733 = load i64, ptr %r2732, align 8
  %r2734 = getelementptr i64, ptr %r2673, i64 2
  %r2735 = load i64, ptr %r2734, align 8
  %r2736 = icmp eq i64 %r2670, %r2733
  br i1 %r2736, label %put.dynic.store.353, label %put.dynic.way1.351

put.dynic.way1.351:                               ; preds = %put.dynic.ways.350
  %r2737 = getelementptr i64, ptr %r2673, i64 3
  %r2738 = load i64, ptr %r2737, align 8
  %r2739 = getelementptr i64, ptr %r2673, i64 4
  %r2740 = load i64, ptr %r2739, align 8
  %r2741 = icmp eq i64 %r2670, %r2738
  br i1 %r2741, label %put.dynic.store.353, label %put.dynic.way2.352

put.dynic.way2.352:                               ; preds = %put.dynic.way1.351
  %r2742 = getelementptr i64, ptr %r2673, i64 5
  %r2743 = load i64, ptr %r2742, align 8
  %r2744 = getelementptr i64, ptr %r2673, i64 6
  %r2745 = load i64, ptr %r2744, align 8
  %r2746 = icmp eq i64 %r2670, %r2743
  br i1 %r2746, label %put.dynic.store.353, label %put.dynic.trans.probe.359

put.dynic.store.353:                              ; preds = %put.dynic.way2.352, %put.dynic.way1.351, %put.dynic.ways.350
  %r2747 = phi i64 [ %r2735, %put.dynic.ways.350 ], [ %r2740, %put.dynic.way1.351 ], [ %r2745, %put.dynic.way2.352 ]
  %r2748 = shl i64 %r2747, 3
  %r2749 = add i64 %r2748, 16
  %r2750 = inttoptr i64 %r2678 to ptr
  %r2751 = getelementptr inbounds i8, ptr %r2750, i64 %r2749
  %r2752 = and i16 %r2702, 1024
  %r2753 = icmp ne i16 %r2752, 0
  br i1 %r2753, label %put.dynic.store.validate.354, label %put.dynic.store.dispatch.355

put.dynic.store.validate.354:                     ; preds = %put.dynic.store.353
  %r2754 = load double, ptr %r2751, align 8
  %r2755 = bitcast double %r2754 to i64
  %r2756 = icmp eq i64 %r2755, 9222246136947933200
  br i1 %r2756, label %put.dynic.slow.367, label %put.dynic.store.dispatch.355

put.dynic.store.dispatch.355:                     ; preds = %put.dynic.store.validate.354, %put.dynic.store.353
  br i1 %r2687, label %put.dynic.store.scalar.356, label %put.dynic.store.ref.357

put.dynic.store.scalar.356:                       ; preds = %put.dynic.store.dispatch.355
  store double %r2669683, ptr %r2751, align 8
  br label %put.dynic.merge.368

put.dynic.store.ref.357:                          ; preds = %put.dynic.store.dispatch.355
  %r2757 = trunc i64 %r2747 to i32
  %r2758 = shl i64 %r2747, 3
  %r2759 = add nuw nsw i64 %r2678, 16
  %r2760 = add i64 %r2759, %r2758
  %r2761 = load double, ptr %r2751, align 8
  %r2762 = bitcast double %r2761 to i64
  store double %r2669683, ptr %r2751, align 8
  call void @js_string_addref_if_heap_string(double %r2669683) #7
  %r2763 = bitcast double %r2669683 to i64
  %r4573.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated689 to i64
  %r4573.rs4o = call i64 asm "", "=r,0"(i64 %r4573.rs4i) #7
  %r4573 = bitcast i64 %r4573.rs4o to double
  %r4574 = bitcast double %r4573 to i64
  %r4575 = and i64 %r4574, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4575, i32 %r2757, i64 %r2763, i64 %r2762) #7
  %r4571.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated689 to i64
  %r4571.rs4o = call i64 asm "", "=r,0"(i64 %r4571.rs4i) #7
  %r4571 = bitcast i64 %r4571.rs4o to double
  %r4572 = bitcast double %r4571 to i64
  call void @js_write_barrier_slot(i64 %r4572, i64 %r2760, i64 %r2763) #7
  br label %put.dynic.merge.368

put.dynic.trans.gate.358:                         ; preds = %put.dynic.guard.349
  %r2731 = and i1 %r2728, %r2724
  br i1 %r2731, label %put.dynic.trans.probe.359, label %put.dynic.slow.367

put.dynic.trans.probe.359:                        ; preds = %put.dynic.trans.gate.358, %put.dynic.way2.352
  %r2764 = lshr i64 %r2670, 48
  %r2765 = icmp eq i64 %r2764, 32767
  %r2766 = and i64 %r2670, 281474976710655
  %r2767 = icmp ugt i64 %r2766, 1048575
  %r2768 = and i16 %r2702, -16384
  %r2769 = icmp eq i16 %r2768, 0
  %r2770 = and i8 %r2697, 32
  %r2771 = icmp eq i8 %r2770, 0
  %r2772 = and i1 %r2765, %r2767
  %r2773 = and i1 %r2772, %r2769
  %r2774 = and i1 %r2773, %r2771
  br i1 %r2774, label %put.dynic.trans.key.360, label %put.dynic.slow.367

put.dynic.trans.key.360:                          ; preds = %put.dynic.trans.probe.359
  %r2775 = and i64 %r2670, 281474976710655
  %r2776 = add nuw nsw i64 %r2775, 4
  %r2777 = inttoptr i64 %r2776 to ptr
  %r2778 = load i32, ptr %r2777, align 4
  %r2779 = icmp uge i32 %r2778, 6
  %r2780 = icmp ule i32 %r2778, 8
  %r2781 = add nuw nsw i64 %r2775, 20
  %r2782 = inttoptr i64 %r2781 to ptr
  %r2783 = load i8, ptr %r2782, align 1
  %r2784 = sub i8 %r2783, 48
  %r2785 = icmp ult i8 %r2784, 10
  %r2786 = icmp eq i1 %r2785, false
  %r2787 = and i1 %r2779, %r2780
  %r2788 = and i1 %r2787, %r2786
  br i1 %r2788, label %put.dynic.trans.entry.361, label %put.dynic.slow.367

put.dynic.trans.entry.361:                        ; preds = %put.dynic.trans.key.360
  %r2789 = add nuw nsw i64 %r2775, 20
  %r2790 = inttoptr i64 %r2789 to ptr
  %r2791 = load i64, ptr %r2790, align 8
  %r2792 = zext nneg i32 %r2778 to i64
  %r2793 = sub nuw nsw i64 8, %r2792
  %r2794 = shl nuw nsw i64 %r2793, 3
  %r2795 = lshr i64 -1, %r2794
  %r2796 = and i64 %r2791, %r2795
  %r2798 = ptrtoint ptr %r92 to i64
  %r2799 = zext i32 %r2715 to i64
  %r2800 = mul i64 %r2799, -7046029254386353131
  %r2801 = lshr i64 %r2796, 3
  %r2802 = mul i64 %r2801, -4126379630918253789
  %r2803 = xor i64 %r2800, %r2802
  %r2804 = and i64 %r2803, 16383
  %r2805 = shl nuw nsw i64 %r2804, 5
  %r2806 = add i64 %r2798, %r2805
  %r2807 = inttoptr i64 %r2806 to ptr
  %r2808 = load i64, ptr %r2807, align 8
  %r2809 = add i64 %r2806, 8
  %r2810 = inttoptr i64 %r2809 to ptr
  %r2811 = load i64, ptr %r2810, align 8
  %r2812 = add i64 %r2806, 16
  %r2813 = inttoptr i64 %r2812 to ptr
  %r2814 = load i32, ptr %r2813, align 4
  %r2815 = add i64 %r2806, 20
  %r2816 = inttoptr i64 %r2815 to ptr
  %r2817 = load i32, ptr %r2816, align 4
  %r2818 = add i64 %r2806, 24
  %r2819 = inttoptr i64 %r2818 to ptr
  %r2820 = load i32, ptr %r2819, align 4
  %r2821 = lshr i32 %r2820, 24
  %r2822 = and i32 %r2820, 16777215
  %r2823 = add i64 %r2806, 28
  %r2824 = inttoptr i64 %r2823 to ptr
  %r2825 = load i32, ptr %r2824, align 4
  %r2826 = icmp eq i64 %r2808, %r2796
  %r2827 = icmp eq i32 %r2821, %r2778
  %r2828 = icmp eq i32 %r2814, %r2715
  %r2829 = icmp ne i64 %r2811, 0
  %r2830 = add nuw nsw i32 %r2822, 1
  %r2831 = icmp eq i32 %r2825, %r2830
  %r2832 = zext nneg i32 %r2822 to i64
  %r2833 = and i64 %r2676, 281474976710655
  %r2834 = icmp eq i64 %r2682, 32765
  %r2835 = icmp eq i64 %r2833, 0
  %r2836 = and i1 %r2834, %r2835
  %r2837 = select i1 %r2836, i64 9222246136947933185, i64 %r2676
  %r2838 = bitcast i64 %r2837 to double
  %r2839 = and i1 %r2826, %r2827
  %r2840 = and i1 %r2839, %r2828
  %r2841 = and i1 %r2840, %r2829
  %r2842 = and i1 %r2841, %r2831
  br i1 %r2842, label %put.dynic.trans.nk.362, label %put.dynic.slow.367

put.dynic.trans.nk.362:                           ; preds = %put.dynic.trans.entry.361
  %r2843 = inttoptr i64 %r2811 to ptr
  %r2844 = load i32, ptr %r2843, align 4
  %r2845 = icmp eq i32 %r2844, %r2830
  br i1 %r2845, label %put.dynic.trans.dispatch.363, label %put.dynic.slow.367

put.dynic.trans.dispatch.363:                     ; preds = %put.dynic.trans.nk.362
  %r2846 = icmp ult i64 %r2832, 2
  br i1 %r2846, label %put.dynic.trans.inline_ref.364, label %put.dynic.trans.ovf.365

put.dynic.trans.inline_ref.364:                   ; preds = %put.dynic.trans.dispatch.363
  %r2847 = shl nuw nsw i64 %r2832, 3
  %r2848 = add nuw nsw i64 %r2847, 16
  %r2849 = add nuw nsw i64 %r2678, %r2848
  %r2850 = inttoptr i64 %r2849 to ptr
  %r2851 = trunc nuw nsw i64 %r2832 to i32
  %r2852 = load double, ptr %r2850, align 8
  %r2853 = bitcast double %r2852 to i64
  store double %r2838, ptr %r2850, align 8
  call void @js_string_addref_if_heap_string(double %r2838) #7
  %r2854 = bitcast double %r2838 to i64
  %r4568.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated689 to i64
  %r4568.rs4o = call i64 asm "", "=r,0"(i64 %r4568.rs4i) #7
  %r4568 = bitcast i64 %r4568.rs4o to double
  %r4569 = bitcast double %r4568 to i64
  %r4570 = and i64 %r4569, 281474976710655
  call void @js_gc_note_slot_layout_aware(i64 %r4570, i32 %r2851, i64 %r2854, i64 %r2853) #7
  %r4566.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated689 to i64
  %r4566.rs4o = call i64 asm "", "=r,0"(i64 %r4566.rs4i) #7
  %r4566 = bitcast i64 %r4566.rs4o to double
  %r4567 = bitcast double %r4566 to i64
  call void @js_write_barrier_slot(i64 %r4567, i64 %r2849, i64 %r2854) #7
  br label %put.dynic.trans.stamp.366

put.dynic.trans.ovf.365:                          ; preds = %put.dynic.trans.dispatch.363
  %r2855 = trunc nuw nsw i64 %r2832 to i32
  %r2856 = call i32 @js_transition_ic_spill_append(double %r2672, i64 %r2720, i32 %r2855, double %r2838) #7
  %r2857 = icmp ne i32 %r2856, 0
  br i1 %r2857, label %put.dynic.trans.stamp.366, label %put.dynic.slow.367

put.dynic.trans.stamp.366:                        ; preds = %put.dynic.trans.ovf.365, %put.dynic.trans.inline_ref.364
  %r4563.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18.relocated689 to i64
  %r4563.rs4o = call i64 asm "", "=r,0"(i64 %r4563.rs4i) #7
  %r4563 = bitcast i64 %r4563.rs4o to double
  %r4564 = bitcast double %r4563 to i64
  %r4565 = and i64 %r4564, 281474976710655
  %r2858 = add nuw nsw i64 %r4565, 4
  %r2859 = inttoptr i64 %r2858 to ptr
  store i32 %r2817, ptr %r2859, align 4
  br label %put.dynic.merge.368

put.dynic.slow.367:                               ; preds = %put.dynic.trans.ovf.365, %put.dynic.trans.nk.362, %put.dynic.trans.entry.361, %put.dynic.trans.key.360, %put.dynic.trans.probe.359, %put.dynic.trans.gate.358, %put.dynic.store.validate.354, %shadow.root.barrier.done.348
  %statepoint_token691 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_large_string_emitters_ts__9, double %r2672, double %r2671, double %r2669683, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.6.relocated688, ptr addrspace(1) %r8.0.relocated684, ptr addrspace(1) %rs4gc.s15.relocated685, ptr addrspace(1) %rs4gc.s13.relocated686, ptr addrspace(1) %rs4gc.s9.relocated687, ptr addrspace(1) %rs4gc.s18.relocated689) ]
  %r2860692 = call double @llvm.experimental.gc.result.f64(token %statepoint_token691)
  %r497.6.relocated693 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token691, i32 0, i32 0) ; (%r497.6.relocated688, %r497.6.relocated688)
  %r8.0.relocated694 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token691, i32 1, i32 1) ; (%r8.0.relocated684, %r8.0.relocated684)
  %rs4gc.s15.relocated695 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token691, i32 2, i32 2) ; (%rs4gc.s15.relocated685, %rs4gc.s15.relocated685)
  %rs4gc.s13.relocated696 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token691, i32 3, i32 3) ; (%rs4gc.s13.relocated686, %rs4gc.s13.relocated686)
  %rs4gc.s9.relocated697 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token691, i32 4, i32 4) ; (%rs4gc.s9.relocated687, %rs4gc.s9.relocated687)
  %rs4gc.s18.relocated698 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token691, i32 5, i32 5) ; (%rs4gc.s18.relocated689, %rs4gc.s18.relocated689)
  br label %put.dynic.merge.368

put.dynic.merge.368:                              ; preds = %put.dynic.slow.367, %put.dynic.trans.stamp.366, %put.dynic.store.ref.357, %put.dynic.store.scalar.356
  %.01489 = phi ptr addrspace(1) [ %r497.6.relocated693, %put.dynic.slow.367 ], [ %r497.6.relocated688, %put.dynic.store.scalar.356 ], [ %r497.6.relocated688, %put.dynic.store.ref.357 ], [ %r497.6.relocated688, %put.dynic.trans.stamp.366 ]
  %.191479 = phi ptr addrspace(1) [ %rs4gc.s18.relocated698, %put.dynic.slow.367 ], [ %rs4gc.s18.relocated689, %put.dynic.store.scalar.356 ], [ %rs4gc.s18.relocated689, %put.dynic.store.ref.357 ], [ %rs4gc.s18.relocated689, %put.dynic.trans.stamp.366 ]
  %.201446 = phi ptr addrspace(1) [ %rs4gc.s15.relocated695, %put.dynic.slow.367 ], [ %rs4gc.s15.relocated685, %put.dynic.store.scalar.356 ], [ %rs4gc.s15.relocated685, %put.dynic.store.ref.357 ], [ %rs4gc.s15.relocated685, %put.dynic.trans.stamp.366 ]
  %.231388 = phi ptr addrspace(1) [ %rs4gc.s13.relocated696, %put.dynic.slow.367 ], [ %rs4gc.s13.relocated686, %put.dynic.store.scalar.356 ], [ %rs4gc.s13.relocated686, %put.dynic.store.ref.357 ], [ %rs4gc.s13.relocated686, %put.dynic.trans.stamp.366 ]
  %.201330 = phi ptr addrspace(1) [ %r8.0.relocated694, %put.dynic.slow.367 ], [ %r8.0.relocated684, %put.dynic.store.scalar.356 ], [ %r8.0.relocated684, %put.dynic.store.ref.357 ], [ %r8.0.relocated684, %put.dynic.trans.stamp.366 ]
  %.23 = phi ptr addrspace(1) [ %rs4gc.s9.relocated697, %put.dynic.slow.367 ], [ %rs4gc.s9.relocated687, %put.dynic.store.scalar.356 ], [ %rs4gc.s9.relocated687, %put.dynic.store.ref.357 ], [ %rs4gc.s9.relocated687, %put.dynic.trans.stamp.366 ]
  %r2861 = phi double [ %r2669683, %put.dynic.store.scalar.356 ], [ %r2669683, %put.dynic.store.ref.357 ], [ %r2838, %put.dynic.trans.stamp.366 ], [ %r2860692, %put.dynic.slow.367 ]
  %r2862.rs4i = ptrtoint ptr addrspace(1) %.191479 to i64
  %r2862.rs4o = call i64 asm "", "=r,0"(i64 %r2862.rs4i) #7
  %r2862 = bitcast i64 %r2862.rs4o to double
  %r2863.rs4i = ptrtoint ptr addrspace(1) %.231388 to i64
  %r2863.rs4o = call i64 asm "", "=r,0"(i64 %r2863.rs4i) #7
  %r2863 = bitcast i64 %r2863.rs4o to double
  br label %ternary.else.370

ternary.else.370:                                 ; preds = %put.dynic.merge.368
  br label %ternary.merge.371

ternary.merge.371:                                ; preds = %ternary.else.370
  %statepoint_token699 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r2862, double %r2863, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.201330, ptr addrspace(1) %.201446, ptr addrspace(1) %.231388, ptr addrspace(1) %.23, ptr addrspace(1) %.01489) ]
  %r2878700 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token699)
  %r8.0.relocated701 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token699, i32 0, i32 0) ; (%.201330, %.201330)
  %rs4gc.s15.relocated702 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token699, i32 1, i32 1) ; (%.201446, %.201446)
  %rs4gc.s13.relocated703 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token699, i32 2, i32 2) ; (%.231388, %.231388)
  %rs4gc.s9.relocated704 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token699, i32 3, i32 3) ; (%.23, %.23)
  %r497.6.relocated705 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token699, i32 4, i32 4) ; (%.01489, %.01489)
  %r2879 = bitcast i64 %r2878700 to double
  %r2880 = bitcast i64 %r2878700 to double
  %r2881.rs4i = ptrtoint ptr addrspace(1) %r497.6.relocated705 to i64
  %r2881.rs4o = call i64 asm "", "=r,0"(i64 %r2881.rs4i) #7
  %r2881 = bitcast i64 %r2881.rs4o to double
  %r2882 = bitcast double %r2881 to i64
  %r2883 = and i64 %r2882, 281474976710655
  %r2884 = sub nsw i64 %r2883, 8
  %r2885 = inttoptr i64 %r2884 to ptr
  %r2886 = load i8, ptr %r2885, align 1
  %r2887 = icmp ne i8 %r2886, 1
  %r2888 = sub nsw i64 %r2883, 7
  %r2889 = inttoptr i64 %r2888 to ptr
  %r2890 = load i8, ptr %r2889, align 1
  %r2891 = and i8 %r2890, -128
  %r2892 = icmp ne i8 %r2891, 0
  %r2893 = or i1 %r2887, %r2892
  br i1 %r2892, label %apush.fwd.372, label %apush.elements.373

apush.fwd.372:                                    ; preds = %apush.elements.check.374, %ternary.merge.371
  %statepoint_token706 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2883, double %r2880, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated701, ptr addrspace(1) %rs4gc.s15.relocated702, ptr addrspace(1) %rs4gc.s13.relocated703, ptr addrspace(1) %rs4gc.s9.relocated704) ]
  %r2920707 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token706)
  %r8.0.relocated708 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token706, i32 0, i32 0) ; (%r8.0.relocated701, %r8.0.relocated701)
  %rs4gc.s15.relocated709 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token706, i32 1, i32 1) ; (%rs4gc.s15.relocated702, %rs4gc.s15.relocated702)
  %rs4gc.s13.relocated710 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token706, i32 2, i32 2) ; (%rs4gc.s13.relocated703, %rs4gc.s13.relocated703)
  %rs4gc.s9.relocated711 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token706, i32 3, i32 3) ; (%rs4gc.s9.relocated704, %rs4gc.s9.relocated704)
  %r2921 = or i64 %r2920707, 9222527611924643840
  %r2922 = bitcast i64 %r2921 to double
  %rs4gc.b48 = bitcast double %r2922 to i64
  %rs4gc.s48 = inttoptr i64 %rs4gc.b48 to ptr addrspace(1)
  br label %apush.merge.378

apush.elements.373:                               ; preds = %ternary.merge.371
  %r2895 = add nuw nsw i64 %r2883, 8
  %r2896 = inttoptr i64 %r2895 to ptr
  %r2897 = load i64, ptr %r2896, align 8
  %r2898 = icmp ne i64 %r2897, 0
  %r2899 = icmp eq i8 %r2886, 2
  %r2900 = and i1 %r2899, %r2898
  %r2901 = select i1 %r2900, i64 %r2897, i64 %r2883
  %r2902 = inttoptr i64 %r2901 to ptr
  %r2903 = getelementptr i64, ptr %r2902, i64 12
  %r2904 = load i64, ptr %r2903, align 8
  %r2905 = icmp ne i64 %r2904, 0
  %r2906 = and i1 %r2900, %r2905
  %r2907 = select i1 %r2906, i64 %r2904, i64 %r2883
  %r2894 = icmp eq i8 %r2886, 1
  br i1 %r2894, label %apush.nofwd.375, label %apush.elements.check.374

apush.elements.check.374:                         ; preds = %apush.elements.373
  %r2908 = icmp ne i64 %r2907, 0
  %r2909 = sub i64 %r2907, 8
  %r2910 = inttoptr i64 %r2909 to ptr
  %r2911 = load i8, ptr %r2910, align 1
  %r2912 = icmp eq i8 %r2911, 1
  %r2913 = sub i64 %r2907, 7
  %r2914 = inttoptr i64 %r2913 to ptr
  %r2915 = load i8, ptr %r2914, align 1
  %r2916 = and i8 %r2915, -128
  %r2917 = icmp eq i8 %r2916, 0
  %r2918 = and i1 %r2908, %r2912
  %r2919 = and i1 %r2918, %r2917
  br i1 %r2919, label %apush.nofwd.375, label %apush.fwd.372

apush.nofwd.375:                                  ; preds = %apush.elements.check.374, %apush.elements.373
  %r2923 = phi i64 [ %r2883, %apush.elements.373 ], [ %r2907, %apush.elements.check.374 ]
  %r2924 = sub i64 %r2923, 6
  %r2925 = inttoptr i64 %r2924 to ptr
  %r2926 = load i16, ptr %r2925, align 2
  %r2927 = and i16 %r2926, 1031
  %r2928 = icmp eq i16 %r2927, 0
  %r2929 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2930 = icmp eq i8 %r2929, 0
  %r2931 = and i1 %r2928, %r2930
  %r2932 = icmp ult i64 %r2923, 4096
  %r2933 = inttoptr i64 %r2923 to ptr
  %r2934 = select i1 %r2932, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r2933
  %r2935 = load i32, ptr %r2934, align 4
  %r2936 = add i64 %r2923, 4
  %r2937 = inttoptr i64 %r2936 to ptr
  %r2938 = load i32, ptr %r2937, align 4
  %r2939 = icmp ult i32 %r2935, %r2938
  %r2940 = and i1 %r2939, %r2931
  br i1 %r2940, label %apush.inbounds.376, label %apush.realloc.377

apush.inbounds.376:                               ; preds = %apush.nofwd.375
  %r2941 = icmp ult i64 %r2923, 4096
  %r2942 = inttoptr i64 %r2923 to ptr
  %r2943 = select i1 %r2941, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r2942
  %r2944 = load i32, ptr %r2943, align 4
  %r2945 = zext i32 %r2944 to i64
  %r2946 = shl nuw nsw i64 %r2945, 3
  %r2947 = add nuw nsw i64 %r2946, 8
  %r2948 = add i64 %r2923, %r2947
  %r2949 = inttoptr i64 %r2948 to ptr
  store double %r2880, ptr %r2949, align 8
  %r2950 = lshr i64 %r2878700, 48
  %r2951 = icmp eq i64 %r2950, 32765
  %r2952 = and i16 %r2926, -1920
  %r2953 = icmp eq i16 %r2952, -24576
  %r2954 = and i1 %r2951, %r2953
  br i1 %r2954, label %apush.pointer_layout.done.380, label %apush.pointer_layout.bookkeeping.379

apush.realloc.377:                                ; preds = %apush.nofwd.375
  %statepoint_token712 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r2883, double %r2880, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated701, ptr addrspace(1) %rs4gc.s15.relocated702, ptr addrspace(1) %rs4gc.s13.relocated703, ptr addrspace(1) %rs4gc.s9.relocated704) ]
  %r2965713 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token712)
  %r8.0.relocated714 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token712, i32 0, i32 0) ; (%r8.0.relocated701, %r8.0.relocated701)
  %rs4gc.s15.relocated715 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token712, i32 1, i32 1) ; (%rs4gc.s15.relocated702, %rs4gc.s15.relocated702)
  %rs4gc.s13.relocated716 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token712, i32 2, i32 2) ; (%rs4gc.s13.relocated703, %rs4gc.s13.relocated703)
  %rs4gc.s9.relocated717 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token712, i32 3, i32 3) ; (%rs4gc.s9.relocated704, %rs4gc.s9.relocated704)
  %r2966 = or i64 %r2965713, 9222527611924643840
  %r2967 = bitcast i64 %r2966 to double
  %rs4gc.b49 = bitcast double %r2967 to i64
  %rs4gc.s49 = inttoptr i64 %rs4gc.b49 to ptr addrspace(1)
  br label %apush.merge.378

apush.merge.378:                                  ; preds = %apush.barrier.done.382, %apush.realloc.377, %apush.fwd.372
  %.211447 = phi ptr addrspace(1) [ %rs4gc.s15.relocated709, %apush.fwd.372 ], [ %rs4gc.s15.relocated702, %apush.barrier.done.382 ], [ %rs4gc.s15.relocated715, %apush.realloc.377 ]
  %.241389 = phi ptr addrspace(1) [ %rs4gc.s13.relocated710, %apush.fwd.372 ], [ %rs4gc.s13.relocated703, %apush.barrier.done.382 ], [ %rs4gc.s13.relocated716, %apush.realloc.377 ]
  %.211331 = phi ptr addrspace(1) [ %r8.0.relocated708, %apush.fwd.372 ], [ %r8.0.relocated701, %apush.barrier.done.382 ], [ %r8.0.relocated714, %apush.realloc.377 ]
  %.24 = phi ptr addrspace(1) [ %rs4gc.s9.relocated711, %apush.fwd.372 ], [ %rs4gc.s9.relocated704, %apush.barrier.done.382 ], [ %rs4gc.s9.relocated717, %apush.realloc.377 ]
  %r497.7 = phi ptr addrspace(1) [ %rs4gc.s48, %apush.fwd.372 ], [ %r497.6.relocated705, %apush.barrier.done.382 ], [ %rs4gc.s49, %apush.realloc.377 ]
  br label %for.cond.383

apush.pointer_layout.bookkeeping.379:             ; preds = %apush.inbounds.376
  call void @js_string_addref_if_heap_string(double %r2880) #7
  call void @js_gc_note_slot_layout(i64 %r2923, i32 %r2944, i64 %r2878700) #7
  call void @js_array_note_numeric_write(i64 %r2923, i64 %r2878700) #7
  br label %apush.pointer_layout.done.380

apush.pointer_layout.done.380:                    ; preds = %apush.pointer_layout.bookkeeping.379, %apush.inbounds.376
  %r2955 = sub i64 %r2923, 7
  %r2956 = inttoptr i64 %r2955 to ptr
  %r2957 = load i8, ptr %r2956, align 1
  %r2958 = and i8 %r2957, 32
  %r2959 = icmp ne i8 %r2958, 0
  %r2960 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2961 = icmp ne i32 %r2960, 0
  %r2962 = or i1 %r2959, %r2961
  br i1 %r2962, label %apush.barrier.381, label %apush.barrier.done.382

apush.barrier.381:                                ; preds = %apush.pointer_layout.done.380
  call void @js_write_barrier_slot_validated_parent(i64 %r2923, i64 %r2948, i64 %r2878700) #7
  br label %apush.barrier.done.382

apush.barrier.done.382:                           ; preds = %apush.barrier.381, %apush.pointer_layout.done.380
  %r2963 = add i32 %r2944, 1
  %r2964 = inttoptr i64 %r2923 to ptr
  store i32 %r2963, ptr %r2964, align 4
  br label %apush.merge.378

for.cond.383:                                     ; preds = %for.update.385, %apush.merge.378
  %.01490 = phi ptr addrspace(1) [ %r497.7, %apush.merge.378 ], [ %.111501, %for.update.385 ]
  %.221448 = phi ptr addrspace(1) [ %.211447, %apush.merge.378 ], [ %.331459, %for.update.385 ]
  %.251390 = phi ptr addrspace(1) [ %.241389, %apush.merge.378 ], [ %.361401, %for.update.385 ]
  %.221332 = phi ptr addrspace(1) [ %.211331, %apush.merge.378 ], [ %.331343, %for.update.385 ]
  %.25 = phi ptr addrspace(1) [ %.24, %apush.merge.378 ], [ %.36, %for.update.385 ]
  %r2968.0 = phi i32 [ 0, %apush.merge.378 ], [ %r3750, %for.update.385 ]
  %r2970 = sitofp i32 %r2968.0 to double
  %r2971.rs4i = ptrtoint ptr addrspace(1) %.01490 to i64
  %r2971.rs4o = call i64 asm "", "=r,0"(i64 %r2971.rs4i) #7
  %r2971 = bitcast i64 %r2971.rs4o to double
  %r2972 = bitcast double %r2971 to i64
  %r2973 = and i64 %r2972, 281474976710655
  %r2974 = lshr i64 %r2972, 48
  %r2975 = and i64 %r2974, 65533
  %r2976 = icmp eq i64 %r2975, 32765
  %r2977 = icmp ugt i64 %r2973, 1048575
  %r2978 = and i1 %r2976, %r2977
  br i1 %r2978, label %plen.check_gc.387, label %plen.slow.389

for.body.384:                                     ; preds = %gcpoll.done.409
  %r3085.rs4i = ptrtoint ptr addrspace(1) %.31493 to i64
  %r3085.rs4o = call i64 asm "", "=r,0"(i64 %r3085.rs4i) #7
  %r3085 = bitcast i64 %r3085.rs4o to double
  %r3087 = bitcast double %r3085 to i64
  %r3088 = and i64 %r3087, 281474976710655
  %r3089 = lshr i64 %r3087, 48
  %r3090 = icmp eq i64 %r3089, 32765
  %r3091 = icmp ugt i64 %r3088, 1048575
  %r3092 = and i1 %r3090, %r3091
  br i1 %r3092, label %arr.guard.deref.414, label %arr.fallback.411

for.update.385:                                   ; preds = %gcpoll.done.532
  %r3750 = add i32 %r2968.0, 1
  %r3751 = sitofp i32 %r2968.0 to double
  %r3752 = sitofp i32 %r3750 to double
  br label %for.cond.383

for.exit.386:                                     ; preds = %gcpoll.done.409
  %r3754 = load double, ptr @test_json_large_string_emitters_ts_.str.0.handle, align 8
  %rs4gc.b50 = bitcast double %r3754 to i64
  %rs4gc.s50 = inttoptr i64 %rs4gc.b50 to ptr addrspace(1)
  %r3755.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s50 to i64
  %r3755 = call i64 asm "", "=r,0"(i64 %r3755.rs4i) #7
  %r3756 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3757 = icmp ne i32 %r3756, 0
  br i1 %r3757, label %shadow.root.barrier.533, label %shadow.root.barrier.done.534

plen.check_gc.387:                                ; preds = %for.cond.383
  %r2979 = sub nuw nsw i64 %r2973, 8
  %r2980 = inttoptr i64 %r2979 to ptr
  %r2981 = load i8, ptr %r2980, align 1
  %r2982 = icmp eq i8 %r2981, 1
  %r2983 = icmp eq i8 %r2981, 3
  %r2984 = or i1 %r2982, %r2983
  %r2985 = sub nuw nsw i64 %r2973, 7
  %r2986 = inttoptr i64 %r2985 to ptr
  %r2987 = load i8, ptr %r2986, align 1
  %r2988 = and i8 %r2987, -128
  %r2989 = icmp eq i8 %r2988, 0
  %r2990 = and i1 %r2984, %r2989
  br i1 %r2990, label %plen.fast.388, label %plen.slow.389

plen.fast.388:                                    ; preds = %plen.check_gc.387
  %r2992 = inttoptr i64 %r2973 to ptr
  %r2993 = select i1 false, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r2992
  %r2994 = load i32, ptr %r2993, align 4
  %r2995 = uitofp i32 %r2994 to double
  br label %plen.merge.390

plen.slow.389:                                    ; preds = %plen.check_gc.387, %for.cond.383
  %r2996 = lshr i64 %r2972, 48
  %r2997 = icmp eq i64 %r2996, 32765
  %r2998 = icmp uge i64 %r2973, 2199023255552
  %r2999 = icmp ult i64 %r2973, 140737488355328
  %r3000 = and i1 %r2997, %r2998
  %r3001 = and i1 %r3000, %r2999
  %r3002 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__10, align 8
  br i1 %r3001, label %plen.ic.header.391, label %plen.ic.miss.403

plen.merge.390:                                   ; preds = %plen.ic.merge.404, %plen.fast.388
  %.11491 = phi ptr addrspace(1) [ %.01490, %plen.fast.388 ], [ %.21492, %plen.ic.merge.404 ]
  %.231449 = phi ptr addrspace(1) [ %.221448, %plen.fast.388 ], [ %.241450, %plen.ic.merge.404 ]
  %.261391 = phi ptr addrspace(1) [ %.251390, %plen.fast.388 ], [ %.271392, %plen.ic.merge.404 ]
  %.231333 = phi ptr addrspace(1) [ %.221332, %plen.fast.388 ], [ %.241334, %plen.ic.merge.404 ]
  %.26 = phi ptr addrspace(1) [ %.25, %plen.fast.388 ], [ %.27, %plen.ic.merge.404 ]
  %r3077 = phi double [ %r2995, %plen.fast.388 ], [ %r3076, %plen.ic.merge.404 ]
  %r3078 = fcmp olt double %r2970, %r3077
  %r3079 = select i1 %r3078, i64 9222246136947933188, i64 9222246136947933187
  %r3080 = bitcast i64 %r3079 to double
  %r3082 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r3083 = icmp ne i32 %r3082, 0
  br i1 %r3083, label %gcpoll.408, label %gcpoll.done.409

plen.ic.header.391:                               ; preds = %plen.slow.389
  %r3004 = sub nuw nsw i64 %r2973, 8
  %r3005 = inttoptr i64 %r3004 to ptr
  %r3006 = load i8, ptr %r3005, align 1
  %r3007 = icmp eq i8 %r3006, 2
  %r3008 = sub nuw nsw i64 %r2973, 7
  %r3009 = inttoptr i64 %r3008 to ptr
  %r3010 = load i8, ptr %r3009, align 1
  %r3011 = and i8 %r3010, -128
  %r3012 = icmp eq i8 %r3011, 0
  %r3013 = and i1 %r3007, %r3012
  br i1 %r3013, label %plen.elem.meta.405, label %plen.ic.miss.403

plen.ic.shape.392:                                ; preds = %plen.elem.store.406, %plen.elem.meta.405
  %r3003 = icmp ne ptr %r3002, null
  br i1 %r3003, label %plen.ic.shape.probe.393, label %plen.ic.miss.403

plen.ic.shape.probe.393:                          ; preds = %plen.ic.shape.392
  %r3025 = inttoptr i64 %r2973 to ptr
  %r3026 = load i32, ptr %r3025, align 4
  %r3027 = add nuw nsw i64 %r2973, 4
  %r3028 = inttoptr i64 %r3027 to ptr
  %r3029 = load i32, ptr %r3028, align 4
  %r3030 = zext i32 %r3026 to i64
  %r3031 = zext i32 %r3029 to i64
  %r3032 = shl nuw i64 %r3030, 32
  %r3033 = or i64 %r3032, %r3031
  %r3034 = getelementptr i64, ptr %r3002, i64 0
  %r3035 = load i64, ptr %r3034, align 8
  %r3036 = icmp ne i64 %r3035, 0
  br i1 %r3036, label %plen.ic.identity.394, label %plen.ic.miss.403

plen.ic.identity.394:                             ; preds = %plen.ic.shape.probe.393
  %r3037 = and i64 %r3035, -9223372036854775808
  %0 = icmp slt i64 %r3035, 0
  br i1 %0, label %plen.ic.family_meta.396, label %plen.ic.exact.395

plen.ic.exact.395:                                ; preds = %plen.ic.identity.394
  %r3039 = icmp eq i64 %r3033, %r3035
  br i1 %r3039, label %plen.ic.slot.398, label %plen.ic.miss.403

plen.ic.family_meta.396:                          ; preds = %plen.ic.identity.394
  %r3040 = add nuw nsw i64 %r2973, 8
  %r3041 = inttoptr i64 %r3040 to ptr
  %r3042 = load i64, ptr %r3041, align 8
  %r3043 = icmp ne i64 %r3042, 0
  br i1 %r3043, label %plen.ic.family_token.397, label %plen.ic.miss.403

plen.ic.family_token.397:                         ; preds = %plen.ic.family_meta.396
  %r3044 = inttoptr i64 %r3042 to ptr
  %r3045 = getelementptr i64, ptr %r3044, i64 6
  %r3046 = load i64, ptr %r3045, align 8
  %r3047 = icmp eq i64 %r3046, %r3035
  br i1 %r3047, label %plen.ic.slot.398, label %plen.ic.miss.403

plen.ic.slot.398:                                 ; preds = %plen.ic.family_token.397, %plen.ic.exact.395
  %r3048 = getelementptr i64, ptr %r3002, i64 1
  %r3049 = load i64, ptr %r3048, align 8
  %r3050 = getelementptr i64, ptr %r3002, i64 2
  %r3051 = load i64, ptr %r3050, align 8
  %r3052 = icmp ult i64 %r3049, %r3051
  br i1 %r3052, label %plen.ic.inline.399, label %plen.ic.spill_meta.400

plen.ic.inline.399:                               ; preds = %plen.ic.slot.398
  %r3053 = shl i64 %r3049, 3
  %r3054 = add i64 %r3053, 16
  %r3055 = add i64 %r2973, %r3054
  %r3056 = inttoptr i64 %r3055 to ptr
  %r3057 = load double, ptr %r3056, align 8
  br label %plen.ic.merge.404

plen.ic.spill_meta.400:                           ; preds = %plen.ic.slot.398
  %r3058 = add nuw nsw i64 %r2973, 8
  %r3059 = inttoptr i64 %r3058 to ptr
  %r3060 = load i64, ptr %r3059, align 8
  %r3061 = icmp ne i64 %r3060, 0
  br i1 %r3061, label %plen.ic.spill_ptr.401, label %plen.ic.miss.403

plen.ic.spill_ptr.401:                            ; preds = %plen.ic.spill_meta.400
  %r3062 = inttoptr i64 %r3060 to ptr
  %r3063 = getelementptr i64, ptr %r3062, i64 4
  %r3064 = load i64, ptr %r3063, align 8
  %r3065 = icmp ne i64 %r3064, 0
  %r3066 = select i1 %r3065, i64 %r3064, i64 %r3060
  %r3067 = inttoptr i64 %r3066 to ptr
  %r3068 = load i32, ptr %r3067, align 4
  %r3069 = zext i32 %r3068 to i64
  %r3070 = icmp ult i64 %r3049, %r3069
  %r3071 = and i1 %r3065, %r3070
  br i1 %r3071, label %plen.ic.spill_load.402, label %plen.ic.miss.403

plen.ic.spill_load.402:                           ; preds = %plen.ic.spill_ptr.401
  %r3072 = add nuw nsw i64 %r3049, 1
  %r3073 = getelementptr inbounds nuw i64, ptr %r3067, i64 %r3072
  %r3074 = load double, ptr %r3073, align 8
  br label %plen.ic.merge.404

plen.ic.miss.403:                                 ; preds = %plen.ic.spill_ptr.401, %plen.ic.spill_meta.400, %plen.ic.family_token.397, %plen.ic.family_meta.396, %plen.ic.exact.395, %plen.ic.shape.probe.393, %plen.ic.shape.392, %plen.ic.header.391, %plen.slow.389
  %statepoint_token718 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r2971, ptr @perry_ic_test_json_large_string_emitters_ts__10, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01490, ptr addrspace(1) %.221332, ptr addrspace(1) %.221448, ptr addrspace(1) %.251390, ptr addrspace(1) %.25) ]
  %r3075719 = call double @llvm.experimental.gc.result.f64(token %statepoint_token718)
  %r497.7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token718, i32 0, i32 0) ; (%.01490, %.01490)
  %r8.0.relocated720 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token718, i32 1, i32 1) ; (%.221332, %.221332)
  %rs4gc.s15.relocated721 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token718, i32 2, i32 2) ; (%.221448, %.221448)
  %rs4gc.s13.relocated722 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token718, i32 3, i32 3) ; (%.251390, %.251390)
  %rs4gc.s9.relocated723 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token718, i32 4, i32 4) ; (%.25, %.25)
  br label %plen.ic.merge.404

plen.ic.merge.404:                                ; preds = %plen.elem.length.407, %plen.ic.miss.403, %plen.ic.spill_load.402, %plen.ic.inline.399
  %.21492 = phi ptr addrspace(1) [ %.01490, %plen.elem.length.407 ], [ %.01490, %plen.ic.inline.399 ], [ %.01490, %plen.ic.spill_load.402 ], [ %r497.7.relocated, %plen.ic.miss.403 ]
  %.241450 = phi ptr addrspace(1) [ %.221448, %plen.elem.length.407 ], [ %.221448, %plen.ic.inline.399 ], [ %.221448, %plen.ic.spill_load.402 ], [ %rs4gc.s15.relocated721, %plen.ic.miss.403 ]
  %.271392 = phi ptr addrspace(1) [ %.251390, %plen.elem.length.407 ], [ %.251390, %plen.ic.inline.399 ], [ %.251390, %plen.ic.spill_load.402 ], [ %rs4gc.s13.relocated722, %plen.ic.miss.403 ]
  %.241334 = phi ptr addrspace(1) [ %.221332, %plen.elem.length.407 ], [ %.221332, %plen.ic.inline.399 ], [ %.221332, %plen.ic.spill_load.402 ], [ %r8.0.relocated720, %plen.ic.miss.403 ]
  %.27 = phi ptr addrspace(1) [ %.25, %plen.elem.length.407 ], [ %.25, %plen.ic.inline.399 ], [ %.25, %plen.ic.spill_load.402 ], [ %rs4gc.s9.relocated723, %plen.ic.miss.403 ]
  %r3076 = phi double [ %r3024, %plen.elem.length.407 ], [ %r3057, %plen.ic.inline.399 ], [ %r3074, %plen.ic.spill_load.402 ], [ %r3075719, %plen.ic.miss.403 ]
  br label %plen.merge.390

plen.elem.meta.405:                               ; preds = %plen.ic.header.391
  %r3014 = add nuw nsw i64 %r2973, 8
  %r3015 = inttoptr i64 %r3014 to ptr
  %r3016 = load i64, ptr %r3015, align 8
  %r3017 = icmp ne i64 %r3016, 0
  br i1 %r3017, label %plen.elem.store.406, label %plen.ic.shape.392

plen.elem.store.406:                              ; preds = %plen.elem.meta.405
  %r3018 = inttoptr i64 %r3016 to ptr
  %r3019 = getelementptr i64, ptr %r3018, i64 12
  %r3020 = load i64, ptr %r3019, align 8
  %r3021 = icmp ne i64 %r3020, 0
  br i1 %r3021, label %plen.elem.length.407, label %plen.ic.shape.392

plen.elem.length.407:                             ; preds = %plen.elem.store.406
  %r3022 = inttoptr i64 %r3020 to ptr
  %r3023 = load i32, ptr %r3022, align 4
  %r3024 = uitofp i32 %r3023 to double
  br label %plen.ic.merge.404

gcpoll.408:                                       ; preds = %plen.merge.390
  %statepoint_token724 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11491, ptr addrspace(1) %.231333, ptr addrspace(1) %.231449, ptr addrspace(1) %.261391, ptr addrspace(1) %.26) ]
  %r497.7.relocated725 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 0, i32 0) ; (%.11491, %.11491)
  %r8.0.relocated726 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 1, i32 1) ; (%.231333, %.231333)
  %rs4gc.s15.relocated727 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 2, i32 2) ; (%.231449, %.231449)
  %rs4gc.s13.relocated728 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 3, i32 3) ; (%.261391, %.261391)
  %rs4gc.s9.relocated729 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token724, i32 4, i32 4) ; (%.26, %.26)
  br label %gcpoll.done.409

gcpoll.done.409:                                  ; preds = %gcpoll.408, %plen.merge.390
  %.31493 = phi ptr addrspace(1) [ %r497.7.relocated725, %gcpoll.408 ], [ %.11491, %plen.merge.390 ]
  %.251451 = phi ptr addrspace(1) [ %rs4gc.s15.relocated727, %gcpoll.408 ], [ %.231449, %plen.merge.390 ]
  %.281393 = phi ptr addrspace(1) [ %rs4gc.s13.relocated728, %gcpoll.408 ], [ %.261391, %plen.merge.390 ]
  %.251335 = phi ptr addrspace(1) [ %r8.0.relocated726, %gcpoll.408 ], [ %.231333, %plen.merge.390 ]
  %.28 = phi ptr addrspace(1) [ %rs4gc.s9.relocated729, %gcpoll.408 ], [ %.26, %plen.merge.390 ]
  %r3081 = icmp eq i64 %r3079, 9222246136947933188
  br i1 %r3081, label %for.body.384, label %for.exit.386

arr.fast.410:                                     ; preds = %arr.guard.range.416
  %r3148 = zext i32 %r2968.0 to i64
  %r3149 = shl nuw nsw i64 %r3148, 3
  %r3150 = add nuw nsw i64 %r3149, 8
  %r3151 = add i64 %r3107, %r3150
  %r3152 = inttoptr i64 %r3151 to ptr
  %r3153 = load double, ptr %r3152, align 8
  %r3154 = bitcast double %r3153 to i64
  %r3155 = icmp eq i64 %r3154, 9222246136947933200
  %r3157 = select i1 %r3155, double 0x7FFC000000000001, double %r3153
  br label %arr.merge.413

arr.fallback.411:                                 ; preds = %arr.guard.live.415, %arr.guard.deref.414, %for.body.384
  %r3146 = sitofp i32 %r2968.0 to double
  %statepoint_token730 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7058970246387859467, double %r3085, double %r3146, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31493, ptr addrspace(1) %.251335, ptr addrspace(1) %.251451, ptr addrspace(1) %.281393, ptr addrspace(1) %.28) ]
  %r3147731 = call double @llvm.experimental.gc.result.f64(token %statepoint_token730)
  %r497.7.relocated732 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token730, i32 0, i32 0) ; (%.31493, %.31493)
  %r8.0.relocated733 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token730, i32 1, i32 1) ; (%.251335, %.251335)
  %rs4gc.s15.relocated734 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token730, i32 2, i32 2) ; (%.251451, %.251451)
  %rs4gc.s13.relocated735 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token730, i32 3, i32 3) ; (%.281393, %.281393)
  %rs4gc.s9.relocated736 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token730, i32 4, i32 4) ; (%.28, %.28)
  br label %arr.merge.413

arr.guard.oob.412:                                ; preds = %arr.guard.range.416
  br label %arr.merge.413

arr.merge.413:                                    ; preds = %arr.guard.oob.412, %arr.fallback.411, %arr.fast.410
  %.41494 = phi ptr addrspace(1) [ %.31493, %arr.fast.410 ], [ %.31493, %arr.guard.oob.412 ], [ %r497.7.relocated732, %arr.fallback.411 ]
  %.261452 = phi ptr addrspace(1) [ %.251451, %arr.fast.410 ], [ %.251451, %arr.guard.oob.412 ], [ %rs4gc.s15.relocated734, %arr.fallback.411 ]
  %.291394 = phi ptr addrspace(1) [ %.281393, %arr.fast.410 ], [ %.281393, %arr.guard.oob.412 ], [ %rs4gc.s13.relocated735, %arr.fallback.411 ]
  %.261336 = phi ptr addrspace(1) [ %.251335, %arr.fast.410 ], [ %.251335, %arr.guard.oob.412 ], [ %r8.0.relocated733, %arr.fallback.411 ]
  %.29 = phi ptr addrspace(1) [ %.28, %arr.fast.410 ], [ %.28, %arr.guard.oob.412 ], [ %rs4gc.s9.relocated736, %arr.fallback.411 ]
  %r3158 = phi double [ %r3157, %arr.fast.410 ], [ %r3147731, %arr.fallback.411 ], [ 0x7FFC000000000001, %arr.guard.oob.412 ]
  %statepoint_token737 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r3158, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41494, ptr addrspace(1) %.261336, ptr addrspace(1) %.261452, ptr addrspace(1) %.291394, ptr addrspace(1) %.29) ]
  %r3159738 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token737)
  %r497.7.relocated739 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token737, i32 0, i32 0) ; (%.41494, %.41494)
  %r8.0.relocated740 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token737, i32 1, i32 1) ; (%.261336, %.261336)
  %rs4gc.s15.relocated741 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token737, i32 2, i32 2) ; (%.261452, %.261452)
  %rs4gc.s13.relocated742 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token737, i32 3, i32 3) ; (%.291394, %.291394)
  %rs4gc.s9.relocated743 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token737, i32 4, i32 4) ; (%.29, %.29)
  %statepoint_token744 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r3159738, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.7.relocated739, ptr addrspace(1) %r8.0.relocated740, ptr addrspace(1) %rs4gc.s15.relocated741, ptr addrspace(1) %rs4gc.s13.relocated742, ptr addrspace(1) %rs4gc.s9.relocated743) ]
  %r3160745 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token744)
  %r497.7.relocated746 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 0, i32 0) ; (%r497.7.relocated739, %r497.7.relocated739)
  %r8.0.relocated747 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 1, i32 1) ; (%r8.0.relocated740, %r8.0.relocated740)
  %rs4gc.s15.relocated748 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 2, i32 2) ; (%rs4gc.s15.relocated741, %rs4gc.s15.relocated741)
  %rs4gc.s13.relocated749 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 3, i32 3) ; (%rs4gc.s13.relocated742, %rs4gc.s13.relocated742)
  %rs4gc.s9.relocated750 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token744, i32 4, i32 4) ; (%rs4gc.s9.relocated743, %rs4gc.s9.relocated743)
  %r3161 = bitcast i64 %r3160745 to double
  %rs4gc.b51 = bitcast double %r3161 to i64
  %rs4gc.s51 = inttoptr i64 %rs4gc.b51 to ptr addrspace(1)
  %r3162.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s51 to i64
  %r3162 = call i64 asm "", "=r,0"(i64 %r3162.rs4i) #7
  %r3163 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3164 = icmp ne i32 %r3163, 0
  br i1 %r3164, label %shadow.root.barrier.417, label %shadow.root.barrier.done.418

arr.guard.deref.414:                              ; preds = %for.body.384
  %r3093 = bitcast double %r3085 to i64
  %r3094 = and i64 %r3093, 281474976710655
  %r3095 = sub nsw i64 %r3094, 8
  %r3096 = inttoptr i64 %r3095 to ptr
  %r3097 = load i8, ptr %r3096, align 1
  %r3098 = icmp eq i8 %r3097, 1
  %r3099 = sub nsw i64 %r3094, 7
  %r3100 = inttoptr i64 %r3099 to ptr
  %r3101 = load i8, ptr %r3100, align 1
  %r3102 = and i8 %r3101, -128
  %r3103 = icmp ne i8 %r3102, 0
  %r3104 = inttoptr i64 %r3094 to ptr
  %r3105 = load i64, ptr %r3104, align 8
  %r3106 = and i1 %r3098, %r3103
  %r3107 = select i1 %r3106, i64 %r3105, i64 %r3094
  %r3108 = lshr i64 %r3107, 48
  %r3109 = icmp eq i64 %r3108, 0
  %r3110 = icmp ugt i64 %r3107, 1048575
  %r3111 = and i1 %r3109, %r3110
  br i1 %r3111, label %arr.guard.live.415, label %arr.fallback.411

arr.guard.live.415:                               ; preds = %arr.guard.deref.414
  %r3112 = sub nuw i64 %r3107, 8
  %r3113 = inttoptr i64 %r3112 to ptr
  %r3114 = load i8, ptr %r3113, align 1
  %r3115 = icmp eq i8 %r3114, 1
  %r3116 = sub nuw i64 %r3107, 7
  %r3117 = inttoptr i64 %r3116 to ptr
  %r3118 = load i8, ptr %r3117, align 1
  %r3119 = and i8 %r3118, -128
  %r3120 = icmp eq i8 %r3119, 0
  %r3121 = sub nuw i64 %r3107, 6
  %r3122 = inttoptr i64 %r3121 to ptr
  %r3123 = load i16, ptr %r3122, align 2
  %r3124 = and i16 %r3123, 1024
  %r3125 = icmp eq i16 %r3124, 0
  %r3126 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3127 = icmp eq i8 %r3126, 0
  %r3128 = inttoptr i64 %r3107 to ptr
  %r3129 = load i32, ptr %r3128, align 4
  %r3130 = getelementptr i8, ptr %r3128, i64 4
  %r3131 = load i32, ptr %r3130, align 4
  %r3132 = icmp slt i32 %r2968.0, 0
  %r3133 = icmp eq i1 %r3132, false
  %r3135 = icmp ule i32 %r3129, 16000000
  %r3136 = icmp ule i32 %r3131, 16000000
  %r3137 = icmp ule i32 %r3129, %r3131
  %r3138 = and i1 %r3115, %r3120
  %r3139 = and i1 %r3138, %r3125
  %r3140 = and i1 %r3139, %r3127
  %r3141 = and i1 %r3140, %r3133
  %r3142 = and i1 %r3141, %r3135
  %r3143 = and i1 %r3142, %r3136
  %r3144 = and i1 %r3143, %r3137
  br i1 %r3144, label %arr.guard.range.416, label %arr.fallback.411

arr.guard.range.416:                              ; preds = %arr.guard.live.415
  %r3134 = icmp ult i32 %r2968.0, %r3129
  br i1 %r3134, label %arr.fast.410, label %arr.guard.oob.412

shadow.root.barrier.417:                          ; preds = %arr.merge.413
  call void @js_write_barrier_root_nanbox(i64 %r3162) #7
  br label %shadow.root.barrier.done.418

shadow.root.barrier.done.418:                     ; preds = %shadow.root.barrier.417, %arr.merge.413
  %r3165.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s51 to i64
  %r3165.rs4o = call i64 asm "", "=r,0"(i64 %r3165.rs4i) #7
  %r3165 = bitcast i64 %r3165.rs4o to double
  %r3166.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15.relocated748 to i64
  %r3166.rs4o = call i64 asm "", "=r,0"(i64 %r3166.rs4i) #7
  %r3166 = bitcast i64 %r3166.rs4o to double
  %r3167 = bitcast double %r3165 to i64
  %r3168 = and i64 %r3167, 281474976710655
  %r3169 = and i64 %r3167, -281474976710656
  %r3170 = icmp eq i64 %r3169, 9222527611924643840
  %r3171 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r3172 = icmp eq i64 %r3171, 0
  %r3173 = icmp ugt i64 %r3168, 1048575
  %r3174 = icmp ult i64 %r3168, 140737488355328
  %r3175 = and i1 %r3173, %r3174
  %r3176 = and i1 %r3170, %r3172
  %r3177 = and i1 %r3176, %r3175
  br i1 %r3177, label %tav.get.brand.423, label %tav.get.slow.421

tav.get.fast.419:                                 ; preds = %tav.get.brand.423
  %r3194 = bitcast double %r3165 to i64
  %r3195 = and i64 %r3194, 281474976710655
  %r3196 = add nuw nsw i64 %r3195, 8
  %r3197 = inttoptr i64 %r3196 to ptr
  %r3198 = load i8, ptr %r3197, align 1
  %r3199 = zext i8 %r3198 to i64
  %r3200 = fptosi double %r3166 to i64
  %r3201 = sitofp i64 %r3200 to double
  %r3202 = fcmp oeq double %r3201, %r3166
  %r3203 = inttoptr i64 %r3195 to ptr
  %r3204 = load i32, ptr %r3203, align 4
  %r3205 = zext i32 %r3204 to i64
  %r3206 = icmp ult i64 %r3200, %r3205
  %r3207 = and i1 %r3202, %r3206
  br i1 %r3207, label %tav.get.load.420, label %tav.get.slow.421

tav.get.load.420:                                 ; preds = %tav.get.fast.419
  %r3208 = add nuw nsw i64 %r3195, 16
  %r3209 = icmp eq i64 %r3199, 0
  br i1 %r3209, label %tav.k.i8.424, label %tav.kd1.432

tav.get.slow.421:                                 ; preds = %tav.get.brand.423, %tav.get.fast.419, %shadow.root.barrier.done.418
  %r3260 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__12, align 8
  %r3261 = icmp ne ptr %r3260, null
  %r3262 = select i1 %r3261, ptr %r3260, ptr @perry_ic_test_json_large_string_emitters_ts__12
  %r3263 = bitcast double %r3165 to i64
  %r3264 = and i64 %r3263, 281474976710655
  %r3265 = and i64 %r3263, -281474976710656
  %r3266 = icmp eq i64 %r3265, 9222527611924643840
  %r3267 = icmp uge i64 %r3264, 2199023255552
  %r3268 = icmp ult i64 %r3264, 140737488355328
  %r3269 = fcmp oge double %r3166, 0.000000e+00
  %r3270 = fcmp olt double %r3166, 0x41EFFFFFFFE00000
  %r3271 = and i1 %r3266, %r3267
  %r3272 = and i1 %r3271, %r3268
  %r3273 = and i1 %r3269, %r3270
  %r3274 = and i1 %r3272, %r3273
  br i1 %r3274, label %arrlike.ic.header.439, label %arrlike.ic.miss.458

tav.get.merge.422:                                ; preds = %arrlike.elem.value.464, %arrlike.ic.miss.458, %arrlike.ic.spill_load.457, %arrlike.ic.inline.454, %arrlike.ic.array_load.442, %tav.k.f64.431, %tav.k.f32.430, %tav.k.u32.429, %tav.k.i32.428, %tav.k.u16.427, %tav.k.i16.426, %tav.k.u8.425, %tav.k.i8.424
  %.01502 = phi ptr addrspace(1) [ %rs4gc.s51, %tav.k.i8.424 ], [ %rs4gc.s51, %tav.k.u8.425 ], [ %rs4gc.s51, %tav.k.i16.426 ], [ %rs4gc.s51, %tav.k.u16.427 ], [ %rs4gc.s51, %tav.k.i32.428 ], [ %rs4gc.s51, %tav.k.u32.429 ], [ %rs4gc.s51, %tav.k.f32.430 ], [ %rs4gc.s51, %tav.k.f64.431 ], [ %rs4gc.s51, %arrlike.ic.array_load.442 ], [ %rs4gc.s51.relocated, %arrlike.ic.miss.458 ], [ %rs4gc.s51, %arrlike.elem.value.464 ], [ %rs4gc.s51, %arrlike.ic.inline.454 ], [ %rs4gc.s51, %arrlike.ic.spill_load.457 ]
  %.51495 = phi ptr addrspace(1) [ %r497.7.relocated746, %tav.k.i8.424 ], [ %r497.7.relocated746, %tav.k.u8.425 ], [ %r497.7.relocated746, %tav.k.i16.426 ], [ %r497.7.relocated746, %tav.k.u16.427 ], [ %r497.7.relocated746, %tav.k.i32.428 ], [ %r497.7.relocated746, %tav.k.u32.429 ], [ %r497.7.relocated746, %tav.k.f32.430 ], [ %r497.7.relocated746, %tav.k.f64.431 ], [ %r497.7.relocated746, %arrlike.ic.array_load.442 ], [ %r497.7.relocated753, %arrlike.ic.miss.458 ], [ %r497.7.relocated746, %arrlike.elem.value.464 ], [ %r497.7.relocated746, %arrlike.ic.inline.454 ], [ %r497.7.relocated746, %arrlike.ic.spill_load.457 ]
  %.271453 = phi ptr addrspace(1) [ %rs4gc.s15.relocated748, %tav.k.i8.424 ], [ %rs4gc.s15.relocated748, %tav.k.u8.425 ], [ %rs4gc.s15.relocated748, %tav.k.i16.426 ], [ %rs4gc.s15.relocated748, %tav.k.u16.427 ], [ %rs4gc.s15.relocated748, %tav.k.i32.428 ], [ %rs4gc.s15.relocated748, %tav.k.u32.429 ], [ %rs4gc.s15.relocated748, %tav.k.f32.430 ], [ %rs4gc.s15.relocated748, %tav.k.f64.431 ], [ %rs4gc.s15.relocated748, %arrlike.ic.array_load.442 ], [ %rs4gc.s15.relocated755, %arrlike.ic.miss.458 ], [ %rs4gc.s15.relocated748, %arrlike.elem.value.464 ], [ %rs4gc.s15.relocated748, %arrlike.ic.inline.454 ], [ %rs4gc.s15.relocated748, %arrlike.ic.spill_load.457 ]
  %.301395 = phi ptr addrspace(1) [ %rs4gc.s13.relocated749, %tav.k.i8.424 ], [ %rs4gc.s13.relocated749, %tav.k.u8.425 ], [ %rs4gc.s13.relocated749, %tav.k.i16.426 ], [ %rs4gc.s13.relocated749, %tav.k.u16.427 ], [ %rs4gc.s13.relocated749, %tav.k.i32.428 ], [ %rs4gc.s13.relocated749, %tav.k.u32.429 ], [ %rs4gc.s13.relocated749, %tav.k.f32.430 ], [ %rs4gc.s13.relocated749, %tav.k.f64.431 ], [ %rs4gc.s13.relocated749, %arrlike.ic.array_load.442 ], [ %rs4gc.s13.relocated756, %arrlike.ic.miss.458 ], [ %rs4gc.s13.relocated749, %arrlike.elem.value.464 ], [ %rs4gc.s13.relocated749, %arrlike.ic.inline.454 ], [ %rs4gc.s13.relocated749, %arrlike.ic.spill_load.457 ]
  %.271337 = phi ptr addrspace(1) [ %r8.0.relocated747, %tav.k.i8.424 ], [ %r8.0.relocated747, %tav.k.u8.425 ], [ %r8.0.relocated747, %tav.k.i16.426 ], [ %r8.0.relocated747, %tav.k.u16.427 ], [ %r8.0.relocated747, %tav.k.i32.428 ], [ %r8.0.relocated747, %tav.k.u32.429 ], [ %r8.0.relocated747, %tav.k.f32.430 ], [ %r8.0.relocated747, %tav.k.f64.431 ], [ %r8.0.relocated747, %arrlike.ic.array_load.442 ], [ %r8.0.relocated754, %arrlike.ic.miss.458 ], [ %r8.0.relocated747, %arrlike.elem.value.464 ], [ %r8.0.relocated747, %arrlike.ic.inline.454 ], [ %r8.0.relocated747, %arrlike.ic.spill_load.457 ]
  %.30 = phi ptr addrspace(1) [ %rs4gc.s9.relocated750, %tav.k.i8.424 ], [ %rs4gc.s9.relocated750, %tav.k.u8.425 ], [ %rs4gc.s9.relocated750, %tav.k.i16.426 ], [ %rs4gc.s9.relocated750, %tav.k.u16.427 ], [ %rs4gc.s9.relocated750, %tav.k.i32.428 ], [ %rs4gc.s9.relocated750, %tav.k.u32.429 ], [ %rs4gc.s9.relocated750, %tav.k.f32.430 ], [ %rs4gc.s9.relocated750, %tav.k.f64.431 ], [ %rs4gc.s9.relocated750, %arrlike.ic.array_load.442 ], [ %rs4gc.s9.relocated757, %arrlike.ic.miss.458 ], [ %rs4gc.s9.relocated750, %arrlike.elem.value.464 ], [ %rs4gc.s9.relocated750, %arrlike.ic.inline.454 ], [ %rs4gc.s9.relocated750, %arrlike.ic.spill_load.457 ]
  %r3433 = phi double [ %r3222, %tav.k.i8.424 ], [ %r3228, %tav.k.u8.425 ], [ %r3234, %tav.k.i16.426 ], [ %r3240, %tav.k.u16.427 ], [ %r3245, %tav.k.i32.428 ], [ %r3250, %tav.k.u32.429 ], [ %r3255, %tav.k.f32.430 ], [ %r3259, %tav.k.f64.431 ], [ %r3316, %arrlike.elem.value.464 ], [ %r3344, %arrlike.ic.array_load.442 ], [ %r3414, %arrlike.ic.inline.454 ], [ %r3431, %arrlike.ic.spill_load.457 ], [ %r3432752, %arrlike.ic.miss.458 ]
  %r3434 = bitcast double %r3433 to i64
  %rs4gc.s52 = inttoptr i64 %r3434 to ptr addrspace(1)
  %r3435.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s52 to i64
  %r3435 = call i64 asm "", "=r,0"(i64 %r3435.rs4i) #7
  %r3436 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3437 = icmp ne i32 %r3436, 0
  br i1 %r3437, label %shadow.root.barrier.466, label %shadow.root.barrier.done.467

tav.get.brand.423:                                ; preds = %shadow.root.barrier.done.418
  %r3178 = bitcast double %r3165 to i64
  %r3179 = and i64 %r3178, 281474976710655
  %r3180 = sub nsw i64 %r3179, 8
  %r3181 = inttoptr i64 %r3180 to ptr
  %r3182 = load i8, ptr %r3181, align 1
  %r3183 = icmp eq i8 %r3182, 11
  %r3184 = add nuw nsw i64 %r3179, 8
  %r3185 = inttoptr i64 %r3184 to ptr
  %r3186 = load i8, ptr %r3185, align 1
  %r3187 = zext i8 %r3186 to i64
  %r3188 = icmp ule i64 %r3187, 8
  %r3189 = fcmp oge double %r3166, 0.000000e+00
  %r3190 = fcmp olt double %r3166, 0x41F0000000000000
  %r3191 = and i1 %r3183, %r3188
  %r3192 = and i1 %r3191, %r3189
  %r3193 = and i1 %r3192, %r3190
  br i1 %r3193, label %tav.get.fast.419, label %tav.get.slow.421

tav.k.i8.424:                                     ; preds = %tav.get.load.420
  %r3217 = shl nuw nsw i64 %r3200, 0
  %r3218 = add nuw nsw i64 %r3208, %r3217
  %r3219 = inttoptr i64 %r3218 to ptr
  %r3220 = load i8, ptr %r3219, align 1
  %r3221 = sext i8 %r3220 to i32
  %r3222 = sitofp i32 %r3221 to double
  br label %tav.get.merge.422

tav.k.u8.425:                                     ; preds = %tav.kd7.438, %tav.kd1.432
  %r3223 = shl nuw nsw i64 %r3200, 0
  %r3224 = add nuw nsw i64 %r3208, %r3223
  %r3225 = inttoptr i64 %r3224 to ptr
  %r3226 = load i8, ptr %r3225, align 1
  %r3227 = zext i8 %r3226 to i32
  %r3228 = uitofp nneg i32 %r3227 to double
  br label %tav.get.merge.422

tav.k.i16.426:                                    ; preds = %tav.kd2.433
  %r3229 = shl nuw nsw i64 %r3200, 1
  %r3230 = add nuw nsw i64 %r3208, %r3229
  %r3231 = inttoptr i64 %r3230 to ptr
  %r3232 = load i16, ptr %r3231, align 2
  %r3233 = sext i16 %r3232 to i32
  %r3234 = sitofp i32 %r3233 to double
  br label %tav.get.merge.422

tav.k.u16.427:                                    ; preds = %tav.kd3.434
  %r3235 = shl nuw nsw i64 %r3200, 1
  %r3236 = add nuw nsw i64 %r3208, %r3235
  %r3237 = inttoptr i64 %r3236 to ptr
  %r3238 = load i16, ptr %r3237, align 2
  %r3239 = zext i16 %r3238 to i32
  %r3240 = uitofp nneg i32 %r3239 to double
  br label %tav.get.merge.422

tav.k.i32.428:                                    ; preds = %tav.kd4.435
  %r3241 = shl nuw nsw i64 %r3200, 2
  %r3242 = add nuw nsw i64 %r3208, %r3241
  %r3243 = inttoptr i64 %r3242 to ptr
  %r3244 = load i32, ptr %r3243, align 4
  %r3245 = sitofp i32 %r3244 to double
  br label %tav.get.merge.422

tav.k.u32.429:                                    ; preds = %tav.kd5.436
  %r3246 = shl nuw nsw i64 %r3200, 2
  %r3247 = add nuw nsw i64 %r3208, %r3246
  %r3248 = inttoptr i64 %r3247 to ptr
  %r3249 = load i32, ptr %r3248, align 4
  %r3250 = uitofp i32 %r3249 to double
  br label %tav.get.merge.422

tav.k.f32.430:                                    ; preds = %tav.kd6.437
  %r3251 = shl nuw nsw i64 %r3200, 2
  %r3252 = add nuw nsw i64 %r3208, %r3251
  %r3253 = inttoptr i64 %r3252 to ptr
  %r3254 = load float, ptr %r3253, align 4
  %r3255 = fpext float %r3254 to double
  br label %tav.get.merge.422

tav.k.f64.431:                                    ; preds = %tav.kd7.438
  %r3256 = shl nuw nsw i64 %r3200, 3
  %r3257 = add nuw nsw i64 %r3208, %r3256
  %r3258 = inttoptr i64 %r3257 to ptr
  %r3259 = load double, ptr %r3258, align 8
  br label %tav.get.merge.422

tav.kd1.432:                                      ; preds = %tav.get.load.420
  %r3210 = icmp eq i64 %r3199, 1
  br i1 %r3210, label %tav.k.u8.425, label %tav.kd2.433

tav.kd2.433:                                      ; preds = %tav.kd1.432
  %r3211 = icmp eq i64 %r3199, 2
  br i1 %r3211, label %tav.k.i16.426, label %tav.kd3.434

tav.kd3.434:                                      ; preds = %tav.kd2.433
  %r3212 = icmp eq i64 %r3199, 3
  br i1 %r3212, label %tav.k.u16.427, label %tav.kd4.435

tav.kd4.435:                                      ; preds = %tav.kd3.434
  %r3213 = icmp eq i64 %r3199, 4
  br i1 %r3213, label %tav.k.i32.428, label %tav.kd5.436

tav.kd5.436:                                      ; preds = %tav.kd4.435
  %r3214 = icmp eq i64 %r3199, 5
  br i1 %r3214, label %tav.k.u32.429, label %tav.kd6.437

tav.kd6.437:                                      ; preds = %tav.kd5.436
  %r3215 = icmp eq i64 %r3199, 6
  br i1 %r3215, label %tav.k.f32.430, label %tav.kd7.438

tav.kd7.438:                                      ; preds = %tav.kd6.437
  %r3216 = icmp eq i64 %r3199, 7
  br i1 %r3216, label %tav.k.f64.431, label %tav.k.u8.425

arrlike.ic.header.439:                            ; preds = %tav.get.slow.421
  %r3275 = fptosi double %r3166 to i64
  %r3276 = sitofp i64 %r3275 to double
  %r3277 = fcmp oeq double %r3276, %r3166
  %r3278 = sub nuw nsw i64 %r3264, 8
  %r3279 = inttoptr i64 %r3278 to ptr
  %r3280 = load i8, ptr %r3279, align 1
  %r3282 = sub nuw nsw i64 %r3264, 7
  %r3283 = inttoptr i64 %r3282 to ptr
  %r3284 = load i8, ptr %r3283, align 1
  %r3285 = and i8 %r3284, -128
  %r3286 = icmp eq i8 %r3285, 0
  %r3287 = and i1 %r3277, %r3286
  br i1 %r3287, label %arrlike.ic.brand.440, label %arrlike.ic.miss.458

arrlike.ic.brand.440:                             ; preds = %arrlike.ic.header.439
  %r3281 = icmp eq i8 %r3280, 1
  br i1 %r3281, label %arrlike.ic.array_guard.441, label %arrlike.elem.kind.459

arrlike.ic.array_guard.441:                       ; preds = %arrlike.ic.brand.440
  %r3319 = sub nuw nsw i64 %r3264, 6
  %r3320 = inttoptr i64 %r3319 to ptr
  %r3321 = load i16, ptr %r3320, align 2
  %r3322 = and i16 %r3321, 1024
  %r3323 = icmp eq i16 %r3322, 0
  %r3324 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3325 = icmp eq i8 %r3324, 0
  %r3326 = inttoptr i64 %r3264 to ptr
  %r3327 = load i32, ptr %r3326, align 4
  %r3328 = add nuw nsw i64 %r3264, 4
  %r3329 = inttoptr i64 %r3328 to ptr
  %r3330 = load i32, ptr %r3329, align 4
  %r3331 = zext i32 %r3327 to i64
  %r3332 = zext i32 %r3330 to i64
  %r3333 = icmp ult i64 %r3275, %r3331
  %r3334 = icmp ule i64 %r3331, %r3332
  %r3335 = and i1 %r3323, %r3325
  %r3336 = and i1 %r3335, %r3333
  %r3337 = and i1 %r3336, %r3334
  br i1 %r3337, label %arrlike.ic.array_load.442, label %arrlike.ic.miss.458

arrlike.ic.array_load.442:                        ; preds = %arrlike.ic.array_guard.441
  %r3338 = add nuw nsw i64 %r3275, 1
  %r3339 = getelementptr inbounds nuw i64, ptr %r3326, i64 %r3338
  %r3340 = load double, ptr %r3339, align 8
  %r3341 = bitcast double %r3340 to i64
  %r3342 = icmp eq i64 %r3341, 9222246136947933200
  %r3344 = select i1 %r3342, double 0x7FFC000000000001, double %r3340
  br label %tav.get.merge.422

arrlike.ic.shape.443:                             ; preds = %arrlike.elem.store.461, %arrlike.elem.meta.460
  %r3346 = inttoptr i64 %r3264 to ptr
  %r3347 = load i32, ptr %r3346, align 4
  %r3348 = add nuw nsw i64 %r3264, 4
  %r3349 = inttoptr i64 %r3348 to ptr
  %r3350 = load i32, ptr %r3349, align 4
  %r3351 = zext i32 %r3347 to i64
  %r3352 = zext i32 %r3350 to i64
  %r3353 = shl nuw i64 %r3351, 32
  %r3354 = or i64 %r3353, %r3352
  %r3355 = getelementptr i64, ptr %r3262, i64 0
  %r3356 = load i64, ptr %r3355, align 8
  %r3357 = icmp ne i64 %r3356, 0
  %r3358 = and i1 true, %r3357
  br i1 %r3358, label %arrlike.ic.identity.444, label %arrlike.ic.miss.458

arrlike.ic.identity.444:                          ; preds = %arrlike.ic.shape.443
  %r3359 = and i64 %r3356, -9223372036854775808
  %1 = icmp slt i64 %r3356, 0
  br i1 %1, label %arrlike.ic.family_meta.446, label %arrlike.ic.exact.445

arrlike.ic.exact.445:                             ; preds = %arrlike.ic.identity.444
  %r3361 = icmp eq i64 %r3354, %r3356
  br i1 %r3361, label %arrlike.ic.bounds.448, label %arrlike.ic.miss.458

arrlike.ic.family_meta.446:                       ; preds = %arrlike.ic.identity.444
  %r3362 = add nuw nsw i64 %r3264, 8
  %r3363 = inttoptr i64 %r3362 to ptr
  %r3364 = load i64, ptr %r3363, align 8
  %r3365 = icmp ne i64 %r3364, 0
  br i1 %r3365, label %arrlike.ic.family_token.447, label %arrlike.ic.miss.458

arrlike.ic.family_token.447:                      ; preds = %arrlike.ic.family_meta.446
  %r3366 = inttoptr i64 %r3364 to ptr
  %r3367 = getelementptr i64, ptr %r3366, i64 6
  %r3368 = load i64, ptr %r3367, align 8
  %r3369 = icmp eq i64 %r3368, %r3356
  br i1 %r3369, label %arrlike.ic.bounds.448, label %arrlike.ic.miss.458

arrlike.ic.bounds.448:                            ; preds = %arrlike.ic.family_token.447, %arrlike.ic.exact.445
  %r3370 = getelementptr i64, ptr %r3260, i64 1
  %r3371 = load i64, ptr %r3370, align 8
  %r3372 = getelementptr i64, ptr %r3260, i64 2
  %r3373 = load i64, ptr %r3372, align 8
  %r3374 = getelementptr i64, ptr %r3260, i64 3
  %r3375 = load i64, ptr %r3374, align 8
  %r3376 = getelementptr i64, ptr %r3260, i64 4
  %r3377 = load i64, ptr %r3376, align 8
  %r3378 = icmp ult i64 %r3371, %r3377
  br i1 %r3378, label %arrlike.ic.length_inline.449, label %arrlike.ic.length_spill_meta.450

arrlike.ic.length_inline.449:                     ; preds = %arrlike.ic.bounds.448
  %r3379 = shl i64 %r3371, 3
  %r3380 = add i64 %r3379, 16
  %r3381 = add i64 %r3264, %r3380
  %r3382 = inttoptr i64 %r3381 to ptr
  %r3383 = load double, ptr %r3382, align 8
  br label %arrlike.ic.range.453

arrlike.ic.length_spill_meta.450:                 ; preds = %arrlike.ic.bounds.448
  %r3384 = add nuw nsw i64 %r3264, 8
  %r3385 = inttoptr i64 %r3384 to ptr
  %r3386 = load i64, ptr %r3385, align 8
  %r3387 = icmp ne i64 %r3386, 0
  br i1 %r3387, label %arrlike.ic.length_spill_ptr.451, label %arrlike.ic.miss.458

arrlike.ic.length_spill_ptr.451:                  ; preds = %arrlike.ic.length_spill_meta.450
  %r3388 = inttoptr i64 %r3386 to ptr
  %r3389 = getelementptr i64, ptr %r3388, i64 4
  %r3390 = load i64, ptr %r3389, align 8
  %r3391 = icmp ne i64 %r3390, 0
  %r3392 = select i1 %r3391, i64 %r3390, i64 %r3386
  %r3393 = inttoptr i64 %r3392 to ptr
  %r3394 = load i32, ptr %r3393, align 4
  %r3395 = zext i32 %r3394 to i64
  %r3396 = icmp ult i64 %r3371, %r3395
  %r3397 = and i1 %r3391, %r3396
  br i1 %r3397, label %arrlike.ic.length_spill_load.452, label %arrlike.ic.miss.458

arrlike.ic.length_spill_load.452:                 ; preds = %arrlike.ic.length_spill_ptr.451
  %r3398 = add nuw nsw i64 %r3371, 1
  %r3399 = getelementptr inbounds nuw i64, ptr %r3393, i64 %r3398
  %r3400 = load double, ptr %r3399, align 8
  br label %arrlike.ic.range.453

arrlike.ic.range.453:                             ; preds = %arrlike.ic.length_spill_load.452, %arrlike.ic.length_inline.449
  %r3401 = phi double [ %r3383, %arrlike.ic.length_inline.449 ], [ %r3400, %arrlike.ic.length_spill_load.452 ]
  %r3402 = fcmp olt double %r3166, %r3401
  %r3403 = icmp ult i64 %r3275, %r3375
  %r3404 = and i1 %r3402, %r3403
  %r3405 = add i64 %r3373, %r3275
  %r3406 = icmp ult i64 %r3405, %r3377
  %r3407 = and i1 %r3404, %r3406
  %r3408 = xor i1 %r3406, true
  %r3409 = and i1 %r3404, %r3408
  br i1 %r3407, label %arrlike.ic.inline.454, label %arrlike.ic.spill_or_miss.465

arrlike.ic.inline.454:                            ; preds = %arrlike.ic.range.453
  %r3410 = shl i64 %r3405, 3
  %r3411 = add i64 %r3410, 16
  %r3412 = add i64 %r3264, %r3411
  %r3413 = inttoptr i64 %r3412 to ptr
  %r3414 = load double, ptr %r3413, align 8
  br label %tav.get.merge.422

arrlike.ic.spill.455:                             ; preds = %arrlike.ic.spill_or_miss.465
  %r3415 = add nuw nsw i64 %r3264, 8
  %r3416 = inttoptr i64 %r3415 to ptr
  %r3417 = load i64, ptr %r3416, align 8
  %r3418 = icmp ne i64 %r3417, 0
  br i1 %r3418, label %arrlike.ic.spill_ptr.456, label %arrlike.ic.miss.458

arrlike.ic.spill_ptr.456:                         ; preds = %arrlike.ic.spill.455
  %r3419 = inttoptr i64 %r3417 to ptr
  %r3420 = getelementptr i64, ptr %r3419, i64 4
  %r3421 = load i64, ptr %r3420, align 8
  %r3422 = icmp ne i64 %r3421, 0
  %r3423 = select i1 %r3422, i64 %r3421, i64 %r3417
  %r3424 = inttoptr i64 %r3423 to ptr
  %r3425 = load i32, ptr %r3424, align 4
  %r3426 = zext i32 %r3425 to i64
  %r3427 = icmp ult i64 %r3405, %r3426
  %r3428 = and i1 %r3422, %r3427
  br i1 %r3428, label %arrlike.ic.spill_load.457, label %arrlike.ic.miss.458

arrlike.ic.spill_load.457:                        ; preds = %arrlike.ic.spill_ptr.456
  %r3429 = add nuw nsw i64 %r3405, 1
  %r3430 = getelementptr inbounds nuw i64, ptr %r3424, i64 %r3429
  %r3431 = load double, ptr %r3430, align 8
  br label %tav.get.merge.422

arrlike.ic.miss.458:                              ; preds = %arrlike.ic.spill_or_miss.465, %arrlike.elem.load.463, %arrlike.elem.bounds.462, %arrlike.elem.kind.459, %arrlike.ic.spill_ptr.456, %arrlike.ic.spill.455, %arrlike.ic.length_spill_ptr.451, %arrlike.ic.length_spill_meta.450, %arrlike.ic.family_token.447, %arrlike.ic.family_meta.446, %arrlike.ic.exact.445, %arrlike.ic.shape.443, %arrlike.ic.array_guard.441, %arrlike.ic.header.439, %tav.get.slow.421
  %statepoint_token751 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r3165, double %r3166, ptr @perry_ic_test_json_large_string_emitters_ts__12, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.7.relocated746, ptr addrspace(1) %rs4gc.s51, ptr addrspace(1) %r8.0.relocated747, ptr addrspace(1) %rs4gc.s15.relocated748, ptr addrspace(1) %rs4gc.s13.relocated749, ptr addrspace(1) %rs4gc.s9.relocated750) ]
  %r3432752 = call double @llvm.experimental.gc.result.f64(token %statepoint_token751)
  %r497.7.relocated753 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token751, i32 0, i32 0) ; (%r497.7.relocated746, %r497.7.relocated746)
  %rs4gc.s51.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token751, i32 1, i32 1) ; (%rs4gc.s51, %rs4gc.s51)
  %r8.0.relocated754 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token751, i32 2, i32 2) ; (%r8.0.relocated747, %r8.0.relocated747)
  %rs4gc.s15.relocated755 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token751, i32 3, i32 3) ; (%rs4gc.s15.relocated748, %rs4gc.s15.relocated748)
  %rs4gc.s13.relocated756 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token751, i32 4, i32 4) ; (%rs4gc.s13.relocated749, %rs4gc.s13.relocated749)
  %rs4gc.s9.relocated757 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token751, i32 5, i32 5) ; (%rs4gc.s9.relocated750, %rs4gc.s9.relocated750)
  br label %tav.get.merge.422

arrlike.elem.kind.459:                            ; preds = %arrlike.ic.brand.440
  %r3288 = icmp eq i8 %r3280, 2
  br i1 %r3288, label %arrlike.elem.meta.460, label %arrlike.ic.miss.458

arrlike.elem.meta.460:                            ; preds = %arrlike.elem.kind.459
  %r3289 = add nuw nsw i64 %r3264, 8
  %r3290 = inttoptr i64 %r3289 to ptr
  %r3291 = load i64, ptr %r3290, align 8
  %r3292 = icmp ne i64 %r3291, 0
  br i1 %r3292, label %arrlike.elem.store.461, label %arrlike.ic.shape.443

arrlike.elem.store.461:                           ; preds = %arrlike.elem.meta.460
  %r3293 = inttoptr i64 %r3291 to ptr
  %r3294 = getelementptr i64, ptr %r3293, i64 12
  %r3295 = load i64, ptr %r3294, align 8
  %r3296 = icmp ne i64 %r3295, 0
  br i1 %r3296, label %arrlike.elem.bounds.462, label %arrlike.ic.shape.443

arrlike.elem.bounds.462:                          ; preds = %arrlike.elem.store.461
  %r3297 = sub i64 %r3295, 8
  %r3298 = inttoptr i64 %r3297 to ptr
  %r3299 = load i8, ptr %r3298, align 1
  %r3300 = icmp eq i8 %r3299, 1
  %r3301 = sub i64 %r3295, 7
  %r3302 = inttoptr i64 %r3301 to ptr
  %r3303 = load i8, ptr %r3302, align 1
  %r3304 = and i8 %r3303, -128
  %r3305 = icmp eq i8 %r3304, 0
  %r3306 = inttoptr i64 %r3295 to ptr
  %r3307 = load i32, ptr %r3306, align 4
  %r3308 = zext i32 %r3307 to i64
  %r3309 = icmp ult i64 %r3275, %r3308
  %r3310 = and i1 %r3300, %r3305
  %r3311 = and i1 %r3310, %r3309
  br i1 %r3311, label %arrlike.elem.load.463, label %arrlike.ic.miss.458

arrlike.elem.load.463:                            ; preds = %arrlike.elem.bounds.462
  %r3312 = shl nuw nsw i64 %r3275, 3
  %r3313 = add i64 %r3295, 8
  %r3314 = add i64 %r3313, %r3312
  %r3315 = inttoptr i64 %r3314 to ptr
  %r3316 = load double, ptr %r3315, align 8
  %r3317 = bitcast double %r3316 to i64
  %r3318 = icmp eq i64 %r3317, 9222246136947933200
  br i1 %r3318, label %arrlike.ic.miss.458, label %arrlike.elem.value.464

arrlike.elem.value.464:                           ; preds = %arrlike.elem.load.463
  br label %tav.get.merge.422

arrlike.ic.spill_or_miss.465:                     ; preds = %arrlike.ic.range.453
  br i1 %r3409, label %arrlike.ic.spill.455, label %arrlike.ic.miss.458

shadow.root.barrier.466:                          ; preds = %tav.get.merge.422
  call void @js_write_barrier_root_nanbox(i64 %r3435) #7
  br label %shadow.root.barrier.done.467

shadow.root.barrier.done.467:                     ; preds = %shadow.root.barrier.466, %tav.get.merge.422
  %r3438.rs4i = ptrtoint ptr addrspace(1) %.271337 to i64
  %r3438.rs4o = call i64 asm "", "=r,0"(i64 %r3438.rs4i) #7
  %r3438 = bitcast i64 %r3438.rs4o to double
  %r3439 = load double, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  %r3441 = sitofp i32 %r2968.0 to double
  %r3442 = load double, ptr @test_json_large_string_emitters_ts_.str.8.handle, align 8
  %r3444 = getelementptr double, ptr %r3443, i64 0
  store double %r3438, ptr %r3444, align 8
  %r3445 = getelementptr double, ptr %r3443, i64 1
  store double %r3439, ptr %r3445, align 8
  %r3446 = getelementptr double, ptr %r3443, i64 2
  store double %r3441, ptr %r3446, align 8
  %r3447 = getelementptr double, ptr %r3443, i64 3
  store double %r3442, ptr %r3447, align 8
  %r3448 = ptrtoint ptr %r3443 to i64
  %statepoint_token758 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r3448, i32 4, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.51495, ptr addrspace(1) %.271337, ptr addrspace(1) %.271453, ptr addrspace(1) %.301395, ptr addrspace(1) %.30, ptr addrspace(1) %.01502, ptr addrspace(1) %rs4gc.s52) ]
  %r3449759 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token758)
  %r497.7.relocated760 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token758, i32 0, i32 0) ; (%.51495, %.51495)
  %r8.0.relocated761 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token758, i32 1, i32 1) ; (%.271337, %.271337)
  %rs4gc.s15.relocated762 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token758, i32 2, i32 2) ; (%.271453, %.271453)
  %rs4gc.s13.relocated763 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token758, i32 3, i32 3) ; (%.301395, %.301395)
  %rs4gc.s9.relocated764 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token758, i32 4, i32 4) ; (%.30, %.30)
  %rs4gc.s51.relocated765 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token758, i32 5, i32 5) ; (%.01502, %.01502)
  %rs4gc.s52.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token758, i32 6, i32 6) ; (%rs4gc.s52, %rs4gc.s52)
  %r3450 = or i64 %r3449759, 9223090561878065152
  %r3451 = bitcast i64 %r3450 to double
  %r3452.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s52.relocated to i64
  %r3452 = call i64 asm "", "=r,0"(i64 %r3452.rs4i) #7
  %r3453 = bitcast i64 %r3452 to double
  %r3454 = and i64 %r3452, 9221120237041090560
  %r3455 = icmp ne i64 %r3454, 9221120237041090560
  %r3456 = and i64 %r3450, 9221120237041090560
  %r3457 = icmp ne i64 %r3456, 9221120237041090560
  %r3458 = and i1 %r3455, %r3457
  br i1 %r3458, label %dyncmp.num.468, label %dyncmp.slow.469

dyncmp.num.468:                                   ; preds = %shadow.root.barrier.done.467
  %r3459 = fcmp oeq double %r3453, %r3451
  %r3460 = select i1 %r3459, i64 9222246136947933188, i64 9222246136947933187
  br label %dyncmp.merge.470

dyncmp.slow.469:                                  ; preds = %shadow.root.barrier.done.467
  %statepoint_token766 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_eq, i32 2, i32 0, i64 %r3452, i64 %r3450, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.7.relocated760, ptr addrspace(1) %r8.0.relocated761, ptr addrspace(1) %rs4gc.s15.relocated762, ptr addrspace(1) %rs4gc.s13.relocated763, ptr addrspace(1) %rs4gc.s9.relocated764, ptr addrspace(1) %rs4gc.s51.relocated765) ]
  %r3461767 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token766)
  %r497.7.relocated768 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 0, i32 0) ; (%r497.7.relocated760, %r497.7.relocated760)
  %r8.0.relocated769 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 1, i32 1) ; (%r8.0.relocated761, %r8.0.relocated761)
  %rs4gc.s15.relocated770 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 2, i32 2) ; (%rs4gc.s15.relocated762, %rs4gc.s15.relocated762)
  %rs4gc.s13.relocated771 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 3, i32 3) ; (%rs4gc.s13.relocated763, %rs4gc.s13.relocated763)
  %rs4gc.s9.relocated772 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 4, i32 4) ; (%rs4gc.s9.relocated764, %rs4gc.s9.relocated764)
  %rs4gc.s51.relocated773 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 5, i32 5) ; (%rs4gc.s51.relocated765, %rs4gc.s51.relocated765)
  br label %dyncmp.merge.470

dyncmp.merge.470:                                 ; preds = %dyncmp.slow.469, %dyncmp.num.468
  %.11503 = phi ptr addrspace(1) [ %rs4gc.s51.relocated765, %dyncmp.num.468 ], [ %rs4gc.s51.relocated773, %dyncmp.slow.469 ]
  %.61496 = phi ptr addrspace(1) [ %r497.7.relocated760, %dyncmp.num.468 ], [ %r497.7.relocated768, %dyncmp.slow.469 ]
  %.281454 = phi ptr addrspace(1) [ %rs4gc.s15.relocated762, %dyncmp.num.468 ], [ %rs4gc.s15.relocated770, %dyncmp.slow.469 ]
  %.311396 = phi ptr addrspace(1) [ %rs4gc.s13.relocated763, %dyncmp.num.468 ], [ %rs4gc.s13.relocated771, %dyncmp.slow.469 ]
  %.281338 = phi ptr addrspace(1) [ %r8.0.relocated761, %dyncmp.num.468 ], [ %r8.0.relocated769, %dyncmp.slow.469 ]
  %.31 = phi ptr addrspace(1) [ %rs4gc.s9.relocated764, %dyncmp.num.468 ], [ %rs4gc.s9.relocated772, %dyncmp.slow.469 ]
  %r3462 = phi i64 [ %r3460, %dyncmp.num.468 ], [ %r3461767, %dyncmp.slow.469 ]
  %r3463 = icmp eq i64 %r3462, 9222246136947933188
  %r3464 = xor i1 %r3463, true
  %r3465 = select i1 %r3464, i64 9222246136947933188, i64 9222246136947933187
  %r3466 = bitcast i64 %r3465 to double
  %r3467 = icmp eq i64 %r3465, 9222246136947933188
  br i1 %r3467, label %logical.merge.472, label %logical.then.471

logical.then.471:                                 ; preds = %dyncmp.merge.470
  %r3468.rs4i = ptrtoint ptr addrspace(1) %.11503 to i64
  %r3468.rs4o = call i64 asm "", "=r,0"(i64 %r3468.rs4i) #7
  %r3468 = bitcast i64 %r3468.rs4o to double
  %r3469 = bitcast double %r3468 to i64
  %r3470 = and i64 %r3469, 281474976710655
  %r3471 = lshr i64 %r3469, 48
  %r3472 = and i64 %r3471, 65533
  %r3473 = icmp eq i64 %r3472, 32765
  br i1 %r3473, label %pget.recv_ok.474, label %pget.recv_other.478

logical.merge.472:                                ; preds = %streqlit.merge.512, %dyncmp.merge.470
  %.71497 = phi ptr addrspace(1) [ %.61496, %dyncmp.merge.470 ], [ %.81498, %streqlit.merge.512 ]
  %.291455 = phi ptr addrspace(1) [ %.281454, %dyncmp.merge.470 ], [ %.301456, %streqlit.merge.512 ]
  %.321397 = phi ptr addrspace(1) [ %.311396, %dyncmp.merge.470 ], [ %.331398, %streqlit.merge.512 ]
  %.291339 = phi ptr addrspace(1) [ %.281338, %dyncmp.merge.470 ], [ %.301340, %streqlit.merge.512 ]
  %.32 = phi ptr addrspace(1) [ %.31, %dyncmp.merge.470 ], [ %.33, %streqlit.merge.512 ]
  %r3644 = phi double [ %r3466, %dyncmp.merge.470 ], [ %r3642, %streqlit.merge.512 ]
  %r3645 = phi i1 [ true, %dyncmp.merge.470 ], [ %r3643, %streqlit.merge.512 ]
  br i1 %r3645, label %if.then.513, label %if.else.514

pget.recv_sso.473:                                ; preds = %pget.recv_other.478
  %r3611 = load double, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  %r3612 = bitcast double %r3611 to i64
  %r3613 = and i64 %r3612, 281474976710655
  %statepoint_token774 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3469, i64 %r3613, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61496, ptr addrspace(1) %.281338, ptr addrspace(1) %.281454, ptr addrspace(1) %.311396, ptr addrspace(1) %.31) ]
  %r3614775 = call double @llvm.experimental.gc.result.f64(token %statepoint_token774)
  %r497.7.relocated776 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token774, i32 0, i32 0) ; (%.61496, %.61496)
  %r8.0.relocated777 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token774, i32 1, i32 1) ; (%.281338, %.281338)
  %rs4gc.s15.relocated778 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token774, i32 2, i32 2) ; (%.281454, %.281454)
  %rs4gc.s13.relocated779 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token774, i32 3, i32 3) ; (%.311396, %.311396)
  %rs4gc.s9.relocated780 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token774, i32 4, i32 4) ; (%.31, %.31)
  br label %pget.recv_merge.477

pget.recv_ok.474:                                 ; preds = %logical.then.471
  %r3480 = icmp ugt i64 %r3470, 1048575
  br i1 %r3480, label %pic.recv_hdr.495, label %pic.miss.cold.492

pget.recv_bad.475:                                ; preds = %pget.check_class_ref.479
  %r3603 = icmp eq i64 %r3469, 9222246136947933185
  %r3604 = icmp eq i64 %r3469, 9222246136947933186
  %r3605 = or i1 %r3603, %r3604
  br i1 %r3605, label %pget.throw_nullish.502, label %pget.recv_undef_return.503

pget.recv_class_ref.476:                          ; preds = %pget.check_class_ref.479
  %r3476 = load double, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  %r3477 = bitcast double %r3476 to i64
  %r3478 = and i64 %r3477, 281474976710655
  %statepoint_token781 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7058970246387859469, i64 %r3469, i64 %r3478, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61496, ptr addrspace(1) %.281338, ptr addrspace(1) %.281454, ptr addrspace(1) %.311396, ptr addrspace(1) %.31) ]
  %r3479782 = call double @llvm.experimental.gc.result.f64(token %statepoint_token781)
  %r497.7.relocated783 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token781, i32 0, i32 0) ; (%.61496, %.61496)
  %r8.0.relocated784 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token781, i32 1, i32 1) ; (%.281338, %.281338)
  %rs4gc.s15.relocated785 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token781, i32 2, i32 2) ; (%.281454, %.281454)
  %rs4gc.s13.relocated786 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token781, i32 3, i32 3) ; (%.311396, %.311396)
  %rs4gc.s9.relocated787 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token781, i32 4, i32 4) ; (%.31, %.31)
  br label %pget.recv_merge.477

pget.recv_merge.477:                              ; preds = %pget.recv_undef_return.503, %pic.merge.494, %pget.recv_class_ref.476, %pget.recv_sso.473
  %.81498 = phi ptr addrspace(1) [ %.91499, %pic.merge.494 ], [ %r497.7.relocated776, %pget.recv_sso.473 ], [ %r497.7.relocated783, %pget.recv_class_ref.476 ], [ %r497.7.relocated805, %pget.recv_undef_return.503 ]
  %.301456 = phi ptr addrspace(1) [ %.311457, %pic.merge.494 ], [ %rs4gc.s15.relocated778, %pget.recv_sso.473 ], [ %rs4gc.s15.relocated785, %pget.recv_class_ref.476 ], [ %rs4gc.s15.relocated807, %pget.recv_undef_return.503 ]
  %.331398 = phi ptr addrspace(1) [ %.341399, %pic.merge.494 ], [ %rs4gc.s13.relocated779, %pget.recv_sso.473 ], [ %rs4gc.s13.relocated786, %pget.recv_class_ref.476 ], [ %rs4gc.s13.relocated808, %pget.recv_undef_return.503 ]
  %.301340 = phi ptr addrspace(1) [ %.311341, %pic.merge.494 ], [ %r8.0.relocated777, %pget.recv_sso.473 ], [ %r8.0.relocated784, %pget.recv_class_ref.476 ], [ %r8.0.relocated806, %pget.recv_undef_return.503 ]
  %.33 = phi ptr addrspace(1) [ %.34, %pic.merge.494 ], [ %rs4gc.s9.relocated780, %pget.recv_sso.473 ], [ %rs4gc.s9.relocated787, %pget.recv_class_ref.476 ], [ %rs4gc.s9.relocated809, %pget.recv_undef_return.503 ]
  %r3615 = phi double [ %r3602, %pic.merge.494 ], [ %r3610804, %pget.recv_undef_return.503 ], [ %r3614775, %pget.recv_sso.473 ], [ %r3479782, %pget.recv_class_ref.476 ]
  %r3616 = load double, ptr @test_json_large_string_emitters_ts_.str.4.handle, align 8
  %r3617 = bitcast double %r3615 to i64
  %r3618 = bitcast double %r3616 to i64
  %r3619 = icmp eq i64 %r3617, %r3618
  br i1 %r3619, label %streqlit.true.510, label %streqlit.sso.504

pget.recv_other.478:                              ; preds = %logical.then.471
  %r3474 = icmp eq i64 %r3471, 32761
  br i1 %r3474, label %pget.recv_sso.473, label %pget.check_class_ref.479

pget.check_class_ref.479:                         ; preds = %pget.recv_other.478
  %r3475 = icmp eq i64 %r3471, 32766
  br i1 %r3475, label %pget.recv_class_ref.476, label %pget.recv_bad.475

pic.hit.480:                                      ; preds = %pic.token.496
  %r3505 = getelementptr i64, ptr %r3490, i64 1
  %r3506 = load i64, ptr %r3505, align 8
  %r3507 = and i64 %r3506, 1073741824
  %r3508 = icmp ne i64 %r3507, 0
  br i1 %r3508, label %pic.hit.overflow.497, label %pic.hit.inline.498

pic.hit.live.481:                                 ; preds = %pic.hit.inline.498
  br label %pic.merge.494

pic.prefix.guard.482:                             ; preds = %pic.token.496
  %r3521 = getelementptr i64, ptr %r3490, i64 2
  %r3522 = load i64, ptr %r3521, align 8
  %r3523 = icmp ne i64 %r3522, 0
  br i1 %r3523, label %pic.prefix.meta.483, label %pic.miss.491

pic.prefix.meta.483:                              ; preds = %pic.prefix.guard.482
  %r3524 = add nuw nsw i64 %r3470, 8
  %r3525 = inttoptr i64 %r3524 to ptr
  %r3526 = load i64, ptr %r3525, align 8
  %r3527 = icmp ne i64 %r3526, 0
  br i1 %r3527, label %pic.prefix.token.484, label %pic.miss.491

pic.prefix.token.484:                             ; preds = %pic.prefix.meta.483
  %r3528 = inttoptr i64 %r3526 to ptr
  %r3529 = getelementptr i64, ptr %r3528, i64 6
  %r3530 = load i64, ptr %r3529, align 8
  %r3531 = icmp eq i64 %r3530, %r3522
  br i1 %r3531, label %pic.prefix.hit.485, label %pic.miss.491

pic.prefix.hit.485:                               ; preds = %pic.prefix.token.484
  %r3532 = getelementptr i64, ptr %r3490, i64 1
  %r3533 = load i64, ptr %r3532, align 8
  %r3534 = shl i64 %r3533, 3
  %r3535 = add nuw nsw i64 %r3470, 16
  %r3536 = add i64 %r3535, %r3534
  %r3537 = inttoptr i64 %r3536 to ptr
  %r3538 = load double, ptr %r3537, align 8
  br label %pic.merge.494

pic.desc.classify.486:                            ; preds = %pic.recv_hdr.495
  %r3494 = and i1 %r3484, %r3491
  br i1 %r3494, label %pic.desc.prefix.guard.487, label %pic.miss.cold.492

pic.desc.prefix.guard.487:                        ; preds = %pic.desc.classify.486
  %r3539 = getelementptr i64, ptr %r3490, i64 2
  %r3540 = load i64, ptr %r3539, align 8
  %r3541 = icmp ne i64 %r3540, 0
  br i1 %r3541, label %pic.desc.prefix.meta.488, label %pic.miss.cold.492

pic.desc.prefix.meta.488:                         ; preds = %pic.desc.prefix.guard.487
  %r3542 = add nuw nsw i64 %r3470, 8
  %r3543 = inttoptr i64 %r3542 to ptr
  %r3544 = load i64, ptr %r3543, align 8
  %r3545 = icmp ne i64 %r3544, 0
  br i1 %r3545, label %pic.desc.prefix.token.489, label %pic.miss.cold.492

pic.desc.prefix.token.489:                        ; preds = %pic.desc.prefix.meta.488
  %r3546 = inttoptr i64 %r3544 to ptr
  %r3547 = getelementptr i64, ptr %r3546, i64 6
  %r3548 = load i64, ptr %r3547, align 8
  %r3549 = icmp eq i64 %r3548, %r3540
  br i1 %r3549, label %pic.desc.prefix.hit.490, label %pic.miss.cold.492

pic.desc.prefix.hit.490:                          ; preds = %pic.desc.prefix.token.489
  %r3550 = getelementptr i64, ptr %r3490, i64 1
  %r3551 = load i64, ptr %r3550, align 8
  %r3552 = shl i64 %r3551, 3
  %r3553 = add nuw nsw i64 %r3470, 16
  %r3554 = add i64 %r3553, %r3552
  %r3555 = inttoptr i64 %r3554 to ptr
  %r3556 = load double, ptr %r3555, align 8
  br label %pic.merge.494

pic.miss.491:                                     ; preds = %pic.hit.inline.498, %pic.prefix.token.484, %pic.prefix.meta.483, %pic.prefix.guard.482
  %r3557 = getelementptr i64, ptr %r3490, i64 3
  %r3558 = load i64, ptr %r3557, align 8
  %r3559 = icmp sgt i64 %r3558, 0
  br i1 %r3559, label %pic.ways.499, label %pic.miss.call.493

pic.miss.cold.492:                                ; preds = %pic.desc.prefix.token.489, %pic.desc.prefix.meta.488, %pic.desc.prefix.guard.487, %pic.desc.classify.486, %pget.recv_ok.474
  br label %pic.miss.call.493

pic.miss.call.493:                                ; preds = %pic.way.load.500, %pic.ways.499, %pic.miss.cold.492, %pic.miss.491
  %r3598 = load double, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  %r3599 = bitcast double %r3598 to i64
  %r3600 = and i64 %r3599, 281474976710655
  %statepoint_token788 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r3470, i64 %r3600, ptr @perry_ic_test_json_large_string_emitters_ts__14, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61496, ptr addrspace(1) %.281338, ptr addrspace(1) %.281454, ptr addrspace(1) %.311396, ptr addrspace(1) %.31) ]
  %r3601789 = call double @llvm.experimental.gc.result.f64(token %statepoint_token788)
  %r497.7.relocated790 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 0, i32 0) ; (%.61496, %.61496)
  %r8.0.relocated791 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 1, i32 1) ; (%.281338, %.281338)
  %rs4gc.s15.relocated792 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 2, i32 2) ; (%.281454, %.281454)
  %rs4gc.s13.relocated793 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 3, i32 3) ; (%.311396, %.311396)
  %rs4gc.s9.relocated794 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token788, i32 4, i32 4) ; (%.31, %.31)
  br label %pic.merge.494

pic.merge.494:                                    ; preds = %pic.way.live.501, %pic.hit.overflow.497, %pic.miss.call.493, %pic.desc.prefix.hit.490, %pic.prefix.hit.485, %pic.hit.live.481
  %.91499 = phi ptr addrspace(1) [ %r497.7.relocated797, %pic.hit.overflow.497 ], [ %r497.7.relocated790, %pic.miss.call.493 ], [ %.61496, %pic.way.live.501 ], [ %.61496, %pic.hit.live.481 ], [ %.61496, %pic.prefix.hit.485 ], [ %.61496, %pic.desc.prefix.hit.490 ]
  %.311457 = phi ptr addrspace(1) [ %rs4gc.s15.relocated799, %pic.hit.overflow.497 ], [ %rs4gc.s15.relocated792, %pic.miss.call.493 ], [ %.281454, %pic.way.live.501 ], [ %.281454, %pic.hit.live.481 ], [ %.281454, %pic.prefix.hit.485 ], [ %.281454, %pic.desc.prefix.hit.490 ]
  %.341399 = phi ptr addrspace(1) [ %rs4gc.s13.relocated800, %pic.hit.overflow.497 ], [ %rs4gc.s13.relocated793, %pic.miss.call.493 ], [ %.311396, %pic.way.live.501 ], [ %.311396, %pic.hit.live.481 ], [ %.311396, %pic.prefix.hit.485 ], [ %.311396, %pic.desc.prefix.hit.490 ]
  %.311341 = phi ptr addrspace(1) [ %r8.0.relocated798, %pic.hit.overflow.497 ], [ %r8.0.relocated791, %pic.miss.call.493 ], [ %.281338, %pic.way.live.501 ], [ %.281338, %pic.hit.live.481 ], [ %.281338, %pic.prefix.hit.485 ], [ %.281338, %pic.desc.prefix.hit.490 ]
  %.34 = phi ptr addrspace(1) [ %rs4gc.s9.relocated801, %pic.hit.overflow.497 ], [ %rs4gc.s9.relocated794, %pic.miss.call.493 ], [ %.31, %pic.way.live.501 ], [ %.31, %pic.hit.live.481 ], [ %.31, %pic.prefix.hit.485 ], [ %.31, %pic.desc.prefix.hit.490 ]
  %r3602 = phi double [ %r3518, %pic.hit.live.481 ], [ %r3513796, %pic.hit.overflow.497 ], [ %r3538, %pic.prefix.hit.485 ], [ %r3556, %pic.desc.prefix.hit.490 ], [ %r3595, %pic.way.live.501 ], [ %r3601789, %pic.miss.call.493 ]
  br label %pget.recv_merge.477

pic.recv_hdr.495:                                 ; preds = %pget.recv_ok.474
  %r3481 = sub nuw nsw i64 %r3470, 8
  %r3482 = inttoptr i64 %r3481 to ptr
  %r3483 = load i8, ptr %r3482, align 1
  %r3484 = icmp eq i8 %r3483, 2
  %r3485 = sub nuw nsw i64 %r3470, 6
  %r3486 = inttoptr i64 %r3485 to ptr
  %r3487 = load i16, ptr %r3486, align 2
  %r3488 = and i16 %r3487, 2048
  %r3489 = icmp eq i16 %r3488, 0
  %r3490 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__14, align 8
  %r3491 = icmp ne ptr %r3490, null
  %r3492 = and i1 %r3484, %r3489
  %r3493 = and i1 %r3492, %r3491
  br i1 %r3493, label %pic.token.496, label %pic.desc.classify.486

pic.token.496:                                    ; preds = %pic.recv_hdr.495
  %r3495 = add nuw nsw i64 %r3470, 4
  %r3496 = inttoptr i64 %r3495 to ptr
  %r3497 = load i32, ptr %r3496, align 4
  %r3498 = zext i32 %r3497 to i64
  %r3499 = or i64 %r3498, 4611686018427387904
  %r3500 = icmp ne i32 %r3497, 0
  %r3501 = getelementptr i64, ptr %r3490, i64 0
  %r3502 = load i64, ptr %r3501, align 8
  %r3503 = icmp eq i64 %r3499, %r3502
  %r3504 = and i1 %r3503, %r3500
  br i1 %r3504, label %pic.hit.480, label %pic.prefix.guard.482

pic.hit.overflow.497:                             ; preds = %pic.hit.480
  %r3509 = load double, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  %r3510 = bitcast double %r3509 to i64
  %r3511 = and i64 %r3510, 281474976710655
  %r3512 = trunc i64 %r3506 to i32
  %statepoint_token795 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r3470, i64 %r3511, i32 %r3512, ptr @perry_ic_test_json_large_string_emitters_ts__14, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61496, ptr addrspace(1) %.281338, ptr addrspace(1) %.281454, ptr addrspace(1) %.311396, ptr addrspace(1) %.31) ]
  %r3513796 = call double @llvm.experimental.gc.result.f64(token %statepoint_token795)
  %r497.7.relocated797 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token795, i32 0, i32 0) ; (%.61496, %.61496)
  %r8.0.relocated798 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token795, i32 1, i32 1) ; (%.281338, %.281338)
  %rs4gc.s15.relocated799 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token795, i32 2, i32 2) ; (%.281454, %.281454)
  %rs4gc.s13.relocated800 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token795, i32 3, i32 3) ; (%.311396, %.311396)
  %rs4gc.s9.relocated801 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token795, i32 4, i32 4) ; (%.31, %.31)
  br label %pic.merge.494

pic.hit.inline.498:                               ; preds = %pic.hit.480
  %r3514 = shl i64 %r3506, 3
  %r3515 = add nuw nsw i64 %r3470, 16
  %r3516 = add i64 %r3515, %r3514
  %r3517 = inttoptr i64 %r3516 to ptr
  %r3518 = load double, ptr %r3517, align 8
  %r3519 = bitcast double %r3518 to i64
  %r3520 = icmp eq i64 %r3519, 9222246136947933200
  br i1 %r3520, label %pic.miss.491, label %pic.hit.live.481

pic.ways.499:                                     ; preds = %pic.miss.491
  %r3560 = getelementptr i64, ptr %r3490, i64 4
  %r3561 = load i64, ptr %r3560, align 8
  %r3562 = icmp eq i64 %r3561, %r3499
  %r3563 = getelementptr i64, ptr %r3490, i64 5
  %r3564 = load i64, ptr %r3563, align 8
  %r3565 = select i1 %r3562, i64 %r3564, i64 0
  %r3566 = getelementptr i64, ptr %r3490, i64 6
  %r3567 = load i64, ptr %r3566, align 8
  %r3568 = icmp eq i64 %r3567, %r3499
  %r3569 = getelementptr i64, ptr %r3490, i64 7
  %r3570 = load i64, ptr %r3569, align 8
  %r3571 = select i1 %r3568, i64 %r3570, i64 0
  %r3572 = getelementptr i64, ptr %r3490, i64 8
  %r3573 = load i64, ptr %r3572, align 8
  %r3574 = icmp eq i64 %r3573, %r3499
  %r3575 = getelementptr i64, ptr %r3490, i64 9
  %r3576 = load i64, ptr %r3575, align 8
  %r3577 = select i1 %r3574, i64 %r3576, i64 0
  %r3578 = getelementptr i64, ptr %r3490, i64 10
  %r3579 = load i64, ptr %r3578, align 8
  %r3580 = icmp eq i64 %r3579, %r3499
  %r3581 = getelementptr i64, ptr %r3490, i64 11
  %r3582 = load i64, ptr %r3581, align 8
  %r3583 = select i1 %r3580, i64 %r3582, i64 0
  %r3584 = or i1 %r3562, %r3568
  %r3585 = select i1 %r3562, i64 %r3565, i64 %r3571
  %r3586 = or i1 %r3574, %r3580
  %r3587 = select i1 %r3574, i64 %r3577, i64 %r3583
  %r3588 = or i1 %r3584, %r3586
  %r3589 = select i1 %r3584, i64 %r3585, i64 %r3587
  %r3590 = and i1 %r3500, %r3588
  br i1 %r3590, label %pic.way.load.500, label %pic.miss.call.493

pic.way.load.500:                                 ; preds = %pic.ways.499
  %r3591 = shl i64 %r3589, 3
  %r3592 = add nuw nsw i64 %r3470, 16
  %r3593 = add i64 %r3592, %r3591
  %r3594 = inttoptr i64 %r3593 to ptr
  %r3595 = load double, ptr %r3594, align 8
  %r3596 = bitcast double %r3595 to i64
  %r3597 = icmp eq i64 %r3596, 9222246136947933200
  br i1 %r3597, label %pic.miss.call.493, label %pic.way.live.501

pic.way.live.501:                                 ; preds = %pic.way.load.500
  br label %pic.merge.494

pget.throw_nullish.502:                           ; preds = %pget.recv_bad.475
  %r3606 = zext i1 %r3604 to i32
  %statepoint_token802 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r3606, ptr @test_json_large_string_emitters_ts_.str.3.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.503:                       ; preds = %pget.recv_bad.475
  %r3607 = load double, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  %r3608 = bitcast double %r3607 to i64
  %r3609 = and i64 %r3608, 281474976710655
  %statepoint_token803 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3469, i64 %r3609, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61496, ptr addrspace(1) %.281338, ptr addrspace(1) %.281454, ptr addrspace(1) %.311396, ptr addrspace(1) %.31) ]
  %r3610804 = call double @llvm.experimental.gc.result.f64(token %statepoint_token803)
  %r497.7.relocated805 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token803, i32 0, i32 0) ; (%.61496, %.61496)
  %r8.0.relocated806 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token803, i32 1, i32 1) ; (%.281338, %.281338)
  %rs4gc.s15.relocated807 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token803, i32 2, i32 2) ; (%.281454, %.281454)
  %rs4gc.s13.relocated808 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token803, i32 3, i32 3) ; (%.311396, %.311396)
  %rs4gc.s9.relocated809 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token803, i32 4, i32 4) ; (%.31, %.31)
  br label %pget.recv_merge.477

streqlit.sso.504:                                 ; preds = %pget.recv_merge.477
  %r3620 = icmp eq i64 %r3617, 9221405010559266405
  br i1 %r3620, label %streqlit.true.510, label %streqlit.tag.505

streqlit.tag.505:                                 ; preds = %streqlit.sso.504
  %r3621 = lshr i64 %r3617, 48
  %r3622 = icmp eq i64 %r3621, 32767
  %r3623 = and i64 %r3617, 281474976710655
  %r3624 = icmp ugt i64 %r3623, 4095
  %r3625 = and i1 %r3622, %r3624
  br i1 %r3625, label %streqlit.len.506, label %streqlit.false.511

streqlit.len.506:                                 ; preds = %streqlit.tag.505
  %r3626 = inttoptr i64 %r3623 to ptr
  %r3627 = getelementptr inbounds nuw i8, ptr %r3626, i64 4
  %r3628 = load i32, ptr %r3627, align 4
  %r3629 = icmp eq i32 %r3628, 3
  br i1 %r3629, label %streqlit.b0.507, label %streqlit.false.511

streqlit.b0.507:                                  ; preds = %streqlit.len.506
  %r3630 = getelementptr inbounds nuw i8, ptr %r3626, i64 20
  %r3631 = load i8, ptr %r3630, align 1
  %r3632 = icmp eq i8 %r3631, 101
  br i1 %r3632, label %streqlit.bl.508, label %streqlit.false.511

streqlit.bl.508:                                  ; preds = %streqlit.b0.507
  %r3633 = getelementptr inbounds nuw i8, ptr %r3626, i64 22
  %r3634 = load i8, ptr %r3633, align 1
  %r3635 = icmp eq i8 %r3634, 100
  br i1 %r3635, label %streqlit.bm.509, label %streqlit.false.511

streqlit.bm.509:                                  ; preds = %streqlit.bl.508
  %r3636 = getelementptr inbounds nuw i8, ptr %r3626, i64 21
  %r3637 = load i8, ptr %r3636, align 1
  %r3638 = icmp eq i8 %r3637, 110
  br i1 %r3638, label %streqlit.true.510, label %streqlit.false.511

streqlit.true.510:                                ; preds = %streqlit.bm.509, %streqlit.sso.504, %pget.recv_merge.477
  br label %streqlit.merge.512

streqlit.false.511:                               ; preds = %streqlit.bm.509, %streqlit.bl.508, %streqlit.b0.507, %streqlit.len.506, %streqlit.tag.505
  br label %streqlit.merge.512

streqlit.merge.512:                               ; preds = %streqlit.false.511, %streqlit.true.510
  %r3639 = phi i1 [ true, %streqlit.true.510 ], [ false, %streqlit.false.511 ]
  %r3640 = xor i1 %r3639, true
  %r3641 = select i1 %r3640, i64 9222246136947933188, i64 9222246136947933187
  %r3642 = bitcast i64 %r3641 to double
  %r3643 = icmp eq i64 %r3641, 9222246136947933188
  br label %logical.merge.472

if.then.513:                                      ; preds = %logical.merge.472
  %r3646 = load double, ptr @test_json_large_string_emitters_ts_.str.9.handle, align 8
  %statepoint_token810 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r3646, i32 0, i32 0)
  %r3647811 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token810)
  %r3648 = or i64 %r3647811, 9222527611924643840
  %r3649 = bitcast i64 %r3648 to double
  %statepoint_token812 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r3649, i32 0, i32 0)
  unreachable

if.else.514:                                      ; preds = %logical.merge.472
  br label %if.merge.515

if.merge.515:                                     ; preds = %if.else.514
  %statepoint_token813 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.71497, ptr addrspace(1) %.291339, ptr addrspace(1) %.291455, ptr addrspace(1) %.321397, ptr addrspace(1) %.32) ]
  %r3650814 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token813)
  %r497.7.relocated815 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token813, i32 0, i32 0) ; (%.71497, %.71497)
  %r8.0.relocated816 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token813, i32 1, i32 1) ; (%.291339, %.291339)
  %rs4gc.s15.relocated817 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token813, i32 2, i32 2) ; (%.291455, %.291455)
  %rs4gc.s13.relocated818 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token813, i32 3, i32 3) ; (%.321397, %.321397)
  %rs4gc.s9.relocated819 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token813, i32 4, i32 4) ; (%.32, %.32)
  %rs4gc.s53 = inttoptr i64 %r3650814 to ptr addrspace(1)
  %r3651.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s53 to i64
  %r3651 = call i64 asm "", "=r,0"(i64 %r3651.rs4i) #7
  %r3652 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3653 = icmp ne i32 %r3652, 0
  br i1 %r3653, label %shadow.root.barrier.516, label %shadow.root.barrier.done.517

shadow.root.barrier.516:                          ; preds = %if.merge.515
  call void @js_write_barrier_root_nanbox(i64 %r3651) #7
  br label %shadow.root.barrier.done.517

shadow.root.barrier.done.517:                     ; preds = %shadow.root.barrier.516, %if.merge.515
  %r3654 = load double, ptr @test_json_large_string_emitters_ts_.str.10.handle, align 8
  %r3655.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s53 to i64
  %r3655 = call i64 asm "", "=r,0"(i64 %r3655.rs4i) #7
  %statepoint_token820 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3655, double %r3654, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.7.relocated815, ptr addrspace(1) %r8.0.relocated816, ptr addrspace(1) %rs4gc.s15.relocated817, ptr addrspace(1) %rs4gc.s13.relocated818, ptr addrspace(1) %rs4gc.s9.relocated819) ]
  %r3656821 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token820)
  %r497.7.relocated822 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token820, i32 0, i32 0) ; (%r497.7.relocated815, %r497.7.relocated815)
  %r8.0.relocated823 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token820, i32 1, i32 1) ; (%r8.0.relocated816, %r8.0.relocated816)
  %rs4gc.s15.relocated824 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token820, i32 2, i32 2) ; (%rs4gc.s15.relocated817, %rs4gc.s15.relocated817)
  %rs4gc.s13.relocated825 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token820, i32 3, i32 3) ; (%rs4gc.s13.relocated818, %rs4gc.s13.relocated818)
  %rs4gc.s9.relocated826 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token820, i32 4, i32 4) ; (%rs4gc.s9.relocated819, %rs4gc.s9.relocated819)
  %rs4gc.s54 = inttoptr i64 %r3656821 to ptr addrspace(1)
  %r3657.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s54 to i64
  %r3657 = call i64 asm "", "=r,0"(i64 %r3657.rs4i) #7
  %r3658 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3659 = icmp ne i32 %r3658, 0
  br i1 %r3659, label %shadow.root.barrier.518, label %shadow.root.barrier.done.519

shadow.root.barrier.518:                          ; preds = %shadow.root.barrier.done.517
  call void @js_write_barrier_root_nanbox(i64 %r3657) #7
  br label %shadow.root.barrier.done.519

shadow.root.barrier.done.519:                     ; preds = %shadow.root.barrier.518, %shadow.root.barrier.done.517
  %r3661 = sitofp i32 %r2968.0 to double
  %r3662.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s54 to i64
  %r3662 = call i64 asm "", "=r,0"(i64 %r3662.rs4i) #7
  %statepoint_token827 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3662, double %r3661, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.7.relocated822, ptr addrspace(1) %r8.0.relocated823, ptr addrspace(1) %rs4gc.s15.relocated824, ptr addrspace(1) %rs4gc.s13.relocated825, ptr addrspace(1) %rs4gc.s9.relocated826) ]
  %r3663828 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token827)
  %r497.7.relocated829 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token827, i32 0, i32 0) ; (%r497.7.relocated822, %r497.7.relocated822)
  %r8.0.relocated830 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token827, i32 1, i32 1) ; (%r8.0.relocated823, %r8.0.relocated823)
  %rs4gc.s15.relocated831 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token827, i32 2, i32 2) ; (%rs4gc.s15.relocated824, %rs4gc.s15.relocated824)
  %rs4gc.s13.relocated832 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token827, i32 3, i32 3) ; (%rs4gc.s13.relocated825, %rs4gc.s13.relocated825)
  %rs4gc.s9.relocated833 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token827, i32 4, i32 4) ; (%rs4gc.s9.relocated826, %rs4gc.s9.relocated826)
  %rs4gc.s55 = inttoptr i64 %r3663828 to ptr addrspace(1)
  %r3664.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s55 to i64
  %r3664 = call i64 asm "", "=r,0"(i64 %r3664.rs4i) #7
  %r3665 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3666 = icmp ne i32 %r3665, 0
  br i1 %r3666, label %shadow.root.barrier.520, label %shadow.root.barrier.done.521

shadow.root.barrier.520:                          ; preds = %shadow.root.barrier.done.519
  call void @js_write_barrier_root_nanbox(i64 %r3664) #7
  br label %shadow.root.barrier.done.521

shadow.root.barrier.done.521:                     ; preds = %shadow.root.barrier.520, %shadow.root.barrier.done.519
  %r3667.rs4i = ptrtoint ptr addrspace(1) %r497.7.relocated829 to i64
  %r3667.rs4o = call i64 asm "", "=r,0"(i64 %r3667.rs4i) #7
  %r3667 = bitcast i64 %r3667.rs4o to double
  %r3669 = bitcast double %r3667 to i64
  %r3670 = and i64 %r3669, 281474976710655
  %r3671 = lshr i64 %r3669, 48
  %r3672 = icmp eq i64 %r3671, 32765
  %r3673 = icmp ugt i64 %r3670, 1048575
  %r3674 = and i1 %r3672, %r3673
  br i1 %r3674, label %arr.guard.deref.526, label %arr.fallback.523

arr.fast.522:                                     ; preds = %arr.guard.range.528
  %r3730 = zext i32 %r2968.0 to i64
  %r3731 = shl nuw nsw i64 %r3730, 3
  %r3732 = add nuw nsw i64 %r3731, 8
  %r3733 = add i64 %r3689, %r3732
  %r3734 = inttoptr i64 %r3733 to ptr
  %r3735 = load double, ptr %r3734, align 8
  %r3736 = bitcast double %r3735 to i64
  %r3737 = icmp eq i64 %r3736, 9222246136947933200
  %r3739 = select i1 %r3737, double 0x7FFC000000000001, double %r3735
  br label %arr.merge.525

arr.fallback.523:                                 ; preds = %arr.guard.live.527, %arr.guard.deref.526, %shadow.root.barrier.done.521
  %r3728 = sitofp i32 %r2968.0 to double
  %statepoint_token834 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7058970246387859471, double %r3667, double %r3728, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.7.relocated829, ptr addrspace(1) %r8.0.relocated830, ptr addrspace(1) %rs4gc.s15.relocated831, ptr addrspace(1) %rs4gc.s13.relocated832, ptr addrspace(1) %rs4gc.s9.relocated833, ptr addrspace(1) %rs4gc.s55) ]
  %r3729835 = call double @llvm.experimental.gc.result.f64(token %statepoint_token834)
  %r497.7.relocated836 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token834, i32 0, i32 0) ; (%r497.7.relocated829, %r497.7.relocated829)
  %r8.0.relocated837 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token834, i32 1, i32 1) ; (%r8.0.relocated830, %r8.0.relocated830)
  %rs4gc.s15.relocated838 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token834, i32 2, i32 2) ; (%rs4gc.s15.relocated831, %rs4gc.s15.relocated831)
  %rs4gc.s13.relocated839 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token834, i32 3, i32 3) ; (%rs4gc.s13.relocated832, %rs4gc.s13.relocated832)
  %rs4gc.s9.relocated840 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token834, i32 4, i32 4) ; (%rs4gc.s9.relocated833, %rs4gc.s9.relocated833)
  %rs4gc.s55.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token834, i32 5, i32 5) ; (%rs4gc.s55, %rs4gc.s55)
  br label %arr.merge.525

arr.guard.oob.524:                                ; preds = %arr.guard.range.528
  br label %arr.merge.525

arr.merge.525:                                    ; preds = %arr.guard.oob.524, %arr.fallback.523, %arr.fast.522
  %.01504 = phi ptr addrspace(1) [ %rs4gc.s55, %arr.fast.522 ], [ %rs4gc.s55, %arr.guard.oob.524 ], [ %rs4gc.s55.relocated, %arr.fallback.523 ]
  %.101500 = phi ptr addrspace(1) [ %r497.7.relocated829, %arr.fast.522 ], [ %r497.7.relocated829, %arr.guard.oob.524 ], [ %r497.7.relocated836, %arr.fallback.523 ]
  %.321458 = phi ptr addrspace(1) [ %rs4gc.s15.relocated831, %arr.fast.522 ], [ %rs4gc.s15.relocated831, %arr.guard.oob.524 ], [ %rs4gc.s15.relocated838, %arr.fallback.523 ]
  %.351400 = phi ptr addrspace(1) [ %rs4gc.s13.relocated832, %arr.fast.522 ], [ %rs4gc.s13.relocated832, %arr.guard.oob.524 ], [ %rs4gc.s13.relocated839, %arr.fallback.523 ]
  %.321342 = phi ptr addrspace(1) [ %r8.0.relocated830, %arr.fast.522 ], [ %r8.0.relocated830, %arr.guard.oob.524 ], [ %r8.0.relocated837, %arr.fallback.523 ]
  %.35 = phi ptr addrspace(1) [ %rs4gc.s9.relocated833, %arr.fast.522 ], [ %rs4gc.s9.relocated833, %arr.guard.oob.524 ], [ %rs4gc.s9.relocated840, %arr.fallback.523 ]
  %r3740 = phi double [ %r3739, %arr.fast.522 ], [ %r3729835, %arr.fallback.523 ], [ 0x7FFC000000000001, %arr.guard.oob.524 ]
  %r3741.rs4i = ptrtoint ptr addrspace(1) %.01504 to i64
  %r3741 = call i64 asm "", "=r,0"(i64 %r3741.rs4i) #7
  %statepoint_token841 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3741, double %r3740, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.101500, ptr addrspace(1) %.321342, ptr addrspace(1) %.321458, ptr addrspace(1) %.351400, ptr addrspace(1) %.35) ]
  %r3742842 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token841)
  %r497.7.relocated843 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token841, i32 0, i32 0) ; (%.101500, %.101500)
  %r8.0.relocated844 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token841, i32 1, i32 1) ; (%.321342, %.321342)
  %rs4gc.s15.relocated845 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token841, i32 2, i32 2) ; (%.321458, %.321458)
  %rs4gc.s13.relocated846 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token841, i32 3, i32 3) ; (%.351400, %.351400)
  %rs4gc.s9.relocated847 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token841, i32 4, i32 4) ; (%.35, %.35)
  %rs4gc.s56 = inttoptr i64 %r3742842 to ptr addrspace(1)
  %r3743.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s56 to i64
  %r3743 = call i64 asm "", "=r,0"(i64 %r3743.rs4i) #7
  %r3744 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3745 = icmp ne i32 %r3744, 0
  br i1 %r3745, label %shadow.root.barrier.529, label %shadow.root.barrier.done.530

arr.guard.deref.526:                              ; preds = %shadow.root.barrier.done.521
  %r3675 = bitcast double %r3667 to i64
  %r3676 = and i64 %r3675, 281474976710655
  %r3677 = sub nsw i64 %r3676, 8
  %r3678 = inttoptr i64 %r3677 to ptr
  %r3679 = load i8, ptr %r3678, align 1
  %r3680 = icmp eq i8 %r3679, 1
  %r3681 = sub nsw i64 %r3676, 7
  %r3682 = inttoptr i64 %r3681 to ptr
  %r3683 = load i8, ptr %r3682, align 1
  %r3684 = and i8 %r3683, -128
  %r3685 = icmp ne i8 %r3684, 0
  %r3686 = inttoptr i64 %r3676 to ptr
  %r3687 = load i64, ptr %r3686, align 8
  %r3688 = and i1 %r3680, %r3685
  %r3689 = select i1 %r3688, i64 %r3687, i64 %r3676
  %r3690 = lshr i64 %r3689, 48
  %r3691 = icmp eq i64 %r3690, 0
  %r3692 = icmp ugt i64 %r3689, 1048575
  %r3693 = and i1 %r3691, %r3692
  br i1 %r3693, label %arr.guard.live.527, label %arr.fallback.523

arr.guard.live.527:                               ; preds = %arr.guard.deref.526
  %r3694 = sub nuw i64 %r3689, 8
  %r3695 = inttoptr i64 %r3694 to ptr
  %r3696 = load i8, ptr %r3695, align 1
  %r3697 = icmp eq i8 %r3696, 1
  %r3698 = sub nuw i64 %r3689, 7
  %r3699 = inttoptr i64 %r3698 to ptr
  %r3700 = load i8, ptr %r3699, align 1
  %r3701 = and i8 %r3700, -128
  %r3702 = icmp eq i8 %r3701, 0
  %r3703 = sub nuw i64 %r3689, 6
  %r3704 = inttoptr i64 %r3703 to ptr
  %r3705 = load i16, ptr %r3704, align 2
  %r3706 = and i16 %r3705, 1024
  %r3707 = icmp eq i16 %r3706, 0
  %r3708 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3709 = icmp eq i8 %r3708, 0
  %r3710 = inttoptr i64 %r3689 to ptr
  %r3711 = load i32, ptr %r3710, align 4
  %r3712 = getelementptr i8, ptr %r3710, i64 4
  %r3713 = load i32, ptr %r3712, align 4
  %r3714 = icmp slt i32 %r2968.0, 0
  %r3715 = icmp eq i1 %r3714, false
  %r3717 = icmp ule i32 %r3711, 16000000
  %r3718 = icmp ule i32 %r3713, 16000000
  %r3719 = icmp ule i32 %r3711, %r3713
  %r3720 = and i1 %r3697, %r3702
  %r3721 = and i1 %r3720, %r3707
  %r3722 = and i1 %r3721, %r3709
  %r3723 = and i1 %r3722, %r3715
  %r3724 = and i1 %r3723, %r3717
  %r3725 = and i1 %r3724, %r3718
  %r3726 = and i1 %r3725, %r3719
  br i1 %r3726, label %arr.guard.range.528, label %arr.fallback.523

arr.guard.range.528:                              ; preds = %arr.guard.live.527
  %r3716 = icmp ult i32 %r2968.0, %r3711
  br i1 %r3716, label %arr.fast.522, label %arr.guard.oob.524

shadow.root.barrier.529:                          ; preds = %arr.merge.525
  call void @js_write_barrier_root_nanbox(i64 %r3743) #7
  br label %shadow.root.barrier.done.530

shadow.root.barrier.done.530:                     ; preds = %shadow.root.barrier.529, %arr.merge.525
  %r3746.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s56 to i64
  %r3746 = call i64 asm "", "=r,0"(i64 %r3746.rs4i) #7
  %statepoint_token848 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r3746, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.7.relocated843, ptr addrspace(1) %r8.0.relocated844, ptr addrspace(1) %rs4gc.s15.relocated845, ptr addrspace(1) %rs4gc.s13.relocated846, ptr addrspace(1) %rs4gc.s9.relocated847) ]
  %r497.7.relocated849 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token848, i32 0, i32 0) ; (%r497.7.relocated843, %r497.7.relocated843)
  %r8.0.relocated850 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token848, i32 1, i32 1) ; (%r8.0.relocated844, %r8.0.relocated844)
  %rs4gc.s15.relocated851 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token848, i32 2, i32 2) ; (%rs4gc.s15.relocated845, %rs4gc.s15.relocated845)
  %rs4gc.s13.relocated852 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token848, i32 3, i32 3) ; (%rs4gc.s13.relocated846, %rs4gc.s13.relocated846)
  %rs4gc.s9.relocated853 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token848, i32 4, i32 4) ; (%rs4gc.s9.relocated847, %rs4gc.s9.relocated847)
  %r3747 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r3748 = icmp ne i32 %r3747, 0
  br i1 %r3748, label %gcpoll.531, label %gcpoll.done.532

gcpoll.531:                                       ; preds = %shadow.root.barrier.done.530
  %statepoint_token854 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r497.7.relocated849, ptr addrspace(1) %r8.0.relocated850, ptr addrspace(1) %rs4gc.s15.relocated851, ptr addrspace(1) %rs4gc.s13.relocated852, ptr addrspace(1) %rs4gc.s9.relocated853) ]
  %r497.7.relocated855 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token854, i32 0, i32 0) ; (%r497.7.relocated849, %r497.7.relocated849)
  %r8.0.relocated856 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token854, i32 1, i32 1) ; (%r8.0.relocated850, %r8.0.relocated850)
  %rs4gc.s15.relocated857 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token854, i32 2, i32 2) ; (%rs4gc.s15.relocated851, %rs4gc.s15.relocated851)
  %rs4gc.s13.relocated858 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token854, i32 3, i32 3) ; (%rs4gc.s13.relocated852, %rs4gc.s13.relocated852)
  %rs4gc.s9.relocated859 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token854, i32 4, i32 4) ; (%rs4gc.s9.relocated853, %rs4gc.s9.relocated853)
  br label %gcpoll.done.532

gcpoll.done.532:                                  ; preds = %gcpoll.531, %shadow.root.barrier.done.530
  %.111501 = phi ptr addrspace(1) [ %r497.7.relocated855, %gcpoll.531 ], [ %r497.7.relocated849, %shadow.root.barrier.done.530 ]
  %.331459 = phi ptr addrspace(1) [ %rs4gc.s15.relocated857, %gcpoll.531 ], [ %rs4gc.s15.relocated851, %shadow.root.barrier.done.530 ]
  %.361401 = phi ptr addrspace(1) [ %rs4gc.s13.relocated858, %gcpoll.531 ], [ %rs4gc.s13.relocated852, %shadow.root.barrier.done.530 ]
  %.331343 = phi ptr addrspace(1) [ %r8.0.relocated856, %gcpoll.531 ], [ %r8.0.relocated850, %shadow.root.barrier.done.530 ]
  %.36 = phi ptr addrspace(1) [ %rs4gc.s9.relocated859, %gcpoll.531 ], [ %rs4gc.s9.relocated853, %shadow.root.barrier.done.530 ]
  br label %for.update.385

shadow.root.barrier.533:                          ; preds = %for.exit.386
  call void @js_write_barrier_root_nanbox(i64 %r3755) #7
  br label %shadow.root.barrier.done.534

shadow.root.barrier.done.534:                     ; preds = %shadow.root.barrier.533, %for.exit.386
  br label %for.cond.535

for.cond.535:                                     ; preds = %for.update.537, %shadow.root.barrier.done.534
  %.371402 = phi ptr addrspace(1) [ %.281393, %shadow.root.barrier.done.534 ], [ %.391404, %for.update.537 ]
  %.341344 = phi ptr addrspace(1) [ %.251335, %shadow.root.barrier.done.534 ], [ %.361346, %for.update.537 ]
  %.37 = phi ptr addrspace(1) [ %.28, %shadow.root.barrier.done.534 ], [ %.39, %for.update.537 ]
  %r3758.0 = phi i32 [ 0, %shadow.root.barrier.done.534 ], [ %r3805, %for.update.537 ]
  %r3753.0 = phi ptr addrspace(1) [ %rs4gc.s50, %shadow.root.barrier.done.534 ], [ %.01507, %for.update.537 ]
  %r3760 = sitofp i32 %r3758.0 to double
  %r3761 = fcmp olt double %r3760, 2.550000e+02
  %r3762 = select i1 %r3761, i64 9222246136947933188, i64 9222246136947933187
  %r3763 = bitcast i64 %r3762 to double
  %r3764 = icmp eq i64 %r3762, 9222246136947933188
  br i1 %r3764, label %for.body.536, label %for.exit.538

for.body.536:                                     ; preds = %for.cond.535
  %r3765.rs4i = ptrtoint ptr addrspace(1) %r3753.0 to i64
  %r3765.rs4o = call i64 asm "", "=r,0"(i64 %r3765.rs4i) #7
  %r3765 = bitcast i64 %r3765.rs4o to double
  %r3767 = sitofp i32 %r3758.0 to double
  %r3768 = fptosi double %r3767 to i64
  %r3770 = srem i64 %r3768, 3
  %r3771 = sitofp i64 %r3770 to double
  %r3772 = icmp eq i64 %r3770, 0
  %r3773 = fcmp olt double %r3767, 0.000000e+00
  %r3774 = and i1 %r3772, %r3773
  %r3775 = fneg double %r3771
  %r3776 = select i1 %r3774, double %r3775, double %r3771
  %r3777 = fcmp oeq double %r3776, 0.000000e+00
  %r3778 = select i1 %r3777, i64 9222246136947933188, i64 9222246136947933187
  %r3779 = bitcast i64 %r3778 to double
  %r3780 = icmp eq i64 %r3778, 9222246136947933188
  br i1 %r3780, label %ternary.then.539, label %ternary.else.540

for.update.537:                                   ; preds = %gcpoll.done.549
  %r3805 = add i32 %r3758.0, 1
  %r3806 = sitofp i32 %r3758.0 to double
  %r3807 = sitofp i32 %r3805 to double
  br label %for.cond.535

for.exit.538:                                     ; preds = %for.cond.535
  %statepoint_token860 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.371402, ptr addrspace(1) %.37, ptr addrspace(1) %.341344, ptr addrspace(1) %r3753.0) ]
  %r3808861 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token860)
  %rs4gc.s13.relocated862 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token860, i32 0, i32 0) ; (%.371402, %.371402)
  %rs4gc.s9.relocated863 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token860, i32 1, i32 1) ; (%.37, %.37)
  %r8.0.relocated864 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token860, i32 2, i32 2) ; (%.341344, %.341344)
  %r3753.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token860, i32 3, i32 3) ; (%r3753.0, %r3753.0)
  %rs4gc.s57 = inttoptr i64 %r3808861 to ptr addrspace(1)
  %r3809.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s57 to i64
  %r3809 = call i64 asm "", "=r,0"(i64 %r3809.rs4i) #7
  %r3810 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3811 = icmp ne i32 %r3810, 0
  br i1 %r3811, label %shadow.root.barrier.550, label %shadow.root.barrier.done.551

ternary.then.539:                                 ; preds = %for.body.536
  %r3781 = load double, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  br label %ternary.merge.541

ternary.else.540:                                 ; preds = %for.body.536
  %r3782 = load double, ptr @test_json_large_string_emitters_ts_.str.11.handle, align 8
  br label %ternary.merge.541

ternary.merge.541:                                ; preds = %ternary.else.540, %ternary.then.539
  %r3783 = phi double [ %r3781, %ternary.then.539 ], [ %r3782, %ternary.else.540 ]
  %r3784 = bitcast double %r3765 to i64
  %r3785 = lshr i64 %r3784, 48
  %r3786 = icmp eq i64 %r3785, 32767
  br i1 %r3786, label %strapp.dheap.542, label %strapp.dynamic.544

strapp.dheap.542:                                 ; preds = %ternary.merge.541
  %r3787 = bitcast double %r3783 to i64
  %r3788 = lshr i64 %r3787, 48
  %r3789 = icmp eq i64 %r3788, 32765
  br i1 %r3789, label %strapp.dynamic.544, label %strapp.append.543

strapp.append.543:                                ; preds = %strapp.dheap.542
  %statepoint_token865 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_jsvalue_to_string, i32 1, i32 0, double %r3783, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.371402, ptr addrspace(1) %.37, ptr addrspace(1) %.341344, ptr addrspace(1) %r3753.0) ]
  %r3790866 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token865)
  %rs4gc.s13.relocated867 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token865, i32 0, i32 0) ; (%.371402, %.371402)
  %rs4gc.s9.relocated868 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token865, i32 1, i32 1) ; (%.37, %.37)
  %r8.0.relocated869 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token865, i32 2, i32 2) ; (%.341344, %.341344)
  %r3753.0.relocated870 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token865, i32 3, i32 3) ; (%r3753.0, %r3753.0)
  %r3791.rs4i = ptrtoint ptr addrspace(1) %r3753.0.relocated870 to i64
  %r3791.rs4o = call i64 asm "", "=r,0"(i64 %r3791.rs4i) #7
  %r3791 = bitcast i64 %r3791.rs4o to double
  %r3792 = bitcast double %r3791 to i64
  %r3793 = and i64 %r3792, 281474976710655
  %statepoint_token871 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_string_append_known_heap, i32 2, i32 0, i64 %r3793, i64 %r3790866, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated867, ptr addrspace(1) %rs4gc.s9.relocated868, ptr addrspace(1) %r8.0.relocated869) ]
  %r3794872 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token871)
  %rs4gc.s13.relocated873 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token871, i32 0, i32 0) ; (%rs4gc.s13.relocated867, %rs4gc.s13.relocated867)
  %rs4gc.s9.relocated874 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token871, i32 1, i32 1) ; (%rs4gc.s9.relocated868, %rs4gc.s9.relocated868)
  %r8.0.relocated875 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token871, i32 2, i32 2) ; (%r8.0.relocated869, %r8.0.relocated869)
  %r3795 = or i64 %r3794872, 9223090561878065152
  %r3796 = bitcast i64 %r3795 to double
  br label %strapp.merge.545

strapp.dynamic.544:                               ; preds = %strapp.dheap.542, %ternary.merge.541
  %statepoint_token876 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r3765, double %r3783, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.371402, ptr addrspace(1) %.37, ptr addrspace(1) %.341344) ]
  %r3797877 = call double @llvm.experimental.gc.result.f64(token %statepoint_token876)
  %rs4gc.s13.relocated878 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token876, i32 0, i32 0) ; (%.371402, %.371402)
  %rs4gc.s9.relocated879 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token876, i32 1, i32 1) ; (%.37, %.37)
  %r8.0.relocated880 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token876, i32 2, i32 2) ; (%.341344, %.341344)
  br label %strapp.merge.545

strapp.merge.545:                                 ; preds = %strapp.dynamic.544, %strapp.append.543
  %.381403 = phi ptr addrspace(1) [ %rs4gc.s13.relocated878, %strapp.dynamic.544 ], [ %rs4gc.s13.relocated873, %strapp.append.543 ]
  %.351345 = phi ptr addrspace(1) [ %r8.0.relocated880, %strapp.dynamic.544 ], [ %r8.0.relocated875, %strapp.append.543 ]
  %.38 = phi ptr addrspace(1) [ %rs4gc.s9.relocated879, %strapp.dynamic.544 ], [ %rs4gc.s9.relocated874, %strapp.append.543 ]
  %r3798 = phi double [ %r3796, %strapp.append.543 ], [ %r3797877, %strapp.dynamic.544 ]
  %rs4gc.b58 = bitcast double %r3798 to i64
  %rs4gc.s58 = inttoptr i64 %rs4gc.b58 to ptr addrspace(1)
  %r3799.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s58 to i64
  %r3799 = call i64 asm "", "=r,0"(i64 %r3799.rs4i) #7
  %r3800 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3801 = icmp ne i32 %r3800, 0
  br i1 %r3801, label %shadow.root.barrier.546, label %shadow.root.barrier.done.547

shadow.root.barrier.546:                          ; preds = %strapp.merge.545
  call void @js_write_barrier_root_nanbox(i64 %r3799) #7
  br label %shadow.root.barrier.done.547

shadow.root.barrier.done.547:                     ; preds = %shadow.root.barrier.546, %strapp.merge.545
  %r3802 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r3803 = icmp ne i32 %r3802, 0
  br i1 %r3803, label %gcpoll.548, label %gcpoll.done.549

gcpoll.548:                                       ; preds = %shadow.root.barrier.done.547
  %statepoint_token881 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s58, ptr addrspace(1) %.381403, ptr addrspace(1) %.38, ptr addrspace(1) %.351345) ]
  %rs4gc.s58.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token881, i32 0, i32 0) ; (%rs4gc.s58, %rs4gc.s58)
  %rs4gc.s13.relocated882 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token881, i32 1, i32 1) ; (%.381403, %.381403)
  %rs4gc.s9.relocated883 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token881, i32 2, i32 2) ; (%.38, %.38)
  %r8.0.relocated884 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token881, i32 3, i32 3) ; (%.351345, %.351345)
  br label %gcpoll.done.549

gcpoll.done.549:                                  ; preds = %gcpoll.548, %shadow.root.barrier.done.547
  %.01507 = phi ptr addrspace(1) [ %rs4gc.s58.relocated, %gcpoll.548 ], [ %rs4gc.s58, %shadow.root.barrier.done.547 ]
  %.391404 = phi ptr addrspace(1) [ %rs4gc.s13.relocated882, %gcpoll.548 ], [ %.381403, %shadow.root.barrier.done.547 ]
  %.361346 = phi ptr addrspace(1) [ %r8.0.relocated884, %gcpoll.548 ], [ %.351345, %shadow.root.barrier.done.547 ]
  %.39 = phi ptr addrspace(1) [ %rs4gc.s9.relocated883, %gcpoll.548 ], [ %.38, %shadow.root.barrier.done.547 ]
  br label %for.update.537

shadow.root.barrier.550:                          ; preds = %for.exit.538
  call void @js_write_barrier_root_nanbox(i64 %r3809) #7
  br label %shadow.root.barrier.done.551

shadow.root.barrier.done.551:                     ; preds = %shadow.root.barrier.550, %for.exit.538
  %r3812 = load double, ptr @test_json_large_string_emitters_ts_.str.12.handle, align 8
  %r3813.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s57 to i64
  %r3813 = call i64 asm "", "=r,0"(i64 %r3813.rs4i) #7
  %statepoint_token885 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3813, double %r3812, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated862, ptr addrspace(1) %rs4gc.s9.relocated863, ptr addrspace(1) %r8.0.relocated864, ptr addrspace(1) %r3753.0.relocated) ]
  %r3814886 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token885)
  %rs4gc.s13.relocated887 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token885, i32 0, i32 0) ; (%rs4gc.s13.relocated862, %rs4gc.s13.relocated862)
  %rs4gc.s9.relocated888 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token885, i32 1, i32 1) ; (%rs4gc.s9.relocated863, %rs4gc.s9.relocated863)
  %r8.0.relocated889 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token885, i32 2, i32 2) ; (%r8.0.relocated864, %r8.0.relocated864)
  %r3753.0.relocated890 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token885, i32 3, i32 3) ; (%r3753.0.relocated, %r3753.0.relocated)
  %rs4gc.s59 = inttoptr i64 %r3814886 to ptr addrspace(1)
  %r3815.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s59 to i64
  %r3815 = call i64 asm "", "=r,0"(i64 %r3815.rs4i) #7
  %r3816 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3817 = icmp ne i32 %r3816, 0
  br i1 %r3817, label %shadow.root.barrier.552, label %shadow.root.barrier.done.553

shadow.root.barrier.552:                          ; preds = %shadow.root.barrier.done.551
  call void @js_write_barrier_root_nanbox(i64 %r3815) #7
  br label %shadow.root.barrier.done.553

shadow.root.barrier.done.553:                     ; preds = %shadow.root.barrier.552, %shadow.root.barrier.done.551
  %r3818.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s59 to i64
  %r3818 = call i64 asm "", "=r,0"(i64 %r3818.rs4i) #7
  %statepoint_token891 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3818, double 2.550000e+02, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated887, ptr addrspace(1) %rs4gc.s9.relocated888, ptr addrspace(1) %r8.0.relocated889, ptr addrspace(1) %r3753.0.relocated890) ]
  %r3819892 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token891)
  %rs4gc.s13.relocated893 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token891, i32 0, i32 0) ; (%rs4gc.s13.relocated887, %rs4gc.s13.relocated887)
  %rs4gc.s9.relocated894 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token891, i32 1, i32 1) ; (%rs4gc.s9.relocated888, %rs4gc.s9.relocated888)
  %r8.0.relocated895 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token891, i32 2, i32 2) ; (%r8.0.relocated889, %r8.0.relocated889)
  %r3753.0.relocated896 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token891, i32 3, i32 3) ; (%r3753.0.relocated890, %r3753.0.relocated890)
  %rs4gc.s60 = inttoptr i64 %r3819892 to ptr addrspace(1)
  %r3820.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s60 to i64
  %r3820 = call i64 asm "", "=r,0"(i64 %r3820.rs4i) #7
  %r3821 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3822 = icmp ne i32 %r3821, 0
  br i1 %r3822, label %shadow.root.barrier.554, label %shadow.root.barrier.done.555

shadow.root.barrier.554:                          ; preds = %shadow.root.barrier.done.553
  call void @js_write_barrier_root_nanbox(i64 %r3820) #7
  br label %shadow.root.barrier.done.555

shadow.root.barrier.done.555:                     ; preds = %shadow.root.barrier.554, %shadow.root.barrier.done.553
  %r3823.rs4i = ptrtoint ptr addrspace(1) %r3753.0.relocated896 to i64
  %r3823.rs4o = call i64 asm "", "=r,0"(i64 %r3823.rs4i) #7
  %r3823 = bitcast i64 %r3823.rs4o to double
  %r3824 = bitcast double %r3823 to i64
  %rs4gc.s61 = inttoptr i64 %r3824 to ptr addrspace(1)
  %r3826.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s61 to i64
  %r3826 = call i64 asm "", "=r,0"(i64 %r3826.rs4i) #7
  %r3827 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3828 = icmp ne i32 %r3827, 0
  br i1 %r3828, label %shadow.root.barrier.556, label %shadow.root.barrier.done.557

shadow.root.barrier.556:                          ; preds = %shadow.root.barrier.done.555
  call void @js_write_barrier_root_nanbox(i64 %r3826) #7
  br label %shadow.root.barrier.done.557

shadow.root.barrier.done.557:                     ; preds = %shadow.root.barrier.556, %shadow.root.barrier.done.555
  %r3831.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9.relocated894 to i64
  %r3831 = call i64 asm "", "=r,0"(i64 %r3831.rs4i) #7
  %statepoint_token897 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 3, i32 0, i32 1, i64 %r3831, i32 %r3833, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated893, ptr addrspace(1) %rs4gc.s9.relocated894, ptr addrspace(1) %r8.0.relocated895, ptr addrspace(1) %r3753.0.relocated896, ptr addrspace(1) %rs4gc.s60, ptr addrspace(1) %rs4gc.s61) ]
  %r3835898 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token897)
  %rs4gc.s13.relocated899 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token897, i32 0, i32 0) ; (%rs4gc.s13.relocated893, %rs4gc.s13.relocated893)
  %rs4gc.s9.relocated900 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token897, i32 1, i32 1) ; (%rs4gc.s9.relocated894, %rs4gc.s9.relocated894)
  %r8.0.relocated901 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token897, i32 2, i32 2) ; (%r8.0.relocated895, %r8.0.relocated895)
  %r3753.0.relocated902 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token897, i32 3, i32 3) ; (%r3753.0.relocated896, %r3753.0.relocated896)
  %rs4gc.s60.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token897, i32 4, i32 4) ; (%rs4gc.s60, %rs4gc.s60)
  %rs4gc.s61.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token897, i32 5, i32 5) ; (%rs4gc.s61, %rs4gc.s61)
  call void @js_gc_declare_typed_shape_layout(i64 %r3835898, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, i32 1) #7
  %rs4gc.s62 = inttoptr i64 %r3835898 to ptr addrspace(1)
  %r3837.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s62 to i64
  %r3837 = call i64 asm "", "=r,0"(i64 %r3837.rs4i) #7
  %r3838 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3839 = icmp ne i32 %r3838, 0
  br i1 %r3839, label %shadow.root.barrier.558, label %shadow.root.barrier.done.559

shadow.root.barrier.558:                          ; preds = %shadow.root.barrier.done.557
  call void @js_write_barrier_root_nanbox(i64 %r3837) #7
  br label %shadow.root.barrier.done.559

shadow.root.barrier.done.559:                     ; preds = %shadow.root.barrier.558, %shadow.root.barrier.done.557
  %r3840 = or i64 %r3835898, 9222527611924643840
  %r3841 = bitcast i64 %r3840 to double
  %r3842.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s61.relocated to i64
  %r3842 = call i64 asm "", "=r,0"(i64 %r3842.rs4i) #7
  %r3843 = bitcast i64 %r3842 to double
  %r3844 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r3845 = icmp eq i8 %r3844, 0
  %r3846 = inttoptr i64 %r3835898 to ptr
  %r3847 = getelementptr i8, ptr %r3846, i64 -6
  %r3848 = load i16, ptr %r3847, align 2
  %r3849 = and i16 %r3848, 4096
  %r3850 = icmp ne i16 %r3849, 0
  %r3851 = and i1 %r3845, %r3850
  br i1 %r3851, label %ctor_prologue.fast.560, label %ctor_prologue.slow.561

ctor_prologue.fast.560:                           ; preds = %shadow.root.barrier.done.559
  %r3852 = inttoptr i64 %r3835898 to ptr
  %r3853 = getelementptr i8, ptr %r3852, i64 16
  %r3854 = bitcast double %r3841 to i64
  %r3855 = getelementptr double, ptr %r3853, i64 0
  store double %r3843, ptr %r3855, align 8
  %r3856 = ptrtoint ptr %r3855 to i64
  %r3857 = bitcast double %r3843 to i64
  %r3858 = lshr i64 %r3857, 48
  %r3859 = icmp eq i64 %r3858, 0
  %r3860 = icmp uge i64 %r3857, 4096
  %r3861 = and i1 %r3859, %r3860
  %r3862 = icmp eq i64 %r3858, 32765
  %r3863 = icmp eq i64 %r3858, 32767
  %r3864 = icmp eq i64 %r3858, 32762
  %r3865 = or i1 %r3862, %r3863
  %r3866 = or i1 %r3865, %r3864
  %r3867 = or i1 %r3866, %r3861
  br i1 %r3867, label %ctor_prologue.barrier.maybe.563, label %ctor_prologue.barrier.done.565

ctor_prologue.slow.561:                           ; preds = %shadow.root.barrier.done.559
  %statepoint_token903 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3_constructor, i32 2, i32 0, double %r3841, double %r3843, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated899, ptr addrspace(1) %rs4gc.s9.relocated900, ptr addrspace(1) %r8.0.relocated901, ptr addrspace(1) %r3753.0.relocated902, ptr addrspace(1) %rs4gc.s60.relocated, ptr addrspace(1) %rs4gc.s62) ]
  %r3876904 = call double @llvm.experimental.gc.result.f64(token %statepoint_token903)
  %rs4gc.s13.relocated905 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token903, i32 0, i32 0) ; (%rs4gc.s13.relocated899, %rs4gc.s13.relocated899)
  %rs4gc.s9.relocated906 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token903, i32 1, i32 1) ; (%rs4gc.s9.relocated900, %rs4gc.s9.relocated900)
  %r8.0.relocated907 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token903, i32 2, i32 2) ; (%r8.0.relocated901, %r8.0.relocated901)
  %r3753.0.relocated908 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token903, i32 3, i32 3) ; (%r3753.0.relocated902, %r3753.0.relocated902)
  %rs4gc.s60.relocated909 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token903, i32 4, i32 4) ; (%rs4gc.s60.relocated, %rs4gc.s60.relocated)
  %rs4gc.s62.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token903, i32 5, i32 5) ; (%rs4gc.s62, %rs4gc.s62)
  br label %ctor_prologue.merge.562

ctor_prologue.merge.562:                          ; preds = %ctor_prologue.barrier.done.565, %ctor_prologue.slow.561
  %.01510 = phi ptr addrspace(1) [ %rs4gc.s62, %ctor_prologue.barrier.done.565 ], [ %rs4gc.s62.relocated, %ctor_prologue.slow.561 ]
  %.01508 = phi ptr addrspace(1) [ %rs4gc.s60.relocated, %ctor_prologue.barrier.done.565 ], [ %rs4gc.s60.relocated909, %ctor_prologue.slow.561 ]
  %.01505 = phi ptr addrspace(1) [ %r3753.0.relocated902, %ctor_prologue.barrier.done.565 ], [ %r3753.0.relocated908, %ctor_prologue.slow.561 ]
  %.401405 = phi ptr addrspace(1) [ %rs4gc.s13.relocated899, %ctor_prologue.barrier.done.565 ], [ %rs4gc.s13.relocated905, %ctor_prologue.slow.561 ]
  %.371347 = phi ptr addrspace(1) [ %r8.0.relocated901, %ctor_prologue.barrier.done.565 ], [ %r8.0.relocated907, %ctor_prologue.slow.561 ]
  %.40 = phi ptr addrspace(1) [ %rs4gc.s9.relocated900, %ctor_prologue.barrier.done.565 ], [ %rs4gc.s9.relocated906, %ctor_prologue.slow.561 ]
  %r3877 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.565 ], [ %r3876904, %ctor_prologue.slow.561 ]
  %r3878.rs4i = ptrtoint ptr addrspace(1) %.01510 to i64
  %r3878 = call i64 asm "", "=r,0"(i64 %r3878.rs4i) #7
  %r3879 = or i64 %r3878, 9222527611924643840
  %r3880 = bitcast i64 %r3879 to double
  %r3881 = bitcast double %r3877 to i64
  %r3882 = icmp eq i64 %r3881, 9222246136947933185
  br i1 %r3882, label %ctor_ret.merge.567, label %ctor_ret.override.566

ctor_prologue.barrier.maybe.563:                  ; preds = %ctor_prologue.fast.560
  %r3868 = sub i64 %r3835898, 7
  %r3869 = inttoptr i64 %r3868 to ptr
  %r3870 = load i8, ptr %r3869, align 1
  %r3871 = and i8 %r3870, 32
  %r3872 = icmp ne i8 %r3871, 0
  %r3873 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3874 = icmp ne i32 %r3873, 0
  %r3875 = or i1 %r3872, %r3874
  br i1 %r3875, label %ctor_prologue.barrier.564, label %ctor_prologue.barrier.done.565

ctor_prologue.barrier.564:                        ; preds = %ctor_prologue.barrier.maybe.563
  call void @js_write_barrier_slot_validated_parent(i64 %r3835898, i64 %r3856, i64 %r3857) #7
  br label %ctor_prologue.barrier.done.565

ctor_prologue.barrier.done.565:                   ; preds = %ctor_prologue.barrier.564, %ctor_prologue.barrier.maybe.563, %ctor_prologue.fast.560
  br label %ctor_prologue.merge.562

ctor_ret.override.566:                            ; preds = %ctor_prologue.merge.562
  %statepoint_token910 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r3880, double %r3877, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.401405, ptr addrspace(1) %.40, ptr addrspace(1) %.371347, ptr addrspace(1) %.01505, ptr addrspace(1) %.01508) ]
  %r3883911 = call double @llvm.experimental.gc.result.f64(token %statepoint_token910)
  %rs4gc.s13.relocated912 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token910, i32 0, i32 0) ; (%.401405, %.401405)
  %rs4gc.s9.relocated913 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token910, i32 1, i32 1) ; (%.40, %.40)
  %r8.0.relocated914 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token910, i32 2, i32 2) ; (%.371347, %.371347)
  %r3753.0.relocated915 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token910, i32 3, i32 3) ; (%.01505, %.01505)
  %rs4gc.s60.relocated916 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token910, i32 4, i32 4) ; (%.01508, %.01508)
  br label %ctor_ret.merge.567

ctor_ret.merge.567:                               ; preds = %ctor_ret.override.566, %ctor_prologue.merge.562
  %.11509 = phi ptr addrspace(1) [ %.01508, %ctor_prologue.merge.562 ], [ %rs4gc.s60.relocated916, %ctor_ret.override.566 ]
  %.11506 = phi ptr addrspace(1) [ %.01505, %ctor_prologue.merge.562 ], [ %r3753.0.relocated915, %ctor_ret.override.566 ]
  %.411406 = phi ptr addrspace(1) [ %.401405, %ctor_prologue.merge.562 ], [ %rs4gc.s13.relocated912, %ctor_ret.override.566 ]
  %.381348 = phi ptr addrspace(1) [ %.371347, %ctor_prologue.merge.562 ], [ %r8.0.relocated914, %ctor_ret.override.566 ]
  %.41 = phi ptr addrspace(1) [ %.40, %ctor_prologue.merge.562 ], [ %rs4gc.s9.relocated913, %ctor_ret.override.566 ]
  %r3884 = phi double [ %r3880, %ctor_prologue.merge.562 ], [ %r3883911, %ctor_ret.override.566 ]
  %statepoint_token917 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r3884, double 0x7FFC000000000002, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.411406, ptr addrspace(1) %.41, ptr addrspace(1) %.381348, ptr addrspace(1) %.11506, ptr addrspace(1) %.11509) ]
  %r3885918 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token917)
  %rs4gc.s13.relocated919 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token917, i32 0, i32 0) ; (%.411406, %.411406)
  %rs4gc.s9.relocated920 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token917, i32 1, i32 1) ; (%.41, %.41)
  %r8.0.relocated921 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token917, i32 2, i32 2) ; (%.381348, %.381348)
  %r3753.0.relocated922 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token917, i32 3, i32 3) ; (%.11506, %.11506)
  %rs4gc.s60.relocated923 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token917, i32 4, i32 4) ; (%.11509, %.11509)
  %r3886 = bitcast i64 %r3885918 to double
  %r3887.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s60.relocated923 to i64
  %r3887 = call i64 asm "", "=r,0"(i64 %r3887.rs4i) #7
  %statepoint_token924 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3887, double %r3886, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated919, ptr addrspace(1) %rs4gc.s9.relocated920, ptr addrspace(1) %r8.0.relocated921, ptr addrspace(1) %r3753.0.relocated922) ]
  %r3888925 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token924)
  %rs4gc.s13.relocated926 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token924, i32 0, i32 0) ; (%rs4gc.s13.relocated919, %rs4gc.s13.relocated919)
  %rs4gc.s9.relocated927 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token924, i32 1, i32 1) ; (%rs4gc.s9.relocated920, %rs4gc.s9.relocated920)
  %r8.0.relocated928 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token924, i32 2, i32 2) ; (%r8.0.relocated921, %r8.0.relocated921)
  %r3753.0.relocated929 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token924, i32 3, i32 3) ; (%r3753.0.relocated922, %r3753.0.relocated922)
  %rs4gc.s63 = inttoptr i64 %r3888925 to ptr addrspace(1)
  %r3889.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s63 to i64
  %r3889 = call i64 asm "", "=r,0"(i64 %r3889.rs4i) #7
  %r3890 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3891 = icmp ne i32 %r3890, 0
  br i1 %r3891, label %shadow.root.barrier.568, label %shadow.root.barrier.done.569

shadow.root.barrier.568:                          ; preds = %ctor_ret.merge.567
  call void @js_write_barrier_root_nanbox(i64 %r3889) #7
  br label %shadow.root.barrier.done.569

shadow.root.barrier.done.569:                     ; preds = %shadow.root.barrier.568, %ctor_ret.merge.567
  %r3892.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s63 to i64
  %r3892 = call i64 asm "", "=r,0"(i64 %r3892.rs4i) #7
  %statepoint_token930 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r3892, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated926, ptr addrspace(1) %rs4gc.s9.relocated927, ptr addrspace(1) %r8.0.relocated928, ptr addrspace(1) %r3753.0.relocated929) ]
  %rs4gc.s13.relocated931 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token930, i32 0, i32 0) ; (%rs4gc.s13.relocated926, %rs4gc.s13.relocated926)
  %rs4gc.s9.relocated932 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token930, i32 1, i32 1) ; (%rs4gc.s9.relocated927, %rs4gc.s9.relocated927)
  %r8.0.relocated933 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token930, i32 2, i32 2) ; (%r8.0.relocated928, %r8.0.relocated928)
  %r3753.0.relocated934 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token930, i32 3, i32 3) ; (%r3753.0.relocated929, %r3753.0.relocated929)
  %statepoint_token935 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated931, ptr addrspace(1) %rs4gc.s9.relocated932, ptr addrspace(1) %r8.0.relocated933, ptr addrspace(1) %r3753.0.relocated934) ]
  %r3893936 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token935)
  %rs4gc.s13.relocated937 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token935, i32 0, i32 0) ; (%rs4gc.s13.relocated931, %rs4gc.s13.relocated931)
  %rs4gc.s9.relocated938 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token935, i32 1, i32 1) ; (%rs4gc.s9.relocated932, %rs4gc.s9.relocated932)
  %r8.0.relocated939 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token935, i32 2, i32 2) ; (%r8.0.relocated933, %r8.0.relocated933)
  %r3753.0.relocated940 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token935, i32 3, i32 3) ; (%r3753.0.relocated934, %r3753.0.relocated934)
  %rs4gc.s64 = inttoptr i64 %r3893936 to ptr addrspace(1)
  %r3894.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s64 to i64
  %r3894 = call i64 asm "", "=r,0"(i64 %r3894.rs4i) #7
  %r3895 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3896 = icmp ne i32 %r3895, 0
  br i1 %r3896, label %shadow.root.barrier.570, label %shadow.root.barrier.done.571

shadow.root.barrier.570:                          ; preds = %shadow.root.barrier.done.569
  call void @js_write_barrier_root_nanbox(i64 %r3894) #7
  br label %shadow.root.barrier.done.571

shadow.root.barrier.done.571:                     ; preds = %shadow.root.barrier.570, %shadow.root.barrier.done.569
  %r3897 = load double, ptr @test_json_large_string_emitters_ts_.str.13.handle, align 8
  %r3898.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s64 to i64
  %r3898 = call i64 asm "", "=r,0"(i64 %r3898.rs4i) #7
  %statepoint_token941 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3898, double %r3897, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated937, ptr addrspace(1) %rs4gc.s9.relocated938, ptr addrspace(1) %r8.0.relocated939, ptr addrspace(1) %r3753.0.relocated940) ]
  %r3899942 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token941)
  %rs4gc.s13.relocated943 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token941, i32 0, i32 0) ; (%rs4gc.s13.relocated937, %rs4gc.s13.relocated937)
  %rs4gc.s9.relocated944 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token941, i32 1, i32 1) ; (%rs4gc.s9.relocated938, %rs4gc.s9.relocated938)
  %r8.0.relocated945 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token941, i32 2, i32 2) ; (%r8.0.relocated939, %r8.0.relocated939)
  %r3753.0.relocated946 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token941, i32 3, i32 3) ; (%r3753.0.relocated940, %r3753.0.relocated940)
  %rs4gc.s65 = inttoptr i64 %r3899942 to ptr addrspace(1)
  %r3900.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s65 to i64
  %r3900 = call i64 asm "", "=r,0"(i64 %r3900.rs4i) #7
  %r3901 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3902 = icmp ne i32 %r3901, 0
  br i1 %r3902, label %shadow.root.barrier.572, label %shadow.root.barrier.done.573

shadow.root.barrier.572:                          ; preds = %shadow.root.barrier.done.571
  call void @js_write_barrier_root_nanbox(i64 %r3900) #7
  br label %shadow.root.barrier.done.573

shadow.root.barrier.done.573:                     ; preds = %shadow.root.barrier.572, %shadow.root.barrier.done.571
  %r3903.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s65 to i64
  %r3903 = call i64 asm "", "=r,0"(i64 %r3903.rs4i) #7
  %statepoint_token947 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3903, double 2.550000e+02, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated943, ptr addrspace(1) %rs4gc.s9.relocated944, ptr addrspace(1) %r8.0.relocated945, ptr addrspace(1) %r3753.0.relocated946) ]
  %r3904948 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token947)
  %rs4gc.s13.relocated949 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token947, i32 0, i32 0) ; (%rs4gc.s13.relocated943, %rs4gc.s13.relocated943)
  %rs4gc.s9.relocated950 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token947, i32 1, i32 1) ; (%rs4gc.s9.relocated944, %rs4gc.s9.relocated944)
  %r8.0.relocated951 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token947, i32 2, i32 2) ; (%r8.0.relocated945, %r8.0.relocated945)
  %r3753.0.relocated952 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token947, i32 3, i32 3) ; (%r3753.0.relocated946, %r3753.0.relocated946)
  %rs4gc.s66 = inttoptr i64 %r3904948 to ptr addrspace(1)
  %r3905.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s66 to i64
  %r3905 = call i64 asm "", "=r,0"(i64 %r3905.rs4i) #7
  %r3906 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3907 = icmp ne i32 %r3906, 0
  br i1 %r3907, label %shadow.root.barrier.574, label %shadow.root.barrier.done.575

shadow.root.barrier.574:                          ; preds = %shadow.root.barrier.done.573
  call void @js_write_barrier_root_nanbox(i64 %r3905) #7
  br label %shadow.root.barrier.done.575

shadow.root.barrier.done.575:                     ; preds = %shadow.root.barrier.574, %shadow.root.barrier.done.573
  %r3908.rs4i = ptrtoint ptr addrspace(1) %r3753.0.relocated952 to i64
  %r3908.rs4o = call i64 asm "", "=r,0"(i64 %r3908.rs4i) #7
  %r3908 = bitcast i64 %r3908.rs4o to double
  %r3909 = bitcast double %r3908 to i64
  %rs4gc.s67 = inttoptr i64 %r3909 to ptr addrspace(1)
  %r3910.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s67 to i64
  %r3910 = call i64 asm "", "=r,0"(i64 %r3910.rs4i) #7
  %r3911 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3912 = icmp ne i32 %r3911, 0
  br i1 %r3912, label %shadow.root.barrier.576, label %shadow.root.barrier.done.577

shadow.root.barrier.576:                          ; preds = %shadow.root.barrier.done.575
  call void @js_write_barrier_root_nanbox(i64 %r3910) #7
  br label %shadow.root.barrier.done.577

shadow.root.barrier.done.577:                     ; preds = %shadow.root.barrier.576, %shadow.root.barrier.done.575
  %r3913.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9.relocated950 to i64
  %r3913 = call i64 asm "", "=r,0"(i64 %r3913.rs4i) #7
  %statepoint_token953 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 3, i32 0, i32 1, i64 %r3913, i32 %r3833, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated949, ptr addrspace(1) %rs4gc.s9.relocated950, ptr addrspace(1) %r8.0.relocated951, ptr addrspace(1) %rs4gc.s66, ptr addrspace(1) %rs4gc.s67) ]
  %r3915954 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token953)
  %rs4gc.s13.relocated955 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token953, i32 0, i32 0) ; (%rs4gc.s13.relocated949, %rs4gc.s13.relocated949)
  %rs4gc.s9.relocated956 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token953, i32 1, i32 1) ; (%rs4gc.s9.relocated950, %rs4gc.s9.relocated950)
  %r8.0.relocated957 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token953, i32 2, i32 2) ; (%r8.0.relocated951, %r8.0.relocated951)
  %rs4gc.s66.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token953, i32 3, i32 3) ; (%rs4gc.s66, %rs4gc.s66)
  %rs4gc.s67.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token953, i32 4, i32 4) ; (%rs4gc.s67, %rs4gc.s67)
  call void @js_gc_declare_typed_shape_layout(i64 %r3915954, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, i32 1) #7
  %rs4gc.s68 = inttoptr i64 %r3915954 to ptr addrspace(1)
  %r3916.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s68 to i64
  %r3916 = call i64 asm "", "=r,0"(i64 %r3916.rs4i) #7
  %r3917 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3918 = icmp ne i32 %r3917, 0
  br i1 %r3918, label %shadow.root.barrier.578, label %shadow.root.barrier.done.579

shadow.root.barrier.578:                          ; preds = %shadow.root.barrier.done.577
  call void @js_write_barrier_root_nanbox(i64 %r3916) #7
  br label %shadow.root.barrier.done.579

shadow.root.barrier.done.579:                     ; preds = %shadow.root.barrier.578, %shadow.root.barrier.done.577
  %r3919 = or i64 %r3915954, 9222527611924643840
  %r3920 = bitcast i64 %r3919 to double
  %r3921.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s67.relocated to i64
  %r3921 = call i64 asm "", "=r,0"(i64 %r3921.rs4i) #7
  %r3922 = bitcast i64 %r3921 to double
  %r3923 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r3924 = icmp eq i8 %r3923, 0
  %r3925 = inttoptr i64 %r3915954 to ptr
  %r3926 = getelementptr i8, ptr %r3925, i64 -6
  %r3927 = load i16, ptr %r3926, align 2
  %r3928 = and i16 %r3927, 4096
  %r3929 = icmp ne i16 %r3928, 0
  %r3930 = and i1 %r3924, %r3929
  br i1 %r3930, label %ctor_prologue.fast.580, label %ctor_prologue.slow.581

ctor_prologue.fast.580:                           ; preds = %shadow.root.barrier.done.579
  %r3931 = inttoptr i64 %r3915954 to ptr
  %r3932 = getelementptr i8, ptr %r3931, i64 16
  %r3933 = bitcast double %r3920 to i64
  %r3934 = getelementptr double, ptr %r3932, i64 0
  store double %r3922, ptr %r3934, align 8
  %r3935 = ptrtoint ptr %r3934 to i64
  %r3936 = bitcast double %r3922 to i64
  %r3937 = lshr i64 %r3936, 48
  %r3938 = icmp eq i64 %r3937, 0
  %r3939 = icmp uge i64 %r3936, 4096
  %r3940 = and i1 %r3938, %r3939
  %r3941 = icmp eq i64 %r3937, 32765
  %r3942 = icmp eq i64 %r3937, 32767
  %r3943 = icmp eq i64 %r3937, 32762
  %r3944 = or i1 %r3941, %r3942
  %r3945 = or i1 %r3944, %r3943
  %r3946 = or i1 %r3945, %r3940
  br i1 %r3946, label %ctor_prologue.barrier.maybe.583, label %ctor_prologue.barrier.done.585

ctor_prologue.slow.581:                           ; preds = %shadow.root.barrier.done.579
  %statepoint_token958 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3_constructor, i32 2, i32 0, double %r3920, double %r3922, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated955, ptr addrspace(1) %rs4gc.s9.relocated956, ptr addrspace(1) %r8.0.relocated957, ptr addrspace(1) %rs4gc.s66.relocated, ptr addrspace(1) %rs4gc.s68) ]
  %r3955959 = call double @llvm.experimental.gc.result.f64(token %statepoint_token958)
  %rs4gc.s13.relocated960 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token958, i32 0, i32 0) ; (%rs4gc.s13.relocated955, %rs4gc.s13.relocated955)
  %rs4gc.s9.relocated961 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token958, i32 1, i32 1) ; (%rs4gc.s9.relocated956, %rs4gc.s9.relocated956)
  %r8.0.relocated962 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token958, i32 2, i32 2) ; (%r8.0.relocated957, %r8.0.relocated957)
  %rs4gc.s66.relocated963 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token958, i32 3, i32 3) ; (%rs4gc.s66.relocated, %rs4gc.s66.relocated)
  %rs4gc.s68.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token958, i32 4, i32 4) ; (%rs4gc.s68, %rs4gc.s68)
  br label %ctor_prologue.merge.582

ctor_prologue.merge.582:                          ; preds = %ctor_prologue.barrier.done.585, %ctor_prologue.slow.581
  %.01513 = phi ptr addrspace(1) [ %rs4gc.s68, %ctor_prologue.barrier.done.585 ], [ %rs4gc.s68.relocated, %ctor_prologue.slow.581 ]
  %.01511 = phi ptr addrspace(1) [ %rs4gc.s66.relocated, %ctor_prologue.barrier.done.585 ], [ %rs4gc.s66.relocated963, %ctor_prologue.slow.581 ]
  %.421407 = phi ptr addrspace(1) [ %rs4gc.s13.relocated955, %ctor_prologue.barrier.done.585 ], [ %rs4gc.s13.relocated960, %ctor_prologue.slow.581 ]
  %.391349 = phi ptr addrspace(1) [ %r8.0.relocated957, %ctor_prologue.barrier.done.585 ], [ %r8.0.relocated962, %ctor_prologue.slow.581 ]
  %.42 = phi ptr addrspace(1) [ %rs4gc.s9.relocated956, %ctor_prologue.barrier.done.585 ], [ %rs4gc.s9.relocated961, %ctor_prologue.slow.581 ]
  %r3956 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.585 ], [ %r3955959, %ctor_prologue.slow.581 ]
  %r3957.rs4i = ptrtoint ptr addrspace(1) %.01513 to i64
  %r3957 = call i64 asm "", "=r,0"(i64 %r3957.rs4i) #7
  %r3958 = or i64 %r3957, 9222527611924643840
  %r3959 = bitcast i64 %r3958 to double
  %r3960 = bitcast double %r3956 to i64
  %r3961 = icmp eq i64 %r3960, 9222246136947933185
  br i1 %r3961, label %ctor_ret.merge.587, label %ctor_ret.override.586

ctor_prologue.barrier.maybe.583:                  ; preds = %ctor_prologue.fast.580
  %r3947 = sub i64 %r3915954, 7
  %r3948 = inttoptr i64 %r3947 to ptr
  %r3949 = load i8, ptr %r3948, align 1
  %r3950 = and i8 %r3949, 32
  %r3951 = icmp ne i8 %r3950, 0
  %r3952 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3953 = icmp ne i32 %r3952, 0
  %r3954 = or i1 %r3951, %r3953
  br i1 %r3954, label %ctor_prologue.barrier.584, label %ctor_prologue.barrier.done.585

ctor_prologue.barrier.584:                        ; preds = %ctor_prologue.barrier.maybe.583
  call void @js_write_barrier_slot_validated_parent(i64 %r3915954, i64 %r3935, i64 %r3936) #7
  br label %ctor_prologue.barrier.done.585

ctor_prologue.barrier.done.585:                   ; preds = %ctor_prologue.barrier.584, %ctor_prologue.barrier.maybe.583, %ctor_prologue.fast.580
  br label %ctor_prologue.merge.582

ctor_ret.override.586:                            ; preds = %ctor_prologue.merge.582
  %statepoint_token964 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r3959, double %r3956, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.421407, ptr addrspace(1) %.42, ptr addrspace(1) %.391349, ptr addrspace(1) %.01511) ]
  %r3962965 = call double @llvm.experimental.gc.result.f64(token %statepoint_token964)
  %rs4gc.s13.relocated966 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token964, i32 0, i32 0) ; (%.421407, %.421407)
  %rs4gc.s9.relocated967 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token964, i32 1, i32 1) ; (%.42, %.42)
  %r8.0.relocated968 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token964, i32 2, i32 2) ; (%.391349, %.391349)
  %rs4gc.s66.relocated969 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token964, i32 3, i32 3) ; (%.01511, %.01511)
  br label %ctor_ret.merge.587

ctor_ret.merge.587:                               ; preds = %ctor_ret.override.586, %ctor_prologue.merge.582
  %.11512 = phi ptr addrspace(1) [ %.01511, %ctor_prologue.merge.582 ], [ %rs4gc.s66.relocated969, %ctor_ret.override.586 ]
  %.431408 = phi ptr addrspace(1) [ %.421407, %ctor_prologue.merge.582 ], [ %rs4gc.s13.relocated966, %ctor_ret.override.586 ]
  %.401350 = phi ptr addrspace(1) [ %.391349, %ctor_prologue.merge.582 ], [ %r8.0.relocated968, %ctor_ret.override.586 ]
  %.43 = phi ptr addrspace(1) [ %.42, %ctor_prologue.merge.582 ], [ %rs4gc.s9.relocated967, %ctor_ret.override.586 ]
  %r3963 = phi double [ %r3959, %ctor_prologue.merge.582 ], [ %r3962965, %ctor_ret.override.586 ]
  %r3964.rs4i = ptrtoint ptr addrspace(1) %.431408 to i64
  %r3964.rs4o = call i64 asm "", "=r,0"(i64 %r3964.rs4i) #7
  %r3964 = bitcast i64 %r3964.rs4o to double
  %statepoint_token970 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r3963, double %r3964, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.431408, ptr addrspace(1) %.43, ptr addrspace(1) %.401350, ptr addrspace(1) %.11512) ]
  %r3965971 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token970)
  %rs4gc.s13.relocated972 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token970, i32 0, i32 0) ; (%.431408, %.431408)
  %rs4gc.s9.relocated973 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token970, i32 1, i32 1) ; (%.43, %.43)
  %r8.0.relocated974 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token970, i32 2, i32 2) ; (%.401350, %.401350)
  %rs4gc.s66.relocated975 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token970, i32 3, i32 3) ; (%.11512, %.11512)
  %r3966 = bitcast i64 %r3965971 to double
  %r3967.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s66.relocated975 to i64
  %r3967 = call i64 asm "", "=r,0"(i64 %r3967.rs4i) #7
  %statepoint_token976 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3967, double %r3966, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated972, ptr addrspace(1) %rs4gc.s9.relocated973, ptr addrspace(1) %r8.0.relocated974) ]
  %r3968977 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token976)
  %rs4gc.s13.relocated978 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token976, i32 0, i32 0) ; (%rs4gc.s13.relocated972, %rs4gc.s13.relocated972)
  %rs4gc.s9.relocated979 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token976, i32 1, i32 1) ; (%rs4gc.s9.relocated973, %rs4gc.s9.relocated973)
  %r8.0.relocated980 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token976, i32 2, i32 2) ; (%r8.0.relocated974, %r8.0.relocated974)
  %rs4gc.s69 = inttoptr i64 %r3968977 to ptr addrspace(1)
  %r3969.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s69 to i64
  %r3969 = call i64 asm "", "=r,0"(i64 %r3969.rs4i) #7
  %r3970 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3971 = icmp ne i32 %r3970, 0
  br i1 %r3971, label %shadow.root.barrier.588, label %shadow.root.barrier.done.589

shadow.root.barrier.588:                          ; preds = %ctor_ret.merge.587
  call void @js_write_barrier_root_nanbox(i64 %r3969) #7
  br label %shadow.root.barrier.done.589

shadow.root.barrier.done.589:                     ; preds = %shadow.root.barrier.588, %ctor_ret.merge.587
  %r3972.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s69 to i64
  %r3972 = call i64 asm "", "=r,0"(i64 %r3972.rs4i) #7
  %statepoint_token981 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r3972, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated978, ptr addrspace(1) %rs4gc.s9.relocated979, ptr addrspace(1) %r8.0.relocated980) ]
  %rs4gc.s13.relocated982 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token981, i32 0, i32 0) ; (%rs4gc.s13.relocated978, %rs4gc.s13.relocated978)
  %rs4gc.s9.relocated983 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token981, i32 1, i32 1) ; (%rs4gc.s9.relocated979, %rs4gc.s9.relocated979)
  %r8.0.relocated984 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token981, i32 2, i32 2) ; (%r8.0.relocated980, %r8.0.relocated980)
  %r3974 = load double, ptr @test_json_large_string_emitters_ts_.str.0.handle, align 8
  %rs4gc.b70 = bitcast double %r3974 to i64
  %rs4gc.s70 = inttoptr i64 %rs4gc.b70 to ptr addrspace(1)
  %r3975.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s70 to i64
  %r3975 = call i64 asm "", "=r,0"(i64 %r3975.rs4i) #7
  %r3976 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3977 = icmp ne i32 %r3976, 0
  br i1 %r3977, label %shadow.root.barrier.590, label %shadow.root.barrier.done.591

shadow.root.barrier.590:                          ; preds = %shadow.root.barrier.done.589
  call void @js_write_barrier_root_nanbox(i64 %r3975) #7
  br label %shadow.root.barrier.done.591

shadow.root.barrier.done.591:                     ; preds = %shadow.root.barrier.590, %shadow.root.barrier.done.589
  br label %for.cond.592

for.cond.592:                                     ; preds = %for.update.594, %shadow.root.barrier.done.591
  %.441409 = phi ptr addrspace(1) [ %rs4gc.s13.relocated982, %shadow.root.barrier.done.591 ], [ %.461411, %for.update.594 ]
  %.411351 = phi ptr addrspace(1) [ %r8.0.relocated984, %shadow.root.barrier.done.591 ], [ %.431353, %for.update.594 ]
  %.44 = phi ptr addrspace(1) [ %rs4gc.s9.relocated983, %shadow.root.barrier.done.591 ], [ %.46, %for.update.594 ]
  %r3978.0 = phi i32 [ 0, %shadow.root.barrier.done.591 ], [ %r4025, %for.update.594 ]
  %r3973.0 = phi ptr addrspace(1) [ %rs4gc.s70, %shadow.root.barrier.done.591 ], [ %.01516, %for.update.594 ]
  %r3980 = sitofp i32 %r3978.0 to double
  %r3981 = fcmp olt double %r3980, 2.560000e+02
  %r3982 = select i1 %r3981, i64 9222246136947933188, i64 9222246136947933187
  %r3983 = bitcast i64 %r3982 to double
  %r3984 = icmp eq i64 %r3982, 9222246136947933188
  br i1 %r3984, label %for.body.593, label %for.exit.595

for.body.593:                                     ; preds = %for.cond.592
  %r3985.rs4i = ptrtoint ptr addrspace(1) %r3973.0 to i64
  %r3985.rs4o = call i64 asm "", "=r,0"(i64 %r3985.rs4i) #7
  %r3985 = bitcast i64 %r3985.rs4o to double
  %r3987 = sitofp i32 %r3978.0 to double
  %r3988 = fptosi double %r3987 to i64
  %r3990 = srem i64 %r3988, 3
  %r3991 = sitofp i64 %r3990 to double
  %r3992 = icmp eq i64 %r3990, 0
  %r3993 = fcmp olt double %r3987, 0.000000e+00
  %r3994 = and i1 %r3992, %r3993
  %r3995 = fneg double %r3991
  %r3996 = select i1 %r3994, double %r3995, double %r3991
  %r3997 = fcmp oeq double %r3996, 0.000000e+00
  %r3998 = select i1 %r3997, i64 9222246136947933188, i64 9222246136947933187
  %r3999 = bitcast i64 %r3998 to double
  %r4000 = icmp eq i64 %r3998, 9222246136947933188
  br i1 %r4000, label %ternary.then.596, label %ternary.else.597

for.update.594:                                   ; preds = %gcpoll.done.606
  %r4025 = add i32 %r3978.0, 1
  %r4026 = sitofp i32 %r3978.0 to double
  %r4027 = sitofp i32 %r4025 to double
  br label %for.cond.592

for.exit.595:                                     ; preds = %for.cond.592
  %statepoint_token985 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.441409, ptr addrspace(1) %.44, ptr addrspace(1) %.411351, ptr addrspace(1) %r3973.0) ]
  %r4028986 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token985)
  %rs4gc.s13.relocated987 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token985, i32 0, i32 0) ; (%.441409, %.441409)
  %rs4gc.s9.relocated988 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token985, i32 1, i32 1) ; (%.44, %.44)
  %r8.0.relocated989 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token985, i32 2, i32 2) ; (%.411351, %.411351)
  %r3973.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token985, i32 3, i32 3) ; (%r3973.0, %r3973.0)
  %rs4gc.s71 = inttoptr i64 %r4028986 to ptr addrspace(1)
  %r4029.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s71 to i64
  %r4029 = call i64 asm "", "=r,0"(i64 %r4029.rs4i) #7
  %r4030 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4031 = icmp ne i32 %r4030, 0
  br i1 %r4031, label %shadow.root.barrier.607, label %shadow.root.barrier.done.608

ternary.then.596:                                 ; preds = %for.body.593
  %r4001 = load double, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  br label %ternary.merge.598

ternary.else.597:                                 ; preds = %for.body.593
  %r4002 = load double, ptr @test_json_large_string_emitters_ts_.str.11.handle, align 8
  br label %ternary.merge.598

ternary.merge.598:                                ; preds = %ternary.else.597, %ternary.then.596
  %r4003 = phi double [ %r4001, %ternary.then.596 ], [ %r4002, %ternary.else.597 ]
  %r4004 = bitcast double %r3985 to i64
  %r4005 = lshr i64 %r4004, 48
  %r4006 = icmp eq i64 %r4005, 32767
  br i1 %r4006, label %strapp.dheap.599, label %strapp.dynamic.601

strapp.dheap.599:                                 ; preds = %ternary.merge.598
  %r4007 = bitcast double %r4003 to i64
  %r4008 = lshr i64 %r4007, 48
  %r4009 = icmp eq i64 %r4008, 32765
  br i1 %r4009, label %strapp.dynamic.601, label %strapp.append.600

strapp.append.600:                                ; preds = %strapp.dheap.599
  %statepoint_token990 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_jsvalue_to_string, i32 1, i32 0, double %r4003, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.441409, ptr addrspace(1) %.44, ptr addrspace(1) %.411351, ptr addrspace(1) %r3973.0) ]
  %r4010991 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token990)
  %rs4gc.s13.relocated992 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token990, i32 0, i32 0) ; (%.441409, %.441409)
  %rs4gc.s9.relocated993 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token990, i32 1, i32 1) ; (%.44, %.44)
  %r8.0.relocated994 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token990, i32 2, i32 2) ; (%.411351, %.411351)
  %r3973.0.relocated995 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token990, i32 3, i32 3) ; (%r3973.0, %r3973.0)
  %r4011.rs4i = ptrtoint ptr addrspace(1) %r3973.0.relocated995 to i64
  %r4011.rs4o = call i64 asm "", "=r,0"(i64 %r4011.rs4i) #7
  %r4011 = bitcast i64 %r4011.rs4o to double
  %r4012 = bitcast double %r4011 to i64
  %r4013 = and i64 %r4012, 281474976710655
  %statepoint_token996 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_string_append_known_heap, i32 2, i32 0, i64 %r4013, i64 %r4010991, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated992, ptr addrspace(1) %rs4gc.s9.relocated993, ptr addrspace(1) %r8.0.relocated994) ]
  %r4014997 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token996)
  %rs4gc.s13.relocated998 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token996, i32 0, i32 0) ; (%rs4gc.s13.relocated992, %rs4gc.s13.relocated992)
  %rs4gc.s9.relocated999 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token996, i32 1, i32 1) ; (%rs4gc.s9.relocated993, %rs4gc.s9.relocated993)
  %r8.0.relocated1000 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token996, i32 2, i32 2) ; (%r8.0.relocated994, %r8.0.relocated994)
  %r4015 = or i64 %r4014997, 9223090561878065152
  %r4016 = bitcast i64 %r4015 to double
  br label %strapp.merge.602

strapp.dynamic.601:                               ; preds = %strapp.dheap.599, %ternary.merge.598
  %statepoint_token1001 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r3985, double %r4003, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.441409, ptr addrspace(1) %.44, ptr addrspace(1) %.411351) ]
  %r40171002 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1001)
  %rs4gc.s13.relocated1003 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1001, i32 0, i32 0) ; (%.441409, %.441409)
  %rs4gc.s9.relocated1004 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1001, i32 1, i32 1) ; (%.44, %.44)
  %r8.0.relocated1005 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1001, i32 2, i32 2) ; (%.411351, %.411351)
  br label %strapp.merge.602

strapp.merge.602:                                 ; preds = %strapp.dynamic.601, %strapp.append.600
  %.451410 = phi ptr addrspace(1) [ %rs4gc.s13.relocated1003, %strapp.dynamic.601 ], [ %rs4gc.s13.relocated998, %strapp.append.600 ]
  %.421352 = phi ptr addrspace(1) [ %r8.0.relocated1005, %strapp.dynamic.601 ], [ %r8.0.relocated1000, %strapp.append.600 ]
  %.45 = phi ptr addrspace(1) [ %rs4gc.s9.relocated1004, %strapp.dynamic.601 ], [ %rs4gc.s9.relocated999, %strapp.append.600 ]
  %r4018 = phi double [ %r4016, %strapp.append.600 ], [ %r40171002, %strapp.dynamic.601 ]
  %rs4gc.b72 = bitcast double %r4018 to i64
  %rs4gc.s72 = inttoptr i64 %rs4gc.b72 to ptr addrspace(1)
  %r4019.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s72 to i64
  %r4019 = call i64 asm "", "=r,0"(i64 %r4019.rs4i) #7
  %r4020 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4021 = icmp ne i32 %r4020, 0
  br i1 %r4021, label %shadow.root.barrier.603, label %shadow.root.barrier.done.604

shadow.root.barrier.603:                          ; preds = %strapp.merge.602
  call void @js_write_barrier_root_nanbox(i64 %r4019) #7
  br label %shadow.root.barrier.done.604

shadow.root.barrier.done.604:                     ; preds = %shadow.root.barrier.603, %strapp.merge.602
  %r4022 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r4023 = icmp ne i32 %r4022, 0
  br i1 %r4023, label %gcpoll.605, label %gcpoll.done.606

gcpoll.605:                                       ; preds = %shadow.root.barrier.done.604
  %statepoint_token1006 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s72, ptr addrspace(1) %.451410, ptr addrspace(1) %.45, ptr addrspace(1) %.421352) ]
  %rs4gc.s72.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1006, i32 0, i32 0) ; (%rs4gc.s72, %rs4gc.s72)
  %rs4gc.s13.relocated1007 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1006, i32 1, i32 1) ; (%.451410, %.451410)
  %rs4gc.s9.relocated1008 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1006, i32 2, i32 2) ; (%.45, %.45)
  %r8.0.relocated1009 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1006, i32 3, i32 3) ; (%.421352, %.421352)
  br label %gcpoll.done.606

gcpoll.done.606:                                  ; preds = %gcpoll.605, %shadow.root.barrier.done.604
  %.01516 = phi ptr addrspace(1) [ %rs4gc.s72.relocated, %gcpoll.605 ], [ %rs4gc.s72, %shadow.root.barrier.done.604 ]
  %.461411 = phi ptr addrspace(1) [ %rs4gc.s13.relocated1007, %gcpoll.605 ], [ %.451410, %shadow.root.barrier.done.604 ]
  %.431353 = phi ptr addrspace(1) [ %r8.0.relocated1009, %gcpoll.605 ], [ %.421352, %shadow.root.barrier.done.604 ]
  %.46 = phi ptr addrspace(1) [ %rs4gc.s9.relocated1008, %gcpoll.605 ], [ %.45, %shadow.root.barrier.done.604 ]
  br label %for.update.594

shadow.root.barrier.607:                          ; preds = %for.exit.595
  call void @js_write_barrier_root_nanbox(i64 %r4029) #7
  br label %shadow.root.barrier.done.608

shadow.root.barrier.done.608:                     ; preds = %shadow.root.barrier.607, %for.exit.595
  %r4032 = load double, ptr @test_json_large_string_emitters_ts_.str.12.handle, align 8
  %r4033.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s71 to i64
  %r4033 = call i64 asm "", "=r,0"(i64 %r4033.rs4i) #7
  %statepoint_token1010 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4033, double %r4032, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated987, ptr addrspace(1) %rs4gc.s9.relocated988, ptr addrspace(1) %r8.0.relocated989, ptr addrspace(1) %r3973.0.relocated) ]
  %r40341011 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1010)
  %rs4gc.s13.relocated1012 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1010, i32 0, i32 0) ; (%rs4gc.s13.relocated987, %rs4gc.s13.relocated987)
  %rs4gc.s9.relocated1013 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1010, i32 1, i32 1) ; (%rs4gc.s9.relocated988, %rs4gc.s9.relocated988)
  %r8.0.relocated1014 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1010, i32 2, i32 2) ; (%r8.0.relocated989, %r8.0.relocated989)
  %r3973.0.relocated1015 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1010, i32 3, i32 3) ; (%r3973.0.relocated, %r3973.0.relocated)
  %rs4gc.s73 = inttoptr i64 %r40341011 to ptr addrspace(1)
  %r4035.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s73 to i64
  %r4035 = call i64 asm "", "=r,0"(i64 %r4035.rs4i) #7
  %r4036 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4037 = icmp ne i32 %r4036, 0
  br i1 %r4037, label %shadow.root.barrier.609, label %shadow.root.barrier.done.610

shadow.root.barrier.609:                          ; preds = %shadow.root.barrier.done.608
  call void @js_write_barrier_root_nanbox(i64 %r4035) #7
  br label %shadow.root.barrier.done.610

shadow.root.barrier.done.610:                     ; preds = %shadow.root.barrier.609, %shadow.root.barrier.done.608
  %r4038.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s73 to i64
  %r4038 = call i64 asm "", "=r,0"(i64 %r4038.rs4i) #7
  %statepoint_token1016 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4038, double 2.560000e+02, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1012, ptr addrspace(1) %rs4gc.s9.relocated1013, ptr addrspace(1) %r8.0.relocated1014, ptr addrspace(1) %r3973.0.relocated1015) ]
  %r40391017 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1016)
  %rs4gc.s13.relocated1018 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1016, i32 0, i32 0) ; (%rs4gc.s13.relocated1012, %rs4gc.s13.relocated1012)
  %rs4gc.s9.relocated1019 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1016, i32 1, i32 1) ; (%rs4gc.s9.relocated1013, %rs4gc.s9.relocated1013)
  %r8.0.relocated1020 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1016, i32 2, i32 2) ; (%r8.0.relocated1014, %r8.0.relocated1014)
  %r3973.0.relocated1021 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1016, i32 3, i32 3) ; (%r3973.0.relocated1015, %r3973.0.relocated1015)
  %rs4gc.s74 = inttoptr i64 %r40391017 to ptr addrspace(1)
  %r4040.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s74 to i64
  %r4040 = call i64 asm "", "=r,0"(i64 %r4040.rs4i) #7
  %r4041 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4042 = icmp ne i32 %r4041, 0
  br i1 %r4042, label %shadow.root.barrier.611, label %shadow.root.barrier.done.612

shadow.root.barrier.611:                          ; preds = %shadow.root.barrier.done.610
  call void @js_write_barrier_root_nanbox(i64 %r4040) #7
  br label %shadow.root.barrier.done.612

shadow.root.barrier.done.612:                     ; preds = %shadow.root.barrier.611, %shadow.root.barrier.done.610
  %r4043.rs4i = ptrtoint ptr addrspace(1) %r3973.0.relocated1021 to i64
  %r4043.rs4o = call i64 asm "", "=r,0"(i64 %r4043.rs4i) #7
  %r4043 = bitcast i64 %r4043.rs4o to double
  %r4044 = bitcast double %r4043 to i64
  %rs4gc.s75 = inttoptr i64 %r4044 to ptr addrspace(1)
  %r4045.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s75 to i64
  %r4045 = call i64 asm "", "=r,0"(i64 %r4045.rs4i) #7
  %r4046 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4047 = icmp ne i32 %r4046, 0
  br i1 %r4047, label %shadow.root.barrier.613, label %shadow.root.barrier.done.614

shadow.root.barrier.613:                          ; preds = %shadow.root.barrier.done.612
  call void @js_write_barrier_root_nanbox(i64 %r4045) #7
  br label %shadow.root.barrier.done.614

shadow.root.barrier.done.614:                     ; preds = %shadow.root.barrier.613, %shadow.root.barrier.done.612
  %r4048.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9.relocated1019 to i64
  %r4048 = call i64 asm "", "=r,0"(i64 %r4048.rs4i) #7
  %statepoint_token1022 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 3, i32 0, i32 1, i64 %r4048, i32 %r3833, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1018, ptr addrspace(1) %rs4gc.s9.relocated1019, ptr addrspace(1) %r8.0.relocated1020, ptr addrspace(1) %r3973.0.relocated1021, ptr addrspace(1) %rs4gc.s74, ptr addrspace(1) %rs4gc.s75) ]
  %r40501023 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1022)
  %rs4gc.s13.relocated1024 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1022, i32 0, i32 0) ; (%rs4gc.s13.relocated1018, %rs4gc.s13.relocated1018)
  %rs4gc.s9.relocated1025 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1022, i32 1, i32 1) ; (%rs4gc.s9.relocated1019, %rs4gc.s9.relocated1019)
  %r8.0.relocated1026 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1022, i32 2, i32 2) ; (%r8.0.relocated1020, %r8.0.relocated1020)
  %r3973.0.relocated1027 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1022, i32 3, i32 3) ; (%r3973.0.relocated1021, %r3973.0.relocated1021)
  %rs4gc.s74.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1022, i32 4, i32 4) ; (%rs4gc.s74, %rs4gc.s74)
  %rs4gc.s75.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1022, i32 5, i32 5) ; (%rs4gc.s75, %rs4gc.s75)
  call void @js_gc_declare_typed_shape_layout(i64 %r40501023, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, i32 1) #7
  %rs4gc.s76 = inttoptr i64 %r40501023 to ptr addrspace(1)
  %r4051.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s76 to i64
  %r4051 = call i64 asm "", "=r,0"(i64 %r4051.rs4i) #7
  %r4052 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4053 = icmp ne i32 %r4052, 0
  br i1 %r4053, label %shadow.root.barrier.615, label %shadow.root.barrier.done.616

shadow.root.barrier.615:                          ; preds = %shadow.root.barrier.done.614
  call void @js_write_barrier_root_nanbox(i64 %r4051) #7
  br label %shadow.root.barrier.done.616

shadow.root.barrier.done.616:                     ; preds = %shadow.root.barrier.615, %shadow.root.barrier.done.614
  %r4054 = or i64 %r40501023, 9222527611924643840
  %r4055 = bitcast i64 %r4054 to double
  %r4056.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s75.relocated to i64
  %r4056 = call i64 asm "", "=r,0"(i64 %r4056.rs4i) #7
  %r4057 = bitcast i64 %r4056 to double
  %r4058 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r4059 = icmp eq i8 %r4058, 0
  %r4060 = inttoptr i64 %r40501023 to ptr
  %r4061 = getelementptr i8, ptr %r4060, i64 -6
  %r4062 = load i16, ptr %r4061, align 2
  %r4063 = and i16 %r4062, 4096
  %r4064 = icmp ne i16 %r4063, 0
  %r4065 = and i1 %r4059, %r4064
  br i1 %r4065, label %ctor_prologue.fast.617, label %ctor_prologue.slow.618

ctor_prologue.fast.617:                           ; preds = %shadow.root.barrier.done.616
  %r4066 = inttoptr i64 %r40501023 to ptr
  %r4067 = getelementptr i8, ptr %r4066, i64 16
  %r4068 = bitcast double %r4055 to i64
  %r4069 = getelementptr double, ptr %r4067, i64 0
  store double %r4057, ptr %r4069, align 8
  %r4070 = ptrtoint ptr %r4069 to i64
  %r4071 = bitcast double %r4057 to i64
  %r4072 = lshr i64 %r4071, 48
  %r4073 = icmp eq i64 %r4072, 0
  %r4074 = icmp uge i64 %r4071, 4096
  %r4075 = and i1 %r4073, %r4074
  %r4076 = icmp eq i64 %r4072, 32765
  %r4077 = icmp eq i64 %r4072, 32767
  %r4078 = icmp eq i64 %r4072, 32762
  %r4079 = or i1 %r4076, %r4077
  %r4080 = or i1 %r4079, %r4078
  %r4081 = or i1 %r4080, %r4075
  br i1 %r4081, label %ctor_prologue.barrier.maybe.620, label %ctor_prologue.barrier.done.622

ctor_prologue.slow.618:                           ; preds = %shadow.root.barrier.done.616
  %statepoint_token1028 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3_constructor, i32 2, i32 0, double %r4055, double %r4057, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1024, ptr addrspace(1) %rs4gc.s9.relocated1025, ptr addrspace(1) %r8.0.relocated1026, ptr addrspace(1) %r3973.0.relocated1027, ptr addrspace(1) %rs4gc.s74.relocated, ptr addrspace(1) %rs4gc.s76) ]
  %r40901029 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1028)
  %rs4gc.s13.relocated1030 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1028, i32 0, i32 0) ; (%rs4gc.s13.relocated1024, %rs4gc.s13.relocated1024)
  %rs4gc.s9.relocated1031 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1028, i32 1, i32 1) ; (%rs4gc.s9.relocated1025, %rs4gc.s9.relocated1025)
  %r8.0.relocated1032 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1028, i32 2, i32 2) ; (%r8.0.relocated1026, %r8.0.relocated1026)
  %r3973.0.relocated1033 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1028, i32 3, i32 3) ; (%r3973.0.relocated1027, %r3973.0.relocated1027)
  %rs4gc.s74.relocated1034 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1028, i32 4, i32 4) ; (%rs4gc.s74.relocated, %rs4gc.s74.relocated)
  %rs4gc.s76.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1028, i32 5, i32 5) ; (%rs4gc.s76, %rs4gc.s76)
  br label %ctor_prologue.merge.619

ctor_prologue.merge.619:                          ; preds = %ctor_prologue.barrier.done.622, %ctor_prologue.slow.618
  %.01519 = phi ptr addrspace(1) [ %rs4gc.s76, %ctor_prologue.barrier.done.622 ], [ %rs4gc.s76.relocated, %ctor_prologue.slow.618 ]
  %.01517 = phi ptr addrspace(1) [ %rs4gc.s74.relocated, %ctor_prologue.barrier.done.622 ], [ %rs4gc.s74.relocated1034, %ctor_prologue.slow.618 ]
  %.01514 = phi ptr addrspace(1) [ %r3973.0.relocated1027, %ctor_prologue.barrier.done.622 ], [ %r3973.0.relocated1033, %ctor_prologue.slow.618 ]
  %.471412 = phi ptr addrspace(1) [ %rs4gc.s13.relocated1024, %ctor_prologue.barrier.done.622 ], [ %rs4gc.s13.relocated1030, %ctor_prologue.slow.618 ]
  %.441354 = phi ptr addrspace(1) [ %r8.0.relocated1026, %ctor_prologue.barrier.done.622 ], [ %r8.0.relocated1032, %ctor_prologue.slow.618 ]
  %.47 = phi ptr addrspace(1) [ %rs4gc.s9.relocated1025, %ctor_prologue.barrier.done.622 ], [ %rs4gc.s9.relocated1031, %ctor_prologue.slow.618 ]
  %r4091 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.622 ], [ %r40901029, %ctor_prologue.slow.618 ]
  %r4092.rs4i = ptrtoint ptr addrspace(1) %.01519 to i64
  %r4092 = call i64 asm "", "=r,0"(i64 %r4092.rs4i) #7
  %r4093 = or i64 %r4092, 9222527611924643840
  %r4094 = bitcast i64 %r4093 to double
  %r4095 = bitcast double %r4091 to i64
  %r4096 = icmp eq i64 %r4095, 9222246136947933185
  br i1 %r4096, label %ctor_ret.merge.624, label %ctor_ret.override.623

ctor_prologue.barrier.maybe.620:                  ; preds = %ctor_prologue.fast.617
  %r4082 = sub i64 %r40501023, 7
  %r4083 = inttoptr i64 %r4082 to ptr
  %r4084 = load i8, ptr %r4083, align 1
  %r4085 = and i8 %r4084, 32
  %r4086 = icmp ne i8 %r4085, 0
  %r4087 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4088 = icmp ne i32 %r4087, 0
  %r4089 = or i1 %r4086, %r4088
  br i1 %r4089, label %ctor_prologue.barrier.621, label %ctor_prologue.barrier.done.622

ctor_prologue.barrier.621:                        ; preds = %ctor_prologue.barrier.maybe.620
  call void @js_write_barrier_slot_validated_parent(i64 %r40501023, i64 %r4070, i64 %r4071) #7
  br label %ctor_prologue.barrier.done.622

ctor_prologue.barrier.done.622:                   ; preds = %ctor_prologue.barrier.621, %ctor_prologue.barrier.maybe.620, %ctor_prologue.fast.617
  br label %ctor_prologue.merge.619

ctor_ret.override.623:                            ; preds = %ctor_prologue.merge.619
  %statepoint_token1035 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r4094, double %r4091, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.471412, ptr addrspace(1) %.47, ptr addrspace(1) %.441354, ptr addrspace(1) %.01514, ptr addrspace(1) %.01517) ]
  %r40971036 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1035)
  %rs4gc.s13.relocated1037 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1035, i32 0, i32 0) ; (%.471412, %.471412)
  %rs4gc.s9.relocated1038 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1035, i32 1, i32 1) ; (%.47, %.47)
  %r8.0.relocated1039 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1035, i32 2, i32 2) ; (%.441354, %.441354)
  %r3973.0.relocated1040 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1035, i32 3, i32 3) ; (%.01514, %.01514)
  %rs4gc.s74.relocated1041 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1035, i32 4, i32 4) ; (%.01517, %.01517)
  br label %ctor_ret.merge.624

ctor_ret.merge.624:                               ; preds = %ctor_ret.override.623, %ctor_prologue.merge.619
  %.11518 = phi ptr addrspace(1) [ %.01517, %ctor_prologue.merge.619 ], [ %rs4gc.s74.relocated1041, %ctor_ret.override.623 ]
  %.11515 = phi ptr addrspace(1) [ %.01514, %ctor_prologue.merge.619 ], [ %r3973.0.relocated1040, %ctor_ret.override.623 ]
  %.481413 = phi ptr addrspace(1) [ %.471412, %ctor_prologue.merge.619 ], [ %rs4gc.s13.relocated1037, %ctor_ret.override.623 ]
  %.451355 = phi ptr addrspace(1) [ %.441354, %ctor_prologue.merge.619 ], [ %r8.0.relocated1039, %ctor_ret.override.623 ]
  %.48 = phi ptr addrspace(1) [ %.47, %ctor_prologue.merge.619 ], [ %rs4gc.s9.relocated1038, %ctor_ret.override.623 ]
  %r4098 = phi double [ %r4094, %ctor_prologue.merge.619 ], [ %r40971036, %ctor_ret.override.623 ]
  %statepoint_token1042 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4098, double 0x7FFC000000000002, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.481413, ptr addrspace(1) %.48, ptr addrspace(1) %.451355, ptr addrspace(1) %.11515, ptr addrspace(1) %.11518) ]
  %r40991043 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1042)
  %rs4gc.s13.relocated1044 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1042, i32 0, i32 0) ; (%.481413, %.481413)
  %rs4gc.s9.relocated1045 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1042, i32 1, i32 1) ; (%.48, %.48)
  %r8.0.relocated1046 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1042, i32 2, i32 2) ; (%.451355, %.451355)
  %r3973.0.relocated1047 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1042, i32 3, i32 3) ; (%.11515, %.11515)
  %rs4gc.s74.relocated1048 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1042, i32 4, i32 4) ; (%.11518, %.11518)
  %r4100 = bitcast i64 %r40991043 to double
  %r4101.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s74.relocated1048 to i64
  %r4101 = call i64 asm "", "=r,0"(i64 %r4101.rs4i) #7
  %statepoint_token1049 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4101, double %r4100, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1044, ptr addrspace(1) %rs4gc.s9.relocated1045, ptr addrspace(1) %r8.0.relocated1046, ptr addrspace(1) %r3973.0.relocated1047) ]
  %r41021050 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1049)
  %rs4gc.s13.relocated1051 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1049, i32 0, i32 0) ; (%rs4gc.s13.relocated1044, %rs4gc.s13.relocated1044)
  %rs4gc.s9.relocated1052 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1049, i32 1, i32 1) ; (%rs4gc.s9.relocated1045, %rs4gc.s9.relocated1045)
  %r8.0.relocated1053 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1049, i32 2, i32 2) ; (%r8.0.relocated1046, %r8.0.relocated1046)
  %r3973.0.relocated1054 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1049, i32 3, i32 3) ; (%r3973.0.relocated1047, %r3973.0.relocated1047)
  %rs4gc.s77 = inttoptr i64 %r41021050 to ptr addrspace(1)
  %r4103.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s77 to i64
  %r4103 = call i64 asm "", "=r,0"(i64 %r4103.rs4i) #7
  %r4104 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4105 = icmp ne i32 %r4104, 0
  br i1 %r4105, label %shadow.root.barrier.625, label %shadow.root.barrier.done.626

shadow.root.barrier.625:                          ; preds = %ctor_ret.merge.624
  call void @js_write_barrier_root_nanbox(i64 %r4103) #7
  br label %shadow.root.barrier.done.626

shadow.root.barrier.done.626:                     ; preds = %shadow.root.barrier.625, %ctor_ret.merge.624
  %r4106.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s77 to i64
  %r4106 = call i64 asm "", "=r,0"(i64 %r4106.rs4i) #7
  %statepoint_token1055 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r4106, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1051, ptr addrspace(1) %rs4gc.s9.relocated1052, ptr addrspace(1) %r8.0.relocated1053, ptr addrspace(1) %r3973.0.relocated1054) ]
  %rs4gc.s13.relocated1056 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1055, i32 0, i32 0) ; (%rs4gc.s13.relocated1051, %rs4gc.s13.relocated1051)
  %rs4gc.s9.relocated1057 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1055, i32 1, i32 1) ; (%rs4gc.s9.relocated1052, %rs4gc.s9.relocated1052)
  %r8.0.relocated1058 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1055, i32 2, i32 2) ; (%r8.0.relocated1053, %r8.0.relocated1053)
  %r3973.0.relocated1059 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1055, i32 3, i32 3) ; (%r3973.0.relocated1054, %r3973.0.relocated1054)
  %statepoint_token1060 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1056, ptr addrspace(1) %rs4gc.s9.relocated1057, ptr addrspace(1) %r8.0.relocated1058, ptr addrspace(1) %r3973.0.relocated1059) ]
  %r41071061 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1060)
  %rs4gc.s13.relocated1062 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1060, i32 0, i32 0) ; (%rs4gc.s13.relocated1056, %rs4gc.s13.relocated1056)
  %rs4gc.s9.relocated1063 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1060, i32 1, i32 1) ; (%rs4gc.s9.relocated1057, %rs4gc.s9.relocated1057)
  %r8.0.relocated1064 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1060, i32 2, i32 2) ; (%r8.0.relocated1058, %r8.0.relocated1058)
  %r3973.0.relocated1065 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1060, i32 3, i32 3) ; (%r3973.0.relocated1059, %r3973.0.relocated1059)
  %rs4gc.s78 = inttoptr i64 %r41071061 to ptr addrspace(1)
  %r4108.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s78 to i64
  %r4108 = call i64 asm "", "=r,0"(i64 %r4108.rs4i) #7
  %r4109 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4110 = icmp ne i32 %r4109, 0
  br i1 %r4110, label %shadow.root.barrier.627, label %shadow.root.barrier.done.628

shadow.root.barrier.627:                          ; preds = %shadow.root.barrier.done.626
  call void @js_write_barrier_root_nanbox(i64 %r4108) #7
  br label %shadow.root.barrier.done.628

shadow.root.barrier.done.628:                     ; preds = %shadow.root.barrier.627, %shadow.root.barrier.done.626
  %r4111 = load double, ptr @test_json_large_string_emitters_ts_.str.13.handle, align 8
  %r4112.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s78 to i64
  %r4112 = call i64 asm "", "=r,0"(i64 %r4112.rs4i) #7
  %statepoint_token1066 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4112, double %r4111, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1062, ptr addrspace(1) %rs4gc.s9.relocated1063, ptr addrspace(1) %r8.0.relocated1064, ptr addrspace(1) %r3973.0.relocated1065) ]
  %r41131067 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1066)
  %rs4gc.s13.relocated1068 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1066, i32 0, i32 0) ; (%rs4gc.s13.relocated1062, %rs4gc.s13.relocated1062)
  %rs4gc.s9.relocated1069 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1066, i32 1, i32 1) ; (%rs4gc.s9.relocated1063, %rs4gc.s9.relocated1063)
  %r8.0.relocated1070 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1066, i32 2, i32 2) ; (%r8.0.relocated1064, %r8.0.relocated1064)
  %r3973.0.relocated1071 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1066, i32 3, i32 3) ; (%r3973.0.relocated1065, %r3973.0.relocated1065)
  %rs4gc.s79 = inttoptr i64 %r41131067 to ptr addrspace(1)
  %r4114.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s79 to i64
  %r4114 = call i64 asm "", "=r,0"(i64 %r4114.rs4i) #7
  %r4115 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4116 = icmp ne i32 %r4115, 0
  br i1 %r4116, label %shadow.root.barrier.629, label %shadow.root.barrier.done.630

shadow.root.barrier.629:                          ; preds = %shadow.root.barrier.done.628
  call void @js_write_barrier_root_nanbox(i64 %r4114) #7
  br label %shadow.root.barrier.done.630

shadow.root.barrier.done.630:                     ; preds = %shadow.root.barrier.629, %shadow.root.barrier.done.628
  %r4117.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s79 to i64
  %r4117 = call i64 asm "", "=r,0"(i64 %r4117.rs4i) #7
  %statepoint_token1072 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4117, double 2.560000e+02, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1068, ptr addrspace(1) %rs4gc.s9.relocated1069, ptr addrspace(1) %r8.0.relocated1070, ptr addrspace(1) %r3973.0.relocated1071) ]
  %r41181073 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1072)
  %rs4gc.s13.relocated1074 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1072, i32 0, i32 0) ; (%rs4gc.s13.relocated1068, %rs4gc.s13.relocated1068)
  %rs4gc.s9.relocated1075 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1072, i32 1, i32 1) ; (%rs4gc.s9.relocated1069, %rs4gc.s9.relocated1069)
  %r8.0.relocated1076 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1072, i32 2, i32 2) ; (%r8.0.relocated1070, %r8.0.relocated1070)
  %r3973.0.relocated1077 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1072, i32 3, i32 3) ; (%r3973.0.relocated1071, %r3973.0.relocated1071)
  %rs4gc.s80 = inttoptr i64 %r41181073 to ptr addrspace(1)
  %r4119.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s80 to i64
  %r4119 = call i64 asm "", "=r,0"(i64 %r4119.rs4i) #7
  %r4120 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4121 = icmp ne i32 %r4120, 0
  br i1 %r4121, label %shadow.root.barrier.631, label %shadow.root.barrier.done.632

shadow.root.barrier.631:                          ; preds = %shadow.root.barrier.done.630
  call void @js_write_barrier_root_nanbox(i64 %r4119) #7
  br label %shadow.root.barrier.done.632

shadow.root.barrier.done.632:                     ; preds = %shadow.root.barrier.631, %shadow.root.barrier.done.630
  %r4122.rs4i = ptrtoint ptr addrspace(1) %r3973.0.relocated1077 to i64
  %r4122.rs4o = call i64 asm "", "=r,0"(i64 %r4122.rs4i) #7
  %r4122 = bitcast i64 %r4122.rs4o to double
  %r4123 = bitcast double %r4122 to i64
  %rs4gc.s81 = inttoptr i64 %r4123 to ptr addrspace(1)
  %r4124.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s81 to i64
  %r4124 = call i64 asm "", "=r,0"(i64 %r4124.rs4i) #7
  %r4125 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4126 = icmp ne i32 %r4125, 0
  br i1 %r4126, label %shadow.root.barrier.633, label %shadow.root.barrier.done.634

shadow.root.barrier.633:                          ; preds = %shadow.root.barrier.done.632
  call void @js_write_barrier_root_nanbox(i64 %r4124) #7
  br label %shadow.root.barrier.done.634

shadow.root.barrier.done.634:                     ; preds = %shadow.root.barrier.633, %shadow.root.barrier.done.632
  %r4127.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9.relocated1075 to i64
  %r4127 = call i64 asm "", "=r,0"(i64 %r4127.rs4i) #7
  %statepoint_token1078 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 3, i32 0, i32 1, i64 %r4127, i32 %r3833, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1074, ptr addrspace(1) %rs4gc.s9.relocated1075, ptr addrspace(1) %r8.0.relocated1076, ptr addrspace(1) %rs4gc.s80, ptr addrspace(1) %rs4gc.s81) ]
  %r41291079 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1078)
  %rs4gc.s13.relocated1080 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1078, i32 0, i32 0) ; (%rs4gc.s13.relocated1074, %rs4gc.s13.relocated1074)
  %rs4gc.s9.relocated1081 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1078, i32 1, i32 1) ; (%rs4gc.s9.relocated1075, %rs4gc.s9.relocated1075)
  %r8.0.relocated1082 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1078, i32 2, i32 2) ; (%r8.0.relocated1076, %r8.0.relocated1076)
  %rs4gc.s80.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1078, i32 3, i32 3) ; (%rs4gc.s80, %rs4gc.s80)
  %rs4gc.s81.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1078, i32 4, i32 4) ; (%rs4gc.s81, %rs4gc.s81)
  call void @js_gc_declare_typed_shape_layout(i64 %r41291079, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, i32 1) #7
  %rs4gc.s82 = inttoptr i64 %r41291079 to ptr addrspace(1)
  %r4130.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s82 to i64
  %r4130 = call i64 asm "", "=r,0"(i64 %r4130.rs4i) #7
  %r4131 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4132 = icmp ne i32 %r4131, 0
  br i1 %r4132, label %shadow.root.barrier.635, label %shadow.root.barrier.done.636

shadow.root.barrier.635:                          ; preds = %shadow.root.barrier.done.634
  call void @js_write_barrier_root_nanbox(i64 %r4130) #7
  br label %shadow.root.barrier.done.636

shadow.root.barrier.done.636:                     ; preds = %shadow.root.barrier.635, %shadow.root.barrier.done.634
  %r4133 = or i64 %r41291079, 9222527611924643840
  %r4134 = bitcast i64 %r4133 to double
  %r4135.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s81.relocated to i64
  %r4135 = call i64 asm "", "=r,0"(i64 %r4135.rs4i) #7
  %r4136 = bitcast i64 %r4135 to double
  %r4137 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r4138 = icmp eq i8 %r4137, 0
  %r4139 = inttoptr i64 %r41291079 to ptr
  %r4140 = getelementptr i8, ptr %r4139, i64 -6
  %r4141 = load i16, ptr %r4140, align 2
  %r4142 = and i16 %r4141, 4096
  %r4143 = icmp ne i16 %r4142, 0
  %r4144 = and i1 %r4138, %r4143
  br i1 %r4144, label %ctor_prologue.fast.637, label %ctor_prologue.slow.638

ctor_prologue.fast.637:                           ; preds = %shadow.root.barrier.done.636
  %r4145 = inttoptr i64 %r41291079 to ptr
  %r4146 = getelementptr i8, ptr %r4145, i64 16
  %r4147 = bitcast double %r4134 to i64
  %r4148 = getelementptr double, ptr %r4146, i64 0
  store double %r4136, ptr %r4148, align 8
  %r4149 = ptrtoint ptr %r4148 to i64
  %r4150 = bitcast double %r4136 to i64
  %r4151 = lshr i64 %r4150, 48
  %r4152 = icmp eq i64 %r4151, 0
  %r4153 = icmp uge i64 %r4150, 4096
  %r4154 = and i1 %r4152, %r4153
  %r4155 = icmp eq i64 %r4151, 32765
  %r4156 = icmp eq i64 %r4151, 32767
  %r4157 = icmp eq i64 %r4151, 32762
  %r4158 = or i1 %r4155, %r4156
  %r4159 = or i1 %r4158, %r4157
  %r4160 = or i1 %r4159, %r4154
  br i1 %r4160, label %ctor_prologue.barrier.maybe.640, label %ctor_prologue.barrier.done.642

ctor_prologue.slow.638:                           ; preds = %shadow.root.barrier.done.636
  %statepoint_token1083 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3_constructor, i32 2, i32 0, double %r4134, double %r4136, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1080, ptr addrspace(1) %rs4gc.s9.relocated1081, ptr addrspace(1) %r8.0.relocated1082, ptr addrspace(1) %rs4gc.s80.relocated, ptr addrspace(1) %rs4gc.s82) ]
  %r41691084 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1083)
  %rs4gc.s13.relocated1085 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1083, i32 0, i32 0) ; (%rs4gc.s13.relocated1080, %rs4gc.s13.relocated1080)
  %rs4gc.s9.relocated1086 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1083, i32 1, i32 1) ; (%rs4gc.s9.relocated1081, %rs4gc.s9.relocated1081)
  %r8.0.relocated1087 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1083, i32 2, i32 2) ; (%r8.0.relocated1082, %r8.0.relocated1082)
  %rs4gc.s80.relocated1088 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1083, i32 3, i32 3) ; (%rs4gc.s80.relocated, %rs4gc.s80.relocated)
  %rs4gc.s82.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1083, i32 4, i32 4) ; (%rs4gc.s82, %rs4gc.s82)
  br label %ctor_prologue.merge.639

ctor_prologue.merge.639:                          ; preds = %ctor_prologue.barrier.done.642, %ctor_prologue.slow.638
  %.01522 = phi ptr addrspace(1) [ %rs4gc.s82, %ctor_prologue.barrier.done.642 ], [ %rs4gc.s82.relocated, %ctor_prologue.slow.638 ]
  %.01520 = phi ptr addrspace(1) [ %rs4gc.s80.relocated, %ctor_prologue.barrier.done.642 ], [ %rs4gc.s80.relocated1088, %ctor_prologue.slow.638 ]
  %.491414 = phi ptr addrspace(1) [ %rs4gc.s13.relocated1080, %ctor_prologue.barrier.done.642 ], [ %rs4gc.s13.relocated1085, %ctor_prologue.slow.638 ]
  %.461356 = phi ptr addrspace(1) [ %r8.0.relocated1082, %ctor_prologue.barrier.done.642 ], [ %r8.0.relocated1087, %ctor_prologue.slow.638 ]
  %.49 = phi ptr addrspace(1) [ %rs4gc.s9.relocated1081, %ctor_prologue.barrier.done.642 ], [ %rs4gc.s9.relocated1086, %ctor_prologue.slow.638 ]
  %r4170 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.642 ], [ %r41691084, %ctor_prologue.slow.638 ]
  %r4171.rs4i = ptrtoint ptr addrspace(1) %.01522 to i64
  %r4171 = call i64 asm "", "=r,0"(i64 %r4171.rs4i) #7
  %r4172 = or i64 %r4171, 9222527611924643840
  %r4173 = bitcast i64 %r4172 to double
  %r4174 = bitcast double %r4170 to i64
  %r4175 = icmp eq i64 %r4174, 9222246136947933185
  br i1 %r4175, label %ctor_ret.merge.644, label %ctor_ret.override.643

ctor_prologue.barrier.maybe.640:                  ; preds = %ctor_prologue.fast.637
  %r4161 = sub i64 %r41291079, 7
  %r4162 = inttoptr i64 %r4161 to ptr
  %r4163 = load i8, ptr %r4162, align 1
  %r4164 = and i8 %r4163, 32
  %r4165 = icmp ne i8 %r4164, 0
  %r4166 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4167 = icmp ne i32 %r4166, 0
  %r4168 = or i1 %r4165, %r4167
  br i1 %r4168, label %ctor_prologue.barrier.641, label %ctor_prologue.barrier.done.642

ctor_prologue.barrier.641:                        ; preds = %ctor_prologue.barrier.maybe.640
  call void @js_write_barrier_slot_validated_parent(i64 %r41291079, i64 %r4149, i64 %r4150) #7
  br label %ctor_prologue.barrier.done.642

ctor_prologue.barrier.done.642:                   ; preds = %ctor_prologue.barrier.641, %ctor_prologue.barrier.maybe.640, %ctor_prologue.fast.637
  br label %ctor_prologue.merge.639

ctor_ret.override.643:                            ; preds = %ctor_prologue.merge.639
  %statepoint_token1089 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r4173, double %r4170, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.491414, ptr addrspace(1) %.49, ptr addrspace(1) %.461356, ptr addrspace(1) %.01520) ]
  %r41761090 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1089)
  %rs4gc.s13.relocated1091 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1089, i32 0, i32 0) ; (%.491414, %.491414)
  %rs4gc.s9.relocated1092 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1089, i32 1, i32 1) ; (%.49, %.49)
  %r8.0.relocated1093 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1089, i32 2, i32 2) ; (%.461356, %.461356)
  %rs4gc.s80.relocated1094 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1089, i32 3, i32 3) ; (%.01520, %.01520)
  br label %ctor_ret.merge.644

ctor_ret.merge.644:                               ; preds = %ctor_ret.override.643, %ctor_prologue.merge.639
  %.11521 = phi ptr addrspace(1) [ %.01520, %ctor_prologue.merge.639 ], [ %rs4gc.s80.relocated1094, %ctor_ret.override.643 ]
  %.501415 = phi ptr addrspace(1) [ %.491414, %ctor_prologue.merge.639 ], [ %rs4gc.s13.relocated1091, %ctor_ret.override.643 ]
  %.471357 = phi ptr addrspace(1) [ %.461356, %ctor_prologue.merge.639 ], [ %r8.0.relocated1093, %ctor_ret.override.643 ]
  %.50 = phi ptr addrspace(1) [ %.49, %ctor_prologue.merge.639 ], [ %rs4gc.s9.relocated1092, %ctor_ret.override.643 ]
  %r4177 = phi double [ %r4173, %ctor_prologue.merge.639 ], [ %r41761090, %ctor_ret.override.643 ]
  %r4178.rs4i = ptrtoint ptr addrspace(1) %.501415 to i64
  %r4178.rs4o = call i64 asm "", "=r,0"(i64 %r4178.rs4i) #7
  %r4178 = bitcast i64 %r4178.rs4o to double
  %statepoint_token1095 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4177, double %r4178, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.501415, ptr addrspace(1) %.50, ptr addrspace(1) %.471357, ptr addrspace(1) %.11521) ]
  %r41791096 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1095)
  %rs4gc.s13.relocated1097 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1095, i32 0, i32 0) ; (%.501415, %.501415)
  %rs4gc.s9.relocated1098 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1095, i32 1, i32 1) ; (%.50, %.50)
  %r8.0.relocated1099 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1095, i32 2, i32 2) ; (%.471357, %.471357)
  %rs4gc.s80.relocated1100 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1095, i32 3, i32 3) ; (%.11521, %.11521)
  %r4180 = bitcast i64 %r41791096 to double
  %r4181.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s80.relocated1100 to i64
  %r4181 = call i64 asm "", "=r,0"(i64 %r4181.rs4i) #7
  %statepoint_token1101 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4181, double %r4180, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1097, ptr addrspace(1) %rs4gc.s9.relocated1098, ptr addrspace(1) %r8.0.relocated1099) ]
  %r41821102 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1101)
  %rs4gc.s13.relocated1103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1101, i32 0, i32 0) ; (%rs4gc.s13.relocated1097, %rs4gc.s13.relocated1097)
  %rs4gc.s9.relocated1104 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1101, i32 1, i32 1) ; (%rs4gc.s9.relocated1098, %rs4gc.s9.relocated1098)
  %r8.0.relocated1105 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1101, i32 2, i32 2) ; (%r8.0.relocated1099, %r8.0.relocated1099)
  %rs4gc.s83 = inttoptr i64 %r41821102 to ptr addrspace(1)
  %r4183.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s83 to i64
  %r4183 = call i64 asm "", "=r,0"(i64 %r4183.rs4i) #7
  %r4184 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4185 = icmp ne i32 %r4184, 0
  br i1 %r4185, label %shadow.root.barrier.645, label %shadow.root.barrier.done.646

shadow.root.barrier.645:                          ; preds = %ctor_ret.merge.644
  call void @js_write_barrier_root_nanbox(i64 %r4183) #7
  br label %shadow.root.barrier.done.646

shadow.root.barrier.done.646:                     ; preds = %shadow.root.barrier.645, %ctor_ret.merge.644
  %r4186.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s83 to i64
  %r4186 = call i64 asm "", "=r,0"(i64 %r4186.rs4i) #7
  %statepoint_token1106 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r4186, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1103, ptr addrspace(1) %rs4gc.s9.relocated1104, ptr addrspace(1) %r8.0.relocated1105) ]
  %rs4gc.s13.relocated1107 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1106, i32 0, i32 0) ; (%rs4gc.s13.relocated1103, %rs4gc.s13.relocated1103)
  %rs4gc.s9.relocated1108 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1106, i32 1, i32 1) ; (%rs4gc.s9.relocated1104, %rs4gc.s9.relocated1104)
  %r8.0.relocated1109 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1106, i32 2, i32 2) ; (%r8.0.relocated1105, %r8.0.relocated1105)
  %r4188 = load double, ptr @test_json_large_string_emitters_ts_.str.0.handle, align 8
  %rs4gc.b84 = bitcast double %r4188 to i64
  %rs4gc.s84 = inttoptr i64 %rs4gc.b84 to ptr addrspace(1)
  %r4189.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s84 to i64
  %r4189 = call i64 asm "", "=r,0"(i64 %r4189.rs4i) #7
  %r4190 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4191 = icmp ne i32 %r4190, 0
  br i1 %r4191, label %shadow.root.barrier.647, label %shadow.root.barrier.done.648

shadow.root.barrier.647:                          ; preds = %shadow.root.barrier.done.646
  call void @js_write_barrier_root_nanbox(i64 %r4189) #7
  br label %shadow.root.barrier.done.648

shadow.root.barrier.done.648:                     ; preds = %shadow.root.barrier.647, %shadow.root.barrier.done.646
  br label %for.cond.649

for.cond.649:                                     ; preds = %for.update.651, %shadow.root.barrier.done.648
  %.511416 = phi ptr addrspace(1) [ %rs4gc.s13.relocated1107, %shadow.root.barrier.done.648 ], [ %.531418, %for.update.651 ]
  %.481358 = phi ptr addrspace(1) [ %r8.0.relocated1109, %shadow.root.barrier.done.648 ], [ %.501360, %for.update.651 ]
  %.51 = phi ptr addrspace(1) [ %rs4gc.s9.relocated1108, %shadow.root.barrier.done.648 ], [ %.53, %for.update.651 ]
  %r4187.0 = phi ptr addrspace(1) [ %rs4gc.s84, %shadow.root.barrier.done.648 ], [ %.01525, %for.update.651 ]
  %r4192.0 = phi i32 [ 0, %shadow.root.barrier.done.648 ], [ %r4239, %for.update.651 ]
  %r4194 = sitofp i32 %r4192.0 to double
  %r4195 = fcmp olt double %r4194, 2.570000e+02
  %r4196 = select i1 %r4195, i64 9222246136947933188, i64 9222246136947933187
  %r4197 = bitcast i64 %r4196 to double
  %r4198 = icmp eq i64 %r4196, 9222246136947933188
  br i1 %r4198, label %for.body.650, label %for.exit.652

for.body.650:                                     ; preds = %for.cond.649
  %r4199.rs4i = ptrtoint ptr addrspace(1) %r4187.0 to i64
  %r4199.rs4o = call i64 asm "", "=r,0"(i64 %r4199.rs4i) #7
  %r4199 = bitcast i64 %r4199.rs4o to double
  %r4201 = sitofp i32 %r4192.0 to double
  %r4202 = fptosi double %r4201 to i64
  %r4204 = srem i64 %r4202, 3
  %r4205 = sitofp i64 %r4204 to double
  %r4206 = icmp eq i64 %r4204, 0
  %r4207 = fcmp olt double %r4201, 0.000000e+00
  %r4208 = and i1 %r4206, %r4207
  %r4209 = fneg double %r4205
  %r4210 = select i1 %r4208, double %r4209, double %r4205
  %r4211 = fcmp oeq double %r4210, 0.000000e+00
  %r4212 = select i1 %r4211, i64 9222246136947933188, i64 9222246136947933187
  %r4213 = bitcast i64 %r4212 to double
  %r4214 = icmp eq i64 %r4212, 9222246136947933188
  br i1 %r4214, label %ternary.then.653, label %ternary.else.654

for.update.651:                                   ; preds = %gcpoll.done.663
  %r4239 = add i32 %r4192.0, 1
  %r4240 = sitofp i32 %r4192.0 to double
  %r4241 = sitofp i32 %r4239 to double
  br label %for.cond.649

for.exit.652:                                     ; preds = %for.cond.649
  %statepoint_token1110 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.511416, ptr addrspace(1) %.51, ptr addrspace(1) %.481358, ptr addrspace(1) %r4187.0) ]
  %r42421111 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1110)
  %rs4gc.s13.relocated1112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1110, i32 0, i32 0) ; (%.511416, %.511416)
  %rs4gc.s9.relocated1113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1110, i32 1, i32 1) ; (%.51, %.51)
  %r8.0.relocated1114 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1110, i32 2, i32 2) ; (%.481358, %.481358)
  %r4187.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1110, i32 3, i32 3) ; (%r4187.0, %r4187.0)
  %rs4gc.s85 = inttoptr i64 %r42421111 to ptr addrspace(1)
  %r4243.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s85 to i64
  %r4243 = call i64 asm "", "=r,0"(i64 %r4243.rs4i) #7
  %r4244 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4245 = icmp ne i32 %r4244, 0
  br i1 %r4245, label %shadow.root.barrier.664, label %shadow.root.barrier.done.665

ternary.then.653:                                 ; preds = %for.body.650
  %r4215 = load double, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  br label %ternary.merge.655

ternary.else.654:                                 ; preds = %for.body.650
  %r4216 = load double, ptr @test_json_large_string_emitters_ts_.str.11.handle, align 8
  br label %ternary.merge.655

ternary.merge.655:                                ; preds = %ternary.else.654, %ternary.then.653
  %r4217 = phi double [ %r4215, %ternary.then.653 ], [ %r4216, %ternary.else.654 ]
  %r4218 = bitcast double %r4199 to i64
  %r4219 = lshr i64 %r4218, 48
  %r4220 = icmp eq i64 %r4219, 32767
  br i1 %r4220, label %strapp.dheap.656, label %strapp.dynamic.658

strapp.dheap.656:                                 ; preds = %ternary.merge.655
  %r4221 = bitcast double %r4217 to i64
  %r4222 = lshr i64 %r4221, 48
  %r4223 = icmp eq i64 %r4222, 32765
  br i1 %r4223, label %strapp.dynamic.658, label %strapp.append.657

strapp.append.657:                                ; preds = %strapp.dheap.656
  %statepoint_token1115 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_jsvalue_to_string, i32 1, i32 0, double %r4217, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.511416, ptr addrspace(1) %.51, ptr addrspace(1) %.481358, ptr addrspace(1) %r4187.0) ]
  %r42241116 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1115)
  %rs4gc.s13.relocated1117 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1115, i32 0, i32 0) ; (%.511416, %.511416)
  %rs4gc.s9.relocated1118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1115, i32 1, i32 1) ; (%.51, %.51)
  %r8.0.relocated1119 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1115, i32 2, i32 2) ; (%.481358, %.481358)
  %r4187.0.relocated1120 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1115, i32 3, i32 3) ; (%r4187.0, %r4187.0)
  %r4225.rs4i = ptrtoint ptr addrspace(1) %r4187.0.relocated1120 to i64
  %r4225.rs4o = call i64 asm "", "=r,0"(i64 %r4225.rs4i) #7
  %r4225 = bitcast i64 %r4225.rs4o to double
  %r4226 = bitcast double %r4225 to i64
  %r4227 = and i64 %r4226, 281474976710655
  %statepoint_token1121 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_string_append_known_heap, i32 2, i32 0, i64 %r4227, i64 %r42241116, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1117, ptr addrspace(1) %rs4gc.s9.relocated1118, ptr addrspace(1) %r8.0.relocated1119) ]
  %r42281122 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1121)
  %rs4gc.s13.relocated1123 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1121, i32 0, i32 0) ; (%rs4gc.s13.relocated1117, %rs4gc.s13.relocated1117)
  %rs4gc.s9.relocated1124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1121, i32 1, i32 1) ; (%rs4gc.s9.relocated1118, %rs4gc.s9.relocated1118)
  %r8.0.relocated1125 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1121, i32 2, i32 2) ; (%r8.0.relocated1119, %r8.0.relocated1119)
  %r4229 = or i64 %r42281122, 9223090561878065152
  %r4230 = bitcast i64 %r4229 to double
  br label %strapp.merge.659

strapp.dynamic.658:                               ; preds = %strapp.dheap.656, %ternary.merge.655
  %statepoint_token1126 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r4199, double %r4217, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.511416, ptr addrspace(1) %.51, ptr addrspace(1) %.481358) ]
  %r42311127 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1126)
  %rs4gc.s13.relocated1128 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1126, i32 0, i32 0) ; (%.511416, %.511416)
  %rs4gc.s9.relocated1129 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1126, i32 1, i32 1) ; (%.51, %.51)
  %r8.0.relocated1130 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1126, i32 2, i32 2) ; (%.481358, %.481358)
  br label %strapp.merge.659

strapp.merge.659:                                 ; preds = %strapp.dynamic.658, %strapp.append.657
  %.521417 = phi ptr addrspace(1) [ %rs4gc.s13.relocated1128, %strapp.dynamic.658 ], [ %rs4gc.s13.relocated1123, %strapp.append.657 ]
  %.491359 = phi ptr addrspace(1) [ %r8.0.relocated1130, %strapp.dynamic.658 ], [ %r8.0.relocated1125, %strapp.append.657 ]
  %.52 = phi ptr addrspace(1) [ %rs4gc.s9.relocated1129, %strapp.dynamic.658 ], [ %rs4gc.s9.relocated1124, %strapp.append.657 ]
  %r4232 = phi double [ %r4230, %strapp.append.657 ], [ %r42311127, %strapp.dynamic.658 ]
  %rs4gc.b86 = bitcast double %r4232 to i64
  %rs4gc.s86 = inttoptr i64 %rs4gc.b86 to ptr addrspace(1)
  %r4233.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s86 to i64
  %r4233 = call i64 asm "", "=r,0"(i64 %r4233.rs4i) #7
  %r4234 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4235 = icmp ne i32 %r4234, 0
  br i1 %r4235, label %shadow.root.barrier.660, label %shadow.root.barrier.done.661

shadow.root.barrier.660:                          ; preds = %strapp.merge.659
  call void @js_write_barrier_root_nanbox(i64 %r4233) #7
  br label %shadow.root.barrier.done.661

shadow.root.barrier.done.661:                     ; preds = %shadow.root.barrier.660, %strapp.merge.659
  %r4236 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r4237 = icmp ne i32 %r4236, 0
  br i1 %r4237, label %gcpoll.662, label %gcpoll.done.663

gcpoll.662:                                       ; preds = %shadow.root.barrier.done.661
  %statepoint_token1131 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s86, ptr addrspace(1) %.521417, ptr addrspace(1) %.52, ptr addrspace(1) %.491359) ]
  %rs4gc.s86.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1131, i32 0, i32 0) ; (%rs4gc.s86, %rs4gc.s86)
  %rs4gc.s13.relocated1132 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1131, i32 1, i32 1) ; (%.521417, %.521417)
  %rs4gc.s9.relocated1133 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1131, i32 2, i32 2) ; (%.52, %.52)
  %r8.0.relocated1134 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1131, i32 3, i32 3) ; (%.491359, %.491359)
  br label %gcpoll.done.663

gcpoll.done.663:                                  ; preds = %gcpoll.662, %shadow.root.barrier.done.661
  %.01525 = phi ptr addrspace(1) [ %rs4gc.s86.relocated, %gcpoll.662 ], [ %rs4gc.s86, %shadow.root.barrier.done.661 ]
  %.531418 = phi ptr addrspace(1) [ %rs4gc.s13.relocated1132, %gcpoll.662 ], [ %.521417, %shadow.root.barrier.done.661 ]
  %.501360 = phi ptr addrspace(1) [ %r8.0.relocated1134, %gcpoll.662 ], [ %.491359, %shadow.root.barrier.done.661 ]
  %.53 = phi ptr addrspace(1) [ %rs4gc.s9.relocated1133, %gcpoll.662 ], [ %.52, %shadow.root.barrier.done.661 ]
  br label %for.update.651

shadow.root.barrier.664:                          ; preds = %for.exit.652
  call void @js_write_barrier_root_nanbox(i64 %r4243) #7
  br label %shadow.root.barrier.done.665

shadow.root.barrier.done.665:                     ; preds = %shadow.root.barrier.664, %for.exit.652
  %r4246 = load double, ptr @test_json_large_string_emitters_ts_.str.12.handle, align 8
  %r4247.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s85 to i64
  %r4247 = call i64 asm "", "=r,0"(i64 %r4247.rs4i) #7
  %statepoint_token1135 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4247, double %r4246, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1112, ptr addrspace(1) %rs4gc.s9.relocated1113, ptr addrspace(1) %r8.0.relocated1114, ptr addrspace(1) %r4187.0.relocated) ]
  %r42481136 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1135)
  %rs4gc.s13.relocated1137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1135, i32 0, i32 0) ; (%rs4gc.s13.relocated1112, %rs4gc.s13.relocated1112)
  %rs4gc.s9.relocated1138 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1135, i32 1, i32 1) ; (%rs4gc.s9.relocated1113, %rs4gc.s9.relocated1113)
  %r8.0.relocated1139 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1135, i32 2, i32 2) ; (%r8.0.relocated1114, %r8.0.relocated1114)
  %r4187.0.relocated1140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1135, i32 3, i32 3) ; (%r4187.0.relocated, %r4187.0.relocated)
  %rs4gc.s87 = inttoptr i64 %r42481136 to ptr addrspace(1)
  %r4249.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s87 to i64
  %r4249 = call i64 asm "", "=r,0"(i64 %r4249.rs4i) #7
  %r4250 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4251 = icmp ne i32 %r4250, 0
  br i1 %r4251, label %shadow.root.barrier.666, label %shadow.root.barrier.done.667

shadow.root.barrier.666:                          ; preds = %shadow.root.barrier.done.665
  call void @js_write_barrier_root_nanbox(i64 %r4249) #7
  br label %shadow.root.barrier.done.667

shadow.root.barrier.done.667:                     ; preds = %shadow.root.barrier.666, %shadow.root.barrier.done.665
  %r4252.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s87 to i64
  %r4252 = call i64 asm "", "=r,0"(i64 %r4252.rs4i) #7
  %statepoint_token1141 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4252, double 2.570000e+02, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1137, ptr addrspace(1) %rs4gc.s9.relocated1138, ptr addrspace(1) %r8.0.relocated1139, ptr addrspace(1) %r4187.0.relocated1140) ]
  %r42531142 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1141)
  %rs4gc.s13.relocated1143 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1141, i32 0, i32 0) ; (%rs4gc.s13.relocated1137, %rs4gc.s13.relocated1137)
  %rs4gc.s9.relocated1144 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1141, i32 1, i32 1) ; (%rs4gc.s9.relocated1138, %rs4gc.s9.relocated1138)
  %r8.0.relocated1145 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1141, i32 2, i32 2) ; (%r8.0.relocated1139, %r8.0.relocated1139)
  %r4187.0.relocated1146 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1141, i32 3, i32 3) ; (%r4187.0.relocated1140, %r4187.0.relocated1140)
  %rs4gc.s88 = inttoptr i64 %r42531142 to ptr addrspace(1)
  %r4254.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s88 to i64
  %r4254 = call i64 asm "", "=r,0"(i64 %r4254.rs4i) #7
  %r4255 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4256 = icmp ne i32 %r4255, 0
  br i1 %r4256, label %shadow.root.barrier.668, label %shadow.root.barrier.done.669

shadow.root.barrier.668:                          ; preds = %shadow.root.barrier.done.667
  call void @js_write_barrier_root_nanbox(i64 %r4254) #7
  br label %shadow.root.barrier.done.669

shadow.root.barrier.done.669:                     ; preds = %shadow.root.barrier.668, %shadow.root.barrier.done.667
  %r4257.rs4i = ptrtoint ptr addrspace(1) %r4187.0.relocated1146 to i64
  %r4257.rs4o = call i64 asm "", "=r,0"(i64 %r4257.rs4i) #7
  %r4257 = bitcast i64 %r4257.rs4o to double
  %r4258 = bitcast double %r4257 to i64
  %rs4gc.s89 = inttoptr i64 %r4258 to ptr addrspace(1)
  %r4259.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s89 to i64
  %r4259 = call i64 asm "", "=r,0"(i64 %r4259.rs4i) #7
  %r4260 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4261 = icmp ne i32 %r4260, 0
  br i1 %r4261, label %shadow.root.barrier.670, label %shadow.root.barrier.done.671

shadow.root.barrier.670:                          ; preds = %shadow.root.barrier.done.669
  call void @js_write_barrier_root_nanbox(i64 %r4259) #7
  br label %shadow.root.barrier.done.671

shadow.root.barrier.done.671:                     ; preds = %shadow.root.barrier.670, %shadow.root.barrier.done.669
  %r4262.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9.relocated1144 to i64
  %r4262 = call i64 asm "", "=r,0"(i64 %r4262.rs4i) #7
  %statepoint_token1147 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 3, i32 0, i32 1, i64 %r4262, i32 %r3833, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1143, ptr addrspace(1) %rs4gc.s9.relocated1144, ptr addrspace(1) %r8.0.relocated1145, ptr addrspace(1) %r4187.0.relocated1146, ptr addrspace(1) %rs4gc.s88, ptr addrspace(1) %rs4gc.s89) ]
  %r42641148 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1147)
  %rs4gc.s13.relocated1149 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1147, i32 0, i32 0) ; (%rs4gc.s13.relocated1143, %rs4gc.s13.relocated1143)
  %rs4gc.s9.relocated1150 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1147, i32 1, i32 1) ; (%rs4gc.s9.relocated1144, %rs4gc.s9.relocated1144)
  %r8.0.relocated1151 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1147, i32 2, i32 2) ; (%r8.0.relocated1145, %r8.0.relocated1145)
  %r4187.0.relocated1152 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1147, i32 3, i32 3) ; (%r4187.0.relocated1146, %r4187.0.relocated1146)
  %rs4gc.s88.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1147, i32 4, i32 4) ; (%rs4gc.s88, %rs4gc.s88)
  %rs4gc.s89.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1147, i32 5, i32 5) ; (%rs4gc.s89, %rs4gc.s89)
  call void @js_gc_declare_typed_shape_layout(i64 %r42641148, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, i32 1) #7
  %rs4gc.s90 = inttoptr i64 %r42641148 to ptr addrspace(1)
  %r4265.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s90 to i64
  %r4265 = call i64 asm "", "=r,0"(i64 %r4265.rs4i) #7
  %r4266 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4267 = icmp ne i32 %r4266, 0
  br i1 %r4267, label %shadow.root.barrier.672, label %shadow.root.barrier.done.673

shadow.root.barrier.672:                          ; preds = %shadow.root.barrier.done.671
  call void @js_write_barrier_root_nanbox(i64 %r4265) #7
  br label %shadow.root.barrier.done.673

shadow.root.barrier.done.673:                     ; preds = %shadow.root.barrier.672, %shadow.root.barrier.done.671
  %r4268 = or i64 %r42641148, 9222527611924643840
  %r4269 = bitcast i64 %r4268 to double
  %r4270.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s89.relocated to i64
  %r4270 = call i64 asm "", "=r,0"(i64 %r4270.rs4i) #7
  %r4271 = bitcast i64 %r4270 to double
  %r4272 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r4273 = icmp eq i8 %r4272, 0
  %r4274 = inttoptr i64 %r42641148 to ptr
  %r4275 = getelementptr i8, ptr %r4274, i64 -6
  %r4276 = load i16, ptr %r4275, align 2
  %r4277 = and i16 %r4276, 4096
  %r4278 = icmp ne i16 %r4277, 0
  %r4279 = and i1 %r4273, %r4278
  br i1 %r4279, label %ctor_prologue.fast.674, label %ctor_prologue.slow.675

ctor_prologue.fast.674:                           ; preds = %shadow.root.barrier.done.673
  %r4280 = inttoptr i64 %r42641148 to ptr
  %r4281 = getelementptr i8, ptr %r4280, i64 16
  %r4282 = bitcast double %r4269 to i64
  %r4283 = getelementptr double, ptr %r4281, i64 0
  store double %r4271, ptr %r4283, align 8
  %r4284 = ptrtoint ptr %r4283 to i64
  %r4285 = bitcast double %r4271 to i64
  %r4286 = lshr i64 %r4285, 48
  %r4287 = icmp eq i64 %r4286, 0
  %r4288 = icmp uge i64 %r4285, 4096
  %r4289 = and i1 %r4287, %r4288
  %r4290 = icmp eq i64 %r4286, 32765
  %r4291 = icmp eq i64 %r4286, 32767
  %r4292 = icmp eq i64 %r4286, 32762
  %r4293 = or i1 %r4290, %r4291
  %r4294 = or i1 %r4293, %r4292
  %r4295 = or i1 %r4294, %r4289
  br i1 %r4295, label %ctor_prologue.barrier.maybe.677, label %ctor_prologue.barrier.done.679

ctor_prologue.slow.675:                           ; preds = %shadow.root.barrier.done.673
  %statepoint_token1153 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3_constructor, i32 2, i32 0, double %r4269, double %r4271, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1149, ptr addrspace(1) %rs4gc.s9.relocated1150, ptr addrspace(1) %r8.0.relocated1151, ptr addrspace(1) %r4187.0.relocated1152, ptr addrspace(1) %rs4gc.s88.relocated, ptr addrspace(1) %rs4gc.s90) ]
  %r43041154 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1153)
  %rs4gc.s13.relocated1155 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1153, i32 0, i32 0) ; (%rs4gc.s13.relocated1149, %rs4gc.s13.relocated1149)
  %rs4gc.s9.relocated1156 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1153, i32 1, i32 1) ; (%rs4gc.s9.relocated1150, %rs4gc.s9.relocated1150)
  %r8.0.relocated1157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1153, i32 2, i32 2) ; (%r8.0.relocated1151, %r8.0.relocated1151)
  %r4187.0.relocated1158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1153, i32 3, i32 3) ; (%r4187.0.relocated1152, %r4187.0.relocated1152)
  %rs4gc.s88.relocated1159 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1153, i32 4, i32 4) ; (%rs4gc.s88.relocated, %rs4gc.s88.relocated)
  %rs4gc.s90.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1153, i32 5, i32 5) ; (%rs4gc.s90, %rs4gc.s90)
  br label %ctor_prologue.merge.676

ctor_prologue.merge.676:                          ; preds = %ctor_prologue.barrier.done.679, %ctor_prologue.slow.675
  %.01528 = phi ptr addrspace(1) [ %rs4gc.s90, %ctor_prologue.barrier.done.679 ], [ %rs4gc.s90.relocated, %ctor_prologue.slow.675 ]
  %.01526 = phi ptr addrspace(1) [ %rs4gc.s88.relocated, %ctor_prologue.barrier.done.679 ], [ %rs4gc.s88.relocated1159, %ctor_prologue.slow.675 ]
  %.01523 = phi ptr addrspace(1) [ %r4187.0.relocated1152, %ctor_prologue.barrier.done.679 ], [ %r4187.0.relocated1158, %ctor_prologue.slow.675 ]
  %.541419 = phi ptr addrspace(1) [ %rs4gc.s13.relocated1149, %ctor_prologue.barrier.done.679 ], [ %rs4gc.s13.relocated1155, %ctor_prologue.slow.675 ]
  %.511361 = phi ptr addrspace(1) [ %r8.0.relocated1151, %ctor_prologue.barrier.done.679 ], [ %r8.0.relocated1157, %ctor_prologue.slow.675 ]
  %.54 = phi ptr addrspace(1) [ %rs4gc.s9.relocated1150, %ctor_prologue.barrier.done.679 ], [ %rs4gc.s9.relocated1156, %ctor_prologue.slow.675 ]
  %r4305 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.679 ], [ %r43041154, %ctor_prologue.slow.675 ]
  %r4306.rs4i = ptrtoint ptr addrspace(1) %.01528 to i64
  %r4306 = call i64 asm "", "=r,0"(i64 %r4306.rs4i) #7
  %r4307 = or i64 %r4306, 9222527611924643840
  %r4308 = bitcast i64 %r4307 to double
  %r4309 = bitcast double %r4305 to i64
  %r4310 = icmp eq i64 %r4309, 9222246136947933185
  br i1 %r4310, label %ctor_ret.merge.681, label %ctor_ret.override.680

ctor_prologue.barrier.maybe.677:                  ; preds = %ctor_prologue.fast.674
  %r4296 = sub i64 %r42641148, 7
  %r4297 = inttoptr i64 %r4296 to ptr
  %r4298 = load i8, ptr %r4297, align 1
  %r4299 = and i8 %r4298, 32
  %r4300 = icmp ne i8 %r4299, 0
  %r4301 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4302 = icmp ne i32 %r4301, 0
  %r4303 = or i1 %r4300, %r4302
  br i1 %r4303, label %ctor_prologue.barrier.678, label %ctor_prologue.barrier.done.679

ctor_prologue.barrier.678:                        ; preds = %ctor_prologue.barrier.maybe.677
  call void @js_write_barrier_slot_validated_parent(i64 %r42641148, i64 %r4284, i64 %r4285) #7
  br label %ctor_prologue.barrier.done.679

ctor_prologue.barrier.done.679:                   ; preds = %ctor_prologue.barrier.678, %ctor_prologue.barrier.maybe.677, %ctor_prologue.fast.674
  br label %ctor_prologue.merge.676

ctor_ret.override.680:                            ; preds = %ctor_prologue.merge.676
  %statepoint_token1160 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r4308, double %r4305, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.541419, ptr addrspace(1) %.54, ptr addrspace(1) %.511361, ptr addrspace(1) %.01523, ptr addrspace(1) %.01526) ]
  %r43111161 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1160)
  %rs4gc.s13.relocated1162 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1160, i32 0, i32 0) ; (%.541419, %.541419)
  %rs4gc.s9.relocated1163 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1160, i32 1, i32 1) ; (%.54, %.54)
  %r8.0.relocated1164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1160, i32 2, i32 2) ; (%.511361, %.511361)
  %r4187.0.relocated1165 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1160, i32 3, i32 3) ; (%.01523, %.01523)
  %rs4gc.s88.relocated1166 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1160, i32 4, i32 4) ; (%.01526, %.01526)
  br label %ctor_ret.merge.681

ctor_ret.merge.681:                               ; preds = %ctor_ret.override.680, %ctor_prologue.merge.676
  %.11527 = phi ptr addrspace(1) [ %.01526, %ctor_prologue.merge.676 ], [ %rs4gc.s88.relocated1166, %ctor_ret.override.680 ]
  %.11524 = phi ptr addrspace(1) [ %.01523, %ctor_prologue.merge.676 ], [ %r4187.0.relocated1165, %ctor_ret.override.680 ]
  %.551420 = phi ptr addrspace(1) [ %.541419, %ctor_prologue.merge.676 ], [ %rs4gc.s13.relocated1162, %ctor_ret.override.680 ]
  %.521362 = phi ptr addrspace(1) [ %.511361, %ctor_prologue.merge.676 ], [ %r8.0.relocated1164, %ctor_ret.override.680 ]
  %.55 = phi ptr addrspace(1) [ %.54, %ctor_prologue.merge.676 ], [ %rs4gc.s9.relocated1163, %ctor_ret.override.680 ]
  %r4312 = phi double [ %r4308, %ctor_prologue.merge.676 ], [ %r43111161, %ctor_ret.override.680 ]
  %statepoint_token1167 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4312, double 0x7FFC000000000002, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.551420, ptr addrspace(1) %.55, ptr addrspace(1) %.521362, ptr addrspace(1) %.11524, ptr addrspace(1) %.11527) ]
  %r43131168 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1167)
  %rs4gc.s13.relocated1169 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1167, i32 0, i32 0) ; (%.551420, %.551420)
  %rs4gc.s9.relocated1170 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1167, i32 1, i32 1) ; (%.55, %.55)
  %r8.0.relocated1171 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1167, i32 2, i32 2) ; (%.521362, %.521362)
  %r4187.0.relocated1172 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1167, i32 3, i32 3) ; (%.11524, %.11524)
  %rs4gc.s88.relocated1173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1167, i32 4, i32 4) ; (%.11527, %.11527)
  %r4314 = bitcast i64 %r43131168 to double
  %r4315.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s88.relocated1173 to i64
  %r4315 = call i64 asm "", "=r,0"(i64 %r4315.rs4i) #7
  %statepoint_token1174 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4315, double %r4314, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1169, ptr addrspace(1) %rs4gc.s9.relocated1170, ptr addrspace(1) %r8.0.relocated1171, ptr addrspace(1) %r4187.0.relocated1172) ]
  %r43161175 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1174)
  %rs4gc.s13.relocated1176 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1174, i32 0, i32 0) ; (%rs4gc.s13.relocated1169, %rs4gc.s13.relocated1169)
  %rs4gc.s9.relocated1177 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1174, i32 1, i32 1) ; (%rs4gc.s9.relocated1170, %rs4gc.s9.relocated1170)
  %r8.0.relocated1178 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1174, i32 2, i32 2) ; (%r8.0.relocated1171, %r8.0.relocated1171)
  %r4187.0.relocated1179 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1174, i32 3, i32 3) ; (%r4187.0.relocated1172, %r4187.0.relocated1172)
  %rs4gc.s91 = inttoptr i64 %r43161175 to ptr addrspace(1)
  %r4317.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s91 to i64
  %r4317 = call i64 asm "", "=r,0"(i64 %r4317.rs4i) #7
  %r4318 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4319 = icmp ne i32 %r4318, 0
  br i1 %r4319, label %shadow.root.barrier.682, label %shadow.root.barrier.done.683

shadow.root.barrier.682:                          ; preds = %ctor_ret.merge.681
  call void @js_write_barrier_root_nanbox(i64 %r4317) #7
  br label %shadow.root.barrier.done.683

shadow.root.barrier.done.683:                     ; preds = %shadow.root.barrier.682, %ctor_ret.merge.681
  %r4320.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s91 to i64
  %r4320 = call i64 asm "", "=r,0"(i64 %r4320.rs4i) #7
  %statepoint_token1180 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r4320, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1176, ptr addrspace(1) %rs4gc.s9.relocated1177, ptr addrspace(1) %r8.0.relocated1178, ptr addrspace(1) %r4187.0.relocated1179) ]
  %rs4gc.s13.relocated1181 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1180, i32 0, i32 0) ; (%rs4gc.s13.relocated1176, %rs4gc.s13.relocated1176)
  %rs4gc.s9.relocated1182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1180, i32 1, i32 1) ; (%rs4gc.s9.relocated1177, %rs4gc.s9.relocated1177)
  %r8.0.relocated1183 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1180, i32 2, i32 2) ; (%r8.0.relocated1178, %r8.0.relocated1178)
  %r4187.0.relocated1184 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1180, i32 3, i32 3) ; (%r4187.0.relocated1179, %r4187.0.relocated1179)
  %statepoint_token1185 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1181, ptr addrspace(1) %rs4gc.s9.relocated1182, ptr addrspace(1) %r8.0.relocated1183, ptr addrspace(1) %r4187.0.relocated1184) ]
  %r43211186 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1185)
  %rs4gc.s13.relocated1187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1185, i32 0, i32 0) ; (%rs4gc.s13.relocated1181, %rs4gc.s13.relocated1181)
  %rs4gc.s9.relocated1188 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1185, i32 1, i32 1) ; (%rs4gc.s9.relocated1182, %rs4gc.s9.relocated1182)
  %r8.0.relocated1189 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1185, i32 2, i32 2) ; (%r8.0.relocated1183, %r8.0.relocated1183)
  %r4187.0.relocated1190 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1185, i32 3, i32 3) ; (%r4187.0.relocated1184, %r4187.0.relocated1184)
  %rs4gc.s92 = inttoptr i64 %r43211186 to ptr addrspace(1)
  %r4322.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s92 to i64
  %r4322 = call i64 asm "", "=r,0"(i64 %r4322.rs4i) #7
  %r4323 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4324 = icmp ne i32 %r4323, 0
  br i1 %r4324, label %shadow.root.barrier.684, label %shadow.root.barrier.done.685

shadow.root.barrier.684:                          ; preds = %shadow.root.barrier.done.683
  call void @js_write_barrier_root_nanbox(i64 %r4322) #7
  br label %shadow.root.barrier.done.685

shadow.root.barrier.done.685:                     ; preds = %shadow.root.barrier.684, %shadow.root.barrier.done.683
  %r4325 = load double, ptr @test_json_large_string_emitters_ts_.str.13.handle, align 8
  %r4326.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s92 to i64
  %r4326 = call i64 asm "", "=r,0"(i64 %r4326.rs4i) #7
  %statepoint_token1191 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4326, double %r4325, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1187, ptr addrspace(1) %rs4gc.s9.relocated1188, ptr addrspace(1) %r8.0.relocated1189, ptr addrspace(1) %r4187.0.relocated1190) ]
  %r43271192 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1191)
  %rs4gc.s13.relocated1193 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1191, i32 0, i32 0) ; (%rs4gc.s13.relocated1187, %rs4gc.s13.relocated1187)
  %rs4gc.s9.relocated1194 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1191, i32 1, i32 1) ; (%rs4gc.s9.relocated1188, %rs4gc.s9.relocated1188)
  %r8.0.relocated1195 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1191, i32 2, i32 2) ; (%r8.0.relocated1189, %r8.0.relocated1189)
  %r4187.0.relocated1196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1191, i32 3, i32 3) ; (%r4187.0.relocated1190, %r4187.0.relocated1190)
  %rs4gc.s93 = inttoptr i64 %r43271192 to ptr addrspace(1)
  %r4328.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s93 to i64
  %r4328 = call i64 asm "", "=r,0"(i64 %r4328.rs4i) #7
  %r4329 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4330 = icmp ne i32 %r4329, 0
  br i1 %r4330, label %shadow.root.barrier.686, label %shadow.root.barrier.done.687

shadow.root.barrier.686:                          ; preds = %shadow.root.barrier.done.685
  call void @js_write_barrier_root_nanbox(i64 %r4328) #7
  br label %shadow.root.barrier.done.687

shadow.root.barrier.done.687:                     ; preds = %shadow.root.barrier.686, %shadow.root.barrier.done.685
  %r4331.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s93 to i64
  %r4331 = call i64 asm "", "=r,0"(i64 %r4331.rs4i) #7
  %statepoint_token1197 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4331, double 2.570000e+02, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1193, ptr addrspace(1) %rs4gc.s9.relocated1194, ptr addrspace(1) %r8.0.relocated1195, ptr addrspace(1) %r4187.0.relocated1196) ]
  %r43321198 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1197)
  %rs4gc.s13.relocated1199 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1197, i32 0, i32 0) ; (%rs4gc.s13.relocated1193, %rs4gc.s13.relocated1193)
  %rs4gc.s9.relocated1200 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1197, i32 1, i32 1) ; (%rs4gc.s9.relocated1194, %rs4gc.s9.relocated1194)
  %r8.0.relocated1201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1197, i32 2, i32 2) ; (%r8.0.relocated1195, %r8.0.relocated1195)
  %r4187.0.relocated1202 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1197, i32 3, i32 3) ; (%r4187.0.relocated1196, %r4187.0.relocated1196)
  %rs4gc.s94 = inttoptr i64 %r43321198 to ptr addrspace(1)
  %r4333.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s94 to i64
  %r4333 = call i64 asm "", "=r,0"(i64 %r4333.rs4i) #7
  %r4334 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4335 = icmp ne i32 %r4334, 0
  br i1 %r4335, label %shadow.root.barrier.688, label %shadow.root.barrier.done.689

shadow.root.barrier.688:                          ; preds = %shadow.root.barrier.done.687
  call void @js_write_barrier_root_nanbox(i64 %r4333) #7
  br label %shadow.root.barrier.done.689

shadow.root.barrier.done.689:                     ; preds = %shadow.root.barrier.688, %shadow.root.barrier.done.687
  %r4336.rs4i = ptrtoint ptr addrspace(1) %r4187.0.relocated1202 to i64
  %r4336.rs4o = call i64 asm "", "=r,0"(i64 %r4336.rs4i) #7
  %r4336 = bitcast i64 %r4336.rs4o to double
  %r4337 = bitcast double %r4336 to i64
  %rs4gc.s95 = inttoptr i64 %r4337 to ptr addrspace(1)
  %r4338.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s95 to i64
  %r4338 = call i64 asm "", "=r,0"(i64 %r4338.rs4i) #7
  %r4339 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4340 = icmp ne i32 %r4339, 0
  br i1 %r4340, label %shadow.root.barrier.690, label %shadow.root.barrier.done.691

shadow.root.barrier.690:                          ; preds = %shadow.root.barrier.done.689
  call void @js_write_barrier_root_nanbox(i64 %r4338) #7
  br label %shadow.root.barrier.done.691

shadow.root.barrier.done.691:                     ; preds = %shadow.root.barrier.690, %shadow.root.barrier.done.689
  %r4341.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9.relocated1200 to i64
  %r4341 = call i64 asm "", "=r,0"(i64 %r4341.rs4i) #7
  %statepoint_token1203 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 3, i32 0, i32 1, i64 %r4341, i32 %r3833, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1199, ptr addrspace(1) %rs4gc.s9.relocated1200, ptr addrspace(1) %r8.0.relocated1201, ptr addrspace(1) %rs4gc.s94, ptr addrspace(1) %rs4gc.s95) ]
  %r43431204 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1203)
  %rs4gc.s13.relocated1205 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1203, i32 0, i32 0) ; (%rs4gc.s13.relocated1199, %rs4gc.s13.relocated1199)
  %rs4gc.s9.relocated1206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1203, i32 1, i32 1) ; (%rs4gc.s9.relocated1200, %rs4gc.s9.relocated1200)
  %r8.0.relocated1207 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1203, i32 2, i32 2) ; (%r8.0.relocated1201, %r8.0.relocated1201)
  %rs4gc.s94.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1203, i32 3, i32 3) ; (%rs4gc.s94, %rs4gc.s94)
  %rs4gc.s95.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1203, i32 4, i32 4) ; (%rs4gc.s95, %rs4gc.s95)
  call void @js_gc_declare_typed_shape_layout(i64 %r43431204, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, i32 1) #7
  %rs4gc.s96 = inttoptr i64 %r43431204 to ptr addrspace(1)
  %r4344.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s96 to i64
  %r4344 = call i64 asm "", "=r,0"(i64 %r4344.rs4i) #7
  %r4345 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4346 = icmp ne i32 %r4345, 0
  br i1 %r4346, label %shadow.root.barrier.692, label %shadow.root.barrier.done.693

shadow.root.barrier.692:                          ; preds = %shadow.root.barrier.done.691
  call void @js_write_barrier_root_nanbox(i64 %r4344) #7
  br label %shadow.root.barrier.done.693

shadow.root.barrier.done.693:                     ; preds = %shadow.root.barrier.692, %shadow.root.barrier.done.691
  %r4347 = or i64 %r43431204, 9222527611924643840
  %r4348 = bitcast i64 %r4347 to double
  %r4349.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s95.relocated to i64
  %r4349 = call i64 asm "", "=r,0"(i64 %r4349.rs4i) #7
  %r4350 = bitcast i64 %r4349 to double
  %r4351 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r4352 = icmp eq i8 %r4351, 0
  %r4353 = inttoptr i64 %r43431204 to ptr
  %r4354 = getelementptr i8, ptr %r4353, i64 -6
  %r4355 = load i16, ptr %r4354, align 2
  %r4356 = and i16 %r4355, 4096
  %r4357 = icmp ne i16 %r4356, 0
  %r4358 = and i1 %r4352, %r4357
  br i1 %r4358, label %ctor_prologue.fast.694, label %ctor_prologue.slow.695

ctor_prologue.fast.694:                           ; preds = %shadow.root.barrier.done.693
  %r4359 = inttoptr i64 %r43431204 to ptr
  %r4360 = getelementptr i8, ptr %r4359, i64 16
  %r4361 = bitcast double %r4348 to i64
  %r4362 = getelementptr double, ptr %r4360, i64 0
  store double %r4350, ptr %r4362, align 8
  %r4363 = ptrtoint ptr %r4362 to i64
  %r4364 = bitcast double %r4350 to i64
  %r4365 = lshr i64 %r4364, 48
  %r4366 = icmp eq i64 %r4365, 0
  %r4367 = icmp uge i64 %r4364, 4096
  %r4368 = and i1 %r4366, %r4367
  %r4369 = icmp eq i64 %r4365, 32765
  %r4370 = icmp eq i64 %r4365, 32767
  %r4371 = icmp eq i64 %r4365, 32762
  %r4372 = or i1 %r4369, %r4370
  %r4373 = or i1 %r4372, %r4371
  %r4374 = or i1 %r4373, %r4368
  br i1 %r4374, label %ctor_prologue.barrier.maybe.697, label %ctor_prologue.barrier.done.699

ctor_prologue.slow.695:                           ; preds = %shadow.root.barrier.done.693
  %statepoint_token1208 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3_constructor, i32 2, i32 0, double %r4348, double %r4350, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1205, ptr addrspace(1) %rs4gc.s9.relocated1206, ptr addrspace(1) %r8.0.relocated1207, ptr addrspace(1) %rs4gc.s94.relocated, ptr addrspace(1) %rs4gc.s96) ]
  %r43831209 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1208)
  %rs4gc.s13.relocated1210 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1208, i32 0, i32 0) ; (%rs4gc.s13.relocated1205, %rs4gc.s13.relocated1205)
  %rs4gc.s9.relocated1211 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1208, i32 1, i32 1) ; (%rs4gc.s9.relocated1206, %rs4gc.s9.relocated1206)
  %r8.0.relocated1212 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1208, i32 2, i32 2) ; (%r8.0.relocated1207, %r8.0.relocated1207)
  %rs4gc.s94.relocated1213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1208, i32 3, i32 3) ; (%rs4gc.s94.relocated, %rs4gc.s94.relocated)
  %rs4gc.s96.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1208, i32 4, i32 4) ; (%rs4gc.s96, %rs4gc.s96)
  br label %ctor_prologue.merge.696

ctor_prologue.merge.696:                          ; preds = %ctor_prologue.barrier.done.699, %ctor_prologue.slow.695
  %.01531 = phi ptr addrspace(1) [ %rs4gc.s96, %ctor_prologue.barrier.done.699 ], [ %rs4gc.s96.relocated, %ctor_prologue.slow.695 ]
  %.01529 = phi ptr addrspace(1) [ %rs4gc.s94.relocated, %ctor_prologue.barrier.done.699 ], [ %rs4gc.s94.relocated1213, %ctor_prologue.slow.695 ]
  %.561421 = phi ptr addrspace(1) [ %rs4gc.s13.relocated1205, %ctor_prologue.barrier.done.699 ], [ %rs4gc.s13.relocated1210, %ctor_prologue.slow.695 ]
  %.531363 = phi ptr addrspace(1) [ %r8.0.relocated1207, %ctor_prologue.barrier.done.699 ], [ %r8.0.relocated1212, %ctor_prologue.slow.695 ]
  %.56 = phi ptr addrspace(1) [ %rs4gc.s9.relocated1206, %ctor_prologue.barrier.done.699 ], [ %rs4gc.s9.relocated1211, %ctor_prologue.slow.695 ]
  %r4384 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.699 ], [ %r43831209, %ctor_prologue.slow.695 ]
  %r4385.rs4i = ptrtoint ptr addrspace(1) %.01531 to i64
  %r4385 = call i64 asm "", "=r,0"(i64 %r4385.rs4i) #7
  %r4386 = or i64 %r4385, 9222527611924643840
  %r4387 = bitcast i64 %r4386 to double
  %r4388 = bitcast double %r4384 to i64
  %r4389 = icmp eq i64 %r4388, 9222246136947933185
  br i1 %r4389, label %ctor_ret.merge.701, label %ctor_ret.override.700

ctor_prologue.barrier.maybe.697:                  ; preds = %ctor_prologue.fast.694
  %r4375 = sub i64 %r43431204, 7
  %r4376 = inttoptr i64 %r4375 to ptr
  %r4377 = load i8, ptr %r4376, align 1
  %r4378 = and i8 %r4377, 32
  %r4379 = icmp ne i8 %r4378, 0
  %r4380 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4381 = icmp ne i32 %r4380, 0
  %r4382 = or i1 %r4379, %r4381
  br i1 %r4382, label %ctor_prologue.barrier.698, label %ctor_prologue.barrier.done.699

ctor_prologue.barrier.698:                        ; preds = %ctor_prologue.barrier.maybe.697
  call void @js_write_barrier_slot_validated_parent(i64 %r43431204, i64 %r4363, i64 %r4364) #7
  br label %ctor_prologue.barrier.done.699

ctor_prologue.barrier.done.699:                   ; preds = %ctor_prologue.barrier.698, %ctor_prologue.barrier.maybe.697, %ctor_prologue.fast.694
  br label %ctor_prologue.merge.696

ctor_ret.override.700:                            ; preds = %ctor_prologue.merge.696
  %statepoint_token1214 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r4387, double %r4384, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.561421, ptr addrspace(1) %.56, ptr addrspace(1) %.531363, ptr addrspace(1) %.01529) ]
  %r43901215 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1214)
  %rs4gc.s13.relocated1216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1214, i32 0, i32 0) ; (%.561421, %.561421)
  %rs4gc.s9.relocated1217 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1214, i32 1, i32 1) ; (%.56, %.56)
  %r8.0.relocated1218 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1214, i32 2, i32 2) ; (%.531363, %.531363)
  %rs4gc.s94.relocated1219 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1214, i32 3, i32 3) ; (%.01529, %.01529)
  br label %ctor_ret.merge.701

ctor_ret.merge.701:                               ; preds = %ctor_ret.override.700, %ctor_prologue.merge.696
  %.11530 = phi ptr addrspace(1) [ %.01529, %ctor_prologue.merge.696 ], [ %rs4gc.s94.relocated1219, %ctor_ret.override.700 ]
  %.571422 = phi ptr addrspace(1) [ %.561421, %ctor_prologue.merge.696 ], [ %rs4gc.s13.relocated1216, %ctor_ret.override.700 ]
  %.541364 = phi ptr addrspace(1) [ %.531363, %ctor_prologue.merge.696 ], [ %r8.0.relocated1218, %ctor_ret.override.700 ]
  %.57 = phi ptr addrspace(1) [ %.56, %ctor_prologue.merge.696 ], [ %rs4gc.s9.relocated1217, %ctor_ret.override.700 ]
  %r4391 = phi double [ %r4387, %ctor_prologue.merge.696 ], [ %r43901215, %ctor_ret.override.700 ]
  %r4392.rs4i = ptrtoint ptr addrspace(1) %.571422 to i64
  %r4392.rs4o = call i64 asm "", "=r,0"(i64 %r4392.rs4i) #7
  %r4392 = bitcast i64 %r4392.rs4o to double
  %statepoint_token1220 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4391, double %r4392, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.541364, ptr addrspace(1) %.571422, ptr addrspace(1) %.57, ptr addrspace(1) %.11530) ]
  %r43931221 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1220)
  %r8.0.relocated1222 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1220, i32 0, i32 0) ; (%.541364, %.541364)
  %rs4gc.s13.relocated1223 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1220, i32 1, i32 1) ; (%.571422, %.571422)
  %rs4gc.s9.relocated1224 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1220, i32 2, i32 2) ; (%.57, %.57)
  %rs4gc.s94.relocated1225 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1220, i32 3, i32 3) ; (%.11530, %.11530)
  %r4394 = bitcast i64 %r43931221 to double
  %r4395.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s94.relocated1225 to i64
  %r4395 = call i64 asm "", "=r,0"(i64 %r4395.rs4i) #7
  %statepoint_token1226 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4395, double %r4394, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r8.0.relocated1222, ptr addrspace(1) %rs4gc.s13.relocated1223, ptr addrspace(1) %rs4gc.s9.relocated1224) ]
  %r43961227 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1226)
  %r8.0.relocated1228 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1226, i32 0, i32 0) ; (%r8.0.relocated1222, %r8.0.relocated1222)
  %rs4gc.s13.relocated1229 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1226, i32 1, i32 1) ; (%rs4gc.s13.relocated1223, %rs4gc.s13.relocated1223)
  %rs4gc.s9.relocated1230 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1226, i32 2, i32 2) ; (%rs4gc.s9.relocated1224, %rs4gc.s9.relocated1224)
  %rs4gc.s97 = inttoptr i64 %r43961227 to ptr addrspace(1)
  %r4397.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s97 to i64
  %r4397 = call i64 asm "", "=r,0"(i64 %r4397.rs4i) #7
  %r4398 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4399 = icmp ne i32 %r4398, 0
  br i1 %r4399, label %shadow.root.barrier.702, label %shadow.root.barrier.done.703

shadow.root.barrier.702:                          ; preds = %ctor_ret.merge.701
  call void @js_write_barrier_root_nanbox(i64 %r4397) #7
  br label %shadow.root.barrier.done.703

shadow.root.barrier.done.703:                     ; preds = %shadow.root.barrier.702, %ctor_ret.merge.701
  %r4400.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s97 to i64
  %r4400 = call i64 asm "", "=r,0"(i64 %r4400.rs4i) #7
  %statepoint_token1231 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r4400, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1229, ptr addrspace(1) %rs4gc.s9.relocated1230, ptr addrspace(1) %r8.0.relocated1228) ]
  %rs4gc.s13.relocated1232 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1231, i32 0, i32 0) ; (%rs4gc.s13.relocated1229, %rs4gc.s13.relocated1229)
  %rs4gc.s9.relocated1233 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1231, i32 1, i32 1) ; (%rs4gc.s9.relocated1230, %rs4gc.s9.relocated1230)
  %r8.0.relocated1234 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1231, i32 2, i32 2) ; (%r8.0.relocated1228, %r8.0.relocated1228)
  %r4402.rs4i = ptrtoint ptr addrspace(1) %r8.0.relocated1234 to i64
  %r4402.rs4o = call i64 asm "", "=r,0"(i64 %r4402.rs4i) #7
  %r4402 = bitcast i64 %r4402.rs4o to double
  %r4403 = bitcast double %r4402 to i64
  %rs4gc.s98 = inttoptr i64 %r4403 to ptr addrspace(1)
  %r4404.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s98 to i64
  %r4404 = call i64 asm "", "=r,0"(i64 %r4404.rs4i) #7
  %r4405 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4406 = icmp ne i32 %r4405, 0
  br i1 %r4406, label %shadow.root.barrier.704, label %shadow.root.barrier.done.705

shadow.root.barrier.704:                          ; preds = %shadow.root.barrier.done.703
  call void @js_write_barrier_root_nanbox(i64 %r4404) #7
  br label %shadow.root.barrier.done.705

shadow.root.barrier.done.705:                     ; preds = %shadow.root.barrier.704, %shadow.root.barrier.done.703
  %r4407 = load double, ptr @test_json_large_string_emitters_ts_.str.14.handle, align 8
  %r4408.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s98 to i64
  %r4408 = call i64 asm "", "=r,0"(i64 %r4408.rs4i) #7
  %r4409 = bitcast i64 %r4408 to double
  %statepoint_token1235 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r4409, double %r4407, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1232, ptr addrspace(1) %rs4gc.s9.relocated1233) ]
  %r44101236 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1235)
  %rs4gc.s13.relocated1237 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1235, i32 0, i32 0) ; (%rs4gc.s13.relocated1232, %rs4gc.s13.relocated1232)
  %rs4gc.s9.relocated1238 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1235, i32 1, i32 1) ; (%rs4gc.s9.relocated1233, %rs4gc.s9.relocated1233)
  %rs4gc.b99 = bitcast double %r44101236 to i64
  %rs4gc.s99 = inttoptr i64 %rs4gc.b99 to ptr addrspace(1)
  %r4411.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s99 to i64
  %r4411 = call i64 asm "", "=r,0"(i64 %r4411.rs4i) #7
  %r4412 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4413 = icmp ne i32 %r4412, 0
  br i1 %r4413, label %shadow.root.barrier.706, label %shadow.root.barrier.done.707

shadow.root.barrier.706:                          ; preds = %shadow.root.barrier.done.705
  call void @js_write_barrier_root_nanbox(i64 %r4411) #7
  br label %shadow.root.barrier.done.707

shadow.root.barrier.done.707:                     ; preds = %shadow.root.barrier.706, %shadow.root.barrier.done.705
  %statepoint_token1239 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1237, ptr addrspace(1) %rs4gc.s9.relocated1238, ptr addrspace(1) %rs4gc.s99) ]
  %r44141240 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1239)
  %rs4gc.s13.relocated1241 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1239, i32 0, i32 0) ; (%rs4gc.s13.relocated1237, %rs4gc.s13.relocated1237)
  %rs4gc.s9.relocated1242 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1239, i32 1, i32 1) ; (%rs4gc.s9.relocated1238, %rs4gc.s9.relocated1238)
  %rs4gc.s99.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1239, i32 2, i32 2) ; (%rs4gc.s99, %rs4gc.s99)
  %rs4gc.s100 = inttoptr i64 %r44141240 to ptr addrspace(1)
  %r4415.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s100 to i64
  %r4415 = call i64 asm "", "=r,0"(i64 %r4415.rs4i) #7
  %r4416 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4417 = icmp ne i32 %r4416, 0
  br i1 %r4417, label %shadow.root.barrier.708, label %shadow.root.barrier.done.709

shadow.root.barrier.708:                          ; preds = %shadow.root.barrier.done.707
  call void @js_write_barrier_root_nanbox(i64 %r4415) #7
  br label %shadow.root.barrier.done.709

shadow.root.barrier.done.709:                     ; preds = %shadow.root.barrier.708, %shadow.root.barrier.done.707
  %r4418 = load double, ptr @test_json_large_string_emitters_ts_.str.15.handle, align 8
  %r4419.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s100 to i64
  %r4419 = call i64 asm "", "=r,0"(i64 %r4419.rs4i) #7
  %statepoint_token1243 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4419, double %r4418, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1241, ptr addrspace(1) %rs4gc.s9.relocated1242, ptr addrspace(1) %rs4gc.s99.relocated) ]
  %r44201244 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1243)
  %rs4gc.s13.relocated1245 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1243, i32 0, i32 0) ; (%rs4gc.s13.relocated1241, %rs4gc.s13.relocated1241)
  %rs4gc.s9.relocated1246 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1243, i32 1, i32 1) ; (%rs4gc.s9.relocated1242, %rs4gc.s9.relocated1242)
  %rs4gc.s99.relocated1247 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1243, i32 2, i32 2) ; (%rs4gc.s99.relocated, %rs4gc.s99.relocated)
  %rs4gc.s101 = inttoptr i64 %r44201244 to ptr addrspace(1)
  %r4421.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s101 to i64
  %r4421 = call i64 asm "", "=r,0"(i64 %r4421.rs4i) #7
  %r4422 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4423 = icmp ne i32 %r4422, 0
  br i1 %r4423, label %shadow.root.barrier.710, label %shadow.root.barrier.done.711

shadow.root.barrier.710:                          ; preds = %shadow.root.barrier.done.709
  call void @js_write_barrier_root_nanbox(i64 %r4421) #7
  br label %shadow.root.barrier.done.711

shadow.root.barrier.done.711:                     ; preds = %shadow.root.barrier.710, %shadow.root.barrier.done.709
  %r4424.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s99.relocated1247 to i64
  %r4424.rs4o = call i64 asm "", "=r,0"(i64 %r4424.rs4i) #7
  %r4424 = bitcast i64 %r4424.rs4o to double
  %r4425 = bitcast double %r4424 to i64
  %rs4gc.s102 = inttoptr i64 %r4425 to ptr addrspace(1)
  %r4426.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s102 to i64
  %r4426 = call i64 asm "", "=r,0"(i64 %r4426.rs4i) #7
  %r4427 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4428 = icmp ne i32 %r4427, 0
  br i1 %r4428, label %shadow.root.barrier.712, label %shadow.root.barrier.done.713

shadow.root.barrier.712:                          ; preds = %shadow.root.barrier.done.711
  call void @js_write_barrier_root_nanbox(i64 %r4426) #7
  br label %shadow.root.barrier.done.713

shadow.root.barrier.done.713:                     ; preds = %shadow.root.barrier.712, %shadow.root.barrier.done.711
  %r4429.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9.relocated1246 to i64
  %r4429 = call i64 asm "", "=r,0"(i64 %r4429.rs4i) #7
  %statepoint_token1248 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 3, i32 0, i32 1, i64 %r4429, i32 %r3833, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1245, ptr addrspace(1) %rs4gc.s9.relocated1246, ptr addrspace(1) %rs4gc.s99.relocated1247, ptr addrspace(1) %rs4gc.s101, ptr addrspace(1) %rs4gc.s102) ]
  %r44311249 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1248)
  %rs4gc.s13.relocated1250 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1248, i32 0, i32 0) ; (%rs4gc.s13.relocated1245, %rs4gc.s13.relocated1245)
  %rs4gc.s9.relocated1251 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1248, i32 1, i32 1) ; (%rs4gc.s9.relocated1246, %rs4gc.s9.relocated1246)
  %rs4gc.s99.relocated1252 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1248, i32 2, i32 2) ; (%rs4gc.s99.relocated1247, %rs4gc.s99.relocated1247)
  %rs4gc.s101.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1248, i32 3, i32 3) ; (%rs4gc.s101, %rs4gc.s101)
  %rs4gc.s102.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1248, i32 4, i32 4) ; (%rs4gc.s102, %rs4gc.s102)
  call void @js_gc_declare_typed_shape_layout(i64 %r44311249, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, i32 1) #7
  %rs4gc.s103 = inttoptr i64 %r44311249 to ptr addrspace(1)
  %r4432.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s103 to i64
  %r4432 = call i64 asm "", "=r,0"(i64 %r4432.rs4i) #7
  %r4433 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4434 = icmp ne i32 %r4433, 0
  br i1 %r4434, label %shadow.root.barrier.714, label %shadow.root.barrier.done.715

shadow.root.barrier.714:                          ; preds = %shadow.root.barrier.done.713
  call void @js_write_barrier_root_nanbox(i64 %r4432) #7
  br label %shadow.root.barrier.done.715

shadow.root.barrier.done.715:                     ; preds = %shadow.root.barrier.714, %shadow.root.barrier.done.713
  %r4435 = or i64 %r44311249, 9222527611924643840
  %r4436 = bitcast i64 %r4435 to double
  %r4437.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s102.relocated to i64
  %r4437 = call i64 asm "", "=r,0"(i64 %r4437.rs4i) #7
  %r4438 = bitcast i64 %r4437 to double
  %r4439 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r4440 = icmp eq i8 %r4439, 0
  %r4441 = inttoptr i64 %r44311249 to ptr
  %r4442 = getelementptr i8, ptr %r4441, i64 -6
  %r4443 = load i16, ptr %r4442, align 2
  %r4444 = and i16 %r4443, 4096
  %r4445 = icmp ne i16 %r4444, 0
  %r4446 = and i1 %r4440, %r4445
  br i1 %r4446, label %ctor_prologue.fast.716, label %ctor_prologue.slow.717

ctor_prologue.fast.716:                           ; preds = %shadow.root.barrier.done.715
  %r4447 = inttoptr i64 %r44311249 to ptr
  %r4448 = getelementptr i8, ptr %r4447, i64 16
  %r4449 = bitcast double %r4436 to i64
  %r4450 = getelementptr double, ptr %r4448, i64 0
  store double %r4438, ptr %r4450, align 8
  %r4451 = ptrtoint ptr %r4450 to i64
  %r4452 = bitcast double %r4438 to i64
  %r4453 = lshr i64 %r4452, 48
  %r4454 = icmp eq i64 %r4453, 0
  %r4455 = icmp uge i64 %r4452, 4096
  %r4456 = and i1 %r4454, %r4455
  %r4457 = icmp eq i64 %r4453, 32765
  %r4458 = icmp eq i64 %r4453, 32767
  %r4459 = icmp eq i64 %r4453, 32762
  %r4460 = or i1 %r4457, %r4458
  %r4461 = or i1 %r4460, %r4459
  %r4462 = or i1 %r4461, %r4456
  br i1 %r4462, label %ctor_prologue.barrier.maybe.719, label %ctor_prologue.barrier.done.721

ctor_prologue.slow.717:                           ; preds = %shadow.root.barrier.done.715
  %statepoint_token1253 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3_constructor, i32 2, i32 0, double %r4436, double %r4438, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1250, ptr addrspace(1) %rs4gc.s9.relocated1251, ptr addrspace(1) %rs4gc.s99.relocated1252, ptr addrspace(1) %rs4gc.s101.relocated, ptr addrspace(1) %rs4gc.s103) ]
  %r44711254 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1253)
  %rs4gc.s13.relocated1255 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1253, i32 0, i32 0) ; (%rs4gc.s13.relocated1250, %rs4gc.s13.relocated1250)
  %rs4gc.s9.relocated1256 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1253, i32 1, i32 1) ; (%rs4gc.s9.relocated1251, %rs4gc.s9.relocated1251)
  %rs4gc.s99.relocated1257 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1253, i32 2, i32 2) ; (%rs4gc.s99.relocated1252, %rs4gc.s99.relocated1252)
  %rs4gc.s101.relocated1258 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1253, i32 3, i32 3) ; (%rs4gc.s101.relocated, %rs4gc.s101.relocated)
  %rs4gc.s103.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1253, i32 4, i32 4) ; (%rs4gc.s103, %rs4gc.s103)
  br label %ctor_prologue.merge.718

ctor_prologue.merge.718:                          ; preds = %ctor_prologue.barrier.done.721, %ctor_prologue.slow.717
  %.01536 = phi ptr addrspace(1) [ %rs4gc.s103, %ctor_prologue.barrier.done.721 ], [ %rs4gc.s103.relocated, %ctor_prologue.slow.717 ]
  %.01534 = phi ptr addrspace(1) [ %rs4gc.s101.relocated, %ctor_prologue.barrier.done.721 ], [ %rs4gc.s101.relocated1258, %ctor_prologue.slow.717 ]
  %.01532 = phi ptr addrspace(1) [ %rs4gc.s99.relocated1252, %ctor_prologue.barrier.done.721 ], [ %rs4gc.s99.relocated1257, %ctor_prologue.slow.717 ]
  %.581423 = phi ptr addrspace(1) [ %rs4gc.s13.relocated1250, %ctor_prologue.barrier.done.721 ], [ %rs4gc.s13.relocated1255, %ctor_prologue.slow.717 ]
  %.58 = phi ptr addrspace(1) [ %rs4gc.s9.relocated1251, %ctor_prologue.barrier.done.721 ], [ %rs4gc.s9.relocated1256, %ctor_prologue.slow.717 ]
  %r4472 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.721 ], [ %r44711254, %ctor_prologue.slow.717 ]
  %r4473.rs4i = ptrtoint ptr addrspace(1) %.01536 to i64
  %r4473 = call i64 asm "", "=r,0"(i64 %r4473.rs4i) #7
  %r4474 = or i64 %r4473, 9222527611924643840
  %r4475 = bitcast i64 %r4474 to double
  %r4476 = bitcast double %r4472 to i64
  %r4477 = icmp eq i64 %r4476, 9222246136947933185
  br i1 %r4477, label %ctor_ret.merge.723, label %ctor_ret.override.722

ctor_prologue.barrier.maybe.719:                  ; preds = %ctor_prologue.fast.716
  %r4463 = sub i64 %r44311249, 7
  %r4464 = inttoptr i64 %r4463 to ptr
  %r4465 = load i8, ptr %r4464, align 1
  %r4466 = and i8 %r4465, 32
  %r4467 = icmp ne i8 %r4466, 0
  %r4468 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4469 = icmp ne i32 %r4468, 0
  %r4470 = or i1 %r4467, %r4469
  br i1 %r4470, label %ctor_prologue.barrier.720, label %ctor_prologue.barrier.done.721

ctor_prologue.barrier.720:                        ; preds = %ctor_prologue.barrier.maybe.719
  call void @js_write_barrier_slot_validated_parent(i64 %r44311249, i64 %r4451, i64 %r4452) #7
  br label %ctor_prologue.barrier.done.721

ctor_prologue.barrier.done.721:                   ; preds = %ctor_prologue.barrier.720, %ctor_prologue.barrier.maybe.719, %ctor_prologue.fast.716
  br label %ctor_prologue.merge.718

ctor_ret.override.722:                            ; preds = %ctor_prologue.merge.718
  %statepoint_token1259 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r4475, double %r4472, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.581423, ptr addrspace(1) %.58, ptr addrspace(1) %.01532, ptr addrspace(1) %.01534) ]
  %r44781260 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1259)
  %rs4gc.s13.relocated1261 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1259, i32 0, i32 0) ; (%.581423, %.581423)
  %rs4gc.s9.relocated1262 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1259, i32 1, i32 1) ; (%.58, %.58)
  %rs4gc.s99.relocated1263 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1259, i32 2, i32 2) ; (%.01532, %.01532)
  %rs4gc.s101.relocated1264 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1259, i32 3, i32 3) ; (%.01534, %.01534)
  br label %ctor_ret.merge.723

ctor_ret.merge.723:                               ; preds = %ctor_ret.override.722, %ctor_prologue.merge.718
  %.11535 = phi ptr addrspace(1) [ %.01534, %ctor_prologue.merge.718 ], [ %rs4gc.s101.relocated1264, %ctor_ret.override.722 ]
  %.11533 = phi ptr addrspace(1) [ %.01532, %ctor_prologue.merge.718 ], [ %rs4gc.s99.relocated1263, %ctor_ret.override.722 ]
  %.591424 = phi ptr addrspace(1) [ %.581423, %ctor_prologue.merge.718 ], [ %rs4gc.s13.relocated1261, %ctor_ret.override.722 ]
  %.59 = phi ptr addrspace(1) [ %.58, %ctor_prologue.merge.718 ], [ %rs4gc.s9.relocated1262, %ctor_ret.override.722 ]
  %r4479 = phi double [ %r4475, %ctor_prologue.merge.718 ], [ %r44781260, %ctor_ret.override.722 ]
  %statepoint_token1265 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4479, double 0x7FFC000000000002, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.591424, ptr addrspace(1) %.59, ptr addrspace(1) %.11533, ptr addrspace(1) %.11535) ]
  %r44801266 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1265)
  %rs4gc.s13.relocated1267 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1265, i32 0, i32 0) ; (%.591424, %.591424)
  %rs4gc.s9.relocated1268 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1265, i32 1, i32 1) ; (%.59, %.59)
  %rs4gc.s99.relocated1269 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1265, i32 2, i32 2) ; (%.11533, %.11533)
  %rs4gc.s101.relocated1270 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1265, i32 3, i32 3) ; (%.11535, %.11535)
  %r4481 = bitcast i64 %r44801266 to double
  %r4482.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s101.relocated1270 to i64
  %r4482 = call i64 asm "", "=r,0"(i64 %r4482.rs4i) #7
  %statepoint_token1271 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4482, double %r4481, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1267, ptr addrspace(1) %rs4gc.s9.relocated1268, ptr addrspace(1) %rs4gc.s99.relocated1269) ]
  %r44831272 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1271)
  %rs4gc.s13.relocated1273 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1271, i32 0, i32 0) ; (%rs4gc.s13.relocated1267, %rs4gc.s13.relocated1267)
  %rs4gc.s9.relocated1274 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1271, i32 1, i32 1) ; (%rs4gc.s9.relocated1268, %rs4gc.s9.relocated1268)
  %rs4gc.s99.relocated1275 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1271, i32 2, i32 2) ; (%rs4gc.s99.relocated1269, %rs4gc.s99.relocated1269)
  %rs4gc.s104 = inttoptr i64 %r44831272 to ptr addrspace(1)
  %r4484.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s104 to i64
  %r4484 = call i64 asm "", "=r,0"(i64 %r4484.rs4i) #7
  %r4485 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4486 = icmp ne i32 %r4485, 0
  br i1 %r4486, label %shadow.root.barrier.724, label %shadow.root.barrier.done.725

shadow.root.barrier.724:                          ; preds = %ctor_ret.merge.723
  call void @js_write_barrier_root_nanbox(i64 %r4484) #7
  br label %shadow.root.barrier.done.725

shadow.root.barrier.done.725:                     ; preds = %shadow.root.barrier.724, %ctor_ret.merge.723
  %r4487.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s104 to i64
  %r4487 = call i64 asm "", "=r,0"(i64 %r4487.rs4i) #7
  %statepoint_token1276 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r4487, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1273, ptr addrspace(1) %rs4gc.s9.relocated1274, ptr addrspace(1) %rs4gc.s99.relocated1275) ]
  %rs4gc.s13.relocated1277 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1276, i32 0, i32 0) ; (%rs4gc.s13.relocated1273, %rs4gc.s13.relocated1273)
  %rs4gc.s9.relocated1278 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1276, i32 1, i32 1) ; (%rs4gc.s9.relocated1274, %rs4gc.s9.relocated1274)
  %rs4gc.s99.relocated1279 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1276, i32 2, i32 2) ; (%rs4gc.s99.relocated1275, %rs4gc.s99.relocated1275)
  %statepoint_token1280 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1277, ptr addrspace(1) %rs4gc.s9.relocated1278, ptr addrspace(1) %rs4gc.s99.relocated1279) ]
  %r44881281 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1280)
  %rs4gc.s13.relocated1282 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1280, i32 0, i32 0) ; (%rs4gc.s13.relocated1277, %rs4gc.s13.relocated1277)
  %rs4gc.s9.relocated1283 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1280, i32 1, i32 1) ; (%rs4gc.s9.relocated1278, %rs4gc.s9.relocated1278)
  %rs4gc.s99.relocated1284 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1280, i32 2, i32 2) ; (%rs4gc.s99.relocated1279, %rs4gc.s99.relocated1279)
  %rs4gc.s105 = inttoptr i64 %r44881281 to ptr addrspace(1)
  %r4489.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s105 to i64
  %r4489 = call i64 asm "", "=r,0"(i64 %r4489.rs4i) #7
  %r4490 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4491 = icmp ne i32 %r4490, 0
  br i1 %r4491, label %shadow.root.barrier.726, label %shadow.root.barrier.done.727

shadow.root.barrier.726:                          ; preds = %shadow.root.barrier.done.725
  call void @js_write_barrier_root_nanbox(i64 %r4489) #7
  br label %shadow.root.barrier.done.727

shadow.root.barrier.done.727:                     ; preds = %shadow.root.barrier.726, %shadow.root.barrier.done.725
  %r4492 = load double, ptr @test_json_large_string_emitters_ts_.str.16.handle, align 8
  %r4493.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s105 to i64
  %r4493 = call i64 asm "", "=r,0"(i64 %r4493.rs4i) #7
  %statepoint_token1285 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4493, double %r4492, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s13.relocated1282, ptr addrspace(1) %rs4gc.s9.relocated1283, ptr addrspace(1) %rs4gc.s99.relocated1284) ]
  %r44941286 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1285)
  %rs4gc.s13.relocated1287 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1285, i32 0, i32 0) ; (%rs4gc.s13.relocated1282, %rs4gc.s13.relocated1282)
  %rs4gc.s9.relocated1288 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1285, i32 1, i32 1) ; (%rs4gc.s9.relocated1283, %rs4gc.s9.relocated1283)
  %rs4gc.s99.relocated1289 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1285, i32 2, i32 2) ; (%rs4gc.s99.relocated1284, %rs4gc.s99.relocated1284)
  %rs4gc.s106 = inttoptr i64 %r44941286 to ptr addrspace(1)
  %r4495.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s106 to i64
  %r4495 = call i64 asm "", "=r,0"(i64 %r4495.rs4i) #7
  %r4496 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4497 = icmp ne i32 %r4496, 0
  br i1 %r4497, label %shadow.root.barrier.728, label %shadow.root.barrier.done.729

shadow.root.barrier.728:                          ; preds = %shadow.root.barrier.done.727
  call void @js_write_barrier_root_nanbox(i64 %r4495) #7
  br label %shadow.root.barrier.done.729

shadow.root.barrier.done.729:                     ; preds = %shadow.root.barrier.728, %shadow.root.barrier.done.727
  %r4498.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s99.relocated1289 to i64
  %r4498.rs4o = call i64 asm "", "=r,0"(i64 %r4498.rs4i) #7
  %r4498 = bitcast i64 %r4498.rs4o to double
  %r4499 = bitcast double %r4498 to i64
  %rs4gc.s107 = inttoptr i64 %r4499 to ptr addrspace(1)
  %r4500.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s107 to i64
  %r4500 = call i64 asm "", "=r,0"(i64 %r4500.rs4i) #7
  %r4501 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4502 = icmp ne i32 %r4501, 0
  br i1 %r4502, label %shadow.root.barrier.730, label %shadow.root.barrier.done.731

shadow.root.barrier.730:                          ; preds = %shadow.root.barrier.done.729
  call void @js_write_barrier_root_nanbox(i64 %r4500) #7
  br label %shadow.root.barrier.done.731

shadow.root.barrier.done.731:                     ; preds = %shadow.root.barrier.730, %shadow.root.barrier.done.729
  %r4503.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9.relocated1288 to i64
  %r4503 = call i64 asm "", "=r,0"(i64 %r4503.rs4i) #7
  %statepoint_token1290 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 3, i32 0, i32 1, i64 %r4503, i32 %r3833, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s106, ptr addrspace(1) %rs4gc.s13.relocated1287, ptr addrspace(1) %rs4gc.s107) ]
  %r45051291 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1290)
  %rs4gc.s106.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1290, i32 0, i32 0) ; (%rs4gc.s106, %rs4gc.s106)
  %rs4gc.s13.relocated1292 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1290, i32 1, i32 1) ; (%rs4gc.s13.relocated1287, %rs4gc.s13.relocated1287)
  %rs4gc.s107.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1290, i32 2, i32 2) ; (%rs4gc.s107, %rs4gc.s107)
  call void @js_gc_declare_typed_shape_layout(i64 %r45051291, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, i32 1) #7
  %rs4gc.s108 = inttoptr i64 %r45051291 to ptr addrspace(1)
  %r4506.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s108 to i64
  %r4506 = call i64 asm "", "=r,0"(i64 %r4506.rs4i) #7
  %r4507 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4508 = icmp ne i32 %r4507, 0
  br i1 %r4508, label %shadow.root.barrier.732, label %shadow.root.barrier.done.733

shadow.root.barrier.732:                          ; preds = %shadow.root.barrier.done.731
  call void @js_write_barrier_root_nanbox(i64 %r4506) #7
  br label %shadow.root.barrier.done.733

shadow.root.barrier.done.733:                     ; preds = %shadow.root.barrier.732, %shadow.root.barrier.done.731
  %r4509 = or i64 %r45051291, 9222527611924643840
  %r4510 = bitcast i64 %r4509 to double
  %r4511.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s107.relocated to i64
  %r4511 = call i64 asm "", "=r,0"(i64 %r4511.rs4i) #7
  %r4512 = bitcast i64 %r4511 to double
  %r4513 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r4514 = icmp eq i8 %r4513, 0
  %r4515 = inttoptr i64 %r45051291 to ptr
  %r4516 = getelementptr i8, ptr %r4515, i64 -6
  %r4517 = load i16, ptr %r4516, align 2
  %r4518 = and i16 %r4517, 4096
  %r4519 = icmp ne i16 %r4518, 0
  %r4520 = and i1 %r4514, %r4519
  br i1 %r4520, label %ctor_prologue.fast.734, label %ctor_prologue.slow.735

ctor_prologue.fast.734:                           ; preds = %shadow.root.barrier.done.733
  %r4521 = inttoptr i64 %r45051291 to ptr
  %r4522 = getelementptr i8, ptr %r4521, i64 16
  %r4523 = bitcast double %r4510 to i64
  %r4524 = getelementptr double, ptr %r4522, i64 0
  store double %r4512, ptr %r4524, align 8
  %r4525 = ptrtoint ptr %r4524 to i64
  %r4526 = bitcast double %r4512 to i64
  %r4527 = lshr i64 %r4526, 48
  %r4528 = icmp eq i64 %r4527, 0
  %r4529 = icmp uge i64 %r4526, 4096
  %r4530 = and i1 %r4528, %r4529
  %r4531 = icmp eq i64 %r4527, 32765
  %r4532 = icmp eq i64 %r4527, 32767
  %r4533 = icmp eq i64 %r4527, 32762
  %r4534 = or i1 %r4531, %r4532
  %r4535 = or i1 %r4534, %r4533
  %r4536 = or i1 %r4535, %r4530
  br i1 %r4536, label %ctor_prologue.barrier.maybe.737, label %ctor_prologue.barrier.done.739

ctor_prologue.slow.735:                           ; preds = %shadow.root.barrier.done.733
  %statepoint_token1293 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3_constructor, i32 2, i32 0, double %r4510, double %r4512, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s106.relocated, ptr addrspace(1) %rs4gc.s13.relocated1292, ptr addrspace(1) %rs4gc.s108) ]
  %r45451294 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1293)
  %rs4gc.s106.relocated1295 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1293, i32 0, i32 0) ; (%rs4gc.s106.relocated, %rs4gc.s106.relocated)
  %rs4gc.s13.relocated1296 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1293, i32 1, i32 1) ; (%rs4gc.s13.relocated1292, %rs4gc.s13.relocated1292)
  %rs4gc.s108.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1293, i32 2, i32 2) ; (%rs4gc.s108, %rs4gc.s108)
  br label %ctor_prologue.merge.736

ctor_prologue.merge.736:                          ; preds = %ctor_prologue.barrier.done.739, %ctor_prologue.slow.735
  %.01539 = phi ptr addrspace(1) [ %rs4gc.s108, %ctor_prologue.barrier.done.739 ], [ %rs4gc.s108.relocated, %ctor_prologue.slow.735 ]
  %.01537 = phi ptr addrspace(1) [ %rs4gc.s106.relocated, %ctor_prologue.barrier.done.739 ], [ %rs4gc.s106.relocated1295, %ctor_prologue.slow.735 ]
  %.60 = phi ptr addrspace(1) [ %rs4gc.s13.relocated1292, %ctor_prologue.barrier.done.739 ], [ %rs4gc.s13.relocated1296, %ctor_prologue.slow.735 ]
  %r4546 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.739 ], [ %r45451294, %ctor_prologue.slow.735 ]
  %r4547.rs4i = ptrtoint ptr addrspace(1) %.01539 to i64
  %r4547 = call i64 asm "", "=r,0"(i64 %r4547.rs4i) #7
  %r4548 = or i64 %r4547, 9222527611924643840
  %r4549 = bitcast i64 %r4548 to double
  %r4550 = bitcast double %r4546 to i64
  %r4551 = icmp eq i64 %r4550, 9222246136947933185
  br i1 %r4551, label %ctor_ret.merge.741, label %ctor_ret.override.740

ctor_prologue.barrier.maybe.737:                  ; preds = %ctor_prologue.fast.734
  %r4537 = sub i64 %r45051291, 7
  %r4538 = inttoptr i64 %r4537 to ptr
  %r4539 = load i8, ptr %r4538, align 1
  %r4540 = and i8 %r4539, 32
  %r4541 = icmp ne i8 %r4540, 0
  %r4542 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4543 = icmp ne i32 %r4542, 0
  %r4544 = or i1 %r4541, %r4543
  br i1 %r4544, label %ctor_prologue.barrier.738, label %ctor_prologue.barrier.done.739

ctor_prologue.barrier.738:                        ; preds = %ctor_prologue.barrier.maybe.737
  call void @js_write_barrier_slot_validated_parent(i64 %r45051291, i64 %r4525, i64 %r4526) #7
  br label %ctor_prologue.barrier.done.739

ctor_prologue.barrier.done.739:                   ; preds = %ctor_prologue.barrier.738, %ctor_prologue.barrier.maybe.737, %ctor_prologue.fast.734
  br label %ctor_prologue.merge.736

ctor_ret.override.740:                            ; preds = %ctor_prologue.merge.736
  %statepoint_token1297 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r4549, double %r4546, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01537, ptr addrspace(1) %.60) ]
  %r45521298 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1297)
  %rs4gc.s106.relocated1299 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1297, i32 0, i32 0) ; (%.01537, %.01537)
  %rs4gc.s13.relocated1300 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1297, i32 1, i32 1) ; (%.60, %.60)
  br label %ctor_ret.merge.741

ctor_ret.merge.741:                               ; preds = %ctor_ret.override.740, %ctor_prologue.merge.736
  %.11538 = phi ptr addrspace(1) [ %.01537, %ctor_prologue.merge.736 ], [ %rs4gc.s106.relocated1299, %ctor_ret.override.740 ]
  %.61 = phi ptr addrspace(1) [ %.60, %ctor_prologue.merge.736 ], [ %rs4gc.s13.relocated1300, %ctor_ret.override.740 ]
  %r4553 = phi double [ %r4549, %ctor_prologue.merge.736 ], [ %r45521298, %ctor_ret.override.740 ]
  %r4554.rs4i = ptrtoint ptr addrspace(1) %.61 to i64
  %r4554.rs4o = call i64 asm "", "=r,0"(i64 %r4554.rs4i) #7
  %r4554 = bitcast i64 %r4554.rs4o to double
  %statepoint_token1301 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r4553, double %r4554, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11538) ]
  %r45551302 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1301)
  %rs4gc.s106.relocated1303 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1301, i32 0, i32 0) ; (%.11538, %.11538)
  %r4556 = bitcast i64 %r45551302 to double
  %r4557.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s106.relocated1303 to i64
  %r4557 = call i64 asm "", "=r,0"(i64 %r4557.rs4i) #7
  %statepoint_token1304 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r4557, double %r4556, i32 0, i32 0)
  %r45581305 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token1304)
  %rs4gc.s109 = inttoptr i64 %r45581305 to ptr addrspace(1)
  %r4559.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s109 to i64
  %r4559 = call i64 asm "", "=r,0"(i64 %r4559.rs4i) #7
  %r4560 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r4561 = icmp ne i32 %r4560, 0
  br i1 %r4561, label %shadow.root.barrier.742, label %shadow.root.barrier.done.743

shadow.root.barrier.742:                          ; preds = %ctor_ret.merge.741
  call void @js_write_barrier_root_nanbox(i64 %r4559) #7
  br label %shadow.root.barrier.done.743

shadow.root.barrier.done.743:                     ; preds = %shadow.root.barrier.742, %ctor_ret.merge.741
  %r4562.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s109 to i64
  %r4562 = call i64 asm "", "=r,0"(i64 %r4562.rs4i) #7
  %statepoint_token1306 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r4562, i32 0, i32 0)
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define double @perry_closure_test_json_large_string_emitters_ts__2(i64 %this_closure, double %arg5, double %arg6) #6 gc "statepoint-example" {
entry.0:
  %r270 = load <2 x i64>, ptr @perry_class_header_image_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, align 16
  %r652 = alloca [32 x double], align 8
  %rs4gc.b3 = bitcast double %arg5 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %rs4gc.b4 = bitcast double %arg6 to i64
  %rs4gc.s4 = inttoptr i64 %rs4gc.b4 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #7
  %r3 = bitcast i64 %r3.rs4o to double
  %r4 = bitcast double %r3 to i64
  %r5 = and i64 %r4, 281474976710655
  %r6 = lshr i64 %r4, 48
  %r7 = and i64 %r6, 65533
  %r8 = icmp eq i64 %r7, 32765
  br i1 %r8, label %pget.recv_ok.2, label %pget.recv_other.7

pget.recv_sso.1:                                  ; preds = %pget.recv_other.7
  %r147 = lshr i64 %r4, 40
  %r148 = and i64 %r147, 255
  %r149 = uitofp nneg i64 %r148 to double
  br label %pget.recv_merge.5

pget.recv_ok.2:                                   ; preds = %entry.0
  %r15 = icmp eq i64 %r6, 32767
  br i1 %r15, label %pget.strlen_heap.6, label %pget.recv_obj.9

pget.recv_bad.3:                                  ; preds = %pget.check_class_ref.8
  %r139 = icmp eq i64 %r4, 9222246136947933185
  %r140 = icmp eq i64 %r4, 9222246136947933186
  %r141 = or i1 %r139, %r140
  br i1 %r141, label %pget.throw_nullish.32, label %pget.recv_undef_return.33

pget.recv_class_ref.4:                            ; preds = %pget.check_class_ref.8
  %r11 = load double, ptr @test_json_large_string_emitters_ts_.str.17.handle, align 8
  %r12 = bitcast double %r11 to i64
  %r13 = and i64 %r12, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7058970246387859472, i64 %r4, i64 %r13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4) ]
  %r1410 = call double @llvm.experimental.gc.result.f64(token %statepoint_token)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s4, %rs4gc.s4)
  br label %pget.recv_merge.5

pget.recv_merge.5:                                ; preds = %pget.recv_undef_return.33, %pic.merge.24, %pget.strlen_heap.6, %pget.recv_class_ref.4, %pget.recv_sso.1
  %.0 = phi ptr addrspace(1) [ %rs4gc.s4, %pget.strlen_heap.6 ], [ %.1, %pic.merge.24 ], [ %rs4gc.s4, %pget.recv_sso.1 ], [ %rs4gc.s4.relocated, %pget.recv_class_ref.4 ], [ %rs4gc.s4.relocated20, %pget.recv_undef_return.33 ]
  %r155 = phi double [ %r138, %pic.merge.24 ], [ %r14619, %pget.recv_undef_return.33 ], [ %r149, %pget.recv_sso.1 ], [ %r1410, %pget.recv_class_ref.4 ], [ %r154, %pget.strlen_heap.6 ]
  %r156 = bitcast double %r155 to i64
  %r157 = lshr i64 %r156, 48
  %r158 = icmp ult i64 %r157, 32761
  %r159 = icmp ugt i64 %r157, 32767
  %r160 = or i1 %r158, %r159
  %r161 = icmp eq i64 %r157, 32766
  %r162 = icmp eq i64 %r156, 9222246136947933185
  %r163 = icmp eq i64 %r156, 9222246136947933186
  %r164 = icmp eq i64 %r156, 9222246136947933187
  %r165 = icmp eq i64 %r156, 9222246136947933188
  %r166 = or i1 %r163, %r164
  %r167 = or i1 %r160, %r161
  %r168 = or i1 %r167, %r162
  %r169 = or i1 %r168, %r166
  %r170 = or i1 %r169, %r165
  br i1 %r170, label %relnum.fast.34, label %relnum.slow.35

pget.strlen_heap.6:                               ; preds = %pget.recv_ok.2
  %r150 = icmp ult i64 %r5, 4096
  %r151 = inttoptr i64 %r5 to ptr
  %r152 = select i1 %r150, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r151
  %r153 = load i32, ptr %r152, align 4
  %r154 = uitofp i32 %r153 to double
  br label %pget.recv_merge.5

pget.recv_other.7:                                ; preds = %entry.0
  %r9 = icmp eq i64 %r6, 32761
  br i1 %r9, label %pget.recv_sso.1, label %pget.check_class_ref.8

pget.check_class_ref.8:                           ; preds = %pget.recv_other.7
  %r10 = icmp eq i64 %r6, 32766
  br i1 %r10, label %pget.recv_class_ref.4, label %pget.recv_bad.3

pget.recv_obj.9:                                  ; preds = %pget.recv_ok.2
  %r16 = icmp ugt i64 %r5, 1048575
  br i1 %r16, label %pic.recv_hdr.25, label %pic.miss.cold.22

pic.hit.10:                                       ; preds = %pic.token.26
  %r41 = getelementptr i64, ptr %r26, i64 1
  %r42 = load i64, ptr %r41, align 8
  %r43 = and i64 %r42, 1073741824
  %r44 = icmp ne i64 %r43, 0
  br i1 %r44, label %pic.hit.overflow.27, label %pic.hit.inline.28

pic.hit.live.11:                                  ; preds = %pic.hit.inline.28
  br label %pic.merge.24

pic.prefix.guard.12:                              ; preds = %pic.token.26
  %r57 = getelementptr i64, ptr %r26, i64 2
  %r58 = load i64, ptr %r57, align 8
  %r59 = icmp ne i64 %r58, 0
  br i1 %r59, label %pic.prefix.meta.13, label %pic.miss.21

pic.prefix.meta.13:                               ; preds = %pic.prefix.guard.12
  %r60 = add nuw nsw i64 %r5, 8
  %r61 = inttoptr i64 %r60 to ptr
  %r62 = load i64, ptr %r61, align 8
  %r63 = icmp ne i64 %r62, 0
  br i1 %r63, label %pic.prefix.token.14, label %pic.miss.21

pic.prefix.token.14:                              ; preds = %pic.prefix.meta.13
  %r64 = inttoptr i64 %r62 to ptr
  %r65 = getelementptr i64, ptr %r64, i64 6
  %r66 = load i64, ptr %r65, align 8
  %r67 = icmp eq i64 %r66, %r58
  br i1 %r67, label %pic.prefix.hit.15, label %pic.miss.21

pic.prefix.hit.15:                                ; preds = %pic.prefix.token.14
  %r68 = getelementptr i64, ptr %r26, i64 1
  %r69 = load i64, ptr %r68, align 8
  %r70 = shl i64 %r69, 3
  %r71 = add nuw nsw i64 %r5, 16
  %r72 = add i64 %r71, %r70
  %r73 = inttoptr i64 %r72 to ptr
  %r74 = load double, ptr %r73, align 8
  br label %pic.merge.24

pic.desc.classify.16:                             ; preds = %pic.recv_hdr.25
  %r30 = and i1 %r20, %r27
  br i1 %r30, label %pic.desc.prefix.guard.17, label %pic.miss.cold.22

pic.desc.prefix.guard.17:                         ; preds = %pic.desc.classify.16
  %r75 = getelementptr i64, ptr %r26, i64 2
  %r76 = load i64, ptr %r75, align 8
  %r77 = icmp ne i64 %r76, 0
  br i1 %r77, label %pic.desc.prefix.meta.18, label %pic.miss.cold.22

pic.desc.prefix.meta.18:                          ; preds = %pic.desc.prefix.guard.17
  %r78 = add nuw nsw i64 %r5, 8
  %r79 = inttoptr i64 %r78 to ptr
  %r80 = load i64, ptr %r79, align 8
  %r81 = icmp ne i64 %r80, 0
  br i1 %r81, label %pic.desc.prefix.token.19, label %pic.miss.cold.22

pic.desc.prefix.token.19:                         ; preds = %pic.desc.prefix.meta.18
  %r82 = inttoptr i64 %r80 to ptr
  %r83 = getelementptr i64, ptr %r82, i64 6
  %r84 = load i64, ptr %r83, align 8
  %r85 = icmp eq i64 %r84, %r76
  br i1 %r85, label %pic.desc.prefix.hit.20, label %pic.miss.cold.22

pic.desc.prefix.hit.20:                           ; preds = %pic.desc.prefix.token.19
  %r86 = getelementptr i64, ptr %r26, i64 1
  %r87 = load i64, ptr %r86, align 8
  %r88 = shl i64 %r87, 3
  %r89 = add nuw nsw i64 %r5, 16
  %r90 = add i64 %r89, %r88
  %r91 = inttoptr i64 %r90 to ptr
  %r92 = load double, ptr %r91, align 8
  br label %pic.merge.24

pic.miss.21:                                      ; preds = %pic.hit.inline.28, %pic.prefix.token.14, %pic.prefix.meta.13, %pic.prefix.guard.12
  %r93 = getelementptr i64, ptr %r26, i64 3
  %r94 = load i64, ptr %r93, align 8
  %r95 = icmp sgt i64 %r94, 0
  br i1 %r95, label %pic.ways.29, label %pic.miss.call.23

pic.miss.cold.22:                                 ; preds = %pic.desc.prefix.token.19, %pic.desc.prefix.meta.18, %pic.desc.prefix.guard.17, %pic.desc.classify.16, %pget.recv_obj.9
  br label %pic.miss.call.23

pic.miss.call.23:                                 ; preds = %pic.way.load.30, %pic.ways.29, %pic.miss.cold.22, %pic.miss.21
  %r134 = load double, ptr @test_json_large_string_emitters_ts_.str.17.handle, align 8
  %r135 = bitcast double %r134 to i64
  %r136 = and i64 %r135, 281474976710655
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r5, i64 %r136, ptr @perry_ic_test_json_large_string_emitters_ts__17, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4) ]
  %r13712 = call double @llvm.experimental.gc.result.f64(token %statepoint_token11)
  %rs4gc.s4.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 0, i32 0) ; (%rs4gc.s4, %rs4gc.s4)
  br label %pic.merge.24

pic.merge.24:                                     ; preds = %pic.way.live.31, %pic.hit.overflow.27, %pic.miss.call.23, %pic.desc.prefix.hit.20, %pic.prefix.hit.15, %pic.hit.live.11
  %.1 = phi ptr addrspace(1) [ %rs4gc.s4.relocated16, %pic.hit.overflow.27 ], [ %rs4gc.s4.relocated13, %pic.miss.call.23 ], [ %rs4gc.s4, %pic.way.live.31 ], [ %rs4gc.s4, %pic.hit.live.11 ], [ %rs4gc.s4, %pic.prefix.hit.15 ], [ %rs4gc.s4, %pic.desc.prefix.hit.20 ]
  %r138 = phi double [ %r54, %pic.hit.live.11 ], [ %r4915, %pic.hit.overflow.27 ], [ %r74, %pic.prefix.hit.15 ], [ %r92, %pic.desc.prefix.hit.20 ], [ %r131, %pic.way.live.31 ], [ %r13712, %pic.miss.call.23 ]
  br label %pget.recv_merge.5

pic.recv_hdr.25:                                  ; preds = %pget.recv_obj.9
  %r17 = sub nuw nsw i64 %r5, 8
  %r18 = inttoptr i64 %r17 to ptr
  %r19 = load i8, ptr %r18, align 1
  %r20 = icmp eq i8 %r19, 2
  %r21 = sub nuw nsw i64 %r5, 6
  %r22 = inttoptr i64 %r21 to ptr
  %r23 = load i16, ptr %r22, align 2
  %r24 = and i16 %r23, 2048
  %r25 = icmp eq i16 %r24, 0
  %r26 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__17, align 8
  %r27 = icmp ne ptr %r26, null
  %r28 = and i1 %r20, %r25
  %r29 = and i1 %r28, %r27
  br i1 %r29, label %pic.token.26, label %pic.desc.classify.16

pic.token.26:                                     ; preds = %pic.recv_hdr.25
  %r31 = add nuw nsw i64 %r5, 4
  %r32 = inttoptr i64 %r31 to ptr
  %r33 = load i32, ptr %r32, align 4
  %r34 = zext i32 %r33 to i64
  %r35 = or i64 %r34, 4611686018427387904
  %r36 = icmp ne i32 %r33, 0
  %r37 = getelementptr i64, ptr %r26, i64 0
  %r38 = load i64, ptr %r37, align 8
  %r39 = icmp eq i64 %r35, %r38
  %r40 = and i1 %r39, %r36
  br i1 %r40, label %pic.hit.10, label %pic.prefix.guard.12

pic.hit.overflow.27:                              ; preds = %pic.hit.10
  %r45 = load double, ptr @test_json_large_string_emitters_ts_.str.17.handle, align 8
  %r46 = bitcast double %r45 to i64
  %r47 = and i64 %r46, 281474976710655
  %r48 = trunc i64 %r42 to i32
  %statepoint_token14 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r5, i64 %r47, i32 %r48, ptr @perry_ic_test_json_large_string_emitters_ts__17, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4) ]
  %r4915 = call double @llvm.experimental.gc.result.f64(token %statepoint_token14)
  %rs4gc.s4.relocated16 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token14, i32 0, i32 0) ; (%rs4gc.s4, %rs4gc.s4)
  br label %pic.merge.24

pic.hit.inline.28:                                ; preds = %pic.hit.10
  %r50 = shl i64 %r42, 3
  %r51 = add nuw nsw i64 %r5, 16
  %r52 = add i64 %r51, %r50
  %r53 = inttoptr i64 %r52 to ptr
  %r54 = load double, ptr %r53, align 8
  %r55 = bitcast double %r54 to i64
  %r56 = icmp eq i64 %r55, 9222246136947933200
  br i1 %r56, label %pic.miss.21, label %pic.hit.live.11

pic.ways.29:                                      ; preds = %pic.miss.21
  %r96 = getelementptr i64, ptr %r26, i64 4
  %r97 = load i64, ptr %r96, align 8
  %r98 = icmp eq i64 %r97, %r35
  %r99 = getelementptr i64, ptr %r26, i64 5
  %r100 = load i64, ptr %r99, align 8
  %r101 = select i1 %r98, i64 %r100, i64 0
  %r102 = getelementptr i64, ptr %r26, i64 6
  %r103 = load i64, ptr %r102, align 8
  %r104 = icmp eq i64 %r103, %r35
  %r105 = getelementptr i64, ptr %r26, i64 7
  %r106 = load i64, ptr %r105, align 8
  %r107 = select i1 %r104, i64 %r106, i64 0
  %r108 = getelementptr i64, ptr %r26, i64 8
  %r109 = load i64, ptr %r108, align 8
  %r110 = icmp eq i64 %r109, %r35
  %r111 = getelementptr i64, ptr %r26, i64 9
  %r112 = load i64, ptr %r111, align 8
  %r113 = select i1 %r110, i64 %r112, i64 0
  %r114 = getelementptr i64, ptr %r26, i64 10
  %r115 = load i64, ptr %r114, align 8
  %r116 = icmp eq i64 %r115, %r35
  %r117 = getelementptr i64, ptr %r26, i64 11
  %r118 = load i64, ptr %r117, align 8
  %r119 = select i1 %r116, i64 %r118, i64 0
  %r120 = or i1 %r98, %r104
  %r121 = select i1 %r98, i64 %r101, i64 %r107
  %r122 = or i1 %r110, %r116
  %r123 = select i1 %r110, i64 %r113, i64 %r119
  %r124 = or i1 %r120, %r122
  %r125 = select i1 %r120, i64 %r121, i64 %r123
  %r126 = and i1 %r36, %r124
  br i1 %r126, label %pic.way.load.30, label %pic.miss.call.23

pic.way.load.30:                                  ; preds = %pic.ways.29
  %r127 = shl i64 %r125, 3
  %r128 = add nuw nsw i64 %r5, 16
  %r129 = add i64 %r128, %r127
  %r130 = inttoptr i64 %r129 to ptr
  %r131 = load double, ptr %r130, align 8
  %r132 = bitcast double %r131 to i64
  %r133 = icmp eq i64 %r132, 9222246136947933200
  br i1 %r133, label %pic.miss.call.23, label %pic.way.live.31

pic.way.live.31:                                  ; preds = %pic.way.load.30
  br label %pic.merge.24

pget.throw_nullish.32:                            ; preds = %pget.recv_bad.3
  %r142 = zext i1 %r140 to i32
  %statepoint_token17 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r142, ptr @test_json_large_string_emitters_ts_.str.17.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.33:                        ; preds = %pget.recv_bad.3
  %r143 = load double, ptr @test_json_large_string_emitters_ts_.str.17.handle, align 8
  %r144 = bitcast double %r143 to i64
  %r145 = and i64 %r144, 281474976710655
  %statepoint_token18 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r4, i64 %r145, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4) ]
  %r14619 = call double @llvm.experimental.gc.result.f64(token %statepoint_token18)
  %rs4gc.s4.relocated20 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token18, i32 0, i32 0) ; (%rs4gc.s4, %rs4gc.s4)
  br label %pget.recv_merge.5

relnum.fast.34:                                   ; preds = %pget.recv_merge.5
  %r171 = trunc i64 %r156 to i32
  %r172 = sitofp i32 %r171 to double
  %r173 = select i1 %r161, double %r172, double %r155
  %r174 = select i1 %r166, double 0.000000e+00, double %r173
  %r175 = select i1 %r165, double 1.000000e+00, double %r174
  %r182 = fcmp ogt double %r175, 2.560000e+02
  %r183 = select i1 %r182, i64 9222246136947933188, i64 9222246136947933187
  %r184 = bitcast i64 %r183 to double
  br label %relnum.merge.36

relnum.slow.35:                                   ; preds = %pget.recv_merge.5
  %statepoint_token21 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_gt, i32 2, i32 0, double %r155, double 2.560000e+02, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r18522 = call double @llvm.experimental.gc.result.f64(token %statepoint_token21)
  %rs4gc.s4.relocated23 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token21, i32 0, i32 0) ; (%.0, %.0)
  br label %relnum.merge.36

relnum.merge.36:                                  ; preds = %relnum.slow.35, %relnum.fast.34
  %.2 = phi ptr addrspace(1) [ %.0, %relnum.fast.34 ], [ %rs4gc.s4.relocated23, %relnum.slow.35 ]
  %r186 = phi double [ %r184, %relnum.fast.34 ], [ %r18522, %relnum.slow.35 ]
  %r187 = bitcast double %r186 to i64
  %r188 = icmp eq i64 %r187, 9222246136947933188
  br i1 %r188, label %logical.then.37, label %logical.merge.38

logical.then.37:                                  ; preds = %relnum.merge.36
  %r189.rs4i = ptrtoint ptr addrspace(1) %.2 to i64
  %r189.rs4o = call i64 asm "", "=r,0"(i64 %r189.rs4i) #7
  %r189 = bitcast i64 %r189.rs4o to double
  %statepoint_token24 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (double)) @js_value_typeof_tag, i32 1, i32 0, double %r189, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r19025 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token24)
  %rs4gc.s4.relocated26 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token24, i32 0, i32 0) ; (%.2, %.2)
  %r191 = icmp eq i32 %r19025, 4
  %r192 = select i1 %r191, i64 9222246136947933188, i64 9222246136947933187
  %r193 = bitcast i64 %r192 to double
  %r194 = icmp eq i64 %r192, 9222246136947933188
  br label %logical.merge.38

logical.merge.38:                                 ; preds = %logical.then.37, %relnum.merge.36
  %.3 = phi ptr addrspace(1) [ %rs4gc.s4.relocated26, %logical.then.37 ], [ %.2, %relnum.merge.36 ]
  %r195 = phi double [ %r186, %relnum.merge.36 ], [ %r193, %logical.then.37 ]
  %r196 = phi i1 [ false, %relnum.merge.36 ], [ %r194, %logical.then.37 ]
  br i1 %r196, label %if.then.39, label %if.else.40

if.then.39:                                       ; preds = %logical.merge.38
  %statepoint_token27 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3) ]
  %r19828 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token27)
  %rs4gc.s4.relocated29 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token27, i32 0, i32 0) ; (%.3, %.3)
  %r199 = or i64 %r19828, 9222527611924643840
  %r200 = bitcast i64 %r199 to double
  %rs4gc.b5 = bitcast double %r200 to i64
  %rs4gc.s5 = inttoptr i64 %rs4gc.b5 to ptr addrspace(1)
  %r201.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s5 to i64
  %r201 = call i64 asm "", "=r,0"(i64 %r201.rs4i) #7
  %r202 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r203 = icmp ne i32 %r202, 0
  br i1 %r203, label %shadow.root.barrier.42, label %shadow.root.barrier.done.43

if.else.40:                                       ; preds = %logical.merge.38
  br label %if.merge.41

if.merge.41:                                      ; preds = %if.else.40
  %r837.rs4i = ptrtoint ptr addrspace(1) %.3 to i64
  %r837.rs4o = call i64 asm "", "=r,0"(i64 %r837.rs4i) #7
  %r837 = bitcast i64 %r837.rs4o to double
  ret double %r837

shadow.root.barrier.42:                           ; preds = %if.then.39
  call void @js_write_barrier_root_nanbox(i64 %r201) #7
  br label %shadow.root.barrier.done.43

shadow.root.barrier.done.43:                      ; preds = %shadow.root.barrier.42, %if.then.39
  %r204 = bitcast double %r200 to i64
  %r205 = and i64 %r204, 281474976710655
  call void @js_array_declare_all_pointer_elements(i64 %r205) #7
  br label %for.cond.44

for.cond.44:                                      ; preds = %for.update.46, %shadow.root.barrier.done.43
  %.4 = phi ptr addrspace(1) [ %rs4gc.s4.relocated29, %shadow.root.barrier.done.43 ], [ %.12, %for.update.46 ]
  %r240.0 = phi ptr [ null, %shadow.root.barrier.done.43 ], [ %r240.1, %for.update.46 ]
  %r206.0 = phi double [ 0.000000e+00, %shadow.root.barrier.done.43 ], [ %r427, %for.update.46 ]
  %r197.0.base = phi ptr addrspace(1) [ %rs4gc.s5, %shadow.root.barrier.done.43 ], [ %.0132, %for.update.46 ], !is_base_value !0
  %r197.0 = phi ptr addrspace(1) [ %rs4gc.s5, %shadow.root.barrier.done.43 ], [ %.0133, %for.update.46 ]
  %r208 = fcmp olt double %r206.0, 6.400000e+01
  %r209 = select i1 %r208, i64 9222246136947933188, i64 9222246136947933187
  %r210 = bitcast i64 %r209 to double
  %r211 = icmp eq i64 %r209, 9222246136947933188
  br i1 %r211, label %for.body.45, label %for.exit.47

for.body.45:                                      ; preds = %for.cond.44
  %r213 = load double, ptr @test_json_large_string_emitters_ts_.str.18.handle, align 8
  %r215 = fcmp oge double %r206.0, 0.000000e+00
  %r216 = fcmp olt double %r206.0, 3.200000e+01
  %r217 = and i1 %r215, %r216
  br i1 %r217, label %csite.chk.48, label %csite.plain.51

for.update.46:                                    ; preds = %gcpoll.done.89
  %r427 = fadd double %r206.0, 1.000000e+00
  br label %for.cond.44

for.exit.47:                                      ; preds = %for.cond.44
  %r429 = load double, ptr @test_json_large_string_emitters_ts_.str.19.handle, align 8
  %r430.rs4i = ptrtoint ptr addrspace(1) %r197.0 to i64
  %r430.rs4o = call i64 asm "", "=r,0"(i64 %r430.rs4i) #7
  %r430 = bitcast i64 %r430.rs4o to double
  %r431 = bitcast double %r430 to i64
  %r432 = and i64 %r431, 281474976710655
  %r433 = lshr i64 %r431, 48
  %r434 = icmp eq i64 %r433, 32765
  %r435 = icmp ugt i64 %r432, 1048575
  %r436 = and i1 %r434, %r435
  br i1 %r436, label %arr.guard.deref.94, label %arr.fallback.91

csite.chk.48:                                     ; preds = %for.body.45
  %r218 = fptosi double %r206.0 to i32
  %r219 = sitofp i32 %r218 to double
  %r220 = fcmp oeq double %r219, %r206.0
  %r221 = sext i32 %r218 to i64
  %r222 = getelementptr [32 x i64], ptr @perry_concat_site_test_json_large_string_emitters_ts__18, i64 0, i64 %r221
  %r223 = load i64, ptr %r222, align 8
  %r224 = icmp ne i64 %r223, 0
  %r225 = and i1 %r220, %r224
  br i1 %r225, label %csite.hit.49, label %csite.fill.50

csite.hit.49:                                     ; preds = %csite.chk.48
  %r226 = bitcast i64 %r223 to double
  br label %csite.merge.52

csite.fill.50:                                    ; preds = %csite.chk.48
  %r227 = bitcast double %r213 to i64
  %r228 = and i64 %r227, 281474976710655
  %statepoint_token30 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, double)) @js_string_concat_site_value, i32 3, i32 0, i64 ptrtoint (ptr @perry_concat_site_test_json_large_string_emitters_ts__18 to i64), i64 %r228, double %r206.0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %r197.0.base, ptr addrspace(1) %r197.0) ]
  %r23031 = call double @llvm.experimental.gc.result.f64(token %statepoint_token30)
  %rs4gc.s4.relocated32 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token30, i32 0, i32 0) ; (%.4, %.4)
  %r197.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token30, i32 1, i32 1) ; (%r197.0.base, %r197.0.base)
  %r197.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token30, i32 1, i32 2) ; (%r197.0.base, %r197.0)
  br label %csite.merge.52

csite.plain.51:                                   ; preds = %for.body.45
  %r231 = bitcast double %r213 to i64
  %r232 = and i64 %r231, 281474976710655
  %statepoint_token33 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r232, double %r206.0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %r197.0.base, ptr addrspace(1) %r197.0) ]
  %r23334 = call double @llvm.experimental.gc.result.f64(token %statepoint_token33)
  %rs4gc.s4.relocated35 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 0, i32 0) ; (%.4, %.4)
  %r197.0.base.relocated36 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 1, i32 1) ; (%r197.0.base, %r197.0.base)
  %r197.0.relocated37 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 1, i32 2) ; (%r197.0.base, %r197.0)
  br label %csite.merge.52

csite.merge.52:                                   ; preds = %csite.plain.51, %csite.fill.50, %csite.hit.49
  %.0122 = phi ptr addrspace(1) [ %r197.0, %csite.hit.49 ], [ %r197.0.relocated, %csite.fill.50 ], [ %r197.0.relocated37, %csite.plain.51 ]
  %.0116 = phi ptr addrspace(1) [ %r197.0.base, %csite.hit.49 ], [ %r197.0.base.relocated, %csite.fill.50 ], [ %r197.0.base.relocated36, %csite.plain.51 ]
  %.5 = phi ptr addrspace(1) [ %.4, %csite.hit.49 ], [ %rs4gc.s4.relocated32, %csite.fill.50 ], [ %rs4gc.s4.relocated35, %csite.plain.51 ]
  %r234 = phi double [ %r226, %csite.hit.49 ], [ %r23031, %csite.fill.50 ], [ %r23334, %csite.plain.51 ]
  %r235 = bitcast double %r234 to i64
  %rs4gc.s6 = inttoptr i64 %r235 to ptr addrspace(1)
  %r237.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r237 = call i64 asm "", "=r,0"(i64 %r237.rs4i) #7
  %r238 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r239 = icmp ne i32 %r238, 0
  br i1 %r239, label %shadow.root.barrier.53, label %shadow.root.barrier.done.54

shadow.root.barrier.53:                           ; preds = %csite.merge.52
  call void @js_write_barrier_root_nanbox(i64 %r237) #7
  br label %shadow.root.barrier.done.54

shadow.root.barrier.done.54:                      ; preds = %shadow.root.barrier.53, %csite.merge.52
  %r242 = icmp eq ptr %r240.0, null
  br i1 %r242, label %arena_state.init.55, label %arena_state.ready.56

arena_state.init.55:                              ; preds = %shadow.root.barrier.done.54
  %r243 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r244 = icmp ne i64 %r243, -1
  br i1 %r244, label %arena_state.hot_tls.tsd.57, label %arena_state.hot_tls.slow.59

arena_state.ready.56:                             ; preds = %arena_state.hot_tls.resolved.61, %shadow.root.barrier.done.54
  %.0128 = phi ptr addrspace(1) [ %.1129, %arena_state.hot_tls.resolved.61 ], [ %rs4gc.s6, %shadow.root.barrier.done.54 ]
  %.1123 = phi ptr addrspace(1) [ %.2124, %arena_state.hot_tls.resolved.61 ], [ %.0122, %shadow.root.barrier.done.54 ]
  %.1117 = phi ptr addrspace(1) [ %.2118, %arena_state.hot_tls.resolved.61 ], [ %.0116, %shadow.root.barrier.done.54 ]
  %.6 = phi ptr addrspace(1) [ %.7, %arena_state.hot_tls.resolved.61 ], [ %.5, %shadow.root.barrier.done.54 ]
  %r240.1 = phi ptr [ %r240.2, %arena_state.hot_tls.resolved.61 ], [ %r240.0, %shadow.root.barrier.done.54 ]
  %r258 = phi ptr [ %r240.0, %shadow.root.barrier.done.54 ], [ %r257, %arena_state.hot_tls.resolved.61 ]
  %r259 = getelementptr i8, ptr %r258, i64 8
  %r260 = load i64, ptr %r259, align 8
  %r261 = add i64 %r260, 40
  %r262 = getelementptr i8, ptr %r258, i64 16
  %r263 = load i64, ptr %r262, align 8
  %r264 = icmp ule i64 %r261, %r263
  br i1 %r264, label %alloc.fast.62, label %alloc.slow.63

arena_state.hot_tls.tsd.57:                       ; preds = %arena_state.init.55
  %r245 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #7
  %r246 = and i64 %r245, -8
  %r247 = shl i64 %r243, 3
  %r248 = add i64 %r246, %r247
  %r249 = inttoptr i64 %r248 to ptr
  %r250 = load ptr, ptr %r249, align 8
  %r251 = icmp ne ptr %r250, null
  br i1 %r251, label %arena_state.hot_tls.fast.58, label %arena_state.hot_tls.slow.59

arena_state.hot_tls.fast.58:                      ; preds = %arena_state.hot_tls.tsd.57
  %r252 = getelementptr i8, ptr %r250, i64 8
  %r253 = load ptr, ptr %r252, align 8
  %r254 = load ptr, ptr %r253, align 8
  %r255 = icmp ne ptr %r254, null
  br i1 %r255, label %arena_state.hot_tls.ready.60, label %arena_state.hot_tls.slow.59

arena_state.hot_tls.slow.59:                      ; preds = %arena_state.hot_tls.fast.58, %arena_state.hot_tls.tsd.57, %arena_state.init.55
  %statepoint_token38 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5, ptr addrspace(1) %.0116, ptr addrspace(1) %.0122, ptr addrspace(1) %rs4gc.s6) ]
  %r25639 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token38)
  %rs4gc.s4.relocated40 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 0, i32 0) ; (%.5, %.5)
  %r197.0.base.relocated41 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 1, i32 1) ; (%.0116, %.0116)
  %r197.0.relocated42 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 1, i32 2) ; (%.0116, %.0122)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 3, i32 3) ; (%rs4gc.s6, %rs4gc.s6)
  br label %arena_state.hot_tls.resolved.61

arena_state.hot_tls.ready.60:                     ; preds = %arena_state.hot_tls.fast.58
  br label %arena_state.hot_tls.resolved.61

arena_state.hot_tls.resolved.61:                  ; preds = %arena_state.hot_tls.ready.60, %arena_state.hot_tls.slow.59
  %.1129 = phi ptr addrspace(1) [ %rs4gc.s6, %arena_state.hot_tls.ready.60 ], [ %rs4gc.s6.relocated, %arena_state.hot_tls.slow.59 ]
  %.2124 = phi ptr addrspace(1) [ %.0122, %arena_state.hot_tls.ready.60 ], [ %r197.0.relocated42, %arena_state.hot_tls.slow.59 ]
  %.2118 = phi ptr addrspace(1) [ %.0116, %arena_state.hot_tls.ready.60 ], [ %r197.0.base.relocated41, %arena_state.hot_tls.slow.59 ]
  %.7 = phi ptr addrspace(1) [ %.5, %arena_state.hot_tls.ready.60 ], [ %rs4gc.s4.relocated40, %arena_state.hot_tls.slow.59 ]
  %r240.2 = phi ptr [ %r253, %arena_state.hot_tls.ready.60 ], [ %r25639, %arena_state.hot_tls.slow.59 ]
  %r257 = phi ptr [ %r253, %arena_state.hot_tls.ready.60 ], [ %r25639, %arena_state.hot_tls.slow.59 ]
  br label %arena_state.ready.56

alloc.fast.62:                                    ; preds = %arena_state.ready.56
  store i64 %r261, ptr %r259, align 8
  %r265 = load ptr, ptr %r258, align 8
  %r266 = getelementptr i8, ptr %r265, i64 %r260
  br label %alloc.merge.64

alloc.slow.63:                                    ; preds = %arena_state.ready.56
  %statepoint_token43 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r258, i64 40, i64 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6, ptr addrspace(1) %.1117, ptr addrspace(1) %.1123, ptr addrspace(1) %.0128) ]
  %r26744 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token43)
  %rs4gc.s4.relocated45 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token43, i32 0, i32 0) ; (%.6, %.6)
  %r197.0.base.relocated46 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token43, i32 1, i32 1) ; (%.1117, %.1117)
  %r197.0.relocated47 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token43, i32 1, i32 2) ; (%.1117, %.1123)
  %rs4gc.s6.relocated48 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token43, i32 3, i32 3) ; (%.0128, %.0128)
  br label %alloc.merge.64

alloc.merge.64:                                   ; preds = %alloc.slow.63, %alloc.fast.62
  %.2130 = phi ptr addrspace(1) [ %.0128, %alloc.fast.62 ], [ %rs4gc.s6.relocated48, %alloc.slow.63 ]
  %.3125 = phi ptr addrspace(1) [ %.1123, %alloc.fast.62 ], [ %r197.0.relocated47, %alloc.slow.63 ]
  %.3119 = phi ptr addrspace(1) [ %.1117, %alloc.fast.62 ], [ %r197.0.base.relocated46, %alloc.slow.63 ]
  %.8 = phi ptr addrspace(1) [ %.6, %alloc.fast.62 ], [ %rs4gc.s4.relocated45, %alloc.slow.63 ]
  %r268 = phi ptr [ %r266, %alloc.fast.62 ], [ %r26744, %alloc.slow.63 ]
  store <2 x i64> %r270, ptr %r268, align 8
  %r272 = getelementptr i8, ptr %r268, i64 16
  store i64 0, ptr %r272, align 8
  %r273 = getelementptr i8, ptr %r268, i64 24
  store i64 9222246136947933185, ptr %r273, align 8
  %r274 = getelementptr i8, ptr %r268, i64 32
  store i64 9222246136947933185, ptr %r274, align 8
  %r275 = getelementptr i8, ptr %r268, i64 8
  %r276 = ptrtoint ptr %r275 to i64
  %r277 = load atomic i32, ptr @PERRY_PER_OBJECT_LAYOUTS_ANY monotonic, align 4
  %r278 = icmp ne i32 %r277, 0
  br i1 %r278, label %layout_forget.young.65, label %layout_forget.done.68

layout_forget.young.65:                           ; preds = %alloc.merge.64
  %r279 = load atomic i32, ptr @PERRY_YOUNG_LAYOUT_RECORDS monotonic, align 4
  %r280 = icmp ne i32 %r279, 0
  br i1 %r280, label %layout_forget.sketch.66, label %layout_forget.done.68

layout_forget.sketch.66:                          ; preds = %layout_forget.young.65
  %r281 = mul i64 %r276, -7046029254386353131
  %r282 = lshr i64 %r281, 52
  %r283 = lshr i64 %r282, 6
  %r284 = and i64 %r282, 63
  %r285 = shl nuw i64 1, %r284
  %r286 = getelementptr i64, ptr @PERRY_LAYOUT_ADDR_FILTER, i64 %r283
  %r287 = load atomic i64, ptr %r286 monotonic, align 8
  %r288 = and i64 %r287, %r285
  %r289 = icmp ne i64 %r288, 0
  br i1 %r289, label %layout_forget.armed.67, label %layout_forget.done.68

layout_forget.armed.67:                           ; preds = %layout_forget.sketch.66
  call void @js_gc_forget_object_layout(i64 %r276) #7
  br label %layout_forget.done.68

layout_forget.done.68:                            ; preds = %layout_forget.armed.67, %layout_forget.sketch.66, %layout_forget.young.65, %alloc.merge.64
  %rs4gc.s7 = inttoptr i64 %r276 to ptr addrspace(1)
  %r291.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r291 = call i64 asm "", "=r,0"(i64 %r291.rs4i) #7
  %r292 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r293 = icmp ne i32 %r292, 0
  br i1 %r293, label %shadow.root.barrier.69, label %shadow.root.barrier.done.70

shadow.root.barrier.69:                           ; preds = %layout_forget.done.68
  call void @js_write_barrier_root_nanbox(i64 %r291) #7
  br label %shadow.root.barrier.done.70

shadow.root.barrier.done.70:                      ; preds = %shadow.root.barrier.69, %layout_forget.done.68
  %r294 = or i64 %r276, 9222527611924643840
  %r295 = bitcast i64 %r294 to double
  %r296.rs4i = ptrtoint ptr addrspace(1) %.2130 to i64
  %r296 = call i64 asm "", "=r,0"(i64 %r296.rs4i) #7
  %r297 = bitcast i64 %r296 to double
  %r298 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r299 = icmp eq i8 %r298, 0
  %r300 = bitcast double %r206.0 to i64
  %r301 = and i64 %r300, 9218868437227405312
  %r302 = icmp ne i64 %r301, 9218868437227405312
  %r303 = and i1 %r299, %r302
  br i1 %r303, label %ctor_prologue.fast.71, label %ctor_prologue.slow.72

ctor_prologue.fast.71:                            ; preds = %shadow.root.barrier.done.70
  %r304 = inttoptr i64 %r276 to ptr
  %r305 = getelementptr i8, ptr %r304, i64 16
  %r306 = bitcast double %r295 to i64
  %r307 = getelementptr double, ptr %r305, i64 0
  store double %r206.0, ptr %r307, align 8
  %r308 = ptrtoint ptr %r307 to i64
  %r309 = bitcast double %r206.0 to i64
  %r310 = getelementptr double, ptr %r305, i64 1
  store double %r297, ptr %r310, align 8
  %r311 = ptrtoint ptr %r310 to i64
  %r312 = bitcast double %r297 to i64
  %r313 = lshr i64 %r312, 48
  %r314 = icmp eq i64 %r313, 0
  %r315 = icmp uge i64 %r312, 4096
  %r316 = and i1 %r314, %r315
  %r317 = icmp eq i64 %r313, 32765
  %r318 = icmp eq i64 %r313, 32767
  %r319 = icmp eq i64 %r313, 32762
  %r320 = or i1 %r317, %r318
  %r321 = or i1 %r320, %r319
  %r322 = or i1 %r321, %r316
  br i1 %r322, label %ctor_prologue.barrier.maybe.74, label %ctor_prologue.barrier.done.76

ctor_prologue.slow.72:                            ; preds = %shadow.root.barrier.done.70
  %statepoint_token49 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double)) @test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c_constructor, i32 3, i32 0, double %r295, double %r206.0, double %r297, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8, ptr addrspace(1) %.3119, ptr addrspace(1) %.3125, ptr addrspace(1) %rs4gc.s7) ]
  %r33150 = call double @llvm.experimental.gc.result.f64(token %statepoint_token49)
  %rs4gc.s4.relocated51 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token49, i32 0, i32 0) ; (%.8, %.8)
  %r197.0.base.relocated52 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token49, i32 1, i32 1) ; (%.3119, %.3119)
  %r197.0.relocated53 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token49, i32 1, i32 2) ; (%.3119, %.3125)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token49, i32 3, i32 3) ; (%rs4gc.s7, %rs4gc.s7)
  br label %ctor_prologue.merge.73

ctor_prologue.merge.73:                           ; preds = %ctor_prologue.barrier.done.76, %ctor_prologue.slow.72
  %.0131 = phi ptr addrspace(1) [ %rs4gc.s7, %ctor_prologue.barrier.done.76 ], [ %rs4gc.s7.relocated, %ctor_prologue.slow.72 ]
  %.4126 = phi ptr addrspace(1) [ %.3125, %ctor_prologue.barrier.done.76 ], [ %r197.0.relocated53, %ctor_prologue.slow.72 ]
  %.4120 = phi ptr addrspace(1) [ %.3119, %ctor_prologue.barrier.done.76 ], [ %r197.0.base.relocated52, %ctor_prologue.slow.72 ]
  %.9 = phi ptr addrspace(1) [ %.8, %ctor_prologue.barrier.done.76 ], [ %rs4gc.s4.relocated51, %ctor_prologue.slow.72 ]
  %r332 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.76 ], [ %r33150, %ctor_prologue.slow.72 ]
  %r333.rs4i = ptrtoint ptr addrspace(1) %.0131 to i64
  %r333 = call i64 asm "", "=r,0"(i64 %r333.rs4i) #7
  %r334 = or i64 %r333, 9222527611924643840
  %r335 = bitcast i64 %r334 to double
  %r336 = bitcast double %r332 to i64
  %r337 = icmp eq i64 %r336, 9222246136947933185
  br i1 %r337, label %ctor_ret.merge.78, label %ctor_ret.override.77

ctor_prologue.barrier.maybe.74:                   ; preds = %ctor_prologue.fast.71
  %r323 = sub i64 %r276, 7
  %r324 = inttoptr i64 %r323 to ptr
  %r325 = load i8, ptr %r324, align 1
  %r326 = and i8 %r325, 32
  %r327 = icmp ne i8 %r326, 0
  %r328 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r329 = icmp ne i32 %r328, 0
  %r330 = or i1 %r327, %r329
  br i1 %r330, label %ctor_prologue.barrier.75, label %ctor_prologue.barrier.done.76

ctor_prologue.barrier.75:                         ; preds = %ctor_prologue.barrier.maybe.74
  call void @js_write_barrier_slot_validated_parent(i64 %r276, i64 %r311, i64 %r312) #7
  br label %ctor_prologue.barrier.done.76

ctor_prologue.barrier.done.76:                    ; preds = %ctor_prologue.barrier.75, %ctor_prologue.barrier.maybe.74, %ctor_prologue.fast.71
  br label %ctor_prologue.merge.73

ctor_ret.override.77:                             ; preds = %ctor_prologue.merge.73
  %statepoint_token54 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r335, double %r332, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9, ptr addrspace(1) %.4120, ptr addrspace(1) %.4126) ]
  %r33855 = call double @llvm.experimental.gc.result.f64(token %statepoint_token54)
  %rs4gc.s4.relocated56 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 0, i32 0) ; (%.9, %.9)
  %r197.0.base.relocated57 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 1, i32 1) ; (%.4120, %.4120)
  %r197.0.relocated58 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 1, i32 2) ; (%.4120, %.4126)
  br label %ctor_ret.merge.78

ctor_ret.merge.78:                                ; preds = %ctor_ret.override.77, %ctor_prologue.merge.73
  %.5127 = phi ptr addrspace(1) [ %.4126, %ctor_prologue.merge.73 ], [ %r197.0.relocated58, %ctor_ret.override.77 ]
  %.5121 = phi ptr addrspace(1) [ %.4120, %ctor_prologue.merge.73 ], [ %r197.0.base.relocated57, %ctor_ret.override.77 ]
  %.10 = phi ptr addrspace(1) [ %.9, %ctor_prologue.merge.73 ], [ %rs4gc.s4.relocated56, %ctor_ret.override.77 ]
  %r339 = phi double [ %r335, %ctor_prologue.merge.73 ], [ %r33855, %ctor_ret.override.77 ]
  %r340 = bitcast double %r339 to i64
  %r341.rs4i = ptrtoint ptr addrspace(1) %.5127 to i64
  %r341.rs4o = call i64 asm "", "=r,0"(i64 %r341.rs4i) #7
  %r341 = bitcast i64 %r341.rs4o to double
  %r342 = bitcast double %r341 to i64
  %r343 = and i64 %r342, 281474976710655
  %r344 = sub nsw i64 %r343, 8
  %r345 = inttoptr i64 %r344 to ptr
  %r346 = load i8, ptr %r345, align 1
  %r347 = icmp ne i8 %r346, 1
  %r348 = sub nsw i64 %r343, 7
  %r349 = inttoptr i64 %r348 to ptr
  %r350 = load i8, ptr %r349, align 1
  %r351 = and i8 %r350, -128
  %r352 = icmp ne i8 %r351, 0
  %r353 = or i1 %r347, %r352
  br i1 %r352, label %apush.fwd.79, label %apush.elements.80

apush.fwd.79:                                     ; preds = %apush.elements.check.81, %ctor_ret.merge.78
  %statepoint_token59 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r343, double %r339, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10) ]
  %r38060 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token59)
  %rs4gc.s4.relocated61 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 0, i32 0) ; (%.10, %.10)
  %r381 = or i64 %r38060, 9222527611924643840
  %r382 = bitcast i64 %r381 to double
  %rs4gc.b8 = bitcast double %r382 to i64
  %rs4gc.s8 = inttoptr i64 %rs4gc.b8 to ptr addrspace(1)
  br label %apush.merge.85

apush.elements.80:                                ; preds = %ctor_ret.merge.78
  %r355 = add nuw nsw i64 %r343, 8
  %r356 = inttoptr i64 %r355 to ptr
  %r357 = load i64, ptr %r356, align 8
  %r358 = icmp ne i64 %r357, 0
  %r359 = icmp eq i8 %r346, 2
  %r360 = and i1 %r359, %r358
  %r361 = select i1 %r360, i64 %r357, i64 %r343
  %r362 = inttoptr i64 %r361 to ptr
  %r363 = getelementptr i64, ptr %r362, i64 12
  %r364 = load i64, ptr %r363, align 8
  %r365 = icmp ne i64 %r364, 0
  %r366 = and i1 %r360, %r365
  %r367 = select i1 %r366, i64 %r364, i64 %r343
  %r354 = icmp eq i8 %r346, 1
  br i1 %r354, label %apush.nofwd.82, label %apush.elements.check.81

apush.elements.check.81:                          ; preds = %apush.elements.80
  %r368 = icmp ne i64 %r367, 0
  %r369 = sub i64 %r367, 8
  %r370 = inttoptr i64 %r369 to ptr
  %r371 = load i8, ptr %r370, align 1
  %r372 = icmp eq i8 %r371, 1
  %r373 = sub i64 %r367, 7
  %r374 = inttoptr i64 %r373 to ptr
  %r375 = load i8, ptr %r374, align 1
  %r376 = and i8 %r375, -128
  %r377 = icmp eq i8 %r376, 0
  %r378 = and i1 %r368, %r372
  %r379 = and i1 %r378, %r377
  br i1 %r379, label %apush.nofwd.82, label %apush.fwd.79

apush.nofwd.82:                                   ; preds = %apush.elements.check.81, %apush.elements.80
  %r383 = phi i64 [ %r343, %apush.elements.80 ], [ %r367, %apush.elements.check.81 ]
  %r384 = sub i64 %r383, 6
  %r385 = inttoptr i64 %r384 to ptr
  %r386 = load i16, ptr %r385, align 2
  %r387 = and i16 %r386, -2937
  %r388 = icmp eq i16 %r387, -24576
  %r389 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r390 = icmp eq i8 %r389, 0
  %r391 = and i1 %r388, %r390
  %r392 = icmp ult i64 %r383, 4096
  %r393 = inttoptr i64 %r383 to ptr
  %r394 = select i1 %r392, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r393
  %r395 = load i32, ptr %r394, align 4
  %r396 = add i64 %r383, 4
  %r397 = inttoptr i64 %r396 to ptr
  %r398 = load i32, ptr %r397, align 4
  %r399 = icmp ult i32 %r395, %r398
  %r400 = and i1 %r399, %r391
  br i1 %r400, label %apush.inbounds.83, label %apush.realloc.84

apush.inbounds.83:                                ; preds = %apush.nofwd.82
  %r401 = icmp ult i64 %r383, 4096
  %r402 = inttoptr i64 %r383 to ptr
  %r403 = select i1 %r401, ptr @perry_null_guard_zero_test_json_large_string_emitters_ts, ptr %r402
  %r404 = load i32, ptr %r403, align 4
  %r405 = zext i32 %r404 to i64
  %r406 = shl nuw nsw i64 %r405, 3
  %r407 = add nuw nsw i64 %r406, 8
  %r408 = add i64 %r383, %r407
  %r409 = inttoptr i64 %r408 to ptr
  store double %r339, ptr %r409, align 8
  call void @js_string_addref_if_heap_string(double %r339) #7
  %r410 = bitcast double %r339 to i64
  %r411 = sub i64 %r383, 7
  %r412 = inttoptr i64 %r411 to ptr
  %r413 = load i8, ptr %r412, align 1
  %r414 = and i8 %r413, 32
  %r415 = icmp ne i8 %r414, 0
  %r416 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r417 = icmp ne i32 %r416, 0
  %r418 = or i1 %r415, %r417
  br i1 %r418, label %apush.barrier.86, label %apush.barrier.done.87

apush.realloc.84:                                 ; preds = %apush.nofwd.82
  %statepoint_token62 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r343, double %r339, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10) ]
  %r42163 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token62)
  %rs4gc.s4.relocated64 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token62, i32 0, i32 0) ; (%.10, %.10)
  %r422 = or i64 %r42163, 9222527611924643840
  %r423 = bitcast i64 %r422 to double
  %rs4gc.b9 = bitcast double %r423 to i64
  %rs4gc.s9 = inttoptr i64 %rs4gc.b9 to ptr addrspace(1)
  br label %apush.merge.85

apush.merge.85:                                   ; preds = %apush.barrier.done.87, %apush.realloc.84, %apush.fwd.79
  %.11 = phi ptr addrspace(1) [ %rs4gc.s4.relocated61, %apush.fwd.79 ], [ %.10, %apush.barrier.done.87 ], [ %rs4gc.s4.relocated64, %apush.realloc.84 ]
  %r197.1.base = phi ptr addrspace(1) [ %rs4gc.s8, %apush.fwd.79 ], [ %.5121, %apush.barrier.done.87 ], [ %rs4gc.s9, %apush.realloc.84 ], !is_base_value !0
  %r197.1 = phi ptr addrspace(1) [ %rs4gc.s8, %apush.fwd.79 ], [ %.5127, %apush.barrier.done.87 ], [ %rs4gc.s9, %apush.realloc.84 ]
  %r424 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r425 = icmp ne i32 %r424, 0
  br i1 %r425, label %gcpoll.88, label %gcpoll.done.89

apush.barrier.86:                                 ; preds = %apush.inbounds.83
  call void @js_write_barrier_slot_validated_parent(i64 %r383, i64 %r408, i64 %r410) #7
  br label %apush.barrier.done.87

apush.barrier.done.87:                            ; preds = %apush.barrier.86, %apush.inbounds.83
  %r419 = add i32 %r404, 1
  %r420 = inttoptr i64 %r383 to ptr
  store i32 %r419, ptr %r420, align 4
  br label %apush.merge.85

gcpoll.88:                                        ; preds = %apush.merge.85
  %statepoint_token65 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r197.1.base, ptr addrspace(1) %r197.1, ptr addrspace(1) %.11) ]
  %r197.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token65, i32 0, i32 0) ; (%r197.1.base, %r197.1.base)
  %r197.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token65, i32 0, i32 1) ; (%r197.1.base, %r197.1)
  %rs4gc.s4.relocated66 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token65, i32 2, i32 2) ; (%.11, %.11)
  br label %gcpoll.done.89

gcpoll.done.89:                                   ; preds = %gcpoll.88, %apush.merge.85
  %.0133 = phi ptr addrspace(1) [ %r197.1.relocated, %gcpoll.88 ], [ %r197.1, %apush.merge.85 ]
  %.0132 = phi ptr addrspace(1) [ %r197.1.base.relocated, %gcpoll.88 ], [ %r197.1.base, %apush.merge.85 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s4.relocated66, %gcpoll.88 ], [ %.11, %apush.merge.85 ]
  br label %for.update.46

arr.fast.90:                                      ; preds = %arr.guard.range.96
  %r495 = add i64 %r451, 512
  %r496 = inttoptr i64 %r495 to ptr
  %r497 = load double, ptr %r496, align 8
  %r498 = bitcast double %r497 to i64
  %r499 = icmp eq i64 %r498, 9222246136947933200
  %r501 = select i1 %r499, double 0x7FFC000000000001, double %r497
  br label %arr.merge.93

arr.fallback.91:                                  ; preds = %arr.guard.live.95, %arr.guard.deref.94, %for.exit.47
  %statepoint_token67 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7058970246387859475, double %r430, double 6.300000e+01, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4) ]
  %r49168 = call double @llvm.experimental.gc.result.f64(token %statepoint_token67)
  %rs4gc.s4.relocated69 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token67, i32 0, i32 0) ; (%.4, %.4)
  br label %arr.merge.93

arr.guard.oob.92:                                 ; preds = %arr.guard.range.96
  br label %arr.merge.93

arr.merge.93:                                     ; preds = %arr.guard.oob.92, %arr.fallback.91, %arr.fast.90
  %.13 = phi ptr addrspace(1) [ %.4, %arr.fast.90 ], [ %.4, %arr.guard.oob.92 ], [ %rs4gc.s4.relocated69, %arr.fallback.91 ]
  %r502 = phi double [ %r501, %arr.fast.90 ], [ %r49168, %arr.fallback.91 ], [ 0x7FFC000000000001, %arr.guard.oob.92 ]
  %r503 = bitcast double %r502 to i64
  %r504 = and i64 %r503, 281474976710655
  %r505 = lshr i64 %r503, 48
  %r506 = and i64 %r505, 65533
  %r507 = icmp eq i64 %r506, 32765
  br i1 %r507, label %pget.recv_ok.98, label %pget.recv_other.102

arr.guard.deref.94:                               ; preds = %for.exit.47
  %r437 = bitcast double %r430 to i64
  %r438 = and i64 %r437, 281474976710655
  %r439 = sub nsw i64 %r438, 8
  %r440 = inttoptr i64 %r439 to ptr
  %r441 = load i8, ptr %r440, align 1
  %r442 = icmp eq i8 %r441, 1
  %r443 = sub nsw i64 %r438, 7
  %r444 = inttoptr i64 %r443 to ptr
  %r445 = load i8, ptr %r444, align 1
  %r446 = and i8 %r445, -128
  %r447 = icmp ne i8 %r446, 0
  %r448 = inttoptr i64 %r438 to ptr
  %r449 = load i64, ptr %r448, align 8
  %r450 = and i1 %r442, %r447
  %r451 = select i1 %r450, i64 %r449, i64 %r438
  %r452 = lshr i64 %r451, 48
  %r453 = icmp eq i64 %r452, 0
  %r454 = icmp ugt i64 %r451, 1048575
  %r455 = and i1 %r453, %r454
  br i1 %r455, label %arr.guard.live.95, label %arr.fallback.91

arr.guard.live.95:                                ; preds = %arr.guard.deref.94
  %r456 = sub nuw i64 %r451, 8
  %r457 = inttoptr i64 %r456 to ptr
  %r458 = load i8, ptr %r457, align 1
  %r459 = icmp eq i8 %r458, 1
  %r460 = sub nuw i64 %r451, 7
  %r461 = inttoptr i64 %r460 to ptr
  %r462 = load i8, ptr %r461, align 1
  %r463 = and i8 %r462, -128
  %r464 = icmp eq i8 %r463, 0
  %r465 = sub nuw i64 %r451, 6
  %r466 = inttoptr i64 %r465 to ptr
  %r467 = load i16, ptr %r466, align 2
  %r468 = and i16 %r467, 1024
  %r469 = icmp eq i16 %r468, 0
  %r470 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r471 = icmp eq i8 %r470, 0
  %r472 = inttoptr i64 %r451 to ptr
  %r473 = load i32, ptr %r472, align 4
  %r474 = getelementptr i8, ptr %r472, i64 4
  %r475 = load i32, ptr %r474, align 4
  %r479 = icmp ule i32 %r473, 16000000
  %r480 = icmp ule i32 %r475, 16000000
  %r481 = icmp ule i32 %r473, %r475
  %r482 = and i1 %r459, %r464
  %r483 = and i1 %r482, %r469
  %r484 = and i1 %r483, %r471
  %r486 = and i1 %r484, %r479
  %r487 = and i1 %r486, %r480
  %r488 = and i1 %r487, %r481
  br i1 %r488, label %arr.guard.range.96, label %arr.fallback.91

arr.guard.range.96:                               ; preds = %arr.guard.live.95
  %r478 = icmp ult i32 63, %r473
  br i1 %r478, label %arr.fast.90, label %arr.guard.oob.92

pget.recv_sso.97:                                 ; preds = %pget.recv_other.102
  %r645 = load double, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  %r646 = bitcast double %r645 to i64
  %r647 = and i64 %r646, 281474976710655
  %statepoint_token70 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r503, i64 %r647, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %r64871 = call double @llvm.experimental.gc.result.f64(token %statepoint_token70)
  %rs4gc.s4.relocated72 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token70, i32 0, i32 0) ; (%.13, %.13)
  br label %pget.recv_merge.101

pget.recv_ok.98:                                  ; preds = %arr.merge.93
  %r514 = icmp ugt i64 %r504, 1048575
  br i1 %r514, label %pic.recv_hdr.119, label %pic.miss.cold.116

pget.recv_bad.99:                                 ; preds = %pget.check_class_ref.103
  %r637 = icmp eq i64 %r503, 9222246136947933185
  %r638 = icmp eq i64 %r503, 9222246136947933186
  %r639 = or i1 %r637, %r638
  br i1 %r639, label %pget.throw_nullish.126, label %pget.recv_undef_return.127

pget.recv_class_ref.100:                          ; preds = %pget.check_class_ref.103
  %r510 = load double, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  %r511 = bitcast double %r510 to i64
  %r512 = and i64 %r511, 281474976710655
  %statepoint_token73 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7058970246387859476, i64 %r503, i64 %r512, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %r51374 = call double @llvm.experimental.gc.result.f64(token %statepoint_token73)
  %rs4gc.s4.relocated75 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 0, i32 0) ; (%.13, %.13)
  br label %pget.recv_merge.101

pget.recv_merge.101:                              ; preds = %pget.recv_undef_return.127, %pic.merge.118, %pget.recv_class_ref.100, %pget.recv_sso.97
  %.14 = phi ptr addrspace(1) [ %.15, %pic.merge.118 ], [ %rs4gc.s4.relocated72, %pget.recv_sso.97 ], [ %rs4gc.s4.relocated75, %pget.recv_class_ref.100 ], [ %rs4gc.s4.relocated94, %pget.recv_undef_return.127 ]
  %r649 = phi double [ %r636, %pic.merge.118 ], [ %r64493, %pget.recv_undef_return.127 ], [ %r64871, %pget.recv_sso.97 ], [ %r51374, %pget.recv_class_ref.100 ]
  %r650 = load double, ptr @test_json_large_string_emitters_ts_.str.21.handle, align 8
  %r651 = load double, ptr @test_json_large_string_emitters_ts_.str.19.handle, align 8
  %r653 = getelementptr double, ptr %r652, i64 0
  store double %r651, ptr %r653, align 8
  %r654 = getelementptr double, ptr %r652, i64 1
  store double %r649, ptr %r654, align 8
  %r655 = getelementptr double, ptr %r652, i64 2
  store double %r650, ptr %r655, align 8
  %r656 = ptrtoint ptr %r652 to i64
  %statepoint_token76 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r656, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.14) ]
  %r65777 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token76)
  %rs4gc.s4.relocated78 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token76, i32 0, i32 0) ; (%.14, %.14)
  %r658 = or i64 %r65777, 9223090561878065152
  %r659 = bitcast i64 %r658 to double
  %statepoint_token79 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r659, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated78) ]
  %r66080 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token79)
  %rs4gc.s4.relocated81 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token79, i32 0, i32 0) ; (%rs4gc.s4.relocated78, %rs4gc.s4.relocated78)
  %statepoint_token82 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r66080, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated81) ]
  %r66183 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token82)
  %rs4gc.s4.relocated84 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token82, i32 0, i32 0) ; (%rs4gc.s4.relocated81, %rs4gc.s4.relocated81)
  %r662 = bitcast i64 %r66183 to double
  %rs4gc.b10 = bitcast double %r662 to i64
  %rs4gc.s10 = inttoptr i64 %rs4gc.b10 to ptr addrspace(1)
  %r663.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r663 = call i64 asm "", "=r,0"(i64 %r663.rs4i) #7
  %r664 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r665 = icmp ne i32 %r664, 0
  br i1 %r665, label %shadow.root.barrier.128, label %shadow.root.barrier.done.129

pget.recv_other.102:                              ; preds = %arr.merge.93
  %r508 = icmp eq i64 %r505, 32761
  br i1 %r508, label %pget.recv_sso.97, label %pget.check_class_ref.103

pget.check_class_ref.103:                         ; preds = %pget.recv_other.102
  %r509 = icmp eq i64 %r505, 32766
  br i1 %r509, label %pget.recv_class_ref.100, label %pget.recv_bad.99

pic.hit.104:                                      ; preds = %pic.token.120
  %r539 = getelementptr i64, ptr %r524, i64 1
  %r540 = load i64, ptr %r539, align 8
  %r541 = and i64 %r540, 1073741824
  %r542 = icmp ne i64 %r541, 0
  br i1 %r542, label %pic.hit.overflow.121, label %pic.hit.inline.122

pic.hit.live.105:                                 ; preds = %pic.hit.inline.122
  br label %pic.merge.118

pic.prefix.guard.106:                             ; preds = %pic.token.120
  %r555 = getelementptr i64, ptr %r524, i64 2
  %r556 = load i64, ptr %r555, align 8
  %r557 = icmp ne i64 %r556, 0
  br i1 %r557, label %pic.prefix.meta.107, label %pic.miss.115

pic.prefix.meta.107:                              ; preds = %pic.prefix.guard.106
  %r558 = add nuw nsw i64 %r504, 8
  %r559 = inttoptr i64 %r558 to ptr
  %r560 = load i64, ptr %r559, align 8
  %r561 = icmp ne i64 %r560, 0
  br i1 %r561, label %pic.prefix.token.108, label %pic.miss.115

pic.prefix.token.108:                             ; preds = %pic.prefix.meta.107
  %r562 = inttoptr i64 %r560 to ptr
  %r563 = getelementptr i64, ptr %r562, i64 6
  %r564 = load i64, ptr %r563, align 8
  %r565 = icmp eq i64 %r564, %r556
  br i1 %r565, label %pic.prefix.hit.109, label %pic.miss.115

pic.prefix.hit.109:                               ; preds = %pic.prefix.token.108
  %r566 = getelementptr i64, ptr %r524, i64 1
  %r567 = load i64, ptr %r566, align 8
  %r568 = shl i64 %r567, 3
  %r569 = add nuw nsw i64 %r504, 16
  %r570 = add i64 %r569, %r568
  %r571 = inttoptr i64 %r570 to ptr
  %r572 = load double, ptr %r571, align 8
  br label %pic.merge.118

pic.desc.classify.110:                            ; preds = %pic.recv_hdr.119
  %r528 = and i1 %r518, %r525
  br i1 %r528, label %pic.desc.prefix.guard.111, label %pic.miss.cold.116

pic.desc.prefix.guard.111:                        ; preds = %pic.desc.classify.110
  %r573 = getelementptr i64, ptr %r524, i64 2
  %r574 = load i64, ptr %r573, align 8
  %r575 = icmp ne i64 %r574, 0
  br i1 %r575, label %pic.desc.prefix.meta.112, label %pic.miss.cold.116

pic.desc.prefix.meta.112:                         ; preds = %pic.desc.prefix.guard.111
  %r576 = add nuw nsw i64 %r504, 8
  %r577 = inttoptr i64 %r576 to ptr
  %r578 = load i64, ptr %r577, align 8
  %r579 = icmp ne i64 %r578, 0
  br i1 %r579, label %pic.desc.prefix.token.113, label %pic.miss.cold.116

pic.desc.prefix.token.113:                        ; preds = %pic.desc.prefix.meta.112
  %r580 = inttoptr i64 %r578 to ptr
  %r581 = getelementptr i64, ptr %r580, i64 6
  %r582 = load i64, ptr %r581, align 8
  %r583 = icmp eq i64 %r582, %r574
  br i1 %r583, label %pic.desc.prefix.hit.114, label %pic.miss.cold.116

pic.desc.prefix.hit.114:                          ; preds = %pic.desc.prefix.token.113
  %r584 = getelementptr i64, ptr %r524, i64 1
  %r585 = load i64, ptr %r584, align 8
  %r586 = shl i64 %r585, 3
  %r587 = add nuw nsw i64 %r504, 16
  %r588 = add i64 %r587, %r586
  %r589 = inttoptr i64 %r588 to ptr
  %r590 = load double, ptr %r589, align 8
  br label %pic.merge.118

pic.miss.115:                                     ; preds = %pic.hit.inline.122, %pic.prefix.token.108, %pic.prefix.meta.107, %pic.prefix.guard.106
  %r591 = getelementptr i64, ptr %r524, i64 3
  %r592 = load i64, ptr %r591, align 8
  %r593 = icmp sgt i64 %r592, 0
  br i1 %r593, label %pic.ways.123, label %pic.miss.call.117

pic.miss.cold.116:                                ; preds = %pic.desc.prefix.token.113, %pic.desc.prefix.meta.112, %pic.desc.prefix.guard.111, %pic.desc.classify.110, %pget.recv_ok.98
  br label %pic.miss.call.117

pic.miss.call.117:                                ; preds = %pic.way.load.124, %pic.ways.123, %pic.miss.cold.116, %pic.miss.115
  %r632 = load double, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  %r633 = bitcast double %r632 to i64
  %r634 = and i64 %r633, 281474976710655
  %statepoint_token85 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r504, i64 %r634, ptr @perry_ic_test_json_large_string_emitters_ts__21, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %r63586 = call double @llvm.experimental.gc.result.f64(token %statepoint_token85)
  %rs4gc.s4.relocated87 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 0, i32 0) ; (%.13, %.13)
  br label %pic.merge.118

pic.merge.118:                                    ; preds = %pic.way.live.125, %pic.hit.overflow.121, %pic.miss.call.117, %pic.desc.prefix.hit.114, %pic.prefix.hit.109, %pic.hit.live.105
  %.15 = phi ptr addrspace(1) [ %rs4gc.s4.relocated90, %pic.hit.overflow.121 ], [ %rs4gc.s4.relocated87, %pic.miss.call.117 ], [ %.13, %pic.way.live.125 ], [ %.13, %pic.hit.live.105 ], [ %.13, %pic.prefix.hit.109 ], [ %.13, %pic.desc.prefix.hit.114 ]
  %r636 = phi double [ %r552, %pic.hit.live.105 ], [ %r54789, %pic.hit.overflow.121 ], [ %r572, %pic.prefix.hit.109 ], [ %r590, %pic.desc.prefix.hit.114 ], [ %r629, %pic.way.live.125 ], [ %r63586, %pic.miss.call.117 ]
  br label %pget.recv_merge.101

pic.recv_hdr.119:                                 ; preds = %pget.recv_ok.98
  %r515 = sub nuw nsw i64 %r504, 8
  %r516 = inttoptr i64 %r515 to ptr
  %r517 = load i8, ptr %r516, align 1
  %r518 = icmp eq i8 %r517, 2
  %r519 = sub nuw nsw i64 %r504, 6
  %r520 = inttoptr i64 %r519 to ptr
  %r521 = load i16, ptr %r520, align 2
  %r522 = and i16 %r521, 2048
  %r523 = icmp eq i16 %r522, 0
  %r524 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__21, align 8
  %r525 = icmp ne ptr %r524, null
  %r526 = and i1 %r518, %r523
  %r527 = and i1 %r526, %r525
  br i1 %r527, label %pic.token.120, label %pic.desc.classify.110

pic.token.120:                                    ; preds = %pic.recv_hdr.119
  %r529 = add nuw nsw i64 %r504, 4
  %r530 = inttoptr i64 %r529 to ptr
  %r531 = load i32, ptr %r530, align 4
  %r532 = zext i32 %r531 to i64
  %r533 = or i64 %r532, 4611686018427387904
  %r534 = icmp ne i32 %r531, 0
  %r535 = getelementptr i64, ptr %r524, i64 0
  %r536 = load i64, ptr %r535, align 8
  %r537 = icmp eq i64 %r533, %r536
  %r538 = and i1 %r537, %r534
  br i1 %r538, label %pic.hit.104, label %pic.prefix.guard.106

pic.hit.overflow.121:                             ; preds = %pic.hit.104
  %r543 = load double, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  %r544 = bitcast double %r543 to i64
  %r545 = and i64 %r544, 281474976710655
  %r546 = trunc i64 %r540 to i32
  %statepoint_token88 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r504, i64 %r545, i32 %r546, ptr @perry_ic_test_json_large_string_emitters_ts__21, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %r54789 = call double @llvm.experimental.gc.result.f64(token %statepoint_token88)
  %rs4gc.s4.relocated90 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token88, i32 0, i32 0) ; (%.13, %.13)
  br label %pic.merge.118

pic.hit.inline.122:                               ; preds = %pic.hit.104
  %r548 = shl i64 %r540, 3
  %r549 = add nuw nsw i64 %r504, 16
  %r550 = add i64 %r549, %r548
  %r551 = inttoptr i64 %r550 to ptr
  %r552 = load double, ptr %r551, align 8
  %r553 = bitcast double %r552 to i64
  %r554 = icmp eq i64 %r553, 9222246136947933200
  br i1 %r554, label %pic.miss.115, label %pic.hit.live.105

pic.ways.123:                                     ; preds = %pic.miss.115
  %r594 = getelementptr i64, ptr %r524, i64 4
  %r595 = load i64, ptr %r594, align 8
  %r596 = icmp eq i64 %r595, %r533
  %r597 = getelementptr i64, ptr %r524, i64 5
  %r598 = load i64, ptr %r597, align 8
  %r599 = select i1 %r596, i64 %r598, i64 0
  %r600 = getelementptr i64, ptr %r524, i64 6
  %r601 = load i64, ptr %r600, align 8
  %r602 = icmp eq i64 %r601, %r533
  %r603 = getelementptr i64, ptr %r524, i64 7
  %r604 = load i64, ptr %r603, align 8
  %r605 = select i1 %r602, i64 %r604, i64 0
  %r606 = getelementptr i64, ptr %r524, i64 8
  %r607 = load i64, ptr %r606, align 8
  %r608 = icmp eq i64 %r607, %r533
  %r609 = getelementptr i64, ptr %r524, i64 9
  %r610 = load i64, ptr %r609, align 8
  %r611 = select i1 %r608, i64 %r610, i64 0
  %r612 = getelementptr i64, ptr %r524, i64 10
  %r613 = load i64, ptr %r612, align 8
  %r614 = icmp eq i64 %r613, %r533
  %r615 = getelementptr i64, ptr %r524, i64 11
  %r616 = load i64, ptr %r615, align 8
  %r617 = select i1 %r614, i64 %r616, i64 0
  %r618 = or i1 %r596, %r602
  %r619 = select i1 %r596, i64 %r599, i64 %r605
  %r620 = or i1 %r608, %r614
  %r621 = select i1 %r608, i64 %r611, i64 %r617
  %r622 = or i1 %r618, %r620
  %r623 = select i1 %r618, i64 %r619, i64 %r621
  %r624 = and i1 %r534, %r622
  br i1 %r624, label %pic.way.load.124, label %pic.miss.call.117

pic.way.load.124:                                 ; preds = %pic.ways.123
  %r625 = shl i64 %r623, 3
  %r626 = add nuw nsw i64 %r504, 16
  %r627 = add i64 %r626, %r625
  %r628 = inttoptr i64 %r627 to ptr
  %r629 = load double, ptr %r628, align 8
  %r630 = bitcast double %r629 to i64
  %r631 = icmp eq i64 %r630, 9222246136947933200
  br i1 %r631, label %pic.miss.call.117, label %pic.way.live.125

pic.way.live.125:                                 ; preds = %pic.way.load.124
  br label %pic.merge.118

pget.throw_nullish.126:                           ; preds = %pget.recv_bad.99
  %r640 = zext i1 %r638 to i32
  %statepoint_token91 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r640, ptr @test_json_large_string_emitters_ts_.str.20.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.127:                       ; preds = %pget.recv_bad.99
  %r641 = load double, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  %r642 = bitcast double %r641 to i64
  %r643 = and i64 %r642, 281474976710655
  %statepoint_token92 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r503, i64 %r643, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %r64493 = call double @llvm.experimental.gc.result.f64(token %statepoint_token92)
  %rs4gc.s4.relocated94 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token92, i32 0, i32 0) ; (%.13, %.13)
  br label %pget.recv_merge.101

shadow.root.barrier.128:                          ; preds = %pget.recv_merge.101
  call void @js_write_barrier_root_nanbox(i64 %r663) #7
  br label %shadow.root.barrier.done.129

shadow.root.barrier.done.129:                     ; preds = %shadow.root.barrier.128, %pget.recv_merge.101
  %r666.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r666.rs4o = call i64 asm "", "=r,0"(i64 %r666.rs4i) #7
  %r666 = bitcast i64 %r666.rs4o to double
  %r667 = bitcast double %r666 to i64
  %r668 = and i64 %r667, 281474976710655
  %r669 = lshr i64 %r667, 48
  %r670 = and i64 %r669, 65533
  %r671 = icmp eq i64 %r670, 32765
  br i1 %r671, label %pget.recv_ok.131, label %pget.recv_other.135

pget.recv_sso.130:                                ; preds = %pget.recv_other.135
  %r809 = load double, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  %r810 = bitcast double %r809 to i64
  %r811 = and i64 %r810, 281474976710655
  %statepoint_token95 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r667, i64 %r811, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated84) ]
  %r81296 = call double @llvm.experimental.gc.result.f64(token %statepoint_token95)
  %rs4gc.s4.relocated97 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token95, i32 0, i32 0) ; (%rs4gc.s4.relocated84, %rs4gc.s4.relocated84)
  br label %pget.recv_merge.134

pget.recv_ok.131:                                 ; preds = %shadow.root.barrier.done.129
  %r678 = icmp ugt i64 %r668, 1048575
  br i1 %r678, label %pic.recv_hdr.152, label %pic.miss.cold.149

pget.recv_bad.132:                                ; preds = %pget.check_class_ref.136
  %r801 = icmp eq i64 %r667, 9222246136947933185
  %r802 = icmp eq i64 %r667, 9222246136947933186
  %r803 = or i1 %r801, %r802
  br i1 %r803, label %pget.throw_nullish.159, label %pget.recv_undef_return.160

pget.recv_class_ref.133:                          ; preds = %pget.check_class_ref.136
  %r674 = load double, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  %r675 = bitcast double %r674 to i64
  %r676 = and i64 %r675, 281474976710655
  %statepoint_token98 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7058970246387859478, i64 %r667, i64 %r676, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated84) ]
  %r67799 = call double @llvm.experimental.gc.result.f64(token %statepoint_token98)
  %rs4gc.s4.relocated100 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token98, i32 0, i32 0) ; (%rs4gc.s4.relocated84, %rs4gc.s4.relocated84)
  br label %pget.recv_merge.134

pget.recv_merge.134:                              ; preds = %pget.recv_undef_return.160, %pic.merge.151, %pget.recv_class_ref.133, %pget.recv_sso.130
  %.16 = phi ptr addrspace(1) [ %.17, %pic.merge.151 ], [ %rs4gc.s4.relocated97, %pget.recv_sso.130 ], [ %rs4gc.s4.relocated100, %pget.recv_class_ref.133 ], [ %rs4gc.s4.relocated110, %pget.recv_undef_return.160 ]
  %r813 = phi double [ %r800, %pic.merge.151 ], [ %r808109, %pget.recv_undef_return.160 ], [ %r81296, %pget.recv_sso.130 ], [ %r67799, %pget.recv_class_ref.133 ]
  %r814 = bitcast double %r813 to i64
  %r815 = lshr i64 %r814, 48
  %r816 = icmp eq i64 %r815, 32766
  %r817 = trunc i64 %r814 to i32
  %r818 = sitofp i32 %r817 to double
  %r819 = select i1 %r816, double %r818, double %r813
  %r826 = fcmp une double %r819, 6.300000e+01
  %r827 = select i1 %r826, i64 9222246136947933188, i64 9222246136947933187
  %r828 = bitcast i64 %r827 to double
  %r829 = icmp eq i64 %r827, 9222246136947933188
  br i1 %r829, label %if.then.161, label %if.else.162

pget.recv_other.135:                              ; preds = %shadow.root.barrier.done.129
  %r672 = icmp eq i64 %r669, 32761
  br i1 %r672, label %pget.recv_sso.130, label %pget.check_class_ref.136

pget.check_class_ref.136:                         ; preds = %pget.recv_other.135
  %r673 = icmp eq i64 %r669, 32766
  br i1 %r673, label %pget.recv_class_ref.133, label %pget.recv_bad.132

pic.hit.137:                                      ; preds = %pic.token.153
  %r703 = getelementptr i64, ptr %r688, i64 1
  %r704 = load i64, ptr %r703, align 8
  %r705 = and i64 %r704, 1073741824
  %r706 = icmp ne i64 %r705, 0
  br i1 %r706, label %pic.hit.overflow.154, label %pic.hit.inline.155

pic.hit.live.138:                                 ; preds = %pic.hit.inline.155
  br label %pic.merge.151

pic.prefix.guard.139:                             ; preds = %pic.token.153
  %r719 = getelementptr i64, ptr %r688, i64 2
  %r720 = load i64, ptr %r719, align 8
  %r721 = icmp ne i64 %r720, 0
  br i1 %r721, label %pic.prefix.meta.140, label %pic.miss.148

pic.prefix.meta.140:                              ; preds = %pic.prefix.guard.139
  %r722 = add nuw nsw i64 %r668, 8
  %r723 = inttoptr i64 %r722 to ptr
  %r724 = load i64, ptr %r723, align 8
  %r725 = icmp ne i64 %r724, 0
  br i1 %r725, label %pic.prefix.token.141, label %pic.miss.148

pic.prefix.token.141:                             ; preds = %pic.prefix.meta.140
  %r726 = inttoptr i64 %r724 to ptr
  %r727 = getelementptr i64, ptr %r726, i64 6
  %r728 = load i64, ptr %r727, align 8
  %r729 = icmp eq i64 %r728, %r720
  br i1 %r729, label %pic.prefix.hit.142, label %pic.miss.148

pic.prefix.hit.142:                               ; preds = %pic.prefix.token.141
  %r730 = getelementptr i64, ptr %r688, i64 1
  %r731 = load i64, ptr %r730, align 8
  %r732 = shl i64 %r731, 3
  %r733 = add nuw nsw i64 %r668, 16
  %r734 = add i64 %r733, %r732
  %r735 = inttoptr i64 %r734 to ptr
  %r736 = load double, ptr %r735, align 8
  br label %pic.merge.151

pic.desc.classify.143:                            ; preds = %pic.recv_hdr.152
  %r692 = and i1 %r682, %r689
  br i1 %r692, label %pic.desc.prefix.guard.144, label %pic.miss.cold.149

pic.desc.prefix.guard.144:                        ; preds = %pic.desc.classify.143
  %r737 = getelementptr i64, ptr %r688, i64 2
  %r738 = load i64, ptr %r737, align 8
  %r739 = icmp ne i64 %r738, 0
  br i1 %r739, label %pic.desc.prefix.meta.145, label %pic.miss.cold.149

pic.desc.prefix.meta.145:                         ; preds = %pic.desc.prefix.guard.144
  %r740 = add nuw nsw i64 %r668, 8
  %r741 = inttoptr i64 %r740 to ptr
  %r742 = load i64, ptr %r741, align 8
  %r743 = icmp ne i64 %r742, 0
  br i1 %r743, label %pic.desc.prefix.token.146, label %pic.miss.cold.149

pic.desc.prefix.token.146:                        ; preds = %pic.desc.prefix.meta.145
  %r744 = inttoptr i64 %r742 to ptr
  %r745 = getelementptr i64, ptr %r744, i64 6
  %r746 = load i64, ptr %r745, align 8
  %r747 = icmp eq i64 %r746, %r738
  br i1 %r747, label %pic.desc.prefix.hit.147, label %pic.miss.cold.149

pic.desc.prefix.hit.147:                          ; preds = %pic.desc.prefix.token.146
  %r748 = getelementptr i64, ptr %r688, i64 1
  %r749 = load i64, ptr %r748, align 8
  %r750 = shl i64 %r749, 3
  %r751 = add nuw nsw i64 %r668, 16
  %r752 = add i64 %r751, %r750
  %r753 = inttoptr i64 %r752 to ptr
  %r754 = load double, ptr %r753, align 8
  br label %pic.merge.151

pic.miss.148:                                     ; preds = %pic.hit.inline.155, %pic.prefix.token.141, %pic.prefix.meta.140, %pic.prefix.guard.139
  %r755 = getelementptr i64, ptr %r688, i64 3
  %r756 = load i64, ptr %r755, align 8
  %r757 = icmp sgt i64 %r756, 0
  br i1 %r757, label %pic.ways.156, label %pic.miss.call.150

pic.miss.cold.149:                                ; preds = %pic.desc.prefix.token.146, %pic.desc.prefix.meta.145, %pic.desc.prefix.guard.144, %pic.desc.classify.143, %pget.recv_ok.131
  br label %pic.miss.call.150

pic.miss.call.150:                                ; preds = %pic.way.load.157, %pic.ways.156, %pic.miss.cold.149, %pic.miss.148
  %r796 = load double, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  %r797 = bitcast double %r796 to i64
  %r798 = and i64 %r797, 281474976710655
  %statepoint_token101 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r668, i64 %r798, ptr @perry_ic_test_json_large_string_emitters_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated84) ]
  %r799102 = call double @llvm.experimental.gc.result.f64(token %statepoint_token101)
  %rs4gc.s4.relocated103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token101, i32 0, i32 0) ; (%rs4gc.s4.relocated84, %rs4gc.s4.relocated84)
  br label %pic.merge.151

pic.merge.151:                                    ; preds = %pic.way.live.158, %pic.hit.overflow.154, %pic.miss.call.150, %pic.desc.prefix.hit.147, %pic.prefix.hit.142, %pic.hit.live.138
  %.17 = phi ptr addrspace(1) [ %rs4gc.s4.relocated106, %pic.hit.overflow.154 ], [ %rs4gc.s4.relocated103, %pic.miss.call.150 ], [ %rs4gc.s4.relocated84, %pic.way.live.158 ], [ %rs4gc.s4.relocated84, %pic.hit.live.138 ], [ %rs4gc.s4.relocated84, %pic.prefix.hit.142 ], [ %rs4gc.s4.relocated84, %pic.desc.prefix.hit.147 ]
  %r800 = phi double [ %r716, %pic.hit.live.138 ], [ %r711105, %pic.hit.overflow.154 ], [ %r736, %pic.prefix.hit.142 ], [ %r754, %pic.desc.prefix.hit.147 ], [ %r793, %pic.way.live.158 ], [ %r799102, %pic.miss.call.150 ]
  br label %pget.recv_merge.134

pic.recv_hdr.152:                                 ; preds = %pget.recv_ok.131
  %r679 = sub nuw nsw i64 %r668, 8
  %r680 = inttoptr i64 %r679 to ptr
  %r681 = load i8, ptr %r680, align 1
  %r682 = icmp eq i8 %r681, 2
  %r683 = sub nuw nsw i64 %r668, 6
  %r684 = inttoptr i64 %r683 to ptr
  %r685 = load i16, ptr %r684, align 2
  %r686 = and i16 %r685, 2048
  %r687 = icmp eq i16 %r686, 0
  %r688 = load ptr, ptr @perry_ic_test_json_large_string_emitters_ts__23, align 8
  %r689 = icmp ne ptr %r688, null
  %r690 = and i1 %r682, %r687
  %r691 = and i1 %r690, %r689
  br i1 %r691, label %pic.token.153, label %pic.desc.classify.143

pic.token.153:                                    ; preds = %pic.recv_hdr.152
  %r693 = add nuw nsw i64 %r668, 4
  %r694 = inttoptr i64 %r693 to ptr
  %r695 = load i32, ptr %r694, align 4
  %r696 = zext i32 %r695 to i64
  %r697 = or i64 %r696, 4611686018427387904
  %r698 = icmp ne i32 %r695, 0
  %r699 = getelementptr i64, ptr %r688, i64 0
  %r700 = load i64, ptr %r699, align 8
  %r701 = icmp eq i64 %r697, %r700
  %r702 = and i1 %r701, %r698
  br i1 %r702, label %pic.hit.137, label %pic.prefix.guard.139

pic.hit.overflow.154:                             ; preds = %pic.hit.137
  %r707 = load double, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  %r708 = bitcast double %r707 to i64
  %r709 = and i64 %r708, 281474976710655
  %r710 = trunc i64 %r704 to i32
  %statepoint_token104 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r668, i64 %r709, i32 %r710, ptr @perry_ic_test_json_large_string_emitters_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated84) ]
  %r711105 = call double @llvm.experimental.gc.result.f64(token %statepoint_token104)
  %rs4gc.s4.relocated106 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token104, i32 0, i32 0) ; (%rs4gc.s4.relocated84, %rs4gc.s4.relocated84)
  br label %pic.merge.151

pic.hit.inline.155:                               ; preds = %pic.hit.137
  %r712 = shl i64 %r704, 3
  %r713 = add nuw nsw i64 %r668, 16
  %r714 = add i64 %r713, %r712
  %r715 = inttoptr i64 %r714 to ptr
  %r716 = load double, ptr %r715, align 8
  %r717 = bitcast double %r716 to i64
  %r718 = icmp eq i64 %r717, 9222246136947933200
  br i1 %r718, label %pic.miss.148, label %pic.hit.live.138

pic.ways.156:                                     ; preds = %pic.miss.148
  %r758 = getelementptr i64, ptr %r688, i64 4
  %r759 = load i64, ptr %r758, align 8
  %r760 = icmp eq i64 %r759, %r697
  %r761 = getelementptr i64, ptr %r688, i64 5
  %r762 = load i64, ptr %r761, align 8
  %r763 = select i1 %r760, i64 %r762, i64 0
  %r764 = getelementptr i64, ptr %r688, i64 6
  %r765 = load i64, ptr %r764, align 8
  %r766 = icmp eq i64 %r765, %r697
  %r767 = getelementptr i64, ptr %r688, i64 7
  %r768 = load i64, ptr %r767, align 8
  %r769 = select i1 %r766, i64 %r768, i64 0
  %r770 = getelementptr i64, ptr %r688, i64 8
  %r771 = load i64, ptr %r770, align 8
  %r772 = icmp eq i64 %r771, %r697
  %r773 = getelementptr i64, ptr %r688, i64 9
  %r774 = load i64, ptr %r773, align 8
  %r775 = select i1 %r772, i64 %r774, i64 0
  %r776 = getelementptr i64, ptr %r688, i64 10
  %r777 = load i64, ptr %r776, align 8
  %r778 = icmp eq i64 %r777, %r697
  %r779 = getelementptr i64, ptr %r688, i64 11
  %r780 = load i64, ptr %r779, align 8
  %r781 = select i1 %r778, i64 %r780, i64 0
  %r782 = or i1 %r760, %r766
  %r783 = select i1 %r760, i64 %r763, i64 %r769
  %r784 = or i1 %r772, %r778
  %r785 = select i1 %r772, i64 %r775, i64 %r781
  %r786 = or i1 %r782, %r784
  %r787 = select i1 %r782, i64 %r783, i64 %r785
  %r788 = and i1 %r698, %r786
  br i1 %r788, label %pic.way.load.157, label %pic.miss.call.150

pic.way.load.157:                                 ; preds = %pic.ways.156
  %r789 = shl i64 %r787, 3
  %r790 = add nuw nsw i64 %r668, 16
  %r791 = add i64 %r790, %r789
  %r792 = inttoptr i64 %r791 to ptr
  %r793 = load double, ptr %r792, align 8
  %r794 = bitcast double %r793 to i64
  %r795 = icmp eq i64 %r794, 9222246136947933200
  br i1 %r795, label %pic.miss.call.150, label %pic.way.live.158

pic.way.live.158:                                 ; preds = %pic.way.load.157
  br label %pic.merge.151

pget.throw_nullish.159:                           ; preds = %pget.recv_bad.132
  %r804 = zext i1 %r802 to i32
  %statepoint_token107 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r804, ptr @test_json_large_string_emitters_ts_.str.20.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.160:                       ; preds = %pget.recv_bad.132
  %r805 = load double, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  %r806 = bitcast double %r805 to i64
  %r807 = and i64 %r806, 281474976710655
  %statepoint_token108 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r667, i64 %r807, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated84) ]
  %r808109 = call double @llvm.experimental.gc.result.f64(token %statepoint_token108)
  %rs4gc.s4.relocated110 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 0, i32 0) ; (%rs4gc.s4.relocated84, %rs4gc.s4.relocated84)
  br label %pget.recv_merge.134

if.then.161:                                      ; preds = %pget.recv_merge.134
  %r830 = load double, ptr @test_json_large_string_emitters_ts_.str.22.handle, align 8
  %statepoint_token111 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r830, i32 0, i32 0)
  %r831112 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token111)
  %r832 = or i64 %r831112, 9222527611924643840
  %r833 = bitcast i64 %r832 to double
  %statepoint_token113 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r833, i32 0, i32 0)
  unreachable

if.else.162:                                      ; preds = %pget.recv_merge.134
  br label %if.merge.163

if.merge.163:                                     ; preds = %if.else.162
  %r834.rs4i = ptrtoint ptr addrspace(1) %.16 to i64
  %r834.rs4o = call i64 asm "", "=r,0"(i64 %r834.rs4i) #7
  %r834 = bitcast i64 %r834.rs4o to double
  %r835 = load double, ptr @test_json_large_string_emitters_ts_.str.8.handle, align 8
  %statepoint_token114 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r834, double %r835, i32 0, i32 0)
  %r836115 = call double @llvm.experimental.gc.result.f64(token %statepoint_token114)
  ret double %r836115
}

; Function Attrs: optsize
define double @test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47_constructor(double %this_arg) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  br label %standalone.ctor.return.after.1

standalone.ctor.return.after.1:                   ; preds = %entry.0
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define double @test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c_constructor(double %this_arg, double %arg9, double %arg10) #6 gc "statepoint-example" {
entry.0:
  %r8 = load i32, ptr @perry_class_shape_id_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg9 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg10 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #7
  %r5 = bitcast i64 %r5.rs4o to double
  %r6.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r6.rs4o = call i64 asm "", "=r,0"(i64 %r6.rs4i) #7
  %r6 = bitcast i64 %r6.rs4o to double
  %r10 = bitcast double %r5 to i64
  %r11 = and i64 %r10, 281474976710655
  %r12 = load double, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  %r13 = bitcast double %r12 to i64
  %r14 = and i64 %r13, 281474976710655
  %r15 = bitcast double %r6 to i64
  %r16 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r17 = icmp eq i8 %r16, 0
  %r18 = lshr i64 %r10, 48
  %r19 = icmp eq i64 %r18, 32765
  %r20 = icmp ugt i64 %r11, 1048575
  %r21 = and i1 %r19, %r20
  %r22 = and i1 %r21, %r17
  br i1 %r22, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.9
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r187.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r187.rs4o = call i64 asm "", "=r,0"(i64 %r187.rs4i) #7
  %r187 = bitcast i64 %r187.rs4o to double
  %r188 = bitcast double %r187 to i64
  %r189 = and i64 %r188, 281474976710655
  %r59 = inttoptr i64 %r189 to ptr
  %r183.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r183.rs4o = call i64 asm "", "=r,0"(i64 %r183.rs4i) #7
  %r183 = bitcast i64 %r183.rs4o to double
  %r184 = bitcast double %r183 to i64
  %r185 = and i64 %r184, 281474976710655
  %r186 = inttoptr i64 %r185 to ptr
  %r60 = getelementptr i8, ptr %r186, i64 16
  %r61 = getelementptr double, ptr %r60, i64 0
  %r182.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r182.rs4o = call i64 asm "", "=r,0"(i64 %r182.rs4i) #7
  %r182 = bitcast i64 %r182.rs4o to double
  %r62 = call double @js_array_numeric_value_to_raw_f64(double %r182) #7
  store double %r62, ptr %r61, align 8
  br label %class_field_set.merge.4

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r176.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r176.rs4o = call i64 asm "", "=r,0"(i64 %r176.rs4i) #7
  %r176 = bitcast i64 %r176.rs4o to double
  %r177 = bitcast double %r176 to i64
  %r178.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r178.rs4o = call i64 asm "", "=r,0"(i64 %r178.rs4i) #7
  %r178 = bitcast i64 %r178.rs4o to double
  %r179 = load double, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  %r180 = bitcast double %r179 to i64
  %r181 = and i64 %r180, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 7058970246387859480, i64 %r177, i64 %r181, double %r178, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s1) ]
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s1, %rs4gc.s1)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.fallback.3, %class_field_set.fast.2
  %.02 = phi ptr addrspace(1) [ %rs4gc.s1, %class_field_set.fast.2 ], [ %rs4gc.s1.relocated, %class_field_set.fallback.3 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %class_field_set.fast.2 ], [ %rs4gc.s3.relocated, %class_field_set.fallback.3 ]
  %r63.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r63.rs4o = call i64 asm "", "=r,0"(i64 %r63.rs4i) #7
  %r63 = bitcast i64 %r63.rs4o to double
  %r64.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r64.rs4o = call i64 asm "", "=r,0"(i64 %r64.rs4i) #7
  %r64 = bitcast i64 %r64.rs4o to double
  %r66 = bitcast double %r63 to i64
  %r67 = and i64 %r66, 281474976710655
  %r68 = load double, ptr @test_json_large_string_emitters_ts_.str.23.handle, align 8
  %r69 = bitcast double %r68 to i64
  %r70 = and i64 %r69, 281474976710655
  %r71 = bitcast double %r64 to i64
  %r72 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r73 = icmp eq i8 %r72, 0
  %r74 = lshr i64 %r66, 48
  %r75 = icmp eq i64 %r74, 32765
  %r76 = icmp ugt i64 %r67, 1048575
  %r77 = and i1 %r75, %r76
  %r78 = and i1 %r77, %r73
  br i1 %r78, label %class_field_inline.deref.10, label %class_field_inline.guardcall.11

class_field_inline.deref.5:                       ; preds = %entry.0
  %r23 = inttoptr i64 %r11 to ptr
  %r24 = getelementptr i8, ptr %r23, i64 -8
  %r25 = load i8, ptr %r24, align 1
  %r26 = icmp eq i8 %r25, 2
  %r27 = getelementptr i8, ptr %r23, i64 -7
  %r28 = load i8, ptr %r27, align 1
  %r29 = and i8 %r28, -128
  %r30 = icmp eq i8 %r29, 0
  %r31 = getelementptr i8, ptr %r23, i64 -6
  %r32 = load i16, ptr %r31, align 2
  %r33 = getelementptr i8, ptr %r23, i64 0
  %r34 = load i32, ptr %r33, align 4
  %r35 = icmp eq i32 %r34, 2
  %r36 = getelementptr i8, ptr %r23, i64 4
  %r37 = load i32, ptr %r36, align 4
  %r38 = icmp eq i32 %r37, %r8
  %r39 = and i1 %r26, %r30
  %r40 = and i1 %r39, %r35
  %r41 = and i1 %r40, %r38
  %r42 = and i16 %r32, 3072
  %r43 = icmp eq i16 %r42, 0
  %r44 = and i1 %r41, %r43
  %r45 = and i16 %r32, 4096
  %r46 = icmp ne i16 %r45, 0
  %r47 = and i1 %r44, %r46
  %r48 = and i16 %r32, 1
  %r49 = icmp eq i16 %r48, 0
  %r50 = and i1 %r47, %r49
  %r51 = and i16 %r32, 128
  %r52 = icmp eq i16 %r51, 0
  %r53 = and i1 %r50, %r52
  %r54 = and i64 %r15, 9218868437227405312
  %r55 = icmp ne i64 %r54, 9218868437227405312
  %r56 = and i1 %r53, %r55
  br i1 %r56, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r57 = call i32 @js_typed_feedback_class_field_set_guard(i64 7058970246387859480, double %r5, i32 2, i32 %r8, i64 %r14, i32 0, double %r6, i32 1) #7
  %r58 = icmp ne i32 %r57, 0
  br i1 %r58, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.fast.7:                           ; preds = %class_field_inline.guardcall.11, %class_field_inline.deref.10
  %r173.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r173.rs4o = call i64 asm "", "=r,0"(i64 %r173.rs4i) #7
  %r173 = bitcast i64 %r173.rs4o to double
  %r174 = bitcast double %r173 to i64
  %r175 = and i64 %r174, 281474976710655
  %r109 = inttoptr i64 %r175 to ptr
  %r169.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r169.rs4o = call i64 asm "", "=r,0"(i64 %r169.rs4i) #7
  %r169 = bitcast i64 %r169.rs4o to double
  %r170 = bitcast double %r169 to i64
  %r171 = and i64 %r170, 281474976710655
  %r172 = inttoptr i64 %r171 to ptr
  %r110 = getelementptr i8, ptr %r172, i64 16
  %r111 = getelementptr double, ptr %r110, i64 1
  %r112 = ptrtoint ptr %r111 to i64
  %r168.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r168.rs4o = call i64 asm "", "=r,0"(i64 %r168.rs4i) #7
  %r168 = bitcast i64 %r168.rs4o to double
  store double %r168, ptr %r111, align 8
  %r167.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r167.rs4o = call i64 asm "", "=r,0"(i64 %r167.rs4i) #7
  %r167 = bitcast i64 %r167.rs4o to double
  %r113 = bitcast double %r167 to i64
  %r165.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r165.rs4o = call i64 asm "", "=r,0"(i64 %r165.rs4i) #7
  %r165 = bitcast i64 %r165.rs4o to double
  %r166 = bitcast double %r165 to i64
  %r114 = lshr i64 %r166, 48
  %r115 = icmp eq i64 %r114, 0
  %r163.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r163.rs4o = call i64 asm "", "=r,0"(i64 %r163.rs4i) #7
  %r163 = bitcast i64 %r163.rs4o to double
  %r164 = bitcast double %r163 to i64
  %r116 = icmp uge i64 %r164, 4096
  %r117 = and i1 %r115, %r116
  %r118 = icmp eq i64 %r114, 32765
  %r119 = icmp eq i64 %r114, 32767
  %r120 = icmp eq i64 %r114, 32762
  %r121 = or i1 %r118, %r119
  %r122 = or i1 %r121, %r120
  %r123 = or i1 %r122, %r117
  br i1 %r123, label %class_field_set.gc_bookkeeping.12, label %class_field_set.gc_bookkeeping.done.13

class_field_set.fallback.8:                       ; preds = %class_field_inline.guardcall.11
  %r157.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r157.rs4o = call i64 asm "", "=r,0"(i64 %r157.rs4i) #7
  %r157 = bitcast i64 %r157.rs4o to double
  %r158 = bitcast double %r157 to i64
  %r159.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r159.rs4o = call i64 asm "", "=r,0"(i64 %r159.rs4i) #7
  %r159 = bitcast i64 %r159.rs4o to double
  %r160 = load double, ptr @test_json_large_string_emitters_ts_.str.23.handle, align 8
  %r161 = bitcast double %r160 to i64
  %r162 = and i64 %r161, 281474976710655
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 7058970246387859481, i64 %r158, i64 %r162, double %r159, i32 0, i32 0)
  br label %class_field_set.merge.9

class_field_set.merge.9:                          ; preds = %class_field_set.gc_bookkeeping.done.13, %class_field_set.fallback.8
  br label %standalone.ctor.return.after.1

class_field_inline.deref.10:                      ; preds = %class_field_set.merge.4
  %r79 = inttoptr i64 %r67 to ptr
  %r80 = getelementptr i8, ptr %r79, i64 -8
  %r81 = load i8, ptr %r80, align 1
  %r82 = icmp eq i8 %r81, 2
  %r83 = getelementptr i8, ptr %r79, i64 -7
  %r84 = load i8, ptr %r83, align 1
  %r85 = and i8 %r84, -128
  %r86 = icmp eq i8 %r85, 0
  %r87 = getelementptr i8, ptr %r79, i64 -6
  %r88 = load i16, ptr %r87, align 2
  %r89 = getelementptr i8, ptr %r79, i64 0
  %r90 = load i32, ptr %r89, align 4
  %r91 = icmp eq i32 %r90, 2
  %r92 = getelementptr i8, ptr %r79, i64 4
  %r93 = load i32, ptr %r92, align 4
  %r94 = icmp eq i32 %r93, %r8
  %r95 = and i1 %r82, %r86
  %r96 = and i1 %r95, %r91
  %r97 = and i1 %r96, %r94
  %r98 = and i16 %r88, 3072
  %r99 = icmp eq i16 %r98, 0
  %r100 = and i1 %r97, %r99
  %r101 = and i16 %r88, 1
  %r102 = icmp eq i16 %r101, 0
  %r103 = and i1 %r100, %r102
  %r104 = and i16 %r88, 128
  %r105 = icmp eq i16 %r104, 0
  %r106 = and i1 %r103, %r105
  br i1 %r106, label %class_field_set.fast.7, label %class_field_inline.guardcall.11

class_field_inline.guardcall.11:                  ; preds = %class_field_inline.deref.10, %class_field_set.merge.4
  %r107 = call i32 @js_typed_feedback_class_field_set_guard(i64 7058970246387859481, double %r63, i32 2, i32 %r8, i64 %r70, i32 1, double %r64, i32 0) #7
  %r108 = icmp ne i32 %r107, 0
  br i1 %r108, label %class_field_set.fast.7, label %class_field_set.fallback.8

class_field_set.gc_bookkeeping.12:                ; preds = %class_field_set.fast.7
  %r156.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r156.rs4o = call i64 asm "", "=r,0"(i64 %r156.rs4i) #7
  %r156 = bitcast i64 %r156.rs4o to double
  call void @js_string_addref_if_heap_string(double %r156) #7
  %r153.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r153.rs4o = call i64 asm "", "=r,0"(i64 %r153.rs4i) #7
  %r153 = bitcast i64 %r153.rs4o to double
  %r154 = bitcast double %r153 to i64
  %r155 = and i64 %r154, 281474976710655
  %r124 = inttoptr i64 %r155 to ptr
  %r149.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r149.rs4o = call i64 asm "", "=r,0"(i64 %r149.rs4i) #7
  %r149 = bitcast i64 %r149.rs4o to double
  %r150 = bitcast double %r149 to i64
  %r151 = and i64 %r150, 281474976710655
  %r152 = inttoptr i64 %r151 to ptr
  %r125 = getelementptr i8, ptr %r152, i64 -6
  %r126 = load i16, ptr %r125, align 2
  %r127 = and i16 %r126, -12288
  %r128 = icmp eq i16 %r127, -28672
  br i1 %r128, label %class_field_set.layout_note.done.15, label %class_field_set.layout_note.14

class_field_set.gc_bookkeeping.done.13:           ; preds = %class_field_set.barrier.16, %class_field_set.layout_note.done.15, %class_field_set.fast.7
  br label %class_field_set.merge.9

class_field_set.layout_note.14:                   ; preds = %class_field_set.gc_bookkeeping.12
  %r144.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r144.rs4o = call i64 asm "", "=r,0"(i64 %r144.rs4i) #7
  %r144 = bitcast i64 %r144.rs4o to double
  %r145 = bitcast double %r144 to i64
  %r146 = and i64 %r145, 281474976710655
  %r147.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r147.rs4o = call i64 asm "", "=r,0"(i64 %r147.rs4i) #7
  %r147 = bitcast i64 %r147.rs4o to double
  %r148 = bitcast double %r147 to i64
  call void @js_gc_note_slot_layout(i64 %r146, i32 1, i64 %r148) #7
  br label %class_field_set.layout_note.done.15

class_field_set.layout_note.done.15:              ; preds = %class_field_set.layout_note.14, %class_field_set.gc_bookkeeping.12
  %r141.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r141.rs4o = call i64 asm "", "=r,0"(i64 %r141.rs4i) #7
  %r141 = bitcast i64 %r141.rs4o to double
  %r142 = bitcast double %r141 to i64
  %r143 = and i64 %r142, 281474976710655
  %r129 = sub nsw i64 %r143, 7
  %r130 = inttoptr i64 %r129 to ptr
  %r131 = load i8, ptr %r130, align 1
  %r132 = and i8 %r131, 32
  %r133 = icmp ne i8 %r132, 0
  %r134 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r135 = icmp ne i32 %r134, 0
  %r136 = or i1 %r133, %r135
  br i1 %r136, label %class_field_set.barrier.16, label %class_field_set.gc_bookkeeping.done.13

class_field_set.barrier.16:                       ; preds = %class_field_set.layout_note.done.15
  %r137.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r137.rs4o = call i64 asm "", "=r,0"(i64 %r137.rs4i) #7
  %r137 = bitcast i64 %r137.rs4o to double
  %r138 = bitcast double %r137 to i64
  %r139.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r139.rs4o = call i64 asm "", "=r,0"(i64 %r139.rs4i) #7
  %r139 = bitcast i64 %r139.rs4o to double
  %r140 = bitcast double %r139 to i64
  call void @js_write_barrier_slot(i64 %r138, i64 %r112, i64 %r140) #7
  br label %class_field_set.gc_bookkeeping.done.13
}

; Function Attrs: optsize
define double @test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3_constructor(double %this_arg, double %arg19) #6 gc "statepoint-example" {
entry.0:
  %r7 = load i32, ptr @perry_class_shape_id_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg19 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r4.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r4.rs4o = call i64 asm "", "=r,0"(i64 %r4.rs4i) #7
  %r4 = bitcast i64 %r4.rs4o to double
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #7
  %r5 = bitcast i64 %r5.rs4o to double
  %r9 = bitcast double %r4 to i64
  %r10 = and i64 %r9, 281474976710655
  %r11 = load double, ptr @test_json_large_string_emitters_ts_.str.23.handle, align 8
  %r12 = bitcast double %r11 to i64
  %r13 = and i64 %r12, 281474976710655
  %r14 = bitcast double %r5 to i64
  %r15 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r16 = icmp eq i8 %r15, 0
  %r17 = lshr i64 %r9, 48
  %r18 = icmp eq i64 %r17, 32765
  %r19 = icmp ugt i64 %r10, 1048575
  %r20 = and i1 %r18, %r19
  %r21 = and i1 %r20, %r16
  br i1 %r21, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.4
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r116.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r116.rs4o = call i64 asm "", "=r,0"(i64 %r116.rs4i) #7
  %r116 = bitcast i64 %r116.rs4o to double
  %r117 = bitcast double %r116 to i64
  %r118 = and i64 %r117, 281474976710655
  %r52 = inttoptr i64 %r118 to ptr
  %r112.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r112.rs4o = call i64 asm "", "=r,0"(i64 %r112.rs4i) #7
  %r112 = bitcast i64 %r112.rs4o to double
  %r113 = bitcast double %r112 to i64
  %r114 = and i64 %r113, 281474976710655
  %r115 = inttoptr i64 %r114 to ptr
  %r53 = getelementptr i8, ptr %r115, i64 16
  %r54 = getelementptr double, ptr %r53, i64 0
  %r55 = ptrtoint ptr %r54 to i64
  %r111.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r111.rs4o = call i64 asm "", "=r,0"(i64 %r111.rs4i) #7
  %r111 = bitcast i64 %r111.rs4o to double
  store double %r111, ptr %r54, align 8
  %r110.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r110.rs4o = call i64 asm "", "=r,0"(i64 %r110.rs4i) #7
  %r110 = bitcast i64 %r110.rs4o to double
  %r56 = bitcast double %r110 to i64
  %r108.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r108.rs4o = call i64 asm "", "=r,0"(i64 %r108.rs4i) #7
  %r108 = bitcast i64 %r108.rs4o to double
  %r109 = bitcast double %r108 to i64
  %r57 = lshr i64 %r109, 48
  %r58 = icmp eq i64 %r57, 0
  %r106.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r106.rs4o = call i64 asm "", "=r,0"(i64 %r106.rs4i) #7
  %r106 = bitcast i64 %r106.rs4o to double
  %r107 = bitcast double %r106 to i64
  %r59 = icmp uge i64 %r107, 4096
  %r60 = and i1 %r58, %r59
  %r61 = icmp eq i64 %r57, 32765
  %r62 = icmp eq i64 %r57, 32767
  %r63 = icmp eq i64 %r57, 32762
  %r64 = or i1 %r61, %r62
  %r65 = or i1 %r64, %r63
  %r66 = or i1 %r65, %r60
  br i1 %r66, label %class_field_set.gc_bookkeeping.7, label %class_field_set.gc_bookkeeping.done.8

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r100.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r100.rs4o = call i64 asm "", "=r,0"(i64 %r100.rs4i) #7
  %r100 = bitcast i64 %r100.rs4o to double
  %r101 = bitcast double %r100 to i64
  %r102.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r102.rs4o = call i64 asm "", "=r,0"(i64 %r102.rs4i) #7
  %r102 = bitcast i64 %r102.rs4o to double
  %r103 = load double, ptr @test_json_large_string_emitters_ts_.str.23.handle, align 8
  %r104 = bitcast double %r103 to i64
  %r105 = and i64 %r104, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 7058970246387859482, i64 %r101, i64 %r105, double %r102, i32 0, i32 0)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.gc_bookkeeping.done.8, %class_field_set.fallback.3
  br label %standalone.ctor.return.after.1

class_field_inline.deref.5:                       ; preds = %entry.0
  %r22 = inttoptr i64 %r10 to ptr
  %r23 = getelementptr i8, ptr %r22, i64 -8
  %r24 = load i8, ptr %r23, align 1
  %r25 = icmp eq i8 %r24, 2
  %r26 = getelementptr i8, ptr %r22, i64 -7
  %r27 = load i8, ptr %r26, align 1
  %r28 = and i8 %r27, -128
  %r29 = icmp eq i8 %r28, 0
  %r30 = getelementptr i8, ptr %r22, i64 -6
  %r31 = load i16, ptr %r30, align 2
  %r32 = getelementptr i8, ptr %r22, i64 0
  %r33 = load i32, ptr %r32, align 4
  %r34 = icmp eq i32 %r33, 3
  %r35 = getelementptr i8, ptr %r22, i64 4
  %r36 = load i32, ptr %r35, align 4
  %r37 = icmp eq i32 %r36, %r7
  %r38 = and i1 %r25, %r29
  %r39 = and i1 %r38, %r34
  %r40 = and i1 %r39, %r37
  %r41 = and i16 %r31, 3072
  %r42 = icmp eq i16 %r41, 0
  %r43 = and i1 %r40, %r42
  %r44 = and i16 %r31, 1
  %r45 = icmp eq i16 %r44, 0
  %r46 = and i1 %r43, %r45
  %r47 = and i16 %r31, 128
  %r48 = icmp eq i16 %r47, 0
  %r49 = and i1 %r46, %r48
  br i1 %r49, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r50 = call i32 @js_typed_feedback_class_field_set_guard(i64 7058970246387859482, double %r4, i32 3, i32 %r7, i64 %r13, i32 0, double %r5, i32 0) #7
  %r51 = icmp ne i32 %r50, 0
  br i1 %r51, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.gc_bookkeeping.7:                 ; preds = %class_field_set.fast.2
  %r99.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r99.rs4o = call i64 asm "", "=r,0"(i64 %r99.rs4i) #7
  %r99 = bitcast i64 %r99.rs4o to double
  call void @js_string_addref_if_heap_string(double %r99) #7
  %r96.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r96.rs4o = call i64 asm "", "=r,0"(i64 %r96.rs4i) #7
  %r96 = bitcast i64 %r96.rs4o to double
  %r97 = bitcast double %r96 to i64
  %r98 = and i64 %r97, 281474976710655
  %r67 = inttoptr i64 %r98 to ptr
  %r92.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r92.rs4o = call i64 asm "", "=r,0"(i64 %r92.rs4i) #7
  %r92 = bitcast i64 %r92.rs4o to double
  %r93 = bitcast double %r92 to i64
  %r94 = and i64 %r93, 281474976710655
  %r95 = inttoptr i64 %r94 to ptr
  %r68 = getelementptr i8, ptr %r95, i64 -6
  %r69 = load i16, ptr %r68, align 2
  %r70 = and i16 %r69, -12288
  %r71 = icmp eq i16 %r70, -28672
  br i1 %r71, label %class_field_set.layout_note.done.10, label %class_field_set.layout_note.9

class_field_set.gc_bookkeeping.done.8:            ; preds = %class_field_set.barrier.11, %class_field_set.layout_note.done.10, %class_field_set.fast.2
  br label %class_field_set.merge.4

class_field_set.layout_note.9:                    ; preds = %class_field_set.gc_bookkeeping.7
  %r87.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r87.rs4o = call i64 asm "", "=r,0"(i64 %r87.rs4i) #7
  %r87 = bitcast i64 %r87.rs4o to double
  %r88 = bitcast double %r87 to i64
  %r89 = and i64 %r88, 281474976710655
  %r90.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r90.rs4o = call i64 asm "", "=r,0"(i64 %r90.rs4i) #7
  %r90 = bitcast i64 %r90.rs4o to double
  %r91 = bitcast double %r90 to i64
  call void @js_gc_note_slot_layout(i64 %r89, i32 0, i64 %r91) #7
  br label %class_field_set.layout_note.done.10

class_field_set.layout_note.done.10:              ; preds = %class_field_set.layout_note.9, %class_field_set.gc_bookkeeping.7
  %r84.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r84.rs4o = call i64 asm "", "=r,0"(i64 %r84.rs4i) #7
  %r84 = bitcast i64 %r84.rs4o to double
  %r85 = bitcast double %r84 to i64
  %r86 = and i64 %r85, 281474976710655
  %r72 = sub nsw i64 %r86, 7
  %r73 = inttoptr i64 %r72 to ptr
  %r74 = load i8, ptr %r73, align 1
  %r75 = and i8 %r74, 32
  %r76 = icmp ne i8 %r75, 0
  %r77 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r78 = icmp ne i32 %r77, 0
  %r79 = or i1 %r76, %r78
  br i1 %r79, label %class_field_set.barrier.11, label %class_field_set.gc_bookkeeping.done.8

class_field_set.barrier.11:                       ; preds = %class_field_set.layout_note.done.10
  %r80.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r80.rs4o = call i64 asm "", "=r,0"(i64 %r80.rs4i) #7
  %r80 = bitcast i64 %r80.rs4o to double
  %r81 = bitcast double %r80 to i64
  %r82.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r82.rs4o = call i64 asm "", "=r,0"(i64 %r82.rs4i) #7
  %r82 = bitcast i64 %r82.rs4o to double
  %r83 = bitcast double %r82 to i64
  call void @js_write_barrier_slot(i64 %r81, i64 %r55, i64 %r83) #7
  br label %class_field_set.gc_bookkeeping.done.8
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_test_json_large_string_emitters_ts__run(i64 %this_closure) #6 {
entry.0:
  %r1 = call double @perry_fn_test_json_large_string_emitters_ts__run()
  ret double %r1
}

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_test_json_large_string_emitters_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @test_json_large_string_emitters_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 {
entry.0:
  call void @js_set_process_entry_path(ptr @test_json_large_string_emitters_ts_.str.0, i32 93)
  call void @js_gc_init()
  call void @js_gc_write_barriers_emitted(i32 1)
  call void @perry_macos_bundle_chdir()
  call void @__perry_init_strings_test_json_large_string_emitters_ts()
  %r1 = call double @perry_fn_test_json_large_string_emitters_ts__run()
  %r2 = call i32 @js_promise_run_microtasks_event_loop()
  %r3 = call i32 @js_promise_run_microtasks_event_loop()
  %r4 = call i32 @js_promise_run_microtasks_event_loop()
  %r5 = call i32 @js_promise_run_microtasks_event_loop()
  call void @js_run_stdlib_pump()
  br label %event_loop.header.1

event_loop.header.1:                              ; preds = %event_loop.body_wait.6, %event_loop.body_check.5, %entry.0
  %r6 = call i32 @js_event_loop_host_driven()
  %r7 = icmp ne i32 %r6, 0
  br i1 %r7, label %event_loop.host_return.3, label %event_loop.check_pending.2

event_loop.check_pending.2:                       ; preds = %event_loop.header.1
  %r8 = call i32 @js_timer_has_pending()
  %r9 = call i32 @js_callback_timer_has_pending()
  %r10 = call i32 @js_interval_timer_has_pending()
  %r11 = call i32 @js_stdlib_has_active_handles()
  %r12 = call i32 @js_bun_ffi_has_active_threadsafe_callbacks()
  %r13 = call i32 @js_microtasks_pending()
  %r14 = or i32 %r8, %r9
  %r15 = or i32 %r10, %r11
  %r16 = or i32 %r15, %r12
  %r17 = or i32 %r14, %r16
  %r18 = or i32 %r17, 0
  %r19 = or i32 %r18, %r13
  %r20 = icmp ne i32 %r19, 0
  br i1 %r20, label %event_loop.body.4, label %event_loop.exit.7

event_loop.host_return.3:                         ; preds = %event_loop.header.1
  call void @js_typed_feedback_maybe_dump_trace()
  ret i32 0

event_loop.body.4:                                ; preds = %event_loop.check_pending.2
  %r21 = call i32 @js_promise_run_microtasks_event_loop()
  call void @js_run_stdlib_pump()
  br label %event_loop.body_check.5

event_loop.body_check.5:                          ; preds = %event_loop.body.4
  %r22 = call i32 @js_timer_has_pending()
  %r23 = call i32 @js_callback_timer_has_pending()
  %r24 = call i32 @js_interval_timer_has_pending()
  %r25 = call i32 @js_stdlib_has_active_handles()
  %r26 = call i32 @js_bun_ffi_has_active_threadsafe_callbacks()
  %r27 = call i32 @js_microtasks_pending()
  %r28 = or i32 %r22, %r23
  %r29 = or i32 %r24, %r25
  %r30 = or i32 %r29, %r26
  %r31 = or i32 %r28, %r30
  %r32 = or i32 %r31, 0
  %r33 = or i32 %r32, %r27
  %r34 = icmp ne i32 %r33, 0
  br i1 %r34, label %event_loop.body_wait.6, label %event_loop.header.1

event_loop.body_wait.6:                           ; preds = %event_loop.body_check.5
  call void @js_wait_for_event()
  br label %event_loop.header.1

event_loop.exit.7:                                ; preds = %event_loop.check_pending.2
  call void @js_process_emit_before_exit_pending()
  %r35 = call i32 @js_promise_run_microtasks_event_loop()
  call void @js_process_run_exit_sequence()
  call void @js_process_run_finalization_exit()
  %r36 = call i32 @js_promise_run_promise_jobs()
  call void @js_trace_events_flush_output()
  call void @js_promise_report_unhandled_rejections()
  call void @js_gc_release_current_thread_collection_side_allocations()
  %r37 = call i32 @js_process_pending_exit_code()
  call void @js_typed_feedback_maybe_dump_trace()
  ret i32 %r37
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_large_string_emitters_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.0.bytes, i32 0)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @test_json_large_string_emitters_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.1.bytes, i32 31)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @test_json_large_string_emitters_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.2.bytes, i32 4)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @test_json_large_string_emitters_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.3.bytes, i32 4)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @test_json_large_string_emitters_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.4.bytes, i32 3)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @test_json_large_string_emitters_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.5.bytes, i32 6)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @test_json_large_string_emitters_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.6.bytes, i32 4)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @test_json_large_string_emitters_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.7.bytes, i32 1)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @test_json_large_string_emitters_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.7.handle to i64))
  %r25 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.8.bytes, i32 9)
  %r26 = call double @js_nanbox_string(i64 %r25)
  store double %r26, ptr @test_json_large_string_emitters_ts_.str.8.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.8.handle to i64))
  %r28 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.9.bytes, i32 37)
  %r29 = call double @js_nanbox_string(i64 %r28)
  store double %r29, ptr @test_json_large_string_emitters_ts_.str.9.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.9.handle to i64))
  %r31 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.10.bytes, i32 13)
  %r32 = call double @js_nanbox_string(i64 %r31)
  store double %r32, ptr @test_json_large_string_emitters_ts_.str.10.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.10.handle to i64))
  %r34 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.11.bytes, i32 1)
  %r35 = call double @js_nanbox_string(i64 %r34)
  store double %r35, ptr @test_json_large_string_emitters_ts_.str.11.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.11.handle to i64))
  %r37 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.12.bytes, i32 8)
  %r38 = call double @js_nanbox_string(i64 %r37)
  store double %r38, ptr @test_json_large_string_emitters_ts_.str.12.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.12.handle to i64))
  %r40 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.13.bytes, i32 17)
  %r41 = call double @js_nanbox_string(i64 %r40)
  store double %r41, ptr @test_json_large_string_emitters_ts_.str.13.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.13.handle to i64))
  %r43 = call i64 @js_string_from_wtf8_bytes(ptr @test_json_large_string_emitters_ts_.str.14.bytes, i32 3)
  %r44 = call double @js_nanbox_string(i64 %r43)
  store double %r44, ptr @test_json_large_string_emitters_ts_.str.14.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.14.handle to i64))
  %r46 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.15.bytes, i32 11)
  %r47 = call double @js_nanbox_string(i64 %r46)
  store double %r47, ptr @test_json_large_string_emitters_ts_.str.15.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.15.handle to i64))
  %r49 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.16.bytes, i32 13)
  %r50 = call double @js_nanbox_string(i64 %r49)
  store double %r50, ptr @test_json_large_string_emitters_ts_.str.16.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.16.handle to i64))
  %r52 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.17.bytes, i32 6)
  %r53 = call double @js_nanbox_string(i64 %r52)
  store double %r53, ptr @test_json_large_string_emitters_ts_.str.17.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.17.handle to i64))
  %r55 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.18.bytes, i32 6)
  %r56 = call double @js_nanbox_string(i64 %r55)
  store double %r56, ptr @test_json_large_string_emitters_ts_.str.18.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.18.handle to i64))
  %r58 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.19.bytes, i32 6)
  %r59 = call double @js_nanbox_string(i64 %r58)
  store double %r59, ptr @test_json_large_string_emitters_ts_.str.19.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.19.handle to i64))
  %r61 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.20.bytes, i32 2)
  %r62 = call double @js_nanbox_string(i64 %r61)
  store double %r62, ptr @test_json_large_string_emitters_ts_.str.20.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.20.handle to i64))
  %r64 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.21.bytes, i32 1)
  %r65 = call double @js_nanbox_string(i64 %r64)
  store double %r65, ptr @test_json_large_string_emitters_ts_.str.21.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.21.handle to i64))
  %r67 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.22.bytes, i32 22)
  %r68 = call double @js_nanbox_string(i64 %r67)
  store double %r68, ptr @test_json_large_string_emitters_ts_.str.22.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.22.handle to i64))
  %r70 = call i64 @js_string_from_bytes(ptr @test_json_large_string_emitters_ts_.str.23.bytes, i32 4)
  %r71 = call double @js_nanbox_string(i64 %r70)
  store double %r71, ptr @test_json_large_string_emitters_ts_.str.23.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_large_string_emitters_ts_.str.23.handle to i64))
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_test_json_large_string_emitters_ts__run, ptr @test_json_large_string_emitters_ts_.str.1, i32 3)
  call void @js_register_function_name_static(ptr @perry_fn_test_json_large_string_emitters_ts__run, ptr @test_json_large_string_emitters_ts_.str.1, i32 3)
  call void @js_register_function_name_static(ptr @test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47_constructor, ptr @test_json_large_string_emitters_ts_.str.2, i32 32)
  call void @js_register_function_name_static(ptr @test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c_constructor, ptr @test_json_large_string_emitters_ts_.str.3, i32 32)
  call void @js_register_function_name_static(ptr @test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3_constructor, ptr @test_json_large_string_emitters_ts_.str.4, i32 32)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_test_json_large_string_emitters_ts__run, ptr @test_json_large_string_emitters_ts_.str.5, i32 1859, i32 0)
  call void @js_register_function_source_static(ptr @perry_closure_test_json_large_string_emitters_ts__2, ptr @test_json_large_string_emitters_ts_.str.6, i32 462, i32 0)
  %r73 = call i64 @js_build_class_keys_array(i32 1, i32 0, ptr null, i32 0)
  store i64 %r73, ptr @perry_class_keys_test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47, align 8
  call void @js_write_barrier_root_heap_word(i64 %r73)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47 to i64))
  %r75 = call i32 @js_object_shape_id_for_keys(i64 %r73, i32 0)
  store i32 %r75, ptr @perry_class_shape_id_test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47, align 4
  %r76 = zext i32 %r75 to i64
  %r77 = shl nuw i64 %r76, 32
  %r78 = or i64 %r77, 1
  %r79 = insertelement <2 x i64> <i64 172872434178, i64 0>, i64 %r78, i32 1
  store <2 x i64> %r79, ptr @perry_class_header_image_test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47, align 8
  %r80 = call i64 @js_build_class_keys_array(i32 2, i32 2, ptr @perry_class_keys_packed_test_json_large_string_emitters_ts__1, i32 8)
  store i64 %r80, ptr @perry_class_keys_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, align 8
  call void @js_write_barrier_root_heap_word(i64 %r80)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c to i64))
  %r82 = call i32 @js_gc_typed_shape_id_for_keys(i32 2, i64 %r80, i32 2, ptr @perry_typed_shape_raw_f64_mask_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, i32 1, ptr @perry_typed_shape_mask_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, i32 1)
  store i32 %r82, ptr @perry_class_shape_id_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, align 4
  %r83 = zext i32 %r82 to i64
  %r84 = shl nuw i64 %r83, 32
  %r85 = or i64 %r84, 2
  %r86 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r85, i32 1
  store <2 x i64> %r86, ptr @perry_class_header_image_test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c, align 8
  %r87 = call i64 @js_build_class_keys_array(i32 3, i32 1, ptr @perry_class_keys_packed_test_json_large_string_emitters_ts__2, i32 5)
  store i64 %r87, ptr @perry_class_keys_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, align 8
  call void @js_write_barrier_root_heap_word(i64 %r87)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3 to i64))
  %r89 = call i32 @js_gc_typed_shape_id_for_keys(i32 3, i64 %r87, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, i32 1)
  store i32 %r89, ptr @perry_class_shape_id_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, align 4
  %r90 = zext i32 %r89 to i64
  %r91 = shl nuw i64 %r90, 32
  %r92 = or i64 %r91, 3
  %r93 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r92, i32 1
  store <2 x i64> %r93, ptr @perry_class_header_image_test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3, align 8
  call void @js_register_class_constructor(i64 1, i64 ptrtoint (ptr @test_json_large_string_emitters_ts____AnonShape_a7449f8c3df3dc47_constructor to i64), i64 0, i64 0)
  call void @js_register_class_constructor(i64 2, i64 ptrtoint (ptr @test_json_large_string_emitters_ts____AnonShape_6ef7d34fbe1f1d2c_constructor to i64), i64 2, i64 0)
  call void @js_register_class_constructor(i64 3, i64 ptrtoint (ptr @test_json_large_string_emitters_ts____AnonShape_f0c6d3c63b1d92d3_constructor to i64), i64 1, i64 0)
  call void @js_register_class_id(i32 1)
  call void @js_register_class_id(i32 2)
  call void @js_register_class_id(i32 3)
  call void @js_register_anon_shape_class_id(i32 1)
  call void @js_register_anon_shape_class_id(i32 2)
  call void @js_register_anon_shape_class_id(i32 3)
  call void @js_register_class_length(i32 1, i32 0)
  call void @js_register_class_length(i32 2, i32 2)
  call void @js_register_class_length(i32 3, i32 1)
  call void @js_register_closure_arity(ptr @perry_closure_test_json_large_string_emitters_ts__2, i32 2)
  call void @js_register_closure_length(ptr @perry_closure_test_json_large_string_emitters_ts__2, i32 2)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_test_json_large_string_emitters_ts__run, i32 0)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_test_json_large_string_emitters_ts__run, i32 0)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_test_json_large_string_emitters_ts__run)
  call void @js_register_closure_strict_function(ptr @perry_closure_test_json_large_string_emitters_ts__2)
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_large_string_emitters_ts() #6 {
entry.0:
  call void @__perry_init_strings_test_json_large_string_emitters_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { "gc-leaf-function" }

!0 = !{}
