; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/dominant-token-dispatch-r43/candidate-primitive-keys-ir-native/.perry-trace/llvm/test_json_primitive_tojson_keys_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@test_json_primitive_tojson_keys_ts_.str.0 = private unnamed_addr constant [94 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/test-files/test_json_primitive_tojson_keys.ts\00"
@test_json_primitive_tojson_keys_ts_.str.0.bytes = private unnamed_addr constant [2 x i8] c":\00"
@test_json_primitive_tojson_keys_ts_.str.1.bytes = private unnamed_addr constant [5 x i8] c"text\00"
@test_json_primitive_tojson_keys_ts_.str.2.bytes = private unnamed_addr constant [10 x i8] c"reentrant\00"
@test_json_primitive_tojson_keys_ts_.str.3.bytes = private unnamed_addr constant [6 x i8] c"inner\00"
@test_json_primitive_tojson_keys_ts_.str.4.bytes = private unnamed_addr constant [5 x i8] c"big:\00"
@test_json_primitive_tojson_keys_ts_.str.5.bytes = private unnamed_addr constant [7 x i8] c"toJSON\00"
@test_json_primitive_tojson_keys_ts_.str.6.bytes = private unnamed_addr constant [7 x i8] c"before\00"
@test_json_primitive_tojson_keys_ts_.str.7.bytes = private unnamed_addr constant [6 x i8] c"after\00"
@test_json_primitive_tojson_keys_ts_.str.8.bytes = private unnamed_addr constant [7 x i8] c"scalar\00"
@test_json_primitive_tojson_keys_ts_.str.9.bytes = private unnamed_addr constant [6 x i8] c"first\00"
@test_json_primitive_tojson_keys_ts_.str.10.bytes = private unnamed_addr constant [5 x i8] c"flag\00"
@test_json_primitive_tojson_keys_ts_.str.11.bytes = private unnamed_addr constant [7 x i8] c"nested\00"
@test_json_primitive_tojson_keys_ts_.str.12.bytes = private unnamed_addr constant [5 x i8] c"list\00"
@test_json_primitive_tojson_keys_ts_.str.13.bytes = private unnamed_addr constant [7 x i8] c"inside\00"
@test_json_primitive_tojson_keys_ts_.str.14.bytes = private unnamed_addr constant [4 x i8] c"big\00"
@test_json_primitive_tojson_keys_ts_.str.15.bytes = private unnamed_addr constant [6 x i8] c"plain\00"
@test_json_primitive_tojson_keys_ts_.str.16.bytes = private unnamed_addr constant [2 x i8] c"s\00"
@test_json_primitive_tojson_keys_ts_.str.17.bytes = private unnamed_addr constant [6 x i8] c"array\00"
@test_json_primitive_tojson_keys_ts_.str.18.bytes = private unnamed_addr constant [7 x i8] c"BigInt\00"
@test_json_primitive_tojson_keys_ts_.str.19.bytes = private unnamed_addr constant [10 x i8] c"prototype\00"
@test_json_primitive_tojson_keys_ts_.str.20.bytes = private unnamed_addr constant [5 x i8] c"last\00"
@perry_class_keys_packed_test_json_primitive_tojson_keys_ts__0 = private unnamed_addr constant [8 x i8] c"toJSON\00\00"
@perry_class_keys_packed_test_json_primitive_tojson_keys_ts__1 = private unnamed_addr constant [14 x i8] c"before\00after\00\00"
@perry_class_keys_packed_test_json_primitive_tojson_keys_ts__2 = private unnamed_addr constant [36 x i8] c"scalar\00text\00first\00flag\00nested\00list\00\00"
@perry_class_keys_packed_test_json_primitive_tojson_keys_ts__3 = private unnamed_addr constant [15 x i8] c"before\00inside\00\00"
@perry_class_keys_packed_test_json_primitive_tojson_keys_ts__4 = private unnamed_addr constant [18 x i8] c"before\00big\00after\00\00"
@perry_class_keys_packed_test_json_primitive_tojson_keys_ts__5 = private unnamed_addr constant [5 x i8] c"big\00\00"
@test_json_primitive_tojson_keys_ts_.str.1 = private unnamed_addr constant [9 x i8] c"identity\00"
@test_json_primitive_tojson_keys_ts_.str.2 = private unnamed_addr constant [9 x i8] c"makeHook\00"
@test_json_primitive_tojson_keys_ts_.str.3 = private unnamed_addr constant [33 x i8] c"new __AnonShape_d4a003cc10c06cd7\00"
@test_json_primitive_tojson_keys_ts_.str.4 = private unnamed_addr constant [33 x i8] c"new __AnonShape_678f61a8283ff599\00"
@test_json_primitive_tojson_keys_ts_.str.5 = private unnamed_addr constant [33 x i8] c"new __AnonShape_79851f090ba2d05b\00"
@test_json_primitive_tojson_keys_ts_.str.6 = private unnamed_addr constant [33 x i8] c"new __AnonShape_b3e89da2b61a9043\00"
@test_json_primitive_tojson_keys_ts_.str.7 = private unnamed_addr constant [33 x i8] c"new __AnonShape_031f75f7a258657b\00"
@test_json_primitive_tojson_keys_ts_.str.8 = private unnamed_addr constant [33 x i8] c"new __AnonShape_c95d02397d239d77\00"
@test_json_primitive_tojson_keys_ts_.str.9 = private unnamed_addr constant [7 x i8] c"toJSON\00"
@test_json_primitive_tojson_keys_ts_.str.10 = private unnamed_addr constant [66 x i8] c"function identity(key: string, value: any): any { return value; }\00"
@test_json_primitive_tojson_keys_ts_.str.11 = private unnamed_addr constant [127 x i8] c"function makeHook(label: string): any {\0A    return { toJSON(key: string) { calls.push(label + ':' + key); return label; } };\0A}\00"
@test_json_primitive_tojson_keys_ts_.str.12 = private unnamed_addr constant [69 x i8] c"toJSON(key: string) { calls.push(label + ':' + key); return label; }\00"
@test_json_primitive_tojson_keys_ts_.str.13 = private unnamed_addr constant [244 x i8] c"function(key: string, v: any): any {\0A    callbackKeys.push(key);\0A    if (key === 'text') {\0A        const inner = { before: 1, inside: makeHook('reentrant') };\0A        console.log('inner', JSON.stringify(inner, identity));\0A    }\0A    return v;\0A}\00"
@test_json_primitive_tojson_keys_ts_.str.14 = private unnamed_addr constant [55 x i8] c"function(key: string): string { return 'big:' + key; }\00"
@test_json_primitive_tojson_keys_ts_.str.15 = private unnamed_addr constant [85 x i8] c"function(key: string, v: any): any { return typeof v === 'bigint' ? String(v) : v; }\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_test_json_primitive_tojson_keys_ts = internal global i32 0
@perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7 = internal global i64 0
@perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7 = global i32 0
@perry_class_header_image_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7 = internal global <2 x i64> zeroinitializer
@perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599 = internal global i64 0
@perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599 = global i32 0
@perry_class_header_image_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599 = internal global <2 x i64> zeroinitializer
@perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b = internal global i64 0
@perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b = global i32 0
@perry_class_header_image_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b = internal global <2 x i64> zeroinitializer
@perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043 = internal global i64 0
@perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043 = global i32 0
@perry_class_header_image_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043 = internal global <2 x i64> zeroinitializer
@perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b = internal global i64 0
@perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b = global i32 0
@perry_class_header_image_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b = internal global <2 x i64> zeroinitializer
@perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77 = internal global i64 0
@perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77 = global i32 0
@perry_class_header_image_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77 = internal global <2 x i64> zeroinitializer
@perry_global_test_json_primitive_tojson_keys_ts__0 = global double 0x7FFC000000000001
@perry_global_test_json_primitive_tojson_keys_ts__2 = global double 0x7FFC000000000001
@perry_ic_test_json_primitive_tojson_keys_ts__16 = private global ptr null
@perry_ic_test_json_primitive_tojson_keys_ts__17 = private global ptr null
@perry_ic_test_json_primitive_tojson_keys_ts__19 = private global ptr null
@test_json_primitive_tojson_keys_ts_.str.0.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.1.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.2.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.3.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.4.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.5.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.6.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.7.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.8.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.9.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.10.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.11.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.12.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.13.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.14.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.15.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.16.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.17.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.18.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.19.handle = internal global double 0.000000e+00
@test_json_primitive_tojson_keys_ts_.str.20.handle = internal global double 0.000000e+00
@perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7 = private unnamed_addr constant [1 x i64] [i64 1]
@perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599 = private unnamed_addr constant [1 x i64] [i64 2]
@perry_typed_shape_raw_f64_mask_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b = private unnamed_addr constant [1 x i64] [i64 1]
@perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b = private unnamed_addr constant [1 x i64] [i64 54]
@perry_typed_shape_raw_f64_mask_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043 = private unnamed_addr constant [1 x i64] [i64 1]
@perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043 = private unnamed_addr constant [1 x i64] [i64 2]
@perry_typed_shape_raw_f64_mask_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b = private unnamed_addr constant [1 x i64] [i64 1]
@perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b = private unnamed_addr constant [1 x i64] [i64 6]
@perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77 = private unnamed_addr constant [1 x i64] [i64 1]

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_16()

declare double @__ic_decl_19()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define internal double @"perry_fn_test_json_primitive_tojson_keys_ts__identity$spec_b_b"(double %arg3, double %arg4) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %arg3 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg4 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  ret double %r3
}

; Function Attrs: inlinehint optsize
define internal double @"perry_fn_test_json_primitive_tojson_keys_ts__identity$generic"(double %arg3, double %arg4) #7 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %arg3 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg4 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  ret double %r3
}

; Function Attrs: noinline optsize
define double @perry_fn_test_json_primitive_tojson_keys_ts__identity(double %arg3, double %arg4) #8 {
entry.0:
  %r1 = call i32 @js_typed_string_arg_guard(double %arg3)
  %r2 = icmp ne i32 %r1, 0
  br i1 %r2, label %spec_public.fast.1, label %spec_public.fallback.2

spec_public.fast.1:                               ; preds = %entry.0
  %r3 = call double @"perry_fn_test_json_primitive_tojson_keys_ts__identity$spec_b_b"(double %arg3, double %arg4)
  ret double %r3

spec_public.fallback.2:                           ; preds = %entry.0
  %r4 = call double @"perry_fn_test_json_primitive_tojson_keys_ts__identity$generic"(double %arg3, double %arg4)
  ret double %r4
}

; Function Attrs: inlinehint optsize
define double @perry_fn_test_json_primitive_tojson_keys_ts__makeHook(double %arg5) #7 gc "statepoint-example" {
entry.0:
  %r4 = alloca [1 x i64], align 8
  %r14 = load i64, ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7, align 8
  %rs4gc.s1 = inttoptr i64 %r14 to ptr addrspace(1)
  %r17 = load i32, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7, align 4
  %rs4gc.b2 = bitcast double %arg5 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r2.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r2.rs4o = call i64 asm "", "=r,0"(i64 %r2.rs4i) #9
  %r2 = bitcast i64 %r2.rs4o to double
  %r3 = bitcast double %r2 to i64
  %r5 = getelementptr i64, ptr %r4, i64 0
  store i64 %r3, ptr %r5, align 8
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr, i32, ptr)) @js_closure_alloc_init, i32 3, i32 0, ptr @perry_closure_test_json_primitive_tojson_keys_ts__2, i32 1, ptr %r4, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s1) ]
  %r69 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token)
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s1, %rs4gc.s1)
  %r7 = or i64 %r69, 9222527611924643840
  %r8 = bitcast i64 %r7 to double
  %rs4gc.s3 = inttoptr i64 %r7 to ptr addrspace(1)
  %r10.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r10 = call i64 asm "", "=r,0"(i64 %r10.rs4i) #9
  %r11 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r12 = icmp ne i32 %r11, 0
  br i1 %r12, label %shadow.root.barrier.1, label %shadow.root.barrier.done.2

shadow.root.barrier.1:                            ; preds = %entry.0
  call void @js_write_barrier_root_nanbox(i64 %r10) #9
  br label %shadow.root.barrier.done.2

shadow.root.barrier.done.2:                       ; preds = %shadow.root.barrier.1, %entry.0
  %r15.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1.relocated to i64
  %r15 = call i64 asm "", "=r,0"(i64 %r15.rs4i) #9
  %statepoint_token10 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 1, i32 0, i32 1, i64 %r15, i32 %r17, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3) ]
  %r1911 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token10)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token10, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  call void @js_gc_declare_typed_shape_layout(i64 %r1911, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7, i32 1) #9
  %rs4gc.s4 = inttoptr i64 %r1911 to ptr addrspace(1)
  %r21.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s4 to i64
  %r21 = call i64 asm "", "=r,0"(i64 %r21.rs4i) #9
  %r22 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r23 = icmp ne i32 %r22, 0
  br i1 %r23, label %shadow.root.barrier.3, label %shadow.root.barrier.done.4

shadow.root.barrier.3:                            ; preds = %shadow.root.barrier.done.2
  call void @js_write_barrier_root_nanbox(i64 %r21) #9
  br label %shadow.root.barrier.done.4

shadow.root.barrier.done.4:                       ; preds = %shadow.root.barrier.3, %shadow.root.barrier.done.2
  %r24 = or i64 %r1911, 9222527611924643840
  %r25 = bitcast i64 %r24 to double
  %r26.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3.relocated to i64
  %r26 = call i64 asm "", "=r,0"(i64 %r26.rs4i) #9
  %r27 = bitcast i64 %r26 to double
  %r28 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r29 = icmp eq i8 %r28, 0
  %r30 = inttoptr i64 %r1911 to ptr
  %r31 = getelementptr i8, ptr %r30, i64 -6
  %r32 = load i16, ptr %r31, align 2
  %r33 = and i16 %r32, 4096
  %r34 = icmp ne i16 %r33, 0
  %r35 = and i1 %r29, %r34
  br i1 %r35, label %ctor_prologue.fast.5, label %ctor_prologue.slow.6

ctor_prologue.fast.5:                             ; preds = %shadow.root.barrier.done.4
  %r36 = inttoptr i64 %r1911 to ptr
  %r37 = getelementptr i8, ptr %r36, i64 16
  %r38 = bitcast double %r25 to i64
  %r39 = getelementptr double, ptr %r37, i64 0
  store double %r27, ptr %r39, align 8
  %r40 = ptrtoint ptr %r39 to i64
  %r41 = bitcast double %r27 to i64
  %r42 = lshr i64 %r41, 48
  %r43 = icmp eq i64 %r42, 0
  %r44 = icmp uge i64 %r41, 4096
  %r45 = and i1 %r43, %r44
  %r46 = icmp eq i64 %r42, 32765
  %r47 = icmp eq i64 %r42, 32767
  %r48 = icmp eq i64 %r42, 32762
  %r49 = or i1 %r46, %r47
  %r50 = or i1 %r49, %r48
  %r51 = or i1 %r50, %r45
  br i1 %r51, label %ctor_prologue.barrier.maybe.8, label %ctor_prologue.barrier.done.10

ctor_prologue.slow.6:                             ; preds = %shadow.root.barrier.done.4
  %statepoint_token12 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7_constructor, i32 2, i32 0, double %r25, double %r27, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4) ]
  %r6013 = call double @llvm.experimental.gc.result.f64(token %statepoint_token12)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token12, i32 0, i32 0) ; (%rs4gc.s4, %rs4gc.s4)
  br label %ctor_prologue.merge.7

ctor_prologue.merge.7:                            ; preds = %ctor_prologue.barrier.done.10, %ctor_prologue.slow.6
  %.0 = phi ptr addrspace(1) [ %rs4gc.s4, %ctor_prologue.barrier.done.10 ], [ %rs4gc.s4.relocated, %ctor_prologue.slow.6 ]
  %r61 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.10 ], [ %r6013, %ctor_prologue.slow.6 ]
  %r62.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r62 = call i64 asm "", "=r,0"(i64 %r62.rs4i) #9
  %r63 = or i64 %r62, 9222527611924643840
  %r64 = bitcast i64 %r63 to double
  %r65 = bitcast double %r61 to i64
  %r66 = icmp eq i64 %r65, 9222246136947933185
  br i1 %r66, label %ctor_ret.merge.12, label %ctor_ret.override.11

ctor_prologue.barrier.maybe.8:                    ; preds = %ctor_prologue.fast.5
  %r52 = sub i64 %r1911, 7
  %r53 = inttoptr i64 %r52 to ptr
  %r54 = load i8, ptr %r53, align 1
  %r55 = and i8 %r54, 32
  %r56 = icmp ne i8 %r55, 0
  %r57 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r58 = icmp ne i32 %r57, 0
  %r59 = or i1 %r56, %r58
  br i1 %r59, label %ctor_prologue.barrier.9, label %ctor_prologue.barrier.done.10

ctor_prologue.barrier.9:                          ; preds = %ctor_prologue.barrier.maybe.8
  call void @js_write_barrier_slot_validated_parent(i64 %r1911, i64 %r40, i64 %r41) #9
  br label %ctor_prologue.barrier.done.10

ctor_prologue.barrier.done.10:                    ; preds = %ctor_prologue.barrier.9, %ctor_prologue.barrier.maybe.8, %ctor_prologue.fast.5
  br label %ctor_prologue.merge.7

ctor_ret.override.11:                             ; preds = %ctor_prologue.merge.7
  %statepoint_token14 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r64, double %r61, i32 0, i32 0, i32 0)
  %r6715 = call double @llvm.experimental.gc.result.f64(token %statepoint_token14)
  br label %ctor_ret.merge.12

ctor_ret.merge.12:                                ; preds = %ctor_ret.override.11, %ctor_prologue.merge.7
  %r68 = phi double [ %r64, %ctor_prologue.merge.7 ], [ %r6715, %ctor_ret.override.11 ]
  ret double %r68
}

; Function Attrs: optsize
define double @perry_closure_test_json_primitive_tojson_keys_ts__2(i64 %this_closure, double %arg6) #6 gc "statepoint-example" {
entry.0:
  %r20 = alloca [32 x double], align 8
  %rs4gc.b1 = bitcast double %arg6 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %r3 = or i64 %this_closure, 9222527611924643840
  %rs4gc.s2 = inttoptr i64 %r3 to ptr addrspace(1)
  %r4 = load double, ptr @perry_global_test_json_primitive_tojson_keys_ts__0, align 8
  %r5 = bitcast double %r4 to i64
  %rs4gc.s3 = inttoptr i64 %r5 to ptr addrspace(1)
  %r7.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r7 = call i64 asm "", "=r,0"(i64 %r7.rs4i) #9
  %r8 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r9 = icmp ne i32 %r8, 0
  br i1 %r9, label %shadow.root.barrier.1, label %shadow.root.barrier.done.2

shadow.root.barrier.1:                            ; preds = %entry.0
  call void @js_write_barrier_root_nanbox(i64 %r7) #9
  br label %shadow.root.barrier.done.2

shadow.root.barrier.done.2:                       ; preds = %shadow.root.barrier.1, %entry.0
  %r10.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r10 = call i64 asm "", "=r,0"(i64 %r10.rs4i) #9
  %r11 = and i64 %r10, 281474976710655
  %r12 = add nuw nsw i64 %r11, 16
  %r13 = inttoptr i64 %r12 to ptr
  %r14 = load i64, ptr %r13, align 8
  %r15 = bitcast i64 %r14 to double
  %r16 = and i64 %r14, -281474976710656
  %r17 = icmp ne i64 %r16, 9223090561878065152
  br i1 %r17, label %str_addref.done.4, label %str_addref.call.3

str_addref.call.3:                                ; preds = %shadow.root.barrier.done.2
  call void @js_string_addref_if_heap_string(double %r15) #9
  br label %str_addref.done.4

str_addref.done.4:                                ; preds = %str_addref.call.3, %shadow.root.barrier.done.2
  %r18 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.0.handle, align 8
  %r19.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r19.rs4o = call i64 asm "", "=r,0"(i64 %r19.rs4i) #9
  %r19 = bitcast i64 %r19.rs4o to double
  %r21 = getelementptr double, ptr %r20, i64 0
  store double %r15, ptr %r21, align 8
  %r22 = getelementptr double, ptr %r20, i64 1
  store double %r18, ptr %r22, align 8
  %r23 = getelementptr double, ptr %r20, i64 2
  store double %r19, ptr %r23, align 8
  %r24 = ptrtoint ptr %r20 to i64
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r24, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s2, ptr addrspace(1) %rs4gc.s3) ]
  %r251 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token)
  %rs4gc.s2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s2, %rs4gc.s2)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s3, %rs4gc.s3)
  %r26 = or i64 %r251, 9223090561878065152
  %r27 = bitcast i64 %r26 to double
  %r28 = bitcast i64 %r26 to double
  %r29.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3.relocated to i64
  %r29 = call i64 asm "", "=r,0"(i64 %r29.rs4i) #9
  %r30 = bitcast i64 %r29 to double
  %r31 = load double, ptr @perry_global_test_json_primitive_tojson_keys_ts__0, align 8
  %r32 = bitcast double %r31 to i64
  %r34 = and i64 %r29, 281474976710655
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r34, double %r28, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s2.relocated) ]
  %r353 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token2)
  %rs4gc.s2.relocated4 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token2, i32 0, i32 0) ; (%rs4gc.s2.relocated, %rs4gc.s2.relocated)
  %r36 = or i64 %r353, 9222527611924643840
  %r37 = bitcast i64 %r36 to double
  %r33 = icmp eq i64 %r32, %r29
  br i1 %r33, label %apush.spec.writeback.5, label %apush.spec.done.6

apush.spec.writeback.5:                           ; preds = %str_addref.done.4
  store double %r37, ptr @perry_global_test_json_primitive_tojson_keys_ts__0, align 8
  %r38 = bitcast double %r37 to i64
  call void @js_write_barrier_root_nanbox(i64 %r38) #9
  br label %apush.spec.done.6

apush.spec.done.6:                                ; preds = %apush.spec.writeback.5, %str_addref.done.4
  %r39.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated4 to i64
  %r39 = call i64 asm "", "=r,0"(i64 %r39.rs4i) #9
  %r40 = and i64 %r39, 281474976710655
  %r41 = add nuw nsw i64 %r40, 16
  %r42 = inttoptr i64 %r41 to ptr
  %r43 = load i64, ptr %r42, align 8
  %r44 = bitcast i64 %r43 to double
  %r45 = and i64 %r43, -281474976710656
  %r46 = icmp ne i64 %r45, 9223090561878065152
  br i1 %r46, label %str_addref.done.8, label %str_addref.call.7

str_addref.call.7:                                ; preds = %apush.spec.done.6
  call void @js_string_addref_if_heap_string(double %r44) #9
  br label %str_addref.done.8

str_addref.done.8:                                ; preds = %str_addref.call.7, %apush.spec.done.6
  ret double %r44
}

; Function Attrs: optsize
define double @perry_closure_test_json_primitive_tojson_keys_ts__6(i64 %this_closure, double %arg16, double %arg17) #6 gc "statepoint-example" {
entry.0:
  %r48 = load i64, ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043, align 8
  %rs4gc.s2 = inttoptr i64 %r48 to ptr addrspace(1)
  %r51 = load i32, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043, align 4
  %rs4gc.b3 = bitcast double %arg16 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %rs4gc.b4 = bitcast double %arg17 to i64
  %rs4gc.s4 = inttoptr i64 %rs4gc.b4 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  %r4 = bitcast double %r3 to i64
  %r5 = load double, ptr @perry_global_test_json_primitive_tojson_keys_ts__2, align 8
  %r6 = bitcast double %r5 to i64
  %r7 = and i64 %r6, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r7, double %r3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s2, ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s3) ]
  %r810 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token)
  %rs4gc.s2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s2, %rs4gc.s2)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 2, i32 2) ; (%rs4gc.s3, %rs4gc.s3)
  %r9 = or i64 %r810, 9222527611924643840
  %r10 = bitcast i64 %r9 to double
  store double %r10, ptr @perry_global_test_json_primitive_tojson_keys_ts__2, align 8
  call void @js_write_barrier_root_nanbox(i64 %r9) #9
  %r11.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3.relocated to i64
  %r11.rs4o = call i64 asm "", "=r,0"(i64 %r11.rs4i) #9
  %r11 = bitcast i64 %r11.rs4o to double
  %r12 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.1.handle, align 8
  %r13 = bitcast double %r11 to i64
  %r14 = bitcast double %r12 to i64
  %r15 = icmp eq i64 %r13, %r14
  br i1 %r15, label %streqlit.true.7, label %streqlit.sso.1

streqlit.sso.1:                                   ; preds = %entry.0
  %r16 = icmp eq i64 %r13, 9221406112018359668
  br i1 %r16, label %streqlit.true.7, label %streqlit.tag.2

streqlit.tag.2:                                   ; preds = %streqlit.sso.1
  %r17 = lshr i64 %r13, 48
  %r18 = icmp eq i64 %r17, 32767
  %r19 = and i64 %r13, 281474976710655
  %r20 = icmp ugt i64 %r19, 4095
  %r21 = and i1 %r18, %r20
  br i1 %r21, label %streqlit.len.3, label %streqlit.false.8

streqlit.len.3:                                   ; preds = %streqlit.tag.2
  %r22 = inttoptr i64 %r19 to ptr
  %r23 = getelementptr inbounds nuw i8, ptr %r22, i64 4
  %r24 = load i32, ptr %r23, align 4
  %r25 = icmp eq i32 %r24, 4
  br i1 %r25, label %streqlit.b0.4, label %streqlit.false.8

streqlit.b0.4:                                    ; preds = %streqlit.len.3
  %r26 = getelementptr inbounds nuw i8, ptr %r22, i64 20
  %r27 = load i8, ptr %r26, align 1
  %r28 = icmp eq i8 %r27, 116
  br i1 %r28, label %streqlit.bl.5, label %streqlit.false.8

streqlit.bl.5:                                    ; preds = %streqlit.b0.4
  %r29 = getelementptr inbounds nuw i8, ptr %r22, i64 23
  %r30 = load i8, ptr %r29, align 1
  %r31 = icmp eq i8 %r30, 116
  br i1 %r31, label %streqlit.slow.6, label %streqlit.false.8

streqlit.slow.6:                                  ; preds = %streqlit.bl.5
  %r32 = and i64 %r14, 281474976710655
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r19, i64 %r32, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s2.relocated, ptr addrspace(1) %rs4gc.s4.relocated) ]
  %r3312 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token11)
  %rs4gc.s2.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 0, i32 0) ; (%rs4gc.s2.relocated, %rs4gc.s2.relocated)
  %rs4gc.s4.relocated14 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 1, i32 1) ; (%rs4gc.s4.relocated, %rs4gc.s4.relocated)
  %r34 = icmp ne i32 %r3312, 0
  br label %streqlit.merge.9

streqlit.true.7:                                  ; preds = %streqlit.sso.1, %entry.0
  br label %streqlit.merge.9

streqlit.false.8:                                 ; preds = %streqlit.bl.5, %streqlit.b0.4, %streqlit.len.3, %streqlit.tag.2
  br label %streqlit.merge.9

streqlit.merge.9:                                 ; preds = %streqlit.false.8, %streqlit.true.7, %streqlit.slow.6
  %.048 = phi ptr addrspace(1) [ %rs4gc.s4.relocated, %streqlit.true.7 ], [ %rs4gc.s4.relocated14, %streqlit.slow.6 ], [ %rs4gc.s4.relocated, %streqlit.false.8 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s2.relocated, %streqlit.true.7 ], [ %rs4gc.s2.relocated13, %streqlit.slow.6 ], [ %rs4gc.s2.relocated, %streqlit.false.8 ]
  %r35 = phi i1 [ true, %streqlit.true.7 ], [ false, %streqlit.false.8 ], [ %r34, %streqlit.slow.6 ]
  %r36 = select i1 %r35, i64 9222246136947933188, i64 9222246136947933187
  %r37 = bitcast i64 %r36 to double
  %r38 = icmp eq i64 %r36, 9222246136947933188
  br i1 %r38, label %if.then.10, label %if.else.11

if.then.10:                                       ; preds = %streqlit.merge.9
  %r40 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.2.handle, align 8
  %statepoint_token15 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @perry_fn_test_json_primitive_tojson_keys_ts__makeHook, i32 1, i32 0, double %r40, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.048, ptr addrspace(1) %.0) ]
  %r4116 = call double @llvm.experimental.gc.result.f64(token %statepoint_token15)
  %rs4gc.s4.relocated17 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token15, i32 0, i32 0) ; (%.048, %.048)
  %rs4gc.s2.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token15, i32 1, i32 1) ; (%.0, %.0)
  %r42 = bitcast double %r4116 to i64
  %rs4gc.s5 = inttoptr i64 %r42 to ptr addrspace(1)
  %r44.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s5 to i64
  %r44 = call i64 asm "", "=r,0"(i64 %r44.rs4i) #9
  %r45 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r46 = icmp ne i32 %r45, 0
  br i1 %r46, label %shadow.root.barrier.13, label %shadow.root.barrier.done.14

if.else.11:                                       ; preds = %streqlit.merge.9
  br label %if.merge.12

if.merge.12:                                      ; preds = %shadow.root.barrier.done.32, %if.else.11
  %.1 = phi ptr addrspace(1) [ %rs4gc.s4.relocated47, %shadow.root.barrier.done.32 ], [ %.048, %if.else.11 ]
  %r135.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r135.rs4o = call i64 asm "", "=r,0"(i64 %r135.rs4i) #9
  %r135 = bitcast i64 %r135.rs4o to double
  ret double %r135

shadow.root.barrier.13:                           ; preds = %if.then.10
  call void @js_write_barrier_root_nanbox(i64 %r44) #9
  br label %shadow.root.barrier.done.14

shadow.root.barrier.done.14:                      ; preds = %shadow.root.barrier.13, %if.then.10
  %r49.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated18 to i64
  %r49 = call i64 asm "", "=r,0"(i64 %r49.rs4i) #9
  %statepoint_token19 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 4, i32 0, i32 2, i64 %r49, i32 %r51, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated17, ptr addrspace(1) %rs4gc.s5) ]
  %r5320 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token19)
  %rs4gc.s4.relocated21 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 0, i32 0) ; (%rs4gc.s4.relocated17, %rs4gc.s4.relocated17)
  %rs4gc.s5.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 1, i32 1) ; (%rs4gc.s5, %rs4gc.s5)
  call void @js_gc_declare_typed_shape_layout(i64 %r5320, i32 2, ptr @perry_typed_shape_raw_f64_mask_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043, i32 1, ptr @perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043, i32 1) #9
  %rs4gc.s6 = inttoptr i64 %r5320 to ptr addrspace(1)
  %r55.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r55 = call i64 asm "", "=r,0"(i64 %r55.rs4i) #9
  %r56 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r57 = icmp ne i32 %r56, 0
  br i1 %r57, label %shadow.root.barrier.15, label %shadow.root.barrier.done.16

shadow.root.barrier.15:                           ; preds = %shadow.root.barrier.done.14
  call void @js_write_barrier_root_nanbox(i64 %r55) #9
  br label %shadow.root.barrier.done.16

shadow.root.barrier.done.16:                      ; preds = %shadow.root.barrier.15, %shadow.root.barrier.done.14
  %r58 = or i64 %r5320, 9222527611924643840
  %r59 = bitcast i64 %r58 to double
  %r60.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s5.relocated to i64
  %r60 = call i64 asm "", "=r,0"(i64 %r60.rs4i) #9
  %r61 = bitcast i64 %r60 to double
  %r62 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r63 = icmp eq i8 %r62, 0
  %r64 = inttoptr i64 %r5320 to ptr
  %r65 = getelementptr i8, ptr %r64, i64 -6
  %r66 = load i16, ptr %r65, align 2
  %r67 = and i16 %r66, 4096
  %r68 = icmp ne i16 %r67, 0
  %r69 = and i1 %r63, %r68
  br i1 %r69, label %ctor_prologue.fast.17, label %ctor_prologue.slow.18

ctor_prologue.fast.17:                            ; preds = %shadow.root.barrier.done.16
  %r74 = inttoptr i64 %r5320 to ptr
  %r75 = getelementptr i8, ptr %r74, i64 16
  %r76 = bitcast double %r59 to i64
  %r77 = getelementptr double, ptr %r75, i64 0
  store double 1.000000e+00, ptr %r77, align 8
  %r78 = ptrtoint ptr %r77 to i64
  %r80 = getelementptr double, ptr %r75, i64 1
  store double %r61, ptr %r80, align 8
  %r81 = ptrtoint ptr %r80 to i64
  %r82 = bitcast double %r61 to i64
  %r83 = lshr i64 %r82, 48
  %r84 = icmp eq i64 %r83, 0
  %r85 = icmp uge i64 %r82, 4096
  %r86 = and i1 %r84, %r85
  %r87 = icmp eq i64 %r83, 32765
  %r88 = icmp eq i64 %r83, 32767
  %r89 = icmp eq i64 %r83, 32762
  %r90 = or i1 %r87, %r88
  %r91 = or i1 %r90, %r89
  %r92 = or i1 %r91, %r86
  br i1 %r92, label %ctor_prologue.barrier.maybe.20, label %ctor_prologue.barrier.done.22

ctor_prologue.slow.18:                            ; preds = %shadow.root.barrier.done.16
  %statepoint_token22 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double)) @test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043_constructor, i32 3, i32 0, double %r59, double 1.000000e+00, double %r61, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated21, ptr addrspace(1) %rs4gc.s6) ]
  %r10123 = call double @llvm.experimental.gc.result.f64(token %statepoint_token22)
  %rs4gc.s4.relocated24 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 0, i32 0) ; (%rs4gc.s4.relocated21, %rs4gc.s4.relocated21)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  br label %ctor_prologue.merge.19

ctor_prologue.merge.19:                           ; preds = %ctor_prologue.barrier.done.22, %ctor_prologue.slow.18
  %.049 = phi ptr addrspace(1) [ %rs4gc.s6, %ctor_prologue.barrier.done.22 ], [ %rs4gc.s6.relocated, %ctor_prologue.slow.18 ]
  %.2 = phi ptr addrspace(1) [ %rs4gc.s4.relocated21, %ctor_prologue.barrier.done.22 ], [ %rs4gc.s4.relocated24, %ctor_prologue.slow.18 ]
  %r102 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.22 ], [ %r10123, %ctor_prologue.slow.18 ]
  %r103.rs4i = ptrtoint ptr addrspace(1) %.049 to i64
  %r103 = call i64 asm "", "=r,0"(i64 %r103.rs4i) #9
  %r104 = or i64 %r103, 9222527611924643840
  %r105 = bitcast i64 %r104 to double
  %r106 = bitcast double %r102 to i64
  %r107 = icmp eq i64 %r106, 9222246136947933185
  br i1 %r107, label %ctor_ret.merge.24, label %ctor_ret.override.23

ctor_prologue.barrier.maybe.20:                   ; preds = %ctor_prologue.fast.17
  %r93 = sub i64 %r5320, 7
  %r94 = inttoptr i64 %r93 to ptr
  %r95 = load i8, ptr %r94, align 1
  %r96 = and i8 %r95, 32
  %r97 = icmp ne i8 %r96, 0
  %r98 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r99 = icmp ne i32 %r98, 0
  %r100 = or i1 %r97, %r99
  br i1 %r100, label %ctor_prologue.barrier.21, label %ctor_prologue.barrier.done.22

ctor_prologue.barrier.21:                         ; preds = %ctor_prologue.barrier.maybe.20
  call void @js_write_barrier_slot_validated_parent(i64 %r5320, i64 %r81, i64 %r82) #9
  br label %ctor_prologue.barrier.done.22

ctor_prologue.barrier.done.22:                    ; preds = %ctor_prologue.barrier.21, %ctor_prologue.barrier.maybe.20, %ctor_prologue.fast.17
  br label %ctor_prologue.merge.19

ctor_ret.override.23:                             ; preds = %ctor_prologue.merge.19
  %statepoint_token25 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r105, double %r102, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r10826 = call double @llvm.experimental.gc.result.f64(token %statepoint_token25)
  %rs4gc.s4.relocated27 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token25, i32 0, i32 0) ; (%.2, %.2)
  br label %ctor_ret.merge.24

ctor_ret.merge.24:                                ; preds = %ctor_ret.override.23, %ctor_prologue.merge.19
  %.3 = phi ptr addrspace(1) [ %.2, %ctor_prologue.merge.19 ], [ %rs4gc.s4.relocated27, %ctor_ret.override.23 ]
  %r109 = phi double [ %r105, %ctor_prologue.merge.19 ], [ %r10826, %ctor_ret.override.23 ]
  %rs4gc.b7 = bitcast double %r109 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r110.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r110 = call i64 asm "", "=r,0"(i64 %r110.rs4i) #9
  %r111 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r112 = icmp ne i32 %r111, 0
  br i1 %r112, label %shadow.root.barrier.25, label %shadow.root.barrier.done.26

shadow.root.barrier.25:                           ; preds = %ctor_ret.merge.24
  call void @js_write_barrier_root_nanbox(i64 %r110) #9
  br label %shadow.root.barrier.done.26

shadow.root.barrier.done.26:                      ; preds = %shadow.root.barrier.25, %ctor_ret.merge.24
  %statepoint_token28 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7, ptr addrspace(1) %.3) ]
  %r11329 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token28)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 0, i32 0) ; (%rs4gc.s7, %rs4gc.s7)
  %rs4gc.s4.relocated30 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 1, i32 1) ; (%.3, %.3)
  %rs4gc.s8 = inttoptr i64 %r11329 to ptr addrspace(1)
  %r114.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r114 = call i64 asm "", "=r,0"(i64 %r114.rs4i) #9
  %r115 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r116 = icmp ne i32 %r115, 0
  br i1 %r116, label %shadow.root.barrier.27, label %shadow.root.barrier.done.28

shadow.root.barrier.27:                           ; preds = %shadow.root.barrier.done.26
  call void @js_write_barrier_root_nanbox(i64 %r114) #9
  br label %shadow.root.barrier.done.28

shadow.root.barrier.done.28:                      ; preds = %shadow.root.barrier.27, %shadow.root.barrier.done.26
  %r117 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.3.handle, align 8
  %r118.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r118 = call i64 asm "", "=r,0"(i64 %r118.rs4i) #9
  %statepoint_token31 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r118, double %r117, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated30, ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r11932 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token31)
  %rs4gc.s4.relocated33 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token31, i32 0, i32 0) ; (%rs4gc.s4.relocated30, %rs4gc.s4.relocated30)
  %rs4gc.s7.relocated34 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token31, i32 1, i32 1) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  %rs4gc.s9 = inttoptr i64 %r11932 to ptr addrspace(1)
  %r120.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r120 = call i64 asm "", "=r,0"(i64 %r120.rs4i) #9
  %r121 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r122 = icmp ne i32 %r121, 0
  br i1 %r122, label %shadow.root.barrier.29, label %shadow.root.barrier.done.30

shadow.root.barrier.29:                           ; preds = %shadow.root.barrier.done.28
  call void @js_write_barrier_root_nanbox(i64 %r120) #9
  br label %shadow.root.barrier.done.30

shadow.root.barrier.done.30:                      ; preds = %shadow.root.barrier.29, %shadow.root.barrier.done.28
  %r123.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7.relocated34 to i64
  %r123.rs4o = call i64 asm "", "=r,0"(i64 %r123.rs4i) #9
  %r123 = bitcast i64 %r123.rs4o to double
  %statepoint_token35 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr)) @js_closure_alloc_singleton, i32 1, i32 0, ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__identity, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated33, ptr addrspace(1) %rs4gc.s9, ptr addrspace(1) %rs4gc.s7.relocated34) ]
  %r12436 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token35)
  %rs4gc.s4.relocated37 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token35, i32 0, i32 0) ; (%rs4gc.s4.relocated33, %rs4gc.s4.relocated33)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token35, i32 1, i32 1) ; (%rs4gc.s9, %rs4gc.s9)
  %rs4gc.s7.relocated38 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token35, i32 2, i32 2) ; (%rs4gc.s7.relocated34, %rs4gc.s7.relocated34)
  %r125 = or i64 %r12436, 9222527611924643840
  %r126 = bitcast i64 %r125 to double
  %r136.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7.relocated38 to i64
  %r136.rs4o = call i64 asm "", "=r,0"(i64 %r136.rs4i) #9
  %r136 = bitcast i64 %r136.rs4o to double
  %statepoint_token39 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r136, double %r126, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated37, ptr addrspace(1) %rs4gc.s9.relocated) ]
  %r12740 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token39)
  %rs4gc.s4.relocated41 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token39, i32 0, i32 0) ; (%rs4gc.s4.relocated37, %rs4gc.s4.relocated37)
  %rs4gc.s9.relocated42 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token39, i32 1, i32 1) ; (%rs4gc.s9.relocated, %rs4gc.s9.relocated)
  %r128 = bitcast i64 %r12740 to double
  %r129.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9.relocated42 to i64
  %r129 = call i64 asm "", "=r,0"(i64 %r129.rs4i) #9
  %statepoint_token43 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r129, double %r128, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated41) ]
  %r13044 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token43)
  %rs4gc.s4.relocated45 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token43, i32 0, i32 0) ; (%rs4gc.s4.relocated41, %rs4gc.s4.relocated41)
  %rs4gc.s10 = inttoptr i64 %r13044 to ptr addrspace(1)
  %r131.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r131 = call i64 asm "", "=r,0"(i64 %r131.rs4i) #9
  %r132 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r133 = icmp ne i32 %r132, 0
  br i1 %r133, label %shadow.root.barrier.31, label %shadow.root.barrier.done.32

shadow.root.barrier.31:                           ; preds = %shadow.root.barrier.done.30
  call void @js_write_barrier_root_nanbox(i64 %r131) #9
  br label %shadow.root.barrier.done.32

shadow.root.barrier.done.32:                      ; preds = %shadow.root.barrier.31, %shadow.root.barrier.done.30
  %r134.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r134 = call i64 asm "", "=r,0"(i64 %r134.rs4i) #9
  %statepoint_token46 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r134, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated45) ]
  %rs4gc.s4.relocated47 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token46, i32 0, i32 0) ; (%rs4gc.s4.relocated45, %rs4gc.s4.relocated45)
  br label %if.merge.12
}

; Function Attrs: optsize
define double @perry_closure_test_json_primitive_tojson_keys_ts__8(i64 %this_closure, double %arg21) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %arg21 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %r2 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.4.handle, align 8
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_string_concat_box, i32 2, i32 0, double %r2, double %r3, i32 0, i32 0)
  %r41 = call double @llvm.experimental.gc.result.f64(token %statepoint_token)
  ret double %r41
}

; Function Attrs: optsize
define double @perry_closure_test_json_primitive_tojson_keys_ts__11(i64 %this_closure, double %arg26, double %arg27) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %arg26 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg27 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (double)) @js_value_typeof_tag, i32 1, i32 0, double %r3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s2) ]
  %r41 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token)
  %rs4gc.s2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s2, %rs4gc.s2)
  %r5 = icmp eq i32 %r41, 6
  %r6 = select i1 %r5, i64 9222246136947933188, i64 9222246136947933187
  %r7 = bitcast i64 %r6 to double
  %r8 = icmp eq i64 %r6, 9222246136947933188
  br i1 %r8, label %ternary.then.1, label %ternary.else.2

ternary.then.1:                                   ; preds = %entry.0
  %r9.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated to i64
  %r9.rs4o = call i64 asm "", "=r,0"(i64 %r9.rs4i) #9
  %r9 = bitcast i64 %r9.rs4o to double
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_string_coerce, i32 1, i32 0, double %r9, i32 0, i32 0)
  %r103 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token2)
  %r11 = or i64 %r103, 9223090561878065152
  %r12 = bitcast i64 %r11 to double
  br label %ternary.merge.3

ternary.else.2:                                   ; preds = %entry.0
  %r13.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated to i64
  %r13.rs4o = call i64 asm "", "=r,0"(i64 %r13.rs4i) #9
  %r13 = bitcast i64 %r13.rs4o to double
  br label %ternary.merge.3

ternary.merge.3:                                  ; preds = %ternary.else.2, %ternary.then.1
  %r14 = phi double [ %r12, %ternary.then.1 ], [ %r13, %ternary.else.2 ]
  ret double %r14
}

; Function Attrs: optsize
define double @test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7_constructor(double %this_arg, double %arg7) #6 gc "statepoint-example" {
entry.0:
  %r7 = load i32, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg7 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r4.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r4.rs4o = call i64 asm "", "=r,0"(i64 %r4.rs4i) #9
  %r4 = bitcast i64 %r4.rs4o to double
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #9
  %r5 = bitcast i64 %r5.rs4o to double
  %r9 = bitcast double %r4 to i64
  %r10 = and i64 %r9, 281474976710655
  %r11 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.5.handle, align 8
  %r12 = bitcast double %r11 to i64
  %r13 = and i64 %r12, 281474976710655
  %r14 = bitcast double %r5 to i64
  %r15 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r16 = icmp eq i8 %r15, 0
  %r17 = lshr i64 %r9, 48
  %r18 = icmp eq i64 %r17, 32765
  %r19 = icmp ugt i64 %r10, 1048575
  %r20 = and i1 %r18, %r19
  %r21 = and i1 %r20, %r16
  br i1 %r21, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.4
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r116.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r116.rs4o = call i64 asm "", "=r,0"(i64 %r116.rs4i) #9
  %r116 = bitcast i64 %r116.rs4o to double
  %r117 = bitcast double %r116 to i64
  %r118 = and i64 %r117, 281474976710655
  %r52 = inttoptr i64 %r118 to ptr
  %r112.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r112.rs4o = call i64 asm "", "=r,0"(i64 %r112.rs4i) #9
  %r112 = bitcast i64 %r112.rs4o to double
  %r113 = bitcast double %r112 to i64
  %r114 = and i64 %r113, 281474976710655
  %r115 = inttoptr i64 %r114 to ptr
  %r53 = getelementptr i8, ptr %r115, i64 16
  %r54 = getelementptr double, ptr %r53, i64 0
  %r55 = ptrtoint ptr %r54 to i64
  %r111.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r111.rs4o = call i64 asm "", "=r,0"(i64 %r111.rs4i) #9
  %r111 = bitcast i64 %r111.rs4o to double
  store double %r111, ptr %r54, align 8
  %r110.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r110.rs4o = call i64 asm "", "=r,0"(i64 %r110.rs4i) #9
  %r110 = bitcast i64 %r110.rs4o to double
  %r56 = bitcast double %r110 to i64
  %r108.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r108.rs4o = call i64 asm "", "=r,0"(i64 %r108.rs4i) #9
  %r108 = bitcast i64 %r108.rs4o to double
  %r109 = bitcast double %r108 to i64
  %r57 = lshr i64 %r109, 48
  %r58 = icmp eq i64 %r57, 0
  %r106.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r106.rs4o = call i64 asm "", "=r,0"(i64 %r106.rs4i) #9
  %r106 = bitcast i64 %r106.rs4o to double
  %r107 = bitcast double %r106 to i64
  %r59 = icmp uge i64 %r107, 4096
  %r60 = and i1 %r58, %r59
  %r61 = icmp eq i64 %r57, 32765
  %r62 = icmp eq i64 %r57, 32767
  %r63 = icmp eq i64 %r57, 32762
  %r64 = or i1 %r61, %r62
  %r65 = or i1 %r64, %r63
  %r66 = or i1 %r65, %r60
  br i1 %r66, label %class_field_set.gc_bookkeeping.7, label %class_field_set.gc_bookkeeping.done.8

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r100.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r100.rs4o = call i64 asm "", "=r,0"(i64 %r100.rs4i) #9
  %r100 = bitcast i64 %r100.rs4o to double
  %r101 = bitcast double %r100 to i64
  %r102.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r102.rs4o = call i64 asm "", "=r,0"(i64 %r102.rs4i) #9
  %r102 = bitcast i64 %r102.rs4o to double
  %r103 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.5.handle, align 8
  %r104 = bitcast double %r103 to i64
  %r105 = and i64 %r104, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479956992, i64 %r101, i64 %r105, double %r102, i32 0, i32 0)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.gc_bookkeeping.done.8, %class_field_set.fallback.3
  br label %standalone.ctor.return.after.1

class_field_inline.deref.5:                       ; preds = %entry.0
  %r22 = inttoptr i64 %r10 to ptr
  %r23 = getelementptr i8, ptr %r22, i64 -8
  %r24 = load i8, ptr %r23, align 1
  %r25 = icmp eq i8 %r24, 2
  %r26 = getelementptr i8, ptr %r22, i64 -7
  %r27 = load i8, ptr %r26, align 1
  %r28 = and i8 %r27, -128
  %r29 = icmp eq i8 %r28, 0
  %r30 = getelementptr i8, ptr %r22, i64 -6
  %r31 = load i16, ptr %r30, align 2
  %r32 = getelementptr i8, ptr %r22, i64 0
  %r33 = load i32, ptr %r32, align 4
  %r34 = icmp eq i32 %r33, 1
  %r35 = getelementptr i8, ptr %r22, i64 4
  %r36 = load i32, ptr %r35, align 4
  %r37 = icmp eq i32 %r36, %r7
  %r38 = and i1 %r25, %r29
  %r39 = and i1 %r38, %r34
  %r40 = and i1 %r39, %r37
  %r41 = and i16 %r31, 3072
  %r42 = icmp eq i16 %r41, 0
  %r43 = and i1 %r40, %r42
  %r44 = and i16 %r31, 1
  %r45 = icmp eq i16 %r44, 0
  %r46 = and i1 %r43, %r45
  %r47 = and i16 %r31, 128
  %r48 = icmp eq i16 %r47, 0
  %r49 = and i1 %r46, %r48
  br i1 %r49, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r50 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479956992, double %r4, i32 1, i32 %r7, i64 %r13, i32 0, double %r5, i32 0) #9
  %r51 = icmp ne i32 %r50, 0
  br i1 %r51, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.gc_bookkeeping.7:                 ; preds = %class_field_set.fast.2
  %r99.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r99.rs4o = call i64 asm "", "=r,0"(i64 %r99.rs4i) #9
  %r99 = bitcast i64 %r99.rs4o to double
  call void @js_string_addref_if_heap_string(double %r99) #9
  %r96.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r96.rs4o = call i64 asm "", "=r,0"(i64 %r96.rs4i) #9
  %r96 = bitcast i64 %r96.rs4o to double
  %r97 = bitcast double %r96 to i64
  %r98 = and i64 %r97, 281474976710655
  %r67 = inttoptr i64 %r98 to ptr
  %r92.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r92.rs4o = call i64 asm "", "=r,0"(i64 %r92.rs4i) #9
  %r92 = bitcast i64 %r92.rs4o to double
  %r93 = bitcast double %r92 to i64
  %r94 = and i64 %r93, 281474976710655
  %r95 = inttoptr i64 %r94 to ptr
  %r68 = getelementptr i8, ptr %r95, i64 -6
  %r69 = load i16, ptr %r68, align 2
  %r70 = and i16 %r69, -12288
  %r71 = icmp eq i16 %r70, -28672
  br i1 %r71, label %class_field_set.layout_note.done.10, label %class_field_set.layout_note.9

class_field_set.gc_bookkeeping.done.8:            ; preds = %class_field_set.barrier.11, %class_field_set.layout_note.done.10, %class_field_set.fast.2
  br label %class_field_set.merge.4

class_field_set.layout_note.9:                    ; preds = %class_field_set.gc_bookkeeping.7
  %r87.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r87.rs4o = call i64 asm "", "=r,0"(i64 %r87.rs4i) #9
  %r87 = bitcast i64 %r87.rs4o to double
  %r88 = bitcast double %r87 to i64
  %r89 = and i64 %r88, 281474976710655
  %r90.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r90.rs4o = call i64 asm "", "=r,0"(i64 %r90.rs4i) #9
  %r90 = bitcast i64 %r90.rs4o to double
  %r91 = bitcast double %r90 to i64
  call void @js_gc_note_slot_layout(i64 %r89, i32 0, i64 %r91) #9
  br label %class_field_set.layout_note.done.10

class_field_set.layout_note.done.10:              ; preds = %class_field_set.layout_note.9, %class_field_set.gc_bookkeeping.7
  %r84.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r84.rs4o = call i64 asm "", "=r,0"(i64 %r84.rs4i) #9
  %r84 = bitcast i64 %r84.rs4o to double
  %r85 = bitcast double %r84 to i64
  %r86 = and i64 %r85, 281474976710655
  %r72 = sub nsw i64 %r86, 7
  %r73 = inttoptr i64 %r72 to ptr
  %r74 = load i8, ptr %r73, align 1
  %r75 = and i8 %r74, 32
  %r76 = icmp ne i8 %r75, 0
  %r77 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r78 = icmp ne i32 %r77, 0
  %r79 = or i1 %r76, %r78
  br i1 %r79, label %class_field_set.barrier.11, label %class_field_set.gc_bookkeeping.done.8

class_field_set.barrier.11:                       ; preds = %class_field_set.layout_note.done.10
  %r80.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r80.rs4o = call i64 asm "", "=r,0"(i64 %r80.rs4i) #9
  %r80 = bitcast i64 %r80.rs4o to double
  %r81 = bitcast double %r80 to i64
  %r82.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r82.rs4o = call i64 asm "", "=r,0"(i64 %r82.rs4i) #9
  %r82 = bitcast i64 %r82.rs4o to double
  %r83 = bitcast double %r82 to i64
  call void @js_write_barrier_slot(i64 %r81, i64 %r55, i64 %r83) #9
  br label %class_field_set.gc_bookkeeping.done.8
}

; Function Attrs: optsize
define double @test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599_constructor(double %this_arg, double %arg8, double %arg9) #6 gc "statepoint-example" {
entry.0:
  %r8 = load i32, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg8 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg9 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #9
  %r5 = bitcast i64 %r5.rs4o to double
  %r6.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r6.rs4o = call i64 asm "", "=r,0"(i64 %r6.rs4i) #9
  %r6 = bitcast i64 %r6.rs4o to double
  %r10 = bitcast double %r5 to i64
  %r11 = and i64 %r10, 281474976710655
  %r12 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.6.handle, align 8
  %r13 = bitcast double %r12 to i64
  %r14 = and i64 %r13, 281474976710655
  %r15 = bitcast double %r6 to i64
  %r16 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r17 = icmp eq i8 %r16, 0
  %r18 = lshr i64 %r10, 48
  %r19 = icmp eq i64 %r18, 32765
  %r20 = icmp ugt i64 %r11, 1048575
  %r21 = and i1 %r19, %r20
  %r22 = and i1 %r21, %r17
  br i1 %r22, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.12
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r218.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r218.rs4o = call i64 asm "", "=r,0"(i64 %r218.rs4i) #9
  %r218 = bitcast i64 %r218.rs4o to double
  %r219 = bitcast double %r218 to i64
  %r220 = and i64 %r219, 281474976710655
  %r53 = inttoptr i64 %r220 to ptr
  %r214.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r214.rs4o = call i64 asm "", "=r,0"(i64 %r214.rs4i) #9
  %r214 = bitcast i64 %r214.rs4o to double
  %r215 = bitcast double %r214 to i64
  %r216 = and i64 %r215, 281474976710655
  %r217 = inttoptr i64 %r216 to ptr
  %r54 = getelementptr i8, ptr %r217, i64 16
  %r55 = getelementptr double, ptr %r54, i64 0
  %r56 = ptrtoint ptr %r55 to i64
  %r213.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r213.rs4o = call i64 asm "", "=r,0"(i64 %r213.rs4i) #9
  %r213 = bitcast i64 %r213.rs4o to double
  store double %r213, ptr %r55, align 8
  %r212.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r212.rs4o = call i64 asm "", "=r,0"(i64 %r212.rs4i) #9
  %r212 = bitcast i64 %r212.rs4o to double
  %r57 = bitcast double %r212 to i64
  %r210.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r210.rs4o = call i64 asm "", "=r,0"(i64 %r210.rs4i) #9
  %r210 = bitcast i64 %r210.rs4o to double
  %r211 = bitcast double %r210 to i64
  %r58 = lshr i64 %r211, 48
  %r59 = icmp eq i64 %r58, 0
  %r208.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r208.rs4o = call i64 asm "", "=r,0"(i64 %r208.rs4i) #9
  %r208 = bitcast i64 %r208.rs4o to double
  %r209 = bitcast double %r208 to i64
  %r60 = icmp uge i64 %r209, 4096
  %r61 = and i1 %r59, %r60
  %r62 = icmp eq i64 %r58, 32765
  %r63 = icmp eq i64 %r58, 32767
  %r64 = icmp eq i64 %r58, 32762
  %r65 = or i1 %r62, %r63
  %r66 = or i1 %r65, %r64
  %r67 = or i1 %r66, %r61
  br i1 %r67, label %class_field_set.gc_bookkeeping.7, label %class_field_set.gc_bookkeeping.done.8

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r202.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r202.rs4o = call i64 asm "", "=r,0"(i64 %r202.rs4i) #9
  %r202 = bitcast i64 %r202.rs4o to double
  %r203 = bitcast double %r202 to i64
  %r204.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r204.rs4o = call i64 asm "", "=r,0"(i64 %r204.rs4i) #9
  %r204 = bitcast i64 %r204.rs4o to double
  %r205 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.6.handle, align 8
  %r206 = bitcast double %r205 to i64
  %r207 = and i64 %r206, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479956993, i64 %r203, i64 %r207, double %r204, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s1) ]
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s1, %rs4gc.s1)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.gc_bookkeeping.done.8, %class_field_set.fallback.3
  %.02 = phi ptr addrspace(1) [ %rs4gc.s1, %class_field_set.gc_bookkeeping.done.8 ], [ %rs4gc.s1.relocated, %class_field_set.fallback.3 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %class_field_set.gc_bookkeeping.done.8 ], [ %rs4gc.s3.relocated, %class_field_set.fallback.3 ]
  %r76.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r76.rs4o = call i64 asm "", "=r,0"(i64 %r76.rs4i) #9
  %r76 = bitcast i64 %r76.rs4o to double
  %r77.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r77.rs4o = call i64 asm "", "=r,0"(i64 %r77.rs4i) #9
  %r77 = bitcast i64 %r77.rs4o to double
  %r79 = bitcast double %r76 to i64
  %r80 = and i64 %r79, 281474976710655
  %r81 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.7.handle, align 8
  %r82 = bitcast double %r81 to i64
  %r83 = and i64 %r82, 281474976710655
  %r84 = bitcast double %r77 to i64
  %r85 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r86 = icmp eq i8 %r85, 0
  %r87 = lshr i64 %r79, 48
  %r88 = icmp eq i64 %r87, 32765
  %r89 = icmp ugt i64 %r80, 1048575
  %r90 = and i1 %r88, %r89
  %r91 = and i1 %r90, %r86
  br i1 %r91, label %class_field_inline.deref.13, label %class_field_inline.guardcall.14

class_field_inline.deref.5:                       ; preds = %entry.0
  %r23 = inttoptr i64 %r11 to ptr
  %r24 = getelementptr i8, ptr %r23, i64 -8
  %r25 = load i8, ptr %r24, align 1
  %r26 = icmp eq i8 %r25, 2
  %r27 = getelementptr i8, ptr %r23, i64 -7
  %r28 = load i8, ptr %r27, align 1
  %r29 = and i8 %r28, -128
  %r30 = icmp eq i8 %r29, 0
  %r31 = getelementptr i8, ptr %r23, i64 -6
  %r32 = load i16, ptr %r31, align 2
  %r33 = getelementptr i8, ptr %r23, i64 0
  %r34 = load i32, ptr %r33, align 4
  %r35 = icmp eq i32 %r34, 2
  %r36 = getelementptr i8, ptr %r23, i64 4
  %r37 = load i32, ptr %r36, align 4
  %r38 = icmp eq i32 %r37, %r8
  %r39 = and i1 %r26, %r30
  %r40 = and i1 %r39, %r35
  %r41 = and i1 %r40, %r38
  %r42 = and i16 %r32, 3072
  %r43 = icmp eq i16 %r42, 0
  %r44 = and i1 %r41, %r43
  %r45 = and i16 %r32, 1
  %r46 = icmp eq i16 %r45, 0
  %r47 = and i1 %r44, %r46
  %r48 = and i16 %r32, 128
  %r49 = icmp eq i16 %r48, 0
  %r50 = and i1 %r47, %r49
  br i1 %r50, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r51 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479956993, double %r5, i32 2, i32 %r8, i64 %r14, i32 0, double %r6, i32 0) #9
  %r52 = icmp ne i32 %r51, 0
  br i1 %r52, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.gc_bookkeeping.7:                 ; preds = %class_field_set.fast.2
  %r201.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r201.rs4o = call i64 asm "", "=r,0"(i64 %r201.rs4i) #9
  %r201 = bitcast i64 %r201.rs4o to double
  call void @js_string_addref_if_heap_string(double %r201) #9
  %r196.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r196.rs4o = call i64 asm "", "=r,0"(i64 %r196.rs4i) #9
  %r196 = bitcast i64 %r196.rs4o to double
  %r197 = bitcast double %r196 to i64
  %r198 = and i64 %r197, 281474976710655
  %r199.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r199.rs4o = call i64 asm "", "=r,0"(i64 %r199.rs4i) #9
  %r199 = bitcast i64 %r199.rs4o to double
  %r200 = bitcast double %r199 to i64
  call void @js_gc_note_slot_layout(i64 %r198, i32 0, i64 %r200) #9
  %r193.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r193.rs4o = call i64 asm "", "=r,0"(i64 %r193.rs4i) #9
  %r193 = bitcast i64 %r193.rs4o to double
  %r194 = bitcast double %r193 to i64
  %r195 = and i64 %r194, 281474976710655
  %r68 = sub nsw i64 %r195, 7
  %r69 = inttoptr i64 %r68 to ptr
  %r70 = load i8, ptr %r69, align 1
  %r71 = and i8 %r70, 32
  %r72 = icmp ne i8 %r71, 0
  %r73 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r74 = icmp ne i32 %r73, 0
  %r75 = or i1 %r72, %r74
  br i1 %r75, label %class_field_set.barrier.9, label %class_field_set.gc_bookkeeping.done.8

class_field_set.gc_bookkeeping.done.8:            ; preds = %class_field_set.barrier.9, %class_field_set.gc_bookkeeping.7, %class_field_set.fast.2
  br label %class_field_set.merge.4

class_field_set.barrier.9:                        ; preds = %class_field_set.gc_bookkeeping.7
  %r189.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r189.rs4o = call i64 asm "", "=r,0"(i64 %r189.rs4i) #9
  %r189 = bitcast i64 %r189.rs4o to double
  %r190 = bitcast double %r189 to i64
  %r191.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r191.rs4o = call i64 asm "", "=r,0"(i64 %r191.rs4i) #9
  %r191 = bitcast i64 %r191.rs4o to double
  %r192 = bitcast double %r191 to i64
  call void @js_write_barrier_slot(i64 %r190, i64 %r56, i64 %r192) #9
  br label %class_field_set.gc_bookkeeping.done.8

class_field_set.fast.10:                          ; preds = %class_field_inline.guardcall.14, %class_field_inline.deref.13
  %r186.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r186.rs4o = call i64 asm "", "=r,0"(i64 %r186.rs4i) #9
  %r186 = bitcast i64 %r186.rs4o to double
  %r187 = bitcast double %r186 to i64
  %r188 = and i64 %r187, 281474976710655
  %r122 = inttoptr i64 %r188 to ptr
  %r182.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r182.rs4o = call i64 asm "", "=r,0"(i64 %r182.rs4i) #9
  %r182 = bitcast i64 %r182.rs4o to double
  %r183 = bitcast double %r182 to i64
  %r184 = and i64 %r183, 281474976710655
  %r185 = inttoptr i64 %r184 to ptr
  %r123 = getelementptr i8, ptr %r185, i64 16
  %r124 = getelementptr double, ptr %r123, i64 1
  %r125 = ptrtoint ptr %r124 to i64
  %r181.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r181.rs4o = call i64 asm "", "=r,0"(i64 %r181.rs4i) #9
  %r181 = bitcast i64 %r181.rs4o to double
  store double %r181, ptr %r124, align 8
  %r180.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r180.rs4o = call i64 asm "", "=r,0"(i64 %r180.rs4i) #9
  %r180 = bitcast i64 %r180.rs4o to double
  %r126 = bitcast double %r180 to i64
  %r178.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r178.rs4o = call i64 asm "", "=r,0"(i64 %r178.rs4i) #9
  %r178 = bitcast i64 %r178.rs4o to double
  %r179 = bitcast double %r178 to i64
  %r127 = lshr i64 %r179, 48
  %r128 = icmp eq i64 %r127, 0
  %r176.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r176.rs4o = call i64 asm "", "=r,0"(i64 %r176.rs4i) #9
  %r176 = bitcast i64 %r176.rs4o to double
  %r177 = bitcast double %r176 to i64
  %r129 = icmp uge i64 %r177, 4096
  %r130 = and i1 %r128, %r129
  %r131 = icmp eq i64 %r127, 32765
  %r132 = icmp eq i64 %r127, 32767
  %r133 = icmp eq i64 %r127, 32762
  %r134 = or i1 %r131, %r132
  %r135 = or i1 %r134, %r133
  %r136 = or i1 %r135, %r130
  br i1 %r136, label %class_field_set.gc_bookkeeping.15, label %class_field_set.gc_bookkeeping.done.16

class_field_set.fallback.11:                      ; preds = %class_field_inline.guardcall.14
  %r170.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r170.rs4o = call i64 asm "", "=r,0"(i64 %r170.rs4i) #9
  %r170 = bitcast i64 %r170.rs4o to double
  %r171 = bitcast double %r170 to i64
  %r172.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r172.rs4o = call i64 asm "", "=r,0"(i64 %r172.rs4i) #9
  %r172 = bitcast i64 %r172.rs4o to double
  %r173 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.7.handle, align 8
  %r174 = bitcast double %r173 to i64
  %r175 = and i64 %r174, 281474976710655
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479956994, i64 %r171, i64 %r175, double %r172, i32 0, i32 0)
  br label %class_field_set.merge.12

class_field_set.merge.12:                         ; preds = %class_field_set.gc_bookkeeping.done.16, %class_field_set.fallback.11
  br label %standalone.ctor.return.after.1

class_field_inline.deref.13:                      ; preds = %class_field_set.merge.4
  %r92 = inttoptr i64 %r80 to ptr
  %r93 = getelementptr i8, ptr %r92, i64 -8
  %r94 = load i8, ptr %r93, align 1
  %r95 = icmp eq i8 %r94, 2
  %r96 = getelementptr i8, ptr %r92, i64 -7
  %r97 = load i8, ptr %r96, align 1
  %r98 = and i8 %r97, -128
  %r99 = icmp eq i8 %r98, 0
  %r100 = getelementptr i8, ptr %r92, i64 -6
  %r101 = load i16, ptr %r100, align 2
  %r102 = getelementptr i8, ptr %r92, i64 0
  %r103 = load i32, ptr %r102, align 4
  %r104 = icmp eq i32 %r103, 2
  %r105 = getelementptr i8, ptr %r92, i64 4
  %r106 = load i32, ptr %r105, align 4
  %r107 = icmp eq i32 %r106, %r8
  %r108 = and i1 %r95, %r99
  %r109 = and i1 %r108, %r104
  %r110 = and i1 %r109, %r107
  %r111 = and i16 %r101, 3072
  %r112 = icmp eq i16 %r111, 0
  %r113 = and i1 %r110, %r112
  %r114 = and i16 %r101, 1
  %r115 = icmp eq i16 %r114, 0
  %r116 = and i1 %r113, %r115
  %r117 = and i16 %r101, 128
  %r118 = icmp eq i16 %r117, 0
  %r119 = and i1 %r116, %r118
  br i1 %r119, label %class_field_set.fast.10, label %class_field_inline.guardcall.14

class_field_inline.guardcall.14:                  ; preds = %class_field_inline.deref.13, %class_field_set.merge.4
  %r120 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479956994, double %r76, i32 2, i32 %r8, i64 %r83, i32 1, double %r77, i32 0) #9
  %r121 = icmp ne i32 %r120, 0
  br i1 %r121, label %class_field_set.fast.10, label %class_field_set.fallback.11

class_field_set.gc_bookkeeping.15:                ; preds = %class_field_set.fast.10
  %r169.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r169.rs4o = call i64 asm "", "=r,0"(i64 %r169.rs4i) #9
  %r169 = bitcast i64 %r169.rs4o to double
  call void @js_string_addref_if_heap_string(double %r169) #9
  %r166.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r166.rs4o = call i64 asm "", "=r,0"(i64 %r166.rs4i) #9
  %r166 = bitcast i64 %r166.rs4o to double
  %r167 = bitcast double %r166 to i64
  %r168 = and i64 %r167, 281474976710655
  %r137 = inttoptr i64 %r168 to ptr
  %r162.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r162.rs4o = call i64 asm "", "=r,0"(i64 %r162.rs4i) #9
  %r162 = bitcast i64 %r162.rs4o to double
  %r163 = bitcast double %r162 to i64
  %r164 = and i64 %r163, 281474976710655
  %r165 = inttoptr i64 %r164 to ptr
  %r138 = getelementptr i8, ptr %r165, i64 -6
  %r139 = load i16, ptr %r138, align 2
  %r140 = and i16 %r139, -12288
  %r141 = icmp eq i16 %r140, -28672
  br i1 %r141, label %class_field_set.layout_note.done.18, label %class_field_set.layout_note.17

class_field_set.gc_bookkeeping.done.16:           ; preds = %class_field_set.barrier.19, %class_field_set.layout_note.done.18, %class_field_set.fast.10
  br label %class_field_set.merge.12

class_field_set.layout_note.17:                   ; preds = %class_field_set.gc_bookkeeping.15
  %r157.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r157.rs4o = call i64 asm "", "=r,0"(i64 %r157.rs4i) #9
  %r157 = bitcast i64 %r157.rs4o to double
  %r158 = bitcast double %r157 to i64
  %r159 = and i64 %r158, 281474976710655
  %r160.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r160.rs4o = call i64 asm "", "=r,0"(i64 %r160.rs4i) #9
  %r160 = bitcast i64 %r160.rs4o to double
  %r161 = bitcast double %r160 to i64
  call void @js_gc_note_slot_layout(i64 %r159, i32 1, i64 %r161) #9
  br label %class_field_set.layout_note.done.18

class_field_set.layout_note.done.18:              ; preds = %class_field_set.layout_note.17, %class_field_set.gc_bookkeeping.15
  %r154.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r154.rs4o = call i64 asm "", "=r,0"(i64 %r154.rs4i) #9
  %r154 = bitcast i64 %r154.rs4o to double
  %r155 = bitcast double %r154 to i64
  %r156 = and i64 %r155, 281474976710655
  %r142 = sub nsw i64 %r156, 7
  %r143 = inttoptr i64 %r142 to ptr
  %r144 = load i8, ptr %r143, align 1
  %r145 = and i8 %r144, 32
  %r146 = icmp ne i8 %r145, 0
  %r147 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r148 = icmp ne i32 %r147, 0
  %r149 = or i1 %r146, %r148
  br i1 %r149, label %class_field_set.barrier.19, label %class_field_set.gc_bookkeeping.done.16

class_field_set.barrier.19:                       ; preds = %class_field_set.layout_note.done.18
  %r150.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r150.rs4o = call i64 asm "", "=r,0"(i64 %r150.rs4i) #9
  %r150 = bitcast i64 %r150.rs4o to double
  %r151 = bitcast double %r150 to i64
  %r152.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r152.rs4o = call i64 asm "", "=r,0"(i64 %r152.rs4i) #9
  %r152 = bitcast i64 %r152.rs4o to double
  %r153 = bitcast double %r152 to i64
  call void @js_write_barrier_slot(i64 %r151, i64 %r125, i64 %r153) #9
  br label %class_field_set.gc_bookkeeping.done.16
}

; Function Attrs: optsize
define double @test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b_constructor(double %this_arg, double %arg10, double %arg11, double %arg12, double %arg13, double %arg14, double %arg15) #6 gc "statepoint-example" {
entry.0:
  %r12 = load i32, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg10 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg11 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %rs4gc.b4 = bitcast double %arg12 to i64
  %rs4gc.s4 = inttoptr i64 %rs4gc.b4 to ptr addrspace(1)
  %rs4gc.b5 = bitcast double %arg13 to i64
  %rs4gc.s5 = inttoptr i64 %rs4gc.b5 to ptr addrspace(1)
  %rs4gc.b6 = bitcast double %arg14 to i64
  %rs4gc.s6 = inttoptr i64 %rs4gc.b6 to ptr addrspace(1)
  %rs4gc.b7 = bitcast double %arg15 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r9.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r9.rs4o = call i64 asm "", "=r,0"(i64 %r9.rs4i) #9
  %r9 = bitcast i64 %r9.rs4o to double
  %r10.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r10.rs4o = call i64 asm "", "=r,0"(i64 %r10.rs4i) #9
  %r10 = bitcast i64 %r10.rs4o to double
  %r14 = bitcast double %r9 to i64
  %r15 = and i64 %r14, 281474976710655
  %r16 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.8.handle, align 8
  %r17 = bitcast double %r16 to i64
  %r18 = and i64 %r17, 281474976710655
  %r19 = bitcast double %r10 to i64
  %r20 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r21 = icmp eq i8 %r20, 0
  %r22 = lshr i64 %r14, 48
  %r23 = icmp eq i64 %r22, 32765
  %r24 = icmp ugt i64 %r15, 1048575
  %r25 = and i1 %r23, %r24
  %r26 = and i1 %r25, %r21
  br i1 %r26, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.47
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r631.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r631.rs4o = call i64 asm "", "=r,0"(i64 %r631.rs4i) #9
  %r631 = bitcast i64 %r631.rs4o to double
  %r632 = bitcast double %r631 to i64
  %r633 = and i64 %r632, 281474976710655
  %r63 = inttoptr i64 %r633 to ptr
  %r627.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r627.rs4o = call i64 asm "", "=r,0"(i64 %r627.rs4i) #9
  %r627 = bitcast i64 %r627.rs4o to double
  %r628 = bitcast double %r627 to i64
  %r629 = and i64 %r628, 281474976710655
  %r630 = inttoptr i64 %r629 to ptr
  %r64 = getelementptr i8, ptr %r630, i64 16
  %r65 = getelementptr double, ptr %r64, i64 0
  %r626.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r626.rs4o = call i64 asm "", "=r,0"(i64 %r626.rs4i) #9
  %r626 = bitcast i64 %r626.rs4o to double
  %r66 = call double @js_array_numeric_value_to_raw_f64(double %r626) #9
  store double %r66, ptr %r65, align 8
  br label %class_field_set.merge.4

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r620.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r620.rs4o = call i64 asm "", "=r,0"(i64 %r620.rs4i) #9
  %r620 = bitcast i64 %r620.rs4o to double
  %r621 = bitcast double %r620 to i64
  %r622.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r622.rs4o = call i64 asm "", "=r,0"(i64 %r622.rs4i) #9
  %r622 = bitcast i64 %r622.rs4o to double
  %r623 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.8.handle, align 8
  %r624 = bitcast double %r623 to i64
  %r625 = and i64 %r624, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479956995, i64 %r621, i64 %r625, double %r622, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s1, ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s5, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s1, %rs4gc.s1)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 2, i32 2) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s5.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 3, i32 3) ; (%rs4gc.s5, %rs4gc.s5)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 4, i32 4) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 5, i32 5) ; (%rs4gc.s7, %rs4gc.s7)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.fallback.3, %class_field_set.fast.2
  %.030 = phi ptr addrspace(1) [ %rs4gc.s7, %class_field_set.fast.2 ], [ %rs4gc.s7.relocated, %class_field_set.fallback.3 ]
  %.026 = phi ptr addrspace(1) [ %rs4gc.s6, %class_field_set.fast.2 ], [ %rs4gc.s6.relocated, %class_field_set.fallback.3 ]
  %.023 = phi ptr addrspace(1) [ %rs4gc.s5, %class_field_set.fast.2 ], [ %rs4gc.s5.relocated, %class_field_set.fallback.3 ]
  %.021 = phi ptr addrspace(1) [ %rs4gc.s4, %class_field_set.fast.2 ], [ %rs4gc.s4.relocated, %class_field_set.fallback.3 ]
  %.020 = phi ptr addrspace(1) [ %rs4gc.s3, %class_field_set.fast.2 ], [ %rs4gc.s3.relocated, %class_field_set.fallback.3 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s1, %class_field_set.fast.2 ], [ %rs4gc.s1.relocated, %class_field_set.fallback.3 ]
  %r67.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r67.rs4o = call i64 asm "", "=r,0"(i64 %r67.rs4i) #9
  %r67 = bitcast i64 %r67.rs4o to double
  %r68.rs4i = ptrtoint ptr addrspace(1) %.020 to i64
  %r68.rs4o = call i64 asm "", "=r,0"(i64 %r68.rs4i) #9
  %r68 = bitcast i64 %r68.rs4o to double
  %r70 = bitcast double %r67 to i64
  %r71 = and i64 %r70, 281474976710655
  %r72 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.1.handle, align 8
  %r73 = bitcast double %r72 to i64
  %r74 = and i64 %r73, 281474976710655
  %r75 = bitcast double %r68 to i64
  %r76 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r77 = icmp eq i8 %r76, 0
  %r78 = lshr i64 %r70, 48
  %r79 = icmp eq i64 %r78, 32765
  %r80 = icmp ugt i64 %r71, 1048575
  %r81 = and i1 %r79, %r80
  %r82 = and i1 %r81, %r77
  br i1 %r82, label %class_field_inline.deref.10, label %class_field_inline.guardcall.11

class_field_inline.deref.5:                       ; preds = %entry.0
  %r27 = inttoptr i64 %r15 to ptr
  %r28 = getelementptr i8, ptr %r27, i64 -8
  %r29 = load i8, ptr %r28, align 1
  %r30 = icmp eq i8 %r29, 2
  %r31 = getelementptr i8, ptr %r27, i64 -7
  %r32 = load i8, ptr %r31, align 1
  %r33 = and i8 %r32, -128
  %r34 = icmp eq i8 %r33, 0
  %r35 = getelementptr i8, ptr %r27, i64 -6
  %r36 = load i16, ptr %r35, align 2
  %r37 = getelementptr i8, ptr %r27, i64 0
  %r38 = load i32, ptr %r37, align 4
  %r39 = icmp eq i32 %r38, 3
  %r40 = getelementptr i8, ptr %r27, i64 4
  %r41 = load i32, ptr %r40, align 4
  %r42 = icmp eq i32 %r41, %r12
  %r43 = and i1 %r30, %r34
  %r44 = and i1 %r43, %r39
  %r45 = and i1 %r44, %r42
  %r46 = and i16 %r36, 3072
  %r47 = icmp eq i16 %r46, 0
  %r48 = and i1 %r45, %r47
  %r49 = and i16 %r36, 4096
  %r50 = icmp ne i16 %r49, 0
  %r51 = and i1 %r48, %r50
  %r52 = and i16 %r36, 1
  %r53 = icmp eq i16 %r52, 0
  %r54 = and i1 %r51, %r53
  %r55 = and i16 %r36, 128
  %r56 = icmp eq i16 %r55, 0
  %r57 = and i1 %r54, %r56
  %r58 = and i64 %r19, 9218868437227405312
  %r59 = icmp ne i64 %r58, 9218868437227405312
  %r60 = and i1 %r57, %r59
  br i1 %r60, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r61 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479956995, double %r9, i32 3, i32 %r12, i64 %r18, i32 0, double %r10, i32 1) #9
  %r62 = icmp ne i32 %r61, 0
  br i1 %r62, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.fast.7:                           ; preds = %class_field_inline.guardcall.11, %class_field_inline.deref.10
  %r617.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r617.rs4o = call i64 asm "", "=r,0"(i64 %r617.rs4i) #9
  %r617 = bitcast i64 %r617.rs4o to double
  %r618 = bitcast double %r617 to i64
  %r619 = and i64 %r618, 281474976710655
  %r113 = inttoptr i64 %r619 to ptr
  %r613.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r613.rs4o = call i64 asm "", "=r,0"(i64 %r613.rs4i) #9
  %r613 = bitcast i64 %r613.rs4o to double
  %r614 = bitcast double %r613 to i64
  %r615 = and i64 %r614, 281474976710655
  %r616 = inttoptr i64 %r615 to ptr
  %r114 = getelementptr i8, ptr %r616, i64 16
  %r115 = getelementptr double, ptr %r114, i64 1
  %r116 = ptrtoint ptr %r115 to i64
  %r612.rs4i = ptrtoint ptr addrspace(1) %.020 to i64
  %r612.rs4o = call i64 asm "", "=r,0"(i64 %r612.rs4i) #9
  %r612 = bitcast i64 %r612.rs4o to double
  store double %r612, ptr %r115, align 8
  %r611.rs4i = ptrtoint ptr addrspace(1) %.020 to i64
  %r611.rs4o = call i64 asm "", "=r,0"(i64 %r611.rs4i) #9
  %r611 = bitcast i64 %r611.rs4o to double
  %r117 = bitcast double %r611 to i64
  %r609.rs4i = ptrtoint ptr addrspace(1) %.020 to i64
  %r609.rs4o = call i64 asm "", "=r,0"(i64 %r609.rs4i) #9
  %r609 = bitcast i64 %r609.rs4o to double
  %r610 = bitcast double %r609 to i64
  %r118 = lshr i64 %r610, 48
  %r119 = icmp eq i64 %r118, 0
  %r607.rs4i = ptrtoint ptr addrspace(1) %.020 to i64
  %r607.rs4o = call i64 asm "", "=r,0"(i64 %r607.rs4i) #9
  %r607 = bitcast i64 %r607.rs4o to double
  %r608 = bitcast double %r607 to i64
  %r120 = icmp uge i64 %r608, 4096
  %r121 = and i1 %r119, %r120
  %r122 = icmp eq i64 %r118, 32765
  %r123 = icmp eq i64 %r118, 32767
  %r124 = icmp eq i64 %r118, 32762
  %r125 = or i1 %r122, %r123
  %r126 = or i1 %r125, %r124
  %r127 = or i1 %r126, %r121
  br i1 %r127, label %class_field_set.gc_bookkeeping.12, label %class_field_set.gc_bookkeeping.done.13

class_field_set.fallback.8:                       ; preds = %class_field_inline.guardcall.11
  %r601.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r601.rs4o = call i64 asm "", "=r,0"(i64 %r601.rs4i) #9
  %r601 = bitcast i64 %r601.rs4o to double
  %r602 = bitcast double %r601 to i64
  %r603.rs4i = ptrtoint ptr addrspace(1) %.020 to i64
  %r603.rs4o = call i64 asm "", "=r,0"(i64 %r603.rs4i) #9
  %r603 = bitcast i64 %r603.rs4o to double
  %r604 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.1.handle, align 8
  %r605 = bitcast double %r604 to i64
  %r606 = and i64 %r605, 281474976710655
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479956996, i64 %r602, i64 %r606, double %r603, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0, ptr addrspace(1) %.021, ptr addrspace(1) %.023, ptr addrspace(1) %.026, ptr addrspace(1) %.030) ]
  %rs4gc.s1.relocated2 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 0, i32 0) ; (%.0, %.0)
  %rs4gc.s4.relocated3 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 1, i32 1) ; (%.021, %.021)
  %rs4gc.s5.relocated4 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 2, i32 2) ; (%.023, %.023)
  %rs4gc.s6.relocated5 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 3, i32 3) ; (%.026, %.026)
  %rs4gc.s7.relocated6 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 4, i32 4) ; (%.030, %.030)
  br label %class_field_set.merge.9

class_field_set.merge.9:                          ; preds = %class_field_set.gc_bookkeeping.done.13, %class_field_set.fallback.8
  %.131 = phi ptr addrspace(1) [ %.030, %class_field_set.gc_bookkeeping.done.13 ], [ %rs4gc.s7.relocated6, %class_field_set.fallback.8 ]
  %.127 = phi ptr addrspace(1) [ %.026, %class_field_set.gc_bookkeeping.done.13 ], [ %rs4gc.s6.relocated5, %class_field_set.fallback.8 ]
  %.124 = phi ptr addrspace(1) [ %.023, %class_field_set.gc_bookkeeping.done.13 ], [ %rs4gc.s5.relocated4, %class_field_set.fallback.8 ]
  %.122 = phi ptr addrspace(1) [ %.021, %class_field_set.gc_bookkeeping.done.13 ], [ %rs4gc.s4.relocated3, %class_field_set.fallback.8 ]
  %.1 = phi ptr addrspace(1) [ %.0, %class_field_set.gc_bookkeeping.done.13 ], [ %rs4gc.s1.relocated2, %class_field_set.fallback.8 ]
  %r141.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r141.rs4o = call i64 asm "", "=r,0"(i64 %r141.rs4i) #9
  %r141 = bitcast i64 %r141.rs4o to double
  %r142.rs4i = ptrtoint ptr addrspace(1) %.122 to i64
  %r142.rs4o = call i64 asm "", "=r,0"(i64 %r142.rs4i) #9
  %r142 = bitcast i64 %r142.rs4o to double
  %r144 = bitcast double %r141 to i64
  %r145 = and i64 %r144, 281474976710655
  %r146 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.9.handle, align 8
  %r147 = bitcast double %r146 to i64
  %r148 = and i64 %r147, 281474976710655
  %r149 = bitcast double %r142 to i64
  %r150 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r151 = icmp eq i8 %r150, 0
  %r152 = lshr i64 %r144, 48
  %r153 = icmp eq i64 %r152, 32765
  %r154 = icmp ugt i64 %r145, 1048575
  %r155 = and i1 %r153, %r154
  %r156 = and i1 %r155, %r151
  br i1 %r156, label %class_field_inline.deref.20, label %class_field_inline.guardcall.21

class_field_inline.deref.10:                      ; preds = %class_field_set.merge.4
  %r83 = inttoptr i64 %r71 to ptr
  %r84 = getelementptr i8, ptr %r83, i64 -8
  %r85 = load i8, ptr %r84, align 1
  %r86 = icmp eq i8 %r85, 2
  %r87 = getelementptr i8, ptr %r83, i64 -7
  %r88 = load i8, ptr %r87, align 1
  %r89 = and i8 %r88, -128
  %r90 = icmp eq i8 %r89, 0
  %r91 = getelementptr i8, ptr %r83, i64 -6
  %r92 = load i16, ptr %r91, align 2
  %r93 = getelementptr i8, ptr %r83, i64 0
  %r94 = load i32, ptr %r93, align 4
  %r95 = icmp eq i32 %r94, 3
  %r96 = getelementptr i8, ptr %r83, i64 4
  %r97 = load i32, ptr %r96, align 4
  %r98 = icmp eq i32 %r97, %r12
  %r99 = and i1 %r86, %r90
  %r100 = and i1 %r99, %r95
  %r101 = and i1 %r100, %r98
  %r102 = and i16 %r92, 3072
  %r103 = icmp eq i16 %r102, 0
  %r104 = and i1 %r101, %r103
  %r105 = and i16 %r92, 1
  %r106 = icmp eq i16 %r105, 0
  %r107 = and i1 %r104, %r106
  %r108 = and i16 %r92, 128
  %r109 = icmp eq i16 %r108, 0
  %r110 = and i1 %r107, %r109
  br i1 %r110, label %class_field_set.fast.7, label %class_field_inline.guardcall.11

class_field_inline.guardcall.11:                  ; preds = %class_field_inline.deref.10, %class_field_set.merge.4
  %r111 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479956996, double %r67, i32 3, i32 %r12, i64 %r74, i32 1, double %r68, i32 0) #9
  %r112 = icmp ne i32 %r111, 0
  br i1 %r112, label %class_field_set.fast.7, label %class_field_set.fallback.8

class_field_set.gc_bookkeeping.12:                ; preds = %class_field_set.fast.7
  %r600.rs4i = ptrtoint ptr addrspace(1) %.020 to i64
  %r600.rs4o = call i64 asm "", "=r,0"(i64 %r600.rs4i) #9
  %r600 = bitcast i64 %r600.rs4o to double
  call void @js_string_addref_if_heap_string(double %r600) #9
  %r597.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r597.rs4o = call i64 asm "", "=r,0"(i64 %r597.rs4i) #9
  %r597 = bitcast i64 %r597.rs4o to double
  %r598 = bitcast double %r597 to i64
  %r599 = and i64 %r598, 281474976710655
  %r128 = inttoptr i64 %r599 to ptr
  %r593.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r593.rs4o = call i64 asm "", "=r,0"(i64 %r593.rs4i) #9
  %r593 = bitcast i64 %r593.rs4o to double
  %r594 = bitcast double %r593 to i64
  %r595 = and i64 %r594, 281474976710655
  %r596 = inttoptr i64 %r595 to ptr
  %r129 = getelementptr i8, ptr %r596, i64 -6
  %r130 = load i16, ptr %r129, align 2
  %r131 = and i16 %r130, -12288
  %r132 = icmp eq i16 %r131, -28672
  br i1 %r132, label %class_field_set.layout_note.done.15, label %class_field_set.layout_note.14

class_field_set.gc_bookkeeping.done.13:           ; preds = %class_field_set.barrier.16, %class_field_set.layout_note.done.15, %class_field_set.fast.7
  br label %class_field_set.merge.9

class_field_set.layout_note.14:                   ; preds = %class_field_set.gc_bookkeeping.12
  %r588.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r588.rs4o = call i64 asm "", "=r,0"(i64 %r588.rs4i) #9
  %r588 = bitcast i64 %r588.rs4o to double
  %r589 = bitcast double %r588 to i64
  %r590 = and i64 %r589, 281474976710655
  %r591.rs4i = ptrtoint ptr addrspace(1) %.020 to i64
  %r591.rs4o = call i64 asm "", "=r,0"(i64 %r591.rs4i) #9
  %r591 = bitcast i64 %r591.rs4o to double
  %r592 = bitcast double %r591 to i64
  call void @js_gc_note_slot_layout(i64 %r590, i32 1, i64 %r592) #9
  br label %class_field_set.layout_note.done.15

class_field_set.layout_note.done.15:              ; preds = %class_field_set.layout_note.14, %class_field_set.gc_bookkeeping.12
  %r585.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r585.rs4o = call i64 asm "", "=r,0"(i64 %r585.rs4i) #9
  %r585 = bitcast i64 %r585.rs4o to double
  %r586 = bitcast double %r585 to i64
  %r587 = and i64 %r586, 281474976710655
  %r133 = sub nsw i64 %r587, 7
  %r134 = inttoptr i64 %r133 to ptr
  %r135 = load i8, ptr %r134, align 1
  %r136 = and i8 %r135, 32
  %r137 = icmp ne i8 %r136, 0
  %r138 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r139 = icmp ne i32 %r138, 0
  %r140 = or i1 %r137, %r139
  br i1 %r140, label %class_field_set.barrier.16, label %class_field_set.gc_bookkeeping.done.13

class_field_set.barrier.16:                       ; preds = %class_field_set.layout_note.done.15
  %r581.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r581.rs4o = call i64 asm "", "=r,0"(i64 %r581.rs4i) #9
  %r581 = bitcast i64 %r581.rs4o to double
  %r582 = bitcast double %r581 to i64
  %r583.rs4i = ptrtoint ptr addrspace(1) %.020 to i64
  %r583.rs4o = call i64 asm "", "=r,0"(i64 %r583.rs4i) #9
  %r583 = bitcast i64 %r583.rs4o to double
  %r584 = bitcast double %r583 to i64
  call void @js_write_barrier_slot(i64 %r582, i64 %r116, i64 %r584) #9
  br label %class_field_set.gc_bookkeeping.done.13

class_field_set.fast.17:                          ; preds = %class_field_inline.guardcall.21, %class_field_inline.deref.20
  %r578.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r578.rs4o = call i64 asm "", "=r,0"(i64 %r578.rs4i) #9
  %r578 = bitcast i64 %r578.rs4o to double
  %r579 = bitcast double %r578 to i64
  %r580 = and i64 %r579, 281474976710655
  %r187 = inttoptr i64 %r580 to ptr
  %r574.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r574.rs4o = call i64 asm "", "=r,0"(i64 %r574.rs4i) #9
  %r574 = bitcast i64 %r574.rs4o to double
  %r575 = bitcast double %r574 to i64
  %r576 = and i64 %r575, 281474976710655
  %r577 = inttoptr i64 %r576 to ptr
  %r188 = getelementptr i8, ptr %r577, i64 16
  %r189 = getelementptr double, ptr %r188, i64 2
  %r190 = ptrtoint ptr %r189 to i64
  %r573.rs4i = ptrtoint ptr addrspace(1) %.122 to i64
  %r573.rs4o = call i64 asm "", "=r,0"(i64 %r573.rs4i) #9
  %r573 = bitcast i64 %r573.rs4o to double
  store double %r573, ptr %r189, align 8
  %r572.rs4i = ptrtoint ptr addrspace(1) %.122 to i64
  %r572.rs4o = call i64 asm "", "=r,0"(i64 %r572.rs4i) #9
  %r572 = bitcast i64 %r572.rs4o to double
  %r191 = bitcast double %r572 to i64
  %r570.rs4i = ptrtoint ptr addrspace(1) %.122 to i64
  %r570.rs4o = call i64 asm "", "=r,0"(i64 %r570.rs4i) #9
  %r570 = bitcast i64 %r570.rs4o to double
  %r571 = bitcast double %r570 to i64
  %r192 = lshr i64 %r571, 48
  %r193 = icmp eq i64 %r192, 0
  %r568.rs4i = ptrtoint ptr addrspace(1) %.122 to i64
  %r568.rs4o = call i64 asm "", "=r,0"(i64 %r568.rs4i) #9
  %r568 = bitcast i64 %r568.rs4o to double
  %r569 = bitcast double %r568 to i64
  %r194 = icmp uge i64 %r569, 4096
  %r195 = and i1 %r193, %r194
  %r196 = icmp eq i64 %r192, 32765
  %r197 = icmp eq i64 %r192, 32767
  %r198 = icmp eq i64 %r192, 32762
  %r199 = or i1 %r196, %r197
  %r200 = or i1 %r199, %r198
  %r201 = or i1 %r200, %r195
  br i1 %r201, label %class_field_set.gc_bookkeeping.22, label %class_field_set.gc_bookkeeping.done.23

class_field_set.fallback.18:                      ; preds = %class_field_inline.guardcall.21
  %r562.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r562.rs4o = call i64 asm "", "=r,0"(i64 %r562.rs4i) #9
  %r562 = bitcast i64 %r562.rs4o to double
  %r563 = bitcast double %r562 to i64
  %r564.rs4i = ptrtoint ptr addrspace(1) %.122 to i64
  %r564.rs4o = call i64 asm "", "=r,0"(i64 %r564.rs4i) #9
  %r564 = bitcast i64 %r564.rs4o to double
  %r565 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.9.handle, align 8
  %r566 = bitcast double %r565 to i64
  %r567 = and i64 %r566, 281474976710655
  %statepoint_token7 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479956997, i64 %r563, i64 %r567, double %r564, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1, ptr addrspace(1) %.124, ptr addrspace(1) %.127, ptr addrspace(1) %.131) ]
  %rs4gc.s1.relocated8 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token7, i32 0, i32 0) ; (%.1, %.1)
  %rs4gc.s5.relocated9 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token7, i32 1, i32 1) ; (%.124, %.124)
  %rs4gc.s6.relocated10 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token7, i32 2, i32 2) ; (%.127, %.127)
  %rs4gc.s7.relocated11 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token7, i32 3, i32 3) ; (%.131, %.131)
  br label %class_field_set.merge.19

class_field_set.merge.19:                         ; preds = %class_field_set.gc_bookkeeping.done.23, %class_field_set.fallback.18
  %.232 = phi ptr addrspace(1) [ %.131, %class_field_set.gc_bookkeeping.done.23 ], [ %rs4gc.s7.relocated11, %class_field_set.fallback.18 ]
  %.228 = phi ptr addrspace(1) [ %.127, %class_field_set.gc_bookkeeping.done.23 ], [ %rs4gc.s6.relocated10, %class_field_set.fallback.18 ]
  %.225 = phi ptr addrspace(1) [ %.124, %class_field_set.gc_bookkeeping.done.23 ], [ %rs4gc.s5.relocated9, %class_field_set.fallback.18 ]
  %.2 = phi ptr addrspace(1) [ %.1, %class_field_set.gc_bookkeeping.done.23 ], [ %rs4gc.s1.relocated8, %class_field_set.fallback.18 ]
  %r215.rs4i = ptrtoint ptr addrspace(1) %.2 to i64
  %r215.rs4o = call i64 asm "", "=r,0"(i64 %r215.rs4i) #9
  %r215 = bitcast i64 %r215.rs4o to double
  %r216.rs4i = ptrtoint ptr addrspace(1) %.225 to i64
  %r216.rs4o = call i64 asm "", "=r,0"(i64 %r216.rs4i) #9
  %r216 = bitcast i64 %r216.rs4o to double
  %r218 = bitcast double %r215 to i64
  %r219 = and i64 %r218, 281474976710655
  %r220 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.10.handle, align 8
  %r221 = bitcast double %r220 to i64
  %r222 = and i64 %r221, 281474976710655
  %r223 = bitcast double %r216 to i64
  %r224 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r225 = icmp eq i8 %r224, 0
  %r226 = lshr i64 %r218, 48
  %r227 = icmp eq i64 %r226, 32765
  %r228 = icmp ugt i64 %r219, 1048575
  %r229 = and i1 %r227, %r228
  %r230 = and i1 %r229, %r225
  br i1 %r230, label %class_field_inline.deref.30, label %class_field_inline.guardcall.31

class_field_inline.deref.20:                      ; preds = %class_field_set.merge.9
  %r157 = inttoptr i64 %r145 to ptr
  %r158 = getelementptr i8, ptr %r157, i64 -8
  %r159 = load i8, ptr %r158, align 1
  %r160 = icmp eq i8 %r159, 2
  %r161 = getelementptr i8, ptr %r157, i64 -7
  %r162 = load i8, ptr %r161, align 1
  %r163 = and i8 %r162, -128
  %r164 = icmp eq i8 %r163, 0
  %r165 = getelementptr i8, ptr %r157, i64 -6
  %r166 = load i16, ptr %r165, align 2
  %r167 = getelementptr i8, ptr %r157, i64 0
  %r168 = load i32, ptr %r167, align 4
  %r169 = icmp eq i32 %r168, 3
  %r170 = getelementptr i8, ptr %r157, i64 4
  %r171 = load i32, ptr %r170, align 4
  %r172 = icmp eq i32 %r171, %r12
  %r173 = and i1 %r160, %r164
  %r174 = and i1 %r173, %r169
  %r175 = and i1 %r174, %r172
  %r176 = and i16 %r166, 3072
  %r177 = icmp eq i16 %r176, 0
  %r178 = and i1 %r175, %r177
  %r179 = and i16 %r166, 1
  %r180 = icmp eq i16 %r179, 0
  %r181 = and i1 %r178, %r180
  %r182 = and i16 %r166, 128
  %r183 = icmp eq i16 %r182, 0
  %r184 = and i1 %r181, %r183
  br i1 %r184, label %class_field_set.fast.17, label %class_field_inline.guardcall.21

class_field_inline.guardcall.21:                  ; preds = %class_field_inline.deref.20, %class_field_set.merge.9
  %r185 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479956997, double %r141, i32 3, i32 %r12, i64 %r148, i32 2, double %r142, i32 0) #9
  %r186 = icmp ne i32 %r185, 0
  br i1 %r186, label %class_field_set.fast.17, label %class_field_set.fallback.18

class_field_set.gc_bookkeeping.22:                ; preds = %class_field_set.fast.17
  %r561.rs4i = ptrtoint ptr addrspace(1) %.122 to i64
  %r561.rs4o = call i64 asm "", "=r,0"(i64 %r561.rs4i) #9
  %r561 = bitcast i64 %r561.rs4o to double
  call void @js_string_addref_if_heap_string(double %r561) #9
  %r558.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r558.rs4o = call i64 asm "", "=r,0"(i64 %r558.rs4i) #9
  %r558 = bitcast i64 %r558.rs4o to double
  %r559 = bitcast double %r558 to i64
  %r560 = and i64 %r559, 281474976710655
  %r202 = inttoptr i64 %r560 to ptr
  %r554.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r554.rs4o = call i64 asm "", "=r,0"(i64 %r554.rs4i) #9
  %r554 = bitcast i64 %r554.rs4o to double
  %r555 = bitcast double %r554 to i64
  %r556 = and i64 %r555, 281474976710655
  %r557 = inttoptr i64 %r556 to ptr
  %r203 = getelementptr i8, ptr %r557, i64 -6
  %r204 = load i16, ptr %r203, align 2
  %r205 = and i16 %r204, -12288
  %r206 = icmp eq i16 %r205, -28672
  br i1 %r206, label %class_field_set.layout_note.done.25, label %class_field_set.layout_note.24

class_field_set.gc_bookkeeping.done.23:           ; preds = %class_field_set.barrier.26, %class_field_set.layout_note.done.25, %class_field_set.fast.17
  br label %class_field_set.merge.19

class_field_set.layout_note.24:                   ; preds = %class_field_set.gc_bookkeeping.22
  %r549.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r549.rs4o = call i64 asm "", "=r,0"(i64 %r549.rs4i) #9
  %r549 = bitcast i64 %r549.rs4o to double
  %r550 = bitcast double %r549 to i64
  %r551 = and i64 %r550, 281474976710655
  %r552.rs4i = ptrtoint ptr addrspace(1) %.122 to i64
  %r552.rs4o = call i64 asm "", "=r,0"(i64 %r552.rs4i) #9
  %r552 = bitcast i64 %r552.rs4o to double
  %r553 = bitcast double %r552 to i64
  call void @js_gc_note_slot_layout(i64 %r551, i32 2, i64 %r553) #9
  br label %class_field_set.layout_note.done.25

class_field_set.layout_note.done.25:              ; preds = %class_field_set.layout_note.24, %class_field_set.gc_bookkeeping.22
  %r546.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r546.rs4o = call i64 asm "", "=r,0"(i64 %r546.rs4i) #9
  %r546 = bitcast i64 %r546.rs4o to double
  %r547 = bitcast double %r546 to i64
  %r548 = and i64 %r547, 281474976710655
  %r207 = sub nsw i64 %r548, 7
  %r208 = inttoptr i64 %r207 to ptr
  %r209 = load i8, ptr %r208, align 1
  %r210 = and i8 %r209, 32
  %r211 = icmp ne i8 %r210, 0
  %r212 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r213 = icmp ne i32 %r212, 0
  %r214 = or i1 %r211, %r213
  br i1 %r214, label %class_field_set.barrier.26, label %class_field_set.gc_bookkeeping.done.23

class_field_set.barrier.26:                       ; preds = %class_field_set.layout_note.done.25
  %r542.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r542.rs4o = call i64 asm "", "=r,0"(i64 %r542.rs4i) #9
  %r542 = bitcast i64 %r542.rs4o to double
  %r543 = bitcast double %r542 to i64
  %r544.rs4i = ptrtoint ptr addrspace(1) %.122 to i64
  %r544.rs4o = call i64 asm "", "=r,0"(i64 %r544.rs4i) #9
  %r544 = bitcast i64 %r544.rs4o to double
  %r545 = bitcast double %r544 to i64
  call void @js_write_barrier_slot(i64 %r543, i64 %r190, i64 %r545) #9
  br label %class_field_set.gc_bookkeeping.done.23

class_field_set.fast.27:                          ; preds = %class_field_inline.guardcall.31, %class_field_inline.deref.30
  %r539.rs4i = ptrtoint ptr addrspace(1) %.2 to i64
  %r539.rs4o = call i64 asm "", "=r,0"(i64 %r539.rs4i) #9
  %r539 = bitcast i64 %r539.rs4o to double
  %r540 = bitcast double %r539 to i64
  %r541 = and i64 %r540, 281474976710655
  %r261 = inttoptr i64 %r541 to ptr
  %r535.rs4i = ptrtoint ptr addrspace(1) %.2 to i64
  %r535.rs4o = call i64 asm "", "=r,0"(i64 %r535.rs4i) #9
  %r535 = bitcast i64 %r535.rs4o to double
  %r536 = bitcast double %r535 to i64
  %r537 = and i64 %r536, 281474976710655
  %r538 = inttoptr i64 %r537 to ptr
  %r262 = getelementptr i8, ptr %r538, i64 16
  %r263 = getelementptr double, ptr %r262, i64 3
  %r264 = ptrtoint ptr %r263 to i64
  %r534.rs4i = ptrtoint ptr addrspace(1) %.225 to i64
  %r534.rs4o = call i64 asm "", "=r,0"(i64 %r534.rs4i) #9
  %r534 = bitcast i64 %r534.rs4o to double
  store double %r534, ptr %r263, align 8
  %r533.rs4i = ptrtoint ptr addrspace(1) %.225 to i64
  %r533.rs4o = call i64 asm "", "=r,0"(i64 %r533.rs4i) #9
  %r533 = bitcast i64 %r533.rs4o to double
  %r265 = bitcast double %r533 to i64
  %r531.rs4i = ptrtoint ptr addrspace(1) %.225 to i64
  %r531.rs4o = call i64 asm "", "=r,0"(i64 %r531.rs4i) #9
  %r531 = bitcast i64 %r531.rs4o to double
  %r532 = bitcast double %r531 to i64
  %r266 = lshr i64 %r532, 48
  %r267 = icmp eq i64 %r266, 0
  %r529.rs4i = ptrtoint ptr addrspace(1) %.225 to i64
  %r529.rs4o = call i64 asm "", "=r,0"(i64 %r529.rs4i) #9
  %r529 = bitcast i64 %r529.rs4o to double
  %r530 = bitcast double %r529 to i64
  %r268 = icmp uge i64 %r530, 4096
  %r269 = and i1 %r267, %r268
  %r270 = icmp eq i64 %r266, 32765
  %r271 = icmp eq i64 %r266, 32767
  %r272 = icmp eq i64 %r266, 32762
  %r273 = or i1 %r270, %r271
  %r274 = or i1 %r273, %r272
  %r275 = or i1 %r274, %r269
  br i1 %r275, label %class_field_set.gc_bookkeeping.32, label %class_field_set.gc_bookkeeping.done.33

class_field_set.fallback.28:                      ; preds = %class_field_inline.guardcall.31
  %r523.rs4i = ptrtoint ptr addrspace(1) %.2 to i64
  %r523.rs4o = call i64 asm "", "=r,0"(i64 %r523.rs4i) #9
  %r523 = bitcast i64 %r523.rs4o to double
  %r524 = bitcast double %r523 to i64
  %r525.rs4i = ptrtoint ptr addrspace(1) %.225 to i64
  %r525.rs4o = call i64 asm "", "=r,0"(i64 %r525.rs4i) #9
  %r525 = bitcast i64 %r525.rs4o to double
  %r526 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.10.handle, align 8
  %r527 = bitcast double %r526 to i64
  %r528 = and i64 %r527, 281474976710655
  %statepoint_token12 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479956998, i64 %r524, i64 %r528, double %r525, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2, ptr addrspace(1) %.228, ptr addrspace(1) %.232) ]
  %rs4gc.s1.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token12, i32 0, i32 0) ; (%.2, %.2)
  %rs4gc.s6.relocated14 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token12, i32 1, i32 1) ; (%.228, %.228)
  %rs4gc.s7.relocated15 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token12, i32 2, i32 2) ; (%.232, %.232)
  br label %class_field_set.merge.29

class_field_set.merge.29:                         ; preds = %class_field_set.gc_bookkeeping.done.33, %class_field_set.fallback.28
  %.333 = phi ptr addrspace(1) [ %.232, %class_field_set.gc_bookkeeping.done.33 ], [ %rs4gc.s7.relocated15, %class_field_set.fallback.28 ]
  %.329 = phi ptr addrspace(1) [ %.228, %class_field_set.gc_bookkeeping.done.33 ], [ %rs4gc.s6.relocated14, %class_field_set.fallback.28 ]
  %.3 = phi ptr addrspace(1) [ %.2, %class_field_set.gc_bookkeeping.done.33 ], [ %rs4gc.s1.relocated13, %class_field_set.fallback.28 ]
  %r284.rs4i = ptrtoint ptr addrspace(1) %.3 to i64
  %r284.rs4o = call i64 asm "", "=r,0"(i64 %r284.rs4i) #9
  %r284 = bitcast i64 %r284.rs4o to double
  %r285.rs4i = ptrtoint ptr addrspace(1) %.329 to i64
  %r285.rs4o = call i64 asm "", "=r,0"(i64 %r285.rs4i) #9
  %r285 = bitcast i64 %r285.rs4o to double
  %r287 = bitcast double %r284 to i64
  %r288 = and i64 %r287, 281474976710655
  %r289 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.11.handle, align 8
  %r290 = bitcast double %r289 to i64
  %r291 = and i64 %r290, 281474976710655
  %r292 = bitcast double %r285 to i64
  %r293 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r294 = icmp eq i8 %r293, 0
  %r295 = lshr i64 %r287, 48
  %r296 = icmp eq i64 %r295, 32765
  %r297 = icmp ugt i64 %r288, 1048575
  %r298 = and i1 %r296, %r297
  %r299 = and i1 %r298, %r294
  br i1 %r299, label %class_field_inline.deref.38, label %class_field_inline.guardcall.39

class_field_inline.deref.30:                      ; preds = %class_field_set.merge.19
  %r231 = inttoptr i64 %r219 to ptr
  %r232 = getelementptr i8, ptr %r231, i64 -8
  %r233 = load i8, ptr %r232, align 1
  %r234 = icmp eq i8 %r233, 2
  %r235 = getelementptr i8, ptr %r231, i64 -7
  %r236 = load i8, ptr %r235, align 1
  %r237 = and i8 %r236, -128
  %r238 = icmp eq i8 %r237, 0
  %r239 = getelementptr i8, ptr %r231, i64 -6
  %r240 = load i16, ptr %r239, align 2
  %r241 = getelementptr i8, ptr %r231, i64 0
  %r242 = load i32, ptr %r241, align 4
  %r243 = icmp eq i32 %r242, 3
  %r244 = getelementptr i8, ptr %r231, i64 4
  %r245 = load i32, ptr %r244, align 4
  %r246 = icmp eq i32 %r245, %r12
  %r247 = and i1 %r234, %r238
  %r248 = and i1 %r247, %r243
  %r249 = and i1 %r248, %r246
  %r250 = and i16 %r240, 3072
  %r251 = icmp eq i16 %r250, 0
  %r252 = and i1 %r249, %r251
  %r253 = and i16 %r240, 1
  %r254 = icmp eq i16 %r253, 0
  %r255 = and i1 %r252, %r254
  %r256 = and i16 %r240, 128
  %r257 = icmp eq i16 %r256, 0
  %r258 = and i1 %r255, %r257
  br i1 %r258, label %class_field_set.fast.27, label %class_field_inline.guardcall.31

class_field_inline.guardcall.31:                  ; preds = %class_field_inline.deref.30, %class_field_set.merge.19
  %r259 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479956998, double %r215, i32 3, i32 %r12, i64 %r222, i32 3, double %r216, i32 0) #9
  %r260 = icmp ne i32 %r259, 0
  br i1 %r260, label %class_field_set.fast.27, label %class_field_set.fallback.28

class_field_set.gc_bookkeeping.32:                ; preds = %class_field_set.fast.27
  %r522.rs4i = ptrtoint ptr addrspace(1) %.225 to i64
  %r522.rs4o = call i64 asm "", "=r,0"(i64 %r522.rs4i) #9
  %r522 = bitcast i64 %r522.rs4o to double
  call void @js_string_addref_if_heap_string(double %r522) #9
  %r517.rs4i = ptrtoint ptr addrspace(1) %.2 to i64
  %r517.rs4o = call i64 asm "", "=r,0"(i64 %r517.rs4i) #9
  %r517 = bitcast i64 %r517.rs4o to double
  %r518 = bitcast double %r517 to i64
  %r519 = and i64 %r518, 281474976710655
  %r520.rs4i = ptrtoint ptr addrspace(1) %.225 to i64
  %r520.rs4o = call i64 asm "", "=r,0"(i64 %r520.rs4i) #9
  %r520 = bitcast i64 %r520.rs4o to double
  %r521 = bitcast double %r520 to i64
  call void @js_gc_note_slot_layout(i64 %r519, i32 3, i64 %r521) #9
  %r514.rs4i = ptrtoint ptr addrspace(1) %.2 to i64
  %r514.rs4o = call i64 asm "", "=r,0"(i64 %r514.rs4i) #9
  %r514 = bitcast i64 %r514.rs4o to double
  %r515 = bitcast double %r514 to i64
  %r516 = and i64 %r515, 281474976710655
  %r276 = sub nsw i64 %r516, 7
  %r277 = inttoptr i64 %r276 to ptr
  %r278 = load i8, ptr %r277, align 1
  %r279 = and i8 %r278, 32
  %r280 = icmp ne i8 %r279, 0
  %r281 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r282 = icmp ne i32 %r281, 0
  %r283 = or i1 %r280, %r282
  br i1 %r283, label %class_field_set.barrier.34, label %class_field_set.gc_bookkeeping.done.33

class_field_set.gc_bookkeeping.done.33:           ; preds = %class_field_set.barrier.34, %class_field_set.gc_bookkeeping.32, %class_field_set.fast.27
  br label %class_field_set.merge.29

class_field_set.barrier.34:                       ; preds = %class_field_set.gc_bookkeeping.32
  %r510.rs4i = ptrtoint ptr addrspace(1) %.2 to i64
  %r510.rs4o = call i64 asm "", "=r,0"(i64 %r510.rs4i) #9
  %r510 = bitcast i64 %r510.rs4o to double
  %r511 = bitcast double %r510 to i64
  %r512.rs4i = ptrtoint ptr addrspace(1) %.225 to i64
  %r512.rs4o = call i64 asm "", "=r,0"(i64 %r512.rs4i) #9
  %r512 = bitcast i64 %r512.rs4o to double
  %r513 = bitcast double %r512 to i64
  call void @js_write_barrier_slot(i64 %r511, i64 %r264, i64 %r513) #9
  br label %class_field_set.gc_bookkeeping.done.33

class_field_set.fast.35:                          ; preds = %class_field_inline.guardcall.39, %class_field_inline.deref.38
  %r507.rs4i = ptrtoint ptr addrspace(1) %.3 to i64
  %r507.rs4o = call i64 asm "", "=r,0"(i64 %r507.rs4i) #9
  %r507 = bitcast i64 %r507.rs4o to double
  %r508 = bitcast double %r507 to i64
  %r509 = and i64 %r508, 281474976710655
  %r330 = inttoptr i64 %r509 to ptr
  %r503.rs4i = ptrtoint ptr addrspace(1) %.3 to i64
  %r503.rs4o = call i64 asm "", "=r,0"(i64 %r503.rs4i) #9
  %r503 = bitcast i64 %r503.rs4o to double
  %r504 = bitcast double %r503 to i64
  %r505 = and i64 %r504, 281474976710655
  %r506 = inttoptr i64 %r505 to ptr
  %r331 = getelementptr i8, ptr %r506, i64 16
  %r332 = getelementptr double, ptr %r331, i64 4
  %r333 = ptrtoint ptr %r332 to i64
  %r502.rs4i = ptrtoint ptr addrspace(1) %.329 to i64
  %r502.rs4o = call i64 asm "", "=r,0"(i64 %r502.rs4i) #9
  %r502 = bitcast i64 %r502.rs4o to double
  store double %r502, ptr %r332, align 8
  %r501.rs4i = ptrtoint ptr addrspace(1) %.329 to i64
  %r501.rs4o = call i64 asm "", "=r,0"(i64 %r501.rs4i) #9
  %r501 = bitcast i64 %r501.rs4o to double
  %r334 = bitcast double %r501 to i64
  %r499.rs4i = ptrtoint ptr addrspace(1) %.329 to i64
  %r499.rs4o = call i64 asm "", "=r,0"(i64 %r499.rs4i) #9
  %r499 = bitcast i64 %r499.rs4o to double
  %r500 = bitcast double %r499 to i64
  %r335 = lshr i64 %r500, 48
  %r336 = icmp eq i64 %r335, 0
  %r497.rs4i = ptrtoint ptr addrspace(1) %.329 to i64
  %r497.rs4o = call i64 asm "", "=r,0"(i64 %r497.rs4i) #9
  %r497 = bitcast i64 %r497.rs4o to double
  %r498 = bitcast double %r497 to i64
  %r337 = icmp uge i64 %r498, 4096
  %r338 = and i1 %r336, %r337
  %r339 = icmp eq i64 %r335, 32765
  %r340 = icmp eq i64 %r335, 32767
  %r341 = icmp eq i64 %r335, 32762
  %r342 = or i1 %r339, %r340
  %r343 = or i1 %r342, %r341
  %r344 = or i1 %r343, %r338
  br i1 %r344, label %class_field_set.gc_bookkeeping.40, label %class_field_set.gc_bookkeeping.done.41

class_field_set.fallback.36:                      ; preds = %class_field_inline.guardcall.39
  %r491.rs4i = ptrtoint ptr addrspace(1) %.3 to i64
  %r491.rs4o = call i64 asm "", "=r,0"(i64 %r491.rs4i) #9
  %r491 = bitcast i64 %r491.rs4o to double
  %r492 = bitcast double %r491 to i64
  %r493.rs4i = ptrtoint ptr addrspace(1) %.329 to i64
  %r493.rs4o = call i64 asm "", "=r,0"(i64 %r493.rs4i) #9
  %r493 = bitcast i64 %r493.rs4o to double
  %r494 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.11.handle, align 8
  %r495 = bitcast double %r494 to i64
  %r496 = and i64 %r495, 281474976710655
  %statepoint_token16 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479956999, i64 %r492, i64 %r496, double %r493, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.333, ptr addrspace(1) %.3) ]
  %rs4gc.s7.relocated17 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 0, i32 0) ; (%.333, %.333)
  %rs4gc.s1.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 1, i32 1) ; (%.3, %.3)
  br label %class_field_set.merge.37

class_field_set.merge.37:                         ; preds = %class_field_set.gc_bookkeeping.done.41, %class_field_set.fallback.36
  %.434 = phi ptr addrspace(1) [ %.333, %class_field_set.gc_bookkeeping.done.41 ], [ %rs4gc.s7.relocated17, %class_field_set.fallback.36 ]
  %.4 = phi ptr addrspace(1) [ %.3, %class_field_set.gc_bookkeeping.done.41 ], [ %rs4gc.s1.relocated18, %class_field_set.fallback.36 ]
  %r358.rs4i = ptrtoint ptr addrspace(1) %.4 to i64
  %r358.rs4o = call i64 asm "", "=r,0"(i64 %r358.rs4i) #9
  %r358 = bitcast i64 %r358.rs4o to double
  %r359.rs4i = ptrtoint ptr addrspace(1) %.434 to i64
  %r359.rs4o = call i64 asm "", "=r,0"(i64 %r359.rs4i) #9
  %r359 = bitcast i64 %r359.rs4o to double
  %r361 = bitcast double %r358 to i64
  %r362 = and i64 %r361, 281474976710655
  %r363 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.12.handle, align 8
  %r364 = bitcast double %r363 to i64
  %r365 = and i64 %r364, 281474976710655
  %r366 = bitcast double %r359 to i64
  %r367 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r368 = icmp eq i8 %r367, 0
  %r369 = lshr i64 %r361, 48
  %r370 = icmp eq i64 %r369, 32765
  %r371 = icmp ugt i64 %r362, 1048575
  %r372 = and i1 %r370, %r371
  %r373 = and i1 %r372, %r368
  br i1 %r373, label %class_field_inline.deref.48, label %class_field_inline.guardcall.49

class_field_inline.deref.38:                      ; preds = %class_field_set.merge.29
  %r300 = inttoptr i64 %r288 to ptr
  %r301 = getelementptr i8, ptr %r300, i64 -8
  %r302 = load i8, ptr %r301, align 1
  %r303 = icmp eq i8 %r302, 2
  %r304 = getelementptr i8, ptr %r300, i64 -7
  %r305 = load i8, ptr %r304, align 1
  %r306 = and i8 %r305, -128
  %r307 = icmp eq i8 %r306, 0
  %r308 = getelementptr i8, ptr %r300, i64 -6
  %r309 = load i16, ptr %r308, align 2
  %r310 = getelementptr i8, ptr %r300, i64 0
  %r311 = load i32, ptr %r310, align 4
  %r312 = icmp eq i32 %r311, 3
  %r313 = getelementptr i8, ptr %r300, i64 4
  %r314 = load i32, ptr %r313, align 4
  %r315 = icmp eq i32 %r314, %r12
  %r316 = and i1 %r303, %r307
  %r317 = and i1 %r316, %r312
  %r318 = and i1 %r317, %r315
  %r319 = and i16 %r309, 3072
  %r320 = icmp eq i16 %r319, 0
  %r321 = and i1 %r318, %r320
  %r322 = and i16 %r309, 1
  %r323 = icmp eq i16 %r322, 0
  %r324 = and i1 %r321, %r323
  %r325 = and i16 %r309, 128
  %r326 = icmp eq i16 %r325, 0
  %r327 = and i1 %r324, %r326
  br i1 %r327, label %class_field_set.fast.35, label %class_field_inline.guardcall.39

class_field_inline.guardcall.39:                  ; preds = %class_field_inline.deref.38, %class_field_set.merge.29
  %r328 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479956999, double %r284, i32 3, i32 %r12, i64 %r291, i32 4, double %r285, i32 0) #9
  %r329 = icmp ne i32 %r328, 0
  br i1 %r329, label %class_field_set.fast.35, label %class_field_set.fallback.36

class_field_set.gc_bookkeeping.40:                ; preds = %class_field_set.fast.35
  %r490.rs4i = ptrtoint ptr addrspace(1) %.329 to i64
  %r490.rs4o = call i64 asm "", "=r,0"(i64 %r490.rs4i) #9
  %r490 = bitcast i64 %r490.rs4o to double
  call void @js_string_addref_if_heap_string(double %r490) #9
  %r487.rs4i = ptrtoint ptr addrspace(1) %.3 to i64
  %r487.rs4o = call i64 asm "", "=r,0"(i64 %r487.rs4i) #9
  %r487 = bitcast i64 %r487.rs4o to double
  %r488 = bitcast double %r487 to i64
  %r489 = and i64 %r488, 281474976710655
  %r345 = inttoptr i64 %r489 to ptr
  %r483.rs4i = ptrtoint ptr addrspace(1) %.3 to i64
  %r483.rs4o = call i64 asm "", "=r,0"(i64 %r483.rs4i) #9
  %r483 = bitcast i64 %r483.rs4o to double
  %r484 = bitcast double %r483 to i64
  %r485 = and i64 %r484, 281474976710655
  %r486 = inttoptr i64 %r485 to ptr
  %r346 = getelementptr i8, ptr %r486, i64 -6
  %r347 = load i16, ptr %r346, align 2
  %r348 = and i16 %r347, -12288
  %r349 = icmp eq i16 %r348, -28672
  br i1 %r349, label %class_field_set.layout_note.done.43, label %class_field_set.layout_note.42

class_field_set.gc_bookkeeping.done.41:           ; preds = %class_field_set.barrier.44, %class_field_set.layout_note.done.43, %class_field_set.fast.35
  br label %class_field_set.merge.37

class_field_set.layout_note.42:                   ; preds = %class_field_set.gc_bookkeeping.40
  %r478.rs4i = ptrtoint ptr addrspace(1) %.3 to i64
  %r478.rs4o = call i64 asm "", "=r,0"(i64 %r478.rs4i) #9
  %r478 = bitcast i64 %r478.rs4o to double
  %r479 = bitcast double %r478 to i64
  %r480 = and i64 %r479, 281474976710655
  %r481.rs4i = ptrtoint ptr addrspace(1) %.329 to i64
  %r481.rs4o = call i64 asm "", "=r,0"(i64 %r481.rs4i) #9
  %r481 = bitcast i64 %r481.rs4o to double
  %r482 = bitcast double %r481 to i64
  call void @js_gc_note_slot_layout(i64 %r480, i32 4, i64 %r482) #9
  br label %class_field_set.layout_note.done.43

class_field_set.layout_note.done.43:              ; preds = %class_field_set.layout_note.42, %class_field_set.gc_bookkeeping.40
  %r475.rs4i = ptrtoint ptr addrspace(1) %.3 to i64
  %r475.rs4o = call i64 asm "", "=r,0"(i64 %r475.rs4i) #9
  %r475 = bitcast i64 %r475.rs4o to double
  %r476 = bitcast double %r475 to i64
  %r477 = and i64 %r476, 281474976710655
  %r350 = sub nsw i64 %r477, 7
  %r351 = inttoptr i64 %r350 to ptr
  %r352 = load i8, ptr %r351, align 1
  %r353 = and i8 %r352, 32
  %r354 = icmp ne i8 %r353, 0
  %r355 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r356 = icmp ne i32 %r355, 0
  %r357 = or i1 %r354, %r356
  br i1 %r357, label %class_field_set.barrier.44, label %class_field_set.gc_bookkeeping.done.41

class_field_set.barrier.44:                       ; preds = %class_field_set.layout_note.done.43
  %r471.rs4i = ptrtoint ptr addrspace(1) %.3 to i64
  %r471.rs4o = call i64 asm "", "=r,0"(i64 %r471.rs4i) #9
  %r471 = bitcast i64 %r471.rs4o to double
  %r472 = bitcast double %r471 to i64
  %r473.rs4i = ptrtoint ptr addrspace(1) %.329 to i64
  %r473.rs4o = call i64 asm "", "=r,0"(i64 %r473.rs4i) #9
  %r473 = bitcast i64 %r473.rs4o to double
  %r474 = bitcast double %r473 to i64
  call void @js_write_barrier_slot(i64 %r472, i64 %r333, i64 %r474) #9
  br label %class_field_set.gc_bookkeeping.done.41

class_field_set.fast.45:                          ; preds = %class_field_inline.guardcall.49, %class_field_inline.deref.48
  %r468.rs4i = ptrtoint ptr addrspace(1) %.4 to i64
  %r468.rs4o = call i64 asm "", "=r,0"(i64 %r468.rs4i) #9
  %r468 = bitcast i64 %r468.rs4o to double
  %r469 = bitcast double %r468 to i64
  %r470 = and i64 %r469, 281474976710655
  %r404 = inttoptr i64 %r470 to ptr
  %r464.rs4i = ptrtoint ptr addrspace(1) %.4 to i64
  %r464.rs4o = call i64 asm "", "=r,0"(i64 %r464.rs4i) #9
  %r464 = bitcast i64 %r464.rs4o to double
  %r465 = bitcast double %r464 to i64
  %r466 = and i64 %r465, 281474976710655
  %r467 = inttoptr i64 %r466 to ptr
  %r405 = getelementptr i8, ptr %r467, i64 16
  %r406 = getelementptr double, ptr %r405, i64 5
  %r407 = ptrtoint ptr %r406 to i64
  %r463.rs4i = ptrtoint ptr addrspace(1) %.434 to i64
  %r463.rs4o = call i64 asm "", "=r,0"(i64 %r463.rs4i) #9
  %r463 = bitcast i64 %r463.rs4o to double
  store double %r463, ptr %r406, align 8
  %r462.rs4i = ptrtoint ptr addrspace(1) %.434 to i64
  %r462.rs4o = call i64 asm "", "=r,0"(i64 %r462.rs4i) #9
  %r462 = bitcast i64 %r462.rs4o to double
  %r408 = bitcast double %r462 to i64
  %r460.rs4i = ptrtoint ptr addrspace(1) %.434 to i64
  %r460.rs4o = call i64 asm "", "=r,0"(i64 %r460.rs4i) #9
  %r460 = bitcast i64 %r460.rs4o to double
  %r461 = bitcast double %r460 to i64
  %r409 = lshr i64 %r461, 48
  %r410 = icmp eq i64 %r409, 0
  %r458.rs4i = ptrtoint ptr addrspace(1) %.434 to i64
  %r458.rs4o = call i64 asm "", "=r,0"(i64 %r458.rs4i) #9
  %r458 = bitcast i64 %r458.rs4o to double
  %r459 = bitcast double %r458 to i64
  %r411 = icmp uge i64 %r459, 4096
  %r412 = and i1 %r410, %r411
  %r413 = icmp eq i64 %r409, 32765
  %r414 = icmp eq i64 %r409, 32767
  %r415 = icmp eq i64 %r409, 32762
  %r416 = or i1 %r413, %r414
  %r417 = or i1 %r416, %r415
  %r418 = or i1 %r417, %r412
  br i1 %r418, label %class_field_set.gc_bookkeeping.50, label %class_field_set.gc_bookkeeping.done.51

class_field_set.fallback.46:                      ; preds = %class_field_inline.guardcall.49
  %r452.rs4i = ptrtoint ptr addrspace(1) %.4 to i64
  %r452.rs4o = call i64 asm "", "=r,0"(i64 %r452.rs4i) #9
  %r452 = bitcast i64 %r452.rs4o to double
  %r453 = bitcast double %r452 to i64
  %r454.rs4i = ptrtoint ptr addrspace(1) %.434 to i64
  %r454.rs4o = call i64 asm "", "=r,0"(i64 %r454.rs4i) #9
  %r454 = bitcast i64 %r454.rs4o to double
  %r455 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.12.handle, align 8
  %r456 = bitcast double %r455 to i64
  %r457 = and i64 %r456, 281474976710655
  %statepoint_token19 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479957000, i64 %r453, i64 %r457, double %r454, i32 0, i32 0)
  br label %class_field_set.merge.47

class_field_set.merge.47:                         ; preds = %class_field_set.gc_bookkeeping.done.51, %class_field_set.fallback.46
  br label %standalone.ctor.return.after.1

class_field_inline.deref.48:                      ; preds = %class_field_set.merge.37
  %r374 = inttoptr i64 %r362 to ptr
  %r375 = getelementptr i8, ptr %r374, i64 -8
  %r376 = load i8, ptr %r375, align 1
  %r377 = icmp eq i8 %r376, 2
  %r378 = getelementptr i8, ptr %r374, i64 -7
  %r379 = load i8, ptr %r378, align 1
  %r380 = and i8 %r379, -128
  %r381 = icmp eq i8 %r380, 0
  %r382 = getelementptr i8, ptr %r374, i64 -6
  %r383 = load i16, ptr %r382, align 2
  %r384 = getelementptr i8, ptr %r374, i64 0
  %r385 = load i32, ptr %r384, align 4
  %r386 = icmp eq i32 %r385, 3
  %r387 = getelementptr i8, ptr %r374, i64 4
  %r388 = load i32, ptr %r387, align 4
  %r389 = icmp eq i32 %r388, %r12
  %r390 = and i1 %r377, %r381
  %r391 = and i1 %r390, %r386
  %r392 = and i1 %r391, %r389
  %r393 = and i16 %r383, 3072
  %r394 = icmp eq i16 %r393, 0
  %r395 = and i1 %r392, %r394
  %r396 = and i16 %r383, 1
  %r397 = icmp eq i16 %r396, 0
  %r398 = and i1 %r395, %r397
  %r399 = and i16 %r383, 128
  %r400 = icmp eq i16 %r399, 0
  %r401 = and i1 %r398, %r400
  br i1 %r401, label %class_field_set.fast.45, label %class_field_inline.guardcall.49

class_field_inline.guardcall.49:                  ; preds = %class_field_inline.deref.48, %class_field_set.merge.37
  %r402 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479957000, double %r358, i32 3, i32 %r12, i64 %r365, i32 5, double %r359, i32 0) #9
  %r403 = icmp ne i32 %r402, 0
  br i1 %r403, label %class_field_set.fast.45, label %class_field_set.fallback.46

class_field_set.gc_bookkeeping.50:                ; preds = %class_field_set.fast.45
  %r451.rs4i = ptrtoint ptr addrspace(1) %.434 to i64
  %r451.rs4o = call i64 asm "", "=r,0"(i64 %r451.rs4i) #9
  %r451 = bitcast i64 %r451.rs4o to double
  call void @js_string_addref_if_heap_string(double %r451) #9
  %r448.rs4i = ptrtoint ptr addrspace(1) %.4 to i64
  %r448.rs4o = call i64 asm "", "=r,0"(i64 %r448.rs4i) #9
  %r448 = bitcast i64 %r448.rs4o to double
  %r449 = bitcast double %r448 to i64
  %r450 = and i64 %r449, 281474976710655
  %r419 = inttoptr i64 %r450 to ptr
  %r444.rs4i = ptrtoint ptr addrspace(1) %.4 to i64
  %r444.rs4o = call i64 asm "", "=r,0"(i64 %r444.rs4i) #9
  %r444 = bitcast i64 %r444.rs4o to double
  %r445 = bitcast double %r444 to i64
  %r446 = and i64 %r445, 281474976710655
  %r447 = inttoptr i64 %r446 to ptr
  %r420 = getelementptr i8, ptr %r447, i64 -6
  %r421 = load i16, ptr %r420, align 2
  %r422 = and i16 %r421, -12288
  %r423 = icmp eq i16 %r422, -28672
  br i1 %r423, label %class_field_set.layout_note.done.53, label %class_field_set.layout_note.52

class_field_set.gc_bookkeeping.done.51:           ; preds = %class_field_set.barrier.54, %class_field_set.layout_note.done.53, %class_field_set.fast.45
  br label %class_field_set.merge.47

class_field_set.layout_note.52:                   ; preds = %class_field_set.gc_bookkeeping.50
  %r439.rs4i = ptrtoint ptr addrspace(1) %.4 to i64
  %r439.rs4o = call i64 asm "", "=r,0"(i64 %r439.rs4i) #9
  %r439 = bitcast i64 %r439.rs4o to double
  %r440 = bitcast double %r439 to i64
  %r441 = and i64 %r440, 281474976710655
  %r442.rs4i = ptrtoint ptr addrspace(1) %.434 to i64
  %r442.rs4o = call i64 asm "", "=r,0"(i64 %r442.rs4i) #9
  %r442 = bitcast i64 %r442.rs4o to double
  %r443 = bitcast double %r442 to i64
  call void @js_gc_note_slot_layout(i64 %r441, i32 5, i64 %r443) #9
  br label %class_field_set.layout_note.done.53

class_field_set.layout_note.done.53:              ; preds = %class_field_set.layout_note.52, %class_field_set.gc_bookkeeping.50
  %r436.rs4i = ptrtoint ptr addrspace(1) %.4 to i64
  %r436.rs4o = call i64 asm "", "=r,0"(i64 %r436.rs4i) #9
  %r436 = bitcast i64 %r436.rs4o to double
  %r437 = bitcast double %r436 to i64
  %r438 = and i64 %r437, 281474976710655
  %r424 = sub nsw i64 %r438, 7
  %r425 = inttoptr i64 %r424 to ptr
  %r426 = load i8, ptr %r425, align 1
  %r427 = and i8 %r426, 32
  %r428 = icmp ne i8 %r427, 0
  %r429 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r430 = icmp ne i32 %r429, 0
  %r431 = or i1 %r428, %r430
  br i1 %r431, label %class_field_set.barrier.54, label %class_field_set.gc_bookkeeping.done.51

class_field_set.barrier.54:                       ; preds = %class_field_set.layout_note.done.53
  %r432.rs4i = ptrtoint ptr addrspace(1) %.4 to i64
  %r432.rs4o = call i64 asm "", "=r,0"(i64 %r432.rs4i) #9
  %r432 = bitcast i64 %r432.rs4o to double
  %r433 = bitcast double %r432 to i64
  %r434.rs4i = ptrtoint ptr addrspace(1) %.434 to i64
  %r434.rs4o = call i64 asm "", "=r,0"(i64 %r434.rs4i) #9
  %r434 = bitcast i64 %r434.rs4o to double
  %r435 = bitcast double %r434 to i64
  call void @js_write_barrier_slot(i64 %r433, i64 %r407, i64 %r435) #9
  br label %class_field_set.gc_bookkeeping.done.51
}

; Function Attrs: optsize
define double @test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043_constructor(double %this_arg, double %arg18, double %arg19) #6 gc "statepoint-example" {
entry.0:
  %r8 = load i32, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg18 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg19 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #9
  %r5 = bitcast i64 %r5.rs4o to double
  %r6.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r6.rs4o = call i64 asm "", "=r,0"(i64 %r6.rs4i) #9
  %r6 = bitcast i64 %r6.rs4o to double
  %r10 = bitcast double %r5 to i64
  %r11 = and i64 %r10, 281474976710655
  %r12 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.6.handle, align 8
  %r13 = bitcast double %r12 to i64
  %r14 = and i64 %r13, 281474976710655
  %r15 = bitcast double %r6 to i64
  %r16 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r17 = icmp eq i8 %r16, 0
  %r18 = lshr i64 %r10, 48
  %r19 = icmp eq i64 %r18, 32765
  %r20 = icmp ugt i64 %r11, 1048575
  %r21 = and i1 %r19, %r20
  %r22 = and i1 %r21, %r17
  br i1 %r22, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.9
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r187.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r187.rs4o = call i64 asm "", "=r,0"(i64 %r187.rs4i) #9
  %r187 = bitcast i64 %r187.rs4o to double
  %r188 = bitcast double %r187 to i64
  %r189 = and i64 %r188, 281474976710655
  %r59 = inttoptr i64 %r189 to ptr
  %r183.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r183.rs4o = call i64 asm "", "=r,0"(i64 %r183.rs4i) #9
  %r183 = bitcast i64 %r183.rs4o to double
  %r184 = bitcast double %r183 to i64
  %r185 = and i64 %r184, 281474976710655
  %r186 = inttoptr i64 %r185 to ptr
  %r60 = getelementptr i8, ptr %r186, i64 16
  %r61 = getelementptr double, ptr %r60, i64 0
  %r182.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r182.rs4o = call i64 asm "", "=r,0"(i64 %r182.rs4i) #9
  %r182 = bitcast i64 %r182.rs4o to double
  %r62 = call double @js_array_numeric_value_to_raw_f64(double %r182) #9
  store double %r62, ptr %r61, align 8
  br label %class_field_set.merge.4

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r176.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r176.rs4o = call i64 asm "", "=r,0"(i64 %r176.rs4i) #9
  %r176 = bitcast i64 %r176.rs4o to double
  %r177 = bitcast double %r176 to i64
  %r178.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r178.rs4o = call i64 asm "", "=r,0"(i64 %r178.rs4i) #9
  %r178 = bitcast i64 %r178.rs4o to double
  %r179 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.6.handle, align 8
  %r180 = bitcast double %r179 to i64
  %r181 = and i64 %r180, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479957001, i64 %r177, i64 %r181, double %r178, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s1) ]
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s1, %rs4gc.s1)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.fallback.3, %class_field_set.fast.2
  %.02 = phi ptr addrspace(1) [ %rs4gc.s1, %class_field_set.fast.2 ], [ %rs4gc.s1.relocated, %class_field_set.fallback.3 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %class_field_set.fast.2 ], [ %rs4gc.s3.relocated, %class_field_set.fallback.3 ]
  %r63.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r63.rs4o = call i64 asm "", "=r,0"(i64 %r63.rs4i) #9
  %r63 = bitcast i64 %r63.rs4o to double
  %r64.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r64.rs4o = call i64 asm "", "=r,0"(i64 %r64.rs4i) #9
  %r64 = bitcast i64 %r64.rs4o to double
  %r66 = bitcast double %r63 to i64
  %r67 = and i64 %r66, 281474976710655
  %r68 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.13.handle, align 8
  %r69 = bitcast double %r68 to i64
  %r70 = and i64 %r69, 281474976710655
  %r71 = bitcast double %r64 to i64
  %r72 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r73 = icmp eq i8 %r72, 0
  %r74 = lshr i64 %r66, 48
  %r75 = icmp eq i64 %r74, 32765
  %r76 = icmp ugt i64 %r67, 1048575
  %r77 = and i1 %r75, %r76
  %r78 = and i1 %r77, %r73
  br i1 %r78, label %class_field_inline.deref.10, label %class_field_inline.guardcall.11

class_field_inline.deref.5:                       ; preds = %entry.0
  %r23 = inttoptr i64 %r11 to ptr
  %r24 = getelementptr i8, ptr %r23, i64 -8
  %r25 = load i8, ptr %r24, align 1
  %r26 = icmp eq i8 %r25, 2
  %r27 = getelementptr i8, ptr %r23, i64 -7
  %r28 = load i8, ptr %r27, align 1
  %r29 = and i8 %r28, -128
  %r30 = icmp eq i8 %r29, 0
  %r31 = getelementptr i8, ptr %r23, i64 -6
  %r32 = load i16, ptr %r31, align 2
  %r33 = getelementptr i8, ptr %r23, i64 0
  %r34 = load i32, ptr %r33, align 4
  %r35 = icmp eq i32 %r34, 4
  %r36 = getelementptr i8, ptr %r23, i64 4
  %r37 = load i32, ptr %r36, align 4
  %r38 = icmp eq i32 %r37, %r8
  %r39 = and i1 %r26, %r30
  %r40 = and i1 %r39, %r35
  %r41 = and i1 %r40, %r38
  %r42 = and i16 %r32, 3072
  %r43 = icmp eq i16 %r42, 0
  %r44 = and i1 %r41, %r43
  %r45 = and i16 %r32, 4096
  %r46 = icmp ne i16 %r45, 0
  %r47 = and i1 %r44, %r46
  %r48 = and i16 %r32, 1
  %r49 = icmp eq i16 %r48, 0
  %r50 = and i1 %r47, %r49
  %r51 = and i16 %r32, 128
  %r52 = icmp eq i16 %r51, 0
  %r53 = and i1 %r50, %r52
  %r54 = and i64 %r15, 9218868437227405312
  %r55 = icmp ne i64 %r54, 9218868437227405312
  %r56 = and i1 %r53, %r55
  br i1 %r56, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r57 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479957001, double %r5, i32 4, i32 %r8, i64 %r14, i32 0, double %r6, i32 1) #9
  %r58 = icmp ne i32 %r57, 0
  br i1 %r58, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.fast.7:                           ; preds = %class_field_inline.guardcall.11, %class_field_inline.deref.10
  %r173.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r173.rs4o = call i64 asm "", "=r,0"(i64 %r173.rs4i) #9
  %r173 = bitcast i64 %r173.rs4o to double
  %r174 = bitcast double %r173 to i64
  %r175 = and i64 %r174, 281474976710655
  %r109 = inttoptr i64 %r175 to ptr
  %r169.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r169.rs4o = call i64 asm "", "=r,0"(i64 %r169.rs4i) #9
  %r169 = bitcast i64 %r169.rs4o to double
  %r170 = bitcast double %r169 to i64
  %r171 = and i64 %r170, 281474976710655
  %r172 = inttoptr i64 %r171 to ptr
  %r110 = getelementptr i8, ptr %r172, i64 16
  %r111 = getelementptr double, ptr %r110, i64 1
  %r112 = ptrtoint ptr %r111 to i64
  %r168.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r168.rs4o = call i64 asm "", "=r,0"(i64 %r168.rs4i) #9
  %r168 = bitcast i64 %r168.rs4o to double
  store double %r168, ptr %r111, align 8
  %r167.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r167.rs4o = call i64 asm "", "=r,0"(i64 %r167.rs4i) #9
  %r167 = bitcast i64 %r167.rs4o to double
  %r113 = bitcast double %r167 to i64
  %r165.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r165.rs4o = call i64 asm "", "=r,0"(i64 %r165.rs4i) #9
  %r165 = bitcast i64 %r165.rs4o to double
  %r166 = bitcast double %r165 to i64
  %r114 = lshr i64 %r166, 48
  %r115 = icmp eq i64 %r114, 0
  %r163.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r163.rs4o = call i64 asm "", "=r,0"(i64 %r163.rs4i) #9
  %r163 = bitcast i64 %r163.rs4o to double
  %r164 = bitcast double %r163 to i64
  %r116 = icmp uge i64 %r164, 4096
  %r117 = and i1 %r115, %r116
  %r118 = icmp eq i64 %r114, 32765
  %r119 = icmp eq i64 %r114, 32767
  %r120 = icmp eq i64 %r114, 32762
  %r121 = or i1 %r118, %r119
  %r122 = or i1 %r121, %r120
  %r123 = or i1 %r122, %r117
  br i1 %r123, label %class_field_set.gc_bookkeeping.12, label %class_field_set.gc_bookkeeping.done.13

class_field_set.fallback.8:                       ; preds = %class_field_inline.guardcall.11
  %r157.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r157.rs4o = call i64 asm "", "=r,0"(i64 %r157.rs4i) #9
  %r157 = bitcast i64 %r157.rs4o to double
  %r158 = bitcast double %r157 to i64
  %r159.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r159.rs4o = call i64 asm "", "=r,0"(i64 %r159.rs4i) #9
  %r159 = bitcast i64 %r159.rs4o to double
  %r160 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.13.handle, align 8
  %r161 = bitcast double %r160 to i64
  %r162 = and i64 %r161, 281474976710655
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479957002, i64 %r158, i64 %r162, double %r159, i32 0, i32 0)
  br label %class_field_set.merge.9

class_field_set.merge.9:                          ; preds = %class_field_set.gc_bookkeeping.done.13, %class_field_set.fallback.8
  br label %standalone.ctor.return.after.1

class_field_inline.deref.10:                      ; preds = %class_field_set.merge.4
  %r79 = inttoptr i64 %r67 to ptr
  %r80 = getelementptr i8, ptr %r79, i64 -8
  %r81 = load i8, ptr %r80, align 1
  %r82 = icmp eq i8 %r81, 2
  %r83 = getelementptr i8, ptr %r79, i64 -7
  %r84 = load i8, ptr %r83, align 1
  %r85 = and i8 %r84, -128
  %r86 = icmp eq i8 %r85, 0
  %r87 = getelementptr i8, ptr %r79, i64 -6
  %r88 = load i16, ptr %r87, align 2
  %r89 = getelementptr i8, ptr %r79, i64 0
  %r90 = load i32, ptr %r89, align 4
  %r91 = icmp eq i32 %r90, 4
  %r92 = getelementptr i8, ptr %r79, i64 4
  %r93 = load i32, ptr %r92, align 4
  %r94 = icmp eq i32 %r93, %r8
  %r95 = and i1 %r82, %r86
  %r96 = and i1 %r95, %r91
  %r97 = and i1 %r96, %r94
  %r98 = and i16 %r88, 3072
  %r99 = icmp eq i16 %r98, 0
  %r100 = and i1 %r97, %r99
  %r101 = and i16 %r88, 1
  %r102 = icmp eq i16 %r101, 0
  %r103 = and i1 %r100, %r102
  %r104 = and i16 %r88, 128
  %r105 = icmp eq i16 %r104, 0
  %r106 = and i1 %r103, %r105
  br i1 %r106, label %class_field_set.fast.7, label %class_field_inline.guardcall.11

class_field_inline.guardcall.11:                  ; preds = %class_field_inline.deref.10, %class_field_set.merge.4
  %r107 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479957002, double %r63, i32 4, i32 %r8, i64 %r70, i32 1, double %r64, i32 0) #9
  %r108 = icmp ne i32 %r107, 0
  br i1 %r108, label %class_field_set.fast.7, label %class_field_set.fallback.8

class_field_set.gc_bookkeeping.12:                ; preds = %class_field_set.fast.7
  %r156.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r156.rs4o = call i64 asm "", "=r,0"(i64 %r156.rs4i) #9
  %r156 = bitcast i64 %r156.rs4o to double
  call void @js_string_addref_if_heap_string(double %r156) #9
  %r153.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r153.rs4o = call i64 asm "", "=r,0"(i64 %r153.rs4i) #9
  %r153 = bitcast i64 %r153.rs4o to double
  %r154 = bitcast double %r153 to i64
  %r155 = and i64 %r154, 281474976710655
  %r124 = inttoptr i64 %r155 to ptr
  %r149.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r149.rs4o = call i64 asm "", "=r,0"(i64 %r149.rs4i) #9
  %r149 = bitcast i64 %r149.rs4o to double
  %r150 = bitcast double %r149 to i64
  %r151 = and i64 %r150, 281474976710655
  %r152 = inttoptr i64 %r151 to ptr
  %r125 = getelementptr i8, ptr %r152, i64 -6
  %r126 = load i16, ptr %r125, align 2
  %r127 = and i16 %r126, -12288
  %r128 = icmp eq i16 %r127, -28672
  br i1 %r128, label %class_field_set.layout_note.done.15, label %class_field_set.layout_note.14

class_field_set.gc_bookkeeping.done.13:           ; preds = %class_field_set.barrier.16, %class_field_set.layout_note.done.15, %class_field_set.fast.7
  br label %class_field_set.merge.9

class_field_set.layout_note.14:                   ; preds = %class_field_set.gc_bookkeeping.12
  %r144.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r144.rs4o = call i64 asm "", "=r,0"(i64 %r144.rs4i) #9
  %r144 = bitcast i64 %r144.rs4o to double
  %r145 = bitcast double %r144 to i64
  %r146 = and i64 %r145, 281474976710655
  %r147.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r147.rs4o = call i64 asm "", "=r,0"(i64 %r147.rs4i) #9
  %r147 = bitcast i64 %r147.rs4o to double
  %r148 = bitcast double %r147 to i64
  call void @js_gc_note_slot_layout(i64 %r146, i32 1, i64 %r148) #9
  br label %class_field_set.layout_note.done.15

class_field_set.layout_note.done.15:              ; preds = %class_field_set.layout_note.14, %class_field_set.gc_bookkeeping.12
  %r141.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r141.rs4o = call i64 asm "", "=r,0"(i64 %r141.rs4i) #9
  %r141 = bitcast i64 %r141.rs4o to double
  %r142 = bitcast double %r141 to i64
  %r143 = and i64 %r142, 281474976710655
  %r129 = sub nsw i64 %r143, 7
  %r130 = inttoptr i64 %r129 to ptr
  %r131 = load i8, ptr %r130, align 1
  %r132 = and i8 %r131, 32
  %r133 = icmp ne i8 %r132, 0
  %r134 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r135 = icmp ne i32 %r134, 0
  %r136 = or i1 %r133, %r135
  br i1 %r136, label %class_field_set.barrier.16, label %class_field_set.gc_bookkeeping.done.13

class_field_set.barrier.16:                       ; preds = %class_field_set.layout_note.done.15
  %r137.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r137.rs4o = call i64 asm "", "=r,0"(i64 %r137.rs4i) #9
  %r137 = bitcast i64 %r137.rs4o to double
  %r138 = bitcast double %r137 to i64
  %r139.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r139.rs4o = call i64 asm "", "=r,0"(i64 %r139.rs4i) #9
  %r139 = bitcast i64 %r139.rs4o to double
  %r140 = bitcast double %r139 to i64
  call void @js_write_barrier_slot(i64 %r138, i64 %r112, i64 %r140) #9
  br label %class_field_set.gc_bookkeeping.done.13
}

; Function Attrs: optsize
define double @test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b_constructor(double %this_arg, double %arg22, double %arg23, double %arg24) #6 gc "statepoint-example" {
entry.0:
  %r9 = load i32, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg22 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg23 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %rs4gc.b4 = bitcast double %arg24 to i64
  %rs4gc.s4 = inttoptr i64 %rs4gc.b4 to ptr addrspace(1)
  %r6.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r6.rs4o = call i64 asm "", "=r,0"(i64 %r6.rs4i) #9
  %r6 = bitcast i64 %r6.rs4o to double
  %r7.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r7.rs4o = call i64 asm "", "=r,0"(i64 %r7.rs4i) #9
  %r7 = bitcast i64 %r7.rs4o to double
  %r11 = bitcast double %r6 to i64
  %r12 = and i64 %r11, 281474976710655
  %r13 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.6.handle, align 8
  %r14 = bitcast double %r13 to i64
  %r15 = and i64 %r14, 281474976710655
  %r16 = bitcast double %r7 to i64
  %r17 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r18 = icmp eq i8 %r17, 0
  %r19 = lshr i64 %r11, 48
  %r20 = icmp eq i64 %r19, 32765
  %r21 = icmp ugt i64 %r12, 1048575
  %r22 = and i1 %r20, %r21
  %r23 = and i1 %r22, %r18
  br i1 %r23, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.19
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r301.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r301.rs4o = call i64 asm "", "=r,0"(i64 %r301.rs4i) #9
  %r301 = bitcast i64 %r301.rs4o to double
  %r302 = bitcast double %r301 to i64
  %r303 = and i64 %r302, 281474976710655
  %r60 = inttoptr i64 %r303 to ptr
  %r297.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r297.rs4o = call i64 asm "", "=r,0"(i64 %r297.rs4i) #9
  %r297 = bitcast i64 %r297.rs4o to double
  %r298 = bitcast double %r297 to i64
  %r299 = and i64 %r298, 281474976710655
  %r300 = inttoptr i64 %r299 to ptr
  %r61 = getelementptr i8, ptr %r300, i64 16
  %r62 = getelementptr double, ptr %r61, i64 0
  %r296.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r296.rs4o = call i64 asm "", "=r,0"(i64 %r296.rs4i) #9
  %r296 = bitcast i64 %r296.rs4o to double
  %r63 = call double @js_array_numeric_value_to_raw_f64(double %r296) #9
  store double %r63, ptr %r62, align 8
  br label %class_field_set.merge.4

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r290.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r290.rs4o = call i64 asm "", "=r,0"(i64 %r290.rs4i) #9
  %r290 = bitcast i64 %r290.rs4o to double
  %r291 = bitcast double %r290 to i64
  %r292.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r292.rs4o = call i64 asm "", "=r,0"(i64 %r292.rs4i) #9
  %r292 = bitcast i64 %r292.rs4o to double
  %r293 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.6.handle, align 8
  %r294 = bitcast double %r293 to i64
  %r295 = and i64 %r294, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479957003, i64 %r291, i64 %r295, double %r292, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s1, ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s4) ]
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s1, %rs4gc.s1)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 2, i32 2) ; (%rs4gc.s4, %rs4gc.s4)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.fallback.3, %class_field_set.fast.2
  %.06 = phi ptr addrspace(1) [ %rs4gc.s4, %class_field_set.fast.2 ], [ %rs4gc.s4.relocated, %class_field_set.fallback.3 ]
  %.05 = phi ptr addrspace(1) [ %rs4gc.s3, %class_field_set.fast.2 ], [ %rs4gc.s3.relocated, %class_field_set.fallback.3 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s1, %class_field_set.fast.2 ], [ %rs4gc.s1.relocated, %class_field_set.fallback.3 ]
  %r64.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r64.rs4o = call i64 asm "", "=r,0"(i64 %r64.rs4i) #9
  %r64 = bitcast i64 %r64.rs4o to double
  %r65.rs4i = ptrtoint ptr addrspace(1) %.05 to i64
  %r65.rs4o = call i64 asm "", "=r,0"(i64 %r65.rs4i) #9
  %r65 = bitcast i64 %r65.rs4o to double
  %r67 = bitcast double %r64 to i64
  %r68 = and i64 %r67, 281474976710655
  %r69 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.14.handle, align 8
  %r70 = bitcast double %r69 to i64
  %r71 = and i64 %r70, 281474976710655
  %r72 = bitcast double %r65 to i64
  %r73 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r74 = icmp eq i8 %r73, 0
  %r75 = lshr i64 %r67, 48
  %r76 = icmp eq i64 %r75, 32765
  %r77 = icmp ugt i64 %r68, 1048575
  %r78 = and i1 %r76, %r77
  %r79 = and i1 %r78, %r74
  br i1 %r79, label %class_field_inline.deref.10, label %class_field_inline.guardcall.11

class_field_inline.deref.5:                       ; preds = %entry.0
  %r24 = inttoptr i64 %r12 to ptr
  %r25 = getelementptr i8, ptr %r24, i64 -8
  %r26 = load i8, ptr %r25, align 1
  %r27 = icmp eq i8 %r26, 2
  %r28 = getelementptr i8, ptr %r24, i64 -7
  %r29 = load i8, ptr %r28, align 1
  %r30 = and i8 %r29, -128
  %r31 = icmp eq i8 %r30, 0
  %r32 = getelementptr i8, ptr %r24, i64 -6
  %r33 = load i16, ptr %r32, align 2
  %r34 = getelementptr i8, ptr %r24, i64 0
  %r35 = load i32, ptr %r34, align 4
  %r36 = icmp eq i32 %r35, 5
  %r37 = getelementptr i8, ptr %r24, i64 4
  %r38 = load i32, ptr %r37, align 4
  %r39 = icmp eq i32 %r38, %r9
  %r40 = and i1 %r27, %r31
  %r41 = and i1 %r40, %r36
  %r42 = and i1 %r41, %r39
  %r43 = and i16 %r33, 3072
  %r44 = icmp eq i16 %r43, 0
  %r45 = and i1 %r42, %r44
  %r46 = and i16 %r33, 4096
  %r47 = icmp ne i16 %r46, 0
  %r48 = and i1 %r45, %r47
  %r49 = and i16 %r33, 1
  %r50 = icmp eq i16 %r49, 0
  %r51 = and i1 %r48, %r50
  %r52 = and i16 %r33, 128
  %r53 = icmp eq i16 %r52, 0
  %r54 = and i1 %r51, %r53
  %r55 = and i64 %r16, 9218868437227405312
  %r56 = icmp ne i64 %r55, 9218868437227405312
  %r57 = and i1 %r54, %r56
  br i1 %r57, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r58 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479957003, double %r6, i32 5, i32 %r9, i64 %r15, i32 0, double %r7, i32 1) #9
  %r59 = icmp ne i32 %r58, 0
  br i1 %r59, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.fast.7:                           ; preds = %class_field_inline.guardcall.11, %class_field_inline.deref.10
  %r287.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r287.rs4o = call i64 asm "", "=r,0"(i64 %r287.rs4i) #9
  %r287 = bitcast i64 %r287.rs4o to double
  %r288 = bitcast double %r287 to i64
  %r289 = and i64 %r288, 281474976710655
  %r110 = inttoptr i64 %r289 to ptr
  %r283.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r283.rs4o = call i64 asm "", "=r,0"(i64 %r283.rs4i) #9
  %r283 = bitcast i64 %r283.rs4o to double
  %r284 = bitcast double %r283 to i64
  %r285 = and i64 %r284, 281474976710655
  %r286 = inttoptr i64 %r285 to ptr
  %r111 = getelementptr i8, ptr %r286, i64 16
  %r112 = getelementptr double, ptr %r111, i64 1
  %r113 = ptrtoint ptr %r112 to i64
  %r282.rs4i = ptrtoint ptr addrspace(1) %.05 to i64
  %r282.rs4o = call i64 asm "", "=r,0"(i64 %r282.rs4i) #9
  %r282 = bitcast i64 %r282.rs4o to double
  store double %r282, ptr %r112, align 8
  %r281.rs4i = ptrtoint ptr addrspace(1) %.05 to i64
  %r281.rs4o = call i64 asm "", "=r,0"(i64 %r281.rs4i) #9
  %r281 = bitcast i64 %r281.rs4o to double
  %r114 = bitcast double %r281 to i64
  %r279.rs4i = ptrtoint ptr addrspace(1) %.05 to i64
  %r279.rs4o = call i64 asm "", "=r,0"(i64 %r279.rs4i) #9
  %r279 = bitcast i64 %r279.rs4o to double
  %r280 = bitcast double %r279 to i64
  %r115 = lshr i64 %r280, 48
  %r116 = icmp eq i64 %r115, 0
  %r277.rs4i = ptrtoint ptr addrspace(1) %.05 to i64
  %r277.rs4o = call i64 asm "", "=r,0"(i64 %r277.rs4i) #9
  %r277 = bitcast i64 %r277.rs4o to double
  %r278 = bitcast double %r277 to i64
  %r117 = icmp uge i64 %r278, 4096
  %r118 = and i1 %r116, %r117
  %r119 = icmp eq i64 %r115, 32765
  %r120 = icmp eq i64 %r115, 32767
  %r121 = icmp eq i64 %r115, 32762
  %r122 = or i1 %r119, %r120
  %r123 = or i1 %r122, %r121
  %r124 = or i1 %r123, %r118
  br i1 %r124, label %class_field_set.gc_bookkeeping.12, label %class_field_set.gc_bookkeeping.done.13

class_field_set.fallback.8:                       ; preds = %class_field_inline.guardcall.11
  %r271.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r271.rs4o = call i64 asm "", "=r,0"(i64 %r271.rs4i) #9
  %r271 = bitcast i64 %r271.rs4o to double
  %r272 = bitcast double %r271 to i64
  %r273.rs4i = ptrtoint ptr addrspace(1) %.05 to i64
  %r273.rs4o = call i64 asm "", "=r,0"(i64 %r273.rs4i) #9
  %r273 = bitcast i64 %r273.rs4o to double
  %r274 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.14.handle, align 8
  %r275 = bitcast double %r274 to i64
  %r276 = and i64 %r275, 281474976710655
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479957004, i64 %r272, i64 %r276, double %r273, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.06, ptr addrspace(1) %.0) ]
  %rs4gc.s4.relocated2 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 0, i32 0) ; (%.06, %.06)
  %rs4gc.s1.relocated3 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 1, i32 1) ; (%.0, %.0)
  br label %class_field_set.merge.9

class_field_set.merge.9:                          ; preds = %class_field_set.gc_bookkeeping.done.13, %class_field_set.fallback.8
  %.17 = phi ptr addrspace(1) [ %.06, %class_field_set.gc_bookkeeping.done.13 ], [ %rs4gc.s4.relocated2, %class_field_set.fallback.8 ]
  %.1 = phi ptr addrspace(1) [ %.0, %class_field_set.gc_bookkeeping.done.13 ], [ %rs4gc.s1.relocated3, %class_field_set.fallback.8 ]
  %r138.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r138.rs4o = call i64 asm "", "=r,0"(i64 %r138.rs4i) #9
  %r138 = bitcast i64 %r138.rs4o to double
  %r139.rs4i = ptrtoint ptr addrspace(1) %.17 to i64
  %r139.rs4o = call i64 asm "", "=r,0"(i64 %r139.rs4i) #9
  %r139 = bitcast i64 %r139.rs4o to double
  %r141 = bitcast double %r138 to i64
  %r142 = and i64 %r141, 281474976710655
  %r143 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.7.handle, align 8
  %r144 = bitcast double %r143 to i64
  %r145 = and i64 %r144, 281474976710655
  %r146 = bitcast double %r139 to i64
  %r147 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r148 = icmp eq i8 %r147, 0
  %r149 = lshr i64 %r141, 48
  %r150 = icmp eq i64 %r149, 32765
  %r151 = icmp ugt i64 %r142, 1048575
  %r152 = and i1 %r150, %r151
  %r153 = and i1 %r152, %r148
  br i1 %r153, label %class_field_inline.deref.20, label %class_field_inline.guardcall.21

class_field_inline.deref.10:                      ; preds = %class_field_set.merge.4
  %r80 = inttoptr i64 %r68 to ptr
  %r81 = getelementptr i8, ptr %r80, i64 -8
  %r82 = load i8, ptr %r81, align 1
  %r83 = icmp eq i8 %r82, 2
  %r84 = getelementptr i8, ptr %r80, i64 -7
  %r85 = load i8, ptr %r84, align 1
  %r86 = and i8 %r85, -128
  %r87 = icmp eq i8 %r86, 0
  %r88 = getelementptr i8, ptr %r80, i64 -6
  %r89 = load i16, ptr %r88, align 2
  %r90 = getelementptr i8, ptr %r80, i64 0
  %r91 = load i32, ptr %r90, align 4
  %r92 = icmp eq i32 %r91, 5
  %r93 = getelementptr i8, ptr %r80, i64 4
  %r94 = load i32, ptr %r93, align 4
  %r95 = icmp eq i32 %r94, %r9
  %r96 = and i1 %r83, %r87
  %r97 = and i1 %r96, %r92
  %r98 = and i1 %r97, %r95
  %r99 = and i16 %r89, 3072
  %r100 = icmp eq i16 %r99, 0
  %r101 = and i1 %r98, %r100
  %r102 = and i16 %r89, 1
  %r103 = icmp eq i16 %r102, 0
  %r104 = and i1 %r101, %r103
  %r105 = and i16 %r89, 128
  %r106 = icmp eq i16 %r105, 0
  %r107 = and i1 %r104, %r106
  br i1 %r107, label %class_field_set.fast.7, label %class_field_inline.guardcall.11

class_field_inline.guardcall.11:                  ; preds = %class_field_inline.deref.10, %class_field_set.merge.4
  %r108 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479957004, double %r64, i32 5, i32 %r9, i64 %r71, i32 1, double %r65, i32 0) #9
  %r109 = icmp ne i32 %r108, 0
  br i1 %r109, label %class_field_set.fast.7, label %class_field_set.fallback.8

class_field_set.gc_bookkeeping.12:                ; preds = %class_field_set.fast.7
  %r270.rs4i = ptrtoint ptr addrspace(1) %.05 to i64
  %r270.rs4o = call i64 asm "", "=r,0"(i64 %r270.rs4i) #9
  %r270 = bitcast i64 %r270.rs4o to double
  call void @js_string_addref_if_heap_string(double %r270) #9
  %r267.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r267.rs4o = call i64 asm "", "=r,0"(i64 %r267.rs4i) #9
  %r267 = bitcast i64 %r267.rs4o to double
  %r268 = bitcast double %r267 to i64
  %r269 = and i64 %r268, 281474976710655
  %r125 = inttoptr i64 %r269 to ptr
  %r263.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r263.rs4o = call i64 asm "", "=r,0"(i64 %r263.rs4i) #9
  %r263 = bitcast i64 %r263.rs4o to double
  %r264 = bitcast double %r263 to i64
  %r265 = and i64 %r264, 281474976710655
  %r266 = inttoptr i64 %r265 to ptr
  %r126 = getelementptr i8, ptr %r266, i64 -6
  %r127 = load i16, ptr %r126, align 2
  %r128 = and i16 %r127, -12288
  %r129 = icmp eq i16 %r128, -28672
  br i1 %r129, label %class_field_set.layout_note.done.15, label %class_field_set.layout_note.14

class_field_set.gc_bookkeeping.done.13:           ; preds = %class_field_set.barrier.16, %class_field_set.layout_note.done.15, %class_field_set.fast.7
  br label %class_field_set.merge.9

class_field_set.layout_note.14:                   ; preds = %class_field_set.gc_bookkeeping.12
  %r258.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r258.rs4o = call i64 asm "", "=r,0"(i64 %r258.rs4i) #9
  %r258 = bitcast i64 %r258.rs4o to double
  %r259 = bitcast double %r258 to i64
  %r260 = and i64 %r259, 281474976710655
  %r261.rs4i = ptrtoint ptr addrspace(1) %.05 to i64
  %r261.rs4o = call i64 asm "", "=r,0"(i64 %r261.rs4i) #9
  %r261 = bitcast i64 %r261.rs4o to double
  %r262 = bitcast double %r261 to i64
  call void @js_gc_note_slot_layout(i64 %r260, i32 1, i64 %r262) #9
  br label %class_field_set.layout_note.done.15

class_field_set.layout_note.done.15:              ; preds = %class_field_set.layout_note.14, %class_field_set.gc_bookkeeping.12
  %r255.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r255.rs4o = call i64 asm "", "=r,0"(i64 %r255.rs4i) #9
  %r255 = bitcast i64 %r255.rs4o to double
  %r256 = bitcast double %r255 to i64
  %r257 = and i64 %r256, 281474976710655
  %r130 = sub nsw i64 %r257, 7
  %r131 = inttoptr i64 %r130 to ptr
  %r132 = load i8, ptr %r131, align 1
  %r133 = and i8 %r132, 32
  %r134 = icmp ne i8 %r133, 0
  %r135 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r136 = icmp ne i32 %r135, 0
  %r137 = or i1 %r134, %r136
  br i1 %r137, label %class_field_set.barrier.16, label %class_field_set.gc_bookkeeping.done.13

class_field_set.barrier.16:                       ; preds = %class_field_set.layout_note.done.15
  %r251.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r251.rs4o = call i64 asm "", "=r,0"(i64 %r251.rs4i) #9
  %r251 = bitcast i64 %r251.rs4o to double
  %r252 = bitcast double %r251 to i64
  %r253.rs4i = ptrtoint ptr addrspace(1) %.05 to i64
  %r253.rs4o = call i64 asm "", "=r,0"(i64 %r253.rs4i) #9
  %r253 = bitcast i64 %r253.rs4o to double
  %r254 = bitcast double %r253 to i64
  call void @js_write_barrier_slot(i64 %r252, i64 %r113, i64 %r254) #9
  br label %class_field_set.gc_bookkeeping.done.13

class_field_set.fast.17:                          ; preds = %class_field_inline.guardcall.21, %class_field_inline.deref.20
  %r248.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r248.rs4o = call i64 asm "", "=r,0"(i64 %r248.rs4i) #9
  %r248 = bitcast i64 %r248.rs4o to double
  %r249 = bitcast double %r248 to i64
  %r250 = and i64 %r249, 281474976710655
  %r184 = inttoptr i64 %r250 to ptr
  %r244.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r244.rs4o = call i64 asm "", "=r,0"(i64 %r244.rs4i) #9
  %r244 = bitcast i64 %r244.rs4o to double
  %r245 = bitcast double %r244 to i64
  %r246 = and i64 %r245, 281474976710655
  %r247 = inttoptr i64 %r246 to ptr
  %r185 = getelementptr i8, ptr %r247, i64 16
  %r186 = getelementptr double, ptr %r185, i64 2
  %r187 = ptrtoint ptr %r186 to i64
  %r243.rs4i = ptrtoint ptr addrspace(1) %.17 to i64
  %r243.rs4o = call i64 asm "", "=r,0"(i64 %r243.rs4i) #9
  %r243 = bitcast i64 %r243.rs4o to double
  store double %r243, ptr %r186, align 8
  %r242.rs4i = ptrtoint ptr addrspace(1) %.17 to i64
  %r242.rs4o = call i64 asm "", "=r,0"(i64 %r242.rs4i) #9
  %r242 = bitcast i64 %r242.rs4o to double
  %r188 = bitcast double %r242 to i64
  %r240.rs4i = ptrtoint ptr addrspace(1) %.17 to i64
  %r240.rs4o = call i64 asm "", "=r,0"(i64 %r240.rs4i) #9
  %r240 = bitcast i64 %r240.rs4o to double
  %r241 = bitcast double %r240 to i64
  %r189 = lshr i64 %r241, 48
  %r190 = icmp eq i64 %r189, 0
  %r238.rs4i = ptrtoint ptr addrspace(1) %.17 to i64
  %r238.rs4o = call i64 asm "", "=r,0"(i64 %r238.rs4i) #9
  %r238 = bitcast i64 %r238.rs4o to double
  %r239 = bitcast double %r238 to i64
  %r191 = icmp uge i64 %r239, 4096
  %r192 = and i1 %r190, %r191
  %r193 = icmp eq i64 %r189, 32765
  %r194 = icmp eq i64 %r189, 32767
  %r195 = icmp eq i64 %r189, 32762
  %r196 = or i1 %r193, %r194
  %r197 = or i1 %r196, %r195
  %r198 = or i1 %r197, %r192
  br i1 %r198, label %class_field_set.gc_bookkeeping.22, label %class_field_set.gc_bookkeeping.done.23

class_field_set.fallback.18:                      ; preds = %class_field_inline.guardcall.21
  %r232.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r232.rs4o = call i64 asm "", "=r,0"(i64 %r232.rs4i) #9
  %r232 = bitcast i64 %r232.rs4o to double
  %r233 = bitcast double %r232 to i64
  %r234.rs4i = ptrtoint ptr addrspace(1) %.17 to i64
  %r234.rs4o = call i64 asm "", "=r,0"(i64 %r234.rs4i) #9
  %r234 = bitcast i64 %r234.rs4o to double
  %r235 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.7.handle, align 8
  %r236 = bitcast double %r235 to i64
  %r237 = and i64 %r236, 281474976710655
  %statepoint_token4 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479957005, i64 %r233, i64 %r237, double %r234, i32 0, i32 0)
  br label %class_field_set.merge.19

class_field_set.merge.19:                         ; preds = %class_field_set.gc_bookkeeping.done.23, %class_field_set.fallback.18
  br label %standalone.ctor.return.after.1

class_field_inline.deref.20:                      ; preds = %class_field_set.merge.9
  %r154 = inttoptr i64 %r142 to ptr
  %r155 = getelementptr i8, ptr %r154, i64 -8
  %r156 = load i8, ptr %r155, align 1
  %r157 = icmp eq i8 %r156, 2
  %r158 = getelementptr i8, ptr %r154, i64 -7
  %r159 = load i8, ptr %r158, align 1
  %r160 = and i8 %r159, -128
  %r161 = icmp eq i8 %r160, 0
  %r162 = getelementptr i8, ptr %r154, i64 -6
  %r163 = load i16, ptr %r162, align 2
  %r164 = getelementptr i8, ptr %r154, i64 0
  %r165 = load i32, ptr %r164, align 4
  %r166 = icmp eq i32 %r165, 5
  %r167 = getelementptr i8, ptr %r154, i64 4
  %r168 = load i32, ptr %r167, align 4
  %r169 = icmp eq i32 %r168, %r9
  %r170 = and i1 %r157, %r161
  %r171 = and i1 %r170, %r166
  %r172 = and i1 %r171, %r169
  %r173 = and i16 %r163, 3072
  %r174 = icmp eq i16 %r173, 0
  %r175 = and i1 %r172, %r174
  %r176 = and i16 %r163, 1
  %r177 = icmp eq i16 %r176, 0
  %r178 = and i1 %r175, %r177
  %r179 = and i16 %r163, 128
  %r180 = icmp eq i16 %r179, 0
  %r181 = and i1 %r178, %r180
  br i1 %r181, label %class_field_set.fast.17, label %class_field_inline.guardcall.21

class_field_inline.guardcall.21:                  ; preds = %class_field_inline.deref.20, %class_field_set.merge.9
  %r182 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479957005, double %r138, i32 5, i32 %r9, i64 %r145, i32 2, double %r139, i32 0) #9
  %r183 = icmp ne i32 %r182, 0
  br i1 %r183, label %class_field_set.fast.17, label %class_field_set.fallback.18

class_field_set.gc_bookkeeping.22:                ; preds = %class_field_set.fast.17
  %r231.rs4i = ptrtoint ptr addrspace(1) %.17 to i64
  %r231.rs4o = call i64 asm "", "=r,0"(i64 %r231.rs4i) #9
  %r231 = bitcast i64 %r231.rs4o to double
  call void @js_string_addref_if_heap_string(double %r231) #9
  %r228.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r228.rs4o = call i64 asm "", "=r,0"(i64 %r228.rs4i) #9
  %r228 = bitcast i64 %r228.rs4o to double
  %r229 = bitcast double %r228 to i64
  %r230 = and i64 %r229, 281474976710655
  %r199 = inttoptr i64 %r230 to ptr
  %r224.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r224.rs4o = call i64 asm "", "=r,0"(i64 %r224.rs4i) #9
  %r224 = bitcast i64 %r224.rs4o to double
  %r225 = bitcast double %r224 to i64
  %r226 = and i64 %r225, 281474976710655
  %r227 = inttoptr i64 %r226 to ptr
  %r200 = getelementptr i8, ptr %r227, i64 -6
  %r201 = load i16, ptr %r200, align 2
  %r202 = and i16 %r201, -12288
  %r203 = icmp eq i16 %r202, -28672
  br i1 %r203, label %class_field_set.layout_note.done.25, label %class_field_set.layout_note.24

class_field_set.gc_bookkeeping.done.23:           ; preds = %class_field_set.barrier.26, %class_field_set.layout_note.done.25, %class_field_set.fast.17
  br label %class_field_set.merge.19

class_field_set.layout_note.24:                   ; preds = %class_field_set.gc_bookkeeping.22
  %r219.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r219.rs4o = call i64 asm "", "=r,0"(i64 %r219.rs4i) #9
  %r219 = bitcast i64 %r219.rs4o to double
  %r220 = bitcast double %r219 to i64
  %r221 = and i64 %r220, 281474976710655
  %r222.rs4i = ptrtoint ptr addrspace(1) %.17 to i64
  %r222.rs4o = call i64 asm "", "=r,0"(i64 %r222.rs4i) #9
  %r222 = bitcast i64 %r222.rs4o to double
  %r223 = bitcast double %r222 to i64
  call void @js_gc_note_slot_layout(i64 %r221, i32 2, i64 %r223) #9
  br label %class_field_set.layout_note.done.25

class_field_set.layout_note.done.25:              ; preds = %class_field_set.layout_note.24, %class_field_set.gc_bookkeeping.22
  %r216.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r216.rs4o = call i64 asm "", "=r,0"(i64 %r216.rs4i) #9
  %r216 = bitcast i64 %r216.rs4o to double
  %r217 = bitcast double %r216 to i64
  %r218 = and i64 %r217, 281474976710655
  %r204 = sub nsw i64 %r218, 7
  %r205 = inttoptr i64 %r204 to ptr
  %r206 = load i8, ptr %r205, align 1
  %r207 = and i8 %r206, 32
  %r208 = icmp ne i8 %r207, 0
  %r209 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r210 = icmp ne i32 %r209, 0
  %r211 = or i1 %r208, %r210
  br i1 %r211, label %class_field_set.barrier.26, label %class_field_set.gc_bookkeeping.done.23

class_field_set.barrier.26:                       ; preds = %class_field_set.layout_note.done.25
  %r212.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r212.rs4o = call i64 asm "", "=r,0"(i64 %r212.rs4i) #9
  %r212 = bitcast i64 %r212.rs4o to double
  %r213 = bitcast double %r212 to i64
  %r214.rs4i = ptrtoint ptr addrspace(1) %.17 to i64
  %r214.rs4o = call i64 asm "", "=r,0"(i64 %r214.rs4i) #9
  %r214 = bitcast i64 %r214.rs4o to double
  %r215 = bitcast double %r214 to i64
  call void @js_write_barrier_slot(i64 %r213, i64 %r187, i64 %r215) #9
  br label %class_field_set.gc_bookkeeping.done.23
}

; Function Attrs: optsize
define double @test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77_constructor(double %this_arg, double %arg25) #6 gc "statepoint-example" {
entry.0:
  %r7 = load i32, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg25 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r4.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r4.rs4o = call i64 asm "", "=r,0"(i64 %r4.rs4i) #9
  %r4 = bitcast i64 %r4.rs4o to double
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #9
  %r5 = bitcast i64 %r5.rs4o to double
  %r9 = bitcast double %r4 to i64
  %r10 = and i64 %r9, 281474976710655
  %r11 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.14.handle, align 8
  %r12 = bitcast double %r11 to i64
  %r13 = and i64 %r12, 281474976710655
  %r14 = bitcast double %r5 to i64
  %r15 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r16 = icmp eq i8 %r15, 0
  %r17 = lshr i64 %r9, 48
  %r18 = icmp eq i64 %r17, 32765
  %r19 = icmp ugt i64 %r10, 1048575
  %r20 = and i1 %r18, %r19
  %r21 = and i1 %r20, %r16
  br i1 %r21, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.4
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r116.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r116.rs4o = call i64 asm "", "=r,0"(i64 %r116.rs4i) #9
  %r116 = bitcast i64 %r116.rs4o to double
  %r117 = bitcast double %r116 to i64
  %r118 = and i64 %r117, 281474976710655
  %r52 = inttoptr i64 %r118 to ptr
  %r112.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r112.rs4o = call i64 asm "", "=r,0"(i64 %r112.rs4i) #9
  %r112 = bitcast i64 %r112.rs4o to double
  %r113 = bitcast double %r112 to i64
  %r114 = and i64 %r113, 281474976710655
  %r115 = inttoptr i64 %r114 to ptr
  %r53 = getelementptr i8, ptr %r115, i64 16
  %r54 = getelementptr double, ptr %r53, i64 0
  %r55 = ptrtoint ptr %r54 to i64
  %r111.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r111.rs4o = call i64 asm "", "=r,0"(i64 %r111.rs4i) #9
  %r111 = bitcast i64 %r111.rs4o to double
  store double %r111, ptr %r54, align 8
  %r110.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r110.rs4o = call i64 asm "", "=r,0"(i64 %r110.rs4i) #9
  %r110 = bitcast i64 %r110.rs4o to double
  %r56 = bitcast double %r110 to i64
  %r108.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r108.rs4o = call i64 asm "", "=r,0"(i64 %r108.rs4i) #9
  %r108 = bitcast i64 %r108.rs4o to double
  %r109 = bitcast double %r108 to i64
  %r57 = lshr i64 %r109, 48
  %r58 = icmp eq i64 %r57, 0
  %r106.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r106.rs4o = call i64 asm "", "=r,0"(i64 %r106.rs4i) #9
  %r106 = bitcast i64 %r106.rs4o to double
  %r107 = bitcast double %r106 to i64
  %r59 = icmp uge i64 %r107, 4096
  %r60 = and i1 %r58, %r59
  %r61 = icmp eq i64 %r57, 32765
  %r62 = icmp eq i64 %r57, 32767
  %r63 = icmp eq i64 %r57, 32762
  %r64 = or i1 %r61, %r62
  %r65 = or i1 %r64, %r63
  %r66 = or i1 %r65, %r60
  br i1 %r66, label %class_field_set.gc_bookkeeping.7, label %class_field_set.gc_bookkeeping.done.8

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r100.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r100.rs4o = call i64 asm "", "=r,0"(i64 %r100.rs4i) #9
  %r100 = bitcast i64 %r100.rs4o to double
  %r101 = bitcast double %r100 to i64
  %r102.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r102.rs4o = call i64 asm "", "=r,0"(i64 %r102.rs4i) #9
  %r102 = bitcast i64 %r102.rs4o to double
  %r103 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.14.handle, align 8
  %r104 = bitcast double %r103 to i64
  %r105 = and i64 %r104, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 6947013080479957006, i64 %r101, i64 %r105, double %r102, i32 0, i32 0)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.gc_bookkeeping.done.8, %class_field_set.fallback.3
  br label %standalone.ctor.return.after.1

class_field_inline.deref.5:                       ; preds = %entry.0
  %r22 = inttoptr i64 %r10 to ptr
  %r23 = getelementptr i8, ptr %r22, i64 -8
  %r24 = load i8, ptr %r23, align 1
  %r25 = icmp eq i8 %r24, 2
  %r26 = getelementptr i8, ptr %r22, i64 -7
  %r27 = load i8, ptr %r26, align 1
  %r28 = and i8 %r27, -128
  %r29 = icmp eq i8 %r28, 0
  %r30 = getelementptr i8, ptr %r22, i64 -6
  %r31 = load i16, ptr %r30, align 2
  %r32 = getelementptr i8, ptr %r22, i64 0
  %r33 = load i32, ptr %r32, align 4
  %r34 = icmp eq i32 %r33, 6
  %r35 = getelementptr i8, ptr %r22, i64 4
  %r36 = load i32, ptr %r35, align 4
  %r37 = icmp eq i32 %r36, %r7
  %r38 = and i1 %r25, %r29
  %r39 = and i1 %r38, %r34
  %r40 = and i1 %r39, %r37
  %r41 = and i16 %r31, 3072
  %r42 = icmp eq i16 %r41, 0
  %r43 = and i1 %r40, %r42
  %r44 = and i16 %r31, 1
  %r45 = icmp eq i16 %r44, 0
  %r46 = and i1 %r43, %r45
  %r47 = and i16 %r31, 128
  %r48 = icmp eq i16 %r47, 0
  %r49 = and i1 %r46, %r48
  br i1 %r49, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r50 = call i32 @js_typed_feedback_class_field_set_guard(i64 6947013080479957006, double %r4, i32 6, i32 %r7, i64 %r13, i32 0, double %r5, i32 0) #9
  %r51 = icmp ne i32 %r50, 0
  br i1 %r51, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.gc_bookkeeping.7:                 ; preds = %class_field_set.fast.2
  %r99.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r99.rs4o = call i64 asm "", "=r,0"(i64 %r99.rs4i) #9
  %r99 = bitcast i64 %r99.rs4o to double
  call void @js_string_addref_if_heap_string(double %r99) #9
  %r96.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r96.rs4o = call i64 asm "", "=r,0"(i64 %r96.rs4i) #9
  %r96 = bitcast i64 %r96.rs4o to double
  %r97 = bitcast double %r96 to i64
  %r98 = and i64 %r97, 281474976710655
  %r67 = inttoptr i64 %r98 to ptr
  %r92.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r92.rs4o = call i64 asm "", "=r,0"(i64 %r92.rs4i) #9
  %r92 = bitcast i64 %r92.rs4o to double
  %r93 = bitcast double %r92 to i64
  %r94 = and i64 %r93, 281474976710655
  %r95 = inttoptr i64 %r94 to ptr
  %r68 = getelementptr i8, ptr %r95, i64 -6
  %r69 = load i16, ptr %r68, align 2
  %r70 = and i16 %r69, -12288
  %r71 = icmp eq i16 %r70, -28672
  br i1 %r71, label %class_field_set.layout_note.done.10, label %class_field_set.layout_note.9

class_field_set.gc_bookkeeping.done.8:            ; preds = %class_field_set.barrier.11, %class_field_set.layout_note.done.10, %class_field_set.fast.2
  br label %class_field_set.merge.4

class_field_set.layout_note.9:                    ; preds = %class_field_set.gc_bookkeeping.7
  %r87.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r87.rs4o = call i64 asm "", "=r,0"(i64 %r87.rs4i) #9
  %r87 = bitcast i64 %r87.rs4o to double
  %r88 = bitcast double %r87 to i64
  %r89 = and i64 %r88, 281474976710655
  %r90.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r90.rs4o = call i64 asm "", "=r,0"(i64 %r90.rs4i) #9
  %r90 = bitcast i64 %r90.rs4o to double
  %r91 = bitcast double %r90 to i64
  call void @js_gc_note_slot_layout(i64 %r89, i32 0, i64 %r91) #9
  br label %class_field_set.layout_note.done.10

class_field_set.layout_note.done.10:              ; preds = %class_field_set.layout_note.9, %class_field_set.gc_bookkeeping.7
  %r84.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r84.rs4o = call i64 asm "", "=r,0"(i64 %r84.rs4i) #9
  %r84 = bitcast i64 %r84.rs4o to double
  %r85 = bitcast double %r84 to i64
  %r86 = and i64 %r85, 281474976710655
  %r72 = sub nsw i64 %r86, 7
  %r73 = inttoptr i64 %r72 to ptr
  %r74 = load i8, ptr %r73, align 1
  %r75 = and i8 %r74, 32
  %r76 = icmp ne i8 %r75, 0
  %r77 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r78 = icmp ne i32 %r77, 0
  %r79 = or i1 %r76, %r78
  br i1 %r79, label %class_field_set.barrier.11, label %class_field_set.gc_bookkeeping.done.8

class_field_set.barrier.11:                       ; preds = %class_field_set.layout_note.done.10
  %r80.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r80.rs4o = call i64 asm "", "=r,0"(i64 %r80.rs4i) #9
  %r80 = bitcast i64 %r80.rs4o to double
  %r81 = bitcast double %r80 to i64
  %r82.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r82.rs4o = call i64 asm "", "=r,0"(i64 %r82.rs4i) #9
  %r82 = bitcast i64 %r82.rs4o to double
  %r83 = bitcast double %r82 to i64
  call void @js_write_barrier_slot(i64 %r81, i64 %r55, i64 %r83) #9
  br label %class_field_set.gc_bookkeeping.done.8
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__identity(i64 %this_closure, double %a0, double %a1) #6 {
entry.0:
  %r1 = call double @perry_fn_test_json_primitive_tojson_keys_ts__identity(double %a0, double %a1)
  ret double %r1
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__makeHook(i64 %this_closure, double %a0) #6 {
entry.0:
  %r1 = call double @perry_fn_test_json_primitive_tojson_keys_ts__makeHook(double %a0)
  ret double %r1
}

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_test_json_primitive_tojson_keys_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @test_json_primitive_tojson_keys_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" {
entry.0:
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @test_json_primitive_tojson_keys_ts_.str.0, i32 93, i32 0, i32 0)
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token3 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token4 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_test_json_primitive_tojson_keys_ts, i32 0, i32 0, i32 0, i32 0)
  %r25 = load i64, ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599, align 8
  %rs4gc.s2 = inttoptr i64 %r25 to ptr addrspace(1)
  %r28 = load i32, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599, align 4
  %r152 = load i64, ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b, align 8
  %rs4gc.s3 = inttoptr i64 %r152 to ptr addrspace(1)
  %r155 = load i32, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b, align 4
  %r581 = load i64, ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b, align 8
  %rs4gc.s4 = inttoptr i64 %r581 to ptr addrspace(1)
  %r584 = load i32, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b, align 4
  %r849 = load i64, ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77, align 8
  %rs4gc.s5 = inttoptr i64 %r849 to ptr addrspace(1)
  %r852 = load i32, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77, align 4
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_test_json_primitive_tojson_keys_ts__0 to i64)) #9
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_test_json_primitive_tojson_keys_ts__2 to i64)) #9
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5, ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s2) ]
  %r3100 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token5)
  %rs4gc.s5.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 0, i32 0) ; (%rs4gc.s5, %rs4gc.s5)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 1, i32 1) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 2, i32 2) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 3, i32 3) ; (%rs4gc.s2, %rs4gc.s2)
  %r4 = or i64 %r3100, 9222527611924643840
  %r5 = bitcast i64 %r4 to double
  store double %r5, ptr @perry_global_test_json_primitive_tojson_keys_ts__0, align 8
  call void @js_write_barrier_root_nanbox(i64 %r4) #9
  %r7 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.15.handle, align 8
  %r8 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.9.handle, align 8
  %statepoint_token101 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @perry_fn_test_json_primitive_tojson_keys_ts__makeHook, i32 1, i32 0, double %r8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated, ptr addrspace(1) %rs4gc.s4.relocated, ptr addrspace(1) %rs4gc.s3.relocated, ptr addrspace(1) %rs4gc.s2.relocated) ]
  %r9102 = call double @llvm.experimental.gc.result.f64(token %statepoint_token101)
  %rs4gc.s5.relocated103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token101, i32 0, i32 0) ; (%rs4gc.s5.relocated, %rs4gc.s5.relocated)
  %rs4gc.s4.relocated104 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token101, i32 1, i32 1) ; (%rs4gc.s4.relocated, %rs4gc.s4.relocated)
  %rs4gc.s3.relocated105 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token101, i32 2, i32 2) ; (%rs4gc.s3.relocated, %rs4gc.s3.relocated)
  %rs4gc.s2.relocated106 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token101, i32 3, i32 3) ; (%rs4gc.s2.relocated, %rs4gc.s2.relocated)
  %r10 = bitcast double %r9102 to i64
  %rs4gc.s6 = inttoptr i64 %r10 to ptr addrspace(1)
  %r12.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r12 = call i64 asm "", "=r,0"(i64 %r12.rs4i) #9
  %r13 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r14 = icmp ne i32 %r13, 0
  br i1 %r14, label %shadow.root.barrier.1, label %shadow.root.barrier.done.2

shadow.root.barrier.1:                            ; preds = %entry.0
  call void @js_write_barrier_root_nanbox(i64 %r12) #9
  br label %shadow.root.barrier.done.2

shadow.root.barrier.done.2:                       ; preds = %shadow.root.barrier.1, %entry.0
  %r17 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.11.handle, align 8
  %statepoint_token107 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @perry_fn_test_json_primitive_tojson_keys_ts__makeHook, i32 1, i32 0, double %r17, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated103, ptr addrspace(1) %rs4gc.s4.relocated104, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s3.relocated105, ptr addrspace(1) %rs4gc.s2.relocated106) ]
  %r18108 = call double @llvm.experimental.gc.result.f64(token %statepoint_token107)
  %rs4gc.s5.relocated109 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token107, i32 0, i32 0) ; (%rs4gc.s5.relocated103, %rs4gc.s5.relocated103)
  %rs4gc.s4.relocated110 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token107, i32 1, i32 1) ; (%rs4gc.s4.relocated104, %rs4gc.s4.relocated104)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token107, i32 2, i32 2) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s3.relocated111 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token107, i32 3, i32 3) ; (%rs4gc.s3.relocated105, %rs4gc.s3.relocated105)
  %rs4gc.s2.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token107, i32 4, i32 4) ; (%rs4gc.s2.relocated106, %rs4gc.s2.relocated106)
  %r19 = bitcast double %r18108 to i64
  %rs4gc.s7 = inttoptr i64 %r19 to ptr addrspace(1)
  %r21.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r21 = call i64 asm "", "=r,0"(i64 %r21.rs4i) #9
  %r22 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r23 = icmp ne i32 %r22, 0
  br i1 %r23, label %shadow.root.barrier.3, label %shadow.root.barrier.done.4

shadow.root.barrier.3:                            ; preds = %shadow.root.barrier.done.2
  call void @js_write_barrier_root_nanbox(i64 %r21) #9
  br label %shadow.root.barrier.done.4

shadow.root.barrier.done.4:                       ; preds = %shadow.root.barrier.3, %shadow.root.barrier.done.2
  %r26.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2.relocated112 to i64
  %r26 = call i64 asm "", "=r,0"(i64 %r26.rs4i) #9
  %statepoint_token113 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 2, i32 0, i32 2, i64 %r26, i32 %r28, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated109, ptr addrspace(1) %rs4gc.s4.relocated110, ptr addrspace(1) %rs4gc.s6.relocated, ptr addrspace(1) %rs4gc.s3.relocated111, ptr addrspace(1) %rs4gc.s7) ]
  %r30114 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token113)
  %rs4gc.s5.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 0, i32 0) ; (%rs4gc.s5.relocated109, %rs4gc.s5.relocated109)
  %rs4gc.s4.relocated116 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 1, i32 1) ; (%rs4gc.s4.relocated110, %rs4gc.s4.relocated110)
  %rs4gc.s6.relocated117 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 2, i32 2) ; (%rs4gc.s6.relocated, %rs4gc.s6.relocated)
  %rs4gc.s3.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 3, i32 3) ; (%rs4gc.s3.relocated111, %rs4gc.s3.relocated111)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 4, i32 4) ; (%rs4gc.s7, %rs4gc.s7)
  call void @js_gc_declare_typed_shape_layout(i64 %r30114, i32 2, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599, i32 1) #9
  %rs4gc.s8 = inttoptr i64 %r30114 to ptr addrspace(1)
  %r32.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r32 = call i64 asm "", "=r,0"(i64 %r32.rs4i) #9
  %r33 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r34 = icmp ne i32 %r33, 0
  br i1 %r34, label %shadow.root.barrier.5, label %shadow.root.barrier.done.6

shadow.root.barrier.5:                            ; preds = %shadow.root.barrier.done.4
  call void @js_write_barrier_root_nanbox(i64 %r32) #9
  br label %shadow.root.barrier.done.6

shadow.root.barrier.done.6:                       ; preds = %shadow.root.barrier.5, %shadow.root.barrier.done.4
  %r35 = or i64 %r30114, 9222527611924643840
  %r36 = bitcast i64 %r35 to double
  %r37.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7.relocated to i64
  %r37 = call i64 asm "", "=r,0"(i64 %r37.rs4i) #9
  %r38 = bitcast i64 %r37 to double
  %r39 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r40 = icmp eq i8 %r39, 0
  %r41 = inttoptr i64 %r30114 to ptr
  %r42 = getelementptr i8, ptr %r41, i64 -6
  %r43 = load i16, ptr %r42, align 2
  %r44 = and i16 %r43, 4096
  %r45 = icmp ne i16 %r44, 0
  %r46 = and i1 %r40, %r45
  br i1 %r46, label %ctor_prologue.fast.7, label %ctor_prologue.slow.8

ctor_prologue.fast.7:                             ; preds = %shadow.root.barrier.done.6
  %r47 = inttoptr i64 %r30114 to ptr
  %r48 = getelementptr i8, ptr %r47, i64 16
  %r49 = bitcast double %r36 to i64
  %r50 = getelementptr double, ptr %r48, i64 0
  store double 0x7FFC000000000002, ptr %r50, align 8
  %r51 = ptrtoint ptr %r50 to i64
  br label %ctor_prologue.barrier.done.12

ctor_prologue.slow.8:                             ; preds = %shadow.root.barrier.done.6
  %statepoint_token119 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double)) @test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599_constructor, i32 3, i32 0, double %r36, double 0x7FFC000000000002, double %r38, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated115, ptr addrspace(1) %rs4gc.s4.relocated116, ptr addrspace(1) %rs4gc.s6.relocated117, ptr addrspace(1) %rs4gc.s3.relocated118, ptr addrspace(1) %rs4gc.s8) ]
  %r92120 = call double @llvm.experimental.gc.result.f64(token %statepoint_token119)
  %rs4gc.s5.relocated121 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 0, i32 0) ; (%rs4gc.s5.relocated115, %rs4gc.s5.relocated115)
  %rs4gc.s4.relocated122 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 1, i32 1) ; (%rs4gc.s4.relocated116, %rs4gc.s4.relocated116)
  %rs4gc.s6.relocated123 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 2, i32 2) ; (%rs4gc.s6.relocated117, %rs4gc.s6.relocated117)
  %rs4gc.s3.relocated124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 3, i32 3) ; (%rs4gc.s3.relocated118, %rs4gc.s3.relocated118)
  %rs4gc.s8.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 4, i32 4) ; (%rs4gc.s8, %rs4gc.s8)
  br label %ctor_prologue.merge.9

ctor_prologue.merge.9:                            ; preds = %ctor_prologue.barrier.done.15, %ctor_prologue.slow.8
  %.0430 = phi ptr addrspace(1) [ %rs4gc.s8, %ctor_prologue.barrier.done.15 ], [ %rs4gc.s8.relocated, %ctor_prologue.slow.8 ]
  %.0426 = phi ptr addrspace(1) [ %rs4gc.s6.relocated117, %ctor_prologue.barrier.done.15 ], [ %rs4gc.s6.relocated123, %ctor_prologue.slow.8 ]
  %.0422 = phi ptr addrspace(1) [ %rs4gc.s3.relocated118, %ctor_prologue.barrier.done.15 ], [ %rs4gc.s3.relocated124, %ctor_prologue.slow.8 ]
  %.0414 = phi ptr addrspace(1) [ %rs4gc.s4.relocated116, %ctor_prologue.barrier.done.15 ], [ %rs4gc.s4.relocated122, %ctor_prologue.slow.8 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s5.relocated115, %ctor_prologue.barrier.done.15 ], [ %rs4gc.s5.relocated121, %ctor_prologue.slow.8 ]
  %r93 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.15 ], [ %r92120, %ctor_prologue.slow.8 ]
  %r94.rs4i = ptrtoint ptr addrspace(1) %.0430 to i64
  %r94 = call i64 asm "", "=r,0"(i64 %r94.rs4i) #9
  %r95 = or i64 %r94, 9222527611924643840
  %r96 = bitcast i64 %r95 to double
  %r97 = bitcast double %r93 to i64
  %r98 = icmp eq i64 %r97, 9222246136947933185
  br i1 %r98, label %ctor_ret.merge.17, label %ctor_ret.override.16

ctor_prologue.barrier.done.12:                    ; preds = %ctor_prologue.fast.7
  %r71 = getelementptr double, ptr %r48, i64 1
  store double %r38, ptr %r71, align 8
  %r72 = ptrtoint ptr %r71 to i64
  %r73 = bitcast double %r38 to i64
  %r74 = lshr i64 %r73, 48
  %r75 = icmp eq i64 %r74, 0
  %r76 = icmp uge i64 %r73, 4096
  %r77 = and i1 %r75, %r76
  %r78 = icmp eq i64 %r74, 32765
  %r79 = icmp eq i64 %r74, 32767
  %r80 = icmp eq i64 %r74, 32762
  %r81 = or i1 %r78, %r79
  %r82 = or i1 %r81, %r80
  %r83 = or i1 %r82, %r77
  br i1 %r83, label %ctor_prologue.barrier.maybe.13, label %ctor_prologue.barrier.done.15

ctor_prologue.barrier.maybe.13:                   ; preds = %ctor_prologue.barrier.done.12
  %r84 = sub i64 %r30114, 7
  %r85 = inttoptr i64 %r84 to ptr
  %r86 = load i8, ptr %r85, align 1
  %r87 = and i8 %r86, 32
  %r88 = icmp ne i8 %r87, 0
  %r89 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r90 = icmp ne i32 %r89, 0
  %r91 = or i1 %r88, %r90
  br i1 %r91, label %ctor_prologue.barrier.14, label %ctor_prologue.barrier.done.15

ctor_prologue.barrier.14:                         ; preds = %ctor_prologue.barrier.maybe.13
  call void @js_write_barrier_slot_validated_parent(i64 %r30114, i64 %r72, i64 %r73) #9
  br label %ctor_prologue.barrier.done.15

ctor_prologue.barrier.done.15:                    ; preds = %ctor_prologue.barrier.14, %ctor_prologue.barrier.maybe.13, %ctor_prologue.barrier.done.12
  br label %ctor_prologue.merge.9

ctor_ret.override.16:                             ; preds = %ctor_prologue.merge.9
  %statepoint_token125 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r96, double %r93, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0, ptr addrspace(1) %.0414, ptr addrspace(1) %.0426, ptr addrspace(1) %.0422) ]
  %r99126 = call double @llvm.experimental.gc.result.f64(token %statepoint_token125)
  %rs4gc.s5.relocated127 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 0, i32 0) ; (%.0, %.0)
  %rs4gc.s4.relocated128 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 1, i32 1) ; (%.0414, %.0414)
  %rs4gc.s6.relocated129 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 2, i32 2) ; (%.0426, %.0426)
  %rs4gc.s3.relocated130 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 3, i32 3) ; (%.0422, %.0422)
  br label %ctor_ret.merge.17

ctor_ret.merge.17:                                ; preds = %ctor_ret.override.16, %ctor_prologue.merge.9
  %.1427 = phi ptr addrspace(1) [ %.0426, %ctor_prologue.merge.9 ], [ %rs4gc.s6.relocated129, %ctor_ret.override.16 ]
  %.1423 = phi ptr addrspace(1) [ %.0422, %ctor_prologue.merge.9 ], [ %rs4gc.s3.relocated130, %ctor_ret.override.16 ]
  %.1415 = phi ptr addrspace(1) [ %.0414, %ctor_prologue.merge.9 ], [ %rs4gc.s4.relocated128, %ctor_ret.override.16 ]
  %.1 = phi ptr addrspace(1) [ %.0, %ctor_prologue.merge.9 ], [ %rs4gc.s5.relocated127, %ctor_ret.override.16 ]
  %r100 = phi double [ %r96, %ctor_prologue.merge.9 ], [ %r99126, %ctor_ret.override.16 ]
  %r101 = bitcast double %r100 to i64
  %rs4gc.s9 = inttoptr i64 %r101 to ptr addrspace(1)
  %r102.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r102 = call i64 asm "", "=r,0"(i64 %r102.rs4i) #9
  %r103 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r104 = icmp ne i32 %r103, 0
  br i1 %r104, label %shadow.root.barrier.18, label %shadow.root.barrier.done.19

shadow.root.barrier.18:                           ; preds = %ctor_ret.merge.17
  call void @js_write_barrier_root_nanbox(i64 %r102) #9
  br label %shadow.root.barrier.done.19

shadow.root.barrier.done.19:                      ; preds = %shadow.root.barrier.18, %ctor_ret.merge.17
  %r105 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.16.handle, align 8
  %r106 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.17.handle, align 8
  %statepoint_token131 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @perry_fn_test_json_primitive_tojson_keys_ts__makeHook, i32 1, i32 0, double %r106, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1, ptr addrspace(1) %.1415, ptr addrspace(1) %rs4gc.s9, ptr addrspace(1) %.1427, ptr addrspace(1) %.1423) ]
  %r107132 = call double @llvm.experimental.gc.result.f64(token %statepoint_token131)
  %rs4gc.s5.relocated133 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token131, i32 0, i32 0) ; (%.1, %.1)
  %rs4gc.s4.relocated134 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token131, i32 1, i32 1) ; (%.1415, %.1415)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token131, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  %rs4gc.s6.relocated135 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token131, i32 3, i32 3) ; (%.1427, %.1427)
  %rs4gc.s3.relocated136 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token131, i32 4, i32 4) ; (%.1423, %.1423)
  %r108 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.16.handle, align 8
  br label %arena_state.init.20

arena_state.init.20:                              ; preds = %shadow.root.barrier.done.19
  %r112 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r113 = icmp ne i64 %r112, -1
  br i1 %r113, label %arena_state.hot_tls.tsd.22, label %arena_state.hot_tls.slow.24

arena_state.ready.21:                             ; preds = %arena_state.hot_tls.resolved.26
  %r128 = getelementptr i8, ptr %r126, i64 8
  %r129 = load i64, ptr %r128, align 8
  %r130 = add i64 %r129, 40
  %r131 = getelementptr i8, ptr %r126, i64 16
  %r132 = load i64, ptr %r131, align 8
  %r133 = icmp ule i64 %r130, %r132
  br i1 %r133, label %arrlit.fast.27, label %arrlit.slow.28

arena_state.hot_tls.tsd.22:                       ; preds = %arena_state.init.20
  %r114 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #9
  %r115 = and i64 %r114, -8
  %r116 = shl i64 %r112, 3
  %r117 = add i64 %r115, %r116
  %r118 = inttoptr i64 %r117 to ptr
  %r119 = load ptr, ptr %r118, align 8
  %r120 = icmp ne ptr %r119, null
  br i1 %r120, label %arena_state.hot_tls.fast.23, label %arena_state.hot_tls.slow.24

arena_state.hot_tls.fast.23:                      ; preds = %arena_state.hot_tls.tsd.22
  %r121 = getelementptr i8, ptr %r119, i64 8
  %r122 = load ptr, ptr %r121, align 8
  %r123 = load ptr, ptr %r122, align 8
  %r124 = icmp ne ptr %r123, null
  br i1 %r124, label %arena_state.hot_tls.ready.25, label %arena_state.hot_tls.slow.24

arena_state.hot_tls.slow.24:                      ; preds = %arena_state.hot_tls.fast.23, %arena_state.hot_tls.tsd.22, %arena_state.init.20
  %statepoint_token137 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated133, ptr addrspace(1) %rs4gc.s4.relocated134, ptr addrspace(1) %rs4gc.s9.relocated, ptr addrspace(1) %rs4gc.s6.relocated135, ptr addrspace(1) %rs4gc.s3.relocated136) ]
  %r125138 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token137)
  %rs4gc.s5.relocated139 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token137, i32 0, i32 0) ; (%rs4gc.s5.relocated133, %rs4gc.s5.relocated133)
  %rs4gc.s4.relocated140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token137, i32 1, i32 1) ; (%rs4gc.s4.relocated134, %rs4gc.s4.relocated134)
  %rs4gc.s9.relocated141 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token137, i32 2, i32 2) ; (%rs4gc.s9.relocated, %rs4gc.s9.relocated)
  %rs4gc.s6.relocated142 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token137, i32 3, i32 3) ; (%rs4gc.s6.relocated135, %rs4gc.s6.relocated135)
  %rs4gc.s3.relocated143 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token137, i32 4, i32 4) ; (%rs4gc.s3.relocated136, %rs4gc.s3.relocated136)
  br label %arena_state.hot_tls.resolved.26

arena_state.hot_tls.ready.25:                     ; preds = %arena_state.hot_tls.fast.23
  br label %arena_state.hot_tls.resolved.26

arena_state.hot_tls.resolved.26:                  ; preds = %arena_state.hot_tls.ready.25, %arena_state.hot_tls.slow.24
  %.0431 = phi ptr addrspace(1) [ %rs4gc.s9.relocated, %arena_state.hot_tls.ready.25 ], [ %rs4gc.s9.relocated141, %arena_state.hot_tls.slow.24 ]
  %.2428 = phi ptr addrspace(1) [ %rs4gc.s6.relocated135, %arena_state.hot_tls.ready.25 ], [ %rs4gc.s6.relocated142, %arena_state.hot_tls.slow.24 ]
  %.2424 = phi ptr addrspace(1) [ %rs4gc.s3.relocated136, %arena_state.hot_tls.ready.25 ], [ %rs4gc.s3.relocated143, %arena_state.hot_tls.slow.24 ]
  %.2416 = phi ptr addrspace(1) [ %rs4gc.s4.relocated134, %arena_state.hot_tls.ready.25 ], [ %rs4gc.s4.relocated140, %arena_state.hot_tls.slow.24 ]
  %.2 = phi ptr addrspace(1) [ %rs4gc.s5.relocated133, %arena_state.hot_tls.ready.25 ], [ %rs4gc.s5.relocated139, %arena_state.hot_tls.slow.24 ]
  %r126 = phi ptr [ %r122, %arena_state.hot_tls.ready.25 ], [ %r125138, %arena_state.hot_tls.slow.24 ]
  br label %arena_state.ready.21

arrlit.fast.27:                                   ; preds = %arena_state.ready.21
  store i64 %r130, ptr %r128, align 8
  %r134 = load ptr, ptr %r126, align 8
  %r135 = getelementptr i8, ptr %r134, i64 %r129
  br label %arrlit.merge.29

arrlit.slow.28:                                   ; preds = %arena_state.ready.21
  %statepoint_token144 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r126, i64 40, i64 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2, ptr addrspace(1) %.2416, ptr addrspace(1) %.0431, ptr addrspace(1) %.2428, ptr addrspace(1) %.2424) ]
  %r136145 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token144)
  %rs4gc.s5.relocated146 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token144, i32 0, i32 0) ; (%.2, %.2)
  %rs4gc.s4.relocated147 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token144, i32 1, i32 1) ; (%.2416, %.2416)
  %rs4gc.s9.relocated148 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token144, i32 2, i32 2) ; (%.0431, %.0431)
  %rs4gc.s6.relocated149 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token144, i32 3, i32 3) ; (%.2428, %.2428)
  %rs4gc.s3.relocated150 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token144, i32 4, i32 4) ; (%.2424, %.2424)
  br label %arrlit.merge.29

arrlit.merge.29:                                  ; preds = %arrlit.slow.28, %arrlit.fast.27
  %.1432 = phi ptr addrspace(1) [ %.0431, %arrlit.fast.27 ], [ %rs4gc.s9.relocated148, %arrlit.slow.28 ]
  %.3429 = phi ptr addrspace(1) [ %.2428, %arrlit.fast.27 ], [ %rs4gc.s6.relocated149, %arrlit.slow.28 ]
  %.3425 = phi ptr addrspace(1) [ %.2424, %arrlit.fast.27 ], [ %rs4gc.s3.relocated150, %arrlit.slow.28 ]
  %.3417 = phi ptr addrspace(1) [ %.2416, %arrlit.fast.27 ], [ %rs4gc.s4.relocated147, %arrlit.slow.28 ]
  %.3 = phi ptr addrspace(1) [ %.2, %arrlit.fast.27 ], [ %rs4gc.s5.relocated146, %arrlit.slow.28 ]
  %r137 = phi ptr [ %r135, %arrlit.fast.27 ], [ %r136145, %arrlit.slow.28 ]
  store i64 172872434177, ptr %r137, align 8
  %r138 = getelementptr i8, ptr %r137, i64 8
  store i64 12884901891, ptr %r138, align 8
  %r139 = getelementptr i8, ptr %r137, i64 8
  %r140 = ptrtoint ptr %r139 to i64
  %r141 = getelementptr inbounds nuw i8, ptr %r137, i64 16
  store double 1.000000e+00, ptr %r141, align 8
  %r142 = getelementptr inbounds nuw i8, ptr %r137, i64 24
  %r965 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.16.handle, align 8
  store double %r965, ptr %r142, align 8
  %r964 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.16.handle, align 8
  call void @js_string_addref_if_heap_string(double %r964) #9
  %r963 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.16.handle, align 8
  %r143 = bitcast double %r963 to i64
  %r961 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.16.handle, align 8
  %r962 = bitcast double %r961 to i64
  call void @js_gc_note_slot_layout(i64 %r140, i32 1, i64 %r962) #9
  %r144 = getelementptr inbounds nuw i8, ptr %r137, i64 32
  store double %r107132, ptr %r144, align 8
  call void @js_string_addref_if_heap_string(double %r107132) #9
  %r145 = bitcast double %r107132 to i64
  call void @js_gc_note_slot_layout(i64 %r140, i32 2, i64 %r145) #9
  %r146 = or i64 %r140, 9222527611924643840
  %r147 = bitcast i64 %r146 to double
  %rs4gc.s10 = inttoptr i64 %r146 to ptr addrspace(1)
  %r148.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r148 = call i64 asm "", "=r,0"(i64 %r148.rs4i) #9
  %r149 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r150 = icmp ne i32 %r149, 0
  br i1 %r150, label %shadow.root.barrier.30, label %shadow.root.barrier.done.31

shadow.root.barrier.30:                           ; preds = %arrlit.merge.29
  call void @js_write_barrier_root_nanbox(i64 %r148) #9
  br label %shadow.root.barrier.done.31

shadow.root.barrier.done.31:                      ; preds = %shadow.root.barrier.30, %arrlit.merge.29
  %r153.rs4i = ptrtoint ptr addrspace(1) %.3425 to i64
  %r153 = call i64 asm "", "=r,0"(i64 %r153.rs4i) #9
  %statepoint_token151 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 3, i32 0, i32 6, i64 %r153, i32 %r155, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3, ptr addrspace(1) %.3417, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %.1432, ptr addrspace(1) %.3429) ]
  %r157152 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token151)
  %rs4gc.s5.relocated153 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 0, i32 0) ; (%.3, %.3)
  %rs4gc.s4.relocated154 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 1, i32 1) ; (%.3417, %.3417)
  %rs4gc.s10.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 2, i32 2) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s9.relocated155 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 3, i32 3) ; (%.1432, %.1432)
  %rs4gc.s6.relocated156 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token151, i32 4, i32 4) ; (%.3429, %.3429)
  call void @js_gc_declare_typed_shape_layout(i64 %r157152, i32 6, ptr @perry_typed_shape_raw_f64_mask_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b, i32 1, ptr @perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b, i32 1) #9
  %rs4gc.s11 = inttoptr i64 %r157152 to ptr addrspace(1)
  %r159.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11 to i64
  %r159 = call i64 asm "", "=r,0"(i64 %r159.rs4i) #9
  %r160 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r161 = icmp ne i32 %r160, 0
  br i1 %r161, label %shadow.root.barrier.32, label %shadow.root.barrier.done.33

shadow.root.barrier.32:                           ; preds = %shadow.root.barrier.done.31
  call void @js_write_barrier_root_nanbox(i64 %r159) #9
  br label %shadow.root.barrier.done.33

shadow.root.barrier.done.33:                      ; preds = %shadow.root.barrier.32, %shadow.root.barrier.done.31
  %r162 = or i64 %r157152, 9222527611924643840
  %r163 = bitcast i64 %r162 to double
  %r164 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.15.handle, align 8
  %r165.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6.relocated156 to i64
  %r165 = call i64 asm "", "=r,0"(i64 %r165.rs4i) #9
  %r166 = bitcast i64 %r165 to double
  %r167.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9.relocated155 to i64
  %r167 = call i64 asm "", "=r,0"(i64 %r167.rs4i) #9
  %r168 = bitcast i64 %r167 to double
  %r169.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10.relocated to i64
  %r169 = call i64 asm "", "=r,0"(i64 %r169.rs4i) #9
  %r170 = bitcast i64 %r169 to double
  %r171 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r172 = icmp eq i8 %r171, 0
  %r173 = inttoptr i64 %r157152 to ptr
  %r174 = getelementptr i8, ptr %r173, i64 -6
  %r175 = load i16, ptr %r174, align 2
  %r176 = and i16 %r175, 4096
  %r177 = icmp ne i16 %r176, 0
  %r178 = and i1 %r172, %r177
  br i1 %r178, label %ctor_prologue.fast.34, label %ctor_prologue.slow.35

ctor_prologue.fast.34:                            ; preds = %shadow.root.barrier.done.33
  %r183 = inttoptr i64 %r157152 to ptr
  %r184 = getelementptr i8, ptr %r183, i64 16
  %r185 = bitcast double %r163 to i64
  %r186 = getelementptr double, ptr %r184, i64 0
  store double 1.000000e+00, ptr %r186, align 8
  %r187 = ptrtoint ptr %r186 to i64
  %r189 = getelementptr double, ptr %r184, i64 1
  store double %r164, ptr %r189, align 8
  %r190 = ptrtoint ptr %r189 to i64
  %r191 = bitcast double %r164 to i64
  %r192 = lshr i64 %r191, 48
  %r193 = icmp eq i64 %r192, 0
  %r194 = icmp uge i64 %r191, 4096
  %r195 = and i1 %r193, %r194
  %r196 = icmp eq i64 %r192, 32765
  %r197 = icmp eq i64 %r192, 32767
  %r198 = icmp eq i64 %r192, 32762
  %r199 = or i1 %r196, %r197
  %r200 = or i1 %r199, %r198
  %r201 = or i1 %r200, %r195
  br i1 %r201, label %ctor_prologue.barrier.maybe.37, label %ctor_prologue.barrier.done.39

ctor_prologue.slow.35:                            ; preds = %shadow.root.barrier.done.33
  %statepoint_token157 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double, double, double, double, double)) @test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b_constructor, i32 7, i32 0, double %r163, double 1.000000e+00, double %r164, double %r166, double 0x7FFC000000000004, double %r168, double %r170, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated153, ptr addrspace(1) %rs4gc.s4.relocated154, ptr addrspace(1) %rs4gc.s11) ]
  %r294158 = call double @llvm.experimental.gc.result.f64(token %statepoint_token157)
  %rs4gc.s5.relocated159 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token157, i32 0, i32 0) ; (%rs4gc.s5.relocated153, %rs4gc.s5.relocated153)
  %rs4gc.s4.relocated160 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token157, i32 1, i32 1) ; (%rs4gc.s4.relocated154, %rs4gc.s4.relocated154)
  %rs4gc.s11.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token157, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %ctor_prologue.merge.36

ctor_prologue.merge.36:                           ; preds = %ctor_prologue.barrier.done.51, %ctor_prologue.slow.35
  %.0433 = phi ptr addrspace(1) [ %rs4gc.s11, %ctor_prologue.barrier.done.51 ], [ %rs4gc.s11.relocated, %ctor_prologue.slow.35 ]
  %.4418 = phi ptr addrspace(1) [ %rs4gc.s4.relocated154, %ctor_prologue.barrier.done.51 ], [ %rs4gc.s4.relocated160, %ctor_prologue.slow.35 ]
  %.4 = phi ptr addrspace(1) [ %rs4gc.s5.relocated153, %ctor_prologue.barrier.done.51 ], [ %rs4gc.s5.relocated159, %ctor_prologue.slow.35 ]
  %r295 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.51 ], [ %r294158, %ctor_prologue.slow.35 ]
  %r296.rs4i = ptrtoint ptr addrspace(1) %.0433 to i64
  %r296 = call i64 asm "", "=r,0"(i64 %r296.rs4i) #9
  %r297 = or i64 %r296, 9222527611924643840
  %r298 = bitcast i64 %r297 to double
  %r299 = bitcast double %r295 to i64
  %r300 = icmp eq i64 %r299, 9222246136947933185
  br i1 %r300, label %ctor_ret.merge.53, label %ctor_ret.override.52

ctor_prologue.barrier.maybe.37:                   ; preds = %ctor_prologue.fast.34
  %r202 = sub i64 %r157152, 7
  %r203 = inttoptr i64 %r202 to ptr
  %r204 = load i8, ptr %r203, align 1
  %r205 = and i8 %r204, 32
  %r206 = icmp ne i8 %r205, 0
  %r207 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r208 = icmp ne i32 %r207, 0
  %r209 = or i1 %r206, %r208
  br i1 %r209, label %ctor_prologue.barrier.38, label %ctor_prologue.barrier.done.39

ctor_prologue.barrier.38:                         ; preds = %ctor_prologue.barrier.maybe.37
  call void @js_write_barrier_slot_validated_parent(i64 %r157152, i64 %r190, i64 %r191) #9
  br label %ctor_prologue.barrier.done.39

ctor_prologue.barrier.done.39:                    ; preds = %ctor_prologue.barrier.38, %ctor_prologue.barrier.maybe.37, %ctor_prologue.fast.34
  %r210 = getelementptr double, ptr %r184, i64 2
  store double %r166, ptr %r210, align 8
  %r211 = ptrtoint ptr %r210 to i64
  %r212 = bitcast double %r166 to i64
  %r213 = lshr i64 %r212, 48
  %r214 = icmp eq i64 %r213, 0
  %r215 = icmp uge i64 %r212, 4096
  %r216 = and i1 %r214, %r215
  %r217 = icmp eq i64 %r213, 32765
  %r218 = icmp eq i64 %r213, 32767
  %r219 = icmp eq i64 %r213, 32762
  %r220 = or i1 %r217, %r218
  %r221 = or i1 %r220, %r219
  %r222 = or i1 %r221, %r216
  br i1 %r222, label %ctor_prologue.barrier.maybe.40, label %ctor_prologue.barrier.done.42

ctor_prologue.barrier.maybe.40:                   ; preds = %ctor_prologue.barrier.done.39
  %r223 = sub i64 %r157152, 7
  %r224 = inttoptr i64 %r223 to ptr
  %r225 = load i8, ptr %r224, align 1
  %r226 = and i8 %r225, 32
  %r227 = icmp ne i8 %r226, 0
  %r228 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r229 = icmp ne i32 %r228, 0
  %r230 = or i1 %r227, %r229
  br i1 %r230, label %ctor_prologue.barrier.41, label %ctor_prologue.barrier.done.42

ctor_prologue.barrier.41:                         ; preds = %ctor_prologue.barrier.maybe.40
  call void @js_write_barrier_slot_validated_parent(i64 %r157152, i64 %r211, i64 %r212) #9
  br label %ctor_prologue.barrier.done.42

ctor_prologue.barrier.done.42:                    ; preds = %ctor_prologue.barrier.41, %ctor_prologue.barrier.maybe.40, %ctor_prologue.barrier.done.39
  %r231 = getelementptr double, ptr %r184, i64 3
  store double 0x7FFC000000000004, ptr %r231, align 8
  %r232 = ptrtoint ptr %r231 to i64
  br label %ctor_prologue.barrier.done.45

ctor_prologue.barrier.done.45:                    ; preds = %ctor_prologue.barrier.done.42
  %r252 = getelementptr double, ptr %r184, i64 4
  store double %r168, ptr %r252, align 8
  %r253 = ptrtoint ptr %r252 to i64
  %r254 = bitcast double %r168 to i64
  %r255 = lshr i64 %r254, 48
  %r256 = icmp eq i64 %r255, 0
  %r257 = icmp uge i64 %r254, 4096
  %r258 = and i1 %r256, %r257
  %r259 = icmp eq i64 %r255, 32765
  %r260 = icmp eq i64 %r255, 32767
  %r261 = icmp eq i64 %r255, 32762
  %r262 = or i1 %r259, %r260
  %r263 = or i1 %r262, %r261
  %r264 = or i1 %r263, %r258
  br i1 %r264, label %ctor_prologue.barrier.maybe.46, label %ctor_prologue.barrier.done.48

ctor_prologue.barrier.maybe.46:                   ; preds = %ctor_prologue.barrier.done.45
  %r265 = sub i64 %r157152, 7
  %r266 = inttoptr i64 %r265 to ptr
  %r267 = load i8, ptr %r266, align 1
  %r268 = and i8 %r267, 32
  %r269 = icmp ne i8 %r268, 0
  %r270 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r271 = icmp ne i32 %r270, 0
  %r272 = or i1 %r269, %r271
  br i1 %r272, label %ctor_prologue.barrier.47, label %ctor_prologue.barrier.done.48

ctor_prologue.barrier.47:                         ; preds = %ctor_prologue.barrier.maybe.46
  call void @js_write_barrier_slot_validated_parent(i64 %r157152, i64 %r253, i64 %r254) #9
  br label %ctor_prologue.barrier.done.48

ctor_prologue.barrier.done.48:                    ; preds = %ctor_prologue.barrier.47, %ctor_prologue.barrier.maybe.46, %ctor_prologue.barrier.done.45
  %r273 = getelementptr double, ptr %r184, i64 5
  store double %r170, ptr %r273, align 8
  %r274 = ptrtoint ptr %r273 to i64
  %r275 = bitcast double %r170 to i64
  %r276 = lshr i64 %r275, 48
  %r277 = icmp eq i64 %r276, 0
  %r278 = icmp uge i64 %r275, 4096
  %r279 = and i1 %r277, %r278
  %r280 = icmp eq i64 %r276, 32765
  %r281 = icmp eq i64 %r276, 32767
  %r282 = icmp eq i64 %r276, 32762
  %r283 = or i1 %r280, %r281
  %r284 = or i1 %r283, %r282
  %r285 = or i1 %r284, %r279
  br i1 %r285, label %ctor_prologue.barrier.maybe.49, label %ctor_prologue.barrier.done.51

ctor_prologue.barrier.maybe.49:                   ; preds = %ctor_prologue.barrier.done.48
  %r286 = sub i64 %r157152, 7
  %r287 = inttoptr i64 %r286 to ptr
  %r288 = load i8, ptr %r287, align 1
  %r289 = and i8 %r288, 32
  %r290 = icmp ne i8 %r289, 0
  %r291 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r292 = icmp ne i32 %r291, 0
  %r293 = or i1 %r290, %r292
  br i1 %r293, label %ctor_prologue.barrier.50, label %ctor_prologue.barrier.done.51

ctor_prologue.barrier.50:                         ; preds = %ctor_prologue.barrier.maybe.49
  call void @js_write_barrier_slot_validated_parent(i64 %r157152, i64 %r274, i64 %r275) #9
  br label %ctor_prologue.barrier.done.51

ctor_prologue.barrier.done.51:                    ; preds = %ctor_prologue.barrier.50, %ctor_prologue.barrier.maybe.49, %ctor_prologue.barrier.done.48
  br label %ctor_prologue.merge.36

ctor_ret.override.52:                             ; preds = %ctor_prologue.merge.36
  %statepoint_token161 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r298, double %r295, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.4418) ]
  %r301162 = call double @llvm.experimental.gc.result.f64(token %statepoint_token161)
  %rs4gc.s5.relocated163 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token161, i32 0, i32 0) ; (%.4, %.4)
  %rs4gc.s4.relocated164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token161, i32 1, i32 1) ; (%.4418, %.4418)
  br label %ctor_ret.merge.53

ctor_ret.merge.53:                                ; preds = %ctor_ret.override.52, %ctor_prologue.merge.36
  %.5419 = phi ptr addrspace(1) [ %.4418, %ctor_prologue.merge.36 ], [ %rs4gc.s4.relocated164, %ctor_ret.override.52 ]
  %.5 = phi ptr addrspace(1) [ %.4, %ctor_prologue.merge.36 ], [ %rs4gc.s5.relocated163, %ctor_ret.override.52 ]
  %r302 = phi double [ %r298, %ctor_prologue.merge.36 ], [ %r301162, %ctor_ret.override.52 ]
  %rs4gc.b12 = bitcast double %r302 to i64
  %rs4gc.s12 = inttoptr i64 %rs4gc.b12 to ptr addrspace(1)
  %r303.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r303 = call i64 asm "", "=r,0"(i64 %r303.rs4i) #9
  %r304 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r305 = icmp ne i32 %r304, 0
  br i1 %r305, label %shadow.root.barrier.54, label %shadow.root.barrier.done.55

shadow.root.barrier.54:                           ; preds = %ctor_ret.merge.53
  call void @js_write_barrier_root_nanbox(i64 %r303) #9
  br label %shadow.root.barrier.done.55

shadow.root.barrier.done.55:                      ; preds = %shadow.root.barrier.54, %ctor_ret.merge.53
  %r306.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r306.rs4o = call i64 asm "", "=r,0"(i64 %r306.rs4i) #9
  %r306 = bitcast i64 %r306.rs4o to double
  %statepoint_token165 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr)) @js_closure_alloc_singleton, i32 1, i32 0, ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__identity, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5, ptr addrspace(1) %.5419, ptr addrspace(1) %rs4gc.s12) ]
  %r307166 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token165)
  %rs4gc.s5.relocated167 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 0, i32 0) ; (%.5, %.5)
  %rs4gc.s4.relocated168 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 1, i32 1) ; (%.5419, %.5419)
  %rs4gc.s12.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 2, i32 2) ; (%rs4gc.s12, %rs4gc.s12)
  %r308 = or i64 %r307166, 9222527611924643840
  %r309 = bitcast i64 %r308 to double
  %r960.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12.relocated to i64
  %r960.rs4o = call i64 asm "", "=r,0"(i64 %r960.rs4i) #9
  %r960 = bitcast i64 %r960.rs4o to double
  %statepoint_token169 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r960, double %r309, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated167, ptr addrspace(1) %rs4gc.s4.relocated168, ptr addrspace(1) %rs4gc.s12.relocated) ]
  %r310170 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token169)
  %rs4gc.s5.relocated171 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 0, i32 0) ; (%rs4gc.s5.relocated167, %rs4gc.s5.relocated167)
  %rs4gc.s4.relocated172 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 1, i32 1) ; (%rs4gc.s4.relocated168, %rs4gc.s4.relocated168)
  %rs4gc.s12.relocated173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 2, i32 2) ; (%rs4gc.s12.relocated, %rs4gc.s12.relocated)
  %r311 = bitcast i64 %r310170 to double
  %rs4gc.s13 = inttoptr i64 %r310170 to ptr addrspace(1)
  %r312.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r312 = call i64 asm "", "=r,0"(i64 %r312.rs4i) #9
  %r313 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r314 = icmp ne i32 %r313, 0
  br i1 %r314, label %shadow.root.barrier.56, label %shadow.root.barrier.done.57

shadow.root.barrier.56:                           ; preds = %shadow.root.barrier.done.55
  call void @js_write_barrier_root_nanbox(i64 %r312) #9
  br label %shadow.root.barrier.done.57

shadow.root.barrier.done.57:                      ; preds = %shadow.root.barrier.56, %shadow.root.barrier.done.55
  %statepoint_token174 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated171, ptr addrspace(1) %rs4gc.s4.relocated172, ptr addrspace(1) %rs4gc.s12.relocated173, ptr addrspace(1) %rs4gc.s13) ]
  %r315175 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token174)
  %rs4gc.s5.relocated176 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token174, i32 0, i32 0) ; (%rs4gc.s5.relocated171, %rs4gc.s5.relocated171)
  %rs4gc.s4.relocated177 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token174, i32 1, i32 1) ; (%rs4gc.s4.relocated172, %rs4gc.s4.relocated172)
  %rs4gc.s12.relocated178 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token174, i32 2, i32 2) ; (%rs4gc.s12.relocated173, %rs4gc.s12.relocated173)
  %rs4gc.s13.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token174, i32 3, i32 3) ; (%rs4gc.s13, %rs4gc.s13)
  %rs4gc.s14 = inttoptr i64 %r315175 to ptr addrspace(1)
  %r316.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r316 = call i64 asm "", "=r,0"(i64 %r316.rs4i) #9
  %r317 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r318 = icmp ne i32 %r317, 0
  br i1 %r318, label %shadow.root.barrier.58, label %shadow.root.barrier.done.59

shadow.root.barrier.58:                           ; preds = %shadow.root.barrier.done.57
  call void @js_write_barrier_root_nanbox(i64 %r316) #9
  br label %shadow.root.barrier.done.59

shadow.root.barrier.done.59:                      ; preds = %shadow.root.barrier.58, %shadow.root.barrier.done.57
  %r319.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated to i64
  %r319 = call i64 asm "", "=r,0"(i64 %r319.rs4i) #9
  %r320 = bitcast i64 %r319 to double
  %r321.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r321 = call i64 asm "", "=r,0"(i64 %r321.rs4i) #9
  %statepoint_token179 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r321, double %r320, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated176, ptr addrspace(1) %rs4gc.s4.relocated177, ptr addrspace(1) %rs4gc.s12.relocated178) ]
  %r322180 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token179)
  %rs4gc.s5.relocated181 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 0, i32 0) ; (%rs4gc.s5.relocated176, %rs4gc.s5.relocated176)
  %rs4gc.s4.relocated182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 1, i32 1) ; (%rs4gc.s4.relocated177, %rs4gc.s4.relocated177)
  %rs4gc.s12.relocated183 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token179, i32 2, i32 2) ; (%rs4gc.s12.relocated178, %rs4gc.s12.relocated178)
  %rs4gc.s15 = inttoptr i64 %r322180 to ptr addrspace(1)
  %r323.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r323 = call i64 asm "", "=r,0"(i64 %r323.rs4i) #9
  %r324 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r325 = icmp ne i32 %r324, 0
  br i1 %r325, label %shadow.root.barrier.60, label %shadow.root.barrier.done.61

shadow.root.barrier.60:                           ; preds = %shadow.root.barrier.done.59
  call void @js_write_barrier_root_nanbox(i64 %r323) #9
  br label %shadow.root.barrier.done.61

shadow.root.barrier.done.61:                      ; preds = %shadow.root.barrier.60, %shadow.root.barrier.done.59
  %r326.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r326 = call i64 asm "", "=r,0"(i64 %r326.rs4i) #9
  %statepoint_token184 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r326, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated181, ptr addrspace(1) %rs4gc.s4.relocated182, ptr addrspace(1) %rs4gc.s12.relocated183) ]
  %rs4gc.s5.relocated185 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token184, i32 0, i32 0) ; (%rs4gc.s5.relocated181, %rs4gc.s5.relocated181)
  %rs4gc.s4.relocated186 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token184, i32 1, i32 1) ; (%rs4gc.s4.relocated182, %rs4gc.s4.relocated182)
  %rs4gc.s12.relocated187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token184, i32 2, i32 2) ; (%rs4gc.s12.relocated183, %rs4gc.s12.relocated183)
  %r327 = load double, ptr @perry_global_test_json_primitive_tojson_keys_ts__0, align 8
  %statepoint_token188 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r327, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated185, ptr addrspace(1) %rs4gc.s4.relocated186, ptr addrspace(1) %rs4gc.s12.relocated187) ]
  %r328189 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token188)
  %rs4gc.s5.relocated190 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 0, i32 0) ; (%rs4gc.s5.relocated185, %rs4gc.s5.relocated185)
  %rs4gc.s4.relocated191 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 1, i32 1) ; (%rs4gc.s4.relocated186, %rs4gc.s4.relocated186)
  %rs4gc.s12.relocated192 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 2, i32 2) ; (%rs4gc.s12.relocated187, %rs4gc.s12.relocated187)
  %r329 = bitcast i64 %r328189 to double
  %rs4gc.s16 = inttoptr i64 %r328189 to ptr addrspace(1)
  %r330.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r330 = call i64 asm "", "=r,0"(i64 %r330.rs4i) #9
  %r331 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r332 = icmp ne i32 %r331, 0
  br i1 %r332, label %shadow.root.barrier.62, label %shadow.root.barrier.done.63

shadow.root.barrier.62:                           ; preds = %shadow.root.barrier.done.61
  call void @js_write_barrier_root_nanbox(i64 %r330) #9
  br label %shadow.root.barrier.done.63

shadow.root.barrier.done.63:                      ; preds = %shadow.root.barrier.62, %shadow.root.barrier.done.61
  %statepoint_token193 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated190, ptr addrspace(1) %rs4gc.s4.relocated191, ptr addrspace(1) %rs4gc.s12.relocated192, ptr addrspace(1) %rs4gc.s16) ]
  %r333194 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token193)
  %rs4gc.s5.relocated195 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 0, i32 0) ; (%rs4gc.s5.relocated190, %rs4gc.s5.relocated190)
  %rs4gc.s4.relocated196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 1, i32 1) ; (%rs4gc.s4.relocated191, %rs4gc.s4.relocated191)
  %rs4gc.s12.relocated197 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 2, i32 2) ; (%rs4gc.s12.relocated192, %rs4gc.s12.relocated192)
  %rs4gc.s16.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 3, i32 3) ; (%rs4gc.s16, %rs4gc.s16)
  %rs4gc.s17 = inttoptr i64 %r333194 to ptr addrspace(1)
  %r334.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r334 = call i64 asm "", "=r,0"(i64 %r334.rs4i) #9
  %r335 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r336 = icmp ne i32 %r335, 0
  br i1 %r336, label %shadow.root.barrier.64, label %shadow.root.barrier.done.65

shadow.root.barrier.64:                           ; preds = %shadow.root.barrier.done.63
  call void @js_write_barrier_root_nanbox(i64 %r334) #9
  br label %shadow.root.barrier.done.65

shadow.root.barrier.done.65:                      ; preds = %shadow.root.barrier.64, %shadow.root.barrier.done.63
  %r337.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16.relocated to i64
  %r337 = call i64 asm "", "=r,0"(i64 %r337.rs4i) #9
  %r338 = bitcast i64 %r337 to double
  %r339.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r339 = call i64 asm "", "=r,0"(i64 %r339.rs4i) #9
  %statepoint_token198 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r339, double %r338, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated195, ptr addrspace(1) %rs4gc.s4.relocated196, ptr addrspace(1) %rs4gc.s12.relocated197) ]
  %r340199 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token198)
  %rs4gc.s5.relocated200 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 0, i32 0) ; (%rs4gc.s5.relocated195, %rs4gc.s5.relocated195)
  %rs4gc.s4.relocated201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 1, i32 1) ; (%rs4gc.s4.relocated196, %rs4gc.s4.relocated196)
  %rs4gc.s12.relocated202 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 2, i32 2) ; (%rs4gc.s12.relocated197, %rs4gc.s12.relocated197)
  %rs4gc.s18 = inttoptr i64 %r340199 to ptr addrspace(1)
  %r341.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r341 = call i64 asm "", "=r,0"(i64 %r341.rs4i) #9
  %r342 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r343 = icmp ne i32 %r342, 0
  br i1 %r343, label %shadow.root.barrier.66, label %shadow.root.barrier.done.67

shadow.root.barrier.66:                           ; preds = %shadow.root.barrier.done.65
  call void @js_write_barrier_root_nanbox(i64 %r341) #9
  br label %shadow.root.barrier.done.67

shadow.root.barrier.done.67:                      ; preds = %shadow.root.barrier.66, %shadow.root.barrier.done.65
  %r344.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r344 = call i64 asm "", "=r,0"(i64 %r344.rs4i) #9
  %statepoint_token203 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r344, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated200, ptr addrspace(1) %rs4gc.s4.relocated201, ptr addrspace(1) %rs4gc.s12.relocated202) ]
  %rs4gc.s5.relocated204 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 0, i32 0) ; (%rs4gc.s5.relocated200, %rs4gc.s5.relocated200)
  %rs4gc.s4.relocated205 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 1, i32 1) ; (%rs4gc.s4.relocated201, %rs4gc.s4.relocated201)
  %rs4gc.s12.relocated206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 2, i32 2) ; (%rs4gc.s12.relocated202, %rs4gc.s12.relocated202)
  %statepoint_token207 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated204, ptr addrspace(1) %rs4gc.s4.relocated205, ptr addrspace(1) %rs4gc.s12.relocated206) ]
  %r345208 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token207)
  %rs4gc.s5.relocated209 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 0, i32 0) ; (%rs4gc.s5.relocated204, %rs4gc.s5.relocated204)
  %rs4gc.s4.relocated210 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 1, i32 1) ; (%rs4gc.s4.relocated205, %rs4gc.s4.relocated205)
  %rs4gc.s12.relocated211 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 2, i32 2) ; (%rs4gc.s12.relocated206, %rs4gc.s12.relocated206)
  %r346 = or i64 %r345208, 9222527611924643840
  %r347 = bitcast i64 %r346 to double
  store double %r347, ptr @perry_global_test_json_primitive_tojson_keys_ts__2, align 8
  call void @js_write_barrier_root_nanbox(i64 %r346) #9
  %r348.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12.relocated211 to i64
  %r348.rs4o = call i64 asm "", "=r,0"(i64 %r348.rs4i) #9
  %r348 = bitcast i64 %r348.rs4o to double
  %statepoint_token212 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr, i32)) @js_closure_alloc, i32 2, i32 0, ptr @perry_closure_test_json_primitive_tojson_keys_ts__6, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated209, ptr addrspace(1) %rs4gc.s4.relocated210, ptr addrspace(1) %rs4gc.s12.relocated211) ]
  %r349213 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token212)
  %rs4gc.s5.relocated214 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 0, i32 0) ; (%rs4gc.s5.relocated209, %rs4gc.s5.relocated209)
  %rs4gc.s4.relocated215 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 1, i32 1) ; (%rs4gc.s4.relocated210, %rs4gc.s4.relocated210)
  %rs4gc.s12.relocated216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 2, i32 2) ; (%rs4gc.s12.relocated211, %rs4gc.s12.relocated211)
  %r350 = or i64 %r349213, 9222527611924643840
  %r351 = bitcast i64 %r350 to double
  %r959.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12.relocated216 to i64
  %r959.rs4o = call i64 asm "", "=r,0"(i64 %r959.rs4i) #9
  %r959 = bitcast i64 %r959.rs4o to double
  %statepoint_token217 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r959, double %r351, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated214, ptr addrspace(1) %rs4gc.s4.relocated215) ]
  %r352218 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token217)
  %rs4gc.s5.relocated219 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 0, i32 0) ; (%rs4gc.s5.relocated214, %rs4gc.s5.relocated214)
  %rs4gc.s4.relocated220 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 1, i32 1) ; (%rs4gc.s4.relocated215, %rs4gc.s4.relocated215)
  %r353 = bitcast i64 %r352218 to double
  %rs4gc.s19 = inttoptr i64 %r352218 to ptr addrspace(1)
  %r354.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r354 = call i64 asm "", "=r,0"(i64 %r354.rs4i) #9
  %r355 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r356 = icmp ne i32 %r355, 0
  br i1 %r356, label %shadow.root.barrier.68, label %shadow.root.barrier.done.69

shadow.root.barrier.68:                           ; preds = %shadow.root.barrier.done.67
  call void @js_write_barrier_root_nanbox(i64 %r354) #9
  br label %shadow.root.barrier.done.69

shadow.root.barrier.done.69:                      ; preds = %shadow.root.barrier.68, %shadow.root.barrier.done.67
  %statepoint_token221 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated219, ptr addrspace(1) %rs4gc.s4.relocated220, ptr addrspace(1) %rs4gc.s19) ]
  %r357222 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token221)
  %rs4gc.s5.relocated223 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 0, i32 0) ; (%rs4gc.s5.relocated219, %rs4gc.s5.relocated219)
  %rs4gc.s4.relocated224 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 1, i32 1) ; (%rs4gc.s4.relocated220, %rs4gc.s4.relocated220)
  %rs4gc.s19.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 2, i32 2) ; (%rs4gc.s19, %rs4gc.s19)
  %rs4gc.s20 = inttoptr i64 %r357222 to ptr addrspace(1)
  %r358.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r358 = call i64 asm "", "=r,0"(i64 %r358.rs4i) #9
  %r359 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r360 = icmp ne i32 %r359, 0
  br i1 %r360, label %shadow.root.barrier.70, label %shadow.root.barrier.done.71

shadow.root.barrier.70:                           ; preds = %shadow.root.barrier.done.69
  call void @js_write_barrier_root_nanbox(i64 %r358) #9
  br label %shadow.root.barrier.done.71

shadow.root.barrier.done.71:                      ; preds = %shadow.root.barrier.70, %shadow.root.barrier.done.69
  %r361.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19.relocated to i64
  %r361 = call i64 asm "", "=r,0"(i64 %r361.rs4i) #9
  %r362 = bitcast i64 %r361 to double
  %r363.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r363 = call i64 asm "", "=r,0"(i64 %r363.rs4i) #9
  %statepoint_token225 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r363, double %r362, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated223, ptr addrspace(1) %rs4gc.s4.relocated224) ]
  %r364226 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token225)
  %rs4gc.s5.relocated227 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token225, i32 0, i32 0) ; (%rs4gc.s5.relocated223, %rs4gc.s5.relocated223)
  %rs4gc.s4.relocated228 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token225, i32 1, i32 1) ; (%rs4gc.s4.relocated224, %rs4gc.s4.relocated224)
  %rs4gc.s21 = inttoptr i64 %r364226 to ptr addrspace(1)
  %r365.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r365 = call i64 asm "", "=r,0"(i64 %r365.rs4i) #9
  %r366 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r367 = icmp ne i32 %r366, 0
  br i1 %r367, label %shadow.root.barrier.72, label %shadow.root.barrier.done.73

shadow.root.barrier.72:                           ; preds = %shadow.root.barrier.done.71
  call void @js_write_barrier_root_nanbox(i64 %r365) #9
  br label %shadow.root.barrier.done.73

shadow.root.barrier.done.73:                      ; preds = %shadow.root.barrier.72, %shadow.root.barrier.done.71
  %r368.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r368 = call i64 asm "", "=r,0"(i64 %r368.rs4i) #9
  %statepoint_token229 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r368, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated227, ptr addrspace(1) %rs4gc.s4.relocated228) ]
  %rs4gc.s5.relocated230 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token229, i32 0, i32 0) ; (%rs4gc.s5.relocated227, %rs4gc.s5.relocated227)
  %rs4gc.s4.relocated231 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token229, i32 1, i32 1) ; (%rs4gc.s4.relocated228, %rs4gc.s4.relocated228)
  %r369 = load double, ptr @perry_global_test_json_primitive_tojson_keys_ts__2, align 8
  %statepoint_token232 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r369, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated230, ptr addrspace(1) %rs4gc.s4.relocated231) ]
  %r370233 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token232)
  %rs4gc.s5.relocated234 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token232, i32 0, i32 0) ; (%rs4gc.s5.relocated230, %rs4gc.s5.relocated230)
  %rs4gc.s4.relocated235 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token232, i32 1, i32 1) ; (%rs4gc.s4.relocated231, %rs4gc.s4.relocated231)
  %r371 = bitcast i64 %r370233 to double
  %rs4gc.s22 = inttoptr i64 %r370233 to ptr addrspace(1)
  %r372.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r372 = call i64 asm "", "=r,0"(i64 %r372.rs4i) #9
  %r373 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r374 = icmp ne i32 %r373, 0
  br i1 %r374, label %shadow.root.barrier.74, label %shadow.root.barrier.done.75

shadow.root.barrier.74:                           ; preds = %shadow.root.barrier.done.73
  call void @js_write_barrier_root_nanbox(i64 %r372) #9
  br label %shadow.root.barrier.done.75

shadow.root.barrier.done.75:                      ; preds = %shadow.root.barrier.74, %shadow.root.barrier.done.73
  %statepoint_token236 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated234, ptr addrspace(1) %rs4gc.s4.relocated235, ptr addrspace(1) %rs4gc.s22) ]
  %r375237 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token236)
  %rs4gc.s5.relocated238 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 0, i32 0) ; (%rs4gc.s5.relocated234, %rs4gc.s5.relocated234)
  %rs4gc.s4.relocated239 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 1, i32 1) ; (%rs4gc.s4.relocated235, %rs4gc.s4.relocated235)
  %rs4gc.s22.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token236, i32 2, i32 2) ; (%rs4gc.s22, %rs4gc.s22)
  %rs4gc.s23 = inttoptr i64 %r375237 to ptr addrspace(1)
  %r376.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r376 = call i64 asm "", "=r,0"(i64 %r376.rs4i) #9
  %r377 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r378 = icmp ne i32 %r377, 0
  br i1 %r378, label %shadow.root.barrier.76, label %shadow.root.barrier.done.77

shadow.root.barrier.76:                           ; preds = %shadow.root.barrier.done.75
  call void @js_write_barrier_root_nanbox(i64 %r376) #9
  br label %shadow.root.barrier.done.77

shadow.root.barrier.done.77:                      ; preds = %shadow.root.barrier.76, %shadow.root.barrier.done.75
  %r379.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22.relocated to i64
  %r379 = call i64 asm "", "=r,0"(i64 %r379.rs4i) #9
  %r380 = bitcast i64 %r379 to double
  %r381.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r381 = call i64 asm "", "=r,0"(i64 %r381.rs4i) #9
  %statepoint_token240 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r381, double %r380, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated238, ptr addrspace(1) %rs4gc.s4.relocated239) ]
  %r382241 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token240)
  %rs4gc.s5.relocated242 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token240, i32 0, i32 0) ; (%rs4gc.s5.relocated238, %rs4gc.s5.relocated238)
  %rs4gc.s4.relocated243 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token240, i32 1, i32 1) ; (%rs4gc.s4.relocated239, %rs4gc.s4.relocated239)
  %rs4gc.s24 = inttoptr i64 %r382241 to ptr addrspace(1)
  %r383.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r383 = call i64 asm "", "=r,0"(i64 %r383.rs4i) #9
  %r384 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r385 = icmp ne i32 %r384, 0
  br i1 %r385, label %shadow.root.barrier.78, label %shadow.root.barrier.done.79

shadow.root.barrier.78:                           ; preds = %shadow.root.barrier.done.77
  call void @js_write_barrier_root_nanbox(i64 %r383) #9
  br label %shadow.root.barrier.done.79

shadow.root.barrier.done.79:                      ; preds = %shadow.root.barrier.78, %shadow.root.barrier.done.77
  %r386.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r386 = call i64 asm "", "=r,0"(i64 %r386.rs4i) #9
  %statepoint_token244 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r386, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated242, ptr addrspace(1) %rs4gc.s4.relocated243) ]
  %rs4gc.s5.relocated245 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 0, i32 0) ; (%rs4gc.s5.relocated242, %rs4gc.s5.relocated242)
  %rs4gc.s4.relocated246 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 1, i32 1) ; (%rs4gc.s4.relocated243, %rs4gc.s4.relocated243)
  %r387 = load double, ptr @perry_global_test_json_primitive_tojson_keys_ts__0, align 8
  %statepoint_token247 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r387, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated245, ptr addrspace(1) %rs4gc.s4.relocated246) ]
  %r388248 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token247)
  %rs4gc.s5.relocated249 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token247, i32 0, i32 0) ; (%rs4gc.s5.relocated245, %rs4gc.s5.relocated245)
  %rs4gc.s4.relocated250 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token247, i32 1, i32 1) ; (%rs4gc.s4.relocated246, %rs4gc.s4.relocated246)
  %r389 = bitcast i64 %r388248 to double
  %rs4gc.s25 = inttoptr i64 %r388248 to ptr addrspace(1)
  %r390.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r390 = call i64 asm "", "=r,0"(i64 %r390.rs4i) #9
  %r391 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r392 = icmp ne i32 %r391, 0
  br i1 %r392, label %shadow.root.barrier.80, label %shadow.root.barrier.done.81

shadow.root.barrier.80:                           ; preds = %shadow.root.barrier.done.79
  call void @js_write_barrier_root_nanbox(i64 %r390) #9
  br label %shadow.root.barrier.done.81

shadow.root.barrier.done.81:                      ; preds = %shadow.root.barrier.80, %shadow.root.barrier.done.79
  %statepoint_token251 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated249, ptr addrspace(1) %rs4gc.s4.relocated250, ptr addrspace(1) %rs4gc.s25) ]
  %r393252 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token251)
  %rs4gc.s5.relocated253 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 0, i32 0) ; (%rs4gc.s5.relocated249, %rs4gc.s5.relocated249)
  %rs4gc.s4.relocated254 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 1, i32 1) ; (%rs4gc.s4.relocated250, %rs4gc.s4.relocated250)
  %rs4gc.s25.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 2, i32 2) ; (%rs4gc.s25, %rs4gc.s25)
  %rs4gc.s26 = inttoptr i64 %r393252 to ptr addrspace(1)
  %r394.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r394 = call i64 asm "", "=r,0"(i64 %r394.rs4i) #9
  %r395 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r396 = icmp ne i32 %r395, 0
  br i1 %r396, label %shadow.root.barrier.82, label %shadow.root.barrier.done.83

shadow.root.barrier.82:                           ; preds = %shadow.root.barrier.done.81
  call void @js_write_barrier_root_nanbox(i64 %r394) #9
  br label %shadow.root.barrier.done.83

shadow.root.barrier.done.83:                      ; preds = %shadow.root.barrier.82, %shadow.root.barrier.done.81
  %r397.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25.relocated to i64
  %r397 = call i64 asm "", "=r,0"(i64 %r397.rs4i) #9
  %r398 = bitcast i64 %r397 to double
  %r399.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r399 = call i64 asm "", "=r,0"(i64 %r399.rs4i) #9
  %statepoint_token255 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r399, double %r398, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated253, ptr addrspace(1) %rs4gc.s4.relocated254) ]
  %r400256 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token255)
  %rs4gc.s5.relocated257 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token255, i32 0, i32 0) ; (%rs4gc.s5.relocated253, %rs4gc.s5.relocated253)
  %rs4gc.s4.relocated258 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token255, i32 1, i32 1) ; (%rs4gc.s4.relocated254, %rs4gc.s4.relocated254)
  %rs4gc.s27 = inttoptr i64 %r400256 to ptr addrspace(1)
  %r401.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r401 = call i64 asm "", "=r,0"(i64 %r401.rs4i) #9
  %r402 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r403 = icmp ne i32 %r402, 0
  br i1 %r403, label %shadow.root.barrier.84, label %shadow.root.barrier.done.85

shadow.root.barrier.84:                           ; preds = %shadow.root.barrier.done.83
  call void @js_write_barrier_root_nanbox(i64 %r401) #9
  br label %shadow.root.barrier.done.85

shadow.root.barrier.done.85:                      ; preds = %shadow.root.barrier.84, %shadow.root.barrier.done.83
  %r404.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r404 = call i64 asm "", "=r,0"(i64 %r404.rs4i) #9
  %statepoint_token259 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r404, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated257, ptr addrspace(1) %rs4gc.s4.relocated258) ]
  %rs4gc.s5.relocated260 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 0, i32 0) ; (%rs4gc.s5.relocated257, %rs4gc.s5.relocated257)
  %rs4gc.s4.relocated261 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 1, i32 1) ; (%rs4gc.s4.relocated258, %rs4gc.s4.relocated258)
  %statepoint_token262 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, i64)) @js_get_global_this_builtin_value, i32 2, i32 0, ptr @test_json_primitive_tojson_keys_ts_.str.18.bytes, i64 6, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated260, ptr addrspace(1) %rs4gc.s4.relocated261) ]
  %r405263 = call double @llvm.experimental.gc.result.f64(token %statepoint_token262)
  %rs4gc.s5.relocated264 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token262, i32 0, i32 0) ; (%rs4gc.s5.relocated260, %rs4gc.s5.relocated260)
  %rs4gc.s4.relocated265 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token262, i32 1, i32 1) ; (%rs4gc.s4.relocated261, %rs4gc.s4.relocated261)
  %r406 = bitcast double %r405263 to i64
  %r407 = and i64 %r406, 281474976710655
  %r408 = lshr i64 %r406, 48
  %r409 = and i64 %r408, 65533
  %r410 = icmp eq i64 %r409, 32765
  br i1 %r410, label %pget.recv_ok.87, label %pget.recv_other.91

pget.recv_sso.86:                                 ; preds = %pget.recv_other.91
  %r548 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.19.handle, align 8
  %r549 = bitcast double %r548 to i64
  %r550 = and i64 %r549, 281474976710655
  %statepoint_token266 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r406, i64 %r550, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated264, ptr addrspace(1) %rs4gc.s4.relocated265) ]
  %r551267 = call double @llvm.experimental.gc.result.f64(token %statepoint_token266)
  %rs4gc.s5.relocated268 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token266, i32 0, i32 0) ; (%rs4gc.s5.relocated264, %rs4gc.s5.relocated264)
  %rs4gc.s4.relocated269 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token266, i32 1, i32 1) ; (%rs4gc.s4.relocated265, %rs4gc.s4.relocated265)
  br label %pget.recv_merge.90

pget.recv_ok.87:                                  ; preds = %shadow.root.barrier.done.85
  %r417 = icmp ugt i64 %r407, 1048575
  br i1 %r417, label %pic.recv_hdr.108, label %pic.miss.cold.105

pget.recv_bad.88:                                 ; preds = %pget.check_class_ref.92
  %r540 = icmp eq i64 %r406, 9222246136947933185
  %r541 = icmp eq i64 %r406, 9222246136947933186
  %r542 = or i1 %r540, %r541
  br i1 %r542, label %pget.throw_nullish.115, label %pget.recv_undef_return.116

pget.recv_class_ref.89:                           ; preds = %pget.check_class_ref.92
  %r413 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.19.handle, align 8
  %r414 = bitcast double %r413 to i64
  %r415 = and i64 %r414, 281474976710655
  %statepoint_token270 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6947013080479957007, i64 %r406, i64 %r415, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated264, ptr addrspace(1) %rs4gc.s4.relocated265) ]
  %r416271 = call double @llvm.experimental.gc.result.f64(token %statepoint_token270)
  %rs4gc.s5.relocated272 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token270, i32 0, i32 0) ; (%rs4gc.s5.relocated264, %rs4gc.s5.relocated264)
  %rs4gc.s4.relocated273 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token270, i32 1, i32 1) ; (%rs4gc.s4.relocated265, %rs4gc.s4.relocated265)
  br label %pget.recv_merge.90

pget.recv_merge.90:                               ; preds = %pget.recv_undef_return.116, %pic.merge.107, %pget.recv_class_ref.89, %pget.recv_sso.86
  %.6420 = phi ptr addrspace(1) [ %.7421, %pic.merge.107 ], [ %rs4gc.s4.relocated269, %pget.recv_sso.86 ], [ %rs4gc.s4.relocated273, %pget.recv_class_ref.89 ], [ %rs4gc.s4.relocated286, %pget.recv_undef_return.116 ]
  %.6 = phi ptr addrspace(1) [ %.7, %pic.merge.107 ], [ %rs4gc.s5.relocated268, %pget.recv_sso.86 ], [ %rs4gc.s5.relocated272, %pget.recv_class_ref.89 ], [ %rs4gc.s5.relocated285, %pget.recv_undef_return.116 ]
  %r552 = phi double [ %r539, %pic.merge.107 ], [ %r547284, %pget.recv_undef_return.116 ], [ %r551267, %pget.recv_sso.86 ], [ %r416271, %pget.recv_class_ref.89 ]
  %r553 = bitcast double %r552 to i64
  %rs4gc.s28 = inttoptr i64 %r553 to ptr addrspace(1)
  %r554.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r554 = call i64 asm "", "=r,0"(i64 %r554.rs4i) #9
  %r555 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r556 = icmp ne i32 %r555, 0
  br i1 %r556, label %shadow.root.barrier.117, label %shadow.root.barrier.done.118

pget.recv_other.91:                               ; preds = %shadow.root.barrier.done.85
  %r411 = icmp eq i64 %r408, 32761
  br i1 %r411, label %pget.recv_sso.86, label %pget.check_class_ref.92

pget.check_class_ref.92:                          ; preds = %pget.recv_other.91
  %r412 = icmp eq i64 %r408, 32766
  br i1 %r412, label %pget.recv_class_ref.89, label %pget.recv_bad.88

pic.hit.93:                                       ; preds = %pic.token.109
  %r442 = getelementptr i64, ptr %r427, i64 1
  %r443 = load i64, ptr %r442, align 8
  %r444 = and i64 %r443, 1073741824
  %r445 = icmp ne i64 %r444, 0
  br i1 %r445, label %pic.hit.overflow.110, label %pic.hit.inline.111

pic.hit.live.94:                                  ; preds = %pic.hit.inline.111
  br label %pic.merge.107

pic.prefix.guard.95:                              ; preds = %pic.token.109
  %r458 = getelementptr i64, ptr %r427, i64 2
  %r459 = load i64, ptr %r458, align 8
  %r460 = icmp ne i64 %r459, 0
  br i1 %r460, label %pic.prefix.meta.96, label %pic.miss.104

pic.prefix.meta.96:                               ; preds = %pic.prefix.guard.95
  %r461 = add nuw nsw i64 %r407, 8
  %r462 = inttoptr i64 %r461 to ptr
  %r463 = load i64, ptr %r462, align 8
  %r464 = icmp ne i64 %r463, 0
  br i1 %r464, label %pic.prefix.token.97, label %pic.miss.104

pic.prefix.token.97:                              ; preds = %pic.prefix.meta.96
  %r465 = inttoptr i64 %r463 to ptr
  %r466 = getelementptr i64, ptr %r465, i64 6
  %r467 = load i64, ptr %r466, align 8
  %r468 = icmp eq i64 %r467, %r459
  br i1 %r468, label %pic.prefix.hit.98, label %pic.miss.104

pic.prefix.hit.98:                                ; preds = %pic.prefix.token.97
  %r469 = getelementptr i64, ptr %r427, i64 1
  %r470 = load i64, ptr %r469, align 8
  %r471 = shl i64 %r470, 3
  %r472 = add nuw nsw i64 %r407, 16
  %r473 = add i64 %r472, %r471
  %r474 = inttoptr i64 %r473 to ptr
  %r475 = load double, ptr %r474, align 8
  br label %pic.merge.107

pic.desc.classify.99:                             ; preds = %pic.recv_hdr.108
  %r431 = and i1 %r421, %r428
  br i1 %r431, label %pic.desc.prefix.guard.100, label %pic.miss.cold.105

pic.desc.prefix.guard.100:                        ; preds = %pic.desc.classify.99
  %r476 = getelementptr i64, ptr %r427, i64 2
  %r477 = load i64, ptr %r476, align 8
  %r478 = icmp ne i64 %r477, 0
  br i1 %r478, label %pic.desc.prefix.meta.101, label %pic.miss.cold.105

pic.desc.prefix.meta.101:                         ; preds = %pic.desc.prefix.guard.100
  %r479 = add nuw nsw i64 %r407, 8
  %r480 = inttoptr i64 %r479 to ptr
  %r481 = load i64, ptr %r480, align 8
  %r482 = icmp ne i64 %r481, 0
  br i1 %r482, label %pic.desc.prefix.token.102, label %pic.miss.cold.105

pic.desc.prefix.token.102:                        ; preds = %pic.desc.prefix.meta.101
  %r483 = inttoptr i64 %r481 to ptr
  %r484 = getelementptr i64, ptr %r483, i64 6
  %r485 = load i64, ptr %r484, align 8
  %r486 = icmp eq i64 %r485, %r477
  br i1 %r486, label %pic.desc.prefix.hit.103, label %pic.miss.cold.105

pic.desc.prefix.hit.103:                          ; preds = %pic.desc.prefix.token.102
  %r487 = getelementptr i64, ptr %r427, i64 1
  %r488 = load i64, ptr %r487, align 8
  %r489 = shl i64 %r488, 3
  %r490 = add nuw nsw i64 %r407, 16
  %r491 = add i64 %r490, %r489
  %r492 = inttoptr i64 %r491 to ptr
  %r493 = load double, ptr %r492, align 8
  br label %pic.merge.107

pic.miss.104:                                     ; preds = %pic.hit.inline.111, %pic.prefix.token.97, %pic.prefix.meta.96, %pic.prefix.guard.95
  %r494 = getelementptr i64, ptr %r427, i64 3
  %r495 = load i64, ptr %r494, align 8
  %r496 = icmp sgt i64 %r495, 0
  br i1 %r496, label %pic.ways.112, label %pic.miss.call.106

pic.miss.cold.105:                                ; preds = %pic.desc.prefix.token.102, %pic.desc.prefix.meta.101, %pic.desc.prefix.guard.100, %pic.desc.classify.99, %pget.recv_ok.87
  br label %pic.miss.call.106

pic.miss.call.106:                                ; preds = %pic.way.load.113, %pic.ways.112, %pic.miss.cold.105, %pic.miss.104
  %r535 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.19.handle, align 8
  %r536 = bitcast double %r535 to i64
  %r537 = and i64 %r536, 281474976710655
  %statepoint_token274 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r407, i64 %r537, ptr @perry_ic_test_json_primitive_tojson_keys_ts__16, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated264, ptr addrspace(1) %rs4gc.s4.relocated265) ]
  %r538275 = call double @llvm.experimental.gc.result.f64(token %statepoint_token274)
  %rs4gc.s5.relocated276 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 0, i32 0) ; (%rs4gc.s5.relocated264, %rs4gc.s5.relocated264)
  %rs4gc.s4.relocated277 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 1, i32 1) ; (%rs4gc.s4.relocated265, %rs4gc.s4.relocated265)
  br label %pic.merge.107

pic.merge.107:                                    ; preds = %pic.way.live.114, %pic.hit.overflow.110, %pic.miss.call.106, %pic.desc.prefix.hit.103, %pic.prefix.hit.98, %pic.hit.live.94
  %.7421 = phi ptr addrspace(1) [ %rs4gc.s4.relocated281, %pic.hit.overflow.110 ], [ %rs4gc.s4.relocated277, %pic.miss.call.106 ], [ %rs4gc.s4.relocated265, %pic.way.live.114 ], [ %rs4gc.s4.relocated265, %pic.hit.live.94 ], [ %rs4gc.s4.relocated265, %pic.prefix.hit.98 ], [ %rs4gc.s4.relocated265, %pic.desc.prefix.hit.103 ]
  %.7 = phi ptr addrspace(1) [ %rs4gc.s5.relocated280, %pic.hit.overflow.110 ], [ %rs4gc.s5.relocated276, %pic.miss.call.106 ], [ %rs4gc.s5.relocated264, %pic.way.live.114 ], [ %rs4gc.s5.relocated264, %pic.hit.live.94 ], [ %rs4gc.s5.relocated264, %pic.prefix.hit.98 ], [ %rs4gc.s5.relocated264, %pic.desc.prefix.hit.103 ]
  %r539 = phi double [ %r455, %pic.hit.live.94 ], [ %r450279, %pic.hit.overflow.110 ], [ %r475, %pic.prefix.hit.98 ], [ %r493, %pic.desc.prefix.hit.103 ], [ %r532, %pic.way.live.114 ], [ %r538275, %pic.miss.call.106 ]
  br label %pget.recv_merge.90

pic.recv_hdr.108:                                 ; preds = %pget.recv_ok.87
  %r418 = sub nuw nsw i64 %r407, 8
  %r419 = inttoptr i64 %r418 to ptr
  %r420 = load i8, ptr %r419, align 1
  %r421 = icmp eq i8 %r420, 2
  %r422 = sub nuw nsw i64 %r407, 6
  %r423 = inttoptr i64 %r422 to ptr
  %r424 = load i16, ptr %r423, align 2
  %r425 = and i16 %r424, 2048
  %r426 = icmp eq i16 %r425, 0
  %r427 = load ptr, ptr @perry_ic_test_json_primitive_tojson_keys_ts__16, align 8
  %r428 = icmp ne ptr %r427, null
  %r429 = and i1 %r421, %r426
  %r430 = and i1 %r429, %r428
  br i1 %r430, label %pic.token.109, label %pic.desc.classify.99

pic.token.109:                                    ; preds = %pic.recv_hdr.108
  %r432 = add nuw nsw i64 %r407, 4
  %r433 = inttoptr i64 %r432 to ptr
  %r434 = load i32, ptr %r433, align 4
  %r435 = zext i32 %r434 to i64
  %r436 = or i64 %r435, 4611686018427387904
  %r437 = icmp ne i32 %r434, 0
  %r438 = getelementptr i64, ptr %r427, i64 0
  %r439 = load i64, ptr %r438, align 8
  %r440 = icmp eq i64 %r436, %r439
  %r441 = and i1 %r440, %r437
  br i1 %r441, label %pic.hit.93, label %pic.prefix.guard.95

pic.hit.overflow.110:                             ; preds = %pic.hit.93
  %r446 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.19.handle, align 8
  %r447 = bitcast double %r446 to i64
  %r448 = and i64 %r447, 281474976710655
  %r449 = trunc i64 %r443 to i32
  %statepoint_token278 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r407, i64 %r448, i32 %r449, ptr @perry_ic_test_json_primitive_tojson_keys_ts__16, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated264, ptr addrspace(1) %rs4gc.s4.relocated265) ]
  %r450279 = call double @llvm.experimental.gc.result.f64(token %statepoint_token278)
  %rs4gc.s5.relocated280 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token278, i32 0, i32 0) ; (%rs4gc.s5.relocated264, %rs4gc.s5.relocated264)
  %rs4gc.s4.relocated281 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token278, i32 1, i32 1) ; (%rs4gc.s4.relocated265, %rs4gc.s4.relocated265)
  br label %pic.merge.107

pic.hit.inline.111:                               ; preds = %pic.hit.93
  %r451 = shl i64 %r443, 3
  %r452 = add nuw nsw i64 %r407, 16
  %r453 = add i64 %r452, %r451
  %r454 = inttoptr i64 %r453 to ptr
  %r455 = load double, ptr %r454, align 8
  %r456 = bitcast double %r455 to i64
  %r457 = icmp eq i64 %r456, 9222246136947933200
  br i1 %r457, label %pic.miss.104, label %pic.hit.live.94

pic.ways.112:                                     ; preds = %pic.miss.104
  %r497 = getelementptr i64, ptr %r427, i64 4
  %r498 = load i64, ptr %r497, align 8
  %r499 = icmp eq i64 %r498, %r436
  %r500 = getelementptr i64, ptr %r427, i64 5
  %r501 = load i64, ptr %r500, align 8
  %r502 = select i1 %r499, i64 %r501, i64 0
  %r503 = getelementptr i64, ptr %r427, i64 6
  %r504 = load i64, ptr %r503, align 8
  %r505 = icmp eq i64 %r504, %r436
  %r506 = getelementptr i64, ptr %r427, i64 7
  %r507 = load i64, ptr %r506, align 8
  %r508 = select i1 %r505, i64 %r507, i64 0
  %r509 = getelementptr i64, ptr %r427, i64 8
  %r510 = load i64, ptr %r509, align 8
  %r511 = icmp eq i64 %r510, %r436
  %r512 = getelementptr i64, ptr %r427, i64 9
  %r513 = load i64, ptr %r512, align 8
  %r514 = select i1 %r511, i64 %r513, i64 0
  %r515 = getelementptr i64, ptr %r427, i64 10
  %r516 = load i64, ptr %r515, align 8
  %r517 = icmp eq i64 %r516, %r436
  %r518 = getelementptr i64, ptr %r427, i64 11
  %r519 = load i64, ptr %r518, align 8
  %r520 = select i1 %r517, i64 %r519, i64 0
  %r521 = or i1 %r499, %r505
  %r522 = select i1 %r499, i64 %r502, i64 %r508
  %r523 = or i1 %r511, %r517
  %r524 = select i1 %r511, i64 %r514, i64 %r520
  %r525 = or i1 %r521, %r523
  %r526 = select i1 %r521, i64 %r522, i64 %r524
  %r527 = and i1 %r437, %r525
  br i1 %r527, label %pic.way.load.113, label %pic.miss.call.106

pic.way.load.113:                                 ; preds = %pic.ways.112
  %r528 = shl i64 %r526, 3
  %r529 = add nuw nsw i64 %r407, 16
  %r530 = add i64 %r529, %r528
  %r531 = inttoptr i64 %r530 to ptr
  %r532 = load double, ptr %r531, align 8
  %r533 = bitcast double %r532 to i64
  %r534 = icmp eq i64 %r533, 9222246136947933200
  br i1 %r534, label %pic.miss.call.106, label %pic.way.live.114

pic.way.live.114:                                 ; preds = %pic.way.load.113
  br label %pic.merge.107

pget.throw_nullish.115:                           ; preds = %pget.recv_bad.88
  %r543 = zext i1 %r541 to i32
  %statepoint_token282 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r543, ptr @test_json_primitive_tojson_keys_ts_.str.19.bytes, i64 9, i32 0, i32 0)
  unreachable

pget.recv_undef_return.116:                       ; preds = %pget.recv_bad.88
  %r544 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.19.handle, align 8
  %r545 = bitcast double %r544 to i64
  %r546 = and i64 %r545, 281474976710655
  %statepoint_token283 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r406, i64 %r546, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated264, ptr addrspace(1) %rs4gc.s4.relocated265) ]
  %r547284 = call double @llvm.experimental.gc.result.f64(token %statepoint_token283)
  %rs4gc.s5.relocated285 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token283, i32 0, i32 0) ; (%rs4gc.s5.relocated264, %rs4gc.s5.relocated264)
  %rs4gc.s4.relocated286 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token283, i32 1, i32 1) ; (%rs4gc.s4.relocated265, %rs4gc.s4.relocated265)
  br label %pget.recv_merge.90

shadow.root.barrier.117:                          ; preds = %pget.recv_merge.90
  call void @js_write_barrier_root_nanbox(i64 %r554) #9
  br label %shadow.root.barrier.done.118

shadow.root.barrier.done.118:                     ; preds = %shadow.root.barrier.117, %pget.recv_merge.90
  %r557 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.5.handle, align 8
  %statepoint_token287 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr, i32)) @js_closure_alloc, i32 2, i32 0, ptr @perry_closure_test_json_primitive_tojson_keys_ts__8, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6, ptr addrspace(1) %.6420, ptr addrspace(1) %rs4gc.s28) ]
  %r558288 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token287)
  %rs4gc.s5.relocated289 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 0, i32 0) ; (%.6, %.6)
  %rs4gc.s4.relocated290 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 1, i32 1) ; (%.6420, %.6420)
  %rs4gc.s28.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 2, i32 2) ; (%rs4gc.s28, %rs4gc.s28)
  %r559 = or i64 %r558288, 9222527611924643840
  %r560 = bitcast i64 %r559 to double
  %r561 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.5.handle, align 8
  %r562.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28.relocated to i64
  %r562 = call i64 asm "", "=r,0"(i64 %r562.rs4i) #9
  %r563 = bitcast i64 %r562 to double
  %statepoint_token291 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, double, double, i32)) @js_put_value_set_dyn_ic, i32 5, i32 0, ptr @perry_ic_test_json_primitive_tojson_keys_ts__17, double %r563, double %r561, double %r560, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated289, ptr addrspace(1) %rs4gc.s4.relocated290) ]
  %rs4gc.s5.relocated292 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 0, i32 0) ; (%rs4gc.s5.relocated289, %rs4gc.s5.relocated289)
  %rs4gc.s4.relocated293 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 1, i32 1) ; (%rs4gc.s4.relocated290, %rs4gc.s4.relocated290)
  %statepoint_token294 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_bigint_from_i128_parts, i32 2, i32 0, i64 42, i64 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated292, ptr addrspace(1) %rs4gc.s4.relocated293) ]
  %r568295 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token294)
  %rs4gc.s5.relocated296 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token294, i32 0, i32 0) ; (%rs4gc.s5.relocated292, %rs4gc.s5.relocated292)
  %rs4gc.s4.relocated297 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token294, i32 1, i32 1) ; (%rs4gc.s4.relocated293, %rs4gc.s4.relocated293)
  %r569 = or i64 %r568295, 9221683186994511872
  %r570 = bitcast i64 %r569 to double
  %rs4gc.s29 = inttoptr i64 %r569 to ptr addrspace(1)
  %r571.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r571 = call i64 asm "", "=r,0"(i64 %r571.rs4i) #9
  %r572 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r573 = icmp ne i32 %r572, 0
  br i1 %r573, label %shadow.root.barrier.119, label %shadow.root.barrier.done.120

shadow.root.barrier.119:                          ; preds = %shadow.root.barrier.done.118
  call void @js_write_barrier_root_nanbox(i64 %r571) #9
  br label %shadow.root.barrier.done.120

shadow.root.barrier.done.120:                     ; preds = %shadow.root.barrier.119, %shadow.root.barrier.done.118
  %r574 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.20.handle, align 8
  %statepoint_token298 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @perry_fn_test_json_primitive_tojson_keys_ts__makeHook, i32 1, i32 0, double %r574, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated296, ptr addrspace(1) %rs4gc.s29, ptr addrspace(1) %rs4gc.s4.relocated297) ]
  %r575299 = call double @llvm.experimental.gc.result.f64(token %statepoint_token298)
  %rs4gc.s5.relocated300 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token298, i32 0, i32 0) ; (%rs4gc.s5.relocated296, %rs4gc.s5.relocated296)
  %rs4gc.s29.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token298, i32 1, i32 1) ; (%rs4gc.s29, %rs4gc.s29)
  %rs4gc.s4.relocated301 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token298, i32 2, i32 2) ; (%rs4gc.s4.relocated297, %rs4gc.s4.relocated297)
  %r576 = bitcast double %r575299 to i64
  %rs4gc.s30 = inttoptr i64 %r576 to ptr addrspace(1)
  %r577.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r577 = call i64 asm "", "=r,0"(i64 %r577.rs4i) #9
  %r578 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r579 = icmp ne i32 %r578, 0
  br i1 %r579, label %shadow.root.barrier.121, label %shadow.root.barrier.done.122

shadow.root.barrier.121:                          ; preds = %shadow.root.barrier.done.120
  call void @js_write_barrier_root_nanbox(i64 %r577) #9
  br label %shadow.root.barrier.done.122

shadow.root.barrier.done.122:                     ; preds = %shadow.root.barrier.121, %shadow.root.barrier.done.120
  %r582.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s4.relocated301 to i64
  %r582 = call i64 asm "", "=r,0"(i64 %r582.rs4i) #9
  %statepoint_token302 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 5, i32 0, i32 3, i64 %r582, i32 %r584, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated300, ptr addrspace(1) %rs4gc.s30, ptr addrspace(1) %rs4gc.s29.relocated) ]
  %r586303 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token302)
  %rs4gc.s5.relocated304 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token302, i32 0, i32 0) ; (%rs4gc.s5.relocated300, %rs4gc.s5.relocated300)
  %rs4gc.s30.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token302, i32 1, i32 1) ; (%rs4gc.s30, %rs4gc.s30)
  %rs4gc.s29.relocated305 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token302, i32 2, i32 2) ; (%rs4gc.s29.relocated, %rs4gc.s29.relocated)
  call void @js_gc_declare_typed_shape_layout(i64 %r586303, i32 3, ptr @perry_typed_shape_raw_f64_mask_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b, i32 1, ptr @perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b, i32 1) #9
  %rs4gc.s31 = inttoptr i64 %r586303 to ptr addrspace(1)
  %r587.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31 to i64
  %r587 = call i64 asm "", "=r,0"(i64 %r587.rs4i) #9
  %r588 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r589 = icmp ne i32 %r588, 0
  br i1 %r589, label %shadow.root.barrier.123, label %shadow.root.barrier.done.124

shadow.root.barrier.123:                          ; preds = %shadow.root.barrier.done.122
  call void @js_write_barrier_root_nanbox(i64 %r587) #9
  br label %shadow.root.barrier.done.124

shadow.root.barrier.done.124:                     ; preds = %shadow.root.barrier.123, %shadow.root.barrier.done.122
  %r590 = or i64 %r586303, 9222527611924643840
  %r591 = bitcast i64 %r590 to double
  %r592.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29.relocated305 to i64
  %r592 = call i64 asm "", "=r,0"(i64 %r592.rs4i) #9
  %r593 = bitcast i64 %r592 to double
  %r594.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30.relocated to i64
  %r594 = call i64 asm "", "=r,0"(i64 %r594.rs4i) #9
  %r595 = bitcast i64 %r594 to double
  %r596 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r597 = icmp eq i8 %r596, 0
  %r598 = inttoptr i64 %r586303 to ptr
  %r599 = getelementptr i8, ptr %r598, i64 -6
  %r600 = load i16, ptr %r599, align 2
  %r601 = and i16 %r600, 4096
  %r602 = icmp ne i16 %r601, 0
  %r603 = and i1 %r597, %r602
  br i1 %r603, label %ctor_prologue.fast.125, label %ctor_prologue.slow.126

ctor_prologue.fast.125:                           ; preds = %shadow.root.barrier.done.124
  %r608 = inttoptr i64 %r586303 to ptr
  %r609 = getelementptr i8, ptr %r608, i64 16
  %r610 = bitcast double %r591 to i64
  %r611 = getelementptr double, ptr %r609, i64 0
  store double 3.000000e+00, ptr %r611, align 8
  %r612 = ptrtoint ptr %r611 to i64
  %r614 = getelementptr double, ptr %r609, i64 1
  store double %r593, ptr %r614, align 8
  %r615 = ptrtoint ptr %r614 to i64
  %r616 = bitcast double %r593 to i64
  %r617 = lshr i64 %r616, 48
  %r618 = icmp eq i64 %r617, 0
  %r619 = icmp uge i64 %r616, 4096
  %r620 = and i1 %r618, %r619
  %r621 = icmp eq i64 %r617, 32765
  %r622 = icmp eq i64 %r617, 32767
  %r623 = icmp eq i64 %r617, 32762
  %r624 = or i1 %r621, %r622
  %r625 = or i1 %r624, %r623
  %r626 = or i1 %r625, %r620
  br i1 %r626, label %ctor_prologue.barrier.maybe.128, label %ctor_prologue.barrier.done.130

ctor_prologue.slow.126:                           ; preds = %shadow.root.barrier.done.124
  %statepoint_token306 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double, double)) @test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b_constructor, i32 4, i32 0, double %r591, double 3.000000e+00, double %r593, double %r595, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated304, ptr addrspace(1) %rs4gc.s31) ]
  %r656307 = call double @llvm.experimental.gc.result.f64(token %statepoint_token306)
  %rs4gc.s5.relocated308 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token306, i32 0, i32 0) ; (%rs4gc.s5.relocated304, %rs4gc.s5.relocated304)
  %rs4gc.s31.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token306, i32 1, i32 1) ; (%rs4gc.s31, %rs4gc.s31)
  br label %ctor_prologue.merge.127

ctor_prologue.merge.127:                          ; preds = %ctor_prologue.barrier.done.133, %ctor_prologue.slow.126
  %.0434 = phi ptr addrspace(1) [ %rs4gc.s31, %ctor_prologue.barrier.done.133 ], [ %rs4gc.s31.relocated, %ctor_prologue.slow.126 ]
  %.8 = phi ptr addrspace(1) [ %rs4gc.s5.relocated304, %ctor_prologue.barrier.done.133 ], [ %rs4gc.s5.relocated308, %ctor_prologue.slow.126 ]
  %r657 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.133 ], [ %r656307, %ctor_prologue.slow.126 ]
  %r658.rs4i = ptrtoint ptr addrspace(1) %.0434 to i64
  %r658 = call i64 asm "", "=r,0"(i64 %r658.rs4i) #9
  %r659 = or i64 %r658, 9222527611924643840
  %r660 = bitcast i64 %r659 to double
  %r661 = bitcast double %r657 to i64
  %r662 = icmp eq i64 %r661, 9222246136947933185
  br i1 %r662, label %ctor_ret.merge.135, label %ctor_ret.override.134

ctor_prologue.barrier.maybe.128:                  ; preds = %ctor_prologue.fast.125
  %r627 = sub i64 %r586303, 7
  %r628 = inttoptr i64 %r627 to ptr
  %r629 = load i8, ptr %r628, align 1
  %r630 = and i8 %r629, 32
  %r631 = icmp ne i8 %r630, 0
  %r632 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r633 = icmp ne i32 %r632, 0
  %r634 = or i1 %r631, %r633
  br i1 %r634, label %ctor_prologue.barrier.129, label %ctor_prologue.barrier.done.130

ctor_prologue.barrier.129:                        ; preds = %ctor_prologue.barrier.maybe.128
  call void @js_write_barrier_slot_validated_parent(i64 %r586303, i64 %r615, i64 %r616) #9
  br label %ctor_prologue.barrier.done.130

ctor_prologue.barrier.done.130:                   ; preds = %ctor_prologue.barrier.129, %ctor_prologue.barrier.maybe.128, %ctor_prologue.fast.125
  %r635 = getelementptr double, ptr %r609, i64 2
  store double %r595, ptr %r635, align 8
  %r636 = ptrtoint ptr %r635 to i64
  %r637 = bitcast double %r595 to i64
  %r638 = lshr i64 %r637, 48
  %r639 = icmp eq i64 %r638, 0
  %r640 = icmp uge i64 %r637, 4096
  %r641 = and i1 %r639, %r640
  %r642 = icmp eq i64 %r638, 32765
  %r643 = icmp eq i64 %r638, 32767
  %r644 = icmp eq i64 %r638, 32762
  %r645 = or i1 %r642, %r643
  %r646 = or i1 %r645, %r644
  %r647 = or i1 %r646, %r641
  br i1 %r647, label %ctor_prologue.barrier.maybe.131, label %ctor_prologue.barrier.done.133

ctor_prologue.barrier.maybe.131:                  ; preds = %ctor_prologue.barrier.done.130
  %r648 = sub i64 %r586303, 7
  %r649 = inttoptr i64 %r648 to ptr
  %r650 = load i8, ptr %r649, align 1
  %r651 = and i8 %r650, 32
  %r652 = icmp ne i8 %r651, 0
  %r653 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r654 = icmp ne i32 %r653, 0
  %r655 = or i1 %r652, %r654
  br i1 %r655, label %ctor_prologue.barrier.132, label %ctor_prologue.barrier.done.133

ctor_prologue.barrier.132:                        ; preds = %ctor_prologue.barrier.maybe.131
  call void @js_write_barrier_slot_validated_parent(i64 %r586303, i64 %r636, i64 %r637) #9
  br label %ctor_prologue.barrier.done.133

ctor_prologue.barrier.done.133:                   ; preds = %ctor_prologue.barrier.132, %ctor_prologue.barrier.maybe.131, %ctor_prologue.barrier.done.130
  br label %ctor_prologue.merge.127

ctor_ret.override.134:                            ; preds = %ctor_prologue.merge.127
  %statepoint_token309 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r660, double %r657, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8) ]
  %r663310 = call double @llvm.experimental.gc.result.f64(token %statepoint_token309)
  %rs4gc.s5.relocated311 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token309, i32 0, i32 0) ; (%.8, %.8)
  br label %ctor_ret.merge.135

ctor_ret.merge.135:                               ; preds = %ctor_ret.override.134, %ctor_prologue.merge.127
  %.9 = phi ptr addrspace(1) [ %.8, %ctor_prologue.merge.127 ], [ %rs4gc.s5.relocated311, %ctor_ret.override.134 ]
  %r664 = phi double [ %r660, %ctor_prologue.merge.127 ], [ %r663310, %ctor_ret.override.134 ]
  %statepoint_token312 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr)) @js_closure_alloc_singleton, i32 1, i32 0, ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__identity, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9) ]
  %r665313 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token312)
  %rs4gc.s5.relocated314 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token312, i32 0, i32 0) ; (%.9, %.9)
  %r666 = or i64 %r665313, 9222527611924643840
  %r667 = bitcast i64 %r666 to double
  %statepoint_token315 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r664, double %r667, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated314) ]
  %r668316 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token315)
  %rs4gc.s5.relocated317 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token315, i32 0, i32 0) ; (%rs4gc.s5.relocated314, %rs4gc.s5.relocated314)
  %r669 = bitcast i64 %r668316 to double
  %rs4gc.s32 = inttoptr i64 %r668316 to ptr addrspace(1)
  %r670.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s32 to i64
  %r670 = call i64 asm "", "=r,0"(i64 %r670.rs4i) #9
  %r671 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r672 = icmp ne i32 %r671, 0
  br i1 %r672, label %shadow.root.barrier.136, label %shadow.root.barrier.done.137

shadow.root.barrier.136:                          ; preds = %ctor_ret.merge.135
  call void @js_write_barrier_root_nanbox(i64 %r670) #9
  br label %shadow.root.barrier.done.137

shadow.root.barrier.done.137:                     ; preds = %shadow.root.barrier.136, %ctor_ret.merge.135
  %statepoint_token318 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated317, ptr addrspace(1) %rs4gc.s32) ]
  %r673319 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token318)
  %rs4gc.s5.relocated320 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token318, i32 0, i32 0) ; (%rs4gc.s5.relocated317, %rs4gc.s5.relocated317)
  %rs4gc.s32.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token318, i32 1, i32 1) ; (%rs4gc.s32, %rs4gc.s32)
  %rs4gc.s33 = inttoptr i64 %r673319 to ptr addrspace(1)
  %r674.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s33 to i64
  %r674 = call i64 asm "", "=r,0"(i64 %r674.rs4i) #9
  %r675 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r676 = icmp ne i32 %r675, 0
  br i1 %r676, label %shadow.root.barrier.138, label %shadow.root.barrier.done.139

shadow.root.barrier.138:                          ; preds = %shadow.root.barrier.done.137
  call void @js_write_barrier_root_nanbox(i64 %r674) #9
  br label %shadow.root.barrier.done.139

shadow.root.barrier.done.139:                     ; preds = %shadow.root.barrier.138, %shadow.root.barrier.done.137
  %r677.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s32.relocated to i64
  %r677 = call i64 asm "", "=r,0"(i64 %r677.rs4i) #9
  %r678 = bitcast i64 %r677 to double
  %r679.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s33 to i64
  %r679 = call i64 asm "", "=r,0"(i64 %r679.rs4i) #9
  %statepoint_token321 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r679, double %r678, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated320) ]
  %r680322 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token321)
  %rs4gc.s5.relocated323 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token321, i32 0, i32 0) ; (%rs4gc.s5.relocated320, %rs4gc.s5.relocated320)
  %rs4gc.s34 = inttoptr i64 %r680322 to ptr addrspace(1)
  %r681.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s34 to i64
  %r681 = call i64 asm "", "=r,0"(i64 %r681.rs4i) #9
  %r682 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r683 = icmp ne i32 %r682, 0
  br i1 %r683, label %shadow.root.barrier.140, label %shadow.root.barrier.done.141

shadow.root.barrier.140:                          ; preds = %shadow.root.barrier.done.139
  call void @js_write_barrier_root_nanbox(i64 %r681) #9
  br label %shadow.root.barrier.done.141

shadow.root.barrier.done.141:                     ; preds = %shadow.root.barrier.140, %shadow.root.barrier.done.139
  %r684.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s34 to i64
  %r684 = call i64 asm "", "=r,0"(i64 %r684.rs4i) #9
  %statepoint_token324 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r684, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated323) ]
  %rs4gc.s5.relocated325 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token324, i32 0, i32 0) ; (%rs4gc.s5.relocated323, %rs4gc.s5.relocated323)
  %statepoint_token326 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, i64)) @js_get_global_this_builtin_value, i32 2, i32 0, ptr @test_json_primitive_tojson_keys_ts_.str.18.bytes, i64 6, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated325) ]
  %r685327 = call double @llvm.experimental.gc.result.f64(token %statepoint_token326)
  %rs4gc.s5.relocated328 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 0, i32 0) ; (%rs4gc.s5.relocated325, %rs4gc.s5.relocated325)
  %r686 = bitcast double %r685327 to i64
  %r687 = and i64 %r686, 281474976710655
  %r688 = lshr i64 %r686, 48
  %r689 = and i64 %r688, 65533
  %r690 = icmp eq i64 %r689, 32765
  br i1 %r690, label %pget.recv_ok.143, label %pget.recv_other.147

pget.recv_sso.142:                                ; preds = %pget.recv_other.147
  %r828 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.19.handle, align 8
  %r829 = bitcast double %r828 to i64
  %r830 = and i64 %r829, 281474976710655
  %statepoint_token329 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r686, i64 %r830, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated328) ]
  %r831330 = call double @llvm.experimental.gc.result.f64(token %statepoint_token329)
  %rs4gc.s5.relocated331 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 0, i32 0) ; (%rs4gc.s5.relocated328, %rs4gc.s5.relocated328)
  br label %pget.recv_merge.146

pget.recv_ok.143:                                 ; preds = %shadow.root.barrier.done.141
  %r697 = icmp ugt i64 %r687, 1048575
  br i1 %r697, label %pic.recv_hdr.164, label %pic.miss.cold.161

pget.recv_bad.144:                                ; preds = %pget.check_class_ref.148
  %r820 = icmp eq i64 %r686, 9222246136947933185
  %r821 = icmp eq i64 %r686, 9222246136947933186
  %r822 = or i1 %r820, %r821
  br i1 %r822, label %pget.throw_nullish.171, label %pget.recv_undef_return.172

pget.recv_class_ref.145:                          ; preds = %pget.check_class_ref.148
  %r693 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.19.handle, align 8
  %r694 = bitcast double %r693 to i64
  %r695 = and i64 %r694, 281474976710655
  %statepoint_token332 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 6947013080479957010, i64 %r686, i64 %r695, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated328) ]
  %r696333 = call double @llvm.experimental.gc.result.f64(token %statepoint_token332)
  %rs4gc.s5.relocated334 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token332, i32 0, i32 0) ; (%rs4gc.s5.relocated328, %rs4gc.s5.relocated328)
  br label %pget.recv_merge.146

pget.recv_merge.146:                              ; preds = %pget.recv_undef_return.172, %pic.merge.163, %pget.recv_class_ref.145, %pget.recv_sso.142
  %.10 = phi ptr addrspace(1) [ %.11, %pic.merge.163 ], [ %rs4gc.s5.relocated331, %pget.recv_sso.142 ], [ %rs4gc.s5.relocated334, %pget.recv_class_ref.145 ], [ %rs4gc.s5.relocated354, %pget.recv_undef_return.172 ]
  %r832 = phi double [ %r819, %pic.merge.163 ], [ %r827353, %pget.recv_undef_return.172 ], [ %r831330, %pget.recv_sso.142 ], [ %r696333, %pget.recv_class_ref.145 ]
  %statepoint_token335 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_require_object_coercible, i32 1, i32 0, double %r832, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10) ]
  %rs4gc.s5.relocated336 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token335, i32 0, i32 0) ; (%.10, %.10)
  %r834 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.5.handle, align 8
  %r835 = bitcast double %r834 to i64
  %r836 = and i64 %r835, 281474976710655
  %statepoint_token337 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (double, i64)) @js_object_delete_field_value, i32 2, i32 0, double %r832, i64 %r836, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated336) ]
  %r837338 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token337)
  %rs4gc.s5.relocated339 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token337, i32 0, i32 0) ; (%rs4gc.s5.relocated336, %rs4gc.s5.relocated336)
  %statepoint_token340 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i32, i32)) @js_delete_result, i32 2, i32 0, i32 %r837338, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated339) ]
  %rs4gc.s5.relocated341 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token340, i32 0, i32 0) ; (%rs4gc.s5.relocated339, %rs4gc.s5.relocated339)
  %statepoint_token342 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_bigint_from_i128_parts, i32 2, i32 0, i64 42, i64 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated341) ]
  %r842343 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token342)
  %rs4gc.s5.relocated344 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 0, i32 0) ; (%rs4gc.s5.relocated341, %rs4gc.s5.relocated341)
  %r843 = or i64 %r842343, 9221683186994511872
  %r844 = bitcast i64 %r843 to double
  %rs4gc.s35 = inttoptr i64 %r843 to ptr addrspace(1)
  %r845.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r845 = call i64 asm "", "=r,0"(i64 %r845.rs4i) #9
  %r846 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r847 = icmp ne i32 %r846, 0
  br i1 %r847, label %shadow.root.barrier.173, label %shadow.root.barrier.done.174

pget.recv_other.147:                              ; preds = %shadow.root.barrier.done.141
  %r691 = icmp eq i64 %r688, 32761
  br i1 %r691, label %pget.recv_sso.142, label %pget.check_class_ref.148

pget.check_class_ref.148:                         ; preds = %pget.recv_other.147
  %r692 = icmp eq i64 %r688, 32766
  br i1 %r692, label %pget.recv_class_ref.145, label %pget.recv_bad.144

pic.hit.149:                                      ; preds = %pic.token.165
  %r722 = getelementptr i64, ptr %r707, i64 1
  %r723 = load i64, ptr %r722, align 8
  %r724 = and i64 %r723, 1073741824
  %r725 = icmp ne i64 %r724, 0
  br i1 %r725, label %pic.hit.overflow.166, label %pic.hit.inline.167

pic.hit.live.150:                                 ; preds = %pic.hit.inline.167
  br label %pic.merge.163

pic.prefix.guard.151:                             ; preds = %pic.token.165
  %r738 = getelementptr i64, ptr %r707, i64 2
  %r739 = load i64, ptr %r738, align 8
  %r740 = icmp ne i64 %r739, 0
  br i1 %r740, label %pic.prefix.meta.152, label %pic.miss.160

pic.prefix.meta.152:                              ; preds = %pic.prefix.guard.151
  %r741 = add nuw nsw i64 %r687, 8
  %r742 = inttoptr i64 %r741 to ptr
  %r743 = load i64, ptr %r742, align 8
  %r744 = icmp ne i64 %r743, 0
  br i1 %r744, label %pic.prefix.token.153, label %pic.miss.160

pic.prefix.token.153:                             ; preds = %pic.prefix.meta.152
  %r745 = inttoptr i64 %r743 to ptr
  %r746 = getelementptr i64, ptr %r745, i64 6
  %r747 = load i64, ptr %r746, align 8
  %r748 = icmp eq i64 %r747, %r739
  br i1 %r748, label %pic.prefix.hit.154, label %pic.miss.160

pic.prefix.hit.154:                               ; preds = %pic.prefix.token.153
  %r749 = getelementptr i64, ptr %r707, i64 1
  %r750 = load i64, ptr %r749, align 8
  %r751 = shl i64 %r750, 3
  %r752 = add nuw nsw i64 %r687, 16
  %r753 = add i64 %r752, %r751
  %r754 = inttoptr i64 %r753 to ptr
  %r755 = load double, ptr %r754, align 8
  br label %pic.merge.163

pic.desc.classify.155:                            ; preds = %pic.recv_hdr.164
  %r711 = and i1 %r701, %r708
  br i1 %r711, label %pic.desc.prefix.guard.156, label %pic.miss.cold.161

pic.desc.prefix.guard.156:                        ; preds = %pic.desc.classify.155
  %r756 = getelementptr i64, ptr %r707, i64 2
  %r757 = load i64, ptr %r756, align 8
  %r758 = icmp ne i64 %r757, 0
  br i1 %r758, label %pic.desc.prefix.meta.157, label %pic.miss.cold.161

pic.desc.prefix.meta.157:                         ; preds = %pic.desc.prefix.guard.156
  %r759 = add nuw nsw i64 %r687, 8
  %r760 = inttoptr i64 %r759 to ptr
  %r761 = load i64, ptr %r760, align 8
  %r762 = icmp ne i64 %r761, 0
  br i1 %r762, label %pic.desc.prefix.token.158, label %pic.miss.cold.161

pic.desc.prefix.token.158:                        ; preds = %pic.desc.prefix.meta.157
  %r763 = inttoptr i64 %r761 to ptr
  %r764 = getelementptr i64, ptr %r763, i64 6
  %r765 = load i64, ptr %r764, align 8
  %r766 = icmp eq i64 %r765, %r757
  br i1 %r766, label %pic.desc.prefix.hit.159, label %pic.miss.cold.161

pic.desc.prefix.hit.159:                          ; preds = %pic.desc.prefix.token.158
  %r767 = getelementptr i64, ptr %r707, i64 1
  %r768 = load i64, ptr %r767, align 8
  %r769 = shl i64 %r768, 3
  %r770 = add nuw nsw i64 %r687, 16
  %r771 = add i64 %r770, %r769
  %r772 = inttoptr i64 %r771 to ptr
  %r773 = load double, ptr %r772, align 8
  br label %pic.merge.163

pic.miss.160:                                     ; preds = %pic.hit.inline.167, %pic.prefix.token.153, %pic.prefix.meta.152, %pic.prefix.guard.151
  %r774 = getelementptr i64, ptr %r707, i64 3
  %r775 = load i64, ptr %r774, align 8
  %r776 = icmp sgt i64 %r775, 0
  br i1 %r776, label %pic.ways.168, label %pic.miss.call.162

pic.miss.cold.161:                                ; preds = %pic.desc.prefix.token.158, %pic.desc.prefix.meta.157, %pic.desc.prefix.guard.156, %pic.desc.classify.155, %pget.recv_ok.143
  br label %pic.miss.call.162

pic.miss.call.162:                                ; preds = %pic.way.load.169, %pic.ways.168, %pic.miss.cold.161, %pic.miss.160
  %r815 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.19.handle, align 8
  %r816 = bitcast double %r815 to i64
  %r817 = and i64 %r816, 281474976710655
  %statepoint_token345 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r687, i64 %r817, ptr @perry_ic_test_json_primitive_tojson_keys_ts__19, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated328) ]
  %r818346 = call double @llvm.experimental.gc.result.f64(token %statepoint_token345)
  %rs4gc.s5.relocated347 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token345, i32 0, i32 0) ; (%rs4gc.s5.relocated328, %rs4gc.s5.relocated328)
  br label %pic.merge.163

pic.merge.163:                                    ; preds = %pic.way.live.170, %pic.hit.overflow.166, %pic.miss.call.162, %pic.desc.prefix.hit.159, %pic.prefix.hit.154, %pic.hit.live.150
  %.11 = phi ptr addrspace(1) [ %rs4gc.s5.relocated350, %pic.hit.overflow.166 ], [ %rs4gc.s5.relocated347, %pic.miss.call.162 ], [ %rs4gc.s5.relocated328, %pic.way.live.170 ], [ %rs4gc.s5.relocated328, %pic.hit.live.150 ], [ %rs4gc.s5.relocated328, %pic.prefix.hit.154 ], [ %rs4gc.s5.relocated328, %pic.desc.prefix.hit.159 ]
  %r819 = phi double [ %r735, %pic.hit.live.150 ], [ %r730349, %pic.hit.overflow.166 ], [ %r755, %pic.prefix.hit.154 ], [ %r773, %pic.desc.prefix.hit.159 ], [ %r812, %pic.way.live.170 ], [ %r818346, %pic.miss.call.162 ]
  br label %pget.recv_merge.146

pic.recv_hdr.164:                                 ; preds = %pget.recv_ok.143
  %r698 = sub nuw nsw i64 %r687, 8
  %r699 = inttoptr i64 %r698 to ptr
  %r700 = load i8, ptr %r699, align 1
  %r701 = icmp eq i8 %r700, 2
  %r702 = sub nuw nsw i64 %r687, 6
  %r703 = inttoptr i64 %r702 to ptr
  %r704 = load i16, ptr %r703, align 2
  %r705 = and i16 %r704, 2048
  %r706 = icmp eq i16 %r705, 0
  %r707 = load ptr, ptr @perry_ic_test_json_primitive_tojson_keys_ts__19, align 8
  %r708 = icmp ne ptr %r707, null
  %r709 = and i1 %r701, %r706
  %r710 = and i1 %r709, %r708
  br i1 %r710, label %pic.token.165, label %pic.desc.classify.155

pic.token.165:                                    ; preds = %pic.recv_hdr.164
  %r712 = add nuw nsw i64 %r687, 4
  %r713 = inttoptr i64 %r712 to ptr
  %r714 = load i32, ptr %r713, align 4
  %r715 = zext i32 %r714 to i64
  %r716 = or i64 %r715, 4611686018427387904
  %r717 = icmp ne i32 %r714, 0
  %r718 = getelementptr i64, ptr %r707, i64 0
  %r719 = load i64, ptr %r718, align 8
  %r720 = icmp eq i64 %r716, %r719
  %r721 = and i1 %r720, %r717
  br i1 %r721, label %pic.hit.149, label %pic.prefix.guard.151

pic.hit.overflow.166:                             ; preds = %pic.hit.149
  %r726 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.19.handle, align 8
  %r727 = bitcast double %r726 to i64
  %r728 = and i64 %r727, 281474976710655
  %r729 = trunc i64 %r723 to i32
  %statepoint_token348 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r687, i64 %r728, i32 %r729, ptr @perry_ic_test_json_primitive_tojson_keys_ts__19, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated328) ]
  %r730349 = call double @llvm.experimental.gc.result.f64(token %statepoint_token348)
  %rs4gc.s5.relocated350 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token348, i32 0, i32 0) ; (%rs4gc.s5.relocated328, %rs4gc.s5.relocated328)
  br label %pic.merge.163

pic.hit.inline.167:                               ; preds = %pic.hit.149
  %r731 = shl i64 %r723, 3
  %r732 = add nuw nsw i64 %r687, 16
  %r733 = add i64 %r732, %r731
  %r734 = inttoptr i64 %r733 to ptr
  %r735 = load double, ptr %r734, align 8
  %r736 = bitcast double %r735 to i64
  %r737 = icmp eq i64 %r736, 9222246136947933200
  br i1 %r737, label %pic.miss.160, label %pic.hit.live.150

pic.ways.168:                                     ; preds = %pic.miss.160
  %r777 = getelementptr i64, ptr %r707, i64 4
  %r778 = load i64, ptr %r777, align 8
  %r779 = icmp eq i64 %r778, %r716
  %r780 = getelementptr i64, ptr %r707, i64 5
  %r781 = load i64, ptr %r780, align 8
  %r782 = select i1 %r779, i64 %r781, i64 0
  %r783 = getelementptr i64, ptr %r707, i64 6
  %r784 = load i64, ptr %r783, align 8
  %r785 = icmp eq i64 %r784, %r716
  %r786 = getelementptr i64, ptr %r707, i64 7
  %r787 = load i64, ptr %r786, align 8
  %r788 = select i1 %r785, i64 %r787, i64 0
  %r789 = getelementptr i64, ptr %r707, i64 8
  %r790 = load i64, ptr %r789, align 8
  %r791 = icmp eq i64 %r790, %r716
  %r792 = getelementptr i64, ptr %r707, i64 9
  %r793 = load i64, ptr %r792, align 8
  %r794 = select i1 %r791, i64 %r793, i64 0
  %r795 = getelementptr i64, ptr %r707, i64 10
  %r796 = load i64, ptr %r795, align 8
  %r797 = icmp eq i64 %r796, %r716
  %r798 = getelementptr i64, ptr %r707, i64 11
  %r799 = load i64, ptr %r798, align 8
  %r800 = select i1 %r797, i64 %r799, i64 0
  %r801 = or i1 %r779, %r785
  %r802 = select i1 %r779, i64 %r782, i64 %r788
  %r803 = or i1 %r791, %r797
  %r804 = select i1 %r791, i64 %r794, i64 %r800
  %r805 = or i1 %r801, %r803
  %r806 = select i1 %r801, i64 %r802, i64 %r804
  %r807 = and i1 %r717, %r805
  br i1 %r807, label %pic.way.load.169, label %pic.miss.call.162

pic.way.load.169:                                 ; preds = %pic.ways.168
  %r808 = shl i64 %r806, 3
  %r809 = add nuw nsw i64 %r687, 16
  %r810 = add i64 %r809, %r808
  %r811 = inttoptr i64 %r810 to ptr
  %r812 = load double, ptr %r811, align 8
  %r813 = bitcast double %r812 to i64
  %r814 = icmp eq i64 %r813, 9222246136947933200
  br i1 %r814, label %pic.miss.call.162, label %pic.way.live.170

pic.way.live.170:                                 ; preds = %pic.way.load.169
  br label %pic.merge.163

pget.throw_nullish.171:                           ; preds = %pget.recv_bad.144
  %r823 = zext i1 %r821 to i32
  %statepoint_token351 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r823, ptr @test_json_primitive_tojson_keys_ts_.str.19.bytes, i64 9, i32 0, i32 0)
  unreachable

pget.recv_undef_return.172:                       ; preds = %pget.recv_bad.144
  %r824 = load double, ptr @test_json_primitive_tojson_keys_ts_.str.19.handle, align 8
  %r825 = bitcast double %r824 to i64
  %r826 = and i64 %r825, 281474976710655
  %statepoint_token352 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r686, i64 %r826, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s5.relocated328) ]
  %r827353 = call double @llvm.experimental.gc.result.f64(token %statepoint_token352)
  %rs4gc.s5.relocated354 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token352, i32 0, i32 0) ; (%rs4gc.s5.relocated328, %rs4gc.s5.relocated328)
  br label %pget.recv_merge.146

shadow.root.barrier.173:                          ; preds = %pget.recv_merge.146
  call void @js_write_barrier_root_nanbox(i64 %r845) #9
  br label %shadow.root.barrier.done.174

shadow.root.barrier.done.174:                     ; preds = %shadow.root.barrier.173, %pget.recv_merge.146
  %r850.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s5.relocated344 to i64
  %r850 = call i64 asm "", "=r,0"(i64 %r850.rs4i) #9
  %statepoint_token355 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 6, i32 0, i32 1, i64 %r850, i32 %r852, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s35) ]
  %r854356 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token355)
  %rs4gc.s35.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token355, i32 0, i32 0) ; (%rs4gc.s35, %rs4gc.s35)
  call void @js_gc_declare_typed_shape_layout(i64 %r854356, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77, i32 1) #9
  %rs4gc.s36 = inttoptr i64 %r854356 to ptr addrspace(1)
  %r855.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s36 to i64
  %r855 = call i64 asm "", "=r,0"(i64 %r855.rs4i) #9
  %r856 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r857 = icmp ne i32 %r856, 0
  br i1 %r857, label %shadow.root.barrier.175, label %shadow.root.barrier.done.176

shadow.root.barrier.175:                          ; preds = %shadow.root.barrier.done.174
  call void @js_write_barrier_root_nanbox(i64 %r855) #9
  br label %shadow.root.barrier.done.176

shadow.root.barrier.done.176:                     ; preds = %shadow.root.barrier.175, %shadow.root.barrier.done.174
  %r858 = or i64 %r854356, 9222527611924643840
  %r859 = bitcast i64 %r858 to double
  %r860.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35.relocated to i64
  %r860 = call i64 asm "", "=r,0"(i64 %r860.rs4i) #9
  %r861 = bitcast i64 %r860 to double
  %r862 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r863 = icmp eq i8 %r862, 0
  %r864 = inttoptr i64 %r854356 to ptr
  %r865 = getelementptr i8, ptr %r864, i64 -6
  %r866 = load i16, ptr %r865, align 2
  %r867 = and i16 %r866, 4096
  %r868 = icmp ne i16 %r867, 0
  %r869 = and i1 %r863, %r868
  br i1 %r869, label %ctor_prologue.fast.177, label %ctor_prologue.slow.178

ctor_prologue.fast.177:                           ; preds = %shadow.root.barrier.done.176
  %r870 = inttoptr i64 %r854356 to ptr
  %r871 = getelementptr i8, ptr %r870, i64 16
  %r872 = bitcast double %r859 to i64
  %r873 = getelementptr double, ptr %r871, i64 0
  store double %r861, ptr %r873, align 8
  %r874 = ptrtoint ptr %r873 to i64
  %r875 = bitcast double %r861 to i64
  %r876 = lshr i64 %r875, 48
  %r877 = icmp eq i64 %r876, 0
  %r878 = icmp uge i64 %r875, 4096
  %r879 = and i1 %r877, %r878
  %r880 = icmp eq i64 %r876, 32765
  %r881 = icmp eq i64 %r876, 32767
  %r882 = icmp eq i64 %r876, 32762
  %r883 = or i1 %r880, %r881
  %r884 = or i1 %r883, %r882
  %r885 = or i1 %r884, %r879
  br i1 %r885, label %ctor_prologue.barrier.maybe.180, label %ctor_prologue.barrier.done.182

ctor_prologue.slow.178:                           ; preds = %shadow.root.barrier.done.176
  %statepoint_token357 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77_constructor, i32 2, i32 0, double %r859, double %r861, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s36) ]
  %r894358 = call double @llvm.experimental.gc.result.f64(token %statepoint_token357)
  %rs4gc.s36.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token357, i32 0, i32 0) ; (%rs4gc.s36, %rs4gc.s36)
  br label %ctor_prologue.merge.179

ctor_prologue.merge.179:                          ; preds = %ctor_prologue.barrier.done.182, %ctor_prologue.slow.178
  %.0435 = phi ptr addrspace(1) [ %rs4gc.s36, %ctor_prologue.barrier.done.182 ], [ %rs4gc.s36.relocated, %ctor_prologue.slow.178 ]
  %r895 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.182 ], [ %r894358, %ctor_prologue.slow.178 ]
  %r896.rs4i = ptrtoint ptr addrspace(1) %.0435 to i64
  %r896 = call i64 asm "", "=r,0"(i64 %r896.rs4i) #9
  %r897 = or i64 %r896, 9222527611924643840
  %r898 = bitcast i64 %r897 to double
  %r899 = bitcast double %r895 to i64
  %r900 = icmp eq i64 %r899, 9222246136947933185
  br i1 %r900, label %ctor_ret.merge.184, label %ctor_ret.override.183

ctor_prologue.barrier.maybe.180:                  ; preds = %ctor_prologue.fast.177
  %r886 = sub i64 %r854356, 7
  %r887 = inttoptr i64 %r886 to ptr
  %r888 = load i8, ptr %r887, align 1
  %r889 = and i8 %r888, 32
  %r890 = icmp ne i8 %r889, 0
  %r891 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r892 = icmp ne i32 %r891, 0
  %r893 = or i1 %r890, %r892
  br i1 %r893, label %ctor_prologue.barrier.181, label %ctor_prologue.barrier.done.182

ctor_prologue.barrier.181:                        ; preds = %ctor_prologue.barrier.maybe.180
  call void @js_write_barrier_slot_validated_parent(i64 %r854356, i64 %r874, i64 %r875) #9
  br label %ctor_prologue.barrier.done.182

ctor_prologue.barrier.done.182:                   ; preds = %ctor_prologue.barrier.181, %ctor_prologue.barrier.maybe.180, %ctor_prologue.fast.177
  br label %ctor_prologue.merge.179

ctor_ret.override.183:                            ; preds = %ctor_prologue.merge.179
  %statepoint_token359 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r898, double %r895, i32 0, i32 0, i32 0)
  %r901360 = call double @llvm.experimental.gc.result.f64(token %statepoint_token359)
  br label %ctor_ret.merge.184

ctor_ret.merge.184:                               ; preds = %ctor_ret.override.183, %ctor_prologue.merge.179
  %r902 = phi double [ %r898, %ctor_prologue.merge.179 ], [ %r901360, %ctor_ret.override.183 ]
  %statepoint_token361 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr, i32)) @js_closure_alloc, i32 2, i32 0, ptr @perry_closure_test_json_primitive_tojson_keys_ts__11, i32 0, i32 0, i32 0)
  %r903362 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token361)
  %r904 = or i64 %r903362, 9222527611924643840
  %r905 = bitcast i64 %r904 to double
  %statepoint_token363 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r902, double %r905, double 0x7FFC000000000002, i32 0, i32 0)
  %r906364 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token363)
  %r907 = bitcast i64 %r906364 to double
  %rs4gc.s37 = inttoptr i64 %r906364 to ptr addrspace(1)
  %r908.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s37 to i64
  %r908 = call i64 asm "", "=r,0"(i64 %r908.rs4i) #9
  %r909 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r910 = icmp ne i32 %r909, 0
  br i1 %r910, label %shadow.root.barrier.185, label %shadow.root.barrier.done.186

shadow.root.barrier.185:                          ; preds = %ctor_ret.merge.184
  call void @js_write_barrier_root_nanbox(i64 %r908) #9
  br label %shadow.root.barrier.done.186

shadow.root.barrier.done.186:                     ; preds = %shadow.root.barrier.185, %ctor_ret.merge.184
  %statepoint_token365 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s37) ]
  %r911366 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token365)
  %rs4gc.s37.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token365, i32 0, i32 0) ; (%rs4gc.s37, %rs4gc.s37)
  %rs4gc.s38 = inttoptr i64 %r911366 to ptr addrspace(1)
  %r912.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s38 to i64
  %r912 = call i64 asm "", "=r,0"(i64 %r912.rs4i) #9
  %r913 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r914 = icmp ne i32 %r913, 0
  br i1 %r914, label %shadow.root.barrier.187, label %shadow.root.barrier.done.188

shadow.root.barrier.187:                          ; preds = %shadow.root.barrier.done.186
  call void @js_write_barrier_root_nanbox(i64 %r912) #9
  br label %shadow.root.barrier.done.188

shadow.root.barrier.done.188:                     ; preds = %shadow.root.barrier.187, %shadow.root.barrier.done.186
  %r915.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s37.relocated to i64
  %r915 = call i64 asm "", "=r,0"(i64 %r915.rs4i) #9
  %r916 = bitcast i64 %r915 to double
  %r917.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s38 to i64
  %r917 = call i64 asm "", "=r,0"(i64 %r917.rs4i) #9
  %statepoint_token367 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r917, double %r916, i32 0, i32 0)
  %r918368 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token367)
  %rs4gc.s39 = inttoptr i64 %r918368 to ptr addrspace(1)
  %r919.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s39 to i64
  %r919 = call i64 asm "", "=r,0"(i64 %r919.rs4i) #9
  %r920 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r921 = icmp ne i32 %r920, 0
  br i1 %r921, label %shadow.root.barrier.189, label %shadow.root.barrier.done.190

shadow.root.barrier.189:                          ; preds = %shadow.root.barrier.done.188
  call void @js_write_barrier_root_nanbox(i64 %r919) #9
  br label %shadow.root.barrier.done.190

shadow.root.barrier.done.190:                     ; preds = %shadow.root.barrier.189, %shadow.root.barrier.done.188
  %r922.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s39 to i64
  %r922 = call i64 asm "", "=r,0"(i64 %r922.rs4i) #9
  %statepoint_token369 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r922, i32 0, i32 0)
  %statepoint_token370 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token371 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token372 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token373 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token374 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.191

event_loop.header.191:                            ; preds = %event_loop.body_wait.196, %event_loop.body_check.195, %shadow.root.barrier.done.190
  %statepoint_token375 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r927376 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token375)
  %r928 = icmp ne i32 %r927376, 0
  br i1 %r928, label %event_loop.host_return.193, label %event_loop.check_pending.192

event_loop.check_pending.192:                     ; preds = %event_loop.header.191
  %statepoint_token377 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r929378 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token377)
  %statepoint_token379 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r930380 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token379)
  %statepoint_token381 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r931382 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token381)
  %statepoint_token383 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r932384 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token383)
  %statepoint_token385 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r933386 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token385)
  %statepoint_token387 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r934388 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token387)
  %r935 = or i32 %r929378, %r930380
  %r936 = or i32 %r931382, %r932384
  %r937 = or i32 %r936, %r933386
  %r938 = or i32 %r935, %r937
  %r939 = or i32 %r938, 0
  %r940 = or i32 %r939, %r934388
  %r941 = icmp ne i32 %r940, 0
  br i1 %r941, label %event_loop.body.194, label %event_loop.exit.197

event_loop.host_return.193:                       ; preds = %event_loop.header.191
  call void @js_typed_feedback_maybe_dump_trace() #9
  ret i32 0

event_loop.body.194:                              ; preds = %event_loop.check_pending.192
  %statepoint_token389 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token390 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.195

event_loop.body_check.195:                        ; preds = %event_loop.body.194
  %statepoint_token391 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r943392 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token391)
  %statepoint_token393 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r944394 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token393)
  %statepoint_token395 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r945396 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token395)
  %statepoint_token397 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r946398 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token397)
  %statepoint_token399 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r947400 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token399)
  %statepoint_token401 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r948402 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token401)
  %r949 = or i32 %r943392, %r944394
  %r950 = or i32 %r945396, %r946398
  %r951 = or i32 %r950, %r947400
  %r952 = or i32 %r949, %r951
  %r953 = or i32 %r952, 0
  %r954 = or i32 %r953, %r948402
  %r955 = icmp ne i32 %r954, 0
  br i1 %r955, label %event_loop.body_wait.196, label %event_loop.header.191

event_loop.body_wait.196:                         ; preds = %event_loop.body_check.195
  %statepoint_token403 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.191

event_loop.exit.197:                              ; preds = %event_loop.check_pending.192
  %statepoint_token404 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token405 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token406 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token407 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token408 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token409 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token410 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token411 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token412 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r958413 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token412)
  call void @js_typed_feedback_maybe_dump_trace() #9
  ret i32 %r958413
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_primitive_tojson_keys_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.0.bytes, i32 1)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @test_json_primitive_tojson_keys_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.1.bytes, i32 4)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @test_json_primitive_tojson_keys_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.2.bytes, i32 9)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @test_json_primitive_tojson_keys_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.3.bytes, i32 5)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @test_json_primitive_tojson_keys_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.4.bytes, i32 4)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @test_json_primitive_tojson_keys_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.5.bytes, i32 6)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @test_json_primitive_tojson_keys_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.6.bytes, i32 6)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @test_json_primitive_tojson_keys_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.7.bytes, i32 5)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @test_json_primitive_tojson_keys_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.7.handle to i64))
  %r25 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.8.bytes, i32 6)
  %r26 = call double @js_nanbox_string(i64 %r25)
  store double %r26, ptr @test_json_primitive_tojson_keys_ts_.str.8.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.8.handle to i64))
  %r28 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.9.bytes, i32 5)
  %r29 = call double @js_nanbox_string(i64 %r28)
  store double %r29, ptr @test_json_primitive_tojson_keys_ts_.str.9.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.9.handle to i64))
  %r31 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.10.bytes, i32 4)
  %r32 = call double @js_nanbox_string(i64 %r31)
  store double %r32, ptr @test_json_primitive_tojson_keys_ts_.str.10.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.10.handle to i64))
  %r34 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.11.bytes, i32 6)
  %r35 = call double @js_nanbox_string(i64 %r34)
  store double %r35, ptr @test_json_primitive_tojson_keys_ts_.str.11.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.11.handle to i64))
  %r37 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.12.bytes, i32 4)
  %r38 = call double @js_nanbox_string(i64 %r37)
  store double %r38, ptr @test_json_primitive_tojson_keys_ts_.str.12.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.12.handle to i64))
  %r40 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.13.bytes, i32 6)
  %r41 = call double @js_nanbox_string(i64 %r40)
  store double %r41, ptr @test_json_primitive_tojson_keys_ts_.str.13.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.13.handle to i64))
  %r43 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.14.bytes, i32 3)
  %r44 = call double @js_nanbox_string(i64 %r43)
  store double %r44, ptr @test_json_primitive_tojson_keys_ts_.str.14.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.14.handle to i64))
  %r46 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.15.bytes, i32 5)
  %r47 = call double @js_nanbox_string(i64 %r46)
  store double %r47, ptr @test_json_primitive_tojson_keys_ts_.str.15.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.15.handle to i64))
  %r49 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.16.bytes, i32 1)
  %r50 = call double @js_nanbox_string(i64 %r49)
  store double %r50, ptr @test_json_primitive_tojson_keys_ts_.str.16.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.16.handle to i64))
  %r52 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.17.bytes, i32 5)
  %r53 = call double @js_nanbox_string(i64 %r52)
  store double %r53, ptr @test_json_primitive_tojson_keys_ts_.str.17.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.17.handle to i64))
  %r55 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.18.bytes, i32 6)
  %r56 = call double @js_nanbox_string(i64 %r55)
  store double %r56, ptr @test_json_primitive_tojson_keys_ts_.str.18.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.18.handle to i64))
  %r58 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.19.bytes, i32 9)
  %r59 = call double @js_nanbox_string(i64 %r58)
  store double %r59, ptr @test_json_primitive_tojson_keys_ts_.str.19.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.19.handle to i64))
  %r61 = call i64 @js_string_from_bytes(ptr @test_json_primitive_tojson_keys_ts_.str.20.bytes, i32 4)
  %r62 = call double @js_nanbox_string(i64 %r61)
  store double %r62, ptr @test_json_primitive_tojson_keys_ts_.str.20.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts_.str.20.handle to i64))
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__identity, ptr @test_json_primitive_tojson_keys_ts_.str.1, i32 8)
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__makeHook, ptr @test_json_primitive_tojson_keys_ts_.str.2, i32 8)
  call void @js_register_function_name_static(ptr @perry_fn_test_json_primitive_tojson_keys_ts__identity, ptr @test_json_primitive_tojson_keys_ts_.str.1, i32 8)
  call void @js_register_function_name_static(ptr @perry_fn_test_json_primitive_tojson_keys_ts__makeHook, ptr @test_json_primitive_tojson_keys_ts_.str.2, i32 8)
  call void @js_register_function_name_static(ptr @test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7_constructor, ptr @test_json_primitive_tojson_keys_ts_.str.3, i32 32)
  call void @js_register_function_name_static(ptr @test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599_constructor, ptr @test_json_primitive_tojson_keys_ts_.str.4, i32 32)
  call void @js_register_function_name_static(ptr @test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b_constructor, ptr @test_json_primitive_tojson_keys_ts_.str.5, i32 32)
  call void @js_register_function_name_static(ptr @test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043_constructor, ptr @test_json_primitive_tojson_keys_ts_.str.6, i32 32)
  call void @js_register_function_name_static(ptr @test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b_constructor, ptr @test_json_primitive_tojson_keys_ts_.str.7, i32 32)
  call void @js_register_function_name_static(ptr @test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77_constructor, ptr @test_json_primitive_tojson_keys_ts_.str.8, i32 32)
  call void @js_register_function_name_static(ptr @perry_closure_test_json_primitive_tojson_keys_ts__2, ptr @test_json_primitive_tojson_keys_ts_.str.9, i32 6)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__identity, ptr @test_json_primitive_tojson_keys_ts_.str.10, i32 65, i32 0)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__makeHook, ptr @test_json_primitive_tojson_keys_ts_.str.11, i32 126, i32 0)
  call void @js_register_function_source_static(ptr @perry_closure_test_json_primitive_tojson_keys_ts__2, ptr @test_json_primitive_tojson_keys_ts_.str.12, i32 68, i32 0)
  call void @js_register_function_source_static(ptr @perry_closure_test_json_primitive_tojson_keys_ts__6, ptr @test_json_primitive_tojson_keys_ts_.str.13, i32 243, i32 0)
  call void @js_register_function_source_static(ptr @perry_closure_test_json_primitive_tojson_keys_ts__8, ptr @test_json_primitive_tojson_keys_ts_.str.14, i32 54, i32 0)
  call void @js_register_function_source_static(ptr @perry_closure_test_json_primitive_tojson_keys_ts__11, ptr @test_json_primitive_tojson_keys_ts_.str.15, i32 84, i32 0)
  %r64 = call i64 @js_build_class_keys_array(i32 1, i32 1, ptr @perry_class_keys_packed_test_json_primitive_tojson_keys_ts__0, i32 7)
  store i64 %r64, ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7, align 8
  call void @js_write_barrier_root_heap_word(i64 %r64)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7 to i64))
  %r66 = call i32 @js_gc_typed_shape_id_for_keys(i32 1, i64 %r64, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7, i32 1)
  store i32 %r66, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7, align 4
  %r67 = zext i32 %r66 to i64
  %r68 = shl nuw i64 %r67, 32
  %r69 = or i64 %r68, 1
  %r70 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r69, i32 1
  store <2 x i64> %r70, ptr @perry_class_header_image_test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7, align 8
  %r71 = call i64 @js_build_class_keys_array(i32 2, i32 2, ptr @perry_class_keys_packed_test_json_primitive_tojson_keys_ts__1, i32 13)
  store i64 %r71, ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599, align 8
  call void @js_write_barrier_root_heap_word(i64 %r71)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599 to i64))
  %r73 = call i32 @js_gc_typed_shape_id_for_keys(i32 2, i64 %r71, i32 2, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599, i32 1)
  store i32 %r73, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599, align 4
  %r74 = zext i32 %r73 to i64
  %r75 = shl nuw i64 %r74, 32
  %r76 = or i64 %r75, 2
  %r77 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r76, i32 1
  store <2 x i64> %r77, ptr @perry_class_header_image_test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599, align 8
  %r78 = call i64 @js_build_class_keys_array(i32 3, i32 6, ptr @perry_class_keys_packed_test_json_primitive_tojson_keys_ts__2, i32 35)
  store i64 %r78, ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b, align 8
  call void @js_write_barrier_root_heap_word(i64 %r78)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b to i64))
  %r80 = call i32 @js_gc_typed_shape_id_for_keys(i32 3, i64 %r78, i32 6, ptr @perry_typed_shape_raw_f64_mask_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b, i32 1, ptr @perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b, i32 1)
  store i32 %r80, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b, align 4
  %r81 = zext i32 %r80 to i64
  %r82 = shl nuw i64 %r81, 32
  %r83 = or i64 %r82, 3
  %r84 = insertelement <2 x i64> <i64 311653564930, i64 0>, i64 %r83, i32 1
  store <2 x i64> %r84, ptr @perry_class_header_image_test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b, align 8
  %r85 = call i64 @js_build_class_keys_array(i32 4, i32 2, ptr @perry_class_keys_packed_test_json_primitive_tojson_keys_ts__3, i32 14)
  store i64 %r85, ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043, align 8
  call void @js_write_barrier_root_heap_word(i64 %r85)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043 to i64))
  %r87 = call i32 @js_gc_typed_shape_id_for_keys(i32 4, i64 %r85, i32 2, ptr @perry_typed_shape_raw_f64_mask_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043, i32 1, ptr @perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043, i32 1)
  store i32 %r87, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043, align 4
  %r88 = zext i32 %r87 to i64
  %r89 = shl nuw i64 %r88, 32
  %r90 = or i64 %r89, 4
  %r91 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r90, i32 1
  store <2 x i64> %r91, ptr @perry_class_header_image_test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043, align 8
  %r92 = call i64 @js_build_class_keys_array(i32 5, i32 3, ptr @perry_class_keys_packed_test_json_primitive_tojson_keys_ts__4, i32 17)
  store i64 %r92, ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b, align 8
  call void @js_write_barrier_root_heap_word(i64 %r92)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b to i64))
  %r94 = call i32 @js_gc_typed_shape_id_for_keys(i32 5, i64 %r92, i32 3, ptr @perry_typed_shape_raw_f64_mask_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b, i32 1, ptr @perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b, i32 1)
  store i32 %r94, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b, align 4
  %r95 = zext i32 %r94 to i64
  %r96 = shl nuw i64 %r95, 32
  %r97 = or i64 %r96, 5
  %r98 = insertelement <2 x i64> <i64 208574349826, i64 0>, i64 %r97, i32 1
  store <2 x i64> %r98, ptr @perry_class_header_image_test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b, align 8
  %r99 = call i64 @js_build_class_keys_array(i32 6, i32 1, ptr @perry_class_keys_packed_test_json_primitive_tojson_keys_ts__5, i32 4)
  store i64 %r99, ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77, align 8
  call void @js_write_barrier_root_heap_word(i64 %r99)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77 to i64))
  %r101 = call i32 @js_gc_typed_shape_id_for_keys(i32 6, i64 %r99, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77, i32 1)
  store i32 %r101, ptr @perry_class_shape_id_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77, align 4
  %r102 = zext i32 %r101 to i64
  %r103 = shl nuw i64 %r102, 32
  %r104 = or i64 %r103, 6
  %r105 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r104, i32 1
  store <2 x i64> %r105, ptr @perry_class_header_image_test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77, align 8
  call void @js_register_class_constructor(i64 1, i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts____AnonShape_d4a003cc10c06cd7_constructor to i64), i64 1, i64 0)
  call void @js_register_class_constructor(i64 2, i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts____AnonShape_678f61a8283ff599_constructor to i64), i64 2, i64 0)
  call void @js_register_class_constructor(i64 3, i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts____AnonShape_79851f090ba2d05b_constructor to i64), i64 6, i64 0)
  call void @js_register_class_constructor(i64 4, i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts____AnonShape_b3e89da2b61a9043_constructor to i64), i64 2, i64 0)
  call void @js_register_class_constructor(i64 5, i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts____AnonShape_031f75f7a258657b_constructor to i64), i64 3, i64 0)
  call void @js_register_class_constructor(i64 6, i64 ptrtoint (ptr @test_json_primitive_tojson_keys_ts____AnonShape_c95d02397d239d77_constructor to i64), i64 1, i64 0)
  call void @js_register_class_id(i32 1)
  call void @js_register_class_id(i32 2)
  call void @js_register_class_id(i32 3)
  call void @js_register_class_id(i32 4)
  call void @js_register_class_id(i32 5)
  call void @js_register_class_id(i32 6)
  call void @js_register_anon_shape_class_id(i32 1)
  call void @js_register_anon_shape_class_id(i32 2)
  call void @js_register_anon_shape_class_id(i32 3)
  call void @js_register_anon_shape_class_id(i32 4)
  call void @js_register_anon_shape_class_id(i32 5)
  call void @js_register_anon_shape_class_id(i32 6)
  call void @js_register_class_length(i32 1, i32 1)
  call void @js_register_class_length(i32 2, i32 2)
  call void @js_register_class_length(i32 3, i32 6)
  call void @js_register_class_length(i32 4, i32 2)
  call void @js_register_class_length(i32 5, i32 3)
  call void @js_register_class_length(i32 6, i32 1)
  call void @js_register_closure_arity(ptr @perry_closure_test_json_primitive_tojson_keys_ts__2, i32 1)
  call void @js_register_closure_arity(ptr @perry_closure_test_json_primitive_tojson_keys_ts__6, i32 2)
  call void @js_register_closure_arity(ptr @perry_closure_test_json_primitive_tojson_keys_ts__8, i32 1)
  call void @js_register_closure_arity(ptr @perry_closure_test_json_primitive_tojson_keys_ts__11, i32 2)
  call void @js_register_closure_length(ptr @perry_closure_test_json_primitive_tojson_keys_ts__2, i32 1)
  call void @js_register_closure_length(ptr @perry_closure_test_json_primitive_tojson_keys_ts__6, i32 2)
  call void @js_register_closure_length(ptr @perry_closure_test_json_primitive_tojson_keys_ts__8, i32 1)
  call void @js_register_closure_length(ptr @perry_closure_test_json_primitive_tojson_keys_ts__11, i32 2)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__identity, i32 2)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__makeHook, i32 1)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__identity, i32 2)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__makeHook, i32 1)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__identity)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_test_json_primitive_tojson_keys_ts__makeHook)
  call void @js_register_closure_strict_function(ptr @perry_closure_test_json_primitive_tojson_keys_ts__11)
  call void @js_register_closure_strict_function(ptr @perry_closure_test_json_primitive_tojson_keys_ts__2)
  call void @js_register_closure_strict_function(ptr @perry_closure_test_json_primitive_tojson_keys_ts__6)
  call void @js_register_closure_strict_function(ptr @perry_closure_test_json_primitive_tojson_keys_ts__8)
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_primitive_tojson_keys_ts() #6 {
entry.0:
  call void @__perry_init_strings_test_json_primitive_tojson_keys_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { inlinehint optsize "frame-pointer"="non-leaf" }
attributes #8 = { noinline optsize "frame-pointer"="non-leaf" }
attributes #9 = { "gc-leaf-function" }
