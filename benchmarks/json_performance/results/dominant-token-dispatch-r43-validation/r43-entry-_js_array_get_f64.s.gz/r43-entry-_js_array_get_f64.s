
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/dominant-token-dispatch-r43/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007c2a90 <_js_array_get_f64>:
1007c2a90:     	sub	sp, sp, #0x70
1007c2a94:     	stp	x26, x25, [sp, #0x20]
1007c2a98:     	stp	x24, x23, [sp, #0x30]
1007c2a9c:     	stp	x22, x21, [sp, #0x40]
1007c2aa0:     	stp	x20, x19, [sp, #0x50]
1007c2aa4:     	stp	x29, x30, [sp, #0x60]
1007c2aa8:     	add	x29, sp, #0x60
1007c2aac:     	mov	x19, x1
1007c2ab0:     	mov	x22, x0
1007c2ab4:     	lsr	x25, x0, #51
1007c2ab8:     	mov	x20, x0
1007c2abc:     	cmp	x25, #0xfff
1007c2ac0:     	b.lo	0x1007c2adc <_js_array_get_f64+0x4c>
1007c2ac4:     	mov	w8, #0x7ffc             ; =32764
1007c2ac8:     	cmp	x8, x22, lsr #48
1007c2acc:     	b.ne	0x1007c2ad8 <_js_array_get_f64+0x48>
1007c2ad0:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007c2ad4:     	b	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c2ad8:     	and	x20, x22, #0xffffffffffff
1007c2adc:     	lsr	x8, x20, #3
1007c2ae0:     	cmp	x8, #0x200
1007c2ae4:     	b.ls	0x1007c2b1c <_js_array_get_f64+0x8c>
1007c2ae8:     	ldurb	w8, [x20, #-0x8]
1007c2aec:     	cmp	w8, #0x9
1007c2af0:     	b.ne	0x1007c2b1c <_js_array_get_f64+0x8c>
1007c2af4:     	ldr	w8, [x20, #0x4]
1007c2af8:     	mov	w9, #0x5841             ; =22593
1007c2afc:     	movk	w9, #0x4c5a, lsl #16
1007c2b00:     	cmp	w8, w9
1007c2b04:     	b.ne	0x1007c2b1c <_js_array_get_f64+0x8c>
1007c2b08:     	mov	x0, x20
1007c2b0c:     	mov	x1, x19
1007c2b10:     	bl	0x10068b804 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007c2b14:     	fmov	d0, x0
1007c2b18:     	b	0x1007c318c <_js_array_get_f64+0x6fc>
1007c2b1c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c2b20:     	b.lo	0x1007c2bd0 <_js_array_get_f64+0x140>
1007c2b24:     	tst	x20, #0xffff800000000000
1007c2b28:     	mov	w8, #0x1000             ; =4096
1007c2b2c:     	ccmp	x20, x8, #0x0, eq
1007c2b30:     	b.lo	0x1007c2bd0 <_js_array_get_f64+0x140>
1007c2b34:     	ldurb	w24, [x20, #-0x8]
1007c2b38:     	ldurh	w23, [x20, #-0x6]
1007c2b3c:     	cmp	w24, #0xa
1007c2b40:     	b.gt	0x1007c2ce8 <_js_array_get_f64+0x258>
1007c2b44:     	cmp	w24, #0x2
1007c2b48:     	b.eq	0x1007c2d70 <_js_array_get_f64+0x2e0>
1007c2b4c:     	cmp	w24, #0x8
1007c2b50:     	b.ne	0x1007c2bd8 <_js_array_get_f64+0x148>
1007c2b54:     	mov	x0, x20
1007c2b58:     	bl	0x100307b68 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007c2b5c:     	cbz	w0, 0x1007c2e00 <_js_array_get_f64+0x370>
1007c2b60:     	mov	x22, #0x1               ; =1
1007c2b64:     	movk	x22, #0x7ffc, lsl #48
1007c2b68:     	lsr	x8, x20, #51
1007c2b6c:     	cmp	x8, #0xfff
1007c2b70:     	b.lo	0x1007c2b84 <_js_array_get_f64+0xf4>
1007c2b74:     	mov	w8, #0x7ffc             ; =32764
1007c2b78:     	cmp	x8, x20, lsr #48
1007c2b7c:     	b.eq	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c2b80:     	and	x20, x20, #0xffffffffffff
1007c2b84:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c2b88:     	b.lo	0x1007c2ba8 <_js_array_get_f64+0x118>
1007c2b8c:     	tst	x20, #0xffff800000000000
1007c2b90:     	mov	w8, #0x1000             ; =4096
1007c2b94:     	ccmp	x20, x8, #0x0, eq
1007c2b98:     	b.lo	0x1007c2ba8 <_js_array_get_f64+0x118>
1007c2b9c:     	ldurb	w8, [x20, #-0x8]
1007c2ba0:     	cmp	w8, #0x2
1007c2ba4:     	b.eq	0x1007c3474 <_js_array_get_f64+0x9e4>
1007c2ba8:     	cbz	x20, 0x1007c3188 <_js_array_get_f64+0x6f8>
1007c2bac:     	mov	x0, x20
1007c2bb0:     	mov	x1, x19
1007c2bb4:     	bl	0x100307d18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007c2bb8:     	cmp	w0, #0x1
1007c2bbc:     	b.ne	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c2bc0:     	ldr	x8, [x20, #0x8]
1007c2bc4:     	ubfiz	x9, x1, #4, #32
1007c2bc8:     	ldr	x22, [x8, x9]
1007c2bcc:     	b	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c2bd0:     	mov	w23, #0x0               ; =0
1007c2bd4:     	mov	w24, #0x0               ; =0
1007c2bd8:     	mov	x21, x22
1007c2bdc:     	cmp	x25, #0xfff
1007c2be0:     	b.lo	0x1007c2bf8 <_js_array_get_f64+0x168>
1007c2be4:     	mov	w8, #0x7ffc             ; =32764
1007c2be8:     	cmp	x8, x22, lsr #48
1007c2bec:     	b.eq	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2bf0:     	ands	x21, x22, #0xffffffffffff
1007c2bf4:     	b.eq	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2bf8:     	and	x8, x21, #0xfffffffffff00000
1007c2bfc:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007c2c00:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007c2c04:     	cmp	x9, x10
1007c2c08:     	ccmp	x8, #0x0, #0x4, lo
1007c2c0c:     	b.eq	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2c10:     	tst	x21, #0x3
1007c2c14:     	ccmp	x21, #0x7, #0x0, eq
1007c2c18:     	b.ls	0x1007c2ec8 <_js_array_get_f64+0x438>
1007c2c1c:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2c20:     	ldr	x8, [x8, #0x48]
1007c2c24:     	cmn	x8, #0x1
1007c2c28:     	b.eq	0x1007c2e18 <_js_array_get_f64+0x388>
1007c2c2c:     	mrs	x9, TPIDRRO_EL0
1007c2c30:     	and	x9, x9, #0xfffffffffffffff8
1007c2c34:     	ldr	x0, [x9, x8, lsl #3]
1007c2c38:     	cbz	x0, 0x1007c2e18 <_js_array_get_f64+0x388>
1007c2c3c:     	lsr	x1, x21, #20
1007c2c40:     	ldr	x8, [x0, #0x10]
1007c2c44:     	ldrb	w9, [x8]
1007c2c48:     	cmp	w9, #0x2
1007c2c4c:     	b.ne	0x1007c2e30 <_js_array_get_f64+0x3a0>
1007c2c50:     	ldrb	w9, [x8, #0x88]
1007c2c54:     	tbz	w9, #0x0, 0x1007c2c74 <_js_array_get_f64+0x1e4>
1007c2c58:     	ldr	x9, [x8, #0x80]
1007c2c5c:     	cmp	x9, x1
1007c2c60:     	b.ne	0x1007c2c74 <_js_array_get_f64+0x1e4>
1007c2c64:     	ldp	x9, x10, [x8, #0x60]
1007c2c68:     	cmp	x9, x21
1007c2c6c:     	ccmp	x10, x21, #0x0, ls
1007c2c70:     	b.hi	0x1007c2e10 <_js_array_get_f64+0x380>
1007c2c74:     	ldrb	w9, [x8, #0xb8]
1007c2c78:     	cbz	w9, 0x1007c2c98 <_js_array_get_f64+0x208>
1007c2c7c:     	ldr	x9, [x8, #0xb0]
1007c2c80:     	cmp	x9, x1
1007c2c84:     	b.ne	0x1007c2c98 <_js_array_get_f64+0x208>
1007c2c88:     	ldp	x9, x10, [x8, #0x90]
1007c2c8c:     	cmp	x9, x21
1007c2c90:     	ccmp	x10, x21, #0x0, ls
1007c2c94:     	b.hi	0x1007c32d8 <_js_array_get_f64+0x848>
1007c2c98:     	ldrb	w9, [x8, #0xe8]
1007c2c9c:     	cbz	w9, 0x1007c2cbc <_js_array_get_f64+0x22c>
1007c2ca0:     	ldr	x9, [x8, #0xe0]
1007c2ca4:     	cmp	x9, x1
1007c2ca8:     	b.ne	0x1007c2cbc <_js_array_get_f64+0x22c>
1007c2cac:     	ldp	x9, x10, [x8, #0xc0]
1007c2cb0:     	cmp	x9, x21
1007c2cb4:     	ccmp	x10, x21, #0x0, ls
1007c2cb8:     	b.hi	0x1007c33c0 <_js_array_get_f64+0x930>
1007c2cbc:     	ldrb	w9, [x8, #0x118]
1007c2cc0:     	cbz	w9, 0x1007c2e90 <_js_array_get_f64+0x400>
1007c2cc4:     	ldr	x9, [x8, #0x110]
1007c2cc8:     	cmp	x9, x1
1007c2ccc:     	b.ne	0x1007c2e90 <_js_array_get_f64+0x400>
1007c2cd0:     	ldp	x9, x10, [x8, #0xf0]
1007c2cd4:     	cmp	x9, x21
1007c2cd8:     	ccmp	x10, x21, #0x0, ls
1007c2cdc:     	b.ls	0x1007c2e90 <_js_array_get_f64+0x400>
1007c2ce0:     	add	x9, x8, #0xf0
1007c2ce4:     	b	0x1007c33c4 <_js_array_get_f64+0x934>
1007c2ce8:     	cmp	w24, #0xb
1007c2cec:     	b.eq	0x1007c2d88 <_js_array_get_f64+0x2f8>
1007c2cf0:     	cmp	w24, #0xc
1007c2cf4:     	b.ne	0x1007c2bd8 <_js_array_get_f64+0x148>
1007c2cf8:     	mov	x0, x20
1007c2cfc:     	bl	0x10030d8f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007c2d00:     	cbz	w0, 0x1007c2e08 <_js_array_get_f64+0x378>
1007c2d04:     	mov	x22, #0x1               ; =1
1007c2d08:     	movk	x22, #0x7ffc, lsl #48
1007c2d0c:     	lsr	x8, x20, #51
1007c2d10:     	cmp	x8, #0xfff
1007c2d14:     	b.lo	0x1007c2d28 <_js_array_get_f64+0x298>
1007c2d18:     	mov	w8, #0x7ffc             ; =32764
1007c2d1c:     	cmp	x8, x20, lsr #48
1007c2d20:     	b.eq	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c2d24:     	and	x20, x20, #0xffffffffffff
1007c2d28:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c2d2c:     	b.lo	0x1007c2d4c <_js_array_get_f64+0x2bc>
1007c2d30:     	tst	x20, #0xffff800000000000
1007c2d34:     	mov	w8, #0x1000             ; =4096
1007c2d38:     	ccmp	x20, x8, #0x0, eq
1007c2d3c:     	b.lo	0x1007c2d4c <_js_array_get_f64+0x2bc>
1007c2d40:     	ldurb	w8, [x20, #-0x8]
1007c2d44:     	cmp	w8, #0x2
1007c2d48:     	b.eq	0x1007c348c <_js_array_get_f64+0x9fc>
1007c2d4c:     	cbz	x20, 0x1007c3188 <_js_array_get_f64+0x6f8>
1007c2d50:     	mov	x0, x20
1007c2d54:     	mov	x1, x19
1007c2d58:     	bl	0x10030f570 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007c2d5c:     	cmp	w0, #0x1
1007c2d60:     	b.ne	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c2d64:     	ldr	x8, [x20, #0x8]
1007c2d68:     	ldr	x22, [x8, w1, uxtw #3]
1007c2d6c:     	b	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c2d70:     	mov	x0, x22
1007c2d74:     	mov	x1, x19
1007c2d78:     	bl	0x10054b4cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007c2d7c:     	tbnz	w0, #0x0, 0x1007c3184 <_js_array_get_f64+0x6f4>
1007c2d80:     	mov	w24, #0x2               ; =2
1007c2d84:     	b	0x1007c2bd8 <_js_array_get_f64+0x148>
1007c2d88:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2d8c:     	add	x8, x8, #0xec0
1007c2d90:     	ldaprb	w8, [x8]
1007c2d94:     	cbz	w8, 0x1007c2df8 <_js_array_get_f64+0x368>
1007c2d98:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2d9c:     	add	x8, x8, #0x58
1007c2da0:     	ldapr	x8, [x8]
1007c2da4:     	cmp	x20, x8
1007c2da8:     	b.lo	0x1007c2df8 <_js_array_get_f64+0x368>
1007c2dac:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2db0:     	add	x8, x8, #0x60
1007c2db4:     	ldapr	x8, [x8]
1007c2db8:     	cmp	x20, x8
1007c2dbc:     	b.hi	0x1007c2df8 <_js_array_get_f64+0x368>
1007c2dc0:     	mov	x0, x20
1007c2dc4:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2dc8:     	tbz	w0, #0x0, 0x1007c2df8 <_js_array_get_f64+0x368>
1007c2dcc:     	add	x0, sp, #0x8
1007c2dd0:     	mov	x1, x20
1007c2dd4:     	bl	0x1002a746c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007c2dd8:     	ldr	x8, [sp, #0x8]
1007c2ddc:     	cbz	x8, 0x1007c3404 <_js_array_get_f64+0x974>
1007c2de0:     	cmp	x8, #0x1
1007c2de4:     	b.ne	0x1007c3448 <_js_array_get_f64+0x9b8>
1007c2de8:     	ldr	d0, [sp, #0x10]
1007c2dec:     	scvtf	d1, w19
1007c2df0:     	bl	0x100821034 <_js_dyn_index_get>
1007c2df4:     	b	0x1007c3184 <_js_array_get_f64+0x6f4>
1007c2df8:     	mov	w24, #0xb               ; =11
1007c2dfc:     	b	0x1007c2bd8 <_js_array_get_f64+0x148>
1007c2e00:     	mov	w24, #0x8               ; =8
1007c2e04:     	b	0x1007c2bd8 <_js_array_get_f64+0x148>
1007c2e08:     	mov	w24, #0xc               ; =12
1007c2e0c:     	b	0x1007c2bd8 <_js_array_get_f64+0x148>
1007c2e10:     	add	x9, x8, #0x60
1007c2e14:     	b	0x1007c33c4 <_js_array_get_f64+0x934>
1007c2e18:     	bl	0x100b444fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007c2e1c:     	lsr	x1, x21, #20
1007c2e20:     	ldr	x8, [x0, #0x10]
1007c2e24:     	ldrb	w9, [x8]
1007c2e28:     	cmp	w9, #0x2
1007c2e2c:     	b.eq	0x1007c2c50 <_js_array_get_f64+0x1c0>
1007c2e30:     	ldr	x9, [x8, #0x8]
1007c2e34:     	ldr	x10, [x8, #0x28]
1007c2e38:     	sub	x9, x1, x9
1007c2e3c:     	cmp	x9, x10
1007c2e40:     	b.hs	0x1007c2e84 <_js_array_get_f64+0x3f4>
1007c2e44:     	ldr	x10, [x8, #0x20]
1007c2e48:     	mov	w11, #0x28              ; =40
1007c2e4c:     	madd	x9, x9, x11, x10
1007c2e50:     	ldr	x10, [x9]
1007c2e54:     	ldr	x11, [x8, #0x10]
1007c2e58:     	cmp	x10, x11
1007c2e5c:     	b.ne	0x1007c2e90 <_js_array_get_f64+0x400>
1007c2e60:     	ldp	x10, x11, [x9, #0x8]
1007c2e64:     	cmp	x10, x21
1007c2e68:     	ccmp	x11, x21, #0x0, ls
1007c2e6c:     	b.ls	0x1007c2e90 <_js_array_get_f64+0x400>
1007c2e70:     	ldr	x10, [x8, #0x30]
1007c2e74:     	add	x10, x10, #0x1
1007c2e78:     	str	x10, [x8, #0x30]
1007c2e7c:     	add	x8, x9, #0x21
1007c2e80:     	b	0x1007c33d4 <_js_array_get_f64+0x944>
1007c2e84:     	ldr	x9, [x8, #0x58]
1007c2e88:     	add	x9, x9, #0x1
1007c2e8c:     	str	x9, [x8, #0x58]
1007c2e90:     	ldr	x9, [x8, #0x38]
1007c2e94:     	add	x9, x9, #0x1
1007c2e98:     	str	x9, [x8, #0x38]
1007c2e9c:     	mov	x0, x21
1007c2ea0:     	bl	0x100521208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007c2ea4:     	and	w8, w0, #0xff
1007c2ea8:     	cbz	w8, 0x1007c2ec8 <_js_array_get_f64+0x438>
1007c2eac:     	ldurb	w8, [x21, #-0x8]
1007c2eb0:     	ldurb	w9, [x21, #-0x7]
1007c2eb4:     	mov	w10, #0x82              ; =130
1007c2eb8:     	and	w9, w9, w10
1007c2ebc:     	cmp	w9, #0x2
1007c2ec0:     	ccmp	w8, #0x1, #0x0, eq
1007c2ec4:     	b.eq	0x1007c2f98 <_js_array_get_f64+0x508>
1007c2ec8:     	mov	x0, x21
1007c2ecc:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2ed0:     	cbz	x0, 0x1007c2ef8 <_js_array_get_f64+0x468>
1007c2ed4:     	ldrb	w9, [x0]
1007c2ed8:     	cmp	w9, #0x1
1007c2edc:     	b.ne	0x1007c2f14 <_js_array_get_f64+0x484>
1007c2ee0:     	ldrsb	w8, [x0, #0x1]
1007c2ee4:     	tbnz	w8, #0x1f, 0x1007c2fc0 <_js_array_get_f64+0x530>
1007c2ee8:     	ldp	w10, w9, [x21]
1007c2eec:     	cmp	w10, w9
1007c2ef0:     	b.hi	0x1007c304c <_js_array_get_f64+0x5bc>
1007c2ef4:     	b	0x1007c3064 <_js_array_get_f64+0x5d4>
1007c2ef8:     	mov	x25, x0
1007c2efc:     	mov	x0, x21
1007c2f00:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2f04:     	tbz	w0, #0x0, 0x1007c2f50 <_js_array_get_f64+0x4c0>
1007c2f08:     	mov	x0, #0x0                ; =0
1007c2f0c:     	mov	x8, x25
1007c2f10:     	b	0x1007c303c <_js_array_get_f64+0x5ac>
1007c2f14:     	mov	x8, x0
1007c2f18:     	cmp	w9, #0x1
1007c2f1c:     	b.eq	0x1007c303c <_js_array_get_f64+0x5ac>
1007c2f20:     	cmp	w9, #0x9
1007c2f24:     	b.ne	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2f28:     	ldr	w8, [x21, #0x4]
1007c2f2c:     	mov	w9, #0x5841             ; =22593
1007c2f30:     	movk	w9, #0x4c5a, lsl #16
1007c2f34:     	cmp	w8, w9
1007c2f38:     	b.ne	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2f3c:     	mov	x0, x21
1007c2f40:     	bl	0x100378910 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007c2f44:     	cbz	x0, 0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2f48:     	mov	x21, x0
1007c2f4c:     	b	0x1007c3080 <_js_array_get_f64+0x5f0>
1007c2f50:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2f54:     	add	x8, x8, #0xec0
1007c2f58:     	ldaprb	w8, [x8]
1007c2f5c:     	cbz	w8, 0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2f60:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2f64:     	add	x8, x8, #0x58
1007c2f68:     	ldapr	x8, [x8]
1007c2f6c:     	cmp	x8, x21
1007c2f70:     	b.hi	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2f74:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2f78:     	add	x8, x8, #0x60
1007c2f7c:     	ldapr	x8, [x8]
1007c2f80:     	cmp	x8, x21
1007c2f84:     	b.lo	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2f88:     	mov	x0, x21
1007c2f8c:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2f90:     	tbnz	w0, #0x0, 0x1007c2f08 <_js_array_get_f64+0x478>
1007c2f94:     	b	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2f98:     	ldr	w8, [x21]
1007c2f9c:     	mov	w9, #0xe100             ; =57600
1007c2fa0:     	movk	w9, #0x5f5, lsl #16
1007c2fa4:     	orr	w9, w9, #0x1
1007c2fa8:     	cmp	w8, w9
1007c2fac:     	b.hs	0x1007c2ec8 <_js_array_get_f64+0x438>
1007c2fb0:     	ldr	w9, [x21, #0x4]
1007c2fb4:     	cmp	w8, w9
1007c2fb8:     	b.ls	0x1007c3080 <_js_array_get_f64+0x5f0>
1007c2fbc:     	b	0x1007c2ec8 <_js_array_get_f64+0x438>
1007c2fc0:     	mov	x25, x0
1007c2fc4:     	ldr	x21, [x0, #0x8]
1007c2fc8:     	mov	x0, x21
1007c2fcc:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2fd0:     	cbz	x0, 0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2fd4:     	ldrb	w8, [x0]
1007c2fd8:     	cmp	w8, #0x1
1007c2fdc:     	b.ne	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2fe0:     	ldrsb	w8, [x0, #0x1]
1007c2fe4:     	tbz	w8, #0x1f, 0x1007c2ee8 <_js_array_get_f64+0x458>
1007c2fe8:     	mov	w26, #0x1               ; =1
1007c2fec:     	ldr	x21, [x0, #0x8]
1007c2ff0:     	mov	x0, x21
1007c2ff4:     	bl	0x10057d880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2ff8:     	cbz	x0, 0x1007c3174 <_js_array_get_f64+0x6e4>
1007c2ffc:     	ldrb	w8, [x0]
1007c3000:     	cmp	w8, #0x1
1007c3004:     	b.ne	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c3008:     	cmp	w26, #0x3f
1007c300c:     	b.hi	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c3010:     	add	w26, w26, #0x1
1007c3014:     	ldrsb	w8, [x0, #0x1]
1007c3018:     	tbnz	w8, #0x1f, 0x1007c2fec <_js_array_get_f64+0x55c>
1007c301c:     	str	x21, [x25, #0x8]
1007c3020:     	ldrb	w8, [x25, #0x1]
1007c3024:     	orr	w9, w8, #0x80
1007c3028:     	mov	x8, x25
1007c302c:     	strb	w9, [x25, #0x1]
1007c3030:     	ldrb	w9, [x0]
1007c3034:     	cmp	w9, #0x1
1007c3038:     	b.ne	0x1007c2f20 <_js_array_get_f64+0x490>
1007c303c:     	ldp	w10, w9, [x21]
1007c3040:     	cmp	w10, w9
1007c3044:     	b.ls	0x1007c3064 <_js_array_get_f64+0x5d4>
1007c3048:     	cbz	x8, 0x1007c3074 <_js_array_get_f64+0x5e4>
1007c304c:     	ldr	w8, [x0, #0x4]
1007c3050:     	ubfiz	x9, x9, #3, #32
1007c3054:     	add	x9, x9, #0x10
1007c3058:     	cmp	x9, x8
1007c305c:     	b.eq	0x1007c3080 <_js_array_get_f64+0x5f0>
1007c3060:     	b	0x1007c3074 <_js_array_get_f64+0x5e4>
1007c3064:     	mov	w8, #0xe100             ; =57600
1007c3068:     	movk	w8, #0x5f5, lsl #16
1007c306c:     	cmp	w10, w8
1007c3070:     	b.ls	0x1007c3080 <_js_array_get_f64+0x5f0>
1007c3074:     	mov	x0, x21
1007c3078:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c307c:     	tbz	w0, #0x0, 0x1007c3130 <_js_array_get_f64+0x6a0>
1007c3080:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c3084:     	add	x8, x8, #0xec0
1007c3088:     	ldaprb	w8, [x8]
1007c308c:     	cbz	w8, 0x1007c30d4 <_js_array_get_f64+0x644>
1007c3090:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c3094:     	add	x8, x8, #0x58
1007c3098:     	ldapr	x8, [x8]
1007c309c:     	cmp	x21, x8
1007c30a0:     	b.lo	0x1007c30d4 <_js_array_get_f64+0x644>
1007c30a4:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c30a8:     	add	x8, x8, #0x60
1007c30ac:     	ldapr	x8, [x8]
1007c30b0:     	cmp	x21, x8
1007c30b4:     	b.hi	0x1007c30d4 <_js_array_get_f64+0x644>
1007c30b8:     	mov	x0, x21
1007c30bc:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c30c0:     	tbz	w0, #0x0, 0x1007c30d4 <_js_array_get_f64+0x644>
1007c30c4:     	mov	x0, x21
1007c30c8:     	mov	x1, x19
1007c30cc:     	bl	0x100900d48 <_js_typed_array_get>
1007c30d0:     	b	0x1007c3184 <_js_array_get_f64+0x6f4>
1007c30d4:     	mov	x0, x21
1007c30d8:     	bl	0x10058c0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c30dc:     	tbz	w0, #0x0, 0x1007c3104 <_js_array_get_f64+0x674>
1007c30e0:     	mov	x0, x21
1007c30e4:     	mov	x1, x19
1007c30e8:     	bl	0x1005893dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007c30ec:     	and	w8, w1, #0xff
1007c30f0:     	ucvtf	d0, w8
1007c30f4:     	fmov	x8, d0
1007c30f8:     	tst	w0, #0x1
1007c30fc:     	csel	x22, x8, xzr, ne
1007c3100:     	b	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c3104:     	cmp	x21, x20
1007c3108:     	b.eq	0x1007c31b0 <_js_array_get_f64+0x720>
1007c310c:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007c3110:     	b.lo	0x1007c31a8 <_js_array_get_f64+0x718>
1007c3114:     	tst	x21, #0xffff800000000000
1007c3118:     	mov	w8, #0x1000             ; =4096
1007c311c:     	ccmp	x21, x8, #0x0, eq
1007c3120:     	b.lo	0x1007c31a8 <_js_array_get_f64+0x718>
1007c3124:     	ldurb	w24, [x21, #-0x8]
1007c3128:     	ldurh	w23, [x21, #-0x6]
1007c312c:     	b	0x1007c31b0 <_js_array_get_f64+0x720>
1007c3130:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c3134:     	add	x8, x8, #0xec0
1007c3138:     	ldaprb	w8, [x8]
1007c313c:     	cbz	w8, 0x1007c3174 <_js_array_get_f64+0x6e4>
1007c3140:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c3144:     	add	x8, x8, #0x58
1007c3148:     	ldapr	x8, [x8]
1007c314c:     	cmp	x21, x8
1007c3150:     	b.lo	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c3154:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c3158:     	add	x8, x8, #0x60
1007c315c:     	ldapr	x8, [x8]
1007c3160:     	cmp	x21, x8
1007c3164:     	b.hi	0x1007c3174 <_js_array_get_f64+0x6e4>
1007c3168:     	mov	x0, x21
1007c316c:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c3170:     	tbnz	w0, #0x0, 0x1007c3080 <_js_array_get_f64+0x5f0>
1007c3174:     	mov	x0, x22
1007c3178:     	mov	x1, x19
1007c317c:     	bl	0x10054b4cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007c3180:     	tbz	w0, #0x0, 0x1007c3458 <_js_array_get_f64+0x9c8>
1007c3184:     	fmov	x22, d0
1007c3188:     	fmov	d0, x22
1007c318c:     	ldp	x29, x30, [sp, #0x60]
1007c3190:     	ldp	x20, x19, [sp, #0x50]
1007c3194:     	ldp	x22, x21, [sp, #0x40]
1007c3198:     	ldp	x24, x23, [sp, #0x30]
1007c319c:     	ldp	x26, x25, [sp, #0x20]
1007c31a0:     	add	sp, sp, #0x70
1007c31a4:     	ret
1007c31a8:     	mov	w23, #0x0               ; =0
1007c31ac:     	mov	w24, #0x0               ; =0
1007c31b0:     	cmp	w24, #0x1
1007c31b4:     	b.ne	0x1007c3368 <_js_array_get_f64+0x8d8>
1007c31b8:     	tbz	w23, #0xa, 0x1007c3368 <_js_array_get_f64+0x8d8>
1007c31bc:     	adrp	x8, 0x100b69000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data14case_ignorable7OFFSETS+0xfc>
1007c31c0:     	add	x8, x8, #0xf4c
1007c31c4:     	cmp	w19, #0x3e8
1007c31c8:     	b.lo	0x1007c3240 <_js_array_get_f64+0x7b0>
1007c31cc:     	mov	x9, #0x0                ; =0
1007c31d0:     	mov	w11, #0x1759            ; =5977
1007c31d4:     	movk	w11, #0xd1b7, lsl #16
1007c31d8:     	mov	w12, #0x2710            ; =10000
1007c31dc:     	mov	w13, #0x147b            ; =5243
1007c31e0:     	mov	w14, #0x64              ; =100
1007c31e4:     	add	x15, sp, #0x8
1007c31e8:     	mov	w16, #0x967f            ; =38527
1007c31ec:     	movk	w16, #0x98, lsl #16
1007c31f0:     	mov	x10, x19
1007c31f4:     	mov	x17, x10
1007c31f8:     	umull	x10, w10, w11
1007c31fc:     	lsr	x10, x10, #45
1007c3200:     	msub	w0, w10, w12, w17
1007c3204:     	ubfx	w1, w0, #2, #14
1007c3208:     	mul	w1, w1, w13
1007c320c:     	lsr	w1, w1, #17
1007c3210:     	msub	w0, w1, w14, w0
1007c3214:     	add	x2, x15, x9
1007c3218:     	ldrh	w1, [x8, w1, uxtw #1]
1007c321c:     	strh	w1, [x2, #0x6]
1007c3220:     	and	x0, x0, #0xffff
1007c3224:     	ldrh	w0, [x8, x0, lsl #1]
1007c3228:     	strh	w0, [x2, #0x8]
1007c322c:     	sub	x9, x9, #0x4
1007c3230:     	cmp	w17, w16
1007c3234:     	b.hi	0x1007c31f4 <_js_array_get_f64+0x764>
1007c3238:     	add	x9, x9, #0xa
1007c323c:     	b	0x1007c3248 <_js_array_get_f64+0x7b8>
1007c3240:     	mov	w9, #0xa                ; =10
1007c3244:     	mov	x10, x19
1007c3248:     	cmp	w10, #0x9
1007c324c:     	b.ls	0x1007c3280 <_js_array_get_f64+0x7f0>
1007c3250:     	sub	x9, x9, #0x2
1007c3254:     	ubfx	w11, w10, #2, #14
1007c3258:     	mov	w12, #0x147b            ; =5243
1007c325c:     	mul	w11, w11, w12
1007c3260:     	lsr	w11, w11, #17
1007c3264:     	mov	w12, #0x64              ; =100
1007c3268:     	msub	w10, w11, w12, w10
1007c326c:     	and	x10, x10, #0xffff
1007c3270:     	ldrh	w10, [x8, x10, lsl #1]
1007c3274:     	add	x12, sp, #0x8
1007c3278:     	strh	w10, [x12, x9]
1007c327c:     	mov	x10, x11
1007c3280:     	cbz	w19, 0x1007c32b8 <_js_array_get_f64+0x828>
1007c3284:     	cbnz	w10, 0x1007c32b8 <_js_array_get_f64+0x828>
1007c3288:     	cmp	x9, #0xa
1007c328c:     	b.ne	0x1007c32e0 <_js_array_get_f64+0x850>
1007c3290:     	mov	w23, #0x1               ; =1
1007c3294:     	add	x0, sp, #0x8
1007c3298:     	mov	x1, x21
1007c329c:     	mov	w2, #0x1                ; =1
1007c32a0:     	mov	x3, #0x0                ; =0
1007c32a4:     	bl	0x1005b57bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007c32a8:     	ldr	x8, [sp, #0x8]
1007c32ac:     	mov	w20, #0x1               ; =1
1007c32b0:     	cbnz	x8, 0x1007c3330 <_js_array_get_f64+0x8a0>
1007c32b4:     	b	0x1007c3368 <_js_array_get_f64+0x8d8>
1007c32b8:     	sub	x23, x9, #0x1
1007c32bc:     	ubfiz	w10, w10, #1, #4
1007c32c0:     	add	x8, x8, x10
1007c32c4:     	ldrb	w8, [x8, #0x1]
1007c32c8:     	add	x10, sp, #0x8
1007c32cc:     	strb	w8, [x10, x23]
1007c32d0:     	mov	w8, #0xb                ; =11
1007c32d4:     	b	0x1007c32e8 <_js_array_get_f64+0x858>
1007c32d8:     	add	x9, x8, #0x90
1007c32dc:     	b	0x1007c33c4 <_js_array_get_f64+0x934>
1007c32e0:     	mov	w8, #0xa                ; =10
1007c32e4:     	mov	x23, x9
1007c32e8:     	sub	x22, x8, x9
1007c32ec:     	mov	x0, x22
1007c32f0:     	mov	w1, #0x1                ; =1
1007c32f4:     	bl	0x100b64388 <_mi_malloc_aligned>
1007c32f8:     	cbz	x0, 0x1007c34a4 <_js_array_get_f64+0xa14>
1007c32fc:     	mov	x20, x0
1007c3300:     	add	x8, sp, #0x8
1007c3304:     	add	x1, x8, x23
1007c3308:     	mov	x2, x22
1007c330c:     	bl	0x100b66fac <_writev+0x100b66fac>
1007c3310:     	add	x0, sp, #0x8
1007c3314:     	mov	x1, x21
1007c3318:     	mov	x2, x20
1007c331c:     	mov	x3, x22
1007c3320:     	bl	0x1005b57bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007c3324:     	ldr	w8, [sp, #0x8]
1007c3328:     	tbz	w8, #0x0, 0x1007c3360 <_js_array_get_f64+0x8d0>
1007c332c:     	mov	w23, #0x0               ; =0
1007c3330:     	mov	x22, #0x1               ; =1
1007c3334:     	movk	x22, #0x7ffc, lsl #48
1007c3338:     	ldr	x0, [sp, #0x10]
1007c333c:     	cbz	x0, 0x1007c33f4 <_js_array_get_f64+0x964>
1007c3340:     	cbz	x21, 0x1007c33e4 <_js_array_get_f64+0x954>
1007c3344:     	lsr	x8, x21, #52
1007c3348:     	cmp	x8, #0x7fe
1007c334c:     	b.hi	0x1007c33e8 <_js_array_get_f64+0x958>
1007c3350:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007c3354:     	bfxil	x8, x21, #0, #48
1007c3358:     	mov	x21, x8
1007c335c:     	b	0x1007c33e8 <_js_array_get_f64+0x958>
1007c3360:     	mov	x0, x20
1007c3364:     	bl	0x100b64100 <_mi_free>
1007c3368:     	ldr	w8, [x21]
1007c336c:     	cmp	w19, w8
1007c3370:     	b.hs	0x1007c33b0 <_js_array_get_f64+0x920>
1007c3374:     	ldr	w8, [x21, #0x4]
1007c3378:     	cmp	w19, w8
1007c337c:     	b.hs	0x1007c33a0 <_js_array_get_f64+0x910>
1007c3380:     	add	x8, x21, w19, uxtw #3
1007c3384:     	ldr	x22, [x8, #0x8]
1007c3388:     	mov	x8, #0x1                ; =1
1007c338c:     	movk	x8, #0x7ffc, lsl #48
1007c3390:     	add	x8, x8, #0xf
1007c3394:     	cmp	x22, x8
1007c3398:     	b.ne	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c339c:     	b	0x1007c33b0 <_js_array_get_f64+0x920>
1007c33a0:     	mov	x0, x21
1007c33a4:     	mov	x1, x19
1007c33a8:     	bl	0x10052d8c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007c33ac:     	tbnz	w0, #0x0, 0x1007c3184 <_js_array_get_f64+0x6f4>
1007c33b0:     	mov	x0, x21
1007c33b4:     	mov	x1, x19
1007c33b8:     	bl	0x1006cbda4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007c33bc:     	b	0x1007c3184 <_js_array_get_f64+0x6f4>
1007c33c0:     	add	x9, x8, #0xc0
1007c33c4:     	ldr	x10, [x8, #0x30]
1007c33c8:     	add	x10, x10, #0x1
1007c33cc:     	str	x10, [x8, #0x30]
1007c33d0:     	add	x8, x9, #0x19
1007c33d4:     	ldrb	w8, [x8]
1007c33d8:     	cmp	w8, #0xff
1007c33dc:     	b.ne	0x1007c2ea8 <_js_array_get_f64+0x418>
1007c33e0:     	b	0x1007c2e9c <_js_array_get_f64+0x40c>
1007c33e4:     	add	x21, x22, #0x1
1007c33e8:     	fmov	d0, x21
1007c33ec:     	bl	0x100701bbc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007c33f0:     	mov	x22, x0
1007c33f4:     	tbnz	w23, #0x0, 0x1007c3188 <_js_array_get_f64+0x6f8>
1007c33f8:     	mov	x0, x20
1007c33fc:     	bl	0x100b64100 <_mi_free>
1007c3400:     	b	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c3404:     	ldr	x20, [sp, #0x10]
1007c3408:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c340c:     	ldr	x8, [x8, #0xed8]
1007c3410:     	cbz	x8, 0x1007c3428 <_js_array_get_f64+0x998>
1007c3414:     	mov	x0, x20
1007c3418:     	bl	0x10013cc40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007c341c:     	tbz	w0, #0x0, 0x1007c3428 <_js_array_get_f64+0x998>
1007c3420:     	mov	x0, x20
1007c3424:     	bl	0x1002c1840 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007c3428:     	tbnz	w19, #0x1f, 0x1007c3448 <_js_array_get_f64+0x9b8>
1007c342c:     	ldr	w8, [x20]
1007c3430:     	cmp	w19, w8
1007c3434:     	b.hs	0x1007c3448 <_js_array_get_f64+0x9b8>
1007c3438:     	mov	w1, w19
1007c343c:     	mov	x0, x20
1007c3440:     	bl	0x1002a7acc <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007c3444:     	b	0x1007c3184 <_js_array_get_f64+0x6f4>
1007c3448:     	mov	x8, #0x1                ; =1
1007c344c:     	movk	x8, #0x7ffc, lsl #48
1007c3450:     	mov	x22, x8
1007c3454:     	b	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c3458:     	mov	x0, x22
1007c345c:     	bl	0x100b4ca70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007c3460:     	cmp	x0, #0x1
1007c3464:     	b.ne	0x1007c2ad0 <_js_array_get_f64+0x40>
1007c3468:     	mov	x0, x19
1007c346c:     	bl	0x100b4ca90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007c3470:     	b	0x1007c3184 <_js_array_get_f64+0x6f4>
1007c3474:     	mov	x0, x20
1007c3478:     	mov	w1, #0x0                ; =0
1007c347c:     	bl	0x100b4f000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007c3480:     	mov	x20, x0
1007c3484:     	cbnz	x0, 0x1007c2bac <_js_array_get_f64+0x11c>
1007c3488:     	b	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c348c:     	mov	x0, x20
1007c3490:     	mov	w1, #0x1                ; =1
1007c3494:     	bl	0x100b4f000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007c3498:     	mov	x20, x0
1007c349c:     	cbnz	x0, 0x1007c2d50 <_js_array_get_f64+0x2c0>
1007c34a0:     	b	0x1007c3188 <_js_array_get_f64+0x6f8>
1007c34a4:     	mov	w0, #0x1                ; =1
1007c34a8:     	mov	x1, x22
1007c34ac:     	bl	0x100b17480 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
