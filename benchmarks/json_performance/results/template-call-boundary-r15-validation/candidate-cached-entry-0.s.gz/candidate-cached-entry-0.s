
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-call-boundary-r15/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004eb1d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template>:
1004eb1d0:     	sub	sp, sp, #0xe0
1004eb1d4:     	stp	x28, x27, [sp, #0x80]
1004eb1d8:     	stp	x26, x25, [sp, #0x90]
1004eb1dc:     	stp	x24, x23, [sp, #0xa0]
1004eb1e0:     	stp	x22, x21, [sp, #0xb0]
1004eb1e4:     	stp	x20, x19, [sp, #0xc0]
1004eb1e8:     	stp	x29, x30, [sp, #0xd0]
1004eb1ec:     	add	x29, sp, #0xd0
1004eb1f0:     	sub	x8, x1, #0x801
1004eb1f4:     	cmn	x8, #0x7c0
1004eb1f8:     	b.lo	0x1004eb318 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x148>
1004eb1fc:     	adrp	x19, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eb200:     	ldr	w20, [x19, #0x578]
1004eb204:     	adrp	x23, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb208:     	cmp	w20, #0x300
1004eb20c:     	b.hs	0x1004eb364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x194>
1004eb210:     	ldr	x8, [x23, #0x48]
1004eb214:     	cmn	x8, #0x1
1004eb218:     	b.eq	0x1004eb340 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x170>
1004eb21c:     	mrs	x9, TPIDRRO_EL0
1004eb220:     	and	x9, x9, #0xfffffffffffffff8
1004eb224:     	ldr	x8, [x9, x8, lsl #3]
1004eb228:     	cbz	x8, 0x1004eb340 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x170>
1004eb22c:     	add	x8, x8, x20, lsl #3
1004eb230:     	ldr	x8, [x8, #0x1e8]
1004eb234:     	cbz	x8, 0x1004eb364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x194>
1004eb238:     	ldr	x9, [x8]
1004eb23c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1004eb240:     	cmp	x9, x10
1004eb244:     	b.hs	0x1004eb398 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x1c8>
1004eb248:     	ldrb	w9, [x8, #0x8]
1004eb24c:     	cmp	w9, #0x2
1004eb250:     	b.eq	0x1004eb318 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x148>
1004eb254:     	ldr	x9, [x8, #0x248]
1004eb258:     	cmp	x9, x0
1004eb25c:     	b.ne	0x1004eb318 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x148>
1004eb260:     	ldrh	w8, [x8, #0x25c]
1004eb264:     	cmp	x1, x8
1004eb268:     	b.ne	0x1004eb318 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x148>
1004eb26c:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb270:     	ldr	w20, [x8, #0x948]
1004eb274:     	cmp	w20, #0x300
1004eb278:     	b.hs	0x1004eb6f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x520>
1004eb27c:     	ldr	x8, [x23, #0x48]
1004eb280:     	cmn	x8, #0x1
1004eb284:     	b.eq	0x1004eb6e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x510>
1004eb288:     	mrs	x9, TPIDRRO_EL0
1004eb28c:     	and	x9, x9, #0xfffffffffffffff8
1004eb290:     	ldr	x0, [x9, x8, lsl #3]
1004eb294:     	cbz	x0, 0x1004eb6e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x510>
1004eb298:     	add	x8, x0, x20, lsl #3
1004eb29c:     	ldr	x0, [x8, #0x1e8]
1004eb2a0:     	cbz	x0, 0x1004eb6f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x520>
1004eb2a4:     	ldrb	w8, [x0]
1004eb2a8:     	cbnz	w8, 0x1004eb704 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x534>
1004eb2ac:     	ldr	w19, [x19, #0x578]
1004eb2b0:     	cmp	w19, #0x300
1004eb2b4:     	b.hs	0x1004eb728 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x558>
1004eb2b8:     	ldr	x8, [x23, #0x48]
1004eb2bc:     	cmn	x8, #0x1
1004eb2c0:     	b.eq	0x1004eb718 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x548>
1004eb2c4:     	mrs	x9, TPIDRRO_EL0
1004eb2c8:     	and	x9, x9, #0xfffffffffffffff8
1004eb2cc:     	ldr	x0, [x9, x8, lsl #3]
1004eb2d0:     	cbz	x0, 0x1004eb718 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x548>
1004eb2d4:     	add	x8, x0, x19, lsl #3
1004eb2d8:     	ldr	x20, [x8, #0x1e8]
1004eb2dc:     	cbz	x20, 0x1004eb728 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x558>
1004eb2e0:     	bl	0x10027f544 <__RNvMs7_NtNtCs3gRpqoBkMHm_13perry_runtime2gc6policyNtB5_15GcSuppressScope3new>
1004eb2e4:     	ldr	x8, [x20]
1004eb2e8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1004eb2ec:     	cmp	x8, x9
1004eb2f0:     	b.hs	0x1004eb74c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x57c>
1004eb2f4:     	mov	x21, x0
1004eb2f8:     	add	x9, x8, #0x1
1004eb2fc:     	str	x9, [x20]
1004eb300:     	mov	x19, x20
1004eb304:     	ldrb	w9, [x19, #0x8]!
1004eb308:     	cmp	w9, #0x2
1004eb30c:     	b.ne	0x1004eb3a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x1d4>
1004eb310:     	str	x8, [x20]
1004eb314:     	tbz	w21, #0x0, 0x1004eb598 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3c8>
1004eb318:     	mov	x0, #0x0                ; =0
1004eb31c:     	mov	x1, x19
1004eb320:     	ldp	x29, x30, [sp, #0xd0]
1004eb324:     	ldp	x20, x19, [sp, #0xc0]
1004eb328:     	ldp	x22, x21, [sp, #0xb0]
1004eb32c:     	ldp	x24, x23, [sp, #0xa0]
1004eb330:     	ldp	x26, x25, [sp, #0x90]
1004eb334:     	ldp	x28, x27, [sp, #0x80]
1004eb338:     	add	sp, sp, #0xe0
1004eb33c:     	ret
1004eb340:     	mov	x22, x1
1004eb344:     	mov	x21, x0
1004eb348:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb34c:     	mov	x1, x22
1004eb350:     	mov	x8, x0
1004eb354:     	mov	x0, x21
1004eb358:     	add	x8, x8, x20, lsl #3
1004eb35c:     	ldr	x8, [x8, #0x1e8]
1004eb360:     	cbnz	x8, 0x1004eb238 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x68>
1004eb364:     	adrp	x8, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
1004eb368:     	add	x8, x8, #0x0
1004eb36c:     	mov	x20, x0
1004eb370:     	mov	x0, x8
1004eb374:     	mov	x21, x1
1004eb378:     	bl	0x100b3a9dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004eb37c:     	mov	x1, x21
1004eb380:     	mov	x8, x0
1004eb384:     	mov	x0, x20
1004eb388:     	ldr	x9, [x8]
1004eb38c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1004eb390:     	cmp	x9, x10
1004eb394:     	b.lo	0x1004eb248 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x78>
1004eb398:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb39c:     	add	x0, x0, #0xd40
1004eb3a0:     	bl	0x100b1051c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1004eb3a4:     	add	x0, sp, #0x18
1004eb3a8:     	bl	0x100235bf8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime5arena12constructionNtB2_17ConstructionBatch3new>
1004eb3ac:     	adrp	x1, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x70b0>
1004eb3b0:     	add	x1, x1, #0xa30
1004eb3b4:     	add	x0, sp, #0x30
1004eb3b8:     	mov	w2, #0x40               ; =64
1004eb3bc:     	bl	0x100b5fc10 <_writev+0x100b5fc10>
1004eb3c0:     	ldrb	w1, [x20, #0x25e]
1004eb3c4:     	cmp	w1, #0x9
1004eb3c8:     	b.hs	0x1004eb808 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x638>
1004eb3cc:     	cbz	w1, 0x1004eb5e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x414>
1004eb3d0:     	str	w21, [sp, #0x4]
1004eb3d4:     	mov	x25, #0x0               ; =0
1004eb3d8:     	mov	w8, #0x48               ; =72
1004eb3dc:     	umaddl	x26, w1, w8, x19
1004eb3e0:     	mov	x27, #0x7ffd000000000000 ; =9222527611924643840
1004eb3e4:     	ldr	x8, [sp, #0x18]
1004eb3e8:     	stp	x20, x8, [sp, #0x8]
1004eb3ec:     	mov	x28, #-0x3000000000000  ; =-844424930131968
1004eb3f0:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
1004eb3f4:     	mov	x24, #0x7ff9000000000000 ; =9221401712017801216
1004eb3f8:     	add	x9, sp, #0x30
1004eb3fc:     	mov	x21, x19
1004eb400:     	b	0x1004eb41c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x24c>
1004eb404:     	ldr	x8, [x19, #0x8]
1004eb408:     	str	x8, [x9, x25, lsl #3]
1004eb40c:     	add	x25, x25, #0x1
1004eb410:     	mov	x19, x21
1004eb414:     	cmp	x21, x26
1004eb418:     	b.eq	0x1004eb568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x398>
1004eb41c:     	ldrb	w8, [x21], #0x48
1004eb420:     	tbz	w8, #0x0, 0x1004eb404 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x234>
1004eb424:     	ldrb	w23, [x19, #0x1]
1004eb428:     	sub	x0, x29, #0x60
1004eb42c:     	add	x1, sp, #0x18
1004eb430:     	mov	x2, x23
1004eb434:     	bl	0x100233650 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray3new>
1004eb438:     	cmp	w23, #0x9
1004eb43c:     	b.hs	0x1004eb7f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x620>
1004eb440:     	ldur	x22, [x29, #-0x60]
1004eb444:     	cbz	w23, 0x1004eb53c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x36c>
1004eb448:     	add	x19, x19, #0x8
1004eb44c:     	lsl	x23, x23, #3
1004eb450:     	b	0x1004eb4a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x2d8>
1004eb454:     	add	x9, x22, w8, uxtw #3
1004eb458:     	str	x2, [x9, #0x8]
1004eb45c:     	and	x9, x2, x28
1004eb460:     	cmp	x9, x27
1004eb464:     	cset	w9, eq
1004eb468:     	ldurb	w10, [x29, #-0x57]
1004eb46c:     	orr	w9, w10, w9
1004eb470:     	sturb	w9, [x29, #-0x57]
1004eb474:     	ldurb	w9, [x29, #-0x56]
1004eb478:     	csel	w9, w9, wzr, eq
1004eb47c:     	sturb	w9, [x29, #-0x56]
1004eb480:     	and	x9, x2, #0xffff000000000000
1004eb484:     	cmp	x9, x20
1004eb488:     	ccmp	x2, x24, #0x0, ls
1004eb48c:     	ldurb	w9, [x29, #-0x55]
1004eb490:     	csel	w9, w9, wzr, lo
1004eb494:     	sturb	w9, [x29, #-0x55]
1004eb498:     	add	w8, w8, #0x1
1004eb49c:     	str	w8, [x22]
1004eb4a0:     	subs	x23, x23, #0x8
1004eb4a4:     	b.eq	0x1004eb538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x368>
1004eb4a8:     	ldr	x2, [x19], #0x8
1004eb4ac:     	ldp	w8, w9, [x22]
1004eb4b0:     	cmp	w8, w9
1004eb4b4:     	b.eq	0x1004eb510 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x340>
1004eb4b8:     	ldurb	w9, [x29, #-0x58]
1004eb4bc:     	tbnz	w9, #0x0, 0x1004eb454 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x284>
1004eb4c0:     	ldr	w9, [x22, #0x4]
1004eb4c4:     	cmp	w8, w9
1004eb4c8:     	b.hs	0x1004eb4f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x320>
1004eb4cc:     	mov	w1, w8
1004eb4d0:     	mov	x0, x22
1004eb4d4:     	bl	0x1005270ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array15header_gc_slots27note_array_slot_layout_only>
1004eb4d8:     	ldr	w8, [x22]
1004eb4dc:     	add	w8, w8, #0x1
1004eb4e0:     	str	w8, [x22]
1004eb4e4:     	subs	x23, x23, #0x8
1004eb4e8:     	b.ne	0x1004eb4a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x2d8>
1004eb4ec:     	b	0x1004eb538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x368>
1004eb4f0:     	fmov	d0, x2
1004eb4f4:     	mov	x0, x22
1004eb4f8:     	bl	0x1007c8428 <_js_array_push_f64>
1004eb4fc:     	mov	x22, x0
1004eb500:     	stur	x0, [x29, #-0x60]
1004eb504:     	subs	x23, x23, #0x8
1004eb508:     	b.ne	0x1004eb4a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x2d8>
1004eb50c:     	b	0x1004eb538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x368>
1004eb510:     	sub	x0, x29, #0x60
1004eb514:     	add	x1, sp, #0x18
1004eb518:     	mov	x22, x2
1004eb51c:     	bl	0x100b3884c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray4grow>
1004eb520:     	mov	x2, x22
1004eb524:     	ldur	x22, [x29, #-0x60]
1004eb528:     	ldr	w8, [x22]
1004eb52c:     	ldurb	w9, [x29, #-0x58]
1004eb530:     	tbz	w9, #0x0, 0x1004eb4c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x2f0>
1004eb534:     	b	0x1004eb454 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x284>
1004eb538:     	ldur	x22, [x29, #-0x60]
1004eb53c:     	sub	x0, x29, #0x60
1004eb540:     	ldr	x1, [sp, #0x10]
1004eb544:     	bl	0x10023348c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray13finish_layout>
1004eb548:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1004eb54c:     	bfxil	x8, x22, #0, #48
1004eb550:     	add	x9, sp, #0x30
1004eb554:     	str	x8, [x9, x25, lsl #3]
1004eb558:     	add	x25, x25, #0x1
1004eb55c:     	mov	x19, x21
1004eb560:     	cmp	x21, x26
1004eb564:     	b.ne	0x1004eb41c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x24c>
1004eb568:     	ldr	x20, [sp, #0x8]
1004eb56c:     	ldrb	w4, [x20, #0x25e]
1004eb570:     	cmp	x4, #0x9
1004eb574:     	adrp	x23, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb578:     	ldr	w21, [sp, #0x4]
1004eb57c:     	b.lo	0x1004eb5e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x418>
1004eb580:     	adrp	x3, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb584:     	add	x3, x3, #0xd70
1004eb588:     	mov	x0, #0x0                ; =0
1004eb58c:     	mov	x1, x4
1004eb590:     	mov	w2, #0x8                ; =8
1004eb594:     	bl	0x100b1080c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1004eb598:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eb59c:     	ldr	w19, [x8, #0x308]
1004eb5a0:     	cmp	w19, #0x300
1004eb5a4:     	b.hs	0x1004eb7a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5d0>
1004eb5a8:     	ldr	x8, [x23, #0x48]
1004eb5ac:     	cmn	x8, #0x1
1004eb5b0:     	b.eq	0x1004eb790 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5c0>
1004eb5b4:     	mrs	x9, TPIDRRO_EL0
1004eb5b8:     	and	x9, x9, #0xfffffffffffffff8
1004eb5bc:     	ldr	x0, [x9, x8, lsl #3]
1004eb5c0:     	cbz	x0, 0x1004eb790 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5c0>
1004eb5c4:     	add	x8, x0, x19, lsl #3
1004eb5c8:     	ldr	x8, [x8, #0x1e8]
1004eb5cc:     	cbz	x8, 0x1004eb7a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5d0>
1004eb5d0:     	mov	x0, #0x0                ; =0
1004eb5d4:     	ldrb	w9, [x8]
1004eb5d8:     	and	w9, w9, #0xfffffffd
1004eb5dc:     	strb	w9, [x8]
1004eb5e0:     	b	0x1004eb31c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x14c>
1004eb5e4:     	mov	x4, #0x0                ; =0
1004eb5e8:     	ldr	w2, [x20, #0x258]
1004eb5ec:     	ldr	x1, [x20, #0x250]
1004eb5f0:     	add	x0, sp, #0x18
1004eb5f4:     	add	x3, sp, #0x30
1004eb5f8:     	bl	0x1005ba3c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
1004eb5fc:     	ldr	x8, [x20]
1004eb600:     	sub	x8, x8, #0x1
1004eb604:     	str	x8, [x20]
1004eb608:     	tbz	w21, #0x0, 0x1004eb66c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x49c>
1004eb60c:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1004eb610:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1004eb614:     	ldr	x8, [x8, #0x758]
1004eb618:     	cbnz	x8, 0x1004eb6c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4f0>
1004eb61c:     	bfxil	x19, x0, #0, #48
1004eb620:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb624:     	ldr	w20, [x8, #0x930]
1004eb628:     	cmp	w20, #0x300
1004eb62c:     	b.hs	0x1004eb768 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x598>
1004eb630:     	ldr	x8, [x23, #0x48]
1004eb634:     	cmn	x8, #0x1
1004eb638:     	b.eq	0x1004eb758 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x588>
1004eb63c:     	mrs	x9, TPIDRRO_EL0
1004eb640:     	and	x9, x9, #0xfffffffffffffff8
1004eb644:     	ldr	x0, [x9, x8, lsl #3]
1004eb648:     	cbz	x0, 0x1004eb758 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x588>
1004eb64c:     	add	x8, x0, x20, lsl #3
1004eb650:     	ldr	x0, [x8, #0x1e8]
1004eb654:     	cbz	x0, 0x1004eb768 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x598>
1004eb658:     	ldrb	w8, [x0]
1004eb65c:     	cbz	w8, 0x1004eb77c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5ac>
1004eb660:     	sub	w8, w8, #0x1
1004eb664:     	strb	w8, [x0]
1004eb668:     	b	0x1004eb788 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5b8>
1004eb66c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eb670:     	ldr	w19, [x8, #0x308]
1004eb674:     	cmp	w19, #0x300
1004eb678:     	b.hs	0x1004eb7d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x600>
1004eb67c:     	ldr	x8, [x23, #0x48]
1004eb680:     	cmn	x8, #0x1
1004eb684:     	b.eq	0x1004eb7b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5e4>
1004eb688:     	mrs	x9, TPIDRRO_EL0
1004eb68c:     	and	x9, x9, #0xfffffffffffffff8
1004eb690:     	ldr	x8, [x9, x8, lsl #3]
1004eb694:     	cbz	x8, 0x1004eb7b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5e4>
1004eb698:     	add	x8, x8, x19, lsl #3
1004eb69c:     	ldr	x8, [x8, #0x1e8]
1004eb6a0:     	cbz	x8, 0x1004eb7d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x600>
1004eb6a4:     	ldrb	w9, [x8]
1004eb6a8:     	and	w9, w9, #0xfffffffd
1004eb6ac:     	strb	w9, [x8]
1004eb6b0:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1004eb6b4:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1004eb6b8:     	ldr	x8, [x8, #0x758]
1004eb6bc:     	cbz	x8, 0x1004eb61c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x44c>
1004eb6c0:     	mov	x20, x0
1004eb6c4:     	bl	0x100b43884 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
1004eb6c8:     	bfxil	x19, x20, #0, #48
1004eb6cc:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb6d0:     	ldr	w20, [x8, #0x930]
1004eb6d4:     	cmp	w20, #0x300
1004eb6d8:     	b.lo	0x1004eb630 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x460>
1004eb6dc:     	b	0x1004eb768 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x598>
1004eb6e0:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb6e4:     	add	x8, x0, x20, lsl #3
1004eb6e8:     	ldr	x0, [x8, #0x1e8]
1004eb6ec:     	cbnz	x0, 0x1004eb2a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0xd4>
1004eb6f0:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1004eb6f4:     	add	x0, x0, #0xcf0
1004eb6f8:     	bl	0x100b3aa28 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb6fc:     	ldrb	w8, [x0]
1004eb700:     	cbz	w8, 0x1004eb2ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0xdc>
1004eb704:     	bl	0x100b4215c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
1004eb708:     	ldr	w19, [x19, #0x578]
1004eb70c:     	cmp	w19, #0x300
1004eb710:     	b.lo	0x1004eb2b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0xe8>
1004eb714:     	b	0x1004eb728 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x558>
1004eb718:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb71c:     	add	x8, x0, x19, lsl #3
1004eb720:     	ldr	x20, [x8, #0x1e8]
1004eb724:     	cbnz	x20, 0x1004eb2e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x110>
1004eb728:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
1004eb72c:     	add	x0, x0, #0x0
1004eb730:     	bl	0x100b3a9dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004eb734:     	mov	x20, x0
1004eb738:     	bl	0x10027f544 <__RNvMs7_NtNtCs3gRpqoBkMHm_13perry_runtime2gc6policyNtB5_15GcSuppressScope3new>
1004eb73c:     	ldr	x8, [x20]
1004eb740:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1004eb744:     	cmp	x8, x9
1004eb748:     	b.lo	0x1004eb2f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x124>
1004eb74c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb750:     	add	x0, x0, #0xd58
1004eb754:     	bl	0x100b1051c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1004eb758:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb75c:     	add	x8, x0, x20, lsl #3
1004eb760:     	ldr	x0, [x8, #0x1e8]
1004eb764:     	cbnz	x0, 0x1004eb658 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x488>
1004eb768:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1004eb76c:     	add	x0, x0, #0xcc0
1004eb770:     	bl	0x100b3aa28 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb774:     	ldrb	w8, [x0]
1004eb778:     	cbnz	w8, 0x1004eb660 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x490>
1004eb77c:     	mov	w8, #0x3f               ; =63
1004eb780:     	strb	w8, [x0]
1004eb784:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
1004eb788:     	mov	w0, #0x1                ; =1
1004eb78c:     	b	0x1004eb31c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x14c>
1004eb790:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb794:     	add	x8, x0, x19, lsl #3
1004eb798:     	ldr	x8, [x8, #0x1e8]
1004eb79c:     	cbnz	x8, 0x1004eb5d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x400>
1004eb7a0:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1004eb7a4:     	add	x0, x0, #0xd20
1004eb7a8:     	bl	0x100b3aa28 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb7ac:     	mov	x8, x0
1004eb7b0:     	b	0x1004eb5d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x400>
1004eb7b4:     	mov	x20, x0
1004eb7b8:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb7bc:     	mov	x8, x0
1004eb7c0:     	mov	x0, x20
1004eb7c4:     	add	x8, x8, x19, lsl #3
1004eb7c8:     	ldr	x8, [x8, #0x1e8]
1004eb7cc:     	cbnz	x8, 0x1004eb6a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4d4>
1004eb7d0:     	adrp	x8, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1004eb7d4:     	add	x8, x8, #0xd20
1004eb7d8:     	mov	x19, x0
1004eb7dc:     	mov	x0, x8
1004eb7e0:     	bl	0x100b3aa28 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb7e4:     	mov	x8, x0
1004eb7e8:     	mov	x0, x19
1004eb7ec:     	b	0x1004eb6a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4d4>
1004eb7f0:     	adrp	x3, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb7f4:     	add	x3, x3, #0xd88
1004eb7f8:     	mov	x0, #0x0                ; =0
1004eb7fc:     	mov	x1, x23
1004eb800:     	mov	w2, #0x8                ; =8
1004eb804:     	bl	0x100b1080c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1004eb808:     	adrp	x3, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb80c:     	add	x3, x3, #0xda0
1004eb810:     	mov	x0, #0x0                ; =0
1004eb814:     	mov	w2, #0x8                ; =8
1004eb818:     	bl	0x100b1080c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
