
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-call-boundary-r15/main-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004eb1d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template>:
1004eb1d0:     	stp	x28, x27, [sp, #-0x60]!
1004eb1d4:     	stp	x26, x25, [sp, #0x10]
1004eb1d8:     	stp	x24, x23, [sp, #0x20]
1004eb1dc:     	stp	x22, x21, [sp, #0x30]
1004eb1e0:     	stp	x20, x19, [sp, #0x40]
1004eb1e4:     	stp	x29, x30, [sp, #0x50]
1004eb1e8:     	add	x29, sp, #0x50
1004eb1ec:     	sub	sp, sp, #0x330
1004eb1f0:     	sub	x8, x1, #0x801
1004eb1f4:     	cmn	x8, #0x7c0
1004eb1f8:     	b.lo	0x1004eb2fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x12c>
1004eb1fc:     	adrp	x19, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eb200:     	ldr	w20, [x19, #0x578]
1004eb204:     	adrp	x23, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb208:     	cmp	w20, #0x300
1004eb20c:     	b.hs	0x1004eb348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x178>
1004eb210:     	ldr	x8, [x23, #0x48]
1004eb214:     	cmn	x8, #0x1
1004eb218:     	b.eq	0x1004eb324 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x154>
1004eb21c:     	mrs	x9, TPIDRRO_EL0
1004eb220:     	and	x9, x9, #0xfffffffffffffff8
1004eb224:     	ldr	x8, [x9, x8, lsl #3]
1004eb228:     	cbz	x8, 0x1004eb324 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x154>
1004eb22c:     	add	x8, x8, x20, lsl #3
1004eb230:     	ldr	x8, [x8, #0x1e8]
1004eb234:     	cbz	x8, 0x1004eb348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x178>
1004eb238:     	ldr	x9, [x8]
1004eb23c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1004eb240:     	cmp	x9, x10
1004eb244:     	b.hs	0x1004eb37c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x1ac>
1004eb248:     	ldrb	w9, [x8, #0x8]
1004eb24c:     	cmp	w9, #0x2
1004eb250:     	b.eq	0x1004eb2fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x12c>
1004eb254:     	ldr	x9, [x8, #0x248]
1004eb258:     	cmp	x9, x0
1004eb25c:     	b.ne	0x1004eb2fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x12c>
1004eb260:     	ldrh	w8, [x8, #0x25c]
1004eb264:     	cmp	x1, x8
1004eb268:     	b.ne	0x1004eb2fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x12c>
1004eb26c:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb270:     	ldr	w20, [x8, #0x948]
1004eb274:     	cmp	w20, #0x300
1004eb278:     	b.hs	0x1004eb6c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4f0>
1004eb27c:     	ldr	x8, [x23, #0x48]
1004eb280:     	cmn	x8, #0x1
1004eb284:     	b.eq	0x1004eb6b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4e0>
1004eb288:     	mrs	x9, TPIDRRO_EL0
1004eb28c:     	and	x9, x9, #0xfffffffffffffff8
1004eb290:     	ldr	x0, [x9, x8, lsl #3]
1004eb294:     	cbz	x0, 0x1004eb6b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4e0>
1004eb298:     	add	x8, x0, x20, lsl #3
1004eb29c:     	ldr	x0, [x8, #0x1e8]
1004eb2a0:     	cbz	x0, 0x1004eb6c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4f0>
1004eb2a4:     	ldrb	w8, [x0]
1004eb2a8:     	cbnz	w8, 0x1004eb6d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x504>
1004eb2ac:     	ldr	w19, [x19, #0x578]
1004eb2b0:     	cmp	w19, #0x300
1004eb2b4:     	b.hs	0x1004eb6f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x528>
1004eb2b8:     	ldr	x8, [x23, #0x48]
1004eb2bc:     	cmn	x8, #0x1
1004eb2c0:     	b.eq	0x1004eb6e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x518>
1004eb2c4:     	mrs	x9, TPIDRRO_EL0
1004eb2c8:     	and	x9, x9, #0xfffffffffffffff8
1004eb2cc:     	ldr	x0, [x9, x8, lsl #3]
1004eb2d0:     	cbz	x0, 0x1004eb6e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x518>
1004eb2d4:     	add	x8, x0, x19, lsl #3
1004eb2d8:     	ldr	x22, [x8, #0x1e8]
1004eb2dc:     	cbz	x22, 0x1004eb6f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x528>
1004eb2e0:     	ldr	x8, [x22]
1004eb2e4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1004eb2e8:     	cmp	x8, x9
1004eb2ec:     	b.hs	0x1004eb718 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x548>
1004eb2f0:     	ldrb	w20, [x22, #0x8]
1004eb2f4:     	cmp	w20, #0x2
1004eb2f8:     	b.ne	0x1004eb388 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x1b8>
1004eb2fc:     	mov	x0, #0x0                ; =0
1004eb300:     	mov	x1, x19
1004eb304:     	add	sp, sp, #0x330
1004eb308:     	ldp	x29, x30, [sp, #0x50]
1004eb30c:     	ldp	x20, x19, [sp, #0x40]
1004eb310:     	ldp	x22, x21, [sp, #0x30]
1004eb314:     	ldp	x24, x23, [sp, #0x20]
1004eb318:     	ldp	x26, x25, [sp, #0x10]
1004eb31c:     	ldp	x28, x27, [sp], #0x60
1004eb320:     	ret
1004eb324:     	mov	x22, x1
1004eb328:     	mov	x21, x0
1004eb32c:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb330:     	mov	x1, x22
1004eb334:     	mov	x8, x0
1004eb338:     	mov	x0, x21
1004eb33c:     	add	x8, x8, x20, lsl #3
1004eb340:     	ldr	x8, [x8, #0x1e8]
1004eb344:     	cbnz	x8, 0x1004eb238 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x68>
1004eb348:     	adrp	x8, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004eb34c:     	add	x8, x8, #0xfb8
1004eb350:     	mov	x20, x0
1004eb354:     	mov	x0, x8
1004eb358:     	mov	x21, x1
1004eb35c:     	bl	0x100b3a95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004eb360:     	mov	x1, x21
1004eb364:     	mov	x8, x0
1004eb368:     	mov	x0, x20
1004eb36c:     	ldr	x9, [x8]
1004eb370:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1004eb374:     	cmp	x9, x10
1004eb378:     	b.lo	0x1004eb248 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x78>
1004eb37c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb380:     	add	x0, x0, #0xd40
1004eb384:     	bl	0x100b1049c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1004eb388:     	add	x19, sp, #0x20
1004eb38c:     	orr	x0, x19, #0x1
1004eb390:     	add	x1, x22, #0x9
1004eb394:     	mov	w2, #0x247              ; =583
1004eb398:     	bl	0x100b5fbac <_writev+0x100b5fbac>
1004eb39c:     	ldr	x10, [x22, #0x250]
1004eb3a0:     	ldr	w11, [x22, #0x258]
1004eb3a4:     	ldrh	w8, [x22, #0x25c]
1004eb3a8:     	ldrb	w21, [x22, #0x25e]
1004eb3ac:     	ldrb	w9, [x22, #0x25f]
1004eb3b0:     	strb	w20, [sp, #0x20]
1004eb3b4:     	str	x10, [sp, #0x8]
1004eb3b8:     	str	x10, [sp, #0x268]
1004eb3bc:     	str	w11, [sp, #0x4]
1004eb3c0:     	str	w11, [sp, #0x270]
1004eb3c4:     	strh	w8, [sp, #0x274]
1004eb3c8:     	strb	w21, [sp, #0x276]
1004eb3cc:     	strb	w9, [sp, #0x277]
1004eb3d0:     	bl	0x10027f544 <__RNvMs7_NtNtCs3gRpqoBkMHm_13perry_runtime2gc6policyNtB5_15GcSuppressScope3new>
1004eb3d4:     	str	w0, [sp]
1004eb3d8:     	add	x0, sp, #0x278
1004eb3dc:     	bl	0x100235bf8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime5arena12constructionNtB2_17ConstructionBatch3new>
1004eb3e0:     	adrp	x1, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x70f0>
1004eb3e4:     	add	x1, x1, #0x9f0
1004eb3e8:     	sub	x0, x29, #0xf0
1004eb3ec:     	mov	w2, #0x40               ; =64
1004eb3f0:     	bl	0x100b5fbd0 <_writev+0x100b5fbd0>
1004eb3f4:     	cmp	w21, #0x9
1004eb3f8:     	b.hs	0x1004eb7b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5e0>
1004eb3fc:     	str	x21, [sp, #0x10]
1004eb400:     	cbz	w21, 0x1004eb5b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3e8>
1004eb404:     	mov	x27, #0x0               ; =0
1004eb408:     	mov	w8, #0x48               ; =72
1004eb40c:     	ldr	x9, [sp, #0x10]
1004eb410:     	umaddl	x28, w9, w8, x19
1004eb414:     	add	x8, sp, #0x20
1004eb418:     	ldr	x9, [sp, #0x278]
1004eb41c:     	str	x9, [sp, #0x18]
1004eb420:     	mov	x22, #0x7ffd000000000000 ; =9222527611924643840
1004eb424:     	mov	x20, #-0x3000000000000  ; =-844424930131968
1004eb428:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
1004eb42c:     	mov	x19, #0x7ff9000000000000 ; =9221401712017801216
1004eb430:     	sub	x23, x29, #0xf0
1004eb434:     	mov	x26, x8
1004eb438:     	b	0x1004eb454 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x284>
1004eb43c:     	ldr	x8, [x8, #0x8]
1004eb440:     	str	x8, [x23, x27, lsl #3]
1004eb444:     	add	x27, x27, #0x1
1004eb448:     	mov	x8, x26
1004eb44c:     	cmp	x26, x28
1004eb450:     	b.eq	0x1004eb5b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3e8>
1004eb454:     	ldrb	w9, [x26], #0x48
1004eb458:     	tbz	w9, #0x0, 0x1004eb43c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x26c>
1004eb45c:     	ldur	q0, [x8, #0x8]
1004eb460:     	ldur	q1, [x8, #0x18]
1004eb464:     	stp	q0, q1, [x29, #-0xb0]
1004eb468:     	ldur	q0, [x8, #0x28]
1004eb46c:     	ldur	q1, [x8, #0x38]
1004eb470:     	stp	q0, q1, [x29, #-0x90]
1004eb474:     	ldrb	w25, [x8, #0x1]
1004eb478:     	sub	x0, x29, #0x68
1004eb47c:     	add	x1, sp, #0x278
1004eb480:     	mov	x2, x25
1004eb484:     	bl	0x100233650 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray3new>
1004eb488:     	cmp	w25, #0x9
1004eb48c:     	b.hs	0x1004eb798 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5c8>
1004eb490:     	ldur	x24, [x29, #-0x68]
1004eb494:     	cbz	w25, 0x1004eb590 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3c0>
1004eb498:     	lsl	x25, x25, #3
1004eb49c:     	sub	x23, x29, #0xb0
1004eb4a0:     	b	0x1004eb4f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x328>
1004eb4a4:     	add	x9, x24, w8, uxtw #3
1004eb4a8:     	str	x2, [x9, #0x8]
1004eb4ac:     	and	x9, x2, x20
1004eb4b0:     	cmp	x9, x22
1004eb4b4:     	cset	w9, eq
1004eb4b8:     	ldurb	w10, [x29, #-0x5f]
1004eb4bc:     	orr	w9, w10, w9
1004eb4c0:     	sturb	w9, [x29, #-0x5f]
1004eb4c4:     	ldurb	w9, [x29, #-0x5e]
1004eb4c8:     	csel	w9, w9, wzr, eq
1004eb4cc:     	sturb	w9, [x29, #-0x5e]
1004eb4d0:     	and	x9, x2, #0xffff000000000000
1004eb4d4:     	cmp	x9, x21
1004eb4d8:     	ccmp	x2, x19, #0x0, ls
1004eb4dc:     	ldurb	w9, [x29, #-0x5d]
1004eb4e0:     	csel	w9, w9, wzr, lo
1004eb4e4:     	sturb	w9, [x29, #-0x5d]
1004eb4e8:     	add	w8, w8, #0x1
1004eb4ec:     	str	w8, [x24]
1004eb4f0:     	subs	x25, x25, #0x8
1004eb4f4:     	b.eq	0x1004eb588 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3b8>
1004eb4f8:     	ldr	x2, [x23], #0x8
1004eb4fc:     	ldp	w8, w9, [x24]
1004eb500:     	cmp	w8, w9
1004eb504:     	b.eq	0x1004eb560 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x390>
1004eb508:     	ldurb	w9, [x29, #-0x60]
1004eb50c:     	tbnz	w9, #0x0, 0x1004eb4a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x2d4>
1004eb510:     	ldr	w9, [x24, #0x4]
1004eb514:     	cmp	w8, w9
1004eb518:     	b.hs	0x1004eb540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x370>
1004eb51c:     	mov	w1, w8
1004eb520:     	mov	x0, x24
1004eb524:     	bl	0x10052702c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array15header_gc_slots27note_array_slot_layout_only>
1004eb528:     	ldr	w8, [x24]
1004eb52c:     	add	w8, w8, #0x1
1004eb530:     	str	w8, [x24]
1004eb534:     	subs	x25, x25, #0x8
1004eb538:     	b.ne	0x1004eb4f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x328>
1004eb53c:     	b	0x1004eb588 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3b8>
1004eb540:     	fmov	d0, x2
1004eb544:     	mov	x0, x24
1004eb548:     	bl	0x1007c83a8 <_js_array_push_f64>
1004eb54c:     	mov	x24, x0
1004eb550:     	stur	x0, [x29, #-0x68]
1004eb554:     	subs	x25, x25, #0x8
1004eb558:     	b.ne	0x1004eb4f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x328>
1004eb55c:     	b	0x1004eb588 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3b8>
1004eb560:     	sub	x0, x29, #0x68
1004eb564:     	add	x1, sp, #0x278
1004eb568:     	mov	x24, x2
1004eb56c:     	bl	0x100b387cc <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray4grow>
1004eb570:     	mov	x2, x24
1004eb574:     	ldur	x24, [x29, #-0x68]
1004eb578:     	ldr	w8, [x24]
1004eb57c:     	ldurb	w9, [x29, #-0x60]
1004eb580:     	tbnz	w9, #0x0, 0x1004eb4a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x2d4>
1004eb584:     	b	0x1004eb510 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x340>
1004eb588:     	ldur	x24, [x29, #-0x68]
1004eb58c:     	sub	x23, x29, #0xf0
1004eb590:     	sub	x0, x29, #0x68
1004eb594:     	ldr	x1, [sp, #0x18]
1004eb598:     	bl	0x10023348c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray13finish_layout>
1004eb59c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1004eb5a0:     	bfxil	x8, x24, #0, #48
1004eb5a4:     	str	x8, [x23, x27, lsl #3]
1004eb5a8:     	add	x27, x27, #0x1
1004eb5ac:     	mov	x8, x26
1004eb5b0:     	cmp	x26, x28
1004eb5b4:     	b.ne	0x1004eb454 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x284>
1004eb5b8:     	add	x0, sp, #0x278
1004eb5bc:     	sub	x3, x29, #0xf0
1004eb5c0:     	ldp	x1, x4, [sp, #0x8]
1004eb5c4:     	ldr	w2, [sp, #0x4]
1004eb5c8:     	bl	0x1005ba348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
1004eb5cc:     	adrp	x21, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb5d0:     	ldr	w8, [sp]
1004eb5d4:     	tbz	w8, #0x0, 0x1004eb63c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x46c>
1004eb5d8:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1004eb5dc:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1004eb5e0:     	ldr	x8, [x8, #0x758]
1004eb5e4:     	cbnz	x8, 0x1004eb690 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4c0>
1004eb5e8:     	bfxil	x19, x0, #0, #48
1004eb5ec:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb5f0:     	ldr	w20, [x8, #0x930]
1004eb5f4:     	cmp	w20, #0x300
1004eb5f8:     	b.hs	0x1004eb734 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x564>
1004eb5fc:     	ldr	x8, [x21, #0x48]
1004eb600:     	cmn	x8, #0x1
1004eb604:     	b.eq	0x1004eb724 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x554>
1004eb608:     	mrs	x9, TPIDRRO_EL0
1004eb60c:     	and	x9, x9, #0xfffffffffffffff8
1004eb610:     	ldr	x0, [x9, x8, lsl #3]
1004eb614:     	cbz	x0, 0x1004eb724 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x554>
1004eb618:     	add	x8, x0, x20, lsl #3
1004eb61c:     	ldr	x0, [x8, #0x1e8]
1004eb620:     	cbz	x0, 0x1004eb734 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x564>
1004eb624:     	ldrb	w8, [x0]
1004eb628:     	cbz	w8, 0x1004eb748 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x578>
1004eb62c:     	sub	w8, w8, #0x1
1004eb630:     	strb	w8, [x0]
1004eb634:     	mov	w0, #0x1                ; =1
1004eb638:     	b	0x1004eb300 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x130>
1004eb63c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eb640:     	ldr	w19, [x8, #0x308]
1004eb644:     	cmp	w19, #0x300
1004eb648:     	b.hs	0x1004eb778 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5a8>
1004eb64c:     	ldr	x8, [x21, #0x48]
1004eb650:     	cmn	x8, #0x1
1004eb654:     	b.eq	0x1004eb75c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x58c>
1004eb658:     	mrs	x9, TPIDRRO_EL0
1004eb65c:     	and	x9, x9, #0xfffffffffffffff8
1004eb660:     	ldr	x8, [x9, x8, lsl #3]
1004eb664:     	cbz	x8, 0x1004eb75c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x58c>
1004eb668:     	add	x8, x8, x19, lsl #3
1004eb66c:     	ldr	x8, [x8, #0x1e8]
1004eb670:     	cbz	x8, 0x1004eb778 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5a8>
1004eb674:     	ldrb	w9, [x8]
1004eb678:     	and	w9, w9, #0xfffffffd
1004eb67c:     	strb	w9, [x8]
1004eb680:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1004eb684:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1004eb688:     	ldr	x8, [x8, #0x758]
1004eb68c:     	cbz	x8, 0x1004eb5e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x418>
1004eb690:     	mov	x20, x0
1004eb694:     	bl	0x100b43830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
1004eb698:     	bfxil	x19, x20, #0, #48
1004eb69c:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eb6a0:     	ldr	w20, [x8, #0x930]
1004eb6a4:     	cmp	w20, #0x300
1004eb6a8:     	b.lo	0x1004eb5fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x42c>
1004eb6ac:     	b	0x1004eb734 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x564>
1004eb6b0:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb6b4:     	add	x8, x0, x20, lsl #3
1004eb6b8:     	ldr	x0, [x8, #0x1e8]
1004eb6bc:     	cbnz	x0, 0x1004eb2a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0xd4>
1004eb6c0:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1004eb6c4:     	add	x0, x0, #0xca8
1004eb6c8:     	bl	0x100b3a9a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb6cc:     	ldrb	w8, [x0]
1004eb6d0:     	cbz	w8, 0x1004eb2ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0xdc>
1004eb6d4:     	bl	0x100b420dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
1004eb6d8:     	ldr	w19, [x19, #0x578]
1004eb6dc:     	cmp	w19, #0x300
1004eb6e0:     	b.lo	0x1004eb2b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0xe8>
1004eb6e4:     	b	0x1004eb6f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x528>
1004eb6e8:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb6ec:     	add	x8, x0, x19, lsl #3
1004eb6f0:     	ldr	x22, [x8, #0x1e8]
1004eb6f4:     	cbnz	x22, 0x1004eb2e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x110>
1004eb6f8:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004eb6fc:     	add	x0, x0, #0xfb8
1004eb700:     	bl	0x100b3a95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004eb704:     	mov	x22, x0
1004eb708:     	ldr	x8, [x0]
1004eb70c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1004eb710:     	cmp	x8, x9
1004eb714:     	b.lo	0x1004eb2f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x120>
1004eb718:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb71c:     	add	x0, x0, #0xd58
1004eb720:     	bl	0x100b1049c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1004eb724:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb728:     	add	x8, x0, x20, lsl #3
1004eb72c:     	ldr	x0, [x8, #0x1e8]
1004eb730:     	cbnz	x0, 0x1004eb624 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x454>
1004eb734:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1004eb738:     	add	x0, x0, #0xc78
1004eb73c:     	bl	0x100b3a9a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb740:     	ldrb	w8, [x0]
1004eb744:     	cbnz	w8, 0x1004eb62c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x45c>
1004eb748:     	mov	w8, #0x3f               ; =63
1004eb74c:     	strb	w8, [x0]
1004eb750:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
1004eb754:     	mov	w0, #0x1                ; =1
1004eb758:     	b	0x1004eb300 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x130>
1004eb75c:     	mov	x20, x0
1004eb760:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb764:     	mov	x8, x0
1004eb768:     	mov	x0, x20
1004eb76c:     	add	x8, x8, x19, lsl #3
1004eb770:     	ldr	x8, [x8, #0x1e8]
1004eb774:     	cbnz	x8, 0x1004eb674 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4a4>
1004eb778:     	adrp	x8, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1004eb77c:     	add	x8, x8, #0xcd8
1004eb780:     	mov	x19, x0
1004eb784:     	mov	x0, x8
1004eb788:     	bl	0x100b3a9a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb78c:     	mov	x8, x0
1004eb790:     	mov	x0, x19
1004eb794:     	b	0x1004eb674 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4a4>
1004eb798:     	adrp	x3, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004eb79c:     	add	x3, x3, #0xfe8
1004eb7a0:     	mov	x0, #0x0                ; =0
1004eb7a4:     	mov	x1, x25
1004eb7a8:     	mov	w2, #0x8                ; =8
1004eb7ac:     	bl	0x100b1078c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1004eb7b0:     	adrp	x3, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1004eb7b4:     	add	x3, x3, #0x0
1004eb7b8:     	mov	x0, #0x0                ; =0
1004eb7bc:     	mov	x1, x21
1004eb7c0:     	mov	w2, #0x8                ; =8
1004eb7c4:     	bl	0x100b1078c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
