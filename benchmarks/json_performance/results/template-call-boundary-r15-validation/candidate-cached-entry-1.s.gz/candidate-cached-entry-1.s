
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-call-boundary-r15/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100503978 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>:
100503978:     	stp	x28, x27, [sp, #-0x60]!
10050397c:     	stp	x26, x25, [sp, #0x10]
100503980:     	stp	x24, x23, [sp, #0x20]
100503984:     	stp	x22, x21, [sp, #0x30]
100503988:     	stp	x20, x19, [sp, #0x40]
10050398c:     	stp	x29, x30, [sp, #0x50]
100503990:     	add	x29, sp, #0x50
100503994:     	sub	sp, sp, #0x1a0
100503998:     	mov	x19, x1
10050399c:     	mov	x21, x0
1005039a0:     	bl	0x1004eb1d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template>
1005039a4:     	cmp	x0, #0x1
1005039a8:     	b.ne	0x1005039d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c>
1005039ac:     	mov	x23, x1
1005039b0:     	mov	x0, x23
1005039b4:     	add	sp, sp, #0x1a0
1005039b8:     	ldp	x29, x30, [sp, #0x50]
1005039bc:     	ldp	x20, x19, [sp, #0x40]
1005039c0:     	ldp	x22, x21, [sp, #0x30]
1005039c4:     	ldp	x24, x23, [sp, #0x20]
1005039c8:     	ldp	x26, x25, [sp, #0x10]
1005039cc:     	ldp	x28, x27, [sp], #0x60
1005039d0:     	ret
1005039d4:     	add	x24, x21, #0x14
1005039d8:     	cmp	x19, #0x2
1005039dc:     	b.ne	0x1005039f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c>
1005039e0:     	ldrh	w8, [x24]
1005039e4:     	mov	w9, #0x7d7b             ; =32123
1005039e8:     	cmp	w8, w9
1005039ec:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005039f0:     	b	0x100503a8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x114>
1005039f4:     	cmp	x19, #0x3
1005039f8:     	b.hs	0x100503a60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe8>
1005039fc:     	add	x0, sp, #0xa0
100503a00:     	add	x1, x21, #0x14
100503a04:     	mov	x2, x19
100503a08:     	bl	0x1004f3c58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object6decode>
100503a0c:     	ldr	w8, [sp, #0xa0]
100503a10:     	tbz	w8, #0x0, 0x100503b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100503a14:     	add	x8, sp, #0xa0
100503a18:     	ldr	x9, [sp, #0x128]
100503a1c:     	str	x9, [sp, #0x90]
100503a20:     	ldur	q0, [x8, #0x48]
100503a24:     	ldur	q1, [x8, #0x58]
100503a28:     	stp	q0, q1, [sp, #0x50]
100503a2c:     	ldur	q0, [x8, #0x68]
100503a30:     	ldur	q1, [x8, #0x78]
100503a34:     	stp	q0, q1, [sp, #0x70]
100503a38:     	ldur	q0, [x8, #0x8]
100503a3c:     	ldur	q1, [x8, #0x18]
100503a40:     	stp	q0, q1, [sp, #0x10]
100503a44:     	ldur	q0, [x8, #0x28]
100503a48:     	ldur	q1, [x8, #0x38]
100503a4c:     	stp	q0, q1, [sp, #0x30]
100503a50:     	add	x0, sp, #0x10
100503a54:     	bl	0x1004f4408 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object8allocate>
100503a58:     	tbnz	w0, #0x0, 0x1005039ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x34>
100503a5c:     	b	0x100503b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100503a60:     	ldrb	w20, [x24]
100503a64:     	cmp	w20, #0x20
100503a68:     	b.hi	0x100503aac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x134>
100503a6c:     	mov	x8, #0x2600             ; =9728
100503a70:     	movk	x8, #0x1, lsl #32
100503a74:     	lsr	x8, x8, x20
100503a78:     	tbz	w8, #0x0, 0x100503aac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x134>
100503a7c:     	add	x0, x21, #0x14
100503a80:     	mov	x1, x19
100503a84:     	bl	0x1004ea3a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty19padded_empty_object>
100503a88:     	tbz	w0, #0x0, 0x100503ad8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160>
100503a8c:     	add	sp, sp, #0x1a0
100503a90:     	ldp	x29, x30, [sp, #0x50]
100503a94:     	ldp	x20, x19, [sp, #0x40]
100503a98:     	ldp	x22, x21, [sp, #0x30]
100503a9c:     	ldp	x24, x23, [sp, #0x20]
100503aa0:     	ldp	x26, x25, [sp, #0x10]
100503aa4:     	ldp	x28, x27, [sp], #0x60
100503aa8:     	b	0x1004ea480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100503aac:     	cmp	w20, #0x7b
100503ab0:     	b.ne	0x100503ad8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160>
100503ab4:     	ldrb	w8, [x21, #0x15]
100503ab8:     	cmp	w8, #0x20
100503abc:     	b.hi	0x100503ad0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x158>
100503ac0:     	mov	x9, #0x2600             ; =9728
100503ac4:     	movk	x9, #0x1, lsl #32
100503ac8:     	lsr	x9, x9, x8
100503acc:     	tbnz	w9, #0x0, 0x100503a7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100503ad0:     	cmp	w8, #0x7d
100503ad4:     	b.eq	0x100503a7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100503ad8:     	cmp	x19, #0x41
100503adc:     	b.hs	0x100503b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100503ae0:     	cmp	w20, #0x7b
100503ae4:     	ccmp	x19, #0x7, #0x0, eq
100503ae8:     	b.lo	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503aec:     	add	x8, x24, x19
100503af0:     	ldurb	w8, [x8, #-0x1]
100503af4:     	cmp	w8, #0x7d
100503af8:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503afc:     	ldrb	w8, [x21, #0x15]
100503b00:     	cmp	w8, #0x22
100503b04:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503b08:     	sub	x9, x19, #0x1
100503b0c:     	mov	x22, x21
100503b10:     	ldrb	w25, [x22, #0x16]!
100503b14:     	cmp	w25, #0x22
100503b18:     	b.ne	0x100503ba8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x230>
100503b1c:     	mov	w23, #0x0               ; =0
100503b20:     	mov	w28, #0x0               ; =0
100503b24:     	mov	w27, #0x0               ; =0
100503b28:     	mov	w26, #0x0               ; =0
100503b2c:     	mov	x20, #0x0               ; =0
100503b30:     	cmp	w25, #0x22
100503b34:     	b.ne	0x100503bd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x25c>
100503b38:     	add	x8, sp, #0xa0
100503b3c:     	mov	x0, x22
100503b40:     	mov	x1, x20
100503b44:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100503b48:     	sub	x11, x19, #0x1
100503b4c:     	ldr	w8, [sp, #0xa0]
100503b50:     	tbnz	w8, #0x0, 0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503b54:     	cmp	w25, #0x22
100503b58:     	b.ne	0x100503c78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x300>
100503b5c:     	mov	x8, #0x0                ; =0
100503b60:     	b	0x100503cac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503b64:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100503b68:     	add	x8, x8, #0x2d8
100503b6c:     	ldapr	x8, [x8]
100503b70:     	cbnz	x8, 0x100503d44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3cc>
100503b74:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100503b78:     	ldrb	w8, [x8, #0x2e0]
100503b7c:     	adrp	x12, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100503b80:     	adrp	x27, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100503b84:     	cbz	w8, 0x100503d5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3e4>
100503b88:     	cmp	w8, #0x1
100503b8c:     	b.ne	0x100503d98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100503b90:     	mov	w28, #0x1               ; =1
100503b94:     	mov	w8, #0x1000000          ; =16777216
100503b98:     	mov	w22, #0x1               ; =1
100503b9c:     	cmp	x19, x8
100503ba0:     	b.hi	0x100503d9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x424>
100503ba4:     	b	0x100503e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x508>
100503ba8:     	cmp	x9, #0x3
100503bac:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503bb0:     	ldrb	w8, [x21, #0x17]
100503bb4:     	cmp	w8, #0x22
100503bb8:     	b.ne	0x100503c4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x2d4>
100503bbc:     	mov	w28, #0x0               ; =0
100503bc0:     	mov	w27, #0x0               ; =0
100503bc4:     	mov	w26, #0x0               ; =0
100503bc8:     	mov	w23, #0x1               ; =1
100503bcc:     	mov	w20, #0x1               ; =1
100503bd0:     	b	0x100503b30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100503bd4:     	ldrb	w8, [x22]
100503bd8:     	cmp	w8, #0x20
100503bdc:     	b.lo	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503be0:     	cmp	w8, #0x5c
100503be4:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503be8:     	tbnz	w23, #0x0, 0x100503b38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503bec:     	ldrb	w8, [x21, #0x17]
100503bf0:     	cmp	w8, #0x20
100503bf4:     	b.lo	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503bf8:     	cmp	w8, #0x5c
100503bfc:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c00:     	tbnz	w28, #0x0, 0x100503b38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503c04:     	ldrb	w8, [x21, #0x18]
100503c08:     	cmp	w8, #0x20
100503c0c:     	b.lo	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c10:     	cmp	w8, #0x5c
100503c14:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c18:     	tbnz	w27, #0x0, 0x100503b38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503c1c:     	ldrb	w8, [x21, #0x19]
100503c20:     	cmp	w8, #0x20
100503c24:     	b.lo	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c28:     	cmp	w8, #0x5c
100503c2c:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c30:     	tbnz	w26, #0x0, 0x100503b38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503c34:     	ldrb	w8, [x21, #0x1a]
100503c38:     	cmp	w8, #0x20
100503c3c:     	b.lo	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c40:     	cmp	w8, #0x5c
100503c44:     	b.ne	0x100503b38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503c48:     	b	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c4c:     	cmp	x9, #0x4
100503c50:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c54:     	ldrb	w8, [x21, #0x18]
100503c58:     	cmp	w8, #0x22
100503c5c:     	b.ne	0x100503d18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3a0>
100503c60:     	mov	w23, #0x0               ; =0
100503c64:     	mov	w27, #0x0               ; =0
100503c68:     	mov	w26, #0x0               ; =0
100503c6c:     	mov	w28, #0x1               ; =1
100503c70:     	mov	w20, #0x2               ; =2
100503c74:     	b	0x100503b30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100503c78:     	ldrb	w8, [x22]
100503c7c:     	tbnz	w23, #0x0, 0x100503cac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503c80:     	ldrb	w9, [x21, #0x17]
100503c84:     	orr	x8, x8, x9, lsl #8
100503c88:     	tbnz	w28, #0x0, 0x100503cac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503c8c:     	ldrb	w9, [x21, #0x18]
100503c90:     	orr	x8, x8, x9, lsl #16
100503c94:     	tbnz	w27, #0x0, 0x100503cac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503c98:     	ldrb	w9, [x21, #0x19]
100503c9c:     	orr	x8, x8, x9, lsl #24
100503ca0:     	tbnz	w26, #0x0, 0x100503cac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503ca4:     	ldrb	w9, [x21, #0x1a]
100503ca8:     	orr	x8, x8, x9, lsl #32
100503cac:     	add	x9, x20, #0x3
100503cb0:     	cmp	x9, x19
100503cb4:     	b.hs	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503cb8:     	ldrb	w9, [x24, x9]
100503cbc:     	cmp	w9, #0x3a
100503cc0:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503cc4:     	add	x10, x20, #0x4
100503cc8:     	subs	x9, x11, x10
100503ccc:     	b.lo	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503cd0:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503cd4:     	orr	x25, x8, x20, lsl #40
100503cd8:     	mov	x26, #0x7ff9000000000000 ; =9221401712017801216
100503cdc:     	add	x8, x24, x10
100503ce0:     	mov	x10, #0x2600            ; =9728
100503ce4:     	movk	x10, #0x1, lsl #32
100503ce8:     	mov	x11, x9
100503cec:     	mov	x12, x8
100503cf0:     	b	0x100503d00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x388>
100503cf4:     	add	x12, x12, #0x1
100503cf8:     	subs	x11, x11, #0x1
100503cfc:     	b.eq	0x100504ba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x122c>
100503d00:     	ldrb	w13, [x12]
100503d04:     	cmp	w13, #0x20
100503d08:     	b.hi	0x100503cf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x37c>
100503d0c:     	lsr	x13, x10, x13
100503d10:     	tbz	w13, #0x0, 0x100503cf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x37c>
100503d14:     	b	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503d18:     	cmp	x9, #0x5
100503d1c:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503d20:     	ldrb	w8, [x21, #0x19]
100503d24:     	cmp	w8, #0x22
100503d28:     	b.ne	0x100504af0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1178>
100503d2c:     	mov	w23, #0x0               ; =0
100503d30:     	mov	w28, #0x0               ; =0
100503d34:     	mov	w26, #0x0               ; =0
100503d38:     	mov	w27, #0x1               ; =1
100503d3c:     	mov	w20, #0x3               ; =3
100503d40:     	b	0x100503b30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100503d44:     	bl	0x100b16bc4 <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockNtNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api8TapeModeE10initializeNCINvB2_11get_or_initNCNvBV_18tape_mode_from_env0E0zEBZ_>
100503d48:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100503d4c:     	ldrb	w8, [x8, #0x2e0]
100503d50:     	adrp	x12, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100503d54:     	adrp	x27, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100503d58:     	cbnz	w8, 0x100503b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x210>
100503d5c:     	sub	x8, x19, #0x400
100503d60:     	mov	w9, #0xfffc00           ; =16776192
100503d64:     	cmp	x8, x9
100503d68:     	b.hi	0x100503d98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100503d6c:     	mov	x8, #0x0                ; =0
100503d70:     	mov	x9, #0x2600             ; =9728
100503d74:     	movk	x9, #0x1, lsl #32
100503d78:     	ldrb	w10, [x24, x8]
100503d7c:     	cmp	w10, #0x20
100503d80:     	b.hi	0x100504278 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x900>
100503d84:     	lsr	x11, x9, x10
100503d88:     	tbz	w11, #0x0, 0x100504278 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x900>
100503d8c:     	add	x8, x8, #0x1
100503d90:     	cmp	x19, x8
100503d94:     	b.ne	0x100503d78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x400>
100503d98:     	mov	w22, #0x0               ; =0
100503d9c:     	ldr	w20, [x12, #0x560]
100503da0:     	cmp	w20, #0x300
100503da4:     	b.hs	0x100504250 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d8>
100503da8:     	ldr	x8, [x27, #0x48]
100503dac:     	cmn	x8, #0x1
100503db0:     	b.eq	0x100504240 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8c8>
100503db4:     	mrs	x9, TPIDRRO_EL0
100503db8:     	and	x9, x9, #0xfffffffffffffff8
100503dbc:     	ldr	x0, [x9, x8, lsl #3]
100503dc0:     	cbz	x0, 0x100504240 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8c8>
100503dc4:     	add	x8, x0, x20, lsl #3
100503dc8:     	ldr	x0, [x8, #0x1e8]
100503dcc:     	cbz	x0, 0x100504250 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d8>
100503dd0:     	ldr	x8, [x0]
100503dd4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100503dd8:     	cmp	x8, x9
100503ddc:     	b.hs	0x10050426c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8f4>
100503de0:     	ldrb	w8, [x0, #0x24]
100503de4:     	cmp	w8, #0x2
100503de8:     	b.eq	0x100503df8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x480>
100503dec:     	ldr	x9, [x0, #0x8]
100503df0:     	cmp	x9, x21
100503df4:     	b.eq	0x100503e60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4e8>
100503df8:     	cmp	x19, #0x3e9
100503dfc:     	b.lo	0x100503e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100503e00:     	mov	x8, #0x0                ; =0
100503e04:     	mov	x9, #0x2600             ; =9728
100503e08:     	movk	x9, #0x1, lsl #32
100503e0c:     	add	x10, x21, x8
100503e10:     	ldrb	w10, [x10, #0x14]
100503e14:     	cmp	w10, #0x20
100503e18:     	b.hi	0x100503e34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4bc>
100503e1c:     	lsr	x11, x9, x10
100503e20:     	tbz	w11, #0x0, 0x100503e34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4bc>
100503e24:     	add	x8, x8, #0x1
100503e28:     	cmp	x19, x8
100503e2c:     	b.ne	0x100503e0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x494>
100503e30:     	b	0x100503e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100503e34:     	cmp	w10, #0x5b
100503e38:     	b.eq	0x100503e44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4cc>
100503e3c:     	cmp	w10, #0x7b
100503e40:     	b.ne	0x100503e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100503e44:     	add	x0, x21, #0x14
100503e48:     	mov	x1, x19
100503e4c:     	mov	w2, #0x3e8              ; =1000
100503e50:     	bl	0x1006c2894 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
100503e54:     	cbz	w0, 0x100503e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100503e58:     	mov	x0, x21
100503e5c:     	b	0x100504ab0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1138>
100503e60:     	ldr	w9, [x0, #0x18]
100503e64:     	cmp	x19, x9
100503e68:     	cset	w9, eq
100503e6c:     	and	w8, w9, w8
100503e70:     	cmp	x19, #0x3e9
100503e74:     	csinc	w8, w8, wzr, hs
100503e78:     	tbz	w8, #0x0, 0x100503e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x488>
100503e7c:     	mov	w28, #0x0               ; =0
100503e80:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100503e84:     	add	x0, x0, #0xce8
100503e88:     	ldr	x8, [x0]
100503e8c:     	blr	x8
100503e90:     	mov	x20, x0
100503e94:     	ldrb	w8, [x0, #0x20]
100503e98:     	cbnz	w8, 0x100504a08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1090>
100503e9c:     	ldr	x8, [x20]
100503ea0:     	cbnz	x8, 0x100504a84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100503ea4:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
100503ea8:     	bfxil	x23, x21, #0, #48
100503eac:     	mov	x8, #-0x1               ; =-1
100503eb0:     	str	x8, [x20]
100503eb4:     	ldr	x21, [x20, #0x18]
100503eb8:     	ldr	x8, [x20, #0x8]
100503ebc:     	cmp	x21, x8
100503ec0:     	b.eq	0x100504204 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x88c>
100503ec4:     	ldr	x8, [x20, #0x10]
100503ec8:     	str	x23, [x8, x21, lsl #3]
100503ecc:     	add	x8, x21, #0x1
100503ed0:     	str	x8, [x20, #0x18]
100503ed4:     	ldr	x8, [x20]
100503ed8:     	add	x8, x8, #0x1
100503edc:     	str	x8, [x20]
100503ee0:     	adrp	x24, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100503ee4:     	ldr	w23, [x24, #0x948]
100503ee8:     	cmp	w23, #0x300
100503eec:     	b.hs	0x100504220 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8a8>
100503ef0:     	ldr	x8, [x27, #0x48]
100503ef4:     	cmn	x8, #0x1
100503ef8:     	b.eq	0x100504210 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x898>
100503efc:     	mrs	x9, TPIDRRO_EL0
100503f00:     	and	x9, x9, #0xfffffffffffffff8
100503f04:     	ldr	x0, [x9, x8, lsl #3]
100503f08:     	cbz	x0, 0x100504210 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x898>
100503f0c:     	add	x8, x0, x23, lsl #3
100503f10:     	ldr	x0, [x8, #0x1e8]
100503f14:     	cbz	x0, 0x100504220 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8a8>
100503f18:     	ldrb	w8, [x0]
100503f1c:     	cbnz	w8, 0x100504234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8bc>
100503f20:     	tbz	w22, #0x0, 0x1005045a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100503f24:     	ldrb	w8, [x20, #0x20]
100503f28:     	cbnz	w8, 0x100504ac0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1148>
100503f2c:     	ldr	x8, [x20]
100503f30:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100503f34:     	cmp	x8, x9
100503f38:     	b.hs	0x100504c04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100503f3c:     	add	x9, x8, #0x1
100503f40:     	str	x9, [x20]
100503f44:     	ldr	x9, [x20, #0x18]
100503f48:     	cmp	x21, x9
100503f4c:     	b.hs	0x100503f60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5e8>
100503f50:     	ldr	x9, [x20, #0x10]
100503f54:     	ldr	x9, [x9, x21, lsl #3]
100503f58:     	and	x23, x9, #0xffffffffffff
100503f5c:     	b	0x100503f64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5ec>
100503f60:     	mov	w23, #0x1               ; =1
100503f64:     	str	x8, [x20]
100503f68:     	adrp	x0, 0x100f84000 <__RNvNCNKNvNtCs3gRpqoBkMHm_13perry_runtime7process29PROCESS_FINALIZATION_EXIT_RAN0s_023___RUST_STD_INTERNAL_VAL>
100503f6c:     	add	x0, x0, #0x168
100503f70:     	ldr	x8, [x0]
100503f74:     	blr	x8
100503f78:     	mov	x22, x0
100503f7c:     	ldrb	w8, [x0, #0x30]
100503f80:     	cmp	w8, #0x1
100503f84:     	b.ne	0x100504a90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1118>
100503f88:     	ldr	x8, [x22]
100503f8c:     	mov	x10, #-0x1              ; =-1
100503f90:     	mov	x9, x22
100503f94:     	str	x10, [x9], #0x8
100503f98:     	cmn	x8, #0x1
100503f9c:     	b.eq	0x100503fbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x644>
100503fa0:     	add	x10, sp, #0xa0
100503fa4:     	ldp	q0, q1, [x9]
100503fa8:     	ldr	x9, [x9, #0x20]
100503fac:     	stur	x9, [x10, #0x28]
100503fb0:     	stur	q1, [x10, #0x18]
100503fb4:     	stur	q0, [x10, #0x8]
100503fb8:     	b	0x100503fd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x658>
100503fbc:     	mov	x8, #0x0                ; =0
100503fc0:     	mov	w9, #0x4                ; =4
100503fc4:     	stp	x9, xzr, [sp, #0xa8]
100503fc8:     	stp	xzr, x9, [sp, #0xb8]
100503fcc:     	str	xzr, [sp, #0xc8]
100503fd0:     	str	x8, [sp, #0xa0]
100503fd4:     	stur	xzr, [x29, #-0x78]
100503fd8:     	add	x8, sp, #0xa0
100503fdc:     	add	x0, x23, #0x14
100503fe0:     	add	x2, sp, #0xa0
100503fe4:     	add	x3, x8, #0x18
100503fe8:     	sub	x4, x29, #0x78
100503fec:     	mov	x1, x19
100503ff0:     	bl	0x10014e764 <__RINvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15build_tape_intoKb1_EB4_>
100503ff4:     	tbz	w0, #0x0, 0x100504104 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x78c>
100503ff8:     	ldur	x23, [x29, #-0x78]
100503ffc:     	ldr	w24, [x24, #0x948]
100504000:     	cmp	w24, #0x300
100504004:     	b.hs	0x10050491c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa4>
100504008:     	ldr	x8, [x27, #0x48]
10050400c:     	cmn	x8, #0x1
100504010:     	b.eq	0x10050490c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf94>
100504014:     	mrs	x9, TPIDRRO_EL0
100504018:     	and	x9, x9, #0xfffffffffffffff8
10050401c:     	ldr	x0, [x9, x8, lsl #3]
100504020:     	cbz	x0, 0x10050490c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf94>
100504024:     	add	x8, x0, x24, lsl #3
100504028:     	ldr	x0, [x8, #0x1e8]
10050402c:     	cbz	x0, 0x10050491c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa4>
100504030:     	ldrb	w8, [x0]
100504034:     	cbnz	w8, 0x100504930 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfb8>
100504038:     	bl	0x1004edb00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
10050403c:     	bl	0x100457940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
100504040:     	mov	x0, x19
100504044:     	bl	0x10022fa2c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
100504048:     	mov	x24, x0
10050404c:     	mov	x25, x1
100504050:     	bl	0x100457754 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
100504054:     	ldrb	w8, [x20, #0x20]
100504058:     	cbnz	w8, 0x100504b4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11d4>
10050405c:     	ldr	x8, [x20]
100504060:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504064:     	cmp	x8, x9
100504068:     	b.hs	0x100504c04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
10050406c:     	add	x9, x8, #0x1
100504070:     	str	x9, [x20]
100504074:     	ldr	x9, [x20, #0x18]
100504078:     	cmp	x21, x9
10050407c:     	b.hs	0x10050419c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x824>
100504080:     	ldr	x9, [x20, #0x10]
100504084:     	ldr	x9, [x9, x21, lsl #3]
100504088:     	and	x2, x9, #0xffffffffffff
10050408c:     	stp	x25, x24, [sp]
100504090:     	str	x8, [x20]
100504094:     	add	x26, x2, #0x14
100504098:     	cmp	x23, #0x3e8
10050409c:     	b.hi	0x1005041b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x83c>
1005040a0:     	ldp	x24, x25, [sp, #0xa8]
1005040a4:     	cbz	x25, 0x1005041d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x858>
1005040a8:     	ldrb	w8, [x24, #0x8]
1005040ac:     	cmp	w8, #0x3
1005040b0:     	b.ne	0x1005041d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x858>
1005040b4:     	ldr	w8, [x24, #0x4]
1005040b8:     	cmp	w8, #0x2
1005040bc:     	b.lo	0x1005042a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x928>
1005040c0:     	mov	w1, #0x0                ; =0
1005040c4:     	mov	w0, #0x1                ; =1
1005040c8:     	mov	w9, #0xc                ; =12
1005040cc:     	b	0x1005040e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x768>
1005040d0:     	add	x0, x0, #0x1
1005040d4:     	add	w1, w1, #0x1
1005040d8:     	cmp	x0, x8
1005040dc:     	b.hs	0x1005042a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x92c>
1005040e0:     	cmp	x0, x25
1005040e4:     	b.hs	0x100504d00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1388>
1005040e8:     	madd	x10, x0, x9, x24
1005040ec:     	ldrb	w11, [x10, #0x8]
1005040f0:     	orr	w11, w11, #0x2
1005040f4:     	cmp	w11, #0x3
1005040f8:     	b.ne	0x1005040d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x758>
1005040fc:     	ldr	w0, [x10, #0x4]
100504100:     	b	0x1005040d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x758>
100504104:     	str	xzr, [sp, #0xb0]
100504108:     	str	xzr, [sp, #0xc8]
10050410c:     	ldr	x8, [sp, #0xa0]
100504110:     	add	x9, x8, x8, lsl #1
100504114:     	lsl	x9, x9, #2
100504118:     	cmp	x9, #0x100, lsl #12     ; =0x100000
10050411c:     	b.ls	0x100504138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c0>
100504120:     	cbz	x8, 0x10050412c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7b4>
100504124:     	ldr	x0, [sp, #0xa8]
100504128:     	bl	0x100b5cd40 <_mi_free>
10050412c:     	mov	w8, #0x4                ; =4
100504130:     	stp	xzr, x8, [sp, #0xa0]
100504134:     	str	xzr, [sp, #0xb0]
100504138:     	ldr	x8, [sp, #0xb8]
10050413c:     	lsl	x9, x8, #2
100504140:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100504144:     	b.ls	0x100504160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7e8>
100504148:     	cbz	x8, 0x100504154 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7dc>
10050414c:     	ldr	x0, [sp, #0xc0]
100504150:     	bl	0x100b5cd40 <_mi_free>
100504154:     	mov	w8, #0x4                ; =4
100504158:     	stp	xzr, x8, [sp, #0xb8]
10050415c:     	str	xzr, [sp, #0xc8]
100504160:     	ldp	x8, x0, [x22]
100504164:     	ldp	x24, x23, [x22, #0x18]
100504168:     	ldp	q1, q0, [sp, #0xb0]
10050416c:     	ldr	q2, [sp, #0xa0]
100504170:     	stp	q2, q1, [x22]
100504174:     	str	q0, [x22, #0x20]
100504178:     	cmn	x8, #0x1
10050417c:     	b.eq	0x100504194 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x81c>
100504180:     	cbz	x8, 0x100504188 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x810>
100504184:     	bl	0x100b5cd40 <_mi_free>
100504188:     	cbz	x24, 0x100504194 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x81c>
10050418c:     	mov	x0, x23
100504190:     	bl	0x100b5cd40 <_mi_free>
100504194:     	ldrb	w8, [x20, #0x20]
100504198:     	b	0x1005044cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb54>
10050419c:     	mov	w2, #0x1                ; =1
1005041a0:     	stp	x25, x24, [sp]
1005041a4:     	str	x8, [x20]
1005041a8:     	add	x26, x2, #0x14
1005041ac:     	cmp	x23, #0x3e8
1005041b0:     	b.ls	0x1005040a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x728>
1005041b4:     	ldp	x0, x1, [sp, #0xa8]
1005041b8:     	mov	x2, x26
1005041bc:     	mov	x3, x19
1005041c0:     	bl	0x100686354 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape9iterative21materialize_iterative>
1005041c4:     	tbz	w0, #0x0, 0x1005041fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x884>
1005041c8:     	mov	x25, x1
1005041cc:     	b	0x1005042f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x97c>
1005041d0:     	bl	0x100288f98 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
1005041d4:     	stp	x0, xzr, [x29, #-0x70]
1005041d8:     	stp	x24, x25, [sp, #0x10]
1005041dc:     	stp	x26, x19, [sp, #0x20]
1005041e0:     	add	x0, sp, #0x10
1005041e4:     	sub	x1, x29, #0x68
1005041e8:     	bl	0x100375960 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24materialize_value_source>
1005041ec:     	mov	x25, x0
1005041f0:     	sub	x0, x29, #0x70
1005041f4:     	bl	0x1001649fc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1005041f8:     	b	0x1005042f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x97c>
1005041fc:     	mov	w25, #0x0               ; =0
100504200:     	b	0x10050433c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9c4>
100504204:     	add	x0, x20, #0x8
100504208:     	bl	0x100b39aac <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10050420c:     	b	0x100503ec4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x54c>
100504210:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504214:     	add	x8, x0, x23, lsl #3
100504218:     	ldr	x0, [x8, #0x1e8]
10050421c:     	cbnz	x0, 0x100503f18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5a0>
100504220:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
100504224:     	add	x0, x0, #0xcf0
100504228:     	bl	0x100b3aa28 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
10050422c:     	ldrb	w8, [x0]
100504230:     	cbz	w8, 0x100503f20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5a8>
100504234:     	bl	0x100b4215c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
100504238:     	tbnz	w22, #0x0, 0x100503f24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5ac>
10050423c:     	b	0x1005045a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100504240:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504244:     	add	x8, x0, x20, lsl #3
100504248:     	ldr	x0, [x8, #0x1e8]
10050424c:     	cbnz	x0, 0x100503dd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x458>
100504250:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1e70>
100504254:     	add	x0, x0, #0xfe8
100504258:     	bl	0x100b3a9dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10050425c:     	ldr	x8, [x0]
100504260:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504264:     	cmp	x8, x9
100504268:     	b.lo	0x100503de0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x468>
10050426c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100504270:     	add	x0, x0, #0xd10
100504274:     	bl	0x100b1051c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100504278:     	cmp	w10, #0x5b
10050427c:     	cset	w22, eq
100504280:     	mov	w8, #0x1000000          ; =16777216
100504284:     	cmp	x19, x8
100504288:     	mov	w8, #0x5b               ; =91
10050428c:     	ccmp	w10, w8, #0x0, ls
100504290:     	b.ne	0x100503d9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x424>
100504294:     	mov	w28, #0x1               ; =1
100504298:     	mov	w22, #0x1               ; =1
10050429c:     	b	0x100503e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x508>
1005042a0:     	mov	w1, #0x0                ; =0
1005042a4:     	ldr	x8, [sp, #0xa0]
1005042a8:     	add	x8, x8, x8, lsl #1
1005042ac:     	lsl	x8, x8, #2
1005042b0:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1005042b4:     	b.ls	0x1005042d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x960>
1005042b8:     	ldr	q0, [sp, #0xa0]
1005042bc:     	str	q0, [sp, #0x10]
1005042c0:     	ldr	x8, [sp, #0xb0]
1005042c4:     	str	x8, [sp, #0x20]
1005042c8:     	mov	w8, #0x4                ; =4
1005042cc:     	stp	xzr, x8, [sp, #0xa0]
1005042d0:     	str	xzr, [sp, #0xb0]
1005042d4:     	b	0x1005042e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x96c>
1005042d8:     	stp	x24, x25, [sp, #0x18]
1005042dc:     	mov	x8, #-0x1               ; =-1
1005042e0:     	str	x8, [sp, #0x10]
1005042e4:     	add	x0, sp, #0x10
1005042e8:     	bl	0x100374ab0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24alloc_lazy_array_backing>
1005042ec:     	mov	x25, #0x7ffd000000000000 ; =9222527611924643840
1005042f0:     	bfxil	x25, x0, #0, #48
1005042f4:     	ldrb	w8, [x20, #0x20]
1005042f8:     	cbnz	w8, 0x100504b7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1204>
1005042fc:     	ldr	x8, [x20]
100504300:     	cbnz	x8, 0x100504a84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100504304:     	mov	x8, #-0x1               ; =-1
100504308:     	str	x8, [x20]
10050430c:     	ldr	x26, [x20, #0x18]
100504310:     	ldr	x8, [x20, #0x8]
100504314:     	cmp	x26, x8
100504318:     	b.eq	0x1005049ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1034>
10050431c:     	ldr	x8, [x20, #0x10]
100504320:     	str	x25, [x8, x26, lsl #3]
100504324:     	add	x8, x26, #0x1
100504328:     	str	x8, [x20, #0x18]
10050432c:     	ldr	x8, [x20]
100504330:     	add	x8, x8, #0x1
100504334:     	str	x8, [x20]
100504338:     	mov	w25, #0x1               ; =1
10050433c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100504340:     	ldr	w24, [x8, #0x308]
100504344:     	cmp	w24, #0x300
100504348:     	b.hs	0x100504948 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd0>
10050434c:     	ldr	x8, [x27, #0x48]
100504350:     	cmn	x8, #0x1
100504354:     	b.eq	0x100504938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfc0>
100504358:     	mrs	x9, TPIDRRO_EL0
10050435c:     	and	x9, x9, #0xfffffffffffffff8
100504360:     	ldr	x0, [x9, x8, lsl #3]
100504364:     	cbz	x0, 0x100504938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfc0>
100504368:     	add	x8, x0, x24, lsl #3
10050436c:     	ldr	x0, [x8, #0x1e8]
100504370:     	cbz	x0, 0x100504948 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd0>
100504374:     	ldrb	w8, [x0]
100504378:     	and	w8, w8, #0xfffffffd
10050437c:     	strb	w8, [x0]
100504380:     	mov	w0, #0x0                ; =0
100504384:     	bl	0x10045b080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
100504388:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
10050438c:     	ldr	w24, [x8, #0x590]
100504390:     	cmp	w24, #0x300
100504394:     	b.hs	0x100504968 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff0>
100504398:     	ldr	x8, [x27, #0x48]
10050439c:     	cmn	x8, #0x1
1005043a0:     	b.eq	0x100504958 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfe0>
1005043a4:     	mrs	x9, TPIDRRO_EL0
1005043a8:     	and	x9, x9, #0xfffffffffffffff8
1005043ac:     	ldr	x0, [x9, x8, lsl #3]
1005043b0:     	cbz	x0, 0x100504958 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfe0>
1005043b4:     	add	x8, x0, x24, lsl #3
1005043b8:     	ldr	x0, [x8, #0x1e8]
1005043bc:     	cbz	x0, 0x100504968 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff0>
1005043c0:     	ldr	x8, [x0]
1005043c4:     	lsr	x8, x8, #25
1005043c8:     	cbz	x8, 0x100504980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1008>
1005043cc:     	bl	0x10045ce34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005043d0:     	cmp	x23, #0x3e8
1005043d4:     	b.hi	0x100504988 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1010>
1005043d8:     	ldp	x1, x0, [sp]
1005043dc:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005043e0:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1005043e4:     	ldr	x8, [x8, #0x758]
1005043e8:     	cbnz	x8, 0x1005049a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1028>
1005043ec:     	tbz	w25, #0x0, 0x100504434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xabc>
1005043f0:     	ldrb	w8, [x20, #0x20]
1005043f4:     	cbnz	w8, 0x100504bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1260>
1005043f8:     	ldr	x8, [x20]
1005043fc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504400:     	cmp	x8, x9
100504404:     	b.hs	0x100504c04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504408:     	add	x9, x8, #0x1
10050440c:     	str	x9, [x20]
100504410:     	ldr	x9, [x20, #0x18]
100504414:     	cmp	x26, x9
100504418:     	b.hs	0x100504428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xab0>
10050441c:     	ldr	x9, [x20, #0x10]
100504420:     	ldr	x23, [x9, x26, lsl #3]
100504424:     	b	0x100504430 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xab8>
100504428:     	mov	x23, #0x1               ; =1
10050442c:     	movk	x23, #0x7ffc, lsl #48
100504430:     	str	x8, [x20]
100504434:     	str	xzr, [sp, #0xb0]
100504438:     	str	xzr, [sp, #0xc8]
10050443c:     	ldr	x8, [sp, #0xa0]
100504440:     	add	x9, x8, x8, lsl #1
100504444:     	lsl	x9, x9, #2
100504448:     	cmp	x9, #0x100, lsl #12     ; =0x100000
10050444c:     	b.ls	0x100504468 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xaf0>
100504450:     	cbz	x8, 0x10050445c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xae4>
100504454:     	ldr	x0, [sp, #0xa8]
100504458:     	bl	0x100b5cd40 <_mi_free>
10050445c:     	mov	w8, #0x4                ; =4
100504460:     	stp	xzr, x8, [sp, #0xa0]
100504464:     	str	xzr, [sp, #0xb0]
100504468:     	ldr	x8, [sp, #0xb8]
10050446c:     	lsl	x9, x8, #2
100504470:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100504474:     	b.ls	0x100504490 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb18>
100504478:     	cbz	x8, 0x100504484 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb0c>
10050447c:     	ldr	x0, [sp, #0xc0]
100504480:     	bl	0x100b5cd40 <_mi_free>
100504484:     	mov	w8, #0x4                ; =4
100504488:     	stp	xzr, x8, [sp, #0xb8]
10050448c:     	str	xzr, [sp, #0xc8]
100504490:     	ldp	x8, x0, [x22]
100504494:     	ldp	x26, x24, [x22, #0x18]
100504498:     	ldp	q1, q0, [sp, #0xb0]
10050449c:     	ldr	q2, [sp, #0xa0]
1005044a0:     	stp	q2, q1, [x22]
1005044a4:     	str	q0, [x22, #0x20]
1005044a8:     	cmn	x8, #0x1
1005044ac:     	b.eq	0x10050455c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbe4>
1005044b0:     	cbz	x8, 0x1005044b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb40>
1005044b4:     	bl	0x100b5cd40 <_mi_free>
1005044b8:     	cbz	x26, 0x10050455c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbe4>
1005044bc:     	mov	x0, x24
1005044c0:     	bl	0x100b5cd40 <_mi_free>
1005044c4:     	ldrb	w8, [x20, #0x20]
1005044c8:     	tbnz	w25, #0x0, 0x100504564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbec>
1005044cc:     	cbnz	w8, 0x100504b1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11a4>
1005044d0:     	ldr	x8, [x20]
1005044d4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005044d8:     	cmp	x8, x9
1005044dc:     	b.hs	0x100504c04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
1005044e0:     	add	x9, x8, #0x1
1005044e4:     	str	x9, [x20]
1005044e8:     	ldr	x9, [x20, #0x18]
1005044ec:     	cmp	x21, x9
1005044f0:     	b.hs	0x100504514 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb9c>
1005044f4:     	ldr	x9, [x20, #0x10]
1005044f8:     	ldr	x9, [x9, x21, lsl #3]
1005044fc:     	and	x22, x9, #0xffffffffffff
100504500:     	str	x8, [x20]
100504504:     	cmp	x19, #0x3e8
100504508:     	csel	w8, wzr, w28, ls
10050450c:     	cbnz	w8, 0x100504528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbb0>
100504510:     	b	0x1005045a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100504514:     	mov	w22, #0x1               ; =1
100504518:     	str	x8, [x20]
10050451c:     	cmp	x19, #0x3e8
100504520:     	csel	w8, wzr, w28, ls
100504524:     	cbz	w8, 0x1005045a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100504528:     	mov	x8, #0x0                ; =0
10050452c:     	mov	x9, #0x2600             ; =9728
100504530:     	movk	x9, #0x1, lsl #32
100504534:     	add	x10, x22, x8
100504538:     	ldrb	w10, [x10, #0x14]
10050453c:     	cmp	w10, #0x20
100504540:     	b.hi	0x100504584 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
100504544:     	lsr	x11, x9, x10
100504548:     	tbz	w11, #0x0, 0x100504584 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
10050454c:     	add	x8, x8, #0x1
100504550:     	cmp	x19, x8
100504554:     	b.ne	0x100504534 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbbc>
100504558:     	b	0x1005045a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
10050455c:     	ldrb	w8, [x20, #0x20]
100504560:     	cbz	w25, 0x1005044cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb54>
100504564:     	cbnz	w8, 0x100504c10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1298>
100504568:     	ldr	x8, [x20]
10050456c:     	cbnz	x8, 0x100504cb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
100504570:     	ldr	x8, [x20, #0x18]
100504574:     	cmp	x21, x8
100504578:     	b.hi	0x1005039b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
10050457c:     	str	x21, [x20, #0x18]
100504580:     	b	0x1005039b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100504584:     	cmp	w10, #0x5b
100504588:     	b.eq	0x100504594 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc1c>
10050458c:     	cmp	w10, #0x7b
100504590:     	b.ne	0x1005045a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100504594:     	add	x0, x22, #0x14
100504598:     	mov	x1, x19
10050459c:     	mov	w2, #0x3e8              ; =1000
1005045a0:     	bl	0x1006c2894 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
1005045a4:     	cbnz	w0, 0x100504aa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x112c>
1005045a8:     	bl	0x1004edb00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
1005045ac:     	bl	0x100457940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
1005045b0:     	mov	x0, x19
1005045b4:     	bl	0x10022fa2c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
1005045b8:     	mov	x24, x0
1005045bc:     	mov	x22, x1
1005045c0:     	bl	0x100457754 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
1005045c4:     	ldrb	w8, [x20, #0x20]
1005045c8:     	cbnz	w8, 0x100504a30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10b8>
1005045cc:     	ldr	x8, [x20]
1005045d0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005045d4:     	cmp	x8, x9
1005045d8:     	b.hs	0x100504c04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
1005045dc:     	add	x9, x8, #0x1
1005045e0:     	str	x9, [x20]
1005045e4:     	ldr	x9, [x20, #0x18]
1005045e8:     	cmp	x21, x9
1005045ec:     	b.hs	0x100504604 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc8c>
1005045f0:     	ldr	x9, [x20, #0x10]
1005045f4:     	ldr	x9, [x9, x21, lsl #3]
1005045f8:     	and	x25, x9, #0xffffffffffff
1005045fc:     	add	x1, x25, #0x14
100504600:     	b	0x10050460c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc94>
100504604:     	mov	w25, #0x1               ; =1
100504608:     	mov	w1, #0x15               ; =21
10050460c:     	str	x8, [x20]
100504610:     	add	x0, sp, #0xa0
100504614:     	mov	x2, x19
100504618:     	mov	x3, x25
10050461c:     	bl	0x10024530c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23new_batched_from_string>
100504620:     	add	x0, sp, #0xa0
100504624:     	bl	0x100242448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
100504628:     	mov	x23, x0
10050462c:     	ldp	x26, x28, [sp, #0x108]
100504630:     	cmp	x28, x26
100504634:     	b.hs	0x100504668 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
100504638:     	ldr	x8, [sp, #0x100]
10050463c:     	mov	x9, #0x2600             ; =9728
100504640:     	movk	x9, #0x1, lsl #32
100504644:     	ldrb	w10, [x8, x28]
100504648:     	cmp	w10, #0x20
10050464c:     	b.hi	0x100504668 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
100504650:     	lsr	x10, x9, x10
100504654:     	tbz	w10, #0x0, 0x100504668 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
100504658:     	add	x28, x28, #0x1
10050465c:     	cmp	x26, x28
100504660:     	b.ne	0x100504644 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xccc>
100504664:     	mov	x28, x26
100504668:     	ldrb	w8, [sp, #0x176]
10050466c:     	tbnz	w8, #0x0, 0x1005049b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1040>
100504670:     	cmp	x28, x26
100504674:     	b.ne	0x1005049c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104c>
100504678:     	ldrb	w8, [sp, #0x174]
10050467c:     	tbz	w8, #0x0, 0x1005049c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104c>
100504680:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100504684:     	ldr	w26, [x8, #0x560]
100504688:     	cmp	w26, #0x300
10050468c:     	b.hs	0x100504824 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeac>
100504690:     	ldr	x8, [x27, #0x48]
100504694:     	cmn	x8, #0x1
100504698:     	b.eq	0x100504814 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe9c>
10050469c:     	mrs	x9, TPIDRRO_EL0
1005046a0:     	and	x9, x9, #0xfffffffffffffff8
1005046a4:     	ldr	x0, [x9, x8, lsl #3]
1005046a8:     	cbz	x0, 0x100504814 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe9c>
1005046ac:     	add	x8, x0, x26, lsl #3
1005046b0:     	ldr	x0, [x8, #0x1e8]
1005046b4:     	cbz	x0, 0x100504824 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeac>
1005046b8:     	ldr	x8, [x0]
1005046bc:     	cbnz	x8, 0x100504838 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xec0>
1005046c0:     	ldrb	w8, [x0, #0x24]
1005046c4:     	cmp	w8, #0x2
1005046c8:     	b.eq	0x1005046ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
1005046cc:     	ldr	x8, [x0, #0x8]
1005046d0:     	cmp	x8, x25
1005046d4:     	b.ne	0x1005046ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
1005046d8:     	ldr	w8, [x0, #0x18]
1005046dc:     	cmp	x19, x8
1005046e0:     	b.ne	0x1005046ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
1005046e4:     	mov	w8, #0x1                ; =1
1005046e8:     	strb	w8, [x0, #0x24]
1005046ec:     	mov	x0, x25
1005046f0:     	mov	x1, x19
1005046f4:     	mov	x2, x23
1005046f8:     	bl	0x1004eabc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template>
1005046fc:     	ldrb	w8, [x20, #0x20]
100504700:     	cbnz	w8, 0x100504a60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10e8>
100504704:     	ldr	x8, [x20]
100504708:     	cbnz	x8, 0x100504a84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
10050470c:     	mov	x8, #-0x1               ; =-1
100504710:     	str	x8, [x20]
100504714:     	ldr	x19, [x20, #0x18]
100504718:     	ldr	x8, [x20, #0x8]
10050471c:     	cmp	x19, x8
100504720:     	b.eq	0x100504844 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xecc>
100504724:     	ldr	x8, [x20, #0x10]
100504728:     	str	x23, [x8, x19, lsl #3]
10050472c:     	add	x8, x19, #0x1
100504730:     	str	x8, [x20, #0x18]
100504734:     	ldr	x8, [x20]
100504738:     	add	x8, x8, #0x1
10050473c:     	str	x8, [x20]
100504740:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100504744:     	ldr	w19, [x8, #0x308]
100504748:     	cmp	w19, #0x300
10050474c:     	b.hs	0x100504860 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xee8>
100504750:     	ldr	x8, [x27, #0x48]
100504754:     	cmn	x8, #0x1
100504758:     	b.eq	0x100504850 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xed8>
10050475c:     	mrs	x9, TPIDRRO_EL0
100504760:     	and	x9, x9, #0xfffffffffffffff8
100504764:     	ldr	x0, [x9, x8, lsl #3]
100504768:     	cbz	x0, 0x100504850 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xed8>
10050476c:     	add	x8, x0, x19, lsl #3
100504770:     	ldr	x0, [x8, #0x1e8]
100504774:     	cbz	x0, 0x100504860 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xee8>
100504778:     	ldrb	w8, [x0]
10050477c:     	and	w8, w8, #0xfffffffd
100504780:     	strb	w8, [x0]
100504784:     	mov	w0, #0x0                ; =0
100504788:     	bl	0x10045b080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
10050478c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100504790:     	ldr	w19, [x8, #0x590]
100504794:     	cmp	w19, #0x300
100504798:     	b.hs	0x100504880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf08>
10050479c:     	ldr	x8, [x27, #0x48]
1005047a0:     	cmn	x8, #0x1
1005047a4:     	b.eq	0x100504870 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef8>
1005047a8:     	mrs	x9, TPIDRRO_EL0
1005047ac:     	and	x9, x9, #0xfffffffffffffff8
1005047b0:     	ldr	x0, [x9, x8, lsl #3]
1005047b4:     	cbz	x0, 0x100504870 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef8>
1005047b8:     	add	x8, x0, x19, lsl #3
1005047bc:     	ldr	x0, [x8, #0x1e8]
1005047c0:     	cbz	x0, 0x100504880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf08>
1005047c4:     	ldr	x8, [x0]
1005047c8:     	lsr	x8, x8, #25
1005047cc:     	cbz	x8, 0x100504898 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf20>
1005047d0:     	bl	0x10045ce34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005047d4:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
1005047d8:     	mov	x0, x24
1005047dc:     	mov	x1, x22
1005047e0:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005047e4:     	ldrb	w8, [x20, #0x20]
1005047e8:     	cbz	w8, 0x1005048b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf38>
1005047ec:     	cmp	w8, #0x2
1005047f0:     	b.eq	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
1005047f4:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
1005047f8:     	add	x1, x1, #0x518
1005047fc:     	mov	x0, x20
100504800:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504804:     	strb	wzr, [x20, #0x20]
100504808:     	ldr	x8, [x20]
10050480c:     	cbz	x8, 0x1005048b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf40>
100504810:     	b	0x100504cb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
100504814:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504818:     	add	x8, x0, x26, lsl #3
10050481c:     	ldr	x0, [x8, #0x1e8]
100504820:     	cbnz	x0, 0x1005046b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd40>
100504824:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1e70>
100504828:     	add	x0, x0, #0xfe8
10050482c:     	bl	0x100b3a9dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100504830:     	ldr	x8, [x0]
100504834:     	cbz	x8, 0x1005046c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd48>
100504838:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10050483c:     	add	x0, x0, #0xcf8
100504840:     	bl	0x100b104ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100504844:     	add	x0, x20, #0x8
100504848:     	bl	0x100b39aac <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10050484c:     	b	0x100504724 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdac>
100504850:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504854:     	add	x8, x0, x19, lsl #3
100504858:     	ldr	x0, [x8, #0x1e8]
10050485c:     	cbnz	x0, 0x100504778 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe00>
100504860:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
100504864:     	add	x0, x0, #0xd20
100504868:     	bl	0x100b3aa28 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
10050486c:     	b	0x100504778 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe00>
100504870:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504874:     	add	x8, x0, x19, lsl #3
100504878:     	ldr	x0, [x8, #0x1e8]
10050487c:     	cbnz	x0, 0x1005047c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe4c>
100504880:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
100504884:     	add	x0, x0, #0x90
100504888:     	bl	0x100b3a9dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10050488c:     	ldr	x8, [x0]
100504890:     	lsr	x8, x8, #25
100504894:     	cbnz	x8, 0x1005047d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe58>
100504898:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
10050489c:     	mov	x0, x24
1005048a0:     	mov	x1, x22
1005048a4:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005048a8:     	ldrb	w8, [x20, #0x20]
1005048ac:     	cbnz	w8, 0x1005047ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe74>
1005048b0:     	ldr	x8, [x20]
1005048b4:     	cbnz	x8, 0x100504cb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
1005048b8:     	ldr	x8, [x20, #0x18]
1005048bc:     	cmp	x21, x8
1005048c0:     	b.ls	0x1005048e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf70>
1005048c4:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1005048c8:     	ldr	x8, [x8, #0x758]
1005048cc:     	cbnz	x8, 0x1005048f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf80>
1005048d0:     	ldr	x8, [sp, #0xd8]
1005048d4:     	cmp	x8, #0x1
1005048d8:     	b.lt	0x1005039b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
1005048dc:     	ldr	x0, [sp, #0xe0]
1005048e0:     	bl	0x100b5cd40 <_mi_free>
1005048e4:     	b	0x1005039b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
1005048e8:     	str	x21, [x20, #0x18]
1005048ec:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1005048f0:     	ldr	x8, [x8, #0x758]
1005048f4:     	cbz	x8, 0x1005048d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf58>
1005048f8:     	bl	0x100b43884 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
1005048fc:     	ldr	x8, [sp, #0xd8]
100504900:     	cmp	x8, #0x1
100504904:     	b.ge	0x1005048dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf64>
100504908:     	b	0x1005039b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
10050490c:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504910:     	add	x8, x0, x24, lsl #3
100504914:     	ldr	x0, [x8, #0x1e8]
100504918:     	cbnz	x0, 0x100504030 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6b8>
10050491c:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
100504920:     	add	x0, x0, #0xcf0
100504924:     	bl	0x100b3aa28 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100504928:     	ldrb	w8, [x0]
10050492c:     	cbz	w8, 0x100504038 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6c0>
100504930:     	bl	0x100b4215c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
100504934:     	b	0x100504038 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6c0>
100504938:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10050493c:     	add	x8, x0, x24, lsl #3
100504940:     	ldr	x0, [x8, #0x1e8]
100504944:     	cbnz	x0, 0x100504374 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9fc>
100504948:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
10050494c:     	add	x0, x0, #0xd20
100504950:     	bl	0x100b3aa28 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100504954:     	b	0x100504374 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9fc>
100504958:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10050495c:     	add	x8, x0, x24, lsl #3
100504960:     	ldr	x0, [x8, #0x1e8]
100504964:     	cbnz	x0, 0x1005043c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa48>
100504968:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
10050496c:     	add	x0, x0, #0x90
100504970:     	bl	0x100b3a9dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100504974:     	ldr	x8, [x0]
100504978:     	lsr	x8, x8, #25
10050497c:     	cbnz	x8, 0x1005043cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa54>
100504980:     	cmp	x23, #0x3e8
100504984:     	b.ls	0x1005043d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa60>
100504988:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
10050498c:     	ldp	x1, x0, [sp]
100504990:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100504994:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100504998:     	ldr	x8, [x8, #0x758]
10050499c:     	cbz	x8, 0x1005043ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa74>
1005049a0:     	bl	0x100b43884 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
1005049a4:     	tbnz	w25, #0x0, 0x1005043f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa78>
1005049a8:     	b	0x100504434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xabc>
1005049ac:     	add	x0, x20, #0x8
1005049b0:     	bl	0x100b39aac <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1005049b4:     	b	0x10050431c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9a4>
1005049b8:     	bl	0x100b43658 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar15clear_key_cache>
1005049bc:     	cmp	x28, x26
1005049c0:     	b.eq	0x100504678 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd00>
1005049c4:     	mov	x0, x23
1005049c8:     	bl	0x1003259cc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15parse_root_push>
1005049cc:     	bl	0x1004578bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy13gc_unsuppress>
1005049d0:     	bl	0x1004eda64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat26finish_parse_gc_accounting>
1005049d4:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
1005049d8:     	mov	x0, x24
1005049dc:     	mov	x1, x22
1005049e0:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005049e4:     	mov	x0, x21
1005049e8:     	bl	0x100325bdc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
1005049ec:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1005049f0:     	ldr	x8, [x8, #0x758]
1005049f4:     	cbnz	x8, 0x100504f5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15e4>
1005049f8:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x715c>
1005049fc:     	add	x0, x0, #0x360
100504a00:     	mov	w1, #0x21               ; =33
100504a04:     	bl	0x100506428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
100504a08:     	cmp	w8, #0x2
100504a0c:     	b.eq	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504a10:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504a14:     	add	x1, x1, #0x518
100504a18:     	mov	x0, x20
100504a1c:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504a20:     	strb	wzr, [x20, #0x20]
100504a24:     	ldr	x8, [x20]
100504a28:     	cbz	x8, 0x100503ea4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x52c>
100504a2c:     	b	0x100504a84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100504a30:     	cmp	w8, #0x2
100504a34:     	b.eq	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504a38:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504a3c:     	add	x1, x1, #0x518
100504a40:     	mov	x0, x20
100504a44:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504a48:     	strb	wzr, [x20, #0x20]
100504a4c:     	ldr	x8, [x20]
100504a50:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504a54:     	cmp	x8, x9
100504a58:     	b.lo	0x1005045dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc64>
100504a5c:     	b	0x100504c04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504a60:     	cmp	w8, #0x2
100504a64:     	b.eq	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504a68:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504a6c:     	add	x1, x1, #0x518
100504a70:     	mov	x0, x20
100504a74:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504a78:     	strb	wzr, [x20, #0x20]
100504a7c:     	ldr	x8, [x20]
100504a80:     	cbz	x8, 0x10050470c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd94>
100504a84:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100504a88:     	add	x0, x0, #0x428
100504a8c:     	bl	0x100b104ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100504a90:     	mov	x0, x22
100504a94:     	bl	0x100b1c2ec <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11TapeScratchEEuE16get_or_init_slowNvNvB2b_12TAPE_SCRATCH27___rust_std_internal_init_fnEB2d_>
100504a98:     	mov	x22, x0
100504a9c:     	cbnz	x0, 0x100503f88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x610>
100504aa0:     	b	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504aa4:     	mov	x0, x21
100504aa8:     	bl	0x100325bdc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100504aac:     	mov	x0, x22
100504ab0:     	mov	x1, x19
100504ab4:     	bl	0x100b43bb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api19parse_deep_or_throw>
100504ab8:     	mov	x23, x0
100504abc:     	b	0x1005039b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100504ac0:     	cmp	w8, #0x2
100504ac4:     	b.eq	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504ac8:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504acc:     	add	x1, x1, #0x518
100504ad0:     	mov	x0, x20
100504ad4:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504ad8:     	strb	wzr, [x20, #0x20]
100504adc:     	ldr	x8, [x20]
100504ae0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504ae4:     	cmp	x8, x9
100504ae8:     	b.lo	0x100503f3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c4>
100504aec:     	b	0x100504c04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504af0:     	cmp	x9, #0x6
100504af4:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504af8:     	ldrb	w8, [x21, #0x1a]
100504afc:     	cmp	w8, #0x22
100504b00:     	b.ne	0x100504c24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12ac>
100504b04:     	mov	w23, #0x0               ; =0
100504b08:     	mov	w28, #0x0               ; =0
100504b0c:     	mov	w27, #0x0               ; =0
100504b10:     	mov	w26, #0x1               ; =1
100504b14:     	mov	w20, #0x4               ; =4
100504b18:     	b	0x100503b30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100504b1c:     	cmp	w8, #0x2
100504b20:     	b.eq	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504b24:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504b28:     	add	x1, x1, #0x518
100504b2c:     	mov	x0, x20
100504b30:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504b34:     	strb	wzr, [x20, #0x20]
100504b38:     	ldr	x8, [x20]
100504b3c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504b40:     	cmp	x8, x9
100504b44:     	b.lo	0x1005044e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb68>
100504b48:     	b	0x100504c04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504b4c:     	cmp	w8, #0x2
100504b50:     	b.eq	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504b54:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504b58:     	add	x1, x1, #0x518
100504b5c:     	mov	x0, x20
100504b60:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504b64:     	strb	wzr, [x20, #0x20]
100504b68:     	ldr	x8, [x20]
100504b6c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504b70:     	cmp	x8, x9
100504b74:     	b.lo	0x10050406c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6f4>
100504b78:     	b	0x100504c04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504b7c:     	cmp	w8, #0x2
100504b80:     	b.eq	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504b84:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504b88:     	add	x1, x1, #0x518
100504b8c:     	mov	x0, x20
100504b90:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504b94:     	strb	wzr, [x20, #0x20]
100504b98:     	ldr	x8, [x20]
100504b9c:     	cbz	x8, 0x100504304 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x98c>
100504ba0:     	b	0x100504a84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100504ba4:     	cmp	x9, #0x1
100504ba8:     	b.ne	0x100504c54 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12dc>
100504bac:     	ldrb	w8, [x8]
100504bb0:     	sub	w9, w8, #0x30
100504bb4:     	cmp	w9, #0xa
100504bb8:     	b.hs	0x100504c58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12e0>
100504bbc:     	and	w8, w9, #0xff
100504bc0:     	ucvtf	d0, w8
100504bc4:     	fmov	x1, d0
100504bc8:     	orr	x0, x25, x26
100504bcc:     	bl	0x1004f3c30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object18allocate_one_field>
100504bd0:     	tbnz	w0, #0x0, 0x1005039ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x34>
100504bd4:     	b	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504bd8:     	cmp	w8, #0x2
100504bdc:     	b.eq	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504be0:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504be4:     	add	x1, x1, #0x518
100504be8:     	mov	x0, x20
100504bec:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504bf0:     	strb	wzr, [x20, #0x20]
100504bf4:     	ldr	x8, [x20]
100504bf8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504bfc:     	cmp	x8, x9
100504c00:     	b.lo	0x100504408 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa90>
100504c04:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100504c08:     	add	x0, x0, #0x3f8
100504c0c:     	bl	0x100b1051c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100504c10:     	cmp	w8, #0x2
100504c14:     	b.ne	0x100504c98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1320>
100504c18:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100504c1c:     	add	x0, x0, #0xc18
100504c20:     	bl	0x100b5639c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100504c24:     	sub	x8, x19, #0x1
100504c28:     	cmp	x8, #0x7
100504c2c:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504c30:     	ldrb	w8, [x21, #0x1b]
100504c34:     	cmp	w8, #0x22
100504c38:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504c3c:     	mov	w23, #0x0               ; =0
100504c40:     	mov	w28, #0x0               ; =0
100504c44:     	mov	w27, #0x0               ; =0
100504c48:     	mov	w26, #0x0               ; =0
100504c4c:     	mov	w20, #0x5               ; =5
100504c50:     	b	0x100503b30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100504c54:     	ldrb	w8, [x8]
100504c58:     	orr	w8, w8, #0x20
100504c5c:     	cmp	w8, #0x7b
100504c60:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504c64:     	sub	x11, x19, #0x5
100504c68:     	mov	x10, #0x2600            ; =9728
100504c6c:     	movk	x10, #0x1, lsl #32
100504c70:     	add	x8, x21, x20
100504c74:     	ldrb	w9, [x8, #0x18]
100504c78:     	cmp	w9, #0x20
100504c7c:     	b.hi	0x100504cc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1348>
100504c80:     	lsr	x12, x10, x9
100504c84:     	tbz	w12, #0x0, 0x100504cc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1348>
100504c88:     	add	x20, x20, #0x1
100504c8c:     	cmp	x11, x20
100504c90:     	b.ne	0x100504c70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f8>
100504c94:     	b	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504c98:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504c9c:     	add	x1, x1, #0x518
100504ca0:     	mov	x0, x20
100504ca4:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504ca8:     	strb	wzr, [x20, #0x20]
100504cac:     	ldr	x8, [x20]
100504cb0:     	cbz	x8, 0x100504570 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbf8>
100504cb4:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100504cb8:     	add	x0, x0, #0x488
100504cbc:     	bl	0x100b104ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100504cc0:     	cmp	x11, x20
100504cc4:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504cc8:     	add	x13, x21, #0x12
100504ccc:     	mov	x14, #0x2600            ; =9728
100504cd0:     	movk	x14, #0x1, lsl #32
100504cd4:     	mov	x10, x20
100504cd8:     	ldrb	w12, [x13, x19]
100504cdc:     	cmp	w12, #0x20
100504ce0:     	b.hi	0x100504d10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1398>
100504ce4:     	lsr	x15, x14, x12
100504ce8:     	tbz	w15, #0x0, 0x100504d10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1398>
100504cec:     	sub	x13, x13, #0x1
100504cf0:     	add	x10, x10, #0x1
100504cf4:     	cmp	x11, x10
100504cf8:     	b.ne	0x100504cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1360>
100504cfc:     	b	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d00:     	adrp	x2, 0x100f07000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime7promise28ITER_RESULT_VALUE_IS_RAW_F64+0x10>
100504d04:     	add	x2, x2, #0x1b8
100504d08:     	mov	x1, x25
100504d0c:     	bl	0x100b1064c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100504d10:     	sub	x11, x19, x10
100504d14:     	sub	x1, x11, #0x5
100504d18:     	cmp	x1, #0x4
100504d1c:     	b.eq	0x100504d88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1410>
100504d20:     	cmp	x1, #0x5
100504d24:     	b.ne	0x100504d90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1418>
100504d28:     	cmp	w9, #0x22
100504d2c:     	b.eq	0x100504dbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1444>
100504d30:     	cmp	w9, #0x2d
100504d34:     	b.eq	0x100504dac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1434>
100504d38:     	cmp	w9, #0x66
100504d3c:     	b.ne	0x100504da0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1428>
100504d40:     	add	x8, x21, x20
100504d44:     	ldrb	w9, [x8, #0x19]
100504d48:     	cmp	w9, #0x61
100504d4c:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d50:     	ldrb	w8, [x8, #0x1a]
100504d54:     	cmp	w8, #0x6c
100504d58:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d5c:     	add	x8, x21, x20
100504d60:     	ldrb	w9, [x8, #0x1b]
100504d64:     	cmp	w9, #0x73
100504d68:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d6c:     	ldrb	w8, [x8, #0x1c]
100504d70:     	cmp	w8, #0x65
100504d74:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d78:     	mov	x8, #0x1                ; =1
100504d7c:     	movk	x8, #0x7ffc, lsl #48
100504d80:     	orr	x1, x8, #0x2
100504d84:     	b	0x100504bc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504d88:     	cmp	w9, #0x6d
100504d8c:     	b.gt	0x100504e28 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14b0>
100504d90:     	cmp	w9, #0x22
100504d94:     	b.eq	0x100504dbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1444>
100504d98:     	cmp	w9, #0x2d
100504d9c:     	b.eq	0x100504dac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1434>
100504da0:     	sub	w9, w9, #0x30
100504da4:     	cmp	w9, #0xa
100504da8:     	b.hs	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504dac:     	add	x0, x8, #0x18
100504db0:     	bl	0x1004eb81c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar12parse_number>
100504db4:     	tbz	w0, #0x0, 0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504db8:     	b	0x100504bc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504dbc:     	sub	x8, x19, #0x6
100504dc0:     	cmp	x8, x10
100504dc4:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504dc8:     	cmp	x1, #0x7
100504dcc:     	b.hi	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504dd0:     	cmp	w12, #0x22
100504dd4:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504dd8:     	sub	x23, x11, #0x7
100504ddc:     	sub	x8, x19, #0x7
100504de0:     	add	x9, x21, x20
100504de4:     	add	x22, x9, #0x19
100504de8:     	cmp	x8, x10
100504dec:     	b.ne	0x100504eb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1538>
100504df0:     	add	x8, sp, #0xa0
100504df4:     	mov	x0, x22
100504df8:     	mov	x1, x23
100504dfc:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100504e00:     	ldr	x8, [sp, #0xa0]
100504e04:     	cbnz	x8, 0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e08:     	cmp	x23, #0x2
100504e0c:     	b.gt	0x100504ee0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1568>
100504e10:     	cbz	x23, 0x100504efc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1584>
100504e14:     	cmp	x23, #0x1
100504e18:     	b.ne	0x100504f04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x158c>
100504e1c:     	ldrb	w8, [x22]
100504e20:     	mov	x9, #0x10000000000      ; =1099511627776
100504e24:     	b	0x100504f50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100504e28:     	cmp	w9, #0x74
100504e2c:     	b.eq	0x100504e74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14fc>
100504e30:     	cmp	w9, #0x6e
100504e34:     	b.ne	0x100504da0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1428>
100504e38:     	add	x8, x21, x20
100504e3c:     	ldrb	w9, [x8, #0x19]
100504e40:     	cmp	w9, #0x75
100504e44:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e48:     	ldrb	w8, [x8, #0x1a]
100504e4c:     	cmp	w8, #0x6c
100504e50:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e54:     	add	x8, x21, x20
100504e58:     	ldrb	w8, [x8, #0x1b]
100504e5c:     	cmp	w8, #0x6c
100504e60:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e64:     	mov	x8, #0x1                ; =1
100504e68:     	movk	x8, #0x7ffc, lsl #48
100504e6c:     	add	x1, x8, #0x1
100504e70:     	b	0x100504bc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504e74:     	add	x8, x21, x20
100504e78:     	ldrb	w9, [x8, #0x19]
100504e7c:     	cmp	w9, #0x72
100504e80:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e84:     	ldrb	w8, [x8, #0x1a]
100504e88:     	cmp	w8, #0x75
100504e8c:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e90:     	add	x8, x21, x20
100504e94:     	ldrb	w8, [x8, #0x1b]
100504e98:     	cmp	w8, #0x65
100504e9c:     	b.ne	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504ea0:     	mov	x8, #0x1                ; =1
100504ea4:     	movk	x8, #0x7ffc, lsl #48
100504ea8:     	add	x1, x8, #0x3
100504eac:     	b	0x100504bc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504eb0:     	mov	x8, x23
100504eb4:     	mov	x9, x22
100504eb8:     	ldrb	w10, [x9], #0x1
100504ebc:     	cmp	w10, #0x20
100504ec0:     	b.lo	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504ec4:     	cmp	w10, #0x22
100504ec8:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504ecc:     	cmp	w10, #0x5c
100504ed0:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504ed4:     	subs	x8, x8, #0x1
100504ed8:     	b.ne	0x100504eb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1540>
100504edc:     	b	0x100504df0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1478>
100504ee0:     	cmp	x23, #0x3
100504ee4:     	b.eq	0x100504f1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15a4>
100504ee8:     	cmp	x23, #0x4
100504eec:     	b.ne	0x100504f3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15c4>
100504ef0:     	ldr	w8, [x22]
100504ef4:     	mov	x9, #0x40000000000      ; =4398046511104
100504ef8:     	b	0x100504f50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100504efc:     	mov	x1, #0x7ff9000000000000 ; =9221401712017801216
100504f00:     	b	0x100504bc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504f04:     	ldrb	w8, [x22]
100504f08:     	add	x9, x21, x20
100504f0c:     	ldrb	w9, [x9, #0x1a]
100504f10:     	orr	x8, x8, x9, lsl #8
100504f14:     	mov	x9, #0x20000000000      ; =2199023255552
100504f18:     	b	0x100504f50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100504f1c:     	ldrb	w8, [x22]
100504f20:     	add	x9, x21, x20
100504f24:     	ldrb	w10, [x9, #0x1a]
100504f28:     	ldrb	w9, [x9, #0x1b]
100504f2c:     	orr	x8, x8, x10, lsl #8
100504f30:     	orr	x8, x8, x9, lsl #16
100504f34:     	mov	x9, #0x30000000000      ; =3298534883328
100504f38:     	b	0x100504f50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100504f3c:     	ldr	w8, [x22]
100504f40:     	add	x9, x21, x20
100504f44:     	ldrb	w9, [x9, #0x1d]
100504f48:     	orr	x8, x8, x9, lsl #32
100504f4c:     	mov	x9, #0x50000000000      ; =5497558138880
100504f50:     	movk	x9, #0x7ff9, lsl #48
100504f54:     	orr	x1, x8, x9
100504f58:     	b	0x100504bc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504f5c:     	bl	0x100b43884 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100504f60:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x715c>
100504f64:     	add	x0, x0, #0x360
100504f68:     	mov	w1, #0x21               ; =33
100504f6c:     	bl	0x100506428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
