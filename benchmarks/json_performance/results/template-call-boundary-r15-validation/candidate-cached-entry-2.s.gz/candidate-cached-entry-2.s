
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-call-boundary-r15/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008426d4 <_js_json_parse>:
1008426d4:     	stp	x29, x30, [sp, #-0x10]!
1008426d8:     	mov	x29, sp
1008426dc:     	cbz	x0, 0x100842734 <_js_json_parse+0x60>
1008426e0:     	ldr	w1, [x0, #0x4]
1008426e4:     	cmp	w1, #0x2
1008426e8:     	b.eq	0x1008426f8 <_js_json_parse+0x24>
1008426ec:     	cbz	w1, 0x100842734 <_js_json_parse+0x60>
1008426f0:     	ldrb	w8, [x0, #0x14]
1008426f4:     	b	0x100842718 <_js_json_parse+0x44>
1008426f8:     	ldrb	w8, [x0, #0x14]
1008426fc:     	cmp	w8, #0x7b
100842700:     	b.ne	0x100842718 <_js_json_parse+0x44>
100842704:     	ldrb	w8, [x0, #0x15]
100842708:     	cmp	w8, #0x7d
10084270c:     	b.ne	0x100842724 <_js_json_parse+0x50>
100842710:     	ldp	x29, x30, [sp], #0x10
100842714:     	b	0x1004ea480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100842718:     	orr	w8, w8, #0x20
10084271c:     	cmp	w8, #0x7b
100842720:     	b.ne	0x10084272c <_js_json_parse+0x58>
100842724:     	ldp	x29, x30, [sp], #0x10
100842728:     	b	0x100503978 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
10084272c:     	ldp	x29, x30, [sp], #0x10
100842730:     	b	0x100505ff4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100842734:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x715c>
100842738:     	add	x0, x0, #0x381
10084273c:     	mov	w1, #0x1c               ; =28
100842740:     	bl	0x100506428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
