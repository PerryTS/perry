
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-call-boundary-r15/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005e8b04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>:
1005e8b04:     	sub	sp, sp, #0x60
1005e8b08:     	stp	x24, x23, [sp, #0x20]
1005e8b0c:     	stp	x22, x21, [sp, #0x30]
1005e8b10:     	stp	x20, x19, [sp, #0x40]
1005e8b14:     	stp	x29, x30, [sp, #0x50]
1005e8b18:     	add	x29, sp, #0x50
1005e8b1c:     	mov	x19, x1
1005e8b20:     	cmp	x2, #0x40
1005e8b24:     	b.hs	0x1005e8c58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x154>
1005e8b28:     	ands	x8, x2, #0x38
1005e8b2c:     	b.eq	0x1005e8b50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4c>
1005e8b30:     	and	x9, x2, #0x38
1005e8b34:     	neg	x9, x9
1005e8b38:     	mov	x10, x19
1005e8b3c:     	ldr	x11, [x10], #0x8
1005e8b40:     	tst	x11, #0x8080808080808080
1005e8b44:     	b.ne	0x1005e8be4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8b48:     	adds	x9, x9, #0x8
1005e8b4c:     	b.ne	0x1005e8b3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x38>
1005e8b50:     	mov	x20, x2
1005e8b54:     	and	x9, x2, #0x7
1005e8b58:     	cbz	x9, 0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8b5c:     	add	x8, x19, x8
1005e8b60:     	ldrsb	w10, [x8]
1005e8b64:     	tbnz	w10, #0x1f, 0x1005e8be4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8b68:     	mov	x20, x2
1005e8b6c:     	cmp	x9, #0x1
1005e8b70:     	b.eq	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8b74:     	ldrsb	w10, [x8, #0x1]
1005e8b78:     	tbnz	w10, #0x1f, 0x1005e8be4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8b7c:     	mov	x20, x2
1005e8b80:     	cmp	x9, #0x2
1005e8b84:     	b.eq	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8b88:     	ldrsb	w10, [x8, #0x2]
1005e8b8c:     	tbnz	w10, #0x1f, 0x1005e8be4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8b90:     	mov	x20, x2
1005e8b94:     	cmp	x9, #0x3
1005e8b98:     	b.eq	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8b9c:     	ldrsb	w10, [x8, #0x3]
1005e8ba0:     	tbnz	w10, #0x1f, 0x1005e8be4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8ba4:     	mov	x20, x2
1005e8ba8:     	cmp	x9, #0x4
1005e8bac:     	b.eq	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8bb0:     	ldrsb	w10, [x8, #0x4]
1005e8bb4:     	tbnz	w10, #0x1f, 0x1005e8be4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8bb8:     	mov	x20, x2
1005e8bbc:     	cmp	x9, #0x5
1005e8bc0:     	b.eq	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8bc4:     	ldrsb	w10, [x8, #0x5]
1005e8bc8:     	tbnz	w10, #0x1f, 0x1005e8be4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8bcc:     	mov	x20, x2
1005e8bd0:     	cmp	x9, #0x6
1005e8bd4:     	b.eq	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8bd8:     	ldrsb	w8, [x8, #0x6]
1005e8bdc:     	mov	x20, x2
1005e8be0:     	tbz	w8, #0x1f, 0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8be4:     	cbz	w2, 0x1005e8ce4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1e0>
1005e8be8:     	mov	x20, x2
1005e8bec:     	mov	w21, w2
1005e8bf0:     	cbz	x21, 0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8bf4:     	mov	x8, x19
1005e8bf8:     	ands	x9, x2, #0x3
1005e8bfc:     	b.eq	0x1005e8c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x114>
1005e8c00:     	mov	x8, x19
1005e8c04:     	ldrsb	w10, [x8]
1005e8c08:     	tbnz	w10, #0x1f, 0x1005e8cfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8c0c:     	add	x8, x8, #0x1
1005e8c10:     	subs	x9, x9, #0x1
1005e8c14:     	b.ne	0x1005e8c04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x100>
1005e8c18:     	mov	x20, x2
1005e8c1c:     	cmp	x21, #0x4
1005e8c20:     	b.lo	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8c24:     	add	x9, x19, x21
1005e8c28:     	ldrsb	w10, [x8]
1005e8c2c:     	tbnz	w10, #0x1f, 0x1005e8cfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8c30:     	ldrsb	w10, [x8, #0x1]
1005e8c34:     	tbnz	w10, #0x1f, 0x1005e8cfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8c38:     	ldrsb	w10, [x8, #0x2]
1005e8c3c:     	tbnz	w10, #0x1f, 0x1005e8cfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8c40:     	ldrsb	w10, [x8, #0x3]
1005e8c44:     	tbnz	w10, #0x1f, 0x1005e8cfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8c48:     	add	x8, x8, #0x4
1005e8c4c:     	cmp	x8, x9
1005e8c50:     	b.ne	0x1005e8c28 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x124>
1005e8c54:     	b	0x1005e8cdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1d8>
1005e8c58:     	and	x8, x2, #0x7fffffffffffffc0
1005e8c5c:     	add	x8, x19, x8
1005e8c60:     	mov	x9, x19
1005e8c64:     	ldp	q0, q1, [x9]
1005e8c68:     	ldp	q2, q3, [x9, #0x20]
1005e8c6c:     	orr.16b	v0, v1, v0
1005e8c70:     	orr.16b	v1, v2, v3
1005e8c74:     	orr.16b	v0, v0, v1
1005e8c78:     	umaxv.16b	b0, v0
1005e8c7c:     	fmov	w10, s0
1005e8c80:     	tbnz	w10, #0x7, 0x1005e8be4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8c84:     	add	x9, x9, #0x40
1005e8c88:     	cmp	x9, x8
1005e8c8c:     	b.ne	0x1005e8c64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x160>
1005e8c90:     	ands	x9, x2, #0x30
1005e8c94:     	b.eq	0x1005e8cb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1b4>
1005e8c98:     	mov	x10, x9
1005e8c9c:     	mov	x11, x8
1005e8ca0:     	ldr	q0, [x11], #0x10
1005e8ca4:     	umaxv.16b	b0, v0
1005e8ca8:     	fmov	w12, s0
1005e8cac:     	tbnz	w12, #0x7, 0x1005e8be4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8cb0:     	subs	x10, x10, #0x10
1005e8cb4:     	b.ne	0x1005e8ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x19c>
1005e8cb8:     	mov	x20, x2
1005e8cbc:     	and	x10, x2, #0xf
1005e8cc0:     	cbz	x10, 0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8cc4:     	add	x8, x8, x9
1005e8cc8:     	ldrsb	w9, [x8]
1005e8ccc:     	tbnz	w9, #0x1f, 0x1005e8be4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8cd0:     	add	x8, x8, #0x1
1005e8cd4:     	subs	x10, x10, #0x1
1005e8cd8:     	b.ne	0x1005e8cc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1c4>
1005e8cdc:     	mov	x20, x2
1005e8ce0:     	b	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8ce4:     	mov	w20, #0x0               ; =0
1005e8ce8:     	mov	w8, #0x14               ; =20
1005e8cec:     	orr	x8, x2, x8
1005e8cf0:     	ldr	x9, [x0]
1005e8cf4:     	cbnz	x9, 0x1005e8dcc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2c8>
1005e8cf8:     	b	0x1005e8e08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005e8cfc:     	mov	x22, x0
1005e8d00:     	mov	x23, x2
1005e8d04:     	cmp	w2, #0x3f
1005e8d08:     	b.ls	0x1005e8e54 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x350>
1005e8d0c:     	mov	x0, x19
1005e8d10:     	mov	x1, x21
1005e8d14:     	bl	0x1005e8520 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
1005e8d18:     	mov	x20, x0
1005e8d1c:     	mov	x2, x23
1005e8d20:     	mov	x0, x22
1005e8d24:     	lsr	w8, w2, #19
1005e8d28:     	cbz	w8, 0x1005e8dc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2bc>
1005e8d2c:     	mov	w23, w2
1005e8d30:     	add	x0, x23, #0x14
1005e8d34:     	mov	w1, #0x3                ; =3
1005e8d38:     	mov	x22, x2
1005e8d3c:     	bl	0x100455f00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
1005e8d40:     	mov	x21, x0
1005e8d44:     	stp	w20, w22, [x0]
1005e8d48:     	str	w22, [x0, #0x8]
1005e8d4c:     	mov	x8, #0x200000000        ; =8589934592
1005e8d50:     	stur	x8, [x0, #0xc]
1005e8d54:     	add	x0, x0, #0x14
1005e8d58:     	mov	x1, x19
1005e8d5c:     	mov	x2, x22
1005e8d60:     	bl	0x100b5fbec <_writev+0x100b5fbec>
1005e8d64:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1005e8d68:     	ldr	w19, [x8, #0x590]
1005e8d6c:     	cmp	w19, #0x300
1005e8d70:     	b.hs	0x1005e8f58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x454>
1005e8d74:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1005e8d78:     	ldr	x8, [x8, #0x48]
1005e8d7c:     	cmn	x8, #0x1
1005e8d80:     	b.eq	0x1005e8f48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x444>
1005e8d84:     	mrs	x9, TPIDRRO_EL0
1005e8d88:     	and	x9, x9, #0xfffffffffffffff8
1005e8d8c:     	ldr	x0, [x9, x8, lsl #3]
1005e8d90:     	cbz	x0, 0x1005e8f48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x444>
1005e8d94:     	add	x8, x0, x19, lsl #3
1005e8d98:     	ldr	x0, [x8, #0x1e8]
1005e8d9c:     	cbz	x0, 0x1005e8f58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x454>
1005e8da0:     	ldr	x8, [x0]
1005e8da4:     	adds	x8, x8, x23
1005e8da8:     	csinv	x8, x8, xzr, lo
1005e8dac:     	str	x8, [x0]
1005e8db0:     	lsr	x8, x8, #25
1005e8db4:     	cbz	x8, 0x1005e8e38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005e8db8:     	bl	0x10045ce34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005e8dbc:     	b	0x1005e8e38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005e8dc0:     	add	x8, x2, #0x14
1005e8dc4:     	ldr	x9, [x0]
1005e8dc8:     	cbz	x9, 0x1005e8e08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005e8dcc:     	add	x9, x8, #0xf
1005e8dd0:     	and	x9, x9, #0xfffffffffffffff8
1005e8dd4:     	cmp	x9, #0x4, lsl #12       ; =0x4000
1005e8dd8:     	b.hi	0x1005e8e08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005e8ddc:     	ldr	x10, [x0, #0x10]
1005e8de0:     	ldrb	w10, [x10]
1005e8de4:     	tbnz	w10, #0x0, 0x1005e8e08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005e8de8:     	ldr	x10, [x0, #0x8]
1005e8dec:     	ldp	x11, x12, [x10, #0x8]
1005e8df0:     	add	x11, x11, #0x7
1005e8df4:     	and	x11, x11, #0xfffffffffffffff8
1005e8df8:     	subs	x12, x12, x11
1005e8dfc:     	csel	x12, xzr, x12, lo
1005e8e00:     	cmp	x9, x12
1005e8e04:     	b.ls	0x1005e8ee0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x3dc>
1005e8e08:     	mov	x0, x2
1005e8e0c:     	mov	x22, x2
1005e8e10:     	bl	0x100348d2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1005e8e14:     	mov	x21, x0
1005e8e18:     	mov	x0, x1
1005e8e1c:     	stp	w20, w22, [x21]
1005e8e20:     	str	w22, [x21, #0x8]
1005e8e24:     	mov	x8, #0x200000000        ; =8589934592
1005e8e28:     	stur	x8, [x21, #0xc]
1005e8e2c:     	mov	x1, x19
1005e8e30:     	mov	x2, x22
1005e8e34:     	bl	0x100b5fbec <_writev+0x100b5fbec>
1005e8e38:     	mov	x0, x21
1005e8e3c:     	ldp	x29, x30, [sp, #0x50]
1005e8e40:     	ldp	x20, x19, [sp, #0x40]
1005e8e44:     	ldp	x22, x21, [sp, #0x30]
1005e8e48:     	ldp	x24, x23, [sp, #0x20]
1005e8e4c:     	add	sp, sp, #0x60
1005e8e50:     	ret
1005e8e54:     	add	x8, sp, #0x8
1005e8e58:     	mov	x0, x19
1005e8e5c:     	mov	x1, x21
1005e8e60:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
1005e8e64:     	ldr	x8, [sp, #0x8]
1005e8e68:     	cbz	x8, 0x1005e8f20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x41c>
1005e8e6c:     	mov	w20, #0x0               ; =0
1005e8e70:     	mov	x8, #0x0                ; =0
1005e8e74:     	mov	w9, #0x2                ; =2
1005e8e78:     	mov	w10, #0x3               ; =3
1005e8e7c:     	mov	w11, #0x4               ; =4
1005e8e80:     	mov	x2, x23
1005e8e84:     	mov	x0, x22
1005e8e88:     	b	0x1005e8ea0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x39c>
1005e8e8c:     	add	w20, w20, #0x1
1005e8e90:     	mov	w12, #0x1               ; =1
1005e8e94:     	add	x8, x12, x8
1005e8e98:     	cmp	x8, x21
1005e8e9c:     	b.hs	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8ea0:     	ldrsb	w12, [x19, x8]
1005e8ea4:     	tbz	w12, #0x1f, 0x1005e8e8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x388>
1005e8ea8:     	and	w12, w12, #0xff
1005e8eac:     	cmp	w12, #0xc0
1005e8eb0:     	b.lo	0x1005e8e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x38c>
1005e8eb4:     	cmp	w12, #0xf0
1005e8eb8:     	add	w13, w20, #0x2
1005e8ebc:     	csel	x14, x10, x11, lo
1005e8ec0:     	csinc	w13, w13, w20, hs
1005e8ec4:     	cmp	w12, #0xe0
1005e8ec8:     	csel	x12, x9, x14, lo
1005e8ecc:     	csinc	w20, w13, w20, hs
1005e8ed0:     	add	x8, x12, x8
1005e8ed4:     	cmp	x8, x21
1005e8ed8:     	b.lo	0x1005e8ea0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x39c>
1005e8edc:     	b	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8ee0:     	ldr	x12, [x10]
1005e8ee4:     	add	x22, x12, x11
1005e8ee8:     	add	x11, x11, x9
1005e8eec:     	str	x11, [x10, #0x8]
1005e8ef0:     	mov	w10, #0x203             ; =515
1005e8ef4:     	stp	w10, w9, [x22]
1005e8ef8:     	add	x21, x22, #0x8
1005e8efc:     	sub	x10, x9, #0x8
1005e8f00:     	subs	x10, x10, x8
1005e8f04:     	csel	x1, xzr, x10, lo
1005e8f08:     	b.ls	0x1005e8fac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4a8>
1005e8f0c:     	cmp	x1, #0x9
1005e8f10:     	b.hs	0x1005e8f9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x498>
1005e8f14:     	add	x8, x22, x9
1005e8f18:     	stur	xzr, [x8, #-0x8]
1005e8f1c:     	b	0x1005e8fac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4a8>
1005e8f20:     	ldr	x8, [sp, #0x18]
1005e8f24:     	mov	x2, x23
1005e8f28:     	mov	x0, x22
1005e8f2c:     	cbz	x8, 0x1005e8f80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x47c>
1005e8f30:     	ldr	x9, [sp, #0x10]
1005e8f34:     	cmp	x8, #0x8
1005e8f38:     	b.hs	0x1005e8f88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x484>
1005e8f3c:     	mov	x10, #0x0               ; =0
1005e8f40:     	mov	w20, #0x0               ; =0
1005e8f44:     	b	0x1005e927c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x778>
1005e8f48:     	bl	0x100b3d1bc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005e8f4c:     	add	x8, x0, x19, lsl #3
1005e8f50:     	ldr	x0, [x8, #0x1e8]
1005e8f54:     	cbnz	x0, 0x1005e8da0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x29c>
1005e8f58:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
1005e8f5c:     	add	x0, x0, #0x90
1005e8f60:     	bl	0x100b3a9dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005e8f64:     	ldr	x8, [x0]
1005e8f68:     	adds	x8, x8, x23
1005e8f6c:     	csinv	x8, x8, xzr, lo
1005e8f70:     	str	x8, [x0]
1005e8f74:     	lsr	x8, x8, #25
1005e8f78:     	cbnz	x8, 0x1005e8db8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2b4>
1005e8f7c:     	b	0x1005e8e38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005e8f80:     	mov	w20, #0x0               ; =0
1005e8f84:     	b	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8f88:     	cmp	x8, #0x20
1005e8f8c:     	b.hs	0x1005e8fc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4c4>
1005e8f90:     	mov	x10, #0x0               ; =0
1005e8f94:     	mov	w20, #0x0               ; =0
1005e8f98:     	b	0x1005e91cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x6c8>
1005e8f9c:     	add	x0, x21, x8
1005e8fa0:     	mov	x23, x2
1005e8fa4:     	bl	0x100b5f724 <_writev+0x100b5f724>
1005e8fa8:     	mov	x2, x23
1005e8fac:     	stp	w20, w2, [x22, #0x8]
1005e8fb0:     	str	w2, [x22, #0x10]
1005e8fb4:     	mov	x8, #0x200000000        ; =8589934592
1005e8fb8:     	stur	x8, [x22, #0x14]
1005e8fbc:     	add	x0, x22, #0x1c
1005e8fc0:     	mov	x1, x19
1005e8fc4:     	b	0x1005e8e34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x330>
1005e8fc8:     	movi.2d	v0, #0000000000000000
1005e8fcc:     	and	x11, x8, #0x18
1005e8fd0:     	movi.16b	v1, #0xf0
1005e8fd4:     	and	x10, x8, #0xffffffffffffffe0
1005e8fd8:     	movi.4s	v2, #0x2
1005e8fdc:     	add	x12, x9, #0x10
1005e8fe0:     	movi.16b	v4, #0xc0
1005e8fe4:     	and	x13, x8, #0xffffffffffffffe0
1005e8fe8:     	movi.2d	v3, #0000000000000000
1005e8fec:     	movi.2d	v6, #0000000000000000
1005e8ff0:     	movi.2d	v5, #0000000000000000
1005e8ff4:     	movi.2d	v7, #0000000000000000
1005e8ff8:     	movi.2d	v16, #0000000000000000
1005e8ffc:     	movi.2d	v17, #0000000000000000
1005e9000:     	movi.2d	v18, #0000000000000000
1005e9004:     	ldp	q20, q19, [x12, #-0x10]
1005e9008:     	cmhi.16b	v21, v1, v20
1005e900c:     	sshll2.8h	v22, v21, #0x0
1005e9010:     	sshll2.4s	v23, v22, #0x0
1005e9014:     	sshll.4s	v24, v22, #0x0
1005e9018:     	sshll.8h	v21, v21, #0x0
1005e901c:     	sshll2.4s	v25, v21, #0x0
1005e9020:     	sshll.4s	v26, v21, #0x0
1005e9024:     	cmhi.16b	v27, v1, v19
1005e9028:     	sshll2.8h	v28, v27, #0x0
1005e902c:     	sshll2.4s	v29, v28, #0x0
1005e9030:     	sshll.4s	v30, v28, #0x0
1005e9034:     	sshll.8h	v27, v27, #0x0
1005e9038:     	sshll2.4s	v31, v27, #0x0
1005e903c:     	bic.16b	v26, v2, v26
1005e9040:     	ssubw.4s	v26, v26, v21
1005e9044:     	bic.16b	v25, v2, v25
1005e9048:     	ssubw2.4s	v25, v25, v21
1005e904c:     	sshll.4s	v21, v27, #0x0
1005e9050:     	bic.16b	v24, v2, v24
1005e9054:     	ssubw.4s	v24, v24, v22
1005e9058:     	bic.16b	v23, v2, v23
1005e905c:     	ssubw2.4s	v22, v23, v22
1005e9060:     	bic.16b	v21, v2, v21
1005e9064:     	ssubw.4s	v21, v21, v27
1005e9068:     	bic.16b	v23, v2, v31
1005e906c:     	ssubw2.4s	v23, v23, v27
1005e9070:     	bic.16b	v27, v2, v30
1005e9074:     	ssubw.4s	v27, v27, v28
1005e9078:     	bic.16b	v29, v2, v29
1005e907c:     	ssubw2.4s	v28, v29, v28
1005e9080:     	cmgt.16b	v29, v4, v20
1005e9084:     	sshll2.8h	v30, v29, #0x0
1005e9088:     	ushll2.4s	v31, v30, #0x0
1005e908c:     	bic.16b	v22, v22, v31
1005e9090:     	cmlt.16b	v20, v20, #0
1005e9094:     	sshll.8h	v29, v29, #0x0
1005e9098:     	ushll.4s	v30, v30, #0x0
1005e909c:     	bic.16b	v24, v24, v30
1005e90a0:     	ushll2.4s	v30, v29, #0x0
1005e90a4:     	bic.16b	v25, v25, v30
1005e90a8:     	sshll2.8h	v30, v20, #0x0
1005e90ac:     	sshll.8h	v20, v20, #0x0
1005e90b0:     	ushll.4s	v29, v29, #0x0
1005e90b4:     	bic.16b	v26, v26, v29
1005e90b8:     	sshll.4s	v29, v20, #0x0
1005e90bc:     	and.16b	v26, v26, v29
1005e90c0:     	mvn.16b	v29, v29
1005e90c4:     	sub.4s	v26, v26, v29
1005e90c8:     	sshll2.4s	v29, v30, #0x0
1005e90cc:     	sshll.4s	v30, v30, #0x0
1005e90d0:     	sshll2.4s	v20, v20, #0x0
1005e90d4:     	and.16b	v25, v25, v20
1005e90d8:     	mvn.16b	v20, v20
1005e90dc:     	sub.4s	v20, v25, v20
1005e90e0:     	cmgt.16b	v25, v4, v19
1005e90e4:     	and.16b	v24, v24, v30
1005e90e8:     	mvn.16b	v30, v30
1005e90ec:     	sub.4s	v24, v24, v30
1005e90f0:     	sshll2.8h	v30, v25, #0x0
1005e90f4:     	and.16b	v22, v22, v29
1005e90f8:     	mvn.16b	v29, v29
1005e90fc:     	sub.4s	v22, v22, v29
1005e9100:     	ushll2.4s	v29, v30, #0x0
1005e9104:     	bic.16b	v28, v28, v29
1005e9108:     	cmlt.16b	v19, v19, #0
1005e910c:     	sshll.8h	v25, v25, #0x0
1005e9110:     	ushll.4s	v29, v30, #0x0
1005e9114:     	bic.16b	v27, v27, v29
1005e9118:     	ushll2.4s	v29, v25, #0x0
1005e911c:     	bic.16b	v23, v23, v29
1005e9120:     	sshll.8h	v29, v19, #0x0
1005e9124:     	ushll.4s	v25, v25, #0x0
1005e9128:     	bic.16b	v21, v21, v25
1005e912c:     	sshll.4s	v25, v29, #0x0
1005e9130:     	and.16b	v21, v21, v25
1005e9134:     	mvn.16b	v25, v25
1005e9138:     	sub.4s	v21, v21, v25
1005e913c:     	sshll2.8h	v19, v19, #0x0
1005e9140:     	sshll2.4s	v25, v29, #0x0
1005e9144:     	and.16b	v23, v23, v25
1005e9148:     	mvn.16b	v25, v25
1005e914c:     	sub.4s	v23, v23, v25
1005e9150:     	sshll.4s	v25, v19, #0x0
1005e9154:     	and.16b	v27, v27, v25
1005e9158:     	mvn.16b	v25, v25
1005e915c:     	sub.4s	v25, v27, v25
1005e9160:     	sshll2.4s	v19, v19, #0x0
1005e9164:     	and.16b	v27, v28, v19
1005e9168:     	mvn.16b	v19, v19
1005e916c:     	sub.4s	v19, v27, v19
1005e9170:     	add.4s	v7, v22, v7
1005e9174:     	add.4s	v5, v24, v5
1005e9178:     	add.4s	v6, v20, v6
1005e917c:     	add.4s	v3, v26, v3
1005e9180:     	add.4s	v18, v19, v18
1005e9184:     	add.4s	v17, v25, v17
1005e9188:     	add.4s	v0, v23, v0
1005e918c:     	add.4s	v16, v21, v16
1005e9190:     	add	x12, x12, #0x20
1005e9194:     	subs	x13, x13, #0x20
1005e9198:     	b.ne	0x1005e9004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x500>
1005e919c:     	add.4s	v0, v0, v6
1005e91a0:     	add.4s	v1, v18, v7
1005e91a4:     	add.4s	v2, v16, v3
1005e91a8:     	add.4s	v3, v17, v5
1005e91ac:     	add.4s	v2, v2, v3
1005e91b0:     	add.4s	v0, v0, v1
1005e91b4:     	add.4s	v0, v2, v0
1005e91b8:     	addv.4s	s0, v0
1005e91bc:     	fmov	w20, s0
1005e91c0:     	cmp	x8, x10
1005e91c4:     	b.eq	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e91c8:     	cbz	x11, 0x1005e927c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x778>
1005e91cc:     	mov	x12, x10
1005e91d0:     	and	x10, x8, #0xfffffffffffffff8
1005e91d4:     	movi.2d	v0, #0000000000000000
1005e91d8:     	mov.s	v0[0], w20
1005e91dc:     	movi.2d	v1, #0000000000000000
1005e91e0:     	sub	x11, x12, x10
1005e91e4:     	add	x12, x9, x12
1005e91e8:     	movi.8b	v2, #0xf0
1005e91ec:     	movi.4s	v3, #0x2
1005e91f0:     	movi.8b	v4, #0xc0
1005e91f4:     	ldr	d5, [x12], #0x8
1005e91f8:     	sshll.8h	v6, v5, #0x0
1005e91fc:     	cmlt.8h	v6, v6, #0
1005e9200:     	sshll2.4s	v7, v6, #0x0
1005e9204:     	sshll.4s	v6, v6, #0x0
1005e9208:     	cmhi.8b	v16, v2, v5
1005e920c:     	sshll.8h	v16, v16, #0x0
1005e9210:     	sshll2.4s	v17, v16, #0x0
1005e9214:     	sshll.4s	v18, v16, #0x0
1005e9218:     	bic.16b	v18, v3, v18
1005e921c:     	ssubw.4s	v18, v18, v16
1005e9220:     	bic.16b	v17, v3, v17
1005e9224:     	ssubw2.4s	v16, v17, v16
1005e9228:     	cmgt.8b	v5, v4, v5
1005e922c:     	sshll.8h	v5, v5, #0x0
1005e9230:     	ushll.4s	v17, v5, #0x0
1005e9234:     	ushll2.4s	v5, v5, #0x0
1005e9238:     	bic.16b	v5, v16, v5
1005e923c:     	bic.16b	v16, v18, v17
1005e9240:     	and.16b	v16, v16, v6
1005e9244:     	mvn.16b	v6, v6
1005e9248:     	sub.4s	v6, v16, v6
1005e924c:     	and.16b	v5, v5, v7
1005e9250:     	mvn.16b	v7, v7
1005e9254:     	sub.4s	v5, v5, v7
1005e9258:     	add.4s	v1, v5, v1
1005e925c:     	add.4s	v0, v6, v0
1005e9260:     	adds	x11, x11, #0x8
1005e9264:     	b.ne	0x1005e91f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x6f0>
1005e9268:     	add.4s	v0, v0, v1
1005e926c:     	addv.4s	s0, v0
1005e9270:     	fmov	w20, s0
1005e9274:     	cmp	x8, x10
1005e9278:     	b.eq	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e927c:     	sub	x8, x8, x10
1005e9280:     	add	x9, x9, x10
1005e9284:     	mov	w10, #0x1               ; =1
1005e9288:     	ldrsb	w11, [x9], #0x1
1005e928c:     	and	w12, w11, #0xff
1005e9290:     	cmp	w12, #0xf0
1005e9294:     	cinc	w13, w10, hs
1005e9298:     	cmp	w12, #0xc0
1005e929c:     	csel	w12, wzr, w13, lo
1005e92a0:     	tst	w11, #0x80000000
1005e92a4:     	csinc	w11, w12, wzr, ne
1005e92a8:     	add	w20, w11, w20
1005e92ac:     	subs	x8, x8, #0x1
1005e92b0:     	b.ne	0x1005e9288 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x784>
1005e92b4:     	b	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
