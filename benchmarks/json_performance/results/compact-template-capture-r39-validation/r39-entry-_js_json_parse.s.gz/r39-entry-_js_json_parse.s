
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/compact-template-capture-r39/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100848cd4 <_js_json_parse>:
100848cd4:     	stp	x29, x30, [sp, #-0x10]!
100848cd8:     	mov	x29, sp
100848cdc:     	cbz	x0, 0x100848d34 <_js_json_parse+0x60>
100848ce0:     	ldr	w1, [x0, #0x4]
100848ce4:     	cmp	w1, #0x2
100848ce8:     	b.eq	0x100848cf8 <_js_json_parse+0x24>
100848cec:     	cbz	w1, 0x100848d34 <_js_json_parse+0x60>
100848cf0:     	ldrb	w8, [x0, #0x14]
100848cf4:     	b	0x100848d18 <_js_json_parse+0x44>
100848cf8:     	ldrb	w8, [x0, #0x14]
100848cfc:     	cmp	w8, #0x7b
100848d00:     	b.ne	0x100848d18 <_js_json_parse+0x44>
100848d04:     	ldrb	w8, [x0, #0x15]
100848d08:     	cmp	w8, #0x7d
100848d0c:     	b.ne	0x100848d24 <_js_json_parse+0x50>
100848d10:     	ldp	x29, x30, [sp], #0x10
100848d14:     	b	0x1004ef3c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100848d18:     	orr	w8, w8, #0x20
100848d1c:     	cmp	w8, #0x7b
100848d20:     	b.ne	0x100848d2c <_js_json_parse+0x58>
100848d24:     	ldp	x29, x30, [sp], #0x10
100848d28:     	b	0x100508c88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
100848d2c:     	ldp	x29, x30, [sp], #0x10
100848d30:     	b	0x10050b3cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100848d34:     	adrp	x0, 0x100c7a000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x7294>
100848d38:     	add	x0, x0, #0x1fd
100848d3c:     	mov	w1, #0x1c               ; =28
100848d40:     	bl	0x10050b800 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
