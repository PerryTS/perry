
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/compact-template-capture-r39/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010084a140 <_js_json_stringify_full>:
10084a140:     	sub	sp, sp, #0x120
10084a144:     	stp	d9, d8, [sp, #0xb0]
10084a148:     	stp	x28, x27, [sp, #0xc0]
10084a14c:     	stp	x26, x25, [sp, #0xd0]
10084a150:     	stp	x24, x23, [sp, #0xe0]
10084a154:     	stp	x22, x21, [sp, #0xf0]
10084a158:     	stp	x20, x19, [sp, #0x100]
10084a15c:     	stp	x29, x30, [sp, #0x110]
10084a160:     	add	x29, sp, #0x110
10084a164:     	mov.16b	v9, v2
10084a168:     	mov.16b	v8, v0
10084a16c:     	fmov	x19, d8
10084a170:     	fmov	x21, d1
10084a174:     	fmov	x23, d9
10084a178:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
10084a17c:     	add	x27, x21, x8
10084a180:     	add	x24, x23, x8
10084a184:     	fcmp	d2, #0.0
10084a188:     	ccmp	x24, #0x2, #0x0, ne
10084a18c:     	b.hi	0x10084a19c <_js_json_stringify_full+0x5c>
10084a190:     	cmp	x27, #0x2
10084a194:     	b.lo	0x10084a1ac <_js_json_stringify_full+0x6c>
10084a198:     	b	0x10084a718 <_js_json_stringify_full+0x5d8>
10084a19c:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
10084a1a0:     	cmp	x23, x8
10084a1a4:     	ccmp	x27, #0x2, #0x2, eq
10084a1a8:     	b.hs	0x10084a718 <_js_json_stringify_full+0x5d8>
10084a1ac:     	mov	x8, #-0x2               ; =-2
10084a1b0:     	movk	x8, #0x8003, lsl #48
10084a1b4:     	add	x8, x19, x8
10084a1b8:     	cmp	x8, #0x3
10084a1bc:     	b.hs	0x10084a1d0 <_js_json_stringify_full+0x90>
10084a1c0:     	adrp	x9, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5230>
10084a1c4:     	add	x9, x9, #0x358
10084a1c8:     	ldr	x20, [x9, x8, lsl #3]
10084a1cc:     	b	0x10084b5e8 <_js_json_stringify_full+0x14a8>
10084a1d0:     	strb	wzr, [sp, #0x4c]
10084a1d4:     	str	wzr, [sp, #0x48]
10084a1d8:     	and	x8, x19, #0xffff000000000000
10084a1dc:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084a1e0:     	cmp	x8, x9
10084a1e4:     	b.eq	0x10084a258 <_js_json_stringify_full+0x118>
10084a1e8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084a1ec:     	cmp	x8, x9
10084a1f0:     	b.ne	0x10084a654 <_js_json_stringify_full+0x514>
10084a1f4:     	ubfx	x10, x19, #40, #8
10084a1f8:     	cbz	x10, 0x10084a248 <_js_json_stringify_full+0x108>
10084a1fc:     	strb	w19, [sp, #0x48]
10084a200:     	cmp	x10, #0x1
10084a204:     	b.eq	0x10084a248 <_js_json_stringify_full+0x108>
10084a208:     	lsr	x9, x19, #8
10084a20c:     	strb	w9, [sp, #0x49]
10084a210:     	cmp	x10, #0x2
10084a214:     	b.eq	0x10084a248 <_js_json_stringify_full+0x108>
10084a218:     	lsr	x9, x19, #16
10084a21c:     	strb	w9, [sp, #0x4a]
10084a220:     	cmp	x10, #0x3
10084a224:     	b.eq	0x10084a248 <_js_json_stringify_full+0x108>
10084a228:     	lsr	x9, x19, #24
10084a22c:     	strb	w9, [sp, #0x4b]
10084a230:     	cmp	x10, #0x4
10084a234:     	b.eq	0x10084a248 <_js_json_stringify_full+0x108>
10084a238:     	lsr	x9, x19, #32
10084a23c:     	strb	w9, [sp, #0x4c]
10084a240:     	cmp	x10, #0x5
10084a244:     	b.ne	0x10084bdbc <_js_json_stringify_full+0x1c7c>
10084a248:     	add	x11, sp, #0x48
10084a24c:     	cmp	w10, #0x3
10084a250:     	b.ls	0x10084a270 <_js_json_stringify_full+0x130>
10084a254:     	b	0x10084a654 <_js_json_stringify_full+0x514>
10084a258:     	ands	x9, x19, #0xffffffffffff
10084a25c:     	b.eq	0x10084a718 <_js_json_stringify_full+0x5d8>
10084a260:     	add	x11, x9, #0x14
10084a264:     	ldr	w10, [x9, #0x4]
10084a268:     	cmp	w10, #0x3
10084a26c:     	b.hi	0x10084a654 <_js_json_stringify_full+0x514>
10084a270:     	stur	wzr, [sp, #0x81]
10084a274:     	mov	w9, #0x22               ; =34
10084a278:     	strb	w9, [sp, #0x80]
10084a27c:     	cbz	w10, 0x10084a2b4 <_js_json_stringify_full+0x174>
10084a280:     	add	x12, sp, #0x80
10084a284:     	ldrb	w13, [x11]
10084a288:     	sxtb	w15, w13
10084a28c:     	cmp	w13, #0xb
10084a290:     	b.le	0x10084a2bc <_js_json_stringify_full+0x17c>
10084a294:     	cmp	w13, #0x21
10084a298:     	b.gt	0x10084a2dc <_js_json_stringify_full+0x19c>
10084a29c:     	cmp	w13, #0xc
10084a2a0:     	b.eq	0x10084a310 <_js_json_stringify_full+0x1d0>
10084a2a4:     	cmp	w13, #0xd
10084a2a8:     	b.ne	0x10084a2ec <_js_json_stringify_full+0x1ac>
10084a2ac:     	mov	w15, #0x72              ; =114
10084a2b0:     	b	0x10084a31c <_js_json_stringify_full+0x1dc>
10084a2b4:     	mov	w12, #0x1               ; =1
10084a2b8:     	b	0x10084a344 <_js_json_stringify_full+0x204>
10084a2bc:     	cmp	w13, #0x8
10084a2c0:     	b.eq	0x10084a308 <_js_json_stringify_full+0x1c8>
10084a2c4:     	cmp	w13, #0x9
10084a2c8:     	b.eq	0x10084a318 <_js_json_stringify_full+0x1d8>
10084a2cc:     	cmp	w13, #0xa
10084a2d0:     	b.ne	0x10084a2ec <_js_json_stringify_full+0x1ac>
10084a2d4:     	mov	w15, #0x6e              ; =110
10084a2d8:     	b	0x10084a31c <_js_json_stringify_full+0x1dc>
10084a2dc:     	cmp	w13, #0x22
10084a2e0:     	b.eq	0x10084a31c <_js_json_stringify_full+0x1dc>
10084a2e4:     	cmp	w13, #0x5c
10084a2e8:     	b.eq	0x10084a31c <_js_json_stringify_full+0x1dc>
10084a2ec:     	cmp	w15, #0x20
10084a2f0:     	b.lt	0x10084a654 <_js_json_stringify_full+0x514>
10084a2f4:     	mov	w14, #0x0               ; =0
10084a2f8:     	add	x13, x12, #0x2
10084a2fc:     	mov	w12, #0x2               ; =2
10084a300:     	mov	w16, #0x1               ; =1
10084a304:     	b	0x10084a334 <_js_json_stringify_full+0x1f4>
10084a308:     	mov	w15, #0x62              ; =98
10084a30c:     	b	0x10084a31c <_js_json_stringify_full+0x1dc>
10084a310:     	mov	w15, #0x66              ; =102
10084a314:     	b	0x10084a31c <_js_json_stringify_full+0x1dc>
10084a318:     	mov	w15, #0x74              ; =116
10084a31c:     	add	x13, x12, #0x3
10084a320:     	mov	w12, #0x5c              ; =92
10084a324:     	strb	w12, [sp, #0x81]
10084a328:     	mov	w14, #0x1               ; =1
10084a32c:     	mov	w12, #0x3               ; =3
10084a330:     	mov	w16, #0x2               ; =2
10084a334:     	add	x17, sp, #0x80
10084a338:     	strb	w15, [x17, x16]
10084a33c:     	cmp	w10, #0x1
10084a340:     	b.ne	0x10084a37c <_js_json_stringify_full+0x23c>
10084a344:     	add	x10, sp, #0x80
10084a348:     	strb	w9, [x10, x12]
10084a34c:     	add	x8, x12, #0x1
10084a350:     	cmp	x12, #0x3
10084a354:     	b.hs	0x10084a368 <_js_json_stringify_full+0x228>
10084a358:     	mov	x13, #0x0               ; =0
10084a35c:     	mov	x11, #0x0               ; =0
10084a360:     	add	x9, sp, #0x80
10084a364:     	b	0x10084a5c4 <_js_json_stringify_full+0x484>
10084a368:     	cmp	x12, #0xf
10084a36c:     	b.hs	0x10084a3ac <_js_json_stringify_full+0x26c>
10084a370:     	mov	x11, #0x0               ; =0
10084a374:     	mov	x13, #0x0               ; =0
10084a378:     	b	0x10084a520 <_js_json_stringify_full+0x3e0>
10084a37c:     	ldrb	w16, [x11, #0x1]
10084a380:     	sxtb	w15, w16
10084a384:     	cmp	w16, #0xb
10084a388:     	b.le	0x10084a5f4 <_js_json_stringify_full+0x4b4>
10084a38c:     	cmp	w16, #0x21
10084a390:     	b.gt	0x10084a614 <_js_json_stringify_full+0x4d4>
10084a394:     	cmp	w16, #0xc
10084a398:     	b.eq	0x10084a644 <_js_json_stringify_full+0x504>
10084a39c:     	cmp	w16, #0xd
10084a3a0:     	b.ne	0x10084a624 <_js_json_stringify_full+0x4e4>
10084a3a4:     	mov	w15, #0x72              ; =114
10084a3a8:     	b	0x10084a650 <_js_json_stringify_full+0x510>
10084a3ac:     	and	x12, x8, #0xc
10084a3b0:     	and	x11, x8, #0x10
10084a3b4:     	add	x13, sp, #0x80
10084a3b8:     	add	x9, x13, x11
10084a3bc:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6230>
10084a3c0:     	ldr	q0, [x14, #0x4d0]
10084a3c4:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6230>
10084a3c8:     	ldr	q1, [x14, #0x4e0]
10084a3cc:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6230>
10084a3d0:     	ldr	q2, [x14, #0x4f0]
10084a3d4:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6230>
10084a3d8:     	ldr	q3, [x14, #0x500]
10084a3dc:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6230>
10084a3e0:     	ldr	q4, [x14, #0x510]
10084a3e4:     	movi.2d	v5, #0000000000000000
10084a3e8:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6230>
10084a3ec:     	ldr	q6, [x14, #0x520]
10084a3f0:     	adrp	x14, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5230>
10084a3f4:     	ldr	q7, [x14, #0x640]
10084a3f8:     	mov	w14, #0x10              ; =16
10084a3fc:     	movi.2d	v16, #0000000000000000
10084a400:     	dup.2d	v17, x14
10084a404:     	adrp	x14, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33a3a>
10084a408:     	ldr	q19, [x14, #0x540]
10084a40c:     	and	x14, x8, #0x10
10084a410:     	movi.2d	v20, #0000000000000000
10084a414:     	movi.2d	v18, #0000000000000000
10084a418:     	movi.2d	v23, #0000000000000000
10084a41c:     	movi.2d	v21, #0000000000000000
10084a420:     	movi.2d	v24, #0000000000000000
10084a424:     	movi.2d	v22, #0000000000000000
10084a428:     	ldr	q25, [x13], #0x10
10084a42c:     	ushll.8h	v26, v25, #0x0
10084a430:     	ushll2.4s	v27, v26, #0x0
10084a434:     	ushll2.2d	v28, v27, #0x0
10084a438:     	ushll2.8h	v25, v25, #0x0
10084a43c:     	ushll.4s	v29, v25, #0x0
10084a440:     	ushll2.2d	v30, v29, #0x0
10084a444:     	ushll.2d	v29, v29, #0x0
10084a448:     	ushll.2d	v27, v27, #0x0
10084a44c:     	ushll.4s	v26, v26, #0x0
10084a450:     	ushll2.2d	v31, v26, #0x0
10084a454:     	ushll2.4s	v25, v25, #0x0
10084a458:     	ushll.2d	v8, v25, #0x0
10084a45c:     	ushll.2d	v26, v26, #0x0
10084a460:     	ushll2.2d	v25, v25, #0x0
10084a464:     	shl.2d	v9, v0, #0x3
10084a468:     	ushl.2d	v25, v25, v9
10084a46c:     	shl.2d	v9, v19, #0x3
10084a470:     	ushl.2d	v26, v26, v9
10084a474:     	shl.2d	v9, v1, #0x3
10084a478:     	ushl.2d	v8, v8, v9
10084a47c:     	shl.2d	v9, v7, #0x3
10084a480:     	ushl.2d	v31, v31, v9
10084a484:     	shl.2d	v9, v6, #0x3
10084a488:     	ushl.2d	v27, v27, v9
10084a48c:     	shl.2d	v9, v3, #0x3
10084a490:     	ushl.2d	v29, v29, v9
10084a494:     	shl.2d	v9, v2, #0x3
10084a498:     	ushl.2d	v30, v30, v9
10084a49c:     	shl.2d	v9, v4, #0x3
10084a4a0:     	ushl.2d	v28, v28, v9
10084a4a4:     	orr.16b	v18, v28, v18
10084a4a8:     	orr.16b	v21, v30, v21
10084a4ac:     	orr.16b	v23, v29, v23
10084a4b0:     	orr.16b	v20, v27, v20
10084a4b4:     	orr.16b	v5, v31, v5
10084a4b8:     	orr.16b	v24, v8, v24
10084a4bc:     	orr.16b	v16, v26, v16
10084a4c0:     	orr.16b	v22, v25, v22
10084a4c4:     	add.2d	v6, v6, v17
10084a4c8:     	add.2d	v7, v7, v17
10084a4cc:     	add.2d	v19, v19, v17
10084a4d0:     	add.2d	v4, v4, v17
10084a4d4:     	add.2d	v3, v3, v17
10084a4d8:     	add.2d	v2, v2, v17
10084a4dc:     	add.2d	v1, v1, v17
10084a4e0:     	add.2d	v0, v0, v17
10084a4e4:     	subs	x14, x14, #0x10
10084a4e8:     	b.ne	0x10084a428 <_js_json_stringify_full+0x2e8>
10084a4ec:     	orr.16b	v0, v16, v23
10084a4f0:     	orr.16b	v1, v20, v24
10084a4f4:     	orr.16b	v0, v0, v1
10084a4f8:     	orr.16b	v1, v5, v21
10084a4fc:     	orr.16b	v2, v18, v22
10084a500:     	orr.16b	v1, v1, v2
10084a504:     	orr.16b	v0, v0, v1
10084a508:     	mov	d1, v0[1]
10084a50c:     	orr.8b	v0, v0, v1
10084a510:     	fmov	x13, d0
10084a514:     	cmp	x8, x11
10084a518:     	b.eq	0x10084a5e4 <_js_json_stringify_full+0x4a4>
10084a51c:     	cbz	x12, 0x10084a5c4 <_js_json_stringify_full+0x484>
10084a520:     	mov	x14, x11
10084a524:     	and	x11, x8, #0x1c
10084a528:     	add	x15, sp, #0x80
10084a52c:     	add	x9, x15, x11
10084a530:     	fmov	d0, x13
10084a534:     	movi.2d	v1, #0000000000000000
10084a538:     	dup.2d	v3, x14
10084a53c:     	adrp	x12, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5230>
10084a540:     	ldr	q2, [x12, #0x640]
10084a544:     	orr.16b	v2, v3, v2
10084a548:     	adrp	x12, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33a3a>
10084a54c:     	ldr	q4, [x12, #0x540]
10084a550:     	orr.16b	v3, v3, v4
10084a554:     	sub	x12, x14, x11
10084a558:     	add	x13, x15, x14
10084a55c:     	movi.2d	v4, #0x000000000000ff
10084a560:     	mov	w14, #0x4               ; =4
10084a564:     	dup.2d	v5, x14
10084a568:     	ldr	s6, [x13], #0x4
10084a56c:     	ushll.8h	v6, v6, #0x0
10084a570:     	ushll.4s	v6, v6, #0x0
10084a574:     	ushll2.2d	v7, v6, #0x0
10084a578:     	and.16b	v7, v7, v4
10084a57c:     	ushll.2d	v6, v6, #0x0
10084a580:     	and.16b	v6, v6, v4
10084a584:     	shl.2d	v16, v2, #0x3
10084a588:     	shl.2d	v17, v3, #0x3
10084a58c:     	ushl.2d	v6, v6, v17
10084a590:     	ushl.2d	v7, v7, v16
10084a594:     	orr.16b	v1, v7, v1
10084a598:     	orr.16b	v0, v6, v0
10084a59c:     	add.2d	v2, v2, v5
10084a5a0:     	add.2d	v3, v3, v5
10084a5a4:     	adds	x12, x12, #0x4
10084a5a8:     	b.ne	0x10084a568 <_js_json_stringify_full+0x428>
10084a5ac:     	orr.16b	v0, v0, v1
10084a5b0:     	mov	d1, v0[1]
10084a5b4:     	orr.8b	v0, v0, v1
10084a5b8:     	fmov	x13, d0
10084a5bc:     	cmp	x8, x11
10084a5c0:     	b.eq	0x10084a5e4 <_js_json_stringify_full+0x4a4>
10084a5c4:     	add	x10, x10, x8
10084a5c8:     	lsl	x11, x11, #3
10084a5cc:     	ldrb	w12, [x9], #0x1
10084a5d0:     	lsl	x12, x12, x11
10084a5d4:     	orr	x13, x12, x13
10084a5d8:     	add	x11, x11, #0x8
10084a5dc:     	cmp	x9, x10
10084a5e0:     	b.ne	0x10084a5cc <_js_json_stringify_full+0x48c>
10084a5e4:     	orr	x8, x13, x8, lsl #40
10084a5e8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084a5ec:     	orr	x20, x8, x9
10084a5f0:     	b	0x10084b5e8 <_js_json_stringify_full+0x14a8>
10084a5f4:     	cmp	w16, #0x8
10084a5f8:     	b.eq	0x10084a63c <_js_json_stringify_full+0x4fc>
10084a5fc:     	cmp	w16, #0x9
10084a600:     	b.eq	0x10084a64c <_js_json_stringify_full+0x50c>
10084a604:     	cmp	w16, #0xa
10084a608:     	b.ne	0x10084a624 <_js_json_stringify_full+0x4e4>
10084a60c:     	mov	w15, #0x6e              ; =110
10084a610:     	b	0x10084a650 <_js_json_stringify_full+0x510>
10084a614:     	cmp	w16, #0x22
10084a618:     	b.eq	0x10084a650 <_js_json_stringify_full+0x510>
10084a61c:     	cmp	w16, #0x5c
10084a620:     	b.eq	0x10084a650 <_js_json_stringify_full+0x510>
10084a624:     	cmp	w15, #0x20
10084a628:     	b.lt	0x10084a654 <_js_json_stringify_full+0x514>
10084a62c:     	add	x13, sp, #0x80
10084a630:     	strb	w15, [x13, x12]
10084a634:     	add	x12, x12, #0x1
10084a638:     	b	0x10084abdc <_js_json_stringify_full+0xa9c>
10084a63c:     	mov	w15, #0x62              ; =98
10084a640:     	b	0x10084a650 <_js_json_stringify_full+0x510>
10084a644:     	mov	w15, #0x66              ; =102
10084a648:     	b	0x10084a650 <_js_json_stringify_full+0x510>
10084a64c:     	mov	w15, #0x74              ; =116
10084a650:     	tbz	w14, #0x0, 0x10084abc8 <_js_json_stringify_full+0xa88>
10084a654:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084a658:     	cmp	x8, x9
10084a65c:     	b.eq	0x10084a6a4 <_js_json_stringify_full+0x564>
10084a660:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084a664:     	cmp	x8, x9
10084a668:     	b.ne	0x10084a718 <_js_json_stringify_full+0x5d8>
10084a66c:     	and	x8, x19, #0xffffffffffff
10084a670:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
10084a674:     	mov	x10, #0x7fffffffffff    ; =140737488355327
10084a678:     	movk	x10, #0xffef, lsl #16
10084a67c:     	cmp	x9, x10
10084a680:     	b.hi	0x10084a718 <_js_json_stringify_full+0x5d8>
10084a684:     	ldr	w8, [x8, #0x4]
10084a688:     	cmp	w8, #0x40
10084a68c:     	b.lo	0x10084a718 <_js_json_stringify_full+0x5d8>
10084a690:     	and	x0, x19, #0xffffffffffff
10084a694:     	bl	0x1004f5968 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
10084a698:     	cmp	x0, #0x1
10084a69c:     	b.ne	0x10084a718 <_js_json_stringify_full+0x5d8>
10084a6a0:     	b	0x10084a864 <_js_json_stringify_full+0x724>
10084a6a4:     	and	x25, x19, #0xffffffffffff
10084a6a8:     	and	x0, x19, #0xffffffffffff
10084a6ac:     	bl	0x10057d980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084a6b0:     	cbz	x0, 0x10084a6e4 <_js_json_stringify_full+0x5a4>
10084a6b4:     	ldrb	w8, [x0]
10084a6b8:     	cmp	w8, #0x2
10084a6bc:     	b.ne	0x10084a6e4 <_js_json_stringify_full+0x5a4>
10084a6c0:     	ldrsb	w8, [x0, #0x1]
10084a6c4:     	tbnz	w8, #0x1f, 0x10084a6e4 <_js_json_stringify_full+0x5a4>
10084a6c8:     	ldrh	w8, [x0, #0x2]
10084a6cc:     	tbnz	w8, #0xb, 0x10084a6e4 <_js_json_stringify_full+0x5a4>
10084a6d0:     	ldr	w8, [x0, #0x4]
10084a6d4:     	cmp	w8, #0x18
10084a6d8:     	b.lo	0x10084a6e4 <_js_json_stringify_full+0x5a4>
10084a6dc:     	ldr	w8, [x25]
10084a6e0:     	cbz	w8, 0x10084b73c <_js_json_stringify_full+0x15fc>
10084a6e4:     	and	x0, x19, #0xffffffffffff
10084a6e8:     	bl	0x10057d980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084a6ec:     	cbz	x0, 0x10084a718 <_js_json_stringify_full+0x5d8>
10084a6f0:     	ldrb	w8, [x0]
10084a6f4:     	cmp	w8, #0x2
10084a6f8:     	b.ne	0x10084a718 <_js_json_stringify_full+0x5d8>
10084a6fc:     	ldrh	w8, [x0, #0x2]
10084a700:     	tbnz	w8, #0xb, 0x10084a718 <_js_json_stringify_full+0x5d8>
10084a704:     	ldr	w8, [x0, #0x4]
10084a708:     	cmp	w8, #0x18
10084a70c:     	b.lo	0x10084a718 <_js_json_stringify_full+0x5d8>
10084a710:     	ldr	w8, [x25]
10084a714:     	cbz	w8, 0x10084b6e0 <_js_json_stringify_full+0x15a0>
10084a718:     	mov	x20, #0x1               ; =1
10084a71c:     	movk	x20, #0x7ffc, lsl #48
10084a720:     	cmp	x19, x20
10084a724:     	b.eq	0x10084b5e8 <_js_json_stringify_full+0x14a8>
10084a728:     	and	x22, x19, #0xffff000000000000
10084a72c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a730:     	cmp	x22, x8
10084a734:     	b.ne	0x10084a76c <_js_json_stringify_full+0x62c>
10084a738:     	and	x8, x19, #0xffffffffffff
10084a73c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084a740:     	b.lo	0x10084a758 <_js_json_stringify_full+0x618>
10084a744:     	ldr	w8, [x8, #0xc]
10084a748:     	mov	w9, #0x4f53             ; =20307
10084a74c:     	movk	w9, #0x434c, lsl #16
10084a750:     	cmp	w8, w9
10084a754:     	b.eq	0x10084b5e8 <_js_json_stringify_full+0x14a8>
10084a758:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a75c:     	cmp	x22, x8
10084a760:     	b.ne	0x10084a798 <_js_json_stringify_full+0x658>
10084a764:     	and	x0, x19, #0xffffffffffff
10084a768:     	b	0x10084a7c0 <_js_json_stringify_full+0x680>
10084a76c:     	lsr	x8, x19, #52
10084a770:     	cbnz	x8, 0x10084a848 <_js_json_stringify_full+0x708>
10084a774:     	and	x8, x19, #0x7
10084a778:     	cbz	x19, 0x10084a7a4 <_js_json_stringify_full+0x664>
10084a77c:     	cbnz	x8, 0x10084a7a4 <_js_json_stringify_full+0x664>
10084a780:     	mov	x0, x19
10084a784:     	bl	0x1005120f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084a788:     	mov	x8, x19
10084a78c:     	tbnz	w0, #0x0, 0x10084a73c <_js_json_stringify_full+0x5fc>
10084a790:     	mov	x8, #0x0                ; =0
10084a794:     	b	0x10084a7a4 <_js_json_stringify_full+0x664>
10084a798:     	lsr	x8, x19, #52
10084a79c:     	cbnz	x8, 0x10084a848 <_js_json_stringify_full+0x708>
10084a7a0:     	and	x8, x19, #0x7
10084a7a4:     	cbz	x19, 0x10084a848 <_js_json_stringify_full+0x708>
10084a7a8:     	cbnz	x8, 0x10084a848 <_js_json_stringify_full+0x708>
10084a7ac:     	mov	x0, x19
10084a7b0:     	bl	0x1005120f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084a7b4:     	mov	x8, x0
10084a7b8:     	mov	x0, x19
10084a7bc:     	tbz	w8, #0x0, 0x10084a848 <_js_json_stringify_full+0x708>
10084a7c0:     	cmp	x0, #0x100, lsl #12     ; =0x100000
10084a7c4:     	b.lo	0x10084a848 <_js_json_stringify_full+0x708>
10084a7c8:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084a7cc:     	add	x8, x8, #0xfb0
10084a7d0:     	ldaprb	w8, [x8]
10084a7d4:     	cbz	w8, 0x10084a848 <_js_json_stringify_full+0x708>
10084a7d8:     	lsr	x8, x0, #3
10084a7dc:     	mov	x9, #0x7c15             ; =31765
10084a7e0:     	movk	x9, #0x7f4a, lsl #16
10084a7e4:     	movk	x9, #0x79b9, lsl #32
10084a7e8:     	movk	x9, #0x9e37, lsl #48
10084a7ec:     	mul	x8, x8, x9
10084a7f0:     	lsr	x10, x8, #54
10084a7f4:     	lsr	x11, x8, #60
10084a7f8:     	adrp	x9, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084a7fc:     	add	x9, x9, #0xf30
10084a800:     	add	x11, x9, x11, lsl #3
10084a804:     	ldapr	x11, [x11]
10084a808:     	lsr	x10, x11, x10
10084a80c:     	tbz	w10, #0x0, 0x10084a848 <_js_json_stringify_full+0x708>
10084a810:     	lsr	x10, x8, #44
10084a814:     	ubfx	x11, x8, #50, #4
10084a818:     	add	x11, x9, x11, lsl #3
10084a81c:     	ldapr	x11, [x11]
10084a820:     	lsr	x10, x11, x10
10084a824:     	tbz	w10, #0x0, 0x10084a848 <_js_json_stringify_full+0x708>
10084a828:     	lsr	x10, x8, #34
10084a82c:     	ubfx	x8, x8, #40, #4
10084a830:     	add	x8, x9, x8, lsl #3
10084a834:     	ldapr	x8, [x8]
10084a838:     	lsr	x8, x8, x10
10084a83c:     	tbz	w8, #0x0, 0x10084a848 <_js_json_stringify_full+0x708>
10084a840:     	bl	0x10034f4cc <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
10084a844:     	tbnz	w0, #0x0, 0x10084b5e8 <_js_json_stringify_full+0x14a8>
10084a848:     	cmp	x24, #0x3
10084a84c:     	ccmp	x27, #0x2, #0x2, lo
10084a850:     	b.hs	0x10084a870 <_js_json_stringify_full+0x730>
10084a854:     	mov.16b	v0, v8
10084a858:     	bl	0x1004f0a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084a85c:     	cmp	x0, #0x1
10084a860:     	b.ne	0x10084a870 <_js_json_stringify_full+0x730>
10084a864:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
10084a868:     	bfxil	x20, x1, #0, #48
10084a86c:     	b	0x10084b5e8 <_js_json_stringify_full+0x14a8>
10084a870:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a874:     	cmp	x22, x8
10084a878:     	b.ne	0x10084a8c8 <_js_json_stringify_full+0x788>
10084a87c:     	ands	x22, x19, #0xffffffffffff
10084a880:     	b.eq	0x10084a8c8 <_js_json_stringify_full+0x788>
10084a884:     	mov	x0, x22
10084a888:     	bl	0x1005120f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084a88c:     	cbz	w0, 0x10084a8c8 <_js_json_stringify_full+0x788>
10084a890:     	ldurb	w8, [x22, #-0x8]
10084a894:     	cmp	w8, #0x9
10084a898:     	b.ne	0x10084a8c8 <_js_json_stringify_full+0x788>
10084a89c:     	ldr	w8, [x22, #0x4]
10084a8a0:     	mov	w9, #0x5841             ; =22593
10084a8a4:     	movk	w9, #0x4c5a, lsl #16
10084a8a8:     	cmp	w8, w9
10084a8ac:     	b.ne	0x10084a8c8 <_js_json_stringify_full+0x788>
10084a8b0:     	mov	x0, x22
10084a8b4:     	bl	0x10068bd64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
10084a8b8:     	cbz	x0, 0x10084a8c8 <_js_json_stringify_full+0x788>
10084a8bc:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
10084a8c0:     	bfxil	x19, x0, #0, #48
10084a8c4:     	fmov	d8, x19
10084a8c8:     	mov	w8, #0x7ffd             ; =32765
10084a8cc:     	cmp	x8, x23, lsr #48
10084a8d0:     	b.ne	0x10084a8e4 <_js_json_stringify_full+0x7a4>
10084a8d4:     	and	x1, x23, #0xffffffffffff
10084a8d8:     	cmp	x1, #0x100, lsl #12     ; =0x100000
10084a8dc:     	b.hs	0x10084a8f8 <_js_json_stringify_full+0x7b8>
10084a8e0:     	b	0x10084a94c <_js_json_stringify_full+0x80c>
10084a8e4:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
10084a8e8:     	mov	x9, #0xfffffff00000     ; =281474975662080
10084a8ec:     	mov	x1, x23
10084a8f0:     	cmp	x8, x9
10084a8f4:     	b.hs	0x10084a94c <_js_json_stringify_full+0x80c>
10084a8f8:     	lsr	x8, x1, #47
10084a8fc:     	cbnz	x8, 0x10084a94c <_js_json_stringify_full+0x80c>
10084a900:     	add	x0, sp, #0x80
10084a904:     	bl	0x1007726ac <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
10084a908:     	ldr	w8, [sp, #0x80]
10084a90c:     	tbz	w8, #0x0, 0x10084a94c <_js_json_stringify_full+0x80c>
10084a910:     	ldr	w8, [sp, #0x88]
10084a914:     	mov	w9, #-0xff30            ; =-65328
10084a918:     	cmp	w8, w9
10084a91c:     	b.eq	0x10084a940 <_js_json_stringify_full+0x800>
10084a920:     	mov	w9, #-0xff2f            ; =-65327
10084a924:     	cmp	w8, w9
10084a928:     	b.ne	0x10084a94c <_js_json_stringify_full+0x80c>
10084a92c:     	mov.16b	v0, v9
10084a930:     	bl	0x10084c9fc <_js_jsvalue_to_string>
10084a934:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
10084a938:     	bfxil	x23, x0, #0, #48
10084a93c:     	b	0x10084a94c <_js_json_stringify_full+0x80c>
10084a940:     	mov.16b	v0, v9
10084a944:     	bl	0x100873fa0 <_js_number_coerce>
10084a948:     	fmov	x23, d0
10084a94c:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
10084a950:     	add	x8, x23, x8
10084a954:     	cmp	x8, #0x3
10084a958:     	b.hs	0x10084a970 <_js_json_stringify_full+0x830>
10084a95c:     	mov	x22, #0x0               ; =0
10084a960:     	mov	w8, #0x1                ; =1
10084a964:     	stp	xzr, x8, [sp, #0x10]
10084a968:     	str	xzr, [sp, #0x20]
10084a96c:     	b	0x10084ac24 <_js_json_stringify_full+0xae4>
10084a970:     	and	x8, x23, #0xffff000000000000
10084a974:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084a978:     	cmp	x8, x9
10084a97c:     	b.eq	0x10084a9a0 <_js_json_stringify_full+0x860>
10084a980:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084a984:     	cmp	x8, x9
10084a988:     	b.ne	0x10084aa2c <_js_json_stringify_full+0x8ec>
10084a98c:     	and	x8, x23, #0xffffffffffff
10084a990:     	cmp	x8, #0x1, lsl #12       ; =0x1000
10084a994:     	b.hs	0x10084aa74 <_js_json_stringify_full+0x934>
10084a998:     	mov	x9, #0x0                ; =0
10084a99c:     	b	0x10084aa7c <_js_json_stringify_full+0x93c>
10084a9a0:     	strb	wzr, [sp, #0x4c]
10084a9a4:     	str	wzr, [sp, #0x48]
10084a9a8:     	ubfx	x1, x23, #40, #8
10084a9ac:     	cbz	x1, 0x10084a9fc <_js_json_stringify_full+0x8bc>
10084a9b0:     	strb	w23, [sp, #0x48]
10084a9b4:     	cmp	x1, #0x1
10084a9b8:     	b.eq	0x10084a9fc <_js_json_stringify_full+0x8bc>
10084a9bc:     	lsr	x8, x23, #8
10084a9c0:     	strb	w8, [sp, #0x49]
10084a9c4:     	cmp	x1, #0x2
10084a9c8:     	b.eq	0x10084a9fc <_js_json_stringify_full+0x8bc>
10084a9cc:     	lsr	x8, x23, #16
10084a9d0:     	strb	w8, [sp, #0x4a]
10084a9d4:     	cmp	x1, #0x3
10084a9d8:     	b.eq	0x10084a9fc <_js_json_stringify_full+0x8bc>
10084a9dc:     	lsr	x8, x23, #24
10084a9e0:     	strb	w8, [sp, #0x4b]
10084a9e4:     	cmp	x1, #0x4
10084a9e8:     	b.eq	0x10084a9fc <_js_json_stringify_full+0x8bc>
10084a9ec:     	lsr	x8, x23, #32
10084a9f0:     	strb	w8, [sp, #0x4c]
10084a9f4:     	cmp	x1, #0x5
10084a9f8:     	b.ne	0x10084bdbc <_js_json_stringify_full+0x1c7c>
10084a9fc:     	add	x8, sp, #0x80
10084aa00:     	add	x0, sp, #0x48
10084aa04:     	bl	0x10002dc18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10084aa08:     	ldr	w8, [sp, #0x80]
10084aa0c:     	ldp	x9, x22, [sp, #0x88]
10084aa10:     	cmp	w8, #0x0
10084aa14:     	csinc	x23, x9, xzr, eq
10084aa18:     	csel	x25, xzr, x22, ne
10084aa1c:     	tbz	x25, #0x3f, 0x10084ab5c <_js_json_stringify_full+0xa1c>
10084aa20:     	mov	x0, #0x0                ; =0
10084aa24:     	mov	x1, x22
10084aa28:     	bl	0x100b16f40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084aa2c:     	add	x8, x20, #0x3
10084aa30:     	cmp	x23, x8
10084aa34:     	b.eq	0x10084a95c <_js_json_stringify_full+0x81c>
10084aa38:     	fmov	d0, x23
10084aa3c:     	fcvtzu	x8, d0
10084aa40:     	mov	w9, #0xa                ; =10
10084aa44:     	cmp	x8, #0xa
10084aa48:     	csel	x3, x8, x9, lo
10084aa4c:     	adrp	x1, 0x100c48000 <_PERRY_EMPTY_STRING+0x1e74>
10084aa50:     	add	x1, x1, #0x364
10084aa54:     	add	x0, sp, #0x80
10084aa58:     	mov	w2, #0x1                ; =1
10084aa5c:     	bl	0x1002304f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
10084aa60:     	ldr	x22, [sp, #0x90]
10084aa64:     	str	x22, [sp, #0x20]
10084aa68:     	ldr	q0, [sp, #0x80]
10084aa6c:     	str	q0, [sp, #0x10]
10084aa70:     	b	0x10084ac24 <_js_json_stringify_full+0xae4>
10084aa74:     	ldr	w22, [x8, #0x4]
10084aa78:     	add	x9, x8, #0x14
10084aa7c:     	mov	x14, #0x0               ; =0
10084aa80:     	mov	x8, #0x0                ; =0
10084aa84:     	cmp	x9, #0x0
10084aa88:     	csel	x24, xzr, x22, eq
10084aa8c:     	csinc	x23, x9, xzr, ne
10084aa90:     	add	x9, x23, x24
10084aa94:     	mov	w10, #0x1               ; =1
10084aa98:     	mov	x11, x23
10084aa9c:     	b	0x10084aacc <_js_json_stringify_full+0x98c>
10084aaa0:     	add	x12, x11, #0x2
10084aaa4:     	bfi	w15, w13, #6, #5
10084aaa8:     	mov	x13, x15
10084aaac:     	sub	x11, x25, x11
10084aab0:     	add	x14, x11, x12
10084aab4:     	cmp	w13, #0x10, lsl #12     ; =0x10000
10084aab8:     	cinc	x11, x10, hs
10084aabc:     	add	x8, x11, x8
10084aac0:     	mov	x11, x12
10084aac4:     	cmp	x8, #0xa
10084aac8:     	b.hi	0x10084ab84 <_js_json_stringify_full+0xa44>
10084aacc:     	cmp	x11, x9
10084aad0:     	b.eq	0x10084ab34 <_js_json_stringify_full+0x9f4>
10084aad4:     	mov	x25, x14
10084aad8:     	mov	x12, x11
10084aadc:     	ldrsb	w14, [x12], #0x1
10084aae0:     	and	w13, w14, #0xff
10084aae4:     	tbz	w14, #0x1f, 0x10084aaac <_js_json_stringify_full+0x96c>
10084aae8:     	ldrb	w12, [x11, #0x1]
10084aaec:     	and	w15, w12, #0x3f
10084aaf0:     	cmp	w13, #0xe0
10084aaf4:     	b.lo	0x10084aaa0 <_js_json_stringify_full+0x960>
10084aaf8:     	and	w14, w13, #0x1f
10084aafc:     	ldrb	w12, [x11, #0x2]
10084ab00:     	and	w12, w12, #0x3f
10084ab04:     	orr	w15, w12, w15, lsl #6
10084ab08:     	cmp	w13, #0xf0
10084ab0c:     	b.lo	0x10084ab28 <_js_json_stringify_full+0x9e8>
10084ab10:     	add	x12, x11, #0x4
10084ab14:     	ldrb	w13, [x11, #0x3]
10084ab18:     	and	w13, w13, #0x3f
10084ab1c:     	orr	w13, w13, w15, lsl #6
10084ab20:     	bfi	w13, w14, #18, #3
10084ab24:     	b	0x10084aaac <_js_json_stringify_full+0x96c>
10084ab28:     	add	x12, x11, #0x3
10084ab2c:     	orr	w13, w15, w14, lsl #12
10084ab30:     	b	0x10084aaac <_js_json_stringify_full+0x96c>
10084ab34:     	cbz	x24, 0x10084abb8 <_js_json_stringify_full+0xa78>
10084ab38:     	mov	x0, x24
10084ab3c:     	mov	w1, #0x1                ; =1
10084ab40:     	bl	0x100b63e48 <_mi_malloc_aligned>
10084ab44:     	cbz	x0, 0x10084bda4 <_js_json_stringify_full+0x1c64>
10084ab48:     	mov	x26, x0
10084ab4c:     	mov	x1, x23
10084ab50:     	mov	x2, x24
10084ab54:     	bl	0x100b66a6c <_writev+0x100b66a6c>
10084ab58:     	b	0x10084abc0 <_js_json_stringify_full+0xa80>
10084ab5c:     	cbz	x25, 0x10084ac14 <_js_json_stringify_full+0xad4>
10084ab60:     	mov	x0, x25
10084ab64:     	mov	w1, #0x1                ; =1
10084ab68:     	bl	0x100b63e48 <_mi_malloc_aligned>
10084ab6c:     	cbz	x0, 0x10084bdb0 <_js_json_stringify_full+0x1c70>
10084ab70:     	mov	x24, x0
10084ab74:     	mov	x1, x23
10084ab78:     	mov	x2, x25
10084ab7c:     	bl	0x100b66a6c <_writev+0x100b66a6c>
10084ab80:     	b	0x10084ac1c <_js_json_stringify_full+0xadc>
10084ab84:     	cbz	x25, 0x10084abb8 <_js_json_stringify_full+0xa78>
10084ab88:     	cmp	x25, x24
10084ab8c:     	b.hs	0x10084b634 <_js_json_stringify_full+0x14f4>
10084ab90:     	ldrsb	w8, [x23, x25]
10084ab94:     	cmn	w8, #0x40
10084ab98:     	b.ge	0x10084b638 <_js_json_stringify_full+0x14f8>
10084ab9c:     	adrp	x4, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084aba0:     	add	x4, x4, #0x270
10084aba4:     	mov	x0, x23
10084aba8:     	mov	x1, x24
10084abac:     	mov	x2, #0x0                ; =0
10084abb0:     	mov	x3, x25
10084abb4:     	bl	0x100b172b8 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
10084abb8:     	mov	x22, #0x0               ; =0
10084abbc:     	mov	w26, #0x1               ; =1
10084abc0:     	stp	x22, x26, [sp, #0x10]
10084abc4:     	b	0x10084ac20 <_js_json_stringify_full+0xae0>
10084abc8:     	add	x14, sp, #0x80
10084abcc:     	mov	w16, #0x5c              ; =92
10084abd0:     	strb	w16, [x14, x12]
10084abd4:     	add	x12, x12, #0x2
10084abd8:     	strb	w15, [x13, #0x1]
10084abdc:     	cmp	w10, #0x2
10084abe0:     	b.eq	0x10084a344 <_js_json_stringify_full+0x204>
10084abe4:     	ldrb	w11, [x11, #0x2]
10084abe8:     	sxtb	w10, w11
10084abec:     	cmp	w11, #0xb
10084abf0:     	b.le	0x10084b6c0 <_js_json_stringify_full+0x1580>
10084abf4:     	cmp	w11, #0x21
10084abf8:     	b.gt	0x10084b70c <_js_json_stringify_full+0x15cc>
10084abfc:     	cmp	w11, #0xc
10084ac00:     	b.eq	0x10084b798 <_js_json_stringify_full+0x1658>
10084ac04:     	cmp	w11, #0xd
10084ac08:     	b.ne	0x10084b71c <_js_json_stringify_full+0x15dc>
10084ac0c:     	mov	w10, #0x72              ; =114
10084ac10:     	b	0x10084b7a4 <_js_json_stringify_full+0x1664>
10084ac14:     	mov	x22, #0x0               ; =0
10084ac18:     	mov	w24, #0x1               ; =1
10084ac1c:     	stp	x22, x24, [sp, #0x10]
10084ac20:     	str	x22, [sp, #0x20]
10084ac24:     	cmp	x27, #0x2
10084ac28:     	b.lo	0x10084ad68 <_js_json_stringify_full+0xc28>
10084ac2c:     	and	x25, x21, #0xffff000000000000
10084ac30:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084ac34:     	cmp	x25, x8
10084ac38:     	b.ne	0x10084ad44 <_js_json_stringify_full+0xc04>
10084ac3c:     	and	x23, x21, #0xffffffffffff
10084ac40:     	cmp	x23, #0x100, lsl #12    ; =0x100000
10084ac44:     	b.lo	0x10084ad68 <_js_json_stringify_full+0xc28>
10084ac48:     	mov	x0, x23
10084ac4c:     	bl	0x10050d600 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
10084ac50:     	tbnz	w0, #0x0, 0x10084ad68 <_js_json_stringify_full+0xc28>
10084ac54:     	lsr	x8, x23, #51
10084ac58:     	cmp	x8, #0xfff
10084ac5c:     	b.lo	0x10084ac74 <_js_json_stringify_full+0xb34>
10084ac60:     	mov	w8, #0x7ffc             ; =32764
10084ac64:     	cmp	x8, x23, lsr #48
10084ac68:     	b.eq	0x10084ad68 <_js_json_stringify_full+0xc28>
10084ac6c:     	ands	x23, x23, #0xffffffffffff
10084ac70:     	b.eq	0x10084ad68 <_js_json_stringify_full+0xc28>
10084ac74:     	and	x8, x23, #0xfffffffffff00000
10084ac78:     	lsr	x9, x23, #47
10084ac7c:     	cmp	x9, #0x0
10084ac80:     	ccmp	x8, #0x0, #0x4, eq
10084ac84:     	b.eq	0x10084ad68 <_js_json_stringify_full+0xc28>
10084ac88:     	tst	x23, #0x3
10084ac8c:     	ccmp	x23, #0x7, #0x0, eq
10084ac90:     	b.ls	0x10084b9d4 <_js_json_stringify_full+0x1894>
10084ac94:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084ac98:     	ldr	x8, [x8, #0x48]
10084ac9c:     	cmn	x8, #0x1
10084aca0:     	b.eq	0x10084b924 <_js_json_stringify_full+0x17e4>
10084aca4:     	mrs	x9, TPIDRRO_EL0
10084aca8:     	and	x9, x9, #0xfffffffffffffff8
10084acac:     	ldr	x0, [x9, x8, lsl #3]
10084acb0:     	cbz	x0, 0x10084b924 <_js_json_stringify_full+0x17e4>
10084acb4:     	lsr	x1, x23, #20
10084acb8:     	ldr	x8, [x0, #0x10]
10084acbc:     	ldrb	w9, [x8]
10084acc0:     	cmp	w9, #0x2
10084acc4:     	b.ne	0x10084b93c <_js_json_stringify_full+0x17fc>
10084acc8:     	ldrb	w9, [x8, #0x88]
10084accc:     	tbz	w9, #0x0, 0x10084acec <_js_json_stringify_full+0xbac>
10084acd0:     	ldr	x9, [x8, #0x80]
10084acd4:     	cmp	x9, x1
10084acd8:     	b.ne	0x10084acec <_js_json_stringify_full+0xbac>
10084acdc:     	ldp	x9, x10, [x8, #0x60]
10084ace0:     	cmp	x9, x23
10084ace4:     	ccmp	x10, x23, #0x0, ls
10084ace8:     	b.hi	0x10084b91c <_js_json_stringify_full+0x17dc>
10084acec:     	ldrb	w9, [x8, #0xb8]
10084acf0:     	cbz	w9, 0x10084ad10 <_js_json_stringify_full+0xbd0>
10084acf4:     	ldr	x9, [x8, #0xb0]
10084acf8:     	cmp	x9, x1
10084acfc:     	b.ne	0x10084ad10 <_js_json_stringify_full+0xbd0>
10084ad00:     	ldp	x9, x10, [x8, #0x90]
10084ad04:     	cmp	x9, x23
10084ad08:     	ccmp	x10, x23, #0x0, ls
10084ad0c:     	b.hi	0x10084bba4 <_js_json_stringify_full+0x1a64>
10084ad10:     	ldrb	w9, [x8, #0xe8]
10084ad14:     	cbz	w9, 0x10084b75c <_js_json_stringify_full+0x161c>
10084ad18:     	ldr	x9, [x8, #0xe0]
10084ad1c:     	cmp	x9, x1
10084ad20:     	b.ne	0x10084b75c <_js_json_stringify_full+0x161c>
10084ad24:     	ldr	x9, [x8, #0xc0]
10084ad28:     	cmp	x9, x23
10084ad2c:     	b.hi	0x10084b75c <_js_json_stringify_full+0x161c>
10084ad30:     	ldr	x9, [x8, #0xc8]
10084ad34:     	cmp	x9, x23
10084ad38:     	b.ls	0x10084b75c <_js_json_stringify_full+0x161c>
10084ad3c:     	add	x9, x8, #0xc0
10084ad40:     	b	0x10084bba8 <_js_json_stringify_full+0x1a68>
10084ad44:     	lsr	x8, x21, #52
10084ad48:     	cbnz	x8, 0x10084ad68 <_js_json_stringify_full+0xc28>
10084ad4c:     	cbz	x21, 0x10084ad68 <_js_json_stringify_full+0xc28>
10084ad50:     	and	x8, x21, #0x7
10084ad54:     	cbnz	x8, 0x10084ad68 <_js_json_stringify_full+0xc28>
10084ad58:     	mov	x0, x21
10084ad5c:     	bl	0x1005120f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084ad60:     	mov	x23, x21
10084ad64:     	cbnz	w0, 0x10084ac40 <_js_json_stringify_full+0xb00>
10084ad68:     	mov	x25, #-0x1              ; =-1
10084ad6c:     	str	x25, [sp, #0x30]
10084ad70:     	mov	w24, #0x1               ; =1
10084ad74:     	cmp	x27, #0x1
10084ad78:     	cset	w8, hi
10084ad7c:     	tst	w8, w24
10084ad80:     	b.eq	0x10084adf4 <_js_json_stringify_full+0xcb4>
10084ad84:     	and	x23, x21, #0xffff000000000000
10084ad88:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084ad8c:     	cmp	x23, x8
10084ad90:     	b.ne	0x10084adcc <_js_json_stringify_full+0xc8c>
10084ad94:     	and	x8, x21, #0xffffffffffff
10084ad98:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084ad9c:     	b.lo	0x10084adf4 <_js_json_stringify_full+0xcb4>
10084ada0:     	ldr	w8, [x8, #0xc]
10084ada4:     	mov	w9, #0x4f53             ; =20307
10084ada8:     	movk	w9, #0x434c, lsl #16
10084adac:     	cmp	w8, w9
10084adb0:     	b.ne	0x10084adf4 <_js_json_stringify_full+0xcb4>
10084adb4:     	and	x8, x21, #0xffffffffffff
10084adb8:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084adbc:     	cmp	x23, x9
10084adc0:     	csel	x28, x8, x21, eq
10084adc4:     	mov	w27, #0x1               ; =1
10084adc8:     	b	0x10084adf8 <_js_json_stringify_full+0xcb8>
10084adcc:     	lsr	x8, x21, #52
10084add0:     	cbnz	x8, 0x10084adf4 <_js_json_stringify_full+0xcb4>
10084add4:     	mov	w27, #0x0               ; =0
10084add8:     	cbz	x21, 0x10084adf8 <_js_json_stringify_full+0xcb8>
10084addc:     	and	x8, x21, #0x7
10084ade0:     	cbnz	x8, 0x10084adf8 <_js_json_stringify_full+0xcb8>
10084ade4:     	mov	x0, x21
10084ade8:     	bl	0x1005120f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084adec:     	mov	x8, x21
10084adf0:     	tbnz	w0, #0x0, 0x10084ad98 <_js_json_stringify_full+0xc58>
10084adf4:     	mov	w27, #0x0               ; =0
10084adf8:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084adfc:     	add	x0, x0, #0xd78
10084ae00:     	ldr	x8, [x0]
10084ae04:     	blr	x8
10084ae08:     	mov	x21, x0
10084ae0c:     	ldr	w26, [x0]
10084ae10:     	add	w8, w26, #0x1
10084ae14:     	str	w8, [x0]
10084ae18:     	cbz	w26, 0x10084ae88 <_js_json_stringify_full+0xd48>
10084ae1c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084ae20:     	add	x0, x0, #0xd00
10084ae24:     	ldr	x8, [x0]
10084ae28:     	blr	x8
10084ae2c:     	ldrb	w8, [x0, #0x20]
10084ae30:     	cmp	w8, #0x1
10084ae34:     	b.ne	0x10084bc14 <_js_json_stringify_full+0x1ad4>
10084ae38:     	ldr	x8, [x0]
10084ae3c:     	cbnz	x8, 0x10084bc20 <_js_json_stringify_full+0x1ae0>
10084ae40:     	mov	x8, #-0x1               ; =-1
10084ae44:     	str	x8, [x0]
10084ae48:     	ldr	x23, [x0, #0x18]
10084ae4c:     	ldr	x8, [x0, #0x8]
10084ae50:     	cmp	x23, x8
10084ae54:     	b.eq	0x10084b610 <_js_json_stringify_full+0x14d0>
10084ae58:     	ldr	x8, [x0, #0x10]
10084ae5c:     	mov	w9, #0x18               ; =24
10084ae60:     	madd	x8, x23, x9, x8
10084ae64:     	mov	w9, #0x8                ; =8
10084ae68:     	stp	xzr, x9, [x8]
10084ae6c:     	str	xzr, [x8, #0x10]
10084ae70:     	add	x8, x23, #0x1
10084ae74:     	str	x8, [x0, #0x18]
10084ae78:     	ldr	x8, [x0]
10084ae7c:     	add	x8, x8, #0x1
10084ae80:     	str	x8, [x0]
10084ae84:     	b	0x10084aef0 <_js_json_stringify_full+0xdb0>
10084ae88:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084ae8c:     	add	x0, x0, #0xdc0
10084ae90:     	ldr	x8, [x0]
10084ae94:     	blr	x8
10084ae98:     	strb	wzr, [x0]
10084ae9c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084aea0:     	add	x0, x0, #0xdf0
10084aea4:     	ldr	x8, [x0]
10084aea8:     	blr	x8
10084aeac:     	strb	wzr, [x0]
10084aeb0:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
10084aeb4:     	ldr	w23, [x8, #0x5a8]
10084aeb8:     	cmp	w23, #0x300
10084aebc:     	b.hs	0x10084b658 <_js_json_stringify_full+0x1518>
10084aec0:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084aec4:     	ldr	x8, [x8, #0x48]
10084aec8:     	cmn	x8, #0x1
10084aecc:     	b.eq	0x10084b648 <_js_json_stringify_full+0x1508>
10084aed0:     	mrs	x9, TPIDRRO_EL0
10084aed4:     	and	x9, x9, #0xfffffffffffffff8
10084aed8:     	ldr	x0, [x9, x8, lsl #3]
10084aedc:     	cbz	x0, 0x10084b648 <_js_json_stringify_full+0x1508>
10084aee0:     	add	x8, x0, x23, lsl #3
10084aee4:     	ldr	x0, [x8, #0x1e8]
10084aee8:     	cbz	x0, 0x10084b658 <_js_json_stringify_full+0x1518>
10084aeec:     	str	xzr, [x0]
10084aef0:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084aef4:     	add	x0, x0, #0xd30
10084aef8:     	ldr	x8, [x0]
10084aefc:     	blr	x8
10084af00:     	mov	x23, x0
10084af04:     	ldrb	w8, [x0, #0x18]
10084af08:     	cmp	w8, #0x1
10084af0c:     	b.ne	0x10084bbc8 <_js_json_stringify_full+0x1a88>
10084af10:     	ldr	x8, [x0]
10084af14:     	mov	x9, #-0x1               ; =-1
10084af18:     	str	x9, [x0]
10084af1c:     	cmn	x8, #0x2
10084af20:     	b.eq	0x10084bd50 <_js_json_stringify_full+0x1c10>
10084af24:     	cmn	x8, #0x1
10084af28:     	b.eq	0x10084affc <_js_json_stringify_full+0xebc>
10084af2c:     	add	x9, sp, #0x48
10084af30:     	ldur	q0, [x0, #0x8]
10084af34:     	stur	q0, [x9, #0x8]
10084af38:     	str	x8, [sp, #0x48]
10084af3c:     	tbz	w24, #0x0, 0x10084b010 <_js_json_stringify_full+0xed0>
10084af40:     	tbz	w27, #0x0, 0x10084b0f8 <_js_json_stringify_full+0xfb8>
10084af44:     	bl	0x10028ddd8 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
10084af48:     	str	x0, [sp, #0x60]
10084af4c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084af50:     	stp	x28, x8, [sp, #0x88]
10084af54:     	mov	w8, #0x1                ; =1
10084af58:     	str	x8, [sp, #0x80]
10084af5c:     	add	x0, sp, #0x80
10084af60:     	bl	0x10028dee0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
10084af64:     	mov	x22, x0
10084af68:     	str	x0, [sp, #0x68]
10084af6c:     	mov	w0, #0x0                ; =0
10084af70:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084af74:     	stp	xzr, xzr, [x0]
10084af78:     	str	wzr, [x0, #0x10]
10084af7c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10084af80:     	bfxil	x8, x0, #0, #48
10084af84:     	fmov	d0, x8
10084af88:     	bl	0x10020b024 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
10084af8c:     	mov	x19, x0
10084af90:     	adrp	x24, 0x100f84000 <_perry_global_worker_ts__1>
10084af94:     	ldr	x8, [x24, #0x48]
10084af98:     	cmn	x8, #0x1
10084af9c:     	b.eq	0x10084b15c <_js_json_stringify_full+0x101c>
10084afa0:     	mrs	x9, TPIDRRO_EL0
10084afa4:     	and	x9, x9, #0xfffffffffffffff8
10084afa8:     	ldr	x8, [x9, x8, lsl #3]
10084afac:     	cbz	x8, 0x10084b15c <_js_json_stringify_full+0x101c>
10084afb0:     	ldr	x8, [x8, #0x19e8]
10084afb4:     	cbz	x8, 0x10084b15c <_js_json_stringify_full+0x101c>
10084afb8:     	ldr	x9, [x8]
10084afbc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084afc0:     	cmp	x9, x10
10084afc4:     	b.hs	0x10084bc9c <_js_json_stringify_full+0x1b5c>
10084afc8:     	add	x10, x9, #0x1
10084afcc:     	str	x10, [x8]
10084afd0:     	ldr	x10, [x8, #0x18]
10084afd4:     	cmp	x19, x10
10084afd8:     	b.hs	0x10084bca8 <_js_json_stringify_full+0x1b68>
10084afdc:     	ldr	x10, [x8, #0x10]
10084afe0:     	mov	w11, #0x18              ; =24
10084afe4:     	madd	x10, x19, x11, x10
10084afe8:     	ldr	x11, [x10]
10084afec:     	cbnz	x11, 0x10084bd08 <_js_json_stringify_full+0x1bc8>
10084aff0:     	ldr	x0, [x10, #0x8]
10084aff4:     	str	x9, [x8]
10084aff8:     	b	0x10084b164 <_js_json_stringify_full+0x1024>
10084affc:     	mov	x8, #0x0                ; =0
10084b000:     	mov	w9, #0x1                ; =1
10084b004:     	stp	x9, xzr, [sp, #0x50]
10084b008:     	str	x8, [sp, #0x48]
10084b00c:     	tbnz	w24, #0x0, 0x10084af40 <_js_json_stringify_full+0xe00>
10084b010:     	cmp	x22, #0x0
10084b014:     	cset	w6, ne
10084b018:     	ldp	x0, x1, [sp, #0x38]
10084b01c:     	ldp	x3, x4, [sp, #0x18]
10084b020:     	add	x2, sp, #0x48
10084b024:     	mov.16b	v0, v8
10084b028:     	mov	x5, #0x0                ; =0
10084b02c:     	bl	0x100505b40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
10084b030:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b034:     	add	x0, x0, #0xd90
10084b038:     	ldr	x8, [x0]
10084b03c:     	blr	x8
10084b040:     	ldrb	w8, [x0, #0x20]
10084b044:     	cbnz	w8, 0x10084bc2c <_js_json_stringify_full+0x1aec>
10084b048:     	ldr	x8, [x0]
10084b04c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10084b050:     	cmp	x8, x9
10084b054:     	b.hs	0x10084bc5c <_js_json_stringify_full+0x1b1c>
10084b058:     	ldr	x9, [x0, #0x18]
10084b05c:     	cbz	x9, 0x10084b068 <_js_json_stringify_full+0xf28>
10084b060:     	cbnz	x8, 0x10084bc68 <_js_json_stringify_full+0x1b28>
10084b064:     	str	xzr, [x0, #0x18]
10084b068:     	ldp	x0, x1, [sp, #0x50]
10084b06c:     	cmp	x1, #0x5
10084b070:     	b.hi	0x10084b0d8 <_js_json_stringify_full+0xf98>
10084b074:     	cbz	x1, 0x10084b2e8 <_js_json_stringify_full+0x11a8>
10084b078:     	ldrsb	w8, [x0]
10084b07c:     	tbnz	w8, #0x1f, 0x10084b0d8 <_js_json_stringify_full+0xf98>
10084b080:     	cmp	x1, #0x1
10084b084:     	b.eq	0x10084b0c0 <_js_json_stringify_full+0xf80>
10084b088:     	ldrsb	w8, [x0, #0x1]
10084b08c:     	tbnz	w8, #0x1f, 0x10084b0d8 <_js_json_stringify_full+0xf98>
10084b090:     	cmp	x1, #0x2
10084b094:     	b.eq	0x10084b0c0 <_js_json_stringify_full+0xf80>
10084b098:     	ldrsb	w8, [x0, #0x2]
10084b09c:     	tbnz	w8, #0x1f, 0x10084b0d8 <_js_json_stringify_full+0xf98>
10084b0a0:     	cmp	x1, #0x3
10084b0a4:     	b.eq	0x10084b0c0 <_js_json_stringify_full+0xf80>
10084b0a8:     	ldrsb	w8, [x0, #0x3]
10084b0ac:     	tbnz	w8, #0x1f, 0x10084b0d8 <_js_json_stringify_full+0xf98>
10084b0b0:     	cmp	x1, #0x4
10084b0b4:     	b.eq	0x10084b0c0 <_js_json_stringify_full+0xf80>
10084b0b8:     	ldrsb	w8, [x0, #0x4]
10084b0bc:     	tbnz	w8, #0x1f, 0x10084b0d8 <_js_json_stringify_full+0xf98>
10084b0c0:     	cmp	x1, #0x4
10084b0c4:     	b.hs	0x10084b428 <_js_json_stringify_full+0x12e8>
10084b0c8:     	mov	x10, #0x0               ; =0
10084b0cc:     	mov	x9, #0x0                ; =0
10084b0d0:     	mov	x8, x0
10084b0d4:     	b	0x10084b4b8 <_js_json_stringify_full+0x1378>
10084b0d8:     	bl	0x10032c848 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
10084b0dc:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
10084b0e0:     	bfxil	x20, x0, #0, #48
10084b0e4:     	ldp	x22, x0, [sp, #0x48]
10084b0e8:     	ldrb	w8, [x23, #0x18]
10084b0ec:     	cmp	w8, #0x1
10084b0f0:     	b.eq	0x10084b4f4 <_js_json_stringify_full+0x13b4>
10084b0f4:     	b	0x10084bbf8 <_js_json_stringify_full+0x1ab8>
10084b0f8:     	mov	w0, #0x0                ; =0
10084b0fc:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084b100:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10084b104:     	bfxil	x8, x0, #0, #48
10084b108:     	fmov	d1, x8
10084b10c:     	stp	xzr, xzr, [x0]
10084b110:     	str	wzr, [x0, #0x10]
10084b114:     	mov.16b	v0, v8
10084b118:     	bl	0x1006ca5e0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
10084b11c:     	mov.16b	v8, v0
10084b120:     	fmov	x24, d8
10084b124:     	cmp	x24, x20
10084b128:     	b.eq	0x10084b370 <_js_json_stringify_full+0x1230>
10084b12c:     	mov	w8, #0x7ffd             ; =32765
10084b130:     	cmp	x8, x24, lsr #48
10084b134:     	b.ne	0x10084b340 <_js_json_stringify_full+0x1200>
10084b138:     	and	x8, x24, #0xffffffffffff
10084b13c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084b140:     	b.lo	0x10084b364 <_js_json_stringify_full+0x1224>
10084b144:     	ldr	w8, [x8, #0xc]
10084b148:     	mov	w9, #0x4f53             ; =20307
10084b14c:     	movk	w9, #0x434c, lsl #16
10084b150:     	cmp	w8, w9
10084b154:     	b.ne	0x10084b364 <_js_json_stringify_full+0x1224>
10084b158:     	b	0x10084b370 <_js_json_stringify_full+0x1230>
10084b15c:     	mov	x0, x19
10084b160:     	bl	0x10013c270 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
10084b164:     	fmov	d1, x0
10084b168:     	mov.16b	v0, v8
10084b16c:     	bl	0x1006ca5e0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
10084b170:     	mov.16b	v8, v0
10084b174:     	ldr	x8, [x24, #0x48]
10084b178:     	cmn	x8, #0x1
10084b17c:     	b.eq	0x10084b1e0 <_js_json_stringify_full+0x10a0>
10084b180:     	mrs	x9, TPIDRRO_EL0
10084b184:     	and	x9, x9, #0xfffffffffffffff8
10084b188:     	ldr	x8, [x9, x8, lsl #3]
10084b18c:     	cbz	x8, 0x10084b1e0 <_js_json_stringify_full+0x10a0>
10084b190:     	ldr	x8, [x8, #0x19e8]
10084b194:     	cbz	x8, 0x10084b1e0 <_js_json_stringify_full+0x10a0>
10084b198:     	ldr	x9, [x8]
10084b19c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084b1a0:     	cmp	x9, x10
10084b1a4:     	b.hs	0x10084bc9c <_js_json_stringify_full+0x1b5c>
10084b1a8:     	add	x10, x9, #0x1
10084b1ac:     	str	x10, [x8]
10084b1b0:     	ldr	x10, [x8, #0x18]
10084b1b4:     	cmp	x22, x10
10084b1b8:     	b.hs	0x10084bca8 <_js_json_stringify_full+0x1b68>
10084b1bc:     	ldr	x10, [x8, #0x10]
10084b1c0:     	mov	w11, #0x18              ; =24
10084b1c4:     	madd	x10, x22, x11, x10
10084b1c8:     	ldr	x11, [x10]
10084b1cc:     	cmp	x11, #0x1
10084b1d0:     	b.ne	0x10084bd68 <_js_json_stringify_full+0x1c28>
10084b1d4:     	ldr	x22, [x10, #0x8]
10084b1d8:     	str	x9, [x8]
10084b1dc:     	b	0x10084b1ec <_js_json_stringify_full+0x10ac>
10084b1e0:     	mov	x0, x22
10084b1e4:     	bl	0x10013c198 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
10084b1e8:     	mov	x22, x0
10084b1ec:     	ldr	x8, [x24, #0x48]
10084b1f0:     	cmn	x8, #0x1
10084b1f4:     	b.eq	0x10084b254 <_js_json_stringify_full+0x1114>
10084b1f8:     	mrs	x9, TPIDRRO_EL0
10084b1fc:     	and	x9, x9, #0xfffffffffffffff8
10084b200:     	ldr	x8, [x9, x8, lsl #3]
10084b204:     	cbz	x8, 0x10084b254 <_js_json_stringify_full+0x1114>
10084b208:     	ldr	x8, [x8, #0x19e8]
10084b20c:     	cbz	x8, 0x10084b254 <_js_json_stringify_full+0x1114>
10084b210:     	ldr	x9, [x8]
10084b214:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084b218:     	cmp	x9, x10
10084b21c:     	b.hs	0x10084bc9c <_js_json_stringify_full+0x1b5c>
10084b220:     	add	x10, x9, #0x1
10084b224:     	str	x10, [x8]
10084b228:     	ldr	x10, [x8, #0x18]
10084b22c:     	cmp	x19, x10
10084b230:     	b.hs	0x10084bca8 <_js_json_stringify_full+0x1b68>
10084b234:     	ldr	x10, [x8, #0x10]
10084b238:     	mov	w11, #0x18              ; =24
10084b23c:     	madd	x10, x19, x11, x10
10084b240:     	ldr	x11, [x10]
10084b244:     	cbnz	x11, 0x10084bd08 <_js_json_stringify_full+0x1bc8>
10084b248:     	ldr	x0, [x10, #0x8]
10084b24c:     	str	x9, [x8]
10084b250:     	b	0x10084b25c <_js_json_stringify_full+0x111c>
10084b254:     	mov	x0, x19
10084b258:     	bl	0x10013c270 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
10084b25c:     	fmov	d9, x0
10084b260:     	mov.16b	v0, v8
10084b264:     	bl	0x1005024e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
10084b268:     	mov.16b	v2, v0
10084b26c:     	mov	x0, x22
10084b270:     	mov.16b	v0, v9
10084b274:     	mov.16b	v1, v8
10084b278:     	bl	0x1005027c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
10084b27c:     	str	d0, [sp, #0x70]
10084b280:     	fmov	x19, d0
10084b284:     	cmp	x19, x20
10084b288:     	b.ne	0x10084b2f0 <_js_json_stringify_full+0x11b0>
10084b28c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b290:     	add	x0, x0, #0xd90
10084b294:     	ldr	x8, [x0]
10084b298:     	blr	x8
10084b29c:     	ldrb	w8, [x0, #0x20]
10084b2a0:     	cbnz	w8, 0x10084bd48 <_js_json_stringify_full+0x1c08>
10084b2a4:     	ldr	x8, [x0]
10084b2a8:     	cbnz	x8, 0x10084bd98 <_js_json_stringify_full+0x1c58>
10084b2ac:     	str	xzr, [x0, #0x18]
10084b2b0:     	ldp	x22, x19, [sp, #0x48]
10084b2b4:     	ldrb	w8, [x23, #0x18]
10084b2b8:     	cmp	w8, #0x1
10084b2bc:     	b.ne	0x10084bce0 <_js_json_stringify_full+0x1ba0>
10084b2c0:     	ldp	x8, x0, [x23]
10084b2c4:     	stp	x22, x19, [x23]
10084b2c8:     	str	xzr, [x23, #0x10]
10084b2cc:     	sub	x8, x8, #0x1
10084b2d0:     	cmn	x8, #0x2
10084b2d4:     	b.hs	0x10084b2dc <_js_json_stringify_full+0x119c>
10084b2d8:     	bl	0x100b63bc0 <_mi_free>
10084b2dc:     	cbz	w26, 0x10084b57c <_js_json_stringify_full+0x143c>
10084b2e0:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b2e4:     	b	0x10084b580 <_js_json_stringify_full+0x1440>
10084b2e8:     	mov	x10, #0x0               ; =0
10084b2ec:     	b	0x10084b4d8 <_js_json_stringify_full+0x1398>
10084b2f0:     	add	x0, sp, #0x48
10084b2f4:     	bl	0x1005031a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
10084b2f8:     	tbnz	w0, #0x0, 0x10084b334 <_js_json_stringify_full+0x11f4>
10084b2fc:     	mov	x0, x19
10084b300:     	bl	0x10032a7ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
10084b304:     	cmp	x0, #0x1
10084b308:     	b.ne	0x10084bd5c <_js_json_stringify_full+0x1c1c>
10084b30c:     	add	x8, sp, #0x78
10084b310:     	add	x9, sp, #0x70
10084b314:     	stp	x1, x8, [sp, #0x78]
10084b318:     	str	x9, [sp, #0x88]
10084b31c:     	add	x8, sp, #0x48
10084b320:     	add	x9, sp, #0x10
10084b324:     	stp	x8, x9, [sp, #0x90]
10084b328:     	add	x0, sp, #0x68
10084b32c:     	add	x1, sp, #0x80
10084b330:     	bl	0x100143c90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
10084b334:     	add	x0, sp, #0x60
10084b338:     	bl	0x100166d7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
10084b33c:     	b	0x10084b030 <_js_json_stringify_full+0xef0>
10084b340:     	lsr	x8, x24, #52
10084b344:     	cbnz	x8, 0x10084b364 <_js_json_stringify_full+0x1224>
10084b348:     	cbz	x24, 0x10084b364 <_js_json_stringify_full+0x1224>
10084b34c:     	and	x8, x24, #0x7
10084b350:     	cbnz	x8, 0x10084b364 <_js_json_stringify_full+0x1224>
10084b354:     	mov	x0, x24
10084b358:     	bl	0x1005120f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084b35c:     	mov	x8, x24
10084b360:     	tbnz	w0, #0x0, 0x10084b13c <_js_json_stringify_full+0xffc>
10084b364:     	mov	x0, x24
10084b368:     	bl	0x10050c46c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
10084b36c:     	tbz	w0, #0x0, 0x10084b3fc <_js_json_stringify_full+0x12bc>
10084b370:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b374:     	add	x0, x0, #0xd90
10084b378:     	ldr	x8, [x0]
10084b37c:     	blr	x8
10084b380:     	ldrb	w8, [x0, #0x20]
10084b384:     	cbnz	w8, 0x10084bcac <_js_json_stringify_full+0x1b6c>
10084b388:     	ldr	x8, [x0]
10084b38c:     	cbnz	x8, 0x10084bcd4 <_js_json_stringify_full+0x1b94>
10084b390:     	str	xzr, [x0, #0x18]
10084b394:     	ldp	x22, x19, [sp, #0x48]
10084b398:     	ldrb	w8, [x23, #0x18]
10084b39c:     	cmp	w8, #0x1
10084b3a0:     	b.ne	0x10084bc88 <_js_json_stringify_full+0x1b48>
10084b3a4:     	ldp	x8, x0, [x23]
10084b3a8:     	stp	x22, x19, [x23]
10084b3ac:     	str	xzr, [x23, #0x10]
10084b3b0:     	sub	x8, x8, #0x1
10084b3b4:     	cmn	x8, #0x2
10084b3b8:     	b.hs	0x10084b3c0 <_js_json_stringify_full+0x1280>
10084b3bc:     	bl	0x100b63bc0 <_mi_free>
10084b3c0:     	cbz	w26, 0x10084b3e0 <_js_json_stringify_full+0x12a0>
10084b3c4:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b3c8:     	ldr	w8, [x21]
10084b3cc:     	sub	w8, w8, #0x1
10084b3d0:     	str	w8, [x21]
10084b3d4:     	cmn	x25, #0x1
10084b3d8:     	b.ne	0x10084b59c <_js_json_stringify_full+0x145c>
10084b3dc:     	b	0x10084b5d8 <_js_json_stringify_full+0x1498>
10084b3e0:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b3e4:     	ldr	w8, [x21]
10084b3e8:     	sub	w8, w8, #0x1
10084b3ec:     	str	w8, [x21]
10084b3f0:     	cmn	x25, #0x1
10084b3f4:     	b.ne	0x10084b59c <_js_json_stringify_full+0x145c>
10084b3f8:     	b	0x10084b5d8 <_js_json_stringify_full+0x1498>
10084b3fc:     	cmp	x19, x24
10084b400:     	b.eq	0x10084b40c <_js_json_stringify_full+0x12cc>
10084b404:     	mov.16b	v0, v8
10084b408:     	bl	0x10051182c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
10084b40c:     	cbz	x22, 0x10084b668 <_js_json_stringify_full+0x1528>
10084b410:     	ldp	x1, x2, [sp, #0x18]
10084b414:     	add	x0, sp, #0x48
10084b418:     	mov.16b	v0, v8
10084b41c:     	mov	x3, #0x0                ; =0
10084b420:     	bl	0x100503c1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
10084b424:     	b	0x10084b678 <_js_json_stringify_full+0x1538>
10084b428:     	and	x9, x1, #0x4
10084b42c:     	add	x8, x0, x9
10084b430:     	adrp	x10, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5230>
10084b434:     	ldr	q0, [x10, #0x640]
10084b438:     	adrp	x10, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33a3a>
10084b43c:     	ldr	q2, [x10, #0x540]
10084b440:     	movi.2d	v1, #0000000000000000
10084b444:     	movi.2d	v3, #0x000000000000ff
10084b448:     	mov	w10, #0x4               ; =4
10084b44c:     	dup.2d	v4, x10
10084b450:     	mov	x10, x0
10084b454:     	and	x11, x1, #0x4
10084b458:     	movi.2d	v5, #0000000000000000
10084b45c:     	ldr	s6, [x10], #0x4
10084b460:     	ushll.8h	v6, v6, #0x0
10084b464:     	ushll.4s	v6, v6, #0x0
10084b468:     	ushll2.2d	v7, v6, #0x0
10084b46c:     	and.16b	v7, v7, v3
10084b470:     	ushll.2d	v6, v6, #0x0
10084b474:     	and.16b	v6, v6, v3
10084b478:     	shl.2d	v16, v0, #0x3
10084b47c:     	shl.2d	v17, v2, #0x3
10084b480:     	ushl.2d	v6, v6, v17
10084b484:     	ushl.2d	v7, v7, v16
10084b488:     	orr.16b	v1, v7, v1
10084b48c:     	orr.16b	v5, v6, v5
10084b490:     	add.2d	v0, v0, v4
10084b494:     	add.2d	v2, v2, v4
10084b498:     	subs	x11, x11, #0x4
10084b49c:     	b.ne	0x10084b45c <_js_json_stringify_full+0x131c>
10084b4a0:     	orr.16b	v0, v5, v1
10084b4a4:     	mov	d1, v0[1]
10084b4a8:     	orr.8b	v0, v0, v1
10084b4ac:     	fmov	x10, d0
10084b4b0:     	cmp	x1, x9
10084b4b4:     	b.eq	0x10084b4d8 <_js_json_stringify_full+0x1398>
10084b4b8:     	add	x11, x0, x1
10084b4bc:     	lsl	x9, x9, #3
10084b4c0:     	ldrb	w12, [x8], #0x1
10084b4c4:     	lsl	x12, x12, x9
10084b4c8:     	orr	x10, x12, x10
10084b4cc:     	add	x9, x9, #0x8
10084b4d0:     	cmp	x8, x11
10084b4d4:     	b.ne	0x10084b4c0 <_js_json_stringify_full+0x1380>
10084b4d8:     	orr	x8, x10, x1, lsl #40
10084b4dc:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084b4e0:     	orr	x20, x8, x9
10084b4e4:     	ldr	x22, [sp, #0x48]
10084b4e8:     	ldrb	w8, [x23, #0x18]
10084b4ec:     	cmp	w8, #0x1
10084b4f0:     	b.ne	0x10084bbf8 <_js_json_stringify_full+0x1ab8>
10084b4f4:     	ldp	x9, x8, [x23]
10084b4f8:     	stp	x22, x0, [x23]
10084b4fc:     	str	xzr, [x23, #0x10]
10084b500:     	sub	x9, x9, #0x1
10084b504:     	cmn	x9, #0x2
10084b508:     	b.hs	0x10084b514 <_js_json_stringify_full+0x13d4>
10084b50c:     	mov	x0, x8
10084b510:     	bl	0x100b63bc0 <_mi_free>
10084b514:     	cbz	w26, 0x10084b534 <_js_json_stringify_full+0x13f4>
10084b518:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b51c:     	ldr	w8, [x21]
10084b520:     	sub	w8, w8, #0x1
10084b524:     	str	w8, [x21]
10084b528:     	cmn	x25, #0x1
10084b52c:     	b.ne	0x10084b54c <_js_json_stringify_full+0x140c>
10084b530:     	b	0x10084b5d8 <_js_json_stringify_full+0x1498>
10084b534:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b538:     	ldr	w8, [x21]
10084b53c:     	sub	w8, w8, #0x1
10084b540:     	str	w8, [x21]
10084b544:     	cmn	x25, #0x1
10084b548:     	b.eq	0x10084b5d8 <_js_json_stringify_full+0x1498>
10084b54c:     	ldp	x19, x21, [sp, #0x38]
10084b550:     	cbz	x21, 0x10084b5cc <_js_json_stringify_full+0x148c>
10084b554:     	add	x22, x19, #0x8
10084b558:     	b	0x10084b568 <_js_json_stringify_full+0x1428>
10084b55c:     	add	x22, x22, #0x18
10084b560:     	subs	x21, x21, #0x1
10084b564:     	b.eq	0x10084b5cc <_js_json_stringify_full+0x148c>
10084b568:     	ldur	x8, [x22, #-0x8]
10084b56c:     	cbz	x8, 0x10084b55c <_js_json_stringify_full+0x141c>
10084b570:     	ldr	x0, [x22]
10084b574:     	bl	0x100b63bc0 <_mi_free>
10084b578:     	b	0x10084b55c <_js_json_stringify_full+0x141c>
10084b57c:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b580:     	ldr	w8, [x21]
10084b584:     	sub	w8, w8, #0x1
10084b588:     	str	w8, [x21]
10084b58c:     	add	x0, sp, #0x60
10084b590:     	bl	0x100166d7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
10084b594:     	cmn	x25, #0x1
10084b598:     	b.eq	0x10084b5d8 <_js_json_stringify_full+0x1498>
10084b59c:     	ldp	x19, x21, [sp, #0x38]
10084b5a0:     	cbz	x21, 0x10084b5cc <_js_json_stringify_full+0x148c>
10084b5a4:     	add	x22, x19, #0x8
10084b5a8:     	b	0x10084b5b8 <_js_json_stringify_full+0x1478>
10084b5ac:     	add	x22, x22, #0x18
10084b5b0:     	subs	x21, x21, #0x1
10084b5b4:     	b.eq	0x10084b5cc <_js_json_stringify_full+0x148c>
10084b5b8:     	ldur	x8, [x22, #-0x8]
10084b5bc:     	cbz	x8, 0x10084b5ac <_js_json_stringify_full+0x146c>
10084b5c0:     	ldr	x0, [x22]
10084b5c4:     	bl	0x100b63bc0 <_mi_free>
10084b5c8:     	b	0x10084b5ac <_js_json_stringify_full+0x146c>
10084b5cc:     	cbz	x25, 0x10084b5d8 <_js_json_stringify_full+0x1498>
10084b5d0:     	mov	x0, x19
10084b5d4:     	bl	0x100b63bc0 <_mi_free>
10084b5d8:     	ldr	x8, [sp, #0x10]
10084b5dc:     	cbz	x8, 0x10084b5e8 <_js_json_stringify_full+0x14a8>
10084b5e0:     	ldr	x0, [sp, #0x18]
10084b5e4:     	bl	0x100b63bc0 <_mi_free>
10084b5e8:     	mov	x0, x20
10084b5ec:     	ldp	x29, x30, [sp, #0x110]
10084b5f0:     	ldp	x20, x19, [sp, #0x100]
10084b5f4:     	ldp	x22, x21, [sp, #0xf0]
10084b5f8:     	ldp	x24, x23, [sp, #0xe0]
10084b5fc:     	ldp	x26, x25, [sp, #0xd0]
10084b600:     	ldp	x28, x27, [sp, #0xc0]
10084b604:     	ldp	d9, d8, [sp, #0xb0]
10084b608:     	add	sp, sp, #0x120
10084b60c:     	ret
10084b610:     	str	x22, [sp, #0x8]
10084b614:     	mov	x22, x28
10084b618:     	mov	x28, x0
10084b61c:     	add	x0, x0, #0x8
10084b620:     	bl	0x100b40910 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10084b624:     	mov	x0, x28
10084b628:     	mov	x28, x22
10084b62c:     	ldr	x22, [sp, #0x8]
10084b630:     	b	0x10084ae58 <_js_json_stringify_full+0xd18>
10084b634:     	b.ne	0x10084ab9c <_js_json_stringify_full+0xa5c>
10084b638:     	tbz	x25, #0x3f, 0x10084b690 <_js_json_stringify_full+0x1550>
10084b63c:     	mov	x0, #0x0                ; =0
10084b640:     	mov	x1, x25
10084b644:     	bl	0x100b16f40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084b648:     	bl	0x100b43fbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084b64c:     	add	x8, x0, x23, lsl #3
10084b650:     	ldr	x0, [x8, #0x1e8]
10084b654:     	cbnz	x0, 0x10084aeec <_js_json_stringify_full+0xdac>
10084b658:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084b65c:     	add	x0, x0, #0x138
10084b660:     	bl	0x100b417dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084b664:     	b	0x10084aeec <_js_json_stringify_full+0xdac>
10084b668:     	add	x1, sp, #0x48
10084b66c:     	mov.16b	v0, v8
10084b670:     	mov	w0, #0x0                ; =0
10084b674:     	bl	0x10050c544 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
10084b678:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b67c:     	add	x0, x0, #0xdc0
10084b680:     	ldr	x8, [x0]
10084b684:     	blr	x8
10084b688:     	strb	wzr, [x0]
10084b68c:     	b	0x10084b030 <_js_json_stringify_full+0xef0>
10084b690:     	mov	x0, x25
10084b694:     	mov	w1, #0x1                ; =1
10084b698:     	bl	0x100b63e48 <_mi_malloc_aligned>
10084b69c:     	mov	x26, x0
10084b6a0:     	mov	w0, #0x1                ; =1
10084b6a4:     	cbz	x26, 0x10084b640 <_js_json_stringify_full+0x1500>
10084b6a8:     	mov	x0, x26
10084b6ac:     	mov	x1, x23
10084b6b0:     	mov	x2, x25
10084b6b4:     	bl	0x100b66a6c <_writev+0x100b66a6c>
10084b6b8:     	mov	x22, x25
10084b6bc:     	b	0x10084abc0 <_js_json_stringify_full+0xa80>
10084b6c0:     	cmp	w11, #0x8
10084b6c4:     	b.eq	0x10084b790 <_js_json_stringify_full+0x1650>
10084b6c8:     	cmp	w11, #0x9
10084b6cc:     	b.eq	0x10084b7a0 <_js_json_stringify_full+0x1660>
10084b6d0:     	cmp	w11, #0xa
10084b6d4:     	b.ne	0x10084b71c <_js_json_stringify_full+0x15dc>
10084b6d8:     	mov	w10, #0x6e              ; =110
10084b6dc:     	b	0x10084b7a4 <_js_json_stringify_full+0x1664>
10084b6e0:     	mov	x22, x0
10084b6e4:     	and	x0, x19, #0xffffffffffff
10084b6e8:     	bl	0x10034a600 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084b6ec:     	cbz	x0, 0x10084b7c8 <_js_json_stringify_full+0x1688>
10084b6f0:     	ldr	w20, [x0]
10084b6f4:     	cmp	w20, #0x4
10084b6f8:     	b.hi	0x10084a718 <_js_json_stringify_full+0x5d8>
10084b6fc:     	ldr	w8, [x0, #0x4]
10084b700:     	cmp	w20, w8
10084b704:     	b.hi	0x10084a718 <_js_json_stringify_full+0x5d8>
10084b708:     	b	0x10084b7cc <_js_json_stringify_full+0x168c>
10084b70c:     	cmp	w11, #0x22
10084b710:     	b.eq	0x10084b7a4 <_js_json_stringify_full+0x1664>
10084b714:     	cmp	w11, #0x5c
10084b718:     	b.eq	0x10084b7a4 <_js_json_stringify_full+0x1664>
10084b71c:     	cmp	x12, #0x3
10084b720:     	mov	w11, #0x20              ; =32
10084b724:     	ccmp	w10, w11, #0x8, ls
10084b728:     	b.lt	0x10084a654 <_js_json_stringify_full+0x514>
10084b72c:     	add	x8, sp, #0x80
10084b730:     	strb	w10, [x8, x12]
10084b734:     	add	x12, x12, #0x1
10084b738:     	b	0x10084a344 <_js_json_stringify_full+0x204>
10084b73c:     	mov	x1, x0
10084b740:     	and	x0, x19, #0xffffffffffff
10084b744:     	mov	x22, x1
10084b748:     	bl	0x1004fbb00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
10084b74c:     	cmp	x0, #0x1
10084b750:     	b.ne	0x10084b874 <_js_json_stringify_full+0x1734>
10084b754:     	mov	x20, x1
10084b758:     	b	0x10084b5e8 <_js_json_stringify_full+0x14a8>
10084b75c:     	ldrb	w9, [x8, #0x118]
10084b760:     	cbz	w9, 0x10084b99c <_js_json_stringify_full+0x185c>
10084b764:     	ldr	x9, [x8, #0x110]
10084b768:     	cmp	x9, x1
10084b76c:     	b.ne	0x10084b99c <_js_json_stringify_full+0x185c>
10084b770:     	ldr	x9, [x8, #0xf0]
10084b774:     	cmp	x9, x23
10084b778:     	b.hi	0x10084b99c <_js_json_stringify_full+0x185c>
10084b77c:     	ldr	x9, [x8, #0xf8]
10084b780:     	cmp	x9, x23
10084b784:     	b.ls	0x10084b99c <_js_json_stringify_full+0x185c>
10084b788:     	add	x9, x8, #0xf0
10084b78c:     	b	0x10084bba8 <_js_json_stringify_full+0x1a68>
10084b790:     	mov	w10, #0x62              ; =98
10084b794:     	b	0x10084b7a4 <_js_json_stringify_full+0x1664>
10084b798:     	mov	w10, #0x66              ; =102
10084b79c:     	b	0x10084b7a4 <_js_json_stringify_full+0x1664>
10084b7a0:     	mov	w10, #0x74              ; =116
10084b7a4:     	cmp	x12, #0x2
10084b7a8:     	b.hi	0x10084a654 <_js_json_stringify_full+0x514>
10084b7ac:     	add	x8, sp, #0x80
10084b7b0:     	add	x8, x8, x12
10084b7b4:     	add	x12, x12, #0x2
10084b7b8:     	mov	w11, #0x5c              ; =92
10084b7bc:     	strb	w11, [x8]
10084b7c0:     	strb	w10, [x8, #0x1]
10084b7c4:     	b	0x10084a344 <_js_json_stringify_full+0x204>
10084b7c8:     	mov	x20, #0x0               ; =0
10084b7cc:     	ldr	w8, [x22, #0x4]
10084b7d0:     	lsl	x9, x20, #3
10084b7d4:     	add	x9, x9, #0x18
10084b7d8:     	cmp	x9, x8
10084b7dc:     	b.hi	0x10084a718 <_js_json_stringify_full+0x5d8>
10084b7e0:     	ldr	w8, [x25, #0x4]
10084b7e4:     	mov	w9, #-0x40000000        ; =-1073741824
10084b7e8:     	cmp	w8, w9
10084b7ec:     	csel	w8, w8, wzr, lt
10084b7f0:     	mov	x22, x0
10084b7f4:     	mov	x0, x8
10084b7f8:     	bl	0x1005e86a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084b7fc:     	mov	w9, #0x2                ; =2
10084b800:     	cmp	w1, #0x2
10084b804:     	csel	w10, w1, w9, hi
10084b808:     	tst	w0, #0x1
10084b80c:     	csel	x8, x10, x9, ne
10084b810:     	cmp	x20, x8
10084b814:     	b.hi	0x10084a718 <_js_json_stringify_full+0x5d8>
10084b818:     	cbz	x20, 0x10084bbd8 <_js_json_stringify_full+0x1a98>
10084b81c:     	mov	x0, x22
10084b820:     	mov	x1, x20
10084b824:     	bl	0x1004f2a80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084b828:     	tbz	w0, #0x0, 0x10084a718 <_js_json_stringify_full+0x5d8>
10084b82c:     	cmp	x20, #0x1
10084b830:     	b.eq	0x10084bc74 <_js_json_stringify_full+0x1b34>
10084b834:     	cmp	x20, #0x2
10084b838:     	b.ne	0x10084bd30 <_js_json_stringify_full+0x1bf0>
10084b83c:     	mov	x22, #0x0               ; =0
10084b840:     	add	x25, x25, #0x10
10084b844:     	mov	w8, #0x1                ; =1
10084b848:     	mov	x26, x8
10084b84c:     	ldr	x1, [x25, x22, lsl #3]
10084b850:     	add	x0, sp, #0x80
10084b854:     	bl	0x1004f2ad4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
10084b858:     	ldr	w8, [sp, #0x80]
10084b85c:     	cmn	w8, #0x1
10084b860:     	b.ne	0x10084bd18 <_js_json_stringify_full+0x1bd8>
10084b864:     	mov	w8, #0x0                ; =0
10084b868:     	mov	w22, #0x1               ; =1
10084b86c:     	tbnz	w26, #0x0, 0x10084b848 <_js_json_stringify_full+0x1708>
10084b870:     	b	0x10084bd30 <_js_json_stringify_full+0x1bf0>
10084b874:     	and	x0, x19, #0xffffffffffff
10084b878:     	bl	0x10034a600 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084b87c:     	cbz	x0, 0x10084b908 <_js_json_stringify_full+0x17c8>
10084b880:     	ldr	w20, [x0]
10084b884:     	cbz	w20, 0x10084b908 <_js_json_stringify_full+0x17c8>
10084b888:     	cmp	w20, #0x8
10084b88c:     	b.hi	0x10084a6e4 <_js_json_stringify_full+0x5a4>
10084b890:     	ldr	w8, [x0, #0x4]
10084b894:     	cmp	w20, w8
10084b898:     	b.hi	0x10084a6e4 <_js_json_stringify_full+0x5a4>
10084b89c:     	ldr	w8, [x22, #0x4]
10084b8a0:     	lsl	x9, x20, #3
10084b8a4:     	add	x9, x9, #0x18
10084b8a8:     	cmp	x9, x8
10084b8ac:     	b.hi	0x10084a6e4 <_js_json_stringify_full+0x5a4>
10084b8b0:     	ldr	w8, [x25, #0x4]
10084b8b4:     	mov	w9, #-0x40000000        ; =-1073741824
10084b8b8:     	cmp	w8, w9
10084b8bc:     	csel	w8, w8, wzr, lt
10084b8c0:     	mov	x22, x0
10084b8c4:     	mov	x0, x8
10084b8c8:     	bl	0x1005e86a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084b8cc:     	mov	w9, #0x2                ; =2
10084b8d0:     	cmp	w1, #0x2
10084b8d4:     	csel	w10, w1, w9, hi
10084b8d8:     	tst	w0, #0x1
10084b8dc:     	csel	w8, w10, w9, ne
10084b8e0:     	cmp	w20, w8
10084b8e4:     	b.hi	0x10084a6e4 <_js_json_stringify_full+0x5a4>
10084b8e8:     	mov	x0, x22
10084b8ec:     	mov	x1, x20
10084b8f0:     	bl	0x1004f2a80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084b8f4:     	cbz	w0, 0x10084a6e4 <_js_json_stringify_full+0x5a4>
10084b8f8:     	and	x0, x19, #0xffffffffffff
10084b8fc:     	mov	x1, x20
10084b900:     	bl	0x1004fac40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
10084b904:     	b	0x10084b910 <_js_json_stringify_full+0x17d0>
10084b908:     	and	x0, x19, #0xffffffffffff
10084b90c:     	bl	0x1004fb9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
10084b910:     	mov	x20, x1
10084b914:     	tbz	w0, #0x0, 0x10084a6e4 <_js_json_stringify_full+0x5a4>
10084b918:     	b	0x10084b5e8 <_js_json_stringify_full+0x14a8>
10084b91c:     	add	x9, x8, #0x60
10084b920:     	b	0x10084bba8 <_js_json_stringify_full+0x1a68>
10084b924:     	bl	0x100b43fbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084b928:     	lsr	x1, x23, #20
10084b92c:     	ldr	x8, [x0, #0x10]
10084b930:     	ldrb	w9, [x8]
10084b934:     	cmp	w9, #0x2
10084b938:     	b.eq	0x10084acc8 <_js_json_stringify_full+0xb88>
10084b93c:     	ldr	x9, [x8, #0x8]
10084b940:     	ldr	x10, [x8, #0x28]
10084b944:     	sub	x9, x1, x9
10084b948:     	cmp	x9, x10
10084b94c:     	b.hs	0x10084b990 <_js_json_stringify_full+0x1850>
10084b950:     	ldr	x10, [x8, #0x20]
10084b954:     	mov	w11, #0x28              ; =40
10084b958:     	madd	x9, x9, x11, x10
10084b95c:     	ldr	x10, [x9]
10084b960:     	ldr	x11, [x8, #0x10]
10084b964:     	cmp	x10, x11
10084b968:     	b.ne	0x10084b99c <_js_json_stringify_full+0x185c>
10084b96c:     	ldp	x10, x11, [x9, #0x8]
10084b970:     	cmp	x10, x23
10084b974:     	ccmp	x11, x23, #0x0, ls
10084b978:     	b.ls	0x10084b99c <_js_json_stringify_full+0x185c>
10084b97c:     	ldr	x10, [x8, #0x30]
10084b980:     	add	x10, x10, #0x1
10084b984:     	str	x10, [x8, #0x30]
10084b988:     	add	x8, x9, #0x21
10084b98c:     	b	0x10084bbb8 <_js_json_stringify_full+0x1a78>
10084b990:     	ldr	x9, [x8, #0x58]
10084b994:     	add	x9, x9, #0x1
10084b998:     	str	x9, [x8, #0x58]
10084b99c:     	ldr	x9, [x8, #0x38]
10084b9a0:     	add	x9, x9, #0x1
10084b9a4:     	str	x9, [x8, #0x38]
10084b9a8:     	mov	x0, x23
10084b9ac:     	bl	0x100521308 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
10084b9b0:     	and	w8, w0, #0xff
10084b9b4:     	cbz	w8, 0x10084b9d4 <_js_json_stringify_full+0x1894>
10084b9b8:     	ldurb	w8, [x23, #-0x8]
10084b9bc:     	ldurb	w9, [x23, #-0x7]
10084b9c0:     	mov	w10, #0x82              ; =130
10084b9c4:     	and	w9, w9, w10
10084b9c8:     	cmp	w9, #0x2
10084b9cc:     	ccmp	w8, #0x1, #0x0, eq
10084b9d0:     	b.eq	0x10084ba68 <_js_json_stringify_full+0x1928>
10084b9d4:     	mov	x0, x23
10084b9d8:     	bl	0x10057d980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084b9dc:     	mov	x24, x0
10084b9e0:     	cbz	x0, 0x10084ba0c <_js_json_stringify_full+0x18cc>
10084b9e4:     	ldrb	w8, [x24]
10084b9e8:     	cmp	w8, #0x1
10084b9ec:     	b.ne	0x10084ba2c <_js_json_stringify_full+0x18ec>
10084b9f0:     	ldrsb	w8, [x24, #0x1]
10084b9f4:     	tbnz	w8, #0x1f, 0x10084ba90 <_js_json_stringify_full+0x1950>
10084b9f8:     	mov	x0, x24
10084b9fc:     	ldp	w9, w8, [x23]
10084ba00:     	cmp	w9, w8
10084ba04:     	b.hi	0x10084bb14 <_js_json_stringify_full+0x19d4>
10084ba08:     	b	0x10084bb2c <_js_json_stringify_full+0x19ec>
10084ba0c:     	mov	x0, x23
10084ba10:     	bl	0x10058c1b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10084ba14:     	tbnz	w0, #0x0, 0x10084ba24 <_js_json_stringify_full+0x18e4>
10084ba18:     	mov	x0, x23
10084ba1c:     	bl	0x1002a6908 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
10084ba20:     	tbz	w0, #0x0, 0x10084ad68 <_js_json_stringify_full+0xc28>
10084ba24:     	mov	x0, #0x0                ; =0
10084ba28:     	b	0x10084bb04 <_js_json_stringify_full+0x19c4>
10084ba2c:     	mov	x0, x24
10084ba30:     	cmp	w8, #0x1
10084ba34:     	b.eq	0x10084bb04 <_js_json_stringify_full+0x19c4>
10084ba38:     	cmp	w8, #0x9
10084ba3c:     	b.ne	0x10084ad68 <_js_json_stringify_full+0xc28>
10084ba40:     	ldr	w8, [x23, #0x4]
10084ba44:     	mov	w9, #0x5841             ; =22593
10084ba48:     	movk	w9, #0x4c5a, lsl #16
10084ba4c:     	cmp	w8, w9
10084ba50:     	b.ne	0x10084ad68 <_js_json_stringify_full+0xc28>
10084ba54:     	mov	x0, x23
10084ba58:     	bl	0x100378910 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
10084ba5c:     	mov	x23, x0
10084ba60:     	cbnz	x0, 0x10084bb54 <_js_json_stringify_full+0x1a14>
10084ba64:     	b	0x10084ad68 <_js_json_stringify_full+0xc28>
10084ba68:     	ldr	w8, [x23]
10084ba6c:     	mov	w9, #0xe100             ; =57600
10084ba70:     	movk	w9, #0x5f5, lsl #16
10084ba74:     	orr	w9, w9, #0x1
10084ba78:     	cmp	w8, w9
10084ba7c:     	b.hs	0x10084b9d4 <_js_json_stringify_full+0x1894>
10084ba80:     	ldr	w9, [x23, #0x4]
10084ba84:     	cmp	w8, w9
10084ba88:     	b.ls	0x10084bb54 <_js_json_stringify_full+0x1a14>
10084ba8c:     	b	0x10084b9d4 <_js_json_stringify_full+0x1894>
10084ba90:     	ldr	x23, [x24, #0x8]
10084ba94:     	mov	x0, x23
10084ba98:     	bl	0x10057d980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084ba9c:     	cbz	x0, 0x10084ad68 <_js_json_stringify_full+0xc28>
10084baa0:     	ldrb	w8, [x0]
10084baa4:     	cmp	w8, #0x1
10084baa8:     	b.ne	0x10084ad68 <_js_json_stringify_full+0xc28>
10084baac:     	ldrsb	w8, [x0, #0x1]
10084bab0:     	tbz	w8, #0x1f, 0x10084b9fc <_js_json_stringify_full+0x18bc>
10084bab4:     	mov	w26, #0x1               ; =1
10084bab8:     	ldr	x23, [x0, #0x8]
10084babc:     	mov	x0, x23
10084bac0:     	bl	0x10057d980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084bac4:     	cbz	x0, 0x10084ad68 <_js_json_stringify_full+0xc28>
10084bac8:     	ldrb	w8, [x0]
10084bacc:     	cmp	w8, #0x1
10084bad0:     	b.ne	0x10084ad68 <_js_json_stringify_full+0xc28>
10084bad4:     	cmp	w26, #0x3f
10084bad8:     	b.hi	0x10084ad68 <_js_json_stringify_full+0xc28>
10084badc:     	add	w26, w26, #0x1
10084bae0:     	ldrsb	w8, [x0, #0x1]
10084bae4:     	tbnz	w8, #0x1f, 0x10084bab8 <_js_json_stringify_full+0x1978>
10084bae8:     	str	x23, [x24, #0x8]
10084baec:     	ldrb	w8, [x24, #0x1]
10084baf0:     	orr	w8, w8, #0x80
10084baf4:     	strb	w8, [x24, #0x1]
10084baf8:     	ldrb	w8, [x0]
10084bafc:     	cmp	w8, #0x1
10084bb00:     	b.ne	0x10084ba38 <_js_json_stringify_full+0x18f8>
10084bb04:     	ldp	w9, w8, [x23]
10084bb08:     	cmp	w9, w8
10084bb0c:     	b.ls	0x10084bb2c <_js_json_stringify_full+0x19ec>
10084bb10:     	cbz	x24, 0x10084bb3c <_js_json_stringify_full+0x19fc>
10084bb14:     	ldr	w9, [x0, #0x4]
10084bb18:     	ubfiz	x8, x8, #3, #32
10084bb1c:     	add	x8, x8, #0x10
10084bb20:     	cmp	x8, x9
10084bb24:     	b.eq	0x10084bb54 <_js_json_stringify_full+0x1a14>
10084bb28:     	b	0x10084bb3c <_js_json_stringify_full+0x19fc>
10084bb2c:     	mov	w8, #0xe100             ; =57600
10084bb30:     	movk	w8, #0x5f5, lsl #16
10084bb34:     	cmp	w9, w8
10084bb38:     	b.ls	0x10084bb54 <_js_json_stringify_full+0x1a14>
10084bb3c:     	mov	x0, x23
10084bb40:     	bl	0x10058c1b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10084bb44:     	tbnz	w0, #0x0, 0x10084bb54 <_js_json_stringify_full+0x1a14>
10084bb48:     	mov	x0, x23
10084bb4c:     	bl	0x1002a6908 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
10084bb50:     	tbz	w0, #0x0, 0x10084ad68 <_js_json_stringify_full+0xc28>
10084bb54:     	ldp	w8, w9, [x23]
10084bb58:     	sub	w10, w9, #0x1
10084bb5c:     	mov	w11, #0x270f            ; =9999
10084bb60:     	cmp	w10, w11
10084bb64:     	ccmp	w8, w9, #0x2, lo
10084bb68:     	b.hi	0x10084ad68 <_js_json_stringify_full+0xc28>
10084bb6c:     	and	x8, x21, #0xffffffffffff
10084bb70:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084bb74:     	cmp	x25, x9
10084bb78:     	csel	x1, x8, x21, eq
10084bb7c:     	add	x0, sp, #0x30
10084bb80:     	bl	0x1005029ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
10084bb84:     	ldr	x25, [sp, #0x30]
10084bb88:     	cmn	x25, #0x1
10084bb8c:     	cset	w24, eq
10084bb90:     	cmp	x27, #0x1
10084bb94:     	cset	w8, hi
10084bb98:     	tst	w8, w24
10084bb9c:     	b.ne	0x10084ad84 <_js_json_stringify_full+0xc44>
10084bba0:     	b	0x10084adf4 <_js_json_stringify_full+0xcb4>
10084bba4:     	add	x9, x8, #0x90
10084bba8:     	ldr	x10, [x8, #0x30]
10084bbac:     	add	x10, x10, #0x1
10084bbb0:     	str	x10, [x8, #0x30]
10084bbb4:     	add	x8, x9, #0x19
10084bbb8:     	ldrb	w8, [x8]
10084bbbc:     	cmp	w8, #0xff
10084bbc0:     	b.ne	0x10084b9b4 <_js_json_stringify_full+0x1874>
10084bbc4:     	b	0x10084b9a8 <_js_json_stringify_full+0x1868>
10084bbc8:     	mov	x0, x23
10084bbcc:     	bl	0x100b23144 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084bbd0:     	cbnz	x0, 0x10084af10 <_js_json_stringify_full+0xdd0>
10084bbd4:     	b	0x10084bd50 <_js_json_stringify_full+0x1c10>
10084bbd8:     	and	x0, x19, #0xffffffffffff
10084bbdc:     	bl	0x1004faa70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
10084bbe0:     	mov	w0, w0
10084bbe4:     	mov	x20, #0x7d7b            ; =32123
10084bbe8:     	movk	x20, #0x200, lsl #32
10084bbec:     	movk	x20, #0x7ff9, lsl #48
10084bbf0:     	tbz	w0, #0x0, 0x10084a718 <_js_json_stringify_full+0x5d8>
10084bbf4:     	b	0x10084b5e8 <_js_json_stringify_full+0x14a8>
10084bbf8:     	mov	x19, x0
10084bbfc:     	mov	x0, x23
10084bc00:     	bl	0x100b23144 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084bc04:     	mov	x23, x0
10084bc08:     	mov	x0, x19
10084bc0c:     	cbnz	x23, 0x10084b4f4 <_js_json_stringify_full+0x13b4>
10084bc10:     	b	0x10084bcf0 <_js_json_stringify_full+0x1bb0>
10084bc14:     	bl	0x100b232a4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084bc18:     	cbnz	x0, 0x10084ae38 <_js_json_stringify_full+0xcf8>
10084bc1c:     	b	0x10084bd50 <_js_json_stringify_full+0x1c10>
10084bc20:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10084bc24:     	add	x0, x0, #0x440
10084bc28:     	bl	0x100b172ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084bc2c:     	cmp	w8, #0x1
10084bc30:     	b.ne	0x10084bd50 <_js_json_stringify_full+0x1c10>
10084bc34:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084bc38:     	add	x1, x1, #0x898
10084bc3c:     	mov	x19, x0
10084bc40:     	bl	0x100a2501c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084bc44:     	mov	x0, x19
10084bc48:     	strb	wzr, [x19, #0x20]
10084bc4c:     	ldr	x8, [x19]
10084bc50:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10084bc54:     	cmp	x8, x9
10084bc58:     	b.lo	0x10084b058 <_js_json_stringify_full+0xf18>
10084bc5c:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084bc60:     	add	x0, x0, #0xea8
10084bc64:     	bl	0x100b1731c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084bc68:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084bc6c:     	add	x0, x0, #0xec0
10084bc70:     	bl	0x100b172ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084bc74:     	and	x0, x19, #0xffffffffffff
10084bc78:     	bl	0x1004f2680 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
10084bc7c:     	mov	x20, x1
10084bc80:     	tbz	w0, #0x0, 0x10084a718 <_js_json_stringify_full+0x5d8>
10084bc84:     	b	0x10084b5e8 <_js_json_stringify_full+0x14a8>
10084bc88:     	mov	x0, x23
10084bc8c:     	bl	0x100b23144 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084bc90:     	mov	x23, x0
10084bc94:     	cbnz	x0, 0x10084b3a4 <_js_json_stringify_full+0x1264>
10084bc98:     	b	0x10084bcf0 <_js_json_stringify_full+0x1bb0>
10084bc9c:     	adrp	x0, 0x100efb000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
10084bca0:     	add	x0, x0, #0xd70
10084bca4:     	bl	0x100b1731c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084bca8:     	bl	0x100b50554 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
10084bcac:     	cmp	w8, #0x2
10084bcb0:     	b.eq	0x10084bd50 <_js_json_stringify_full+0x1c10>
10084bcb4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084bcb8:     	add	x1, x1, #0x898
10084bcbc:     	mov	x19, x0
10084bcc0:     	bl	0x100a2501c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084bcc4:     	mov	x0, x19
10084bcc8:     	strb	wzr, [x19, #0x20]
10084bccc:     	ldr	x8, [x19]
10084bcd0:     	cbz	x8, 0x10084b390 <_js_json_stringify_full+0x1250>
10084bcd4:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084bcd8:     	add	x0, x0, #0xe90
10084bcdc:     	bl	0x100b172ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084bce0:     	mov	x0, x23
10084bce4:     	bl	0x100b23144 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084bce8:     	mov	x23, x0
10084bcec:     	cbnz	x0, 0x10084b2c0 <_js_json_stringify_full+0x1180>
10084bcf0:     	cbz	x22, 0x10084bd50 <_js_json_stringify_full+0x1c10>
10084bcf4:     	mov	x0, x19
10084bcf8:     	bl	0x100b63bc0 <_mi_free>
10084bcfc:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084bd00:     	add	x0, x0, #0xc18
10084bd04:     	bl	0x100b5d21c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084bd08:     	adrp	x0, 0x100c47000 <_PERRY_EMPTY_STRING+0xe74>
10084bd0c:     	add	x0, x0, #0xf8
10084bd10:     	mov	w1, #0xf                ; =15
10084bd14:     	bl	0x100b5051c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084bd18:     	and	x0, x19, #0xffffffffffff
10084bd1c:     	add	x2, sp, #0x80
10084bd20:     	mov	x1, x22
10084bd24:     	bl	0x1004f2e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
10084bd28:     	tbnz	w0, #0x0, 0x10084b754 <_js_json_stringify_full+0x1614>
10084bd2c:     	mov	w20, #0x2               ; =2
10084bd30:     	and	x0, x19, #0xffffffffffff
10084bd34:     	mov	x1, x20
10084bd38:     	bl	0x1004f1500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
10084bd3c:     	mov	x20, x1
10084bd40:     	tbz	w0, #0x0, 0x10084a718 <_js_json_stringify_full+0x5d8>
10084bd44:     	b	0x10084b5e8 <_js_json_stringify_full+0x14a8>
10084bd48:     	cmp	w8, #0x2
10084bd4c:     	b.ne	0x10084bd78 <_js_json_stringify_full+0x1c38>
10084bd50:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084bd54:     	add	x0, x0, #0xc18
10084bd58:     	bl	0x100b5d21c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084bd5c:     	adrp	x0, 0x100f33000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x148>
10084bd60:     	add	x0, x0, #0x890
10084bd64:     	bl	0x100b173b0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
10084bd68:     	adrp	x0, 0x100c46000 <_anon.3a0f55142d697dd4d6c50f8035b0d3d6.3+0x5340>
10084bd6c:     	add	x0, x0, #0xde7
10084bd70:     	mov	w1, #0xb                ; =11
10084bd74:     	bl	0x100b5051c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084bd78:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084bd7c:     	add	x1, x1, #0x898
10084bd80:     	mov	x19, x0
10084bd84:     	bl	0x100a2501c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084bd88:     	mov	x0, x19
10084bd8c:     	strb	wzr, [x19, #0x20]
10084bd90:     	ldr	x8, [x19]
10084bd94:     	cbz	x8, 0x10084b2ac <_js_json_stringify_full+0x116c>
10084bd98:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084bd9c:     	add	x0, x0, #0xe78
10084bda0:     	bl	0x100b172ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084bda4:     	mov	w0, #0x1                ; =1
10084bda8:     	mov	x1, x24
10084bdac:     	bl	0x100b16f40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084bdb0:     	mov	w0, #0x1                ; =1
10084bdb4:     	mov	x1, x22
10084bdb8:     	bl	0x100b16f40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084bdbc:     	adrp	x2, 0x100efc000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
10084bdc0:     	add	x2, x2, #0x3c8
10084bdc4:     	mov	w0, #0x5                ; =5
10084bdc8:     	mov	w1, #0x5                ; =5
10084bdcc:     	bl	0x100b1744c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
