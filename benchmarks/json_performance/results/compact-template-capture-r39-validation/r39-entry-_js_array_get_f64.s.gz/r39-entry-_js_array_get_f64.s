
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/compact-template-capture-r39/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007c2550 <_js_array_get_f64>:
1007c2550:     	sub	sp, sp, #0x70
1007c2554:     	stp	x26, x25, [sp, #0x20]
1007c2558:     	stp	x24, x23, [sp, #0x30]
1007c255c:     	stp	x22, x21, [sp, #0x40]
1007c2560:     	stp	x20, x19, [sp, #0x50]
1007c2564:     	stp	x29, x30, [sp, #0x60]
1007c2568:     	add	x29, sp, #0x60
1007c256c:     	mov	x19, x1
1007c2570:     	mov	x22, x0
1007c2574:     	lsr	x25, x0, #51
1007c2578:     	mov	x20, x0
1007c257c:     	cmp	x25, #0xfff
1007c2580:     	b.lo	0x1007c259c <_js_array_get_f64+0x4c>
1007c2584:     	mov	w8, #0x7ffc             ; =32764
1007c2588:     	cmp	x8, x22, lsr #48
1007c258c:     	b.ne	0x1007c2598 <_js_array_get_f64+0x48>
1007c2590:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007c2594:     	b	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2598:     	and	x20, x22, #0xffffffffffff
1007c259c:     	lsr	x8, x20, #3
1007c25a0:     	cmp	x8, #0x200
1007c25a4:     	b.ls	0x1007c25dc <_js_array_get_f64+0x8c>
1007c25a8:     	ldurb	w8, [x20, #-0x8]
1007c25ac:     	cmp	w8, #0x9
1007c25b0:     	b.ne	0x1007c25dc <_js_array_get_f64+0x8c>
1007c25b4:     	ldr	w8, [x20, #0x4]
1007c25b8:     	mov	w9, #0x5841             ; =22593
1007c25bc:     	movk	w9, #0x4c5a, lsl #16
1007c25c0:     	cmp	w8, w9
1007c25c4:     	b.ne	0x1007c25dc <_js_array_get_f64+0x8c>
1007c25c8:     	mov	x0, x20
1007c25cc:     	mov	x1, x19
1007c25d0:     	bl	0x10068b904 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007c25d4:     	fmov	d0, x0
1007c25d8:     	b	0x1007c2c4c <_js_array_get_f64+0x6fc>
1007c25dc:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c25e0:     	b.lo	0x1007c2690 <_js_array_get_f64+0x140>
1007c25e4:     	tst	x20, #0xffff800000000000
1007c25e8:     	mov	w8, #0x1000             ; =4096
1007c25ec:     	ccmp	x20, x8, #0x0, eq
1007c25f0:     	b.lo	0x1007c2690 <_js_array_get_f64+0x140>
1007c25f4:     	ldurb	w24, [x20, #-0x8]
1007c25f8:     	ldurh	w23, [x20, #-0x6]
1007c25fc:     	cmp	w24, #0xa
1007c2600:     	b.gt	0x1007c27a8 <_js_array_get_f64+0x258>
1007c2604:     	cmp	w24, #0x2
1007c2608:     	b.eq	0x1007c2830 <_js_array_get_f64+0x2e0>
1007c260c:     	cmp	w24, #0x8
1007c2610:     	b.ne	0x1007c2698 <_js_array_get_f64+0x148>
1007c2614:     	mov	x0, x20
1007c2618:     	bl	0x100307b68 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007c261c:     	cbz	w0, 0x1007c28c0 <_js_array_get_f64+0x370>
1007c2620:     	mov	x22, #0x1               ; =1
1007c2624:     	movk	x22, #0x7ffc, lsl #48
1007c2628:     	lsr	x8, x20, #51
1007c262c:     	cmp	x8, #0xfff
1007c2630:     	b.lo	0x1007c2644 <_js_array_get_f64+0xf4>
1007c2634:     	mov	w8, #0x7ffc             ; =32764
1007c2638:     	cmp	x8, x20, lsr #48
1007c263c:     	b.eq	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2640:     	and	x20, x20, #0xffffffffffff
1007c2644:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c2648:     	b.lo	0x1007c2668 <_js_array_get_f64+0x118>
1007c264c:     	tst	x20, #0xffff800000000000
1007c2650:     	mov	w8, #0x1000             ; =4096
1007c2654:     	ccmp	x20, x8, #0x0, eq
1007c2658:     	b.lo	0x1007c2668 <_js_array_get_f64+0x118>
1007c265c:     	ldurb	w8, [x20, #-0x8]
1007c2660:     	cmp	w8, #0x2
1007c2664:     	b.eq	0x1007c2f34 <_js_array_get_f64+0x9e4>
1007c2668:     	cbz	x20, 0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c266c:     	mov	x0, x20
1007c2670:     	mov	x1, x19
1007c2674:     	bl	0x100307d18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007c2678:     	cmp	w0, #0x1
1007c267c:     	b.ne	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2680:     	ldr	x8, [x20, #0x8]
1007c2684:     	ubfiz	x9, x1, #4, #32
1007c2688:     	ldr	x22, [x8, x9]
1007c268c:     	b	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2690:     	mov	w23, #0x0               ; =0
1007c2694:     	mov	w24, #0x0               ; =0
1007c2698:     	mov	x21, x22
1007c269c:     	cmp	x25, #0xfff
1007c26a0:     	b.lo	0x1007c26b8 <_js_array_get_f64+0x168>
1007c26a4:     	mov	w8, #0x7ffc             ; =32764
1007c26a8:     	cmp	x8, x22, lsr #48
1007c26ac:     	b.eq	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c26b0:     	ands	x21, x22, #0xffffffffffff
1007c26b4:     	b.eq	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c26b8:     	and	x8, x21, #0xfffffffffff00000
1007c26bc:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007c26c0:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007c26c4:     	cmp	x9, x10
1007c26c8:     	ccmp	x8, #0x0, #0x4, lo
1007c26cc:     	b.eq	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c26d0:     	tst	x21, #0x3
1007c26d4:     	ccmp	x21, #0x7, #0x0, eq
1007c26d8:     	b.ls	0x1007c2988 <_js_array_get_f64+0x438>
1007c26dc:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c26e0:     	ldr	x8, [x8, #0x48]
1007c26e4:     	cmn	x8, #0x1
1007c26e8:     	b.eq	0x1007c28d8 <_js_array_get_f64+0x388>
1007c26ec:     	mrs	x9, TPIDRRO_EL0
1007c26f0:     	and	x9, x9, #0xfffffffffffffff8
1007c26f4:     	ldr	x0, [x9, x8, lsl #3]
1007c26f8:     	cbz	x0, 0x1007c28d8 <_js_array_get_f64+0x388>
1007c26fc:     	lsr	x1, x21, #20
1007c2700:     	ldr	x8, [x0, #0x10]
1007c2704:     	ldrb	w9, [x8]
1007c2708:     	cmp	w9, #0x2
1007c270c:     	b.ne	0x1007c28f0 <_js_array_get_f64+0x3a0>
1007c2710:     	ldrb	w9, [x8, #0x88]
1007c2714:     	tbz	w9, #0x0, 0x1007c2734 <_js_array_get_f64+0x1e4>
1007c2718:     	ldr	x9, [x8, #0x80]
1007c271c:     	cmp	x9, x1
1007c2720:     	b.ne	0x1007c2734 <_js_array_get_f64+0x1e4>
1007c2724:     	ldp	x9, x10, [x8, #0x60]
1007c2728:     	cmp	x9, x21
1007c272c:     	ccmp	x10, x21, #0x0, ls
1007c2730:     	b.hi	0x1007c28d0 <_js_array_get_f64+0x380>
1007c2734:     	ldrb	w9, [x8, #0xb8]
1007c2738:     	cbz	w9, 0x1007c2758 <_js_array_get_f64+0x208>
1007c273c:     	ldr	x9, [x8, #0xb0]
1007c2740:     	cmp	x9, x1
1007c2744:     	b.ne	0x1007c2758 <_js_array_get_f64+0x208>
1007c2748:     	ldp	x9, x10, [x8, #0x90]
1007c274c:     	cmp	x9, x21
1007c2750:     	ccmp	x10, x21, #0x0, ls
1007c2754:     	b.hi	0x1007c2d98 <_js_array_get_f64+0x848>
1007c2758:     	ldrb	w9, [x8, #0xe8]
1007c275c:     	cbz	w9, 0x1007c277c <_js_array_get_f64+0x22c>
1007c2760:     	ldr	x9, [x8, #0xe0]
1007c2764:     	cmp	x9, x1
1007c2768:     	b.ne	0x1007c277c <_js_array_get_f64+0x22c>
1007c276c:     	ldp	x9, x10, [x8, #0xc0]
1007c2770:     	cmp	x9, x21
1007c2774:     	ccmp	x10, x21, #0x0, ls
1007c2778:     	b.hi	0x1007c2e80 <_js_array_get_f64+0x930>
1007c277c:     	ldrb	w9, [x8, #0x118]
1007c2780:     	cbz	w9, 0x1007c2950 <_js_array_get_f64+0x400>
1007c2784:     	ldr	x9, [x8, #0x110]
1007c2788:     	cmp	x9, x1
1007c278c:     	b.ne	0x1007c2950 <_js_array_get_f64+0x400>
1007c2790:     	ldp	x9, x10, [x8, #0xf0]
1007c2794:     	cmp	x9, x21
1007c2798:     	ccmp	x10, x21, #0x0, ls
1007c279c:     	b.ls	0x1007c2950 <_js_array_get_f64+0x400>
1007c27a0:     	add	x9, x8, #0xf0
1007c27a4:     	b	0x1007c2e84 <_js_array_get_f64+0x934>
1007c27a8:     	cmp	w24, #0xb
1007c27ac:     	b.eq	0x1007c2848 <_js_array_get_f64+0x2f8>
1007c27b0:     	cmp	w24, #0xc
1007c27b4:     	b.ne	0x1007c2698 <_js_array_get_f64+0x148>
1007c27b8:     	mov	x0, x20
1007c27bc:     	bl	0x10030d8f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007c27c0:     	cbz	w0, 0x1007c28c8 <_js_array_get_f64+0x378>
1007c27c4:     	mov	x22, #0x1               ; =1
1007c27c8:     	movk	x22, #0x7ffc, lsl #48
1007c27cc:     	lsr	x8, x20, #51
1007c27d0:     	cmp	x8, #0xfff
1007c27d4:     	b.lo	0x1007c27e8 <_js_array_get_f64+0x298>
1007c27d8:     	mov	w8, #0x7ffc             ; =32764
1007c27dc:     	cmp	x8, x20, lsr #48
1007c27e0:     	b.eq	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c27e4:     	and	x20, x20, #0xffffffffffff
1007c27e8:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c27ec:     	b.lo	0x1007c280c <_js_array_get_f64+0x2bc>
1007c27f0:     	tst	x20, #0xffff800000000000
1007c27f4:     	mov	w8, #0x1000             ; =4096
1007c27f8:     	ccmp	x20, x8, #0x0, eq
1007c27fc:     	b.lo	0x1007c280c <_js_array_get_f64+0x2bc>
1007c2800:     	ldurb	w8, [x20, #-0x8]
1007c2804:     	cmp	w8, #0x2
1007c2808:     	b.eq	0x1007c2f4c <_js_array_get_f64+0x9fc>
1007c280c:     	cbz	x20, 0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2810:     	mov	x0, x20
1007c2814:     	mov	x1, x19
1007c2818:     	bl	0x10030f570 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007c281c:     	cmp	w0, #0x1
1007c2820:     	b.ne	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2824:     	ldr	x8, [x20, #0x8]
1007c2828:     	ldr	x22, [x8, w1, uxtw #3]
1007c282c:     	b	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2830:     	mov	x0, x22
1007c2834:     	mov	x1, x19
1007c2838:     	bl	0x10054b5cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007c283c:     	tbnz	w0, #0x0, 0x1007c2c44 <_js_array_get_f64+0x6f4>
1007c2840:     	mov	w24, #0x2               ; =2
1007c2844:     	b	0x1007c2698 <_js_array_get_f64+0x148>
1007c2848:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c284c:     	add	x8, x8, #0xec0
1007c2850:     	ldaprb	w8, [x8]
1007c2854:     	cbz	w8, 0x1007c28b8 <_js_array_get_f64+0x368>
1007c2858:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c285c:     	add	x8, x8, #0x58
1007c2860:     	ldapr	x8, [x8]
1007c2864:     	cmp	x20, x8
1007c2868:     	b.lo	0x1007c28b8 <_js_array_get_f64+0x368>
1007c286c:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2870:     	add	x8, x8, #0x60
1007c2874:     	ldapr	x8, [x8]
1007c2878:     	cmp	x20, x8
1007c287c:     	b.hi	0x1007c28b8 <_js_array_get_f64+0x368>
1007c2880:     	mov	x0, x20
1007c2884:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2888:     	tbz	w0, #0x0, 0x1007c28b8 <_js_array_get_f64+0x368>
1007c288c:     	add	x0, sp, #0x8
1007c2890:     	mov	x1, x20
1007c2894:     	bl	0x1002a746c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007c2898:     	ldr	x8, [sp, #0x8]
1007c289c:     	cbz	x8, 0x1007c2ec4 <_js_array_get_f64+0x974>
1007c28a0:     	cmp	x8, #0x1
1007c28a4:     	b.ne	0x1007c2f08 <_js_array_get_f64+0x9b8>
1007c28a8:     	ldr	d0, [sp, #0x10]
1007c28ac:     	scvtf	d1, w19
1007c28b0:     	bl	0x100820af4 <_js_dyn_index_get>
1007c28b4:     	b	0x1007c2c44 <_js_array_get_f64+0x6f4>
1007c28b8:     	mov	w24, #0xb               ; =11
1007c28bc:     	b	0x1007c2698 <_js_array_get_f64+0x148>
1007c28c0:     	mov	w24, #0x8               ; =8
1007c28c4:     	b	0x1007c2698 <_js_array_get_f64+0x148>
1007c28c8:     	mov	w24, #0xc               ; =12
1007c28cc:     	b	0x1007c2698 <_js_array_get_f64+0x148>
1007c28d0:     	add	x9, x8, #0x60
1007c28d4:     	b	0x1007c2e84 <_js_array_get_f64+0x934>
1007c28d8:     	bl	0x100b43fbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007c28dc:     	lsr	x1, x21, #20
1007c28e0:     	ldr	x8, [x0, #0x10]
1007c28e4:     	ldrb	w9, [x8]
1007c28e8:     	cmp	w9, #0x2
1007c28ec:     	b.eq	0x1007c2710 <_js_array_get_f64+0x1c0>
1007c28f0:     	ldr	x9, [x8, #0x8]
1007c28f4:     	ldr	x10, [x8, #0x28]
1007c28f8:     	sub	x9, x1, x9
1007c28fc:     	cmp	x9, x10
1007c2900:     	b.hs	0x1007c2944 <_js_array_get_f64+0x3f4>
1007c2904:     	ldr	x10, [x8, #0x20]
1007c2908:     	mov	w11, #0x28              ; =40
1007c290c:     	madd	x9, x9, x11, x10
1007c2910:     	ldr	x10, [x9]
1007c2914:     	ldr	x11, [x8, #0x10]
1007c2918:     	cmp	x10, x11
1007c291c:     	b.ne	0x1007c2950 <_js_array_get_f64+0x400>
1007c2920:     	ldp	x10, x11, [x9, #0x8]
1007c2924:     	cmp	x10, x21
1007c2928:     	ccmp	x11, x21, #0x0, ls
1007c292c:     	b.ls	0x1007c2950 <_js_array_get_f64+0x400>
1007c2930:     	ldr	x10, [x8, #0x30]
1007c2934:     	add	x10, x10, #0x1
1007c2938:     	str	x10, [x8, #0x30]
1007c293c:     	add	x8, x9, #0x21
1007c2940:     	b	0x1007c2e94 <_js_array_get_f64+0x944>
1007c2944:     	ldr	x9, [x8, #0x58]
1007c2948:     	add	x9, x9, #0x1
1007c294c:     	str	x9, [x8, #0x58]
1007c2950:     	ldr	x9, [x8, #0x38]
1007c2954:     	add	x9, x9, #0x1
1007c2958:     	str	x9, [x8, #0x38]
1007c295c:     	mov	x0, x21
1007c2960:     	bl	0x100521308 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007c2964:     	and	w8, w0, #0xff
1007c2968:     	cbz	w8, 0x1007c2988 <_js_array_get_f64+0x438>
1007c296c:     	ldurb	w8, [x21, #-0x8]
1007c2970:     	ldurb	w9, [x21, #-0x7]
1007c2974:     	mov	w10, #0x82              ; =130
1007c2978:     	and	w9, w9, w10
1007c297c:     	cmp	w9, #0x2
1007c2980:     	ccmp	w8, #0x1, #0x0, eq
1007c2984:     	b.eq	0x1007c2a58 <_js_array_get_f64+0x508>
1007c2988:     	mov	x0, x21
1007c298c:     	bl	0x10057d980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2990:     	cbz	x0, 0x1007c29b8 <_js_array_get_f64+0x468>
1007c2994:     	ldrb	w9, [x0]
1007c2998:     	cmp	w9, #0x1
1007c299c:     	b.ne	0x1007c29d4 <_js_array_get_f64+0x484>
1007c29a0:     	ldrsb	w8, [x0, #0x1]
1007c29a4:     	tbnz	w8, #0x1f, 0x1007c2a80 <_js_array_get_f64+0x530>
1007c29a8:     	ldp	w10, w9, [x21]
1007c29ac:     	cmp	w10, w9
1007c29b0:     	b.hi	0x1007c2b0c <_js_array_get_f64+0x5bc>
1007c29b4:     	b	0x1007c2b24 <_js_array_get_f64+0x5d4>
1007c29b8:     	mov	x25, x0
1007c29bc:     	mov	x0, x21
1007c29c0:     	bl	0x10058c1b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c29c4:     	tbz	w0, #0x0, 0x1007c2a10 <_js_array_get_f64+0x4c0>
1007c29c8:     	mov	x0, #0x0                ; =0
1007c29cc:     	mov	x8, x25
1007c29d0:     	b	0x1007c2afc <_js_array_get_f64+0x5ac>
1007c29d4:     	mov	x8, x0
1007c29d8:     	cmp	w9, #0x1
1007c29dc:     	b.eq	0x1007c2afc <_js_array_get_f64+0x5ac>
1007c29e0:     	cmp	w9, #0x9
1007c29e4:     	b.ne	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c29e8:     	ldr	w8, [x21, #0x4]
1007c29ec:     	mov	w9, #0x5841             ; =22593
1007c29f0:     	movk	w9, #0x4c5a, lsl #16
1007c29f4:     	cmp	w8, w9
1007c29f8:     	b.ne	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c29fc:     	mov	x0, x21
1007c2a00:     	bl	0x100378910 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007c2a04:     	cbz	x0, 0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2a08:     	mov	x21, x0
1007c2a0c:     	b	0x1007c2b40 <_js_array_get_f64+0x5f0>
1007c2a10:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2a14:     	add	x8, x8, #0xec0
1007c2a18:     	ldaprb	w8, [x8]
1007c2a1c:     	cbz	w8, 0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2a20:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2a24:     	add	x8, x8, #0x58
1007c2a28:     	ldapr	x8, [x8]
1007c2a2c:     	cmp	x8, x21
1007c2a30:     	b.hi	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2a34:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2a38:     	add	x8, x8, #0x60
1007c2a3c:     	ldapr	x8, [x8]
1007c2a40:     	cmp	x8, x21
1007c2a44:     	b.lo	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2a48:     	mov	x0, x21
1007c2a4c:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2a50:     	tbnz	w0, #0x0, 0x1007c29c8 <_js_array_get_f64+0x478>
1007c2a54:     	b	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2a58:     	ldr	w8, [x21]
1007c2a5c:     	mov	w9, #0xe100             ; =57600
1007c2a60:     	movk	w9, #0x5f5, lsl #16
1007c2a64:     	orr	w9, w9, #0x1
1007c2a68:     	cmp	w8, w9
1007c2a6c:     	b.hs	0x1007c2988 <_js_array_get_f64+0x438>
1007c2a70:     	ldr	w9, [x21, #0x4]
1007c2a74:     	cmp	w8, w9
1007c2a78:     	b.ls	0x1007c2b40 <_js_array_get_f64+0x5f0>
1007c2a7c:     	b	0x1007c2988 <_js_array_get_f64+0x438>
1007c2a80:     	mov	x25, x0
1007c2a84:     	ldr	x21, [x0, #0x8]
1007c2a88:     	mov	x0, x21
1007c2a8c:     	bl	0x10057d980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2a90:     	cbz	x0, 0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2a94:     	ldrb	w8, [x0]
1007c2a98:     	cmp	w8, #0x1
1007c2a9c:     	b.ne	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2aa0:     	ldrsb	w8, [x0, #0x1]
1007c2aa4:     	tbz	w8, #0x1f, 0x1007c29a8 <_js_array_get_f64+0x458>
1007c2aa8:     	mov	w26, #0x1               ; =1
1007c2aac:     	ldr	x21, [x0, #0x8]
1007c2ab0:     	mov	x0, x21
1007c2ab4:     	bl	0x10057d980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2ab8:     	cbz	x0, 0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2abc:     	ldrb	w8, [x0]
1007c2ac0:     	cmp	w8, #0x1
1007c2ac4:     	b.ne	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2ac8:     	cmp	w26, #0x3f
1007c2acc:     	b.hi	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2ad0:     	add	w26, w26, #0x1
1007c2ad4:     	ldrsb	w8, [x0, #0x1]
1007c2ad8:     	tbnz	w8, #0x1f, 0x1007c2aac <_js_array_get_f64+0x55c>
1007c2adc:     	str	x21, [x25, #0x8]
1007c2ae0:     	ldrb	w8, [x25, #0x1]
1007c2ae4:     	orr	w9, w8, #0x80
1007c2ae8:     	mov	x8, x25
1007c2aec:     	strb	w9, [x25, #0x1]
1007c2af0:     	ldrb	w9, [x0]
1007c2af4:     	cmp	w9, #0x1
1007c2af8:     	b.ne	0x1007c29e0 <_js_array_get_f64+0x490>
1007c2afc:     	ldp	w10, w9, [x21]
1007c2b00:     	cmp	w10, w9
1007c2b04:     	b.ls	0x1007c2b24 <_js_array_get_f64+0x5d4>
1007c2b08:     	cbz	x8, 0x1007c2b34 <_js_array_get_f64+0x5e4>
1007c2b0c:     	ldr	w8, [x0, #0x4]
1007c2b10:     	ubfiz	x9, x9, #3, #32
1007c2b14:     	add	x9, x9, #0x10
1007c2b18:     	cmp	x9, x8
1007c2b1c:     	b.eq	0x1007c2b40 <_js_array_get_f64+0x5f0>
1007c2b20:     	b	0x1007c2b34 <_js_array_get_f64+0x5e4>
1007c2b24:     	mov	w8, #0xe100             ; =57600
1007c2b28:     	movk	w8, #0x5f5, lsl #16
1007c2b2c:     	cmp	w10, w8
1007c2b30:     	b.ls	0x1007c2b40 <_js_array_get_f64+0x5f0>
1007c2b34:     	mov	x0, x21
1007c2b38:     	bl	0x10058c1b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2b3c:     	tbz	w0, #0x0, 0x1007c2bf0 <_js_array_get_f64+0x6a0>
1007c2b40:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2b44:     	add	x8, x8, #0xec0
1007c2b48:     	ldaprb	w8, [x8]
1007c2b4c:     	cbz	w8, 0x1007c2b94 <_js_array_get_f64+0x644>
1007c2b50:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2b54:     	add	x8, x8, #0x58
1007c2b58:     	ldapr	x8, [x8]
1007c2b5c:     	cmp	x21, x8
1007c2b60:     	b.lo	0x1007c2b94 <_js_array_get_f64+0x644>
1007c2b64:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2b68:     	add	x8, x8, #0x60
1007c2b6c:     	ldapr	x8, [x8]
1007c2b70:     	cmp	x21, x8
1007c2b74:     	b.hi	0x1007c2b94 <_js_array_get_f64+0x644>
1007c2b78:     	mov	x0, x21
1007c2b7c:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2b80:     	tbz	w0, #0x0, 0x1007c2b94 <_js_array_get_f64+0x644>
1007c2b84:     	mov	x0, x21
1007c2b88:     	mov	x1, x19
1007c2b8c:     	bl	0x100900808 <_js_typed_array_get>
1007c2b90:     	b	0x1007c2c44 <_js_array_get_f64+0x6f4>
1007c2b94:     	mov	x0, x21
1007c2b98:     	bl	0x10058c1b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2b9c:     	tbz	w0, #0x0, 0x1007c2bc4 <_js_array_get_f64+0x674>
1007c2ba0:     	mov	x0, x21
1007c2ba4:     	mov	x1, x19
1007c2ba8:     	bl	0x1005894dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007c2bac:     	and	w8, w1, #0xff
1007c2bb0:     	ucvtf	d0, w8
1007c2bb4:     	fmov	x8, d0
1007c2bb8:     	tst	w0, #0x1
1007c2bbc:     	csel	x22, x8, xzr, ne
1007c2bc0:     	b	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2bc4:     	cmp	x21, x20
1007c2bc8:     	b.eq	0x1007c2c70 <_js_array_get_f64+0x720>
1007c2bcc:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007c2bd0:     	b.lo	0x1007c2c68 <_js_array_get_f64+0x718>
1007c2bd4:     	tst	x21, #0xffff800000000000
1007c2bd8:     	mov	w8, #0x1000             ; =4096
1007c2bdc:     	ccmp	x21, x8, #0x0, eq
1007c2be0:     	b.lo	0x1007c2c68 <_js_array_get_f64+0x718>
1007c2be4:     	ldurb	w24, [x21, #-0x8]
1007c2be8:     	ldurh	w23, [x21, #-0x6]
1007c2bec:     	b	0x1007c2c70 <_js_array_get_f64+0x720>
1007c2bf0:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2bf4:     	add	x8, x8, #0xec0
1007c2bf8:     	ldaprb	w8, [x8]
1007c2bfc:     	cbz	w8, 0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2c00:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2c04:     	add	x8, x8, #0x58
1007c2c08:     	ldapr	x8, [x8]
1007c2c0c:     	cmp	x21, x8
1007c2c10:     	b.lo	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2c14:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2c18:     	add	x8, x8, #0x60
1007c2c1c:     	ldapr	x8, [x8]
1007c2c20:     	cmp	x21, x8
1007c2c24:     	b.hi	0x1007c2c34 <_js_array_get_f64+0x6e4>
1007c2c28:     	mov	x0, x21
1007c2c2c:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2c30:     	tbnz	w0, #0x0, 0x1007c2b40 <_js_array_get_f64+0x5f0>
1007c2c34:     	mov	x0, x22
1007c2c38:     	mov	x1, x19
1007c2c3c:     	bl	0x10054b5cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007c2c40:     	tbz	w0, #0x0, 0x1007c2f18 <_js_array_get_f64+0x9c8>
1007c2c44:     	fmov	x22, d0
1007c2c48:     	fmov	d0, x22
1007c2c4c:     	ldp	x29, x30, [sp, #0x60]
1007c2c50:     	ldp	x20, x19, [sp, #0x50]
1007c2c54:     	ldp	x22, x21, [sp, #0x40]
1007c2c58:     	ldp	x24, x23, [sp, #0x30]
1007c2c5c:     	ldp	x26, x25, [sp, #0x20]
1007c2c60:     	add	sp, sp, #0x70
1007c2c64:     	ret
1007c2c68:     	mov	w23, #0x0               ; =0
1007c2c6c:     	mov	w24, #0x0               ; =0
1007c2c70:     	cmp	w24, #0x1
1007c2c74:     	b.ne	0x1007c2e28 <_js_array_get_f64+0x8d8>
1007c2c78:     	tbz	w23, #0xa, 0x1007c2e28 <_js_array_get_f64+0x8d8>
1007c2c7c:     	adrp	x8, 0x100b69000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data15grapheme_extend7OFFSETS+0x2a5>
1007c2c80:     	add	x8, x8, #0xa0c
1007c2c84:     	cmp	w19, #0x3e8
1007c2c88:     	b.lo	0x1007c2d00 <_js_array_get_f64+0x7b0>
1007c2c8c:     	mov	x9, #0x0                ; =0
1007c2c90:     	mov	w11, #0x1759            ; =5977
1007c2c94:     	movk	w11, #0xd1b7, lsl #16
1007c2c98:     	mov	w12, #0x2710            ; =10000
1007c2c9c:     	mov	w13, #0x147b            ; =5243
1007c2ca0:     	mov	w14, #0x64              ; =100
1007c2ca4:     	add	x15, sp, #0x8
1007c2ca8:     	mov	w16, #0x967f            ; =38527
1007c2cac:     	movk	w16, #0x98, lsl #16
1007c2cb0:     	mov	x10, x19
1007c2cb4:     	mov	x17, x10
1007c2cb8:     	umull	x10, w10, w11
1007c2cbc:     	lsr	x10, x10, #45
1007c2cc0:     	msub	w0, w10, w12, w17
1007c2cc4:     	ubfx	w1, w0, #2, #14
1007c2cc8:     	mul	w1, w1, w13
1007c2ccc:     	lsr	w1, w1, #17
1007c2cd0:     	msub	w0, w1, w14, w0
1007c2cd4:     	add	x2, x15, x9
1007c2cd8:     	ldrh	w1, [x8, w1, uxtw #1]
1007c2cdc:     	strh	w1, [x2, #0x6]
1007c2ce0:     	and	x0, x0, #0xffff
1007c2ce4:     	ldrh	w0, [x8, x0, lsl #1]
1007c2ce8:     	strh	w0, [x2, #0x8]
1007c2cec:     	sub	x9, x9, #0x4
1007c2cf0:     	cmp	w17, w16
1007c2cf4:     	b.hi	0x1007c2cb4 <_js_array_get_f64+0x764>
1007c2cf8:     	add	x9, x9, #0xa
1007c2cfc:     	b	0x1007c2d08 <_js_array_get_f64+0x7b8>
1007c2d00:     	mov	w9, #0xa                ; =10
1007c2d04:     	mov	x10, x19
1007c2d08:     	cmp	w10, #0x9
1007c2d0c:     	b.ls	0x1007c2d40 <_js_array_get_f64+0x7f0>
1007c2d10:     	sub	x9, x9, #0x2
1007c2d14:     	ubfx	w11, w10, #2, #14
1007c2d18:     	mov	w12, #0x147b            ; =5243
1007c2d1c:     	mul	w11, w11, w12
1007c2d20:     	lsr	w11, w11, #17
1007c2d24:     	mov	w12, #0x64              ; =100
1007c2d28:     	msub	w10, w11, w12, w10
1007c2d2c:     	and	x10, x10, #0xffff
1007c2d30:     	ldrh	w10, [x8, x10, lsl #1]
1007c2d34:     	add	x12, sp, #0x8
1007c2d38:     	strh	w10, [x12, x9]
1007c2d3c:     	mov	x10, x11
1007c2d40:     	cbz	w19, 0x1007c2d78 <_js_array_get_f64+0x828>
1007c2d44:     	cbnz	w10, 0x1007c2d78 <_js_array_get_f64+0x828>
1007c2d48:     	cmp	x9, #0xa
1007c2d4c:     	b.ne	0x1007c2da0 <_js_array_get_f64+0x850>
1007c2d50:     	mov	w23, #0x1               ; =1
1007c2d54:     	add	x0, sp, #0x8
1007c2d58:     	mov	x1, x21
1007c2d5c:     	mov	w2, #0x1                ; =1
1007c2d60:     	mov	x3, #0x0                ; =0
1007c2d64:     	bl	0x1005b58bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007c2d68:     	ldr	x8, [sp, #0x8]
1007c2d6c:     	mov	w20, #0x1               ; =1
1007c2d70:     	cbnz	x8, 0x1007c2df0 <_js_array_get_f64+0x8a0>
1007c2d74:     	b	0x1007c2e28 <_js_array_get_f64+0x8d8>
1007c2d78:     	sub	x23, x9, #0x1
1007c2d7c:     	ubfiz	w10, w10, #1, #4
1007c2d80:     	add	x8, x8, x10
1007c2d84:     	ldrb	w8, [x8, #0x1]
1007c2d88:     	add	x10, sp, #0x8
1007c2d8c:     	strb	w8, [x10, x23]
1007c2d90:     	mov	w8, #0xb                ; =11
1007c2d94:     	b	0x1007c2da8 <_js_array_get_f64+0x858>
1007c2d98:     	add	x9, x8, #0x90
1007c2d9c:     	b	0x1007c2e84 <_js_array_get_f64+0x934>
1007c2da0:     	mov	w8, #0xa                ; =10
1007c2da4:     	mov	x23, x9
1007c2da8:     	sub	x22, x8, x9
1007c2dac:     	mov	x0, x22
1007c2db0:     	mov	w1, #0x1                ; =1
1007c2db4:     	bl	0x100b63e48 <_mi_malloc_aligned>
1007c2db8:     	cbz	x0, 0x1007c2f64 <_js_array_get_f64+0xa14>
1007c2dbc:     	mov	x20, x0
1007c2dc0:     	add	x8, sp, #0x8
1007c2dc4:     	add	x1, x8, x23
1007c2dc8:     	mov	x2, x22
1007c2dcc:     	bl	0x100b66a6c <_writev+0x100b66a6c>
1007c2dd0:     	add	x0, sp, #0x8
1007c2dd4:     	mov	x1, x21
1007c2dd8:     	mov	x2, x20
1007c2ddc:     	mov	x3, x22
1007c2de0:     	bl	0x1005b58bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007c2de4:     	ldr	w8, [sp, #0x8]
1007c2de8:     	tbz	w8, #0x0, 0x1007c2e20 <_js_array_get_f64+0x8d0>
1007c2dec:     	mov	w23, #0x0               ; =0
1007c2df0:     	mov	x22, #0x1               ; =1
1007c2df4:     	movk	x22, #0x7ffc, lsl #48
1007c2df8:     	ldr	x0, [sp, #0x10]
1007c2dfc:     	cbz	x0, 0x1007c2eb4 <_js_array_get_f64+0x964>
1007c2e00:     	cbz	x21, 0x1007c2ea4 <_js_array_get_f64+0x954>
1007c2e04:     	lsr	x8, x21, #52
1007c2e08:     	cmp	x8, #0x7fe
1007c2e0c:     	b.hi	0x1007c2ea8 <_js_array_get_f64+0x958>
1007c2e10:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007c2e14:     	bfxil	x8, x21, #0, #48
1007c2e18:     	mov	x21, x8
1007c2e1c:     	b	0x1007c2ea8 <_js_array_get_f64+0x958>
1007c2e20:     	mov	x0, x20
1007c2e24:     	bl	0x100b63bc0 <_mi_free>
1007c2e28:     	ldr	w8, [x21]
1007c2e2c:     	cmp	w19, w8
1007c2e30:     	b.hs	0x1007c2e70 <_js_array_get_f64+0x920>
1007c2e34:     	ldr	w8, [x21, #0x4]
1007c2e38:     	cmp	w19, w8
1007c2e3c:     	b.hs	0x1007c2e60 <_js_array_get_f64+0x910>
1007c2e40:     	add	x8, x21, w19, uxtw #3
1007c2e44:     	ldr	x22, [x8, #0x8]
1007c2e48:     	mov	x8, #0x1                ; =1
1007c2e4c:     	movk	x8, #0x7ffc, lsl #48
1007c2e50:     	add	x8, x8, #0xf
1007c2e54:     	cmp	x22, x8
1007c2e58:     	b.ne	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2e5c:     	b	0x1007c2e70 <_js_array_get_f64+0x920>
1007c2e60:     	mov	x0, x21
1007c2e64:     	mov	x1, x19
1007c2e68:     	bl	0x10052d9c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007c2e6c:     	tbnz	w0, #0x0, 0x1007c2c44 <_js_array_get_f64+0x6f4>
1007c2e70:     	mov	x0, x21
1007c2e74:     	mov	x1, x19
1007c2e78:     	bl	0x1006cb864 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007c2e7c:     	b	0x1007c2c44 <_js_array_get_f64+0x6f4>
1007c2e80:     	add	x9, x8, #0xc0
1007c2e84:     	ldr	x10, [x8, #0x30]
1007c2e88:     	add	x10, x10, #0x1
1007c2e8c:     	str	x10, [x8, #0x30]
1007c2e90:     	add	x8, x9, #0x19
1007c2e94:     	ldrb	w8, [x8]
1007c2e98:     	cmp	w8, #0xff
1007c2e9c:     	b.ne	0x1007c2968 <_js_array_get_f64+0x418>
1007c2ea0:     	b	0x1007c295c <_js_array_get_f64+0x40c>
1007c2ea4:     	add	x21, x22, #0x1
1007c2ea8:     	fmov	d0, x21
1007c2eac:     	bl	0x10070167c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007c2eb0:     	mov	x22, x0
1007c2eb4:     	tbnz	w23, #0x0, 0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2eb8:     	mov	x0, x20
1007c2ebc:     	bl	0x100b63bc0 <_mi_free>
1007c2ec0:     	b	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2ec4:     	ldr	x20, [sp, #0x10]
1007c2ec8:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2ecc:     	ldr	x8, [x8, #0xed8]
1007c2ed0:     	cbz	x8, 0x1007c2ee8 <_js_array_get_f64+0x998>
1007c2ed4:     	mov	x0, x20
1007c2ed8:     	bl	0x10013cc40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007c2edc:     	tbz	w0, #0x0, 0x1007c2ee8 <_js_array_get_f64+0x998>
1007c2ee0:     	mov	x0, x20
1007c2ee4:     	bl	0x1002c1840 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007c2ee8:     	tbnz	w19, #0x1f, 0x1007c2f08 <_js_array_get_f64+0x9b8>
1007c2eec:     	ldr	w8, [x20]
1007c2ef0:     	cmp	w19, w8
1007c2ef4:     	b.hs	0x1007c2f08 <_js_array_get_f64+0x9b8>
1007c2ef8:     	mov	w1, w19
1007c2efc:     	mov	x0, x20
1007c2f00:     	bl	0x1002a7acc <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007c2f04:     	b	0x1007c2c44 <_js_array_get_f64+0x6f4>
1007c2f08:     	mov	x8, #0x1                ; =1
1007c2f0c:     	movk	x8, #0x7ffc, lsl #48
1007c2f10:     	mov	x22, x8
1007c2f14:     	b	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2f18:     	mov	x0, x22
1007c2f1c:     	bl	0x100b4c530 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007c2f20:     	cmp	x0, #0x1
1007c2f24:     	b.ne	0x1007c2590 <_js_array_get_f64+0x40>
1007c2f28:     	mov	x0, x19
1007c2f2c:     	bl	0x100b4c550 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007c2f30:     	b	0x1007c2c44 <_js_array_get_f64+0x6f4>
1007c2f34:     	mov	x0, x20
1007c2f38:     	mov	w1, #0x0                ; =0
1007c2f3c:     	bl	0x100b4eac0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007c2f40:     	mov	x20, x0
1007c2f44:     	cbnz	x0, 0x1007c266c <_js_array_get_f64+0x11c>
1007c2f48:     	b	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2f4c:     	mov	x0, x20
1007c2f50:     	mov	w1, #0x1                ; =1
1007c2f54:     	bl	0x100b4eac0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007c2f58:     	mov	x20, x0
1007c2f5c:     	cbnz	x0, 0x1007c2810 <_js_array_get_f64+0x2c0>
1007c2f60:     	b	0x1007c2c48 <_js_array_get_f64+0x6f8>
1007c2f64:     	mov	w0, #0x1                ; =1
1007c2f68:     	mov	x1, x22
1007c2f6c:     	bl	0x100b16f40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
