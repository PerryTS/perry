
benchmarks/json_performance/.work/compact-template-capture-r39/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004ed840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template>:
1004ed840:     	stp	x28, x27, [sp, #-0x60]!
1004ed844:     	stp	x26, x25, [sp, #0x10]
1004ed848:     	stp	x24, x23, [sp, #0x20]
1004ed84c:     	stp	x22, x21, [sp, #0x30]
1004ed850:     	stp	x20, x19, [sp, #0x40]
1004ed854:     	stp	x29, x30, [sp, #0x50]
1004ed858:     	add	x29, sp, #0x50
1004ed85c:     	sub	sp, sp, #0x4e0
1004ed860:     	ldr	xzr, [sp]
1004ed864:     	sub	x8, x1, #0x41
1004ed868:     	lsr	x9, x2, #48
1004ed86c:     	mov	w10, #0x7ffd            ; =32765
1004ed870:     	cmp	x9, x10
1004ed874:     	mov	w9, #0x7bf              ; =1983
1004ed878:     	ccmp	x8, x9, #0x2, eq
1004ed87c:     	ccmp	x0, #0x0, #0x4, ls
1004ed880:     	b.eq	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004ed884:     	and	x24, x2, #0xffffffffffff
1004ed888:     	ldurb	w8, [x24, #-0x8]
1004ed88c:     	cmp	w8, #0x2
1004ed890:     	b.ne	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004ed894:     	mov	x19, x1
1004ed898:     	mov	x20, x0
1004ed89c:     	ldr	w8, [x24, #0x4]
1004ed8a0:     	mov	w9, #-0x40000000        ; =-1073741824
1004ed8a4:     	cmp	w8, w9
1004ed8a8:     	csel	w0, w8, wzr, lt
1004ed8ac:     	bl	0x1005e6224 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
1004ed8b0:     	tst	w0, #0x1
1004ed8b4:     	csel	w9, w1, wzr, ne
1004ed8b8:     	cmp	w9, #0x8
1004ed8bc:     	b.hi	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004ed8c0:     	add	w8, w9, w9, lsl #3
1004ed8c4:     	lsl	w8, w8, #3
1004ed8c8:     	str	x8, [sp, #0x8]
1004ed8cc:     	str	w9, [sp, #0x4]
1004ed8d0:     	cbz	w9, 0x1004edac0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x280>
1004ed8d4:     	add	x26, x24, #0x10
1004ed8d8:     	add	x8, sp, #0x10
1004ed8dc:     	ldr	x9, [sp, #0x8]
1004ed8e0:     	add	x27, x8, x9
1004ed8e4:     	add	x28, sp, #0x290
1004ed8e8:     	add	x21, sp, #0x10
1004ed8ec:     	mov	w22, #0x7ffd            ; =32765
1004ed8f0:     	b	0x1004ed934 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0xf4>
1004ed8f4:     	mov	w10, #0x0               ; =0
1004ed8f8:     	ldp	q0, q1, [sp, #0x250]
1004ed8fc:     	stp	q0, q1, [sp, #0x290]
1004ed900:     	ldr	q2, [sp, #0x270]
1004ed904:     	str	q2, [sp, #0x2b0]
1004ed908:     	ldr	x11, [sp, #0x280]
1004ed90c:     	strb	w10, [x21]
1004ed910:     	strb	w8, [x21, #0x1]
1004ed914:     	str	x9, [x21, #0x8]
1004ed918:     	stp	q0, q1, [x21, #0x10]
1004ed91c:     	str	q2, [x21, #0x30]
1004ed920:     	str	x11, [x21, #0x40]
1004ed924:     	add	x21, x21, #0x48
1004ed928:     	str	x11, [sp, #0x2c0]
1004ed92c:     	cmp	x21, x27
1004ed930:     	b.eq	0x1004edac0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x280>
1004ed934:     	ldr	x9, [x26], #0x8
1004ed938:     	cmp	x22, x9, lsr #48
1004ed93c:     	b.ne	0x1004ed8f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0xb4>
1004ed940:     	and	x23, x9, #0xffffffffffff
1004ed944:     	ldurb	w8, [x23, #-0x8]
1004ed948:     	cmp	w8, #0x1
1004ed94c:     	b.ne	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004ed950:     	ldr	w25, [x23]
1004ed954:     	cmp	w25, #0x8
1004ed958:     	b.hi	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004ed95c:     	add	x0, sp, #0x290
1004ed960:     	adrp	x1, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x73f0>
1004ed964:     	add	x1, x1, #0x6f0
1004ed968:     	mov	w2, #0x40               ; =64
1004ed96c:     	bl	0x100b648d0 <_writev+0x100b648d0>
1004ed970:     	cbz	w25, 0x1004eda94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x254>
1004ed974:     	mov	x0, x23
1004ed978:     	mov	w1, #0x0                ; =0
1004ed97c:     	bl	0x1007c00d0 <_js_array_get_f64>
1004ed980:     	fmov	x8, d0
1004ed984:     	cmp	x22, x8, lsr #48
1004ed988:     	b.eq	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004ed98c:     	str	d0, [sp, #0x290]
1004ed990:     	cmp	w25, #0x1
1004ed994:     	b.eq	0x1004eda8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x24c>
1004ed998:     	mov	x0, x23
1004ed99c:     	mov	w1, #0x1                ; =1
1004ed9a0:     	bl	0x1007c00d0 <_js_array_get_f64>
1004ed9a4:     	fmov	x8, d0
1004ed9a8:     	cmp	x22, x8, lsr #48
1004ed9ac:     	b.eq	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004ed9b0:     	str	d0, [sp, #0x298]
1004ed9b4:     	cmp	w25, #0x2
1004ed9b8:     	b.eq	0x1004eda8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x24c>
1004ed9bc:     	mov	x0, x23
1004ed9c0:     	mov	w1, #0x2                ; =2
1004ed9c4:     	bl	0x1007c00d0 <_js_array_get_f64>
1004ed9c8:     	fmov	x8, d0
1004ed9cc:     	cmp	x22, x8, lsr #48
1004ed9d0:     	b.eq	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004ed9d4:     	str	d0, [sp, #0x2a0]
1004ed9d8:     	cmp	w25, #0x3
1004ed9dc:     	b.eq	0x1004eda8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x24c>
1004ed9e0:     	mov	x0, x23
1004ed9e4:     	mov	w1, #0x3                ; =3
1004ed9e8:     	bl	0x1007c00d0 <_js_array_get_f64>
1004ed9ec:     	fmov	x8, d0
1004ed9f0:     	cmp	x22, x8, lsr #48
1004ed9f4:     	b.eq	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004ed9f8:     	str	d0, [sp, #0x2a8]
1004ed9fc:     	cmp	w25, #0x4
1004eda00:     	b.eq	0x1004eda8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x24c>
1004eda04:     	mov	x0, x23
1004eda08:     	mov	w1, #0x4                ; =4
1004eda0c:     	bl	0x1007c00d0 <_js_array_get_f64>
1004eda10:     	fmov	x8, d0
1004eda14:     	cmp	x22, x8, lsr #48
1004eda18:     	b.eq	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004eda1c:     	str	d0, [sp, #0x2b0]
1004eda20:     	cmp	w25, #0x5
1004eda24:     	b.eq	0x1004eda8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x24c>
1004eda28:     	mov	x0, x23
1004eda2c:     	mov	w1, #0x5                ; =5
1004eda30:     	bl	0x1007c00d0 <_js_array_get_f64>
1004eda34:     	fmov	x8, d0
1004eda38:     	cmp	x22, x8, lsr #48
1004eda3c:     	b.eq	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004eda40:     	str	d0, [sp, #0x2b8]
1004eda44:     	cmp	w25, #0x6
1004eda48:     	b.eq	0x1004eda8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x24c>
1004eda4c:     	mov	x0, x23
1004eda50:     	mov	w1, #0x6                ; =6
1004eda54:     	bl	0x1007c00d0 <_js_array_get_f64>
1004eda58:     	fmov	x8, d0
1004eda5c:     	cmp	x22, x8, lsr #48
1004eda60:     	b.eq	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004eda64:     	str	d0, [sp, #0x2c0]
1004eda68:     	cmp	w25, #0x7
1004eda6c:     	b.eq	0x1004eda8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x24c>
1004eda70:     	mov	x0, x23
1004eda74:     	mov	w1, #0x7                ; =7
1004eda78:     	bl	0x1007c00d0 <_js_array_get_f64>
1004eda7c:     	fmov	x8, d0
1004eda80:     	cmp	x22, x8, lsr #48
1004eda84:     	b.eq	0x1004ede1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5dc>
1004eda88:     	str	d0, [sp, #0x2c8]
1004eda8c:     	ldr	w8, [x23]
1004eda90:     	b	0x1004eda98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x258>
1004eda94:     	mov	w8, #0x0                ; =0
1004eda98:     	ldr	x9, [sp, #0x290]
1004eda9c:     	ldur	q0, [x28, #0x8]
1004edaa0:     	ldur	q1, [x28, #0x18]
1004edaa4:     	stp	q0, q1, [sp, #0x250]
1004edaa8:     	ldur	q0, [x28, #0x28]
1004edaac:     	str	q0, [sp, #0x270]
1004edab0:     	ldur	x10, [x28, #0x38]
1004edab4:     	str	x10, [sp, #0x280]
1004edab8:     	mov	w10, #0x1               ; =1
1004edabc:     	b	0x1004ed8f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0xb8>
1004edac0:     	ldr	w22, [x24, #0x4]
1004edac4:     	mov	w8, #-0x40000000        ; =-1073741824
1004edac8:     	cmp	w22, w8
1004edacc:     	csel	w21, w22, w8, lt
1004edad0:     	adrp	x8, 0x100f80000 <_perry_global_rotating_worker_ts__1>
1004edad4:     	ldr	w23, [x8, #0x800]
1004edad8:     	adrp	x27, 0x100f80000 <_perry_global_rotating_worker_ts__1>
1004edadc:     	cmp	w23, #0x300
1004edae0:     	b.hs	0x1004edb74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x334>
1004edae4:     	ldr	x8, [x27, #0x48]
1004edae8:     	cmn	x8, #0x1
1004edaec:     	b.eq	0x1004edb64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x324>
1004edaf0:     	mrs	x9, TPIDRRO_EL0
1004edaf4:     	and	x9, x9, #0xfffffffffffffff8
1004edaf8:     	ldr	x0, [x9, x8, lsl #3]
1004edafc:     	cbz	x0, 0x1004edb64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x324>
1004edb00:     	add	x8, x0, x23, lsl #3
1004edb04:     	ldr	x0, [x8, #0x1e8]
1004edb08:     	cbz	x0, 0x1004edb74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x334>
1004edb0c:     	ldr	x0, [x0]
1004edb10:     	cbz	x0, 0x1004edb88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x348>
1004edb14:     	mov	w8, #-0x40000001        ; =-1073741825
1004edb18:     	cmp	w22, w8
1004edb1c:     	b.gt	0x1004edb98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x358>
1004edb20:     	ldr	x10, [x0, #0x51d0]
1004edb24:     	and	w8, w21, #0x3fffffff
1004edb28:     	lsr	x9, x8, #15
1004edb2c:     	cmp	x9, x10
1004edb30:     	b.hs	0x1004edb98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x358>
1004edb34:     	ldr	x10, [x0, #0x51c8]
1004edb38:     	ldr	x9, [x10, x9, lsl #3]
1004edb3c:     	cbz	x9, 0x1004edb98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x358>
1004edb40:     	ubfx	x10, x8, #5, #10
1004edb44:     	ldr	x9, [x9, x10, lsl #3]
1004edb48:     	cbz	x9, 0x1004edb98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x358>
1004edb4c:     	and	x8, x8, #0x1f
1004edb50:     	add	x8, x9, x8, lsl #5
1004edb54:     	ldrb	w9, [x8, #0x1c]
1004edb58:     	tbz	w9, #0x0, 0x1004edb98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x358>
1004edb5c:     	ldr	x22, [x8]
1004edb60:     	b	0x1004edb9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x35c>
1004edb64:     	bl	0x100b41dfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004edb68:     	add	x8, x0, x23, lsl #3
1004edb6c:     	ldr	x0, [x8, #0x1e8]
1004edb70:     	cbnz	x0, 0x1004edb0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x2cc>
1004edb74:     	adrp	x0, 0x100f0a000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json25PARSE_KEY_CACHE_OVERSIZED+0x3b0>
1004edb78:     	add	x0, x0, #0x578
1004edb7c:     	bl	0x100b3f61c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004edb80:     	ldr	x0, [x0]
1004edb84:     	cbnz	x0, 0x1004edb14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x2d4>
1004edb88:     	bl	0x100b412a0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime5state10init_state>
1004edb8c:     	mov	w8, #-0x40000001        ; =-1073741825
1004edb90:     	cmp	w22, w8
1004edb94:     	b.le	0x1004edb20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x2e0>
1004edb98:     	mov	x22, #0x0               ; =0
1004edb9c:     	ldr	w8, [x24, #0x4]
1004edba0:     	mov	w9, #-0x40000000        ; =-1073741824
1004edba4:     	cmp	w8, w9
1004edba8:     	csel	w26, w8, wzr, lt
1004edbac:     	adrp	x21, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf85c>
1004edbb0:     	ldr	w8, [x21, #0x7a4]
1004edbb4:     	cbz	w8, 0x1004edbc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x384>
1004edbb8:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
1004edbbc:     	bfxil	x0, x20, #0, #48
1004edbc0:     	bl	0x100476d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004edbc4:     	cbz	x22, 0x1004edbd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x398>
1004edbc8:     	ldr	w8, [x21, #0x7a4]
1004edbcc:     	cbz	w8, 0x1004edbd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x398>
1004edbd0:     	mov	x0, x22
1004edbd4:     	bl	0x100476d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004edbd8:     	ldr	w8, [sp, #0x4]
1004edbdc:     	cbz	w8, 0x1004edce8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x4a8>
1004edbe0:     	add	x8, sp, #0x10
1004edbe4:     	add	x24, x8, #0x8
1004edbe8:     	ldr	x28, [sp, #0x8]
1004edbec:     	b	0x1004edbfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3bc>
1004edbf0:     	add	x24, x24, #0x48
1004edbf4:     	subs	x28, x28, #0x48
1004edbf8:     	b.eq	0x1004edce8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x4a8>
1004edbfc:     	ldurb	w8, [x24, #-0x8]
1004edc00:     	tbz	w8, #0x0, 0x1004edcd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x494>
1004edc04:     	ldp	q0, q1, [x24]
1004edc08:     	stp	q0, q1, [sp, #0x290]
1004edc0c:     	ldp	q0, q1, [x24, #0x20]
1004edc10:     	stp	q0, q1, [sp, #0x2b0]
1004edc14:     	ldurb	w23, [x24, #-0x7]
1004edc18:     	cmp	w23, #0x9
1004edc1c:     	b.hs	0x1004ede70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x630>
1004edc20:     	cbz	w23, 0x1004edbf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3b0>
1004edc24:     	ldr	x0, [sp, #0x290]
1004edc28:     	ldr	w8, [x21, #0x7a4]
1004edc2c:     	cbz	w8, 0x1004edc34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3f4>
1004edc30:     	bl	0x100476d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004edc34:     	cmp	w23, #0x1
1004edc38:     	b.eq	0x1004edbf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3b0>
1004edc3c:     	ldr	x0, [sp, #0x298]
1004edc40:     	ldr	w8, [x21, #0x7a4]
1004edc44:     	cbz	w8, 0x1004edc4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x40c>
1004edc48:     	bl	0x100476d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004edc4c:     	cmp	w23, #0x2
1004edc50:     	b.eq	0x1004edbf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3b0>
1004edc54:     	ldr	x0, [sp, #0x2a0]
1004edc58:     	ldr	w8, [x21, #0x7a4]
1004edc5c:     	cbz	w8, 0x1004edc64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x424>
1004edc60:     	bl	0x100476d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004edc64:     	cmp	w23, #0x3
1004edc68:     	b.eq	0x1004edbf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3b0>
1004edc6c:     	ldr	x0, [sp, #0x2a8]
1004edc70:     	ldr	w8, [x21, #0x7a4]
1004edc74:     	cbz	w8, 0x1004edc7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x43c>
1004edc78:     	bl	0x100476d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004edc7c:     	cmp	w23, #0x4
1004edc80:     	b.eq	0x1004edbf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3b0>
1004edc84:     	ldr	x0, [sp, #0x2b0]
1004edc88:     	ldr	w8, [x21, #0x7a4]
1004edc8c:     	cbz	w8, 0x1004edc94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x454>
1004edc90:     	bl	0x100476d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004edc94:     	cmp	w23, #0x5
1004edc98:     	b.eq	0x1004edbf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3b0>
1004edc9c:     	ldr	x0, [sp, #0x2b8]
1004edca0:     	ldr	w8, [x21, #0x7a4]
1004edca4:     	cbz	w8, 0x1004edcac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x46c>
1004edca8:     	bl	0x100476d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004edcac:     	cmp	w23, #0x6
1004edcb0:     	b.eq	0x1004edbf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3b0>
1004edcb4:     	ldr	x0, [sp, #0x2c0]
1004edcb8:     	ldr	w8, [x21, #0x7a4]
1004edcbc:     	cbz	w8, 0x1004edcc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x484>
1004edcc0:     	bl	0x100476d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004edcc4:     	cmp	w23, #0x7
1004edcc8:     	b.eq	0x1004edbf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3b0>
1004edccc:     	ldr	x0, [sp, #0x2c8]
1004edcd0:     	b	0x1004edcd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x498>
1004edcd4:     	ldr	x0, [x24]
1004edcd8:     	ldr	w8, [x21, #0x7a4]
1004edcdc:     	cbz	w8, 0x1004edbf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3b0>
1004edce0:     	bl	0x100476d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1004edce4:     	b	0x1004edbf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x3b0>
1004edce8:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
1004edcec:     	ldr	w21, [x8, #0x578]
1004edcf0:     	cmp	w21, #0x300
1004edcf4:     	b.hs	0x1004ede4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x60c>
1004edcf8:     	ldr	x8, [x27, #0x48]
1004edcfc:     	cmn	x8, #0x1
1004edd00:     	b.eq	0x1004ede3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5fc>
1004edd04:     	mrs	x9, TPIDRRO_EL0
1004edd08:     	and	x9, x9, #0xfffffffffffffff8
1004edd0c:     	ldr	x0, [x9, x8, lsl #3]
1004edd10:     	cbz	x0, 0x1004ede3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5fc>
1004edd14:     	add	x8, x0, x21, lsl #3
1004edd18:     	ldr	x23, [x8, #0x1e8]
1004edd1c:     	cbz	x23, 0x1004ede4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x60c>
1004edd20:     	ldr	x8, [x23]
1004edd24:     	cbnz	x8, 0x1004ede64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x624>
1004edd28:     	mov	x8, #-0x1               ; =-1
1004edd2c:     	str	x8, [x23]
1004edd30:     	mov	x24, x23
1004edd34:     	ldrb	w8, [x24, #0x8]!
1004edd38:     	cmp	w8, #0x2
1004edd3c:     	ldr	w21, [sp, #0x4]
1004edd40:     	b.ne	0x1004eddf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5b0>
1004edd44:     	add	x8, sp, #0x290
1004edd48:     	adrp	x9, 0x100c44000 <_PERRY_EMPTY_STRING+0x34>
1004edd4c:     	add	x9, x9, #0xd70
1004edd50:     	ldp	q0, q1, [x9]
1004edd54:     	stp	q0, q1, [sp, #0x290]
1004edd58:     	ldp	q2, q3, [x9, #0x20]
1004edd5c:     	stp	q2, q3, [sp, #0x2b0]
1004edd60:     	str	xzr, [sp, #0x2d0]
1004edd64:     	str	xzr, [sp, #0x318]
1004edd68:     	stur	q0, [x8, #0x48]
1004edd6c:     	stur	q1, [x8, #0x58]
1004edd70:     	stur	q2, [x8, #0x68]
1004edd74:     	stur	q3, [x8, #0x78]
1004edd78:     	stp	q0, q1, [sp, #0x320]
1004edd7c:     	stp	q2, q3, [sp, #0x340]
1004edd80:     	add	x9, sp, #0x290
1004edd84:     	add	x10, x9, #0xd8
1004edd88:     	str	q3, [x10, #0x30]
1004edd8c:     	str	xzr, [sp, #0x360]
1004edd90:     	str	xzr, [sp, #0x3a8]
1004edd94:     	stur	q2, [x8, #0xf8]
1004edd98:     	stur	q1, [x8, #0xe8]
1004edd9c:     	stur	q0, [x8, #0xd8]
1004edda0:     	stp	q2, q3, [sp, #0x3d0]
1004edda4:     	stp	q0, q1, [sp, #0x3b0]
1004edda8:     	add	x8, x9, #0x168
1004eddac:     	stp	q0, q1, [x8]
1004eddb0:     	stp	q2, q3, [x8, #0x20]
1004eddb4:     	str	xzr, [sp, #0x3f0]
1004eddb8:     	str	xzr, [sp, #0x438]
1004eddbc:     	str	q3, [sp, #0x470]
1004eddc0:     	str	q2, [sp, #0x460]
1004eddc4:     	str	q1, [sp, #0x450]
1004eddc8:     	str	q0, [sp, #0x440]
1004eddcc:     	add	x8, x9, #0x1f8
1004eddd0:     	stp	q2, q3, [x8, #0x20]
1004eddd4:     	stp	q0, q1, [x8]
1004eddd8:     	str	xzr, [sp, #0x480]
1004edddc:     	str	xzr, [sp, #0x4c8]
1004edde0:     	add	x1, sp, #0x290
1004edde4:     	mov	x0, x24
1004edde8:     	mov	w2, #0x240              ; =576
1004eddec:     	bl	0x100b648ac <_writev+0x100b648ac>
1004eddf0:     	str	x20, [x23, #0x248]
1004eddf4:     	strh	w19, [x23, #0x25c]
1004eddf8:     	str	x22, [x23, #0x250]
1004eddfc:     	str	w26, [x23, #0x258]
1004ede00:     	cbz	w21, 0x1004ede14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x5d4>
1004ede04:     	add	x1, sp, #0x10
1004ede08:     	mov	x0, x24
1004ede0c:     	ldr	x2, [sp, #0x8]
1004ede10:     	bl	0x100b648ac <_writev+0x100b648ac>
1004ede14:     	strb	w21, [x23, #0x25e]
1004ede18:     	str	xzr, [x23]
1004ede1c:     	add	sp, sp, #0x4e0
1004ede20:     	ldp	x29, x30, [sp, #0x50]
1004ede24:     	ldp	x20, x19, [sp, #0x40]
1004ede28:     	ldp	x22, x21, [sp, #0x30]
1004ede2c:     	ldp	x24, x23, [sp, #0x20]
1004ede30:     	ldp	x26, x25, [sp, #0x10]
1004ede34:     	ldp	x28, x27, [sp], #0x60
1004ede38:     	ret
1004ede3c:     	bl	0x100b41dfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004ede40:     	add	x8, x0, x21, lsl #3
1004ede44:     	ldr	x23, [x8, #0x1e8]
1004ede48:     	cbnz	x23, 0x1004edd20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x4e0>
1004ede4c:     	adrp	x0, 0x100f0f000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004ede50:     	add	x0, x0, #0xfb8
1004ede54:     	bl	0x100b3f61c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004ede58:     	mov	x23, x0
1004ede5c:     	ldr	x8, [x0]
1004ede60:     	cbz	x8, 0x1004edd28 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template+0x4e8>
1004ede64:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004ede68:     	add	x0, x0, #0xd28
1004ede6c:     	bl	0x100b1512c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1004ede70:     	adrp	x3, 0x100f0f000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004ede74:     	add	x3, x3, #0xfd0
1004ede78:     	mov	x0, #0x0                ; =0
1004ede7c:     	mov	x1, x23
1004ede80:     	mov	w2, #0x8                ; =8
1004ede84:     	bl	0x100b1544c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
