
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/compact-template-capture-r39/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008499ec <_js_json_stringify>:
1008499ec:     	sub	sp, sp, #0x80
1008499f0:     	stp	d9, d8, [sp, #0x20]
1008499f4:     	stp	x26, x25, [sp, #0x30]
1008499f8:     	stp	x24, x23, [sp, #0x40]
1008499fc:     	stp	x22, x21, [sp, #0x50]
100849a00:     	stp	x20, x19, [sp, #0x60]
100849a04:     	stp	x29, x30, [sp, #0x70]
100849a08:     	add	x29, sp, #0x70
100849a0c:     	mov	x21, x0
100849a10:     	mov.16b	v8, v0
100849a14:     	fmov	x19, d8
100849a18:     	and	x20, x19, #0xffff000000000000
100849a1c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100849a20:     	cmp	x20, x8
100849a24:     	b.ne	0x100849a4c <_js_json_stringify+0x60>
100849a28:     	and	x0, x19, #0xffffffffffff
100849a2c:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
100849a30:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100849a34:     	movk	x9, #0xffef, lsl #16
100849a38:     	cmp	x8, x9
100849a3c:     	b.hi	0x100849a4c <_js_json_stringify+0x60>
100849a40:     	ldr	w8, [x0, #0x4]
100849a44:     	cmp	w8, #0x40
100849a48:     	b.hs	0x100849abc <_js_json_stringify+0xd0>
100849a4c:     	mov.16b	v0, v8
100849a50:     	bl	0x1004f0a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100849a54:     	tbz	w0, #0x0, 0x100849a60 <_js_json_stringify+0x74>
100849a58:     	mov	x23, x1
100849a5c:     	b	0x100849fd0 <_js_json_stringify+0x5e4>
100849a60:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100849a64:     	cmp	x20, x8
100849a68:     	b.ne	0x100849ad0 <_js_json_stringify+0xe4>
100849a6c:     	ands	x19, x19, #0xffffffffffff
100849a70:     	b.eq	0x100849ad0 <_js_json_stringify+0xe4>
100849a74:     	mov	x0, x19
100849a78:     	bl	0x1005120f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100849a7c:     	cbz	w0, 0x100849ad0 <_js_json_stringify+0xe4>
100849a80:     	ldurb	w8, [x19, #-0x8]
100849a84:     	cmp	w8, #0x9
100849a88:     	b.ne	0x100849ad0 <_js_json_stringify+0xe4>
100849a8c:     	ldr	w8, [x19, #0x4]
100849a90:     	mov	w9, #0x5841             ; =22593
100849a94:     	movk	w9, #0x4c5a, lsl #16
100849a98:     	cmp	w8, w9
100849a9c:     	b.ne	0x100849ad0 <_js_json_stringify+0xe4>
100849aa0:     	mov	x0, x19
100849aa4:     	bl	0x10068bd64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100849aa8:     	cbz	x0, 0x100849ad0 <_js_json_stringify+0xe4>
100849aac:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100849ab0:     	bfxil	x8, x0, #0, #48
100849ab4:     	fmov	d8, x8
100849ab8:     	b	0x100849ad0 <_js_json_stringify+0xe4>
100849abc:     	bl	0x1004f5968 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100849ac0:     	tbnz	w0, #0x0, 0x100849a58 <_js_json_stringify+0x6c>
100849ac4:     	mov.16b	v0, v8
100849ac8:     	bl	0x1004f0a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100849acc:     	tbnz	w0, #0x0, 0x100849a58 <_js_json_stringify+0x6c>
100849ad0:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849ad4:     	add	x0, x0, #0xd78
100849ad8:     	ldr	x8, [x0]
100849adc:     	blr	x8
100849ae0:     	mov	x19, x0
100849ae4:     	ldr	w26, [x0]
100849ae8:     	add	w8, w26, #0x1
100849aec:     	str	w8, [x0]
100849af0:     	cbz	w26, 0x100849b60 <_js_json_stringify+0x174>
100849af4:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849af8:     	add	x0, x0, #0xd00
100849afc:     	ldr	x8, [x0]
100849b00:     	blr	x8
100849b04:     	ldrb	w8, [x0, #0x20]
100849b08:     	cmp	w8, #0x1
100849b0c:     	b.ne	0x10084a0c4 <_js_json_stringify+0x6d8>
100849b10:     	ldr	x8, [x0]
100849b14:     	cbnz	x8, 0x10084a0d0 <_js_json_stringify+0x6e4>
100849b18:     	mov	x8, #-0x1               ; =-1
100849b1c:     	str	x8, [x0]
100849b20:     	ldr	x20, [x0, #0x18]
100849b24:     	ldr	x8, [x0, #0x8]
100849b28:     	cmp	x20, x8
100849b2c:     	b.eq	0x100849ff4 <_js_json_stringify+0x608>
100849b30:     	ldr	x8, [x0, #0x10]
100849b34:     	mov	w9, #0x18               ; =24
100849b38:     	madd	x8, x20, x9, x8
100849b3c:     	mov	w9, #0x8                ; =8
100849b40:     	stp	xzr, x9, [x8]
100849b44:     	str	xzr, [x8, #0x10]
100849b48:     	add	x8, x20, #0x1
100849b4c:     	str	x8, [x0, #0x18]
100849b50:     	ldr	x8, [x0]
100849b54:     	add	x8, x8, #0x1
100849b58:     	str	x8, [x0]
100849b5c:     	b	0x100849bec <_js_json_stringify+0x200>
100849b60:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849b64:     	add	x0, x0, #0xdc0
100849b68:     	ldr	x8, [x0]
100849b6c:     	blr	x8
100849b70:     	strb	wzr, [x0]
100849b74:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849b78:     	add	x0, x0, #0xdf0
100849b7c:     	ldr	x8, [x0]
100849b80:     	blr	x8
100849b84:     	strb	wzr, [x0]
100849b88:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
100849b8c:     	ldr	w20, [x8, #0x5a8]
100849b90:     	cmp	w20, #0x300
100849b94:     	b.hs	0x10084a050 <_js_json_stringify+0x664>
100849b98:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
100849b9c:     	ldr	x8, [x8, #0x48]
100849ba0:     	cmn	x8, #0x1
100849ba4:     	b.eq	0x10084a040 <_js_json_stringify+0x654>
100849ba8:     	mrs	x9, TPIDRRO_EL0
100849bac:     	and	x9, x9, #0xfffffffffffffff8
100849bb0:     	ldr	x0, [x9, x8, lsl #3]
100849bb4:     	cbz	x0, 0x10084a040 <_js_json_stringify+0x654>
100849bb8:     	add	x8, x0, x20, lsl #3
100849bbc:     	ldr	x0, [x8, #0x1e8]
100849bc0:     	cbz	x0, 0x10084a050 <_js_json_stringify+0x664>
100849bc4:     	str	xzr, [x0]
100849bc8:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849bcc:     	add	x0, x0, #0xd90
100849bd0:     	ldr	x8, [x0]
100849bd4:     	blr	x8
100849bd8:     	ldrb	w8, [x0, #0x20]
100849bdc:     	cbnz	w8, 0x10084a0dc <_js_json_stringify+0x6f0>
100849be0:     	ldr	x8, [x0]
100849be4:     	cbnz	x8, 0x10084a104 <_js_json_stringify+0x718>
100849be8:     	str	xzr, [x0, #0x18]
100849bec:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849bf0:     	add	x0, x0, #0xd30
100849bf4:     	ldr	x8, [x0]
100849bf8:     	blr	x8
100849bfc:     	mov	x20, x0
100849c00:     	ldrb	w8, [x0, #0x18]
100849c04:     	cmp	w8, #0x1
100849c08:     	b.ne	0x10084a060 <_js_json_stringify+0x674>
100849c0c:     	ldr	x8, [x0]
100849c10:     	mov	x9, #-0x1               ; =-1
100849c14:     	str	x9, [x0]
100849c18:     	cmn	x8, #0x2
100849c1c:     	b.eq	0x10084a110 <_js_json_stringify+0x724>
100849c20:     	cmn	x8, #0x1
100849c24:     	b.eq	0x100849c38 <_js_json_stringify+0x24c>
100849c28:     	add	x9, sp, #0x8
100849c2c:     	ldur	q0, [x0, #0x8]
100849c30:     	stur	q0, [x9, #0x8]
100849c34:     	b	0x100849c44 <_js_json_stringify+0x258>
100849c38:     	mov	x8, #0x0                ; =0
100849c3c:     	mov	w9, #0x1                ; =1
100849c40:     	stp	x9, xzr, [sp, #0x10]
100849c44:     	str	x8, [sp, #0x8]
100849c48:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849c4c:     	add	x0, x0, #0xd18
100849c50:     	ldr	x8, [x0]
100849c54:     	blr	x8
100849c58:     	ldrb	w8, [x0, #0x20]
100849c5c:     	cbnz	w8, 0x10084a090 <_js_json_stringify+0x6a4>
100849c60:     	ldr	x8, [x0]
100849c64:     	cbnz	x8, 0x10084a0b8 <_js_json_stringify+0x6cc>
100849c68:     	str	xzr, [x0, #0x18]
100849c6c:     	add	x1, sp, #0x8
100849c70:     	mov.16b	v0, v8
100849c74:     	mov	x0, x21
100849c78:     	bl	0x10050c544 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100849c7c:     	ldp	x21, x22, [sp, #0x10]
100849c80:     	cmp	w22, #0x80, lsl #12     ; =0x80000
100849c84:     	b.hs	0x100849d44 <_js_json_stringify+0x358>
100849c88:     	cmp	x22, #0x40
100849c8c:     	b.hs	0x100849e08 <_js_json_stringify+0x41c>
100849c90:     	ands	x9, x22, #0x38
100849c94:     	b.eq	0x100849cb8 <_js_json_stringify+0x2cc>
100849c98:     	and	x8, x22, #0x38
100849c9c:     	neg	x8, x8
100849ca0:     	mov	x10, x21
100849ca4:     	ldr	x11, [x10], #0x8
100849ca8:     	tst	x11, #0x8080808080808080
100849cac:     	b.ne	0x100849d2c <_js_json_stringify+0x340>
100849cb0:     	adds	x8, x8, #0x8
100849cb4:     	b.ne	0x100849ca4 <_js_json_stringify+0x2b8>
100849cb8:     	and	x8, x22, #0x7
100849cbc:     	cbz	x8, 0x100849e8c <_js_json_stringify+0x4a0>
100849cc0:     	add	x9, x21, x9
100849cc4:     	ldrsb	w10, [x9]
100849cc8:     	tbnz	w10, #0x1f, 0x100849d2c <_js_json_stringify+0x340>
100849ccc:     	cmp	x8, #0x1
100849cd0:     	b.eq	0x100849e8c <_js_json_stringify+0x4a0>
100849cd4:     	ldrsb	w10, [x9, #0x1]
100849cd8:     	tbnz	w10, #0x1f, 0x100849d2c <_js_json_stringify+0x340>
100849cdc:     	cmp	x8, #0x2
100849ce0:     	b.eq	0x100849e8c <_js_json_stringify+0x4a0>
100849ce4:     	ldrsb	w10, [x9, #0x2]
100849ce8:     	tbnz	w10, #0x1f, 0x100849d2c <_js_json_stringify+0x340>
100849cec:     	cmp	x8, #0x3
100849cf0:     	b.eq	0x100849e8c <_js_json_stringify+0x4a0>
100849cf4:     	ldrsb	w10, [x9, #0x3]
100849cf8:     	tbnz	w10, #0x1f, 0x100849d2c <_js_json_stringify+0x340>
100849cfc:     	cmp	x8, #0x4
100849d00:     	b.eq	0x100849e8c <_js_json_stringify+0x4a0>
100849d04:     	ldrsb	w10, [x9, #0x4]
100849d08:     	tbnz	w10, #0x1f, 0x100849d2c <_js_json_stringify+0x340>
100849d0c:     	cmp	x8, #0x5
100849d10:     	b.eq	0x100849e8c <_js_json_stringify+0x4a0>
100849d14:     	ldrsb	w10, [x9, #0x5]
100849d18:     	tbnz	w10, #0x1f, 0x100849d2c <_js_json_stringify+0x340>
100849d1c:     	cmp	x8, #0x6
100849d20:     	b.eq	0x100849e8c <_js_json_stringify+0x4a0>
100849d24:     	ldrsb	w8, [x9, #0x6]
100849d28:     	tbz	w8, #0x1f, 0x100849e8c <_js_json_stringify+0x4a0>
100849d2c:     	mov	x0, x21
100849d30:     	mov	x1, x22
100849d34:     	mov	x2, x22
100849d38:     	bl	0x1008e13c0 <_js_string_from_bytes_with_capacity>
100849d3c:     	mov	x23, x0
100849d40:     	b	0x100849f88 <_js_json_stringify+0x59c>
100849d44:     	and	x8, x22, #0x7fffffffffffffc0
100849d48:     	add	x8, x21, x8
100849d4c:     	mov	x9, x21
100849d50:     	ldp	q0, q1, [x9]
100849d54:     	ldp	q2, q3, [x9, #0x20]
100849d58:     	orr.16b	v0, v1, v0
100849d5c:     	orr.16b	v1, v2, v3
100849d60:     	orr.16b	v0, v0, v1
100849d64:     	umaxv.16b	b0, v0
100849d68:     	fmov	w10, s0
100849d6c:     	tbnz	w10, #0x7, 0x100849dcc <_js_json_stringify+0x3e0>
100849d70:     	add	x9, x9, #0x40
100849d74:     	cmp	x9, x8
100849d78:     	b.ne	0x100849d50 <_js_json_stringify+0x364>
100849d7c:     	ands	x9, x22, #0x30
100849d80:     	b.eq	0x100849da4 <_js_json_stringify+0x3b8>
100849d84:     	mov	x10, x9
100849d88:     	mov	x11, x8
100849d8c:     	ldr	q0, [x11], #0x10
100849d90:     	umaxv.16b	b0, v0
100849d94:     	fmov	w12, s0
100849d98:     	tbnz	w12, #0x7, 0x100849dcc <_js_json_stringify+0x3e0>
100849d9c:     	subs	x10, x10, #0x10
100849da0:     	b.ne	0x100849d8c <_js_json_stringify+0x3a0>
100849da4:     	and	x10, x22, #0xf
100849da8:     	cbz	x10, 0x100849dc4 <_js_json_stringify+0x3d8>
100849dac:     	add	x8, x8, x9
100849db0:     	ldrsb	w9, [x8]
100849db4:     	tbnz	w9, #0x1f, 0x100849dcc <_js_json_stringify+0x3e0>
100849db8:     	add	x8, x8, #0x1
100849dbc:     	subs	x10, x10, #0x1
100849dc0:     	b.ne	0x100849db0 <_js_json_stringify+0x3c4>
100849dc4:     	mov	w24, w22
100849dc8:     	b	0x100849e00 <_js_json_stringify+0x414>
100849dcc:     	mov	w24, w22
100849dd0:     	cbz	x24, 0x100849e00 <_js_json_stringify+0x414>
100849dd4:     	mov	x8, x21
100849dd8:     	ands	x9, x22, #0x3
100849ddc:     	b.eq	0x100849df8 <_js_json_stringify+0x40c>
100849de0:     	mov	x8, x21
100849de4:     	ldrsb	w10, [x8]
100849de8:     	tbnz	w10, #0x1f, 0x100849ef0 <_js_json_stringify+0x504>
100849dec:     	add	x8, x8, #0x1
100849df0:     	subs	x9, x9, #0x1
100849df4:     	b.ne	0x100849de4 <_js_json_stringify+0x3f8>
100849df8:     	cmp	x24, #0x4
100849dfc:     	b.hs	0x100849ebc <_js_json_stringify+0x4d0>
100849e00:     	mov	x25, x22
100849e04:     	b	0x100849f00 <_js_json_stringify+0x514>
100849e08:     	and	x8, x22, #0x7fffffffffffffc0
100849e0c:     	and	x8, x8, #0xffffffff0007ffff
100849e10:     	add	x8, x21, x8
100849e14:     	mov	x9, x21
100849e18:     	ldp	q0, q1, [x9]
100849e1c:     	ldp	q2, q3, [x9, #0x20]
100849e20:     	orr.16b	v0, v1, v0
100849e24:     	orr.16b	v1, v2, v3
100849e28:     	orr.16b	v0, v0, v1
100849e2c:     	umaxv.16b	b0, v0
100849e30:     	fmov	w10, s0
100849e34:     	tbnz	w10, #0x7, 0x100849d2c <_js_json_stringify+0x340>
100849e38:     	add	x9, x9, #0x40
100849e3c:     	cmp	x9, x8
100849e40:     	b.ne	0x100849e18 <_js_json_stringify+0x42c>
100849e44:     	ands	x9, x22, #0x30
100849e48:     	b.eq	0x100849e6c <_js_json_stringify+0x480>
100849e4c:     	mov	x10, x9
100849e50:     	mov	x11, x8
100849e54:     	ldr	q0, [x11], #0x10
100849e58:     	umaxv.16b	b0, v0
100849e5c:     	fmov	w12, s0
100849e60:     	tbnz	w12, #0x7, 0x100849d2c <_js_json_stringify+0x340>
100849e64:     	subs	x10, x10, #0x10
100849e68:     	b.ne	0x100849e54 <_js_json_stringify+0x468>
100849e6c:     	and	x10, x22, #0xf
100849e70:     	cbz	x10, 0x100849e8c <_js_json_stringify+0x4a0>
100849e74:     	add	x8, x8, x9
100849e78:     	ldrsb	w9, [x8]
100849e7c:     	tbnz	w9, #0x1f, 0x100849d2c <_js_json_stringify+0x340>
100849e80:     	add	x8, x8, #0x1
100849e84:     	subs	x10, x10, #0x1
100849e88:     	b.ne	0x100849e78 <_js_json_stringify+0x48c>
100849e8c:     	mov	x0, x22
100849e90:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100849e94:     	mov	x23, x0
100849e98:     	stp	w22, w22, [x0]
100849e9c:     	stp	wzr, wzr, [x0, #0xc]
100849ea0:     	str	w22, [x0, #0x8]
100849ea4:     	cbz	w22, 0x100849f88 <_js_json_stringify+0x59c>
100849ea8:     	and	x2, x22, #0x7ffff
100849eac:     	mov	x0, x1
100849eb0:     	mov	x1, x21
100849eb4:     	bl	0x100b66a6c <_writev+0x100b66a6c>
100849eb8:     	b	0x100849f88 <_js_json_stringify+0x59c>
100849ebc:     	add	x9, x21, x24
100849ec0:     	ldrsb	w10, [x8]
100849ec4:     	tbnz	w10, #0x1f, 0x100849ef0 <_js_json_stringify+0x504>
100849ec8:     	ldrsb	w10, [x8, #0x1]
100849ecc:     	tbnz	w10, #0x1f, 0x100849ef0 <_js_json_stringify+0x504>
100849ed0:     	ldrsb	w10, [x8, #0x2]
100849ed4:     	tbnz	w10, #0x1f, 0x100849ef0 <_js_json_stringify+0x504>
100849ed8:     	ldrsb	w10, [x8, #0x3]
100849edc:     	tbnz	w10, #0x1f, 0x100849ef0 <_js_json_stringify+0x504>
100849ee0:     	add	x8, x8, #0x4
100849ee4:     	cmp	x8, x9
100849ee8:     	b.ne	0x100849ec0 <_js_json_stringify+0x4d4>
100849eec:     	b	0x100849e00 <_js_json_stringify+0x414>
100849ef0:     	mov	w1, w22
100849ef4:     	mov	x0, x21
100849ef8:     	bl	0x1005ed8e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
100849efc:     	mov	x25, x0
100849f00:     	bl	0x1004f2bc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100849f04:     	add	x0, x24, #0x14
100849f08:     	mov	w1, #0x3                ; =3
100849f0c:     	bl	0x10045ae40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
100849f10:     	mov	x23, x0
100849f14:     	stp	w25, w22, [x0]
100849f18:     	stp	wzr, wzr, [x0, #0xc]
100849f1c:     	str	w22, [x0, #0x8]
100849f20:     	add	x0, x0, #0x14
100849f24:     	mov	x1, x21
100849f28:     	mov	x2, x24
100849f2c:     	bl	0x100b66a6c <_writev+0x100b66a6c>
100849f30:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
100849f34:     	ldr	w21, [x8, #0x590]
100849f38:     	cmp	w21, #0x300
100849f3c:     	b.hs	0x10084a018 <_js_json_stringify+0x62c>
100849f40:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
100849f44:     	ldr	x8, [x8, #0x48]
100849f48:     	cmn	x8, #0x1
100849f4c:     	b.eq	0x10084a008 <_js_json_stringify+0x61c>
100849f50:     	mrs	x9, TPIDRRO_EL0
100849f54:     	and	x9, x9, #0xfffffffffffffff8
100849f58:     	ldr	x0, [x9, x8, lsl #3]
100849f5c:     	cbz	x0, 0x10084a008 <_js_json_stringify+0x61c>
100849f60:     	add	x8, x0, x21, lsl #3
100849f64:     	ldr	x0, [x8, #0x1e8]
100849f68:     	cbz	x0, 0x10084a018 <_js_json_stringify+0x62c>
100849f6c:     	ldr	x8, [x0]
100849f70:     	adds	x8, x8, x24
100849f74:     	csinv	x8, x8, xzr, lo
100849f78:     	str	x8, [x0]
100849f7c:     	lsr	x8, x8, #25
100849f80:     	cbz	x8, 0x100849f88 <_js_json_stringify+0x59c>
100849f84:     	bl	0x100461d74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100849f88:     	ldp	x22, x21, [sp, #0x8]
100849f8c:     	ldrb	w8, [x20, #0x18]
100849f90:     	cmp	w8, #0x1
100849f94:     	b.ne	0x10084a070 <_js_json_stringify+0x684>
100849f98:     	ldp	x8, x0, [x20]
100849f9c:     	stp	x22, x21, [x20]
100849fa0:     	str	xzr, [x20, #0x10]
100849fa4:     	sub	x8, x8, #0x1
100849fa8:     	cmn	x8, #0x2
100849fac:     	b.hs	0x100849fb4 <_js_json_stringify+0x5c8>
100849fb0:     	bl	0x100b63bc0 <_mi_free>
100849fb4:     	cbz	w26, 0x100849fc0 <_js_json_stringify+0x5d4>
100849fb8:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100849fbc:     	b	0x100849fc4 <_js_json_stringify+0x5d8>
100849fc0:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100849fc4:     	ldr	w8, [x19]
100849fc8:     	sub	w8, w8, #0x1
100849fcc:     	str	w8, [x19]
100849fd0:     	mov	x0, x23
100849fd4:     	ldp	x29, x30, [sp, #0x70]
100849fd8:     	ldp	x20, x19, [sp, #0x60]
100849fdc:     	ldp	x22, x21, [sp, #0x50]
100849fe0:     	ldp	x24, x23, [sp, #0x40]
100849fe4:     	ldp	x26, x25, [sp, #0x30]
100849fe8:     	ldp	d9, d8, [sp, #0x20]
100849fec:     	add	sp, sp, #0x80
100849ff0:     	ret
100849ff4:     	mov	x22, x0
100849ff8:     	add	x0, x0, #0x8
100849ffc:     	bl	0x100b40910 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10084a000:     	mov	x0, x22
10084a004:     	b	0x100849b30 <_js_json_stringify+0x144>
10084a008:     	bl	0x100b43fbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084a00c:     	add	x8, x0, x21, lsl #3
10084a010:     	ldr	x0, [x8, #0x1e8]
10084a014:     	cbnz	x0, 0x100849f6c <_js_json_stringify+0x580>
10084a018:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084a01c:     	add	x0, x0, #0x78
10084a020:     	bl	0x100b417dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084a024:     	ldr	x8, [x0]
10084a028:     	adds	x8, x8, x24
10084a02c:     	csinv	x8, x8, xzr, lo
10084a030:     	str	x8, [x0]
10084a034:     	lsr	x8, x8, #25
10084a038:     	cbnz	x8, 0x100849f84 <_js_json_stringify+0x598>
10084a03c:     	b	0x100849f88 <_js_json_stringify+0x59c>
10084a040:     	bl	0x100b43fbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084a044:     	add	x8, x0, x20, lsl #3
10084a048:     	ldr	x0, [x8, #0x1e8]
10084a04c:     	cbnz	x0, 0x100849bc4 <_js_json_stringify+0x1d8>
10084a050:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084a054:     	add	x0, x0, #0x138
10084a058:     	bl	0x100b417dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084a05c:     	b	0x100849bc4 <_js_json_stringify+0x1d8>
10084a060:     	mov	x0, x20
10084a064:     	bl	0x100b23144 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084a068:     	cbnz	x0, 0x100849c0c <_js_json_stringify+0x220>
10084a06c:     	b	0x10084a110 <_js_json_stringify+0x724>
10084a070:     	mov	x0, x20
10084a074:     	bl	0x100b23144 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084a078:     	mov	x20, x0
10084a07c:     	cbnz	x0, 0x100849f98 <_js_json_stringify+0x5ac>
10084a080:     	cbz	x22, 0x10084a110 <_js_json_stringify+0x724>
10084a084:     	mov	x0, x21
10084a088:     	bl	0x100b63bc0 <_mi_free>
10084a08c:     	b	0x10084a110 <_js_json_stringify+0x724>
10084a090:     	cmp	w8, #0x2
10084a094:     	b.eq	0x10084a110 <_js_json_stringify+0x724>
10084a098:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084a09c:     	add	x1, x1, #0xef8
10084a0a0:     	mov	x22, x0
10084a0a4:     	bl	0x100a2501c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084a0a8:     	mov	x0, x22
10084a0ac:     	strb	wzr, [x22, #0x20]
10084a0b0:     	ldr	x8, [x22]
10084a0b4:     	cbz	x8, 0x100849c68 <_js_json_stringify+0x27c>
10084a0b8:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084a0bc:     	add	x0, x0, #0xdb8
10084a0c0:     	bl	0x100b172ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a0c4:     	bl	0x100b232a4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084a0c8:     	cbnz	x0, 0x100849b10 <_js_json_stringify+0x124>
10084a0cc:     	b	0x10084a110 <_js_json_stringify+0x724>
10084a0d0:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10084a0d4:     	add	x0, x0, #0x440
10084a0d8:     	bl	0x100b172ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a0dc:     	cmp	w8, #0x1
10084a0e0:     	b.ne	0x10084a110 <_js_json_stringify+0x724>
10084a0e4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084a0e8:     	add	x1, x1, #0x898
10084a0ec:     	mov	x20, x0
10084a0f0:     	bl	0x100a2501c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084a0f4:     	mov	x0, x20
10084a0f8:     	strb	wzr, [x20, #0x20]
10084a0fc:     	ldr	x8, [x20]
10084a100:     	cbz	x8, 0x100849be8 <_js_json_stringify+0x1fc>
10084a104:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084a108:     	add	x0, x0, #0xd88
10084a10c:     	bl	0x100b172ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a110:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084a114:     	add	x0, x0, #0xc18
10084a118:     	bl	0x100b5d21c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
