
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-only-r14/main-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100243948 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value>:
100243948:     	sub	sp, sp, #0x60
10024394c:     	stp	x24, x23, [sp, #0x20]
100243950:     	stp	x22, x21, [sp, #0x30]
100243954:     	stp	x20, x19, [sp, #0x40]
100243958:     	stp	x29, x30, [sp, #0x50]
10024395c:     	add	x29, sp, #0x50
100243960:     	mov	x21, x0
100243964:     	ldr	x23, [x0, #0x70]
100243968:     	ldp	x8, x9, [x0]
10024396c:     	cmp	x8, #0x0
100243970:     	ccmp	x9, x23, #0x0, ne
100243974:     	b.eq	0x1002439a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x58>
100243978:     	add	x0, sp, #0x8
10024397c:     	mov	x1, x21
100243980:     	bl	0x1002434f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
100243984:     	ldr	x22, [sp, #0x8]
100243988:     	cmn	x22, #0x2
10024398c:     	b.ne	0x1002439c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x80>
100243990:     	strb	wzr, [x21, #0xd4]
100243994:     	mov	x0, #0x2                ; =2
100243998:     	movk	x0, #0x7ffc, lsl #48
10024399c:     	b	0x1002439b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
1002439a0:     	ldp	x8, x9, [x21, #0x10]
1002439a4:     	str	x8, [x21, #0x70]
1002439a8:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
1002439ac:     	bfxil	x0, x9, #0, #48
1002439b0:     	ldp	x29, x30, [sp, #0x50]
1002439b4:     	ldp	x20, x19, [sp, #0x40]
1002439b8:     	ldp	x22, x21, [sp, #0x30]
1002439bc:     	ldp	x24, x23, [sp, #0x20]
1002439c0:     	add	sp, sp, #0x60
1002439c4:     	ret
1002439c8:     	ldp	x20, x19, [sp, #0x10]
1002439cc:     	cmp	x19, #0x6
1002439d0:     	b.hs	0x100243a60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
1002439d4:     	subs	x8, x19, #0x3
1002439d8:     	b.lo	0x100243a8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
1002439dc:     	ldrb	w9, [x20]
1002439e0:     	cmp	w9, #0xed
1002439e4:     	b.ne	0x100243a04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xbc>
1002439e8:     	ldrb	w9, [x20, #0x1]
1002439ec:     	and	w9, w9, #0xe0
1002439f0:     	cmp	w9, #0xa0
1002439f4:     	b.ne	0x100243a04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xbc>
1002439f8:     	ldrsb	w9, [x20, #0x2]
1002439fc:     	cmn	w9, #0x40
100243a00:     	b.lt	0x100243a60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100243a04:     	cbz	x8, 0x100243a8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100243a08:     	ldrb	w9, [x20, #0x1]
100243a0c:     	cmp	w9, #0xed
100243a10:     	b.ne	0x100243a30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xe8>
100243a14:     	ldrb	w9, [x20, #0x2]
100243a18:     	and	w9, w9, #0xe0
100243a1c:     	cmp	w9, #0xa0
100243a20:     	b.ne	0x100243a30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xe8>
100243a24:     	ldrsb	w9, [x20, #0x3]
100243a28:     	cmn	w9, #0x40
100243a2c:     	b.lt	0x100243a60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100243a30:     	cmp	x8, #0x1
100243a34:     	b.eq	0x100243a8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100243a38:     	ldrb	w8, [x20, #0x2]
100243a3c:     	cmp	w8, #0xed
100243a40:     	b.ne	0x100243a8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100243a44:     	ldrb	w8, [x20, #0x3]
100243a48:     	and	w8, w8, #0xe0
100243a4c:     	cmp	w8, #0xa0
100243a50:     	b.ne	0x100243a8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100243a54:     	ldrsb	w8, [x20, #0x4]
100243a58:     	cmn	w8, #0x40
100243a5c:     	b.ge	0x100243a8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100243a60:     	cmn	x22, #0x1
100243a64:     	b.eq	0x100243aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x160>
100243a68:     	mov	x0, x20
100243a6c:     	mov	x1, x19
100243a70:     	bl	0x100349370 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
100243a74:     	mov	x8, x0
100243a78:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100243a7c:     	bfxil	x0, x8, #0, #48
100243a80:     	cmp	x22, #0x1
100243a84:     	b.ge	0x100243c38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2f0>
100243a88:     	b	0x1002439b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100243a8c:     	cbz	x19, 0x100243b6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x224>
100243a90:     	cmp	x19, #0x4
100243a94:     	b.hs	0x100243b74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x22c>
100243a98:     	mov	x10, #0x0               ; =0
100243a9c:     	mov	x9, #0x0                ; =0
100243aa0:     	mov	x8, x20
100243aa4:     	b	0x100243c04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2bc>
100243aa8:     	add	x0, x21, #0x20
100243aac:     	mov	x1, x20
100243ab0:     	mov	x2, x19
100243ab4:     	bl	0x1005e8a84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
100243ab8:     	ldr	x22, [x21, #0x68]
100243abc:     	cmp	x22, #0x200, lsl #12    ; =0x200000
100243ac0:     	b.hi	0x100243cac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100243ac4:     	cmp	x19, #0x100
100243ac8:     	b.lo	0x100243cac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100243acc:     	cbz	x0, 0x100243cac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100243ad0:     	ldr	x20, [x21, #0xc8]
100243ad4:     	cbz	x20, 0x100243cac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100243ad8:     	ldr	x21, [x21, #0x70]
100243adc:     	sub	x8, x22, x22, lsr #1
100243ae0:     	cmp	x19, x8
100243ae4:     	orr	x8, x21, x23
100243ae8:     	and	x8, x8, #0xffffffff00000000
100243aec:     	ccmp	x8, #0x0, #0x0, hs
100243af0:     	b.ne	0x100243cac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100243af4:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100243af8:     	ldr	w19, [x8, #0x560]
100243afc:     	cmp	w19, #0x300
100243b00:     	b.hs	0x100243cd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x390>
100243b04:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100243b08:     	ldr	x8, [x8, #0x48]
100243b0c:     	cmn	x8, #0x1
100243b10:     	b.eq	0x100243cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x374>
100243b14:     	mrs	x9, TPIDRRO_EL0
100243b18:     	and	x9, x9, #0xfffffffffffffff8
100243b1c:     	ldr	x8, [x9, x8, lsl #3]
100243b20:     	cbz	x8, 0x100243cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x374>
100243b24:     	add	x8, x8, x19, lsl #3
100243b28:     	ldr	x19, [x8, #0x1e8]
100243b2c:     	cbz	x19, 0x100243cd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x390>
100243b30:     	ldr	x8, [x19]
100243b34:     	cbnz	x8, 0x100243cf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3b0>
100243b38:     	mov	x8, #-0x1               ; =-1
100243b3c:     	str	x8, [x19]
100243b40:     	ldrb	w8, [x19, #0x24]
100243b44:     	cmp	w8, #0x2
100243b48:     	b.eq	0x100243c4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100243b4c:     	ldr	x8, [x19, #0x8]
100243b50:     	cmp	x8, x20
100243b54:     	b.ne	0x100243c4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100243b58:     	ldr	w8, [x19, #0x18]
100243b5c:     	cmp	w8, w22
100243b60:     	b.ne	0x100243c4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100243b64:     	mov	x8, #0x0                ; =0
100243b68:     	b	0x100243ca8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x360>
100243b6c:     	mov	x10, #0x0               ; =0
100243b70:     	b	0x100243c24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2dc>
100243b74:     	and	x9, x19, #0x4
100243b78:     	add	x8, x20, x9
100243b7c:     	adrp	x10, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x50f0>
100243b80:     	ldr	q0, [x10, #0x780]
100243b84:     	adrp	x10, 0x100c37000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x338fa>
100243b88:     	ldr	q2, [x10, #0x680]
100243b8c:     	movi.2d	v1, #0000000000000000
100243b90:     	movi.2d	v3, #0x000000000000ff
100243b94:     	mov	w10, #0x4               ; =4
100243b98:     	dup.2d	v4, x10
100243b9c:     	mov	x10, x20
100243ba0:     	and	x11, x19, #0x4
100243ba4:     	movi.2d	v5, #0000000000000000
100243ba8:     	ldr	s6, [x10], #0x4
100243bac:     	ushll.8h	v6, v6, #0x0
100243bb0:     	ushll.4s	v6, v6, #0x0
100243bb4:     	ushll2.2d	v7, v6, #0x0
100243bb8:     	and.16b	v7, v7, v3
100243bbc:     	ushll.2d	v6, v6, #0x0
100243bc0:     	and.16b	v6, v6, v3
100243bc4:     	shl.2d	v16, v0, #0x3
100243bc8:     	shl.2d	v17, v2, #0x3
100243bcc:     	ushl.2d	v6, v6, v17
100243bd0:     	ushl.2d	v7, v7, v16
100243bd4:     	orr.16b	v1, v7, v1
100243bd8:     	orr.16b	v5, v6, v5
100243bdc:     	add.2d	v0, v0, v4
100243be0:     	add.2d	v2, v2, v4
100243be4:     	subs	x11, x11, #0x4
100243be8:     	b.ne	0x100243ba8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x260>
100243bec:     	orr.16b	v0, v5, v1
100243bf0:     	mov	d1, v0[1]
100243bf4:     	orr.8b	v0, v0, v1
100243bf8:     	fmov	x10, d0
100243bfc:     	cmp	x19, x9
100243c00:     	b.eq	0x100243c24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2dc>
100243c04:     	add	x11, x20, x19
100243c08:     	lsl	x9, x9, #3
100243c0c:     	ldrb	w12, [x8], #0x1
100243c10:     	lsl	x12, x12, x9
100243c14:     	orr	x10, x12, x10
100243c18:     	add	x9, x9, #0x8
100243c1c:     	cmp	x8, x11
100243c20:     	b.ne	0x100243c0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2c4>
100243c24:     	orr	x8, x10, x19, lsl #40
100243c28:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100243c2c:     	orr	x0, x8, x9
100243c30:     	cmp	x22, #0x1
100243c34:     	b.lt	0x1002439b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100243c38:     	mov	x19, x0
100243c3c:     	mov	x0, x20
100243c40:     	bl	0x100b5cd00 <_mi_free>
100243c44:     	mov	x0, x19
100243c48:     	b	0x1002439b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100243c4c:     	stp	x20, x0, [x19, #0x8]
100243c50:     	stp	w22, w23, [x19, #0x18]
100243c54:     	str	w21, [x19, #0x20]
100243c58:     	strb	wzr, [x19, #0x24]
100243c5c:     	adrp	x21, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf85c>
100243c60:     	ldr	w8, [x21, #0x7a4]
100243c64:     	cbz	w8, 0x100243c80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x338>
100243c68:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100243c6c:     	bfxil	x8, x20, #0, #48
100243c70:     	mov	x20, x0
100243c74:     	mov	x0, x8
100243c78:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
100243c7c:     	mov	x0, x20
100243c80:     	ldr	w8, [x21, #0x7a4]
100243c84:     	cbz	w8, 0x100243ca0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x358>
100243c88:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100243c8c:     	bfxil	x8, x0, #0, #48
100243c90:     	mov	x20, x0
100243c94:     	mov	x0, x8
100243c98:     	bl	0x1004742b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
100243c9c:     	mov	x0, x20
100243ca0:     	ldr	x8, [x19]
100243ca4:     	add	x8, x8, #0x1
100243ca8:     	str	x8, [x19]
100243cac:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100243cb0:     	bfxil	x8, x0, #0, #48
100243cb4:     	mov	x0, x8
100243cb8:     	b	0x1002439b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100243cbc:     	mov	x24, x0
100243cc0:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100243cc4:     	mov	x8, x0
100243cc8:     	mov	x0, x24
100243ccc:     	add	x8, x8, x19, lsl #3
100243cd0:     	ldr	x19, [x8, #0x1e8]
100243cd4:     	cbnz	x19, 0x100243b30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1e8>
100243cd8:     	str	x0, [sp]
100243cdc:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
100243ce0:     	add	x0, x0, #0xfa0
100243ce4:     	bl	0x100b3a95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100243ce8:     	mov	x19, x0
100243cec:     	ldr	x0, [sp]
100243cf0:     	ldr	x8, [x19]
100243cf4:     	cbz	x8, 0x100243b38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1f0>
100243cf8:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100243cfc:     	add	x0, x0, #0xce0
100243d00:     	bl	0x100b1046c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
		...
