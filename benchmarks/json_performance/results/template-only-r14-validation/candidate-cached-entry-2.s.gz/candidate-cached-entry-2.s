
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-only-r14/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100842794 <_js_json_parse>:
100842794:     	stp	x29, x30, [sp, #-0x10]!
100842798:     	mov	x29, sp
10084279c:     	cbz	x0, 0x1008427f4 <_js_json_parse+0x60>
1008427a0:     	ldr	w1, [x0, #0x4]
1008427a4:     	cmp	w1, #0x2
1008427a8:     	b.eq	0x1008427b8 <_js_json_parse+0x24>
1008427ac:     	cbz	w1, 0x1008427f4 <_js_json_parse+0x60>
1008427b0:     	ldrb	w8, [x0, #0x14]
1008427b4:     	b	0x1008427d8 <_js_json_parse+0x44>
1008427b8:     	ldrb	w8, [x0, #0x14]
1008427bc:     	cmp	w8, #0x7b
1008427c0:     	b.ne	0x1008427d8 <_js_json_parse+0x44>
1008427c4:     	ldrb	w8, [x0, #0x15]
1008427c8:     	cmp	w8, #0x7d
1008427cc:     	b.ne	0x1008427e4 <_js_json_parse+0x50>
1008427d0:     	ldp	x29, x30, [sp], #0x10
1008427d4:     	b	0x1004ea480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
1008427d8:     	orr	w8, w8, #0x20
1008427dc:     	cmp	w8, #0x7b
1008427e0:     	b.ne	0x1008427ec <_js_json_parse+0x58>
1008427e4:     	ldp	x29, x30, [sp], #0x10
1008427e8:     	b	0x1005038b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
1008427ec:     	ldp	x29, x30, [sp], #0x10
1008427f0:     	b	0x1005060cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
1008427f4:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x705c>
1008427f8:     	add	x0, x0, #0x481
1008427fc:     	mov	w1, #0x1c               ; =28
100842800:     	bl	0x100506500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
