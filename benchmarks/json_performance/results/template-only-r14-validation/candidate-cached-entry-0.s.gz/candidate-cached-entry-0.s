
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-only-r14/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004eabac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template>:
1004eabac:     	sub	sp, sp, #0xe0
1004eabb0:     	stp	x28, x27, [sp, #0x80]
1004eabb4:     	stp	x26, x25, [sp, #0x90]
1004eabb8:     	stp	x24, x23, [sp, #0xa0]
1004eabbc:     	stp	x22, x21, [sp, #0xb0]
1004eabc0:     	stp	x20, x19, [sp, #0xc0]
1004eabc4:     	stp	x29, x30, [sp, #0xd0]
1004eabc8:     	add	x29, sp, #0xd0
1004eabcc:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eabd0:     	ldr	w19, [x8, #0x948]
1004eabd4:     	adrp	x21, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eabd8:     	cmp	w19, #0x300
1004eabdc:     	b.hs	0x1004eafd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x428>
1004eabe0:     	ldr	x8, [x21, #0x48]
1004eabe4:     	cmn	x8, #0x1
1004eabe8:     	b.eq	0x1004eafc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x418>
1004eabec:     	mrs	x9, TPIDRRO_EL0
1004eabf0:     	and	x9, x9, #0xfffffffffffffff8
1004eabf4:     	ldr	x0, [x9, x8, lsl #3]
1004eabf8:     	cbz	x0, 0x1004eafc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x418>
1004eabfc:     	add	x8, x0, x19, lsl #3
1004eac00:     	ldr	x0, [x8, #0x1e8]
1004eac04:     	cbz	x0, 0x1004eafd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x428>
1004eac08:     	ldrb	w8, [x0]
1004eac0c:     	cbnz	w8, 0x1004eafe8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x43c>
1004eac10:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eac14:     	ldr	w19, [x8, #0x578]
1004eac18:     	cmp	w19, #0x300
1004eac1c:     	b.hs	0x1004eb010 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x464>
1004eac20:     	ldr	x8, [x21, #0x48]
1004eac24:     	cmn	x8, #0x1
1004eac28:     	b.eq	0x1004eb000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x454>
1004eac2c:     	mrs	x9, TPIDRRO_EL0
1004eac30:     	and	x9, x9, #0xfffffffffffffff8
1004eac34:     	ldr	x0, [x9, x8, lsl #3]
1004eac38:     	cbz	x0, 0x1004eb000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x454>
1004eac3c:     	add	x8, x0, x19, lsl #3
1004eac40:     	ldr	x20, [x8, #0x1e8]
1004eac44:     	cbz	x20, 0x1004eb010 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x464>
1004eac48:     	bl	0x10027f544 <__RNvMs7_NtNtCs3gRpqoBkMHm_13perry_runtime2gc6policyNtB5_15GcSuppressScope3new>
1004eac4c:     	ldr	x8, [x20]
1004eac50:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1004eac54:     	cmp	x8, x9
1004eac58:     	b.hs	0x1004eb034 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x488>
1004eac5c:     	mov	x22, x0
1004eac60:     	add	x9, x8, #0x1
1004eac64:     	str	x9, [x20]
1004eac68:     	mov	x19, x20
1004eac6c:     	ldrb	w9, [x19, #0x8]!
1004eac70:     	cmp	w9, #0x2
1004eac74:     	b.ne	0x1004eac88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0xdc>
1004eac78:     	str	x8, [x20]
1004eac7c:     	tbz	w22, #0x0, 0x1004eae7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x2d0>
1004eac80:     	mov	x0, #0x0                ; =0
1004eac84:     	b	0x1004eb074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4c8>
1004eac88:     	add	x0, sp, #0x18
1004eac8c:     	bl	0x100235bf8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime5arena12constructionNtB2_17ConstructionBatch3new>
1004eac90:     	adrp	x1, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6fb0>
1004eac94:     	add	x1, x1, #0xb30
1004eac98:     	add	x0, sp, #0x30
1004eac9c:     	mov	w2, #0x40               ; =64
1004eaca0:     	bl	0x100b5fd10 <_writev+0x100b5fd10>
1004eaca4:     	ldrb	w1, [x20, #0x25e]
1004eaca8:     	cmp	w1, #0x9
1004eacac:     	b.hs	0x1004eb110 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x564>
1004eacb0:     	cbz	w1, 0x1004eaec8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x31c>
1004eacb4:     	str	w22, [sp, #0x4]
1004eacb8:     	mov	x25, #0x0               ; =0
1004eacbc:     	mov	w8, #0x48               ; =72
1004eacc0:     	umaddl	x26, w1, w8, x19
1004eacc4:     	mov	x27, #0x7ffd000000000000 ; =9222527611924643840
1004eacc8:     	ldr	x8, [sp, #0x18]
1004eaccc:     	stp	x20, x8, [sp, #0x8]
1004eacd0:     	mov	x28, #-0x3000000000000  ; =-844424930131968
1004eacd4:     	mov	x24, #0x7fff000000000000 ; =9223090561878065152
1004eacd8:     	mov	x20, #0x7ff9000000000000 ; =9221401712017801216
1004eacdc:     	add	x9, sp, #0x30
1004eace0:     	mov	x21, x19
1004eace4:     	b	0x1004ead00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x154>
1004eace8:     	ldr	x8, [x19, #0x8]
1004eacec:     	str	x8, [x9, x25, lsl #3]
1004eacf0:     	add	x25, x25, #0x1
1004eacf4:     	mov	x19, x21
1004eacf8:     	cmp	x21, x26
1004eacfc:     	b.eq	0x1004eae4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x2a0>
1004ead00:     	ldrb	w8, [x21], #0x48
1004ead04:     	tbz	w8, #0x0, 0x1004eace8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x13c>
1004ead08:     	ldrb	w23, [x19, #0x1]
1004ead0c:     	sub	x0, x29, #0x60
1004ead10:     	add	x1, sp, #0x18
1004ead14:     	mov	x2, x23
1004ead18:     	bl	0x100233650 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray3new>
1004ead1c:     	cmp	w23, #0x9
1004ead20:     	b.hs	0x1004eb0f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x54c>
1004ead24:     	ldur	x22, [x29, #-0x60]
1004ead28:     	cbz	w23, 0x1004eae20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x274>
1004ead2c:     	add	x19, x19, #0x8
1004ead30:     	lsl	x23, x23, #3
1004ead34:     	b	0x1004ead8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x1e0>
1004ead38:     	add	x9, x22, w8, uxtw #3
1004ead3c:     	str	x2, [x9, #0x8]
1004ead40:     	and	x9, x2, x28
1004ead44:     	cmp	x9, x27
1004ead48:     	cset	w9, eq
1004ead4c:     	ldurb	w10, [x29, #-0x57]
1004ead50:     	orr	w9, w10, w9
1004ead54:     	sturb	w9, [x29, #-0x57]
1004ead58:     	ldurb	w9, [x29, #-0x56]
1004ead5c:     	csel	w9, w9, wzr, eq
1004ead60:     	sturb	w9, [x29, #-0x56]
1004ead64:     	and	x9, x2, #0xffff000000000000
1004ead68:     	cmp	x9, x24
1004ead6c:     	ccmp	x2, x20, #0x0, ls
1004ead70:     	ldurb	w9, [x29, #-0x55]
1004ead74:     	csel	w9, w9, wzr, lo
1004ead78:     	sturb	w9, [x29, #-0x55]
1004ead7c:     	add	w8, w8, #0x1
1004ead80:     	str	w8, [x22]
1004ead84:     	subs	x23, x23, #0x8
1004ead88:     	b.eq	0x1004eae1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x270>
1004ead8c:     	ldr	x2, [x19], #0x8
1004ead90:     	ldp	w8, w9, [x22]
1004ead94:     	cmp	w8, w9
1004ead98:     	b.eq	0x1004eadf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x248>
1004ead9c:     	ldurb	w9, [x29, #-0x58]
1004eada0:     	tbnz	w9, #0x0, 0x1004ead38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x18c>
1004eada4:     	ldr	w9, [x22, #0x4]
1004eada8:     	cmp	w8, w9
1004eadac:     	b.hs	0x1004eadd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x228>
1004eadb0:     	mov	w1, w8
1004eadb4:     	mov	x0, x22
1004eadb8:     	bl	0x10052716c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array15header_gc_slots27note_array_slot_layout_only>
1004eadbc:     	ldr	w8, [x22]
1004eadc0:     	add	w8, w8, #0x1
1004eadc4:     	str	w8, [x22]
1004eadc8:     	subs	x23, x23, #0x8
1004eadcc:     	b.ne	0x1004ead8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x1e0>
1004eadd0:     	b	0x1004eae1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x270>
1004eadd4:     	fmov	d0, x2
1004eadd8:     	mov	x0, x22
1004eaddc:     	bl	0x1007c84e8 <_js_array_push_f64>
1004eade0:     	mov	x22, x0
1004eade4:     	stur	x0, [x29, #-0x60]
1004eade8:     	subs	x23, x23, #0x8
1004eadec:     	b.ne	0x1004ead8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x1e0>
1004eadf0:     	b	0x1004eae1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x270>
1004eadf4:     	sub	x0, x29, #0x60
1004eadf8:     	add	x1, sp, #0x18
1004eadfc:     	mov	x22, x2
1004eae00:     	bl	0x100b3890c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray4grow>
1004eae04:     	mov	x2, x22
1004eae08:     	ldur	x22, [x29, #-0x60]
1004eae0c:     	ldr	w8, [x22]
1004eae10:     	ldurb	w9, [x29, #-0x58]
1004eae14:     	tbnz	w9, #0x0, 0x1004ead38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x18c>
1004eae18:     	b	0x1004eada4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x1f8>
1004eae1c:     	ldur	x22, [x29, #-0x60]
1004eae20:     	sub	x0, x29, #0x60
1004eae24:     	ldr	x1, [sp, #0x10]
1004eae28:     	bl	0x10023348c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray13finish_layout>
1004eae2c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1004eae30:     	bfxil	x8, x22, #0, #48
1004eae34:     	add	x9, sp, #0x30
1004eae38:     	str	x8, [x9, x25, lsl #3]
1004eae3c:     	add	x25, x25, #0x1
1004eae40:     	mov	x19, x21
1004eae44:     	cmp	x21, x26
1004eae48:     	b.ne	0x1004ead00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x154>
1004eae4c:     	ldr	x20, [sp, #0x8]
1004eae50:     	ldrb	w4, [x20, #0x25e]
1004eae54:     	cmp	x4, #0x9
1004eae58:     	adrp	x21, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eae5c:     	ldr	w22, [sp, #0x4]
1004eae60:     	b.lo	0x1004eaecc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x320>
1004eae64:     	adrp	x3, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eae68:     	add	x3, x3, #0xd40
1004eae6c:     	mov	x0, #0x0                ; =0
1004eae70:     	mov	x1, x4
1004eae74:     	mov	w2, #0x8                ; =8
1004eae78:     	bl	0x100b108cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1004eae7c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eae80:     	ldr	w19, [x8, #0x308]
1004eae84:     	cmp	w19, #0x300
1004eae88:     	b.hs	0x1004eb0a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4fc>
1004eae8c:     	ldr	x8, [x21, #0x48]
1004eae90:     	cmn	x8, #0x1
1004eae94:     	b.eq	0x1004eb098 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4ec>
1004eae98:     	mrs	x9, TPIDRRO_EL0
1004eae9c:     	and	x9, x9, #0xfffffffffffffff8
1004eaea0:     	ldr	x0, [x9, x8, lsl #3]
1004eaea4:     	cbz	x0, 0x1004eb098 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4ec>
1004eaea8:     	add	x8, x0, x19, lsl #3
1004eaeac:     	ldr	x8, [x8, #0x1e8]
1004eaeb0:     	cbz	x8, 0x1004eb0a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4fc>
1004eaeb4:     	mov	x0, #0x0                ; =0
1004eaeb8:     	ldrb	w9, [x8]
1004eaebc:     	and	w9, w9, #0xfffffffd
1004eaec0:     	strb	w9, [x8]
1004eaec4:     	b	0x1004eb074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4c8>
1004eaec8:     	mov	x4, #0x0                ; =0
1004eaecc:     	ldr	w2, [x20, #0x258]
1004eaed0:     	ldr	x1, [x20, #0x250]
1004eaed4:     	add	x0, sp, #0x18
1004eaed8:     	add	x3, sp, #0x30
1004eaedc:     	bl	0x1005ba488 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
1004eaee0:     	ldr	x8, [x20]
1004eaee4:     	sub	x8, x8, #0x1
1004eaee8:     	str	x8, [x20]
1004eaeec:     	tbz	w22, #0x0, 0x1004eaf50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x3a4>
1004eaef0:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1004eaef4:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1004eaef8:     	ldr	x8, [x8, #0x758]
1004eaefc:     	cbnz	x8, 0x1004eafa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x3f8>
1004eaf00:     	bfxil	x19, x0, #0, #48
1004eaf04:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eaf08:     	ldr	w20, [x8, #0x930]
1004eaf0c:     	cmp	w20, #0x300
1004eaf10:     	b.hs	0x1004eb050 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4a4>
1004eaf14:     	ldr	x8, [x21, #0x48]
1004eaf18:     	cmn	x8, #0x1
1004eaf1c:     	b.eq	0x1004eb040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x494>
1004eaf20:     	mrs	x9, TPIDRRO_EL0
1004eaf24:     	and	x9, x9, #0xfffffffffffffff8
1004eaf28:     	ldr	x0, [x9, x8, lsl #3]
1004eaf2c:     	cbz	x0, 0x1004eb040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x494>
1004eaf30:     	add	x8, x0, x20, lsl #3
1004eaf34:     	ldr	x0, [x8, #0x1e8]
1004eaf38:     	cbz	x0, 0x1004eb050 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4a4>
1004eaf3c:     	ldrb	w8, [x0]
1004eaf40:     	cbz	w8, 0x1004eb064 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4b8>
1004eaf44:     	sub	w8, w8, #0x1
1004eaf48:     	strb	w8, [x0]
1004eaf4c:     	b	0x1004eb070 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4c4>
1004eaf50:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eaf54:     	ldr	w19, [x8, #0x308]
1004eaf58:     	cmp	w19, #0x300
1004eaf5c:     	b.hs	0x1004eb0d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x52c>
1004eaf60:     	ldr	x8, [x21, #0x48]
1004eaf64:     	cmn	x8, #0x1
1004eaf68:     	b.eq	0x1004eb0bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x510>
1004eaf6c:     	mrs	x9, TPIDRRO_EL0
1004eaf70:     	and	x9, x9, #0xfffffffffffffff8
1004eaf74:     	ldr	x8, [x9, x8, lsl #3]
1004eaf78:     	cbz	x8, 0x1004eb0bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x510>
1004eaf7c:     	add	x8, x8, x19, lsl #3
1004eaf80:     	ldr	x8, [x8, #0x1e8]
1004eaf84:     	cbz	x8, 0x1004eb0d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x52c>
1004eaf88:     	ldrb	w9, [x8]
1004eaf8c:     	and	w9, w9, #0xfffffffd
1004eaf90:     	strb	w9, [x8]
1004eaf94:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1004eaf98:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1004eaf9c:     	ldr	x8, [x8, #0x758]
1004eafa0:     	cbz	x8, 0x1004eaf00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x354>
1004eafa4:     	mov	x20, x0
1004eafa8:     	bl	0x100b43938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
1004eafac:     	bfxil	x19, x20, #0, #48
1004eafb0:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1004eafb4:     	ldr	w20, [x8, #0x930]
1004eafb8:     	cmp	w20, #0x300
1004eafbc:     	b.lo	0x1004eaf14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x368>
1004eafc0:     	b	0x1004eb050 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4a4>
1004eafc4:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eafc8:     	add	x8, x0, x19, lsl #3
1004eafcc:     	ldr	x0, [x8, #0x1e8]
1004eafd0:     	cbnz	x0, 0x1004eac08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x5c>
1004eafd4:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1004eafd8:     	add	x0, x0, #0xcf0
1004eafdc:     	bl	0x100b3aae8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eafe0:     	ldrb	w8, [x0]
1004eafe4:     	cbz	w8, 0x1004eac10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x64>
1004eafe8:     	bl	0x100b4221c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
1004eafec:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1004eaff0:     	ldr	w19, [x8, #0x578]
1004eaff4:     	cmp	w19, #0x300
1004eaff8:     	b.lo	0x1004eac20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x74>
1004eaffc:     	b	0x1004eb010 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x464>
1004eb000:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb004:     	add	x8, x0, x19, lsl #3
1004eb008:     	ldr	x20, [x8, #0x1e8]
1004eb00c:     	cbnz	x20, 0x1004eac48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x9c>
1004eb010:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
1004eb014:     	add	x0, x0, #0x0
1004eb018:     	bl	0x100b3aa9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004eb01c:     	mov	x20, x0
1004eb020:     	bl	0x10027f544 <__RNvMs7_NtNtCs3gRpqoBkMHm_13perry_runtime2gc6policyNtB5_15GcSuppressScope3new>
1004eb024:     	ldr	x8, [x20]
1004eb028:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1004eb02c:     	cmp	x8, x9
1004eb030:     	b.lo	0x1004eac5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0xb0>
1004eb034:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb038:     	add	x0, x0, #0xd28
1004eb03c:     	bl	0x100b105dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1004eb040:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb044:     	add	x8, x0, x20, lsl #3
1004eb048:     	ldr	x0, [x8, #0x1e8]
1004eb04c:     	cbnz	x0, 0x1004eaf3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x390>
1004eb050:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1004eb054:     	add	x0, x0, #0xcc0
1004eb058:     	bl	0x100b3aae8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb05c:     	ldrb	w8, [x0]
1004eb060:     	cbnz	w8, 0x1004eaf44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x398>
1004eb064:     	mov	w8, #0x3f               ; =63
1004eb068:     	strb	w8, [x0]
1004eb06c:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
1004eb070:     	mov	w0, #0x1                ; =1
1004eb074:     	mov	x1, x19
1004eb078:     	ldp	x29, x30, [sp, #0xd0]
1004eb07c:     	ldp	x20, x19, [sp, #0xc0]
1004eb080:     	ldp	x22, x21, [sp, #0xb0]
1004eb084:     	ldp	x24, x23, [sp, #0xa0]
1004eb088:     	ldp	x26, x25, [sp, #0x90]
1004eb08c:     	ldp	x28, x27, [sp, #0x80]
1004eb090:     	add	sp, sp, #0xe0
1004eb094:     	ret
1004eb098:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb09c:     	add	x8, x0, x19, lsl #3
1004eb0a0:     	ldr	x8, [x8, #0x1e8]
1004eb0a4:     	cbnz	x8, 0x1004eaeb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x308>
1004eb0a8:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1004eb0ac:     	add	x0, x0, #0xd20
1004eb0b0:     	bl	0x100b3aae8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb0b4:     	mov	x8, x0
1004eb0b8:     	b	0x1004eaeb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x308>
1004eb0bc:     	mov	x20, x0
1004eb0c0:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004eb0c4:     	mov	x8, x0
1004eb0c8:     	mov	x0, x20
1004eb0cc:     	add	x8, x8, x19, lsl #3
1004eb0d0:     	ldr	x8, [x8, #0x1e8]
1004eb0d4:     	cbnz	x8, 0x1004eaf88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x3dc>
1004eb0d8:     	adrp	x8, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1004eb0dc:     	add	x8, x8, #0xd20
1004eb0e0:     	mov	x19, x0
1004eb0e4:     	mov	x0, x8
1004eb0e8:     	bl	0x100b3aae8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004eb0ec:     	mov	x8, x0
1004eb0f0:     	mov	x0, x19
1004eb0f4:     	b	0x1004eaf88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x3dc>
1004eb0f8:     	adrp	x3, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb0fc:     	add	x3, x3, #0xd58
1004eb100:     	mov	x0, #0x0                ; =0
1004eb104:     	mov	x1, x23
1004eb108:     	mov	w2, #0x8                ; =8
1004eb10c:     	bl	0x100b108cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1004eb110:     	adrp	x3, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004eb114:     	add	x3, x3, #0xd70
1004eb118:     	mov	x0, #0x0                ; =0
1004eb11c:     	mov	w2, #0x8                ; =8
1004eb120:     	bl	0x100b108cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1004eb124:     	nop
1004eb128:     	nop
1004eb12c:     	nop
1004eb130:     	nop
1004eb134:     	nop
1004eb138:     	nop
1004eb13c:     	nop
