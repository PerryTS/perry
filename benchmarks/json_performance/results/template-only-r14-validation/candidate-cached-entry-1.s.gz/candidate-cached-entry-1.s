
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-only-r14/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005038b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>:
1005038b8:     	stp	x28, x27, [sp, #-0x60]!
1005038bc:     	stp	x26, x25, [sp, #0x10]
1005038c0:     	stp	x24, x23, [sp, #0x20]
1005038c4:     	stp	x22, x21, [sp, #0x30]
1005038c8:     	stp	x20, x19, [sp, #0x40]
1005038cc:     	stp	x29, x30, [sp, #0x50]
1005038d0:     	add	x29, sp, #0x50
1005038d4:     	sub	sp, sp, #0x1a0
1005038d8:     	mov	x19, x1
1005038dc:     	mov	x21, x0
1005038e0:     	add	x24, x0, #0x14
1005038e4:     	sub	x8, x1, #0x801
1005038e8:     	adrp	x27, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1005038ec:     	cmn	x8, #0x7c0
1005038f0:     	b.hs	0x100503910 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x58>
1005038f4:     	cmp	x19, #0x2
1005038f8:     	b.ne	0x100503988 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd0>
1005038fc:     	ldrh	w8, [x24]
100503900:     	mov	w9, #0x7d7b             ; =32123
100503904:     	cmp	w8, w9
100503908:     	b.eq	0x1005039bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
10050390c:     	b	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503910:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100503914:     	ldr	w20, [x8, #0x578]
100503918:     	cmp	w20, #0x300
10050391c:     	b.hs	0x100503aa8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1f0>
100503920:     	ldr	x8, [x27, #0x48]
100503924:     	cmn	x8, #0x1
100503928:     	b.eq	0x100503a98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1e0>
10050392c:     	mrs	x9, TPIDRRO_EL0
100503930:     	and	x9, x9, #0xfffffffffffffff8
100503934:     	ldr	x0, [x9, x8, lsl #3]
100503938:     	cbz	x0, 0x100503a98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1e0>
10050393c:     	add	x8, x0, x20, lsl #3
100503940:     	ldr	x0, [x8, #0x1e8]
100503944:     	cbz	x0, 0x100503aa8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1f0>
100503948:     	ldr	x8, [x0]
10050394c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100503950:     	cmp	x8, x9
100503954:     	b.hs	0x100503ac4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x20c>
100503958:     	ldrb	w8, [x0, #0x8]
10050395c:     	cmp	w8, #0x2
100503960:     	b.eq	0x100503990 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd8>
100503964:     	ldr	x8, [x0, #0x248]
100503968:     	cmp	x8, x21
10050396c:     	b.ne	0x100503990 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd8>
100503970:     	ldrh	w8, [x0, #0x25c]
100503974:     	cmp	x19, x8
100503978:     	b.ne	0x100503990 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd8>
10050397c:     	bl	0x1004eabac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template>
100503980:     	tbz	w0, #0x0, 0x100503990 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd8>
100503984:     	b	0x100503cb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3f8>
100503988:     	cmp	x19, #0x3
10050398c:     	b.lo	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503990:     	ldrb	w20, [x24]
100503994:     	cmp	w20, #0x20
100503998:     	b.hi	0x1005039dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x124>
10050399c:     	mov	x8, #0x2600             ; =9728
1005039a0:     	movk	x8, #0x1, lsl #32
1005039a4:     	lsr	x8, x8, x20
1005039a8:     	tbz	w8, #0x0, 0x1005039dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x124>
1005039ac:     	add	x0, x21, #0x14
1005039b0:     	mov	x1, x19
1005039b4:     	bl	0x1004ea3a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty19padded_empty_object>
1005039b8:     	tbz	w0, #0x0, 0x100503a08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x150>
1005039bc:     	add	sp, sp, #0x1a0
1005039c0:     	ldp	x29, x30, [sp, #0x50]
1005039c4:     	ldp	x20, x19, [sp, #0x40]
1005039c8:     	ldp	x22, x21, [sp, #0x30]
1005039cc:     	ldp	x24, x23, [sp, #0x20]
1005039d0:     	ldp	x26, x25, [sp, #0x10]
1005039d4:     	ldp	x28, x27, [sp], #0x60
1005039d8:     	b	0x1004ea480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
1005039dc:     	cmp	w20, #0x7b
1005039e0:     	b.ne	0x100503a08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x150>
1005039e4:     	ldrb	w8, [x21, #0x15]
1005039e8:     	cmp	w8, #0x20
1005039ec:     	b.hi	0x100503a00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x148>
1005039f0:     	mov	x9, #0x2600             ; =9728
1005039f4:     	movk	x9, #0x1, lsl #32
1005039f8:     	lsr	x9, x9, x8
1005039fc:     	tbnz	w9, #0x0, 0x1005039ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf4>
100503a00:     	cmp	w8, #0x7d
100503a04:     	b.eq	0x1005039ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf4>
100503a08:     	cmp	x19, #0x41
100503a0c:     	b.hs	0x100503cb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x400>
100503a10:     	cmp	w20, #0x7b
100503a14:     	ccmp	x19, #0x7, #0x0, eq
100503a18:     	b.lo	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503a1c:     	add	x8, x24, x19
100503a20:     	ldurb	w8, [x8, #-0x1]
100503a24:     	cmp	w8, #0x7d
100503a28:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503a2c:     	ldrb	w8, [x21, #0x15]
100503a30:     	cmp	w8, #0x22
100503a34:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503a38:     	sub	x9, x19, #0x1
100503a3c:     	mov	x22, x21
100503a40:     	ldrb	w25, [x22, #0x16]!
100503a44:     	cmp	w25, #0x22
100503a48:     	b.ne	0x100503ad0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x218>
100503a4c:     	mov	w20, #0x0               ; =0
100503a50:     	mov	w23, #0x0               ; =0
100503a54:     	mov	w28, #0x0               ; =0
100503a58:     	str	wzr, [sp, #0x8]
100503a5c:     	mov	x26, #0x0               ; =0
100503a60:     	cmp	w25, #0x22
100503a64:     	b.ne	0x100503afc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x244>
100503a68:     	add	x8, sp, #0xa0
100503a6c:     	mov	x0, x22
100503a70:     	mov	x1, x26
100503a74:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100503a78:     	sub	x12, x19, #0x1
100503a7c:     	ldr	w8, [sp, #0xa0]
100503a80:     	tbnz	w8, #0x0, 0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503a84:     	mov	x11, x26
100503a88:     	cmp	w25, #0x22
100503a8c:     	b.ne	0x100503ba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x2ec>
100503a90:     	mov	x8, #0x0                ; =0
100503a94:     	b	0x100503bdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x324>
100503a98:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100503a9c:     	add	x8, x0, x20, lsl #3
100503aa0:     	ldr	x0, [x8, #0x1e8]
100503aa4:     	cbnz	x0, 0x100503948 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x90>
100503aa8:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
100503aac:     	add	x0, x0, #0x0
100503ab0:     	bl	0x100b3aa9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100503ab4:     	ldr	x8, [x0]
100503ab8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100503abc:     	cmp	x8, x9
100503ac0:     	b.lo	0x100503958 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa0>
100503ac4:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100503ac8:     	add	x0, x0, #0xda0
100503acc:     	bl	0x100b105dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100503ad0:     	cmp	x9, #0x3
100503ad4:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503ad8:     	ldrb	w8, [x21, #0x17]
100503adc:     	cmp	w8, #0x22
100503ae0:     	b.ne	0x100503b78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x2c0>
100503ae4:     	mov	w23, #0x0               ; =0
100503ae8:     	mov	w28, #0x0               ; =0
100503aec:     	str	wzr, [sp, #0x8]
100503af0:     	mov	w20, #0x1               ; =1
100503af4:     	mov	w26, #0x1               ; =1
100503af8:     	b	0x100503a60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1a8>
100503afc:     	ldrb	w8, [x22]
100503b00:     	cmp	w8, #0x20
100503b04:     	b.lo	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503b08:     	cmp	w8, #0x5c
100503b0c:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503b10:     	tbnz	w20, #0x0, 0x100503a68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b0>
100503b14:     	ldrb	w8, [x21, #0x17]
100503b18:     	cmp	w8, #0x20
100503b1c:     	b.lo	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503b20:     	cmp	w8, #0x5c
100503b24:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503b28:     	tbnz	w23, #0x0, 0x100503a68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b0>
100503b2c:     	ldrb	w8, [x21, #0x18]
100503b30:     	cmp	w8, #0x20
100503b34:     	b.lo	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503b38:     	cmp	w8, #0x5c
100503b3c:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503b40:     	tbnz	w28, #0x0, 0x100503a68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b0>
100503b44:     	ldrb	w8, [x21, #0x19]
100503b48:     	cmp	w8, #0x20
100503b4c:     	b.lo	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503b50:     	cmp	w8, #0x5c
100503b54:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503b58:     	ldr	w8, [sp, #0x8]
100503b5c:     	tbnz	w8, #0x0, 0x100503a68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b0>
100503b60:     	ldrb	w8, [x21, #0x1a]
100503b64:     	cmp	w8, #0x20
100503b68:     	b.lo	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503b6c:     	cmp	w8, #0x5c
100503b70:     	b.ne	0x100503a68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b0>
100503b74:     	b	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503b78:     	cmp	x9, #0x4
100503b7c:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503b80:     	ldrb	w8, [x21, #0x18]
100503b84:     	cmp	w8, #0x22
100503b88:     	b.ne	0x100503c48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x390>
100503b8c:     	mov	w20, #0x0               ; =0
100503b90:     	mov	w28, #0x0               ; =0
100503b94:     	str	wzr, [sp, #0x8]
100503b98:     	mov	w23, #0x1               ; =1
100503b9c:     	mov	w26, #0x2               ; =2
100503ba0:     	b	0x100503a60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1a8>
100503ba4:     	ldrb	w8, [x22]
100503ba8:     	tbnz	w20, #0x0, 0x100503bdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x324>
100503bac:     	ldrb	w9, [x21, #0x17]
100503bb0:     	orr	x8, x8, x9, lsl #8
100503bb4:     	tbnz	w23, #0x0, 0x100503bdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x324>
100503bb8:     	ldrb	w9, [x21, #0x18]
100503bbc:     	orr	x8, x8, x9, lsl #16
100503bc0:     	tbnz	w28, #0x0, 0x100503bdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x324>
100503bc4:     	ldrb	w9, [x21, #0x19]
100503bc8:     	orr	x8, x8, x9, lsl #24
100503bcc:     	ldr	w9, [sp, #0x8]
100503bd0:     	tbnz	w9, #0x0, 0x100503bdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x324>
100503bd4:     	ldrb	w9, [x21, #0x1a]
100503bd8:     	orr	x8, x8, x9, lsl #32
100503bdc:     	add	x9, x11, #0x3
100503be0:     	cmp	x9, x19
100503be4:     	b.hs	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503be8:     	ldrb	w9, [x24, x9]
100503bec:     	cmp	w9, #0x3a
100503bf0:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503bf4:     	add	x10, x11, #0x4
100503bf8:     	subs	x9, x12, x10
100503bfc:     	b.lo	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503c00:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503c04:     	orr	x25, x8, x11, lsl #40
100503c08:     	mov	x28, #0x7ff9000000000000 ; =9221401712017801216
100503c0c:     	add	x8, x24, x10
100503c10:     	mov	x10, #0x2600            ; =9728
100503c14:     	movk	x10, #0x1, lsl #32
100503c18:     	mov	x11, x9
100503c1c:     	mov	x12, x8
100503c20:     	b	0x100503c30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x378>
100503c24:     	add	x12, x12, #0x1
100503c28:     	subs	x11, x11, #0x1
100503c2c:     	b.eq	0x100504b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12d0>
100503c30:     	ldrb	w13, [x12]
100503c34:     	cmp	w13, #0x20
100503c38:     	b.hi	0x100503c24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x36c>
100503c3c:     	lsr	x13, x10, x13
100503c40:     	tbz	w13, #0x0, 0x100503c24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x36c>
100503c44:     	b	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100503c48:     	cmp	x9, #0x5
100503c4c:     	b.ne	0x100503cf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x440>
100503c50:     	add	x0, sp, #0xa0
100503c54:     	add	x1, x21, #0x14
100503c58:     	mov	x2, x19
100503c5c:     	bl	0x1004f3b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object6decode>
100503c60:     	ldr	w8, [sp, #0xa0]
100503c64:     	tbz	w8, #0x0, 0x100503cb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x400>
100503c68:     	add	x8, sp, #0xa0
100503c6c:     	ldr	x9, [sp, #0x128]
100503c70:     	str	x9, [sp, #0x90]
100503c74:     	ldur	q0, [x8, #0x48]
100503c78:     	ldur	q1, [x8, #0x58]
100503c7c:     	stp	q0, q1, [sp, #0x50]
100503c80:     	ldur	q0, [x8, #0x68]
100503c84:     	ldur	q1, [x8, #0x78]
100503c88:     	stp	q0, q1, [sp, #0x70]
100503c8c:     	ldur	q0, [x8, #0x8]
100503c90:     	ldur	q1, [x8, #0x18]
100503c94:     	stp	q0, q1, [sp, #0x10]
100503c98:     	ldur	q0, [x8, #0x28]
100503c9c:     	ldur	q1, [x8, #0x38]
100503ca0:     	stp	q0, q1, [sp, #0x30]
100503ca4:     	add	x0, sp, #0x10
100503ca8:     	bl	0x1004f4348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object8allocate>
100503cac:     	tbz	w0, #0x0, 0x100503cb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x400>
100503cb0:     	mov	x23, x1
100503cb4:     	b	0x10050483c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf84>
100503cb8:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100503cbc:     	add	x8, x8, #0x2d8
100503cc0:     	ldapr	x8, [x8]
100503cc4:     	cbnz	x8, 0x100503d1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x464>
100503cc8:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100503ccc:     	ldrb	w8, [x8, #0x2e0]
100503cd0:     	adrp	x12, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100503cd4:     	cbz	w8, 0x100503d30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x478>
100503cd8:     	cmp	w8, #0x1
100503cdc:     	b.ne	0x100503d6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4b4>
100503ce0:     	mov	w28, #0x1               ; =1
100503ce4:     	mov	w8, #0x1000000          ; =16777216
100503ce8:     	mov	w22, #0x1               ; =1
100503cec:     	cmp	x19, x8
100503cf0:     	b.hi	0x100503d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4b8>
100503cf4:     	b	0x100503e54 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x59c>
100503cf8:     	ldrb	w8, [x21, #0x19]
100503cfc:     	cmp	w8, #0x22
100503d00:     	b.ne	0x100504a40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1188>
100503d04:     	mov	w20, #0x0               ; =0
100503d08:     	mov	w23, #0x0               ; =0
100503d0c:     	str	wzr, [sp, #0x8]
100503d10:     	mov	w28, #0x1               ; =1
100503d14:     	mov	w26, #0x3               ; =3
100503d18:     	b	0x100503a60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1a8>
100503d1c:     	bl	0x100b16c84 <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockNtNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api8TapeModeE10initializeNCINvB2_11get_or_initNCNvBV_18tape_mode_from_env0E0zEBZ_>
100503d20:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100503d24:     	ldrb	w8, [x8, #0x2e0]
100503d28:     	adrp	x12, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100503d2c:     	cbnz	w8, 0x100503cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100503d30:     	sub	x8, x19, #0x400
100503d34:     	mov	w9, #0xfffc00           ; =16776192
100503d38:     	cmp	x8, x9
100503d3c:     	b.hi	0x100503d6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4b4>
100503d40:     	mov	x8, #0x0                ; =0
100503d44:     	mov	x9, #0x2600             ; =9728
100503d48:     	movk	x9, #0x1, lsl #32
100503d4c:     	ldrb	w10, [x24, x8]
100503d50:     	cmp	w10, #0x20
100503d54:     	b.hi	0x1005048bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1004>
100503d58:     	lsr	x11, x9, x10
100503d5c:     	tbz	w11, #0x0, 0x1005048bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1004>
100503d60:     	add	x8, x8, #0x1
100503d64:     	cmp	x19, x8
100503d68:     	b.ne	0x100503d4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x494>
100503d6c:     	mov	w22, #0x0               ; =0
100503d70:     	ldr	w20, [x12, #0x560]
100503d74:     	cmp	w20, #0x300
100503d78:     	b.hs	0x100504894 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfdc>
100503d7c:     	ldr	x8, [x27, #0x48]
100503d80:     	cmn	x8, #0x1
100503d84:     	b.eq	0x100504884 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfcc>
100503d88:     	mrs	x9, TPIDRRO_EL0
100503d8c:     	and	x9, x9, #0xfffffffffffffff8
100503d90:     	ldr	x0, [x9, x8, lsl #3]
100503d94:     	cbz	x0, 0x100504884 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfcc>
100503d98:     	add	x8, x0, x20, lsl #3
100503d9c:     	ldr	x0, [x8, #0x1e8]
100503da0:     	cbz	x0, 0x100504894 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfdc>
100503da4:     	ldr	x8, [x0]
100503da8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100503dac:     	cmp	x8, x9
100503db0:     	b.hs	0x1005048b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff8>
100503db4:     	ldrb	w8, [x0, #0x24]
100503db8:     	cmp	w8, #0x2
100503dbc:     	b.eq	0x100503dcc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x514>
100503dc0:     	ldr	x9, [x0, #0x8]
100503dc4:     	cmp	x9, x21
100503dc8:     	b.eq	0x100503e34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x57c>
100503dcc:     	cmp	x19, #0x3e9
100503dd0:     	b.lo	0x100503e50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x598>
100503dd4:     	mov	x8, #0x0                ; =0
100503dd8:     	mov	x9, #0x2600             ; =9728
100503ddc:     	movk	x9, #0x1, lsl #32
100503de0:     	add	x10, x21, x8
100503de4:     	ldrb	w10, [x10, #0x14]
100503de8:     	cmp	w10, #0x20
100503dec:     	b.hi	0x100503e08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x550>
100503df0:     	lsr	x11, x9, x10
100503df4:     	tbz	w11, #0x0, 0x100503e08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x550>
100503df8:     	add	x8, x8, #0x1
100503dfc:     	cmp	x19, x8
100503e00:     	b.ne	0x100503de0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x528>
100503e04:     	b	0x100503e50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x598>
100503e08:     	cmp	w10, #0x5b
100503e0c:     	b.eq	0x100503e18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x560>
100503e10:     	cmp	w10, #0x7b
100503e14:     	b.ne	0x100503e50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x598>
100503e18:     	add	x0, x21, #0x14
100503e1c:     	mov	x1, x19
100503e20:     	mov	w2, #0x3e8              ; =1000
100503e24:     	bl	0x1006c2954 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
100503e28:     	cbz	w0, 0x100503e50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x598>
100503e2c:     	mov	x0, x21
100503e30:     	b	0x100504b18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1260>
100503e34:     	ldr	w9, [x0, #0x18]
100503e38:     	cmp	x19, x9
100503e3c:     	cset	w9, eq
100503e40:     	and	w8, w9, w8
100503e44:     	cmp	x19, #0x3e9
100503e48:     	csinc	w8, w8, wzr, hs
100503e4c:     	tbz	w8, #0x0, 0x100503dd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x51c>
100503e50:     	mov	w28, #0x0               ; =0
100503e54:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100503e58:     	add	x0, x0, #0xce8
100503e5c:     	ldr	x8, [x0]
100503e60:     	blr	x8
100503e64:     	mov	x20, x0
100503e68:     	ldrb	w8, [x0, #0x20]
100503e6c:     	cbnz	w8, 0x100504a70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11b8>
100503e70:     	ldr	x8, [x20]
100503e74:     	cbnz	x8, 0x100504aec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1234>
100503e78:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
100503e7c:     	bfxil	x23, x21, #0, #48
100503e80:     	mov	x8, #-0x1               ; =-1
100503e84:     	str	x8, [x20]
100503e88:     	ldr	x21, [x20, #0x18]
100503e8c:     	ldr	x8, [x20, #0x8]
100503e90:     	cmp	x21, x8
100503e94:     	b.eq	0x100504730 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe78>
100503e98:     	ldr	x8, [x20, #0x10]
100503e9c:     	str	x23, [x8, x21, lsl #3]
100503ea0:     	add	x8, x21, #0x1
100503ea4:     	str	x8, [x20, #0x18]
100503ea8:     	ldr	x8, [x20]
100503eac:     	add	x8, x8, #0x1
100503eb0:     	str	x8, [x20]
100503eb4:     	adrp	x24, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100503eb8:     	ldr	w23, [x24, #0x948]
100503ebc:     	cmp	w23, #0x300
100503ec0:     	b.hs	0x10050474c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe94>
100503ec4:     	ldr	x8, [x27, #0x48]
100503ec8:     	cmn	x8, #0x1
100503ecc:     	b.eq	0x10050473c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe84>
100503ed0:     	mrs	x9, TPIDRRO_EL0
100503ed4:     	and	x9, x9, #0xfffffffffffffff8
100503ed8:     	ldr	x0, [x9, x8, lsl #3]
100503edc:     	cbz	x0, 0x10050473c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe84>
100503ee0:     	add	x8, x0, x23, lsl #3
100503ee4:     	ldr	x0, [x8, #0x1e8]
100503ee8:     	cbz	x0, 0x10050474c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe94>
100503eec:     	ldrb	w8, [x0]
100503ef0:     	cbnz	w8, 0x100504760 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xea8>
100503ef4:     	tbz	w22, #0x0, 0x1005044c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
100503ef8:     	ldrb	w8, [x20, #0x20]
100503efc:     	cbnz	w8, 0x100504b28 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1270>
100503f00:     	ldr	x8, [x20]
100503f04:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100503f08:     	cmp	x8, x9
100503f0c:     	b.hs	0x100504c8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13d4>
100503f10:     	add	x9, x8, #0x1
100503f14:     	str	x9, [x20]
100503f18:     	ldr	x9, [x20, #0x18]
100503f1c:     	cmp	x21, x9
100503f20:     	b.hs	0x100503f34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x67c>
100503f24:     	ldr	x9, [x20, #0x10]
100503f28:     	ldr	x9, [x9, x21, lsl #3]
100503f2c:     	and	x23, x9, #0xffffffffffff
100503f30:     	b	0x100503f38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x680>
100503f34:     	mov	w23, #0x1               ; =1
100503f38:     	str	x8, [x20]
100503f3c:     	adrp	x0, 0x100f84000 <__RNvNCNKNvNtCs3gRpqoBkMHm_13perry_runtime7process29PROCESS_FINALIZATION_EXIT_RAN0s_023___RUST_STD_INTERNAL_VAL>
100503f40:     	add	x0, x0, #0x168
100503f44:     	ldr	x8, [x0]
100503f48:     	blr	x8
100503f4c:     	mov	x22, x0
100503f50:     	ldrb	w8, [x0, #0x30]
100503f54:     	cmp	w8, #0x1
100503f58:     	b.ne	0x100504af8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1240>
100503f5c:     	ldr	x8, [x22]
100503f60:     	mov	x10, #-0x1              ; =-1
100503f64:     	mov	x9, x22
100503f68:     	str	x10, [x9], #0x8
100503f6c:     	cmn	x8, #0x1
100503f70:     	b.eq	0x100503f90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6d8>
100503f74:     	add	x10, sp, #0xa0
100503f78:     	ldp	q0, q1, [x9]
100503f7c:     	ldr	x9, [x9, #0x20]
100503f80:     	stur	x9, [x10, #0x28]
100503f84:     	stur	q1, [x10, #0x18]
100503f88:     	stur	q0, [x10, #0x8]
100503f8c:     	b	0x100503fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6ec>
100503f90:     	mov	x8, #0x0                ; =0
100503f94:     	mov	w9, #0x4                ; =4
100503f98:     	stp	x9, xzr, [sp, #0xa8]
100503f9c:     	stp	xzr, x9, [sp, #0xb8]
100503fa0:     	str	xzr, [sp, #0xc8]
100503fa4:     	str	x8, [sp, #0xa0]
100503fa8:     	stur	xzr, [x29, #-0x78]
100503fac:     	add	x8, sp, #0xa0
100503fb0:     	add	x0, x23, #0x14
100503fb4:     	add	x2, sp, #0xa0
100503fb8:     	add	x3, x8, #0x18
100503fbc:     	sub	x4, x29, #0x78
100503fc0:     	mov	x1, x19
100503fc4:     	bl	0x10014e764 <__RINvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15build_tape_intoKb1_EB4_>
100503fc8:     	tbz	w0, #0x0, 0x1005040d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x820>
100503fcc:     	ldur	x23, [x29, #-0x78]
100503fd0:     	ldr	w24, [x24, #0x948]
100503fd4:     	cmp	w24, #0x300
100503fd8:     	b.hs	0x100504954 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x109c>
100503fdc:     	ldr	x8, [x27, #0x48]
100503fe0:     	cmn	x8, #0x1
100503fe4:     	b.eq	0x100504944 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x108c>
100503fe8:     	mrs	x9, TPIDRRO_EL0
100503fec:     	and	x9, x9, #0xfffffffffffffff8
100503ff0:     	ldr	x0, [x9, x8, lsl #3]
100503ff4:     	cbz	x0, 0x100504944 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x108c>
100503ff8:     	add	x8, x0, x24, lsl #3
100503ffc:     	ldr	x0, [x8, #0x1e8]
100504000:     	cbz	x0, 0x100504954 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x109c>
100504004:     	ldrb	w8, [x0]
100504008:     	cbnz	w8, 0x100504968 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10b0>
10050400c:     	bl	0x1004eda40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100504010:     	bl	0x100457940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
100504014:     	mov	x0, x19
100504018:     	bl	0x10022fa2c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
10050401c:     	mov	x24, x0
100504020:     	mov	x25, x1
100504024:     	bl	0x100457754 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
100504028:     	ldrb	w8, [x20, #0x20]
10050402c:     	cbnz	w8, 0x100504be8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1330>
100504030:     	ldr	x8, [x20]
100504034:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504038:     	cmp	x8, x9
10050403c:     	b.hs	0x100504c8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13d4>
100504040:     	add	x9, x8, #0x1
100504044:     	str	x9, [x20]
100504048:     	ldr	x9, [x20, #0x18]
10050404c:     	cmp	x21, x9
100504050:     	b.hs	0x100504170 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8b8>
100504054:     	ldr	x9, [x20, #0x10]
100504058:     	ldr	x9, [x9, x21, lsl #3]
10050405c:     	and	x2, x9, #0xffffffffffff
100504060:     	stp	x25, x24, [sp]
100504064:     	str	x8, [x20]
100504068:     	add	x26, x2, #0x14
10050406c:     	cmp	x23, #0x3e8
100504070:     	b.hi	0x100504188 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d0>
100504074:     	ldp	x24, x25, [sp, #0xa8]
100504078:     	cbz	x25, 0x1005041d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x918>
10050407c:     	ldrb	w8, [x24, #0x8]
100504080:     	cmp	w8, #0x3
100504084:     	b.ne	0x1005041d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x918>
100504088:     	ldr	w8, [x24, #0x4]
10050408c:     	cmp	w8, #0x2
100504090:     	b.lo	0x1005048e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x102c>
100504094:     	mov	w1, #0x0                ; =0
100504098:     	mov	w0, #0x1                ; =1
10050409c:     	mov	w9, #0xc                ; =12
1005040a0:     	b	0x1005040b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7fc>
1005040a4:     	add	x0, x0, #0x1
1005040a8:     	add	w1, w1, #0x1
1005040ac:     	cmp	x0, x8
1005040b0:     	b.hs	0x1005048e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1030>
1005040b4:     	cmp	x0, x25
1005040b8:     	b.hs	0x100504d8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14d4>
1005040bc:     	madd	x10, x0, x9, x24
1005040c0:     	ldrb	w11, [x10, #0x8]
1005040c4:     	orr	w11, w11, #0x2
1005040c8:     	cmp	w11, #0x3
1005040cc:     	b.ne	0x1005040a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7ec>
1005040d0:     	ldr	w0, [x10, #0x4]
1005040d4:     	b	0x1005040a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7ec>
1005040d8:     	str	xzr, [sp, #0xb0]
1005040dc:     	str	xzr, [sp, #0xc8]
1005040e0:     	ldr	x8, [sp, #0xa0]
1005040e4:     	add	x9, x8, x8, lsl #1
1005040e8:     	lsl	x9, x9, #2
1005040ec:     	cmp	x9, #0x100, lsl #12     ; =0x100000
1005040f0:     	b.ls	0x10050410c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x854>
1005040f4:     	cbz	x8, 0x100504100 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x848>
1005040f8:     	ldr	x0, [sp, #0xa8]
1005040fc:     	bl	0x100b5ce40 <_mi_free>
100504100:     	mov	w8, #0x4                ; =4
100504104:     	stp	xzr, x8, [sp, #0xa0]
100504108:     	str	xzr, [sp, #0xb0]
10050410c:     	ldr	x8, [sp, #0xb8]
100504110:     	lsl	x9, x8, #2
100504114:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100504118:     	b.ls	0x100504134 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x87c>
10050411c:     	cbz	x8, 0x100504128 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x870>
100504120:     	ldr	x0, [sp, #0xc0]
100504124:     	bl	0x100b5ce40 <_mi_free>
100504128:     	mov	w8, #0x4                ; =4
10050412c:     	stp	xzr, x8, [sp, #0xb8]
100504130:     	str	xzr, [sp, #0xc8]
100504134:     	ldp	x8, x0, [x22]
100504138:     	ldp	x24, x23, [x22, #0x18]
10050413c:     	ldp	q1, q0, [sp, #0xb0]
100504140:     	ldr	q2, [sp, #0xa0]
100504144:     	stp	q2, q1, [x22]
100504148:     	str	q0, [x22, #0x20]
10050414c:     	cmn	x8, #0x1
100504150:     	b.eq	0x100504168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8b0>
100504154:     	cbz	x8, 0x10050415c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8a4>
100504158:     	bl	0x100b5ce40 <_mi_free>
10050415c:     	cbz	x24, 0x100504168 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8b0>
100504160:     	mov	x0, x23
100504164:     	bl	0x100b5ce40 <_mi_free>
100504168:     	ldrb	w8, [x20, #0x20]
10050416c:     	b	0x1005043e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb30>
100504170:     	mov	w2, #0x1                ; =1
100504174:     	stp	x25, x24, [sp]
100504178:     	str	x8, [x20]
10050417c:     	add	x26, x2, #0x14
100504180:     	cmp	x23, #0x3e8
100504184:     	b.ls	0x100504074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7bc>
100504188:     	ldp	x0, x1, [sp, #0xa8]
10050418c:     	mov	x2, x26
100504190:     	mov	x3, x19
100504194:     	bl	0x100686414 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape9iterative21materialize_iterative>
100504198:     	tbz	w0, #0x0, 0x100504254 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x99c>
10050419c:     	mov	x25, x1
1005041a0:     	ldrb	w8, [x20, #0x20]
1005041a4:     	cbz	w8, 0x100504200 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x948>
1005041a8:     	cmp	w8, #0x2
1005041ac:     	b.eq	0x100504ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13e8>
1005041b0:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
1005041b4:     	add	x1, x1, #0x518
1005041b8:     	mov	x0, x20
1005041bc:     	bl	0x100a1e2dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1005041c0:     	strb	wzr, [x20, #0x20]
1005041c4:     	ldr	x8, [x20]
1005041c8:     	cbz	x8, 0x100504208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x950>
1005041cc:     	b	0x100504aec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1234>
1005041d0:     	bl	0x100288f98 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
1005041d4:     	stp	x0, xzr, [x29, #-0x70]
1005041d8:     	stp	x24, x25, [sp, #0x10]
1005041dc:     	stp	x26, x19, [sp, #0x20]
1005041e0:     	add	x0, sp, #0x10
1005041e4:     	sub	x1, x29, #0x68
1005041e8:     	bl	0x100375960 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24materialize_value_source>
1005041ec:     	mov	x25, x0
1005041f0:     	sub	x0, x29, #0x70
1005041f4:     	bl	0x1001649fc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1005041f8:     	ldrb	w8, [x20, #0x20]
1005041fc:     	cbnz	w8, 0x1005041a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8f0>
100504200:     	ldr	x8, [x20]
100504204:     	cbnz	x8, 0x100504aec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1234>
100504208:     	mov	x8, #-0x1               ; =-1
10050420c:     	str	x8, [x20]
100504210:     	ldr	x26, [x20, #0x18]
100504214:     	ldr	x8, [x20, #0x8]
100504218:     	cmp	x26, x8
10050421c:     	b.eq	0x1005049e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x112c>
100504220:     	ldr	x8, [x20, #0x10]
100504224:     	str	x25, [x8, x26, lsl #3]
100504228:     	add	x8, x26, #0x1
10050422c:     	str	x8, [x20, #0x18]
100504230:     	ldr	x8, [x20]
100504234:     	add	x8, x8, #0x1
100504238:     	str	x8, [x20]
10050423c:     	mov	w25, #0x1               ; =1
100504240:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100504244:     	ldr	w24, [x8, #0x308]
100504248:     	cmp	w24, #0x300
10050424c:     	b.lo	0x100504268 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9b0>
100504250:     	b	0x100504980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10c8>
100504254:     	mov	w25, #0x0               ; =0
100504258:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
10050425c:     	ldr	w24, [x8, #0x308]
100504260:     	cmp	w24, #0x300
100504264:     	b.hs	0x100504980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10c8>
100504268:     	ldr	x8, [x27, #0x48]
10050426c:     	cmn	x8, #0x1
100504270:     	b.eq	0x100504970 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10b8>
100504274:     	mrs	x9, TPIDRRO_EL0
100504278:     	and	x9, x9, #0xfffffffffffffff8
10050427c:     	ldr	x0, [x9, x8, lsl #3]
100504280:     	cbz	x0, 0x100504970 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10b8>
100504284:     	add	x8, x0, x24, lsl #3
100504288:     	ldr	x0, [x8, #0x1e8]
10050428c:     	cbz	x0, 0x100504980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10c8>
100504290:     	ldrb	w8, [x0]
100504294:     	and	w8, w8, #0xfffffffd
100504298:     	strb	w8, [x0]
10050429c:     	mov	w0, #0x0                ; =0
1005042a0:     	bl	0x10045b080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
1005042a4:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1005042a8:     	ldr	w24, [x8, #0x590]
1005042ac:     	cmp	w24, #0x300
1005042b0:     	b.hs	0x1005049a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10e8>
1005042b4:     	ldr	x8, [x27, #0x48]
1005042b8:     	cmn	x8, #0x1
1005042bc:     	b.eq	0x100504990 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10d8>
1005042c0:     	mrs	x9, TPIDRRO_EL0
1005042c4:     	and	x9, x9, #0xfffffffffffffff8
1005042c8:     	ldr	x0, [x9, x8, lsl #3]
1005042cc:     	cbz	x0, 0x100504990 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10d8>
1005042d0:     	add	x8, x0, x24, lsl #3
1005042d4:     	ldr	x0, [x8, #0x1e8]
1005042d8:     	cbz	x0, 0x1005049a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10e8>
1005042dc:     	ldr	x8, [x0]
1005042e0:     	lsr	x8, x8, #25
1005042e4:     	cbz	x8, 0x1005049b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1100>
1005042e8:     	bl	0x10045ce34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005042ec:     	cmp	x23, #0x3e8
1005042f0:     	b.hi	0x1005049c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1108>
1005042f4:     	ldp	x1, x0, [sp]
1005042f8:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005042fc:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100504300:     	ldr	x8, [x8, #0x758]
100504304:     	cbnz	x8, 0x1005049d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1120>
100504308:     	tbz	w25, #0x0, 0x100504350 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa98>
10050430c:     	ldrb	w8, [x20, #0x20]
100504310:     	cbnz	w8, 0x100504c60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13a8>
100504314:     	ldr	x8, [x20]
100504318:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10050431c:     	cmp	x8, x9
100504320:     	b.hs	0x100504c8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13d4>
100504324:     	add	x9, x8, #0x1
100504328:     	str	x9, [x20]
10050432c:     	ldr	x9, [x20, #0x18]
100504330:     	cmp	x26, x9
100504334:     	b.hs	0x100504344 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa8c>
100504338:     	ldr	x9, [x20, #0x10]
10050433c:     	ldr	x23, [x9, x26, lsl #3]
100504340:     	b	0x10050434c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa94>
100504344:     	mov	x23, #0x1               ; =1
100504348:     	movk	x23, #0x7ffc, lsl #48
10050434c:     	str	x8, [x20]
100504350:     	str	xzr, [sp, #0xb0]
100504354:     	str	xzr, [sp, #0xc8]
100504358:     	ldr	x8, [sp, #0xa0]
10050435c:     	add	x9, x8, x8, lsl #1
100504360:     	lsl	x9, x9, #2
100504364:     	cmp	x9, #0x100, lsl #12     ; =0x100000
100504368:     	b.ls	0x100504384 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xacc>
10050436c:     	cbz	x8, 0x100504378 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xac0>
100504370:     	ldr	x0, [sp, #0xa8]
100504374:     	bl	0x100b5ce40 <_mi_free>
100504378:     	mov	w8, #0x4                ; =4
10050437c:     	stp	xzr, x8, [sp, #0xa0]
100504380:     	str	xzr, [sp, #0xb0]
100504384:     	ldr	x8, [sp, #0xb8]
100504388:     	lsl	x9, x8, #2
10050438c:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100504390:     	b.ls	0x1005043ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xaf4>
100504394:     	cbz	x8, 0x1005043a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xae8>
100504398:     	ldr	x0, [sp, #0xc0]
10050439c:     	bl	0x100b5ce40 <_mi_free>
1005043a0:     	mov	w8, #0x4                ; =4
1005043a4:     	stp	xzr, x8, [sp, #0xb8]
1005043a8:     	str	xzr, [sp, #0xc8]
1005043ac:     	ldp	x8, x0, [x22]
1005043b0:     	ldp	x26, x24, [x22, #0x18]
1005043b4:     	ldp	q1, q0, [sp, #0xb0]
1005043b8:     	ldr	q2, [sp, #0xa0]
1005043bc:     	stp	q2, q1, [x22]
1005043c0:     	str	q0, [x22, #0x20]
1005043c4:     	cmn	x8, #0x1
1005043c8:     	b.eq	0x100504478 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbc0>
1005043cc:     	cbz	x8, 0x1005043d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb1c>
1005043d0:     	bl	0x100b5ce40 <_mi_free>
1005043d4:     	cbz	x26, 0x100504478 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbc0>
1005043d8:     	mov	x0, x24
1005043dc:     	bl	0x100b5ce40 <_mi_free>
1005043e0:     	ldrb	w8, [x20, #0x20]
1005043e4:     	tbnz	w25, #0x0, 0x100504480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbc8>
1005043e8:     	cbnz	w8, 0x100504b58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
1005043ec:     	ldr	x8, [x20]
1005043f0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005043f4:     	cmp	x8, x9
1005043f8:     	b.hs	0x100504c8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13d4>
1005043fc:     	add	x9, x8, #0x1
100504400:     	str	x9, [x20]
100504404:     	ldr	x9, [x20, #0x18]
100504408:     	cmp	x21, x9
10050440c:     	b.hs	0x100504430 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb78>
100504410:     	ldr	x9, [x20, #0x10]
100504414:     	ldr	x9, [x9, x21, lsl #3]
100504418:     	and	x22, x9, #0xffffffffffff
10050441c:     	str	x8, [x20]
100504420:     	cmp	x19, #0x3e8
100504424:     	csel	w8, wzr, w28, ls
100504428:     	cbnz	w8, 0x100504444 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb8c>
10050442c:     	b	0x1005044c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
100504430:     	mov	w22, #0x1               ; =1
100504434:     	str	x8, [x20]
100504438:     	cmp	x19, #0x3e8
10050443c:     	csel	w8, wzr, w28, ls
100504440:     	cbz	w8, 0x1005044c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
100504444:     	mov	x8, #0x0                ; =0
100504448:     	mov	x9, #0x2600             ; =9728
10050444c:     	movk	x9, #0x1, lsl #32
100504450:     	add	x10, x22, x8
100504454:     	ldrb	w10, [x10, #0x14]
100504458:     	cmp	w10, #0x20
10050445c:     	b.hi	0x1005044a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbe8>
100504460:     	lsr	x11, x9, x10
100504464:     	tbz	w11, #0x0, 0x1005044a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbe8>
100504468:     	add	x8, x8, #0x1
10050446c:     	cmp	x19, x8
100504470:     	b.ne	0x100504450 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb98>
100504474:     	b	0x1005044c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
100504478:     	ldrb	w8, [x20, #0x20]
10050447c:     	cbz	w25, 0x1005043e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb30>
100504480:     	cbnz	w8, 0x100504c98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13e0>
100504484:     	ldr	x8, [x20]
100504488:     	cbnz	x8, 0x100504cc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1410>
10050448c:     	ldr	x8, [x20, #0x18]
100504490:     	cmp	x21, x8
100504494:     	b.hi	0x10050483c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf84>
100504498:     	str	x21, [x20, #0x18]
10050449c:     	b	0x10050483c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf84>
1005044a0:     	cmp	w10, #0x5b
1005044a4:     	b.eq	0x1005044b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbf8>
1005044a8:     	cmp	w10, #0x7b
1005044ac:     	b.ne	0x1005044c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
1005044b0:     	add	x0, x22, #0x14
1005044b4:     	mov	x1, x19
1005044b8:     	mov	w2, #0x3e8              ; =1000
1005044bc:     	bl	0x1006c2954 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
1005044c0:     	cbnz	w0, 0x100504b0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1254>
1005044c4:     	bl	0x1004eda40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
1005044c8:     	bl	0x100457940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
1005044cc:     	mov	x0, x19
1005044d0:     	bl	0x10022fa2c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
1005044d4:     	mov	x24, x0
1005044d8:     	mov	x22, x1
1005044dc:     	bl	0x100457754 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
1005044e0:     	ldrb	w8, [x20, #0x20]
1005044e4:     	cbnz	w8, 0x100504a98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11e0>
1005044e8:     	ldr	x8, [x20]
1005044ec:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005044f0:     	cmp	x8, x9
1005044f4:     	b.hs	0x100504c8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13d4>
1005044f8:     	add	x9, x8, #0x1
1005044fc:     	str	x9, [x20]
100504500:     	ldr	x9, [x20, #0x18]
100504504:     	cmp	x21, x9
100504508:     	b.hs	0x100504520 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc68>
10050450c:     	ldr	x9, [x20, #0x10]
100504510:     	ldr	x9, [x9, x21, lsl #3]
100504514:     	and	x25, x9, #0xffffffffffff
100504518:     	add	x1, x25, #0x14
10050451c:     	b	0x100504528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc70>
100504520:     	mov	w25, #0x1               ; =1
100504524:     	mov	w1, #0x15               ; =21
100504528:     	str	x8, [x20]
10050452c:     	add	x0, sp, #0xa0
100504530:     	mov	x2, x19
100504534:     	mov	x3, x25
100504538:     	bl	0x10024530c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23new_batched_from_string>
10050453c:     	add	x0, sp, #0xa0
100504540:     	bl	0x100242448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
100504544:     	mov	x23, x0
100504548:     	ldp	x26, x28, [sp, #0x108]
10050454c:     	cmp	x28, x26
100504550:     	b.hs	0x100504584 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xccc>
100504554:     	ldr	x8, [sp, #0x100]
100504558:     	mov	x9, #0x2600             ; =9728
10050455c:     	movk	x9, #0x1, lsl #32
100504560:     	ldrb	w10, [x8, x28]
100504564:     	cmp	w10, #0x20
100504568:     	b.hi	0x100504584 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xccc>
10050456c:     	lsr	x10, x9, x10
100504570:     	tbz	w10, #0x0, 0x100504584 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xccc>
100504574:     	add	x28, x28, #0x1
100504578:     	cmp	x26, x28
10050457c:     	b.ne	0x100504560 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xca8>
100504580:     	mov	x28, x26
100504584:     	ldrb	w8, [sp, #0x176]
100504588:     	tbnz	w8, #0x0, 0x1005049f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1138>
10050458c:     	cmp	x28, x26
100504590:     	b.ne	0x1005049fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1144>
100504594:     	ldrb	w8, [sp, #0x174]
100504598:     	tbz	w8, #0x0, 0x1005049fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1144>
10050459c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1005045a0:     	ldr	w26, [x8, #0x560]
1005045a4:     	cmp	w26, #0x300
1005045a8:     	b.hs	0x10050477c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xec4>
1005045ac:     	ldr	x8, [x27, #0x48]
1005045b0:     	cmn	x8, #0x1
1005045b4:     	b.eq	0x10050476c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeb4>
1005045b8:     	mrs	x9, TPIDRRO_EL0
1005045bc:     	and	x9, x9, #0xfffffffffffffff8
1005045c0:     	ldr	x0, [x9, x8, lsl #3]
1005045c4:     	cbz	x0, 0x10050476c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeb4>
1005045c8:     	add	x8, x0, x26, lsl #3
1005045cc:     	ldr	x0, [x8, #0x1e8]
1005045d0:     	cbz	x0, 0x10050477c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xec4>
1005045d4:     	ldr	x8, [x0]
1005045d8:     	cbnz	x8, 0x100504790 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xed8>
1005045dc:     	ldrb	w8, [x0, #0x24]
1005045e0:     	cmp	w8, #0x2
1005045e4:     	b.eq	0x100504608 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd50>
1005045e8:     	ldr	x8, [x0, #0x8]
1005045ec:     	cmp	x8, x25
1005045f0:     	b.ne	0x100504608 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd50>
1005045f4:     	ldr	w8, [x0, #0x18]
1005045f8:     	cmp	x19, x8
1005045fc:     	b.ne	0x100504608 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd50>
100504600:     	mov	w8, #0x1                ; =1
100504604:     	strb	w8, [x0, #0x24]
100504608:     	mov	x0, x25
10050460c:     	mov	x1, x19
100504610:     	mov	x2, x23
100504614:     	bl	0x1004eb140 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template>
100504618:     	ldrb	w8, [x20, #0x20]
10050461c:     	cbnz	w8, 0x100504ac8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1210>
100504620:     	ldr	x8, [x20]
100504624:     	cbnz	x8, 0x100504aec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1234>
100504628:     	mov	x8, #-0x1               ; =-1
10050462c:     	str	x8, [x20]
100504630:     	ldr	x19, [x20, #0x18]
100504634:     	ldr	x8, [x20, #0x8]
100504638:     	cmp	x19, x8
10050463c:     	b.eq	0x10050479c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xee4>
100504640:     	ldr	x8, [x20, #0x10]
100504644:     	str	x23, [x8, x19, lsl #3]
100504648:     	add	x8, x19, #0x1
10050464c:     	str	x8, [x20, #0x18]
100504650:     	ldr	x8, [x20]
100504654:     	add	x8, x8, #0x1
100504658:     	str	x8, [x20]
10050465c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100504660:     	ldr	w19, [x8, #0x308]
100504664:     	cmp	w19, #0x300
100504668:     	b.hs	0x1005047b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf00>
10050466c:     	ldr	x8, [x27, #0x48]
100504670:     	cmn	x8, #0x1
100504674:     	b.eq	0x1005047a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef0>
100504678:     	mrs	x9, TPIDRRO_EL0
10050467c:     	and	x9, x9, #0xfffffffffffffff8
100504680:     	ldr	x0, [x9, x8, lsl #3]
100504684:     	cbz	x0, 0x1005047a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef0>
100504688:     	add	x8, x0, x19, lsl #3
10050468c:     	ldr	x0, [x8, #0x1e8]
100504690:     	cbz	x0, 0x1005047b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf00>
100504694:     	ldrb	w8, [x0]
100504698:     	and	w8, w8, #0xfffffffd
10050469c:     	strb	w8, [x0]
1005046a0:     	mov	w0, #0x0                ; =0
1005046a4:     	bl	0x10045b080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
1005046a8:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1005046ac:     	ldr	w19, [x8, #0x590]
1005046b0:     	cmp	w19, #0x300
1005046b4:     	b.hs	0x1005047d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf20>
1005046b8:     	ldr	x8, [x27, #0x48]
1005046bc:     	cmn	x8, #0x1
1005046c0:     	b.eq	0x1005047c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf10>
1005046c4:     	mrs	x9, TPIDRRO_EL0
1005046c8:     	and	x9, x9, #0xfffffffffffffff8
1005046cc:     	ldr	x0, [x9, x8, lsl #3]
1005046d0:     	cbz	x0, 0x1005047c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf10>
1005046d4:     	add	x8, x0, x19, lsl #3
1005046d8:     	ldr	x0, [x8, #0x1e8]
1005046dc:     	cbz	x0, 0x1005047d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf20>
1005046e0:     	ldr	x8, [x0]
1005046e4:     	lsr	x8, x8, #25
1005046e8:     	cbz	x8, 0x1005047f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf38>
1005046ec:     	bl	0x10045ce34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005046f0:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
1005046f4:     	mov	x0, x24
1005046f8:     	mov	x1, x22
1005046fc:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100504700:     	ldrb	w8, [x20, #0x20]
100504704:     	cbz	w8, 0x100504808 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf50>
100504708:     	cmp	w8, #0x2
10050470c:     	b.eq	0x100504ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13e8>
100504710:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504714:     	add	x1, x1, #0x518
100504718:     	mov	x0, x20
10050471c:     	bl	0x100a1e2dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504720:     	strb	wzr, [x20, #0x20]
100504724:     	ldr	x8, [x20]
100504728:     	cbz	x8, 0x100504810 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf58>
10050472c:     	b	0x100504cc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1410>
100504730:     	add	x0, x20, #0x8
100504734:     	bl	0x100b39b6c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100504738:     	b	0x100503e98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5e0>
10050473c:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504740:     	add	x8, x0, x23, lsl #3
100504744:     	ldr	x0, [x8, #0x1e8]
100504748:     	cbnz	x0, 0x100503eec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x634>
10050474c:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
100504750:     	add	x0, x0, #0xcf0
100504754:     	bl	0x100b3aae8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100504758:     	ldrb	w8, [x0]
10050475c:     	cbz	w8, 0x100503ef4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x63c>
100504760:     	bl	0x100b4221c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
100504764:     	tbnz	w22, #0x0, 0x100503ef8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x640>
100504768:     	b	0x1005044c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
10050476c:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504770:     	add	x8, x0, x26, lsl #3
100504774:     	ldr	x0, [x8, #0x1e8]
100504778:     	cbnz	x0, 0x1005045d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd1c>
10050477c:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1e70>
100504780:     	add	x0, x0, #0xfe8
100504784:     	bl	0x100b3aa9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100504788:     	ldr	x8, [x0]
10050478c:     	cbz	x8, 0x1005045dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd24>
100504790:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100504794:     	add	x0, x0, #0xcf8
100504798:     	bl	0x100b105ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10050479c:     	add	x0, x20, #0x8
1005047a0:     	bl	0x100b39b6c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1005047a4:     	b	0x100504640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd88>
1005047a8:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005047ac:     	add	x8, x0, x19, lsl #3
1005047b0:     	ldr	x0, [x8, #0x1e8]
1005047b4:     	cbnz	x0, 0x100504694 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xddc>
1005047b8:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1005047bc:     	add	x0, x0, #0xd20
1005047c0:     	bl	0x100b3aae8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1005047c4:     	b	0x100504694 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xddc>
1005047c8:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005047cc:     	add	x8, x0, x19, lsl #3
1005047d0:     	ldr	x0, [x8, #0x1e8]
1005047d4:     	cbnz	x0, 0x1005046e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe28>
1005047d8:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
1005047dc:     	add	x0, x0, #0x90
1005047e0:     	bl	0x100b3aa9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005047e4:     	ldr	x8, [x0]
1005047e8:     	lsr	x8, x8, #25
1005047ec:     	cbnz	x8, 0x1005046ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe34>
1005047f0:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
1005047f4:     	mov	x0, x24
1005047f8:     	mov	x1, x22
1005047fc:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100504800:     	ldrb	w8, [x20, #0x20]
100504804:     	cbnz	w8, 0x100504708 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe50>
100504808:     	ldr	x8, [x20]
10050480c:     	cbnz	x8, 0x100504cc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1410>
100504810:     	ldr	x8, [x20, #0x18]
100504814:     	cmp	x21, x8
100504818:     	b.ls	0x100504860 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa8>
10050481c:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100504820:     	ldr	x8, [x8, #0x758]
100504824:     	cbnz	x8, 0x100504870 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfb8>
100504828:     	ldr	x8, [sp, #0xd8]
10050482c:     	cmp	x8, #0x1
100504830:     	b.lt	0x10050483c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf84>
100504834:     	ldr	x0, [sp, #0xe0]
100504838:     	bl	0x100b5ce40 <_mi_free>
10050483c:     	mov	x0, x23
100504840:     	add	sp, sp, #0x1a0
100504844:     	ldp	x29, x30, [sp, #0x50]
100504848:     	ldp	x20, x19, [sp, #0x40]
10050484c:     	ldp	x22, x21, [sp, #0x30]
100504850:     	ldp	x24, x23, [sp, #0x20]
100504854:     	ldp	x26, x25, [sp, #0x10]
100504858:     	ldp	x28, x27, [sp], #0x60
10050485c:     	ret
100504860:     	str	x21, [x20, #0x18]
100504864:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100504868:     	ldr	x8, [x8, #0x758]
10050486c:     	cbz	x8, 0x100504828 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf70>
100504870:     	bl	0x100b43938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100504874:     	ldr	x8, [sp, #0xd8]
100504878:     	cmp	x8, #0x1
10050487c:     	b.ge	0x100504834 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf7c>
100504880:     	b	0x10050483c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf84>
100504884:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504888:     	add	x8, x0, x20, lsl #3
10050488c:     	ldr	x0, [x8, #0x1e8]
100504890:     	cbnz	x0, 0x100503da4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4ec>
100504894:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1e70>
100504898:     	add	x0, x0, #0xfe8
10050489c:     	bl	0x100b3aa9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005048a0:     	ldr	x8, [x0]
1005048a4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005048a8:     	cmp	x8, x9
1005048ac:     	b.lo	0x100503db4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4fc>
1005048b0:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1005048b4:     	add	x0, x0, #0xd10
1005048b8:     	bl	0x100b105dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1005048bc:     	cmp	w10, #0x5b
1005048c0:     	cset	w22, eq
1005048c4:     	mov	w8, #0x1000000          ; =16777216
1005048c8:     	cmp	x19, x8
1005048cc:     	mov	w8, #0x5b               ; =91
1005048d0:     	ccmp	w10, w8, #0x0, ls
1005048d4:     	b.ne	0x100503d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4b8>
1005048d8:     	mov	w28, #0x1               ; =1
1005048dc:     	mov	w22, #0x1               ; =1
1005048e0:     	b	0x100503e54 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x59c>
1005048e4:     	mov	w1, #0x0                ; =0
1005048e8:     	ldr	x8, [sp, #0xa0]
1005048ec:     	add	x8, x8, x8, lsl #1
1005048f0:     	lsl	x8, x8, #2
1005048f4:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1005048f8:     	b.ls	0x10050491c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1064>
1005048fc:     	ldr	q0, [sp, #0xa0]
100504900:     	str	q0, [sp, #0x10]
100504904:     	ldr	x8, [sp, #0xb0]
100504908:     	str	x8, [sp, #0x20]
10050490c:     	mov	w8, #0x4                ; =4
100504910:     	stp	xzr, x8, [sp, #0xa0]
100504914:     	str	xzr, [sp, #0xb0]
100504918:     	b	0x100504928 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1070>
10050491c:     	stp	x24, x25, [sp, #0x18]
100504920:     	mov	x8, #-0x1               ; =-1
100504924:     	str	x8, [sp, #0x10]
100504928:     	add	x0, sp, #0x10
10050492c:     	bl	0x100374ab0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24alloc_lazy_array_backing>
100504930:     	mov	x25, #0x7ffd000000000000 ; =9222527611924643840
100504934:     	bfxil	x25, x0, #0, #48
100504938:     	ldrb	w8, [x20, #0x20]
10050493c:     	cbz	w8, 0x100504200 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x948>
100504940:     	b	0x1005041a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8f0>
100504944:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504948:     	add	x8, x0, x24, lsl #3
10050494c:     	ldr	x0, [x8, #0x1e8]
100504950:     	cbnz	x0, 0x100504004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x74c>
100504954:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
100504958:     	add	x0, x0, #0xcf0
10050495c:     	bl	0x100b3aae8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100504960:     	ldrb	w8, [x0]
100504964:     	cbz	w8, 0x10050400c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x754>
100504968:     	bl	0x100b4221c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
10050496c:     	b	0x10050400c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x754>
100504970:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504974:     	add	x8, x0, x24, lsl #3
100504978:     	ldr	x0, [x8, #0x1e8]
10050497c:     	cbnz	x0, 0x100504290 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9d8>
100504980:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
100504984:     	add	x0, x0, #0xd20
100504988:     	bl	0x100b3aae8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
10050498c:     	b	0x100504290 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9d8>
100504990:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504994:     	add	x8, x0, x24, lsl #3
100504998:     	ldr	x0, [x8, #0x1e8]
10050499c:     	cbnz	x0, 0x1005042dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa24>
1005049a0:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
1005049a4:     	add	x0, x0, #0x90
1005049a8:     	bl	0x100b3aa9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005049ac:     	ldr	x8, [x0]
1005049b0:     	lsr	x8, x8, #25
1005049b4:     	cbnz	x8, 0x1005042e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa30>
1005049b8:     	cmp	x23, #0x3e8
1005049bc:     	b.ls	0x1005042f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa3c>
1005049c0:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
1005049c4:     	ldp	x1, x0, [sp]
1005049c8:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005049cc:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1005049d0:     	ldr	x8, [x8, #0x758]
1005049d4:     	cbz	x8, 0x100504308 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa50>
1005049d8:     	bl	0x100b43938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
1005049dc:     	tbnz	w25, #0x0, 0x10050430c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa54>
1005049e0:     	b	0x100504350 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa98>
1005049e4:     	add	x0, x20, #0x8
1005049e8:     	bl	0x100b39b6c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1005049ec:     	b	0x100504220 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x968>
1005049f0:     	bl	0x100b4370c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar15clear_key_cache>
1005049f4:     	cmp	x28, x26
1005049f8:     	b.eq	0x100504594 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcdc>
1005049fc:     	mov	x0, x23
100504a00:     	bl	0x1003259cc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15parse_root_push>
100504a04:     	bl	0x1004578bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy13gc_unsuppress>
100504a08:     	bl	0x1004ed9a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat26finish_parse_gc_accounting>
100504a0c:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100504a10:     	mov	x0, x24
100504a14:     	mov	x1, x22
100504a18:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100504a1c:     	mov	x0, x21
100504a20:     	bl	0x100325bdc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100504a24:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100504a28:     	ldr	x8, [x8, #0x758]
100504a2c:     	cbnz	x8, 0x100504f70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x16b8>
100504a30:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x705c>
100504a34:     	add	x0, x0, #0x460
100504a38:     	mov	w1, #0x21               ; =33
100504a3c:     	bl	0x100506500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
100504a40:     	cmp	x9, #0x6
100504a44:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504a48:     	ldrb	w8, [x21, #0x1a]
100504a4c:     	cmp	w8, #0x22
100504a50:     	b.ne	0x100504bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1304>
100504a54:     	mov	w20, #0x0               ; =0
100504a58:     	mov	w23, #0x0               ; =0
100504a5c:     	mov	w28, #0x0               ; =0
100504a60:     	mov	w8, #0x1                ; =1
100504a64:     	str	w8, [sp, #0x8]
100504a68:     	mov	w26, #0x4               ; =4
100504a6c:     	b	0x100503a60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1a8>
100504a70:     	cmp	w8, #0x2
100504a74:     	b.eq	0x100504ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13e8>
100504a78:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504a7c:     	add	x1, x1, #0x518
100504a80:     	mov	x0, x20
100504a84:     	bl	0x100a1e2dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504a88:     	strb	wzr, [x20, #0x20]
100504a8c:     	ldr	x8, [x20]
100504a90:     	cbz	x8, 0x100503e78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c0>
100504a94:     	b	0x100504aec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1234>
100504a98:     	cmp	w8, #0x2
100504a9c:     	b.eq	0x100504ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13e8>
100504aa0:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504aa4:     	add	x1, x1, #0x518
100504aa8:     	mov	x0, x20
100504aac:     	bl	0x100a1e2dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504ab0:     	strb	wzr, [x20, #0x20]
100504ab4:     	ldr	x8, [x20]
100504ab8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504abc:     	cmp	x8, x9
100504ac0:     	b.lo	0x1005044f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc40>
100504ac4:     	b	0x100504c8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13d4>
100504ac8:     	cmp	w8, #0x2
100504acc:     	b.eq	0x100504ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13e8>
100504ad0:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504ad4:     	add	x1, x1, #0x518
100504ad8:     	mov	x0, x20
100504adc:     	bl	0x100a1e2dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504ae0:     	strb	wzr, [x20, #0x20]
100504ae4:     	ldr	x8, [x20]
100504ae8:     	cbz	x8, 0x100504628 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd70>
100504aec:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100504af0:     	add	x0, x0, #0x428
100504af4:     	bl	0x100b105ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100504af8:     	mov	x0, x22
100504afc:     	bl	0x100b1c3ac <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11TapeScratchEEuE16get_or_init_slowNvNvB2b_12TAPE_SCRATCH27___rust_std_internal_init_fnEB2d_>
100504b00:     	mov	x22, x0
100504b04:     	cbnz	x0, 0x100503f5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6a4>
100504b08:     	b	0x100504ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13e8>
100504b0c:     	mov	x0, x21
100504b10:     	bl	0x100325bdc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100504b14:     	mov	x0, x22
100504b18:     	mov	x1, x19
100504b1c:     	bl	0x100b43c90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api19parse_deep_or_throw>
100504b20:     	mov	x23, x0
100504b24:     	b	0x10050483c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf84>
100504b28:     	cmp	w8, #0x2
100504b2c:     	b.eq	0x100504ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13e8>
100504b30:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504b34:     	add	x1, x1, #0x518
100504b38:     	mov	x0, x20
100504b3c:     	bl	0x100a1e2dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504b40:     	strb	wzr, [x20, #0x20]
100504b44:     	ldr	x8, [x20]
100504b48:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504b4c:     	cmp	x8, x9
100504b50:     	b.lo	0x100503f10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x658>
100504b54:     	b	0x100504c8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13d4>
100504b58:     	cmp	w8, #0x2
100504b5c:     	b.eq	0x100504ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13e8>
100504b60:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504b64:     	add	x1, x1, #0x518
100504b68:     	mov	x0, x20
100504b6c:     	bl	0x100a1e2dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504b70:     	strb	wzr, [x20, #0x20]
100504b74:     	ldr	x8, [x20]
100504b78:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504b7c:     	cmp	x8, x9
100504b80:     	b.lo	0x1005043fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb44>
100504b84:     	b	0x100504c8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13d4>
100504b88:     	cmp	x9, #0x1
100504b8c:     	b.ne	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1360>
100504b90:     	ldrb	w8, [x8]
100504b94:     	sub	w9, w8, #0x30
100504b98:     	cmp	w9, #0xa
100504b9c:     	b.hs	0x100504c1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1364>
100504ba0:     	and	w8, w9, #0xff
100504ba4:     	ucvtf	d0, w8
100504ba8:     	fmov	x1, d0
100504bac:     	orr	x0, x25, x28
100504bb0:     	bl	0x1004f3b70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object18allocate_one_field>
100504bb4:     	tbz	w0, #0x0, 0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504bb8:     	b	0x100503cb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3f8>
100504bbc:     	cmp	x9, #0x7
100504bc0:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504bc4:     	ldrb	w8, [x21, #0x1b]
100504bc8:     	cmp	w8, #0x22
100504bcc:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504bd0:     	mov	w20, #0x0               ; =0
100504bd4:     	mov	w23, #0x0               ; =0
100504bd8:     	mov	w28, #0x0               ; =0
100504bdc:     	str	wzr, [sp, #0x8]
100504be0:     	mov	w26, #0x5               ; =5
100504be4:     	b	0x100503a60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1a8>
100504be8:     	cmp	w8, #0x2
100504bec:     	b.eq	0x100504ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13e8>
100504bf0:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504bf4:     	add	x1, x1, #0x518
100504bf8:     	mov	x0, x20
100504bfc:     	bl	0x100a1e2dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504c00:     	strb	wzr, [x20, #0x20]
100504c04:     	ldr	x8, [x20]
100504c08:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504c0c:     	cmp	x8, x9
100504c10:     	b.lo	0x100504040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x788>
100504c14:     	b	0x100504c8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13d4>
100504c18:     	ldrb	w8, [x8]
100504c1c:     	orr	w8, w8, #0x20
100504c20:     	cmp	w8, #0x7b
100504c24:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504c28:     	mov	x20, x26
100504c2c:     	sub	x11, x19, #0x5
100504c30:     	mov	x10, #0x2600            ; =9728
100504c34:     	movk	x10, #0x1, lsl #32
100504c38:     	add	x8, x21, x20
100504c3c:     	ldrb	w9, [x8, #0x18]
100504c40:     	cmp	w9, #0x20
100504c44:     	b.hi	0x100504cd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x141c>
100504c48:     	lsr	x12, x10, x9
100504c4c:     	tbz	w12, #0x0, 0x100504cd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x141c>
100504c50:     	add	x20, x20, #0x1
100504c54:     	cmp	x11, x20
100504c58:     	b.ne	0x100504c38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1380>
100504c5c:     	b	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504c60:     	cmp	w8, #0x2
100504c64:     	b.eq	0x100504ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13e8>
100504c68:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504c6c:     	add	x1, x1, #0x518
100504c70:     	mov	x0, x20
100504c74:     	bl	0x100a1e2dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504c78:     	strb	wzr, [x20, #0x20]
100504c7c:     	ldr	x8, [x20]
100504c80:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504c84:     	cmp	x8, x9
100504c88:     	b.lo	0x100504324 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa6c>
100504c8c:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100504c90:     	add	x0, x0, #0x3f8
100504c94:     	bl	0x100b105dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100504c98:     	cmp	w8, #0x2
100504c9c:     	b.ne	0x100504cac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13f4>
100504ca0:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100504ca4:     	add	x0, x0, #0xc18
100504ca8:     	bl	0x100b5649c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100504cac:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504cb0:     	add	x1, x1, #0x518
100504cb4:     	mov	x0, x20
100504cb8:     	bl	0x100a1e2dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504cbc:     	strb	wzr, [x20, #0x20]
100504cc0:     	ldr	x8, [x20]
100504cc4:     	cbz	x8, 0x10050448c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbd4>
100504cc8:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100504ccc:     	add	x0, x0, #0x488
100504cd0:     	bl	0x100b105ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100504cd4:     	cmp	x11, x20
100504cd8:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504cdc:     	add	x13, x21, #0x12
100504ce0:     	mov	x14, #0x2600            ; =9728
100504ce4:     	movk	x14, #0x1, lsl #32
100504ce8:     	mov	x10, x20
100504cec:     	ldrb	w12, [x13, x19]
100504cf0:     	cmp	w12, #0x20
100504cf4:     	b.hi	0x100504d14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x145c>
100504cf8:     	lsr	x15, x14, x12
100504cfc:     	tbz	w15, #0x0, 0x100504d14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x145c>
100504d00:     	sub	x13, x13, #0x1
100504d04:     	add	x10, x10, #0x1
100504d08:     	cmp	x11, x10
100504d0c:     	b.ne	0x100504cec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1434>
100504d10:     	b	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504d14:     	sub	x11, x19, x10
100504d18:     	sub	x1, x11, #0x5
100504d1c:     	cmp	x1, #0x4
100504d20:     	b.eq	0x100504d9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14e4>
100504d24:     	cmp	x1, #0x5
100504d28:     	b.ne	0x100504da4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ec>
100504d2c:     	cmp	w9, #0x22
100504d30:     	b.eq	0x100504dd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1518>
100504d34:     	cmp	w9, #0x2d
100504d38:     	b.eq	0x100504dc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1508>
100504d3c:     	cmp	w9, #0x66
100504d40:     	b.ne	0x100504db4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14fc>
100504d44:     	add	x8, x21, x20
100504d48:     	ldrb	w9, [x8, #0x19]
100504d4c:     	cmp	w9, #0x61
100504d50:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504d54:     	ldrb	w8, [x8, #0x1a]
100504d58:     	cmp	w8, #0x6c
100504d5c:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504d60:     	add	x8, x21, x20
100504d64:     	ldrb	w9, [x8, #0x1b]
100504d68:     	cmp	w9, #0x73
100504d6c:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504d70:     	ldrb	w8, [x8, #0x1c]
100504d74:     	cmp	w8, #0x65
100504d78:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504d7c:     	mov	x8, #0x1                ; =1
100504d80:     	movk	x8, #0x7ffc, lsl #48
100504d84:     	orr	x1, x8, #0x2
100504d88:     	b	0x100504bac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f4>
100504d8c:     	adrp	x2, 0x100f07000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime7promise28ITER_RESULT_VALUE_IS_RAW_F64+0x10>
100504d90:     	add	x2, x2, #0x1b8
100504d94:     	mov	x1, x25
100504d98:     	bl	0x100b1070c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100504d9c:     	cmp	w9, #0x6d
100504da0:     	b.gt	0x100504e3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1584>
100504da4:     	cmp	w9, #0x22
100504da8:     	b.eq	0x100504dd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1518>
100504dac:     	cmp	w9, #0x2d
100504db0:     	b.eq	0x100504dc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1508>
100504db4:     	sub	w9, w9, #0x30
100504db8:     	cmp	w9, #0xa
100504dbc:     	b.hs	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504dc0:     	add	x0, x8, #0x18
100504dc4:     	bl	0x1004eb750 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar12parse_number>
100504dc8:     	tbz	w0, #0x0, 0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504dcc:     	b	0x100504bac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f4>
100504dd0:     	sub	x8, x19, #0x6
100504dd4:     	cmp	x8, x10
100504dd8:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504ddc:     	cmp	x1, #0x7
100504de0:     	b.hi	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504de4:     	cmp	w12, #0x22
100504de8:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504dec:     	sub	x23, x11, #0x7
100504df0:     	sub	x8, x19, #0x7
100504df4:     	add	x9, x21, x20
100504df8:     	add	x22, x9, #0x19
100504dfc:     	cmp	x8, x10
100504e00:     	b.ne	0x100504ec4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160c>
100504e04:     	add	x8, sp, #0xa0
100504e08:     	mov	x0, x22
100504e0c:     	mov	x1, x23
100504e10:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100504e14:     	ldr	x8, [sp, #0xa0]
100504e18:     	cbnz	x8, 0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504e1c:     	cmp	x23, #0x2
100504e20:     	b.gt	0x100504ef4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x163c>
100504e24:     	cbz	x23, 0x100504f10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1658>
100504e28:     	cmp	x23, #0x1
100504e2c:     	b.ne	0x100504f18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1660>
100504e30:     	ldrb	w8, [x22]
100504e34:     	mov	x9, #0x10000000000      ; =1099511627776
100504e38:     	b	0x100504f64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x16ac>
100504e3c:     	cmp	w9, #0x74
100504e40:     	b.eq	0x100504e88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d0>
100504e44:     	cmp	w9, #0x6e
100504e48:     	b.ne	0x100504db4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14fc>
100504e4c:     	add	x8, x21, x20
100504e50:     	ldrb	w9, [x8, #0x19]
100504e54:     	cmp	w9, #0x75
100504e58:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504e5c:     	ldrb	w8, [x8, #0x1a]
100504e60:     	cmp	w8, #0x6c
100504e64:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504e68:     	add	x8, x21, x20
100504e6c:     	ldrb	w8, [x8, #0x1b]
100504e70:     	cmp	w8, #0x6c
100504e74:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504e78:     	mov	x8, #0x1                ; =1
100504e7c:     	movk	x8, #0x7ffc, lsl #48
100504e80:     	add	x1, x8, #0x1
100504e84:     	b	0x100504bac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f4>
100504e88:     	add	x8, x21, x20
100504e8c:     	ldrb	w9, [x8, #0x19]
100504e90:     	cmp	w9, #0x72
100504e94:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504e98:     	ldrb	w8, [x8, #0x1a]
100504e9c:     	cmp	w8, #0x75
100504ea0:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504ea4:     	add	x8, x21, x20
100504ea8:     	ldrb	w8, [x8, #0x1b]
100504eac:     	cmp	w8, #0x65
100504eb0:     	b.ne	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504eb4:     	mov	x8, #0x1                ; =1
100504eb8:     	movk	x8, #0x7ffc, lsl #48
100504ebc:     	add	x1, x8, #0x3
100504ec0:     	b	0x100504bac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f4>
100504ec4:     	mov	x8, x23
100504ec8:     	mov	x9, x22
100504ecc:     	ldrb	w10, [x9], #0x1
100504ed0:     	cmp	w10, #0x20
100504ed4:     	b.lo	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504ed8:     	cmp	w10, #0x22
100504edc:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504ee0:     	cmp	w10, #0x5c
100504ee4:     	b.eq	0x100503c50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100504ee8:     	subs	x8, x8, #0x1
100504eec:     	b.ne	0x100504ecc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1614>
100504ef0:     	b	0x100504e04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x154c>
100504ef4:     	cmp	x23, #0x3
100504ef8:     	b.eq	0x100504f30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1678>
100504efc:     	cmp	x23, #0x4
100504f00:     	b.ne	0x100504f50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1698>
100504f04:     	ldr	w8, [x22]
100504f08:     	mov	x9, #0x40000000000      ; =4398046511104
100504f0c:     	b	0x100504f64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x16ac>
100504f10:     	mov	x1, #0x7ff9000000000000 ; =9221401712017801216
100504f14:     	b	0x100504bac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f4>
100504f18:     	ldrb	w8, [x22]
100504f1c:     	add	x9, x21, x20
100504f20:     	ldrb	w9, [x9, #0x1a]
100504f24:     	orr	x8, x8, x9, lsl #8
100504f28:     	mov	x9, #0x20000000000      ; =2199023255552
100504f2c:     	b	0x100504f64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x16ac>
100504f30:     	ldrb	w8, [x22]
100504f34:     	add	x9, x21, x20
100504f38:     	ldrb	w10, [x9, #0x1a]
100504f3c:     	ldrb	w9, [x9, #0x1b]
100504f40:     	orr	x8, x8, x10, lsl #8
100504f44:     	orr	x8, x8, x9, lsl #16
100504f48:     	mov	x9, #0x30000000000      ; =3298534883328
100504f4c:     	b	0x100504f64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x16ac>
100504f50:     	ldr	w8, [x22]
100504f54:     	add	x9, x21, x20
100504f58:     	ldrb	w9, [x9, #0x1d]
100504f5c:     	orr	x8, x8, x9, lsl #32
100504f60:     	mov	x9, #0x50000000000      ; =5497558138880
100504f64:     	movk	x9, #0x7ff9, lsl #48
100504f68:     	orr	x1, x8, x9
100504f6c:     	b	0x100504bac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f4>
100504f70:     	bl	0x100b43938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100504f74:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x705c>
100504f78:     	add	x0, x0, #0x460
100504f7c:     	mov	w1, #0x21               ; =33
100504f80:     	bl	0x100506500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
