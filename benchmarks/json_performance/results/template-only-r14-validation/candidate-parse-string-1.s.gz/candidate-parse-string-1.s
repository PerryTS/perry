
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-only-r14/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005e8bc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>:
1005e8bc4:     	sub	sp, sp, #0x60
1005e8bc8:     	stp	x24, x23, [sp, #0x20]
1005e8bcc:     	stp	x22, x21, [sp, #0x30]
1005e8bd0:     	stp	x20, x19, [sp, #0x40]
1005e8bd4:     	stp	x29, x30, [sp, #0x50]
1005e8bd8:     	add	x29, sp, #0x50
1005e8bdc:     	mov	x19, x1
1005e8be0:     	cmp	x2, #0x40
1005e8be4:     	b.hs	0x1005e8d18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x154>
1005e8be8:     	ands	x8, x2, #0x38
1005e8bec:     	b.eq	0x1005e8c10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4c>
1005e8bf0:     	and	x9, x2, #0x38
1005e8bf4:     	neg	x9, x9
1005e8bf8:     	mov	x10, x19
1005e8bfc:     	ldr	x11, [x10], #0x8
1005e8c00:     	tst	x11, #0x8080808080808080
1005e8c04:     	b.ne	0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8c08:     	adds	x9, x9, #0x8
1005e8c0c:     	b.ne	0x1005e8bfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x38>
1005e8c10:     	mov	x20, x2
1005e8c14:     	and	x9, x2, #0x7
1005e8c18:     	cbz	x9, 0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8c1c:     	add	x8, x19, x8
1005e8c20:     	ldrsb	w10, [x8]
1005e8c24:     	tbnz	w10, #0x1f, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8c28:     	mov	x20, x2
1005e8c2c:     	cmp	x9, #0x1
1005e8c30:     	b.eq	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8c34:     	ldrsb	w10, [x8, #0x1]
1005e8c38:     	tbnz	w10, #0x1f, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8c3c:     	mov	x20, x2
1005e8c40:     	cmp	x9, #0x2
1005e8c44:     	b.eq	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8c48:     	ldrsb	w10, [x8, #0x2]
1005e8c4c:     	tbnz	w10, #0x1f, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8c50:     	mov	x20, x2
1005e8c54:     	cmp	x9, #0x3
1005e8c58:     	b.eq	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8c5c:     	ldrsb	w10, [x8, #0x3]
1005e8c60:     	tbnz	w10, #0x1f, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8c64:     	mov	x20, x2
1005e8c68:     	cmp	x9, #0x4
1005e8c6c:     	b.eq	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8c70:     	ldrsb	w10, [x8, #0x4]
1005e8c74:     	tbnz	w10, #0x1f, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8c78:     	mov	x20, x2
1005e8c7c:     	cmp	x9, #0x5
1005e8c80:     	b.eq	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8c84:     	ldrsb	w10, [x8, #0x5]
1005e8c88:     	tbnz	w10, #0x1f, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8c8c:     	mov	x20, x2
1005e8c90:     	cmp	x9, #0x6
1005e8c94:     	b.eq	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8c98:     	ldrsb	w8, [x8, #0x6]
1005e8c9c:     	mov	x20, x2
1005e8ca0:     	tbz	w8, #0x1f, 0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8ca4:     	cbz	w2, 0x1005e8da4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1e0>
1005e8ca8:     	mov	x20, x2
1005e8cac:     	mov	w21, w2
1005e8cb0:     	cbz	x21, 0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8cb4:     	mov	x8, x19
1005e8cb8:     	ands	x9, x2, #0x3
1005e8cbc:     	b.eq	0x1005e8cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x114>
1005e8cc0:     	mov	x8, x19
1005e8cc4:     	ldrsb	w10, [x8]
1005e8cc8:     	tbnz	w10, #0x1f, 0x1005e8dbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8ccc:     	add	x8, x8, #0x1
1005e8cd0:     	subs	x9, x9, #0x1
1005e8cd4:     	b.ne	0x1005e8cc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x100>
1005e8cd8:     	mov	x20, x2
1005e8cdc:     	cmp	x21, #0x4
1005e8ce0:     	b.lo	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8ce4:     	add	x9, x19, x21
1005e8ce8:     	ldrsb	w10, [x8]
1005e8cec:     	tbnz	w10, #0x1f, 0x1005e8dbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8cf0:     	ldrsb	w10, [x8, #0x1]
1005e8cf4:     	tbnz	w10, #0x1f, 0x1005e8dbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8cf8:     	ldrsb	w10, [x8, #0x2]
1005e8cfc:     	tbnz	w10, #0x1f, 0x1005e8dbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8d00:     	ldrsb	w10, [x8, #0x3]
1005e8d04:     	tbnz	w10, #0x1f, 0x1005e8dbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1f8>
1005e8d08:     	add	x8, x8, #0x4
1005e8d0c:     	cmp	x8, x9
1005e8d10:     	b.ne	0x1005e8ce8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x124>
1005e8d14:     	b	0x1005e8d9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1d8>
1005e8d18:     	and	x8, x2, #0x7fffffffffffffc0
1005e8d1c:     	add	x8, x19, x8
1005e8d20:     	mov	x9, x19
1005e8d24:     	ldp	q0, q1, [x9]
1005e8d28:     	ldp	q2, q3, [x9, #0x20]
1005e8d2c:     	orr.16b	v0, v1, v0
1005e8d30:     	orr.16b	v1, v2, v3
1005e8d34:     	orr.16b	v0, v0, v1
1005e8d38:     	umaxv.16b	b0, v0
1005e8d3c:     	fmov	w10, s0
1005e8d40:     	tbnz	w10, #0x7, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8d44:     	add	x9, x9, #0x40
1005e8d48:     	cmp	x9, x8
1005e8d4c:     	b.ne	0x1005e8d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x160>
1005e8d50:     	ands	x9, x2, #0x30
1005e8d54:     	b.eq	0x1005e8d78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1b4>
1005e8d58:     	mov	x10, x9
1005e8d5c:     	mov	x11, x8
1005e8d60:     	ldr	q0, [x11], #0x10
1005e8d64:     	umaxv.16b	b0, v0
1005e8d68:     	fmov	w12, s0
1005e8d6c:     	tbnz	w12, #0x7, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8d70:     	subs	x10, x10, #0x10
1005e8d74:     	b.ne	0x1005e8d60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x19c>
1005e8d78:     	mov	x20, x2
1005e8d7c:     	and	x10, x2, #0xf
1005e8d80:     	cbz	x10, 0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8d84:     	add	x8, x8, x9
1005e8d88:     	ldrsb	w9, [x8]
1005e8d8c:     	tbnz	w9, #0x1f, 0x1005e8ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0xe0>
1005e8d90:     	add	x8, x8, #0x1
1005e8d94:     	subs	x10, x10, #0x1
1005e8d98:     	b.ne	0x1005e8d88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x1c4>
1005e8d9c:     	mov	x20, x2
1005e8da0:     	b	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8da4:     	mov	w20, #0x0               ; =0
1005e8da8:     	mov	w8, #0x14               ; =20
1005e8dac:     	orr	x8, x2, x8
1005e8db0:     	ldr	x9, [x0]
1005e8db4:     	cbnz	x9, 0x1005e8e8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2c8>
1005e8db8:     	b	0x1005e8ec8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005e8dbc:     	mov	x22, x0
1005e8dc0:     	mov	x23, x2
1005e8dc4:     	cmp	w2, #0x3f
1005e8dc8:     	b.ls	0x1005e8f14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x350>
1005e8dcc:     	mov	x0, x19
1005e8dd0:     	mov	x1, x21
1005e8dd4:     	bl	0x1005e85e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
1005e8dd8:     	mov	x20, x0
1005e8ddc:     	mov	x2, x23
1005e8de0:     	mov	x0, x22
1005e8de4:     	lsr	w8, w2, #19
1005e8de8:     	cbz	w8, 0x1005e8e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2bc>
1005e8dec:     	mov	w23, w2
1005e8df0:     	add	x0, x23, #0x14
1005e8df4:     	mov	w1, #0x3                ; =3
1005e8df8:     	mov	x22, x2
1005e8dfc:     	bl	0x100455f00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
1005e8e00:     	mov	x21, x0
1005e8e04:     	stp	w20, w22, [x0]
1005e8e08:     	str	w22, [x0, #0x8]
1005e8e0c:     	mov	x8, #0x200000000        ; =8589934592
1005e8e10:     	stur	x8, [x0, #0xc]
1005e8e14:     	add	x0, x0, #0x14
1005e8e18:     	mov	x1, x19
1005e8e1c:     	mov	x2, x22
1005e8e20:     	bl	0x100b5fcec <_writev+0x100b5fcec>
1005e8e24:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1005e8e28:     	ldr	w19, [x8, #0x590]
1005e8e2c:     	cmp	w19, #0x300
1005e8e30:     	b.hs	0x1005e9018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x454>
1005e8e34:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1005e8e38:     	ldr	x8, [x8, #0x48]
1005e8e3c:     	cmn	x8, #0x1
1005e8e40:     	b.eq	0x1005e9008 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x444>
1005e8e44:     	mrs	x9, TPIDRRO_EL0
1005e8e48:     	and	x9, x9, #0xfffffffffffffff8
1005e8e4c:     	ldr	x0, [x9, x8, lsl #3]
1005e8e50:     	cbz	x0, 0x1005e9008 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x444>
1005e8e54:     	add	x8, x0, x19, lsl #3
1005e8e58:     	ldr	x0, [x8, #0x1e8]
1005e8e5c:     	cbz	x0, 0x1005e9018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x454>
1005e8e60:     	ldr	x8, [x0]
1005e8e64:     	adds	x8, x8, x23
1005e8e68:     	csinv	x8, x8, xzr, lo
1005e8e6c:     	str	x8, [x0]
1005e8e70:     	lsr	x8, x8, #25
1005e8e74:     	cbz	x8, 0x1005e8ef8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005e8e78:     	bl	0x10045ce34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005e8e7c:     	b	0x1005e8ef8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005e8e80:     	add	x8, x2, #0x14
1005e8e84:     	ldr	x9, [x0]
1005e8e88:     	cbz	x9, 0x1005e8ec8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005e8e8c:     	add	x9, x8, #0xf
1005e8e90:     	and	x9, x9, #0xfffffffffffffff8
1005e8e94:     	cmp	x9, #0x4, lsl #12       ; =0x4000
1005e8e98:     	b.hi	0x1005e8ec8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005e8e9c:     	ldr	x10, [x0, #0x10]
1005e8ea0:     	ldrb	w10, [x10]
1005e8ea4:     	tbnz	w10, #0x0, 0x1005e8ec8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x304>
1005e8ea8:     	ldr	x10, [x0, #0x8]
1005e8eac:     	ldp	x11, x12, [x10, #0x8]
1005e8eb0:     	add	x11, x11, #0x7
1005e8eb4:     	and	x11, x11, #0xfffffffffffffff8
1005e8eb8:     	subs	x12, x12, x11
1005e8ebc:     	csel	x12, xzr, x12, lo
1005e8ec0:     	cmp	x9, x12
1005e8ec4:     	b.ls	0x1005e8fa0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x3dc>
1005e8ec8:     	mov	x0, x2
1005e8ecc:     	mov	x22, x2
1005e8ed0:     	bl	0x100348d2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1005e8ed4:     	mov	x21, x0
1005e8ed8:     	mov	x0, x1
1005e8edc:     	stp	w20, w22, [x21]
1005e8ee0:     	str	w22, [x21, #0x8]
1005e8ee4:     	mov	x8, #0x200000000        ; =8589934592
1005e8ee8:     	stur	x8, [x21, #0xc]
1005e8eec:     	mov	x1, x19
1005e8ef0:     	mov	x2, x22
1005e8ef4:     	bl	0x100b5fcec <_writev+0x100b5fcec>
1005e8ef8:     	mov	x0, x21
1005e8efc:     	ldp	x29, x30, [sp, #0x50]
1005e8f00:     	ldp	x20, x19, [sp, #0x40]
1005e8f04:     	ldp	x22, x21, [sp, #0x30]
1005e8f08:     	ldp	x24, x23, [sp, #0x20]
1005e8f0c:     	add	sp, sp, #0x60
1005e8f10:     	ret
1005e8f14:     	add	x8, sp, #0x8
1005e8f18:     	mov	x0, x19
1005e8f1c:     	mov	x1, x21
1005e8f20:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
1005e8f24:     	ldr	x8, [sp, #0x8]
1005e8f28:     	cbz	x8, 0x1005e8fe0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x41c>
1005e8f2c:     	mov	w20, #0x0               ; =0
1005e8f30:     	mov	x8, #0x0                ; =0
1005e8f34:     	mov	w9, #0x2                ; =2
1005e8f38:     	mov	w10, #0x3               ; =3
1005e8f3c:     	mov	w11, #0x4               ; =4
1005e8f40:     	mov	x2, x23
1005e8f44:     	mov	x0, x22
1005e8f48:     	b	0x1005e8f60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x39c>
1005e8f4c:     	add	w20, w20, #0x1
1005e8f50:     	mov	w12, #0x1               ; =1
1005e8f54:     	add	x8, x12, x8
1005e8f58:     	cmp	x8, x21
1005e8f5c:     	b.hs	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8f60:     	ldrsb	w12, [x19, x8]
1005e8f64:     	tbz	w12, #0x1f, 0x1005e8f4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x388>
1005e8f68:     	and	w12, w12, #0xff
1005e8f6c:     	cmp	w12, #0xc0
1005e8f70:     	b.lo	0x1005e8f50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x38c>
1005e8f74:     	cmp	w12, #0xf0
1005e8f78:     	add	w13, w20, #0x2
1005e8f7c:     	csel	x14, x10, x11, lo
1005e8f80:     	csinc	w13, w13, w20, hs
1005e8f84:     	cmp	w12, #0xe0
1005e8f88:     	csel	x12, x9, x14, lo
1005e8f8c:     	csinc	w20, w13, w20, hs
1005e8f90:     	add	x8, x12, x8
1005e8f94:     	cmp	x8, x21
1005e8f98:     	b.lo	0x1005e8f60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x39c>
1005e8f9c:     	b	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e8fa0:     	ldr	x12, [x10]
1005e8fa4:     	add	x22, x12, x11
1005e8fa8:     	add	x11, x11, x9
1005e8fac:     	str	x11, [x10, #0x8]
1005e8fb0:     	mov	w10, #0x203             ; =515
1005e8fb4:     	stp	w10, w9, [x22]
1005e8fb8:     	add	x21, x22, #0x8
1005e8fbc:     	sub	x10, x9, #0x8
1005e8fc0:     	subs	x10, x10, x8
1005e8fc4:     	csel	x1, xzr, x10, lo
1005e8fc8:     	b.ls	0x1005e906c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4a8>
1005e8fcc:     	cmp	x1, #0x9
1005e8fd0:     	b.hs	0x1005e905c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x498>
1005e8fd4:     	add	x8, x22, x9
1005e8fd8:     	stur	xzr, [x8, #-0x8]
1005e8fdc:     	b	0x1005e906c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4a8>
1005e8fe0:     	ldr	x8, [sp, #0x18]
1005e8fe4:     	mov	x2, x23
1005e8fe8:     	mov	x0, x22
1005e8fec:     	cbz	x8, 0x1005e9040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x47c>
1005e8ff0:     	ldr	x9, [sp, #0x10]
1005e8ff4:     	cmp	x8, #0x8
1005e8ff8:     	b.hs	0x1005e9048 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x484>
1005e8ffc:     	mov	x10, #0x0               ; =0
1005e9000:     	mov	w20, #0x0               ; =0
1005e9004:     	b	0x1005e933c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x778>
1005e9008:     	bl	0x100b3d27c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005e900c:     	add	x8, x0, x19, lsl #3
1005e9010:     	ldr	x0, [x8, #0x1e8]
1005e9014:     	cbnz	x0, 0x1005e8e60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x29c>
1005e9018:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
1005e901c:     	add	x0, x0, #0x90
1005e9020:     	bl	0x100b3aa9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005e9024:     	ldr	x8, [x0]
1005e9028:     	adds	x8, x8, x23
1005e902c:     	csinv	x8, x8, xzr, lo
1005e9030:     	str	x8, [x0]
1005e9034:     	lsr	x8, x8, #25
1005e9038:     	cbnz	x8, 0x1005e8e78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x2b4>
1005e903c:     	b	0x1005e8ef8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x334>
1005e9040:     	mov	w20, #0x0               ; =0
1005e9044:     	b	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e9048:     	cmp	x8, #0x20
1005e904c:     	b.hs	0x1005e9088 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x4c4>
1005e9050:     	mov	x10, #0x0               ; =0
1005e9054:     	mov	w20, #0x0               ; =0
1005e9058:     	b	0x1005e928c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x6c8>
1005e905c:     	add	x0, x21, x8
1005e9060:     	mov	x23, x2
1005e9064:     	bl	0x100b5f824 <_writev+0x100b5f824>
1005e9068:     	mov	x2, x23
1005e906c:     	stp	w20, w2, [x22, #0x8]
1005e9070:     	str	w2, [x22, #0x10]
1005e9074:     	mov	x8, #0x200000000        ; =8589934592
1005e9078:     	stur	x8, [x22, #0x14]
1005e907c:     	add	x0, x22, #0x1c
1005e9080:     	mov	x1, x19
1005e9084:     	b	0x1005e8ef4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x330>
1005e9088:     	movi.2d	v0, #0000000000000000
1005e908c:     	and	x11, x8, #0x18
1005e9090:     	movi.16b	v1, #0xf0
1005e9094:     	and	x10, x8, #0xffffffffffffffe0
1005e9098:     	movi.4s	v2, #0x2
1005e909c:     	add	x12, x9, #0x10
1005e90a0:     	movi.16b	v4, #0xc0
1005e90a4:     	and	x13, x8, #0xffffffffffffffe0
1005e90a8:     	movi.2d	v3, #0000000000000000
1005e90ac:     	movi.2d	v6, #0000000000000000
1005e90b0:     	movi.2d	v5, #0000000000000000
1005e90b4:     	movi.2d	v7, #0000000000000000
1005e90b8:     	movi.2d	v16, #0000000000000000
1005e90bc:     	movi.2d	v17, #0000000000000000
1005e90c0:     	movi.2d	v18, #0000000000000000
1005e90c4:     	ldp	q20, q19, [x12, #-0x10]
1005e90c8:     	cmhi.16b	v21, v1, v20
1005e90cc:     	sshll2.8h	v22, v21, #0x0
1005e90d0:     	sshll2.4s	v23, v22, #0x0
1005e90d4:     	sshll.4s	v24, v22, #0x0
1005e90d8:     	sshll.8h	v21, v21, #0x0
1005e90dc:     	sshll2.4s	v25, v21, #0x0
1005e90e0:     	sshll.4s	v26, v21, #0x0
1005e90e4:     	cmhi.16b	v27, v1, v19
1005e90e8:     	sshll2.8h	v28, v27, #0x0
1005e90ec:     	sshll2.4s	v29, v28, #0x0
1005e90f0:     	sshll.4s	v30, v28, #0x0
1005e90f4:     	sshll.8h	v27, v27, #0x0
1005e90f8:     	sshll2.4s	v31, v27, #0x0
1005e90fc:     	bic.16b	v26, v2, v26
1005e9100:     	ssubw.4s	v26, v26, v21
1005e9104:     	bic.16b	v25, v2, v25
1005e9108:     	ssubw2.4s	v25, v25, v21
1005e910c:     	sshll.4s	v21, v27, #0x0
1005e9110:     	bic.16b	v24, v2, v24
1005e9114:     	ssubw.4s	v24, v24, v22
1005e9118:     	bic.16b	v23, v2, v23
1005e911c:     	ssubw2.4s	v22, v23, v22
1005e9120:     	bic.16b	v21, v2, v21
1005e9124:     	ssubw.4s	v21, v21, v27
1005e9128:     	bic.16b	v23, v2, v31
1005e912c:     	ssubw2.4s	v23, v23, v27
1005e9130:     	bic.16b	v27, v2, v30
1005e9134:     	ssubw.4s	v27, v27, v28
1005e9138:     	bic.16b	v29, v2, v29
1005e913c:     	ssubw2.4s	v28, v29, v28
1005e9140:     	cmgt.16b	v29, v4, v20
1005e9144:     	sshll2.8h	v30, v29, #0x0
1005e9148:     	ushll2.4s	v31, v30, #0x0
1005e914c:     	bic.16b	v22, v22, v31
1005e9150:     	cmlt.16b	v20, v20, #0
1005e9154:     	sshll.8h	v29, v29, #0x0
1005e9158:     	ushll.4s	v30, v30, #0x0
1005e915c:     	bic.16b	v24, v24, v30
1005e9160:     	ushll2.4s	v30, v29, #0x0
1005e9164:     	bic.16b	v25, v25, v30
1005e9168:     	sshll2.8h	v30, v20, #0x0
1005e916c:     	sshll.8h	v20, v20, #0x0
1005e9170:     	ushll.4s	v29, v29, #0x0
1005e9174:     	bic.16b	v26, v26, v29
1005e9178:     	sshll.4s	v29, v20, #0x0
1005e917c:     	and.16b	v26, v26, v29
1005e9180:     	mvn.16b	v29, v29
1005e9184:     	sub.4s	v26, v26, v29
1005e9188:     	sshll2.4s	v29, v30, #0x0
1005e918c:     	sshll.4s	v30, v30, #0x0
1005e9190:     	sshll2.4s	v20, v20, #0x0
1005e9194:     	and.16b	v25, v25, v20
1005e9198:     	mvn.16b	v20, v20
1005e919c:     	sub.4s	v20, v25, v20
1005e91a0:     	cmgt.16b	v25, v4, v19
1005e91a4:     	and.16b	v24, v24, v30
1005e91a8:     	mvn.16b	v30, v30
1005e91ac:     	sub.4s	v24, v24, v30
1005e91b0:     	sshll2.8h	v30, v25, #0x0
1005e91b4:     	and.16b	v22, v22, v29
1005e91b8:     	mvn.16b	v29, v29
1005e91bc:     	sub.4s	v22, v22, v29
1005e91c0:     	ushll2.4s	v29, v30, #0x0
1005e91c4:     	bic.16b	v28, v28, v29
1005e91c8:     	cmlt.16b	v19, v19, #0
1005e91cc:     	sshll.8h	v25, v25, #0x0
1005e91d0:     	ushll.4s	v29, v30, #0x0
1005e91d4:     	bic.16b	v27, v27, v29
1005e91d8:     	ushll2.4s	v29, v25, #0x0
1005e91dc:     	bic.16b	v23, v23, v29
1005e91e0:     	sshll.8h	v29, v19, #0x0
1005e91e4:     	ushll.4s	v25, v25, #0x0
1005e91e8:     	bic.16b	v21, v21, v25
1005e91ec:     	sshll.4s	v25, v29, #0x0
1005e91f0:     	and.16b	v21, v21, v25
1005e91f4:     	mvn.16b	v25, v25
1005e91f8:     	sub.4s	v21, v21, v25
1005e91fc:     	sshll2.8h	v19, v19, #0x0
1005e9200:     	sshll2.4s	v25, v29, #0x0
1005e9204:     	and.16b	v23, v23, v25
1005e9208:     	mvn.16b	v25, v25
1005e920c:     	sub.4s	v23, v23, v25
1005e9210:     	sshll.4s	v25, v19, #0x0
1005e9214:     	and.16b	v27, v27, v25
1005e9218:     	mvn.16b	v25, v25
1005e921c:     	sub.4s	v25, v27, v25
1005e9220:     	sshll2.4s	v19, v19, #0x0
1005e9224:     	and.16b	v27, v28, v19
1005e9228:     	mvn.16b	v19, v19
1005e922c:     	sub.4s	v19, v27, v19
1005e9230:     	add.4s	v7, v22, v7
1005e9234:     	add.4s	v5, v24, v5
1005e9238:     	add.4s	v6, v20, v6
1005e923c:     	add.4s	v3, v26, v3
1005e9240:     	add.4s	v18, v19, v18
1005e9244:     	add.4s	v17, v25, v17
1005e9248:     	add.4s	v0, v23, v0
1005e924c:     	add.4s	v16, v21, v16
1005e9250:     	add	x12, x12, #0x20
1005e9254:     	subs	x13, x13, #0x20
1005e9258:     	b.ne	0x1005e90c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x500>
1005e925c:     	add.4s	v0, v0, v6
1005e9260:     	add.4s	v1, v18, v7
1005e9264:     	add.4s	v2, v16, v3
1005e9268:     	add.4s	v3, v17, v5
1005e926c:     	add.4s	v2, v2, v3
1005e9270:     	add.4s	v0, v0, v1
1005e9274:     	add.4s	v0, v2, v0
1005e9278:     	addv.4s	s0, v0
1005e927c:     	fmov	w20, s0
1005e9280:     	cmp	x8, x10
1005e9284:     	b.eq	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e9288:     	cbz	x11, 0x1005e933c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x778>
1005e928c:     	mov	x12, x10
1005e9290:     	and	x10, x8, #0xfffffffffffffff8
1005e9294:     	movi.2d	v0, #0000000000000000
1005e9298:     	mov.s	v0[0], w20
1005e929c:     	movi.2d	v1, #0000000000000000
1005e92a0:     	sub	x11, x12, x10
1005e92a4:     	add	x12, x9, x12
1005e92a8:     	movi.8b	v2, #0xf0
1005e92ac:     	movi.4s	v3, #0x2
1005e92b0:     	movi.8b	v4, #0xc0
1005e92b4:     	ldr	d5, [x12], #0x8
1005e92b8:     	sshll.8h	v6, v5, #0x0
1005e92bc:     	cmlt.8h	v6, v6, #0
1005e92c0:     	sshll2.4s	v7, v6, #0x0
1005e92c4:     	sshll.4s	v6, v6, #0x0
1005e92c8:     	cmhi.8b	v16, v2, v5
1005e92cc:     	sshll.8h	v16, v16, #0x0
1005e92d0:     	sshll2.4s	v17, v16, #0x0
1005e92d4:     	sshll.4s	v18, v16, #0x0
1005e92d8:     	bic.16b	v18, v3, v18
1005e92dc:     	ssubw.4s	v18, v18, v16
1005e92e0:     	bic.16b	v17, v3, v17
1005e92e4:     	ssubw2.4s	v16, v17, v16
1005e92e8:     	cmgt.8b	v5, v4, v5
1005e92ec:     	sshll.8h	v5, v5, #0x0
1005e92f0:     	ushll.4s	v17, v5, #0x0
1005e92f4:     	ushll2.4s	v5, v5, #0x0
1005e92f8:     	bic.16b	v5, v16, v5
1005e92fc:     	bic.16b	v16, v18, v17
1005e9300:     	and.16b	v16, v16, v6
1005e9304:     	mvn.16b	v6, v6
1005e9308:     	sub.4s	v6, v16, v6
1005e930c:     	and.16b	v5, v5, v7
1005e9310:     	mvn.16b	v7, v7
1005e9314:     	sub.4s	v5, v5, v7
1005e9318:     	add.4s	v1, v5, v1
1005e931c:     	add.4s	v0, v6, v0
1005e9320:     	adds	x11, x11, #0x8
1005e9324:     	b.ne	0x1005e92b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x6f0>
1005e9328:     	add.4s	v0, v0, v1
1005e932c:     	addv.4s	s0, v0
1005e9330:     	fmov	w20, s0
1005e9334:     	cmp	x8, x10
1005e9338:     	b.eq	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
1005e933c:     	sub	x8, x8, x10
1005e9340:     	add	x9, x9, x10
1005e9344:     	mov	w10, #0x1               ; =1
1005e9348:     	ldrsb	w11, [x9], #0x1
1005e934c:     	and	w12, w11, #0xff
1005e9350:     	cmp	w12, #0xf0
1005e9354:     	cinc	w13, w10, hs
1005e9358:     	cmp	w12, #0xc0
1005e935c:     	csel	w12, wzr, w13, lo
1005e9360:     	tst	w11, #0x80000000
1005e9364:     	csinc	w11, w12, wzr, ne
1005e9368:     	add	w20, w11, w20
1005e936c:     	subs	x8, x8, #0x1
1005e9370:     	b.ne	0x1005e9348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x784>
1005e9374:     	b	0x1005e8de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes+0x220>
