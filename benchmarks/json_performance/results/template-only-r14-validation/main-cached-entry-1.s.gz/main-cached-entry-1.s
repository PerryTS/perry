
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/template-only-r14/main-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005038f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>:
1005038f8:     	stp	x28, x27, [sp, #-0x60]!
1005038fc:     	stp	x26, x25, [sp, #0x10]
100503900:     	stp	x24, x23, [sp, #0x20]
100503904:     	stp	x22, x21, [sp, #0x30]
100503908:     	stp	x20, x19, [sp, #0x40]
10050390c:     	stp	x29, x30, [sp, #0x50]
100503910:     	add	x29, sp, #0x50
100503914:     	sub	sp, sp, #0x1a0
100503918:     	mov	x19, x1
10050391c:     	mov	x21, x0
100503920:     	bl	0x1004eb1d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template>
100503924:     	cmp	x0, #0x1
100503928:     	b.ne	0x100503954 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c>
10050392c:     	mov	x23, x1
100503930:     	mov	x0, x23
100503934:     	add	sp, sp, #0x1a0
100503938:     	ldp	x29, x30, [sp, #0x50]
10050393c:     	ldp	x20, x19, [sp, #0x40]
100503940:     	ldp	x22, x21, [sp, #0x30]
100503944:     	ldp	x24, x23, [sp, #0x20]
100503948:     	ldp	x26, x25, [sp, #0x10]
10050394c:     	ldp	x28, x27, [sp], #0x60
100503950:     	ret
100503954:     	add	x24, x21, #0x14
100503958:     	cmp	x19, #0x2
10050395c:     	b.ne	0x100503974 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c>
100503960:     	ldrh	w8, [x24]
100503964:     	mov	w9, #0x7d7b             ; =32123
100503968:     	cmp	w8, w9
10050396c:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503970:     	b	0x100503a0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x114>
100503974:     	cmp	x19, #0x3
100503978:     	b.hs	0x1005039e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe8>
10050397c:     	add	x0, sp, #0xa0
100503980:     	add	x1, x21, #0x14
100503984:     	mov	x2, x19
100503988:     	bl	0x1004f3bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object6decode>
10050398c:     	ldr	w8, [sp, #0xa0]
100503990:     	tbz	w8, #0x0, 0x100503ae4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100503994:     	add	x8, sp, #0xa0
100503998:     	ldr	x9, [sp, #0x128]
10050399c:     	str	x9, [sp, #0x90]
1005039a0:     	ldur	q0, [x8, #0x48]
1005039a4:     	ldur	q1, [x8, #0x58]
1005039a8:     	stp	q0, q1, [sp, #0x50]
1005039ac:     	ldur	q0, [x8, #0x68]
1005039b0:     	ldur	q1, [x8, #0x78]
1005039b4:     	stp	q0, q1, [sp, #0x70]
1005039b8:     	ldur	q0, [x8, #0x8]
1005039bc:     	ldur	q1, [x8, #0x18]
1005039c0:     	stp	q0, q1, [sp, #0x10]
1005039c4:     	ldur	q0, [x8, #0x28]
1005039c8:     	ldur	q1, [x8, #0x38]
1005039cc:     	stp	q0, q1, [sp, #0x30]
1005039d0:     	add	x0, sp, #0x10
1005039d4:     	bl	0x1004f4388 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object8allocate>
1005039d8:     	tbnz	w0, #0x0, 0x10050392c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x34>
1005039dc:     	b	0x100503ae4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
1005039e0:     	ldrb	w20, [x24]
1005039e4:     	cmp	w20, #0x20
1005039e8:     	b.hi	0x100503a2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x134>
1005039ec:     	mov	x8, #0x2600             ; =9728
1005039f0:     	movk	x8, #0x1, lsl #32
1005039f4:     	lsr	x8, x8, x20
1005039f8:     	tbz	w8, #0x0, 0x100503a2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x134>
1005039fc:     	add	x0, x21, #0x14
100503a00:     	mov	x1, x19
100503a04:     	bl	0x1004ea3a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty19padded_empty_object>
100503a08:     	tbz	w0, #0x0, 0x100503a58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160>
100503a0c:     	add	sp, sp, #0x1a0
100503a10:     	ldp	x29, x30, [sp, #0x50]
100503a14:     	ldp	x20, x19, [sp, #0x40]
100503a18:     	ldp	x22, x21, [sp, #0x30]
100503a1c:     	ldp	x24, x23, [sp, #0x20]
100503a20:     	ldp	x26, x25, [sp, #0x10]
100503a24:     	ldp	x28, x27, [sp], #0x60
100503a28:     	b	0x1004ea480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100503a2c:     	cmp	w20, #0x7b
100503a30:     	b.ne	0x100503a58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160>
100503a34:     	ldrb	w8, [x21, #0x15]
100503a38:     	cmp	w8, #0x20
100503a3c:     	b.hi	0x100503a50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x158>
100503a40:     	mov	x9, #0x2600             ; =9728
100503a44:     	movk	x9, #0x1, lsl #32
100503a48:     	lsr	x9, x9, x8
100503a4c:     	tbnz	w9, #0x0, 0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100503a50:     	cmp	w8, #0x7d
100503a54:     	b.eq	0x1005039fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100503a58:     	cmp	x19, #0x41
100503a5c:     	b.hs	0x100503ae4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100503a60:     	cmp	w20, #0x7b
100503a64:     	ccmp	x19, #0x7, #0x0, eq
100503a68:     	b.lo	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503a6c:     	add	x8, x24, x19
100503a70:     	ldurb	w8, [x8, #-0x1]
100503a74:     	cmp	w8, #0x7d
100503a78:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503a7c:     	ldrb	w8, [x21, #0x15]
100503a80:     	cmp	w8, #0x22
100503a84:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503a88:     	sub	x9, x19, #0x1
100503a8c:     	mov	x22, x21
100503a90:     	ldrb	w25, [x22, #0x16]!
100503a94:     	cmp	w25, #0x22
100503a98:     	b.ne	0x100503b28 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x230>
100503a9c:     	mov	w23, #0x0               ; =0
100503aa0:     	mov	w28, #0x0               ; =0
100503aa4:     	mov	w27, #0x0               ; =0
100503aa8:     	mov	w26, #0x0               ; =0
100503aac:     	mov	x20, #0x0               ; =0
100503ab0:     	cmp	w25, #0x22
100503ab4:     	b.ne	0x100503b54 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x25c>
100503ab8:     	add	x8, sp, #0xa0
100503abc:     	mov	x0, x22
100503ac0:     	mov	x1, x20
100503ac4:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100503ac8:     	sub	x11, x19, #0x1
100503acc:     	ldr	w8, [sp, #0xa0]
100503ad0:     	tbnz	w8, #0x0, 0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503ad4:     	cmp	w25, #0x22
100503ad8:     	b.ne	0x100503bf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x300>
100503adc:     	mov	x8, #0x0                ; =0
100503ae0:     	b	0x100503c2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503ae4:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100503ae8:     	add	x8, x8, #0x2d8
100503aec:     	ldapr	x8, [x8]
100503af0:     	cbnz	x8, 0x100503cc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3cc>
100503af4:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100503af8:     	ldrb	w8, [x8, #0x2e0]
100503afc:     	adrp	x12, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100503b00:     	adrp	x27, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100503b04:     	cbz	w8, 0x100503cdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3e4>
100503b08:     	cmp	w8, #0x1
100503b0c:     	b.ne	0x100503d18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100503b10:     	mov	w28, #0x1               ; =1
100503b14:     	mov	w8, #0x1000000          ; =16777216
100503b18:     	mov	w22, #0x1               ; =1
100503b1c:     	cmp	x19, x8
100503b20:     	b.hi	0x100503d1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x424>
100503b24:     	b	0x100503e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x508>
100503b28:     	cmp	x9, #0x3
100503b2c:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503b30:     	ldrb	w8, [x21, #0x17]
100503b34:     	cmp	w8, #0x22
100503b38:     	b.ne	0x100503bcc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x2d4>
100503b3c:     	mov	w28, #0x0               ; =0
100503b40:     	mov	w27, #0x0               ; =0
100503b44:     	mov	w26, #0x0               ; =0
100503b48:     	mov	w23, #0x1               ; =1
100503b4c:     	mov	w20, #0x1               ; =1
100503b50:     	b	0x100503ab0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100503b54:     	ldrb	w8, [x22]
100503b58:     	cmp	w8, #0x20
100503b5c:     	b.lo	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503b60:     	cmp	w8, #0x5c
100503b64:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503b68:     	tbnz	w23, #0x0, 0x100503ab8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503b6c:     	ldrb	w8, [x21, #0x17]
100503b70:     	cmp	w8, #0x20
100503b74:     	b.lo	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503b78:     	cmp	w8, #0x5c
100503b7c:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503b80:     	tbnz	w28, #0x0, 0x100503ab8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503b84:     	ldrb	w8, [x21, #0x18]
100503b88:     	cmp	w8, #0x20
100503b8c:     	b.lo	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503b90:     	cmp	w8, #0x5c
100503b94:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503b98:     	tbnz	w27, #0x0, 0x100503ab8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503b9c:     	ldrb	w8, [x21, #0x19]
100503ba0:     	cmp	w8, #0x20
100503ba4:     	b.lo	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503ba8:     	cmp	w8, #0x5c
100503bac:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503bb0:     	tbnz	w26, #0x0, 0x100503ab8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503bb4:     	ldrb	w8, [x21, #0x1a]
100503bb8:     	cmp	w8, #0x20
100503bbc:     	b.lo	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503bc0:     	cmp	w8, #0x5c
100503bc4:     	b.ne	0x100503ab8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100503bc8:     	b	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503bcc:     	cmp	x9, #0x4
100503bd0:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503bd4:     	ldrb	w8, [x21, #0x18]
100503bd8:     	cmp	w8, #0x22
100503bdc:     	b.ne	0x100503c98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3a0>
100503be0:     	mov	w23, #0x0               ; =0
100503be4:     	mov	w27, #0x0               ; =0
100503be8:     	mov	w26, #0x0               ; =0
100503bec:     	mov	w28, #0x1               ; =1
100503bf0:     	mov	w20, #0x2               ; =2
100503bf4:     	b	0x100503ab0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100503bf8:     	ldrb	w8, [x22]
100503bfc:     	tbnz	w23, #0x0, 0x100503c2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503c00:     	ldrb	w9, [x21, #0x17]
100503c04:     	orr	x8, x8, x9, lsl #8
100503c08:     	tbnz	w28, #0x0, 0x100503c2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503c0c:     	ldrb	w9, [x21, #0x18]
100503c10:     	orr	x8, x8, x9, lsl #16
100503c14:     	tbnz	w27, #0x0, 0x100503c2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503c18:     	ldrb	w9, [x21, #0x19]
100503c1c:     	orr	x8, x8, x9, lsl #24
100503c20:     	tbnz	w26, #0x0, 0x100503c2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100503c24:     	ldrb	w9, [x21, #0x1a]
100503c28:     	orr	x8, x8, x9, lsl #32
100503c2c:     	add	x9, x20, #0x3
100503c30:     	cmp	x9, x19
100503c34:     	b.hs	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c38:     	ldrb	w9, [x24, x9]
100503c3c:     	cmp	w9, #0x3a
100503c40:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c44:     	add	x10, x20, #0x4
100503c48:     	subs	x9, x11, x10
100503c4c:     	b.lo	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c50:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c54:     	orr	x25, x8, x20, lsl #40
100503c58:     	mov	x26, #0x7ff9000000000000 ; =9221401712017801216
100503c5c:     	add	x8, x24, x10
100503c60:     	mov	x10, #0x2600            ; =9728
100503c64:     	movk	x10, #0x1, lsl #32
100503c68:     	mov	x11, x9
100503c6c:     	mov	x12, x8
100503c70:     	b	0x100503c80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x388>
100503c74:     	add	x12, x12, #0x1
100503c78:     	subs	x11, x11, #0x1
100503c7c:     	b.eq	0x100504b24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x122c>
100503c80:     	ldrb	w13, [x12]
100503c84:     	cmp	w13, #0x20
100503c88:     	b.hi	0x100503c74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x37c>
100503c8c:     	lsr	x13, x10, x13
100503c90:     	tbz	w13, #0x0, 0x100503c74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x37c>
100503c94:     	b	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503c98:     	cmp	x9, #0x5
100503c9c:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100503ca0:     	ldrb	w8, [x21, #0x19]
100503ca4:     	cmp	w8, #0x22
100503ca8:     	b.ne	0x100504a70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1178>
100503cac:     	mov	w23, #0x0               ; =0
100503cb0:     	mov	w28, #0x0               ; =0
100503cb4:     	mov	w26, #0x0               ; =0
100503cb8:     	mov	w27, #0x1               ; =1
100503cbc:     	mov	w20, #0x3               ; =3
100503cc0:     	b	0x100503ab0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100503cc4:     	bl	0x100b16b44 <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockNtNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api8TapeModeE10initializeNCINvB2_11get_or_initNCNvBV_18tape_mode_from_env0E0zEBZ_>
100503cc8:     	adrp	x8, 0x100f7d000 <__MergedGlobals+0xb8>
100503ccc:     	ldrb	w8, [x8, #0x2e0]
100503cd0:     	adrp	x12, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100503cd4:     	adrp	x27, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100503cd8:     	cbnz	w8, 0x100503b08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x210>
100503cdc:     	sub	x8, x19, #0x400
100503ce0:     	mov	w9, #0xfffc00           ; =16776192
100503ce4:     	cmp	x8, x9
100503ce8:     	b.hi	0x100503d18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100503cec:     	mov	x8, #0x0                ; =0
100503cf0:     	mov	x9, #0x2600             ; =9728
100503cf4:     	movk	x9, #0x1, lsl #32
100503cf8:     	ldrb	w10, [x24, x8]
100503cfc:     	cmp	w10, #0x20
100503d00:     	b.hi	0x1005041f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x900>
100503d04:     	lsr	x11, x9, x10
100503d08:     	tbz	w11, #0x0, 0x1005041f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x900>
100503d0c:     	add	x8, x8, #0x1
100503d10:     	cmp	x19, x8
100503d14:     	b.ne	0x100503cf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x400>
100503d18:     	mov	w22, #0x0               ; =0
100503d1c:     	ldr	w20, [x12, #0x560]
100503d20:     	cmp	w20, #0x300
100503d24:     	b.hs	0x1005041d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d8>
100503d28:     	ldr	x8, [x27, #0x48]
100503d2c:     	cmn	x8, #0x1
100503d30:     	b.eq	0x1005041c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8c8>
100503d34:     	mrs	x9, TPIDRRO_EL0
100503d38:     	and	x9, x9, #0xfffffffffffffff8
100503d3c:     	ldr	x0, [x9, x8, lsl #3]
100503d40:     	cbz	x0, 0x1005041c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8c8>
100503d44:     	add	x8, x0, x20, lsl #3
100503d48:     	ldr	x0, [x8, #0x1e8]
100503d4c:     	cbz	x0, 0x1005041d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d8>
100503d50:     	ldr	x8, [x0]
100503d54:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100503d58:     	cmp	x8, x9
100503d5c:     	b.hs	0x1005041ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8f4>
100503d60:     	ldrb	w8, [x0, #0x24]
100503d64:     	cmp	w8, #0x2
100503d68:     	b.eq	0x100503d78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x480>
100503d6c:     	ldr	x9, [x0, #0x8]
100503d70:     	cmp	x9, x21
100503d74:     	b.eq	0x100503de0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4e8>
100503d78:     	cmp	x19, #0x3e9
100503d7c:     	b.lo	0x100503dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100503d80:     	mov	x8, #0x0                ; =0
100503d84:     	mov	x9, #0x2600             ; =9728
100503d88:     	movk	x9, #0x1, lsl #32
100503d8c:     	add	x10, x21, x8
100503d90:     	ldrb	w10, [x10, #0x14]
100503d94:     	cmp	w10, #0x20
100503d98:     	b.hi	0x100503db4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4bc>
100503d9c:     	lsr	x11, x9, x10
100503da0:     	tbz	w11, #0x0, 0x100503db4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4bc>
100503da4:     	add	x8, x8, #0x1
100503da8:     	cmp	x19, x8
100503dac:     	b.ne	0x100503d8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x494>
100503db0:     	b	0x100503dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100503db4:     	cmp	w10, #0x5b
100503db8:     	b.eq	0x100503dc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4cc>
100503dbc:     	cmp	w10, #0x7b
100503dc0:     	b.ne	0x100503dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100503dc4:     	add	x0, x21, #0x14
100503dc8:     	mov	x1, x19
100503dcc:     	mov	w2, #0x3e8              ; =1000
100503dd0:     	bl	0x1006c2814 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
100503dd4:     	cbz	w0, 0x100503dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100503dd8:     	mov	x0, x21
100503ddc:     	b	0x100504a30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1138>
100503de0:     	ldr	w9, [x0, #0x18]
100503de4:     	cmp	x19, x9
100503de8:     	cset	w9, eq
100503dec:     	and	w8, w9, w8
100503df0:     	cmp	x19, #0x3e9
100503df4:     	csinc	w8, w8, wzr, hs
100503df8:     	tbz	w8, #0x0, 0x100503d80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x488>
100503dfc:     	mov	w28, #0x0               ; =0
100503e00:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100503e04:     	add	x0, x0, #0xce8
100503e08:     	ldr	x8, [x0]
100503e0c:     	blr	x8
100503e10:     	mov	x20, x0
100503e14:     	ldrb	w8, [x0, #0x20]
100503e18:     	cbnz	w8, 0x100504988 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1090>
100503e1c:     	ldr	x8, [x20]
100503e20:     	cbnz	x8, 0x100504a04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100503e24:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
100503e28:     	bfxil	x23, x21, #0, #48
100503e2c:     	mov	x8, #-0x1               ; =-1
100503e30:     	str	x8, [x20]
100503e34:     	ldr	x21, [x20, #0x18]
100503e38:     	ldr	x8, [x20, #0x8]
100503e3c:     	cmp	x21, x8
100503e40:     	b.eq	0x100504184 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x88c>
100503e44:     	ldr	x8, [x20, #0x10]
100503e48:     	str	x23, [x8, x21, lsl #3]
100503e4c:     	add	x8, x21, #0x1
100503e50:     	str	x8, [x20, #0x18]
100503e54:     	ldr	x8, [x20]
100503e58:     	add	x8, x8, #0x1
100503e5c:     	str	x8, [x20]
100503e60:     	adrp	x24, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100503e64:     	ldr	w23, [x24, #0x948]
100503e68:     	cmp	w23, #0x300
100503e6c:     	b.hs	0x1005041a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8a8>
100503e70:     	ldr	x8, [x27, #0x48]
100503e74:     	cmn	x8, #0x1
100503e78:     	b.eq	0x100504190 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x898>
100503e7c:     	mrs	x9, TPIDRRO_EL0
100503e80:     	and	x9, x9, #0xfffffffffffffff8
100503e84:     	ldr	x0, [x9, x8, lsl #3]
100503e88:     	cbz	x0, 0x100504190 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x898>
100503e8c:     	add	x8, x0, x23, lsl #3
100503e90:     	ldr	x0, [x8, #0x1e8]
100503e94:     	cbz	x0, 0x1005041a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8a8>
100503e98:     	ldrb	w8, [x0]
100503e9c:     	cbnz	w8, 0x1005041b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8bc>
100503ea0:     	tbz	w22, #0x0, 0x100504528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100503ea4:     	ldrb	w8, [x20, #0x20]
100503ea8:     	cbnz	w8, 0x100504a40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1148>
100503eac:     	ldr	x8, [x20]
100503eb0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100503eb4:     	cmp	x8, x9
100503eb8:     	b.hs	0x100504b84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100503ebc:     	add	x9, x8, #0x1
100503ec0:     	str	x9, [x20]
100503ec4:     	ldr	x9, [x20, #0x18]
100503ec8:     	cmp	x21, x9
100503ecc:     	b.hs	0x100503ee0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5e8>
100503ed0:     	ldr	x9, [x20, #0x10]
100503ed4:     	ldr	x9, [x9, x21, lsl #3]
100503ed8:     	and	x23, x9, #0xffffffffffff
100503edc:     	b	0x100503ee4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5ec>
100503ee0:     	mov	w23, #0x1               ; =1
100503ee4:     	str	x8, [x20]
100503ee8:     	adrp	x0, 0x100f84000 <__RNvNCNKNvNtCs3gRpqoBkMHm_13perry_runtime7process29PROCESS_FINALIZATION_EXIT_RAN0s_023___RUST_STD_INTERNAL_VAL>
100503eec:     	add	x0, x0, #0x168
100503ef0:     	ldr	x8, [x0]
100503ef4:     	blr	x8
100503ef8:     	mov	x22, x0
100503efc:     	ldrb	w8, [x0, #0x30]
100503f00:     	cmp	w8, #0x1
100503f04:     	b.ne	0x100504a10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1118>
100503f08:     	ldr	x8, [x22]
100503f0c:     	mov	x10, #-0x1              ; =-1
100503f10:     	mov	x9, x22
100503f14:     	str	x10, [x9], #0x8
100503f18:     	cmn	x8, #0x1
100503f1c:     	b.eq	0x100503f3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x644>
100503f20:     	add	x10, sp, #0xa0
100503f24:     	ldp	q0, q1, [x9]
100503f28:     	ldr	x9, [x9, #0x20]
100503f2c:     	stur	x9, [x10, #0x28]
100503f30:     	stur	q1, [x10, #0x18]
100503f34:     	stur	q0, [x10, #0x8]
100503f38:     	b	0x100503f50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x658>
100503f3c:     	mov	x8, #0x0                ; =0
100503f40:     	mov	w9, #0x4                ; =4
100503f44:     	stp	x9, xzr, [sp, #0xa8]
100503f48:     	stp	xzr, x9, [sp, #0xb8]
100503f4c:     	str	xzr, [sp, #0xc8]
100503f50:     	str	x8, [sp, #0xa0]
100503f54:     	stur	xzr, [x29, #-0x78]
100503f58:     	add	x8, sp, #0xa0
100503f5c:     	add	x0, x23, #0x14
100503f60:     	add	x2, sp, #0xa0
100503f64:     	add	x3, x8, #0x18
100503f68:     	sub	x4, x29, #0x78
100503f6c:     	mov	x1, x19
100503f70:     	bl	0x10014e764 <__RINvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15build_tape_intoKb1_EB4_>
100503f74:     	tbz	w0, #0x0, 0x100504084 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x78c>
100503f78:     	ldur	x23, [x29, #-0x78]
100503f7c:     	ldr	w24, [x24, #0x948]
100503f80:     	cmp	w24, #0x300
100503f84:     	b.hs	0x10050489c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa4>
100503f88:     	ldr	x8, [x27, #0x48]
100503f8c:     	cmn	x8, #0x1
100503f90:     	b.eq	0x10050488c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf94>
100503f94:     	mrs	x9, TPIDRRO_EL0
100503f98:     	and	x9, x9, #0xfffffffffffffff8
100503f9c:     	ldr	x0, [x9, x8, lsl #3]
100503fa0:     	cbz	x0, 0x10050488c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf94>
100503fa4:     	add	x8, x0, x24, lsl #3
100503fa8:     	ldr	x0, [x8, #0x1e8]
100503fac:     	cbz	x0, 0x10050489c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa4>
100503fb0:     	ldrb	w8, [x0]
100503fb4:     	cbnz	w8, 0x1005048b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfb8>
100503fb8:     	bl	0x1004eda80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100503fbc:     	bl	0x100457940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
100503fc0:     	mov	x0, x19
100503fc4:     	bl	0x10022fa2c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
100503fc8:     	mov	x24, x0
100503fcc:     	mov	x25, x1
100503fd0:     	bl	0x100457754 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
100503fd4:     	ldrb	w8, [x20, #0x20]
100503fd8:     	cbnz	w8, 0x100504acc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11d4>
100503fdc:     	ldr	x8, [x20]
100503fe0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100503fe4:     	cmp	x8, x9
100503fe8:     	b.hs	0x100504b84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100503fec:     	add	x9, x8, #0x1
100503ff0:     	str	x9, [x20]
100503ff4:     	ldr	x9, [x20, #0x18]
100503ff8:     	cmp	x21, x9
100503ffc:     	b.hs	0x10050411c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x824>
100504000:     	ldr	x9, [x20, #0x10]
100504004:     	ldr	x9, [x9, x21, lsl #3]
100504008:     	and	x2, x9, #0xffffffffffff
10050400c:     	stp	x25, x24, [sp]
100504010:     	str	x8, [x20]
100504014:     	add	x26, x2, #0x14
100504018:     	cmp	x23, #0x3e8
10050401c:     	b.hi	0x100504134 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x83c>
100504020:     	ldp	x24, x25, [sp, #0xa8]
100504024:     	cbz	x25, 0x100504150 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x858>
100504028:     	ldrb	w8, [x24, #0x8]
10050402c:     	cmp	w8, #0x3
100504030:     	b.ne	0x100504150 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x858>
100504034:     	ldr	w8, [x24, #0x4]
100504038:     	cmp	w8, #0x2
10050403c:     	b.lo	0x100504220 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x928>
100504040:     	mov	w1, #0x0                ; =0
100504044:     	mov	w0, #0x1                ; =1
100504048:     	mov	w9, #0xc                ; =12
10050404c:     	b	0x100504060 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x768>
100504050:     	add	x0, x0, #0x1
100504054:     	add	w1, w1, #0x1
100504058:     	cmp	x0, x8
10050405c:     	b.hs	0x100504224 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x92c>
100504060:     	cmp	x0, x25
100504064:     	b.hs	0x100504c80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1388>
100504068:     	madd	x10, x0, x9, x24
10050406c:     	ldrb	w11, [x10, #0x8]
100504070:     	orr	w11, w11, #0x2
100504074:     	cmp	w11, #0x3
100504078:     	b.ne	0x100504050 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x758>
10050407c:     	ldr	w0, [x10, #0x4]
100504080:     	b	0x100504050 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x758>
100504084:     	str	xzr, [sp, #0xb0]
100504088:     	str	xzr, [sp, #0xc8]
10050408c:     	ldr	x8, [sp, #0xa0]
100504090:     	add	x9, x8, x8, lsl #1
100504094:     	lsl	x9, x9, #2
100504098:     	cmp	x9, #0x100, lsl #12     ; =0x100000
10050409c:     	b.ls	0x1005040b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c0>
1005040a0:     	cbz	x8, 0x1005040ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7b4>
1005040a4:     	ldr	x0, [sp, #0xa8]
1005040a8:     	bl	0x100b5cd00 <_mi_free>
1005040ac:     	mov	w8, #0x4                ; =4
1005040b0:     	stp	xzr, x8, [sp, #0xa0]
1005040b4:     	str	xzr, [sp, #0xb0]
1005040b8:     	ldr	x8, [sp, #0xb8]
1005040bc:     	lsl	x9, x8, #2
1005040c0:     	cmp	x9, #0x10, lsl #12      ; =0x10000
1005040c4:     	b.ls	0x1005040e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7e8>
1005040c8:     	cbz	x8, 0x1005040d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7dc>
1005040cc:     	ldr	x0, [sp, #0xc0]
1005040d0:     	bl	0x100b5cd00 <_mi_free>
1005040d4:     	mov	w8, #0x4                ; =4
1005040d8:     	stp	xzr, x8, [sp, #0xb8]
1005040dc:     	str	xzr, [sp, #0xc8]
1005040e0:     	ldp	x8, x0, [x22]
1005040e4:     	ldp	x24, x23, [x22, #0x18]
1005040e8:     	ldp	q1, q0, [sp, #0xb0]
1005040ec:     	ldr	q2, [sp, #0xa0]
1005040f0:     	stp	q2, q1, [x22]
1005040f4:     	str	q0, [x22, #0x20]
1005040f8:     	cmn	x8, #0x1
1005040fc:     	b.eq	0x100504114 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x81c>
100504100:     	cbz	x8, 0x100504108 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x810>
100504104:     	bl	0x100b5cd00 <_mi_free>
100504108:     	cbz	x24, 0x100504114 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x81c>
10050410c:     	mov	x0, x23
100504110:     	bl	0x100b5cd00 <_mi_free>
100504114:     	ldrb	w8, [x20, #0x20]
100504118:     	b	0x10050444c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb54>
10050411c:     	mov	w2, #0x1                ; =1
100504120:     	stp	x25, x24, [sp]
100504124:     	str	x8, [x20]
100504128:     	add	x26, x2, #0x14
10050412c:     	cmp	x23, #0x3e8
100504130:     	b.ls	0x100504020 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x728>
100504134:     	ldp	x0, x1, [sp, #0xa8]
100504138:     	mov	x2, x26
10050413c:     	mov	x3, x19
100504140:     	bl	0x1006862d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape9iterative21materialize_iterative>
100504144:     	tbz	w0, #0x0, 0x10050417c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x884>
100504148:     	mov	x25, x1
10050414c:     	b	0x100504274 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x97c>
100504150:     	bl	0x100288f98 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100504154:     	stp	x0, xzr, [x29, #-0x70]
100504158:     	stp	x24, x25, [sp, #0x10]
10050415c:     	stp	x26, x19, [sp, #0x20]
100504160:     	add	x0, sp, #0x10
100504164:     	sub	x1, x29, #0x68
100504168:     	bl	0x100375960 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24materialize_value_source>
10050416c:     	mov	x25, x0
100504170:     	sub	x0, x29, #0x70
100504174:     	bl	0x1001649fc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100504178:     	b	0x100504274 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x97c>
10050417c:     	mov	w25, #0x0               ; =0
100504180:     	b	0x1005042bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9c4>
100504184:     	add	x0, x20, #0x8
100504188:     	bl	0x100b39a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10050418c:     	b	0x100503e44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x54c>
100504190:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504194:     	add	x8, x0, x23, lsl #3
100504198:     	ldr	x0, [x8, #0x1e8]
10050419c:     	cbnz	x0, 0x100503e98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5a0>
1005041a0:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1005041a4:     	add	x0, x0, #0xca8
1005041a8:     	bl	0x100b3a9a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1005041ac:     	ldrb	w8, [x0]
1005041b0:     	cbz	w8, 0x100503ea0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5a8>
1005041b4:     	bl	0x100b420dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
1005041b8:     	tbnz	w22, #0x0, 0x100503ea4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5ac>
1005041bc:     	b	0x100504528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
1005041c0:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005041c4:     	add	x8, x0, x20, lsl #3
1005041c8:     	ldr	x0, [x8, #0x1e8]
1005041cc:     	cbnz	x0, 0x100503d50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x458>
1005041d0:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1005041d4:     	add	x0, x0, #0xfa0
1005041d8:     	bl	0x100b3a95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005041dc:     	ldr	x8, [x0]
1005041e0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005041e4:     	cmp	x8, x9
1005041e8:     	b.lo	0x100503d60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x468>
1005041ec:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1005041f0:     	add	x0, x0, #0xd10
1005041f4:     	bl	0x100b1049c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1005041f8:     	cmp	w10, #0x5b
1005041fc:     	cset	w22, eq
100504200:     	mov	w8, #0x1000000          ; =16777216
100504204:     	cmp	x19, x8
100504208:     	mov	w8, #0x5b               ; =91
10050420c:     	ccmp	w10, w8, #0x0, ls
100504210:     	b.ne	0x100503d1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x424>
100504214:     	mov	w28, #0x1               ; =1
100504218:     	mov	w22, #0x1               ; =1
10050421c:     	b	0x100503e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x508>
100504220:     	mov	w1, #0x0                ; =0
100504224:     	ldr	x8, [sp, #0xa0]
100504228:     	add	x8, x8, x8, lsl #1
10050422c:     	lsl	x8, x8, #2
100504230:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100504234:     	b.ls	0x100504258 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x960>
100504238:     	ldr	q0, [sp, #0xa0]
10050423c:     	str	q0, [sp, #0x10]
100504240:     	ldr	x8, [sp, #0xb0]
100504244:     	str	x8, [sp, #0x20]
100504248:     	mov	w8, #0x4                ; =4
10050424c:     	stp	xzr, x8, [sp, #0xa0]
100504250:     	str	xzr, [sp, #0xb0]
100504254:     	b	0x100504264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x96c>
100504258:     	stp	x24, x25, [sp, #0x18]
10050425c:     	mov	x8, #-0x1               ; =-1
100504260:     	str	x8, [sp, #0x10]
100504264:     	add	x0, sp, #0x10
100504268:     	bl	0x100374ab0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24alloc_lazy_array_backing>
10050426c:     	mov	x25, #0x7ffd000000000000 ; =9222527611924643840
100504270:     	bfxil	x25, x0, #0, #48
100504274:     	ldrb	w8, [x20, #0x20]
100504278:     	cbnz	w8, 0x100504afc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1204>
10050427c:     	ldr	x8, [x20]
100504280:     	cbnz	x8, 0x100504a04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100504284:     	mov	x8, #-0x1               ; =-1
100504288:     	str	x8, [x20]
10050428c:     	ldr	x26, [x20, #0x18]
100504290:     	ldr	x8, [x20, #0x8]
100504294:     	cmp	x26, x8
100504298:     	b.eq	0x10050492c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1034>
10050429c:     	ldr	x8, [x20, #0x10]
1005042a0:     	str	x25, [x8, x26, lsl #3]
1005042a4:     	add	x8, x26, #0x1
1005042a8:     	str	x8, [x20, #0x18]
1005042ac:     	ldr	x8, [x20]
1005042b0:     	add	x8, x8, #0x1
1005042b4:     	str	x8, [x20]
1005042b8:     	mov	w25, #0x1               ; =1
1005042bc:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1005042c0:     	ldr	w24, [x8, #0x308]
1005042c4:     	cmp	w24, #0x300
1005042c8:     	b.hs	0x1005048c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd0>
1005042cc:     	ldr	x8, [x27, #0x48]
1005042d0:     	cmn	x8, #0x1
1005042d4:     	b.eq	0x1005048b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfc0>
1005042d8:     	mrs	x9, TPIDRRO_EL0
1005042dc:     	and	x9, x9, #0xfffffffffffffff8
1005042e0:     	ldr	x0, [x9, x8, lsl #3]
1005042e4:     	cbz	x0, 0x1005048b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfc0>
1005042e8:     	add	x8, x0, x24, lsl #3
1005042ec:     	ldr	x0, [x8, #0x1e8]
1005042f0:     	cbz	x0, 0x1005048c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd0>
1005042f4:     	ldrb	w8, [x0]
1005042f8:     	and	w8, w8, #0xfffffffd
1005042fc:     	strb	w8, [x0]
100504300:     	mov	w0, #0x0                ; =0
100504304:     	bl	0x10045b080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
100504308:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
10050430c:     	ldr	w24, [x8, #0x590]
100504310:     	cmp	w24, #0x300
100504314:     	b.hs	0x1005048e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff0>
100504318:     	ldr	x8, [x27, #0x48]
10050431c:     	cmn	x8, #0x1
100504320:     	b.eq	0x1005048d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfe0>
100504324:     	mrs	x9, TPIDRRO_EL0
100504328:     	and	x9, x9, #0xfffffffffffffff8
10050432c:     	ldr	x0, [x9, x8, lsl #3]
100504330:     	cbz	x0, 0x1005048d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfe0>
100504334:     	add	x8, x0, x24, lsl #3
100504338:     	ldr	x0, [x8, #0x1e8]
10050433c:     	cbz	x0, 0x1005048e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff0>
100504340:     	ldr	x8, [x0]
100504344:     	lsr	x8, x8, #25
100504348:     	cbz	x8, 0x100504900 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1008>
10050434c:     	bl	0x10045ce34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100504350:     	cmp	x23, #0x3e8
100504354:     	b.hi	0x100504908 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1010>
100504358:     	ldp	x1, x0, [sp]
10050435c:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100504360:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100504364:     	ldr	x8, [x8, #0x758]
100504368:     	cbnz	x8, 0x100504920 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1028>
10050436c:     	tbz	w25, #0x0, 0x1005043b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xabc>
100504370:     	ldrb	w8, [x20, #0x20]
100504374:     	cbnz	w8, 0x100504b58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1260>
100504378:     	ldr	x8, [x20]
10050437c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504380:     	cmp	x8, x9
100504384:     	b.hs	0x100504b84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504388:     	add	x9, x8, #0x1
10050438c:     	str	x9, [x20]
100504390:     	ldr	x9, [x20, #0x18]
100504394:     	cmp	x26, x9
100504398:     	b.hs	0x1005043a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xab0>
10050439c:     	ldr	x9, [x20, #0x10]
1005043a0:     	ldr	x23, [x9, x26, lsl #3]
1005043a4:     	b	0x1005043b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xab8>
1005043a8:     	mov	x23, #0x1               ; =1
1005043ac:     	movk	x23, #0x7ffc, lsl #48
1005043b0:     	str	x8, [x20]
1005043b4:     	str	xzr, [sp, #0xb0]
1005043b8:     	str	xzr, [sp, #0xc8]
1005043bc:     	ldr	x8, [sp, #0xa0]
1005043c0:     	add	x9, x8, x8, lsl #1
1005043c4:     	lsl	x9, x9, #2
1005043c8:     	cmp	x9, #0x100, lsl #12     ; =0x100000
1005043cc:     	b.ls	0x1005043e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xaf0>
1005043d0:     	cbz	x8, 0x1005043dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xae4>
1005043d4:     	ldr	x0, [sp, #0xa8]
1005043d8:     	bl	0x100b5cd00 <_mi_free>
1005043dc:     	mov	w8, #0x4                ; =4
1005043e0:     	stp	xzr, x8, [sp, #0xa0]
1005043e4:     	str	xzr, [sp, #0xb0]
1005043e8:     	ldr	x8, [sp, #0xb8]
1005043ec:     	lsl	x9, x8, #2
1005043f0:     	cmp	x9, #0x10, lsl #12      ; =0x10000
1005043f4:     	b.ls	0x100504410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb18>
1005043f8:     	cbz	x8, 0x100504404 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb0c>
1005043fc:     	ldr	x0, [sp, #0xc0]
100504400:     	bl	0x100b5cd00 <_mi_free>
100504404:     	mov	w8, #0x4                ; =4
100504408:     	stp	xzr, x8, [sp, #0xb8]
10050440c:     	str	xzr, [sp, #0xc8]
100504410:     	ldp	x8, x0, [x22]
100504414:     	ldp	x26, x24, [x22, #0x18]
100504418:     	ldp	q1, q0, [sp, #0xb0]
10050441c:     	ldr	q2, [sp, #0xa0]
100504420:     	stp	q2, q1, [x22]
100504424:     	str	q0, [x22, #0x20]
100504428:     	cmn	x8, #0x1
10050442c:     	b.eq	0x1005044dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbe4>
100504430:     	cbz	x8, 0x100504438 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb40>
100504434:     	bl	0x100b5cd00 <_mi_free>
100504438:     	cbz	x26, 0x1005044dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbe4>
10050443c:     	mov	x0, x24
100504440:     	bl	0x100b5cd00 <_mi_free>
100504444:     	ldrb	w8, [x20, #0x20]
100504448:     	tbnz	w25, #0x0, 0x1005044e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbec>
10050444c:     	cbnz	w8, 0x100504a9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11a4>
100504450:     	ldr	x8, [x20]
100504454:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504458:     	cmp	x8, x9
10050445c:     	b.hs	0x100504b84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504460:     	add	x9, x8, #0x1
100504464:     	str	x9, [x20]
100504468:     	ldr	x9, [x20, #0x18]
10050446c:     	cmp	x21, x9
100504470:     	b.hs	0x100504494 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb9c>
100504474:     	ldr	x9, [x20, #0x10]
100504478:     	ldr	x9, [x9, x21, lsl #3]
10050447c:     	and	x22, x9, #0xffffffffffff
100504480:     	str	x8, [x20]
100504484:     	cmp	x19, #0x3e8
100504488:     	csel	w8, wzr, w28, ls
10050448c:     	cbnz	w8, 0x1005044a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbb0>
100504490:     	b	0x100504528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100504494:     	mov	w22, #0x1               ; =1
100504498:     	str	x8, [x20]
10050449c:     	cmp	x19, #0x3e8
1005044a0:     	csel	w8, wzr, w28, ls
1005044a4:     	cbz	w8, 0x100504528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
1005044a8:     	mov	x8, #0x0                ; =0
1005044ac:     	mov	x9, #0x2600             ; =9728
1005044b0:     	movk	x9, #0x1, lsl #32
1005044b4:     	add	x10, x22, x8
1005044b8:     	ldrb	w10, [x10, #0x14]
1005044bc:     	cmp	w10, #0x20
1005044c0:     	b.hi	0x100504504 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
1005044c4:     	lsr	x11, x9, x10
1005044c8:     	tbz	w11, #0x0, 0x100504504 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc0c>
1005044cc:     	add	x8, x8, #0x1
1005044d0:     	cmp	x19, x8
1005044d4:     	b.ne	0x1005044b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbbc>
1005044d8:     	b	0x100504528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
1005044dc:     	ldrb	w8, [x20, #0x20]
1005044e0:     	cbz	w25, 0x10050444c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb54>
1005044e4:     	cbnz	w8, 0x100504b90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1298>
1005044e8:     	ldr	x8, [x20]
1005044ec:     	cbnz	x8, 0x100504c34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
1005044f0:     	ldr	x8, [x20, #0x18]
1005044f4:     	cmp	x21, x8
1005044f8:     	b.hi	0x100503930 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
1005044fc:     	str	x21, [x20, #0x18]
100504500:     	b	0x100503930 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100504504:     	cmp	w10, #0x5b
100504508:     	b.eq	0x100504514 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc1c>
10050450c:     	cmp	w10, #0x7b
100504510:     	b.ne	0x100504528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
100504514:     	add	x0, x22, #0x14
100504518:     	mov	x1, x19
10050451c:     	mov	w2, #0x3e8              ; =1000
100504520:     	bl	0x1006c2814 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
100504524:     	cbnz	w0, 0x100504a24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x112c>
100504528:     	bl	0x1004eda80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
10050452c:     	bl	0x100457940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
100504530:     	mov	x0, x19
100504534:     	bl	0x10022fa2c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
100504538:     	mov	x24, x0
10050453c:     	mov	x22, x1
100504540:     	bl	0x100457754 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
100504544:     	ldrb	w8, [x20, #0x20]
100504548:     	cbnz	w8, 0x1005049b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10b8>
10050454c:     	ldr	x8, [x20]
100504550:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504554:     	cmp	x8, x9
100504558:     	b.hs	0x100504b84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
10050455c:     	add	x9, x8, #0x1
100504560:     	str	x9, [x20]
100504564:     	ldr	x9, [x20, #0x18]
100504568:     	cmp	x21, x9
10050456c:     	b.hs	0x100504584 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc8c>
100504570:     	ldr	x9, [x20, #0x10]
100504574:     	ldr	x9, [x9, x21, lsl #3]
100504578:     	and	x25, x9, #0xffffffffffff
10050457c:     	add	x1, x25, #0x14
100504580:     	b	0x10050458c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc94>
100504584:     	mov	w25, #0x1               ; =1
100504588:     	mov	w1, #0x15               ; =21
10050458c:     	str	x8, [x20]
100504590:     	add	x0, sp, #0xa0
100504594:     	mov	x2, x19
100504598:     	mov	x3, x25
10050459c:     	bl	0x10024530c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23new_batched_from_string>
1005045a0:     	add	x0, sp, #0xa0
1005045a4:     	bl	0x100242448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
1005045a8:     	mov	x23, x0
1005045ac:     	ldp	x26, x28, [sp, #0x108]
1005045b0:     	cmp	x28, x26
1005045b4:     	b.hs	0x1005045e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
1005045b8:     	ldr	x8, [sp, #0x100]
1005045bc:     	mov	x9, #0x2600             ; =9728
1005045c0:     	movk	x9, #0x1, lsl #32
1005045c4:     	ldrb	w10, [x8, x28]
1005045c8:     	cmp	w10, #0x20
1005045cc:     	b.hi	0x1005045e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
1005045d0:     	lsr	x10, x9, x10
1005045d4:     	tbz	w10, #0x0, 0x1005045e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcf0>
1005045d8:     	add	x28, x28, #0x1
1005045dc:     	cmp	x26, x28
1005045e0:     	b.ne	0x1005045c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xccc>
1005045e4:     	mov	x28, x26
1005045e8:     	ldrb	w8, [sp, #0x176]
1005045ec:     	tbnz	w8, #0x0, 0x100504938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1040>
1005045f0:     	cmp	x28, x26
1005045f4:     	b.ne	0x100504944 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104c>
1005045f8:     	ldrb	w8, [sp, #0x174]
1005045fc:     	tbz	w8, #0x0, 0x100504944 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104c>
100504600:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100504604:     	ldr	w26, [x8, #0x560]
100504608:     	cmp	w26, #0x300
10050460c:     	b.hs	0x1005047a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeac>
100504610:     	ldr	x8, [x27, #0x48]
100504614:     	cmn	x8, #0x1
100504618:     	b.eq	0x100504794 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe9c>
10050461c:     	mrs	x9, TPIDRRO_EL0
100504620:     	and	x9, x9, #0xfffffffffffffff8
100504624:     	ldr	x0, [x9, x8, lsl #3]
100504628:     	cbz	x0, 0x100504794 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe9c>
10050462c:     	add	x8, x0, x26, lsl #3
100504630:     	ldr	x0, [x8, #0x1e8]
100504634:     	cbz	x0, 0x1005047a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeac>
100504638:     	ldr	x8, [x0]
10050463c:     	cbnz	x8, 0x1005047b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xec0>
100504640:     	ldrb	w8, [x0, #0x24]
100504644:     	cmp	w8, #0x2
100504648:     	b.eq	0x10050466c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
10050464c:     	ldr	x8, [x0, #0x8]
100504650:     	cmp	x8, x25
100504654:     	b.ne	0x10050466c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
100504658:     	ldr	w8, [x0, #0x18]
10050465c:     	cmp	x19, x8
100504660:     	b.ne	0x10050466c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd74>
100504664:     	mov	w8, #0x1                ; =1
100504668:     	strb	w8, [x0, #0x24]
10050466c:     	mov	x0, x25
100504670:     	mov	x1, x19
100504674:     	mov	x2, x23
100504678:     	bl	0x1004eabc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template>
10050467c:     	ldrb	w8, [x20, #0x20]
100504680:     	cbnz	w8, 0x1005049e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10e8>
100504684:     	ldr	x8, [x20]
100504688:     	cbnz	x8, 0x100504a04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
10050468c:     	mov	x8, #-0x1               ; =-1
100504690:     	str	x8, [x20]
100504694:     	ldr	x19, [x20, #0x18]
100504698:     	ldr	x8, [x20, #0x8]
10050469c:     	cmp	x19, x8
1005046a0:     	b.eq	0x1005047c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xecc>
1005046a4:     	ldr	x8, [x20, #0x10]
1005046a8:     	str	x23, [x8, x19, lsl #3]
1005046ac:     	add	x8, x19, #0x1
1005046b0:     	str	x8, [x20, #0x18]
1005046b4:     	ldr	x8, [x20]
1005046b8:     	add	x8, x8, #0x1
1005046bc:     	str	x8, [x20]
1005046c0:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1005046c4:     	ldr	w19, [x8, #0x308]
1005046c8:     	cmp	w19, #0x300
1005046cc:     	b.hs	0x1005047e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xee8>
1005046d0:     	ldr	x8, [x27, #0x48]
1005046d4:     	cmn	x8, #0x1
1005046d8:     	b.eq	0x1005047d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xed8>
1005046dc:     	mrs	x9, TPIDRRO_EL0
1005046e0:     	and	x9, x9, #0xfffffffffffffff8
1005046e4:     	ldr	x0, [x9, x8, lsl #3]
1005046e8:     	cbz	x0, 0x1005047d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xed8>
1005046ec:     	add	x8, x0, x19, lsl #3
1005046f0:     	ldr	x0, [x8, #0x1e8]
1005046f4:     	cbz	x0, 0x1005047e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xee8>
1005046f8:     	ldrb	w8, [x0]
1005046fc:     	and	w8, w8, #0xfffffffd
100504700:     	strb	w8, [x0]
100504704:     	mov	w0, #0x0                ; =0
100504708:     	bl	0x10045b080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
10050470c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100504710:     	ldr	w19, [x8, #0x590]
100504714:     	cmp	w19, #0x300
100504718:     	b.hs	0x100504800 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf08>
10050471c:     	ldr	x8, [x27, #0x48]
100504720:     	cmn	x8, #0x1
100504724:     	b.eq	0x1005047f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef8>
100504728:     	mrs	x9, TPIDRRO_EL0
10050472c:     	and	x9, x9, #0xfffffffffffffff8
100504730:     	ldr	x0, [x9, x8, lsl #3]
100504734:     	cbz	x0, 0x1005047f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef8>
100504738:     	add	x8, x0, x19, lsl #3
10050473c:     	ldr	x0, [x8, #0x1e8]
100504740:     	cbz	x0, 0x100504800 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf08>
100504744:     	ldr	x8, [x0]
100504748:     	lsr	x8, x8, #25
10050474c:     	cbz	x8, 0x100504818 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf20>
100504750:     	bl	0x10045ce34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100504754:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100504758:     	mov	x0, x24
10050475c:     	mov	x1, x22
100504760:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100504764:     	ldrb	w8, [x20, #0x20]
100504768:     	cbz	w8, 0x100504830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf38>
10050476c:     	cmp	w8, #0x2
100504770:     	b.eq	0x100504b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504774:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504778:     	add	x1, x1, #0x518
10050477c:     	mov	x0, x20
100504780:     	bl	0x100a1e19c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504784:     	strb	wzr, [x20, #0x20]
100504788:     	ldr	x8, [x20]
10050478c:     	cbz	x8, 0x100504838 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf40>
100504790:     	b	0x100504c34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
100504794:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504798:     	add	x8, x0, x26, lsl #3
10050479c:     	ldr	x0, [x8, #0x1e8]
1005047a0:     	cbnz	x0, 0x100504638 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd40>
1005047a4:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1005047a8:     	add	x0, x0, #0xfa0
1005047ac:     	bl	0x100b3a95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005047b0:     	ldr	x8, [x0]
1005047b4:     	cbz	x8, 0x100504640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd48>
1005047b8:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1005047bc:     	add	x0, x0, #0xcf8
1005047c0:     	bl	0x100b1046c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1005047c4:     	add	x0, x20, #0x8
1005047c8:     	bl	0x100b39a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1005047cc:     	b	0x1005046a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdac>
1005047d0:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005047d4:     	add	x8, x0, x19, lsl #3
1005047d8:     	ldr	x0, [x8, #0x1e8]
1005047dc:     	cbnz	x0, 0x1005046f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe00>
1005047e0:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1005047e4:     	add	x0, x0, #0xcd8
1005047e8:     	bl	0x100b3a9a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1005047ec:     	b	0x1005046f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe00>
1005047f0:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005047f4:     	add	x8, x0, x19, lsl #3
1005047f8:     	ldr	x0, [x8, #0x1e8]
1005047fc:     	cbnz	x0, 0x100504744 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe4c>
100504800:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100504804:     	add	x0, x0, #0x78
100504808:     	bl	0x100b3a95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10050480c:     	ldr	x8, [x0]
100504810:     	lsr	x8, x8, #25
100504814:     	cbnz	x8, 0x100504750 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe58>
100504818:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
10050481c:     	mov	x0, x24
100504820:     	mov	x1, x22
100504824:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100504828:     	ldrb	w8, [x20, #0x20]
10050482c:     	cbnz	w8, 0x10050476c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe74>
100504830:     	ldr	x8, [x20]
100504834:     	cbnz	x8, 0x100504c34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x133c>
100504838:     	ldr	x8, [x20, #0x18]
10050483c:     	cmp	x21, x8
100504840:     	b.ls	0x100504868 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf70>
100504844:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100504848:     	ldr	x8, [x8, #0x758]
10050484c:     	cbnz	x8, 0x100504878 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf80>
100504850:     	ldr	x8, [sp, #0xd8]
100504854:     	cmp	x8, #0x1
100504858:     	b.lt	0x100503930 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
10050485c:     	ldr	x0, [sp, #0xe0]
100504860:     	bl	0x100b5cd00 <_mi_free>
100504864:     	b	0x100503930 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100504868:     	str	x21, [x20, #0x18]
10050486c:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100504870:     	ldr	x8, [x8, #0x758]
100504874:     	cbz	x8, 0x100504850 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf58>
100504878:     	bl	0x100b43830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
10050487c:     	ldr	x8, [sp, #0xd8]
100504880:     	cmp	x8, #0x1
100504884:     	b.ge	0x10050485c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf64>
100504888:     	b	0x100503930 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
10050488c:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100504890:     	add	x8, x0, x24, lsl #3
100504894:     	ldr	x0, [x8, #0x1e8]
100504898:     	cbnz	x0, 0x100503fb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6b8>
10050489c:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1005048a0:     	add	x0, x0, #0xca8
1005048a4:     	bl	0x100b3a9a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1005048a8:     	ldrb	w8, [x0]
1005048ac:     	cbz	w8, 0x100503fb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6c0>
1005048b0:     	bl	0x100b420dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
1005048b4:     	b	0x100503fb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6c0>
1005048b8:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005048bc:     	add	x8, x0, x24, lsl #3
1005048c0:     	ldr	x0, [x8, #0x1e8]
1005048c4:     	cbnz	x0, 0x1005042f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9fc>
1005048c8:     	adrp	x0, 0x100f08000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1005048cc:     	add	x0, x0, #0xcd8
1005048d0:     	bl	0x100b3a9a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1005048d4:     	b	0x1005042f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9fc>
1005048d8:     	bl	0x100b3d13c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005048dc:     	add	x8, x0, x24, lsl #3
1005048e0:     	ldr	x0, [x8, #0x1e8]
1005048e4:     	cbnz	x0, 0x100504340 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa48>
1005048e8:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1005048ec:     	add	x0, x0, #0x78
1005048f0:     	bl	0x100b3a95c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005048f4:     	ldr	x8, [x0]
1005048f8:     	lsr	x8, x8, #25
1005048fc:     	cbnz	x8, 0x10050434c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa54>
100504900:     	cmp	x23, #0x3e8
100504904:     	b.ls	0x100504358 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa60>
100504908:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
10050490c:     	ldp	x1, x0, [sp]
100504910:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100504914:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100504918:     	ldr	x8, [x8, #0x758]
10050491c:     	cbz	x8, 0x10050436c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa74>
100504920:     	bl	0x100b43830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100504924:     	tbnz	w25, #0x0, 0x100504370 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa78>
100504928:     	b	0x1005043b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xabc>
10050492c:     	add	x0, x20, #0x8
100504930:     	bl	0x100b39a2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100504934:     	b	0x10050429c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9a4>
100504938:     	bl	0x100b43604 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar15clear_key_cache>
10050493c:     	cmp	x28, x26
100504940:     	b.eq	0x1005045f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd00>
100504944:     	mov	x0, x23
100504948:     	bl	0x1003259cc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15parse_root_push>
10050494c:     	bl	0x1004578bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy13gc_unsuppress>
100504950:     	bl	0x1004ed9e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat26finish_parse_gc_accounting>
100504954:     	bl	0x10045f160 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100504958:     	mov	x0, x24
10050495c:     	mov	x1, x22
100504960:     	bl	0x10022fb78 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100504964:     	mov	x0, x21
100504968:     	bl	0x100325bdc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
10050496c:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100504970:     	ldr	x8, [x8, #0x758]
100504974:     	cbnz	x8, 0x100504edc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15e4>
100504978:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x719c>
10050497c:     	add	x0, x0, #0x320
100504980:     	mov	w1, #0x21               ; =33
100504984:     	bl	0x1005063a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
100504988:     	cmp	w8, #0x2
10050498c:     	b.eq	0x100504b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504990:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504994:     	add	x1, x1, #0x518
100504998:     	mov	x0, x20
10050499c:     	bl	0x100a1e19c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1005049a0:     	strb	wzr, [x20, #0x20]
1005049a4:     	ldr	x8, [x20]
1005049a8:     	cbz	x8, 0x100503e24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x52c>
1005049ac:     	b	0x100504a04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
1005049b0:     	cmp	w8, #0x2
1005049b4:     	b.eq	0x100504b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
1005049b8:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
1005049bc:     	add	x1, x1, #0x518
1005049c0:     	mov	x0, x20
1005049c4:     	bl	0x100a1e19c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1005049c8:     	strb	wzr, [x20, #0x20]
1005049cc:     	ldr	x8, [x20]
1005049d0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005049d4:     	cmp	x8, x9
1005049d8:     	b.lo	0x10050455c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc64>
1005049dc:     	b	0x100504b84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
1005049e0:     	cmp	w8, #0x2
1005049e4:     	b.eq	0x100504b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
1005049e8:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
1005049ec:     	add	x1, x1, #0x518
1005049f0:     	mov	x0, x20
1005049f4:     	bl	0x100a1e19c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1005049f8:     	strb	wzr, [x20, #0x20]
1005049fc:     	ldr	x8, [x20]
100504a00:     	cbz	x8, 0x10050468c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd94>
100504a04:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100504a08:     	add	x0, x0, #0x428
100504a0c:     	bl	0x100b1046c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100504a10:     	mov	x0, x22
100504a14:     	bl	0x100b1c26c <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11TapeScratchEEuE16get_or_init_slowNvNvB2b_12TAPE_SCRATCH27___rust_std_internal_init_fnEB2d_>
100504a18:     	mov	x22, x0
100504a1c:     	cbnz	x0, 0x100503f08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x610>
100504a20:     	b	0x100504b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504a24:     	mov	x0, x21
100504a28:     	bl	0x100325bdc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100504a2c:     	mov	x0, x22
100504a30:     	mov	x1, x19
100504a34:     	bl	0x100b43b78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api19parse_deep_or_throw>
100504a38:     	mov	x23, x0
100504a3c:     	b	0x100503930 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100504a40:     	cmp	w8, #0x2
100504a44:     	b.eq	0x100504b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504a48:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504a4c:     	add	x1, x1, #0x518
100504a50:     	mov	x0, x20
100504a54:     	bl	0x100a1e19c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504a58:     	strb	wzr, [x20, #0x20]
100504a5c:     	ldr	x8, [x20]
100504a60:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504a64:     	cmp	x8, x9
100504a68:     	b.lo	0x100503ebc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c4>
100504a6c:     	b	0x100504b84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504a70:     	cmp	x9, #0x6
100504a74:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504a78:     	ldrb	w8, [x21, #0x1a]
100504a7c:     	cmp	w8, #0x22
100504a80:     	b.ne	0x100504ba4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12ac>
100504a84:     	mov	w23, #0x0               ; =0
100504a88:     	mov	w28, #0x0               ; =0
100504a8c:     	mov	w27, #0x0               ; =0
100504a90:     	mov	w26, #0x1               ; =1
100504a94:     	mov	w20, #0x4               ; =4
100504a98:     	b	0x100503ab0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100504a9c:     	cmp	w8, #0x2
100504aa0:     	b.eq	0x100504b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504aa4:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504aa8:     	add	x1, x1, #0x518
100504aac:     	mov	x0, x20
100504ab0:     	bl	0x100a1e19c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504ab4:     	strb	wzr, [x20, #0x20]
100504ab8:     	ldr	x8, [x20]
100504abc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504ac0:     	cmp	x8, x9
100504ac4:     	b.lo	0x100504460 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb68>
100504ac8:     	b	0x100504b84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504acc:     	cmp	w8, #0x2
100504ad0:     	b.eq	0x100504b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504ad4:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504ad8:     	add	x1, x1, #0x518
100504adc:     	mov	x0, x20
100504ae0:     	bl	0x100a1e19c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504ae4:     	strb	wzr, [x20, #0x20]
100504ae8:     	ldr	x8, [x20]
100504aec:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504af0:     	cmp	x8, x9
100504af4:     	b.lo	0x100503fec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6f4>
100504af8:     	b	0x100504b84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x128c>
100504afc:     	cmp	w8, #0x2
100504b00:     	b.eq	0x100504b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504b04:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504b08:     	add	x1, x1, #0x518
100504b0c:     	mov	x0, x20
100504b10:     	bl	0x100a1e19c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504b14:     	strb	wzr, [x20, #0x20]
100504b18:     	ldr	x8, [x20]
100504b1c:     	cbz	x8, 0x100504284 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x98c>
100504b20:     	b	0x100504a04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x110c>
100504b24:     	cmp	x9, #0x1
100504b28:     	b.ne	0x100504bd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12dc>
100504b2c:     	ldrb	w8, [x8]
100504b30:     	sub	w9, w8, #0x30
100504b34:     	cmp	w9, #0xa
100504b38:     	b.hs	0x100504bd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12e0>
100504b3c:     	and	w8, w9, #0xff
100504b40:     	ucvtf	d0, w8
100504b44:     	fmov	x1, d0
100504b48:     	orr	x0, x25, x26
100504b4c:     	bl	0x1004f3bb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object18allocate_one_field>
100504b50:     	tbnz	w0, #0x0, 0x10050392c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x34>
100504b54:     	b	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504b58:     	cmp	w8, #0x2
100504b5c:     	b.eq	0x100504b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a0>
100504b60:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504b64:     	add	x1, x1, #0x518
100504b68:     	mov	x0, x20
100504b6c:     	bl	0x100a1e19c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504b70:     	strb	wzr, [x20, #0x20]
100504b74:     	ldr	x8, [x20]
100504b78:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100504b7c:     	cmp	x8, x9
100504b80:     	b.lo	0x100504388 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa90>
100504b84:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100504b88:     	add	x0, x0, #0x3f8
100504b8c:     	bl	0x100b1049c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100504b90:     	cmp	w8, #0x2
100504b94:     	b.ne	0x100504c18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1320>
100504b98:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100504b9c:     	add	x0, x0, #0xc18
100504ba0:     	bl	0x100b5635c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100504ba4:     	sub	x8, x19, #0x1
100504ba8:     	cmp	x8, #0x7
100504bac:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504bb0:     	ldrb	w8, [x21, #0x1b]
100504bb4:     	cmp	w8, #0x22
100504bb8:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504bbc:     	mov	w23, #0x0               ; =0
100504bc0:     	mov	w28, #0x0               ; =0
100504bc4:     	mov	w27, #0x0               ; =0
100504bc8:     	mov	w26, #0x0               ; =0
100504bcc:     	mov	w20, #0x5               ; =5
100504bd0:     	b	0x100503ab0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100504bd4:     	ldrb	w8, [x8]
100504bd8:     	orr	w8, w8, #0x20
100504bdc:     	cmp	w8, #0x7b
100504be0:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504be4:     	sub	x11, x19, #0x5
100504be8:     	mov	x10, #0x2600            ; =9728
100504bec:     	movk	x10, #0x1, lsl #32
100504bf0:     	add	x8, x21, x20
100504bf4:     	ldrb	w9, [x8, #0x18]
100504bf8:     	cmp	w9, #0x20
100504bfc:     	b.hi	0x100504c40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1348>
100504c00:     	lsr	x12, x10, x9
100504c04:     	tbz	w12, #0x0, 0x100504c40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1348>
100504c08:     	add	x20, x20, #0x1
100504c0c:     	cmp	x11, x20
100504c10:     	b.ne	0x100504bf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f8>
100504c14:     	b	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504c18:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100504c1c:     	add	x1, x1, #0x518
100504c20:     	mov	x0, x20
100504c24:     	bl	0x100a1e19c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100504c28:     	strb	wzr, [x20, #0x20]
100504c2c:     	ldr	x8, [x20]
100504c30:     	cbz	x8, 0x1005044f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbf8>
100504c34:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100504c38:     	add	x0, x0, #0x488
100504c3c:     	bl	0x100b1046c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100504c40:     	cmp	x11, x20
100504c44:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504c48:     	add	x13, x21, #0x12
100504c4c:     	mov	x14, #0x2600            ; =9728
100504c50:     	movk	x14, #0x1, lsl #32
100504c54:     	mov	x10, x20
100504c58:     	ldrb	w12, [x13, x19]
100504c5c:     	cmp	w12, #0x20
100504c60:     	b.hi	0x100504c90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1398>
100504c64:     	lsr	x15, x14, x12
100504c68:     	tbz	w15, #0x0, 0x100504c90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1398>
100504c6c:     	sub	x13, x13, #0x1
100504c70:     	add	x10, x10, #0x1
100504c74:     	cmp	x11, x10
100504c78:     	b.ne	0x100504c58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1360>
100504c7c:     	b	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504c80:     	adrp	x2, 0x100f07000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime7promise28ITER_RESULT_VALUE_IS_RAW_I32+0x40>
100504c84:     	add	x2, x2, #0x170
100504c88:     	mov	x1, x25
100504c8c:     	bl	0x100b105cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100504c90:     	sub	x11, x19, x10
100504c94:     	sub	x1, x11, #0x5
100504c98:     	cmp	x1, #0x4
100504c9c:     	b.eq	0x100504d08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1410>
100504ca0:     	cmp	x1, #0x5
100504ca4:     	b.ne	0x100504d10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1418>
100504ca8:     	cmp	w9, #0x22
100504cac:     	b.eq	0x100504d3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1444>
100504cb0:     	cmp	w9, #0x2d
100504cb4:     	b.eq	0x100504d2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1434>
100504cb8:     	cmp	w9, #0x66
100504cbc:     	b.ne	0x100504d20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1428>
100504cc0:     	add	x8, x21, x20
100504cc4:     	ldrb	w9, [x8, #0x19]
100504cc8:     	cmp	w9, #0x61
100504ccc:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504cd0:     	ldrb	w8, [x8, #0x1a]
100504cd4:     	cmp	w8, #0x6c
100504cd8:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504cdc:     	add	x8, x21, x20
100504ce0:     	ldrb	w9, [x8, #0x1b]
100504ce4:     	cmp	w9, #0x73
100504ce8:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504cec:     	ldrb	w8, [x8, #0x1c]
100504cf0:     	cmp	w8, #0x65
100504cf4:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504cf8:     	mov	x8, #0x1                ; =1
100504cfc:     	movk	x8, #0x7ffc, lsl #48
100504d00:     	orr	x1, x8, #0x2
100504d04:     	b	0x100504b48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504d08:     	cmp	w9, #0x6d
100504d0c:     	b.gt	0x100504da8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14b0>
100504d10:     	cmp	w9, #0x22
100504d14:     	b.eq	0x100504d3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1444>
100504d18:     	cmp	w9, #0x2d
100504d1c:     	b.eq	0x100504d2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1434>
100504d20:     	sub	w9, w9, #0x30
100504d24:     	cmp	w9, #0xa
100504d28:     	b.hs	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d2c:     	add	x0, x8, #0x18
100504d30:     	bl	0x1004eb7c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar12parse_number>
100504d34:     	tbz	w0, #0x0, 0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d38:     	b	0x100504b48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504d3c:     	sub	x8, x19, #0x6
100504d40:     	cmp	x8, x10
100504d44:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d48:     	cmp	x1, #0x7
100504d4c:     	b.hi	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d50:     	cmp	w12, #0x22
100504d54:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d58:     	sub	x23, x11, #0x7
100504d5c:     	sub	x8, x19, #0x7
100504d60:     	add	x9, x21, x20
100504d64:     	add	x22, x9, #0x19
100504d68:     	cmp	x8, x10
100504d6c:     	b.ne	0x100504e30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1538>
100504d70:     	add	x8, sp, #0xa0
100504d74:     	mov	x0, x22
100504d78:     	mov	x1, x23
100504d7c:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100504d80:     	ldr	x8, [sp, #0xa0]
100504d84:     	cbnz	x8, 0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504d88:     	cmp	x23, #0x2
100504d8c:     	b.gt	0x100504e60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1568>
100504d90:     	cbz	x23, 0x100504e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1584>
100504d94:     	cmp	x23, #0x1
100504d98:     	b.ne	0x100504e84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x158c>
100504d9c:     	ldrb	w8, [x22]
100504da0:     	mov	x9, #0x10000000000      ; =1099511627776
100504da4:     	b	0x100504ed0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100504da8:     	cmp	w9, #0x74
100504dac:     	b.eq	0x100504df4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14fc>
100504db0:     	cmp	w9, #0x6e
100504db4:     	b.ne	0x100504d20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1428>
100504db8:     	add	x8, x21, x20
100504dbc:     	ldrb	w9, [x8, #0x19]
100504dc0:     	cmp	w9, #0x75
100504dc4:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504dc8:     	ldrb	w8, [x8, #0x1a]
100504dcc:     	cmp	w8, #0x6c
100504dd0:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504dd4:     	add	x8, x21, x20
100504dd8:     	ldrb	w8, [x8, #0x1b]
100504ddc:     	cmp	w8, #0x6c
100504de0:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504de4:     	mov	x8, #0x1                ; =1
100504de8:     	movk	x8, #0x7ffc, lsl #48
100504dec:     	add	x1, x8, #0x1
100504df0:     	b	0x100504b48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504df4:     	add	x8, x21, x20
100504df8:     	ldrb	w9, [x8, #0x19]
100504dfc:     	cmp	w9, #0x72
100504e00:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e04:     	ldrb	w8, [x8, #0x1a]
100504e08:     	cmp	w8, #0x75
100504e0c:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e10:     	add	x8, x21, x20
100504e14:     	ldrb	w8, [x8, #0x1b]
100504e18:     	cmp	w8, #0x65
100504e1c:     	b.ne	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e20:     	mov	x8, #0x1                ; =1
100504e24:     	movk	x8, #0x7ffc, lsl #48
100504e28:     	add	x1, x8, #0x3
100504e2c:     	b	0x100504b48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504e30:     	mov	x8, x23
100504e34:     	mov	x9, x22
100504e38:     	ldrb	w10, [x9], #0x1
100504e3c:     	cmp	w10, #0x20
100504e40:     	b.lo	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e44:     	cmp	w10, #0x22
100504e48:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e4c:     	cmp	w10, #0x5c
100504e50:     	b.eq	0x10050397c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100504e54:     	subs	x8, x8, #0x1
100504e58:     	b.ne	0x100504e38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1540>
100504e5c:     	b	0x100504d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1478>
100504e60:     	cmp	x23, #0x3
100504e64:     	b.eq	0x100504e9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15a4>
100504e68:     	cmp	x23, #0x4
100504e6c:     	b.ne	0x100504ebc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15c4>
100504e70:     	ldr	w8, [x22]
100504e74:     	mov	x9, #0x40000000000      ; =4398046511104
100504e78:     	b	0x100504ed0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100504e7c:     	mov	x1, #0x7ff9000000000000 ; =9221401712017801216
100504e80:     	b	0x100504b48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504e84:     	ldrb	w8, [x22]
100504e88:     	add	x9, x21, x20
100504e8c:     	ldrb	w9, [x9, #0x1a]
100504e90:     	orr	x8, x8, x9, lsl #8
100504e94:     	mov	x9, #0x20000000000      ; =2199023255552
100504e98:     	b	0x100504ed0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100504e9c:     	ldrb	w8, [x22]
100504ea0:     	add	x9, x21, x20
100504ea4:     	ldrb	w10, [x9, #0x1a]
100504ea8:     	ldrb	w9, [x9, #0x1b]
100504eac:     	orr	x8, x8, x10, lsl #8
100504eb0:     	orr	x8, x8, x9, lsl #16
100504eb4:     	mov	x9, #0x30000000000      ; =3298534883328
100504eb8:     	b	0x100504ed0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15d8>
100504ebc:     	ldr	w8, [x22]
100504ec0:     	add	x9, x21, x20
100504ec4:     	ldrb	w9, [x9, #0x1d]
100504ec8:     	orr	x8, x8, x9, lsl #32
100504ecc:     	mov	x9, #0x50000000000      ; =5497558138880
100504ed0:     	movk	x9, #0x7ff9, lsl #48
100504ed4:     	orr	x1, x8, x9
100504ed8:     	b	0x100504b48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1250>
100504edc:     	bl	0x100b43830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100504ee0:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x719c>
100504ee4:     	add	x0, x0, #0x320
100504ee8:     	mov	w1, #0x21               ; =33
100504eec:     	bl	0x1005063a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
