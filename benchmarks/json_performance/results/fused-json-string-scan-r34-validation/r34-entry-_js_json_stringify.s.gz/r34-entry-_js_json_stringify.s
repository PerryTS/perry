
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/fused-json-string-scan-r34/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008442ac <_js_json_stringify>:
1008442ac:     	sub	sp, sp, #0x80
1008442b0:     	stp	d9, d8, [sp, #0x20]
1008442b4:     	stp	x26, x25, [sp, #0x30]
1008442b8:     	stp	x24, x23, [sp, #0x40]
1008442bc:     	stp	x22, x21, [sp, #0x50]
1008442c0:     	stp	x20, x19, [sp, #0x60]
1008442c4:     	stp	x29, x30, [sp, #0x70]
1008442c8:     	add	x29, sp, #0x70
1008442cc:     	mov	x21, x0
1008442d0:     	mov.16b	v8, v0
1008442d4:     	fmov	x19, d8
1008442d8:     	and	x20, x19, #0xffff000000000000
1008442dc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008442e0:     	cmp	x20, x8
1008442e4:     	b.ne	0x10084430c <_js_json_stringify+0x60>
1008442e8:     	and	x0, x19, #0xffffffffffff
1008442ec:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
1008442f0:     	mov	x9, #0x7fffffffffff     ; =140737488355327
1008442f4:     	movk	x9, #0xffef, lsl #16
1008442f8:     	cmp	x8, x9
1008442fc:     	b.hi	0x10084430c <_js_json_stringify+0x60>
100844300:     	ldr	w8, [x0, #0x4]
100844304:     	cmp	w8, #0x40
100844308:     	b.hs	0x10084437c <_js_json_stringify+0xd0>
10084430c:     	mov.16b	v0, v8
100844310:     	bl	0x1004ec5fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100844314:     	tbz	w0, #0x0, 0x100844320 <_js_json_stringify+0x74>
100844318:     	mov	x23, x1
10084431c:     	b	0x100844890 <_js_json_stringify+0x5e4>
100844320:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100844324:     	cmp	x20, x8
100844328:     	b.ne	0x100844390 <_js_json_stringify+0xe4>
10084432c:     	ands	x19, x19, #0xffffffffffff
100844330:     	b.eq	0x100844390 <_js_json_stringify+0xe4>
100844334:     	mov	x0, x19
100844338:     	bl	0x10050d7f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084433c:     	cbz	w0, 0x100844390 <_js_json_stringify+0xe4>
100844340:     	ldurb	w8, [x19, #-0x8]
100844344:     	cmp	w8, #0x9
100844348:     	b.ne	0x100844390 <_js_json_stringify+0xe4>
10084434c:     	ldr	w8, [x19, #0x4]
100844350:     	mov	w9, #0x5841             ; =22593
100844354:     	movk	w9, #0x4c5a, lsl #16
100844358:     	cmp	w8, w9
10084435c:     	b.ne	0x100844390 <_js_json_stringify+0xe4>
100844360:     	mov	x0, x19
100844364:     	bl	0x1006862a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100844368:     	cbz	x0, 0x100844390 <_js_json_stringify+0xe4>
10084436c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100844370:     	bfxil	x8, x0, #0, #48
100844374:     	fmov	d8, x8
100844378:     	b	0x100844390 <_js_json_stringify+0xe4>
10084437c:     	bl	0x1004f1528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100844380:     	tbnz	w0, #0x0, 0x100844318 <_js_json_stringify+0x6c>
100844384:     	mov.16b	v0, v8
100844388:     	bl	0x1004ec5fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084438c:     	tbnz	w0, #0x0, 0x100844318 <_js_json_stringify+0x6c>
100844390:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100844394:     	add	x0, x0, #0xd78
100844398:     	ldr	x8, [x0]
10084439c:     	blr	x8
1008443a0:     	mov	x19, x0
1008443a4:     	ldr	w26, [x0]
1008443a8:     	add	w8, w26, #0x1
1008443ac:     	str	w8, [x0]
1008443b0:     	cbz	w26, 0x100844420 <_js_json_stringify+0x174>
1008443b4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008443b8:     	add	x0, x0, #0xd00
1008443bc:     	ldr	x8, [x0]
1008443c0:     	blr	x8
1008443c4:     	ldrb	w8, [x0, #0x20]
1008443c8:     	cmp	w8, #0x1
1008443cc:     	b.ne	0x100844984 <_js_json_stringify+0x6d8>
1008443d0:     	ldr	x8, [x0]
1008443d4:     	cbnz	x8, 0x100844990 <_js_json_stringify+0x6e4>
1008443d8:     	mov	x8, #-0x1               ; =-1
1008443dc:     	str	x8, [x0]
1008443e0:     	ldr	x20, [x0, #0x18]
1008443e4:     	ldr	x8, [x0, #0x8]
1008443e8:     	cmp	x20, x8
1008443ec:     	b.eq	0x1008448b4 <_js_json_stringify+0x608>
1008443f0:     	ldr	x8, [x0, #0x10]
1008443f4:     	mov	w9, #0x18               ; =24
1008443f8:     	madd	x8, x20, x9, x8
1008443fc:     	mov	w9, #0x8                ; =8
100844400:     	stp	xzr, x9, [x8]
100844404:     	str	xzr, [x8, #0x10]
100844408:     	add	x8, x20, #0x1
10084440c:     	str	x8, [x0, #0x18]
100844410:     	ldr	x8, [x0]
100844414:     	add	x8, x8, #0x1
100844418:     	str	x8, [x0]
10084441c:     	b	0x1008444ac <_js_json_stringify+0x200>
100844420:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100844424:     	add	x0, x0, #0xdc0
100844428:     	ldr	x8, [x0]
10084442c:     	blr	x8
100844430:     	strb	wzr, [x0]
100844434:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100844438:     	add	x0, x0, #0xdf0
10084443c:     	ldr	x8, [x0]
100844440:     	blr	x8
100844444:     	strb	wzr, [x0]
100844448:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
10084444c:     	ldr	w20, [x8, #0x5a8]
100844450:     	cmp	w20, #0x300
100844454:     	b.hs	0x100844910 <_js_json_stringify+0x664>
100844458:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
10084445c:     	ldr	x8, [x8, #0x48]
100844460:     	cmn	x8, #0x1
100844464:     	b.eq	0x100844900 <_js_json_stringify+0x654>
100844468:     	mrs	x9, TPIDRRO_EL0
10084446c:     	and	x9, x9, #0xfffffffffffffff8
100844470:     	ldr	x0, [x9, x8, lsl #3]
100844474:     	cbz	x0, 0x100844900 <_js_json_stringify+0x654>
100844478:     	add	x8, x0, x20, lsl #3
10084447c:     	ldr	x0, [x8, #0x1e8]
100844480:     	cbz	x0, 0x100844910 <_js_json_stringify+0x664>
100844484:     	str	xzr, [x0]
100844488:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084448c:     	add	x0, x0, #0xd90
100844490:     	ldr	x8, [x0]
100844494:     	blr	x8
100844498:     	ldrb	w8, [x0, #0x20]
10084449c:     	cbnz	w8, 0x10084499c <_js_json_stringify+0x6f0>
1008444a0:     	ldr	x8, [x0]
1008444a4:     	cbnz	x8, 0x1008449c4 <_js_json_stringify+0x718>
1008444a8:     	str	xzr, [x0, #0x18]
1008444ac:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008444b0:     	add	x0, x0, #0xd30
1008444b4:     	ldr	x8, [x0]
1008444b8:     	blr	x8
1008444bc:     	mov	x20, x0
1008444c0:     	ldrb	w8, [x0, #0x18]
1008444c4:     	cmp	w8, #0x1
1008444c8:     	b.ne	0x100844920 <_js_json_stringify+0x674>
1008444cc:     	ldr	x8, [x0]
1008444d0:     	mov	x9, #-0x1               ; =-1
1008444d4:     	str	x9, [x0]
1008444d8:     	cmn	x8, #0x2
1008444dc:     	b.eq	0x1008449d0 <_js_json_stringify+0x724>
1008444e0:     	cmn	x8, #0x1
1008444e4:     	b.eq	0x1008444f8 <_js_json_stringify+0x24c>
1008444e8:     	add	x9, sp, #0x8
1008444ec:     	ldur	q0, [x0, #0x8]
1008444f0:     	stur	q0, [x9, #0x8]
1008444f4:     	b	0x100844504 <_js_json_stringify+0x258>
1008444f8:     	mov	x8, #0x0                ; =0
1008444fc:     	mov	w9, #0x1                ; =1
100844500:     	stp	x9, xzr, [sp, #0x10]
100844504:     	str	x8, [sp, #0x8]
100844508:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084450c:     	add	x0, x0, #0xd18
100844510:     	ldr	x8, [x0]
100844514:     	blr	x8
100844518:     	ldrb	w8, [x0, #0x20]
10084451c:     	cbnz	w8, 0x100844950 <_js_json_stringify+0x6a4>
100844520:     	ldr	x8, [x0]
100844524:     	cbnz	x8, 0x100844978 <_js_json_stringify+0x6cc>
100844528:     	str	xzr, [x0, #0x18]
10084452c:     	add	x1, sp, #0x8
100844530:     	mov.16b	v0, v8
100844534:     	mov	x0, x21
100844538:     	bl	0x100507c3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
10084453c:     	ldp	x21, x22, [sp, #0x10]
100844540:     	cmp	w22, #0x80, lsl #12     ; =0x80000
100844544:     	b.hs	0x100844604 <_js_json_stringify+0x358>
100844548:     	cmp	x22, #0x40
10084454c:     	b.hs	0x1008446c8 <_js_json_stringify+0x41c>
100844550:     	ands	x9, x22, #0x38
100844554:     	b.eq	0x100844578 <_js_json_stringify+0x2cc>
100844558:     	and	x8, x22, #0x38
10084455c:     	neg	x8, x8
100844560:     	mov	x10, x21
100844564:     	ldr	x11, [x10], #0x8
100844568:     	tst	x11, #0x8080808080808080
10084456c:     	b.ne	0x1008445ec <_js_json_stringify+0x340>
100844570:     	adds	x8, x8, #0x8
100844574:     	b.ne	0x100844564 <_js_json_stringify+0x2b8>
100844578:     	and	x8, x22, #0x7
10084457c:     	cbz	x8, 0x10084474c <_js_json_stringify+0x4a0>
100844580:     	add	x9, x21, x9
100844584:     	ldrsb	w10, [x9]
100844588:     	tbnz	w10, #0x1f, 0x1008445ec <_js_json_stringify+0x340>
10084458c:     	cmp	x8, #0x1
100844590:     	b.eq	0x10084474c <_js_json_stringify+0x4a0>
100844594:     	ldrsb	w10, [x9, #0x1]
100844598:     	tbnz	w10, #0x1f, 0x1008445ec <_js_json_stringify+0x340>
10084459c:     	cmp	x8, #0x2
1008445a0:     	b.eq	0x10084474c <_js_json_stringify+0x4a0>
1008445a4:     	ldrsb	w10, [x9, #0x2]
1008445a8:     	tbnz	w10, #0x1f, 0x1008445ec <_js_json_stringify+0x340>
1008445ac:     	cmp	x8, #0x3
1008445b0:     	b.eq	0x10084474c <_js_json_stringify+0x4a0>
1008445b4:     	ldrsb	w10, [x9, #0x3]
1008445b8:     	tbnz	w10, #0x1f, 0x1008445ec <_js_json_stringify+0x340>
1008445bc:     	cmp	x8, #0x4
1008445c0:     	b.eq	0x10084474c <_js_json_stringify+0x4a0>
1008445c4:     	ldrsb	w10, [x9, #0x4]
1008445c8:     	tbnz	w10, #0x1f, 0x1008445ec <_js_json_stringify+0x340>
1008445cc:     	cmp	x8, #0x5
1008445d0:     	b.eq	0x10084474c <_js_json_stringify+0x4a0>
1008445d4:     	ldrsb	w10, [x9, #0x5]
1008445d8:     	tbnz	w10, #0x1f, 0x1008445ec <_js_json_stringify+0x340>
1008445dc:     	cmp	x8, #0x6
1008445e0:     	b.eq	0x10084474c <_js_json_stringify+0x4a0>
1008445e4:     	ldrsb	w8, [x9, #0x6]
1008445e8:     	tbz	w8, #0x1f, 0x10084474c <_js_json_stringify+0x4a0>
1008445ec:     	mov	x0, x21
1008445f0:     	mov	x1, x22
1008445f4:     	mov	x2, x22
1008445f8:     	bl	0x1008dbc80 <_js_string_from_bytes_with_capacity>
1008445fc:     	mov	x23, x0
100844600:     	b	0x100844848 <_js_json_stringify+0x59c>
100844604:     	and	x8, x22, #0x7fffffffffffffc0
100844608:     	add	x8, x21, x8
10084460c:     	mov	x9, x21
100844610:     	ldp	q0, q1, [x9]
100844614:     	ldp	q2, q3, [x9, #0x20]
100844618:     	orr.16b	v0, v1, v0
10084461c:     	orr.16b	v1, v2, v3
100844620:     	orr.16b	v0, v0, v1
100844624:     	umaxv.16b	b0, v0
100844628:     	fmov	w10, s0
10084462c:     	tbnz	w10, #0x7, 0x10084468c <_js_json_stringify+0x3e0>
100844630:     	add	x9, x9, #0x40
100844634:     	cmp	x9, x8
100844638:     	b.ne	0x100844610 <_js_json_stringify+0x364>
10084463c:     	ands	x9, x22, #0x30
100844640:     	b.eq	0x100844664 <_js_json_stringify+0x3b8>
100844644:     	mov	x10, x9
100844648:     	mov	x11, x8
10084464c:     	ldr	q0, [x11], #0x10
100844650:     	umaxv.16b	b0, v0
100844654:     	fmov	w12, s0
100844658:     	tbnz	w12, #0x7, 0x10084468c <_js_json_stringify+0x3e0>
10084465c:     	subs	x10, x10, #0x10
100844660:     	b.ne	0x10084464c <_js_json_stringify+0x3a0>
100844664:     	and	x10, x22, #0xf
100844668:     	cbz	x10, 0x100844684 <_js_json_stringify+0x3d8>
10084466c:     	add	x8, x8, x9
100844670:     	ldrsb	w9, [x8]
100844674:     	tbnz	w9, #0x1f, 0x10084468c <_js_json_stringify+0x3e0>
100844678:     	add	x8, x8, #0x1
10084467c:     	subs	x10, x10, #0x1
100844680:     	b.ne	0x100844670 <_js_json_stringify+0x3c4>
100844684:     	mov	w24, w22
100844688:     	b	0x1008446c0 <_js_json_stringify+0x414>
10084468c:     	mov	w24, w22
100844690:     	cbz	x24, 0x1008446c0 <_js_json_stringify+0x414>
100844694:     	mov	x8, x21
100844698:     	ands	x9, x22, #0x3
10084469c:     	b.eq	0x1008446b8 <_js_json_stringify+0x40c>
1008446a0:     	mov	x8, x21
1008446a4:     	ldrsb	w10, [x8]
1008446a8:     	tbnz	w10, #0x1f, 0x1008447b0 <_js_json_stringify+0x504>
1008446ac:     	add	x8, x8, #0x1
1008446b0:     	subs	x9, x9, #0x1
1008446b4:     	b.ne	0x1008446a4 <_js_json_stringify+0x3f8>
1008446b8:     	cmp	x24, #0x4
1008446bc:     	b.hs	0x10084477c <_js_json_stringify+0x4d0>
1008446c0:     	mov	x25, x22
1008446c4:     	b	0x1008447c0 <_js_json_stringify+0x514>
1008446c8:     	and	x8, x22, #0x7fffffffffffffc0
1008446cc:     	and	x8, x8, #0xffffffff0007ffff
1008446d0:     	add	x8, x21, x8
1008446d4:     	mov	x9, x21
1008446d8:     	ldp	q0, q1, [x9]
1008446dc:     	ldp	q2, q3, [x9, #0x20]
1008446e0:     	orr.16b	v0, v1, v0
1008446e4:     	orr.16b	v1, v2, v3
1008446e8:     	orr.16b	v0, v0, v1
1008446ec:     	umaxv.16b	b0, v0
1008446f0:     	fmov	w10, s0
1008446f4:     	tbnz	w10, #0x7, 0x1008445ec <_js_json_stringify+0x340>
1008446f8:     	add	x9, x9, #0x40
1008446fc:     	cmp	x9, x8
100844700:     	b.ne	0x1008446d8 <_js_json_stringify+0x42c>
100844704:     	ands	x9, x22, #0x30
100844708:     	b.eq	0x10084472c <_js_json_stringify+0x480>
10084470c:     	mov	x10, x9
100844710:     	mov	x11, x8
100844714:     	ldr	q0, [x11], #0x10
100844718:     	umaxv.16b	b0, v0
10084471c:     	fmov	w12, s0
100844720:     	tbnz	w12, #0x7, 0x1008445ec <_js_json_stringify+0x340>
100844724:     	subs	x10, x10, #0x10
100844728:     	b.ne	0x100844714 <_js_json_stringify+0x468>
10084472c:     	and	x10, x22, #0xf
100844730:     	cbz	x10, 0x10084474c <_js_json_stringify+0x4a0>
100844734:     	add	x8, x8, x9
100844738:     	ldrsb	w9, [x8]
10084473c:     	tbnz	w9, #0x1f, 0x1008445ec <_js_json_stringify+0x340>
100844740:     	add	x8, x8, #0x1
100844744:     	subs	x10, x10, #0x1
100844748:     	b.ne	0x100844738 <_js_json_stringify+0x48c>
10084474c:     	mov	x0, x22
100844750:     	bl	0x100349a2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100844754:     	mov	x23, x0
100844758:     	stp	w22, w22, [x0]
10084475c:     	stp	wzr, wzr, [x0, #0xc]
100844760:     	str	w22, [x0, #0x8]
100844764:     	cbz	w22, 0x100844848 <_js_json_stringify+0x59c>
100844768:     	and	x2, x22, #0x7ffff
10084476c:     	mov	x0, x1
100844770:     	mov	x1, x21
100844774:     	bl	0x100b6132c <_writev+0x100b6132c>
100844778:     	b	0x100844848 <_js_json_stringify+0x59c>
10084477c:     	add	x9, x21, x24
100844780:     	ldrsb	w10, [x8]
100844784:     	tbnz	w10, #0x1f, 0x1008447b0 <_js_json_stringify+0x504>
100844788:     	ldrsb	w10, [x8, #0x1]
10084478c:     	tbnz	w10, #0x1f, 0x1008447b0 <_js_json_stringify+0x504>
100844790:     	ldrsb	w10, [x8, #0x2]
100844794:     	tbnz	w10, #0x1f, 0x1008447b0 <_js_json_stringify+0x504>
100844798:     	ldrsb	w10, [x8, #0x3]
10084479c:     	tbnz	w10, #0x1f, 0x1008447b0 <_js_json_stringify+0x504>
1008447a0:     	add	x8, x8, #0x4
1008447a4:     	cmp	x8, x9
1008447a8:     	b.ne	0x100844780 <_js_json_stringify+0x4d4>
1008447ac:     	b	0x1008446c0 <_js_json_stringify+0x414>
1008447b0:     	mov	w1, w22
1008447b4:     	mov	x0, x21
1008447b8:     	bl	0x1005e8fe0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
1008447bc:     	mov	x25, x0
1008447c0:     	bl	0x1004ee780 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
1008447c4:     	add	x0, x24, #0x14
1008447c8:     	mov	w1, #0x3                ; =3
1008447cc:     	bl	0x100456c00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
1008447d0:     	mov	x23, x0
1008447d4:     	stp	w25, w22, [x0]
1008447d8:     	stp	wzr, wzr, [x0, #0xc]
1008447dc:     	str	w22, [x0, #0x8]
1008447e0:     	add	x0, x0, #0x14
1008447e4:     	mov	x1, x21
1008447e8:     	mov	x2, x24
1008447ec:     	bl	0x100b6132c <_writev+0x100b6132c>
1008447f0:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1008447f4:     	ldr	w21, [x8, #0x590]
1008447f8:     	cmp	w21, #0x300
1008447fc:     	b.hs	0x1008448d8 <_js_json_stringify+0x62c>
100844800:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100844804:     	ldr	x8, [x8, #0x48]
100844808:     	cmn	x8, #0x1
10084480c:     	b.eq	0x1008448c8 <_js_json_stringify+0x61c>
100844810:     	mrs	x9, TPIDRRO_EL0
100844814:     	and	x9, x9, #0xfffffffffffffff8
100844818:     	ldr	x0, [x9, x8, lsl #3]
10084481c:     	cbz	x0, 0x1008448c8 <_js_json_stringify+0x61c>
100844820:     	add	x8, x0, x21, lsl #3
100844824:     	ldr	x0, [x8, #0x1e8]
100844828:     	cbz	x0, 0x1008448d8 <_js_json_stringify+0x62c>
10084482c:     	ldr	x8, [x0]
100844830:     	adds	x8, x8, x24
100844834:     	csinv	x8, x8, xzr, lo
100844838:     	str	x8, [x0]
10084483c:     	lsr	x8, x8, #25
100844840:     	cbz	x8, 0x100844848 <_js_json_stringify+0x59c>
100844844:     	bl	0x10045db34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100844848:     	ldp	x22, x21, [sp, #0x8]
10084484c:     	ldrb	w8, [x20, #0x18]
100844850:     	cmp	w8, #0x1
100844854:     	b.ne	0x100844930 <_js_json_stringify+0x684>
100844858:     	ldp	x8, x0, [x20]
10084485c:     	stp	x22, x21, [x20]
100844860:     	str	xzr, [x20, #0x10]
100844864:     	sub	x8, x8, #0x1
100844868:     	cmn	x8, #0x2
10084486c:     	b.hs	0x100844874 <_js_json_stringify+0x5c8>
100844870:     	bl	0x100b5e480 <_mi_free>
100844874:     	cbz	w26, 0x100844880 <_js_json_stringify+0x5d4>
100844878:     	bl	0x100326968 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084487c:     	b	0x100844884 <_js_json_stringify+0x5d8>
100844880:     	bl	0x100326798 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100844884:     	ldr	w8, [x19]
100844888:     	sub	w8, w8, #0x1
10084488c:     	str	w8, [x19]
100844890:     	mov	x0, x23
100844894:     	ldp	x29, x30, [sp, #0x70]
100844898:     	ldp	x20, x19, [sp, #0x60]
10084489c:     	ldp	x22, x21, [sp, #0x50]
1008448a0:     	ldp	x24, x23, [sp, #0x40]
1008448a4:     	ldp	x26, x25, [sp, #0x30]
1008448a8:     	ldp	d9, d8, [sp, #0x20]
1008448ac:     	add	sp, sp, #0x80
1008448b0:     	ret
1008448b4:     	mov	x22, x0
1008448b8:     	add	x0, x0, #0x8
1008448bc:     	bl	0x100b3b1d0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1008448c0:     	mov	x0, x22
1008448c4:     	b	0x1008443f0 <_js_json_stringify+0x144>
1008448c8:     	bl	0x100b3e87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008448cc:     	add	x8, x0, x21, lsl #3
1008448d0:     	ldr	x0, [x8, #0x1e8]
1008448d4:     	cbnz	x0, 0x10084482c <_js_json_stringify+0x580>
1008448d8:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1008448dc:     	add	x0, x0, #0x78
1008448e0:     	bl	0x100b3c09c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1008448e4:     	ldr	x8, [x0]
1008448e8:     	adds	x8, x8, x24
1008448ec:     	csinv	x8, x8, xzr, lo
1008448f0:     	str	x8, [x0]
1008448f4:     	lsr	x8, x8, #25
1008448f8:     	cbnz	x8, 0x100844844 <_js_json_stringify+0x598>
1008448fc:     	b	0x100844848 <_js_json_stringify+0x59c>
100844900:     	bl	0x100b3e87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100844904:     	add	x8, x0, x20, lsl #3
100844908:     	ldr	x0, [x8, #0x1e8]
10084490c:     	cbnz	x0, 0x100844484 <_js_json_stringify+0x1d8>
100844910:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100844914:     	add	x0, x0, #0x138
100844918:     	bl	0x100b3c09c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084491c:     	b	0x100844484 <_js_json_stringify+0x1d8>
100844920:     	mov	x0, x20
100844924:     	bl	0x100b1da04 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100844928:     	cbnz	x0, 0x1008444cc <_js_json_stringify+0x220>
10084492c:     	b	0x1008449d0 <_js_json_stringify+0x724>
100844930:     	mov	x0, x20
100844934:     	bl	0x100b1da04 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100844938:     	mov	x20, x0
10084493c:     	cbnz	x0, 0x100844858 <_js_json_stringify+0x5ac>
100844940:     	cbz	x22, 0x1008449d0 <_js_json_stringify+0x724>
100844944:     	mov	x0, x21
100844948:     	bl	0x100b5e480 <_mi_free>
10084494c:     	b	0x1008449d0 <_js_json_stringify+0x724>
100844950:     	cmp	w8, #0x2
100844954:     	b.eq	0x1008449d0 <_js_json_stringify+0x724>
100844958:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime10perf_hooks8ObserverEEEB2h_+0x7c>
10084495c:     	add	x1, x1, #0x9b8
100844960:     	mov	x22, x0
100844964:     	bl	0x100a1f8dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100844968:     	mov	x0, x22
10084496c:     	strb	wzr, [x22, #0x20]
100844970:     	ldr	x8, [x22]
100844974:     	cbz	x8, 0x100844528 <_js_json_stringify+0x27c>
100844978:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084497c:     	add	x0, x0, #0xdb8
100844980:     	bl	0x100b11bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100844984:     	bl	0x100b1db64 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100844988:     	cbnz	x0, 0x1008443d0 <_js_json_stringify+0x124>
10084498c:     	b	0x1008449d0 <_js_json_stringify+0x724>
100844990:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100844994:     	add	x0, x0, #0x440
100844998:     	bl	0x100b11bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084499c:     	cmp	w8, #0x1
1008449a0:     	b.ne	0x1008449d0 <_js_json_stringify+0x724>
1008449a4:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime10perf_hooks8ObserverEEEB2h_+0x7c>
1008449a8:     	add	x1, x1, #0x358
1008449ac:     	mov	x20, x0
1008449b0:     	bl	0x100a1f8dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008449b4:     	mov	x0, x20
1008449b8:     	strb	wzr, [x20, #0x20]
1008449bc:     	ldr	x8, [x20]
1008449c0:     	cbz	x8, 0x1008444a8 <_js_json_stringify+0x1fc>
1008449c4:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008449c8:     	add	x0, x0, #0xd88
1008449cc:     	bl	0x100b11bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008449d0:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1008449d4:     	add	x0, x0, #0xc18
1008449d8:     	bl	0x100b57adc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
