
benchmarks/json_performance/.work/access-gaps-r32-profiles/r32-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001000008c0 <_perry_fn_access_worker_ts__run$spec_b_b>:
1000008c0:     	sub	sp, sp, #0xc0
1000008c4:     	stp	d15, d14, [sp, #0x20]
1000008c8:     	stp	d13, d12, [sp, #0x30]
1000008cc:     	stp	d11, d10, [sp, #0x40]
1000008d0:     	stp	d9, d8, [sp, #0x50]
1000008d4:     	stp	x28, x27, [sp, #0x60]
1000008d8:     	stp	x26, x25, [sp, #0x70]
1000008dc:     	stp	x24, x23, [sp, #0x80]
1000008e0:     	stp	x22, x21, [sp, #0x90]
1000008e4:     	stp	x20, x19, [sp, #0xa0]
1000008e8:     	stp	x29, x30, [sp, #0xb0]
1000008ec:     	add	x29, sp, #0xb0
1000008f0:     	fmov	x25, d0
1000008f4:     	fmov	x23, d1
1000008f8:     	adrp	x19, 0x100f7c000 <_perry_global_access_worker_ts__1>
1000008fc:     	ldr	x8, [x19]
100000900:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100000904:     	ldr	x9, [x9, #0x680]
100000908:     	cmp	x8, x9
10000090c:     	b.ne	0x10000093c <_perry_fn_access_worker_ts__run$spec_b_b+0x7c>
100000910:     	mov	x8, x23
100000914:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100000918:     	cmp	x8, x9
10000091c:     	b.lo	0x1000009cc <_perry_fn_access_worker_ts__run$spec_b_b+0x10c>
100000920:     	and	x9, x8, #0xffff000000000000
100000924:     	mov	x10, #0x7fff000000000000 ; =9223090561878065152
100000928:     	cmp	x9, x10
10000092c:     	b.hi	0x1000009cc <_perry_fn_access_worker_ts__run$spec_b_b+0x10c>
100000930:     	str	wzr, [sp, #0x4]
100000934:     	mov	w28, #0x0               ; =0
100000938:     	b	0x100000a08 <_perry_fn_access_worker_ts__run$spec_b_b+0x148>
10000093c:     	mov	w10, #0x7fff            ; =32767
100000940:     	cmp	x10, x8, lsr #48
100000944:     	b.ne	0x100000990 <_perry_fn_access_worker_ts__run$spec_b_b+0xd0>
100000948:     	and	x0, x8, #0xffffffffffff
10000094c:     	cmp	x0, #0x1, lsl #12       ; =0x1000
100000950:     	b.lo	0x100000990 <_perry_fn_access_worker_ts__run$spec_b_b+0xd0>
100000954:     	ldr	w10, [x0, #0x4]
100000958:     	cmp	w10, #0x6
10000095c:     	b.ne	0x100000990 <_perry_fn_access_worker_ts__run$spec_b_b+0xd0>
100000960:     	ldrb	w10, [x0, #0x14]
100000964:     	cmp	w10, #0x72
100000968:     	b.ne	0x100000990 <_perry_fn_access_worker_ts__run$spec_b_b+0xd0>
10000096c:     	ldrb	w10, [x0, #0x19]
100000970:     	cmp	w10, #0x74
100000974:     	b.ne	0x100000990 <_perry_fn_access_worker_ts__run$spec_b_b+0xd0>
100000978:     	stp	x25, x23, [sp, #0x10]
10000097c:     	and	x1, x9, #0xffffffffffff
100000980:     	bl	0x1008db600 <_js_string_equals>
100000984:     	ldp	x25, x23, [sp, #0x10]
100000988:     	cbnz	w0, 0x100000910 <_perry_fn_access_worker_ts__run$spec_b_b+0x50>
10000098c:     	ldr	x8, [x19]
100000990:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100000994:     	ldr	x9, [x9, #0x690]
100000998:     	cmp	x8, x9
10000099c:     	b.ne	0x10000101c <_perry_fn_access_worker_ts__run$spec_b_b+0x75c>
1000009a0:     	mov	x8, x23
1000009a4:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1000009a8:     	cmp	x8, x9
1000009ac:     	b.lo	0x1000010ac <_perry_fn_access_worker_ts__run$spec_b_b+0x7ec>
1000009b0:     	and	x9, x8, #0xffff000000000000
1000009b4:     	mov	x10, #0x7fff000000000000 ; =9223090561878065152
1000009b8:     	cmp	x9, x10
1000009bc:     	b.hi	0x1000010ac <_perry_fn_access_worker_ts__run$spec_b_b+0x7ec>
1000009c0:     	mov	w20, #0x0               ; =0
1000009c4:     	mov	w27, #0x0               ; =0
1000009c8:     	b	0x1000011f0 <_perry_fn_access_worker_ts__run$spec_b_b+0x930>
1000009cc:     	fmov	d0, x8
1000009d0:     	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
1000009d4:     	fmov	d1, x8
1000009d8:     	fcmp	d0, d1
1000009dc:     	b.lt	0x100000930 <_perry_fn_access_worker_ts__run$spec_b_b+0x70>
1000009e0:     	fcvtzs	w8, d0
1000009e4:     	scvtf	d1, w8
1000009e8:     	adrp	x9, 0x100b60000 <__mi_theap_area_visit_blocks.cold.1+0x44>
1000009ec:     	ldr	d2, [x9, #0xf40]
1000009f0:     	fcmp	d1, d0
1000009f4:     	cset	w9, eq
1000009f8:     	fcmp	d0, d2
1000009fc:     	csel	w8, wzr, w8, hi
100000a00:     	str	w8, [sp, #0x4]
100000a04:     	csel	w28, wzr, w9, hi
100000a08:     	mov	w26, #0x0               ; =0
100000a0c:     	mov	x24, #0x0               ; =0
100000a10:     	adrp	x20, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100000a14:     	add	x20, x20, #0x824
100000a18:     	mov	x21, #0x7ffd000000000000 ; =9222527611924643840
100000a1c:     	movi.2d	v8, #0000000000000000
100000a20:     	adrp	x19, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100000a24:     	add	x19, x19, #0x580
100000a28:     	fmov	d9, #7.00000000
100000a2c:     	adrp	x8, 0x100b60000 <__mi_theap_area_visit_blocks.cold.1+0x44>
100000a30:     	ldr	d10, [x8, #0xf50]
100000a34:     	mov	x27, #-0x3000000000000  ; =-844424930131968
100000a38:     	adrp	x22, 0x100f7c000 <_perry_global_access_worker_ts__1>
100000a3c:     	add	x22, x22, #0x28
100000a40:     	fmov	d11, #1.00000000
100000a44:     	tbnz	w28, #0x0, 0x100000a7c <_perry_fn_access_worker_ts__run$spec_b_b+0x1bc>
100000a48:     	mov	x27, x23
100000a4c:     	ldr	w8, [x22]
100000a50:     	cbz	w8, 0x100000a68 <_perry_fn_access_worker_ts__run$spec_b_b+0x1a8>
100000a54:     	stp	x25, x24, [sp, #0x10]
100000a58:     	str	x23, [sp, #0x8]
100000a5c:     	bl	0x100837b60 <_js_gc_loop_safepoint>
100000a60:     	ldp	x23, x25, [sp, #0x8]
100000a64:     	ldr	x24, [sp, #0x18]
100000a68:     	fmov	d0, x27
100000a6c:     	fcmp	d8, d0
100000a70:     	mov	x27, #-0x3000000000000  ; =-844424930131968
100000a74:     	b.pl	0x10000321c <_perry_fn_access_worker_ts__run$spec_b_b+0x295c>
100000a78:     	b	0x100000a88 <_perry_fn_access_worker_ts__run$spec_b_b+0x1c8>
100000a7c:     	ldr	w8, [sp, #0x4]
100000a80:     	cmp	w26, w8
100000a84:     	b.ge	0x10000321c <_perry_fn_access_worker_ts__run$spec_b_b+0x295c>
100000a88:     	mov	x0, x24
100000a8c:     	ldr	w8, [x20]
100000a90:     	cbz	w8, 0x100000a98 <_perry_fn_access_worker_ts__run$spec_b_b+0x1d8>
100000a94:     	bl	0x10092b40c <_js_write_barrier_root_nanbox>
100000a98:     	mov	x9, x25
100000a9c:     	and	x8, x9, #0xffffffffffff
100000aa0:     	and	x13, x9, #0xffff000000000000
100000aa4:     	cmp	x13, x21
100000aa8:     	b.ne	0x100000b14 <_perry_fn_access_worker_ts__run$spec_b_b+0x254>
100000aac:     	adrp	x10, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100000ab0:     	add	x10, x10, #0xc30
100000ab4:     	ldr	x10, [x10]
100000ab8:     	sub	x11, x8, #0x100, lsl #12 ; =0x100000
100000abc:     	cmp	x10, #0x0
100000ac0:     	mov	x10, #0x7ffffff00000    ; =140737487306752
100000ac4:     	ccmp	x11, x10, #0x2, eq
100000ac8:     	b.hs	0x100000b14 <_perry_fn_access_worker_ts__run$spec_b_b+0x254>
100000acc:     	ldurb	w11, [x8, #-0x8]
100000ad0:     	ldrb	w10, [x8, #0x8]
100000ad4:     	cmp	w11, #0xb
100000ad8:     	ccmp	w10, #0x9, #0x2, eq
100000adc:     	b.hs	0x100000b14 <_perry_fn_access_worker_ts__run$spec_b_b+0x254>
100000ae0:     	ldr	w11, [x8]
100000ae4:     	cmp	w11, #0x8
100000ae8:     	b.lo	0x100000b14 <_perry_fn_access_worker_ts__run$spec_b_b+0x254>
100000aec:     	cmp	w10, #0x3
100000af0:     	b.le	0x100000c24 <_perry_fn_access_worker_ts__run$spec_b_b+0x364>
100000af4:     	cmp	w10, #0x5
100000af8:     	b.gt	0x100000c40 <_perry_fn_access_worker_ts__run$spec_b_b+0x380>
100000afc:     	cmp	w10, #0x4
100000b00:     	b.eq	0x100000c6c <_perry_fn_access_worker_ts__run$spec_b_b+0x3ac>
100000b04:     	cmp	w10, #0x5
100000b08:     	b.ne	0x100000c60 <_perry_fn_access_worker_ts__run$spec_b_b+0x3a0>
100000b0c:     	ldr	s0, [x8, #0x2c]
100000b10:     	b	0x100000c64 <_perry_fn_access_worker_ts__run$spec_b_b+0x3a4>
100000b14:     	ldr	x12, [x19]
100000b18:     	cmp	x12, #0x0
100000b1c:     	csel	x11, x19, x12, eq
100000b20:     	cmp	x13, x21
100000b24:     	b.ne	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000b28:     	mov	x10, #-0x20000000000    ; =-2199023255552
100000b2c:     	add	x10, x8, x10
100000b30:     	lsr	x10, x10, #41
100000b34:     	cmp	x10, #0x3f
100000b38:     	b.hs	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000b3c:     	ldursb	w10, [x8, #-0x7]
100000b40:     	tbnz	w10, #0x1f, 0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000b44:     	ldurb	w10, [x8, #-0x8]
100000b48:     	cmp	w10, #0x2
100000b4c:     	b.eq	0x100000ba4 <_perry_fn_access_worker_ts__run$spec_b_b+0x2e4>
100000b50:     	cmp	w10, #0x1
100000b54:     	b.ne	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000b58:     	ldurh	w11, [x8, #-0x6]
100000b5c:     	adrp	x10, 0x10104d000 <_out_buf+0x39c8>
100000b60:     	add	x10, x10, #0x820
100000b64:     	ldrb	w10, [x10]
100000b68:     	tbnz	w11, #0xa, 0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000b6c:     	cbnz	w10, 0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000b70:     	ldr	w10, [x8]
100000b74:     	cmp	w10, #0x8
100000b78:     	b.lo	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000b7c:     	ldr	w11, [x8, #0x4]
100000b80:     	cmp	w10, w11
100000b84:     	b.hi	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000b88:     	ldr	d0, [x8, #0x40]
100000b8c:     	fmov	x8, d0
100000b90:     	mov	x9, #0x10               ; =16
100000b94:     	movk	x9, #0x7ffc, lsl #48
100000b98:     	cmp	x8, x9
100000b9c:     	fcsel	d0, d10, d0, eq
100000ba0:     	b	0x100000d64 <_perry_fn_access_worker_ts__run$spec_b_b+0x4a4>
100000ba4:     	ldr	x10, [x8, #0x8]
100000ba8:     	cbz	x10, 0x100000bf0 <_perry_fn_access_worker_ts__run$spec_b_b+0x330>
100000bac:     	ldr	x13, [x10, #0x60]
100000bb0:     	cbz	x13, 0x100000bf0 <_perry_fn_access_worker_ts__run$spec_b_b+0x330>
100000bb4:     	ldurb	w8, [x13, #-0x8]
100000bb8:     	cmp	w8, #0x1
100000bbc:     	b.ne	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000bc0:     	ldursb	w8, [x13, #-0x7]
100000bc4:     	tbnz	w8, #0x1f, 0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000bc8:     	ldr	w8, [x13]
100000bcc:     	cmp	w8, #0x8
100000bd0:     	b.lo	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000bd4:     	ldr	d0, [x13, #0x40]
100000bd8:     	fmov	x8, d0
100000bdc:     	mov	x10, #0x10              ; =16
100000be0:     	movk	x10, #0x7ffc, lsl #48
100000be4:     	cmp	x8, x10
100000be8:     	b.ne	0x100000d64 <_perry_fn_access_worker_ts__run$spec_b_b+0x4a4>
100000bec:     	b	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000bf0:     	ldr	x11, [x11]
100000bf4:     	cbz	x11, 0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000bf8:     	tbnz	x11, #0x3f, 0x100000c8c <_perry_fn_access_worker_ts__run$spec_b_b+0x3cc>
100000bfc:     	ldp	w14, w13, [x8]
100000c00:     	orr	x13, x13, x14, lsl #32
100000c04:     	cmp	x13, x11
100000c08:     	b.ne	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000c0c:     	ldp	x14, x11, [x12, #0x8]
100000c10:     	ldp	x13, x12, [x12, #0x18]
100000c14:     	cmp	x14, x12
100000c18:     	b.lo	0x100000cac <_perry_fn_access_worker_ts__run$spec_b_b+0x3ec>
100000c1c:     	cbz	x10, 0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000c20:     	b	0x100000cb8 <_perry_fn_access_worker_ts__run$spec_b_b+0x3f8>
100000c24:     	cbz	w10, 0x100000c58 <_perry_fn_access_worker_ts__run$spec_b_b+0x398>
100000c28:     	cmp	w10, #0x2
100000c2c:     	b.eq	0x100000c80 <_perry_fn_access_worker_ts__run$spec_b_b+0x3c0>
100000c30:     	cmp	w10, #0x3
100000c34:     	b.ne	0x100000c60 <_perry_fn_access_worker_ts__run$spec_b_b+0x3a0>
100000c38:     	ldr	h0, [x8, #0x1e]
100000c3c:     	b	0x100000c64 <_perry_fn_access_worker_ts__run$spec_b_b+0x3a4>
100000c40:     	cmp	w10, #0x6
100000c44:     	b.eq	0x100000c74 <_perry_fn_access_worker_ts__run$spec_b_b+0x3b4>
100000c48:     	cmp	w10, #0x7
100000c4c:     	b.ne	0x100000c60 <_perry_fn_access_worker_ts__run$spec_b_b+0x3a0>
100000c50:     	ldr	d0, [x8, #0x48]
100000c54:     	b	0x100000d64 <_perry_fn_access_worker_ts__run$spec_b_b+0x4a4>
100000c58:     	ldrsb	w8, [x8, #0x17]
100000c5c:     	b	0x100000c84 <_perry_fn_access_worker_ts__run$spec_b_b+0x3c4>
100000c60:     	ldr	b0, [x8, #0x17]
100000c64:     	ucvtf	d0, d0
100000c68:     	b	0x100000d64 <_perry_fn_access_worker_ts__run$spec_b_b+0x4a4>
100000c6c:     	ldr	w8, [x8, #0x2c]
100000c70:     	b	0x100000c84 <_perry_fn_access_worker_ts__run$spec_b_b+0x3c4>
100000c74:     	ldr	s0, [x8, #0x2c]
100000c78:     	fcvt	d0, s0
100000c7c:     	b	0x100000d64 <_perry_fn_access_worker_ts__run$spec_b_b+0x4a4>
100000c80:     	ldrsh	w8, [x8, #0x1e]
100000c84:     	scvtf	d0, w8
100000c88:     	b	0x100000d64 <_perry_fn_access_worker_ts__run$spec_b_b+0x4a4>
100000c8c:     	cbz	x10, 0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000c90:     	ldr	x13, [x10, #0x30]
100000c94:     	cmp	x13, x11
100000c98:     	b.ne	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000c9c:     	ldp	x14, x11, [x12, #0x8]
100000ca0:     	ldp	x13, x12, [x12, #0x18]
100000ca4:     	cmp	x14, x12
100000ca8:     	b.hs	0x100000cb8 <_perry_fn_access_worker_ts__run$spec_b_b+0x3f8>
100000cac:     	add	x14, x8, x14, lsl #3
100000cb0:     	add	x14, x14, #0x10
100000cb4:     	b	0x100000cdc <_perry_fn_access_worker_ts__run$spec_b_b+0x41c>
100000cb8:     	ldr	x16, [x10, #0x20]
100000cbc:     	cmp	x16, #0x0
100000cc0:     	csel	x15, x16, x10, ne
100000cc4:     	cbz	x16, 0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000cc8:     	ldr	w16, [x15]
100000ccc:     	cmp	x14, x16
100000cd0:     	b.hs	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000cd4:     	add	x14, x15, x14, lsl #3
100000cd8:     	add	x14, x14, #0x8
100000cdc:     	ldr	d0, [x14]
100000ce0:     	fcmp	d0, d9
100000ce4:     	ccmp	x13, #0x7, #0x0, gt
100000ce8:     	cset	w14, hi
100000cec:     	add	x13, x11, #0x7
100000cf0:     	cmp	x13, x12
100000cf4:     	b.hs	0x100000d08 <_perry_fn_access_worker_ts__run$spec_b_b+0x448>
100000cf8:     	cbz	w14, 0x100000d08 <_perry_fn_access_worker_ts__run$spec_b_b+0x448>
100000cfc:     	add	x8, x8, x13, lsl #3
100000d00:     	ldr	d0, [x8, #0x10]
100000d04:     	b	0x100000d64 <_perry_fn_access_worker_ts__run$spec_b_b+0x4a4>
100000d08:     	cbz	x10, 0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000d0c:     	cmp	x13, x12
100000d10:     	b.lo	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000d14:     	eor	w8, w14, #0x1
100000d18:     	tbnz	w8, #0x0, 0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000d1c:     	ldr	x12, [x10, #0x20]
100000d20:     	cmp	x12, #0x0
100000d24:     	csel	x8, x12, x10, ne
100000d28:     	cbz	x12, 0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000d2c:     	ldr	w10, [x8]
100000d30:     	cmp	x13, x10
100000d34:     	b.hs	0x100000d44 <_perry_fn_access_worker_ts__run$spec_b_b+0x484>
100000d38:     	add	x8, x8, x11, lsl #3
100000d3c:     	ldr	d0, [x8, #0x40]
100000d40:     	b	0x100000d64 <_perry_fn_access_worker_ts__run$spec_b_b+0x4a4>
100000d44:     	fmov	d0, x9
100000d48:     	stp	x23, x25, [sp, #0x10]
100000d4c:     	str	x24, [sp, #0x8]
100000d50:     	fmov	d1, #7.00000000
100000d54:     	mov	x0, x19
100000d58:     	bl	0x10089c260 <_js_packed_arraylike_index_get>
100000d5c:     	ldp	x24, x23, [sp, #0x8]
100000d60:     	ldr	x25, [sp, #0x18]
100000d64:     	fmov	x8, d0
100000d68:     	and	x9, x8, x27
100000d6c:     	cmp	x9, x21
100000d70:     	b.ne	0x100000de4 <_perry_fn_access_worker_ts__run$spec_b_b+0x524>
100000d74:     	and	x0, x8, #0xffffffffffff
100000d78:     	lsr	x8, x0, #20
100000d7c:     	cbz	x8, 0x100000f38 <_perry_fn_access_worker_ts__run$spec_b_b+0x678>
100000d80:     	ldurb	w9, [x0, #-0x8]
100000d84:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100000d88:     	ldr	x8, [x8, #0x588]
100000d8c:     	cbz	x8, 0x100000e5c <_perry_fn_access_worker_ts__run$spec_b_b+0x59c>
100000d90:     	ldurh	w10, [x0, #-0x6]
100000d94:     	and	w10, w10, #0x800
100000d98:     	cmp	w9, #0x2
100000d9c:     	ccmp	w10, #0x0, #0x0, eq
100000da0:     	b.ne	0x100000e5c <_perry_fn_access_worker_ts__run$spec_b_b+0x59c>
100000da4:     	ldr	w10, [x0, #0x4]
100000da8:     	orr	x9, x10, #0x4000000000000000
100000dac:     	cbz	w10, 0x100000e88 <_perry_fn_access_worker_ts__run$spec_b_b+0x5c8>
100000db0:     	ldr	x11, [x8]
100000db4:     	cmp	x9, x11
100000db8:     	b.ne	0x100000e88 <_perry_fn_access_worker_ts__run$spec_b_b+0x5c8>
100000dbc:     	ldr	x2, [x8, #0x8]
100000dc0:     	tbnz	w2, #0x1e, 0x100000ff8 <_perry_fn_access_worker_ts__run$spec_b_b+0x738>
100000dc4:     	add	x11, x0, x2, lsl #3
100000dc8:     	ldr	d1, [x11, #0x10]
100000dcc:     	fmov	x11, d1
100000dd0:     	mov	x12, #0x10              ; =16
100000dd4:     	movk	x12, #0x7ffc, lsl #48
100000dd8:     	cmp	x11, x12
100000ddc:     	b.ne	0x100000f64 <_perry_fn_access_worker_ts__run$spec_b_b+0x6a4>
100000de0:     	b	0x100000eb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x5f4>
100000de4:     	lsr	x9, x8, #48
100000de8:     	mov	w10, #0x7ff9            ; =32761
100000dec:     	cmp	x9, x10
100000df0:     	b.eq	0x100000e3c <_perry_fn_access_worker_ts__run$spec_b_b+0x57c>
100000df4:     	mov	w10, #0x7ffe            ; =32766
100000df8:     	cmp	w9, w10
100000dfc:     	b.ne	0x100000e2c <_perry_fn_access_worker_ts__run$spec_b_b+0x56c>
100000e00:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100000e04:     	ldr	x9, [x9, #0x688]
100000e08:     	stp	x25, x24, [sp, #0x10]
100000e0c:     	str	x23, [sp, #0x8]
100000e10:     	and	x2, x9, #0xffffffffffff
100000e14:     	mov	x0, #0x1                ; =1
100000e18:     	movk	x0, #0xddae, lsl #32
100000e1c:     	movk	x0, #0x5556, lsl #48
100000e20:     	mov	x1, x8
100000e24:     	bl	0x100903ec0 <_js_typed_feedback_object_get_field_by_name_f64>
100000e28:     	b	0x100000f58 <_perry_fn_access_worker_ts__run$spec_b_b+0x698>
100000e2c:     	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
100000e30:     	add	x9, x8, x9
100000e34:     	cmp	x9, #0x2
100000e38:     	b.lo	0x100003250 <_perry_fn_access_worker_ts__run$spec_b_b+0x2990>
100000e3c:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100000e40:     	ldr	x9, [x9, #0x688]
100000e44:     	stp	x25, x24, [sp, #0x10]
100000e48:     	str	x23, [sp, #0x8]
100000e4c:     	and	x1, x9, #0xffffffffffff
100000e50:     	mov	x0, x8
100000e54:     	bl	0x100885498 <_js_object_get_field_by_name_f64>
100000e58:     	b	0x100000f58 <_perry_fn_access_worker_ts__run$spec_b_b+0x698>
100000e5c:     	cmp	w9, #0x2
100000e60:     	ccmp	x8, #0x0, #0x4, eq
100000e64:     	b.eq	0x100000f38 <_perry_fn_access_worker_ts__run$spec_b_b+0x678>
100000e68:     	ldr	x9, [x8, #0x10]
100000e6c:     	cbz	x9, 0x100000f38 <_perry_fn_access_worker_ts__run$spec_b_b+0x678>
100000e70:     	ldr	x10, [x0, #0x8]
100000e74:     	cbz	x10, 0x100000f38 <_perry_fn_access_worker_ts__run$spec_b_b+0x678>
100000e78:     	ldr	x10, [x10, #0x30]
100000e7c:     	cmp	x10, x9
100000e80:     	b.eq	0x100000ea4 <_perry_fn_access_worker_ts__run$spec_b_b+0x5e4>
100000e84:     	b	0x100000f38 <_perry_fn_access_worker_ts__run$spec_b_b+0x678>
100000e88:     	ldr	x11, [x8, #0x10]
100000e8c:     	cbz	x11, 0x100000eb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x5f4>
100000e90:     	ldr	x12, [x0, #0x8]
100000e94:     	cbz	x12, 0x100000eb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x5f4>
100000e98:     	ldr	x12, [x12, #0x30]
100000e9c:     	cmp	x12, x11
100000ea0:     	b.ne	0x100000eb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x5f4>
100000ea4:     	ldr	x8, [x8, #0x8]
100000ea8:     	add	x8, x0, x8, lsl #3
100000eac:     	ldr	d1, [x8, #0x10]
100000eb0:     	b	0x100000f64 <_perry_fn_access_worker_ts__run$spec_b_b+0x6a4>
100000eb4:     	ldr	x11, [x8, #0x18]
100000eb8:     	cmp	x11, #0x0
100000ebc:     	b.le	0x100000f38 <_perry_fn_access_worker_ts__run$spec_b_b+0x678>
100000ec0:     	ldr	x11, [x8, #0x20]
100000ec4:     	ldr	x12, [x8, #0x30]
100000ec8:     	ldr	x13, [x8, #0x40]
100000ecc:     	cmp	x13, x9
100000ed0:     	ldr	x14, [x8, #0x50]
100000ed4:     	ccmp	x14, x9, #0x4, ne
100000ed8:     	ccmp	x12, x9, #0x4, ne
100000edc:     	ccmp	x11, x9, #0x4, ne
100000ee0:     	cset	w15, eq
100000ee4:     	cbz	w10, 0x100000f38 <_perry_fn_access_worker_ts__run$spec_b_b+0x678>
100000ee8:     	cbz	w15, 0x100000f38 <_perry_fn_access_worker_ts__run$spec_b_b+0x678>
100000eec:     	ldr	x10, [x8, #0x48]
100000ef0:     	ldr	x15, [x8, #0x58]
100000ef4:     	cmp	x14, x9
100000ef8:     	csel	x14, x15, xzr, eq
100000efc:     	cmp	x13, x9
100000f00:     	csel	x10, x10, x14, eq
100000f04:     	ldr	x13, [x8, #0x28]
100000f08:     	ldr	x8, [x8, #0x38]
100000f0c:     	cmp	x12, x9
100000f10:     	csel	x8, x8, x10, eq
100000f14:     	cmp	x11, x9
100000f18:     	csel	x8, x13, x8, eq
100000f1c:     	add	x8, x0, x8, lsl #3
100000f20:     	ldr	d1, [x8, #0x10]
100000f24:     	fmov	x8, d1
100000f28:     	mov	x9, #0x10               ; =16
100000f2c:     	movk	x9, #0x7ffc, lsl #48
100000f30:     	cmp	x8, x9
100000f34:     	b.ne	0x100000f64 <_perry_fn_access_worker_ts__run$spec_b_b+0x6a4>
100000f38:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100000f3c:     	ldr	x8, [x8, #0x688]
100000f40:     	stp	x25, x24, [sp, #0x10]
100000f44:     	str	x23, [sp, #0x8]
100000f48:     	and	x1, x8, #0xffffffffffff
100000f4c:     	adrp	x2, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100000f50:     	add	x2, x2, #0x588
100000f54:     	bl	0x100885980 <_js_object_get_field_ic_miss>
100000f58:     	mov.16b	v1, v0
100000f5c:     	ldp	x23, x25, [sp, #0x8]
100000f60:     	ldr	x24, [sp, #0x18]
100000f64:     	fmov	d0, x24
100000f68:     	and	x9, x24, #0xffff000000000000
100000f6c:     	fmov	x8, d1
100000f70:     	and	x10, x8, #0xffff000000000000
100000f74:     	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
100000f78:     	cmp	x8, x11
100000f7c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100000f80:     	ccmp	x10, x8, #0x2, hs
100000f84:     	cset	w8, hi
100000f88:     	mov	x10, #0x1               ; =1
100000f8c:     	movk	x10, #0x7fff, lsl #48
100000f90:     	cmp	x9, x10
100000f94:     	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
100000f98:     	ccmp	x24, x9, #0x0, lo
100000f9c:     	b.hi	0x100000fac <_perry_fn_access_worker_ts__run$spec_b_b+0x6ec>
100000fa0:     	tbz	w8, #0x0, 0x100000fac <_perry_fn_access_worker_ts__run$spec_b_b+0x6ec>
100000fa4:     	fadd	d0, d1, d0
100000fa8:     	b	0x100000fb8 <_perry_fn_access_worker_ts__run$spec_b_b+0x6f8>
100000fac:     	stp	x23, x25, [sp, #0x10]
100000fb0:     	bl	0x10081f2e4 <_js_dynamic_string_or_number_add>
100000fb4:     	ldp	x23, x25, [sp, #0x10]
100000fb8:     	fmov	x24, d0
100000fbc:     	mov	x0, x24
100000fc0:     	ldr	w8, [x20]
100000fc4:     	cbz	w8, 0x100000fcc <_perry_fn_access_worker_ts__run$spec_b_b+0x70c>
100000fc8:     	bl	0x10092b40c <_js_write_barrier_root_nanbox>
100000fcc:     	ldr	w8, [x22]
100000fd0:     	cbz	w8, 0x100000fe8 <_perry_fn_access_worker_ts__run$spec_b_b+0x728>
100000fd4:     	stp	x25, x23, [sp, #0x10]
100000fd8:     	str	x24, [sp, #0x8]
100000fdc:     	bl	0x100837b60 <_js_gc_loop_safepoint>
100000fe0:     	ldp	x24, x25, [sp, #0x8]
100000fe4:     	ldr	x23, [sp, #0x18]
100000fe8:     	fadd	d8, d8, d11
100000fec:     	add	w26, w26, #0x1
100000ff0:     	tbz	w28, #0x0, 0x100000a48 <_perry_fn_access_worker_ts__run$spec_b_b+0x188>
100000ff4:     	b	0x100000a7c <_perry_fn_access_worker_ts__run$spec_b_b+0x1bc>
100000ff8:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100000ffc:     	ldr	x8, [x8, #0x688]
100001000:     	stp	x25, x24, [sp, #0x10]
100001004:     	str	x23, [sp, #0x8]
100001008:     	and	x1, x8, #0xffffffffffff
10000100c:     	adrp	x3, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100001010:     	add	x3, x3, #0x588
100001014:     	bl	0x100886300 <_js_object_get_field_ic_overflow_load>
100001018:     	b	0x100000f58 <_perry_fn_access_worker_ts__run$spec_b_b+0x698>
10000101c:     	mov	w10, #0x7fff            ; =32767
100001020:     	cmp	x10, x8, lsr #48
100001024:     	b.ne	0x100001070 <_perry_fn_access_worker_ts__run$spec_b_b+0x7b0>
100001028:     	and	x0, x8, #0xffffffffffff
10000102c:     	cmp	x0, #0x1, lsl #12       ; =0x1000
100001030:     	b.lo	0x100001070 <_perry_fn_access_worker_ts__run$spec_b_b+0x7b0>
100001034:     	ldr	w10, [x0, #0x4]
100001038:     	cmp	w10, #0x6
10000103c:     	b.ne	0x100001070 <_perry_fn_access_worker_ts__run$spec_b_b+0x7b0>
100001040:     	ldrb	w10, [x0, #0x14]
100001044:     	cmp	w10, #0x72
100001048:     	b.ne	0x100001070 <_perry_fn_access_worker_ts__run$spec_b_b+0x7b0>
10000104c:     	ldrb	w10, [x0, #0x19]
100001050:     	cmp	w10, #0x6d
100001054:     	b.ne	0x100001070 <_perry_fn_access_worker_ts__run$spec_b_b+0x7b0>
100001058:     	stp	x25, x23, [sp, #0x10]
10000105c:     	and	x1, x9, #0xffffffffffff
100001060:     	bl	0x1008db600 <_js_string_equals>
100001064:     	ldp	x25, x23, [sp, #0x10]
100001068:     	cbnz	w0, 0x1000009a0 <_perry_fn_access_worker_ts__run$spec_b_b+0xe0>
10000106c:     	ldr	x8, [x19]
100001070:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100001074:     	ldr	x9, [x9, #0x698]
100001078:     	cmp	x8, x9
10000107c:     	b.ne	0x1000010f0 <_perry_fn_access_worker_ts__run$spec_b_b+0x830>
100001080:     	mov	x8, x23
100001084:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100001088:     	cmp	x8, x9
10000108c:     	b.lo	0x10000116c <_perry_fn_access_worker_ts__run$spec_b_b+0x8ac>
100001090:     	and	x9, x8, #0xffff000000000000
100001094:     	mov	x10, #0x7fff000000000000 ; =9223090561878065152
100001098:     	cmp	x9, x10
10000109c:     	b.hi	0x10000116c <_perry_fn_access_worker_ts__run$spec_b_b+0x8ac>
1000010a0:     	mov	w22, #0x0               ; =0
1000010a4:     	mov	w26, #0x0               ; =0
1000010a8:     	b	0x1000018cc <_perry_fn_access_worker_ts__run$spec_b_b+0x100c>
1000010ac:     	mov	w20, #0x0               ; =0
1000010b0:     	fmov	d0, x8
1000010b4:     	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
1000010b8:     	fmov	d1, x8
1000010bc:     	fcmp	d0, d1
1000010c0:     	b.lt	0x1000011ec <_perry_fn_access_worker_ts__run$spec_b_b+0x92c>
1000010c4:     	adrp	x8, 0x100b60000 <__mi_theap_area_visit_blocks.cold.1+0x44>
1000010c8:     	ldr	d1, [x8, #0xf40]
1000010cc:     	fcmp	d0, d1
1000010d0:     	mov	x27, x20
1000010d4:     	b.hi	0x1000011f0 <_perry_fn_access_worker_ts__run$spec_b_b+0x930>
1000010d8:     	fcvtzs	w20, d0
1000010dc:     	scvtf	d1, w20
1000010e0:     	fcmp	d1, d0
1000010e4:     	b.ne	0x1000009c4 <_perry_fn_access_worker_ts__run$spec_b_b+0x104>
1000010e8:     	mov	w27, #0x1               ; =1
1000010ec:     	b	0x1000011f0 <_perry_fn_access_worker_ts__run$spec_b_b+0x930>
1000010f0:     	mov	w10, #0x7fff            ; =32767
1000010f4:     	cmp	x10, x8, lsr #48
1000010f8:     	b.ne	0x100001140 <_perry_fn_access_worker_ts__run$spec_b_b+0x880>
1000010fc:     	and	x0, x8, #0xffffffffffff
100001100:     	cmp	x0, #0x1, lsl #12       ; =0x1000
100001104:     	b.lo	0x100001140 <_perry_fn_access_worker_ts__run$spec_b_b+0x880>
100001108:     	ldr	w8, [x0, #0x4]
10000110c:     	cmp	w8, #0x6
100001110:     	b.ne	0x100001140 <_perry_fn_access_worker_ts__run$spec_b_b+0x880>
100001114:     	ldrb	w8, [x0, #0x14]
100001118:     	cmp	w8, #0x66
10000111c:     	b.ne	0x100001140 <_perry_fn_access_worker_ts__run$spec_b_b+0x880>
100001120:     	ldrb	w8, [x0, #0x19]
100001124:     	cmp	w8, #0x73
100001128:     	b.ne	0x100001140 <_perry_fn_access_worker_ts__run$spec_b_b+0x880>
10000112c:     	stp	x25, x23, [sp, #0x10]
100001130:     	and	x1, x9, #0xffffffffffff
100001134:     	bl	0x1008db600 <_js_string_equals>
100001138:     	ldp	x25, x23, [sp, #0x10]
10000113c:     	cbnz	w0, 0x100001080 <_perry_fn_access_worker_ts__run$spec_b_b+0x7c0>
100001140:     	mov	x8, x23
100001144:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100001148:     	cmp	x8, x9
10000114c:     	b.lo	0x1000011ac <_perry_fn_access_worker_ts__run$spec_b_b+0x8ec>
100001150:     	and	x9, x8, #0xffff000000000000
100001154:     	mov	x10, #0x7fff000000000000 ; =9223090561878065152
100001158:     	cmp	x9, x10
10000115c:     	b.hi	0x1000011ac <_perry_fn_access_worker_ts__run$spec_b_b+0x8ec>
100001160:     	mov	w28, #0x0               ; =0
100001164:     	mov	w27, #0x0               ; =0
100001168:     	b	0x100002b90 <_perry_fn_access_worker_ts__run$spec_b_b+0x22d0>
10000116c:     	mov	w22, #0x0               ; =0
100001170:     	fmov	d0, x8
100001174:     	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
100001178:     	fmov	d1, x8
10000117c:     	fcmp	d0, d1
100001180:     	b.lt	0x1000018c8 <_perry_fn_access_worker_ts__run$spec_b_b+0x1008>
100001184:     	adrp	x8, 0x100b60000 <__mi_theap_area_visit_blocks.cold.1+0x44>
100001188:     	ldr	d1, [x8, #0xf40]
10000118c:     	fcmp	d0, d1
100001190:     	mov	x26, x22
100001194:     	b.hi	0x1000018cc <_perry_fn_access_worker_ts__run$spec_b_b+0x100c>
100001198:     	fcvtzs	w22, d0
10000119c:     	frintz	d1, d0
1000011a0:     	fcmp	d1, d0
1000011a4:     	cset	w26, eq
1000011a8:     	b	0x1000018cc <_perry_fn_access_worker_ts__run$spec_b_b+0x100c>
1000011ac:     	mov	w28, #0x0               ; =0
1000011b0:     	fmov	d0, x8
1000011b4:     	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
1000011b8:     	fmov	d1, x8
1000011bc:     	fcmp	d0, d1
1000011c0:     	b.lt	0x100002b8c <_perry_fn_access_worker_ts__run$spec_b_b+0x22cc>
1000011c4:     	adrp	x8, 0x100b60000 <__mi_theap_area_visit_blocks.cold.1+0x44>
1000011c8:     	ldr	d1, [x8, #0xf40]
1000011cc:     	fcmp	d0, d1
1000011d0:     	mov	x27, x28
1000011d4:     	b.hi	0x100002b90 <_perry_fn_access_worker_ts__run$spec_b_b+0x22d0>
1000011d8:     	fcvtzs	w28, d0
1000011dc:     	frintz	d1, d0
1000011e0:     	fcmp	d1, d0
1000011e4:     	cset	w27, eq
1000011e8:     	b	0x100002b90 <_perry_fn_access_worker_ts__run$spec_b_b+0x22d0>
1000011ec:     	mov	x27, x20
1000011f0:     	mov	w26, #0x0               ; =0
1000011f4:     	mov	x24, #0x0               ; =0
1000011f8:     	movi.2d	v8, #0000000000000000
1000011fc:     	mov	x28, #0x7ff9000000000000 ; =9221401712017801216
100001200:     	adrp	x22, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100001204:     	add	x22, x22, #0x824
100001208:     	mov	x21, #0x7ffd000000000000 ; =9222527611924643840
10000120c:     	fmov	d9, #17.00000000
100001210:     	mov	x8, #0x41f0000000000000 ; =4751297606875873280
100001214:     	fmov	d10, #7.00000000
100001218:     	adrp	x19, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
10000121c:     	add	x19, x19, #0x590
100001220:     	fmov	d11, x8
100001224:     	adrp	x8, 0x100b60000 <__mi_theap_area_visit_blocks.cold.1+0x44>
100001228:     	ldr	d12, [x8, #0xf48]
10000122c:     	adrp	x8, 0x100b60000 <__mi_theap_area_visit_blocks.cold.1+0x44>
100001230:     	ldr	d13, [x8, #0xf50]
100001234:     	fmov	d14, #1.00000000
100001238:     	movi.2d	v15, #0000000000000000
10000123c:     	tbnz	w27, #0x0, 0x100001284 <_perry_fn_access_worker_ts__run$spec_b_b+0x9c4>
100001240:     	mov	x28, x20
100001244:     	mov	x20, x23
100001248:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
10000124c:     	add	x8, x8, #0x28
100001250:     	ldr	w8, [x8]
100001254:     	cbz	w8, 0x10000126c <_perry_fn_access_worker_ts__run$spec_b_b+0x9ac>
100001258:     	stp	x24, x23, [sp, #0x10]
10000125c:     	str	x25, [sp, #0x8]
100001260:     	bl	0x100837b60 <_js_gc_loop_safepoint>
100001264:     	ldp	x25, x24, [sp, #0x8]
100001268:     	ldr	x23, [sp, #0x18]
10000126c:     	fmov	d0, x20
100001270:     	fcmp	d15, d0
100001274:     	mov	x20, x28
100001278:     	mov	x28, #0x7ff9000000000000 ; =9221401712017801216
10000127c:     	b.pl	0x10000321c <_perry_fn_access_worker_ts__run$spec_b_b+0x295c>
100001280:     	b	0x10000128c <_perry_fn_access_worker_ts__run$spec_b_b+0x9cc>
100001284:     	cmp	w26, w20
100001288:     	b.ge	0x10000321c <_perry_fn_access_worker_ts__run$spec_b_b+0x295c>
10000128c:     	fmov	x8, d8
100001290:     	cmp	x8, x28
100001294:     	b.lo	0x1000012c8 <_perry_fn_access_worker_ts__run$spec_b_b+0xa08>
100001298:     	and	x8, x8, #0xffff000000000000
10000129c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
1000012a0:     	cmp	x8, x9
1000012a4:     	b.hi	0x1000012c8 <_perry_fn_access_worker_ts__run$spec_b_b+0xa08>
1000012a8:     	stp	x24, x23, [sp, #0x10]
1000012ac:     	str	x25, [sp, #0x8]
1000012b0:     	fmov	d1, #17.00000000
1000012b4:     	mov.16b	v0, v8
1000012b8:     	bl	0x10081dc28 <_js_dynamic_mul>
1000012bc:     	ldp	x25, x24, [sp, #0x8]
1000012c0:     	ldr	x23, [sp, #0x18]
1000012c4:     	b	0x1000012cc <_perry_fn_access_worker_ts__run$spec_b_b+0xa0c>
1000012c8:     	fmul	d0, d8, d9
1000012cc:     	fadd	d0, d0, d10
1000012d0:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1000012d4:     	ldr	d1, [x8, #0x8]
1000012d8:     	stp	x25, x24, [sp, #0x10]
1000012dc:     	str	x23, [sp, #0x8]
1000012e0:     	bl	0x10081d9d4 <_js_dynamic_mod>
1000012e4:     	mov.16b	v8, v0
1000012e8:     	ldp	x23, x25, [sp, #0x8]
1000012ec:     	ldr	x24, [sp, #0x18]
1000012f0:     	fmov	x8, d8
1000012f4:     	mov	w9, #0x7fff             ; =32767
1000012f8:     	cmp	x9, x8, lsr #48
1000012fc:     	b.ne	0x100001308 <_perry_fn_access_worker_ts__run$spec_b_b+0xa48>
100001300:     	mov.16b	v0, v8
100001304:     	bl	0x1008d7034 <_js_string_addref_if_heap_string>
100001308:     	mov	x0, x24
10000130c:     	ldr	w8, [x22]
100001310:     	cbz	w8, 0x100001318 <_perry_fn_access_worker_ts__run$spec_b_b+0xa58>
100001314:     	bl	0x10092b40c <_js_write_barrier_root_nanbox>
100001318:     	mov	x8, x25
10000131c:     	and	x9, x8, #0xffffffffffff
100001320:     	and	x14, x8, #0xffff000000000000
100001324:     	cmp	x14, x21
100001328:     	b.ne	0x100001384 <_perry_fn_access_worker_ts__run$spec_b_b+0xac4>
10000132c:     	adrp	x10, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100001330:     	add	x10, x10, #0xc30
100001334:     	ldr	x10, [x10]
100001338:     	sub	x11, x9, #0x100, lsl #12 ; =0x100000
10000133c:     	cmp	x10, #0x0
100001340:     	mov	x10, #0x7ffffff00000    ; =140737487306752
100001344:     	ccmp	x11, x10, #0x2, eq
100001348:     	b.hs	0x100001384 <_perry_fn_access_worker_ts__run$spec_b_b+0xac4>
10000134c:     	fcmp	d8, d11
100001350:     	b.pl	0x100001384 <_perry_fn_access_worker_ts__run$spec_b_b+0xac4>
100001354:     	ldurb	w10, [x9, #-0x8]
100001358:     	ldrb	w11, [x9, #0x8]
10000135c:     	fcmp	d8, #0.0
100001360:     	ccmp	w10, #0xb, #0x0, ge
100001364:     	ccmp	w11, #0x9, #0x2, eq
100001368:     	b.hs	0x100001384 <_perry_fn_access_worker_ts__run$spec_b_b+0xac4>
10000136c:     	fcvtzs	x10, d8
100001370:     	scvtf	d0, x10
100001374:     	ldr	w12, [x9]
100001378:     	fcmp	d8, d0
10000137c:     	ccmp	x10, x12, #0x2, eq
100001380:     	b.lo	0x100001434 <_perry_fn_access_worker_ts__run$spec_b_b+0xb74>
100001384:     	ldr	x12, [x19]
100001388:     	cmp	x12, #0x0
10000138c:     	csel	x13, x19, x12, eq
100001390:     	cmp	x14, x21
100001394:     	b.ne	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
100001398:     	fcmp	d8, #0.0
10000139c:     	b.lt	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000013a0:     	fcmp	d8, d12
1000013a4:     	b.pl	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000013a8:     	mov	x10, #-0x20000000000    ; =-2199023255552
1000013ac:     	add	x10, x9, x10
1000013b0:     	lsr	x10, x10, #41
1000013b4:     	cmp	x10, #0x3f
1000013b8:     	b.hs	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000013bc:     	fcvtzs	x10, d8
1000013c0:     	scvtf	d0, x10
1000013c4:     	fcmp	d8, d0
1000013c8:     	b.ne	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000013cc:     	ldursb	w11, [x9, #-0x7]
1000013d0:     	tbnz	w11, #0x1f, 0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000013d4:     	ldurb	w11, [x9, #-0x8]
1000013d8:     	cmp	w11, #0x2
1000013dc:     	b.eq	0x100001460 <_perry_fn_access_worker_ts__run$spec_b_b+0xba0>
1000013e0:     	cmp	w11, #0x1
1000013e4:     	b.ne	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000013e8:     	ldurh	w13, [x9, #-0x6]
1000013ec:     	adrp	x11, 0x10104d000 <_out_buf+0x39c8>
1000013f0:     	add	x11, x11, #0x820
1000013f4:     	ldrb	w12, [x11]
1000013f8:     	ldp	w11, w14, [x9]
1000013fc:     	cmp	w11, w14
100001400:     	b.hi	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
100001404:     	tbnz	w13, #0xa, 0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
100001408:     	cbnz	w12, 0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
10000140c:     	cmp	x10, x11
100001410:     	b.hs	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
100001414:     	add	x8, x9, x10, lsl #3
100001418:     	ldr	d0, [x8, #0x8]
10000141c:     	fmov	x8, d0
100001420:     	mov	x9, #0x10               ; =16
100001424:     	movk	x9, #0x7ffc, lsl #48
100001428:     	cmp	x8, x9
10000142c:     	fcsel	d0, d13, d0, eq
100001430:     	b	0x100001614 <_perry_fn_access_worker_ts__run$spec_b_b+0xd54>
100001434:     	add	x8, x9, #0x10
100001438:     	cmp	w11, #0x3
10000143c:     	b.le	0x1000014b0 <_perry_fn_access_worker_ts__run$spec_b_b+0xbf0>
100001440:     	cmp	w11, #0x5
100001444:     	b.gt	0x100001500 <_perry_fn_access_worker_ts__run$spec_b_b+0xc40>
100001448:     	cmp	w11, #0x4
10000144c:     	b.eq	0x10000152c <_perry_fn_access_worker_ts__run$spec_b_b+0xc6c>
100001450:     	cmp	w11, #0x5
100001454:     	b.ne	0x100001520 <_perry_fn_access_worker_ts__run$spec_b_b+0xc60>
100001458:     	ldr	s0, [x8, x10, lsl #2]
10000145c:     	b	0x100001524 <_perry_fn_access_worker_ts__run$spec_b_b+0xc64>
100001460:     	ldr	x11, [x9, #0x8]
100001464:     	cbz	x11, 0x1000014cc <_perry_fn_access_worker_ts__run$spec_b_b+0xc0c>
100001468:     	ldr	x14, [x11, #0x60]
10000146c:     	cbz	x14, 0x1000014cc <_perry_fn_access_worker_ts__run$spec_b_b+0xc0c>
100001470:     	ldurb	w9, [x14, #-0x8]
100001474:     	cmp	w9, #0x1
100001478:     	b.ne	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
10000147c:     	ldursb	w9, [x14, #-0x7]
100001480:     	tbnz	w9, #0x1f, 0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
100001484:     	ldr	w9, [x14]
100001488:     	cmp	x10, x9
10000148c:     	b.hs	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
100001490:     	add	x9, x14, x10, lsl #3
100001494:     	ldr	d0, [x9, #0x8]
100001498:     	fmov	x9, d0
10000149c:     	mov	x10, #0x10              ; =16
1000014a0:     	movk	x10, #0x7ffc, lsl #48
1000014a4:     	cmp	x9, x10
1000014a8:     	b.ne	0x100001614 <_perry_fn_access_worker_ts__run$spec_b_b+0xd54>
1000014ac:     	b	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000014b0:     	cbz	w11, 0x100001518 <_perry_fn_access_worker_ts__run$spec_b_b+0xc58>
1000014b4:     	cmp	w11, #0x2
1000014b8:     	b.eq	0x100001540 <_perry_fn_access_worker_ts__run$spec_b_b+0xc80>
1000014bc:     	cmp	w11, #0x3
1000014c0:     	b.ne	0x100001520 <_perry_fn_access_worker_ts__run$spec_b_b+0xc60>
1000014c4:     	ldr	h0, [x8, x10, lsl #1]
1000014c8:     	b	0x100001524 <_perry_fn_access_worker_ts__run$spec_b_b+0xc64>
1000014cc:     	ldr	x13, [x13]
1000014d0:     	cbz	x13, 0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000014d4:     	tbnz	x13, #0x3f, 0x10000154c <_perry_fn_access_worker_ts__run$spec_b_b+0xc8c>
1000014d8:     	ldp	w15, w14, [x9]
1000014dc:     	orr	x14, x14, x15, lsl #32
1000014e0:     	cmp	x14, x13
1000014e4:     	b.ne	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000014e8:     	ldp	x15, x13, [x12, #0x8]
1000014ec:     	ldp	x14, x12, [x12, #0x18]
1000014f0:     	cmp	x15, x12
1000014f4:     	b.lo	0x10000156c <_perry_fn_access_worker_ts__run$spec_b_b+0xcac>
1000014f8:     	cbz	x11, 0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000014fc:     	b	0x100001578 <_perry_fn_access_worker_ts__run$spec_b_b+0xcb8>
100001500:     	cmp	w11, #0x6
100001504:     	b.eq	0x100001534 <_perry_fn_access_worker_ts__run$spec_b_b+0xc74>
100001508:     	cmp	w11, #0x7
10000150c:     	b.ne	0x100001520 <_perry_fn_access_worker_ts__run$spec_b_b+0xc60>
100001510:     	ldr	d0, [x8, x10, lsl #3]
100001514:     	b	0x100001614 <_perry_fn_access_worker_ts__run$spec_b_b+0xd54>
100001518:     	ldrsb	w8, [x8, x10]
10000151c:     	b	0x100001544 <_perry_fn_access_worker_ts__run$spec_b_b+0xc84>
100001520:     	ldr	b0, [x8, x10]
100001524:     	ucvtf	d0, d0
100001528:     	b	0x100001614 <_perry_fn_access_worker_ts__run$spec_b_b+0xd54>
10000152c:     	ldr	w8, [x8, x10, lsl #2]
100001530:     	b	0x100001544 <_perry_fn_access_worker_ts__run$spec_b_b+0xc84>
100001534:     	ldr	s0, [x8, x10, lsl #2]
100001538:     	fcvt	d0, s0
10000153c:     	b	0x100001614 <_perry_fn_access_worker_ts__run$spec_b_b+0xd54>
100001540:     	ldrsh	w8, [x8, x10, lsl #1]
100001544:     	scvtf	d0, w8
100001548:     	b	0x100001614 <_perry_fn_access_worker_ts__run$spec_b_b+0xd54>
10000154c:     	cbz	x11, 0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
100001550:     	ldr	x14, [x11, #0x30]
100001554:     	cmp	x14, x13
100001558:     	b.ne	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
10000155c:     	ldp	x15, x13, [x12, #0x8]
100001560:     	ldp	x14, x12, [x12, #0x18]
100001564:     	cmp	x15, x12
100001568:     	b.hs	0x100001578 <_perry_fn_access_worker_ts__run$spec_b_b+0xcb8>
10000156c:     	add	x15, x9, x15, lsl #3
100001570:     	add	x15, x15, #0x10
100001574:     	b	0x10000159c <_perry_fn_access_worker_ts__run$spec_b_b+0xcdc>
100001578:     	ldr	x17, [x11, #0x20]
10000157c:     	cmp	x17, #0x0
100001580:     	csel	x16, x17, x11, ne
100001584:     	cbz	x17, 0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
100001588:     	ldr	w17, [x16]
10000158c:     	cmp	x15, x17
100001590:     	b.hs	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
100001594:     	add	x15, x16, x15, lsl #3
100001598:     	add	x15, x15, #0x8
10000159c:     	ldr	d0, [x15]
1000015a0:     	fcmp	d8, d0
1000015a4:     	ccmp	x14, x10, #0x0, mi
1000015a8:     	cset	w14, hi
1000015ac:     	add	x10, x13, x10
1000015b0:     	cmp	x10, x12
1000015b4:     	ccmp	w14, #0x0, #0x4, lo
1000015b8:     	b.ne	0x1000018bc <_perry_fn_access_worker_ts__run$spec_b_b+0xffc>
1000015bc:     	cbz	x11, 0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000015c0:     	cmp	x10, x12
1000015c4:     	b.lo	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000015c8:     	eor	w9, w14, #0x1
1000015cc:     	tbnz	w9, #0x0, 0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000015d0:     	ldr	x12, [x11, #0x20]
1000015d4:     	cmp	x12, #0x0
1000015d8:     	csel	x9, x12, x11, ne
1000015dc:     	cbz	x12, 0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000015e0:     	ldr	w11, [x9]
1000015e4:     	cmp	x10, x11
1000015e8:     	b.hs	0x1000015f8 <_perry_fn_access_worker_ts__run$spec_b_b+0xd38>
1000015ec:     	add	x8, x9, x10, lsl #3
1000015f0:     	ldr	d0, [x8, #0x8]
1000015f4:     	b	0x100001614 <_perry_fn_access_worker_ts__run$spec_b_b+0xd54>
1000015f8:     	fmov	d0, x8
1000015fc:     	str	x24, [sp, #0x18]
100001600:     	mov.16b	v1, v8
100001604:     	mov	x0, x19
100001608:     	bl	0x10089c260 <_js_packed_arraylike_index_get>
10000160c:     	ldp	x25, x24, [sp, #0x10]
100001610:     	ldr	x23, [sp, #0x8]
100001614:     	fmov	x8, d0
100001618:     	mov	x9, #-0x3000000000000   ; =-844424930131968
10000161c:     	and	x9, x8, x9
100001620:     	cmp	x9, x21
100001624:     	b.ne	0x100001690 <_perry_fn_access_worker_ts__run$spec_b_b+0xdd0>
100001628:     	and	x0, x8, #0xffffffffffff
10000162c:     	lsr	x8, x0, #20
100001630:     	cbz	x8, 0x1000017e4 <_perry_fn_access_worker_ts__run$spec_b_b+0xf24>
100001634:     	ldurb	w9, [x0, #-0x8]
100001638:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
10000163c:     	ldr	x8, [x8, #0x598]
100001640:     	cbz	x8, 0x100001700 <_perry_fn_access_worker_ts__run$spec_b_b+0xe40>
100001644:     	ldurh	w10, [x0, #-0x6]
100001648:     	and	w10, w10, #0x800
10000164c:     	cmp	w9, #0x2
100001650:     	ccmp	w10, #0x0, #0x0, eq
100001654:     	b.ne	0x100001700 <_perry_fn_access_worker_ts__run$spec_b_b+0xe40>
100001658:     	ldr	w10, [x0, #0x4]
10000165c:     	orr	x9, x10, #0x4000000000000000
100001660:     	ldr	x11, [x8]
100001664:     	cmp	w10, #0x0
100001668:     	ccmp	x9, x11, #0x0, ne
10000166c:     	b.eq	0x100001738 <_perry_fn_access_worker_ts__run$spec_b_b+0xe78>
100001670:     	ldr	x11, [x8, #0x10]
100001674:     	cbz	x11, 0x10000175c <_perry_fn_access_worker_ts__run$spec_b_b+0xe9c>
100001678:     	ldr	x12, [x0, #0x8]
10000167c:     	cbz	x12, 0x10000175c <_perry_fn_access_worker_ts__run$spec_b_b+0xe9c>
100001680:     	ldr	x12, [x12, #0x30]
100001684:     	cmp	x12, x11
100001688:     	b.eq	0x100001728 <_perry_fn_access_worker_ts__run$spec_b_b+0xe68>
10000168c:     	b	0x10000175c <_perry_fn_access_worker_ts__run$spec_b_b+0xe9c>
100001690:     	lsr	x9, x8, #48
100001694:     	mov	w10, #0x7ff9            ; =32761
100001698:     	cmp	x9, x10
10000169c:     	b.eq	0x1000016e4 <_perry_fn_access_worker_ts__run$spec_b_b+0xe24>
1000016a0:     	mov	w10, #0x7ffe            ; =32766
1000016a4:     	cmp	w9, w10
1000016a8:     	b.ne	0x1000016d4 <_perry_fn_access_worker_ts__run$spec_b_b+0xe14>
1000016ac:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1000016b0:     	ldr	x9, [x9, #0x688]
1000016b4:     	str	x24, [sp, #0x18]
1000016b8:     	and	x2, x9, #0xffffffffffff
1000016bc:     	mov	x0, #0x4                ; =4
1000016c0:     	movk	x0, #0xddae, lsl #32
1000016c4:     	movk	x0, #0x5556, lsl #48
1000016c8:     	mov	x1, x8
1000016cc:     	bl	0x100903ec0 <_js_typed_feedback_object_get_field_by_name_f64>
1000016d0:     	b	0x100001800 <_perry_fn_access_worker_ts__run$spec_b_b+0xf40>
1000016d4:     	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
1000016d8:     	add	x9, x8, x9
1000016dc:     	cmp	x9, #0x2
1000016e0:     	b.lo	0x100003250 <_perry_fn_access_worker_ts__run$spec_b_b+0x2990>
1000016e4:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1000016e8:     	ldr	x9, [x9, #0x688]
1000016ec:     	str	x24, [sp, #0x18]
1000016f0:     	and	x1, x9, #0xffffffffffff
1000016f4:     	mov	x0, x8
1000016f8:     	bl	0x100885498 <_js_object_get_field_by_name_f64>
1000016fc:     	b	0x100001800 <_perry_fn_access_worker_ts__run$spec_b_b+0xf40>
100001700:     	cmp	w9, #0x2
100001704:     	ccmp	x8, #0x0, #0x4, eq
100001708:     	b.eq	0x1000017e4 <_perry_fn_access_worker_ts__run$spec_b_b+0xf24>
10000170c:     	ldr	x9, [x8, #0x10]
100001710:     	cbz	x9, 0x1000017e4 <_perry_fn_access_worker_ts__run$spec_b_b+0xf24>
100001714:     	ldr	x10, [x0, #0x8]
100001718:     	cbz	x10, 0x1000017e4 <_perry_fn_access_worker_ts__run$spec_b_b+0xf24>
10000171c:     	ldr	x10, [x10, #0x30]
100001720:     	cmp	x10, x9
100001724:     	b.ne	0x1000017e4 <_perry_fn_access_worker_ts__run$spec_b_b+0xf24>
100001728:     	ldr	x8, [x8, #0x8]
10000172c:     	add	x8, x0, x8, lsl #3
100001730:     	ldr	d1, [x8, #0x10]
100001734:     	b	0x10000180c <_perry_fn_access_worker_ts__run$spec_b_b+0xf4c>
100001738:     	ldr	x2, [x8, #0x8]
10000173c:     	tbnz	w2, #0x1e, 0x10000189c <_perry_fn_access_worker_ts__run$spec_b_b+0xfdc>
100001740:     	add	x11, x0, x2, lsl #3
100001744:     	ldr	d1, [x11, #0x10]
100001748:     	fmov	x11, d1
10000174c:     	mov	x12, #0x10              ; =16
100001750:     	movk	x12, #0x7ffc, lsl #48
100001754:     	cmp	x11, x12
100001758:     	b.ne	0x10000180c <_perry_fn_access_worker_ts__run$spec_b_b+0xf4c>
10000175c:     	ldr	x11, [x8, #0x18]
100001760:     	cmp	x11, #0x0
100001764:     	b.le	0x1000017e4 <_perry_fn_access_worker_ts__run$spec_b_b+0xf24>
100001768:     	ldr	x11, [x8, #0x20]
10000176c:     	ldr	x12, [x8, #0x30]
100001770:     	ldr	x13, [x8, #0x40]
100001774:     	cmp	x13, x9
100001778:     	ldr	x14, [x8, #0x50]
10000177c:     	ccmp	x14, x9, #0x4, ne
100001780:     	ccmp	x12, x9, #0x4, ne
100001784:     	ccmp	x11, x9, #0x4, ne
100001788:     	cset	w15, eq
10000178c:     	cmp	w10, #0x0
100001790:     	ccmp	w15, #0x0, #0x4, ne
100001794:     	b.eq	0x1000017e4 <_perry_fn_access_worker_ts__run$spec_b_b+0xf24>
100001798:     	ldr	x10, [x8, #0x48]
10000179c:     	ldr	x15, [x8, #0x58]
1000017a0:     	cmp	x14, x9
1000017a4:     	csel	x14, x15, xzr, eq
1000017a8:     	cmp	x13, x9
1000017ac:     	csel	x10, x10, x14, eq
1000017b0:     	ldr	x13, [x8, #0x28]
1000017b4:     	ldr	x8, [x8, #0x38]
1000017b8:     	cmp	x12, x9
1000017bc:     	csel	x8, x8, x10, eq
1000017c0:     	cmp	x11, x9
1000017c4:     	csel	x8, x13, x8, eq
1000017c8:     	add	x8, x0, x8, lsl #3
1000017cc:     	ldr	d1, [x8, #0x10]
1000017d0:     	fmov	x8, d1
1000017d4:     	mov	x9, #0x10               ; =16
1000017d8:     	movk	x9, #0x7ffc, lsl #48
1000017dc:     	cmp	x8, x9
1000017e0:     	b.ne	0x10000180c <_perry_fn_access_worker_ts__run$spec_b_b+0xf4c>
1000017e4:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1000017e8:     	ldr	x8, [x8, #0x688]
1000017ec:     	str	x24, [sp, #0x18]
1000017f0:     	and	x1, x8, #0xffffffffffff
1000017f4:     	adrp	x2, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1000017f8:     	add	x2, x2, #0x598
1000017fc:     	bl	0x100885980 <_js_object_get_field_ic_miss>
100001800:     	mov.16b	v1, v0
100001804:     	ldp	x23, x25, [sp, #0x8]
100001808:     	ldr	x24, [sp, #0x18]
10000180c:     	fmov	d0, x24
100001810:     	and	x9, x24, #0xffff000000000000
100001814:     	fmov	x8, d1
100001818:     	and	x10, x8, #0xffff000000000000
10000181c:     	cmp	x8, x28
100001820:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100001824:     	ccmp	x10, x8, #0x2, hs
100001828:     	cset	w8, hi
10000182c:     	mov	x10, #0x1               ; =1
100001830:     	movk	x10, #0x7fff, lsl #48
100001834:     	cmp	x9, x10
100001838:     	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
10000183c:     	ccmp	x24, x9, #0x0, lo
100001840:     	b.hi	0x100001850 <_perry_fn_access_worker_ts__run$spec_b_b+0xf90>
100001844:     	tbz	w8, #0x0, 0x100001850 <_perry_fn_access_worker_ts__run$spec_b_b+0xf90>
100001848:     	fadd	d0, d1, d0
10000184c:     	b	0x100001858 <_perry_fn_access_worker_ts__run$spec_b_b+0xf98>
100001850:     	bl	0x10081f2e4 <_js_dynamic_string_or_number_add>
100001854:     	ldp	x23, x25, [sp, #0x8]
100001858:     	fmov	x24, d0
10000185c:     	mov	x0, x24
100001860:     	ldr	w8, [x22]
100001864:     	cbz	w8, 0x10000186c <_perry_fn_access_worker_ts__run$spec_b_b+0xfac>
100001868:     	bl	0x10092b40c <_js_write_barrier_root_nanbox>
10000186c:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100001870:     	add	x8, x8, #0x28
100001874:     	ldr	w8, [x8]
100001878:     	cbz	w8, 0x10000188c <_perry_fn_access_worker_ts__run$spec_b_b+0xfcc>
10000187c:     	str	x24, [sp, #0x18]
100001880:     	bl	0x100837b60 <_js_gc_loop_safepoint>
100001884:     	ldp	x25, x24, [sp, #0x10]
100001888:     	ldr	x23, [sp, #0x8]
10000188c:     	fadd	d15, d15, d14
100001890:     	add	w26, w26, #0x1
100001894:     	tbz	w27, #0x0, 0x100001240 <_perry_fn_access_worker_ts__run$spec_b_b+0x980>
100001898:     	b	0x100001284 <_perry_fn_access_worker_ts__run$spec_b_b+0x9c4>
10000189c:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1000018a0:     	ldr	x8, [x8, #0x688]
1000018a4:     	str	x24, [sp, #0x18]
1000018a8:     	and	x1, x8, #0xffffffffffff
1000018ac:     	adrp	x3, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1000018b0:     	add	x3, x3, #0x598
1000018b4:     	bl	0x100886300 <_js_object_get_field_ic_overflow_load>
1000018b8:     	b	0x100001800 <_perry_fn_access_worker_ts__run$spec_b_b+0xf40>
1000018bc:     	add	x8, x9, x10, lsl #3
1000018c0:     	ldr	d0, [x8, #0x10]
1000018c4:     	b	0x100001614 <_perry_fn_access_worker_ts__run$spec_b_b+0xd54>
1000018c8:     	mov	x26, x22
1000018cc:     	mov	w9, #0x0                ; =0
1000018d0:     	mov	x24, #0x0               ; =0
1000018d4:     	adrp	x27, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1000018d8:     	add	x27, x27, #0x824
1000018dc:     	adrp	x19, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1000018e0:     	add	x19, x19, #0xc30
1000018e4:     	adrp	x21, 0x100f7c000 <_perry_global_access_worker_ts__1>
1000018e8:     	mov	x20, #0x7ffd000000000000 ; =9222527611924643840
1000018ec:     	adrp	x8, 0x100b60000 <__mi_theap_area_visit_blocks.cold.1+0x44>
1000018f0:     	ldr	d9, [x8, #0xf48]
1000018f4:     	adrp	x8, 0x100b60000 <__mi_theap_area_visit_blocks.cold.1+0x44>
1000018f8:     	ldr	d10, [x8, #0xf50]
1000018fc:     	mov	x8, #0x41f0000000000000 ; =4751297606875873280
100001900:     	fmov	d11, x8
100001904:     	tbnz	w26, #0x0, 0x100001974 <_perry_fn_access_worker_ts__run$spec_b_b+0x10b4>
100001908:     	mov	x28, x27
10000190c:     	mov	x27, x21
100001910:     	mov	x21, x19
100001914:     	mov	x19, x26
100001918:     	mov	x26, x22
10000191c:     	mov	x22, x23
100001920:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100001924:     	add	x8, x8, #0x28
100001928:     	ldr	w8, [x8]
10000192c:     	cbz	w8, 0x10000194c <_perry_fn_access_worker_ts__run$spec_b_b+0x108c>
100001930:     	stp	x25, x23, [sp, #0x10]
100001934:     	str	x24, [sp, #0x8]
100001938:     	mov	x23, x9
10000193c:     	bl	0x100837b60 <_js_gc_loop_safepoint>
100001940:     	mov	x9, x23
100001944:     	ldp	x24, x25, [sp, #0x8]
100001948:     	ldr	x23, [sp, #0x18]
10000194c:     	scvtf	d0, w9
100001950:     	fmov	d1, x22
100001954:     	fcmp	d0, d1
100001958:     	mov	x22, x26
10000195c:     	mov	x26, x19
100001960:     	mov	x19, x21
100001964:     	mov	x21, x27
100001968:     	mov	x27, x28
10000196c:     	b.pl	0x10000321c <_perry_fn_access_worker_ts__run$spec_b_b+0x295c>
100001970:     	b	0x100001980 <_perry_fn_access_worker_ts__run$spec_b_b+0x10c0>
100001974:     	cmp	w9, w22
100001978:     	b.ge	0x10000321c <_perry_fn_access_worker_ts__run$spec_b_b+0x295c>
10000197c:     	scvtf	d0, w9
100001980:     	mov	x28, x9
100001984:     	ldr	d1, [x21, #0x8]
100001988:     	stp	x23, x24, [sp, #0x10]
10000198c:     	str	x25, [sp, #0x8]
100001990:     	bl	0x10081d9d4 <_js_dynamic_mod>
100001994:     	mov.16b	v8, v0
100001998:     	ldp	x25, x23, [sp, #0x8]
10000199c:     	ldr	x24, [sp, #0x18]
1000019a0:     	mov	x0, x24
1000019a4:     	ldr	w8, [x27]
1000019a8:     	cbz	w8, 0x1000019b0 <_perry_fn_access_worker_ts__run$spec_b_b+0x10f0>
1000019ac:     	bl	0x10092b40c <_js_write_barrier_root_nanbox>
1000019b0:     	mov	x8, x25
1000019b4:     	and	x9, x8, #0xffffffffffff
1000019b8:     	and	x14, x8, #0xffff000000000000
1000019bc:     	ldr	x10, [x19]
1000019c0:     	sub	x11, x9, #0x100, lsl #12 ; =0x100000
1000019c4:     	cmp	x14, x20
1000019c8:     	ccmp	x10, #0x0, #0x0, eq
1000019cc:     	mov	x10, #0x7ffffff00000    ; =140737487306752
1000019d0:     	ccmp	x11, x10, #0x2, eq
1000019d4:     	b.hs	0x100001a18 <_perry_fn_access_worker_ts__run$spec_b_b+0x1158>
1000019d8:     	mov	x10, #0x41f0000000000000 ; =4751297606875873280
1000019dc:     	fmov	d0, x10
1000019e0:     	fcmp	d8, d0
1000019e4:     	b.pl	0x100001a18 <_perry_fn_access_worker_ts__run$spec_b_b+0x1158>
1000019e8:     	ldurb	w10, [x9, #-0x8]
1000019ec:     	ldrb	w11, [x9, #0x8]
1000019f0:     	fcmp	d8, #0.0
1000019f4:     	ccmp	w10, #0xb, #0x0, ge
1000019f8:     	ccmp	w11, #0x9, #0x2, eq
1000019fc:     	b.hs	0x100001a18 <_perry_fn_access_worker_ts__run$spec_b_b+0x1158>
100001a00:     	fcvtzs	x10, d8
100001a04:     	scvtf	d0, x10
100001a08:     	ldr	w12, [x9]
100001a0c:     	fcmp	d8, d0
100001a10:     	ccmp	x10, x12, #0x2, eq
100001a14:     	b.lo	0x100001ad0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1210>
100001a18:     	adrp	x10, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100001a1c:     	add	x10, x10, #0x5a0
100001a20:     	ldr	x12, [x10]
100001a24:     	cmp	x12, #0x0
100001a28:     	csel	x13, x10, x12, eq
100001a2c:     	cmp	x14, x20
100001a30:     	b.ne	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001a34:     	fcmp	d8, #0.0
100001a38:     	b.lt	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001a3c:     	fcmp	d8, d9
100001a40:     	b.pl	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001a44:     	mov	x10, #-0x20000000000    ; =-2199023255552
100001a48:     	add	x10, x9, x10
100001a4c:     	lsr	x10, x10, #41
100001a50:     	cmp	x10, #0x3f
100001a54:     	b.hs	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001a58:     	fcvtzs	x10, d8
100001a5c:     	scvtf	d0, x10
100001a60:     	fcmp	d8, d0
100001a64:     	b.ne	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001a68:     	ldursb	w11, [x9, #-0x7]
100001a6c:     	tbnz	w11, #0x1f, 0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001a70:     	ldurb	w11, [x9, #-0x8]
100001a74:     	cmp	w11, #0x2
100001a78:     	b.eq	0x100001afc <_perry_fn_access_worker_ts__run$spec_b_b+0x123c>
100001a7c:     	cmp	w11, #0x1
100001a80:     	b.ne	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001a84:     	ldurh	w13, [x9, #-0x6]
100001a88:     	adrp	x11, 0x10104d000 <_out_buf+0x39c8>
100001a8c:     	add	x11, x11, #0x820
100001a90:     	ldrb	w12, [x11]
100001a94:     	ldp	w11, w14, [x9]
100001a98:     	cmp	w11, w14
100001a9c:     	b.hi	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001aa0:     	tbnz	w13, #0xa, 0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001aa4:     	cbnz	w12, 0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001aa8:     	cmp	x10, x11
100001aac:     	b.hs	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001ab0:     	add	x8, x9, x10, lsl #3
100001ab4:     	ldr	d0, [x8, #0x8]
100001ab8:     	fmov	x8, d0
100001abc:     	mov	x9, #0x10               ; =16
100001ac0:     	movk	x9, #0x7ffc, lsl #48
100001ac4:     	cmp	x8, x9
100001ac8:     	fcsel	d0, d10, d0, eq
100001acc:     	b	0x100001cb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x13f4>
100001ad0:     	add	x8, x9, #0x10
100001ad4:     	cmp	w11, #0x3
100001ad8:     	b.le	0x100001b4c <_perry_fn_access_worker_ts__run$spec_b_b+0x128c>
100001adc:     	cmp	w11, #0x5
100001ae0:     	b.gt	0x100001b9c <_perry_fn_access_worker_ts__run$spec_b_b+0x12dc>
100001ae4:     	cmp	w11, #0x4
100001ae8:     	b.eq	0x100001bc8 <_perry_fn_access_worker_ts__run$spec_b_b+0x1308>
100001aec:     	cmp	w11, #0x5
100001af0:     	b.ne	0x100001bbc <_perry_fn_access_worker_ts__run$spec_b_b+0x12fc>
100001af4:     	ldr	s0, [x8, x10, lsl #2]
100001af8:     	b	0x100001bc0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1300>
100001afc:     	ldr	x11, [x9, #0x8]
100001b00:     	cbz	x11, 0x100001b68 <_perry_fn_access_worker_ts__run$spec_b_b+0x12a8>
100001b04:     	ldr	x14, [x11, #0x60]
100001b08:     	cbz	x14, 0x100001b68 <_perry_fn_access_worker_ts__run$spec_b_b+0x12a8>
100001b0c:     	ldurb	w9, [x14, #-0x8]
100001b10:     	cmp	w9, #0x1
100001b14:     	b.ne	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001b18:     	ldursb	w9, [x14, #-0x7]
100001b1c:     	tbnz	w9, #0x1f, 0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001b20:     	ldr	w9, [x14]
100001b24:     	cmp	x10, x9
100001b28:     	b.hs	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001b2c:     	add	x9, x14, x10, lsl #3
100001b30:     	ldr	d0, [x9, #0x8]
100001b34:     	fmov	x9, d0
100001b38:     	mov	x10, #0x10              ; =16
100001b3c:     	movk	x10, #0x7ffc, lsl #48
100001b40:     	cmp	x9, x10
100001b44:     	b.ne	0x100001cb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x13f4>
100001b48:     	b	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001b4c:     	cbz	w11, 0x100001bb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x12f4>
100001b50:     	cmp	w11, #0x2
100001b54:     	b.eq	0x100001bdc <_perry_fn_access_worker_ts__run$spec_b_b+0x131c>
100001b58:     	cmp	w11, #0x3
100001b5c:     	b.ne	0x100001bbc <_perry_fn_access_worker_ts__run$spec_b_b+0x12fc>
100001b60:     	ldr	h0, [x8, x10, lsl #1]
100001b64:     	b	0x100001bc0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1300>
100001b68:     	ldr	x13, [x13]
100001b6c:     	cbz	x13, 0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001b70:     	tbnz	x13, #0x3f, 0x100001be8 <_perry_fn_access_worker_ts__run$spec_b_b+0x1328>
100001b74:     	ldp	w15, w14, [x9]
100001b78:     	orr	x14, x14, x15, lsl #32
100001b7c:     	cmp	x14, x13
100001b80:     	b.ne	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001b84:     	ldp	x15, x13, [x12, #0x8]
100001b88:     	ldp	x14, x12, [x12, #0x18]
100001b8c:     	cmp	x15, x12
100001b90:     	b.lo	0x100001c08 <_perry_fn_access_worker_ts__run$spec_b_b+0x1348>
100001b94:     	cbz	x11, 0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001b98:     	b	0x100001c14 <_perry_fn_access_worker_ts__run$spec_b_b+0x1354>
100001b9c:     	cmp	w11, #0x6
100001ba0:     	b.eq	0x100001bd0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1310>
100001ba4:     	cmp	w11, #0x7
100001ba8:     	b.ne	0x100001bbc <_perry_fn_access_worker_ts__run$spec_b_b+0x12fc>
100001bac:     	ldr	d0, [x8, x10, lsl #3]
100001bb0:     	b	0x100001cb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x13f4>
100001bb4:     	ldrsb	w8, [x8, x10]
100001bb8:     	b	0x100001be0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1320>
100001bbc:     	ldr	b0, [x8, x10]
100001bc0:     	ucvtf	d0, d0
100001bc4:     	b	0x100001cb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x13f4>
100001bc8:     	ldr	w8, [x8, x10, lsl #2]
100001bcc:     	b	0x100001be0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1320>
100001bd0:     	ldr	s0, [x8, x10, lsl #2]
100001bd4:     	fcvt	d0, s0
100001bd8:     	b	0x100001cb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x13f4>
100001bdc:     	ldrsh	w8, [x8, x10, lsl #1]
100001be0:     	scvtf	d0, w8
100001be4:     	b	0x100001cb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x13f4>
100001be8:     	cbz	x11, 0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001bec:     	ldr	x14, [x11, #0x30]
100001bf0:     	cmp	x14, x13
100001bf4:     	b.ne	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001bf8:     	ldp	x15, x13, [x12, #0x8]
100001bfc:     	ldp	x14, x12, [x12, #0x18]
100001c00:     	cmp	x15, x12
100001c04:     	b.hs	0x100001c14 <_perry_fn_access_worker_ts__run$spec_b_b+0x1354>
100001c08:     	add	x15, x9, x15, lsl #3
100001c0c:     	add	x15, x15, #0x10
100001c10:     	b	0x100001c38 <_perry_fn_access_worker_ts__run$spec_b_b+0x1378>
100001c14:     	ldr	x17, [x11, #0x20]
100001c18:     	cmp	x17, #0x0
100001c1c:     	csel	x16, x17, x11, ne
100001c20:     	cbz	x17, 0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001c24:     	ldr	w17, [x16]
100001c28:     	cmp	x15, x17
100001c2c:     	b.hs	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001c30:     	add	x15, x16, x15, lsl #3
100001c34:     	add	x15, x15, #0x8
100001c38:     	ldr	d0, [x15]
100001c3c:     	fcmp	d8, d0
100001c40:     	ccmp	x14, x10, #0x0, mi
100001c44:     	cset	w14, hi
100001c48:     	add	x10, x13, x10
100001c4c:     	cmp	x10, x12
100001c50:     	ccmp	w14, #0x0, #0x4, lo
100001c54:     	b.ne	0x100002b80 <_perry_fn_access_worker_ts__run$spec_b_b+0x22c0>
100001c58:     	cbz	x11, 0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001c5c:     	cmp	x10, x12
100001c60:     	b.lo	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001c64:     	eor	w9, w14, #0x1
100001c68:     	tbnz	w9, #0x0, 0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001c6c:     	ldr	x12, [x11, #0x20]
100001c70:     	cmp	x12, #0x0
100001c74:     	csel	x9, x12, x11, ne
100001c78:     	cbz	x12, 0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001c7c:     	ldr	w11, [x9]
100001c80:     	cmp	x10, x11
100001c84:     	b.hs	0x100001c94 <_perry_fn_access_worker_ts__run$spec_b_b+0x13d4>
100001c88:     	add	x8, x9, x10, lsl #3
100001c8c:     	ldr	d0, [x8, #0x8]
100001c90:     	b	0x100001cb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x13f4>
100001c94:     	fmov	d0, x8
100001c98:     	str	x24, [sp, #0x18]
100001c9c:     	mov.16b	v1, v8
100001ca0:     	adrp	x0, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100001ca4:     	add	x0, x0, #0x5a0
100001ca8:     	bl	0x10089c260 <_js_packed_arraylike_index_get>
100001cac:     	ldp	x25, x23, [sp, #0x8]
100001cb0:     	ldr	x24, [sp, #0x18]
100001cb4:     	fmov	x8, d0
100001cb8:     	mov	x9, #-0x3000000000000   ; =-844424930131968
100001cbc:     	and	x9, x8, x9
100001cc0:     	cmp	x9, x20
100001cc4:     	b.ne	0x100001d30 <_perry_fn_access_worker_ts__run$spec_b_b+0x1470>
100001cc8:     	and	x0, x8, #0xffffffffffff
100001ccc:     	lsr	x8, x0, #20
100001cd0:     	cbz	x8, 0x100001e84 <_perry_fn_access_worker_ts__run$spec_b_b+0x15c4>
100001cd4:     	ldurb	w9, [x0, #-0x8]
100001cd8:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100001cdc:     	ldr	x8, [x8, #0x5a8]
100001ce0:     	cbz	x8, 0x100001da0 <_perry_fn_access_worker_ts__run$spec_b_b+0x14e0>
100001ce4:     	ldurh	w10, [x0, #-0x6]
100001ce8:     	and	w10, w10, #0x800
100001cec:     	cmp	w9, #0x2
100001cf0:     	ccmp	w10, #0x0, #0x0, eq
100001cf4:     	b.ne	0x100001da0 <_perry_fn_access_worker_ts__run$spec_b_b+0x14e0>
100001cf8:     	ldr	w10, [x0, #0x4]
100001cfc:     	orr	x9, x10, #0x4000000000000000
100001d00:     	ldr	x11, [x8]
100001d04:     	cmp	w10, #0x0
100001d08:     	ccmp	x9, x11, #0x0, ne
100001d0c:     	b.eq	0x100001dd8 <_perry_fn_access_worker_ts__run$spec_b_b+0x1518>
100001d10:     	ldr	x11, [x8, #0x10]
100001d14:     	cbz	x11, 0x100001dfc <_perry_fn_access_worker_ts__run$spec_b_b+0x153c>
100001d18:     	ldr	x12, [x0, #0x8]
100001d1c:     	cbz	x12, 0x100001dfc <_perry_fn_access_worker_ts__run$spec_b_b+0x153c>
100001d20:     	ldr	x12, [x12, #0x30]
100001d24:     	cmp	x12, x11
100001d28:     	b.eq	0x100001dc8 <_perry_fn_access_worker_ts__run$spec_b_b+0x1508>
100001d2c:     	b	0x100001dfc <_perry_fn_access_worker_ts__run$spec_b_b+0x153c>
100001d30:     	lsr	x9, x8, #48
100001d34:     	mov	w10, #0x7ff9            ; =32761
100001d38:     	cmp	x9, x10
100001d3c:     	b.eq	0x100001d84 <_perry_fn_access_worker_ts__run$spec_b_b+0x14c4>
100001d40:     	mov	w10, #0x7ffe            ; =32766
100001d44:     	cmp	w9, w10
100001d48:     	b.ne	0x100001d74 <_perry_fn_access_worker_ts__run$spec_b_b+0x14b4>
100001d4c:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100001d50:     	ldr	x9, [x9, #0x688]
100001d54:     	str	x24, [sp, #0x18]
100001d58:     	and	x2, x9, #0xffffffffffff
100001d5c:     	mov	x0, #0x7                ; =7
100001d60:     	movk	x0, #0xddae, lsl #32
100001d64:     	movk	x0, #0x5556, lsl #48
100001d68:     	mov	x1, x8
100001d6c:     	bl	0x100903ec0 <_js_typed_feedback_object_get_field_by_name_f64>
100001d70:     	b	0x100001ea0 <_perry_fn_access_worker_ts__run$spec_b_b+0x15e0>
100001d74:     	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
100001d78:     	add	x9, x8, x9
100001d7c:     	cmp	x9, #0x2
100001d80:     	b.lo	0x100003250 <_perry_fn_access_worker_ts__run$spec_b_b+0x2990>
100001d84:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100001d88:     	ldr	x9, [x9, #0x688]
100001d8c:     	str	x24, [sp, #0x18]
100001d90:     	and	x1, x9, #0xffffffffffff
100001d94:     	mov	x0, x8
100001d98:     	bl	0x100885498 <_js_object_get_field_by_name_f64>
100001d9c:     	b	0x100001ea0 <_perry_fn_access_worker_ts__run$spec_b_b+0x15e0>
100001da0:     	cmp	w9, #0x2
100001da4:     	ccmp	x8, #0x0, #0x4, eq
100001da8:     	b.eq	0x100001e84 <_perry_fn_access_worker_ts__run$spec_b_b+0x15c4>
100001dac:     	ldr	x9, [x8, #0x10]
100001db0:     	cbz	x9, 0x100001e84 <_perry_fn_access_worker_ts__run$spec_b_b+0x15c4>
100001db4:     	ldr	x10, [x0, #0x8]
100001db8:     	cbz	x10, 0x100001e84 <_perry_fn_access_worker_ts__run$spec_b_b+0x15c4>
100001dbc:     	ldr	x10, [x10, #0x30]
100001dc0:     	cmp	x10, x9
100001dc4:     	b.ne	0x100001e84 <_perry_fn_access_worker_ts__run$spec_b_b+0x15c4>
100001dc8:     	ldr	x8, [x8, #0x8]
100001dcc:     	add	x8, x0, x8, lsl #3
100001dd0:     	ldr	d1, [x8, #0x10]
100001dd4:     	b	0x100001eac <_perry_fn_access_worker_ts__run$spec_b_b+0x15ec>
100001dd8:     	ldr	x2, [x8, #0x8]
100001ddc:     	tbnz	w2, #0x1e, 0x100002128 <_perry_fn_access_worker_ts__run$spec_b_b+0x1868>
100001de0:     	add	x11, x0, x2, lsl #3
100001de4:     	ldr	d1, [x11, #0x10]
100001de8:     	fmov	x11, d1
100001dec:     	mov	x12, #0x10              ; =16
100001df0:     	movk	x12, #0x7ffc, lsl #48
100001df4:     	cmp	x11, x12
100001df8:     	b.ne	0x100001eac <_perry_fn_access_worker_ts__run$spec_b_b+0x15ec>
100001dfc:     	ldr	x11, [x8, #0x18]
100001e00:     	cmp	x11, #0x0
100001e04:     	b.le	0x100001e84 <_perry_fn_access_worker_ts__run$spec_b_b+0x15c4>
100001e08:     	ldr	x11, [x8, #0x20]
100001e0c:     	ldr	x12, [x8, #0x30]
100001e10:     	ldr	x13, [x8, #0x40]
100001e14:     	cmp	x13, x9
100001e18:     	ldr	x14, [x8, #0x50]
100001e1c:     	ccmp	x14, x9, #0x4, ne
100001e20:     	ccmp	x12, x9, #0x4, ne
100001e24:     	ccmp	x11, x9, #0x4, ne
100001e28:     	cset	w15, eq
100001e2c:     	cmp	w10, #0x0
100001e30:     	ccmp	w15, #0x0, #0x4, ne
100001e34:     	b.eq	0x100001e84 <_perry_fn_access_worker_ts__run$spec_b_b+0x15c4>
100001e38:     	ldr	x10, [x8, #0x48]
100001e3c:     	ldr	x15, [x8, #0x58]
100001e40:     	cmp	x14, x9
100001e44:     	csel	x14, x15, xzr, eq
100001e48:     	cmp	x13, x9
100001e4c:     	csel	x10, x10, x14, eq
100001e50:     	ldr	x13, [x8, #0x28]
100001e54:     	ldr	x8, [x8, #0x38]
100001e58:     	cmp	x12, x9
100001e5c:     	csel	x8, x8, x10, eq
100001e60:     	cmp	x11, x9
100001e64:     	csel	x8, x13, x8, eq
100001e68:     	add	x8, x0, x8, lsl #3
100001e6c:     	ldr	d1, [x8, #0x10]
100001e70:     	fmov	x8, d1
100001e74:     	mov	x9, #0x10               ; =16
100001e78:     	movk	x9, #0x7ffc, lsl #48
100001e7c:     	cmp	x8, x9
100001e80:     	b.ne	0x100001eac <_perry_fn_access_worker_ts__run$spec_b_b+0x15ec>
100001e84:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100001e88:     	ldr	x8, [x8, #0x688]
100001e8c:     	str	x24, [sp, #0x18]
100001e90:     	and	x1, x8, #0xffffffffffff
100001e94:     	adrp	x2, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100001e98:     	add	x2, x2, #0x5a8
100001e9c:     	bl	0x100885980 <_js_object_get_field_ic_miss>
100001ea0:     	mov.16b	v1, v0
100001ea4:     	ldp	x25, x23, [sp, #0x8]
100001ea8:     	ldr	x24, [sp, #0x18]
100001eac:     	fmov	d0, x24
100001eb0:     	and	x9, x24, #0xffff000000000000
100001eb4:     	fmov	x8, d1
100001eb8:     	and	x10, x8, #0xffff000000000000
100001ebc:     	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
100001ec0:     	cmp	x8, x11
100001ec4:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100001ec8:     	ccmp	x10, x8, #0x2, hs
100001ecc:     	cset	w8, hi
100001ed0:     	mov	x10, #0x1               ; =1
100001ed4:     	movk	x10, #0x7fff, lsl #48
100001ed8:     	cmp	x9, x10
100001edc:     	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
100001ee0:     	ccmp	x24, x9, #0x0, lo
100001ee4:     	b.hi	0x100001ef4 <_perry_fn_access_worker_ts__run$spec_b_b+0x1634>
100001ee8:     	tbz	w8, #0x0, 0x100001ef4 <_perry_fn_access_worker_ts__run$spec_b_b+0x1634>
100001eec:     	fadd	d0, d1, d0
100001ef0:     	b	0x100001efc <_perry_fn_access_worker_ts__run$spec_b_b+0x163c>
100001ef4:     	bl	0x10081f2e4 <_js_dynamic_string_or_number_add>
100001ef8:     	ldp	x25, x23, [sp, #0x8]
100001efc:     	fmov	x24, d0
100001f00:     	mov	x0, x24
100001f04:     	ldr	w8, [x27]
100001f08:     	cbz	w8, 0x100001f10 <_perry_fn_access_worker_ts__run$spec_b_b+0x1650>
100001f0c:     	bl	0x10092b40c <_js_write_barrier_root_nanbox>
100001f10:     	mov	x0, x24
100001f14:     	ldr	w8, [x27]
100001f18:     	cbz	w8, 0x100001f20 <_perry_fn_access_worker_ts__run$spec_b_b+0x1660>
100001f1c:     	bl	0x10092b40c <_js_write_barrier_root_nanbox>
100001f20:     	mov	x8, x25
100001f24:     	and	x9, x8, #0xffffffffffff
100001f28:     	and	x11, x8, #0xffff000000000000
100001f2c:     	cmp	x11, x20
100001f30:     	b.ne	0x100001f8c <_perry_fn_access_worker_ts__run$spec_b_b+0x16cc>
100001f34:     	ldr	x10, [x19]
100001f38:     	cbnz	x10, 0x100001f8c <_perry_fn_access_worker_ts__run$spec_b_b+0x16cc>
100001f3c:     	sub	x10, x9, #0x100, lsl #12 ; =0x100000
100001f40:     	mov	x12, #0x7ffffff00000    ; =140737487306752
100001f44:     	cmp	x10, x12
100001f48:     	b.hs	0x100001f8c <_perry_fn_access_worker_ts__run$spec_b_b+0x16cc>
100001f4c:     	fcmp	d8, d11
100001f50:     	b.pl	0x100001f8c <_perry_fn_access_worker_ts__run$spec_b_b+0x16cc>
100001f54:     	fcmp	d8, #0.0
100001f58:     	b.lt	0x100001f8c <_perry_fn_access_worker_ts__run$spec_b_b+0x16cc>
100001f5c:     	ldurb	w10, [x9, #-0x8]
100001f60:     	cmp	w10, #0xb
100001f64:     	b.ne	0x100001f8c <_perry_fn_access_worker_ts__run$spec_b_b+0x16cc>
100001f68:     	ldrb	w12, [x9, #0x8]
100001f6c:     	cmp	w12, #0x9
100001f70:     	b.hs	0x100001f8c <_perry_fn_access_worker_ts__run$spec_b_b+0x16cc>
100001f74:     	fcvtzs	x10, d8
100001f78:     	scvtf	d0, x10
100001f7c:     	ldr	w13, [x9]
100001f80:     	fcmp	d8, d0
100001f84:     	ccmp	x10, x13, #0x2, eq
100001f88:     	b.lo	0x100002044 <_perry_fn_access_worker_ts__run$spec_b_b+0x1784>
100001f8c:     	adrp	x10, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100001f90:     	add	x10, x10, #0x5b0
100001f94:     	ldr	x12, [x10]
100001f98:     	cmp	x12, #0x0
100001f9c:     	csel	x13, x10, x12, eq
100001fa0:     	cmp	x11, x20
100001fa4:     	b.ne	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100001fa8:     	fcmp	d8, #0.0
100001fac:     	b.lt	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100001fb0:     	fcmp	d8, d9
100001fb4:     	b.pl	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100001fb8:     	mov	x10, #-0x20000000000    ; =-2199023255552
100001fbc:     	add	x10, x9, x10
100001fc0:     	lsr	x10, x10, #41
100001fc4:     	cmp	x10, #0x3f
100001fc8:     	b.hs	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100001fcc:     	fcvtzs	x10, d8
100001fd0:     	scvtf	d0, x10
100001fd4:     	fcmp	d8, d0
100001fd8:     	b.ne	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100001fdc:     	ldursb	w11, [x9, #-0x7]
100001fe0:     	tbnz	w11, #0x1f, 0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100001fe4:     	ldurb	w11, [x9, #-0x8]
100001fe8:     	cmp	w11, #0x2
100001fec:     	b.eq	0x100002070 <_perry_fn_access_worker_ts__run$spec_b_b+0x17b0>
100001ff0:     	cmp	w11, #0x1
100001ff4:     	b.ne	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100001ff8:     	ldurh	w13, [x9, #-0x6]
100001ffc:     	adrp	x11, 0x10104d000 <_out_buf+0x39c8>
100002000:     	add	x11, x11, #0x820
100002004:     	ldrb	w12, [x11]
100002008:     	ldp	w11, w14, [x9]
10000200c:     	cmp	w11, w14
100002010:     	b.hi	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100002014:     	tbnz	w13, #0xa, 0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100002018:     	cbnz	w12, 0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
10000201c:     	cmp	x10, x11
100002020:     	b.hs	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100002024:     	add	x8, x9, x10, lsl #3
100002028:     	ldr	d0, [x8, #0x8]
10000202c:     	fmov	x8, d0
100002030:     	mov	x9, #0x10               ; =16
100002034:     	movk	x9, #0x7ffc, lsl #48
100002038:     	cmp	x8, x9
10000203c:     	fcsel	d0, d10, d0, eq
100002040:     	b	0x100002254 <_perry_fn_access_worker_ts__run$spec_b_b+0x1994>
100002044:     	add	x8, x9, #0x10
100002048:     	cmp	w12, #0x3
10000204c:     	b.le	0x1000020c0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1800>
100002050:     	cmp	w12, #0x5
100002054:     	b.gt	0x100002110 <_perry_fn_access_worker_ts__run$spec_b_b+0x1850>
100002058:     	cmp	w12, #0x4
10000205c:     	b.eq	0x10000215c <_perry_fn_access_worker_ts__run$spec_b_b+0x189c>
100002060:     	cmp	w12, #0x5
100002064:     	b.ne	0x100002150 <_perry_fn_access_worker_ts__run$spec_b_b+0x1890>
100002068:     	ldr	s0, [x8, x10, lsl #2]
10000206c:     	b	0x100002154 <_perry_fn_access_worker_ts__run$spec_b_b+0x1894>
100002070:     	ldr	x11, [x9, #0x8]
100002074:     	cbz	x11, 0x1000020dc <_perry_fn_access_worker_ts__run$spec_b_b+0x181c>
100002078:     	ldr	x14, [x11, #0x60]
10000207c:     	cbz	x14, 0x1000020dc <_perry_fn_access_worker_ts__run$spec_b_b+0x181c>
100002080:     	ldurb	w9, [x14, #-0x8]
100002084:     	cmp	w9, #0x1
100002088:     	b.ne	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
10000208c:     	ldursb	w9, [x14, #-0x7]
100002090:     	tbnz	w9, #0x1f, 0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100002094:     	ldr	w9, [x14]
100002098:     	cmp	x10, x9
10000209c:     	b.hs	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
1000020a0:     	add	x9, x14, x10, lsl #3
1000020a4:     	ldr	d0, [x9, #0x8]
1000020a8:     	fmov	x9, d0
1000020ac:     	mov	x10, #0x10              ; =16
1000020b0:     	movk	x10, #0x7ffc, lsl #48
1000020b4:     	cmp	x9, x10
1000020b8:     	b.ne	0x100002254 <_perry_fn_access_worker_ts__run$spec_b_b+0x1994>
1000020bc:     	b	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
1000020c0:     	cbz	w12, 0x100002148 <_perry_fn_access_worker_ts__run$spec_b_b+0x1888>
1000020c4:     	cmp	w12, #0x2
1000020c8:     	b.eq	0x100002170 <_perry_fn_access_worker_ts__run$spec_b_b+0x18b0>
1000020cc:     	cmp	w12, #0x3
1000020d0:     	b.ne	0x100002150 <_perry_fn_access_worker_ts__run$spec_b_b+0x1890>
1000020d4:     	ldr	h0, [x8, x10, lsl #1]
1000020d8:     	b	0x100002154 <_perry_fn_access_worker_ts__run$spec_b_b+0x1894>
1000020dc:     	ldr	x13, [x13]
1000020e0:     	cbz	x13, 0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
1000020e4:     	tbnz	x13, #0x3f, 0x10000217c <_perry_fn_access_worker_ts__run$spec_b_b+0x18bc>
1000020e8:     	ldp	w15, w14, [x9]
1000020ec:     	orr	x14, x14, x15, lsl #32
1000020f0:     	cmp	x14, x13
1000020f4:     	b.ne	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
1000020f8:     	ldp	x15, x13, [x12, #0x8]
1000020fc:     	ldp	x14, x12, [x12, #0x18]
100002100:     	cmp	x15, x12
100002104:     	b.lo	0x10000219c <_perry_fn_access_worker_ts__run$spec_b_b+0x18dc>
100002108:     	cbz	x11, 0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
10000210c:     	b	0x1000021a8 <_perry_fn_access_worker_ts__run$spec_b_b+0x18e8>
100002110:     	cmp	w12, #0x6
100002114:     	b.eq	0x100002164 <_perry_fn_access_worker_ts__run$spec_b_b+0x18a4>
100002118:     	cmp	w12, #0x7
10000211c:     	b.ne	0x100002150 <_perry_fn_access_worker_ts__run$spec_b_b+0x1890>
100002120:     	ldr	d0, [x8, x10, lsl #3]
100002124:     	b	0x100002254 <_perry_fn_access_worker_ts__run$spec_b_b+0x1994>
100002128:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
10000212c:     	ldr	x8, [x8, #0x688]
100002130:     	str	x24, [sp, #0x18]
100002134:     	and	x1, x8, #0xffffffffffff
100002138:     	adrp	x3, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
10000213c:     	add	x3, x3, #0x5a8
100002140:     	bl	0x100886300 <_js_object_get_field_ic_overflow_load>
100002144:     	b	0x100001ea0 <_perry_fn_access_worker_ts__run$spec_b_b+0x15e0>
100002148:     	ldrsb	w8, [x8, x10]
10000214c:     	b	0x100002174 <_perry_fn_access_worker_ts__run$spec_b_b+0x18b4>
100002150:     	ldr	b0, [x8, x10]
100002154:     	ucvtf	d0, d0
100002158:     	b	0x100002254 <_perry_fn_access_worker_ts__run$spec_b_b+0x1994>
10000215c:     	ldr	w8, [x8, x10, lsl #2]
100002160:     	b	0x100002174 <_perry_fn_access_worker_ts__run$spec_b_b+0x18b4>
100002164:     	ldr	s0, [x8, x10, lsl #2]
100002168:     	fcvt	d0, s0
10000216c:     	b	0x100002254 <_perry_fn_access_worker_ts__run$spec_b_b+0x1994>
100002170:     	ldrsh	w8, [x8, x10, lsl #1]
100002174:     	scvtf	d0, w8
100002178:     	b	0x100002254 <_perry_fn_access_worker_ts__run$spec_b_b+0x1994>
10000217c:     	cbz	x11, 0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100002180:     	ldr	x14, [x11, #0x30]
100002184:     	cmp	x14, x13
100002188:     	b.ne	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
10000218c:     	ldp	x15, x13, [x12, #0x8]
100002190:     	ldp	x14, x12, [x12, #0x18]
100002194:     	cmp	x15, x12
100002198:     	b.hs	0x1000021a8 <_perry_fn_access_worker_ts__run$spec_b_b+0x18e8>
10000219c:     	add	x15, x9, x15, lsl #3
1000021a0:     	add	x15, x15, #0x10
1000021a4:     	b	0x1000021cc <_perry_fn_access_worker_ts__run$spec_b_b+0x190c>
1000021a8:     	ldr	x17, [x11, #0x20]
1000021ac:     	cmp	x17, #0x0
1000021b0:     	csel	x16, x17, x11, ne
1000021b4:     	cbz	x17, 0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
1000021b8:     	ldr	w17, [x16]
1000021bc:     	cmp	x15, x17
1000021c0:     	b.hs	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
1000021c4:     	add	x15, x16, x15, lsl #3
1000021c8:     	add	x15, x15, #0x8
1000021cc:     	ldr	d0, [x15]
1000021d0:     	fcmp	d8, d0
1000021d4:     	ccmp	x14, x10, #0x0, mi
1000021d8:     	cset	w14, hi
1000021dc:     	add	x10, x13, x10
1000021e0:     	cmp	x10, x12
1000021e4:     	b.hs	0x1000021f8 <_perry_fn_access_worker_ts__run$spec_b_b+0x1938>
1000021e8:     	cbz	w14, 0x1000021f8 <_perry_fn_access_worker_ts__run$spec_b_b+0x1938>
1000021ec:     	add	x8, x9, x10, lsl #3
1000021f0:     	ldr	d0, [x8, #0x10]
1000021f4:     	b	0x100002254 <_perry_fn_access_worker_ts__run$spec_b_b+0x1994>
1000021f8:     	cbz	x11, 0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
1000021fc:     	cmp	x10, x12
100002200:     	b.lo	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100002204:     	eor	w9, w14, #0x1
100002208:     	tbnz	w9, #0x0, 0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
10000220c:     	ldr	x12, [x11, #0x20]
100002210:     	cmp	x12, #0x0
100002214:     	csel	x9, x12, x11, ne
100002218:     	cbz	x12, 0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
10000221c:     	ldr	w11, [x9]
100002220:     	cmp	x10, x11
100002224:     	b.hs	0x100002234 <_perry_fn_access_worker_ts__run$spec_b_b+0x1974>
100002228:     	add	x8, x9, x10, lsl #3
10000222c:     	ldr	d0, [x8, #0x8]
100002230:     	b	0x100002254 <_perry_fn_access_worker_ts__run$spec_b_b+0x1994>
100002234:     	fmov	d0, x8
100002238:     	str	x24, [sp, #0x18]
10000223c:     	mov.16b	v1, v8
100002240:     	adrp	x0, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002244:     	add	x0, x0, #0x5b0
100002248:     	bl	0x10089c260 <_js_packed_arraylike_index_get>
10000224c:     	ldp	x25, x23, [sp, #0x8]
100002250:     	ldr	x24, [sp, #0x18]
100002254:     	fmov	x8, d0
100002258:     	mov	x9, #-0x3000000000000   ; =-844424930131968
10000225c:     	and	x9, x8, x9
100002260:     	cmp	x9, x20
100002264:     	b.ne	0x1000022d4 <_perry_fn_access_worker_ts__run$spec_b_b+0x1a14>
100002268:     	and	x0, x8, #0xffffffffffff
10000226c:     	lsr	x8, x0, #20
100002270:     	cbz	x8, 0x100002420 <_perry_fn_access_worker_ts__run$spec_b_b+0x1b60>
100002274:     	ldurb	w9, [x0, #-0x8]
100002278:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
10000227c:     	ldr	x8, [x8, #0x5b8]
100002280:     	cbz	x8, 0x100002344 <_perry_fn_access_worker_ts__run$spec_b_b+0x1a84>
100002284:     	cmp	w9, #0x2
100002288:     	b.ne	0x100002344 <_perry_fn_access_worker_ts__run$spec_b_b+0x1a84>
10000228c:     	ldurh	w10, [x0, #-0x6]
100002290:     	tbnz	w10, #0xb, 0x100002344 <_perry_fn_access_worker_ts__run$spec_b_b+0x1a84>
100002294:     	ldr	w10, [x0, #0x4]
100002298:     	orr	x9, x10, #0x4000000000000000
10000229c:     	cbz	w10, 0x100002370 <_perry_fn_access_worker_ts__run$spec_b_b+0x1ab0>
1000022a0:     	ldr	x11, [x8]
1000022a4:     	cmp	x9, x11
1000022a8:     	b.ne	0x100002370 <_perry_fn_access_worker_ts__run$spec_b_b+0x1ab0>
1000022ac:     	ldr	x2, [x8, #0x8]
1000022b0:     	tbnz	w2, #0x1e, 0x100002730 <_perry_fn_access_worker_ts__run$spec_b_b+0x1e70>
1000022b4:     	add	x11, x0, x2, lsl #3
1000022b8:     	ldr	d0, [x11, #0x10]
1000022bc:     	fmov	x11, d0
1000022c0:     	mov	x12, #0x10              ; =16
1000022c4:     	movk	x12, #0x7ffc, lsl #48
1000022c8:     	cmp	x11, x12
1000022cc:     	b.ne	0x100002444 <_perry_fn_access_worker_ts__run$spec_b_b+0x1b84>
1000022d0:     	b	0x10000239c <_perry_fn_access_worker_ts__run$spec_b_b+0x1adc>
1000022d4:     	lsr	x9, x8, #48
1000022d8:     	mov	w10, #0x7ff9            ; =32761
1000022dc:     	cmp	x9, x10
1000022e0:     	b.eq	0x100002328 <_perry_fn_access_worker_ts__run$spec_b_b+0x1a68>
1000022e4:     	mov	w10, #0x7ffe            ; =32766
1000022e8:     	cmp	w9, w10
1000022ec:     	b.ne	0x100002318 <_perry_fn_access_worker_ts__run$spec_b_b+0x1a58>
1000022f0:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1000022f4:     	ldr	x9, [x9, #0x6a0]
1000022f8:     	str	x24, [sp, #0x18]
1000022fc:     	and	x2, x9, #0xffffffffffff
100002300:     	mov	x0, #0xa                ; =10
100002304:     	movk	x0, #0xddae, lsl #32
100002308:     	movk	x0, #0x5556, lsl #48
10000230c:     	mov	x1, x8
100002310:     	bl	0x100903ec0 <_js_typed_feedback_object_get_field_by_name_f64>
100002314:     	b	0x10000243c <_perry_fn_access_worker_ts__run$spec_b_b+0x1b7c>
100002318:     	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
10000231c:     	add	x9, x8, x9
100002320:     	cmp	x9, #0x2
100002324:     	b.lo	0x100003278 <_perry_fn_access_worker_ts__run$spec_b_b+0x29b8>
100002328:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
10000232c:     	ldr	x9, [x9, #0x6a0]
100002330:     	str	x24, [sp, #0x18]
100002334:     	and	x1, x9, #0xffffffffffff
100002338:     	mov	x0, x8
10000233c:     	bl	0x100885498 <_js_object_get_field_by_name_f64>
100002340:     	b	0x10000243c <_perry_fn_access_worker_ts__run$spec_b_b+0x1b7c>
100002344:     	cmp	w9, #0x2
100002348:     	b.ne	0x100002420 <_perry_fn_access_worker_ts__run$spec_b_b+0x1b60>
10000234c:     	cbz	x8, 0x100002420 <_perry_fn_access_worker_ts__run$spec_b_b+0x1b60>
100002350:     	ldr	x9, [x8, #0x10]
100002354:     	cbz	x9, 0x100002420 <_perry_fn_access_worker_ts__run$spec_b_b+0x1b60>
100002358:     	ldr	x10, [x0, #0x8]
10000235c:     	cbz	x10, 0x100002420 <_perry_fn_access_worker_ts__run$spec_b_b+0x1b60>
100002360:     	ldr	x10, [x10, #0x30]
100002364:     	cmp	x10, x9
100002368:     	b.eq	0x10000238c <_perry_fn_access_worker_ts__run$spec_b_b+0x1acc>
10000236c:     	b	0x100002420 <_perry_fn_access_worker_ts__run$spec_b_b+0x1b60>
100002370:     	ldr	x11, [x8, #0x10]
100002374:     	cbz	x11, 0x10000239c <_perry_fn_access_worker_ts__run$spec_b_b+0x1adc>
100002378:     	ldr	x12, [x0, #0x8]
10000237c:     	cbz	x12, 0x10000239c <_perry_fn_access_worker_ts__run$spec_b_b+0x1adc>
100002380:     	ldr	x12, [x12, #0x30]
100002384:     	cmp	x12, x11
100002388:     	b.ne	0x10000239c <_perry_fn_access_worker_ts__run$spec_b_b+0x1adc>
10000238c:     	ldr	x8, [x8, #0x8]
100002390:     	add	x8, x0, x8, lsl #3
100002394:     	ldr	d0, [x8, #0x10]
100002398:     	b	0x100002444 <_perry_fn_access_worker_ts__run$spec_b_b+0x1b84>
10000239c:     	ldr	x11, [x8, #0x18]
1000023a0:     	cmp	x11, #0x0
1000023a4:     	b.le	0x100002420 <_perry_fn_access_worker_ts__run$spec_b_b+0x1b60>
1000023a8:     	ldr	x11, [x8, #0x20]
1000023ac:     	ldr	x12, [x8, #0x30]
1000023b0:     	ldr	x13, [x8, #0x40]
1000023b4:     	cmp	x13, x9
1000023b8:     	ldr	x14, [x8, #0x50]
1000023bc:     	ccmp	x14, x9, #0x4, ne
1000023c0:     	ccmp	x12, x9, #0x4, ne
1000023c4:     	ccmp	x11, x9, #0x4, ne
1000023c8:     	cset	w15, eq
1000023cc:     	cbz	w10, 0x100002420 <_perry_fn_access_worker_ts__run$spec_b_b+0x1b60>
1000023d0:     	cbz	w15, 0x100002420 <_perry_fn_access_worker_ts__run$spec_b_b+0x1b60>
1000023d4:     	ldr	x10, [x8, #0x48]
1000023d8:     	ldr	x15, [x8, #0x58]
1000023dc:     	cmp	x14, x9
1000023e0:     	csel	x14, x15, xzr, eq
1000023e4:     	cmp	x13, x9
1000023e8:     	csel	x10, x10, x14, eq
1000023ec:     	ldr	x13, [x8, #0x28]
1000023f0:     	ldr	x8, [x8, #0x38]
1000023f4:     	cmp	x12, x9
1000023f8:     	csel	x8, x8, x10, eq
1000023fc:     	cmp	x11, x9
100002400:     	csel	x8, x13, x8, eq
100002404:     	add	x8, x0, x8, lsl #3
100002408:     	ldr	d0, [x8, #0x10]
10000240c:     	fmov	x8, d0
100002410:     	mov	x9, #0x10               ; =16
100002414:     	movk	x9, #0x7ffc, lsl #48
100002418:     	cmp	x8, x9
10000241c:     	b.ne	0x100002444 <_perry_fn_access_worker_ts__run$spec_b_b+0x1b84>
100002420:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002424:     	ldr	x8, [x8, #0x6a0]
100002428:     	str	x24, [sp, #0x18]
10000242c:     	and	x1, x8, #0xffffffffffff
100002430:     	adrp	x2, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002434:     	add	x2, x2, #0x5b8
100002438:     	bl	0x100885980 <_js_object_get_field_ic_miss>
10000243c:     	ldp	x25, x23, [sp, #0x8]
100002440:     	ldr	x24, [sp, #0x18]
100002444:     	fmov	x8, d0
100002448:     	lsr	x9, x8, #48
10000244c:     	mov	w10, #0x7ff9            ; =32761
100002450:     	cmp	x9, x10
100002454:     	b.eq	0x100002484 <_perry_fn_access_worker_ts__run$spec_b_b+0x1bc4>
100002458:     	mov	w10, #0x7fff            ; =32767
10000245c:     	cmp	w9, w10
100002460:     	b.ne	0x100002490 <_perry_fn_access_worker_ts__run$spec_b_b+0x1bd0>
100002464:     	and	x9, x8, #0xffffffffffff
100002468:     	tst	x8, #0xfffffffff000
10000246c:     	adrp	x8, 0x100b60000 <__mi_theap_area_visit_blocks.cold.1+0x44>
100002470:     	add	x8, x8, #0xf70
100002474:     	csel	x8, x8, x9, eq
100002478:     	ldr	s0, [x8]
10000247c:     	ucvtf	d1, d0
100002480:     	b	0x1000024a4 <_perry_fn_access_worker_ts__run$spec_b_b+0x1be4>
100002484:     	ubfx	x8, x8, #40, #8
100002488:     	ucvtf	d1, x8
10000248c:     	b	0x1000024a4 <_perry_fn_access_worker_ts__run$spec_b_b+0x1be4>
100002490:     	str	x24, [sp, #0x18]
100002494:     	bl	0x10092058c <_js_value_length_property_f64>
100002498:     	mov.16b	v1, v0
10000249c:     	ldp	x25, x23, [sp, #0x8]
1000024a0:     	ldr	x24, [sp, #0x18]
1000024a4:     	fmov	d0, x24
1000024a8:     	and	x9, x24, #0xffff000000000000
1000024ac:     	fmov	x8, d1
1000024b0:     	and	x10, x8, #0xffff000000000000
1000024b4:     	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
1000024b8:     	cmp	x8, x11
1000024bc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1000024c0:     	ccmp	x10, x8, #0x2, hs
1000024c4:     	cset	w8, hi
1000024c8:     	mov	x10, #0x1               ; =1
1000024cc:     	movk	x10, #0x7fff, lsl #48
1000024d0:     	cmp	x9, x10
1000024d4:     	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
1000024d8:     	ccmp	x24, x9, #0x0, lo
1000024dc:     	b.hi	0x1000024ec <_perry_fn_access_worker_ts__run$spec_b_b+0x1c2c>
1000024e0:     	cbz	w8, 0x1000024ec <_perry_fn_access_worker_ts__run$spec_b_b+0x1c2c>
1000024e4:     	fadd	d0, d1, d0
1000024e8:     	b	0x1000024f8 <_perry_fn_access_worker_ts__run$spec_b_b+0x1c38>
1000024ec:     	stp	x23, x25, [sp, #0x10]
1000024f0:     	bl	0x10081f2e4 <_js_dynamic_string_or_number_add>
1000024f4:     	ldp	x23, x25, [sp, #0x10]
1000024f8:     	fmov	x24, d0
1000024fc:     	mov	x0, x24
100002500:     	ldr	w8, [x27]
100002504:     	cbz	w8, 0x10000250c <_perry_fn_access_worker_ts__run$spec_b_b+0x1c4c>
100002508:     	bl	0x10092b40c <_js_write_barrier_root_nanbox>
10000250c:     	mov	x0, x24
100002510:     	ldr	w8, [x27]
100002514:     	cbz	w8, 0x10000251c <_perry_fn_access_worker_ts__run$spec_b_b+0x1c5c>
100002518:     	bl	0x10092b40c <_js_write_barrier_root_nanbox>
10000251c:     	mov	x8, x25
100002520:     	and	x9, x8, #0xffffffffffff
100002524:     	and	x11, x8, #0xffff000000000000
100002528:     	cmp	x11, x20
10000252c:     	b.ne	0x1000025c0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1d00>
100002530:     	ldr	x10, [x19]
100002534:     	cbnz	x10, 0x1000025c0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1d00>
100002538:     	sub	x10, x9, #0x100, lsl #12 ; =0x100000
10000253c:     	mov	x12, #0x7ffffff00000    ; =140737487306752
100002540:     	cmp	x10, x12
100002544:     	b.hs	0x1000025c0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1d00>
100002548:     	mov	x10, #0x41f0000000000000 ; =4751297606875873280
10000254c:     	fmov	d0, x10
100002550:     	fcmp	d8, d0
100002554:     	b.pl	0x1000025c0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1d00>
100002558:     	fcmp	d8, #0.0
10000255c:     	b.lt	0x1000025c0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1d00>
100002560:     	ldurb	w10, [x9, #-0x8]
100002564:     	cmp	w10, #0xb
100002568:     	b.ne	0x1000025c0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1d00>
10000256c:     	ldrb	w12, [x9, #0x8]
100002570:     	cmp	w12, #0x9
100002574:     	b.hs	0x1000025c0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1d00>
100002578:     	fcvtzs	x10, d8
10000257c:     	scvtf	d0, x10
100002580:     	fcmp	d8, d0
100002584:     	b.ne	0x1000025c0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1d00>
100002588:     	ldr	w13, [x9]
10000258c:     	cmp	x10, x13
100002590:     	b.hs	0x1000025c0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1d00>
100002594:     	add	x8, x9, #0x10
100002598:     	cmp	w12, #0x3
10000259c:     	b.le	0x1000026c8 <_perry_fn_access_worker_ts__run$spec_b_b+0x1e08>
1000025a0:     	cmp	w12, #0x5
1000025a4:     	b.gt	0x100002718 <_perry_fn_access_worker_ts__run$spec_b_b+0x1e58>
1000025a8:     	cmp	w12, #0x4
1000025ac:     	b.eq	0x100002764 <_perry_fn_access_worker_ts__run$spec_b_b+0x1ea4>
1000025b0:     	cmp	w12, #0x5
1000025b4:     	b.ne	0x100002758 <_perry_fn_access_worker_ts__run$spec_b_b+0x1e98>
1000025b8:     	ldr	s0, [x8, x10, lsl #2]
1000025bc:     	b	0x10000275c <_perry_fn_access_worker_ts__run$spec_b_b+0x1e9c>
1000025c0:     	adrp	x10, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1000025c4:     	add	x10, x10, #0x5c0
1000025c8:     	ldr	x12, [x10]
1000025cc:     	cmp	x12, #0x0
1000025d0:     	csel	x13, x10, x12, eq
1000025d4:     	cmp	x11, x20
1000025d8:     	b.ne	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
1000025dc:     	fcmp	d8, #0.0
1000025e0:     	b.lt	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
1000025e4:     	fcmp	d8, d9
1000025e8:     	b.pl	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
1000025ec:     	mov	x10, #-0x20000000000    ; =-2199023255552
1000025f0:     	add	x10, x9, x10
1000025f4:     	lsr	x10, x10, #41
1000025f8:     	cmp	x10, #0x3f
1000025fc:     	b.hs	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002600:     	fcvtzs	x10, d8
100002604:     	scvtf	d0, x10
100002608:     	fcmp	d8, d0
10000260c:     	b.ne	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002610:     	ldursb	w11, [x9, #-0x7]
100002614:     	tbnz	w11, #0x1f, 0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002618:     	ldurb	w11, [x9, #-0x8]
10000261c:     	cmp	w11, #0x2
100002620:     	b.eq	0x100002678 <_perry_fn_access_worker_ts__run$spec_b_b+0x1db8>
100002624:     	cmp	w11, #0x1
100002628:     	b.ne	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
10000262c:     	ldurh	w13, [x9, #-0x6]
100002630:     	adrp	x11, 0x10104d000 <_out_buf+0x39c8>
100002634:     	add	x11, x11, #0x820
100002638:     	ldrb	w12, [x11]
10000263c:     	ldp	w11, w14, [x9]
100002640:     	cmp	w11, w14
100002644:     	b.hi	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002648:     	tbnz	w13, #0xa, 0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
10000264c:     	cbnz	w12, 0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002650:     	cmp	x10, x11
100002654:     	b.hs	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002658:     	add	x8, x9, x10, lsl #3
10000265c:     	ldr	d0, [x8, #0x8]
100002660:     	fmov	x8, d0
100002664:     	mov	x9, #0x10               ; =16
100002668:     	movk	x9, #0x7ffc, lsl #48
10000266c:     	cmp	x8, x9
100002670:     	fcsel	d0, d10, d0, eq
100002674:     	b	0x100002860 <_perry_fn_access_worker_ts__run$spec_b_b+0x1fa0>
100002678:     	ldr	x11, [x9, #0x8]
10000267c:     	cbz	x11, 0x1000026e4 <_perry_fn_access_worker_ts__run$spec_b_b+0x1e24>
100002680:     	ldr	x14, [x11, #0x60]
100002684:     	cbz	x14, 0x1000026e4 <_perry_fn_access_worker_ts__run$spec_b_b+0x1e24>
100002688:     	ldurb	w9, [x14, #-0x8]
10000268c:     	cmp	w9, #0x1
100002690:     	b.ne	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002694:     	ldursb	w9, [x14, #-0x7]
100002698:     	tbnz	w9, #0x1f, 0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
10000269c:     	ldr	w9, [x14]
1000026a0:     	cmp	x10, x9
1000026a4:     	b.hs	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
1000026a8:     	add	x9, x14, x10, lsl #3
1000026ac:     	ldr	d0, [x9, #0x8]
1000026b0:     	fmov	x9, d0
1000026b4:     	mov	x10, #0x10              ; =16
1000026b8:     	movk	x10, #0x7ffc, lsl #48
1000026bc:     	cmp	x9, x10
1000026c0:     	b.ne	0x100002860 <_perry_fn_access_worker_ts__run$spec_b_b+0x1fa0>
1000026c4:     	b	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
1000026c8:     	cbz	w12, 0x100002750 <_perry_fn_access_worker_ts__run$spec_b_b+0x1e90>
1000026cc:     	cmp	w12, #0x2
1000026d0:     	b.eq	0x100002778 <_perry_fn_access_worker_ts__run$spec_b_b+0x1eb8>
1000026d4:     	cmp	w12, #0x3
1000026d8:     	b.ne	0x100002758 <_perry_fn_access_worker_ts__run$spec_b_b+0x1e98>
1000026dc:     	ldr	h0, [x8, x10, lsl #1]
1000026e0:     	b	0x10000275c <_perry_fn_access_worker_ts__run$spec_b_b+0x1e9c>
1000026e4:     	ldr	x13, [x13]
1000026e8:     	cbz	x13, 0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
1000026ec:     	tbnz	x13, #0x3f, 0x100002784 <_perry_fn_access_worker_ts__run$spec_b_b+0x1ec4>
1000026f0:     	ldp	w15, w14, [x9]
1000026f4:     	orr	x14, x14, x15, lsl #32
1000026f8:     	cmp	x14, x13
1000026fc:     	b.ne	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002700:     	ldp	x15, x13, [x12, #0x8]
100002704:     	ldp	x14, x12, [x12, #0x18]
100002708:     	cmp	x15, x12
10000270c:     	b.lo	0x1000027a4 <_perry_fn_access_worker_ts__run$spec_b_b+0x1ee4>
100002710:     	cbz	x11, 0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002714:     	b	0x1000027b0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1ef0>
100002718:     	cmp	w12, #0x6
10000271c:     	b.eq	0x10000276c <_perry_fn_access_worker_ts__run$spec_b_b+0x1eac>
100002720:     	cmp	w12, #0x7
100002724:     	b.ne	0x100002758 <_perry_fn_access_worker_ts__run$spec_b_b+0x1e98>
100002728:     	ldr	d0, [x8, x10, lsl #3]
10000272c:     	b	0x100002860 <_perry_fn_access_worker_ts__run$spec_b_b+0x1fa0>
100002730:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002734:     	ldr	x8, [x8, #0x6a0]
100002738:     	str	x24, [sp, #0x18]
10000273c:     	and	x1, x8, #0xffffffffffff
100002740:     	adrp	x3, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002744:     	add	x3, x3, #0x5b8
100002748:     	bl	0x100886300 <_js_object_get_field_ic_overflow_load>
10000274c:     	b	0x10000243c <_perry_fn_access_worker_ts__run$spec_b_b+0x1b7c>
100002750:     	ldrsb	w8, [x8, x10]
100002754:     	b	0x10000277c <_perry_fn_access_worker_ts__run$spec_b_b+0x1ebc>
100002758:     	ldr	b0, [x8, x10]
10000275c:     	ucvtf	d0, d0
100002760:     	b	0x100002860 <_perry_fn_access_worker_ts__run$spec_b_b+0x1fa0>
100002764:     	ldr	w8, [x8, x10, lsl #2]
100002768:     	b	0x10000277c <_perry_fn_access_worker_ts__run$spec_b_b+0x1ebc>
10000276c:     	ldr	s0, [x8, x10, lsl #2]
100002770:     	fcvt	d0, s0
100002774:     	b	0x100002860 <_perry_fn_access_worker_ts__run$spec_b_b+0x1fa0>
100002778:     	ldrsh	w8, [x8, x10, lsl #1]
10000277c:     	scvtf	d0, w8
100002780:     	b	0x100002860 <_perry_fn_access_worker_ts__run$spec_b_b+0x1fa0>
100002784:     	cbz	x11, 0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002788:     	ldr	x14, [x11, #0x30]
10000278c:     	cmp	x14, x13
100002790:     	b.ne	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002794:     	ldp	x15, x13, [x12, #0x8]
100002798:     	ldp	x14, x12, [x12, #0x18]
10000279c:     	cmp	x15, x12
1000027a0:     	b.hs	0x1000027b0 <_perry_fn_access_worker_ts__run$spec_b_b+0x1ef0>
1000027a4:     	add	x15, x9, x15, lsl #3
1000027a8:     	add	x15, x15, #0x10
1000027ac:     	b	0x1000027d4 <_perry_fn_access_worker_ts__run$spec_b_b+0x1f14>
1000027b0:     	ldr	x17, [x11, #0x20]
1000027b4:     	cmp	x17, #0x0
1000027b8:     	csel	x16, x17, x11, ne
1000027bc:     	cbz	x17, 0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
1000027c0:     	ldr	w17, [x16]
1000027c4:     	cmp	x15, x17
1000027c8:     	b.hs	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
1000027cc:     	add	x15, x16, x15, lsl #3
1000027d0:     	add	x15, x15, #0x8
1000027d4:     	ldr	d0, [x15]
1000027d8:     	fcmp	d8, d0
1000027dc:     	ccmp	x14, x10, #0x0, mi
1000027e0:     	cset	w14, hi
1000027e4:     	add	x10, x13, x10
1000027e8:     	cmp	x10, x12
1000027ec:     	b.hs	0x100002800 <_perry_fn_access_worker_ts__run$spec_b_b+0x1f40>
1000027f0:     	cbz	w14, 0x100002800 <_perry_fn_access_worker_ts__run$spec_b_b+0x1f40>
1000027f4:     	add	x8, x9, x10, lsl #3
1000027f8:     	ldr	d0, [x8, #0x10]
1000027fc:     	b	0x100002860 <_perry_fn_access_worker_ts__run$spec_b_b+0x1fa0>
100002800:     	cbz	x11, 0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002804:     	cmp	x10, x12
100002808:     	b.lo	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
10000280c:     	eor	w9, w14, #0x1
100002810:     	tbnz	w9, #0x0, 0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002814:     	ldr	x12, [x11, #0x20]
100002818:     	cmp	x12, #0x0
10000281c:     	csel	x9, x12, x11, ne
100002820:     	cbz	x12, 0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002824:     	ldr	w11, [x9]
100002828:     	cmp	x10, x11
10000282c:     	b.hs	0x10000283c <_perry_fn_access_worker_ts__run$spec_b_b+0x1f7c>
100002830:     	add	x8, x9, x10, lsl #3
100002834:     	ldr	d0, [x8, #0x8]
100002838:     	b	0x100002860 <_perry_fn_access_worker_ts__run$spec_b_b+0x1fa0>
10000283c:     	fmov	d0, x8
100002840:     	stp	x25, x24, [sp, #0x10]
100002844:     	str	x23, [sp, #0x8]
100002848:     	mov.16b	v1, v8
10000284c:     	adrp	x0, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002850:     	add	x0, x0, #0x5c0
100002854:     	bl	0x10089c260 <_js_packed_arraylike_index_get>
100002858:     	ldp	x23, x25, [sp, #0x8]
10000285c:     	ldr	x24, [sp, #0x18]
100002860:     	fmov	x8, d0
100002864:     	mov	x9, #-0x3000000000000   ; =-844424930131968
100002868:     	and	x9, x8, x9
10000286c:     	cmp	x9, x20
100002870:     	b.ne	0x1000028e0 <_perry_fn_access_worker_ts__run$spec_b_b+0x2020>
100002874:     	and	x0, x8, #0xffffffffffff
100002878:     	lsr	x8, x0, #20
10000287c:     	cbz	x8, 0x100002a34 <_perry_fn_access_worker_ts__run$spec_b_b+0x2174>
100002880:     	ldurb	w9, [x0, #-0x8]
100002884:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002888:     	ldr	x8, [x8, #0x5c8]
10000288c:     	cbz	x8, 0x100002958 <_perry_fn_access_worker_ts__run$spec_b_b+0x2098>
100002890:     	cmp	w9, #0x2
100002894:     	b.ne	0x100002958 <_perry_fn_access_worker_ts__run$spec_b_b+0x2098>
100002898:     	ldurh	w10, [x0, #-0x6]
10000289c:     	tbnz	w10, #0xb, 0x100002958 <_perry_fn_access_worker_ts__run$spec_b_b+0x2098>
1000028a0:     	ldr	w10, [x0, #0x4]
1000028a4:     	orr	x9, x10, #0x4000000000000000
1000028a8:     	cbz	w10, 0x100002984 <_perry_fn_access_worker_ts__run$spec_b_b+0x20c4>
1000028ac:     	ldr	x11, [x8]
1000028b0:     	cmp	x9, x11
1000028b4:     	b.ne	0x100002984 <_perry_fn_access_worker_ts__run$spec_b_b+0x20c4>
1000028b8:     	ldr	x2, [x8, #0x8]
1000028bc:     	tbnz	w2, #0x1e, 0x100002b5c <_perry_fn_access_worker_ts__run$spec_b_b+0x229c>
1000028c0:     	add	x11, x0, x2, lsl #3
1000028c4:     	ldr	d0, [x11, #0x10]
1000028c8:     	fmov	x11, d0
1000028cc:     	mov	x12, #0x10              ; =16
1000028d0:     	movk	x12, #0x7ffc, lsl #48
1000028d4:     	cmp	x11, x12
1000028d8:     	b.ne	0x100002a5c <_perry_fn_access_worker_ts__run$spec_b_b+0x219c>
1000028dc:     	b	0x1000029b0 <_perry_fn_access_worker_ts__run$spec_b_b+0x20f0>
1000028e0:     	lsr	x9, x8, #48
1000028e4:     	mov	w10, #0x7ff9            ; =32761
1000028e8:     	cmp	x9, x10
1000028ec:     	b.eq	0x100002938 <_perry_fn_access_worker_ts__run$spec_b_b+0x2078>
1000028f0:     	mov	w10, #0x7ffe            ; =32766
1000028f4:     	cmp	w9, w10
1000028f8:     	b.ne	0x100002928 <_perry_fn_access_worker_ts__run$spec_b_b+0x2068>
1000028fc:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002900:     	ldr	x9, [x9, #0x6a8]
100002904:     	stp	x25, x24, [sp, #0x10]
100002908:     	str	x23, [sp, #0x8]
10000290c:     	and	x2, x9, #0xffffffffffff
100002910:     	mov	x0, #0xd                ; =13
100002914:     	movk	x0, #0xddae, lsl #32
100002918:     	movk	x0, #0x5556, lsl #48
10000291c:     	mov	x1, x8
100002920:     	bl	0x100903ec0 <_js_typed_feedback_object_get_field_by_name_f64>
100002924:     	b	0x100002a54 <_perry_fn_access_worker_ts__run$spec_b_b+0x2194>
100002928:     	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
10000292c:     	add	x9, x8, x9
100002930:     	cmp	x9, #0x2
100002934:     	b.lo	0x10000329c <_perry_fn_access_worker_ts__run$spec_b_b+0x29dc>
100002938:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
10000293c:     	ldr	x9, [x9, #0x6a8]
100002940:     	stp	x25, x24, [sp, #0x10]
100002944:     	str	x23, [sp, #0x8]
100002948:     	and	x1, x9, #0xffffffffffff
10000294c:     	mov	x0, x8
100002950:     	bl	0x100885498 <_js_object_get_field_by_name_f64>
100002954:     	b	0x100002a54 <_perry_fn_access_worker_ts__run$spec_b_b+0x2194>
100002958:     	cmp	w9, #0x2
10000295c:     	b.ne	0x100002a34 <_perry_fn_access_worker_ts__run$spec_b_b+0x2174>
100002960:     	cbz	x8, 0x100002a34 <_perry_fn_access_worker_ts__run$spec_b_b+0x2174>
100002964:     	ldr	x9, [x8, #0x10]
100002968:     	cbz	x9, 0x100002a34 <_perry_fn_access_worker_ts__run$spec_b_b+0x2174>
10000296c:     	ldr	x10, [x0, #0x8]
100002970:     	cbz	x10, 0x100002a34 <_perry_fn_access_worker_ts__run$spec_b_b+0x2174>
100002974:     	ldr	x10, [x10, #0x30]
100002978:     	cmp	x10, x9
10000297c:     	b.eq	0x1000029a0 <_perry_fn_access_worker_ts__run$spec_b_b+0x20e0>
100002980:     	b	0x100002a34 <_perry_fn_access_worker_ts__run$spec_b_b+0x2174>
100002984:     	ldr	x11, [x8, #0x10]
100002988:     	cbz	x11, 0x1000029b0 <_perry_fn_access_worker_ts__run$spec_b_b+0x20f0>
10000298c:     	ldr	x12, [x0, #0x8]
100002990:     	cbz	x12, 0x1000029b0 <_perry_fn_access_worker_ts__run$spec_b_b+0x20f0>
100002994:     	ldr	x12, [x12, #0x30]
100002998:     	cmp	x12, x11
10000299c:     	b.ne	0x1000029b0 <_perry_fn_access_worker_ts__run$spec_b_b+0x20f0>
1000029a0:     	ldr	x8, [x8, #0x8]
1000029a4:     	add	x8, x0, x8, lsl #3
1000029a8:     	ldr	d0, [x8, #0x10]
1000029ac:     	b	0x100002a5c <_perry_fn_access_worker_ts__run$spec_b_b+0x219c>
1000029b0:     	ldr	x11, [x8, #0x18]
1000029b4:     	cmp	x11, #0x0
1000029b8:     	b.le	0x100002a34 <_perry_fn_access_worker_ts__run$spec_b_b+0x2174>
1000029bc:     	ldr	x11, [x8, #0x20]
1000029c0:     	ldr	x12, [x8, #0x30]
1000029c4:     	ldr	x13, [x8, #0x40]
1000029c8:     	cmp	x13, x9
1000029cc:     	ldr	x14, [x8, #0x50]
1000029d0:     	ccmp	x14, x9, #0x4, ne
1000029d4:     	ccmp	x12, x9, #0x4, ne
1000029d8:     	ccmp	x11, x9, #0x4, ne
1000029dc:     	cset	w15, eq
1000029e0:     	cbz	w10, 0x100002a34 <_perry_fn_access_worker_ts__run$spec_b_b+0x2174>
1000029e4:     	cbz	w15, 0x100002a34 <_perry_fn_access_worker_ts__run$spec_b_b+0x2174>
1000029e8:     	ldr	x10, [x8, #0x48]
1000029ec:     	ldr	x15, [x8, #0x58]
1000029f0:     	cmp	x14, x9
1000029f4:     	csel	x14, x15, xzr, eq
1000029f8:     	cmp	x13, x9
1000029fc:     	csel	x10, x10, x14, eq
100002a00:     	ldr	x13, [x8, #0x28]
100002a04:     	ldr	x8, [x8, #0x38]
100002a08:     	cmp	x12, x9
100002a0c:     	csel	x8, x8, x10, eq
100002a10:     	cmp	x11, x9
100002a14:     	csel	x8, x13, x8, eq
100002a18:     	add	x8, x0, x8, lsl #3
100002a1c:     	ldr	d0, [x8, #0x10]
100002a20:     	fmov	x8, d0
100002a24:     	mov	x9, #0x10               ; =16
100002a28:     	movk	x9, #0x7ffc, lsl #48
100002a2c:     	cmp	x8, x9
100002a30:     	b.ne	0x100002a5c <_perry_fn_access_worker_ts__run$spec_b_b+0x219c>
100002a34:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002a38:     	ldr	x8, [x8, #0x6a8]
100002a3c:     	stp	x25, x24, [sp, #0x10]
100002a40:     	str	x23, [sp, #0x8]
100002a44:     	and	x1, x8, #0xffffffffffff
100002a48:     	adrp	x2, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002a4c:     	add	x2, x2, #0x5c8
100002a50:     	bl	0x100885980 <_js_object_get_field_ic_miss>
100002a54:     	ldp	x23, x25, [sp, #0x8]
100002a58:     	ldr	x24, [sp, #0x18]
100002a5c:     	fmov	x8, d0
100002a60:     	mov	x9, #0x7ff8000000000000 ; =9221120237041090560
100002a64:     	bics	xzr, x9, x8
100002a68:     	b.ne	0x100002a98 <_perry_fn_access_worker_ts__run$spec_b_b+0x21d8>
100002a6c:     	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
100002a70:     	add	x9, x8, x9
100002a74:     	cmp	x9, #0x4
100002a78:     	b.hs	0x100002aac <_perry_fn_access_worker_ts__run$spec_b_b+0x21ec>
100002a7c:     	mov	x9, #0x10               ; =16
100002a80:     	movk	x9, #0x7ffc, lsl #48
100002a84:     	sub	x9, x9, #0xc
100002a88:     	movi.2d	v1, #0000000000000000
100002a8c:     	cmp	x8, x9
100002a90:     	b.eq	0x100002ac8 <_perry_fn_access_worker_ts__run$spec_b_b+0x2208>
100002a94:     	b	0x100002acc <_perry_fn_access_worker_ts__run$spec_b_b+0x220c>
100002a98:     	movi.2d	v1, #0000000000000000
100002a9c:     	fcmp	d0, #0.0
100002aa0:     	b.eq	0x100002acc <_perry_fn_access_worker_ts__run$spec_b_b+0x220c>
100002aa4:     	b.vs	0x100002acc <_perry_fn_access_worker_ts__run$spec_b_b+0x220c>
100002aa8:     	b	0x100002ac8 <_perry_fn_access_worker_ts__run$spec_b_b+0x2208>
100002aac:     	mov	w9, #0x7ffd             ; =32765
100002ab0:     	cmp	x9, x8, lsr #48
100002ab4:     	b.ne	0x100002ac0 <_perry_fn_access_worker_ts__run$spec_b_b+0x2200>
100002ab8:     	and	x8, x8, #0xffffffffffff
100002abc:     	cbnz	x8, 0x100002ac8 <_perry_fn_access_worker_ts__run$spec_b_b+0x2208>
100002ac0:     	bl	0x100841250 <_js_is_truthy>
100002ac4:     	cbz	w0, 0x100002b54 <_perry_fn_access_worker_ts__run$spec_b_b+0x2294>
100002ac8:     	fmov	d1, #1.00000000
100002acc:     	fmov	d0, x24
100002ad0:     	and	x8, x24, #0xffff000000000000
100002ad4:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100002ad8:     	cmp	x24, x9
100002adc:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100002ae0:     	ccmp	x8, x9, #0x2, hs
100002ae4:     	cset	w8, hi
100002ae8:     	fmov	x9, d1
100002aec:     	mov	x10, #0x7ff8ffffffffffff ; =9221401712017801215
100002af0:     	cmp	x9, x10
100002af4:     	b.hi	0x100002b04 <_perry_fn_access_worker_ts__run$spec_b_b+0x2244>
100002af8:     	tbz	w8, #0x0, 0x100002b04 <_perry_fn_access_worker_ts__run$spec_b_b+0x2244>
100002afc:     	fadd	d0, d1, d0
100002b00:     	b	0x100002b10 <_perry_fn_access_worker_ts__run$spec_b_b+0x2250>
100002b04:     	stp	x23, x25, [sp, #0x10]
100002b08:     	bl	0x10081f2e4 <_js_dynamic_string_or_number_add>
100002b0c:     	ldp	x23, x25, [sp, #0x10]
100002b10:     	fmov	x24, d0
100002b14:     	mov	x0, x24
100002b18:     	ldr	w8, [x27]
100002b1c:     	cbz	w8, 0x100002b24 <_perry_fn_access_worker_ts__run$spec_b_b+0x2264>
100002b20:     	bl	0x10092b40c <_js_write_barrier_root_nanbox>
100002b24:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100002b28:     	add	x8, x8, #0x28
100002b2c:     	ldr	w8, [x8]
100002b30:     	cbz	w8, 0x100002b48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2288>
100002b34:     	stp	x25, x23, [sp, #0x10]
100002b38:     	str	x24, [sp, #0x8]
100002b3c:     	bl	0x100837b60 <_js_gc_loop_safepoint>
100002b40:     	ldp	x24, x25, [sp, #0x8]
100002b44:     	ldr	x23, [sp, #0x18]
100002b48:     	add	w9, w28, #0x1
100002b4c:     	tbz	w26, #0x0, 0x100001908 <_perry_fn_access_worker_ts__run$spec_b_b+0x1048>
100002b50:     	b	0x100001974 <_perry_fn_access_worker_ts__run$spec_b_b+0x10b4>
100002b54:     	movi.2d	v1, #0000000000000000
100002b58:     	b	0x100002acc <_perry_fn_access_worker_ts__run$spec_b_b+0x220c>
100002b5c:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002b60:     	ldr	x8, [x8, #0x6a8]
100002b64:     	stp	x25, x24, [sp, #0x10]
100002b68:     	str	x23, [sp, #0x8]
100002b6c:     	and	x1, x8, #0xffffffffffff
100002b70:     	adrp	x3, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002b74:     	add	x3, x3, #0x5c8
100002b78:     	bl	0x100886300 <_js_object_get_field_ic_overflow_load>
100002b7c:     	b	0x100002a54 <_perry_fn_access_worker_ts__run$spec_b_b+0x2194>
100002b80:     	add	x8, x9, x10, lsl #3
100002b84:     	ldr	d0, [x8, #0x10]
100002b88:     	b	0x100001cb4 <_perry_fn_access_worker_ts__run$spec_b_b+0x13f4>
100002b8c:     	mov	x27, x28
100002b90:     	mov	w26, #0x0               ; =0
100002b94:     	mov	x24, #0x0               ; =0
100002b98:     	adrp	x21, 0x100f7c000 <_perry_global_access_worker_ts__1>
100002b9c:     	adrp	x22, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100002ba0:     	add	x22, x22, #0x824
100002ba4:     	adrp	x19, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100002ba8:     	add	x19, x19, #0xc30
100002bac:     	mov	x20, #0x7ffd000000000000 ; =9222527611924643840
100002bb0:     	adrp	x8, 0x100b60000 <__mi_theap_area_visit_blocks.cold.1+0x44>
100002bb4:     	ldr	d9, [x8, #0xf48]
100002bb8:     	adrp	x8, 0x100b60000 <__mi_theap_area_visit_blocks.cold.1+0x44>
100002bbc:     	ldr	d10, [x8, #0xf50]
100002bc0:     	mov	x8, #0x41f0000000000000 ; =4751297606875873280
100002bc4:     	fmov	d11, x8
100002bc8:     	tbnz	w27, #0x0, 0x100002c34 <_perry_fn_access_worker_ts__run$spec_b_b+0x2374>
100002bcc:     	mov	x20, x19
100002bd0:     	mov	x19, x27
100002bd4:     	mov	x27, x22
100002bd8:     	mov	x22, x21
100002bdc:     	mov	x21, x28
100002be0:     	mov	x28, x23
100002be4:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100002be8:     	add	x8, x8, #0x28
100002bec:     	ldr	w8, [x8]
100002bf0:     	cbz	w8, 0x100002c08 <_perry_fn_access_worker_ts__run$spec_b_b+0x2348>
100002bf4:     	stp	x25, x23, [sp, #0x10]
100002bf8:     	str	x24, [sp, #0x8]
100002bfc:     	bl	0x100837b60 <_js_gc_loop_safepoint>
100002c00:     	ldp	x24, x25, [sp, #0x8]
100002c04:     	ldr	x23, [sp, #0x18]
100002c08:     	scvtf	d0, w26
100002c0c:     	fmov	d1, x28
100002c10:     	fcmp	d0, d1
100002c14:     	mov	x28, x21
100002c18:     	mov	x21, x22
100002c1c:     	mov	x22, x27
100002c20:     	mov	x27, x19
100002c24:     	mov	x19, x20
100002c28:     	mov	x20, #0x7ffd000000000000 ; =9222527611924643840
100002c2c:     	b.pl	0x10000321c <_perry_fn_access_worker_ts__run$spec_b_b+0x295c>
100002c30:     	b	0x100002c40 <_perry_fn_access_worker_ts__run$spec_b_b+0x2380>
100002c34:     	cmp	w26, w28
100002c38:     	b.ge	0x10000321c <_perry_fn_access_worker_ts__run$spec_b_b+0x295c>
100002c3c:     	scvtf	d0, w26
100002c40:     	ldr	d1, [x21, #0x8]
100002c44:     	stp	x25, x24, [sp, #0x10]
100002c48:     	str	x23, [sp, #0x8]
100002c4c:     	bl	0x10081d9d4 <_js_dynamic_mod>
100002c50:     	mov.16b	v8, v0
100002c54:     	ldp	x23, x25, [sp, #0x8]
100002c58:     	ldr	x24, [sp, #0x18]
100002c5c:     	mov	x0, x24
100002c60:     	ldr	w8, [x22]
100002c64:     	cbz	w8, 0x100002c6c <_perry_fn_access_worker_ts__run$spec_b_b+0x23ac>
100002c68:     	bl	0x10092b40c <_js_write_barrier_root_nanbox>
100002c6c:     	mov	x8, x25
100002c70:     	and	x9, x8, #0xffffffffffff
100002c74:     	and	x14, x8, #0xffff000000000000
100002c78:     	ldr	x10, [x19]
100002c7c:     	sub	x11, x9, #0x100, lsl #12 ; =0x100000
100002c80:     	cmp	x14, x20
100002c84:     	ccmp	x10, #0x0, #0x0, eq
100002c88:     	mov	x10, #0x7ffffff00000    ; =140737487306752
100002c8c:     	ccmp	x11, x10, #0x2, eq
100002c90:     	b.hs	0x100002ccc <_perry_fn_access_worker_ts__run$spec_b_b+0x240c>
100002c94:     	fcmp	d8, d11
100002c98:     	b.pl	0x100002ccc <_perry_fn_access_worker_ts__run$spec_b_b+0x240c>
100002c9c:     	ldurb	w10, [x9, #-0x8]
100002ca0:     	ldrb	w11, [x9, #0x8]
100002ca4:     	fcmp	d8, #0.0
100002ca8:     	ccmp	w10, #0xb, #0x0, ge
100002cac:     	ccmp	w11, #0x9, #0x2, eq
100002cb0:     	b.hs	0x100002ccc <_perry_fn_access_worker_ts__run$spec_b_b+0x240c>
100002cb4:     	fcvtzs	x10, d8
100002cb8:     	scvtf	d0, x10
100002cbc:     	ldr	w12, [x9]
100002cc0:     	fcmp	d8, d0
100002cc4:     	ccmp	x10, x12, #0x2, eq
100002cc8:     	b.lo	0x100002d84 <_perry_fn_access_worker_ts__run$spec_b_b+0x24c4>
100002ccc:     	adrp	x10, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002cd0:     	add	x10, x10, #0x5d0
100002cd4:     	ldr	x12, [x10]
100002cd8:     	cmp	x12, #0x0
100002cdc:     	csel	x13, x10, x12, eq
100002ce0:     	cmp	x14, x20
100002ce4:     	b.ne	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002ce8:     	fcmp	d8, #0.0
100002cec:     	b.lt	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002cf0:     	fcmp	d8, d9
100002cf4:     	b.pl	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002cf8:     	mov	x10, #-0x20000000000    ; =-2199023255552
100002cfc:     	add	x10, x9, x10
100002d00:     	lsr	x10, x10, #41
100002d04:     	cmp	x10, #0x3f
100002d08:     	b.hs	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002d0c:     	fcvtzs	x10, d8
100002d10:     	scvtf	d0, x10
100002d14:     	fcmp	d8, d0
100002d18:     	b.ne	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002d1c:     	ldursb	w11, [x9, #-0x7]
100002d20:     	tbnz	w11, #0x1f, 0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002d24:     	ldurb	w11, [x9, #-0x8]
100002d28:     	cmp	w11, #0x2
100002d2c:     	b.eq	0x100002db0 <_perry_fn_access_worker_ts__run$spec_b_b+0x24f0>
100002d30:     	cmp	w11, #0x1
100002d34:     	b.ne	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002d38:     	ldurh	w13, [x9, #-0x6]
100002d3c:     	adrp	x11, 0x10104d000 <_out_buf+0x39c8>
100002d40:     	add	x11, x11, #0x820
100002d44:     	ldrb	w12, [x11]
100002d48:     	ldp	w11, w14, [x9]
100002d4c:     	cmp	w11, w14
100002d50:     	b.hi	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002d54:     	tbnz	w13, #0xa, 0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002d58:     	cbnz	w12, 0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002d5c:     	cmp	x10, x11
100002d60:     	b.hs	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002d64:     	add	x8, x9, x10, lsl #3
100002d68:     	ldr	d0, [x8, #0x8]
100002d6c:     	fmov	x8, d0
100002d70:     	mov	x9, #0x10               ; =16
100002d74:     	movk	x9, #0x7ffc, lsl #48
100002d78:     	cmp	x8, x9
100002d7c:     	fcsel	d0, d10, d0, eq
100002d80:     	b	0x100002f68 <_perry_fn_access_worker_ts__run$spec_b_b+0x26a8>
100002d84:     	add	x8, x9, #0x10
100002d88:     	cmp	w11, #0x3
100002d8c:     	b.le	0x100002e00 <_perry_fn_access_worker_ts__run$spec_b_b+0x2540>
100002d90:     	cmp	w11, #0x5
100002d94:     	b.gt	0x100002e50 <_perry_fn_access_worker_ts__run$spec_b_b+0x2590>
100002d98:     	cmp	w11, #0x4
100002d9c:     	b.eq	0x100002e7c <_perry_fn_access_worker_ts__run$spec_b_b+0x25bc>
100002da0:     	cmp	w11, #0x5
100002da4:     	b.ne	0x100002e70 <_perry_fn_access_worker_ts__run$spec_b_b+0x25b0>
100002da8:     	ldr	s0, [x8, x10, lsl #2]
100002dac:     	b	0x100002e74 <_perry_fn_access_worker_ts__run$spec_b_b+0x25b4>
100002db0:     	ldr	x11, [x9, #0x8]
100002db4:     	cbz	x11, 0x100002e1c <_perry_fn_access_worker_ts__run$spec_b_b+0x255c>
100002db8:     	ldr	x14, [x11, #0x60]
100002dbc:     	cbz	x14, 0x100002e1c <_perry_fn_access_worker_ts__run$spec_b_b+0x255c>
100002dc0:     	ldurb	w9, [x14, #-0x8]
100002dc4:     	cmp	w9, #0x1
100002dc8:     	b.ne	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002dcc:     	ldursb	w9, [x14, #-0x7]
100002dd0:     	tbnz	w9, #0x1f, 0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002dd4:     	ldr	w9, [x14]
100002dd8:     	cmp	x10, x9
100002ddc:     	b.hs	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002de0:     	add	x9, x14, x10, lsl #3
100002de4:     	ldr	d0, [x9, #0x8]
100002de8:     	fmov	x9, d0
100002dec:     	mov	x10, #0x10              ; =16
100002df0:     	movk	x10, #0x7ffc, lsl #48
100002df4:     	cmp	x9, x10
100002df8:     	b.ne	0x100002f68 <_perry_fn_access_worker_ts__run$spec_b_b+0x26a8>
100002dfc:     	b	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002e00:     	cbz	w11, 0x100002e68 <_perry_fn_access_worker_ts__run$spec_b_b+0x25a8>
100002e04:     	cmp	w11, #0x2
100002e08:     	b.eq	0x100002e90 <_perry_fn_access_worker_ts__run$spec_b_b+0x25d0>
100002e0c:     	cmp	w11, #0x3
100002e10:     	b.ne	0x100002e70 <_perry_fn_access_worker_ts__run$spec_b_b+0x25b0>
100002e14:     	ldr	h0, [x8, x10, lsl #1]
100002e18:     	b	0x100002e74 <_perry_fn_access_worker_ts__run$spec_b_b+0x25b4>
100002e1c:     	ldr	x13, [x13]
100002e20:     	cbz	x13, 0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002e24:     	tbnz	x13, #0x3f, 0x100002e9c <_perry_fn_access_worker_ts__run$spec_b_b+0x25dc>
100002e28:     	ldp	w15, w14, [x9]
100002e2c:     	orr	x14, x14, x15, lsl #32
100002e30:     	cmp	x14, x13
100002e34:     	b.ne	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002e38:     	ldp	x15, x13, [x12, #0x8]
100002e3c:     	ldp	x14, x12, [x12, #0x18]
100002e40:     	cmp	x15, x12
100002e44:     	b.lo	0x100002ebc <_perry_fn_access_worker_ts__run$spec_b_b+0x25fc>
100002e48:     	cbz	x11, 0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002e4c:     	b	0x100002ec8 <_perry_fn_access_worker_ts__run$spec_b_b+0x2608>
100002e50:     	cmp	w11, #0x6
100002e54:     	b.eq	0x100002e84 <_perry_fn_access_worker_ts__run$spec_b_b+0x25c4>
100002e58:     	cmp	w11, #0x7
100002e5c:     	b.ne	0x100002e70 <_perry_fn_access_worker_ts__run$spec_b_b+0x25b0>
100002e60:     	ldr	d0, [x8, x10, lsl #3]
100002e64:     	b	0x100002f68 <_perry_fn_access_worker_ts__run$spec_b_b+0x26a8>
100002e68:     	ldrsb	w8, [x8, x10]
100002e6c:     	b	0x100002e94 <_perry_fn_access_worker_ts__run$spec_b_b+0x25d4>
100002e70:     	ldr	b0, [x8, x10]
100002e74:     	ucvtf	d0, d0
100002e78:     	b	0x100002f68 <_perry_fn_access_worker_ts__run$spec_b_b+0x26a8>
100002e7c:     	ldr	w8, [x8, x10, lsl #2]
100002e80:     	b	0x100002e94 <_perry_fn_access_worker_ts__run$spec_b_b+0x25d4>
100002e84:     	ldr	s0, [x8, x10, lsl #2]
100002e88:     	fcvt	d0, s0
100002e8c:     	b	0x100002f68 <_perry_fn_access_worker_ts__run$spec_b_b+0x26a8>
100002e90:     	ldrsh	w8, [x8, x10, lsl #1]
100002e94:     	scvtf	d0, w8
100002e98:     	b	0x100002f68 <_perry_fn_access_worker_ts__run$spec_b_b+0x26a8>
100002e9c:     	cbz	x11, 0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002ea0:     	ldr	x14, [x11, #0x30]
100002ea4:     	cmp	x14, x13
100002ea8:     	b.ne	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002eac:     	ldp	x15, x13, [x12, #0x8]
100002eb0:     	ldp	x14, x12, [x12, #0x18]
100002eb4:     	cmp	x15, x12
100002eb8:     	b.hs	0x100002ec8 <_perry_fn_access_worker_ts__run$spec_b_b+0x2608>
100002ebc:     	add	x15, x9, x15, lsl #3
100002ec0:     	add	x15, x15, #0x10
100002ec4:     	b	0x100002eec <_perry_fn_access_worker_ts__run$spec_b_b+0x262c>
100002ec8:     	ldr	x17, [x11, #0x20]
100002ecc:     	cmp	x17, #0x0
100002ed0:     	csel	x16, x17, x11, ne
100002ed4:     	cbz	x17, 0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002ed8:     	ldr	w17, [x16]
100002edc:     	cmp	x15, x17
100002ee0:     	b.hs	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002ee4:     	add	x15, x16, x15, lsl #3
100002ee8:     	add	x15, x15, #0x8
100002eec:     	ldr	d0, [x15]
100002ef0:     	fcmp	d8, d0
100002ef4:     	ccmp	x14, x10, #0x0, mi
100002ef8:     	cset	w14, hi
100002efc:     	add	x10, x13, x10
100002f00:     	cmp	x10, x12
100002f04:     	ccmp	w14, #0x0, #0x4, lo
100002f08:     	b.ne	0x100003210 <_perry_fn_access_worker_ts__run$spec_b_b+0x2950>
100002f0c:     	cbz	x11, 0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002f10:     	cmp	x10, x12
100002f14:     	b.lo	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002f18:     	eor	w9, w14, #0x1
100002f1c:     	tbnz	w9, #0x0, 0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002f20:     	ldr	x12, [x11, #0x20]
100002f24:     	cmp	x12, #0x0
100002f28:     	csel	x9, x12, x11, ne
100002f2c:     	cbz	x12, 0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002f30:     	ldr	w11, [x9]
100002f34:     	cmp	x10, x11
100002f38:     	b.hs	0x100002f48 <_perry_fn_access_worker_ts__run$spec_b_b+0x2688>
100002f3c:     	add	x8, x9, x10, lsl #3
100002f40:     	ldr	d0, [x8, #0x8]
100002f44:     	b	0x100002f68 <_perry_fn_access_worker_ts__run$spec_b_b+0x26a8>
100002f48:     	fmov	d0, x8
100002f4c:     	str	x24, [sp, #0x18]
100002f50:     	mov.16b	v1, v8
100002f54:     	adrp	x0, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002f58:     	add	x0, x0, #0x5d0
100002f5c:     	bl	0x10089c260 <_js_packed_arraylike_index_get>
100002f60:     	ldp	x25, x24, [sp, #0x10]
100002f64:     	ldr	x23, [sp, #0x8]
100002f68:     	fmov	x8, d0
100002f6c:     	mov	x9, #-0x3000000000000   ; =-844424930131968
100002f70:     	and	x9, x8, x9
100002f74:     	cmp	x9, x20
100002f78:     	b.ne	0x100002fe4 <_perry_fn_access_worker_ts__run$spec_b_b+0x2724>
100002f7c:     	and	x0, x8, #0xffffffffffff
100002f80:     	lsr	x8, x0, #20
100002f84:     	cbz	x8, 0x100003138 <_perry_fn_access_worker_ts__run$spec_b_b+0x2878>
100002f88:     	ldurb	w9, [x0, #-0x8]
100002f8c:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100002f90:     	ldr	x8, [x8, #0x5d8]
100002f94:     	cbz	x8, 0x100003054 <_perry_fn_access_worker_ts__run$spec_b_b+0x2794>
100002f98:     	ldurh	w10, [x0, #-0x6]
100002f9c:     	and	w10, w10, #0x800
100002fa0:     	cmp	w9, #0x2
100002fa4:     	ccmp	w10, #0x0, #0x0, eq
100002fa8:     	b.ne	0x100003054 <_perry_fn_access_worker_ts__run$spec_b_b+0x2794>
100002fac:     	ldr	w10, [x0, #0x4]
100002fb0:     	orr	x9, x10, #0x4000000000000000
100002fb4:     	ldr	x11, [x8]
100002fb8:     	cmp	w10, #0x0
100002fbc:     	ccmp	x9, x11, #0x0, ne
100002fc0:     	b.eq	0x10000308c <_perry_fn_access_worker_ts__run$spec_b_b+0x27cc>
100002fc4:     	ldr	x11, [x8, #0x10]
100002fc8:     	cbz	x11, 0x1000030b0 <_perry_fn_access_worker_ts__run$spec_b_b+0x27f0>
100002fcc:     	ldr	x12, [x0, #0x8]
100002fd0:     	cbz	x12, 0x1000030b0 <_perry_fn_access_worker_ts__run$spec_b_b+0x27f0>
100002fd4:     	ldr	x12, [x12, #0x30]
100002fd8:     	cmp	x12, x11
100002fdc:     	b.eq	0x10000307c <_perry_fn_access_worker_ts__run$spec_b_b+0x27bc>
100002fe0:     	b	0x1000030b0 <_perry_fn_access_worker_ts__run$spec_b_b+0x27f0>
100002fe4:     	lsr	x9, x8, #48
100002fe8:     	mov	w10, #0x7ff9            ; =32761
100002fec:     	cmp	x9, x10
100002ff0:     	b.eq	0x100003038 <_perry_fn_access_worker_ts__run$spec_b_b+0x2778>
100002ff4:     	mov	w10, #0x7ffe            ; =32766
100002ff8:     	cmp	w9, w10
100002ffc:     	b.ne	0x100003028 <_perry_fn_access_worker_ts__run$spec_b_b+0x2768>
100003000:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100003004:     	ldr	x9, [x9, #0x688]
100003008:     	str	x24, [sp, #0x18]
10000300c:     	and	x2, x9, #0xffffffffffff
100003010:     	mov	x0, #0x10               ; =16
100003014:     	movk	x0, #0xddae, lsl #32
100003018:     	movk	x0, #0x5556, lsl #48
10000301c:     	mov	x1, x8
100003020:     	bl	0x100903ec0 <_js_typed_feedback_object_get_field_by_name_f64>
100003024:     	b	0x100003154 <_perry_fn_access_worker_ts__run$spec_b_b+0x2894>
100003028:     	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
10000302c:     	add	x9, x8, x9
100003030:     	cmp	x9, #0x2
100003034:     	b.lo	0x100003250 <_perry_fn_access_worker_ts__run$spec_b_b+0x2990>
100003038:     	adrp	x9, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
10000303c:     	ldr	x9, [x9, #0x688]
100003040:     	str	x24, [sp, #0x18]
100003044:     	and	x1, x9, #0xffffffffffff
100003048:     	mov	x0, x8
10000304c:     	bl	0x100885498 <_js_object_get_field_by_name_f64>
100003050:     	b	0x100003154 <_perry_fn_access_worker_ts__run$spec_b_b+0x2894>
100003054:     	cmp	w9, #0x2
100003058:     	ccmp	x8, #0x0, #0x4, eq
10000305c:     	b.eq	0x100003138 <_perry_fn_access_worker_ts__run$spec_b_b+0x2878>
100003060:     	ldr	x9, [x8, #0x10]
100003064:     	cbz	x9, 0x100003138 <_perry_fn_access_worker_ts__run$spec_b_b+0x2878>
100003068:     	ldr	x10, [x0, #0x8]
10000306c:     	cbz	x10, 0x100003138 <_perry_fn_access_worker_ts__run$spec_b_b+0x2878>
100003070:     	ldr	x10, [x10, #0x30]
100003074:     	cmp	x10, x9
100003078:     	b.ne	0x100003138 <_perry_fn_access_worker_ts__run$spec_b_b+0x2878>
10000307c:     	ldr	x8, [x8, #0x8]
100003080:     	add	x8, x0, x8, lsl #3
100003084:     	ldr	d1, [x8, #0x10]
100003088:     	b	0x100003160 <_perry_fn_access_worker_ts__run$spec_b_b+0x28a0>
10000308c:     	ldr	x2, [x8, #0x8]
100003090:     	tbnz	w2, #0x1e, 0x1000031f0 <_perry_fn_access_worker_ts__run$spec_b_b+0x2930>
100003094:     	add	x11, x0, x2, lsl #3
100003098:     	ldr	d1, [x11, #0x10]
10000309c:     	fmov	x11, d1
1000030a0:     	mov	x12, #0x10              ; =16
1000030a4:     	movk	x12, #0x7ffc, lsl #48
1000030a8:     	cmp	x11, x12
1000030ac:     	b.ne	0x100003160 <_perry_fn_access_worker_ts__run$spec_b_b+0x28a0>
1000030b0:     	ldr	x11, [x8, #0x18]
1000030b4:     	cmp	x11, #0x0
1000030b8:     	b.le	0x100003138 <_perry_fn_access_worker_ts__run$spec_b_b+0x2878>
1000030bc:     	ldr	x11, [x8, #0x20]
1000030c0:     	ldr	x12, [x8, #0x30]
1000030c4:     	ldr	x13, [x8, #0x40]
1000030c8:     	cmp	x13, x9
1000030cc:     	ldr	x14, [x8, #0x50]
1000030d0:     	ccmp	x14, x9, #0x4, ne
1000030d4:     	ccmp	x12, x9, #0x4, ne
1000030d8:     	ccmp	x11, x9, #0x4, ne
1000030dc:     	cset	w15, eq
1000030e0:     	cmp	w10, #0x0
1000030e4:     	ccmp	w15, #0x0, #0x4, ne
1000030e8:     	b.eq	0x100003138 <_perry_fn_access_worker_ts__run$spec_b_b+0x2878>
1000030ec:     	ldr	x10, [x8, #0x48]
1000030f0:     	ldr	x15, [x8, #0x58]
1000030f4:     	cmp	x14, x9
1000030f8:     	csel	x14, x15, xzr, eq
1000030fc:     	cmp	x13, x9
100003100:     	csel	x10, x10, x14, eq
100003104:     	ldr	x13, [x8, #0x28]
100003108:     	ldr	x8, [x8, #0x38]
10000310c:     	cmp	x12, x9
100003110:     	csel	x8, x8, x10, eq
100003114:     	cmp	x11, x9
100003118:     	csel	x8, x13, x8, eq
10000311c:     	add	x8, x0, x8, lsl #3
100003120:     	ldr	d1, [x8, #0x10]
100003124:     	fmov	x8, d1
100003128:     	mov	x9, #0x10               ; =16
10000312c:     	movk	x9, #0x7ffc, lsl #48
100003130:     	cmp	x8, x9
100003134:     	b.ne	0x100003160 <_perry_fn_access_worker_ts__run$spec_b_b+0x28a0>
100003138:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
10000313c:     	ldr	x8, [x8, #0x688]
100003140:     	str	x24, [sp, #0x18]
100003144:     	and	x1, x8, #0xffffffffffff
100003148:     	adrp	x2, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
10000314c:     	add	x2, x2, #0x5d8
100003150:     	bl	0x100885980 <_js_object_get_field_ic_miss>
100003154:     	mov.16b	v1, v0
100003158:     	ldp	x23, x25, [sp, #0x8]
10000315c:     	ldr	x24, [sp, #0x18]
100003160:     	fmov	d0, x24
100003164:     	and	x9, x24, #0xffff000000000000
100003168:     	fmov	x8, d1
10000316c:     	and	x10, x8, #0xffff000000000000
100003170:     	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
100003174:     	cmp	x8, x11
100003178:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10000317c:     	ccmp	x10, x8, #0x2, hs
100003180:     	cset	w8, hi
100003184:     	mov	x10, #0x1               ; =1
100003188:     	movk	x10, #0x7fff, lsl #48
10000318c:     	cmp	x9, x10
100003190:     	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
100003194:     	ccmp	x24, x9, #0x0, lo
100003198:     	b.hi	0x1000031a8 <_perry_fn_access_worker_ts__run$spec_b_b+0x28e8>
10000319c:     	tbz	w8, #0x0, 0x1000031a8 <_perry_fn_access_worker_ts__run$spec_b_b+0x28e8>
1000031a0:     	fadd	d0, d1, d0
1000031a4:     	b	0x1000031b0 <_perry_fn_access_worker_ts__run$spec_b_b+0x28f0>
1000031a8:     	bl	0x10081f2e4 <_js_dynamic_string_or_number_add>
1000031ac:     	ldp	x23, x25, [sp, #0x8]
1000031b0:     	fmov	x24, d0
1000031b4:     	mov	x0, x24
1000031b8:     	ldr	w8, [x22]
1000031bc:     	cbz	w8, 0x1000031c4 <_perry_fn_access_worker_ts__run$spec_b_b+0x2904>
1000031c0:     	bl	0x10092b40c <_js_write_barrier_root_nanbox>
1000031c4:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1000031c8:     	add	x8, x8, #0x28
1000031cc:     	ldr	w8, [x8]
1000031d0:     	cbz	w8, 0x1000031e4 <_perry_fn_access_worker_ts__run$spec_b_b+0x2924>
1000031d4:     	str	x24, [sp, #0x18]
1000031d8:     	bl	0x100837b60 <_js_gc_loop_safepoint>
1000031dc:     	ldp	x25, x24, [sp, #0x10]
1000031e0:     	ldr	x23, [sp, #0x8]
1000031e4:     	add	w26, w26, #0x1
1000031e8:     	tbz	w27, #0x0, 0x100002bcc <_perry_fn_access_worker_ts__run$spec_b_b+0x230c>
1000031ec:     	b	0x100002c34 <_perry_fn_access_worker_ts__run$spec_b_b+0x2374>
1000031f0:     	adrp	x8, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1000031f4:     	ldr	x8, [x8, #0x688]
1000031f8:     	str	x24, [sp, #0x18]
1000031fc:     	and	x1, x8, #0xffffffffffff
100003200:     	adrp	x3, 0x100fc6000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100003204:     	add	x3, x3, #0x5d8
100003208:     	bl	0x100886300 <_js_object_get_field_ic_overflow_load>
10000320c:     	b	0x100003154 <_perry_fn_access_worker_ts__run$spec_b_b+0x2894>
100003210:     	add	x8, x9, x10, lsl #3
100003214:     	ldr	d0, [x8, #0x10]
100003218:     	b	0x100002f68 <_perry_fn_access_worker_ts__run$spec_b_b+0x26a8>
10000321c:     	fmov	d0, x24
100003220:     	ldp	x29, x30, [sp, #0xb0]
100003224:     	ldp	x20, x19, [sp, #0xa0]
100003228:     	ldp	x22, x21, [sp, #0x90]
10000322c:     	ldp	x24, x23, [sp, #0x80]
100003230:     	ldp	x26, x25, [sp, #0x70]
100003234:     	ldp	x28, x27, [sp, #0x60]
100003238:     	ldp	d9, d8, [sp, #0x50]
10000323c:     	ldp	d11, d10, [sp, #0x40]
100003240:     	ldp	d13, d12, [sp, #0x30]
100003244:     	ldp	d15, d14, [sp, #0x20]
100003248:     	add	sp, sp, #0xc0
10000324c:     	ret
100003250:     	mov	x9, #0x10               ; =16
100003254:     	movk	x9, #0x7ffc, lsl #48
100003258:     	sub	x9, x9, #0xe
10000325c:     	cmp	x8, x9
100003260:     	cset	w0, eq
100003264:     	adrp	x1, 0x100d5f000 <_ZSTDv06_decodeSequence.OF_base+0xc>
100003268:     	add	x1, x1, #0x848
10000326c:     	mov	w2, #0x2                ; =2
100003270:     	bl	0x1008f306c <_js_throw_type_error_property_access>
100003274:     	brk	#0x1
100003278:     	mov	x9, #0x10               ; =16
10000327c:     	movk	x9, #0x7ffc, lsl #48
100003280:     	sub	x9, x9, #0xe
100003284:     	cmp	x8, x9
100003288:     	cset	w0, eq
10000328c:     	adrp	x1, 0x100d5f000 <_ZSTDv06_decodeSequence.OF_base+0xc>
100003290:     	add	x1, x1, #0x859
100003294:     	mov	w2, #0x4                ; =4
100003298:     	b	0x100003270 <_perry_fn_access_worker_ts__run$spec_b_b+0x29b0>
10000329c:     	mov	x9, #0x10               ; =16
1000032a0:     	movk	x9, #0x7ffc, lsl #48
1000032a4:     	sub	x9, x9, #0xe
1000032a8:     	cmp	x8, x9
1000032ac:     	cset	w0, eq
1000032b0:     	adrp	x1, 0x100d5f000 <_ZSTDv06_decodeSequence.OF_base+0xc>
1000032b4:     	add	x1, x1, #0x85e
1000032b8:     	mov	w2, #0x6                ; =6
1000032bc:     	b	0x100003270 <_perry_fn_access_worker_ts__run$spec_b_b+0x29b0>
