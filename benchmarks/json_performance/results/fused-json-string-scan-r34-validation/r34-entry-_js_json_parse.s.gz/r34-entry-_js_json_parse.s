
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/fused-json-string-scan-r34/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100843594 <_js_json_parse>:
100843594:     	stp	x29, x30, [sp, #-0x10]!
100843598:     	mov	x29, sp
10084359c:     	cbz	x0, 0x1008435f4 <_js_json_parse+0x60>
1008435a0:     	ldr	w1, [x0, #0x4]
1008435a4:     	cmp	w1, #0x2
1008435a8:     	b.eq	0x1008435b8 <_js_json_parse+0x24>
1008435ac:     	cbz	w1, 0x1008435f4 <_js_json_parse+0x60>
1008435b0:     	ldrb	w8, [x0, #0x14]
1008435b4:     	b	0x1008435d8 <_js_json_parse+0x44>
1008435b8:     	ldrb	w8, [x0, #0x14]
1008435bc:     	cmp	w8, #0x7b
1008435c0:     	b.ne	0x1008435d8 <_js_json_parse+0x44>
1008435c4:     	ldrb	w8, [x0, #0x15]
1008435c8:     	cmp	w8, #0x7d
1008435cc:     	b.ne	0x1008435e4 <_js_json_parse+0x50>
1008435d0:     	ldp	x29, x30, [sp], #0x10
1008435d4:     	b	0x1004eb180 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
1008435d8:     	orr	w8, w8, #0x20
1008435dc:     	cmp	w8, #0x7b
1008435e0:     	b.ne	0x1008435ec <_js_json_parse+0x58>
1008435e4:     	ldp	x29, x30, [sp], #0x10
1008435e8:     	b	0x100504448 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
1008435ec:     	ldp	x29, x30, [sp], #0x10
1008435f0:     	b	0x100506ac4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
1008435f4:     	adrp	x0, 0x100c74000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x6a1c>
1008435f8:     	add	x0, x0, #0xac1
1008435fc:     	mov	w1, #0x1c               ; =28
100843600:     	bl	0x100506ef8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
