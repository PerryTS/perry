
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/fused-json-string-scan-r34/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007bce10 <_js_array_get_f64>:
1007bce10:     	sub	sp, sp, #0x70
1007bce14:     	stp	x26, x25, [sp, #0x20]
1007bce18:     	stp	x24, x23, [sp, #0x30]
1007bce1c:     	stp	x22, x21, [sp, #0x40]
1007bce20:     	stp	x20, x19, [sp, #0x50]
1007bce24:     	stp	x29, x30, [sp, #0x60]
1007bce28:     	add	x29, sp, #0x60
1007bce2c:     	mov	x19, x1
1007bce30:     	mov	x22, x0
1007bce34:     	lsr	x25, x0, #51
1007bce38:     	mov	x20, x0
1007bce3c:     	cmp	x25, #0xfff
1007bce40:     	b.lo	0x1007bce5c <_js_array_get_f64+0x4c>
1007bce44:     	mov	w8, #0x7ffc             ; =32764
1007bce48:     	cmp	x8, x22, lsr #48
1007bce4c:     	b.ne	0x1007bce58 <_js_array_get_f64+0x48>
1007bce50:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007bce54:     	b	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bce58:     	and	x20, x22, #0xffffffffffff
1007bce5c:     	lsr	x8, x20, #3
1007bce60:     	cmp	x8, #0x200
1007bce64:     	b.ls	0x1007bce9c <_js_array_get_f64+0x8c>
1007bce68:     	ldurb	w8, [x20, #-0x8]
1007bce6c:     	cmp	w8, #0x9
1007bce70:     	b.ne	0x1007bce9c <_js_array_get_f64+0x8c>
1007bce74:     	ldr	w8, [x20, #0x4]
1007bce78:     	mov	w9, #0x5841             ; =22593
1007bce7c:     	movk	w9, #0x4c5a, lsl #16
1007bce80:     	cmp	w8, w9
1007bce84:     	b.ne	0x1007bce9c <_js_array_get_f64+0x8c>
1007bce88:     	mov	x0, x20
1007bce8c:     	mov	x1, x19
1007bce90:     	bl	0x100685e44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007bce94:     	fmov	d0, x0
1007bce98:     	b	0x1007bd50c <_js_array_get_f64+0x6fc>
1007bce9c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bcea0:     	b.lo	0x1007bcf50 <_js_array_get_f64+0x140>
1007bcea4:     	tst	x20, #0xffff800000000000
1007bcea8:     	mov	w8, #0x1000             ; =4096
1007bceac:     	ccmp	x20, x8, #0x0, eq
1007bceb0:     	b.lo	0x1007bcf50 <_js_array_get_f64+0x140>
1007bceb4:     	ldurb	w24, [x20, #-0x8]
1007bceb8:     	ldurh	w23, [x20, #-0x6]
1007bcebc:     	cmp	w24, #0xa
1007bcec0:     	b.gt	0x1007bd068 <_js_array_get_f64+0x258>
1007bcec4:     	cmp	w24, #0x2
1007bcec8:     	b.eq	0x1007bd0f0 <_js_array_get_f64+0x2e0>
1007bcecc:     	cmp	w24, #0x8
1007bced0:     	b.ne	0x1007bcf58 <_js_array_get_f64+0x148>
1007bced4:     	mov	x0, x20
1007bced8:     	bl	0x100303a28 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007bcedc:     	cbz	w0, 0x1007bd180 <_js_array_get_f64+0x370>
1007bcee0:     	mov	x22, #0x1               ; =1
1007bcee4:     	movk	x22, #0x7ffc, lsl #48
1007bcee8:     	lsr	x8, x20, #51
1007bceec:     	cmp	x8, #0xfff
1007bcef0:     	b.lo	0x1007bcf04 <_js_array_get_f64+0xf4>
1007bcef4:     	mov	w8, #0x7ffc             ; =32764
1007bcef8:     	cmp	x8, x20, lsr #48
1007bcefc:     	b.eq	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bcf00:     	and	x20, x20, #0xffffffffffff
1007bcf04:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bcf08:     	b.lo	0x1007bcf28 <_js_array_get_f64+0x118>
1007bcf0c:     	tst	x20, #0xffff800000000000
1007bcf10:     	mov	w8, #0x1000             ; =4096
1007bcf14:     	ccmp	x20, x8, #0x0, eq
1007bcf18:     	b.lo	0x1007bcf28 <_js_array_get_f64+0x118>
1007bcf1c:     	ldurb	w8, [x20, #-0x8]
1007bcf20:     	cmp	w8, #0x2
1007bcf24:     	b.eq	0x1007bd7f4 <_js_array_get_f64+0x9e4>
1007bcf28:     	cbz	x20, 0x1007bd508 <_js_array_get_f64+0x6f8>
1007bcf2c:     	mov	x0, x20
1007bcf30:     	mov	x1, x19
1007bcf34:     	bl	0x100303bd8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007bcf38:     	cmp	w0, #0x1
1007bcf3c:     	b.ne	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bcf40:     	ldr	x8, [x20, #0x8]
1007bcf44:     	ubfiz	x9, x1, #4, #32
1007bcf48:     	ldr	x22, [x8, x9]
1007bcf4c:     	b	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bcf50:     	mov	w23, #0x0               ; =0
1007bcf54:     	mov	w24, #0x0               ; =0
1007bcf58:     	mov	x21, x22
1007bcf5c:     	cmp	x25, #0xfff
1007bcf60:     	b.lo	0x1007bcf78 <_js_array_get_f64+0x168>
1007bcf64:     	mov	w8, #0x7ffc             ; =32764
1007bcf68:     	cmp	x8, x22, lsr #48
1007bcf6c:     	b.eq	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bcf70:     	ands	x21, x22, #0xffffffffffff
1007bcf74:     	b.eq	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bcf78:     	and	x8, x21, #0xfffffffffff00000
1007bcf7c:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007bcf80:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007bcf84:     	cmp	x9, x10
1007bcf88:     	ccmp	x8, #0x0, #0x4, lo
1007bcf8c:     	b.eq	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bcf90:     	tst	x21, #0x3
1007bcf94:     	ccmp	x21, #0x7, #0x0, eq
1007bcf98:     	b.ls	0x1007bd248 <_js_array_get_f64+0x438>
1007bcf9c:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007bcfa0:     	ldr	x8, [x8, #0x48]
1007bcfa4:     	cmn	x8, #0x1
1007bcfa8:     	b.eq	0x1007bd198 <_js_array_get_f64+0x388>
1007bcfac:     	mrs	x9, TPIDRRO_EL0
1007bcfb0:     	and	x9, x9, #0xfffffffffffffff8
1007bcfb4:     	ldr	x0, [x9, x8, lsl #3]
1007bcfb8:     	cbz	x0, 0x1007bd198 <_js_array_get_f64+0x388>
1007bcfbc:     	lsr	x1, x21, #20
1007bcfc0:     	ldr	x8, [x0, #0x10]
1007bcfc4:     	ldrb	w9, [x8]
1007bcfc8:     	cmp	w9, #0x2
1007bcfcc:     	b.ne	0x1007bd1b0 <_js_array_get_f64+0x3a0>
1007bcfd0:     	ldrb	w9, [x8, #0x88]
1007bcfd4:     	tbz	w9, #0x0, 0x1007bcff4 <_js_array_get_f64+0x1e4>
1007bcfd8:     	ldr	x9, [x8, #0x80]
1007bcfdc:     	cmp	x9, x1
1007bcfe0:     	b.ne	0x1007bcff4 <_js_array_get_f64+0x1e4>
1007bcfe4:     	ldp	x9, x10, [x8, #0x60]
1007bcfe8:     	cmp	x9, x21
1007bcfec:     	ccmp	x10, x21, #0x0, ls
1007bcff0:     	b.hi	0x1007bd190 <_js_array_get_f64+0x380>
1007bcff4:     	ldrb	w9, [x8, #0xb8]
1007bcff8:     	cbz	w9, 0x1007bd018 <_js_array_get_f64+0x208>
1007bcffc:     	ldr	x9, [x8, #0xb0]
1007bd000:     	cmp	x9, x1
1007bd004:     	b.ne	0x1007bd018 <_js_array_get_f64+0x208>
1007bd008:     	ldp	x9, x10, [x8, #0x90]
1007bd00c:     	cmp	x9, x21
1007bd010:     	ccmp	x10, x21, #0x0, ls
1007bd014:     	b.hi	0x1007bd658 <_js_array_get_f64+0x848>
1007bd018:     	ldrb	w9, [x8, #0xe8]
1007bd01c:     	cbz	w9, 0x1007bd03c <_js_array_get_f64+0x22c>
1007bd020:     	ldr	x9, [x8, #0xe0]
1007bd024:     	cmp	x9, x1
1007bd028:     	b.ne	0x1007bd03c <_js_array_get_f64+0x22c>
1007bd02c:     	ldp	x9, x10, [x8, #0xc0]
1007bd030:     	cmp	x9, x21
1007bd034:     	ccmp	x10, x21, #0x0, ls
1007bd038:     	b.hi	0x1007bd740 <_js_array_get_f64+0x930>
1007bd03c:     	ldrb	w9, [x8, #0x118]
1007bd040:     	cbz	w9, 0x1007bd210 <_js_array_get_f64+0x400>
1007bd044:     	ldr	x9, [x8, #0x110]
1007bd048:     	cmp	x9, x1
1007bd04c:     	b.ne	0x1007bd210 <_js_array_get_f64+0x400>
1007bd050:     	ldp	x9, x10, [x8, #0xf0]
1007bd054:     	cmp	x9, x21
1007bd058:     	ccmp	x10, x21, #0x0, ls
1007bd05c:     	b.ls	0x1007bd210 <_js_array_get_f64+0x400>
1007bd060:     	add	x9, x8, #0xf0
1007bd064:     	b	0x1007bd744 <_js_array_get_f64+0x934>
1007bd068:     	cmp	w24, #0xb
1007bd06c:     	b.eq	0x1007bd108 <_js_array_get_f64+0x2f8>
1007bd070:     	cmp	w24, #0xc
1007bd074:     	b.ne	0x1007bcf58 <_js_array_get_f64+0x148>
1007bd078:     	mov	x0, x20
1007bd07c:     	bl	0x1003097b8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007bd080:     	cbz	w0, 0x1007bd188 <_js_array_get_f64+0x378>
1007bd084:     	mov	x22, #0x1               ; =1
1007bd088:     	movk	x22, #0x7ffc, lsl #48
1007bd08c:     	lsr	x8, x20, #51
1007bd090:     	cmp	x8, #0xfff
1007bd094:     	b.lo	0x1007bd0a8 <_js_array_get_f64+0x298>
1007bd098:     	mov	w8, #0x7ffc             ; =32764
1007bd09c:     	cmp	x8, x20, lsr #48
1007bd0a0:     	b.eq	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bd0a4:     	and	x20, x20, #0xffffffffffff
1007bd0a8:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bd0ac:     	b.lo	0x1007bd0cc <_js_array_get_f64+0x2bc>
1007bd0b0:     	tst	x20, #0xffff800000000000
1007bd0b4:     	mov	w8, #0x1000             ; =4096
1007bd0b8:     	ccmp	x20, x8, #0x0, eq
1007bd0bc:     	b.lo	0x1007bd0cc <_js_array_get_f64+0x2bc>
1007bd0c0:     	ldurb	w8, [x20, #-0x8]
1007bd0c4:     	cmp	w8, #0x2
1007bd0c8:     	b.eq	0x1007bd80c <_js_array_get_f64+0x9fc>
1007bd0cc:     	cbz	x20, 0x1007bd508 <_js_array_get_f64+0x6f8>
1007bd0d0:     	mov	x0, x20
1007bd0d4:     	mov	x1, x19
1007bd0d8:     	bl	0x10030b430 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007bd0dc:     	cmp	w0, #0x1
1007bd0e0:     	b.ne	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bd0e4:     	ldr	x8, [x20, #0x8]
1007bd0e8:     	ldr	x22, [x8, w1, uxtw #3]
1007bd0ec:     	b	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bd0f0:     	mov	x0, x22
1007bd0f4:     	mov	x1, x19
1007bd0f8:     	bl	0x100546ccc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bd0fc:     	tbnz	w0, #0x0, 0x1007bd504 <_js_array_get_f64+0x6f4>
1007bd100:     	mov	w24, #0x2               ; =2
1007bd104:     	b	0x1007bcf58 <_js_array_get_f64+0x148>
1007bd108:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bd10c:     	add	x8, x8, #0xec0
1007bd110:     	ldaprb	w8, [x8]
1007bd114:     	cbz	w8, 0x1007bd178 <_js_array_get_f64+0x368>
1007bd118:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007bd11c:     	add	x8, x8, #0x58
1007bd120:     	ldapr	x8, [x8]
1007bd124:     	cmp	x20, x8
1007bd128:     	b.lo	0x1007bd178 <_js_array_get_f64+0x368>
1007bd12c:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007bd130:     	add	x8, x8, #0x60
1007bd134:     	ldapr	x8, [x8]
1007bd138:     	cmp	x20, x8
1007bd13c:     	b.hi	0x1007bd178 <_js_array_get_f64+0x368>
1007bd140:     	mov	x0, x20
1007bd144:     	bl	0x1002a34f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd148:     	tbz	w0, #0x0, 0x1007bd178 <_js_array_get_f64+0x368>
1007bd14c:     	add	x0, sp, #0x8
1007bd150:     	mov	x1, x20
1007bd154:     	bl	0x1002a332c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007bd158:     	ldr	x8, [sp, #0x8]
1007bd15c:     	cbz	x8, 0x1007bd784 <_js_array_get_f64+0x974>
1007bd160:     	cmp	x8, #0x1
1007bd164:     	b.ne	0x1007bd7c8 <_js_array_get_f64+0x9b8>
1007bd168:     	ldr	d0, [sp, #0x10]
1007bd16c:     	scvtf	d1, w19
1007bd170:     	bl	0x10081b3b4 <_js_dyn_index_get>
1007bd174:     	b	0x1007bd504 <_js_array_get_f64+0x6f4>
1007bd178:     	mov	w24, #0xb               ; =11
1007bd17c:     	b	0x1007bcf58 <_js_array_get_f64+0x148>
1007bd180:     	mov	w24, #0x8               ; =8
1007bd184:     	b	0x1007bcf58 <_js_array_get_f64+0x148>
1007bd188:     	mov	w24, #0xc               ; =12
1007bd18c:     	b	0x1007bcf58 <_js_array_get_f64+0x148>
1007bd190:     	add	x9, x8, #0x60
1007bd194:     	b	0x1007bd744 <_js_array_get_f64+0x934>
1007bd198:     	bl	0x100b3e87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007bd19c:     	lsr	x1, x21, #20
1007bd1a0:     	ldr	x8, [x0, #0x10]
1007bd1a4:     	ldrb	w9, [x8]
1007bd1a8:     	cmp	w9, #0x2
1007bd1ac:     	b.eq	0x1007bcfd0 <_js_array_get_f64+0x1c0>
1007bd1b0:     	ldr	x9, [x8, #0x8]
1007bd1b4:     	ldr	x10, [x8, #0x28]
1007bd1b8:     	sub	x9, x1, x9
1007bd1bc:     	cmp	x9, x10
1007bd1c0:     	b.hs	0x1007bd204 <_js_array_get_f64+0x3f4>
1007bd1c4:     	ldr	x10, [x8, #0x20]
1007bd1c8:     	mov	w11, #0x28              ; =40
1007bd1cc:     	madd	x9, x9, x11, x10
1007bd1d0:     	ldr	x10, [x9]
1007bd1d4:     	ldr	x11, [x8, #0x10]
1007bd1d8:     	cmp	x10, x11
1007bd1dc:     	b.ne	0x1007bd210 <_js_array_get_f64+0x400>
1007bd1e0:     	ldp	x10, x11, [x9, #0x8]
1007bd1e4:     	cmp	x10, x21
1007bd1e8:     	ccmp	x11, x21, #0x0, ls
1007bd1ec:     	b.ls	0x1007bd210 <_js_array_get_f64+0x400>
1007bd1f0:     	ldr	x10, [x8, #0x30]
1007bd1f4:     	add	x10, x10, #0x1
1007bd1f8:     	str	x10, [x8, #0x30]
1007bd1fc:     	add	x8, x9, #0x21
1007bd200:     	b	0x1007bd754 <_js_array_get_f64+0x944>
1007bd204:     	ldr	x9, [x8, #0x58]
1007bd208:     	add	x9, x9, #0x1
1007bd20c:     	str	x9, [x8, #0x58]
1007bd210:     	ldr	x9, [x8, #0x38]
1007bd214:     	add	x9, x9, #0x1
1007bd218:     	str	x9, [x8, #0x38]
1007bd21c:     	mov	x0, x21
1007bd220:     	bl	0x10051ca08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007bd224:     	and	w8, w0, #0xff
1007bd228:     	cbz	w8, 0x1007bd248 <_js_array_get_f64+0x438>
1007bd22c:     	ldurb	w8, [x21, #-0x8]
1007bd230:     	ldurb	w9, [x21, #-0x7]
1007bd234:     	mov	w10, #0x82              ; =130
1007bd238:     	and	w9, w9, w10
1007bd23c:     	cmp	w9, #0x2
1007bd240:     	ccmp	w8, #0x1, #0x0, eq
1007bd244:     	b.eq	0x1007bd318 <_js_array_get_f64+0x508>
1007bd248:     	mov	x0, x21
1007bd24c:     	bl	0x100579080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd250:     	cbz	x0, 0x1007bd278 <_js_array_get_f64+0x468>
1007bd254:     	ldrb	w9, [x0]
1007bd258:     	cmp	w9, #0x1
1007bd25c:     	b.ne	0x1007bd294 <_js_array_get_f64+0x484>
1007bd260:     	ldrsb	w8, [x0, #0x1]
1007bd264:     	tbnz	w8, #0x1f, 0x1007bd340 <_js_array_get_f64+0x530>
1007bd268:     	ldp	w10, w9, [x21]
1007bd26c:     	cmp	w10, w9
1007bd270:     	b.hi	0x1007bd3cc <_js_array_get_f64+0x5bc>
1007bd274:     	b	0x1007bd3e4 <_js_array_get_f64+0x5d4>
1007bd278:     	mov	x25, x0
1007bd27c:     	mov	x0, x21
1007bd280:     	bl	0x1005878b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd284:     	tbz	w0, #0x0, 0x1007bd2d0 <_js_array_get_f64+0x4c0>
1007bd288:     	mov	x0, #0x0                ; =0
1007bd28c:     	mov	x8, x25
1007bd290:     	b	0x1007bd3bc <_js_array_get_f64+0x5ac>
1007bd294:     	mov	x8, x0
1007bd298:     	cmp	w9, #0x1
1007bd29c:     	b.eq	0x1007bd3bc <_js_array_get_f64+0x5ac>
1007bd2a0:     	cmp	w9, #0x9
1007bd2a4:     	b.ne	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd2a8:     	ldr	w8, [x21, #0x4]
1007bd2ac:     	mov	w9, #0x5841             ; =22593
1007bd2b0:     	movk	w9, #0x4c5a, lsl #16
1007bd2b4:     	cmp	w8, w9
1007bd2b8:     	b.ne	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd2bc:     	mov	x0, x21
1007bd2c0:     	bl	0x1003746d0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007bd2c4:     	cbz	x0, 0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd2c8:     	mov	x21, x0
1007bd2cc:     	b	0x1007bd400 <_js_array_get_f64+0x5f0>
1007bd2d0:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bd2d4:     	add	x8, x8, #0xec0
1007bd2d8:     	ldaprb	w8, [x8]
1007bd2dc:     	cbz	w8, 0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd2e0:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007bd2e4:     	add	x8, x8, #0x58
1007bd2e8:     	ldapr	x8, [x8]
1007bd2ec:     	cmp	x8, x21
1007bd2f0:     	b.hi	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd2f4:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007bd2f8:     	add	x8, x8, #0x60
1007bd2fc:     	ldapr	x8, [x8]
1007bd300:     	cmp	x8, x21
1007bd304:     	b.lo	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd308:     	mov	x0, x21
1007bd30c:     	bl	0x1002a34f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd310:     	tbnz	w0, #0x0, 0x1007bd288 <_js_array_get_f64+0x478>
1007bd314:     	b	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd318:     	ldr	w8, [x21]
1007bd31c:     	mov	w9, #0xe100             ; =57600
1007bd320:     	movk	w9, #0x5f5, lsl #16
1007bd324:     	orr	w9, w9, #0x1
1007bd328:     	cmp	w8, w9
1007bd32c:     	b.hs	0x1007bd248 <_js_array_get_f64+0x438>
1007bd330:     	ldr	w9, [x21, #0x4]
1007bd334:     	cmp	w8, w9
1007bd338:     	b.ls	0x1007bd400 <_js_array_get_f64+0x5f0>
1007bd33c:     	b	0x1007bd248 <_js_array_get_f64+0x438>
1007bd340:     	mov	x25, x0
1007bd344:     	ldr	x21, [x0, #0x8]
1007bd348:     	mov	x0, x21
1007bd34c:     	bl	0x100579080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd350:     	cbz	x0, 0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd354:     	ldrb	w8, [x0]
1007bd358:     	cmp	w8, #0x1
1007bd35c:     	b.ne	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd360:     	ldrsb	w8, [x0, #0x1]
1007bd364:     	tbz	w8, #0x1f, 0x1007bd268 <_js_array_get_f64+0x458>
1007bd368:     	mov	w26, #0x1               ; =1
1007bd36c:     	ldr	x21, [x0, #0x8]
1007bd370:     	mov	x0, x21
1007bd374:     	bl	0x100579080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd378:     	cbz	x0, 0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd37c:     	ldrb	w8, [x0]
1007bd380:     	cmp	w8, #0x1
1007bd384:     	b.ne	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd388:     	cmp	w26, #0x3f
1007bd38c:     	b.hi	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd390:     	add	w26, w26, #0x1
1007bd394:     	ldrsb	w8, [x0, #0x1]
1007bd398:     	tbnz	w8, #0x1f, 0x1007bd36c <_js_array_get_f64+0x55c>
1007bd39c:     	str	x21, [x25, #0x8]
1007bd3a0:     	ldrb	w8, [x25, #0x1]
1007bd3a4:     	orr	w9, w8, #0x80
1007bd3a8:     	mov	x8, x25
1007bd3ac:     	strb	w9, [x25, #0x1]
1007bd3b0:     	ldrb	w9, [x0]
1007bd3b4:     	cmp	w9, #0x1
1007bd3b8:     	b.ne	0x1007bd2a0 <_js_array_get_f64+0x490>
1007bd3bc:     	ldp	w10, w9, [x21]
1007bd3c0:     	cmp	w10, w9
1007bd3c4:     	b.ls	0x1007bd3e4 <_js_array_get_f64+0x5d4>
1007bd3c8:     	cbz	x8, 0x1007bd3f4 <_js_array_get_f64+0x5e4>
1007bd3cc:     	ldr	w8, [x0, #0x4]
1007bd3d0:     	ubfiz	x9, x9, #3, #32
1007bd3d4:     	add	x9, x9, #0x10
1007bd3d8:     	cmp	x9, x8
1007bd3dc:     	b.eq	0x1007bd400 <_js_array_get_f64+0x5f0>
1007bd3e0:     	b	0x1007bd3f4 <_js_array_get_f64+0x5e4>
1007bd3e4:     	mov	w8, #0xe100             ; =57600
1007bd3e8:     	movk	w8, #0x5f5, lsl #16
1007bd3ec:     	cmp	w10, w8
1007bd3f0:     	b.ls	0x1007bd400 <_js_array_get_f64+0x5f0>
1007bd3f4:     	mov	x0, x21
1007bd3f8:     	bl	0x1005878b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd3fc:     	tbz	w0, #0x0, 0x1007bd4b0 <_js_array_get_f64+0x6a0>
1007bd400:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bd404:     	add	x8, x8, #0xec0
1007bd408:     	ldaprb	w8, [x8]
1007bd40c:     	cbz	w8, 0x1007bd454 <_js_array_get_f64+0x644>
1007bd410:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007bd414:     	add	x8, x8, #0x58
1007bd418:     	ldapr	x8, [x8]
1007bd41c:     	cmp	x21, x8
1007bd420:     	b.lo	0x1007bd454 <_js_array_get_f64+0x644>
1007bd424:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007bd428:     	add	x8, x8, #0x60
1007bd42c:     	ldapr	x8, [x8]
1007bd430:     	cmp	x21, x8
1007bd434:     	b.hi	0x1007bd454 <_js_array_get_f64+0x644>
1007bd438:     	mov	x0, x21
1007bd43c:     	bl	0x1002a34f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd440:     	tbz	w0, #0x0, 0x1007bd454 <_js_array_get_f64+0x644>
1007bd444:     	mov	x0, x21
1007bd448:     	mov	x1, x19
1007bd44c:     	bl	0x1008fb0c8 <_js_typed_array_get>
1007bd450:     	b	0x1007bd504 <_js_array_get_f64+0x6f4>
1007bd454:     	mov	x0, x21
1007bd458:     	bl	0x1005878b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd45c:     	tbz	w0, #0x0, 0x1007bd484 <_js_array_get_f64+0x674>
1007bd460:     	mov	x0, x21
1007bd464:     	mov	x1, x19
1007bd468:     	bl	0x100584bdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007bd46c:     	and	w8, w1, #0xff
1007bd470:     	ucvtf	d0, w8
1007bd474:     	fmov	x8, d0
1007bd478:     	tst	w0, #0x1
1007bd47c:     	csel	x22, x8, xzr, ne
1007bd480:     	b	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bd484:     	cmp	x21, x20
1007bd488:     	b.eq	0x1007bd530 <_js_array_get_f64+0x720>
1007bd48c:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007bd490:     	b.lo	0x1007bd528 <_js_array_get_f64+0x718>
1007bd494:     	tst	x21, #0xffff800000000000
1007bd498:     	mov	w8, #0x1000             ; =4096
1007bd49c:     	ccmp	x21, x8, #0x0, eq
1007bd4a0:     	b.lo	0x1007bd528 <_js_array_get_f64+0x718>
1007bd4a4:     	ldurb	w24, [x21, #-0x8]
1007bd4a8:     	ldurh	w23, [x21, #-0x6]
1007bd4ac:     	b	0x1007bd530 <_js_array_get_f64+0x720>
1007bd4b0:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bd4b4:     	add	x8, x8, #0xec0
1007bd4b8:     	ldaprb	w8, [x8]
1007bd4bc:     	cbz	w8, 0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd4c0:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007bd4c4:     	add	x8, x8, #0x58
1007bd4c8:     	ldapr	x8, [x8]
1007bd4cc:     	cmp	x21, x8
1007bd4d0:     	b.lo	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd4d4:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007bd4d8:     	add	x8, x8, #0x60
1007bd4dc:     	ldapr	x8, [x8]
1007bd4e0:     	cmp	x21, x8
1007bd4e4:     	b.hi	0x1007bd4f4 <_js_array_get_f64+0x6e4>
1007bd4e8:     	mov	x0, x21
1007bd4ec:     	bl	0x1002a34f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd4f0:     	tbnz	w0, #0x0, 0x1007bd400 <_js_array_get_f64+0x5f0>
1007bd4f4:     	mov	x0, x22
1007bd4f8:     	mov	x1, x19
1007bd4fc:     	bl	0x100546ccc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bd500:     	tbz	w0, #0x0, 0x1007bd7d8 <_js_array_get_f64+0x9c8>
1007bd504:     	fmov	x22, d0
1007bd508:     	fmov	d0, x22
1007bd50c:     	ldp	x29, x30, [sp, #0x60]
1007bd510:     	ldp	x20, x19, [sp, #0x50]
1007bd514:     	ldp	x22, x21, [sp, #0x40]
1007bd518:     	ldp	x24, x23, [sp, #0x30]
1007bd51c:     	ldp	x26, x25, [sp, #0x20]
1007bd520:     	add	sp, sp, #0x70
1007bd524:     	ret
1007bd528:     	mov	w23, #0x0               ; =0
1007bd52c:     	mov	w24, #0x0               ; =0
1007bd530:     	cmp	w24, #0x1
1007bd534:     	b.ne	0x1007bd6e8 <_js_array_get_f64+0x8d8>
1007bd538:     	tbz	w23, #0xa, 0x1007bd6e8 <_js_array_get_f64+0x8d8>
1007bd53c:     	adrp	x8, 0x100b64000 <_anon.2aa35172874dc18ddd0733027929dfee.91+0xcd>
1007bd540:     	add	x8, x8, #0x2cc
1007bd544:     	cmp	w19, #0x3e8
1007bd548:     	b.lo	0x1007bd5c0 <_js_array_get_f64+0x7b0>
1007bd54c:     	mov	x9, #0x0                ; =0
1007bd550:     	mov	w11, #0x1759            ; =5977
1007bd554:     	movk	w11, #0xd1b7, lsl #16
1007bd558:     	mov	w12, #0x2710            ; =10000
1007bd55c:     	mov	w13, #0x147b            ; =5243
1007bd560:     	mov	w14, #0x64              ; =100
1007bd564:     	add	x15, sp, #0x8
1007bd568:     	mov	w16, #0x967f            ; =38527
1007bd56c:     	movk	w16, #0x98, lsl #16
1007bd570:     	mov	x10, x19
1007bd574:     	mov	x17, x10
1007bd578:     	umull	x10, w10, w11
1007bd57c:     	lsr	x10, x10, #45
1007bd580:     	msub	w0, w10, w12, w17
1007bd584:     	ubfx	w1, w0, #2, #14
1007bd588:     	mul	w1, w1, w13
1007bd58c:     	lsr	w1, w1, #17
1007bd590:     	msub	w0, w1, w14, w0
1007bd594:     	add	x2, x15, x9
1007bd598:     	ldrh	w1, [x8, w1, uxtw #1]
1007bd59c:     	strh	w1, [x2, #0x6]
1007bd5a0:     	and	x0, x0, #0xffff
1007bd5a4:     	ldrh	w0, [x8, x0, lsl #1]
1007bd5a8:     	strh	w0, [x2, #0x8]
1007bd5ac:     	sub	x9, x9, #0x4
1007bd5b0:     	cmp	w17, w16
1007bd5b4:     	b.hi	0x1007bd574 <_js_array_get_f64+0x764>
1007bd5b8:     	add	x9, x9, #0xa
1007bd5bc:     	b	0x1007bd5c8 <_js_array_get_f64+0x7b8>
1007bd5c0:     	mov	w9, #0xa                ; =10
1007bd5c4:     	mov	x10, x19
1007bd5c8:     	cmp	w10, #0x9
1007bd5cc:     	b.ls	0x1007bd600 <_js_array_get_f64+0x7f0>
1007bd5d0:     	sub	x9, x9, #0x2
1007bd5d4:     	ubfx	w11, w10, #2, #14
1007bd5d8:     	mov	w12, #0x147b            ; =5243
1007bd5dc:     	mul	w11, w11, w12
1007bd5e0:     	lsr	w11, w11, #17
1007bd5e4:     	mov	w12, #0x64              ; =100
1007bd5e8:     	msub	w10, w11, w12, w10
1007bd5ec:     	and	x10, x10, #0xffff
1007bd5f0:     	ldrh	w10, [x8, x10, lsl #1]
1007bd5f4:     	add	x12, sp, #0x8
1007bd5f8:     	strh	w10, [x12, x9]
1007bd5fc:     	mov	x10, x11
1007bd600:     	cbz	w19, 0x1007bd638 <_js_array_get_f64+0x828>
1007bd604:     	cbnz	w10, 0x1007bd638 <_js_array_get_f64+0x828>
1007bd608:     	cmp	x9, #0xa
1007bd60c:     	b.ne	0x1007bd660 <_js_array_get_f64+0x850>
1007bd610:     	mov	w23, #0x1               ; =1
1007bd614:     	add	x0, sp, #0x8
1007bd618:     	mov	x1, x21
1007bd61c:     	mov	w2, #0x1                ; =1
1007bd620:     	mov	x3, #0x0                ; =0
1007bd624:     	bl	0x1005b0fbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bd628:     	ldr	x8, [sp, #0x8]
1007bd62c:     	mov	w20, #0x1               ; =1
1007bd630:     	cbnz	x8, 0x1007bd6b0 <_js_array_get_f64+0x8a0>
1007bd634:     	b	0x1007bd6e8 <_js_array_get_f64+0x8d8>
1007bd638:     	sub	x23, x9, #0x1
1007bd63c:     	ubfiz	w10, w10, #1, #4
1007bd640:     	add	x8, x8, x10
1007bd644:     	ldrb	w8, [x8, #0x1]
1007bd648:     	add	x10, sp, #0x8
1007bd64c:     	strb	w8, [x10, x23]
1007bd650:     	mov	w8, #0xb                ; =11
1007bd654:     	b	0x1007bd668 <_js_array_get_f64+0x858>
1007bd658:     	add	x9, x8, #0x90
1007bd65c:     	b	0x1007bd744 <_js_array_get_f64+0x934>
1007bd660:     	mov	w8, #0xa                ; =10
1007bd664:     	mov	x23, x9
1007bd668:     	sub	x22, x8, x9
1007bd66c:     	mov	x0, x22
1007bd670:     	mov	w1, #0x1                ; =1
1007bd674:     	bl	0x100b5e708 <_mi_malloc_aligned>
1007bd678:     	cbz	x0, 0x1007bd824 <_js_array_get_f64+0xa14>
1007bd67c:     	mov	x20, x0
1007bd680:     	add	x8, sp, #0x8
1007bd684:     	add	x1, x8, x23
1007bd688:     	mov	x2, x22
1007bd68c:     	bl	0x100b6132c <_writev+0x100b6132c>
1007bd690:     	add	x0, sp, #0x8
1007bd694:     	mov	x1, x21
1007bd698:     	mov	x2, x20
1007bd69c:     	mov	x3, x22
1007bd6a0:     	bl	0x1005b0fbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bd6a4:     	ldr	w8, [sp, #0x8]
1007bd6a8:     	tbz	w8, #0x0, 0x1007bd6e0 <_js_array_get_f64+0x8d0>
1007bd6ac:     	mov	w23, #0x0               ; =0
1007bd6b0:     	mov	x22, #0x1               ; =1
1007bd6b4:     	movk	x22, #0x7ffc, lsl #48
1007bd6b8:     	ldr	x0, [sp, #0x10]
1007bd6bc:     	cbz	x0, 0x1007bd774 <_js_array_get_f64+0x964>
1007bd6c0:     	cbz	x21, 0x1007bd764 <_js_array_get_f64+0x954>
1007bd6c4:     	lsr	x8, x21, #52
1007bd6c8:     	cmp	x8, #0x7fe
1007bd6cc:     	b.hi	0x1007bd768 <_js_array_get_f64+0x958>
1007bd6d0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007bd6d4:     	bfxil	x8, x21, #0, #48
1007bd6d8:     	mov	x21, x8
1007bd6dc:     	b	0x1007bd768 <_js_array_get_f64+0x958>
1007bd6e0:     	mov	x0, x20
1007bd6e4:     	bl	0x100b5e480 <_mi_free>
1007bd6e8:     	ldr	w8, [x21]
1007bd6ec:     	cmp	w19, w8
1007bd6f0:     	b.hs	0x1007bd730 <_js_array_get_f64+0x920>
1007bd6f4:     	ldr	w8, [x21, #0x4]
1007bd6f8:     	cmp	w19, w8
1007bd6fc:     	b.hs	0x1007bd720 <_js_array_get_f64+0x910>
1007bd700:     	add	x8, x21, w19, uxtw #3
1007bd704:     	ldr	x22, [x8, #0x8]
1007bd708:     	mov	x8, #0x1                ; =1
1007bd70c:     	movk	x8, #0x7ffc, lsl #48
1007bd710:     	add	x8, x8, #0xf
1007bd714:     	cmp	x22, x8
1007bd718:     	b.ne	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bd71c:     	b	0x1007bd730 <_js_array_get_f64+0x920>
1007bd720:     	mov	x0, x21
1007bd724:     	mov	x1, x19
1007bd728:     	bl	0x1005290c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007bd72c:     	tbnz	w0, #0x0, 0x1007bd504 <_js_array_get_f64+0x6f4>
1007bd730:     	mov	x0, x21
1007bd734:     	mov	x1, x19
1007bd738:     	bl	0x1006c6268 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007bd73c:     	b	0x1007bd504 <_js_array_get_f64+0x6f4>
1007bd740:     	add	x9, x8, #0xc0
1007bd744:     	ldr	x10, [x8, #0x30]
1007bd748:     	add	x10, x10, #0x1
1007bd74c:     	str	x10, [x8, #0x30]
1007bd750:     	add	x8, x9, #0x19
1007bd754:     	ldrb	w8, [x8]
1007bd758:     	cmp	w8, #0xff
1007bd75c:     	b.ne	0x1007bd228 <_js_array_get_f64+0x418>
1007bd760:     	b	0x1007bd21c <_js_array_get_f64+0x40c>
1007bd764:     	add	x21, x22, #0x1
1007bd768:     	fmov	d0, x21
1007bd76c:     	bl	0x1006fc07c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007bd770:     	mov	x22, x0
1007bd774:     	tbnz	w23, #0x0, 0x1007bd508 <_js_array_get_f64+0x6f8>
1007bd778:     	mov	x0, x20
1007bd77c:     	bl	0x100b5e480 <_mi_free>
1007bd780:     	b	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bd784:     	ldr	x20, [sp, #0x10]
1007bd788:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bd78c:     	ldr	x8, [x8, #0xed8]
1007bd790:     	cbz	x8, 0x1007bd7a8 <_js_array_get_f64+0x998>
1007bd794:     	mov	x0, x20
1007bd798:     	bl	0x10013cd40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007bd79c:     	tbz	w0, #0x0, 0x1007bd7a8 <_js_array_get_f64+0x998>
1007bd7a0:     	mov	x0, x20
1007bd7a4:     	bl	0x1002bd700 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007bd7a8:     	tbnz	w19, #0x1f, 0x1007bd7c8 <_js_array_get_f64+0x9b8>
1007bd7ac:     	ldr	w8, [x20]
1007bd7b0:     	cmp	w19, w8
1007bd7b4:     	b.hs	0x1007bd7c8 <_js_array_get_f64+0x9b8>
1007bd7b8:     	mov	w1, w19
1007bd7bc:     	mov	x0, x20
1007bd7c0:     	bl	0x1002a398c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007bd7c4:     	b	0x1007bd504 <_js_array_get_f64+0x6f4>
1007bd7c8:     	mov	x8, #0x1                ; =1
1007bd7cc:     	movk	x8, #0x7ffc, lsl #48
1007bd7d0:     	mov	x22, x8
1007bd7d4:     	b	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bd7d8:     	mov	x0, x22
1007bd7dc:     	bl	0x100b46df0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007bd7e0:     	cmp	x0, #0x1
1007bd7e4:     	b.ne	0x1007bce50 <_js_array_get_f64+0x40>
1007bd7e8:     	mov	x0, x19
1007bd7ec:     	bl	0x100b46e10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007bd7f0:     	b	0x1007bd504 <_js_array_get_f64+0x6f4>
1007bd7f4:     	mov	x0, x20
1007bd7f8:     	mov	w1, #0x0                ; =0
1007bd7fc:     	bl	0x100b49380 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bd800:     	mov	x20, x0
1007bd804:     	cbnz	x0, 0x1007bcf2c <_js_array_get_f64+0x11c>
1007bd808:     	b	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bd80c:     	mov	x0, x20
1007bd810:     	mov	w1, #0x1                ; =1
1007bd814:     	bl	0x100b49380 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bd818:     	mov	x20, x0
1007bd81c:     	cbnz	x0, 0x1007bd0d0 <_js_array_get_f64+0x2c0>
1007bd820:     	b	0x1007bd508 <_js_array_get_f64+0x6f8>
1007bd824:     	mov	w0, #0x1                ; =1
1007bd828:     	mov	x1, x22
1007bd82c:     	bl	0x100b11800 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
