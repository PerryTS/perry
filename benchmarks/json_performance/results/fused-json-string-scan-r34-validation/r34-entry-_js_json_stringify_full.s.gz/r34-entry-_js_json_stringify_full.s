
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/fused-json-string-scan-r34/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100844a00 <_js_json_stringify_full>:
100844a00:     	sub	sp, sp, #0x120
100844a04:     	stp	d9, d8, [sp, #0xb0]
100844a08:     	stp	x28, x27, [sp, #0xc0]
100844a0c:     	stp	x26, x25, [sp, #0xd0]
100844a10:     	stp	x24, x23, [sp, #0xe0]
100844a14:     	stp	x22, x21, [sp, #0xf0]
100844a18:     	stp	x20, x19, [sp, #0x100]
100844a1c:     	stp	x29, x30, [sp, #0x110]
100844a20:     	add	x29, sp, #0x110
100844a24:     	mov.16b	v9, v2
100844a28:     	mov.16b	v8, v0
100844a2c:     	fmov	x19, d8
100844a30:     	fmov	x21, d1
100844a34:     	fmov	x23, d9
100844a38:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100844a3c:     	add	x27, x21, x8
100844a40:     	add	x24, x23, x8
100844a44:     	fcmp	d2, #0.0
100844a48:     	ccmp	x24, #0x2, #0x0, ne
100844a4c:     	b.hi	0x100844a5c <_js_json_stringify_full+0x5c>
100844a50:     	cmp	x27, #0x2
100844a54:     	b.lo	0x100844a6c <_js_json_stringify_full+0x6c>
100844a58:     	b	0x100844fd8 <_js_json_stringify_full+0x5d8>
100844a5c:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
100844a60:     	cmp	x23, x8
100844a64:     	ccmp	x27, #0x2, #0x2, eq
100844a68:     	b.hs	0x100844fd8 <_js_json_stringify_full+0x5d8>
100844a6c:     	mov	x8, #-0x2               ; =-2
100844a70:     	movk	x8, #0x8003, lsl #48
100844a74:     	add	x8, x19, x8
100844a78:     	cmp	x8, #0x3
100844a7c:     	b.hs	0x100844a90 <_js_json_stringify_full+0x90>
100844a80:     	adrp	x9, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4970>
100844a84:     	add	x9, x9, #0xc18
100844a88:     	ldr	x20, [x9, x8, lsl #3]
100844a8c:     	b	0x100845ea8 <_js_json_stringify_full+0x14a8>
100844a90:     	strb	wzr, [sp, #0x4c]
100844a94:     	str	wzr, [sp, #0x48]
100844a98:     	and	x8, x19, #0xffff000000000000
100844a9c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100844aa0:     	cmp	x8, x9
100844aa4:     	b.eq	0x100844b18 <_js_json_stringify_full+0x118>
100844aa8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100844aac:     	cmp	x8, x9
100844ab0:     	b.ne	0x100844f14 <_js_json_stringify_full+0x514>
100844ab4:     	ubfx	x10, x19, #40, #8
100844ab8:     	cbz	x10, 0x100844b08 <_js_json_stringify_full+0x108>
100844abc:     	strb	w19, [sp, #0x48]
100844ac0:     	cmp	x10, #0x1
100844ac4:     	b.eq	0x100844b08 <_js_json_stringify_full+0x108>
100844ac8:     	lsr	x9, x19, #8
100844acc:     	strb	w9, [sp, #0x49]
100844ad0:     	cmp	x10, #0x2
100844ad4:     	b.eq	0x100844b08 <_js_json_stringify_full+0x108>
100844ad8:     	lsr	x9, x19, #16
100844adc:     	strb	w9, [sp, #0x4a]
100844ae0:     	cmp	x10, #0x3
100844ae4:     	b.eq	0x100844b08 <_js_json_stringify_full+0x108>
100844ae8:     	lsr	x9, x19, #24
100844aec:     	strb	w9, [sp, #0x4b]
100844af0:     	cmp	x10, #0x4
100844af4:     	b.eq	0x100844b08 <_js_json_stringify_full+0x108>
100844af8:     	lsr	x9, x19, #32
100844afc:     	strb	w9, [sp, #0x4c]
100844b00:     	cmp	x10, #0x5
100844b04:     	b.ne	0x10084667c <_js_json_stringify_full+0x1c7c>
100844b08:     	add	x11, sp, #0x48
100844b0c:     	cmp	w10, #0x3
100844b10:     	b.ls	0x100844b30 <_js_json_stringify_full+0x130>
100844b14:     	b	0x100844f14 <_js_json_stringify_full+0x514>
100844b18:     	ands	x9, x19, #0xffffffffffff
100844b1c:     	b.eq	0x100844fd8 <_js_json_stringify_full+0x5d8>
100844b20:     	add	x11, x9, #0x14
100844b24:     	ldr	w10, [x9, #0x4]
100844b28:     	cmp	w10, #0x3
100844b2c:     	b.hi	0x100844f14 <_js_json_stringify_full+0x514>
100844b30:     	stur	wzr, [sp, #0x81]
100844b34:     	mov	w9, #0x22               ; =34
100844b38:     	strb	w9, [sp, #0x80]
100844b3c:     	cbz	w10, 0x100844b74 <_js_json_stringify_full+0x174>
100844b40:     	add	x12, sp, #0x80
100844b44:     	ldrb	w13, [x11]
100844b48:     	sxtb	w15, w13
100844b4c:     	cmp	w13, #0xb
100844b50:     	b.le	0x100844b7c <_js_json_stringify_full+0x17c>
100844b54:     	cmp	w13, #0x21
100844b58:     	b.gt	0x100844b9c <_js_json_stringify_full+0x19c>
100844b5c:     	cmp	w13, #0xc
100844b60:     	b.eq	0x100844bd0 <_js_json_stringify_full+0x1d0>
100844b64:     	cmp	w13, #0xd
100844b68:     	b.ne	0x100844bac <_js_json_stringify_full+0x1ac>
100844b6c:     	mov	w15, #0x72              ; =114
100844b70:     	b	0x100844bdc <_js_json_stringify_full+0x1dc>
100844b74:     	mov	w12, #0x1               ; =1
100844b78:     	b	0x100844c04 <_js_json_stringify_full+0x204>
100844b7c:     	cmp	w13, #0x8
100844b80:     	b.eq	0x100844bc8 <_js_json_stringify_full+0x1c8>
100844b84:     	cmp	w13, #0x9
100844b88:     	b.eq	0x100844bd8 <_js_json_stringify_full+0x1d8>
100844b8c:     	cmp	w13, #0xa
100844b90:     	b.ne	0x100844bac <_js_json_stringify_full+0x1ac>
100844b94:     	mov	w15, #0x6e              ; =110
100844b98:     	b	0x100844bdc <_js_json_stringify_full+0x1dc>
100844b9c:     	cmp	w13, #0x22
100844ba0:     	b.eq	0x100844bdc <_js_json_stringify_full+0x1dc>
100844ba4:     	cmp	w13, #0x5c
100844ba8:     	b.eq	0x100844bdc <_js_json_stringify_full+0x1dc>
100844bac:     	cmp	w15, #0x20
100844bb0:     	b.lt	0x100844f14 <_js_json_stringify_full+0x514>
100844bb4:     	mov	w14, #0x0               ; =0
100844bb8:     	add	x13, x12, #0x2
100844bbc:     	mov	w12, #0x2               ; =2
100844bc0:     	mov	w16, #0x1               ; =1
100844bc4:     	b	0x100844bf4 <_js_json_stringify_full+0x1f4>
100844bc8:     	mov	w15, #0x62              ; =98
100844bcc:     	b	0x100844bdc <_js_json_stringify_full+0x1dc>
100844bd0:     	mov	w15, #0x66              ; =102
100844bd4:     	b	0x100844bdc <_js_json_stringify_full+0x1dc>
100844bd8:     	mov	w15, #0x74              ; =116
100844bdc:     	add	x13, x12, #0x3
100844be0:     	mov	w12, #0x5c              ; =92
100844be4:     	strb	w12, [sp, #0x81]
100844be8:     	mov	w14, #0x1               ; =1
100844bec:     	mov	w12, #0x3               ; =3
100844bf0:     	mov	w16, #0x2               ; =2
100844bf4:     	add	x17, sp, #0x80
100844bf8:     	strb	w15, [x17, x16]
100844bfc:     	cmp	w10, #0x1
100844c00:     	b.ne	0x100844c3c <_js_json_stringify_full+0x23c>
100844c04:     	add	x10, sp, #0x80
100844c08:     	strb	w9, [x10, x12]
100844c0c:     	add	x8, x12, #0x1
100844c10:     	cmp	x12, #0x3
100844c14:     	b.hs	0x100844c28 <_js_json_stringify_full+0x228>
100844c18:     	mov	x13, #0x0               ; =0
100844c1c:     	mov	x11, #0x0               ; =0
100844c20:     	add	x9, sp, #0x80
100844c24:     	b	0x100844e84 <_js_json_stringify_full+0x484>
100844c28:     	cmp	x12, #0xf
100844c2c:     	b.hs	0x100844c6c <_js_json_stringify_full+0x26c>
100844c30:     	mov	x11, #0x0               ; =0
100844c34:     	mov	x13, #0x0               ; =0
100844c38:     	b	0x100844de0 <_js_json_stringify_full+0x3e0>
100844c3c:     	ldrb	w16, [x11, #0x1]
100844c40:     	sxtb	w15, w16
100844c44:     	cmp	w16, #0xb
100844c48:     	b.le	0x100844eb4 <_js_json_stringify_full+0x4b4>
100844c4c:     	cmp	w16, #0x21
100844c50:     	b.gt	0x100844ed4 <_js_json_stringify_full+0x4d4>
100844c54:     	cmp	w16, #0xc
100844c58:     	b.eq	0x100844f04 <_js_json_stringify_full+0x504>
100844c5c:     	cmp	w16, #0xd
100844c60:     	b.ne	0x100844ee4 <_js_json_stringify_full+0x4e4>
100844c64:     	mov	w15, #0x72              ; =114
100844c68:     	b	0x100844f10 <_js_json_stringify_full+0x510>
100844c6c:     	and	x12, x8, #0xc
100844c70:     	and	x11, x8, #0x10
100844c74:     	add	x13, sp, #0x80
100844c78:     	add	x9, x13, x11
100844c7c:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5970>
100844c80:     	ldr	q0, [x14, #0xd90]
100844c84:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5970>
100844c88:     	ldr	q1, [x14, #0xda0]
100844c8c:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5970>
100844c90:     	ldr	q2, [x14, #0xdb0]
100844c94:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5970>
100844c98:     	ldr	q3, [x14, #0xdc0]
100844c9c:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5970>
100844ca0:     	ldr	q4, [x14, #0xdd0]
100844ca4:     	movi.2d	v5, #0000000000000000
100844ca8:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5970>
100844cac:     	ldr	q6, [x14, #0xde0]
100844cb0:     	adrp	x14, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4970>
100844cb4:     	ldr	q7, [x14, #0xf00]
100844cb8:     	mov	w14, #0x10              ; =16
100844cbc:     	movi.2d	v16, #0000000000000000
100844cc0:     	dup.2d	v17, x14
100844cc4:     	adrp	x14, 0x100c38000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3317a>
100844cc8:     	ldr	q19, [x14, #0xe00]
100844ccc:     	and	x14, x8, #0x10
100844cd0:     	movi.2d	v20, #0000000000000000
100844cd4:     	movi.2d	v18, #0000000000000000
100844cd8:     	movi.2d	v23, #0000000000000000
100844cdc:     	movi.2d	v21, #0000000000000000
100844ce0:     	movi.2d	v24, #0000000000000000
100844ce4:     	movi.2d	v22, #0000000000000000
100844ce8:     	ldr	q25, [x13], #0x10
100844cec:     	ushll.8h	v26, v25, #0x0
100844cf0:     	ushll2.4s	v27, v26, #0x0
100844cf4:     	ushll2.2d	v28, v27, #0x0
100844cf8:     	ushll2.8h	v25, v25, #0x0
100844cfc:     	ushll.4s	v29, v25, #0x0
100844d00:     	ushll2.2d	v30, v29, #0x0
100844d04:     	ushll.2d	v29, v29, #0x0
100844d08:     	ushll.2d	v27, v27, #0x0
100844d0c:     	ushll.4s	v26, v26, #0x0
100844d10:     	ushll2.2d	v31, v26, #0x0
100844d14:     	ushll2.4s	v25, v25, #0x0
100844d18:     	ushll.2d	v8, v25, #0x0
100844d1c:     	ushll.2d	v26, v26, #0x0
100844d20:     	ushll2.2d	v25, v25, #0x0
100844d24:     	shl.2d	v9, v0, #0x3
100844d28:     	ushl.2d	v25, v25, v9
100844d2c:     	shl.2d	v9, v19, #0x3
100844d30:     	ushl.2d	v26, v26, v9
100844d34:     	shl.2d	v9, v1, #0x3
100844d38:     	ushl.2d	v8, v8, v9
100844d3c:     	shl.2d	v9, v7, #0x3
100844d40:     	ushl.2d	v31, v31, v9
100844d44:     	shl.2d	v9, v6, #0x3
100844d48:     	ushl.2d	v27, v27, v9
100844d4c:     	shl.2d	v9, v3, #0x3
100844d50:     	ushl.2d	v29, v29, v9
100844d54:     	shl.2d	v9, v2, #0x3
100844d58:     	ushl.2d	v30, v30, v9
100844d5c:     	shl.2d	v9, v4, #0x3
100844d60:     	ushl.2d	v28, v28, v9
100844d64:     	orr.16b	v18, v28, v18
100844d68:     	orr.16b	v21, v30, v21
100844d6c:     	orr.16b	v23, v29, v23
100844d70:     	orr.16b	v20, v27, v20
100844d74:     	orr.16b	v5, v31, v5
100844d78:     	orr.16b	v24, v8, v24
100844d7c:     	orr.16b	v16, v26, v16
100844d80:     	orr.16b	v22, v25, v22
100844d84:     	add.2d	v6, v6, v17
100844d88:     	add.2d	v7, v7, v17
100844d8c:     	add.2d	v19, v19, v17
100844d90:     	add.2d	v4, v4, v17
100844d94:     	add.2d	v3, v3, v17
100844d98:     	add.2d	v2, v2, v17
100844d9c:     	add.2d	v1, v1, v17
100844da0:     	add.2d	v0, v0, v17
100844da4:     	subs	x14, x14, #0x10
100844da8:     	b.ne	0x100844ce8 <_js_json_stringify_full+0x2e8>
100844dac:     	orr.16b	v0, v16, v23
100844db0:     	orr.16b	v1, v20, v24
100844db4:     	orr.16b	v0, v0, v1
100844db8:     	orr.16b	v1, v5, v21
100844dbc:     	orr.16b	v2, v18, v22
100844dc0:     	orr.16b	v1, v1, v2
100844dc4:     	orr.16b	v0, v0, v1
100844dc8:     	mov	d1, v0[1]
100844dcc:     	orr.8b	v0, v0, v1
100844dd0:     	fmov	x13, d0
100844dd4:     	cmp	x8, x11
100844dd8:     	b.eq	0x100844ea4 <_js_json_stringify_full+0x4a4>
100844ddc:     	cbz	x12, 0x100844e84 <_js_json_stringify_full+0x484>
100844de0:     	mov	x14, x11
100844de4:     	and	x11, x8, #0x1c
100844de8:     	add	x15, sp, #0x80
100844dec:     	add	x9, x15, x11
100844df0:     	fmov	d0, x13
100844df4:     	movi.2d	v1, #0000000000000000
100844df8:     	dup.2d	v3, x14
100844dfc:     	adrp	x12, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4970>
100844e00:     	ldr	q2, [x12, #0xf00]
100844e04:     	orr.16b	v2, v3, v2
100844e08:     	adrp	x12, 0x100c38000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3317a>
100844e0c:     	ldr	q4, [x12, #0xe00]
100844e10:     	orr.16b	v3, v3, v4
100844e14:     	sub	x12, x14, x11
100844e18:     	add	x13, x15, x14
100844e1c:     	movi.2d	v4, #0x000000000000ff
100844e20:     	mov	w14, #0x4               ; =4
100844e24:     	dup.2d	v5, x14
100844e28:     	ldr	s6, [x13], #0x4
100844e2c:     	ushll.8h	v6, v6, #0x0
100844e30:     	ushll.4s	v6, v6, #0x0
100844e34:     	ushll2.2d	v7, v6, #0x0
100844e38:     	and.16b	v7, v7, v4
100844e3c:     	ushll.2d	v6, v6, #0x0
100844e40:     	and.16b	v6, v6, v4
100844e44:     	shl.2d	v16, v2, #0x3
100844e48:     	shl.2d	v17, v3, #0x3
100844e4c:     	ushl.2d	v6, v6, v17
100844e50:     	ushl.2d	v7, v7, v16
100844e54:     	orr.16b	v1, v7, v1
100844e58:     	orr.16b	v0, v6, v0
100844e5c:     	add.2d	v2, v2, v5
100844e60:     	add.2d	v3, v3, v5
100844e64:     	adds	x12, x12, #0x4
100844e68:     	b.ne	0x100844e28 <_js_json_stringify_full+0x428>
100844e6c:     	orr.16b	v0, v0, v1
100844e70:     	mov	d1, v0[1]
100844e74:     	orr.8b	v0, v0, v1
100844e78:     	fmov	x13, d0
100844e7c:     	cmp	x8, x11
100844e80:     	b.eq	0x100844ea4 <_js_json_stringify_full+0x4a4>
100844e84:     	add	x10, x10, x8
100844e88:     	lsl	x11, x11, #3
100844e8c:     	ldrb	w12, [x9], #0x1
100844e90:     	lsl	x12, x12, x11
100844e94:     	orr	x13, x12, x13
100844e98:     	add	x11, x11, #0x8
100844e9c:     	cmp	x9, x10
100844ea0:     	b.ne	0x100844e8c <_js_json_stringify_full+0x48c>
100844ea4:     	orr	x8, x13, x8, lsl #40
100844ea8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100844eac:     	orr	x20, x8, x9
100844eb0:     	b	0x100845ea8 <_js_json_stringify_full+0x14a8>
100844eb4:     	cmp	w16, #0x8
100844eb8:     	b.eq	0x100844efc <_js_json_stringify_full+0x4fc>
100844ebc:     	cmp	w16, #0x9
100844ec0:     	b.eq	0x100844f0c <_js_json_stringify_full+0x50c>
100844ec4:     	cmp	w16, #0xa
100844ec8:     	b.ne	0x100844ee4 <_js_json_stringify_full+0x4e4>
100844ecc:     	mov	w15, #0x6e              ; =110
100844ed0:     	b	0x100844f10 <_js_json_stringify_full+0x510>
100844ed4:     	cmp	w16, #0x22
100844ed8:     	b.eq	0x100844f10 <_js_json_stringify_full+0x510>
100844edc:     	cmp	w16, #0x5c
100844ee0:     	b.eq	0x100844f10 <_js_json_stringify_full+0x510>
100844ee4:     	cmp	w15, #0x20
100844ee8:     	b.lt	0x100844f14 <_js_json_stringify_full+0x514>
100844eec:     	add	x13, sp, #0x80
100844ef0:     	strb	w15, [x13, x12]
100844ef4:     	add	x12, x12, #0x1
100844ef8:     	b	0x10084549c <_js_json_stringify_full+0xa9c>
100844efc:     	mov	w15, #0x62              ; =98
100844f00:     	b	0x100844f10 <_js_json_stringify_full+0x510>
100844f04:     	mov	w15, #0x66              ; =102
100844f08:     	b	0x100844f10 <_js_json_stringify_full+0x510>
100844f0c:     	mov	w15, #0x74              ; =116
100844f10:     	tbz	w14, #0x0, 0x100845488 <_js_json_stringify_full+0xa88>
100844f14:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100844f18:     	cmp	x8, x9
100844f1c:     	b.eq	0x100844f64 <_js_json_stringify_full+0x564>
100844f20:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100844f24:     	cmp	x8, x9
100844f28:     	b.ne	0x100844fd8 <_js_json_stringify_full+0x5d8>
100844f2c:     	and	x8, x19, #0xffffffffffff
100844f30:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
100844f34:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100844f38:     	movk	x10, #0xffef, lsl #16
100844f3c:     	cmp	x9, x10
100844f40:     	b.hi	0x100844fd8 <_js_json_stringify_full+0x5d8>
100844f44:     	ldr	w8, [x8, #0x4]
100844f48:     	cmp	w8, #0x40
100844f4c:     	b.lo	0x100844fd8 <_js_json_stringify_full+0x5d8>
100844f50:     	and	x0, x19, #0xffffffffffff
100844f54:     	bl	0x1004f1528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100844f58:     	cmp	x0, #0x1
100844f5c:     	b.ne	0x100844fd8 <_js_json_stringify_full+0x5d8>
100844f60:     	b	0x100845124 <_js_json_stringify_full+0x724>
100844f64:     	and	x25, x19, #0xffffffffffff
100844f68:     	and	x0, x19, #0xffffffffffff
100844f6c:     	bl	0x100579080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100844f70:     	cbz	x0, 0x100844fa4 <_js_json_stringify_full+0x5a4>
100844f74:     	ldrb	w8, [x0]
100844f78:     	cmp	w8, #0x2
100844f7c:     	b.ne	0x100844fa4 <_js_json_stringify_full+0x5a4>
100844f80:     	ldrsb	w8, [x0, #0x1]
100844f84:     	tbnz	w8, #0x1f, 0x100844fa4 <_js_json_stringify_full+0x5a4>
100844f88:     	ldrh	w8, [x0, #0x2]
100844f8c:     	tbnz	w8, #0xb, 0x100844fa4 <_js_json_stringify_full+0x5a4>
100844f90:     	ldr	w8, [x0, #0x4]
100844f94:     	cmp	w8, #0x18
100844f98:     	b.lo	0x100844fa4 <_js_json_stringify_full+0x5a4>
100844f9c:     	ldr	w8, [x25]
100844fa0:     	cbz	w8, 0x100845ffc <_js_json_stringify_full+0x15fc>
100844fa4:     	and	x0, x19, #0xffffffffffff
100844fa8:     	bl	0x100579080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100844fac:     	cbz	x0, 0x100844fd8 <_js_json_stringify_full+0x5d8>
100844fb0:     	ldrb	w8, [x0]
100844fb4:     	cmp	w8, #0x2
100844fb8:     	b.ne	0x100844fd8 <_js_json_stringify_full+0x5d8>
100844fbc:     	ldrh	w8, [x0, #0x2]
100844fc0:     	tbnz	w8, #0xb, 0x100844fd8 <_js_json_stringify_full+0x5d8>
100844fc4:     	ldr	w8, [x0, #0x4]
100844fc8:     	cmp	w8, #0x18
100844fcc:     	b.lo	0x100844fd8 <_js_json_stringify_full+0x5d8>
100844fd0:     	ldr	w8, [x25]
100844fd4:     	cbz	w8, 0x100845fa0 <_js_json_stringify_full+0x15a0>
100844fd8:     	mov	x20, #0x1               ; =1
100844fdc:     	movk	x20, #0x7ffc, lsl #48
100844fe0:     	cmp	x19, x20
100844fe4:     	b.eq	0x100845ea8 <_js_json_stringify_full+0x14a8>
100844fe8:     	and	x22, x19, #0xffff000000000000
100844fec:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100844ff0:     	cmp	x22, x8
100844ff4:     	b.ne	0x10084502c <_js_json_stringify_full+0x62c>
100844ff8:     	and	x8, x19, #0xffffffffffff
100844ffc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100845000:     	b.lo	0x100845018 <_js_json_stringify_full+0x618>
100845004:     	ldr	w8, [x8, #0xc]
100845008:     	mov	w9, #0x4f53             ; =20307
10084500c:     	movk	w9, #0x434c, lsl #16
100845010:     	cmp	w8, w9
100845014:     	b.eq	0x100845ea8 <_js_json_stringify_full+0x14a8>
100845018:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084501c:     	cmp	x22, x8
100845020:     	b.ne	0x100845058 <_js_json_stringify_full+0x658>
100845024:     	and	x0, x19, #0xffffffffffff
100845028:     	b	0x100845080 <_js_json_stringify_full+0x680>
10084502c:     	lsr	x8, x19, #52
100845030:     	cbnz	x8, 0x100845108 <_js_json_stringify_full+0x708>
100845034:     	and	x8, x19, #0x7
100845038:     	cbz	x19, 0x100845064 <_js_json_stringify_full+0x664>
10084503c:     	cbnz	x8, 0x100845064 <_js_json_stringify_full+0x664>
100845040:     	mov	x0, x19
100845044:     	bl	0x10050d7f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100845048:     	mov	x8, x19
10084504c:     	tbnz	w0, #0x0, 0x100844ffc <_js_json_stringify_full+0x5fc>
100845050:     	mov	x8, #0x0                ; =0
100845054:     	b	0x100845064 <_js_json_stringify_full+0x664>
100845058:     	lsr	x8, x19, #52
10084505c:     	cbnz	x8, 0x100845108 <_js_json_stringify_full+0x708>
100845060:     	and	x8, x19, #0x7
100845064:     	cbz	x19, 0x100845108 <_js_json_stringify_full+0x708>
100845068:     	cbnz	x8, 0x100845108 <_js_json_stringify_full+0x708>
10084506c:     	mov	x0, x19
100845070:     	bl	0x10050d7f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100845074:     	mov	x8, x0
100845078:     	mov	x0, x19
10084507c:     	tbz	w8, #0x0, 0x100845108 <_js_json_stringify_full+0x708>
100845080:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100845084:     	b.lo	0x100845108 <_js_json_stringify_full+0x708>
100845088:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084508c:     	add	x8, x8, #0xfb0
100845090:     	ldaprb	w8, [x8]
100845094:     	cbz	w8, 0x100845108 <_js_json_stringify_full+0x708>
100845098:     	lsr	x8, x0, #3
10084509c:     	mov	x9, #0x7c15             ; =31765
1008450a0:     	movk	x9, #0x7f4a, lsl #16
1008450a4:     	movk	x9, #0x79b9, lsl #32
1008450a8:     	movk	x9, #0x9e37, lsl #48
1008450ac:     	mul	x8, x8, x9
1008450b0:     	lsr	x10, x8, #54
1008450b4:     	lsr	x11, x8, #60
1008450b8:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1008450bc:     	add	x9, x9, #0xf30
1008450c0:     	add	x11, x9, x11, lsl #3
1008450c4:     	ldapr	x11, [x11]
1008450c8:     	lsr	x10, x11, x10
1008450cc:     	tbz	w10, #0x0, 0x100845108 <_js_json_stringify_full+0x708>
1008450d0:     	lsr	x10, x8, #44
1008450d4:     	ubfx	x11, x8, #50, #4
1008450d8:     	add	x11, x9, x11, lsl #3
1008450dc:     	ldapr	x11, [x11]
1008450e0:     	lsr	x10, x11, x10
1008450e4:     	tbz	w10, #0x0, 0x100845108 <_js_json_stringify_full+0x708>
1008450e8:     	lsr	x10, x8, #34
1008450ec:     	ubfx	x8, x8, #40, #4
1008450f0:     	add	x8, x9, x8, lsl #3
1008450f4:     	ldapr	x8, [x8]
1008450f8:     	lsr	x8, x8, x10
1008450fc:     	tbz	w8, #0x0, 0x100845108 <_js_json_stringify_full+0x708>
100845100:     	bl	0x10034b2ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
100845104:     	tbnz	w0, #0x0, 0x100845ea8 <_js_json_stringify_full+0x14a8>
100845108:     	cmp	x24, #0x3
10084510c:     	ccmp	x27, #0x2, #0x2, lo
100845110:     	b.hs	0x100845130 <_js_json_stringify_full+0x730>
100845114:     	mov.16b	v0, v8
100845118:     	bl	0x1004ec5fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084511c:     	cmp	x0, #0x1
100845120:     	b.ne	0x100845130 <_js_json_stringify_full+0x730>
100845124:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100845128:     	bfxil	x20, x1, #0, #48
10084512c:     	b	0x100845ea8 <_js_json_stringify_full+0x14a8>
100845130:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845134:     	cmp	x22, x8
100845138:     	b.ne	0x100845188 <_js_json_stringify_full+0x788>
10084513c:     	ands	x22, x19, #0xffffffffffff
100845140:     	b.eq	0x100845188 <_js_json_stringify_full+0x788>
100845144:     	mov	x0, x22
100845148:     	bl	0x10050d7f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084514c:     	cbz	w0, 0x100845188 <_js_json_stringify_full+0x788>
100845150:     	ldurb	w8, [x22, #-0x8]
100845154:     	cmp	w8, #0x9
100845158:     	b.ne	0x100845188 <_js_json_stringify_full+0x788>
10084515c:     	ldr	w8, [x22, #0x4]
100845160:     	mov	w9, #0x5841             ; =22593
100845164:     	movk	w9, #0x4c5a, lsl #16
100845168:     	cmp	w8, w9
10084516c:     	b.ne	0x100845188 <_js_json_stringify_full+0x788>
100845170:     	mov	x0, x22
100845174:     	bl	0x1006862a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100845178:     	cbz	x0, 0x100845188 <_js_json_stringify_full+0x788>
10084517c:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100845180:     	bfxil	x19, x0, #0, #48
100845184:     	fmov	d8, x19
100845188:     	mov	w8, #0x7ffd             ; =32765
10084518c:     	cmp	x8, x23, lsr #48
100845190:     	b.ne	0x1008451a4 <_js_json_stringify_full+0x7a4>
100845194:     	and	x1, x23, #0xffffffffffff
100845198:     	cmp	x1, #0x100, lsl #12     ; =0x100000
10084519c:     	b.hs	0x1008451b8 <_js_json_stringify_full+0x7b8>
1008451a0:     	b	0x10084520c <_js_json_stringify_full+0x80c>
1008451a4:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
1008451a8:     	mov	x9, #0xfffffff00000     ; =281474975662080
1008451ac:     	mov	x1, x23
1008451b0:     	cmp	x8, x9
1008451b4:     	b.hs	0x10084520c <_js_json_stringify_full+0x80c>
1008451b8:     	lsr	x8, x1, #47
1008451bc:     	cbnz	x8, 0x10084520c <_js_json_stringify_full+0x80c>
1008451c0:     	add	x0, sp, #0x80
1008451c4:     	bl	0x10076d0ac <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
1008451c8:     	ldr	w8, [sp, #0x80]
1008451cc:     	tbz	w8, #0x0, 0x10084520c <_js_json_stringify_full+0x80c>
1008451d0:     	ldr	w8, [sp, #0x88]
1008451d4:     	mov	w9, #-0xff30            ; =-65328
1008451d8:     	cmp	w8, w9
1008451dc:     	b.eq	0x100845200 <_js_json_stringify_full+0x800>
1008451e0:     	mov	w9, #-0xff2f            ; =-65327
1008451e4:     	cmp	w8, w9
1008451e8:     	b.ne	0x10084520c <_js_json_stringify_full+0x80c>
1008451ec:     	mov.16b	v0, v9
1008451f0:     	bl	0x1008472bc <_js_jsvalue_to_string>
1008451f4:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
1008451f8:     	bfxil	x23, x0, #0, #48
1008451fc:     	b	0x10084520c <_js_json_stringify_full+0x80c>
100845200:     	mov.16b	v0, v9
100845204:     	bl	0x10086e860 <_js_number_coerce>
100845208:     	fmov	x23, d0
10084520c:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100845210:     	add	x8, x23, x8
100845214:     	cmp	x8, #0x3
100845218:     	b.hs	0x100845230 <_js_json_stringify_full+0x830>
10084521c:     	mov	x22, #0x0               ; =0
100845220:     	mov	w8, #0x1                ; =1
100845224:     	stp	xzr, x8, [sp, #0x10]
100845228:     	str	xzr, [sp, #0x20]
10084522c:     	b	0x1008454e4 <_js_json_stringify_full+0xae4>
100845230:     	and	x8, x23, #0xffff000000000000
100845234:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845238:     	cmp	x8, x9
10084523c:     	b.eq	0x100845260 <_js_json_stringify_full+0x860>
100845240:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845244:     	cmp	x8, x9
100845248:     	b.ne	0x1008452ec <_js_json_stringify_full+0x8ec>
10084524c:     	and	x8, x23, #0xffffffffffff
100845250:     	cmp	x8, #0x1, lsl #12       ; =0x1000
100845254:     	b.hs	0x100845334 <_js_json_stringify_full+0x934>
100845258:     	mov	x9, #0x0                ; =0
10084525c:     	b	0x10084533c <_js_json_stringify_full+0x93c>
100845260:     	strb	wzr, [sp, #0x4c]
100845264:     	str	wzr, [sp, #0x48]
100845268:     	ubfx	x1, x23, #40, #8
10084526c:     	cbz	x1, 0x1008452bc <_js_json_stringify_full+0x8bc>
100845270:     	strb	w23, [sp, #0x48]
100845274:     	cmp	x1, #0x1
100845278:     	b.eq	0x1008452bc <_js_json_stringify_full+0x8bc>
10084527c:     	lsr	x8, x23, #8
100845280:     	strb	w8, [sp, #0x49]
100845284:     	cmp	x1, #0x2
100845288:     	b.eq	0x1008452bc <_js_json_stringify_full+0x8bc>
10084528c:     	lsr	x8, x23, #16
100845290:     	strb	w8, [sp, #0x4a]
100845294:     	cmp	x1, #0x3
100845298:     	b.eq	0x1008452bc <_js_json_stringify_full+0x8bc>
10084529c:     	lsr	x8, x23, #24
1008452a0:     	strb	w8, [sp, #0x4b]
1008452a4:     	cmp	x1, #0x4
1008452a8:     	b.eq	0x1008452bc <_js_json_stringify_full+0x8bc>
1008452ac:     	lsr	x8, x23, #32
1008452b0:     	strb	w8, [sp, #0x4c]
1008452b4:     	cmp	x1, #0x5
1008452b8:     	b.ne	0x10084667c <_js_json_stringify_full+0x1c7c>
1008452bc:     	add	x8, sp, #0x80
1008452c0:     	add	x0, sp, #0x48
1008452c4:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
1008452c8:     	ldr	w8, [sp, #0x80]
1008452cc:     	ldp	x9, x22, [sp, #0x88]
1008452d0:     	cmp	w8, #0x0
1008452d4:     	csinc	x23, x9, xzr, eq
1008452d8:     	csel	x25, xzr, x22, ne
1008452dc:     	tbz	x25, #0x3f, 0x10084541c <_js_json_stringify_full+0xa1c>
1008452e0:     	mov	x0, #0x0                ; =0
1008452e4:     	mov	x1, x22
1008452e8:     	bl	0x100b11800 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008452ec:     	add	x8, x20, #0x3
1008452f0:     	cmp	x23, x8
1008452f4:     	b.eq	0x10084521c <_js_json_stringify_full+0x81c>
1008452f8:     	fmov	d0, x23
1008452fc:     	fcvtzu	x8, d0
100845300:     	mov	w9, #0xa                ; =10
100845304:     	cmp	x8, #0xa
100845308:     	csel	x3, x8, x9, lo
10084530c:     	adrp	x1, 0x100c42000 <_PERRY_EMPTY_STRING+0x15b4>
100845310:     	add	x1, x1, #0xbdc
100845314:     	add	x0, sp, #0x80
100845318:     	mov	w2, #0x1                ; =1
10084531c:     	bl	0x10022dfb4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
100845320:     	ldr	x22, [sp, #0x90]
100845324:     	str	x22, [sp, #0x20]
100845328:     	ldr	q0, [sp, #0x80]
10084532c:     	str	q0, [sp, #0x10]
100845330:     	b	0x1008454e4 <_js_json_stringify_full+0xae4>
100845334:     	ldr	w22, [x8, #0x4]
100845338:     	add	x9, x8, #0x14
10084533c:     	mov	x14, #0x0               ; =0
100845340:     	mov	x8, #0x0                ; =0
100845344:     	cmp	x9, #0x0
100845348:     	csel	x24, xzr, x22, eq
10084534c:     	csinc	x23, x9, xzr, ne
100845350:     	add	x9, x23, x24
100845354:     	mov	w10, #0x1               ; =1
100845358:     	mov	x11, x23
10084535c:     	b	0x10084538c <_js_json_stringify_full+0x98c>
100845360:     	add	x12, x11, #0x2
100845364:     	bfi	w15, w13, #6, #5
100845368:     	mov	x13, x15
10084536c:     	sub	x11, x25, x11
100845370:     	add	x14, x11, x12
100845374:     	cmp	w13, #0x10, lsl #12     ; =0x10000
100845378:     	cinc	x11, x10, hs
10084537c:     	add	x8, x11, x8
100845380:     	mov	x11, x12
100845384:     	cmp	x8, #0xa
100845388:     	b.hi	0x100845444 <_js_json_stringify_full+0xa44>
10084538c:     	cmp	x11, x9
100845390:     	b.eq	0x1008453f4 <_js_json_stringify_full+0x9f4>
100845394:     	mov	x25, x14
100845398:     	mov	x12, x11
10084539c:     	ldrsb	w14, [x12], #0x1
1008453a0:     	and	w13, w14, #0xff
1008453a4:     	tbz	w14, #0x1f, 0x10084536c <_js_json_stringify_full+0x96c>
1008453a8:     	ldrb	w12, [x11, #0x1]
1008453ac:     	and	w15, w12, #0x3f
1008453b0:     	cmp	w13, #0xe0
1008453b4:     	b.lo	0x100845360 <_js_json_stringify_full+0x960>
1008453b8:     	and	w14, w13, #0x1f
1008453bc:     	ldrb	w12, [x11, #0x2]
1008453c0:     	and	w12, w12, #0x3f
1008453c4:     	orr	w15, w12, w15, lsl #6
1008453c8:     	cmp	w13, #0xf0
1008453cc:     	b.lo	0x1008453e8 <_js_json_stringify_full+0x9e8>
1008453d0:     	add	x12, x11, #0x4
1008453d4:     	ldrb	w13, [x11, #0x3]
1008453d8:     	and	w13, w13, #0x3f
1008453dc:     	orr	w13, w13, w15, lsl #6
1008453e0:     	bfi	w13, w14, #18, #3
1008453e4:     	b	0x10084536c <_js_json_stringify_full+0x96c>
1008453e8:     	add	x12, x11, #0x3
1008453ec:     	orr	w13, w15, w14, lsl #12
1008453f0:     	b	0x10084536c <_js_json_stringify_full+0x96c>
1008453f4:     	cbz	x24, 0x100845478 <_js_json_stringify_full+0xa78>
1008453f8:     	mov	x0, x24
1008453fc:     	mov	w1, #0x1                ; =1
100845400:     	bl	0x100b5e708 <_mi_malloc_aligned>
100845404:     	cbz	x0, 0x100846664 <_js_json_stringify_full+0x1c64>
100845408:     	mov	x26, x0
10084540c:     	mov	x1, x23
100845410:     	mov	x2, x24
100845414:     	bl	0x100b6132c <_writev+0x100b6132c>
100845418:     	b	0x100845480 <_js_json_stringify_full+0xa80>
10084541c:     	cbz	x25, 0x1008454d4 <_js_json_stringify_full+0xad4>
100845420:     	mov	x0, x25
100845424:     	mov	w1, #0x1                ; =1
100845428:     	bl	0x100b5e708 <_mi_malloc_aligned>
10084542c:     	cbz	x0, 0x100846670 <_js_json_stringify_full+0x1c70>
100845430:     	mov	x24, x0
100845434:     	mov	x1, x23
100845438:     	mov	x2, x25
10084543c:     	bl	0x100b6132c <_writev+0x100b6132c>
100845440:     	b	0x1008454dc <_js_json_stringify_full+0xadc>
100845444:     	cbz	x25, 0x100845478 <_js_json_stringify_full+0xa78>
100845448:     	cmp	x25, x24
10084544c:     	b.hs	0x100845ef4 <_js_json_stringify_full+0x14f4>
100845450:     	ldrsb	w8, [x23, x25]
100845454:     	cmn	w8, #0x40
100845458:     	b.ge	0x100845ef8 <_js_json_stringify_full+0x14f8>
10084545c:     	adrp	x4, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100845460:     	add	x4, x4, #0x270
100845464:     	mov	x0, x23
100845468:     	mov	x1, x24
10084546c:     	mov	x2, #0x0                ; =0
100845470:     	mov	x3, x25
100845474:     	bl	0x100b11b78 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
100845478:     	mov	x22, #0x0               ; =0
10084547c:     	mov	w26, #0x1               ; =1
100845480:     	stp	x22, x26, [sp, #0x10]
100845484:     	b	0x1008454e0 <_js_json_stringify_full+0xae0>
100845488:     	add	x14, sp, #0x80
10084548c:     	mov	w16, #0x5c              ; =92
100845490:     	strb	w16, [x14, x12]
100845494:     	add	x12, x12, #0x2
100845498:     	strb	w15, [x13, #0x1]
10084549c:     	cmp	w10, #0x2
1008454a0:     	b.eq	0x100844c04 <_js_json_stringify_full+0x204>
1008454a4:     	ldrb	w11, [x11, #0x2]
1008454a8:     	sxtb	w10, w11
1008454ac:     	cmp	w11, #0xb
1008454b0:     	b.le	0x100845f80 <_js_json_stringify_full+0x1580>
1008454b4:     	cmp	w11, #0x21
1008454b8:     	b.gt	0x100845fcc <_js_json_stringify_full+0x15cc>
1008454bc:     	cmp	w11, #0xc
1008454c0:     	b.eq	0x100846058 <_js_json_stringify_full+0x1658>
1008454c4:     	cmp	w11, #0xd
1008454c8:     	b.ne	0x100845fdc <_js_json_stringify_full+0x15dc>
1008454cc:     	mov	w10, #0x72              ; =114
1008454d0:     	b	0x100846064 <_js_json_stringify_full+0x1664>
1008454d4:     	mov	x22, #0x0               ; =0
1008454d8:     	mov	w24, #0x1               ; =1
1008454dc:     	stp	x22, x24, [sp, #0x10]
1008454e0:     	str	x22, [sp, #0x20]
1008454e4:     	cmp	x27, #0x2
1008454e8:     	b.lo	0x100845628 <_js_json_stringify_full+0xc28>
1008454ec:     	and	x25, x21, #0xffff000000000000
1008454f0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008454f4:     	cmp	x25, x8
1008454f8:     	b.ne	0x100845604 <_js_json_stringify_full+0xc04>
1008454fc:     	and	x23, x21, #0xffffffffffff
100845500:     	cmp	x23, #0x100, lsl #12    ; =0x100000
100845504:     	b.lo	0x100845628 <_js_json_stringify_full+0xc28>
100845508:     	mov	x0, x23
10084550c:     	bl	0x100508d00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
100845510:     	tbnz	w0, #0x0, 0x100845628 <_js_json_stringify_full+0xc28>
100845514:     	lsr	x8, x23, #51
100845518:     	cmp	x8, #0xfff
10084551c:     	b.lo	0x100845534 <_js_json_stringify_full+0xb34>
100845520:     	mov	w8, #0x7ffc             ; =32764
100845524:     	cmp	x8, x23, lsr #48
100845528:     	b.eq	0x100845628 <_js_json_stringify_full+0xc28>
10084552c:     	ands	x23, x23, #0xffffffffffff
100845530:     	b.eq	0x100845628 <_js_json_stringify_full+0xc28>
100845534:     	and	x8, x23, #0xfffffffffff00000
100845538:     	lsr	x9, x23, #47
10084553c:     	cmp	x9, #0x0
100845540:     	ccmp	x8, #0x0, #0x4, eq
100845544:     	b.eq	0x100845628 <_js_json_stringify_full+0xc28>
100845548:     	tst	x23, #0x3
10084554c:     	ccmp	x23, #0x7, #0x0, eq
100845550:     	b.ls	0x100846294 <_js_json_stringify_full+0x1894>
100845554:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100845558:     	ldr	x8, [x8, #0x48]
10084555c:     	cmn	x8, #0x1
100845560:     	b.eq	0x1008461e4 <_js_json_stringify_full+0x17e4>
100845564:     	mrs	x9, TPIDRRO_EL0
100845568:     	and	x9, x9, #0xfffffffffffffff8
10084556c:     	ldr	x0, [x9, x8, lsl #3]
100845570:     	cbz	x0, 0x1008461e4 <_js_json_stringify_full+0x17e4>
100845574:     	lsr	x1, x23, #20
100845578:     	ldr	x8, [x0, #0x10]
10084557c:     	ldrb	w9, [x8]
100845580:     	cmp	w9, #0x2
100845584:     	b.ne	0x1008461fc <_js_json_stringify_full+0x17fc>
100845588:     	ldrb	w9, [x8, #0x88]
10084558c:     	tbz	w9, #0x0, 0x1008455ac <_js_json_stringify_full+0xbac>
100845590:     	ldr	x9, [x8, #0x80]
100845594:     	cmp	x9, x1
100845598:     	b.ne	0x1008455ac <_js_json_stringify_full+0xbac>
10084559c:     	ldp	x9, x10, [x8, #0x60]
1008455a0:     	cmp	x9, x23
1008455a4:     	ccmp	x10, x23, #0x0, ls
1008455a8:     	b.hi	0x1008461dc <_js_json_stringify_full+0x17dc>
1008455ac:     	ldrb	w9, [x8, #0xb8]
1008455b0:     	cbz	w9, 0x1008455d0 <_js_json_stringify_full+0xbd0>
1008455b4:     	ldr	x9, [x8, #0xb0]
1008455b8:     	cmp	x9, x1
1008455bc:     	b.ne	0x1008455d0 <_js_json_stringify_full+0xbd0>
1008455c0:     	ldp	x9, x10, [x8, #0x90]
1008455c4:     	cmp	x9, x23
1008455c8:     	ccmp	x10, x23, #0x0, ls
1008455cc:     	b.hi	0x100846464 <_js_json_stringify_full+0x1a64>
1008455d0:     	ldrb	w9, [x8, #0xe8]
1008455d4:     	cbz	w9, 0x10084601c <_js_json_stringify_full+0x161c>
1008455d8:     	ldr	x9, [x8, #0xe0]
1008455dc:     	cmp	x9, x1
1008455e0:     	b.ne	0x10084601c <_js_json_stringify_full+0x161c>
1008455e4:     	ldr	x9, [x8, #0xc0]
1008455e8:     	cmp	x9, x23
1008455ec:     	b.hi	0x10084601c <_js_json_stringify_full+0x161c>
1008455f0:     	ldr	x9, [x8, #0xc8]
1008455f4:     	cmp	x9, x23
1008455f8:     	b.ls	0x10084601c <_js_json_stringify_full+0x161c>
1008455fc:     	add	x9, x8, #0xc0
100845600:     	b	0x100846468 <_js_json_stringify_full+0x1a68>
100845604:     	lsr	x8, x21, #52
100845608:     	cbnz	x8, 0x100845628 <_js_json_stringify_full+0xc28>
10084560c:     	cbz	x21, 0x100845628 <_js_json_stringify_full+0xc28>
100845610:     	and	x8, x21, #0x7
100845614:     	cbnz	x8, 0x100845628 <_js_json_stringify_full+0xc28>
100845618:     	mov	x0, x21
10084561c:     	bl	0x10050d7f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100845620:     	mov	x23, x21
100845624:     	cbnz	w0, 0x100845500 <_js_json_stringify_full+0xb00>
100845628:     	mov	x25, #-0x1              ; =-1
10084562c:     	str	x25, [sp, #0x30]
100845630:     	mov	w24, #0x1               ; =1
100845634:     	cmp	x27, #0x1
100845638:     	cset	w8, hi
10084563c:     	tst	w8, w24
100845640:     	b.eq	0x1008456b4 <_js_json_stringify_full+0xcb4>
100845644:     	and	x23, x21, #0xffff000000000000
100845648:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084564c:     	cmp	x23, x8
100845650:     	b.ne	0x10084568c <_js_json_stringify_full+0xc8c>
100845654:     	and	x8, x21, #0xffffffffffff
100845658:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084565c:     	b.lo	0x1008456b4 <_js_json_stringify_full+0xcb4>
100845660:     	ldr	w8, [x8, #0xc]
100845664:     	mov	w9, #0x4f53             ; =20307
100845668:     	movk	w9, #0x434c, lsl #16
10084566c:     	cmp	w8, w9
100845670:     	b.ne	0x1008456b4 <_js_json_stringify_full+0xcb4>
100845674:     	and	x8, x21, #0xffffffffffff
100845678:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084567c:     	cmp	x23, x9
100845680:     	csel	x28, x8, x21, eq
100845684:     	mov	w27, #0x1               ; =1
100845688:     	b	0x1008456b8 <_js_json_stringify_full+0xcb8>
10084568c:     	lsr	x8, x21, #52
100845690:     	cbnz	x8, 0x1008456b4 <_js_json_stringify_full+0xcb4>
100845694:     	mov	w27, #0x0               ; =0
100845698:     	cbz	x21, 0x1008456b8 <_js_json_stringify_full+0xcb8>
10084569c:     	and	x8, x21, #0x7
1008456a0:     	cbnz	x8, 0x1008456b8 <_js_json_stringify_full+0xcb8>
1008456a4:     	mov	x0, x21
1008456a8:     	bl	0x10050d7f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008456ac:     	mov	x8, x21
1008456b0:     	tbnz	w0, #0x0, 0x100845658 <_js_json_stringify_full+0xc58>
1008456b4:     	mov	w27, #0x0               ; =0
1008456b8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008456bc:     	add	x0, x0, #0xd78
1008456c0:     	ldr	x8, [x0]
1008456c4:     	blr	x8
1008456c8:     	mov	x21, x0
1008456cc:     	ldr	w26, [x0]
1008456d0:     	add	w8, w26, #0x1
1008456d4:     	str	w8, [x0]
1008456d8:     	cbz	w26, 0x100845748 <_js_json_stringify_full+0xd48>
1008456dc:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008456e0:     	add	x0, x0, #0xd00
1008456e4:     	ldr	x8, [x0]
1008456e8:     	blr	x8
1008456ec:     	ldrb	w8, [x0, #0x20]
1008456f0:     	cmp	w8, #0x1
1008456f4:     	b.ne	0x1008464d4 <_js_json_stringify_full+0x1ad4>
1008456f8:     	ldr	x8, [x0]
1008456fc:     	cbnz	x8, 0x1008464e0 <_js_json_stringify_full+0x1ae0>
100845700:     	mov	x8, #-0x1               ; =-1
100845704:     	str	x8, [x0]
100845708:     	ldr	x23, [x0, #0x18]
10084570c:     	ldr	x8, [x0, #0x8]
100845710:     	cmp	x23, x8
100845714:     	b.eq	0x100845ed0 <_js_json_stringify_full+0x14d0>
100845718:     	ldr	x8, [x0, #0x10]
10084571c:     	mov	w9, #0x18               ; =24
100845720:     	madd	x8, x23, x9, x8
100845724:     	mov	w9, #0x8                ; =8
100845728:     	stp	xzr, x9, [x8]
10084572c:     	str	xzr, [x8, #0x10]
100845730:     	add	x8, x23, #0x1
100845734:     	str	x8, [x0, #0x18]
100845738:     	ldr	x8, [x0]
10084573c:     	add	x8, x8, #0x1
100845740:     	str	x8, [x0]
100845744:     	b	0x1008457b0 <_js_json_stringify_full+0xdb0>
100845748:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084574c:     	add	x0, x0, #0xdc0
100845750:     	ldr	x8, [x0]
100845754:     	blr	x8
100845758:     	strb	wzr, [x0]
10084575c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845760:     	add	x0, x0, #0xdf0
100845764:     	ldr	x8, [x0]
100845768:     	blr	x8
10084576c:     	strb	wzr, [x0]
100845770:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100845774:     	ldr	w23, [x8, #0x5a8]
100845778:     	cmp	w23, #0x300
10084577c:     	b.hs	0x100845f18 <_js_json_stringify_full+0x1518>
100845780:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100845784:     	ldr	x8, [x8, #0x48]
100845788:     	cmn	x8, #0x1
10084578c:     	b.eq	0x100845f08 <_js_json_stringify_full+0x1508>
100845790:     	mrs	x9, TPIDRRO_EL0
100845794:     	and	x9, x9, #0xfffffffffffffff8
100845798:     	ldr	x0, [x9, x8, lsl #3]
10084579c:     	cbz	x0, 0x100845f08 <_js_json_stringify_full+0x1508>
1008457a0:     	add	x8, x0, x23, lsl #3
1008457a4:     	ldr	x0, [x8, #0x1e8]
1008457a8:     	cbz	x0, 0x100845f18 <_js_json_stringify_full+0x1518>
1008457ac:     	str	xzr, [x0]
1008457b0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008457b4:     	add	x0, x0, #0xd30
1008457b8:     	ldr	x8, [x0]
1008457bc:     	blr	x8
1008457c0:     	mov	x23, x0
1008457c4:     	ldrb	w8, [x0, #0x18]
1008457c8:     	cmp	w8, #0x1
1008457cc:     	b.ne	0x100846488 <_js_json_stringify_full+0x1a88>
1008457d0:     	ldr	x8, [x0]
1008457d4:     	mov	x9, #-0x1               ; =-1
1008457d8:     	str	x9, [x0]
1008457dc:     	cmn	x8, #0x2
1008457e0:     	b.eq	0x100846610 <_js_json_stringify_full+0x1c10>
1008457e4:     	cmn	x8, #0x1
1008457e8:     	b.eq	0x1008458bc <_js_json_stringify_full+0xebc>
1008457ec:     	add	x9, sp, #0x48
1008457f0:     	ldur	q0, [x0, #0x8]
1008457f4:     	stur	q0, [x9, #0x8]
1008457f8:     	str	x8, [sp, #0x48]
1008457fc:     	tbz	w24, #0x0, 0x1008458d0 <_js_json_stringify_full+0xed0>
100845800:     	tbz	w27, #0x0, 0x1008459b8 <_js_json_stringify_full+0xfb8>
100845804:     	bl	0x100289c98 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100845808:     	str	x0, [sp, #0x60]
10084580c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845810:     	stp	x28, x8, [sp, #0x88]
100845814:     	mov	w8, #0x1                ; =1
100845818:     	str	x8, [sp, #0x80]
10084581c:     	add	x0, sp, #0x80
100845820:     	bl	0x100289da0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100845824:     	mov	x22, x0
100845828:     	str	x0, [sp, #0x68]
10084582c:     	mov	w0, #0x0                ; =0
100845830:     	bl	0x100349a2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100845834:     	stp	xzr, xzr, [x0]
100845838:     	str	wzr, [x0, #0x10]
10084583c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100845840:     	bfxil	x8, x0, #0, #48
100845844:     	fmov	d0, x8
100845848:     	bl	0x100208ae4 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
10084584c:     	mov	x19, x0
100845850:     	adrp	x24, 0x100f7c000 <_perry_global_worker_ts__1>
100845854:     	ldr	x8, [x24, #0x48]
100845858:     	cmn	x8, #0x1
10084585c:     	b.eq	0x100845a1c <_js_json_stringify_full+0x101c>
100845860:     	mrs	x9, TPIDRRO_EL0
100845864:     	and	x9, x9, #0xfffffffffffffff8
100845868:     	ldr	x8, [x9, x8, lsl #3]
10084586c:     	cbz	x8, 0x100845a1c <_js_json_stringify_full+0x101c>
100845870:     	ldr	x8, [x8, #0x19e8]
100845874:     	cbz	x8, 0x100845a1c <_js_json_stringify_full+0x101c>
100845878:     	ldr	x9, [x8]
10084587c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100845880:     	cmp	x9, x10
100845884:     	b.hs	0x10084655c <_js_json_stringify_full+0x1b5c>
100845888:     	add	x10, x9, #0x1
10084588c:     	str	x10, [x8]
100845890:     	ldr	x10, [x8, #0x18]
100845894:     	cmp	x19, x10
100845898:     	b.hs	0x100846568 <_js_json_stringify_full+0x1b68>
10084589c:     	ldr	x10, [x8, #0x10]
1008458a0:     	mov	w11, #0x18              ; =24
1008458a4:     	madd	x10, x19, x11, x10
1008458a8:     	ldr	x11, [x10]
1008458ac:     	cbnz	x11, 0x1008465c8 <_js_json_stringify_full+0x1bc8>
1008458b0:     	ldr	x0, [x10, #0x8]
1008458b4:     	str	x9, [x8]
1008458b8:     	b	0x100845a24 <_js_json_stringify_full+0x1024>
1008458bc:     	mov	x8, #0x0                ; =0
1008458c0:     	mov	w9, #0x1                ; =1
1008458c4:     	stp	x9, xzr, [sp, #0x50]
1008458c8:     	str	x8, [sp, #0x48]
1008458cc:     	tbnz	w24, #0x0, 0x100845800 <_js_json_stringify_full+0xe00>
1008458d0:     	cmp	x22, #0x0
1008458d4:     	cset	w6, ne
1008458d8:     	ldp	x0, x1, [sp, #0x38]
1008458dc:     	ldp	x3, x4, [sp, #0x18]
1008458e0:     	add	x2, sp, #0x48
1008458e4:     	mov.16b	v0, v8
1008458e8:     	mov	x5, #0x0                ; =0
1008458ec:     	bl	0x100501300 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
1008458f0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008458f4:     	add	x0, x0, #0xd90
1008458f8:     	ldr	x8, [x0]
1008458fc:     	blr	x8
100845900:     	ldrb	w8, [x0, #0x20]
100845904:     	cbnz	w8, 0x1008464ec <_js_json_stringify_full+0x1aec>
100845908:     	ldr	x8, [x0]
10084590c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100845910:     	cmp	x8, x9
100845914:     	b.hs	0x10084651c <_js_json_stringify_full+0x1b1c>
100845918:     	ldr	x9, [x0, #0x18]
10084591c:     	cbz	x9, 0x100845928 <_js_json_stringify_full+0xf28>
100845920:     	cbnz	x8, 0x100846528 <_js_json_stringify_full+0x1b28>
100845924:     	str	xzr, [x0, #0x18]
100845928:     	ldp	x0, x1, [sp, #0x50]
10084592c:     	cmp	x1, #0x5
100845930:     	b.hi	0x100845998 <_js_json_stringify_full+0xf98>
100845934:     	cbz	x1, 0x100845ba8 <_js_json_stringify_full+0x11a8>
100845938:     	ldrsb	w8, [x0]
10084593c:     	tbnz	w8, #0x1f, 0x100845998 <_js_json_stringify_full+0xf98>
100845940:     	cmp	x1, #0x1
100845944:     	b.eq	0x100845980 <_js_json_stringify_full+0xf80>
100845948:     	ldrsb	w8, [x0, #0x1]
10084594c:     	tbnz	w8, #0x1f, 0x100845998 <_js_json_stringify_full+0xf98>
100845950:     	cmp	x1, #0x2
100845954:     	b.eq	0x100845980 <_js_json_stringify_full+0xf80>
100845958:     	ldrsb	w8, [x0, #0x2]
10084595c:     	tbnz	w8, #0x1f, 0x100845998 <_js_json_stringify_full+0xf98>
100845960:     	cmp	x1, #0x3
100845964:     	b.eq	0x100845980 <_js_json_stringify_full+0xf80>
100845968:     	ldrsb	w8, [x0, #0x3]
10084596c:     	tbnz	w8, #0x1f, 0x100845998 <_js_json_stringify_full+0xf98>
100845970:     	cmp	x1, #0x4
100845974:     	b.eq	0x100845980 <_js_json_stringify_full+0xf80>
100845978:     	ldrsb	w8, [x0, #0x4]
10084597c:     	tbnz	w8, #0x1f, 0x100845998 <_js_json_stringify_full+0xf98>
100845980:     	cmp	x1, #0x4
100845984:     	b.hs	0x100845ce8 <_js_json_stringify_full+0x12e8>
100845988:     	mov	x10, #0x0               ; =0
10084598c:     	mov	x9, #0x0                ; =0
100845990:     	mov	x8, x0
100845994:     	b	0x100845d78 <_js_json_stringify_full+0x1378>
100845998:     	bl	0x100328708 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
10084599c:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
1008459a0:     	bfxil	x20, x0, #0, #48
1008459a4:     	ldp	x22, x0, [sp, #0x48]
1008459a8:     	ldrb	w8, [x23, #0x18]
1008459ac:     	cmp	w8, #0x1
1008459b0:     	b.eq	0x100845db4 <_js_json_stringify_full+0x13b4>
1008459b4:     	b	0x1008464b8 <_js_json_stringify_full+0x1ab8>
1008459b8:     	mov	w0, #0x0                ; =0
1008459bc:     	bl	0x100349a2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1008459c0:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008459c4:     	bfxil	x8, x0, #0, #48
1008459c8:     	fmov	d1, x8
1008459cc:     	stp	xzr, xzr, [x0]
1008459d0:     	str	wzr, [x0, #0x10]
1008459d4:     	mov.16b	v0, v8
1008459d8:     	bl	0x1006c4fe4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
1008459dc:     	mov.16b	v8, v0
1008459e0:     	fmov	x24, d8
1008459e4:     	cmp	x24, x20
1008459e8:     	b.eq	0x100845c30 <_js_json_stringify_full+0x1230>
1008459ec:     	mov	w8, #0x7ffd             ; =32765
1008459f0:     	cmp	x8, x24, lsr #48
1008459f4:     	b.ne	0x100845c00 <_js_json_stringify_full+0x1200>
1008459f8:     	and	x8, x24, #0xffffffffffff
1008459fc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100845a00:     	b.lo	0x100845c24 <_js_json_stringify_full+0x1224>
100845a04:     	ldr	w8, [x8, #0xc]
100845a08:     	mov	w9, #0x4f53             ; =20307
100845a0c:     	movk	w9, #0x434c, lsl #16
100845a10:     	cmp	w8, w9
100845a14:     	b.ne	0x100845c24 <_js_json_stringify_full+0x1224>
100845a18:     	b	0x100845c30 <_js_json_stringify_full+0x1230>
100845a1c:     	mov	x0, x19
100845a20:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100845a24:     	fmov	d1, x0
100845a28:     	mov.16b	v0, v8
100845a2c:     	bl	0x1006c4fe4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
100845a30:     	mov.16b	v8, v0
100845a34:     	ldr	x8, [x24, #0x48]
100845a38:     	cmn	x8, #0x1
100845a3c:     	b.eq	0x100845aa0 <_js_json_stringify_full+0x10a0>
100845a40:     	mrs	x9, TPIDRRO_EL0
100845a44:     	and	x9, x9, #0xfffffffffffffff8
100845a48:     	ldr	x8, [x9, x8, lsl #3]
100845a4c:     	cbz	x8, 0x100845aa0 <_js_json_stringify_full+0x10a0>
100845a50:     	ldr	x8, [x8, #0x19e8]
100845a54:     	cbz	x8, 0x100845aa0 <_js_json_stringify_full+0x10a0>
100845a58:     	ldr	x9, [x8]
100845a5c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100845a60:     	cmp	x9, x10
100845a64:     	b.hs	0x10084655c <_js_json_stringify_full+0x1b5c>
100845a68:     	add	x10, x9, #0x1
100845a6c:     	str	x10, [x8]
100845a70:     	ldr	x10, [x8, #0x18]
100845a74:     	cmp	x22, x10
100845a78:     	b.hs	0x100846568 <_js_json_stringify_full+0x1b68>
100845a7c:     	ldr	x10, [x8, #0x10]
100845a80:     	mov	w11, #0x18              ; =24
100845a84:     	madd	x10, x22, x11, x10
100845a88:     	ldr	x11, [x10]
100845a8c:     	cmp	x11, #0x1
100845a90:     	b.ne	0x100846628 <_js_json_stringify_full+0x1c28>
100845a94:     	ldr	x22, [x10, #0x8]
100845a98:     	str	x9, [x8]
100845a9c:     	b	0x100845aac <_js_json_stringify_full+0x10ac>
100845aa0:     	mov	x0, x22
100845aa4:     	bl	0x10013c298 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100845aa8:     	mov	x22, x0
100845aac:     	ldr	x8, [x24, #0x48]
100845ab0:     	cmn	x8, #0x1
100845ab4:     	b.eq	0x100845b14 <_js_json_stringify_full+0x1114>
100845ab8:     	mrs	x9, TPIDRRO_EL0
100845abc:     	and	x9, x9, #0xfffffffffffffff8
100845ac0:     	ldr	x8, [x9, x8, lsl #3]
100845ac4:     	cbz	x8, 0x100845b14 <_js_json_stringify_full+0x1114>
100845ac8:     	ldr	x8, [x8, #0x19e8]
100845acc:     	cbz	x8, 0x100845b14 <_js_json_stringify_full+0x1114>
100845ad0:     	ldr	x9, [x8]
100845ad4:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100845ad8:     	cmp	x9, x10
100845adc:     	b.hs	0x10084655c <_js_json_stringify_full+0x1b5c>
100845ae0:     	add	x10, x9, #0x1
100845ae4:     	str	x10, [x8]
100845ae8:     	ldr	x10, [x8, #0x18]
100845aec:     	cmp	x19, x10
100845af0:     	b.hs	0x100846568 <_js_json_stringify_full+0x1b68>
100845af4:     	ldr	x10, [x8, #0x10]
100845af8:     	mov	w11, #0x18              ; =24
100845afc:     	madd	x10, x19, x11, x10
100845b00:     	ldr	x11, [x10]
100845b04:     	cbnz	x11, 0x1008465c8 <_js_json_stringify_full+0x1bc8>
100845b08:     	ldr	x0, [x10, #0x8]
100845b0c:     	str	x9, [x8]
100845b10:     	b	0x100845b1c <_js_json_stringify_full+0x111c>
100845b14:     	mov	x0, x19
100845b18:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100845b1c:     	fmov	d9, x0
100845b20:     	mov.16b	v0, v8
100845b24:     	bl	0x1004fdcb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100845b28:     	mov.16b	v2, v0
100845b2c:     	mov	x0, x22
100845b30:     	mov.16b	v0, v9
100845b34:     	mov.16b	v1, v8
100845b38:     	bl	0x1004fdf94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
100845b3c:     	str	d0, [sp, #0x70]
100845b40:     	fmov	x19, d0
100845b44:     	cmp	x19, x20
100845b48:     	b.ne	0x100845bb0 <_js_json_stringify_full+0x11b0>
100845b4c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845b50:     	add	x0, x0, #0xd90
100845b54:     	ldr	x8, [x0]
100845b58:     	blr	x8
100845b5c:     	ldrb	w8, [x0, #0x20]
100845b60:     	cbnz	w8, 0x100846608 <_js_json_stringify_full+0x1c08>
100845b64:     	ldr	x8, [x0]
100845b68:     	cbnz	x8, 0x100846658 <_js_json_stringify_full+0x1c58>
100845b6c:     	str	xzr, [x0, #0x18]
100845b70:     	ldp	x22, x19, [sp, #0x48]
100845b74:     	ldrb	w8, [x23, #0x18]
100845b78:     	cmp	w8, #0x1
100845b7c:     	b.ne	0x1008465a0 <_js_json_stringify_full+0x1ba0>
100845b80:     	ldp	x8, x0, [x23]
100845b84:     	stp	x22, x19, [x23]
100845b88:     	str	xzr, [x23, #0x10]
100845b8c:     	sub	x8, x8, #0x1
100845b90:     	cmn	x8, #0x2
100845b94:     	b.hs	0x100845b9c <_js_json_stringify_full+0x119c>
100845b98:     	bl	0x100b5e480 <_mi_free>
100845b9c:     	cbz	w26, 0x100845e3c <_js_json_stringify_full+0x143c>
100845ba0:     	bl	0x100326968 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100845ba4:     	b	0x100845e40 <_js_json_stringify_full+0x1440>
100845ba8:     	mov	x10, #0x0               ; =0
100845bac:     	b	0x100845d98 <_js_json_stringify_full+0x1398>
100845bb0:     	add	x0, sp, #0x48
100845bb4:     	bl	0x1004fe974 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
100845bb8:     	tbnz	w0, #0x0, 0x100845bf4 <_js_json_stringify_full+0x11f4>
100845bbc:     	mov	x0, x19
100845bc0:     	bl	0x10032666c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
100845bc4:     	cmp	x0, #0x1
100845bc8:     	b.ne	0x10084661c <_js_json_stringify_full+0x1c1c>
100845bcc:     	add	x8, sp, #0x78
100845bd0:     	add	x9, sp, #0x70
100845bd4:     	stp	x1, x8, [sp, #0x78]
100845bd8:     	str	x9, [sp, #0x88]
100845bdc:     	add	x8, sp, #0x48
100845be0:     	add	x9, sp, #0x10
100845be4:     	stp	x8, x9, [sp, #0x90]
100845be8:     	add	x0, sp, #0x68
100845bec:     	add	x1, sp, #0x80
100845bf0:     	bl	0x100143d90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
100845bf4:     	add	x0, sp, #0x60
100845bf8:     	bl	0x10016483c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100845bfc:     	b	0x1008458f0 <_js_json_stringify_full+0xef0>
100845c00:     	lsr	x8, x24, #52
100845c04:     	cbnz	x8, 0x100845c24 <_js_json_stringify_full+0x1224>
100845c08:     	cbz	x24, 0x100845c24 <_js_json_stringify_full+0x1224>
100845c0c:     	and	x8, x24, #0x7
100845c10:     	cbnz	x8, 0x100845c24 <_js_json_stringify_full+0x1224>
100845c14:     	mov	x0, x24
100845c18:     	bl	0x10050d7f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100845c1c:     	mov	x8, x24
100845c20:     	tbnz	w0, #0x0, 0x1008459fc <_js_json_stringify_full+0xffc>
100845c24:     	mov	x0, x24
100845c28:     	bl	0x100507b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
100845c2c:     	tbz	w0, #0x0, 0x100845cbc <_js_json_stringify_full+0x12bc>
100845c30:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845c34:     	add	x0, x0, #0xd90
100845c38:     	ldr	x8, [x0]
100845c3c:     	blr	x8
100845c40:     	ldrb	w8, [x0, #0x20]
100845c44:     	cbnz	w8, 0x10084656c <_js_json_stringify_full+0x1b6c>
100845c48:     	ldr	x8, [x0]
100845c4c:     	cbnz	x8, 0x100846594 <_js_json_stringify_full+0x1b94>
100845c50:     	str	xzr, [x0, #0x18]
100845c54:     	ldp	x22, x19, [sp, #0x48]
100845c58:     	ldrb	w8, [x23, #0x18]
100845c5c:     	cmp	w8, #0x1
100845c60:     	b.ne	0x100846548 <_js_json_stringify_full+0x1b48>
100845c64:     	ldp	x8, x0, [x23]
100845c68:     	stp	x22, x19, [x23]
100845c6c:     	str	xzr, [x23, #0x10]
100845c70:     	sub	x8, x8, #0x1
100845c74:     	cmn	x8, #0x2
100845c78:     	b.hs	0x100845c80 <_js_json_stringify_full+0x1280>
100845c7c:     	bl	0x100b5e480 <_mi_free>
100845c80:     	cbz	w26, 0x100845ca0 <_js_json_stringify_full+0x12a0>
100845c84:     	bl	0x100326968 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100845c88:     	ldr	w8, [x21]
100845c8c:     	sub	w8, w8, #0x1
100845c90:     	str	w8, [x21]
100845c94:     	cmn	x25, #0x1
100845c98:     	b.ne	0x100845e5c <_js_json_stringify_full+0x145c>
100845c9c:     	b	0x100845e98 <_js_json_stringify_full+0x1498>
100845ca0:     	bl	0x100326798 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100845ca4:     	ldr	w8, [x21]
100845ca8:     	sub	w8, w8, #0x1
100845cac:     	str	w8, [x21]
100845cb0:     	cmn	x25, #0x1
100845cb4:     	b.ne	0x100845e5c <_js_json_stringify_full+0x145c>
100845cb8:     	b	0x100845e98 <_js_json_stringify_full+0x1498>
100845cbc:     	cmp	x19, x24
100845cc0:     	b.eq	0x100845ccc <_js_json_stringify_full+0x12cc>
100845cc4:     	mov.16b	v0, v8
100845cc8:     	bl	0x10050cf2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
100845ccc:     	cbz	x22, 0x100845f28 <_js_json_stringify_full+0x1528>
100845cd0:     	ldp	x1, x2, [sp, #0x18]
100845cd4:     	add	x0, sp, #0x48
100845cd8:     	mov.16b	v0, v8
100845cdc:     	mov	x3, #0x0                ; =0
100845ce0:     	bl	0x1004ff3ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
100845ce4:     	b	0x100845f38 <_js_json_stringify_full+0x1538>
100845ce8:     	and	x9, x1, #0x4
100845cec:     	add	x8, x0, x9
100845cf0:     	adrp	x10, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4970>
100845cf4:     	ldr	q0, [x10, #0xf00]
100845cf8:     	adrp	x10, 0x100c38000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x3317a>
100845cfc:     	ldr	q2, [x10, #0xe00]
100845d00:     	movi.2d	v1, #0000000000000000
100845d04:     	movi.2d	v3, #0x000000000000ff
100845d08:     	mov	w10, #0x4               ; =4
100845d0c:     	dup.2d	v4, x10
100845d10:     	mov	x10, x0
100845d14:     	and	x11, x1, #0x4
100845d18:     	movi.2d	v5, #0000000000000000
100845d1c:     	ldr	s6, [x10], #0x4
100845d20:     	ushll.8h	v6, v6, #0x0
100845d24:     	ushll.4s	v6, v6, #0x0
100845d28:     	ushll2.2d	v7, v6, #0x0
100845d2c:     	and.16b	v7, v7, v3
100845d30:     	ushll.2d	v6, v6, #0x0
100845d34:     	and.16b	v6, v6, v3
100845d38:     	shl.2d	v16, v0, #0x3
100845d3c:     	shl.2d	v17, v2, #0x3
100845d40:     	ushl.2d	v6, v6, v17
100845d44:     	ushl.2d	v7, v7, v16
100845d48:     	orr.16b	v1, v7, v1
100845d4c:     	orr.16b	v5, v6, v5
100845d50:     	add.2d	v0, v0, v4
100845d54:     	add.2d	v2, v2, v4
100845d58:     	subs	x11, x11, #0x4
100845d5c:     	b.ne	0x100845d1c <_js_json_stringify_full+0x131c>
100845d60:     	orr.16b	v0, v5, v1
100845d64:     	mov	d1, v0[1]
100845d68:     	orr.8b	v0, v0, v1
100845d6c:     	fmov	x10, d0
100845d70:     	cmp	x1, x9
100845d74:     	b.eq	0x100845d98 <_js_json_stringify_full+0x1398>
100845d78:     	add	x11, x0, x1
100845d7c:     	lsl	x9, x9, #3
100845d80:     	ldrb	w12, [x8], #0x1
100845d84:     	lsl	x12, x12, x9
100845d88:     	orr	x10, x12, x10
100845d8c:     	add	x9, x9, #0x8
100845d90:     	cmp	x8, x11
100845d94:     	b.ne	0x100845d80 <_js_json_stringify_full+0x1380>
100845d98:     	orr	x8, x10, x1, lsl #40
100845d9c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845da0:     	orr	x20, x8, x9
100845da4:     	ldr	x22, [sp, #0x48]
100845da8:     	ldrb	w8, [x23, #0x18]
100845dac:     	cmp	w8, #0x1
100845db0:     	b.ne	0x1008464b8 <_js_json_stringify_full+0x1ab8>
100845db4:     	ldp	x9, x8, [x23]
100845db8:     	stp	x22, x0, [x23]
100845dbc:     	str	xzr, [x23, #0x10]
100845dc0:     	sub	x9, x9, #0x1
100845dc4:     	cmn	x9, #0x2
100845dc8:     	b.hs	0x100845dd4 <_js_json_stringify_full+0x13d4>
100845dcc:     	mov	x0, x8
100845dd0:     	bl	0x100b5e480 <_mi_free>
100845dd4:     	cbz	w26, 0x100845df4 <_js_json_stringify_full+0x13f4>
100845dd8:     	bl	0x100326968 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100845ddc:     	ldr	w8, [x21]
100845de0:     	sub	w8, w8, #0x1
100845de4:     	str	w8, [x21]
100845de8:     	cmn	x25, #0x1
100845dec:     	b.ne	0x100845e0c <_js_json_stringify_full+0x140c>
100845df0:     	b	0x100845e98 <_js_json_stringify_full+0x1498>
100845df4:     	bl	0x100326798 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100845df8:     	ldr	w8, [x21]
100845dfc:     	sub	w8, w8, #0x1
100845e00:     	str	w8, [x21]
100845e04:     	cmn	x25, #0x1
100845e08:     	b.eq	0x100845e98 <_js_json_stringify_full+0x1498>
100845e0c:     	ldp	x19, x21, [sp, #0x38]
100845e10:     	cbz	x21, 0x100845e8c <_js_json_stringify_full+0x148c>
100845e14:     	add	x22, x19, #0x8
100845e18:     	b	0x100845e28 <_js_json_stringify_full+0x1428>
100845e1c:     	add	x22, x22, #0x18
100845e20:     	subs	x21, x21, #0x1
100845e24:     	b.eq	0x100845e8c <_js_json_stringify_full+0x148c>
100845e28:     	ldur	x8, [x22, #-0x8]
100845e2c:     	cbz	x8, 0x100845e1c <_js_json_stringify_full+0x141c>
100845e30:     	ldr	x0, [x22]
100845e34:     	bl	0x100b5e480 <_mi_free>
100845e38:     	b	0x100845e1c <_js_json_stringify_full+0x141c>
100845e3c:     	bl	0x100326798 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100845e40:     	ldr	w8, [x21]
100845e44:     	sub	w8, w8, #0x1
100845e48:     	str	w8, [x21]
100845e4c:     	add	x0, sp, #0x60
100845e50:     	bl	0x10016483c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100845e54:     	cmn	x25, #0x1
100845e58:     	b.eq	0x100845e98 <_js_json_stringify_full+0x1498>
100845e5c:     	ldp	x19, x21, [sp, #0x38]
100845e60:     	cbz	x21, 0x100845e8c <_js_json_stringify_full+0x148c>
100845e64:     	add	x22, x19, #0x8
100845e68:     	b	0x100845e78 <_js_json_stringify_full+0x1478>
100845e6c:     	add	x22, x22, #0x18
100845e70:     	subs	x21, x21, #0x1
100845e74:     	b.eq	0x100845e8c <_js_json_stringify_full+0x148c>
100845e78:     	ldur	x8, [x22, #-0x8]
100845e7c:     	cbz	x8, 0x100845e6c <_js_json_stringify_full+0x146c>
100845e80:     	ldr	x0, [x22]
100845e84:     	bl	0x100b5e480 <_mi_free>
100845e88:     	b	0x100845e6c <_js_json_stringify_full+0x146c>
100845e8c:     	cbz	x25, 0x100845e98 <_js_json_stringify_full+0x1498>
100845e90:     	mov	x0, x19
100845e94:     	bl	0x100b5e480 <_mi_free>
100845e98:     	ldr	x8, [sp, #0x10]
100845e9c:     	cbz	x8, 0x100845ea8 <_js_json_stringify_full+0x14a8>
100845ea0:     	ldr	x0, [sp, #0x18]
100845ea4:     	bl	0x100b5e480 <_mi_free>
100845ea8:     	mov	x0, x20
100845eac:     	ldp	x29, x30, [sp, #0x110]
100845eb0:     	ldp	x20, x19, [sp, #0x100]
100845eb4:     	ldp	x22, x21, [sp, #0xf0]
100845eb8:     	ldp	x24, x23, [sp, #0xe0]
100845ebc:     	ldp	x26, x25, [sp, #0xd0]
100845ec0:     	ldp	x28, x27, [sp, #0xc0]
100845ec4:     	ldp	d9, d8, [sp, #0xb0]
100845ec8:     	add	sp, sp, #0x120
100845ecc:     	ret
100845ed0:     	str	x22, [sp, #0x8]
100845ed4:     	mov	x22, x28
100845ed8:     	mov	x28, x0
100845edc:     	add	x0, x0, #0x8
100845ee0:     	bl	0x100b3b1d0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100845ee4:     	mov	x0, x28
100845ee8:     	mov	x28, x22
100845eec:     	ldr	x22, [sp, #0x8]
100845ef0:     	b	0x100845718 <_js_json_stringify_full+0xd18>
100845ef4:     	b.ne	0x10084545c <_js_json_stringify_full+0xa5c>
100845ef8:     	tbz	x25, #0x3f, 0x100845f50 <_js_json_stringify_full+0x1550>
100845efc:     	mov	x0, #0x0                ; =0
100845f00:     	mov	x1, x25
100845f04:     	bl	0x100b11800 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100845f08:     	bl	0x100b3e87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100845f0c:     	add	x8, x0, x23, lsl #3
100845f10:     	ldr	x0, [x8, #0x1e8]
100845f14:     	cbnz	x0, 0x1008457ac <_js_json_stringify_full+0xdac>
100845f18:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100845f1c:     	add	x0, x0, #0x138
100845f20:     	bl	0x100b3c09c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100845f24:     	b	0x1008457ac <_js_json_stringify_full+0xdac>
100845f28:     	add	x1, sp, #0x48
100845f2c:     	mov.16b	v0, v8
100845f30:     	mov	w0, #0x0                ; =0
100845f34:     	bl	0x100507c3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100845f38:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845f3c:     	add	x0, x0, #0xdc0
100845f40:     	ldr	x8, [x0]
100845f44:     	blr	x8
100845f48:     	strb	wzr, [x0]
100845f4c:     	b	0x1008458f0 <_js_json_stringify_full+0xef0>
100845f50:     	mov	x0, x25
100845f54:     	mov	w1, #0x1                ; =1
100845f58:     	bl	0x100b5e708 <_mi_malloc_aligned>
100845f5c:     	mov	x26, x0
100845f60:     	mov	w0, #0x1                ; =1
100845f64:     	cbz	x26, 0x100845f00 <_js_json_stringify_full+0x1500>
100845f68:     	mov	x0, x26
100845f6c:     	mov	x1, x23
100845f70:     	mov	x2, x25
100845f74:     	bl	0x100b6132c <_writev+0x100b6132c>
100845f78:     	mov	x22, x25
100845f7c:     	b	0x100845480 <_js_json_stringify_full+0xa80>
100845f80:     	cmp	w11, #0x8
100845f84:     	b.eq	0x100846050 <_js_json_stringify_full+0x1650>
100845f88:     	cmp	w11, #0x9
100845f8c:     	b.eq	0x100846060 <_js_json_stringify_full+0x1660>
100845f90:     	cmp	w11, #0xa
100845f94:     	b.ne	0x100845fdc <_js_json_stringify_full+0x15dc>
100845f98:     	mov	w10, #0x6e              ; =110
100845f9c:     	b	0x100846064 <_js_json_stringify_full+0x1664>
100845fa0:     	mov	x22, x0
100845fa4:     	and	x0, x19, #0xffffffffffff
100845fa8:     	bl	0x1003464c0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
100845fac:     	cbz	x0, 0x100846088 <_js_json_stringify_full+0x1688>
100845fb0:     	ldr	w20, [x0]
100845fb4:     	cmp	w20, #0x4
100845fb8:     	b.hi	0x100844fd8 <_js_json_stringify_full+0x5d8>
100845fbc:     	ldr	w8, [x0, #0x4]
100845fc0:     	cmp	w20, w8
100845fc4:     	b.hi	0x100844fd8 <_js_json_stringify_full+0x5d8>
100845fc8:     	b	0x10084608c <_js_json_stringify_full+0x168c>
100845fcc:     	cmp	w11, #0x22
100845fd0:     	b.eq	0x100846064 <_js_json_stringify_full+0x1664>
100845fd4:     	cmp	w11, #0x5c
100845fd8:     	b.eq	0x100846064 <_js_json_stringify_full+0x1664>
100845fdc:     	cmp	x12, #0x3
100845fe0:     	mov	w11, #0x20              ; =32
100845fe4:     	ccmp	w10, w11, #0x8, ls
100845fe8:     	b.lt	0x100844f14 <_js_json_stringify_full+0x514>
100845fec:     	add	x8, sp, #0x80
100845ff0:     	strb	w10, [x8, x12]
100845ff4:     	add	x12, x12, #0x1
100845ff8:     	b	0x100844c04 <_js_json_stringify_full+0x204>
100845ffc:     	mov	x1, x0
100846000:     	and	x0, x19, #0xffffffffffff
100846004:     	mov	x22, x1
100846008:     	bl	0x1004f7680 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
10084600c:     	cmp	x0, #0x1
100846010:     	b.ne	0x100846134 <_js_json_stringify_full+0x1734>
100846014:     	mov	x20, x1
100846018:     	b	0x100845ea8 <_js_json_stringify_full+0x14a8>
10084601c:     	ldrb	w9, [x8, #0x118]
100846020:     	cbz	w9, 0x10084625c <_js_json_stringify_full+0x185c>
100846024:     	ldr	x9, [x8, #0x110]
100846028:     	cmp	x9, x1
10084602c:     	b.ne	0x10084625c <_js_json_stringify_full+0x185c>
100846030:     	ldr	x9, [x8, #0xf0]
100846034:     	cmp	x9, x23
100846038:     	b.hi	0x10084625c <_js_json_stringify_full+0x185c>
10084603c:     	ldr	x9, [x8, #0xf8]
100846040:     	cmp	x9, x23
100846044:     	b.ls	0x10084625c <_js_json_stringify_full+0x185c>
100846048:     	add	x9, x8, #0xf0
10084604c:     	b	0x100846468 <_js_json_stringify_full+0x1a68>
100846050:     	mov	w10, #0x62              ; =98
100846054:     	b	0x100846064 <_js_json_stringify_full+0x1664>
100846058:     	mov	w10, #0x66              ; =102
10084605c:     	b	0x100846064 <_js_json_stringify_full+0x1664>
100846060:     	mov	w10, #0x74              ; =116
100846064:     	cmp	x12, #0x2
100846068:     	b.hi	0x100844f14 <_js_json_stringify_full+0x514>
10084606c:     	add	x8, sp, #0x80
100846070:     	add	x8, x8, x12
100846074:     	add	x12, x12, #0x2
100846078:     	mov	w11, #0x5c              ; =92
10084607c:     	strb	w11, [x8]
100846080:     	strb	w10, [x8, #0x1]
100846084:     	b	0x100844c04 <_js_json_stringify_full+0x204>
100846088:     	mov	x20, #0x0               ; =0
10084608c:     	ldr	w8, [x22, #0x4]
100846090:     	lsl	x9, x20, #3
100846094:     	add	x9, x9, #0x18
100846098:     	cmp	x9, x8
10084609c:     	b.hi	0x100844fd8 <_js_json_stringify_full+0x5d8>
1008460a0:     	ldr	w8, [x25, #0x4]
1008460a4:     	mov	w9, #-0x40000000        ; =-1073741824
1008460a8:     	cmp	w8, w9
1008460ac:     	csel	w8, w8, wzr, lt
1008460b0:     	mov	x22, x0
1008460b4:     	mov	x0, x8
1008460b8:     	bl	0x1005e3da4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
1008460bc:     	mov	w9, #0x2                ; =2
1008460c0:     	cmp	w1, #0x2
1008460c4:     	csel	w10, w1, w9, hi
1008460c8:     	tst	w0, #0x1
1008460cc:     	csel	x8, x10, x9, ne
1008460d0:     	cmp	x20, x8
1008460d4:     	b.hi	0x100844fd8 <_js_json_stringify_full+0x5d8>
1008460d8:     	cbz	x20, 0x100846498 <_js_json_stringify_full+0x1a98>
1008460dc:     	mov	x0, x22
1008460e0:     	mov	x1, x20
1008460e4:     	bl	0x1004ee640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008460e8:     	tbz	w0, #0x0, 0x100844fd8 <_js_json_stringify_full+0x5d8>
1008460ec:     	cmp	x20, #0x1
1008460f0:     	b.eq	0x100846534 <_js_json_stringify_full+0x1b34>
1008460f4:     	cmp	x20, #0x2
1008460f8:     	b.ne	0x1008465f0 <_js_json_stringify_full+0x1bf0>
1008460fc:     	mov	x22, #0x0               ; =0
100846100:     	add	x25, x25, #0x10
100846104:     	mov	w8, #0x1                ; =1
100846108:     	mov	x26, x8
10084610c:     	ldr	x1, [x25, x22, lsl #3]
100846110:     	add	x0, sp, #0x80
100846114:     	bl	0x1004ee694 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
100846118:     	ldr	w8, [sp, #0x80]
10084611c:     	cmn	w8, #0x1
100846120:     	b.ne	0x1008465d8 <_js_json_stringify_full+0x1bd8>
100846124:     	mov	w8, #0x0                ; =0
100846128:     	mov	w22, #0x1               ; =1
10084612c:     	tbnz	w26, #0x0, 0x100846108 <_js_json_stringify_full+0x1708>
100846130:     	b	0x1008465f0 <_js_json_stringify_full+0x1bf0>
100846134:     	and	x0, x19, #0xffffffffffff
100846138:     	bl	0x1003464c0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084613c:     	cbz	x0, 0x1008461c8 <_js_json_stringify_full+0x17c8>
100846140:     	ldr	w20, [x0]
100846144:     	cbz	w20, 0x1008461c8 <_js_json_stringify_full+0x17c8>
100846148:     	cmp	w20, #0x8
10084614c:     	b.hi	0x100844fa4 <_js_json_stringify_full+0x5a4>
100846150:     	ldr	w8, [x0, #0x4]
100846154:     	cmp	w20, w8
100846158:     	b.hi	0x100844fa4 <_js_json_stringify_full+0x5a4>
10084615c:     	ldr	w8, [x22, #0x4]
100846160:     	lsl	x9, x20, #3
100846164:     	add	x9, x9, #0x18
100846168:     	cmp	x9, x8
10084616c:     	b.hi	0x100844fa4 <_js_json_stringify_full+0x5a4>
100846170:     	ldr	w8, [x25, #0x4]
100846174:     	mov	w9, #-0x40000000        ; =-1073741824
100846178:     	cmp	w8, w9
10084617c:     	csel	w8, w8, wzr, lt
100846180:     	mov	x22, x0
100846184:     	mov	x0, x8
100846188:     	bl	0x1005e3da4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084618c:     	mov	w9, #0x2                ; =2
100846190:     	cmp	w1, #0x2
100846194:     	csel	w10, w1, w9, hi
100846198:     	tst	w0, #0x1
10084619c:     	csel	w8, w10, w9, ne
1008461a0:     	cmp	w20, w8
1008461a4:     	b.hi	0x100844fa4 <_js_json_stringify_full+0x5a4>
1008461a8:     	mov	x0, x22
1008461ac:     	mov	x1, x20
1008461b0:     	bl	0x1004ee640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008461b4:     	cbz	w0, 0x100844fa4 <_js_json_stringify_full+0x5a4>
1008461b8:     	and	x0, x19, #0xffffffffffff
1008461bc:     	mov	x1, x20
1008461c0:     	bl	0x1004f67c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
1008461c4:     	b	0x1008461d0 <_js_json_stringify_full+0x17d0>
1008461c8:     	and	x0, x19, #0xffffffffffff
1008461cc:     	bl	0x1004f7540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
1008461d0:     	mov	x20, x1
1008461d4:     	tbz	w0, #0x0, 0x100844fa4 <_js_json_stringify_full+0x5a4>
1008461d8:     	b	0x100845ea8 <_js_json_stringify_full+0x14a8>
1008461dc:     	add	x9, x8, #0x60
1008461e0:     	b	0x100846468 <_js_json_stringify_full+0x1a68>
1008461e4:     	bl	0x100b3e87c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008461e8:     	lsr	x1, x23, #20
1008461ec:     	ldr	x8, [x0, #0x10]
1008461f0:     	ldrb	w9, [x8]
1008461f4:     	cmp	w9, #0x2
1008461f8:     	b.eq	0x100845588 <_js_json_stringify_full+0xb88>
1008461fc:     	ldr	x9, [x8, #0x8]
100846200:     	ldr	x10, [x8, #0x28]
100846204:     	sub	x9, x1, x9
100846208:     	cmp	x9, x10
10084620c:     	b.hs	0x100846250 <_js_json_stringify_full+0x1850>
100846210:     	ldr	x10, [x8, #0x20]
100846214:     	mov	w11, #0x28              ; =40
100846218:     	madd	x9, x9, x11, x10
10084621c:     	ldr	x10, [x9]
100846220:     	ldr	x11, [x8, #0x10]
100846224:     	cmp	x10, x11
100846228:     	b.ne	0x10084625c <_js_json_stringify_full+0x185c>
10084622c:     	ldp	x10, x11, [x9, #0x8]
100846230:     	cmp	x10, x23
100846234:     	ccmp	x11, x23, #0x0, ls
100846238:     	b.ls	0x10084625c <_js_json_stringify_full+0x185c>
10084623c:     	ldr	x10, [x8, #0x30]
100846240:     	add	x10, x10, #0x1
100846244:     	str	x10, [x8, #0x30]
100846248:     	add	x8, x9, #0x21
10084624c:     	b	0x100846478 <_js_json_stringify_full+0x1a78>
100846250:     	ldr	x9, [x8, #0x58]
100846254:     	add	x9, x9, #0x1
100846258:     	str	x9, [x8, #0x58]
10084625c:     	ldr	x9, [x8, #0x38]
100846260:     	add	x9, x9, #0x1
100846264:     	str	x9, [x8, #0x38]
100846268:     	mov	x0, x23
10084626c:     	bl	0x10051ca08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100846270:     	and	w8, w0, #0xff
100846274:     	cbz	w8, 0x100846294 <_js_json_stringify_full+0x1894>
100846278:     	ldurb	w8, [x23, #-0x8]
10084627c:     	ldurb	w9, [x23, #-0x7]
100846280:     	mov	w10, #0x82              ; =130
100846284:     	and	w9, w9, w10
100846288:     	cmp	w9, #0x2
10084628c:     	ccmp	w8, #0x1, #0x0, eq
100846290:     	b.eq	0x100846328 <_js_json_stringify_full+0x1928>
100846294:     	mov	x0, x23
100846298:     	bl	0x100579080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084629c:     	mov	x24, x0
1008462a0:     	cbz	x0, 0x1008462cc <_js_json_stringify_full+0x18cc>
1008462a4:     	ldrb	w8, [x24]
1008462a8:     	cmp	w8, #0x1
1008462ac:     	b.ne	0x1008462ec <_js_json_stringify_full+0x18ec>
1008462b0:     	ldrsb	w8, [x24, #0x1]
1008462b4:     	tbnz	w8, #0x1f, 0x100846350 <_js_json_stringify_full+0x1950>
1008462b8:     	mov	x0, x24
1008462bc:     	ldp	w9, w8, [x23]
1008462c0:     	cmp	w9, w8
1008462c4:     	b.hi	0x1008463d4 <_js_json_stringify_full+0x19d4>
1008462c8:     	b	0x1008463ec <_js_json_stringify_full+0x19ec>
1008462cc:     	mov	x0, x23
1008462d0:     	bl	0x1005878b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1008462d4:     	tbnz	w0, #0x0, 0x1008462e4 <_js_json_stringify_full+0x18e4>
1008462d8:     	mov	x0, x23
1008462dc:     	bl	0x1002a27c8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
1008462e0:     	tbz	w0, #0x0, 0x100845628 <_js_json_stringify_full+0xc28>
1008462e4:     	mov	x0, #0x0                ; =0
1008462e8:     	b	0x1008463c4 <_js_json_stringify_full+0x19c4>
1008462ec:     	mov	x0, x24
1008462f0:     	cmp	w8, #0x1
1008462f4:     	b.eq	0x1008463c4 <_js_json_stringify_full+0x19c4>
1008462f8:     	cmp	w8, #0x9
1008462fc:     	b.ne	0x100845628 <_js_json_stringify_full+0xc28>
100846300:     	ldr	w8, [x23, #0x4]
100846304:     	mov	w9, #0x5841             ; =22593
100846308:     	movk	w9, #0x4c5a, lsl #16
10084630c:     	cmp	w8, w9
100846310:     	b.ne	0x100845628 <_js_json_stringify_full+0xc28>
100846314:     	mov	x0, x23
100846318:     	bl	0x1003746d0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
10084631c:     	mov	x23, x0
100846320:     	cbnz	x0, 0x100846414 <_js_json_stringify_full+0x1a14>
100846324:     	b	0x100845628 <_js_json_stringify_full+0xc28>
100846328:     	ldr	w8, [x23]
10084632c:     	mov	w9, #0xe100             ; =57600
100846330:     	movk	w9, #0x5f5, lsl #16
100846334:     	orr	w9, w9, #0x1
100846338:     	cmp	w8, w9
10084633c:     	b.hs	0x100846294 <_js_json_stringify_full+0x1894>
100846340:     	ldr	w9, [x23, #0x4]
100846344:     	cmp	w8, w9
100846348:     	b.ls	0x100846414 <_js_json_stringify_full+0x1a14>
10084634c:     	b	0x100846294 <_js_json_stringify_full+0x1894>
100846350:     	ldr	x23, [x24, #0x8]
100846354:     	mov	x0, x23
100846358:     	bl	0x100579080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084635c:     	cbz	x0, 0x100845628 <_js_json_stringify_full+0xc28>
100846360:     	ldrb	w8, [x0]
100846364:     	cmp	w8, #0x1
100846368:     	b.ne	0x100845628 <_js_json_stringify_full+0xc28>
10084636c:     	ldrsb	w8, [x0, #0x1]
100846370:     	tbz	w8, #0x1f, 0x1008462bc <_js_json_stringify_full+0x18bc>
100846374:     	mov	w26, #0x1               ; =1
100846378:     	ldr	x23, [x0, #0x8]
10084637c:     	mov	x0, x23
100846380:     	bl	0x100579080 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100846384:     	cbz	x0, 0x100845628 <_js_json_stringify_full+0xc28>
100846388:     	ldrb	w8, [x0]
10084638c:     	cmp	w8, #0x1
100846390:     	b.ne	0x100845628 <_js_json_stringify_full+0xc28>
100846394:     	cmp	w26, #0x3f
100846398:     	b.hi	0x100845628 <_js_json_stringify_full+0xc28>
10084639c:     	add	w26, w26, #0x1
1008463a0:     	ldrsb	w8, [x0, #0x1]
1008463a4:     	tbnz	w8, #0x1f, 0x100846378 <_js_json_stringify_full+0x1978>
1008463a8:     	str	x23, [x24, #0x8]
1008463ac:     	ldrb	w8, [x24, #0x1]
1008463b0:     	orr	w8, w8, #0x80
1008463b4:     	strb	w8, [x24, #0x1]
1008463b8:     	ldrb	w8, [x0]
1008463bc:     	cmp	w8, #0x1
1008463c0:     	b.ne	0x1008462f8 <_js_json_stringify_full+0x18f8>
1008463c4:     	ldp	w9, w8, [x23]
1008463c8:     	cmp	w9, w8
1008463cc:     	b.ls	0x1008463ec <_js_json_stringify_full+0x19ec>
1008463d0:     	cbz	x24, 0x1008463fc <_js_json_stringify_full+0x19fc>
1008463d4:     	ldr	w9, [x0, #0x4]
1008463d8:     	ubfiz	x8, x8, #3, #32
1008463dc:     	add	x8, x8, #0x10
1008463e0:     	cmp	x8, x9
1008463e4:     	b.eq	0x100846414 <_js_json_stringify_full+0x1a14>
1008463e8:     	b	0x1008463fc <_js_json_stringify_full+0x19fc>
1008463ec:     	mov	w8, #0xe100             ; =57600
1008463f0:     	movk	w8, #0x5f5, lsl #16
1008463f4:     	cmp	w9, w8
1008463f8:     	b.ls	0x100846414 <_js_json_stringify_full+0x1a14>
1008463fc:     	mov	x0, x23
100846400:     	bl	0x1005878b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100846404:     	tbnz	w0, #0x0, 0x100846414 <_js_json_stringify_full+0x1a14>
100846408:     	mov	x0, x23
10084640c:     	bl	0x1002a27c8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100846410:     	tbz	w0, #0x0, 0x100845628 <_js_json_stringify_full+0xc28>
100846414:     	ldp	w8, w9, [x23]
100846418:     	sub	w10, w9, #0x1
10084641c:     	mov	w11, #0x270f            ; =9999
100846420:     	cmp	w10, w11
100846424:     	ccmp	w8, w9, #0x2, lo
100846428:     	b.hi	0x100845628 <_js_json_stringify_full+0xc28>
10084642c:     	and	x8, x21, #0xffffffffffff
100846430:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846434:     	cmp	x25, x9
100846438:     	csel	x1, x8, x21, eq
10084643c:     	add	x0, sp, #0x30
100846440:     	bl	0x1004fe17c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
100846444:     	ldr	x25, [sp, #0x30]
100846448:     	cmn	x25, #0x1
10084644c:     	cset	w24, eq
100846450:     	cmp	x27, #0x1
100846454:     	cset	w8, hi
100846458:     	tst	w8, w24
10084645c:     	b.ne	0x100845644 <_js_json_stringify_full+0xc44>
100846460:     	b	0x1008456b4 <_js_json_stringify_full+0xcb4>
100846464:     	add	x9, x8, #0x90
100846468:     	ldr	x10, [x8, #0x30]
10084646c:     	add	x10, x10, #0x1
100846470:     	str	x10, [x8, #0x30]
100846474:     	add	x8, x9, #0x19
100846478:     	ldrb	w8, [x8]
10084647c:     	cmp	w8, #0xff
100846480:     	b.ne	0x100846274 <_js_json_stringify_full+0x1874>
100846484:     	b	0x100846268 <_js_json_stringify_full+0x1868>
100846488:     	mov	x0, x23
10084648c:     	bl	0x100b1da04 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100846490:     	cbnz	x0, 0x1008457d0 <_js_json_stringify_full+0xdd0>
100846494:     	b	0x100846610 <_js_json_stringify_full+0x1c10>
100846498:     	and	x0, x19, #0xffffffffffff
10084649c:     	bl	0x1004f65f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
1008464a0:     	mov	w0, w0
1008464a4:     	mov	x20, #0x7d7b            ; =32123
1008464a8:     	movk	x20, #0x200, lsl #32
1008464ac:     	movk	x20, #0x7ff9, lsl #48
1008464b0:     	tbz	w0, #0x0, 0x100844fd8 <_js_json_stringify_full+0x5d8>
1008464b4:     	b	0x100845ea8 <_js_json_stringify_full+0x14a8>
1008464b8:     	mov	x19, x0
1008464bc:     	mov	x0, x23
1008464c0:     	bl	0x100b1da04 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008464c4:     	mov	x23, x0
1008464c8:     	mov	x0, x19
1008464cc:     	cbnz	x23, 0x100845db4 <_js_json_stringify_full+0x13b4>
1008464d0:     	b	0x1008465b0 <_js_json_stringify_full+0x1bb0>
1008464d4:     	bl	0x100b1db64 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
1008464d8:     	cbnz	x0, 0x1008456f8 <_js_json_stringify_full+0xcf8>
1008464dc:     	b	0x100846610 <_js_json_stringify_full+0x1c10>
1008464e0:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1008464e4:     	add	x0, x0, #0x440
1008464e8:     	bl	0x100b11bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008464ec:     	cmp	w8, #0x1
1008464f0:     	b.ne	0x100846610 <_js_json_stringify_full+0x1c10>
1008464f4:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime10perf_hooks8ObserverEEEB2h_+0x7c>
1008464f8:     	add	x1, x1, #0x358
1008464fc:     	mov	x19, x0
100846500:     	bl	0x100a1f8dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100846504:     	mov	x0, x19
100846508:     	strb	wzr, [x19, #0x20]
10084650c:     	ldr	x8, [x19]
100846510:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100846514:     	cmp	x8, x9
100846518:     	b.lo	0x100845918 <_js_json_stringify_full+0xf18>
10084651c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100846520:     	add	x0, x0, #0xea8
100846524:     	bl	0x100b11bdc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100846528:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084652c:     	add	x0, x0, #0xec0
100846530:     	bl	0x100b11bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100846534:     	and	x0, x19, #0xffffffffffff
100846538:     	bl	0x1004ee240 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
10084653c:     	mov	x20, x1
100846540:     	tbz	w0, #0x0, 0x100844fd8 <_js_json_stringify_full+0x5d8>
100846544:     	b	0x100845ea8 <_js_json_stringify_full+0x14a8>
100846548:     	mov	x0, x23
10084654c:     	bl	0x100b1da04 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100846550:     	mov	x23, x0
100846554:     	cbnz	x0, 0x100845c64 <_js_json_stringify_full+0x1264>
100846558:     	b	0x1008465b0 <_js_json_stringify_full+0x1bb0>
10084655c:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100846560:     	add	x0, x0, #0xd70
100846564:     	bl	0x100b11bdc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100846568:     	bl	0x100b4ae14 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
10084656c:     	cmp	w8, #0x2
100846570:     	b.eq	0x100846610 <_js_json_stringify_full+0x1c10>
100846574:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime10perf_hooks8ObserverEEEB2h_+0x7c>
100846578:     	add	x1, x1, #0x358
10084657c:     	mov	x19, x0
100846580:     	bl	0x100a1f8dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100846584:     	mov	x0, x19
100846588:     	strb	wzr, [x19, #0x20]
10084658c:     	ldr	x8, [x19]
100846590:     	cbz	x8, 0x100845c50 <_js_json_stringify_full+0x1250>
100846594:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100846598:     	add	x0, x0, #0xe90
10084659c:     	bl	0x100b11bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008465a0:     	mov	x0, x23
1008465a4:     	bl	0x100b1da04 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008465a8:     	mov	x23, x0
1008465ac:     	cbnz	x0, 0x100845b80 <_js_json_stringify_full+0x1180>
1008465b0:     	cbz	x22, 0x100846610 <_js_json_stringify_full+0x1c10>
1008465b4:     	mov	x0, x19
1008465b8:     	bl	0x100b5e480 <_mi_free>
1008465bc:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1008465c0:     	add	x0, x0, #0xc18
1008465c4:     	bl	0x100b57adc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1008465c8:     	adrp	x0, 0x100c41000 <_PERRY_EMPTY_STRING+0x5b4>
1008465cc:     	add	x0, x0, #0x970
1008465d0:     	mov	w1, #0xf                ; =15
1008465d4:     	bl	0x100b4addc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
1008465d8:     	and	x0, x19, #0xffffffffffff
1008465dc:     	add	x2, sp, #0x80
1008465e0:     	mov	x1, x22
1008465e4:     	bl	0x1004eea40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
1008465e8:     	tbnz	w0, #0x0, 0x100846014 <_js_json_stringify_full+0x1614>
1008465ec:     	mov	w20, #0x2               ; =2
1008465f0:     	and	x0, x19, #0xffffffffffff
1008465f4:     	mov	x1, x20
1008465f8:     	bl	0x1004ed0c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
1008465fc:     	mov	x20, x1
100846600:     	tbz	w0, #0x0, 0x100844fd8 <_js_json_stringify_full+0x5d8>
100846604:     	b	0x100845ea8 <_js_json_stringify_full+0x14a8>
100846608:     	cmp	w8, #0x2
10084660c:     	b.ne	0x100846638 <_js_json_stringify_full+0x1c38>
100846610:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100846614:     	add	x0, x0, #0xc18
100846618:     	bl	0x100b57adc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084661c:     	adrp	x0, 0x100f2b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x190>
100846620:     	add	x0, x0, #0x848
100846624:     	bl	0x100b11c70 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100846628:     	adrp	x0, 0x100c41000 <_PERRY_EMPTY_STRING+0x5b4>
10084662c:     	add	x0, x0, #0x6a7
100846630:     	mov	w1, #0xb                ; =11
100846634:     	bl	0x100b4addc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100846638:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime10perf_hooks8ObserverEEEB2h_+0x7c>
10084663c:     	add	x1, x1, #0x358
100846640:     	mov	x19, x0
100846644:     	bl	0x100a1f8dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100846648:     	mov	x0, x19
10084664c:     	strb	wzr, [x19, #0x20]
100846650:     	ldr	x8, [x19]
100846654:     	cbz	x8, 0x100845b6c <_js_json_stringify_full+0x116c>
100846658:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084665c:     	add	x0, x0, #0xe78
100846660:     	bl	0x100b11bac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100846664:     	mov	w0, #0x1                ; =1
100846668:     	mov	x1, x24
10084666c:     	bl	0x100b11800 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100846670:     	mov	w0, #0x1                ; =1
100846674:     	mov	x1, x22
100846678:     	bl	0x100b11800 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084667c:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100846680:     	add	x2, x2, #0x3c8
100846684:     	mov	w0, #0x5                ; =5
100846688:     	mov	w1, #0x5                ; =5
10084668c:     	bl	0x100b11d0c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
