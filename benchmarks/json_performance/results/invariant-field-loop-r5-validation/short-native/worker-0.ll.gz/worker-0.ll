; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/invariant-field-loop-r5/short-native/.perry-trace/llvm/short_loops_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@short_loops_ts_.str.0 = private unnamed_addr constant [121 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/invariant-field-loop-r5/short-loops.ts\00"
@short_loops_ts_.str.0.bytes = private unnamed_addr constant [3 x i8] c"id\00"
@short_loops_ts_.str.1.bytes = private unnamed_addr constant [3 x i8] c"fs\00"
@short_loops_ts_.str.2.bytes = private unnamed_addr constant [13 x i8] c"readFileSync\00"
@short_loops_ts_.str.3.bytes = private unnamed_addr constant [5 x i8] c"utf8\00"
@short_loops_ts_.str.4.bytes = private unnamed_addr constant [4 x i8] c"rss\00"
@short_loops_ts_.str.5.bytes = private unnamed_addr constant [7 x i8] c"RESULT\00"
@short_loops_ts_.str.6.bytes = private unnamed_addr constant [5 x i8] c"user\00"
@short_loops_ts_.str.7.bytes = private unnamed_addr constant [7 x i8] c"system\00"
@short_loops_ts_.str.8.bytes = private unnamed_addr constant [5 x i8] c"KEEP\00"
@short_loops_ts_.str.9.bytes = private unnamed_addr constant [7 x i8] c"length\00"
@short_loops_ts_.str.1 = private unnamed_addr constant [4 x i8] c"sum\00"
@short_loops_ts_.str.2 = private unnamed_addr constant [4 x i8] c"run\00"
@short_loops_ts_.str.3 = private unnamed_addr constant [145 x i8] c"function sum(rows: any, count: number): number {\0A    let value = 0;\0A    for (let i = 0; i < count; i++) value += rows[7].id;\0A    return value;\0A}\00"
@short_loops_ts_.str.4 = private unnamed_addr constant [179 x i8] c"function run(rows: any, repeats: number, count: number): number {\0A    let checksum = 0;\0A    for (let i = 0; i < repeats; i++) checksum += sum(rows, count);\0A    return checksum;\0A}\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_short_loops_ts = internal global i32 0
@perry_ic_short_loops_ts__0 = private global ptr null
@perry_ic_short_loops_ts__2 = private global ptr null
@perry_ic_short_loops_ts__3 = private global ptr null
@perry_ic_short_loops_ts__5 = private global ptr null
@perry_ic_short_loops_ts__11 = private global ptr null
@perry_ic_short_loops_ts__13 = private global ptr null
@perry_ic_short_loops_ts__15 = private global ptr null
@perry_ic_short_loops_ts__17 = private global ptr null
@perry_ic_short_loops_ts__19 = private global ptr null
@perry_ic_short_loops_ts__21 = private global ptr null
@perry_ic_short_loops_ts__23 = private global ptr null
@short_loops_ts_.str.0.handle = internal global double 0.000000e+00
@short_loops_ts_.str.1.handle = internal global double 0.000000e+00
@short_loops_ts_.str.2.handle = internal global double 0.000000e+00
@short_loops_ts_.str.3.handle = internal global double 0.000000e+00
@short_loops_ts_.str.4.handle = internal global double 0.000000e+00
@short_loops_ts_.str.5.handle = internal global double 0.000000e+00
@short_loops_ts_.str.6.handle = internal global double 0.000000e+00
@short_loops_ts_.str.7.handle = internal global double 0.000000e+00
@short_loops_ts_.str.8.handle = internal global double 0.000000e+00
@short_loops_ts_.str.9.handle = internal global double 0.000000e+00

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare double @js_array_index_own_number(double, i32, ptr, i64)

declare double @js_json_lazy_index_scalar(double, double, ptr, i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_2()

declare double @__ic_decl_5()

declare double @__ic_decl_11()

declare double @__ic_decl_13()

declare double @__ic_decl_15()

declare double @__ic_decl_17()

declare double @__ic_decl_19()

declare double @__ic_decl_21()

declare double @__ic_decl_23()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define internal double @"perry_fn_short_loops_ts__sum$spec_b_b"(double %arg11, double %arg12) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b2 = bitcast double %arg11 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg12 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #9
  %r5 = bitcast i64 %r5.rs4o to double
  %r6 = bitcast double %r5 to i64
  %r7 = and i64 %r6, -281474976710656
  %r8 = icmp ult i64 %r7, 9221401712017801216
  %r9 = icmp ugt i64 %r7, 9223090561878065152
  %r10 = or i1 %r8, %r9
  br i1 %r10, label %invariant_field.range.3, label %invariant_field.slow.1

invariant_field.slow.1:                           ; preds = %invariant_field.probe.5, %invariant_field.convert.4, %invariant_field.range.3, %entry.0
  %r42.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r42.rs4o = call i64 asm "", "=r,0"(i64 %r42.rs4i) #9
  %r42 = bitcast i64 %r42.rs4o to double
  %r43 = bitcast double %r42 to i64
  %r44 = and i64 %r43, -281474976710656
  %r45 = icmp ult i64 %r44, 9221401712017801216
  %r46 = icmp ugt i64 %r44, 9223090561878065152
  %r47 = or i1 %r45, %r46
  br i1 %r47, label %for.invariant_field_slow.bound_i32.number.9, label %for.invariant_field_slow.bound_i32.merge.11

invariant_field.merge.2:                          ; preds = %for.invariant_field_slow.exit.17, %invariant_field.fast.exit.8
  %r3.0 = phi ptr addrspace(1) [ %rs4gc.s5, %invariant_field.fast.exit.8 ], [ %.148, %for.invariant_field_slow.exit.17 ]
  %r581.rs4i = ptrtoint ptr addrspace(1) %r3.0 to i64
  %r581.rs4o = call i64 asm "", "=r,0"(i64 %r581.rs4i) #9
  %r581 = bitcast i64 %r581.rs4o to double
  ret double %r581

invariant_field.range.3:                          ; preds = %entry.0
  %r11 = fcmp ogt double %r5, 0.000000e+00
  %r12 = fcmp ole double %r5, 0x41DFFFFFFFC00000
  %r13 = and i1 %r11, %r12
  br i1 %r13, label %invariant_field.convert.4, label %invariant_field.slow.1

invariant_field.convert.4:                        ; preds = %invariant_field.range.3
  %r14 = fptosi double %r5 to i32
  %r15 = sitofp i32 %r14 to double
  %r16 = fcmp oeq double %r5, %r15
  br i1 %r16, label %invariant_field.probe.5, label %invariant_field.slow.1

invariant_field.probe.5:                          ; preds = %invariant_field.convert.4
  %r17.rs4o = call i64 asm "", "=r,0"(i64 0) #9
  %r17 = bitcast i64 %r17.rs4o to double
  %r18 = bitcast double %r17 to i64
  %r19 = and i64 %r18, -281474976710656
  %r20 = icmp ult i64 %r19, 9221401712017801216
  %r21 = icmp ugt i64 %r19, 9223090561878065152
  %r22 = or i1 %r20, %r21
  %r23.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r23.rs4o = call i64 asm "", "=r,0"(i64 %r23.rs4i) #9
  %r23 = bitcast i64 %r23.rs4o to double
  %r24 = call double @js_array_index_own_number(double %r23, i32 7, ptr @short_loops_ts_.str.0.bytes, i64 2) #9
  %r25 = bitcast double %r24 to i64
  %r26 = and i64 %r25, -281474976710656
  %r27 = icmp ult i64 %r26, 9221401712017801216
  %r28 = icmp ugt i64 %r26, 9223090561878065152
  %r29 = or i1 %r27, %r28
  %r30 = and i1 %r22, %r29
  br i1 %r30, label %invariant_field.fast.preheader.6, label %invariant_field.slow.1

invariant_field.fast.preheader.6:                 ; preds = %invariant_field.probe.5
  %r583.rs4o = call i64 asm "", "=r,0"(i64 0) #9
  %r583 = bitcast i64 %r583.rs4o to double
  br label %invariant_field.fast.body.7

invariant_field.fast.body.7:                      ; preds = %invariant_field.fast.body.7, %invariant_field.fast.preheader.6
  %r32.0 = phi i32 [ 0, %invariant_field.fast.preheader.6 ], [ %r36, %invariant_field.fast.body.7 ]
  %r31.0 = phi double [ %r583, %invariant_field.fast.preheader.6 ], [ %r34, %invariant_field.fast.body.7 ]
  %r34 = fadd double %r31.0, %r24
  %r36 = add i32 %r32.0, 1
  %r37 = icmp slt i32 %r36, %r14
  br i1 %r37, label %invariant_field.fast.body.7, label %invariant_field.fast.exit.8

invariant_field.fast.exit.8:                      ; preds = %invariant_field.fast.body.7
  %rs4gc.b5 = bitcast double %r34 to i64
  %rs4gc.s5 = inttoptr i64 %rs4gc.b5 to ptr addrspace(1)
  %r38 = sitofp i32 %r36 to double
  br label %invariant_field.merge.2

for.invariant_field_slow.bound_i32.number.9:      ; preds = %invariant_field.slow.1
  %r48 = fcmp oge double %r42, 0xC1E0000000000000
  %r49 = fcmp ole double %r42, 0x41DFFFFFFFC00000
  %r50 = and i1 %r48, %r49
  br i1 %r50, label %for.invariant_field_slow.bound_i32.convert.10, label %for.invariant_field_slow.bound_i32.merge.11

for.invariant_field_slow.bound_i32.convert.10:    ; preds = %for.invariant_field_slow.bound_i32.number.9
  %r51 = fptosi double %r42 to i32
  %r52 = sitofp i32 %r51 to double
  %r53 = fcmp oeq double %r52, %r42
  br i1 %r53, label %for.invariant_field_slow.counter_i32.range.12, label %for.invariant_field_slow.bound_i32.merge.11

for.invariant_field_slow.bound_i32.merge.11:      ; preds = %for.invariant_field_slow.counter_i32.convert.13, %for.invariant_field_slow.bound_i32.convert.10, %for.invariant_field_slow.bound_i32.number.9, %invariant_field.slow.1
  %r41.0 = phi i32 [ %r51, %for.invariant_field_slow.counter_i32.convert.13 ], [ 0, %invariant_field.slow.1 ], [ %r51, %for.invariant_field_slow.bound_i32.convert.10 ], [ 0, %for.invariant_field_slow.bound_i32.number.9 ]
  %r40.0 = phi i1 [ true, %for.invariant_field_slow.counter_i32.convert.13 ], [ false, %invariant_field.slow.1 ], [ false, %for.invariant_field_slow.bound_i32.convert.10 ], [ false, %for.invariant_field_slow.bound_i32.number.9 ]
  br label %for.invariant_field_slow.cond.14

for.invariant_field_slow.counter_i32.range.12:    ; preds = %for.invariant_field_slow.bound_i32.convert.10
  br label %for.invariant_field_slow.counter_i32.convert.13

for.invariant_field_slow.counter_i32.convert.13:  ; preds = %for.invariant_field_slow.counter_i32.range.12
  br label %for.invariant_field_slow.bound_i32.merge.11

for.invariant_field_slow.cond.14:                 ; preds = %for.invariant_field_slow.update.16, %for.invariant_field_slow.bound_i32.merge.11
  %.038 = phi ptr addrspace(1) [ %rs4gc.s2, %for.invariant_field_slow.bound_i32.merge.11 ], [ %.846, %for.invariant_field_slow.update.16 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %for.invariant_field_slow.bound_i32.merge.11 ], [ %.8, %for.invariant_field_slow.update.16 ]
  %r39.1 = phi i32 [ 0, %for.invariant_field_slow.bound_i32.merge.11 ], [ %r580, %for.invariant_field_slow.update.16 ]
  %r4.0 = phi double [ 0.000000e+00, %for.invariant_field_slow.bound_i32.merge.11 ], [ %r578, %for.invariant_field_slow.update.16 ]
  %r3.1 = phi ptr addrspace(1) [ null, %for.invariant_field_slow.bound_i32.merge.11 ], [ %.054, %for.invariant_field_slow.update.16 ]
  br i1 %r40.0, label %for.invariant_field_slow.cond.fast.18, label %for.invariant_field_slow.cond.slow.19

for.invariant_field_slow.body.15:                 ; preds = %gcpoll.done.21, %for.invariant_field_slow.cond.fast.18
  %.047 = phi ptr addrspace(1) [ %r3.1, %for.invariant_field_slow.cond.fast.18 ], [ %.249, %gcpoll.done.21 ]
  %.139 = phi ptr addrspace(1) [ %.038, %for.invariant_field_slow.cond.fast.18 ], [ %.240, %gcpoll.done.21 ]
  %.1 = phi ptr addrspace(1) [ %.0, %for.invariant_field_slow.cond.fast.18 ], [ %.2, %gcpoll.done.21 ]
  %r73.rs4i = ptrtoint ptr addrspace(1) %.047 to i64
  %r73.rs4o = call i64 asm "", "=r,0"(i64 %r73.rs4i) #9
  %r73 = bitcast i64 %r73.rs4o to double
  %r74 = bitcast double %r73 to i64
  %rs4gc.s6 = inttoptr i64 %r74 to ptr addrspace(1)
  %r76.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r76 = call i64 asm "", "=r,0"(i64 %r76.rs4i) #9
  %r77 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r78 = icmp ne i32 %r77, 0
  br i1 %r78, label %shadow.root.barrier.22, label %shadow.root.barrier.done.23

for.invariant_field_slow.update.16:               ; preds = %gcpoll.done.120
  %r578 = fadd double %r4.0, 1.000000e+00
  %r580 = add i32 %r39.1, 1
  br label %for.invariant_field_slow.cond.14

for.invariant_field_slow.exit.17:                 ; preds = %gcpoll.done.21, %for.invariant_field_slow.cond.fast.18
  %.148 = phi ptr addrspace(1) [ %r3.1, %for.invariant_field_slow.cond.fast.18 ], [ %.249, %gcpoll.done.21 ]
  br label %invariant_field.merge.2

for.invariant_field_slow.cond.fast.18:            ; preds = %for.invariant_field_slow.cond.14
  %r64 = icmp slt i32 %r39.1, %r41.0
  br i1 %r64, label %for.invariant_field_slow.body.15, label %for.invariant_field_slow.exit.17

for.invariant_field_slow.cond.slow.19:            ; preds = %for.invariant_field_slow.cond.14
  %r66.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r66.rs4o = call i64 asm "", "=r,0"(i64 %r66.rs4i) #9
  %r66 = bitcast i64 %r66.rs4o to double
  %r67 = fcmp olt double %r4.0, %r66
  %r68 = select i1 %r67, i64 9222246136947933188, i64 9222246136947933187
  %r69 = bitcast i64 %r68 to double
  %r71 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r72 = icmp ne i32 %r71, 0
  br i1 %r72, label %gcpoll.20, label %gcpoll.done.21

gcpoll.20:                                        ; preds = %for.invariant_field_slow.cond.slow.19
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0, ptr addrspace(1) %.038, ptr addrspace(1) %r3.1) ]
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%.0, %.0)
  %rs4gc.s2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%.038, %.038)
  %r3.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 2, i32 2) ; (%r3.1, %r3.1)
  br label %gcpoll.done.21

gcpoll.done.21:                                   ; preds = %gcpoll.20, %for.invariant_field_slow.cond.slow.19
  %.249 = phi ptr addrspace(1) [ %r3.1.relocated, %gcpoll.20 ], [ %r3.1, %for.invariant_field_slow.cond.slow.19 ]
  %.240 = phi ptr addrspace(1) [ %rs4gc.s2.relocated, %gcpoll.20 ], [ %.038, %for.invariant_field_slow.cond.slow.19 ]
  %.2 = phi ptr addrspace(1) [ %rs4gc.s3.relocated, %gcpoll.20 ], [ %.0, %for.invariant_field_slow.cond.slow.19 ]
  %r70 = icmp eq i64 %r68, 9222246136947933188
  br i1 %r70, label %for.invariant_field_slow.body.15, label %for.invariant_field_slow.exit.17

shadow.root.barrier.22:                           ; preds = %for.invariant_field_slow.body.15
  call void @js_write_barrier_root_nanbox(i64 %r76) #9
  br label %shadow.root.barrier.done.23

shadow.root.barrier.done.23:                      ; preds = %shadow.root.barrier.22, %for.invariant_field_slow.body.15
  %r79.rs4i = ptrtoint ptr addrspace(1) %.139 to i64
  %r79.rs4o = call i64 asm "", "=r,0"(i64 %r79.rs4i) #9
  %r79 = bitcast i64 %r79.rs4o to double
  %r80 = bitcast double %r79 to i64
  %r81 = and i64 %r80, 281474976710655
  %r82 = and i64 %r80, -281474976710656
  %r83 = icmp eq i64 %r82, 9222527611924643840
  %r84 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r85 = icmp eq i64 %r84, 0
  %r86 = icmp ugt i64 %r81, 1048575
  %r87 = icmp ult i64 %r81, 140737488355328
  %r88 = and i1 %r86, %r87
  %r89 = and i1 %r83, %r85
  %r90 = and i1 %r89, %r88
  br i1 %r90, label %tav.get.brand.28, label %tav.get.slow.26

tav.get.fast.24:                                  ; preds = %tav.get.brand.28
  %r107 = bitcast double %r79 to i64
  %r108 = and i64 %r107, 281474976710655
  %r109 = add nuw nsw i64 %r108, 8
  %r110 = inttoptr i64 %r109 to ptr
  %r111 = load i8, ptr %r110, align 1
  %r112 = zext i8 %r111 to i64
  %r116 = inttoptr i64 %r108 to ptr
  %r117 = load i32, ptr %r116, align 4
  %r118 = zext i32 %r117 to i64
  %r119 = icmp ult i64 7, %r118
  %r120 = and i1 true, %r119
  br i1 %r120, label %tav.get.load.25, label %tav.get.slow.26

tav.get.load.25:                                  ; preds = %tav.get.fast.24
  %r121 = add nuw nsw i64 %r108, 16
  %r122 = icmp eq i64 %r112, 0
  br i1 %r122, label %tav.k.i8.29, label %tav.kd1.37

tav.get.slow.26:                                  ; preds = %tav.get.brand.28, %tav.get.fast.24, %shadow.root.barrier.done.23
  %r173 = load ptr, ptr @perry_ic_short_loops_ts__0, align 8
  %r174 = icmp ne ptr %r173, null
  %r175 = select i1 %r174, ptr %r173, ptr @perry_ic_short_loops_ts__0
  %r176 = bitcast double %r79 to i64
  %r177 = and i64 %r176, 281474976710655
  %r178 = and i64 %r176, -281474976710656
  %r179 = icmp eq i64 %r178, 9222527611924643840
  %r180 = icmp uge i64 %r177, 2199023255552
  %r181 = icmp ult i64 %r177, 140737488355328
  %r184 = and i1 %r179, %r180
  %r185 = and i1 %r184, %r181
  br i1 %r185, label %arrlike.ic.header.44, label %arrlike.ic.miss.63

tav.get.merge.27:                                 ; preds = %json.scalar.exposed.76, %arrlike.elem.value.69, %arrlike.ic.miss.63, %arrlike.ic.spill_load.62, %arrlike.ic.inline.59, %arrlike.ic.array_load.47, %tav.k.f64.36, %tav.k.f32.35, %tav.k.u32.34, %tav.k.i32.33, %tav.k.u16.32, %tav.k.i16.31, %tav.k.u8.30, %tav.k.i8.29
  %.050 = phi ptr addrspace(1) [ %rs4gc.s6, %tav.k.i8.29 ], [ %rs4gc.s6, %tav.k.u8.30 ], [ %rs4gc.s6, %tav.k.i16.31 ], [ %rs4gc.s6, %tav.k.u16.32 ], [ %rs4gc.s6, %tav.k.i32.33 ], [ %rs4gc.s6, %tav.k.u32.34 ], [ %rs4gc.s6, %tav.k.f32.35 ], [ %rs4gc.s6, %tav.k.f64.36 ], [ %rs4gc.s6, %arrlike.ic.array_load.47 ], [ %rs4gc.s6.relocated, %arrlike.ic.miss.63 ], [ %rs4gc.s6, %arrlike.elem.value.69 ], [ %rs4gc.s6, %arrlike.ic.inline.59 ], [ %rs4gc.s6, %arrlike.ic.spill_load.62 ], [ %rs4gc.s6, %json.scalar.exposed.76 ]
  %.341 = phi ptr addrspace(1) [ %.139, %tav.k.i8.29 ], [ %.139, %tav.k.u8.30 ], [ %.139, %tav.k.i16.31 ], [ %.139, %tav.k.u16.32 ], [ %.139, %tav.k.i32.33 ], [ %.139, %tav.k.u32.34 ], [ %.139, %tav.k.f32.35 ], [ %.139, %tav.k.f64.36 ], [ %.139, %arrlike.ic.array_load.47 ], [ %rs4gc.s2.relocated4, %arrlike.ic.miss.63 ], [ %.139, %arrlike.elem.value.69 ], [ %.139, %arrlike.ic.inline.59 ], [ %.139, %arrlike.ic.spill_load.62 ], [ %.139, %json.scalar.exposed.76 ]
  %.3 = phi ptr addrspace(1) [ %.1, %tav.k.i8.29 ], [ %.1, %tav.k.u8.30 ], [ %.1, %tav.k.i16.31 ], [ %.1, %tav.k.u16.32 ], [ %.1, %tav.k.i32.33 ], [ %.1, %tav.k.u32.34 ], [ %.1, %tav.k.f32.35 ], [ %.1, %tav.k.f64.36 ], [ %.1, %arrlike.ic.array_load.47 ], [ %rs4gc.s3.relocated3, %arrlike.ic.miss.63 ], [ %.1, %arrlike.elem.value.69 ], [ %.1, %arrlike.ic.inline.59 ], [ %.1, %arrlike.ic.spill_load.62 ], [ %.1, %json.scalar.exposed.76 ]
  %r408 = phi double [ %r135, %tav.k.i8.29 ], [ %r141, %tav.k.u8.30 ], [ %r147, %tav.k.i16.31 ], [ %r153, %tav.k.u16.32 ], [ %r158, %tav.k.i32.33 ], [ %r163, %tav.k.u32.34 ], [ %r168, %tav.k.f32.35 ], [ %r172, %tav.k.f64.36 ], [ %r248, %json.scalar.exposed.76 ], [ %r290, %arrlike.elem.value.69 ], [ %r319, %arrlike.ic.array_load.47 ], [ %r389, %arrlike.ic.inline.59 ], [ %r406, %arrlike.ic.spill_load.62 ], [ %r4072, %arrlike.ic.miss.63 ]
  %r409 = bitcast double %r408 to i64
  %r410 = and i64 %r409, 281474976710655
  %r411 = lshr i64 %r409, 48
  %r412 = and i64 %r411, 65533
  %r413 = icmp eq i64 %r412, 32765
  br i1 %r413, label %pget.recv_ok.84, label %pget.recv_other.88

tav.get.brand.28:                                 ; preds = %shadow.root.barrier.done.23
  %r91 = bitcast double %r79 to i64
  %r92 = and i64 %r91, 281474976710655
  %r93 = sub nsw i64 %r92, 8
  %r94 = inttoptr i64 %r93 to ptr
  %r95 = load i8, ptr %r94, align 1
  %r96 = icmp eq i8 %r95, 11
  %r97 = add nuw nsw i64 %r92, 8
  %r98 = inttoptr i64 %r97 to ptr
  %r99 = load i8, ptr %r98, align 1
  %r100 = zext i8 %r99 to i64
  %r101 = icmp ule i64 %r100, 8
  %r104 = and i1 %r96, %r101
  br i1 %r104, label %tav.get.fast.24, label %tav.get.slow.26

tav.k.i8.29:                                      ; preds = %tav.get.load.25
  %r131 = add nuw nsw i64 %r121, 7
  %r132 = inttoptr i64 %r131 to ptr
  %r133 = load i8, ptr %r132, align 1
  %r134 = sext i8 %r133 to i32
  %r135 = sitofp i32 %r134 to double
  br label %tav.get.merge.27

tav.k.u8.30:                                      ; preds = %tav.kd7.43, %tav.kd1.37
  %r137 = add nuw nsw i64 %r121, 7
  %r138 = inttoptr i64 %r137 to ptr
  %r139 = load i8, ptr %r138, align 1
  %r140 = zext i8 %r139 to i32
  %r141 = uitofp nneg i32 %r140 to double
  br label %tav.get.merge.27

tav.k.i16.31:                                     ; preds = %tav.kd2.38
  %r143 = add nuw nsw i64 %r121, 14
  %r144 = inttoptr i64 %r143 to ptr
  %r145 = load i16, ptr %r144, align 2
  %r146 = sext i16 %r145 to i32
  %r147 = sitofp i32 %r146 to double
  br label %tav.get.merge.27

tav.k.u16.32:                                     ; preds = %tav.kd3.39
  %r149 = add nuw nsw i64 %r121, 14
  %r150 = inttoptr i64 %r149 to ptr
  %r151 = load i16, ptr %r150, align 2
  %r152 = zext i16 %r151 to i32
  %r153 = uitofp nneg i32 %r152 to double
  br label %tav.get.merge.27

tav.k.i32.33:                                     ; preds = %tav.kd4.40
  %r155 = add nuw nsw i64 %r121, 28
  %r156 = inttoptr i64 %r155 to ptr
  %r157 = load i32, ptr %r156, align 4
  %r158 = sitofp i32 %r157 to double
  br label %tav.get.merge.27

tav.k.u32.34:                                     ; preds = %tav.kd5.41
  %r160 = add nuw nsw i64 %r121, 28
  %r161 = inttoptr i64 %r160 to ptr
  %r162 = load i32, ptr %r161, align 4
  %r163 = uitofp i32 %r162 to double
  br label %tav.get.merge.27

tav.k.f32.35:                                     ; preds = %tav.kd6.42
  %r165 = add nuw nsw i64 %r121, 28
  %r166 = inttoptr i64 %r165 to ptr
  %r167 = load float, ptr %r166, align 4
  %r168 = fpext float %r167 to double
  br label %tav.get.merge.27

tav.k.f64.36:                                     ; preds = %tav.kd7.43
  %r170 = add nuw nsw i64 %r121, 56
  %r171 = inttoptr i64 %r170 to ptr
  %r172 = load double, ptr %r171, align 8
  br label %tav.get.merge.27

tav.kd1.37:                                       ; preds = %tav.get.load.25
  %r123 = icmp eq i64 %r112, 1
  br i1 %r123, label %tav.k.u8.30, label %tav.kd2.38

tav.kd2.38:                                       ; preds = %tav.kd1.37
  %r124 = icmp eq i64 %r112, 2
  br i1 %r124, label %tav.k.i16.31, label %tav.kd3.39

tav.kd3.39:                                       ; preds = %tav.kd2.38
  %r125 = icmp eq i64 %r112, 3
  br i1 %r125, label %tav.k.u16.32, label %tav.kd4.40

tav.kd4.40:                                       ; preds = %tav.kd3.39
  %r126 = icmp eq i64 %r112, 4
  br i1 %r126, label %tav.k.i32.33, label %tav.kd5.41

tav.kd5.41:                                       ; preds = %tav.kd4.40
  %r127 = icmp eq i64 %r112, 5
  br i1 %r127, label %tav.k.u32.34, label %tav.kd6.42

tav.kd6.42:                                       ; preds = %tav.kd5.41
  %r128 = icmp eq i64 %r112, 6
  br i1 %r128, label %tav.k.f32.35, label %tav.kd7.43

tav.kd7.43:                                       ; preds = %tav.kd6.42
  %r129 = icmp eq i64 %r112, 7
  br i1 %r129, label %tav.k.f64.36, label %tav.k.u8.30

arrlike.ic.header.44:                             ; preds = %tav.get.slow.26
  %r191 = sub nuw nsw i64 %r177, 8
  %r192 = inttoptr i64 %r191 to ptr
  %r193 = load i8, ptr %r192, align 1
  %r195 = sub nuw nsw i64 %r177, 7
  %r196 = inttoptr i64 %r195 to ptr
  %r197 = load i8, ptr %r196, align 1
  %r198 = and i8 %r197, -128
  %r199 = icmp eq i8 %r198, 0
  %r200 = and i1 true, %r199
  br i1 %r200, label %arrlike.ic.brand.45, label %arrlike.ic.miss.63

arrlike.ic.brand.45:                              ; preds = %arrlike.ic.header.44
  %r194 = icmp eq i8 %r193, 1
  br i1 %r194, label %arrlike.ic.array_guard.46, label %arrlike.elem.kind.64

arrlike.ic.array_guard.46:                        ; preds = %json.scalar.materialized_ready.74, %arrlike.ic.brand.45
  %r293 = phi i64 [ %r177, %arrlike.ic.brand.45 ], [ %r217, %json.scalar.materialized_ready.74 ]
  %r294 = sub i64 %r293, 6
  %r295 = inttoptr i64 %r294 to ptr
  %r296 = load i16, ptr %r295, align 2
  %r297 = and i16 %r296, 1024
  %r298 = icmp eq i16 %r297, 0
  %r299 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r300 = icmp eq i8 %r299, 0
  %r301 = inttoptr i64 %r293 to ptr
  %r302 = load i32, ptr %r301, align 4
  %r303 = add i64 %r293, 4
  %r304 = inttoptr i64 %r303 to ptr
  %r305 = load i32, ptr %r304, align 4
  %r306 = zext i32 %r302 to i64
  %r307 = zext i32 %r305 to i64
  %r308 = icmp ult i64 7, %r306
  %r309 = icmp ule i64 %r306, %r307
  %r310 = and i1 %r298, %r300
  %r311 = and i1 %r310, %r308
  %r312 = and i1 %r311, %r309
  br i1 %r312, label %arrlike.ic.array_load.47, label %arrlike.ic.miss.63

arrlike.ic.array_load.47:                         ; preds = %arrlike.ic.array_guard.46
  %r314 = getelementptr inbounds nuw i64, ptr %r301, i64 8
  %r315 = load double, ptr %r314, align 8
  %r316 = bitcast double %r315 to i64
  %r317 = icmp eq i64 %r316, 9222246136947933200
  %r319 = select i1 %r317, double 0x7FFC000000000001, double %r315
  br label %tav.get.merge.27

arrlike.ic.shape.48:                              ; preds = %arrlike.elem.store.66, %arrlike.elem.meta.65
  %r321 = inttoptr i64 %r177 to ptr
  %r322 = load i32, ptr %r321, align 4
  %r323 = add nuw nsw i64 %r177, 4
  %r324 = inttoptr i64 %r323 to ptr
  %r325 = load i32, ptr %r324, align 4
  %r326 = zext i32 %r322 to i64
  %r327 = zext i32 %r325 to i64
  %r328 = shl nuw i64 %r326, 32
  %r329 = or i64 %r328, %r327
  %r330 = getelementptr i64, ptr %r175, i64 0
  %r331 = load i64, ptr %r330, align 8
  %r332 = icmp ne i64 %r331, 0
  %r333 = and i1 true, %r332
  br i1 %r333, label %arrlike.ic.identity.49, label %arrlike.ic.miss.63

arrlike.ic.identity.49:                           ; preds = %arrlike.ic.shape.48
  %r334 = and i64 %r331, -9223372036854775808
  %0 = icmp slt i64 %r331, 0
  br i1 %0, label %arrlike.ic.family_meta.51, label %arrlike.ic.exact.50

arrlike.ic.exact.50:                              ; preds = %arrlike.ic.identity.49
  %r336 = icmp eq i64 %r329, %r331
  br i1 %r336, label %arrlike.ic.bounds.53, label %arrlike.ic.miss.63

arrlike.ic.family_meta.51:                        ; preds = %arrlike.ic.identity.49
  %r337 = add nuw nsw i64 %r177, 8
  %r338 = inttoptr i64 %r337 to ptr
  %r339 = load i64, ptr %r338, align 8
  %r340 = icmp ne i64 %r339, 0
  br i1 %r340, label %arrlike.ic.family_token.52, label %arrlike.ic.miss.63

arrlike.ic.family_token.52:                       ; preds = %arrlike.ic.family_meta.51
  %r341 = inttoptr i64 %r339 to ptr
  %r342 = getelementptr i64, ptr %r341, i64 6
  %r343 = load i64, ptr %r342, align 8
  %r344 = icmp eq i64 %r343, %r331
  br i1 %r344, label %arrlike.ic.bounds.53, label %arrlike.ic.miss.63

arrlike.ic.bounds.53:                             ; preds = %arrlike.ic.family_token.52, %arrlike.ic.exact.50
  %r345 = getelementptr i64, ptr %r173, i64 1
  %r346 = load i64, ptr %r345, align 8
  %r347 = getelementptr i64, ptr %r173, i64 2
  %r348 = load i64, ptr %r347, align 8
  %r349 = getelementptr i64, ptr %r173, i64 3
  %r350 = load i64, ptr %r349, align 8
  %r351 = getelementptr i64, ptr %r173, i64 4
  %r352 = load i64, ptr %r351, align 8
  %r353 = icmp ult i64 %r346, %r352
  br i1 %r353, label %arrlike.ic.length_inline.54, label %arrlike.ic.length_spill_meta.55

arrlike.ic.length_inline.54:                      ; preds = %arrlike.ic.bounds.53
  %r354 = shl i64 %r346, 3
  %r355 = add i64 %r354, 16
  %r356 = add i64 %r177, %r355
  %r357 = inttoptr i64 %r356 to ptr
  %r358 = load double, ptr %r357, align 8
  br label %arrlike.ic.range.58

arrlike.ic.length_spill_meta.55:                  ; preds = %arrlike.ic.bounds.53
  %r359 = add nuw nsw i64 %r177, 8
  %r360 = inttoptr i64 %r359 to ptr
  %r361 = load i64, ptr %r360, align 8
  %r362 = icmp ne i64 %r361, 0
  br i1 %r362, label %arrlike.ic.length_spill_ptr.56, label %arrlike.ic.miss.63

arrlike.ic.length_spill_ptr.56:                   ; preds = %arrlike.ic.length_spill_meta.55
  %r363 = inttoptr i64 %r361 to ptr
  %r364 = getelementptr i64, ptr %r363, i64 4
  %r365 = load i64, ptr %r364, align 8
  %r366 = icmp ne i64 %r365, 0
  %r367 = select i1 %r366, i64 %r365, i64 %r361
  %r368 = inttoptr i64 %r367 to ptr
  %r369 = load i32, ptr %r368, align 4
  %r370 = zext i32 %r369 to i64
  %r371 = icmp ult i64 %r346, %r370
  %r372 = and i1 %r366, %r371
  br i1 %r372, label %arrlike.ic.length_spill_load.57, label %arrlike.ic.miss.63

arrlike.ic.length_spill_load.57:                  ; preds = %arrlike.ic.length_spill_ptr.56
  %r373 = add nuw nsw i64 %r346, 1
  %r374 = getelementptr inbounds nuw i64, ptr %r368, i64 %r373
  %r375 = load double, ptr %r374, align 8
  br label %arrlike.ic.range.58

arrlike.ic.range.58:                              ; preds = %arrlike.ic.length_spill_load.57, %arrlike.ic.length_inline.54
  %r376 = phi double [ %r358, %arrlike.ic.length_inline.54 ], [ %r375, %arrlike.ic.length_spill_load.57 ]
  %r377 = fcmp olt double 7.000000e+00, %r376
  %r378 = icmp ult i64 7, %r350
  %r379 = and i1 %r377, %r378
  %r380 = add i64 %r348, 7
  %r381 = icmp ult i64 %r380, %r352
  %r382 = and i1 %r379, %r381
  %r383 = xor i1 %r381, true
  %r384 = and i1 %r379, %r383
  br i1 %r382, label %arrlike.ic.inline.59, label %arrlike.ic.spill_or_miss.82

arrlike.ic.inline.59:                             ; preds = %arrlike.ic.range.58
  %r385 = shl i64 %r380, 3
  %r386 = add i64 %r385, 16
  %r387 = add i64 %r177, %r386
  %r388 = inttoptr i64 %r387 to ptr
  %r389 = load double, ptr %r388, align 8
  br label %tav.get.merge.27

arrlike.ic.spill.60:                              ; preds = %arrlike.ic.spill_or_miss.82
  %r390 = add nuw nsw i64 %r177, 8
  %r391 = inttoptr i64 %r390 to ptr
  %r392 = load i64, ptr %r391, align 8
  %r393 = icmp ne i64 %r392, 0
  br i1 %r393, label %arrlike.ic.spill_ptr.61, label %arrlike.ic.miss.63

arrlike.ic.spill_ptr.61:                          ; preds = %arrlike.ic.spill.60
  %r394 = inttoptr i64 %r392 to ptr
  %r395 = getelementptr i64, ptr %r394, i64 4
  %r396 = load i64, ptr %r395, align 8
  %r397 = icmp ne i64 %r396, 0
  %r398 = select i1 %r397, i64 %r396, i64 %r392
  %r399 = inttoptr i64 %r398 to ptr
  %r400 = load i32, ptr %r399, align 4
  %r401 = zext i32 %r400 to i64
  %r402 = icmp ult i64 %r380, %r401
  %r403 = and i1 %r397, %r402
  br i1 %r403, label %arrlike.ic.spill_load.62, label %arrlike.ic.miss.63

arrlike.ic.spill_load.62:                         ; preds = %arrlike.ic.spill_ptr.61
  %r404 = add nuw nsw i64 %r380, 1
  %r405 = getelementptr inbounds nuw i64, ptr %r399, i64 %r404
  %r406 = load double, ptr %r405, align 8
  br label %tav.get.merge.27

arrlike.ic.miss.63:                               ; preds = %arrlike.ic.spill_or_miss.82, %json.scalar.cold.80, %json.scalar.memo.77, %json.scalar.materialized_guard.73, %json.scalar.cache_guard.72, %json.scalar.kind.70, %arrlike.elem.load.68, %arrlike.elem.bounds.67, %arrlike.ic.spill_ptr.61, %arrlike.ic.spill.60, %arrlike.ic.length_spill_ptr.56, %arrlike.ic.length_spill_meta.55, %arrlike.ic.family_token.52, %arrlike.ic.family_meta.51, %arrlike.ic.exact.50, %arrlike.ic.shape.48, %arrlike.ic.array_guard.46, %arrlike.ic.header.44, %tav.get.slow.26
  %r582.rs4i = ptrtoint ptr addrspace(1) %.139 to i64
  %r582.rs4o = call i64 asm "", "=r,0"(i64 %r582.rs4i) #9
  %r582 = bitcast i64 %r582.rs4o to double
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r582, double 7.000000e+00, ptr @perry_ic_short_loops_ts__0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %.1, ptr addrspace(1) %.139) ]
  %r4072 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 0, i32 0) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s3.relocated3 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 1, i32 1) ; (%.1, %.1)
  %rs4gc.s2.relocated4 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 2, i32 2) ; (%.139, %.139)
  br label %tav.get.merge.27

arrlike.elem.kind.64:                             ; preds = %arrlike.ic.brand.45
  %r201 = icmp eq i8 %r193, 2
  br i1 %r201, label %arrlike.elem.meta.65, label %json.scalar.kind.70

arrlike.elem.meta.65:                             ; preds = %arrlike.elem.kind.64
  %r263 = add nuw nsw i64 %r177, 8
  %r264 = inttoptr i64 %r263 to ptr
  %r265 = load i64, ptr %r264, align 8
  %r266 = icmp ne i64 %r265, 0
  br i1 %r266, label %arrlike.elem.store.66, label %arrlike.ic.shape.48

arrlike.elem.store.66:                            ; preds = %arrlike.elem.meta.65
  %r267 = inttoptr i64 %r265 to ptr
  %r268 = getelementptr i64, ptr %r267, i64 12
  %r269 = load i64, ptr %r268, align 8
  %r270 = icmp ne i64 %r269, 0
  br i1 %r270, label %arrlike.elem.bounds.67, label %arrlike.ic.shape.48

arrlike.elem.bounds.67:                           ; preds = %arrlike.elem.store.66
  %r271 = sub i64 %r269, 8
  %r272 = inttoptr i64 %r271 to ptr
  %r273 = load i8, ptr %r272, align 1
  %r274 = icmp eq i8 %r273, 1
  %r275 = sub i64 %r269, 7
  %r276 = inttoptr i64 %r275 to ptr
  %r277 = load i8, ptr %r276, align 1
  %r278 = and i8 %r277, -128
  %r279 = icmp eq i8 %r278, 0
  %r280 = inttoptr i64 %r269 to ptr
  %r281 = load i32, ptr %r280, align 4
  %r282 = zext i32 %r281 to i64
  %r283 = icmp ult i64 7, %r282
  %r284 = and i1 %r274, %r279
  %r285 = and i1 %r284, %r283
  br i1 %r285, label %arrlike.elem.load.68, label %arrlike.ic.miss.63

arrlike.elem.load.68:                             ; preds = %arrlike.elem.bounds.67
  %r287 = add i64 %r269, 8
  %r288 = add i64 %r287, 56
  %r289 = inttoptr i64 %r288 to ptr
  %r290 = load double, ptr %r289, align 8
  %r291 = bitcast double %r290 to i64
  %r292 = icmp eq i64 %r291, 9222246136947933200
  br i1 %r292, label %arrlike.ic.miss.63, label %arrlike.elem.value.69

arrlike.elem.value.69:                            ; preds = %arrlike.elem.load.68
  br label %tav.get.merge.27

json.scalar.kind.70:                              ; preds = %arrlike.elem.kind.64
  %r202 = icmp eq i8 %r193, 9
  br i1 %r202, label %json.scalar.guard.71, label %arrlike.ic.miss.63

json.scalar.guard.71:                             ; preds = %json.scalar.kind.70
  %r203 = inttoptr i64 %r177 to ptr
  %r204 = getelementptr i8, ptr %r203, i64 4
  %r205 = load i32, ptr %r204, align 4
  %r206 = icmp eq i32 %r205, 1280989249
  %r207 = getelementptr i8, ptr %r203, i64 32
  %r208 = load ptr, ptr %r207, align 8
  %r209 = icmp eq ptr %r208, null
  %r210 = getelementptr i8, ptr %r203, i64 -6
  %r211 = load i16, ptr %r210, align 2
  %r212 = and i16 %r211, 3072
  %r213 = icmp eq i16 %r212, 0
  %r214 = and i1 %r206, %r213
  %r215 = icmp ne ptr %r208, null
  %r216 = and i1 %r214, %r215
  br i1 %r216, label %json.scalar.materialized_guard.73, label %json.scalar.cache_guard.72

json.scalar.cache_guard.72:                       ; preds = %json.scalar.guard.71
  %r227 = load i32, ptr %r203, align 4
  %r228 = zext i32 %r227 to i64
  %r229 = icmp ult i64 7, %r228
  %r230 = getelementptr i8, ptr %r203, i64 40
  %r231 = load ptr, ptr %r230, align 8
  %r232 = getelementptr i8, ptr %r203, i64 48
  %r233 = load ptr, ptr %r232, align 8
  %r234 = icmp ne ptr %r231, null
  %r235 = icmp ne ptr %r233, null
  %r236 = and i1 %r229, %r214
  %r237 = and i1 %r236, %r209
  %r238 = and i1 %r237, %r234
  %r239 = and i1 %r238, %r235
  br i1 %r239, label %json.scalar.bitmap.75, label %arrlike.ic.miss.63

json.scalar.materialized_guard.73:                ; preds = %json.scalar.guard.71
  %r217 = ptrtoint ptr %r208 to i64
  %r218 = getelementptr i8, ptr %r208, i64 -8
  %r219 = load i8, ptr %r218, align 1
  %r220 = icmp eq i8 %r219, 1
  %r221 = getelementptr i8, ptr %r208, i64 -7
  %r222 = load i8, ptr %r221, align 1
  %r223 = and i8 %r222, -128
  %r224 = icmp eq i8 %r223, 0
  %r225 = and i1 %r220, %r224
  br i1 %r225, label %json.scalar.materialized_ready.74, label %arrlike.ic.miss.63

json.scalar.materialized_ready.74:                ; preds = %json.scalar.materialized_guard.73
  %r226 = load i32, ptr %r208, align 4
  store i32 %r226, ptr %r203, align 4
  br label %arrlike.ic.array_guard.46

json.scalar.bitmap.75:                            ; preds = %json.scalar.cache_guard.72
  %r241 = getelementptr i64, ptr %r233, i64 0
  %r242 = load i64, ptr %r241, align 8
  %r245 = and i64 %r242, 128
  %r247 = getelementptr i64, ptr %r231, i64 7
  %r246 = icmp ne i64 %r245, 0
  br i1 %r246, label %json.scalar.exposed.76, label %json.scalar.memo.77

json.scalar.exposed.76:                           ; preds = %json.scalar.bitmap.75
  %r248 = load double, ptr %r247, align 8
  br label %tav.get.merge.27

json.scalar.memo.77:                              ; preds = %json.scalar.bitmap.75
  %r249 = getelementptr i8, ptr %r203, i64 80
  %r250 = load i64, ptr %r249, align 8
  %r251 = icmp eq i64 %r250, 6580483
  %r252 = icmp eq i64 %r250, 0
  %r253 = or i1 %r251, %r252
  br i1 %r253, label %json.scalar.memo_slot.78, label %arrlike.ic.miss.63

json.scalar.memo_slot.78:                         ; preds = %json.scalar.memo.77
  %r254 = load i64, ptr %r247, align 8
  %r255 = icmp ne i64 %r254, 0
  %r256 = and i1 %r251, %r255
  br i1 %r256, label %json.scalar.memo_hit.79, label %json.scalar.cold.80

json.scalar.memo_hit.79:                          ; preds = %json.scalar.memo_slot.78
  %r257 = icmp eq i64 %r254, 9222809086901354496
  %r258 = select i1 %r257, i64 0, i64 %r254
  %r259 = bitcast i64 %r258 to double
  br label %json.scalar.merge.81

json.scalar.cold.80:                              ; preds = %json.scalar.memo_slot.78
  %r260 = call double @js_json_lazy_index_scalar(double %r79, double 7.000000e+00, ptr @short_loops_ts_.str.0.bytes, i64 2) #9
  %r261 = bitcast double %r260 to i64
  %r262 = icmp eq i64 %r261, 9222246136947933200
  br i1 %r262, label %arrlike.ic.miss.63, label %json.scalar.merge.81

json.scalar.merge.81:                             ; preds = %pget.recv_merge.87, %json.scalar.cold.80, %json.scalar.memo_hit.79
  %.151 = phi ptr addrspace(1) [ %.252, %pget.recv_merge.87 ], [ %rs4gc.s6, %json.scalar.memo_hit.79 ], [ %rs4gc.s6, %json.scalar.cold.80 ]
  %.442 = phi ptr addrspace(1) [ %.543, %pget.recv_merge.87 ], [ %.139, %json.scalar.memo_hit.79 ], [ %.139, %json.scalar.cold.80 ]
  %.4 = phi ptr addrspace(1) [ %.5, %pget.recv_merge.87 ], [ %.1, %json.scalar.memo_hit.79 ], [ %.1, %json.scalar.cold.80 ]
  %r556 = phi double [ %r259, %json.scalar.memo_hit.79 ], [ %r260, %json.scalar.cold.80 ], [ %r555, %pget.recv_merge.87 ]
  %r557.rs4i = ptrtoint ptr addrspace(1) %.151 to i64
  %r557 = call i64 asm "", "=r,0"(i64 %r557.rs4i) #9
  %r558 = bitcast i64 %r557 to double
  %r559 = and i64 %r557, -281474976710656
  %r560 = icmp ult i64 %r559, 9221401712017801216
  %r561 = icmp ugt i64 %r559, 9223090561878065152
  %r562 = or i1 %r560, %r561
  %r563 = bitcast double %r556 to i64
  %r564 = and i64 %r563, -281474976710656
  %r565 = icmp ult i64 %r564, 9221401712017801216
  %r566 = icmp ugt i64 %r564, 9223090561878065152
  %r567 = or i1 %r565, %r566
  %r568 = and i1 %r562, %r567
  br i1 %r568, label %guarded_add.numeric.114, label %guarded_add.dynamic.115

arrlike.ic.spill_or_miss.82:                      ; preds = %arrlike.ic.range.58
  br i1 %r384, label %arrlike.ic.spill.60, label %arrlike.ic.miss.63

pget.recv_sso.83:                                 ; preds = %pget.recv_other.88
  %r551 = load double, ptr @short_loops_ts_.str.0.handle, align 8
  %r552 = bitcast double %r551 to i64
  %r553 = and i64 %r552, 281474976710655
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r409, i64 %r553, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3, ptr addrspace(1) %.341, ptr addrspace(1) %.050) ]
  %r5546 = call double @llvm.experimental.gc.result.f64(token %statepoint_token5)
  %rs4gc.s3.relocated7 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 0, i32 0) ; (%.3, %.3)
  %rs4gc.s2.relocated8 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 1, i32 1) ; (%.341, %.341)
  %rs4gc.s6.relocated9 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 2, i32 2) ; (%.050, %.050)
  br label %pget.recv_merge.87

pget.recv_ok.84:                                  ; preds = %tav.get.merge.27
  %r420 = icmp ugt i64 %r410, 1048575
  br i1 %r420, label %pic.recv_hdr.105, label %pic.miss.cold.102

pget.recv_bad.85:                                 ; preds = %pget.check_class_ref.89
  %r543 = icmp eq i64 %r409, 9222246136947933185
  %r544 = icmp eq i64 %r409, 9222246136947933186
  %r545 = or i1 %r543, %r544
  br i1 %r545, label %pget.throw_nullish.112, label %pget.recv_undef_return.113

pget.recv_class_ref.86:                           ; preds = %pget.check_class_ref.89
  %r416 = load double, ptr @short_loops_ts_.str.0.handle, align 8
  %r417 = bitcast double %r416 to i64
  %r418 = and i64 %r417, 281474976710655
  %statepoint_token10 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 2301219111847329793, i64 %r409, i64 %r418, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3, ptr addrspace(1) %.341, ptr addrspace(1) %.050) ]
  %r41911 = call double @llvm.experimental.gc.result.f64(token %statepoint_token10)
  %rs4gc.s3.relocated12 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token10, i32 0, i32 0) ; (%.3, %.3)
  %rs4gc.s2.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token10, i32 1, i32 1) ; (%.341, %.341)
  %rs4gc.s6.relocated14 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token10, i32 2, i32 2) ; (%.050, %.050)
  br label %pget.recv_merge.87

pget.recv_merge.87:                               ; preds = %pget.recv_undef_return.113, %pic.merge.104, %pget.recv_class_ref.86, %pget.recv_sso.83
  %.252 = phi ptr addrspace(1) [ %.353, %pic.merge.104 ], [ %rs4gc.s6.relocated9, %pget.recv_sso.83 ], [ %rs4gc.s6.relocated14, %pget.recv_class_ref.86 ], [ %rs4gc.s6.relocated30, %pget.recv_undef_return.113 ]
  %.543 = phi ptr addrspace(1) [ %.644, %pic.merge.104 ], [ %rs4gc.s2.relocated8, %pget.recv_sso.83 ], [ %rs4gc.s2.relocated13, %pget.recv_class_ref.86 ], [ %rs4gc.s2.relocated29, %pget.recv_undef_return.113 ]
  %.5 = phi ptr addrspace(1) [ %.6, %pic.merge.104 ], [ %rs4gc.s3.relocated7, %pget.recv_sso.83 ], [ %rs4gc.s3.relocated12, %pget.recv_class_ref.86 ], [ %rs4gc.s3.relocated28, %pget.recv_undef_return.113 ]
  %r555 = phi double [ %r542, %pic.merge.104 ], [ %r55027, %pget.recv_undef_return.113 ], [ %r5546, %pget.recv_sso.83 ], [ %r41911, %pget.recv_class_ref.86 ]
  br label %json.scalar.merge.81

pget.recv_other.88:                               ; preds = %tav.get.merge.27
  %r414 = icmp eq i64 %r411, 32761
  br i1 %r414, label %pget.recv_sso.83, label %pget.check_class_ref.89

pget.check_class_ref.89:                          ; preds = %pget.recv_other.88
  %r415 = icmp eq i64 %r411, 32766
  br i1 %r415, label %pget.recv_class_ref.86, label %pget.recv_bad.85

pic.hit.90:                                       ; preds = %pic.token.106
  %r445 = getelementptr i64, ptr %r430, i64 1
  %r446 = load i64, ptr %r445, align 8
  %r447 = and i64 %r446, 1073741824
  %r448 = icmp ne i64 %r447, 0
  br i1 %r448, label %pic.hit.overflow.107, label %pic.hit.inline.108

pic.hit.live.91:                                  ; preds = %pic.hit.inline.108
  br label %pic.merge.104

pic.prefix.guard.92:                              ; preds = %pic.token.106
  %r461 = getelementptr i64, ptr %r430, i64 2
  %r462 = load i64, ptr %r461, align 8
  %r463 = icmp ne i64 %r462, 0
  br i1 %r463, label %pic.prefix.meta.93, label %pic.miss.101

pic.prefix.meta.93:                               ; preds = %pic.prefix.guard.92
  %r464 = add nuw nsw i64 %r410, 8
  %r465 = inttoptr i64 %r464 to ptr
  %r466 = load i64, ptr %r465, align 8
  %r467 = icmp ne i64 %r466, 0
  br i1 %r467, label %pic.prefix.token.94, label %pic.miss.101

pic.prefix.token.94:                              ; preds = %pic.prefix.meta.93
  %r468 = inttoptr i64 %r466 to ptr
  %r469 = getelementptr i64, ptr %r468, i64 6
  %r470 = load i64, ptr %r469, align 8
  %r471 = icmp eq i64 %r470, %r462
  br i1 %r471, label %pic.prefix.hit.95, label %pic.miss.101

pic.prefix.hit.95:                                ; preds = %pic.prefix.token.94
  %r472 = getelementptr i64, ptr %r430, i64 1
  %r473 = load i64, ptr %r472, align 8
  %r474 = shl i64 %r473, 3
  %r475 = add nuw nsw i64 %r410, 16
  %r476 = add i64 %r475, %r474
  %r477 = inttoptr i64 %r476 to ptr
  %r478 = load double, ptr %r477, align 8
  br label %pic.merge.104

pic.desc.classify.96:                             ; preds = %pic.recv_hdr.105
  %r434 = and i1 %r424, %r431
  br i1 %r434, label %pic.desc.prefix.guard.97, label %pic.miss.cold.102

pic.desc.prefix.guard.97:                         ; preds = %pic.desc.classify.96
  %r479 = getelementptr i64, ptr %r430, i64 2
  %r480 = load i64, ptr %r479, align 8
  %r481 = icmp ne i64 %r480, 0
  br i1 %r481, label %pic.desc.prefix.meta.98, label %pic.miss.cold.102

pic.desc.prefix.meta.98:                          ; preds = %pic.desc.prefix.guard.97
  %r482 = add nuw nsw i64 %r410, 8
  %r483 = inttoptr i64 %r482 to ptr
  %r484 = load i64, ptr %r483, align 8
  %r485 = icmp ne i64 %r484, 0
  br i1 %r485, label %pic.desc.prefix.token.99, label %pic.miss.cold.102

pic.desc.prefix.token.99:                         ; preds = %pic.desc.prefix.meta.98
  %r486 = inttoptr i64 %r484 to ptr
  %r487 = getelementptr i64, ptr %r486, i64 6
  %r488 = load i64, ptr %r487, align 8
  %r489 = icmp eq i64 %r488, %r480
  br i1 %r489, label %pic.desc.prefix.hit.100, label %pic.miss.cold.102

pic.desc.prefix.hit.100:                          ; preds = %pic.desc.prefix.token.99
  %r490 = getelementptr i64, ptr %r430, i64 1
  %r491 = load i64, ptr %r490, align 8
  %r492 = shl i64 %r491, 3
  %r493 = add nuw nsw i64 %r410, 16
  %r494 = add i64 %r493, %r492
  %r495 = inttoptr i64 %r494 to ptr
  %r496 = load double, ptr %r495, align 8
  br label %pic.merge.104

pic.miss.101:                                     ; preds = %pic.hit.inline.108, %pic.prefix.token.94, %pic.prefix.meta.93, %pic.prefix.guard.92
  %r497 = getelementptr i64, ptr %r430, i64 3
  %r498 = load i64, ptr %r497, align 8
  %r499 = icmp sgt i64 %r498, 0
  br i1 %r499, label %pic.ways.109, label %pic.miss.call.103

pic.miss.cold.102:                                ; preds = %pic.desc.prefix.token.99, %pic.desc.prefix.meta.98, %pic.desc.prefix.guard.97, %pic.desc.classify.96, %pget.recv_ok.84
  br label %pic.miss.call.103

pic.miss.call.103:                                ; preds = %pic.way.load.110, %pic.ways.109, %pic.miss.cold.102, %pic.miss.101
  %r538 = load double, ptr @short_loops_ts_.str.0.handle, align 8
  %r539 = bitcast double %r538 to i64
  %r540 = and i64 %r539, 281474976710655
  %statepoint_token15 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r410, i64 %r540, ptr @perry_ic_short_loops_ts__2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3, ptr addrspace(1) %.341, ptr addrspace(1) %.050) ]
  %r54116 = call double @llvm.experimental.gc.result.f64(token %statepoint_token15)
  %rs4gc.s3.relocated17 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token15, i32 0, i32 0) ; (%.3, %.3)
  %rs4gc.s2.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token15, i32 1, i32 1) ; (%.341, %.341)
  %rs4gc.s6.relocated19 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token15, i32 2, i32 2) ; (%.050, %.050)
  br label %pic.merge.104

pic.merge.104:                                    ; preds = %pic.way.live.111, %pic.hit.overflow.107, %pic.miss.call.103, %pic.desc.prefix.hit.100, %pic.prefix.hit.95, %pic.hit.live.91
  %.353 = phi ptr addrspace(1) [ %rs4gc.s6.relocated24, %pic.hit.overflow.107 ], [ %rs4gc.s6.relocated19, %pic.miss.call.103 ], [ %.050, %pic.way.live.111 ], [ %.050, %pic.hit.live.91 ], [ %.050, %pic.prefix.hit.95 ], [ %.050, %pic.desc.prefix.hit.100 ]
  %.644 = phi ptr addrspace(1) [ %rs4gc.s2.relocated23, %pic.hit.overflow.107 ], [ %rs4gc.s2.relocated18, %pic.miss.call.103 ], [ %.341, %pic.way.live.111 ], [ %.341, %pic.hit.live.91 ], [ %.341, %pic.prefix.hit.95 ], [ %.341, %pic.desc.prefix.hit.100 ]
  %.6 = phi ptr addrspace(1) [ %rs4gc.s3.relocated22, %pic.hit.overflow.107 ], [ %rs4gc.s3.relocated17, %pic.miss.call.103 ], [ %.3, %pic.way.live.111 ], [ %.3, %pic.hit.live.91 ], [ %.3, %pic.prefix.hit.95 ], [ %.3, %pic.desc.prefix.hit.100 ]
  %r542 = phi double [ %r458, %pic.hit.live.91 ], [ %r45321, %pic.hit.overflow.107 ], [ %r478, %pic.prefix.hit.95 ], [ %r496, %pic.desc.prefix.hit.100 ], [ %r535, %pic.way.live.111 ], [ %r54116, %pic.miss.call.103 ]
  br label %pget.recv_merge.87

pic.recv_hdr.105:                                 ; preds = %pget.recv_ok.84
  %r421 = sub nuw nsw i64 %r410, 8
  %r422 = inttoptr i64 %r421 to ptr
  %r423 = load i8, ptr %r422, align 1
  %r424 = icmp eq i8 %r423, 2
  %r425 = sub nuw nsw i64 %r410, 6
  %r426 = inttoptr i64 %r425 to ptr
  %r427 = load i16, ptr %r426, align 2
  %r428 = and i16 %r427, 2048
  %r429 = icmp eq i16 %r428, 0
  %r430 = load ptr, ptr @perry_ic_short_loops_ts__2, align 8
  %r431 = icmp ne ptr %r430, null
  %r432 = and i1 %r424, %r429
  %r433 = and i1 %r432, %r431
  br i1 %r433, label %pic.token.106, label %pic.desc.classify.96

pic.token.106:                                    ; preds = %pic.recv_hdr.105
  %r435 = add nuw nsw i64 %r410, 4
  %r436 = inttoptr i64 %r435 to ptr
  %r437 = load i32, ptr %r436, align 4
  %r438 = zext i32 %r437 to i64
  %r439 = or i64 %r438, 4611686018427387904
  %r440 = icmp ne i32 %r437, 0
  %r441 = getelementptr i64, ptr %r430, i64 0
  %r442 = load i64, ptr %r441, align 8
  %r443 = icmp eq i64 %r439, %r442
  %r444 = and i1 %r443, %r440
  br i1 %r444, label %pic.hit.90, label %pic.prefix.guard.92

pic.hit.overflow.107:                             ; preds = %pic.hit.90
  %r449 = load double, ptr @short_loops_ts_.str.0.handle, align 8
  %r450 = bitcast double %r449 to i64
  %r451 = and i64 %r450, 281474976710655
  %r452 = trunc i64 %r446 to i32
  %statepoint_token20 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r410, i64 %r451, i32 %r452, ptr @perry_ic_short_loops_ts__2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3, ptr addrspace(1) %.341, ptr addrspace(1) %.050) ]
  %r45321 = call double @llvm.experimental.gc.result.f64(token %statepoint_token20)
  %rs4gc.s3.relocated22 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 0, i32 0) ; (%.3, %.3)
  %rs4gc.s2.relocated23 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 1, i32 1) ; (%.341, %.341)
  %rs4gc.s6.relocated24 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 2, i32 2) ; (%.050, %.050)
  br label %pic.merge.104

pic.hit.inline.108:                               ; preds = %pic.hit.90
  %r454 = shl i64 %r446, 3
  %r455 = add nuw nsw i64 %r410, 16
  %r456 = add i64 %r455, %r454
  %r457 = inttoptr i64 %r456 to ptr
  %r458 = load double, ptr %r457, align 8
  %r459 = bitcast double %r458 to i64
  %r460 = icmp eq i64 %r459, 9222246136947933200
  br i1 %r460, label %pic.miss.101, label %pic.hit.live.91

pic.ways.109:                                     ; preds = %pic.miss.101
  %r500 = getelementptr i64, ptr %r430, i64 4
  %r501 = load i64, ptr %r500, align 8
  %r502 = icmp eq i64 %r501, %r439
  %r503 = getelementptr i64, ptr %r430, i64 5
  %r504 = load i64, ptr %r503, align 8
  %r505 = select i1 %r502, i64 %r504, i64 0
  %r506 = getelementptr i64, ptr %r430, i64 6
  %r507 = load i64, ptr %r506, align 8
  %r508 = icmp eq i64 %r507, %r439
  %r509 = getelementptr i64, ptr %r430, i64 7
  %r510 = load i64, ptr %r509, align 8
  %r511 = select i1 %r508, i64 %r510, i64 0
  %r512 = getelementptr i64, ptr %r430, i64 8
  %r513 = load i64, ptr %r512, align 8
  %r514 = icmp eq i64 %r513, %r439
  %r515 = getelementptr i64, ptr %r430, i64 9
  %r516 = load i64, ptr %r515, align 8
  %r517 = select i1 %r514, i64 %r516, i64 0
  %r518 = getelementptr i64, ptr %r430, i64 10
  %r519 = load i64, ptr %r518, align 8
  %r520 = icmp eq i64 %r519, %r439
  %r521 = getelementptr i64, ptr %r430, i64 11
  %r522 = load i64, ptr %r521, align 8
  %r523 = select i1 %r520, i64 %r522, i64 0
  %r524 = or i1 %r502, %r508
  %r525 = select i1 %r502, i64 %r505, i64 %r511
  %r526 = or i1 %r514, %r520
  %r527 = select i1 %r514, i64 %r517, i64 %r523
  %r528 = or i1 %r524, %r526
  %r529 = select i1 %r524, i64 %r525, i64 %r527
  %r530 = and i1 %r440, %r528
  br i1 %r530, label %pic.way.load.110, label %pic.miss.call.103

pic.way.load.110:                                 ; preds = %pic.ways.109
  %r531 = shl i64 %r529, 3
  %r532 = add nuw nsw i64 %r410, 16
  %r533 = add i64 %r532, %r531
  %r534 = inttoptr i64 %r533 to ptr
  %r535 = load double, ptr %r534, align 8
  %r536 = bitcast double %r535 to i64
  %r537 = icmp eq i64 %r536, 9222246136947933200
  br i1 %r537, label %pic.miss.call.103, label %pic.way.live.111

pic.way.live.111:                                 ; preds = %pic.way.load.110
  br label %pic.merge.104

pget.throw_nullish.112:                           ; preds = %pget.recv_bad.85
  %r546 = zext i1 %r544 to i32
  %statepoint_token25 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r546, ptr @short_loops_ts_.str.0.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.113:                       ; preds = %pget.recv_bad.85
  %r547 = load double, ptr @short_loops_ts_.str.0.handle, align 8
  %r548 = bitcast double %r547 to i64
  %r549 = and i64 %r548, 281474976710655
  %statepoint_token26 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r409, i64 %r549, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3, ptr addrspace(1) %.341, ptr addrspace(1) %.050) ]
  %r55027 = call double @llvm.experimental.gc.result.f64(token %statepoint_token26)
  %rs4gc.s3.relocated28 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token26, i32 0, i32 0) ; (%.3, %.3)
  %rs4gc.s2.relocated29 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token26, i32 1, i32 1) ; (%.341, %.341)
  %rs4gc.s6.relocated30 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token26, i32 2, i32 2) ; (%.050, %.050)
  br label %pget.recv_merge.87

guarded_add.numeric.114:                          ; preds = %json.scalar.merge.81
  %r569 = fadd double %r558, %r556
  br label %guarded_add.merge.116

guarded_add.dynamic.115:                          ; preds = %json.scalar.merge.81
  %statepoint_token31 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r558, double %r556, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.442) ]
  %r57032 = call double @llvm.experimental.gc.result.f64(token %statepoint_token31)
  %rs4gc.s3.relocated33 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token31, i32 0, i32 0) ; (%.4, %.4)
  %rs4gc.s2.relocated34 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token31, i32 1, i32 1) ; (%.442, %.442)
  br label %guarded_add.merge.116

guarded_add.merge.116:                            ; preds = %guarded_add.dynamic.115, %guarded_add.numeric.114
  %.745 = phi ptr addrspace(1) [ %.442, %guarded_add.numeric.114 ], [ %rs4gc.s2.relocated34, %guarded_add.dynamic.115 ]
  %.7 = phi ptr addrspace(1) [ %.4, %guarded_add.numeric.114 ], [ %rs4gc.s3.relocated33, %guarded_add.dynamic.115 ]
  %r571 = phi double [ %r569, %guarded_add.numeric.114 ], [ %r57032, %guarded_add.dynamic.115 ]
  %rs4gc.b7 = bitcast double %r571 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r572.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r572 = call i64 asm "", "=r,0"(i64 %r572.rs4i) #9
  %r573 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r574 = icmp ne i32 %r573, 0
  br i1 %r574, label %shadow.root.barrier.117, label %shadow.root.barrier.done.118

shadow.root.barrier.117:                          ; preds = %guarded_add.merge.116
  call void @js_write_barrier_root_nanbox(i64 %r572) #9
  br label %shadow.root.barrier.done.118

shadow.root.barrier.done.118:                     ; preds = %shadow.root.barrier.117, %guarded_add.merge.116
  %r575 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r576 = icmp ne i32 %r575, 0
  br i1 %r576, label %gcpoll.119, label %gcpoll.done.120

gcpoll.119:                                       ; preds = %shadow.root.barrier.done.118
  %statepoint_token35 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7, ptr addrspace(1) %.745, ptr addrspace(1) %.7) ]
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token35, i32 0, i32 0) ; (%rs4gc.s7, %rs4gc.s7)
  %rs4gc.s2.relocated36 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token35, i32 1, i32 1) ; (%.745, %.745)
  %rs4gc.s3.relocated37 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token35, i32 2, i32 2) ; (%.7, %.7)
  br label %gcpoll.done.120

gcpoll.done.120:                                  ; preds = %gcpoll.119, %shadow.root.barrier.done.118
  %.054 = phi ptr addrspace(1) [ %rs4gc.s7.relocated, %gcpoll.119 ], [ %rs4gc.s7, %shadow.root.barrier.done.118 ]
  %.846 = phi ptr addrspace(1) [ %rs4gc.s2.relocated36, %gcpoll.119 ], [ %.745, %shadow.root.barrier.done.118 ]
  %.8 = phi ptr addrspace(1) [ %rs4gc.s3.relocated37, %gcpoll.119 ], [ %.7, %shadow.root.barrier.done.118 ]
  br label %for.invariant_field_slow.update.16
}

; Function Attrs: optsize
define internal double @"perry_fn_short_loops_ts__run$spec_b_b_b"(double %arg15, double %arg16, double %arg17) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b2 = bitcast double %arg15 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg16 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %rs4gc.b4 = bitcast double %arg17 to i64
  %rs4gc.s4 = inttoptr i64 %rs4gc.b4 to ptr addrspace(1)
  %r9.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r9.rs4o = call i64 asm "", "=r,0"(i64 %r9.rs4i) #9
  %r9 = bitcast i64 %r9.rs4o to double
  %r10 = bitcast double %r9 to i64
  %r11 = and i64 %r10, -281474976710656
  %r12 = icmp ult i64 %r11, 9221401712017801216
  %r13 = icmp ugt i64 %r11, 9223090561878065152
  %r14 = or i1 %r12, %r13
  br i1 %r14, label %for.bound_i32.number.1, label %for.bound_i32.merge.3

for.bound_i32.number.1:                           ; preds = %entry.0
  %r15 = fcmp oge double %r9, 0xC1E0000000000000
  %r16 = fcmp ole double %r9, 0x41DFFFFFFFC00000
  %r17 = and i1 %r15, %r16
  br i1 %r17, label %for.bound_i32.convert.2, label %for.bound_i32.merge.3

for.bound_i32.convert.2:                          ; preds = %for.bound_i32.number.1
  %r18 = fptosi double %r9 to i32
  %r19 = sitofp i32 %r18 to double
  %r20 = fcmp oeq double %r19, %r9
  br i1 %r20, label %for.counter_i32.range.4, label %for.bound_i32.merge.3

for.bound_i32.merge.3:                            ; preds = %for.counter_i32.convert.5, %for.bound_i32.convert.2, %for.bound_i32.number.1, %entry.0
  %r8.0 = phi i32 [ %r18, %for.counter_i32.convert.5 ], [ 0, %entry.0 ], [ %r18, %for.bound_i32.convert.2 ], [ 0, %for.bound_i32.number.1 ]
  %r7.0 = phi i1 [ true, %for.counter_i32.convert.5 ], [ false, %entry.0 ], [ false, %for.bound_i32.convert.2 ], [ false, %for.bound_i32.number.1 ]
  br label %for.cond.6

for.counter_i32.range.4:                          ; preds = %for.bound_i32.convert.2
  br label %for.counter_i32.convert.5

for.counter_i32.convert.5:                        ; preds = %for.counter_i32.range.4
  br label %for.bound_i32.merge.3

for.cond.6:                                       ; preds = %for.update.8, %for.bound_i32.merge.3
  %.020 = phi ptr addrspace(1) [ %rs4gc.s2, %for.bound_i32.merge.3 ], [ %.424, %for.update.8 ]
  %.015 = phi ptr addrspace(1) [ %rs4gc.s4, %for.bound_i32.merge.3 ], [ %.419, %for.update.8 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %for.bound_i32.merge.3 ], [ %.4, %for.update.8 ]
  %r6.1 = phi i32 [ 0, %for.bound_i32.merge.3 ], [ %r72, %for.update.8 ]
  %r5.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.3 ], [ %r70, %for.update.8 ]
  %r4.0 = phi ptr addrspace(1) [ null, %for.bound_i32.merge.3 ], [ %.028, %for.update.8 ]
  br i1 %r7.0, label %for.cond.fast.10, label %for.cond.slow.11

for.body.7:                                       ; preds = %gcpoll.done.13, %for.cond.fast.10
  %.025 = phi ptr addrspace(1) [ %r4.0, %for.cond.fast.10 ], [ %.227, %gcpoll.done.13 ]
  %.121 = phi ptr addrspace(1) [ %.020, %for.cond.fast.10 ], [ %.222, %gcpoll.done.13 ]
  %.116 = phi ptr addrspace(1) [ %.015, %for.cond.fast.10 ], [ %.217, %gcpoll.done.13 ]
  %.1 = phi ptr addrspace(1) [ %.0, %for.cond.fast.10 ], [ %.2, %gcpoll.done.13 ]
  %r40.rs4i = ptrtoint ptr addrspace(1) %.025 to i64
  %r40.rs4o = call i64 asm "", "=r,0"(i64 %r40.rs4i) #9
  %r40 = bitcast i64 %r40.rs4o to double
  %r41 = bitcast double %r40 to i64
  %rs4gc.s6 = inttoptr i64 %r41 to ptr addrspace(1)
  %r43.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r43 = call i64 asm "", "=r,0"(i64 %r43.rs4i) #9
  %r44 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r45 = icmp ne i32 %r44, 0
  br i1 %r45, label %shadow.root.barrier.14, label %shadow.root.barrier.done.15

for.update.8:                                     ; preds = %gcpoll.done.22
  %r70 = fadd double %r5.0, 1.000000e+00
  %r72 = add i32 %r6.1, 1
  br label %for.cond.6

for.exit.9:                                       ; preds = %gcpoll.done.13, %for.cond.fast.10
  %.126 = phi ptr addrspace(1) [ %r4.0, %for.cond.fast.10 ], [ %.227, %gcpoll.done.13 ]
  %r73.rs4i = ptrtoint ptr addrspace(1) %.126 to i64
  %r73.rs4o = call i64 asm "", "=r,0"(i64 %r73.rs4i) #9
  %r73 = bitcast i64 %r73.rs4o to double
  ret double %r73

for.cond.fast.10:                                 ; preds = %for.cond.6
  %r31 = icmp slt i32 %r6.1, %r8.0
  br i1 %r31, label %for.body.7, label %for.exit.9

for.cond.slow.11:                                 ; preds = %for.cond.6
  %r33.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r33.rs4o = call i64 asm "", "=r,0"(i64 %r33.rs4i) #9
  %r33 = bitcast i64 %r33.rs4o to double
  %r34 = fcmp olt double %r5.0, %r33
  %r35 = select i1 %r34, i64 9222246136947933188, i64 9222246136947933187
  %r36 = bitcast i64 %r35 to double
  %r38 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r39 = icmp ne i32 %r38, 0
  br i1 %r39, label %gcpoll.12, label %gcpoll.done.13

gcpoll.12:                                        ; preds = %for.cond.slow.11
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0, ptr addrspace(1) %.015, ptr addrspace(1) %.020, ptr addrspace(1) %r4.0) ]
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%.0, %.0)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%.015, %.015)
  %rs4gc.s2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 2, i32 2) ; (%.020, %.020)
  %r4.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 3, i32 3) ; (%r4.0, %r4.0)
  br label %gcpoll.done.13

gcpoll.done.13:                                   ; preds = %gcpoll.12, %for.cond.slow.11
  %.227 = phi ptr addrspace(1) [ %r4.0.relocated, %gcpoll.12 ], [ %r4.0, %for.cond.slow.11 ]
  %.222 = phi ptr addrspace(1) [ %rs4gc.s2.relocated, %gcpoll.12 ], [ %.020, %for.cond.slow.11 ]
  %.217 = phi ptr addrspace(1) [ %rs4gc.s4.relocated, %gcpoll.12 ], [ %.015, %for.cond.slow.11 ]
  %.2 = phi ptr addrspace(1) [ %rs4gc.s3.relocated, %gcpoll.12 ], [ %.0, %for.cond.slow.11 ]
  %r37 = icmp eq i64 %r35, 9222246136947933188
  br i1 %r37, label %for.body.7, label %for.exit.9

shadow.root.barrier.14:                           ; preds = %for.body.7
  call void @js_write_barrier_root_nanbox(i64 %r43) #9
  br label %shadow.root.barrier.done.15

shadow.root.barrier.done.15:                      ; preds = %shadow.root.barrier.14, %for.body.7
  %r46.rs4i = ptrtoint ptr addrspace(1) %.121 to i64
  %r46.rs4o = call i64 asm "", "=r,0"(i64 %r46.rs4i) #9
  %r46 = bitcast i64 %r46.rs4o to double
  %r47.rs4i = ptrtoint ptr addrspace(1) %.116 to i64
  %r47.rs4o = call i64 asm "", "=r,0"(i64 %r47.rs4i) #9
  %r47 = bitcast i64 %r47.rs4o to double
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @"perry_fn_short_loops_ts__sum$spec_b_b", i32 2, i32 0, double %r46, double %r47, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1, ptr addrspace(1) %.116, ptr addrspace(1) %.121, ptr addrspace(1) %rs4gc.s6) ]
  %r482 = call double @llvm.experimental.gc.result.f64(token %statepoint_token1)
  %rs4gc.s3.relocated3 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 0, i32 0) ; (%.1, %.1)
  %rs4gc.s4.relocated4 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 1, i32 1) ; (%.116, %.116)
  %rs4gc.s2.relocated5 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 2, i32 2) ; (%.121, %.121)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token1, i32 3, i32 3) ; (%rs4gc.s6, %rs4gc.s6)
  %r49.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6.relocated to i64
  %r49 = call i64 asm "", "=r,0"(i64 %r49.rs4i) #9
  %r50 = bitcast i64 %r49 to double
  %r51 = and i64 %r49, -281474976710656
  %r52 = icmp ult i64 %r51, 9221401712017801216
  %r53 = icmp ugt i64 %r51, 9223090561878065152
  %r54 = or i1 %r52, %r53
  %r55 = bitcast double %r482 to i64
  %r56 = and i64 %r55, -281474976710656
  %r57 = icmp ult i64 %r56, 9221401712017801216
  %r58 = icmp ugt i64 %r56, 9223090561878065152
  %r59 = or i1 %r57, %r58
  %r60 = and i1 %r54, %r59
  br i1 %r60, label %guarded_add.numeric.16, label %guarded_add.dynamic.17

guarded_add.numeric.16:                           ; preds = %shadow.root.barrier.done.15
  %r61 = fadd double %r50, %r482
  br label %guarded_add.merge.18

guarded_add.dynamic.17:                           ; preds = %shadow.root.barrier.done.15
  %statepoint_token6 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r50, double %r482, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated3, ptr addrspace(1) %rs4gc.s4.relocated4, ptr addrspace(1) %rs4gc.s2.relocated5) ]
  %r627 = call double @llvm.experimental.gc.result.f64(token %statepoint_token6)
  %rs4gc.s3.relocated8 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token6, i32 0, i32 0) ; (%rs4gc.s3.relocated3, %rs4gc.s3.relocated3)
  %rs4gc.s4.relocated9 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token6, i32 1, i32 1) ; (%rs4gc.s4.relocated4, %rs4gc.s4.relocated4)
  %rs4gc.s2.relocated10 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token6, i32 2, i32 2) ; (%rs4gc.s2.relocated5, %rs4gc.s2.relocated5)
  br label %guarded_add.merge.18

guarded_add.merge.18:                             ; preds = %guarded_add.dynamic.17, %guarded_add.numeric.16
  %.323 = phi ptr addrspace(1) [ %rs4gc.s2.relocated5, %guarded_add.numeric.16 ], [ %rs4gc.s2.relocated10, %guarded_add.dynamic.17 ]
  %.318 = phi ptr addrspace(1) [ %rs4gc.s4.relocated4, %guarded_add.numeric.16 ], [ %rs4gc.s4.relocated9, %guarded_add.dynamic.17 ]
  %.3 = phi ptr addrspace(1) [ %rs4gc.s3.relocated3, %guarded_add.numeric.16 ], [ %rs4gc.s3.relocated8, %guarded_add.dynamic.17 ]
  %r63 = phi double [ %r61, %guarded_add.numeric.16 ], [ %r627, %guarded_add.dynamic.17 ]
  %rs4gc.b7 = bitcast double %r63 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r64.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r64 = call i64 asm "", "=r,0"(i64 %r64.rs4i) #9
  %r65 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r66 = icmp ne i32 %r65, 0
  br i1 %r66, label %shadow.root.barrier.19, label %shadow.root.barrier.done.20

shadow.root.barrier.19:                           ; preds = %guarded_add.merge.18
  call void @js_write_barrier_root_nanbox(i64 %r64) #9
  br label %shadow.root.barrier.done.20

shadow.root.barrier.done.20:                      ; preds = %shadow.root.barrier.19, %guarded_add.merge.18
  %r67 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r68 = icmp ne i32 %r67, 0
  br i1 %r68, label %gcpoll.21, label %gcpoll.done.22

gcpoll.21:                                        ; preds = %shadow.root.barrier.done.20
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7, ptr addrspace(1) %.318, ptr addrspace(1) %.323, ptr addrspace(1) %.3) ]
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 0, i32 0) ; (%rs4gc.s7, %rs4gc.s7)
  %rs4gc.s4.relocated12 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 1, i32 1) ; (%.318, %.318)
  %rs4gc.s2.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 2, i32 2) ; (%.323, %.323)
  %rs4gc.s3.relocated14 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 3, i32 3) ; (%.3, %.3)
  br label %gcpoll.done.22

gcpoll.done.22:                                   ; preds = %gcpoll.21, %shadow.root.barrier.done.20
  %.028 = phi ptr addrspace(1) [ %rs4gc.s7.relocated, %gcpoll.21 ], [ %rs4gc.s7, %shadow.root.barrier.done.20 ]
  %.424 = phi ptr addrspace(1) [ %rs4gc.s2.relocated13, %gcpoll.21 ], [ %.323, %shadow.root.barrier.done.20 ]
  %.419 = phi ptr addrspace(1) [ %rs4gc.s4.relocated12, %gcpoll.21 ], [ %.318, %shadow.root.barrier.done.20 ]
  %.4 = phi ptr addrspace(1) [ %rs4gc.s3.relocated14, %gcpoll.21 ], [ %.3, %shadow.root.barrier.done.20 ]
  br label %for.update.8
}

; Function Attrs: optsize
define internal double @"perry_fn_short_loops_ts__sum$generic"(double %arg11, double %arg12) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b2 = bitcast double %arg11 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg12 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #9
  %r5 = bitcast i64 %r5.rs4o to double
  %r6 = bitcast double %r5 to i64
  %r7 = and i64 %r6, -281474976710656
  %r8 = icmp ult i64 %r7, 9221401712017801216
  %r9 = icmp ugt i64 %r7, 9223090561878065152
  %r10 = or i1 %r8, %r9
  br i1 %r10, label %invariant_field.range.3, label %invariant_field.slow.1

invariant_field.slow.1:                           ; preds = %invariant_field.probe.5, %invariant_field.convert.4, %invariant_field.range.3, %entry.0
  %r42.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r42.rs4o = call i64 asm "", "=r,0"(i64 %r42.rs4i) #9
  %r42 = bitcast i64 %r42.rs4o to double
  %r43 = bitcast double %r42 to i64
  %r44 = and i64 %r43, -281474976710656
  %r45 = icmp ult i64 %r44, 9221401712017801216
  %r46 = icmp ugt i64 %r44, 9223090561878065152
  %r47 = or i1 %r45, %r46
  br i1 %r47, label %for.invariant_field_slow.bound_i32.number.9, label %for.invariant_field_slow.bound_i32.merge.11

invariant_field.merge.2:                          ; preds = %for.invariant_field_slow.exit.17, %invariant_field.fast.exit.8
  %r3.0 = phi ptr addrspace(1) [ %rs4gc.s5, %invariant_field.fast.exit.8 ], [ %.154, %for.invariant_field_slow.exit.17 ]
  %r610.rs4i = ptrtoint ptr addrspace(1) %r3.0 to i64
  %r610.rs4o = call i64 asm "", "=r,0"(i64 %r610.rs4i) #9
  %r610 = bitcast i64 %r610.rs4o to double
  ret double %r610

invariant_field.range.3:                          ; preds = %entry.0
  %r11 = fcmp ogt double %r5, 0.000000e+00
  %r12 = fcmp ole double %r5, 0x41DFFFFFFFC00000
  %r13 = and i1 %r11, %r12
  br i1 %r13, label %invariant_field.convert.4, label %invariant_field.slow.1

invariant_field.convert.4:                        ; preds = %invariant_field.range.3
  %r14 = fptosi double %r5 to i32
  %r15 = sitofp i32 %r14 to double
  %r16 = fcmp oeq double %r5, %r15
  br i1 %r16, label %invariant_field.probe.5, label %invariant_field.slow.1

invariant_field.probe.5:                          ; preds = %invariant_field.convert.4
  %r17.rs4o = call i64 asm "", "=r,0"(i64 0) #9
  %r17 = bitcast i64 %r17.rs4o to double
  %r18 = bitcast double %r17 to i64
  %r19 = and i64 %r18, -281474976710656
  %r20 = icmp ult i64 %r19, 9221401712017801216
  %r21 = icmp ugt i64 %r19, 9223090561878065152
  %r22 = or i1 %r20, %r21
  %r23.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r23.rs4o = call i64 asm "", "=r,0"(i64 %r23.rs4i) #9
  %r23 = bitcast i64 %r23.rs4o to double
  %r24 = call double @js_array_index_own_number(double %r23, i32 7, ptr @short_loops_ts_.str.0.bytes, i64 2) #9
  %r25 = bitcast double %r24 to i64
  %r26 = and i64 %r25, -281474976710656
  %r27 = icmp ult i64 %r26, 9221401712017801216
  %r28 = icmp ugt i64 %r26, 9223090561878065152
  %r29 = or i1 %r27, %r28
  %r30 = and i1 %r22, %r29
  br i1 %r30, label %invariant_field.fast.preheader.6, label %invariant_field.slow.1

invariant_field.fast.preheader.6:                 ; preds = %invariant_field.probe.5
  %r612.rs4o = call i64 asm "", "=r,0"(i64 0) #9
  %r612 = bitcast i64 %r612.rs4o to double
  br label %invariant_field.fast.body.7

invariant_field.fast.body.7:                      ; preds = %invariant_field.fast.body.7, %invariant_field.fast.preheader.6
  %r32.0 = phi i32 [ 0, %invariant_field.fast.preheader.6 ], [ %r36, %invariant_field.fast.body.7 ]
  %r31.0 = phi double [ %r612, %invariant_field.fast.preheader.6 ], [ %r34, %invariant_field.fast.body.7 ]
  %r34 = fadd double %r31.0, %r24
  %r36 = add i32 %r32.0, 1
  %r37 = icmp slt i32 %r36, %r14
  br i1 %r37, label %invariant_field.fast.body.7, label %invariant_field.fast.exit.8

invariant_field.fast.exit.8:                      ; preds = %invariant_field.fast.body.7
  %rs4gc.b5 = bitcast double %r34 to i64
  %rs4gc.s5 = inttoptr i64 %rs4gc.b5 to ptr addrspace(1)
  %r38 = sitofp i32 %r36 to double
  br label %invariant_field.merge.2

for.invariant_field_slow.bound_i32.number.9:      ; preds = %invariant_field.slow.1
  %r48 = fcmp oge double %r42, 0xC1E0000000000000
  %r49 = fcmp ole double %r42, 0x41DFFFFFFFC00000
  %r50 = and i1 %r48, %r49
  br i1 %r50, label %for.invariant_field_slow.bound_i32.convert.10, label %for.invariant_field_slow.bound_i32.merge.11

for.invariant_field_slow.bound_i32.convert.10:    ; preds = %for.invariant_field_slow.bound_i32.number.9
  %r51 = fptosi double %r42 to i32
  %r52 = sitofp i32 %r51 to double
  %r53 = fcmp oeq double %r52, %r42
  br i1 %r53, label %for.invariant_field_slow.counter_i32.range.12, label %for.invariant_field_slow.bound_i32.merge.11

for.invariant_field_slow.bound_i32.merge.11:      ; preds = %for.invariant_field_slow.counter_i32.convert.13, %for.invariant_field_slow.bound_i32.convert.10, %for.invariant_field_slow.bound_i32.number.9, %invariant_field.slow.1
  %r41.0 = phi i32 [ %r51, %for.invariant_field_slow.counter_i32.convert.13 ], [ 0, %invariant_field.slow.1 ], [ %r51, %for.invariant_field_slow.bound_i32.convert.10 ], [ 0, %for.invariant_field_slow.bound_i32.number.9 ]
  %r40.0 = phi i1 [ true, %for.invariant_field_slow.counter_i32.convert.13 ], [ false, %invariant_field.slow.1 ], [ false, %for.invariant_field_slow.bound_i32.convert.10 ], [ false, %for.invariant_field_slow.bound_i32.number.9 ]
  br label %for.invariant_field_slow.cond.14

for.invariant_field_slow.counter_i32.range.12:    ; preds = %for.invariant_field_slow.bound_i32.convert.10
  br label %for.invariant_field_slow.counter_i32.convert.13

for.invariant_field_slow.counter_i32.convert.13:  ; preds = %for.invariant_field_slow.counter_i32.range.12
  br label %for.invariant_field_slow.bound_i32.merge.11

for.invariant_field_slow.cond.14:                 ; preds = %for.invariant_field_slow.update.16, %for.invariant_field_slow.bound_i32.merge.11
  %.043 = phi ptr addrspace(1) [ %rs4gc.s3, %for.invariant_field_slow.bound_i32.merge.11 ], [ %.952, %for.invariant_field_slow.update.16 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s2, %for.invariant_field_slow.bound_i32.merge.11 ], [ %.9, %for.invariant_field_slow.update.16 ]
  %r39.1 = phi i32 [ 0, %for.invariant_field_slow.bound_i32.merge.11 ], [ %r609, %for.invariant_field_slow.update.16 ]
  %r4.0 = phi double [ 0.000000e+00, %for.invariant_field_slow.bound_i32.merge.11 ], [ %r607, %for.invariant_field_slow.update.16 ]
  %r3.1 = phi ptr addrspace(1) [ null, %for.invariant_field_slow.bound_i32.merge.11 ], [ %.061, %for.invariant_field_slow.update.16 ]
  br i1 %r40.0, label %for.invariant_field_slow.cond.fast.18, label %for.invariant_field_slow.cond.slow.19

for.invariant_field_slow.body.15:                 ; preds = %gcpoll.done.24, %for.invariant_field_slow.cond.fast.18
  %.053 = phi ptr addrspace(1) [ %r3.1, %for.invariant_field_slow.cond.fast.18 ], [ %.356, %gcpoll.done.24 ]
  %.144 = phi ptr addrspace(1) [ %.043, %for.invariant_field_slow.cond.fast.18 ], [ %.346, %gcpoll.done.24 ]
  %.1 = phi ptr addrspace(1) [ %.0, %for.invariant_field_slow.cond.fast.18 ], [ %.3, %gcpoll.done.24 ]
  %r102.rs4i = ptrtoint ptr addrspace(1) %.053 to i64
  %r102.rs4o = call i64 asm "", "=r,0"(i64 %r102.rs4i) #9
  %r102 = bitcast i64 %r102.rs4o to double
  %r103 = bitcast double %r102 to i64
  %rs4gc.s6 = inttoptr i64 %r103 to ptr addrspace(1)
  %r105.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r105 = call i64 asm "", "=r,0"(i64 %r105.rs4i) #9
  %r106 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r107 = icmp ne i32 %r106, 0
  br i1 %r107, label %shadow.root.barrier.25, label %shadow.root.barrier.done.26

for.invariant_field_slow.update.16:               ; preds = %gcpoll.done.123
  %r607 = fadd double %r4.0, 1.000000e+00
  %r609 = add i32 %r39.1, 1
  br label %for.invariant_field_slow.cond.14

for.invariant_field_slow.exit.17:                 ; preds = %gcpoll.done.24, %for.invariant_field_slow.cond.fast.18
  %.154 = phi ptr addrspace(1) [ %r3.1, %for.invariant_field_slow.cond.fast.18 ], [ %.356, %gcpoll.done.24 ]
  br label %invariant_field.merge.2

for.invariant_field_slow.cond.fast.18:            ; preds = %for.invariant_field_slow.cond.14
  %r64 = icmp slt i32 %r39.1, %r41.0
  br i1 %r64, label %for.invariant_field_slow.body.15, label %for.invariant_field_slow.exit.17

for.invariant_field_slow.cond.slow.19:            ; preds = %for.invariant_field_slow.cond.14
  %r66.rs4i = ptrtoint ptr addrspace(1) %.043 to i64
  %r66.rs4o = call i64 asm "", "=r,0"(i64 %r66.rs4i) #9
  %r66 = bitcast i64 %r66.rs4o to double
  %r67 = bitcast double %r66 to i64
  %r68 = lshr i64 %r67, 48
  %r69 = icmp ult i64 %r68, 32761
  %r70 = icmp ugt i64 %r68, 32767
  %r71 = or i1 %r69, %r70
  %r72 = icmp eq i64 %r68, 32766
  %r73 = icmp eq i64 %r67, 9222246136947933185
  %r74 = icmp eq i64 %r67, 9222246136947933186
  %r75 = icmp eq i64 %r67, 9222246136947933187
  %r76 = icmp eq i64 %r67, 9222246136947933188
  %r77 = or i1 %r74, %r75
  %r78 = or i1 %r71, %r72
  %r79 = or i1 %r78, %r73
  %r80 = or i1 %r79, %r77
  %r81 = or i1 %r80, %r76
  br i1 %r81, label %relnum.fast.20, label %relnum.slow.21

relnum.fast.20:                                   ; preds = %for.invariant_field_slow.cond.slow.19
  %r82 = trunc i64 %r67 to i32
  %r83 = sitofp i32 %r82 to double
  %r84 = select i1 %r72, double %r83, double %r66
  %r85 = select i1 %r77, double 0.000000e+00, double %r84
  %r86 = select i1 %r76, double 1.000000e+00, double %r85
  %r87 = bitcast double %r4.0 to i64
  %r88 = lshr i64 %r87, 48
  %r89 = icmp eq i64 %r88, 32766
  %r90 = trunc i64 %r87 to i32
  %r91 = sitofp i32 %r90 to double
  %r92 = select i1 %r89, double %r91, double %r4.0
  %r93 = fcmp olt double %r92, %r86
  %r94 = select i1 %r93, i64 9222246136947933188, i64 9222246136947933187
  %r95 = bitcast i64 %r94 to double
  br label %relnum.merge.22

relnum.slow.21:                                   ; preds = %for.invariant_field_slow.cond.slow.19
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r4.0, double %r66, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0, ptr addrspace(1) %.043, ptr addrspace(1) %r3.1) ]
  %r961 = call double @llvm.experimental.gc.result.f64(token %statepoint_token)
  %rs4gc.s2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%.0, %.0)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%.043, %.043)
  %r3.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 2, i32 2) ; (%r3.1, %r3.1)
  br label %relnum.merge.22

relnum.merge.22:                                  ; preds = %relnum.slow.21, %relnum.fast.20
  %.255 = phi ptr addrspace(1) [ %r3.1, %relnum.fast.20 ], [ %r3.1.relocated, %relnum.slow.21 ]
  %.245 = phi ptr addrspace(1) [ %.043, %relnum.fast.20 ], [ %rs4gc.s3.relocated, %relnum.slow.21 ]
  %.2 = phi ptr addrspace(1) [ %.0, %relnum.fast.20 ], [ %rs4gc.s2.relocated, %relnum.slow.21 ]
  %r97 = phi double [ %r95, %relnum.fast.20 ], [ %r961, %relnum.slow.21 ]
  %r98 = bitcast double %r97 to i64
  %r100 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r101 = icmp ne i32 %r100, 0
  br i1 %r101, label %gcpoll.23, label %gcpoll.done.24

gcpoll.23:                                        ; preds = %relnum.merge.22
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.245, ptr addrspace(1) %.2, ptr addrspace(1) %.255) ]
  %rs4gc.s3.relocated3 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token2, i32 0, i32 0) ; (%.245, %.245)
  %rs4gc.s2.relocated4 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token2, i32 1, i32 1) ; (%.2, %.2)
  %r3.1.relocated5 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token2, i32 2, i32 2) ; (%.255, %.255)
  br label %gcpoll.done.24

gcpoll.done.24:                                   ; preds = %gcpoll.23, %relnum.merge.22
  %.356 = phi ptr addrspace(1) [ %r3.1.relocated5, %gcpoll.23 ], [ %.255, %relnum.merge.22 ]
  %.346 = phi ptr addrspace(1) [ %rs4gc.s3.relocated3, %gcpoll.23 ], [ %.245, %relnum.merge.22 ]
  %.3 = phi ptr addrspace(1) [ %rs4gc.s2.relocated4, %gcpoll.23 ], [ %.2, %relnum.merge.22 ]
  %r99 = icmp eq i64 %r98, 9222246136947933188
  br i1 %r99, label %for.invariant_field_slow.body.15, label %for.invariant_field_slow.exit.17

shadow.root.barrier.25:                           ; preds = %for.invariant_field_slow.body.15
  call void @js_write_barrier_root_nanbox(i64 %r105) #9
  br label %shadow.root.barrier.done.26

shadow.root.barrier.done.26:                      ; preds = %shadow.root.barrier.25, %for.invariant_field_slow.body.15
  %r108.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r108.rs4o = call i64 asm "", "=r,0"(i64 %r108.rs4i) #9
  %r108 = bitcast i64 %r108.rs4o to double
  %r109 = bitcast double %r108 to i64
  %r110 = and i64 %r109, 281474976710655
  %r111 = and i64 %r109, -281474976710656
  %r112 = icmp eq i64 %r111, 9222527611924643840
  %r113 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r114 = icmp eq i64 %r113, 0
  %r115 = icmp ugt i64 %r110, 1048575
  %r116 = icmp ult i64 %r110, 140737488355328
  %r117 = and i1 %r115, %r116
  %r118 = and i1 %r112, %r114
  %r119 = and i1 %r118, %r117
  br i1 %r119, label %tav.get.brand.31, label %tav.get.slow.29

tav.get.fast.27:                                  ; preds = %tav.get.brand.31
  %r136 = bitcast double %r108 to i64
  %r137 = and i64 %r136, 281474976710655
  %r138 = add nuw nsw i64 %r137, 8
  %r139 = inttoptr i64 %r138 to ptr
  %r140 = load i8, ptr %r139, align 1
  %r141 = zext i8 %r140 to i64
  %r145 = inttoptr i64 %r137 to ptr
  %r146 = load i32, ptr %r145, align 4
  %r147 = zext i32 %r146 to i64
  %r148 = icmp ult i64 7, %r147
  %r149 = and i1 true, %r148
  br i1 %r149, label %tav.get.load.28, label %tav.get.slow.29

tav.get.load.28:                                  ; preds = %tav.get.fast.27
  %r150 = add nuw nsw i64 %r137, 16
  %r151 = icmp eq i64 %r141, 0
  br i1 %r151, label %tav.k.i8.32, label %tav.kd1.40

tav.get.slow.29:                                  ; preds = %tav.get.brand.31, %tav.get.fast.27, %shadow.root.barrier.done.26
  %r202 = load ptr, ptr @perry_ic_short_loops_ts__3, align 8
  %r203 = icmp ne ptr %r202, null
  %r204 = select i1 %r203, ptr %r202, ptr @perry_ic_short_loops_ts__3
  %r205 = bitcast double %r108 to i64
  %r206 = and i64 %r205, 281474976710655
  %r207 = and i64 %r205, -281474976710656
  %r208 = icmp eq i64 %r207, 9222527611924643840
  %r209 = icmp uge i64 %r206, 2199023255552
  %r210 = icmp ult i64 %r206, 140737488355328
  %r213 = and i1 %r208, %r209
  %r214 = and i1 %r213, %r210
  br i1 %r214, label %arrlike.ic.header.47, label %arrlike.ic.miss.66

tav.get.merge.30:                                 ; preds = %json.scalar.exposed.79, %arrlike.elem.value.72, %arrlike.ic.miss.66, %arrlike.ic.spill_load.65, %arrlike.ic.inline.62, %arrlike.ic.array_load.50, %tav.k.f64.39, %tav.k.f32.38, %tav.k.u32.37, %tav.k.i32.36, %tav.k.u16.35, %tav.k.i16.34, %tav.k.u8.33, %tav.k.i8.32
  %.057 = phi ptr addrspace(1) [ %rs4gc.s6, %tav.k.i8.32 ], [ %rs4gc.s6, %tav.k.u8.33 ], [ %rs4gc.s6, %tav.k.i16.34 ], [ %rs4gc.s6, %tav.k.u16.35 ], [ %rs4gc.s6, %tav.k.i32.36 ], [ %rs4gc.s6, %tav.k.u32.37 ], [ %rs4gc.s6, %tav.k.f32.38 ], [ %rs4gc.s6, %tav.k.f64.39 ], [ %rs4gc.s6, %arrlike.ic.array_load.50 ], [ %rs4gc.s6.relocated, %arrlike.ic.miss.66 ], [ %rs4gc.s6, %arrlike.elem.value.72 ], [ %rs4gc.s6, %arrlike.ic.inline.62 ], [ %rs4gc.s6, %arrlike.ic.spill_load.65 ], [ %rs4gc.s6, %json.scalar.exposed.79 ]
  %.447 = phi ptr addrspace(1) [ %.144, %tav.k.i8.32 ], [ %.144, %tav.k.u8.33 ], [ %.144, %tav.k.i16.34 ], [ %.144, %tav.k.u16.35 ], [ %.144, %tav.k.i32.36 ], [ %.144, %tav.k.u32.37 ], [ %.144, %tav.k.f32.38 ], [ %.144, %tav.k.f64.39 ], [ %.144, %arrlike.ic.array_load.50 ], [ %rs4gc.s3.relocated8, %arrlike.ic.miss.66 ], [ %.144, %arrlike.elem.value.72 ], [ %.144, %arrlike.ic.inline.62 ], [ %.144, %arrlike.ic.spill_load.65 ], [ %.144, %json.scalar.exposed.79 ]
  %.4 = phi ptr addrspace(1) [ %.1, %tav.k.i8.32 ], [ %.1, %tav.k.u8.33 ], [ %.1, %tav.k.i16.34 ], [ %.1, %tav.k.u16.35 ], [ %.1, %tav.k.i32.36 ], [ %.1, %tav.k.u32.37 ], [ %.1, %tav.k.f32.38 ], [ %.1, %tav.k.f64.39 ], [ %.1, %arrlike.ic.array_load.50 ], [ %rs4gc.s2.relocated9, %arrlike.ic.miss.66 ], [ %.1, %arrlike.elem.value.72 ], [ %.1, %arrlike.ic.inline.62 ], [ %.1, %arrlike.ic.spill_load.65 ], [ %.1, %json.scalar.exposed.79 ]
  %r437 = phi double [ %r164, %tav.k.i8.32 ], [ %r170, %tav.k.u8.33 ], [ %r176, %tav.k.i16.34 ], [ %r182, %tav.k.u16.35 ], [ %r187, %tav.k.i32.36 ], [ %r192, %tav.k.u32.37 ], [ %r197, %tav.k.f32.38 ], [ %r201, %tav.k.f64.39 ], [ %r277, %json.scalar.exposed.79 ], [ %r319, %arrlike.elem.value.72 ], [ %r348, %arrlike.ic.array_load.50 ], [ %r418, %arrlike.ic.inline.62 ], [ %r435, %arrlike.ic.spill_load.65 ], [ %r4367, %arrlike.ic.miss.66 ]
  %r438 = bitcast double %r437 to i64
  %r439 = and i64 %r438, 281474976710655
  %r440 = lshr i64 %r438, 48
  %r441 = and i64 %r440, 65533
  %r442 = icmp eq i64 %r441, 32765
  br i1 %r442, label %pget.recv_ok.87, label %pget.recv_other.91

tav.get.brand.31:                                 ; preds = %shadow.root.barrier.done.26
  %r120 = bitcast double %r108 to i64
  %r121 = and i64 %r120, 281474976710655
  %r122 = sub nsw i64 %r121, 8
  %r123 = inttoptr i64 %r122 to ptr
  %r124 = load i8, ptr %r123, align 1
  %r125 = icmp eq i8 %r124, 11
  %r126 = add nuw nsw i64 %r121, 8
  %r127 = inttoptr i64 %r126 to ptr
  %r128 = load i8, ptr %r127, align 1
  %r129 = zext i8 %r128 to i64
  %r130 = icmp ule i64 %r129, 8
  %r133 = and i1 %r125, %r130
  br i1 %r133, label %tav.get.fast.27, label %tav.get.slow.29

tav.k.i8.32:                                      ; preds = %tav.get.load.28
  %r160 = add nuw nsw i64 %r150, 7
  %r161 = inttoptr i64 %r160 to ptr
  %r162 = load i8, ptr %r161, align 1
  %r163 = sext i8 %r162 to i32
  %r164 = sitofp i32 %r163 to double
  br label %tav.get.merge.30

tav.k.u8.33:                                      ; preds = %tav.kd7.46, %tav.kd1.40
  %r166 = add nuw nsw i64 %r150, 7
  %r167 = inttoptr i64 %r166 to ptr
  %r168 = load i8, ptr %r167, align 1
  %r169 = zext i8 %r168 to i32
  %r170 = uitofp nneg i32 %r169 to double
  br label %tav.get.merge.30

tav.k.i16.34:                                     ; preds = %tav.kd2.41
  %r172 = add nuw nsw i64 %r150, 14
  %r173 = inttoptr i64 %r172 to ptr
  %r174 = load i16, ptr %r173, align 2
  %r175 = sext i16 %r174 to i32
  %r176 = sitofp i32 %r175 to double
  br label %tav.get.merge.30

tav.k.u16.35:                                     ; preds = %tav.kd3.42
  %r178 = add nuw nsw i64 %r150, 14
  %r179 = inttoptr i64 %r178 to ptr
  %r180 = load i16, ptr %r179, align 2
  %r181 = zext i16 %r180 to i32
  %r182 = uitofp nneg i32 %r181 to double
  br label %tav.get.merge.30

tav.k.i32.36:                                     ; preds = %tav.kd4.43
  %r184 = add nuw nsw i64 %r150, 28
  %r185 = inttoptr i64 %r184 to ptr
  %r186 = load i32, ptr %r185, align 4
  %r187 = sitofp i32 %r186 to double
  br label %tav.get.merge.30

tav.k.u32.37:                                     ; preds = %tav.kd5.44
  %r189 = add nuw nsw i64 %r150, 28
  %r190 = inttoptr i64 %r189 to ptr
  %r191 = load i32, ptr %r190, align 4
  %r192 = uitofp i32 %r191 to double
  br label %tav.get.merge.30

tav.k.f32.38:                                     ; preds = %tav.kd6.45
  %r194 = add nuw nsw i64 %r150, 28
  %r195 = inttoptr i64 %r194 to ptr
  %r196 = load float, ptr %r195, align 4
  %r197 = fpext float %r196 to double
  br label %tav.get.merge.30

tav.k.f64.39:                                     ; preds = %tav.kd7.46
  %r199 = add nuw nsw i64 %r150, 56
  %r200 = inttoptr i64 %r199 to ptr
  %r201 = load double, ptr %r200, align 8
  br label %tav.get.merge.30

tav.kd1.40:                                       ; preds = %tav.get.load.28
  %r152 = icmp eq i64 %r141, 1
  br i1 %r152, label %tav.k.u8.33, label %tav.kd2.41

tav.kd2.41:                                       ; preds = %tav.kd1.40
  %r153 = icmp eq i64 %r141, 2
  br i1 %r153, label %tav.k.i16.34, label %tav.kd3.42

tav.kd3.42:                                       ; preds = %tav.kd2.41
  %r154 = icmp eq i64 %r141, 3
  br i1 %r154, label %tav.k.u16.35, label %tav.kd4.43

tav.kd4.43:                                       ; preds = %tav.kd3.42
  %r155 = icmp eq i64 %r141, 4
  br i1 %r155, label %tav.k.i32.36, label %tav.kd5.44

tav.kd5.44:                                       ; preds = %tav.kd4.43
  %r156 = icmp eq i64 %r141, 5
  br i1 %r156, label %tav.k.u32.37, label %tav.kd6.45

tav.kd6.45:                                       ; preds = %tav.kd5.44
  %r157 = icmp eq i64 %r141, 6
  br i1 %r157, label %tav.k.f32.38, label %tav.kd7.46

tav.kd7.46:                                       ; preds = %tav.kd6.45
  %r158 = icmp eq i64 %r141, 7
  br i1 %r158, label %tav.k.f64.39, label %tav.k.u8.33

arrlike.ic.header.47:                             ; preds = %tav.get.slow.29
  %r220 = sub nuw nsw i64 %r206, 8
  %r221 = inttoptr i64 %r220 to ptr
  %r222 = load i8, ptr %r221, align 1
  %r224 = sub nuw nsw i64 %r206, 7
  %r225 = inttoptr i64 %r224 to ptr
  %r226 = load i8, ptr %r225, align 1
  %r227 = and i8 %r226, -128
  %r228 = icmp eq i8 %r227, 0
  %r229 = and i1 true, %r228
  br i1 %r229, label %arrlike.ic.brand.48, label %arrlike.ic.miss.66

arrlike.ic.brand.48:                              ; preds = %arrlike.ic.header.47
  %r223 = icmp eq i8 %r222, 1
  br i1 %r223, label %arrlike.ic.array_guard.49, label %arrlike.elem.kind.67

arrlike.ic.array_guard.49:                        ; preds = %json.scalar.materialized_ready.77, %arrlike.ic.brand.48
  %r322 = phi i64 [ %r206, %arrlike.ic.brand.48 ], [ %r246, %json.scalar.materialized_ready.77 ]
  %r323 = sub i64 %r322, 6
  %r324 = inttoptr i64 %r323 to ptr
  %r325 = load i16, ptr %r324, align 2
  %r326 = and i16 %r325, 1024
  %r327 = icmp eq i16 %r326, 0
  %r328 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r329 = icmp eq i8 %r328, 0
  %r330 = inttoptr i64 %r322 to ptr
  %r331 = load i32, ptr %r330, align 4
  %r332 = add i64 %r322, 4
  %r333 = inttoptr i64 %r332 to ptr
  %r334 = load i32, ptr %r333, align 4
  %r335 = zext i32 %r331 to i64
  %r336 = zext i32 %r334 to i64
  %r337 = icmp ult i64 7, %r335
  %r338 = icmp ule i64 %r335, %r336
  %r339 = and i1 %r327, %r329
  %r340 = and i1 %r339, %r337
  %r341 = and i1 %r340, %r338
  br i1 %r341, label %arrlike.ic.array_load.50, label %arrlike.ic.miss.66

arrlike.ic.array_load.50:                         ; preds = %arrlike.ic.array_guard.49
  %r343 = getelementptr inbounds nuw i64, ptr %r330, i64 8
  %r344 = load double, ptr %r343, align 8
  %r345 = bitcast double %r344 to i64
  %r346 = icmp eq i64 %r345, 9222246136947933200
  %r348 = select i1 %r346, double 0x7FFC000000000001, double %r344
  br label %tav.get.merge.30

arrlike.ic.shape.51:                              ; preds = %arrlike.elem.store.69, %arrlike.elem.meta.68
  %r350 = inttoptr i64 %r206 to ptr
  %r351 = load i32, ptr %r350, align 4
  %r352 = add nuw nsw i64 %r206, 4
  %r353 = inttoptr i64 %r352 to ptr
  %r354 = load i32, ptr %r353, align 4
  %r355 = zext i32 %r351 to i64
  %r356 = zext i32 %r354 to i64
  %r357 = shl nuw i64 %r355, 32
  %r358 = or i64 %r357, %r356
  %r359 = getelementptr i64, ptr %r204, i64 0
  %r360 = load i64, ptr %r359, align 8
  %r361 = icmp ne i64 %r360, 0
  %r362 = and i1 true, %r361
  br i1 %r362, label %arrlike.ic.identity.52, label %arrlike.ic.miss.66

arrlike.ic.identity.52:                           ; preds = %arrlike.ic.shape.51
  %r363 = and i64 %r360, -9223372036854775808
  %0 = icmp slt i64 %r360, 0
  br i1 %0, label %arrlike.ic.family_meta.54, label %arrlike.ic.exact.53

arrlike.ic.exact.53:                              ; preds = %arrlike.ic.identity.52
  %r365 = icmp eq i64 %r358, %r360
  br i1 %r365, label %arrlike.ic.bounds.56, label %arrlike.ic.miss.66

arrlike.ic.family_meta.54:                        ; preds = %arrlike.ic.identity.52
  %r366 = add nuw nsw i64 %r206, 8
  %r367 = inttoptr i64 %r366 to ptr
  %r368 = load i64, ptr %r367, align 8
  %r369 = icmp ne i64 %r368, 0
  br i1 %r369, label %arrlike.ic.family_token.55, label %arrlike.ic.miss.66

arrlike.ic.family_token.55:                       ; preds = %arrlike.ic.family_meta.54
  %r370 = inttoptr i64 %r368 to ptr
  %r371 = getelementptr i64, ptr %r370, i64 6
  %r372 = load i64, ptr %r371, align 8
  %r373 = icmp eq i64 %r372, %r360
  br i1 %r373, label %arrlike.ic.bounds.56, label %arrlike.ic.miss.66

arrlike.ic.bounds.56:                             ; preds = %arrlike.ic.family_token.55, %arrlike.ic.exact.53
  %r374 = getelementptr i64, ptr %r202, i64 1
  %r375 = load i64, ptr %r374, align 8
  %r376 = getelementptr i64, ptr %r202, i64 2
  %r377 = load i64, ptr %r376, align 8
  %r378 = getelementptr i64, ptr %r202, i64 3
  %r379 = load i64, ptr %r378, align 8
  %r380 = getelementptr i64, ptr %r202, i64 4
  %r381 = load i64, ptr %r380, align 8
  %r382 = icmp ult i64 %r375, %r381
  br i1 %r382, label %arrlike.ic.length_inline.57, label %arrlike.ic.length_spill_meta.58

arrlike.ic.length_inline.57:                      ; preds = %arrlike.ic.bounds.56
  %r383 = shl i64 %r375, 3
  %r384 = add i64 %r383, 16
  %r385 = add i64 %r206, %r384
  %r386 = inttoptr i64 %r385 to ptr
  %r387 = load double, ptr %r386, align 8
  br label %arrlike.ic.range.61

arrlike.ic.length_spill_meta.58:                  ; preds = %arrlike.ic.bounds.56
  %r388 = add nuw nsw i64 %r206, 8
  %r389 = inttoptr i64 %r388 to ptr
  %r390 = load i64, ptr %r389, align 8
  %r391 = icmp ne i64 %r390, 0
  br i1 %r391, label %arrlike.ic.length_spill_ptr.59, label %arrlike.ic.miss.66

arrlike.ic.length_spill_ptr.59:                   ; preds = %arrlike.ic.length_spill_meta.58
  %r392 = inttoptr i64 %r390 to ptr
  %r393 = getelementptr i64, ptr %r392, i64 4
  %r394 = load i64, ptr %r393, align 8
  %r395 = icmp ne i64 %r394, 0
  %r396 = select i1 %r395, i64 %r394, i64 %r390
  %r397 = inttoptr i64 %r396 to ptr
  %r398 = load i32, ptr %r397, align 4
  %r399 = zext i32 %r398 to i64
  %r400 = icmp ult i64 %r375, %r399
  %r401 = and i1 %r395, %r400
  br i1 %r401, label %arrlike.ic.length_spill_load.60, label %arrlike.ic.miss.66

arrlike.ic.length_spill_load.60:                  ; preds = %arrlike.ic.length_spill_ptr.59
  %r402 = add nuw nsw i64 %r375, 1
  %r403 = getelementptr inbounds nuw i64, ptr %r397, i64 %r402
  %r404 = load double, ptr %r403, align 8
  br label %arrlike.ic.range.61

arrlike.ic.range.61:                              ; preds = %arrlike.ic.length_spill_load.60, %arrlike.ic.length_inline.57
  %r405 = phi double [ %r387, %arrlike.ic.length_inline.57 ], [ %r404, %arrlike.ic.length_spill_load.60 ]
  %r406 = fcmp olt double 7.000000e+00, %r405
  %r407 = icmp ult i64 7, %r379
  %r408 = and i1 %r406, %r407
  %r409 = add i64 %r377, 7
  %r410 = icmp ult i64 %r409, %r381
  %r411 = and i1 %r408, %r410
  %r412 = xor i1 %r410, true
  %r413 = and i1 %r408, %r412
  br i1 %r411, label %arrlike.ic.inline.62, label %arrlike.ic.spill_or_miss.85

arrlike.ic.inline.62:                             ; preds = %arrlike.ic.range.61
  %r414 = shl i64 %r409, 3
  %r415 = add i64 %r414, 16
  %r416 = add i64 %r206, %r415
  %r417 = inttoptr i64 %r416 to ptr
  %r418 = load double, ptr %r417, align 8
  br label %tav.get.merge.30

arrlike.ic.spill.63:                              ; preds = %arrlike.ic.spill_or_miss.85
  %r419 = add nuw nsw i64 %r206, 8
  %r420 = inttoptr i64 %r419 to ptr
  %r421 = load i64, ptr %r420, align 8
  %r422 = icmp ne i64 %r421, 0
  br i1 %r422, label %arrlike.ic.spill_ptr.64, label %arrlike.ic.miss.66

arrlike.ic.spill_ptr.64:                          ; preds = %arrlike.ic.spill.63
  %r423 = inttoptr i64 %r421 to ptr
  %r424 = getelementptr i64, ptr %r423, i64 4
  %r425 = load i64, ptr %r424, align 8
  %r426 = icmp ne i64 %r425, 0
  %r427 = select i1 %r426, i64 %r425, i64 %r421
  %r428 = inttoptr i64 %r427 to ptr
  %r429 = load i32, ptr %r428, align 4
  %r430 = zext i32 %r429 to i64
  %r431 = icmp ult i64 %r409, %r430
  %r432 = and i1 %r426, %r431
  br i1 %r432, label %arrlike.ic.spill_load.65, label %arrlike.ic.miss.66

arrlike.ic.spill_load.65:                         ; preds = %arrlike.ic.spill_ptr.64
  %r433 = add nuw nsw i64 %r409, 1
  %r434 = getelementptr inbounds nuw i64, ptr %r428, i64 %r433
  %r435 = load double, ptr %r434, align 8
  br label %tav.get.merge.30

arrlike.ic.miss.66:                               ; preds = %arrlike.ic.spill_or_miss.85, %json.scalar.cold.83, %json.scalar.memo.80, %json.scalar.materialized_guard.76, %json.scalar.cache_guard.75, %json.scalar.kind.73, %arrlike.elem.load.71, %arrlike.elem.bounds.70, %arrlike.ic.spill_ptr.64, %arrlike.ic.spill.63, %arrlike.ic.length_spill_ptr.59, %arrlike.ic.length_spill_meta.58, %arrlike.ic.family_token.55, %arrlike.ic.family_meta.54, %arrlike.ic.exact.53, %arrlike.ic.shape.51, %arrlike.ic.array_guard.49, %arrlike.ic.header.47, %tav.get.slow.29
  %r611.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r611.rs4o = call i64 asm "", "=r,0"(i64 %r611.rs4i) #9
  %r611 = bitcast i64 %r611.rs4o to double
  %statepoint_token6 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r611, double 7.000000e+00, ptr @perry_ic_short_loops_ts__3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %.144, ptr addrspace(1) %.1) ]
  %r4367 = call double @llvm.experimental.gc.result.f64(token %statepoint_token6)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token6, i32 0, i32 0) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s3.relocated8 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token6, i32 1, i32 1) ; (%.144, %.144)
  %rs4gc.s2.relocated9 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token6, i32 2, i32 2) ; (%.1, %.1)
  br label %tav.get.merge.30

arrlike.elem.kind.67:                             ; preds = %arrlike.ic.brand.48
  %r230 = icmp eq i8 %r222, 2
  br i1 %r230, label %arrlike.elem.meta.68, label %json.scalar.kind.73

arrlike.elem.meta.68:                             ; preds = %arrlike.elem.kind.67
  %r292 = add nuw nsw i64 %r206, 8
  %r293 = inttoptr i64 %r292 to ptr
  %r294 = load i64, ptr %r293, align 8
  %r295 = icmp ne i64 %r294, 0
  br i1 %r295, label %arrlike.elem.store.69, label %arrlike.ic.shape.51

arrlike.elem.store.69:                            ; preds = %arrlike.elem.meta.68
  %r296 = inttoptr i64 %r294 to ptr
  %r297 = getelementptr i64, ptr %r296, i64 12
  %r298 = load i64, ptr %r297, align 8
  %r299 = icmp ne i64 %r298, 0
  br i1 %r299, label %arrlike.elem.bounds.70, label %arrlike.ic.shape.51

arrlike.elem.bounds.70:                           ; preds = %arrlike.elem.store.69
  %r300 = sub i64 %r298, 8
  %r301 = inttoptr i64 %r300 to ptr
  %r302 = load i8, ptr %r301, align 1
  %r303 = icmp eq i8 %r302, 1
  %r304 = sub i64 %r298, 7
  %r305 = inttoptr i64 %r304 to ptr
  %r306 = load i8, ptr %r305, align 1
  %r307 = and i8 %r306, -128
  %r308 = icmp eq i8 %r307, 0
  %r309 = inttoptr i64 %r298 to ptr
  %r310 = load i32, ptr %r309, align 4
  %r311 = zext i32 %r310 to i64
  %r312 = icmp ult i64 7, %r311
  %r313 = and i1 %r303, %r308
  %r314 = and i1 %r313, %r312
  br i1 %r314, label %arrlike.elem.load.71, label %arrlike.ic.miss.66

arrlike.elem.load.71:                             ; preds = %arrlike.elem.bounds.70
  %r316 = add i64 %r298, 8
  %r317 = add i64 %r316, 56
  %r318 = inttoptr i64 %r317 to ptr
  %r319 = load double, ptr %r318, align 8
  %r320 = bitcast double %r319 to i64
  %r321 = icmp eq i64 %r320, 9222246136947933200
  br i1 %r321, label %arrlike.ic.miss.66, label %arrlike.elem.value.72

arrlike.elem.value.72:                            ; preds = %arrlike.elem.load.71
  br label %tav.get.merge.30

json.scalar.kind.73:                              ; preds = %arrlike.elem.kind.67
  %r231 = icmp eq i8 %r222, 9
  br i1 %r231, label %json.scalar.guard.74, label %arrlike.ic.miss.66

json.scalar.guard.74:                             ; preds = %json.scalar.kind.73
  %r232 = inttoptr i64 %r206 to ptr
  %r233 = getelementptr i8, ptr %r232, i64 4
  %r234 = load i32, ptr %r233, align 4
  %r235 = icmp eq i32 %r234, 1280989249
  %r236 = getelementptr i8, ptr %r232, i64 32
  %r237 = load ptr, ptr %r236, align 8
  %r238 = icmp eq ptr %r237, null
  %r239 = getelementptr i8, ptr %r232, i64 -6
  %r240 = load i16, ptr %r239, align 2
  %r241 = and i16 %r240, 3072
  %r242 = icmp eq i16 %r241, 0
  %r243 = and i1 %r235, %r242
  %r244 = icmp ne ptr %r237, null
  %r245 = and i1 %r243, %r244
  br i1 %r245, label %json.scalar.materialized_guard.76, label %json.scalar.cache_guard.75

json.scalar.cache_guard.75:                       ; preds = %json.scalar.guard.74
  %r256 = load i32, ptr %r232, align 4
  %r257 = zext i32 %r256 to i64
  %r258 = icmp ult i64 7, %r257
  %r259 = getelementptr i8, ptr %r232, i64 40
  %r260 = load ptr, ptr %r259, align 8
  %r261 = getelementptr i8, ptr %r232, i64 48
  %r262 = load ptr, ptr %r261, align 8
  %r263 = icmp ne ptr %r260, null
  %r264 = icmp ne ptr %r262, null
  %r265 = and i1 %r258, %r243
  %r266 = and i1 %r265, %r238
  %r267 = and i1 %r266, %r263
  %r268 = and i1 %r267, %r264
  br i1 %r268, label %json.scalar.bitmap.78, label %arrlike.ic.miss.66

json.scalar.materialized_guard.76:                ; preds = %json.scalar.guard.74
  %r246 = ptrtoint ptr %r237 to i64
  %r247 = getelementptr i8, ptr %r237, i64 -8
  %r248 = load i8, ptr %r247, align 1
  %r249 = icmp eq i8 %r248, 1
  %r250 = getelementptr i8, ptr %r237, i64 -7
  %r251 = load i8, ptr %r250, align 1
  %r252 = and i8 %r251, -128
  %r253 = icmp eq i8 %r252, 0
  %r254 = and i1 %r249, %r253
  br i1 %r254, label %json.scalar.materialized_ready.77, label %arrlike.ic.miss.66

json.scalar.materialized_ready.77:                ; preds = %json.scalar.materialized_guard.76
  %r255 = load i32, ptr %r237, align 4
  store i32 %r255, ptr %r232, align 4
  br label %arrlike.ic.array_guard.49

json.scalar.bitmap.78:                            ; preds = %json.scalar.cache_guard.75
  %r270 = getelementptr i64, ptr %r262, i64 0
  %r271 = load i64, ptr %r270, align 8
  %r274 = and i64 %r271, 128
  %r276 = getelementptr i64, ptr %r260, i64 7
  %r275 = icmp ne i64 %r274, 0
  br i1 %r275, label %json.scalar.exposed.79, label %json.scalar.memo.80

json.scalar.exposed.79:                           ; preds = %json.scalar.bitmap.78
  %r277 = load double, ptr %r276, align 8
  br label %tav.get.merge.30

json.scalar.memo.80:                              ; preds = %json.scalar.bitmap.78
  %r278 = getelementptr i8, ptr %r232, i64 80
  %r279 = load i64, ptr %r278, align 8
  %r280 = icmp eq i64 %r279, 6580483
  %r281 = icmp eq i64 %r279, 0
  %r282 = or i1 %r280, %r281
  br i1 %r282, label %json.scalar.memo_slot.81, label %arrlike.ic.miss.66

json.scalar.memo_slot.81:                         ; preds = %json.scalar.memo.80
  %r283 = load i64, ptr %r276, align 8
  %r284 = icmp ne i64 %r283, 0
  %r285 = and i1 %r280, %r284
  br i1 %r285, label %json.scalar.memo_hit.82, label %json.scalar.cold.83

json.scalar.memo_hit.82:                          ; preds = %json.scalar.memo_slot.81
  %r286 = icmp eq i64 %r283, 9222809086901354496
  %r287 = select i1 %r286, i64 0, i64 %r283
  %r288 = bitcast i64 %r287 to double
  br label %json.scalar.merge.84

json.scalar.cold.83:                              ; preds = %json.scalar.memo_slot.81
  %r289 = call double @js_json_lazy_index_scalar(double %r108, double 7.000000e+00, ptr @short_loops_ts_.str.0.bytes, i64 2) #9
  %r290 = bitcast double %r289 to i64
  %r291 = icmp eq i64 %r290, 9222246136947933200
  br i1 %r291, label %arrlike.ic.miss.66, label %json.scalar.merge.84

json.scalar.merge.84:                             ; preds = %pget.recv_merge.90, %json.scalar.cold.83, %json.scalar.memo_hit.82
  %.158 = phi ptr addrspace(1) [ %.259, %pget.recv_merge.90 ], [ %rs4gc.s6, %json.scalar.memo_hit.82 ], [ %rs4gc.s6, %json.scalar.cold.83 ]
  %.548 = phi ptr addrspace(1) [ %.649, %pget.recv_merge.90 ], [ %.144, %json.scalar.memo_hit.82 ], [ %.144, %json.scalar.cold.83 ]
  %.5 = phi ptr addrspace(1) [ %.6, %pget.recv_merge.90 ], [ %.1, %json.scalar.memo_hit.82 ], [ %.1, %json.scalar.cold.83 ]
  %r585 = phi double [ %r288, %json.scalar.memo_hit.82 ], [ %r289, %json.scalar.cold.83 ], [ %r584, %pget.recv_merge.90 ]
  %r586.rs4i = ptrtoint ptr addrspace(1) %.158 to i64
  %r586 = call i64 asm "", "=r,0"(i64 %r586.rs4i) #9
  %r587 = bitcast i64 %r586 to double
  %r588 = and i64 %r586, -281474976710656
  %r589 = icmp ult i64 %r588, 9221401712017801216
  %r590 = icmp ugt i64 %r588, 9223090561878065152
  %r591 = or i1 %r589, %r590
  %r592 = bitcast double %r585 to i64
  %r593 = and i64 %r592, -281474976710656
  %r594 = icmp ult i64 %r593, 9221401712017801216
  %r595 = icmp ugt i64 %r593, 9223090561878065152
  %r596 = or i1 %r594, %r595
  %r597 = and i1 %r591, %r596
  br i1 %r597, label %guarded_add.numeric.117, label %guarded_add.dynamic.118

arrlike.ic.spill_or_miss.85:                      ; preds = %arrlike.ic.range.61
  br i1 %r413, label %arrlike.ic.spill.63, label %arrlike.ic.miss.66

pget.recv_sso.86:                                 ; preds = %pget.recv_other.91
  %r580 = load double, ptr @short_loops_ts_.str.0.handle, align 8
  %r581 = bitcast double %r580 to i64
  %r582 = and i64 %r581, 281474976710655
  %statepoint_token10 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r438, i64 %r582, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.447, ptr addrspace(1) %.4, ptr addrspace(1) %.057) ]
  %r58311 = call double @llvm.experimental.gc.result.f64(token %statepoint_token10)
  %rs4gc.s3.relocated12 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token10, i32 0, i32 0) ; (%.447, %.447)
  %rs4gc.s2.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token10, i32 1, i32 1) ; (%.4, %.4)
  %rs4gc.s6.relocated14 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token10, i32 2, i32 2) ; (%.057, %.057)
  br label %pget.recv_merge.90

pget.recv_ok.87:                                  ; preds = %tav.get.merge.30
  %r449 = icmp ugt i64 %r439, 1048575
  br i1 %r449, label %pic.recv_hdr.108, label %pic.miss.cold.105

pget.recv_bad.88:                                 ; preds = %pget.check_class_ref.92
  %r572 = icmp eq i64 %r438, 9222246136947933185
  %r573 = icmp eq i64 %r438, 9222246136947933186
  %r574 = or i1 %r572, %r573
  br i1 %r574, label %pget.throw_nullish.115, label %pget.recv_undef_return.116

pget.recv_class_ref.89:                           ; preds = %pget.check_class_ref.92
  %r445 = load double, ptr @short_loops_ts_.str.0.handle, align 8
  %r446 = bitcast double %r445 to i64
  %r447 = and i64 %r446, 281474976710655
  %statepoint_token15 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 2301219111847329796, i64 %r438, i64 %r447, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.447, ptr addrspace(1) %.4, ptr addrspace(1) %.057) ]
  %r44816 = call double @llvm.experimental.gc.result.f64(token %statepoint_token15)
  %rs4gc.s3.relocated17 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token15, i32 0, i32 0) ; (%.447, %.447)
  %rs4gc.s2.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token15, i32 1, i32 1) ; (%.4, %.4)
  %rs4gc.s6.relocated19 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token15, i32 2, i32 2) ; (%.057, %.057)
  br label %pget.recv_merge.90

pget.recv_merge.90:                               ; preds = %pget.recv_undef_return.116, %pic.merge.107, %pget.recv_class_ref.89, %pget.recv_sso.86
  %.259 = phi ptr addrspace(1) [ %.360, %pic.merge.107 ], [ %rs4gc.s6.relocated14, %pget.recv_sso.86 ], [ %rs4gc.s6.relocated19, %pget.recv_class_ref.89 ], [ %rs4gc.s6.relocated35, %pget.recv_undef_return.116 ]
  %.649 = phi ptr addrspace(1) [ %.750, %pic.merge.107 ], [ %rs4gc.s3.relocated12, %pget.recv_sso.86 ], [ %rs4gc.s3.relocated17, %pget.recv_class_ref.89 ], [ %rs4gc.s3.relocated33, %pget.recv_undef_return.116 ]
  %.6 = phi ptr addrspace(1) [ %.7, %pic.merge.107 ], [ %rs4gc.s2.relocated13, %pget.recv_sso.86 ], [ %rs4gc.s2.relocated18, %pget.recv_class_ref.89 ], [ %rs4gc.s2.relocated34, %pget.recv_undef_return.116 ]
  %r584 = phi double [ %r571, %pic.merge.107 ], [ %r57932, %pget.recv_undef_return.116 ], [ %r58311, %pget.recv_sso.86 ], [ %r44816, %pget.recv_class_ref.89 ]
  br label %json.scalar.merge.84

pget.recv_other.91:                               ; preds = %tav.get.merge.30
  %r443 = icmp eq i64 %r440, 32761
  br i1 %r443, label %pget.recv_sso.86, label %pget.check_class_ref.92

pget.check_class_ref.92:                          ; preds = %pget.recv_other.91
  %r444 = icmp eq i64 %r440, 32766
  br i1 %r444, label %pget.recv_class_ref.89, label %pget.recv_bad.88

pic.hit.93:                                       ; preds = %pic.token.109
  %r474 = getelementptr i64, ptr %r459, i64 1
  %r475 = load i64, ptr %r474, align 8
  %r476 = and i64 %r475, 1073741824
  %r477 = icmp ne i64 %r476, 0
  br i1 %r477, label %pic.hit.overflow.110, label %pic.hit.inline.111

pic.hit.live.94:                                  ; preds = %pic.hit.inline.111
  br label %pic.merge.107

pic.prefix.guard.95:                              ; preds = %pic.token.109
  %r490 = getelementptr i64, ptr %r459, i64 2
  %r491 = load i64, ptr %r490, align 8
  %r492 = icmp ne i64 %r491, 0
  br i1 %r492, label %pic.prefix.meta.96, label %pic.miss.104

pic.prefix.meta.96:                               ; preds = %pic.prefix.guard.95
  %r493 = add nuw nsw i64 %r439, 8
  %r494 = inttoptr i64 %r493 to ptr
  %r495 = load i64, ptr %r494, align 8
  %r496 = icmp ne i64 %r495, 0
  br i1 %r496, label %pic.prefix.token.97, label %pic.miss.104

pic.prefix.token.97:                              ; preds = %pic.prefix.meta.96
  %r497 = inttoptr i64 %r495 to ptr
  %r498 = getelementptr i64, ptr %r497, i64 6
  %r499 = load i64, ptr %r498, align 8
  %r500 = icmp eq i64 %r499, %r491
  br i1 %r500, label %pic.prefix.hit.98, label %pic.miss.104

pic.prefix.hit.98:                                ; preds = %pic.prefix.token.97
  %r501 = getelementptr i64, ptr %r459, i64 1
  %r502 = load i64, ptr %r501, align 8
  %r503 = shl i64 %r502, 3
  %r504 = add nuw nsw i64 %r439, 16
  %r505 = add i64 %r504, %r503
  %r506 = inttoptr i64 %r505 to ptr
  %r507 = load double, ptr %r506, align 8
  br label %pic.merge.107

pic.desc.classify.99:                             ; preds = %pic.recv_hdr.108
  %r463 = and i1 %r453, %r460
  br i1 %r463, label %pic.desc.prefix.guard.100, label %pic.miss.cold.105

pic.desc.prefix.guard.100:                        ; preds = %pic.desc.classify.99
  %r508 = getelementptr i64, ptr %r459, i64 2
  %r509 = load i64, ptr %r508, align 8
  %r510 = icmp ne i64 %r509, 0
  br i1 %r510, label %pic.desc.prefix.meta.101, label %pic.miss.cold.105

pic.desc.prefix.meta.101:                         ; preds = %pic.desc.prefix.guard.100
  %r511 = add nuw nsw i64 %r439, 8
  %r512 = inttoptr i64 %r511 to ptr
  %r513 = load i64, ptr %r512, align 8
  %r514 = icmp ne i64 %r513, 0
  br i1 %r514, label %pic.desc.prefix.token.102, label %pic.miss.cold.105

pic.desc.prefix.token.102:                        ; preds = %pic.desc.prefix.meta.101
  %r515 = inttoptr i64 %r513 to ptr
  %r516 = getelementptr i64, ptr %r515, i64 6
  %r517 = load i64, ptr %r516, align 8
  %r518 = icmp eq i64 %r517, %r509
  br i1 %r518, label %pic.desc.prefix.hit.103, label %pic.miss.cold.105

pic.desc.prefix.hit.103:                          ; preds = %pic.desc.prefix.token.102
  %r519 = getelementptr i64, ptr %r459, i64 1
  %r520 = load i64, ptr %r519, align 8
  %r521 = shl i64 %r520, 3
  %r522 = add nuw nsw i64 %r439, 16
  %r523 = add i64 %r522, %r521
  %r524 = inttoptr i64 %r523 to ptr
  %r525 = load double, ptr %r524, align 8
  br label %pic.merge.107

pic.miss.104:                                     ; preds = %pic.hit.inline.111, %pic.prefix.token.97, %pic.prefix.meta.96, %pic.prefix.guard.95
  %r526 = getelementptr i64, ptr %r459, i64 3
  %r527 = load i64, ptr %r526, align 8
  %r528 = icmp sgt i64 %r527, 0
  br i1 %r528, label %pic.ways.112, label %pic.miss.call.106

pic.miss.cold.105:                                ; preds = %pic.desc.prefix.token.102, %pic.desc.prefix.meta.101, %pic.desc.prefix.guard.100, %pic.desc.classify.99, %pget.recv_ok.87
  br label %pic.miss.call.106

pic.miss.call.106:                                ; preds = %pic.way.load.113, %pic.ways.112, %pic.miss.cold.105, %pic.miss.104
  %r567 = load double, ptr @short_loops_ts_.str.0.handle, align 8
  %r568 = bitcast double %r567 to i64
  %r569 = and i64 %r568, 281474976710655
  %statepoint_token20 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r439, i64 %r569, ptr @perry_ic_short_loops_ts__5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.447, ptr addrspace(1) %.4, ptr addrspace(1) %.057) ]
  %r57021 = call double @llvm.experimental.gc.result.f64(token %statepoint_token20)
  %rs4gc.s3.relocated22 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 0, i32 0) ; (%.447, %.447)
  %rs4gc.s2.relocated23 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 1, i32 1) ; (%.4, %.4)
  %rs4gc.s6.relocated24 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 2, i32 2) ; (%.057, %.057)
  br label %pic.merge.107

pic.merge.107:                                    ; preds = %pic.way.live.114, %pic.hit.overflow.110, %pic.miss.call.106, %pic.desc.prefix.hit.103, %pic.prefix.hit.98, %pic.hit.live.94
  %.360 = phi ptr addrspace(1) [ %rs4gc.s6.relocated29, %pic.hit.overflow.110 ], [ %rs4gc.s6.relocated24, %pic.miss.call.106 ], [ %.057, %pic.way.live.114 ], [ %.057, %pic.hit.live.94 ], [ %.057, %pic.prefix.hit.98 ], [ %.057, %pic.desc.prefix.hit.103 ]
  %.750 = phi ptr addrspace(1) [ %rs4gc.s3.relocated27, %pic.hit.overflow.110 ], [ %rs4gc.s3.relocated22, %pic.miss.call.106 ], [ %.447, %pic.way.live.114 ], [ %.447, %pic.hit.live.94 ], [ %.447, %pic.prefix.hit.98 ], [ %.447, %pic.desc.prefix.hit.103 ]
  %.7 = phi ptr addrspace(1) [ %rs4gc.s2.relocated28, %pic.hit.overflow.110 ], [ %rs4gc.s2.relocated23, %pic.miss.call.106 ], [ %.4, %pic.way.live.114 ], [ %.4, %pic.hit.live.94 ], [ %.4, %pic.prefix.hit.98 ], [ %.4, %pic.desc.prefix.hit.103 ]
  %r571 = phi double [ %r487, %pic.hit.live.94 ], [ %r48226, %pic.hit.overflow.110 ], [ %r507, %pic.prefix.hit.98 ], [ %r525, %pic.desc.prefix.hit.103 ], [ %r564, %pic.way.live.114 ], [ %r57021, %pic.miss.call.106 ]
  br label %pget.recv_merge.90

pic.recv_hdr.108:                                 ; preds = %pget.recv_ok.87
  %r450 = sub nuw nsw i64 %r439, 8
  %r451 = inttoptr i64 %r450 to ptr
  %r452 = load i8, ptr %r451, align 1
  %r453 = icmp eq i8 %r452, 2
  %r454 = sub nuw nsw i64 %r439, 6
  %r455 = inttoptr i64 %r454 to ptr
  %r456 = load i16, ptr %r455, align 2
  %r457 = and i16 %r456, 2048
  %r458 = icmp eq i16 %r457, 0
  %r459 = load ptr, ptr @perry_ic_short_loops_ts__5, align 8
  %r460 = icmp ne ptr %r459, null
  %r461 = and i1 %r453, %r458
  %r462 = and i1 %r461, %r460
  br i1 %r462, label %pic.token.109, label %pic.desc.classify.99

pic.token.109:                                    ; preds = %pic.recv_hdr.108
  %r464 = add nuw nsw i64 %r439, 4
  %r465 = inttoptr i64 %r464 to ptr
  %r466 = load i32, ptr %r465, align 4
  %r467 = zext i32 %r466 to i64
  %r468 = or i64 %r467, 4611686018427387904
  %r469 = icmp ne i32 %r466, 0
  %r470 = getelementptr i64, ptr %r459, i64 0
  %r471 = load i64, ptr %r470, align 8
  %r472 = icmp eq i64 %r468, %r471
  %r473 = and i1 %r472, %r469
  br i1 %r473, label %pic.hit.93, label %pic.prefix.guard.95

pic.hit.overflow.110:                             ; preds = %pic.hit.93
  %r478 = load double, ptr @short_loops_ts_.str.0.handle, align 8
  %r479 = bitcast double %r478 to i64
  %r480 = and i64 %r479, 281474976710655
  %r481 = trunc i64 %r475 to i32
  %statepoint_token25 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r439, i64 %r480, i32 %r481, ptr @perry_ic_short_loops_ts__5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.447, ptr addrspace(1) %.4, ptr addrspace(1) %.057) ]
  %r48226 = call double @llvm.experimental.gc.result.f64(token %statepoint_token25)
  %rs4gc.s3.relocated27 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token25, i32 0, i32 0) ; (%.447, %.447)
  %rs4gc.s2.relocated28 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token25, i32 1, i32 1) ; (%.4, %.4)
  %rs4gc.s6.relocated29 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token25, i32 2, i32 2) ; (%.057, %.057)
  br label %pic.merge.107

pic.hit.inline.111:                               ; preds = %pic.hit.93
  %r483 = shl i64 %r475, 3
  %r484 = add nuw nsw i64 %r439, 16
  %r485 = add i64 %r484, %r483
  %r486 = inttoptr i64 %r485 to ptr
  %r487 = load double, ptr %r486, align 8
  %r488 = bitcast double %r487 to i64
  %r489 = icmp eq i64 %r488, 9222246136947933200
  br i1 %r489, label %pic.miss.104, label %pic.hit.live.94

pic.ways.112:                                     ; preds = %pic.miss.104
  %r529 = getelementptr i64, ptr %r459, i64 4
  %r530 = load i64, ptr %r529, align 8
  %r531 = icmp eq i64 %r530, %r468
  %r532 = getelementptr i64, ptr %r459, i64 5
  %r533 = load i64, ptr %r532, align 8
  %r534 = select i1 %r531, i64 %r533, i64 0
  %r535 = getelementptr i64, ptr %r459, i64 6
  %r536 = load i64, ptr %r535, align 8
  %r537 = icmp eq i64 %r536, %r468
  %r538 = getelementptr i64, ptr %r459, i64 7
  %r539 = load i64, ptr %r538, align 8
  %r540 = select i1 %r537, i64 %r539, i64 0
  %r541 = getelementptr i64, ptr %r459, i64 8
  %r542 = load i64, ptr %r541, align 8
  %r543 = icmp eq i64 %r542, %r468
  %r544 = getelementptr i64, ptr %r459, i64 9
  %r545 = load i64, ptr %r544, align 8
  %r546 = select i1 %r543, i64 %r545, i64 0
  %r547 = getelementptr i64, ptr %r459, i64 10
  %r548 = load i64, ptr %r547, align 8
  %r549 = icmp eq i64 %r548, %r468
  %r550 = getelementptr i64, ptr %r459, i64 11
  %r551 = load i64, ptr %r550, align 8
  %r552 = select i1 %r549, i64 %r551, i64 0
  %r553 = or i1 %r531, %r537
  %r554 = select i1 %r531, i64 %r534, i64 %r540
  %r555 = or i1 %r543, %r549
  %r556 = select i1 %r543, i64 %r546, i64 %r552
  %r557 = or i1 %r553, %r555
  %r558 = select i1 %r553, i64 %r554, i64 %r556
  %r559 = and i1 %r469, %r557
  br i1 %r559, label %pic.way.load.113, label %pic.miss.call.106

pic.way.load.113:                                 ; preds = %pic.ways.112
  %r560 = shl i64 %r558, 3
  %r561 = add nuw nsw i64 %r439, 16
  %r562 = add i64 %r561, %r560
  %r563 = inttoptr i64 %r562 to ptr
  %r564 = load double, ptr %r563, align 8
  %r565 = bitcast double %r564 to i64
  %r566 = icmp eq i64 %r565, 9222246136947933200
  br i1 %r566, label %pic.miss.call.106, label %pic.way.live.114

pic.way.live.114:                                 ; preds = %pic.way.load.113
  br label %pic.merge.107

pget.throw_nullish.115:                           ; preds = %pget.recv_bad.88
  %r575 = zext i1 %r573 to i32
  %statepoint_token30 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r575, ptr @short_loops_ts_.str.0.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.116:                       ; preds = %pget.recv_bad.88
  %r576 = load double, ptr @short_loops_ts_.str.0.handle, align 8
  %r577 = bitcast double %r576 to i64
  %r578 = and i64 %r577, 281474976710655
  %statepoint_token31 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r438, i64 %r578, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.447, ptr addrspace(1) %.4, ptr addrspace(1) %.057) ]
  %r57932 = call double @llvm.experimental.gc.result.f64(token %statepoint_token31)
  %rs4gc.s3.relocated33 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token31, i32 0, i32 0) ; (%.447, %.447)
  %rs4gc.s2.relocated34 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token31, i32 1, i32 1) ; (%.4, %.4)
  %rs4gc.s6.relocated35 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token31, i32 2, i32 2) ; (%.057, %.057)
  br label %pget.recv_merge.90

guarded_add.numeric.117:                          ; preds = %json.scalar.merge.84
  %r598 = fadd double %r587, %r585
  br label %guarded_add.merge.119

guarded_add.dynamic.118:                          ; preds = %json.scalar.merge.84
  %statepoint_token36 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r587, double %r585, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.548, ptr addrspace(1) %.5) ]
  %r59937 = call double @llvm.experimental.gc.result.f64(token %statepoint_token36)
  %rs4gc.s3.relocated38 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token36, i32 0, i32 0) ; (%.548, %.548)
  %rs4gc.s2.relocated39 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token36, i32 1, i32 1) ; (%.5, %.5)
  br label %guarded_add.merge.119

guarded_add.merge.119:                            ; preds = %guarded_add.dynamic.118, %guarded_add.numeric.117
  %.851 = phi ptr addrspace(1) [ %.548, %guarded_add.numeric.117 ], [ %rs4gc.s3.relocated38, %guarded_add.dynamic.118 ]
  %.8 = phi ptr addrspace(1) [ %.5, %guarded_add.numeric.117 ], [ %rs4gc.s2.relocated39, %guarded_add.dynamic.118 ]
  %r600 = phi double [ %r598, %guarded_add.numeric.117 ], [ %r59937, %guarded_add.dynamic.118 ]
  %rs4gc.b7 = bitcast double %r600 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r601.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r601 = call i64 asm "", "=r,0"(i64 %r601.rs4i) #9
  %r602 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r603 = icmp ne i32 %r602, 0
  br i1 %r603, label %shadow.root.barrier.120, label %shadow.root.barrier.done.121

shadow.root.barrier.120:                          ; preds = %guarded_add.merge.119
  call void @js_write_barrier_root_nanbox(i64 %r601) #9
  br label %shadow.root.barrier.done.121

shadow.root.barrier.done.121:                     ; preds = %shadow.root.barrier.120, %guarded_add.merge.119
  %r604 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r605 = icmp ne i32 %r604, 0
  br i1 %r605, label %gcpoll.122, label %gcpoll.done.123

gcpoll.122:                                       ; preds = %shadow.root.barrier.done.121
  %statepoint_token40 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7, ptr addrspace(1) %.8, ptr addrspace(1) %.851) ]
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 0, i32 0) ; (%rs4gc.s7, %rs4gc.s7)
  %rs4gc.s2.relocated41 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 1, i32 1) ; (%.8, %.8)
  %rs4gc.s3.relocated42 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 2, i32 2) ; (%.851, %.851)
  br label %gcpoll.done.123

gcpoll.done.123:                                  ; preds = %gcpoll.122, %shadow.root.barrier.done.121
  %.061 = phi ptr addrspace(1) [ %rs4gc.s7.relocated, %gcpoll.122 ], [ %rs4gc.s7, %shadow.root.barrier.done.121 ]
  %.952 = phi ptr addrspace(1) [ %rs4gc.s3.relocated42, %gcpoll.122 ], [ %.851, %shadow.root.barrier.done.121 ]
  %.9 = phi ptr addrspace(1) [ %rs4gc.s2.relocated41, %gcpoll.122 ], [ %.8, %shadow.root.barrier.done.121 ]
  br label %for.invariant_field_slow.update.16
}

; Function Attrs: noinline optsize
define double @perry_fn_short_loops_ts__sum(double %arg11, double %arg12) #7 {
entry.0:
  %r1 = bitcast double %arg12 to i64
  %r2 = lshr i64 %r1, 48
  %r3 = icmp ult i64 %r2, 32761
  %r4 = icmp ugt i64 %r2, 32767
  %r5 = or i1 %r3, %r4
  %r6 = and i64 %r1, -4294967296
  %r7 = icmp eq i64 %r6, 9222809086901354496
  %r8 = or i1 %r5, %r7
  br i1 %r8, label %spec_public.fast.1, label %spec_public.fallback.2

spec_public.fast.1:                               ; preds = %entry.0
  %r9 = call double @"perry_fn_short_loops_ts__sum$spec_b_b"(double %arg11, double %arg12)
  ret double %r9

spec_public.fallback.2:                           ; preds = %entry.0
  %r10 = call double @"perry_fn_short_loops_ts__sum$generic"(double %arg11, double %arg12)
  ret double %r10
}

; Function Attrs: inlinehint optsize
define internal double @"perry_fn_short_loops_ts__run$generic"(double %arg15, double %arg16, double %arg17) #8 gc "statepoint-example" {
entry.0:
  %rs4gc.b2 = bitcast double %arg15 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg16 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %rs4gc.b4 = bitcast double %arg17 to i64
  %rs4gc.s4 = inttoptr i64 %rs4gc.b4 to ptr addrspace(1)
  %r9.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r9.rs4o = call i64 asm "", "=r,0"(i64 %r9.rs4i) #9
  %r9 = bitcast i64 %r9.rs4o to double
  %r10 = bitcast double %r9 to i64
  %r11 = and i64 %r10, -281474976710656
  %r12 = icmp ult i64 %r11, 9221401712017801216
  %r13 = icmp ugt i64 %r11, 9223090561878065152
  %r14 = or i1 %r12, %r13
  br i1 %r14, label %for.bound_i32.number.1, label %for.bound_i32.merge.3

for.bound_i32.number.1:                           ; preds = %entry.0
  %r15 = fcmp oge double %r9, 0xC1E0000000000000
  %r16 = fcmp ole double %r9, 0x41DFFFFFFFC00000
  %r17 = and i1 %r15, %r16
  br i1 %r17, label %for.bound_i32.convert.2, label %for.bound_i32.merge.3

for.bound_i32.convert.2:                          ; preds = %for.bound_i32.number.1
  %r18 = fptosi double %r9 to i32
  %r19 = sitofp i32 %r18 to double
  %r20 = fcmp oeq double %r19, %r9
  br i1 %r20, label %for.counter_i32.range.4, label %for.bound_i32.merge.3

for.bound_i32.merge.3:                            ; preds = %for.counter_i32.convert.5, %for.bound_i32.convert.2, %for.bound_i32.number.1, %entry.0
  %r8.0 = phi i32 [ %r18, %for.counter_i32.convert.5 ], [ 0, %entry.0 ], [ %r18, %for.bound_i32.convert.2 ], [ 0, %for.bound_i32.number.1 ]
  %r7.0 = phi i1 [ true, %for.counter_i32.convert.5 ], [ false, %entry.0 ], [ false, %for.bound_i32.convert.2 ], [ false, %for.bound_i32.number.1 ]
  br label %for.cond.6

for.counter_i32.range.4:                          ; preds = %for.bound_i32.convert.2
  br label %for.counter_i32.convert.5

for.counter_i32.convert.5:                        ; preds = %for.counter_i32.range.4
  br label %for.bound_i32.merge.3

for.cond.6:                                       ; preds = %for.update.8, %for.bound_i32.merge.3
  %.027 = phi ptr addrspace(1) [ %rs4gc.s3, %for.bound_i32.merge.3 ], [ %.532, %for.update.8 ]
  %.021 = phi ptr addrspace(1) [ %rs4gc.s2, %for.bound_i32.merge.3 ], [ %.526, %for.update.8 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s4, %for.bound_i32.merge.3 ], [ %.5, %for.update.8 ]
  %r6.1 = phi i32 [ 0, %for.bound_i32.merge.3 ], [ %r101, %for.update.8 ]
  %r5.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.3 ], [ %r99, %for.update.8 ]
  %r4.0 = phi ptr addrspace(1) [ null, %for.bound_i32.merge.3 ], [ %.037, %for.update.8 ]
  br i1 %r7.0, label %for.cond.fast.10, label %for.cond.slow.11

for.body.7:                                       ; preds = %gcpoll.done.16, %for.cond.fast.10
  %.033 = phi ptr addrspace(1) [ %r4.0, %for.cond.fast.10 ], [ %.336, %gcpoll.done.16 ]
  %.128 = phi ptr addrspace(1) [ %.027, %for.cond.fast.10 ], [ %.330, %gcpoll.done.16 ]
  %.122 = phi ptr addrspace(1) [ %.021, %for.cond.fast.10 ], [ %.324, %gcpoll.done.16 ]
  %.1 = phi ptr addrspace(1) [ %.0, %for.cond.fast.10 ], [ %.3, %gcpoll.done.16 ]
  %r69.rs4i = ptrtoint ptr addrspace(1) %.033 to i64
  %r69.rs4o = call i64 asm "", "=r,0"(i64 %r69.rs4i) #9
  %r69 = bitcast i64 %r69.rs4o to double
  %r70 = bitcast double %r69 to i64
  %rs4gc.s6 = inttoptr i64 %r70 to ptr addrspace(1)
  %r72.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r72 = call i64 asm "", "=r,0"(i64 %r72.rs4i) #9
  %r73 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r74 = icmp ne i32 %r73, 0
  br i1 %r74, label %shadow.root.barrier.17, label %shadow.root.barrier.done.18

for.update.8:                                     ; preds = %gcpoll.done.25
  %r99 = fadd double %r5.0, 1.000000e+00
  %r101 = add i32 %r6.1, 1
  br label %for.cond.6

for.exit.9:                                       ; preds = %gcpoll.done.16, %for.cond.fast.10
  %.134 = phi ptr addrspace(1) [ %r4.0, %for.cond.fast.10 ], [ %.336, %gcpoll.done.16 ]
  %r102.rs4i = ptrtoint ptr addrspace(1) %.134 to i64
  %r102.rs4o = call i64 asm "", "=r,0"(i64 %r102.rs4i) #9
  %r102 = bitcast i64 %r102.rs4o to double
  ret double %r102

for.cond.fast.10:                                 ; preds = %for.cond.6
  %r31 = icmp slt i32 %r6.1, %r8.0
  br i1 %r31, label %for.body.7, label %for.exit.9

for.cond.slow.11:                                 ; preds = %for.cond.6
  %r33.rs4i = ptrtoint ptr addrspace(1) %.027 to i64
  %r33.rs4o = call i64 asm "", "=r,0"(i64 %r33.rs4i) #9
  %r33 = bitcast i64 %r33.rs4o to double
  %r34 = bitcast double %r33 to i64
  %r35 = lshr i64 %r34, 48
  %r36 = icmp ult i64 %r35, 32761
  %r37 = icmp ugt i64 %r35, 32767
  %r38 = or i1 %r36, %r37
  %r39 = icmp eq i64 %r35, 32766
  %r40 = icmp eq i64 %r34, 9222246136947933185
  %r41 = icmp eq i64 %r34, 9222246136947933186
  %r42 = icmp eq i64 %r34, 9222246136947933187
  %r43 = icmp eq i64 %r34, 9222246136947933188
  %r44 = or i1 %r41, %r42
  %r45 = or i1 %r38, %r39
  %r46 = or i1 %r45, %r40
  %r47 = or i1 %r46, %r44
  %r48 = or i1 %r47, %r43
  br i1 %r48, label %relnum.fast.12, label %relnum.slow.13

relnum.fast.12:                                   ; preds = %for.cond.slow.11
  %r49 = trunc i64 %r34 to i32
  %r50 = sitofp i32 %r49 to double
  %r51 = select i1 %r39, double %r50, double %r33
  %r52 = select i1 %r44, double 0.000000e+00, double %r51
  %r53 = select i1 %r43, double 1.000000e+00, double %r52
  %r54 = bitcast double %r5.0 to i64
  %r55 = lshr i64 %r54, 48
  %r56 = icmp eq i64 %r55, 32766
  %r57 = trunc i64 %r54 to i32
  %r58 = sitofp i32 %r57 to double
  %r59 = select i1 %r56, double %r58, double %r5.0
  %r60 = fcmp olt double %r59, %r53
  %r61 = select i1 %r60, i64 9222246136947933188, i64 9222246136947933187
  %r62 = bitcast i64 %r61 to double
  br label %relnum.merge.14

relnum.slow.13:                                   ; preds = %for.cond.slow.11
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r5.0, double %r33, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0, ptr addrspace(1) %.021, ptr addrspace(1) %.027, ptr addrspace(1) %r4.0) ]
  %r631 = call double @llvm.experimental.gc.result.f64(token %statepoint_token)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%.0, %.0)
  %rs4gc.s2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%.021, %.021)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 2, i32 2) ; (%.027, %.027)
  %r4.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 3, i32 3) ; (%r4.0, %r4.0)
  br label %relnum.merge.14

relnum.merge.14:                                  ; preds = %relnum.slow.13, %relnum.fast.12
  %.235 = phi ptr addrspace(1) [ %r4.0, %relnum.fast.12 ], [ %r4.0.relocated, %relnum.slow.13 ]
  %.229 = phi ptr addrspace(1) [ %.027, %relnum.fast.12 ], [ %rs4gc.s3.relocated, %relnum.slow.13 ]
  %.223 = phi ptr addrspace(1) [ %.021, %relnum.fast.12 ], [ %rs4gc.s2.relocated, %relnum.slow.13 ]
  %.2 = phi ptr addrspace(1) [ %.0, %relnum.fast.12 ], [ %rs4gc.s4.relocated, %relnum.slow.13 ]
  %r64 = phi double [ %r62, %relnum.fast.12 ], [ %r631, %relnum.slow.13 ]
  %r65 = bitcast double %r64 to i64
  %r67 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r68 = icmp ne i32 %r67, 0
  br i1 %r68, label %gcpoll.15, label %gcpoll.done.16

gcpoll.15:                                        ; preds = %relnum.merge.14
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.229, ptr addrspace(1) %.2, ptr addrspace(1) %.223, ptr addrspace(1) %.235) ]
  %rs4gc.s3.relocated3 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token2, i32 0, i32 0) ; (%.229, %.229)
  %rs4gc.s4.relocated4 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token2, i32 1, i32 1) ; (%.2, %.2)
  %rs4gc.s2.relocated5 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token2, i32 2, i32 2) ; (%.223, %.223)
  %r4.0.relocated6 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token2, i32 3, i32 3) ; (%.235, %.235)
  br label %gcpoll.done.16

gcpoll.done.16:                                   ; preds = %gcpoll.15, %relnum.merge.14
  %.336 = phi ptr addrspace(1) [ %r4.0.relocated6, %gcpoll.15 ], [ %.235, %relnum.merge.14 ]
  %.330 = phi ptr addrspace(1) [ %rs4gc.s3.relocated3, %gcpoll.15 ], [ %.229, %relnum.merge.14 ]
  %.324 = phi ptr addrspace(1) [ %rs4gc.s2.relocated5, %gcpoll.15 ], [ %.223, %relnum.merge.14 ]
  %.3 = phi ptr addrspace(1) [ %rs4gc.s4.relocated4, %gcpoll.15 ], [ %.2, %relnum.merge.14 ]
  %r66 = icmp eq i64 %r65, 9222246136947933188
  br i1 %r66, label %for.body.7, label %for.exit.9

shadow.root.barrier.17:                           ; preds = %for.body.7
  call void @js_write_barrier_root_nanbox(i64 %r72) #9
  br label %shadow.root.barrier.done.18

shadow.root.barrier.done.18:                      ; preds = %shadow.root.barrier.17, %for.body.7
  %r75.rs4i = ptrtoint ptr addrspace(1) %.122 to i64
  %r75.rs4o = call i64 asm "", "=r,0"(i64 %r75.rs4i) #9
  %r75 = bitcast i64 %r75.rs4o to double
  %r76.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r76.rs4o = call i64 asm "", "=r,0"(i64 %r76.rs4i) #9
  %r76 = bitcast i64 %r76.rs4o to double
  %statepoint_token7 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @perry_fn_short_loops_ts__sum, i32 2, i32 0, double %r75, double %r76, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.128, ptr addrspace(1) %.1, ptr addrspace(1) %.122, ptr addrspace(1) %rs4gc.s6) ]
  %r778 = call double @llvm.experimental.gc.result.f64(token %statepoint_token7)
  %rs4gc.s3.relocated9 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token7, i32 0, i32 0) ; (%.128, %.128)
  %rs4gc.s4.relocated10 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token7, i32 1, i32 1) ; (%.1, %.1)
  %rs4gc.s2.relocated11 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token7, i32 2, i32 2) ; (%.122, %.122)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token7, i32 3, i32 3) ; (%rs4gc.s6, %rs4gc.s6)
  %r78.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6.relocated to i64
  %r78 = call i64 asm "", "=r,0"(i64 %r78.rs4i) #9
  %r79 = bitcast i64 %r78 to double
  %r80 = and i64 %r78, -281474976710656
  %r81 = icmp ult i64 %r80, 9221401712017801216
  %r82 = icmp ugt i64 %r80, 9223090561878065152
  %r83 = or i1 %r81, %r82
  %r84 = bitcast double %r778 to i64
  %r85 = and i64 %r84, -281474976710656
  %r86 = icmp ult i64 %r85, 9221401712017801216
  %r87 = icmp ugt i64 %r85, 9223090561878065152
  %r88 = or i1 %r86, %r87
  %r89 = and i1 %r83, %r88
  br i1 %r89, label %guarded_add.numeric.19, label %guarded_add.dynamic.20

guarded_add.numeric.19:                           ; preds = %shadow.root.barrier.done.18
  %r90 = fadd double %r79, %r778
  br label %guarded_add.merge.21

guarded_add.dynamic.20:                           ; preds = %shadow.root.barrier.done.18
  %statepoint_token12 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r79, double %r778, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated9, ptr addrspace(1) %rs4gc.s4.relocated10, ptr addrspace(1) %rs4gc.s2.relocated11) ]
  %r9113 = call double @llvm.experimental.gc.result.f64(token %statepoint_token12)
  %rs4gc.s3.relocated14 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token12, i32 0, i32 0) ; (%rs4gc.s3.relocated9, %rs4gc.s3.relocated9)
  %rs4gc.s4.relocated15 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token12, i32 1, i32 1) ; (%rs4gc.s4.relocated10, %rs4gc.s4.relocated10)
  %rs4gc.s2.relocated16 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token12, i32 2, i32 2) ; (%rs4gc.s2.relocated11, %rs4gc.s2.relocated11)
  br label %guarded_add.merge.21

guarded_add.merge.21:                             ; preds = %guarded_add.dynamic.20, %guarded_add.numeric.19
  %.431 = phi ptr addrspace(1) [ %rs4gc.s3.relocated9, %guarded_add.numeric.19 ], [ %rs4gc.s3.relocated14, %guarded_add.dynamic.20 ]
  %.425 = phi ptr addrspace(1) [ %rs4gc.s2.relocated11, %guarded_add.numeric.19 ], [ %rs4gc.s2.relocated16, %guarded_add.dynamic.20 ]
  %.4 = phi ptr addrspace(1) [ %rs4gc.s4.relocated10, %guarded_add.numeric.19 ], [ %rs4gc.s4.relocated15, %guarded_add.dynamic.20 ]
  %r92 = phi double [ %r90, %guarded_add.numeric.19 ], [ %r9113, %guarded_add.dynamic.20 ]
  %rs4gc.b7 = bitcast double %r92 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r93.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r93 = call i64 asm "", "=r,0"(i64 %r93.rs4i) #9
  %r94 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r95 = icmp ne i32 %r94, 0
  br i1 %r95, label %shadow.root.barrier.22, label %shadow.root.barrier.done.23

shadow.root.barrier.22:                           ; preds = %guarded_add.merge.21
  call void @js_write_barrier_root_nanbox(i64 %r93) #9
  br label %shadow.root.barrier.done.23

shadow.root.barrier.done.23:                      ; preds = %shadow.root.barrier.22, %guarded_add.merge.21
  %r96 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r97 = icmp ne i32 %r96, 0
  br i1 %r97, label %gcpoll.24, label %gcpoll.done.25

gcpoll.24:                                        ; preds = %shadow.root.barrier.done.23
  %statepoint_token17 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7, ptr addrspace(1) %.4, ptr addrspace(1) %.425, ptr addrspace(1) %.431) ]
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token17, i32 0, i32 0) ; (%rs4gc.s7, %rs4gc.s7)
  %rs4gc.s4.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token17, i32 1, i32 1) ; (%.4, %.4)
  %rs4gc.s2.relocated19 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token17, i32 2, i32 2) ; (%.425, %.425)
  %rs4gc.s3.relocated20 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token17, i32 3, i32 3) ; (%.431, %.431)
  br label %gcpoll.done.25

gcpoll.done.25:                                   ; preds = %gcpoll.24, %shadow.root.barrier.done.23
  %.037 = phi ptr addrspace(1) [ %rs4gc.s7.relocated, %gcpoll.24 ], [ %rs4gc.s7, %shadow.root.barrier.done.23 ]
  %.532 = phi ptr addrspace(1) [ %rs4gc.s3.relocated20, %gcpoll.24 ], [ %.431, %shadow.root.barrier.done.23 ]
  %.526 = phi ptr addrspace(1) [ %rs4gc.s2.relocated19, %gcpoll.24 ], [ %.425, %shadow.root.barrier.done.23 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s4.relocated18, %gcpoll.24 ], [ %.4, %shadow.root.barrier.done.23 ]
  br label %for.update.8
}

; Function Attrs: noinline optsize
define double @perry_fn_short_loops_ts__run(double %arg15, double %arg16, double %arg17) #7 {
entry.0:
  %r1 = bitcast double %arg16 to i64
  %r2 = lshr i64 %r1, 48
  %r3 = icmp ult i64 %r2, 32761
  %r4 = icmp ugt i64 %r2, 32767
  %r5 = or i1 %r3, %r4
  %r6 = and i64 %r1, -4294967296
  %r7 = icmp eq i64 %r6, 9222809086901354496
  %r8 = or i1 %r5, %r7
  %r9 = bitcast double %arg17 to i64
  %r10 = lshr i64 %r9, 48
  %r11 = icmp ult i64 %r10, 32761
  %r12 = icmp ugt i64 %r10, 32767
  %r13 = or i1 %r11, %r12
  %r14 = and i64 %r9, -4294967296
  %r15 = icmp eq i64 %r14, 9222809086901354496
  %r16 = or i1 %r13, %r15
  %r17 = and i1 %r8, %r16
  br i1 %r17, label %spec_public.fast.1, label %spec_public.fallback.2

spec_public.fast.1:                               ; preds = %entry.0
  %r18 = call double @"perry_fn_short_loops_ts__run$spec_b_b_b"(double %arg15, double %arg16, double %arg17)
  ret double %r18

spec_public.fallback.2:                           ; preds = %entry.0
  %r19 = call double @"perry_fn_short_loops_ts__run$generic"(double %arg15, double %arg16, double %arg17)
  ret double %r19
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_short_loops_ts__sum(i64 %this_closure, double %a0, double %a1) #6 {
entry.0:
  %r1 = call double @perry_fn_short_loops_ts__sum(double %a0, double %a1)
  ret double %r1
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_short_loops_ts__run(i64 %this_closure, double %a0, double %a1, double %a2) #6 {
entry.0:
  %r1 = call double @perry_fn_short_loops_ts__run(double %a0, double %a1, double %a2)
  ret double %r1
}

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_short_loops_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @short_loops_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" {
entry.0:
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @short_loops_ts_.str.0, i32 120, i32 0, i32 0)
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token3 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token4 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_short_loops_ts, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_mark_entry_module_esm, i32 0, i32 0, i32 0, i32 0)
  %r1 = load double, ptr @short_loops_ts_.str.1.handle, align 8
  %r2 = load double, ptr @short_loops_ts_.str.2.handle, align 8
  %statepoint_token6 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_native_module_named_esm_export_value, i32 2, i32 0, double %r1, double %r2, i32 0, i32 0)
  %statepoint_token7 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0)
  %r515 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token7)
  %r6 = or i64 %r515, 9222527611924643840
  %r7 = bitcast i64 %r6 to double
  %r8 = and i64 %r6, 281474976710655
  %r9 = lshr i64 %r6, 48
  %r10 = icmp eq i64 %r9, 32765
  %r11 = icmp ugt i64 %r8, 1048575
  %r12 = and i1 %r10, %r11
  br i1 %r12, label %arr.guard.deref.5, label %arr.fallback.2

arr.fast.1:                                       ; preds = %arr.guard.range.7
  %r71 = add i64 %r27, 24
  %r72 = inttoptr i64 %r71 to ptr
  %r73 = load double, ptr %r72, align 8
  %r74 = bitcast double %r73 to i64
  %r75 = icmp eq i64 %r74, 9222246136947933200
  %r77 = select i1 %r75, double 0x7FFC000000000001, double %r73
  br label %arr.merge.4

arr.fallback.2:                                   ; preds = %arr.guard.live.6, %arr.guard.deref.5, %entry.0
  %statepoint_token16 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 2301219111847329798, double %r7, double 2.000000e+00, i32 0, i32 0)
  %r6717 = call double @llvm.experimental.gc.result.f64(token %statepoint_token16)
  br label %arr.merge.4

arr.guard.oob.3:                                  ; preds = %arr.guard.range.7
  br label %arr.merge.4

arr.merge.4:                                      ; preds = %arr.guard.oob.3, %arr.fallback.2, %arr.fast.1
  %r78 = phi double [ %r77, %arr.fast.1 ], [ %r6717, %arr.fallback.2 ], [ 0x7FFC000000000001, %arr.guard.oob.3 ]
  %r79 = load double, ptr @short_loops_ts_.str.3.handle, align 8
  %statepoint_token18 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_fs_read_file_dispatch, i32 2, i32 0, double %r78, double %r79, i32 0, i32 0)
  %r8019 = call double @llvm.experimental.gc.result.f64(token %statepoint_token18)
  %rs4gc.b7 = bitcast double %r8019 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r81.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r81 = call i64 asm "", "=r,0"(i64 %r81.rs4i) #9
  %r82 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r83 = icmp ne i32 %r82, 0
  br i1 %r83, label %shadow.root.barrier.8, label %shadow.root.barrier.done.9

arr.guard.deref.5:                                ; preds = %entry.0
  %r13 = bitcast double %r7 to i64
  %r14 = and i64 %r13, 281474976710655
  %r15 = sub nsw i64 %r14, 8
  %r16 = inttoptr i64 %r15 to ptr
  %r17 = load i8, ptr %r16, align 1
  %r18 = icmp eq i8 %r17, 1
  %r19 = sub nsw i64 %r14, 7
  %r20 = inttoptr i64 %r19 to ptr
  %r21 = load i8, ptr %r20, align 1
  %r22 = and i8 %r21, -128
  %r23 = icmp ne i8 %r22, 0
  %r24 = inttoptr i64 %r14 to ptr
  %r25 = load i64, ptr %r24, align 8
  %r26 = and i1 %r18, %r23
  %r27 = select i1 %r26, i64 %r25, i64 %r14
  %r28 = lshr i64 %r27, 48
  %r29 = icmp eq i64 %r28, 0
  %r30 = icmp ugt i64 %r27, 1048575
  %r31 = and i1 %r29, %r30
  br i1 %r31, label %arr.guard.live.6, label %arr.fallback.2

arr.guard.live.6:                                 ; preds = %arr.guard.deref.5
  %r32 = sub nuw i64 %r27, 8
  %r33 = inttoptr i64 %r32 to ptr
  %r34 = load i8, ptr %r33, align 1
  %r35 = icmp eq i8 %r34, 1
  %r36 = sub nuw i64 %r27, 7
  %r37 = inttoptr i64 %r36 to ptr
  %r38 = load i8, ptr %r37, align 1
  %r39 = and i8 %r38, -128
  %r40 = icmp eq i8 %r39, 0
  %r41 = sub nuw i64 %r27, 6
  %r42 = inttoptr i64 %r41 to ptr
  %r43 = load i16, ptr %r42, align 2
  %r44 = and i16 %r43, 1024
  %r45 = icmp eq i16 %r44, 0
  %r46 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r47 = icmp eq i8 %r46, 0
  %r48 = inttoptr i64 %r27 to ptr
  %r49 = load i32, ptr %r48, align 4
  %r50 = getelementptr i8, ptr %r48, i64 4
  %r51 = load i32, ptr %r50, align 4
  %r55 = icmp ule i32 %r49, 16000000
  %r56 = icmp ule i32 %r51, 16000000
  %r57 = icmp ule i32 %r49, %r51
  %r58 = and i1 %r35, %r40
  %r59 = and i1 %r58, %r45
  %r60 = and i1 %r59, %r47
  %r62 = and i1 %r60, %r55
  %r63 = and i1 %r62, %r56
  %r64 = and i1 %r63, %r57
  br i1 %r64, label %arr.guard.range.7, label %arr.fallback.2

arr.guard.range.7:                                ; preds = %arr.guard.live.6
  %r54 = icmp ult i32 2, %r49
  br i1 %r54, label %arr.fast.1, label %arr.guard.oob.3

shadow.root.barrier.8:                            ; preds = %arr.merge.4
  call void @js_write_barrier_root_nanbox(i64 %r81) #9
  br label %shadow.root.barrier.done.9

shadow.root.barrier.done.9:                       ; preds = %shadow.root.barrier.8, %arr.merge.4
  %statepoint_token20 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7) ]
  %r8521 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token20)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 0, i32 0) ; (%rs4gc.s7, %rs4gc.s7)
  %r86 = or i64 %r8521, 9222527611924643840
  %r87 = bitcast i64 %r86 to double
  %r88 = and i64 %r86, 281474976710655
  %r89 = lshr i64 %r86, 48
  %r90 = icmp eq i64 %r89, 32765
  %r91 = icmp ugt i64 %r88, 1048575
  %r92 = and i1 %r90, %r91
  br i1 %r92, label %arr.guard.deref.14, label %arr.fallback.11

arr.fast.10:                                      ; preds = %arr.guard.range.16
  %r151 = add i64 %r107, 32
  %r152 = inttoptr i64 %r151 to ptr
  %r153 = load double, ptr %r152, align 8
  %r154 = bitcast double %r153 to i64
  %r155 = icmp eq i64 %r154, 9222246136947933200
  %r157 = select i1 %r155, double 0x7FFC000000000001, double %r153
  br label %arr.merge.13

arr.fallback.11:                                  ; preds = %arr.guard.live.15, %arr.guard.deref.14, %shadow.root.barrier.done.9
  %statepoint_token22 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 2301219111847329799, double %r87, double 3.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r14723 = call double @llvm.experimental.gc.result.f64(token %statepoint_token22)
  %rs4gc.s7.relocated24 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %arr.merge.13

arr.guard.oob.12:                                 ; preds = %arr.guard.range.16
  br label %arr.merge.13

arr.merge.13:                                     ; preds = %arr.guard.oob.12, %arr.fallback.11, %arr.fast.10
  %.0 = phi ptr addrspace(1) [ %rs4gc.s7.relocated, %arr.fast.10 ], [ %rs4gc.s7.relocated, %arr.guard.oob.12 ], [ %rs4gc.s7.relocated24, %arr.fallback.11 ]
  %r158 = phi double [ %r157, %arr.fast.10 ], [ %r14723, %arr.fallback.11 ], [ 0x7FFC000000000001, %arr.guard.oob.12 ]
  %statepoint_token25 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_number_coerce, i32 1, i32 0, double %r158, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r15926 = call double @llvm.experimental.gc.result.f64(token %statepoint_token25)
  %rs4gc.s7.relocated27 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token25, i32 0, i32 0) ; (%.0, %.0)
  %statepoint_token28 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated27) ]
  %r16129 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token28)
  %rs4gc.s7.relocated30 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 0, i32 0) ; (%rs4gc.s7.relocated27, %rs4gc.s7.relocated27)
  %r162 = or i64 %r16129, 9222527611924643840
  %r163 = bitcast i64 %r162 to double
  %r164 = and i64 %r162, 281474976710655
  %r165 = lshr i64 %r162, 48
  %r166 = icmp eq i64 %r165, 32765
  %r167 = icmp ugt i64 %r164, 1048575
  %r168 = and i1 %r166, %r167
  br i1 %r168, label %arr.guard.deref.21, label %arr.fallback.18

arr.guard.deref.14:                               ; preds = %shadow.root.barrier.done.9
  %r93 = bitcast double %r87 to i64
  %r94 = and i64 %r93, 281474976710655
  %r95 = sub nsw i64 %r94, 8
  %r96 = inttoptr i64 %r95 to ptr
  %r97 = load i8, ptr %r96, align 1
  %r98 = icmp eq i8 %r97, 1
  %r99 = sub nsw i64 %r94, 7
  %r100 = inttoptr i64 %r99 to ptr
  %r101 = load i8, ptr %r100, align 1
  %r102 = and i8 %r101, -128
  %r103 = icmp ne i8 %r102, 0
  %r104 = inttoptr i64 %r94 to ptr
  %r105 = load i64, ptr %r104, align 8
  %r106 = and i1 %r98, %r103
  %r107 = select i1 %r106, i64 %r105, i64 %r94
  %r108 = lshr i64 %r107, 48
  %r109 = icmp eq i64 %r108, 0
  %r110 = icmp ugt i64 %r107, 1048575
  %r111 = and i1 %r109, %r110
  br i1 %r111, label %arr.guard.live.15, label %arr.fallback.11

arr.guard.live.15:                                ; preds = %arr.guard.deref.14
  %r112 = sub nuw i64 %r107, 8
  %r113 = inttoptr i64 %r112 to ptr
  %r114 = load i8, ptr %r113, align 1
  %r115 = icmp eq i8 %r114, 1
  %r116 = sub nuw i64 %r107, 7
  %r117 = inttoptr i64 %r116 to ptr
  %r118 = load i8, ptr %r117, align 1
  %r119 = and i8 %r118, -128
  %r120 = icmp eq i8 %r119, 0
  %r121 = sub nuw i64 %r107, 6
  %r122 = inttoptr i64 %r121 to ptr
  %r123 = load i16, ptr %r122, align 2
  %r124 = and i16 %r123, 1024
  %r125 = icmp eq i16 %r124, 0
  %r126 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r127 = icmp eq i8 %r126, 0
  %r128 = inttoptr i64 %r107 to ptr
  %r129 = load i32, ptr %r128, align 4
  %r130 = getelementptr i8, ptr %r128, i64 4
  %r131 = load i32, ptr %r130, align 4
  %r135 = icmp ule i32 %r129, 16000000
  %r136 = icmp ule i32 %r131, 16000000
  %r137 = icmp ule i32 %r129, %r131
  %r138 = and i1 %r115, %r120
  %r139 = and i1 %r138, %r125
  %r140 = and i1 %r139, %r127
  %r142 = and i1 %r140, %r135
  %r143 = and i1 %r142, %r136
  %r144 = and i1 %r143, %r137
  br i1 %r144, label %arr.guard.range.16, label %arr.fallback.11

arr.guard.range.16:                               ; preds = %arr.guard.live.15
  %r134 = icmp ult i32 3, %r129
  br i1 %r134, label %arr.fast.10, label %arr.guard.oob.12

arr.fast.17:                                      ; preds = %arr.guard.range.23
  %r227 = add i64 %r183, 40
  %r228 = inttoptr i64 %r227 to ptr
  %r229 = load double, ptr %r228, align 8
  %r230 = bitcast double %r229 to i64
  %r231 = icmp eq i64 %r230, 9222246136947933200
  %r233 = select i1 %r231, double 0x7FFC000000000001, double %r229
  br label %arr.merge.20

arr.fallback.18:                                  ; preds = %arr.guard.live.22, %arr.guard.deref.21, %arr.merge.13
  %statepoint_token31 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 2301219111847329800, double %r163, double 4.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated30) ]
  %r22332 = call double @llvm.experimental.gc.result.f64(token %statepoint_token31)
  %rs4gc.s7.relocated33 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token31, i32 0, i32 0) ; (%rs4gc.s7.relocated30, %rs4gc.s7.relocated30)
  br label %arr.merge.20

arr.guard.oob.19:                                 ; preds = %arr.guard.range.23
  br label %arr.merge.20

arr.merge.20:                                     ; preds = %arr.guard.oob.19, %arr.fallback.18, %arr.fast.17
  %.1 = phi ptr addrspace(1) [ %rs4gc.s7.relocated30, %arr.fast.17 ], [ %rs4gc.s7.relocated30, %arr.guard.oob.19 ], [ %rs4gc.s7.relocated33, %arr.fallback.18 ]
  %r234 = phi double [ %r233, %arr.fast.17 ], [ %r22332, %arr.fallback.18 ], [ 0x7FFC000000000001, %arr.guard.oob.19 ]
  %statepoint_token34 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_number_coerce, i32 1, i32 0, double %r234, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1) ]
  %r23535 = call double @llvm.experimental.gc.result.f64(token %statepoint_token34)
  %rs4gc.s7.relocated36 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token34, i32 0, i32 0) ; (%.1, %.1)
  %statepoint_token37 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated36) ]
  %r23738 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token37)
  %rs4gc.s7.relocated39 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token37, i32 0, i32 0) ; (%rs4gc.s7.relocated36, %rs4gc.s7.relocated36)
  %r238 = or i64 %r23738, 9222527611924643840
  %r239 = bitcast i64 %r238 to double
  %r240 = and i64 %r238, 281474976710655
  %r241 = lshr i64 %r238, 48
  %r242 = icmp eq i64 %r241, 32765
  %r243 = icmp ugt i64 %r240, 1048575
  %r244 = and i1 %r242, %r243
  br i1 %r244, label %arr.guard.deref.28, label %arr.fallback.25

arr.guard.deref.21:                               ; preds = %arr.merge.13
  %r169 = bitcast double %r163 to i64
  %r170 = and i64 %r169, 281474976710655
  %r171 = sub nsw i64 %r170, 8
  %r172 = inttoptr i64 %r171 to ptr
  %r173 = load i8, ptr %r172, align 1
  %r174 = icmp eq i8 %r173, 1
  %r175 = sub nsw i64 %r170, 7
  %r176 = inttoptr i64 %r175 to ptr
  %r177 = load i8, ptr %r176, align 1
  %r178 = and i8 %r177, -128
  %r179 = icmp ne i8 %r178, 0
  %r180 = inttoptr i64 %r170 to ptr
  %r181 = load i64, ptr %r180, align 8
  %r182 = and i1 %r174, %r179
  %r183 = select i1 %r182, i64 %r181, i64 %r170
  %r184 = lshr i64 %r183, 48
  %r185 = icmp eq i64 %r184, 0
  %r186 = icmp ugt i64 %r183, 1048575
  %r187 = and i1 %r185, %r186
  br i1 %r187, label %arr.guard.live.22, label %arr.fallback.18

arr.guard.live.22:                                ; preds = %arr.guard.deref.21
  %r188 = sub nuw i64 %r183, 8
  %r189 = inttoptr i64 %r188 to ptr
  %r190 = load i8, ptr %r189, align 1
  %r191 = icmp eq i8 %r190, 1
  %r192 = sub nuw i64 %r183, 7
  %r193 = inttoptr i64 %r192 to ptr
  %r194 = load i8, ptr %r193, align 1
  %r195 = and i8 %r194, -128
  %r196 = icmp eq i8 %r195, 0
  %r197 = sub nuw i64 %r183, 6
  %r198 = inttoptr i64 %r197 to ptr
  %r199 = load i16, ptr %r198, align 2
  %r200 = and i16 %r199, 1024
  %r201 = icmp eq i16 %r200, 0
  %r202 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r203 = icmp eq i8 %r202, 0
  %r204 = inttoptr i64 %r183 to ptr
  %r205 = load i32, ptr %r204, align 4
  %r206 = getelementptr i8, ptr %r204, i64 4
  %r207 = load i32, ptr %r206, align 4
  %r211 = icmp ule i32 %r205, 16000000
  %r212 = icmp ule i32 %r207, 16000000
  %r213 = icmp ule i32 %r205, %r207
  %r214 = and i1 %r191, %r196
  %r215 = and i1 %r214, %r201
  %r216 = and i1 %r215, %r203
  %r218 = and i1 %r216, %r211
  %r219 = and i1 %r218, %r212
  %r220 = and i1 %r219, %r213
  br i1 %r220, label %arr.guard.range.23, label %arr.fallback.18

arr.guard.range.23:                               ; preds = %arr.guard.live.22
  %r210 = icmp ult i32 4, %r205
  br i1 %r210, label %arr.fast.17, label %arr.guard.oob.19

arr.fast.24:                                      ; preds = %arr.guard.range.30
  %r303 = add i64 %r259, 48
  %r304 = inttoptr i64 %r303 to ptr
  %r305 = load double, ptr %r304, align 8
  %r306 = bitcast double %r305 to i64
  %r307 = icmp eq i64 %r306, 9222246136947933200
  %r309 = select i1 %r307, double 0x7FFC000000000001, double %r305
  br label %arr.merge.27

arr.fallback.25:                                  ; preds = %arr.guard.live.29, %arr.guard.deref.28, %arr.merge.20
  %statepoint_token40 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 2301219111847329801, double %r239, double 5.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated39) ]
  %r29941 = call double @llvm.experimental.gc.result.f64(token %statepoint_token40)
  %rs4gc.s7.relocated42 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 0, i32 0) ; (%rs4gc.s7.relocated39, %rs4gc.s7.relocated39)
  br label %arr.merge.27

arr.guard.oob.26:                                 ; preds = %arr.guard.range.30
  br label %arr.merge.27

arr.merge.27:                                     ; preds = %arr.guard.oob.26, %arr.fallback.25, %arr.fast.24
  %.2 = phi ptr addrspace(1) [ %rs4gc.s7.relocated39, %arr.fast.24 ], [ %rs4gc.s7.relocated39, %arr.guard.oob.26 ], [ %rs4gc.s7.relocated42, %arr.fallback.25 ]
  %r310 = phi double [ %r309, %arr.fast.24 ], [ %r29941, %arr.fallback.25 ], [ 0x7FFC000000000001, %arr.guard.oob.26 ]
  %statepoint_token43 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_number_coerce, i32 1, i32 0, double %r310, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r31144 = call double @llvm.experimental.gc.result.f64(token %statepoint_token43)
  %rs4gc.s7.relocated45 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token43, i32 0, i32 0) ; (%.2, %.2)
  %r313.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7.relocated45 to i64
  %r313.rs4o = call i64 asm "", "=r,0"(i64 %r313.rs4i) #9
  %r313 = bitcast i64 %r313.rs4o to double
  %statepoint_token46 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r313, i32 0, i32 0)
  %r31447 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token46)
  %statepoint_token48 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r31447, i32 0, i32 0)
  %r31549 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token48)
  %r316 = bitcast i64 %r31549 to double
  %rs4gc.b8 = bitcast double %r316 to i64
  %rs4gc.s8 = inttoptr i64 %rs4gc.b8 to ptr addrspace(1)
  %r317.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r317 = call i64 asm "", "=r,0"(i64 %r317.rs4i) #9
  %r318 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r319 = icmp ne i32 %r318, 0
  br i1 %r319, label %shadow.root.barrier.31, label %shadow.root.barrier.done.32

arr.guard.deref.28:                               ; preds = %arr.merge.20
  %r245 = bitcast double %r239 to i64
  %r246 = and i64 %r245, 281474976710655
  %r247 = sub nsw i64 %r246, 8
  %r248 = inttoptr i64 %r247 to ptr
  %r249 = load i8, ptr %r248, align 1
  %r250 = icmp eq i8 %r249, 1
  %r251 = sub nsw i64 %r246, 7
  %r252 = inttoptr i64 %r251 to ptr
  %r253 = load i8, ptr %r252, align 1
  %r254 = and i8 %r253, -128
  %r255 = icmp ne i8 %r254, 0
  %r256 = inttoptr i64 %r246 to ptr
  %r257 = load i64, ptr %r256, align 8
  %r258 = and i1 %r250, %r255
  %r259 = select i1 %r258, i64 %r257, i64 %r246
  %r260 = lshr i64 %r259, 48
  %r261 = icmp eq i64 %r260, 0
  %r262 = icmp ugt i64 %r259, 1048575
  %r263 = and i1 %r261, %r262
  br i1 %r263, label %arr.guard.live.29, label %arr.fallback.25

arr.guard.live.29:                                ; preds = %arr.guard.deref.28
  %r264 = sub nuw i64 %r259, 8
  %r265 = inttoptr i64 %r264 to ptr
  %r266 = load i8, ptr %r265, align 1
  %r267 = icmp eq i8 %r266, 1
  %r268 = sub nuw i64 %r259, 7
  %r269 = inttoptr i64 %r268 to ptr
  %r270 = load i8, ptr %r269, align 1
  %r271 = and i8 %r270, -128
  %r272 = icmp eq i8 %r271, 0
  %r273 = sub nuw i64 %r259, 6
  %r274 = inttoptr i64 %r273 to ptr
  %r275 = load i16, ptr %r274, align 2
  %r276 = and i16 %r275, 1024
  %r277 = icmp eq i16 %r276, 0
  %r278 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r279 = icmp eq i8 %r278, 0
  %r280 = inttoptr i64 %r259 to ptr
  %r281 = load i32, ptr %r280, align 4
  %r282 = getelementptr i8, ptr %r280, i64 4
  %r283 = load i32, ptr %r282, align 4
  %r287 = icmp ule i32 %r281, 16000000
  %r288 = icmp ule i32 %r283, 16000000
  %r289 = icmp ule i32 %r281, %r283
  %r290 = and i1 %r267, %r272
  %r291 = and i1 %r290, %r277
  %r292 = and i1 %r291, %r279
  %r294 = and i1 %r292, %r287
  %r295 = and i1 %r294, %r288
  %r296 = and i1 %r295, %r289
  br i1 %r296, label %arr.guard.range.30, label %arr.fallback.25

arr.guard.range.30:                               ; preds = %arr.guard.live.29
  %r286 = icmp ult i32 5, %r281
  br i1 %r286, label %arr.fast.24, label %arr.guard.oob.26

shadow.root.barrier.31:                           ; preds = %arr.merge.27
  call void @js_write_barrier_root_nanbox(i64 %r317) #9
  br label %shadow.root.barrier.done.32

shadow.root.barrier.done.32:                      ; preds = %shadow.root.barrier.31, %arr.merge.27
  %r321.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r321.rs4o = call i64 asm "", "=r,0"(i64 %r321.rs4i) #9
  %r321 = bitcast i64 %r321.rs4o to double
  %statepoint_token50 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double)) @"perry_fn_short_loops_ts__run$spec_b_b_b", i32 3, i32 0, double %r321, double %r31144, double %r15926, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8) ]
  %r32451 = call double @llvm.experimental.gc.result.f64(token %statepoint_token50)
  %rs4gc.s8.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token50, i32 0, i32 0) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.b9 = bitcast double %r32451 to i64
  %rs4gc.s9 = inttoptr i64 %rs4gc.b9 to ptr addrspace(1)
  %r325.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r325 = call i64 asm "", "=r,0"(i64 %r325.rs4i) #9
  %r326 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r327 = icmp ne i32 %r326, 0
  br i1 %r327, label %shadow.root.barrier.33, label %shadow.root.barrier.done.34

shadow.root.barrier.33:                           ; preds = %shadow.root.barrier.done.32
  call void @js_write_barrier_root_nanbox(i64 %r325) #9
  br label %shadow.root.barrier.done.34

shadow.root.barrier.done.34:                      ; preds = %shadow.root.barrier.33, %shadow.root.barrier.done.32
  %statepoint_token52 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_process_memory_usage, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated, ptr addrspace(1) %rs4gc.s9) ]
  %r32953 = call double @llvm.experimental.gc.result.f64(token %statepoint_token52)
  %rs4gc.s8.relocated54 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token52, i32 0, i32 0) ; (%rs4gc.s8.relocated, %rs4gc.s8.relocated)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token52, i32 1, i32 1) ; (%rs4gc.s9, %rs4gc.s9)
  %r330 = bitcast double %r32953 to i64
  %r331 = and i64 %r330, 281474976710655
  %r332 = lshr i64 %r330, 48
  %r333 = and i64 %r332, 65533
  %r334 = icmp eq i64 %r333, 32765
  br i1 %r334, label %pget.recv_ok.36, label %pget.recv_other.40

pget.recv_sso.35:                                 ; preds = %pget.recv_other.40
  %r472 = load double, ptr @short_loops_ts_.str.4.handle, align 8
  %r473 = bitcast double %r472 to i64
  %r474 = and i64 %r473, 281474976710655
  %statepoint_token55 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r330, i64 %r474, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated54, ptr addrspace(1) %rs4gc.s9.relocated) ]
  %r47556 = call double @llvm.experimental.gc.result.f64(token %statepoint_token55)
  %rs4gc.s8.relocated57 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 0, i32 0) ; (%rs4gc.s8.relocated54, %rs4gc.s8.relocated54)
  %rs4gc.s9.relocated58 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 1, i32 1) ; (%rs4gc.s9.relocated, %rs4gc.s9.relocated)
  br label %pget.recv_merge.39

pget.recv_ok.36:                                  ; preds = %shadow.root.barrier.done.34
  %r341 = icmp ugt i64 %r331, 1048575
  br i1 %r341, label %pic.recv_hdr.57, label %pic.miss.cold.54

pget.recv_bad.37:                                 ; preds = %pget.check_class_ref.41
  %r464 = icmp eq i64 %r330, 9222246136947933185
  %r465 = icmp eq i64 %r330, 9222246136947933186
  %r466 = or i1 %r464, %r465
  br i1 %r466, label %pget.throw_nullish.64, label %pget.recv_undef_return.65

pget.recv_class_ref.38:                           ; preds = %pget.check_class_ref.41
  %r337 = load double, ptr @short_loops_ts_.str.4.handle, align 8
  %r338 = bitcast double %r337 to i64
  %r339 = and i64 %r338, 281474976710655
  %statepoint_token59 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 2301219111847329802, i64 %r330, i64 %r339, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated54, ptr addrspace(1) %rs4gc.s9.relocated) ]
  %r34060 = call double @llvm.experimental.gc.result.f64(token %statepoint_token59)
  %rs4gc.s8.relocated61 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 0, i32 0) ; (%rs4gc.s8.relocated54, %rs4gc.s8.relocated54)
  %rs4gc.s9.relocated62 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 1, i32 1) ; (%rs4gc.s9.relocated, %rs4gc.s9.relocated)
  br label %pget.recv_merge.39

pget.recv_merge.39:                               ; preds = %pget.recv_undef_return.65, %pic.merge.56, %pget.recv_class_ref.38, %pget.recv_sso.35
  %.0427 = phi ptr addrspace(1) [ %.1428, %pic.merge.56 ], [ %rs4gc.s9.relocated58, %pget.recv_sso.35 ], [ %rs4gc.s9.relocated62, %pget.recv_class_ref.38 ], [ %rs4gc.s9.relocated75, %pget.recv_undef_return.65 ]
  %.0424 = phi ptr addrspace(1) [ %.1425, %pic.merge.56 ], [ %rs4gc.s8.relocated57, %pget.recv_sso.35 ], [ %rs4gc.s8.relocated61, %pget.recv_class_ref.38 ], [ %rs4gc.s8.relocated74, %pget.recv_undef_return.65 ]
  %r476 = phi double [ %r463, %pic.merge.56 ], [ %r47173, %pget.recv_undef_return.65 ], [ %r47556, %pget.recv_sso.35 ], [ %r34060, %pget.recv_class_ref.38 ]
  %rs4gc.b10 = bitcast double %r476 to i64
  %rs4gc.s10 = inttoptr i64 %rs4gc.b10 to ptr addrspace(1)
  %r477.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r477 = call i64 asm "", "=r,0"(i64 %r477.rs4i) #9
  %r478 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r479 = icmp ne i32 %r478, 0
  br i1 %r479, label %shadow.root.barrier.66, label %shadow.root.barrier.done.67

pget.recv_other.40:                               ; preds = %shadow.root.barrier.done.34
  %r335 = icmp eq i64 %r332, 32761
  br i1 %r335, label %pget.recv_sso.35, label %pget.check_class_ref.41

pget.check_class_ref.41:                          ; preds = %pget.recv_other.40
  %r336 = icmp eq i64 %r332, 32766
  br i1 %r336, label %pget.recv_class_ref.38, label %pget.recv_bad.37

pic.hit.42:                                       ; preds = %pic.token.58
  %r366 = getelementptr i64, ptr %r351, i64 1
  %r367 = load i64, ptr %r366, align 8
  %r368 = and i64 %r367, 1073741824
  %r369 = icmp ne i64 %r368, 0
  br i1 %r369, label %pic.hit.overflow.59, label %pic.hit.inline.60

pic.hit.live.43:                                  ; preds = %pic.hit.inline.60
  br label %pic.merge.56

pic.prefix.guard.44:                              ; preds = %pic.token.58
  %r382 = getelementptr i64, ptr %r351, i64 2
  %r383 = load i64, ptr %r382, align 8
  %r384 = icmp ne i64 %r383, 0
  br i1 %r384, label %pic.prefix.meta.45, label %pic.miss.53

pic.prefix.meta.45:                               ; preds = %pic.prefix.guard.44
  %r385 = add nuw nsw i64 %r331, 8
  %r386 = inttoptr i64 %r385 to ptr
  %r387 = load i64, ptr %r386, align 8
  %r388 = icmp ne i64 %r387, 0
  br i1 %r388, label %pic.prefix.token.46, label %pic.miss.53

pic.prefix.token.46:                              ; preds = %pic.prefix.meta.45
  %r389 = inttoptr i64 %r387 to ptr
  %r390 = getelementptr i64, ptr %r389, i64 6
  %r391 = load i64, ptr %r390, align 8
  %r392 = icmp eq i64 %r391, %r383
  br i1 %r392, label %pic.prefix.hit.47, label %pic.miss.53

pic.prefix.hit.47:                                ; preds = %pic.prefix.token.46
  %r393 = getelementptr i64, ptr %r351, i64 1
  %r394 = load i64, ptr %r393, align 8
  %r395 = shl i64 %r394, 3
  %r396 = add nuw nsw i64 %r331, 16
  %r397 = add i64 %r396, %r395
  %r398 = inttoptr i64 %r397 to ptr
  %r399 = load double, ptr %r398, align 8
  br label %pic.merge.56

pic.desc.classify.48:                             ; preds = %pic.recv_hdr.57
  %r355 = and i1 %r345, %r352
  br i1 %r355, label %pic.desc.prefix.guard.49, label %pic.miss.cold.54

pic.desc.prefix.guard.49:                         ; preds = %pic.desc.classify.48
  %r400 = getelementptr i64, ptr %r351, i64 2
  %r401 = load i64, ptr %r400, align 8
  %r402 = icmp ne i64 %r401, 0
  br i1 %r402, label %pic.desc.prefix.meta.50, label %pic.miss.cold.54

pic.desc.prefix.meta.50:                          ; preds = %pic.desc.prefix.guard.49
  %r403 = add nuw nsw i64 %r331, 8
  %r404 = inttoptr i64 %r403 to ptr
  %r405 = load i64, ptr %r404, align 8
  %r406 = icmp ne i64 %r405, 0
  br i1 %r406, label %pic.desc.prefix.token.51, label %pic.miss.cold.54

pic.desc.prefix.token.51:                         ; preds = %pic.desc.prefix.meta.50
  %r407 = inttoptr i64 %r405 to ptr
  %r408 = getelementptr i64, ptr %r407, i64 6
  %r409 = load i64, ptr %r408, align 8
  %r410 = icmp eq i64 %r409, %r401
  br i1 %r410, label %pic.desc.prefix.hit.52, label %pic.miss.cold.54

pic.desc.prefix.hit.52:                           ; preds = %pic.desc.prefix.token.51
  %r411 = getelementptr i64, ptr %r351, i64 1
  %r412 = load i64, ptr %r411, align 8
  %r413 = shl i64 %r412, 3
  %r414 = add nuw nsw i64 %r331, 16
  %r415 = add i64 %r414, %r413
  %r416 = inttoptr i64 %r415 to ptr
  %r417 = load double, ptr %r416, align 8
  br label %pic.merge.56

pic.miss.53:                                      ; preds = %pic.hit.inline.60, %pic.prefix.token.46, %pic.prefix.meta.45, %pic.prefix.guard.44
  %r418 = getelementptr i64, ptr %r351, i64 3
  %r419 = load i64, ptr %r418, align 8
  %r420 = icmp sgt i64 %r419, 0
  br i1 %r420, label %pic.ways.61, label %pic.miss.call.55

pic.miss.cold.54:                                 ; preds = %pic.desc.prefix.token.51, %pic.desc.prefix.meta.50, %pic.desc.prefix.guard.49, %pic.desc.classify.48, %pget.recv_ok.36
  br label %pic.miss.call.55

pic.miss.call.55:                                 ; preds = %pic.way.load.62, %pic.ways.61, %pic.miss.cold.54, %pic.miss.53
  %r459 = load double, ptr @short_loops_ts_.str.4.handle, align 8
  %r460 = bitcast double %r459 to i64
  %r461 = and i64 %r460, 281474976710655
  %statepoint_token63 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r331, i64 %r461, ptr @perry_ic_short_loops_ts__11, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated54, ptr addrspace(1) %rs4gc.s9.relocated) ]
  %r46264 = call double @llvm.experimental.gc.result.f64(token %statepoint_token63)
  %rs4gc.s8.relocated65 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 0, i32 0) ; (%rs4gc.s8.relocated54, %rs4gc.s8.relocated54)
  %rs4gc.s9.relocated66 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 1, i32 1) ; (%rs4gc.s9.relocated, %rs4gc.s9.relocated)
  br label %pic.merge.56

pic.merge.56:                                     ; preds = %pic.way.live.63, %pic.hit.overflow.59, %pic.miss.call.55, %pic.desc.prefix.hit.52, %pic.prefix.hit.47, %pic.hit.live.43
  %.1428 = phi ptr addrspace(1) [ %rs4gc.s9.relocated70, %pic.hit.overflow.59 ], [ %rs4gc.s9.relocated66, %pic.miss.call.55 ], [ %rs4gc.s9.relocated, %pic.way.live.63 ], [ %rs4gc.s9.relocated, %pic.hit.live.43 ], [ %rs4gc.s9.relocated, %pic.prefix.hit.47 ], [ %rs4gc.s9.relocated, %pic.desc.prefix.hit.52 ]
  %.1425 = phi ptr addrspace(1) [ %rs4gc.s8.relocated69, %pic.hit.overflow.59 ], [ %rs4gc.s8.relocated65, %pic.miss.call.55 ], [ %rs4gc.s8.relocated54, %pic.way.live.63 ], [ %rs4gc.s8.relocated54, %pic.hit.live.43 ], [ %rs4gc.s8.relocated54, %pic.prefix.hit.47 ], [ %rs4gc.s8.relocated54, %pic.desc.prefix.hit.52 ]
  %r463 = phi double [ %r379, %pic.hit.live.43 ], [ %r37468, %pic.hit.overflow.59 ], [ %r399, %pic.prefix.hit.47 ], [ %r417, %pic.desc.prefix.hit.52 ], [ %r456, %pic.way.live.63 ], [ %r46264, %pic.miss.call.55 ]
  br label %pget.recv_merge.39

pic.recv_hdr.57:                                  ; preds = %pget.recv_ok.36
  %r342 = sub nuw nsw i64 %r331, 8
  %r343 = inttoptr i64 %r342 to ptr
  %r344 = load i8, ptr %r343, align 1
  %r345 = icmp eq i8 %r344, 2
  %r346 = sub nuw nsw i64 %r331, 6
  %r347 = inttoptr i64 %r346 to ptr
  %r348 = load i16, ptr %r347, align 2
  %r349 = and i16 %r348, 2048
  %r350 = icmp eq i16 %r349, 0
  %r351 = load ptr, ptr @perry_ic_short_loops_ts__11, align 8
  %r352 = icmp ne ptr %r351, null
  %r353 = and i1 %r345, %r350
  %r354 = and i1 %r353, %r352
  br i1 %r354, label %pic.token.58, label %pic.desc.classify.48

pic.token.58:                                     ; preds = %pic.recv_hdr.57
  %r356 = add nuw nsw i64 %r331, 4
  %r357 = inttoptr i64 %r356 to ptr
  %r358 = load i32, ptr %r357, align 4
  %r359 = zext i32 %r358 to i64
  %r360 = or i64 %r359, 4611686018427387904
  %r361 = icmp ne i32 %r358, 0
  %r362 = getelementptr i64, ptr %r351, i64 0
  %r363 = load i64, ptr %r362, align 8
  %r364 = icmp eq i64 %r360, %r363
  %r365 = and i1 %r364, %r361
  br i1 %r365, label %pic.hit.42, label %pic.prefix.guard.44

pic.hit.overflow.59:                              ; preds = %pic.hit.42
  %r370 = load double, ptr @short_loops_ts_.str.4.handle, align 8
  %r371 = bitcast double %r370 to i64
  %r372 = and i64 %r371, 281474976710655
  %r373 = trunc i64 %r367 to i32
  %statepoint_token67 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r331, i64 %r372, i32 %r373, ptr @perry_ic_short_loops_ts__11, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated54, ptr addrspace(1) %rs4gc.s9.relocated) ]
  %r37468 = call double @llvm.experimental.gc.result.f64(token %statepoint_token67)
  %rs4gc.s8.relocated69 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token67, i32 0, i32 0) ; (%rs4gc.s8.relocated54, %rs4gc.s8.relocated54)
  %rs4gc.s9.relocated70 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token67, i32 1, i32 1) ; (%rs4gc.s9.relocated, %rs4gc.s9.relocated)
  br label %pic.merge.56

pic.hit.inline.60:                                ; preds = %pic.hit.42
  %r375 = shl i64 %r367, 3
  %r376 = add nuw nsw i64 %r331, 16
  %r377 = add i64 %r376, %r375
  %r378 = inttoptr i64 %r377 to ptr
  %r379 = load double, ptr %r378, align 8
  %r380 = bitcast double %r379 to i64
  %r381 = icmp eq i64 %r380, 9222246136947933200
  br i1 %r381, label %pic.miss.53, label %pic.hit.live.43

pic.ways.61:                                      ; preds = %pic.miss.53
  %r421 = getelementptr i64, ptr %r351, i64 4
  %r422 = load i64, ptr %r421, align 8
  %r423 = icmp eq i64 %r422, %r360
  %r424 = getelementptr i64, ptr %r351, i64 5
  %r425 = load i64, ptr %r424, align 8
  %r426 = select i1 %r423, i64 %r425, i64 0
  %r427 = getelementptr i64, ptr %r351, i64 6
  %r428 = load i64, ptr %r427, align 8
  %r429 = icmp eq i64 %r428, %r360
  %r430 = getelementptr i64, ptr %r351, i64 7
  %r431 = load i64, ptr %r430, align 8
  %r432 = select i1 %r429, i64 %r431, i64 0
  %r433 = getelementptr i64, ptr %r351, i64 8
  %r434 = load i64, ptr %r433, align 8
  %r435 = icmp eq i64 %r434, %r360
  %r436 = getelementptr i64, ptr %r351, i64 9
  %r437 = load i64, ptr %r436, align 8
  %r438 = select i1 %r435, i64 %r437, i64 0
  %r439 = getelementptr i64, ptr %r351, i64 10
  %r440 = load i64, ptr %r439, align 8
  %r441 = icmp eq i64 %r440, %r360
  %r442 = getelementptr i64, ptr %r351, i64 11
  %r443 = load i64, ptr %r442, align 8
  %r444 = select i1 %r441, i64 %r443, i64 0
  %r445 = or i1 %r423, %r429
  %r446 = select i1 %r423, i64 %r426, i64 %r432
  %r447 = or i1 %r435, %r441
  %r448 = select i1 %r435, i64 %r438, i64 %r444
  %r449 = or i1 %r445, %r447
  %r450 = select i1 %r445, i64 %r446, i64 %r448
  %r451 = and i1 %r361, %r449
  br i1 %r451, label %pic.way.load.62, label %pic.miss.call.55

pic.way.load.62:                                  ; preds = %pic.ways.61
  %r452 = shl i64 %r450, 3
  %r453 = add nuw nsw i64 %r331, 16
  %r454 = add i64 %r453, %r452
  %r455 = inttoptr i64 %r454 to ptr
  %r456 = load double, ptr %r455, align 8
  %r457 = bitcast double %r456 to i64
  %r458 = icmp eq i64 %r457, 9222246136947933200
  br i1 %r458, label %pic.miss.call.55, label %pic.way.live.63

pic.way.live.63:                                  ; preds = %pic.way.load.62
  br label %pic.merge.56

pget.throw_nullish.64:                            ; preds = %pget.recv_bad.37
  %r467 = zext i1 %r465 to i32
  %statepoint_token71 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r467, ptr @short_loops_ts_.str.4.bytes, i64 3, i32 0, i32 0)
  unreachable

pget.recv_undef_return.65:                        ; preds = %pget.recv_bad.37
  %r468 = load double, ptr @short_loops_ts_.str.4.handle, align 8
  %r469 = bitcast double %r468 to i64
  %r470 = and i64 %r469, 281474976710655
  %statepoint_token72 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r330, i64 %r470, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated54, ptr addrspace(1) %rs4gc.s9.relocated) ]
  %r47173 = call double @llvm.experimental.gc.result.f64(token %statepoint_token72)
  %rs4gc.s8.relocated74 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token72, i32 0, i32 0) ; (%rs4gc.s8.relocated54, %rs4gc.s8.relocated54)
  %rs4gc.s9.relocated75 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token72, i32 1, i32 1) ; (%rs4gc.s9.relocated, %rs4gc.s9.relocated)
  br label %pget.recv_merge.39

shadow.root.barrier.66:                           ; preds = %pget.recv_merge.39
  call void @js_write_barrier_root_nanbox(i64 %r477) #9
  br label %shadow.root.barrier.done.67

shadow.root.barrier.done.67:                      ; preds = %shadow.root.barrier.66, %pget.recv_merge.39
  %statepoint_token76 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_process_cpu_usage, i32 1, i32 0, double 0x7FFC000000000001, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0427, ptr addrspace(1) %.0424, ptr addrspace(1) %rs4gc.s10) ]
  %r48177 = call double @llvm.experimental.gc.result.f64(token %statepoint_token76)
  %rs4gc.s9.relocated78 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token76, i32 0, i32 0) ; (%.0427, %.0427)
  %rs4gc.s8.relocated79 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token76, i32 1, i32 1) ; (%.0424, %.0424)
  %rs4gc.s10.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token76, i32 2, i32 2) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.b11 = bitcast double %r48177 to i64
  %rs4gc.s11 = inttoptr i64 %rs4gc.b11 to ptr addrspace(1)
  %r482.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11 to i64
  %r482 = call i64 asm "", "=r,0"(i64 %r482.rs4i) #9
  %r483 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r484 = icmp ne i32 %r483, 0
  br i1 %r484, label %shadow.root.barrier.68, label %shadow.root.barrier.done.69

shadow.root.barrier.68:                           ; preds = %shadow.root.barrier.done.67
  call void @js_write_barrier_root_nanbox(i64 %r482) #9
  br label %shadow.root.barrier.done.69

shadow.root.barrier.done.69:                      ; preds = %shadow.root.barrier.68, %shadow.root.barrier.done.67
  %statepoint_token80 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_performance_now, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated79, ptr addrspace(1) %rs4gc.s10.relocated, ptr addrspace(1) %rs4gc.s11, ptr addrspace(1) %rs4gc.s9.relocated78) ]
  %r48681 = call double @llvm.experimental.gc.result.f64(token %statepoint_token80)
  %rs4gc.s8.relocated82 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 0, i32 0) ; (%rs4gc.s8.relocated79, %rs4gc.s8.relocated79)
  %rs4gc.s10.relocated83 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 1, i32 1) ; (%rs4gc.s10.relocated, %rs4gc.s10.relocated)
  %rs4gc.s11.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  %rs4gc.s9.relocated84 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 3, i32 3) ; (%rs4gc.s9.relocated78, %rs4gc.s9.relocated78)
  %r487.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9.relocated84 to i64
  %r487.rs4o = call i64 asm "", "=r,0"(i64 %r487.rs4i) #9
  %r487 = bitcast i64 %r487.rs4o to double
  %r488 = bitcast double %r487 to i64
  %rs4gc.s12 = inttoptr i64 %r488 to ptr addrspace(1)
  %r490.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r490 = call i64 asm "", "=r,0"(i64 %r490.rs4i) #9
  %r491 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r492 = icmp ne i32 %r491, 0
  br i1 %r492, label %shadow.root.barrier.70, label %shadow.root.barrier.done.71

shadow.root.barrier.70:                           ; preds = %shadow.root.barrier.done.69
  call void @js_write_barrier_root_nanbox(i64 %r490) #9
  br label %shadow.root.barrier.done.71

shadow.root.barrier.done.71:                      ; preds = %shadow.root.barrier.70, %shadow.root.barrier.done.69
  %r493.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8.relocated82 to i64
  %r493.rs4o = call i64 asm "", "=r,0"(i64 %r493.rs4i) #9
  %r493 = bitcast i64 %r493.rs4o to double
  %statepoint_token85 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double)) @"perry_fn_short_loops_ts__run$spec_b_b_b", i32 3, i32 0, double %r493, double %r23535, double %r15926, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated82, ptr addrspace(1) %rs4gc.s10.relocated83, ptr addrspace(1) %rs4gc.s11.relocated, ptr addrspace(1) %rs4gc.s12) ]
  %r49686 = call double @llvm.experimental.gc.result.f64(token %statepoint_token85)
  %rs4gc.s8.relocated87 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 0, i32 0) ; (%rs4gc.s8.relocated82, %rs4gc.s8.relocated82)
  %rs4gc.s10.relocated88 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 1, i32 1) ; (%rs4gc.s10.relocated83, %rs4gc.s10.relocated83)
  %rs4gc.s11.relocated89 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 2, i32 2) ; (%rs4gc.s11.relocated, %rs4gc.s11.relocated)
  %rs4gc.s12.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 3, i32 3) ; (%rs4gc.s12, %rs4gc.s12)
  %r497.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12.relocated to i64
  %r497 = call i64 asm "", "=r,0"(i64 %r497.rs4i) #9
  %r498 = bitcast i64 %r497 to double
  %r499 = and i64 %r497, -281474976710656
  %r500 = icmp ult i64 %r499, 9221401712017801216
  %r501 = icmp ugt i64 %r499, 9223090561878065152
  %r502 = or i1 %r500, %r501
  %r503 = bitcast double %r49686 to i64
  %r504 = and i64 %r503, -281474976710656
  %r505 = icmp ult i64 %r504, 9221401712017801216
  %r506 = icmp ugt i64 %r504, 9223090561878065152
  %r507 = or i1 %r505, %r506
  %r508 = and i1 %r502, %r507
  br i1 %r508, label %guarded_add.numeric.72, label %guarded_add.dynamic.73

guarded_add.numeric.72:                           ; preds = %shadow.root.barrier.done.71
  %r509 = fadd double %r498, %r49686
  br label %guarded_add.merge.74

guarded_add.dynamic.73:                           ; preds = %shadow.root.barrier.done.71
  %statepoint_token90 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r498, double %r49686, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated87, ptr addrspace(1) %rs4gc.s10.relocated88, ptr addrspace(1) %rs4gc.s11.relocated89) ]
  %r51091 = call double @llvm.experimental.gc.result.f64(token %statepoint_token90)
  %rs4gc.s8.relocated92 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token90, i32 0, i32 0) ; (%rs4gc.s8.relocated87, %rs4gc.s8.relocated87)
  %rs4gc.s10.relocated93 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token90, i32 1, i32 1) ; (%rs4gc.s10.relocated88, %rs4gc.s10.relocated88)
  %rs4gc.s11.relocated94 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token90, i32 2, i32 2) ; (%rs4gc.s11.relocated89, %rs4gc.s11.relocated89)
  br label %guarded_add.merge.74

guarded_add.merge.74:                             ; preds = %guarded_add.dynamic.73, %guarded_add.numeric.72
  %.0441 = phi ptr addrspace(1) [ %rs4gc.s11.relocated89, %guarded_add.numeric.72 ], [ %rs4gc.s11.relocated94, %guarded_add.dynamic.73 ]
  %.0429 = phi ptr addrspace(1) [ %rs4gc.s10.relocated88, %guarded_add.numeric.72 ], [ %rs4gc.s10.relocated93, %guarded_add.dynamic.73 ]
  %.2426 = phi ptr addrspace(1) [ %rs4gc.s8.relocated87, %guarded_add.numeric.72 ], [ %rs4gc.s8.relocated92, %guarded_add.dynamic.73 ]
  %r511 = phi double [ %r509, %guarded_add.numeric.72 ], [ %r51091, %guarded_add.dynamic.73 ]
  %rs4gc.b13 = bitcast double %r511 to i64
  %rs4gc.s13 = inttoptr i64 %rs4gc.b13 to ptr addrspace(1)
  %r512.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r512 = call i64 asm "", "=r,0"(i64 %r512.rs4i) #9
  %r513 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r514 = icmp ne i32 %r513, 0
  br i1 %r514, label %shadow.root.barrier.75, label %shadow.root.barrier.done.76

shadow.root.barrier.75:                           ; preds = %guarded_add.merge.74
  call void @js_write_barrier_root_nanbox(i64 %r512) #9
  br label %shadow.root.barrier.done.76

shadow.root.barrier.done.76:                      ; preds = %shadow.root.barrier.75, %guarded_add.merge.74
  %statepoint_token95 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_performance_now, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2426, ptr addrspace(1) %rs4gc.s13, ptr addrspace(1) %.0429, ptr addrspace(1) %.0441) ]
  %r51696 = call double @llvm.experimental.gc.result.f64(token %statepoint_token95)
  %rs4gc.s8.relocated97 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token95, i32 0, i32 0) ; (%.2426, %.2426)
  %rs4gc.s13.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token95, i32 1, i32 1) ; (%rs4gc.s13, %rs4gc.s13)
  %rs4gc.s10.relocated98 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token95, i32 2, i32 2) ; (%.0429, %.0429)
  %rs4gc.s11.relocated99 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token95, i32 3, i32 3) ; (%.0441, %.0441)
  %r518 = bitcast double %r51696 to i64
  %r519 = and i64 %r518, -281474976710656
  %r520 = icmp ult i64 %r519, 9221401712017801216
  %r521 = icmp ugt i64 %r519, 9223090561878065152
  %r522 = or i1 %r520, %r521
  %r523 = bitcast double %r48681 to i64
  %r524 = and i64 %r523, -281474976710656
  %r525 = icmp ult i64 %r524, 9221401712017801216
  %r526 = icmp ugt i64 %r524, 9223090561878065152
  %r527 = or i1 %r525, %r526
  %r528 = and i1 %r522, %r527
  br i1 %r528, label %guarded_arith.numeric.77, label %guarded_arith.dynamic.78

guarded_arith.numeric.77:                         ; preds = %shadow.root.barrier.done.76
  %r529 = fsub double %r51696, %r48681
  br label %guarded_arith.merge.79

guarded_arith.dynamic.78:                         ; preds = %shadow.root.barrier.done.76
  %statepoint_token100 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_sub, i32 2, i32 0, double %r51696, double %r48681, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated97, ptr addrspace(1) %rs4gc.s13.relocated, ptr addrspace(1) %rs4gc.s10.relocated98, ptr addrspace(1) %rs4gc.s11.relocated99) ]
  %r530101 = call double @llvm.experimental.gc.result.f64(token %statepoint_token100)
  %rs4gc.s8.relocated102 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 0, i32 0) ; (%rs4gc.s8.relocated97, %rs4gc.s8.relocated97)
  %rs4gc.s13.relocated103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 1, i32 1) ; (%rs4gc.s13.relocated, %rs4gc.s13.relocated)
  %rs4gc.s10.relocated104 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 2, i32 2) ; (%rs4gc.s10.relocated98, %rs4gc.s10.relocated98)
  %rs4gc.s11.relocated105 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 3, i32 3) ; (%rs4gc.s11.relocated99, %rs4gc.s11.relocated99)
  br label %guarded_arith.merge.79

guarded_arith.merge.79:                           ; preds = %guarded_arith.dynamic.78, %guarded_arith.numeric.77
  %.0450 = phi ptr addrspace(1) [ %rs4gc.s13.relocated, %guarded_arith.numeric.77 ], [ %rs4gc.s13.relocated103, %guarded_arith.dynamic.78 ]
  %.1442 = phi ptr addrspace(1) [ %rs4gc.s11.relocated99, %guarded_arith.numeric.77 ], [ %rs4gc.s11.relocated105, %guarded_arith.dynamic.78 ]
  %.1430 = phi ptr addrspace(1) [ %rs4gc.s10.relocated98, %guarded_arith.numeric.77 ], [ %rs4gc.s10.relocated104, %guarded_arith.dynamic.78 ]
  %.3 = phi ptr addrspace(1) [ %rs4gc.s8.relocated97, %guarded_arith.numeric.77 ], [ %rs4gc.s8.relocated102, %guarded_arith.dynamic.78 ]
  %r531 = phi double [ %r529, %guarded_arith.numeric.77 ], [ %r530101, %guarded_arith.dynamic.78 ]
  %statepoint_token106 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_process_cpu_usage, i32 1, i32 0, double 0x7FFC000000000001, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3, ptr addrspace(1) %.0450, ptr addrspace(1) %.1430, ptr addrspace(1) %.1442) ]
  %r533107 = call double @llvm.experimental.gc.result.f64(token %statepoint_token106)
  %rs4gc.s8.relocated108 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 0, i32 0) ; (%.3, %.3)
  %rs4gc.s13.relocated109 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 1, i32 1) ; (%.0450, %.0450)
  %rs4gc.s10.relocated110 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 2, i32 2) ; (%.1430, %.1430)
  %rs4gc.s11.relocated111 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token106, i32 3, i32 3) ; (%.1442, %.1442)
  %rs4gc.b14 = bitcast double %r533107 to i64
  %rs4gc.s14 = inttoptr i64 %rs4gc.b14 to ptr addrspace(1)
  %r534.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r534 = call i64 asm "", "=r,0"(i64 %r534.rs4i) #9
  %r535 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r536 = icmp ne i32 %r535, 0
  br i1 %r536, label %shadow.root.barrier.80, label %shadow.root.barrier.done.81

shadow.root.barrier.80:                           ; preds = %guarded_arith.merge.79
  call void @js_write_barrier_root_nanbox(i64 %r534) #9
  br label %shadow.root.barrier.done.81

shadow.root.barrier.done.81:                      ; preds = %shadow.root.barrier.80, %guarded_arith.merge.79
  %statepoint_token112 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated108, ptr addrspace(1) %rs4gc.s13.relocated109, ptr addrspace(1) %rs4gc.s10.relocated110, ptr addrspace(1) %rs4gc.s11.relocated111, ptr addrspace(1) %rs4gc.s14) ]
  %r537113 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token112)
  %rs4gc.s8.relocated114 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token112, i32 0, i32 0) ; (%rs4gc.s8.relocated108, %rs4gc.s8.relocated108)
  %rs4gc.s13.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token112, i32 1, i32 1) ; (%rs4gc.s13.relocated109, %rs4gc.s13.relocated109)
  %rs4gc.s10.relocated116 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token112, i32 2, i32 2) ; (%rs4gc.s10.relocated110, %rs4gc.s10.relocated110)
  %rs4gc.s11.relocated117 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token112, i32 3, i32 3) ; (%rs4gc.s11.relocated111, %rs4gc.s11.relocated111)
  %rs4gc.s14.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token112, i32 4, i32 4) ; (%rs4gc.s14, %rs4gc.s14)
  %rs4gc.s15 = inttoptr i64 %r537113 to ptr addrspace(1)
  %r538.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r538 = call i64 asm "", "=r,0"(i64 %r538.rs4i) #9
  %r539 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r540 = icmp ne i32 %r539, 0
  br i1 %r540, label %shadow.root.barrier.82, label %shadow.root.barrier.done.83

shadow.root.barrier.82:                           ; preds = %shadow.root.barrier.done.81
  call void @js_write_barrier_root_nanbox(i64 %r538) #9
  br label %shadow.root.barrier.done.83

shadow.root.barrier.done.83:                      ; preds = %shadow.root.barrier.82, %shadow.root.barrier.done.81
  %r541 = load double, ptr @short_loops_ts_.str.5.handle, align 8
  %r542.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r542 = call i64 asm "", "=r,0"(i64 %r542.rs4i) #9
  %statepoint_token118 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r542, double %r541, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated114, ptr addrspace(1) %rs4gc.s13.relocated115, ptr addrspace(1) %rs4gc.s10.relocated116, ptr addrspace(1) %rs4gc.s11.relocated117, ptr addrspace(1) %rs4gc.s14.relocated) ]
  %r543119 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token118)
  %rs4gc.s8.relocated120 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token118, i32 0, i32 0) ; (%rs4gc.s8.relocated114, %rs4gc.s8.relocated114)
  %rs4gc.s13.relocated121 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token118, i32 1, i32 1) ; (%rs4gc.s13.relocated115, %rs4gc.s13.relocated115)
  %rs4gc.s10.relocated122 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token118, i32 2, i32 2) ; (%rs4gc.s10.relocated116, %rs4gc.s10.relocated116)
  %rs4gc.s11.relocated123 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token118, i32 3, i32 3) ; (%rs4gc.s11.relocated117, %rs4gc.s11.relocated117)
  %rs4gc.s14.relocated124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token118, i32 4, i32 4) ; (%rs4gc.s14.relocated, %rs4gc.s14.relocated)
  %rs4gc.s16 = inttoptr i64 %r543119 to ptr addrspace(1)
  %r544.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r544 = call i64 asm "", "=r,0"(i64 %r544.rs4i) #9
  %r545 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r546 = icmp ne i32 %r545, 0
  br i1 %r546, label %shadow.root.barrier.84, label %shadow.root.barrier.done.85

shadow.root.barrier.84:                           ; preds = %shadow.root.barrier.done.83
  call void @js_write_barrier_root_nanbox(i64 %r544) #9
  br label %shadow.root.barrier.done.85

shadow.root.barrier.done.85:                      ; preds = %shadow.root.barrier.84, %shadow.root.barrier.done.83
  %r548.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r548 = call i64 asm "", "=r,0"(i64 %r548.rs4i) #9
  %statepoint_token125 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r548, double %r531, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated120, ptr addrspace(1) %rs4gc.s13.relocated121, ptr addrspace(1) %rs4gc.s10.relocated122, ptr addrspace(1) %rs4gc.s11.relocated123, ptr addrspace(1) %rs4gc.s14.relocated124) ]
  %r549126 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token125)
  %rs4gc.s8.relocated127 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 0, i32 0) ; (%rs4gc.s8.relocated120, %rs4gc.s8.relocated120)
  %rs4gc.s13.relocated128 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 1, i32 1) ; (%rs4gc.s13.relocated121, %rs4gc.s13.relocated121)
  %rs4gc.s10.relocated129 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 2, i32 2) ; (%rs4gc.s10.relocated122, %rs4gc.s10.relocated122)
  %rs4gc.s11.relocated130 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 3, i32 3) ; (%rs4gc.s11.relocated123, %rs4gc.s11.relocated123)
  %rs4gc.s14.relocated131 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 4, i32 4) ; (%rs4gc.s14.relocated124, %rs4gc.s14.relocated124)
  %rs4gc.s17 = inttoptr i64 %r549126 to ptr addrspace(1)
  %r550.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r550 = call i64 asm "", "=r,0"(i64 %r550.rs4i) #9
  %r551 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r552 = icmp ne i32 %r551, 0
  br i1 %r552, label %shadow.root.barrier.86, label %shadow.root.barrier.done.87

shadow.root.barrier.86:                           ; preds = %shadow.root.barrier.done.85
  call void @js_write_barrier_root_nanbox(i64 %r550) #9
  br label %shadow.root.barrier.done.87

shadow.root.barrier.done.87:                      ; preds = %shadow.root.barrier.86, %shadow.root.barrier.done.85
  %r553.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14.relocated131 to i64
  %r553.rs4o = call i64 asm "", "=r,0"(i64 %r553.rs4i) #9
  %r553 = bitcast i64 %r553.rs4o to double
  %r554 = bitcast double %r553 to i64
  %r555 = and i64 %r554, 281474976710655
  %r556 = lshr i64 %r554, 48
  %r557 = and i64 %r556, 65533
  %r558 = icmp eq i64 %r557, 32765
  br i1 %r558, label %pget.recv_ok.89, label %pget.recv_other.93

pget.recv_sso.88:                                 ; preds = %pget.recv_other.93
  %r696 = load double, ptr @short_loops_ts_.str.6.handle, align 8
  %r697 = bitcast double %r696 to i64
  %r698 = and i64 %r697, 281474976710655
  %statepoint_token132 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r554, i64 %r698, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated127, ptr addrspace(1) %rs4gc.s13.relocated128, ptr addrspace(1) %rs4gc.s10.relocated129, ptr addrspace(1) %rs4gc.s11.relocated130, ptr addrspace(1) %rs4gc.s14.relocated131, ptr addrspace(1) %rs4gc.s17) ]
  %r699133 = call double @llvm.experimental.gc.result.f64(token %statepoint_token132)
  %rs4gc.s8.relocated134 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 0, i32 0) ; (%rs4gc.s8.relocated127, %rs4gc.s8.relocated127)
  %rs4gc.s13.relocated135 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 1, i32 1) ; (%rs4gc.s13.relocated128, %rs4gc.s13.relocated128)
  %rs4gc.s10.relocated136 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 2, i32 2) ; (%rs4gc.s10.relocated129, %rs4gc.s10.relocated129)
  %rs4gc.s11.relocated137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 3, i32 3) ; (%rs4gc.s11.relocated130, %rs4gc.s11.relocated130)
  %rs4gc.s14.relocated138 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 4, i32 4) ; (%rs4gc.s14.relocated131, %rs4gc.s14.relocated131)
  %rs4gc.s17.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 5, i32 5) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pget.recv_merge.92

pget.recv_ok.89:                                  ; preds = %shadow.root.barrier.done.87
  %r565 = icmp ugt i64 %r555, 1048575
  br i1 %r565, label %pic.recv_hdr.110, label %pic.miss.cold.107

pget.recv_bad.90:                                 ; preds = %pget.check_class_ref.94
  %r688 = icmp eq i64 %r554, 9222246136947933185
  %r689 = icmp eq i64 %r554, 9222246136947933186
  %r690 = or i1 %r688, %r689
  br i1 %r690, label %pget.throw_nullish.117, label %pget.recv_undef_return.118

pget.recv_class_ref.91:                           ; preds = %pget.check_class_ref.94
  %r561 = load double, ptr @short_loops_ts_.str.6.handle, align 8
  %r562 = bitcast double %r561 to i64
  %r563 = and i64 %r562, 281474976710655
  %statepoint_token139 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 2301219111847329804, i64 %r554, i64 %r563, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated127, ptr addrspace(1) %rs4gc.s13.relocated128, ptr addrspace(1) %rs4gc.s10.relocated129, ptr addrspace(1) %rs4gc.s11.relocated130, ptr addrspace(1) %rs4gc.s14.relocated131, ptr addrspace(1) %rs4gc.s17) ]
  %r564140 = call double @llvm.experimental.gc.result.f64(token %statepoint_token139)
  %rs4gc.s8.relocated141 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 0, i32 0) ; (%rs4gc.s8.relocated127, %rs4gc.s8.relocated127)
  %rs4gc.s13.relocated142 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 1, i32 1) ; (%rs4gc.s13.relocated128, %rs4gc.s13.relocated128)
  %rs4gc.s10.relocated143 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 2, i32 2) ; (%rs4gc.s10.relocated129, %rs4gc.s10.relocated129)
  %rs4gc.s11.relocated144 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 3, i32 3) ; (%rs4gc.s11.relocated130, %rs4gc.s11.relocated130)
  %rs4gc.s14.relocated145 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 4, i32 4) ; (%rs4gc.s14.relocated131, %rs4gc.s14.relocated131)
  %rs4gc.s17.relocated146 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token139, i32 5, i32 5) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pget.recv_merge.92

pget.recv_merge.92:                               ; preds = %pget.recv_undef_return.118, %pic.merge.109, %pget.recv_class_ref.91, %pget.recv_sso.88
  %.0468 = phi ptr addrspace(1) [ %.1469, %pic.merge.109 ], [ %rs4gc.s17.relocated, %pget.recv_sso.88 ], [ %rs4gc.s17.relocated146, %pget.recv_class_ref.91 ], [ %rs4gc.s17.relocated171, %pget.recv_undef_return.118 ]
  %.0463 = phi ptr addrspace(1) [ %.1464, %pic.merge.109 ], [ %rs4gc.s14.relocated138, %pget.recv_sso.88 ], [ %rs4gc.s14.relocated145, %pget.recv_class_ref.91 ], [ %rs4gc.s14.relocated170, %pget.recv_undef_return.118 ]
  %.1451 = phi ptr addrspace(1) [ %.2452, %pic.merge.109 ], [ %rs4gc.s13.relocated135, %pget.recv_sso.88 ], [ %rs4gc.s13.relocated142, %pget.recv_class_ref.91 ], [ %rs4gc.s13.relocated167, %pget.recv_undef_return.118 ]
  %.2443 = phi ptr addrspace(1) [ %.3444, %pic.merge.109 ], [ %rs4gc.s11.relocated137, %pget.recv_sso.88 ], [ %rs4gc.s11.relocated144, %pget.recv_class_ref.91 ], [ %rs4gc.s11.relocated169, %pget.recv_undef_return.118 ]
  %.2431 = phi ptr addrspace(1) [ %.3432, %pic.merge.109 ], [ %rs4gc.s10.relocated136, %pget.recv_sso.88 ], [ %rs4gc.s10.relocated143, %pget.recv_class_ref.91 ], [ %rs4gc.s10.relocated168, %pget.recv_undef_return.118 ]
  %.4 = phi ptr addrspace(1) [ %.5, %pic.merge.109 ], [ %rs4gc.s8.relocated134, %pget.recv_sso.88 ], [ %rs4gc.s8.relocated141, %pget.recv_class_ref.91 ], [ %rs4gc.s8.relocated166, %pget.recv_undef_return.118 ]
  %r700 = phi double [ %r687, %pic.merge.109 ], [ %r695165, %pget.recv_undef_return.118 ], [ %r699133, %pget.recv_sso.88 ], [ %r564140, %pget.recv_class_ref.91 ]
  %r701 = bitcast double %r700 to i64
  %rs4gc.s18 = inttoptr i64 %r701 to ptr addrspace(1)
  %r703.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r703 = call i64 asm "", "=r,0"(i64 %r703.rs4i) #9
  %r704 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r705 = icmp ne i32 %r704, 0
  br i1 %r705, label %shadow.root.barrier.119, label %shadow.root.barrier.done.120

pget.recv_other.93:                               ; preds = %shadow.root.barrier.done.87
  %r559 = icmp eq i64 %r556, 32761
  br i1 %r559, label %pget.recv_sso.88, label %pget.check_class_ref.94

pget.check_class_ref.94:                          ; preds = %pget.recv_other.93
  %r560 = icmp eq i64 %r556, 32766
  br i1 %r560, label %pget.recv_class_ref.91, label %pget.recv_bad.90

pic.hit.95:                                       ; preds = %pic.token.111
  %r590 = getelementptr i64, ptr %r575, i64 1
  %r591 = load i64, ptr %r590, align 8
  %r592 = and i64 %r591, 1073741824
  %r593 = icmp ne i64 %r592, 0
  br i1 %r593, label %pic.hit.overflow.112, label %pic.hit.inline.113

pic.hit.live.96:                                  ; preds = %pic.hit.inline.113
  br label %pic.merge.109

pic.prefix.guard.97:                              ; preds = %pic.token.111
  %r606 = getelementptr i64, ptr %r575, i64 2
  %r607 = load i64, ptr %r606, align 8
  %r608 = icmp ne i64 %r607, 0
  br i1 %r608, label %pic.prefix.meta.98, label %pic.miss.106

pic.prefix.meta.98:                               ; preds = %pic.prefix.guard.97
  %r609 = add nuw nsw i64 %r555, 8
  %r610 = inttoptr i64 %r609 to ptr
  %r611 = load i64, ptr %r610, align 8
  %r612 = icmp ne i64 %r611, 0
  br i1 %r612, label %pic.prefix.token.99, label %pic.miss.106

pic.prefix.token.99:                              ; preds = %pic.prefix.meta.98
  %r613 = inttoptr i64 %r611 to ptr
  %r614 = getelementptr i64, ptr %r613, i64 6
  %r615 = load i64, ptr %r614, align 8
  %r616 = icmp eq i64 %r615, %r607
  br i1 %r616, label %pic.prefix.hit.100, label %pic.miss.106

pic.prefix.hit.100:                               ; preds = %pic.prefix.token.99
  %r617 = getelementptr i64, ptr %r575, i64 1
  %r618 = load i64, ptr %r617, align 8
  %r619 = shl i64 %r618, 3
  %r620 = add nuw nsw i64 %r555, 16
  %r621 = add i64 %r620, %r619
  %r622 = inttoptr i64 %r621 to ptr
  %r623 = load double, ptr %r622, align 8
  br label %pic.merge.109

pic.desc.classify.101:                            ; preds = %pic.recv_hdr.110
  %r579 = and i1 %r569, %r576
  br i1 %r579, label %pic.desc.prefix.guard.102, label %pic.miss.cold.107

pic.desc.prefix.guard.102:                        ; preds = %pic.desc.classify.101
  %r624 = getelementptr i64, ptr %r575, i64 2
  %r625 = load i64, ptr %r624, align 8
  %r626 = icmp ne i64 %r625, 0
  br i1 %r626, label %pic.desc.prefix.meta.103, label %pic.miss.cold.107

pic.desc.prefix.meta.103:                         ; preds = %pic.desc.prefix.guard.102
  %r627 = add nuw nsw i64 %r555, 8
  %r628 = inttoptr i64 %r627 to ptr
  %r629 = load i64, ptr %r628, align 8
  %r630 = icmp ne i64 %r629, 0
  br i1 %r630, label %pic.desc.prefix.token.104, label %pic.miss.cold.107

pic.desc.prefix.token.104:                        ; preds = %pic.desc.prefix.meta.103
  %r631 = inttoptr i64 %r629 to ptr
  %r632 = getelementptr i64, ptr %r631, i64 6
  %r633 = load i64, ptr %r632, align 8
  %r634 = icmp eq i64 %r633, %r625
  br i1 %r634, label %pic.desc.prefix.hit.105, label %pic.miss.cold.107

pic.desc.prefix.hit.105:                          ; preds = %pic.desc.prefix.token.104
  %r635 = getelementptr i64, ptr %r575, i64 1
  %r636 = load i64, ptr %r635, align 8
  %r637 = shl i64 %r636, 3
  %r638 = add nuw nsw i64 %r555, 16
  %r639 = add i64 %r638, %r637
  %r640 = inttoptr i64 %r639 to ptr
  %r641 = load double, ptr %r640, align 8
  br label %pic.merge.109

pic.miss.106:                                     ; preds = %pic.hit.inline.113, %pic.prefix.token.99, %pic.prefix.meta.98, %pic.prefix.guard.97
  %r642 = getelementptr i64, ptr %r575, i64 3
  %r643 = load i64, ptr %r642, align 8
  %r644 = icmp sgt i64 %r643, 0
  br i1 %r644, label %pic.ways.114, label %pic.miss.call.108

pic.miss.cold.107:                                ; preds = %pic.desc.prefix.token.104, %pic.desc.prefix.meta.103, %pic.desc.prefix.guard.102, %pic.desc.classify.101, %pget.recv_ok.89
  br label %pic.miss.call.108

pic.miss.call.108:                                ; preds = %pic.way.load.115, %pic.ways.114, %pic.miss.cold.107, %pic.miss.106
  %r683 = load double, ptr @short_loops_ts_.str.6.handle, align 8
  %r684 = bitcast double %r683 to i64
  %r685 = and i64 %r684, 281474976710655
  %statepoint_token147 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r555, i64 %r685, ptr @perry_ic_short_loops_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated127, ptr addrspace(1) %rs4gc.s13.relocated128, ptr addrspace(1) %rs4gc.s10.relocated129, ptr addrspace(1) %rs4gc.s11.relocated130, ptr addrspace(1) %rs4gc.s14.relocated131, ptr addrspace(1) %rs4gc.s17) ]
  %r686148 = call double @llvm.experimental.gc.result.f64(token %statepoint_token147)
  %rs4gc.s8.relocated149 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token147, i32 0, i32 0) ; (%rs4gc.s8.relocated127, %rs4gc.s8.relocated127)
  %rs4gc.s13.relocated150 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token147, i32 1, i32 1) ; (%rs4gc.s13.relocated128, %rs4gc.s13.relocated128)
  %rs4gc.s10.relocated151 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token147, i32 2, i32 2) ; (%rs4gc.s10.relocated129, %rs4gc.s10.relocated129)
  %rs4gc.s11.relocated152 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token147, i32 3, i32 3) ; (%rs4gc.s11.relocated130, %rs4gc.s11.relocated130)
  %rs4gc.s14.relocated153 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token147, i32 4, i32 4) ; (%rs4gc.s14.relocated131, %rs4gc.s14.relocated131)
  %rs4gc.s17.relocated154 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token147, i32 5, i32 5) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pic.merge.109

pic.merge.109:                                    ; preds = %pic.way.live.116, %pic.hit.overflow.112, %pic.miss.call.108, %pic.desc.prefix.hit.105, %pic.prefix.hit.100, %pic.hit.live.96
  %.1469 = phi ptr addrspace(1) [ %rs4gc.s17.relocated162, %pic.hit.overflow.112 ], [ %rs4gc.s17.relocated154, %pic.miss.call.108 ], [ %rs4gc.s17, %pic.way.live.116 ], [ %rs4gc.s17, %pic.hit.live.96 ], [ %rs4gc.s17, %pic.prefix.hit.100 ], [ %rs4gc.s17, %pic.desc.prefix.hit.105 ]
  %.1464 = phi ptr addrspace(1) [ %rs4gc.s14.relocated161, %pic.hit.overflow.112 ], [ %rs4gc.s14.relocated153, %pic.miss.call.108 ], [ %rs4gc.s14.relocated131, %pic.way.live.116 ], [ %rs4gc.s14.relocated131, %pic.hit.live.96 ], [ %rs4gc.s14.relocated131, %pic.prefix.hit.100 ], [ %rs4gc.s14.relocated131, %pic.desc.prefix.hit.105 ]
  %.2452 = phi ptr addrspace(1) [ %rs4gc.s13.relocated158, %pic.hit.overflow.112 ], [ %rs4gc.s13.relocated150, %pic.miss.call.108 ], [ %rs4gc.s13.relocated128, %pic.way.live.116 ], [ %rs4gc.s13.relocated128, %pic.hit.live.96 ], [ %rs4gc.s13.relocated128, %pic.prefix.hit.100 ], [ %rs4gc.s13.relocated128, %pic.desc.prefix.hit.105 ]
  %.3444 = phi ptr addrspace(1) [ %rs4gc.s11.relocated160, %pic.hit.overflow.112 ], [ %rs4gc.s11.relocated152, %pic.miss.call.108 ], [ %rs4gc.s11.relocated130, %pic.way.live.116 ], [ %rs4gc.s11.relocated130, %pic.hit.live.96 ], [ %rs4gc.s11.relocated130, %pic.prefix.hit.100 ], [ %rs4gc.s11.relocated130, %pic.desc.prefix.hit.105 ]
  %.3432 = phi ptr addrspace(1) [ %rs4gc.s10.relocated159, %pic.hit.overflow.112 ], [ %rs4gc.s10.relocated151, %pic.miss.call.108 ], [ %rs4gc.s10.relocated129, %pic.way.live.116 ], [ %rs4gc.s10.relocated129, %pic.hit.live.96 ], [ %rs4gc.s10.relocated129, %pic.prefix.hit.100 ], [ %rs4gc.s10.relocated129, %pic.desc.prefix.hit.105 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s8.relocated157, %pic.hit.overflow.112 ], [ %rs4gc.s8.relocated149, %pic.miss.call.108 ], [ %rs4gc.s8.relocated127, %pic.way.live.116 ], [ %rs4gc.s8.relocated127, %pic.hit.live.96 ], [ %rs4gc.s8.relocated127, %pic.prefix.hit.100 ], [ %rs4gc.s8.relocated127, %pic.desc.prefix.hit.105 ]
  %r687 = phi double [ %r603, %pic.hit.live.96 ], [ %r598156, %pic.hit.overflow.112 ], [ %r623, %pic.prefix.hit.100 ], [ %r641, %pic.desc.prefix.hit.105 ], [ %r680, %pic.way.live.116 ], [ %r686148, %pic.miss.call.108 ]
  br label %pget.recv_merge.92

pic.recv_hdr.110:                                 ; preds = %pget.recv_ok.89
  %r566 = sub nuw nsw i64 %r555, 8
  %r567 = inttoptr i64 %r566 to ptr
  %r568 = load i8, ptr %r567, align 1
  %r569 = icmp eq i8 %r568, 2
  %r570 = sub nuw nsw i64 %r555, 6
  %r571 = inttoptr i64 %r570 to ptr
  %r572 = load i16, ptr %r571, align 2
  %r573 = and i16 %r572, 2048
  %r574 = icmp eq i16 %r573, 0
  %r575 = load ptr, ptr @perry_ic_short_loops_ts__13, align 8
  %r576 = icmp ne ptr %r575, null
  %r577 = and i1 %r569, %r574
  %r578 = and i1 %r577, %r576
  br i1 %r578, label %pic.token.111, label %pic.desc.classify.101

pic.token.111:                                    ; preds = %pic.recv_hdr.110
  %r580 = add nuw nsw i64 %r555, 4
  %r581 = inttoptr i64 %r580 to ptr
  %r582 = load i32, ptr %r581, align 4
  %r583 = zext i32 %r582 to i64
  %r584 = or i64 %r583, 4611686018427387904
  %r585 = icmp ne i32 %r582, 0
  %r586 = getelementptr i64, ptr %r575, i64 0
  %r587 = load i64, ptr %r586, align 8
  %r588 = icmp eq i64 %r584, %r587
  %r589 = and i1 %r588, %r585
  br i1 %r589, label %pic.hit.95, label %pic.prefix.guard.97

pic.hit.overflow.112:                             ; preds = %pic.hit.95
  %r594 = load double, ptr @short_loops_ts_.str.6.handle, align 8
  %r595 = bitcast double %r594 to i64
  %r596 = and i64 %r595, 281474976710655
  %r597 = trunc i64 %r591 to i32
  %statepoint_token155 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r555, i64 %r596, i32 %r597, ptr @perry_ic_short_loops_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated127, ptr addrspace(1) %rs4gc.s13.relocated128, ptr addrspace(1) %rs4gc.s10.relocated129, ptr addrspace(1) %rs4gc.s11.relocated130, ptr addrspace(1) %rs4gc.s14.relocated131, ptr addrspace(1) %rs4gc.s17) ]
  %r598156 = call double @llvm.experimental.gc.result.f64(token %statepoint_token155)
  %rs4gc.s8.relocated157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 0, i32 0) ; (%rs4gc.s8.relocated127, %rs4gc.s8.relocated127)
  %rs4gc.s13.relocated158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 1, i32 1) ; (%rs4gc.s13.relocated128, %rs4gc.s13.relocated128)
  %rs4gc.s10.relocated159 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 2, i32 2) ; (%rs4gc.s10.relocated129, %rs4gc.s10.relocated129)
  %rs4gc.s11.relocated160 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 3, i32 3) ; (%rs4gc.s11.relocated130, %rs4gc.s11.relocated130)
  %rs4gc.s14.relocated161 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 4, i32 4) ; (%rs4gc.s14.relocated131, %rs4gc.s14.relocated131)
  %rs4gc.s17.relocated162 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 5, i32 5) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pic.merge.109

pic.hit.inline.113:                               ; preds = %pic.hit.95
  %r599 = shl i64 %r591, 3
  %r600 = add nuw nsw i64 %r555, 16
  %r601 = add i64 %r600, %r599
  %r602 = inttoptr i64 %r601 to ptr
  %r603 = load double, ptr %r602, align 8
  %r604 = bitcast double %r603 to i64
  %r605 = icmp eq i64 %r604, 9222246136947933200
  br i1 %r605, label %pic.miss.106, label %pic.hit.live.96

pic.ways.114:                                     ; preds = %pic.miss.106
  %r645 = getelementptr i64, ptr %r575, i64 4
  %r646 = load i64, ptr %r645, align 8
  %r647 = icmp eq i64 %r646, %r584
  %r648 = getelementptr i64, ptr %r575, i64 5
  %r649 = load i64, ptr %r648, align 8
  %r650 = select i1 %r647, i64 %r649, i64 0
  %r651 = getelementptr i64, ptr %r575, i64 6
  %r652 = load i64, ptr %r651, align 8
  %r653 = icmp eq i64 %r652, %r584
  %r654 = getelementptr i64, ptr %r575, i64 7
  %r655 = load i64, ptr %r654, align 8
  %r656 = select i1 %r653, i64 %r655, i64 0
  %r657 = getelementptr i64, ptr %r575, i64 8
  %r658 = load i64, ptr %r657, align 8
  %r659 = icmp eq i64 %r658, %r584
  %r660 = getelementptr i64, ptr %r575, i64 9
  %r661 = load i64, ptr %r660, align 8
  %r662 = select i1 %r659, i64 %r661, i64 0
  %r663 = getelementptr i64, ptr %r575, i64 10
  %r664 = load i64, ptr %r663, align 8
  %r665 = icmp eq i64 %r664, %r584
  %r666 = getelementptr i64, ptr %r575, i64 11
  %r667 = load i64, ptr %r666, align 8
  %r668 = select i1 %r665, i64 %r667, i64 0
  %r669 = or i1 %r647, %r653
  %r670 = select i1 %r647, i64 %r650, i64 %r656
  %r671 = or i1 %r659, %r665
  %r672 = select i1 %r659, i64 %r662, i64 %r668
  %r673 = or i1 %r669, %r671
  %r674 = select i1 %r669, i64 %r670, i64 %r672
  %r675 = and i1 %r585, %r673
  br i1 %r675, label %pic.way.load.115, label %pic.miss.call.108

pic.way.load.115:                                 ; preds = %pic.ways.114
  %r676 = shl i64 %r674, 3
  %r677 = add nuw nsw i64 %r555, 16
  %r678 = add i64 %r677, %r676
  %r679 = inttoptr i64 %r678 to ptr
  %r680 = load double, ptr %r679, align 8
  %r681 = bitcast double %r680 to i64
  %r682 = icmp eq i64 %r681, 9222246136947933200
  br i1 %r682, label %pic.miss.call.108, label %pic.way.live.116

pic.way.live.116:                                 ; preds = %pic.way.load.115
  br label %pic.merge.109

pget.throw_nullish.117:                           ; preds = %pget.recv_bad.90
  %r691 = zext i1 %r689 to i32
  %statepoint_token163 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r691, ptr @short_loops_ts_.str.6.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.118:                       ; preds = %pget.recv_bad.90
  %r692 = load double, ptr @short_loops_ts_.str.6.handle, align 8
  %r693 = bitcast double %r692 to i64
  %r694 = and i64 %r693, 281474976710655
  %statepoint_token164 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r554, i64 %r694, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated127, ptr addrspace(1) %rs4gc.s13.relocated128, ptr addrspace(1) %rs4gc.s10.relocated129, ptr addrspace(1) %rs4gc.s11.relocated130, ptr addrspace(1) %rs4gc.s14.relocated131, ptr addrspace(1) %rs4gc.s17) ]
  %r695165 = call double @llvm.experimental.gc.result.f64(token %statepoint_token164)
  %rs4gc.s8.relocated166 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token164, i32 0, i32 0) ; (%rs4gc.s8.relocated127, %rs4gc.s8.relocated127)
  %rs4gc.s13.relocated167 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token164, i32 1, i32 1) ; (%rs4gc.s13.relocated128, %rs4gc.s13.relocated128)
  %rs4gc.s10.relocated168 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token164, i32 2, i32 2) ; (%rs4gc.s10.relocated129, %rs4gc.s10.relocated129)
  %rs4gc.s11.relocated169 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token164, i32 3, i32 3) ; (%rs4gc.s11.relocated130, %rs4gc.s11.relocated130)
  %rs4gc.s14.relocated170 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token164, i32 4, i32 4) ; (%rs4gc.s14.relocated131, %rs4gc.s14.relocated131)
  %rs4gc.s17.relocated171 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token164, i32 5, i32 5) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pget.recv_merge.92

shadow.root.barrier.119:                          ; preds = %pget.recv_merge.92
  call void @js_write_barrier_root_nanbox(i64 %r703) #9
  br label %shadow.root.barrier.done.120

shadow.root.barrier.done.120:                     ; preds = %shadow.root.barrier.119, %pget.recv_merge.92
  %r706.rs4i = ptrtoint ptr addrspace(1) %.2443 to i64
  %r706.rs4o = call i64 asm "", "=r,0"(i64 %r706.rs4i) #9
  %r706 = bitcast i64 %r706.rs4o to double
  %r707 = bitcast double %r706 to i64
  %r708 = and i64 %r707, 281474976710655
  %r709 = lshr i64 %r707, 48
  %r710 = and i64 %r709, 65533
  %r711 = icmp eq i64 %r710, 32765
  br i1 %r711, label %pget.recv_ok.122, label %pget.recv_other.126

pget.recv_sso.121:                                ; preds = %pget.recv_other.126
  %r849 = load double, ptr @short_loops_ts_.str.6.handle, align 8
  %r850 = bitcast double %r849 to i64
  %r851 = and i64 %r850, 281474976710655
  %statepoint_token172 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r707, i64 %r851, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.1451, ptr addrspace(1) %.2431, ptr addrspace(1) %.2443, ptr addrspace(1) %.0463, ptr addrspace(1) %.0468, ptr addrspace(1) %rs4gc.s18) ]
  %r852173 = call double @llvm.experimental.gc.result.f64(token %statepoint_token172)
  %rs4gc.s8.relocated174 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 0, i32 0) ; (%.4, %.4)
  %rs4gc.s13.relocated175 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 1, i32 1) ; (%.1451, %.1451)
  %rs4gc.s10.relocated176 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 2, i32 2) ; (%.2431, %.2431)
  %rs4gc.s11.relocated177 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 3, i32 3) ; (%.2443, %.2443)
  %rs4gc.s14.relocated178 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 4, i32 4) ; (%.0463, %.0463)
  %rs4gc.s17.relocated179 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 5, i32 5) ; (%.0468, %.0468)
  %rs4gc.s18.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 6, i32 6) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pget.recv_merge.125

pget.recv_ok.122:                                 ; preds = %shadow.root.barrier.done.120
  %r718 = icmp ugt i64 %r708, 1048575
  br i1 %r718, label %pic.recv_hdr.143, label %pic.miss.cold.140

pget.recv_bad.123:                                ; preds = %pget.check_class_ref.127
  %r841 = icmp eq i64 %r707, 9222246136947933185
  %r842 = icmp eq i64 %r707, 9222246136947933186
  %r843 = or i1 %r841, %r842
  br i1 %r843, label %pget.throw_nullish.150, label %pget.recv_undef_return.151

pget.recv_class_ref.124:                          ; preds = %pget.check_class_ref.127
  %r714 = load double, ptr @short_loops_ts_.str.6.handle, align 8
  %r715 = bitcast double %r714 to i64
  %r716 = and i64 %r715, 281474976710655
  %statepoint_token180 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 2301219111847329806, i64 %r707, i64 %r716, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.1451, ptr addrspace(1) %.2431, ptr addrspace(1) %.2443, ptr addrspace(1) %.0463, ptr addrspace(1) %.0468, ptr addrspace(1) %rs4gc.s18) ]
  %r717181 = call double @llvm.experimental.gc.result.f64(token %statepoint_token180)
  %rs4gc.s8.relocated182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token180, i32 0, i32 0) ; (%.4, %.4)
  %rs4gc.s13.relocated183 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token180, i32 1, i32 1) ; (%.1451, %.1451)
  %rs4gc.s10.relocated184 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token180, i32 2, i32 2) ; (%.2431, %.2431)
  %rs4gc.s11.relocated185 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token180, i32 3, i32 3) ; (%.2443, %.2443)
  %rs4gc.s14.relocated186 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token180, i32 4, i32 4) ; (%.0463, %.0463)
  %rs4gc.s17.relocated187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token180, i32 5, i32 5) ; (%.0468, %.0468)
  %rs4gc.s18.relocated188 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token180, i32 6, i32 6) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pget.recv_merge.125

pget.recv_merge.125:                              ; preds = %pget.recv_undef_return.151, %pic.merge.142, %pget.recv_class_ref.124, %pget.recv_sso.121
  %.0473 = phi ptr addrspace(1) [ %.1474, %pic.merge.142 ], [ %rs4gc.s18.relocated, %pget.recv_sso.121 ], [ %rs4gc.s18.relocated188, %pget.recv_class_ref.124 ], [ %rs4gc.s18.relocated216, %pget.recv_undef_return.151 ]
  %.2470 = phi ptr addrspace(1) [ %.3471, %pic.merge.142 ], [ %rs4gc.s17.relocated179, %pget.recv_sso.121 ], [ %rs4gc.s17.relocated187, %pget.recv_class_ref.124 ], [ %rs4gc.s17.relocated215, %pget.recv_undef_return.151 ]
  %.2465 = phi ptr addrspace(1) [ %.3466, %pic.merge.142 ], [ %rs4gc.s14.relocated178, %pget.recv_sso.121 ], [ %rs4gc.s14.relocated186, %pget.recv_class_ref.124 ], [ %rs4gc.s14.relocated214, %pget.recv_undef_return.151 ]
  %.3453 = phi ptr addrspace(1) [ %.4454, %pic.merge.142 ], [ %rs4gc.s13.relocated175, %pget.recv_sso.121 ], [ %rs4gc.s13.relocated183, %pget.recv_class_ref.124 ], [ %rs4gc.s13.relocated211, %pget.recv_undef_return.151 ]
  %.4445 = phi ptr addrspace(1) [ %.5446, %pic.merge.142 ], [ %rs4gc.s11.relocated177, %pget.recv_sso.121 ], [ %rs4gc.s11.relocated185, %pget.recv_class_ref.124 ], [ %rs4gc.s11.relocated213, %pget.recv_undef_return.151 ]
  %.4433 = phi ptr addrspace(1) [ %.5434, %pic.merge.142 ], [ %rs4gc.s10.relocated176, %pget.recv_sso.121 ], [ %rs4gc.s10.relocated184, %pget.recv_class_ref.124 ], [ %rs4gc.s10.relocated212, %pget.recv_undef_return.151 ]
  %.6 = phi ptr addrspace(1) [ %.7, %pic.merge.142 ], [ %rs4gc.s8.relocated174, %pget.recv_sso.121 ], [ %rs4gc.s8.relocated182, %pget.recv_class_ref.124 ], [ %rs4gc.s8.relocated210, %pget.recv_undef_return.151 ]
  %r853 = phi double [ %r840, %pic.merge.142 ], [ %r848209, %pget.recv_undef_return.151 ], [ %r852173, %pget.recv_sso.121 ], [ %r717181, %pget.recv_class_ref.124 ]
  %r854.rs4i = ptrtoint ptr addrspace(1) %.0473 to i64
  %r854 = call i64 asm "", "=r,0"(i64 %r854.rs4i) #9
  %r855 = bitcast i64 %r854 to double
  %r856 = and i64 %r854, -281474976710656
  %r857 = icmp ult i64 %r856, 9221401712017801216
  %r858 = icmp ugt i64 %r856, 9223090561878065152
  %r859 = or i1 %r857, %r858
  %r860 = bitcast double %r853 to i64
  %r861 = and i64 %r860, -281474976710656
  %r862 = icmp ult i64 %r861, 9221401712017801216
  %r863 = icmp ugt i64 %r861, 9223090561878065152
  %r864 = or i1 %r862, %r863
  %r865 = and i1 %r859, %r864
  br i1 %r865, label %guarded_arith.numeric.152, label %guarded_arith.dynamic.153

pget.recv_other.126:                              ; preds = %shadow.root.barrier.done.120
  %r712 = icmp eq i64 %r709, 32761
  br i1 %r712, label %pget.recv_sso.121, label %pget.check_class_ref.127

pget.check_class_ref.127:                         ; preds = %pget.recv_other.126
  %r713 = icmp eq i64 %r709, 32766
  br i1 %r713, label %pget.recv_class_ref.124, label %pget.recv_bad.123

pic.hit.128:                                      ; preds = %pic.token.144
  %r743 = getelementptr i64, ptr %r728, i64 1
  %r744 = load i64, ptr %r743, align 8
  %r745 = and i64 %r744, 1073741824
  %r746 = icmp ne i64 %r745, 0
  br i1 %r746, label %pic.hit.overflow.145, label %pic.hit.inline.146

pic.hit.live.129:                                 ; preds = %pic.hit.inline.146
  br label %pic.merge.142

pic.prefix.guard.130:                             ; preds = %pic.token.144
  %r759 = getelementptr i64, ptr %r728, i64 2
  %r760 = load i64, ptr %r759, align 8
  %r761 = icmp ne i64 %r760, 0
  br i1 %r761, label %pic.prefix.meta.131, label %pic.miss.139

pic.prefix.meta.131:                              ; preds = %pic.prefix.guard.130
  %r762 = add nuw nsw i64 %r708, 8
  %r763 = inttoptr i64 %r762 to ptr
  %r764 = load i64, ptr %r763, align 8
  %r765 = icmp ne i64 %r764, 0
  br i1 %r765, label %pic.prefix.token.132, label %pic.miss.139

pic.prefix.token.132:                             ; preds = %pic.prefix.meta.131
  %r766 = inttoptr i64 %r764 to ptr
  %r767 = getelementptr i64, ptr %r766, i64 6
  %r768 = load i64, ptr %r767, align 8
  %r769 = icmp eq i64 %r768, %r760
  br i1 %r769, label %pic.prefix.hit.133, label %pic.miss.139

pic.prefix.hit.133:                               ; preds = %pic.prefix.token.132
  %r770 = getelementptr i64, ptr %r728, i64 1
  %r771 = load i64, ptr %r770, align 8
  %r772 = shl i64 %r771, 3
  %r773 = add nuw nsw i64 %r708, 16
  %r774 = add i64 %r773, %r772
  %r775 = inttoptr i64 %r774 to ptr
  %r776 = load double, ptr %r775, align 8
  br label %pic.merge.142

pic.desc.classify.134:                            ; preds = %pic.recv_hdr.143
  %r732 = and i1 %r722, %r729
  br i1 %r732, label %pic.desc.prefix.guard.135, label %pic.miss.cold.140

pic.desc.prefix.guard.135:                        ; preds = %pic.desc.classify.134
  %r777 = getelementptr i64, ptr %r728, i64 2
  %r778 = load i64, ptr %r777, align 8
  %r779 = icmp ne i64 %r778, 0
  br i1 %r779, label %pic.desc.prefix.meta.136, label %pic.miss.cold.140

pic.desc.prefix.meta.136:                         ; preds = %pic.desc.prefix.guard.135
  %r780 = add nuw nsw i64 %r708, 8
  %r781 = inttoptr i64 %r780 to ptr
  %r782 = load i64, ptr %r781, align 8
  %r783 = icmp ne i64 %r782, 0
  br i1 %r783, label %pic.desc.prefix.token.137, label %pic.miss.cold.140

pic.desc.prefix.token.137:                        ; preds = %pic.desc.prefix.meta.136
  %r784 = inttoptr i64 %r782 to ptr
  %r785 = getelementptr i64, ptr %r784, i64 6
  %r786 = load i64, ptr %r785, align 8
  %r787 = icmp eq i64 %r786, %r778
  br i1 %r787, label %pic.desc.prefix.hit.138, label %pic.miss.cold.140

pic.desc.prefix.hit.138:                          ; preds = %pic.desc.prefix.token.137
  %r788 = getelementptr i64, ptr %r728, i64 1
  %r789 = load i64, ptr %r788, align 8
  %r790 = shl i64 %r789, 3
  %r791 = add nuw nsw i64 %r708, 16
  %r792 = add i64 %r791, %r790
  %r793 = inttoptr i64 %r792 to ptr
  %r794 = load double, ptr %r793, align 8
  br label %pic.merge.142

pic.miss.139:                                     ; preds = %pic.hit.inline.146, %pic.prefix.token.132, %pic.prefix.meta.131, %pic.prefix.guard.130
  %r795 = getelementptr i64, ptr %r728, i64 3
  %r796 = load i64, ptr %r795, align 8
  %r797 = icmp sgt i64 %r796, 0
  br i1 %r797, label %pic.ways.147, label %pic.miss.call.141

pic.miss.cold.140:                                ; preds = %pic.desc.prefix.token.137, %pic.desc.prefix.meta.136, %pic.desc.prefix.guard.135, %pic.desc.classify.134, %pget.recv_ok.122
  br label %pic.miss.call.141

pic.miss.call.141:                                ; preds = %pic.way.load.148, %pic.ways.147, %pic.miss.cold.140, %pic.miss.139
  %r836 = load double, ptr @short_loops_ts_.str.6.handle, align 8
  %r837 = bitcast double %r836 to i64
  %r838 = and i64 %r837, 281474976710655
  %statepoint_token189 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r708, i64 %r838, ptr @perry_ic_short_loops_ts__15, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.1451, ptr addrspace(1) %.2431, ptr addrspace(1) %.2443, ptr addrspace(1) %.0463, ptr addrspace(1) %.0468, ptr addrspace(1) %rs4gc.s18) ]
  %r839190 = call double @llvm.experimental.gc.result.f64(token %statepoint_token189)
  %rs4gc.s8.relocated191 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 0, i32 0) ; (%.4, %.4)
  %rs4gc.s13.relocated192 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 1, i32 1) ; (%.1451, %.1451)
  %rs4gc.s10.relocated193 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 2, i32 2) ; (%.2431, %.2431)
  %rs4gc.s11.relocated194 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 3, i32 3) ; (%.2443, %.2443)
  %rs4gc.s14.relocated195 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 4, i32 4) ; (%.0463, %.0463)
  %rs4gc.s17.relocated196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 5, i32 5) ; (%.0468, %.0468)
  %rs4gc.s18.relocated197 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 6, i32 6) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pic.merge.142

pic.merge.142:                                    ; preds = %pic.way.live.149, %pic.hit.overflow.145, %pic.miss.call.141, %pic.desc.prefix.hit.138, %pic.prefix.hit.133, %pic.hit.live.129
  %.1474 = phi ptr addrspace(1) [ %rs4gc.s18.relocated206, %pic.hit.overflow.145 ], [ %rs4gc.s18.relocated197, %pic.miss.call.141 ], [ %rs4gc.s18, %pic.way.live.149 ], [ %rs4gc.s18, %pic.hit.live.129 ], [ %rs4gc.s18, %pic.prefix.hit.133 ], [ %rs4gc.s18, %pic.desc.prefix.hit.138 ]
  %.3471 = phi ptr addrspace(1) [ %rs4gc.s17.relocated205, %pic.hit.overflow.145 ], [ %rs4gc.s17.relocated196, %pic.miss.call.141 ], [ %.0468, %pic.way.live.149 ], [ %.0468, %pic.hit.live.129 ], [ %.0468, %pic.prefix.hit.133 ], [ %.0468, %pic.desc.prefix.hit.138 ]
  %.3466 = phi ptr addrspace(1) [ %rs4gc.s14.relocated204, %pic.hit.overflow.145 ], [ %rs4gc.s14.relocated195, %pic.miss.call.141 ], [ %.0463, %pic.way.live.149 ], [ %.0463, %pic.hit.live.129 ], [ %.0463, %pic.prefix.hit.133 ], [ %.0463, %pic.desc.prefix.hit.138 ]
  %.4454 = phi ptr addrspace(1) [ %rs4gc.s13.relocated201, %pic.hit.overflow.145 ], [ %rs4gc.s13.relocated192, %pic.miss.call.141 ], [ %.1451, %pic.way.live.149 ], [ %.1451, %pic.hit.live.129 ], [ %.1451, %pic.prefix.hit.133 ], [ %.1451, %pic.desc.prefix.hit.138 ]
  %.5446 = phi ptr addrspace(1) [ %rs4gc.s11.relocated203, %pic.hit.overflow.145 ], [ %rs4gc.s11.relocated194, %pic.miss.call.141 ], [ %.2443, %pic.way.live.149 ], [ %.2443, %pic.hit.live.129 ], [ %.2443, %pic.prefix.hit.133 ], [ %.2443, %pic.desc.prefix.hit.138 ]
  %.5434 = phi ptr addrspace(1) [ %rs4gc.s10.relocated202, %pic.hit.overflow.145 ], [ %rs4gc.s10.relocated193, %pic.miss.call.141 ], [ %.2431, %pic.way.live.149 ], [ %.2431, %pic.hit.live.129 ], [ %.2431, %pic.prefix.hit.133 ], [ %.2431, %pic.desc.prefix.hit.138 ]
  %.7 = phi ptr addrspace(1) [ %rs4gc.s8.relocated200, %pic.hit.overflow.145 ], [ %rs4gc.s8.relocated191, %pic.miss.call.141 ], [ %.4, %pic.way.live.149 ], [ %.4, %pic.hit.live.129 ], [ %.4, %pic.prefix.hit.133 ], [ %.4, %pic.desc.prefix.hit.138 ]
  %r840 = phi double [ %r756, %pic.hit.live.129 ], [ %r751199, %pic.hit.overflow.145 ], [ %r776, %pic.prefix.hit.133 ], [ %r794, %pic.desc.prefix.hit.138 ], [ %r833, %pic.way.live.149 ], [ %r839190, %pic.miss.call.141 ]
  br label %pget.recv_merge.125

pic.recv_hdr.143:                                 ; preds = %pget.recv_ok.122
  %r719 = sub nuw nsw i64 %r708, 8
  %r720 = inttoptr i64 %r719 to ptr
  %r721 = load i8, ptr %r720, align 1
  %r722 = icmp eq i8 %r721, 2
  %r723 = sub nuw nsw i64 %r708, 6
  %r724 = inttoptr i64 %r723 to ptr
  %r725 = load i16, ptr %r724, align 2
  %r726 = and i16 %r725, 2048
  %r727 = icmp eq i16 %r726, 0
  %r728 = load ptr, ptr @perry_ic_short_loops_ts__15, align 8
  %r729 = icmp ne ptr %r728, null
  %r730 = and i1 %r722, %r727
  %r731 = and i1 %r730, %r729
  br i1 %r731, label %pic.token.144, label %pic.desc.classify.134

pic.token.144:                                    ; preds = %pic.recv_hdr.143
  %r733 = add nuw nsw i64 %r708, 4
  %r734 = inttoptr i64 %r733 to ptr
  %r735 = load i32, ptr %r734, align 4
  %r736 = zext i32 %r735 to i64
  %r737 = or i64 %r736, 4611686018427387904
  %r738 = icmp ne i32 %r735, 0
  %r739 = getelementptr i64, ptr %r728, i64 0
  %r740 = load i64, ptr %r739, align 8
  %r741 = icmp eq i64 %r737, %r740
  %r742 = and i1 %r741, %r738
  br i1 %r742, label %pic.hit.128, label %pic.prefix.guard.130

pic.hit.overflow.145:                             ; preds = %pic.hit.128
  %r747 = load double, ptr @short_loops_ts_.str.6.handle, align 8
  %r748 = bitcast double %r747 to i64
  %r749 = and i64 %r748, 281474976710655
  %r750 = trunc i64 %r744 to i32
  %statepoint_token198 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r708, i64 %r749, i32 %r750, ptr @perry_ic_short_loops_ts__15, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.1451, ptr addrspace(1) %.2431, ptr addrspace(1) %.2443, ptr addrspace(1) %.0463, ptr addrspace(1) %.0468, ptr addrspace(1) %rs4gc.s18) ]
  %r751199 = call double @llvm.experimental.gc.result.f64(token %statepoint_token198)
  %rs4gc.s8.relocated200 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 0, i32 0) ; (%.4, %.4)
  %rs4gc.s13.relocated201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 1, i32 1) ; (%.1451, %.1451)
  %rs4gc.s10.relocated202 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 2, i32 2) ; (%.2431, %.2431)
  %rs4gc.s11.relocated203 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 3, i32 3) ; (%.2443, %.2443)
  %rs4gc.s14.relocated204 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 4, i32 4) ; (%.0463, %.0463)
  %rs4gc.s17.relocated205 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 5, i32 5) ; (%.0468, %.0468)
  %rs4gc.s18.relocated206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token198, i32 6, i32 6) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pic.merge.142

pic.hit.inline.146:                               ; preds = %pic.hit.128
  %r752 = shl i64 %r744, 3
  %r753 = add nuw nsw i64 %r708, 16
  %r754 = add i64 %r753, %r752
  %r755 = inttoptr i64 %r754 to ptr
  %r756 = load double, ptr %r755, align 8
  %r757 = bitcast double %r756 to i64
  %r758 = icmp eq i64 %r757, 9222246136947933200
  br i1 %r758, label %pic.miss.139, label %pic.hit.live.129

pic.ways.147:                                     ; preds = %pic.miss.139
  %r798 = getelementptr i64, ptr %r728, i64 4
  %r799 = load i64, ptr %r798, align 8
  %r800 = icmp eq i64 %r799, %r737
  %r801 = getelementptr i64, ptr %r728, i64 5
  %r802 = load i64, ptr %r801, align 8
  %r803 = select i1 %r800, i64 %r802, i64 0
  %r804 = getelementptr i64, ptr %r728, i64 6
  %r805 = load i64, ptr %r804, align 8
  %r806 = icmp eq i64 %r805, %r737
  %r807 = getelementptr i64, ptr %r728, i64 7
  %r808 = load i64, ptr %r807, align 8
  %r809 = select i1 %r806, i64 %r808, i64 0
  %r810 = getelementptr i64, ptr %r728, i64 8
  %r811 = load i64, ptr %r810, align 8
  %r812 = icmp eq i64 %r811, %r737
  %r813 = getelementptr i64, ptr %r728, i64 9
  %r814 = load i64, ptr %r813, align 8
  %r815 = select i1 %r812, i64 %r814, i64 0
  %r816 = getelementptr i64, ptr %r728, i64 10
  %r817 = load i64, ptr %r816, align 8
  %r818 = icmp eq i64 %r817, %r737
  %r819 = getelementptr i64, ptr %r728, i64 11
  %r820 = load i64, ptr %r819, align 8
  %r821 = select i1 %r818, i64 %r820, i64 0
  %r822 = or i1 %r800, %r806
  %r823 = select i1 %r800, i64 %r803, i64 %r809
  %r824 = or i1 %r812, %r818
  %r825 = select i1 %r812, i64 %r815, i64 %r821
  %r826 = or i1 %r822, %r824
  %r827 = select i1 %r822, i64 %r823, i64 %r825
  %r828 = and i1 %r738, %r826
  br i1 %r828, label %pic.way.load.148, label %pic.miss.call.141

pic.way.load.148:                                 ; preds = %pic.ways.147
  %r829 = shl i64 %r827, 3
  %r830 = add nuw nsw i64 %r708, 16
  %r831 = add i64 %r830, %r829
  %r832 = inttoptr i64 %r831 to ptr
  %r833 = load double, ptr %r832, align 8
  %r834 = bitcast double %r833 to i64
  %r835 = icmp eq i64 %r834, 9222246136947933200
  br i1 %r835, label %pic.miss.call.141, label %pic.way.live.149

pic.way.live.149:                                 ; preds = %pic.way.load.148
  br label %pic.merge.142

pget.throw_nullish.150:                           ; preds = %pget.recv_bad.123
  %r844 = zext i1 %r842 to i32
  %statepoint_token207 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r844, ptr @short_loops_ts_.str.6.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.151:                       ; preds = %pget.recv_bad.123
  %r845 = load double, ptr @short_loops_ts_.str.6.handle, align 8
  %r846 = bitcast double %r845 to i64
  %r847 = and i64 %r846, 281474976710655
  %statepoint_token208 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r707, i64 %r847, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.1451, ptr addrspace(1) %.2431, ptr addrspace(1) %.2443, ptr addrspace(1) %.0463, ptr addrspace(1) %.0468, ptr addrspace(1) %rs4gc.s18) ]
  %r848209 = call double @llvm.experimental.gc.result.f64(token %statepoint_token208)
  %rs4gc.s8.relocated210 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token208, i32 0, i32 0) ; (%.4, %.4)
  %rs4gc.s13.relocated211 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token208, i32 1, i32 1) ; (%.1451, %.1451)
  %rs4gc.s10.relocated212 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token208, i32 2, i32 2) ; (%.2431, %.2431)
  %rs4gc.s11.relocated213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token208, i32 3, i32 3) ; (%.2443, %.2443)
  %rs4gc.s14.relocated214 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token208, i32 4, i32 4) ; (%.0463, %.0463)
  %rs4gc.s17.relocated215 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token208, i32 5, i32 5) ; (%.0468, %.0468)
  %rs4gc.s18.relocated216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token208, i32 6, i32 6) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pget.recv_merge.125

guarded_arith.numeric.152:                        ; preds = %pget.recv_merge.125
  %r866 = fsub double %r855, %r853
  br label %guarded_arith.merge.154

guarded_arith.dynamic.153:                        ; preds = %pget.recv_merge.125
  %statepoint_token217 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_sub, i32 2, i32 0, double %r855, double %r853, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6, ptr addrspace(1) %.3453, ptr addrspace(1) %.4433, ptr addrspace(1) %.4445, ptr addrspace(1) %.2465, ptr addrspace(1) %.2470) ]
  %r867218 = call double @llvm.experimental.gc.result.f64(token %statepoint_token217)
  %rs4gc.s8.relocated219 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 0, i32 0) ; (%.6, %.6)
  %rs4gc.s13.relocated220 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 1, i32 1) ; (%.3453, %.3453)
  %rs4gc.s10.relocated221 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 2, i32 2) ; (%.4433, %.4433)
  %rs4gc.s11.relocated222 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 3, i32 3) ; (%.4445, %.4445)
  %rs4gc.s14.relocated223 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 4, i32 4) ; (%.2465, %.2465)
  %rs4gc.s17.relocated224 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token217, i32 5, i32 5) ; (%.2470, %.2470)
  br label %guarded_arith.merge.154

guarded_arith.merge.154:                          ; preds = %guarded_arith.dynamic.153, %guarded_arith.numeric.152
  %.4472 = phi ptr addrspace(1) [ %.2470, %guarded_arith.numeric.152 ], [ %rs4gc.s17.relocated224, %guarded_arith.dynamic.153 ]
  %.4467 = phi ptr addrspace(1) [ %.2465, %guarded_arith.numeric.152 ], [ %rs4gc.s14.relocated223, %guarded_arith.dynamic.153 ]
  %.5455 = phi ptr addrspace(1) [ %.3453, %guarded_arith.numeric.152 ], [ %rs4gc.s13.relocated220, %guarded_arith.dynamic.153 ]
  %.6447 = phi ptr addrspace(1) [ %.4445, %guarded_arith.numeric.152 ], [ %rs4gc.s11.relocated222, %guarded_arith.dynamic.153 ]
  %.6435 = phi ptr addrspace(1) [ %.4433, %guarded_arith.numeric.152 ], [ %rs4gc.s10.relocated221, %guarded_arith.dynamic.153 ]
  %.8 = phi ptr addrspace(1) [ %.6, %guarded_arith.numeric.152 ], [ %rs4gc.s8.relocated219, %guarded_arith.dynamic.153 ]
  %r868 = phi double [ %r866, %guarded_arith.numeric.152 ], [ %r867218, %guarded_arith.dynamic.153 ]
  %r869.rs4i = ptrtoint ptr addrspace(1) %.4472 to i64
  %r869 = call i64 asm "", "=r,0"(i64 %r869.rs4i) #9
  %statepoint_token225 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r869, double %r868, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8, ptr addrspace(1) %.5455, ptr addrspace(1) %.6435, ptr addrspace(1) %.6447, ptr addrspace(1) %.4467) ]
  %r870226 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token225)
  %rs4gc.s8.relocated227 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token225, i32 0, i32 0) ; (%.8, %.8)
  %rs4gc.s13.relocated228 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token225, i32 1, i32 1) ; (%.5455, %.5455)
  %rs4gc.s10.relocated229 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token225, i32 2, i32 2) ; (%.6435, %.6435)
  %rs4gc.s11.relocated230 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token225, i32 3, i32 3) ; (%.6447, %.6447)
  %rs4gc.s14.relocated231 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token225, i32 4, i32 4) ; (%.4467, %.4467)
  %rs4gc.s19 = inttoptr i64 %r870226 to ptr addrspace(1)
  %r871.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r871 = call i64 asm "", "=r,0"(i64 %r871.rs4i) #9
  %r872 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r873 = icmp ne i32 %r872, 0
  br i1 %r873, label %shadow.root.barrier.155, label %shadow.root.barrier.done.156

shadow.root.barrier.155:                          ; preds = %guarded_arith.merge.154
  call void @js_write_barrier_root_nanbox(i64 %r871) #9
  br label %shadow.root.barrier.done.156

shadow.root.barrier.done.156:                     ; preds = %shadow.root.barrier.155, %guarded_arith.merge.154
  %r874.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14.relocated231 to i64
  %r874.rs4o = call i64 asm "", "=r,0"(i64 %r874.rs4i) #9
  %r874 = bitcast i64 %r874.rs4o to double
  %r875 = bitcast double %r874 to i64
  %r876 = and i64 %r875, 281474976710655
  %r877 = lshr i64 %r875, 48
  %r878 = and i64 %r877, 65533
  %r879 = icmp eq i64 %r878, 32765
  br i1 %r879, label %pget.recv_ok.158, label %pget.recv_other.162

pget.recv_sso.157:                                ; preds = %pget.recv_other.162
  %r1017 = load double, ptr @short_loops_ts_.str.7.handle, align 8
  %r1018 = bitcast double %r1017 to i64
  %r1019 = and i64 %r1018, 281474976710655
  %statepoint_token232 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r875, i64 %r1019, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated227, ptr addrspace(1) %rs4gc.s13.relocated228, ptr addrspace(1) %rs4gc.s10.relocated229, ptr addrspace(1) %rs4gc.s19, ptr addrspace(1) %rs4gc.s11.relocated230) ]
  %r1020233 = call double @llvm.experimental.gc.result.f64(token %statepoint_token232)
  %rs4gc.s8.relocated234 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token232, i32 0, i32 0) ; (%rs4gc.s8.relocated227, %rs4gc.s8.relocated227)
  %rs4gc.s13.relocated235 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token232, i32 1, i32 1) ; (%rs4gc.s13.relocated228, %rs4gc.s13.relocated228)
  %rs4gc.s10.relocated236 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token232, i32 2, i32 2) ; (%rs4gc.s10.relocated229, %rs4gc.s10.relocated229)
  %rs4gc.s19.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token232, i32 3, i32 3) ; (%rs4gc.s19, %rs4gc.s19)
  %rs4gc.s11.relocated237 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token232, i32 4, i32 4) ; (%rs4gc.s11.relocated230, %rs4gc.s11.relocated230)
  br label %pget.recv_merge.161

pget.recv_ok.158:                                 ; preds = %shadow.root.barrier.done.156
  %r886 = icmp ugt i64 %r876, 1048575
  br i1 %r886, label %pic.recv_hdr.179, label %pic.miss.cold.176

pget.recv_bad.159:                                ; preds = %pget.check_class_ref.163
  %r1009 = icmp eq i64 %r875, 9222246136947933185
  %r1010 = icmp eq i64 %r875, 9222246136947933186
  %r1011 = or i1 %r1009, %r1010
  br i1 %r1011, label %pget.throw_nullish.186, label %pget.recv_undef_return.187

pget.recv_class_ref.160:                          ; preds = %pget.check_class_ref.163
  %r882 = load double, ptr @short_loops_ts_.str.7.handle, align 8
  %r883 = bitcast double %r882 to i64
  %r884 = and i64 %r883, 281474976710655
  %statepoint_token238 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 2301219111847329808, i64 %r875, i64 %r884, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated227, ptr addrspace(1) %rs4gc.s13.relocated228, ptr addrspace(1) %rs4gc.s10.relocated229, ptr addrspace(1) %rs4gc.s19, ptr addrspace(1) %rs4gc.s11.relocated230) ]
  %r885239 = call double @llvm.experimental.gc.result.f64(token %statepoint_token238)
  %rs4gc.s8.relocated240 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 0, i32 0) ; (%rs4gc.s8.relocated227, %rs4gc.s8.relocated227)
  %rs4gc.s13.relocated241 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 1, i32 1) ; (%rs4gc.s13.relocated228, %rs4gc.s13.relocated228)
  %rs4gc.s10.relocated242 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 2, i32 2) ; (%rs4gc.s10.relocated229, %rs4gc.s10.relocated229)
  %rs4gc.s19.relocated243 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 3, i32 3) ; (%rs4gc.s19, %rs4gc.s19)
  %rs4gc.s11.relocated244 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token238, i32 4, i32 4) ; (%rs4gc.s11.relocated230, %rs4gc.s11.relocated230)
  br label %pget.recv_merge.161

pget.recv_merge.161:                              ; preds = %pget.recv_undef_return.187, %pic.merge.178, %pget.recv_class_ref.160, %pget.recv_sso.157
  %.0475 = phi ptr addrspace(1) [ %.1476, %pic.merge.178 ], [ %rs4gc.s19.relocated, %pget.recv_sso.157 ], [ %rs4gc.s19.relocated243, %pget.recv_class_ref.160 ], [ %rs4gc.s19.relocated265, %pget.recv_undef_return.187 ]
  %.6456 = phi ptr addrspace(1) [ %.7457, %pic.merge.178 ], [ %rs4gc.s13.relocated235, %pget.recv_sso.157 ], [ %rs4gc.s13.relocated241, %pget.recv_class_ref.160 ], [ %rs4gc.s13.relocated263, %pget.recv_undef_return.187 ]
  %.7448 = phi ptr addrspace(1) [ %.8449, %pic.merge.178 ], [ %rs4gc.s11.relocated237, %pget.recv_sso.157 ], [ %rs4gc.s11.relocated244, %pget.recv_class_ref.160 ], [ %rs4gc.s11.relocated266, %pget.recv_undef_return.187 ]
  %.7436 = phi ptr addrspace(1) [ %.8437, %pic.merge.178 ], [ %rs4gc.s10.relocated236, %pget.recv_sso.157 ], [ %rs4gc.s10.relocated242, %pget.recv_class_ref.160 ], [ %rs4gc.s10.relocated264, %pget.recv_undef_return.187 ]
  %.9 = phi ptr addrspace(1) [ %.10, %pic.merge.178 ], [ %rs4gc.s8.relocated234, %pget.recv_sso.157 ], [ %rs4gc.s8.relocated240, %pget.recv_class_ref.160 ], [ %rs4gc.s8.relocated262, %pget.recv_undef_return.187 ]
  %r1021 = phi double [ %r1008, %pic.merge.178 ], [ %r1016261, %pget.recv_undef_return.187 ], [ %r1020233, %pget.recv_sso.157 ], [ %r885239, %pget.recv_class_ref.160 ]
  %r1022 = bitcast double %r1021 to i64
  %rs4gc.s20 = inttoptr i64 %r1022 to ptr addrspace(1)
  %r1023.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r1023 = call i64 asm "", "=r,0"(i64 %r1023.rs4i) #9
  %r1024 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1025 = icmp ne i32 %r1024, 0
  br i1 %r1025, label %shadow.root.barrier.188, label %shadow.root.barrier.done.189

pget.recv_other.162:                              ; preds = %shadow.root.barrier.done.156
  %r880 = icmp eq i64 %r877, 32761
  br i1 %r880, label %pget.recv_sso.157, label %pget.check_class_ref.163

pget.check_class_ref.163:                         ; preds = %pget.recv_other.162
  %r881 = icmp eq i64 %r877, 32766
  br i1 %r881, label %pget.recv_class_ref.160, label %pget.recv_bad.159

pic.hit.164:                                      ; preds = %pic.token.180
  %r911 = getelementptr i64, ptr %r896, i64 1
  %r912 = load i64, ptr %r911, align 8
  %r913 = and i64 %r912, 1073741824
  %r914 = icmp ne i64 %r913, 0
  br i1 %r914, label %pic.hit.overflow.181, label %pic.hit.inline.182

pic.hit.live.165:                                 ; preds = %pic.hit.inline.182
  br label %pic.merge.178

pic.prefix.guard.166:                             ; preds = %pic.token.180
  %r927 = getelementptr i64, ptr %r896, i64 2
  %r928 = load i64, ptr %r927, align 8
  %r929 = icmp ne i64 %r928, 0
  br i1 %r929, label %pic.prefix.meta.167, label %pic.miss.175

pic.prefix.meta.167:                              ; preds = %pic.prefix.guard.166
  %r930 = add nuw nsw i64 %r876, 8
  %r931 = inttoptr i64 %r930 to ptr
  %r932 = load i64, ptr %r931, align 8
  %r933 = icmp ne i64 %r932, 0
  br i1 %r933, label %pic.prefix.token.168, label %pic.miss.175

pic.prefix.token.168:                             ; preds = %pic.prefix.meta.167
  %r934 = inttoptr i64 %r932 to ptr
  %r935 = getelementptr i64, ptr %r934, i64 6
  %r936 = load i64, ptr %r935, align 8
  %r937 = icmp eq i64 %r936, %r928
  br i1 %r937, label %pic.prefix.hit.169, label %pic.miss.175

pic.prefix.hit.169:                               ; preds = %pic.prefix.token.168
  %r938 = getelementptr i64, ptr %r896, i64 1
  %r939 = load i64, ptr %r938, align 8
  %r940 = shl i64 %r939, 3
  %r941 = add nuw nsw i64 %r876, 16
  %r942 = add i64 %r941, %r940
  %r943 = inttoptr i64 %r942 to ptr
  %r944 = load double, ptr %r943, align 8
  br label %pic.merge.178

pic.desc.classify.170:                            ; preds = %pic.recv_hdr.179
  %r900 = and i1 %r890, %r897
  br i1 %r900, label %pic.desc.prefix.guard.171, label %pic.miss.cold.176

pic.desc.prefix.guard.171:                        ; preds = %pic.desc.classify.170
  %r945 = getelementptr i64, ptr %r896, i64 2
  %r946 = load i64, ptr %r945, align 8
  %r947 = icmp ne i64 %r946, 0
  br i1 %r947, label %pic.desc.prefix.meta.172, label %pic.miss.cold.176

pic.desc.prefix.meta.172:                         ; preds = %pic.desc.prefix.guard.171
  %r948 = add nuw nsw i64 %r876, 8
  %r949 = inttoptr i64 %r948 to ptr
  %r950 = load i64, ptr %r949, align 8
  %r951 = icmp ne i64 %r950, 0
  br i1 %r951, label %pic.desc.prefix.token.173, label %pic.miss.cold.176

pic.desc.prefix.token.173:                        ; preds = %pic.desc.prefix.meta.172
  %r952 = inttoptr i64 %r950 to ptr
  %r953 = getelementptr i64, ptr %r952, i64 6
  %r954 = load i64, ptr %r953, align 8
  %r955 = icmp eq i64 %r954, %r946
  br i1 %r955, label %pic.desc.prefix.hit.174, label %pic.miss.cold.176

pic.desc.prefix.hit.174:                          ; preds = %pic.desc.prefix.token.173
  %r956 = getelementptr i64, ptr %r896, i64 1
  %r957 = load i64, ptr %r956, align 8
  %r958 = shl i64 %r957, 3
  %r959 = add nuw nsw i64 %r876, 16
  %r960 = add i64 %r959, %r958
  %r961 = inttoptr i64 %r960 to ptr
  %r962 = load double, ptr %r961, align 8
  br label %pic.merge.178

pic.miss.175:                                     ; preds = %pic.hit.inline.182, %pic.prefix.token.168, %pic.prefix.meta.167, %pic.prefix.guard.166
  %r963 = getelementptr i64, ptr %r896, i64 3
  %r964 = load i64, ptr %r963, align 8
  %r965 = icmp sgt i64 %r964, 0
  br i1 %r965, label %pic.ways.183, label %pic.miss.call.177

pic.miss.cold.176:                                ; preds = %pic.desc.prefix.token.173, %pic.desc.prefix.meta.172, %pic.desc.prefix.guard.171, %pic.desc.classify.170, %pget.recv_ok.158
  br label %pic.miss.call.177

pic.miss.call.177:                                ; preds = %pic.way.load.184, %pic.ways.183, %pic.miss.cold.176, %pic.miss.175
  %r1004 = load double, ptr @short_loops_ts_.str.7.handle, align 8
  %r1005 = bitcast double %r1004 to i64
  %r1006 = and i64 %r1005, 281474976710655
  %statepoint_token245 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r876, i64 %r1006, ptr @perry_ic_short_loops_ts__17, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated227, ptr addrspace(1) %rs4gc.s13.relocated228, ptr addrspace(1) %rs4gc.s10.relocated229, ptr addrspace(1) %rs4gc.s19, ptr addrspace(1) %rs4gc.s11.relocated230) ]
  %r1007246 = call double @llvm.experimental.gc.result.f64(token %statepoint_token245)
  %rs4gc.s8.relocated247 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token245, i32 0, i32 0) ; (%rs4gc.s8.relocated227, %rs4gc.s8.relocated227)
  %rs4gc.s13.relocated248 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token245, i32 1, i32 1) ; (%rs4gc.s13.relocated228, %rs4gc.s13.relocated228)
  %rs4gc.s10.relocated249 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token245, i32 2, i32 2) ; (%rs4gc.s10.relocated229, %rs4gc.s10.relocated229)
  %rs4gc.s19.relocated250 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token245, i32 3, i32 3) ; (%rs4gc.s19, %rs4gc.s19)
  %rs4gc.s11.relocated251 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token245, i32 4, i32 4) ; (%rs4gc.s11.relocated230, %rs4gc.s11.relocated230)
  br label %pic.merge.178

pic.merge.178:                                    ; preds = %pic.way.live.185, %pic.hit.overflow.181, %pic.miss.call.177, %pic.desc.prefix.hit.174, %pic.prefix.hit.169, %pic.hit.live.165
  %.1476 = phi ptr addrspace(1) [ %rs4gc.s19.relocated257, %pic.hit.overflow.181 ], [ %rs4gc.s19.relocated250, %pic.miss.call.177 ], [ %rs4gc.s19, %pic.way.live.185 ], [ %rs4gc.s19, %pic.hit.live.165 ], [ %rs4gc.s19, %pic.prefix.hit.169 ], [ %rs4gc.s19, %pic.desc.prefix.hit.174 ]
  %.7457 = phi ptr addrspace(1) [ %rs4gc.s13.relocated255, %pic.hit.overflow.181 ], [ %rs4gc.s13.relocated248, %pic.miss.call.177 ], [ %rs4gc.s13.relocated228, %pic.way.live.185 ], [ %rs4gc.s13.relocated228, %pic.hit.live.165 ], [ %rs4gc.s13.relocated228, %pic.prefix.hit.169 ], [ %rs4gc.s13.relocated228, %pic.desc.prefix.hit.174 ]
  %.8449 = phi ptr addrspace(1) [ %rs4gc.s11.relocated258, %pic.hit.overflow.181 ], [ %rs4gc.s11.relocated251, %pic.miss.call.177 ], [ %rs4gc.s11.relocated230, %pic.way.live.185 ], [ %rs4gc.s11.relocated230, %pic.hit.live.165 ], [ %rs4gc.s11.relocated230, %pic.prefix.hit.169 ], [ %rs4gc.s11.relocated230, %pic.desc.prefix.hit.174 ]
  %.8437 = phi ptr addrspace(1) [ %rs4gc.s10.relocated256, %pic.hit.overflow.181 ], [ %rs4gc.s10.relocated249, %pic.miss.call.177 ], [ %rs4gc.s10.relocated229, %pic.way.live.185 ], [ %rs4gc.s10.relocated229, %pic.hit.live.165 ], [ %rs4gc.s10.relocated229, %pic.prefix.hit.169 ], [ %rs4gc.s10.relocated229, %pic.desc.prefix.hit.174 ]
  %.10 = phi ptr addrspace(1) [ %rs4gc.s8.relocated254, %pic.hit.overflow.181 ], [ %rs4gc.s8.relocated247, %pic.miss.call.177 ], [ %rs4gc.s8.relocated227, %pic.way.live.185 ], [ %rs4gc.s8.relocated227, %pic.hit.live.165 ], [ %rs4gc.s8.relocated227, %pic.prefix.hit.169 ], [ %rs4gc.s8.relocated227, %pic.desc.prefix.hit.174 ]
  %r1008 = phi double [ %r924, %pic.hit.live.165 ], [ %r919253, %pic.hit.overflow.181 ], [ %r944, %pic.prefix.hit.169 ], [ %r962, %pic.desc.prefix.hit.174 ], [ %r1001, %pic.way.live.185 ], [ %r1007246, %pic.miss.call.177 ]
  br label %pget.recv_merge.161

pic.recv_hdr.179:                                 ; preds = %pget.recv_ok.158
  %r887 = sub nuw nsw i64 %r876, 8
  %r888 = inttoptr i64 %r887 to ptr
  %r889 = load i8, ptr %r888, align 1
  %r890 = icmp eq i8 %r889, 2
  %r891 = sub nuw nsw i64 %r876, 6
  %r892 = inttoptr i64 %r891 to ptr
  %r893 = load i16, ptr %r892, align 2
  %r894 = and i16 %r893, 2048
  %r895 = icmp eq i16 %r894, 0
  %r896 = load ptr, ptr @perry_ic_short_loops_ts__17, align 8
  %r897 = icmp ne ptr %r896, null
  %r898 = and i1 %r890, %r895
  %r899 = and i1 %r898, %r897
  br i1 %r899, label %pic.token.180, label %pic.desc.classify.170

pic.token.180:                                    ; preds = %pic.recv_hdr.179
  %r901 = add nuw nsw i64 %r876, 4
  %r902 = inttoptr i64 %r901 to ptr
  %r903 = load i32, ptr %r902, align 4
  %r904 = zext i32 %r903 to i64
  %r905 = or i64 %r904, 4611686018427387904
  %r906 = icmp ne i32 %r903, 0
  %r907 = getelementptr i64, ptr %r896, i64 0
  %r908 = load i64, ptr %r907, align 8
  %r909 = icmp eq i64 %r905, %r908
  %r910 = and i1 %r909, %r906
  br i1 %r910, label %pic.hit.164, label %pic.prefix.guard.166

pic.hit.overflow.181:                             ; preds = %pic.hit.164
  %r915 = load double, ptr @short_loops_ts_.str.7.handle, align 8
  %r916 = bitcast double %r915 to i64
  %r917 = and i64 %r916, 281474976710655
  %r918 = trunc i64 %r912 to i32
  %statepoint_token252 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r876, i64 %r917, i32 %r918, ptr @perry_ic_short_loops_ts__17, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated227, ptr addrspace(1) %rs4gc.s13.relocated228, ptr addrspace(1) %rs4gc.s10.relocated229, ptr addrspace(1) %rs4gc.s19, ptr addrspace(1) %rs4gc.s11.relocated230) ]
  %r919253 = call double @llvm.experimental.gc.result.f64(token %statepoint_token252)
  %rs4gc.s8.relocated254 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 0, i32 0) ; (%rs4gc.s8.relocated227, %rs4gc.s8.relocated227)
  %rs4gc.s13.relocated255 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 1, i32 1) ; (%rs4gc.s13.relocated228, %rs4gc.s13.relocated228)
  %rs4gc.s10.relocated256 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 2, i32 2) ; (%rs4gc.s10.relocated229, %rs4gc.s10.relocated229)
  %rs4gc.s19.relocated257 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 3, i32 3) ; (%rs4gc.s19, %rs4gc.s19)
  %rs4gc.s11.relocated258 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 4, i32 4) ; (%rs4gc.s11.relocated230, %rs4gc.s11.relocated230)
  br label %pic.merge.178

pic.hit.inline.182:                               ; preds = %pic.hit.164
  %r920 = shl i64 %r912, 3
  %r921 = add nuw nsw i64 %r876, 16
  %r922 = add i64 %r921, %r920
  %r923 = inttoptr i64 %r922 to ptr
  %r924 = load double, ptr %r923, align 8
  %r925 = bitcast double %r924 to i64
  %r926 = icmp eq i64 %r925, 9222246136947933200
  br i1 %r926, label %pic.miss.175, label %pic.hit.live.165

pic.ways.183:                                     ; preds = %pic.miss.175
  %r966 = getelementptr i64, ptr %r896, i64 4
  %r967 = load i64, ptr %r966, align 8
  %r968 = icmp eq i64 %r967, %r905
  %r969 = getelementptr i64, ptr %r896, i64 5
  %r970 = load i64, ptr %r969, align 8
  %r971 = select i1 %r968, i64 %r970, i64 0
  %r972 = getelementptr i64, ptr %r896, i64 6
  %r973 = load i64, ptr %r972, align 8
  %r974 = icmp eq i64 %r973, %r905
  %r975 = getelementptr i64, ptr %r896, i64 7
  %r976 = load i64, ptr %r975, align 8
  %r977 = select i1 %r974, i64 %r976, i64 0
  %r978 = getelementptr i64, ptr %r896, i64 8
  %r979 = load i64, ptr %r978, align 8
  %r980 = icmp eq i64 %r979, %r905
  %r981 = getelementptr i64, ptr %r896, i64 9
  %r982 = load i64, ptr %r981, align 8
  %r983 = select i1 %r980, i64 %r982, i64 0
  %r984 = getelementptr i64, ptr %r896, i64 10
  %r985 = load i64, ptr %r984, align 8
  %r986 = icmp eq i64 %r985, %r905
  %r987 = getelementptr i64, ptr %r896, i64 11
  %r988 = load i64, ptr %r987, align 8
  %r989 = select i1 %r986, i64 %r988, i64 0
  %r990 = or i1 %r968, %r974
  %r991 = select i1 %r968, i64 %r971, i64 %r977
  %r992 = or i1 %r980, %r986
  %r993 = select i1 %r980, i64 %r983, i64 %r989
  %r994 = or i1 %r990, %r992
  %r995 = select i1 %r990, i64 %r991, i64 %r993
  %r996 = and i1 %r906, %r994
  br i1 %r996, label %pic.way.load.184, label %pic.miss.call.177

pic.way.load.184:                                 ; preds = %pic.ways.183
  %r997 = shl i64 %r995, 3
  %r998 = add nuw nsw i64 %r876, 16
  %r999 = add i64 %r998, %r997
  %r1000 = inttoptr i64 %r999 to ptr
  %r1001 = load double, ptr %r1000, align 8
  %r1002 = bitcast double %r1001 to i64
  %r1003 = icmp eq i64 %r1002, 9222246136947933200
  br i1 %r1003, label %pic.miss.call.177, label %pic.way.live.185

pic.way.live.185:                                 ; preds = %pic.way.load.184
  br label %pic.merge.178

pget.throw_nullish.186:                           ; preds = %pget.recv_bad.159
  %r1012 = zext i1 %r1010 to i32
  %statepoint_token259 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1012, ptr @short_loops_ts_.str.7.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.187:                       ; preds = %pget.recv_bad.159
  %r1013 = load double, ptr @short_loops_ts_.str.7.handle, align 8
  %r1014 = bitcast double %r1013 to i64
  %r1015 = and i64 %r1014, 281474976710655
  %statepoint_token260 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r875, i64 %r1015, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated227, ptr addrspace(1) %rs4gc.s13.relocated228, ptr addrspace(1) %rs4gc.s10.relocated229, ptr addrspace(1) %rs4gc.s19, ptr addrspace(1) %rs4gc.s11.relocated230) ]
  %r1016261 = call double @llvm.experimental.gc.result.f64(token %statepoint_token260)
  %rs4gc.s8.relocated262 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 0, i32 0) ; (%rs4gc.s8.relocated227, %rs4gc.s8.relocated227)
  %rs4gc.s13.relocated263 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 1, i32 1) ; (%rs4gc.s13.relocated228, %rs4gc.s13.relocated228)
  %rs4gc.s10.relocated264 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 2, i32 2) ; (%rs4gc.s10.relocated229, %rs4gc.s10.relocated229)
  %rs4gc.s19.relocated265 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 3, i32 3) ; (%rs4gc.s19, %rs4gc.s19)
  %rs4gc.s11.relocated266 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 4, i32 4) ; (%rs4gc.s11.relocated230, %rs4gc.s11.relocated230)
  br label %pget.recv_merge.161

shadow.root.barrier.188:                          ; preds = %pget.recv_merge.161
  call void @js_write_barrier_root_nanbox(i64 %r1023) #9
  br label %shadow.root.barrier.done.189

shadow.root.barrier.done.189:                     ; preds = %shadow.root.barrier.188, %pget.recv_merge.161
  %r1026.rs4i = ptrtoint ptr addrspace(1) %.7448 to i64
  %r1026.rs4o = call i64 asm "", "=r,0"(i64 %r1026.rs4i) #9
  %r1026 = bitcast i64 %r1026.rs4o to double
  %r1027 = bitcast double %r1026 to i64
  %r1028 = and i64 %r1027, 281474976710655
  %r1029 = lshr i64 %r1027, 48
  %r1030 = and i64 %r1029, 65533
  %r1031 = icmp eq i64 %r1030, 32765
  br i1 %r1031, label %pget.recv_ok.191, label %pget.recv_other.195

pget.recv_sso.190:                                ; preds = %pget.recv_other.195
  %r1169 = load double, ptr @short_loops_ts_.str.7.handle, align 8
  %r1170 = bitcast double %r1169 to i64
  %r1171 = and i64 %r1170, 281474976710655
  %statepoint_token267 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1027, i64 %r1171, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9, ptr addrspace(1) %.6456, ptr addrspace(1) %.7436, ptr addrspace(1) %.0475, ptr addrspace(1) %rs4gc.s20) ]
  %r1172268 = call double @llvm.experimental.gc.result.f64(token %statepoint_token267)
  %rs4gc.s8.relocated269 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 0, i32 0) ; (%.9, %.9)
  %rs4gc.s13.relocated270 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 1, i32 1) ; (%.6456, %.6456)
  %rs4gc.s10.relocated271 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 2, i32 2) ; (%.7436, %.7436)
  %rs4gc.s19.relocated272 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 3, i32 3) ; (%.0475, %.0475)
  %rs4gc.s20.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 4, i32 4) ; (%rs4gc.s20, %rs4gc.s20)
  br label %pget.recv_merge.194

pget.recv_ok.191:                                 ; preds = %shadow.root.barrier.done.189
  %r1038 = icmp ugt i64 %r1028, 1048575
  br i1 %r1038, label %pic.recv_hdr.212, label %pic.miss.cold.209

pget.recv_bad.192:                                ; preds = %pget.check_class_ref.196
  %r1161 = icmp eq i64 %r1027, 9222246136947933185
  %r1162 = icmp eq i64 %r1027, 9222246136947933186
  %r1163 = or i1 %r1161, %r1162
  br i1 %r1163, label %pget.throw_nullish.219, label %pget.recv_undef_return.220

pget.recv_class_ref.193:                          ; preds = %pget.check_class_ref.196
  %r1034 = load double, ptr @short_loops_ts_.str.7.handle, align 8
  %r1035 = bitcast double %r1034 to i64
  %r1036 = and i64 %r1035, 281474976710655
  %statepoint_token273 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 2301219111847329810, i64 %r1027, i64 %r1036, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9, ptr addrspace(1) %.6456, ptr addrspace(1) %.7436, ptr addrspace(1) %.0475, ptr addrspace(1) %rs4gc.s20) ]
  %r1037274 = call double @llvm.experimental.gc.result.f64(token %statepoint_token273)
  %rs4gc.s8.relocated275 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 0, i32 0) ; (%.9, %.9)
  %rs4gc.s13.relocated276 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 1, i32 1) ; (%.6456, %.6456)
  %rs4gc.s10.relocated277 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 2, i32 2) ; (%.7436, %.7436)
  %rs4gc.s19.relocated278 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 3, i32 3) ; (%.0475, %.0475)
  %rs4gc.s20.relocated279 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token273, i32 4, i32 4) ; (%rs4gc.s20, %rs4gc.s20)
  br label %pget.recv_merge.194

pget.recv_merge.194:                              ; preds = %pget.recv_undef_return.220, %pic.merge.211, %pget.recv_class_ref.193, %pget.recv_sso.190
  %.0480 = phi ptr addrspace(1) [ %.1481, %pic.merge.211 ], [ %rs4gc.s20.relocated, %pget.recv_sso.190 ], [ %rs4gc.s20.relocated279, %pget.recv_class_ref.193 ], [ %rs4gc.s20.relocated301, %pget.recv_undef_return.220 ]
  %.2477 = phi ptr addrspace(1) [ %.3478, %pic.merge.211 ], [ %rs4gc.s19.relocated272, %pget.recv_sso.190 ], [ %rs4gc.s19.relocated278, %pget.recv_class_ref.193 ], [ %rs4gc.s19.relocated300, %pget.recv_undef_return.220 ]
  %.8458 = phi ptr addrspace(1) [ %.9459, %pic.merge.211 ], [ %rs4gc.s13.relocated270, %pget.recv_sso.190 ], [ %rs4gc.s13.relocated276, %pget.recv_class_ref.193 ], [ %rs4gc.s13.relocated298, %pget.recv_undef_return.220 ]
  %.9438 = phi ptr addrspace(1) [ %.10439, %pic.merge.211 ], [ %rs4gc.s10.relocated271, %pget.recv_sso.190 ], [ %rs4gc.s10.relocated277, %pget.recv_class_ref.193 ], [ %rs4gc.s10.relocated299, %pget.recv_undef_return.220 ]
  %.11 = phi ptr addrspace(1) [ %.12, %pic.merge.211 ], [ %rs4gc.s8.relocated269, %pget.recv_sso.190 ], [ %rs4gc.s8.relocated275, %pget.recv_class_ref.193 ], [ %rs4gc.s8.relocated297, %pget.recv_undef_return.220 ]
  %r1173 = phi double [ %r1160, %pic.merge.211 ], [ %r1168296, %pget.recv_undef_return.220 ], [ %r1172268, %pget.recv_sso.190 ], [ %r1037274, %pget.recv_class_ref.193 ]
  %r1174.rs4i = ptrtoint ptr addrspace(1) %.0480 to i64
  %r1174 = call i64 asm "", "=r,0"(i64 %r1174.rs4i) #9
  %r1175 = bitcast i64 %r1174 to double
  %r1176 = and i64 %r1174, -281474976710656
  %r1177 = icmp ult i64 %r1176, 9221401712017801216
  %r1178 = icmp ugt i64 %r1176, 9223090561878065152
  %r1179 = or i1 %r1177, %r1178
  %r1180 = bitcast double %r1173 to i64
  %r1181 = and i64 %r1180, -281474976710656
  %r1182 = icmp ult i64 %r1181, 9221401712017801216
  %r1183 = icmp ugt i64 %r1181, 9223090561878065152
  %r1184 = or i1 %r1182, %r1183
  %r1185 = and i1 %r1179, %r1184
  br i1 %r1185, label %guarded_arith.numeric.221, label %guarded_arith.dynamic.222

pget.recv_other.195:                              ; preds = %shadow.root.barrier.done.189
  %r1032 = icmp eq i64 %r1029, 32761
  br i1 %r1032, label %pget.recv_sso.190, label %pget.check_class_ref.196

pget.check_class_ref.196:                         ; preds = %pget.recv_other.195
  %r1033 = icmp eq i64 %r1029, 32766
  br i1 %r1033, label %pget.recv_class_ref.193, label %pget.recv_bad.192

pic.hit.197:                                      ; preds = %pic.token.213
  %r1063 = getelementptr i64, ptr %r1048, i64 1
  %r1064 = load i64, ptr %r1063, align 8
  %r1065 = and i64 %r1064, 1073741824
  %r1066 = icmp ne i64 %r1065, 0
  br i1 %r1066, label %pic.hit.overflow.214, label %pic.hit.inline.215

pic.hit.live.198:                                 ; preds = %pic.hit.inline.215
  br label %pic.merge.211

pic.prefix.guard.199:                             ; preds = %pic.token.213
  %r1079 = getelementptr i64, ptr %r1048, i64 2
  %r1080 = load i64, ptr %r1079, align 8
  %r1081 = icmp ne i64 %r1080, 0
  br i1 %r1081, label %pic.prefix.meta.200, label %pic.miss.208

pic.prefix.meta.200:                              ; preds = %pic.prefix.guard.199
  %r1082 = add nuw nsw i64 %r1028, 8
  %r1083 = inttoptr i64 %r1082 to ptr
  %r1084 = load i64, ptr %r1083, align 8
  %r1085 = icmp ne i64 %r1084, 0
  br i1 %r1085, label %pic.prefix.token.201, label %pic.miss.208

pic.prefix.token.201:                             ; preds = %pic.prefix.meta.200
  %r1086 = inttoptr i64 %r1084 to ptr
  %r1087 = getelementptr i64, ptr %r1086, i64 6
  %r1088 = load i64, ptr %r1087, align 8
  %r1089 = icmp eq i64 %r1088, %r1080
  br i1 %r1089, label %pic.prefix.hit.202, label %pic.miss.208

pic.prefix.hit.202:                               ; preds = %pic.prefix.token.201
  %r1090 = getelementptr i64, ptr %r1048, i64 1
  %r1091 = load i64, ptr %r1090, align 8
  %r1092 = shl i64 %r1091, 3
  %r1093 = add nuw nsw i64 %r1028, 16
  %r1094 = add i64 %r1093, %r1092
  %r1095 = inttoptr i64 %r1094 to ptr
  %r1096 = load double, ptr %r1095, align 8
  br label %pic.merge.211

pic.desc.classify.203:                            ; preds = %pic.recv_hdr.212
  %r1052 = and i1 %r1042, %r1049
  br i1 %r1052, label %pic.desc.prefix.guard.204, label %pic.miss.cold.209

pic.desc.prefix.guard.204:                        ; preds = %pic.desc.classify.203
  %r1097 = getelementptr i64, ptr %r1048, i64 2
  %r1098 = load i64, ptr %r1097, align 8
  %r1099 = icmp ne i64 %r1098, 0
  br i1 %r1099, label %pic.desc.prefix.meta.205, label %pic.miss.cold.209

pic.desc.prefix.meta.205:                         ; preds = %pic.desc.prefix.guard.204
  %r1100 = add nuw nsw i64 %r1028, 8
  %r1101 = inttoptr i64 %r1100 to ptr
  %r1102 = load i64, ptr %r1101, align 8
  %r1103 = icmp ne i64 %r1102, 0
  br i1 %r1103, label %pic.desc.prefix.token.206, label %pic.miss.cold.209

pic.desc.prefix.token.206:                        ; preds = %pic.desc.prefix.meta.205
  %r1104 = inttoptr i64 %r1102 to ptr
  %r1105 = getelementptr i64, ptr %r1104, i64 6
  %r1106 = load i64, ptr %r1105, align 8
  %r1107 = icmp eq i64 %r1106, %r1098
  br i1 %r1107, label %pic.desc.prefix.hit.207, label %pic.miss.cold.209

pic.desc.prefix.hit.207:                          ; preds = %pic.desc.prefix.token.206
  %r1108 = getelementptr i64, ptr %r1048, i64 1
  %r1109 = load i64, ptr %r1108, align 8
  %r1110 = shl i64 %r1109, 3
  %r1111 = add nuw nsw i64 %r1028, 16
  %r1112 = add i64 %r1111, %r1110
  %r1113 = inttoptr i64 %r1112 to ptr
  %r1114 = load double, ptr %r1113, align 8
  br label %pic.merge.211

pic.miss.208:                                     ; preds = %pic.hit.inline.215, %pic.prefix.token.201, %pic.prefix.meta.200, %pic.prefix.guard.199
  %r1115 = getelementptr i64, ptr %r1048, i64 3
  %r1116 = load i64, ptr %r1115, align 8
  %r1117 = icmp sgt i64 %r1116, 0
  br i1 %r1117, label %pic.ways.216, label %pic.miss.call.210

pic.miss.cold.209:                                ; preds = %pic.desc.prefix.token.206, %pic.desc.prefix.meta.205, %pic.desc.prefix.guard.204, %pic.desc.classify.203, %pget.recv_ok.191
  br label %pic.miss.call.210

pic.miss.call.210:                                ; preds = %pic.way.load.217, %pic.ways.216, %pic.miss.cold.209, %pic.miss.208
  %r1156 = load double, ptr @short_loops_ts_.str.7.handle, align 8
  %r1157 = bitcast double %r1156 to i64
  %r1158 = and i64 %r1157, 281474976710655
  %statepoint_token280 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1028, i64 %r1158, ptr @perry_ic_short_loops_ts__19, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9, ptr addrspace(1) %.6456, ptr addrspace(1) %.7436, ptr addrspace(1) %.0475, ptr addrspace(1) %rs4gc.s20) ]
  %r1159281 = call double @llvm.experimental.gc.result.f64(token %statepoint_token280)
  %rs4gc.s8.relocated282 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token280, i32 0, i32 0) ; (%.9, %.9)
  %rs4gc.s13.relocated283 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token280, i32 1, i32 1) ; (%.6456, %.6456)
  %rs4gc.s10.relocated284 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token280, i32 2, i32 2) ; (%.7436, %.7436)
  %rs4gc.s19.relocated285 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token280, i32 3, i32 3) ; (%.0475, %.0475)
  %rs4gc.s20.relocated286 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token280, i32 4, i32 4) ; (%rs4gc.s20, %rs4gc.s20)
  br label %pic.merge.211

pic.merge.211:                                    ; preds = %pic.way.live.218, %pic.hit.overflow.214, %pic.miss.call.210, %pic.desc.prefix.hit.207, %pic.prefix.hit.202, %pic.hit.live.198
  %.1481 = phi ptr addrspace(1) [ %rs4gc.s20.relocated293, %pic.hit.overflow.214 ], [ %rs4gc.s20.relocated286, %pic.miss.call.210 ], [ %rs4gc.s20, %pic.way.live.218 ], [ %rs4gc.s20, %pic.hit.live.198 ], [ %rs4gc.s20, %pic.prefix.hit.202 ], [ %rs4gc.s20, %pic.desc.prefix.hit.207 ]
  %.3478 = phi ptr addrspace(1) [ %rs4gc.s19.relocated292, %pic.hit.overflow.214 ], [ %rs4gc.s19.relocated285, %pic.miss.call.210 ], [ %.0475, %pic.way.live.218 ], [ %.0475, %pic.hit.live.198 ], [ %.0475, %pic.prefix.hit.202 ], [ %.0475, %pic.desc.prefix.hit.207 ]
  %.9459 = phi ptr addrspace(1) [ %rs4gc.s13.relocated290, %pic.hit.overflow.214 ], [ %rs4gc.s13.relocated283, %pic.miss.call.210 ], [ %.6456, %pic.way.live.218 ], [ %.6456, %pic.hit.live.198 ], [ %.6456, %pic.prefix.hit.202 ], [ %.6456, %pic.desc.prefix.hit.207 ]
  %.10439 = phi ptr addrspace(1) [ %rs4gc.s10.relocated291, %pic.hit.overflow.214 ], [ %rs4gc.s10.relocated284, %pic.miss.call.210 ], [ %.7436, %pic.way.live.218 ], [ %.7436, %pic.hit.live.198 ], [ %.7436, %pic.prefix.hit.202 ], [ %.7436, %pic.desc.prefix.hit.207 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s8.relocated289, %pic.hit.overflow.214 ], [ %rs4gc.s8.relocated282, %pic.miss.call.210 ], [ %.9, %pic.way.live.218 ], [ %.9, %pic.hit.live.198 ], [ %.9, %pic.prefix.hit.202 ], [ %.9, %pic.desc.prefix.hit.207 ]
  %r1160 = phi double [ %r1076, %pic.hit.live.198 ], [ %r1071288, %pic.hit.overflow.214 ], [ %r1096, %pic.prefix.hit.202 ], [ %r1114, %pic.desc.prefix.hit.207 ], [ %r1153, %pic.way.live.218 ], [ %r1159281, %pic.miss.call.210 ]
  br label %pget.recv_merge.194

pic.recv_hdr.212:                                 ; preds = %pget.recv_ok.191
  %r1039 = sub nuw nsw i64 %r1028, 8
  %r1040 = inttoptr i64 %r1039 to ptr
  %r1041 = load i8, ptr %r1040, align 1
  %r1042 = icmp eq i8 %r1041, 2
  %r1043 = sub nuw nsw i64 %r1028, 6
  %r1044 = inttoptr i64 %r1043 to ptr
  %r1045 = load i16, ptr %r1044, align 2
  %r1046 = and i16 %r1045, 2048
  %r1047 = icmp eq i16 %r1046, 0
  %r1048 = load ptr, ptr @perry_ic_short_loops_ts__19, align 8
  %r1049 = icmp ne ptr %r1048, null
  %r1050 = and i1 %r1042, %r1047
  %r1051 = and i1 %r1050, %r1049
  br i1 %r1051, label %pic.token.213, label %pic.desc.classify.203

pic.token.213:                                    ; preds = %pic.recv_hdr.212
  %r1053 = add nuw nsw i64 %r1028, 4
  %r1054 = inttoptr i64 %r1053 to ptr
  %r1055 = load i32, ptr %r1054, align 4
  %r1056 = zext i32 %r1055 to i64
  %r1057 = or i64 %r1056, 4611686018427387904
  %r1058 = icmp ne i32 %r1055, 0
  %r1059 = getelementptr i64, ptr %r1048, i64 0
  %r1060 = load i64, ptr %r1059, align 8
  %r1061 = icmp eq i64 %r1057, %r1060
  %r1062 = and i1 %r1061, %r1058
  br i1 %r1062, label %pic.hit.197, label %pic.prefix.guard.199

pic.hit.overflow.214:                             ; preds = %pic.hit.197
  %r1067 = load double, ptr @short_loops_ts_.str.7.handle, align 8
  %r1068 = bitcast double %r1067 to i64
  %r1069 = and i64 %r1068, 281474976710655
  %r1070 = trunc i64 %r1064 to i32
  %statepoint_token287 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1028, i64 %r1069, i32 %r1070, ptr @perry_ic_short_loops_ts__19, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9, ptr addrspace(1) %.6456, ptr addrspace(1) %.7436, ptr addrspace(1) %.0475, ptr addrspace(1) %rs4gc.s20) ]
  %r1071288 = call double @llvm.experimental.gc.result.f64(token %statepoint_token287)
  %rs4gc.s8.relocated289 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 0, i32 0) ; (%.9, %.9)
  %rs4gc.s13.relocated290 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 1, i32 1) ; (%.6456, %.6456)
  %rs4gc.s10.relocated291 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 2, i32 2) ; (%.7436, %.7436)
  %rs4gc.s19.relocated292 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 3, i32 3) ; (%.0475, %.0475)
  %rs4gc.s20.relocated293 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token287, i32 4, i32 4) ; (%rs4gc.s20, %rs4gc.s20)
  br label %pic.merge.211

pic.hit.inline.215:                               ; preds = %pic.hit.197
  %r1072 = shl i64 %r1064, 3
  %r1073 = add nuw nsw i64 %r1028, 16
  %r1074 = add i64 %r1073, %r1072
  %r1075 = inttoptr i64 %r1074 to ptr
  %r1076 = load double, ptr %r1075, align 8
  %r1077 = bitcast double %r1076 to i64
  %r1078 = icmp eq i64 %r1077, 9222246136947933200
  br i1 %r1078, label %pic.miss.208, label %pic.hit.live.198

pic.ways.216:                                     ; preds = %pic.miss.208
  %r1118 = getelementptr i64, ptr %r1048, i64 4
  %r1119 = load i64, ptr %r1118, align 8
  %r1120 = icmp eq i64 %r1119, %r1057
  %r1121 = getelementptr i64, ptr %r1048, i64 5
  %r1122 = load i64, ptr %r1121, align 8
  %r1123 = select i1 %r1120, i64 %r1122, i64 0
  %r1124 = getelementptr i64, ptr %r1048, i64 6
  %r1125 = load i64, ptr %r1124, align 8
  %r1126 = icmp eq i64 %r1125, %r1057
  %r1127 = getelementptr i64, ptr %r1048, i64 7
  %r1128 = load i64, ptr %r1127, align 8
  %r1129 = select i1 %r1126, i64 %r1128, i64 0
  %r1130 = getelementptr i64, ptr %r1048, i64 8
  %r1131 = load i64, ptr %r1130, align 8
  %r1132 = icmp eq i64 %r1131, %r1057
  %r1133 = getelementptr i64, ptr %r1048, i64 9
  %r1134 = load i64, ptr %r1133, align 8
  %r1135 = select i1 %r1132, i64 %r1134, i64 0
  %r1136 = getelementptr i64, ptr %r1048, i64 10
  %r1137 = load i64, ptr %r1136, align 8
  %r1138 = icmp eq i64 %r1137, %r1057
  %r1139 = getelementptr i64, ptr %r1048, i64 11
  %r1140 = load i64, ptr %r1139, align 8
  %r1141 = select i1 %r1138, i64 %r1140, i64 0
  %r1142 = or i1 %r1120, %r1126
  %r1143 = select i1 %r1120, i64 %r1123, i64 %r1129
  %r1144 = or i1 %r1132, %r1138
  %r1145 = select i1 %r1132, i64 %r1135, i64 %r1141
  %r1146 = or i1 %r1142, %r1144
  %r1147 = select i1 %r1142, i64 %r1143, i64 %r1145
  %r1148 = and i1 %r1058, %r1146
  br i1 %r1148, label %pic.way.load.217, label %pic.miss.call.210

pic.way.load.217:                                 ; preds = %pic.ways.216
  %r1149 = shl i64 %r1147, 3
  %r1150 = add nuw nsw i64 %r1028, 16
  %r1151 = add i64 %r1150, %r1149
  %r1152 = inttoptr i64 %r1151 to ptr
  %r1153 = load double, ptr %r1152, align 8
  %r1154 = bitcast double %r1153 to i64
  %r1155 = icmp eq i64 %r1154, 9222246136947933200
  br i1 %r1155, label %pic.miss.call.210, label %pic.way.live.218

pic.way.live.218:                                 ; preds = %pic.way.load.217
  br label %pic.merge.211

pget.throw_nullish.219:                           ; preds = %pget.recv_bad.192
  %r1164 = zext i1 %r1162 to i32
  %statepoint_token294 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1164, ptr @short_loops_ts_.str.7.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.220:                       ; preds = %pget.recv_bad.192
  %r1165 = load double, ptr @short_loops_ts_.str.7.handle, align 8
  %r1166 = bitcast double %r1165 to i64
  %r1167 = and i64 %r1166, 281474976710655
  %statepoint_token295 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1027, i64 %r1167, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9, ptr addrspace(1) %.6456, ptr addrspace(1) %.7436, ptr addrspace(1) %.0475, ptr addrspace(1) %rs4gc.s20) ]
  %r1168296 = call double @llvm.experimental.gc.result.f64(token %statepoint_token295)
  %rs4gc.s8.relocated297 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token295, i32 0, i32 0) ; (%.9, %.9)
  %rs4gc.s13.relocated298 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token295, i32 1, i32 1) ; (%.6456, %.6456)
  %rs4gc.s10.relocated299 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token295, i32 2, i32 2) ; (%.7436, %.7436)
  %rs4gc.s19.relocated300 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token295, i32 3, i32 3) ; (%.0475, %.0475)
  %rs4gc.s20.relocated301 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token295, i32 4, i32 4) ; (%rs4gc.s20, %rs4gc.s20)
  br label %pget.recv_merge.194

guarded_arith.numeric.221:                        ; preds = %pget.recv_merge.194
  %r1186 = fsub double %r1175, %r1173
  br label %guarded_arith.merge.223

guarded_arith.dynamic.222:                        ; preds = %pget.recv_merge.194
  %statepoint_token302 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_sub, i32 2, i32 0, double %r1175, double %r1173, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11, ptr addrspace(1) %.8458, ptr addrspace(1) %.9438, ptr addrspace(1) %.2477) ]
  %r1187303 = call double @llvm.experimental.gc.result.f64(token %statepoint_token302)
  %rs4gc.s8.relocated304 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token302, i32 0, i32 0) ; (%.11, %.11)
  %rs4gc.s13.relocated305 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token302, i32 1, i32 1) ; (%.8458, %.8458)
  %rs4gc.s10.relocated306 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token302, i32 2, i32 2) ; (%.9438, %.9438)
  %rs4gc.s19.relocated307 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token302, i32 3, i32 3) ; (%.2477, %.2477)
  br label %guarded_arith.merge.223

guarded_arith.merge.223:                          ; preds = %guarded_arith.dynamic.222, %guarded_arith.numeric.221
  %.4479 = phi ptr addrspace(1) [ %.2477, %guarded_arith.numeric.221 ], [ %rs4gc.s19.relocated307, %guarded_arith.dynamic.222 ]
  %.10460 = phi ptr addrspace(1) [ %.8458, %guarded_arith.numeric.221 ], [ %rs4gc.s13.relocated305, %guarded_arith.dynamic.222 ]
  %.11440 = phi ptr addrspace(1) [ %.9438, %guarded_arith.numeric.221 ], [ %rs4gc.s10.relocated306, %guarded_arith.dynamic.222 ]
  %.13 = phi ptr addrspace(1) [ %.11, %guarded_arith.numeric.221 ], [ %rs4gc.s8.relocated304, %guarded_arith.dynamic.222 ]
  %r1188 = phi double [ %r1186, %guarded_arith.numeric.221 ], [ %r1187303, %guarded_arith.dynamic.222 ]
  %r1189.rs4i = ptrtoint ptr addrspace(1) %.4479 to i64
  %r1189 = call i64 asm "", "=r,0"(i64 %r1189.rs4i) #9
  %statepoint_token308 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1189, double %r1188, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13, ptr addrspace(1) %.10460, ptr addrspace(1) %.11440) ]
  %r1190309 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token308)
  %rs4gc.s8.relocated310 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token308, i32 0, i32 0) ; (%.13, %.13)
  %rs4gc.s13.relocated311 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token308, i32 1, i32 1) ; (%.10460, %.10460)
  %rs4gc.s10.relocated312 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token308, i32 2, i32 2) ; (%.11440, %.11440)
  %rs4gc.s21 = inttoptr i64 %r1190309 to ptr addrspace(1)
  %r1191.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r1191 = call i64 asm "", "=r,0"(i64 %r1191.rs4i) #9
  %r1192 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1193 = icmp ne i32 %r1192, 0
  br i1 %r1193, label %shadow.root.barrier.224, label %shadow.root.barrier.done.225

shadow.root.barrier.224:                          ; preds = %guarded_arith.merge.223
  call void @js_write_barrier_root_nanbox(i64 %r1191) #9
  br label %shadow.root.barrier.done.225

shadow.root.barrier.done.225:                     ; preds = %shadow.root.barrier.224, %guarded_arith.merge.223
  %r1194.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10.relocated312 to i64
  %r1194.rs4o = call i64 asm "", "=r,0"(i64 %r1194.rs4i) #9
  %r1194 = bitcast i64 %r1194.rs4o to double
  %r1195.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r1195 = call i64 asm "", "=r,0"(i64 %r1195.rs4i) #9
  %statepoint_token313 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1195, double %r1194, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated310, ptr addrspace(1) %rs4gc.s13.relocated311) ]
  %r1196314 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token313)
  %rs4gc.s8.relocated315 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token313, i32 0, i32 0) ; (%rs4gc.s8.relocated310, %rs4gc.s8.relocated310)
  %rs4gc.s13.relocated316 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token313, i32 1, i32 1) ; (%rs4gc.s13.relocated311, %rs4gc.s13.relocated311)
  %rs4gc.s22 = inttoptr i64 %r1196314 to ptr addrspace(1)
  %r1197.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r1197 = call i64 asm "", "=r,0"(i64 %r1197.rs4i) #9
  %r1198 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1199 = icmp ne i32 %r1198, 0
  br i1 %r1199, label %shadow.root.barrier.226, label %shadow.root.barrier.done.227

shadow.root.barrier.226:                          ; preds = %shadow.root.barrier.done.225
  call void @js_write_barrier_root_nanbox(i64 %r1197) #9
  br label %shadow.root.barrier.done.227

shadow.root.barrier.done.227:                     ; preds = %shadow.root.barrier.226, %shadow.root.barrier.done.225
  %statepoint_token317 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_process_memory_usage, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated315, ptr addrspace(1) %rs4gc.s13.relocated316, ptr addrspace(1) %rs4gc.s22) ]
  %r1200318 = call double @llvm.experimental.gc.result.f64(token %statepoint_token317)
  %rs4gc.s8.relocated319 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 0, i32 0) ; (%rs4gc.s8.relocated315, %rs4gc.s8.relocated315)
  %rs4gc.s13.relocated320 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 1, i32 1) ; (%rs4gc.s13.relocated316, %rs4gc.s13.relocated316)
  %rs4gc.s22.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 2, i32 2) ; (%rs4gc.s22, %rs4gc.s22)
  %r1201 = bitcast double %r1200318 to i64
  %r1202 = and i64 %r1201, 281474976710655
  %r1203 = lshr i64 %r1201, 48
  %r1204 = and i64 %r1203, 65533
  %r1205 = icmp eq i64 %r1204, 32765
  br i1 %r1205, label %pget.recv_ok.229, label %pget.recv_other.233

pget.recv_sso.228:                                ; preds = %pget.recv_other.233
  %r1343 = load double, ptr @short_loops_ts_.str.4.handle, align 8
  %r1344 = bitcast double %r1343 to i64
  %r1345 = and i64 %r1344, 281474976710655
  %statepoint_token321 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1201, i64 %r1345, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated319, ptr addrspace(1) %rs4gc.s13.relocated320, ptr addrspace(1) %rs4gc.s22.relocated) ]
  %r1346322 = call double @llvm.experimental.gc.result.f64(token %statepoint_token321)
  %rs4gc.s8.relocated323 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token321, i32 0, i32 0) ; (%rs4gc.s8.relocated319, %rs4gc.s8.relocated319)
  %rs4gc.s13.relocated324 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token321, i32 1, i32 1) ; (%rs4gc.s13.relocated320, %rs4gc.s13.relocated320)
  %rs4gc.s22.relocated325 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token321, i32 2, i32 2) ; (%rs4gc.s22.relocated, %rs4gc.s22.relocated)
  br label %pget.recv_merge.232

pget.recv_ok.229:                                 ; preds = %shadow.root.barrier.done.227
  %r1212 = icmp ugt i64 %r1202, 1048575
  br i1 %r1212, label %pic.recv_hdr.250, label %pic.miss.cold.247

pget.recv_bad.230:                                ; preds = %pget.check_class_ref.234
  %r1335 = icmp eq i64 %r1201, 9222246136947933185
  %r1336 = icmp eq i64 %r1201, 9222246136947933186
  %r1337 = or i1 %r1335, %r1336
  br i1 %r1337, label %pget.throw_nullish.257, label %pget.recv_undef_return.258

pget.recv_class_ref.231:                          ; preds = %pget.check_class_ref.234
  %r1208 = load double, ptr @short_loops_ts_.str.4.handle, align 8
  %r1209 = bitcast double %r1208 to i64
  %r1210 = and i64 %r1209, 281474976710655
  %statepoint_token326 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 2301219111847329812, i64 %r1201, i64 %r1210, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated319, ptr addrspace(1) %rs4gc.s13.relocated320, ptr addrspace(1) %rs4gc.s22.relocated) ]
  %r1211327 = call double @llvm.experimental.gc.result.f64(token %statepoint_token326)
  %rs4gc.s8.relocated328 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 0, i32 0) ; (%rs4gc.s8.relocated319, %rs4gc.s8.relocated319)
  %rs4gc.s13.relocated329 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 1, i32 1) ; (%rs4gc.s13.relocated320, %rs4gc.s13.relocated320)
  %rs4gc.s22.relocated330 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token326, i32 2, i32 2) ; (%rs4gc.s22.relocated, %rs4gc.s22.relocated)
  br label %pget.recv_merge.232

pget.recv_merge.232:                              ; preds = %pget.recv_undef_return.258, %pic.merge.249, %pget.recv_class_ref.231, %pget.recv_sso.228
  %.0482 = phi ptr addrspace(1) [ %.1483, %pic.merge.249 ], [ %rs4gc.s22.relocated325, %pget.recv_sso.228 ], [ %rs4gc.s22.relocated330, %pget.recv_class_ref.231 ], [ %rs4gc.s22.relocated350, %pget.recv_undef_return.258 ]
  %.11461 = phi ptr addrspace(1) [ %.12462, %pic.merge.249 ], [ %rs4gc.s13.relocated324, %pget.recv_sso.228 ], [ %rs4gc.s13.relocated329, %pget.recv_class_ref.231 ], [ %rs4gc.s13.relocated349, %pget.recv_undef_return.258 ]
  %.14 = phi ptr addrspace(1) [ %.15, %pic.merge.249 ], [ %rs4gc.s8.relocated323, %pget.recv_sso.228 ], [ %rs4gc.s8.relocated328, %pget.recv_class_ref.231 ], [ %rs4gc.s8.relocated348, %pget.recv_undef_return.258 ]
  %r1347 = phi double [ %r1334, %pic.merge.249 ], [ %r1342347, %pget.recv_undef_return.258 ], [ %r1346322, %pget.recv_sso.228 ], [ %r1211327, %pget.recv_class_ref.231 ]
  %r1348.rs4i = ptrtoint ptr addrspace(1) %.0482 to i64
  %r1348 = call i64 asm "", "=r,0"(i64 %r1348.rs4i) #9
  %statepoint_token331 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1348, double %r1347, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.14, ptr addrspace(1) %.11461) ]
  %r1349332 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token331)
  %rs4gc.s8.relocated333 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token331, i32 0, i32 0) ; (%.14, %.14)
  %rs4gc.s13.relocated334 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token331, i32 1, i32 1) ; (%.11461, %.11461)
  %rs4gc.s23 = inttoptr i64 %r1349332 to ptr addrspace(1)
  %r1350.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r1350 = call i64 asm "", "=r,0"(i64 %r1350.rs4i) #9
  %r1351 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1352 = icmp ne i32 %r1351, 0
  br i1 %r1352, label %shadow.root.barrier.259, label %shadow.root.barrier.done.260

pget.recv_other.233:                              ; preds = %shadow.root.barrier.done.227
  %r1206 = icmp eq i64 %r1203, 32761
  br i1 %r1206, label %pget.recv_sso.228, label %pget.check_class_ref.234

pget.check_class_ref.234:                         ; preds = %pget.recv_other.233
  %r1207 = icmp eq i64 %r1203, 32766
  br i1 %r1207, label %pget.recv_class_ref.231, label %pget.recv_bad.230

pic.hit.235:                                      ; preds = %pic.token.251
  %r1237 = getelementptr i64, ptr %r1222, i64 1
  %r1238 = load i64, ptr %r1237, align 8
  %r1239 = and i64 %r1238, 1073741824
  %r1240 = icmp ne i64 %r1239, 0
  br i1 %r1240, label %pic.hit.overflow.252, label %pic.hit.inline.253

pic.hit.live.236:                                 ; preds = %pic.hit.inline.253
  br label %pic.merge.249

pic.prefix.guard.237:                             ; preds = %pic.token.251
  %r1253 = getelementptr i64, ptr %r1222, i64 2
  %r1254 = load i64, ptr %r1253, align 8
  %r1255 = icmp ne i64 %r1254, 0
  br i1 %r1255, label %pic.prefix.meta.238, label %pic.miss.246

pic.prefix.meta.238:                              ; preds = %pic.prefix.guard.237
  %r1256 = add nuw nsw i64 %r1202, 8
  %r1257 = inttoptr i64 %r1256 to ptr
  %r1258 = load i64, ptr %r1257, align 8
  %r1259 = icmp ne i64 %r1258, 0
  br i1 %r1259, label %pic.prefix.token.239, label %pic.miss.246

pic.prefix.token.239:                             ; preds = %pic.prefix.meta.238
  %r1260 = inttoptr i64 %r1258 to ptr
  %r1261 = getelementptr i64, ptr %r1260, i64 6
  %r1262 = load i64, ptr %r1261, align 8
  %r1263 = icmp eq i64 %r1262, %r1254
  br i1 %r1263, label %pic.prefix.hit.240, label %pic.miss.246

pic.prefix.hit.240:                               ; preds = %pic.prefix.token.239
  %r1264 = getelementptr i64, ptr %r1222, i64 1
  %r1265 = load i64, ptr %r1264, align 8
  %r1266 = shl i64 %r1265, 3
  %r1267 = add nuw nsw i64 %r1202, 16
  %r1268 = add i64 %r1267, %r1266
  %r1269 = inttoptr i64 %r1268 to ptr
  %r1270 = load double, ptr %r1269, align 8
  br label %pic.merge.249

pic.desc.classify.241:                            ; preds = %pic.recv_hdr.250
  %r1226 = and i1 %r1216, %r1223
  br i1 %r1226, label %pic.desc.prefix.guard.242, label %pic.miss.cold.247

pic.desc.prefix.guard.242:                        ; preds = %pic.desc.classify.241
  %r1271 = getelementptr i64, ptr %r1222, i64 2
  %r1272 = load i64, ptr %r1271, align 8
  %r1273 = icmp ne i64 %r1272, 0
  br i1 %r1273, label %pic.desc.prefix.meta.243, label %pic.miss.cold.247

pic.desc.prefix.meta.243:                         ; preds = %pic.desc.prefix.guard.242
  %r1274 = add nuw nsw i64 %r1202, 8
  %r1275 = inttoptr i64 %r1274 to ptr
  %r1276 = load i64, ptr %r1275, align 8
  %r1277 = icmp ne i64 %r1276, 0
  br i1 %r1277, label %pic.desc.prefix.token.244, label %pic.miss.cold.247

pic.desc.prefix.token.244:                        ; preds = %pic.desc.prefix.meta.243
  %r1278 = inttoptr i64 %r1276 to ptr
  %r1279 = getelementptr i64, ptr %r1278, i64 6
  %r1280 = load i64, ptr %r1279, align 8
  %r1281 = icmp eq i64 %r1280, %r1272
  br i1 %r1281, label %pic.desc.prefix.hit.245, label %pic.miss.cold.247

pic.desc.prefix.hit.245:                          ; preds = %pic.desc.prefix.token.244
  %r1282 = getelementptr i64, ptr %r1222, i64 1
  %r1283 = load i64, ptr %r1282, align 8
  %r1284 = shl i64 %r1283, 3
  %r1285 = add nuw nsw i64 %r1202, 16
  %r1286 = add i64 %r1285, %r1284
  %r1287 = inttoptr i64 %r1286 to ptr
  %r1288 = load double, ptr %r1287, align 8
  br label %pic.merge.249

pic.miss.246:                                     ; preds = %pic.hit.inline.253, %pic.prefix.token.239, %pic.prefix.meta.238, %pic.prefix.guard.237
  %r1289 = getelementptr i64, ptr %r1222, i64 3
  %r1290 = load i64, ptr %r1289, align 8
  %r1291 = icmp sgt i64 %r1290, 0
  br i1 %r1291, label %pic.ways.254, label %pic.miss.call.248

pic.miss.cold.247:                                ; preds = %pic.desc.prefix.token.244, %pic.desc.prefix.meta.243, %pic.desc.prefix.guard.242, %pic.desc.classify.241, %pget.recv_ok.229
  br label %pic.miss.call.248

pic.miss.call.248:                                ; preds = %pic.way.load.255, %pic.ways.254, %pic.miss.cold.247, %pic.miss.246
  %r1330 = load double, ptr @short_loops_ts_.str.4.handle, align 8
  %r1331 = bitcast double %r1330 to i64
  %r1332 = and i64 %r1331, 281474976710655
  %statepoint_token335 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1202, i64 %r1332, ptr @perry_ic_short_loops_ts__21, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated319, ptr addrspace(1) %rs4gc.s13.relocated320, ptr addrspace(1) %rs4gc.s22.relocated) ]
  %r1333336 = call double @llvm.experimental.gc.result.f64(token %statepoint_token335)
  %rs4gc.s8.relocated337 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token335, i32 0, i32 0) ; (%rs4gc.s8.relocated319, %rs4gc.s8.relocated319)
  %rs4gc.s13.relocated338 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token335, i32 1, i32 1) ; (%rs4gc.s13.relocated320, %rs4gc.s13.relocated320)
  %rs4gc.s22.relocated339 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token335, i32 2, i32 2) ; (%rs4gc.s22.relocated, %rs4gc.s22.relocated)
  br label %pic.merge.249

pic.merge.249:                                    ; preds = %pic.way.live.256, %pic.hit.overflow.252, %pic.miss.call.248, %pic.desc.prefix.hit.245, %pic.prefix.hit.240, %pic.hit.live.236
  %.1483 = phi ptr addrspace(1) [ %rs4gc.s22.relocated344, %pic.hit.overflow.252 ], [ %rs4gc.s22.relocated339, %pic.miss.call.248 ], [ %rs4gc.s22.relocated, %pic.way.live.256 ], [ %rs4gc.s22.relocated, %pic.hit.live.236 ], [ %rs4gc.s22.relocated, %pic.prefix.hit.240 ], [ %rs4gc.s22.relocated, %pic.desc.prefix.hit.245 ]
  %.12462 = phi ptr addrspace(1) [ %rs4gc.s13.relocated343, %pic.hit.overflow.252 ], [ %rs4gc.s13.relocated338, %pic.miss.call.248 ], [ %rs4gc.s13.relocated320, %pic.way.live.256 ], [ %rs4gc.s13.relocated320, %pic.hit.live.236 ], [ %rs4gc.s13.relocated320, %pic.prefix.hit.240 ], [ %rs4gc.s13.relocated320, %pic.desc.prefix.hit.245 ]
  %.15 = phi ptr addrspace(1) [ %rs4gc.s8.relocated342, %pic.hit.overflow.252 ], [ %rs4gc.s8.relocated337, %pic.miss.call.248 ], [ %rs4gc.s8.relocated319, %pic.way.live.256 ], [ %rs4gc.s8.relocated319, %pic.hit.live.236 ], [ %rs4gc.s8.relocated319, %pic.prefix.hit.240 ], [ %rs4gc.s8.relocated319, %pic.desc.prefix.hit.245 ]
  %r1334 = phi double [ %r1250, %pic.hit.live.236 ], [ %r1245341, %pic.hit.overflow.252 ], [ %r1270, %pic.prefix.hit.240 ], [ %r1288, %pic.desc.prefix.hit.245 ], [ %r1327, %pic.way.live.256 ], [ %r1333336, %pic.miss.call.248 ]
  br label %pget.recv_merge.232

pic.recv_hdr.250:                                 ; preds = %pget.recv_ok.229
  %r1213 = sub nuw nsw i64 %r1202, 8
  %r1214 = inttoptr i64 %r1213 to ptr
  %r1215 = load i8, ptr %r1214, align 1
  %r1216 = icmp eq i8 %r1215, 2
  %r1217 = sub nuw nsw i64 %r1202, 6
  %r1218 = inttoptr i64 %r1217 to ptr
  %r1219 = load i16, ptr %r1218, align 2
  %r1220 = and i16 %r1219, 2048
  %r1221 = icmp eq i16 %r1220, 0
  %r1222 = load ptr, ptr @perry_ic_short_loops_ts__21, align 8
  %r1223 = icmp ne ptr %r1222, null
  %r1224 = and i1 %r1216, %r1221
  %r1225 = and i1 %r1224, %r1223
  br i1 %r1225, label %pic.token.251, label %pic.desc.classify.241

pic.token.251:                                    ; preds = %pic.recv_hdr.250
  %r1227 = add nuw nsw i64 %r1202, 4
  %r1228 = inttoptr i64 %r1227 to ptr
  %r1229 = load i32, ptr %r1228, align 4
  %r1230 = zext i32 %r1229 to i64
  %r1231 = or i64 %r1230, 4611686018427387904
  %r1232 = icmp ne i32 %r1229, 0
  %r1233 = getelementptr i64, ptr %r1222, i64 0
  %r1234 = load i64, ptr %r1233, align 8
  %r1235 = icmp eq i64 %r1231, %r1234
  %r1236 = and i1 %r1235, %r1232
  br i1 %r1236, label %pic.hit.235, label %pic.prefix.guard.237

pic.hit.overflow.252:                             ; preds = %pic.hit.235
  %r1241 = load double, ptr @short_loops_ts_.str.4.handle, align 8
  %r1242 = bitcast double %r1241 to i64
  %r1243 = and i64 %r1242, 281474976710655
  %r1244 = trunc i64 %r1238 to i32
  %statepoint_token340 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1202, i64 %r1243, i32 %r1244, ptr @perry_ic_short_loops_ts__21, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated319, ptr addrspace(1) %rs4gc.s13.relocated320, ptr addrspace(1) %rs4gc.s22.relocated) ]
  %r1245341 = call double @llvm.experimental.gc.result.f64(token %statepoint_token340)
  %rs4gc.s8.relocated342 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token340, i32 0, i32 0) ; (%rs4gc.s8.relocated319, %rs4gc.s8.relocated319)
  %rs4gc.s13.relocated343 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token340, i32 1, i32 1) ; (%rs4gc.s13.relocated320, %rs4gc.s13.relocated320)
  %rs4gc.s22.relocated344 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token340, i32 2, i32 2) ; (%rs4gc.s22.relocated, %rs4gc.s22.relocated)
  br label %pic.merge.249

pic.hit.inline.253:                               ; preds = %pic.hit.235
  %r1246 = shl i64 %r1238, 3
  %r1247 = add nuw nsw i64 %r1202, 16
  %r1248 = add i64 %r1247, %r1246
  %r1249 = inttoptr i64 %r1248 to ptr
  %r1250 = load double, ptr %r1249, align 8
  %r1251 = bitcast double %r1250 to i64
  %r1252 = icmp eq i64 %r1251, 9222246136947933200
  br i1 %r1252, label %pic.miss.246, label %pic.hit.live.236

pic.ways.254:                                     ; preds = %pic.miss.246
  %r1292 = getelementptr i64, ptr %r1222, i64 4
  %r1293 = load i64, ptr %r1292, align 8
  %r1294 = icmp eq i64 %r1293, %r1231
  %r1295 = getelementptr i64, ptr %r1222, i64 5
  %r1296 = load i64, ptr %r1295, align 8
  %r1297 = select i1 %r1294, i64 %r1296, i64 0
  %r1298 = getelementptr i64, ptr %r1222, i64 6
  %r1299 = load i64, ptr %r1298, align 8
  %r1300 = icmp eq i64 %r1299, %r1231
  %r1301 = getelementptr i64, ptr %r1222, i64 7
  %r1302 = load i64, ptr %r1301, align 8
  %r1303 = select i1 %r1300, i64 %r1302, i64 0
  %r1304 = getelementptr i64, ptr %r1222, i64 8
  %r1305 = load i64, ptr %r1304, align 8
  %r1306 = icmp eq i64 %r1305, %r1231
  %r1307 = getelementptr i64, ptr %r1222, i64 9
  %r1308 = load i64, ptr %r1307, align 8
  %r1309 = select i1 %r1306, i64 %r1308, i64 0
  %r1310 = getelementptr i64, ptr %r1222, i64 10
  %r1311 = load i64, ptr %r1310, align 8
  %r1312 = icmp eq i64 %r1311, %r1231
  %r1313 = getelementptr i64, ptr %r1222, i64 11
  %r1314 = load i64, ptr %r1313, align 8
  %r1315 = select i1 %r1312, i64 %r1314, i64 0
  %r1316 = or i1 %r1294, %r1300
  %r1317 = select i1 %r1294, i64 %r1297, i64 %r1303
  %r1318 = or i1 %r1306, %r1312
  %r1319 = select i1 %r1306, i64 %r1309, i64 %r1315
  %r1320 = or i1 %r1316, %r1318
  %r1321 = select i1 %r1316, i64 %r1317, i64 %r1319
  %r1322 = and i1 %r1232, %r1320
  br i1 %r1322, label %pic.way.load.255, label %pic.miss.call.248

pic.way.load.255:                                 ; preds = %pic.ways.254
  %r1323 = shl i64 %r1321, 3
  %r1324 = add nuw nsw i64 %r1202, 16
  %r1325 = add i64 %r1324, %r1323
  %r1326 = inttoptr i64 %r1325 to ptr
  %r1327 = load double, ptr %r1326, align 8
  %r1328 = bitcast double %r1327 to i64
  %r1329 = icmp eq i64 %r1328, 9222246136947933200
  br i1 %r1329, label %pic.miss.call.248, label %pic.way.live.256

pic.way.live.256:                                 ; preds = %pic.way.load.255
  br label %pic.merge.249

pget.throw_nullish.257:                           ; preds = %pget.recv_bad.230
  %r1338 = zext i1 %r1336 to i32
  %statepoint_token345 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1338, ptr @short_loops_ts_.str.4.bytes, i64 3, i32 0, i32 0)
  unreachable

pget.recv_undef_return.258:                       ; preds = %pget.recv_bad.230
  %r1339 = load double, ptr @short_loops_ts_.str.4.handle, align 8
  %r1340 = bitcast double %r1339 to i64
  %r1341 = and i64 %r1340, 281474976710655
  %statepoint_token346 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1201, i64 %r1341, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated319, ptr addrspace(1) %rs4gc.s13.relocated320, ptr addrspace(1) %rs4gc.s22.relocated) ]
  %r1342347 = call double @llvm.experimental.gc.result.f64(token %statepoint_token346)
  %rs4gc.s8.relocated348 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token346, i32 0, i32 0) ; (%rs4gc.s8.relocated319, %rs4gc.s8.relocated319)
  %rs4gc.s13.relocated349 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token346, i32 1, i32 1) ; (%rs4gc.s13.relocated320, %rs4gc.s13.relocated320)
  %rs4gc.s22.relocated350 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token346, i32 2, i32 2) ; (%rs4gc.s22.relocated, %rs4gc.s22.relocated)
  br label %pget.recv_merge.232

shadow.root.barrier.259:                          ; preds = %pget.recv_merge.232
  call void @js_write_barrier_root_nanbox(i64 %r1350) #9
  br label %shadow.root.barrier.done.260

shadow.root.barrier.done.260:                     ; preds = %shadow.root.barrier.259, %pget.recv_merge.232
  %r1353.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated334 to i64
  %r1353.rs4o = call i64 asm "", "=r,0"(i64 %r1353.rs4i) #9
  %r1353 = bitcast i64 %r1353.rs4o to double
  %r1354.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r1354 = call i64 asm "", "=r,0"(i64 %r1354.rs4i) #9
  %statepoint_token351 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1354, double %r1353, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated333) ]
  %r1355352 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token351)
  %rs4gc.s8.relocated353 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token351, i32 0, i32 0) ; (%rs4gc.s8.relocated333, %rs4gc.s8.relocated333)
  %rs4gc.s24 = inttoptr i64 %r1355352 to ptr addrspace(1)
  %r1356.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r1356 = call i64 asm "", "=r,0"(i64 %r1356.rs4i) #9
  %r1357 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1358 = icmp ne i32 %r1357, 0
  br i1 %r1358, label %shadow.root.barrier.261, label %shadow.root.barrier.done.262

shadow.root.barrier.261:                          ; preds = %shadow.root.barrier.done.260
  call void @js_write_barrier_root_nanbox(i64 %r1356) #9
  br label %shadow.root.barrier.done.262

shadow.root.barrier.done.262:                     ; preds = %shadow.root.barrier.261, %shadow.root.barrier.done.260
  %r1359.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r1359 = call i64 asm "", "=r,0"(i64 %r1359.rs4i) #9
  %statepoint_token354 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1359, double 0.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated353) ]
  %r1360355 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token354)
  %rs4gc.s8.relocated356 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token354, i32 0, i32 0) ; (%rs4gc.s8.relocated353, %rs4gc.s8.relocated353)
  %rs4gc.s25 = inttoptr i64 %r1360355 to ptr addrspace(1)
  %r1361.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r1361 = call i64 asm "", "=r,0"(i64 %r1361.rs4i) #9
  %r1362 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1363 = icmp ne i32 %r1362, 0
  br i1 %r1363, label %shadow.root.barrier.263, label %shadow.root.barrier.done.264

shadow.root.barrier.263:                          ; preds = %shadow.root.barrier.done.262
  call void @js_write_barrier_root_nanbox(i64 %r1361) #9
  br label %shadow.root.barrier.done.264

shadow.root.barrier.done.264:                     ; preds = %shadow.root.barrier.263, %shadow.root.barrier.done.262
  %r1364.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r1364 = call i64 asm "", "=r,0"(i64 %r1364.rs4i) #9
  %statepoint_token357 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1364, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated356) ]
  %rs4gc.s8.relocated358 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token357, i32 0, i32 0) ; (%rs4gc.s8.relocated356, %rs4gc.s8.relocated356)
  %statepoint_token359 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated358) ]
  %r1365360 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token359)
  %rs4gc.s8.relocated361 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token359, i32 0, i32 0) ; (%rs4gc.s8.relocated358, %rs4gc.s8.relocated358)
  %rs4gc.s26 = inttoptr i64 %r1365360 to ptr addrspace(1)
  %r1366.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r1366 = call i64 asm "", "=r,0"(i64 %r1366.rs4i) #9
  %r1367 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1368 = icmp ne i32 %r1367, 0
  br i1 %r1368, label %shadow.root.barrier.265, label %shadow.root.barrier.done.266

shadow.root.barrier.265:                          ; preds = %shadow.root.barrier.done.264
  call void @js_write_barrier_root_nanbox(i64 %r1366) #9
  br label %shadow.root.barrier.done.266

shadow.root.barrier.done.266:                     ; preds = %shadow.root.barrier.265, %shadow.root.barrier.done.264
  %r1369 = load double, ptr @short_loops_ts_.str.8.handle, align 8
  %r1370.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r1370 = call i64 asm "", "=r,0"(i64 %r1370.rs4i) #9
  %statepoint_token362 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1370, double %r1369, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated361) ]
  %r1371363 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token362)
  %rs4gc.s8.relocated364 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token362, i32 0, i32 0) ; (%rs4gc.s8.relocated361, %rs4gc.s8.relocated361)
  %rs4gc.s27 = inttoptr i64 %r1371363 to ptr addrspace(1)
  %r1372.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r1372 = call i64 asm "", "=r,0"(i64 %r1372.rs4i) #9
  %r1373 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1374 = icmp ne i32 %r1373, 0
  br i1 %r1374, label %shadow.root.barrier.267, label %shadow.root.barrier.done.268

shadow.root.barrier.267:                          ; preds = %shadow.root.barrier.done.266
  call void @js_write_barrier_root_nanbox(i64 %r1372) #9
  br label %shadow.root.barrier.done.268

shadow.root.barrier.done.268:                     ; preds = %shadow.root.barrier.267, %shadow.root.barrier.done.266
  %r1375.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8.relocated364 to i64
  %r1375.rs4o = call i64 asm "", "=r,0"(i64 %r1375.rs4i) #9
  %r1375 = bitcast i64 %r1375.rs4o to double
  %r1376 = bitcast double %r1375 to i64
  %r1377 = and i64 %r1376, 281474976710655
  %r1378 = lshr i64 %r1376, 48
  %r1379 = and i64 %r1378, 65533
  %r1380 = icmp eq i64 %r1379, 32765
  br i1 %r1380, label %pget.recv_ok.270, label %pget.recv_other.275

pget.recv_sso.269:                                ; preds = %pget.recv_other.275
  %r1519 = lshr i64 %r1376, 40
  %r1520 = and i64 %r1519, 255
  %r1521 = uitofp nneg i64 %r1520 to double
  br label %pget.recv_merge.273

pget.recv_ok.270:                                 ; preds = %shadow.root.barrier.done.268
  %r1387 = icmp eq i64 %r1378, 32767
  br i1 %r1387, label %pget.strlen_heap.274, label %pget.recv_obj.277

pget.recv_bad.271:                                ; preds = %pget.check_class_ref.276
  %r1511 = icmp eq i64 %r1376, 9222246136947933185
  %r1512 = icmp eq i64 %r1376, 9222246136947933186
  %r1513 = or i1 %r1511, %r1512
  br i1 %r1513, label %pget.throw_nullish.300, label %pget.recv_undef_return.301

pget.recv_class_ref.272:                          ; preds = %pget.check_class_ref.276
  %r1383 = load double, ptr @short_loops_ts_.str.9.handle, align 8
  %r1384 = bitcast double %r1383 to i64
  %r1385 = and i64 %r1384, 281474976710655
  %statepoint_token365 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 2301219111847329814, i64 %r1376, i64 %r1385, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s27) ]
  %r1386366 = call double @llvm.experimental.gc.result.f64(token %statepoint_token365)
  %rs4gc.s27.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token365, i32 0, i32 0) ; (%rs4gc.s27, %rs4gc.s27)
  br label %pget.recv_merge.273

pget.recv_merge.273:                              ; preds = %pget.recv_undef_return.301, %pic.merge.292, %pget.strlen_heap.274, %pget.recv_class_ref.272, %pget.recv_sso.269
  %.0484 = phi ptr addrspace(1) [ %rs4gc.s27, %pget.strlen_heap.274 ], [ %.1485, %pic.merge.292 ], [ %rs4gc.s27, %pget.recv_sso.269 ], [ %rs4gc.s27.relocated, %pget.recv_class_ref.272 ], [ %rs4gc.s27.relocated378, %pget.recv_undef_return.301 ]
  %r1527 = phi double [ %r1510, %pic.merge.292 ], [ %r1518377, %pget.recv_undef_return.301 ], [ %r1521, %pget.recv_sso.269 ], [ %r1386366, %pget.recv_class_ref.272 ], [ %r1526, %pget.strlen_heap.274 ]
  %r1528.rs4i = ptrtoint ptr addrspace(1) %.0484 to i64
  %r1528 = call i64 asm "", "=r,0"(i64 %r1528.rs4i) #9
  %statepoint_token367 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1528, double %r1527, i32 0, i32 0)
  %r1529368 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token367)
  %rs4gc.s28 = inttoptr i64 %r1529368 to ptr addrspace(1)
  %r1530.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r1530 = call i64 asm "", "=r,0"(i64 %r1530.rs4i) #9
  %r1531 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1532 = icmp ne i32 %r1531, 0
  br i1 %r1532, label %shadow.root.barrier.302, label %shadow.root.barrier.done.303

pget.strlen_heap.274:                             ; preds = %pget.recv_ok.270
  %r1522 = icmp ult i64 %r1377, 4096
  %r1523 = inttoptr i64 %r1377 to ptr
  %r1524 = select i1 %r1522, ptr @perry_null_guard_zero_short_loops_ts, ptr %r1523
  %r1525 = load i32, ptr %r1524, align 4
  %r1526 = uitofp i32 %r1525 to double
  br label %pget.recv_merge.273

pget.recv_other.275:                              ; preds = %shadow.root.barrier.done.268
  %r1381 = icmp eq i64 %r1378, 32761
  br i1 %r1381, label %pget.recv_sso.269, label %pget.check_class_ref.276

pget.check_class_ref.276:                         ; preds = %pget.recv_other.275
  %r1382 = icmp eq i64 %r1378, 32766
  br i1 %r1382, label %pget.recv_class_ref.272, label %pget.recv_bad.271

pget.recv_obj.277:                                ; preds = %pget.recv_ok.270
  %r1388 = icmp ugt i64 %r1377, 1048575
  br i1 %r1388, label %pic.recv_hdr.293, label %pic.miss.cold.290

pic.hit.278:                                      ; preds = %pic.token.294
  %r1413 = getelementptr i64, ptr %r1398, i64 1
  %r1414 = load i64, ptr %r1413, align 8
  %r1415 = and i64 %r1414, 1073741824
  %r1416 = icmp ne i64 %r1415, 0
  br i1 %r1416, label %pic.hit.overflow.295, label %pic.hit.inline.296

pic.hit.live.279:                                 ; preds = %pic.hit.inline.296
  br label %pic.merge.292

pic.prefix.guard.280:                             ; preds = %pic.token.294
  %r1429 = getelementptr i64, ptr %r1398, i64 2
  %r1430 = load i64, ptr %r1429, align 8
  %r1431 = icmp ne i64 %r1430, 0
  br i1 %r1431, label %pic.prefix.meta.281, label %pic.miss.289

pic.prefix.meta.281:                              ; preds = %pic.prefix.guard.280
  %r1432 = add nuw nsw i64 %r1377, 8
  %r1433 = inttoptr i64 %r1432 to ptr
  %r1434 = load i64, ptr %r1433, align 8
  %r1435 = icmp ne i64 %r1434, 0
  br i1 %r1435, label %pic.prefix.token.282, label %pic.miss.289

pic.prefix.token.282:                             ; preds = %pic.prefix.meta.281
  %r1436 = inttoptr i64 %r1434 to ptr
  %r1437 = getelementptr i64, ptr %r1436, i64 6
  %r1438 = load i64, ptr %r1437, align 8
  %r1439 = icmp eq i64 %r1438, %r1430
  br i1 %r1439, label %pic.prefix.hit.283, label %pic.miss.289

pic.prefix.hit.283:                               ; preds = %pic.prefix.token.282
  %r1440 = getelementptr i64, ptr %r1398, i64 1
  %r1441 = load i64, ptr %r1440, align 8
  %r1442 = shl i64 %r1441, 3
  %r1443 = add nuw nsw i64 %r1377, 16
  %r1444 = add i64 %r1443, %r1442
  %r1445 = inttoptr i64 %r1444 to ptr
  %r1446 = load double, ptr %r1445, align 8
  br label %pic.merge.292

pic.desc.classify.284:                            ; preds = %pic.recv_hdr.293
  %r1402 = and i1 %r1392, %r1399
  br i1 %r1402, label %pic.desc.prefix.guard.285, label %pic.miss.cold.290

pic.desc.prefix.guard.285:                        ; preds = %pic.desc.classify.284
  %r1447 = getelementptr i64, ptr %r1398, i64 2
  %r1448 = load i64, ptr %r1447, align 8
  %r1449 = icmp ne i64 %r1448, 0
  br i1 %r1449, label %pic.desc.prefix.meta.286, label %pic.miss.cold.290

pic.desc.prefix.meta.286:                         ; preds = %pic.desc.prefix.guard.285
  %r1450 = add nuw nsw i64 %r1377, 8
  %r1451 = inttoptr i64 %r1450 to ptr
  %r1452 = load i64, ptr %r1451, align 8
  %r1453 = icmp ne i64 %r1452, 0
  br i1 %r1453, label %pic.desc.prefix.token.287, label %pic.miss.cold.290

pic.desc.prefix.token.287:                        ; preds = %pic.desc.prefix.meta.286
  %r1454 = inttoptr i64 %r1452 to ptr
  %r1455 = getelementptr i64, ptr %r1454, i64 6
  %r1456 = load i64, ptr %r1455, align 8
  %r1457 = icmp eq i64 %r1456, %r1448
  br i1 %r1457, label %pic.desc.prefix.hit.288, label %pic.miss.cold.290

pic.desc.prefix.hit.288:                          ; preds = %pic.desc.prefix.token.287
  %r1458 = getelementptr i64, ptr %r1398, i64 1
  %r1459 = load i64, ptr %r1458, align 8
  %r1460 = shl i64 %r1459, 3
  %r1461 = add nuw nsw i64 %r1377, 16
  %r1462 = add i64 %r1461, %r1460
  %r1463 = inttoptr i64 %r1462 to ptr
  %r1464 = load double, ptr %r1463, align 8
  br label %pic.merge.292

pic.miss.289:                                     ; preds = %pic.hit.inline.296, %pic.prefix.token.282, %pic.prefix.meta.281, %pic.prefix.guard.280
  %r1465 = getelementptr i64, ptr %r1398, i64 3
  %r1466 = load i64, ptr %r1465, align 8
  %r1467 = icmp sgt i64 %r1466, 0
  br i1 %r1467, label %pic.ways.297, label %pic.miss.call.291

pic.miss.cold.290:                                ; preds = %pic.desc.prefix.token.287, %pic.desc.prefix.meta.286, %pic.desc.prefix.guard.285, %pic.desc.classify.284, %pget.recv_obj.277
  br label %pic.miss.call.291

pic.miss.call.291:                                ; preds = %pic.way.load.298, %pic.ways.297, %pic.miss.cold.290, %pic.miss.289
  %r1506 = load double, ptr @short_loops_ts_.str.9.handle, align 8
  %r1507 = bitcast double %r1506 to i64
  %r1508 = and i64 %r1507, 281474976710655
  %statepoint_token369 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1377, i64 %r1508, ptr @perry_ic_short_loops_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s27) ]
  %r1509370 = call double @llvm.experimental.gc.result.f64(token %statepoint_token369)
  %rs4gc.s27.relocated371 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token369, i32 0, i32 0) ; (%rs4gc.s27, %rs4gc.s27)
  br label %pic.merge.292

pic.merge.292:                                    ; preds = %pic.way.live.299, %pic.hit.overflow.295, %pic.miss.call.291, %pic.desc.prefix.hit.288, %pic.prefix.hit.283, %pic.hit.live.279
  %.1485 = phi ptr addrspace(1) [ %rs4gc.s27.relocated374, %pic.hit.overflow.295 ], [ %rs4gc.s27.relocated371, %pic.miss.call.291 ], [ %rs4gc.s27, %pic.way.live.299 ], [ %rs4gc.s27, %pic.hit.live.279 ], [ %rs4gc.s27, %pic.prefix.hit.283 ], [ %rs4gc.s27, %pic.desc.prefix.hit.288 ]
  %r1510 = phi double [ %r1426, %pic.hit.live.279 ], [ %r1421373, %pic.hit.overflow.295 ], [ %r1446, %pic.prefix.hit.283 ], [ %r1464, %pic.desc.prefix.hit.288 ], [ %r1503, %pic.way.live.299 ], [ %r1509370, %pic.miss.call.291 ]
  br label %pget.recv_merge.273

pic.recv_hdr.293:                                 ; preds = %pget.recv_obj.277
  %r1389 = sub nuw nsw i64 %r1377, 8
  %r1390 = inttoptr i64 %r1389 to ptr
  %r1391 = load i8, ptr %r1390, align 1
  %r1392 = icmp eq i8 %r1391, 2
  %r1393 = sub nuw nsw i64 %r1377, 6
  %r1394 = inttoptr i64 %r1393 to ptr
  %r1395 = load i16, ptr %r1394, align 2
  %r1396 = and i16 %r1395, 2048
  %r1397 = icmp eq i16 %r1396, 0
  %r1398 = load ptr, ptr @perry_ic_short_loops_ts__23, align 8
  %r1399 = icmp ne ptr %r1398, null
  %r1400 = and i1 %r1392, %r1397
  %r1401 = and i1 %r1400, %r1399
  br i1 %r1401, label %pic.token.294, label %pic.desc.classify.284

pic.token.294:                                    ; preds = %pic.recv_hdr.293
  %r1403 = add nuw nsw i64 %r1377, 4
  %r1404 = inttoptr i64 %r1403 to ptr
  %r1405 = load i32, ptr %r1404, align 4
  %r1406 = zext i32 %r1405 to i64
  %r1407 = or i64 %r1406, 4611686018427387904
  %r1408 = icmp ne i32 %r1405, 0
  %r1409 = getelementptr i64, ptr %r1398, i64 0
  %r1410 = load i64, ptr %r1409, align 8
  %r1411 = icmp eq i64 %r1407, %r1410
  %r1412 = and i1 %r1411, %r1408
  br i1 %r1412, label %pic.hit.278, label %pic.prefix.guard.280

pic.hit.overflow.295:                             ; preds = %pic.hit.278
  %r1417 = load double, ptr @short_loops_ts_.str.9.handle, align 8
  %r1418 = bitcast double %r1417 to i64
  %r1419 = and i64 %r1418, 281474976710655
  %r1420 = trunc i64 %r1414 to i32
  %statepoint_token372 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1377, i64 %r1419, i32 %r1420, ptr @perry_ic_short_loops_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s27) ]
  %r1421373 = call double @llvm.experimental.gc.result.f64(token %statepoint_token372)
  %rs4gc.s27.relocated374 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 0, i32 0) ; (%rs4gc.s27, %rs4gc.s27)
  br label %pic.merge.292

pic.hit.inline.296:                               ; preds = %pic.hit.278
  %r1422 = shl i64 %r1414, 3
  %r1423 = add nuw nsw i64 %r1377, 16
  %r1424 = add i64 %r1423, %r1422
  %r1425 = inttoptr i64 %r1424 to ptr
  %r1426 = load double, ptr %r1425, align 8
  %r1427 = bitcast double %r1426 to i64
  %r1428 = icmp eq i64 %r1427, 9222246136947933200
  br i1 %r1428, label %pic.miss.289, label %pic.hit.live.279

pic.ways.297:                                     ; preds = %pic.miss.289
  %r1468 = getelementptr i64, ptr %r1398, i64 4
  %r1469 = load i64, ptr %r1468, align 8
  %r1470 = icmp eq i64 %r1469, %r1407
  %r1471 = getelementptr i64, ptr %r1398, i64 5
  %r1472 = load i64, ptr %r1471, align 8
  %r1473 = select i1 %r1470, i64 %r1472, i64 0
  %r1474 = getelementptr i64, ptr %r1398, i64 6
  %r1475 = load i64, ptr %r1474, align 8
  %r1476 = icmp eq i64 %r1475, %r1407
  %r1477 = getelementptr i64, ptr %r1398, i64 7
  %r1478 = load i64, ptr %r1477, align 8
  %r1479 = select i1 %r1476, i64 %r1478, i64 0
  %r1480 = getelementptr i64, ptr %r1398, i64 8
  %r1481 = load i64, ptr %r1480, align 8
  %r1482 = icmp eq i64 %r1481, %r1407
  %r1483 = getelementptr i64, ptr %r1398, i64 9
  %r1484 = load i64, ptr %r1483, align 8
  %r1485 = select i1 %r1482, i64 %r1484, i64 0
  %r1486 = getelementptr i64, ptr %r1398, i64 10
  %r1487 = load i64, ptr %r1486, align 8
  %r1488 = icmp eq i64 %r1487, %r1407
  %r1489 = getelementptr i64, ptr %r1398, i64 11
  %r1490 = load i64, ptr %r1489, align 8
  %r1491 = select i1 %r1488, i64 %r1490, i64 0
  %r1492 = or i1 %r1470, %r1476
  %r1493 = select i1 %r1470, i64 %r1473, i64 %r1479
  %r1494 = or i1 %r1482, %r1488
  %r1495 = select i1 %r1482, i64 %r1485, i64 %r1491
  %r1496 = or i1 %r1492, %r1494
  %r1497 = select i1 %r1492, i64 %r1493, i64 %r1495
  %r1498 = and i1 %r1408, %r1496
  br i1 %r1498, label %pic.way.load.298, label %pic.miss.call.291

pic.way.load.298:                                 ; preds = %pic.ways.297
  %r1499 = shl i64 %r1497, 3
  %r1500 = add nuw nsw i64 %r1377, 16
  %r1501 = add i64 %r1500, %r1499
  %r1502 = inttoptr i64 %r1501 to ptr
  %r1503 = load double, ptr %r1502, align 8
  %r1504 = bitcast double %r1503 to i64
  %r1505 = icmp eq i64 %r1504, 9222246136947933200
  br i1 %r1505, label %pic.miss.call.291, label %pic.way.live.299

pic.way.live.299:                                 ; preds = %pic.way.load.298
  br label %pic.merge.292

pget.throw_nullish.300:                           ; preds = %pget.recv_bad.271
  %r1514 = zext i1 %r1512 to i32
  %statepoint_token375 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1514, ptr @short_loops_ts_.str.9.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.301:                       ; preds = %pget.recv_bad.271
  %r1515 = load double, ptr @short_loops_ts_.str.9.handle, align 8
  %r1516 = bitcast double %r1515 to i64
  %r1517 = and i64 %r1516, 281474976710655
  %statepoint_token376 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1376, i64 %r1517, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s27) ]
  %r1518377 = call double @llvm.experimental.gc.result.f64(token %statepoint_token376)
  %rs4gc.s27.relocated378 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token376, i32 0, i32 0) ; (%rs4gc.s27, %rs4gc.s27)
  br label %pget.recv_merge.273

shadow.root.barrier.302:                          ; preds = %pget.recv_merge.273
  call void @js_write_barrier_root_nanbox(i64 %r1530) #9
  br label %shadow.root.barrier.done.303

shadow.root.barrier.done.303:                     ; preds = %shadow.root.barrier.302, %pget.recv_merge.273
  %r1533.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r1533 = call i64 asm "", "=r,0"(i64 %r1533.rs4i) #9
  %statepoint_token379 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1533, i32 0, i32 0)
  %statepoint_token380 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token381 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token382 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token383 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token384 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.304

event_loop.header.304:                            ; preds = %event_loop.body_wait.309, %event_loop.body_check.308, %shadow.root.barrier.done.303
  %statepoint_token385 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r1538386 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token385)
  %r1539 = icmp ne i32 %r1538386, 0
  br i1 %r1539, label %event_loop.host_return.306, label %event_loop.check_pending.305

event_loop.check_pending.305:                     ; preds = %event_loop.header.304
  %statepoint_token387 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1540388 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token387)
  %statepoint_token389 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1541390 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token389)
  %statepoint_token391 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1542392 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token391)
  %statepoint_token393 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r1543394 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token393)
  %statepoint_token395 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r1544396 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token395)
  %statepoint_token397 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r1545398 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token397)
  %r1546 = or i32 %r1540388, %r1541390
  %r1547 = or i32 %r1542392, %r1543394
  %r1548 = or i32 %r1547, %r1544396
  %r1549 = or i32 %r1546, %r1548
  %r1550 = or i32 %r1549, 0
  %r1551 = or i32 %r1550, %r1545398
  %r1552 = icmp ne i32 %r1551, 0
  br i1 %r1552, label %event_loop.body.307, label %event_loop.exit.310

event_loop.host_return.306:                       ; preds = %event_loop.header.304
  call void @js_typed_feedback_maybe_dump_trace() #9
  ret i32 0

event_loop.body.307:                              ; preds = %event_loop.check_pending.305
  %statepoint_token399 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token400 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.308

event_loop.body_check.308:                        ; preds = %event_loop.body.307
  %statepoint_token401 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1554402 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token401)
  %statepoint_token403 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1555404 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token403)
  %statepoint_token405 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1556406 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token405)
  %statepoint_token407 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r1557408 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token407)
  %statepoint_token409 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r1558410 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token409)
  %statepoint_token411 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r1559412 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token411)
  %r1560 = or i32 %r1554402, %r1555404
  %r1561 = or i32 %r1556406, %r1557408
  %r1562 = or i32 %r1561, %r1558410
  %r1563 = or i32 %r1560, %r1562
  %r1564 = or i32 %r1563, 0
  %r1565 = or i32 %r1564, %r1559412
  %r1566 = icmp ne i32 %r1565, 0
  br i1 %r1566, label %event_loop.body_wait.309, label %event_loop.header.304

event_loop.body_wait.309:                         ; preds = %event_loop.body_check.308
  %statepoint_token413 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.304

event_loop.exit.310:                              ; preds = %event_loop.check_pending.305
  %statepoint_token414 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token415 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token416 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token417 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token418 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token419 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token420 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token421 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token422 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r1569423 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token422)
  call void @js_typed_feedback_maybe_dump_trace() #9
  ret i32 %r1569423
}

; Function Attrs: optsize
define void @__perry_init_strings_short_loops_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @short_loops_ts_.str.0.bytes, i32 2)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @short_loops_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @short_loops_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @short_loops_ts_.str.1.bytes, i32 2)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @short_loops_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @short_loops_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @short_loops_ts_.str.2.bytes, i32 12)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @short_loops_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @short_loops_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @short_loops_ts_.str.3.bytes, i32 4)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @short_loops_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @short_loops_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @short_loops_ts_.str.4.bytes, i32 3)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @short_loops_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @short_loops_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @short_loops_ts_.str.5.bytes, i32 6)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @short_loops_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @short_loops_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @short_loops_ts_.str.6.bytes, i32 4)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @short_loops_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @short_loops_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @short_loops_ts_.str.7.bytes, i32 6)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @short_loops_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @short_loops_ts_.str.7.handle to i64))
  %r25 = call i64 @js_string_from_bytes(ptr @short_loops_ts_.str.8.bytes, i32 4)
  %r26 = call double @js_nanbox_string(i64 %r25)
  store double %r26, ptr @short_loops_ts_.str.8.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @short_loops_ts_.str.8.handle to i64))
  %r28 = call i64 @js_string_from_bytes(ptr @short_loops_ts_.str.9.bytes, i32 6)
  %r29 = call double @js_nanbox_string(i64 %r28)
  store double %r29, ptr @short_loops_ts_.str.9.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @short_loops_ts_.str.9.handle to i64))
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_short_loops_ts__sum, ptr @short_loops_ts_.str.1, i32 3)
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_short_loops_ts__run, ptr @short_loops_ts_.str.2, i32 3)
  call void @js_register_function_name_static(ptr @perry_fn_short_loops_ts__sum, ptr @short_loops_ts_.str.1, i32 3)
  call void @js_register_function_name_static(ptr @perry_fn_short_loops_ts__run, ptr @short_loops_ts_.str.2, i32 3)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_short_loops_ts__sum, ptr @short_loops_ts_.str.3, i32 144, i32 0)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_short_loops_ts__run, ptr @short_loops_ts_.str.4, i32 178, i32 0)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_short_loops_ts__run, i32 3)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_short_loops_ts__sum, i32 2)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_short_loops_ts__run, i32 3)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_short_loops_ts__sum, i32 2)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_short_loops_ts__run)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_short_loops_ts__sum)
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_short_loops_ts() #6 {
entry.0:
  call void @__perry_init_strings_short_loops_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { noinline optsize "frame-pointer"="non-leaf" }
attributes #8 = { inlinehint optsize "frame-pointer"="non-leaf" }
attributes #9 = { "gc-leaf-function" }
