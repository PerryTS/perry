
benchmarks/json_performance/.work/invariant-field-loop-r5/access-worker.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0xc0
       4:      	stp	d15, d14, [sp, #0x20]
       8:      	stp	d13, d12, [sp, #0x30]
       c:      	stp	d11, d10, [sp, #0x40]
      10:      	stp	d9, d8, [sp, #0x50]
      14:      	stp	x28, x27, [sp, #0x60]
      18:      	stp	x26, x25, [sp, #0x70]
      1c:      	stp	x24, x23, [sp, #0x80]
      20:      	stp	x22, x21, [sp, #0x90]
      24:      	stp	x20, x19, [sp, #0xa0]
      28:      	stp	x29, x30, [sp, #0xb0]
      2c:      	add	x29, sp, #0xb0
      30:      	fmov	x26, d0
      34:      	fmov	x27, d1
      38:      	adrp	x19, 0x0 <ltmp0>
		0000000000000038:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__1
      3c:      	ldr	x8, [x19]
		000000000000003c:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
      40:      	adrp	x9, 0x0 <ltmp0>
		0000000000000040:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.0.handle
      44:      	ldr	x9, [x9]
		0000000000000044:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.0.handle
      48:      	cmp	x8, x9
      4c:      	b.ne	0x9c <ltmp0+0x9c>
      50:      	mov	x8, x27
      54:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
      58:      	cmp	x8, x9
      5c:      	b.lo	0x12c <ltmp0+0x12c>
      60:      	and	x9, x8, #0xffff000000000000
      64:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
      68:      	cmp	x9, x10
      6c:      	b.hi	0x12c <ltmp0+0x12c>
      70:      	mov	x8, x27
      74:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
      78:      	cmp	x8, x9
      7c:      	b.lo	0x2a8 <ltmp0+0x2a8>
      80:      	and	x9, x8, #0xffff000000000000
      84:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
      88:      	cmp	x9, x10
      8c:      	b.hi	0x2a8 <ltmp0+0x2a8>
      90:      	str	wzr, [sp, #0x4]
      94:      	mov	w24, #0x0               ; =0
      98:      	b	0x2e4 <ltmp0+0x2e4>
      9c:      	mov	w10, #0x7fff            ; =32767
      a0:      	cmp	x10, x8, lsr #48
      a4:      	b.ne	0xf0 <ltmp0+0xf0>
      a8:      	and	x0, x8, #0xffffffffffff
      ac:      	cmp	x0, #0x1, lsl #12       ; =0x1000
      b0:      	b.lo	0xf0 <ltmp0+0xf0>
      b4:      	ldr	w10, [x0, #0x4]
      b8:      	cmp	w10, #0x6
      bc:      	b.ne	0xf0 <ltmp0+0xf0>
      c0:      	ldrb	w10, [x0, #0x14]
      c4:      	cmp	w10, #0x72
      c8:      	b.ne	0xf0 <ltmp0+0xf0>
      cc:      	ldrb	w10, [x0, #0x19]
      d0:      	cmp	w10, #0x74
      d4:      	b.ne	0xf0 <ltmp0+0xf0>
      d8:      	stp	x26, x27, [sp, #0x10]
      dc:      	and	x1, x9, #0xffffffffffff
      e0:      	bl	0xe0 <ltmp0+0xe0>
		00000000000000e0:  ARM64_RELOC_BRANCH26	_js_string_equals
      e4:      	ldp	x26, x27, [sp, #0x10]
      e8:      	cbnz	w0, 0x50 <ltmp0+0x50>
      ec:      	ldr	x8, [x19]
		00000000000000ec:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
      f0:      	adrp	x9, 0x0 <ltmp0>
		00000000000000f0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.2.handle
      f4:      	ldr	x9, [x9]
		00000000000000f4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.2.handle
      f8:      	cmp	x8, x9
      fc:      	b.ne	0x208 <ltmp0+0x208>
     100:      	mov	x8, x27
     104:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
     108:      	cmp	x8, x9
     10c:      	b.lo	0x9f8 <ltmp0+0x9f8>
     110:      	and	x9, x8, #0xffff000000000000
     114:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
     118:      	cmp	x9, x10
     11c:      	b.hi	0x9f8 <ltmp0+0x9f8>
     120:      	mov	w21, #0x0               ; =0
     124:      	mov	w23, #0x0               ; =0
     128:      	b	0xb4c <ltmp0+0xb4c>
     12c:      	fmov	d0, x8
     130:      	fcmp	d0, #0.0
     134:      	b.le	0x70 <ltmp0+0x70>
     138:      	adrp	x8, 0x0 <ltmp0>
		0000000000000138:  ARM64_RELOC_PAGE21	lCPI0_0
     13c:      	ldr	d1, [x8]
		000000000000013c:  ARM64_RELOC_PAGEOFF12	lCPI0_0
     140:      	fcmp	d0, d1
     144:      	b.hi	0x70 <ltmp0+0x70>
     148:      	fcvtzs	w19, d0
     14c:      	scvtf	d1, w19
     150:      	fcmp	d0, d1
     154:      	b.ne	0x70 <ltmp0+0x70>
     158:      	mov	x20, #0x0               ; =0
     15c:      	and	x21, x20, #0xffff000000000000
     160:      	mov	x8, x26
     164:      	fmov	d0, x8
     168:      	adrp	x1, 0x0 <ltmp0>
		0000000000000168:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
     16c:      	add	x1, x1, #0x0
		000000000000016c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
     170:      	mov	w0, #0x7                ; =7
     174:      	mov	w2, #0x2                ; =2
     178:      	bl	0x178 <ltmp0+0x178>
		0000000000000178:  ARM64_RELOC_BRANCH26	_js_array_index_own_number
     17c:      	fmov	x8, d0
     180:      	and	x9, x8, #0xffff000000000000
     184:      	mov	x10, #0x7ff9000000000000 ; =9221401712017801216
     188:      	cmp	x8, x10
     18c:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
     190:      	ccmp	x9, x8, #0x2, hs
     194:      	cset	w8, hi
     198:      	mov	x9, #0x1                ; =1
     19c:      	movk	x9, #0x7fff, lsl #48
     1a0:      	cmp	x21, x9
     1a4:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
     1a8:      	ccmp	x20, x9, #0x0, lo
     1ac:      	b.hi	0x70 <ltmp0+0x70>
     1b0:      	cbz	w8, 0x70 <ltmp0+0x70>
     1b4:      	mov	x8, #0x0                ; =0
     1b8:      	fmov	d1, x8
     1bc:      	cmp	w19, #0x1
     1c0:      	csinc	w8, w19, wzr, gt
     1c4:      	fadd	d1, d0, d1
     1c8:      	subs	w8, w8, #0x1
     1cc:      	b.ne	0x1c4 <ltmp0+0x1c4>
     1d0:      	fmov	x20, d1
     1d4:      	fmov	d0, x20
     1d8:      	ldp	x29, x30, [sp, #0xb0]
     1dc:      	ldp	x20, x19, [sp, #0xa0]
     1e0:      	ldp	x22, x21, [sp, #0x90]
     1e4:      	ldp	x24, x23, [sp, #0x80]
     1e8:      	ldp	x26, x25, [sp, #0x70]
     1ec:      	ldp	x28, x27, [sp, #0x60]
     1f0:      	ldp	d9, d8, [sp, #0x50]
     1f4:      	ldp	d11, d10, [sp, #0x40]
     1f8:      	ldp	d13, d12, [sp, #0x30]
     1fc:      	ldp	d15, d14, [sp, #0x20]
     200:      	add	sp, sp, #0xc0
     204:      	ret
     208:      	mov	w10, #0x7fff            ; =32767
     20c:      	cmp	x10, x8, lsr #48
     210:      	b.ne	0x25c <ltmp0+0x25c>
     214:      	and	x0, x8, #0xffffffffffff
     218:      	cmp	x0, #0x1, lsl #12       ; =0x1000
     21c:      	b.lo	0x25c <ltmp0+0x25c>
     220:      	ldr	w10, [x0, #0x4]
     224:      	cmp	w10, #0x6
     228:      	b.ne	0x25c <ltmp0+0x25c>
     22c:      	ldrb	w10, [x0, #0x14]
     230:      	cmp	w10, #0x72
     234:      	b.ne	0x25c <ltmp0+0x25c>
     238:      	ldrb	w10, [x0, #0x19]
     23c:      	cmp	w10, #0x6d
     240:      	b.ne	0x25c <ltmp0+0x25c>
     244:      	stp	x26, x27, [sp, #0x10]
     248:      	and	x1, x9, #0xffffffffffff
     24c:      	bl	0x24c <ltmp0+0x24c>
		000000000000024c:  ARM64_RELOC_BRANCH26	_js_string_equals
     250:      	ldp	x26, x27, [sp, #0x10]
     254:      	cbnz	w0, 0x100 <ltmp0+0x100>
     258:      	ldr	x8, [x19]
		0000000000000258:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
     25c:      	adrp	x9, 0x0 <ltmp0>
		000000000000025c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.3.handle
     260:      	ldr	x9, [x9]
		0000000000000260:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.3.handle
     264:      	adrp	x23, 0x0 <ltmp0>
		0000000000000264:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
     268:      	ldr	x23, [x23]
		0000000000000268:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
     26c:      	adrp	x12, 0x0 <ltmp0>
		000000000000026c:  ARM64_RELOC_PAGE21	lCPI0_1
     270:      	adrp	x11, 0x0 <ltmp0>
		0000000000000270:  ARM64_RELOC_PAGE21	lCPI0_2
     274:      	cmp	x8, x9
     278:      	b.ne	0xa3c <ltmp0+0xa3c>
     27c:      	mov	x8, x27
     280:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
     284:      	cmp	x8, x9
     288:      	b.lo	0xac8 <ltmp0+0xac8>
     28c:      	and	x9, x8, #0xffff000000000000
     290:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
     294:      	cmp	x9, x10
     298:      	b.hi	0xac8 <ltmp0+0xac8>
     29c:      	mov	w25, #0x0               ; =0
     2a0:      	mov	w28, #0x0               ; =0
     2a4:      	b	0x1330 <ltmp0+0x1330>
     2a8:      	fmov	d0, x8
     2ac:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
     2b0:      	fmov	d1, x8
     2b4:      	fcmp	d0, d1
     2b8:      	b.lt	0x90 <ltmp0+0x90>
     2bc:      	fcvtzs	w8, d0
     2c0:      	scvtf	d1, w8
     2c4:      	adrp	x9, 0x0 <ltmp0>
		00000000000002c4:  ARM64_RELOC_PAGE21	lCPI0_0
     2c8:      	ldr	d2, [x9]
		00000000000002c8:  ARM64_RELOC_PAGEOFF12	lCPI0_0
     2cc:      	fcmp	d1, d0
     2d0:      	cset	w9, eq
     2d4:      	fcmp	d0, d2
     2d8:      	csel	w8, wzr, w8, hi
     2dc:      	str	w8, [sp, #0x4]
     2e0:      	csel	w24, wzr, w9, hi
     2e4:      	mov	w28, #0x0               ; =0
     2e8:      	mov	x20, #0x0               ; =0
     2ec:      	adrp	x21, 0x0 <ltmp0>
		00000000000002ec:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
     2f0:      	ldr	x21, [x21]
		00000000000002f0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
     2f4:      	movi.2d	v8, #0000000000000000
     2f8:      	mov	x22, #0x7ffd000000000000 ; =9222527611924643840
     2fc:      	adrp	x19, 0x0 <ltmp0>
		00000000000002fc:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__0
     300:      	add	x19, x19, #0x0
		0000000000000300:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__0
     304:      	fmov	d9, #7.00000000
     308:      	adrp	x8, 0x0 <ltmp0>
		0000000000000308:  ARM64_RELOC_PAGE21	lCPI0_2
     30c:      	ldr	d10, [x8]
		000000000000030c:  ARM64_RELOC_PAGEOFF12	lCPI0_2
     310:      	mov	x23, #0x7ff9000000000000 ; =9221401712017801216
     314:      	adrp	x25, 0x0 <ltmp0>
		0000000000000314:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
     318:      	ldr	x25, [x25]
		0000000000000318:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
     31c:      	fmov	d11, #1.00000000
     320:      	tbnz	w24, #0x0, 0x358 <ltmp0+0x358>
     324:      	mov	x23, x27
     328:      	ldr	w8, [x25]
     32c:      	cbz	w8, 0x344 <ltmp0+0x344>
     330:      	stp	x26, x20, [sp, #0x10]
     334:      	str	x27, [sp, #0x8]
     338:      	bl	0x338 <ltmp0+0x338>
		0000000000000338:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
     33c:      	ldp	x27, x26, [sp, #0x8]
     340:      	ldr	x20, [sp, #0x18]
     344:      	fmov	d0, x23
     348:      	fcmp	d8, d0
     34c:      	mov	x23, #0x7ff9000000000000 ; =9221401712017801216
     350:      	b.pl	0x1d4 <ltmp0+0x1d4>
     354:      	b	0x364 <ltmp0+0x364>
     358:      	ldr	w8, [sp, #0x4]
     35c:      	cmp	w28, w8
     360:      	b.ge	0x1d4 <ltmp0+0x1d4>
     364:      	mov	x0, x20
     368:      	ldr	w8, [x21]
     36c:      	cbz	w8, 0x374 <ltmp0+0x374>
     370:      	bl	0x370 <ltmp0+0x370>
		0000000000000370:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
     374:      	mov	x9, x26
     378:      	and	x8, x9, #0xffffffffffff
     37c:      	and	x12, x9, #0xffff000000000000
     380:      	cmp	x12, x22
     384:      	b.ne	0x3f0 <ltmp0+0x3f0>
     388:      	adrp	x10, 0x0 <ltmp0>
		0000000000000388:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
     38c:      	ldr	x10, [x10]
		000000000000038c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
     390:      	ldr	x10, [x10]
     394:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
     398:      	cmp	x10, #0x0
     39c:      	mov	x10, #0x7ffffff00000    ; =140737487306752
     3a0:      	ccmp	x11, x10, #0x2, eq
     3a4:      	b.hs	0x3f0 <ltmp0+0x3f0>
     3a8:      	ldurb	w11, [x8, #-0x8]
     3ac:      	ldrb	w10, [x8, #0x8]
     3b0:      	cmp	w11, #0xb
     3b4:      	ccmp	w10, #0x9, #0x2, eq
     3b8:      	b.hs	0x3f0 <ltmp0+0x3f0>
     3bc:      	ldr	w11, [x8]
     3c0:      	cmp	w11, #0x8
     3c4:      	b.lo	0x3f0 <ltmp0+0x3f0>
     3c8:      	cmp	w10, #0x3
     3cc:      	b.le	0x524 <ltmp0+0x524>
     3d0:      	cmp	w10, #0x5
     3d4:      	b.gt	0x574 <ltmp0+0x574>
     3d8:      	cmp	w10, #0x4
     3dc:      	b.eq	0x60c <ltmp0+0x60c>
     3e0:      	cmp	w10, #0x5
     3e4:      	b.ne	0x600 <ltmp0+0x600>
     3e8:      	ldr	s0, [x8, #0x2c]
     3ec:      	b	0x604 <ltmp0+0x604>
     3f0:      	ldr	x11, [x19]
     3f4:      	cmp	x11, #0x0
     3f8:      	csel	x10, x19, x11, eq
     3fc:      	cmp	x12, x22
     400:      	b.ne	0x71c <ltmp0+0x71c>
     404:      	mov	x12, #-0x20000000000    ; =-2199023255552
     408:      	add	x12, x8, x12
     40c:      	lsr	x12, x12, #41
     410:      	cmp	x12, #0x3f
     414:      	b.hs	0x71c <ltmp0+0x71c>
     418:      	ldursb	w12, [x8, #-0x7]
     41c:      	tbnz	w12, #0x1f, 0x71c <ltmp0+0x71c>
     420:      	ldurb	w12, [x8, #-0x8]
     424:      	cmp	w12, #0x9
     428:      	b.eq	0x4d8 <ltmp0+0x4d8>
     42c:      	cmp	w12, #0x2
     430:      	b.eq	0x48c <ltmp0+0x48c>
     434:      	cmp	w12, #0x1
     438:      	b.ne	0x71c <ltmp0+0x71c>
     43c:      	ldr	w9, [x8]
     440:      	mov	x10, x8
     444:      	ldurh	w12, [x8, #-0x6]
     448:      	adrp	x11, 0x0 <ltmp0>
		0000000000000448:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
     44c:      	ldr	x11, [x11]
		000000000000044c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
     450:      	ldrb	w11, [x11]
     454:      	tbnz	w12, #0xa, 0x71c <ltmp0+0x71c>
     458:      	cbnz	w11, 0x71c <ltmp0+0x71c>
     45c:      	cmp	w9, #0x8
     460:      	b.lo	0x71c <ltmp0+0x71c>
     464:      	ldr	w8, [x8, #0x4]
     468:      	cmp	w9, w8
     46c:      	b.hi	0x71c <ltmp0+0x71c>
     470:      	ldr	d0, [x10, #0x40]
     474:      	fmov	x8, d0
     478:      	mov	x9, #0x10               ; =16
     47c:      	movk	x9, #0x7ffc, lsl #48
     480:      	cmp	x8, x9
     484:      	fcsel	d0, d10, d0, eq
     488:      	b	0x740 <ltmp0+0x740>
     48c:      	ldr	x9, [x8, #0x8]
     490:      	cbz	x9, 0x540 <ltmp0+0x540>
     494:      	ldr	x12, [x9, #0x60]
     498:      	cbz	x12, 0x540 <ltmp0+0x540>
     49c:      	ldurb	w8, [x12, #-0x8]
     4a0:      	cmp	w8, #0x1
     4a4:      	b.ne	0x71c <ltmp0+0x71c>
     4a8:      	ldursb	w8, [x12, #-0x7]
     4ac:      	tbnz	w8, #0x1f, 0x71c <ltmp0+0x71c>
     4b0:      	ldr	w8, [x12]
     4b4:      	cmp	w8, #0x8
     4b8:      	b.lo	0x71c <ltmp0+0x71c>
     4bc:      	ldr	d0, [x12, #0x40]
     4c0:      	fmov	x8, d0
     4c4:      	mov	x9, #0x10               ; =16
     4c8:      	movk	x9, #0x7ffc, lsl #48
     4cc:      	cmp	x8, x9
     4d0:      	b.eq	0x71c <ltmp0+0x71c>
     4d4:      	b	0x740 <ltmp0+0x740>
     4d8:      	ldr	w11, [x8, #0x4]
     4dc:      	ldr	x10, [x8, #0x20]
     4e0:      	ldurh	w12, [x8, #-0x6]
     4e4:      	tst	w12, #0xc00
     4e8:      	mov	w12, #0x5841            ; =22593
     4ec:      	movk	w12, #0x4c5a, lsl #16
     4f0:      	ccmp	w11, w12, #0x0, eq
     4f4:      	cset	w11, eq
     4f8:      	cbz	x10, 0x58c <ltmp0+0x58c>
     4fc:      	tbz	w11, #0x0, 0x58c <ltmp0+0x58c>
     500:      	ldurb	w9, [x10, #-0x8]
     504:      	cmp	w9, #0x1
     508:      	b.ne	0x71c <ltmp0+0x71c>
     50c:      	ldursb	w9, [x10, #-0x7]
     510:      	tbnz	w9, #0x1f, 0x71c <ltmp0+0x71c>
     514:      	ldr	w9, [x10]
     518:      	str	w9, [x8]
     51c:      	mov	x8, x10
     520:      	b	0x444 <ltmp0+0x444>
     524:      	cbz	w10, 0x5f8 <ltmp0+0x5f8>
     528:      	cmp	w10, #0x2
     52c:      	b.eq	0x620 <ltmp0+0x620>
     530:      	cmp	w10, #0x3
     534:      	b.ne	0x600 <ltmp0+0x600>
     538:      	ldr	h0, [x8, #0x1e]
     53c:      	b	0x604 <ltmp0+0x604>
     540:      	ldr	x10, [x10]
     544:      	cbz	x10, 0x71c <ltmp0+0x71c>
     548:      	tbnz	x10, #0x3f, 0x62c <ltmp0+0x62c>
     54c:      	ldp	w13, w12, [x8]
     550:      	orr	x12, x12, x13, lsl #32
     554:      	cmp	x12, x10
     558:      	b.ne	0x71c <ltmp0+0x71c>
     55c:      	ldp	x13, x10, [x11, #0x8]
     560:      	ldp	x12, x11, [x11, #0x18]
     564:      	cmp	x13, x11
     568:      	b.lo	0x64c <ltmp0+0x64c>
     56c:      	cbz	x9, 0x71c <ltmp0+0x71c>
     570:      	b	0x660 <ltmp0+0x660>
     574:      	cmp	w10, #0x6
     578:      	b.eq	0x614 <ltmp0+0x614>
     57c:      	cmp	w10, #0x7
     580:      	b.ne	0x600 <ltmp0+0x600>
     584:      	ldr	d0, [x8, #0x48]
     588:      	b	0x740 <ltmp0+0x740>
     58c:      	cmp	x10, #0x0
     590:      	ldr	w13, [x8]
     594:      	ldp	x10, x12, [x8, #0x28]
     598:      	ccmp	w13, #0x7, #0x0, eq
     59c:      	ccmp	x10, #0x0, #0x4, hi
     5a0:      	ccmp	x12, #0x0, #0x4, ne
     5a4:      	csel	w11, wzr, w11, eq
     5a8:      	tbz	w11, #0x0, 0x71c <ltmp0+0x71c>
     5ac:      	ldrb	w11, [x12]
     5b0:      	tbnz	w11, #0x7, 0x658 <ltmp0+0x658>
     5b4:      	ldr	x8, [x8, #0x50]
     5b8:      	mov	w11, #0x6903            ; =26883
     5bc:      	movk	w11, #0x64, lsl #16
     5c0:      	cmp	x8, x11
     5c4:      	b.eq	0x5cc <ltmp0+0x5cc>
     5c8:      	cbnz	x8, 0x71c <ltmp0+0x71c>
     5cc:      	mov	w11, #0x6903            ; =26883
     5d0:      	movk	w11, #0x64, lsl #16
     5d4:      	cmp	x8, x11
     5d8:      	b.ne	0x6ec <ltmp0+0x6ec>
     5dc:      	ldr	x8, [x10, #0x38]
     5e0:      	cbz	x8, 0x6ec <ltmp0+0x6ec>
     5e4:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
     5e8:      	cmp	x8, x9
     5ec:      	csel	x8, xzr, x8, eq
     5f0:      	fmov	d1, x8
     5f4:      	b	0x944 <ltmp0+0x944>
     5f8:      	ldrsb	w8, [x8, #0x17]
     5fc:      	b	0x624 <ltmp0+0x624>
     600:      	ldr	b0, [x8, #0x17]
     604:      	ucvtf	d0, d0
     608:      	b	0x740 <ltmp0+0x740>
     60c:      	ldr	w8, [x8, #0x2c]
     610:      	b	0x624 <ltmp0+0x624>
     614:      	ldr	s0, [x8, #0x2c]
     618:      	fcvt	d0, s0
     61c:      	b	0x740 <ltmp0+0x740>
     620:      	ldrsh	w8, [x8, #0x1e]
     624:      	scvtf	d0, w8
     628:      	b	0x740 <ltmp0+0x740>
     62c:      	cbz	x9, 0x71c <ltmp0+0x71c>
     630:      	ldr	x12, [x9, #0x30]
     634:      	cmp	x12, x10
     638:      	b.ne	0x71c <ltmp0+0x71c>
     63c:      	ldp	x13, x10, [x11, #0x8]
     640:      	ldp	x12, x11, [x11, #0x18]
     644:      	cmp	x13, x11
     648:      	b.hs	0x660 <ltmp0+0x660>
     64c:      	add	x13, x8, x13, lsl #3
     650:      	add	x13, x13, #0x10
     654:      	b	0x684 <ltmp0+0x684>
     658:      	ldr	d0, [x10, #0x38]
     65c:      	b	0x740 <ltmp0+0x740>
     660:      	ldr	x15, [x9, #0x20]
     664:      	cmp	x15, #0x0
     668:      	csel	x14, x15, x9, ne
     66c:      	cbz	x15, 0x71c <ltmp0+0x71c>
     670:      	ldr	w15, [x14]
     674:      	cmp	x13, x15
     678:      	b.hs	0x71c <ltmp0+0x71c>
     67c:      	add	x13, x14, x13, lsl #3
     680:      	add	x13, x13, #0x8
     684:      	ldr	d0, [x13]
     688:      	fcmp	d0, d9
     68c:      	ccmp	x12, #0x7, #0x0, gt
     690:      	cset	w13, hi
     694:      	add	x12, x10, #0x7
     698:      	cmp	x12, x11
     69c:      	b.hs	0x6b0 <ltmp0+0x6b0>
     6a0:      	cbz	w13, 0x6b0 <ltmp0+0x6b0>
     6a4:      	add	x8, x8, x12, lsl #3
     6a8:      	ldr	d0, [x8, #0x10]
     6ac:      	b	0x740 <ltmp0+0x740>
     6b0:      	cbz	x9, 0x71c <ltmp0+0x71c>
     6b4:      	cmp	x12, x11
     6b8:      	b.lo	0x71c <ltmp0+0x71c>
     6bc:      	eor	w8, w13, #0x1
     6c0:      	tbnz	w8, #0x0, 0x71c <ltmp0+0x71c>
     6c4:      	ldr	x11, [x9, #0x20]
     6c8:      	cmp	x11, #0x0
     6cc:      	csel	x8, x11, x9, ne
     6d0:      	cbz	x11, 0x71c <ltmp0+0x71c>
     6d4:      	ldr	w9, [x8]
     6d8:      	cmp	x12, x9
     6dc:      	b.hs	0x71c <ltmp0+0x71c>
     6e0:      	add	x8, x8, x10, lsl #3
     6e4:      	ldr	d0, [x8, #0x40]
     6e8:      	b	0x740 <ltmp0+0x740>
     6ec:      	fmov	d0, x9
     6f0:      	fmov	d1, #7.00000000
     6f4:      	adrp	x0, 0x0 <ltmp0>
		00000000000006f4:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
     6f8:      	add	x0, x0, #0x0
		00000000000006f8:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
     6fc:      	mov	w1, #0x2                ; =2
     700:      	bl	0x700 <ltmp0+0x700>
		0000000000000700:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
     704:      	mov.16b	v1, v0
     708:      	fmov	x8, d1
     70c:      	mov	x9, #0x10               ; =16
     710:      	movk	x9, #0x7ffc, lsl #48
     714:      	cmp	x8, x9
     718:      	b.ne	0x944 <ltmp0+0x944>
     71c:      	mov	x8, x26
     720:      	stp	x27, x26, [sp, #0x10]
     724:      	fmov	d0, x8
     728:      	str	x20, [sp, #0x8]
     72c:      	fmov	d1, #7.00000000
     730:      	mov	x0, x19
     734:      	bl	0x734 <ltmp0+0x734>
		0000000000000734:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
     738:      	ldp	x20, x27, [sp, #0x8]
     73c:      	ldr	x26, [sp, #0x18]
     740:      	fmov	x8, d0
     744:      	mov	x9, #-0x3000000000000   ; =-844424930131968
     748:      	and	x9, x8, x9
     74c:      	cmp	x9, x22
     750:      	b.ne	0x7c4 <ltmp0+0x7c4>
     754:      	and	x0, x8, #0xffffffffffff
     758:      	lsr	x8, x0, #20
     75c:      	cbz	x8, 0x918 <ltmp0+0x918>
     760:      	ldurb	w9, [x0, #-0x8]
     764:      	adrp	x8, 0x0 <ltmp0>
		0000000000000764:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__2
     768:      	ldr	x8, [x8]
		0000000000000768:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__2
     76c:      	cbz	x8, 0x83c <ltmp0+0x83c>
     770:      	ldurh	w10, [x0, #-0x6]
     774:      	and	w10, w10, #0x800
     778:      	cmp	w9, #0x2
     77c:      	ccmp	w10, #0x0, #0x0, eq
     780:      	b.ne	0x83c <ltmp0+0x83c>
     784:      	ldr	w10, [x0, #0x4]
     788:      	orr	x9, x10, #0x4000000000000000
     78c:      	cbz	w10, 0x868 <ltmp0+0x868>
     790:      	ldr	x11, [x8]
     794:      	cmp	x9, x11
     798:      	b.ne	0x868 <ltmp0+0x868>
     79c:      	ldr	x2, [x8, #0x8]
     7a0:      	tbnz	w2, #0x1e, 0x9d4 <ltmp0+0x9d4>
     7a4:      	add	x11, x0, x2, lsl #3
     7a8:      	ldr	d1, [x11, #0x10]
     7ac:      	fmov	x11, d1
     7b0:      	mov	x12, #0x10              ; =16
     7b4:      	movk	x12, #0x7ffc, lsl #48
     7b8:      	cmp	x11, x12
     7bc:      	b.ne	0x944 <ltmp0+0x944>
     7c0:      	b	0x894 <ltmp0+0x894>
     7c4:      	lsr	x9, x8, #48
     7c8:      	mov	w10, #0x7ff9            ; =32761
     7cc:      	cmp	x9, x10
     7d0:      	b.eq	0x81c <ltmp0+0x81c>
     7d4:      	mov	w10, #0x7ffe            ; =32766
     7d8:      	cmp	w9, w10
     7dc:      	b.ne	0x80c <ltmp0+0x80c>
     7e0:      	adrp	x9, 0x0 <ltmp0>
		00000000000007e0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
     7e4:      	ldr	x9, [x9]
		00000000000007e4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
     7e8:      	stp	x26, x20, [sp, #0x10]
     7ec:      	str	x27, [sp, #0x8]
     7f0:      	and	x2, x9, #0xffffffffffff
     7f4:      	mov	x0, #0x1                ; =1
     7f8:      	movk	x0, #0xddae, lsl #32
     7fc:      	movk	x0, #0x5556, lsl #48
     800:      	mov	x1, x8
     804:      	bl	0x804 <ltmp0+0x804>
		0000000000000804:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
     808:      	b	0x938 <ltmp0+0x938>
     80c:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
     810:      	add	x9, x8, x9
     814:      	cmp	x9, #0x2
     818:      	b.lo	0x302c <ltmp0+0x302c>
     81c:      	adrp	x9, 0x0 <ltmp0>
		000000000000081c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
     820:      	ldr	x9, [x9]
		0000000000000820:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
     824:      	stp	x26, x20, [sp, #0x10]
     828:      	str	x27, [sp, #0x8]
     82c:      	and	x1, x9, #0xffffffffffff
     830:      	mov	x0, x8
     834:      	bl	0x834 <ltmp0+0x834>
		0000000000000834:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
     838:      	b	0x938 <ltmp0+0x938>
     83c:      	cmp	w9, #0x2
     840:      	ccmp	x8, #0x0, #0x4, eq
     844:      	b.eq	0x918 <ltmp0+0x918>
     848:      	ldr	x9, [x8, #0x10]
     84c:      	cbz	x9, 0x918 <ltmp0+0x918>
     850:      	ldr	x10, [x0, #0x8]
     854:      	cbz	x10, 0x918 <ltmp0+0x918>
     858:      	ldr	x10, [x10, #0x30]
     85c:      	cmp	x10, x9
     860:      	b.eq	0x884 <ltmp0+0x884>
     864:      	b	0x918 <ltmp0+0x918>
     868:      	ldr	x11, [x8, #0x10]
     86c:      	cbz	x11, 0x894 <ltmp0+0x894>
     870:      	ldr	x12, [x0, #0x8]
     874:      	cbz	x12, 0x894 <ltmp0+0x894>
     878:      	ldr	x12, [x12, #0x30]
     87c:      	cmp	x12, x11
     880:      	b.ne	0x894 <ltmp0+0x894>
     884:      	ldr	x8, [x8, #0x8]
     888:      	add	x8, x0, x8, lsl #3
     88c:      	ldr	d1, [x8, #0x10]
     890:      	b	0x944 <ltmp0+0x944>
     894:      	ldr	x11, [x8, #0x18]
     898:      	cmp	x11, #0x0
     89c:      	b.le	0x918 <ltmp0+0x918>
     8a0:      	ldr	x11, [x8, #0x20]
     8a4:      	ldr	x12, [x8, #0x30]
     8a8:      	ldr	x13, [x8, #0x40]
     8ac:      	cmp	x13, x9
     8b0:      	ldr	x14, [x8, #0x50]
     8b4:      	ccmp	x14, x9, #0x4, ne
     8b8:      	ccmp	x12, x9, #0x4, ne
     8bc:      	ccmp	x11, x9, #0x4, ne
     8c0:      	cset	w15, eq
     8c4:      	cbz	w10, 0x918 <ltmp0+0x918>
     8c8:      	cbz	w15, 0x918 <ltmp0+0x918>
     8cc:      	ldr	x10, [x8, #0x48]
     8d0:      	ldr	x15, [x8, #0x58]
     8d4:      	cmp	x14, x9
     8d8:      	csel	x14, x15, xzr, eq
     8dc:      	cmp	x13, x9
     8e0:      	csel	x10, x10, x14, eq
     8e4:      	ldr	x13, [x8, #0x28]
     8e8:      	ldr	x8, [x8, #0x38]
     8ec:      	cmp	x12, x9
     8f0:      	csel	x8, x8, x10, eq
     8f4:      	cmp	x11, x9
     8f8:      	csel	x8, x13, x8, eq
     8fc:      	add	x8, x0, x8, lsl #3
     900:      	ldr	d1, [x8, #0x10]
     904:      	fmov	x8, d1
     908:      	mov	x9, #0x10               ; =16
     90c:      	movk	x9, #0x7ffc, lsl #48
     910:      	cmp	x8, x9
     914:      	b.ne	0x944 <ltmp0+0x944>
     918:      	adrp	x8, 0x0 <ltmp0>
		0000000000000918:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
     91c:      	ldr	x8, [x8]
		000000000000091c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
     920:      	stp	x26, x20, [sp, #0x10]
     924:      	str	x27, [sp, #0x8]
     928:      	and	x1, x8, #0xffffffffffff
     92c:      	adrp	x2, 0x0 <ltmp0>
		000000000000092c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__2
     930:      	add	x2, x2, #0x0
		0000000000000930:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__2
     934:      	bl	0x934 <ltmp0+0x934>
		0000000000000934:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
     938:      	mov.16b	v1, v0
     93c:      	ldp	x27, x26, [sp, #0x8]
     940:      	ldr	x20, [sp, #0x18]
     944:      	fmov	d0, x20
     948:      	and	x9, x20, #0xffff000000000000
     94c:      	fmov	x8, d1
     950:      	and	x10, x8, #0xffff000000000000
     954:      	cmp	x8, x23
     958:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
     95c:      	ccmp	x10, x8, #0x2, hs
     960:      	cset	w8, hi
     964:      	mov	x10, #0x1               ; =1
     968:      	movk	x10, #0x7fff, lsl #48
     96c:      	cmp	x9, x10
     970:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
     974:      	ccmp	x20, x9, #0x0, lo
     978:      	b.hi	0x988 <ltmp0+0x988>
     97c:      	tbz	w8, #0x0, 0x988 <ltmp0+0x988>
     980:      	fadd	d0, d1, d0
     984:      	b	0x994 <ltmp0+0x994>
     988:      	stp	x27, x26, [sp, #0x10]
     98c:      	bl	0x98c <ltmp0+0x98c>
		000000000000098c:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
     990:      	ldp	x27, x26, [sp, #0x10]
     994:      	fmov	x20, d0
     998:      	mov	x0, x20
     99c:      	ldr	w8, [x21]
     9a0:      	cbz	w8, 0x9a8 <ltmp0+0x9a8>
     9a4:      	bl	0x9a4 <ltmp0+0x9a4>
		00000000000009a4:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
     9a8:      	ldr	w8, [x25]
     9ac:      	cbz	w8, 0x9c4 <ltmp0+0x9c4>
     9b0:      	stp	x26, x27, [sp, #0x10]
     9b4:      	str	x20, [sp, #0x8]
     9b8:      	bl	0x9b8 <ltmp0+0x9b8>
		00000000000009b8:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
     9bc:      	ldp	x20, x26, [sp, #0x8]
     9c0:      	ldr	x27, [sp, #0x18]
     9c4:      	fadd	d8, d8, d11
     9c8:      	add	w28, w28, #0x1
     9cc:      	tbz	w24, #0x0, 0x324 <ltmp0+0x324>
     9d0:      	b	0x358 <ltmp0+0x358>
     9d4:      	adrp	x8, 0x0 <ltmp0>
		00000000000009d4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
     9d8:      	ldr	x8, [x8]
		00000000000009d8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
     9dc:      	stp	x26, x20, [sp, #0x10]
     9e0:      	str	x27, [sp, #0x8]
     9e4:      	and	x1, x8, #0xffffffffffff
     9e8:      	adrp	x3, 0x0 <ltmp0>
		00000000000009e8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__2
     9ec:      	add	x3, x3, #0x0
		00000000000009ec:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__2
     9f0:      	bl	0x9f0 <ltmp0+0x9f0>
		00000000000009f0:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
     9f4:      	b	0x938 <ltmp0+0x938>
     9f8:      	mov	w21, #0x0               ; =0
     9fc:      	fmov	d0, x8
     a00:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
     a04:      	fmov	d1, x8
     a08:      	fcmp	d0, d1
     a0c:      	b.lt	0xb48 <ltmp0+0xb48>
     a10:      	adrp	x8, 0x0 <ltmp0>
		0000000000000a10:  ARM64_RELOC_PAGE21	lCPI0_0
     a14:      	ldr	d1, [x8]
		0000000000000a14:  ARM64_RELOC_PAGEOFF12	lCPI0_0
     a18:      	fcmp	d0, d1
     a1c:      	mov	x23, x21
     a20:      	b.hi	0xb4c <ltmp0+0xb4c>
     a24:      	fcvtzs	w21, d0
     a28:      	scvtf	d1, w21
     a2c:      	fcmp	d1, d0
     a30:      	b.ne	0x124 <ltmp0+0x124>
     a34:      	mov	w23, #0x1               ; =1
     a38:      	b	0xb4c <ltmp0+0xb4c>
     a3c:      	mov	w10, #0x7fff            ; =32767
     a40:      	cmp	x10, x8, lsr #48
     a44:      	b.ne	0xa9c <ltmp0+0xa9c>
     a48:      	and	x0, x8, #0xffffffffffff
     a4c:      	cmp	x0, #0x1, lsl #12       ; =0x1000
     a50:      	b.lo	0xa9c <ltmp0+0xa9c>
     a54:      	ldr	w8, [x0, #0x4]
     a58:      	cmp	w8, #0x6
     a5c:      	b.ne	0xa9c <ltmp0+0xa9c>
     a60:      	ldrb	w8, [x0, #0x14]
     a64:      	cmp	w8, #0x66
     a68:      	b.ne	0xa9c <ltmp0+0xa9c>
     a6c:      	ldrb	w8, [x0, #0x19]
     a70:      	cmp	w8, #0x73
     a74:      	b.ne	0xa9c <ltmp0+0xa9c>
     a78:      	stp	x26, x27, [sp, #0x10]
     a7c:      	and	x1, x9, #0xffffffffffff
     a80:      	mov	x19, x11
     a84:      	mov	x20, x12
     a88:      	bl	0xa88 <ltmp0+0xa88>
		0000000000000a88:  ARM64_RELOC_BRANCH26	_js_string_equals
     a8c:      	mov	x12, x20
     a90:      	mov	x11, x19
     a94:      	ldp	x26, x27, [sp, #0x10]
     a98:      	cbnz	w0, 0x27c <ltmp0+0x27c>
     a9c:      	mov	x8, x27
     aa0:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
     aa4:      	cmp	x8, x9
     aa8:      	b.lo	0xb08 <ltmp0+0xb08>
     aac:      	and	x9, x8, #0xffff000000000000
     ab0:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
     ab4:      	cmp	x9, x10
     ab8:      	b.hi	0xb08 <ltmp0+0xb08>
     abc:      	mov	w25, #0x0               ; =0
     ac0:      	mov	w22, #0x0               ; =0
     ac4:      	b	0x28d4 <ltmp0+0x28d4>
     ac8:      	mov	w25, #0x0               ; =0
     acc:      	fmov	d0, x8
     ad0:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
     ad4:      	fmov	d1, x8
     ad8:      	fcmp	d0, d1
     adc:      	b.lt	0x132c <ltmp0+0x132c>
     ae0:      	adrp	x8, 0x0 <ltmp0>
		0000000000000ae0:  ARM64_RELOC_PAGE21	lCPI0_0
     ae4:      	ldr	d1, [x8]
		0000000000000ae4:  ARM64_RELOC_PAGEOFF12	lCPI0_0
     ae8:      	fcmp	d0, d1
     aec:      	mov	x28, x25
     af0:      	b.hi	0x1330 <ltmp0+0x1330>
     af4:      	fcvtzs	w25, d0
     af8:      	frintz	d1, d0
     afc:      	fcmp	d1, d0
     b00:      	cset	w28, eq
     b04:      	b	0x1330 <ltmp0+0x1330>
     b08:      	mov	w25, #0x0               ; =0
     b0c:      	fmov	d0, x8
     b10:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
     b14:      	fmov	d1, x8
     b18:      	fcmp	d0, d1
     b1c:      	b.lt	0x28d0 <ltmp0+0x28d0>
     b20:      	adrp	x8, 0x0 <ltmp0>
		0000000000000b20:  ARM64_RELOC_PAGE21	lCPI0_0
     b24:      	ldr	d1, [x8]
		0000000000000b24:  ARM64_RELOC_PAGEOFF12	lCPI0_0
     b28:      	fcmp	d0, d1
     b2c:      	mov	x22, x25
     b30:      	b.hi	0x28d4 <ltmp0+0x28d4>
     b34:      	fcvtzs	w25, d0
     b38:      	frintz	d1, d0
     b3c:      	fcmp	d1, d0
     b40:      	cset	w22, eq
     b44:      	b	0x28d4 <ltmp0+0x28d4>
     b48:      	mov	x23, x21
     b4c:      	mov	w28, #0x0               ; =0
     b50:      	mov	x20, #0x0               ; =0
     b54:      	movi.2d	v8, #0000000000000000
     b58:      	mov	x25, #0x7ff9000000000000 ; =9221401712017801216
     b5c:      	fmov	d9, #17.00000000
     b60:      	adrp	x24, 0x0 <ltmp0>
		0000000000000b60:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
     b64:      	ldr	x24, [x24]
		0000000000000b64:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
     b68:      	mov	x22, #0x7ffd000000000000 ; =9222527611924643840
     b6c:      	fmov	d10, #7.00000000
     b70:      	mov	x8, #0x41f0000000000000 ; =4751297606875873280
     b74:      	fmov	d11, x8
     b78:      	adrp	x19, 0x0 <ltmp0>
		0000000000000b78:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__3
     b7c:      	add	x19, x19, #0x0
		0000000000000b7c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__3
     b80:      	adrp	x8, 0x0 <ltmp0>
		0000000000000b80:  ARM64_RELOC_PAGE21	lCPI0_1
     b84:      	ldr	d12, [x8]
		0000000000000b84:  ARM64_RELOC_PAGEOFF12	lCPI0_1
     b88:      	adrp	x8, 0x0 <ltmp0>
		0000000000000b88:  ARM64_RELOC_PAGE21	lCPI0_2
     b8c:      	ldr	d13, [x8]
		0000000000000b8c:  ARM64_RELOC_PAGEOFF12	lCPI0_2
     b90:      	fmov	d14, #1.00000000
     b94:      	movi.2d	v15, #0000000000000000
     b98:      	tbnz	w23, #0x0, 0xbe0 <ltmp0+0xbe0>
     b9c:      	mov	x25, x21
     ba0:      	mov	x21, x27
     ba4:      	adrp	x8, 0x0 <ltmp0>
		0000000000000ba4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
     ba8:      	ldr	x8, [x8]
		0000000000000ba8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
     bac:      	ldr	w8, [x8]
     bb0:      	cbz	w8, 0xbc8 <ltmp0+0xbc8>
     bb4:      	stp	x20, x27, [sp, #0x10]
     bb8:      	str	x26, [sp, #0x8]
     bbc:      	bl	0xbbc <ltmp0+0xbbc>
		0000000000000bbc:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
     bc0:      	ldp	x26, x20, [sp, #0x8]
     bc4:      	ldr	x27, [sp, #0x18]
     bc8:      	fmov	d0, x21
     bcc:      	fcmp	d15, d0
     bd0:      	mov	x21, x25
     bd4:      	mov	x25, #0x7ff9000000000000 ; =9221401712017801216
     bd8:      	b.pl	0x1d4 <ltmp0+0x1d4>
     bdc:      	b	0xbe8 <ltmp0+0xbe8>
     be0:      	cmp	w28, w21
     be4:      	b.ge	0x1d4 <ltmp0+0x1d4>
     be8:      	fmov	x8, d8
     bec:      	cmp	x8, x25
     bf0:      	b.lo	0xc24 <ltmp0+0xc24>
     bf4:      	and	x8, x8, #0xffff000000000000
     bf8:      	mov	x9, #0x7fff000000000000 ; =9223090561878065152
     bfc:      	cmp	x8, x9
     c00:      	b.hi	0xc24 <ltmp0+0xc24>
     c04:      	stp	x20, x27, [sp, #0x10]
     c08:      	str	x26, [sp, #0x8]
     c0c:      	fmov	d1, #17.00000000
     c10:      	mov.16b	v0, v8
     c14:      	bl	0xc14 <ltmp0+0xc14>
		0000000000000c14:  ARM64_RELOC_BRANCH26	_js_dynamic_mul
     c18:      	ldp	x26, x20, [sp, #0x8]
     c1c:      	ldr	x27, [sp, #0x18]
     c20:      	b	0xc28 <ltmp0+0xc28>
     c24:      	fmul	d0, d8, d9
     c28:      	fadd	d0, d0, d10
     c2c:      	adrp	x8, 0x0 <ltmp0>
		0000000000000c2c:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
     c30:      	ldr	d1, [x8]
		0000000000000c30:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
     c34:      	stp	x26, x20, [sp, #0x10]
     c38:      	str	x27, [sp, #0x8]
     c3c:      	bl	0xc3c <ltmp0+0xc3c>
		0000000000000c3c:  ARM64_RELOC_BRANCH26	_js_dynamic_mod
     c40:      	mov.16b	v8, v0
     c44:      	ldp	x27, x26, [sp, #0x8]
     c48:      	ldr	x20, [sp, #0x18]
     c4c:      	fmov	x8, d8
     c50:      	mov	w9, #0x7fff             ; =32767
     c54:      	cmp	x9, x8, lsr #48
     c58:      	b.ne	0xc64 <ltmp0+0xc64>
     c5c:      	mov.16b	v0, v8
     c60:      	bl	0xc60 <ltmp0+0xc60>
		0000000000000c60:  ARM64_RELOC_BRANCH26	_js_string_addref_if_heap_string
     c64:      	mov	x0, x20
     c68:      	ldr	w8, [x24]
     c6c:      	cbz	w8, 0xc74 <ltmp0+0xc74>
     c70:      	bl	0xc70 <ltmp0+0xc70>
		0000000000000c70:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
     c74:      	mov	x10, x26
     c78:      	and	x8, x10, #0xffffffffffff
     c7c:      	and	x13, x10, #0xffff000000000000
     c80:      	cmp	x13, x22
     c84:      	b.ne	0xce0 <ltmp0+0xce0>
     c88:      	adrp	x9, 0x0 <ltmp0>
		0000000000000c88:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
     c8c:      	ldr	x9, [x9]
		0000000000000c8c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
     c90:      	ldr	x9, [x9]
     c94:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
     c98:      	cmp	x9, #0x0
     c9c:      	mov	x9, #0x7ffffff00000     ; =140737487306752
     ca0:      	ccmp	x11, x9, #0x2, eq
     ca4:      	b.hs	0xce0 <ltmp0+0xce0>
     ca8:      	fcmp	d8, d11
     cac:      	b.pl	0xce0 <ltmp0+0xce0>
     cb0:      	ldurb	w9, [x8, #-0x8]
     cb4:      	ldrb	w11, [x8, #0x8]
     cb8:      	fcmp	d8, #0.0
     cbc:      	ccmp	w9, #0xb, #0x0, ge
     cc0:      	ccmp	w11, #0x9, #0x2, eq
     cc4:      	b.hs	0xce0 <ltmp0+0xce0>
     cc8:      	fcvtzs	x9, d8
     ccc:      	scvtf	d0, x9
     cd0:      	ldr	w12, [x8]
     cd4:      	fcmp	d8, d0
     cd8:      	ccmp	x9, x12, #0x2, eq
     cdc:      	b.lo	0xda0 <ltmp0+0xda0>
     ce0:      	ldr	x11, [x19]
     ce4:      	cmp	x11, #0x0
     ce8:      	csel	x12, x19, x11, eq
     cec:      	cmp	x13, x22
     cf0:      	b.ne	0x1068 <ltmp0+0x1068>
     cf4:      	fcmp	d8, #0.0
     cf8:      	b.lt	0x1068 <ltmp0+0x1068>
     cfc:      	fcmp	d8, d12
     d00:      	b.pl	0x1068 <ltmp0+0x1068>
     d04:      	mov	x9, #-0x20000000000     ; =-2199023255552
     d08:      	add	x9, x8, x9
     d0c:      	lsr	x9, x9, #41
     d10:      	cmp	x9, #0x3f
     d14:      	b.hs	0x1068 <ltmp0+0x1068>
     d18:      	fcvtzs	x9, d8
     d1c:      	scvtf	d0, x9
     d20:      	fcmp	d8, d0
     d24:      	b.ne	0x1068 <ltmp0+0x1068>
     d28:      	ldursb	w13, [x8, #-0x7]
     d2c:      	tbnz	w13, #0x1f, 0x1068 <ltmp0+0x1068>
     d30:      	ldurb	w13, [x8, #-0x8]
     d34:      	cmp	w13, #0x9
     d38:      	b.eq	0xe38 <ltmp0+0xe38>
     d3c:      	cmp	w13, #0x2
     d40:      	b.eq	0xde8 <ltmp0+0xde8>
     d44:      	cmp	w13, #0x1
     d48:      	b.ne	0x1068 <ltmp0+0x1068>
     d4c:      	ldr	w10, [x8]
     d50:      	mov	x11, x8
     d54:      	ldurh	w13, [x8, #-0x6]
     d58:      	adrp	x12, 0x0 <ltmp0>
		0000000000000d58:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
     d5c:      	ldr	x12, [x12]
		0000000000000d5c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
     d60:      	ldrb	w12, [x12]
     d64:      	ldr	w8, [x8, #0x4]
     d68:      	cmp	x10, x8
     d6c:      	b.hi	0x1068 <ltmp0+0x1068>
     d70:      	tbnz	w13, #0xa, 0x1068 <ltmp0+0x1068>
     d74:      	cbnz	w12, 0x1068 <ltmp0+0x1068>
     d78:      	cmp	x9, x10
     d7c:      	b.hs	0x1068 <ltmp0+0x1068>
     d80:      	add	x8, x11, x9, lsl #3
     d84:      	ldr	d0, [x8, #0x8]
     d88:      	fmov	x8, d0
     d8c:      	mov	x9, #0x10               ; =16
     d90:      	movk	x9, #0x7ffc, lsl #48
     d94:      	cmp	x8, x9
     d98:      	fcsel	d0, d13, d0, eq
     d9c:      	b	0x1084 <ltmp0+0x1084>
     da0:      	add	x8, x8, #0x10
     da4:      	cmp	w11, #0x3
     da8:      	b.le	0xdcc <ltmp0+0xdcc>
     dac:      	cmp	w11, #0x5
     db0:      	b.gt	0xe84 <ltmp0+0xe84>
     db4:      	cmp	w11, #0x4
     db8:      	b.eq	0xf1c <ltmp0+0xf1c>
     dbc:      	cmp	w11, #0x5
     dc0:      	b.ne	0xf10 <ltmp0+0xf10>
     dc4:      	ldr	s0, [x8, x9, lsl #2]
     dc8:      	b	0xf14 <ltmp0+0xf14>
     dcc:      	cbz	w11, 0xf08 <ltmp0+0xf08>
     dd0:      	cmp	w11, #0x2
     dd4:      	b.eq	0xf30 <ltmp0+0xf30>
     dd8:      	cmp	w11, #0x3
     ddc:      	b.ne	0xf10 <ltmp0+0xf10>
     de0:      	ldr	h0, [x8, x9, lsl #1]
     de4:      	b	0xf14 <ltmp0+0xf14>
     de8:      	ldr	x10, [x8, #0x8]
     dec:      	cbz	x10, 0xe9c <ltmp0+0xe9c>
     df0:      	ldr	x13, [x10, #0x60]
     df4:      	cbz	x13, 0xe9c <ltmp0+0xe9c>
     df8:      	ldurb	w8, [x13, #-0x8]
     dfc:      	cmp	w8, #0x1
     e00:      	b.ne	0x1068 <ltmp0+0x1068>
     e04:      	ldursb	w8, [x13, #-0x7]
     e08:      	tbnz	w8, #0x1f, 0x1068 <ltmp0+0x1068>
     e0c:      	ldr	w8, [x13]
     e10:      	cmp	x9, x8
     e14:      	b.hs	0x1068 <ltmp0+0x1068>
     e18:      	add	x8, x13, x9, lsl #3
     e1c:      	ldr	d0, [x8, #0x8]
     e20:      	fmov	x8, d0
     e24:      	mov	x9, #0x10               ; =16
     e28:      	movk	x9, #0x7ffc, lsl #48
     e2c:      	cmp	x8, x9
     e30:      	b.eq	0x1068 <ltmp0+0x1068>
     e34:      	b	0x1084 <ltmp0+0x1084>
     e38:      	ldr	w12, [x8, #0x4]
     e3c:      	ldr	x11, [x8, #0x20]
     e40:      	ldurh	w13, [x8, #-0x6]
     e44:      	tst	w13, #0xc00
     e48:      	mov	w13, #0x5841            ; =22593
     e4c:      	movk	w13, #0x4c5a, lsl #16
     e50:      	ccmp	w12, w13, #0x0, eq
     e54:      	cset	w12, eq
     e58:      	cbz	x11, 0xed0 <ltmp0+0xed0>
     e5c:      	tbz	w12, #0x0, 0xed0 <ltmp0+0xed0>
     e60:      	ldurb	w10, [x11, #-0x8]
     e64:      	cmp	w10, #0x1
     e68:      	b.ne	0x1068 <ltmp0+0x1068>
     e6c:      	ldursb	w10, [x11, #-0x7]
     e70:      	tbnz	w10, #0x1f, 0x1068 <ltmp0+0x1068>
     e74:      	ldr	w10, [x11]
     e78:      	str	w10, [x8]
     e7c:      	mov	x8, x11
     e80:      	b	0xd54 <ltmp0+0xd54>
     e84:      	cmp	w11, #0x6
     e88:      	b.eq	0xf24 <ltmp0+0xf24>
     e8c:      	cmp	w11, #0x7
     e90:      	b.ne	0xf10 <ltmp0+0xf10>
     e94:      	ldr	d0, [x8, x9, lsl #3]
     e98:      	b	0x1084 <ltmp0+0x1084>
     e9c:      	ldr	x12, [x12]
     ea0:      	cbz	x12, 0x1068 <ltmp0+0x1068>
     ea4:      	tbnz	x12, #0x3f, 0xf3c <ltmp0+0xf3c>
     ea8:      	ldp	w14, w13, [x8]
     eac:      	orr	x13, x13, x14, lsl #32
     eb0:      	cmp	x13, x12
     eb4:      	b.ne	0x1068 <ltmp0+0x1068>
     eb8:      	ldp	x14, x12, [x11, #0x8]
     ebc:      	ldp	x13, x11, [x11, #0x18]
     ec0:      	cmp	x14, x11
     ec4:      	b.lo	0xf5c <ltmp0+0xf5c>
     ec8:      	cbz	x10, 0x1068 <ltmp0+0x1068>
     ecc:      	b	0xfac <ltmp0+0xfac>
     ed0:      	cmp	x11, #0x0
     ed4:      	ldr	w14, [x8]
     ed8:      	ldp	x11, x13, [x8, #0x28]
     edc:      	ccmp	x9, x14, #0x2, eq
     ee0:      	ccmp	x11, #0x0, #0x4, lo
     ee4:      	ccmp	x13, #0x0, #0x4, ne
     ee8:      	csel	w12, wzr, w12, eq
     eec:      	tbz	w12, #0x0, 0x1068 <ltmp0+0x1068>
     ef0:      	lsr	x12, x9, #6
     ef4:      	ldr	x12, [x13, x12, lsl #3]
     ef8:      	lsr	x12, x12, x9
     efc:      	tbz	w12, #0x0, 0xf68 <ltmp0+0xf68>
     f00:      	ldr	d0, [x11, x9, lsl #3]
     f04:      	b	0x1084 <ltmp0+0x1084>
     f08:      	ldrsb	w8, [x8, x9]
     f0c:      	b	0xf34 <ltmp0+0xf34>
     f10:      	ldr	b0, [x8, x9]
     f14:      	ucvtf	d0, d0
     f18:      	b	0x1084 <ltmp0+0x1084>
     f1c:      	ldr	w8, [x8, x9, lsl #2]
     f20:      	b	0xf34 <ltmp0+0xf34>
     f24:      	ldr	s0, [x8, x9, lsl #2]
     f28:      	fcvt	d0, s0
     f2c:      	b	0x1084 <ltmp0+0x1084>
     f30:      	ldrsh	w8, [x8, x9, lsl #1]
     f34:      	scvtf	d0, w8
     f38:      	b	0x1084 <ltmp0+0x1084>
     f3c:      	cbz	x10, 0x1068 <ltmp0+0x1068>
     f40:      	ldr	x13, [x10, #0x30]
     f44:      	cmp	x13, x12
     f48:      	b.ne	0x1068 <ltmp0+0x1068>
     f4c:      	ldp	x14, x12, [x11, #0x8]
     f50:      	ldp	x13, x11, [x11, #0x18]
     f54:      	cmp	x14, x11
     f58:      	b.hs	0xfac <ltmp0+0xfac>
     f5c:      	add	x14, x8, x14, lsl #3
     f60:      	add	x14, x14, #0x10
     f64:      	b	0xfd0 <ltmp0+0xfd0>
     f68:      	ldr	x8, [x8, #0x50]
     f6c:      	mov	w12, #0x6903            ; =26883
     f70:      	movk	w12, #0x64, lsl #16
     f74:      	cmp	x8, x12
     f78:      	b.eq	0xf80 <ltmp0+0xf80>
     f7c:      	cbnz	x8, 0x1068 <ltmp0+0x1068>
     f80:      	mov	w12, #0x6903            ; =26883
     f84:      	movk	w12, #0x64, lsl #16
     f88:      	cmp	x8, x12
     f8c:      	b.ne	0x1038 <ltmp0+0x1038>
     f90:      	ldr	x8, [x11, x9, lsl #3]
     f94:      	cbz	x8, 0x1038 <ltmp0+0x1038>
     f98:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
     f9c:      	cmp	x8, x9
     fa0:      	csel	x8, xzr, x8, eq
     fa4:      	fmov	d1, x8
     fa8:      	b	0x127c <ltmp0+0x127c>
     fac:      	ldr	x16, [x10, #0x20]
     fb0:      	cmp	x16, #0x0
     fb4:      	csel	x15, x16, x10, ne
     fb8:      	cbz	x16, 0x1068 <ltmp0+0x1068>
     fbc:      	ldr	w16, [x15]
     fc0:      	cmp	x14, x16
     fc4:      	b.hs	0x1068 <ltmp0+0x1068>
     fc8:      	add	x14, x15, x14, lsl #3
     fcc:      	add	x14, x14, #0x8
     fd0:      	ldr	d0, [x14]
     fd4:      	fcmp	d8, d0
     fd8:      	ccmp	x13, x9, #0x0, mi
     fdc:      	cset	w13, hi
     fe0:      	add	x9, x12, x9
     fe4:      	cmp	x9, x11
     fe8:      	ccmp	w13, #0x0, #0x4, lo
     fec:      	b.ne	0x102c <ltmp0+0x102c>
     ff0:      	cbz	x10, 0x1068 <ltmp0+0x1068>
     ff4:      	cmp	x9, x11
     ff8:      	b.lo	0x1068 <ltmp0+0x1068>
     ffc:      	eor	w8, w13, #0x1
    1000:      	tbnz	w8, #0x0, 0x1068 <ltmp0+0x1068>
    1004:      	ldr	x11, [x10, #0x20]
    1008:      	cmp	x11, #0x0
    100c:      	csel	x8, x11, x10, ne
    1010:      	cbz	x11, 0x1068 <ltmp0+0x1068>
    1014:      	ldr	w10, [x8]
    1018:      	cmp	x9, x10
    101c:      	b.hs	0x1068 <ltmp0+0x1068>
    1020:      	add	x8, x8, x9, lsl #3
    1024:      	ldr	d0, [x8, #0x8]
    1028:      	b	0x1084 <ltmp0+0x1084>
    102c:      	add	x8, x8, x9, lsl #3
    1030:      	ldr	d0, [x8, #0x10]
    1034:      	b	0x1084 <ltmp0+0x1084>
    1038:      	fmov	d0, x10
    103c:      	mov.16b	v1, v8
    1040:      	adrp	x0, 0x1000 <ltmp0+0x1000>
		0000000000001040:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    1044:      	add	x0, x0, #0x0
		0000000000001044:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    1048:      	mov	w1, #0x2                ; =2
    104c:      	bl	0x104c <ltmp0+0x104c>
		000000000000104c:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    1050:      	mov.16b	v1, v0
    1054:      	fmov	x8, d1
    1058:      	mov	x9, #0x10               ; =16
    105c:      	movk	x9, #0x7ffc, lsl #48
    1060:      	cmp	x8, x9
    1064:      	b.ne	0x127c <ltmp0+0x127c>
    1068:      	fmov	d0, x26
    106c:      	str	x20, [sp, #0x18]
    1070:      	mov.16b	v1, v8
    1074:      	mov	x0, x19
    1078:      	bl	0x1078 <ltmp0+0x1078>
		0000000000001078:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    107c:      	ldp	x26, x20, [sp, #0x10]
    1080:      	ldr	x27, [sp, #0x8]
    1084:      	fmov	x8, d0
    1088:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    108c:      	and	x9, x8, x9
    1090:      	cmp	x9, x22
    1094:      	b.ne	0x1100 <ltmp0+0x1100>
    1098:      	and	x0, x8, #0xffffffffffff
    109c:      	lsr	x8, x0, #20
    10a0:      	cbz	x8, 0x1254 <ltmp0+0x1254>
    10a4:      	ldurb	w9, [x0, #-0x8]
    10a8:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		00000000000010a8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__5
    10ac:      	ldr	x8, [x8]
		00000000000010ac:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__5
    10b0:      	cbz	x8, 0x1170 <ltmp0+0x1170>
    10b4:      	ldurh	w10, [x0, #-0x6]
    10b8:      	and	w10, w10, #0x800
    10bc:      	cmp	w9, #0x2
    10c0:      	ccmp	w10, #0x0, #0x0, eq
    10c4:      	b.ne	0x1170 <ltmp0+0x1170>
    10c8:      	ldr	w10, [x0, #0x4]
    10cc:      	orr	x9, x10, #0x4000000000000000
    10d0:      	ldr	x11, [x8]
    10d4:      	cmp	w10, #0x0
    10d8:      	ccmp	x9, x11, #0x0, ne
    10dc:      	b.eq	0x11a8 <ltmp0+0x11a8>
    10e0:      	ldr	x11, [x8, #0x10]
    10e4:      	cbz	x11, 0x11cc <ltmp0+0x11cc>
    10e8:      	ldr	x12, [x0, #0x8]
    10ec:      	cbz	x12, 0x11cc <ltmp0+0x11cc>
    10f0:      	ldr	x12, [x12, #0x30]
    10f4:      	cmp	x12, x11
    10f8:      	b.eq	0x1198 <ltmp0+0x1198>
    10fc:      	b	0x11cc <ltmp0+0x11cc>
    1100:      	lsr	x9, x8, #48
    1104:      	mov	w10, #0x7ff9            ; =32761
    1108:      	cmp	x9, x10
    110c:      	b.eq	0x1154 <ltmp0+0x1154>
    1110:      	mov	w10, #0x7ffe            ; =32766
    1114:      	cmp	w9, w10
    1118:      	b.ne	0x1144 <ltmp0+0x1144>
    111c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		000000000000111c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    1120:      	ldr	x9, [x9]
		0000000000001120:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    1124:      	str	x20, [sp, #0x18]
    1128:      	and	x2, x9, #0xffffffffffff
    112c:      	mov	x0, #0x4                ; =4
    1130:      	movk	x0, #0xddae, lsl #32
    1134:      	movk	x0, #0x5556, lsl #48
    1138:      	mov	x1, x8
    113c:      	bl	0x113c <ltmp0+0x113c>
		000000000000113c:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    1140:      	b	0x1270 <ltmp0+0x1270>
    1144:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    1148:      	add	x9, x8, x9
    114c:      	cmp	x9, #0x2
    1150:      	b.lo	0x302c <ltmp0+0x302c>
    1154:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		0000000000001154:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    1158:      	ldr	x9, [x9]
		0000000000001158:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    115c:      	str	x20, [sp, #0x18]
    1160:      	and	x1, x9, #0xffffffffffff
    1164:      	mov	x0, x8
    1168:      	bl	0x1168 <ltmp0+0x1168>
		0000000000001168:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    116c:      	b	0x1270 <ltmp0+0x1270>
    1170:      	cmp	w9, #0x2
    1174:      	ccmp	x8, #0x0, #0x4, eq
    1178:      	b.eq	0x1254 <ltmp0+0x1254>
    117c:      	ldr	x9, [x8, #0x10]
    1180:      	cbz	x9, 0x1254 <ltmp0+0x1254>
    1184:      	ldr	x10, [x0, #0x8]
    1188:      	cbz	x10, 0x1254 <ltmp0+0x1254>
    118c:      	ldr	x10, [x10, #0x30]
    1190:      	cmp	x10, x9
    1194:      	b.ne	0x1254 <ltmp0+0x1254>
    1198:      	ldr	x8, [x8, #0x8]
    119c:      	add	x8, x0, x8, lsl #3
    11a0:      	ldr	d1, [x8, #0x10]
    11a4:      	b	0x127c <ltmp0+0x127c>
    11a8:      	ldr	x2, [x8, #0x8]
    11ac:      	tbnz	w2, #0x1e, 0x130c <ltmp0+0x130c>
    11b0:      	add	x11, x0, x2, lsl #3
    11b4:      	ldr	d1, [x11, #0x10]
    11b8:      	fmov	x11, d1
    11bc:      	mov	x12, #0x10              ; =16
    11c0:      	movk	x12, #0x7ffc, lsl #48
    11c4:      	cmp	x11, x12
    11c8:      	b.ne	0x127c <ltmp0+0x127c>
    11cc:      	ldr	x11, [x8, #0x18]
    11d0:      	cmp	x11, #0x0
    11d4:      	b.le	0x1254 <ltmp0+0x1254>
    11d8:      	ldr	x11, [x8, #0x20]
    11dc:      	ldr	x12, [x8, #0x30]
    11e0:      	ldr	x13, [x8, #0x40]
    11e4:      	cmp	x13, x9
    11e8:      	ldr	x14, [x8, #0x50]
    11ec:      	ccmp	x14, x9, #0x4, ne
    11f0:      	ccmp	x12, x9, #0x4, ne
    11f4:      	ccmp	x11, x9, #0x4, ne
    11f8:      	cset	w15, eq
    11fc:      	cmp	w10, #0x0
    1200:      	ccmp	w15, #0x0, #0x4, ne
    1204:      	b.eq	0x1254 <ltmp0+0x1254>
    1208:      	ldr	x10, [x8, #0x48]
    120c:      	ldr	x15, [x8, #0x58]
    1210:      	cmp	x14, x9
    1214:      	csel	x14, x15, xzr, eq
    1218:      	cmp	x13, x9
    121c:      	csel	x10, x10, x14, eq
    1220:      	ldr	x13, [x8, #0x28]
    1224:      	ldr	x8, [x8, #0x38]
    1228:      	cmp	x12, x9
    122c:      	csel	x8, x8, x10, eq
    1230:      	cmp	x11, x9
    1234:      	csel	x8, x13, x8, eq
    1238:      	add	x8, x0, x8, lsl #3
    123c:      	ldr	d1, [x8, #0x10]
    1240:      	fmov	x8, d1
    1244:      	mov	x9, #0x10               ; =16
    1248:      	movk	x9, #0x7ffc, lsl #48
    124c:      	cmp	x8, x9
    1250:      	b.ne	0x127c <ltmp0+0x127c>
    1254:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		0000000000001254:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    1258:      	ldr	x8, [x8]
		0000000000001258:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    125c:      	str	x20, [sp, #0x18]
    1260:      	and	x1, x8, #0xffffffffffff
    1264:      	adrp	x2, 0x1000 <ltmp0+0x1000>
		0000000000001264:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__5
    1268:      	add	x2, x2, #0x0
		0000000000001268:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__5
    126c:      	bl	0x126c <ltmp0+0x126c>
		000000000000126c:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    1270:      	mov.16b	v1, v0
    1274:      	ldp	x27, x26, [sp, #0x8]
    1278:      	ldr	x20, [sp, #0x18]
    127c:      	fmov	d0, x20
    1280:      	and	x9, x20, #0xffff000000000000
    1284:      	fmov	x8, d1
    1288:      	and	x10, x8, #0xffff000000000000
    128c:      	cmp	x8, x25
    1290:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    1294:      	ccmp	x10, x8, #0x2, hs
    1298:      	cset	w8, hi
    129c:      	mov	x10, #0x1               ; =1
    12a0:      	movk	x10, #0x7fff, lsl #48
    12a4:      	cmp	x9, x10
    12a8:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    12ac:      	ccmp	x20, x9, #0x0, lo
    12b0:      	b.hi	0x12c0 <ltmp0+0x12c0>
    12b4:      	tbz	w8, #0x0, 0x12c0 <ltmp0+0x12c0>
    12b8:      	fadd	d0, d1, d0
    12bc:      	b	0x12c8 <ltmp0+0x12c8>
    12c0:      	bl	0x12c0 <ltmp0+0x12c0>
		00000000000012c0:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    12c4:      	ldp	x27, x26, [sp, #0x8]
    12c8:      	fmov	x20, d0
    12cc:      	mov	x0, x20
    12d0:      	ldr	w8, [x24]
    12d4:      	cbz	w8, 0x12dc <ltmp0+0x12dc>
    12d8:      	bl	0x12d8 <ltmp0+0x12d8>
		00000000000012d8:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    12dc:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		00000000000012dc:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    12e0:      	ldr	x8, [x8]
		00000000000012e0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    12e4:      	ldr	w8, [x8]
    12e8:      	cbz	w8, 0x12fc <ltmp0+0x12fc>
    12ec:      	str	x20, [sp, #0x18]
    12f0:      	bl	0x12f0 <ltmp0+0x12f0>
		00000000000012f0:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    12f4:      	ldp	x26, x20, [sp, #0x10]
    12f8:      	ldr	x27, [sp, #0x8]
    12fc:      	fadd	d15, d15, d14
    1300:      	add	w28, w28, #0x1
    1304:      	tbz	w23, #0x0, 0xb9c <ltmp0+0xb9c>
    1308:      	b	0xbe0 <ltmp0+0xbe0>
    130c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		000000000000130c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    1310:      	ldr	x8, [x8]
		0000000000001310:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    1314:      	str	x20, [sp, #0x18]
    1318:      	and	x1, x8, #0xffffffffffff
    131c:      	adrp	x3, 0x1000 <ltmp0+0x1000>
		000000000000131c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__5
    1320:      	add	x3, x3, #0x0
		0000000000001320:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__5
    1324:      	bl	0x1324 <ltmp0+0x1324>
		0000000000001324:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    1328:      	b	0x1270 <ltmp0+0x1270>
    132c:      	mov	x28, x25
    1330:      	mov	w24, #0x0               ; =0
    1334:      	mov	x20, #0x0               ; =0
    1338:      	mov	x22, #0x7ffd000000000000 ; =9222527611924643840
    133c:      	mov	x19, #0x7ffffff00000    ; =140737487306752
    1340:      	ldr	d9, [x12]
		0000000000001340:  ARM64_RELOC_PAGEOFF12	lCPI0_1
    1344:      	ldr	d10, [x11]
		0000000000001344:  ARM64_RELOC_PAGEOFF12	lCPI0_2
    1348:      	mov	x21, #0x7ff8ffffffffffff ; =9221401712017801215
    134c:      	mov	x8, #0x41f0000000000000 ; =4751297606875873280
    1350:      	fmov	d11, x8
    1354:      	tbnz	w28, #0x0, 0x13a8 <ltmp0+0x13a8>
    1358:      	mov	x19, x28
    135c:      	mov	x28, x25
    1360:      	mov	x25, x27
    1364:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		0000000000001364:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    1368:      	ldr	x8, [x8]
		0000000000001368:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    136c:      	ldr	w8, [x8]
    1370:      	cbz	w8, 0x1388 <ltmp0+0x1388>
    1374:      	stp	x26, x27, [sp, #0x10]
    1378:      	str	x20, [sp, #0x8]
    137c:      	bl	0x137c <ltmp0+0x137c>
		000000000000137c:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    1380:      	ldp	x20, x26, [sp, #0x8]
    1384:      	ldr	x27, [sp, #0x18]
    1388:      	scvtf	d0, w24
    138c:      	fmov	d1, x25
    1390:      	fcmp	d0, d1
    1394:      	mov	x25, x28
    1398:      	mov	x28, x19
    139c:      	mov	x19, #0x7ffffff00000    ; =140737487306752
    13a0:      	b.pl	0x1d4 <ltmp0+0x1d4>
    13a4:      	b	0x13b4 <ltmp0+0x13b4>
    13a8:      	cmp	w24, w25
    13ac:      	b.ge	0x1d4 <ltmp0+0x1d4>
    13b0:      	scvtf	d0, w24
    13b4:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		00000000000013b4:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    13b8:      	ldr	d1, [x8]
		00000000000013b8:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    13bc:      	stp	x27, x20, [sp, #0x10]
    13c0:      	str	x26, [sp, #0x8]
    13c4:      	bl	0x13c4 <ltmp0+0x13c4>
		00000000000013c4:  ARM64_RELOC_BRANCH26	_js_dynamic_mod
    13c8:      	mov.16b	v8, v0
    13cc:      	ldp	x26, x27, [sp, #0x8]
    13d0:      	ldr	x20, [sp, #0x18]
    13d4:      	mov	x0, x20
    13d8:      	ldr	w8, [x23]
    13dc:      	cbz	w8, 0x13e4 <ltmp0+0x13e4>
    13e0:      	bl	0x13e0 <ltmp0+0x13e0>
		00000000000013e0:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    13e4:      	mov	x10, x26
    13e8:      	and	x8, x10, #0xffffffffffff
    13ec:      	and	x13, x10, #0xffff000000000000
    13f0:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		00000000000013f0:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    13f4:      	ldr	x9, [x9]
		00000000000013f4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    13f8:      	ldr	x9, [x9]
    13fc:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
    1400:      	cmp	x13, x22
    1404:      	ccmp	x9, #0x0, #0x0, eq
    1408:      	ccmp	x11, x19, #0x2, eq
    140c:      	b.hs	0x1450 <ltmp0+0x1450>
    1410:      	mov	x9, #0x41f0000000000000 ; =4751297606875873280
    1414:      	fmov	d0, x9
    1418:      	fcmp	d8, d0
    141c:      	b.pl	0x1450 <ltmp0+0x1450>
    1420:      	ldurb	w9, [x8, #-0x8]
    1424:      	ldrb	w11, [x8, #0x8]
    1428:      	fcmp	d8, #0.0
    142c:      	ccmp	w9, #0xb, #0x0, ge
    1430:      	ccmp	w11, #0x9, #0x2, eq
    1434:      	b.hs	0x1450 <ltmp0+0x1450>
    1438:      	fcvtzs	x9, d8
    143c:      	scvtf	d0, x9
    1440:      	ldr	w12, [x8]
    1444:      	fcmp	d8, d0
    1448:      	ccmp	x9, x12, #0x2, eq
    144c:      	b.lo	0x1518 <ltmp0+0x1518>
    1450:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		0000000000001450:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__6
    1454:      	add	x9, x9, #0x0
		0000000000001454:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__6
    1458:      	ldr	x11, [x9]
    145c:      	cmp	x11, #0x0
    1460:      	csel	x12, x9, x11, eq
    1464:      	cmp	x13, x22
    1468:      	b.ne	0x17e0 <ltmp0+0x17e0>
    146c:      	fcmp	d8, #0.0
    1470:      	b.lt	0x17e0 <ltmp0+0x17e0>
    1474:      	fcmp	d8, d9
    1478:      	b.pl	0x17e0 <ltmp0+0x17e0>
    147c:      	mov	x9, #-0x20000000000     ; =-2199023255552
    1480:      	add	x9, x8, x9
    1484:      	lsr	x9, x9, #41
    1488:      	cmp	x9, #0x3f
    148c:      	b.hs	0x17e0 <ltmp0+0x17e0>
    1490:      	fcvtzs	x9, d8
    1494:      	scvtf	d0, x9
    1498:      	fcmp	d8, d0
    149c:      	b.ne	0x17e0 <ltmp0+0x17e0>
    14a0:      	ldursb	w13, [x8, #-0x7]
    14a4:      	tbnz	w13, #0x1f, 0x17e0 <ltmp0+0x17e0>
    14a8:      	ldurb	w13, [x8, #-0x8]
    14ac:      	cmp	w13, #0x9
    14b0:      	b.eq	0x15b0 <ltmp0+0x15b0>
    14b4:      	cmp	w13, #0x2
    14b8:      	b.eq	0x1560 <ltmp0+0x1560>
    14bc:      	cmp	w13, #0x1
    14c0:      	b.ne	0x17e0 <ltmp0+0x17e0>
    14c4:      	ldr	w10, [x8]
    14c8:      	mov	x11, x8
    14cc:      	ldurh	w13, [x8, #-0x6]
    14d0:      	adrp	x12, 0x1000 <ltmp0+0x1000>
		00000000000014d0:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    14d4:      	ldr	x12, [x12]
		00000000000014d4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    14d8:      	ldrb	w12, [x12]
    14dc:      	ldr	w8, [x8, #0x4]
    14e0:      	cmp	x10, x8
    14e4:      	b.hi	0x17e0 <ltmp0+0x17e0>
    14e8:      	tbnz	w13, #0xa, 0x17e0 <ltmp0+0x17e0>
    14ec:      	cbnz	w12, 0x17e0 <ltmp0+0x17e0>
    14f0:      	cmp	x9, x10
    14f4:      	b.hs	0x17e0 <ltmp0+0x17e0>
    14f8:      	add	x8, x11, x9, lsl #3
    14fc:      	ldr	d0, [x8, #0x8]
    1500:      	fmov	x8, d0
    1504:      	mov	x9, #0x10               ; =16
    1508:      	movk	x9, #0x7ffc, lsl #48
    150c:      	cmp	x8, x9
    1510:      	fcsel	d0, d10, d0, eq
    1514:      	b	0x1800 <ltmp0+0x1800>
    1518:      	add	x8, x8, #0x10
    151c:      	cmp	w11, #0x3
    1520:      	b.le	0x1544 <ltmp0+0x1544>
    1524:      	cmp	w11, #0x5
    1528:      	b.gt	0x15fc <ltmp0+0x15fc>
    152c:      	cmp	w11, #0x4
    1530:      	b.eq	0x1694 <ltmp0+0x1694>
    1534:      	cmp	w11, #0x5
    1538:      	b.ne	0x1688 <ltmp0+0x1688>
    153c:      	ldr	s0, [x8, x9, lsl #2]
    1540:      	b	0x168c <ltmp0+0x168c>
    1544:      	cbz	w11, 0x1680 <ltmp0+0x1680>
    1548:      	cmp	w11, #0x2
    154c:      	b.eq	0x16a8 <ltmp0+0x16a8>
    1550:      	cmp	w11, #0x3
    1554:      	b.ne	0x1688 <ltmp0+0x1688>
    1558:      	ldr	h0, [x8, x9, lsl #1]
    155c:      	b	0x168c <ltmp0+0x168c>
    1560:      	ldr	x10, [x8, #0x8]
    1564:      	cbz	x10, 0x1614 <ltmp0+0x1614>
    1568:      	ldr	x13, [x10, #0x60]
    156c:      	cbz	x13, 0x1614 <ltmp0+0x1614>
    1570:      	ldurb	w8, [x13, #-0x8]
    1574:      	cmp	w8, #0x1
    1578:      	b.ne	0x17e0 <ltmp0+0x17e0>
    157c:      	ldursb	w8, [x13, #-0x7]
    1580:      	tbnz	w8, #0x1f, 0x17e0 <ltmp0+0x17e0>
    1584:      	ldr	w8, [x13]
    1588:      	cmp	x9, x8
    158c:      	b.hs	0x17e0 <ltmp0+0x17e0>
    1590:      	add	x8, x13, x9, lsl #3
    1594:      	ldr	d0, [x8, #0x8]
    1598:      	fmov	x8, d0
    159c:      	mov	x9, #0x10               ; =16
    15a0:      	movk	x9, #0x7ffc, lsl #48
    15a4:      	cmp	x8, x9
    15a8:      	b.eq	0x17e0 <ltmp0+0x17e0>
    15ac:      	b	0x1800 <ltmp0+0x1800>
    15b0:      	ldr	w12, [x8, #0x4]
    15b4:      	ldr	x11, [x8, #0x20]
    15b8:      	ldurh	w13, [x8, #-0x6]
    15bc:      	tst	w13, #0xc00
    15c0:      	mov	w13, #0x5841            ; =22593
    15c4:      	movk	w13, #0x4c5a, lsl #16
    15c8:      	ccmp	w12, w13, #0x0, eq
    15cc:      	cset	w12, eq
    15d0:      	cbz	x11, 0x1648 <ltmp0+0x1648>
    15d4:      	tbz	w12, #0x0, 0x1648 <ltmp0+0x1648>
    15d8:      	ldurb	w10, [x11, #-0x8]
    15dc:      	cmp	w10, #0x1
    15e0:      	b.ne	0x17e0 <ltmp0+0x17e0>
    15e4:      	ldursb	w10, [x11, #-0x7]
    15e8:      	tbnz	w10, #0x1f, 0x17e0 <ltmp0+0x17e0>
    15ec:      	ldr	w10, [x11]
    15f0:      	str	w10, [x8]
    15f4:      	mov	x8, x11
    15f8:      	b	0x14cc <ltmp0+0x14cc>
    15fc:      	cmp	w11, #0x6
    1600:      	b.eq	0x169c <ltmp0+0x169c>
    1604:      	cmp	w11, #0x7
    1608:      	b.ne	0x1688 <ltmp0+0x1688>
    160c:      	ldr	d0, [x8, x9, lsl #3]
    1610:      	b	0x1800 <ltmp0+0x1800>
    1614:      	ldr	x12, [x12]
    1618:      	cbz	x12, 0x17e0 <ltmp0+0x17e0>
    161c:      	tbnz	x12, #0x3f, 0x16b4 <ltmp0+0x16b4>
    1620:      	ldp	w14, w13, [x8]
    1624:      	orr	x13, x13, x14, lsl #32
    1628:      	cmp	x13, x12
    162c:      	b.ne	0x17e0 <ltmp0+0x17e0>
    1630:      	ldp	x14, x12, [x11, #0x8]
    1634:      	ldp	x13, x11, [x11, #0x18]
    1638:      	cmp	x14, x11
    163c:      	b.lo	0x16d4 <ltmp0+0x16d4>
    1640:      	cbz	x10, 0x17e0 <ltmp0+0x17e0>
    1644:      	b	0x1724 <ltmp0+0x1724>
    1648:      	cmp	x11, #0x0
    164c:      	ldr	w14, [x8]
    1650:      	ldp	x11, x13, [x8, #0x28]
    1654:      	ccmp	x9, x14, #0x2, eq
    1658:      	ccmp	x11, #0x0, #0x4, lo
    165c:      	ccmp	x13, #0x0, #0x4, ne
    1660:      	csel	w12, wzr, w12, eq
    1664:      	tbz	w12, #0x0, 0x17e0 <ltmp0+0x17e0>
    1668:      	lsr	x12, x9, #6
    166c:      	ldr	x12, [x13, x12, lsl #3]
    1670:      	lsr	x12, x12, x9
    1674:      	tbz	w12, #0x0, 0x16e0 <ltmp0+0x16e0>
    1678:      	ldr	d0, [x11, x9, lsl #3]
    167c:      	b	0x1800 <ltmp0+0x1800>
    1680:      	ldrsb	w8, [x8, x9]
    1684:      	b	0x16ac <ltmp0+0x16ac>
    1688:      	ldr	b0, [x8, x9]
    168c:      	ucvtf	d0, d0
    1690:      	b	0x1800 <ltmp0+0x1800>
    1694:      	ldr	w8, [x8, x9, lsl #2]
    1698:      	b	0x16ac <ltmp0+0x16ac>
    169c:      	ldr	s0, [x8, x9, lsl #2]
    16a0:      	fcvt	d0, s0
    16a4:      	b	0x1800 <ltmp0+0x1800>
    16a8:      	ldrsh	w8, [x8, x9, lsl #1]
    16ac:      	scvtf	d0, w8
    16b0:      	b	0x1800 <ltmp0+0x1800>
    16b4:      	cbz	x10, 0x17e0 <ltmp0+0x17e0>
    16b8:      	ldr	x13, [x10, #0x30]
    16bc:      	cmp	x13, x12
    16c0:      	b.ne	0x17e0 <ltmp0+0x17e0>
    16c4:      	ldp	x14, x12, [x11, #0x8]
    16c8:      	ldp	x13, x11, [x11, #0x18]
    16cc:      	cmp	x14, x11
    16d0:      	b.hs	0x1724 <ltmp0+0x1724>
    16d4:      	add	x14, x8, x14, lsl #3
    16d8:      	add	x14, x14, #0x10
    16dc:      	b	0x1748 <ltmp0+0x1748>
    16e0:      	ldr	x8, [x8, #0x50]
    16e4:      	mov	w12, #0x6903            ; =26883
    16e8:      	movk	w12, #0x64, lsl #16
    16ec:      	cmp	x8, x12
    16f0:      	b.eq	0x16f8 <ltmp0+0x16f8>
    16f4:      	cbnz	x8, 0x17e0 <ltmp0+0x17e0>
    16f8:      	mov	w12, #0x6903            ; =26883
    16fc:      	movk	w12, #0x64, lsl #16
    1700:      	cmp	x8, x12
    1704:      	b.ne	0x17b0 <ltmp0+0x17b0>
    1708:      	ldr	x8, [x11, x9, lsl #3]
    170c:      	cbz	x8, 0x17b0 <ltmp0+0x17b0>
    1710:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    1714:      	cmp	x8, x9
    1718:      	csel	x8, xzr, x8, eq
    171c:      	fmov	d1, x8
    1720:      	b	0x19f8 <ltmp0+0x19f8>
    1724:      	ldr	x16, [x10, #0x20]
    1728:      	cmp	x16, #0x0
    172c:      	csel	x15, x16, x10, ne
    1730:      	cbz	x16, 0x17e0 <ltmp0+0x17e0>
    1734:      	ldr	w16, [x15]
    1738:      	cmp	x14, x16
    173c:      	b.hs	0x17e0 <ltmp0+0x17e0>
    1740:      	add	x14, x15, x14, lsl #3
    1744:      	add	x14, x14, #0x8
    1748:      	ldr	d0, [x14]
    174c:      	fcmp	d8, d0
    1750:      	ccmp	x13, x9, #0x0, mi
    1754:      	cset	w13, hi
    1758:      	add	x9, x12, x9
    175c:      	cmp	x9, x11
    1760:      	ccmp	w13, #0x0, #0x4, lo
    1764:      	b.ne	0x17a4 <ltmp0+0x17a4>
    1768:      	cbz	x10, 0x17e0 <ltmp0+0x17e0>
    176c:      	cmp	x9, x11
    1770:      	b.lo	0x17e0 <ltmp0+0x17e0>
    1774:      	eor	w8, w13, #0x1
    1778:      	tbnz	w8, #0x0, 0x17e0 <ltmp0+0x17e0>
    177c:      	ldr	x11, [x10, #0x20]
    1780:      	cmp	x11, #0x0
    1784:      	csel	x8, x11, x10, ne
    1788:      	cbz	x11, 0x17e0 <ltmp0+0x17e0>
    178c:      	ldr	w10, [x8]
    1790:      	cmp	x9, x10
    1794:      	b.hs	0x17e0 <ltmp0+0x17e0>
    1798:      	add	x8, x8, x9, lsl #3
    179c:      	ldr	d0, [x8, #0x8]
    17a0:      	b	0x1800 <ltmp0+0x1800>
    17a4:      	add	x8, x8, x9, lsl #3
    17a8:      	ldr	d0, [x8, #0x10]
    17ac:      	b	0x1800 <ltmp0+0x1800>
    17b0:      	fmov	d0, x10
    17b4:      	mov.16b	v1, v8
    17b8:      	adrp	x0, 0x1000 <ltmp0+0x1000>
		00000000000017b8:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    17bc:      	add	x0, x0, #0x0
		00000000000017bc:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    17c0:      	mov	w1, #0x2                ; =2
    17c4:      	bl	0x17c4 <ltmp0+0x17c4>
		00000000000017c4:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    17c8:      	mov.16b	v1, v0
    17cc:      	fmov	x8, d1
    17d0:      	mov	x9, #0x10               ; =16
    17d4:      	movk	x9, #0x7ffc, lsl #48
    17d8:      	cmp	x8, x9
    17dc:      	b.ne	0x19f8 <ltmp0+0x19f8>
    17e0:      	fmov	d0, x26
    17e4:      	str	x20, [sp, #0x18]
    17e8:      	mov.16b	v1, v8
    17ec:      	adrp	x0, 0x1000 <ltmp0+0x1000>
		00000000000017ec:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__6
    17f0:      	add	x0, x0, #0x0
		00000000000017f0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__6
    17f4:      	bl	0x17f4 <ltmp0+0x17f4>
		00000000000017f4:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    17f8:      	ldp	x26, x27, [sp, #0x8]
    17fc:      	ldr	x20, [sp, #0x18]
    1800:      	fmov	x8, d0
    1804:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    1808:      	and	x9, x8, x9
    180c:      	cmp	x9, x22
    1810:      	b.ne	0x187c <ltmp0+0x187c>
    1814:      	and	x0, x8, #0xffffffffffff
    1818:      	lsr	x8, x0, #20
    181c:      	cbz	x8, 0x19d0 <ltmp0+0x19d0>
    1820:      	ldurb	w9, [x0, #-0x8]
    1824:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		0000000000001824:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__8
    1828:      	ldr	x8, [x8]
		0000000000001828:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__8
    182c:      	cbz	x8, 0x18ec <ltmp0+0x18ec>
    1830:      	ldurh	w10, [x0, #-0x6]
    1834:      	and	w10, w10, #0x800
    1838:      	cmp	w9, #0x2
    183c:      	ccmp	w10, #0x0, #0x0, eq
    1840:      	b.ne	0x18ec <ltmp0+0x18ec>
    1844:      	ldr	w10, [x0, #0x4]
    1848:      	orr	x9, x10, #0x4000000000000000
    184c:      	ldr	x11, [x8]
    1850:      	cmp	w10, #0x0
    1854:      	ccmp	x9, x11, #0x0, ne
    1858:      	b.eq	0x1924 <ltmp0+0x1924>
    185c:      	ldr	x11, [x8, #0x10]
    1860:      	cbz	x11, 0x1948 <ltmp0+0x1948>
    1864:      	ldr	x12, [x0, #0x8]
    1868:      	cbz	x12, 0x1948 <ltmp0+0x1948>
    186c:      	ldr	x12, [x12, #0x30]
    1870:      	cmp	x12, x11
    1874:      	b.eq	0x1914 <ltmp0+0x1914>
    1878:      	b	0x1948 <ltmp0+0x1948>
    187c:      	lsr	x9, x8, #48
    1880:      	mov	w10, #0x7ff9            ; =32761
    1884:      	cmp	x9, x10
    1888:      	b.eq	0x18d0 <ltmp0+0x18d0>
    188c:      	mov	w10, #0x7ffe            ; =32766
    1890:      	cmp	w9, w10
    1894:      	b.ne	0x18c0 <ltmp0+0x18c0>
    1898:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		0000000000001898:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    189c:      	ldr	x9, [x9]
		000000000000189c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    18a0:      	str	x20, [sp, #0x18]
    18a4:      	and	x2, x9, #0xffffffffffff
    18a8:      	mov	x0, #0x7                ; =7
    18ac:      	movk	x0, #0xddae, lsl #32
    18b0:      	movk	x0, #0x5556, lsl #48
    18b4:      	mov	x1, x8
    18b8:      	bl	0x18b8 <ltmp0+0x18b8>
		00000000000018b8:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    18bc:      	b	0x19ec <ltmp0+0x19ec>
    18c0:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    18c4:      	add	x9, x8, x9
    18c8:      	cmp	x9, #0x2
    18cc:      	b.lo	0x302c <ltmp0+0x302c>
    18d0:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		00000000000018d0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    18d4:      	ldr	x9, [x9]
		00000000000018d4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    18d8:      	str	x20, [sp, #0x18]
    18dc:      	and	x1, x9, #0xffffffffffff
    18e0:      	mov	x0, x8
    18e4:      	bl	0x18e4 <ltmp0+0x18e4>
		00000000000018e4:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    18e8:      	b	0x19ec <ltmp0+0x19ec>
    18ec:      	cmp	w9, #0x2
    18f0:      	ccmp	x8, #0x0, #0x4, eq
    18f4:      	b.eq	0x19d0 <ltmp0+0x19d0>
    18f8:      	ldr	x9, [x8, #0x10]
    18fc:      	cbz	x9, 0x19d0 <ltmp0+0x19d0>
    1900:      	ldr	x10, [x0, #0x8]
    1904:      	cbz	x10, 0x19d0 <ltmp0+0x19d0>
    1908:      	ldr	x10, [x10, #0x30]
    190c:      	cmp	x10, x9
    1910:      	b.ne	0x19d0 <ltmp0+0x19d0>
    1914:      	ldr	x8, [x8, #0x8]
    1918:      	add	x8, x0, x8, lsl #3
    191c:      	ldr	d1, [x8, #0x10]
    1920:      	b	0x19f8 <ltmp0+0x19f8>
    1924:      	ldr	x2, [x8, #0x8]
    1928:      	tbnz	w2, #0x1e, 0x1cd0 <ltmp0+0x1cd0>
    192c:      	add	x11, x0, x2, lsl #3
    1930:      	ldr	d1, [x11, #0x10]
    1934:      	fmov	x11, d1
    1938:      	mov	x12, #0x10              ; =16
    193c:      	movk	x12, #0x7ffc, lsl #48
    1940:      	cmp	x11, x12
    1944:      	b.ne	0x19f8 <ltmp0+0x19f8>
    1948:      	ldr	x11, [x8, #0x18]
    194c:      	cmp	x11, #0x0
    1950:      	b.le	0x19d0 <ltmp0+0x19d0>
    1954:      	ldr	x11, [x8, #0x20]
    1958:      	ldr	x12, [x8, #0x30]
    195c:      	ldr	x13, [x8, #0x40]
    1960:      	cmp	x13, x9
    1964:      	ldr	x14, [x8, #0x50]
    1968:      	ccmp	x14, x9, #0x4, ne
    196c:      	ccmp	x12, x9, #0x4, ne
    1970:      	ccmp	x11, x9, #0x4, ne
    1974:      	cset	w15, eq
    1978:      	cmp	w10, #0x0
    197c:      	ccmp	w15, #0x0, #0x4, ne
    1980:      	b.eq	0x19d0 <ltmp0+0x19d0>
    1984:      	ldr	x10, [x8, #0x48]
    1988:      	ldr	x15, [x8, #0x58]
    198c:      	cmp	x14, x9
    1990:      	csel	x14, x15, xzr, eq
    1994:      	cmp	x13, x9
    1998:      	csel	x10, x10, x14, eq
    199c:      	ldr	x13, [x8, #0x28]
    19a0:      	ldr	x8, [x8, #0x38]
    19a4:      	cmp	x12, x9
    19a8:      	csel	x8, x8, x10, eq
    19ac:      	cmp	x11, x9
    19b0:      	csel	x8, x13, x8, eq
    19b4:      	add	x8, x0, x8, lsl #3
    19b8:      	ldr	d1, [x8, #0x10]
    19bc:      	fmov	x8, d1
    19c0:      	mov	x9, #0x10               ; =16
    19c4:      	movk	x9, #0x7ffc, lsl #48
    19c8:      	cmp	x8, x9
    19cc:      	b.ne	0x19f8 <ltmp0+0x19f8>
    19d0:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		00000000000019d0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    19d4:      	ldr	x8, [x8]
		00000000000019d4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    19d8:      	str	x20, [sp, #0x18]
    19dc:      	and	x1, x8, #0xffffffffffff
    19e0:      	adrp	x2, 0x1000 <ltmp0+0x1000>
		00000000000019e0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__8
    19e4:      	add	x2, x2, #0x0
		00000000000019e4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__8
    19e8:      	bl	0x19e8 <ltmp0+0x19e8>
		00000000000019e8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    19ec:      	mov.16b	v1, v0
    19f0:      	ldp	x26, x27, [sp, #0x8]
    19f4:      	ldr	x20, [sp, #0x18]
    19f8:      	fmov	d0, x20
    19fc:      	and	x9, x20, #0xffff000000000000
    1a00:      	fmov	x8, d1
    1a04:      	and	x10, x8, #0xffff000000000000
    1a08:      	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
    1a0c:      	cmp	x8, x11
    1a10:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    1a14:      	ccmp	x10, x8, #0x2, hs
    1a18:      	cset	w8, hi
    1a1c:      	mov	x10, #0x1               ; =1
    1a20:      	movk	x10, #0x7fff, lsl #48
    1a24:      	cmp	x9, x10
    1a28:      	ccmp	x20, x21, #0x0, lo
    1a2c:      	b.hi	0x1a3c <ltmp0+0x1a3c>
    1a30:      	tbz	w8, #0x0, 0x1a3c <ltmp0+0x1a3c>
    1a34:      	fadd	d0, d1, d0
    1a38:      	b	0x1a44 <ltmp0+0x1a44>
    1a3c:      	bl	0x1a3c <ltmp0+0x1a3c>
		0000000000001a3c:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    1a40:      	ldp	x26, x27, [sp, #0x8]
    1a44:      	fmov	x20, d0
    1a48:      	mov	x0, x20
    1a4c:      	ldr	w8, [x23]
    1a50:      	cbz	w8, 0x1a58 <ltmp0+0x1a58>
    1a54:      	bl	0x1a54 <ltmp0+0x1a54>
		0000000000001a54:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    1a58:      	mov	x0, x20
    1a5c:      	ldr	w8, [x23]
    1a60:      	cbz	w8, 0x1a68 <ltmp0+0x1a68>
    1a64:      	bl	0x1a64 <ltmp0+0x1a64>
		0000000000001a64:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    1a68:      	mov	x10, x26
    1a6c:      	and	x8, x10, #0xffffffffffff
    1a70:      	and	x13, x10, #0xffff000000000000
    1a74:      	cmp	x13, x22
    1a78:      	b.ne	0x1ad8 <ltmp0+0x1ad8>
    1a7c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		0000000000001a7c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    1a80:      	ldr	x9, [x9]
		0000000000001a80:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    1a84:      	ldr	x9, [x9]
    1a88:      	cbnz	x9, 0x1ad8 <ltmp0+0x1ad8>
    1a8c:      	sub	x9, x8, #0x100, lsl #12 ; =0x100000
    1a90:      	cmp	x9, x19
    1a94:      	b.hs	0x1ad8 <ltmp0+0x1ad8>
    1a98:      	fcmp	d8, d11
    1a9c:      	b.pl	0x1ad8 <ltmp0+0x1ad8>
    1aa0:      	fcmp	d8, #0.0
    1aa4:      	b.lt	0x1ad8 <ltmp0+0x1ad8>
    1aa8:      	ldurb	w9, [x8, #-0x8]
    1aac:      	cmp	w9, #0xb
    1ab0:      	b.ne	0x1ad8 <ltmp0+0x1ad8>
    1ab4:      	ldrb	w11, [x8, #0x8]
    1ab8:      	cmp	w11, #0x9
    1abc:      	b.hs	0x1ad8 <ltmp0+0x1ad8>
    1ac0:      	fcvtzs	x9, d8
    1ac4:      	scvtf	d0, x9
    1ac8:      	ldr	w12, [x8]
    1acc:      	fcmp	d8, d0
    1ad0:      	ccmp	x9, x12, #0x2, eq
    1ad4:      	b.lo	0x1ba0 <ltmp0+0x1ba0>
    1ad8:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		0000000000001ad8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__9
    1adc:      	add	x9, x9, #0x0
		0000000000001adc:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__9
    1ae0:      	ldr	x11, [x9]
    1ae4:      	cmp	x11, #0x0
    1ae8:      	csel	x12, x9, x11, eq
    1aec:      	cmp	x13, x22
    1af0:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1af4:      	fcmp	d8, #0.0
    1af8:      	b.lt	0x1e80 <ltmp0+0x1e80>
    1afc:      	fcmp	d8, d9
    1b00:      	b.pl	0x1e80 <ltmp0+0x1e80>
    1b04:      	mov	x9, #-0x20000000000     ; =-2199023255552
    1b08:      	add	x9, x8, x9
    1b0c:      	lsr	x9, x9, #41
    1b10:      	cmp	x9, #0x3f
    1b14:      	b.hs	0x1e80 <ltmp0+0x1e80>
    1b18:      	fcvtzs	x9, d8
    1b1c:      	scvtf	d0, x9
    1b20:      	fcmp	d8, d0
    1b24:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1b28:      	ldursb	w13, [x8, #-0x7]
    1b2c:      	tbnz	w13, #0x1f, 0x1e80 <ltmp0+0x1e80>
    1b30:      	ldurb	w13, [x8, #-0x8]
    1b34:      	cmp	w13, #0x9
    1b38:      	b.eq	0x1c38 <ltmp0+0x1c38>
    1b3c:      	cmp	w13, #0x2
    1b40:      	b.eq	0x1be8 <ltmp0+0x1be8>
    1b44:      	cmp	w13, #0x1
    1b48:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1b4c:      	ldr	w10, [x8]
    1b50:      	mov	x11, x8
    1b54:      	ldurh	w13, [x8, #-0x6]
    1b58:      	adrp	x12, 0x1000 <ltmp0+0x1000>
		0000000000001b58:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    1b5c:      	ldr	x12, [x12]
		0000000000001b5c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    1b60:      	ldrb	w12, [x12]
    1b64:      	ldr	w8, [x8, #0x4]
    1b68:      	cmp	x10, x8
    1b6c:      	b.hi	0x1e80 <ltmp0+0x1e80>
    1b70:      	tbnz	w13, #0xa, 0x1e80 <ltmp0+0x1e80>
    1b74:      	cbnz	w12, 0x1e80 <ltmp0+0x1e80>
    1b78:      	cmp	x9, x10
    1b7c:      	b.hs	0x1e80 <ltmp0+0x1e80>
    1b80:      	add	x8, x11, x9, lsl #3
    1b84:      	ldr	d0, [x8, #0x8]
    1b88:      	fmov	x8, d0
    1b8c:      	mov	x9, #0x10               ; =16
    1b90:      	movk	x9, #0x7ffc, lsl #48
    1b94:      	cmp	x8, x9
    1b98:      	fcsel	d0, d10, d0, eq
    1b9c:      	b	0x1ea0 <ltmp0+0x1ea0>
    1ba0:      	add	x8, x8, #0x10
    1ba4:      	cmp	w11, #0x3
    1ba8:      	b.le	0x1bcc <ltmp0+0x1bcc>
    1bac:      	cmp	w11, #0x5
    1bb0:      	b.gt	0x1c84 <ltmp0+0x1c84>
    1bb4:      	cmp	w11, #0x4
    1bb8:      	b.eq	0x1d3c <ltmp0+0x1d3c>
    1bbc:      	cmp	w11, #0x5
    1bc0:      	b.ne	0x1d30 <ltmp0+0x1d30>
    1bc4:      	ldr	s0, [x8, x9, lsl #2]
    1bc8:      	b	0x1d34 <ltmp0+0x1d34>
    1bcc:      	cbz	w11, 0x1d28 <ltmp0+0x1d28>
    1bd0:      	cmp	w11, #0x2
    1bd4:      	b.eq	0x1d50 <ltmp0+0x1d50>
    1bd8:      	cmp	w11, #0x3
    1bdc:      	b.ne	0x1d30 <ltmp0+0x1d30>
    1be0:      	ldr	h0, [x8, x9, lsl #1]
    1be4:      	b	0x1d34 <ltmp0+0x1d34>
    1be8:      	ldr	x10, [x8, #0x8]
    1bec:      	cbz	x10, 0x1c9c <ltmp0+0x1c9c>
    1bf0:      	ldr	x13, [x10, #0x60]
    1bf4:      	cbz	x13, 0x1c9c <ltmp0+0x1c9c>
    1bf8:      	ldurb	w8, [x13, #-0x8]
    1bfc:      	cmp	w8, #0x1
    1c00:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1c04:      	ldursb	w8, [x13, #-0x7]
    1c08:      	tbnz	w8, #0x1f, 0x1e80 <ltmp0+0x1e80>
    1c0c:      	ldr	w8, [x13]
    1c10:      	cmp	x9, x8
    1c14:      	b.hs	0x1e80 <ltmp0+0x1e80>
    1c18:      	add	x8, x13, x9, lsl #3
    1c1c:      	ldr	d0, [x8, #0x8]
    1c20:      	fmov	x8, d0
    1c24:      	mov	x9, #0x10               ; =16
    1c28:      	movk	x9, #0x7ffc, lsl #48
    1c2c:      	cmp	x8, x9
    1c30:      	b.eq	0x1e80 <ltmp0+0x1e80>
    1c34:      	b	0x1ea0 <ltmp0+0x1ea0>
    1c38:      	ldr	w12, [x8, #0x4]
    1c3c:      	ldr	x11, [x8, #0x20]
    1c40:      	ldurh	w13, [x8, #-0x6]
    1c44:      	tst	w13, #0xc00
    1c48:      	mov	w13, #0x5841            ; =22593
    1c4c:      	movk	w13, #0x4c5a, lsl #16
    1c50:      	ccmp	w12, w13, #0x0, eq
    1c54:      	cset	w12, eq
    1c58:      	cbz	x11, 0x1cf0 <ltmp0+0x1cf0>
    1c5c:      	tbz	w12, #0x0, 0x1cf0 <ltmp0+0x1cf0>
    1c60:      	ldurb	w10, [x11, #-0x8]
    1c64:      	cmp	w10, #0x1
    1c68:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1c6c:      	ldursb	w10, [x11, #-0x7]
    1c70:      	tbnz	w10, #0x1f, 0x1e80 <ltmp0+0x1e80>
    1c74:      	ldr	w10, [x11]
    1c78:      	str	w10, [x8]
    1c7c:      	mov	x8, x11
    1c80:      	b	0x1b54 <ltmp0+0x1b54>
    1c84:      	cmp	w11, #0x6
    1c88:      	b.eq	0x1d44 <ltmp0+0x1d44>
    1c8c:      	cmp	w11, #0x7
    1c90:      	b.ne	0x1d30 <ltmp0+0x1d30>
    1c94:      	ldr	d0, [x8, x9, lsl #3]
    1c98:      	b	0x1ea0 <ltmp0+0x1ea0>
    1c9c:      	ldr	x12, [x12]
    1ca0:      	cbz	x12, 0x1e80 <ltmp0+0x1e80>
    1ca4:      	tbnz	x12, #0x3f, 0x1d5c <ltmp0+0x1d5c>
    1ca8:      	ldp	w14, w13, [x8]
    1cac:      	orr	x13, x13, x14, lsl #32
    1cb0:      	cmp	x13, x12
    1cb4:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1cb8:      	ldp	x14, x12, [x11, #0x8]
    1cbc:      	ldp	x13, x11, [x11, #0x18]
    1cc0:      	cmp	x14, x11
    1cc4:      	b.lo	0x1d7c <ltmp0+0x1d7c>
    1cc8:      	cbz	x10, 0x1e80 <ltmp0+0x1e80>
    1ccc:      	b	0x1dc8 <ltmp0+0x1dc8>
    1cd0:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		0000000000001cd0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    1cd4:      	ldr	x8, [x8]
		0000000000001cd4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    1cd8:      	str	x20, [sp, #0x18]
    1cdc:      	and	x1, x8, #0xffffffffffff
    1ce0:      	adrp	x3, 0x1000 <ltmp0+0x1000>
		0000000000001ce0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__8
    1ce4:      	add	x3, x3, #0x0
		0000000000001ce4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__8
    1ce8:      	bl	0x1ce8 <ltmp0+0x1ce8>
		0000000000001ce8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    1cec:      	b	0x19ec <ltmp0+0x19ec>
    1cf0:      	cmp	x11, #0x0
    1cf4:      	ldr	w14, [x8]
    1cf8:      	ldp	x11, x13, [x8, #0x28]
    1cfc:      	ccmp	x9, x14, #0x2, eq
    1d00:      	ccmp	x11, #0x0, #0x4, lo
    1d04:      	ccmp	x13, #0x0, #0x4, ne
    1d08:      	csel	w12, wzr, w12, eq
    1d0c:      	tbz	w12, #0x0, 0x1e80 <ltmp0+0x1e80>
    1d10:      	lsr	x12, x9, #6
    1d14:      	ldr	x12, [x13, x12, lsl #3]
    1d18:      	lsr	x12, x12, x9
    1d1c:      	tbz	w12, #0x0, 0x1d88 <ltmp0+0x1d88>
    1d20:      	ldr	d0, [x11, x9, lsl #3]
    1d24:      	b	0x1ea0 <ltmp0+0x1ea0>
    1d28:      	ldrsb	w8, [x8, x9]
    1d2c:      	b	0x1d54 <ltmp0+0x1d54>
    1d30:      	ldr	b0, [x8, x9]
    1d34:      	ucvtf	d0, d0
    1d38:      	b	0x1ea0 <ltmp0+0x1ea0>
    1d3c:      	ldr	w8, [x8, x9, lsl #2]
    1d40:      	b	0x1d54 <ltmp0+0x1d54>
    1d44:      	ldr	s0, [x8, x9, lsl #2]
    1d48:      	fcvt	d0, s0
    1d4c:      	b	0x1ea0 <ltmp0+0x1ea0>
    1d50:      	ldrsh	w8, [x8, x9, lsl #1]
    1d54:      	scvtf	d0, w8
    1d58:      	b	0x1ea0 <ltmp0+0x1ea0>
    1d5c:      	cbz	x10, 0x1e80 <ltmp0+0x1e80>
    1d60:      	ldr	x13, [x10, #0x30]
    1d64:      	cmp	x13, x12
    1d68:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1d6c:      	ldp	x14, x12, [x11, #0x8]
    1d70:      	ldp	x13, x11, [x11, #0x18]
    1d74:      	cmp	x14, x11
    1d78:      	b.hs	0x1dc8 <ltmp0+0x1dc8>
    1d7c:      	add	x14, x8, x14, lsl #3
    1d80:      	add	x14, x14, #0x10
    1d84:      	b	0x1dec <ltmp0+0x1dec>
    1d88:      	ldr	x8, [x8, #0x50]
    1d8c:      	mov	x12, #0x6e05            ; =28165
    1d90:      	movk	x12, #0x6d61, lsl #16
    1d94:      	movk	x12, #0x65, lsl #32
    1d98:      	cmp	x8, x12
    1d9c:      	b.eq	0x1da4 <ltmp0+0x1da4>
    1da0:      	cbnz	x8, 0x1e80 <ltmp0+0x1e80>
    1da4:      	cmp	x8, x12
    1da8:      	b.ne	0x1e54 <ltmp0+0x1e54>
    1dac:      	ldr	x8, [x11, x9, lsl #3]
    1db0:      	cbz	x8, 0x1e54 <ltmp0+0x1e54>
    1db4:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    1db8:      	cmp	x8, x9
    1dbc:      	csel	x8, xzr, x8, eq
    1dc0:      	fmov	d0, x8
    1dc4:      	b	0x2090 <ltmp0+0x2090>
    1dc8:      	ldr	x16, [x10, #0x20]
    1dcc:      	cmp	x16, #0x0
    1dd0:      	csel	x15, x16, x10, ne
    1dd4:      	cbz	x16, 0x1e80 <ltmp0+0x1e80>
    1dd8:      	ldr	w16, [x15]
    1ddc:      	cmp	x14, x16
    1de0:      	b.hs	0x1e80 <ltmp0+0x1e80>
    1de4:      	add	x14, x15, x14, lsl #3
    1de8:      	add	x14, x14, #0x8
    1dec:      	ldr	d0, [x14]
    1df0:      	fcmp	d8, d0
    1df4:      	ccmp	x13, x9, #0x0, mi
    1df8:      	cset	w13, hi
    1dfc:      	add	x9, x12, x9
    1e00:      	cmp	x9, x11
    1e04:      	b.hs	0x1e18 <ltmp0+0x1e18>
    1e08:      	cbz	w13, 0x1e18 <ltmp0+0x1e18>
    1e0c:      	add	x8, x8, x9, lsl #3
    1e10:      	ldr	d0, [x8, #0x10]
    1e14:      	b	0x1ea0 <ltmp0+0x1ea0>
    1e18:      	cbz	x10, 0x1e80 <ltmp0+0x1e80>
    1e1c:      	cmp	x9, x11
    1e20:      	b.lo	0x1e80 <ltmp0+0x1e80>
    1e24:      	eor	w8, w13, #0x1
    1e28:      	tbnz	w8, #0x0, 0x1e80 <ltmp0+0x1e80>
    1e2c:      	ldr	x11, [x10, #0x20]
    1e30:      	cmp	x11, #0x0
    1e34:      	csel	x8, x11, x10, ne
    1e38:      	cbz	x11, 0x1e80 <ltmp0+0x1e80>
    1e3c:      	ldr	w10, [x8]
    1e40:      	cmp	x9, x10
    1e44:      	b.hs	0x1e80 <ltmp0+0x1e80>
    1e48:      	add	x8, x8, x9, lsl #3
    1e4c:      	ldr	d0, [x8, #0x8]
    1e50:      	b	0x1ea0 <ltmp0+0x1ea0>
    1e54:      	fmov	d0, x10
    1e58:      	mov.16b	v1, v8
    1e5c:      	adrp	x0, 0x1000 <ltmp0+0x1000>
		0000000000001e5c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.4.bytes
    1e60:      	add	x0, x0, #0x0
		0000000000001e60:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.4.bytes
    1e64:      	mov	w1, #0x4                ; =4
    1e68:      	bl	0x1e68 <ltmp0+0x1e68>
		0000000000001e68:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    1e6c:      	fmov	x8, d0
    1e70:      	mov	x9, #0x10               ; =16
    1e74:      	movk	x9, #0x7ffc, lsl #48
    1e78:      	cmp	x8, x9
    1e7c:      	b.ne	0x2090 <ltmp0+0x2090>
    1e80:      	fmov	d0, x26
    1e84:      	str	x20, [sp, #0x18]
    1e88:      	mov.16b	v1, v8
    1e8c:      	adrp	x0, 0x1000 <ltmp0+0x1000>
		0000000000001e8c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__9
    1e90:      	add	x0, x0, #0x0
		0000000000001e90:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__9
    1e94:      	bl	0x1e94 <ltmp0+0x1e94>
		0000000000001e94:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    1e98:      	ldp	x26, x27, [sp, #0x8]
    1e9c:      	ldr	x20, [sp, #0x18]
    1ea0:      	fmov	x8, d0
    1ea4:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    1ea8:      	and	x9, x8, x9
    1eac:      	cmp	x9, x22
    1eb0:      	b.ne	0x1f20 <ltmp0+0x1f20>
    1eb4:      	and	x0, x8, #0xffffffffffff
    1eb8:      	lsr	x8, x0, #20
    1ebc:      	cbz	x8, 0x206c <ltmp0+0x206c>
    1ec0:      	ldurb	w9, [x0, #-0x8]
    1ec4:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		0000000000001ec4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__11
    1ec8:      	ldr	x8, [x8]
		0000000000001ec8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__11
    1ecc:      	cbz	x8, 0x1f90 <ltmp0+0x1f90>
    1ed0:      	cmp	w9, #0x2
    1ed4:      	b.ne	0x1f90 <ltmp0+0x1f90>
    1ed8:      	ldurh	w10, [x0, #-0x6]
    1edc:      	tbnz	w10, #0xb, 0x1f90 <ltmp0+0x1f90>
    1ee0:      	ldr	w10, [x0, #0x4]
    1ee4:      	orr	x9, x10, #0x4000000000000000
    1ee8:      	cbz	w10, 0x1fbc <ltmp0+0x1fbc>
    1eec:      	ldr	x11, [x8]
    1ef0:      	cmp	x9, x11
    1ef4:      	b.ne	0x1fbc <ltmp0+0x1fbc>
    1ef8:      	ldr	x2, [x8, #0x8]
    1efc:      	tbnz	w2, #0x1e, 0x23d8 <ltmp0+0x23d8>
    1f00:      	add	x11, x0, x2, lsl #3
    1f04:      	ldr	d0, [x11, #0x10]
    1f08:      	fmov	x11, d0
    1f0c:      	mov	x12, #0x10              ; =16
    1f10:      	movk	x12, #0x7ffc, lsl #48
    1f14:      	cmp	x11, x12
    1f18:      	b.ne	0x2090 <ltmp0+0x2090>
    1f1c:      	b	0x1fe8 <ltmp0+0x1fe8>
    1f20:      	lsr	x9, x8, #48
    1f24:      	mov	w10, #0x7ff9            ; =32761
    1f28:      	cmp	x9, x10
    1f2c:      	b.eq	0x1f74 <ltmp0+0x1f74>
    1f30:      	mov	w10, #0x7ffe            ; =32766
    1f34:      	cmp	w9, w10
    1f38:      	b.ne	0x1f64 <ltmp0+0x1f64>
    1f3c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		0000000000001f3c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    1f40:      	ldr	x9, [x9]
		0000000000001f40:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    1f44:      	str	x20, [sp, #0x18]
    1f48:      	and	x2, x9, #0xffffffffffff
    1f4c:      	mov	x0, #0xa                ; =10
    1f50:      	movk	x0, #0xddae, lsl #32
    1f54:      	movk	x0, #0x5556, lsl #48
    1f58:      	mov	x1, x8
    1f5c:      	bl	0x1f5c <ltmp0+0x1f5c>
		0000000000001f5c:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    1f60:      	b	0x2088 <ltmp0+0x2088>
    1f64:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    1f68:      	add	x9, x8, x9
    1f6c:      	cmp	x9, #0x2
    1f70:      	b.lo	0x3054 <ltmp0+0x3054>
    1f74:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		0000000000001f74:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    1f78:      	ldr	x9, [x9]
		0000000000001f78:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    1f7c:      	str	x20, [sp, #0x18]
    1f80:      	and	x1, x9, #0xffffffffffff
    1f84:      	mov	x0, x8
    1f88:      	bl	0x1f88 <ltmp0+0x1f88>
		0000000000001f88:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    1f8c:      	b	0x2088 <ltmp0+0x2088>
    1f90:      	cmp	w9, #0x2
    1f94:      	b.ne	0x206c <ltmp0+0x206c>
    1f98:      	cbz	x8, 0x206c <ltmp0+0x206c>
    1f9c:      	ldr	x9, [x8, #0x10]
    1fa0:      	cbz	x9, 0x206c <ltmp0+0x206c>
    1fa4:      	ldr	x10, [x0, #0x8]
    1fa8:      	cbz	x10, 0x206c <ltmp0+0x206c>
    1fac:      	ldr	x10, [x10, #0x30]
    1fb0:      	cmp	x10, x9
    1fb4:      	b.eq	0x1fd8 <ltmp0+0x1fd8>
    1fb8:      	b	0x206c <ltmp0+0x206c>
    1fbc:      	ldr	x11, [x8, #0x10]
    1fc0:      	cbz	x11, 0x1fe8 <ltmp0+0x1fe8>
    1fc4:      	ldr	x12, [x0, #0x8]
    1fc8:      	cbz	x12, 0x1fe8 <ltmp0+0x1fe8>
    1fcc:      	ldr	x12, [x12, #0x30]
    1fd0:      	cmp	x12, x11
    1fd4:      	b.ne	0x1fe8 <ltmp0+0x1fe8>
    1fd8:      	ldr	x8, [x8, #0x8]
    1fdc:      	add	x8, x0, x8, lsl #3
    1fe0:      	ldr	d0, [x8, #0x10]
    1fe4:      	b	0x2090 <ltmp0+0x2090>
    1fe8:      	ldr	x11, [x8, #0x18]
    1fec:      	cmp	x11, #0x0
    1ff0:      	b.le	0x206c <ltmp0+0x206c>
    1ff4:      	ldr	x11, [x8, #0x20]
    1ff8:      	ldr	x12, [x8, #0x30]
    1ffc:      	ldr	x13, [x8, #0x40]
    2000:      	cmp	x13, x9
    2004:      	ldr	x14, [x8, #0x50]
    2008:      	ccmp	x14, x9, #0x4, ne
    200c:      	ccmp	x12, x9, #0x4, ne
    2010:      	ccmp	x11, x9, #0x4, ne
    2014:      	cset	w15, eq
    2018:      	cbz	w10, 0x206c <ltmp0+0x206c>
    201c:      	cbz	w15, 0x206c <ltmp0+0x206c>
    2020:      	ldr	x10, [x8, #0x48]
    2024:      	ldr	x15, [x8, #0x58]
    2028:      	cmp	x14, x9
    202c:      	csel	x14, x15, xzr, eq
    2030:      	cmp	x13, x9
    2034:      	csel	x10, x10, x14, eq
    2038:      	ldr	x13, [x8, #0x28]
    203c:      	ldr	x8, [x8, #0x38]
    2040:      	cmp	x12, x9
    2044:      	csel	x8, x8, x10, eq
    2048:      	cmp	x11, x9
    204c:      	csel	x8, x13, x8, eq
    2050:      	add	x8, x0, x8, lsl #3
    2054:      	ldr	d0, [x8, #0x10]
    2058:      	fmov	x8, d0
    205c:      	mov	x9, #0x10               ; =16
    2060:      	movk	x9, #0x7ffc, lsl #48
    2064:      	cmp	x8, x9
    2068:      	b.ne	0x2090 <ltmp0+0x2090>
    206c:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		000000000000206c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    2070:      	ldr	x8, [x8]
		0000000000002070:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    2074:      	str	x20, [sp, #0x18]
    2078:      	and	x1, x8, #0xffffffffffff
    207c:      	adrp	x2, 0x2000 <ltmp0+0x2000>
		000000000000207c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__11
    2080:      	add	x2, x2, #0x0
		0000000000002080:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__11
    2084:      	bl	0x2084 <ltmp0+0x2084>
		0000000000002084:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    2088:      	ldp	x26, x27, [sp, #0x8]
    208c:      	ldr	x20, [sp, #0x18]
    2090:      	fmov	x8, d0
    2094:      	lsr	x9, x8, #48
    2098:      	mov	w10, #0x7ff9            ; =32761
    209c:      	cmp	x9, x10
    20a0:      	b.eq	0x20d0 <ltmp0+0x20d0>
    20a4:      	mov	w10, #0x7fff            ; =32767
    20a8:      	cmp	w9, w10
    20ac:      	b.ne	0x20dc <ltmp0+0x20dc>
    20b0:      	and	x9, x8, #0xffffffffffff
    20b4:      	tst	x8, #0xfffffffff000
    20b8:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		00000000000020b8:  ARM64_RELOC_PAGE21	_perry_null_guard_zero_access_worker_ts
    20bc:      	add	x8, x8, #0x0
		00000000000020bc:  ARM64_RELOC_PAGEOFF12	_perry_null_guard_zero_access_worker_ts
    20c0:      	csel	x8, x8, x9, eq
    20c4:      	ldr	s0, [x8]
    20c8:      	ucvtf	d1, d0
    20cc:      	b	0x20f0 <ltmp0+0x20f0>
    20d0:      	ubfx	x8, x8, #40, #8
    20d4:      	ucvtf	d1, x8
    20d8:      	b	0x20f0 <ltmp0+0x20f0>
    20dc:      	str	x20, [sp, #0x18]
    20e0:      	bl	0x20e0 <ltmp0+0x20e0>
		00000000000020e0:  ARM64_RELOC_BRANCH26	_js_value_length_property_f64
    20e4:      	mov.16b	v1, v0
    20e8:      	ldp	x26, x27, [sp, #0x8]
    20ec:      	ldr	x20, [sp, #0x18]
    20f0:      	fmov	d0, x20
    20f4:      	and	x9, x20, #0xffff000000000000
    20f8:      	fmov	x8, d1
    20fc:      	and	x10, x8, #0xffff000000000000
    2100:      	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
    2104:      	cmp	x8, x11
    2108:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    210c:      	ccmp	x10, x8, #0x2, hs
    2110:      	cset	w8, hi
    2114:      	mov	x10, #0x1               ; =1
    2118:      	movk	x10, #0x7fff, lsl #48
    211c:      	cmp	x9, x10
    2120:      	ccmp	x20, x21, #0x0, lo
    2124:      	b.hi	0x2134 <ltmp0+0x2134>
    2128:      	cbz	w8, 0x2134 <ltmp0+0x2134>
    212c:      	fadd	d0, d1, d0
    2130:      	b	0x2140 <ltmp0+0x2140>
    2134:      	stp	x27, x26, [sp, #0x10]
    2138:      	bl	0x2138 <ltmp0+0x2138>
		0000000000002138:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    213c:      	ldp	x27, x26, [sp, #0x10]
    2140:      	fmov	x20, d0
    2144:      	mov	x0, x20
    2148:      	ldr	w8, [x23]
    214c:      	cbz	w8, 0x2154 <ltmp0+0x2154>
    2150:      	bl	0x2150 <ltmp0+0x2150>
		0000000000002150:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    2154:      	mov	x0, x20
    2158:      	ldr	w8, [x23]
    215c:      	cbz	w8, 0x2164 <ltmp0+0x2164>
    2160:      	bl	0x2160 <ltmp0+0x2160>
		0000000000002160:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    2164:      	mov	x10, x26
    2168:      	and	x8, x10, #0xffffffffffff
    216c:      	and	x12, x10, #0xffff000000000000
    2170:      	cmp	x12, x22
    2174:      	b.ne	0x220c <ltmp0+0x220c>
    2178:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		0000000000002178:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    217c:      	ldr	x9, [x9]
		000000000000217c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    2180:      	ldr	x9, [x9]
    2184:      	cbnz	x9, 0x220c <ltmp0+0x220c>
    2188:      	sub	x9, x8, #0x100, lsl #12 ; =0x100000
    218c:      	cmp	x9, x19
    2190:      	b.hs	0x220c <ltmp0+0x220c>
    2194:      	mov	x9, #0x41f0000000000000 ; =4751297606875873280
    2198:      	fmov	d0, x9
    219c:      	fcmp	d8, d0
    21a0:      	b.pl	0x220c <ltmp0+0x220c>
    21a4:      	fcmp	d8, #0.0
    21a8:      	b.lt	0x220c <ltmp0+0x220c>
    21ac:      	ldurb	w9, [x8, #-0x8]
    21b0:      	cmp	w9, #0xb
    21b4:      	b.ne	0x220c <ltmp0+0x220c>
    21b8:      	ldrb	w11, [x8, #0x8]
    21bc:      	cmp	w11, #0x9
    21c0:      	b.hs	0x220c <ltmp0+0x220c>
    21c4:      	fcvtzs	x9, d8
    21c8:      	scvtf	d0, x9
    21cc:      	fcmp	d8, d0
    21d0:      	b.ne	0x220c <ltmp0+0x220c>
    21d4:      	ldr	w13, [x8]
    21d8:      	cmp	x9, x13
    21dc:      	b.hs	0x220c <ltmp0+0x220c>
    21e0:      	add	x8, x8, #0x10
    21e4:      	cmp	w11, #0x3
    21e8:      	b.le	0x22d4 <ltmp0+0x22d4>
    21ec:      	cmp	w11, #0x5
    21f0:      	b.gt	0x238c <ltmp0+0x238c>
    21f4:      	cmp	w11, #0x4
    21f8:      	b.eq	0x2444 <ltmp0+0x2444>
    21fc:      	cmp	w11, #0x5
    2200:      	b.ne	0x2438 <ltmp0+0x2438>
    2204:      	ldr	s0, [x8, x9, lsl #2]
    2208:      	b	0x243c <ltmp0+0x243c>
    220c:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		000000000000220c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__12
    2210:      	add	x9, x9, #0x0
		0000000000002210:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__12
    2214:      	ldr	x11, [x9]
    2218:      	cmp	x11, #0x0
    221c:      	csel	x13, x9, x11, eq
    2220:      	cmp	x12, x22
    2224:      	b.ne	0x258c <ltmp0+0x258c>
    2228:      	fcmp	d8, #0.0
    222c:      	b.lt	0x258c <ltmp0+0x258c>
    2230:      	fcmp	d8, d9
    2234:      	b.pl	0x258c <ltmp0+0x258c>
    2238:      	mov	x9, #-0x20000000000     ; =-2199023255552
    223c:      	add	x9, x8, x9
    2240:      	lsr	x9, x9, #41
    2244:      	cmp	x9, #0x3f
    2248:      	b.hs	0x258c <ltmp0+0x258c>
    224c:      	fcvtzs	x9, d8
    2250:      	scvtf	d0, x9
    2254:      	fcmp	d8, d0
    2258:      	b.ne	0x258c <ltmp0+0x258c>
    225c:      	ldursb	w12, [x8, #-0x7]
    2260:      	tbnz	w12, #0x1f, 0x258c <ltmp0+0x258c>
    2264:      	ldurb	w12, [x8, #-0x8]
    2268:      	cmp	w12, #0x9
    226c:      	b.eq	0x2340 <ltmp0+0x2340>
    2270:      	cmp	w12, #0x2
    2274:      	b.eq	0x22f0 <ltmp0+0x22f0>
    2278:      	cmp	w12, #0x1
    227c:      	b.ne	0x258c <ltmp0+0x258c>
    2280:      	ldr	w10, [x8]
    2284:      	mov	x11, x8
    2288:      	ldurh	w13, [x8, #-0x6]
    228c:      	adrp	x12, 0x2000 <ltmp0+0x2000>
		000000000000228c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    2290:      	ldr	x12, [x12]
		0000000000002290:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    2294:      	ldrb	w12, [x12]
    2298:      	ldr	w8, [x8, #0x4]
    229c:      	cmp	x10, x8
    22a0:      	b.hi	0x258c <ltmp0+0x258c>
    22a4:      	tbnz	w13, #0xa, 0x258c <ltmp0+0x258c>
    22a8:      	cbnz	w12, 0x258c <ltmp0+0x258c>
    22ac:      	cmp	x9, x10
    22b0:      	b.hs	0x258c <ltmp0+0x258c>
    22b4:      	add	x8, x11, x9, lsl #3
    22b8:      	ldr	d0, [x8, #0x8]
    22bc:      	fmov	x8, d0
    22c0:      	mov	x9, #0x10               ; =16
    22c4:      	movk	x9, #0x7ffc, lsl #48
    22c8:      	cmp	x8, x9
    22cc:      	fcsel	d0, d10, d0, eq
    22d0:      	b	0x25b4 <ltmp0+0x25b4>
    22d4:      	cbz	w11, 0x2430 <ltmp0+0x2430>
    22d8:      	cmp	w11, #0x2
    22dc:      	b.eq	0x2458 <ltmp0+0x2458>
    22e0:      	cmp	w11, #0x3
    22e4:      	b.ne	0x2438 <ltmp0+0x2438>
    22e8:      	ldr	h0, [x8, x9, lsl #1]
    22ec:      	b	0x243c <ltmp0+0x243c>
    22f0:      	ldr	x10, [x8, #0x8]
    22f4:      	cbz	x10, 0x23a4 <ltmp0+0x23a4>
    22f8:      	ldr	x12, [x10, #0x60]
    22fc:      	cbz	x12, 0x23a4 <ltmp0+0x23a4>
    2300:      	ldurb	w8, [x12, #-0x8]
    2304:      	cmp	w8, #0x1
    2308:      	b.ne	0x258c <ltmp0+0x258c>
    230c:      	ldursb	w8, [x12, #-0x7]
    2310:      	tbnz	w8, #0x1f, 0x258c <ltmp0+0x258c>
    2314:      	ldr	w8, [x12]
    2318:      	cmp	x9, x8
    231c:      	b.hs	0x258c <ltmp0+0x258c>
    2320:      	add	x8, x12, x9, lsl #3
    2324:      	ldr	d0, [x8, #0x8]
    2328:      	fmov	x8, d0
    232c:      	mov	x9, #0x10               ; =16
    2330:      	movk	x9, #0x7ffc, lsl #48
    2334:      	cmp	x8, x9
    2338:      	b.eq	0x258c <ltmp0+0x258c>
    233c:      	b	0x25b4 <ltmp0+0x25b4>
    2340:      	ldr	w12, [x8, #0x4]
    2344:      	ldr	x11, [x8, #0x20]
    2348:      	ldurh	w13, [x8, #-0x6]
    234c:      	tst	w13, #0xc00
    2350:      	mov	w13, #0x5841            ; =22593
    2354:      	movk	w13, #0x4c5a, lsl #16
    2358:      	ccmp	w12, w13, #0x0, eq
    235c:      	cset	w12, eq
    2360:      	cbz	x11, 0x23f8 <ltmp0+0x23f8>
    2364:      	tbz	w12, #0x0, 0x23f8 <ltmp0+0x23f8>
    2368:      	ldurb	w10, [x11, #-0x8]
    236c:      	cmp	w10, #0x1
    2370:      	b.ne	0x258c <ltmp0+0x258c>
    2374:      	ldursb	w10, [x11, #-0x7]
    2378:      	tbnz	w10, #0x1f, 0x258c <ltmp0+0x258c>
    237c:      	ldr	w10, [x11]
    2380:      	str	w10, [x8]
    2384:      	mov	x8, x11
    2388:      	b	0x2288 <ltmp0+0x2288>
    238c:      	cmp	w11, #0x6
    2390:      	b.eq	0x244c <ltmp0+0x244c>
    2394:      	cmp	w11, #0x7
    2398:      	b.ne	0x2438 <ltmp0+0x2438>
    239c:      	ldr	d0, [x8, x9, lsl #3]
    23a0:      	b	0x25b4 <ltmp0+0x25b4>
    23a4:      	ldr	x12, [x13]
    23a8:      	cbz	x12, 0x258c <ltmp0+0x258c>
    23ac:      	tbnz	x12, #0x3f, 0x2464 <ltmp0+0x2464>
    23b0:      	ldp	w14, w13, [x8]
    23b4:      	orr	x13, x13, x14, lsl #32
    23b8:      	cmp	x13, x12
    23bc:      	b.ne	0x258c <ltmp0+0x258c>
    23c0:      	ldp	x14, x12, [x11, #0x8]
    23c4:      	ldp	x13, x11, [x11, #0x18]
    23c8:      	cmp	x14, x11
    23cc:      	b.lo	0x2484 <ltmp0+0x2484>
    23d0:      	cbz	x10, 0x258c <ltmp0+0x258c>
    23d4:      	b	0x24d4 <ltmp0+0x24d4>
    23d8:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		00000000000023d8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    23dc:      	ldr	x8, [x8]
		00000000000023dc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    23e0:      	str	x20, [sp, #0x18]
    23e4:      	and	x1, x8, #0xffffffffffff
    23e8:      	adrp	x3, 0x2000 <ltmp0+0x2000>
		00000000000023e8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__11
    23ec:      	add	x3, x3, #0x0
		00000000000023ec:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__11
    23f0:      	bl	0x23f0 <ltmp0+0x23f0>
		00000000000023f0:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    23f4:      	b	0x2088 <ltmp0+0x2088>
    23f8:      	cmp	x11, #0x0
    23fc:      	ldr	w14, [x8]
    2400:      	ldp	x11, x13, [x8, #0x28]
    2404:      	ccmp	x9, x14, #0x2, eq
    2408:      	ccmp	x11, #0x0, #0x4, lo
    240c:      	ccmp	x13, #0x0, #0x4, ne
    2410:      	csel	w12, wzr, w12, eq
    2414:      	tbz	w12, #0x0, 0x258c <ltmp0+0x258c>
    2418:      	lsr	x12, x9, #6
    241c:      	ldr	x12, [x13, x12, lsl #3]
    2420:      	lsr	x12, x12, x9
    2424:      	tbz	w12, #0x0, 0x2490 <ltmp0+0x2490>
    2428:      	ldr	d0, [x11, x9, lsl #3]
    242c:      	b	0x25b4 <ltmp0+0x25b4>
    2430:      	ldrsb	w8, [x8, x9]
    2434:      	b	0x245c <ltmp0+0x245c>
    2438:      	ldr	b0, [x8, x9]
    243c:      	ucvtf	d0, d0
    2440:      	b	0x25b4 <ltmp0+0x25b4>
    2444:      	ldr	w8, [x8, x9, lsl #2]
    2448:      	b	0x245c <ltmp0+0x245c>
    244c:      	ldr	s0, [x8, x9, lsl #2]
    2450:      	fcvt	d0, s0
    2454:      	b	0x25b4 <ltmp0+0x25b4>
    2458:      	ldrsh	w8, [x8, x9, lsl #1]
    245c:      	scvtf	d0, w8
    2460:      	b	0x25b4 <ltmp0+0x25b4>
    2464:      	cbz	x10, 0x258c <ltmp0+0x258c>
    2468:      	ldr	x13, [x10, #0x30]
    246c:      	cmp	x13, x12
    2470:      	b.ne	0x258c <ltmp0+0x258c>
    2474:      	ldp	x14, x12, [x11, #0x8]
    2478:      	ldp	x13, x11, [x11, #0x18]
    247c:      	cmp	x14, x11
    2480:      	b.hs	0x24d4 <ltmp0+0x24d4>
    2484:      	add	x14, x8, x14, lsl #3
    2488:      	add	x14, x14, #0x10
    248c:      	b	0x24f8 <ltmp0+0x24f8>
    2490:      	ldr	x8, [x8, #0x50]
    2494:      	mov	x12, #0x6107            ; =24839
    2498:      	movk	x12, #0x7463, lsl #16
    249c:      	movk	x12, #0x7669, lsl #32
    24a0:      	movk	x12, #0x65, lsl #48
    24a4:      	cmp	x8, x12
    24a8:      	b.eq	0x24b0 <ltmp0+0x24b0>
    24ac:      	cbnz	x8, 0x258c <ltmp0+0x258c>
    24b0:      	cmp	x8, x12
    24b4:      	b.ne	0x2560 <ltmp0+0x2560>
    24b8:      	ldr	x8, [x11, x9, lsl #3]
    24bc:      	cbz	x8, 0x2560 <ltmp0+0x2560>
    24c0:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    24c4:      	cmp	x8, x9
    24c8:      	csel	x8, xzr, x8, eq
    24cc:      	fmov	d0, x8
    24d0:      	b	0x27b0 <ltmp0+0x27b0>
    24d4:      	ldr	x16, [x10, #0x20]
    24d8:      	cmp	x16, #0x0
    24dc:      	csel	x15, x16, x10, ne
    24e0:      	cbz	x16, 0x258c <ltmp0+0x258c>
    24e4:      	ldr	w16, [x15]
    24e8:      	cmp	x14, x16
    24ec:      	b.hs	0x258c <ltmp0+0x258c>
    24f0:      	add	x14, x15, x14, lsl #3
    24f4:      	add	x14, x14, #0x8
    24f8:      	ldr	d0, [x14]
    24fc:      	fcmp	d8, d0
    2500:      	ccmp	x13, x9, #0x0, mi
    2504:      	cset	w13, hi
    2508:      	add	x9, x12, x9
    250c:      	cmp	x9, x11
    2510:      	b.hs	0x2524 <ltmp0+0x2524>
    2514:      	cbz	w13, 0x2524 <ltmp0+0x2524>
    2518:      	add	x8, x8, x9, lsl #3
    251c:      	ldr	d0, [x8, #0x10]
    2520:      	b	0x25b4 <ltmp0+0x25b4>
    2524:      	cbz	x10, 0x258c <ltmp0+0x258c>
    2528:      	cmp	x9, x11
    252c:      	b.lo	0x258c <ltmp0+0x258c>
    2530:      	eor	w8, w13, #0x1
    2534:      	tbnz	w8, #0x0, 0x258c <ltmp0+0x258c>
    2538:      	ldr	x11, [x10, #0x20]
    253c:      	cmp	x11, #0x0
    2540:      	csel	x8, x11, x10, ne
    2544:      	cbz	x11, 0x258c <ltmp0+0x258c>
    2548:      	ldr	w10, [x8]
    254c:      	cmp	x9, x10
    2550:      	b.hs	0x258c <ltmp0+0x258c>
    2554:      	add	x8, x8, x9, lsl #3
    2558:      	ldr	d0, [x8, #0x8]
    255c:      	b	0x25b4 <ltmp0+0x25b4>
    2560:      	fmov	d0, x10
    2564:      	mov.16b	v1, v8
    2568:      	adrp	x0, 0x2000 <ltmp0+0x2000>
		0000000000002568:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.5.bytes
    256c:      	add	x0, x0, #0x0
		000000000000256c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.5.bytes
    2570:      	mov	w1, #0x6                ; =6
    2574:      	bl	0x2574 <ltmp0+0x2574>
		0000000000002574:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    2578:      	fmov	x8, d0
    257c:      	mov	x9, #0x10               ; =16
    2580:      	movk	x9, #0x7ffc, lsl #48
    2584:      	cmp	x8, x9
    2588:      	b.ne	0x27b0 <ltmp0+0x27b0>
    258c:      	mov	x8, x26
    2590:      	stp	x26, x20, [sp, #0x10]
    2594:      	fmov	d0, x8
    2598:      	str	x27, [sp, #0x8]
    259c:      	mov.16b	v1, v8
    25a0:      	adrp	x0, 0x2000 <ltmp0+0x2000>
		00000000000025a0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__12
    25a4:      	add	x0, x0, #0x0
		00000000000025a4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__12
    25a8:      	bl	0x25a8 <ltmp0+0x25a8>
		00000000000025a8:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    25ac:      	ldp	x27, x26, [sp, #0x8]
    25b0:      	ldr	x20, [sp, #0x18]
    25b4:      	fmov	x8, d0
    25b8:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    25bc:      	and	x9, x8, x9
    25c0:      	cmp	x9, x22
    25c4:      	b.ne	0x2634 <ltmp0+0x2634>
    25c8:      	and	x0, x8, #0xffffffffffff
    25cc:      	lsr	x8, x0, #20
    25d0:      	cbz	x8, 0x2788 <ltmp0+0x2788>
    25d4:      	ldurb	w9, [x0, #-0x8]
    25d8:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		00000000000025d8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__14
    25dc:      	ldr	x8, [x8]
		00000000000025dc:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__14
    25e0:      	cbz	x8, 0x26ac <ltmp0+0x26ac>
    25e4:      	cmp	w9, #0x2
    25e8:      	b.ne	0x26ac <ltmp0+0x26ac>
    25ec:      	ldurh	w10, [x0, #-0x6]
    25f0:      	tbnz	w10, #0xb, 0x26ac <ltmp0+0x26ac>
    25f4:      	ldr	w10, [x0, #0x4]
    25f8:      	orr	x9, x10, #0x4000000000000000
    25fc:      	cbz	w10, 0x26d8 <ltmp0+0x26d8>
    2600:      	ldr	x11, [x8]
    2604:      	cmp	x9, x11
    2608:      	b.ne	0x26d8 <ltmp0+0x26d8>
    260c:      	ldr	x2, [x8, #0x8]
    2610:      	tbnz	w2, #0x1e, 0x28ac <ltmp0+0x28ac>
    2614:      	add	x11, x0, x2, lsl #3
    2618:      	ldr	d0, [x11, #0x10]
    261c:      	fmov	x11, d0
    2620:      	mov	x12, #0x10              ; =16
    2624:      	movk	x12, #0x7ffc, lsl #48
    2628:      	cmp	x11, x12
    262c:      	b.ne	0x27b0 <ltmp0+0x27b0>
    2630:      	b	0x2704 <ltmp0+0x2704>
    2634:      	lsr	x9, x8, #48
    2638:      	mov	w10, #0x7ff9            ; =32761
    263c:      	cmp	x9, x10
    2640:      	b.eq	0x268c <ltmp0+0x268c>
    2644:      	mov	w10, #0x7ffe            ; =32766
    2648:      	cmp	w9, w10
    264c:      	b.ne	0x267c <ltmp0+0x267c>
    2650:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		0000000000002650:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    2654:      	ldr	x9, [x9]
		0000000000002654:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    2658:      	stp	x26, x20, [sp, #0x10]
    265c:      	str	x27, [sp, #0x8]
    2660:      	and	x2, x9, #0xffffffffffff
    2664:      	mov	x0, #0xd                ; =13
    2668:      	movk	x0, #0xddae, lsl #32
    266c:      	movk	x0, #0x5556, lsl #48
    2670:      	mov	x1, x8
    2674:      	bl	0x2674 <ltmp0+0x2674>
		0000000000002674:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    2678:      	b	0x27a8 <ltmp0+0x27a8>
    267c:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    2680:      	add	x9, x8, x9
    2684:      	cmp	x9, #0x2
    2688:      	b.lo	0x3078 <ltmp0+0x3078>
    268c:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		000000000000268c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    2690:      	ldr	x9, [x9]
		0000000000002690:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    2694:      	stp	x26, x20, [sp, #0x10]
    2698:      	str	x27, [sp, #0x8]
    269c:      	and	x1, x9, #0xffffffffffff
    26a0:      	mov	x0, x8
    26a4:      	bl	0x26a4 <ltmp0+0x26a4>
		00000000000026a4:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    26a8:      	b	0x27a8 <ltmp0+0x27a8>
    26ac:      	cmp	w9, #0x2
    26b0:      	b.ne	0x2788 <ltmp0+0x2788>
    26b4:      	cbz	x8, 0x2788 <ltmp0+0x2788>
    26b8:      	ldr	x9, [x8, #0x10]
    26bc:      	cbz	x9, 0x2788 <ltmp0+0x2788>
    26c0:      	ldr	x10, [x0, #0x8]
    26c4:      	cbz	x10, 0x2788 <ltmp0+0x2788>
    26c8:      	ldr	x10, [x10, #0x30]
    26cc:      	cmp	x10, x9
    26d0:      	b.eq	0x26f4 <ltmp0+0x26f4>
    26d4:      	b	0x2788 <ltmp0+0x2788>
    26d8:      	ldr	x11, [x8, #0x10]
    26dc:      	cbz	x11, 0x2704 <ltmp0+0x2704>
    26e0:      	ldr	x12, [x0, #0x8]
    26e4:      	cbz	x12, 0x2704 <ltmp0+0x2704>
    26e8:      	ldr	x12, [x12, #0x30]
    26ec:      	cmp	x12, x11
    26f0:      	b.ne	0x2704 <ltmp0+0x2704>
    26f4:      	ldr	x8, [x8, #0x8]
    26f8:      	add	x8, x0, x8, lsl #3
    26fc:      	ldr	d0, [x8, #0x10]
    2700:      	b	0x27b0 <ltmp0+0x27b0>
    2704:      	ldr	x11, [x8, #0x18]
    2708:      	cmp	x11, #0x0
    270c:      	b.le	0x2788 <ltmp0+0x2788>
    2710:      	ldr	x11, [x8, #0x20]
    2714:      	ldr	x12, [x8, #0x30]
    2718:      	ldr	x13, [x8, #0x40]
    271c:      	cmp	x13, x9
    2720:      	ldr	x14, [x8, #0x50]
    2724:      	ccmp	x14, x9, #0x4, ne
    2728:      	ccmp	x12, x9, #0x4, ne
    272c:      	ccmp	x11, x9, #0x4, ne
    2730:      	cset	w15, eq
    2734:      	cbz	w10, 0x2788 <ltmp0+0x2788>
    2738:      	cbz	w15, 0x2788 <ltmp0+0x2788>
    273c:      	ldr	x10, [x8, #0x48]
    2740:      	ldr	x15, [x8, #0x58]
    2744:      	cmp	x14, x9
    2748:      	csel	x14, x15, xzr, eq
    274c:      	cmp	x13, x9
    2750:      	csel	x10, x10, x14, eq
    2754:      	ldr	x13, [x8, #0x28]
    2758:      	ldr	x8, [x8, #0x38]
    275c:      	cmp	x12, x9
    2760:      	csel	x8, x8, x10, eq
    2764:      	cmp	x11, x9
    2768:      	csel	x8, x13, x8, eq
    276c:      	add	x8, x0, x8, lsl #3
    2770:      	ldr	d0, [x8, #0x10]
    2774:      	fmov	x8, d0
    2778:      	mov	x9, #0x10               ; =16
    277c:      	movk	x9, #0x7ffc, lsl #48
    2780:      	cmp	x8, x9
    2784:      	b.ne	0x27b0 <ltmp0+0x27b0>
    2788:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		0000000000002788:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    278c:      	ldr	x8, [x8]
		000000000000278c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    2790:      	stp	x26, x20, [sp, #0x10]
    2794:      	str	x27, [sp, #0x8]
    2798:      	and	x1, x8, #0xffffffffffff
    279c:      	adrp	x2, 0x2000 <ltmp0+0x2000>
		000000000000279c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__14
    27a0:      	add	x2, x2, #0x0
		00000000000027a0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__14
    27a4:      	bl	0x27a4 <ltmp0+0x27a4>
		00000000000027a4:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    27a8:      	ldp	x27, x26, [sp, #0x8]
    27ac:      	ldr	x20, [sp, #0x18]
    27b0:      	fmov	x8, d0
    27b4:      	mov	x9, #0x7ff8000000000000 ; =9221120237041090560
    27b8:      	bics	xzr, x9, x8
    27bc:      	b.ne	0x27ec <ltmp0+0x27ec>
    27c0:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    27c4:      	add	x9, x8, x9
    27c8:      	cmp	x9, #0x4
    27cc:      	b.hs	0x2800 <ltmp0+0x2800>
    27d0:      	mov	x9, #0x10               ; =16
    27d4:      	movk	x9, #0x7ffc, lsl #48
    27d8:      	sub	x9, x9, #0xc
    27dc:      	movi.2d	v1, #0000000000000000
    27e0:      	cmp	x8, x9
    27e4:      	b.eq	0x281c <ltmp0+0x281c>
    27e8:      	b	0x2820 <ltmp0+0x2820>
    27ec:      	movi.2d	v1, #0000000000000000
    27f0:      	fcmp	d0, #0.0
    27f4:      	b.eq	0x2820 <ltmp0+0x2820>
    27f8:      	b.vs	0x2820 <ltmp0+0x2820>
    27fc:      	b	0x281c <ltmp0+0x281c>
    2800:      	mov	w9, #0x7ffd             ; =32765
    2804:      	cmp	x9, x8, lsr #48
    2808:      	b.ne	0x2814 <ltmp0+0x2814>
    280c:      	and	x8, x8, #0xffffffffffff
    2810:      	cbnz	x8, 0x281c <ltmp0+0x281c>
    2814:      	bl	0x2814 <ltmp0+0x2814>
		0000000000002814:  ARM64_RELOC_BRANCH26	_js_is_truthy
    2818:      	cbz	w0, 0x28a4 <ltmp0+0x28a4>
    281c:      	fmov	d1, #1.00000000
    2820:      	fmov	d0, x20
    2824:      	and	x8, x20, #0xffff000000000000
    2828:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    282c:      	cmp	x20, x9
    2830:      	mov	x9, #0x7fff000000000000 ; =9223090561878065152
    2834:      	ccmp	x8, x9, #0x2, hs
    2838:      	cset	w8, hi
    283c:      	fmov	x9, d1
    2840:      	cmp	x9, x21
    2844:      	b.hi	0x2854 <ltmp0+0x2854>
    2848:      	tbz	w8, #0x0, 0x2854 <ltmp0+0x2854>
    284c:      	fadd	d0, d1, d0
    2850:      	b	0x2860 <ltmp0+0x2860>
    2854:      	stp	x27, x26, [sp, #0x10]
    2858:      	bl	0x2858 <ltmp0+0x2858>
		0000000000002858:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    285c:      	ldp	x27, x26, [sp, #0x10]
    2860:      	fmov	x20, d0
    2864:      	mov	x0, x20
    2868:      	ldr	w8, [x23]
    286c:      	cbz	w8, 0x2874 <ltmp0+0x2874>
    2870:      	bl	0x2870 <ltmp0+0x2870>
		0000000000002870:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    2874:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		0000000000002874:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    2878:      	ldr	x8, [x8]
		0000000000002878:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    287c:      	ldr	w8, [x8]
    2880:      	cbz	w8, 0x2898 <ltmp0+0x2898>
    2884:      	stp	x26, x27, [sp, #0x10]
    2888:      	str	x20, [sp, #0x8]
    288c:      	bl	0x288c <ltmp0+0x288c>
		000000000000288c:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    2890:      	ldp	x20, x26, [sp, #0x8]
    2894:      	ldr	x27, [sp, #0x18]
    2898:      	add	w24, w24, #0x1
    289c:      	tbz	w28, #0x0, 0x1358 <ltmp0+0x1358>
    28a0:      	b	0x13a8 <ltmp0+0x13a8>
    28a4:      	movi.2d	v1, #0000000000000000
    28a8:      	b	0x2820 <ltmp0+0x2820>
    28ac:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		00000000000028ac:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    28b0:      	ldr	x8, [x8]
		00000000000028b0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    28b4:      	stp	x26, x20, [sp, #0x10]
    28b8:      	str	x27, [sp, #0x8]
    28bc:      	and	x1, x8, #0xffffffffffff
    28c0:      	adrp	x3, 0x2000 <ltmp0+0x2000>
		00000000000028c0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__14
    28c4:      	add	x3, x3, #0x0
		00000000000028c4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__14
    28c8:      	bl	0x28c8 <ltmp0+0x28c8>
		00000000000028c8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    28cc:      	b	0x27a8 <ltmp0+0x27a8>
    28d0:      	mov	x22, x25
    28d4:      	mov	w28, #0x0               ; =0
    28d8:      	mov	x20, #0x0               ; =0
    28dc:      	mov	x21, #0x7ffd000000000000 ; =9222527611924643840
    28e0:      	mov	x24, #0x7ffffff00000    ; =140737487306752
    28e4:      	adrp	x19, 0x2000 <ltmp0+0x2000>
		00000000000028e4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__15
    28e8:      	add	x19, x19, #0x0
		00000000000028e8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__15
    28ec:      	ldr	d9, [x12]
		00000000000028ec:  ARM64_RELOC_PAGEOFF12	lCPI0_1
    28f0:      	ldr	d10, [x11]
		00000000000028f0:  ARM64_RELOC_PAGEOFF12	lCPI0_2
    28f4:      	mov	x8, #0x41f0000000000000 ; =4751297606875873280
    28f8:      	fmov	d11, x8
    28fc:      	tbnz	w22, #0x0, 0x2940 <ltmp0+0x2940>
    2900:      	mov	x24, x27
    2904:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		0000000000002904:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    2908:      	ldr	x8, [x8]
		0000000000002908:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    290c:      	ldr	w8, [x8]
    2910:      	cbz	w8, 0x2928 <ltmp0+0x2928>
    2914:      	stp	x26, x27, [sp, #0x10]
    2918:      	str	x20, [sp, #0x8]
    291c:      	bl	0x291c <ltmp0+0x291c>
		000000000000291c:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    2920:      	ldp	x20, x26, [sp, #0x8]
    2924:      	ldr	x27, [sp, #0x18]
    2928:      	scvtf	d0, w28
    292c:      	fmov	d1, x24
    2930:      	fcmp	d0, d1
    2934:      	mov	x24, #0x7ffffff00000    ; =140737487306752
    2938:      	b.pl	0x1d4 <ltmp0+0x1d4>
    293c:      	b	0x294c <ltmp0+0x294c>
    2940:      	cmp	w28, w25
    2944:      	b.ge	0x1d4 <ltmp0+0x1d4>
    2948:      	scvtf	d0, w28
    294c:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		000000000000294c:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    2950:      	ldr	d1, [x8]
		0000000000002950:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    2954:      	stp	x26, x20, [sp, #0x10]
    2958:      	str	x27, [sp, #0x8]
    295c:      	bl	0x295c <ltmp0+0x295c>
		000000000000295c:  ARM64_RELOC_BRANCH26	_js_dynamic_mod
    2960:      	mov.16b	v8, v0
    2964:      	ldp	x27, x26, [sp, #0x8]
    2968:      	ldr	x20, [sp, #0x18]
    296c:      	mov	x0, x20
    2970:      	ldr	w8, [x23]
    2974:      	cbz	w8, 0x297c <ltmp0+0x297c>
    2978:      	bl	0x2978 <ltmp0+0x2978>
		0000000000002978:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    297c:      	mov	x10, x26
    2980:      	and	x8, x10, #0xffffffffffff
    2984:      	and	x13, x10, #0xffff000000000000
    2988:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		0000000000002988:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    298c:      	ldr	x9, [x9]
		000000000000298c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    2990:      	ldr	x9, [x9]
    2994:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
    2998:      	cmp	x13, x21
    299c:      	ccmp	x9, #0x0, #0x0, eq
    29a0:      	ccmp	x11, x24, #0x2, eq
    29a4:      	b.hs	0x29e0 <ltmp0+0x29e0>
    29a8:      	fcmp	d8, d11
    29ac:      	b.pl	0x29e0 <ltmp0+0x29e0>
    29b0:      	ldurb	w9, [x8, #-0x8]
    29b4:      	ldrb	w11, [x8, #0x8]
    29b8:      	fcmp	d8, #0.0
    29bc:      	ccmp	w9, #0xb, #0x0, ge
    29c0:      	ccmp	w11, #0x9, #0x2, eq
    29c4:      	b.hs	0x29e0 <ltmp0+0x29e0>
    29c8:      	fcvtzs	x9, d8
    29cc:      	scvtf	d0, x9
    29d0:      	ldr	w12, [x8]
    29d4:      	fcmp	d8, d0
    29d8:      	ccmp	x9, x12, #0x2, eq
    29dc:      	b.lo	0x2aa0 <ltmp0+0x2aa0>
    29e0:      	ldr	x11, [x19]
    29e4:      	cmp	x11, #0x0
    29e8:      	csel	x12, x19, x11, eq
    29ec:      	cmp	x13, x21
    29f0:      	b.ne	0x2d68 <ltmp0+0x2d68>
    29f4:      	fcmp	d8, #0.0
    29f8:      	b.lt	0x2d68 <ltmp0+0x2d68>
    29fc:      	fcmp	d8, d9
    2a00:      	b.pl	0x2d68 <ltmp0+0x2d68>
    2a04:      	mov	x9, #-0x20000000000     ; =-2199023255552
    2a08:      	add	x9, x8, x9
    2a0c:      	lsr	x9, x9, #41
    2a10:      	cmp	x9, #0x3f
    2a14:      	b.hs	0x2d68 <ltmp0+0x2d68>
    2a18:      	fcvtzs	x9, d8
    2a1c:      	scvtf	d0, x9
    2a20:      	fcmp	d8, d0
    2a24:      	b.ne	0x2d68 <ltmp0+0x2d68>
    2a28:      	ldursb	w13, [x8, #-0x7]
    2a2c:      	tbnz	w13, #0x1f, 0x2d68 <ltmp0+0x2d68>
    2a30:      	ldurb	w13, [x8, #-0x8]
    2a34:      	cmp	w13, #0x9
    2a38:      	b.eq	0x2b38 <ltmp0+0x2b38>
    2a3c:      	cmp	w13, #0x2
    2a40:      	b.eq	0x2ae8 <ltmp0+0x2ae8>
    2a44:      	cmp	w13, #0x1
    2a48:      	b.ne	0x2d68 <ltmp0+0x2d68>
    2a4c:      	ldr	w10, [x8]
    2a50:      	mov	x11, x8
    2a54:      	ldurh	w13, [x8, #-0x6]
    2a58:      	adrp	x12, 0x2000 <ltmp0+0x2000>
		0000000000002a58:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    2a5c:      	ldr	x12, [x12]
		0000000000002a5c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    2a60:      	ldrb	w12, [x12]
    2a64:      	ldr	w8, [x8, #0x4]
    2a68:      	cmp	x10, x8
    2a6c:      	b.hi	0x2d68 <ltmp0+0x2d68>
    2a70:      	tbnz	w13, #0xa, 0x2d68 <ltmp0+0x2d68>
    2a74:      	cbnz	w12, 0x2d68 <ltmp0+0x2d68>
    2a78:      	cmp	x9, x10
    2a7c:      	b.hs	0x2d68 <ltmp0+0x2d68>
    2a80:      	add	x8, x11, x9, lsl #3
    2a84:      	ldr	d0, [x8, #0x8]
    2a88:      	fmov	x8, d0
    2a8c:      	mov	x9, #0x10               ; =16
    2a90:      	movk	x9, #0x7ffc, lsl #48
    2a94:      	cmp	x8, x9
    2a98:      	fcsel	d0, d10, d0, eq
    2a9c:      	b	0x2d84 <ltmp0+0x2d84>
    2aa0:      	add	x8, x8, #0x10
    2aa4:      	cmp	w11, #0x3
    2aa8:      	b.le	0x2acc <ltmp0+0x2acc>
    2aac:      	cmp	w11, #0x5
    2ab0:      	b.gt	0x2b84 <ltmp0+0x2b84>
    2ab4:      	cmp	w11, #0x4
    2ab8:      	b.eq	0x2c1c <ltmp0+0x2c1c>
    2abc:      	cmp	w11, #0x5
    2ac0:      	b.ne	0x2c10 <ltmp0+0x2c10>
    2ac4:      	ldr	s0, [x8, x9, lsl #2]
    2ac8:      	b	0x2c14 <ltmp0+0x2c14>
    2acc:      	cbz	w11, 0x2c08 <ltmp0+0x2c08>
    2ad0:      	cmp	w11, #0x2
    2ad4:      	b.eq	0x2c30 <ltmp0+0x2c30>
    2ad8:      	cmp	w11, #0x3
    2adc:      	b.ne	0x2c10 <ltmp0+0x2c10>
    2ae0:      	ldr	h0, [x8, x9, lsl #1]
    2ae4:      	b	0x2c14 <ltmp0+0x2c14>
    2ae8:      	ldr	x10, [x8, #0x8]
    2aec:      	cbz	x10, 0x2b9c <ltmp0+0x2b9c>
    2af0:      	ldr	x13, [x10, #0x60]
    2af4:      	cbz	x13, 0x2b9c <ltmp0+0x2b9c>
    2af8:      	ldurb	w8, [x13, #-0x8]
    2afc:      	cmp	w8, #0x1
    2b00:      	b.ne	0x2d68 <ltmp0+0x2d68>
    2b04:      	ldursb	w8, [x13, #-0x7]
    2b08:      	tbnz	w8, #0x1f, 0x2d68 <ltmp0+0x2d68>
    2b0c:      	ldr	w8, [x13]
    2b10:      	cmp	x9, x8
    2b14:      	b.hs	0x2d68 <ltmp0+0x2d68>
    2b18:      	add	x8, x13, x9, lsl #3
    2b1c:      	ldr	d0, [x8, #0x8]
    2b20:      	fmov	x8, d0
    2b24:      	mov	x9, #0x10               ; =16
    2b28:      	movk	x9, #0x7ffc, lsl #48
    2b2c:      	cmp	x8, x9
    2b30:      	b.eq	0x2d68 <ltmp0+0x2d68>
    2b34:      	b	0x2d84 <ltmp0+0x2d84>
    2b38:      	ldr	w12, [x8, #0x4]
    2b3c:      	ldr	x11, [x8, #0x20]
    2b40:      	ldurh	w13, [x8, #-0x6]
    2b44:      	tst	w13, #0xc00
    2b48:      	mov	w13, #0x5841            ; =22593
    2b4c:      	movk	w13, #0x4c5a, lsl #16
    2b50:      	ccmp	w12, w13, #0x0, eq
    2b54:      	cset	w12, eq
    2b58:      	cbz	x11, 0x2bd0 <ltmp0+0x2bd0>
    2b5c:      	tbz	w12, #0x0, 0x2bd0 <ltmp0+0x2bd0>
    2b60:      	ldurb	w10, [x11, #-0x8]
    2b64:      	cmp	w10, #0x1
    2b68:      	b.ne	0x2d68 <ltmp0+0x2d68>
    2b6c:      	ldursb	w10, [x11, #-0x7]
    2b70:      	tbnz	w10, #0x1f, 0x2d68 <ltmp0+0x2d68>
    2b74:      	ldr	w10, [x11]
    2b78:      	str	w10, [x8]
    2b7c:      	mov	x8, x11
    2b80:      	b	0x2a54 <ltmp0+0x2a54>
    2b84:      	cmp	w11, #0x6
    2b88:      	b.eq	0x2c24 <ltmp0+0x2c24>
    2b8c:      	cmp	w11, #0x7
    2b90:      	b.ne	0x2c10 <ltmp0+0x2c10>
    2b94:      	ldr	d0, [x8, x9, lsl #3]
    2b98:      	b	0x2d84 <ltmp0+0x2d84>
    2b9c:      	ldr	x12, [x12]
    2ba0:      	cbz	x12, 0x2d68 <ltmp0+0x2d68>
    2ba4:      	tbnz	x12, #0x3f, 0x2c3c <ltmp0+0x2c3c>
    2ba8:      	ldp	w14, w13, [x8]
    2bac:      	orr	x13, x13, x14, lsl #32
    2bb0:      	cmp	x13, x12
    2bb4:      	b.ne	0x2d68 <ltmp0+0x2d68>
    2bb8:      	ldp	x14, x12, [x11, #0x8]
    2bbc:      	ldp	x13, x11, [x11, #0x18]
    2bc0:      	cmp	x14, x11
    2bc4:      	b.lo	0x2c5c <ltmp0+0x2c5c>
    2bc8:      	cbz	x10, 0x2d68 <ltmp0+0x2d68>
    2bcc:      	b	0x2cac <ltmp0+0x2cac>
    2bd0:      	cmp	x11, #0x0
    2bd4:      	ldr	w14, [x8]
    2bd8:      	ldp	x11, x13, [x8, #0x28]
    2bdc:      	ccmp	x9, x14, #0x2, eq
    2be0:      	ccmp	x11, #0x0, #0x4, lo
    2be4:      	ccmp	x13, #0x0, #0x4, ne
    2be8:      	csel	w12, wzr, w12, eq
    2bec:      	tbz	w12, #0x0, 0x2d68 <ltmp0+0x2d68>
    2bf0:      	lsr	x12, x9, #6
    2bf4:      	ldr	x12, [x13, x12, lsl #3]
    2bf8:      	lsr	x12, x12, x9
    2bfc:      	tbz	w12, #0x0, 0x2c68 <ltmp0+0x2c68>
    2c00:      	ldr	d0, [x11, x9, lsl #3]
    2c04:      	b	0x2d84 <ltmp0+0x2d84>
    2c08:      	ldrsb	w8, [x8, x9]
    2c0c:      	b	0x2c34 <ltmp0+0x2c34>
    2c10:      	ldr	b0, [x8, x9]
    2c14:      	ucvtf	d0, d0
    2c18:      	b	0x2d84 <ltmp0+0x2d84>
    2c1c:      	ldr	w8, [x8, x9, lsl #2]
    2c20:      	b	0x2c34 <ltmp0+0x2c34>
    2c24:      	ldr	s0, [x8, x9, lsl #2]
    2c28:      	fcvt	d0, s0
    2c2c:      	b	0x2d84 <ltmp0+0x2d84>
    2c30:      	ldrsh	w8, [x8, x9, lsl #1]
    2c34:      	scvtf	d0, w8
    2c38:      	b	0x2d84 <ltmp0+0x2d84>
    2c3c:      	cbz	x10, 0x2d68 <ltmp0+0x2d68>
    2c40:      	ldr	x13, [x10, #0x30]
    2c44:      	cmp	x13, x12
    2c48:      	b.ne	0x2d68 <ltmp0+0x2d68>
    2c4c:      	ldp	x14, x12, [x11, #0x8]
    2c50:      	ldp	x13, x11, [x11, #0x18]
    2c54:      	cmp	x14, x11
    2c58:      	b.hs	0x2cac <ltmp0+0x2cac>
    2c5c:      	add	x14, x8, x14, lsl #3
    2c60:      	add	x14, x14, #0x10
    2c64:      	b	0x2cd0 <ltmp0+0x2cd0>
    2c68:      	ldr	x8, [x8, #0x50]
    2c6c:      	mov	w12, #0x6903            ; =26883
    2c70:      	movk	w12, #0x64, lsl #16
    2c74:      	cmp	x8, x12
    2c78:      	b.eq	0x2c80 <ltmp0+0x2c80>
    2c7c:      	cbnz	x8, 0x2d68 <ltmp0+0x2d68>
    2c80:      	mov	w12, #0x6903            ; =26883
    2c84:      	movk	w12, #0x64, lsl #16
    2c88:      	cmp	x8, x12
    2c8c:      	b.ne	0x2d38 <ltmp0+0x2d38>
    2c90:      	ldr	x8, [x11, x9, lsl #3]
    2c94:      	cbz	x8, 0x2d38 <ltmp0+0x2d38>
    2c98:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    2c9c:      	cmp	x8, x9
    2ca0:      	csel	x8, xzr, x8, eq
    2ca4:      	fmov	d1, x8
    2ca8:      	b	0x2f7c <ltmp0+0x2f7c>
    2cac:      	ldr	x16, [x10, #0x20]
    2cb0:      	cmp	x16, #0x0
    2cb4:      	csel	x15, x16, x10, ne
    2cb8:      	cbz	x16, 0x2d68 <ltmp0+0x2d68>
    2cbc:      	ldr	w16, [x15]
    2cc0:      	cmp	x14, x16
    2cc4:      	b.hs	0x2d68 <ltmp0+0x2d68>
    2cc8:      	add	x14, x15, x14, lsl #3
    2ccc:      	add	x14, x14, #0x8
    2cd0:      	ldr	d0, [x14]
    2cd4:      	fcmp	d8, d0
    2cd8:      	ccmp	x13, x9, #0x0, mi
    2cdc:      	cset	w13, hi
    2ce0:      	add	x9, x12, x9
    2ce4:      	cmp	x9, x11
    2ce8:      	ccmp	w13, #0x0, #0x4, lo
    2cec:      	b.ne	0x2d2c <ltmp0+0x2d2c>
    2cf0:      	cbz	x10, 0x2d68 <ltmp0+0x2d68>
    2cf4:      	cmp	x9, x11
    2cf8:      	b.lo	0x2d68 <ltmp0+0x2d68>
    2cfc:      	eor	w8, w13, #0x1
    2d00:      	tbnz	w8, #0x0, 0x2d68 <ltmp0+0x2d68>
    2d04:      	ldr	x11, [x10, #0x20]
    2d08:      	cmp	x11, #0x0
    2d0c:      	csel	x8, x11, x10, ne
    2d10:      	cbz	x11, 0x2d68 <ltmp0+0x2d68>
    2d14:      	ldr	w10, [x8]
    2d18:      	cmp	x9, x10
    2d1c:      	b.hs	0x2d68 <ltmp0+0x2d68>
    2d20:      	add	x8, x8, x9, lsl #3
    2d24:      	ldr	d0, [x8, #0x8]
    2d28:      	b	0x2d84 <ltmp0+0x2d84>
    2d2c:      	add	x8, x8, x9, lsl #3
    2d30:      	ldr	d0, [x8, #0x10]
    2d34:      	b	0x2d84 <ltmp0+0x2d84>
    2d38:      	fmov	d0, x10
    2d3c:      	mov.16b	v1, v8
    2d40:      	adrp	x0, 0x2000 <ltmp0+0x2000>
		0000000000002d40:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    2d44:      	add	x0, x0, #0x0
		0000000000002d44:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    2d48:      	mov	w1, #0x2                ; =2
    2d4c:      	bl	0x2d4c <ltmp0+0x2d4c>
		0000000000002d4c:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    2d50:      	mov.16b	v1, v0
    2d54:      	fmov	x8, d1
    2d58:      	mov	x9, #0x10               ; =16
    2d5c:      	movk	x9, #0x7ffc, lsl #48
    2d60:      	cmp	x8, x9
    2d64:      	b.ne	0x2f7c <ltmp0+0x2f7c>
    2d68:      	fmov	d0, x26
    2d6c:      	str	x20, [sp, #0x18]
    2d70:      	mov.16b	v1, v8
    2d74:      	mov	x0, x19
    2d78:      	bl	0x2d78 <ltmp0+0x2d78>
		0000000000002d78:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    2d7c:      	ldp	x26, x20, [sp, #0x10]
    2d80:      	ldr	x27, [sp, #0x8]
    2d84:      	fmov	x8, d0
    2d88:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    2d8c:      	and	x9, x8, x9
    2d90:      	cmp	x9, x21
    2d94:      	b.ne	0x2e00 <ltmp0+0x2e00>
    2d98:      	and	x0, x8, #0xffffffffffff
    2d9c:      	lsr	x8, x0, #20
    2da0:      	cbz	x8, 0x2f54 <ltmp0+0x2f54>
    2da4:      	ldurb	w9, [x0, #-0x8]
    2da8:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		0000000000002da8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__17
    2dac:      	ldr	x8, [x8]
		0000000000002dac:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__17
    2db0:      	cbz	x8, 0x2e70 <ltmp0+0x2e70>
    2db4:      	ldurh	w10, [x0, #-0x6]
    2db8:      	and	w10, w10, #0x800
    2dbc:      	cmp	w9, #0x2
    2dc0:      	ccmp	w10, #0x0, #0x0, eq
    2dc4:      	b.ne	0x2e70 <ltmp0+0x2e70>
    2dc8:      	ldr	w10, [x0, #0x4]
    2dcc:      	orr	x9, x10, #0x4000000000000000
    2dd0:      	ldr	x11, [x8]
    2dd4:      	cmp	w10, #0x0
    2dd8:      	ccmp	x9, x11, #0x0, ne
    2ddc:      	b.eq	0x2ea8 <ltmp0+0x2ea8>
    2de0:      	ldr	x11, [x8, #0x10]
    2de4:      	cbz	x11, 0x2ecc <ltmp0+0x2ecc>
    2de8:      	ldr	x12, [x0, #0x8]
    2dec:      	cbz	x12, 0x2ecc <ltmp0+0x2ecc>
    2df0:      	ldr	x12, [x12, #0x30]
    2df4:      	cmp	x12, x11
    2df8:      	b.eq	0x2e98 <ltmp0+0x2e98>
    2dfc:      	b	0x2ecc <ltmp0+0x2ecc>
    2e00:      	lsr	x9, x8, #48
    2e04:      	mov	w10, #0x7ff9            ; =32761
    2e08:      	cmp	x9, x10
    2e0c:      	b.eq	0x2e54 <ltmp0+0x2e54>
    2e10:      	mov	w10, #0x7ffe            ; =32766
    2e14:      	cmp	w9, w10
    2e18:      	b.ne	0x2e44 <ltmp0+0x2e44>
    2e1c:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		0000000000002e1c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    2e20:      	ldr	x9, [x9]
		0000000000002e20:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    2e24:      	str	x20, [sp, #0x18]
    2e28:      	and	x2, x9, #0xffffffffffff
    2e2c:      	mov	x0, #0x10               ; =16
    2e30:      	movk	x0, #0xddae, lsl #32
    2e34:      	movk	x0, #0x5556, lsl #48
    2e38:      	mov	x1, x8
    2e3c:      	bl	0x2e3c <ltmp0+0x2e3c>
		0000000000002e3c:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    2e40:      	b	0x2f70 <ltmp0+0x2f70>
    2e44:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    2e48:      	add	x9, x8, x9
    2e4c:      	cmp	x9, #0x2
    2e50:      	b.lo	0x302c <ltmp0+0x302c>
    2e54:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		0000000000002e54:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    2e58:      	ldr	x9, [x9]
		0000000000002e58:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    2e5c:      	str	x20, [sp, #0x18]
    2e60:      	and	x1, x9, #0xffffffffffff
    2e64:      	mov	x0, x8
    2e68:      	bl	0x2e68 <ltmp0+0x2e68>
		0000000000002e68:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    2e6c:      	b	0x2f70 <ltmp0+0x2f70>
    2e70:      	cmp	w9, #0x2
    2e74:      	ccmp	x8, #0x0, #0x4, eq
    2e78:      	b.eq	0x2f54 <ltmp0+0x2f54>
    2e7c:      	ldr	x9, [x8, #0x10]
    2e80:      	cbz	x9, 0x2f54 <ltmp0+0x2f54>
    2e84:      	ldr	x10, [x0, #0x8]
    2e88:      	cbz	x10, 0x2f54 <ltmp0+0x2f54>
    2e8c:      	ldr	x10, [x10, #0x30]
    2e90:      	cmp	x10, x9
    2e94:      	b.ne	0x2f54 <ltmp0+0x2f54>
    2e98:      	ldr	x8, [x8, #0x8]
    2e9c:      	add	x8, x0, x8, lsl #3
    2ea0:      	ldr	d1, [x8, #0x10]
    2ea4:      	b	0x2f7c <ltmp0+0x2f7c>
    2ea8:      	ldr	x2, [x8, #0x8]
    2eac:      	tbnz	w2, #0x1e, 0x300c <ltmp0+0x300c>
    2eb0:      	add	x11, x0, x2, lsl #3
    2eb4:      	ldr	d1, [x11, #0x10]
    2eb8:      	fmov	x11, d1
    2ebc:      	mov	x12, #0x10              ; =16
    2ec0:      	movk	x12, #0x7ffc, lsl #48
    2ec4:      	cmp	x11, x12
    2ec8:      	b.ne	0x2f7c <ltmp0+0x2f7c>
    2ecc:      	ldr	x11, [x8, #0x18]
    2ed0:      	cmp	x11, #0x0
    2ed4:      	b.le	0x2f54 <ltmp0+0x2f54>
    2ed8:      	ldr	x11, [x8, #0x20]
    2edc:      	ldr	x12, [x8, #0x30]
    2ee0:      	ldr	x13, [x8, #0x40]
    2ee4:      	cmp	x13, x9
    2ee8:      	ldr	x14, [x8, #0x50]
    2eec:      	ccmp	x14, x9, #0x4, ne
    2ef0:      	ccmp	x12, x9, #0x4, ne
    2ef4:      	ccmp	x11, x9, #0x4, ne
    2ef8:      	cset	w15, eq
    2efc:      	cmp	w10, #0x0
    2f00:      	ccmp	w15, #0x0, #0x4, ne
    2f04:      	b.eq	0x2f54 <ltmp0+0x2f54>
    2f08:      	ldr	x10, [x8, #0x48]
    2f0c:      	ldr	x15, [x8, #0x58]
    2f10:      	cmp	x14, x9
    2f14:      	csel	x14, x15, xzr, eq
    2f18:      	cmp	x13, x9
    2f1c:      	csel	x10, x10, x14, eq
    2f20:      	ldr	x13, [x8, #0x28]
    2f24:      	ldr	x8, [x8, #0x38]
    2f28:      	cmp	x12, x9
    2f2c:      	csel	x8, x8, x10, eq
    2f30:      	cmp	x11, x9
    2f34:      	csel	x8, x13, x8, eq
    2f38:      	add	x8, x0, x8, lsl #3
    2f3c:      	ldr	d1, [x8, #0x10]
    2f40:      	fmov	x8, d1
    2f44:      	mov	x9, #0x10               ; =16
    2f48:      	movk	x9, #0x7ffc, lsl #48
    2f4c:      	cmp	x8, x9
    2f50:      	b.ne	0x2f7c <ltmp0+0x2f7c>
    2f54:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		0000000000002f54:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    2f58:      	ldr	x8, [x8]
		0000000000002f58:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    2f5c:      	str	x20, [sp, #0x18]
    2f60:      	and	x1, x8, #0xffffffffffff
    2f64:      	adrp	x2, 0x2000 <ltmp0+0x2000>
		0000000000002f64:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__17
    2f68:      	add	x2, x2, #0x0
		0000000000002f68:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__17
    2f6c:      	bl	0x2f6c <ltmp0+0x2f6c>
		0000000000002f6c:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    2f70:      	mov.16b	v1, v0
    2f74:      	ldp	x27, x26, [sp, #0x8]
    2f78:      	ldr	x20, [sp, #0x18]
    2f7c:      	fmov	d0, x20
    2f80:      	and	x9, x20, #0xffff000000000000
    2f84:      	fmov	x8, d1
    2f88:      	and	x10, x8, #0xffff000000000000
    2f8c:      	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
    2f90:      	cmp	x8, x11
    2f94:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    2f98:      	ccmp	x10, x8, #0x2, hs
    2f9c:      	cset	w8, hi
    2fa0:      	mov	x10, #0x1               ; =1
    2fa4:      	movk	x10, #0x7fff, lsl #48
    2fa8:      	cmp	x9, x10
    2fac:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    2fb0:      	ccmp	x20, x9, #0x0, lo
    2fb4:      	b.hi	0x2fc4 <ltmp0+0x2fc4>
    2fb8:      	tbz	w8, #0x0, 0x2fc4 <ltmp0+0x2fc4>
    2fbc:      	fadd	d0, d1, d0
    2fc0:      	b	0x2fcc <ltmp0+0x2fcc>
    2fc4:      	bl	0x2fc4 <ltmp0+0x2fc4>
		0000000000002fc4:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    2fc8:      	ldp	x27, x26, [sp, #0x8]
    2fcc:      	fmov	x20, d0
    2fd0:      	mov	x0, x20
    2fd4:      	ldr	w8, [x23]
    2fd8:      	cbz	w8, 0x2fe0 <ltmp0+0x2fe0>
    2fdc:      	bl	0x2fdc <ltmp0+0x2fdc>
		0000000000002fdc:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    2fe0:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		0000000000002fe0:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    2fe4:      	ldr	x8, [x8]
		0000000000002fe4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    2fe8:      	ldr	w8, [x8]
    2fec:      	cbz	w8, 0x3000 <ltmp0+0x3000>
    2ff0:      	str	x20, [sp, #0x18]
    2ff4:      	bl	0x2ff4 <ltmp0+0x2ff4>
		0000000000002ff4:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    2ff8:      	ldp	x26, x20, [sp, #0x10]
    2ffc:      	ldr	x27, [sp, #0x8]
    3000:      	add	w28, w28, #0x1
    3004:      	tbz	w22, #0x0, 0x2900 <ltmp0+0x2900>
    3008:      	b	0x2940 <ltmp0+0x2940>
    300c:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		000000000000300c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    3010:      	ldr	x8, [x8]
		0000000000003010:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    3014:      	str	x20, [sp, #0x18]
    3018:      	and	x1, x8, #0xffffffffffff
    301c:      	adrp	x3, 0x3000 <ltmp0+0x3000>
		000000000000301c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__17
    3020:      	add	x3, x3, #0x0
		0000000000003020:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__17
    3024:      	bl	0x3024 <ltmp0+0x3024>
		0000000000003024:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    3028:      	b	0x2f70 <ltmp0+0x2f70>
    302c:      	mov	x9, #0x10               ; =16
    3030:      	movk	x9, #0x7ffc, lsl #48
    3034:      	sub	x9, x9, #0xe
    3038:      	cmp	x8, x9
    303c:      	cset	w0, eq
    3040:      	adrp	x1, 0x3000 <ltmp0+0x3000>
		0000000000003040:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    3044:      	add	x1, x1, #0x0
		0000000000003044:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    3048:      	mov	w2, #0x2                ; =2
    304c:      	bl	0x304c <ltmp0+0x304c>
		000000000000304c:  ARM64_RELOC_BRANCH26	_js_throw_type_error_property_access
    3050:      	brk	#0x1
    3054:      	mov	x9, #0x10               ; =16
    3058:      	movk	x9, #0x7ffc, lsl #48
    305c:      	sub	x9, x9, #0xe
    3060:      	cmp	x8, x9
    3064:      	cset	w0, eq
    3068:      	adrp	x1, 0x3000 <ltmp0+0x3000>
		0000000000003068:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.4.bytes
    306c:      	add	x1, x1, #0x0
		000000000000306c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.4.bytes
    3070:      	mov	w2, #0x4                ; =4
    3074:      	b	0x304c <ltmp0+0x304c>
    3078:      	mov	x9, #0x10               ; =16
    307c:      	movk	x9, #0x7ffc, lsl #48
    3080:      	sub	x9, x9, #0xe
    3084:      	cmp	x8, x9
    3088:      	cset	w0, eq
    308c:      	adrp	x1, 0x3000 <ltmp0+0x3000>
		000000000000308c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.5.bytes
    3090:      	add	x1, x1, #0x0
		0000000000003090:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.5.bytes
    3094:      	mov	w2, #0x6                ; =6
    3098:      	b	0x304c <ltmp0+0x304c>

000000000000309c <_perry_fn_access_worker_ts__run$generic>:
    309c:      	sub	sp, sp, #0xd0
    30a0:      	stp	d15, d14, [sp, #0x30]
    30a4:      	stp	d13, d12, [sp, #0x40]
    30a8:      	stp	d11, d10, [sp, #0x50]
    30ac:      	stp	d9, d8, [sp, #0x60]
    30b0:      	stp	x28, x27, [sp, #0x70]
    30b4:      	stp	x26, x25, [sp, #0x80]
    30b8:      	stp	x24, x23, [sp, #0x90]
    30bc:      	stp	x22, x21, [sp, #0xa0]
    30c0:      	stp	x20, x19, [sp, #0xb0]
    30c4:      	stp	x29, x30, [sp, #0xc0]
    30c8:      	add	x29, sp, #0xc0
    30cc:      	fmov	x26, d0
    30d0:      	fmov	x24, d1
    30d4:      	adrp	x19, 0x3000 <ltmp0+0x3000>
		00000000000030d4:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__1
    30d8:      	ldr	x8, [x19]
		00000000000030d8:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
    30dc:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		00000000000030dc:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.0.handle
    30e0:      	ldr	x9, [x9]
		00000000000030e0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.0.handle
    30e4:      	cmp	x8, x9
    30e8:      	b.ne	0x3138 <_perry_fn_access_worker_ts__run$generic+0x9c>
    30ec:      	mov	x8, x24
    30f0:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    30f4:      	cmp	x8, x9
    30f8:      	b.lo	0x31c8 <_perry_fn_access_worker_ts__run$generic+0x12c>
    30fc:      	and	x9, x8, #0xffff000000000000
    3100:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
    3104:      	cmp	x9, x10
    3108:      	b.hi	0x31c8 <_perry_fn_access_worker_ts__run$generic+0x12c>
    310c:      	mov	x8, x24
    3110:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    3114:      	cmp	x8, x9
    3118:      	b.lo	0x3344 <_perry_fn_access_worker_ts__run$generic+0x2a8>
    311c:      	and	x9, x8, #0xffff000000000000
    3120:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
    3124:      	cmp	x9, x10
    3128:      	b.hi	0x3344 <_perry_fn_access_worker_ts__run$generic+0x2a8>
    312c:      	str	wzr, [sp, #0x14]
    3130:      	mov	w27, #0x0               ; =0
    3134:      	b	0x3380 <_perry_fn_access_worker_ts__run$generic+0x2e4>
    3138:      	mov	w10, #0x7fff            ; =32767
    313c:      	cmp	x10, x8, lsr #48
    3140:      	b.ne	0x318c <_perry_fn_access_worker_ts__run$generic+0xf0>
    3144:      	and	x0, x8, #0xffffffffffff
    3148:      	cmp	x0, #0x1, lsl #12       ; =0x1000
    314c:      	b.lo	0x318c <_perry_fn_access_worker_ts__run$generic+0xf0>
    3150:      	ldr	w10, [x0, #0x4]
    3154:      	cmp	w10, #0x6
    3158:      	b.ne	0x318c <_perry_fn_access_worker_ts__run$generic+0xf0>
    315c:      	ldrb	w10, [x0, #0x14]
    3160:      	cmp	w10, #0x72
    3164:      	b.ne	0x318c <_perry_fn_access_worker_ts__run$generic+0xf0>
    3168:      	ldrb	w10, [x0, #0x19]
    316c:      	cmp	w10, #0x74
    3170:      	b.ne	0x318c <_perry_fn_access_worker_ts__run$generic+0xf0>
    3174:      	stp	x26, x24, [sp, #0x20]
    3178:      	and	x1, x9, #0xffffffffffff
    317c:      	bl	0x317c <_perry_fn_access_worker_ts__run$generic+0xe0>
		000000000000317c:  ARM64_RELOC_BRANCH26	_js_string_equals
    3180:      	ldp	x26, x24, [sp, #0x20]
    3184:      	cbnz	w0, 0x30ec <_perry_fn_access_worker_ts__run$generic+0x50>
    3188:      	ldr	x8, [x19]
		0000000000003188:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
    318c:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		000000000000318c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.2.handle
    3190:      	ldr	x9, [x9]
		0000000000003190:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.2.handle
    3194:      	cmp	x8, x9
    3198:      	b.ne	0x32a4 <_perry_fn_access_worker_ts__run$generic+0x208>
    319c:      	mov	x8, x24
    31a0:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    31a4:      	cmp	x8, x9
    31a8:      	b.lo	0x3b30 <_perry_fn_access_worker_ts__run$generic+0xa94>
    31ac:      	and	x9, x8, #0xffff000000000000
    31b0:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
    31b4:      	cmp	x9, x10
    31b8:      	b.hi	0x3b30 <_perry_fn_access_worker_ts__run$generic+0xa94>
    31bc:      	mov	w9, #0x0                ; =0
    31c0:      	mov	w27, #0x0               ; =0
    31c4:      	b	0x3c80 <_perry_fn_access_worker_ts__run$generic+0xbe4>
    31c8:      	fmov	d0, x8
    31cc:      	fcmp	d0, #0.0
    31d0:      	b.le	0x310c <_perry_fn_access_worker_ts__run$generic+0x70>
    31d4:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		00000000000031d4:  ARM64_RELOC_PAGE21	lCPI1_0
    31d8:      	ldr	d1, [x8]
		00000000000031d8:  ARM64_RELOC_PAGEOFF12	lCPI1_0
    31dc:      	fcmp	d0, d1
    31e0:      	b.hi	0x310c <_perry_fn_access_worker_ts__run$generic+0x70>
    31e4:      	fcvtzs	w19, d0
    31e8:      	scvtf	d1, w19
    31ec:      	fcmp	d0, d1
    31f0:      	b.ne	0x310c <_perry_fn_access_worker_ts__run$generic+0x70>
    31f4:      	mov	x20, #0x0               ; =0
    31f8:      	and	x21, x20, #0xffff000000000000
    31fc:      	mov	x8, x26
    3200:      	fmov	d0, x8
    3204:      	adrp	x1, 0x3000 <ltmp0+0x3000>
		0000000000003204:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    3208:      	add	x1, x1, #0x0
		0000000000003208:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    320c:      	mov	w0, #0x7                ; =7
    3210:      	mov	w2, #0x2                ; =2
    3214:      	bl	0x3214 <_perry_fn_access_worker_ts__run$generic+0x178>
		0000000000003214:  ARM64_RELOC_BRANCH26	_js_array_index_own_number
    3218:      	fmov	x8, d0
    321c:      	and	x9, x8, #0xffff000000000000
    3220:      	mov	x10, #0x7ff9000000000000 ; =9221401712017801216
    3224:      	cmp	x8, x10
    3228:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    322c:      	ccmp	x9, x8, #0x2, hs
    3230:      	cset	w8, hi
    3234:      	mov	x9, #0x1                ; =1
    3238:      	movk	x9, #0x7fff, lsl #48
    323c:      	cmp	x21, x9
    3240:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    3244:      	ccmp	x20, x9, #0x0, lo
    3248:      	b.hi	0x310c <_perry_fn_access_worker_ts__run$generic+0x70>
    324c:      	cbz	w8, 0x310c <_perry_fn_access_worker_ts__run$generic+0x70>
    3250:      	mov	x8, #0x0                ; =0
    3254:      	fmov	d1, x8
    3258:      	cmp	w19, #0x1
    325c:      	csinc	w8, w19, wzr, gt
    3260:      	fadd	d1, d0, d1
    3264:      	subs	w8, w8, #0x1
    3268:      	b.ne	0x3260 <_perry_fn_access_worker_ts__run$generic+0x1c4>
    326c:      	fmov	x20, d1
    3270:      	fmov	d0, x20
    3274:      	ldp	x29, x30, [sp, #0xc0]
    3278:      	ldp	x20, x19, [sp, #0xb0]
    327c:      	ldp	x22, x21, [sp, #0xa0]
    3280:      	ldp	x24, x23, [sp, #0x90]
    3284:      	ldp	x26, x25, [sp, #0x80]
    3288:      	ldp	x28, x27, [sp, #0x70]
    328c:      	ldp	d9, d8, [sp, #0x60]
    3290:      	ldp	d11, d10, [sp, #0x50]
    3294:      	ldp	d13, d12, [sp, #0x40]
    3298:      	ldp	d15, d14, [sp, #0x30]
    329c:      	add	sp, sp, #0xd0
    32a0:      	ret
    32a4:      	mov	w10, #0x7fff            ; =32767
    32a8:      	cmp	x10, x8, lsr #48
    32ac:      	b.ne	0x32f8 <_perry_fn_access_worker_ts__run$generic+0x25c>
    32b0:      	and	x0, x8, #0xffffffffffff
    32b4:      	cmp	x0, #0x1, lsl #12       ; =0x1000
    32b8:      	b.lo	0x32f8 <_perry_fn_access_worker_ts__run$generic+0x25c>
    32bc:      	ldr	w10, [x0, #0x4]
    32c0:      	cmp	w10, #0x6
    32c4:      	b.ne	0x32f8 <_perry_fn_access_worker_ts__run$generic+0x25c>
    32c8:      	ldrb	w10, [x0, #0x14]
    32cc:      	cmp	w10, #0x72
    32d0:      	b.ne	0x32f8 <_perry_fn_access_worker_ts__run$generic+0x25c>
    32d4:      	ldrb	w10, [x0, #0x19]
    32d8:      	cmp	w10, #0x6d
    32dc:      	b.ne	0x32f8 <_perry_fn_access_worker_ts__run$generic+0x25c>
    32e0:      	stp	x26, x24, [sp, #0x20]
    32e4:      	and	x1, x9, #0xffffffffffff
    32e8:      	bl	0x32e8 <_perry_fn_access_worker_ts__run$generic+0x24c>
		00000000000032e8:  ARM64_RELOC_BRANCH26	_js_string_equals
    32ec:      	ldp	x26, x24, [sp, #0x20]
    32f0:      	cbnz	w0, 0x319c <_perry_fn_access_worker_ts__run$generic+0x100>
    32f4:      	ldr	x8, [x19]
		00000000000032f4:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
    32f8:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		00000000000032f8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.3.handle
    32fc:      	ldr	x9, [x9]
		00000000000032fc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.3.handle
    3300:      	adrp	x27, 0x3000 <ltmp0+0x3000>
		0000000000003300:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    3304:      	ldr	x27, [x27]
		0000000000003304:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    3308:      	adrp	x21, 0x3000 <ltmp0+0x3000>
		0000000000003308:  ARM64_RELOC_PAGE21	lCPI1_2
    330c:      	adrp	x11, 0x3000 <ltmp0+0x3000>
		000000000000330c:  ARM64_RELOC_PAGE21	lCPI1_3
    3310:      	cmp	x8, x9
    3314:      	b.ne	0x3b74 <_perry_fn_access_worker_ts__run$generic+0xad8>
    3318:      	mov	x8, x24
    331c:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    3320:      	cmp	x8, x9
    3324:      	b.lo	0x3bf8 <_perry_fn_access_worker_ts__run$generic+0xb5c>
    3328:      	and	x9, x8, #0xffff000000000000
    332c:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
    3330:      	cmp	x9, x10
    3334:      	b.hi	0x3bf8 <_perry_fn_access_worker_ts__run$generic+0xb5c>
    3338:      	mov	w9, #0x0                ; =0
    333c:      	str	wzr, [sp, #0x14]
    3340:      	b	0x4520 <_perry_fn_access_worker_ts__run$generic+0x1484>
    3344:      	fmov	d0, x8
    3348:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
    334c:      	fmov	d1, x8
    3350:      	fcmp	d0, d1
    3354:      	b.lt	0x312c <_perry_fn_access_worker_ts__run$generic+0x90>
    3358:      	fcvtzs	w8, d0
    335c:      	scvtf	d1, w8
    3360:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		0000000000003360:  ARM64_RELOC_PAGE21	lCPI1_0
    3364:      	ldr	d2, [x9]
		0000000000003364:  ARM64_RELOC_PAGEOFF12	lCPI1_0
    3368:      	fcmp	d1, d0
    336c:      	cset	w9, eq
    3370:      	fcmp	d0, d2
    3374:      	csel	w8, wzr, w8, hi
    3378:      	str	w8, [sp, #0x14]
    337c:      	csel	w27, wzr, w9, hi
    3380:      	mov	w28, #0x0               ; =0
    3384:      	mov	x20, #0x0               ; =0
    3388:      	mov	x25, #0x10              ; =16
    338c:      	movk	x25, #0x7ffc, lsl #48
    3390:      	adrp	x22, 0x3000 <ltmp0+0x3000>
		0000000000003390:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    3394:      	ldr	x22, [x22]
		0000000000003394:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    3398:      	movi.2d	v10, #0000000000000000
    339c:      	mov	x21, #0x7ffd000000000000 ; =9222527611924643840
    33a0:      	adrp	x19, 0x3000 <ltmp0+0x3000>
		00000000000033a0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__18
    33a4:      	add	x19, x19, #0x0
		00000000000033a4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__18
    33a8:      	fmov	d11, #7.00000000
    33ac:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		00000000000033ac:  ARM64_RELOC_PAGE21	lCPI1_3
    33b0:      	ldr	d12, [x8]
		00000000000033b0:  ARM64_RELOC_PAGEOFF12	lCPI1_3
    33b4:      	adrp	x23, 0x3000 <ltmp0+0x3000>
		00000000000033b4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    33b8:      	ldr	x23, [x23]
		00000000000033b8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    33bc:      	fmov	d13, #1.00000000
    33c0:      	movi.2d	v8, #0000000000000000
    33c4:      	tbnz	w27, #0x0, 0x34b4 <_perry_fn_access_worker_ts__run$generic+0x418>
    33c8:      	mov	x8, x24
    33cc:      	fmov	d1, x8
    33d0:      	and	x9, x8, #0xffff000000000000
    33d4:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    33d8:      	cmp	x9, x10
    33dc:      	b.eq	0x341c <_perry_fn_access_worker_ts__run$generic+0x380>
    33e0:      	mov	x10, #0x7ff9000000000000 ; =9221401712017801216
    33e4:      	cmp	x8, x10
    33e8:      	b.lt	0x341c <_perry_fn_access_worker_ts__run$generic+0x380>
    33ec:      	mov	x10, #-0x7ffc000000000001 ; =-9222246136947933185
    33f0:      	add	x10, x8, x10
    33f4:      	cmp	x10, #0x3
    33f8:      	b.ls	0x341c <_perry_fn_access_worker_ts__run$generic+0x380>
    33fc:      	stp	x24, x20, [sp, #0x20]
    3400:      	str	x26, [sp, #0x18]
    3404:      	mov.16b	v0, v8
    3408:      	bl	0x3408 <_perry_fn_access_worker_ts__run$generic+0x36c>
		0000000000003408:  ARM64_RELOC_BRANCH26	_js_rel_lt
    340c:      	mov.16b	v9, v0
    3410:      	ldp	x26, x24, [sp, #0x18]
    3414:      	ldr	x20, [sp, #0x28]
    3418:      	b	0x3484 <_perry_fn_access_worker_ts__run$generic+0x3e8>
    341c:      	mov	x12, #0x10              ; =16
    3420:      	movk	x12, #0x7ffc, lsl #48
    3424:      	sub	x10, x12, #0xc
    3428:      	and	x11, x8, #0xfffffffffffffffe
    342c:      	mov	x25, #0x10              ; =16
    3430:      	movk	x25, #0x7ffc, lsl #48
    3434:      	sub	x12, x12, #0xe
    3438:      	scvtf	d0, w8
    343c:      	mov	x13, #0x7ffe000000000000 ; =9222809086901354496
    3440:      	cmp	x9, x13
    3444:      	fcsel	d0, d0, d1, eq
    3448:      	cmp	x11, x12
    344c:      	fcsel	d0, d10, d0, eq
    3450:      	cmp	x8, x10
    3454:      	fcsel	d0, d13, d0, eq
    3458:      	fmov	x8, d8
    345c:      	scvtf	d1, w8
    3460:      	mov	w9, #0x7ffe             ; =32766
    3464:      	cmp	x9, x8, lsr #48
    3468:      	fcsel	d1, d1, d8, eq
    346c:      	fcmp	d1, d0
    3470:      	mov	w8, #0x8                ; =8
    3474:      	csel	x8, x8, xzr, mi
    3478:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		0000000000003478:  ARM64_RELOC_PAGE21	lCPI1_1
    347c:      	add	x9, x9, #0x0
		000000000000347c:  ARM64_RELOC_PAGEOFF12	lCPI1_1
    3480:      	ldr	d9, [x9, x8]
    3484:      	ldr	w8, [x23]
    3488:      	cbz	w8, 0x34a0 <_perry_fn_access_worker_ts__run$generic+0x404>
    348c:      	stp	x26, x20, [sp, #0x20]
    3490:      	str	x24, [sp, #0x18]
    3494:      	bl	0x3494 <_perry_fn_access_worker_ts__run$generic+0x3f8>
		0000000000003494:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    3498:      	ldp	x24, x26, [sp, #0x18]
    349c:      	ldr	x20, [sp, #0x28]
    34a0:      	fmov	x8, d9
    34a4:      	sub	x9, x25, #0xc
    34a8:      	cmp	x8, x9
    34ac:      	b.ne	0x3270 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    34b0:      	b	0x34c0 <_perry_fn_access_worker_ts__run$generic+0x424>
    34b4:      	ldr	w8, [sp, #0x14]
    34b8:      	cmp	w28, w8
    34bc:      	b.ge	0x3270 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    34c0:      	mov	x0, x20
    34c4:      	ldr	w8, [x22]
    34c8:      	cbz	w8, 0x34d0 <_perry_fn_access_worker_ts__run$generic+0x434>
    34cc:      	bl	0x34cc <_perry_fn_access_worker_ts__run$generic+0x430>
		00000000000034cc:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    34d0:      	mov	x9, x26
    34d4:      	and	x8, x9, #0xffffffffffff
    34d8:      	and	x12, x9, #0xffff000000000000
    34dc:      	cmp	x12, x21
    34e0:      	b.ne	0x354c <_perry_fn_access_worker_ts__run$generic+0x4b0>
    34e4:      	adrp	x10, 0x3000 <ltmp0+0x3000>
		00000000000034e4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    34e8:      	ldr	x10, [x10]
		00000000000034e8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    34ec:      	ldr	x10, [x10]
    34f0:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
    34f4:      	cmp	x10, #0x0
    34f8:      	mov	x10, #0x7ffffff00000    ; =140737487306752
    34fc:      	ccmp	x11, x10, #0x2, eq
    3500:      	b.hs	0x354c <_perry_fn_access_worker_ts__run$generic+0x4b0>
    3504:      	ldurb	w11, [x8, #-0x8]
    3508:      	ldrb	w10, [x8, #0x8]
    350c:      	cmp	w11, #0xb
    3510:      	ccmp	w10, #0x9, #0x2, eq
    3514:      	b.hs	0x354c <_perry_fn_access_worker_ts__run$generic+0x4b0>
    3518:      	ldr	w11, [x8]
    351c:      	cmp	w11, #0x8
    3520:      	b.lo	0x354c <_perry_fn_access_worker_ts__run$generic+0x4b0>
    3524:      	cmp	w10, #0x3
    3528:      	b.le	0x3670 <_perry_fn_access_worker_ts__run$generic+0x5d4>
    352c:      	cmp	w10, #0x5
    3530:      	b.gt	0x36c0 <_perry_fn_access_worker_ts__run$generic+0x624>
    3534:      	cmp	w10, #0x4
    3538:      	b.eq	0x3758 <_perry_fn_access_worker_ts__run$generic+0x6bc>
    353c:      	cmp	w10, #0x5
    3540:      	b.ne	0x374c <_perry_fn_access_worker_ts__run$generic+0x6b0>
    3544:      	ldr	s0, [x8, #0x2c]
    3548:      	b	0x3750 <_perry_fn_access_worker_ts__run$generic+0x6b4>
    354c:      	ldr	x11, [x19]
    3550:      	cmp	x11, #0x0
    3554:      	csel	x10, x19, x11, eq
    3558:      	cmp	x12, x21
    355c:      	b.ne	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3560:      	mov	x12, #-0x20000000000    ; =-2199023255552
    3564:      	add	x12, x8, x12
    3568:      	lsr	x12, x12, #41
    356c:      	cmp	x12, #0x3f
    3570:      	b.hs	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3574:      	ldursb	w12, [x8, #-0x7]
    3578:      	tbnz	w12, #0x1f, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    357c:      	ldurb	w12, [x8, #-0x8]
    3580:      	cmp	w12, #0x9
    3584:      	b.eq	0x3624 <_perry_fn_access_worker_ts__run$generic+0x588>
    3588:      	cmp	w12, #0x2
    358c:      	b.eq	0x35e0 <_perry_fn_access_worker_ts__run$generic+0x544>
    3590:      	cmp	w12, #0x1
    3594:      	b.ne	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3598:      	ldr	w9, [x8]
    359c:      	mov	x10, x8
    35a0:      	ldurh	w12, [x8, #-0x6]
    35a4:      	adrp	x11, 0x3000 <ltmp0+0x3000>
		00000000000035a4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    35a8:      	ldr	x11, [x11]
		00000000000035a8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    35ac:      	ldrb	w11, [x11]
    35b0:      	tbnz	w12, #0xa, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    35b4:      	cbnz	w11, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    35b8:      	cmp	w9, #0x8
    35bc:      	b.lo	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    35c0:      	ldr	w8, [x8, #0x4]
    35c4:      	cmp	w9, w8
    35c8:      	b.hi	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    35cc:      	ldr	d0, [x10, #0x40]
    35d0:      	fmov	x8, d0
    35d4:      	cmp	x8, x25
    35d8:      	fcsel	d0, d12, d0, eq
    35dc:      	b	0x3884 <_perry_fn_access_worker_ts__run$generic+0x7e8>
    35e0:      	ldr	x9, [x8, #0x8]
    35e4:      	cbz	x9, 0x368c <_perry_fn_access_worker_ts__run$generic+0x5f0>
    35e8:      	ldr	x12, [x9, #0x60]
    35ec:      	cbz	x12, 0x368c <_perry_fn_access_worker_ts__run$generic+0x5f0>
    35f0:      	ldurb	w8, [x12, #-0x8]
    35f4:      	cmp	w8, #0x1
    35f8:      	b.ne	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    35fc:      	ldursb	w8, [x12, #-0x7]
    3600:      	tbnz	w8, #0x1f, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3604:      	ldr	w8, [x12]
    3608:      	cmp	w8, #0x8
    360c:      	b.lo	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3610:      	ldr	d0, [x12, #0x40]
    3614:      	fmov	x8, d0
    3618:      	cmp	x8, x25
    361c:      	b.eq	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3620:      	b	0x3884 <_perry_fn_access_worker_ts__run$generic+0x7e8>
    3624:      	ldr	w11, [x8, #0x4]
    3628:      	ldr	x10, [x8, #0x20]
    362c:      	ldurh	w12, [x8, #-0x6]
    3630:      	tst	w12, #0xc00
    3634:      	mov	w12, #0x5841            ; =22593
    3638:      	movk	w12, #0x4c5a, lsl #16
    363c:      	ccmp	w11, w12, #0x0, eq
    3640:      	cset	w11, eq
    3644:      	cbz	x10, 0x36d8 <_perry_fn_access_worker_ts__run$generic+0x63c>
    3648:      	tbz	w11, #0x0, 0x36d8 <_perry_fn_access_worker_ts__run$generic+0x63c>
    364c:      	ldurb	w9, [x10, #-0x8]
    3650:      	cmp	w9, #0x1
    3654:      	b.ne	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3658:      	ldursb	w9, [x10, #-0x7]
    365c:      	tbnz	w9, #0x1f, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3660:      	ldr	w9, [x10]
    3664:      	str	w9, [x8]
    3668:      	mov	x8, x10
    366c:      	b	0x35a0 <_perry_fn_access_worker_ts__run$generic+0x504>
    3670:      	cbz	w10, 0x3744 <_perry_fn_access_worker_ts__run$generic+0x6a8>
    3674:      	cmp	w10, #0x2
    3678:      	b.eq	0x376c <_perry_fn_access_worker_ts__run$generic+0x6d0>
    367c:      	cmp	w10, #0x3
    3680:      	b.ne	0x374c <_perry_fn_access_worker_ts__run$generic+0x6b0>
    3684:      	ldr	h0, [x8, #0x1e]
    3688:      	b	0x3750 <_perry_fn_access_worker_ts__run$generic+0x6b4>
    368c:      	ldr	x10, [x10]
    3690:      	cbz	x10, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3694:      	tbnz	x10, #0x3f, 0x3778 <_perry_fn_access_worker_ts__run$generic+0x6dc>
    3698:      	ldp	w13, w12, [x8]
    369c:      	orr	x12, x12, x13, lsl #32
    36a0:      	cmp	x12, x10
    36a4:      	b.ne	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    36a8:      	ldp	x13, x10, [x11, #0x8]
    36ac:      	ldp	x12, x11, [x11, #0x18]
    36b0:      	cmp	x13, x11
    36b4:      	b.lo	0x3798 <_perry_fn_access_worker_ts__run$generic+0x6fc>
    36b8:      	cbz	x9, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    36bc:      	b	0x37ac <_perry_fn_access_worker_ts__run$generic+0x710>
    36c0:      	cmp	w10, #0x6
    36c4:      	b.eq	0x3760 <_perry_fn_access_worker_ts__run$generic+0x6c4>
    36c8:      	cmp	w10, #0x7
    36cc:      	b.ne	0x374c <_perry_fn_access_worker_ts__run$generic+0x6b0>
    36d0:      	ldr	d0, [x8, #0x48]
    36d4:      	b	0x3884 <_perry_fn_access_worker_ts__run$generic+0x7e8>
    36d8:      	cmp	x10, #0x0
    36dc:      	ldr	w13, [x8]
    36e0:      	ldp	x10, x12, [x8, #0x28]
    36e4:      	ccmp	w13, #0x7, #0x0, eq
    36e8:      	ccmp	x10, #0x0, #0x4, hi
    36ec:      	ccmp	x12, #0x0, #0x4, ne
    36f0:      	csel	w11, wzr, w11, eq
    36f4:      	tbz	w11, #0x0, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    36f8:      	ldrb	w11, [x12]
    36fc:      	tbnz	w11, #0x7, 0x37a4 <_perry_fn_access_worker_ts__run$generic+0x708>
    3700:      	ldr	x8, [x8, #0x50]
    3704:      	mov	w11, #0x6903            ; =26883
    3708:      	movk	w11, #0x64, lsl #16
    370c:      	cmp	x8, x11
    3710:      	b.eq	0x3718 <_perry_fn_access_worker_ts__run$generic+0x67c>
    3714:      	cbnz	x8, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3718:      	mov	w11, #0x6903            ; =26883
    371c:      	movk	w11, #0x64, lsl #16
    3720:      	cmp	x8, x11
    3724:      	b.ne	0x3838 <_perry_fn_access_worker_ts__run$generic+0x79c>
    3728:      	ldr	x8, [x10, #0x38]
    372c:      	cbz	x8, 0x3838 <_perry_fn_access_worker_ts__run$generic+0x79c>
    3730:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    3734:      	cmp	x8, x9
    3738:      	csel	x8, xzr, x8, eq
    373c:      	fmov	d1, x8
    3740:      	b	0x3a78 <_perry_fn_access_worker_ts__run$generic+0x9dc>
    3744:      	ldrsb	w8, [x8, #0x17]
    3748:      	b	0x3770 <_perry_fn_access_worker_ts__run$generic+0x6d4>
    374c:      	ldr	b0, [x8, #0x17]
    3750:      	ucvtf	d0, d0
    3754:      	b	0x3884 <_perry_fn_access_worker_ts__run$generic+0x7e8>
    3758:      	ldr	w8, [x8, #0x2c]
    375c:      	b	0x3770 <_perry_fn_access_worker_ts__run$generic+0x6d4>
    3760:      	ldr	s0, [x8, #0x2c]
    3764:      	fcvt	d0, s0
    3768:      	b	0x3884 <_perry_fn_access_worker_ts__run$generic+0x7e8>
    376c:      	ldrsh	w8, [x8, #0x1e]
    3770:      	scvtf	d0, w8
    3774:      	b	0x3884 <_perry_fn_access_worker_ts__run$generic+0x7e8>
    3778:      	cbz	x9, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    377c:      	ldr	x12, [x9, #0x30]
    3780:      	cmp	x12, x10
    3784:      	b.ne	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3788:      	ldp	x13, x10, [x11, #0x8]
    378c:      	ldp	x12, x11, [x11, #0x18]
    3790:      	cmp	x13, x11
    3794:      	b.hs	0x37ac <_perry_fn_access_worker_ts__run$generic+0x710>
    3798:      	add	x13, x8, x13, lsl #3
    379c:      	add	x13, x13, #0x10
    37a0:      	b	0x37d0 <_perry_fn_access_worker_ts__run$generic+0x734>
    37a4:      	ldr	d0, [x10, #0x38]
    37a8:      	b	0x3884 <_perry_fn_access_worker_ts__run$generic+0x7e8>
    37ac:      	ldr	x15, [x9, #0x20]
    37b0:      	cmp	x15, #0x0
    37b4:      	csel	x14, x15, x9, ne
    37b8:      	cbz	x15, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    37bc:      	ldr	w15, [x14]
    37c0:      	cmp	x13, x15
    37c4:      	b.hs	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    37c8:      	add	x13, x14, x13, lsl #3
    37cc:      	add	x13, x13, #0x8
    37d0:      	ldr	d0, [x13]
    37d4:      	fcmp	d0, d11
    37d8:      	ccmp	x12, #0x7, #0x0, gt
    37dc:      	cset	w13, hi
    37e0:      	add	x12, x10, #0x7
    37e4:      	cmp	x12, x11
    37e8:      	b.hs	0x37fc <_perry_fn_access_worker_ts__run$generic+0x760>
    37ec:      	cbz	w13, 0x37fc <_perry_fn_access_worker_ts__run$generic+0x760>
    37f0:      	add	x8, x8, x12, lsl #3
    37f4:      	ldr	d0, [x8, #0x10]
    37f8:      	b	0x3884 <_perry_fn_access_worker_ts__run$generic+0x7e8>
    37fc:      	cbz	x9, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3800:      	cmp	x12, x11
    3804:      	b.lo	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3808:      	eor	w8, w13, #0x1
    380c:      	tbnz	w8, #0x0, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3810:      	ldr	x11, [x9, #0x20]
    3814:      	cmp	x11, #0x0
    3818:      	csel	x8, x11, x9, ne
    381c:      	cbz	x11, 0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    3820:      	ldr	w9, [x8]
    3824:      	cmp	x12, x9
    3828:      	b.hs	0x3860 <_perry_fn_access_worker_ts__run$generic+0x7c4>
    382c:      	add	x8, x8, x10, lsl #3
    3830:      	ldr	d0, [x8, #0x40]
    3834:      	b	0x3884 <_perry_fn_access_worker_ts__run$generic+0x7e8>
    3838:      	fmov	d0, x9
    383c:      	fmov	d1, #7.00000000
    3840:      	adrp	x0, 0x3000 <ltmp0+0x3000>
		0000000000003840:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    3844:      	add	x0, x0, #0x0
		0000000000003844:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    3848:      	mov	w1, #0x2                ; =2
    384c:      	bl	0x384c <_perry_fn_access_worker_ts__run$generic+0x7b0>
		000000000000384c:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    3850:      	mov.16b	v1, v0
    3854:      	fmov	x8, d1
    3858:      	cmp	x8, x25
    385c:      	b.ne	0x3a78 <_perry_fn_access_worker_ts__run$generic+0x9dc>
    3860:      	mov	x8, x26
    3864:      	stp	x24, x26, [sp, #0x20]
    3868:      	fmov	d0, x8
    386c:      	str	x20, [sp, #0x18]
    3870:      	fmov	d1, #7.00000000
    3874:      	mov	x0, x19
    3878:      	bl	0x3878 <_perry_fn_access_worker_ts__run$generic+0x7dc>
		0000000000003878:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    387c:      	ldp	x20, x24, [sp, #0x18]
    3880:      	ldr	x26, [sp, #0x28]
    3884:      	fmov	x8, d0
    3888:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    388c:      	and	x9, x8, x9
    3890:      	cmp	x9, x21
    3894:      	b.ne	0x3900 <_perry_fn_access_worker_ts__run$generic+0x864>
    3898:      	and	x0, x8, #0xffffffffffff
    389c:      	lsr	x8, x0, #20
    38a0:      	cbz	x8, 0x3a4c <_perry_fn_access_worker_ts__run$generic+0x9b0>
    38a4:      	ldurb	w9, [x0, #-0x8]
    38a8:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		00000000000038a8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__20
    38ac:      	ldr	x8, [x8]
		00000000000038ac:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__20
    38b0:      	cbz	x8, 0x3978 <_perry_fn_access_worker_ts__run$generic+0x8dc>
    38b4:      	ldurh	w10, [x0, #-0x6]
    38b8:      	and	w10, w10, #0x800
    38bc:      	cmp	w9, #0x2
    38c0:      	ccmp	w10, #0x0, #0x0, eq
    38c4:      	b.ne	0x3978 <_perry_fn_access_worker_ts__run$generic+0x8dc>
    38c8:      	ldr	w10, [x0, #0x4]
    38cc:      	orr	x9, x10, #0x4000000000000000
    38d0:      	cbz	w10, 0x39a4 <_perry_fn_access_worker_ts__run$generic+0x908>
    38d4:      	ldr	x11, [x8]
    38d8:      	cmp	x9, x11
    38dc:      	b.ne	0x39a4 <_perry_fn_access_worker_ts__run$generic+0x908>
    38e0:      	ldr	x2, [x8, #0x8]
    38e4:      	tbnz	w2, #0x1e, 0x3b0c <_perry_fn_access_worker_ts__run$generic+0xa70>
    38e8:      	add	x11, x0, x2, lsl #3
    38ec:      	ldr	d1, [x11, #0x10]
    38f0:      	fmov	x11, d1
    38f4:      	cmp	x11, x25
    38f8:      	b.ne	0x3a78 <_perry_fn_access_worker_ts__run$generic+0x9dc>
    38fc:      	b	0x39d0 <_perry_fn_access_worker_ts__run$generic+0x934>
    3900:      	lsr	x9, x8, #48
    3904:      	mov	w10, #0x7ff9            ; =32761
    3908:      	cmp	x9, x10
    390c:      	b.eq	0x3958 <_perry_fn_access_worker_ts__run$generic+0x8bc>
    3910:      	mov	w10, #0x7ffe            ; =32766
    3914:      	cmp	w9, w10
    3918:      	b.ne	0x3948 <_perry_fn_access_worker_ts__run$generic+0x8ac>
    391c:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		000000000000391c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    3920:      	ldr	x9, [x9]
		0000000000003920:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    3924:      	stp	x26, x20, [sp, #0x20]
    3928:      	str	x24, [sp, #0x18]
    392c:      	and	x2, x9, #0xffffffffffff
    3930:      	mov	x0, #0x13               ; =19
    3934:      	movk	x0, #0xddae, lsl #32
    3938:      	movk	x0, #0x5556, lsl #48
    393c:      	mov	x1, x8
    3940:      	bl	0x3940 <_perry_fn_access_worker_ts__run$generic+0x8a4>
		0000000000003940:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    3944:      	b	0x3a6c <_perry_fn_access_worker_ts__run$generic+0x9d0>
    3948:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    394c:      	add	x9, x8, x9
    3950:      	cmp	x9, #0x2
    3954:      	b.lo	0x6394 <_perry_fn_access_worker_ts__run$generic+0x32f8>
    3958:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		0000000000003958:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    395c:      	ldr	x9, [x9]
		000000000000395c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    3960:      	stp	x26, x20, [sp, #0x20]
    3964:      	str	x24, [sp, #0x18]
    3968:      	and	x1, x9, #0xffffffffffff
    396c:      	mov	x0, x8
    3970:      	bl	0x3970 <_perry_fn_access_worker_ts__run$generic+0x8d4>
		0000000000003970:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    3974:      	b	0x3a6c <_perry_fn_access_worker_ts__run$generic+0x9d0>
    3978:      	cmp	w9, #0x2
    397c:      	ccmp	x8, #0x0, #0x4, eq
    3980:      	b.eq	0x3a4c <_perry_fn_access_worker_ts__run$generic+0x9b0>
    3984:      	ldr	x9, [x8, #0x10]
    3988:      	cbz	x9, 0x3a4c <_perry_fn_access_worker_ts__run$generic+0x9b0>
    398c:      	ldr	x10, [x0, #0x8]
    3990:      	cbz	x10, 0x3a4c <_perry_fn_access_worker_ts__run$generic+0x9b0>
    3994:      	ldr	x10, [x10, #0x30]
    3998:      	cmp	x10, x9
    399c:      	b.eq	0x39c0 <_perry_fn_access_worker_ts__run$generic+0x924>
    39a0:      	b	0x3a4c <_perry_fn_access_worker_ts__run$generic+0x9b0>
    39a4:      	ldr	x11, [x8, #0x10]
    39a8:      	cbz	x11, 0x39d0 <_perry_fn_access_worker_ts__run$generic+0x934>
    39ac:      	ldr	x12, [x0, #0x8]
    39b0:      	cbz	x12, 0x39d0 <_perry_fn_access_worker_ts__run$generic+0x934>
    39b4:      	ldr	x12, [x12, #0x30]
    39b8:      	cmp	x12, x11
    39bc:      	b.ne	0x39d0 <_perry_fn_access_worker_ts__run$generic+0x934>
    39c0:      	ldr	x8, [x8, #0x8]
    39c4:      	add	x8, x0, x8, lsl #3
    39c8:      	ldr	d1, [x8, #0x10]
    39cc:      	b	0x3a78 <_perry_fn_access_worker_ts__run$generic+0x9dc>
    39d0:      	ldr	x11, [x8, #0x18]
    39d4:      	cmp	x11, #0x0
    39d8:      	b.le	0x3a4c <_perry_fn_access_worker_ts__run$generic+0x9b0>
    39dc:      	ldr	x11, [x8, #0x20]
    39e0:      	ldr	x12, [x8, #0x30]
    39e4:      	ldr	x13, [x8, #0x40]
    39e8:      	cmp	x13, x9
    39ec:      	ldr	x14, [x8, #0x50]
    39f0:      	ccmp	x14, x9, #0x4, ne
    39f4:      	ccmp	x12, x9, #0x4, ne
    39f8:      	ccmp	x11, x9, #0x4, ne
    39fc:      	cset	w15, eq
    3a00:      	cbz	w10, 0x3a4c <_perry_fn_access_worker_ts__run$generic+0x9b0>
    3a04:      	cbz	w15, 0x3a4c <_perry_fn_access_worker_ts__run$generic+0x9b0>
    3a08:      	ldr	x10, [x8, #0x48]
    3a0c:      	ldr	x15, [x8, #0x58]
    3a10:      	cmp	x14, x9
    3a14:      	csel	x14, x15, xzr, eq
    3a18:      	cmp	x13, x9
    3a1c:      	csel	x10, x10, x14, eq
    3a20:      	ldr	x13, [x8, #0x28]
    3a24:      	ldr	x8, [x8, #0x38]
    3a28:      	cmp	x12, x9
    3a2c:      	csel	x8, x8, x10, eq
    3a30:      	cmp	x11, x9
    3a34:      	csel	x8, x13, x8, eq
    3a38:      	add	x8, x0, x8, lsl #3
    3a3c:      	ldr	d1, [x8, #0x10]
    3a40:      	fmov	x8, d1
    3a44:      	cmp	x8, x25
    3a48:      	b.ne	0x3a78 <_perry_fn_access_worker_ts__run$generic+0x9dc>
    3a4c:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003a4c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    3a50:      	ldr	x8, [x8]
		0000000000003a50:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    3a54:      	stp	x26, x20, [sp, #0x20]
    3a58:      	str	x24, [sp, #0x18]
    3a5c:      	and	x1, x8, #0xffffffffffff
    3a60:      	adrp	x2, 0x3000 <ltmp0+0x3000>
		0000000000003a60:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__20
    3a64:      	add	x2, x2, #0x0
		0000000000003a64:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__20
    3a68:      	bl	0x3a68 <_perry_fn_access_worker_ts__run$generic+0x9cc>
		0000000000003a68:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    3a6c:      	mov.16b	v1, v0
    3a70:      	ldp	x24, x26, [sp, #0x18]
    3a74:      	ldr	x20, [sp, #0x28]
    3a78:      	fmov	d0, x20
    3a7c:      	and	x9, x20, #0xffff000000000000
    3a80:      	fmov	x8, d1
    3a84:      	and	x10, x8, #0xffff000000000000
    3a88:      	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
    3a8c:      	cmp	x8, x11
    3a90:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    3a94:      	ccmp	x10, x8, #0x2, hs
    3a98:      	cset	w8, hi
    3a9c:      	mov	x10, #0x1               ; =1
    3aa0:      	movk	x10, #0x7fff, lsl #48
    3aa4:      	cmp	x9, x10
    3aa8:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    3aac:      	ccmp	x20, x9, #0x0, lo
    3ab0:      	b.hi	0x3ac0 <_perry_fn_access_worker_ts__run$generic+0xa24>
    3ab4:      	tbz	w8, #0x0, 0x3ac0 <_perry_fn_access_worker_ts__run$generic+0xa24>
    3ab8:      	fadd	d0, d1, d0
    3abc:      	b	0x3acc <_perry_fn_access_worker_ts__run$generic+0xa30>
    3ac0:      	stp	x24, x26, [sp, #0x20]
    3ac4:      	bl	0x3ac4 <_perry_fn_access_worker_ts__run$generic+0xa28>
		0000000000003ac4:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    3ac8:      	ldp	x24, x26, [sp, #0x20]
    3acc:      	fmov	x20, d0
    3ad0:      	mov	x0, x20
    3ad4:      	ldr	w8, [x22]
    3ad8:      	cbz	w8, 0x3ae0 <_perry_fn_access_worker_ts__run$generic+0xa44>
    3adc:      	bl	0x3adc <_perry_fn_access_worker_ts__run$generic+0xa40>
		0000000000003adc:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    3ae0:      	ldr	w8, [x23]
    3ae4:      	cbz	w8, 0x3afc <_perry_fn_access_worker_ts__run$generic+0xa60>
    3ae8:      	stp	x26, x24, [sp, #0x20]
    3aec:      	str	x20, [sp, #0x18]
    3af0:      	bl	0x3af0 <_perry_fn_access_worker_ts__run$generic+0xa54>
		0000000000003af0:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    3af4:      	ldp	x20, x26, [sp, #0x18]
    3af8:      	ldr	x24, [sp, #0x28]
    3afc:      	fadd	d8, d8, d13
    3b00:      	add	w28, w28, #0x1
    3b04:      	tbz	w27, #0x0, 0x33c8 <_perry_fn_access_worker_ts__run$generic+0x32c>
    3b08:      	b	0x34b4 <_perry_fn_access_worker_ts__run$generic+0x418>
    3b0c:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003b0c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    3b10:      	ldr	x8, [x8]
		0000000000003b10:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    3b14:      	stp	x26, x20, [sp, #0x20]
    3b18:      	str	x24, [sp, #0x18]
    3b1c:      	and	x1, x8, #0xffffffffffff
    3b20:      	adrp	x3, 0x3000 <ltmp0+0x3000>
		0000000000003b20:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__20
    3b24:      	add	x3, x3, #0x0
		0000000000003b24:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__20
    3b28:      	bl	0x3b28 <_perry_fn_access_worker_ts__run$generic+0xa8c>
		0000000000003b28:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    3b2c:      	b	0x3a6c <_perry_fn_access_worker_ts__run$generic+0x9d0>
    3b30:      	mov	w9, #0x0                ; =0
    3b34:      	fmov	d0, x8
    3b38:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
    3b3c:      	fmov	d1, x8
    3b40:      	fcmp	d0, d1
    3b44:      	b.lt	0x3c7c <_perry_fn_access_worker_ts__run$generic+0xbe0>
    3b48:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003b48:  ARM64_RELOC_PAGE21	lCPI1_0
    3b4c:      	ldr	d1, [x8]
		0000000000003b4c:  ARM64_RELOC_PAGEOFF12	lCPI1_0
    3b50:      	fcmp	d0, d1
    3b54:      	mov	x27, x9
    3b58:      	b.hi	0x3c80 <_perry_fn_access_worker_ts__run$generic+0xbe4>
    3b5c:      	fcvtzs	w9, d0
    3b60:      	scvtf	d1, w9
    3b64:      	fcmp	d1, d0
    3b68:      	b.ne	0x31c0 <_perry_fn_access_worker_ts__run$generic+0x124>
    3b6c:      	mov	w27, #0x1               ; =1
    3b70:      	b	0x3c80 <_perry_fn_access_worker_ts__run$generic+0xbe4>
    3b74:      	mov	w10, #0x7fff            ; =32767
    3b78:      	cmp	x10, x8, lsr #48
    3b7c:      	b.ne	0x3bcc <_perry_fn_access_worker_ts__run$generic+0xb30>
    3b80:      	and	x0, x8, #0xffffffffffff
    3b84:      	cmp	x0, #0x1, lsl #12       ; =0x1000
    3b88:      	b.lo	0x3bcc <_perry_fn_access_worker_ts__run$generic+0xb30>
    3b8c:      	ldr	w8, [x0, #0x4]
    3b90:      	cmp	w8, #0x6
    3b94:      	b.ne	0x3bcc <_perry_fn_access_worker_ts__run$generic+0xb30>
    3b98:      	ldrb	w8, [x0, #0x14]
    3b9c:      	cmp	w8, #0x66
    3ba0:      	b.ne	0x3bcc <_perry_fn_access_worker_ts__run$generic+0xb30>
    3ba4:      	ldrb	w8, [x0, #0x19]
    3ba8:      	cmp	w8, #0x73
    3bac:      	b.ne	0x3bcc <_perry_fn_access_worker_ts__run$generic+0xb30>
    3bb0:      	stp	x26, x24, [sp, #0x20]
    3bb4:      	and	x1, x9, #0xffffffffffff
    3bb8:      	mov	x19, x11
    3bbc:      	bl	0x3bbc <_perry_fn_access_worker_ts__run$generic+0xb20>
		0000000000003bbc:  ARM64_RELOC_BRANCH26	_js_string_equals
    3bc0:      	mov	x11, x19
    3bc4:      	ldp	x26, x24, [sp, #0x20]
    3bc8:      	cbnz	w0, 0x3318 <_perry_fn_access_worker_ts__run$generic+0x27c>
    3bcc:      	mov	x8, x24
    3bd0:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    3bd4:      	cmp	x8, x9
    3bd8:      	b.lo	0x3c3c <_perry_fn_access_worker_ts__run$generic+0xba0>
    3bdc:      	and	x9, x8, #0xffff000000000000
    3be0:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
    3be4:      	cmp	x9, x10
    3be8:      	b.hi	0x3c3c <_perry_fn_access_worker_ts__run$generic+0xba0>
    3bec:      	mov	w22, #0x0               ; =0
    3bf0:      	mov	w25, #0x0               ; =0
    3bf4:      	b	0x5b6c <_perry_fn_access_worker_ts__run$generic+0x2ad0>
    3bf8:      	mov	w9, #0x0                ; =0
    3bfc:      	fmov	d0, x8
    3c00:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
    3c04:      	fmov	d1, x8
    3c08:      	fcmp	d0, d1
    3c0c:      	b.lt	0x451c <_perry_fn_access_worker_ts__run$generic+0x1480>
    3c10:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003c10:  ARM64_RELOC_PAGE21	lCPI1_0
    3c14:      	ldr	d1, [x8]
		0000000000003c14:  ARM64_RELOC_PAGEOFF12	lCPI1_0
    3c18:      	fcmp	d0, d1
    3c1c:      	str	w9, [sp, #0x14]
    3c20:      	b.hi	0x4520 <_perry_fn_access_worker_ts__run$generic+0x1484>
    3c24:      	fcvtzs	w9, d0
    3c28:      	frintz	d1, d0
    3c2c:      	fcmp	d1, d0
    3c30:      	cset	w8, eq
    3c34:      	str	w8, [sp, #0x14]
    3c38:      	b	0x4520 <_perry_fn_access_worker_ts__run$generic+0x1484>
    3c3c:      	mov	w22, #0x0               ; =0
    3c40:      	fmov	d0, x8
    3c44:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
    3c48:      	fmov	d1, x8
    3c4c:      	fcmp	d0, d1
    3c50:      	b.lt	0x5b68 <_perry_fn_access_worker_ts__run$generic+0x2acc>
    3c54:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003c54:  ARM64_RELOC_PAGE21	lCPI1_0
    3c58:      	ldr	d1, [x8]
		0000000000003c58:  ARM64_RELOC_PAGEOFF12	lCPI1_0
    3c5c:      	fcmp	d0, d1
    3c60:      	mov	x25, x22
    3c64:      	b.hi	0x5b6c <_perry_fn_access_worker_ts__run$generic+0x2ad0>
    3c68:      	fcvtzs	w22, d0
    3c6c:      	frintz	d1, d0
    3c70:      	fcmp	d1, d0
    3c74:      	cset	w25, eq
    3c78:      	b	0x5b6c <_perry_fn_access_worker_ts__run$generic+0x2ad0>
    3c7c:      	mov	x27, x9
    3c80:      	str	w9, [sp, #0x14]
    3c84:      	mov	w28, #0x0               ; =0
    3c88:      	mov	x20, #0x0               ; =0
    3c8c:      	mov	x21, #0x7ff9000000000000 ; =9221401712017801216
    3c90:      	fmov	d12, #17.00000000
    3c94:      	adrp	x22, 0x3000 <ltmp0+0x3000>
		0000000000003c94:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    3c98:      	ldr	x22, [x22]
		0000000000003c98:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    3c9c:      	mov	x25, #0x7ffd000000000000 ; =9222527611924643840
    3ca0:      	fmov	d13, #7.00000000
    3ca4:      	mov	x8, #0x41f0000000000000 ; =4751297606875873280
    3ca8:      	fmov	d14, x8
    3cac:      	adrp	x19, 0x3000 <ltmp0+0x3000>
		0000000000003cac:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__21
    3cb0:      	add	x19, x19, #0x0
		0000000000003cb0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__21
    3cb4:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003cb4:  ARM64_RELOC_PAGE21	lCPI1_2
    3cb8:      	ldr	d15, [x8]
		0000000000003cb8:  ARM64_RELOC_PAGEOFF12	lCPI1_2
    3cbc:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003cbc:  ARM64_RELOC_PAGE21	lCPI1_3
    3cc0:      	ldr	d0, [x8]
		0000000000003cc0:  ARM64_RELOC_PAGEOFF12	lCPI1_3
    3cc4:      	str	d0, [sp, #0x8]
    3cc8:      	mov	x23, #0x7fff000000000000 ; =9223090561878065152
    3ccc:      	fmov	d11, #1.00000000
    3cd0:      	movi.2d	v8, #0000000000000000
    3cd4:      	movi.2d	v9, #0000000000000000
    3cd8:      	tbnz	w27, #0x0, 0x3dd0 <_perry_fn_access_worker_ts__run$generic+0xd34>
    3cdc:      	mov	x8, x24
    3ce0:      	fmov	d1, x8
    3ce4:      	and	x9, x8, #0xffff000000000000
    3ce8:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    3cec:      	cmp	x9, x10
    3cf0:      	b.eq	0x3d2c <_perry_fn_access_worker_ts__run$generic+0xc90>
    3cf4:      	cmp	x8, x21
    3cf8:      	b.lt	0x3d2c <_perry_fn_access_worker_ts__run$generic+0xc90>
    3cfc:      	mov	x10, #-0x7ffc000000000001 ; =-9222246136947933185
    3d00:      	add	x10, x8, x10
    3d04:      	cmp	x10, #0x3
    3d08:      	b.ls	0x3d2c <_perry_fn_access_worker_ts__run$generic+0xc90>
    3d0c:      	stp	x20, x24, [sp, #0x20]
    3d10:      	str	x26, [sp, #0x18]
    3d14:      	mov.16b	v0, v8
    3d18:      	bl	0x3d18 <_perry_fn_access_worker_ts__run$generic+0xc7c>
		0000000000003d18:  ARM64_RELOC_BRANCH26	_js_rel_lt
    3d1c:      	mov.16b	v10, v0
    3d20:      	ldp	x26, x20, [sp, #0x18]
    3d24:      	ldr	x24, [sp, #0x28]
    3d28:      	b	0x3d90 <_perry_fn_access_worker_ts__run$generic+0xcf4>
    3d2c:      	mov	x12, #0x10              ; =16
    3d30:      	movk	x12, #0x7ffc, lsl #48
    3d34:      	sub	x10, x12, #0xc
    3d38:      	and	x11, x8, #0xfffffffffffffffe
    3d3c:      	sub	x12, x12, #0xe
    3d40:      	scvtf	d0, w8
    3d44:      	mov	x13, #0x7ffe000000000000 ; =9222809086901354496
    3d48:      	cmp	x9, x13
    3d4c:      	fcsel	d0, d0, d1, eq
    3d50:      	cmp	x11, x12
    3d54:      	movi.2d	v1, #0000000000000000
    3d58:      	fcsel	d0, d1, d0, eq
    3d5c:      	cmp	x8, x10
    3d60:      	fcsel	d0, d11, d0, eq
    3d64:      	fmov	x8, d8
    3d68:      	scvtf	d1, w8
    3d6c:      	mov	w9, #0x7ffe             ; =32766
    3d70:      	cmp	x9, x8, lsr #48
    3d74:      	fcsel	d1, d1, d8, eq
    3d78:      	fcmp	d1, d0
    3d7c:      	mov	w8, #0x8                ; =8
    3d80:      	csel	x8, x8, xzr, mi
    3d84:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		0000000000003d84:  ARM64_RELOC_PAGE21	lCPI1_1
    3d88:      	add	x9, x9, #0x0
		0000000000003d88:  ARM64_RELOC_PAGEOFF12	lCPI1_1
    3d8c:      	ldr	d10, [x9, x8]
    3d90:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003d90:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    3d94:      	ldr	x8, [x8]
		0000000000003d94:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    3d98:      	ldr	w8, [x8]
    3d9c:      	cbz	w8, 0x3db4 <_perry_fn_access_worker_ts__run$generic+0xd18>
    3da0:      	stp	x20, x24, [sp, #0x20]
    3da4:      	str	x26, [sp, #0x18]
    3da8:      	bl	0x3da8 <_perry_fn_access_worker_ts__run$generic+0xd0c>
		0000000000003da8:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    3dac:      	ldp	x26, x20, [sp, #0x18]
    3db0:      	ldr	x24, [sp, #0x28]
    3db4:      	fmov	x8, d10
    3db8:      	mov	x9, #0x10               ; =16
    3dbc:      	movk	x9, #0x7ffc, lsl #48
    3dc0:      	sub	x9, x9, #0xc
    3dc4:      	cmp	x8, x9
    3dc8:      	b.ne	0x3270 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    3dcc:      	b	0x3ddc <_perry_fn_access_worker_ts__run$generic+0xd40>
    3dd0:      	ldr	w8, [sp, #0x14]
    3dd4:      	cmp	w28, w8
    3dd8:      	b.ge	0x3270 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    3ddc:      	fmov	x8, d9
    3de0:      	cmp	x8, x21
    3de4:      	b.lo	0x3e14 <_perry_fn_access_worker_ts__run$generic+0xd78>
    3de8:      	and	x8, x8, #0xffff000000000000
    3dec:      	cmp	x8, x23
    3df0:      	b.hi	0x3e14 <_perry_fn_access_worker_ts__run$generic+0xd78>
    3df4:      	stp	x20, x24, [sp, #0x20]
    3df8:      	str	x26, [sp, #0x18]
    3dfc:      	fmov	d1, #17.00000000
    3e00:      	mov.16b	v0, v9
    3e04:      	bl	0x3e04 <_perry_fn_access_worker_ts__run$generic+0xd68>
		0000000000003e04:  ARM64_RELOC_BRANCH26	_js_dynamic_mul
    3e08:      	ldp	x26, x20, [sp, #0x18]
    3e0c:      	ldr	x24, [sp, #0x28]
    3e10:      	b	0x3e18 <_perry_fn_access_worker_ts__run$generic+0xd7c>
    3e14:      	fmul	d0, d9, d12
    3e18:      	fadd	d0, d0, d13
    3e1c:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003e1c:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    3e20:      	ldr	d1, [x8]
		0000000000003e20:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    3e24:      	stp	x26, x20, [sp, #0x20]
    3e28:      	str	x24, [sp, #0x18]
    3e2c:      	bl	0x3e2c <_perry_fn_access_worker_ts__run$generic+0xd90>
		0000000000003e2c:  ARM64_RELOC_BRANCH26	_js_dynamic_mod
    3e30:      	mov.16b	v9, v0
    3e34:      	ldp	x24, x26, [sp, #0x18]
    3e38:      	ldr	x20, [sp, #0x28]
    3e3c:      	fmov	x8, d9
    3e40:      	mov	w9, #0x7fff             ; =32767
    3e44:      	cmp	x9, x8, lsr #48
    3e48:      	b.ne	0x3e54 <_perry_fn_access_worker_ts__run$generic+0xdb8>
    3e4c:      	mov.16b	v0, v9
    3e50:      	bl	0x3e50 <_perry_fn_access_worker_ts__run$generic+0xdb4>
		0000000000003e50:  ARM64_RELOC_BRANCH26	_js_string_addref_if_heap_string
    3e54:      	mov	x0, x20
    3e58:      	ldr	w8, [x22]
    3e5c:      	cbz	w8, 0x3e64 <_perry_fn_access_worker_ts__run$generic+0xdc8>
    3e60:      	bl	0x3e60 <_perry_fn_access_worker_ts__run$generic+0xdc4>
		0000000000003e60:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    3e64:      	mov	x10, x26
    3e68:      	and	x8, x10, #0xffffffffffff
    3e6c:      	and	x13, x10, #0xffff000000000000
    3e70:      	cmp	x13, x25
    3e74:      	b.ne	0x3ed0 <_perry_fn_access_worker_ts__run$generic+0xe34>
    3e78:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		0000000000003e78:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    3e7c:      	ldr	x9, [x9]
		0000000000003e7c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    3e80:      	ldr	x9, [x9]
    3e84:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
    3e88:      	cmp	x9, #0x0
    3e8c:      	mov	x9, #0x7ffffff00000     ; =140737487306752
    3e90:      	ccmp	x11, x9, #0x2, eq
    3e94:      	b.hs	0x3ed0 <_perry_fn_access_worker_ts__run$generic+0xe34>
    3e98:      	fcmp	d9, d14
    3e9c:      	b.pl	0x3ed0 <_perry_fn_access_worker_ts__run$generic+0xe34>
    3ea0:      	ldurb	w9, [x8, #-0x8]
    3ea4:      	ldrb	w11, [x8, #0x8]
    3ea8:      	fcmp	d9, #0.0
    3eac:      	ccmp	w9, #0xb, #0x0, ge
    3eb0:      	ccmp	w11, #0x9, #0x2, eq
    3eb4:      	b.hs	0x3ed0 <_perry_fn_access_worker_ts__run$generic+0xe34>
    3eb8:      	fcvtzs	x9, d9
    3ebc:      	scvtf	d0, x9
    3ec0:      	ldr	w12, [x8]
    3ec4:      	fcmp	d9, d0
    3ec8:      	ccmp	x9, x12, #0x2, eq
    3ecc:      	b.lo	0x3f94 <_perry_fn_access_worker_ts__run$generic+0xef8>
    3ed0:      	ldr	x11, [x19]
    3ed4:      	cmp	x11, #0x0
    3ed8:      	csel	x12, x19, x11, eq
    3edc:      	cmp	x13, x25
    3ee0:      	b.ne	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    3ee4:      	fcmp	d9, #0.0
    3ee8:      	b.lt	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    3eec:      	fcmp	d9, d15
    3ef0:      	b.pl	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    3ef4:      	mov	x9, #-0x20000000000     ; =-2199023255552
    3ef8:      	add	x9, x8, x9
    3efc:      	lsr	x9, x9, #41
    3f00:      	cmp	x9, #0x3f
    3f04:      	b.hs	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    3f08:      	fcvtzs	x9, d9
    3f0c:      	scvtf	d0, x9
    3f10:      	fcmp	d9, d0
    3f14:      	b.ne	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    3f18:      	ldursb	w13, [x8, #-0x7]
    3f1c:      	tbnz	w13, #0x1f, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    3f20:      	ldurb	w13, [x8, #-0x8]
    3f24:      	cmp	w13, #0x9
    3f28:      	b.eq	0x402c <_perry_fn_access_worker_ts__run$generic+0xf90>
    3f2c:      	cmp	w13, #0x2
    3f30:      	b.eq	0x3fdc <_perry_fn_access_worker_ts__run$generic+0xf40>
    3f34:      	cmp	w13, #0x1
    3f38:      	b.ne	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    3f3c:      	ldr	w10, [x8]
    3f40:      	mov	x11, x8
    3f44:      	ldurh	w13, [x8, #-0x6]
    3f48:      	adrp	x12, 0x3000 <ltmp0+0x3000>
		0000000000003f48:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    3f4c:      	ldr	x12, [x12]
		0000000000003f4c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    3f50:      	ldrb	w12, [x12]
    3f54:      	ldr	w8, [x8, #0x4]
    3f58:      	cmp	x10, x8
    3f5c:      	b.hi	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    3f60:      	tbnz	w13, #0xa, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    3f64:      	cbnz	w12, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    3f68:      	cmp	x9, x10
    3f6c:      	b.hs	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    3f70:      	add	x8, x11, x9, lsl #3
    3f74:      	ldr	d0, [x8, #0x8]
    3f78:      	fmov	x8, d0
    3f7c:      	mov	x9, #0x10               ; =16
    3f80:      	movk	x9, #0x7ffc, lsl #48
    3f84:      	cmp	x8, x9
    3f88:      	ldr	d1, [sp, #0x8]
    3f8c:      	fcsel	d0, d1, d0, eq
    3f90:      	b	0x4278 <_perry_fn_access_worker_ts__run$generic+0x11dc>
    3f94:      	add	x8, x8, #0x10
    3f98:      	cmp	w11, #0x3
    3f9c:      	b.le	0x3fc0 <_perry_fn_access_worker_ts__run$generic+0xf24>
    3fa0:      	cmp	w11, #0x5
    3fa4:      	b.gt	0x4078 <_perry_fn_access_worker_ts__run$generic+0xfdc>
    3fa8:      	cmp	w11, #0x4
    3fac:      	b.eq	0x4110 <_perry_fn_access_worker_ts__run$generic+0x1074>
    3fb0:      	cmp	w11, #0x5
    3fb4:      	b.ne	0x4104 <_perry_fn_access_worker_ts__run$generic+0x1068>
    3fb8:      	ldr	s0, [x8, x9, lsl #2]
    3fbc:      	b	0x4108 <_perry_fn_access_worker_ts__run$generic+0x106c>
    3fc0:      	cbz	w11, 0x40fc <_perry_fn_access_worker_ts__run$generic+0x1060>
    3fc4:      	cmp	w11, #0x2
    3fc8:      	b.eq	0x4124 <_perry_fn_access_worker_ts__run$generic+0x1088>
    3fcc:      	cmp	w11, #0x3
    3fd0:      	b.ne	0x4104 <_perry_fn_access_worker_ts__run$generic+0x1068>
    3fd4:      	ldr	h0, [x8, x9, lsl #1]
    3fd8:      	b	0x4108 <_perry_fn_access_worker_ts__run$generic+0x106c>
    3fdc:      	ldr	x10, [x8, #0x8]
    3fe0:      	cbz	x10, 0x4090 <_perry_fn_access_worker_ts__run$generic+0xff4>
    3fe4:      	ldr	x13, [x10, #0x60]
    3fe8:      	cbz	x13, 0x4090 <_perry_fn_access_worker_ts__run$generic+0xff4>
    3fec:      	ldurb	w8, [x13, #-0x8]
    3ff0:      	cmp	w8, #0x1
    3ff4:      	b.ne	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    3ff8:      	ldursb	w8, [x13, #-0x7]
    3ffc:      	tbnz	w8, #0x1f, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    4000:      	ldr	w8, [x13]
    4004:      	cmp	x9, x8
    4008:      	b.hs	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    400c:      	add	x8, x13, x9, lsl #3
    4010:      	ldr	d0, [x8, #0x8]
    4014:      	fmov	x8, d0
    4018:      	mov	x9, #0x10               ; =16
    401c:      	movk	x9, #0x7ffc, lsl #48
    4020:      	cmp	x8, x9
    4024:      	b.eq	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    4028:      	b	0x4278 <_perry_fn_access_worker_ts__run$generic+0x11dc>
    402c:      	ldr	w12, [x8, #0x4]
    4030:      	ldr	x11, [x8, #0x20]
    4034:      	ldurh	w13, [x8, #-0x6]
    4038:      	tst	w13, #0xc00
    403c:      	mov	w13, #0x5841            ; =22593
    4040:      	movk	w13, #0x4c5a, lsl #16
    4044:      	ccmp	w12, w13, #0x0, eq
    4048:      	cset	w12, eq
    404c:      	cbz	x11, 0x40c4 <_perry_fn_access_worker_ts__run$generic+0x1028>
    4050:      	tbz	w12, #0x0, 0x40c4 <_perry_fn_access_worker_ts__run$generic+0x1028>
    4054:      	ldurb	w10, [x11, #-0x8]
    4058:      	cmp	w10, #0x1
    405c:      	b.ne	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    4060:      	ldursb	w10, [x11, #-0x7]
    4064:      	tbnz	w10, #0x1f, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    4068:      	ldr	w10, [x11]
    406c:      	str	w10, [x8]
    4070:      	mov	x8, x11
    4074:      	b	0x3f44 <_perry_fn_access_worker_ts__run$generic+0xea8>
    4078:      	cmp	w11, #0x6
    407c:      	b.eq	0x4118 <_perry_fn_access_worker_ts__run$generic+0x107c>
    4080:      	cmp	w11, #0x7
    4084:      	b.ne	0x4104 <_perry_fn_access_worker_ts__run$generic+0x1068>
    4088:      	ldr	d0, [x8, x9, lsl #3]
    408c:      	b	0x4278 <_perry_fn_access_worker_ts__run$generic+0x11dc>
    4090:      	ldr	x12, [x12]
    4094:      	cbz	x12, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    4098:      	tbnz	x12, #0x3f, 0x4130 <_perry_fn_access_worker_ts__run$generic+0x1094>
    409c:      	ldp	w14, w13, [x8]
    40a0:      	orr	x13, x13, x14, lsl #32
    40a4:      	cmp	x13, x12
    40a8:      	b.ne	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    40ac:      	ldp	x14, x12, [x11, #0x8]
    40b0:      	ldp	x13, x11, [x11, #0x18]
    40b4:      	cmp	x14, x11
    40b8:      	b.lo	0x4150 <_perry_fn_access_worker_ts__run$generic+0x10b4>
    40bc:      	cbz	x10, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    40c0:      	b	0x41a0 <_perry_fn_access_worker_ts__run$generic+0x1104>
    40c4:      	cmp	x11, #0x0
    40c8:      	ldr	w14, [x8]
    40cc:      	ldp	x11, x13, [x8, #0x28]
    40d0:      	ccmp	x9, x14, #0x2, eq
    40d4:      	ccmp	x11, #0x0, #0x4, lo
    40d8:      	ccmp	x13, #0x0, #0x4, ne
    40dc:      	csel	w12, wzr, w12, eq
    40e0:      	tbz	w12, #0x0, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    40e4:      	lsr	x12, x9, #6
    40e8:      	ldr	x12, [x13, x12, lsl #3]
    40ec:      	lsr	x12, x12, x9
    40f0:      	tbz	w12, #0x0, 0x415c <_perry_fn_access_worker_ts__run$generic+0x10c0>
    40f4:      	ldr	d0, [x11, x9, lsl #3]
    40f8:      	b	0x4278 <_perry_fn_access_worker_ts__run$generic+0x11dc>
    40fc:      	ldrsb	w8, [x8, x9]
    4100:      	b	0x4128 <_perry_fn_access_worker_ts__run$generic+0x108c>
    4104:      	ldr	b0, [x8, x9]
    4108:      	ucvtf	d0, d0
    410c:      	b	0x4278 <_perry_fn_access_worker_ts__run$generic+0x11dc>
    4110:      	ldr	w8, [x8, x9, lsl #2]
    4114:      	b	0x4128 <_perry_fn_access_worker_ts__run$generic+0x108c>
    4118:      	ldr	s0, [x8, x9, lsl #2]
    411c:      	fcvt	d0, s0
    4120:      	b	0x4278 <_perry_fn_access_worker_ts__run$generic+0x11dc>
    4124:      	ldrsh	w8, [x8, x9, lsl #1]
    4128:      	scvtf	d0, w8
    412c:      	b	0x4278 <_perry_fn_access_worker_ts__run$generic+0x11dc>
    4130:      	cbz	x10, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    4134:      	ldr	x13, [x10, #0x30]
    4138:      	cmp	x13, x12
    413c:      	b.ne	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    4140:      	ldp	x14, x12, [x11, #0x8]
    4144:      	ldp	x13, x11, [x11, #0x18]
    4148:      	cmp	x14, x11
    414c:      	b.hs	0x41a0 <_perry_fn_access_worker_ts__run$generic+0x1104>
    4150:      	add	x14, x8, x14, lsl #3
    4154:      	add	x14, x14, #0x10
    4158:      	b	0x41c4 <_perry_fn_access_worker_ts__run$generic+0x1128>
    415c:      	ldr	x8, [x8, #0x50]
    4160:      	mov	w12, #0x6903            ; =26883
    4164:      	movk	w12, #0x64, lsl #16
    4168:      	cmp	x8, x12
    416c:      	b.eq	0x4174 <_perry_fn_access_worker_ts__run$generic+0x10d8>
    4170:      	cbnz	x8, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    4174:      	mov	w12, #0x6903            ; =26883
    4178:      	movk	w12, #0x64, lsl #16
    417c:      	cmp	x8, x12
    4180:      	b.ne	0x422c <_perry_fn_access_worker_ts__run$generic+0x1190>
    4184:      	ldr	x8, [x11, x9, lsl #3]
    4188:      	cbz	x8, 0x422c <_perry_fn_access_worker_ts__run$generic+0x1190>
    418c:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    4190:      	cmp	x8, x9
    4194:      	csel	x8, xzr, x8, eq
    4198:      	fmov	d1, x8
    419c:      	b	0x4470 <_perry_fn_access_worker_ts__run$generic+0x13d4>
    41a0:      	ldr	x16, [x10, #0x20]
    41a4:      	cmp	x16, #0x0
    41a8:      	csel	x15, x16, x10, ne
    41ac:      	cbz	x16, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    41b0:      	ldr	w16, [x15]
    41b4:      	cmp	x14, x16
    41b8:      	b.hs	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    41bc:      	add	x14, x15, x14, lsl #3
    41c0:      	add	x14, x14, #0x8
    41c4:      	ldr	d0, [x14]
    41c8:      	fcmp	d9, d0
    41cc:      	ccmp	x13, x9, #0x0, mi
    41d0:      	cset	w13, hi
    41d4:      	add	x9, x12, x9
    41d8:      	cmp	x9, x11
    41dc:      	ccmp	w13, #0x0, #0x4, lo
    41e0:      	b.ne	0x4220 <_perry_fn_access_worker_ts__run$generic+0x1184>
    41e4:      	cbz	x10, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    41e8:      	cmp	x9, x11
    41ec:      	b.lo	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    41f0:      	eor	w8, w13, #0x1
    41f4:      	tbnz	w8, #0x0, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    41f8:      	ldr	x11, [x10, #0x20]
    41fc:      	cmp	x11, #0x0
    4200:      	csel	x8, x11, x10, ne
    4204:      	cbz	x11, 0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    4208:      	ldr	w10, [x8]
    420c:      	cmp	x9, x10
    4210:      	b.hs	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c0>
    4214:      	add	x8, x8, x9, lsl #3
    4218:      	ldr	d0, [x8, #0x8]
    421c:      	b	0x4278 <_perry_fn_access_worker_ts__run$generic+0x11dc>
    4220:      	add	x8, x8, x9, lsl #3
    4224:      	ldr	d0, [x8, #0x10]
    4228:      	b	0x4278 <_perry_fn_access_worker_ts__run$generic+0x11dc>
    422c:      	fmov	d0, x10
    4230:      	mov.16b	v1, v9
    4234:      	adrp	x0, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004234:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    4238:      	add	x0, x0, #0x0
		0000000000004238:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    423c:      	mov	w1, #0x2                ; =2
    4240:      	bl	0x4240 <_perry_fn_access_worker_ts__run$generic+0x11a4>
		0000000000004240:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    4244:      	mov.16b	v1, v0
    4248:      	fmov	x8, d1
    424c:      	mov	x9, #0x10               ; =16
    4250:      	movk	x9, #0x7ffc, lsl #48
    4254:      	cmp	x8, x9
    4258:      	b.ne	0x4470 <_perry_fn_access_worker_ts__run$generic+0x13d4>
    425c:      	fmov	d0, x26
    4260:      	str	x20, [sp, #0x28]
    4264:      	mov.16b	v1, v9
    4268:      	mov	x0, x19
    426c:      	bl	0x426c <_perry_fn_access_worker_ts__run$generic+0x11d0>
		000000000000426c:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    4270:      	ldp	x26, x20, [sp, #0x20]
    4274:      	ldr	x24, [sp, #0x18]
    4278:      	fmov	x8, d0
    427c:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    4280:      	and	x9, x8, x9
    4284:      	cmp	x9, x25
    4288:      	b.ne	0x42f4 <_perry_fn_access_worker_ts__run$generic+0x1258>
    428c:      	and	x0, x8, #0xffffffffffff
    4290:      	lsr	x8, x0, #20
    4294:      	cbz	x8, 0x4448 <_perry_fn_access_worker_ts__run$generic+0x13ac>
    4298:      	ldurb	w9, [x0, #-0x8]
    429c:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		000000000000429c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__23
    42a0:      	ldr	x8, [x8]
		00000000000042a0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__23
    42a4:      	cbz	x8, 0x4364 <_perry_fn_access_worker_ts__run$generic+0x12c8>
    42a8:      	ldurh	w10, [x0, #-0x6]
    42ac:      	and	w10, w10, #0x800
    42b0:      	cmp	w9, #0x2
    42b4:      	ccmp	w10, #0x0, #0x0, eq
    42b8:      	b.ne	0x4364 <_perry_fn_access_worker_ts__run$generic+0x12c8>
    42bc:      	ldr	w10, [x0, #0x4]
    42c0:      	orr	x9, x10, #0x4000000000000000
    42c4:      	ldr	x11, [x8]
    42c8:      	cmp	w10, #0x0
    42cc:      	ccmp	x9, x11, #0x0, ne
    42d0:      	b.eq	0x439c <_perry_fn_access_worker_ts__run$generic+0x1300>
    42d4:      	ldr	x11, [x8, #0x10]
    42d8:      	cbz	x11, 0x43c0 <_perry_fn_access_worker_ts__run$generic+0x1324>
    42dc:      	ldr	x12, [x0, #0x8]
    42e0:      	cbz	x12, 0x43c0 <_perry_fn_access_worker_ts__run$generic+0x1324>
    42e4:      	ldr	x12, [x12, #0x30]
    42e8:      	cmp	x12, x11
    42ec:      	b.eq	0x438c <_perry_fn_access_worker_ts__run$generic+0x12f0>
    42f0:      	b	0x43c0 <_perry_fn_access_worker_ts__run$generic+0x1324>
    42f4:      	lsr	x9, x8, #48
    42f8:      	mov	w10, #0x7ff9            ; =32761
    42fc:      	cmp	x9, x10
    4300:      	b.eq	0x4348 <_perry_fn_access_worker_ts__run$generic+0x12ac>
    4304:      	mov	w10, #0x7ffe            ; =32766
    4308:      	cmp	w9, w10
    430c:      	b.ne	0x4338 <_perry_fn_access_worker_ts__run$generic+0x129c>
    4310:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004310:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    4314:      	ldr	x9, [x9]
		0000000000004314:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4318:      	str	x20, [sp, #0x28]
    431c:      	and	x2, x9, #0xffffffffffff
    4320:      	mov	x0, #0x16               ; =22
    4324:      	movk	x0, #0xddae, lsl #32
    4328:      	movk	x0, #0x5556, lsl #48
    432c:      	mov	x1, x8
    4330:      	bl	0x4330 <_perry_fn_access_worker_ts__run$generic+0x1294>
		0000000000004330:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    4334:      	b	0x4464 <_perry_fn_access_worker_ts__run$generic+0x13c8>
    4338:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    433c:      	add	x9, x8, x9
    4340:      	cmp	x9, #0x2
    4344:      	b.lo	0x6384 <_perry_fn_access_worker_ts__run$generic+0x32e8>
    4348:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004348:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    434c:      	ldr	x9, [x9]
		000000000000434c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4350:      	str	x20, [sp, #0x28]
    4354:      	and	x1, x9, #0xffffffffffff
    4358:      	mov	x0, x8
    435c:      	bl	0x435c <_perry_fn_access_worker_ts__run$generic+0x12c0>
		000000000000435c:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    4360:      	b	0x4464 <_perry_fn_access_worker_ts__run$generic+0x13c8>
    4364:      	cmp	w9, #0x2
    4368:      	ccmp	x8, #0x0, #0x4, eq
    436c:      	b.eq	0x4448 <_perry_fn_access_worker_ts__run$generic+0x13ac>
    4370:      	ldr	x9, [x8, #0x10]
    4374:      	cbz	x9, 0x4448 <_perry_fn_access_worker_ts__run$generic+0x13ac>
    4378:      	ldr	x10, [x0, #0x8]
    437c:      	cbz	x10, 0x4448 <_perry_fn_access_worker_ts__run$generic+0x13ac>
    4380:      	ldr	x10, [x10, #0x30]
    4384:      	cmp	x10, x9
    4388:      	b.ne	0x4448 <_perry_fn_access_worker_ts__run$generic+0x13ac>
    438c:      	ldr	x8, [x8, #0x8]
    4390:      	add	x8, x0, x8, lsl #3
    4394:      	ldr	d1, [x8, #0x10]
    4398:      	b	0x4470 <_perry_fn_access_worker_ts__run$generic+0x13d4>
    439c:      	ldr	x2, [x8, #0x8]
    43a0:      	tbnz	w2, #0x1e, 0x44fc <_perry_fn_access_worker_ts__run$generic+0x1460>
    43a4:      	add	x11, x0, x2, lsl #3
    43a8:      	ldr	d1, [x11, #0x10]
    43ac:      	fmov	x11, d1
    43b0:      	mov	x12, #0x10              ; =16
    43b4:      	movk	x12, #0x7ffc, lsl #48
    43b8:      	cmp	x11, x12
    43bc:      	b.ne	0x4470 <_perry_fn_access_worker_ts__run$generic+0x13d4>
    43c0:      	ldr	x11, [x8, #0x18]
    43c4:      	cmp	x11, #0x0
    43c8:      	b.le	0x4448 <_perry_fn_access_worker_ts__run$generic+0x13ac>
    43cc:      	ldr	x11, [x8, #0x20]
    43d0:      	ldr	x12, [x8, #0x30]
    43d4:      	ldr	x13, [x8, #0x40]
    43d8:      	cmp	x13, x9
    43dc:      	ldr	x14, [x8, #0x50]
    43e0:      	ccmp	x14, x9, #0x4, ne
    43e4:      	ccmp	x12, x9, #0x4, ne
    43e8:      	ccmp	x11, x9, #0x4, ne
    43ec:      	cset	w15, eq
    43f0:      	cmp	w10, #0x0
    43f4:      	ccmp	w15, #0x0, #0x4, ne
    43f8:      	b.eq	0x4448 <_perry_fn_access_worker_ts__run$generic+0x13ac>
    43fc:      	ldr	x10, [x8, #0x48]
    4400:      	ldr	x15, [x8, #0x58]
    4404:      	cmp	x14, x9
    4408:      	csel	x14, x15, xzr, eq
    440c:      	cmp	x13, x9
    4410:      	csel	x10, x10, x14, eq
    4414:      	ldr	x13, [x8, #0x28]
    4418:      	ldr	x8, [x8, #0x38]
    441c:      	cmp	x12, x9
    4420:      	csel	x8, x8, x10, eq
    4424:      	cmp	x11, x9
    4428:      	csel	x8, x13, x8, eq
    442c:      	add	x8, x0, x8, lsl #3
    4430:      	ldr	d1, [x8, #0x10]
    4434:      	fmov	x8, d1
    4438:      	mov	x9, #0x10               ; =16
    443c:      	movk	x9, #0x7ffc, lsl #48
    4440:      	cmp	x8, x9
    4444:      	b.ne	0x4470 <_perry_fn_access_worker_ts__run$generic+0x13d4>
    4448:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004448:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    444c:      	ldr	x8, [x8]
		000000000000444c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4450:      	str	x20, [sp, #0x28]
    4454:      	and	x1, x8, #0xffffffffffff
    4458:      	adrp	x2, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004458:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__23
    445c:      	add	x2, x2, #0x0
		000000000000445c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__23
    4460:      	bl	0x4460 <_perry_fn_access_worker_ts__run$generic+0x13c4>
		0000000000004460:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    4464:      	mov.16b	v1, v0
    4468:      	ldp	x24, x26, [sp, #0x18]
    446c:      	ldr	x20, [sp, #0x28]
    4470:      	fmov	d0, x20
    4474:      	and	x9, x20, #0xffff000000000000
    4478:      	fmov	x8, d1
    447c:      	and	x10, x8, #0xffff000000000000
    4480:      	cmp	x8, x21
    4484:      	ccmp	x10, x23, #0x2, hs
    4488:      	cset	w8, hi
    448c:      	mov	x10, #0x1               ; =1
    4490:      	movk	x10, #0x7fff, lsl #48
    4494:      	cmp	x9, x10
    4498:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    449c:      	ccmp	x20, x9, #0x0, lo
    44a0:      	b.hi	0x44b0 <_perry_fn_access_worker_ts__run$generic+0x1414>
    44a4:      	tbz	w8, #0x0, 0x44b0 <_perry_fn_access_worker_ts__run$generic+0x1414>
    44a8:      	fadd	d0, d1, d0
    44ac:      	b	0x44b8 <_perry_fn_access_worker_ts__run$generic+0x141c>
    44b0:      	bl	0x44b0 <_perry_fn_access_worker_ts__run$generic+0x1414>
		00000000000044b0:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    44b4:      	ldp	x24, x26, [sp, #0x18]
    44b8:      	fmov	x20, d0
    44bc:      	mov	x0, x20
    44c0:      	ldr	w8, [x22]
    44c4:      	cbz	w8, 0x44cc <_perry_fn_access_worker_ts__run$generic+0x1430>
    44c8:      	bl	0x44c8 <_perry_fn_access_worker_ts__run$generic+0x142c>
		00000000000044c8:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    44cc:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		00000000000044cc:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    44d0:      	ldr	x8, [x8]
		00000000000044d0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    44d4:      	ldr	w8, [x8]
    44d8:      	cbz	w8, 0x44ec <_perry_fn_access_worker_ts__run$generic+0x1450>
    44dc:      	str	x20, [sp, #0x28]
    44e0:      	bl	0x44e0 <_perry_fn_access_worker_ts__run$generic+0x1444>
		00000000000044e0:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    44e4:      	ldp	x26, x20, [sp, #0x20]
    44e8:      	ldr	x24, [sp, #0x18]
    44ec:      	fadd	d8, d8, d11
    44f0:      	add	w28, w28, #0x1
    44f4:      	tbz	w27, #0x0, 0x3cdc <_perry_fn_access_worker_ts__run$generic+0xc40>
    44f8:      	b	0x3dd0 <_perry_fn_access_worker_ts__run$generic+0xd34>
    44fc:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		00000000000044fc:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    4500:      	ldr	x8, [x8]
		0000000000004500:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4504:      	str	x20, [sp, #0x28]
    4508:      	and	x1, x8, #0xffffffffffff
    450c:      	adrp	x3, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		000000000000450c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__23
    4510:      	add	x3, x3, #0x0
		0000000000004510:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__23
    4514:      	bl	0x4514 <_perry_fn_access_worker_ts__run$generic+0x1478>
		0000000000004514:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    4518:      	b	0x4464 <_perry_fn_access_worker_ts__run$generic+0x13c8>
    451c:      	str	w9, [sp, #0x14]
    4520:      	str	w9, [sp, #0x8]
    4524:      	mov	w28, #0x0               ; =0
    4528:      	mov	x20, #0x0               ; =0
    452c:      	mov	x22, #0x7ffd000000000000 ; =9222527611924643840
    4530:      	ldr	d10, [x21]
		0000000000004530:  ARM64_RELOC_PAGEOFF12	lCPI1_2
    4534:      	ldr	d11, [x11]
		0000000000004534:  ARM64_RELOC_PAGEOFF12	lCPI1_3
    4538:      	mov	x25, #-0x3000000000000  ; =-844424930131968
    453c:      	mov	x21, #0x7ff9000000000000 ; =9221401712017801216
    4540:      	mov	x19, #0x7fff000000000000 ; =9223090561878065152
    4544:      	mov	x23, #0x7ff8ffffffffffff ; =9221401712017801215
    4548:      	mov	x8, #0x41f0000000000000 ; =4751297606875873280
    454c:      	fmov	d12, x8
    4550:      	movi.2d	v13, #0000000000000000
    4554:      	fmov	d14, #1.00000000
    4558:      	ldr	w8, [sp, #0x14]
    455c:      	tbz	w8, #0x0, 0x4574 <_perry_fn_access_worker_ts__run$generic+0x14d8>
    4560:      	ldr	w8, [sp, #0x8]
    4564:      	cmp	w28, w8
    4568:      	b.ge	0x3270 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    456c:      	scvtf	d8, w28
    4570:      	b	0x4664 <_perry_fn_access_worker_ts__run$generic+0x15c8>
    4574:      	scvtf	d8, w28
    4578:      	mov	x8, x24
    457c:      	fmov	d1, x8
    4580:      	and	x9, x8, #0xffff000000000000
    4584:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    4588:      	cmp	x9, x10
    458c:      	b.eq	0x45c8 <_perry_fn_access_worker_ts__run$generic+0x152c>
    4590:      	cmp	x8, x21
    4594:      	b.lt	0x45c8 <_perry_fn_access_worker_ts__run$generic+0x152c>
    4598:      	mov	x10, #-0x7ffc000000000001 ; =-9222246136947933185
    459c:      	add	x10, x8, x10
    45a0:      	cmp	x10, #0x3
    45a4:      	b.ls	0x45c8 <_perry_fn_access_worker_ts__run$generic+0x152c>
    45a8:      	stp	x24, x20, [sp, #0x20]
    45ac:      	str	x26, [sp, #0x18]
    45b0:      	mov.16b	v0, v8
    45b4:      	bl	0x45b4 <_perry_fn_access_worker_ts__run$generic+0x1518>
		00000000000045b4:  ARM64_RELOC_BRANCH26	_js_rel_lt
    45b8:      	mov.16b	v9, v0
    45bc:      	ldp	x26, x24, [sp, #0x18]
    45c0:      	ldr	x20, [sp, #0x28]
    45c4:      	b	0x4628 <_perry_fn_access_worker_ts__run$generic+0x158c>
    45c8:      	mov	x12, #0x10              ; =16
    45cc:      	movk	x12, #0x7ffc, lsl #48
    45d0:      	sub	x10, x12, #0xc
    45d4:      	and	x11, x8, #0xfffffffffffffffe
    45d8:      	sub	x12, x12, #0xe
    45dc:      	scvtf	d0, w8
    45e0:      	mov	x13, #0x7ffe000000000000 ; =9222809086901354496
    45e4:      	cmp	x9, x13
    45e8:      	fcsel	d0, d0, d1, eq
    45ec:      	cmp	x11, x12
    45f0:      	fcsel	d0, d13, d0, eq
    45f4:      	cmp	x8, x10
    45f8:      	fcsel	d0, d14, d0, eq
    45fc:      	fmov	x8, d8
    4600:      	scvtf	d1, w8
    4604:      	mov	w9, #0x7ffe             ; =32766
    4608:      	cmp	x9, x8, lsr #48
    460c:      	fcsel	d1, d1, d8, eq
    4610:      	fcmp	d1, d0
    4614:      	mov	w8, #0x8                ; =8
    4618:      	csel	x8, x8, xzr, mi
    461c:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		000000000000461c:  ARM64_RELOC_PAGE21	lCPI1_1
    4620:      	add	x9, x9, #0x0
		0000000000004620:  ARM64_RELOC_PAGEOFF12	lCPI1_1
    4624:      	ldr	d9, [x9, x8]
    4628:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004628:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    462c:      	ldr	x8, [x8]
		000000000000462c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    4630:      	ldr	w8, [x8]
    4634:      	cbz	w8, 0x464c <_perry_fn_access_worker_ts__run$generic+0x15b0>
    4638:      	stp	x26, x24, [sp, #0x20]
    463c:      	str	x20, [sp, #0x18]
    4640:      	bl	0x4640 <_perry_fn_access_worker_ts__run$generic+0x15a4>
		0000000000004640:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    4644:      	ldp	x20, x26, [sp, #0x18]
    4648:      	ldr	x24, [sp, #0x28]
    464c:      	fmov	x8, d9
    4650:      	mov	x9, #0x10               ; =16
    4654:      	movk	x9, #0x7ffc, lsl #48
    4658:      	sub	x9, x9, #0xc
    465c:      	cmp	x8, x9
    4660:      	b.ne	0x3270 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    4664:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004664:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    4668:      	ldr	d1, [x8]
		0000000000004668:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    466c:      	stp	x24, x20, [sp, #0x20]
    4670:      	str	x26, [sp, #0x18]
    4674:      	mov.16b	v0, v8
    4678:      	bl	0x4678 <_perry_fn_access_worker_ts__run$generic+0x15dc>
		0000000000004678:  ARM64_RELOC_BRANCH26	_js_dynamic_mod
    467c:      	mov.16b	v8, v0
    4680:      	ldp	x26, x24, [sp, #0x18]
    4684:      	ldr	x20, [sp, #0x28]
    4688:      	mov	x0, x20
    468c:      	ldr	w8, [x27]
    4690:      	cbz	w8, 0x4698 <_perry_fn_access_worker_ts__run$generic+0x15fc>
    4694:      	bl	0x4694 <_perry_fn_access_worker_ts__run$generic+0x15f8>
		0000000000004694:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    4698:      	mov	x10, x26
    469c:      	and	x8, x10, #0xffffffffffff
    46a0:      	and	x13, x10, #0xffff000000000000
    46a4:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		00000000000046a4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    46a8:      	ldr	x9, [x9]
		00000000000046a8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    46ac:      	ldr	x9, [x9]
    46b0:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
    46b4:      	cmp	x13, x22
    46b8:      	ccmp	x9, #0x0, #0x0, eq
    46bc:      	mov	x9, #0x7ffffff00000     ; =140737487306752
    46c0:      	ccmp	x11, x9, #0x2, eq
    46c4:      	b.hs	0x4708 <_perry_fn_access_worker_ts__run$generic+0x166c>
    46c8:      	mov	x9, #0x41f0000000000000 ; =4751297606875873280
    46cc:      	fmov	d0, x9
    46d0:      	fcmp	d8, d0
    46d4:      	b.pl	0x4708 <_perry_fn_access_worker_ts__run$generic+0x166c>
    46d8:      	ldurb	w9, [x8, #-0x8]
    46dc:      	ldrb	w11, [x8, #0x8]
    46e0:      	fcmp	d8, #0.0
    46e4:      	ccmp	w9, #0xb, #0x0, ge
    46e8:      	ccmp	w11, #0x9, #0x2, eq
    46ec:      	b.hs	0x4708 <_perry_fn_access_worker_ts__run$generic+0x166c>
    46f0:      	fcvtzs	x9, d8
    46f4:      	scvtf	d0, x9
    46f8:      	ldr	w12, [x8]
    46fc:      	fcmp	d8, d0
    4700:      	ccmp	x9, x12, #0x2, eq
    4704:      	b.lo	0x47d0 <_perry_fn_access_worker_ts__run$generic+0x1734>
    4708:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004708:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__24
    470c:      	add	x9, x9, #0x0
		000000000000470c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__24
    4710:      	ldr	x11, [x9]
    4714:      	cmp	x11, #0x0
    4718:      	csel	x12, x9, x11, eq
    471c:      	cmp	x13, x22
    4720:      	b.ne	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4724:      	fcmp	d8, #0.0
    4728:      	b.lt	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    472c:      	fcmp	d8, d10
    4730:      	b.pl	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4734:      	mov	x9, #-0x20000000000     ; =-2199023255552
    4738:      	add	x9, x8, x9
    473c:      	lsr	x9, x9, #41
    4740:      	cmp	x9, #0x3f
    4744:      	b.hs	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4748:      	fcvtzs	x9, d8
    474c:      	scvtf	d0, x9
    4750:      	fcmp	d8, d0
    4754:      	b.ne	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4758:      	ldursb	w13, [x8, #-0x7]
    475c:      	tbnz	w13, #0x1f, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4760:      	ldurb	w13, [x8, #-0x8]
    4764:      	cmp	w13, #0x9
    4768:      	b.eq	0x4868 <_perry_fn_access_worker_ts__run$generic+0x17cc>
    476c:      	cmp	w13, #0x2
    4770:      	b.eq	0x4818 <_perry_fn_access_worker_ts__run$generic+0x177c>
    4774:      	cmp	w13, #0x1
    4778:      	b.ne	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    477c:      	ldr	w10, [x8]
    4780:      	mov	x11, x8
    4784:      	ldurh	w13, [x8, #-0x6]
    4788:      	adrp	x12, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004788:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    478c:      	ldr	x12, [x12]
		000000000000478c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    4790:      	ldrb	w12, [x12]
    4794:      	ldr	w8, [x8, #0x4]
    4798:      	cmp	x10, x8
    479c:      	b.hi	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    47a0:      	tbnz	w13, #0xa, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    47a4:      	cbnz	w12, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    47a8:      	cmp	x9, x10
    47ac:      	b.hs	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    47b0:      	add	x8, x11, x9, lsl #3
    47b4:      	ldr	d0, [x8, #0x8]
    47b8:      	fmov	x8, d0
    47bc:      	mov	x9, #0x10               ; =16
    47c0:      	movk	x9, #0x7ffc, lsl #48
    47c4:      	cmp	x8, x9
    47c8:      	fcsel	d0, d11, d0, eq
    47cc:      	b	0x4ab8 <_perry_fn_access_worker_ts__run$generic+0x1a1c>
    47d0:      	add	x8, x8, #0x10
    47d4:      	cmp	w11, #0x3
    47d8:      	b.le	0x47fc <_perry_fn_access_worker_ts__run$generic+0x1760>
    47dc:      	cmp	w11, #0x5
    47e0:      	b.gt	0x48b4 <_perry_fn_access_worker_ts__run$generic+0x1818>
    47e4:      	cmp	w11, #0x4
    47e8:      	b.eq	0x494c <_perry_fn_access_worker_ts__run$generic+0x18b0>
    47ec:      	cmp	w11, #0x5
    47f0:      	b.ne	0x4940 <_perry_fn_access_worker_ts__run$generic+0x18a4>
    47f4:      	ldr	s0, [x8, x9, lsl #2]
    47f8:      	b	0x4944 <_perry_fn_access_worker_ts__run$generic+0x18a8>
    47fc:      	cbz	w11, 0x4938 <_perry_fn_access_worker_ts__run$generic+0x189c>
    4800:      	cmp	w11, #0x2
    4804:      	b.eq	0x4960 <_perry_fn_access_worker_ts__run$generic+0x18c4>
    4808:      	cmp	w11, #0x3
    480c:      	b.ne	0x4940 <_perry_fn_access_worker_ts__run$generic+0x18a4>
    4810:      	ldr	h0, [x8, x9, lsl #1]
    4814:      	b	0x4944 <_perry_fn_access_worker_ts__run$generic+0x18a8>
    4818:      	ldr	x10, [x8, #0x8]
    481c:      	cbz	x10, 0x48cc <_perry_fn_access_worker_ts__run$generic+0x1830>
    4820:      	ldr	x13, [x10, #0x60]
    4824:      	cbz	x13, 0x48cc <_perry_fn_access_worker_ts__run$generic+0x1830>
    4828:      	ldurb	w8, [x13, #-0x8]
    482c:      	cmp	w8, #0x1
    4830:      	b.ne	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4834:      	ldursb	w8, [x13, #-0x7]
    4838:      	tbnz	w8, #0x1f, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    483c:      	ldr	w8, [x13]
    4840:      	cmp	x9, x8
    4844:      	b.hs	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4848:      	add	x8, x13, x9, lsl #3
    484c:      	ldr	d0, [x8, #0x8]
    4850:      	fmov	x8, d0
    4854:      	mov	x9, #0x10               ; =16
    4858:      	movk	x9, #0x7ffc, lsl #48
    485c:      	cmp	x8, x9
    4860:      	b.eq	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4864:      	b	0x4ab8 <_perry_fn_access_worker_ts__run$generic+0x1a1c>
    4868:      	ldr	w12, [x8, #0x4]
    486c:      	ldr	x11, [x8, #0x20]
    4870:      	ldurh	w13, [x8, #-0x6]
    4874:      	tst	w13, #0xc00
    4878:      	mov	w13, #0x5841            ; =22593
    487c:      	movk	w13, #0x4c5a, lsl #16
    4880:      	ccmp	w12, w13, #0x0, eq
    4884:      	cset	w12, eq
    4888:      	cbz	x11, 0x4900 <_perry_fn_access_worker_ts__run$generic+0x1864>
    488c:      	tbz	w12, #0x0, 0x4900 <_perry_fn_access_worker_ts__run$generic+0x1864>
    4890:      	ldurb	w10, [x11, #-0x8]
    4894:      	cmp	w10, #0x1
    4898:      	b.ne	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    489c:      	ldursb	w10, [x11, #-0x7]
    48a0:      	tbnz	w10, #0x1f, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    48a4:      	ldr	w10, [x11]
    48a8:      	str	w10, [x8]
    48ac:      	mov	x8, x11
    48b0:      	b	0x4784 <_perry_fn_access_worker_ts__run$generic+0x16e8>
    48b4:      	cmp	w11, #0x6
    48b8:      	b.eq	0x4954 <_perry_fn_access_worker_ts__run$generic+0x18b8>
    48bc:      	cmp	w11, #0x7
    48c0:      	b.ne	0x4940 <_perry_fn_access_worker_ts__run$generic+0x18a4>
    48c4:      	ldr	d0, [x8, x9, lsl #3]
    48c8:      	b	0x4ab8 <_perry_fn_access_worker_ts__run$generic+0x1a1c>
    48cc:      	ldr	x12, [x12]
    48d0:      	cbz	x12, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    48d4:      	tbnz	x12, #0x3f, 0x496c <_perry_fn_access_worker_ts__run$generic+0x18d0>
    48d8:      	ldp	w14, w13, [x8]
    48dc:      	orr	x13, x13, x14, lsl #32
    48e0:      	cmp	x13, x12
    48e4:      	b.ne	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    48e8:      	ldp	x14, x12, [x11, #0x8]
    48ec:      	ldp	x13, x11, [x11, #0x18]
    48f0:      	cmp	x14, x11
    48f4:      	b.lo	0x498c <_perry_fn_access_worker_ts__run$generic+0x18f0>
    48f8:      	cbz	x10, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    48fc:      	b	0x49dc <_perry_fn_access_worker_ts__run$generic+0x1940>
    4900:      	cmp	x11, #0x0
    4904:      	ldr	w14, [x8]
    4908:      	ldp	x11, x13, [x8, #0x28]
    490c:      	ccmp	x9, x14, #0x2, eq
    4910:      	ccmp	x11, #0x0, #0x4, lo
    4914:      	ccmp	x13, #0x0, #0x4, ne
    4918:      	csel	w12, wzr, w12, eq
    491c:      	tbz	w12, #0x0, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4920:      	lsr	x12, x9, #6
    4924:      	ldr	x12, [x13, x12, lsl #3]
    4928:      	lsr	x12, x12, x9
    492c:      	tbz	w12, #0x0, 0x4998 <_perry_fn_access_worker_ts__run$generic+0x18fc>
    4930:      	ldr	d0, [x11, x9, lsl #3]
    4934:      	b	0x4ab8 <_perry_fn_access_worker_ts__run$generic+0x1a1c>
    4938:      	ldrsb	w8, [x8, x9]
    493c:      	b	0x4964 <_perry_fn_access_worker_ts__run$generic+0x18c8>
    4940:      	ldr	b0, [x8, x9]
    4944:      	ucvtf	d0, d0
    4948:      	b	0x4ab8 <_perry_fn_access_worker_ts__run$generic+0x1a1c>
    494c:      	ldr	w8, [x8, x9, lsl #2]
    4950:      	b	0x4964 <_perry_fn_access_worker_ts__run$generic+0x18c8>
    4954:      	ldr	s0, [x8, x9, lsl #2]
    4958:      	fcvt	d0, s0
    495c:      	b	0x4ab8 <_perry_fn_access_worker_ts__run$generic+0x1a1c>
    4960:      	ldrsh	w8, [x8, x9, lsl #1]
    4964:      	scvtf	d0, w8
    4968:      	b	0x4ab8 <_perry_fn_access_worker_ts__run$generic+0x1a1c>
    496c:      	cbz	x10, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4970:      	ldr	x13, [x10, #0x30]
    4974:      	cmp	x13, x12
    4978:      	b.ne	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    497c:      	ldp	x14, x12, [x11, #0x8]
    4980:      	ldp	x13, x11, [x11, #0x18]
    4984:      	cmp	x14, x11
    4988:      	b.hs	0x49dc <_perry_fn_access_worker_ts__run$generic+0x1940>
    498c:      	add	x14, x8, x14, lsl #3
    4990:      	add	x14, x14, #0x10
    4994:      	b	0x4a00 <_perry_fn_access_worker_ts__run$generic+0x1964>
    4998:      	ldr	x8, [x8, #0x50]
    499c:      	mov	w12, #0x6903            ; =26883
    49a0:      	movk	w12, #0x64, lsl #16
    49a4:      	cmp	x8, x12
    49a8:      	b.eq	0x49b0 <_perry_fn_access_worker_ts__run$generic+0x1914>
    49ac:      	cbnz	x8, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    49b0:      	mov	w12, #0x6903            ; =26883
    49b4:      	movk	w12, #0x64, lsl #16
    49b8:      	cmp	x8, x12
    49bc:      	b.ne	0x4a68 <_perry_fn_access_worker_ts__run$generic+0x19cc>
    49c0:      	ldr	x8, [x11, x9, lsl #3]
    49c4:      	cbz	x8, 0x4a68 <_perry_fn_access_worker_ts__run$generic+0x19cc>
    49c8:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    49cc:      	cmp	x8, x9
    49d0:      	csel	x8, xzr, x8, eq
    49d4:      	fmov	d1, x8
    49d8:      	b	0x4cac <_perry_fn_access_worker_ts__run$generic+0x1c10>
    49dc:      	ldr	x16, [x10, #0x20]
    49e0:      	cmp	x16, #0x0
    49e4:      	csel	x15, x16, x10, ne
    49e8:      	cbz	x16, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    49ec:      	ldr	w16, [x15]
    49f0:      	cmp	x14, x16
    49f4:      	b.hs	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    49f8:      	add	x14, x15, x14, lsl #3
    49fc:      	add	x14, x14, #0x8
    4a00:      	ldr	d0, [x14]
    4a04:      	fcmp	d8, d0
    4a08:      	ccmp	x13, x9, #0x0, mi
    4a0c:      	cset	w13, hi
    4a10:      	add	x9, x12, x9
    4a14:      	cmp	x9, x11
    4a18:      	ccmp	w13, #0x0, #0x4, lo
    4a1c:      	b.ne	0x4a5c <_perry_fn_access_worker_ts__run$generic+0x19c0>
    4a20:      	cbz	x10, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4a24:      	cmp	x9, x11
    4a28:      	b.lo	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4a2c:      	eor	w8, w13, #0x1
    4a30:      	tbnz	w8, #0x0, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4a34:      	ldr	x11, [x10, #0x20]
    4a38:      	cmp	x11, #0x0
    4a3c:      	csel	x8, x11, x10, ne
    4a40:      	cbz	x11, 0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4a44:      	ldr	w10, [x8]
    4a48:      	cmp	x9, x10
    4a4c:      	b.hs	0x4a98 <_perry_fn_access_worker_ts__run$generic+0x19fc>
    4a50:      	add	x8, x8, x9, lsl #3
    4a54:      	ldr	d0, [x8, #0x8]
    4a58:      	b	0x4ab8 <_perry_fn_access_worker_ts__run$generic+0x1a1c>
    4a5c:      	add	x8, x8, x9, lsl #3
    4a60:      	ldr	d0, [x8, #0x10]
    4a64:      	b	0x4ab8 <_perry_fn_access_worker_ts__run$generic+0x1a1c>
    4a68:      	fmov	d0, x10
    4a6c:      	mov.16b	v1, v8
    4a70:      	adrp	x0, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004a70:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    4a74:      	add	x0, x0, #0x0
		0000000000004a74:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    4a78:      	mov	w1, #0x2                ; =2
    4a7c:      	bl	0x4a7c <_perry_fn_access_worker_ts__run$generic+0x19e0>
		0000000000004a7c:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    4a80:      	mov.16b	v1, v0
    4a84:      	fmov	x8, d1
    4a88:      	mov	x9, #0x10               ; =16
    4a8c:      	movk	x9, #0x7ffc, lsl #48
    4a90:      	cmp	x8, x9
    4a94:      	b.ne	0x4cac <_perry_fn_access_worker_ts__run$generic+0x1c10>
    4a98:      	fmov	d0, x26
    4a9c:      	str	x20, [sp, #0x28]
    4aa0:      	mov.16b	v1, v8
    4aa4:      	adrp	x0, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004aa4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__24
    4aa8:      	add	x0, x0, #0x0
		0000000000004aa8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__24
    4aac:      	bl	0x4aac <_perry_fn_access_worker_ts__run$generic+0x1a10>
		0000000000004aac:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    4ab0:      	ldp	x26, x24, [sp, #0x18]
    4ab4:      	ldr	x20, [sp, #0x28]
    4ab8:      	fmov	x8, d0
    4abc:      	and	x9, x8, x25
    4ac0:      	cmp	x9, x22
    4ac4:      	b.ne	0x4b30 <_perry_fn_access_worker_ts__run$generic+0x1a94>
    4ac8:      	and	x0, x8, #0xffffffffffff
    4acc:      	lsr	x8, x0, #20
    4ad0:      	cbz	x8, 0x4c84 <_perry_fn_access_worker_ts__run$generic+0x1be8>
    4ad4:      	ldurb	w9, [x0, #-0x8]
    4ad8:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004ad8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__26
    4adc:      	ldr	x8, [x8]
		0000000000004adc:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__26
    4ae0:      	cbz	x8, 0x4ba0 <_perry_fn_access_worker_ts__run$generic+0x1b04>
    4ae4:      	ldurh	w10, [x0, #-0x6]
    4ae8:      	and	w10, w10, #0x800
    4aec:      	cmp	w9, #0x2
    4af0:      	ccmp	w10, #0x0, #0x0, eq
    4af4:      	b.ne	0x4ba0 <_perry_fn_access_worker_ts__run$generic+0x1b04>
    4af8:      	ldr	w10, [x0, #0x4]
    4afc:      	orr	x9, x10, #0x4000000000000000
    4b00:      	ldr	x11, [x8]
    4b04:      	cmp	w10, #0x0
    4b08:      	ccmp	x9, x11, #0x0, ne
    4b0c:      	b.eq	0x4bd8 <_perry_fn_access_worker_ts__run$generic+0x1b3c>
    4b10:      	ldr	x11, [x8, #0x10]
    4b14:      	cbz	x11, 0x4bfc <_perry_fn_access_worker_ts__run$generic+0x1b60>
    4b18:      	ldr	x12, [x0, #0x8]
    4b1c:      	cbz	x12, 0x4bfc <_perry_fn_access_worker_ts__run$generic+0x1b60>
    4b20:      	ldr	x12, [x12, #0x30]
    4b24:      	cmp	x12, x11
    4b28:      	b.eq	0x4bc8 <_perry_fn_access_worker_ts__run$generic+0x1b2c>
    4b2c:      	b	0x4bfc <_perry_fn_access_worker_ts__run$generic+0x1b60>
    4b30:      	lsr	x9, x8, #48
    4b34:      	mov	w10, #0x7ff9            ; =32761
    4b38:      	cmp	x9, x10
    4b3c:      	b.eq	0x4b84 <_perry_fn_access_worker_ts__run$generic+0x1ae8>
    4b40:      	mov	w10, #0x7ffe            ; =32766
    4b44:      	cmp	w9, w10
    4b48:      	b.ne	0x4b74 <_perry_fn_access_worker_ts__run$generic+0x1ad8>
    4b4c:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004b4c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    4b50:      	ldr	x9, [x9]
		0000000000004b50:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4b54:      	str	x20, [sp, #0x28]
    4b58:      	and	x2, x9, #0xffffffffffff
    4b5c:      	mov	x0, #0x19               ; =25
    4b60:      	movk	x0, #0xddae, lsl #32
    4b64:      	movk	x0, #0x5556, lsl #48
    4b68:      	mov	x1, x8
    4b6c:      	bl	0x4b6c <_perry_fn_access_worker_ts__run$generic+0x1ad0>
		0000000000004b6c:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    4b70:      	b	0x4ca0 <_perry_fn_access_worker_ts__run$generic+0x1c04>
    4b74:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    4b78:      	add	x9, x8, x9
    4b7c:      	cmp	x9, #0x2
    4b80:      	b.lo	0x6384 <_perry_fn_access_worker_ts__run$generic+0x32e8>
    4b84:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004b84:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    4b88:      	ldr	x9, [x9]
		0000000000004b88:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4b8c:      	str	x20, [sp, #0x28]
    4b90:      	and	x1, x9, #0xffffffffffff
    4b94:      	mov	x0, x8
    4b98:      	bl	0x4b98 <_perry_fn_access_worker_ts__run$generic+0x1afc>
		0000000000004b98:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    4b9c:      	b	0x4ca0 <_perry_fn_access_worker_ts__run$generic+0x1c04>
    4ba0:      	cmp	w9, #0x2
    4ba4:      	ccmp	x8, #0x0, #0x4, eq
    4ba8:      	b.eq	0x4c84 <_perry_fn_access_worker_ts__run$generic+0x1be8>
    4bac:      	ldr	x9, [x8, #0x10]
    4bb0:      	cbz	x9, 0x4c84 <_perry_fn_access_worker_ts__run$generic+0x1be8>
    4bb4:      	ldr	x10, [x0, #0x8]
    4bb8:      	cbz	x10, 0x4c84 <_perry_fn_access_worker_ts__run$generic+0x1be8>
    4bbc:      	ldr	x10, [x10, #0x30]
    4bc0:      	cmp	x10, x9
    4bc4:      	b.ne	0x4c84 <_perry_fn_access_worker_ts__run$generic+0x1be8>
    4bc8:      	ldr	x8, [x8, #0x8]
    4bcc:      	add	x8, x0, x8, lsl #3
    4bd0:      	ldr	d1, [x8, #0x10]
    4bd4:      	b	0x4cac <_perry_fn_access_worker_ts__run$generic+0x1c10>
    4bd8:      	ldr	x2, [x8, #0x8]
    4bdc:      	tbnz	w2, #0x1e, 0x4f80 <_perry_fn_access_worker_ts__run$generic+0x1ee4>
    4be0:      	add	x11, x0, x2, lsl #3
    4be4:      	ldr	d1, [x11, #0x10]
    4be8:      	fmov	x11, d1
    4bec:      	mov	x12, #0x10              ; =16
    4bf0:      	movk	x12, #0x7ffc, lsl #48
    4bf4:      	cmp	x11, x12
    4bf8:      	b.ne	0x4cac <_perry_fn_access_worker_ts__run$generic+0x1c10>
    4bfc:      	ldr	x11, [x8, #0x18]
    4c00:      	cmp	x11, #0x0
    4c04:      	b.le	0x4c84 <_perry_fn_access_worker_ts__run$generic+0x1be8>
    4c08:      	ldr	x11, [x8, #0x20]
    4c0c:      	ldr	x12, [x8, #0x30]
    4c10:      	ldr	x13, [x8, #0x40]
    4c14:      	cmp	x13, x9
    4c18:      	ldr	x14, [x8, #0x50]
    4c1c:      	ccmp	x14, x9, #0x4, ne
    4c20:      	ccmp	x12, x9, #0x4, ne
    4c24:      	ccmp	x11, x9, #0x4, ne
    4c28:      	cset	w15, eq
    4c2c:      	cmp	w10, #0x0
    4c30:      	ccmp	w15, #0x0, #0x4, ne
    4c34:      	b.eq	0x4c84 <_perry_fn_access_worker_ts__run$generic+0x1be8>
    4c38:      	ldr	x10, [x8, #0x48]
    4c3c:      	ldr	x15, [x8, #0x58]
    4c40:      	cmp	x14, x9
    4c44:      	csel	x14, x15, xzr, eq
    4c48:      	cmp	x13, x9
    4c4c:      	csel	x10, x10, x14, eq
    4c50:      	ldr	x13, [x8, #0x28]
    4c54:      	ldr	x8, [x8, #0x38]
    4c58:      	cmp	x12, x9
    4c5c:      	csel	x8, x8, x10, eq
    4c60:      	cmp	x11, x9
    4c64:      	csel	x8, x13, x8, eq
    4c68:      	add	x8, x0, x8, lsl #3
    4c6c:      	ldr	d1, [x8, #0x10]
    4c70:      	fmov	x8, d1
    4c74:      	mov	x9, #0x10               ; =16
    4c78:      	movk	x9, #0x7ffc, lsl #48
    4c7c:      	cmp	x8, x9
    4c80:      	b.ne	0x4cac <_perry_fn_access_worker_ts__run$generic+0x1c10>
    4c84:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004c84:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    4c88:      	ldr	x8, [x8]
		0000000000004c88:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4c8c:      	str	x20, [sp, #0x28]
    4c90:      	and	x1, x8, #0xffffffffffff
    4c94:      	adrp	x2, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004c94:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__26
    4c98:      	add	x2, x2, #0x0
		0000000000004c98:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__26
    4c9c:      	bl	0x4c9c <_perry_fn_access_worker_ts__run$generic+0x1c00>
		0000000000004c9c:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    4ca0:      	mov.16b	v1, v0
    4ca4:      	ldp	x26, x24, [sp, #0x18]
    4ca8:      	ldr	x20, [sp, #0x28]
    4cac:      	fmov	d0, x20
    4cb0:      	and	x9, x20, #0xffff000000000000
    4cb4:      	fmov	x8, d1
    4cb8:      	and	x10, x8, #0xffff000000000000
    4cbc:      	cmp	x8, x21
    4cc0:      	ccmp	x10, x19, #0x2, hs
    4cc4:      	cset	w8, hi
    4cc8:      	mov	x10, #0x1               ; =1
    4ccc:      	movk	x10, #0x7fff, lsl #48
    4cd0:      	cmp	x9, x10
    4cd4:      	ccmp	x20, x23, #0x0, lo
    4cd8:      	b.hi	0x4ce8 <_perry_fn_access_worker_ts__run$generic+0x1c4c>
    4cdc:      	tbz	w8, #0x0, 0x4ce8 <_perry_fn_access_worker_ts__run$generic+0x1c4c>
    4ce0:      	fadd	d0, d1, d0
    4ce4:      	b	0x4cf0 <_perry_fn_access_worker_ts__run$generic+0x1c54>
    4ce8:      	bl	0x4ce8 <_perry_fn_access_worker_ts__run$generic+0x1c4c>
		0000000000004ce8:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    4cec:      	ldp	x26, x24, [sp, #0x18]
    4cf0:      	fmov	x20, d0
    4cf4:      	mov	x0, x20
    4cf8:      	ldr	w8, [x27]
    4cfc:      	cbz	w8, 0x4d04 <_perry_fn_access_worker_ts__run$generic+0x1c68>
    4d00:      	bl	0x4d00 <_perry_fn_access_worker_ts__run$generic+0x1c64>
		0000000000004d00:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    4d04:      	mov	x0, x20
    4d08:      	ldr	w8, [x27]
    4d0c:      	cbz	w8, 0x4d14 <_perry_fn_access_worker_ts__run$generic+0x1c78>
    4d10:      	bl	0x4d10 <_perry_fn_access_worker_ts__run$generic+0x1c74>
		0000000000004d10:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    4d14:      	mov	x10, x26
    4d18:      	and	x8, x10, #0xffffffffffff
    4d1c:      	and	x13, x10, #0xffff000000000000
    4d20:      	cmp	x13, x22
    4d24:      	b.ne	0x4d88 <_perry_fn_access_worker_ts__run$generic+0x1cec>
    4d28:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004d28:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    4d2c:      	ldr	x9, [x9]
		0000000000004d2c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    4d30:      	ldr	x9, [x9]
    4d34:      	cbnz	x9, 0x4d88 <_perry_fn_access_worker_ts__run$generic+0x1cec>
    4d38:      	sub	x9, x8, #0x100, lsl #12 ; =0x100000
    4d3c:      	mov	x11, #0x7ffffff00000    ; =140737487306752
    4d40:      	cmp	x9, x11
    4d44:      	b.hs	0x4d88 <_perry_fn_access_worker_ts__run$generic+0x1cec>
    4d48:      	fcmp	d8, d12
    4d4c:      	b.pl	0x4d88 <_perry_fn_access_worker_ts__run$generic+0x1cec>
    4d50:      	fcmp	d8, #0.0
    4d54:      	b.lt	0x4d88 <_perry_fn_access_worker_ts__run$generic+0x1cec>
    4d58:      	ldurb	w9, [x8, #-0x8]
    4d5c:      	cmp	w9, #0xb
    4d60:      	b.ne	0x4d88 <_perry_fn_access_worker_ts__run$generic+0x1cec>
    4d64:      	ldrb	w11, [x8, #0x8]
    4d68:      	cmp	w11, #0x9
    4d6c:      	b.hs	0x4d88 <_perry_fn_access_worker_ts__run$generic+0x1cec>
    4d70:      	fcvtzs	x9, d8
    4d74:      	scvtf	d0, x9
    4d78:      	ldr	w12, [x8]
    4d7c:      	fcmp	d8, d0
    4d80:      	ccmp	x9, x12, #0x2, eq
    4d84:      	b.lo	0x4e50 <_perry_fn_access_worker_ts__run$generic+0x1db4>
    4d88:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004d88:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__27
    4d8c:      	add	x9, x9, #0x0
		0000000000004d8c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__27
    4d90:      	ldr	x11, [x9]
    4d94:      	cmp	x11, #0x0
    4d98:      	csel	x12, x9, x11, eq
    4d9c:      	cmp	x13, x22
    4da0:      	b.ne	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4da4:      	fcmp	d8, #0.0
    4da8:      	b.lt	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4dac:      	fcmp	d8, d10
    4db0:      	b.pl	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4db4:      	mov	x9, #-0x20000000000     ; =-2199023255552
    4db8:      	add	x9, x8, x9
    4dbc:      	lsr	x9, x9, #41
    4dc0:      	cmp	x9, #0x3f
    4dc4:      	b.hs	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4dc8:      	fcvtzs	x9, d8
    4dcc:      	scvtf	d0, x9
    4dd0:      	fcmp	d8, d0
    4dd4:      	b.ne	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4dd8:      	ldursb	w13, [x8, #-0x7]
    4ddc:      	tbnz	w13, #0x1f, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4de0:      	ldurb	w13, [x8, #-0x8]
    4de4:      	cmp	w13, #0x9
    4de8:      	b.eq	0x4ee8 <_perry_fn_access_worker_ts__run$generic+0x1e4c>
    4dec:      	cmp	w13, #0x2
    4df0:      	b.eq	0x4e98 <_perry_fn_access_worker_ts__run$generic+0x1dfc>
    4df4:      	cmp	w13, #0x1
    4df8:      	b.ne	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4dfc:      	ldr	w10, [x8]
    4e00:      	mov	x11, x8
    4e04:      	ldurh	w13, [x8, #-0x6]
    4e08:      	adrp	x12, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004e08:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    4e0c:      	ldr	x12, [x12]
		0000000000004e0c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    4e10:      	ldrb	w12, [x12]
    4e14:      	ldr	w8, [x8, #0x4]
    4e18:      	cmp	x10, x8
    4e1c:      	b.hi	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4e20:      	tbnz	w13, #0xa, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4e24:      	cbnz	w12, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4e28:      	cmp	x9, x10
    4e2c:      	b.hs	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4e30:      	add	x8, x11, x9, lsl #3
    4e34:      	ldr	d0, [x8, #0x8]
    4e38:      	fmov	x8, d0
    4e3c:      	mov	x9, #0x10               ; =16
    4e40:      	movk	x9, #0x7ffc, lsl #48
    4e44:      	cmp	x8, x9
    4e48:      	fcsel	d0, d11, d0, eq
    4e4c:      	b	0x5150 <_perry_fn_access_worker_ts__run$generic+0x20b4>
    4e50:      	add	x8, x8, #0x10
    4e54:      	cmp	w11, #0x3
    4e58:      	b.le	0x4e7c <_perry_fn_access_worker_ts__run$generic+0x1de0>
    4e5c:      	cmp	w11, #0x5
    4e60:      	b.gt	0x4f34 <_perry_fn_access_worker_ts__run$generic+0x1e98>
    4e64:      	cmp	w11, #0x4
    4e68:      	b.eq	0x4fec <_perry_fn_access_worker_ts__run$generic+0x1f50>
    4e6c:      	cmp	w11, #0x5
    4e70:      	b.ne	0x4fe0 <_perry_fn_access_worker_ts__run$generic+0x1f44>
    4e74:      	ldr	s0, [x8, x9, lsl #2]
    4e78:      	b	0x4fe4 <_perry_fn_access_worker_ts__run$generic+0x1f48>
    4e7c:      	cbz	w11, 0x4fd8 <_perry_fn_access_worker_ts__run$generic+0x1f3c>
    4e80:      	cmp	w11, #0x2
    4e84:      	b.eq	0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
    4e88:      	cmp	w11, #0x3
    4e8c:      	b.ne	0x4fe0 <_perry_fn_access_worker_ts__run$generic+0x1f44>
    4e90:      	ldr	h0, [x8, x9, lsl #1]
    4e94:      	b	0x4fe4 <_perry_fn_access_worker_ts__run$generic+0x1f48>
    4e98:      	ldr	x10, [x8, #0x8]
    4e9c:      	cbz	x10, 0x4f4c <_perry_fn_access_worker_ts__run$generic+0x1eb0>
    4ea0:      	ldr	x13, [x10, #0x60]
    4ea4:      	cbz	x13, 0x4f4c <_perry_fn_access_worker_ts__run$generic+0x1eb0>
    4ea8:      	ldurb	w8, [x13, #-0x8]
    4eac:      	cmp	w8, #0x1
    4eb0:      	b.ne	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4eb4:      	ldursb	w8, [x13, #-0x7]
    4eb8:      	tbnz	w8, #0x1f, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4ebc:      	ldr	w8, [x13]
    4ec0:      	cmp	x9, x8
    4ec4:      	b.hs	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4ec8:      	add	x8, x13, x9, lsl #3
    4ecc:      	ldr	d0, [x8, #0x8]
    4ed0:      	fmov	x8, d0
    4ed4:      	mov	x9, #0x10               ; =16
    4ed8:      	movk	x9, #0x7ffc, lsl #48
    4edc:      	cmp	x8, x9
    4ee0:      	b.eq	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4ee4:      	b	0x5150 <_perry_fn_access_worker_ts__run$generic+0x20b4>
    4ee8:      	ldr	w12, [x8, #0x4]
    4eec:      	ldr	x11, [x8, #0x20]
    4ef0:      	ldurh	w13, [x8, #-0x6]
    4ef4:      	tst	w13, #0xc00
    4ef8:      	mov	w13, #0x5841            ; =22593
    4efc:      	movk	w13, #0x4c5a, lsl #16
    4f00:      	ccmp	w12, w13, #0x0, eq
    4f04:      	cset	w12, eq
    4f08:      	cbz	x11, 0x4fa0 <_perry_fn_access_worker_ts__run$generic+0x1f04>
    4f0c:      	tbz	w12, #0x0, 0x4fa0 <_perry_fn_access_worker_ts__run$generic+0x1f04>
    4f10:      	ldurb	w10, [x11, #-0x8]
    4f14:      	cmp	w10, #0x1
    4f18:      	b.ne	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4f1c:      	ldursb	w10, [x11, #-0x7]
    4f20:      	tbnz	w10, #0x1f, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4f24:      	ldr	w10, [x11]
    4f28:      	str	w10, [x8]
    4f2c:      	mov	x8, x11
    4f30:      	b	0x4e04 <_perry_fn_access_worker_ts__run$generic+0x1d68>
    4f34:      	cmp	w11, #0x6
    4f38:      	b.eq	0x4ff4 <_perry_fn_access_worker_ts__run$generic+0x1f58>
    4f3c:      	cmp	w11, #0x7
    4f40:      	b.ne	0x4fe0 <_perry_fn_access_worker_ts__run$generic+0x1f44>
    4f44:      	ldr	d0, [x8, x9, lsl #3]
    4f48:      	b	0x5150 <_perry_fn_access_worker_ts__run$generic+0x20b4>
    4f4c:      	ldr	x12, [x12]
    4f50:      	cbz	x12, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4f54:      	tbnz	x12, #0x3f, 0x500c <_perry_fn_access_worker_ts__run$generic+0x1f70>
    4f58:      	ldp	w14, w13, [x8]
    4f5c:      	orr	x13, x13, x14, lsl #32
    4f60:      	cmp	x13, x12
    4f64:      	b.ne	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4f68:      	ldp	x14, x12, [x11, #0x8]
    4f6c:      	ldp	x13, x11, [x11, #0x18]
    4f70:      	cmp	x14, x11
    4f74:      	b.lo	0x502c <_perry_fn_access_worker_ts__run$generic+0x1f90>
    4f78:      	cbz	x10, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4f7c:      	b	0x5078 <_perry_fn_access_worker_ts__run$generic+0x1fdc>
    4f80:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004f80:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    4f84:      	ldr	x8, [x8]
		0000000000004f84:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4f88:      	str	x20, [sp, #0x28]
    4f8c:      	and	x1, x8, #0xffffffffffff
    4f90:      	adrp	x3, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf64>
		0000000000004f90:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__26
    4f94:      	add	x3, x3, #0x0
		0000000000004f94:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__26
    4f98:      	bl	0x4f98 <_perry_fn_access_worker_ts__run$generic+0x1efc>
		0000000000004f98:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    4f9c:      	b	0x4ca0 <_perry_fn_access_worker_ts__run$generic+0x1c04>
    4fa0:      	cmp	x11, #0x0
    4fa4:      	ldr	w14, [x8]
    4fa8:      	ldp	x11, x13, [x8, #0x28]
    4fac:      	ccmp	x9, x14, #0x2, eq
    4fb0:      	ccmp	x11, #0x0, #0x4, lo
    4fb4:      	ccmp	x13, #0x0, #0x4, ne
    4fb8:      	csel	w12, wzr, w12, eq
    4fbc:      	tbz	w12, #0x0, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    4fc0:      	lsr	x12, x9, #6
    4fc4:      	ldr	x12, [x13, x12, lsl #3]
    4fc8:      	lsr	x12, x12, x9
    4fcc:      	tbz	w12, #0x0, 0x5038 <_perry_fn_access_worker_ts__run$generic+0x1f9c>
    4fd0:      	ldr	d0, [x11, x9, lsl #3]
    4fd4:      	b	0x5150 <_perry_fn_access_worker_ts__run$generic+0x20b4>
    4fd8:      	ldrsb	w8, [x8, x9]
    4fdc:      	b	0x5004 <_perry_fn_access_worker_ts__run$generic+0x1f68>
    4fe0:      	ldr	b0, [x8, x9]
    4fe4:      	ucvtf	d0, d0
    4fe8:      	b	0x5150 <_perry_fn_access_worker_ts__run$generic+0x20b4>
    4fec:      	ldr	w8, [x8, x9, lsl #2]
    4ff0:      	b	0x5004 <_perry_fn_access_worker_ts__run$generic+0x1f68>
    4ff4:      	ldr	s0, [x8, x9, lsl #2]
    4ff8:      	fcvt	d0, s0
    4ffc:      	b	0x5150 <_perry_fn_access_worker_ts__run$generic+0x20b4>
    5000:      	ldrsh	w8, [x8, x9, lsl #1]
    5004:      	scvtf	d0, w8
    5008:      	b	0x5150 <_perry_fn_access_worker_ts__run$generic+0x20b4>
    500c:      	cbz	x10, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    5010:      	ldr	x13, [x10, #0x30]
    5014:      	cmp	x13, x12
    5018:      	b.ne	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    501c:      	ldp	x14, x12, [x11, #0x8]
    5020:      	ldp	x13, x11, [x11, #0x18]
    5024:      	cmp	x14, x11
    5028:      	b.hs	0x5078 <_perry_fn_access_worker_ts__run$generic+0x1fdc>
    502c:      	add	x14, x8, x14, lsl #3
    5030:      	add	x14, x14, #0x10
    5034:      	b	0x509c <_perry_fn_access_worker_ts__run$generic+0x2000>
    5038:      	ldr	x8, [x8, #0x50]
    503c:      	mov	x12, #0x6e05            ; =28165
    5040:      	movk	x12, #0x6d61, lsl #16
    5044:      	movk	x12, #0x65, lsl #32
    5048:      	cmp	x8, x12
    504c:      	b.eq	0x5054 <_perry_fn_access_worker_ts__run$generic+0x1fb8>
    5050:      	cbnz	x8, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    5054:      	cmp	x8, x12
    5058:      	b.ne	0x5104 <_perry_fn_access_worker_ts__run$generic+0x2068>
    505c:      	ldr	x8, [x11, x9, lsl #3]
    5060:      	cbz	x8, 0x5104 <_perry_fn_access_worker_ts__run$generic+0x2068>
    5064:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    5068:      	cmp	x8, x9
    506c:      	csel	x8, xzr, x8, eq
    5070:      	fmov	d0, x8
    5074:      	b	0x533c <_perry_fn_access_worker_ts__run$generic+0x22a0>
    5078:      	ldr	x16, [x10, #0x20]
    507c:      	cmp	x16, #0x0
    5080:      	csel	x15, x16, x10, ne
    5084:      	cbz	x16, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    5088:      	ldr	w16, [x15]
    508c:      	cmp	x14, x16
    5090:      	b.hs	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    5094:      	add	x14, x15, x14, lsl #3
    5098:      	add	x14, x14, #0x8
    509c:      	ldr	d0, [x14]
    50a0:      	fcmp	d8, d0
    50a4:      	ccmp	x13, x9, #0x0, mi
    50a8:      	cset	w13, hi
    50ac:      	add	x9, x12, x9
    50b0:      	cmp	x9, x11
    50b4:      	b.hs	0x50c8 <_perry_fn_access_worker_ts__run$generic+0x202c>
    50b8:      	cbz	w13, 0x50c8 <_perry_fn_access_worker_ts__run$generic+0x202c>
    50bc:      	add	x8, x8, x9, lsl #3
    50c0:      	ldr	d0, [x8, #0x10]
    50c4:      	b	0x5150 <_perry_fn_access_worker_ts__run$generic+0x20b4>
    50c8:      	cbz	x10, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    50cc:      	cmp	x9, x11
    50d0:      	b.lo	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    50d4:      	eor	w8, w13, #0x1
    50d8:      	tbnz	w8, #0x0, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    50dc:      	ldr	x11, [x10, #0x20]
    50e0:      	cmp	x11, #0x0
    50e4:      	csel	x8, x11, x10, ne
    50e8:      	cbz	x11, 0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    50ec:      	ldr	w10, [x8]
    50f0:      	cmp	x9, x10
    50f4:      	b.hs	0x5130 <_perry_fn_access_worker_ts__run$generic+0x2094>
    50f8:      	add	x8, x8, x9, lsl #3
    50fc:      	ldr	d0, [x8, #0x8]
    5100:      	b	0x5150 <_perry_fn_access_worker_ts__run$generic+0x20b4>
    5104:      	fmov	d0, x10
    5108:      	mov.16b	v1, v8
    510c:      	adrp	x0, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		000000000000510c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.4.bytes
    5110:      	add	x0, x0, #0x0
		0000000000005110:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.4.bytes
    5114:      	mov	w1, #0x4                ; =4
    5118:      	bl	0x5118 <_perry_fn_access_worker_ts__run$generic+0x207c>
		0000000000005118:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    511c:      	fmov	x8, d0
    5120:      	mov	x9, #0x10               ; =16
    5124:      	movk	x9, #0x7ffc, lsl #48
    5128:      	cmp	x8, x9
    512c:      	b.ne	0x533c <_perry_fn_access_worker_ts__run$generic+0x22a0>
    5130:      	fmov	d0, x26
    5134:      	str	x20, [sp, #0x28]
    5138:      	mov.16b	v1, v8
    513c:      	adrp	x0, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		000000000000513c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__27
    5140:      	add	x0, x0, #0x0
		0000000000005140:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__27
    5144:      	bl	0x5144 <_perry_fn_access_worker_ts__run$generic+0x20a8>
		0000000000005144:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    5148:      	ldp	x26, x24, [sp, #0x18]
    514c:      	ldr	x20, [sp, #0x28]
    5150:      	fmov	x8, d0
    5154:      	and	x9, x8, x25
    5158:      	cmp	x9, x22
    515c:      	b.ne	0x51cc <_perry_fn_access_worker_ts__run$generic+0x2130>
    5160:      	and	x0, x8, #0xffffffffffff
    5164:      	lsr	x8, x0, #20
    5168:      	cbz	x8, 0x5318 <_perry_fn_access_worker_ts__run$generic+0x227c>
    516c:      	ldurb	w9, [x0, #-0x8]
    5170:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005170:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__29
    5174:      	ldr	x8, [x8]
		0000000000005174:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__29
    5178:      	cbz	x8, 0x523c <_perry_fn_access_worker_ts__run$generic+0x21a0>
    517c:      	cmp	w9, #0x2
    5180:      	b.ne	0x523c <_perry_fn_access_worker_ts__run$generic+0x21a0>
    5184:      	ldurh	w10, [x0, #-0x6]
    5188:      	tbnz	w10, #0xb, 0x523c <_perry_fn_access_worker_ts__run$generic+0x21a0>
    518c:      	ldr	w10, [x0, #0x4]
    5190:      	orr	x9, x10, #0x4000000000000000
    5194:      	cbz	w10, 0x5268 <_perry_fn_access_worker_ts__run$generic+0x21cc>
    5198:      	ldr	x11, [x8]
    519c:      	cmp	x9, x11
    51a0:      	b.ne	0x5268 <_perry_fn_access_worker_ts__run$generic+0x21cc>
    51a4:      	ldr	x2, [x8, #0x8]
    51a8:      	tbnz	w2, #0x1e, 0x5680 <_perry_fn_access_worker_ts__run$generic+0x25e4>
    51ac:      	add	x11, x0, x2, lsl #3
    51b0:      	ldr	d0, [x11, #0x10]
    51b4:      	fmov	x11, d0
    51b8:      	mov	x12, #0x10              ; =16
    51bc:      	movk	x12, #0x7ffc, lsl #48
    51c0:      	cmp	x11, x12
    51c4:      	b.ne	0x533c <_perry_fn_access_worker_ts__run$generic+0x22a0>
    51c8:      	b	0x5294 <_perry_fn_access_worker_ts__run$generic+0x21f8>
    51cc:      	lsr	x9, x8, #48
    51d0:      	mov	w10, #0x7ff9            ; =32761
    51d4:      	cmp	x9, x10
    51d8:      	b.eq	0x5220 <_perry_fn_access_worker_ts__run$generic+0x2184>
    51dc:      	mov	w10, #0x7ffe            ; =32766
    51e0:      	cmp	w9, w10
    51e4:      	b.ne	0x5210 <_perry_fn_access_worker_ts__run$generic+0x2174>
    51e8:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		00000000000051e8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    51ec:      	ldr	x9, [x9]
		00000000000051ec:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    51f0:      	str	x20, [sp, #0x28]
    51f4:      	and	x2, x9, #0xffffffffffff
    51f8:      	mov	x0, #0x1c               ; =28
    51fc:      	movk	x0, #0xddae, lsl #32
    5200:      	movk	x0, #0x5556, lsl #48
    5204:      	mov	x1, x8
    5208:      	bl	0x5208 <_perry_fn_access_worker_ts__run$generic+0x216c>
		0000000000005208:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    520c:      	b	0x5334 <_perry_fn_access_worker_ts__run$generic+0x2298>
    5210:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    5214:      	add	x9, x8, x9
    5218:      	cmp	x9, #0x2
    521c:      	b.lo	0x63b4 <_perry_fn_access_worker_ts__run$generic+0x3318>
    5220:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005220:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    5224:      	ldr	x9, [x9]
		0000000000005224:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    5228:      	str	x20, [sp, #0x28]
    522c:      	and	x1, x9, #0xffffffffffff
    5230:      	mov	x0, x8
    5234:      	bl	0x5234 <_perry_fn_access_worker_ts__run$generic+0x2198>
		0000000000005234:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    5238:      	b	0x5334 <_perry_fn_access_worker_ts__run$generic+0x2298>
    523c:      	cmp	w9, #0x2
    5240:      	b.ne	0x5318 <_perry_fn_access_worker_ts__run$generic+0x227c>
    5244:      	cbz	x8, 0x5318 <_perry_fn_access_worker_ts__run$generic+0x227c>
    5248:      	ldr	x9, [x8, #0x10]
    524c:      	cbz	x9, 0x5318 <_perry_fn_access_worker_ts__run$generic+0x227c>
    5250:      	ldr	x10, [x0, #0x8]
    5254:      	cbz	x10, 0x5318 <_perry_fn_access_worker_ts__run$generic+0x227c>
    5258:      	ldr	x10, [x10, #0x30]
    525c:      	cmp	x10, x9
    5260:      	b.eq	0x5284 <_perry_fn_access_worker_ts__run$generic+0x21e8>
    5264:      	b	0x5318 <_perry_fn_access_worker_ts__run$generic+0x227c>
    5268:      	ldr	x11, [x8, #0x10]
    526c:      	cbz	x11, 0x5294 <_perry_fn_access_worker_ts__run$generic+0x21f8>
    5270:      	ldr	x12, [x0, #0x8]
    5274:      	cbz	x12, 0x5294 <_perry_fn_access_worker_ts__run$generic+0x21f8>
    5278:      	ldr	x12, [x12, #0x30]
    527c:      	cmp	x12, x11
    5280:      	b.ne	0x5294 <_perry_fn_access_worker_ts__run$generic+0x21f8>
    5284:      	ldr	x8, [x8, #0x8]
    5288:      	add	x8, x0, x8, lsl #3
    528c:      	ldr	d0, [x8, #0x10]
    5290:      	b	0x533c <_perry_fn_access_worker_ts__run$generic+0x22a0>
    5294:      	ldr	x11, [x8, #0x18]
    5298:      	cmp	x11, #0x0
    529c:      	b.le	0x5318 <_perry_fn_access_worker_ts__run$generic+0x227c>
    52a0:      	ldr	x11, [x8, #0x20]
    52a4:      	ldr	x12, [x8, #0x30]
    52a8:      	ldr	x13, [x8, #0x40]
    52ac:      	cmp	x13, x9
    52b0:      	ldr	x14, [x8, #0x50]
    52b4:      	ccmp	x14, x9, #0x4, ne
    52b8:      	ccmp	x12, x9, #0x4, ne
    52bc:      	ccmp	x11, x9, #0x4, ne
    52c0:      	cset	w15, eq
    52c4:      	cbz	w10, 0x5318 <_perry_fn_access_worker_ts__run$generic+0x227c>
    52c8:      	cbz	w15, 0x5318 <_perry_fn_access_worker_ts__run$generic+0x227c>
    52cc:      	ldr	x10, [x8, #0x48]
    52d0:      	ldr	x15, [x8, #0x58]
    52d4:      	cmp	x14, x9
    52d8:      	csel	x14, x15, xzr, eq
    52dc:      	cmp	x13, x9
    52e0:      	csel	x10, x10, x14, eq
    52e4:      	ldr	x13, [x8, #0x28]
    52e8:      	ldr	x8, [x8, #0x38]
    52ec:      	cmp	x12, x9
    52f0:      	csel	x8, x8, x10, eq
    52f4:      	cmp	x11, x9
    52f8:      	csel	x8, x13, x8, eq
    52fc:      	add	x8, x0, x8, lsl #3
    5300:      	ldr	d0, [x8, #0x10]
    5304:      	fmov	x8, d0
    5308:      	mov	x9, #0x10               ; =16
    530c:      	movk	x9, #0x7ffc, lsl #48
    5310:      	cmp	x8, x9
    5314:      	b.ne	0x533c <_perry_fn_access_worker_ts__run$generic+0x22a0>
    5318:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005318:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    531c:      	ldr	x8, [x8]
		000000000000531c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    5320:      	str	x20, [sp, #0x28]
    5324:      	and	x1, x8, #0xffffffffffff
    5328:      	adrp	x2, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005328:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__29
    532c:      	add	x2, x2, #0x0
		000000000000532c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__29
    5330:      	bl	0x5330 <_perry_fn_access_worker_ts__run$generic+0x2294>
		0000000000005330:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    5334:      	ldp	x26, x24, [sp, #0x18]
    5338:      	ldr	x20, [sp, #0x28]
    533c:      	fmov	x8, d0
    5340:      	lsr	x9, x8, #48
    5344:      	mov	w10, #0x7ff9            ; =32761
    5348:      	cmp	x9, x10
    534c:      	b.eq	0x537c <_perry_fn_access_worker_ts__run$generic+0x22e0>
    5350:      	mov	w10, #0x7fff            ; =32767
    5354:      	cmp	w9, w10
    5358:      	b.ne	0x5388 <_perry_fn_access_worker_ts__run$generic+0x22ec>
    535c:      	and	x9, x8, #0xffffffffffff
    5360:      	tst	x8, #0xfffffffff000
    5364:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005364:  ARM64_RELOC_PAGE21	_perry_null_guard_zero_access_worker_ts
    5368:      	add	x8, x8, #0x0
		0000000000005368:  ARM64_RELOC_PAGEOFF12	_perry_null_guard_zero_access_worker_ts
    536c:      	csel	x8, x8, x9, eq
    5370:      	ldr	s0, [x8]
    5374:      	ucvtf	d1, d0
    5378:      	b	0x539c <_perry_fn_access_worker_ts__run$generic+0x2300>
    537c:      	ubfx	x8, x8, #40, #8
    5380:      	ucvtf	d1, x8
    5384:      	b	0x539c <_perry_fn_access_worker_ts__run$generic+0x2300>
    5388:      	str	x20, [sp, #0x28]
    538c:      	bl	0x538c <_perry_fn_access_worker_ts__run$generic+0x22f0>
		000000000000538c:  ARM64_RELOC_BRANCH26	_js_value_length_property_f64
    5390:      	mov.16b	v1, v0
    5394:      	ldp	x26, x24, [sp, #0x18]
    5398:      	ldr	x20, [sp, #0x28]
    539c:      	fmov	d0, x20
    53a0:      	and	x9, x20, #0xffff000000000000
    53a4:      	fmov	x8, d1
    53a8:      	and	x10, x8, #0xffff000000000000
    53ac:      	cmp	x8, x21
    53b0:      	ccmp	x10, x19, #0x2, hs
    53b4:      	cset	w8, hi
    53b8:      	mov	x10, #0x1               ; =1
    53bc:      	movk	x10, #0x7fff, lsl #48
    53c0:      	cmp	x9, x10
    53c4:      	ccmp	x20, x23, #0x0, lo
    53c8:      	b.hi	0x53d8 <_perry_fn_access_worker_ts__run$generic+0x233c>
    53cc:      	cbz	w8, 0x53d8 <_perry_fn_access_worker_ts__run$generic+0x233c>
    53d0:      	fadd	d0, d1, d0
    53d4:      	b	0x53e4 <_perry_fn_access_worker_ts__run$generic+0x2348>
    53d8:      	stp	x24, x26, [sp, #0x20]
    53dc:      	bl	0x53dc <_perry_fn_access_worker_ts__run$generic+0x2340>
		00000000000053dc:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    53e0:      	ldp	x24, x26, [sp, #0x20]
    53e4:      	fmov	x20, d0
    53e8:      	mov	x0, x20
    53ec:      	ldr	w8, [x27]
    53f0:      	cbz	w8, 0x53f8 <_perry_fn_access_worker_ts__run$generic+0x235c>
    53f4:      	bl	0x53f4 <_perry_fn_access_worker_ts__run$generic+0x2358>
		00000000000053f4:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    53f8:      	mov	x0, x20
    53fc:      	ldr	w8, [x27]
    5400:      	cbz	w8, 0x5408 <_perry_fn_access_worker_ts__run$generic+0x236c>
    5404:      	bl	0x5404 <_perry_fn_access_worker_ts__run$generic+0x2368>
		0000000000005404:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    5408:      	mov	x10, x26
    540c:      	and	x8, x10, #0xffffffffffff
    5410:      	and	x12, x10, #0xffff000000000000
    5414:      	cmp	x12, x22
    5418:      	b.ne	0x54b4 <_perry_fn_access_worker_ts__run$generic+0x2418>
    541c:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		000000000000541c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    5420:      	ldr	x9, [x9]
		0000000000005420:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    5424:      	ldr	x9, [x9]
    5428:      	cbnz	x9, 0x54b4 <_perry_fn_access_worker_ts__run$generic+0x2418>
    542c:      	sub	x9, x8, #0x100, lsl #12 ; =0x100000
    5430:      	mov	x11, #0x7ffffff00000    ; =140737487306752
    5434:      	cmp	x9, x11
    5438:      	b.hs	0x54b4 <_perry_fn_access_worker_ts__run$generic+0x2418>
    543c:      	mov	x9, #0x41f0000000000000 ; =4751297606875873280
    5440:      	fmov	d0, x9
    5444:      	fcmp	d8, d0
    5448:      	b.pl	0x54b4 <_perry_fn_access_worker_ts__run$generic+0x2418>
    544c:      	fcmp	d8, #0.0
    5450:      	b.lt	0x54b4 <_perry_fn_access_worker_ts__run$generic+0x2418>
    5454:      	ldurb	w9, [x8, #-0x8]
    5458:      	cmp	w9, #0xb
    545c:      	b.ne	0x54b4 <_perry_fn_access_worker_ts__run$generic+0x2418>
    5460:      	ldrb	w11, [x8, #0x8]
    5464:      	cmp	w11, #0x9
    5468:      	b.hs	0x54b4 <_perry_fn_access_worker_ts__run$generic+0x2418>
    546c:      	fcvtzs	x9, d8
    5470:      	scvtf	d0, x9
    5474:      	fcmp	d8, d0
    5478:      	b.ne	0x54b4 <_perry_fn_access_worker_ts__run$generic+0x2418>
    547c:      	ldr	w13, [x8]
    5480:      	cmp	x9, x13
    5484:      	b.hs	0x54b4 <_perry_fn_access_worker_ts__run$generic+0x2418>
    5488:      	add	x8, x8, #0x10
    548c:      	cmp	w11, #0x3
    5490:      	b.le	0x557c <_perry_fn_access_worker_ts__run$generic+0x24e0>
    5494:      	cmp	w11, #0x5
    5498:      	b.gt	0x5634 <_perry_fn_access_worker_ts__run$generic+0x2598>
    549c:      	cmp	w11, #0x4
    54a0:      	b.eq	0x56ec <_perry_fn_access_worker_ts__run$generic+0x2650>
    54a4:      	cmp	w11, #0x5
    54a8:      	b.ne	0x56e0 <_perry_fn_access_worker_ts__run$generic+0x2644>
    54ac:      	ldr	s0, [x8, x9, lsl #2]
    54b0:      	b	0x56e4 <_perry_fn_access_worker_ts__run$generic+0x2648>
    54b4:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		00000000000054b4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__30
    54b8:      	add	x9, x9, #0x0
		00000000000054b8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__30
    54bc:      	ldr	x11, [x9]
    54c0:      	cmp	x11, #0x0
    54c4:      	csel	x13, x9, x11, eq
    54c8:      	cmp	x12, x22
    54cc:      	b.ne	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    54d0:      	fcmp	d8, #0.0
    54d4:      	b.lt	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    54d8:      	fcmp	d8, d10
    54dc:      	b.pl	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    54e0:      	mov	x9, #-0x20000000000     ; =-2199023255552
    54e4:      	add	x9, x8, x9
    54e8:      	lsr	x9, x9, #41
    54ec:      	cmp	x9, #0x3f
    54f0:      	b.hs	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    54f4:      	fcvtzs	x9, d8
    54f8:      	scvtf	d0, x9
    54fc:      	fcmp	d8, d0
    5500:      	b.ne	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    5504:      	ldursb	w12, [x8, #-0x7]
    5508:      	tbnz	w12, #0x1f, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    550c:      	ldurb	w12, [x8, #-0x8]
    5510:      	cmp	w12, #0x9
    5514:      	b.eq	0x55e8 <_perry_fn_access_worker_ts__run$generic+0x254c>
    5518:      	cmp	w12, #0x2
    551c:      	b.eq	0x5598 <_perry_fn_access_worker_ts__run$generic+0x24fc>
    5520:      	cmp	w12, #0x1
    5524:      	b.ne	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    5528:      	ldr	w10, [x8]
    552c:      	mov	x11, x8
    5530:      	ldurh	w13, [x8, #-0x6]
    5534:      	adrp	x12, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005534:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    5538:      	ldr	x12, [x12]
		0000000000005538:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    553c:      	ldrb	w12, [x12]
    5540:      	ldr	w8, [x8, #0x4]
    5544:      	cmp	x10, x8
    5548:      	b.hi	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    554c:      	tbnz	w13, #0xa, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    5550:      	cbnz	w12, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    5554:      	cmp	x9, x10
    5558:      	b.hs	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    555c:      	add	x8, x11, x9, lsl #3
    5560:      	ldr	d0, [x8, #0x8]
    5564:      	fmov	x8, d0
    5568:      	mov	x9, #0x10               ; =16
    556c:      	movk	x9, #0x7ffc, lsl #48
    5570:      	cmp	x8, x9
    5574:      	fcsel	d0, d11, d0, eq
    5578:      	b	0x585c <_perry_fn_access_worker_ts__run$generic+0x27c0>
    557c:      	cbz	w11, 0x56d8 <_perry_fn_access_worker_ts__run$generic+0x263c>
    5580:      	cmp	w11, #0x2
    5584:      	b.eq	0x5700 <_perry_fn_access_worker_ts__run$generic+0x2664>
    5588:      	cmp	w11, #0x3
    558c:      	b.ne	0x56e0 <_perry_fn_access_worker_ts__run$generic+0x2644>
    5590:      	ldr	h0, [x8, x9, lsl #1]
    5594:      	b	0x56e4 <_perry_fn_access_worker_ts__run$generic+0x2648>
    5598:      	ldr	x10, [x8, #0x8]
    559c:      	cbz	x10, 0x564c <_perry_fn_access_worker_ts__run$generic+0x25b0>
    55a0:      	ldr	x12, [x10, #0x60]
    55a4:      	cbz	x12, 0x564c <_perry_fn_access_worker_ts__run$generic+0x25b0>
    55a8:      	ldurb	w8, [x12, #-0x8]
    55ac:      	cmp	w8, #0x1
    55b0:      	b.ne	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    55b4:      	ldursb	w8, [x12, #-0x7]
    55b8:      	tbnz	w8, #0x1f, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    55bc:      	ldr	w8, [x12]
    55c0:      	cmp	x9, x8
    55c4:      	b.hs	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    55c8:      	add	x8, x12, x9, lsl #3
    55cc:      	ldr	d0, [x8, #0x8]
    55d0:      	fmov	x8, d0
    55d4:      	mov	x9, #0x10               ; =16
    55d8:      	movk	x9, #0x7ffc, lsl #48
    55dc:      	cmp	x8, x9
    55e0:      	b.eq	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    55e4:      	b	0x585c <_perry_fn_access_worker_ts__run$generic+0x27c0>
    55e8:      	ldr	w12, [x8, #0x4]
    55ec:      	ldr	x11, [x8, #0x20]
    55f0:      	ldurh	w13, [x8, #-0x6]
    55f4:      	tst	w13, #0xc00
    55f8:      	mov	w13, #0x5841            ; =22593
    55fc:      	movk	w13, #0x4c5a, lsl #16
    5600:      	ccmp	w12, w13, #0x0, eq
    5604:      	cset	w12, eq
    5608:      	cbz	x11, 0x56a0 <_perry_fn_access_worker_ts__run$generic+0x2604>
    560c:      	tbz	w12, #0x0, 0x56a0 <_perry_fn_access_worker_ts__run$generic+0x2604>
    5610:      	ldurb	w10, [x11, #-0x8]
    5614:      	cmp	w10, #0x1
    5618:      	b.ne	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    561c:      	ldursb	w10, [x11, #-0x7]
    5620:      	tbnz	w10, #0x1f, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    5624:      	ldr	w10, [x11]
    5628:      	str	w10, [x8]
    562c:      	mov	x8, x11
    5630:      	b	0x5530 <_perry_fn_access_worker_ts__run$generic+0x2494>
    5634:      	cmp	w11, #0x6
    5638:      	b.eq	0x56f4 <_perry_fn_access_worker_ts__run$generic+0x2658>
    563c:      	cmp	w11, #0x7
    5640:      	b.ne	0x56e0 <_perry_fn_access_worker_ts__run$generic+0x2644>
    5644:      	ldr	d0, [x8, x9, lsl #3]
    5648:      	b	0x585c <_perry_fn_access_worker_ts__run$generic+0x27c0>
    564c:      	ldr	x12, [x13]
    5650:      	cbz	x12, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    5654:      	tbnz	x12, #0x3f, 0x570c <_perry_fn_access_worker_ts__run$generic+0x2670>
    5658:      	ldp	w14, w13, [x8]
    565c:      	orr	x13, x13, x14, lsl #32
    5660:      	cmp	x13, x12
    5664:      	b.ne	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    5668:      	ldp	x14, x12, [x11, #0x8]
    566c:      	ldp	x13, x11, [x11, #0x18]
    5670:      	cmp	x14, x11
    5674:      	b.lo	0x572c <_perry_fn_access_worker_ts__run$generic+0x2690>
    5678:      	cbz	x10, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    567c:      	b	0x577c <_perry_fn_access_worker_ts__run$generic+0x26e0>
    5680:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005680:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    5684:      	ldr	x8, [x8]
		0000000000005684:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    5688:      	str	x20, [sp, #0x28]
    568c:      	and	x1, x8, #0xffffffffffff
    5690:      	adrp	x3, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005690:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__29
    5694:      	add	x3, x3, #0x0
		0000000000005694:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__29
    5698:      	bl	0x5698 <_perry_fn_access_worker_ts__run$generic+0x25fc>
		0000000000005698:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    569c:      	b	0x5334 <_perry_fn_access_worker_ts__run$generic+0x2298>
    56a0:      	cmp	x11, #0x0
    56a4:      	ldr	w14, [x8]
    56a8:      	ldp	x11, x13, [x8, #0x28]
    56ac:      	ccmp	x9, x14, #0x2, eq
    56b0:      	ccmp	x11, #0x0, #0x4, lo
    56b4:      	ccmp	x13, #0x0, #0x4, ne
    56b8:      	csel	w12, wzr, w12, eq
    56bc:      	tbz	w12, #0x0, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    56c0:      	lsr	x12, x9, #6
    56c4:      	ldr	x12, [x13, x12, lsl #3]
    56c8:      	lsr	x12, x12, x9
    56cc:      	tbz	w12, #0x0, 0x5738 <_perry_fn_access_worker_ts__run$generic+0x269c>
    56d0:      	ldr	d0, [x11, x9, lsl #3]
    56d4:      	b	0x585c <_perry_fn_access_worker_ts__run$generic+0x27c0>
    56d8:      	ldrsb	w8, [x8, x9]
    56dc:      	b	0x5704 <_perry_fn_access_worker_ts__run$generic+0x2668>
    56e0:      	ldr	b0, [x8, x9]
    56e4:      	ucvtf	d0, d0
    56e8:      	b	0x585c <_perry_fn_access_worker_ts__run$generic+0x27c0>
    56ec:      	ldr	w8, [x8, x9, lsl #2]
    56f0:      	b	0x5704 <_perry_fn_access_worker_ts__run$generic+0x2668>
    56f4:      	ldr	s0, [x8, x9, lsl #2]
    56f8:      	fcvt	d0, s0
    56fc:      	b	0x585c <_perry_fn_access_worker_ts__run$generic+0x27c0>
    5700:      	ldrsh	w8, [x8, x9, lsl #1]
    5704:      	scvtf	d0, w8
    5708:      	b	0x585c <_perry_fn_access_worker_ts__run$generic+0x27c0>
    570c:      	cbz	x10, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    5710:      	ldr	x13, [x10, #0x30]
    5714:      	cmp	x13, x12
    5718:      	b.ne	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    571c:      	ldp	x14, x12, [x11, #0x8]
    5720:      	ldp	x13, x11, [x11, #0x18]
    5724:      	cmp	x14, x11
    5728:      	b.hs	0x577c <_perry_fn_access_worker_ts__run$generic+0x26e0>
    572c:      	add	x14, x8, x14, lsl #3
    5730:      	add	x14, x14, #0x10
    5734:      	b	0x57a0 <_perry_fn_access_worker_ts__run$generic+0x2704>
    5738:      	ldr	x8, [x8, #0x50]
    573c:      	mov	x12, #0x6107            ; =24839
    5740:      	movk	x12, #0x7463, lsl #16
    5744:      	movk	x12, #0x7669, lsl #32
    5748:      	movk	x12, #0x65, lsl #48
    574c:      	cmp	x8, x12
    5750:      	b.eq	0x5758 <_perry_fn_access_worker_ts__run$generic+0x26bc>
    5754:      	cbnz	x8, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    5758:      	cmp	x8, x12
    575c:      	b.ne	0x5808 <_perry_fn_access_worker_ts__run$generic+0x276c>
    5760:      	ldr	x8, [x11, x9, lsl #3]
    5764:      	cbz	x8, 0x5808 <_perry_fn_access_worker_ts__run$generic+0x276c>
    5768:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    576c:      	cmp	x8, x9
    5770:      	csel	x8, xzr, x8, eq
    5774:      	fmov	d0, x8
    5778:      	b	0x5a54 <_perry_fn_access_worker_ts__run$generic+0x29b8>
    577c:      	ldr	x16, [x10, #0x20]
    5780:      	cmp	x16, #0x0
    5784:      	csel	x15, x16, x10, ne
    5788:      	cbz	x16, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    578c:      	ldr	w16, [x15]
    5790:      	cmp	x14, x16
    5794:      	b.hs	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    5798:      	add	x14, x15, x14, lsl #3
    579c:      	add	x14, x14, #0x8
    57a0:      	ldr	d0, [x14]
    57a4:      	fcmp	d8, d0
    57a8:      	ccmp	x13, x9, #0x0, mi
    57ac:      	cset	w13, hi
    57b0:      	add	x9, x12, x9
    57b4:      	cmp	x9, x11
    57b8:      	b.hs	0x57cc <_perry_fn_access_worker_ts__run$generic+0x2730>
    57bc:      	cbz	w13, 0x57cc <_perry_fn_access_worker_ts__run$generic+0x2730>
    57c0:      	add	x8, x8, x9, lsl #3
    57c4:      	ldr	d0, [x8, #0x10]
    57c8:      	b	0x585c <_perry_fn_access_worker_ts__run$generic+0x27c0>
    57cc:      	cbz	x10, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    57d0:      	cmp	x9, x11
    57d4:      	b.lo	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    57d8:      	eor	w8, w13, #0x1
    57dc:      	tbnz	w8, #0x0, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    57e0:      	ldr	x11, [x10, #0x20]
    57e4:      	cmp	x11, #0x0
    57e8:      	csel	x8, x11, x10, ne
    57ec:      	cbz	x11, 0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    57f0:      	ldr	w10, [x8]
    57f4:      	cmp	x9, x10
    57f8:      	b.hs	0x5834 <_perry_fn_access_worker_ts__run$generic+0x2798>
    57fc:      	add	x8, x8, x9, lsl #3
    5800:      	ldr	d0, [x8, #0x8]
    5804:      	b	0x585c <_perry_fn_access_worker_ts__run$generic+0x27c0>
    5808:      	fmov	d0, x10
    580c:      	mov.16b	v1, v8
    5810:      	adrp	x0, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005810:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.5.bytes
    5814:      	add	x0, x0, #0x0
		0000000000005814:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.5.bytes
    5818:      	mov	w1, #0x6                ; =6
    581c:      	bl	0x581c <_perry_fn_access_worker_ts__run$generic+0x2780>
		000000000000581c:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    5820:      	fmov	x8, d0
    5824:      	mov	x9, #0x10               ; =16
    5828:      	movk	x9, #0x7ffc, lsl #48
    582c:      	cmp	x8, x9
    5830:      	b.ne	0x5a54 <_perry_fn_access_worker_ts__run$generic+0x29b8>
    5834:      	mov	x8, x26
    5838:      	stp	x26, x20, [sp, #0x20]
    583c:      	fmov	d0, x8
    5840:      	str	x24, [sp, #0x18]
    5844:      	mov.16b	v1, v8
    5848:      	adrp	x0, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005848:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__30
    584c:      	add	x0, x0, #0x0
		000000000000584c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__30
    5850:      	bl	0x5850 <_perry_fn_access_worker_ts__run$generic+0x27b4>
		0000000000005850:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    5854:      	ldp	x24, x26, [sp, #0x18]
    5858:      	ldr	x20, [sp, #0x28]
    585c:      	fmov	x8, d0
    5860:      	and	x9, x8, x25
    5864:      	cmp	x9, x22
    5868:      	b.ne	0x58d8 <_perry_fn_access_worker_ts__run$generic+0x283c>
    586c:      	and	x0, x8, #0xffffffffffff
    5870:      	lsr	x8, x0, #20
    5874:      	cbz	x8, 0x5a2c <_perry_fn_access_worker_ts__run$generic+0x2990>
    5878:      	ldurb	w9, [x0, #-0x8]
    587c:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		000000000000587c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__32
    5880:      	ldr	x8, [x8]
		0000000000005880:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__32
    5884:      	cbz	x8, 0x5950 <_perry_fn_access_worker_ts__run$generic+0x28b4>
    5888:      	cmp	w9, #0x2
    588c:      	b.ne	0x5950 <_perry_fn_access_worker_ts__run$generic+0x28b4>
    5890:      	ldurh	w10, [x0, #-0x6]
    5894:      	tbnz	w10, #0xb, 0x5950 <_perry_fn_access_worker_ts__run$generic+0x28b4>
    5898:      	ldr	w10, [x0, #0x4]
    589c:      	orr	x9, x10, #0x4000000000000000
    58a0:      	cbz	w10, 0x597c <_perry_fn_access_worker_ts__run$generic+0x28e0>
    58a4:      	ldr	x11, [x8]
    58a8:      	cmp	x9, x11
    58ac:      	b.ne	0x597c <_perry_fn_access_worker_ts__run$generic+0x28e0>
    58b0:      	ldr	x2, [x8, #0x8]
    58b4:      	tbnz	w2, #0x1e, 0x5b44 <_perry_fn_access_worker_ts__run$generic+0x2aa8>
    58b8:      	add	x11, x0, x2, lsl #3
    58bc:      	ldr	d0, [x11, #0x10]
    58c0:      	fmov	x11, d0
    58c4:      	mov	x12, #0x10              ; =16
    58c8:      	movk	x12, #0x7ffc, lsl #48
    58cc:      	cmp	x11, x12
    58d0:      	b.ne	0x5a54 <_perry_fn_access_worker_ts__run$generic+0x29b8>
    58d4:      	b	0x59a8 <_perry_fn_access_worker_ts__run$generic+0x290c>
    58d8:      	lsr	x9, x8, #48
    58dc:      	mov	w10, #0x7ff9            ; =32761
    58e0:      	cmp	x9, x10
    58e4:      	b.eq	0x5930 <_perry_fn_access_worker_ts__run$generic+0x2894>
    58e8:      	mov	w10, #0x7ffe            ; =32766
    58ec:      	cmp	w9, w10
    58f0:      	b.ne	0x5920 <_perry_fn_access_worker_ts__run$generic+0x2884>
    58f4:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		00000000000058f4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    58f8:      	ldr	x9, [x9]
		00000000000058f8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    58fc:      	stp	x26, x20, [sp, #0x20]
    5900:      	str	x24, [sp, #0x18]
    5904:      	and	x2, x9, #0xffffffffffff
    5908:      	mov	x0, #0x1f               ; =31
    590c:      	movk	x0, #0xddae, lsl #32
    5910:      	movk	x0, #0x5556, lsl #48
    5914:      	mov	x1, x8
    5918:      	bl	0x5918 <_perry_fn_access_worker_ts__run$generic+0x287c>
		0000000000005918:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    591c:      	b	0x5a4c <_perry_fn_access_worker_ts__run$generic+0x29b0>
    5920:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    5924:      	add	x9, x8, x9
    5928:      	cmp	x9, #0x2
    592c:      	b.lo	0x63d8 <_perry_fn_access_worker_ts__run$generic+0x333c>
    5930:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005930:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    5934:      	ldr	x9, [x9]
		0000000000005934:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    5938:      	stp	x26, x20, [sp, #0x20]
    593c:      	str	x24, [sp, #0x18]
    5940:      	and	x1, x9, #0xffffffffffff
    5944:      	mov	x0, x8
    5948:      	bl	0x5948 <_perry_fn_access_worker_ts__run$generic+0x28ac>
		0000000000005948:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    594c:      	b	0x5a4c <_perry_fn_access_worker_ts__run$generic+0x29b0>
    5950:      	cmp	w9, #0x2
    5954:      	b.ne	0x5a2c <_perry_fn_access_worker_ts__run$generic+0x2990>
    5958:      	cbz	x8, 0x5a2c <_perry_fn_access_worker_ts__run$generic+0x2990>
    595c:      	ldr	x9, [x8, #0x10]
    5960:      	cbz	x9, 0x5a2c <_perry_fn_access_worker_ts__run$generic+0x2990>
    5964:      	ldr	x10, [x0, #0x8]
    5968:      	cbz	x10, 0x5a2c <_perry_fn_access_worker_ts__run$generic+0x2990>
    596c:      	ldr	x10, [x10, #0x30]
    5970:      	cmp	x10, x9
    5974:      	b.eq	0x5998 <_perry_fn_access_worker_ts__run$generic+0x28fc>
    5978:      	b	0x5a2c <_perry_fn_access_worker_ts__run$generic+0x2990>
    597c:      	ldr	x11, [x8, #0x10]
    5980:      	cbz	x11, 0x59a8 <_perry_fn_access_worker_ts__run$generic+0x290c>
    5984:      	ldr	x12, [x0, #0x8]
    5988:      	cbz	x12, 0x59a8 <_perry_fn_access_worker_ts__run$generic+0x290c>
    598c:      	ldr	x12, [x12, #0x30]
    5990:      	cmp	x12, x11
    5994:      	b.ne	0x59a8 <_perry_fn_access_worker_ts__run$generic+0x290c>
    5998:      	ldr	x8, [x8, #0x8]
    599c:      	add	x8, x0, x8, lsl #3
    59a0:      	ldr	d0, [x8, #0x10]
    59a4:      	b	0x5a54 <_perry_fn_access_worker_ts__run$generic+0x29b8>
    59a8:      	ldr	x11, [x8, #0x18]
    59ac:      	cmp	x11, #0x0
    59b0:      	b.le	0x5a2c <_perry_fn_access_worker_ts__run$generic+0x2990>
    59b4:      	ldr	x11, [x8, #0x20]
    59b8:      	ldr	x12, [x8, #0x30]
    59bc:      	ldr	x13, [x8, #0x40]
    59c0:      	cmp	x13, x9
    59c4:      	ldr	x14, [x8, #0x50]
    59c8:      	ccmp	x14, x9, #0x4, ne
    59cc:      	ccmp	x12, x9, #0x4, ne
    59d0:      	ccmp	x11, x9, #0x4, ne
    59d4:      	cset	w15, eq
    59d8:      	cbz	w10, 0x5a2c <_perry_fn_access_worker_ts__run$generic+0x2990>
    59dc:      	cbz	w15, 0x5a2c <_perry_fn_access_worker_ts__run$generic+0x2990>
    59e0:      	ldr	x10, [x8, #0x48]
    59e4:      	ldr	x15, [x8, #0x58]
    59e8:      	cmp	x14, x9
    59ec:      	csel	x14, x15, xzr, eq
    59f0:      	cmp	x13, x9
    59f4:      	csel	x10, x10, x14, eq
    59f8:      	ldr	x13, [x8, #0x28]
    59fc:      	ldr	x8, [x8, #0x38]
    5a00:      	cmp	x12, x9
    5a04:      	csel	x8, x8, x10, eq
    5a08:      	cmp	x11, x9
    5a0c:      	csel	x8, x13, x8, eq
    5a10:      	add	x8, x0, x8, lsl #3
    5a14:      	ldr	d0, [x8, #0x10]
    5a18:      	fmov	x8, d0
    5a1c:      	mov	x9, #0x10               ; =16
    5a20:      	movk	x9, #0x7ffc, lsl #48
    5a24:      	cmp	x8, x9
    5a28:      	b.ne	0x5a54 <_perry_fn_access_worker_ts__run$generic+0x29b8>
    5a2c:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005a2c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    5a30:      	ldr	x8, [x8]
		0000000000005a30:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    5a34:      	stp	x26, x20, [sp, #0x20]
    5a38:      	str	x24, [sp, #0x18]
    5a3c:      	and	x1, x8, #0xffffffffffff
    5a40:      	adrp	x2, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005a40:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__32
    5a44:      	add	x2, x2, #0x0
		0000000000005a44:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__32
    5a48:      	bl	0x5a48 <_perry_fn_access_worker_ts__run$generic+0x29ac>
		0000000000005a48:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    5a4c:      	ldp	x24, x26, [sp, #0x18]
    5a50:      	ldr	x20, [sp, #0x28]
    5a54:      	fmov	x8, d0
    5a58:      	mov	x9, #0x7ff8000000000000 ; =9221120237041090560
    5a5c:      	bics	xzr, x9, x8
    5a60:      	b.ne	0x5a90 <_perry_fn_access_worker_ts__run$generic+0x29f4>
    5a64:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    5a68:      	add	x9, x8, x9
    5a6c:      	cmp	x9, #0x4
    5a70:      	b.hs	0x5aa4 <_perry_fn_access_worker_ts__run$generic+0x2a08>
    5a74:      	mov	x9, #0x10               ; =16
    5a78:      	movk	x9, #0x7ffc, lsl #48
    5a7c:      	sub	x9, x9, #0xc
    5a80:      	movi.2d	v1, #0000000000000000
    5a84:      	cmp	x8, x9
    5a88:      	b.eq	0x5ac0 <_perry_fn_access_worker_ts__run$generic+0x2a24>
    5a8c:      	b	0x5ac4 <_perry_fn_access_worker_ts__run$generic+0x2a28>
    5a90:      	movi.2d	v1, #0000000000000000
    5a94:      	fcmp	d0, #0.0
    5a98:      	b.eq	0x5ac4 <_perry_fn_access_worker_ts__run$generic+0x2a28>
    5a9c:      	b.vs	0x5ac4 <_perry_fn_access_worker_ts__run$generic+0x2a28>
    5aa0:      	b	0x5ac0 <_perry_fn_access_worker_ts__run$generic+0x2a24>
    5aa4:      	mov	w9, #0x7ffd             ; =32765
    5aa8:      	cmp	x9, x8, lsr #48
    5aac:      	b.ne	0x5ab8 <_perry_fn_access_worker_ts__run$generic+0x2a1c>
    5ab0:      	and	x8, x8, #0xffffffffffff
    5ab4:      	cbnz	x8, 0x5ac0 <_perry_fn_access_worker_ts__run$generic+0x2a24>
    5ab8:      	bl	0x5ab8 <_perry_fn_access_worker_ts__run$generic+0x2a1c>
		0000000000005ab8:  ARM64_RELOC_BRANCH26	_js_is_truthy
    5abc:      	cbz	w0, 0x5b3c <_perry_fn_access_worker_ts__run$generic+0x2aa0>
    5ac0:      	fmov	d1, #1.00000000
    5ac4:      	fmov	d0, x20
    5ac8:      	and	x8, x20, #0xffff000000000000
    5acc:      	cmp	x20, x21
    5ad0:      	ccmp	x8, x19, #0x2, hs
    5ad4:      	cset	w8, hi
    5ad8:      	fmov	x9, d1
    5adc:      	cmp	x9, x23
    5ae0:      	b.hi	0x5af0 <_perry_fn_access_worker_ts__run$generic+0x2a54>
    5ae4:      	tbz	w8, #0x0, 0x5af0 <_perry_fn_access_worker_ts__run$generic+0x2a54>
    5ae8:      	fadd	d0, d1, d0
    5aec:      	b	0x5afc <_perry_fn_access_worker_ts__run$generic+0x2a60>
    5af0:      	stp	x24, x26, [sp, #0x20]
    5af4:      	bl	0x5af4 <_perry_fn_access_worker_ts__run$generic+0x2a58>
		0000000000005af4:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    5af8:      	ldp	x24, x26, [sp, #0x20]
    5afc:      	fmov	x20, d0
    5b00:      	mov	x0, x20
    5b04:      	ldr	w8, [x27]
    5b08:      	cbz	w8, 0x5b10 <_perry_fn_access_worker_ts__run$generic+0x2a74>
    5b0c:      	bl	0x5b0c <_perry_fn_access_worker_ts__run$generic+0x2a70>
		0000000000005b0c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    5b10:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005b10:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    5b14:      	ldr	x8, [x8]
		0000000000005b14:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    5b18:      	ldr	w8, [x8]
    5b1c:      	cbz	w8, 0x5b34 <_perry_fn_access_worker_ts__run$generic+0x2a98>
    5b20:      	stp	x26, x24, [sp, #0x20]
    5b24:      	str	x20, [sp, #0x18]
    5b28:      	bl	0x5b28 <_perry_fn_access_worker_ts__run$generic+0x2a8c>
		0000000000005b28:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    5b2c:      	ldp	x20, x26, [sp, #0x18]
    5b30:      	ldr	x24, [sp, #0x28]
    5b34:      	add	w28, w28, #0x1
    5b38:      	b	0x4558 <_perry_fn_access_worker_ts__run$generic+0x14bc>
    5b3c:      	movi.2d	v1, #0000000000000000
    5b40:      	b	0x5ac4 <_perry_fn_access_worker_ts__run$generic+0x2a28>
    5b44:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005b44:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    5b48:      	ldr	x8, [x8]
		0000000000005b48:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    5b4c:      	stp	x26, x20, [sp, #0x20]
    5b50:      	str	x24, [sp, #0x18]
    5b54:      	and	x1, x8, #0xffffffffffff
    5b58:      	adrp	x3, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005b58:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__32
    5b5c:      	add	x3, x3, #0x0
		0000000000005b5c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__32
    5b60:      	bl	0x5b60 <_perry_fn_access_worker_ts__run$generic+0x2ac4>
		0000000000005b60:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    5b64:      	b	0x5a4c <_perry_fn_access_worker_ts__run$generic+0x29b0>
    5b68:      	mov	x25, x22
    5b6c:      	mov	w28, #0x0               ; =0
    5b70:      	mov	x20, #0x0               ; =0
    5b74:      	mov	x23, #0x7ffd000000000000 ; =9222527611924643840
    5b78:      	adrp	x19, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005b78:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__33
    5b7c:      	add	x19, x19, #0x0
		0000000000005b7c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__33
    5b80:      	ldr	d10, [x21]
		0000000000005b80:  ARM64_RELOC_PAGEOFF12	lCPI1_2
    5b84:      	ldr	d11, [x11]
		0000000000005b84:  ARM64_RELOC_PAGEOFF12	lCPI1_3
    5b88:      	mov	x21, #0x7ff9000000000000 ; =9221401712017801216
    5b8c:      	mov	x8, #0x41f0000000000000 ; =4751297606875873280
    5b90:      	fmov	d12, x8
    5b94:      	movi.2d	v13, #0000000000000000
    5b98:      	fmov	d14, #1.00000000
    5b9c:      	tbnz	w25, #0x0, 0x5c94 <_perry_fn_access_worker_ts__run$generic+0x2bf8>
    5ba0:      	scvtf	d8, w28
    5ba4:      	mov	x8, x24
    5ba8:      	fmov	d1, x8
    5bac:      	and	x9, x8, #0xffff000000000000
    5bb0:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    5bb4:      	cmp	x9, x10
    5bb8:      	b.eq	0x5bf4 <_perry_fn_access_worker_ts__run$generic+0x2b58>
    5bbc:      	cmp	x8, x21
    5bc0:      	b.lt	0x5bf4 <_perry_fn_access_worker_ts__run$generic+0x2b58>
    5bc4:      	mov	x10, #-0x7ffc000000000001 ; =-9222246136947933185
    5bc8:      	add	x10, x8, x10
    5bcc:      	cmp	x10, #0x3
    5bd0:      	b.ls	0x5bf4 <_perry_fn_access_worker_ts__run$generic+0x2b58>
    5bd4:      	stp	x24, x20, [sp, #0x20]
    5bd8:      	str	x26, [sp, #0x18]
    5bdc:      	mov.16b	v0, v8
    5be0:      	bl	0x5be0 <_perry_fn_access_worker_ts__run$generic+0x2b44>
		0000000000005be0:  ARM64_RELOC_BRANCH26	_js_rel_lt
    5be4:      	mov.16b	v9, v0
    5be8:      	ldp	x26, x24, [sp, #0x18]
    5bec:      	ldr	x20, [sp, #0x28]
    5bf0:      	b	0x5c54 <_perry_fn_access_worker_ts__run$generic+0x2bb8>
    5bf4:      	mov	x12, #0x10              ; =16
    5bf8:      	movk	x12, #0x7ffc, lsl #48
    5bfc:      	sub	x10, x12, #0xc
    5c00:      	and	x11, x8, #0xfffffffffffffffe
    5c04:      	sub	x12, x12, #0xe
    5c08:      	scvtf	d0, w8
    5c0c:      	mov	x13, #0x7ffe000000000000 ; =9222809086901354496
    5c10:      	cmp	x9, x13
    5c14:      	fcsel	d0, d0, d1, eq
    5c18:      	cmp	x11, x12
    5c1c:      	fcsel	d0, d13, d0, eq
    5c20:      	cmp	x8, x10
    5c24:      	fcsel	d0, d14, d0, eq
    5c28:      	fmov	x8, d8
    5c2c:      	scvtf	d1, w8
    5c30:      	mov	w9, #0x7ffe             ; =32766
    5c34:      	cmp	x9, x8, lsr #48
    5c38:      	fcsel	d1, d1, d8, eq
    5c3c:      	fcmp	d1, d0
    5c40:      	mov	w8, #0x8                ; =8
    5c44:      	csel	x8, x8, xzr, mi
    5c48:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005c48:  ARM64_RELOC_PAGE21	lCPI1_1
    5c4c:      	add	x9, x9, #0x0
		0000000000005c4c:  ARM64_RELOC_PAGEOFF12	lCPI1_1
    5c50:      	ldr	d9, [x9, x8]
    5c54:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005c54:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    5c58:      	ldr	x8, [x8]
		0000000000005c58:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    5c5c:      	ldr	w8, [x8]
    5c60:      	cbz	w8, 0x5c78 <_perry_fn_access_worker_ts__run$generic+0x2bdc>
    5c64:      	stp	x26, x24, [sp, #0x20]
    5c68:      	str	x20, [sp, #0x18]
    5c6c:      	bl	0x5c6c <_perry_fn_access_worker_ts__run$generic+0x2bd0>
		0000000000005c6c:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    5c70:      	ldp	x20, x26, [sp, #0x18]
    5c74:      	ldr	x24, [sp, #0x28]
    5c78:      	fmov	x8, d9
    5c7c:      	mov	x9, #0x10               ; =16
    5c80:      	movk	x9, #0x7ffc, lsl #48
    5c84:      	sub	x9, x9, #0xc
    5c88:      	cmp	x8, x9
    5c8c:      	b.ne	0x3270 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    5c90:      	b	0x5ca0 <_perry_fn_access_worker_ts__run$generic+0x2c04>
    5c94:      	cmp	w28, w22
    5c98:      	b.ge	0x3270 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    5c9c:      	scvtf	d8, w28
    5ca0:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005ca0:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    5ca4:      	ldr	d1, [x8]
		0000000000005ca4:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    5ca8:      	stp	x26, x20, [sp, #0x20]
    5cac:      	str	x24, [sp, #0x18]
    5cb0:      	mov.16b	v0, v8
    5cb4:      	bl	0x5cb4 <_perry_fn_access_worker_ts__run$generic+0x2c18>
		0000000000005cb4:  ARM64_RELOC_BRANCH26	_js_dynamic_mod
    5cb8:      	mov.16b	v8, v0
    5cbc:      	ldp	x24, x26, [sp, #0x18]
    5cc0:      	ldr	x20, [sp, #0x28]
    5cc4:      	mov	x0, x20
    5cc8:      	ldr	w8, [x27]
    5ccc:      	cbz	w8, 0x5cd4 <_perry_fn_access_worker_ts__run$generic+0x2c38>
    5cd0:      	bl	0x5cd0 <_perry_fn_access_worker_ts__run$generic+0x2c34>
		0000000000005cd0:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    5cd4:      	mov	x10, x26
    5cd8:      	and	x8, x10, #0xffffffffffff
    5cdc:      	and	x13, x10, #0xffff000000000000
    5ce0:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005ce0:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    5ce4:      	ldr	x9, [x9]
		0000000000005ce4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    5ce8:      	ldr	x9, [x9]
    5cec:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
    5cf0:      	cmp	x13, x23
    5cf4:      	ccmp	x9, #0x0, #0x0, eq
    5cf8:      	mov	x9, #0x7ffffff00000     ; =140737487306752
    5cfc:      	ccmp	x11, x9, #0x2, eq
    5d00:      	b.hs	0x5d3c <_perry_fn_access_worker_ts__run$generic+0x2ca0>
    5d04:      	fcmp	d8, d12
    5d08:      	b.pl	0x5d3c <_perry_fn_access_worker_ts__run$generic+0x2ca0>
    5d0c:      	ldurb	w9, [x8, #-0x8]
    5d10:      	ldrb	w11, [x8, #0x8]
    5d14:      	fcmp	d8, #0.0
    5d18:      	ccmp	w9, #0xb, #0x0, ge
    5d1c:      	ccmp	w11, #0x9, #0x2, eq
    5d20:      	b.hs	0x5d3c <_perry_fn_access_worker_ts__run$generic+0x2ca0>
    5d24:      	fcvtzs	x9, d8
    5d28:      	scvtf	d0, x9
    5d2c:      	ldr	w12, [x8]
    5d30:      	fcmp	d8, d0
    5d34:      	ccmp	x9, x12, #0x2, eq
    5d38:      	b.lo	0x5dfc <_perry_fn_access_worker_ts__run$generic+0x2d60>
    5d3c:      	ldr	x11, [x19]
    5d40:      	cmp	x11, #0x0
    5d44:      	csel	x12, x19, x11, eq
    5d48:      	cmp	x13, x23
    5d4c:      	b.ne	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5d50:      	fcmp	d8, #0.0
    5d54:      	b.lt	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5d58:      	fcmp	d8, d10
    5d5c:      	b.pl	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5d60:      	mov	x9, #-0x20000000000     ; =-2199023255552
    5d64:      	add	x9, x8, x9
    5d68:      	lsr	x9, x9, #41
    5d6c:      	cmp	x9, #0x3f
    5d70:      	b.hs	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5d74:      	fcvtzs	x9, d8
    5d78:      	scvtf	d0, x9
    5d7c:      	fcmp	d8, d0
    5d80:      	b.ne	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5d84:      	ldursb	w13, [x8, #-0x7]
    5d88:      	tbnz	w13, #0x1f, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5d8c:      	ldurb	w13, [x8, #-0x8]
    5d90:      	cmp	w13, #0x9
    5d94:      	b.eq	0x5e94 <_perry_fn_access_worker_ts__run$generic+0x2df8>
    5d98:      	cmp	w13, #0x2
    5d9c:      	b.eq	0x5e44 <_perry_fn_access_worker_ts__run$generic+0x2da8>
    5da0:      	cmp	w13, #0x1
    5da4:      	b.ne	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5da8:      	ldr	w10, [x8]
    5dac:      	mov	x11, x8
    5db0:      	ldurh	w13, [x8, #-0x6]
    5db4:      	adrp	x12, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f64>
		0000000000005db4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    5db8:      	ldr	x12, [x12]
		0000000000005db8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    5dbc:      	ldrb	w12, [x12]
    5dc0:      	ldr	w8, [x8, #0x4]
    5dc4:      	cmp	x10, x8
    5dc8:      	b.hi	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5dcc:      	tbnz	w13, #0xa, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5dd0:      	cbnz	w12, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5dd4:      	cmp	x9, x10
    5dd8:      	b.hs	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5ddc:      	add	x8, x11, x9, lsl #3
    5de0:      	ldr	d0, [x8, #0x8]
    5de4:      	fmov	x8, d0
    5de8:      	mov	x9, #0x10               ; =16
    5dec:      	movk	x9, #0x7ffc, lsl #48
    5df0:      	cmp	x8, x9
    5df4:      	fcsel	d0, d11, d0, eq
    5df8:      	b	0x60e0 <_perry_fn_access_worker_ts__run$generic+0x3044>
    5dfc:      	add	x8, x8, #0x10
    5e00:      	cmp	w11, #0x3
    5e04:      	b.le	0x5e28 <_perry_fn_access_worker_ts__run$generic+0x2d8c>
    5e08:      	cmp	w11, #0x5
    5e0c:      	b.gt	0x5ee0 <_perry_fn_access_worker_ts__run$generic+0x2e44>
    5e10:      	cmp	w11, #0x4
    5e14:      	b.eq	0x5f78 <_perry_fn_access_worker_ts__run$generic+0x2edc>
    5e18:      	cmp	w11, #0x5
    5e1c:      	b.ne	0x5f6c <_perry_fn_access_worker_ts__run$generic+0x2ed0>
    5e20:      	ldr	s0, [x8, x9, lsl #2]
    5e24:      	b	0x5f70 <_perry_fn_access_worker_ts__run$generic+0x2ed4>
    5e28:      	cbz	w11, 0x5f64 <_perry_fn_access_worker_ts__run$generic+0x2ec8>
    5e2c:      	cmp	w11, #0x2
    5e30:      	b.eq	0x5f8c <_perry_fn_access_worker_ts__run$generic+0x2ef0>
    5e34:      	cmp	w11, #0x3
    5e38:      	b.ne	0x5f6c <_perry_fn_access_worker_ts__run$generic+0x2ed0>
    5e3c:      	ldr	h0, [x8, x9, lsl #1]
    5e40:      	b	0x5f70 <_perry_fn_access_worker_ts__run$generic+0x2ed4>
    5e44:      	ldr	x10, [x8, #0x8]
    5e48:      	cbz	x10, 0x5ef8 <_perry_fn_access_worker_ts__run$generic+0x2e5c>
    5e4c:      	ldr	x13, [x10, #0x60]
    5e50:      	cbz	x13, 0x5ef8 <_perry_fn_access_worker_ts__run$generic+0x2e5c>
    5e54:      	ldurb	w8, [x13, #-0x8]
    5e58:      	cmp	w8, #0x1
    5e5c:      	b.ne	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5e60:      	ldursb	w8, [x13, #-0x7]
    5e64:      	tbnz	w8, #0x1f, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5e68:      	ldr	w8, [x13]
    5e6c:      	cmp	x9, x8
    5e70:      	b.hs	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5e74:      	add	x8, x13, x9, lsl #3
    5e78:      	ldr	d0, [x8, #0x8]
    5e7c:      	fmov	x8, d0
    5e80:      	mov	x9, #0x10               ; =16
    5e84:      	movk	x9, #0x7ffc, lsl #48
    5e88:      	cmp	x8, x9
    5e8c:      	b.eq	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5e90:      	b	0x60e0 <_perry_fn_access_worker_ts__run$generic+0x3044>
    5e94:      	ldr	w12, [x8, #0x4]
    5e98:      	ldr	x11, [x8, #0x20]
    5e9c:      	ldurh	w13, [x8, #-0x6]
    5ea0:      	tst	w13, #0xc00
    5ea4:      	mov	w13, #0x5841            ; =22593
    5ea8:      	movk	w13, #0x4c5a, lsl #16
    5eac:      	ccmp	w12, w13, #0x0, eq
    5eb0:      	cset	w12, eq
    5eb4:      	cbz	x11, 0x5f2c <_perry_fn_access_worker_ts__run$generic+0x2e90>
    5eb8:      	tbz	w12, #0x0, 0x5f2c <_perry_fn_access_worker_ts__run$generic+0x2e90>
    5ebc:      	ldurb	w10, [x11, #-0x8]
    5ec0:      	cmp	w10, #0x1
    5ec4:      	b.ne	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5ec8:      	ldursb	w10, [x11, #-0x7]
    5ecc:      	tbnz	w10, #0x1f, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5ed0:      	ldr	w10, [x11]
    5ed4:      	str	w10, [x8]
    5ed8:      	mov	x8, x11
    5edc:      	b	0x5db0 <_perry_fn_access_worker_ts__run$generic+0x2d14>
    5ee0:      	cmp	w11, #0x6
    5ee4:      	b.eq	0x5f80 <_perry_fn_access_worker_ts__run$generic+0x2ee4>
    5ee8:      	cmp	w11, #0x7
    5eec:      	b.ne	0x5f6c <_perry_fn_access_worker_ts__run$generic+0x2ed0>
    5ef0:      	ldr	d0, [x8, x9, lsl #3]
    5ef4:      	b	0x60e0 <_perry_fn_access_worker_ts__run$generic+0x3044>
    5ef8:      	ldr	x12, [x12]
    5efc:      	cbz	x12, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5f00:      	tbnz	x12, #0x3f, 0x5f98 <_perry_fn_access_worker_ts__run$generic+0x2efc>
    5f04:      	ldp	w14, w13, [x8]
    5f08:      	orr	x13, x13, x14, lsl #32
    5f0c:      	cmp	x13, x12
    5f10:      	b.ne	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5f14:      	ldp	x14, x12, [x11, #0x8]
    5f18:      	ldp	x13, x11, [x11, #0x18]
    5f1c:      	cmp	x14, x11
    5f20:      	b.lo	0x5fb8 <_perry_fn_access_worker_ts__run$generic+0x2f1c>
    5f24:      	cbz	x10, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5f28:      	b	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
    5f2c:      	cmp	x11, #0x0
    5f30:      	ldr	w14, [x8]
    5f34:      	ldp	x11, x13, [x8, #0x28]
    5f38:      	ccmp	x9, x14, #0x2, eq
    5f3c:      	ccmp	x11, #0x0, #0x4, lo
    5f40:      	ccmp	x13, #0x0, #0x4, ne
    5f44:      	csel	w12, wzr, w12, eq
    5f48:      	tbz	w12, #0x0, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5f4c:      	lsr	x12, x9, #6
    5f50:      	ldr	x12, [x13, x12, lsl #3]
    5f54:      	lsr	x12, x12, x9
    5f58:      	tbz	w12, #0x0, 0x5fc4 <_perry_fn_access_worker_ts__run$generic+0x2f28>
    5f5c:      	ldr	d0, [x11, x9, lsl #3]
    5f60:      	b	0x60e0 <_perry_fn_access_worker_ts__run$generic+0x3044>
    5f64:      	ldrsb	w8, [x8, x9]
    5f68:      	b	0x5f90 <_perry_fn_access_worker_ts__run$generic+0x2ef4>
    5f6c:      	ldr	b0, [x8, x9]
    5f70:      	ucvtf	d0, d0
    5f74:      	b	0x60e0 <_perry_fn_access_worker_ts__run$generic+0x3044>
    5f78:      	ldr	w8, [x8, x9, lsl #2]
    5f7c:      	b	0x5f90 <_perry_fn_access_worker_ts__run$generic+0x2ef4>
    5f80:      	ldr	s0, [x8, x9, lsl #2]
    5f84:      	fcvt	d0, s0
    5f88:      	b	0x60e0 <_perry_fn_access_worker_ts__run$generic+0x3044>
    5f8c:      	ldrsh	w8, [x8, x9, lsl #1]
    5f90:      	scvtf	d0, w8
    5f94:      	b	0x60e0 <_perry_fn_access_worker_ts__run$generic+0x3044>
    5f98:      	cbz	x10, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5f9c:      	ldr	x13, [x10, #0x30]
    5fa0:      	cmp	x13, x12
    5fa4:      	b.ne	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5fa8:      	ldp	x14, x12, [x11, #0x8]
    5fac:      	ldp	x13, x11, [x11, #0x18]
    5fb0:      	cmp	x14, x11
    5fb4:      	b.hs	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
    5fb8:      	add	x14, x8, x14, lsl #3
    5fbc:      	add	x14, x14, #0x10
    5fc0:      	b	0x602c <_perry_fn_access_worker_ts__run$generic+0x2f90>
    5fc4:      	ldr	x8, [x8, #0x50]
    5fc8:      	mov	w12, #0x6903            ; =26883
    5fcc:      	movk	w12, #0x64, lsl #16
    5fd0:      	cmp	x8, x12
    5fd4:      	b.eq	0x5fdc <_perry_fn_access_worker_ts__run$generic+0x2f40>
    5fd8:      	cbnz	x8, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    5fdc:      	mov	w12, #0x6903            ; =26883
    5fe0:      	movk	w12, #0x64, lsl #16
    5fe4:      	cmp	x8, x12
    5fe8:      	b.ne	0x6094 <_perry_fn_access_worker_ts__run$generic+0x2ff8>
    5fec:      	ldr	x8, [x11, x9, lsl #3]
    5ff0:      	cbz	x8, 0x6094 <_perry_fn_access_worker_ts__run$generic+0x2ff8>
    5ff4:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    5ff8:      	cmp	x8, x9
    5ffc:      	csel	x8, xzr, x8, eq
    6000:      	fmov	d1, x8
    6004:      	b	0x62d8 <_perry_fn_access_worker_ts__run$generic+0x323c>
    6008:      	ldr	x16, [x10, #0x20]
    600c:      	cmp	x16, #0x0
    6010:      	csel	x15, x16, x10, ne
    6014:      	cbz	x16, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    6018:      	ldr	w16, [x15]
    601c:      	cmp	x14, x16
    6020:      	b.hs	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    6024:      	add	x14, x15, x14, lsl #3
    6028:      	add	x14, x14, #0x8
    602c:      	ldr	d0, [x14]
    6030:      	fcmp	d8, d0
    6034:      	ccmp	x13, x9, #0x0, mi
    6038:      	cset	w13, hi
    603c:      	add	x9, x12, x9
    6040:      	cmp	x9, x11
    6044:      	ccmp	w13, #0x0, #0x4, lo
    6048:      	b.ne	0x6088 <_perry_fn_access_worker_ts__run$generic+0x2fec>
    604c:      	cbz	x10, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    6050:      	cmp	x9, x11
    6054:      	b.lo	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    6058:      	eor	w8, w13, #0x1
    605c:      	tbnz	w8, #0x0, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    6060:      	ldr	x11, [x10, #0x20]
    6064:      	cmp	x11, #0x0
    6068:      	csel	x8, x11, x10, ne
    606c:      	cbz	x11, 0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    6070:      	ldr	w10, [x8]
    6074:      	cmp	x9, x10
    6078:      	b.hs	0x60c4 <_perry_fn_access_worker_ts__run$generic+0x3028>
    607c:      	add	x8, x8, x9, lsl #3
    6080:      	ldr	d0, [x8, #0x8]
    6084:      	b	0x60e0 <_perry_fn_access_worker_ts__run$generic+0x3044>
    6088:      	add	x8, x8, x9, lsl #3
    608c:      	ldr	d0, [x8, #0x10]
    6090:      	b	0x60e0 <_perry_fn_access_worker_ts__run$generic+0x3044>
    6094:      	fmov	d0, x10
    6098:      	mov.16b	v1, v8
    609c:      	adrp	x0, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		000000000000609c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    60a0:      	add	x0, x0, #0x0
		00000000000060a0:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    60a4:      	mov	w1, #0x2                ; =2
    60a8:      	bl	0x60a8 <_perry_fn_access_worker_ts__run$generic+0x300c>
		00000000000060a8:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    60ac:      	mov.16b	v1, v0
    60b0:      	fmov	x8, d1
    60b4:      	mov	x9, #0x10               ; =16
    60b8:      	movk	x9, #0x7ffc, lsl #48
    60bc:      	cmp	x8, x9
    60c0:      	b.ne	0x62d8 <_perry_fn_access_worker_ts__run$generic+0x323c>
    60c4:      	fmov	d0, x26
    60c8:      	str	x20, [sp, #0x28]
    60cc:      	mov.16b	v1, v8
    60d0:      	mov	x0, x19
    60d4:      	bl	0x60d4 <_perry_fn_access_worker_ts__run$generic+0x3038>
		00000000000060d4:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    60d8:      	ldp	x26, x20, [sp, #0x20]
    60dc:      	ldr	x24, [sp, #0x18]
    60e0:      	fmov	x8, d0
    60e4:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    60e8:      	and	x9, x8, x9
    60ec:      	cmp	x9, x23
    60f0:      	b.ne	0x615c <_perry_fn_access_worker_ts__run$generic+0x30c0>
    60f4:      	and	x0, x8, #0xffffffffffff
    60f8:      	lsr	x8, x0, #20
    60fc:      	cbz	x8, 0x62b0 <_perry_fn_access_worker_ts__run$generic+0x3214>
    6100:      	ldurb	w9, [x0, #-0x8]
    6104:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006104:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__35
    6108:      	ldr	x8, [x8]
		0000000000006108:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__35
    610c:      	cbz	x8, 0x61cc <_perry_fn_access_worker_ts__run$generic+0x3130>
    6110:      	ldurh	w10, [x0, #-0x6]
    6114:      	and	w10, w10, #0x800
    6118:      	cmp	w9, #0x2
    611c:      	ccmp	w10, #0x0, #0x0, eq
    6120:      	b.ne	0x61cc <_perry_fn_access_worker_ts__run$generic+0x3130>
    6124:      	ldr	w10, [x0, #0x4]
    6128:      	orr	x9, x10, #0x4000000000000000
    612c:      	ldr	x11, [x8]
    6130:      	cmp	w10, #0x0
    6134:      	ccmp	x9, x11, #0x0, ne
    6138:      	b.eq	0x6204 <_perry_fn_access_worker_ts__run$generic+0x3168>
    613c:      	ldr	x11, [x8, #0x10]
    6140:      	cbz	x11, 0x6228 <_perry_fn_access_worker_ts__run$generic+0x318c>
    6144:      	ldr	x12, [x0, #0x8]
    6148:      	cbz	x12, 0x6228 <_perry_fn_access_worker_ts__run$generic+0x318c>
    614c:      	ldr	x12, [x12, #0x30]
    6150:      	cmp	x12, x11
    6154:      	b.eq	0x61f4 <_perry_fn_access_worker_ts__run$generic+0x3158>
    6158:      	b	0x6228 <_perry_fn_access_worker_ts__run$generic+0x318c>
    615c:      	lsr	x9, x8, #48
    6160:      	mov	w10, #0x7ff9            ; =32761
    6164:      	cmp	x9, x10
    6168:      	b.eq	0x61b0 <_perry_fn_access_worker_ts__run$generic+0x3114>
    616c:      	mov	w10, #0x7ffe            ; =32766
    6170:      	cmp	w9, w10
    6174:      	b.ne	0x61a0 <_perry_fn_access_worker_ts__run$generic+0x3104>
    6178:      	adrp	x9, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006178:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    617c:      	ldr	x9, [x9]
		000000000000617c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    6180:      	str	x20, [sp, #0x28]
    6184:      	and	x2, x9, #0xffffffffffff
    6188:      	mov	x0, #0x22               ; =34
    618c:      	movk	x0, #0xddae, lsl #32
    6190:      	movk	x0, #0x5556, lsl #48
    6194:      	mov	x1, x8
    6198:      	bl	0x6198 <_perry_fn_access_worker_ts__run$generic+0x30fc>
		0000000000006198:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    619c:      	b	0x62cc <_perry_fn_access_worker_ts__run$generic+0x3230>
    61a0:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    61a4:      	add	x9, x8, x9
    61a8:      	cmp	x9, #0x2
    61ac:      	b.lo	0x6384 <_perry_fn_access_worker_ts__run$generic+0x32e8>
    61b0:      	adrp	x9, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		00000000000061b0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    61b4:      	ldr	x9, [x9]
		00000000000061b4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    61b8:      	str	x20, [sp, #0x28]
    61bc:      	and	x1, x9, #0xffffffffffff
    61c0:      	mov	x0, x8
    61c4:      	bl	0x61c4 <_perry_fn_access_worker_ts__run$generic+0x3128>
		00000000000061c4:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    61c8:      	b	0x62cc <_perry_fn_access_worker_ts__run$generic+0x3230>
    61cc:      	cmp	w9, #0x2
    61d0:      	ccmp	x8, #0x0, #0x4, eq
    61d4:      	b.eq	0x62b0 <_perry_fn_access_worker_ts__run$generic+0x3214>
    61d8:      	ldr	x9, [x8, #0x10]
    61dc:      	cbz	x9, 0x62b0 <_perry_fn_access_worker_ts__run$generic+0x3214>
    61e0:      	ldr	x10, [x0, #0x8]
    61e4:      	cbz	x10, 0x62b0 <_perry_fn_access_worker_ts__run$generic+0x3214>
    61e8:      	ldr	x10, [x10, #0x30]
    61ec:      	cmp	x10, x9
    61f0:      	b.ne	0x62b0 <_perry_fn_access_worker_ts__run$generic+0x3214>
    61f4:      	ldr	x8, [x8, #0x8]
    61f8:      	add	x8, x0, x8, lsl #3
    61fc:      	ldr	d1, [x8, #0x10]
    6200:      	b	0x62d8 <_perry_fn_access_worker_ts__run$generic+0x323c>
    6204:      	ldr	x2, [x8, #0x8]
    6208:      	tbnz	w2, #0x1e, 0x6364 <_perry_fn_access_worker_ts__run$generic+0x32c8>
    620c:      	add	x11, x0, x2, lsl #3
    6210:      	ldr	d1, [x11, #0x10]
    6214:      	fmov	x11, d1
    6218:      	mov	x12, #0x10              ; =16
    621c:      	movk	x12, #0x7ffc, lsl #48
    6220:      	cmp	x11, x12
    6224:      	b.ne	0x62d8 <_perry_fn_access_worker_ts__run$generic+0x323c>
    6228:      	ldr	x11, [x8, #0x18]
    622c:      	cmp	x11, #0x0
    6230:      	b.le	0x62b0 <_perry_fn_access_worker_ts__run$generic+0x3214>
    6234:      	ldr	x11, [x8, #0x20]
    6238:      	ldr	x12, [x8, #0x30]
    623c:      	ldr	x13, [x8, #0x40]
    6240:      	cmp	x13, x9
    6244:      	ldr	x14, [x8, #0x50]
    6248:      	ccmp	x14, x9, #0x4, ne
    624c:      	ccmp	x12, x9, #0x4, ne
    6250:      	ccmp	x11, x9, #0x4, ne
    6254:      	cset	w15, eq
    6258:      	cmp	w10, #0x0
    625c:      	ccmp	w15, #0x0, #0x4, ne
    6260:      	b.eq	0x62b0 <_perry_fn_access_worker_ts__run$generic+0x3214>
    6264:      	ldr	x10, [x8, #0x48]
    6268:      	ldr	x15, [x8, #0x58]
    626c:      	cmp	x14, x9
    6270:      	csel	x14, x15, xzr, eq
    6274:      	cmp	x13, x9
    6278:      	csel	x10, x10, x14, eq
    627c:      	ldr	x13, [x8, #0x28]
    6280:      	ldr	x8, [x8, #0x38]
    6284:      	cmp	x12, x9
    6288:      	csel	x8, x8, x10, eq
    628c:      	cmp	x11, x9
    6290:      	csel	x8, x13, x8, eq
    6294:      	add	x8, x0, x8, lsl #3
    6298:      	ldr	d1, [x8, #0x10]
    629c:      	fmov	x8, d1
    62a0:      	mov	x9, #0x10               ; =16
    62a4:      	movk	x9, #0x7ffc, lsl #48
    62a8:      	cmp	x8, x9
    62ac:      	b.ne	0x62d8 <_perry_fn_access_worker_ts__run$generic+0x323c>
    62b0:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		00000000000062b0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    62b4:      	ldr	x8, [x8]
		00000000000062b4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    62b8:      	str	x20, [sp, #0x28]
    62bc:      	and	x1, x8, #0xffffffffffff
    62c0:      	adrp	x2, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		00000000000062c0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__35
    62c4:      	add	x2, x2, #0x0
		00000000000062c4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__35
    62c8:      	bl	0x62c8 <_perry_fn_access_worker_ts__run$generic+0x322c>
		00000000000062c8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    62cc:      	mov.16b	v1, v0
    62d0:      	ldp	x24, x26, [sp, #0x18]
    62d4:      	ldr	x20, [sp, #0x28]
    62d8:      	fmov	d0, x20
    62dc:      	and	x9, x20, #0xffff000000000000
    62e0:      	fmov	x8, d1
    62e4:      	and	x10, x8, #0xffff000000000000
    62e8:      	cmp	x8, x21
    62ec:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    62f0:      	ccmp	x10, x8, #0x2, hs
    62f4:      	cset	w8, hi
    62f8:      	mov	x10, #0x1               ; =1
    62fc:      	movk	x10, #0x7fff, lsl #48
    6300:      	cmp	x9, x10
    6304:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    6308:      	ccmp	x20, x9, #0x0, lo
    630c:      	b.hi	0x631c <_perry_fn_access_worker_ts__run$generic+0x3280>
    6310:      	tbz	w8, #0x0, 0x631c <_perry_fn_access_worker_ts__run$generic+0x3280>
    6314:      	fadd	d0, d1, d0
    6318:      	b	0x6324 <_perry_fn_access_worker_ts__run$generic+0x3288>
    631c:      	bl	0x631c <_perry_fn_access_worker_ts__run$generic+0x3280>
		000000000000631c:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    6320:      	ldp	x24, x26, [sp, #0x18]
    6324:      	fmov	x20, d0
    6328:      	mov	x0, x20
    632c:      	ldr	w8, [x27]
    6330:      	cbz	w8, 0x6338 <_perry_fn_access_worker_ts__run$generic+0x329c>
    6334:      	bl	0x6334 <_perry_fn_access_worker_ts__run$generic+0x3298>
		0000000000006334:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6338:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006338:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    633c:      	ldr	x8, [x8]
		000000000000633c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    6340:      	ldr	w8, [x8]
    6344:      	cbz	w8, 0x6358 <_perry_fn_access_worker_ts__run$generic+0x32bc>
    6348:      	str	x20, [sp, #0x28]
    634c:      	bl	0x634c <_perry_fn_access_worker_ts__run$generic+0x32b0>
		000000000000634c:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    6350:      	ldp	x26, x20, [sp, #0x20]
    6354:      	ldr	x24, [sp, #0x18]
    6358:      	add	w28, w28, #0x1
    635c:      	tbz	w25, #0x0, 0x5ba0 <_perry_fn_access_worker_ts__run$generic+0x2b04>
    6360:      	b	0x5c94 <_perry_fn_access_worker_ts__run$generic+0x2bf8>
    6364:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006364:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    6368:      	ldr	x8, [x8]
		0000000000006368:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    636c:      	str	x20, [sp, #0x28]
    6370:      	and	x1, x8, #0xffffffffffff
    6374:      	adrp	x3, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006374:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__35
    6378:      	add	x3, x3, #0x0
		0000000000006378:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__35
    637c:      	bl	0x637c <_perry_fn_access_worker_ts__run$generic+0x32e0>
		000000000000637c:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    6380:      	b	0x62cc <_perry_fn_access_worker_ts__run$generic+0x3230>
    6384:      	mov	x9, #0x10               ; =16
    6388:      	movk	x9, #0x7ffc, lsl #48
    638c:      	sub	x9, x9, #0xe
    6390:      	b	0x6398 <_perry_fn_access_worker_ts__run$generic+0x32fc>
    6394:      	sub	x9, x25, #0xe
    6398:      	cmp	x8, x9
    639c:      	cset	w0, eq
    63a0:      	adrp	x1, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		00000000000063a0:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    63a4:      	add	x1, x1, #0x0
		00000000000063a4:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    63a8:      	mov	w2, #0x2                ; =2
    63ac:      	bl	0x63ac <_perry_fn_access_worker_ts__run$generic+0x3310>
		00000000000063ac:  ARM64_RELOC_BRANCH26	_js_throw_type_error_property_access
    63b0:      	brk	#0x1
    63b4:      	mov	x9, #0x10               ; =16
    63b8:      	movk	x9, #0x7ffc, lsl #48
    63bc:      	sub	x9, x9, #0xe
    63c0:      	cmp	x8, x9
    63c4:      	cset	w0, eq
    63c8:      	adrp	x1, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		00000000000063c8:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.4.bytes
    63cc:      	add	x1, x1, #0x0
		00000000000063cc:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.4.bytes
    63d0:      	mov	w2, #0x4                ; =4
    63d4:      	b	0x63ac <_perry_fn_access_worker_ts__run$generic+0x3310>
    63d8:      	mov	x9, #0x10               ; =16
    63dc:      	movk	x9, #0x7ffc, lsl #48
    63e0:      	sub	x9, x9, #0xe
    63e4:      	cmp	x8, x9
    63e8:      	cset	w0, eq
    63ec:      	adrp	x1, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		00000000000063ec:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.5.bytes
    63f0:      	add	x1, x1, #0x0
		00000000000063f0:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.5.bytes
    63f4:      	mov	w2, #0x6                ; =6
    63f8:      	b	0x63ac <_perry_fn_access_worker_ts__run$generic+0x3310>

00000000000063fc <_perry_fn_access_worker_ts__run>:
    63fc:      	fmov	x8, d1
    6400:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    6404:      	cmp	x8, x9
    6408:      	b.lt	0x6420 <_perry_fn_access_worker_ts__run+0x24>
    640c:      	and	x8, x8, #0xffffffff00000000
    6410:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    6414:      	cmp	x8, x9
    6418:      	b.eq	0x6420 <_perry_fn_access_worker_ts__run+0x24>
    641c:      	b	0x641c <_perry_fn_access_worker_ts__run+0x20>
		000000000000641c:  ARM64_RELOC_BRANCH26	_perry_fn_access_worker_ts__run$generic
    6420:      	b	0x6420 <_perry_fn_access_worker_ts__run+0x24>
		0000000000006420:  ARM64_RELOC_BRANCH26	_perry_fn_access_worker_ts__run$spec_b_b

0000000000006424 <___perry_wrap_perry_fn_access_worker_ts__run>:
    6424:      	b	0x6424 <___perry_wrap_perry_fn_access_worker_ts__run>
		0000000000006424:  ARM64_RELOC_BRANCH26	_perry_fn_access_worker_ts__run

0000000000006428 <_access_worker_ts__init>:
    6428:      	ret

000000000000642c <_main>:
    642c:      	sub	sp, sp, #0xa0
    6430:      	stp	d11, d10, [sp, #0x40]
    6434:      	stp	d9, d8, [sp, #0x50]
    6438:      	stp	x24, x23, [sp, #0x60]
    643c:      	stp	x22, x21, [sp, #0x70]
    6440:      	stp	x20, x19, [sp, #0x80]
    6444:      	stp	x29, x30, [sp, #0x90]
    6448:      	add	x29, sp, #0x90
    644c:      	mov	w19, #0x2401            ; =9217
    6450:      	movk	w19, #0xf4, lsl #16
    6454:      	adrp	x0, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006454:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.0
    6458:      	add	x0, x0, #0x0
		0000000000006458:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.0
    645c:      	mov	w1, #0x5c               ; =92
    6460:      	bl	0x6460 <_main+0x34>
		0000000000006460:  ARM64_RELOC_BRANCH26	_js_set_process_entry_path
    6464:      	bl	0x6464 <_main+0x38>
		0000000000006464:  ARM64_RELOC_BRANCH26	_js_gc_init
    6468:      	mov	w0, #0x1                ; =1
    646c:      	bl	0x646c <_main+0x40>
		000000000000646c:  ARM64_RELOC_BRANCH26	_js_gc_write_barriers_emitted
    6470:      	bl	0x6470 <_main+0x44>
		0000000000006470:  ARM64_RELOC_BRANCH26	_perry_macos_bundle_chdir
    6474:      	bl	0x6474 <_main+0x48>
		0000000000006474:  ARM64_RELOC_BRANCH26	___perry_init_strings_access_worker_ts
    6478:      	adrp	x0, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006478:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__1
    647c:      	add	x0, x0, #0x0
		000000000000647c:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
    6480:      	bl	0x6480 <_main+0x54>
		0000000000006480:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    6484:      	adrp	x0, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006484:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    6488:      	add	x0, x0, #0x0
		0000000000006488:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    648c:      	bl	0x648c <_main+0x60>
		000000000000648c:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    6490:      	bl	0x6490 <_main+0x64>
		0000000000006490:  ARM64_RELOC_BRANCH26	_js_mark_entry_module_esm
    6494:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006494:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.6.handle
    6498:      	ldr	d0, [x8]
		0000000000006498:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.6.handle
    649c:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		000000000000649c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.7.handle
    64a0:      	ldr	d1, [x8]
		00000000000064a0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.7.handle
    64a4:      	bl	0x64a4 <_main+0x78>
		00000000000064a4:  ARM64_RELOC_BRANCH26	_js_native_module_named_esm_export_value
    64a8:      	bl	0x64a8 <_main+0x7c>
		00000000000064a8:  ARM64_RELOC_BRANCH26	_js_process_argv
    64ac:      	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
    64b0:      	orr	x8, x0, x8
    64b4:      	and	x9, x0, #0xffffffffffff
    64b8:      	adrp	x20, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		00000000000064b8:  ARM64_RELOC_PAGE21	lCPI5_0
    64bc:      	cmp	x9, #0x100, lsl #12     ; =0x100000
    64c0:      	b.lo	0x6560 <_main+0x134>
    64c4:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    64c8:      	cmp	x8, x10
    64cc:      	b.hs	0x6560 <_main+0x134>
    64d0:      	ldurb	w10, [x9, #-0x8]
    64d4:      	ldursb	w11, [x9, #-0x7]
    64d8:      	cmp	w11, #0x0
    64dc:      	ccmp	w10, #0x1, #0x0, mi
    64e0:      	ldr	x10, [x9]
    64e4:      	csel	x9, x10, x9, eq
    64e8:      	sub	x10, x9, #0x100, lsl #12 ; =0x100000
    64ec:      	mov	x11, #-0x100001         ; =-1048577
    64f0:      	movk	x11, #0x0, lsl #48
    64f4:      	cmp	x10, x11
    64f8:      	b.hi	0x6560 <_main+0x134>
    64fc:      	ldurb	w13, [x9, #-0x8]
    6500:      	ldursb	w12, [x9, #-0x7]
    6504:      	ldurh	w10, [x9, #-0x6]
    6508:      	adrp	x11, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006508:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    650c:      	ldr	x11, [x11]
		000000000000650c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    6510:      	ldrb	w14, [x11]
    6514:      	ldp	w11, w15, [x9]
    6518:      	cmp	w11, w15
    651c:      	ccmp	w15, w19, #0x2, ls
    6520:      	ccmp	w11, w19, #0x2, lo
    6524:      	ccmp	w14, #0x0, #0x0, lo
    6528:      	ccmp	w13, #0x1, #0x0, eq
    652c:      	b.ne	0x6560 <_main+0x134>
    6530:      	tbnz	w12, #0x1f, 0x6560 <_main+0x134>
    6534:      	tbnz	w10, #0xa, 0x6560 <_main+0x134>
    6538:      	cmp	w11, #0x2
    653c:      	b.ls	0x6998 <_main+0x56c>
    6540:      	ldr	d0, [x9, #0x18]
    6544:      	fmov	x8, d0
    6548:      	mov	x9, #0x10               ; =16
    654c:      	movk	x9, #0x7ffc, lsl #48
    6550:      	cmp	x8, x9
    6554:      	ldr	d1, [x20]
		0000000000006554:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    6558:      	fcsel	d0, d1, d0, eq
    655c:      	b	0x6578 <_main+0x14c>
    6560:      	fmov	d0, x8
    6564:      	mov	x0, #0x24               ; =36
    6568:      	movk	x0, #0xddae, lsl #32
    656c:      	movk	x0, #0x5556, lsl #48
    6570:      	fmov	d1, #2.00000000
    6574:      	bl	0x6574 <_main+0x148>
		0000000000006574:  ARM64_RELOC_BRANCH26	_js_typed_feedback_array_index_get_fallback_boxed
    6578:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006578:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.8.handle
    657c:      	ldr	d1, [x8]
		000000000000657c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.8.handle
    6580:      	bl	0x6580 <_main+0x154>
		0000000000006580:  ARM64_RELOC_BRANCH26	_js_fs_read_file_dispatch
    6584:      	fmov	x0, d0
    6588:      	mov	x21, x0
    658c:      	adrp	x22, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		000000000000658c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    6590:      	ldr	x22, [x22]
		0000000000006590:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    6594:      	ldr	w8, [x22]
    6598:      	cbz	w8, 0x65a0 <_main+0x174>
    659c:      	bl	0x659c <_main+0x170>
		000000000000659c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    65a0:      	str	x21, [sp, #0x38]
    65a4:      	bl	0x65a4 <_main+0x178>
		00000000000065a4:  ARM64_RELOC_BRANCH26	_js_process_argv
    65a8:      	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
    65ac:      	orr	x8, x0, x8
    65b0:      	and	x9, x0, #0xffffffffffff
    65b4:      	cmp	x9, #0x100, lsl #12     ; =0x100000
    65b8:      	b.lo	0x6658 <_main+0x22c>
    65bc:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    65c0:      	cmp	x8, x10
    65c4:      	b.hs	0x6658 <_main+0x22c>
    65c8:      	ldurb	w10, [x9, #-0x8]
    65cc:      	ldursb	w11, [x9, #-0x7]
    65d0:      	cmp	w11, #0x0
    65d4:      	ccmp	w10, #0x1, #0x0, mi
    65d8:      	ldr	x10, [x9]
    65dc:      	csel	x9, x10, x9, eq
    65e0:      	sub	x10, x9, #0x100, lsl #12 ; =0x100000
    65e4:      	mov	x11, #-0x100001         ; =-1048577
    65e8:      	movk	x11, #0x0, lsl #48
    65ec:      	cmp	x10, x11
    65f0:      	b.hi	0x6658 <_main+0x22c>
    65f4:      	ldurb	w13, [x9, #-0x8]
    65f8:      	ldursb	w12, [x9, #-0x7]
    65fc:      	ldurh	w10, [x9, #-0x6]
    6600:      	adrp	x11, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006600:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    6604:      	ldr	x11, [x11]
		0000000000006604:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    6608:      	ldrb	w14, [x11]
    660c:      	ldp	w11, w15, [x9]
    6610:      	cmp	w11, w15
    6614:      	ccmp	w15, w19, #0x2, ls
    6618:      	ccmp	w11, w19, #0x2, lo
    661c:      	ccmp	w14, #0x0, #0x0, lo
    6620:      	ccmp	w13, #0x1, #0x0, eq
    6624:      	b.ne	0x6658 <_main+0x22c>
    6628:      	tbnz	w12, #0x1f, 0x6658 <_main+0x22c>
    662c:      	tbnz	w10, #0xa, 0x6658 <_main+0x22c>
    6630:      	cmp	w11, #0x3
    6634:      	b.ls	0x69a0 <_main+0x574>
    6638:      	ldr	d0, [x9, #0x20]
    663c:      	fmov	x8, d0
    6640:      	mov	x9, #0x10               ; =16
    6644:      	movk	x9, #0x7ffc, lsl #48
    6648:      	cmp	x8, x9
    664c:      	ldr	d1, [x20]
		000000000000664c:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    6650:      	fcsel	d0, d1, d0, eq
    6654:      	b	0x6670 <_main+0x244>
    6658:      	fmov	d0, x8
    665c:      	mov	x0, #0x25               ; =37
    6660:      	movk	x0, #0xddae, lsl #32
    6664:      	movk	x0, #0x5556, lsl #48
    6668:      	fmov	d1, #3.00000000
    666c:      	bl	0x666c <_main+0x240>
		000000000000666c:  ARM64_RELOC_BRANCH26	_js_typed_feedback_array_index_get_fallback_boxed
    6670:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006670:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__1
    6674:      	str	d0, [x8]
		0000000000006674:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
    6678:      	fmov	x0, d0
    667c:      	bl	0x667c <_main+0x250>
		000000000000667c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6680:      	bl	0x6680 <_main+0x254>
		0000000000006680:  ARM64_RELOC_BRANCH26	_js_process_argv
    6684:      	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
    6688:      	orr	x8, x0, x8
    668c:      	and	x9, x0, #0xffffffffffff
    6690:      	cmp	x9, #0x100, lsl #12     ; =0x100000
    6694:      	b.lo	0x6740 <_main+0x314>
    6698:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    669c:      	cmp	x8, x10
    66a0:      	b.hs	0x6740 <_main+0x314>
    66a4:      	ldurb	w10, [x9, #-0x8]
    66a8:      	ldursb	w11, [x9, #-0x7]
    66ac:      	cmp	w11, #0x0
    66b0:      	ccmp	w10, #0x1, #0x0, mi
    66b4:      	ldr	x10, [x9]
    66b8:      	csel	x9, x10, x9, eq
    66bc:      	sub	x10, x9, #0x100, lsl #12 ; =0x100000
    66c0:      	mov	x11, #-0x100001         ; =-1048577
    66c4:      	movk	x11, #0x0, lsl #48
    66c8:      	cmp	x10, x11
    66cc:      	b.hi	0x6740 <_main+0x314>
    66d0:      	ldurb	w13, [x9, #-0x8]
    66d4:      	ldursb	w12, [x9, #-0x7]
    66d8:      	ldurh	w10, [x9, #-0x6]
    66dc:      	adrp	x11, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		00000000000066dc:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    66e0:      	ldr	x11, [x11]
		00000000000066e0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    66e4:      	ldrb	w14, [x11]
    66e8:      	ldp	w11, w15, [x9]
    66ec:      	cmp	w11, w15
    66f0:      	b.hi	0x6740 <_main+0x314>
    66f4:      	cmp	w15, w19
    66f8:      	b.hs	0x6740 <_main+0x314>
    66fc:      	cmp	w11, w19
    6700:      	b.hs	0x6740 <_main+0x314>
    6704:      	cbnz	w14, 0x6740 <_main+0x314>
    6708:      	cmp	w13, #0x1
    670c:      	b.ne	0x6740 <_main+0x314>
    6710:      	tbnz	w12, #0x1f, 0x6740 <_main+0x314>
    6714:      	tbnz	w10, #0xa, 0x6740 <_main+0x314>
    6718:      	cmp	w11, #0x4
    671c:      	b.ls	0x6988 <_main+0x55c>
    6720:      	ldr	d0, [x9, #0x28]
    6724:      	fmov	x8, d0
    6728:      	mov	x9, #0x10               ; =16
    672c:      	movk	x9, #0x7ffc, lsl #48
    6730:      	cmp	x8, x9
    6734:      	ldr	d1, [x20]
		0000000000006734:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    6738:      	fcsel	d0, d1, d0, eq
    673c:      	b	0x6758 <_main+0x32c>
    6740:      	fmov	d0, x8
    6744:      	mov	x0, #0x26               ; =38
    6748:      	movk	x0, #0xddae, lsl #32
    674c:      	movk	x0, #0x5556, lsl #48
    6750:      	fmov	d1, #4.00000000
    6754:      	bl	0x6754 <_main+0x328>
		0000000000006754:  ARM64_RELOC_BRANCH26	_js_typed_feedback_array_index_get_fallback_boxed
    6758:      	bl	0x6758 <_main+0x32c>
		0000000000006758:  ARM64_RELOC_BRANCH26	_js_number_coerce
    675c:      	mov.16b	v8, v0
    6760:      	bl	0x6760 <_main+0x334>
		0000000000006760:  ARM64_RELOC_BRANCH26	_js_process_argv
    6764:      	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
    6768:      	orr	x8, x0, x8
    676c:      	and	x9, x0, #0xffffffffffff
    6770:      	cmp	x9, #0x100, lsl #12     ; =0x100000
    6774:      	b.lo	0x6820 <_main+0x3f4>
    6778:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    677c:      	cmp	x8, x10
    6780:      	b.hs	0x6820 <_main+0x3f4>
    6784:      	ldurb	w10, [x9, #-0x8]
    6788:      	ldursb	w11, [x9, #-0x7]
    678c:      	cmp	w11, #0x0
    6790:      	ccmp	w10, #0x1, #0x0, mi
    6794:      	ldr	x10, [x9]
    6798:      	csel	x9, x10, x9, eq
    679c:      	sub	x10, x9, #0x100, lsl #12 ; =0x100000
    67a0:      	mov	x11, #-0x100001         ; =-1048577
    67a4:      	movk	x11, #0x0, lsl #48
    67a8:      	cmp	x10, x11
    67ac:      	b.hi	0x6820 <_main+0x3f4>
    67b0:      	ldurb	w13, [x9, #-0x8]
    67b4:      	ldursb	w12, [x9, #-0x7]
    67b8:      	ldurh	w10, [x9, #-0x6]
    67bc:      	adrp	x11, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		00000000000067bc:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    67c0:      	ldr	x11, [x11]
		00000000000067c0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    67c4:      	ldrb	w14, [x11]
    67c8:      	ldp	w11, w15, [x9]
    67cc:      	cmp	w11, w15
    67d0:      	b.hi	0x6820 <_main+0x3f4>
    67d4:      	cmp	w15, w19
    67d8:      	b.hs	0x6820 <_main+0x3f4>
    67dc:      	cmp	w11, w19
    67e0:      	b.hs	0x6820 <_main+0x3f4>
    67e4:      	cbnz	w14, 0x6820 <_main+0x3f4>
    67e8:      	cmp	w13, #0x1
    67ec:      	b.ne	0x6820 <_main+0x3f4>
    67f0:      	tbnz	w12, #0x1f, 0x6820 <_main+0x3f4>
    67f4:      	tbnz	w10, #0xa, 0x6820 <_main+0x3f4>
    67f8:      	cmp	w11, #0x5
    67fc:      	b.ls	0x6990 <_main+0x564>
    6800:      	ldr	d0, [x9, #0x30]
    6804:      	fmov	x8, d0
    6808:      	mov	x9, #0x10               ; =16
    680c:      	movk	x9, #0x7ffc, lsl #48
    6810:      	cmp	x8, x9
    6814:      	ldr	d1, [x20]
		0000000000006814:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    6818:      	fcsel	d0, d1, d0, eq
    681c:      	b	0x6838 <_main+0x40c>
    6820:      	fmov	d0, x8
    6824:      	mov	x0, #0x27               ; =39
    6828:      	movk	x0, #0xddae, lsl #32
    682c:      	movk	x0, #0x5556, lsl #48
    6830:      	fmov	d1, #5.00000000
    6834:      	bl	0x6834 <_main+0x408>
		0000000000006834:  ARM64_RELOC_BRANCH26	_js_typed_feedback_array_index_get_fallback_boxed
    6838:      	bl	0x6838 <_main+0x40c>
		0000000000006838:  ARM64_RELOC_BRANCH26	_js_number_coerce
    683c:      	mov.16b	v9, v0
    6840:      	ldr	x8, [sp, #0x38]
    6844:      	fmov	d0, x8
    6848:      	bl	0x6848 <_main+0x41c>
		0000000000006848:  ARM64_RELOC_BRANCH26	_js_json_text_to_string
    684c:      	bl	0x684c <_main+0x420>
		000000000000684c:  ARM64_RELOC_BRANCH26	_js_json_parse
    6850:      	mov	x19, x0
    6854:      	ldr	w8, [x22]
    6858:      	cbz	w8, 0x6860 <_main+0x434>
    685c:      	bl	0x685c <_main+0x430>
		000000000000685c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6860:      	mov	x8, x19
    6864:      	lsr	x9, x8, #48
    6868:      	mov	x10, #-0x3000000000000  ; =-844424930131968
    686c:      	and	x10, x8, x10
    6870:      	mov	x11, #0x7ffd000000000000 ; =9222527611924643840
    6874:      	cmp	x10, x11
    6878:      	b.ne	0x68a8 <_main+0x47c>
    687c:      	and	x0, x8, #0xffffffffffff
    6880:      	mov	w8, #0x7fff             ; =32767
    6884:      	cmp	x9, x8
    6888:      	b.ne	0x68e8 <_main+0x4bc>
    688c:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		000000000000688c:  ARM64_RELOC_PAGE21	_perry_null_guard_zero_access_worker_ts
    6890:      	add	x8, x8, #0x0
		0000000000006890:  ARM64_RELOC_PAGEOFF12	_perry_null_guard_zero_access_worker_ts
    6894:      	cmp	x0, #0x1, lsl #12       ; =0x1000
    6898:      	csel	x8, x8, x0, lo
    689c:      	ldr	s0, [x8]
    68a0:      	ucvtf	d0, d0
    68a4:      	b	0x6aa4 <_main+0x678>
    68a8:      	mov	w10, #0x7ff9            ; =32761
    68ac:      	cmp	x9, x10
    68b0:      	b.eq	0x6950 <_main+0x524>
    68b4:      	mov	w10, #0x7ffe            ; =32766
    68b8:      	cmp	w9, w10
    68bc:      	b.ne	0x695c <_main+0x530>
    68c0:      	adrp	x9, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		00000000000068c0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    68c4:      	ldr	x9, [x9]
		00000000000068c4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    68c8:      	str	x19, [sp, #0x38]
    68cc:      	mov	x0, #0x28               ; =40
    68d0:      	movk	x0, #0xddae, lsl #32
    68d4:      	movk	x0, #0x5556, lsl #48
    68d8:      	and	x2, x9, #0xffffffffffff
    68dc:      	mov	x1, x8
    68e0:      	bl	0x68e0 <_main+0x4b4>
		00000000000068e0:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    68e4:      	b	0x6aa0 <_main+0x674>
    68e8:      	lsr	x8, x0, #20
    68ec:      	cbz	x8, 0x6a84 <_main+0x658>
    68f0:      	ldurb	w9, [x0, #-0x8]
    68f4:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		00000000000068f4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__41
    68f8:      	ldr	x8, [x8]
		00000000000068f8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__41
    68fc:      	cbz	x8, 0x69a8 <_main+0x57c>
    6900:      	cmp	w9, #0x2
    6904:      	b.ne	0x69a8 <_main+0x57c>
    6908:      	ldurh	w10, [x0, #-0x6]
    690c:      	tbnz	w10, #0xb, 0x69a8 <_main+0x57c>
    6910:      	ldr	w10, [x0, #0x4]
    6914:      	orr	x9, x10, #0x4000000000000000
    6918:      	cbz	w10, 0x69d4 <_main+0x5a8>
    691c:      	ldr	x11, [x8]
    6920:      	cmp	x9, x11
    6924:      	b.ne	0x69d4 <_main+0x5a8>
    6928:      	ldr	x2, [x8, #0x8]
    692c:      	tbnz	w2, #0x1e, 0x7dd8 <_main+0x19ac>
    6930:      	add	x11, x0, x2, lsl #3
    6934:      	ldr	d0, [x11, #0x10]
    6938:      	fmov	x11, d0
    693c:      	mov	x12, #0x10              ; =16
    6940:      	movk	x12, #0x7ffc, lsl #48
    6944:      	cmp	x11, x12
    6948:      	b.ne	0x6aa4 <_main+0x678>
    694c:      	b	0x6a00 <_main+0x5d4>
    6950:      	ubfx	x8, x8, #40, #8
    6954:      	ucvtf	d0, x8
    6958:      	b	0x6aa4 <_main+0x678>
    695c:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    6960:      	add	x9, x8, x9
    6964:      	cmp	x9, #0x2
    6968:      	b.lo	0x7e3c <_main+0x1a10>
    696c:      	adrp	x9, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		000000000000696c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    6970:      	ldr	x9, [x9]
		0000000000006970:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    6974:      	str	x19, [sp, #0x38]
    6978:      	and	x1, x9, #0xffffffffffff
    697c:      	mov	x0, x8
    6980:      	bl	0x6980 <_main+0x554>
		0000000000006980:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    6984:      	b	0x6aa0 <_main+0x674>
    6988:      	ldr	d0, [x20]
		0000000000006988:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    698c:      	b	0x6758 <_main+0x32c>
    6990:      	ldr	d0, [x20]
		0000000000006990:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    6994:      	b	0x6838 <_main+0x40c>
    6998:      	ldr	d0, [x20]
		0000000000006998:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    699c:      	b	0x6578 <_main+0x14c>
    69a0:      	ldr	d0, [x20]
		00000000000069a0:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    69a4:      	b	0x6670 <_main+0x244>
    69a8:      	cmp	w9, #0x2
    69ac:      	b.ne	0x6a84 <_main+0x658>
    69b0:      	cbz	x8, 0x6a84 <_main+0x658>
    69b4:      	ldr	x9, [x8, #0x10]
    69b8:      	cbz	x9, 0x6a84 <_main+0x658>
    69bc:      	ldr	x10, [x0, #0x8]
    69c0:      	cbz	x10, 0x6a84 <_main+0x658>
    69c4:      	ldr	x10, [x10, #0x30]
    69c8:      	cmp	x10, x9
    69cc:      	b.eq	0x69f0 <_main+0x5c4>
    69d0:      	b	0x6a84 <_main+0x658>
    69d4:      	ldr	x11, [x8, #0x10]
    69d8:      	cbz	x11, 0x6a00 <_main+0x5d4>
    69dc:      	ldr	x12, [x0, #0x8]
    69e0:      	cbz	x12, 0x6a00 <_main+0x5d4>
    69e4:      	ldr	x12, [x12, #0x30]
    69e8:      	cmp	x12, x11
    69ec:      	b.ne	0x6a00 <_main+0x5d4>
    69f0:      	ldr	x8, [x8, #0x8]
    69f4:      	add	x8, x0, x8, lsl #3
    69f8:      	ldr	d0, [x8, #0x10]
    69fc:      	b	0x6aa4 <_main+0x678>
    6a00:      	ldr	x11, [x8, #0x18]
    6a04:      	cmp	x11, #0x0
    6a08:      	b.le	0x6a84 <_main+0x658>
    6a0c:      	ldr	x11, [x8, #0x20]
    6a10:      	ldr	x12, [x8, #0x30]
    6a14:      	ldr	x13, [x8, #0x40]
    6a18:      	cmp	x13, x9
    6a1c:      	ldr	x14, [x8, #0x50]
    6a20:      	ccmp	x14, x9, #0x4, ne
    6a24:      	ccmp	x12, x9, #0x4, ne
    6a28:      	ccmp	x11, x9, #0x4, ne
    6a2c:      	cset	w15, eq
    6a30:      	cbz	w10, 0x6a84 <_main+0x658>
    6a34:      	cbz	w15, 0x6a84 <_main+0x658>
    6a38:      	ldr	x10, [x8, #0x48]
    6a3c:      	ldr	x15, [x8, #0x58]
    6a40:      	cmp	x14, x9
    6a44:      	csel	x14, x15, xzr, eq
    6a48:      	cmp	x13, x9
    6a4c:      	csel	x10, x10, x14, eq
    6a50:      	ldr	x13, [x8, #0x28]
    6a54:      	ldr	x8, [x8, #0x38]
    6a58:      	cmp	x12, x9
    6a5c:      	csel	x8, x8, x10, eq
    6a60:      	cmp	x11, x9
    6a64:      	csel	x8, x13, x8, eq
    6a68:      	add	x8, x0, x8, lsl #3
    6a6c:      	ldr	d0, [x8, #0x10]
    6a70:      	fmov	x8, d0
    6a74:      	mov	x9, #0x10               ; =16
    6a78:      	movk	x9, #0x7ffc, lsl #48
    6a7c:      	cmp	x8, x9
    6a80:      	b.ne	0x6aa4 <_main+0x678>
    6a84:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006a84:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    6a88:      	ldr	x8, [x8]
		0000000000006a88:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    6a8c:      	str	x19, [sp, #0x38]
    6a90:      	adrp	x2, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006a90:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__41
    6a94:      	add	x2, x2, #0x0
		0000000000006a94:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__41
    6a98:      	and	x1, x8, #0xffffffffffff
    6a9c:      	bl	0x6a9c <_main+0x670>
		0000000000006a9c:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    6aa0:      	ldr	x19, [sp, #0x38]
    6aa4:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006aa4:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    6aa8:      	str	d0, [x8]
		0000000000006aa8:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    6aac:      	fmov	x0, d0
    6ab0:      	bl	0x6ab0 <_main+0x684>
		0000000000006ab0:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6ab4:      	mov	x8, x19
    6ab8:      	fmov	d0, x8
    6abc:      	str	x19, [sp, #0x38]
    6ac0:      	mov.16b	v1, v9
    6ac4:      	bl	0x6ac4 <_main+0x698>
		0000000000006ac4:  ARM64_RELOC_BRANCH26	_perry_fn_access_worker_ts__run$spec_b_b
    6ac8:      	fmov	x0, d0
    6acc:      	mov	x19, x0
    6ad0:      	ldr	w8, [x22]
    6ad4:      	cbz	w8, 0x6adc <_main+0x6b0>
    6ad8:      	bl	0x6ad8 <_main+0x6ac>
		0000000000006ad8:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6adc:      	str	x19, [sp, #0x30]
    6ae0:      	bl	0x6ae0 <_main+0x6b4>
		0000000000006ae0:  ARM64_RELOC_BRANCH26	_js_process_memory_usage
    6ae4:      	fmov	x8, d0
    6ae8:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    6aec:      	and	x9, x8, x9
    6af0:      	mov	x10, #0x7ffd000000000000 ; =9222527611924643840
    6af4:      	cmp	x9, x10
    6af8:      	b.ne	0x6b68 <_main+0x73c>
    6afc:      	and	x0, x8, #0xffffffffffff
    6b00:      	lsr	x8, x0, #20
    6b04:      	cbz	x8, 0x6cac <_main+0x880>
    6b08:      	ldurb	w9, [x0, #-0x8]
    6b0c:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006b0c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__43
    6b10:      	ldr	x8, [x8]
		0000000000006b10:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__43
    6b14:      	cbz	x8, 0x6bd0 <_main+0x7a4>
    6b18:      	cmp	w9, #0x2
    6b1c:      	b.ne	0x6bd0 <_main+0x7a4>
    6b20:      	ldurh	w10, [x0, #-0x6]
    6b24:      	tbnz	w10, #0xb, 0x6bd0 <_main+0x7a4>
    6b28:      	ldr	w10, [x0, #0x4]
    6b2c:      	orr	x9, x10, #0x4000000000000000
    6b30:      	cbz	w10, 0x6bfc <_main+0x7d0>
    6b34:      	ldr	x11, [x8]
    6b38:      	cmp	x9, x11
    6b3c:      	b.ne	0x6bfc <_main+0x7d0>
    6b40:      	ldr	x2, [x8, #0x8]
    6b44:      	tbnz	w2, #0x1e, 0x7b20 <_main+0x16f4>
    6b48:      	add	x11, x0, x2, lsl #3
    6b4c:      	ldr	d0, [x11, #0x10]
    6b50:      	fmov	x11, d0
    6b54:      	mov	x12, #0x10              ; =16
    6b58:      	movk	x12, #0x7ffc, lsl #48
    6b5c:      	cmp	x11, x12
    6b60:      	b.ne	0x6cc4 <_main+0x898>
    6b64:      	b	0x6c28 <_main+0x7fc>
    6b68:      	lsr	x9, x8, #48
    6b6c:      	mov	w10, #0x7ff9            ; =32761
    6b70:      	cmp	x9, x10
    6b74:      	b.eq	0x6bb8 <_main+0x78c>
    6b78:      	mov	w10, #0x7ffe            ; =32766
    6b7c:      	cmp	w9, w10
    6b80:      	b.ne	0x6ba8 <_main+0x77c>
    6b84:      	adrp	x9, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006b84:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    6b88:      	ldr	x9, [x9]
		0000000000006b88:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    6b8c:      	mov	x0, #0x2a               ; =42
    6b90:      	movk	x0, #0xddae, lsl #32
    6b94:      	movk	x0, #0x5556, lsl #48
    6b98:      	and	x2, x9, #0xffffffffffff
    6b9c:      	mov	x1, x8
    6ba0:      	bl	0x6ba0 <_main+0x774>
		0000000000006ba0:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    6ba4:      	b	0x6cc4 <_main+0x898>
    6ba8:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    6bac:      	add	x9, x8, x9
    6bb0:      	cmp	x9, #0x2
    6bb4:      	b.lo	0x7e18 <_main+0x19ec>
    6bb8:      	adrp	x9, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006bb8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    6bbc:      	ldr	x9, [x9]
		0000000000006bbc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    6bc0:      	and	x1, x9, #0xffffffffffff
    6bc4:      	mov	x0, x8
    6bc8:      	bl	0x6bc8 <_main+0x79c>
		0000000000006bc8:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    6bcc:      	b	0x6cc4 <_main+0x898>
    6bd0:      	cmp	w9, #0x2
    6bd4:      	b.ne	0x6cac <_main+0x880>
    6bd8:      	cbz	x8, 0x6cac <_main+0x880>
    6bdc:      	ldr	x9, [x8, #0x10]
    6be0:      	cbz	x9, 0x6cac <_main+0x880>
    6be4:      	ldr	x10, [x0, #0x8]
    6be8:      	cbz	x10, 0x6cac <_main+0x880>
    6bec:      	ldr	x10, [x10, #0x30]
    6bf0:      	cmp	x10, x9
    6bf4:      	b.eq	0x6c18 <_main+0x7ec>
    6bf8:      	b	0x6cac <_main+0x880>
    6bfc:      	ldr	x11, [x8, #0x10]
    6c00:      	cbz	x11, 0x6c28 <_main+0x7fc>
    6c04:      	ldr	x12, [x0, #0x8]
    6c08:      	cbz	x12, 0x6c28 <_main+0x7fc>
    6c0c:      	ldr	x12, [x12, #0x30]
    6c10:      	cmp	x12, x11
    6c14:      	b.ne	0x6c28 <_main+0x7fc>
    6c18:      	ldr	x8, [x8, #0x8]
    6c1c:      	add	x8, x0, x8, lsl #3
    6c20:      	ldr	d0, [x8, #0x10]
    6c24:      	b	0x6cc4 <_main+0x898>
    6c28:      	ldr	x11, [x8, #0x18]
    6c2c:      	cmp	x11, #0x0
    6c30:      	b.le	0x6cac <_main+0x880>
    6c34:      	ldr	x11, [x8, #0x20]
    6c38:      	ldr	x12, [x8, #0x30]
    6c3c:      	ldr	x13, [x8, #0x40]
    6c40:      	cmp	x13, x9
    6c44:      	ldr	x14, [x8, #0x50]
    6c48:      	ccmp	x14, x9, #0x4, ne
    6c4c:      	ccmp	x12, x9, #0x4, ne
    6c50:      	ccmp	x11, x9, #0x4, ne
    6c54:      	cset	w15, eq
    6c58:      	cbz	w10, 0x6cac <_main+0x880>
    6c5c:      	cbz	w15, 0x6cac <_main+0x880>
    6c60:      	ldr	x10, [x8, #0x48]
    6c64:      	ldr	x15, [x8, #0x58]
    6c68:      	cmp	x14, x9
    6c6c:      	csel	x14, x15, xzr, eq
    6c70:      	cmp	x13, x9
    6c74:      	csel	x10, x10, x14, eq
    6c78:      	ldr	x13, [x8, #0x28]
    6c7c:      	ldr	x8, [x8, #0x38]
    6c80:      	cmp	x12, x9
    6c84:      	csel	x8, x8, x10, eq
    6c88:      	cmp	x11, x9
    6c8c:      	csel	x8, x13, x8, eq
    6c90:      	add	x8, x0, x8, lsl #3
    6c94:      	ldr	d0, [x8, #0x10]
    6c98:      	fmov	x8, d0
    6c9c:      	mov	x9, #0x10               ; =16
    6ca0:      	movk	x9, #0x7ffc, lsl #48
    6ca4:      	cmp	x8, x9
    6ca8:      	b.ne	0x6cc4 <_main+0x898>
    6cac:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006cac:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    6cb0:      	ldr	x8, [x8]
		0000000000006cb0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    6cb4:      	adrp	x2, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006cb4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__43
    6cb8:      	add	x2, x2, #0x0
		0000000000006cb8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__43
    6cbc:      	and	x1, x8, #0xffffffffffff
    6cc0:      	bl	0x6cc0 <_main+0x894>
		0000000000006cc0:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    6cc4:      	fmov	x0, d0
    6cc8:      	mov	x19, x0
    6ccc:      	ldr	w8, [x22]
    6cd0:      	cbz	w8, 0x6cd8 <_main+0x8ac>
    6cd4:      	bl	0x6cd4 <_main+0x8a8>
		0000000000006cd4:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6cd8:      	str	x19, [sp, #0x28]
    6cdc:      	ldr	d9, [x20]
		0000000000006cdc:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    6ce0:      	mov.16b	v0, v9
    6ce4:      	bl	0x6ce4 <_main+0x8b8>
		0000000000006ce4:  ARM64_RELOC_BRANCH26	_js_process_cpu_usage
    6ce8:      	fmov	x0, d0
    6cec:      	mov	x19, x0
    6cf0:      	ldr	w8, [x22]
    6cf4:      	cbz	w8, 0x6cfc <_main+0x8d0>
    6cf8:      	bl	0x6cf8 <_main+0x8cc>
		0000000000006cf8:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6cfc:      	str	x19, [sp, #0x20]
    6d00:      	bl	0x6d00 <_main+0x8d4>
		0000000000006d00:  ARM64_RELOC_BRANCH26	_js_performance_now
    6d04:      	mov.16b	v10, v0
    6d08:      	ldp	x0, x19, [sp, #0x30]
    6d0c:      	mov	x20, x0
    6d10:      	ldr	w8, [x22]
    6d14:      	cbz	w8, 0x6d1c <_main+0x8f0>
    6d18:      	bl	0x6d18 <_main+0x8ec>
		0000000000006d18:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6d1c:      	fmov	d0, x19
    6d20:      	str	x20, [sp, #0x30]
    6d24:      	mov.16b	v1, v8
    6d28:      	bl	0x6d28 <_main+0x8fc>
		0000000000006d28:  ARM64_RELOC_BRANCH26	_perry_fn_access_worker_ts__run$spec_b_b
    6d2c:      	mov.16b	v1, v0
    6d30:      	ldr	x8, [sp, #0x30]
    6d34:      	and	x9, x8, #0xffff000000000000
    6d38:      	mov	x10, #0x7ff9000000000000 ; =9221401712017801216
    6d3c:      	cmp	x8, x10
    6d40:      	fmov	d0, x8
    6d44:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    6d48:      	ccmp	x9, x8, #0x2, hs
    6d4c:      	cset	w8, hi
    6d50:      	fmov	x9, d1
    6d54:      	and	x10, x9, #0xffff000000000000
    6d58:      	mov	x11, #0x1               ; =1
    6d5c:      	movk	x11, #0x7fff, lsl #48
    6d60:      	cmp	x10, x11
    6d64:      	mov	x10, #0x7ff8ffffffffffff ; =9221401712017801215
    6d68:      	ccmp	x9, x10, #0x0, lo
    6d6c:      	b.hi	0x6d7c <_main+0x950>
    6d70:      	cbz	w8, 0x6d7c <_main+0x950>
    6d74:      	fadd	d0, d1, d0
    6d78:      	b	0x6d80 <_main+0x954>
    6d7c:      	bl	0x6d7c <_main+0x950>
		0000000000006d7c:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    6d80:      	fmov	x0, d0
    6d84:      	mov	x19, x0
    6d88:      	ldr	w8, [x22]
    6d8c:      	cbz	w8, 0x6d94 <_main+0x968>
    6d90:      	bl	0x6d90 <_main+0x964>
		0000000000006d90:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6d94:      	str	x19, [sp, #0x30]
    6d98:      	bl	0x6d98 <_main+0x96c>
		0000000000006d98:  ARM64_RELOC_BRANCH26	_js_performance_now
    6d9c:      	fmov	x8, d0
    6da0:      	and	x9, x8, #0xffff000000000000
    6da4:      	mov	x10, #0x7ff9000000000000 ; =9221401712017801216
    6da8:      	cmp	x8, x10
    6dac:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    6db0:      	ccmp	x9, x8, #0x2, hs
    6db4:      	cset	w8, hi
    6db8:      	fmov	x9, d10
    6dbc:      	and	x10, x9, #0xffff000000000000
    6dc0:      	mov	x11, #0x1               ; =1
    6dc4:      	movk	x11, #0x7fff, lsl #48
    6dc8:      	cmp	x10, x11
    6dcc:      	mov	x10, #0x7ff8ffffffffffff ; =9221401712017801215
    6dd0:      	ccmp	x9, x10, #0x0, lo
    6dd4:      	b.hi	0x6de4 <_main+0x9b8>
    6dd8:      	cbz	w8, 0x6de4 <_main+0x9b8>
    6ddc:      	fsub	d8, d0, d10
    6de0:      	b	0x6df0 <_main+0x9c4>
    6de4:      	mov.16b	v1, v10
    6de8:      	bl	0x6de8 <_main+0x9bc>
		0000000000006de8:  ARM64_RELOC_BRANCH26	_js_dynamic_sub
    6dec:      	mov.16b	v8, v0
    6df0:      	mov.16b	v0, v9
    6df4:      	bl	0x6df4 <_main+0x9c8>
		0000000000006df4:  ARM64_RELOC_BRANCH26	_js_process_cpu_usage
    6df8:      	fmov	x0, d0
    6dfc:      	mov	x19, x0
    6e00:      	ldr	w8, [x22]
    6e04:      	cbz	w8, 0x6e0c <_main+0x9e0>
    6e08:      	bl	0x6e08 <_main+0x9dc>
		0000000000006e08:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6e0c:      	str	x19, [sp, #0x18]
    6e10:      	mov	w0, #0x8                ; =8
    6e14:      	bl	0x6e14 <_main+0x9e8>
		0000000000006e14:  ARM64_RELOC_BRANCH26	_js_array_alloc
    6e18:      	mov	x19, x0
    6e1c:      	ldr	w8, [x22]
    6e20:      	cbz	w8, 0x6e28 <_main+0x9fc>
    6e24:      	bl	0x6e24 <_main+0x9f8>
		0000000000006e24:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6e28:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006e28:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.11.handle
    6e2c:      	ldr	d0, [x8]
		0000000000006e2c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.11.handle
    6e30:      	mov	x0, x19
    6e34:      	bl	0x6e34 <_main+0xa08>
		0000000000006e34:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    6e38:      	mov	x19, x0
    6e3c:      	ldr	w8, [x22]
    6e40:      	cbz	w8, 0x6e48 <_main+0xa1c>
    6e44:      	bl	0x6e44 <_main+0xa18>
		0000000000006e44:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6e48:      	mov	x0, x19
    6e4c:      	mov.16b	v0, v8
    6e50:      	bl	0x6e50 <_main+0xa24>
		0000000000006e50:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    6e54:      	mov	x19, x0
    6e58:      	ldp	x21, x20, [sp, #0x18]
    6e5c:      	ldr	w8, [x22]
    6e60:      	cbz	w8, 0x6e68 <_main+0xa3c>
    6e64:      	bl	0x6e64 <_main+0xa38>
		0000000000006e64:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6e68:      	mov	x8, #-0x3000000000000   ; =-844424930131968
    6e6c:      	and	x8, x21, x8
    6e70:      	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
    6e74:      	cmp	x8, x9
    6e78:      	b.ne	0x6ee8 <_main+0xabc>
    6e7c:      	and	x0, x21, #0xffffffffffff
    6e80:      	lsr	x8, x0, #20
    6e84:      	cbz	x8, 0x7034 <_main+0xc08>
    6e88:      	ldurb	w9, [x0, #-0x8]
    6e8c:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006e8c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__45
    6e90:      	ldr	x8, [x8]
		0000000000006e90:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__45
    6e94:      	cbz	x8, 0x6f58 <_main+0xb2c>
    6e98:      	cmp	w9, #0x2
    6e9c:      	b.ne	0x6f58 <_main+0xb2c>
    6ea0:      	ldurh	w10, [x0, #-0x6]
    6ea4:      	tbnz	w10, #0xb, 0x6f58 <_main+0xb2c>
    6ea8:      	ldr	w10, [x0, #0x4]
    6eac:      	orr	x9, x10, #0x4000000000000000
    6eb0:      	cbz	w10, 0x6f84 <_main+0xb58>
    6eb4:      	ldr	x11, [x8]
    6eb8:      	cmp	x9, x11
    6ebc:      	b.ne	0x6f84 <_main+0xb58>
    6ec0:      	ldr	x2, [x8, #0x8]
    6ec4:      	tbnz	w2, #0x1e, 0x7d38 <_main+0x190c>
    6ec8:      	add	x11, x0, x2, lsl #3
    6ecc:      	ldr	d0, [x11, #0x10]
    6ed0:      	fmov	x11, d0
    6ed4:      	mov	x12, #0x10              ; =16
    6ed8:      	movk	x12, #0x7ffc, lsl #48
    6edc:      	cmp	x11, x12
    6ee0:      	b.ne	0x7058 <_main+0xc2c>
    6ee4:      	b	0x6fb0 <_main+0xb84>
    6ee8:      	lsr	x8, x21, #48
    6eec:      	mov	w9, #0x7ff9             ; =32761
    6ef0:      	cmp	x8, x9
    6ef4:      	b.eq	0x6f3c <_main+0xb10>
    6ef8:      	mov	w9, #0x7ffe             ; =32766
    6efc:      	cmp	w8, w9
    6f00:      	b.ne	0x6f2c <_main+0xb00>
    6f04:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006f04:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    6f08:      	ldr	x8, [x8]
		0000000000006f08:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    6f0c:      	str	x19, [sp, #0x10]
    6f10:      	mov	x0, #0x2c               ; =44
    6f14:      	movk	x0, #0xddae, lsl #32
    6f18:      	movk	x0, #0x5556, lsl #48
    6f1c:      	and	x2, x8, #0xffffffffffff
    6f20:      	mov	x1, x21
    6f24:      	bl	0x6f24 <_main+0xaf8>
		0000000000006f24:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    6f28:      	b	0x7050 <_main+0xc24>
    6f2c:      	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
    6f30:      	add	x8, x21, x8
    6f34:      	cmp	x8, #0x2
    6f38:      	b.lo	0x7e50 <_main+0x1a24>
    6f3c:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f64>
		0000000000006f3c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    6f40:      	ldr	x8, [x8]
		0000000000006f40:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    6f44:      	str	x19, [sp, #0x10]
    6f48:      	and	x1, x8, #0xffffffffffff
    6f4c:      	mov	x0, x21
    6f50:      	bl	0x6f50 <_main+0xb24>
		0000000000006f50:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    6f54:      	b	0x7050 <_main+0xc24>
    6f58:      	cmp	w9, #0x2
    6f5c:      	b.ne	0x7034 <_main+0xc08>
    6f60:      	cbz	x8, 0x7034 <_main+0xc08>
    6f64:      	ldr	x9, [x8, #0x10]
    6f68:      	cbz	x9, 0x7034 <_main+0xc08>
    6f6c:      	ldr	x10, [x0, #0x8]
    6f70:      	cbz	x10, 0x7034 <_main+0xc08>
    6f74:      	ldr	x10, [x10, #0x30]
    6f78:      	cmp	x10, x9
    6f7c:      	b.eq	0x6fa0 <_main+0xb74>
    6f80:      	b	0x7034 <_main+0xc08>
    6f84:      	ldr	x11, [x8, #0x10]
    6f88:      	cbz	x11, 0x6fb0 <_main+0xb84>
    6f8c:      	ldr	x12, [x0, #0x8]
    6f90:      	cbz	x12, 0x6fb0 <_main+0xb84>
    6f94:      	ldr	x12, [x12, #0x30]
    6f98:      	cmp	x12, x11
    6f9c:      	b.ne	0x6fb0 <_main+0xb84>
    6fa0:      	ldr	x8, [x8, #0x8]
    6fa4:      	add	x8, x0, x8, lsl #3
    6fa8:      	ldr	d0, [x8, #0x10]
    6fac:      	b	0x7058 <_main+0xc2c>
    6fb0:      	ldr	x11, [x8, #0x18]
    6fb4:      	cmp	x11, #0x0
    6fb8:      	b.le	0x7034 <_main+0xc08>
    6fbc:      	ldr	x11, [x8, #0x20]
    6fc0:      	ldr	x12, [x8, #0x30]
    6fc4:      	ldr	x13, [x8, #0x40]
    6fc8:      	cmp	x13, x9
    6fcc:      	ldr	x14, [x8, #0x50]
    6fd0:      	ccmp	x14, x9, #0x4, ne
    6fd4:      	ccmp	x12, x9, #0x4, ne
    6fd8:      	ccmp	x11, x9, #0x4, ne
    6fdc:      	cset	w15, eq
    6fe0:      	cbz	w10, 0x7034 <_main+0xc08>
    6fe4:      	cbz	w15, 0x7034 <_main+0xc08>
    6fe8:      	ldr	x10, [x8, #0x48]
    6fec:      	ldr	x15, [x8, #0x58]
    6ff0:      	cmp	x14, x9
    6ff4:      	csel	x14, x15, xzr, eq
    6ff8:      	cmp	x13, x9
    6ffc:      	csel	x10, x10, x14, eq
    7000:      	ldr	x13, [x8, #0x28]
    7004:      	ldr	x8, [x8, #0x38]
    7008:      	cmp	x12, x9
    700c:      	csel	x8, x8, x10, eq
    7010:      	cmp	x11, x9
    7014:      	csel	x8, x13, x8, eq
    7018:      	add	x8, x0, x8, lsl #3
    701c:      	ldr	d0, [x8, #0x10]
    7020:      	fmov	x8, d0
    7024:      	mov	x9, #0x10               ; =16
    7028:      	movk	x9, #0x7ffc, lsl #48
    702c:      	cmp	x8, x9
    7030:      	b.ne	0x7058 <_main+0xc2c>
    7034:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007034:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    7038:      	ldr	x8, [x8]
		0000000000007038:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    703c:      	str	x19, [sp, #0x10]
    7040:      	adrp	x2, 0x7000 <_main+0xbd4>
		0000000000007040:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__45
    7044:      	add	x2, x2, #0x0
		0000000000007044:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__45
    7048:      	and	x1, x8, #0xffffffffffff
    704c:      	bl	0x704c <_main+0xc20>
		000000000000704c:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    7050:      	ldr	x20, [sp, #0x20]
    7054:      	ldr	x19, [sp, #0x10]
    7058:      	fmov	x21, d0
    705c:      	mov	x0, x21
    7060:      	ldr	w8, [x22]
    7064:      	cbz	w8, 0x706c <_main+0xc40>
    7068:      	bl	0x7068 <_main+0xc3c>
		0000000000007068:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    706c:      	mov	x8, #-0x3000000000000   ; =-844424930131968
    7070:      	and	x8, x20, x8
    7074:      	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
    7078:      	cmp	x8, x9
    707c:      	b.ne	0x70ec <_main+0xcc0>
    7080:      	and	x0, x20, #0xffffffffffff
    7084:      	lsr	x8, x0, #20
    7088:      	cbz	x8, 0x7238 <_main+0xe0c>
    708c:      	ldurb	w9, [x0, #-0x8]
    7090:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007090:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__47
    7094:      	ldr	x8, [x8]
		0000000000007094:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__47
    7098:      	cbz	x8, 0x715c <_main+0xd30>
    709c:      	cmp	w9, #0x2
    70a0:      	b.ne	0x715c <_main+0xd30>
    70a4:      	ldurh	w10, [x0, #-0x6]
    70a8:      	tbnz	w10, #0xb, 0x715c <_main+0xd30>
    70ac:      	ldr	w10, [x0, #0x4]
    70b0:      	orr	x9, x10, #0x4000000000000000
    70b4:      	cbz	w10, 0x7188 <_main+0xd5c>
    70b8:      	ldr	x11, [x8]
    70bc:      	cmp	x9, x11
    70c0:      	b.ne	0x7188 <_main+0xd5c>
    70c4:      	ldr	x2, [x8, #0x8]
    70c8:      	tbnz	w2, #0x1e, 0x7d58 <_main+0x192c>
    70cc:      	add	x11, x0, x2, lsl #3
    70d0:      	ldr	d1, [x11, #0x10]
    70d4:      	fmov	x11, d1
    70d8:      	mov	x12, #0x10              ; =16
    70dc:      	movk	x12, #0x7ffc, lsl #48
    70e0:      	cmp	x11, x12
    70e4:      	b.ne	0x725c <_main+0xe30>
    70e8:      	b	0x71b4 <_main+0xd88>
    70ec:      	lsr	x8, x20, #48
    70f0:      	mov	w9, #0x7ff9             ; =32761
    70f4:      	cmp	x8, x9
    70f8:      	b.eq	0x7140 <_main+0xd14>
    70fc:      	mov	w9, #0x7ffe             ; =32766
    7100:      	cmp	w8, w9
    7104:      	b.ne	0x7130 <_main+0xd04>
    7108:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007108:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    710c:      	ldr	x8, [x8]
		000000000000710c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    7110:      	stp	x19, x21, [sp, #0x8]
    7114:      	mov	x0, #0x2e               ; =46
    7118:      	movk	x0, #0xddae, lsl #32
    711c:      	movk	x0, #0x5556, lsl #48
    7120:      	and	x2, x8, #0xffffffffffff
    7124:      	mov	x1, x20
    7128:      	bl	0x7128 <_main+0xcfc>
		0000000000007128:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    712c:      	b	0x7254 <_main+0xe28>
    7130:      	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
    7134:      	add	x8, x20, x8
    7138:      	cmp	x8, #0x2
    713c:      	b.lo	0x7e64 <_main+0x1a38>
    7140:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007140:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    7144:      	ldr	x8, [x8]
		0000000000007144:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    7148:      	stp	x19, x21, [sp, #0x8]
    714c:      	and	x1, x8, #0xffffffffffff
    7150:      	mov	x0, x20
    7154:      	bl	0x7154 <_main+0xd28>
		0000000000007154:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    7158:      	b	0x7254 <_main+0xe28>
    715c:      	cmp	w9, #0x2
    7160:      	b.ne	0x7238 <_main+0xe0c>
    7164:      	cbz	x8, 0x7238 <_main+0xe0c>
    7168:      	ldr	x9, [x8, #0x10]
    716c:      	cbz	x9, 0x7238 <_main+0xe0c>
    7170:      	ldr	x10, [x0, #0x8]
    7174:      	cbz	x10, 0x7238 <_main+0xe0c>
    7178:      	ldr	x10, [x10, #0x30]
    717c:      	cmp	x10, x9
    7180:      	b.eq	0x71a4 <_main+0xd78>
    7184:      	b	0x7238 <_main+0xe0c>
    7188:      	ldr	x11, [x8, #0x10]
    718c:      	cbz	x11, 0x71b4 <_main+0xd88>
    7190:      	ldr	x12, [x0, #0x8]
    7194:      	cbz	x12, 0x71b4 <_main+0xd88>
    7198:      	ldr	x12, [x12, #0x30]
    719c:      	cmp	x12, x11
    71a0:      	b.ne	0x71b4 <_main+0xd88>
    71a4:      	ldr	x8, [x8, #0x8]
    71a8:      	add	x8, x0, x8, lsl #3
    71ac:      	ldr	d1, [x8, #0x10]
    71b0:      	b	0x725c <_main+0xe30>
    71b4:      	ldr	x11, [x8, #0x18]
    71b8:      	cmp	x11, #0x0
    71bc:      	b.le	0x7238 <_main+0xe0c>
    71c0:      	ldr	x11, [x8, #0x20]
    71c4:      	ldr	x12, [x8, #0x30]
    71c8:      	ldr	x13, [x8, #0x40]
    71cc:      	cmp	x13, x9
    71d0:      	ldr	x14, [x8, #0x50]
    71d4:      	ccmp	x14, x9, #0x4, ne
    71d8:      	ccmp	x12, x9, #0x4, ne
    71dc:      	ccmp	x11, x9, #0x4, ne
    71e0:      	cset	w15, eq
    71e4:      	cbz	w10, 0x7238 <_main+0xe0c>
    71e8:      	cbz	w15, 0x7238 <_main+0xe0c>
    71ec:      	ldr	x10, [x8, #0x48]
    71f0:      	ldr	x15, [x8, #0x58]
    71f4:      	cmp	x14, x9
    71f8:      	csel	x14, x15, xzr, eq
    71fc:      	cmp	x13, x9
    7200:      	csel	x10, x10, x14, eq
    7204:      	ldr	x13, [x8, #0x28]
    7208:      	ldr	x8, [x8, #0x38]
    720c:      	cmp	x12, x9
    7210:      	csel	x8, x8, x10, eq
    7214:      	cmp	x11, x9
    7218:      	csel	x8, x13, x8, eq
    721c:      	add	x8, x0, x8, lsl #3
    7220:      	ldr	d1, [x8, #0x10]
    7224:      	fmov	x8, d1
    7228:      	mov	x9, #0x10               ; =16
    722c:      	movk	x9, #0x7ffc, lsl #48
    7230:      	cmp	x8, x9
    7234:      	b.ne	0x725c <_main+0xe30>
    7238:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007238:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    723c:      	ldr	x8, [x8]
		000000000000723c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    7240:      	stp	x19, x21, [sp, #0x8]
    7244:      	adrp	x2, 0x7000 <_main+0xbd4>
		0000000000007244:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__47
    7248:      	add	x2, x2, #0x0
		0000000000007248:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__47
    724c:      	and	x1, x8, #0xffffffffffff
    7250:      	bl	0x7250 <_main+0xe24>
		0000000000007250:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    7254:      	mov.16b	v1, v0
    7258:      	ldp	x19, x21, [sp, #0x8]
    725c:      	fmov	d0, x21
    7260:      	and	x9, x21, #0xffff000000000000
    7264:      	fmov	x8, d1
    7268:      	and	x10, x8, #0xffff000000000000
    726c:      	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
    7270:      	cmp	x8, x11
    7274:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    7278:      	ccmp	x10, x8, #0x2, hs
    727c:      	cset	w8, hi
    7280:      	mov	x10, #0x1               ; =1
    7284:      	movk	x10, #0x7fff, lsl #48
    7288:      	cmp	x9, x10
    728c:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    7290:      	ccmp	x21, x9, #0x0, lo
    7294:      	b.hi	0x72a4 <_main+0xe78>
    7298:      	tbz	w8, #0x0, 0x72a4 <_main+0xe78>
    729c:      	fsub	d0, d0, d1
    72a0:      	b	0x72b0 <_main+0xe84>
    72a4:      	str	x19, [sp, #0x10]
    72a8:      	bl	0x72a8 <_main+0xe7c>
		00000000000072a8:  ARM64_RELOC_BRANCH26	_js_dynamic_sub
    72ac:      	ldr	x19, [sp, #0x10]
    72b0:      	mov	x0, x19
    72b4:      	bl	0x72b4 <_main+0xe88>
		00000000000072b4:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    72b8:      	mov	x19, x0
    72bc:      	ldp	x21, x20, [sp, #0x18]
    72c0:      	ldr	w8, [x22]
    72c4:      	cbz	w8, 0x72cc <_main+0xea0>
    72c8:      	bl	0x72c8 <_main+0xe9c>
		00000000000072c8:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    72cc:      	mov	x8, #-0x3000000000000   ; =-844424930131968
    72d0:      	and	x8, x21, x8
    72d4:      	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
    72d8:      	cmp	x8, x9
    72dc:      	b.ne	0x734c <_main+0xf20>
    72e0:      	and	x0, x21, #0xffffffffffff
    72e4:      	lsr	x8, x0, #20
    72e8:      	cbz	x8, 0x7498 <_main+0x106c>
    72ec:      	ldurb	w9, [x0, #-0x8]
    72f0:      	adrp	x8, 0x7000 <_main+0xbd4>
		00000000000072f0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__49
    72f4:      	ldr	x8, [x8]
		00000000000072f4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__49
    72f8:      	cbz	x8, 0x73bc <_main+0xf90>
    72fc:      	cmp	w9, #0x2
    7300:      	b.ne	0x73bc <_main+0xf90>
    7304:      	ldurh	w10, [x0, #-0x6]
    7308:      	tbnz	w10, #0xb, 0x73bc <_main+0xf90>
    730c:      	ldr	w10, [x0, #0x4]
    7310:      	orr	x9, x10, #0x4000000000000000
    7314:      	cbz	w10, 0x73e8 <_main+0xfbc>
    7318:      	ldr	x11, [x8]
    731c:      	cmp	x9, x11
    7320:      	b.ne	0x73e8 <_main+0xfbc>
    7324:      	ldr	x2, [x8, #0x8]
    7328:      	tbnz	w2, #0x1e, 0x7d78 <_main+0x194c>
    732c:      	add	x11, x0, x2, lsl #3
    7330:      	ldr	d0, [x11, #0x10]
    7334:      	fmov	x11, d0
    7338:      	mov	x12, #0x10              ; =16
    733c:      	movk	x12, #0x7ffc, lsl #48
    7340:      	cmp	x11, x12
    7344:      	b.ne	0x74b8 <_main+0x108c>
    7348:      	b	0x7414 <_main+0xfe8>
    734c:      	lsr	x8, x21, #48
    7350:      	mov	w9, #0x7ff9             ; =32761
    7354:      	cmp	x8, x9
    7358:      	b.eq	0x73a0 <_main+0xf74>
    735c:      	mov	w9, #0x7ffe             ; =32766
    7360:      	cmp	w8, w9
    7364:      	b.ne	0x7390 <_main+0xf64>
    7368:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007368:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    736c:      	ldr	x8, [x8]
		000000000000736c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    7370:      	str	x19, [sp, #0x18]
    7374:      	mov	x0, #0x30               ; =48
    7378:      	movk	x0, #0xddae, lsl #32
    737c:      	movk	x0, #0x5556, lsl #48
    7380:      	and	x2, x8, #0xffffffffffff
    7384:      	mov	x1, x21
    7388:      	bl	0x7388 <_main+0xf5c>
		0000000000007388:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    738c:      	b	0x74b4 <_main+0x1088>
    7390:      	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
    7394:      	add	x8, x21, x8
    7398:      	cmp	x8, #0x2
    739c:      	b.lo	0x7e88 <_main+0x1a5c>
    73a0:      	adrp	x8, 0x7000 <_main+0xbd4>
		00000000000073a0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    73a4:      	ldr	x8, [x8]
		00000000000073a4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    73a8:      	str	x19, [sp, #0x18]
    73ac:      	and	x1, x8, #0xffffffffffff
    73b0:      	mov	x0, x21
    73b4:      	bl	0x73b4 <_main+0xf88>
		00000000000073b4:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    73b8:      	b	0x74b4 <_main+0x1088>
    73bc:      	cmp	w9, #0x2
    73c0:      	b.ne	0x7498 <_main+0x106c>
    73c4:      	cbz	x8, 0x7498 <_main+0x106c>
    73c8:      	ldr	x9, [x8, #0x10]
    73cc:      	cbz	x9, 0x7498 <_main+0x106c>
    73d0:      	ldr	x10, [x0, #0x8]
    73d4:      	cbz	x10, 0x7498 <_main+0x106c>
    73d8:      	ldr	x10, [x10, #0x30]
    73dc:      	cmp	x10, x9
    73e0:      	b.eq	0x7404 <_main+0xfd8>
    73e4:      	b	0x7498 <_main+0x106c>
    73e8:      	ldr	x11, [x8, #0x10]
    73ec:      	cbz	x11, 0x7414 <_main+0xfe8>
    73f0:      	ldr	x12, [x0, #0x8]
    73f4:      	cbz	x12, 0x7414 <_main+0xfe8>
    73f8:      	ldr	x12, [x12, #0x30]
    73fc:      	cmp	x12, x11
    7400:      	b.ne	0x7414 <_main+0xfe8>
    7404:      	ldr	x8, [x8, #0x8]
    7408:      	add	x8, x0, x8, lsl #3
    740c:      	ldr	d0, [x8, #0x10]
    7410:      	b	0x74b8 <_main+0x108c>
    7414:      	ldr	x11, [x8, #0x18]
    7418:      	cmp	x11, #0x0
    741c:      	b.le	0x7498 <_main+0x106c>
    7420:      	ldr	x11, [x8, #0x20]
    7424:      	ldr	x12, [x8, #0x30]
    7428:      	ldr	x13, [x8, #0x40]
    742c:      	cmp	x13, x9
    7430:      	ldr	x14, [x8, #0x50]
    7434:      	ccmp	x14, x9, #0x4, ne
    7438:      	ccmp	x12, x9, #0x4, ne
    743c:      	ccmp	x11, x9, #0x4, ne
    7440:      	cset	w15, eq
    7444:      	cbz	w10, 0x7498 <_main+0x106c>
    7448:      	cbz	w15, 0x7498 <_main+0x106c>
    744c:      	ldr	x10, [x8, #0x48]
    7450:      	ldr	x15, [x8, #0x58]
    7454:      	cmp	x14, x9
    7458:      	csel	x14, x15, xzr, eq
    745c:      	cmp	x13, x9
    7460:      	csel	x10, x10, x14, eq
    7464:      	ldr	x13, [x8, #0x28]
    7468:      	ldr	x8, [x8, #0x38]
    746c:      	cmp	x12, x9
    7470:      	csel	x8, x8, x10, eq
    7474:      	cmp	x11, x9
    7478:      	csel	x8, x13, x8, eq
    747c:      	add	x8, x0, x8, lsl #3
    7480:      	ldr	d0, [x8, #0x10]
    7484:      	fmov	x8, d0
    7488:      	mov	x9, #0x10               ; =16
    748c:      	movk	x9, #0x7ffc, lsl #48
    7490:      	cmp	x8, x9
    7494:      	b.ne	0x74b8 <_main+0x108c>
    7498:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007498:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    749c:      	ldr	x8, [x8]
		000000000000749c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    74a0:      	str	x19, [sp, #0x18]
    74a4:      	adrp	x2, 0x7000 <_main+0xbd4>
		00000000000074a4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__49
    74a8:      	add	x2, x2, #0x0
		00000000000074a8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__49
    74ac:      	and	x1, x8, #0xffffffffffff
    74b0:      	bl	0x74b0 <_main+0x1084>
		00000000000074b0:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    74b4:      	ldp	x19, x20, [sp, #0x18]
    74b8:      	fmov	x21, d0
    74bc:      	mov	x0, x21
    74c0:      	ldr	w8, [x22]
    74c4:      	cbz	w8, 0x74cc <_main+0x10a0>
    74c8:      	bl	0x74c8 <_main+0x109c>
		00000000000074c8:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    74cc:      	mov	x8, #-0x3000000000000   ; =-844424930131968
    74d0:      	and	x8, x20, x8
    74d4:      	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
    74d8:      	cmp	x8, x9
    74dc:      	b.ne	0x754c <_main+0x1120>
    74e0:      	and	x0, x20, #0xffffffffffff
    74e4:      	lsr	x8, x0, #20
    74e8:      	cbz	x8, 0x7698 <_main+0x126c>
    74ec:      	ldurb	w9, [x0, #-0x8]
    74f0:      	adrp	x8, 0x7000 <_main+0xbd4>
		00000000000074f0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__51
    74f4:      	ldr	x8, [x8]
		00000000000074f4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__51
    74f8:      	cbz	x8, 0x75bc <_main+0x1190>
    74fc:      	cmp	w9, #0x2
    7500:      	b.ne	0x75bc <_main+0x1190>
    7504:      	ldurh	w10, [x0, #-0x6]
    7508:      	tbnz	w10, #0xb, 0x75bc <_main+0x1190>
    750c:      	ldr	w10, [x0, #0x4]
    7510:      	orr	x9, x10, #0x4000000000000000
    7514:      	cbz	w10, 0x75e8 <_main+0x11bc>
    7518:      	ldr	x11, [x8]
    751c:      	cmp	x9, x11
    7520:      	b.ne	0x75e8 <_main+0x11bc>
    7524:      	ldr	x2, [x8, #0x8]
    7528:      	tbnz	w2, #0x1e, 0x7d98 <_main+0x196c>
    752c:      	add	x11, x0, x2, lsl #3
    7530:      	ldr	d1, [x11, #0x10]
    7534:      	fmov	x11, d1
    7538:      	mov	x12, #0x10              ; =16
    753c:      	movk	x12, #0x7ffc, lsl #48
    7540:      	cmp	x11, x12
    7544:      	b.ne	0x76bc <_main+0x1290>
    7548:      	b	0x7614 <_main+0x11e8>
    754c:      	lsr	x8, x20, #48
    7550:      	mov	w9, #0x7ff9             ; =32761
    7554:      	cmp	x8, x9
    7558:      	b.eq	0x75a0 <_main+0x1174>
    755c:      	mov	w9, #0x7ffe             ; =32766
    7560:      	cmp	w8, w9
    7564:      	b.ne	0x7590 <_main+0x1164>
    7568:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007568:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    756c:      	ldr	x8, [x8]
		000000000000756c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    7570:      	stp	x19, x21, [sp, #0x18]
    7574:      	mov	x0, #0x32               ; =50
    7578:      	movk	x0, #0xddae, lsl #32
    757c:      	movk	x0, #0x5556, lsl #48
    7580:      	and	x2, x8, #0xffffffffffff
    7584:      	mov	x1, x20
    7588:      	bl	0x7588 <_main+0x115c>
		0000000000007588:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    758c:      	b	0x76b4 <_main+0x1288>
    7590:      	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
    7594:      	add	x8, x20, x8
    7598:      	cmp	x8, #0x2
    759c:      	b.lo	0x7e9c <_main+0x1a70>
    75a0:      	adrp	x8, 0x7000 <_main+0xbd4>
		00000000000075a0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    75a4:      	ldr	x8, [x8]
		00000000000075a4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    75a8:      	stp	x19, x21, [sp, #0x18]
    75ac:      	and	x1, x8, #0xffffffffffff
    75b0:      	mov	x0, x20
    75b4:      	bl	0x75b4 <_main+0x1188>
		00000000000075b4:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    75b8:      	b	0x76b4 <_main+0x1288>
    75bc:      	cmp	w9, #0x2
    75c0:      	b.ne	0x7698 <_main+0x126c>
    75c4:      	cbz	x8, 0x7698 <_main+0x126c>
    75c8:      	ldr	x9, [x8, #0x10]
    75cc:      	cbz	x9, 0x7698 <_main+0x126c>
    75d0:      	ldr	x10, [x0, #0x8]
    75d4:      	cbz	x10, 0x7698 <_main+0x126c>
    75d8:      	ldr	x10, [x10, #0x30]
    75dc:      	cmp	x10, x9
    75e0:      	b.eq	0x7604 <_main+0x11d8>
    75e4:      	b	0x7698 <_main+0x126c>
    75e8:      	ldr	x11, [x8, #0x10]
    75ec:      	cbz	x11, 0x7614 <_main+0x11e8>
    75f0:      	ldr	x12, [x0, #0x8]
    75f4:      	cbz	x12, 0x7614 <_main+0x11e8>
    75f8:      	ldr	x12, [x12, #0x30]
    75fc:      	cmp	x12, x11
    7600:      	b.ne	0x7614 <_main+0x11e8>
    7604:      	ldr	x8, [x8, #0x8]
    7608:      	add	x8, x0, x8, lsl #3
    760c:      	ldr	d1, [x8, #0x10]
    7610:      	b	0x76bc <_main+0x1290>
    7614:      	ldr	x11, [x8, #0x18]
    7618:      	cmp	x11, #0x0
    761c:      	b.le	0x7698 <_main+0x126c>
    7620:      	ldr	x11, [x8, #0x20]
    7624:      	ldr	x12, [x8, #0x30]
    7628:      	ldr	x13, [x8, #0x40]
    762c:      	cmp	x13, x9
    7630:      	ldr	x14, [x8, #0x50]
    7634:      	ccmp	x14, x9, #0x4, ne
    7638:      	ccmp	x12, x9, #0x4, ne
    763c:      	ccmp	x11, x9, #0x4, ne
    7640:      	cset	w15, eq
    7644:      	cbz	w10, 0x7698 <_main+0x126c>
    7648:      	cbz	w15, 0x7698 <_main+0x126c>
    764c:      	ldr	x10, [x8, #0x48]
    7650:      	ldr	x15, [x8, #0x58]
    7654:      	cmp	x14, x9
    7658:      	csel	x14, x15, xzr, eq
    765c:      	cmp	x13, x9
    7660:      	csel	x10, x10, x14, eq
    7664:      	ldr	x13, [x8, #0x28]
    7668:      	ldr	x8, [x8, #0x38]
    766c:      	cmp	x12, x9
    7670:      	csel	x8, x8, x10, eq
    7674:      	cmp	x11, x9
    7678:      	csel	x8, x13, x8, eq
    767c:      	add	x8, x0, x8, lsl #3
    7680:      	ldr	d1, [x8, #0x10]
    7684:      	fmov	x8, d1
    7688:      	mov	x9, #0x10               ; =16
    768c:      	movk	x9, #0x7ffc, lsl #48
    7690:      	cmp	x8, x9
    7694:      	b.ne	0x76bc <_main+0x1290>
    7698:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007698:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    769c:      	ldr	x8, [x8]
		000000000000769c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    76a0:      	stp	x19, x21, [sp, #0x18]
    76a4:      	adrp	x2, 0x7000 <_main+0xbd4>
		00000000000076a4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__51
    76a8:      	add	x2, x2, #0x0
		00000000000076a8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__51
    76ac:      	and	x1, x8, #0xffffffffffff
    76b0:      	bl	0x76b0 <_main+0x1284>
		00000000000076b0:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    76b4:      	mov.16b	v1, v0
    76b8:      	ldp	x19, x21, [sp, #0x18]
    76bc:      	fmov	d0, x21
    76c0:      	and	x9, x21, #0xffff000000000000
    76c4:      	fmov	x8, d1
    76c8:      	and	x10, x8, #0xffff000000000000
    76cc:      	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
    76d0:      	cmp	x8, x11
    76d4:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    76d8:      	ccmp	x10, x8, #0x2, hs
    76dc:      	cset	w8, hi
    76e0:      	mov	x10, #0x1               ; =1
    76e4:      	movk	x10, #0x7fff, lsl #48
    76e8:      	cmp	x9, x10
    76ec:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    76f0:      	ccmp	x21, x9, #0x0, lo
    76f4:      	b.hi	0x7704 <_main+0x12d8>
    76f8:      	tbz	w8, #0x0, 0x7704 <_main+0x12d8>
    76fc:      	fsub	d0, d0, d1
    7700:      	b	0x7710 <_main+0x12e4>
    7704:      	str	x19, [sp, #0x20]
    7708:      	bl	0x7708 <_main+0x12dc>
		0000000000007708:  ARM64_RELOC_BRANCH26	_js_dynamic_sub
    770c:      	ldr	x19, [sp, #0x20]
    7710:      	mov	x0, x19
    7714:      	bl	0x7714 <_main+0x12e8>
		0000000000007714:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    7718:      	mov	x19, x0
    771c:      	ldr	x20, [sp, #0x28]
    7720:      	ldr	w8, [x22]
    7724:      	cbz	w8, 0x772c <_main+0x1300>
    7728:      	bl	0x7728 <_main+0x12fc>
		0000000000007728:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    772c:      	fmov	d0, x20
    7730:      	mov	x0, x19
    7734:      	bl	0x7734 <_main+0x1308>
		0000000000007734:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    7738:      	mov	x19, x0
    773c:      	ldr	w8, [x22]
    7740:      	cbz	w8, 0x7748 <_main+0x131c>
    7744:      	bl	0x7744 <_main+0x1318>
		0000000000007744:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    7748:      	str	x19, [sp, #0x28]
    774c:      	bl	0x774c <_main+0x1320>
		000000000000774c:  ARM64_RELOC_BRANCH26	_js_process_memory_usage
    7750:      	fmov	x8, d0
    7754:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    7758:      	and	x9, x8, x9
    775c:      	mov	x10, #0x7ffd000000000000 ; =9222527611924643840
    7760:      	cmp	x9, x10
    7764:      	b.ne	0x77d8 <_main+0x13ac>
    7768:      	and	x8, x8, #0xffffffffffff
    776c:      	lsr	x9, x8, #20
    7770:      	cbz	x9, 0x791c <_main+0x14f0>
    7774:      	ldr	x0, [sp, #0x28]
    7778:      	ldurb	w10, [x8, #-0x8]
    777c:      	adrp	x9, 0x7000 <_main+0xbd4>
		000000000000777c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__53
    7780:      	ldr	x9, [x9]
		0000000000007780:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__53
    7784:      	cbz	x9, 0x7840 <_main+0x1414>
    7788:      	cmp	w10, #0x2
    778c:      	b.ne	0x7840 <_main+0x1414>
    7790:      	ldurh	w11, [x8, #-0x6]
    7794:      	tbnz	w11, #0xb, 0x7840 <_main+0x1414>
    7798:      	ldr	w11, [x8, #0x4]
    779c:      	orr	x10, x11, #0x4000000000000000
    77a0:      	cbz	w11, 0x786c <_main+0x1440>
    77a4:      	ldr	x12, [x9]
    77a8:      	cmp	x10, x12
    77ac:      	b.ne	0x786c <_main+0x1440>
    77b0:      	ldr	x2, [x9, #0x8]
    77b4:      	tbnz	w2, #0x1e, 0x7db8 <_main+0x198c>
    77b8:      	add	x12, x8, x2, lsl #3
    77bc:      	ldr	d0, [x12, #0x10]
    77c0:      	fmov	x12, d0
    77c4:      	mov	x13, #0x10              ; =16
    77c8:      	movk	x13, #0x7ffc, lsl #48
    77cc:      	cmp	x12, x13
    77d0:      	b.ne	0x793c <_main+0x1510>
    77d4:      	b	0x7898 <_main+0x146c>
    77d8:      	lsr	x9, x8, #48
    77dc:      	mov	w10, #0x7ff9            ; =32761
    77e0:      	cmp	x9, x10
    77e4:      	b.eq	0x7828 <_main+0x13fc>
    77e8:      	mov	w10, #0x7ffe            ; =32766
    77ec:      	cmp	w9, w10
    77f0:      	b.ne	0x7818 <_main+0x13ec>
    77f4:      	adrp	x9, 0x7000 <_main+0xbd4>
		00000000000077f4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    77f8:      	ldr	x9, [x9]
		00000000000077f8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    77fc:      	mov	x0, #0x34               ; =52
    7800:      	movk	x0, #0xddae, lsl #32
    7804:      	movk	x0, #0x5556, lsl #48
    7808:      	and	x2, x9, #0xffffffffffff
    780c:      	mov	x1, x8
    7810:      	bl	0x7810 <_main+0x13e4>
		0000000000007810:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    7814:      	b	0x7938 <_main+0x150c>
    7818:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    781c:      	add	x9, x8, x9
    7820:      	cmp	x9, #0x2
    7824:      	b.lo	0x7e18 <_main+0x19ec>
    7828:      	adrp	x9, 0x7000 <_main+0xbd4>
		0000000000007828:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    782c:      	ldr	x9, [x9]
		000000000000782c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    7830:      	and	x1, x9, #0xffffffffffff
    7834:      	mov	x0, x8
    7838:      	bl	0x7838 <_main+0x140c>
		0000000000007838:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    783c:      	b	0x7938 <_main+0x150c>
    7840:      	cmp	w10, #0x2
    7844:      	b.ne	0x791c <_main+0x14f0>
    7848:      	cbz	x9, 0x791c <_main+0x14f0>
    784c:      	ldr	x10, [x9, #0x10]
    7850:      	cbz	x10, 0x791c <_main+0x14f0>
    7854:      	ldr	x11, [x8, #0x8]
    7858:      	cbz	x11, 0x791c <_main+0x14f0>
    785c:      	ldr	x11, [x11, #0x30]
    7860:      	cmp	x11, x10
    7864:      	b.eq	0x7888 <_main+0x145c>
    7868:      	b	0x791c <_main+0x14f0>
    786c:      	ldr	x12, [x9, #0x10]
    7870:      	cbz	x12, 0x7898 <_main+0x146c>
    7874:      	ldr	x13, [x8, #0x8]
    7878:      	cbz	x13, 0x7898 <_main+0x146c>
    787c:      	ldr	x13, [x13, #0x30]
    7880:      	cmp	x13, x12
    7884:      	b.ne	0x7898 <_main+0x146c>
    7888:      	ldr	x9, [x9, #0x8]
    788c:      	add	x8, x8, x9, lsl #3
    7890:      	ldr	d0, [x8, #0x10]
    7894:      	b	0x793c <_main+0x1510>
    7898:      	ldr	x12, [x9, #0x18]
    789c:      	cmp	x12, #0x0
    78a0:      	b.le	0x791c <_main+0x14f0>
    78a4:      	ldr	x12, [x9, #0x20]
    78a8:      	ldr	x13, [x9, #0x30]
    78ac:      	ldr	x14, [x9, #0x40]
    78b0:      	cmp	x14, x10
    78b4:      	ldr	x15, [x9, #0x50]
    78b8:      	ccmp	x15, x10, #0x4, ne
    78bc:      	ccmp	x13, x10, #0x4, ne
    78c0:      	ccmp	x12, x10, #0x4, ne
    78c4:      	cset	w16, eq
    78c8:      	cbz	w11, 0x791c <_main+0x14f0>
    78cc:      	cbz	w16, 0x791c <_main+0x14f0>
    78d0:      	ldr	x11, [x9, #0x48]
    78d4:      	ldr	x16, [x9, #0x58]
    78d8:      	cmp	x15, x10
    78dc:      	csel	x15, x16, xzr, eq
    78e0:      	cmp	x14, x10
    78e4:      	csel	x11, x11, x15, eq
    78e8:      	ldr	x14, [x9, #0x28]
    78ec:      	ldr	x9, [x9, #0x38]
    78f0:      	cmp	x13, x10
    78f4:      	csel	x9, x9, x11, eq
    78f8:      	cmp	x12, x10
    78fc:      	csel	x9, x14, x9, eq
    7900:      	add	x9, x8, x9, lsl #3
    7904:      	ldr	d0, [x9, #0x10]
    7908:      	fmov	x9, d0
    790c:      	mov	x10, #0x10              ; =16
    7910:      	movk	x10, #0x7ffc, lsl #48
    7914:      	cmp	x9, x10
    7918:      	b.ne	0x793c <_main+0x1510>
    791c:      	adrp	x9, 0x7000 <_main+0xbd4>
		000000000000791c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    7920:      	ldr	x9, [x9]
		0000000000007920:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    7924:      	adrp	x2, 0x7000 <_main+0xbd4>
		0000000000007924:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__53
    7928:      	add	x2, x2, #0x0
		0000000000007928:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__53
    792c:      	and	x1, x9, #0xffffffffffff
    7930:      	mov	x0, x8
    7934:      	bl	0x7934 <_main+0x1508>
		0000000000007934:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    7938:      	ldr	x0, [sp, #0x28]
    793c:      	bl	0x793c <_main+0x1510>
		000000000000793c:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    7940:      	mov	x19, x0
    7944:      	ldr	x20, [sp, #0x30]
    7948:      	ldr	w8, [x22]
    794c:      	cbz	w8, 0x7954 <_main+0x1528>
    7950:      	bl	0x7950 <_main+0x1524>
		0000000000007950:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    7954:      	fmov	d0, x20
    7958:      	mov	x0, x19
    795c:      	bl	0x795c <_main+0x1530>
		000000000000795c:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    7960:      	mov	x19, x0
    7964:      	ldr	w8, [x22]
    7968:      	cbz	w8, 0x7970 <_main+0x1544>
    796c:      	bl	0x796c <_main+0x1540>
		000000000000796c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    7970:      	movi.2d	v0, #0000000000000000
    7974:      	mov	x0, x19
    7978:      	bl	0x7978 <_main+0x154c>
		0000000000007978:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    797c:      	mov	x19, x0
    7980:      	ldr	w8, [x22]
    7984:      	cbz	w8, 0x798c <_main+0x1560>
    7988:      	bl	0x7988 <_main+0x155c>
		0000000000007988:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    798c:      	mov	x0, x19
    7990:      	bl	0x7990 <_main+0x1564>
		0000000000007990:  ARM64_RELOC_BRANCH26	_js_console_log_spread
    7994:      	mov	w0, #0x2                ; =2
    7998:      	bl	0x7998 <_main+0x156c>
		0000000000007998:  ARM64_RELOC_BRANCH26	_js_array_alloc
    799c:      	mov	x19, x0
    79a0:      	ldr	w8, [x22]
    79a4:      	cbz	w8, 0x79ac <_main+0x1580>
    79a8:      	bl	0x79a8 <_main+0x157c>
		00000000000079a8:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    79ac:      	adrp	x8, 0x7000 <_main+0xbd4>
		00000000000079ac:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.14.handle
    79b0:      	ldr	d0, [x8]
		00000000000079b0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.14.handle
    79b4:      	mov	x0, x19
    79b8:      	bl	0x79b8 <_main+0x158c>
		00000000000079b8:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    79bc:      	mov	x19, x0
    79c0:      	ldr	x20, [sp, #0x38]
    79c4:      	ldr	w8, [x22]
    79c8:      	cbz	w8, 0x79d0 <_main+0x15a4>
    79cc:      	bl	0x79cc <_main+0x15a0>
		00000000000079cc:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    79d0:      	lsr	x8, x20, #48
    79d4:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    79d8:      	and	x9, x20, x9
    79dc:      	mov	x10, #0x7ffd000000000000 ; =9222527611924643840
    79e0:      	cmp	x9, x10
    79e4:      	b.ne	0x7a14 <_main+0x15e8>
    79e8:      	and	x0, x20, #0xffffffffffff
    79ec:      	mov	w9, #0x7fff             ; =32767
    79f0:      	cmp	x8, x9
    79f4:      	b.ne	0x7a54 <_main+0x1628>
    79f8:      	adrp	x8, 0x7000 <_main+0xbd4>
		00000000000079f8:  ARM64_RELOC_PAGE21	_perry_null_guard_zero_access_worker_ts
    79fc:      	add	x8, x8, #0x0
		00000000000079fc:  ARM64_RELOC_PAGEOFF12	_perry_null_guard_zero_access_worker_ts
    7a00:      	cmp	x0, #0x1, lsl #12       ; =0x1000
    7a04:      	csel	x8, x8, x0, lo
    7a08:      	ldr	s0, [x8]
    7a0c:      	ucvtf	d0, d0
    7a10:      	b	0x7c0c <_main+0x17e0>
    7a14:      	mov	w9, #0x7ff9             ; =32761
    7a18:      	cmp	x8, x9
    7a1c:      	b.eq	0x7abc <_main+0x1690>
    7a20:      	mov	w9, #0x7ffe             ; =32766
    7a24:      	cmp	w8, w9
    7a28:      	b.ne	0x7ac8 <_main+0x169c>
    7a2c:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007a2c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    7a30:      	ldr	x8, [x8]
		0000000000007a30:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    7a34:      	str	x19, [sp, #0x38]
    7a38:      	mov	x0, #0x36               ; =54
    7a3c:      	movk	x0, #0xddae, lsl #32
    7a40:      	movk	x0, #0x5556, lsl #48
    7a44:      	and	x2, x8, #0xffffffffffff
    7a48:      	mov	x1, x20
    7a4c:      	bl	0x7a4c <_main+0x1620>
		0000000000007a4c:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    7a50:      	b	0x7c08 <_main+0x17dc>
    7a54:      	lsr	x8, x0, #20
    7a58:      	cbz	x8, 0x7bec <_main+0x17c0>
    7a5c:      	ldurb	w9, [x0, #-0x8]
    7a60:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007a60:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__55
    7a64:      	ldr	x8, [x8]
		0000000000007a64:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__55
    7a68:      	cbz	x8, 0x7af4 <_main+0x16c8>
    7a6c:      	cmp	w9, #0x2
    7a70:      	b.ne	0x7af4 <_main+0x16c8>
    7a74:      	ldurh	w10, [x0, #-0x6]
    7a78:      	tbnz	w10, #0xb, 0x7af4 <_main+0x16c8>
    7a7c:      	ldr	w10, [x0, #0x4]
    7a80:      	orr	x9, x10, #0x4000000000000000
    7a84:      	cbz	w10, 0x7b3c <_main+0x1710>
    7a88:      	ldr	x11, [x8]
    7a8c:      	cmp	x9, x11
    7a90:      	b.ne	0x7b3c <_main+0x1710>
    7a94:      	ldr	x2, [x8, #0x8]
    7a98:      	tbnz	w2, #0x1e, 0x7df8 <_main+0x19cc>
    7a9c:      	add	x11, x0, x2, lsl #3
    7aa0:      	ldr	d0, [x11, #0x10]
    7aa4:      	fmov	x11, d0
    7aa8:      	mov	x12, #0x10              ; =16
    7aac:      	movk	x12, #0x7ffc, lsl #48
    7ab0:      	cmp	x11, x12
    7ab4:      	b.ne	0x7c0c <_main+0x17e0>
    7ab8:      	b	0x7b68 <_main+0x173c>
    7abc:      	ubfx	x8, x20, #40, #8
    7ac0:      	ucvtf	d0, x8
    7ac4:      	b	0x7c0c <_main+0x17e0>
    7ac8:      	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
    7acc:      	add	x8, x20, x8
    7ad0:      	cmp	x8, #0x2
    7ad4:      	b.lo	0x7ebc <_main+0x1a90>
    7ad8:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007ad8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    7adc:      	ldr	x8, [x8]
		0000000000007adc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    7ae0:      	str	x19, [sp, #0x38]
    7ae4:      	and	x1, x8, #0xffffffffffff
    7ae8:      	mov	x0, x20
    7aec:      	bl	0x7aec <_main+0x16c0>
		0000000000007aec:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    7af0:      	b	0x7c08 <_main+0x17dc>
    7af4:      	cmp	w9, #0x2
    7af8:      	b.ne	0x7bec <_main+0x17c0>
    7afc:      	cbz	x8, 0x7bec <_main+0x17c0>
    7b00:      	ldr	x9, [x8, #0x10]
    7b04:      	cbz	x9, 0x7bec <_main+0x17c0>
    7b08:      	ldr	x10, [x0, #0x8]
    7b0c:      	cbz	x10, 0x7bec <_main+0x17c0>
    7b10:      	ldr	x10, [x10, #0x30]
    7b14:      	cmp	x10, x9
    7b18:      	b.eq	0x7b58 <_main+0x172c>
    7b1c:      	b	0x7bec <_main+0x17c0>
    7b20:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007b20:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    7b24:      	ldr	x8, [x8]
		0000000000007b24:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    7b28:      	adrp	x3, 0x7000 <_main+0xbd4>
		0000000000007b28:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__43
    7b2c:      	add	x3, x3, #0x0
		0000000000007b2c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__43
    7b30:      	and	x1, x8, #0xffffffffffff
    7b34:      	bl	0x7b34 <_main+0x1708>
		0000000000007b34:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7b38:      	b	0x6cc4 <_main+0x898>
    7b3c:      	ldr	x11, [x8, #0x10]
    7b40:      	cbz	x11, 0x7b68 <_main+0x173c>
    7b44:      	ldr	x12, [x0, #0x8]
    7b48:      	cbz	x12, 0x7b68 <_main+0x173c>
    7b4c:      	ldr	x12, [x12, #0x30]
    7b50:      	cmp	x12, x11
    7b54:      	b.ne	0x7b68 <_main+0x173c>
    7b58:      	ldr	x8, [x8, #0x8]
    7b5c:      	add	x8, x0, x8, lsl #3
    7b60:      	ldr	d0, [x8, #0x10]
    7b64:      	b	0x7c0c <_main+0x17e0>
    7b68:      	ldr	x11, [x8, #0x18]
    7b6c:      	cmp	x11, #0x0
    7b70:      	b.le	0x7bec <_main+0x17c0>
    7b74:      	ldr	x11, [x8, #0x20]
    7b78:      	ldr	x12, [x8, #0x30]
    7b7c:      	ldr	x13, [x8, #0x40]
    7b80:      	cmp	x13, x9
    7b84:      	ldr	x14, [x8, #0x50]
    7b88:      	ccmp	x14, x9, #0x4, ne
    7b8c:      	ccmp	x12, x9, #0x4, ne
    7b90:      	ccmp	x11, x9, #0x4, ne
    7b94:      	cset	w15, eq
    7b98:      	cbz	w10, 0x7bec <_main+0x17c0>
    7b9c:      	cbz	w15, 0x7bec <_main+0x17c0>
    7ba0:      	ldr	x10, [x8, #0x48]
    7ba4:      	ldr	x15, [x8, #0x58]
    7ba8:      	cmp	x14, x9
    7bac:      	csel	x14, x15, xzr, eq
    7bb0:      	cmp	x13, x9
    7bb4:      	csel	x10, x10, x14, eq
    7bb8:      	ldr	x13, [x8, #0x28]
    7bbc:      	ldr	x8, [x8, #0x38]
    7bc0:      	cmp	x12, x9
    7bc4:      	csel	x8, x8, x10, eq
    7bc8:      	cmp	x11, x9
    7bcc:      	csel	x8, x13, x8, eq
    7bd0:      	add	x8, x0, x8, lsl #3
    7bd4:      	ldr	d0, [x8, #0x10]
    7bd8:      	fmov	x8, d0
    7bdc:      	mov	x9, #0x10               ; =16
    7be0:      	movk	x9, #0x7ffc, lsl #48
    7be4:      	cmp	x8, x9
    7be8:      	b.ne	0x7c0c <_main+0x17e0>
    7bec:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007bec:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    7bf0:      	ldr	x8, [x8]
		0000000000007bf0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    7bf4:      	str	x19, [sp, #0x38]
    7bf8:      	adrp	x2, 0x7000 <_main+0xbd4>
		0000000000007bf8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__55
    7bfc:      	add	x2, x2, #0x0
		0000000000007bfc:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__55
    7c00:      	and	x1, x8, #0xffffffffffff
    7c04:      	bl	0x7c04 <_main+0x17d8>
		0000000000007c04:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    7c08:      	ldr	x19, [sp, #0x38]
    7c0c:      	mov	x0, x19
    7c10:      	bl	0x7c10 <_main+0x17e4>
		0000000000007c10:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    7c14:      	mov	x19, x0
    7c18:      	ldr	w8, [x22]
    7c1c:      	cbz	w8, 0x7c24 <_main+0x17f8>
    7c20:      	bl	0x7c20 <_main+0x17f4>
		0000000000007c20:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    7c24:      	mov	x0, x19
    7c28:      	bl	0x7c28 <_main+0x17fc>
		0000000000007c28:  ARM64_RELOC_BRANCH26	_js_console_log_spread
    7c2c:      	bl	0x7c2c <_main+0x1800>
		0000000000007c2c:  ARM64_RELOC_BRANCH26	_js_promise_run_microtasks_event_loop
    7c30:      	bl	0x7c30 <_main+0x1804>
		0000000000007c30:  ARM64_RELOC_BRANCH26	_js_promise_run_microtasks_event_loop
    7c34:      	bl	0x7c34 <_main+0x1808>
		0000000000007c34:  ARM64_RELOC_BRANCH26	_js_promise_run_microtasks_event_loop
    7c38:      	bl	0x7c38 <_main+0x180c>
		0000000000007c38:  ARM64_RELOC_BRANCH26	_js_promise_run_microtasks_event_loop
    7c3c:      	bl	0x7c3c <_main+0x1810>
		0000000000007c3c:  ARM64_RELOC_BRANCH26	_js_run_stdlib_pump
    7c40:      	bl	0x7c40 <_main+0x1814>
		0000000000007c40:  ARM64_RELOC_BRANCH26	_js_event_loop_host_driven
    7c44:      	cbnz	w0, 0x7ce0 <_main+0x18b4>
    7c48:      	bl	0x7c48 <_main+0x181c>
		0000000000007c48:  ARM64_RELOC_BRANCH26	_js_timer_has_pending
    7c4c:      	mov	x19, x0
    7c50:      	bl	0x7c50 <_main+0x1824>
		0000000000007c50:  ARM64_RELOC_BRANCH26	_js_callback_timer_has_pending
    7c54:      	mov	x20, x0
    7c58:      	bl	0x7c58 <_main+0x182c>
		0000000000007c58:  ARM64_RELOC_BRANCH26	_js_interval_timer_has_pending
    7c5c:      	mov	x21, x0
    7c60:      	bl	0x7c60 <_main+0x1834>
		0000000000007c60:  ARM64_RELOC_BRANCH26	_js_stdlib_has_active_handles
    7c64:      	mov	x22, x0
    7c68:      	bl	0x7c68 <_main+0x183c>
		0000000000007c68:  ARM64_RELOC_BRANCH26	_js_bun_ffi_has_active_threadsafe_callbacks
    7c6c:      	mov	x23, x0
    7c70:      	bl	0x7c70 <_main+0x1844>
		0000000000007c70:  ARM64_RELOC_BRANCH26	_js_microtasks_pending
    7c74:      	orr	w8, w20, w19
    7c78:      	orr	w9, w21, w22
    7c7c:      	orr	w8, w8, w9
    7c80:      	orr	w9, w23, w0
    7c84:      	orr	w8, w8, w9
    7c88:      	cbz	w8, 0x7d0c <_main+0x18e0>
    7c8c:      	bl	0x7c8c <_main+0x1860>
		0000000000007c8c:  ARM64_RELOC_BRANCH26	_js_promise_run_microtasks_event_loop
    7c90:      	bl	0x7c90 <_main+0x1864>
		0000000000007c90:  ARM64_RELOC_BRANCH26	_js_run_stdlib_pump
    7c94:      	bl	0x7c94 <_main+0x1868>
		0000000000007c94:  ARM64_RELOC_BRANCH26	_js_timer_has_pending
    7c98:      	mov	x19, x0
    7c9c:      	bl	0x7c9c <_main+0x1870>
		0000000000007c9c:  ARM64_RELOC_BRANCH26	_js_callback_timer_has_pending
    7ca0:      	mov	x20, x0
    7ca4:      	bl	0x7ca4 <_main+0x1878>
		0000000000007ca4:  ARM64_RELOC_BRANCH26	_js_interval_timer_has_pending
    7ca8:      	mov	x21, x0
    7cac:      	bl	0x7cac <_main+0x1880>
		0000000000007cac:  ARM64_RELOC_BRANCH26	_js_stdlib_has_active_handles
    7cb0:      	mov	x22, x0
    7cb4:      	bl	0x7cb4 <_main+0x1888>
		0000000000007cb4:  ARM64_RELOC_BRANCH26	_js_bun_ffi_has_active_threadsafe_callbacks
    7cb8:      	mov	x23, x0
    7cbc:      	bl	0x7cbc <_main+0x1890>
		0000000000007cbc:  ARM64_RELOC_BRANCH26	_js_microtasks_pending
    7cc0:      	orr	w8, w20, w19
    7cc4:      	orr	w9, w21, w22
    7cc8:      	orr	w8, w8, w9
    7ccc:      	orr	w9, w23, w0
    7cd0:      	orr	w8, w8, w9
    7cd4:      	cbz	w8, 0x7c40 <_main+0x1814>
    7cd8:      	bl	0x7cd8 <_main+0x18ac>
		0000000000007cd8:  ARM64_RELOC_BRANCH26	_js_wait_for_event
    7cdc:      	b	0x7c40 <_main+0x1814>
    7ce0:      	mov	w19, #0x0               ; =0
    7ce4:      	bl	0x7ce4 <_main+0x18b8>
		0000000000007ce4:  ARM64_RELOC_BRANCH26	_js_typed_feedback_maybe_dump_trace
    7ce8:      	mov	x0, x19
    7cec:      	ldp	x29, x30, [sp, #0x90]
    7cf0:      	ldp	x20, x19, [sp, #0x80]
    7cf4:      	ldp	x22, x21, [sp, #0x70]
    7cf8:      	ldp	x24, x23, [sp, #0x60]
    7cfc:      	ldp	d9, d8, [sp, #0x50]
    7d00:      	ldp	d11, d10, [sp, #0x40]
    7d04:      	add	sp, sp, #0xa0
    7d08:      	ret
    7d0c:      	bl	0x7d0c <_main+0x18e0>
		0000000000007d0c:  ARM64_RELOC_BRANCH26	_js_process_emit_before_exit_pending
    7d10:      	bl	0x7d10 <_main+0x18e4>
		0000000000007d10:  ARM64_RELOC_BRANCH26	_js_promise_run_microtasks_event_loop
    7d14:      	bl	0x7d14 <_main+0x18e8>
		0000000000007d14:  ARM64_RELOC_BRANCH26	_js_process_run_exit_sequence
    7d18:      	bl	0x7d18 <_main+0x18ec>
		0000000000007d18:  ARM64_RELOC_BRANCH26	_js_process_run_finalization_exit
    7d1c:      	bl	0x7d1c <_main+0x18f0>
		0000000000007d1c:  ARM64_RELOC_BRANCH26	_js_promise_run_promise_jobs
    7d20:      	bl	0x7d20 <_main+0x18f4>
		0000000000007d20:  ARM64_RELOC_BRANCH26	_js_trace_events_flush_output
    7d24:      	bl	0x7d24 <_main+0x18f8>
		0000000000007d24:  ARM64_RELOC_BRANCH26	_js_promise_report_unhandled_rejections
    7d28:      	bl	0x7d28 <_main+0x18fc>
		0000000000007d28:  ARM64_RELOC_BRANCH26	_js_gc_release_current_thread_collection_side_allocations
    7d2c:      	bl	0x7d2c <_main+0x1900>
		0000000000007d2c:  ARM64_RELOC_BRANCH26	_js_process_pending_exit_code
    7d30:      	mov	x19, x0
    7d34:      	b	0x7ce4 <_main+0x18b8>
    7d38:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007d38:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    7d3c:      	ldr	x8, [x8]
		0000000000007d3c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    7d40:      	str	x19, [sp, #0x10]
    7d44:      	adrp	x3, 0x7000 <_main+0xbd4>
		0000000000007d44:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__45
    7d48:      	add	x3, x3, #0x0
		0000000000007d48:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__45
    7d4c:      	and	x1, x8, #0xffffffffffff
    7d50:      	bl	0x7d50 <_main+0x1924>
		0000000000007d50:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7d54:      	b	0x7050 <_main+0xc24>
    7d58:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007d58:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    7d5c:      	ldr	x8, [x8]
		0000000000007d5c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    7d60:      	stp	x19, x21, [sp, #0x8]
    7d64:      	adrp	x3, 0x7000 <_main+0xbd4>
		0000000000007d64:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__47
    7d68:      	add	x3, x3, #0x0
		0000000000007d68:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__47
    7d6c:      	and	x1, x8, #0xffffffffffff
    7d70:      	bl	0x7d70 <_main+0x1944>
		0000000000007d70:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7d74:      	b	0x7254 <_main+0xe28>
    7d78:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007d78:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    7d7c:      	ldr	x8, [x8]
		0000000000007d7c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    7d80:      	str	x19, [sp, #0x18]
    7d84:      	adrp	x3, 0x7000 <_main+0xbd4>
		0000000000007d84:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__49
    7d88:      	add	x3, x3, #0x0
		0000000000007d88:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__49
    7d8c:      	and	x1, x8, #0xffffffffffff
    7d90:      	bl	0x7d90 <_main+0x1964>
		0000000000007d90:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7d94:      	b	0x74b4 <_main+0x1088>
    7d98:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007d98:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    7d9c:      	ldr	x8, [x8]
		0000000000007d9c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    7da0:      	stp	x19, x21, [sp, #0x18]
    7da4:      	adrp	x3, 0x7000 <_main+0xbd4>
		0000000000007da4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__51
    7da8:      	add	x3, x3, #0x0
		0000000000007da8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__51
    7dac:      	and	x1, x8, #0xffffffffffff
    7db0:      	bl	0x7db0 <_main+0x1984>
		0000000000007db0:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7db4:      	b	0x76b4 <_main+0x1288>
    7db8:      	adrp	x9, 0x7000 <_main+0xbd4>
		0000000000007db8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    7dbc:      	ldr	x9, [x9]
		0000000000007dbc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    7dc0:      	adrp	x3, 0x7000 <_main+0xbd4>
		0000000000007dc0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__53
    7dc4:      	add	x3, x3, #0x0
		0000000000007dc4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__53
    7dc8:      	and	x1, x9, #0xffffffffffff
    7dcc:      	mov	x0, x8
    7dd0:      	bl	0x7dd0 <_main+0x19a4>
		0000000000007dd0:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7dd4:      	b	0x7938 <_main+0x150c>
    7dd8:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007dd8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    7ddc:      	ldr	x8, [x8]
		0000000000007ddc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    7de0:      	str	x19, [sp, #0x38]
    7de4:      	adrp	x3, 0x7000 <_main+0xbd4>
		0000000000007de4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__41
    7de8:      	add	x3, x3, #0x0
		0000000000007de8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__41
    7dec:      	and	x1, x8, #0xffffffffffff
    7df0:      	bl	0x7df0 <_main+0x19c4>
		0000000000007df0:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7df4:      	b	0x6aa0 <_main+0x674>
    7df8:      	adrp	x8, 0x7000 <_main+0xbd4>
		0000000000007df8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    7dfc:      	ldr	x8, [x8]
		0000000000007dfc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    7e00:      	str	x19, [sp, #0x38]
    7e04:      	adrp	x3, 0x7000 <_main+0xbd4>
		0000000000007e04:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__55
    7e08:      	add	x3, x3, #0x0
		0000000000007e08:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__55
    7e0c:      	and	x1, x8, #0xffffffffffff
    7e10:      	bl	0x7e10 <_main+0x19e4>
		0000000000007e10:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7e14:      	b	0x7c08 <_main+0x17dc>
    7e18:      	mov	x9, #0x10               ; =16
    7e1c:      	movk	x9, #0x7ffc, lsl #48
    7e20:      	sub	x9, x9, #0xe
    7e24:      	cmp	x8, x9
    7e28:      	cset	w0, eq
    7e2c:      	adrp	x1, 0x7000 <_main+0xbd4>
		0000000000007e2c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.10.bytes
    7e30:      	add	x1, x1, #0x0
		0000000000007e30:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.10.bytes
    7e34:      	mov	w2, #0x3                ; =3
    7e38:      	b	0x7edc <_main+0x1ab0>
    7e3c:      	mov	x9, #0x10               ; =16
    7e40:      	movk	x9, #0x7ffc, lsl #48
    7e44:      	sub	x9, x9, #0xe
    7e48:      	cmp	x8, x9
    7e4c:      	b	0x7ecc <_main+0x1aa0>
    7e50:      	mov	x8, #0x10               ; =16
    7e54:      	movk	x8, #0x7ffc, lsl #48
    7e58:      	sub	x8, x8, #0xe
    7e5c:      	cmp	x21, x8
    7e60:      	b	0x7e74 <_main+0x1a48>
    7e64:      	mov	x8, #0x10               ; =16
    7e68:      	movk	x8, #0x7ffc, lsl #48
    7e6c:      	sub	x8, x8, #0xe
    7e70:      	cmp	x20, x8
    7e74:      	cset	w0, eq
    7e78:      	adrp	x1, 0x7000 <_main+0xbd4>
		0000000000007e78:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.12.bytes
    7e7c:      	add	x1, x1, #0x0
		0000000000007e7c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.12.bytes
    7e80:      	mov	w2, #0x4                ; =4
    7e84:      	b	0x7edc <_main+0x1ab0>
    7e88:      	mov	x8, #0x10               ; =16
    7e8c:      	movk	x8, #0x7ffc, lsl #48
    7e90:      	sub	x8, x8, #0xe
    7e94:      	cmp	x21, x8
    7e98:      	b	0x7eac <_main+0x1a80>
    7e9c:      	mov	x8, #0x10               ; =16
    7ea0:      	movk	x8, #0x7ffc, lsl #48
    7ea4:      	sub	x8, x8, #0xe
    7ea8:      	cmp	x20, x8
    7eac:      	cset	w0, eq
    7eb0:      	adrp	x1, 0x7000 <_main+0xbd4>
		0000000000007eb0:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.13.bytes
    7eb4:      	add	x1, x1, #0x0
		0000000000007eb4:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.13.bytes
    7eb8:      	b	0x7ed8 <_main+0x1aac>
    7ebc:      	mov	x8, #0x10               ; =16
    7ec0:      	movk	x8, #0x7ffc, lsl #48
    7ec4:      	sub	x8, x8, #0xe
    7ec8:      	cmp	x20, x8
    7ecc:      	cset	w0, eq
    7ed0:      	adrp	x1, 0x7000 <_main+0xbd4>
		0000000000007ed0:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.9.bytes
    7ed4:      	add	x1, x1, #0x0
		0000000000007ed4:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.9.bytes
    7ed8:      	mov	w2, #0x6                ; =6
    7edc:      	bl	0x7edc <_main+0x1ab0>
		0000000000007edc:  ARM64_RELOC_BRANCH26	_js_throw_type_error_property_access
    7ee0:      	brk	#0x1

0000000000007ee4 <___perry_init_strings_access_worker_ts_chunk0>:
    7ee4:      	stp	x20, x19, [sp, #-0x20]!
    7ee8:      	stp	x29, x30, [sp, #0x10]
    7eec:      	add	x29, sp, #0x10
    7ef0:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007ef0:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.0.bytes
    7ef4:      	add	x0, x0, #0x0
		0000000000007ef4:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.0.bytes
    7ef8:      	mov	w1, #0x6                ; =6
    7efc:      	bl	0x7efc <___perry_init_strings_access_worker_ts_chunk0+0x18>
		0000000000007efc:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7f00:      	bl	0x7f00 <___perry_init_strings_access_worker_ts_chunk0+0x1c>
		0000000000007f00:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7f04:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007f04:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.0.handle
    7f08:      	add	x0, x0, #0x0
		0000000000007f08:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.0.handle
    7f0c:      	str	d0, [x0]
    7f10:      	bl	0x7f10 <___perry_init_strings_access_worker_ts_chunk0+0x2c>
		0000000000007f10:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7f14:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007f14:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    7f18:      	add	x0, x0, #0x0
		0000000000007f18:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    7f1c:      	mov	w1, #0x2                ; =2
    7f20:      	bl	0x7f20 <___perry_init_strings_access_worker_ts_chunk0+0x3c>
		0000000000007f20:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7f24:      	bl	0x7f24 <___perry_init_strings_access_worker_ts_chunk0+0x40>
		0000000000007f24:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7f28:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007f28:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    7f2c:      	add	x0, x0, #0x0
		0000000000007f2c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    7f30:      	str	d0, [x0]
    7f34:      	bl	0x7f34 <___perry_init_strings_access_worker_ts_chunk0+0x50>
		0000000000007f34:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7f38:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007f38:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.2.bytes
    7f3c:      	add	x0, x0, #0x0
		0000000000007f3c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.2.bytes
    7f40:      	mov	w1, #0x6                ; =6
    7f44:      	bl	0x7f44 <___perry_init_strings_access_worker_ts_chunk0+0x60>
		0000000000007f44:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7f48:      	bl	0x7f48 <___perry_init_strings_access_worker_ts_chunk0+0x64>
		0000000000007f48:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7f4c:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007f4c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.2.handle
    7f50:      	add	x0, x0, #0x0
		0000000000007f50:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.2.handle
    7f54:      	str	d0, [x0]
    7f58:      	bl	0x7f58 <___perry_init_strings_access_worker_ts_chunk0+0x74>
		0000000000007f58:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7f5c:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007f5c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.3.bytes
    7f60:      	add	x0, x0, #0x0
		0000000000007f60:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.3.bytes
    7f64:      	mov	w1, #0x6                ; =6
    7f68:      	bl	0x7f68 <___perry_init_strings_access_worker_ts_chunk0+0x84>
		0000000000007f68:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7f6c:      	bl	0x7f6c <___perry_init_strings_access_worker_ts_chunk0+0x88>
		0000000000007f6c:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7f70:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007f70:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.3.handle
    7f74:      	add	x0, x0, #0x0
		0000000000007f74:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.3.handle
    7f78:      	str	d0, [x0]
    7f7c:      	bl	0x7f7c <___perry_init_strings_access_worker_ts_chunk0+0x98>
		0000000000007f7c:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7f80:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007f80:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.4.bytes
    7f84:      	add	x0, x0, #0x0
		0000000000007f84:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.4.bytes
    7f88:      	mov	w1, #0x4                ; =4
    7f8c:      	bl	0x7f8c <___perry_init_strings_access_worker_ts_chunk0+0xa8>
		0000000000007f8c:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7f90:      	bl	0x7f90 <___perry_init_strings_access_worker_ts_chunk0+0xac>
		0000000000007f90:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7f94:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007f94:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    7f98:      	add	x0, x0, #0x0
		0000000000007f98:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    7f9c:      	str	d0, [x0]
    7fa0:      	bl	0x7fa0 <___perry_init_strings_access_worker_ts_chunk0+0xbc>
		0000000000007fa0:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7fa4:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007fa4:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.5.bytes
    7fa8:      	add	x0, x0, #0x0
		0000000000007fa8:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.5.bytes
    7fac:      	mov	w1, #0x6                ; =6
    7fb0:      	bl	0x7fb0 <___perry_init_strings_access_worker_ts_chunk0+0xcc>
		0000000000007fb0:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7fb4:      	bl	0x7fb4 <___perry_init_strings_access_worker_ts_chunk0+0xd0>
		0000000000007fb4:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7fb8:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007fb8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    7fbc:      	add	x0, x0, #0x0
		0000000000007fbc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    7fc0:      	str	d0, [x0]
    7fc4:      	bl	0x7fc4 <___perry_init_strings_access_worker_ts_chunk0+0xe0>
		0000000000007fc4:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7fc8:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007fc8:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.6.bytes
    7fcc:      	add	x0, x0, #0x0
		0000000000007fcc:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.6.bytes
    7fd0:      	mov	w1, #0x2                ; =2
    7fd4:      	bl	0x7fd4 <___perry_init_strings_access_worker_ts_chunk0+0xf0>
		0000000000007fd4:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7fd8:      	bl	0x7fd8 <___perry_init_strings_access_worker_ts_chunk0+0xf4>
		0000000000007fd8:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7fdc:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007fdc:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.6.handle
    7fe0:      	add	x0, x0, #0x0
		0000000000007fe0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.6.handle
    7fe4:      	str	d0, [x0]
    7fe8:      	bl	0x7fe8 <___perry_init_strings_access_worker_ts_chunk0+0x104>
		0000000000007fe8:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7fec:      	adrp	x0, 0x7000 <_main+0xbd4>
		0000000000007fec:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.7.bytes
    7ff0:      	add	x0, x0, #0x0
		0000000000007ff0:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.7.bytes
    7ff4:      	mov	w1, #0xc                ; =12
    7ff8:      	bl	0x7ff8 <___perry_init_strings_access_worker_ts_chunk0+0x114>
		0000000000007ff8:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7ffc:      	bl	0x7ffc <___perry_init_strings_access_worker_ts_chunk0+0x118>
		0000000000007ffc:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    8000:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		0000000000008000:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.7.handle
    8004:      	add	x0, x0, #0x0
		0000000000008004:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.7.handle
    8008:      	str	d0, [x0]
    800c:      	bl	0x800c <___perry_init_strings_access_worker_ts_chunk0+0x128>
		000000000000800c:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    8010:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		0000000000008010:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.8.bytes
    8014:      	add	x0, x0, #0x0
		0000000000008014:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.8.bytes
    8018:      	mov	w1, #0x4                ; =4
    801c:      	bl	0x801c <___perry_init_strings_access_worker_ts_chunk0+0x138>
		000000000000801c:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    8020:      	bl	0x8020 <___perry_init_strings_access_worker_ts_chunk0+0x13c>
		0000000000008020:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    8024:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		0000000000008024:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.8.handle
    8028:      	add	x0, x0, #0x0
		0000000000008028:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.8.handle
    802c:      	str	d0, [x0]
    8030:      	bl	0x8030 <___perry_init_strings_access_worker_ts_chunk0+0x14c>
		0000000000008030:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    8034:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		0000000000008034:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.9.bytes
    8038:      	add	x0, x0, #0x0
		0000000000008038:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.9.bytes
    803c:      	mov	w1, #0x6                ; =6
    8040:      	bl	0x8040 <___perry_init_strings_access_worker_ts_chunk0+0x15c>
		0000000000008040:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    8044:      	bl	0x8044 <___perry_init_strings_access_worker_ts_chunk0+0x160>
		0000000000008044:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    8048:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		0000000000008048:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    804c:      	add	x0, x0, #0x0
		000000000000804c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    8050:      	str	d0, [x0]
    8054:      	bl	0x8054 <___perry_init_strings_access_worker_ts_chunk0+0x170>
		0000000000008054:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    8058:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		0000000000008058:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.10.bytes
    805c:      	add	x0, x0, #0x0
		000000000000805c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.10.bytes
    8060:      	mov	w1, #0x3                ; =3
    8064:      	bl	0x8064 <___perry_init_strings_access_worker_ts_chunk0+0x180>
		0000000000008064:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    8068:      	bl	0x8068 <___perry_init_strings_access_worker_ts_chunk0+0x184>
		0000000000008068:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    806c:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		000000000000806c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    8070:      	add	x0, x0, #0x0
		0000000000008070:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    8074:      	str	d0, [x0]
    8078:      	bl	0x8078 <___perry_init_strings_access_worker_ts_chunk0+0x194>
		0000000000008078:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    807c:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		000000000000807c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.11.bytes
    8080:      	add	x0, x0, #0x0
		0000000000008080:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.11.bytes
    8084:      	mov	w1, #0x6                ; =6
    8088:      	bl	0x8088 <___perry_init_strings_access_worker_ts_chunk0+0x1a4>
		0000000000008088:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    808c:      	bl	0x808c <___perry_init_strings_access_worker_ts_chunk0+0x1a8>
		000000000000808c:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    8090:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		0000000000008090:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.11.handle
    8094:      	add	x0, x0, #0x0
		0000000000008094:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.11.handle
    8098:      	str	d0, [x0]
    809c:      	bl	0x809c <___perry_init_strings_access_worker_ts_chunk0+0x1b8>
		000000000000809c:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    80a0:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		00000000000080a0:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.12.bytes
    80a4:      	add	x0, x0, #0x0
		00000000000080a4:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.12.bytes
    80a8:      	mov	w1, #0x4                ; =4
    80ac:      	bl	0x80ac <___perry_init_strings_access_worker_ts_chunk0+0x1c8>
		00000000000080ac:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    80b0:      	bl	0x80b0 <___perry_init_strings_access_worker_ts_chunk0+0x1cc>
		00000000000080b0:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    80b4:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		00000000000080b4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    80b8:      	add	x0, x0, #0x0
		00000000000080b8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    80bc:      	str	d0, [x0]
    80c0:      	bl	0x80c0 <___perry_init_strings_access_worker_ts_chunk0+0x1dc>
		00000000000080c0:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    80c4:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		00000000000080c4:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.13.bytes
    80c8:      	add	x0, x0, #0x0
		00000000000080c8:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.13.bytes
    80cc:      	mov	w1, #0x6                ; =6
    80d0:      	bl	0x80d0 <___perry_init_strings_access_worker_ts_chunk0+0x1ec>
		00000000000080d0:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    80d4:      	bl	0x80d4 <___perry_init_strings_access_worker_ts_chunk0+0x1f0>
		00000000000080d4:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    80d8:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		00000000000080d8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    80dc:      	add	x0, x0, #0x0
		00000000000080dc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    80e0:      	str	d0, [x0]
    80e4:      	bl	0x80e4 <___perry_init_strings_access_worker_ts_chunk0+0x200>
		00000000000080e4:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    80e8:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		00000000000080e8:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.14.bytes
    80ec:      	add	x0, x0, #0x0
		00000000000080ec:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.14.bytes
    80f0:      	mov	w1, #0x4                ; =4
    80f4:      	bl	0x80f4 <___perry_init_strings_access_worker_ts_chunk0+0x210>
		00000000000080f4:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    80f8:      	bl	0x80f8 <___perry_init_strings_access_worker_ts_chunk0+0x214>
		00000000000080f8:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    80fc:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		00000000000080fc:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.14.handle
    8100:      	add	x0, x0, #0x0
		0000000000008100:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.14.handle
    8104:      	str	d0, [x0]
    8108:      	bl	0x8108 <___perry_init_strings_access_worker_ts_chunk0+0x224>
		0000000000008108:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    810c:      	adrp	x19, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		000000000000810c:  ARM64_RELOC_PAGE21	___perry_wrap_perry_fn_access_worker_ts__run
    8110:      	add	x19, x19, #0x0
		0000000000008110:  ARM64_RELOC_PAGEOFF12	___perry_wrap_perry_fn_access_worker_ts__run
    8114:      	adrp	x20, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		0000000000008114:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1
    8118:      	add	x20, x20, #0x0
		0000000000008118:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1
    811c:      	mov	x0, x19
    8120:      	mov	x1, x20
    8124:      	mov	w2, #0x3                ; =3
    8128:      	bl	0x8128 <___perry_init_strings_access_worker_ts_chunk0+0x244>
		0000000000008128:  ARM64_RELOC_BRANCH26	_js_register_function_name_static
    812c:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		000000000000812c:  ARM64_RELOC_PAGE21	_perry_fn_access_worker_ts__run
    8130:      	add	x0, x0, #0x0
		0000000000008130:  ARM64_RELOC_PAGEOFF12	_perry_fn_access_worker_ts__run
    8134:      	mov	x1, x20
    8138:      	mov	w2, #0x3                ; =3
    813c:      	bl	0x813c <___perry_init_strings_access_worker_ts_chunk0+0x258>
		000000000000813c:  ARM64_RELOC_BRANCH26	_js_register_function_name_static
    8140:      	adrp	x1, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x11c>
		0000000000008140:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.2
    8144:      	add	x1, x1, #0x0
		0000000000008144:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.2
    8148:      	mov	x0, x19
    814c:      	mov	w2, #0x319              ; =793
    8150:      	mov	w3, #0x0                ; =0
    8154:      	bl	0x8154 <___perry_init_strings_access_worker_ts_chunk0+0x270>
		0000000000008154:  ARM64_RELOC_BRANCH26	_js_register_function_source_static
    8158:      	mov	x0, x19
    815c:      	mov	w1, #0x2                ; =2
    8160:      	bl	0x8160 <___perry_init_strings_access_worker_ts_chunk0+0x27c>
		0000000000008160:  ARM64_RELOC_BRANCH26	_js_register_closure_arity
    8164:      	mov	x0, x19
    8168:      	mov	w1, #0x2                ; =2
    816c:      	bl	0x816c <___perry_init_strings_access_worker_ts_chunk0+0x288>
		000000000000816c:  ARM64_RELOC_BRANCH26	_js_register_closure_length
    8170:      	mov	x0, x19
    8174:      	ldp	x29, x30, [sp, #0x10]
    8178:      	ldp	x20, x19, [sp], #0x20
    817c:      	b	0x817c <___perry_init_strings_access_worker_ts_chunk0+0x298>
		000000000000817c:  ARM64_RELOC_BRANCH26	_js_register_closure_strict_function

0000000000008180 <___perry_init_strings_access_worker_ts>:
    8180:      	b	0x8180 <___perry_init_strings_access_worker_ts>
		0000000000008180:  ARM64_RELOC_BRANCH26	___perry_init_strings_access_worker_ts_chunk0
