
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/native-buffer-escape-r38/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010084a100 <_js_json_stringify_full>:
10084a100:     	sub	sp, sp, #0x120
10084a104:     	stp	d9, d8, [sp, #0xb0]
10084a108:     	stp	x28, x27, [sp, #0xc0]
10084a10c:     	stp	x26, x25, [sp, #0xd0]
10084a110:     	stp	x24, x23, [sp, #0xe0]
10084a114:     	stp	x22, x21, [sp, #0xf0]
10084a118:     	stp	x20, x19, [sp, #0x100]
10084a11c:     	stp	x29, x30, [sp, #0x110]
10084a120:     	add	x29, sp, #0x110
10084a124:     	mov.16b	v9, v2
10084a128:     	mov.16b	v8, v0
10084a12c:     	fmov	x19, d8
10084a130:     	fmov	x21, d1
10084a134:     	fmov	x23, d9
10084a138:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
10084a13c:     	add	x27, x21, x8
10084a140:     	add	x24, x23, x8
10084a144:     	fcmp	d2, #0.0
10084a148:     	ccmp	x24, #0x2, #0x0, ne
10084a14c:     	b.hi	0x10084a15c <_js_json_stringify_full+0x5c>
10084a150:     	cmp	x27, #0x2
10084a154:     	b.lo	0x10084a16c <_js_json_stringify_full+0x6c>
10084a158:     	b	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084a15c:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
10084a160:     	cmp	x23, x8
10084a164:     	ccmp	x27, #0x2, #0x2, eq
10084a168:     	b.hs	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084a16c:     	mov	x8, #-0x2               ; =-2
10084a170:     	movk	x8, #0x8003, lsl #48
10084a174:     	add	x8, x19, x8
10084a178:     	cmp	x8, #0x3
10084a17c:     	b.hs	0x10084a190 <_js_json_stringify_full+0x90>
10084a180:     	adrp	x9, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5270>
10084a184:     	add	x9, x9, #0x318
10084a188:     	ldr	x20, [x9, x8, lsl #3]
10084a18c:     	b	0x10084b5a8 <_js_json_stringify_full+0x14a8>
10084a190:     	strb	wzr, [sp, #0x4c]
10084a194:     	str	wzr, [sp, #0x48]
10084a198:     	and	x8, x19, #0xffff000000000000
10084a19c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084a1a0:     	cmp	x8, x9
10084a1a4:     	b.eq	0x10084a218 <_js_json_stringify_full+0x118>
10084a1a8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084a1ac:     	cmp	x8, x9
10084a1b0:     	b.ne	0x10084a614 <_js_json_stringify_full+0x514>
10084a1b4:     	ubfx	x10, x19, #40, #8
10084a1b8:     	cbz	x10, 0x10084a208 <_js_json_stringify_full+0x108>
10084a1bc:     	strb	w19, [sp, #0x48]
10084a1c0:     	cmp	x10, #0x1
10084a1c4:     	b.eq	0x10084a208 <_js_json_stringify_full+0x108>
10084a1c8:     	lsr	x9, x19, #8
10084a1cc:     	strb	w9, [sp, #0x49]
10084a1d0:     	cmp	x10, #0x2
10084a1d4:     	b.eq	0x10084a208 <_js_json_stringify_full+0x108>
10084a1d8:     	lsr	x9, x19, #16
10084a1dc:     	strb	w9, [sp, #0x4a]
10084a1e0:     	cmp	x10, #0x3
10084a1e4:     	b.eq	0x10084a208 <_js_json_stringify_full+0x108>
10084a1e8:     	lsr	x9, x19, #24
10084a1ec:     	strb	w9, [sp, #0x4b]
10084a1f0:     	cmp	x10, #0x4
10084a1f4:     	b.eq	0x10084a208 <_js_json_stringify_full+0x108>
10084a1f8:     	lsr	x9, x19, #32
10084a1fc:     	strb	w9, [sp, #0x4c]
10084a200:     	cmp	x10, #0x5
10084a204:     	b.ne	0x10084bd7c <_js_json_stringify_full+0x1c7c>
10084a208:     	add	x11, sp, #0x48
10084a20c:     	cmp	w10, #0x3
10084a210:     	b.ls	0x10084a230 <_js_json_stringify_full+0x130>
10084a214:     	b	0x10084a614 <_js_json_stringify_full+0x514>
10084a218:     	ands	x9, x19, #0xffffffffffff
10084a21c:     	b.eq	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084a220:     	add	x11, x9, #0x14
10084a224:     	ldr	w10, [x9, #0x4]
10084a228:     	cmp	w10, #0x3
10084a22c:     	b.hi	0x10084a614 <_js_json_stringify_full+0x514>
10084a230:     	stur	wzr, [sp, #0x81]
10084a234:     	mov	w9, #0x22               ; =34
10084a238:     	strb	w9, [sp, #0x80]
10084a23c:     	cbz	w10, 0x10084a274 <_js_json_stringify_full+0x174>
10084a240:     	add	x12, sp, #0x80
10084a244:     	ldrb	w13, [x11]
10084a248:     	sxtb	w15, w13
10084a24c:     	cmp	w13, #0xb
10084a250:     	b.le	0x10084a27c <_js_json_stringify_full+0x17c>
10084a254:     	cmp	w13, #0x21
10084a258:     	b.gt	0x10084a29c <_js_json_stringify_full+0x19c>
10084a25c:     	cmp	w13, #0xc
10084a260:     	b.eq	0x10084a2d0 <_js_json_stringify_full+0x1d0>
10084a264:     	cmp	w13, #0xd
10084a268:     	b.ne	0x10084a2ac <_js_json_stringify_full+0x1ac>
10084a26c:     	mov	w15, #0x72              ; =114
10084a270:     	b	0x10084a2dc <_js_json_stringify_full+0x1dc>
10084a274:     	mov	w12, #0x1               ; =1
10084a278:     	b	0x10084a304 <_js_json_stringify_full+0x204>
10084a27c:     	cmp	w13, #0x8
10084a280:     	b.eq	0x10084a2c8 <_js_json_stringify_full+0x1c8>
10084a284:     	cmp	w13, #0x9
10084a288:     	b.eq	0x10084a2d8 <_js_json_stringify_full+0x1d8>
10084a28c:     	cmp	w13, #0xa
10084a290:     	b.ne	0x10084a2ac <_js_json_stringify_full+0x1ac>
10084a294:     	mov	w15, #0x6e              ; =110
10084a298:     	b	0x10084a2dc <_js_json_stringify_full+0x1dc>
10084a29c:     	cmp	w13, #0x22
10084a2a0:     	b.eq	0x10084a2dc <_js_json_stringify_full+0x1dc>
10084a2a4:     	cmp	w13, #0x5c
10084a2a8:     	b.eq	0x10084a2dc <_js_json_stringify_full+0x1dc>
10084a2ac:     	cmp	w15, #0x20
10084a2b0:     	b.lt	0x10084a614 <_js_json_stringify_full+0x514>
10084a2b4:     	mov	w14, #0x0               ; =0
10084a2b8:     	add	x13, x12, #0x2
10084a2bc:     	mov	w12, #0x2               ; =2
10084a2c0:     	mov	w16, #0x1               ; =1
10084a2c4:     	b	0x10084a2f4 <_js_json_stringify_full+0x1f4>
10084a2c8:     	mov	w15, #0x62              ; =98
10084a2cc:     	b	0x10084a2dc <_js_json_stringify_full+0x1dc>
10084a2d0:     	mov	w15, #0x66              ; =102
10084a2d4:     	b	0x10084a2dc <_js_json_stringify_full+0x1dc>
10084a2d8:     	mov	w15, #0x74              ; =116
10084a2dc:     	add	x13, x12, #0x3
10084a2e0:     	mov	w12, #0x5c              ; =92
10084a2e4:     	strb	w12, [sp, #0x81]
10084a2e8:     	mov	w14, #0x1               ; =1
10084a2ec:     	mov	w12, #0x3               ; =3
10084a2f0:     	mov	w16, #0x2               ; =2
10084a2f4:     	add	x17, sp, #0x80
10084a2f8:     	strb	w15, [x17, x16]
10084a2fc:     	cmp	w10, #0x1
10084a300:     	b.ne	0x10084a33c <_js_json_stringify_full+0x23c>
10084a304:     	add	x10, sp, #0x80
10084a308:     	strb	w9, [x10, x12]
10084a30c:     	add	x8, x12, #0x1
10084a310:     	cmp	x12, #0x3
10084a314:     	b.hs	0x10084a328 <_js_json_stringify_full+0x228>
10084a318:     	mov	x13, #0x0               ; =0
10084a31c:     	mov	x11, #0x0               ; =0
10084a320:     	add	x9, sp, #0x80
10084a324:     	b	0x10084a584 <_js_json_stringify_full+0x484>
10084a328:     	cmp	x12, #0xf
10084a32c:     	b.hs	0x10084a36c <_js_json_stringify_full+0x26c>
10084a330:     	mov	x11, #0x0               ; =0
10084a334:     	mov	x13, #0x0               ; =0
10084a338:     	b	0x10084a4e0 <_js_json_stringify_full+0x3e0>
10084a33c:     	ldrb	w16, [x11, #0x1]
10084a340:     	sxtb	w15, w16
10084a344:     	cmp	w16, #0xb
10084a348:     	b.le	0x10084a5b4 <_js_json_stringify_full+0x4b4>
10084a34c:     	cmp	w16, #0x21
10084a350:     	b.gt	0x10084a5d4 <_js_json_stringify_full+0x4d4>
10084a354:     	cmp	w16, #0xc
10084a358:     	b.eq	0x10084a604 <_js_json_stringify_full+0x504>
10084a35c:     	cmp	w16, #0xd
10084a360:     	b.ne	0x10084a5e4 <_js_json_stringify_full+0x4e4>
10084a364:     	mov	w15, #0x72              ; =114
10084a368:     	b	0x10084a610 <_js_json_stringify_full+0x510>
10084a36c:     	and	x12, x8, #0xc
10084a370:     	and	x11, x8, #0x10
10084a374:     	add	x13, sp, #0x80
10084a378:     	add	x9, x13, x11
10084a37c:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6270>
10084a380:     	ldr	q0, [x14, #0x490]
10084a384:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6270>
10084a388:     	ldr	q1, [x14, #0x4a0]
10084a38c:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6270>
10084a390:     	ldr	q2, [x14, #0x4b0]
10084a394:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6270>
10084a398:     	ldr	q3, [x14, #0x4c0]
10084a39c:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6270>
10084a3a0:     	ldr	q4, [x14, #0x4d0]
10084a3a4:     	movi.2d	v5, #0000000000000000
10084a3a8:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6270>
10084a3ac:     	ldr	q6, [x14, #0x4e0]
10084a3b0:     	adrp	x14, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5270>
10084a3b4:     	ldr	q7, [x14, #0x600]
10084a3b8:     	mov	w14, #0x10              ; =16
10084a3bc:     	movi.2d	v16, #0000000000000000
10084a3c0:     	dup.2d	v17, x14
10084a3c4:     	adrp	x14, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33a7a>
10084a3c8:     	ldr	q19, [x14, #0x500]
10084a3cc:     	and	x14, x8, #0x10
10084a3d0:     	movi.2d	v20, #0000000000000000
10084a3d4:     	movi.2d	v18, #0000000000000000
10084a3d8:     	movi.2d	v23, #0000000000000000
10084a3dc:     	movi.2d	v21, #0000000000000000
10084a3e0:     	movi.2d	v24, #0000000000000000
10084a3e4:     	movi.2d	v22, #0000000000000000
10084a3e8:     	ldr	q25, [x13], #0x10
10084a3ec:     	ushll.8h	v26, v25, #0x0
10084a3f0:     	ushll2.4s	v27, v26, #0x0
10084a3f4:     	ushll2.2d	v28, v27, #0x0
10084a3f8:     	ushll2.8h	v25, v25, #0x0
10084a3fc:     	ushll.4s	v29, v25, #0x0
10084a400:     	ushll2.2d	v30, v29, #0x0
10084a404:     	ushll.2d	v29, v29, #0x0
10084a408:     	ushll.2d	v27, v27, #0x0
10084a40c:     	ushll.4s	v26, v26, #0x0
10084a410:     	ushll2.2d	v31, v26, #0x0
10084a414:     	ushll2.4s	v25, v25, #0x0
10084a418:     	ushll.2d	v8, v25, #0x0
10084a41c:     	ushll.2d	v26, v26, #0x0
10084a420:     	ushll2.2d	v25, v25, #0x0
10084a424:     	shl.2d	v9, v0, #0x3
10084a428:     	ushl.2d	v25, v25, v9
10084a42c:     	shl.2d	v9, v19, #0x3
10084a430:     	ushl.2d	v26, v26, v9
10084a434:     	shl.2d	v9, v1, #0x3
10084a438:     	ushl.2d	v8, v8, v9
10084a43c:     	shl.2d	v9, v7, #0x3
10084a440:     	ushl.2d	v31, v31, v9
10084a444:     	shl.2d	v9, v6, #0x3
10084a448:     	ushl.2d	v27, v27, v9
10084a44c:     	shl.2d	v9, v3, #0x3
10084a450:     	ushl.2d	v29, v29, v9
10084a454:     	shl.2d	v9, v2, #0x3
10084a458:     	ushl.2d	v30, v30, v9
10084a45c:     	shl.2d	v9, v4, #0x3
10084a460:     	ushl.2d	v28, v28, v9
10084a464:     	orr.16b	v18, v28, v18
10084a468:     	orr.16b	v21, v30, v21
10084a46c:     	orr.16b	v23, v29, v23
10084a470:     	orr.16b	v20, v27, v20
10084a474:     	orr.16b	v5, v31, v5
10084a478:     	orr.16b	v24, v8, v24
10084a47c:     	orr.16b	v16, v26, v16
10084a480:     	orr.16b	v22, v25, v22
10084a484:     	add.2d	v6, v6, v17
10084a488:     	add.2d	v7, v7, v17
10084a48c:     	add.2d	v19, v19, v17
10084a490:     	add.2d	v4, v4, v17
10084a494:     	add.2d	v3, v3, v17
10084a498:     	add.2d	v2, v2, v17
10084a49c:     	add.2d	v1, v1, v17
10084a4a0:     	add.2d	v0, v0, v17
10084a4a4:     	subs	x14, x14, #0x10
10084a4a8:     	b.ne	0x10084a3e8 <_js_json_stringify_full+0x2e8>
10084a4ac:     	orr.16b	v0, v16, v23
10084a4b0:     	orr.16b	v1, v20, v24
10084a4b4:     	orr.16b	v0, v0, v1
10084a4b8:     	orr.16b	v1, v5, v21
10084a4bc:     	orr.16b	v2, v18, v22
10084a4c0:     	orr.16b	v1, v1, v2
10084a4c4:     	orr.16b	v0, v0, v1
10084a4c8:     	mov	d1, v0[1]
10084a4cc:     	orr.8b	v0, v0, v1
10084a4d0:     	fmov	x13, d0
10084a4d4:     	cmp	x8, x11
10084a4d8:     	b.eq	0x10084a5a4 <_js_json_stringify_full+0x4a4>
10084a4dc:     	cbz	x12, 0x10084a584 <_js_json_stringify_full+0x484>
10084a4e0:     	mov	x14, x11
10084a4e4:     	and	x11, x8, #0x1c
10084a4e8:     	add	x15, sp, #0x80
10084a4ec:     	add	x9, x15, x11
10084a4f0:     	fmov	d0, x13
10084a4f4:     	movi.2d	v1, #0000000000000000
10084a4f8:     	dup.2d	v3, x14
10084a4fc:     	adrp	x12, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5270>
10084a500:     	ldr	q2, [x12, #0x600]
10084a504:     	orr.16b	v2, v3, v2
10084a508:     	adrp	x12, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33a7a>
10084a50c:     	ldr	q4, [x12, #0x500]
10084a510:     	orr.16b	v3, v3, v4
10084a514:     	sub	x12, x14, x11
10084a518:     	add	x13, x15, x14
10084a51c:     	movi.2d	v4, #0x000000000000ff
10084a520:     	mov	w14, #0x4               ; =4
10084a524:     	dup.2d	v5, x14
10084a528:     	ldr	s6, [x13], #0x4
10084a52c:     	ushll.8h	v6, v6, #0x0
10084a530:     	ushll.4s	v6, v6, #0x0
10084a534:     	ushll2.2d	v7, v6, #0x0
10084a538:     	and.16b	v7, v7, v4
10084a53c:     	ushll.2d	v6, v6, #0x0
10084a540:     	and.16b	v6, v6, v4
10084a544:     	shl.2d	v16, v2, #0x3
10084a548:     	shl.2d	v17, v3, #0x3
10084a54c:     	ushl.2d	v6, v6, v17
10084a550:     	ushl.2d	v7, v7, v16
10084a554:     	orr.16b	v1, v7, v1
10084a558:     	orr.16b	v0, v6, v0
10084a55c:     	add.2d	v2, v2, v5
10084a560:     	add.2d	v3, v3, v5
10084a564:     	adds	x12, x12, #0x4
10084a568:     	b.ne	0x10084a528 <_js_json_stringify_full+0x428>
10084a56c:     	orr.16b	v0, v0, v1
10084a570:     	mov	d1, v0[1]
10084a574:     	orr.8b	v0, v0, v1
10084a578:     	fmov	x13, d0
10084a57c:     	cmp	x8, x11
10084a580:     	b.eq	0x10084a5a4 <_js_json_stringify_full+0x4a4>
10084a584:     	add	x10, x10, x8
10084a588:     	lsl	x11, x11, #3
10084a58c:     	ldrb	w12, [x9], #0x1
10084a590:     	lsl	x12, x12, x11
10084a594:     	orr	x13, x12, x13
10084a598:     	add	x11, x11, #0x8
10084a59c:     	cmp	x9, x10
10084a5a0:     	b.ne	0x10084a58c <_js_json_stringify_full+0x48c>
10084a5a4:     	orr	x8, x13, x8, lsl #40
10084a5a8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084a5ac:     	orr	x20, x8, x9
10084a5b0:     	b	0x10084b5a8 <_js_json_stringify_full+0x14a8>
10084a5b4:     	cmp	w16, #0x8
10084a5b8:     	b.eq	0x10084a5fc <_js_json_stringify_full+0x4fc>
10084a5bc:     	cmp	w16, #0x9
10084a5c0:     	b.eq	0x10084a60c <_js_json_stringify_full+0x50c>
10084a5c4:     	cmp	w16, #0xa
10084a5c8:     	b.ne	0x10084a5e4 <_js_json_stringify_full+0x4e4>
10084a5cc:     	mov	w15, #0x6e              ; =110
10084a5d0:     	b	0x10084a610 <_js_json_stringify_full+0x510>
10084a5d4:     	cmp	w16, #0x22
10084a5d8:     	b.eq	0x10084a610 <_js_json_stringify_full+0x510>
10084a5dc:     	cmp	w16, #0x5c
10084a5e0:     	b.eq	0x10084a610 <_js_json_stringify_full+0x510>
10084a5e4:     	cmp	w15, #0x20
10084a5e8:     	b.lt	0x10084a614 <_js_json_stringify_full+0x514>
10084a5ec:     	add	x13, sp, #0x80
10084a5f0:     	strb	w15, [x13, x12]
10084a5f4:     	add	x12, x12, #0x1
10084a5f8:     	b	0x10084ab9c <_js_json_stringify_full+0xa9c>
10084a5fc:     	mov	w15, #0x62              ; =98
10084a600:     	b	0x10084a610 <_js_json_stringify_full+0x510>
10084a604:     	mov	w15, #0x66              ; =102
10084a608:     	b	0x10084a610 <_js_json_stringify_full+0x510>
10084a60c:     	mov	w15, #0x74              ; =116
10084a610:     	tbz	w14, #0x0, 0x10084ab88 <_js_json_stringify_full+0xa88>
10084a614:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084a618:     	cmp	x8, x9
10084a61c:     	b.eq	0x10084a664 <_js_json_stringify_full+0x564>
10084a620:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084a624:     	cmp	x8, x9
10084a628:     	b.ne	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084a62c:     	and	x8, x19, #0xffffffffffff
10084a630:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
10084a634:     	mov	x10, #0x7fffffffffff    ; =140737488355327
10084a638:     	movk	x10, #0xffef, lsl #16
10084a63c:     	cmp	x9, x10
10084a640:     	b.hi	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084a644:     	ldr	w8, [x8, #0x4]
10084a648:     	cmp	w8, #0x40
10084a64c:     	b.lo	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084a650:     	and	x0, x19, #0xffffffffffff
10084a654:     	bl	0x1004f5928 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
10084a658:     	cmp	x0, #0x1
10084a65c:     	b.ne	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084a660:     	b	0x10084a824 <_js_json_stringify_full+0x724>
10084a664:     	and	x25, x19, #0xffffffffffff
10084a668:     	and	x0, x19, #0xffffffffffff
10084a66c:     	bl	0x10057d940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084a670:     	cbz	x0, 0x10084a6a4 <_js_json_stringify_full+0x5a4>
10084a674:     	ldrb	w8, [x0]
10084a678:     	cmp	w8, #0x2
10084a67c:     	b.ne	0x10084a6a4 <_js_json_stringify_full+0x5a4>
10084a680:     	ldrsb	w8, [x0, #0x1]
10084a684:     	tbnz	w8, #0x1f, 0x10084a6a4 <_js_json_stringify_full+0x5a4>
10084a688:     	ldrh	w8, [x0, #0x2]
10084a68c:     	tbnz	w8, #0xb, 0x10084a6a4 <_js_json_stringify_full+0x5a4>
10084a690:     	ldr	w8, [x0, #0x4]
10084a694:     	cmp	w8, #0x18
10084a698:     	b.lo	0x10084a6a4 <_js_json_stringify_full+0x5a4>
10084a69c:     	ldr	w8, [x25]
10084a6a0:     	cbz	w8, 0x10084b6fc <_js_json_stringify_full+0x15fc>
10084a6a4:     	and	x0, x19, #0xffffffffffff
10084a6a8:     	bl	0x10057d940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084a6ac:     	cbz	x0, 0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084a6b0:     	ldrb	w8, [x0]
10084a6b4:     	cmp	w8, #0x2
10084a6b8:     	b.ne	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084a6bc:     	ldrh	w8, [x0, #0x2]
10084a6c0:     	tbnz	w8, #0xb, 0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084a6c4:     	ldr	w8, [x0, #0x4]
10084a6c8:     	cmp	w8, #0x18
10084a6cc:     	b.lo	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084a6d0:     	ldr	w8, [x25]
10084a6d4:     	cbz	w8, 0x10084b6a0 <_js_json_stringify_full+0x15a0>
10084a6d8:     	mov	x20, #0x1               ; =1
10084a6dc:     	movk	x20, #0x7ffc, lsl #48
10084a6e0:     	cmp	x19, x20
10084a6e4:     	b.eq	0x10084b5a8 <_js_json_stringify_full+0x14a8>
10084a6e8:     	and	x22, x19, #0xffff000000000000
10084a6ec:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a6f0:     	cmp	x22, x8
10084a6f4:     	b.ne	0x10084a72c <_js_json_stringify_full+0x62c>
10084a6f8:     	and	x8, x19, #0xffffffffffff
10084a6fc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084a700:     	b.lo	0x10084a718 <_js_json_stringify_full+0x618>
10084a704:     	ldr	w8, [x8, #0xc]
10084a708:     	mov	w9, #0x4f53             ; =20307
10084a70c:     	movk	w9, #0x434c, lsl #16
10084a710:     	cmp	w8, w9
10084a714:     	b.eq	0x10084b5a8 <_js_json_stringify_full+0x14a8>
10084a718:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a71c:     	cmp	x22, x8
10084a720:     	b.ne	0x10084a758 <_js_json_stringify_full+0x658>
10084a724:     	and	x0, x19, #0xffffffffffff
10084a728:     	b	0x10084a780 <_js_json_stringify_full+0x680>
10084a72c:     	lsr	x8, x19, #52
10084a730:     	cbnz	x8, 0x10084a808 <_js_json_stringify_full+0x708>
10084a734:     	and	x8, x19, #0x7
10084a738:     	cbz	x19, 0x10084a764 <_js_json_stringify_full+0x664>
10084a73c:     	cbnz	x8, 0x10084a764 <_js_json_stringify_full+0x664>
10084a740:     	mov	x0, x19
10084a744:     	bl	0x1005120b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084a748:     	mov	x8, x19
10084a74c:     	tbnz	w0, #0x0, 0x10084a6fc <_js_json_stringify_full+0x5fc>
10084a750:     	mov	x8, #0x0                ; =0
10084a754:     	b	0x10084a764 <_js_json_stringify_full+0x664>
10084a758:     	lsr	x8, x19, #52
10084a75c:     	cbnz	x8, 0x10084a808 <_js_json_stringify_full+0x708>
10084a760:     	and	x8, x19, #0x7
10084a764:     	cbz	x19, 0x10084a808 <_js_json_stringify_full+0x708>
10084a768:     	cbnz	x8, 0x10084a808 <_js_json_stringify_full+0x708>
10084a76c:     	mov	x0, x19
10084a770:     	bl	0x1005120b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084a774:     	mov	x8, x0
10084a778:     	mov	x0, x19
10084a77c:     	tbz	w8, #0x0, 0x10084a808 <_js_json_stringify_full+0x708>
10084a780:     	cmp	x0, #0x100, lsl #12     ; =0x100000
10084a784:     	b.lo	0x10084a808 <_js_json_stringify_full+0x708>
10084a788:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084a78c:     	add	x8, x8, #0xfb0
10084a790:     	ldaprb	w8, [x8]
10084a794:     	cbz	w8, 0x10084a808 <_js_json_stringify_full+0x708>
10084a798:     	lsr	x8, x0, #3
10084a79c:     	mov	x9, #0x7c15             ; =31765
10084a7a0:     	movk	x9, #0x7f4a, lsl #16
10084a7a4:     	movk	x9, #0x79b9, lsl #32
10084a7a8:     	movk	x9, #0x9e37, lsl #48
10084a7ac:     	mul	x8, x8, x9
10084a7b0:     	lsr	x10, x8, #54
10084a7b4:     	lsr	x11, x8, #60
10084a7b8:     	adrp	x9, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084a7bc:     	add	x9, x9, #0xf30
10084a7c0:     	add	x11, x9, x11, lsl #3
10084a7c4:     	ldapr	x11, [x11]
10084a7c8:     	lsr	x10, x11, x10
10084a7cc:     	tbz	w10, #0x0, 0x10084a808 <_js_json_stringify_full+0x708>
10084a7d0:     	lsr	x10, x8, #44
10084a7d4:     	ubfx	x11, x8, #50, #4
10084a7d8:     	add	x11, x9, x11, lsl #3
10084a7dc:     	ldapr	x11, [x11]
10084a7e0:     	lsr	x10, x11, x10
10084a7e4:     	tbz	w10, #0x0, 0x10084a808 <_js_json_stringify_full+0x708>
10084a7e8:     	lsr	x10, x8, #34
10084a7ec:     	ubfx	x8, x8, #40, #4
10084a7f0:     	add	x8, x9, x8, lsl #3
10084a7f4:     	ldapr	x8, [x8]
10084a7f8:     	lsr	x8, x8, x10
10084a7fc:     	tbz	w8, #0x0, 0x10084a808 <_js_json_stringify_full+0x708>
10084a800:     	bl	0x10034f4cc <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
10084a804:     	tbnz	w0, #0x0, 0x10084b5a8 <_js_json_stringify_full+0x14a8>
10084a808:     	cmp	x24, #0x3
10084a80c:     	ccmp	x27, #0x2, #0x2, lo
10084a810:     	b.hs	0x10084a830 <_js_json_stringify_full+0x730>
10084a814:     	mov.16b	v0, v8
10084a818:     	bl	0x1004f09fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084a81c:     	cmp	x0, #0x1
10084a820:     	b.ne	0x10084a830 <_js_json_stringify_full+0x730>
10084a824:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
10084a828:     	bfxil	x20, x1, #0, #48
10084a82c:     	b	0x10084b5a8 <_js_json_stringify_full+0x14a8>
10084a830:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a834:     	cmp	x22, x8
10084a838:     	b.ne	0x10084a888 <_js_json_stringify_full+0x788>
10084a83c:     	ands	x22, x19, #0xffffffffffff
10084a840:     	b.eq	0x10084a888 <_js_json_stringify_full+0x788>
10084a844:     	mov	x0, x22
10084a848:     	bl	0x1005120b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084a84c:     	cbz	w0, 0x10084a888 <_js_json_stringify_full+0x788>
10084a850:     	ldurb	w8, [x22, #-0x8]
10084a854:     	cmp	w8, #0x9
10084a858:     	b.ne	0x10084a888 <_js_json_stringify_full+0x788>
10084a85c:     	ldr	w8, [x22, #0x4]
10084a860:     	mov	w9, #0x5841             ; =22593
10084a864:     	movk	w9, #0x4c5a, lsl #16
10084a868:     	cmp	w8, w9
10084a86c:     	b.ne	0x10084a888 <_js_json_stringify_full+0x788>
10084a870:     	mov	x0, x22
10084a874:     	bl	0x10068bd24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
10084a878:     	cbz	x0, 0x10084a888 <_js_json_stringify_full+0x788>
10084a87c:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
10084a880:     	bfxil	x19, x0, #0, #48
10084a884:     	fmov	d8, x19
10084a888:     	mov	w8, #0x7ffd             ; =32765
10084a88c:     	cmp	x8, x23, lsr #48
10084a890:     	b.ne	0x10084a8a4 <_js_json_stringify_full+0x7a4>
10084a894:     	and	x1, x23, #0xffffffffffff
10084a898:     	cmp	x1, #0x100, lsl #12     ; =0x100000
10084a89c:     	b.hs	0x10084a8b8 <_js_json_stringify_full+0x7b8>
10084a8a0:     	b	0x10084a90c <_js_json_stringify_full+0x80c>
10084a8a4:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
10084a8a8:     	mov	x9, #0xfffffff00000     ; =281474975662080
10084a8ac:     	mov	x1, x23
10084a8b0:     	cmp	x8, x9
10084a8b4:     	b.hs	0x10084a90c <_js_json_stringify_full+0x80c>
10084a8b8:     	lsr	x8, x1, #47
10084a8bc:     	cbnz	x8, 0x10084a90c <_js_json_stringify_full+0x80c>
10084a8c0:     	add	x0, sp, #0x80
10084a8c4:     	bl	0x10077266c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
10084a8c8:     	ldr	w8, [sp, #0x80]
10084a8cc:     	tbz	w8, #0x0, 0x10084a90c <_js_json_stringify_full+0x80c>
10084a8d0:     	ldr	w8, [sp, #0x88]
10084a8d4:     	mov	w9, #-0xff30            ; =-65328
10084a8d8:     	cmp	w8, w9
10084a8dc:     	b.eq	0x10084a900 <_js_json_stringify_full+0x800>
10084a8e0:     	mov	w9, #-0xff2f            ; =-65327
10084a8e4:     	cmp	w8, w9
10084a8e8:     	b.ne	0x10084a90c <_js_json_stringify_full+0x80c>
10084a8ec:     	mov.16b	v0, v9
10084a8f0:     	bl	0x10084c9bc <_js_jsvalue_to_string>
10084a8f4:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
10084a8f8:     	bfxil	x23, x0, #0, #48
10084a8fc:     	b	0x10084a90c <_js_json_stringify_full+0x80c>
10084a900:     	mov.16b	v0, v9
10084a904:     	bl	0x100873f60 <_js_number_coerce>
10084a908:     	fmov	x23, d0
10084a90c:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
10084a910:     	add	x8, x23, x8
10084a914:     	cmp	x8, #0x3
10084a918:     	b.hs	0x10084a930 <_js_json_stringify_full+0x830>
10084a91c:     	mov	x22, #0x0               ; =0
10084a920:     	mov	w8, #0x1                ; =1
10084a924:     	stp	xzr, x8, [sp, #0x10]
10084a928:     	str	xzr, [sp, #0x20]
10084a92c:     	b	0x10084abe4 <_js_json_stringify_full+0xae4>
10084a930:     	and	x8, x23, #0xffff000000000000
10084a934:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084a938:     	cmp	x8, x9
10084a93c:     	b.eq	0x10084a960 <_js_json_stringify_full+0x860>
10084a940:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084a944:     	cmp	x8, x9
10084a948:     	b.ne	0x10084a9ec <_js_json_stringify_full+0x8ec>
10084a94c:     	and	x8, x23, #0xffffffffffff
10084a950:     	cmp	x8, #0x1, lsl #12       ; =0x1000
10084a954:     	b.hs	0x10084aa34 <_js_json_stringify_full+0x934>
10084a958:     	mov	x9, #0x0                ; =0
10084a95c:     	b	0x10084aa3c <_js_json_stringify_full+0x93c>
10084a960:     	strb	wzr, [sp, #0x4c]
10084a964:     	str	wzr, [sp, #0x48]
10084a968:     	ubfx	x1, x23, #40, #8
10084a96c:     	cbz	x1, 0x10084a9bc <_js_json_stringify_full+0x8bc>
10084a970:     	strb	w23, [sp, #0x48]
10084a974:     	cmp	x1, #0x1
10084a978:     	b.eq	0x10084a9bc <_js_json_stringify_full+0x8bc>
10084a97c:     	lsr	x8, x23, #8
10084a980:     	strb	w8, [sp, #0x49]
10084a984:     	cmp	x1, #0x2
10084a988:     	b.eq	0x10084a9bc <_js_json_stringify_full+0x8bc>
10084a98c:     	lsr	x8, x23, #16
10084a990:     	strb	w8, [sp, #0x4a]
10084a994:     	cmp	x1, #0x3
10084a998:     	b.eq	0x10084a9bc <_js_json_stringify_full+0x8bc>
10084a99c:     	lsr	x8, x23, #24
10084a9a0:     	strb	w8, [sp, #0x4b]
10084a9a4:     	cmp	x1, #0x4
10084a9a8:     	b.eq	0x10084a9bc <_js_json_stringify_full+0x8bc>
10084a9ac:     	lsr	x8, x23, #32
10084a9b0:     	strb	w8, [sp, #0x4c]
10084a9b4:     	cmp	x1, #0x5
10084a9b8:     	b.ne	0x10084bd7c <_js_json_stringify_full+0x1c7c>
10084a9bc:     	add	x8, sp, #0x80
10084a9c0:     	add	x0, sp, #0x48
10084a9c4:     	bl	0x10002dc18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10084a9c8:     	ldr	w8, [sp, #0x80]
10084a9cc:     	ldp	x9, x22, [sp, #0x88]
10084a9d0:     	cmp	w8, #0x0
10084a9d4:     	csinc	x23, x9, xzr, eq
10084a9d8:     	csel	x25, xzr, x22, ne
10084a9dc:     	tbz	x25, #0x3f, 0x10084ab1c <_js_json_stringify_full+0xa1c>
10084a9e0:     	mov	x0, #0x0                ; =0
10084a9e4:     	mov	x1, x22
10084a9e8:     	bl	0x100b16f00 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084a9ec:     	add	x8, x20, #0x3
10084a9f0:     	cmp	x23, x8
10084a9f4:     	b.eq	0x10084a91c <_js_json_stringify_full+0x81c>
10084a9f8:     	fmov	d0, x23
10084a9fc:     	fcvtzu	x8, d0
10084aa00:     	mov	w9, #0xa                ; =10
10084aa04:     	cmp	x8, #0xa
10084aa08:     	csel	x3, x8, x9, lo
10084aa0c:     	adrp	x1, 0x100c48000 <_PERRY_EMPTY_STRING+0x1eb4>
10084aa10:     	add	x1, x1, #0x2dc
10084aa14:     	add	x0, sp, #0x80
10084aa18:     	mov	w2, #0x1                ; =1
10084aa1c:     	bl	0x1002304f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
10084aa20:     	ldr	x22, [sp, #0x90]
10084aa24:     	str	x22, [sp, #0x20]
10084aa28:     	ldr	q0, [sp, #0x80]
10084aa2c:     	str	q0, [sp, #0x10]
10084aa30:     	b	0x10084abe4 <_js_json_stringify_full+0xae4>
10084aa34:     	ldr	w22, [x8, #0x4]
10084aa38:     	add	x9, x8, #0x14
10084aa3c:     	mov	x14, #0x0               ; =0
10084aa40:     	mov	x8, #0x0                ; =0
10084aa44:     	cmp	x9, #0x0
10084aa48:     	csel	x24, xzr, x22, eq
10084aa4c:     	csinc	x23, x9, xzr, ne
10084aa50:     	add	x9, x23, x24
10084aa54:     	mov	w10, #0x1               ; =1
10084aa58:     	mov	x11, x23
10084aa5c:     	b	0x10084aa8c <_js_json_stringify_full+0x98c>
10084aa60:     	add	x12, x11, #0x2
10084aa64:     	bfi	w15, w13, #6, #5
10084aa68:     	mov	x13, x15
10084aa6c:     	sub	x11, x25, x11
10084aa70:     	add	x14, x11, x12
10084aa74:     	cmp	w13, #0x10, lsl #12     ; =0x10000
10084aa78:     	cinc	x11, x10, hs
10084aa7c:     	add	x8, x11, x8
10084aa80:     	mov	x11, x12
10084aa84:     	cmp	x8, #0xa
10084aa88:     	b.hi	0x10084ab44 <_js_json_stringify_full+0xa44>
10084aa8c:     	cmp	x11, x9
10084aa90:     	b.eq	0x10084aaf4 <_js_json_stringify_full+0x9f4>
10084aa94:     	mov	x25, x14
10084aa98:     	mov	x12, x11
10084aa9c:     	ldrsb	w14, [x12], #0x1
10084aaa0:     	and	w13, w14, #0xff
10084aaa4:     	tbz	w14, #0x1f, 0x10084aa6c <_js_json_stringify_full+0x96c>
10084aaa8:     	ldrb	w12, [x11, #0x1]
10084aaac:     	and	w15, w12, #0x3f
10084aab0:     	cmp	w13, #0xe0
10084aab4:     	b.lo	0x10084aa60 <_js_json_stringify_full+0x960>
10084aab8:     	and	w14, w13, #0x1f
10084aabc:     	ldrb	w12, [x11, #0x2]
10084aac0:     	and	w12, w12, #0x3f
10084aac4:     	orr	w15, w12, w15, lsl #6
10084aac8:     	cmp	w13, #0xf0
10084aacc:     	b.lo	0x10084aae8 <_js_json_stringify_full+0x9e8>
10084aad0:     	add	x12, x11, #0x4
10084aad4:     	ldrb	w13, [x11, #0x3]
10084aad8:     	and	w13, w13, #0x3f
10084aadc:     	orr	w13, w13, w15, lsl #6
10084aae0:     	bfi	w13, w14, #18, #3
10084aae4:     	b	0x10084aa6c <_js_json_stringify_full+0x96c>
10084aae8:     	add	x12, x11, #0x3
10084aaec:     	orr	w13, w15, w14, lsl #12
10084aaf0:     	b	0x10084aa6c <_js_json_stringify_full+0x96c>
10084aaf4:     	cbz	x24, 0x10084ab78 <_js_json_stringify_full+0xa78>
10084aaf8:     	mov	x0, x24
10084aafc:     	mov	w1, #0x1                ; =1
10084ab00:     	bl	0x100b63e08 <_mi_malloc_aligned>
10084ab04:     	cbz	x0, 0x10084bd64 <_js_json_stringify_full+0x1c64>
10084ab08:     	mov	x26, x0
10084ab0c:     	mov	x1, x23
10084ab10:     	mov	x2, x24
10084ab14:     	bl	0x100b66a2c <_writev+0x100b66a2c>
10084ab18:     	b	0x10084ab80 <_js_json_stringify_full+0xa80>
10084ab1c:     	cbz	x25, 0x10084abd4 <_js_json_stringify_full+0xad4>
10084ab20:     	mov	x0, x25
10084ab24:     	mov	w1, #0x1                ; =1
10084ab28:     	bl	0x100b63e08 <_mi_malloc_aligned>
10084ab2c:     	cbz	x0, 0x10084bd70 <_js_json_stringify_full+0x1c70>
10084ab30:     	mov	x24, x0
10084ab34:     	mov	x1, x23
10084ab38:     	mov	x2, x25
10084ab3c:     	bl	0x100b66a2c <_writev+0x100b66a2c>
10084ab40:     	b	0x10084abdc <_js_json_stringify_full+0xadc>
10084ab44:     	cbz	x25, 0x10084ab78 <_js_json_stringify_full+0xa78>
10084ab48:     	cmp	x25, x24
10084ab4c:     	b.hs	0x10084b5f4 <_js_json_stringify_full+0x14f4>
10084ab50:     	ldrsb	w8, [x23, x25]
10084ab54:     	cmn	w8, #0x40
10084ab58:     	b.ge	0x10084b5f8 <_js_json_stringify_full+0x14f8>
10084ab5c:     	adrp	x4, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084ab60:     	add	x4, x4, #0x270
10084ab64:     	mov	x0, x23
10084ab68:     	mov	x1, x24
10084ab6c:     	mov	x2, #0x0                ; =0
10084ab70:     	mov	x3, x25
10084ab74:     	bl	0x100b17278 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
10084ab78:     	mov	x22, #0x0               ; =0
10084ab7c:     	mov	w26, #0x1               ; =1
10084ab80:     	stp	x22, x26, [sp, #0x10]
10084ab84:     	b	0x10084abe0 <_js_json_stringify_full+0xae0>
10084ab88:     	add	x14, sp, #0x80
10084ab8c:     	mov	w16, #0x5c              ; =92
10084ab90:     	strb	w16, [x14, x12]
10084ab94:     	add	x12, x12, #0x2
10084ab98:     	strb	w15, [x13, #0x1]
10084ab9c:     	cmp	w10, #0x2
10084aba0:     	b.eq	0x10084a304 <_js_json_stringify_full+0x204>
10084aba4:     	ldrb	w11, [x11, #0x2]
10084aba8:     	sxtb	w10, w11
10084abac:     	cmp	w11, #0xb
10084abb0:     	b.le	0x10084b680 <_js_json_stringify_full+0x1580>
10084abb4:     	cmp	w11, #0x21
10084abb8:     	b.gt	0x10084b6cc <_js_json_stringify_full+0x15cc>
10084abbc:     	cmp	w11, #0xc
10084abc0:     	b.eq	0x10084b758 <_js_json_stringify_full+0x1658>
10084abc4:     	cmp	w11, #0xd
10084abc8:     	b.ne	0x10084b6dc <_js_json_stringify_full+0x15dc>
10084abcc:     	mov	w10, #0x72              ; =114
10084abd0:     	b	0x10084b764 <_js_json_stringify_full+0x1664>
10084abd4:     	mov	x22, #0x0               ; =0
10084abd8:     	mov	w24, #0x1               ; =1
10084abdc:     	stp	x22, x24, [sp, #0x10]
10084abe0:     	str	x22, [sp, #0x20]
10084abe4:     	cmp	x27, #0x2
10084abe8:     	b.lo	0x10084ad28 <_js_json_stringify_full+0xc28>
10084abec:     	and	x25, x21, #0xffff000000000000
10084abf0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084abf4:     	cmp	x25, x8
10084abf8:     	b.ne	0x10084ad04 <_js_json_stringify_full+0xc04>
10084abfc:     	and	x23, x21, #0xffffffffffff
10084ac00:     	cmp	x23, #0x100, lsl #12    ; =0x100000
10084ac04:     	b.lo	0x10084ad28 <_js_json_stringify_full+0xc28>
10084ac08:     	mov	x0, x23
10084ac0c:     	bl	0x10050d5c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
10084ac10:     	tbnz	w0, #0x0, 0x10084ad28 <_js_json_stringify_full+0xc28>
10084ac14:     	lsr	x8, x23, #51
10084ac18:     	cmp	x8, #0xfff
10084ac1c:     	b.lo	0x10084ac34 <_js_json_stringify_full+0xb34>
10084ac20:     	mov	w8, #0x7ffc             ; =32764
10084ac24:     	cmp	x8, x23, lsr #48
10084ac28:     	b.eq	0x10084ad28 <_js_json_stringify_full+0xc28>
10084ac2c:     	ands	x23, x23, #0xffffffffffff
10084ac30:     	b.eq	0x10084ad28 <_js_json_stringify_full+0xc28>
10084ac34:     	and	x8, x23, #0xfffffffffff00000
10084ac38:     	lsr	x9, x23, #47
10084ac3c:     	cmp	x9, #0x0
10084ac40:     	ccmp	x8, #0x0, #0x4, eq
10084ac44:     	b.eq	0x10084ad28 <_js_json_stringify_full+0xc28>
10084ac48:     	tst	x23, #0x3
10084ac4c:     	ccmp	x23, #0x7, #0x0, eq
10084ac50:     	b.ls	0x10084b994 <_js_json_stringify_full+0x1894>
10084ac54:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084ac58:     	ldr	x8, [x8, #0x48]
10084ac5c:     	cmn	x8, #0x1
10084ac60:     	b.eq	0x10084b8e4 <_js_json_stringify_full+0x17e4>
10084ac64:     	mrs	x9, TPIDRRO_EL0
10084ac68:     	and	x9, x9, #0xfffffffffffffff8
10084ac6c:     	ldr	x0, [x9, x8, lsl #3]
10084ac70:     	cbz	x0, 0x10084b8e4 <_js_json_stringify_full+0x17e4>
10084ac74:     	lsr	x1, x23, #20
10084ac78:     	ldr	x8, [x0, #0x10]
10084ac7c:     	ldrb	w9, [x8]
10084ac80:     	cmp	w9, #0x2
10084ac84:     	b.ne	0x10084b8fc <_js_json_stringify_full+0x17fc>
10084ac88:     	ldrb	w9, [x8, #0x88]
10084ac8c:     	tbz	w9, #0x0, 0x10084acac <_js_json_stringify_full+0xbac>
10084ac90:     	ldr	x9, [x8, #0x80]
10084ac94:     	cmp	x9, x1
10084ac98:     	b.ne	0x10084acac <_js_json_stringify_full+0xbac>
10084ac9c:     	ldp	x9, x10, [x8, #0x60]
10084aca0:     	cmp	x9, x23
10084aca4:     	ccmp	x10, x23, #0x0, ls
10084aca8:     	b.hi	0x10084b8dc <_js_json_stringify_full+0x17dc>
10084acac:     	ldrb	w9, [x8, #0xb8]
10084acb0:     	cbz	w9, 0x10084acd0 <_js_json_stringify_full+0xbd0>
10084acb4:     	ldr	x9, [x8, #0xb0]
10084acb8:     	cmp	x9, x1
10084acbc:     	b.ne	0x10084acd0 <_js_json_stringify_full+0xbd0>
10084acc0:     	ldp	x9, x10, [x8, #0x90]
10084acc4:     	cmp	x9, x23
10084acc8:     	ccmp	x10, x23, #0x0, ls
10084accc:     	b.hi	0x10084bb64 <_js_json_stringify_full+0x1a64>
10084acd0:     	ldrb	w9, [x8, #0xe8]
10084acd4:     	cbz	w9, 0x10084b71c <_js_json_stringify_full+0x161c>
10084acd8:     	ldr	x9, [x8, #0xe0]
10084acdc:     	cmp	x9, x1
10084ace0:     	b.ne	0x10084b71c <_js_json_stringify_full+0x161c>
10084ace4:     	ldr	x9, [x8, #0xc0]
10084ace8:     	cmp	x9, x23
10084acec:     	b.hi	0x10084b71c <_js_json_stringify_full+0x161c>
10084acf0:     	ldr	x9, [x8, #0xc8]
10084acf4:     	cmp	x9, x23
10084acf8:     	b.ls	0x10084b71c <_js_json_stringify_full+0x161c>
10084acfc:     	add	x9, x8, #0xc0
10084ad00:     	b	0x10084bb68 <_js_json_stringify_full+0x1a68>
10084ad04:     	lsr	x8, x21, #52
10084ad08:     	cbnz	x8, 0x10084ad28 <_js_json_stringify_full+0xc28>
10084ad0c:     	cbz	x21, 0x10084ad28 <_js_json_stringify_full+0xc28>
10084ad10:     	and	x8, x21, #0x7
10084ad14:     	cbnz	x8, 0x10084ad28 <_js_json_stringify_full+0xc28>
10084ad18:     	mov	x0, x21
10084ad1c:     	bl	0x1005120b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084ad20:     	mov	x23, x21
10084ad24:     	cbnz	w0, 0x10084ac00 <_js_json_stringify_full+0xb00>
10084ad28:     	mov	x25, #-0x1              ; =-1
10084ad2c:     	str	x25, [sp, #0x30]
10084ad30:     	mov	w24, #0x1               ; =1
10084ad34:     	cmp	x27, #0x1
10084ad38:     	cset	w8, hi
10084ad3c:     	tst	w8, w24
10084ad40:     	b.eq	0x10084adb4 <_js_json_stringify_full+0xcb4>
10084ad44:     	and	x23, x21, #0xffff000000000000
10084ad48:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084ad4c:     	cmp	x23, x8
10084ad50:     	b.ne	0x10084ad8c <_js_json_stringify_full+0xc8c>
10084ad54:     	and	x8, x21, #0xffffffffffff
10084ad58:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084ad5c:     	b.lo	0x10084adb4 <_js_json_stringify_full+0xcb4>
10084ad60:     	ldr	w8, [x8, #0xc]
10084ad64:     	mov	w9, #0x4f53             ; =20307
10084ad68:     	movk	w9, #0x434c, lsl #16
10084ad6c:     	cmp	w8, w9
10084ad70:     	b.ne	0x10084adb4 <_js_json_stringify_full+0xcb4>
10084ad74:     	and	x8, x21, #0xffffffffffff
10084ad78:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084ad7c:     	cmp	x23, x9
10084ad80:     	csel	x28, x8, x21, eq
10084ad84:     	mov	w27, #0x1               ; =1
10084ad88:     	b	0x10084adb8 <_js_json_stringify_full+0xcb8>
10084ad8c:     	lsr	x8, x21, #52
10084ad90:     	cbnz	x8, 0x10084adb4 <_js_json_stringify_full+0xcb4>
10084ad94:     	mov	w27, #0x0               ; =0
10084ad98:     	cbz	x21, 0x10084adb8 <_js_json_stringify_full+0xcb8>
10084ad9c:     	and	x8, x21, #0x7
10084ada0:     	cbnz	x8, 0x10084adb8 <_js_json_stringify_full+0xcb8>
10084ada4:     	mov	x0, x21
10084ada8:     	bl	0x1005120b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084adac:     	mov	x8, x21
10084adb0:     	tbnz	w0, #0x0, 0x10084ad58 <_js_json_stringify_full+0xc58>
10084adb4:     	mov	w27, #0x0               ; =0
10084adb8:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084adbc:     	add	x0, x0, #0xd78
10084adc0:     	ldr	x8, [x0]
10084adc4:     	blr	x8
10084adc8:     	mov	x21, x0
10084adcc:     	ldr	w26, [x0]
10084add0:     	add	w8, w26, #0x1
10084add4:     	str	w8, [x0]
10084add8:     	cbz	w26, 0x10084ae48 <_js_json_stringify_full+0xd48>
10084addc:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084ade0:     	add	x0, x0, #0xd00
10084ade4:     	ldr	x8, [x0]
10084ade8:     	blr	x8
10084adec:     	ldrb	w8, [x0, #0x20]
10084adf0:     	cmp	w8, #0x1
10084adf4:     	b.ne	0x10084bbd4 <_js_json_stringify_full+0x1ad4>
10084adf8:     	ldr	x8, [x0]
10084adfc:     	cbnz	x8, 0x10084bbe0 <_js_json_stringify_full+0x1ae0>
10084ae00:     	mov	x8, #-0x1               ; =-1
10084ae04:     	str	x8, [x0]
10084ae08:     	ldr	x23, [x0, #0x18]
10084ae0c:     	ldr	x8, [x0, #0x8]
10084ae10:     	cmp	x23, x8
10084ae14:     	b.eq	0x10084b5d0 <_js_json_stringify_full+0x14d0>
10084ae18:     	ldr	x8, [x0, #0x10]
10084ae1c:     	mov	w9, #0x18               ; =24
10084ae20:     	madd	x8, x23, x9, x8
10084ae24:     	mov	w9, #0x8                ; =8
10084ae28:     	stp	xzr, x9, [x8]
10084ae2c:     	str	xzr, [x8, #0x10]
10084ae30:     	add	x8, x23, #0x1
10084ae34:     	str	x8, [x0, #0x18]
10084ae38:     	ldr	x8, [x0]
10084ae3c:     	add	x8, x8, #0x1
10084ae40:     	str	x8, [x0]
10084ae44:     	b	0x10084aeb0 <_js_json_stringify_full+0xdb0>
10084ae48:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084ae4c:     	add	x0, x0, #0xdc0
10084ae50:     	ldr	x8, [x0]
10084ae54:     	blr	x8
10084ae58:     	strb	wzr, [x0]
10084ae5c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084ae60:     	add	x0, x0, #0xdf0
10084ae64:     	ldr	x8, [x0]
10084ae68:     	blr	x8
10084ae6c:     	strb	wzr, [x0]
10084ae70:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
10084ae74:     	ldr	w23, [x8, #0x5a8]
10084ae78:     	cmp	w23, #0x300
10084ae7c:     	b.hs	0x10084b618 <_js_json_stringify_full+0x1518>
10084ae80:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084ae84:     	ldr	x8, [x8, #0x48]
10084ae88:     	cmn	x8, #0x1
10084ae8c:     	b.eq	0x10084b608 <_js_json_stringify_full+0x1508>
10084ae90:     	mrs	x9, TPIDRRO_EL0
10084ae94:     	and	x9, x9, #0xfffffffffffffff8
10084ae98:     	ldr	x0, [x9, x8, lsl #3]
10084ae9c:     	cbz	x0, 0x10084b608 <_js_json_stringify_full+0x1508>
10084aea0:     	add	x8, x0, x23, lsl #3
10084aea4:     	ldr	x0, [x8, #0x1e8]
10084aea8:     	cbz	x0, 0x10084b618 <_js_json_stringify_full+0x1518>
10084aeac:     	str	xzr, [x0]
10084aeb0:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084aeb4:     	add	x0, x0, #0xd30
10084aeb8:     	ldr	x8, [x0]
10084aebc:     	blr	x8
10084aec0:     	mov	x23, x0
10084aec4:     	ldrb	w8, [x0, #0x18]
10084aec8:     	cmp	w8, #0x1
10084aecc:     	b.ne	0x10084bb88 <_js_json_stringify_full+0x1a88>
10084aed0:     	ldr	x8, [x0]
10084aed4:     	mov	x9, #-0x1               ; =-1
10084aed8:     	str	x9, [x0]
10084aedc:     	cmn	x8, #0x2
10084aee0:     	b.eq	0x10084bd10 <_js_json_stringify_full+0x1c10>
10084aee4:     	cmn	x8, #0x1
10084aee8:     	b.eq	0x10084afbc <_js_json_stringify_full+0xebc>
10084aeec:     	add	x9, sp, #0x48
10084aef0:     	ldur	q0, [x0, #0x8]
10084aef4:     	stur	q0, [x9, #0x8]
10084aef8:     	str	x8, [sp, #0x48]
10084aefc:     	tbz	w24, #0x0, 0x10084afd0 <_js_json_stringify_full+0xed0>
10084af00:     	tbz	w27, #0x0, 0x10084b0b8 <_js_json_stringify_full+0xfb8>
10084af04:     	bl	0x10028ddd8 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
10084af08:     	str	x0, [sp, #0x60]
10084af0c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084af10:     	stp	x28, x8, [sp, #0x88]
10084af14:     	mov	w8, #0x1                ; =1
10084af18:     	str	x8, [sp, #0x80]
10084af1c:     	add	x0, sp, #0x80
10084af20:     	bl	0x10028dee0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
10084af24:     	mov	x22, x0
10084af28:     	str	x0, [sp, #0x68]
10084af2c:     	mov	w0, #0x0                ; =0
10084af30:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084af34:     	stp	xzr, xzr, [x0]
10084af38:     	str	wzr, [x0, #0x10]
10084af3c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10084af40:     	bfxil	x8, x0, #0, #48
10084af44:     	fmov	d0, x8
10084af48:     	bl	0x10020b024 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
10084af4c:     	mov	x19, x0
10084af50:     	adrp	x24, 0x100f84000 <_perry_global_worker_ts__1>
10084af54:     	ldr	x8, [x24, #0x48]
10084af58:     	cmn	x8, #0x1
10084af5c:     	b.eq	0x10084b11c <_js_json_stringify_full+0x101c>
10084af60:     	mrs	x9, TPIDRRO_EL0
10084af64:     	and	x9, x9, #0xfffffffffffffff8
10084af68:     	ldr	x8, [x9, x8, lsl #3]
10084af6c:     	cbz	x8, 0x10084b11c <_js_json_stringify_full+0x101c>
10084af70:     	ldr	x8, [x8, #0x19e8]
10084af74:     	cbz	x8, 0x10084b11c <_js_json_stringify_full+0x101c>
10084af78:     	ldr	x9, [x8]
10084af7c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084af80:     	cmp	x9, x10
10084af84:     	b.hs	0x10084bc5c <_js_json_stringify_full+0x1b5c>
10084af88:     	add	x10, x9, #0x1
10084af8c:     	str	x10, [x8]
10084af90:     	ldr	x10, [x8, #0x18]
10084af94:     	cmp	x19, x10
10084af98:     	b.hs	0x10084bc68 <_js_json_stringify_full+0x1b68>
10084af9c:     	ldr	x10, [x8, #0x10]
10084afa0:     	mov	w11, #0x18              ; =24
10084afa4:     	madd	x10, x19, x11, x10
10084afa8:     	ldr	x11, [x10]
10084afac:     	cbnz	x11, 0x10084bcc8 <_js_json_stringify_full+0x1bc8>
10084afb0:     	ldr	x0, [x10, #0x8]
10084afb4:     	str	x9, [x8]
10084afb8:     	b	0x10084b124 <_js_json_stringify_full+0x1024>
10084afbc:     	mov	x8, #0x0                ; =0
10084afc0:     	mov	w9, #0x1                ; =1
10084afc4:     	stp	x9, xzr, [sp, #0x50]
10084afc8:     	str	x8, [sp, #0x48]
10084afcc:     	tbnz	w24, #0x0, 0x10084af00 <_js_json_stringify_full+0xe00>
10084afd0:     	cmp	x22, #0x0
10084afd4:     	cset	w6, ne
10084afd8:     	ldp	x0, x1, [sp, #0x38]
10084afdc:     	ldp	x3, x4, [sp, #0x18]
10084afe0:     	add	x2, sp, #0x48
10084afe4:     	mov.16b	v0, v8
10084afe8:     	mov	x5, #0x0                ; =0
10084afec:     	bl	0x100505b00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
10084aff0:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084aff4:     	add	x0, x0, #0xd90
10084aff8:     	ldr	x8, [x0]
10084affc:     	blr	x8
10084b000:     	ldrb	w8, [x0, #0x20]
10084b004:     	cbnz	w8, 0x10084bbec <_js_json_stringify_full+0x1aec>
10084b008:     	ldr	x8, [x0]
10084b00c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10084b010:     	cmp	x8, x9
10084b014:     	b.hs	0x10084bc1c <_js_json_stringify_full+0x1b1c>
10084b018:     	ldr	x9, [x0, #0x18]
10084b01c:     	cbz	x9, 0x10084b028 <_js_json_stringify_full+0xf28>
10084b020:     	cbnz	x8, 0x10084bc28 <_js_json_stringify_full+0x1b28>
10084b024:     	str	xzr, [x0, #0x18]
10084b028:     	ldp	x0, x1, [sp, #0x50]
10084b02c:     	cmp	x1, #0x5
10084b030:     	b.hi	0x10084b098 <_js_json_stringify_full+0xf98>
10084b034:     	cbz	x1, 0x10084b2a8 <_js_json_stringify_full+0x11a8>
10084b038:     	ldrsb	w8, [x0]
10084b03c:     	tbnz	w8, #0x1f, 0x10084b098 <_js_json_stringify_full+0xf98>
10084b040:     	cmp	x1, #0x1
10084b044:     	b.eq	0x10084b080 <_js_json_stringify_full+0xf80>
10084b048:     	ldrsb	w8, [x0, #0x1]
10084b04c:     	tbnz	w8, #0x1f, 0x10084b098 <_js_json_stringify_full+0xf98>
10084b050:     	cmp	x1, #0x2
10084b054:     	b.eq	0x10084b080 <_js_json_stringify_full+0xf80>
10084b058:     	ldrsb	w8, [x0, #0x2]
10084b05c:     	tbnz	w8, #0x1f, 0x10084b098 <_js_json_stringify_full+0xf98>
10084b060:     	cmp	x1, #0x3
10084b064:     	b.eq	0x10084b080 <_js_json_stringify_full+0xf80>
10084b068:     	ldrsb	w8, [x0, #0x3]
10084b06c:     	tbnz	w8, #0x1f, 0x10084b098 <_js_json_stringify_full+0xf98>
10084b070:     	cmp	x1, #0x4
10084b074:     	b.eq	0x10084b080 <_js_json_stringify_full+0xf80>
10084b078:     	ldrsb	w8, [x0, #0x4]
10084b07c:     	tbnz	w8, #0x1f, 0x10084b098 <_js_json_stringify_full+0xf98>
10084b080:     	cmp	x1, #0x4
10084b084:     	b.hs	0x10084b3e8 <_js_json_stringify_full+0x12e8>
10084b088:     	mov	x10, #0x0               ; =0
10084b08c:     	mov	x9, #0x0                ; =0
10084b090:     	mov	x8, x0
10084b094:     	b	0x10084b478 <_js_json_stringify_full+0x1378>
10084b098:     	bl	0x10032c848 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
10084b09c:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
10084b0a0:     	bfxil	x20, x0, #0, #48
10084b0a4:     	ldp	x22, x0, [sp, #0x48]
10084b0a8:     	ldrb	w8, [x23, #0x18]
10084b0ac:     	cmp	w8, #0x1
10084b0b0:     	b.eq	0x10084b4b4 <_js_json_stringify_full+0x13b4>
10084b0b4:     	b	0x10084bbb8 <_js_json_stringify_full+0x1ab8>
10084b0b8:     	mov	w0, #0x0                ; =0
10084b0bc:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084b0c0:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10084b0c4:     	bfxil	x8, x0, #0, #48
10084b0c8:     	fmov	d1, x8
10084b0cc:     	stp	xzr, xzr, [x0]
10084b0d0:     	str	wzr, [x0, #0x10]
10084b0d4:     	mov.16b	v0, v8
10084b0d8:     	bl	0x1006ca5a0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
10084b0dc:     	mov.16b	v8, v0
10084b0e0:     	fmov	x24, d8
10084b0e4:     	cmp	x24, x20
10084b0e8:     	b.eq	0x10084b330 <_js_json_stringify_full+0x1230>
10084b0ec:     	mov	w8, #0x7ffd             ; =32765
10084b0f0:     	cmp	x8, x24, lsr #48
10084b0f4:     	b.ne	0x10084b300 <_js_json_stringify_full+0x1200>
10084b0f8:     	and	x8, x24, #0xffffffffffff
10084b0fc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084b100:     	b.lo	0x10084b324 <_js_json_stringify_full+0x1224>
10084b104:     	ldr	w8, [x8, #0xc]
10084b108:     	mov	w9, #0x4f53             ; =20307
10084b10c:     	movk	w9, #0x434c, lsl #16
10084b110:     	cmp	w8, w9
10084b114:     	b.ne	0x10084b324 <_js_json_stringify_full+0x1224>
10084b118:     	b	0x10084b330 <_js_json_stringify_full+0x1230>
10084b11c:     	mov	x0, x19
10084b120:     	bl	0x10013c270 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
10084b124:     	fmov	d1, x0
10084b128:     	mov.16b	v0, v8
10084b12c:     	bl	0x1006ca5a0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
10084b130:     	mov.16b	v8, v0
10084b134:     	ldr	x8, [x24, #0x48]
10084b138:     	cmn	x8, #0x1
10084b13c:     	b.eq	0x10084b1a0 <_js_json_stringify_full+0x10a0>
10084b140:     	mrs	x9, TPIDRRO_EL0
10084b144:     	and	x9, x9, #0xfffffffffffffff8
10084b148:     	ldr	x8, [x9, x8, lsl #3]
10084b14c:     	cbz	x8, 0x10084b1a0 <_js_json_stringify_full+0x10a0>
10084b150:     	ldr	x8, [x8, #0x19e8]
10084b154:     	cbz	x8, 0x10084b1a0 <_js_json_stringify_full+0x10a0>
10084b158:     	ldr	x9, [x8]
10084b15c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084b160:     	cmp	x9, x10
10084b164:     	b.hs	0x10084bc5c <_js_json_stringify_full+0x1b5c>
10084b168:     	add	x10, x9, #0x1
10084b16c:     	str	x10, [x8]
10084b170:     	ldr	x10, [x8, #0x18]
10084b174:     	cmp	x22, x10
10084b178:     	b.hs	0x10084bc68 <_js_json_stringify_full+0x1b68>
10084b17c:     	ldr	x10, [x8, #0x10]
10084b180:     	mov	w11, #0x18              ; =24
10084b184:     	madd	x10, x22, x11, x10
10084b188:     	ldr	x11, [x10]
10084b18c:     	cmp	x11, #0x1
10084b190:     	b.ne	0x10084bd28 <_js_json_stringify_full+0x1c28>
10084b194:     	ldr	x22, [x10, #0x8]
10084b198:     	str	x9, [x8]
10084b19c:     	b	0x10084b1ac <_js_json_stringify_full+0x10ac>
10084b1a0:     	mov	x0, x22
10084b1a4:     	bl	0x10013c198 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
10084b1a8:     	mov	x22, x0
10084b1ac:     	ldr	x8, [x24, #0x48]
10084b1b0:     	cmn	x8, #0x1
10084b1b4:     	b.eq	0x10084b214 <_js_json_stringify_full+0x1114>
10084b1b8:     	mrs	x9, TPIDRRO_EL0
10084b1bc:     	and	x9, x9, #0xfffffffffffffff8
10084b1c0:     	ldr	x8, [x9, x8, lsl #3]
10084b1c4:     	cbz	x8, 0x10084b214 <_js_json_stringify_full+0x1114>
10084b1c8:     	ldr	x8, [x8, #0x19e8]
10084b1cc:     	cbz	x8, 0x10084b214 <_js_json_stringify_full+0x1114>
10084b1d0:     	ldr	x9, [x8]
10084b1d4:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084b1d8:     	cmp	x9, x10
10084b1dc:     	b.hs	0x10084bc5c <_js_json_stringify_full+0x1b5c>
10084b1e0:     	add	x10, x9, #0x1
10084b1e4:     	str	x10, [x8]
10084b1e8:     	ldr	x10, [x8, #0x18]
10084b1ec:     	cmp	x19, x10
10084b1f0:     	b.hs	0x10084bc68 <_js_json_stringify_full+0x1b68>
10084b1f4:     	ldr	x10, [x8, #0x10]
10084b1f8:     	mov	w11, #0x18              ; =24
10084b1fc:     	madd	x10, x19, x11, x10
10084b200:     	ldr	x11, [x10]
10084b204:     	cbnz	x11, 0x10084bcc8 <_js_json_stringify_full+0x1bc8>
10084b208:     	ldr	x0, [x10, #0x8]
10084b20c:     	str	x9, [x8]
10084b210:     	b	0x10084b21c <_js_json_stringify_full+0x111c>
10084b214:     	mov	x0, x19
10084b218:     	bl	0x10013c270 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
10084b21c:     	fmov	d9, x0
10084b220:     	mov.16b	v0, v8
10084b224:     	bl	0x1005024a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
10084b228:     	mov.16b	v2, v0
10084b22c:     	mov	x0, x22
10084b230:     	mov.16b	v0, v9
10084b234:     	mov.16b	v1, v8
10084b238:     	bl	0x100502784 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
10084b23c:     	str	d0, [sp, #0x70]
10084b240:     	fmov	x19, d0
10084b244:     	cmp	x19, x20
10084b248:     	b.ne	0x10084b2b0 <_js_json_stringify_full+0x11b0>
10084b24c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b250:     	add	x0, x0, #0xd90
10084b254:     	ldr	x8, [x0]
10084b258:     	blr	x8
10084b25c:     	ldrb	w8, [x0, #0x20]
10084b260:     	cbnz	w8, 0x10084bd08 <_js_json_stringify_full+0x1c08>
10084b264:     	ldr	x8, [x0]
10084b268:     	cbnz	x8, 0x10084bd58 <_js_json_stringify_full+0x1c58>
10084b26c:     	str	xzr, [x0, #0x18]
10084b270:     	ldp	x22, x19, [sp, #0x48]
10084b274:     	ldrb	w8, [x23, #0x18]
10084b278:     	cmp	w8, #0x1
10084b27c:     	b.ne	0x10084bca0 <_js_json_stringify_full+0x1ba0>
10084b280:     	ldp	x8, x0, [x23]
10084b284:     	stp	x22, x19, [x23]
10084b288:     	str	xzr, [x23, #0x10]
10084b28c:     	sub	x8, x8, #0x1
10084b290:     	cmn	x8, #0x2
10084b294:     	b.hs	0x10084b29c <_js_json_stringify_full+0x119c>
10084b298:     	bl	0x100b63b80 <_mi_free>
10084b29c:     	cbz	w26, 0x10084b53c <_js_json_stringify_full+0x143c>
10084b2a0:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b2a4:     	b	0x10084b540 <_js_json_stringify_full+0x1440>
10084b2a8:     	mov	x10, #0x0               ; =0
10084b2ac:     	b	0x10084b498 <_js_json_stringify_full+0x1398>
10084b2b0:     	add	x0, sp, #0x48
10084b2b4:     	bl	0x100503164 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
10084b2b8:     	tbnz	w0, #0x0, 0x10084b2f4 <_js_json_stringify_full+0x11f4>
10084b2bc:     	mov	x0, x19
10084b2c0:     	bl	0x10032a7ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
10084b2c4:     	cmp	x0, #0x1
10084b2c8:     	b.ne	0x10084bd1c <_js_json_stringify_full+0x1c1c>
10084b2cc:     	add	x8, sp, #0x78
10084b2d0:     	add	x9, sp, #0x70
10084b2d4:     	stp	x1, x8, [sp, #0x78]
10084b2d8:     	str	x9, [sp, #0x88]
10084b2dc:     	add	x8, sp, #0x48
10084b2e0:     	add	x9, sp, #0x10
10084b2e4:     	stp	x8, x9, [sp, #0x90]
10084b2e8:     	add	x0, sp, #0x68
10084b2ec:     	add	x1, sp, #0x80
10084b2f0:     	bl	0x100143c90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
10084b2f4:     	add	x0, sp, #0x60
10084b2f8:     	bl	0x100166d7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
10084b2fc:     	b	0x10084aff0 <_js_json_stringify_full+0xef0>
10084b300:     	lsr	x8, x24, #52
10084b304:     	cbnz	x8, 0x10084b324 <_js_json_stringify_full+0x1224>
10084b308:     	cbz	x24, 0x10084b324 <_js_json_stringify_full+0x1224>
10084b30c:     	and	x8, x24, #0x7
10084b310:     	cbnz	x8, 0x10084b324 <_js_json_stringify_full+0x1224>
10084b314:     	mov	x0, x24
10084b318:     	bl	0x1005120b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084b31c:     	mov	x8, x24
10084b320:     	tbnz	w0, #0x0, 0x10084b0fc <_js_json_stringify_full+0xffc>
10084b324:     	mov	x0, x24
10084b328:     	bl	0x10050c42c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
10084b32c:     	tbz	w0, #0x0, 0x10084b3bc <_js_json_stringify_full+0x12bc>
10084b330:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b334:     	add	x0, x0, #0xd90
10084b338:     	ldr	x8, [x0]
10084b33c:     	blr	x8
10084b340:     	ldrb	w8, [x0, #0x20]
10084b344:     	cbnz	w8, 0x10084bc6c <_js_json_stringify_full+0x1b6c>
10084b348:     	ldr	x8, [x0]
10084b34c:     	cbnz	x8, 0x10084bc94 <_js_json_stringify_full+0x1b94>
10084b350:     	str	xzr, [x0, #0x18]
10084b354:     	ldp	x22, x19, [sp, #0x48]
10084b358:     	ldrb	w8, [x23, #0x18]
10084b35c:     	cmp	w8, #0x1
10084b360:     	b.ne	0x10084bc48 <_js_json_stringify_full+0x1b48>
10084b364:     	ldp	x8, x0, [x23]
10084b368:     	stp	x22, x19, [x23]
10084b36c:     	str	xzr, [x23, #0x10]
10084b370:     	sub	x8, x8, #0x1
10084b374:     	cmn	x8, #0x2
10084b378:     	b.hs	0x10084b380 <_js_json_stringify_full+0x1280>
10084b37c:     	bl	0x100b63b80 <_mi_free>
10084b380:     	cbz	w26, 0x10084b3a0 <_js_json_stringify_full+0x12a0>
10084b384:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b388:     	ldr	w8, [x21]
10084b38c:     	sub	w8, w8, #0x1
10084b390:     	str	w8, [x21]
10084b394:     	cmn	x25, #0x1
10084b398:     	b.ne	0x10084b55c <_js_json_stringify_full+0x145c>
10084b39c:     	b	0x10084b598 <_js_json_stringify_full+0x1498>
10084b3a0:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b3a4:     	ldr	w8, [x21]
10084b3a8:     	sub	w8, w8, #0x1
10084b3ac:     	str	w8, [x21]
10084b3b0:     	cmn	x25, #0x1
10084b3b4:     	b.ne	0x10084b55c <_js_json_stringify_full+0x145c>
10084b3b8:     	b	0x10084b598 <_js_json_stringify_full+0x1498>
10084b3bc:     	cmp	x19, x24
10084b3c0:     	b.eq	0x10084b3cc <_js_json_stringify_full+0x12cc>
10084b3c4:     	mov.16b	v0, v8
10084b3c8:     	bl	0x1005117ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
10084b3cc:     	cbz	x22, 0x10084b628 <_js_json_stringify_full+0x1528>
10084b3d0:     	ldp	x1, x2, [sp, #0x18]
10084b3d4:     	add	x0, sp, #0x48
10084b3d8:     	mov.16b	v0, v8
10084b3dc:     	mov	x3, #0x0                ; =0
10084b3e0:     	bl	0x100503bdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
10084b3e4:     	b	0x10084b638 <_js_json_stringify_full+0x1538>
10084b3e8:     	and	x9, x1, #0x4
10084b3ec:     	add	x8, x0, x9
10084b3f0:     	adrp	x10, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5270>
10084b3f4:     	ldr	q0, [x10, #0x600]
10084b3f8:     	adrp	x10, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33a7a>
10084b3fc:     	ldr	q2, [x10, #0x500]
10084b400:     	movi.2d	v1, #0000000000000000
10084b404:     	movi.2d	v3, #0x000000000000ff
10084b408:     	mov	w10, #0x4               ; =4
10084b40c:     	dup.2d	v4, x10
10084b410:     	mov	x10, x0
10084b414:     	and	x11, x1, #0x4
10084b418:     	movi.2d	v5, #0000000000000000
10084b41c:     	ldr	s6, [x10], #0x4
10084b420:     	ushll.8h	v6, v6, #0x0
10084b424:     	ushll.4s	v6, v6, #0x0
10084b428:     	ushll2.2d	v7, v6, #0x0
10084b42c:     	and.16b	v7, v7, v3
10084b430:     	ushll.2d	v6, v6, #0x0
10084b434:     	and.16b	v6, v6, v3
10084b438:     	shl.2d	v16, v0, #0x3
10084b43c:     	shl.2d	v17, v2, #0x3
10084b440:     	ushl.2d	v6, v6, v17
10084b444:     	ushl.2d	v7, v7, v16
10084b448:     	orr.16b	v1, v7, v1
10084b44c:     	orr.16b	v5, v6, v5
10084b450:     	add.2d	v0, v0, v4
10084b454:     	add.2d	v2, v2, v4
10084b458:     	subs	x11, x11, #0x4
10084b45c:     	b.ne	0x10084b41c <_js_json_stringify_full+0x131c>
10084b460:     	orr.16b	v0, v5, v1
10084b464:     	mov	d1, v0[1]
10084b468:     	orr.8b	v0, v0, v1
10084b46c:     	fmov	x10, d0
10084b470:     	cmp	x1, x9
10084b474:     	b.eq	0x10084b498 <_js_json_stringify_full+0x1398>
10084b478:     	add	x11, x0, x1
10084b47c:     	lsl	x9, x9, #3
10084b480:     	ldrb	w12, [x8], #0x1
10084b484:     	lsl	x12, x12, x9
10084b488:     	orr	x10, x12, x10
10084b48c:     	add	x9, x9, #0x8
10084b490:     	cmp	x8, x11
10084b494:     	b.ne	0x10084b480 <_js_json_stringify_full+0x1380>
10084b498:     	orr	x8, x10, x1, lsl #40
10084b49c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084b4a0:     	orr	x20, x8, x9
10084b4a4:     	ldr	x22, [sp, #0x48]
10084b4a8:     	ldrb	w8, [x23, #0x18]
10084b4ac:     	cmp	w8, #0x1
10084b4b0:     	b.ne	0x10084bbb8 <_js_json_stringify_full+0x1ab8>
10084b4b4:     	ldp	x9, x8, [x23]
10084b4b8:     	stp	x22, x0, [x23]
10084b4bc:     	str	xzr, [x23, #0x10]
10084b4c0:     	sub	x9, x9, #0x1
10084b4c4:     	cmn	x9, #0x2
10084b4c8:     	b.hs	0x10084b4d4 <_js_json_stringify_full+0x13d4>
10084b4cc:     	mov	x0, x8
10084b4d0:     	bl	0x100b63b80 <_mi_free>
10084b4d4:     	cbz	w26, 0x10084b4f4 <_js_json_stringify_full+0x13f4>
10084b4d8:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b4dc:     	ldr	w8, [x21]
10084b4e0:     	sub	w8, w8, #0x1
10084b4e4:     	str	w8, [x21]
10084b4e8:     	cmn	x25, #0x1
10084b4ec:     	b.ne	0x10084b50c <_js_json_stringify_full+0x140c>
10084b4f0:     	b	0x10084b598 <_js_json_stringify_full+0x1498>
10084b4f4:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b4f8:     	ldr	w8, [x21]
10084b4fc:     	sub	w8, w8, #0x1
10084b500:     	str	w8, [x21]
10084b504:     	cmn	x25, #0x1
10084b508:     	b.eq	0x10084b598 <_js_json_stringify_full+0x1498>
10084b50c:     	ldp	x19, x21, [sp, #0x38]
10084b510:     	cbz	x21, 0x10084b58c <_js_json_stringify_full+0x148c>
10084b514:     	add	x22, x19, #0x8
10084b518:     	b	0x10084b528 <_js_json_stringify_full+0x1428>
10084b51c:     	add	x22, x22, #0x18
10084b520:     	subs	x21, x21, #0x1
10084b524:     	b.eq	0x10084b58c <_js_json_stringify_full+0x148c>
10084b528:     	ldur	x8, [x22, #-0x8]
10084b52c:     	cbz	x8, 0x10084b51c <_js_json_stringify_full+0x141c>
10084b530:     	ldr	x0, [x22]
10084b534:     	bl	0x100b63b80 <_mi_free>
10084b538:     	b	0x10084b51c <_js_json_stringify_full+0x141c>
10084b53c:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b540:     	ldr	w8, [x21]
10084b544:     	sub	w8, w8, #0x1
10084b548:     	str	w8, [x21]
10084b54c:     	add	x0, sp, #0x60
10084b550:     	bl	0x100166d7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
10084b554:     	cmn	x25, #0x1
10084b558:     	b.eq	0x10084b598 <_js_json_stringify_full+0x1498>
10084b55c:     	ldp	x19, x21, [sp, #0x38]
10084b560:     	cbz	x21, 0x10084b58c <_js_json_stringify_full+0x148c>
10084b564:     	add	x22, x19, #0x8
10084b568:     	b	0x10084b578 <_js_json_stringify_full+0x1478>
10084b56c:     	add	x22, x22, #0x18
10084b570:     	subs	x21, x21, #0x1
10084b574:     	b.eq	0x10084b58c <_js_json_stringify_full+0x148c>
10084b578:     	ldur	x8, [x22, #-0x8]
10084b57c:     	cbz	x8, 0x10084b56c <_js_json_stringify_full+0x146c>
10084b580:     	ldr	x0, [x22]
10084b584:     	bl	0x100b63b80 <_mi_free>
10084b588:     	b	0x10084b56c <_js_json_stringify_full+0x146c>
10084b58c:     	cbz	x25, 0x10084b598 <_js_json_stringify_full+0x1498>
10084b590:     	mov	x0, x19
10084b594:     	bl	0x100b63b80 <_mi_free>
10084b598:     	ldr	x8, [sp, #0x10]
10084b59c:     	cbz	x8, 0x10084b5a8 <_js_json_stringify_full+0x14a8>
10084b5a0:     	ldr	x0, [sp, #0x18]
10084b5a4:     	bl	0x100b63b80 <_mi_free>
10084b5a8:     	mov	x0, x20
10084b5ac:     	ldp	x29, x30, [sp, #0x110]
10084b5b0:     	ldp	x20, x19, [sp, #0x100]
10084b5b4:     	ldp	x22, x21, [sp, #0xf0]
10084b5b8:     	ldp	x24, x23, [sp, #0xe0]
10084b5bc:     	ldp	x26, x25, [sp, #0xd0]
10084b5c0:     	ldp	x28, x27, [sp, #0xc0]
10084b5c4:     	ldp	d9, d8, [sp, #0xb0]
10084b5c8:     	add	sp, sp, #0x120
10084b5cc:     	ret
10084b5d0:     	str	x22, [sp, #0x8]
10084b5d4:     	mov	x22, x28
10084b5d8:     	mov	x28, x0
10084b5dc:     	add	x0, x0, #0x8
10084b5e0:     	bl	0x100b408d0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10084b5e4:     	mov	x0, x28
10084b5e8:     	mov	x28, x22
10084b5ec:     	ldr	x22, [sp, #0x8]
10084b5f0:     	b	0x10084ae18 <_js_json_stringify_full+0xd18>
10084b5f4:     	b.ne	0x10084ab5c <_js_json_stringify_full+0xa5c>
10084b5f8:     	tbz	x25, #0x3f, 0x10084b650 <_js_json_stringify_full+0x1550>
10084b5fc:     	mov	x0, #0x0                ; =0
10084b600:     	mov	x1, x25
10084b604:     	bl	0x100b16f00 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084b608:     	bl	0x100b43f7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084b60c:     	add	x8, x0, x23, lsl #3
10084b610:     	ldr	x0, [x8, #0x1e8]
10084b614:     	cbnz	x0, 0x10084aeac <_js_json_stringify_full+0xdac>
10084b618:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084b61c:     	add	x0, x0, #0x138
10084b620:     	bl	0x100b4179c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084b624:     	b	0x10084aeac <_js_json_stringify_full+0xdac>
10084b628:     	add	x1, sp, #0x48
10084b62c:     	mov.16b	v0, v8
10084b630:     	mov	w0, #0x0                ; =0
10084b634:     	bl	0x10050c504 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
10084b638:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b63c:     	add	x0, x0, #0xdc0
10084b640:     	ldr	x8, [x0]
10084b644:     	blr	x8
10084b648:     	strb	wzr, [x0]
10084b64c:     	b	0x10084aff0 <_js_json_stringify_full+0xef0>
10084b650:     	mov	x0, x25
10084b654:     	mov	w1, #0x1                ; =1
10084b658:     	bl	0x100b63e08 <_mi_malloc_aligned>
10084b65c:     	mov	x26, x0
10084b660:     	mov	w0, #0x1                ; =1
10084b664:     	cbz	x26, 0x10084b600 <_js_json_stringify_full+0x1500>
10084b668:     	mov	x0, x26
10084b66c:     	mov	x1, x23
10084b670:     	mov	x2, x25
10084b674:     	bl	0x100b66a2c <_writev+0x100b66a2c>
10084b678:     	mov	x22, x25
10084b67c:     	b	0x10084ab80 <_js_json_stringify_full+0xa80>
10084b680:     	cmp	w11, #0x8
10084b684:     	b.eq	0x10084b750 <_js_json_stringify_full+0x1650>
10084b688:     	cmp	w11, #0x9
10084b68c:     	b.eq	0x10084b760 <_js_json_stringify_full+0x1660>
10084b690:     	cmp	w11, #0xa
10084b694:     	b.ne	0x10084b6dc <_js_json_stringify_full+0x15dc>
10084b698:     	mov	w10, #0x6e              ; =110
10084b69c:     	b	0x10084b764 <_js_json_stringify_full+0x1664>
10084b6a0:     	mov	x22, x0
10084b6a4:     	and	x0, x19, #0xffffffffffff
10084b6a8:     	bl	0x10034a600 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084b6ac:     	cbz	x0, 0x10084b788 <_js_json_stringify_full+0x1688>
10084b6b0:     	ldr	w20, [x0]
10084b6b4:     	cmp	w20, #0x4
10084b6b8:     	b.hi	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084b6bc:     	ldr	w8, [x0, #0x4]
10084b6c0:     	cmp	w20, w8
10084b6c4:     	b.hi	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084b6c8:     	b	0x10084b78c <_js_json_stringify_full+0x168c>
10084b6cc:     	cmp	w11, #0x22
10084b6d0:     	b.eq	0x10084b764 <_js_json_stringify_full+0x1664>
10084b6d4:     	cmp	w11, #0x5c
10084b6d8:     	b.eq	0x10084b764 <_js_json_stringify_full+0x1664>
10084b6dc:     	cmp	x12, #0x3
10084b6e0:     	mov	w11, #0x20              ; =32
10084b6e4:     	ccmp	w10, w11, #0x8, ls
10084b6e8:     	b.lt	0x10084a614 <_js_json_stringify_full+0x514>
10084b6ec:     	add	x8, sp, #0x80
10084b6f0:     	strb	w10, [x8, x12]
10084b6f4:     	add	x12, x12, #0x1
10084b6f8:     	b	0x10084a304 <_js_json_stringify_full+0x204>
10084b6fc:     	mov	x1, x0
10084b700:     	and	x0, x19, #0xffffffffffff
10084b704:     	mov	x22, x1
10084b708:     	bl	0x1004fbac0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
10084b70c:     	cmp	x0, #0x1
10084b710:     	b.ne	0x10084b834 <_js_json_stringify_full+0x1734>
10084b714:     	mov	x20, x1
10084b718:     	b	0x10084b5a8 <_js_json_stringify_full+0x14a8>
10084b71c:     	ldrb	w9, [x8, #0x118]
10084b720:     	cbz	w9, 0x10084b95c <_js_json_stringify_full+0x185c>
10084b724:     	ldr	x9, [x8, #0x110]
10084b728:     	cmp	x9, x1
10084b72c:     	b.ne	0x10084b95c <_js_json_stringify_full+0x185c>
10084b730:     	ldr	x9, [x8, #0xf0]
10084b734:     	cmp	x9, x23
10084b738:     	b.hi	0x10084b95c <_js_json_stringify_full+0x185c>
10084b73c:     	ldr	x9, [x8, #0xf8]
10084b740:     	cmp	x9, x23
10084b744:     	b.ls	0x10084b95c <_js_json_stringify_full+0x185c>
10084b748:     	add	x9, x8, #0xf0
10084b74c:     	b	0x10084bb68 <_js_json_stringify_full+0x1a68>
10084b750:     	mov	w10, #0x62              ; =98
10084b754:     	b	0x10084b764 <_js_json_stringify_full+0x1664>
10084b758:     	mov	w10, #0x66              ; =102
10084b75c:     	b	0x10084b764 <_js_json_stringify_full+0x1664>
10084b760:     	mov	w10, #0x74              ; =116
10084b764:     	cmp	x12, #0x2
10084b768:     	b.hi	0x10084a614 <_js_json_stringify_full+0x514>
10084b76c:     	add	x8, sp, #0x80
10084b770:     	add	x8, x8, x12
10084b774:     	add	x12, x12, #0x2
10084b778:     	mov	w11, #0x5c              ; =92
10084b77c:     	strb	w11, [x8]
10084b780:     	strb	w10, [x8, #0x1]
10084b784:     	b	0x10084a304 <_js_json_stringify_full+0x204>
10084b788:     	mov	x20, #0x0               ; =0
10084b78c:     	ldr	w8, [x22, #0x4]
10084b790:     	lsl	x9, x20, #3
10084b794:     	add	x9, x9, #0x18
10084b798:     	cmp	x9, x8
10084b79c:     	b.hi	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084b7a0:     	ldr	w8, [x25, #0x4]
10084b7a4:     	mov	w9, #-0x40000000        ; =-1073741824
10084b7a8:     	cmp	w8, w9
10084b7ac:     	csel	w8, w8, wzr, lt
10084b7b0:     	mov	x22, x0
10084b7b4:     	mov	x0, x8
10084b7b8:     	bl	0x1005e8664 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084b7bc:     	mov	w9, #0x2                ; =2
10084b7c0:     	cmp	w1, #0x2
10084b7c4:     	csel	w10, w1, w9, hi
10084b7c8:     	tst	w0, #0x1
10084b7cc:     	csel	x8, x10, x9, ne
10084b7d0:     	cmp	x20, x8
10084b7d4:     	b.hi	0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084b7d8:     	cbz	x20, 0x10084bb98 <_js_json_stringify_full+0x1a98>
10084b7dc:     	mov	x0, x22
10084b7e0:     	mov	x1, x20
10084b7e4:     	bl	0x1004f2a40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084b7e8:     	tbz	w0, #0x0, 0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084b7ec:     	cmp	x20, #0x1
10084b7f0:     	b.eq	0x10084bc34 <_js_json_stringify_full+0x1b34>
10084b7f4:     	cmp	x20, #0x2
10084b7f8:     	b.ne	0x10084bcf0 <_js_json_stringify_full+0x1bf0>
10084b7fc:     	mov	x22, #0x0               ; =0
10084b800:     	add	x25, x25, #0x10
10084b804:     	mov	w8, #0x1                ; =1
10084b808:     	mov	x26, x8
10084b80c:     	ldr	x1, [x25, x22, lsl #3]
10084b810:     	add	x0, sp, #0x80
10084b814:     	bl	0x1004f2a94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
10084b818:     	ldr	w8, [sp, #0x80]
10084b81c:     	cmn	w8, #0x1
10084b820:     	b.ne	0x10084bcd8 <_js_json_stringify_full+0x1bd8>
10084b824:     	mov	w8, #0x0                ; =0
10084b828:     	mov	w22, #0x1               ; =1
10084b82c:     	tbnz	w26, #0x0, 0x10084b808 <_js_json_stringify_full+0x1708>
10084b830:     	b	0x10084bcf0 <_js_json_stringify_full+0x1bf0>
10084b834:     	and	x0, x19, #0xffffffffffff
10084b838:     	bl	0x10034a600 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084b83c:     	cbz	x0, 0x10084b8c8 <_js_json_stringify_full+0x17c8>
10084b840:     	ldr	w20, [x0]
10084b844:     	cbz	w20, 0x10084b8c8 <_js_json_stringify_full+0x17c8>
10084b848:     	cmp	w20, #0x8
10084b84c:     	b.hi	0x10084a6a4 <_js_json_stringify_full+0x5a4>
10084b850:     	ldr	w8, [x0, #0x4]
10084b854:     	cmp	w20, w8
10084b858:     	b.hi	0x10084a6a4 <_js_json_stringify_full+0x5a4>
10084b85c:     	ldr	w8, [x22, #0x4]
10084b860:     	lsl	x9, x20, #3
10084b864:     	add	x9, x9, #0x18
10084b868:     	cmp	x9, x8
10084b86c:     	b.hi	0x10084a6a4 <_js_json_stringify_full+0x5a4>
10084b870:     	ldr	w8, [x25, #0x4]
10084b874:     	mov	w9, #-0x40000000        ; =-1073741824
10084b878:     	cmp	w8, w9
10084b87c:     	csel	w8, w8, wzr, lt
10084b880:     	mov	x22, x0
10084b884:     	mov	x0, x8
10084b888:     	bl	0x1005e8664 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084b88c:     	mov	w9, #0x2                ; =2
10084b890:     	cmp	w1, #0x2
10084b894:     	csel	w10, w1, w9, hi
10084b898:     	tst	w0, #0x1
10084b89c:     	csel	w8, w10, w9, ne
10084b8a0:     	cmp	w20, w8
10084b8a4:     	b.hi	0x10084a6a4 <_js_json_stringify_full+0x5a4>
10084b8a8:     	mov	x0, x22
10084b8ac:     	mov	x1, x20
10084b8b0:     	bl	0x1004f2a40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084b8b4:     	cbz	w0, 0x10084a6a4 <_js_json_stringify_full+0x5a4>
10084b8b8:     	and	x0, x19, #0xffffffffffff
10084b8bc:     	mov	x1, x20
10084b8c0:     	bl	0x1004fac00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
10084b8c4:     	b	0x10084b8d0 <_js_json_stringify_full+0x17d0>
10084b8c8:     	and	x0, x19, #0xffffffffffff
10084b8cc:     	bl	0x1004fb980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
10084b8d0:     	mov	x20, x1
10084b8d4:     	tbz	w0, #0x0, 0x10084a6a4 <_js_json_stringify_full+0x5a4>
10084b8d8:     	b	0x10084b5a8 <_js_json_stringify_full+0x14a8>
10084b8dc:     	add	x9, x8, #0x60
10084b8e0:     	b	0x10084bb68 <_js_json_stringify_full+0x1a68>
10084b8e4:     	bl	0x100b43f7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084b8e8:     	lsr	x1, x23, #20
10084b8ec:     	ldr	x8, [x0, #0x10]
10084b8f0:     	ldrb	w9, [x8]
10084b8f4:     	cmp	w9, #0x2
10084b8f8:     	b.eq	0x10084ac88 <_js_json_stringify_full+0xb88>
10084b8fc:     	ldr	x9, [x8, #0x8]
10084b900:     	ldr	x10, [x8, #0x28]
10084b904:     	sub	x9, x1, x9
10084b908:     	cmp	x9, x10
10084b90c:     	b.hs	0x10084b950 <_js_json_stringify_full+0x1850>
10084b910:     	ldr	x10, [x8, #0x20]
10084b914:     	mov	w11, #0x28              ; =40
10084b918:     	madd	x9, x9, x11, x10
10084b91c:     	ldr	x10, [x9]
10084b920:     	ldr	x11, [x8, #0x10]
10084b924:     	cmp	x10, x11
10084b928:     	b.ne	0x10084b95c <_js_json_stringify_full+0x185c>
10084b92c:     	ldp	x10, x11, [x9, #0x8]
10084b930:     	cmp	x10, x23
10084b934:     	ccmp	x11, x23, #0x0, ls
10084b938:     	b.ls	0x10084b95c <_js_json_stringify_full+0x185c>
10084b93c:     	ldr	x10, [x8, #0x30]
10084b940:     	add	x10, x10, #0x1
10084b944:     	str	x10, [x8, #0x30]
10084b948:     	add	x8, x9, #0x21
10084b94c:     	b	0x10084bb78 <_js_json_stringify_full+0x1a78>
10084b950:     	ldr	x9, [x8, #0x58]
10084b954:     	add	x9, x9, #0x1
10084b958:     	str	x9, [x8, #0x58]
10084b95c:     	ldr	x9, [x8, #0x38]
10084b960:     	add	x9, x9, #0x1
10084b964:     	str	x9, [x8, #0x38]
10084b968:     	mov	x0, x23
10084b96c:     	bl	0x1005212c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
10084b970:     	and	w8, w0, #0xff
10084b974:     	cbz	w8, 0x10084b994 <_js_json_stringify_full+0x1894>
10084b978:     	ldurb	w8, [x23, #-0x8]
10084b97c:     	ldurb	w9, [x23, #-0x7]
10084b980:     	mov	w10, #0x82              ; =130
10084b984:     	and	w9, w9, w10
10084b988:     	cmp	w9, #0x2
10084b98c:     	ccmp	w8, #0x1, #0x0, eq
10084b990:     	b.eq	0x10084ba28 <_js_json_stringify_full+0x1928>
10084b994:     	mov	x0, x23
10084b998:     	bl	0x10057d940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084b99c:     	mov	x24, x0
10084b9a0:     	cbz	x0, 0x10084b9cc <_js_json_stringify_full+0x18cc>
10084b9a4:     	ldrb	w8, [x24]
10084b9a8:     	cmp	w8, #0x1
10084b9ac:     	b.ne	0x10084b9ec <_js_json_stringify_full+0x18ec>
10084b9b0:     	ldrsb	w8, [x24, #0x1]
10084b9b4:     	tbnz	w8, #0x1f, 0x10084ba50 <_js_json_stringify_full+0x1950>
10084b9b8:     	mov	x0, x24
10084b9bc:     	ldp	w9, w8, [x23]
10084b9c0:     	cmp	w9, w8
10084b9c4:     	b.hi	0x10084bad4 <_js_json_stringify_full+0x19d4>
10084b9c8:     	b	0x10084baec <_js_json_stringify_full+0x19ec>
10084b9cc:     	mov	x0, x23
10084b9d0:     	bl	0x10058c174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10084b9d4:     	tbnz	w0, #0x0, 0x10084b9e4 <_js_json_stringify_full+0x18e4>
10084b9d8:     	mov	x0, x23
10084b9dc:     	bl	0x1002a6908 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
10084b9e0:     	tbz	w0, #0x0, 0x10084ad28 <_js_json_stringify_full+0xc28>
10084b9e4:     	mov	x0, #0x0                ; =0
10084b9e8:     	b	0x10084bac4 <_js_json_stringify_full+0x19c4>
10084b9ec:     	mov	x0, x24
10084b9f0:     	cmp	w8, #0x1
10084b9f4:     	b.eq	0x10084bac4 <_js_json_stringify_full+0x19c4>
10084b9f8:     	cmp	w8, #0x9
10084b9fc:     	b.ne	0x10084ad28 <_js_json_stringify_full+0xc28>
10084ba00:     	ldr	w8, [x23, #0x4]
10084ba04:     	mov	w9, #0x5841             ; =22593
10084ba08:     	movk	w9, #0x4c5a, lsl #16
10084ba0c:     	cmp	w8, w9
10084ba10:     	b.ne	0x10084ad28 <_js_json_stringify_full+0xc28>
10084ba14:     	mov	x0, x23
10084ba18:     	bl	0x100378910 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
10084ba1c:     	mov	x23, x0
10084ba20:     	cbnz	x0, 0x10084bb14 <_js_json_stringify_full+0x1a14>
10084ba24:     	b	0x10084ad28 <_js_json_stringify_full+0xc28>
10084ba28:     	ldr	w8, [x23]
10084ba2c:     	mov	w9, #0xe100             ; =57600
10084ba30:     	movk	w9, #0x5f5, lsl #16
10084ba34:     	orr	w9, w9, #0x1
10084ba38:     	cmp	w8, w9
10084ba3c:     	b.hs	0x10084b994 <_js_json_stringify_full+0x1894>
10084ba40:     	ldr	w9, [x23, #0x4]
10084ba44:     	cmp	w8, w9
10084ba48:     	b.ls	0x10084bb14 <_js_json_stringify_full+0x1a14>
10084ba4c:     	b	0x10084b994 <_js_json_stringify_full+0x1894>
10084ba50:     	ldr	x23, [x24, #0x8]
10084ba54:     	mov	x0, x23
10084ba58:     	bl	0x10057d940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084ba5c:     	cbz	x0, 0x10084ad28 <_js_json_stringify_full+0xc28>
10084ba60:     	ldrb	w8, [x0]
10084ba64:     	cmp	w8, #0x1
10084ba68:     	b.ne	0x10084ad28 <_js_json_stringify_full+0xc28>
10084ba6c:     	ldrsb	w8, [x0, #0x1]
10084ba70:     	tbz	w8, #0x1f, 0x10084b9bc <_js_json_stringify_full+0x18bc>
10084ba74:     	mov	w26, #0x1               ; =1
10084ba78:     	ldr	x23, [x0, #0x8]
10084ba7c:     	mov	x0, x23
10084ba80:     	bl	0x10057d940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084ba84:     	cbz	x0, 0x10084ad28 <_js_json_stringify_full+0xc28>
10084ba88:     	ldrb	w8, [x0]
10084ba8c:     	cmp	w8, #0x1
10084ba90:     	b.ne	0x10084ad28 <_js_json_stringify_full+0xc28>
10084ba94:     	cmp	w26, #0x3f
10084ba98:     	b.hi	0x10084ad28 <_js_json_stringify_full+0xc28>
10084ba9c:     	add	w26, w26, #0x1
10084baa0:     	ldrsb	w8, [x0, #0x1]
10084baa4:     	tbnz	w8, #0x1f, 0x10084ba78 <_js_json_stringify_full+0x1978>
10084baa8:     	str	x23, [x24, #0x8]
10084baac:     	ldrb	w8, [x24, #0x1]
10084bab0:     	orr	w8, w8, #0x80
10084bab4:     	strb	w8, [x24, #0x1]
10084bab8:     	ldrb	w8, [x0]
10084babc:     	cmp	w8, #0x1
10084bac0:     	b.ne	0x10084b9f8 <_js_json_stringify_full+0x18f8>
10084bac4:     	ldp	w9, w8, [x23]
10084bac8:     	cmp	w9, w8
10084bacc:     	b.ls	0x10084baec <_js_json_stringify_full+0x19ec>
10084bad0:     	cbz	x24, 0x10084bafc <_js_json_stringify_full+0x19fc>
10084bad4:     	ldr	w9, [x0, #0x4]
10084bad8:     	ubfiz	x8, x8, #3, #32
10084badc:     	add	x8, x8, #0x10
10084bae0:     	cmp	x8, x9
10084bae4:     	b.eq	0x10084bb14 <_js_json_stringify_full+0x1a14>
10084bae8:     	b	0x10084bafc <_js_json_stringify_full+0x19fc>
10084baec:     	mov	w8, #0xe100             ; =57600
10084baf0:     	movk	w8, #0x5f5, lsl #16
10084baf4:     	cmp	w9, w8
10084baf8:     	b.ls	0x10084bb14 <_js_json_stringify_full+0x1a14>
10084bafc:     	mov	x0, x23
10084bb00:     	bl	0x10058c174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10084bb04:     	tbnz	w0, #0x0, 0x10084bb14 <_js_json_stringify_full+0x1a14>
10084bb08:     	mov	x0, x23
10084bb0c:     	bl	0x1002a6908 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
10084bb10:     	tbz	w0, #0x0, 0x10084ad28 <_js_json_stringify_full+0xc28>
10084bb14:     	ldp	w8, w9, [x23]
10084bb18:     	sub	w10, w9, #0x1
10084bb1c:     	mov	w11, #0x270f            ; =9999
10084bb20:     	cmp	w10, w11
10084bb24:     	ccmp	w8, w9, #0x2, lo
10084bb28:     	b.hi	0x10084ad28 <_js_json_stringify_full+0xc28>
10084bb2c:     	and	x8, x21, #0xffffffffffff
10084bb30:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084bb34:     	cmp	x25, x9
10084bb38:     	csel	x1, x8, x21, eq
10084bb3c:     	add	x0, sp, #0x30
10084bb40:     	bl	0x10050296c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
10084bb44:     	ldr	x25, [sp, #0x30]
10084bb48:     	cmn	x25, #0x1
10084bb4c:     	cset	w24, eq
10084bb50:     	cmp	x27, #0x1
10084bb54:     	cset	w8, hi
10084bb58:     	tst	w8, w24
10084bb5c:     	b.ne	0x10084ad44 <_js_json_stringify_full+0xc44>
10084bb60:     	b	0x10084adb4 <_js_json_stringify_full+0xcb4>
10084bb64:     	add	x9, x8, #0x90
10084bb68:     	ldr	x10, [x8, #0x30]
10084bb6c:     	add	x10, x10, #0x1
10084bb70:     	str	x10, [x8, #0x30]
10084bb74:     	add	x8, x9, #0x19
10084bb78:     	ldrb	w8, [x8]
10084bb7c:     	cmp	w8, #0xff
10084bb80:     	b.ne	0x10084b974 <_js_json_stringify_full+0x1874>
10084bb84:     	b	0x10084b968 <_js_json_stringify_full+0x1868>
10084bb88:     	mov	x0, x23
10084bb8c:     	bl	0x100b23104 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084bb90:     	cbnz	x0, 0x10084aed0 <_js_json_stringify_full+0xdd0>
10084bb94:     	b	0x10084bd10 <_js_json_stringify_full+0x1c10>
10084bb98:     	and	x0, x19, #0xffffffffffff
10084bb9c:     	bl	0x1004faa30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
10084bba0:     	mov	w0, w0
10084bba4:     	mov	x20, #0x7d7b            ; =32123
10084bba8:     	movk	x20, #0x200, lsl #32
10084bbac:     	movk	x20, #0x7ff9, lsl #48
10084bbb0:     	tbz	w0, #0x0, 0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084bbb4:     	b	0x10084b5a8 <_js_json_stringify_full+0x14a8>
10084bbb8:     	mov	x19, x0
10084bbbc:     	mov	x0, x23
10084bbc0:     	bl	0x100b23104 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084bbc4:     	mov	x23, x0
10084bbc8:     	mov	x0, x19
10084bbcc:     	cbnz	x23, 0x10084b4b4 <_js_json_stringify_full+0x13b4>
10084bbd0:     	b	0x10084bcb0 <_js_json_stringify_full+0x1bb0>
10084bbd4:     	bl	0x100b23264 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084bbd8:     	cbnz	x0, 0x10084adf8 <_js_json_stringify_full+0xcf8>
10084bbdc:     	b	0x10084bd10 <_js_json_stringify_full+0x1c10>
10084bbe0:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10084bbe4:     	add	x0, x0, #0x440
10084bbe8:     	bl	0x100b172ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084bbec:     	cmp	w8, #0x1
10084bbf0:     	b.ne	0x10084bd10 <_js_json_stringify_full+0x1c10>
10084bbf4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084bbf8:     	add	x1, x1, #0x898
10084bbfc:     	mov	x19, x0
10084bc00:     	bl	0x100a24fdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084bc04:     	mov	x0, x19
10084bc08:     	strb	wzr, [x19, #0x20]
10084bc0c:     	ldr	x8, [x19]
10084bc10:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10084bc14:     	cmp	x8, x9
10084bc18:     	b.lo	0x10084b018 <_js_json_stringify_full+0xf18>
10084bc1c:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084bc20:     	add	x0, x0, #0xea8
10084bc24:     	bl	0x100b172dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084bc28:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084bc2c:     	add	x0, x0, #0xec0
10084bc30:     	bl	0x100b172ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084bc34:     	and	x0, x19, #0xffffffffffff
10084bc38:     	bl	0x1004f2640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
10084bc3c:     	mov	x20, x1
10084bc40:     	tbz	w0, #0x0, 0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084bc44:     	b	0x10084b5a8 <_js_json_stringify_full+0x14a8>
10084bc48:     	mov	x0, x23
10084bc4c:     	bl	0x100b23104 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084bc50:     	mov	x23, x0
10084bc54:     	cbnz	x0, 0x10084b364 <_js_json_stringify_full+0x1264>
10084bc58:     	b	0x10084bcb0 <_js_json_stringify_full+0x1bb0>
10084bc5c:     	adrp	x0, 0x100efb000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
10084bc60:     	add	x0, x0, #0xd70
10084bc64:     	bl	0x100b172dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084bc68:     	bl	0x100b50514 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
10084bc6c:     	cmp	w8, #0x2
10084bc70:     	b.eq	0x10084bd10 <_js_json_stringify_full+0x1c10>
10084bc74:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084bc78:     	add	x1, x1, #0x898
10084bc7c:     	mov	x19, x0
10084bc80:     	bl	0x100a24fdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084bc84:     	mov	x0, x19
10084bc88:     	strb	wzr, [x19, #0x20]
10084bc8c:     	ldr	x8, [x19]
10084bc90:     	cbz	x8, 0x10084b350 <_js_json_stringify_full+0x1250>
10084bc94:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084bc98:     	add	x0, x0, #0xe90
10084bc9c:     	bl	0x100b172ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084bca0:     	mov	x0, x23
10084bca4:     	bl	0x100b23104 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084bca8:     	mov	x23, x0
10084bcac:     	cbnz	x0, 0x10084b280 <_js_json_stringify_full+0x1180>
10084bcb0:     	cbz	x22, 0x10084bd10 <_js_json_stringify_full+0x1c10>
10084bcb4:     	mov	x0, x19
10084bcb8:     	bl	0x100b63b80 <_mi_free>
10084bcbc:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084bcc0:     	add	x0, x0, #0xc18
10084bcc4:     	bl	0x100b5d1dc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084bcc8:     	adrp	x0, 0x100c47000 <_PERRY_EMPTY_STRING+0xeb4>
10084bccc:     	add	x0, x0, #0x70
10084bcd0:     	mov	w1, #0xf                ; =15
10084bcd4:     	bl	0x100b504dc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084bcd8:     	and	x0, x19, #0xffffffffffff
10084bcdc:     	add	x2, sp, #0x80
10084bce0:     	mov	x1, x22
10084bce4:     	bl	0x1004f2e40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
10084bce8:     	tbnz	w0, #0x0, 0x10084b714 <_js_json_stringify_full+0x1614>
10084bcec:     	mov	w20, #0x2               ; =2
10084bcf0:     	and	x0, x19, #0xffffffffffff
10084bcf4:     	mov	x1, x20
10084bcf8:     	bl	0x1004f14c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
10084bcfc:     	mov	x20, x1
10084bd00:     	tbz	w0, #0x0, 0x10084a6d8 <_js_json_stringify_full+0x5d8>
10084bd04:     	b	0x10084b5a8 <_js_json_stringify_full+0x14a8>
10084bd08:     	cmp	w8, #0x2
10084bd0c:     	b.ne	0x10084bd38 <_js_json_stringify_full+0x1c38>
10084bd10:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084bd14:     	add	x0, x0, #0xc18
10084bd18:     	bl	0x100b5d1dc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084bd1c:     	adrp	x0, 0x100f33000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x148>
10084bd20:     	add	x0, x0, #0x890
10084bd24:     	bl	0x100b17370 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
10084bd28:     	adrp	x0, 0x100c46000 <_anon.3a0f55142d697dd4d6c50f8035b0d3d6.3+0x5380>
10084bd2c:     	add	x0, x0, #0xda7
10084bd30:     	mov	w1, #0xb                ; =11
10084bd34:     	bl	0x100b504dc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084bd38:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084bd3c:     	add	x1, x1, #0x898
10084bd40:     	mov	x19, x0
10084bd44:     	bl	0x100a24fdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084bd48:     	mov	x0, x19
10084bd4c:     	strb	wzr, [x19, #0x20]
10084bd50:     	ldr	x8, [x19]
10084bd54:     	cbz	x8, 0x10084b26c <_js_json_stringify_full+0x116c>
10084bd58:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084bd5c:     	add	x0, x0, #0xe78
10084bd60:     	bl	0x100b172ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084bd64:     	mov	w0, #0x1                ; =1
10084bd68:     	mov	x1, x24
10084bd6c:     	bl	0x100b16f00 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084bd70:     	mov	w0, #0x1                ; =1
10084bd74:     	mov	x1, x22
10084bd78:     	bl	0x100b16f00 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084bd7c:     	adrp	x2, 0x100efc000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
10084bd80:     	add	x2, x2, #0x3c8
10084bd84:     	mov	w0, #0x5                ; =5
10084bd88:     	mov	w1, #0x5                ; =5
10084bd8c:     	bl	0x100b1740c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
