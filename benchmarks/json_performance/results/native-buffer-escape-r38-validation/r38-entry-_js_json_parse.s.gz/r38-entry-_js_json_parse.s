
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/native-buffer-escape-r38/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100848c94 <_js_json_parse>:
100848c94:     	stp	x29, x30, [sp, #-0x10]!
100848c98:     	mov	x29, sp
100848c9c:     	cbz	x0, 0x100848cf4 <_js_json_parse+0x60>
100848ca0:     	ldr	w1, [x0, #0x4]
100848ca4:     	cmp	w1, #0x2
100848ca8:     	b.eq	0x100848cb8 <_js_json_parse+0x24>
100848cac:     	cbz	w1, 0x100848cf4 <_js_json_parse+0x60>
100848cb0:     	ldrb	w8, [x0, #0x14]
100848cb4:     	b	0x100848cd8 <_js_json_parse+0x44>
100848cb8:     	ldrb	w8, [x0, #0x14]
100848cbc:     	cmp	w8, #0x7b
100848cc0:     	b.ne	0x100848cd8 <_js_json_parse+0x44>
100848cc4:     	ldrb	w8, [x0, #0x15]
100848cc8:     	cmp	w8, #0x7d
100848ccc:     	b.ne	0x100848ce4 <_js_json_parse+0x50>
100848cd0:     	ldp	x29, x30, [sp], #0x10
100848cd4:     	b	0x1004ef3c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100848cd8:     	orr	w8, w8, #0x20
100848cdc:     	cmp	w8, #0x7b
100848ce0:     	b.ne	0x100848cec <_js_json_parse+0x58>
100848ce4:     	ldp	x29, x30, [sp], #0x10
100848ce8:     	b	0x100508c48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
100848cec:     	ldp	x29, x30, [sp], #0x10
100848cf0:     	b	0x10050b38c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100848cf4:     	adrp	x0, 0x100c7a000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x731c>
100848cf8:     	add	x0, x0, #0x1c1
100848cfc:     	mov	w1, #0x1c               ; =28
100848d00:     	bl	0x10050b7c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
