
benchmarks/json_performance/.work/native-buffer-escape-r38/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010034e1b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>:
10034e1b0:     	stp	x22, x21, [sp, #-0x30]!
10034e1b4:     	stp	x20, x19, [sp, #0x10]
10034e1b8:     	stp	x29, x30, [sp, #0x20]
10034e1bc:     	add	x29, sp, #0x20
10034e1c0:     	lsr	x8, x1, #32
10034e1c4:     	cbnz	x8, 0x10034e48c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x2dc>
10034e1c8:     	mov	x19, x1
10034e1cc:     	mov	x20, x0
10034e1d0:     	cmp	x1, #0x40
10034e1d4:     	b.hs	0x10034e334 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x184>
10034e1d8:     	ands	x9, x19, #0x38
10034e1dc:     	b.eq	0x10034e200 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x50>
10034e1e0:     	and	x8, x19, #0x38
10034e1e4:     	neg	x8, x8
10034e1e8:     	mov	x10, x20
10034e1ec:     	ldr	x11, [x10], #0x8
10034e1f0:     	tst	x11, #0x8080808080808080
10034e1f4:     	b.ne	0x10034e274 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xc4>
10034e1f8:     	adds	x8, x8, #0x8
10034e1fc:     	b.ne	0x10034e1ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x3c>
10034e200:     	and	x8, x19, #0x7
10034e204:     	cbz	x8, 0x10034e3b4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x204>
10034e208:     	add	x9, x20, x9
10034e20c:     	ldrsb	w10, [x9]
10034e210:     	tbnz	w10, #0x1f, 0x10034e274 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xc4>
10034e214:     	cmp	x8, #0x1
10034e218:     	b.eq	0x10034e3b4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x204>
10034e21c:     	ldrsb	w10, [x9, #0x1]
10034e220:     	tbnz	w10, #0x1f, 0x10034e274 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xc4>
10034e224:     	cmp	x8, #0x2
10034e228:     	b.eq	0x10034e3b4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x204>
10034e22c:     	ldrsb	w10, [x9, #0x2]
10034e230:     	tbnz	w10, #0x1f, 0x10034e274 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xc4>
10034e234:     	cmp	x8, #0x3
10034e238:     	b.eq	0x10034e3b4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x204>
10034e23c:     	ldrsb	w10, [x9, #0x3]
10034e240:     	tbnz	w10, #0x1f, 0x10034e274 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xc4>
10034e244:     	cmp	x8, #0x4
10034e248:     	b.eq	0x10034e3b4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x204>
10034e24c:     	ldrsb	w10, [x9, #0x4]
10034e250:     	tbnz	w10, #0x1f, 0x10034e274 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xc4>
10034e254:     	cmp	x8, #0x5
10034e258:     	b.eq	0x10034e3b4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x204>
10034e25c:     	ldrsb	w10, [x9, #0x5]
10034e260:     	tbnz	w10, #0x1f, 0x10034e274 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xc4>
10034e264:     	cmp	x8, #0x6
10034e268:     	b.eq	0x10034e3b4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x204>
10034e26c:     	ldrsb	w8, [x9, #0x6]
10034e270:     	tbz	w8, #0x1f, 0x10034e3b4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x204>
10034e274:     	cbz	x19, 0x10034e438 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x288>
10034e278:     	mov	x0, #0x0                ; =0
10034e27c:     	mov	w21, #0x0               ; =0
10034e280:     	mov	w8, #0x0                ; =0
10034e284:     	b	0x10034e2a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xf8>
10034e288:     	adds	w9, w21, #0x1
10034e28c:     	csinv	w21, w9, wzr, lo
10034e290:     	mov	w9, #0x1                ; =1
10034e294:     	add	x9, x9, x0
10034e298:     	cmp	x19, x9
10034e29c:     	csel	x0, x19, x9, lo
10034e2a0:     	cmp	x9, x19
10034e2a4:     	b.hs	0x10034e404 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x254>
10034e2a8:     	cmp	x0, x19
10034e2ac:     	b.hs	0x10034e47c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x2cc>
10034e2b0:     	ldrsb	w9, [x20, x0]
10034e2b4:     	tbz	w9, #0x1f, 0x10034e288 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xd8>
10034e2b8:     	and	w9, w9, #0xff
10034e2bc:     	cmp	w9, #0xc0
10034e2c0:     	b.lo	0x10034e290 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xe0>
10034e2c4:     	add	x10, x0, #0x1
10034e2c8:     	cmp	x10, x19
10034e2cc:     	b.hs	0x10034e2f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x148>
10034e2d0:     	ldrb	w10, [x20, x10]
10034e2d4:     	and	w10, w10, #0x3f
10034e2d8:     	cmp	w9, #0xe0
10034e2dc:     	b.lo	0x10034e304 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x154>
10034e2e0:     	cmp	w9, #0xf0
10034e2e4:     	b.hs	0x10034e324 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x174>
10034e2e8:     	ubfiz	w9, w9, #12, #4
10034e2ec:     	orr	w10, w9, w10, lsl #6
10034e2f0:     	mov	w9, #0x3                ; =3
10034e2f4:     	b	0x10034e308 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x158>
10034e2f8:     	mov	w10, #0x0               ; =0
10034e2fc:     	cmp	w9, #0xe0
10034e300:     	b.hs	0x10034e2e0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x130>
10034e304:     	mov	w9, #0x2                ; =2
10034e308:     	adds	w11, w21, #0x1
10034e30c:     	csinv	w21, w11, wzr, lo
10034e310:     	lsr	w10, w10, #11
10034e314:     	cmp	w10, #0x1b
10034e318:     	cset	w10, eq
10034e31c:     	orr	w8, w8, w10
10034e320:     	b	0x10034e294 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xe4>
10034e324:     	adds	w9, w21, #0x2
10034e328:     	csinv	w21, w9, wzr, lo
10034e32c:     	mov	w9, #0x4                ; =4
10034e330:     	b	0x10034e294 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xe4>
10034e334:     	and	x8, x19, #0xffffffc0
10034e338:     	add	x8, x20, x8
10034e33c:     	mov	x9, x20
10034e340:     	ldp	q0, q1, [x9]
10034e344:     	ldp	q2, q3, [x9, #0x20]
10034e348:     	orr.16b	v0, v1, v0
10034e34c:     	orr.16b	v1, v2, v3
10034e350:     	orr.16b	v0, v0, v1
10034e354:     	umaxv.16b	b0, v0
10034e358:     	fmov	w10, s0
10034e35c:     	tbnz	w10, #0x7, 0x10034e274 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xc4>
10034e360:     	add	x9, x9, #0x40
10034e364:     	cmp	x9, x8
10034e368:     	b.ne	0x10034e340 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x190>
10034e36c:     	ands	x9, x19, #0x30
10034e370:     	b.eq	0x10034e394 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x1e4>
10034e374:     	mov	x10, x9
10034e378:     	mov	x11, x8
10034e37c:     	ldr	q0, [x11], #0x10
10034e380:     	umaxv.16b	b0, v0
10034e384:     	fmov	w12, s0
10034e388:     	tbnz	w12, #0x7, 0x10034e274 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xc4>
10034e38c:     	subs	x10, x10, #0x10
10034e390:     	b.ne	0x10034e37c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x1cc>
10034e394:     	and	x10, x19, #0xf
10034e398:     	cbz	x10, 0x10034e3b4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x204>
10034e39c:     	add	x8, x8, x9
10034e3a0:     	ldrsb	w9, [x8]
10034e3a4:     	tbnz	w9, #0x1f, 0x10034e274 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xc4>
10034e3a8:     	add	x8, x8, #0x1
10034e3ac:     	subs	x10, x10, #0x1
10034e3b0:     	b.ne	0x10034e3a0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x1f0>
10034e3b4:     	mov	w8, #0xffe8             ; =65512
10034e3b8:     	movk	w8, #0x1fff, lsl #16
10034e3bc:     	cmp	x19, x8
10034e3c0:     	b.hi	0x10034e48c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x2dc>
10034e3c4:     	mov	x0, x19
10034e3c8:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10034e3cc:     	stp	w19, w19, [x0]
10034e3d0:     	stp	wzr, wzr, [x0, #0xc]
10034e3d4:     	str	w19, [x0, #0x8]
10034e3d8:     	cbz	x19, 0x10034e3f4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x244>
10034e3dc:     	mov	x21, x0
10034e3e0:     	mov	x0, x1
10034e3e4:     	mov	x1, x20
10034e3e8:     	mov	x2, x19
10034e3ec:     	bl	0x100b66a2c <_writev+0x100b66a2c>
10034e3f0:     	mov	x0, x21
10034e3f4:     	ldp	x29, x30, [sp, #0x20]
10034e3f8:     	ldp	x20, x19, [sp, #0x10]
10034e3fc:     	ldp	x22, x21, [sp], #0x30
10034e400:     	ret
10034e404:     	mov	w9, #0xffe8             ; =65512
10034e408:     	movk	w9, #0x1fff, lsl #16
10034e40c:     	cmp	w21, w9
10034e410:     	b.hi	0x10034e48c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x2dc>
10034e414:     	tbz	w8, #0x0, 0x10034e43c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x28c>
10034e418:     	mov	x0, x19
10034e41c:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10034e420:     	stp	w21, w19, [x0]
10034e424:     	str	w19, [x0, #0x8]
10034e428:     	mov	x8, #0x100000000        ; =4294967296
10034e42c:     	mov	x21, x0
10034e430:     	stur	x8, [x0, #0xc]
10034e434:     	b	0x10034e458 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x2a8>
10034e438:     	mov	w21, #0x0               ; =0
10034e43c:     	mov	x0, x19
10034e440:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10034e444:     	stp	w21, w19, [x0]
10034e448:     	stp	wzr, wzr, [x0, #0xc]
10034e44c:     	str	w19, [x0, #0x8]
10034e450:     	cbz	x19, 0x10034e46c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x2bc>
10034e454:     	mov	x21, x0
10034e458:     	mov	x0, x1
10034e45c:     	mov	x1, x20
10034e460:     	mov	x2, x19
10034e464:     	bl	0x100b66a2c <_writev+0x100b66a2c>
10034e468:     	mov	x0, x21
10034e46c:     	ldp	x29, x30, [sp, #0x20]
10034e470:     	ldp	x20, x19, [sp, #0x10]
10034e474:     	ldp	x22, x21, [sp], #0x30
10034e478:     	b	0x1005f0138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6concat28canonicalize_surrogate_pairs>
10034e47c:     	adrp	x2, 0x100f0e000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json25PARSE_KEY_CACHE_OVERSIZED+0x3b0>
10034e480:     	add	x2, x2, #0xbf0
10034e484:     	mov	x1, x19
10034e488:     	bl	0x100b1740c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
10034e48c:     	bl	0x10034e14c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string27throw_invalid_string_length>
