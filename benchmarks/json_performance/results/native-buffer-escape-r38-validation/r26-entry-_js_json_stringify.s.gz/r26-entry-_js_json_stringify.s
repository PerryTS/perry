
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/native-buffer-escape-r38/main-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010084536c <_js_json_stringify>:
10084536c:     	sub	sp, sp, #0x80
100845370:     	stp	d9, d8, [sp, #0x20]
100845374:     	stp	x26, x25, [sp, #0x30]
100845378:     	stp	x24, x23, [sp, #0x40]
10084537c:     	stp	x22, x21, [sp, #0x50]
100845380:     	stp	x20, x19, [sp, #0x60]
100845384:     	stp	x29, x30, [sp, #0x70]
100845388:     	add	x29, sp, #0x70
10084538c:     	mov	x21, x0
100845390:     	mov.16b	v8, v0
100845394:     	fmov	x19, d8
100845398:     	and	x20, x19, #0xffff000000000000
10084539c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008453a0:     	cmp	x20, x8
1008453a4:     	b.ne	0x1008453cc <_js_json_stringify+0x60>
1008453a8:     	and	x0, x19, #0xffffffffffff
1008453ac:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
1008453b0:     	mov	x9, #0x7fffffffffff     ; =140737488355327
1008453b4:     	movk	x9, #0xffef, lsl #16
1008453b8:     	cmp	x8, x9
1008453bc:     	b.hi	0x1008453cc <_js_json_stringify+0x60>
1008453c0:     	ldr	w8, [x0, #0x4]
1008453c4:     	cmp	w8, #0x40
1008453c8:     	b.hs	0x10084543c <_js_json_stringify+0xd0>
1008453cc:     	mov.16b	v0, v8
1008453d0:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
1008453d4:     	tbz	w0, #0x0, 0x1008453e0 <_js_json_stringify+0x74>
1008453d8:     	mov	x23, x1
1008453dc:     	b	0x100845950 <_js_json_stringify+0x5e4>
1008453e0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008453e4:     	cmp	x20, x8
1008453e8:     	b.ne	0x100845450 <_js_json_stringify+0xe4>
1008453ec:     	ands	x19, x19, #0xffffffffffff
1008453f0:     	b.eq	0x100845450 <_js_json_stringify+0xe4>
1008453f4:     	mov	x0, x19
1008453f8:     	bl	0x10050f138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008453fc:     	cbz	w0, 0x100845450 <_js_json_stringify+0xe4>
100845400:     	ldurb	w8, [x19, #-0x8]
100845404:     	cmp	w8, #0x9
100845408:     	b.ne	0x100845450 <_js_json_stringify+0xe4>
10084540c:     	ldr	w8, [x19, #0x4]
100845410:     	mov	w9, #0x5841             ; =22593
100845414:     	movk	w9, #0x4c5a, lsl #16
100845418:     	cmp	w8, w9
10084541c:     	b.ne	0x100845450 <_js_json_stringify+0xe4>
100845420:     	mov	x0, x19
100845424:     	bl	0x100688364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100845428:     	cbz	x0, 0x100845450 <_js_json_stringify+0xe4>
10084542c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845430:     	bfxil	x8, x0, #0, #48
100845434:     	fmov	d8, x8
100845438:     	b	0x100845450 <_js_json_stringify+0xe4>
10084543c:     	bl	0x1004f2ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100845440:     	tbnz	w0, #0x0, 0x1008453d8 <_js_json_stringify+0x6c>
100845444:     	mov.16b	v0, v8
100845448:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084544c:     	tbnz	w0, #0x0, 0x1008453d8 <_js_json_stringify+0x6c>
100845450:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845454:     	add	x0, x0, #0xd78
100845458:     	ldr	x8, [x0]
10084545c:     	blr	x8
100845460:     	mov	x19, x0
100845464:     	ldr	w26, [x0]
100845468:     	add	w8, w26, #0x1
10084546c:     	str	w8, [x0]
100845470:     	cbz	w26, 0x1008454e0 <_js_json_stringify+0x174>
100845474:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845478:     	add	x0, x0, #0xd00
10084547c:     	ldr	x8, [x0]
100845480:     	blr	x8
100845484:     	ldrb	w8, [x0, #0x20]
100845488:     	cmp	w8, #0x1
10084548c:     	b.ne	0x100845a44 <_js_json_stringify+0x6d8>
100845490:     	ldr	x8, [x0]
100845494:     	cbnz	x8, 0x100845a50 <_js_json_stringify+0x6e4>
100845498:     	mov	x8, #-0x1               ; =-1
10084549c:     	str	x8, [x0]
1008454a0:     	ldr	x20, [x0, #0x18]
1008454a4:     	ldr	x8, [x0, #0x8]
1008454a8:     	cmp	x20, x8
1008454ac:     	b.eq	0x100845974 <_js_json_stringify+0x608>
1008454b0:     	ldr	x8, [x0, #0x10]
1008454b4:     	mov	w9, #0x18               ; =24
1008454b8:     	madd	x8, x20, x9, x8
1008454bc:     	mov	w9, #0x8                ; =8
1008454c0:     	stp	xzr, x9, [x8]
1008454c4:     	str	xzr, [x8, #0x10]
1008454c8:     	add	x8, x20, #0x1
1008454cc:     	str	x8, [x0, #0x18]
1008454d0:     	ldr	x8, [x0]
1008454d4:     	add	x8, x8, #0x1
1008454d8:     	str	x8, [x0]
1008454dc:     	b	0x10084556c <_js_json_stringify+0x200>
1008454e0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008454e4:     	add	x0, x0, #0xdc0
1008454e8:     	ldr	x8, [x0]
1008454ec:     	blr	x8
1008454f0:     	strb	wzr, [x0]
1008454f4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008454f8:     	add	x0, x0, #0xdf0
1008454fc:     	ldr	x8, [x0]
100845500:     	blr	x8
100845504:     	strb	wzr, [x0]
100845508:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
10084550c:     	ldr	w20, [x8, #0x5a8]
100845510:     	cmp	w20, #0x300
100845514:     	b.hs	0x1008459d0 <_js_json_stringify+0x664>
100845518:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
10084551c:     	ldr	x8, [x8, #0x48]
100845520:     	cmn	x8, #0x1
100845524:     	b.eq	0x1008459c0 <_js_json_stringify+0x654>
100845528:     	mrs	x9, TPIDRRO_EL0
10084552c:     	and	x9, x9, #0xfffffffffffffff8
100845530:     	ldr	x0, [x9, x8, lsl #3]
100845534:     	cbz	x0, 0x1008459c0 <_js_json_stringify+0x654>
100845538:     	add	x8, x0, x20, lsl #3
10084553c:     	ldr	x0, [x8, #0x1e8]
100845540:     	cbz	x0, 0x1008459d0 <_js_json_stringify+0x664>
100845544:     	str	xzr, [x0]
100845548:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084554c:     	add	x0, x0, #0xd90
100845550:     	ldr	x8, [x0]
100845554:     	blr	x8
100845558:     	ldrb	w8, [x0, #0x20]
10084555c:     	cbnz	w8, 0x100845a5c <_js_json_stringify+0x6f0>
100845560:     	ldr	x8, [x0]
100845564:     	cbnz	x8, 0x100845a84 <_js_json_stringify+0x718>
100845568:     	str	xzr, [x0, #0x18]
10084556c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845570:     	add	x0, x0, #0xd30
100845574:     	ldr	x8, [x0]
100845578:     	blr	x8
10084557c:     	mov	x20, x0
100845580:     	ldrb	w8, [x0, #0x18]
100845584:     	cmp	w8, #0x1
100845588:     	b.ne	0x1008459e0 <_js_json_stringify+0x674>
10084558c:     	ldr	x8, [x0]
100845590:     	mov	x9, #-0x1               ; =-1
100845594:     	str	x9, [x0]
100845598:     	cmn	x8, #0x2
10084559c:     	b.eq	0x100845a90 <_js_json_stringify+0x724>
1008455a0:     	cmn	x8, #0x1
1008455a4:     	b.eq	0x1008455b8 <_js_json_stringify+0x24c>
1008455a8:     	add	x9, sp, #0x8
1008455ac:     	ldur	q0, [x0, #0x8]
1008455b0:     	stur	q0, [x9, #0x8]
1008455b4:     	b	0x1008455c4 <_js_json_stringify+0x258>
1008455b8:     	mov	x8, #0x0                ; =0
1008455bc:     	mov	w9, #0x1                ; =1
1008455c0:     	stp	x9, xzr, [sp, #0x10]
1008455c4:     	str	x8, [sp, #0x8]
1008455c8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008455cc:     	add	x0, x0, #0xd18
1008455d0:     	ldr	x8, [x0]
1008455d4:     	blr	x8
1008455d8:     	ldrb	w8, [x0, #0x20]
1008455dc:     	cbnz	w8, 0x100845a10 <_js_json_stringify+0x6a4>
1008455e0:     	ldr	x8, [x0]
1008455e4:     	cbnz	x8, 0x100845a38 <_js_json_stringify+0x6cc>
1008455e8:     	str	xzr, [x0, #0x18]
1008455ec:     	add	x1, sp, #0x8
1008455f0:     	mov.16b	v0, v8
1008455f4:     	mov	x0, x21
1008455f8:     	bl	0x10050956c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
1008455fc:     	ldp	x21, x22, [sp, #0x10]
100845600:     	cmp	w22, #0x80, lsl #12     ; =0x80000
100845604:     	b.hs	0x1008456c4 <_js_json_stringify+0x358>
100845608:     	cmp	x22, #0x40
10084560c:     	b.hs	0x100845788 <_js_json_stringify+0x41c>
100845610:     	ands	x9, x22, #0x38
100845614:     	b.eq	0x100845638 <_js_json_stringify+0x2cc>
100845618:     	and	x8, x22, #0x38
10084561c:     	neg	x8, x8
100845620:     	mov	x10, x21
100845624:     	ldr	x11, [x10], #0x8
100845628:     	tst	x11, #0x8080808080808080
10084562c:     	b.ne	0x1008456ac <_js_json_stringify+0x340>
100845630:     	adds	x8, x8, #0x8
100845634:     	b.ne	0x100845624 <_js_json_stringify+0x2b8>
100845638:     	and	x8, x22, #0x7
10084563c:     	cbz	x8, 0x10084580c <_js_json_stringify+0x4a0>
100845640:     	add	x9, x21, x9
100845644:     	ldrsb	w10, [x9]
100845648:     	tbnz	w10, #0x1f, 0x1008456ac <_js_json_stringify+0x340>
10084564c:     	cmp	x8, #0x1
100845650:     	b.eq	0x10084580c <_js_json_stringify+0x4a0>
100845654:     	ldrsb	w10, [x9, #0x1]
100845658:     	tbnz	w10, #0x1f, 0x1008456ac <_js_json_stringify+0x340>
10084565c:     	cmp	x8, #0x2
100845660:     	b.eq	0x10084580c <_js_json_stringify+0x4a0>
100845664:     	ldrsb	w10, [x9, #0x2]
100845668:     	tbnz	w10, #0x1f, 0x1008456ac <_js_json_stringify+0x340>
10084566c:     	cmp	x8, #0x3
100845670:     	b.eq	0x10084580c <_js_json_stringify+0x4a0>
100845674:     	ldrsb	w10, [x9, #0x3]
100845678:     	tbnz	w10, #0x1f, 0x1008456ac <_js_json_stringify+0x340>
10084567c:     	cmp	x8, #0x4
100845680:     	b.eq	0x10084580c <_js_json_stringify+0x4a0>
100845684:     	ldrsb	w10, [x9, #0x4]
100845688:     	tbnz	w10, #0x1f, 0x1008456ac <_js_json_stringify+0x340>
10084568c:     	cmp	x8, #0x5
100845690:     	b.eq	0x10084580c <_js_json_stringify+0x4a0>
100845694:     	ldrsb	w10, [x9, #0x5]
100845698:     	tbnz	w10, #0x1f, 0x1008456ac <_js_json_stringify+0x340>
10084569c:     	cmp	x8, #0x6
1008456a0:     	b.eq	0x10084580c <_js_json_stringify+0x4a0>
1008456a4:     	ldrsb	w8, [x9, #0x6]
1008456a8:     	tbz	w8, #0x1f, 0x10084580c <_js_json_stringify+0x4a0>
1008456ac:     	mov	x0, x21
1008456b0:     	mov	x1, x22
1008456b4:     	mov	x2, x22
1008456b8:     	bl	0x1008dcd40 <_js_string_from_bytes_with_capacity>
1008456bc:     	mov	x23, x0
1008456c0:     	b	0x100845908 <_js_json_stringify+0x59c>
1008456c4:     	and	x8, x22, #0x7fffffffffffffc0
1008456c8:     	add	x8, x21, x8
1008456cc:     	mov	x9, x21
1008456d0:     	ldp	q0, q1, [x9]
1008456d4:     	ldp	q2, q3, [x9, #0x20]
1008456d8:     	orr.16b	v0, v1, v0
1008456dc:     	orr.16b	v1, v2, v3
1008456e0:     	orr.16b	v0, v0, v1
1008456e4:     	umaxv.16b	b0, v0
1008456e8:     	fmov	w10, s0
1008456ec:     	tbnz	w10, #0x7, 0x10084574c <_js_json_stringify+0x3e0>
1008456f0:     	add	x9, x9, #0x40
1008456f4:     	cmp	x9, x8
1008456f8:     	b.ne	0x1008456d0 <_js_json_stringify+0x364>
1008456fc:     	ands	x9, x22, #0x30
100845700:     	b.eq	0x100845724 <_js_json_stringify+0x3b8>
100845704:     	mov	x10, x9
100845708:     	mov	x11, x8
10084570c:     	ldr	q0, [x11], #0x10
100845710:     	umaxv.16b	b0, v0
100845714:     	fmov	w12, s0
100845718:     	tbnz	w12, #0x7, 0x10084574c <_js_json_stringify+0x3e0>
10084571c:     	subs	x10, x10, #0x10
100845720:     	b.ne	0x10084570c <_js_json_stringify+0x3a0>
100845724:     	and	x10, x22, #0xf
100845728:     	cbz	x10, 0x100845744 <_js_json_stringify+0x3d8>
10084572c:     	add	x8, x8, x9
100845730:     	ldrsb	w9, [x8]
100845734:     	tbnz	w9, #0x1f, 0x10084574c <_js_json_stringify+0x3e0>
100845738:     	add	x8, x8, #0x1
10084573c:     	subs	x10, x10, #0x1
100845740:     	b.ne	0x100845730 <_js_json_stringify+0x3c4>
100845744:     	mov	w24, w22
100845748:     	b	0x100845780 <_js_json_stringify+0x414>
10084574c:     	mov	w24, w22
100845750:     	cbz	x24, 0x100845780 <_js_json_stringify+0x414>
100845754:     	mov	x8, x21
100845758:     	ands	x9, x22, #0x3
10084575c:     	b.eq	0x100845778 <_js_json_stringify+0x40c>
100845760:     	mov	x8, x21
100845764:     	ldrsb	w10, [x8]
100845768:     	tbnz	w10, #0x1f, 0x100845870 <_js_json_stringify+0x504>
10084576c:     	add	x8, x8, #0x1
100845770:     	subs	x9, x9, #0x1
100845774:     	b.ne	0x100845764 <_js_json_stringify+0x3f8>
100845778:     	cmp	x24, #0x4
10084577c:     	b.hs	0x10084583c <_js_json_stringify+0x4d0>
100845780:     	mov	x25, x22
100845784:     	b	0x100845880 <_js_json_stringify+0x514>
100845788:     	and	x8, x22, #0x7fffffffffffffc0
10084578c:     	and	x8, x8, #0xffffffff0007ffff
100845790:     	add	x8, x21, x8
100845794:     	mov	x9, x21
100845798:     	ldp	q0, q1, [x9]
10084579c:     	ldp	q2, q3, [x9, #0x20]
1008457a0:     	orr.16b	v0, v1, v0
1008457a4:     	orr.16b	v1, v2, v3
1008457a8:     	orr.16b	v0, v0, v1
1008457ac:     	umaxv.16b	b0, v0
1008457b0:     	fmov	w10, s0
1008457b4:     	tbnz	w10, #0x7, 0x1008456ac <_js_json_stringify+0x340>
1008457b8:     	add	x9, x9, #0x40
1008457bc:     	cmp	x9, x8
1008457c0:     	b.ne	0x100845798 <_js_json_stringify+0x42c>
1008457c4:     	ands	x9, x22, #0x30
1008457c8:     	b.eq	0x1008457ec <_js_json_stringify+0x480>
1008457cc:     	mov	x10, x9
1008457d0:     	mov	x11, x8
1008457d4:     	ldr	q0, [x11], #0x10
1008457d8:     	umaxv.16b	b0, v0
1008457dc:     	fmov	w12, s0
1008457e0:     	tbnz	w12, #0x7, 0x1008456ac <_js_json_stringify+0x340>
1008457e4:     	subs	x10, x10, #0x10
1008457e8:     	b.ne	0x1008457d4 <_js_json_stringify+0x468>
1008457ec:     	and	x10, x22, #0xf
1008457f0:     	cbz	x10, 0x10084580c <_js_json_stringify+0x4a0>
1008457f4:     	add	x8, x8, x9
1008457f8:     	ldrsb	w9, [x8]
1008457fc:     	tbnz	w9, #0x1f, 0x1008456ac <_js_json_stringify+0x340>
100845800:     	add	x8, x8, #0x1
100845804:     	subs	x10, x10, #0x1
100845808:     	b.ne	0x1008457f8 <_js_json_stringify+0x48c>
10084580c:     	mov	x0, x22
100845810:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100845814:     	mov	x23, x0
100845818:     	stp	w22, w22, [x0]
10084581c:     	stp	wzr, wzr, [x0, #0xc]
100845820:     	str	w22, [x0, #0x8]
100845824:     	cbz	w22, 0x100845908 <_js_json_stringify+0x59c>
100845828:     	and	x2, x22, #0x7ffff
10084582c:     	mov	x0, x1
100845830:     	mov	x1, x21
100845834:     	bl	0x100b61dec <_writev+0x100b61dec>
100845838:     	b	0x100845908 <_js_json_stringify+0x59c>
10084583c:     	add	x9, x21, x24
100845840:     	ldrsb	w10, [x8]
100845844:     	tbnz	w10, #0x1f, 0x100845870 <_js_json_stringify+0x504>
100845848:     	ldrsb	w10, [x8, #0x1]
10084584c:     	tbnz	w10, #0x1f, 0x100845870 <_js_json_stringify+0x504>
100845850:     	ldrsb	w10, [x8, #0x2]
100845854:     	tbnz	w10, #0x1f, 0x100845870 <_js_json_stringify+0x504>
100845858:     	ldrsb	w10, [x8, #0x3]
10084585c:     	tbnz	w10, #0x1f, 0x100845870 <_js_json_stringify+0x504>
100845860:     	add	x8, x8, #0x4
100845864:     	cmp	x8, x9
100845868:     	b.ne	0x100845840 <_js_json_stringify+0x4d4>
10084586c:     	b	0x100845780 <_js_json_stringify+0x414>
100845870:     	mov	w1, w22
100845874:     	mov	x0, x21
100845878:     	bl	0x1005ea920 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
10084587c:     	mov	x25, x0
100845880:     	bl	0x1004eff00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100845884:     	add	x0, x24, #0x14
100845888:     	mov	w1, #0x3                ; =3
10084588c:     	bl	0x100458380 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
100845890:     	mov	x23, x0
100845894:     	stp	w25, w22, [x0]
100845898:     	stp	wzr, wzr, [x0, #0xc]
10084589c:     	str	w22, [x0, #0x8]
1008458a0:     	add	x0, x0, #0x14
1008458a4:     	mov	x1, x21
1008458a8:     	mov	x2, x24
1008458ac:     	bl	0x100b61dec <_writev+0x100b61dec>
1008458b0:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1008458b4:     	ldr	w21, [x8, #0x590]
1008458b8:     	cmp	w21, #0x300
1008458bc:     	b.hs	0x100845998 <_js_json_stringify+0x62c>
1008458c0:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1008458c4:     	ldr	x8, [x8, #0x48]
1008458c8:     	cmn	x8, #0x1
1008458cc:     	b.eq	0x100845988 <_js_json_stringify+0x61c>
1008458d0:     	mrs	x9, TPIDRRO_EL0
1008458d4:     	and	x9, x9, #0xfffffffffffffff8
1008458d8:     	ldr	x0, [x9, x8, lsl #3]
1008458dc:     	cbz	x0, 0x100845988 <_js_json_stringify+0x61c>
1008458e0:     	add	x8, x0, x21, lsl #3
1008458e4:     	ldr	x0, [x8, #0x1e8]
1008458e8:     	cbz	x0, 0x100845998 <_js_json_stringify+0x62c>
1008458ec:     	ldr	x8, [x0]
1008458f0:     	adds	x8, x8, x24
1008458f4:     	csinv	x8, x8, xzr, lo
1008458f8:     	str	x8, [x0]
1008458fc:     	lsr	x8, x8, #25
100845900:     	cbz	x8, 0x100845908 <_js_json_stringify+0x59c>
100845904:     	bl	0x10045f2b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100845908:     	ldp	x22, x21, [sp, #0x8]
10084590c:     	ldrb	w8, [x20, #0x18]
100845910:     	cmp	w8, #0x1
100845914:     	b.ne	0x1008459f0 <_js_json_stringify+0x684>
100845918:     	ldp	x8, x0, [x20]
10084591c:     	stp	x22, x21, [x20]
100845920:     	str	xzr, [x20, #0x10]
100845924:     	sub	x8, x8, #0x1
100845928:     	cmn	x8, #0x2
10084592c:     	b.hs	0x100845934 <_js_json_stringify+0x5c8>
100845930:     	bl	0x100b5ef40 <_mi_free>
100845934:     	cbz	w26, 0x100845940 <_js_json_stringify+0x5d4>
100845938:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084593c:     	b	0x100845944 <_js_json_stringify+0x5d8>
100845940:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100845944:     	ldr	w8, [x19]
100845948:     	sub	w8, w8, #0x1
10084594c:     	str	w8, [x19]
100845950:     	mov	x0, x23
100845954:     	ldp	x29, x30, [sp, #0x70]
100845958:     	ldp	x20, x19, [sp, #0x60]
10084595c:     	ldp	x22, x21, [sp, #0x50]
100845960:     	ldp	x24, x23, [sp, #0x40]
100845964:     	ldp	x26, x25, [sp, #0x30]
100845968:     	ldp	d9, d8, [sp, #0x20]
10084596c:     	add	sp, sp, #0x80
100845970:     	ret
100845974:     	mov	x22, x0
100845978:     	add	x0, x0, #0x8
10084597c:     	bl	0x100b3bcd0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100845980:     	mov	x0, x22
100845984:     	b	0x1008454b0 <_js_json_stringify+0x144>
100845988:     	bl	0x100b3f37c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084598c:     	add	x8, x0, x21, lsl #3
100845990:     	ldr	x0, [x8, #0x1e8]
100845994:     	cbnz	x0, 0x1008458ec <_js_json_stringify+0x580>
100845998:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084599c:     	add	x0, x0, #0x78
1008459a0:     	bl	0x100b3cb9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1008459a4:     	ldr	x8, [x0]
1008459a8:     	adds	x8, x8, x24
1008459ac:     	csinv	x8, x8, xzr, lo
1008459b0:     	str	x8, [x0]
1008459b4:     	lsr	x8, x8, #25
1008459b8:     	cbnz	x8, 0x100845904 <_js_json_stringify+0x598>
1008459bc:     	b	0x100845908 <_js_json_stringify+0x59c>
1008459c0:     	bl	0x100b3f37c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008459c4:     	add	x8, x0, x20, lsl #3
1008459c8:     	ldr	x0, [x8, #0x1e8]
1008459cc:     	cbnz	x0, 0x100845544 <_js_json_stringify+0x1d8>
1008459d0:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1008459d4:     	add	x0, x0, #0x138
1008459d8:     	bl	0x100b3cb9c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1008459dc:     	b	0x100845544 <_js_json_stringify+0x1d8>
1008459e0:     	mov	x0, x20
1008459e4:     	bl	0x100b1e504 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008459e8:     	cbnz	x0, 0x10084558c <_js_json_stringify+0x220>
1008459ec:     	b	0x100845a90 <_js_json_stringify+0x724>
1008459f0:     	mov	x0, x20
1008459f4:     	bl	0x100b1e504 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008459f8:     	mov	x20, x0
1008459fc:     	cbnz	x0, 0x100845918 <_js_json_stringify+0x5ac>
100845a00:     	cbz	x22, 0x100845a90 <_js_json_stringify+0x724>
100845a04:     	mov	x0, x21
100845a08:     	bl	0x100b5ef40 <_mi_free>
100845a0c:     	b	0x100845a90 <_js_json_stringify+0x724>
100845a10:     	cmp	w8, #0x2
100845a14:     	b.eq	0x100845a90 <_js_json_stringify+0x724>
100845a18:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100845a1c:     	add	x1, x1, #0xff8
100845a20:     	mov	x22, x0
100845a24:     	bl	0x100a203dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845a28:     	mov	x0, x22
100845a2c:     	strb	wzr, [x22, #0x20]
100845a30:     	ldr	x8, [x22]
100845a34:     	cbz	x8, 0x1008455e8 <_js_json_stringify+0x27c>
100845a38:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845a3c:     	add	x0, x0, #0xdb8
100845a40:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845a44:     	bl	0x100b1e664 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100845a48:     	cbnz	x0, 0x100845490 <_js_json_stringify+0x124>
100845a4c:     	b	0x100845a90 <_js_json_stringify+0x724>
100845a50:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100845a54:     	add	x0, x0, #0x440
100845a58:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845a5c:     	cmp	w8, #0x1
100845a60:     	b.ne	0x100845a90 <_js_json_stringify+0x724>
100845a64:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100845a68:     	add	x1, x1, #0x998
100845a6c:     	mov	x20, x0
100845a70:     	bl	0x100a203dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845a74:     	mov	x0, x20
100845a78:     	strb	wzr, [x20, #0x20]
100845a7c:     	ldr	x8, [x20]
100845a80:     	cbz	x8, 0x100845568 <_js_json_stringify+0x1fc>
100845a84:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845a88:     	add	x0, x0, #0xd88
100845a8c:     	bl	0x100b126ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845a90:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100845a94:     	add	x0, x0, #0xc18
100845a98:     	bl	0x100b5859c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
