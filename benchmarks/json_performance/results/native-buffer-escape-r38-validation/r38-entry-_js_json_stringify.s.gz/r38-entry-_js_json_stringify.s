
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/native-buffer-escape-r38/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008499ac <_js_json_stringify>:
1008499ac:     	sub	sp, sp, #0x80
1008499b0:     	stp	d9, d8, [sp, #0x20]
1008499b4:     	stp	x26, x25, [sp, #0x30]
1008499b8:     	stp	x24, x23, [sp, #0x40]
1008499bc:     	stp	x22, x21, [sp, #0x50]
1008499c0:     	stp	x20, x19, [sp, #0x60]
1008499c4:     	stp	x29, x30, [sp, #0x70]
1008499c8:     	add	x29, sp, #0x70
1008499cc:     	mov	x21, x0
1008499d0:     	mov.16b	v8, v0
1008499d4:     	fmov	x19, d8
1008499d8:     	and	x20, x19, #0xffff000000000000
1008499dc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008499e0:     	cmp	x20, x8
1008499e4:     	b.ne	0x100849a0c <_js_json_stringify+0x60>
1008499e8:     	and	x0, x19, #0xffffffffffff
1008499ec:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
1008499f0:     	mov	x9, #0x7fffffffffff     ; =140737488355327
1008499f4:     	movk	x9, #0xffef, lsl #16
1008499f8:     	cmp	x8, x9
1008499fc:     	b.hi	0x100849a0c <_js_json_stringify+0x60>
100849a00:     	ldr	w8, [x0, #0x4]
100849a04:     	cmp	w8, #0x40
100849a08:     	b.hs	0x100849a7c <_js_json_stringify+0xd0>
100849a0c:     	mov.16b	v0, v8
100849a10:     	bl	0x1004f09fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100849a14:     	tbz	w0, #0x0, 0x100849a20 <_js_json_stringify+0x74>
100849a18:     	mov	x23, x1
100849a1c:     	b	0x100849f90 <_js_json_stringify+0x5e4>
100849a20:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100849a24:     	cmp	x20, x8
100849a28:     	b.ne	0x100849a90 <_js_json_stringify+0xe4>
100849a2c:     	ands	x19, x19, #0xffffffffffff
100849a30:     	b.eq	0x100849a90 <_js_json_stringify+0xe4>
100849a34:     	mov	x0, x19
100849a38:     	bl	0x1005120b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100849a3c:     	cbz	w0, 0x100849a90 <_js_json_stringify+0xe4>
100849a40:     	ldurb	w8, [x19, #-0x8]
100849a44:     	cmp	w8, #0x9
100849a48:     	b.ne	0x100849a90 <_js_json_stringify+0xe4>
100849a4c:     	ldr	w8, [x19, #0x4]
100849a50:     	mov	w9, #0x5841             ; =22593
100849a54:     	movk	w9, #0x4c5a, lsl #16
100849a58:     	cmp	w8, w9
100849a5c:     	b.ne	0x100849a90 <_js_json_stringify+0xe4>
100849a60:     	mov	x0, x19
100849a64:     	bl	0x10068bd24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100849a68:     	cbz	x0, 0x100849a90 <_js_json_stringify+0xe4>
100849a6c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100849a70:     	bfxil	x8, x0, #0, #48
100849a74:     	fmov	d8, x8
100849a78:     	b	0x100849a90 <_js_json_stringify+0xe4>
100849a7c:     	bl	0x1004f5928 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100849a80:     	tbnz	w0, #0x0, 0x100849a18 <_js_json_stringify+0x6c>
100849a84:     	mov.16b	v0, v8
100849a88:     	bl	0x1004f09fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100849a8c:     	tbnz	w0, #0x0, 0x100849a18 <_js_json_stringify+0x6c>
100849a90:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849a94:     	add	x0, x0, #0xd78
100849a98:     	ldr	x8, [x0]
100849a9c:     	blr	x8
100849aa0:     	mov	x19, x0
100849aa4:     	ldr	w26, [x0]
100849aa8:     	add	w8, w26, #0x1
100849aac:     	str	w8, [x0]
100849ab0:     	cbz	w26, 0x100849b20 <_js_json_stringify+0x174>
100849ab4:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849ab8:     	add	x0, x0, #0xd00
100849abc:     	ldr	x8, [x0]
100849ac0:     	blr	x8
100849ac4:     	ldrb	w8, [x0, #0x20]
100849ac8:     	cmp	w8, #0x1
100849acc:     	b.ne	0x10084a084 <_js_json_stringify+0x6d8>
100849ad0:     	ldr	x8, [x0]
100849ad4:     	cbnz	x8, 0x10084a090 <_js_json_stringify+0x6e4>
100849ad8:     	mov	x8, #-0x1               ; =-1
100849adc:     	str	x8, [x0]
100849ae0:     	ldr	x20, [x0, #0x18]
100849ae4:     	ldr	x8, [x0, #0x8]
100849ae8:     	cmp	x20, x8
100849aec:     	b.eq	0x100849fb4 <_js_json_stringify+0x608>
100849af0:     	ldr	x8, [x0, #0x10]
100849af4:     	mov	w9, #0x18               ; =24
100849af8:     	madd	x8, x20, x9, x8
100849afc:     	mov	w9, #0x8                ; =8
100849b00:     	stp	xzr, x9, [x8]
100849b04:     	str	xzr, [x8, #0x10]
100849b08:     	add	x8, x20, #0x1
100849b0c:     	str	x8, [x0, #0x18]
100849b10:     	ldr	x8, [x0]
100849b14:     	add	x8, x8, #0x1
100849b18:     	str	x8, [x0]
100849b1c:     	b	0x100849bac <_js_json_stringify+0x200>
100849b20:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849b24:     	add	x0, x0, #0xdc0
100849b28:     	ldr	x8, [x0]
100849b2c:     	blr	x8
100849b30:     	strb	wzr, [x0]
100849b34:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849b38:     	add	x0, x0, #0xdf0
100849b3c:     	ldr	x8, [x0]
100849b40:     	blr	x8
100849b44:     	strb	wzr, [x0]
100849b48:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
100849b4c:     	ldr	w20, [x8, #0x5a8]
100849b50:     	cmp	w20, #0x300
100849b54:     	b.hs	0x10084a010 <_js_json_stringify+0x664>
100849b58:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
100849b5c:     	ldr	x8, [x8, #0x48]
100849b60:     	cmn	x8, #0x1
100849b64:     	b.eq	0x10084a000 <_js_json_stringify+0x654>
100849b68:     	mrs	x9, TPIDRRO_EL0
100849b6c:     	and	x9, x9, #0xfffffffffffffff8
100849b70:     	ldr	x0, [x9, x8, lsl #3]
100849b74:     	cbz	x0, 0x10084a000 <_js_json_stringify+0x654>
100849b78:     	add	x8, x0, x20, lsl #3
100849b7c:     	ldr	x0, [x8, #0x1e8]
100849b80:     	cbz	x0, 0x10084a010 <_js_json_stringify+0x664>
100849b84:     	str	xzr, [x0]
100849b88:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849b8c:     	add	x0, x0, #0xd90
100849b90:     	ldr	x8, [x0]
100849b94:     	blr	x8
100849b98:     	ldrb	w8, [x0, #0x20]
100849b9c:     	cbnz	w8, 0x10084a09c <_js_json_stringify+0x6f0>
100849ba0:     	ldr	x8, [x0]
100849ba4:     	cbnz	x8, 0x10084a0c4 <_js_json_stringify+0x718>
100849ba8:     	str	xzr, [x0, #0x18]
100849bac:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849bb0:     	add	x0, x0, #0xd30
100849bb4:     	ldr	x8, [x0]
100849bb8:     	blr	x8
100849bbc:     	mov	x20, x0
100849bc0:     	ldrb	w8, [x0, #0x18]
100849bc4:     	cmp	w8, #0x1
100849bc8:     	b.ne	0x10084a020 <_js_json_stringify+0x674>
100849bcc:     	ldr	x8, [x0]
100849bd0:     	mov	x9, #-0x1               ; =-1
100849bd4:     	str	x9, [x0]
100849bd8:     	cmn	x8, #0x2
100849bdc:     	b.eq	0x10084a0d0 <_js_json_stringify+0x724>
100849be0:     	cmn	x8, #0x1
100849be4:     	b.eq	0x100849bf8 <_js_json_stringify+0x24c>
100849be8:     	add	x9, sp, #0x8
100849bec:     	ldur	q0, [x0, #0x8]
100849bf0:     	stur	q0, [x9, #0x8]
100849bf4:     	b	0x100849c04 <_js_json_stringify+0x258>
100849bf8:     	mov	x8, #0x0                ; =0
100849bfc:     	mov	w9, #0x1                ; =1
100849c00:     	stp	x9, xzr, [sp, #0x10]
100849c04:     	str	x8, [sp, #0x8]
100849c08:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849c0c:     	add	x0, x0, #0xd18
100849c10:     	ldr	x8, [x0]
100849c14:     	blr	x8
100849c18:     	ldrb	w8, [x0, #0x20]
100849c1c:     	cbnz	w8, 0x10084a050 <_js_json_stringify+0x6a4>
100849c20:     	ldr	x8, [x0]
100849c24:     	cbnz	x8, 0x10084a078 <_js_json_stringify+0x6cc>
100849c28:     	str	xzr, [x0, #0x18]
100849c2c:     	add	x1, sp, #0x8
100849c30:     	mov.16b	v0, v8
100849c34:     	mov	x0, x21
100849c38:     	bl	0x10050c504 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100849c3c:     	ldp	x21, x22, [sp, #0x10]
100849c40:     	cmp	w22, #0x80, lsl #12     ; =0x80000
100849c44:     	b.hs	0x100849d04 <_js_json_stringify+0x358>
100849c48:     	cmp	x22, #0x40
100849c4c:     	b.hs	0x100849dc8 <_js_json_stringify+0x41c>
100849c50:     	ands	x9, x22, #0x38
100849c54:     	b.eq	0x100849c78 <_js_json_stringify+0x2cc>
100849c58:     	and	x8, x22, #0x38
100849c5c:     	neg	x8, x8
100849c60:     	mov	x10, x21
100849c64:     	ldr	x11, [x10], #0x8
100849c68:     	tst	x11, #0x8080808080808080
100849c6c:     	b.ne	0x100849cec <_js_json_stringify+0x340>
100849c70:     	adds	x8, x8, #0x8
100849c74:     	b.ne	0x100849c64 <_js_json_stringify+0x2b8>
100849c78:     	and	x8, x22, #0x7
100849c7c:     	cbz	x8, 0x100849e4c <_js_json_stringify+0x4a0>
100849c80:     	add	x9, x21, x9
100849c84:     	ldrsb	w10, [x9]
100849c88:     	tbnz	w10, #0x1f, 0x100849cec <_js_json_stringify+0x340>
100849c8c:     	cmp	x8, #0x1
100849c90:     	b.eq	0x100849e4c <_js_json_stringify+0x4a0>
100849c94:     	ldrsb	w10, [x9, #0x1]
100849c98:     	tbnz	w10, #0x1f, 0x100849cec <_js_json_stringify+0x340>
100849c9c:     	cmp	x8, #0x2
100849ca0:     	b.eq	0x100849e4c <_js_json_stringify+0x4a0>
100849ca4:     	ldrsb	w10, [x9, #0x2]
100849ca8:     	tbnz	w10, #0x1f, 0x100849cec <_js_json_stringify+0x340>
100849cac:     	cmp	x8, #0x3
100849cb0:     	b.eq	0x100849e4c <_js_json_stringify+0x4a0>
100849cb4:     	ldrsb	w10, [x9, #0x3]
100849cb8:     	tbnz	w10, #0x1f, 0x100849cec <_js_json_stringify+0x340>
100849cbc:     	cmp	x8, #0x4
100849cc0:     	b.eq	0x100849e4c <_js_json_stringify+0x4a0>
100849cc4:     	ldrsb	w10, [x9, #0x4]
100849cc8:     	tbnz	w10, #0x1f, 0x100849cec <_js_json_stringify+0x340>
100849ccc:     	cmp	x8, #0x5
100849cd0:     	b.eq	0x100849e4c <_js_json_stringify+0x4a0>
100849cd4:     	ldrsb	w10, [x9, #0x5]
100849cd8:     	tbnz	w10, #0x1f, 0x100849cec <_js_json_stringify+0x340>
100849cdc:     	cmp	x8, #0x6
100849ce0:     	b.eq	0x100849e4c <_js_json_stringify+0x4a0>
100849ce4:     	ldrsb	w8, [x9, #0x6]
100849ce8:     	tbz	w8, #0x1f, 0x100849e4c <_js_json_stringify+0x4a0>
100849cec:     	mov	x0, x21
100849cf0:     	mov	x1, x22
100849cf4:     	mov	x2, x22
100849cf8:     	bl	0x1008e1380 <_js_string_from_bytes_with_capacity>
100849cfc:     	mov	x23, x0
100849d00:     	b	0x100849f48 <_js_json_stringify+0x59c>
100849d04:     	and	x8, x22, #0x7fffffffffffffc0
100849d08:     	add	x8, x21, x8
100849d0c:     	mov	x9, x21
100849d10:     	ldp	q0, q1, [x9]
100849d14:     	ldp	q2, q3, [x9, #0x20]
100849d18:     	orr.16b	v0, v1, v0
100849d1c:     	orr.16b	v1, v2, v3
100849d20:     	orr.16b	v0, v0, v1
100849d24:     	umaxv.16b	b0, v0
100849d28:     	fmov	w10, s0
100849d2c:     	tbnz	w10, #0x7, 0x100849d8c <_js_json_stringify+0x3e0>
100849d30:     	add	x9, x9, #0x40
100849d34:     	cmp	x9, x8
100849d38:     	b.ne	0x100849d10 <_js_json_stringify+0x364>
100849d3c:     	ands	x9, x22, #0x30
100849d40:     	b.eq	0x100849d64 <_js_json_stringify+0x3b8>
100849d44:     	mov	x10, x9
100849d48:     	mov	x11, x8
100849d4c:     	ldr	q0, [x11], #0x10
100849d50:     	umaxv.16b	b0, v0
100849d54:     	fmov	w12, s0
100849d58:     	tbnz	w12, #0x7, 0x100849d8c <_js_json_stringify+0x3e0>
100849d5c:     	subs	x10, x10, #0x10
100849d60:     	b.ne	0x100849d4c <_js_json_stringify+0x3a0>
100849d64:     	and	x10, x22, #0xf
100849d68:     	cbz	x10, 0x100849d84 <_js_json_stringify+0x3d8>
100849d6c:     	add	x8, x8, x9
100849d70:     	ldrsb	w9, [x8]
100849d74:     	tbnz	w9, #0x1f, 0x100849d8c <_js_json_stringify+0x3e0>
100849d78:     	add	x8, x8, #0x1
100849d7c:     	subs	x10, x10, #0x1
100849d80:     	b.ne	0x100849d70 <_js_json_stringify+0x3c4>
100849d84:     	mov	w24, w22
100849d88:     	b	0x100849dc0 <_js_json_stringify+0x414>
100849d8c:     	mov	w24, w22
100849d90:     	cbz	x24, 0x100849dc0 <_js_json_stringify+0x414>
100849d94:     	mov	x8, x21
100849d98:     	ands	x9, x22, #0x3
100849d9c:     	b.eq	0x100849db8 <_js_json_stringify+0x40c>
100849da0:     	mov	x8, x21
100849da4:     	ldrsb	w10, [x8]
100849da8:     	tbnz	w10, #0x1f, 0x100849eb0 <_js_json_stringify+0x504>
100849dac:     	add	x8, x8, #0x1
100849db0:     	subs	x9, x9, #0x1
100849db4:     	b.ne	0x100849da4 <_js_json_stringify+0x3f8>
100849db8:     	cmp	x24, #0x4
100849dbc:     	b.hs	0x100849e7c <_js_json_stringify+0x4d0>
100849dc0:     	mov	x25, x22
100849dc4:     	b	0x100849ec0 <_js_json_stringify+0x514>
100849dc8:     	and	x8, x22, #0x7fffffffffffffc0
100849dcc:     	and	x8, x8, #0xffffffff0007ffff
100849dd0:     	add	x8, x21, x8
100849dd4:     	mov	x9, x21
100849dd8:     	ldp	q0, q1, [x9]
100849ddc:     	ldp	q2, q3, [x9, #0x20]
100849de0:     	orr.16b	v0, v1, v0
100849de4:     	orr.16b	v1, v2, v3
100849de8:     	orr.16b	v0, v0, v1
100849dec:     	umaxv.16b	b0, v0
100849df0:     	fmov	w10, s0
100849df4:     	tbnz	w10, #0x7, 0x100849cec <_js_json_stringify+0x340>
100849df8:     	add	x9, x9, #0x40
100849dfc:     	cmp	x9, x8
100849e00:     	b.ne	0x100849dd8 <_js_json_stringify+0x42c>
100849e04:     	ands	x9, x22, #0x30
100849e08:     	b.eq	0x100849e2c <_js_json_stringify+0x480>
100849e0c:     	mov	x10, x9
100849e10:     	mov	x11, x8
100849e14:     	ldr	q0, [x11], #0x10
100849e18:     	umaxv.16b	b0, v0
100849e1c:     	fmov	w12, s0
100849e20:     	tbnz	w12, #0x7, 0x100849cec <_js_json_stringify+0x340>
100849e24:     	subs	x10, x10, #0x10
100849e28:     	b.ne	0x100849e14 <_js_json_stringify+0x468>
100849e2c:     	and	x10, x22, #0xf
100849e30:     	cbz	x10, 0x100849e4c <_js_json_stringify+0x4a0>
100849e34:     	add	x8, x8, x9
100849e38:     	ldrsb	w9, [x8]
100849e3c:     	tbnz	w9, #0x1f, 0x100849cec <_js_json_stringify+0x340>
100849e40:     	add	x8, x8, #0x1
100849e44:     	subs	x10, x10, #0x1
100849e48:     	b.ne	0x100849e38 <_js_json_stringify+0x48c>
100849e4c:     	mov	x0, x22
100849e50:     	bl	0x10034db6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100849e54:     	mov	x23, x0
100849e58:     	stp	w22, w22, [x0]
100849e5c:     	stp	wzr, wzr, [x0, #0xc]
100849e60:     	str	w22, [x0, #0x8]
100849e64:     	cbz	w22, 0x100849f48 <_js_json_stringify+0x59c>
100849e68:     	and	x2, x22, #0x7ffff
100849e6c:     	mov	x0, x1
100849e70:     	mov	x1, x21
100849e74:     	bl	0x100b66a2c <_writev+0x100b66a2c>
100849e78:     	b	0x100849f48 <_js_json_stringify+0x59c>
100849e7c:     	add	x9, x21, x24
100849e80:     	ldrsb	w10, [x8]
100849e84:     	tbnz	w10, #0x1f, 0x100849eb0 <_js_json_stringify+0x504>
100849e88:     	ldrsb	w10, [x8, #0x1]
100849e8c:     	tbnz	w10, #0x1f, 0x100849eb0 <_js_json_stringify+0x504>
100849e90:     	ldrsb	w10, [x8, #0x2]
100849e94:     	tbnz	w10, #0x1f, 0x100849eb0 <_js_json_stringify+0x504>
100849e98:     	ldrsb	w10, [x8, #0x3]
100849e9c:     	tbnz	w10, #0x1f, 0x100849eb0 <_js_json_stringify+0x504>
100849ea0:     	add	x8, x8, #0x4
100849ea4:     	cmp	x8, x9
100849ea8:     	b.ne	0x100849e80 <_js_json_stringify+0x4d4>
100849eac:     	b	0x100849dc0 <_js_json_stringify+0x414>
100849eb0:     	mov	w1, w22
100849eb4:     	mov	x0, x21
100849eb8:     	bl	0x1005ed8a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
100849ebc:     	mov	x25, x0
100849ec0:     	bl	0x1004f2b80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100849ec4:     	add	x0, x24, #0x14
100849ec8:     	mov	w1, #0x3                ; =3
100849ecc:     	bl	0x10045ae40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
100849ed0:     	mov	x23, x0
100849ed4:     	stp	w25, w22, [x0]
100849ed8:     	stp	wzr, wzr, [x0, #0xc]
100849edc:     	str	w22, [x0, #0x8]
100849ee0:     	add	x0, x0, #0x14
100849ee4:     	mov	x1, x21
100849ee8:     	mov	x2, x24
100849eec:     	bl	0x100b66a2c <_writev+0x100b66a2c>
100849ef0:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
100849ef4:     	ldr	w21, [x8, #0x590]
100849ef8:     	cmp	w21, #0x300
100849efc:     	b.hs	0x100849fd8 <_js_json_stringify+0x62c>
100849f00:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
100849f04:     	ldr	x8, [x8, #0x48]
100849f08:     	cmn	x8, #0x1
100849f0c:     	b.eq	0x100849fc8 <_js_json_stringify+0x61c>
100849f10:     	mrs	x9, TPIDRRO_EL0
100849f14:     	and	x9, x9, #0xfffffffffffffff8
100849f18:     	ldr	x0, [x9, x8, lsl #3]
100849f1c:     	cbz	x0, 0x100849fc8 <_js_json_stringify+0x61c>
100849f20:     	add	x8, x0, x21, lsl #3
100849f24:     	ldr	x0, [x8, #0x1e8]
100849f28:     	cbz	x0, 0x100849fd8 <_js_json_stringify+0x62c>
100849f2c:     	ldr	x8, [x0]
100849f30:     	adds	x8, x8, x24
100849f34:     	csinv	x8, x8, xzr, lo
100849f38:     	str	x8, [x0]
100849f3c:     	lsr	x8, x8, #25
100849f40:     	cbz	x8, 0x100849f48 <_js_json_stringify+0x59c>
100849f44:     	bl	0x100461d74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100849f48:     	ldp	x22, x21, [sp, #0x8]
100849f4c:     	ldrb	w8, [x20, #0x18]
100849f50:     	cmp	w8, #0x1
100849f54:     	b.ne	0x10084a030 <_js_json_stringify+0x684>
100849f58:     	ldp	x8, x0, [x20]
100849f5c:     	stp	x22, x21, [x20]
100849f60:     	str	xzr, [x20, #0x10]
100849f64:     	sub	x8, x8, #0x1
100849f68:     	cmn	x8, #0x2
100849f6c:     	b.hs	0x100849f74 <_js_json_stringify+0x5c8>
100849f70:     	bl	0x100b63b80 <_mi_free>
100849f74:     	cbz	w26, 0x100849f80 <_js_json_stringify+0x5d4>
100849f78:     	bl	0x10032aaa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100849f7c:     	b	0x100849f84 <_js_json_stringify+0x5d8>
100849f80:     	bl	0x10032a8d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100849f84:     	ldr	w8, [x19]
100849f88:     	sub	w8, w8, #0x1
100849f8c:     	str	w8, [x19]
100849f90:     	mov	x0, x23
100849f94:     	ldp	x29, x30, [sp, #0x70]
100849f98:     	ldp	x20, x19, [sp, #0x60]
100849f9c:     	ldp	x22, x21, [sp, #0x50]
100849fa0:     	ldp	x24, x23, [sp, #0x40]
100849fa4:     	ldp	x26, x25, [sp, #0x30]
100849fa8:     	ldp	d9, d8, [sp, #0x20]
100849fac:     	add	sp, sp, #0x80
100849fb0:     	ret
100849fb4:     	mov	x22, x0
100849fb8:     	add	x0, x0, #0x8
100849fbc:     	bl	0x100b408d0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100849fc0:     	mov	x0, x22
100849fc4:     	b	0x100849af0 <_js_json_stringify+0x144>
100849fc8:     	bl	0x100b43f7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100849fcc:     	add	x8, x0, x21, lsl #3
100849fd0:     	ldr	x0, [x8, #0x1e8]
100849fd4:     	cbnz	x0, 0x100849f2c <_js_json_stringify+0x580>
100849fd8:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100849fdc:     	add	x0, x0, #0x78
100849fe0:     	bl	0x100b4179c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100849fe4:     	ldr	x8, [x0]
100849fe8:     	adds	x8, x8, x24
100849fec:     	csinv	x8, x8, xzr, lo
100849ff0:     	str	x8, [x0]
100849ff4:     	lsr	x8, x8, #25
100849ff8:     	cbnz	x8, 0x100849f44 <_js_json_stringify+0x598>
100849ffc:     	b	0x100849f48 <_js_json_stringify+0x59c>
10084a000:     	bl	0x100b43f7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084a004:     	add	x8, x0, x20, lsl #3
10084a008:     	ldr	x0, [x8, #0x1e8]
10084a00c:     	cbnz	x0, 0x100849b84 <_js_json_stringify+0x1d8>
10084a010:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084a014:     	add	x0, x0, #0x138
10084a018:     	bl	0x100b4179c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084a01c:     	b	0x100849b84 <_js_json_stringify+0x1d8>
10084a020:     	mov	x0, x20
10084a024:     	bl	0x100b23104 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084a028:     	cbnz	x0, 0x100849bcc <_js_json_stringify+0x220>
10084a02c:     	b	0x10084a0d0 <_js_json_stringify+0x724>
10084a030:     	mov	x0, x20
10084a034:     	bl	0x100b23104 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084a038:     	mov	x20, x0
10084a03c:     	cbnz	x0, 0x100849f58 <_js_json_stringify+0x5ac>
10084a040:     	cbz	x22, 0x10084a0d0 <_js_json_stringify+0x724>
10084a044:     	mov	x0, x21
10084a048:     	bl	0x100b63b80 <_mi_free>
10084a04c:     	b	0x10084a0d0 <_js_json_stringify+0x724>
10084a050:     	cmp	w8, #0x2
10084a054:     	b.eq	0x10084a0d0 <_js_json_stringify+0x724>
10084a058:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084a05c:     	add	x1, x1, #0xef8
10084a060:     	mov	x22, x0
10084a064:     	bl	0x100a24fdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084a068:     	mov	x0, x22
10084a06c:     	strb	wzr, [x22, #0x20]
10084a070:     	ldr	x8, [x22]
10084a074:     	cbz	x8, 0x100849c28 <_js_json_stringify+0x27c>
10084a078:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084a07c:     	add	x0, x0, #0xdb8
10084a080:     	bl	0x100b172ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a084:     	bl	0x100b23264 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084a088:     	cbnz	x0, 0x100849ad0 <_js_json_stringify+0x124>
10084a08c:     	b	0x10084a0d0 <_js_json_stringify+0x724>
10084a090:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10084a094:     	add	x0, x0, #0x440
10084a098:     	bl	0x100b172ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a09c:     	cmp	w8, #0x1
10084a0a0:     	b.ne	0x10084a0d0 <_js_json_stringify+0x724>
10084a0a4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084a0a8:     	add	x1, x1, #0x898
10084a0ac:     	mov	x20, x0
10084a0b0:     	bl	0x100a24fdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084a0b4:     	mov	x0, x20
10084a0b8:     	strb	wzr, [x20, #0x20]
10084a0bc:     	ldr	x8, [x20]
10084a0c0:     	cbz	x8, 0x100849ba8 <_js_json_stringify+0x1fc>
10084a0c4:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084a0c8:     	add	x0, x0, #0xd88
10084a0cc:     	bl	0x100b172ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084a0d0:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084a0d4:     	add	x0, x0, #0xc18
10084a0d8:     	bl	0x100b5d1dc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
