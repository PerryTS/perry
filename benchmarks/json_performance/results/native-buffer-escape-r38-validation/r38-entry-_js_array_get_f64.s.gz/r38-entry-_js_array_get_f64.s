
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/native-buffer-escape-r38/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007c2510 <_js_array_get_f64>:
1007c2510:     	sub	sp, sp, #0x70
1007c2514:     	stp	x26, x25, [sp, #0x20]
1007c2518:     	stp	x24, x23, [sp, #0x30]
1007c251c:     	stp	x22, x21, [sp, #0x40]
1007c2520:     	stp	x20, x19, [sp, #0x50]
1007c2524:     	stp	x29, x30, [sp, #0x60]
1007c2528:     	add	x29, sp, #0x60
1007c252c:     	mov	x19, x1
1007c2530:     	mov	x22, x0
1007c2534:     	lsr	x25, x0, #51
1007c2538:     	mov	x20, x0
1007c253c:     	cmp	x25, #0xfff
1007c2540:     	b.lo	0x1007c255c <_js_array_get_f64+0x4c>
1007c2544:     	mov	w8, #0x7ffc             ; =32764
1007c2548:     	cmp	x8, x22, lsr #48
1007c254c:     	b.ne	0x1007c2558 <_js_array_get_f64+0x48>
1007c2550:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007c2554:     	b	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c2558:     	and	x20, x22, #0xffffffffffff
1007c255c:     	lsr	x8, x20, #3
1007c2560:     	cmp	x8, #0x200
1007c2564:     	b.ls	0x1007c259c <_js_array_get_f64+0x8c>
1007c2568:     	ldurb	w8, [x20, #-0x8]
1007c256c:     	cmp	w8, #0x9
1007c2570:     	b.ne	0x1007c259c <_js_array_get_f64+0x8c>
1007c2574:     	ldr	w8, [x20, #0x4]
1007c2578:     	mov	w9, #0x5841             ; =22593
1007c257c:     	movk	w9, #0x4c5a, lsl #16
1007c2580:     	cmp	w8, w9
1007c2584:     	b.ne	0x1007c259c <_js_array_get_f64+0x8c>
1007c2588:     	mov	x0, x20
1007c258c:     	mov	x1, x19
1007c2590:     	bl	0x10068b8c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007c2594:     	fmov	d0, x0
1007c2598:     	b	0x1007c2c0c <_js_array_get_f64+0x6fc>
1007c259c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c25a0:     	b.lo	0x1007c2650 <_js_array_get_f64+0x140>
1007c25a4:     	tst	x20, #0xffff800000000000
1007c25a8:     	mov	w8, #0x1000             ; =4096
1007c25ac:     	ccmp	x20, x8, #0x0, eq
1007c25b0:     	b.lo	0x1007c2650 <_js_array_get_f64+0x140>
1007c25b4:     	ldurb	w24, [x20, #-0x8]
1007c25b8:     	ldurh	w23, [x20, #-0x6]
1007c25bc:     	cmp	w24, #0xa
1007c25c0:     	b.gt	0x1007c2768 <_js_array_get_f64+0x258>
1007c25c4:     	cmp	w24, #0x2
1007c25c8:     	b.eq	0x1007c27f0 <_js_array_get_f64+0x2e0>
1007c25cc:     	cmp	w24, #0x8
1007c25d0:     	b.ne	0x1007c2658 <_js_array_get_f64+0x148>
1007c25d4:     	mov	x0, x20
1007c25d8:     	bl	0x100307b68 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007c25dc:     	cbz	w0, 0x1007c2880 <_js_array_get_f64+0x370>
1007c25e0:     	mov	x22, #0x1               ; =1
1007c25e4:     	movk	x22, #0x7ffc, lsl #48
1007c25e8:     	lsr	x8, x20, #51
1007c25ec:     	cmp	x8, #0xfff
1007c25f0:     	b.lo	0x1007c2604 <_js_array_get_f64+0xf4>
1007c25f4:     	mov	w8, #0x7ffc             ; =32764
1007c25f8:     	cmp	x8, x20, lsr #48
1007c25fc:     	b.eq	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c2600:     	and	x20, x20, #0xffffffffffff
1007c2604:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c2608:     	b.lo	0x1007c2628 <_js_array_get_f64+0x118>
1007c260c:     	tst	x20, #0xffff800000000000
1007c2610:     	mov	w8, #0x1000             ; =4096
1007c2614:     	ccmp	x20, x8, #0x0, eq
1007c2618:     	b.lo	0x1007c2628 <_js_array_get_f64+0x118>
1007c261c:     	ldurb	w8, [x20, #-0x8]
1007c2620:     	cmp	w8, #0x2
1007c2624:     	b.eq	0x1007c2ef4 <_js_array_get_f64+0x9e4>
1007c2628:     	cbz	x20, 0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c262c:     	mov	x0, x20
1007c2630:     	mov	x1, x19
1007c2634:     	bl	0x100307d18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007c2638:     	cmp	w0, #0x1
1007c263c:     	b.ne	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c2640:     	ldr	x8, [x20, #0x8]
1007c2644:     	ubfiz	x9, x1, #4, #32
1007c2648:     	ldr	x22, [x8, x9]
1007c264c:     	b	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c2650:     	mov	w23, #0x0               ; =0
1007c2654:     	mov	w24, #0x0               ; =0
1007c2658:     	mov	x21, x22
1007c265c:     	cmp	x25, #0xfff
1007c2660:     	b.lo	0x1007c2678 <_js_array_get_f64+0x168>
1007c2664:     	mov	w8, #0x7ffc             ; =32764
1007c2668:     	cmp	x8, x22, lsr #48
1007c266c:     	b.eq	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2670:     	ands	x21, x22, #0xffffffffffff
1007c2674:     	b.eq	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2678:     	and	x8, x21, #0xfffffffffff00000
1007c267c:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007c2680:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007c2684:     	cmp	x9, x10
1007c2688:     	ccmp	x8, #0x0, #0x4, lo
1007c268c:     	b.eq	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2690:     	tst	x21, #0x3
1007c2694:     	ccmp	x21, #0x7, #0x0, eq
1007c2698:     	b.ls	0x1007c2948 <_js_array_get_f64+0x438>
1007c269c:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c26a0:     	ldr	x8, [x8, #0x48]
1007c26a4:     	cmn	x8, #0x1
1007c26a8:     	b.eq	0x1007c2898 <_js_array_get_f64+0x388>
1007c26ac:     	mrs	x9, TPIDRRO_EL0
1007c26b0:     	and	x9, x9, #0xfffffffffffffff8
1007c26b4:     	ldr	x0, [x9, x8, lsl #3]
1007c26b8:     	cbz	x0, 0x1007c2898 <_js_array_get_f64+0x388>
1007c26bc:     	lsr	x1, x21, #20
1007c26c0:     	ldr	x8, [x0, #0x10]
1007c26c4:     	ldrb	w9, [x8]
1007c26c8:     	cmp	w9, #0x2
1007c26cc:     	b.ne	0x1007c28b0 <_js_array_get_f64+0x3a0>
1007c26d0:     	ldrb	w9, [x8, #0x88]
1007c26d4:     	tbz	w9, #0x0, 0x1007c26f4 <_js_array_get_f64+0x1e4>
1007c26d8:     	ldr	x9, [x8, #0x80]
1007c26dc:     	cmp	x9, x1
1007c26e0:     	b.ne	0x1007c26f4 <_js_array_get_f64+0x1e4>
1007c26e4:     	ldp	x9, x10, [x8, #0x60]
1007c26e8:     	cmp	x9, x21
1007c26ec:     	ccmp	x10, x21, #0x0, ls
1007c26f0:     	b.hi	0x1007c2890 <_js_array_get_f64+0x380>
1007c26f4:     	ldrb	w9, [x8, #0xb8]
1007c26f8:     	cbz	w9, 0x1007c2718 <_js_array_get_f64+0x208>
1007c26fc:     	ldr	x9, [x8, #0xb0]
1007c2700:     	cmp	x9, x1
1007c2704:     	b.ne	0x1007c2718 <_js_array_get_f64+0x208>
1007c2708:     	ldp	x9, x10, [x8, #0x90]
1007c270c:     	cmp	x9, x21
1007c2710:     	ccmp	x10, x21, #0x0, ls
1007c2714:     	b.hi	0x1007c2d58 <_js_array_get_f64+0x848>
1007c2718:     	ldrb	w9, [x8, #0xe8]
1007c271c:     	cbz	w9, 0x1007c273c <_js_array_get_f64+0x22c>
1007c2720:     	ldr	x9, [x8, #0xe0]
1007c2724:     	cmp	x9, x1
1007c2728:     	b.ne	0x1007c273c <_js_array_get_f64+0x22c>
1007c272c:     	ldp	x9, x10, [x8, #0xc0]
1007c2730:     	cmp	x9, x21
1007c2734:     	ccmp	x10, x21, #0x0, ls
1007c2738:     	b.hi	0x1007c2e40 <_js_array_get_f64+0x930>
1007c273c:     	ldrb	w9, [x8, #0x118]
1007c2740:     	cbz	w9, 0x1007c2910 <_js_array_get_f64+0x400>
1007c2744:     	ldr	x9, [x8, #0x110]
1007c2748:     	cmp	x9, x1
1007c274c:     	b.ne	0x1007c2910 <_js_array_get_f64+0x400>
1007c2750:     	ldp	x9, x10, [x8, #0xf0]
1007c2754:     	cmp	x9, x21
1007c2758:     	ccmp	x10, x21, #0x0, ls
1007c275c:     	b.ls	0x1007c2910 <_js_array_get_f64+0x400>
1007c2760:     	add	x9, x8, #0xf0
1007c2764:     	b	0x1007c2e44 <_js_array_get_f64+0x934>
1007c2768:     	cmp	w24, #0xb
1007c276c:     	b.eq	0x1007c2808 <_js_array_get_f64+0x2f8>
1007c2770:     	cmp	w24, #0xc
1007c2774:     	b.ne	0x1007c2658 <_js_array_get_f64+0x148>
1007c2778:     	mov	x0, x20
1007c277c:     	bl	0x10030d8f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007c2780:     	cbz	w0, 0x1007c2888 <_js_array_get_f64+0x378>
1007c2784:     	mov	x22, #0x1               ; =1
1007c2788:     	movk	x22, #0x7ffc, lsl #48
1007c278c:     	lsr	x8, x20, #51
1007c2790:     	cmp	x8, #0xfff
1007c2794:     	b.lo	0x1007c27a8 <_js_array_get_f64+0x298>
1007c2798:     	mov	w8, #0x7ffc             ; =32764
1007c279c:     	cmp	x8, x20, lsr #48
1007c27a0:     	b.eq	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c27a4:     	and	x20, x20, #0xffffffffffff
1007c27a8:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c27ac:     	b.lo	0x1007c27cc <_js_array_get_f64+0x2bc>
1007c27b0:     	tst	x20, #0xffff800000000000
1007c27b4:     	mov	w8, #0x1000             ; =4096
1007c27b8:     	ccmp	x20, x8, #0x0, eq
1007c27bc:     	b.lo	0x1007c27cc <_js_array_get_f64+0x2bc>
1007c27c0:     	ldurb	w8, [x20, #-0x8]
1007c27c4:     	cmp	w8, #0x2
1007c27c8:     	b.eq	0x1007c2f0c <_js_array_get_f64+0x9fc>
1007c27cc:     	cbz	x20, 0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c27d0:     	mov	x0, x20
1007c27d4:     	mov	x1, x19
1007c27d8:     	bl	0x10030f570 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007c27dc:     	cmp	w0, #0x1
1007c27e0:     	b.ne	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c27e4:     	ldr	x8, [x20, #0x8]
1007c27e8:     	ldr	x22, [x8, w1, uxtw #3]
1007c27ec:     	b	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c27f0:     	mov	x0, x22
1007c27f4:     	mov	x1, x19
1007c27f8:     	bl	0x10054b58c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007c27fc:     	tbnz	w0, #0x0, 0x1007c2c04 <_js_array_get_f64+0x6f4>
1007c2800:     	mov	w24, #0x2               ; =2
1007c2804:     	b	0x1007c2658 <_js_array_get_f64+0x148>
1007c2808:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c280c:     	add	x8, x8, #0xec0
1007c2810:     	ldaprb	w8, [x8]
1007c2814:     	cbz	w8, 0x1007c2878 <_js_array_get_f64+0x368>
1007c2818:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c281c:     	add	x8, x8, #0x58
1007c2820:     	ldapr	x8, [x8]
1007c2824:     	cmp	x20, x8
1007c2828:     	b.lo	0x1007c2878 <_js_array_get_f64+0x368>
1007c282c:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2830:     	add	x8, x8, #0x60
1007c2834:     	ldapr	x8, [x8]
1007c2838:     	cmp	x20, x8
1007c283c:     	b.hi	0x1007c2878 <_js_array_get_f64+0x368>
1007c2840:     	mov	x0, x20
1007c2844:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2848:     	tbz	w0, #0x0, 0x1007c2878 <_js_array_get_f64+0x368>
1007c284c:     	add	x0, sp, #0x8
1007c2850:     	mov	x1, x20
1007c2854:     	bl	0x1002a746c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007c2858:     	ldr	x8, [sp, #0x8]
1007c285c:     	cbz	x8, 0x1007c2e84 <_js_array_get_f64+0x974>
1007c2860:     	cmp	x8, #0x1
1007c2864:     	b.ne	0x1007c2ec8 <_js_array_get_f64+0x9b8>
1007c2868:     	ldr	d0, [sp, #0x10]
1007c286c:     	scvtf	d1, w19
1007c2870:     	bl	0x100820ab4 <_js_dyn_index_get>
1007c2874:     	b	0x1007c2c04 <_js_array_get_f64+0x6f4>
1007c2878:     	mov	w24, #0xb               ; =11
1007c287c:     	b	0x1007c2658 <_js_array_get_f64+0x148>
1007c2880:     	mov	w24, #0x8               ; =8
1007c2884:     	b	0x1007c2658 <_js_array_get_f64+0x148>
1007c2888:     	mov	w24, #0xc               ; =12
1007c288c:     	b	0x1007c2658 <_js_array_get_f64+0x148>
1007c2890:     	add	x9, x8, #0x60
1007c2894:     	b	0x1007c2e44 <_js_array_get_f64+0x934>
1007c2898:     	bl	0x100b43f7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007c289c:     	lsr	x1, x21, #20
1007c28a0:     	ldr	x8, [x0, #0x10]
1007c28a4:     	ldrb	w9, [x8]
1007c28a8:     	cmp	w9, #0x2
1007c28ac:     	b.eq	0x1007c26d0 <_js_array_get_f64+0x1c0>
1007c28b0:     	ldr	x9, [x8, #0x8]
1007c28b4:     	ldr	x10, [x8, #0x28]
1007c28b8:     	sub	x9, x1, x9
1007c28bc:     	cmp	x9, x10
1007c28c0:     	b.hs	0x1007c2904 <_js_array_get_f64+0x3f4>
1007c28c4:     	ldr	x10, [x8, #0x20]
1007c28c8:     	mov	w11, #0x28              ; =40
1007c28cc:     	madd	x9, x9, x11, x10
1007c28d0:     	ldr	x10, [x9]
1007c28d4:     	ldr	x11, [x8, #0x10]
1007c28d8:     	cmp	x10, x11
1007c28dc:     	b.ne	0x1007c2910 <_js_array_get_f64+0x400>
1007c28e0:     	ldp	x10, x11, [x9, #0x8]
1007c28e4:     	cmp	x10, x21
1007c28e8:     	ccmp	x11, x21, #0x0, ls
1007c28ec:     	b.ls	0x1007c2910 <_js_array_get_f64+0x400>
1007c28f0:     	ldr	x10, [x8, #0x30]
1007c28f4:     	add	x10, x10, #0x1
1007c28f8:     	str	x10, [x8, #0x30]
1007c28fc:     	add	x8, x9, #0x21
1007c2900:     	b	0x1007c2e54 <_js_array_get_f64+0x944>
1007c2904:     	ldr	x9, [x8, #0x58]
1007c2908:     	add	x9, x9, #0x1
1007c290c:     	str	x9, [x8, #0x58]
1007c2910:     	ldr	x9, [x8, #0x38]
1007c2914:     	add	x9, x9, #0x1
1007c2918:     	str	x9, [x8, #0x38]
1007c291c:     	mov	x0, x21
1007c2920:     	bl	0x1005212c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007c2924:     	and	w8, w0, #0xff
1007c2928:     	cbz	w8, 0x1007c2948 <_js_array_get_f64+0x438>
1007c292c:     	ldurb	w8, [x21, #-0x8]
1007c2930:     	ldurb	w9, [x21, #-0x7]
1007c2934:     	mov	w10, #0x82              ; =130
1007c2938:     	and	w9, w9, w10
1007c293c:     	cmp	w9, #0x2
1007c2940:     	ccmp	w8, #0x1, #0x0, eq
1007c2944:     	b.eq	0x1007c2a18 <_js_array_get_f64+0x508>
1007c2948:     	mov	x0, x21
1007c294c:     	bl	0x10057d940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2950:     	cbz	x0, 0x1007c2978 <_js_array_get_f64+0x468>
1007c2954:     	ldrb	w9, [x0]
1007c2958:     	cmp	w9, #0x1
1007c295c:     	b.ne	0x1007c2994 <_js_array_get_f64+0x484>
1007c2960:     	ldrsb	w8, [x0, #0x1]
1007c2964:     	tbnz	w8, #0x1f, 0x1007c2a40 <_js_array_get_f64+0x530>
1007c2968:     	ldp	w10, w9, [x21]
1007c296c:     	cmp	w10, w9
1007c2970:     	b.hi	0x1007c2acc <_js_array_get_f64+0x5bc>
1007c2974:     	b	0x1007c2ae4 <_js_array_get_f64+0x5d4>
1007c2978:     	mov	x25, x0
1007c297c:     	mov	x0, x21
1007c2980:     	bl	0x10058c174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2984:     	tbz	w0, #0x0, 0x1007c29d0 <_js_array_get_f64+0x4c0>
1007c2988:     	mov	x0, #0x0                ; =0
1007c298c:     	mov	x8, x25
1007c2990:     	b	0x1007c2abc <_js_array_get_f64+0x5ac>
1007c2994:     	mov	x8, x0
1007c2998:     	cmp	w9, #0x1
1007c299c:     	b.eq	0x1007c2abc <_js_array_get_f64+0x5ac>
1007c29a0:     	cmp	w9, #0x9
1007c29a4:     	b.ne	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c29a8:     	ldr	w8, [x21, #0x4]
1007c29ac:     	mov	w9, #0x5841             ; =22593
1007c29b0:     	movk	w9, #0x4c5a, lsl #16
1007c29b4:     	cmp	w8, w9
1007c29b8:     	b.ne	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c29bc:     	mov	x0, x21
1007c29c0:     	bl	0x100378910 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007c29c4:     	cbz	x0, 0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c29c8:     	mov	x21, x0
1007c29cc:     	b	0x1007c2b00 <_js_array_get_f64+0x5f0>
1007c29d0:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c29d4:     	add	x8, x8, #0xec0
1007c29d8:     	ldaprb	w8, [x8]
1007c29dc:     	cbz	w8, 0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c29e0:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c29e4:     	add	x8, x8, #0x58
1007c29e8:     	ldapr	x8, [x8]
1007c29ec:     	cmp	x8, x21
1007c29f0:     	b.hi	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c29f4:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c29f8:     	add	x8, x8, #0x60
1007c29fc:     	ldapr	x8, [x8]
1007c2a00:     	cmp	x8, x21
1007c2a04:     	b.lo	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2a08:     	mov	x0, x21
1007c2a0c:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2a10:     	tbnz	w0, #0x0, 0x1007c2988 <_js_array_get_f64+0x478>
1007c2a14:     	b	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2a18:     	ldr	w8, [x21]
1007c2a1c:     	mov	w9, #0xe100             ; =57600
1007c2a20:     	movk	w9, #0x5f5, lsl #16
1007c2a24:     	orr	w9, w9, #0x1
1007c2a28:     	cmp	w8, w9
1007c2a2c:     	b.hs	0x1007c2948 <_js_array_get_f64+0x438>
1007c2a30:     	ldr	w9, [x21, #0x4]
1007c2a34:     	cmp	w8, w9
1007c2a38:     	b.ls	0x1007c2b00 <_js_array_get_f64+0x5f0>
1007c2a3c:     	b	0x1007c2948 <_js_array_get_f64+0x438>
1007c2a40:     	mov	x25, x0
1007c2a44:     	ldr	x21, [x0, #0x8]
1007c2a48:     	mov	x0, x21
1007c2a4c:     	bl	0x10057d940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2a50:     	cbz	x0, 0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2a54:     	ldrb	w8, [x0]
1007c2a58:     	cmp	w8, #0x1
1007c2a5c:     	b.ne	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2a60:     	ldrsb	w8, [x0, #0x1]
1007c2a64:     	tbz	w8, #0x1f, 0x1007c2968 <_js_array_get_f64+0x458>
1007c2a68:     	mov	w26, #0x1               ; =1
1007c2a6c:     	ldr	x21, [x0, #0x8]
1007c2a70:     	mov	x0, x21
1007c2a74:     	bl	0x10057d940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c2a78:     	cbz	x0, 0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2a7c:     	ldrb	w8, [x0]
1007c2a80:     	cmp	w8, #0x1
1007c2a84:     	b.ne	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2a88:     	cmp	w26, #0x3f
1007c2a8c:     	b.hi	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2a90:     	add	w26, w26, #0x1
1007c2a94:     	ldrsb	w8, [x0, #0x1]
1007c2a98:     	tbnz	w8, #0x1f, 0x1007c2a6c <_js_array_get_f64+0x55c>
1007c2a9c:     	str	x21, [x25, #0x8]
1007c2aa0:     	ldrb	w8, [x25, #0x1]
1007c2aa4:     	orr	w9, w8, #0x80
1007c2aa8:     	mov	x8, x25
1007c2aac:     	strb	w9, [x25, #0x1]
1007c2ab0:     	ldrb	w9, [x0]
1007c2ab4:     	cmp	w9, #0x1
1007c2ab8:     	b.ne	0x1007c29a0 <_js_array_get_f64+0x490>
1007c2abc:     	ldp	w10, w9, [x21]
1007c2ac0:     	cmp	w10, w9
1007c2ac4:     	b.ls	0x1007c2ae4 <_js_array_get_f64+0x5d4>
1007c2ac8:     	cbz	x8, 0x1007c2af4 <_js_array_get_f64+0x5e4>
1007c2acc:     	ldr	w8, [x0, #0x4]
1007c2ad0:     	ubfiz	x9, x9, #3, #32
1007c2ad4:     	add	x9, x9, #0x10
1007c2ad8:     	cmp	x9, x8
1007c2adc:     	b.eq	0x1007c2b00 <_js_array_get_f64+0x5f0>
1007c2ae0:     	b	0x1007c2af4 <_js_array_get_f64+0x5e4>
1007c2ae4:     	mov	w8, #0xe100             ; =57600
1007c2ae8:     	movk	w8, #0x5f5, lsl #16
1007c2aec:     	cmp	w10, w8
1007c2af0:     	b.ls	0x1007c2b00 <_js_array_get_f64+0x5f0>
1007c2af4:     	mov	x0, x21
1007c2af8:     	bl	0x10058c174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2afc:     	tbz	w0, #0x0, 0x1007c2bb0 <_js_array_get_f64+0x6a0>
1007c2b00:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2b04:     	add	x8, x8, #0xec0
1007c2b08:     	ldaprb	w8, [x8]
1007c2b0c:     	cbz	w8, 0x1007c2b54 <_js_array_get_f64+0x644>
1007c2b10:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2b14:     	add	x8, x8, #0x58
1007c2b18:     	ldapr	x8, [x8]
1007c2b1c:     	cmp	x21, x8
1007c2b20:     	b.lo	0x1007c2b54 <_js_array_get_f64+0x644>
1007c2b24:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2b28:     	add	x8, x8, #0x60
1007c2b2c:     	ldapr	x8, [x8]
1007c2b30:     	cmp	x21, x8
1007c2b34:     	b.hi	0x1007c2b54 <_js_array_get_f64+0x644>
1007c2b38:     	mov	x0, x21
1007c2b3c:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2b40:     	tbz	w0, #0x0, 0x1007c2b54 <_js_array_get_f64+0x644>
1007c2b44:     	mov	x0, x21
1007c2b48:     	mov	x1, x19
1007c2b4c:     	bl	0x1009007c8 <_js_typed_array_get>
1007c2b50:     	b	0x1007c2c04 <_js_array_get_f64+0x6f4>
1007c2b54:     	mov	x0, x21
1007c2b58:     	bl	0x10058c174 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2b5c:     	tbz	w0, #0x0, 0x1007c2b84 <_js_array_get_f64+0x674>
1007c2b60:     	mov	x0, x21
1007c2b64:     	mov	x1, x19
1007c2b68:     	bl	0x10058949c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007c2b6c:     	and	w8, w1, #0xff
1007c2b70:     	ucvtf	d0, w8
1007c2b74:     	fmov	x8, d0
1007c2b78:     	tst	w0, #0x1
1007c2b7c:     	csel	x22, x8, xzr, ne
1007c2b80:     	b	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c2b84:     	cmp	x21, x20
1007c2b88:     	b.eq	0x1007c2c30 <_js_array_get_f64+0x720>
1007c2b8c:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007c2b90:     	b.lo	0x1007c2c28 <_js_array_get_f64+0x718>
1007c2b94:     	tst	x21, #0xffff800000000000
1007c2b98:     	mov	w8, #0x1000             ; =4096
1007c2b9c:     	ccmp	x21, x8, #0x0, eq
1007c2ba0:     	b.lo	0x1007c2c28 <_js_array_get_f64+0x718>
1007c2ba4:     	ldurb	w24, [x21, #-0x8]
1007c2ba8:     	ldurh	w23, [x21, #-0x6]
1007c2bac:     	b	0x1007c2c30 <_js_array_get_f64+0x720>
1007c2bb0:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2bb4:     	add	x8, x8, #0xec0
1007c2bb8:     	ldaprb	w8, [x8]
1007c2bbc:     	cbz	w8, 0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2bc0:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2bc4:     	add	x8, x8, #0x58
1007c2bc8:     	ldapr	x8, [x8]
1007c2bcc:     	cmp	x21, x8
1007c2bd0:     	b.lo	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2bd4:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2bd8:     	add	x8, x8, #0x60
1007c2bdc:     	ldapr	x8, [x8]
1007c2be0:     	cmp	x21, x8
1007c2be4:     	b.hi	0x1007c2bf4 <_js_array_get_f64+0x6e4>
1007c2be8:     	mov	x0, x21
1007c2bec:     	bl	0x1002a7638 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2bf0:     	tbnz	w0, #0x0, 0x1007c2b00 <_js_array_get_f64+0x5f0>
1007c2bf4:     	mov	x0, x22
1007c2bf8:     	mov	x1, x19
1007c2bfc:     	bl	0x10054b58c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007c2c00:     	tbz	w0, #0x0, 0x1007c2ed8 <_js_array_get_f64+0x9c8>
1007c2c04:     	fmov	x22, d0
1007c2c08:     	fmov	d0, x22
1007c2c0c:     	ldp	x29, x30, [sp, #0x60]
1007c2c10:     	ldp	x20, x19, [sp, #0x50]
1007c2c14:     	ldp	x22, x21, [sp, #0x40]
1007c2c18:     	ldp	x24, x23, [sp, #0x30]
1007c2c1c:     	ldp	x26, x25, [sp, #0x20]
1007c2c20:     	add	sp, sp, #0x70
1007c2c24:     	ret
1007c2c28:     	mov	w23, #0x0               ; =0
1007c2c2c:     	mov	w24, #0x0               ; =0
1007c2c30:     	cmp	w24, #0x1
1007c2c34:     	b.ne	0x1007c2de8 <_js_array_get_f64+0x8d8>
1007c2c38:     	tbz	w23, #0xa, 0x1007c2de8 <_js_array_get_f64+0x8d8>
1007c2c3c:     	adrp	x8, 0x100b69000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data15grapheme_extend7OFFSETS+0x2e5>
1007c2c40:     	add	x8, x8, #0x9cc
1007c2c44:     	cmp	w19, #0x3e8
1007c2c48:     	b.lo	0x1007c2cc0 <_js_array_get_f64+0x7b0>
1007c2c4c:     	mov	x9, #0x0                ; =0
1007c2c50:     	mov	w11, #0x1759            ; =5977
1007c2c54:     	movk	w11, #0xd1b7, lsl #16
1007c2c58:     	mov	w12, #0x2710            ; =10000
1007c2c5c:     	mov	w13, #0x147b            ; =5243
1007c2c60:     	mov	w14, #0x64              ; =100
1007c2c64:     	add	x15, sp, #0x8
1007c2c68:     	mov	w16, #0x967f            ; =38527
1007c2c6c:     	movk	w16, #0x98, lsl #16
1007c2c70:     	mov	x10, x19
1007c2c74:     	mov	x17, x10
1007c2c78:     	umull	x10, w10, w11
1007c2c7c:     	lsr	x10, x10, #45
1007c2c80:     	msub	w0, w10, w12, w17
1007c2c84:     	ubfx	w1, w0, #2, #14
1007c2c88:     	mul	w1, w1, w13
1007c2c8c:     	lsr	w1, w1, #17
1007c2c90:     	msub	w0, w1, w14, w0
1007c2c94:     	add	x2, x15, x9
1007c2c98:     	ldrh	w1, [x8, w1, uxtw #1]
1007c2c9c:     	strh	w1, [x2, #0x6]
1007c2ca0:     	and	x0, x0, #0xffff
1007c2ca4:     	ldrh	w0, [x8, x0, lsl #1]
1007c2ca8:     	strh	w0, [x2, #0x8]
1007c2cac:     	sub	x9, x9, #0x4
1007c2cb0:     	cmp	w17, w16
1007c2cb4:     	b.hi	0x1007c2c74 <_js_array_get_f64+0x764>
1007c2cb8:     	add	x9, x9, #0xa
1007c2cbc:     	b	0x1007c2cc8 <_js_array_get_f64+0x7b8>
1007c2cc0:     	mov	w9, #0xa                ; =10
1007c2cc4:     	mov	x10, x19
1007c2cc8:     	cmp	w10, #0x9
1007c2ccc:     	b.ls	0x1007c2d00 <_js_array_get_f64+0x7f0>
1007c2cd0:     	sub	x9, x9, #0x2
1007c2cd4:     	ubfx	w11, w10, #2, #14
1007c2cd8:     	mov	w12, #0x147b            ; =5243
1007c2cdc:     	mul	w11, w11, w12
1007c2ce0:     	lsr	w11, w11, #17
1007c2ce4:     	mov	w12, #0x64              ; =100
1007c2ce8:     	msub	w10, w11, w12, w10
1007c2cec:     	and	x10, x10, #0xffff
1007c2cf0:     	ldrh	w10, [x8, x10, lsl #1]
1007c2cf4:     	add	x12, sp, #0x8
1007c2cf8:     	strh	w10, [x12, x9]
1007c2cfc:     	mov	x10, x11
1007c2d00:     	cbz	w19, 0x1007c2d38 <_js_array_get_f64+0x828>
1007c2d04:     	cbnz	w10, 0x1007c2d38 <_js_array_get_f64+0x828>
1007c2d08:     	cmp	x9, #0xa
1007c2d0c:     	b.ne	0x1007c2d60 <_js_array_get_f64+0x850>
1007c2d10:     	mov	w23, #0x1               ; =1
1007c2d14:     	add	x0, sp, #0x8
1007c2d18:     	mov	x1, x21
1007c2d1c:     	mov	w2, #0x1                ; =1
1007c2d20:     	mov	x3, #0x0                ; =0
1007c2d24:     	bl	0x1005b587c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007c2d28:     	ldr	x8, [sp, #0x8]
1007c2d2c:     	mov	w20, #0x1               ; =1
1007c2d30:     	cbnz	x8, 0x1007c2db0 <_js_array_get_f64+0x8a0>
1007c2d34:     	b	0x1007c2de8 <_js_array_get_f64+0x8d8>
1007c2d38:     	sub	x23, x9, #0x1
1007c2d3c:     	ubfiz	w10, w10, #1, #4
1007c2d40:     	add	x8, x8, x10
1007c2d44:     	ldrb	w8, [x8, #0x1]
1007c2d48:     	add	x10, sp, #0x8
1007c2d4c:     	strb	w8, [x10, x23]
1007c2d50:     	mov	w8, #0xb                ; =11
1007c2d54:     	b	0x1007c2d68 <_js_array_get_f64+0x858>
1007c2d58:     	add	x9, x8, #0x90
1007c2d5c:     	b	0x1007c2e44 <_js_array_get_f64+0x934>
1007c2d60:     	mov	w8, #0xa                ; =10
1007c2d64:     	mov	x23, x9
1007c2d68:     	sub	x22, x8, x9
1007c2d6c:     	mov	x0, x22
1007c2d70:     	mov	w1, #0x1                ; =1
1007c2d74:     	bl	0x100b63e08 <_mi_malloc_aligned>
1007c2d78:     	cbz	x0, 0x1007c2f24 <_js_array_get_f64+0xa14>
1007c2d7c:     	mov	x20, x0
1007c2d80:     	add	x8, sp, #0x8
1007c2d84:     	add	x1, x8, x23
1007c2d88:     	mov	x2, x22
1007c2d8c:     	bl	0x100b66a2c <_writev+0x100b66a2c>
1007c2d90:     	add	x0, sp, #0x8
1007c2d94:     	mov	x1, x21
1007c2d98:     	mov	x2, x20
1007c2d9c:     	mov	x3, x22
1007c2da0:     	bl	0x1005b587c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007c2da4:     	ldr	w8, [sp, #0x8]
1007c2da8:     	tbz	w8, #0x0, 0x1007c2de0 <_js_array_get_f64+0x8d0>
1007c2dac:     	mov	w23, #0x0               ; =0
1007c2db0:     	mov	x22, #0x1               ; =1
1007c2db4:     	movk	x22, #0x7ffc, lsl #48
1007c2db8:     	ldr	x0, [sp, #0x10]
1007c2dbc:     	cbz	x0, 0x1007c2e74 <_js_array_get_f64+0x964>
1007c2dc0:     	cbz	x21, 0x1007c2e64 <_js_array_get_f64+0x954>
1007c2dc4:     	lsr	x8, x21, #52
1007c2dc8:     	cmp	x8, #0x7fe
1007c2dcc:     	b.hi	0x1007c2e68 <_js_array_get_f64+0x958>
1007c2dd0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007c2dd4:     	bfxil	x8, x21, #0, #48
1007c2dd8:     	mov	x21, x8
1007c2ddc:     	b	0x1007c2e68 <_js_array_get_f64+0x958>
1007c2de0:     	mov	x0, x20
1007c2de4:     	bl	0x100b63b80 <_mi_free>
1007c2de8:     	ldr	w8, [x21]
1007c2dec:     	cmp	w19, w8
1007c2df0:     	b.hs	0x1007c2e30 <_js_array_get_f64+0x920>
1007c2df4:     	ldr	w8, [x21, #0x4]
1007c2df8:     	cmp	w19, w8
1007c2dfc:     	b.hs	0x1007c2e20 <_js_array_get_f64+0x910>
1007c2e00:     	add	x8, x21, w19, uxtw #3
1007c2e04:     	ldr	x22, [x8, #0x8]
1007c2e08:     	mov	x8, #0x1                ; =1
1007c2e0c:     	movk	x8, #0x7ffc, lsl #48
1007c2e10:     	add	x8, x8, #0xf
1007c2e14:     	cmp	x22, x8
1007c2e18:     	b.ne	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c2e1c:     	b	0x1007c2e30 <_js_array_get_f64+0x920>
1007c2e20:     	mov	x0, x21
1007c2e24:     	mov	x1, x19
1007c2e28:     	bl	0x10052d984 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007c2e2c:     	tbnz	w0, #0x0, 0x1007c2c04 <_js_array_get_f64+0x6f4>
1007c2e30:     	mov	x0, x21
1007c2e34:     	mov	x1, x19
1007c2e38:     	bl	0x1006cb824 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007c2e3c:     	b	0x1007c2c04 <_js_array_get_f64+0x6f4>
1007c2e40:     	add	x9, x8, #0xc0
1007c2e44:     	ldr	x10, [x8, #0x30]
1007c2e48:     	add	x10, x10, #0x1
1007c2e4c:     	str	x10, [x8, #0x30]
1007c2e50:     	add	x8, x9, #0x19
1007c2e54:     	ldrb	w8, [x8]
1007c2e58:     	cmp	w8, #0xff
1007c2e5c:     	b.ne	0x1007c2928 <_js_array_get_f64+0x418>
1007c2e60:     	b	0x1007c291c <_js_array_get_f64+0x40c>
1007c2e64:     	add	x21, x22, #0x1
1007c2e68:     	fmov	d0, x21
1007c2e6c:     	bl	0x10070163c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007c2e70:     	mov	x22, x0
1007c2e74:     	tbnz	w23, #0x0, 0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c2e78:     	mov	x0, x20
1007c2e7c:     	bl	0x100b63b80 <_mi_free>
1007c2e80:     	b	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c2e84:     	ldr	x20, [sp, #0x10]
1007c2e88:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2e8c:     	ldr	x8, [x8, #0xed8]
1007c2e90:     	cbz	x8, 0x1007c2ea8 <_js_array_get_f64+0x998>
1007c2e94:     	mov	x0, x20
1007c2e98:     	bl	0x10013cc40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007c2e9c:     	tbz	w0, #0x0, 0x1007c2ea8 <_js_array_get_f64+0x998>
1007c2ea0:     	mov	x0, x20
1007c2ea4:     	bl	0x1002c1840 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007c2ea8:     	tbnz	w19, #0x1f, 0x1007c2ec8 <_js_array_get_f64+0x9b8>
1007c2eac:     	ldr	w8, [x20]
1007c2eb0:     	cmp	w19, w8
1007c2eb4:     	b.hs	0x1007c2ec8 <_js_array_get_f64+0x9b8>
1007c2eb8:     	mov	w1, w19
1007c2ebc:     	mov	x0, x20
1007c2ec0:     	bl	0x1002a7acc <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007c2ec4:     	b	0x1007c2c04 <_js_array_get_f64+0x6f4>
1007c2ec8:     	mov	x8, #0x1                ; =1
1007c2ecc:     	movk	x8, #0x7ffc, lsl #48
1007c2ed0:     	mov	x22, x8
1007c2ed4:     	b	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c2ed8:     	mov	x0, x22
1007c2edc:     	bl	0x100b4c4f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007c2ee0:     	cmp	x0, #0x1
1007c2ee4:     	b.ne	0x1007c2550 <_js_array_get_f64+0x40>
1007c2ee8:     	mov	x0, x19
1007c2eec:     	bl	0x100b4c510 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007c2ef0:     	b	0x1007c2c04 <_js_array_get_f64+0x6f4>
1007c2ef4:     	mov	x0, x20
1007c2ef8:     	mov	w1, #0x0                ; =0
1007c2efc:     	bl	0x100b4ea80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007c2f00:     	mov	x20, x0
1007c2f04:     	cbnz	x0, 0x1007c262c <_js_array_get_f64+0x11c>
1007c2f08:     	b	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c2f0c:     	mov	x0, x20
1007c2f10:     	mov	w1, #0x1                ; =1
1007c2f14:     	bl	0x100b4ea80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007c2f18:     	mov	x20, x0
1007c2f1c:     	cbnz	x0, 0x1007c27d0 <_js_array_get_f64+0x2c0>
1007c2f20:     	b	0x1007c2c08 <_js_array_get_f64+0x6f8>
1007c2f24:     	mov	w0, #0x1                ; =1
1007c2f28:     	mov	x1, x22
1007c2f2c:     	bl	0x100b16f00 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
