
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/source-length-r11/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005e9278 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes>:
1005e9278:     	stp	x22, x21, [sp, #-0x30]!
1005e927c:     	stp	x20, x19, [sp, #0x10]
1005e9280:     	stp	x29, x30, [sp, #0x20]
1005e9284:     	add	x29, sp, #0x20
1005e9288:     	cbz	x3, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e928c:     	ldr	w8, [x3, #0x4]
1005e9290:     	adds	x11, x4, x2
1005e9294:     	cset	w9, hs
1005e9298:     	subs	x10, x8, x11
1005e929c:     	csinc	w9, w9, wzr, hs
1005e92a0:     	tbnz	w9, #0x0, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e92a4:     	subs	x8, x8, x2
1005e92a8:     	b.lo	0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e92ac:     	cmp	x8, x2, lsr #3
1005e92b0:     	b.hi	0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e92b4:     	add	x12, x3, #0x14
1005e92b8:     	add	x9, x12, x4
1005e92bc:     	add	x9, x9, x2
1005e92c0:     	ldurb	w13, [x9, #-0x1]
1005e92c4:     	cmp	w13, #0xc0
1005e92c8:     	b.hs	0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e92cc:     	ldurb	w13, [x9, #-0x2]
1005e92d0:     	cmp	w13, #0xdf
1005e92d4:     	b.hi	0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e92d8:     	ldurb	w9, [x9, #-0x3]
1005e92dc:     	cmp	w9, #0xef
1005e92e0:     	b.hi	0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e92e4:     	ldr	w9, [x3]
1005e92e8:     	cmp	x4, #0x40
1005e92ec:     	b.hs	0x1005e9390 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x118>
1005e92f0:     	ands	x14, x4, #0x38
1005e92f4:     	b.eq	0x1005e9318 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0xa0>
1005e92f8:     	and	x13, x4, #0x38
1005e92fc:     	neg	x13, x13
1005e9300:     	mov	x15, x12
1005e9304:     	ldr	x16, [x15], #0x8
1005e9308:     	tst	x16, #0x8080808080808080
1005e930c:     	b.ne	0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e9310:     	adds	x13, x13, #0x8
1005e9314:     	b.ne	0x1005e9304 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x8c>
1005e9318:     	and	x13, x4, #0x7
1005e931c:     	cbz	x13, 0x1005e9410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x198>
1005e9320:     	add	x14, x12, x14
1005e9324:     	ldrsb	w15, [x14]
1005e9328:     	tbnz	w15, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e932c:     	cmp	x13, #0x1
1005e9330:     	b.eq	0x1005e9410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x198>
1005e9334:     	ldrsb	w15, [x14, #0x1]
1005e9338:     	tbnz	w15, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e933c:     	cmp	x13, #0x2
1005e9340:     	b.eq	0x1005e9410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x198>
1005e9344:     	ldrsb	w15, [x14, #0x2]
1005e9348:     	tbnz	w15, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e934c:     	cmp	x13, #0x3
1005e9350:     	b.eq	0x1005e9410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x198>
1005e9354:     	ldrsb	w15, [x14, #0x3]
1005e9358:     	tbnz	w15, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e935c:     	cmp	x13, #0x4
1005e9360:     	b.eq	0x1005e9410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x198>
1005e9364:     	ldrsb	w15, [x14, #0x4]
1005e9368:     	tbnz	w15, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e936c:     	cmp	x13, #0x5
1005e9370:     	b.eq	0x1005e9410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x198>
1005e9374:     	ldrsb	w15, [x14, #0x5]
1005e9378:     	tbnz	w15, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e937c:     	cmp	x13, #0x6
1005e9380:     	b.eq	0x1005e9410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x198>
1005e9384:     	ldrsb	w13, [x14, #0x6]
1005e9388:     	tbz	w13, #0x1f, 0x1005e9410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x198>
1005e938c:     	b	0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e9390:     	and	x13, x4, #0x7fffffffffffffc0
1005e9394:     	add	x13, x12, x13
1005e9398:     	mov	x14, x12
1005e939c:     	ldp	q0, q1, [x14]
1005e93a0:     	ldp	q2, q3, [x14, #0x20]
1005e93a4:     	orr.16b	v0, v1, v0
1005e93a8:     	orr.16b	v1, v2, v3
1005e93ac:     	orr.16b	v0, v0, v1
1005e93b0:     	umaxv.16b	b0, v0
1005e93b4:     	fmov	w15, s0
1005e93b8:     	tbnz	w15, #0x7, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e93bc:     	add	x14, x14, #0x40
1005e93c0:     	cmp	x14, x13
1005e93c4:     	b.ne	0x1005e939c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x124>
1005e93c8:     	ands	x14, x4, #0x30
1005e93cc:     	b.eq	0x1005e93f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x178>
1005e93d0:     	mov	x15, x14
1005e93d4:     	mov	x16, x13
1005e93d8:     	ldr	q0, [x16], #0x10
1005e93dc:     	umaxv.16b	b0, v0
1005e93e0:     	fmov	w17, s0
1005e93e4:     	tbnz	w17, #0x7, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e93e8:     	subs	x15, x15, #0x10
1005e93ec:     	b.ne	0x1005e93d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x160>
1005e93f0:     	and	x15, x4, #0xf
1005e93f4:     	cbz	x15, 0x1005e9410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x198>
1005e93f8:     	add	x13, x13, x14
1005e93fc:     	ldrsb	w14, [x13]
1005e9400:     	tbnz	w14, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e9404:     	add	x13, x13, #0x1
1005e9408:     	subs	x15, x15, #0x1
1005e940c:     	b.ne	0x1005e93fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x184>
1005e9410:     	add	x11, x12, x11
1005e9414:     	cmp	x10, #0x40
1005e9418:     	b.hs	0x1005e94bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x244>
1005e941c:     	ands	x12, x10, #0x38
1005e9420:     	b.eq	0x1005e9444 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x1cc>
1005e9424:     	and	x13, x10, #0x38
1005e9428:     	neg	x13, x13
1005e942c:     	mov	x14, x11
1005e9430:     	ldr	x15, [x14], #0x8
1005e9434:     	tst	x15, #0x8080808080808080
1005e9438:     	b.ne	0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e943c:     	adds	x13, x13, #0x8
1005e9440:     	b.ne	0x1005e9430 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x1b8>
1005e9444:     	and	x10, x10, #0x7
1005e9448:     	cbz	x10, 0x1005e9538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c0>
1005e944c:     	add	x11, x11, x12
1005e9450:     	ldrsb	w12, [x11]
1005e9454:     	tbnz	w12, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e9458:     	cmp	x10, #0x1
1005e945c:     	b.eq	0x1005e9538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c0>
1005e9460:     	ldrsb	w12, [x11, #0x1]
1005e9464:     	tbnz	w12, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e9468:     	cmp	x10, #0x2
1005e946c:     	b.eq	0x1005e9538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c0>
1005e9470:     	ldrsb	w12, [x11, #0x2]
1005e9474:     	tbnz	w12, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e9478:     	cmp	x10, #0x3
1005e947c:     	b.eq	0x1005e9538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c0>
1005e9480:     	ldrsb	w12, [x11, #0x3]
1005e9484:     	tbnz	w12, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e9488:     	cmp	x10, #0x4
1005e948c:     	b.eq	0x1005e9538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c0>
1005e9490:     	ldrsb	w12, [x11, #0x4]
1005e9494:     	tbnz	w12, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e9498:     	cmp	x10, #0x5
1005e949c:     	b.eq	0x1005e9538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c0>
1005e94a0:     	ldrsb	w12, [x11, #0x5]
1005e94a4:     	tbnz	w12, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e94a8:     	cmp	x10, #0x6
1005e94ac:     	b.eq	0x1005e9538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c0>
1005e94b0:     	ldrsb	w10, [x11, #0x6]
1005e94b4:     	tbz	w10, #0x1f, 0x1005e9538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c0>
1005e94b8:     	b	0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e94bc:     	and	x12, x10, #0xffffffc0
1005e94c0:     	add	x12, x11, x12
1005e94c4:     	ldp	q0, q1, [x11]
1005e94c8:     	ldp	q2, q3, [x11, #0x20]
1005e94cc:     	orr.16b	v0, v1, v0
1005e94d0:     	orr.16b	v1, v2, v3
1005e94d4:     	orr.16b	v0, v0, v1
1005e94d8:     	umaxv.16b	b0, v0
1005e94dc:     	fmov	w13, s0
1005e94e0:     	tbnz	w13, #0x7, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e94e4:     	add	x11, x11, #0x40
1005e94e8:     	cmp	x11, x12
1005e94ec:     	b.ne	0x1005e94c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x24c>
1005e94f0:     	ands	x11, x10, #0x30
1005e94f4:     	b.eq	0x1005e9518 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2a0>
1005e94f8:     	mov	x13, x11
1005e94fc:     	mov	x14, x12
1005e9500:     	ldr	q0, [x14], #0x10
1005e9504:     	umaxv.16b	b0, v0
1005e9508:     	fmov	w15, s0
1005e950c:     	tbnz	w15, #0x7, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e9510:     	subs	x13, x13, #0x10
1005e9514:     	b.ne	0x1005e9500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x288>
1005e9518:     	and	x10, x10, #0xf
1005e951c:     	cbz	x10, 0x1005e9538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c0>
1005e9520:     	add	x11, x12, x11
1005e9524:     	ldrsb	w12, [x11]
1005e9528:     	tbnz	w12, #0x1f, 0x1005e9540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2c8>
1005e952c:     	add	x11, x11, #0x1
1005e9530:     	subs	x10, x10, #0x1
1005e9534:     	b.ne	0x1005e9524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2ac>
1005e9538:     	subs	w22, w9, w8
1005e953c:     	b.hs	0x1005e9550 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x2d8>
1005e9540:     	ldp	x29, x30, [sp, #0x20]
1005e9544:     	ldp	x20, x19, [sp, #0x10]
1005e9548:     	ldp	x22, x21, [sp], #0x30
1005e954c:     	b	0x1005e8ac4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
1005e9550:     	add	x0, x2, #0x14
1005e9554:     	mov	x20, x1
1005e9558:     	mov	w1, #0x3                ; =3
1005e955c:     	mov	x21, x2
1005e9560:     	bl	0x100455f40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
1005e9564:     	mov	x19, x0
1005e9568:     	stp	w22, w21, [x0]
1005e956c:     	str	w21, [x0, #0x8]
1005e9570:     	mov	x8, #0x200000000        ; =8589934592
1005e9574:     	stur	x8, [x0, #0xc]
1005e9578:     	add	x0, x0, #0x14
1005e957c:     	mov	x1, x20
1005e9580:     	mov	x20, x21
1005e9584:     	mov	x2, x21
1005e9588:     	bl	0x100b5ffac <_writev+0x100b5ffac>
1005e958c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1005e9590:     	ldr	w21, [x8, #0x590]
1005e9594:     	cmp	w21, #0x300
1005e9598:     	b.hs	0x1005e9608 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x390>
1005e959c:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1005e95a0:     	ldr	x8, [x8, #0x48]
1005e95a4:     	cmn	x8, #0x1
1005e95a8:     	b.eq	0x1005e95f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x380>
1005e95ac:     	mrs	x9, TPIDRRO_EL0
1005e95b0:     	and	x9, x9, #0xfffffffffffffff8
1005e95b4:     	ldr	x0, [x9, x8, lsl #3]
1005e95b8:     	cbz	x0, 0x1005e95f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x380>
1005e95bc:     	add	x8, x0, x21, lsl #3
1005e95c0:     	ldr	x0, [x8, #0x1e8]
1005e95c4:     	cbz	x0, 0x1005e9608 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x390>
1005e95c8:     	ldr	x8, [x0]
1005e95cc:     	adds	x8, x8, x20
1005e95d0:     	csinv	x8, x8, xzr, lo
1005e95d4:     	str	x8, [x0]
1005e95d8:     	lsr	x8, x8, #25
1005e95dc:     	cbz	x8, 0x1005e95e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x36c>
1005e95e0:     	bl	0x10045ce74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005e95e4:     	mov	x0, x19
1005e95e8:     	ldp	x29, x30, [sp, #0x20]
1005e95ec:     	ldp	x20, x19, [sp, #0x10]
1005e95f0:     	ldp	x22, x21, [sp], #0x30
1005e95f4:     	ret
1005e95f8:     	bl	0x100b3d53c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005e95fc:     	add	x8, x0, x21, lsl #3
1005e9600:     	ldr	x0, [x8, #0x1e8]
1005e9604:     	cbnz	x0, 0x1005e95c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x350>
1005e9608:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1005e960c:     	add	x0, x0, #0x78
1005e9610:     	bl	0x100b3ad5c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1005e9614:     	ldr	x8, [x0]
1005e9618:     	adds	x8, x8, x20
1005e961c:     	csinv	x8, x8, xzr, lo
1005e9620:     	str	x8, [x0]
1005e9624:     	lsr	x8, x8, #25
1005e9628:     	cbnz	x8, 0x1005e95e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x368>
1005e962c:     	b	0x1005e95e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction29string_from_json_source_bytes+0x36c>
