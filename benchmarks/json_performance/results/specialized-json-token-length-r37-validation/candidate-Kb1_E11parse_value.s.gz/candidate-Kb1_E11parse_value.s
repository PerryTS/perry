
benchmarks/json_performance/.work/specialized-json-token-length-r37/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100245d4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_>:
100245d4c:     	stp	x28, x27, [sp, #-0x60]!
100245d50:     	stp	x26, x25, [sp, #0x10]
100245d54:     	stp	x24, x23, [sp, #0x20]
100245d58:     	stp	x22, x21, [sp, #0x30]
100245d5c:     	stp	x20, x19, [sp, #0x40]
100245d60:     	stp	x29, x30, [sp, #0x50]
100245d64:     	add	x29, sp, #0x50
100245d68:     	sub	sp, sp, #0x240
100245d6c:     	ldp	x2, x19, [x0, #0x68]
100245d70:     	cmp	x19, x2
100245d74:     	b.hs	0x100245dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x60>
100245d78:     	ldr	x8, [x0, #0x60]
100245d7c:     	mov	x9, #0x2600             ; =9728
100245d80:     	movk	x9, #0x1, lsl #32
100245d84:     	ldrb	w10, [x8, x19]
100245d88:     	cmp	w10, #0x20
100245d8c:     	b.hi	0x100245dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x60>
100245d90:     	lsr	x10, x9, x10
100245d94:     	tbz	w10, #0x0, 0x100245dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x60>
100245d98:     	add	x19, x19, #0x1
100245d9c:     	str	x19, [x0, #0x70]
100245da0:     	cmp	x2, x19
100245da4:     	b.ne	0x100245d84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x38>
100245da8:     	b	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100245dac:     	cmp	x19, x2
100245db0:     	b.hs	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100245db4:     	ldr	x12, [x0, #0x60]
100245db8:     	add	x9, x12, x19
100245dbc:     	ldrb	w8, [x9]
100245dc0:     	cmp	w8, #0x65
100245dc4:     	b.le	0x100245e18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xcc>
100245dc8:     	cmp	w8, #0x73
100245dcc:     	b.gt	0x100245f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1c8>
100245dd0:     	cmp	w8, #0x66
100245dd4:     	b.eq	0x100245fd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x288>
100245dd8:     	cmp	w8, #0x6e
100245ddc:     	b.ne	0x100245fbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x270>
100245de0:     	add	x1, x19, #0x4
100245de4:     	cmp	x1, x2
100245de8:     	b.hi	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100245dec:     	cmn	x19, #0x5
100245df0:     	b.hi	0x100247758 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a0c>
100245df4:     	ldr	w8, [x9]
100245df8:     	mov	w9, #0x756e             ; =30062
100245dfc:     	movk	w9, #0x6c6c, lsl #16
100245e00:     	cmp	w8, w9
100245e04:     	b.ne	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100245e08:     	mov	x19, #0x2               ; =2
100245e0c:     	movk	x19, #0x7ffc, lsl #48
100245e10:     	str	x1, [x0, #0x70]
100245e14:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100245e18:     	cmp	w8, #0x22
100245e1c:     	b.eq	0x100245f90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x244>
100245e20:     	cmp	w8, #0x2d
100245e24:     	b.eq	0x100246058 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x30c>
100245e28:     	cmp	w8, #0x5b
100245e2c:     	b.ne	0x100245fbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x270>
100245e30:     	add	x8, x19, #0x1
100245e34:     	str	x8, [x0, #0x70]
100245e38:     	cmp	x8, x2
100245e3c:     	b.hs	0x100245e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120>
100245e40:     	mov	x9, #0x2600             ; =9728
100245e44:     	movk	x9, #0x1, lsl #32
100245e48:     	ldrb	w10, [x12, x8]
100245e4c:     	cmp	w10, #0x20
100245e50:     	b.hi	0x100245e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120>
100245e54:     	lsr	x10, x9, x10
100245e58:     	tbz	w10, #0x0, 0x100245e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120>
100245e5c:     	add	x8, x8, #0x1
100245e60:     	str	x8, [x0, #0x70]
100245e64:     	cmp	x2, x8
100245e68:     	b.ne	0x100245e48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xfc>
100245e6c:     	mov	x20, x0
100245e70:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100245e74:     	add	x0, x0, #0xce8
100245e78:     	ldr	x8, [x0]
100245e7c:     	blr	x8
100245e80:     	mov	x19, x0
100245e84:     	ldrb	w8, [x0, #0x20]
100245e88:     	cbnz	w8, 0x1002476d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1984>
100245e8c:     	ldr	x8, [x19]
100245e90:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100245e94:     	cmp	x8, x9
100245e98:     	b.hs	0x10024772c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19e0>
100245e9c:     	mov	x0, x20
100245ea0:     	ldr	x1, [x19, #0x18]
100245ea4:     	ldp	x8, x9, [x20, #0x68]
100245ea8:     	subs	x8, x8, x9
100245eac:     	b.ls	0x1002460c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x374>
100245eb0:     	ldr	x10, [x0, #0x60]
100245eb4:     	ldrb	w9, [x10, x9]
100245eb8:     	cmp	w9, #0x7b
100245ebc:     	b.ne	0x1002460c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x374>
100245ec0:     	mov	x9, #-0x5555555555555556 ; =-6148914691236517206
100245ec4:     	movk	x9, #0xaaab
100245ec8:     	umulh	x8, x8, x9
100245ecc:     	lsr	x8, x8, #6
100245ed0:     	mov	w9, #0x10               ; =16
100245ed4:     	cmp	x8, #0x10
100245ed8:     	csel	x8, x8, x9, hi
100245edc:     	mov	w9, #0x4000             ; =16384
100245ee0:     	cmp	x8, #0x4, lsl #12       ; =0x4000
100245ee4:     	csel	x2, x8, x9, lo
100245ee8:     	mov	x19, x0
100245eec:     	add	x0, sp, #0x188
100245ef0:     	mov	x20, x1
100245ef4:     	add	x1, x19, #0x20
100245ef8:     	bl	0x100233550 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray3new>
100245efc:     	add	x1, sp, #0x188
100245f00:     	mov	x0, x19
100245f04:     	mov	x2, x20
100245f08:     	bl	0x1002478cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E16parse_array_tailB9_>
100245f0c:     	mov	x19, x0
100245f10:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100245f14:     	cmp	w8, #0x74
100245f18:     	b.eq	0x10024601c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x2d0>
100245f1c:     	cmp	w8, #0x7b
100245f20:     	b.ne	0x100245fbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x270>
100245f24:     	add	x8, x19, #0x1
100245f28:     	str	x8, [x0, #0x70]
100245f2c:     	cmp	x8, x2
100245f30:     	b.hs	0x100245f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
100245f34:     	mov	x9, #0x2600             ; =9728
100245f38:     	movk	x9, #0x1, lsl #32
100245f3c:     	ldrb	w10, [x12, x8]
100245f40:     	cmp	w10, #0x20
100245f44:     	b.hi	0x100245f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
100245f48:     	lsr	x10, x9, x10
100245f4c:     	tbz	w10, #0x0, 0x100245f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x214>
100245f50:     	add	x8, x8, #0x1
100245f54:     	str	x8, [x0, #0x70]
100245f58:     	cmp	x2, x8
100245f5c:     	b.ne	0x100245f3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1f0>
100245f60:     	ldrb	w8, [x0, #0xd5]
100245f64:     	tbz	w8, #0x0, 0x10024610c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3c0>
100245f68:     	strb	wzr, [x0, #0xd5]
100245f6c:     	ldr	x22, [x0, #0x78]
100245f70:     	ldp	q0, q1, [x0, #0x80]
100245f74:     	stur	q0, [sp, #0xa8]
100245f78:     	stur	q1, [sp, #0xb8]
100245f7c:     	ldp	q0, q1, [x0, #0xa0]
100245f80:     	stur	q0, [sp, #0xc8]
100245f84:     	stur	q1, [sp, #0xd8]
100245f88:     	ldr	x9, [x0, #0xc0]
100245f8c:     	b	0x1002462b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x568>
100245f90:     	ldr	x8, [x0]
100245f94:     	cmp	x8, #0x1
100245f98:     	b.ne	0x1002460e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x394>
100245f9c:     	ldr	x8, [x0, #0x8]
100245fa0:     	cmp	x8, x19
100245fa4:     	b.ne	0x1002460e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x394>
100245fa8:     	ldp	x9, x8, [x0, #0x10]
100245fac:     	str	x9, [x0, #0x70]
100245fb0:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
100245fb4:     	bfxil	x19, x8, #0, #48
100245fb8:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100245fbc:     	sub	w8, w8, #0x30
100245fc0:     	cmp	w8, #0x9
100245fc4:     	b.hi	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100245fc8:     	mov	w13, #0x0               ; =0
100245fcc:     	mov	x10, x19
100245fd0:     	b	0x100246064 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x318>
100245fd4:     	add	x1, x19, #0x5
100245fd8:     	cmp	x1, x2
100245fdc:     	b.hi	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100245fe0:     	cmn	x19, #0x6
100245fe4:     	b.hi	0x100247738 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19ec>
100245fe8:     	ldrb	w8, [x9, #0x4]
100245fec:     	ldr	w9, [x9]
100245ff0:     	orr	x8, x9, x8, lsl #32
100245ff4:     	mov	x9, #0x6166             ; =24934
100245ff8:     	movk	x9, #0x736c, lsl #16
100245ffc:     	movk	x9, #0x65, lsl #32
100246000:     	cmp	x8, x9
100246004:     	b.ne	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100246008:     	str	x1, [x0, #0x70]
10024600c:     	mov	x8, #0x2                ; =2
100246010:     	movk	x8, #0x7ffc, lsl #48
100246014:     	orr	x19, x8, #0x1
100246018:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
10024601c:     	add	x1, x19, #0x4
100246020:     	cmp	x1, x2
100246024:     	b.hi	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100246028:     	cmn	x19, #0x5
10024602c:     	b.hi	0x100247748 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19fc>
100246030:     	ldr	w8, [x9]
100246034:     	mov	w9, #0x7274             ; =29300
100246038:     	movk	w9, #0x6575, lsl #16
10024603c:     	cmp	w8, w9
100246040:     	b.ne	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100246044:     	str	x1, [x0, #0x70]
100246048:     	mov	x8, #0x2                ; =2
10024604c:     	movk	x8, #0x7ffc, lsl #48
100246050:     	add	x19, x8, #0x2
100246054:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100246058:     	add	x10, x19, #0x1
10024605c:     	str	x10, [x0, #0x70]
100246060:     	mov	w13, #0x1               ; =1
100246064:     	cmp	x10, x2
100246068:     	b.hs	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
10024606c:     	add	x14, x12, x10
100246070:     	ldrb	w8, [x14]
100246074:     	cmp	w8, #0x30
100246078:     	b.ne	0x100246130 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3e4>
10024607c:     	add	x1, x10, #0x1
100246080:     	str	x1, [x0, #0x70]
100246084:     	cmp	x1, x2
100246088:     	b.hs	0x100246168 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x41c>
10024608c:     	ldrb	w8, [x12, x1]
100246090:     	sub	w8, w8, #0x30
100246094:     	cmp	w8, #0x9
100246098:     	b.hi	0x100246168 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x41c>
10024609c:     	ldrb	w8, [x12, x1]
1002460a0:     	sub	w8, w8, #0x30
1002460a4:     	cmp	w8, #0xa
1002460a8:     	b.hs	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
1002460ac:     	add	x1, x1, #0x1
1002460b0:     	str	x1, [x0, #0x70]
1002460b4:     	cmp	x2, x1
1002460b8:     	b.ne	0x10024609c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x350>
1002460bc:     	b	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
1002460c0:     	add	sp, sp, #0x240
1002460c4:     	ldp	x29, x30, [sp, #0x50]
1002460c8:     	ldp	x20, x19, [sp, #0x40]
1002460cc:     	ldp	x22, x21, [sp, #0x30]
1002460d0:     	ldp	x24, x23, [sp, #0x20]
1002460d4:     	ldp	x26, x25, [sp, #0x10]
1002460d8:     	ldp	x28, x27, [sp], #0x60
1002460dc:     	b	0x100247d4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E18parse_array_prefixB9_>
1002460e0:     	mov	x1, x0
1002460e4:     	add	x0, sp, #0x188
1002460e8:     	mov	x24, x1
1002460ec:     	bl	0x1002433f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_>
1002460f0:     	ldr	x22, [sp, #0x188]
1002460f4:     	cmn	x22, #0x2
1002460f8:     	b.ne	0x1002461e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x498>
1002460fc:     	mov	x19, #0x2               ; =2
100246100:     	movk	x19, #0x7ffc, lsl #48
100246104:     	strb	wzr, [x24, #0xd4]
100246108:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
10024610c:     	ldr	x22, [x0, #0x78]
100246110:     	ldr	x9, [x0, #0xc0]
100246114:     	cmp	x22, #0x0
100246118:     	ccmp	x9, #0x0, #0x4, ne
10024611c:     	b.ne	0x10024629c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x550>
100246120:     	mov	x21, x0
100246124:     	mov	x8, #0x0                ; =0
100246128:     	mov	w27, #0x0               ; =0
10024612c:     	b	0x1002462d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x588>
100246130:     	sub	w8, w8, #0x31
100246134:     	cmp	w8, #0x8
100246138:     	b.hi	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
10024613c:     	mov	x1, x10
100246140:     	ldrb	w8, [x12, x1]
100246144:     	sub	w8, w8, #0x30
100246148:     	cmp	w8, #0x9
10024614c:     	b.hi	0x100246168 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x41c>
100246150:     	add	x1, x1, #0x1
100246154:     	str	x1, [x0, #0x70]
100246158:     	cmp	x2, x1
10024615c:     	b.ne	0x100246140 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x3f4>
100246160:     	mov	x1, x2
100246164:     	b	0x100246190 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x444>
100246168:     	subs	x8, x1, x2
10024616c:     	b.hs	0x100246190 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x444>
100246170:     	ldrb	w11, [x12, x1]
100246174:     	cmp	w11, #0x2e
100246178:     	b.eq	0x1002470f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x13a4>
10024617c:     	cmp	w11, #0x45
100246180:     	b.eq	0x100246f58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120c>
100246184:     	mov	x8, x1
100246188:     	cmp	w11, #0x65
10024618c:     	b.eq	0x100246f5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100246190:     	subs	x8, x1, x10
100246194:     	ccmp	x8, #0x13, #0x2, ne
100246198:     	b.hs	0x100246f58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x120c>
10024619c:     	cmp	x1, x10
1002461a0:     	b.lo	0x1002477c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a78>
1002461a4:     	cmp	x1, x2
1002461a8:     	b.hi	0x1002477c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a78>
1002461ac:     	mov	x9, #0x0                ; =0
1002461b0:     	mov	w10, #0xa               ; =10
1002461b4:     	ldrb	w11, [x14], #0x1
1002461b8:     	mul	x9, x9, x10
1002461bc:     	sub	w11, w11, #0x30
1002461c0:     	add	x9, x9, w11, uxtb
1002461c4:     	subs	x8, x8, #0x1
1002461c8:     	b.ne	0x1002461b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x468>
1002461cc:     	ucvtf	d0, x9
1002461d0:     	fneg	d1, d0
1002461d4:     	cmp	w13, #0x0
1002461d8:     	fcsel	d0, d1, d0, ne
1002461dc:     	fmov	x19, d0
1002461e0:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002461e4:     	ldp	x21, x20, [sp, #0x190]
1002461e8:     	cmp	x20, #0x6
1002461ec:     	b.hs	0x10024627c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x530>
1002461f0:     	subs	x8, x20, #0x3
1002461f4:     	b.lo	0x100247080 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
1002461f8:     	ldrb	w9, [x21]
1002461fc:     	cmp	w9, #0xed
100246200:     	b.ne	0x100246220 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4d4>
100246204:     	ldrb	w9, [x21, #0x1]
100246208:     	and	w9, w9, #0xe0
10024620c:     	cmp	w9, #0xa0
100246210:     	b.ne	0x100246220 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x4d4>
100246214:     	ldrsb	w9, [x21, #0x2]
100246218:     	cmn	w9, #0x40
10024621c:     	b.lt	0x10024627c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x530>
100246220:     	cbz	x8, 0x100247080 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
100246224:     	ldrb	w9, [x21, #0x1]
100246228:     	cmp	w9, #0xed
10024622c:     	b.ne	0x10024624c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x500>
100246230:     	ldrb	w9, [x21, #0x2]
100246234:     	and	w9, w9, #0xe0
100246238:     	cmp	w9, #0xa0
10024623c:     	b.ne	0x10024624c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x500>
100246240:     	ldrsb	w9, [x21, #0x3]
100246244:     	cmn	w9, #0x40
100246248:     	b.lt	0x10024627c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x530>
10024624c:     	cmp	x8, #0x1
100246250:     	b.eq	0x100247080 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
100246254:     	ldrb	w8, [x21, #0x2]
100246258:     	cmp	w8, #0xed
10024625c:     	b.ne	0x100247080 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
100246260:     	ldrb	w8, [x21, #0x3]
100246264:     	and	w8, w8, #0xe0
100246268:     	cmp	w8, #0xa0
10024626c:     	b.ne	0x100247080 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
100246270:     	ldrsb	w8, [x21, #0x4]
100246274:     	cmn	w8, #0x40
100246278:     	b.ge	0x100247080 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1334>
10024627c:     	cmn	x22, #0x1
100246280:     	b.eq	0x1002470ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1360>
100246284:     	mov	x0, x21
100246288:     	mov	x1, x20
10024628c:     	bl	0x10034bcf0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
100246290:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
100246294:     	bfxil	x19, x0, #0, #48
100246298:     	b	0x100247200 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14b4>
10024629c:     	ldp	q0, q1, [x0, #0x80]
1002462a0:     	stur	q0, [sp, #0xa8]
1002462a4:     	stur	q1, [sp, #0xb8]
1002462a8:     	ldp	q0, q1, [x0, #0xa0]
1002462ac:     	stur	q0, [sp, #0xc8]
1002462b0:     	stur	q1, [sp, #0xd8]
1002462b4:     	mov	x21, x0
1002462b8:     	ldr	w8, [x0, #0xd0]
1002462bc:     	stp	x22, x9, [sp, #0xe8]
1002462c0:     	str	x9, [sp, #0x90]
1002462c4:     	str	w8, [sp, #0x7c]
1002462c8:     	str	w8, [sp, #0xf8]
1002462cc:     	mov	w8, #0x1                ; =1
1002462d0:     	mov	w27, #0x1               ; =1
1002462d4:     	str	x8, [sp, #0xa0]
1002462d8:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1002462dc:     	add	x0, x0, #0xce8
1002462e0:     	ldr	x8, [x0]
1002462e4:     	blr	x8
1002462e8:     	mov	x19, x0
1002462ec:     	ldrb	w8, [x0, #0x20]
1002462f0:     	cbnz	w8, 0x100247700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19b4>
1002462f4:     	ldr	x8, [x19]
1002462f8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1002462fc:     	cmp	x8, x9
100246300:     	b.hs	0x10024772c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19e0>
100246304:     	ldr	x23, [x19, #0x18]
100246308:     	ldp	x24, x28, [x21, #0x68]
10024630c:     	cmp	x28, x24
100246310:     	b.hs	0x100246344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5f8>
100246314:     	ldr	x8, [x21, #0x60]
100246318:     	ldrb	w8, [x8, x28]
10024631c:     	cmp	w8, #0x7d
100246320:     	b.ne	0x100246344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5f8>
100246324:     	add	x8, x28, #0x1
100246328:     	str	x8, [x21, #0x70]
10024632c:     	ldr	x8, [x21, #0x78]
100246330:     	cbnz	x8, 0x100247024 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12d8>
100246334:     	ldr	x1, [x21, #0xc0]
100246338:     	cbz	x1, 0x100247024 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12d8>
10024633c:     	ldr	w2, [x21, #0xd0]
100246340:     	b	0x100247044 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12f8>
100246344:     	movi.2d	v0, #0000000000000000
100246348:     	stp	q0, q0, [sp, #0x120]
10024634c:     	stp	q0, q0, [sp, #0x100]
100246350:     	adrp	x1, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x77b0>
100246354:     	add	x1, x1, #0x330
100246358:     	add	x0, sp, #0x148
10024635c:     	mov	w2, #0x40               ; =64
100246360:     	bl	0x100b64510 <_writev+0x100b64510>
100246364:     	mov	x8, x21
100246368:     	mov	x12, #0x0               ; =0
10024636c:     	str	xzr, [sp, #0x98]
100246370:     	mov	x9, #-0x1               ; =-1
100246374:     	str	x9, [sp, #0x188]
100246378:     	add	x9, sp, #0xa0
10024637c:     	add	x9, x9, #0x8
100246380:     	stp	x9, xzr, [sp, #0x68]
100246384:     	mov	x25, #0x2600            ; =9728
100246388:     	movk	x25, #0x1, lsl #32
10024638c:     	adrp	x9, 0x100c9c000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x57b0>
100246390:     	ldr	q0, [x9, #0xd0]
100246394:     	str	q0, [sp, #0x50]
100246398:     	adrp	x9, 0x100c9c000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x57b0>
10024639c:     	ldr	q0, [x9, #0xe0]
1002463a0:     	str	q0, [sp, #0x40]
1002463a4:     	mov	x26, x27
1002463a8:     	mov	x9, x27
1002463ac:     	str	w27, [sp, #0x88]
1002463b0:     	str	x22, [sp, #0x80]
1002463b4:     	str	w9, [sp, #0x8c]
1002463b8:     	cmp	x28, x24
1002463bc:     	b.hs	0x1002463ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6a0>
1002463c0:     	ldr	x9, [x8, #0x60]
1002463c4:     	ldrb	w10, [x9, x28]
1002463c8:     	cmp	w10, #0x20
1002463cc:     	b.hi	0x1002463ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6a0>
1002463d0:     	lsr	x10, x25, x10
1002463d4:     	tbz	w10, #0x0, 0x1002463ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x6a0>
1002463d8:     	add	x28, x28, #0x1
1002463dc:     	str	x28, [x8, #0x70]
1002463e0:     	cmp	x24, x28
1002463e4:     	b.ne	0x1002463c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x678>
1002463e8:     	mov	x28, x24
1002463ec:     	cbz	w27, 0x1002464b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x764>
1002463f0:     	cmp	x12, x22
1002463f4:     	cset	w9, lo
1002463f8:     	tst	w26, w9
1002463fc:     	b.eq	0x1002464b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x764>
100246400:     	mov	x20, x26
100246404:     	mov	x26, x12
100246408:     	cmp	x12, #0x8
10024640c:     	b.hs	0x100247860 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b14>
100246410:     	cmp	x28, x24
100246414:     	b.hs	0x1002464c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
100246418:     	ldr	x8, [sp, #0x68]
10024641c:     	ldr	x9, [x8, x26, lsl #3]
100246420:     	cbz	x9, 0x1002464c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
100246424:     	ldr	x10, [x21, #0x60]
100246428:     	ldrb	w8, [x10, x28]
10024642c:     	cmp	w8, #0x22
100246430:     	b.ne	0x1002464c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
100246434:     	add	x11, x28, #0x1
100246438:     	ldr	w14, [x9, #0x4]
10024643c:     	add	x8, x11, x14
100246440:     	cmp	x8, x24
100246444:     	ccmp	x8, x28, #0x0, lo
100246448:     	b.ls	0x1002464c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
10024644c:     	ldrb	w12, [x10, x8]
100246450:     	cmp	w12, #0x22
100246454:     	b.ne	0x1002464c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
100246458:     	add	x1, x10, x11
10024645c:     	cbz	w14, 0x100246498 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x74c>
100246460:     	add	x9, x9, #0x14
100246464:     	mov	x10, x14
100246468:     	mov	x11, x1
10024646c:     	ldrb	w12, [x11], #0x1
100246470:     	cmp	w12, #0x5c
100246474:     	b.eq	0x1002464c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
100246478:     	cmp	w12, #0x22
10024647c:     	b.eq	0x1002464c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
100246480:     	ldrb	w13, [x9], #0x1
100246484:     	cmp	w12, #0x20
100246488:     	ccmp	w12, w13, #0x0, hs
10024648c:     	b.ne	0x1002464c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x778>
100246490:     	subs	x10, x10, #0x1
100246494:     	b.ne	0x10024646c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x720>
100246498:     	add	x9, x8, #0x1
10024649c:     	mov	x8, x21
1002464a0:     	str	x9, [x21, #0x70]
1002464a4:     	mov	w24, #0x1               ; =1
1002464a8:     	mov	x27, #-0x1              ; =-1
1002464ac:     	b	0x1002464e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x79c>
1002464b0:     	mov	x20, x26
1002464b4:     	mov	x26, x12
1002464b8:     	mov	x1, x8
1002464bc:     	sub	x0, x29, #0x80
1002464c0:     	b	0x1002464cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x780>
1002464c4:     	sub	x0, x29, #0x80
1002464c8:     	mov	x1, x21
1002464cc:     	bl	0x1002433f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_>
1002464d0:     	ldur	x27, [x29, #-0x80]
1002464d4:     	cmn	x27, #0x2
1002464d8:     	b.eq	0x100247254 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1508>
1002464dc:     	mov	w24, #0x0               ; =0
1002464e0:     	ldp	x1, x14, [x29, #-0x78]
1002464e4:     	mov	x8, x21
1002464e8:     	ldr	x28, [sp, #0x98]
1002464ec:     	ldp	x10, x9, [x8, #0x68]
1002464f0:     	cmp	x9, x10
1002464f4:     	b.hs	0x100246efc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b0>
1002464f8:     	ldr	x11, [x8, #0x60]
1002464fc:     	ldrb	w12, [x11, x9]
100246500:     	cmp	w12, #0x3a
100246504:     	b.hi	0x100246efc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b0>
100246508:     	lsr	x13, x25, x12
10024650c:     	tbz	w13, #0x0, 0x100246524 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x7d8>
100246510:     	add	x9, x9, #0x1
100246514:     	str	x9, [x8, #0x70]
100246518:     	cmp	x10, x9
10024651c:     	b.ne	0x1002464fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x7b0>
100246520:     	b	0x100246efc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b0>
100246524:     	cmp	x12, #0x3a
100246528:     	b.ne	0x100246efc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b0>
10024652c:     	stp	x14, x1, [sp, #0x30]
100246530:     	add	x9, x9, #0x1
100246534:     	str	x9, [x8, #0x70]
100246538:     	mov	x0, x21
10024653c:     	bl	0x100245d4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_>
100246540:     	mov	x8, x21
100246544:     	ldrb	w9, [x21, #0xd4]
100246548:     	tbz	w9, #0x0, 0x1002476b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1964>
10024654c:     	ldr	x10, [sp, #0x188]
100246550:     	cmn	x10, #0x1
100246554:     	ldp	x3, x17, [sp, #0x30]
100246558:     	str	x0, [sp, #0x28]
10024655c:     	b.eq	0x100246614 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x8c8>
100246560:     	ldr	x9, [sp, #0x1b8]
100246564:     	cmn	x9, #0x1
100246568:     	b.eq	0x100246658 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x90c>
10024656c:     	ldp	x8, x11, [sp, #0x1f0]
100246570:     	ldr	x10, [sp, #0x200]
100246574:     	ldr	x9, [sp, #0x208]
100246578:     	eor	x11, x11, x3
10024657c:     	mov	x13, #0x7f2d            ; =32557
100246580:     	movk	x13, #0x4c95, lsl #16
100246584:     	movk	x13, #0xf42d, lsl #32
100246588:     	movk	x13, #0x5851, lsl #48
10024658c:     	mul	x12, x11, x13
100246590:     	umulh	x11, x11, x13
100246594:     	eor	x11, x11, x12
100246598:     	add	x11, x3, x11
10024659c:     	mul	x11, x11, x13
1002465a0:     	cmp	x3, #0x8
1002465a4:     	b.ls	0x1002466ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x960>
1002465a8:     	cmp	x3, #0x10
1002465ac:     	b.ls	0x100246760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa14>
1002465b0:     	add	x12, x17, x3
1002465b4:     	ldp	x12, x13, [x12, #-0x10]
1002465b8:     	eor	x12, x10, x12
1002465bc:     	eor	x13, x13, x9
1002465c0:     	mul	x14, x13, x12
1002465c4:     	umulh	x12, x13, x12
1002465c8:     	eor	x12, x12, x14
1002465cc:     	add	x11, x11, x8
1002465d0:     	eor	x11, x11, x12
1002465d4:     	ror	x11, x11, #0x29
1002465d8:     	mov	x13, x17
1002465dc:     	mov	x12, x3
1002465e0:     	ldp	x15, x14, [x13], #0x10
1002465e4:     	sub	x12, x12, #0x10
1002465e8:     	eor	x15, x10, x15
1002465ec:     	eor	x14, x14, x9
1002465f0:     	mul	x16, x14, x15
1002465f4:     	umulh	x14, x14, x15
1002465f8:     	eor	x14, x14, x16
1002465fc:     	add	x11, x11, x8
100246600:     	eor	x11, x11, x14
100246604:     	ror	x11, x11, #0x29
100246608:     	cmp	x12, #0x10
10024660c:     	b.hi	0x1002465e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x894>
100246610:     	b	0x10024684c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb00>
100246614:     	ldr	w9, [sp, #0x8c]
100246618:     	tbz	w9, #0x0, 0x1002466cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x980>
10024661c:     	ldr	w9, [sp, #0x88]
100246620:     	tbz	w9, #0x0, 0x100247830 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ae4>
100246624:     	mov	x12, x26
100246628:     	ldr	x9, [sp, #0x80]
10024662c:     	cmp	x26, x9
100246630:     	b.hs	0x10024698c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc40>
100246634:     	mov	x26, x20
100246638:     	tbz	w24, #0x0, 0x10024694c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc00>
10024663c:     	cmp	x12, #0x7
100246640:     	b.hi	0x100247898 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b4c>
100246644:     	ldr	x9, [sp, #0x68]
100246648:     	ldr	x11, [x9, x12, lsl #3]
10024664c:     	add	x12, x12, #0x1
100246650:     	mov	w9, #0x1                ; =1
100246654:     	b	0x1002469b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc64>
100246658:     	str	x10, [sp, #0x10]
10024665c:     	ldp	x1, x24, [sp, #0x190]
100246660:     	cmp	x24, #0x80
100246664:     	b.ne	0x1002466f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x9a4>
100246668:     	mov	w9, #0x1                ; =1
10024666c:     	strb	w9, [x8, #0xd6]
100246670:     	add	x8, sp, #0x188
100246674:     	add	x0, x8, #0x30
100246678:     	mov	x28, x1
10024667c:     	bl	0x10028909c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex9from_keys>
100246680:     	ldp	x3, x17, [sp, #0x30]
100246684:     	ldr	x8, [sp, #0x1b8]
100246688:     	cmn	x8, #0x1
10024668c:     	b.ne	0x10024656c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x820>
100246690:     	mov	x0, x17
100246694:     	mov	x1, x3
100246698:     	bl	0x10032873c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
10024669c:     	mov	x13, x0
1002466a0:     	add	x22, x28, #0x400
1002466a4:     	mov	x11, x28
1002466a8:     	b	0x100246710 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x9c4>
1002466ac:     	cmp	x3, #0x1
1002466b0:     	b.ls	0x100246770 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa24>
1002466b4:     	add	x13, x17, x3
1002466b8:     	cmp	x3, #0x3
1002466bc:     	b.ls	0x100246818 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xacc>
1002466c0:     	ldr	w12, [x17]
1002466c4:     	ldur	w13, [x13, #-0x4]
1002466c8:     	b	0x10024682c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xae0>
1002466cc:     	mov	x0, x17
1002466d0:     	mov	x1, x3
1002466d4:     	bl	0x10032873c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
1002466d8:     	mov	x11, x0
1002466dc:     	mov	x8, x21
1002466e0:     	mov	w9, #0x0                ; =0
1002466e4:     	mov	x12, x26
1002466e8:     	mov	x26, x20
1002466ec:     	b	0x1002469b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc64>
1002466f0:     	str	x1, [sp, #0x8]
1002466f4:     	mov	x0, x17
1002466f8:     	mov	x1, x3
1002466fc:     	bl	0x10032873c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100246700:     	mov	x13, x0
100246704:     	cbz	x24, 0x100246d78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x102c>
100246708:     	ldr	x11, [sp, #0x8]
10024670c:     	add	x22, x11, x24, lsl #3
100246710:     	mov	x12, x26
100246714:     	cmp	x26, #0x0
100246718:     	cset	w8, eq
10024671c:     	ldr	w9, [sp, #0x8c]
100246720:     	orr	w8, w8, w9
100246724:     	tbz	w8, #0x0, 0x100246780 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa34>
100246728:     	mov	x0, #0x0                ; =0
10024672c:     	mov	x9, x11
100246730:     	mov	x8, x21
100246734:     	mov	x26, x20
100246738:     	ldr	x1, [sp, #0x38]
10024673c:     	ldr	x20, [sp, #0x20]
100246740:     	ldr	x10, [x9], #0x8
100246744:     	cmp	x10, x13
100246748:     	b.eq	0x1002467fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xab0>
10024674c:     	add	x0, x0, #0x1
100246750:     	cmp	x9, x22
100246754:     	b.ne	0x100246740 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x9f4>
100246758:     	ldr	x28, [sp, #0x98]
10024675c:     	b	0x100246da4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1058>
100246760:     	ldr	x12, [x17]
100246764:     	add	x13, x17, x3
100246768:     	ldur	x13, [x13, #-0x8]
10024676c:     	b	0x10024682c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xae0>
100246770:     	b.ne	0x100246824 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xad8>
100246774:     	ldrb	w12, [x17]
100246778:     	mov	x13, x12
10024677c:     	b	0x10024682c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xae0>
100246780:     	stp	x24, x11, [sp]
100246784:     	str	x23, [sp, #0x18]
100246788:     	mov	x24, #0x0               ; =0
10024678c:     	mov	x23, x11
100246790:     	mov	x26, x20
100246794:     	ldp	x2, x1, [sp, #0x30]
100246798:     	ldr	x20, [sp, #0x20]
10024679c:     	b	0x1002467ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa60>
1002467a0:     	sub	x24, x24, #0x1
1002467a4:     	cmp	x23, x22
1002467a8:     	b.eq	0x100246d90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1044>
1002467ac:     	ldr	x8, [x23], #0x8
1002467b0:     	cmp	x8, x13
1002467b4:     	b.eq	0x1002467f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xaa4>
1002467b8:     	ldr	w9, [x8, #0x4]
1002467bc:     	cmp	x2, x9
1002467c0:     	b.ne	0x1002467a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa54>
1002467c4:     	add	x0, x8, #0x14
1002467c8:     	mov	x20, x26
1002467cc:     	mov	x26, x12
1002467d0:     	mov	x28, x13
1002467d4:     	bl	0x100b644e0 <_writev+0x100b644e0>
1002467d8:     	mov	x13, x28
1002467dc:     	ldp	x2, x1, [sp, #0x30]
1002467e0:     	mov	x12, x26
1002467e4:     	mov	x26, x20
1002467e8:     	ldr	x20, [sp, #0x20]
1002467ec:     	cbnz	w0, 0x1002467a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xa54>
1002467f0:     	neg	x0, x24
1002467f4:     	mov	x8, x21
1002467f8:     	ldr	x23, [sp, #0x18]
1002467fc:     	cmp	x0, x20
100246800:     	ldr	x28, [sp, #0x98]
100246804:     	ldr	x9, [sp, #0x60]
100246808:     	b.hs	0x100247888 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b3c>
10024680c:     	ldr	x10, [sp, #0x28]
100246810:     	str	x10, [x9, x0, lsl #3]
100246814:     	b	0x100246de4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1098>
100246818:     	ldrh	w12, [x17]
10024681c:     	ldurb	w13, [x13, #-0x1]
100246820:     	b	0x10024682c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xae0>
100246824:     	mov	x12, #0x0               ; =0
100246828:     	mov	x13, #0x0               ; =0
10024682c:     	eor	x10, x12, x10
100246830:     	eor	x9, x13, x9
100246834:     	mul	x12, x9, x10
100246838:     	umulh	x9, x9, x10
10024683c:     	eor	x9, x9, x12
100246840:     	add	x10, x11, x8
100246844:     	eor	x9, x10, x9
100246848:     	ror	x11, x9, #0x29
10024684c:     	mul	x9, x11, x8
100246850:     	umulh	x8, x11, x8
100246854:     	eor	x8, x8, x9
100246858:     	neg	w9, w11
10024685c:     	ror	x24, x8, x9
100246860:     	ldp	x4, x28, [sp, #0x190]
100246864:     	add	x8, sp, #0x188
100246868:     	add	x0, x8, #0x30
10024686c:     	mov	x1, x24
100246870:     	mov	x2, x17
100246874:     	mov	x5, x28
100246878:     	bl	0x100288ccc <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11find_hashed>
10024687c:     	tbz	w0, #0x0, 0x1002468a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb5c>
100246880:     	ldr	x8, [sp, #0x20]
100246884:     	cmp	x1, x8
100246888:     	b.hs	0x100247874 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b28>
10024688c:     	mov	x8, x21
100246890:     	mov	x12, x26
100246894:     	ldr	x9, [sp, #0x60]
100246898:     	ldr	x10, [sp, #0x28]
10024689c:     	str	x10, [x9, x1, lsl #3]
1002468a0:     	ldr	x28, [sp, #0x98]
1002468a4:     	b	0x100246940 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xbf4>
1002468a8:     	cmn	x27, #0x1
1002468ac:     	str	x23, [sp, #0x18]
1002468b0:     	b.eq	0x1002468c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb74>
1002468b4:     	ldp	x1, x0, [sp, #0x30]
1002468b8:     	bl	0x10034bcf0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
1002468bc:     	b	0x1002468cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xb80>
1002468c0:     	add	x0, x21, #0x20
1002468c4:     	ldp	x2, x1, [sp, #0x30]
1002468c8:     	bl	0x1005eb684 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
1002468cc:     	mov	x22, x0
1002468d0:     	add	x8, sp, #0x188
1002468d4:     	add	x0, x8, #0x30
1002468d8:     	mov	x1, x24
1002468dc:     	mov	x2, x28
1002468e0:     	bl	0x100288ea0 <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
1002468e4:     	ldr	x23, [sp, #0x198]
1002468e8:     	ldr	x8, [sp, #0x188]
1002468ec:     	cmp	x23, x8
1002468f0:     	b.eq	0x100246e70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1124>
1002468f4:     	ldr	x8, [sp, #0x190]
1002468f8:     	str	x22, [x8, x23, lsl #3]
1002468fc:     	add	x8, x23, #0x1
100246900:     	str	x8, [sp, #0x198]
100246904:     	ldr	x23, [sp, #0x1b0]
100246908:     	ldr	x8, [sp, #0x1a0]
10024690c:     	cmp	x23, x8
100246910:     	ldr	x28, [sp, #0x98]
100246914:     	b.eq	0x100246e7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1130>
100246918:     	ldr	x8, [sp, #0x1a8]
10024691c:     	str	x8, [sp, #0x60]
100246920:     	ldr	x9, [sp, #0x28]
100246924:     	str	x9, [x8, x23, lsl #3]
100246928:     	add	x8, x23, #0x1
10024692c:     	str	x8, [sp, #0x20]
100246930:     	str	x8, [sp, #0x1b0]
100246934:     	mov	x8, x21
100246938:     	ldr	x23, [sp, #0x18]
10024693c:     	mov	x12, x26
100246940:     	mov	x26, x20
100246944:     	ldr	x1, [sp, #0x38]
100246948:     	b	0x100246de4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1098>
10024694c:     	cmp	x12, #0x8
100246950:     	b.hs	0x1002478ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b60>
100246954:     	ldr	x8, [sp, #0x68]
100246958:     	ldr	x9, [x8, x12, lsl #3]
10024695c:     	ldr	w8, [x9, #0x4]
100246960:     	cmp	x3, x8
100246964:     	b.ne	0x10024698c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xc40>
100246968:     	add	x0, x9, #0x14
10024696c:     	mov	x1, x17
100246970:     	mov	x2, x3
100246974:     	mov	x24, x12
100246978:     	mov	x20, x9
10024697c:     	bl	0x100b644e0 <_writev+0x100b644e0>
100246980:     	ldp	x3, x17, [sp, #0x30]
100246984:     	mov	x12, x24
100246988:     	cbz	w0, 0x100246e8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1140>
10024698c:     	mov	x0, x17
100246990:     	mov	x1, x3
100246994:     	mov	x24, x12
100246998:     	bl	0x10032873c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
10024699c:     	mov	x12, x24
1002469a0:     	mov	x11, x0
1002469a4:     	mov	x8, x21
1002469a8:     	mov	w26, #0x0               ; =0
1002469ac:     	mov	w9, #0x0                ; =0
1002469b0:     	cmp	x12, #0x0
1002469b4:     	str	w9, [sp, #0x8c]
1002469b8:     	csinc	w24, w9, wzr, ne
1002469bc:     	cmp	x28, #0x9
1002469c0:     	b.hs	0x1002477e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a9c>
1002469c4:     	ldp	x2, x1, [sp, #0x30]
1002469c8:     	cbz	x28, 0x100246d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
1002469cc:     	ldr	x9, [sp, #0x100]
1002469d0:     	cmp	x9, x11
1002469d4:     	b.eq	0x100246d68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x101c>
1002469d8:     	tbnz	w24, #0x0, 0x100246a14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xcc8>
1002469dc:     	ldr	w10, [x9, #0x4]
1002469e0:     	cmp	x2, x10
1002469e4:     	b.ne	0x100246a14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xcc8>
1002469e8:     	add	x0, x9, #0x14
1002469ec:     	mov	x20, x26
1002469f0:     	mov	x26, x12
1002469f4:     	str	x11, [sp, #0x98]
1002469f8:     	bl	0x100b644e0 <_writev+0x100b644e0>
1002469fc:     	ldr	x11, [sp, #0x98]
100246a00:     	ldp	x2, x1, [sp, #0x30]
100246a04:     	mov	x12, x26
100246a08:     	mov	x26, x20
100246a0c:     	mov	x8, x21
100246a10:     	cbz	w0, 0x100246d68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x101c>
100246a14:     	cmp	x28, #0x1
100246a18:     	b.eq	0x100246d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100246a1c:     	ldr	x10, [sp, #0x108]
100246a20:     	add	x9, sp, #0x148
100246a24:     	add	x9, x9, #0x8
100246a28:     	cmp	x10, x11
100246a2c:     	b.eq	0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246a30:     	tbnz	w24, #0x0, 0x100246a74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd28>
100246a34:     	ldr	w9, [x10, #0x4]
100246a38:     	cmp	x2, x9
100246a3c:     	b.ne	0x100246a74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd28>
100246a40:     	add	x0, x10, #0x14
100246a44:     	mov	x20, x26
100246a48:     	mov	x26, x12
100246a4c:     	str	x11, [sp, #0x98]
100246a50:     	bl	0x100b644e0 <_writev+0x100b644e0>
100246a54:     	ldr	x11, [sp, #0x98]
100246a58:     	ldp	x2, x1, [sp, #0x30]
100246a5c:     	mov	x12, x26
100246a60:     	mov	x26, x20
100246a64:     	mov	x8, x21
100246a68:     	add	x9, sp, #0x148
100246a6c:     	add	x9, x9, #0x8
100246a70:     	cbz	w0, 0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246a74:     	cmp	x28, #0x2
100246a78:     	b.eq	0x100246d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100246a7c:     	ldr	x10, [sp, #0x110]
100246a80:     	add	x9, sp, #0x148
100246a84:     	add	x9, x9, #0x10
100246a88:     	cmp	x10, x11
100246a8c:     	b.eq	0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246a90:     	tbnz	w24, #0x0, 0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd88>
100246a94:     	ldr	w9, [x10, #0x4]
100246a98:     	cmp	x2, x9
100246a9c:     	b.ne	0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xd88>
100246aa0:     	add	x0, x10, #0x14
100246aa4:     	mov	x20, x26
100246aa8:     	mov	x26, x12
100246aac:     	str	x11, [sp, #0x98]
100246ab0:     	bl	0x100b644e0 <_writev+0x100b644e0>
100246ab4:     	ldr	x11, [sp, #0x98]
100246ab8:     	ldp	x2, x1, [sp, #0x30]
100246abc:     	mov	x12, x26
100246ac0:     	mov	x26, x20
100246ac4:     	mov	x8, x21
100246ac8:     	add	x9, sp, #0x148
100246acc:     	add	x9, x9, #0x10
100246ad0:     	cbz	w0, 0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246ad4:     	cmp	x28, #0x3
100246ad8:     	b.eq	0x100246d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100246adc:     	ldr	x10, [sp, #0x118]
100246ae0:     	add	x9, sp, #0x148
100246ae4:     	add	x9, x9, #0x18
100246ae8:     	cmp	x10, x11
100246aec:     	b.eq	0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246af0:     	tbnz	w24, #0x0, 0x100246b34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xde8>
100246af4:     	ldr	w9, [x10, #0x4]
100246af8:     	cmp	x2, x9
100246afc:     	b.ne	0x100246b34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xde8>
100246b00:     	add	x0, x10, #0x14
100246b04:     	mov	x20, x26
100246b08:     	mov	x26, x12
100246b0c:     	str	x11, [sp, #0x98]
100246b10:     	bl	0x100b644e0 <_writev+0x100b644e0>
100246b14:     	ldr	x11, [sp, #0x98]
100246b18:     	ldp	x2, x1, [sp, #0x30]
100246b1c:     	mov	x12, x26
100246b20:     	mov	x26, x20
100246b24:     	mov	x8, x21
100246b28:     	add	x9, sp, #0x148
100246b2c:     	add	x9, x9, #0x18
100246b30:     	cbz	w0, 0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246b34:     	cmp	x28, #0x4
100246b38:     	b.eq	0x100246d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100246b3c:     	ldr	x10, [sp, #0x120]
100246b40:     	add	x9, sp, #0x148
100246b44:     	add	x9, x9, #0x20
100246b48:     	cmp	x10, x11
100246b4c:     	b.eq	0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246b50:     	tbnz	w24, #0x0, 0x100246b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xe48>
100246b54:     	ldr	w9, [x10, #0x4]
100246b58:     	cmp	x2, x9
100246b5c:     	b.ne	0x100246b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xe48>
100246b60:     	add	x0, x10, #0x14
100246b64:     	mov	x20, x26
100246b68:     	mov	x26, x12
100246b6c:     	str	x11, [sp, #0x98]
100246b70:     	bl	0x100b644e0 <_writev+0x100b644e0>
100246b74:     	ldr	x11, [sp, #0x98]
100246b78:     	ldp	x2, x1, [sp, #0x30]
100246b7c:     	mov	x12, x26
100246b80:     	mov	x26, x20
100246b84:     	mov	x8, x21
100246b88:     	add	x9, sp, #0x148
100246b8c:     	add	x9, x9, #0x20
100246b90:     	cbz	w0, 0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246b94:     	cmp	x28, #0x5
100246b98:     	b.eq	0x100246d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100246b9c:     	ldr	x10, [sp, #0x128]
100246ba0:     	add	x9, sp, #0x148
100246ba4:     	add	x9, x9, #0x28
100246ba8:     	cmp	x10, x11
100246bac:     	b.eq	0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246bb0:     	tbnz	w24, #0x0, 0x100246bf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xea8>
100246bb4:     	ldr	w9, [x10, #0x4]
100246bb8:     	cmp	x2, x9
100246bbc:     	b.ne	0x100246bf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xea8>
100246bc0:     	add	x0, x10, #0x14
100246bc4:     	mov	x20, x26
100246bc8:     	mov	x26, x12
100246bcc:     	str	x11, [sp, #0x98]
100246bd0:     	bl	0x100b644e0 <_writev+0x100b644e0>
100246bd4:     	ldr	x11, [sp, #0x98]
100246bd8:     	ldp	x2, x1, [sp, #0x30]
100246bdc:     	mov	x12, x26
100246be0:     	mov	x26, x20
100246be4:     	mov	x8, x21
100246be8:     	add	x9, sp, #0x148
100246bec:     	add	x9, x9, #0x28
100246bf0:     	cbz	w0, 0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246bf4:     	cmp	x28, #0x6
100246bf8:     	b.eq	0x100246d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100246bfc:     	ldr	x10, [sp, #0x130]
100246c00:     	add	x9, sp, #0x148
100246c04:     	add	x9, x9, #0x30
100246c08:     	cmp	x10, x11
100246c0c:     	b.eq	0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246c10:     	tbnz	w24, #0x0, 0x100246c54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf08>
100246c14:     	ldr	w9, [x10, #0x4]
100246c18:     	cmp	x2, x9
100246c1c:     	b.ne	0x100246c54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf08>
100246c20:     	add	x0, x10, #0x14
100246c24:     	mov	x20, x26
100246c28:     	mov	x26, x12
100246c2c:     	str	x11, [sp, #0x98]
100246c30:     	bl	0x100b644e0 <_writev+0x100b644e0>
100246c34:     	ldr	x11, [sp, #0x98]
100246c38:     	ldp	x2, x1, [sp, #0x30]
100246c3c:     	mov	x12, x26
100246c40:     	mov	x26, x20
100246c44:     	mov	x8, x21
100246c48:     	add	x9, sp, #0x148
100246c4c:     	add	x9, x9, #0x30
100246c50:     	cbz	w0, 0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246c54:     	cmp	x28, #0x7
100246c58:     	b.eq	0x100246d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100246c5c:     	ldr	x10, [sp, #0x138]
100246c60:     	add	x9, sp, #0x148
100246c64:     	add	x9, x9, #0x38
100246c68:     	cmp	x10, x11
100246c6c:     	b.eq	0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246c70:     	tbnz	w24, #0x0, 0x100246cac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf60>
100246c74:     	ldr	w9, [x10, #0x4]
100246c78:     	cmp	x2, x9
100246c7c:     	b.ne	0x100246cac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xf60>
100246c80:     	add	x0, x10, #0x14
100246c84:     	mov	x24, x12
100246c88:     	mov	x20, x11
100246c8c:     	bl	0x100b644e0 <_writev+0x100b644e0>
100246c90:     	mov	x11, x20
100246c94:     	ldr	x1, [sp, #0x38]
100246c98:     	mov	x12, x24
100246c9c:     	mov	x8, x21
100246ca0:     	add	x9, sp, #0x148
100246ca4:     	add	x9, x9, #0x38
100246ca8:     	cbz	w0, 0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1020>
100246cac:     	cmp	x28, #0x8
100246cb0:     	b.ne	0x100246d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xffc>
100246cb4:     	mov	x28, x11
100246cb8:     	mov	x20, x26
100246cbc:     	mov	x26, x12
100246cc0:     	mov	w0, #0x80               ; =128
100246cc4:     	mov	w1, #0x8                ; =8
100246cc8:     	bl	0x100b618c8 <_mi_malloc_aligned>
100246ccc:     	cbz	x0, 0x1002478c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b74>
100246cd0:     	mov	x24, x0
100246cd4:     	mov	w0, #0x80               ; =128
100246cd8:     	mov	w1, #0x8                ; =8
100246cdc:     	bl	0x100b618c8 <_mi_malloc_aligned>
100246ce0:     	str	x0, [sp, #0x60]
100246ce4:     	cbz	x0, 0x1002478c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b74>
100246ce8:     	ldp	q0, q1, [sp, #0x100]
100246cec:     	stp	q0, q1, [x24]
100246cf0:     	ldp	q0, q1, [sp, #0x120]
100246cf4:     	stp	q0, q1, [x24, #0x20]
100246cf8:     	add	x9, sp, #0x148
100246cfc:     	ldp	q0, q1, [x9]
100246d00:     	ldr	x8, [sp, #0x60]
100246d04:     	stp	q0, q1, [x8]
100246d08:     	ldp	q0, q1, [x9, #0x20]
100246d0c:     	stp	q0, q1, [x8, #0x20]
100246d10:     	str	x28, [x24, #0x40]
100246d14:     	ldr	x10, [sp, #0x28]
100246d18:     	str	x10, [x8, #0x40]
100246d1c:     	mov	w10, #0x10              ; =16
100246d20:     	stp	x10, x24, [sp, #0x188]
100246d24:     	ldp	q0, q1, [sp, #0x40]
100246d28:     	str	q1, [x9, #0x50]
100246d2c:     	str	x8, [sp, #0x1a8]
100246d30:     	mov	w8, #0x9                ; =9
100246d34:     	str	x8, [sp, #0x20]
100246d38:     	mov	w28, #0x8               ; =8
100246d3c:     	stur	q0, [x9, #0x68]
100246d40:     	mov	x8, x21
100246d44:     	b	0x10024693c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xbf0>
100246d48:     	add	x9, sp, #0x100
100246d4c:     	str	x11, [x9, x28, lsl #3]
100246d50:     	add	x9, sp, #0x148
100246d54:     	ldr	x10, [sp, #0x28]
100246d58:     	str	x10, [x9, x28, lsl #3]
100246d5c:     	add	x28, x28, #0x1
100246d60:     	str	x28, [sp, #0x70]
100246d64:     	b	0x100246de4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1098>
100246d68:     	add	x9, sp, #0x148
100246d6c:     	ldr	x10, [sp, #0x28]
100246d70:     	str	x10, [x9]
100246d74:     	b	0x100246de4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1098>
100246d78:     	mov	x8, x21
100246d7c:     	mov	x12, x26
100246d80:     	mov	x26, x20
100246d84:     	ldr	x1, [sp, #0x38]
100246d88:     	ldr	x20, [sp, #0x20]
100246d8c:     	b	0x100246da0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1054>
100246d90:     	mov	x8, x21
100246d94:     	ldr	x23, [sp, #0x18]
100246d98:     	ldr	x28, [sp, #0x98]
100246d9c:     	ldr	x24, [sp]
100246da0:     	ldr	x11, [sp, #0x8]
100246da4:     	ldr	x9, [sp, #0x10]
100246da8:     	cmp	x24, x9
100246dac:     	b.eq	0x100246e98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x114c>
100246db0:     	str	x13, [x11, x24, lsl #3]
100246db4:     	add	x9, x24, #0x1
100246db8:     	str	x9, [sp, #0x198]
100246dbc:     	ldr	x9, [sp, #0x1a0]
100246dc0:     	cmp	x20, x9
100246dc4:     	b.eq	0x100246edc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1190>
100246dc8:     	ldr	x9, [sp, #0x1a8]
100246dcc:     	str	x9, [sp, #0x60]
100246dd0:     	ldr	x10, [sp, #0x28]
100246dd4:     	str	x10, [x9, x20, lsl #3]
100246dd8:     	add	x20, x20, #0x1
100246ddc:     	str	x20, [sp, #0x20]
100246de0:     	str	x20, [sp, #0x1b0]
100246de4:     	ldp	x24, x9, [x8, #0x68]
100246de8:     	cmp	x9, x24
100246dec:     	b.hs	0x100246e1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x10d0>
100246df0:     	ldr	x10, [x8, #0x60]
100246df4:     	ldrb	w11, [x10, x9]
100246df8:     	cmp	w11, #0x20
100246dfc:     	b.hi	0x100246e1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x10d0>
100246e00:     	lsr	x11, x25, x11
100246e04:     	tbz	w11, #0x0, 0x100246e1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x10d0>
100246e08:     	add	x9, x9, #0x1
100246e0c:     	str	x9, [x8, #0x70]
100246e10:     	cmp	x24, x9
100246e14:     	b.ne	0x100246df4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x10a8>
100246e18:     	b	0x1002470a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1358>
100246e1c:     	cmp	x9, x24
100246e20:     	b.hs	0x1002470a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1358>
100246e24:     	ldr	x10, [x8, #0x60]
100246e28:     	ldrb	w10, [x10, x9]
100246e2c:     	cmp	w10, #0x2c
100246e30:     	b.ne	0x1002470a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1358>
100246e34:     	str	x28, [sp, #0x98]
100246e38:     	add	x28, x9, #0x1
100246e3c:     	str	x28, [x8, #0x70]
100246e40:     	cmp	x27, #0x1
100246e44:     	ldr	x22, [sp, #0x80]
100246e48:     	ldp	w27, w9, [sp, #0x88]
100246e4c:     	b.lt	0x1002463b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x668>
100246e50:     	mov	x0, x1
100246e54:     	mov	x24, x12
100246e58:     	bl	0x100b61640 <_mi_free>
100246e5c:     	ldr	w9, [sp, #0x8c]
100246e60:     	mov	x12, x24
100246e64:     	mov	x8, x21
100246e68:     	ldp	x24, x28, [x21, #0x68]
100246e6c:     	b	0x1002463b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x668>
100246e70:     	add	x0, sp, #0x188
100246e74:     	bl	0x100b3e32c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100246e78:     	b	0x1002468f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xba8>
100246e7c:     	add	x8, sp, #0x188
100246e80:     	add	x0, x8, #0x18
100246e84:     	bl	0x100b3e32c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100246e88:     	b	0x100246918 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0xbcc>
100246e8c:     	mov	x11, x20
100246e90:     	mov	x8, x21
100246e94:     	b	0x10024664c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x900>
100246e98:     	add	x0, sp, #0x188
100246e9c:     	mov	x20, x24
100246ea0:     	mov	x24, x12
100246ea4:     	mov	x22, x13
100246ea8:     	bl	0x100b3e32c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100246eac:     	ldr	x1, [sp, #0x38]
100246eb0:     	mov	x12, x24
100246eb4:     	mov	x24, x20
100246eb8:     	mov	x8, x21
100246ebc:     	ldr	x11, [sp, #0x190]
100246ec0:     	ldr	x20, [sp, #0x1b0]
100246ec4:     	str	x22, [x11, x24, lsl #3]
100246ec8:     	add	x9, x24, #0x1
100246ecc:     	str	x9, [sp, #0x198]
100246ed0:     	ldr	x9, [sp, #0x1a0]
100246ed4:     	cmp	x20, x9
100246ed8:     	b.ne	0x100246dc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x107c>
100246edc:     	add	x8, sp, #0x188
100246ee0:     	add	x0, x8, #0x18
100246ee4:     	mov	x24, x12
100246ee8:     	bl	0x100b3e32c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100246eec:     	ldr	x1, [sp, #0x38]
100246ef0:     	mov	x12, x24
100246ef4:     	mov	x8, x21
100246ef8:     	b	0x100246dc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x107c>
100246efc:     	strb	wzr, [x8, #0xd4]
100246f00:     	cmp	x27, #0x1
100246f04:     	b.lt	0x100246f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11c8>
100246f08:     	mov	x0, x1
100246f0c:     	bl	0x100b61640 <_mi_free>
100246f10:     	mov	x8, x21
100246f14:     	ldr	x20, [sp, #0x90]
100246f18:     	ldp	x10, x9, [x8, #0x68]
100246f1c:     	cmp	x9, x10
100246f20:     	b.hs	0x100247268 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x151c>
100246f24:     	ldr	x11, [x8, #0x60]
100246f28:     	mov	x12, #0x2600            ; =9728
100246f2c:     	movk	x12, #0x1, lsl #32
100246f30:     	ldrb	w13, [x11, x9]
100246f34:     	cmp	w13, #0x20
100246f38:     	b.hi	0x100247010 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12c4>
100246f3c:     	lsr	x14, x12, x13
100246f40:     	tbz	w14, #0x0, 0x100247010 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x12c4>
100246f44:     	add	x9, x9, #0x1
100246f48:     	str	x9, [x8, #0x70]
100246f4c:     	cmp	x10, x9
100246f50:     	b.ne	0x100246f30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11e4>
100246f54:     	b	0x100247268 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x151c>
100246f58:     	mov	x8, x1
100246f5c:     	cmp	x8, x2
100246f60:     	b.hs	0x100246fd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x128c>
100246f64:     	ldrb	w10, [x12, x8]
100246f68:     	orr	w10, w10, #0x20
100246f6c:     	cmp	w10, #0x65
100246f70:     	b.ne	0x100246fd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x128c>
100246f74:     	add	x10, x8, #0x1
100246f78:     	str	x10, [x0, #0x70]
100246f7c:     	cmp	x10, x2
100246f80:     	b.hs	0x100246fa0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1254>
100246f84:     	ldrb	w11, [x12, x10]
100246f88:     	cmp	w11, #0x2d
100246f8c:     	b.eq	0x100246f98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x124c>
100246f90:     	cmp	w11, #0x2b
100246f94:     	b.ne	0x100246fa0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1254>
100246f98:     	add	x10, x8, #0x2
100246f9c:     	str	x10, [x0, #0x70]
100246fa0:     	cmp	x10, x2
100246fa4:     	b.hs	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100246fa8:     	mov	x8, x10
100246fac:     	ldrb	w11, [x12, x8]
100246fb0:     	sub	w11, w11, #0x30
100246fb4:     	cmp	w11, #0x9
100246fb8:     	b.hi	0x100246fd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1284>
100246fbc:     	add	x8, x8, #0x1
100246fc0:     	str	x8, [x0, #0x70]
100246fc4:     	cmp	x2, x8
100246fc8:     	b.ne	0x100246fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1260>
100246fcc:     	mov	x8, x2
100246fd0:     	cmp	x8, x10
100246fd4:     	b.eq	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100246fd8:     	subs	x1, x8, x19
100246fdc:     	b.lo	0x1002477b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a64>
100246fe0:     	cmp	x8, x2
100246fe4:     	b.hi	0x1002477b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a64>
100246fe8:     	mov	x20, x0
100246fec:     	add	x8, sp, #0x188
100246ff0:     	mov	x0, x9
100246ff4:     	bl	0x10003102c <__RNvXs2_NtNtCsjgY6bXVaRmE_4core3num11float_parsedNtNtNtB9_3str6traits7FromStr8from_str>
100246ff8:     	ldrb	w8, [sp, #0x188]
100246ffc:     	tbz	w8, #0x0, 0x10024709c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1350>
100247000:     	mov	x19, #0x2               ; =2
100247004:     	movk	x19, #0x7ffc, lsl #48
100247008:     	strb	wzr, [x20, #0xd4]
10024700c:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100247010:     	cmp	w13, #0x7d
100247014:     	b.ne	0x100247268 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x151c>
100247018:     	add	x9, x9, #0x1
10024701c:     	str	x9, [x8, #0x70]
100247020:     	b	0x10024726c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1520>
100247024:     	sub	x0, x29, #0x68
100247028:     	mov	x1, #0x0                ; =0
10024702c:     	bl	0x100329e1c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100247030:     	mov	x2, x1
100247034:     	mov	x1, x0
100247038:     	str	xzr, [x21, #0x78]
10024703c:     	str	x0, [x21, #0xc0]
100247040:     	str	w2, [x21, #0xd0]
100247044:     	add	x0, x21, #0x20
100247048:     	mov	w3, #0x8                ; =8
10024704c:     	mov	x4, #0x0                ; =0
100247050:     	bl	0x1005bcf48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100247054:     	ldrb	w8, [x19, #0x20]
100247058:     	cbnz	w8, 0x1002477d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a88>
10024705c:     	ldr	x8, [x19]
100247060:     	cbnz	x8, 0x100247824 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ad8>
100247064:     	ldr	x8, [x19, #0x18]
100247068:     	cmp	x23, x8
10024706c:     	b.hi	0x100247074 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1328>
100247070:     	str	x23, [x19, #0x18]
100247074:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100247078:     	bfxil	x19, x0, #0, #48
10024707c:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100247080:     	cbz	x20, 0x10024713c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x13f0>
100247084:     	cmp	x20, #0x4
100247088:     	b.hs	0x100247144 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x13f8>
10024708c:     	mov	x10, #0x0               ; =0
100247090:     	mov	x9, #0x0                ; =0
100247094:     	mov	x8, x21
100247098:     	b	0x1002471d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1488>
10024709c:     	ldr	x19, [sp, #0x190]
1002470a0:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002470a4:     	mov	x26, x12
1002470a8:     	b	0x100246f00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b4>
1002470ac:     	ldr	x22, [x24, #0x68]
1002470b0:     	sub	x9, x22, x20
1002470b4:     	cmp	x9, #0x101
1002470b8:     	mov	w9, #0xff               ; =255
1002470bc:     	ccmp	x20, x9, #0x0, lo
1002470c0:     	b.ls	0x100247214 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14c8>
1002470c4:     	ldr	x1, [x24, #0x60]
1002470c8:     	ldr	x23, [x24, #0xc8]
1002470cc:     	add	x0, x24, #0x20
1002470d0:     	mov	x2, x22
1002470d4:     	mov	x3, x23
1002470d8:     	mov	x4, x19
1002470dc:     	mov	x5, x21
1002470e0:     	mov	x6, x20
1002470e4:     	bl	0x1006c7b78 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser13source_length26string_from_dominant_token>
1002470e8:     	mov	x21, x0
1002470ec:     	b	0x10024722c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14e0>
1002470f0:     	add	x11, x1, #0x1
1002470f4:     	cmp	x11, x2
1002470f8:     	b.hs	0x10024750c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c0>
1002470fc:     	add	x16, x12, #0x1
100247100:     	mov	x15, #-0x1              ; =-1
100247104:     	ldrb	w17, [x16, x1]
100247108:     	sub	w3, w17, #0x30
10024710c:     	cmp	w3, #0x9
100247110:     	b.hi	0x1002475e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1898>
100247114:     	add	x16, x16, #0x1
100247118:     	sub	x15, x15, #0x1
10024711c:     	cmp	x8, x15
100247120:     	b.ne	0x100247104 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x13b8>
100247124:     	str	x2, [x0, #0x70]
100247128:     	mov	x8, x2
10024712c:     	subs	x16, x1, x10
100247130:     	b.eq	0x100246fd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x128c>
100247134:     	mov	x8, x2
100247138:     	b	0x100247618 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x18cc>
10024713c:     	mov	x10, #0x0               ; =0
100247140:     	b	0x1002471f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14a8>
100247144:     	and	x9, x20, #0x4
100247148:     	add	x8, x21, x9
10024714c:     	adrp	x10, 0x100c9c000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x57b0>
100247150:     	ldr	q0, [x10, #0xc0]
100247154:     	adrp	x10, 0x100c3b000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x32fba>
100247158:     	ldr	q2, [x10, #0xfc0]
10024715c:     	movi.2d	v1, #0000000000000000
100247160:     	movi.2d	v3, #0x000000000000ff
100247164:     	mov	w10, #0x4               ; =4
100247168:     	dup.2d	v4, x10
10024716c:     	mov	x10, x21
100247170:     	and	x11, x20, #0x4
100247174:     	movi.2d	v5, #0000000000000000
100247178:     	ldr	s6, [x10], #0x4
10024717c:     	ushll.8h	v6, v6, #0x0
100247180:     	ushll.4s	v6, v6, #0x0
100247184:     	ushll2.2d	v7, v6, #0x0
100247188:     	and.16b	v7, v7, v3
10024718c:     	ushll.2d	v6, v6, #0x0
100247190:     	and.16b	v6, v6, v3
100247194:     	shl.2d	v16, v0, #0x3
100247198:     	shl.2d	v17, v2, #0x3
10024719c:     	ushl.2d	v6, v6, v17
1002471a0:     	ushl.2d	v7, v7, v16
1002471a4:     	orr.16b	v1, v7, v1
1002471a8:     	orr.16b	v5, v6, v5
1002471ac:     	add.2d	v0, v0, v4
1002471b0:     	add.2d	v2, v2, v4
1002471b4:     	subs	x11, x11, #0x4
1002471b8:     	b.ne	0x100247178 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x142c>
1002471bc:     	orr.16b	v0, v5, v1
1002471c0:     	mov	d1, v0[1]
1002471c4:     	orr.8b	v0, v0, v1
1002471c8:     	fmov	x10, d0
1002471cc:     	cmp	x20, x9
1002471d0:     	b.eq	0x1002471f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x14a8>
1002471d4:     	add	x11, x21, x20
1002471d8:     	lsl	x9, x9, #3
1002471dc:     	ldrb	w12, [x8], #0x1
1002471e0:     	lsl	x12, x12, x9
1002471e4:     	orr	x10, x12, x10
1002471e8:     	add	x9, x9, #0x8
1002471ec:     	cmp	x8, x11
1002471f0:     	b.ne	0x1002471dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1490>
1002471f4:     	orr	x8, x10, x20, lsl #40
1002471f8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1002471fc:     	orr	x19, x8, x9
100247200:     	cmp	x22, #0x1
100247204:     	b.lt	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100247208:     	mov	x0, x21
10024720c:     	bl	0x100b61640 <_mi_free>
100247210:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100247214:     	add	x0, x24, #0x20
100247218:     	mov	x1, x21
10024721c:     	mov	x2, x20
100247220:     	bl	0x1005ec0c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction30string_from_scanned_json_bytes>
100247224:     	mov	x21, x0
100247228:     	ldr	x23, [x24, #0xc8]
10024722c:     	ldr	x3, [x24, #0x70]
100247230:     	mov	x0, x23
100247234:     	mov	x1, x22
100247238:     	mov	x2, x19
10024723c:     	mov	x4, x21
100247240:     	mov	x5, x20
100247244:     	bl	0x1004ed52c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21remember_parse_string>
100247248:     	mov	x19, #0x7fff000000000000 ; =9223090561878065152
10024724c:     	bfxil	x19, x21, #0, #48
100247250:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100247254:     	mov	x8, x21
100247258:     	ldp	x20, x28, [sp, #0x90]
10024725c:     	ldp	x10, x9, [x21, #0x68]
100247260:     	cmp	x9, x10
100247264:     	b.lo	0x100246f24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11d8>
100247268:     	strb	wzr, [x8, #0xd4]
10024726c:     	ldr	x27, [sp, #0x188]
100247270:     	cmn	x27, #0x1
100247274:     	b.eq	0x1002472e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x159c>
100247278:     	ldp	x0, x1, [sp, #0x190]
10024727c:     	cmp	x1, #0x9
100247280:     	b.hs	0x100247380 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1634>
100247284:     	ldr	x9, [x8, #0x78]
100247288:     	cmp	x1, x9
10024728c:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
100247290:     	ldr	x20, [x8, #0xc0]
100247294:     	cbz	x20, 0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
100247298:     	cbz	x1, 0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
10024729c:     	ldr	x9, [x8, #0x80]
1002472a0:     	ldr	x10, [x0]
1002472a4:     	cmp	x9, x10
1002472a8:     	b.eq	0x100247394 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1648>
1002472ac:     	mov	x24, x0
1002472b0:     	mov	x25, x1
1002472b4:     	bl	0x100329e1c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
1002472b8:     	mov	x20, x0
1002472bc:     	mov	x26, x1
1002472c0:     	str	x25, [x21, #0x78]
1002472c4:     	lsl	x2, x25, #3
1002472c8:     	add	x0, x21, #0x80
1002472cc:     	mov	x1, x24
1002472d0:     	bl	0x100b644ec <_writev+0x100b644ec>
1002472d4:     	mov	x2, x26
1002472d8:     	mov	x8, x21
1002472dc:     	str	x20, [x21, #0xc0]
1002472e0:     	str	w26, [x21, #0xd0]
1002472e4:     	b	0x10024744c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1700>
1002472e8:     	ldp	w9, w10, [sp, #0x88]
1002472ec:     	and	w9, w9, w10
1002472f0:     	ldr	w2, [sp, #0x7c]
1002472f4:     	tbz	w9, #0x0, 0x100247314 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15c8>
1002472f8:     	ldr	x9, [sp, #0x70]
1002472fc:     	ldr	x10, [sp, #0x80]
100247300:     	cmp	x10, x9
100247304:     	b.ne	0x100247314 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15c8>
100247308:     	ldr	x9, [sp, #0x80]
10024730c:     	cmp	x26, x9
100247310:     	b.eq	0x10024744c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1700>
100247314:     	cmp	x28, #0x9
100247318:     	b.hs	0x100247798 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a4c>
10024731c:     	ldr	x9, [x8, #0x78]
100247320:     	cmp	x28, x9
100247324:     	b.ne	0x100247344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100247328:     	ldr	x20, [x8, #0xc0]
10024732c:     	cbz	x20, 0x100247344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100247330:     	cbz	x28, 0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100247334:     	ldr	x9, [x8, #0x80]
100247338:     	ldr	x10, [sp, #0x100]
10024733c:     	cmp	x9, x10
100247340:     	b.eq	0x100247440 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16f4>
100247344:     	add	x0, sp, #0x100
100247348:     	mov	x1, x28
10024734c:     	bl	0x100329e1c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100247350:     	mov	x20, x0
100247354:     	mov	x24, x1
100247358:     	str	x28, [x21, #0x78]
10024735c:     	lsl	x2, x28, #3
100247360:     	add	x0, x21, #0x80
100247364:     	add	x1, sp, #0x100
100247368:     	bl	0x100b644ec <_writev+0x100b644ec>
10024736c:     	mov	x2, x24
100247370:     	mov	x8, x21
100247374:     	str	x20, [x21, #0xc0]
100247378:     	str	w24, [x21, #0xd0]
10024737c:     	b	0x10024744c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1700>
100247380:     	bl	0x100329e1c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100247384:     	mov	x20, x0
100247388:     	mov	x8, x21
10024738c:     	mov	x2, x1
100247390:     	b	0x10024744c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1700>
100247394:     	cmp	x1, #0x1
100247398:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
10024739c:     	ldr	x9, [x8, #0x88]
1002473a0:     	ldr	x10, [x0, #0x8]
1002473a4:     	cmp	x9, x10
1002473a8:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
1002473ac:     	cmp	x1, #0x2
1002473b0:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002473b4:     	ldr	x9, [x8, #0x90]
1002473b8:     	ldr	x10, [x0, #0x10]
1002473bc:     	cmp	x9, x10
1002473c0:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
1002473c4:     	cmp	x1, #0x3
1002473c8:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002473cc:     	ldr	x9, [x8, #0x98]
1002473d0:     	ldr	x10, [x0, #0x18]
1002473d4:     	cmp	x9, x10
1002473d8:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
1002473dc:     	cmp	x1, #0x4
1002473e0:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002473e4:     	ldr	x9, [x8, #0xa0]
1002473e8:     	ldr	x10, [x0, #0x20]
1002473ec:     	cmp	x9, x10
1002473f0:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
1002473f4:     	cmp	x1, #0x5
1002473f8:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002473fc:     	ldr	x9, [x8, #0xa8]
100247400:     	ldr	x10, [x0, #0x28]
100247404:     	cmp	x9, x10
100247408:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
10024740c:     	cmp	x1, #0x6
100247410:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100247414:     	ldr	x9, [x8, #0xb0]
100247418:     	ldr	x10, [x0, #0x30]
10024741c:     	cmp	x9, x10
100247420:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
100247424:     	cmp	x1, #0x7
100247428:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
10024742c:     	ldr	x9, [x8, #0xb8]
100247430:     	ldr	x10, [x0, #0x38]
100247434:     	cmp	x9, x10
100247438:     	b.ne	0x1002472ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1560>
10024743c:     	b	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100247440:     	cmp	x28, #0x1
100247444:     	b.ne	0x100247540 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17f4>
100247448:     	ldr	w2, [x8, #0xd0]
10024744c:     	cmp	x28, #0x9
100247450:     	b.hs	0x1002476b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x196c>
100247454:     	ldr	x9, [sp, #0x1b0]
100247458:     	cmn	x27, #0x1
10024745c:     	add	x10, sp, #0x148
100247460:     	ldr	x11, [sp, #0x60]
100247464:     	csel	x3, x10, x11, eq
100247468:     	csel	x4, x28, x9, eq
10024746c:     	add	x0, x8, #0x20
100247470:     	mov	x1, x20
100247474:     	bl	0x1005bcf48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100247478:     	ldrb	w8, [x19, #0x20]
10024747c:     	cbnz	w8, 0x100247768 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a1c>
100247480:     	ldr	x8, [x19]
100247484:     	cbnz	x8, 0x100247824 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ad8>
100247488:     	ldr	x8, [x19, #0x18]
10024748c:     	cmp	x23, x8
100247490:     	b.hi	0x100247498 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x174c>
100247494:     	str	x23, [x19, #0x18]
100247498:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
10024749c:     	bfxil	x19, x0, #0, #48
1002474a0:     	ldr	x8, [sp, #0x188]
1002474a4:     	cmn	x8, #0x1
1002474a8:     	b.eq	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002474ac:     	cbz	x8, 0x1002474b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x176c>
1002474b0:     	ldr	x0, [sp, #0x190]
1002474b4:     	bl	0x100b61640 <_mi_free>
1002474b8:     	ldr	x8, [sp, #0x1a0]
1002474bc:     	cbz	x8, 0x1002474c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x177c>
1002474c0:     	ldr	x0, [sp, #0x1a8]
1002474c4:     	bl	0x100b61640 <_mi_free>
1002474c8:     	ldr	x20, [sp, #0x1b8]
1002474cc:     	cmn	x20, #0x1
1002474d0:     	b.eq	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
1002474d4:     	ldr	x9, [sp, #0x1d8]
1002474d8:     	cbz	x9, 0x1002474fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17b0>
1002474dc:     	lsl	x8, x9, #4
1002474e0:     	add	x9, x8, x9
1002474e4:     	cmn	x9, #0x19
1002474e8:     	b.eq	0x1002474fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17b0>
1002474ec:     	ldr	x9, [sp, #0x1d0]
1002474f0:     	sub	x8, x9, x8
1002474f4:     	sub	x0, x8, #0x10
1002474f8:     	bl	0x100b61640 <_mi_free>
1002474fc:     	cbz	x20, 0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
100247500:     	ldr	x0, [sp, #0x1c0]
100247504:     	bl	0x100b61640 <_mi_free>
100247508:     	b	0x10024751c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17d0>
10024750c:     	str	x11, [x0, #0x70]
100247510:     	mov	x19, #0x2               ; =2
100247514:     	movk	x19, #0x7ffc, lsl #48
100247518:     	strb	wzr, [x0, #0xd4]
10024751c:     	mov	x0, x19
100247520:     	add	sp, sp, #0x240
100247524:     	ldp	x29, x30, [sp, #0x50]
100247528:     	ldp	x20, x19, [sp, #0x40]
10024752c:     	ldp	x22, x21, [sp, #0x30]
100247530:     	ldp	x24, x23, [sp, #0x20]
100247534:     	ldp	x26, x25, [sp, #0x10]
100247538:     	ldp	x28, x27, [sp], #0x60
10024753c:     	ret
100247540:     	ldr	x9, [x8, #0x88]
100247544:     	ldr	x10, [sp, #0x108]
100247548:     	cmp	x9, x10
10024754c:     	b.ne	0x100247344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100247550:     	cmp	x28, #0x2
100247554:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100247558:     	ldr	x9, [x8, #0x90]
10024755c:     	ldr	x10, [sp, #0x110]
100247560:     	cmp	x9, x10
100247564:     	b.ne	0x100247344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100247568:     	cmp	x28, #0x3
10024756c:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100247570:     	ldr	x9, [x8, #0x98]
100247574:     	ldr	x10, [sp, #0x118]
100247578:     	cmp	x9, x10
10024757c:     	b.ne	0x100247344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100247580:     	cmp	x28, #0x4
100247584:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
100247588:     	ldr	x9, [x8, #0xa0]
10024758c:     	ldr	x10, [sp, #0x120]
100247590:     	cmp	x9, x10
100247594:     	b.ne	0x100247344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
100247598:     	cmp	x28, #0x5
10024759c:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002475a0:     	ldr	x9, [x8, #0xa8]
1002475a4:     	ldr	x10, [sp, #0x128]
1002475a8:     	cmp	x9, x10
1002475ac:     	b.ne	0x100247344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
1002475b0:     	cmp	x28, #0x6
1002475b4:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002475b8:     	ldr	x9, [x8, #0xb0]
1002475bc:     	ldr	x10, [sp, #0x130]
1002475c0:     	cmp	x9, x10
1002475c4:     	b.ne	0x100247344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
1002475c8:     	cmp	x28, #0x7
1002475cc:     	b.eq	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002475d0:     	ldr	x9, [x8, #0xb8]
1002475d4:     	ldr	x10, [sp, #0x138]
1002475d8:     	cmp	x9, x10
1002475dc:     	b.ne	0x100247344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x15f8>
1002475e0:     	b	0x100247448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x16fc>
1002475e4:     	sub	x8, x1, x15
1002475e8:     	str	x8, [x0, #0x70]
1002475ec:     	cmp	w17, #0x65
1002475f0:     	b.ne	0x100247600 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x18b4>
1002475f4:     	cmn	x15, #0x1
1002475f8:     	b.ne	0x100246f5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
1002475fc:     	b	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100247600:     	cmn	x15, #0x1
100247604:     	b.eq	0x100247510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x17c4>
100247608:     	subs	x16, x1, x10
10024760c:     	b.eq	0x100246f5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100247610:     	cmp	w17, #0x45
100247614:     	b.eq	0x100246f5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100247618:     	sub	x15, x8, x11
10024761c:     	cmp	x15, #0x9
100247620:     	b.hi	0x100246f5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100247624:     	add	x17, x16, x15
100247628:     	cmp	x17, #0x11
10024762c:     	b.hi	0x100246f5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100247630:     	cmp	x1, x10
100247634:     	b.lo	0x10024783c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1af0>
100247638:     	mov	x10, #0x0               ; =0
10024763c:     	b.eq	0x10024765c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1910>
100247640:     	mov	w17, #0xa               ; =10
100247644:     	ldrb	w3, [x14], #0x1
100247648:     	mul	x10, x10, x17
10024764c:     	sub	w3, w3, #0x30
100247650:     	add	x10, x10, w3, uxtb
100247654:     	subs	x16, x16, #0x1
100247658:     	b.ne	0x100247644 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x18f8>
10024765c:     	cmp	x8, x1
100247660:     	b.ls	0x10024784c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b00>
100247664:     	cmp	x8, x2
100247668:     	b.hi	0x10024784c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1b00>
10024766c:     	mov	w14, #0xa               ; =10
100247670:     	ldrb	w16, [x12, x11]
100247674:     	mul	x10, x10, x14
100247678:     	sub	w16, w16, #0x30
10024767c:     	add	x10, x10, w16, uxtb
100247680:     	add	x11, x11, #0x1
100247684:     	cmp	x8, x11
100247688:     	b.ne	0x100247670 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1924>
10024768c:     	mov	x11, #0x20000000000000  ; =9007199254740992
100247690:     	cmp	x10, x11
100247694:     	b.hi	0x100246f5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1210>
100247698:     	ucvtf	d0, x10
10024769c:     	adrp	x8, 0x100c48000 <_PERRY_EMPTY_STRING+0x43f4>
1002476a0:     	add	x8, x8, #0xae8
1002476a4:     	ldr	d1, [x8, x15, lsl #3]
1002476a8:     	fdiv	d0, d0, d1
1002476ac:     	b	0x1002461d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x484>
1002476b0:     	ldr	x1, [sp, #0x38]
1002476b4:     	b	0x100246f00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x11b4>
1002476b8:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002476bc:     	add	x3, x3, #0x710
1002476c0:     	mov	x0, #0x0                ; =0
1002476c4:     	mov	x1, x28
1002476c8:     	mov	w2, #0x8                ; =8
1002476cc:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002476d0:     	cmp	w8, #0x2
1002476d4:     	b.eq	0x1002477dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a90>
1002476d8:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1L_6string6StringEEECs3gRpqoBkMHm_13perry_runtime+0x34>
1002476dc:     	add	x1, x1, #0x418
1002476e0:     	mov	x0, x19
1002476e4:     	bl	0x100a22a9c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1002476e8:     	strb	wzr, [x19, #0x20]
1002476ec:     	ldr	x8, [x19]
1002476f0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1002476f4:     	cmp	x8, x9
1002476f8:     	b.lo	0x100245e9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x150>
1002476fc:     	b	0x10024772c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x19e0>
100247700:     	cmp	w8, #0x1
100247704:     	b.ne	0x1002477dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a90>
100247708:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1L_6string6StringEEECs3gRpqoBkMHm_13perry_runtime+0x34>
10024770c:     	add	x1, x1, #0x418
100247710:     	mov	x0, x19
100247714:     	bl	0x100a22a9c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100247718:     	strb	wzr, [x19, #0x20]
10024771c:     	ldr	x8, [x19]
100247720:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100247724:     	cmp	x8, x9
100247728:     	b.lo	0x100246304 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x5b8>
10024772c:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100247730:     	add	x0, x0, #0x4a0
100247734:     	bl	0x100b14d9c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100247738:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024773c:     	add	x3, x3, #0x5c0
100247740:     	mov	x0, x19
100247744:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100247748:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024774c:     	add	x3, x3, #0x5a8
100247750:     	mov	x0, x19
100247754:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100247758:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024775c:     	add	x3, x3, #0x590
100247760:     	mov	x0, x19
100247764:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100247768:     	cmp	w8, #0x2
10024776c:     	b.eq	0x1002477dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1a90>
100247770:     	mov	x20, x0
100247774:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1L_6string6StringEEECs3gRpqoBkMHm_13perry_runtime+0x34>
100247778:     	add	x1, x1, #0x418
10024777c:     	mov	x0, x19
100247780:     	bl	0x100a22a9c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100247784:     	strb	wzr, [x19, #0x20]
100247788:     	mov	x0, x20
10024778c:     	ldr	x8, [x19]
100247790:     	cbz	x8, 0x100247488 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x173c>
100247794:     	b	0x100247824 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ad8>
100247798:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024779c:     	add	x3, x3, #0x6f8
1002477a0:     	mov	x0, #0x0                ; =0
1002477a4:     	mov	x1, x28
1002477a8:     	mov	w2, #0x8                ; =8
1002477ac:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002477b0:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002477b4:     	add	x3, x3, #0x620
1002477b8:     	mov	x0, x19
1002477bc:     	mov	x1, x8
1002477c0:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002477c4:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002477c8:     	add	x3, x3, #0x5d8
1002477cc:     	mov	x0, x10
1002477d0:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1002477d4:     	cmp	w8, #0x2
1002477d8:     	b.ne	0x100247800 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1ab4>
1002477dc:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1002477e0:     	add	x0, x0, #0xc18
1002477e4:     	bl	0x100b5ac9c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1002477e8:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002477ec:     	add	x3, x3, #0x6b0
1002477f0:     	mov	x0, #0x0                ; =0
1002477f4:     	mov	x1, x28
1002477f8:     	mov	w2, #0x8                ; =8
1002477fc:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100247800:     	mov	x20, x0
100247804:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1L_6string6StringEEECs3gRpqoBkMHm_13perry_runtime+0x34>
100247808:     	add	x1, x1, #0x418
10024780c:     	mov	x0, x19
100247810:     	bl	0x100a22a9c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100247814:     	strb	wzr, [x19, #0x20]
100247818:     	mov	x0, x20
10024781c:     	ldr	x8, [x19]
100247820:     	cbz	x8, 0x100247064 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb1_E11parse_valueB9_+0x1318>
100247824:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100247828:     	add	x0, x0, #0x488
10024782c:     	bl	0x100b14d6c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100247830:     	adrp	x0, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247834:     	add	x0, x0, #0x668
100247838:     	bl	0x100b14e30 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
10024783c:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247840:     	add	x3, x3, #0x608
100247844:     	mov	x0, x10
100247848:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
10024784c:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247850:     	add	x3, x3, #0x5f0
100247854:     	mov	x0, x11
100247858:     	mov	x1, x8
10024785c:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100247860:     	adrp	x2, 0x100ef8000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100247864:     	add	x2, x2, #0x800
100247868:     	mov	x0, x26
10024786c:     	mov	w1, #0x8                ; =8
100247870:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247874:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100247878:     	add	x2, x2, #0x6c8
10024787c:     	mov	x0, x1
100247880:     	ldr	x1, [sp, #0x20]
100247884:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247888:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024788c:     	add	x2, x2, #0x6e0
100247890:     	ldr	x1, [sp, #0x20]
100247894:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100247898:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024789c:     	add	x2, x2, #0x698
1002478a0:     	mov	x0, x12
1002478a4:     	mov	w1, #0x8                ; =8
1002478a8:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
1002478ac:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002478b0:     	add	x2, x2, #0x680
1002478b4:     	mov	x0, x12
1002478b8:     	mov	w1, #0x8                ; =8
1002478bc:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
1002478c0:     	mov	w0, #0x8                ; =8
1002478c4:     	mov	w1, #0x80               ; =128
1002478c8:     	bl	0x100b149c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
