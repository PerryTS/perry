
benchmarks/json_performance/.work/specialized-json-token-length-r37/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001002439b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_>:
1002439b8:     	sub	sp, sp, #0x60
1002439bc:     	stp	x24, x23, [sp, #0x20]
1002439c0:     	stp	x22, x21, [sp, #0x30]
1002439c4:     	stp	x20, x19, [sp, #0x40]
1002439c8:     	stp	x29, x30, [sp, #0x50]
1002439cc:     	add	x29, sp, #0x50
1002439d0:     	mov	x21, x0
1002439d4:     	ldr	x22, [x0, #0x70]
1002439d8:     	ldp	x8, x9, [x0]
1002439dc:     	cmp	x8, #0x0
1002439e0:     	ccmp	x9, x22, #0x0, ne
1002439e4:     	b.eq	0x100243a10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x58>
1002439e8:     	add	x0, sp, #0x8
1002439ec:     	mov	x1, x21
1002439f0:     	bl	0x1002433f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_>
1002439f4:     	ldr	x23, [sp, #0x8]
1002439f8:     	cmn	x23, #0x2
1002439fc:     	b.ne	0x100243a38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x80>
100243a00:     	strb	wzr, [x21, #0xd4]
100243a04:     	mov	x0, #0x2                ; =2
100243a08:     	movk	x0, #0x7ffc, lsl #48
100243a0c:     	b	0x100243a20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x68>
100243a10:     	ldp	x8, x9, [x21, #0x10]
100243a14:     	str	x8, [x21, #0x70]
100243a18:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100243a1c:     	bfxil	x0, x9, #0, #48
100243a20:     	ldp	x29, x30, [sp, #0x50]
100243a24:     	ldp	x20, x19, [sp, #0x40]
100243a28:     	ldp	x22, x21, [sp, #0x30]
100243a2c:     	ldp	x24, x23, [sp, #0x20]
100243a30:     	add	sp, sp, #0x60
100243a34:     	ret
100243a38:     	ldp	x19, x20, [sp, #0x10]
100243a3c:     	cmp	x20, #0x6
100243a40:     	b.hs	0x100243ad0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x118>
100243a44:     	subs	x8, x20, #0x3
100243a48:     	b.lo	0x100243afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x144>
100243a4c:     	ldrb	w9, [x19]
100243a50:     	cmp	w9, #0xed
100243a54:     	b.ne	0x100243a74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0xbc>
100243a58:     	ldrb	w9, [x19, #0x1]
100243a5c:     	and	w9, w9, #0xe0
100243a60:     	cmp	w9, #0xa0
100243a64:     	b.ne	0x100243a74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0xbc>
100243a68:     	ldrsb	w9, [x19, #0x2]
100243a6c:     	cmn	w9, #0x40
100243a70:     	b.lt	0x100243ad0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x118>
100243a74:     	cbz	x8, 0x100243afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x144>
100243a78:     	ldrb	w9, [x19, #0x1]
100243a7c:     	cmp	w9, #0xed
100243a80:     	b.ne	0x100243aa0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0xe8>
100243a84:     	ldrb	w9, [x19, #0x2]
100243a88:     	and	w9, w9, #0xe0
100243a8c:     	cmp	w9, #0xa0
100243a90:     	b.ne	0x100243aa0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0xe8>
100243a94:     	ldrsb	w9, [x19, #0x3]
100243a98:     	cmn	w9, #0x40
100243a9c:     	b.lt	0x100243ad0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x118>
100243aa0:     	cmp	x8, #0x1
100243aa4:     	b.eq	0x100243afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x144>
100243aa8:     	ldrb	w8, [x19, #0x2]
100243aac:     	cmp	w8, #0xed
100243ab0:     	b.ne	0x100243afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x144>
100243ab4:     	ldrb	w8, [x19, #0x3]
100243ab8:     	and	w8, w8, #0xe0
100243abc:     	cmp	w8, #0xa0
100243ac0:     	b.ne	0x100243afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x144>
100243ac4:     	ldrsb	w8, [x19, #0x4]
100243ac8:     	cmn	w8, #0x40
100243acc:     	b.ge	0x100243afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x144>
100243ad0:     	cmn	x23, #0x1
100243ad4:     	b.eq	0x100243b18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x160>
100243ad8:     	mov	x0, x19
100243adc:     	mov	x1, x20
100243ae0:     	bl	0x10034bcf0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
100243ae4:     	mov	x8, x0
100243ae8:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100243aec:     	bfxil	x0, x8, #0, #48
100243af0:     	cmp	x23, #0x1
100243af4:     	b.ge	0x100243c1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x264>
100243af8:     	b	0x100243a20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x68>
100243afc:     	cbz	x20, 0x100243b50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x198>
100243b00:     	cmp	x20, #0x4
100243b04:     	b.hs	0x100243b58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x1a0>
100243b08:     	mov	x10, #0x0               ; =0
100243b0c:     	mov	x9, #0x0                ; =0
100243b10:     	mov	x8, x19
100243b14:     	b	0x100243be8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x230>
100243b18:     	add	x0, x21, #0x20
100243b1c:     	mov	x1, x19
100243b20:     	mov	x2, x20
100243b24:     	bl	0x1005ec0c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction30string_from_scanned_json_bytes>
100243b28:     	mov	x19, x0
100243b2c:     	ldr	x0, [x21, #0xc8]
100243b30:     	ldp	x1, x3, [x21, #0x68]
100243b34:     	mov	x2, x22
100243b38:     	mov	x4, x19
100243b3c:     	mov	x5, x20
100243b40:     	bl	0x1004ed52c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21remember_parse_string>
100243b44:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100243b48:     	bfxil	x0, x19, #0, #48
100243b4c:     	b	0x100243a20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x68>
100243b50:     	mov	x10, #0x0               ; =0
100243b54:     	b	0x100243c08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x250>
100243b58:     	and	x9, x20, #0x4
100243b5c:     	add	x8, x19, x9
100243b60:     	adrp	x10, 0x100c9c000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x57b0>
100243b64:     	ldr	q0, [x10, #0xc0]
100243b68:     	adrp	x10, 0x100c3b000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x32fba>
100243b6c:     	ldr	q2, [x10, #0xfc0]
100243b70:     	movi.2d	v1, #0000000000000000
100243b74:     	movi.2d	v3, #0x000000000000ff
100243b78:     	mov	w10, #0x4               ; =4
100243b7c:     	dup.2d	v4, x10
100243b80:     	mov	x10, x19
100243b84:     	and	x11, x20, #0x4
100243b88:     	movi.2d	v5, #0000000000000000
100243b8c:     	ldr	s6, [x10], #0x4
100243b90:     	ushll.8h	v6, v6, #0x0
100243b94:     	ushll.4s	v6, v6, #0x0
100243b98:     	ushll2.2d	v7, v6, #0x0
100243b9c:     	and.16b	v7, v7, v3
100243ba0:     	ushll.2d	v6, v6, #0x0
100243ba4:     	and.16b	v6, v6, v3
100243ba8:     	shl.2d	v16, v0, #0x3
100243bac:     	shl.2d	v17, v2, #0x3
100243bb0:     	ushl.2d	v6, v6, v17
100243bb4:     	ushl.2d	v7, v7, v16
100243bb8:     	orr.16b	v1, v7, v1
100243bbc:     	orr.16b	v5, v6, v5
100243bc0:     	add.2d	v0, v0, v4
100243bc4:     	add.2d	v2, v2, v4
100243bc8:     	subs	x11, x11, #0x4
100243bcc:     	b.ne	0x100243b8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x1d4>
100243bd0:     	orr.16b	v0, v5, v1
100243bd4:     	mov	d1, v0[1]
100243bd8:     	orr.8b	v0, v0, v1
100243bdc:     	fmov	x10, d0
100243be0:     	cmp	x20, x9
100243be4:     	b.eq	0x100243c08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x250>
100243be8:     	add	x11, x19, x20
100243bec:     	lsl	x9, x9, #3
100243bf0:     	ldrb	w12, [x8], #0x1
100243bf4:     	lsl	x12, x12, x9
100243bf8:     	orr	x10, x12, x10
100243bfc:     	add	x9, x9, #0x8
100243c00:     	cmp	x8, x11
100243c04:     	b.ne	0x100243bf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x238>
100243c08:     	orr	x8, x10, x20, lsl #40
100243c0c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100243c10:     	orr	x0, x8, x9
100243c14:     	cmp	x23, #0x1
100243c18:     	b.lt	0x100243a20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x68>
100243c1c:     	mov	x20, x0
100243c20:     	mov	x0, x19
100243c24:     	bl	0x100b61640 <_mi_free>
100243c28:     	mov	x0, x20
100243c2c:     	b	0x100243a20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_valueB9_+0x68>
		...
