
benchmarks/json_performance/.work/specialized-json-token-length-r37/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100243c44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_>:
100243c44:     	stp	x28, x27, [sp, #-0x60]!
100243c48:     	stp	x26, x25, [sp, #0x10]
100243c4c:     	stp	x24, x23, [sp, #0x20]
100243c50:     	stp	x22, x21, [sp, #0x30]
100243c54:     	stp	x20, x19, [sp, #0x40]
100243c58:     	stp	x29, x30, [sp, #0x50]
100243c5c:     	add	x29, sp, #0x50
100243c60:     	sub	sp, sp, #0x250
100243c64:     	mov	x19, x0
100243c68:     	ldp	x8, x9, [x0, #0x68]
100243c6c:     	add	x9, x9, #0x1
100243c70:     	str	x9, [x0, #0x70]
100243c74:     	cmp	x9, x8
100243c78:     	b.hs	0x100243cac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x68>
100243c7c:     	ldr	x10, [x19, #0x60]
100243c80:     	mov	x11, #0x2600            ; =9728
100243c84:     	movk	x11, #0x1, lsl #32
100243c88:     	ldrb	w12, [x10, x9]
100243c8c:     	cmp	w12, #0x20
100243c90:     	b.hi	0x100243cac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x68>
100243c94:     	lsr	x12, x11, x12
100243c98:     	tbz	w12, #0x0, 0x100243cac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x68>
100243c9c:     	add	x9, x9, #0x1
100243ca0:     	str	x9, [x19, #0x70]
100243ca4:     	cmp	x8, x9
100243ca8:     	b.ne	0x100243c88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x44>
100243cac:     	ldrb	w8, [x19, #0xd5]
100243cb0:     	tbz	w8, #0x0, 0x100243cdc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x98>
100243cb4:     	strb	wzr, [x19, #0xd5]
100243cb8:     	ldr	x22, [x19, #0x78]
100243cbc:     	ldp	q0, q1, [x19, #0x80]
100243cc0:     	stur	q0, [sp, #0xb8]
100243cc4:     	stur	q1, [sp, #0xc8]
100243cc8:     	ldp	q0, q1, [x19, #0xa0]
100243ccc:     	stur	q0, [sp, #0xd8]
100243cd0:     	stur	q1, [sp, #0xe8]
100243cd4:     	ldr	x21, [x19, #0xc0]
100243cd8:     	b	0x100243d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc8>
100243cdc:     	mov	w26, #0x0               ; =0
100243ce0:     	mov	x8, #0x0                ; =0
100243ce4:     	ldr	x22, [x19, #0x78]
100243ce8:     	cbz	x22, 0x100244a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xde0>
100243cec:     	ldr	x21, [x19, #0xc0]
100243cf0:     	cbz	x21, 0x100243d24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe0>
100243cf4:     	ldp	q0, q1, [x19, #0x80]
100243cf8:     	stur	q0, [sp, #0xb8]
100243cfc:     	stur	q1, [sp, #0xc8]
100243d00:     	ldp	q0, q1, [x19, #0xa0]
100243d04:     	stur	q0, [sp, #0xd8]
100243d08:     	stur	q1, [sp, #0xe8]
100243d0c:     	ldr	w8, [x19, #0xd0]
100243d10:     	stp	x22, x21, [sp, #0xf8]
100243d14:     	str	w8, [sp, #0x84]
100243d18:     	str	w8, [sp, #0x108]
100243d1c:     	mov	w8, #0x1                ; =1
100243d20:     	mov	w26, #0x1               ; =1
100243d24:     	str	x8, [sp, #0xb0]
100243d28:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100243d2c:     	add	x0, x0, #0xce8
100243d30:     	ldr	x8, [x0]
100243d34:     	blr	x8
100243d38:     	mov	x20, x0
100243d3c:     	ldrb	w8, [x0, #0x20]
100243d40:     	cbnz	w8, 0x100244d94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1150>
100243d44:     	ldr	x8, [x20]
100243d48:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100243d4c:     	cmp	x8, x9
100243d50:     	b.hs	0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x117c>
100243d54:     	ldr	x27, [x20, #0x18]
100243d58:     	ldp	x23, x28, [x19, #0x68]
100243d5c:     	cmp	x28, x23
100243d60:     	b.hs	0x100243d94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x150>
100243d64:     	ldr	x8, [x19, #0x60]
100243d68:     	ldrb	w8, [x8, x28]
100243d6c:     	cmp	w8, #0x7d
100243d70:     	b.ne	0x100243d94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x150>
100243d74:     	add	x8, x28, #0x1
100243d78:     	str	x8, [x19, #0x70]
100243d7c:     	ldr	x8, [x19, #0x78]
100243d80:     	cbnz	x8, 0x100244a28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xde4>
100243d84:     	ldr	x1, [x19, #0xc0]
100243d88:     	cbz	x1, 0x100244a28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xde4>
100243d8c:     	ldr	w2, [x19, #0xd0]
100243d90:     	b	0x100244a48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe04>
100243d94:     	movi.2d	v0, #0000000000000000
100243d98:     	stp	q0, q0, [sp, #0x130]
100243d9c:     	stp	q0, q0, [sp, #0x110]
100243da0:     	adrp	x1, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x77b0>
100243da4:     	add	x1, x1, #0x330
100243da8:     	add	x0, sp, #0x158
100243dac:     	mov	w2, #0x40               ; =64
100243db0:     	bl	0x100b64510 <_writev+0x100b64510>
100243db4:     	mov	x24, #0x0               ; =0
100243db8:     	str	xzr, [sp, #0xa0]
100243dbc:     	mov	x8, #-0x1               ; =-1
100243dc0:     	str	x8, [sp, #0x198]
100243dc4:     	add	x8, sp, #0xb0
100243dc8:     	add	x8, x8, #0x8
100243dcc:     	stp	x8, xzr, [sp, #0x88]
100243dd0:     	mov	x25, #0x2600            ; =9728
100243dd4:     	movk	x25, #0x1, lsl #32
100243dd8:     	adrp	x8, 0x100c9c000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x57b0>
100243ddc:     	ldr	q0, [x8, #0xd0]
100243de0:     	str	q0, [sp, #0x60]
100243de4:     	adrp	x8, 0x100c9c000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x57b0>
100243de8:     	ldr	q0, [x8, #0xe0]
100243dec:     	str	q0, [sp, #0x50]
100243df0:     	mov	x11, x26
100243df4:     	mov	x8, x26
100243df8:     	str	x21, [sp, #0x78]
100243dfc:     	str	w26, [sp, #0x9c]
100243e00:     	str	w8, [sp, #0x98]
100243e04:     	cmp	x28, x23
100243e08:     	b.hs	0x100243e38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1f4>
100243e0c:     	ldr	x8, [x19, #0x60]
100243e10:     	ldrb	w9, [x8, x28]
100243e14:     	cmp	w9, #0x20
100243e18:     	b.hi	0x100243e38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1f4>
100243e1c:     	lsr	x9, x25, x9
100243e20:     	tbz	w9, #0x0, 0x100243e38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1f4>
100243e24:     	add	x28, x28, #0x1
100243e28:     	str	x28, [x19, #0x70]
100243e2c:     	cmp	x23, x28
100243e30:     	b.ne	0x100243e10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1cc>
100243e34:     	mov	x28, x23
100243e38:     	str	x24, [sp, #0xa8]
100243e3c:     	cbz	w26, 0x100243ef8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b4>
100243e40:     	cmp	x24, x22
100243e44:     	cset	w8, lo
100243e48:     	tst	w11, w8
100243e4c:     	b.eq	0x100243ef8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b4>
100243e50:     	cmp	x24, #0x8
100243e54:     	b.hs	0x100244e68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1224>
100243e58:     	mov	x26, x11
100243e5c:     	cmp	x28, x23
100243e60:     	b.hs	0x100243efc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100243e64:     	ldr	x8, [sp, #0x88]
100243e68:     	ldr	x9, [x8, x24, lsl #3]
100243e6c:     	cbz	x9, 0x100243efc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100243e70:     	ldr	x10, [x19, #0x60]
100243e74:     	ldrb	w8, [x10, x28]
100243e78:     	cmp	w8, #0x22
100243e7c:     	b.ne	0x100243efc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100243e80:     	add	x11, x28, #0x1
100243e84:     	ldr	w14, [x9, #0x4]
100243e88:     	add	x8, x11, x14
100243e8c:     	cmp	x8, x23
100243e90:     	ccmp	x8, x28, #0x0, lo
100243e94:     	b.ls	0x100243efc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100243e98:     	ldrb	w12, [x10, x8]
100243e9c:     	cmp	w12, #0x22
100243ea0:     	b.ne	0x100243efc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100243ea4:     	add	x23, x10, x11
100243ea8:     	cbz	w14, 0x100243ee4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2a0>
100243eac:     	add	x9, x9, #0x14
100243eb0:     	mov	x10, x14
100243eb4:     	mov	x11, x23
100243eb8:     	ldrb	w12, [x11], #0x1
100243ebc:     	cmp	w12, #0x5c
100243ec0:     	b.eq	0x100243efc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100243ec4:     	cmp	w12, #0x22
100243ec8:     	b.eq	0x100243efc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100243ecc:     	ldrb	w13, [x9], #0x1
100243ed0:     	cmp	w12, #0x20
100243ed4:     	ccmp	w12, w13, #0x0, hs
100243ed8:     	b.ne	0x100243efc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2b8>
100243edc:     	subs	x10, x10, #0x1
100243ee0:     	b.ne	0x100243eb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x274>
100243ee4:     	add	x8, x8, #0x1
100243ee8:     	str	x8, [x19, #0x70]
100243eec:     	mov	w28, #0x1               ; =1
100243ef0:     	mov	x24, #-0x1              ; =-1
100243ef4:     	b	0x100243f1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2d8>
100243ef8:     	mov	x26, x11
100243efc:     	sub	x0, x29, #0x80
100243f00:     	mov	x1, x19
100243f04:     	bl	0x1002433f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E18parse_string_bytesB9_>
100243f08:     	ldur	x24, [x29, #-0x80]
100243f0c:     	cmn	x24, #0x2
100243f10:     	b.eq	0x100244a90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe4c>
100243f14:     	mov	w28, #0x0               ; =0
100243f18:     	ldp	x23, x14, [x29, #-0x78]
100243f1c:     	ldp	x9, x8, [x19, #0x68]
100243f20:     	cmp	x8, x9
100243f24:     	b.hs	0x100244900 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcbc>
100243f28:     	ldr	x10, [x19, #0x60]
100243f2c:     	ldrb	w11, [x10, x8]
100243f30:     	cmp	w11, #0x3a
100243f34:     	b.hi	0x100244900 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcbc>
100243f38:     	lsr	x12, x25, x11
100243f3c:     	tbz	w12, #0x0, 0x100243f54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x310>
100243f40:     	add	x8, x8, #0x1
100243f44:     	str	x8, [x19, #0x70]
100243f48:     	cmp	x9, x8
100243f4c:     	b.ne	0x100243f2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x2e8>
100243f50:     	b	0x100244900 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcbc>
100243f54:     	cmp	x11, #0x3a
100243f58:     	b.ne	0x100244900 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcbc>
100243f5c:     	str	x14, [sp, #0x48]
100243f60:     	add	x8, x8, #0x1
100243f64:     	str	x8, [x19, #0x70]
100243f68:     	mov	x0, x19
100243f6c:     	bl	0x100242348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E11parse_valueB9_>
100243f70:     	ldrb	w8, [x19, #0xd4]
100243f74:     	tbz	w8, #0x0, 0x100244904 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcc0>
100243f78:     	ldr	x9, [sp, #0x198]
100243f7c:     	cmn	x9, #0x1
100243f80:     	stp	x0, x23, [sp, #0x38]
100243f84:     	ldr	x17, [sp, #0x48]
100243f88:     	b.eq	0x10024404c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x408>
100243f8c:     	ldr	x8, [sp, #0x1c8]
100243f90:     	ldr	x28, [sp, #0x1a8]
100243f94:     	cmn	x8, #0x1
100243f98:     	b.eq	0x10024409c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x458>
100243f9c:     	ldr	x11, [sp, #0x208]
100243fa0:     	ldr	x8, [sp, #0x200]
100243fa4:     	ldr	x10, [sp, #0x210]
100243fa8:     	ldr	x9, [sp, #0x218]
100243fac:     	eor	x11, x11, x17
100243fb0:     	mov	x13, #0x7f2d            ; =32557
100243fb4:     	movk	x13, #0x4c95, lsl #16
100243fb8:     	movk	x13, #0xf42d, lsl #32
100243fbc:     	movk	x13, #0x5851, lsl #48
100243fc0:     	mul	x12, x11, x13
100243fc4:     	umulh	x11, x11, x13
100243fc8:     	eor	x11, x11, x12
100243fcc:     	add	x11, x17, x11
100243fd0:     	mul	x11, x11, x13
100243fd4:     	cmp	x17, #0x8
100243fd8:     	str	x28, [sp, #0x28]
100243fdc:     	b.ls	0x1002440f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x4ac>
100243fe0:     	cmp	x17, #0x10
100243fe4:     	b.ls	0x100244198 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x554>
100243fe8:     	add	x12, x23, x17
100243fec:     	ldp	x12, x13, [x12, #-0x10]
100243ff0:     	eor	x12, x10, x12
100243ff4:     	eor	x13, x13, x9
100243ff8:     	mul	x14, x13, x12
100243ffc:     	umulh	x12, x13, x12
100244000:     	eor	x12, x12, x14
100244004:     	add	x11, x11, x8
100244008:     	eor	x11, x11, x12
10024400c:     	ror	x11, x11, #0x29
100244010:     	mov	x13, x23
100244014:     	mov	x12, x17
100244018:     	ldp	x15, x14, [x13], #0x10
10024401c:     	sub	x12, x12, #0x10
100244020:     	eor	x15, x10, x15
100244024:     	eor	x14, x14, x9
100244028:     	mul	x16, x14, x15
10024402c:     	umulh	x14, x14, x15
100244030:     	eor	x14, x14, x16
100244034:     	add	x11, x11, x8
100244038:     	eor	x11, x11, x14
10024403c:     	ror	x11, x11, #0x29
100244040:     	cmp	x12, #0x10
100244044:     	b.hi	0x100244018 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x3d4>
100244048:     	b	0x100244274 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x630>
10024404c:     	ldr	w8, [sp, #0x98]
100244050:     	tbz	w8, #0x0, 0x100244110 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x4cc>
100244054:     	ldr	w8, [sp, #0x9c]
100244058:     	tbz	w8, #0x0, 0x100244e5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1218>
10024405c:     	ldr	x8, [sp, #0xa8]
100244060:     	cmp	x8, x22
100244064:     	mov	x11, x26
100244068:     	ldr	w26, [sp, #0x9c]
10024406c:     	b.hs	0x1002443b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x76c>
100244070:     	tbz	w28, #0x0, 0x10024436c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x728>
100244074:     	ldr	x0, [sp, #0xa8]
100244078:     	cmp	x0, #0x7
10024407c:     	ldr	x9, [sp, #0x30]
100244080:     	b.hi	0x100244ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x125c>
100244084:     	ldr	x8, [sp, #0x88]
100244088:     	ldr	x10, [x8, x0, lsl #3]
10024408c:     	add	x0, x0, #0x1
100244090:     	str	x0, [sp, #0xa8]
100244094:     	mov	w8, #0x1                ; =1
100244098:     	b	0x1002443cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x788>
10024409c:     	str	x9, [sp, #0x10]
1002440a0:     	ldr	x1, [sp, #0x1a0]
1002440a4:     	cmp	x28, #0x80
1002440a8:     	b.ne	0x100244130 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x4ec>
1002440ac:     	mov	w8, #0x1                ; =1
1002440b0:     	strb	w8, [x19, #0xd6]
1002440b4:     	add	x8, sp, #0x198
1002440b8:     	add	x0, x8, #0x30
1002440bc:     	mov	x21, x1
1002440c0:     	bl	0x10028909c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex9from_keys>
1002440c4:     	ldr	x17, [sp, #0x48]
1002440c8:     	ldr	x8, [sp, #0x1c8]
1002440cc:     	cmn	x8, #0x1
1002440d0:     	b.ne	0x100243f9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x358>
1002440d4:     	mov	x0, x23
1002440d8:     	mov	x1, x17
1002440dc:     	bl	0x10032873c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
1002440e0:     	mov	x23, x0
1002440e4:     	add	x13, x21, #0x400
1002440e8:     	mov	x10, x21
1002440ec:     	b	0x100244150 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x50c>
1002440f0:     	cmp	x17, #0x1
1002440f4:     	b.ls	0x1002441a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x564>
1002440f8:     	add	x13, x23, x17
1002440fc:     	cmp	x17, #0x3
100244100:     	b.ls	0x100244240 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x5fc>
100244104:     	ldr	w12, [x23]
100244108:     	ldur	w13, [x13, #-0x4]
10024410c:     	b	0x100244254 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x610>
100244110:     	mov	x0, x23
100244114:     	mov	x1, x17
100244118:     	bl	0x10032873c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
10024411c:     	mov	x10, x0
100244120:     	mov	w8, #0x0                ; =0
100244124:     	mov	x11, x26
100244128:     	ldr	w26, [sp, #0x9c]
10024412c:     	b	0x1002443c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x784>
100244130:     	str	x1, [sp, #0x8]
100244134:     	mov	x0, x23
100244138:     	mov	x1, x17
10024413c:     	bl	0x10032873c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100244140:     	mov	x23, x0
100244144:     	cbz	x28, 0x100244794 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb50>
100244148:     	ldr	x10, [sp, #0x8]
10024414c:     	add	x13, x10, x28, lsl #3
100244150:     	ldr	x8, [sp, #0xa8]
100244154:     	cmp	x8, #0x0
100244158:     	cset	w8, eq
10024415c:     	ldr	w9, [sp, #0x98]
100244160:     	orr	w8, w8, w9
100244164:     	tbz	w8, #0x0, 0x1002441b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x574>
100244168:     	mov	x0, #0x0                ; =0
10024416c:     	mov	x8, x10
100244170:     	mov	x11, x26
100244174:     	ldr	w26, [sp, #0x9c]
100244178:     	ldr	x9, [x8], #0x8
10024417c:     	cmp	x9, x23
100244180:     	b.eq	0x100244224 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x5e0>
100244184:     	add	x0, x0, #0x1
100244188:     	cmp	x8, x13
10024418c:     	b.ne	0x100244178 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x534>
100244190:     	ldr	x9, [sp, #0x30]
100244194:     	b	0x1002447b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb74>
100244198:     	ldr	x12, [x23]
10024419c:     	add	x13, x23, x17
1002441a0:     	ldur	x13, [x13, #-0x8]
1002441a4:     	b	0x100244254 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x610>
1002441a8:     	b.ne	0x10024424c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x608>
1002441ac:     	ldrb	w12, [x23]
1002441b0:     	mov	x13, x12
1002441b4:     	b	0x100244254 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x610>
1002441b8:     	str	x28, [sp, #0x28]
1002441bc:     	str	x27, [sp, #0x18]
1002441c0:     	mov	x28, #0x0               ; =0
1002441c4:     	str	x10, [sp, #0x8]
1002441c8:     	mov	x27, x10
1002441cc:     	ldr	x2, [sp, #0x48]
1002441d0:     	b	0x1002441e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x59c>
1002441d4:     	sub	x28, x28, #0x1
1002441d8:     	cmp	x27, x13
1002441dc:     	b.eq	0x1002447a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb60>
1002441e0:     	ldr	x8, [x27], #0x8
1002441e4:     	cmp	x8, x23
1002441e8:     	b.eq	0x100244214 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x5d0>
1002441ec:     	ldr	w9, [x8, #0x4]
1002441f0:     	cmp	x2, x9
1002441f4:     	b.ne	0x1002441d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x590>
1002441f8:     	add	x0, x8, #0x14
1002441fc:     	ldr	x1, [sp, #0x40]
100244200:     	mov	x21, x13
100244204:     	bl	0x100b644e0 <_writev+0x100b644e0>
100244208:     	mov	x13, x21
10024420c:     	ldr	x2, [sp, #0x48]
100244210:     	cbnz	w0, 0x1002441d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x590>
100244214:     	neg	x0, x28
100244218:     	ldr	x27, [sp, #0x18]
10024421c:     	mov	x11, x26
100244220:     	ldr	w26, [sp, #0x9c]
100244224:     	ldr	x9, [sp, #0x30]
100244228:     	cmp	x0, x9
10024422c:     	b.hs	0x100244e90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x124c>
100244230:     	ldr	x8, [sp, #0x20]
100244234:     	ldr	x10, [sp, #0x38]
100244238:     	str	x10, [x8, x0, lsl #3]
10024423c:     	b	0x1002447f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
100244240:     	ldrh	w12, [x23]
100244244:     	ldurb	w13, [x13, #-0x1]
100244248:     	b	0x100244254 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x610>
10024424c:     	mov	x12, #0x0               ; =0
100244250:     	mov	x13, #0x0               ; =0
100244254:     	eor	x10, x12, x10
100244258:     	eor	x9, x13, x9
10024425c:     	mul	x12, x9, x10
100244260:     	umulh	x9, x9, x10
100244264:     	eor	x9, x9, x12
100244268:     	add	x10, x11, x8
10024426c:     	eor	x9, x10, x9
100244270:     	ror	x11, x9, #0x29
100244274:     	mul	x9, x11, x8
100244278:     	umulh	x8, x11, x8
10024427c:     	eor	x8, x8, x9
100244280:     	neg	w9, w11
100244284:     	ror	x28, x8, x9
100244288:     	ldr	x4, [sp, #0x1a0]
10024428c:     	add	x8, sp, #0x198
100244290:     	add	x0, x8, #0x30
100244294:     	mov	x1, x28
100244298:     	mov	x2, x23
10024429c:     	mov	x3, x17
1002442a0:     	ldr	x5, [sp, #0x28]
1002442a4:     	bl	0x100288ccc <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11find_hashed>
1002442a8:     	tbz	w0, #0x0, 0x1002442d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x68c>
1002442ac:     	ldr	x9, [sp, #0x30]
1002442b0:     	cmp	x1, x9
1002442b4:     	b.hs	0x100244e7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1238>
1002442b8:     	mov	x11, x26
1002442bc:     	ldr	x8, [sp, #0x20]
1002442c0:     	ldr	x10, [sp, #0x38]
1002442c4:     	str	x10, [x8, x1, lsl #3]
1002442c8:     	ldr	w26, [sp, #0x9c]
1002442cc:     	b	0x1002447f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
1002442d0:     	str	x27, [sp, #0x18]
1002442d4:     	cmn	x24, #0x1
1002442d8:     	b.eq	0x1002442ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x6a8>
1002442dc:     	mov	x0, x23
1002442e0:     	ldr	x1, [sp, #0x48]
1002442e4:     	bl	0x10034bcf0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
1002442e8:     	b	0x1002442fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x6b8>
1002442ec:     	add	x0, x19, #0x20
1002442f0:     	mov	x1, x23
1002442f4:     	ldr	x2, [sp, #0x48]
1002442f8:     	bl	0x1005eb684 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
1002442fc:     	mov	x27, x0
100244300:     	add	x8, sp, #0x198
100244304:     	add	x0, x8, #0x30
100244308:     	mov	x1, x28
10024430c:     	ldr	x2, [sp, #0x28]
100244310:     	bl	0x100288ea0 <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
100244314:     	ldr	x23, [sp, #0x1a8]
100244318:     	ldr	x8, [sp, #0x198]
10024431c:     	cmp	x23, x8
100244320:     	b.eq	0x100244884 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc40>
100244324:     	ldr	x8, [sp, #0x1a0]
100244328:     	ldr	x9, [sp, #0x1b0]
10024432c:     	str	x27, [x8, x23, lsl #3]
100244330:     	add	x8, x23, #0x1
100244334:     	str	x8, [sp, #0x1a8]
100244338:     	ldr	x23, [sp, #0x1c0]
10024433c:     	cmp	x23, x9
100244340:     	b.eq	0x100244890 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc4c>
100244344:     	ldr	x8, [sp, #0x1b8]
100244348:     	str	x8, [sp, #0x20]
10024434c:     	ldr	x9, [sp, #0x38]
100244350:     	str	x9, [x8, x23, lsl #3]
100244354:     	add	x9, x23, #0x1
100244358:     	str	x9, [sp, #0x1c0]
10024435c:     	ldr	x27, [sp, #0x18]
100244360:     	mov	x11, x26
100244364:     	ldr	w26, [sp, #0x9c]
100244368:     	b	0x1002447f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
10024436c:     	ldr	x0, [sp, #0xa8]
100244370:     	cmp	x0, #0x8
100244374:     	b.hs	0x100244eb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x126c>
100244378:     	ldr	x8, [sp, #0x88]
10024437c:     	ldr	x9, [x8, x0, lsl #3]
100244380:     	ldr	w8, [x9, #0x4]
100244384:     	cmp	x17, x8
100244388:     	b.ne	0x1002443b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x76c>
10024438c:     	add	x0, x9, #0x14
100244390:     	mov	x1, x23
100244394:     	mov	x2, x17
100244398:     	mov	x23, x11
10024439c:     	mov	x28, x9
1002443a0:     	bl	0x100b644e0 <_writev+0x100b644e0>
1002443a4:     	mov	x11, x23
1002443a8:     	ldp	x23, x17, [sp, #0x40]
1002443ac:     	cbz	w0, 0x1002448a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc5c>
1002443b0:     	mov	x0, x23
1002443b4:     	mov	x1, x17
1002443b8:     	bl	0x10032873c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
1002443bc:     	mov	x10, x0
1002443c0:     	mov	w11, #0x0               ; =0
1002443c4:     	mov	w8, #0x0                ; =0
1002443c8:     	ldr	x9, [sp, #0x30]
1002443cc:     	ldp	x1, x12, [sp, #0xa0]
1002443d0:     	cmp	x12, #0x0
1002443d4:     	str	w8, [sp, #0x98]
1002443d8:     	csinc	w28, w8, wzr, ne
1002443dc:     	cmp	x1, #0x9
1002443e0:     	b.hs	0x100244e20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11dc>
1002443e4:     	ldr	x2, [sp, #0x48]
1002443e8:     	cbz	x1, 0x100244760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
1002443ec:     	ldr	x8, [sp, #0x110]
1002443f0:     	cmp	x8, x10
1002443f4:     	b.eq	0x100244784 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb40>
1002443f8:     	tbnz	w28, #0x0, 0x100244430 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7ec>
1002443fc:     	ldr	w9, [x8, #0x4]
100244400:     	cmp	x2, x9
100244404:     	ldr	x9, [sp, #0x30]
100244408:     	b.ne	0x100244430 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x7ec>
10024440c:     	add	x0, x8, #0x14
100244410:     	mov	x1, x23
100244414:     	mov	x23, x11
100244418:     	str	x10, [sp, #0x28]
10024441c:     	bl	0x100b644e0 <_writev+0x100b644e0>
100244420:     	ldp	x10, x9, [sp, #0x28]
100244424:     	mov	x11, x23
100244428:     	ldp	x23, x2, [sp, #0x40]
10024442c:     	cbz	w0, 0x100244784 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb40>
100244430:     	ldr	x1, [sp, #0xa0]
100244434:     	cmp	x1, #0x1
100244438:     	b.eq	0x100244760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
10024443c:     	ldr	x9, [sp, #0x118]
100244440:     	add	x8, sp, #0x158
100244444:     	add	x8, x8, #0x8
100244448:     	cmp	x9, x10
10024444c:     	b.eq	0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100244450:     	tbnz	w28, #0x0, 0x10024448c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x848>
100244454:     	ldr	w8, [x9, #0x4]
100244458:     	cmp	x2, x8
10024445c:     	b.ne	0x10024448c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x848>
100244460:     	add	x0, x9, #0x14
100244464:     	mov	x1, x23
100244468:     	mov	x23, x11
10024446c:     	str	x10, [sp, #0x28]
100244470:     	bl	0x100b644e0 <_writev+0x100b644e0>
100244474:     	ldr	x10, [sp, #0x28]
100244478:     	mov	x11, x23
10024447c:     	ldp	x23, x2, [sp, #0x40]
100244480:     	add	x8, sp, #0x158
100244484:     	add	x8, x8, #0x8
100244488:     	cbz	w0, 0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
10024448c:     	ldr	x1, [sp, #0xa0]
100244490:     	cmp	x1, #0x2
100244494:     	ldr	x9, [sp, #0x30]
100244498:     	b.eq	0x100244760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
10024449c:     	ldr	x9, [sp, #0x120]
1002444a0:     	add	x8, sp, #0x158
1002444a4:     	add	x8, x8, #0x10
1002444a8:     	cmp	x9, x10
1002444ac:     	b.eq	0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
1002444b0:     	tbnz	w28, #0x0, 0x1002444ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x8a8>
1002444b4:     	ldr	w8, [x9, #0x4]
1002444b8:     	cmp	x2, x8
1002444bc:     	b.ne	0x1002444ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x8a8>
1002444c0:     	add	x0, x9, #0x14
1002444c4:     	mov	x1, x23
1002444c8:     	mov	x23, x11
1002444cc:     	str	x10, [sp, #0x28]
1002444d0:     	bl	0x100b644e0 <_writev+0x100b644e0>
1002444d4:     	ldr	x10, [sp, #0x28]
1002444d8:     	mov	x11, x23
1002444dc:     	ldp	x23, x2, [sp, #0x40]
1002444e0:     	add	x8, sp, #0x158
1002444e4:     	add	x8, x8, #0x10
1002444e8:     	cbz	w0, 0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
1002444ec:     	ldr	x1, [sp, #0xa0]
1002444f0:     	cmp	x1, #0x3
1002444f4:     	ldr	x9, [sp, #0x30]
1002444f8:     	b.eq	0x100244760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
1002444fc:     	ldr	x9, [sp, #0x128]
100244500:     	add	x8, sp, #0x158
100244504:     	add	x8, x8, #0x18
100244508:     	cmp	x9, x10
10024450c:     	b.eq	0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100244510:     	tbnz	w28, #0x0, 0x10024454c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x908>
100244514:     	ldr	w8, [x9, #0x4]
100244518:     	cmp	x2, x8
10024451c:     	b.ne	0x10024454c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x908>
100244520:     	add	x0, x9, #0x14
100244524:     	mov	x1, x23
100244528:     	mov	x23, x11
10024452c:     	str	x10, [sp, #0x28]
100244530:     	bl	0x100b644e0 <_writev+0x100b644e0>
100244534:     	ldr	x10, [sp, #0x28]
100244538:     	mov	x11, x23
10024453c:     	ldp	x23, x2, [sp, #0x40]
100244540:     	add	x8, sp, #0x158
100244544:     	add	x8, x8, #0x18
100244548:     	cbz	w0, 0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
10024454c:     	ldr	x1, [sp, #0xa0]
100244550:     	cmp	x1, #0x4
100244554:     	ldr	x9, [sp, #0x30]
100244558:     	b.eq	0x100244760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
10024455c:     	ldr	x9, [sp, #0x130]
100244560:     	add	x8, sp, #0x158
100244564:     	add	x8, x8, #0x20
100244568:     	cmp	x9, x10
10024456c:     	b.eq	0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100244570:     	tbnz	w28, #0x0, 0x1002445ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x968>
100244574:     	ldr	w8, [x9, #0x4]
100244578:     	cmp	x2, x8
10024457c:     	b.ne	0x1002445ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x968>
100244580:     	add	x0, x9, #0x14
100244584:     	mov	x1, x23
100244588:     	mov	x23, x11
10024458c:     	str	x10, [sp, #0x28]
100244590:     	bl	0x100b644e0 <_writev+0x100b644e0>
100244594:     	ldr	x10, [sp, #0x28]
100244598:     	mov	x11, x23
10024459c:     	ldp	x23, x2, [sp, #0x40]
1002445a0:     	add	x8, sp, #0x158
1002445a4:     	add	x8, x8, #0x20
1002445a8:     	cbz	w0, 0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
1002445ac:     	ldr	x1, [sp, #0xa0]
1002445b0:     	cmp	x1, #0x5
1002445b4:     	ldr	x9, [sp, #0x30]
1002445b8:     	b.eq	0x100244760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
1002445bc:     	ldr	x9, [sp, #0x138]
1002445c0:     	add	x8, sp, #0x158
1002445c4:     	add	x8, x8, #0x28
1002445c8:     	cmp	x9, x10
1002445cc:     	b.eq	0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
1002445d0:     	tbnz	w28, #0x0, 0x10024460c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x9c8>
1002445d4:     	ldr	w8, [x9, #0x4]
1002445d8:     	cmp	x2, x8
1002445dc:     	b.ne	0x10024460c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x9c8>
1002445e0:     	add	x0, x9, #0x14
1002445e4:     	mov	x1, x23
1002445e8:     	mov	x23, x11
1002445ec:     	str	x10, [sp, #0x28]
1002445f0:     	bl	0x100b644e0 <_writev+0x100b644e0>
1002445f4:     	ldr	x10, [sp, #0x28]
1002445f8:     	mov	x11, x23
1002445fc:     	ldp	x23, x2, [sp, #0x40]
100244600:     	add	x8, sp, #0x158
100244604:     	add	x8, x8, #0x28
100244608:     	cbz	w0, 0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
10024460c:     	ldr	x1, [sp, #0xa0]
100244610:     	cmp	x1, #0x6
100244614:     	ldr	x9, [sp, #0x30]
100244618:     	b.eq	0x100244760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
10024461c:     	ldr	x9, [sp, #0x140]
100244620:     	add	x8, sp, #0x158
100244624:     	add	x8, x8, #0x30
100244628:     	cmp	x9, x10
10024462c:     	b.eq	0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100244630:     	tbnz	w28, #0x0, 0x10024466c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa28>
100244634:     	ldr	w8, [x9, #0x4]
100244638:     	cmp	x2, x8
10024463c:     	b.ne	0x10024466c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa28>
100244640:     	add	x0, x9, #0x14
100244644:     	mov	x1, x23
100244648:     	mov	x23, x11
10024464c:     	str	x10, [sp, #0x28]
100244650:     	bl	0x100b644e0 <_writev+0x100b644e0>
100244654:     	ldr	x10, [sp, #0x28]
100244658:     	mov	x11, x23
10024465c:     	ldp	x23, x2, [sp, #0x40]
100244660:     	add	x8, sp, #0x158
100244664:     	add	x8, x8, #0x30
100244668:     	cbz	w0, 0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
10024466c:     	ldr	x1, [sp, #0xa0]
100244670:     	cmp	x1, #0x7
100244674:     	ldr	x9, [sp, #0x30]
100244678:     	b.eq	0x100244760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
10024467c:     	ldr	x9, [sp, #0x148]
100244680:     	add	x8, sp, #0x158
100244684:     	add	x8, x8, #0x38
100244688:     	cmp	x9, x10
10024468c:     	b.eq	0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
100244690:     	tbnz	w28, #0x0, 0x1002446c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa84>
100244694:     	ldr	w8, [x9, #0x4]
100244698:     	cmp	x2, x8
10024469c:     	b.ne	0x1002446c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xa84>
1002446a0:     	add	x0, x9, #0x14
1002446a4:     	mov	x1, x23
1002446a8:     	mov	x23, x11
1002446ac:     	mov	x28, x10
1002446b0:     	bl	0x100b644e0 <_writev+0x100b644e0>
1002446b4:     	mov	x10, x28
1002446b8:     	mov	x11, x23
1002446bc:     	add	x8, sp, #0x158
1002446c0:     	add	x8, x8, #0x38
1002446c4:     	cbz	w0, 0x100244788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb44>
1002446c8:     	ldr	x1, [sp, #0xa0]
1002446cc:     	cmp	x1, #0x8
1002446d0:     	ldr	x9, [sp, #0x30]
1002446d4:     	b.ne	0x100244760 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb1c>
1002446d8:     	mov	x28, x10
1002446dc:     	mov	x26, x11
1002446e0:     	mov	w0, #0x80               ; =128
1002446e4:     	bl	0x100b618c8 <_mi_malloc_aligned>
1002446e8:     	cbz	x0, 0x100244ec0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x127c>
1002446ec:     	mov	x23, x0
1002446f0:     	mov	w0, #0x80               ; =128
1002446f4:     	mov	w1, #0x8                ; =8
1002446f8:     	bl	0x100b618c8 <_mi_malloc_aligned>
1002446fc:     	str	x0, [sp, #0x20]
100244700:     	cbz	x0, 0x100244ec0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x127c>
100244704:     	ldp	q0, q1, [sp, #0x110]
100244708:     	stp	q0, q1, [x23]
10024470c:     	ldp	q0, q1, [sp, #0x130]
100244710:     	stp	q0, q1, [x23, #0x20]
100244714:     	add	x9, sp, #0x158
100244718:     	ldp	q0, q1, [x9]
10024471c:     	ldr	x10, [sp, #0x20]
100244720:     	stp	q0, q1, [x10]
100244724:     	ldp	q0, q1, [x9, #0x20]
100244728:     	stp	q0, q1, [x10, #0x20]
10024472c:     	str	x28, [x23, #0x40]
100244730:     	ldr	x8, [sp, #0x38]
100244734:     	str	x8, [x10, #0x40]
100244738:     	mov	w8, #0x10               ; =16
10024473c:     	stp	x8, x23, [sp, #0x198]
100244740:     	ldp	q0, q1, [sp, #0x50]
100244744:     	str	q1, [x9, #0x50]
100244748:     	str	x10, [sp, #0x1b8]
10024474c:     	mov	w8, #0x8                ; =8
100244750:     	str	x8, [sp, #0xa0]
100244754:     	stur	q0, [x9, #0x68]
100244758:     	mov	w9, #0x9                ; =9
10024475c:     	b	0x100244360 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x71c>
100244760:     	add	x8, sp, #0x110
100244764:     	str	x10, [x8, x1, lsl #3]
100244768:     	add	x8, sp, #0x158
10024476c:     	ldr	x10, [sp, #0x38]
100244770:     	str	x10, [x8, x1, lsl #3]
100244774:     	add	x8, x1, #0x1
100244778:     	str	x8, [sp, #0x90]
10024477c:     	str	x8, [sp, #0xa0]
100244780:     	b	0x1002447f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
100244784:     	add	x8, sp, #0x158
100244788:     	ldp	x9, x10, [sp, #0x30]
10024478c:     	str	x10, [x8]
100244790:     	b	0x1002447f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbb0>
100244794:     	mov	x11, x26
100244798:     	ldr	w26, [sp, #0x9c]
10024479c:     	ldr	x9, [sp, #0x30]
1002447a0:     	b	0x1002447b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb70>
1002447a4:     	ldr	x27, [sp, #0x18]
1002447a8:     	mov	x11, x26
1002447ac:     	ldr	w26, [sp, #0x9c]
1002447b0:     	ldp	x28, x9, [sp, #0x28]
1002447b4:     	ldr	x10, [sp, #0x8]
1002447b8:     	ldr	x8, [sp, #0x10]
1002447bc:     	cmp	x28, x8
1002447c0:     	b.eq	0x1002448b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc6c>
1002447c4:     	str	x23, [x10, x28, lsl #3]
1002447c8:     	add	x8, x28, #0x1
1002447cc:     	str	x8, [sp, #0x1a8]
1002447d0:     	ldr	x8, [sp, #0x1b0]
1002447d4:     	cmp	x9, x8
1002447d8:     	b.eq	0x1002448e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xc9c>
1002447dc:     	ldr	x8, [sp, #0x1b8]
1002447e0:     	str	x8, [sp, #0x20]
1002447e4:     	ldr	x10, [sp, #0x38]
1002447e8:     	str	x10, [x8, x9, lsl #3]
1002447ec:     	add	x9, x9, #0x1
1002447f0:     	str	x9, [sp, #0x1c0]
1002447f4:     	ldp	x23, x8, [x19, #0x68]
1002447f8:     	cmp	x8, x23
1002447fc:     	b.hs	0x100244834 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbf0>
100244800:     	mov	x12, x9
100244804:     	ldr	x9, [x19, #0x60]
100244808:     	ldrb	w10, [x9, x8]
10024480c:     	cmp	w10, #0x20
100244810:     	b.hi	0x100244830 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbec>
100244814:     	lsr	x10, x25, x10
100244818:     	tbz	w10, #0x0, 0x100244830 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbec>
10024481c:     	add	x8, x8, #0x1
100244820:     	str	x8, [x19, #0x70]
100244824:     	cmp	x23, x8
100244828:     	b.ne	0x100244808 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xbc4>
10024482c:     	b	0x100244a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe3c>
100244830:     	mov	x9, x12
100244834:     	cmp	x8, x23
100244838:     	b.hs	0x100244a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe3c>
10024483c:     	str	x9, [sp, #0x30]
100244840:     	ldr	x9, [x19, #0x60]
100244844:     	ldrb	w9, [x9, x8]
100244848:     	cmp	w9, #0x2c
10024484c:     	b.ne	0x100244a80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe3c>
100244850:     	add	x28, x8, #0x1
100244854:     	str	x28, [x19, #0x70]
100244858:     	cmp	x24, #0x1
10024485c:     	ldr	x24, [sp, #0xa8]
100244860:     	ldr	w8, [sp, #0x98]
100244864:     	b.lt	0x100243e00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1bc>
100244868:     	ldr	x0, [sp, #0x40]
10024486c:     	mov	x23, x11
100244870:     	bl	0x100b61640 <_mi_free>
100244874:     	mov	x11, x23
100244878:     	ldr	w8, [sp, #0x98]
10024487c:     	ldp	x23, x28, [x19, #0x68]
100244880:     	b	0x100243e00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1bc>
100244884:     	add	x0, sp, #0x198
100244888:     	bl	0x100b3e32c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10024488c:     	b	0x100244324 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x6e0>
100244890:     	add	x8, sp, #0x198
100244894:     	add	x0, x8, #0x18
100244898:     	bl	0x100b3e32c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10024489c:     	b	0x100244344 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x700>
1002448a0:     	mov	x10, x28
1002448a4:     	ldr	x0, [sp, #0xa8]
1002448a8:     	ldr	x9, [sp, #0x30]
1002448ac:     	b	0x10024408c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x448>
1002448b0:     	add	x0, sp, #0x198
1002448b4:     	str	w11, [sp, #0x48]
1002448b8:     	bl	0x100b3e32c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1002448bc:     	ldr	w11, [sp, #0x48]
1002448c0:     	ldr	x10, [sp, #0x1a0]
1002448c4:     	ldr	x9, [sp, #0x1c0]
1002448c8:     	str	x23, [x10, x28, lsl #3]
1002448cc:     	add	x8, x28, #0x1
1002448d0:     	str	x8, [sp, #0x1a8]
1002448d4:     	ldr	x8, [sp, #0x1b0]
1002448d8:     	cmp	x9, x8
1002448dc:     	b.ne	0x1002447dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb98>
1002448e0:     	add	x8, sp, #0x198
1002448e4:     	add	x0, x8, #0x18
1002448e8:     	mov	x23, x11
1002448ec:     	mov	x28, x9
1002448f0:     	bl	0x100b3e32c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1002448f4:     	mov	x9, x28
1002448f8:     	mov	x11, x23
1002448fc:     	b	0x1002447dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xb98>
100244900:     	strb	wzr, [x19, #0xd4]
100244904:     	ldr	w26, [sp, #0x9c]
100244908:     	cmp	x24, #0x1
10024490c:     	b.lt	0x100244918 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcd4>
100244910:     	mov	x0, x23
100244914:     	bl	0x100b61640 <_mi_free>
100244918:     	ldr	x21, [sp, #0xa8]
10024491c:     	ldp	x9, x8, [x19, #0x68]
100244920:     	cmp	x8, x9
100244924:     	b.hs	0x100244aa4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe60>
100244928:     	ldr	x10, [x19, #0x60]
10024492c:     	mov	x11, #0x2600            ; =9728
100244930:     	movk	x11, #0x1, lsl #32
100244934:     	ldrb	w12, [x10, x8]
100244938:     	cmp	w12, #0x20
10024493c:     	b.hi	0x10024495c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd18>
100244940:     	lsr	x13, x11, x12
100244944:     	tbz	w13, #0x0, 0x10024495c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd18>
100244948:     	add	x8, x8, #0x1
10024494c:     	str	x8, [x19, #0x70]
100244950:     	cmp	x9, x8
100244954:     	b.ne	0x100244934 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcf0>
100244958:     	b	0x100244aa4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe60>
10024495c:     	cmp	w12, #0x7d
100244960:     	b.ne	0x100244aa4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe60>
100244964:     	add	x8, x8, #0x1
100244968:     	str	x8, [x19, #0x70]
10024496c:     	ldr	x8, [sp, #0x198]
100244970:     	cmn	x8, #0x1
100244974:     	b.ne	0x100244ab4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe70>
100244978:     	ldr	w8, [sp, #0x98]
10024497c:     	and	w8, w26, w8
100244980:     	tbz	w8, #0x0, 0x1002449b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd70>
100244984:     	ldr	x8, [sp, #0x90]
100244988:     	cmp	x22, x8
10024498c:     	b.ne	0x1002449b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd70>
100244990:     	cmp	x21, x22
100244994:     	b.ne	0x1002449b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd70>
100244998:     	ldr	x22, [sp, #0xa0]
10024499c:     	cmp	x22, #0x9
1002449a0:     	ldr	w2, [sp, #0x84]
1002449a4:     	ldr	x21, [sp, #0x78]
1002449a8:     	b.hs	0x100244b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xee4>
1002449ac:     	add	x3, sp, #0x158
1002449b0:     	b	0x100244b5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf18>
1002449b4:     	ldr	x22, [sp, #0xa0]
1002449b8:     	cmp	x22, #0x9
1002449bc:     	b.hs	0x100244df4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11b0>
1002449c0:     	ldr	x8, [x19, #0x78]
1002449c4:     	cmp	x22, x8
1002449c8:     	b.ne	0x1002449e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
1002449cc:     	ldr	x21, [x19, #0xc0]
1002449d0:     	cbz	x21, 0x1002449e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
1002449d4:     	cbz	x22, 0x100244c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
1002449d8:     	ldr	x8, [x19, #0x80]
1002449dc:     	ldr	x9, [sp, #0x110]
1002449e0:     	cmp	x8, x9
1002449e4:     	b.eq	0x100244c38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xff4>
1002449e8:     	add	x0, sp, #0x110
1002449ec:     	mov	x1, x22
1002449f0:     	bl	0x100329e1c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
1002449f4:     	mov	x21, x0
1002449f8:     	mov	x23, x1
1002449fc:     	str	x22, [x19, #0x78]
100244a00:     	lsl	x2, x22, #3
100244a04:     	add	x0, x19, #0x80
100244a08:     	add	x1, sp, #0x110
100244a0c:     	bl	0x100b644ec <_writev+0x100b644ec>
100244a10:     	mov	x2, x23
100244a14:     	str	x21, [x19, #0xc0]
100244a18:     	str	w23, [x19, #0xd0]
100244a1c:     	add	x3, sp, #0x158
100244a20:     	b	0x100244b5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf18>
100244a24:     	b	0x100243d24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe0>
100244a28:     	sub	x0, x29, #0x68
100244a2c:     	mov	x1, #0x0                ; =0
100244a30:     	bl	0x100329e1c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100244a34:     	mov	x2, x1
100244a38:     	mov	x1, x0
100244a3c:     	str	xzr, [x19, #0x78]
100244a40:     	str	x0, [x19, #0xc0]
100244a44:     	str	w2, [x19, #0xd0]
100244a48:     	add	x0, x19, #0x20
100244a4c:     	mov	w3, #0x8                ; =8
100244a50:     	mov	x4, #0x0                ; =0
100244a54:     	bl	0x1005bcf48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100244a58:     	mov	x19, x0
100244a5c:     	ldrb	w8, [x20, #0x20]
100244a60:     	cbnz	w8, 0x100244e0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11c8>
100244a64:     	ldr	x8, [x20]
100244a68:     	cbnz	x8, 0x100244e50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x120c>
100244a6c:     	ldr	x8, [x20, #0x18]
100244a70:     	cmp	x27, x8
100244a74:     	b.hi	0x100244bf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
100244a78:     	str	x27, [x20, #0x18]
100244a7c:     	b	0x100244bf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
100244a80:     	ldr	x23, [sp, #0x40]
100244a84:     	cmp	x24, #0x1
100244a88:     	b.ge	0x100244910 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xccc>
100244a8c:     	b	0x100244918 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xcd4>
100244a90:     	ldr	x21, [sp, #0xa8]
100244a94:     	ldr	w26, [sp, #0x9c]
100244a98:     	ldp	x9, x8, [x19, #0x68]
100244a9c:     	cmp	x8, x9
100244aa0:     	b.lo	0x100244928 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xce4>
100244aa4:     	strb	wzr, [x19, #0xd4]
100244aa8:     	ldr	x8, [sp, #0x198]
100244aac:     	cmn	x8, #0x1
100244ab0:     	b.eq	0x100244978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xd34>
100244ab4:     	ldp	x0, x1, [sp, #0x1a0]
100244ab8:     	cmp	x1, #0x9
100244abc:     	b.hs	0x100244b40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xefc>
100244ac0:     	ldr	x8, [x19, #0x78]
100244ac4:     	cmp	x1, x8
100244ac8:     	ldr	x22, [sp, #0xa0]
100244acc:     	b.ne	0x100244aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100244ad0:     	ldr	x21, [x19, #0xc0]
100244ad4:     	cbz	x21, 0x100244aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100244ad8:     	cbz	x1, 0x100244c28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
100244adc:     	ldr	x8, [x19, #0x80]
100244ae0:     	ldr	x9, [x0]
100244ae4:     	cmp	x8, x9
100244ae8:     	b.eq	0x100244c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfdc>
100244aec:     	mov	x24, x0
100244af0:     	mov	x25, x1
100244af4:     	bl	0x100329e1c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100244af8:     	mov	x21, x0
100244afc:     	mov	x23, x1
100244b00:     	str	x25, [x19, #0x78]
100244b04:     	lsl	x2, x25, #3
100244b08:     	add	x0, x19, #0x80
100244b0c:     	mov	x1, x24
100244b10:     	bl	0x100b644ec <_writev+0x100b644ec>
100244b14:     	mov	x2, x23
100244b18:     	str	x21, [x19, #0xc0]
100244b1c:     	str	w23, [x19, #0xd0]
100244b20:     	cmp	x22, #0x9
100244b24:     	b.lo	0x100244b58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf14>
100244b28:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244b2c:     	add	x3, x3, #0x710
100244b30:     	mov	x0, #0x0                ; =0
100244b34:     	mov	x1, x22
100244b38:     	mov	w2, #0x8                ; =8
100244b3c:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100244b40:     	bl	0x100329e1c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100244b44:     	mov	x21, x0
100244b48:     	mov	x2, x1
100244b4c:     	ldr	x22, [sp, #0xa0]
100244b50:     	cmp	x22, #0x9
100244b54:     	b.hs	0x100244b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xee4>
100244b58:     	ldp	x3, x22, [sp, #0x1b8]
100244b5c:     	add	x0, x19, #0x20
100244b60:     	mov	x1, x21
100244b64:     	mov	x4, x22
100244b68:     	bl	0x1005bcf48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100244b6c:     	mov	x19, x0
100244b70:     	ldrb	w8, [x20, #0x20]
100244b74:     	cbnz	w8, 0x100244dcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1188>
100244b78:     	ldr	x8, [x20]
100244b7c:     	cbnz	x8, 0x100244e50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x120c>
100244b80:     	ldr	x8, [x20, #0x18]
100244b84:     	cmp	x27, x8
100244b88:     	b.hi	0x100244b90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf4c>
100244b8c:     	str	x27, [x20, #0x18]
100244b90:     	ldr	x8, [sp, #0x198]
100244b94:     	cmn	x8, #0x1
100244b98:     	b.eq	0x100244bf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
100244b9c:     	cbz	x8, 0x100244ba8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf64>
100244ba0:     	ldr	x0, [sp, #0x1a0]
100244ba4:     	bl	0x100b61640 <_mi_free>
100244ba8:     	ldr	x8, [sp, #0x1b0]
100244bac:     	cbz	x8, 0x100244bb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf74>
100244bb0:     	ldr	x0, [sp, #0x1b8]
100244bb4:     	bl	0x100b61640 <_mi_free>
100244bb8:     	ldr	x20, [sp, #0x1c8]
100244bbc:     	cmn	x20, #0x1
100244bc0:     	b.eq	0x100244bf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
100244bc4:     	ldr	x9, [sp, #0x1e8]
100244bc8:     	cbz	x9, 0x100244bec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfa8>
100244bcc:     	lsl	x8, x9, #4
100244bd0:     	add	x9, x8, x9
100244bd4:     	cmn	x9, #0x19
100244bd8:     	b.eq	0x100244bec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfa8>
100244bdc:     	ldr	x9, [sp, #0x1e0]
100244be0:     	sub	x8, x9, x8
100244be4:     	sub	x0, x8, #0x10
100244be8:     	bl	0x100b61640 <_mi_free>
100244bec:     	cbz	x20, 0x100244bf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfb4>
100244bf0:     	ldr	x0, [sp, #0x1d0]
100244bf4:     	bl	0x100b61640 <_mi_free>
100244bf8:     	mov	x0, #0x7ffd000000000000 ; =9222527611924643840
100244bfc:     	bfxil	x0, x19, #0, #48
100244c00:     	add	sp, sp, #0x250
100244c04:     	ldp	x29, x30, [sp, #0x50]
100244c08:     	ldp	x20, x19, [sp, #0x40]
100244c0c:     	ldp	x22, x21, [sp, #0x30]
100244c10:     	ldp	x24, x23, [sp, #0x20]
100244c14:     	ldp	x26, x25, [sp, #0x10]
100244c18:     	ldp	x28, x27, [sp], #0x60
100244c1c:     	ret
100244c20:     	cmp	x1, #0x1
100244c24:     	b.ne	0x100244c4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x1008>
100244c28:     	ldr	w2, [x19, #0xd0]
100244c2c:     	cmp	x22, #0x9
100244c30:     	b.lo	0x100244b58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf14>
100244c34:     	b	0x100244b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xee4>
100244c38:     	cmp	x22, #0x1
100244c3c:     	b.ne	0x100244cf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x10ac>
100244c40:     	ldr	w2, [x19, #0xd0]
100244c44:     	add	x3, sp, #0x158
100244c48:     	b	0x100244b5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf18>
100244c4c:     	ldr	x8, [x19, #0x88]
100244c50:     	ldr	x9, [x0, #0x8]
100244c54:     	cmp	x8, x9
100244c58:     	b.ne	0x100244aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100244c5c:     	cmp	x1, #0x2
100244c60:     	b.eq	0x100244c28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
100244c64:     	ldr	x8, [x19, #0x90]
100244c68:     	ldr	x9, [x0, #0x10]
100244c6c:     	cmp	x8, x9
100244c70:     	b.ne	0x100244aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100244c74:     	cmp	x1, #0x3
100244c78:     	b.eq	0x100244c28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
100244c7c:     	ldr	x8, [x19, #0x98]
100244c80:     	ldr	x9, [x0, #0x18]
100244c84:     	cmp	x8, x9
100244c88:     	b.ne	0x100244aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100244c8c:     	cmp	x1, #0x4
100244c90:     	b.eq	0x100244c28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
100244c94:     	ldr	x8, [x19, #0xa0]
100244c98:     	ldr	x9, [x0, #0x20]
100244c9c:     	cmp	x8, x9
100244ca0:     	b.ne	0x100244aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100244ca4:     	cmp	x1, #0x5
100244ca8:     	b.eq	0x100244c28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
100244cac:     	ldr	x8, [x19, #0xa8]
100244cb0:     	ldr	x9, [x0, #0x28]
100244cb4:     	cmp	x8, x9
100244cb8:     	b.ne	0x100244aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100244cbc:     	cmp	x1, #0x6
100244cc0:     	b.eq	0x100244c28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
100244cc4:     	ldr	x8, [x19, #0xb0]
100244cc8:     	ldr	x9, [x0, #0x30]
100244ccc:     	cmp	x8, x9
100244cd0:     	b.ne	0x100244aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100244cd4:     	cmp	x1, #0x7
100244cd8:     	b.eq	0x100244c28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
100244cdc:     	ldr	x8, [x19, #0xb8]
100244ce0:     	ldr	x9, [x0, #0x38]
100244ce4:     	cmp	x8, x9
100244ce8:     	b.ne	0x100244aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xea8>
100244cec:     	b	0x100244c28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xfe4>
100244cf0:     	ldr	x8, [x19, #0x88]
100244cf4:     	ldr	x9, [sp, #0x118]
100244cf8:     	cmp	x8, x9
100244cfc:     	b.ne	0x1002449e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100244d00:     	cmp	x22, #0x2
100244d04:     	b.eq	0x100244c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
100244d08:     	ldr	x8, [x19, #0x90]
100244d0c:     	ldr	x9, [sp, #0x120]
100244d10:     	cmp	x8, x9
100244d14:     	b.ne	0x1002449e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100244d18:     	cmp	x22, #0x3
100244d1c:     	b.eq	0x100244c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
100244d20:     	ldr	x8, [x19, #0x98]
100244d24:     	ldr	x9, [sp, #0x128]
100244d28:     	cmp	x8, x9
100244d2c:     	b.ne	0x1002449e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100244d30:     	cmp	x22, #0x4
100244d34:     	b.eq	0x100244c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
100244d38:     	ldr	x8, [x19, #0xa0]
100244d3c:     	ldr	x9, [sp, #0x130]
100244d40:     	cmp	x8, x9
100244d44:     	b.ne	0x1002449e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100244d48:     	cmp	x22, #0x5
100244d4c:     	b.eq	0x100244c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
100244d50:     	ldr	x8, [x19, #0xa8]
100244d54:     	ldr	x9, [sp, #0x138]
100244d58:     	cmp	x8, x9
100244d5c:     	b.ne	0x1002449e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100244d60:     	cmp	x22, #0x6
100244d64:     	b.eq	0x100244c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
100244d68:     	ldr	x8, [x19, #0xb0]
100244d6c:     	ldr	x9, [sp, #0x140]
100244d70:     	cmp	x8, x9
100244d74:     	b.ne	0x1002449e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100244d78:     	cmp	x22, #0x7
100244d7c:     	b.eq	0x100244c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
100244d80:     	ldr	x8, [x19, #0xb8]
100244d84:     	ldr	x9, [sp, #0x148]
100244d88:     	cmp	x8, x9
100244d8c:     	b.ne	0x1002449e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xda4>
100244d90:     	b	0x100244c40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xffc>
100244d94:     	cmp	w8, #0x1
100244d98:     	b.ne	0x100244e14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11d0>
100244d9c:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1L_6string6StringEEECs3gRpqoBkMHm_13perry_runtime+0x34>
100244da0:     	add	x1, x1, #0x418
100244da4:     	mov	x0, x20
100244da8:     	bl	0x100a22a9c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100244dac:     	strb	wzr, [x20, #0x20]
100244db0:     	ldr	x8, [x20]
100244db4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100244db8:     	cmp	x8, x9
100244dbc:     	b.lo	0x100243d54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x110>
100244dc0:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100244dc4:     	add	x0, x0, #0x4a0
100244dc8:     	bl	0x100b14d9c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100244dcc:     	cmp	w8, #0x2
100244dd0:     	b.eq	0x100244e14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11d0>
100244dd4:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1L_6string6StringEEECs3gRpqoBkMHm_13perry_runtime+0x34>
100244dd8:     	add	x1, x1, #0x418
100244ddc:     	mov	x0, x20
100244de0:     	bl	0x100a22a9c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100244de4:     	strb	wzr, [x20, #0x20]
100244de8:     	ldr	x8, [x20]
100244dec:     	cbz	x8, 0x100244b80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xf3c>
100244df0:     	b	0x100244e50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x120c>
100244df4:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244df8:     	add	x3, x3, #0x6f8
100244dfc:     	mov	x0, #0x0                ; =0
100244e00:     	mov	x1, x22
100244e04:     	mov	w2, #0x8                ; =8
100244e08:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100244e0c:     	cmp	w8, #0x2
100244e10:     	b.ne	0x100244e34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0x11f0>
100244e14:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100244e18:     	add	x0, x0, #0xc18
100244e1c:     	bl	0x100b5ac9c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100244e20:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244e24:     	add	x3, x3, #0x6b0
100244e28:     	mov	x0, #0x0                ; =0
100244e2c:     	mov	w2, #0x8                ; =8
100244e30:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100244e34:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1L_6string6StringEEECs3gRpqoBkMHm_13perry_runtime+0x34>
100244e38:     	add	x1, x1, #0x418
100244e3c:     	mov	x0, x20
100244e40:     	bl	0x100a22a9c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100244e44:     	strb	wzr, [x20, #0x20]
100244e48:     	ldr	x8, [x20]
100244e4c:     	cbz	x8, 0x100244a6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E20parse_object_untypedB9_+0xe28>
100244e50:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100244e54:     	add	x0, x0, #0x488
100244e58:     	bl	0x100b14d6c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100244e5c:     	adrp	x0, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244e60:     	add	x0, x0, #0x668
100244e64:     	bl	0x100b14e30 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100244e68:     	adrp	x2, 0x100ef8000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100244e6c:     	add	x2, x2, #0x800
100244e70:     	mov	x0, x24
100244e74:     	mov	w1, #0x8                ; =8
100244e78:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100244e7c:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244e80:     	add	x2, x2, #0x6c8
100244e84:     	mov	x0, x1
100244e88:     	mov	x1, x9
100244e8c:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100244e90:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244e94:     	add	x2, x2, #0x6e0
100244e98:     	mov	x1, x9
100244e9c:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100244ea0:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244ea4:     	add	x2, x2, #0x698
100244ea8:     	mov	w1, #0x8                ; =8
100244eac:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100244eb0:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244eb4:     	add	x2, x2, #0x680
100244eb8:     	mov	w1, #0x8                ; =8
100244ebc:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100244ec0:     	mov	w0, #0x8                ; =8
100244ec4:     	mov	w1, #0x80               ; =128
100244ec8:     	bl	0x100b149c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
