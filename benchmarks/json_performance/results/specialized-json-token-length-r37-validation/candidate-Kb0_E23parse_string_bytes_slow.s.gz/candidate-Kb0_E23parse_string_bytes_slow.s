
benchmarks/json_performance/.work/specialized-json-token-length-r37/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100244fd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_>:
100244fd4:     	sub	sp, sp, #0x90
100244fd8:     	stp	x28, x27, [sp, #0x30]
100244fdc:     	stp	x26, x25, [sp, #0x40]
100244fe0:     	stp	x24, x23, [sp, #0x50]
100244fe4:     	stp	x22, x21, [sp, #0x60]
100244fe8:     	stp	x20, x19, [sp, #0x70]
100244fec:     	stp	x29, x30, [sp, #0x80]
100244ff0:     	add	x29, sp, #0x80
100244ff4:     	ldp	x20, x22, [x1, #0x68]
100244ff8:     	subs	x23, x22, x2
100244ffc:     	b.lo	0x100245c08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xc34>
100245000:     	cmp	x22, x20
100245004:     	b.hi	0x100245c08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xc34>
100245008:     	tbz	x23, #0x3f, 0x10024501c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x48>
10024500c:     	mov	x24, #0x0               ; =0
100245010:     	mov	x0, x24
100245014:     	mov	x1, x23
100245018:     	bl	0x100b149c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10024501c:     	mov	x21, x1
100245020:     	str	x0, [sp, #0x8]
100245024:     	ldr	x25, [x1, #0x60]
100245028:     	cmp	x22, x2
10024502c:     	b.ne	0x100245040 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x6c>
100245030:     	mov	w8, #0x1                ; =1
100245034:     	stp	x23, x8, [sp, #0x10]
100245038:     	str	xzr, [sp, #0x20]
10024503c:     	b	0x10024506c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x98>
100245040:     	mov	x19, x2
100245044:     	mov	w24, #0x1               ; =1
100245048:     	mov	x0, x23
10024504c:     	mov	w1, #0x1                ; =1
100245050:     	bl	0x100b618c8 <_mi_malloc_aligned>
100245054:     	cbz	x0, 0x100245010 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x3c>
100245058:     	stp	x23, x0, [sp, #0x10]
10024505c:     	add	x1, x25, x19
100245060:     	mov	x2, x23
100245064:     	bl	0x100b644ec <_writev+0x100b644ec>
100245068:     	str	x23, [sp, #0x20]
10024506c:     	adds	x8, x22, #0x40
100245070:     	csinv	x8, x8, xzr, lo
100245074:     	cmp	x8, x20
100245078:     	csel	x19, x8, x20, lo
10024507c:     	mov	x24, #-0x101010101010102 ; =-72340172838076674
100245080:     	movk	x24, #0xfeff
100245084:     	mov	w8, #0xdc00             ; =56320
100245088:     	movk	w8, #0x370, lsl #16
10024508c:     	sub	w8, w8, #0x100, lsl #12 ; =0x100000
100245090:     	str	w8, [sp, #0x4]
100245094:     	mov	x13, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100245098:     	orr	x13, x13, #0x4444444444444444
10024509c:     	mov	x14, #-0x2020202020202021 ; =-2314885530818453537
1002450a0:     	movk	x14, #0xdfe0
1002450a4:     	cmp	x22, x19
1002450a8:     	b.lo	0x10024566c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x698>
1002450ac:     	sub	x8, x20, x22
1002450b0:     	cmp	x8, #0x40
1002450b4:     	b.lo	0x100245638 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x664>
1002450b8:     	ldp	x16, x28, [sp, #0x18]
1002450bc:     	ldr	x8, [sp, #0x10]
1002450c0:     	sub	x8, x8, x28
1002450c4:     	cmp	x8, #0x3f
1002450c8:     	b.ls	0x100245638 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x664>
1002450cc:     	cmn	x22, #0x35
1002450d0:     	b.hi	0x1002450e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x114>
1002450d4:     	mov	x19, #0x0               ; =0
1002450d8:     	add	x26, x16, x28
1002450dc:     	add	x27, x22, #0x34
1002450e0:     	mov	x8, x22
1002450e4:     	b	0x100245124 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x150>
1002450e8:     	mov	x19, #0x0               ; =0
1002450ec:     	str	x22, [x21, #0x70]
1002450f0:     	add	x28, x19, x28
1002450f4:     	str	x28, [sp, #0x20]
1002450f8:     	sub	x8, x20, x22
1002450fc:     	cmp	x8, #0x40
100245100:     	b.hs	0x1002450bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xe8>
100245104:     	b	0x100245638 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x664>
100245108:     	mov	w8, #0x9                ; =9
10024510c:     	strb	w8, [x26, x19]
100245110:     	mov	w23, #0x1               ; =1
100245114:     	add	x19, x23, x19
100245118:     	mov	x8, x22
10024511c:     	cmp	x22, x27
100245120:     	b.hs	0x1002450ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x118>
100245124:     	add	x9, x25, x8
100245128:     	ldrb	w10, [x9]
10024512c:     	add	x22, x8, #0x1
100245130:     	cmp	w10, #0x5c
100245134:     	b.eq	0x100245188 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x1b4>
100245138:     	cmp	w10, #0x22
10024513c:     	b.eq	0x100245bb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbe4>
100245140:     	cmp	w10, #0x20
100245144:     	b.lo	0x100245b90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbbc>
100245148:     	ldr	x9, [x9]
10024514c:     	eor	x10, x9, #0x2222222222222222
100245150:     	eor	x11, x9, x13
100245154:     	add	x11, x11, x24
100245158:     	add	x12, x9, x14
10024515c:     	orr	x11, x11, x12
100245160:     	add	x10, x10, x24
100245164:     	orr	x10, x11, x10
100245168:     	bic	x10, x10, x9
10024516c:     	and	x10, x10, #0x8080808080808080
100245170:     	rbit	x10, x10
100245174:     	clz	x10, x10
100245178:     	lsr	x23, x10, #3
10024517c:     	str	x9, [x26, x19]
100245180:     	add	x22, x23, x8
100245184:     	b	0x100245114 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x140>
100245188:     	ldrb	w10, [x25, x22]
10024518c:     	add	x22, x8, #0x2
100245190:     	cmp	w10, #0x65
100245194:     	b.le	0x100245210 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x23c>
100245198:     	cmp	w10, #0x71
10024519c:     	b.le	0x100245248 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x274>
1002451a0:     	cmp	w10, #0x72
1002451a4:     	b.eq	0x100245270 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x29c>
1002451a8:     	cmp	w10, #0x74
1002451ac:     	b.eq	0x100245108 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x134>
1002451b0:     	cmp	w10, #0x75
1002451b4:     	b.ne	0x100245b90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbbc>
1002451b8:     	add	x11, x25, x22
1002451bc:     	ldrb	w12, [x11]
1002451c0:     	sub	w10, w12, #0x30
1002451c4:     	cmp	w10, #0xa
1002451c8:     	b.lo	0x1002451dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x208>
1002451cc:     	sub	w10, w12, #0x61
1002451d0:     	cmp	w10, #0x6
1002451d4:     	b.hs	0x100245280 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x2ac>
1002451d8:     	sub	w10, w12, #0x57
1002451dc:     	ldrb	w13, [x11, #0x1]
1002451e0:     	sub	w12, w13, #0x30
1002451e4:     	cmp	w12, #0xa
1002451e8:     	b.hs	0x1002452a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x2cc>
1002451ec:     	ldrb	w14, [x11, #0x2]
1002451f0:     	sub	w13, w14, #0x30
1002451f4:     	cmp	w13, #0xa
1002451f8:     	b.hs	0x1002452c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x2ec>
1002451fc:     	ldrb	w11, [x11, #0x3]
100245200:     	sub	w14, w11, #0x30
100245204:     	cmp	w14, #0xa
100245208:     	b.lo	0x10024534c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x378>
10024520c:     	b	0x100245328 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x354>
100245210:     	cmp	w10, #0x5b
100245214:     	b.gt	0x100245230 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x25c>
100245218:     	cmp	w10, #0x22
10024521c:     	b.eq	0x100245260 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x28c>
100245220:     	cmp	w10, #0x2f
100245224:     	b.ne	0x100245b90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbbc>
100245228:     	mov	w8, #0x2f               ; =47
10024522c:     	b	0x10024510c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x138>
100245230:     	cmp	w10, #0x5c
100245234:     	b.eq	0x100245268 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x294>
100245238:     	cmp	w10, #0x62
10024523c:     	b.ne	0x100245b90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbbc>
100245240:     	mov	w8, #0x8                ; =8
100245244:     	b	0x10024510c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x138>
100245248:     	cmp	w10, #0x66
10024524c:     	b.eq	0x100245278 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x2a4>
100245250:     	cmp	w10, #0x6e
100245254:     	b.ne	0x100245b90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbbc>
100245258:     	mov	w8, #0xa                ; =10
10024525c:     	b	0x10024510c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x138>
100245260:     	mov	w8, #0x22               ; =34
100245264:     	b	0x10024510c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x138>
100245268:     	mov	w8, #0x5c               ; =92
10024526c:     	b	0x10024510c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x138>
100245270:     	mov	w8, #0xd                ; =13
100245274:     	b	0x10024510c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x138>
100245278:     	mov	w8, #0xc                ; =12
10024527c:     	b	0x10024510c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x138>
100245280:     	sub	w10, w12, #0x41
100245284:     	cmp	w10, #0x6
100245288:     	b.hs	0x100245b90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbbc>
10024528c:     	sub	w10, w12, #0x37
100245290:     	ldrb	w13, [x11, #0x1]
100245294:     	sub	w12, w13, #0x30
100245298:     	cmp	w12, #0xa
10024529c:     	b.lo	0x1002451ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x218>
1002452a0:     	sub	w12, w13, #0x61
1002452a4:     	cmp	w12, #0x6
1002452a8:     	b.hs	0x1002452e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x310>
1002452ac:     	sub	w12, w13, #0x57
1002452b0:     	ldrb	w14, [x11, #0x2]
1002452b4:     	sub	w13, w14, #0x30
1002452b8:     	cmp	w13, #0xa
1002452bc:     	b.lo	0x1002451fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x228>
1002452c0:     	sub	w13, w14, #0x61
1002452c4:     	cmp	w13, #0x6
1002452c8:     	b.hs	0x100245308 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x334>
1002452cc:     	sub	w13, w14, #0x57
1002452d0:     	ldrb	w11, [x11, #0x3]
1002452d4:     	sub	w14, w11, #0x30
1002452d8:     	cmp	w14, #0xa
1002452dc:     	b.hs	0x100245328 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x354>
1002452e0:     	b	0x10024534c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x378>
1002452e4:     	sub	w12, w13, #0x41
1002452e8:     	cmp	w12, #0x5
1002452ec:     	b.hi	0x100245b90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbbc>
1002452f0:     	sub	w12, w13, #0x37
1002452f4:     	ldrb	w14, [x11, #0x2]
1002452f8:     	sub	w13, w14, #0x30
1002452fc:     	cmp	w13, #0xa
100245300:     	b.hs	0x1002452c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x2ec>
100245304:     	b	0x1002451fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x228>
100245308:     	sub	w13, w14, #0x41
10024530c:     	cmp	w13, #0x5
100245310:     	b.hi	0x100245b90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbbc>
100245314:     	sub	w13, w14, #0x37
100245318:     	ldrb	w11, [x11, #0x3]
10024531c:     	sub	w14, w11, #0x30
100245320:     	cmp	w14, #0xa
100245324:     	b.lo	0x10024534c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x378>
100245328:     	sub	w14, w11, #0x61
10024532c:     	cmp	w14, #0x6
100245330:     	b.hs	0x10024533c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x368>
100245334:     	sub	w14, w11, #0x57
100245338:     	b	0x10024534c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x378>
10024533c:     	sub	w14, w11, #0x41
100245340:     	cmp	w14, #0x5
100245344:     	b.hi	0x100245b90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbbc>
100245348:     	sub	w14, w11, #0x37
10024534c:     	add	x22, x8, #0x6
100245350:     	and	w10, w10, #0xff
100245354:     	and	w11, w12, #0xff
100245358:     	lsl	w11, w11, #4
10024535c:     	orr	w11, w11, w10, lsl #8
100245360:     	and	w10, w13, #0xff
100245364:     	orr	w12, w11, w10
100245368:     	lsl	w13, w12, #4
10024536c:     	and	w10, w14, #0xff
100245370:     	orr	w10, w13, w10
100245374:     	cmp	w11, #0xd80
100245378:     	b.hs	0x1002453b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x3e4>
10024537c:     	str	wzr, [sp, #0x2c]
100245380:     	and	w8, w13, #0xffff
100245384:     	mov	w9, #0xd800             ; =55296
100245388:     	movk	w9, #0xffef, lsl #16
10024538c:     	eor	w8, w8, w9
100245390:     	mov	w9, #0x800              ; =2048
100245394:     	movk	w9, #0xffef, lsl #16
100245398:     	cmp	w8, w9
10024539c:     	b.lo	0x100245c20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xc4c>
1002453a0:     	mov	x24, x16
1002453a4:     	cmp	w12, #0x8
1002453a8:     	b.hs	0x100245410 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x43c>
1002453ac:     	strb	w10, [sp, #0x2c]
1002453b0:     	mov	w23, #0x1               ; =1
1002453b4:     	b	0x1002455e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x60c>
1002453b8:     	cmp	w12, #0xdbf
1002453bc:     	b.hi	0x100245438 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x464>
1002453c0:     	cmp	x22, x20
1002453c4:     	b.hs	0x100245c7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xca8>
1002453c8:     	ldrb	w12, [x25, x22]
1002453cc:     	cmp	w12, #0x5c
1002453d0:     	b.ne	0x1002455b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x5dc>
1002453d4:     	add	x0, x8, #0x7
1002453d8:     	cmp	x0, x20
1002453dc:     	b.hs	0x100245c90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xcbc>
1002453e0:     	ldrb	w12, [x25, x0]
1002453e4:     	cmp	w12, #0x75
1002453e8:     	b.ne	0x1002455b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x5dc>
1002453ec:     	ldrb	w13, [x9, #0x8]
1002453f0:     	sub	w12, w13, #0x30
1002453f4:     	cmp	w12, #0xa
1002453f8:     	b.lo	0x100245474 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x4a0>
1002453fc:     	sub	w12, w13, #0x61
100245400:     	cmp	w12, #0x6
100245404:     	b.hs	0x100245464 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x490>
100245408:     	sub	w12, w13, #0x57
10024540c:     	b	0x100245474 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x4a0>
100245410:     	mov	w8, #-0x80              ; =-128
100245414:     	bfxil	w8, w10, #0, #6
100245418:     	cmp	w11, #0x80
10024541c:     	b.hs	0x100245448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x474>
100245420:     	lsr	w9, w10, #6
100245424:     	orr	w9, w9, #0xc0
100245428:     	strb	w9, [sp, #0x2c]
10024542c:     	strb	w8, [sp, #0x2d]
100245430:     	mov	w23, #0x2               ; =2
100245434:     	b	0x1002455e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x60c>
100245438:     	str	wzr, [sp, #0x2c]
10024543c:     	cmp	w11, #0xe00
100245440:     	b.hs	0x100245380 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x3ac>
100245444:     	b	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x5e0>
100245448:     	lsr	w9, w11, #8
10024544c:     	mov	w11, #0x80              ; =128
100245450:     	orr	w9, w9, #0xe0
100245454:     	strb	w9, [sp, #0x2c]
100245458:     	bfxil	w11, w10, #6, #6
10024545c:     	strb	w11, [sp, #0x2d]
100245460:     	b	0x1002455d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x604>
100245464:     	sub	w12, w13, #0x41
100245468:     	cmp	w12, #0x6
10024546c:     	b.hs	0x1002455b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x5dc>
100245470:     	sub	w12, w13, #0x37
100245474:     	ldrb	w14, [x9, #0x9]
100245478:     	sub	w13, w14, #0x30
10024547c:     	cmp	w13, #0xa
100245480:     	b.lo	0x1002454a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x4d4>
100245484:     	sub	w13, w14, #0x61
100245488:     	cmp	w13, #0x6
10024548c:     	b.hs	0x100245498 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x4c4>
100245490:     	sub	w13, w14, #0x57
100245494:     	b	0x1002454a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x4d4>
100245498:     	sub	w13, w14, #0x41
10024549c:     	cmp	w13, #0x5
1002454a0:     	b.hi	0x1002455b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x5dc>
1002454a4:     	sub	w13, w14, #0x37
1002454a8:     	ldrb	w15, [x9, #0xa]
1002454ac:     	sub	w14, w15, #0x30
1002454b0:     	cmp	w14, #0xa
1002454b4:     	b.lo	0x1002454dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x508>
1002454b8:     	sub	w14, w15, #0x61
1002454bc:     	cmp	w14, #0x6
1002454c0:     	b.hs	0x1002454cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x4f8>
1002454c4:     	sub	w14, w15, #0x57
1002454c8:     	b	0x1002454dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x508>
1002454cc:     	sub	w14, w15, #0x41
1002454d0:     	cmp	w14, #0x5
1002454d4:     	b.hi	0x1002455b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x5dc>
1002454d8:     	sub	w14, w15, #0x37
1002454dc:     	ldrb	w15, [x9, #0xb]
1002454e0:     	sub	w9, w15, #0x30
1002454e4:     	cmp	w9, #0xa
1002454e8:     	b.lo	0x100245510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x53c>
1002454ec:     	sub	w9, w15, #0x61
1002454f0:     	cmp	w9, #0x6
1002454f4:     	b.hs	0x100245500 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x52c>
1002454f8:     	sub	w9, w15, #0x57
1002454fc:     	b	0x100245510 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x53c>
100245500:     	sub	w9, w15, #0x41
100245504:     	cmp	w9, #0x5
100245508:     	b.hi	0x1002455b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x5dc>
10024550c:     	sub	w9, w15, #0x37
100245510:     	and	w12, w12, #0xff
100245514:     	and	w13, w13, #0xff
100245518:     	lsl	w13, w13, #4
10024551c:     	orr	w12, w13, w12, lsl #8
100245520:     	and	w13, w14, #0xff
100245524:     	orr	w12, w12, w13
100245528:     	and	w13, w12, #0xfc0
10024552c:     	str	wzr, [sp, #0x2c]
100245530:     	cmp	w13, #0xdc0
100245534:     	b.ne	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x5e0>
100245538:     	and	w9, w9, #0xff
10024553c:     	orr	w11, w9, w12, lsl #4
100245540:     	and	w9, w10, #0xffff
100245544:     	lsl	w9, w9, #10
100245548:     	add	w12, w9, w11, uxth
10024554c:     	mov	w9, #0x2400             ; =9216
100245550:     	movk	w9, #0xfca0, lsl #16
100245554:     	add	w9, w12, w9
100245558:     	mov	w10, #0xd800            ; =55296
10024555c:     	eor	w10, w9, w10
100245560:     	mov	w13, #0x800             ; =2048
100245564:     	movk	w13, #0xffef, lsl #16
100245568:     	add	w10, w10, w13
10024556c:     	sub	w10, w10, #0x800
100245570:     	cmp	w10, w13
100245574:     	b.lo	0x100245c44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xc70>
100245578:     	mov	x24, x16
10024557c:     	add	x22, x8, #0xc
100245580:     	mov	w8, #-0x80              ; =-128
100245584:     	bfxil	w8, w11, #0, #6
100245588:     	mov	w10, #-0x80             ; =-128
10024558c:     	bfxil	w10, w9, #6, #6
100245590:     	ldr	w11, [sp, #0x4]
100245594:     	cmp	w12, w11
100245598:     	b.hs	0x100245610 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x63c>
10024559c:     	lsr	w9, w9, #12
1002455a0:     	orr	w9, w9, #0xe0
1002455a4:     	strb	w9, [sp, #0x2c]
1002455a8:     	strb	w10, [sp, #0x2d]
1002455ac:     	b	0x1002455d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x604>
1002455b0:     	str	wzr, [sp, #0x2c]
1002455b4:     	mov	x24, x16
1002455b8:     	lsr	w8, w11, #8
1002455bc:     	orr	w8, w8, #0xe0
1002455c0:     	strb	w8, [sp, #0x2c]
1002455c4:     	mov	w8, #0x80               ; =128
1002455c8:     	bfxil	w8, w10, #6, #6
1002455cc:     	strb	w8, [sp, #0x2d]
1002455d0:     	mov	w8, #0x80               ; =128
1002455d4:     	bfxil	w8, w10, #0, #6
1002455d8:     	strb	w8, [sp, #0x2e]
1002455dc:     	mov	w23, #0x3               ; =3
1002455e0:     	add	x0, x26, x19
1002455e4:     	add	x1, sp, #0x2c
1002455e8:     	mov	x2, x23
1002455ec:     	bl	0x100b644ec <_writev+0x100b644ec>
1002455f0:     	mov	x13, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
1002455f4:     	orr	x13, x13, #0x4444444444444444
1002455f8:     	mov	x14, #-0x2020202020202021 ; =-2314885530818453537
1002455fc:     	movk	x14, #0xdfe0
100245600:     	mov	x16, x24
100245604:     	mov	x24, #-0x101010101010102 ; =-72340172838076674
100245608:     	movk	x24, #0xfeff
10024560c:     	b	0x100245114 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x140>
100245610:     	lsr	w11, w9, #18
100245614:     	orr	w11, w11, #0xf0
100245618:     	mov	w12, #0x80              ; =128
10024561c:     	strb	w11, [sp, #0x2c]
100245620:     	bfxil	w12, w9, #12, #6
100245624:     	strb	w12, [sp, #0x2d]
100245628:     	strb	w10, [sp, #0x2e]
10024562c:     	strb	w8, [sp, #0x2f]
100245630:     	mov	w23, #0x4               ; =4
100245634:     	b	0x1002455e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x60c>
100245638:     	adds	x8, x22, #0x40
10024563c:     	csinv	x8, x8, xzr, lo
100245640:     	cmp	x8, x20
100245644:     	csel	x19, x8, x20, lo
100245648:     	cmp	x22, x20
10024564c:     	b.lo	0x10024566c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x698>
100245650:     	b	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbc0>
100245654:     	ldr	x8, [sp, #0x18]
100245658:     	strb	w23, [x8, x26]
10024565c:     	add	x8, x26, #0x1
100245660:     	str	x8, [sp, #0x20]
100245664:     	cmp	x22, x19
100245668:     	b.hs	0x1002450ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xd8>
10024566c:     	mov	x8, x22
100245670:     	ldrb	w23, [x25, x22]
100245674:     	add	x22, x22, #0x1
100245678:     	str	x22, [x21, #0x70]
10024567c:     	cmp	w23, #0x5c
100245680:     	b.eq	0x1002456c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x6ec>
100245684:     	cmp	w23, #0x22
100245688:     	b.eq	0x100245bf4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xc20>
10024568c:     	cmp	w23, #0x20
100245690:     	b.lo	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbc0>
100245694:     	ldr	x26, [sp, #0x20]
100245698:     	ldr	x8, [sp, #0x10]
10024569c:     	cmp	x26, x8
1002456a0:     	b.ne	0x100245654 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x680>
1002456a4:     	add	x0, sp, #0x10
1002456a8:     	bl	0x100b148a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002456ac:     	mov	x14, #-0x2020202020202021 ; =-2314885530818453537
1002456b0:     	movk	x14, #0xdfe0
1002456b4:     	mov	x13, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
1002456b8:     	orr	x13, x13, #0x4444444444444444
1002456bc:     	b	0x100245654 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x680>
1002456c0:     	cmp	x22, x20
1002456c4:     	b.hs	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbc0>
1002456c8:     	ldrb	w9, [x25, x22]
1002456cc:     	add	x23, x8, #0x2
1002456d0:     	str	x23, [x21, #0x70]
1002456d4:     	cmp	w9, #0x65
1002456d8:     	b.le	0x100245740 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x76c>
1002456dc:     	cmp	w9, #0x71
1002456e0:     	b.le	0x100245800 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x82c>
1002456e4:     	cmp	w9, #0x72
1002456e8:     	b.eq	0x1002458f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x920>
1002456ec:     	cmp	w9, #0x74
1002456f0:     	b.ne	0x10024598c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x9b8>
1002456f4:     	ldr	x22, [sp, #0x20]
1002456f8:     	ldr	x8, [sp, #0x10]
1002456fc:     	cmp	x22, x8
100245700:     	b.ne	0x10024571c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x748>
100245704:     	add	x0, sp, #0x10
100245708:     	bl	0x100b148a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
10024570c:     	mov	x14, #-0x2020202020202021 ; =-2314885530818453537
100245710:     	movk	x14, #0xdfe0
100245714:     	mov	x13, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100245718:     	orr	x13, x13, #0x4444444444444444
10024571c:     	ldr	x8, [sp, #0x18]
100245720:     	mov	w9, #0x9                ; =9
100245724:     	strb	w9, [x8, x22]
100245728:     	add	x8, x22, #0x1
10024572c:     	str	x8, [sp, #0x20]
100245730:     	mov	x22, x23
100245734:     	cmp	x23, x19
100245738:     	b.lo	0x10024566c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x698>
10024573c:     	b	0x1002450ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xd8>
100245740:     	cmp	w9, #0x5b
100245744:     	b.gt	0x1002457a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x7d0>
100245748:     	cmp	w9, #0x22
10024574c:     	b.eq	0x10024585c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x888>
100245750:     	cmp	w9, #0x2f
100245754:     	b.ne	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbc0>
100245758:     	ldr	x22, [sp, #0x20]
10024575c:     	ldr	x8, [sp, #0x10]
100245760:     	cmp	x22, x8
100245764:     	b.ne	0x100245780 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x7ac>
100245768:     	add	x0, sp, #0x10
10024576c:     	bl	0x100b148a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245770:     	mov	x14, #-0x2020202020202021 ; =-2314885530818453537
100245774:     	movk	x14, #0xdfe0
100245778:     	mov	x13, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
10024577c:     	orr	x13, x13, #0x4444444444444444
100245780:     	ldr	x8, [sp, #0x18]
100245784:     	mov	w9, #0x2f               ; =47
100245788:     	strb	w9, [x8, x22]
10024578c:     	add	x8, x22, #0x1
100245790:     	str	x8, [sp, #0x20]
100245794:     	mov	x22, x23
100245798:     	cmp	x23, x19
10024579c:     	b.lo	0x10024566c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x698>
1002457a0:     	b	0x1002450ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xd8>
1002457a4:     	cmp	w9, #0x5c
1002457a8:     	b.eq	0x1002458a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x8d4>
1002457ac:     	cmp	w9, #0x62
1002457b0:     	b.ne	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbc0>
1002457b4:     	ldr	x22, [sp, #0x20]
1002457b8:     	ldr	x8, [sp, #0x10]
1002457bc:     	cmp	x22, x8
1002457c0:     	b.ne	0x1002457dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x808>
1002457c4:     	add	x0, sp, #0x10
1002457c8:     	bl	0x100b148a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002457cc:     	mov	x14, #-0x2020202020202021 ; =-2314885530818453537
1002457d0:     	movk	x14, #0xdfe0
1002457d4:     	mov	x13, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
1002457d8:     	orr	x13, x13, #0x4444444444444444
1002457dc:     	ldr	x8, [sp, #0x18]
1002457e0:     	mov	w9, #0x8                ; =8
1002457e4:     	strb	w9, [x8, x22]
1002457e8:     	add	x8, x22, #0x1
1002457ec:     	str	x8, [sp, #0x20]
1002457f0:     	mov	x22, x23
1002457f4:     	cmp	x23, x19
1002457f8:     	b.lo	0x10024566c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x698>
1002457fc:     	b	0x1002450ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xd8>
100245800:     	cmp	w9, #0x66
100245804:     	b.eq	0x100245940 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x96c>
100245808:     	cmp	w9, #0x6e
10024580c:     	b.ne	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbc0>
100245810:     	ldr	x22, [sp, #0x20]
100245814:     	ldr	x8, [sp, #0x10]
100245818:     	cmp	x22, x8
10024581c:     	b.ne	0x100245838 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x864>
100245820:     	add	x0, sp, #0x10
100245824:     	bl	0x100b148a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245828:     	mov	x14, #-0x2020202020202021 ; =-2314885530818453537
10024582c:     	movk	x14, #0xdfe0
100245830:     	mov	x13, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100245834:     	orr	x13, x13, #0x4444444444444444
100245838:     	ldr	x8, [sp, #0x18]
10024583c:     	mov	w9, #0xa                ; =10
100245840:     	strb	w9, [x8, x22]
100245844:     	add	x8, x22, #0x1
100245848:     	str	x8, [sp, #0x20]
10024584c:     	mov	x22, x23
100245850:     	cmp	x23, x19
100245854:     	b.lo	0x10024566c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x698>
100245858:     	b	0x1002450ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xd8>
10024585c:     	ldr	x22, [sp, #0x20]
100245860:     	ldr	x8, [sp, #0x10]
100245864:     	cmp	x22, x8
100245868:     	b.ne	0x100245884 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x8b0>
10024586c:     	add	x0, sp, #0x10
100245870:     	bl	0x100b148a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245874:     	mov	x14, #-0x2020202020202021 ; =-2314885530818453537
100245878:     	movk	x14, #0xdfe0
10024587c:     	mov	x13, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100245880:     	orr	x13, x13, #0x4444444444444444
100245884:     	ldr	x8, [sp, #0x18]
100245888:     	mov	w9, #0x22               ; =34
10024588c:     	strb	w9, [x8, x22]
100245890:     	add	x8, x22, #0x1
100245894:     	str	x8, [sp, #0x20]
100245898:     	mov	x22, x23
10024589c:     	cmp	x23, x19
1002458a0:     	b.lo	0x10024566c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x698>
1002458a4:     	b	0x1002450ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xd8>
1002458a8:     	ldr	x22, [sp, #0x20]
1002458ac:     	ldr	x8, [sp, #0x10]
1002458b0:     	cmp	x22, x8
1002458b4:     	b.ne	0x1002458d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x8fc>
1002458b8:     	add	x0, sp, #0x10
1002458bc:     	bl	0x100b148a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002458c0:     	mov	x14, #-0x2020202020202021 ; =-2314885530818453537
1002458c4:     	movk	x14, #0xdfe0
1002458c8:     	mov	x13, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
1002458cc:     	orr	x13, x13, #0x4444444444444444
1002458d0:     	ldr	x8, [sp, #0x18]
1002458d4:     	mov	w9, #0x5c               ; =92
1002458d8:     	strb	w9, [x8, x22]
1002458dc:     	add	x8, x22, #0x1
1002458e0:     	str	x8, [sp, #0x20]
1002458e4:     	mov	x22, x23
1002458e8:     	cmp	x23, x19
1002458ec:     	b.lo	0x10024566c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x698>
1002458f0:     	b	0x1002450ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xd8>
1002458f4:     	ldr	x22, [sp, #0x20]
1002458f8:     	ldr	x8, [sp, #0x10]
1002458fc:     	cmp	x22, x8
100245900:     	b.ne	0x10024591c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x948>
100245904:     	add	x0, sp, #0x10
100245908:     	bl	0x100b148a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
10024590c:     	mov	x14, #-0x2020202020202021 ; =-2314885530818453537
100245910:     	movk	x14, #0xdfe0
100245914:     	mov	x13, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100245918:     	orr	x13, x13, #0x4444444444444444
10024591c:     	ldr	x8, [sp, #0x18]
100245920:     	mov	w9, #0xd                ; =13
100245924:     	strb	w9, [x8, x22]
100245928:     	add	x8, x22, #0x1
10024592c:     	str	x8, [sp, #0x20]
100245930:     	mov	x22, x23
100245934:     	cmp	x23, x19
100245938:     	b.lo	0x10024566c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x698>
10024593c:     	b	0x1002450ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xd8>
100245940:     	ldr	x22, [sp, #0x20]
100245944:     	ldr	x8, [sp, #0x10]
100245948:     	cmp	x22, x8
10024594c:     	b.ne	0x100245968 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x994>
100245950:     	add	x0, sp, #0x10
100245954:     	bl	0x100b148a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100245958:     	mov	x14, #-0x2020202020202021 ; =-2314885530818453537
10024595c:     	movk	x14, #0xdfe0
100245960:     	mov	x13, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100245964:     	orr	x13, x13, #0x4444444444444444
100245968:     	ldr	x8, [sp, #0x18]
10024596c:     	mov	w9, #0xc                ; =12
100245970:     	strb	w9, [x8, x22]
100245974:     	add	x8, x22, #0x1
100245978:     	str	x8, [sp, #0x20]
10024597c:     	mov	x22, x23
100245980:     	cmp	x23, x19
100245984:     	b.lo	0x10024566c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x698>
100245988:     	b	0x1002450ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xd8>
10024598c:     	cmp	w9, #0x75
100245990:     	b.ne	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbc0>
100245994:     	add	x22, x8, #0x6
100245998:     	cmp	x22, x20
10024599c:     	b.hi	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbc0>
1002459a0:     	cmp	x22, x23
1002459a4:     	b.lo	0x100245c2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xc58>
1002459a8:     	add	x10, x25, x23
1002459ac:     	ldrb	w11, [x10]
1002459b0:     	sub	w9, w11, #0x30
1002459b4:     	cmp	w9, #0xa
1002459b8:     	b.lo	0x1002459e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xa0c>
1002459bc:     	sub	w9, w11, #0x61
1002459c0:     	cmp	w9, #0x6
1002459c4:     	b.hs	0x1002459d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0x9fc>
1002459c8:     	sub	w9, w11, #0x57
1002459cc:     	b	0x1002459e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xa0c>
1002459d0:     	sub	w9, w11, #0x41
1002459d4:     	cmp	w9, #0x6
1002459d8:     	b.hs	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbc0>
1002459dc:     	sub	w9, w11, #0x37
1002459e0:     	ldrb	w12, [x10, #0x1]
1002459e4:     	sub	w11, w12, #0x30
1002459e8:     	cmp	w11, #0xa
1002459ec:     	b.lo	0x100245a14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xa40>
1002459f0:     	sub	w11, w12, #0x61
1002459f4:     	cmp	w11, #0x6
1002459f8:     	b.hs	0x100245a04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xa30>
1002459fc:     	sub	w11, w12, #0x57
100245a00:     	b	0x100245a14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xa40>
100245a04:     	sub	w11, w12, #0x41
100245a08:     	cmp	w11, #0x5
100245a0c:     	b.hi	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbc0>
100245a10:     	sub	w11, w12, #0x37
100245a14:     	ldrb	w13, [x10, #0x2]
100245a18:     	sub	w12, w13, #0x30
100245a1c:     	cmp	w12, #0xa
100245a20:     	b.lo	0x100245a48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xa74>
100245a24:     	sub	w12, w13, #0x61
100245a28:     	cmp	w12, #0x6
100245a2c:     	b.hs	0x100245a38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xa64>
100245a30:     	sub	w12, w13, #0x57
100245a34:     	b	0x100245a48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xa74>
100245a38:     	sub	w12, w13, #0x41
100245a3c:     	cmp	w12, #0x5
100245a40:     	b.hi	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbc0>
100245a44:     	sub	w12, w13, #0x37
100245a48:     	ldrb	w13, [x10, #0x3]
100245a4c:     	sub	w10, w13, #0x30
100245a50:     	cmp	w10, #0xa
100245a54:     	b.lo	0x100245a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xaa8>
100245a58:     	sub	w10, w13, #0x61
100245a5c:     	cmp	w10, #0x6
100245a60:     	b.hs	0x100245a6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xa98>
100245a64:     	sub	w10, w13, #0x57
100245a68:     	b	0x100245a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xaa8>
100245a6c:     	sub	w10, w13, #0x41
100245a70:     	cmp	w10, #0x5
100245a74:     	b.hi	0x100245b94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbc0>
100245a78:     	sub	w10, w13, #0x37
100245a7c:     	and	w9, w9, #0xff
100245a80:     	and	w11, w11, #0xff
100245a84:     	lsl	w11, w11, #4
100245a88:     	orr	w11, w11, w9, lsl #8
100245a8c:     	and	w9, w12, #0xff
100245a90:     	orr	w9, w11, w9
100245a94:     	and	w10, w10, #0xff
100245a98:     	orr	w1, w10, w9, lsl #4
100245a9c:     	str	x22, [x21, #0x70]
100245aa0:     	cmp	w11, #0xd80
100245aa4:     	b.lo	0x100245b84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbb0>
100245aa8:     	cmp	w9, #0xdbf
100245aac:     	b.hi	0x100245b84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbb0>
100245ab0:     	add	x23, x8, #0xc
100245ab4:     	cmp	x23, x20
100245ab8:     	b.hi	0x100245b84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbb0>
100245abc:     	cmp	x22, x20
100245ac0:     	b.hs	0x100245ca0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xccc>
100245ac4:     	ldrb	w9, [x25, x22]
100245ac8:     	cmp	w9, #0x5c
100245acc:     	b.ne	0x100245b84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbb0>
100245ad0:     	add	x0, x8, #0x7
100245ad4:     	cmp	x0, x20
100245ad8:     	b.hs	0x100245cb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xce0>
100245adc:     	ldrb	w9, [x25, x0]
100245ae0:     	cmp	w9, #0x75
100245ae4:     	b.ne	0x100245b84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbb0>
100245ae8:     	add	x0, x8, #0x8
100245aec:     	cmp	x23, x0
100245af0:     	b.lo	0x100245c50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xc7c>
100245af4:     	mov	x26, x1
100245af8:     	add	x0, x25, x0
100245afc:     	bl	0x1004fcdb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser14decode_hex_u16>
100245b00:     	mov	x8, x1
100245b04:     	ubfx	w9, w1, #10, #6
100245b08:     	cmp	w9, #0x37
100245b0c:     	cset	w9, eq
100245b10:     	and	w9, w0, w9
100245b14:     	mov	x1, x26
100245b18:     	tbz	w9, #0x0, 0x100245b84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbb0>
100245b1c:     	str	x23, [x21, #0x70]
100245b20:     	and	w9, w1, #0xffff
100245b24:     	lsl	w9, w9, #10
100245b28:     	add	w8, w9, w8, uxth
100245b2c:     	mov	w9, #0x2400             ; =9216
100245b30:     	movk	w9, #0xfca0, lsl #16
100245b34:     	add	w0, w8, w9
100245b38:     	mov	w8, #0xd800             ; =55296
100245b3c:     	eor	w8, w0, w8
100245b40:     	mov	w9, #0x800              ; =2048
100245b44:     	movk	w9, #0xffef, lsl #16
100245b48:     	add	w8, w8, w9
100245b4c:     	sub	w8, w8, #0x800
100245b50:     	cmp	w8, w9
100245b54:     	b.lo	0x100245c64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xc90>
100245b58:     	str	wzr, [sp, #0x2c]
100245b5c:     	add	x1, sp, #0x2c
100245b60:     	bl	0x10068c090 <__RNvNtNtCsjgY6bXVaRmE_4core4char7methods15encode_utf8_raw>
100245b64:     	mov	x2, x0
100245b68:     	mov	x3, x1
100245b6c:     	add	x0, sp, #0x10
100245b70:     	mov	x1, x2
100245b74:     	mov	x2, x3
100245b78:     	bl	0x100285090 <__RNvMs_NtCsctvjasLqLe9_5alloc3vecINtB4_3VechE15append_elementsCs3gRpqoBkMHm_13perry_runtime>
100245b7c:     	mov	x22, x23
100245b80:     	b	0x100245094 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xc0>
100245b84:     	add	x0, sp, #0x10
100245b88:     	bl	0x1004fcf08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser19push_code_unit_wtf8>
100245b8c:     	b	0x100245094 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xc0>
100245b90:     	str	x22, [x21, #0x70]
100245b94:     	strb	wzr, [x21, #0xd4]
100245b98:     	mov	x8, #-0x2               ; =-2
100245b9c:     	ldr	x9, [sp, #0x8]
100245ba0:     	str	x8, [x9]
100245ba4:     	ldr	x8, [sp, #0x10]
100245ba8:     	cbz	x8, 0x100245bd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xc00>
100245bac:     	ldr	x0, [sp, #0x18]
100245bb0:     	bl	0x100b61640 <_mi_free>
100245bb4:     	b	0x100245bd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xc00>
100245bb8:     	str	x22, [x21, #0x70]
100245bbc:     	add	x8, x19, x28
100245bc0:     	str	x8, [sp, #0x20]
100245bc4:     	ldr	q0, [sp, #0x10]
100245bc8:     	ldr	x9, [sp, #0x8]
100245bcc:     	str	q0, [x9]
100245bd0:     	str	x8, [x9, #0x10]
100245bd4:     	ldp	x29, x30, [sp, #0x80]
100245bd8:     	ldp	x20, x19, [sp, #0x70]
100245bdc:     	ldp	x22, x21, [sp, #0x60]
100245be0:     	ldp	x24, x23, [sp, #0x50]
100245be4:     	ldp	x26, x25, [sp, #0x40]
100245be8:     	ldp	x28, x27, [sp, #0x30]
100245bec:     	add	sp, sp, #0x90
100245bf0:     	ret
100245bf4:     	ldr	q0, [sp, #0x10]
100245bf8:     	ldr	x9, [sp, #0x8]
100245bfc:     	str	q0, [x9]
100245c00:     	ldr	x8, [sp, #0x20]
100245c04:     	b	0x100245bd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserINtB5_23SpecializedDirectParserKb0_E23parse_string_bytes_slowB9_+0xbfc>
100245c08:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245c0c:     	add	x3, x3, #0x7a0
100245c10:     	mov	x0, x2
100245c14:     	mov	x1, x22
100245c18:     	mov	x2, x20
100245c1c:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245c20:     	adrp	x0, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245c24:     	add	x0, x0, #0x348
100245c28:     	bl	0x100b14e30 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100245c2c:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245c30:     	add	x3, x3, #0x788
100245c34:     	mov	x0, x23
100245c38:     	mov	x1, x22
100245c3c:     	mov	x2, x20
100245c40:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245c44:     	adrp	x0, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245c48:     	add	x0, x0, #0x330
100245c4c:     	bl	0x100b14e30 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100245c50:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245c54:     	add	x3, x3, #0x770
100245c58:     	mov	x1, x23
100245c5c:     	mov	x2, x20
100245c60:     	bl	0x100b1508c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245c64:     	adrp	x0, 0x100c48000 <_PERRY_EMPTY_STRING+0x43f4>
100245c68:     	add	x0, x0, #0xb38
100245c6c:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245c70:     	add	x2, x2, #0x758
100245c74:     	mov	w1, #0x22               ; =34
100245c78:     	bl	0x100b14e00 <__RNvNtCsjgY6bXVaRmE_4core6option13expect_failed>
100245c7c:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245c80:     	add	x2, x2, #0x300
100245c84:     	mov	x0, x22
100245c88:     	mov	x1, x20
100245c8c:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245c90:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245c94:     	add	x2, x2, #0x318
100245c98:     	mov	x1, x20
100245c9c:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245ca0:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245ca4:     	add	x2, x2, #0x728
100245ca8:     	mov	x0, x22
100245cac:     	mov	x1, x20
100245cb0:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245cb4:     	adrp	x2, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245cb8:     	add	x2, x2, #0x740
100245cbc:     	mov	x1, x20
100245cc0:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
