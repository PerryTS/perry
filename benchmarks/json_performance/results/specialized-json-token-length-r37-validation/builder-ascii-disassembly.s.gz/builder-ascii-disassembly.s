
benchmarks/json_performance/.work/specialized-json-token-length-r37/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010034bcf0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>:
10034bcf0:     	stp	x24, x23, [sp, #-0x40]!
10034bcf4:     	stp	x22, x21, [sp, #0x10]
10034bcf8:     	stp	x20, x19, [sp, #0x20]
10034bcfc:     	stp	x29, x30, [sp, #0x30]
10034bd00:     	add	x29, sp, #0x30
10034bd04:     	lsr	x8, x1, #32
10034bd08:     	cbnz	x8, 0x10034beec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x1fc>
10034bd0c:     	mov	x19, x1
10034bd10:     	mov	x20, x0
10034bd14:     	cbz	x1, 0x10034bd44 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x54>
10034bd18:     	mov	x8, x20
10034bd1c:     	ands	x9, x19, #0x3
10034bd20:     	b.eq	0x10034bd3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x4c>
10034bd24:     	mov	x8, x20
10034bd28:     	ldrsb	w10, [x8]
10034bd2c:     	tbnz	w10, #0x1f, 0x10034bdcc <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xdc>
10034bd30:     	add	x8, x8, #0x1
10034bd34:     	subs	x9, x9, #0x1
10034bd38:     	b.ne	0x10034bd28 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x38>
10034bd3c:     	cmp	x19, #0x4
10034bd40:     	b.hs	0x10034bd98 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xa8>
10034bd44:     	mov	w8, #0xffe8             ; =65512
10034bd48:     	movk	w8, #0x1fff, lsl #16
10034bd4c:     	cmp	x19, x8
10034bd50:     	b.hi	0x10034beec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x1fc>
10034bd54:     	mov	x0, x19
10034bd58:     	bl	0x10034b6ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10034bd5c:     	stp	w19, w19, [x0]
10034bd60:     	stp	wzr, wzr, [x0, #0xc]
10034bd64:     	str	w19, [x0, #0x8]
10034bd68:     	cbz	x19, 0x10034bd84 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x94>
10034bd6c:     	mov	x21, x0
10034bd70:     	mov	x0, x1
10034bd74:     	mov	x1, x20
10034bd78:     	mov	x2, x19
10034bd7c:     	bl	0x100b644ec <_writev+0x100b644ec>
10034bd80:     	mov	x0, x21
10034bd84:     	ldp	x29, x30, [sp, #0x30]
10034bd88:     	ldp	x20, x19, [sp, #0x20]
10034bd8c:     	ldp	x22, x21, [sp, #0x10]
10034bd90:     	ldp	x24, x23, [sp], #0x40
10034bd94:     	ret
10034bd98:     	add	x9, x20, x19
10034bd9c:     	ldrsb	w10, [x8]
10034bda0:     	tbnz	w10, #0x1f, 0x10034bdcc <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xdc>
10034bda4:     	ldrsb	w10, [x8, #0x1]
10034bda8:     	tbnz	w10, #0x1f, 0x10034bdcc <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xdc>
10034bdac:     	ldrsb	w10, [x8, #0x2]
10034bdb0:     	tbnz	w10, #0x1f, 0x10034bdcc <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xdc>
10034bdb4:     	ldrsb	w10, [x8, #0x3]
10034bdb8:     	tbnz	w10, #0x1f, 0x10034bdcc <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xdc>
10034bdbc:     	add	x8, x8, #0x4
10034bdc0:     	cmp	x8, x9
10034bdc4:     	b.ne	0x10034bd9c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xac>
10034bdc8:     	b	0x10034bd44 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x54>
10034bdcc:     	mov	x0, #0x0                ; =0
10034bdd0:     	mov	w23, #0x0               ; =0
10034bdd4:     	mov	w22, #0x0               ; =0
10034bdd8:     	b	0x10034bdfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x10c>
10034bddc:     	adds	w8, w23, #0x1
10034bde0:     	csinv	w23, w8, wzr, lo
10034bde4:     	mov	w8, #0x1                ; =1
10034bde8:     	add	x8, x8, x0
10034bdec:     	cmp	x19, x8
10034bdf0:     	csel	x0, x19, x8, lo
10034bdf4:     	cmp	x8, x19
10034bdf8:     	b.hs	0x10034be88 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x198>
10034bdfc:     	cmp	x0, x19
10034be00:     	b.hs	0x10034bedc <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x1ec>
10034be04:     	ldrsb	w8, [x20, x0]
10034be08:     	tbz	w8, #0x1f, 0x10034bddc <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xec>
10034be0c:     	and	w8, w8, #0xff
10034be10:     	cmp	w8, #0xc0
10034be14:     	b.lo	0x10034bde4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xf4>
10034be18:     	add	x9, x0, #0x1
10034be1c:     	cmp	x9, x19
10034be20:     	b.hs	0x10034be4c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x15c>
10034be24:     	ldrb	w9, [x20, x9]
10034be28:     	and	w9, w9, #0x3f
10034be2c:     	cmp	w8, #0xe0
10034be30:     	b.lo	0x10034be58 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x168>
10034be34:     	cmp	w8, #0xf0
10034be38:     	b.hs	0x10034be78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x188>
10034be3c:     	ubfiz	w8, w8, #12, #4
10034be40:     	orr	w9, w8, w9, lsl #6
10034be44:     	mov	w8, #0x3                ; =3
10034be48:     	b	0x10034be5c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x16c>
10034be4c:     	mov	w9, #0x0                ; =0
10034be50:     	cmp	w8, #0xe0
10034be54:     	b.hs	0x10034be34 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x144>
10034be58:     	mov	w8, #0x2                ; =2
10034be5c:     	adds	w10, w23, #0x1
10034be60:     	csinv	w23, w10, wzr, lo
10034be64:     	lsr	w9, w9, #11
10034be68:     	cmp	w9, #0x1b
10034be6c:     	cset	w9, eq
10034be70:     	orr	w22, w22, w9
10034be74:     	b	0x10034bde8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xf8>
10034be78:     	adds	w8, w23, #0x2
10034be7c:     	csinv	w23, w8, wzr, lo
10034be80:     	mov	w8, #0x4                ; =4
10034be84:     	b	0x10034bde8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0xf8>
10034be88:     	mov	w8, #0xffe8             ; =65512
10034be8c:     	movk	w8, #0x1fff, lsl #16
10034be90:     	cmp	w23, w8
10034be94:     	b.hi	0x10034beec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes+0x1fc>
10034be98:     	mov	x0, x19
10034be9c:     	bl	0x10034b6ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10034bea0:     	mov	x21, x0
10034bea4:     	mov	x0, x1
10034bea8:     	stp	w23, w19, [x21]
10034beac:     	stp	w19, wzr, [x21, #0x8]
10034beb0:     	and	w8, w22, #0x1
10034beb4:     	str	w8, [x21, #0x10]
10034beb8:     	mov	x1, x20
10034bebc:     	mov	x2, x19
10034bec0:     	bl	0x100b644ec <_writev+0x100b644ec>
10034bec4:     	mov	x0, x21
10034bec8:     	ldp	x29, x30, [sp, #0x30]
10034becc:     	ldp	x20, x19, [sp, #0x20]
10034bed0:     	ldp	x22, x21, [sp, #0x10]
10034bed4:     	ldp	x24, x23, [sp], #0x40
10034bed8:     	b	0x1005ed938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6concat28canonicalize_surrogate_pairs>
10034bedc:     	adrp	x2, 0x100f0a000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json25PARSE_KEY_CACHE_OVERSIZED+0x3b0>
10034bee0:     	add	x2, x2, #0xbf0
10034bee4:     	mov	x1, x19
10034bee8:     	bl	0x100b14ecc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
10034beec:     	bl	0x10034bc8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string27throw_invalid_string_length>
