
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/specialized-json-token-length-r37/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007c2190 <_js_array_get_f64>:
1007c2190:     	sub	sp, sp, #0x70
1007c2194:     	stp	x26, x25, [sp, #0x20]
1007c2198:     	stp	x24, x23, [sp, #0x30]
1007c219c:     	stp	x22, x21, [sp, #0x40]
1007c21a0:     	stp	x20, x19, [sp, #0x50]
1007c21a4:     	stp	x29, x30, [sp, #0x60]
1007c21a8:     	add	x29, sp, #0x60
1007c21ac:     	mov	x19, x1
1007c21b0:     	mov	x22, x0
1007c21b4:     	lsr	x25, x0, #51
1007c21b8:     	mov	x20, x0
1007c21bc:     	cmp	x25, #0xfff
1007c21c0:     	b.lo	0x1007c21dc <_js_array_get_f64+0x4c>
1007c21c4:     	mov	w8, #0x7ffc             ; =32764
1007c21c8:     	cmp	x8, x22, lsr #48
1007c21cc:     	b.ne	0x1007c21d8 <_js_array_get_f64+0x48>
1007c21d0:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007c21d4:     	b	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c21d8:     	and	x20, x22, #0xffffffffffff
1007c21dc:     	lsr	x8, x20, #3
1007c21e0:     	cmp	x8, #0x200
1007c21e4:     	b.ls	0x1007c221c <_js_array_get_f64+0x8c>
1007c21e8:     	ldurb	w8, [x20, #-0x8]
1007c21ec:     	cmp	w8, #0x9
1007c21f0:     	b.ne	0x1007c221c <_js_array_get_f64+0x8c>
1007c21f4:     	ldr	w8, [x20, #0x4]
1007c21f8:     	mov	w9, #0x5841             ; =22593
1007c21fc:     	movk	w9, #0x4c5a, lsl #16
1007c2200:     	cmp	w8, w9
1007c2204:     	b.ne	0x1007c221c <_js_array_get_f64+0x8c>
1007c2208:     	mov	x0, x20
1007c220c:     	mov	x1, x19
1007c2210:     	bl	0x10068b544 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007c2214:     	fmov	d0, x0
1007c2218:     	b	0x1007c288c <_js_array_get_f64+0x6fc>
1007c221c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c2220:     	b.lo	0x1007c22d0 <_js_array_get_f64+0x140>
1007c2224:     	tst	x20, #0xffff800000000000
1007c2228:     	mov	w8, #0x1000             ; =4096
1007c222c:     	ccmp	x20, x8, #0x0, eq
1007c2230:     	b.lo	0x1007c22d0 <_js_array_get_f64+0x140>
1007c2234:     	ldurb	w24, [x20, #-0x8]
1007c2238:     	ldurh	w23, [x20, #-0x6]
1007c223c:     	cmp	w24, #0xa
1007c2240:     	b.gt	0x1007c23e8 <_js_array_get_f64+0x258>
1007c2244:     	cmp	w24, #0x2
1007c2248:     	b.eq	0x1007c2470 <_js_array_get_f64+0x2e0>
1007c224c:     	cmp	w24, #0x8
1007c2250:     	b.ne	0x1007c22d8 <_js_array_get_f64+0x148>
1007c2254:     	mov	x0, x20
1007c2258:     	bl	0x100307b28 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007c225c:     	cbz	w0, 0x1007c2500 <_js_array_get_f64+0x370>
1007c2260:     	mov	x22, #0x1               ; =1
1007c2264:     	movk	x22, #0x7ffc, lsl #48
1007c2268:     	lsr	x8, x20, #51
1007c226c:     	cmp	x8, #0xfff
1007c2270:     	b.lo	0x1007c2284 <_js_array_get_f64+0xf4>
1007c2274:     	mov	w8, #0x7ffc             ; =32764
1007c2278:     	cmp	x8, x20, lsr #48
1007c227c:     	b.eq	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c2280:     	and	x20, x20, #0xffffffffffff
1007c2284:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c2288:     	b.lo	0x1007c22a8 <_js_array_get_f64+0x118>
1007c228c:     	tst	x20, #0xffff800000000000
1007c2290:     	mov	w8, #0x1000             ; =4096
1007c2294:     	ccmp	x20, x8, #0x0, eq
1007c2298:     	b.lo	0x1007c22a8 <_js_array_get_f64+0x118>
1007c229c:     	ldurb	w8, [x20, #-0x8]
1007c22a0:     	cmp	w8, #0x2
1007c22a4:     	b.eq	0x1007c2b74 <_js_array_get_f64+0x9e4>
1007c22a8:     	cbz	x20, 0x1007c2888 <_js_array_get_f64+0x6f8>
1007c22ac:     	mov	x0, x20
1007c22b0:     	mov	x1, x19
1007c22b4:     	bl	0x100307cd8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007c22b8:     	cmp	w0, #0x1
1007c22bc:     	b.ne	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c22c0:     	ldr	x8, [x20, #0x8]
1007c22c4:     	ubfiz	x9, x1, #4, #32
1007c22c8:     	ldr	x22, [x8, x9]
1007c22cc:     	b	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c22d0:     	mov	w23, #0x0               ; =0
1007c22d4:     	mov	w24, #0x0               ; =0
1007c22d8:     	mov	x21, x22
1007c22dc:     	cmp	x25, #0xfff
1007c22e0:     	b.lo	0x1007c22f8 <_js_array_get_f64+0x168>
1007c22e4:     	mov	w8, #0x7ffc             ; =32764
1007c22e8:     	cmp	x8, x22, lsr #48
1007c22ec:     	b.eq	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c22f0:     	ands	x21, x22, #0xffffffffffff
1007c22f4:     	b.eq	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c22f8:     	and	x8, x21, #0xfffffffffff00000
1007c22fc:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007c2300:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007c2304:     	cmp	x9, x10
1007c2308:     	ccmp	x8, #0x0, #0x4, lo
1007c230c:     	b.eq	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c2310:     	tst	x21, #0x3
1007c2314:     	ccmp	x21, #0x7, #0x0, eq
1007c2318:     	b.ls	0x1007c25c8 <_js_array_get_f64+0x438>
1007c231c:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2320:     	ldr	x8, [x8, #0x48]
1007c2324:     	cmn	x8, #0x1
1007c2328:     	b.eq	0x1007c2518 <_js_array_get_f64+0x388>
1007c232c:     	mrs	x9, TPIDRRO_EL0
1007c2330:     	and	x9, x9, #0xfffffffffffffff8
1007c2334:     	ldr	x0, [x9, x8, lsl #3]
1007c2338:     	cbz	x0, 0x1007c2518 <_js_array_get_f64+0x388>
1007c233c:     	lsr	x1, x21, #20
1007c2340:     	ldr	x8, [x0, #0x10]
1007c2344:     	ldrb	w9, [x8]
1007c2348:     	cmp	w9, #0x2
1007c234c:     	b.ne	0x1007c2530 <_js_array_get_f64+0x3a0>
1007c2350:     	ldrb	w9, [x8, #0x88]
1007c2354:     	tbz	w9, #0x0, 0x1007c2374 <_js_array_get_f64+0x1e4>
1007c2358:     	ldr	x9, [x8, #0x80]
1007c235c:     	cmp	x9, x1
1007c2360:     	b.ne	0x1007c2374 <_js_array_get_f64+0x1e4>
1007c2364:     	ldp	x9, x10, [x8, #0x60]
1007c2368:     	cmp	x9, x21
1007c236c:     	ccmp	x10, x21, #0x0, ls
1007c2370:     	b.hi	0x1007c2510 <_js_array_get_f64+0x380>
1007c2374:     	ldrb	w9, [x8, #0xb8]
1007c2378:     	cbz	w9, 0x1007c2398 <_js_array_get_f64+0x208>
1007c237c:     	ldr	x9, [x8, #0xb0]
1007c2380:     	cmp	x9, x1
1007c2384:     	b.ne	0x1007c2398 <_js_array_get_f64+0x208>
1007c2388:     	ldp	x9, x10, [x8, #0x90]
1007c238c:     	cmp	x9, x21
1007c2390:     	ccmp	x10, x21, #0x0, ls
1007c2394:     	b.hi	0x1007c29d8 <_js_array_get_f64+0x848>
1007c2398:     	ldrb	w9, [x8, #0xe8]
1007c239c:     	cbz	w9, 0x1007c23bc <_js_array_get_f64+0x22c>
1007c23a0:     	ldr	x9, [x8, #0xe0]
1007c23a4:     	cmp	x9, x1
1007c23a8:     	b.ne	0x1007c23bc <_js_array_get_f64+0x22c>
1007c23ac:     	ldp	x9, x10, [x8, #0xc0]
1007c23b0:     	cmp	x9, x21
1007c23b4:     	ccmp	x10, x21, #0x0, ls
1007c23b8:     	b.hi	0x1007c2ac0 <_js_array_get_f64+0x930>
1007c23bc:     	ldrb	w9, [x8, #0x118]
1007c23c0:     	cbz	w9, 0x1007c2590 <_js_array_get_f64+0x400>
1007c23c4:     	ldr	x9, [x8, #0x110]
1007c23c8:     	cmp	x9, x1
1007c23cc:     	b.ne	0x1007c2590 <_js_array_get_f64+0x400>
1007c23d0:     	ldp	x9, x10, [x8, #0xf0]
1007c23d4:     	cmp	x9, x21
1007c23d8:     	ccmp	x10, x21, #0x0, ls
1007c23dc:     	b.ls	0x1007c2590 <_js_array_get_f64+0x400>
1007c23e0:     	add	x9, x8, #0xf0
1007c23e4:     	b	0x1007c2ac4 <_js_array_get_f64+0x934>
1007c23e8:     	cmp	w24, #0xb
1007c23ec:     	b.eq	0x1007c2488 <_js_array_get_f64+0x2f8>
1007c23f0:     	cmp	w24, #0xc
1007c23f4:     	b.ne	0x1007c22d8 <_js_array_get_f64+0x148>
1007c23f8:     	mov	x0, x20
1007c23fc:     	bl	0x10030d8b8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007c2400:     	cbz	w0, 0x1007c2508 <_js_array_get_f64+0x378>
1007c2404:     	mov	x22, #0x1               ; =1
1007c2408:     	movk	x22, #0x7ffc, lsl #48
1007c240c:     	lsr	x8, x20, #51
1007c2410:     	cmp	x8, #0xfff
1007c2414:     	b.lo	0x1007c2428 <_js_array_get_f64+0x298>
1007c2418:     	mov	w8, #0x7ffc             ; =32764
1007c241c:     	cmp	x8, x20, lsr #48
1007c2420:     	b.eq	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c2424:     	and	x20, x20, #0xffffffffffff
1007c2428:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007c242c:     	b.lo	0x1007c244c <_js_array_get_f64+0x2bc>
1007c2430:     	tst	x20, #0xffff800000000000
1007c2434:     	mov	w8, #0x1000             ; =4096
1007c2438:     	ccmp	x20, x8, #0x0, eq
1007c243c:     	b.lo	0x1007c244c <_js_array_get_f64+0x2bc>
1007c2440:     	ldurb	w8, [x20, #-0x8]
1007c2444:     	cmp	w8, #0x2
1007c2448:     	b.eq	0x1007c2b8c <_js_array_get_f64+0x9fc>
1007c244c:     	cbz	x20, 0x1007c2888 <_js_array_get_f64+0x6f8>
1007c2450:     	mov	x0, x20
1007c2454:     	mov	x1, x19
1007c2458:     	bl	0x10030f530 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007c245c:     	cmp	w0, #0x1
1007c2460:     	b.ne	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c2464:     	ldr	x8, [x20, #0x8]
1007c2468:     	ldr	x22, [x8, w1, uxtw #3]
1007c246c:     	b	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c2470:     	mov	x0, x22
1007c2474:     	mov	x1, x19
1007c2478:     	bl	0x10054b20c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007c247c:     	tbnz	w0, #0x0, 0x1007c2884 <_js_array_get_f64+0x6f4>
1007c2480:     	mov	w24, #0x2               ; =2
1007c2484:     	b	0x1007c22d8 <_js_array_get_f64+0x148>
1007c2488:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c248c:     	add	x8, x8, #0xec0
1007c2490:     	ldaprb	w8, [x8]
1007c2494:     	cbz	w8, 0x1007c24f8 <_js_array_get_f64+0x368>
1007c2498:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c249c:     	add	x8, x8, #0x58
1007c24a0:     	ldapr	x8, [x8]
1007c24a4:     	cmp	x20, x8
1007c24a8:     	b.lo	0x1007c24f8 <_js_array_get_f64+0x368>
1007c24ac:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c24b0:     	add	x8, x8, #0x60
1007c24b4:     	ldapr	x8, [x8]
1007c24b8:     	cmp	x20, x8
1007c24bc:     	b.hi	0x1007c24f8 <_js_array_get_f64+0x368>
1007c24c0:     	mov	x0, x20
1007c24c4:     	bl	0x1002a75f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c24c8:     	tbz	w0, #0x0, 0x1007c24f8 <_js_array_get_f64+0x368>
1007c24cc:     	add	x0, sp, #0x8
1007c24d0:     	mov	x1, x20
1007c24d4:     	bl	0x1002a742c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007c24d8:     	ldr	x8, [sp, #0x8]
1007c24dc:     	cbz	x8, 0x1007c2b04 <_js_array_get_f64+0x974>
1007c24e0:     	cmp	x8, #0x1
1007c24e4:     	b.ne	0x1007c2b48 <_js_array_get_f64+0x9b8>
1007c24e8:     	ldr	d0, [sp, #0x10]
1007c24ec:     	scvtf	d1, w19
1007c24f0:     	bl	0x100820734 <_js_dyn_index_get>
1007c24f4:     	b	0x1007c2884 <_js_array_get_f64+0x6f4>
1007c24f8:     	mov	w24, #0xb               ; =11
1007c24fc:     	b	0x1007c22d8 <_js_array_get_f64+0x148>
1007c2500:     	mov	w24, #0x8               ; =8
1007c2504:     	b	0x1007c22d8 <_js_array_get_f64+0x148>
1007c2508:     	mov	w24, #0xc               ; =12
1007c250c:     	b	0x1007c22d8 <_js_array_get_f64+0x148>
1007c2510:     	add	x9, x8, #0x60
1007c2514:     	b	0x1007c2ac4 <_js_array_get_f64+0x934>
1007c2518:     	bl	0x100b43bfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007c251c:     	lsr	x1, x21, #20
1007c2520:     	ldr	x8, [x0, #0x10]
1007c2524:     	ldrb	w9, [x8]
1007c2528:     	cmp	w9, #0x2
1007c252c:     	b.eq	0x1007c2350 <_js_array_get_f64+0x1c0>
1007c2530:     	ldr	x9, [x8, #0x8]
1007c2534:     	ldr	x10, [x8, #0x28]
1007c2538:     	sub	x9, x1, x9
1007c253c:     	cmp	x9, x10
1007c2540:     	b.hs	0x1007c2584 <_js_array_get_f64+0x3f4>
1007c2544:     	ldr	x10, [x8, #0x20]
1007c2548:     	mov	w11, #0x28              ; =40
1007c254c:     	madd	x9, x9, x11, x10
1007c2550:     	ldr	x10, [x9]
1007c2554:     	ldr	x11, [x8, #0x10]
1007c2558:     	cmp	x10, x11
1007c255c:     	b.ne	0x1007c2590 <_js_array_get_f64+0x400>
1007c2560:     	ldp	x10, x11, [x9, #0x8]
1007c2564:     	cmp	x10, x21
1007c2568:     	ccmp	x11, x21, #0x0, ls
1007c256c:     	b.ls	0x1007c2590 <_js_array_get_f64+0x400>
1007c2570:     	ldr	x10, [x8, #0x30]
1007c2574:     	add	x10, x10, #0x1
1007c2578:     	str	x10, [x8, #0x30]
1007c257c:     	add	x8, x9, #0x21
1007c2580:     	b	0x1007c2ad4 <_js_array_get_f64+0x944>
1007c2584:     	ldr	x9, [x8, #0x58]
1007c2588:     	add	x9, x9, #0x1
1007c258c:     	str	x9, [x8, #0x58]
1007c2590:     	ldr	x9, [x8, #0x38]
1007c2594:     	add	x9, x9, #0x1
1007c2598:     	str	x9, [x8, #0x38]
1007c259c:     	mov	x0, x21
1007c25a0:     	bl	0x100520f48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007c25a4:     	and	w8, w0, #0xff
1007c25a8:     	cbz	w8, 0x1007c25c8 <_js_array_get_f64+0x438>
1007c25ac:     	ldurb	w8, [x21, #-0x8]
1007c25b0:     	ldurb	w9, [x21, #-0x7]
1007c25b4:     	mov	w10, #0x82              ; =130
1007c25b8:     	and	w9, w9, w10
1007c25bc:     	cmp	w9, #0x2
1007c25c0:     	ccmp	w8, #0x1, #0x0, eq
1007c25c4:     	b.eq	0x1007c2698 <_js_array_get_f64+0x508>
1007c25c8:     	mov	x0, x21
1007c25cc:     	bl	0x10057d5c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c25d0:     	cbz	x0, 0x1007c25f8 <_js_array_get_f64+0x468>
1007c25d4:     	ldrb	w9, [x0]
1007c25d8:     	cmp	w9, #0x1
1007c25dc:     	b.ne	0x1007c2614 <_js_array_get_f64+0x484>
1007c25e0:     	ldrsb	w8, [x0, #0x1]
1007c25e4:     	tbnz	w8, #0x1f, 0x1007c26c0 <_js_array_get_f64+0x530>
1007c25e8:     	ldp	w10, w9, [x21]
1007c25ec:     	cmp	w10, w9
1007c25f0:     	b.hi	0x1007c274c <_js_array_get_f64+0x5bc>
1007c25f4:     	b	0x1007c2764 <_js_array_get_f64+0x5d4>
1007c25f8:     	mov	x25, x0
1007c25fc:     	mov	x0, x21
1007c2600:     	bl	0x10058bdf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c2604:     	tbz	w0, #0x0, 0x1007c2650 <_js_array_get_f64+0x4c0>
1007c2608:     	mov	x0, #0x0                ; =0
1007c260c:     	mov	x8, x25
1007c2610:     	b	0x1007c273c <_js_array_get_f64+0x5ac>
1007c2614:     	mov	x8, x0
1007c2618:     	cmp	w9, #0x1
1007c261c:     	b.eq	0x1007c273c <_js_array_get_f64+0x5ac>
1007c2620:     	cmp	w9, #0x9
1007c2624:     	b.ne	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c2628:     	ldr	w8, [x21, #0x4]
1007c262c:     	mov	w9, #0x5841             ; =22593
1007c2630:     	movk	w9, #0x4c5a, lsl #16
1007c2634:     	cmp	w8, w9
1007c2638:     	b.ne	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c263c:     	mov	x0, x21
1007c2640:     	bl	0x1003787d0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007c2644:     	cbz	x0, 0x1007c2874 <_js_array_get_f64+0x6e4>
1007c2648:     	mov	x21, x0
1007c264c:     	b	0x1007c2780 <_js_array_get_f64+0x5f0>
1007c2650:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2654:     	add	x8, x8, #0xec0
1007c2658:     	ldaprb	w8, [x8]
1007c265c:     	cbz	w8, 0x1007c2874 <_js_array_get_f64+0x6e4>
1007c2660:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2664:     	add	x8, x8, #0x58
1007c2668:     	ldapr	x8, [x8]
1007c266c:     	cmp	x8, x21
1007c2670:     	b.hi	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c2674:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2678:     	add	x8, x8, #0x60
1007c267c:     	ldapr	x8, [x8]
1007c2680:     	cmp	x8, x21
1007c2684:     	b.lo	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c2688:     	mov	x0, x21
1007c268c:     	bl	0x1002a75f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2690:     	tbnz	w0, #0x0, 0x1007c2608 <_js_array_get_f64+0x478>
1007c2694:     	b	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c2698:     	ldr	w8, [x21]
1007c269c:     	mov	w9, #0xe100             ; =57600
1007c26a0:     	movk	w9, #0x5f5, lsl #16
1007c26a4:     	orr	w9, w9, #0x1
1007c26a8:     	cmp	w8, w9
1007c26ac:     	b.hs	0x1007c25c8 <_js_array_get_f64+0x438>
1007c26b0:     	ldr	w9, [x21, #0x4]
1007c26b4:     	cmp	w8, w9
1007c26b8:     	b.ls	0x1007c2780 <_js_array_get_f64+0x5f0>
1007c26bc:     	b	0x1007c25c8 <_js_array_get_f64+0x438>
1007c26c0:     	mov	x25, x0
1007c26c4:     	ldr	x21, [x0, #0x8]
1007c26c8:     	mov	x0, x21
1007c26cc:     	bl	0x10057d5c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c26d0:     	cbz	x0, 0x1007c2874 <_js_array_get_f64+0x6e4>
1007c26d4:     	ldrb	w8, [x0]
1007c26d8:     	cmp	w8, #0x1
1007c26dc:     	b.ne	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c26e0:     	ldrsb	w8, [x0, #0x1]
1007c26e4:     	tbz	w8, #0x1f, 0x1007c25e8 <_js_array_get_f64+0x458>
1007c26e8:     	mov	w26, #0x1               ; =1
1007c26ec:     	ldr	x21, [x0, #0x8]
1007c26f0:     	mov	x0, x21
1007c26f4:     	bl	0x10057d5c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007c26f8:     	cbz	x0, 0x1007c2874 <_js_array_get_f64+0x6e4>
1007c26fc:     	ldrb	w8, [x0]
1007c2700:     	cmp	w8, #0x1
1007c2704:     	b.ne	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c2708:     	cmp	w26, #0x3f
1007c270c:     	b.hi	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c2710:     	add	w26, w26, #0x1
1007c2714:     	ldrsb	w8, [x0, #0x1]
1007c2718:     	tbnz	w8, #0x1f, 0x1007c26ec <_js_array_get_f64+0x55c>
1007c271c:     	str	x21, [x25, #0x8]
1007c2720:     	ldrb	w8, [x25, #0x1]
1007c2724:     	orr	w9, w8, #0x80
1007c2728:     	mov	x8, x25
1007c272c:     	strb	w9, [x25, #0x1]
1007c2730:     	ldrb	w9, [x0]
1007c2734:     	cmp	w9, #0x1
1007c2738:     	b.ne	0x1007c2620 <_js_array_get_f64+0x490>
1007c273c:     	ldp	w10, w9, [x21]
1007c2740:     	cmp	w10, w9
1007c2744:     	b.ls	0x1007c2764 <_js_array_get_f64+0x5d4>
1007c2748:     	cbz	x8, 0x1007c2774 <_js_array_get_f64+0x5e4>
1007c274c:     	ldr	w8, [x0, #0x4]
1007c2750:     	ubfiz	x9, x9, #3, #32
1007c2754:     	add	x9, x9, #0x10
1007c2758:     	cmp	x9, x8
1007c275c:     	b.eq	0x1007c2780 <_js_array_get_f64+0x5f0>
1007c2760:     	b	0x1007c2774 <_js_array_get_f64+0x5e4>
1007c2764:     	mov	w8, #0xe100             ; =57600
1007c2768:     	movk	w8, #0x5f5, lsl #16
1007c276c:     	cmp	w10, w8
1007c2770:     	b.ls	0x1007c2780 <_js_array_get_f64+0x5f0>
1007c2774:     	mov	x0, x21
1007c2778:     	bl	0x10058bdf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c277c:     	tbz	w0, #0x0, 0x1007c2830 <_js_array_get_f64+0x6a0>
1007c2780:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2784:     	add	x8, x8, #0xec0
1007c2788:     	ldaprb	w8, [x8]
1007c278c:     	cbz	w8, 0x1007c27d4 <_js_array_get_f64+0x644>
1007c2790:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2794:     	add	x8, x8, #0x58
1007c2798:     	ldapr	x8, [x8]
1007c279c:     	cmp	x21, x8
1007c27a0:     	b.lo	0x1007c27d4 <_js_array_get_f64+0x644>
1007c27a4:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c27a8:     	add	x8, x8, #0x60
1007c27ac:     	ldapr	x8, [x8]
1007c27b0:     	cmp	x21, x8
1007c27b4:     	b.hi	0x1007c27d4 <_js_array_get_f64+0x644>
1007c27b8:     	mov	x0, x21
1007c27bc:     	bl	0x1002a75f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c27c0:     	tbz	w0, #0x0, 0x1007c27d4 <_js_array_get_f64+0x644>
1007c27c4:     	mov	x0, x21
1007c27c8:     	mov	x1, x19
1007c27cc:     	bl	0x100900448 <_js_typed_array_get>
1007c27d0:     	b	0x1007c2884 <_js_array_get_f64+0x6f4>
1007c27d4:     	mov	x0, x21
1007c27d8:     	bl	0x10058bdf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007c27dc:     	tbz	w0, #0x0, 0x1007c2804 <_js_array_get_f64+0x674>
1007c27e0:     	mov	x0, x21
1007c27e4:     	mov	x1, x19
1007c27e8:     	bl	0x10058911c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007c27ec:     	and	w8, w1, #0xff
1007c27f0:     	ucvtf	d0, w8
1007c27f4:     	fmov	x8, d0
1007c27f8:     	tst	w0, #0x1
1007c27fc:     	csel	x22, x8, xzr, ne
1007c2800:     	b	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c2804:     	cmp	x21, x20
1007c2808:     	b.eq	0x1007c28b0 <_js_array_get_f64+0x720>
1007c280c:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007c2810:     	b.lo	0x1007c28a8 <_js_array_get_f64+0x718>
1007c2814:     	tst	x21, #0xffff800000000000
1007c2818:     	mov	w8, #0x1000             ; =4096
1007c281c:     	ccmp	x21, x8, #0x0, eq
1007c2820:     	b.lo	0x1007c28a8 <_js_array_get_f64+0x718>
1007c2824:     	ldurb	w24, [x21, #-0x8]
1007c2828:     	ldurh	w23, [x21, #-0x6]
1007c282c:     	b	0x1007c28b0 <_js_array_get_f64+0x720>
1007c2830:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2834:     	add	x8, x8, #0xec0
1007c2838:     	ldaprb	w8, [x8]
1007c283c:     	cbz	w8, 0x1007c2874 <_js_array_get_f64+0x6e4>
1007c2840:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2844:     	add	x8, x8, #0x58
1007c2848:     	ldapr	x8, [x8]
1007c284c:     	cmp	x21, x8
1007c2850:     	b.lo	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c2854:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1007c2858:     	add	x8, x8, #0x60
1007c285c:     	ldapr	x8, [x8]
1007c2860:     	cmp	x21, x8
1007c2864:     	b.hi	0x1007c2874 <_js_array_get_f64+0x6e4>
1007c2868:     	mov	x0, x21
1007c286c:     	bl	0x1002a75f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007c2870:     	tbnz	w0, #0x0, 0x1007c2780 <_js_array_get_f64+0x5f0>
1007c2874:     	mov	x0, x22
1007c2878:     	mov	x1, x19
1007c287c:     	bl	0x10054b20c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007c2880:     	tbz	w0, #0x0, 0x1007c2b58 <_js_array_get_f64+0x9c8>
1007c2884:     	fmov	x22, d0
1007c2888:     	fmov	d0, x22
1007c288c:     	ldp	x29, x30, [sp, #0x60]
1007c2890:     	ldp	x20, x19, [sp, #0x50]
1007c2894:     	ldp	x22, x21, [sp, #0x40]
1007c2898:     	ldp	x24, x23, [sp, #0x30]
1007c289c:     	ldp	x26, x25, [sp, #0x20]
1007c28a0:     	add	sp, sp, #0x70
1007c28a4:     	ret
1007c28a8:     	mov	w23, #0x0               ; =0
1007c28ac:     	mov	w24, #0x0               ; =0
1007c28b0:     	cmp	w24, #0x1
1007c28b4:     	b.ne	0x1007c2a68 <_js_array_get_f64+0x8d8>
1007c28b8:     	tbz	w23, #0xa, 0x1007c2a68 <_js_array_get_f64+0x8d8>
1007c28bc:     	adrp	x8, 0x100b69000 <_anon.2aa35172874dc18ddd0733027929dfee.3+0x58>
1007c28c0:     	add	x8, x8, #0x64c
1007c28c4:     	cmp	w19, #0x3e8
1007c28c8:     	b.lo	0x1007c2940 <_js_array_get_f64+0x7b0>
1007c28cc:     	mov	x9, #0x0                ; =0
1007c28d0:     	mov	w11, #0x1759            ; =5977
1007c28d4:     	movk	w11, #0xd1b7, lsl #16
1007c28d8:     	mov	w12, #0x2710            ; =10000
1007c28dc:     	mov	w13, #0x147b            ; =5243
1007c28e0:     	mov	w14, #0x64              ; =100
1007c28e4:     	add	x15, sp, #0x8
1007c28e8:     	mov	w16, #0x967f            ; =38527
1007c28ec:     	movk	w16, #0x98, lsl #16
1007c28f0:     	mov	x10, x19
1007c28f4:     	mov	x17, x10
1007c28f8:     	umull	x10, w10, w11
1007c28fc:     	lsr	x10, x10, #45
1007c2900:     	msub	w0, w10, w12, w17
1007c2904:     	ubfx	w1, w0, #2, #14
1007c2908:     	mul	w1, w1, w13
1007c290c:     	lsr	w1, w1, #17
1007c2910:     	msub	w0, w1, w14, w0
1007c2914:     	add	x2, x15, x9
1007c2918:     	ldrh	w1, [x8, w1, uxtw #1]
1007c291c:     	strh	w1, [x2, #0x6]
1007c2920:     	and	x0, x0, #0xffff
1007c2924:     	ldrh	w0, [x8, x0, lsl #1]
1007c2928:     	strh	w0, [x2, #0x8]
1007c292c:     	sub	x9, x9, #0x4
1007c2930:     	cmp	w17, w16
1007c2934:     	b.hi	0x1007c28f4 <_js_array_get_f64+0x764>
1007c2938:     	add	x9, x9, #0xa
1007c293c:     	b	0x1007c2948 <_js_array_get_f64+0x7b8>
1007c2940:     	mov	w9, #0xa                ; =10
1007c2944:     	mov	x10, x19
1007c2948:     	cmp	w10, #0x9
1007c294c:     	b.ls	0x1007c2980 <_js_array_get_f64+0x7f0>
1007c2950:     	sub	x9, x9, #0x2
1007c2954:     	ubfx	w11, w10, #2, #14
1007c2958:     	mov	w12, #0x147b            ; =5243
1007c295c:     	mul	w11, w11, w12
1007c2960:     	lsr	w11, w11, #17
1007c2964:     	mov	w12, #0x64              ; =100
1007c2968:     	msub	w10, w11, w12, w10
1007c296c:     	and	x10, x10, #0xffff
1007c2970:     	ldrh	w10, [x8, x10, lsl #1]
1007c2974:     	add	x12, sp, #0x8
1007c2978:     	strh	w10, [x12, x9]
1007c297c:     	mov	x10, x11
1007c2980:     	cbz	w19, 0x1007c29b8 <_js_array_get_f64+0x828>
1007c2984:     	cbnz	w10, 0x1007c29b8 <_js_array_get_f64+0x828>
1007c2988:     	cmp	x9, #0xa
1007c298c:     	b.ne	0x1007c29e0 <_js_array_get_f64+0x850>
1007c2990:     	mov	w23, #0x1               ; =1
1007c2994:     	add	x0, sp, #0x8
1007c2998:     	mov	x1, x21
1007c299c:     	mov	w2, #0x1                ; =1
1007c29a0:     	mov	x3, #0x0                ; =0
1007c29a4:     	bl	0x1005b54fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007c29a8:     	ldr	x8, [sp, #0x8]
1007c29ac:     	mov	w20, #0x1               ; =1
1007c29b0:     	cbnz	x8, 0x1007c2a30 <_js_array_get_f64+0x8a0>
1007c29b4:     	b	0x1007c2a68 <_js_array_get_f64+0x8d8>
1007c29b8:     	sub	x23, x9, #0x1
1007c29bc:     	ubfiz	w10, w10, #1, #4
1007c29c0:     	add	x8, x8, x10
1007c29c4:     	ldrb	w8, [x8, #0x1]
1007c29c8:     	add	x10, sp, #0x8
1007c29cc:     	strb	w8, [x10, x23]
1007c29d0:     	mov	w8, #0xb                ; =11
1007c29d4:     	b	0x1007c29e8 <_js_array_get_f64+0x858>
1007c29d8:     	add	x9, x8, #0x90
1007c29dc:     	b	0x1007c2ac4 <_js_array_get_f64+0x934>
1007c29e0:     	mov	w8, #0xa                ; =10
1007c29e4:     	mov	x23, x9
1007c29e8:     	sub	x22, x8, x9
1007c29ec:     	mov	x0, x22
1007c29f0:     	mov	w1, #0x1                ; =1
1007c29f4:     	bl	0x100b63a88 <_mi_malloc_aligned>
1007c29f8:     	cbz	x0, 0x1007c2ba4 <_js_array_get_f64+0xa14>
1007c29fc:     	mov	x20, x0
1007c2a00:     	add	x8, sp, #0x8
1007c2a04:     	add	x1, x8, x23
1007c2a08:     	mov	x2, x22
1007c2a0c:     	bl	0x100b666ac <_writev+0x100b666ac>
1007c2a10:     	add	x0, sp, #0x8
1007c2a14:     	mov	x1, x21
1007c2a18:     	mov	x2, x20
1007c2a1c:     	mov	x3, x22
1007c2a20:     	bl	0x1005b54fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007c2a24:     	ldr	w8, [sp, #0x8]
1007c2a28:     	tbz	w8, #0x0, 0x1007c2a60 <_js_array_get_f64+0x8d0>
1007c2a2c:     	mov	w23, #0x0               ; =0
1007c2a30:     	mov	x22, #0x1               ; =1
1007c2a34:     	movk	x22, #0x7ffc, lsl #48
1007c2a38:     	ldr	x0, [sp, #0x10]
1007c2a3c:     	cbz	x0, 0x1007c2af4 <_js_array_get_f64+0x964>
1007c2a40:     	cbz	x21, 0x1007c2ae4 <_js_array_get_f64+0x954>
1007c2a44:     	lsr	x8, x21, #52
1007c2a48:     	cmp	x8, #0x7fe
1007c2a4c:     	b.hi	0x1007c2ae8 <_js_array_get_f64+0x958>
1007c2a50:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007c2a54:     	bfxil	x8, x21, #0, #48
1007c2a58:     	mov	x21, x8
1007c2a5c:     	b	0x1007c2ae8 <_js_array_get_f64+0x958>
1007c2a60:     	mov	x0, x20
1007c2a64:     	bl	0x100b63800 <_mi_free>
1007c2a68:     	ldr	w8, [x21]
1007c2a6c:     	cmp	w19, w8
1007c2a70:     	b.hs	0x1007c2ab0 <_js_array_get_f64+0x920>
1007c2a74:     	ldr	w8, [x21, #0x4]
1007c2a78:     	cmp	w19, w8
1007c2a7c:     	b.hs	0x1007c2aa0 <_js_array_get_f64+0x910>
1007c2a80:     	add	x8, x21, w19, uxtw #3
1007c2a84:     	ldr	x22, [x8, #0x8]
1007c2a88:     	mov	x8, #0x1                ; =1
1007c2a8c:     	movk	x8, #0x7ffc, lsl #48
1007c2a90:     	add	x8, x8, #0xf
1007c2a94:     	cmp	x22, x8
1007c2a98:     	b.ne	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c2a9c:     	b	0x1007c2ab0 <_js_array_get_f64+0x920>
1007c2aa0:     	mov	x0, x21
1007c2aa4:     	mov	x1, x19
1007c2aa8:     	bl	0x10052d604 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007c2aac:     	tbnz	w0, #0x0, 0x1007c2884 <_js_array_get_f64+0x6f4>
1007c2ab0:     	mov	x0, x21
1007c2ab4:     	mov	x1, x19
1007c2ab8:     	bl	0x1006cb4a4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007c2abc:     	b	0x1007c2884 <_js_array_get_f64+0x6f4>
1007c2ac0:     	add	x9, x8, #0xc0
1007c2ac4:     	ldr	x10, [x8, #0x30]
1007c2ac8:     	add	x10, x10, #0x1
1007c2acc:     	str	x10, [x8, #0x30]
1007c2ad0:     	add	x8, x9, #0x19
1007c2ad4:     	ldrb	w8, [x8]
1007c2ad8:     	cmp	w8, #0xff
1007c2adc:     	b.ne	0x1007c25a8 <_js_array_get_f64+0x418>
1007c2ae0:     	b	0x1007c259c <_js_array_get_f64+0x40c>
1007c2ae4:     	add	x21, x22, #0x1
1007c2ae8:     	fmov	d0, x21
1007c2aec:     	bl	0x1007012bc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007c2af0:     	mov	x22, x0
1007c2af4:     	tbnz	w23, #0x0, 0x1007c2888 <_js_array_get_f64+0x6f8>
1007c2af8:     	mov	x0, x20
1007c2afc:     	bl	0x100b63800 <_mi_free>
1007c2b00:     	b	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c2b04:     	ldr	x20, [sp, #0x10]
1007c2b08:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007c2b0c:     	ldr	x8, [x8, #0xed8]
1007c2b10:     	cbz	x8, 0x1007c2b28 <_js_array_get_f64+0x998>
1007c2b14:     	mov	x0, x20
1007c2b18:     	bl	0x10013cc40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007c2b1c:     	tbz	w0, #0x0, 0x1007c2b28 <_js_array_get_f64+0x998>
1007c2b20:     	mov	x0, x20
1007c2b24:     	bl	0x1002c1800 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007c2b28:     	tbnz	w19, #0x1f, 0x1007c2b48 <_js_array_get_f64+0x9b8>
1007c2b2c:     	ldr	w8, [x20]
1007c2b30:     	cmp	w19, w8
1007c2b34:     	b.hs	0x1007c2b48 <_js_array_get_f64+0x9b8>
1007c2b38:     	mov	w1, w19
1007c2b3c:     	mov	x0, x20
1007c2b40:     	bl	0x1002a7a8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007c2b44:     	b	0x1007c2884 <_js_array_get_f64+0x6f4>
1007c2b48:     	mov	x8, #0x1                ; =1
1007c2b4c:     	movk	x8, #0x7ffc, lsl #48
1007c2b50:     	mov	x22, x8
1007c2b54:     	b	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c2b58:     	mov	x0, x22
1007c2b5c:     	bl	0x100b4c170 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007c2b60:     	cmp	x0, #0x1
1007c2b64:     	b.ne	0x1007c21d0 <_js_array_get_f64+0x40>
1007c2b68:     	mov	x0, x19
1007c2b6c:     	bl	0x100b4c190 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007c2b70:     	b	0x1007c2884 <_js_array_get_f64+0x6f4>
1007c2b74:     	mov	x0, x20
1007c2b78:     	mov	w1, #0x0                ; =0
1007c2b7c:     	bl	0x100b4e700 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007c2b80:     	mov	x20, x0
1007c2b84:     	cbnz	x0, 0x1007c22ac <_js_array_get_f64+0x11c>
1007c2b88:     	b	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c2b8c:     	mov	x0, x20
1007c2b90:     	mov	w1, #0x1                ; =1
1007c2b94:     	bl	0x100b4e700 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007c2b98:     	mov	x20, x0
1007c2b9c:     	cbnz	x0, 0x1007c2450 <_js_array_get_f64+0x2c0>
1007c2ba0:     	b	0x1007c2888 <_js_array_get_f64+0x6f8>
1007c2ba4:     	mov	w0, #0x1                ; =1
1007c2ba8:     	mov	x1, x22
1007c2bac:     	bl	0x100b16b80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
