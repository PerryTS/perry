
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/specialized-json-token-length-r37/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100849d80 <_js_json_stringify_full>:
100849d80:     	sub	sp, sp, #0x120
100849d84:     	stp	d9, d8, [sp, #0xb0]
100849d88:     	stp	x28, x27, [sp, #0xc0]
100849d8c:     	stp	x26, x25, [sp, #0xd0]
100849d90:     	stp	x24, x23, [sp, #0xe0]
100849d94:     	stp	x22, x21, [sp, #0xf0]
100849d98:     	stp	x20, x19, [sp, #0x100]
100849d9c:     	stp	x29, x30, [sp, #0x110]
100849da0:     	add	x29, sp, #0x110
100849da4:     	mov.16b	v9, v2
100849da8:     	mov.16b	v8, v0
100849dac:     	fmov	x19, d8
100849db0:     	fmov	x21, d1
100849db4:     	fmov	x23, d9
100849db8:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100849dbc:     	add	x27, x21, x8
100849dc0:     	add	x24, x23, x8
100849dc4:     	fcmp	d2, #0.0
100849dc8:     	ccmp	x24, #0x2, #0x0, ne
100849dcc:     	b.hi	0x100849ddc <_js_json_stringify_full+0x5c>
100849dd0:     	cmp	x27, #0x2
100849dd4:     	b.lo	0x100849dec <_js_json_stringify_full+0x6c>
100849dd8:     	b	0x10084a358 <_js_json_stringify_full+0x5d8>
100849ddc:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
100849de0:     	cmp	x23, x8
100849de4:     	ccmp	x27, #0x2, #0x2, eq
100849de8:     	b.hs	0x10084a358 <_js_json_stringify_full+0x5d8>
100849dec:     	mov	x8, #-0x2               ; =-2
100849df0:     	movk	x8, #0x8003, lsl #48
100849df4:     	add	x8, x19, x8
100849df8:     	cmp	x8, #0x3
100849dfc:     	b.hs	0x100849e10 <_js_json_stringify_full+0x90>
100849e00:     	adrp	x9, 0x100c9d000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x45f0>
100849e04:     	add	x9, x9, #0xf98
100849e08:     	ldr	x20, [x9, x8, lsl #3]
100849e0c:     	b	0x10084b228 <_js_json_stringify_full+0x14a8>
100849e10:     	strb	wzr, [sp, #0x4c]
100849e14:     	str	wzr, [sp, #0x48]
100849e18:     	and	x8, x19, #0xffff000000000000
100849e1c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100849e20:     	cmp	x8, x9
100849e24:     	b.eq	0x100849e98 <_js_json_stringify_full+0x118>
100849e28:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100849e2c:     	cmp	x8, x9
100849e30:     	b.ne	0x10084a294 <_js_json_stringify_full+0x514>
100849e34:     	ubfx	x10, x19, #40, #8
100849e38:     	cbz	x10, 0x100849e88 <_js_json_stringify_full+0x108>
100849e3c:     	strb	w19, [sp, #0x48]
100849e40:     	cmp	x10, #0x1
100849e44:     	b.eq	0x100849e88 <_js_json_stringify_full+0x108>
100849e48:     	lsr	x9, x19, #8
100849e4c:     	strb	w9, [sp, #0x49]
100849e50:     	cmp	x10, #0x2
100849e54:     	b.eq	0x100849e88 <_js_json_stringify_full+0x108>
100849e58:     	lsr	x9, x19, #16
100849e5c:     	strb	w9, [sp, #0x4a]
100849e60:     	cmp	x10, #0x3
100849e64:     	b.eq	0x100849e88 <_js_json_stringify_full+0x108>
100849e68:     	lsr	x9, x19, #24
100849e6c:     	strb	w9, [sp, #0x4b]
100849e70:     	cmp	x10, #0x4
100849e74:     	b.eq	0x100849e88 <_js_json_stringify_full+0x108>
100849e78:     	lsr	x9, x19, #32
100849e7c:     	strb	w9, [sp, #0x4c]
100849e80:     	cmp	x10, #0x5
100849e84:     	b.ne	0x10084b9fc <_js_json_stringify_full+0x1c7c>
100849e88:     	add	x11, sp, #0x48
100849e8c:     	cmp	w10, #0x3
100849e90:     	b.ls	0x100849eb0 <_js_json_stringify_full+0x130>
100849e94:     	b	0x10084a294 <_js_json_stringify_full+0x514>
100849e98:     	ands	x9, x19, #0xffffffffffff
100849e9c:     	b.eq	0x10084a358 <_js_json_stringify_full+0x5d8>
100849ea0:     	add	x11, x9, #0x14
100849ea4:     	ldr	w10, [x9, #0x4]
100849ea8:     	cmp	w10, #0x3
100849eac:     	b.hi	0x10084a294 <_js_json_stringify_full+0x514>
100849eb0:     	stur	wzr, [sp, #0x81]
100849eb4:     	mov	w9, #0x22               ; =34
100849eb8:     	strb	w9, [sp, #0x80]
100849ebc:     	cbz	w10, 0x100849ef4 <_js_json_stringify_full+0x174>
100849ec0:     	add	x12, sp, #0x80
100849ec4:     	ldrb	w13, [x11]
100849ec8:     	sxtb	w15, w13
100849ecc:     	cmp	w13, #0xb
100849ed0:     	b.le	0x100849efc <_js_json_stringify_full+0x17c>
100849ed4:     	cmp	w13, #0x21
100849ed8:     	b.gt	0x100849f1c <_js_json_stringify_full+0x19c>
100849edc:     	cmp	w13, #0xc
100849ee0:     	b.eq	0x100849f50 <_js_json_stringify_full+0x1d0>
100849ee4:     	cmp	w13, #0xd
100849ee8:     	b.ne	0x100849f2c <_js_json_stringify_full+0x1ac>
100849eec:     	mov	w15, #0x72              ; =114
100849ef0:     	b	0x100849f5c <_js_json_stringify_full+0x1dc>
100849ef4:     	mov	w12, #0x1               ; =1
100849ef8:     	b	0x100849f84 <_js_json_stringify_full+0x204>
100849efc:     	cmp	w13, #0x8
100849f00:     	b.eq	0x100849f48 <_js_json_stringify_full+0x1c8>
100849f04:     	cmp	w13, #0x9
100849f08:     	b.eq	0x100849f58 <_js_json_stringify_full+0x1d8>
100849f0c:     	cmp	w13, #0xa
100849f10:     	b.ne	0x100849f2c <_js_json_stringify_full+0x1ac>
100849f14:     	mov	w15, #0x6e              ; =110
100849f18:     	b	0x100849f5c <_js_json_stringify_full+0x1dc>
100849f1c:     	cmp	w13, #0x22
100849f20:     	b.eq	0x100849f5c <_js_json_stringify_full+0x1dc>
100849f24:     	cmp	w13, #0x5c
100849f28:     	b.eq	0x100849f5c <_js_json_stringify_full+0x1dc>
100849f2c:     	cmp	w15, #0x20
100849f30:     	b.lt	0x10084a294 <_js_json_stringify_full+0x514>
100849f34:     	mov	w14, #0x0               ; =0
100849f38:     	add	x13, x12, #0x2
100849f3c:     	mov	w12, #0x2               ; =2
100849f40:     	mov	w16, #0x1               ; =1
100849f44:     	b	0x100849f74 <_js_json_stringify_full+0x1f4>
100849f48:     	mov	w15, #0x62              ; =98
100849f4c:     	b	0x100849f5c <_js_json_stringify_full+0x1dc>
100849f50:     	mov	w15, #0x66              ; =102
100849f54:     	b	0x100849f5c <_js_json_stringify_full+0x1dc>
100849f58:     	mov	w15, #0x74              ; =116
100849f5c:     	add	x13, x12, #0x3
100849f60:     	mov	w12, #0x5c              ; =92
100849f64:     	strb	w12, [sp, #0x81]
100849f68:     	mov	w14, #0x1               ; =1
100849f6c:     	mov	w12, #0x3               ; =3
100849f70:     	mov	w16, #0x2               ; =2
100849f74:     	add	x17, sp, #0x80
100849f78:     	strb	w15, [x17, x16]
100849f7c:     	cmp	w10, #0x1
100849f80:     	b.ne	0x100849fbc <_js_json_stringify_full+0x23c>
100849f84:     	add	x10, sp, #0x80
100849f88:     	strb	w9, [x10, x12]
100849f8c:     	add	x8, x12, #0x1
100849f90:     	cmp	x12, #0x3
100849f94:     	b.hs	0x100849fa8 <_js_json_stringify_full+0x228>
100849f98:     	mov	x13, #0x0               ; =0
100849f9c:     	mov	x11, #0x0               ; =0
100849fa0:     	add	x9, sp, #0x80
100849fa4:     	b	0x10084a204 <_js_json_stringify_full+0x484>
100849fa8:     	cmp	x12, #0xf
100849fac:     	b.hs	0x100849fec <_js_json_stringify_full+0x26c>
100849fb0:     	mov	x11, #0x0               ; =0
100849fb4:     	mov	x13, #0x0               ; =0
100849fb8:     	b	0x10084a160 <_js_json_stringify_full+0x3e0>
100849fbc:     	ldrb	w16, [x11, #0x1]
100849fc0:     	sxtb	w15, w16
100849fc4:     	cmp	w16, #0xb
100849fc8:     	b.le	0x10084a234 <_js_json_stringify_full+0x4b4>
100849fcc:     	cmp	w16, #0x21
100849fd0:     	b.gt	0x10084a254 <_js_json_stringify_full+0x4d4>
100849fd4:     	cmp	w16, #0xc
100849fd8:     	b.eq	0x10084a284 <_js_json_stringify_full+0x504>
100849fdc:     	cmp	w16, #0xd
100849fe0:     	b.ne	0x10084a264 <_js_json_stringify_full+0x4e4>
100849fe4:     	mov	w15, #0x72              ; =114
100849fe8:     	b	0x10084a290 <_js_json_stringify_full+0x510>
100849fec:     	and	x12, x8, #0xc
100849ff0:     	and	x11, x8, #0x10
100849ff4:     	add	x13, sp, #0x80
100849ff8:     	add	x9, x13, x11
100849ffc:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x65f0>
10084a000:     	ldr	q0, [x14, #0x110]
10084a004:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x65f0>
10084a008:     	ldr	q1, [x14, #0x120]
10084a00c:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x65f0>
10084a010:     	ldr	q2, [x14, #0x130]
10084a014:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x65f0>
10084a018:     	ldr	q3, [x14, #0x140]
10084a01c:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x65f0>
10084a020:     	ldr	q4, [x14, #0x150]
10084a024:     	movi.2d	v5, #0000000000000000
10084a028:     	adrp	x14, 0x100c9f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x65f0>
10084a02c:     	ldr	q6, [x14, #0x160]
10084a030:     	adrp	x14, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x55f0>
10084a034:     	ldr	q7, [x14, #0x280]
10084a038:     	mov	w14, #0x10              ; =16
10084a03c:     	movi.2d	v16, #0000000000000000
10084a040:     	dup.2d	v17, x14
10084a044:     	adrp	x14, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33dfa>
10084a048:     	ldr	q19, [x14, #0x180]
10084a04c:     	and	x14, x8, #0x10
10084a050:     	movi.2d	v20, #0000000000000000
10084a054:     	movi.2d	v18, #0000000000000000
10084a058:     	movi.2d	v23, #0000000000000000
10084a05c:     	movi.2d	v21, #0000000000000000
10084a060:     	movi.2d	v24, #0000000000000000
10084a064:     	movi.2d	v22, #0000000000000000
10084a068:     	ldr	q25, [x13], #0x10
10084a06c:     	ushll.8h	v26, v25, #0x0
10084a070:     	ushll2.4s	v27, v26, #0x0
10084a074:     	ushll2.2d	v28, v27, #0x0
10084a078:     	ushll2.8h	v25, v25, #0x0
10084a07c:     	ushll.4s	v29, v25, #0x0
10084a080:     	ushll2.2d	v30, v29, #0x0
10084a084:     	ushll.2d	v29, v29, #0x0
10084a088:     	ushll.2d	v27, v27, #0x0
10084a08c:     	ushll.4s	v26, v26, #0x0
10084a090:     	ushll2.2d	v31, v26, #0x0
10084a094:     	ushll2.4s	v25, v25, #0x0
10084a098:     	ushll.2d	v8, v25, #0x0
10084a09c:     	ushll.2d	v26, v26, #0x0
10084a0a0:     	ushll2.2d	v25, v25, #0x0
10084a0a4:     	shl.2d	v9, v0, #0x3
10084a0a8:     	ushl.2d	v25, v25, v9
10084a0ac:     	shl.2d	v9, v19, #0x3
10084a0b0:     	ushl.2d	v26, v26, v9
10084a0b4:     	shl.2d	v9, v1, #0x3
10084a0b8:     	ushl.2d	v8, v8, v9
10084a0bc:     	shl.2d	v9, v7, #0x3
10084a0c0:     	ushl.2d	v31, v31, v9
10084a0c4:     	shl.2d	v9, v6, #0x3
10084a0c8:     	ushl.2d	v27, v27, v9
10084a0cc:     	shl.2d	v9, v3, #0x3
10084a0d0:     	ushl.2d	v29, v29, v9
10084a0d4:     	shl.2d	v9, v2, #0x3
10084a0d8:     	ushl.2d	v30, v30, v9
10084a0dc:     	shl.2d	v9, v4, #0x3
10084a0e0:     	ushl.2d	v28, v28, v9
10084a0e4:     	orr.16b	v18, v28, v18
10084a0e8:     	orr.16b	v21, v30, v21
10084a0ec:     	orr.16b	v23, v29, v23
10084a0f0:     	orr.16b	v20, v27, v20
10084a0f4:     	orr.16b	v5, v31, v5
10084a0f8:     	orr.16b	v24, v8, v24
10084a0fc:     	orr.16b	v16, v26, v16
10084a100:     	orr.16b	v22, v25, v22
10084a104:     	add.2d	v6, v6, v17
10084a108:     	add.2d	v7, v7, v17
10084a10c:     	add.2d	v19, v19, v17
10084a110:     	add.2d	v4, v4, v17
10084a114:     	add.2d	v3, v3, v17
10084a118:     	add.2d	v2, v2, v17
10084a11c:     	add.2d	v1, v1, v17
10084a120:     	add.2d	v0, v0, v17
10084a124:     	subs	x14, x14, #0x10
10084a128:     	b.ne	0x10084a068 <_js_json_stringify_full+0x2e8>
10084a12c:     	orr.16b	v0, v16, v23
10084a130:     	orr.16b	v1, v20, v24
10084a134:     	orr.16b	v0, v0, v1
10084a138:     	orr.16b	v1, v5, v21
10084a13c:     	orr.16b	v2, v18, v22
10084a140:     	orr.16b	v1, v1, v2
10084a144:     	orr.16b	v0, v0, v1
10084a148:     	mov	d1, v0[1]
10084a14c:     	orr.8b	v0, v0, v1
10084a150:     	fmov	x13, d0
10084a154:     	cmp	x8, x11
10084a158:     	b.eq	0x10084a224 <_js_json_stringify_full+0x4a4>
10084a15c:     	cbz	x12, 0x10084a204 <_js_json_stringify_full+0x484>
10084a160:     	mov	x14, x11
10084a164:     	and	x11, x8, #0x1c
10084a168:     	add	x15, sp, #0x80
10084a16c:     	add	x9, x15, x11
10084a170:     	fmov	d0, x13
10084a174:     	movi.2d	v1, #0000000000000000
10084a178:     	dup.2d	v3, x14
10084a17c:     	adrp	x12, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x55f0>
10084a180:     	ldr	q2, [x12, #0x280]
10084a184:     	orr.16b	v2, v3, v2
10084a188:     	adrp	x12, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33dfa>
10084a18c:     	ldr	q4, [x12, #0x180]
10084a190:     	orr.16b	v3, v3, v4
10084a194:     	sub	x12, x14, x11
10084a198:     	add	x13, x15, x14
10084a19c:     	movi.2d	v4, #0x000000000000ff
10084a1a0:     	mov	w14, #0x4               ; =4
10084a1a4:     	dup.2d	v5, x14
10084a1a8:     	ldr	s6, [x13], #0x4
10084a1ac:     	ushll.8h	v6, v6, #0x0
10084a1b0:     	ushll.4s	v6, v6, #0x0
10084a1b4:     	ushll2.2d	v7, v6, #0x0
10084a1b8:     	and.16b	v7, v7, v4
10084a1bc:     	ushll.2d	v6, v6, #0x0
10084a1c0:     	and.16b	v6, v6, v4
10084a1c4:     	shl.2d	v16, v2, #0x3
10084a1c8:     	shl.2d	v17, v3, #0x3
10084a1cc:     	ushl.2d	v6, v6, v17
10084a1d0:     	ushl.2d	v7, v7, v16
10084a1d4:     	orr.16b	v1, v7, v1
10084a1d8:     	orr.16b	v0, v6, v0
10084a1dc:     	add.2d	v2, v2, v5
10084a1e0:     	add.2d	v3, v3, v5
10084a1e4:     	adds	x12, x12, #0x4
10084a1e8:     	b.ne	0x10084a1a8 <_js_json_stringify_full+0x428>
10084a1ec:     	orr.16b	v0, v0, v1
10084a1f0:     	mov	d1, v0[1]
10084a1f4:     	orr.8b	v0, v0, v1
10084a1f8:     	fmov	x13, d0
10084a1fc:     	cmp	x8, x11
10084a200:     	b.eq	0x10084a224 <_js_json_stringify_full+0x4a4>
10084a204:     	add	x10, x10, x8
10084a208:     	lsl	x11, x11, #3
10084a20c:     	ldrb	w12, [x9], #0x1
10084a210:     	lsl	x12, x12, x11
10084a214:     	orr	x13, x12, x13
10084a218:     	add	x11, x11, #0x8
10084a21c:     	cmp	x9, x10
10084a220:     	b.ne	0x10084a20c <_js_json_stringify_full+0x48c>
10084a224:     	orr	x8, x13, x8, lsl #40
10084a228:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084a22c:     	orr	x20, x8, x9
10084a230:     	b	0x10084b228 <_js_json_stringify_full+0x14a8>
10084a234:     	cmp	w16, #0x8
10084a238:     	b.eq	0x10084a27c <_js_json_stringify_full+0x4fc>
10084a23c:     	cmp	w16, #0x9
10084a240:     	b.eq	0x10084a28c <_js_json_stringify_full+0x50c>
10084a244:     	cmp	w16, #0xa
10084a248:     	b.ne	0x10084a264 <_js_json_stringify_full+0x4e4>
10084a24c:     	mov	w15, #0x6e              ; =110
10084a250:     	b	0x10084a290 <_js_json_stringify_full+0x510>
10084a254:     	cmp	w16, #0x22
10084a258:     	b.eq	0x10084a290 <_js_json_stringify_full+0x510>
10084a25c:     	cmp	w16, #0x5c
10084a260:     	b.eq	0x10084a290 <_js_json_stringify_full+0x510>
10084a264:     	cmp	w15, #0x20
10084a268:     	b.lt	0x10084a294 <_js_json_stringify_full+0x514>
10084a26c:     	add	x13, sp, #0x80
10084a270:     	strb	w15, [x13, x12]
10084a274:     	add	x12, x12, #0x1
10084a278:     	b	0x10084a81c <_js_json_stringify_full+0xa9c>
10084a27c:     	mov	w15, #0x62              ; =98
10084a280:     	b	0x10084a290 <_js_json_stringify_full+0x510>
10084a284:     	mov	w15, #0x66              ; =102
10084a288:     	b	0x10084a290 <_js_json_stringify_full+0x510>
10084a28c:     	mov	w15, #0x74              ; =116
10084a290:     	tbz	w14, #0x0, 0x10084a808 <_js_json_stringify_full+0xa88>
10084a294:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084a298:     	cmp	x8, x9
10084a29c:     	b.eq	0x10084a2e4 <_js_json_stringify_full+0x564>
10084a2a0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084a2a4:     	cmp	x8, x9
10084a2a8:     	b.ne	0x10084a358 <_js_json_stringify_full+0x5d8>
10084a2ac:     	and	x8, x19, #0xffffffffffff
10084a2b0:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
10084a2b4:     	mov	x10, #0x7fffffffffff    ; =140737488355327
10084a2b8:     	movk	x10, #0xffef, lsl #16
10084a2bc:     	cmp	x9, x10
10084a2c0:     	b.hi	0x10084a358 <_js_json_stringify_full+0x5d8>
10084a2c4:     	ldr	w8, [x8, #0x4]
10084a2c8:     	cmp	w8, #0x40
10084a2cc:     	b.lo	0x10084a358 <_js_json_stringify_full+0x5d8>
10084a2d0:     	and	x0, x19, #0xffffffffffff
10084a2d4:     	bl	0x1004f57e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
10084a2d8:     	cmp	x0, #0x1
10084a2dc:     	b.ne	0x10084a358 <_js_json_stringify_full+0x5d8>
10084a2e0:     	b	0x10084a4a4 <_js_json_stringify_full+0x724>
10084a2e4:     	and	x25, x19, #0xffffffffffff
10084a2e8:     	and	x0, x19, #0xffffffffffff
10084a2ec:     	bl	0x10057d5c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084a2f0:     	cbz	x0, 0x10084a324 <_js_json_stringify_full+0x5a4>
10084a2f4:     	ldrb	w8, [x0]
10084a2f8:     	cmp	w8, #0x2
10084a2fc:     	b.ne	0x10084a324 <_js_json_stringify_full+0x5a4>
10084a300:     	ldrsb	w8, [x0, #0x1]
10084a304:     	tbnz	w8, #0x1f, 0x10084a324 <_js_json_stringify_full+0x5a4>
10084a308:     	ldrh	w8, [x0, #0x2]
10084a30c:     	tbnz	w8, #0xb, 0x10084a324 <_js_json_stringify_full+0x5a4>
10084a310:     	ldr	w8, [x0, #0x4]
10084a314:     	cmp	w8, #0x18
10084a318:     	b.lo	0x10084a324 <_js_json_stringify_full+0x5a4>
10084a31c:     	ldr	w8, [x25]
10084a320:     	cbz	w8, 0x10084b37c <_js_json_stringify_full+0x15fc>
10084a324:     	and	x0, x19, #0xffffffffffff
10084a328:     	bl	0x10057d5c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084a32c:     	cbz	x0, 0x10084a358 <_js_json_stringify_full+0x5d8>
10084a330:     	ldrb	w8, [x0]
10084a334:     	cmp	w8, #0x2
10084a338:     	b.ne	0x10084a358 <_js_json_stringify_full+0x5d8>
10084a33c:     	ldrh	w8, [x0, #0x2]
10084a340:     	tbnz	w8, #0xb, 0x10084a358 <_js_json_stringify_full+0x5d8>
10084a344:     	ldr	w8, [x0, #0x4]
10084a348:     	cmp	w8, #0x18
10084a34c:     	b.lo	0x10084a358 <_js_json_stringify_full+0x5d8>
10084a350:     	ldr	w8, [x25]
10084a354:     	cbz	w8, 0x10084b320 <_js_json_stringify_full+0x15a0>
10084a358:     	mov	x20, #0x1               ; =1
10084a35c:     	movk	x20, #0x7ffc, lsl #48
10084a360:     	cmp	x19, x20
10084a364:     	b.eq	0x10084b228 <_js_json_stringify_full+0x14a8>
10084a368:     	and	x22, x19, #0xffff000000000000
10084a36c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a370:     	cmp	x22, x8
10084a374:     	b.ne	0x10084a3ac <_js_json_stringify_full+0x62c>
10084a378:     	and	x8, x19, #0xffffffffffff
10084a37c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084a380:     	b.lo	0x10084a398 <_js_json_stringify_full+0x618>
10084a384:     	ldr	w8, [x8, #0xc]
10084a388:     	mov	w9, #0x4f53             ; =20307
10084a38c:     	movk	w9, #0x434c, lsl #16
10084a390:     	cmp	w8, w9
10084a394:     	b.eq	0x10084b228 <_js_json_stringify_full+0x14a8>
10084a398:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a39c:     	cmp	x22, x8
10084a3a0:     	b.ne	0x10084a3d8 <_js_json_stringify_full+0x658>
10084a3a4:     	and	x0, x19, #0xffffffffffff
10084a3a8:     	b	0x10084a400 <_js_json_stringify_full+0x680>
10084a3ac:     	lsr	x8, x19, #52
10084a3b0:     	cbnz	x8, 0x10084a488 <_js_json_stringify_full+0x708>
10084a3b4:     	and	x8, x19, #0x7
10084a3b8:     	cbz	x19, 0x10084a3e4 <_js_json_stringify_full+0x664>
10084a3bc:     	cbnz	x8, 0x10084a3e4 <_js_json_stringify_full+0x664>
10084a3c0:     	mov	x0, x19
10084a3c4:     	bl	0x100511d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084a3c8:     	mov	x8, x19
10084a3cc:     	tbnz	w0, #0x0, 0x10084a37c <_js_json_stringify_full+0x5fc>
10084a3d0:     	mov	x8, #0x0                ; =0
10084a3d4:     	b	0x10084a3e4 <_js_json_stringify_full+0x664>
10084a3d8:     	lsr	x8, x19, #52
10084a3dc:     	cbnz	x8, 0x10084a488 <_js_json_stringify_full+0x708>
10084a3e0:     	and	x8, x19, #0x7
10084a3e4:     	cbz	x19, 0x10084a488 <_js_json_stringify_full+0x708>
10084a3e8:     	cbnz	x8, 0x10084a488 <_js_json_stringify_full+0x708>
10084a3ec:     	mov	x0, x19
10084a3f0:     	bl	0x100511d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084a3f4:     	mov	x8, x0
10084a3f8:     	mov	x0, x19
10084a3fc:     	tbz	w8, #0x0, 0x10084a488 <_js_json_stringify_full+0x708>
10084a400:     	cmp	x0, #0x100, lsl #12     ; =0x100000
10084a404:     	b.lo	0x10084a488 <_js_json_stringify_full+0x708>
10084a408:     	adrp	x8, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084a40c:     	add	x8, x8, #0xfb0
10084a410:     	ldaprb	w8, [x8]
10084a414:     	cbz	w8, 0x10084a488 <_js_json_stringify_full+0x708>
10084a418:     	lsr	x8, x0, #3
10084a41c:     	mov	x9, #0x7c15             ; =31765
10084a420:     	movk	x9, #0x7f4a, lsl #16
10084a424:     	movk	x9, #0x79b9, lsl #32
10084a428:     	movk	x9, #0x9e37, lsl #48
10084a42c:     	mul	x8, x8, x9
10084a430:     	lsr	x10, x8, #54
10084a434:     	lsr	x11, x8, #60
10084a438:     	adrp	x9, 0x101065000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084a43c:     	add	x9, x9, #0xf30
10084a440:     	add	x11, x9, x11, lsl #3
10084a444:     	ldapr	x11, [x11]
10084a448:     	lsr	x10, x11, x10
10084a44c:     	tbz	w10, #0x0, 0x10084a488 <_js_json_stringify_full+0x708>
10084a450:     	lsr	x10, x8, #44
10084a454:     	ubfx	x11, x8, #50, #4
10084a458:     	add	x11, x9, x11, lsl #3
10084a45c:     	ldapr	x11, [x11]
10084a460:     	lsr	x10, x11, x10
10084a464:     	tbz	w10, #0x0, 0x10084a488 <_js_json_stringify_full+0x708>
10084a468:     	lsr	x10, x8, #34
10084a46c:     	ubfx	x8, x8, #40, #4
10084a470:     	add	x8, x9, x8, lsl #3
10084a474:     	ldapr	x8, [x8]
10084a478:     	lsr	x8, x8, x10
10084a47c:     	tbz	w8, #0x0, 0x10084a488 <_js_json_stringify_full+0x708>
10084a480:     	bl	0x10034f3ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
10084a484:     	tbnz	w0, #0x0, 0x10084b228 <_js_json_stringify_full+0x14a8>
10084a488:     	cmp	x24, #0x3
10084a48c:     	ccmp	x27, #0x2, #0x2, lo
10084a490:     	b.hs	0x10084a4b0 <_js_json_stringify_full+0x730>
10084a494:     	mov.16b	v0, v8
10084a498:     	bl	0x1004f08bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084a49c:     	cmp	x0, #0x1
10084a4a0:     	b.ne	0x10084a4b0 <_js_json_stringify_full+0x730>
10084a4a4:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
10084a4a8:     	bfxil	x20, x1, #0, #48
10084a4ac:     	b	0x10084b228 <_js_json_stringify_full+0x14a8>
10084a4b0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a4b4:     	cmp	x22, x8
10084a4b8:     	b.ne	0x10084a508 <_js_json_stringify_full+0x788>
10084a4bc:     	ands	x22, x19, #0xffffffffffff
10084a4c0:     	b.eq	0x10084a508 <_js_json_stringify_full+0x788>
10084a4c4:     	mov	x0, x22
10084a4c8:     	bl	0x100511d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084a4cc:     	cbz	w0, 0x10084a508 <_js_json_stringify_full+0x788>
10084a4d0:     	ldurb	w8, [x22, #-0x8]
10084a4d4:     	cmp	w8, #0x9
10084a4d8:     	b.ne	0x10084a508 <_js_json_stringify_full+0x788>
10084a4dc:     	ldr	w8, [x22, #0x4]
10084a4e0:     	mov	w9, #0x5841             ; =22593
10084a4e4:     	movk	w9, #0x4c5a, lsl #16
10084a4e8:     	cmp	w8, w9
10084a4ec:     	b.ne	0x10084a508 <_js_json_stringify_full+0x788>
10084a4f0:     	mov	x0, x22
10084a4f4:     	bl	0x10068b9a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
10084a4f8:     	cbz	x0, 0x10084a508 <_js_json_stringify_full+0x788>
10084a4fc:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
10084a500:     	bfxil	x19, x0, #0, #48
10084a504:     	fmov	d8, x19
10084a508:     	mov	w8, #0x7ffd             ; =32765
10084a50c:     	cmp	x8, x23, lsr #48
10084a510:     	b.ne	0x10084a524 <_js_json_stringify_full+0x7a4>
10084a514:     	and	x1, x23, #0xffffffffffff
10084a518:     	cmp	x1, #0x100, lsl #12     ; =0x100000
10084a51c:     	b.hs	0x10084a538 <_js_json_stringify_full+0x7b8>
10084a520:     	b	0x10084a58c <_js_json_stringify_full+0x80c>
10084a524:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
10084a528:     	mov	x9, #0xfffffff00000     ; =281474975662080
10084a52c:     	mov	x1, x23
10084a530:     	cmp	x8, x9
10084a534:     	b.hs	0x10084a58c <_js_json_stringify_full+0x80c>
10084a538:     	lsr	x8, x1, #47
10084a53c:     	cbnz	x8, 0x10084a58c <_js_json_stringify_full+0x80c>
10084a540:     	add	x0, sp, #0x80
10084a544:     	bl	0x1007722ec <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
10084a548:     	ldr	w8, [sp, #0x80]
10084a54c:     	tbz	w8, #0x0, 0x10084a58c <_js_json_stringify_full+0x80c>
10084a550:     	ldr	w8, [sp, #0x88]
10084a554:     	mov	w9, #-0xff30            ; =-65328
10084a558:     	cmp	w8, w9
10084a55c:     	b.eq	0x10084a580 <_js_json_stringify_full+0x800>
10084a560:     	mov	w9, #-0xff2f            ; =-65327
10084a564:     	cmp	w8, w9
10084a568:     	b.ne	0x10084a58c <_js_json_stringify_full+0x80c>
10084a56c:     	mov.16b	v0, v9
10084a570:     	bl	0x10084c63c <_js_jsvalue_to_string>
10084a574:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
10084a578:     	bfxil	x23, x0, #0, #48
10084a57c:     	b	0x10084a58c <_js_json_stringify_full+0x80c>
10084a580:     	mov.16b	v0, v9
10084a584:     	bl	0x100873be0 <_js_number_coerce>
10084a588:     	fmov	x23, d0
10084a58c:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
10084a590:     	add	x8, x23, x8
10084a594:     	cmp	x8, #0x3
10084a598:     	b.hs	0x10084a5b0 <_js_json_stringify_full+0x830>
10084a59c:     	mov	x22, #0x0               ; =0
10084a5a0:     	mov	w8, #0x1                ; =1
10084a5a4:     	stp	xzr, x8, [sp, #0x10]
10084a5a8:     	str	xzr, [sp, #0x20]
10084a5ac:     	b	0x10084a864 <_js_json_stringify_full+0xae4>
10084a5b0:     	and	x8, x23, #0xffff000000000000
10084a5b4:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084a5b8:     	cmp	x8, x9
10084a5bc:     	b.eq	0x10084a5e0 <_js_json_stringify_full+0x860>
10084a5c0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084a5c4:     	cmp	x8, x9
10084a5c8:     	b.ne	0x10084a66c <_js_json_stringify_full+0x8ec>
10084a5cc:     	and	x8, x23, #0xffffffffffff
10084a5d0:     	cmp	x8, #0x1, lsl #12       ; =0x1000
10084a5d4:     	b.hs	0x10084a6b4 <_js_json_stringify_full+0x934>
10084a5d8:     	mov	x9, #0x0                ; =0
10084a5dc:     	b	0x10084a6bc <_js_json_stringify_full+0x93c>
10084a5e0:     	strb	wzr, [sp, #0x4c]
10084a5e4:     	str	wzr, [sp, #0x48]
10084a5e8:     	ubfx	x1, x23, #40, #8
10084a5ec:     	cbz	x1, 0x10084a63c <_js_json_stringify_full+0x8bc>
10084a5f0:     	strb	w23, [sp, #0x48]
10084a5f4:     	cmp	x1, #0x1
10084a5f8:     	b.eq	0x10084a63c <_js_json_stringify_full+0x8bc>
10084a5fc:     	lsr	x8, x23, #8
10084a600:     	strb	w8, [sp, #0x49]
10084a604:     	cmp	x1, #0x2
10084a608:     	b.eq	0x10084a63c <_js_json_stringify_full+0x8bc>
10084a60c:     	lsr	x8, x23, #16
10084a610:     	strb	w8, [sp, #0x4a]
10084a614:     	cmp	x1, #0x3
10084a618:     	b.eq	0x10084a63c <_js_json_stringify_full+0x8bc>
10084a61c:     	lsr	x8, x23, #24
10084a620:     	strb	w8, [sp, #0x4b]
10084a624:     	cmp	x1, #0x4
10084a628:     	b.eq	0x10084a63c <_js_json_stringify_full+0x8bc>
10084a62c:     	lsr	x8, x23, #32
10084a630:     	strb	w8, [sp, #0x4c]
10084a634:     	cmp	x1, #0x5
10084a638:     	b.ne	0x10084b9fc <_js_json_stringify_full+0x1c7c>
10084a63c:     	add	x8, sp, #0x80
10084a640:     	add	x0, sp, #0x48
10084a644:     	bl	0x10002dc18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10084a648:     	ldr	w8, [sp, #0x80]
10084a64c:     	ldp	x9, x22, [sp, #0x88]
10084a650:     	cmp	w8, #0x0
10084a654:     	csinc	x23, x9, xzr, eq
10084a658:     	csel	x25, xzr, x22, ne
10084a65c:     	tbz	x25, #0x3f, 0x10084a79c <_js_json_stringify_full+0xa1c>
10084a660:     	mov	x0, #0x0                ; =0
10084a664:     	mov	x1, x22
10084a668:     	bl	0x100b16b80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084a66c:     	add	x8, x20, #0x3
10084a670:     	cmp	x23, x8
10084a674:     	b.eq	0x10084a59c <_js_json_stringify_full+0x81c>
10084a678:     	fmov	d0, x23
10084a67c:     	fcvtzu	x8, d0
10084a680:     	mov	w9, #0xa                ; =10
10084a684:     	cmp	x8, #0xa
10084a688:     	csel	x3, x8, x9, lo
10084a68c:     	adrp	x1, 0x100c47000 <_PERRY_EMPTY_STRING+0x1234>
10084a690:     	add	x1, x1, #0xf5c
10084a694:     	add	x0, sp, #0x80
10084a698:     	mov	w2, #0x1                ; =1
10084a69c:     	bl	0x1002304f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
10084a6a0:     	ldr	x22, [sp, #0x90]
10084a6a4:     	str	x22, [sp, #0x20]
10084a6a8:     	ldr	q0, [sp, #0x80]
10084a6ac:     	str	q0, [sp, #0x10]
10084a6b0:     	b	0x10084a864 <_js_json_stringify_full+0xae4>
10084a6b4:     	ldr	w22, [x8, #0x4]
10084a6b8:     	add	x9, x8, #0x14
10084a6bc:     	mov	x14, #0x0               ; =0
10084a6c0:     	mov	x8, #0x0                ; =0
10084a6c4:     	cmp	x9, #0x0
10084a6c8:     	csel	x24, xzr, x22, eq
10084a6cc:     	csinc	x23, x9, xzr, ne
10084a6d0:     	add	x9, x23, x24
10084a6d4:     	mov	w10, #0x1               ; =1
10084a6d8:     	mov	x11, x23
10084a6dc:     	b	0x10084a70c <_js_json_stringify_full+0x98c>
10084a6e0:     	add	x12, x11, #0x2
10084a6e4:     	bfi	w15, w13, #6, #5
10084a6e8:     	mov	x13, x15
10084a6ec:     	sub	x11, x25, x11
10084a6f0:     	add	x14, x11, x12
10084a6f4:     	cmp	w13, #0x10, lsl #12     ; =0x10000
10084a6f8:     	cinc	x11, x10, hs
10084a6fc:     	add	x8, x11, x8
10084a700:     	mov	x11, x12
10084a704:     	cmp	x8, #0xa
10084a708:     	b.hi	0x10084a7c4 <_js_json_stringify_full+0xa44>
10084a70c:     	cmp	x11, x9
10084a710:     	b.eq	0x10084a774 <_js_json_stringify_full+0x9f4>
10084a714:     	mov	x25, x14
10084a718:     	mov	x12, x11
10084a71c:     	ldrsb	w14, [x12], #0x1
10084a720:     	and	w13, w14, #0xff
10084a724:     	tbz	w14, #0x1f, 0x10084a6ec <_js_json_stringify_full+0x96c>
10084a728:     	ldrb	w12, [x11, #0x1]
10084a72c:     	and	w15, w12, #0x3f
10084a730:     	cmp	w13, #0xe0
10084a734:     	b.lo	0x10084a6e0 <_js_json_stringify_full+0x960>
10084a738:     	and	w14, w13, #0x1f
10084a73c:     	ldrb	w12, [x11, #0x2]
10084a740:     	and	w12, w12, #0x3f
10084a744:     	orr	w15, w12, w15, lsl #6
10084a748:     	cmp	w13, #0xf0
10084a74c:     	b.lo	0x10084a768 <_js_json_stringify_full+0x9e8>
10084a750:     	add	x12, x11, #0x4
10084a754:     	ldrb	w13, [x11, #0x3]
10084a758:     	and	w13, w13, #0x3f
10084a75c:     	orr	w13, w13, w15, lsl #6
10084a760:     	bfi	w13, w14, #18, #3
10084a764:     	b	0x10084a6ec <_js_json_stringify_full+0x96c>
10084a768:     	add	x12, x11, #0x3
10084a76c:     	orr	w13, w15, w14, lsl #12
10084a770:     	b	0x10084a6ec <_js_json_stringify_full+0x96c>
10084a774:     	cbz	x24, 0x10084a7f8 <_js_json_stringify_full+0xa78>
10084a778:     	mov	x0, x24
10084a77c:     	mov	w1, #0x1                ; =1
10084a780:     	bl	0x100b63a88 <_mi_malloc_aligned>
10084a784:     	cbz	x0, 0x10084b9e4 <_js_json_stringify_full+0x1c64>
10084a788:     	mov	x26, x0
10084a78c:     	mov	x1, x23
10084a790:     	mov	x2, x24
10084a794:     	bl	0x100b666ac <_writev+0x100b666ac>
10084a798:     	b	0x10084a800 <_js_json_stringify_full+0xa80>
10084a79c:     	cbz	x25, 0x10084a854 <_js_json_stringify_full+0xad4>
10084a7a0:     	mov	x0, x25
10084a7a4:     	mov	w1, #0x1                ; =1
10084a7a8:     	bl	0x100b63a88 <_mi_malloc_aligned>
10084a7ac:     	cbz	x0, 0x10084b9f0 <_js_json_stringify_full+0x1c70>
10084a7b0:     	mov	x24, x0
10084a7b4:     	mov	x1, x23
10084a7b8:     	mov	x2, x25
10084a7bc:     	bl	0x100b666ac <_writev+0x100b666ac>
10084a7c0:     	b	0x10084a85c <_js_json_stringify_full+0xadc>
10084a7c4:     	cbz	x25, 0x10084a7f8 <_js_json_stringify_full+0xa78>
10084a7c8:     	cmp	x25, x24
10084a7cc:     	b.hs	0x10084b274 <_js_json_stringify_full+0x14f4>
10084a7d0:     	ldrsb	w8, [x23, x25]
10084a7d4:     	cmn	w8, #0x40
10084a7d8:     	b.ge	0x10084b278 <_js_json_stringify_full+0x14f8>
10084a7dc:     	adrp	x4, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084a7e0:     	add	x4, x4, #0x270
10084a7e4:     	mov	x0, x23
10084a7e8:     	mov	x1, x24
10084a7ec:     	mov	x2, #0x0                ; =0
10084a7f0:     	mov	x3, x25
10084a7f4:     	bl	0x100b16ef8 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
10084a7f8:     	mov	x22, #0x0               ; =0
10084a7fc:     	mov	w26, #0x1               ; =1
10084a800:     	stp	x22, x26, [sp, #0x10]
10084a804:     	b	0x10084a860 <_js_json_stringify_full+0xae0>
10084a808:     	add	x14, sp, #0x80
10084a80c:     	mov	w16, #0x5c              ; =92
10084a810:     	strb	w16, [x14, x12]
10084a814:     	add	x12, x12, #0x2
10084a818:     	strb	w15, [x13, #0x1]
10084a81c:     	cmp	w10, #0x2
10084a820:     	b.eq	0x100849f84 <_js_json_stringify_full+0x204>
10084a824:     	ldrb	w11, [x11, #0x2]
10084a828:     	sxtb	w10, w11
10084a82c:     	cmp	w11, #0xb
10084a830:     	b.le	0x10084b300 <_js_json_stringify_full+0x1580>
10084a834:     	cmp	w11, #0x21
10084a838:     	b.gt	0x10084b34c <_js_json_stringify_full+0x15cc>
10084a83c:     	cmp	w11, #0xc
10084a840:     	b.eq	0x10084b3d8 <_js_json_stringify_full+0x1658>
10084a844:     	cmp	w11, #0xd
10084a848:     	b.ne	0x10084b35c <_js_json_stringify_full+0x15dc>
10084a84c:     	mov	w10, #0x72              ; =114
10084a850:     	b	0x10084b3e4 <_js_json_stringify_full+0x1664>
10084a854:     	mov	x22, #0x0               ; =0
10084a858:     	mov	w24, #0x1               ; =1
10084a85c:     	stp	x22, x24, [sp, #0x10]
10084a860:     	str	x22, [sp, #0x20]
10084a864:     	cmp	x27, #0x2
10084a868:     	b.lo	0x10084a9a8 <_js_json_stringify_full+0xc28>
10084a86c:     	and	x25, x21, #0xffff000000000000
10084a870:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a874:     	cmp	x25, x8
10084a878:     	b.ne	0x10084a984 <_js_json_stringify_full+0xc04>
10084a87c:     	and	x23, x21, #0xffffffffffff
10084a880:     	cmp	x23, #0x100, lsl #12    ; =0x100000
10084a884:     	b.lo	0x10084a9a8 <_js_json_stringify_full+0xc28>
10084a888:     	mov	x0, x23
10084a88c:     	bl	0x10050d240 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
10084a890:     	tbnz	w0, #0x0, 0x10084a9a8 <_js_json_stringify_full+0xc28>
10084a894:     	lsr	x8, x23, #51
10084a898:     	cmp	x8, #0xfff
10084a89c:     	b.lo	0x10084a8b4 <_js_json_stringify_full+0xb34>
10084a8a0:     	mov	w8, #0x7ffc             ; =32764
10084a8a4:     	cmp	x8, x23, lsr #48
10084a8a8:     	b.eq	0x10084a9a8 <_js_json_stringify_full+0xc28>
10084a8ac:     	ands	x23, x23, #0xffffffffffff
10084a8b0:     	b.eq	0x10084a9a8 <_js_json_stringify_full+0xc28>
10084a8b4:     	and	x8, x23, #0xfffffffffff00000
10084a8b8:     	lsr	x9, x23, #47
10084a8bc:     	cmp	x9, #0x0
10084a8c0:     	ccmp	x8, #0x0, #0x4, eq
10084a8c4:     	b.eq	0x10084a9a8 <_js_json_stringify_full+0xc28>
10084a8c8:     	tst	x23, #0x3
10084a8cc:     	ccmp	x23, #0x7, #0x0, eq
10084a8d0:     	b.ls	0x10084b614 <_js_json_stringify_full+0x1894>
10084a8d4:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084a8d8:     	ldr	x8, [x8, #0x48]
10084a8dc:     	cmn	x8, #0x1
10084a8e0:     	b.eq	0x10084b564 <_js_json_stringify_full+0x17e4>
10084a8e4:     	mrs	x9, TPIDRRO_EL0
10084a8e8:     	and	x9, x9, #0xfffffffffffffff8
10084a8ec:     	ldr	x0, [x9, x8, lsl #3]
10084a8f0:     	cbz	x0, 0x10084b564 <_js_json_stringify_full+0x17e4>
10084a8f4:     	lsr	x1, x23, #20
10084a8f8:     	ldr	x8, [x0, #0x10]
10084a8fc:     	ldrb	w9, [x8]
10084a900:     	cmp	w9, #0x2
10084a904:     	b.ne	0x10084b57c <_js_json_stringify_full+0x17fc>
10084a908:     	ldrb	w9, [x8, #0x88]
10084a90c:     	tbz	w9, #0x0, 0x10084a92c <_js_json_stringify_full+0xbac>
10084a910:     	ldr	x9, [x8, #0x80]
10084a914:     	cmp	x9, x1
10084a918:     	b.ne	0x10084a92c <_js_json_stringify_full+0xbac>
10084a91c:     	ldp	x9, x10, [x8, #0x60]
10084a920:     	cmp	x9, x23
10084a924:     	ccmp	x10, x23, #0x0, ls
10084a928:     	b.hi	0x10084b55c <_js_json_stringify_full+0x17dc>
10084a92c:     	ldrb	w9, [x8, #0xb8]
10084a930:     	cbz	w9, 0x10084a950 <_js_json_stringify_full+0xbd0>
10084a934:     	ldr	x9, [x8, #0xb0]
10084a938:     	cmp	x9, x1
10084a93c:     	b.ne	0x10084a950 <_js_json_stringify_full+0xbd0>
10084a940:     	ldp	x9, x10, [x8, #0x90]
10084a944:     	cmp	x9, x23
10084a948:     	ccmp	x10, x23, #0x0, ls
10084a94c:     	b.hi	0x10084b7e4 <_js_json_stringify_full+0x1a64>
10084a950:     	ldrb	w9, [x8, #0xe8]
10084a954:     	cbz	w9, 0x10084b39c <_js_json_stringify_full+0x161c>
10084a958:     	ldr	x9, [x8, #0xe0]
10084a95c:     	cmp	x9, x1
10084a960:     	b.ne	0x10084b39c <_js_json_stringify_full+0x161c>
10084a964:     	ldr	x9, [x8, #0xc0]
10084a968:     	cmp	x9, x23
10084a96c:     	b.hi	0x10084b39c <_js_json_stringify_full+0x161c>
10084a970:     	ldr	x9, [x8, #0xc8]
10084a974:     	cmp	x9, x23
10084a978:     	b.ls	0x10084b39c <_js_json_stringify_full+0x161c>
10084a97c:     	add	x9, x8, #0xc0
10084a980:     	b	0x10084b7e8 <_js_json_stringify_full+0x1a68>
10084a984:     	lsr	x8, x21, #52
10084a988:     	cbnz	x8, 0x10084a9a8 <_js_json_stringify_full+0xc28>
10084a98c:     	cbz	x21, 0x10084a9a8 <_js_json_stringify_full+0xc28>
10084a990:     	and	x8, x21, #0x7
10084a994:     	cbnz	x8, 0x10084a9a8 <_js_json_stringify_full+0xc28>
10084a998:     	mov	x0, x21
10084a99c:     	bl	0x100511d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084a9a0:     	mov	x23, x21
10084a9a4:     	cbnz	w0, 0x10084a880 <_js_json_stringify_full+0xb00>
10084a9a8:     	mov	x25, #-0x1              ; =-1
10084a9ac:     	str	x25, [sp, #0x30]
10084a9b0:     	mov	w24, #0x1               ; =1
10084a9b4:     	cmp	x27, #0x1
10084a9b8:     	cset	w8, hi
10084a9bc:     	tst	w8, w24
10084a9c0:     	b.eq	0x10084aa34 <_js_json_stringify_full+0xcb4>
10084a9c4:     	and	x23, x21, #0xffff000000000000
10084a9c8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084a9cc:     	cmp	x23, x8
10084a9d0:     	b.ne	0x10084aa0c <_js_json_stringify_full+0xc8c>
10084a9d4:     	and	x8, x21, #0xffffffffffff
10084a9d8:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084a9dc:     	b.lo	0x10084aa34 <_js_json_stringify_full+0xcb4>
10084a9e0:     	ldr	w8, [x8, #0xc]
10084a9e4:     	mov	w9, #0x4f53             ; =20307
10084a9e8:     	movk	w9, #0x434c, lsl #16
10084a9ec:     	cmp	w8, w9
10084a9f0:     	b.ne	0x10084aa34 <_js_json_stringify_full+0xcb4>
10084a9f4:     	and	x8, x21, #0xffffffffffff
10084a9f8:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084a9fc:     	cmp	x23, x9
10084aa00:     	csel	x28, x8, x21, eq
10084aa04:     	mov	w27, #0x1               ; =1
10084aa08:     	b	0x10084aa38 <_js_json_stringify_full+0xcb8>
10084aa0c:     	lsr	x8, x21, #52
10084aa10:     	cbnz	x8, 0x10084aa34 <_js_json_stringify_full+0xcb4>
10084aa14:     	mov	w27, #0x0               ; =0
10084aa18:     	cbz	x21, 0x10084aa38 <_js_json_stringify_full+0xcb8>
10084aa1c:     	and	x8, x21, #0x7
10084aa20:     	cbnz	x8, 0x10084aa38 <_js_json_stringify_full+0xcb8>
10084aa24:     	mov	x0, x21
10084aa28:     	bl	0x100511d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084aa2c:     	mov	x8, x21
10084aa30:     	tbnz	w0, #0x0, 0x10084a9d8 <_js_json_stringify_full+0xc58>
10084aa34:     	mov	w27, #0x0               ; =0
10084aa38:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084aa3c:     	add	x0, x0, #0xd78
10084aa40:     	ldr	x8, [x0]
10084aa44:     	blr	x8
10084aa48:     	mov	x21, x0
10084aa4c:     	ldr	w26, [x0]
10084aa50:     	add	w8, w26, #0x1
10084aa54:     	str	w8, [x0]
10084aa58:     	cbz	w26, 0x10084aac8 <_js_json_stringify_full+0xd48>
10084aa5c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084aa60:     	add	x0, x0, #0xd00
10084aa64:     	ldr	x8, [x0]
10084aa68:     	blr	x8
10084aa6c:     	ldrb	w8, [x0, #0x20]
10084aa70:     	cmp	w8, #0x1
10084aa74:     	b.ne	0x10084b854 <_js_json_stringify_full+0x1ad4>
10084aa78:     	ldr	x8, [x0]
10084aa7c:     	cbnz	x8, 0x10084b860 <_js_json_stringify_full+0x1ae0>
10084aa80:     	mov	x8, #-0x1               ; =-1
10084aa84:     	str	x8, [x0]
10084aa88:     	ldr	x23, [x0, #0x18]
10084aa8c:     	ldr	x8, [x0, #0x8]
10084aa90:     	cmp	x23, x8
10084aa94:     	b.eq	0x10084b250 <_js_json_stringify_full+0x14d0>
10084aa98:     	ldr	x8, [x0, #0x10]
10084aa9c:     	mov	w9, #0x18               ; =24
10084aaa0:     	madd	x8, x23, x9, x8
10084aaa4:     	mov	w9, #0x8                ; =8
10084aaa8:     	stp	xzr, x9, [x8]
10084aaac:     	str	xzr, [x8, #0x10]
10084aab0:     	add	x8, x23, #0x1
10084aab4:     	str	x8, [x0, #0x18]
10084aab8:     	ldr	x8, [x0]
10084aabc:     	add	x8, x8, #0x1
10084aac0:     	str	x8, [x0]
10084aac4:     	b	0x10084ab30 <_js_json_stringify_full+0xdb0>
10084aac8:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084aacc:     	add	x0, x0, #0xdc0
10084aad0:     	ldr	x8, [x0]
10084aad4:     	blr	x8
10084aad8:     	strb	wzr, [x0]
10084aadc:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084aae0:     	add	x0, x0, #0xdf0
10084aae4:     	ldr	x8, [x0]
10084aae8:     	blr	x8
10084aaec:     	strb	wzr, [x0]
10084aaf0:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
10084aaf4:     	ldr	w23, [x8, #0x5a8]
10084aaf8:     	cmp	w23, #0x300
10084aafc:     	b.hs	0x10084b298 <_js_json_stringify_full+0x1518>
10084ab00:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
10084ab04:     	ldr	x8, [x8, #0x48]
10084ab08:     	cmn	x8, #0x1
10084ab0c:     	b.eq	0x10084b288 <_js_json_stringify_full+0x1508>
10084ab10:     	mrs	x9, TPIDRRO_EL0
10084ab14:     	and	x9, x9, #0xfffffffffffffff8
10084ab18:     	ldr	x0, [x9, x8, lsl #3]
10084ab1c:     	cbz	x0, 0x10084b288 <_js_json_stringify_full+0x1508>
10084ab20:     	add	x8, x0, x23, lsl #3
10084ab24:     	ldr	x0, [x8, #0x1e8]
10084ab28:     	cbz	x0, 0x10084b298 <_js_json_stringify_full+0x1518>
10084ab2c:     	str	xzr, [x0]
10084ab30:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084ab34:     	add	x0, x0, #0xd30
10084ab38:     	ldr	x8, [x0]
10084ab3c:     	blr	x8
10084ab40:     	mov	x23, x0
10084ab44:     	ldrb	w8, [x0, #0x18]
10084ab48:     	cmp	w8, #0x1
10084ab4c:     	b.ne	0x10084b808 <_js_json_stringify_full+0x1a88>
10084ab50:     	ldr	x8, [x0]
10084ab54:     	mov	x9, #-0x1               ; =-1
10084ab58:     	str	x9, [x0]
10084ab5c:     	cmn	x8, #0x2
10084ab60:     	b.eq	0x10084b990 <_js_json_stringify_full+0x1c10>
10084ab64:     	cmn	x8, #0x1
10084ab68:     	b.eq	0x10084ac3c <_js_json_stringify_full+0xebc>
10084ab6c:     	add	x9, sp, #0x48
10084ab70:     	ldur	q0, [x0, #0x8]
10084ab74:     	stur	q0, [x9, #0x8]
10084ab78:     	str	x8, [sp, #0x48]
10084ab7c:     	tbz	w24, #0x0, 0x10084ac50 <_js_json_stringify_full+0xed0>
10084ab80:     	tbz	w27, #0x0, 0x10084ad38 <_js_json_stringify_full+0xfb8>
10084ab84:     	bl	0x10028dd98 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
10084ab88:     	str	x0, [sp, #0x60]
10084ab8c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084ab90:     	stp	x28, x8, [sp, #0x88]
10084ab94:     	mov	w8, #0x1                ; =1
10084ab98:     	str	x8, [sp, #0x80]
10084ab9c:     	add	x0, sp, #0x80
10084aba0:     	bl	0x10028dea0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
10084aba4:     	mov	x22, x0
10084aba8:     	str	x0, [sp, #0x68]
10084abac:     	mov	w0, #0x0                ; =0
10084abb0:     	bl	0x10034db2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084abb4:     	stp	xzr, xzr, [x0]
10084abb8:     	str	wzr, [x0, #0x10]
10084abbc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10084abc0:     	bfxil	x8, x0, #0, #48
10084abc4:     	fmov	d0, x8
10084abc8:     	bl	0x10020b024 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
10084abcc:     	mov	x19, x0
10084abd0:     	adrp	x24, 0x100f84000 <_perry_global_worker_ts__1>
10084abd4:     	ldr	x8, [x24, #0x48]
10084abd8:     	cmn	x8, #0x1
10084abdc:     	b.eq	0x10084ad9c <_js_json_stringify_full+0x101c>
10084abe0:     	mrs	x9, TPIDRRO_EL0
10084abe4:     	and	x9, x9, #0xfffffffffffffff8
10084abe8:     	ldr	x8, [x9, x8, lsl #3]
10084abec:     	cbz	x8, 0x10084ad9c <_js_json_stringify_full+0x101c>
10084abf0:     	ldr	x8, [x8, #0x19e8]
10084abf4:     	cbz	x8, 0x10084ad9c <_js_json_stringify_full+0x101c>
10084abf8:     	ldr	x9, [x8]
10084abfc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084ac00:     	cmp	x9, x10
10084ac04:     	b.hs	0x10084b8dc <_js_json_stringify_full+0x1b5c>
10084ac08:     	add	x10, x9, #0x1
10084ac0c:     	str	x10, [x8]
10084ac10:     	ldr	x10, [x8, #0x18]
10084ac14:     	cmp	x19, x10
10084ac18:     	b.hs	0x10084b8e8 <_js_json_stringify_full+0x1b68>
10084ac1c:     	ldr	x10, [x8, #0x10]
10084ac20:     	mov	w11, #0x18              ; =24
10084ac24:     	madd	x10, x19, x11, x10
10084ac28:     	ldr	x11, [x10]
10084ac2c:     	cbnz	x11, 0x10084b948 <_js_json_stringify_full+0x1bc8>
10084ac30:     	ldr	x0, [x10, #0x8]
10084ac34:     	str	x9, [x8]
10084ac38:     	b	0x10084ada4 <_js_json_stringify_full+0x1024>
10084ac3c:     	mov	x8, #0x0                ; =0
10084ac40:     	mov	w9, #0x1                ; =1
10084ac44:     	stp	x9, xzr, [sp, #0x50]
10084ac48:     	str	x8, [sp, #0x48]
10084ac4c:     	tbnz	w24, #0x0, 0x10084ab80 <_js_json_stringify_full+0xe00>
10084ac50:     	cmp	x22, #0x0
10084ac54:     	cset	w6, ne
10084ac58:     	ldp	x0, x1, [sp, #0x38]
10084ac5c:     	ldp	x3, x4, [sp, #0x18]
10084ac60:     	add	x2, sp, #0x48
10084ac64:     	mov.16b	v0, v8
10084ac68:     	mov	x5, #0x0                ; =0
10084ac6c:     	bl	0x100505780 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
10084ac70:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084ac74:     	add	x0, x0, #0xd90
10084ac78:     	ldr	x8, [x0]
10084ac7c:     	blr	x8
10084ac80:     	ldrb	w8, [x0, #0x20]
10084ac84:     	cbnz	w8, 0x10084b86c <_js_json_stringify_full+0x1aec>
10084ac88:     	ldr	x8, [x0]
10084ac8c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10084ac90:     	cmp	x8, x9
10084ac94:     	b.hs	0x10084b89c <_js_json_stringify_full+0x1b1c>
10084ac98:     	ldr	x9, [x0, #0x18]
10084ac9c:     	cbz	x9, 0x10084aca8 <_js_json_stringify_full+0xf28>
10084aca0:     	cbnz	x8, 0x10084b8a8 <_js_json_stringify_full+0x1b28>
10084aca4:     	str	xzr, [x0, #0x18]
10084aca8:     	ldp	x0, x1, [sp, #0x50]
10084acac:     	cmp	x1, #0x5
10084acb0:     	b.hi	0x10084ad18 <_js_json_stringify_full+0xf98>
10084acb4:     	cbz	x1, 0x10084af28 <_js_json_stringify_full+0x11a8>
10084acb8:     	ldrsb	w8, [x0]
10084acbc:     	tbnz	w8, #0x1f, 0x10084ad18 <_js_json_stringify_full+0xf98>
10084acc0:     	cmp	x1, #0x1
10084acc4:     	b.eq	0x10084ad00 <_js_json_stringify_full+0xf80>
10084acc8:     	ldrsb	w8, [x0, #0x1]
10084accc:     	tbnz	w8, #0x1f, 0x10084ad18 <_js_json_stringify_full+0xf98>
10084acd0:     	cmp	x1, #0x2
10084acd4:     	b.eq	0x10084ad00 <_js_json_stringify_full+0xf80>
10084acd8:     	ldrsb	w8, [x0, #0x2]
10084acdc:     	tbnz	w8, #0x1f, 0x10084ad18 <_js_json_stringify_full+0xf98>
10084ace0:     	cmp	x1, #0x3
10084ace4:     	b.eq	0x10084ad00 <_js_json_stringify_full+0xf80>
10084ace8:     	ldrsb	w8, [x0, #0x3]
10084acec:     	tbnz	w8, #0x1f, 0x10084ad18 <_js_json_stringify_full+0xf98>
10084acf0:     	cmp	x1, #0x4
10084acf4:     	b.eq	0x10084ad00 <_js_json_stringify_full+0xf80>
10084acf8:     	ldrsb	w8, [x0, #0x4]
10084acfc:     	tbnz	w8, #0x1f, 0x10084ad18 <_js_json_stringify_full+0xf98>
10084ad00:     	cmp	x1, #0x4
10084ad04:     	b.hs	0x10084b068 <_js_json_stringify_full+0x12e8>
10084ad08:     	mov	x10, #0x0               ; =0
10084ad0c:     	mov	x9, #0x0                ; =0
10084ad10:     	mov	x8, x0
10084ad14:     	b	0x10084b0f8 <_js_json_stringify_full+0x1378>
10084ad18:     	bl	0x10032c808 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
10084ad1c:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
10084ad20:     	bfxil	x20, x0, #0, #48
10084ad24:     	ldp	x22, x0, [sp, #0x48]
10084ad28:     	ldrb	w8, [x23, #0x18]
10084ad2c:     	cmp	w8, #0x1
10084ad30:     	b.eq	0x10084b134 <_js_json_stringify_full+0x13b4>
10084ad34:     	b	0x10084b838 <_js_json_stringify_full+0x1ab8>
10084ad38:     	mov	w0, #0x0                ; =0
10084ad3c:     	bl	0x10034db2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10084ad40:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10084ad44:     	bfxil	x8, x0, #0, #48
10084ad48:     	fmov	d1, x8
10084ad4c:     	stp	xzr, xzr, [x0]
10084ad50:     	str	wzr, [x0, #0x10]
10084ad54:     	mov.16b	v0, v8
10084ad58:     	bl	0x1006ca220 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
10084ad5c:     	mov.16b	v8, v0
10084ad60:     	fmov	x24, d8
10084ad64:     	cmp	x24, x20
10084ad68:     	b.eq	0x10084afb0 <_js_json_stringify_full+0x1230>
10084ad6c:     	mov	w8, #0x7ffd             ; =32765
10084ad70:     	cmp	x8, x24, lsr #48
10084ad74:     	b.ne	0x10084af80 <_js_json_stringify_full+0x1200>
10084ad78:     	and	x8, x24, #0xffffffffffff
10084ad7c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
10084ad80:     	b.lo	0x10084afa4 <_js_json_stringify_full+0x1224>
10084ad84:     	ldr	w8, [x8, #0xc]
10084ad88:     	mov	w9, #0x4f53             ; =20307
10084ad8c:     	movk	w9, #0x434c, lsl #16
10084ad90:     	cmp	w8, w9
10084ad94:     	b.ne	0x10084afa4 <_js_json_stringify_full+0x1224>
10084ad98:     	b	0x10084afb0 <_js_json_stringify_full+0x1230>
10084ad9c:     	mov	x0, x19
10084ada0:     	bl	0x10013c270 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
10084ada4:     	fmov	d1, x0
10084ada8:     	mov.16b	v0, v8
10084adac:     	bl	0x1006ca220 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
10084adb0:     	mov.16b	v8, v0
10084adb4:     	ldr	x8, [x24, #0x48]
10084adb8:     	cmn	x8, #0x1
10084adbc:     	b.eq	0x10084ae20 <_js_json_stringify_full+0x10a0>
10084adc0:     	mrs	x9, TPIDRRO_EL0
10084adc4:     	and	x9, x9, #0xfffffffffffffff8
10084adc8:     	ldr	x8, [x9, x8, lsl #3]
10084adcc:     	cbz	x8, 0x10084ae20 <_js_json_stringify_full+0x10a0>
10084add0:     	ldr	x8, [x8, #0x19e8]
10084add4:     	cbz	x8, 0x10084ae20 <_js_json_stringify_full+0x10a0>
10084add8:     	ldr	x9, [x8]
10084addc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084ade0:     	cmp	x9, x10
10084ade4:     	b.hs	0x10084b8dc <_js_json_stringify_full+0x1b5c>
10084ade8:     	add	x10, x9, #0x1
10084adec:     	str	x10, [x8]
10084adf0:     	ldr	x10, [x8, #0x18]
10084adf4:     	cmp	x22, x10
10084adf8:     	b.hs	0x10084b8e8 <_js_json_stringify_full+0x1b68>
10084adfc:     	ldr	x10, [x8, #0x10]
10084ae00:     	mov	w11, #0x18              ; =24
10084ae04:     	madd	x10, x22, x11, x10
10084ae08:     	ldr	x11, [x10]
10084ae0c:     	cmp	x11, #0x1
10084ae10:     	b.ne	0x10084b9a8 <_js_json_stringify_full+0x1c28>
10084ae14:     	ldr	x22, [x10, #0x8]
10084ae18:     	str	x9, [x8]
10084ae1c:     	b	0x10084ae2c <_js_json_stringify_full+0x10ac>
10084ae20:     	mov	x0, x22
10084ae24:     	bl	0x10013c198 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
10084ae28:     	mov	x22, x0
10084ae2c:     	ldr	x8, [x24, #0x48]
10084ae30:     	cmn	x8, #0x1
10084ae34:     	b.eq	0x10084ae94 <_js_json_stringify_full+0x1114>
10084ae38:     	mrs	x9, TPIDRRO_EL0
10084ae3c:     	and	x9, x9, #0xfffffffffffffff8
10084ae40:     	ldr	x8, [x9, x8, lsl #3]
10084ae44:     	cbz	x8, 0x10084ae94 <_js_json_stringify_full+0x1114>
10084ae48:     	ldr	x8, [x8, #0x19e8]
10084ae4c:     	cbz	x8, 0x10084ae94 <_js_json_stringify_full+0x1114>
10084ae50:     	ldr	x9, [x8]
10084ae54:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084ae58:     	cmp	x9, x10
10084ae5c:     	b.hs	0x10084b8dc <_js_json_stringify_full+0x1b5c>
10084ae60:     	add	x10, x9, #0x1
10084ae64:     	str	x10, [x8]
10084ae68:     	ldr	x10, [x8, #0x18]
10084ae6c:     	cmp	x19, x10
10084ae70:     	b.hs	0x10084b8e8 <_js_json_stringify_full+0x1b68>
10084ae74:     	ldr	x10, [x8, #0x10]
10084ae78:     	mov	w11, #0x18              ; =24
10084ae7c:     	madd	x10, x19, x11, x10
10084ae80:     	ldr	x11, [x10]
10084ae84:     	cbnz	x11, 0x10084b948 <_js_json_stringify_full+0x1bc8>
10084ae88:     	ldr	x0, [x10, #0x8]
10084ae8c:     	str	x9, [x8]
10084ae90:     	b	0x10084ae9c <_js_json_stringify_full+0x111c>
10084ae94:     	mov	x0, x19
10084ae98:     	bl	0x10013c270 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
10084ae9c:     	fmov	d9, x0
10084aea0:     	mov.16b	v0, v8
10084aea4:     	bl	0x100502124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
10084aea8:     	mov.16b	v2, v0
10084aeac:     	mov	x0, x22
10084aeb0:     	mov.16b	v0, v9
10084aeb4:     	mov.16b	v1, v8
10084aeb8:     	bl	0x100502404 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
10084aebc:     	str	d0, [sp, #0x70]
10084aec0:     	fmov	x19, d0
10084aec4:     	cmp	x19, x20
10084aec8:     	b.ne	0x10084af30 <_js_json_stringify_full+0x11b0>
10084aecc:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084aed0:     	add	x0, x0, #0xd90
10084aed4:     	ldr	x8, [x0]
10084aed8:     	blr	x8
10084aedc:     	ldrb	w8, [x0, #0x20]
10084aee0:     	cbnz	w8, 0x10084b988 <_js_json_stringify_full+0x1c08>
10084aee4:     	ldr	x8, [x0]
10084aee8:     	cbnz	x8, 0x10084b9d8 <_js_json_stringify_full+0x1c58>
10084aeec:     	str	xzr, [x0, #0x18]
10084aef0:     	ldp	x22, x19, [sp, #0x48]
10084aef4:     	ldrb	w8, [x23, #0x18]
10084aef8:     	cmp	w8, #0x1
10084aefc:     	b.ne	0x10084b920 <_js_json_stringify_full+0x1ba0>
10084af00:     	ldp	x8, x0, [x23]
10084af04:     	stp	x22, x19, [x23]
10084af08:     	str	xzr, [x23, #0x10]
10084af0c:     	sub	x8, x8, #0x1
10084af10:     	cmn	x8, #0x2
10084af14:     	b.hs	0x10084af1c <_js_json_stringify_full+0x119c>
10084af18:     	bl	0x100b63800 <_mi_free>
10084af1c:     	cbz	w26, 0x10084b1bc <_js_json_stringify_full+0x143c>
10084af20:     	bl	0x10032aa68 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084af24:     	b	0x10084b1c0 <_js_json_stringify_full+0x1440>
10084af28:     	mov	x10, #0x0               ; =0
10084af2c:     	b	0x10084b118 <_js_json_stringify_full+0x1398>
10084af30:     	add	x0, sp, #0x48
10084af34:     	bl	0x100502de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
10084af38:     	tbnz	w0, #0x0, 0x10084af74 <_js_json_stringify_full+0x11f4>
10084af3c:     	mov	x0, x19
10084af40:     	bl	0x10032a76c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
10084af44:     	cmp	x0, #0x1
10084af48:     	b.ne	0x10084b99c <_js_json_stringify_full+0x1c1c>
10084af4c:     	add	x8, sp, #0x78
10084af50:     	add	x9, sp, #0x70
10084af54:     	stp	x1, x8, [sp, #0x78]
10084af58:     	str	x9, [sp, #0x88]
10084af5c:     	add	x8, sp, #0x48
10084af60:     	add	x9, sp, #0x10
10084af64:     	stp	x8, x9, [sp, #0x90]
10084af68:     	add	x0, sp, #0x68
10084af6c:     	add	x1, sp, #0x80
10084af70:     	bl	0x100143c90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
10084af74:     	add	x0, sp, #0x60
10084af78:     	bl	0x100166d7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
10084af7c:     	b	0x10084ac70 <_js_json_stringify_full+0xef0>
10084af80:     	lsr	x8, x24, #52
10084af84:     	cbnz	x8, 0x10084afa4 <_js_json_stringify_full+0x1224>
10084af88:     	cbz	x24, 0x10084afa4 <_js_json_stringify_full+0x1224>
10084af8c:     	and	x8, x24, #0x7
10084af90:     	cbnz	x8, 0x10084afa4 <_js_json_stringify_full+0x1224>
10084af94:     	mov	x0, x24
10084af98:     	bl	0x100511d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084af9c:     	mov	x8, x24
10084afa0:     	tbnz	w0, #0x0, 0x10084ad7c <_js_json_stringify_full+0xffc>
10084afa4:     	mov	x0, x24
10084afa8:     	bl	0x10050c0ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
10084afac:     	tbz	w0, #0x0, 0x10084b03c <_js_json_stringify_full+0x12bc>
10084afb0:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084afb4:     	add	x0, x0, #0xd90
10084afb8:     	ldr	x8, [x0]
10084afbc:     	blr	x8
10084afc0:     	ldrb	w8, [x0, #0x20]
10084afc4:     	cbnz	w8, 0x10084b8ec <_js_json_stringify_full+0x1b6c>
10084afc8:     	ldr	x8, [x0]
10084afcc:     	cbnz	x8, 0x10084b914 <_js_json_stringify_full+0x1b94>
10084afd0:     	str	xzr, [x0, #0x18]
10084afd4:     	ldp	x22, x19, [sp, #0x48]
10084afd8:     	ldrb	w8, [x23, #0x18]
10084afdc:     	cmp	w8, #0x1
10084afe0:     	b.ne	0x10084b8c8 <_js_json_stringify_full+0x1b48>
10084afe4:     	ldp	x8, x0, [x23]
10084afe8:     	stp	x22, x19, [x23]
10084afec:     	str	xzr, [x23, #0x10]
10084aff0:     	sub	x8, x8, #0x1
10084aff4:     	cmn	x8, #0x2
10084aff8:     	b.hs	0x10084b000 <_js_json_stringify_full+0x1280>
10084affc:     	bl	0x100b63800 <_mi_free>
10084b000:     	cbz	w26, 0x10084b020 <_js_json_stringify_full+0x12a0>
10084b004:     	bl	0x10032aa68 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b008:     	ldr	w8, [x21]
10084b00c:     	sub	w8, w8, #0x1
10084b010:     	str	w8, [x21]
10084b014:     	cmn	x25, #0x1
10084b018:     	b.ne	0x10084b1dc <_js_json_stringify_full+0x145c>
10084b01c:     	b	0x10084b218 <_js_json_stringify_full+0x1498>
10084b020:     	bl	0x10032a898 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b024:     	ldr	w8, [x21]
10084b028:     	sub	w8, w8, #0x1
10084b02c:     	str	w8, [x21]
10084b030:     	cmn	x25, #0x1
10084b034:     	b.ne	0x10084b1dc <_js_json_stringify_full+0x145c>
10084b038:     	b	0x10084b218 <_js_json_stringify_full+0x1498>
10084b03c:     	cmp	x19, x24
10084b040:     	b.eq	0x10084b04c <_js_json_stringify_full+0x12cc>
10084b044:     	mov.16b	v0, v8
10084b048:     	bl	0x10051146c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
10084b04c:     	cbz	x22, 0x10084b2a8 <_js_json_stringify_full+0x1528>
10084b050:     	ldp	x1, x2, [sp, #0x18]
10084b054:     	add	x0, sp, #0x48
10084b058:     	mov.16b	v0, v8
10084b05c:     	mov	x3, #0x0                ; =0
10084b060:     	bl	0x10050385c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
10084b064:     	b	0x10084b2b8 <_js_json_stringify_full+0x1538>
10084b068:     	and	x9, x1, #0x4
10084b06c:     	add	x8, x0, x9
10084b070:     	adrp	x10, 0x100c9e000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x55f0>
10084b074:     	ldr	q0, [x10, #0x280]
10084b078:     	adrp	x10, 0x100c3e000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33dfa>
10084b07c:     	ldr	q2, [x10, #0x180]
10084b080:     	movi.2d	v1, #0000000000000000
10084b084:     	movi.2d	v3, #0x000000000000ff
10084b088:     	mov	w10, #0x4               ; =4
10084b08c:     	dup.2d	v4, x10
10084b090:     	mov	x10, x0
10084b094:     	and	x11, x1, #0x4
10084b098:     	movi.2d	v5, #0000000000000000
10084b09c:     	ldr	s6, [x10], #0x4
10084b0a0:     	ushll.8h	v6, v6, #0x0
10084b0a4:     	ushll.4s	v6, v6, #0x0
10084b0a8:     	ushll2.2d	v7, v6, #0x0
10084b0ac:     	and.16b	v7, v7, v3
10084b0b0:     	ushll.2d	v6, v6, #0x0
10084b0b4:     	and.16b	v6, v6, v3
10084b0b8:     	shl.2d	v16, v0, #0x3
10084b0bc:     	shl.2d	v17, v2, #0x3
10084b0c0:     	ushl.2d	v6, v6, v17
10084b0c4:     	ushl.2d	v7, v7, v16
10084b0c8:     	orr.16b	v1, v7, v1
10084b0cc:     	orr.16b	v5, v6, v5
10084b0d0:     	add.2d	v0, v0, v4
10084b0d4:     	add.2d	v2, v2, v4
10084b0d8:     	subs	x11, x11, #0x4
10084b0dc:     	b.ne	0x10084b09c <_js_json_stringify_full+0x131c>
10084b0e0:     	orr.16b	v0, v5, v1
10084b0e4:     	mov	d1, v0[1]
10084b0e8:     	orr.8b	v0, v0, v1
10084b0ec:     	fmov	x10, d0
10084b0f0:     	cmp	x1, x9
10084b0f4:     	b.eq	0x10084b118 <_js_json_stringify_full+0x1398>
10084b0f8:     	add	x11, x0, x1
10084b0fc:     	lsl	x9, x9, #3
10084b100:     	ldrb	w12, [x8], #0x1
10084b104:     	lsl	x12, x12, x9
10084b108:     	orr	x10, x12, x10
10084b10c:     	add	x9, x9, #0x8
10084b110:     	cmp	x8, x11
10084b114:     	b.ne	0x10084b100 <_js_json_stringify_full+0x1380>
10084b118:     	orr	x8, x10, x1, lsl #40
10084b11c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084b120:     	orr	x20, x8, x9
10084b124:     	ldr	x22, [sp, #0x48]
10084b128:     	ldrb	w8, [x23, #0x18]
10084b12c:     	cmp	w8, #0x1
10084b130:     	b.ne	0x10084b838 <_js_json_stringify_full+0x1ab8>
10084b134:     	ldp	x9, x8, [x23]
10084b138:     	stp	x22, x0, [x23]
10084b13c:     	str	xzr, [x23, #0x10]
10084b140:     	sub	x9, x9, #0x1
10084b144:     	cmn	x9, #0x2
10084b148:     	b.hs	0x10084b154 <_js_json_stringify_full+0x13d4>
10084b14c:     	mov	x0, x8
10084b150:     	bl	0x100b63800 <_mi_free>
10084b154:     	cbz	w26, 0x10084b174 <_js_json_stringify_full+0x13f4>
10084b158:     	bl	0x10032aa68 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084b15c:     	ldr	w8, [x21]
10084b160:     	sub	w8, w8, #0x1
10084b164:     	str	w8, [x21]
10084b168:     	cmn	x25, #0x1
10084b16c:     	b.ne	0x10084b18c <_js_json_stringify_full+0x140c>
10084b170:     	b	0x10084b218 <_js_json_stringify_full+0x1498>
10084b174:     	bl	0x10032a898 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b178:     	ldr	w8, [x21]
10084b17c:     	sub	w8, w8, #0x1
10084b180:     	str	w8, [x21]
10084b184:     	cmn	x25, #0x1
10084b188:     	b.eq	0x10084b218 <_js_json_stringify_full+0x1498>
10084b18c:     	ldp	x19, x21, [sp, #0x38]
10084b190:     	cbz	x21, 0x10084b20c <_js_json_stringify_full+0x148c>
10084b194:     	add	x22, x19, #0x8
10084b198:     	b	0x10084b1a8 <_js_json_stringify_full+0x1428>
10084b19c:     	add	x22, x22, #0x18
10084b1a0:     	subs	x21, x21, #0x1
10084b1a4:     	b.eq	0x10084b20c <_js_json_stringify_full+0x148c>
10084b1a8:     	ldur	x8, [x22, #-0x8]
10084b1ac:     	cbz	x8, 0x10084b19c <_js_json_stringify_full+0x141c>
10084b1b0:     	ldr	x0, [x22]
10084b1b4:     	bl	0x100b63800 <_mi_free>
10084b1b8:     	b	0x10084b19c <_js_json_stringify_full+0x141c>
10084b1bc:     	bl	0x10032a898 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084b1c0:     	ldr	w8, [x21]
10084b1c4:     	sub	w8, w8, #0x1
10084b1c8:     	str	w8, [x21]
10084b1cc:     	add	x0, sp, #0x60
10084b1d0:     	bl	0x100166d7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
10084b1d4:     	cmn	x25, #0x1
10084b1d8:     	b.eq	0x10084b218 <_js_json_stringify_full+0x1498>
10084b1dc:     	ldp	x19, x21, [sp, #0x38]
10084b1e0:     	cbz	x21, 0x10084b20c <_js_json_stringify_full+0x148c>
10084b1e4:     	add	x22, x19, #0x8
10084b1e8:     	b	0x10084b1f8 <_js_json_stringify_full+0x1478>
10084b1ec:     	add	x22, x22, #0x18
10084b1f0:     	subs	x21, x21, #0x1
10084b1f4:     	b.eq	0x10084b20c <_js_json_stringify_full+0x148c>
10084b1f8:     	ldur	x8, [x22, #-0x8]
10084b1fc:     	cbz	x8, 0x10084b1ec <_js_json_stringify_full+0x146c>
10084b200:     	ldr	x0, [x22]
10084b204:     	bl	0x100b63800 <_mi_free>
10084b208:     	b	0x10084b1ec <_js_json_stringify_full+0x146c>
10084b20c:     	cbz	x25, 0x10084b218 <_js_json_stringify_full+0x1498>
10084b210:     	mov	x0, x19
10084b214:     	bl	0x100b63800 <_mi_free>
10084b218:     	ldr	x8, [sp, #0x10]
10084b21c:     	cbz	x8, 0x10084b228 <_js_json_stringify_full+0x14a8>
10084b220:     	ldr	x0, [sp, #0x18]
10084b224:     	bl	0x100b63800 <_mi_free>
10084b228:     	mov	x0, x20
10084b22c:     	ldp	x29, x30, [sp, #0x110]
10084b230:     	ldp	x20, x19, [sp, #0x100]
10084b234:     	ldp	x22, x21, [sp, #0xf0]
10084b238:     	ldp	x24, x23, [sp, #0xe0]
10084b23c:     	ldp	x26, x25, [sp, #0xd0]
10084b240:     	ldp	x28, x27, [sp, #0xc0]
10084b244:     	ldp	d9, d8, [sp, #0xb0]
10084b248:     	add	sp, sp, #0x120
10084b24c:     	ret
10084b250:     	str	x22, [sp, #0x8]
10084b254:     	mov	x22, x28
10084b258:     	mov	x28, x0
10084b25c:     	add	x0, x0, #0x8
10084b260:     	bl	0x100b40550 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
10084b264:     	mov	x0, x28
10084b268:     	mov	x28, x22
10084b26c:     	ldr	x22, [sp, #0x8]
10084b270:     	b	0x10084aa98 <_js_json_stringify_full+0xd18>
10084b274:     	b.ne	0x10084a7dc <_js_json_stringify_full+0xa5c>
10084b278:     	tbz	x25, #0x3f, 0x10084b2d0 <_js_json_stringify_full+0x1550>
10084b27c:     	mov	x0, #0x0                ; =0
10084b280:     	mov	x1, x25
10084b284:     	bl	0x100b16b80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084b288:     	bl	0x100b43bfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084b28c:     	add	x8, x0, x23, lsl #3
10084b290:     	ldr	x0, [x8, #0x1e8]
10084b294:     	cbnz	x0, 0x10084ab2c <_js_json_stringify_full+0xdac>
10084b298:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084b29c:     	add	x0, x0, #0x138
10084b2a0:     	bl	0x100b4141c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084b2a4:     	b	0x10084ab2c <_js_json_stringify_full+0xdac>
10084b2a8:     	add	x1, sp, #0x48
10084b2ac:     	mov.16b	v0, v8
10084b2b0:     	mov	w0, #0x0                ; =0
10084b2b4:     	bl	0x10050c184 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
10084b2b8:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084b2bc:     	add	x0, x0, #0xdc0
10084b2c0:     	ldr	x8, [x0]
10084b2c4:     	blr	x8
10084b2c8:     	strb	wzr, [x0]
10084b2cc:     	b	0x10084ac70 <_js_json_stringify_full+0xef0>
10084b2d0:     	mov	x0, x25
10084b2d4:     	mov	w1, #0x1                ; =1
10084b2d8:     	bl	0x100b63a88 <_mi_malloc_aligned>
10084b2dc:     	mov	x26, x0
10084b2e0:     	mov	w0, #0x1                ; =1
10084b2e4:     	cbz	x26, 0x10084b280 <_js_json_stringify_full+0x1500>
10084b2e8:     	mov	x0, x26
10084b2ec:     	mov	x1, x23
10084b2f0:     	mov	x2, x25
10084b2f4:     	bl	0x100b666ac <_writev+0x100b666ac>
10084b2f8:     	mov	x22, x25
10084b2fc:     	b	0x10084a800 <_js_json_stringify_full+0xa80>
10084b300:     	cmp	w11, #0x8
10084b304:     	b.eq	0x10084b3d0 <_js_json_stringify_full+0x1650>
10084b308:     	cmp	w11, #0x9
10084b30c:     	b.eq	0x10084b3e0 <_js_json_stringify_full+0x1660>
10084b310:     	cmp	w11, #0xa
10084b314:     	b.ne	0x10084b35c <_js_json_stringify_full+0x15dc>
10084b318:     	mov	w10, #0x6e              ; =110
10084b31c:     	b	0x10084b3e4 <_js_json_stringify_full+0x1664>
10084b320:     	mov	x22, x0
10084b324:     	and	x0, x19, #0xffffffffffff
10084b328:     	bl	0x10034a5c0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084b32c:     	cbz	x0, 0x10084b408 <_js_json_stringify_full+0x1688>
10084b330:     	ldr	w20, [x0]
10084b334:     	cmp	w20, #0x4
10084b338:     	b.hi	0x10084a358 <_js_json_stringify_full+0x5d8>
10084b33c:     	ldr	w8, [x0, #0x4]
10084b340:     	cmp	w20, w8
10084b344:     	b.hi	0x10084a358 <_js_json_stringify_full+0x5d8>
10084b348:     	b	0x10084b40c <_js_json_stringify_full+0x168c>
10084b34c:     	cmp	w11, #0x22
10084b350:     	b.eq	0x10084b3e4 <_js_json_stringify_full+0x1664>
10084b354:     	cmp	w11, #0x5c
10084b358:     	b.eq	0x10084b3e4 <_js_json_stringify_full+0x1664>
10084b35c:     	cmp	x12, #0x3
10084b360:     	mov	w11, #0x20              ; =32
10084b364:     	ccmp	w10, w11, #0x8, ls
10084b368:     	b.lt	0x10084a294 <_js_json_stringify_full+0x514>
10084b36c:     	add	x8, sp, #0x80
10084b370:     	strb	w10, [x8, x12]
10084b374:     	add	x12, x12, #0x1
10084b378:     	b	0x100849f84 <_js_json_stringify_full+0x204>
10084b37c:     	mov	x1, x0
10084b380:     	and	x0, x19, #0xffffffffffff
10084b384:     	mov	x22, x1
10084b388:     	bl	0x1004fb940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
10084b38c:     	cmp	x0, #0x1
10084b390:     	b.ne	0x10084b4b4 <_js_json_stringify_full+0x1734>
10084b394:     	mov	x20, x1
10084b398:     	b	0x10084b228 <_js_json_stringify_full+0x14a8>
10084b39c:     	ldrb	w9, [x8, #0x118]
10084b3a0:     	cbz	w9, 0x10084b5dc <_js_json_stringify_full+0x185c>
10084b3a4:     	ldr	x9, [x8, #0x110]
10084b3a8:     	cmp	x9, x1
10084b3ac:     	b.ne	0x10084b5dc <_js_json_stringify_full+0x185c>
10084b3b0:     	ldr	x9, [x8, #0xf0]
10084b3b4:     	cmp	x9, x23
10084b3b8:     	b.hi	0x10084b5dc <_js_json_stringify_full+0x185c>
10084b3bc:     	ldr	x9, [x8, #0xf8]
10084b3c0:     	cmp	x9, x23
10084b3c4:     	b.ls	0x10084b5dc <_js_json_stringify_full+0x185c>
10084b3c8:     	add	x9, x8, #0xf0
10084b3cc:     	b	0x10084b7e8 <_js_json_stringify_full+0x1a68>
10084b3d0:     	mov	w10, #0x62              ; =98
10084b3d4:     	b	0x10084b3e4 <_js_json_stringify_full+0x1664>
10084b3d8:     	mov	w10, #0x66              ; =102
10084b3dc:     	b	0x10084b3e4 <_js_json_stringify_full+0x1664>
10084b3e0:     	mov	w10, #0x74              ; =116
10084b3e4:     	cmp	x12, #0x2
10084b3e8:     	b.hi	0x10084a294 <_js_json_stringify_full+0x514>
10084b3ec:     	add	x8, sp, #0x80
10084b3f0:     	add	x8, x8, x12
10084b3f4:     	add	x12, x12, #0x2
10084b3f8:     	mov	w11, #0x5c              ; =92
10084b3fc:     	strb	w11, [x8]
10084b400:     	strb	w10, [x8, #0x1]
10084b404:     	b	0x100849f84 <_js_json_stringify_full+0x204>
10084b408:     	mov	x20, #0x0               ; =0
10084b40c:     	ldr	w8, [x22, #0x4]
10084b410:     	lsl	x9, x20, #3
10084b414:     	add	x9, x9, #0x18
10084b418:     	cmp	x9, x8
10084b41c:     	b.hi	0x10084a358 <_js_json_stringify_full+0x5d8>
10084b420:     	ldr	w8, [x25, #0x4]
10084b424:     	mov	w9, #-0x40000000        ; =-1073741824
10084b428:     	cmp	w8, w9
10084b42c:     	csel	w8, w8, wzr, lt
10084b430:     	mov	x22, x0
10084b434:     	mov	x0, x8
10084b438:     	bl	0x1005e82e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084b43c:     	mov	w9, #0x2                ; =2
10084b440:     	cmp	w1, #0x2
10084b444:     	csel	w10, w1, w9, hi
10084b448:     	tst	w0, #0x1
10084b44c:     	csel	x8, x10, x9, ne
10084b450:     	cmp	x20, x8
10084b454:     	b.hi	0x10084a358 <_js_json_stringify_full+0x5d8>
10084b458:     	cbz	x20, 0x10084b818 <_js_json_stringify_full+0x1a98>
10084b45c:     	mov	x0, x22
10084b460:     	mov	x1, x20
10084b464:     	bl	0x1004f2900 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084b468:     	tbz	w0, #0x0, 0x10084a358 <_js_json_stringify_full+0x5d8>
10084b46c:     	cmp	x20, #0x1
10084b470:     	b.eq	0x10084b8b4 <_js_json_stringify_full+0x1b34>
10084b474:     	cmp	x20, #0x2
10084b478:     	b.ne	0x10084b970 <_js_json_stringify_full+0x1bf0>
10084b47c:     	mov	x22, #0x0               ; =0
10084b480:     	add	x25, x25, #0x10
10084b484:     	mov	w8, #0x1                ; =1
10084b488:     	mov	x26, x8
10084b48c:     	ldr	x1, [x25, x22, lsl #3]
10084b490:     	add	x0, sp, #0x80
10084b494:     	bl	0x1004f2954 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
10084b498:     	ldr	w8, [sp, #0x80]
10084b49c:     	cmn	w8, #0x1
10084b4a0:     	b.ne	0x10084b958 <_js_json_stringify_full+0x1bd8>
10084b4a4:     	mov	w8, #0x0                ; =0
10084b4a8:     	mov	w22, #0x1               ; =1
10084b4ac:     	tbnz	w26, #0x0, 0x10084b488 <_js_json_stringify_full+0x1708>
10084b4b0:     	b	0x10084b970 <_js_json_stringify_full+0x1bf0>
10084b4b4:     	and	x0, x19, #0xffffffffffff
10084b4b8:     	bl	0x10034a5c0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084b4bc:     	cbz	x0, 0x10084b548 <_js_json_stringify_full+0x17c8>
10084b4c0:     	ldr	w20, [x0]
10084b4c4:     	cbz	w20, 0x10084b548 <_js_json_stringify_full+0x17c8>
10084b4c8:     	cmp	w20, #0x8
10084b4cc:     	b.hi	0x10084a324 <_js_json_stringify_full+0x5a4>
10084b4d0:     	ldr	w8, [x0, #0x4]
10084b4d4:     	cmp	w20, w8
10084b4d8:     	b.hi	0x10084a324 <_js_json_stringify_full+0x5a4>
10084b4dc:     	ldr	w8, [x22, #0x4]
10084b4e0:     	lsl	x9, x20, #3
10084b4e4:     	add	x9, x9, #0x18
10084b4e8:     	cmp	x9, x8
10084b4ec:     	b.hi	0x10084a324 <_js_json_stringify_full+0x5a4>
10084b4f0:     	ldr	w8, [x25, #0x4]
10084b4f4:     	mov	w9, #-0x40000000        ; =-1073741824
10084b4f8:     	cmp	w8, w9
10084b4fc:     	csel	w8, w8, wzr, lt
10084b500:     	mov	x22, x0
10084b504:     	mov	x0, x8
10084b508:     	bl	0x1005e82e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084b50c:     	mov	w9, #0x2                ; =2
10084b510:     	cmp	w1, #0x2
10084b514:     	csel	w10, w1, w9, hi
10084b518:     	tst	w0, #0x1
10084b51c:     	csel	w8, w10, w9, ne
10084b520:     	cmp	w20, w8
10084b524:     	b.hi	0x10084a324 <_js_json_stringify_full+0x5a4>
10084b528:     	mov	x0, x22
10084b52c:     	mov	x1, x20
10084b530:     	bl	0x1004f2900 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
10084b534:     	cbz	w0, 0x10084a324 <_js_json_stringify_full+0x5a4>
10084b538:     	and	x0, x19, #0xffffffffffff
10084b53c:     	mov	x1, x20
10084b540:     	bl	0x1004faa80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
10084b544:     	b	0x10084b550 <_js_json_stringify_full+0x17d0>
10084b548:     	and	x0, x19, #0xffffffffffff
10084b54c:     	bl	0x1004fb800 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
10084b550:     	mov	x20, x1
10084b554:     	tbz	w0, #0x0, 0x10084a324 <_js_json_stringify_full+0x5a4>
10084b558:     	b	0x10084b228 <_js_json_stringify_full+0x14a8>
10084b55c:     	add	x9, x8, #0x60
10084b560:     	b	0x10084b7e8 <_js_json_stringify_full+0x1a68>
10084b564:     	bl	0x100b43bfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084b568:     	lsr	x1, x23, #20
10084b56c:     	ldr	x8, [x0, #0x10]
10084b570:     	ldrb	w9, [x8]
10084b574:     	cmp	w9, #0x2
10084b578:     	b.eq	0x10084a908 <_js_json_stringify_full+0xb88>
10084b57c:     	ldr	x9, [x8, #0x8]
10084b580:     	ldr	x10, [x8, #0x28]
10084b584:     	sub	x9, x1, x9
10084b588:     	cmp	x9, x10
10084b58c:     	b.hs	0x10084b5d0 <_js_json_stringify_full+0x1850>
10084b590:     	ldr	x10, [x8, #0x20]
10084b594:     	mov	w11, #0x28              ; =40
10084b598:     	madd	x9, x9, x11, x10
10084b59c:     	ldr	x10, [x9]
10084b5a0:     	ldr	x11, [x8, #0x10]
10084b5a4:     	cmp	x10, x11
10084b5a8:     	b.ne	0x10084b5dc <_js_json_stringify_full+0x185c>
10084b5ac:     	ldp	x10, x11, [x9, #0x8]
10084b5b0:     	cmp	x10, x23
10084b5b4:     	ccmp	x11, x23, #0x0, ls
10084b5b8:     	b.ls	0x10084b5dc <_js_json_stringify_full+0x185c>
10084b5bc:     	ldr	x10, [x8, #0x30]
10084b5c0:     	add	x10, x10, #0x1
10084b5c4:     	str	x10, [x8, #0x30]
10084b5c8:     	add	x8, x9, #0x21
10084b5cc:     	b	0x10084b7f8 <_js_json_stringify_full+0x1a78>
10084b5d0:     	ldr	x9, [x8, #0x58]
10084b5d4:     	add	x9, x9, #0x1
10084b5d8:     	str	x9, [x8, #0x58]
10084b5dc:     	ldr	x9, [x8, #0x38]
10084b5e0:     	add	x9, x9, #0x1
10084b5e4:     	str	x9, [x8, #0x38]
10084b5e8:     	mov	x0, x23
10084b5ec:     	bl	0x100520f48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
10084b5f0:     	and	w8, w0, #0xff
10084b5f4:     	cbz	w8, 0x10084b614 <_js_json_stringify_full+0x1894>
10084b5f8:     	ldurb	w8, [x23, #-0x8]
10084b5fc:     	ldurb	w9, [x23, #-0x7]
10084b600:     	mov	w10, #0x82              ; =130
10084b604:     	and	w9, w9, w10
10084b608:     	cmp	w9, #0x2
10084b60c:     	ccmp	w8, #0x1, #0x0, eq
10084b610:     	b.eq	0x10084b6a8 <_js_json_stringify_full+0x1928>
10084b614:     	mov	x0, x23
10084b618:     	bl	0x10057d5c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084b61c:     	mov	x24, x0
10084b620:     	cbz	x0, 0x10084b64c <_js_json_stringify_full+0x18cc>
10084b624:     	ldrb	w8, [x24]
10084b628:     	cmp	w8, #0x1
10084b62c:     	b.ne	0x10084b66c <_js_json_stringify_full+0x18ec>
10084b630:     	ldrsb	w8, [x24, #0x1]
10084b634:     	tbnz	w8, #0x1f, 0x10084b6d0 <_js_json_stringify_full+0x1950>
10084b638:     	mov	x0, x24
10084b63c:     	ldp	w9, w8, [x23]
10084b640:     	cmp	w9, w8
10084b644:     	b.hi	0x10084b754 <_js_json_stringify_full+0x19d4>
10084b648:     	b	0x10084b76c <_js_json_stringify_full+0x19ec>
10084b64c:     	mov	x0, x23
10084b650:     	bl	0x10058bdf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10084b654:     	tbnz	w0, #0x0, 0x10084b664 <_js_json_stringify_full+0x18e4>
10084b658:     	mov	x0, x23
10084b65c:     	bl	0x1002a68c8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
10084b660:     	tbz	w0, #0x0, 0x10084a9a8 <_js_json_stringify_full+0xc28>
10084b664:     	mov	x0, #0x0                ; =0
10084b668:     	b	0x10084b744 <_js_json_stringify_full+0x19c4>
10084b66c:     	mov	x0, x24
10084b670:     	cmp	w8, #0x1
10084b674:     	b.eq	0x10084b744 <_js_json_stringify_full+0x19c4>
10084b678:     	cmp	w8, #0x9
10084b67c:     	b.ne	0x10084a9a8 <_js_json_stringify_full+0xc28>
10084b680:     	ldr	w8, [x23, #0x4]
10084b684:     	mov	w9, #0x5841             ; =22593
10084b688:     	movk	w9, #0x4c5a, lsl #16
10084b68c:     	cmp	w8, w9
10084b690:     	b.ne	0x10084a9a8 <_js_json_stringify_full+0xc28>
10084b694:     	mov	x0, x23
10084b698:     	bl	0x1003787d0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
10084b69c:     	mov	x23, x0
10084b6a0:     	cbnz	x0, 0x10084b794 <_js_json_stringify_full+0x1a14>
10084b6a4:     	b	0x10084a9a8 <_js_json_stringify_full+0xc28>
10084b6a8:     	ldr	w8, [x23]
10084b6ac:     	mov	w9, #0xe100             ; =57600
10084b6b0:     	movk	w9, #0x5f5, lsl #16
10084b6b4:     	orr	w9, w9, #0x1
10084b6b8:     	cmp	w8, w9
10084b6bc:     	b.hs	0x10084b614 <_js_json_stringify_full+0x1894>
10084b6c0:     	ldr	w9, [x23, #0x4]
10084b6c4:     	cmp	w8, w9
10084b6c8:     	b.ls	0x10084b794 <_js_json_stringify_full+0x1a14>
10084b6cc:     	b	0x10084b614 <_js_json_stringify_full+0x1894>
10084b6d0:     	ldr	x23, [x24, #0x8]
10084b6d4:     	mov	x0, x23
10084b6d8:     	bl	0x10057d5c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084b6dc:     	cbz	x0, 0x10084a9a8 <_js_json_stringify_full+0xc28>
10084b6e0:     	ldrb	w8, [x0]
10084b6e4:     	cmp	w8, #0x1
10084b6e8:     	b.ne	0x10084a9a8 <_js_json_stringify_full+0xc28>
10084b6ec:     	ldrsb	w8, [x0, #0x1]
10084b6f0:     	tbz	w8, #0x1f, 0x10084b63c <_js_json_stringify_full+0x18bc>
10084b6f4:     	mov	w26, #0x1               ; =1
10084b6f8:     	ldr	x23, [x0, #0x8]
10084b6fc:     	mov	x0, x23
10084b700:     	bl	0x10057d5c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084b704:     	cbz	x0, 0x10084a9a8 <_js_json_stringify_full+0xc28>
10084b708:     	ldrb	w8, [x0]
10084b70c:     	cmp	w8, #0x1
10084b710:     	b.ne	0x10084a9a8 <_js_json_stringify_full+0xc28>
10084b714:     	cmp	w26, #0x3f
10084b718:     	b.hi	0x10084a9a8 <_js_json_stringify_full+0xc28>
10084b71c:     	add	w26, w26, #0x1
10084b720:     	ldrsb	w8, [x0, #0x1]
10084b724:     	tbnz	w8, #0x1f, 0x10084b6f8 <_js_json_stringify_full+0x1978>
10084b728:     	str	x23, [x24, #0x8]
10084b72c:     	ldrb	w8, [x24, #0x1]
10084b730:     	orr	w8, w8, #0x80
10084b734:     	strb	w8, [x24, #0x1]
10084b738:     	ldrb	w8, [x0]
10084b73c:     	cmp	w8, #0x1
10084b740:     	b.ne	0x10084b678 <_js_json_stringify_full+0x18f8>
10084b744:     	ldp	w9, w8, [x23]
10084b748:     	cmp	w9, w8
10084b74c:     	b.ls	0x10084b76c <_js_json_stringify_full+0x19ec>
10084b750:     	cbz	x24, 0x10084b77c <_js_json_stringify_full+0x19fc>
10084b754:     	ldr	w9, [x0, #0x4]
10084b758:     	ubfiz	x8, x8, #3, #32
10084b75c:     	add	x8, x8, #0x10
10084b760:     	cmp	x8, x9
10084b764:     	b.eq	0x10084b794 <_js_json_stringify_full+0x1a14>
10084b768:     	b	0x10084b77c <_js_json_stringify_full+0x19fc>
10084b76c:     	mov	w8, #0xe100             ; =57600
10084b770:     	movk	w8, #0x5f5, lsl #16
10084b774:     	cmp	w9, w8
10084b778:     	b.ls	0x10084b794 <_js_json_stringify_full+0x1a14>
10084b77c:     	mov	x0, x23
10084b780:     	bl	0x10058bdf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10084b784:     	tbnz	w0, #0x0, 0x10084b794 <_js_json_stringify_full+0x1a14>
10084b788:     	mov	x0, x23
10084b78c:     	bl	0x1002a68c8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
10084b790:     	tbz	w0, #0x0, 0x10084a9a8 <_js_json_stringify_full+0xc28>
10084b794:     	ldp	w8, w9, [x23]
10084b798:     	sub	w10, w9, #0x1
10084b79c:     	mov	w11, #0x270f            ; =9999
10084b7a0:     	cmp	w10, w11
10084b7a4:     	ccmp	w8, w9, #0x2, lo
10084b7a8:     	b.hi	0x10084a9a8 <_js_json_stringify_full+0xc28>
10084b7ac:     	and	x8, x21, #0xffffffffffff
10084b7b0:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
10084b7b4:     	cmp	x25, x9
10084b7b8:     	csel	x1, x8, x21, eq
10084b7bc:     	add	x0, sp, #0x30
10084b7c0:     	bl	0x1005025ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
10084b7c4:     	ldr	x25, [sp, #0x30]
10084b7c8:     	cmn	x25, #0x1
10084b7cc:     	cset	w24, eq
10084b7d0:     	cmp	x27, #0x1
10084b7d4:     	cset	w8, hi
10084b7d8:     	tst	w8, w24
10084b7dc:     	b.ne	0x10084a9c4 <_js_json_stringify_full+0xc44>
10084b7e0:     	b	0x10084aa34 <_js_json_stringify_full+0xcb4>
10084b7e4:     	add	x9, x8, #0x90
10084b7e8:     	ldr	x10, [x8, #0x30]
10084b7ec:     	add	x10, x10, #0x1
10084b7f0:     	str	x10, [x8, #0x30]
10084b7f4:     	add	x8, x9, #0x19
10084b7f8:     	ldrb	w8, [x8]
10084b7fc:     	cmp	w8, #0xff
10084b800:     	b.ne	0x10084b5f4 <_js_json_stringify_full+0x1874>
10084b804:     	b	0x10084b5e8 <_js_json_stringify_full+0x1868>
10084b808:     	mov	x0, x23
10084b80c:     	bl	0x100b22d84 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084b810:     	cbnz	x0, 0x10084ab50 <_js_json_stringify_full+0xdd0>
10084b814:     	b	0x10084b990 <_js_json_stringify_full+0x1c10>
10084b818:     	and	x0, x19, #0xffffffffffff
10084b81c:     	bl	0x1004fa8b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
10084b820:     	mov	w0, w0
10084b824:     	mov	x20, #0x7d7b            ; =32123
10084b828:     	movk	x20, #0x200, lsl #32
10084b82c:     	movk	x20, #0x7ff9, lsl #48
10084b830:     	tbz	w0, #0x0, 0x10084a358 <_js_json_stringify_full+0x5d8>
10084b834:     	b	0x10084b228 <_js_json_stringify_full+0x14a8>
10084b838:     	mov	x19, x0
10084b83c:     	mov	x0, x23
10084b840:     	bl	0x100b22d84 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084b844:     	mov	x23, x0
10084b848:     	mov	x0, x19
10084b84c:     	cbnz	x23, 0x10084b134 <_js_json_stringify_full+0x13b4>
10084b850:     	b	0x10084b930 <_js_json_stringify_full+0x1bb0>
10084b854:     	bl	0x100b22ee4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084b858:     	cbnz	x0, 0x10084aa78 <_js_json_stringify_full+0xcf8>
10084b85c:     	b	0x10084b990 <_js_json_stringify_full+0x1c10>
10084b860:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10084b864:     	add	x0, x0, #0x440
10084b868:     	bl	0x100b16f2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084b86c:     	cmp	w8, #0x1
10084b870:     	b.ne	0x10084b990 <_js_json_stringify_full+0x1c10>
10084b874:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084b878:     	add	x1, x1, #0x898
10084b87c:     	mov	x19, x0
10084b880:     	bl	0x100a24c5c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084b884:     	mov	x0, x19
10084b888:     	strb	wzr, [x19, #0x20]
10084b88c:     	ldr	x8, [x19]
10084b890:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10084b894:     	cmp	x8, x9
10084b898:     	b.lo	0x10084ac98 <_js_json_stringify_full+0xf18>
10084b89c:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084b8a0:     	add	x0, x0, #0xea8
10084b8a4:     	bl	0x100b16f5c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084b8a8:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084b8ac:     	add	x0, x0, #0xec0
10084b8b0:     	bl	0x100b16f2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084b8b4:     	and	x0, x19, #0xffffffffffff
10084b8b8:     	bl	0x1004f2500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
10084b8bc:     	mov	x20, x1
10084b8c0:     	tbz	w0, #0x0, 0x10084a358 <_js_json_stringify_full+0x5d8>
10084b8c4:     	b	0x10084b228 <_js_json_stringify_full+0x14a8>
10084b8c8:     	mov	x0, x23
10084b8cc:     	bl	0x100b22d84 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084b8d0:     	mov	x23, x0
10084b8d4:     	cbnz	x0, 0x10084afe4 <_js_json_stringify_full+0x1264>
10084b8d8:     	b	0x10084b930 <_js_json_stringify_full+0x1bb0>
10084b8dc:     	adrp	x0, 0x100efb000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
10084b8e0:     	add	x0, x0, #0xd70
10084b8e4:     	bl	0x100b16f5c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
10084b8e8:     	bl	0x100b50194 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
10084b8ec:     	cmp	w8, #0x2
10084b8f0:     	b.eq	0x10084b990 <_js_json_stringify_full+0x1c10>
10084b8f4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084b8f8:     	add	x1, x1, #0x898
10084b8fc:     	mov	x19, x0
10084b900:     	bl	0x100a24c5c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084b904:     	mov	x0, x19
10084b908:     	strb	wzr, [x19, #0x20]
10084b90c:     	ldr	x8, [x19]
10084b910:     	cbz	x8, 0x10084afd0 <_js_json_stringify_full+0x1250>
10084b914:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084b918:     	add	x0, x0, #0xe90
10084b91c:     	bl	0x100b16f2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084b920:     	mov	x0, x23
10084b924:     	bl	0x100b22d84 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
10084b928:     	mov	x23, x0
10084b92c:     	cbnz	x0, 0x10084af00 <_js_json_stringify_full+0x1180>
10084b930:     	cbz	x22, 0x10084b990 <_js_json_stringify_full+0x1c10>
10084b934:     	mov	x0, x19
10084b938:     	bl	0x100b63800 <_mi_free>
10084b93c:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084b940:     	add	x0, x0, #0xc18
10084b944:     	bl	0x100b5ce5c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084b948:     	adrp	x0, 0x100c46000 <_PERRY_EMPTY_STRING+0x234>
10084b94c:     	add	x0, x0, #0xcf0
10084b950:     	mov	w1, #0xf                ; =15
10084b954:     	bl	0x100b5015c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084b958:     	and	x0, x19, #0xffffffffffff
10084b95c:     	add	x2, sp, #0x80
10084b960:     	mov	x1, x22
10084b964:     	bl	0x1004f2d00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
10084b968:     	tbnz	w0, #0x0, 0x10084b394 <_js_json_stringify_full+0x1614>
10084b96c:     	mov	w20, #0x2               ; =2
10084b970:     	and	x0, x19, #0xffffffffffff
10084b974:     	mov	x1, x20
10084b978:     	bl	0x1004f1380 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
10084b97c:     	mov	x20, x1
10084b980:     	tbz	w0, #0x0, 0x10084a358 <_js_json_stringify_full+0x5d8>
10084b984:     	b	0x10084b228 <_js_json_stringify_full+0x14a8>
10084b988:     	cmp	w8, #0x2
10084b98c:     	b.ne	0x10084b9b8 <_js_json_stringify_full+0x1c38>
10084b990:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
10084b994:     	add	x0, x0, #0xc18
10084b998:     	bl	0x100b5ce5c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084b99c:     	adrp	x0, 0x100f33000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x148>
10084b9a0:     	add	x0, x0, #0x890
10084b9a4:     	bl	0x100b16ff0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
10084b9a8:     	adrp	x0, 0x100c46000 <_PERRY_EMPTY_STRING+0x234>
10084b9ac:     	add	x0, x0, #0xa27
10084b9b0:     	mov	w1, #0xb                ; =11
10084b9b4:     	bl	0x100b5015c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
10084b9b8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
10084b9bc:     	add	x1, x1, #0x898
10084b9c0:     	mov	x19, x0
10084b9c4:     	bl	0x100a24c5c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084b9c8:     	mov	x0, x19
10084b9cc:     	strb	wzr, [x19, #0x20]
10084b9d0:     	ldr	x8, [x19]
10084b9d4:     	cbz	x8, 0x10084aeec <_js_json_stringify_full+0x116c>
10084b9d8:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10084b9dc:     	add	x0, x0, #0xe78
10084b9e0:     	bl	0x100b16f2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084b9e4:     	mov	w0, #0x1                ; =1
10084b9e8:     	mov	x1, x24
10084b9ec:     	bl	0x100b16b80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084b9f0:     	mov	w0, #0x1                ; =1
10084b9f4:     	mov	x1, x22
10084b9f8:     	bl	0x100b16b80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084b9fc:     	adrp	x2, 0x100efc000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
10084ba00:     	add	x2, x2, #0x3c8
10084ba04:     	mov	w0, #0x5                ; =5
10084ba08:     	mov	w1, #0x5                ; =5
10084ba0c:     	bl	0x100b1708c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
