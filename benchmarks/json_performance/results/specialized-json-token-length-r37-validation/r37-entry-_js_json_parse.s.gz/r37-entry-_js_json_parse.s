
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/specialized-json-token-length-r37/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100848914 <_js_json_parse>:
100848914:     	stp	x29, x30, [sp, #-0x10]!
100848918:     	mov	x29, sp
10084891c:     	cbz	x0, 0x100848974 <_js_json_parse+0x60>
100848920:     	ldr	w1, [x0, #0x4]
100848924:     	cmp	w1, #0x2
100848928:     	b.eq	0x100848938 <_js_json_parse+0x24>
10084892c:     	cbz	w1, 0x100848974 <_js_json_parse+0x60>
100848930:     	ldrb	w8, [x0, #0x14]
100848934:     	b	0x100848958 <_js_json_parse+0x44>
100848938:     	ldrb	w8, [x0, #0x14]
10084893c:     	cmp	w8, #0x7b
100848940:     	b.ne	0x100848958 <_js_json_parse+0x44>
100848944:     	ldrb	w8, [x0, #0x15]
100848948:     	cmp	w8, #0x7d
10084894c:     	b.ne	0x100848964 <_js_json_parse+0x50>
100848950:     	ldp	x29, x30, [sp], #0x10
100848954:     	b	0x1004ef280 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100848958:     	orr	w8, w8, #0x20
10084895c:     	cmp	w8, #0x7b
100848960:     	b.ne	0x10084896c <_js_json_parse+0x58>
100848964:     	ldp	x29, x30, [sp], #0x10
100848968:     	b	0x1005088c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
10084896c:     	ldp	x29, x30, [sp], #0x10
100848970:     	b	0x10050b00c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100848974:     	adrp	x0, 0x100c79000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x669c>
100848978:     	add	x0, x0, #0xe41
10084897c:     	mov	w1, #0x1c               ; =28
100848980:     	bl	0x10050b440 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
