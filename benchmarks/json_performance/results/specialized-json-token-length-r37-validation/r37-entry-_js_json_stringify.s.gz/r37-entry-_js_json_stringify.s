
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/specialized-json-token-length-r37/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010084962c <_js_json_stringify>:
10084962c:     	sub	sp, sp, #0x80
100849630:     	stp	d9, d8, [sp, #0x20]
100849634:     	stp	x26, x25, [sp, #0x30]
100849638:     	stp	x24, x23, [sp, #0x40]
10084963c:     	stp	x22, x21, [sp, #0x50]
100849640:     	stp	x20, x19, [sp, #0x60]
100849644:     	stp	x29, x30, [sp, #0x70]
100849648:     	add	x29, sp, #0x70
10084964c:     	mov	x21, x0
100849650:     	mov.16b	v8, v0
100849654:     	fmov	x19, d8
100849658:     	and	x20, x19, #0xffff000000000000
10084965c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100849660:     	cmp	x20, x8
100849664:     	b.ne	0x10084968c <_js_json_stringify+0x60>
100849668:     	and	x0, x19, #0xffffffffffff
10084966c:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
100849670:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100849674:     	movk	x9, #0xffef, lsl #16
100849678:     	cmp	x8, x9
10084967c:     	b.hi	0x10084968c <_js_json_stringify+0x60>
100849680:     	ldr	w8, [x0, #0x4]
100849684:     	cmp	w8, #0x40
100849688:     	b.hs	0x1008496fc <_js_json_stringify+0xd0>
10084968c:     	mov.16b	v0, v8
100849690:     	bl	0x1004f08bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100849694:     	tbz	w0, #0x0, 0x1008496a0 <_js_json_stringify+0x74>
100849698:     	mov	x23, x1
10084969c:     	b	0x100849c10 <_js_json_stringify+0x5e4>
1008496a0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008496a4:     	cmp	x20, x8
1008496a8:     	b.ne	0x100849710 <_js_json_stringify+0xe4>
1008496ac:     	ands	x19, x19, #0xffffffffffff
1008496b0:     	b.eq	0x100849710 <_js_json_stringify+0xe4>
1008496b4:     	mov	x0, x19
1008496b8:     	bl	0x100511d38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008496bc:     	cbz	w0, 0x100849710 <_js_json_stringify+0xe4>
1008496c0:     	ldurb	w8, [x19, #-0x8]
1008496c4:     	cmp	w8, #0x9
1008496c8:     	b.ne	0x100849710 <_js_json_stringify+0xe4>
1008496cc:     	ldr	w8, [x19, #0x4]
1008496d0:     	mov	w9, #0x5841             ; =22593
1008496d4:     	movk	w9, #0x4c5a, lsl #16
1008496d8:     	cmp	w8, w9
1008496dc:     	b.ne	0x100849710 <_js_json_stringify+0xe4>
1008496e0:     	mov	x0, x19
1008496e4:     	bl	0x10068b9a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1008496e8:     	cbz	x0, 0x100849710 <_js_json_stringify+0xe4>
1008496ec:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008496f0:     	bfxil	x8, x0, #0, #48
1008496f4:     	fmov	d8, x8
1008496f8:     	b	0x100849710 <_js_json_stringify+0xe4>
1008496fc:     	bl	0x1004f57e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100849700:     	tbnz	w0, #0x0, 0x100849698 <_js_json_stringify+0x6c>
100849704:     	mov.16b	v0, v8
100849708:     	bl	0x1004f08bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084970c:     	tbnz	w0, #0x0, 0x100849698 <_js_json_stringify+0x6c>
100849710:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849714:     	add	x0, x0, #0xd78
100849718:     	ldr	x8, [x0]
10084971c:     	blr	x8
100849720:     	mov	x19, x0
100849724:     	ldr	w26, [x0]
100849728:     	add	w8, w26, #0x1
10084972c:     	str	w8, [x0]
100849730:     	cbz	w26, 0x1008497a0 <_js_json_stringify+0x174>
100849734:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849738:     	add	x0, x0, #0xd00
10084973c:     	ldr	x8, [x0]
100849740:     	blr	x8
100849744:     	ldrb	w8, [x0, #0x20]
100849748:     	cmp	w8, #0x1
10084974c:     	b.ne	0x100849d04 <_js_json_stringify+0x6d8>
100849750:     	ldr	x8, [x0]
100849754:     	cbnz	x8, 0x100849d10 <_js_json_stringify+0x6e4>
100849758:     	mov	x8, #-0x1               ; =-1
10084975c:     	str	x8, [x0]
100849760:     	ldr	x20, [x0, #0x18]
100849764:     	ldr	x8, [x0, #0x8]
100849768:     	cmp	x20, x8
10084976c:     	b.eq	0x100849c34 <_js_json_stringify+0x608>
100849770:     	ldr	x8, [x0, #0x10]
100849774:     	mov	w9, #0x18               ; =24
100849778:     	madd	x8, x20, x9, x8
10084977c:     	mov	w9, #0x8                ; =8
100849780:     	stp	xzr, x9, [x8]
100849784:     	str	xzr, [x8, #0x10]
100849788:     	add	x8, x20, #0x1
10084978c:     	str	x8, [x0, #0x18]
100849790:     	ldr	x8, [x0]
100849794:     	add	x8, x8, #0x1
100849798:     	str	x8, [x0]
10084979c:     	b	0x10084982c <_js_json_stringify+0x200>
1008497a0:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
1008497a4:     	add	x0, x0, #0xdc0
1008497a8:     	ldr	x8, [x0]
1008497ac:     	blr	x8
1008497b0:     	strb	wzr, [x0]
1008497b4:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
1008497b8:     	add	x0, x0, #0xdf0
1008497bc:     	ldr	x8, [x0]
1008497c0:     	blr	x8
1008497c4:     	strb	wzr, [x0]
1008497c8:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
1008497cc:     	ldr	w20, [x8, #0x5a8]
1008497d0:     	cmp	w20, #0x300
1008497d4:     	b.hs	0x100849c90 <_js_json_stringify+0x664>
1008497d8:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
1008497dc:     	ldr	x8, [x8, #0x48]
1008497e0:     	cmn	x8, #0x1
1008497e4:     	b.eq	0x100849c80 <_js_json_stringify+0x654>
1008497e8:     	mrs	x9, TPIDRRO_EL0
1008497ec:     	and	x9, x9, #0xfffffffffffffff8
1008497f0:     	ldr	x0, [x9, x8, lsl #3]
1008497f4:     	cbz	x0, 0x100849c80 <_js_json_stringify+0x654>
1008497f8:     	add	x8, x0, x20, lsl #3
1008497fc:     	ldr	x0, [x8, #0x1e8]
100849800:     	cbz	x0, 0x100849c90 <_js_json_stringify+0x664>
100849804:     	str	xzr, [x0]
100849808:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084980c:     	add	x0, x0, #0xd90
100849810:     	ldr	x8, [x0]
100849814:     	blr	x8
100849818:     	ldrb	w8, [x0, #0x20]
10084981c:     	cbnz	w8, 0x100849d1c <_js_json_stringify+0x6f0>
100849820:     	ldr	x8, [x0]
100849824:     	cbnz	x8, 0x100849d44 <_js_json_stringify+0x718>
100849828:     	str	xzr, [x0, #0x18]
10084982c:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
100849830:     	add	x0, x0, #0xd30
100849834:     	ldr	x8, [x0]
100849838:     	blr	x8
10084983c:     	mov	x20, x0
100849840:     	ldrb	w8, [x0, #0x18]
100849844:     	cmp	w8, #0x1
100849848:     	b.ne	0x100849ca0 <_js_json_stringify+0x674>
10084984c:     	ldr	x8, [x0]
100849850:     	mov	x9, #-0x1               ; =-1
100849854:     	str	x9, [x0]
100849858:     	cmn	x8, #0x2
10084985c:     	b.eq	0x100849d50 <_js_json_stringify+0x724>
100849860:     	cmn	x8, #0x1
100849864:     	b.eq	0x100849878 <_js_json_stringify+0x24c>
100849868:     	add	x9, sp, #0x8
10084986c:     	ldur	q0, [x0, #0x8]
100849870:     	stur	q0, [x9, #0x8]
100849874:     	b	0x100849884 <_js_json_stringify+0x258>
100849878:     	mov	x8, #0x0                ; =0
10084987c:     	mov	w9, #0x1                ; =1
100849880:     	stp	x9, xzr, [sp, #0x10]
100849884:     	str	x8, [sp, #0x8]
100849888:     	adrp	x0, 0x100f8b000 <_theap_main+0x1f80>
10084988c:     	add	x0, x0, #0xd18
100849890:     	ldr	x8, [x0]
100849894:     	blr	x8
100849898:     	ldrb	w8, [x0, #0x20]
10084989c:     	cbnz	w8, 0x100849cd0 <_js_json_stringify+0x6a4>
1008498a0:     	ldr	x8, [x0]
1008498a4:     	cbnz	x8, 0x100849cf8 <_js_json_stringify+0x6cc>
1008498a8:     	str	xzr, [x0, #0x18]
1008498ac:     	add	x1, sp, #0x8
1008498b0:     	mov.16b	v0, v8
1008498b4:     	mov	x0, x21
1008498b8:     	bl	0x10050c184 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
1008498bc:     	ldp	x21, x22, [sp, #0x10]
1008498c0:     	cmp	w22, #0x80, lsl #12     ; =0x80000
1008498c4:     	b.hs	0x100849984 <_js_json_stringify+0x358>
1008498c8:     	cmp	x22, #0x40
1008498cc:     	b.hs	0x100849a48 <_js_json_stringify+0x41c>
1008498d0:     	ands	x9, x22, #0x38
1008498d4:     	b.eq	0x1008498f8 <_js_json_stringify+0x2cc>
1008498d8:     	and	x8, x22, #0x38
1008498dc:     	neg	x8, x8
1008498e0:     	mov	x10, x21
1008498e4:     	ldr	x11, [x10], #0x8
1008498e8:     	tst	x11, #0x8080808080808080
1008498ec:     	b.ne	0x10084996c <_js_json_stringify+0x340>
1008498f0:     	adds	x8, x8, #0x8
1008498f4:     	b.ne	0x1008498e4 <_js_json_stringify+0x2b8>
1008498f8:     	and	x8, x22, #0x7
1008498fc:     	cbz	x8, 0x100849acc <_js_json_stringify+0x4a0>
100849900:     	add	x9, x21, x9
100849904:     	ldrsb	w10, [x9]
100849908:     	tbnz	w10, #0x1f, 0x10084996c <_js_json_stringify+0x340>
10084990c:     	cmp	x8, #0x1
100849910:     	b.eq	0x100849acc <_js_json_stringify+0x4a0>
100849914:     	ldrsb	w10, [x9, #0x1]
100849918:     	tbnz	w10, #0x1f, 0x10084996c <_js_json_stringify+0x340>
10084991c:     	cmp	x8, #0x2
100849920:     	b.eq	0x100849acc <_js_json_stringify+0x4a0>
100849924:     	ldrsb	w10, [x9, #0x2]
100849928:     	tbnz	w10, #0x1f, 0x10084996c <_js_json_stringify+0x340>
10084992c:     	cmp	x8, #0x3
100849930:     	b.eq	0x100849acc <_js_json_stringify+0x4a0>
100849934:     	ldrsb	w10, [x9, #0x3]
100849938:     	tbnz	w10, #0x1f, 0x10084996c <_js_json_stringify+0x340>
10084993c:     	cmp	x8, #0x4
100849940:     	b.eq	0x100849acc <_js_json_stringify+0x4a0>
100849944:     	ldrsb	w10, [x9, #0x4]
100849948:     	tbnz	w10, #0x1f, 0x10084996c <_js_json_stringify+0x340>
10084994c:     	cmp	x8, #0x5
100849950:     	b.eq	0x100849acc <_js_json_stringify+0x4a0>
100849954:     	ldrsb	w10, [x9, #0x5]
100849958:     	tbnz	w10, #0x1f, 0x10084996c <_js_json_stringify+0x340>
10084995c:     	cmp	x8, #0x6
100849960:     	b.eq	0x100849acc <_js_json_stringify+0x4a0>
100849964:     	ldrsb	w8, [x9, #0x6]
100849968:     	tbz	w8, #0x1f, 0x100849acc <_js_json_stringify+0x4a0>
10084996c:     	mov	x0, x21
100849970:     	mov	x1, x22
100849974:     	mov	x2, x22
100849978:     	bl	0x1008e1000 <_js_string_from_bytes_with_capacity>
10084997c:     	mov	x23, x0
100849980:     	b	0x100849bc8 <_js_json_stringify+0x59c>
100849984:     	and	x8, x22, #0x7fffffffffffffc0
100849988:     	add	x8, x21, x8
10084998c:     	mov	x9, x21
100849990:     	ldp	q0, q1, [x9]
100849994:     	ldp	q2, q3, [x9, #0x20]
100849998:     	orr.16b	v0, v1, v0
10084999c:     	orr.16b	v1, v2, v3
1008499a0:     	orr.16b	v0, v0, v1
1008499a4:     	umaxv.16b	b0, v0
1008499a8:     	fmov	w10, s0
1008499ac:     	tbnz	w10, #0x7, 0x100849a0c <_js_json_stringify+0x3e0>
1008499b0:     	add	x9, x9, #0x40
1008499b4:     	cmp	x9, x8
1008499b8:     	b.ne	0x100849990 <_js_json_stringify+0x364>
1008499bc:     	ands	x9, x22, #0x30
1008499c0:     	b.eq	0x1008499e4 <_js_json_stringify+0x3b8>
1008499c4:     	mov	x10, x9
1008499c8:     	mov	x11, x8
1008499cc:     	ldr	q0, [x11], #0x10
1008499d0:     	umaxv.16b	b0, v0
1008499d4:     	fmov	w12, s0
1008499d8:     	tbnz	w12, #0x7, 0x100849a0c <_js_json_stringify+0x3e0>
1008499dc:     	subs	x10, x10, #0x10
1008499e0:     	b.ne	0x1008499cc <_js_json_stringify+0x3a0>
1008499e4:     	and	x10, x22, #0xf
1008499e8:     	cbz	x10, 0x100849a04 <_js_json_stringify+0x3d8>
1008499ec:     	add	x8, x8, x9
1008499f0:     	ldrsb	w9, [x8]
1008499f4:     	tbnz	w9, #0x1f, 0x100849a0c <_js_json_stringify+0x3e0>
1008499f8:     	add	x8, x8, #0x1
1008499fc:     	subs	x10, x10, #0x1
100849a00:     	b.ne	0x1008499f0 <_js_json_stringify+0x3c4>
100849a04:     	mov	w24, w22
100849a08:     	b	0x100849a40 <_js_json_stringify+0x414>
100849a0c:     	mov	w24, w22
100849a10:     	cbz	x24, 0x100849a40 <_js_json_stringify+0x414>
100849a14:     	mov	x8, x21
100849a18:     	ands	x9, x22, #0x3
100849a1c:     	b.eq	0x100849a38 <_js_json_stringify+0x40c>
100849a20:     	mov	x8, x21
100849a24:     	ldrsb	w10, [x8]
100849a28:     	tbnz	w10, #0x1f, 0x100849b30 <_js_json_stringify+0x504>
100849a2c:     	add	x8, x8, #0x1
100849a30:     	subs	x9, x9, #0x1
100849a34:     	b.ne	0x100849a24 <_js_json_stringify+0x3f8>
100849a38:     	cmp	x24, #0x4
100849a3c:     	b.hs	0x100849afc <_js_json_stringify+0x4d0>
100849a40:     	mov	x25, x22
100849a44:     	b	0x100849b40 <_js_json_stringify+0x514>
100849a48:     	and	x8, x22, #0x7fffffffffffffc0
100849a4c:     	and	x8, x8, #0xffffffff0007ffff
100849a50:     	add	x8, x21, x8
100849a54:     	mov	x9, x21
100849a58:     	ldp	q0, q1, [x9]
100849a5c:     	ldp	q2, q3, [x9, #0x20]
100849a60:     	orr.16b	v0, v1, v0
100849a64:     	orr.16b	v1, v2, v3
100849a68:     	orr.16b	v0, v0, v1
100849a6c:     	umaxv.16b	b0, v0
100849a70:     	fmov	w10, s0
100849a74:     	tbnz	w10, #0x7, 0x10084996c <_js_json_stringify+0x340>
100849a78:     	add	x9, x9, #0x40
100849a7c:     	cmp	x9, x8
100849a80:     	b.ne	0x100849a58 <_js_json_stringify+0x42c>
100849a84:     	ands	x9, x22, #0x30
100849a88:     	b.eq	0x100849aac <_js_json_stringify+0x480>
100849a8c:     	mov	x10, x9
100849a90:     	mov	x11, x8
100849a94:     	ldr	q0, [x11], #0x10
100849a98:     	umaxv.16b	b0, v0
100849a9c:     	fmov	w12, s0
100849aa0:     	tbnz	w12, #0x7, 0x10084996c <_js_json_stringify+0x340>
100849aa4:     	subs	x10, x10, #0x10
100849aa8:     	b.ne	0x100849a94 <_js_json_stringify+0x468>
100849aac:     	and	x10, x22, #0xf
100849ab0:     	cbz	x10, 0x100849acc <_js_json_stringify+0x4a0>
100849ab4:     	add	x8, x8, x9
100849ab8:     	ldrsb	w9, [x8]
100849abc:     	tbnz	w9, #0x1f, 0x10084996c <_js_json_stringify+0x340>
100849ac0:     	add	x8, x8, #0x1
100849ac4:     	subs	x10, x10, #0x1
100849ac8:     	b.ne	0x100849ab8 <_js_json_stringify+0x48c>
100849acc:     	mov	x0, x22
100849ad0:     	bl	0x10034db2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100849ad4:     	mov	x23, x0
100849ad8:     	stp	w22, w22, [x0]
100849adc:     	stp	wzr, wzr, [x0, #0xc]
100849ae0:     	str	w22, [x0, #0x8]
100849ae4:     	cbz	w22, 0x100849bc8 <_js_json_stringify+0x59c>
100849ae8:     	and	x2, x22, #0x7ffff
100849aec:     	mov	x0, x1
100849af0:     	mov	x1, x21
100849af4:     	bl	0x100b666ac <_writev+0x100b666ac>
100849af8:     	b	0x100849bc8 <_js_json_stringify+0x59c>
100849afc:     	add	x9, x21, x24
100849b00:     	ldrsb	w10, [x8]
100849b04:     	tbnz	w10, #0x1f, 0x100849b30 <_js_json_stringify+0x504>
100849b08:     	ldrsb	w10, [x8, #0x1]
100849b0c:     	tbnz	w10, #0x1f, 0x100849b30 <_js_json_stringify+0x504>
100849b10:     	ldrsb	w10, [x8, #0x2]
100849b14:     	tbnz	w10, #0x1f, 0x100849b30 <_js_json_stringify+0x504>
100849b18:     	ldrsb	w10, [x8, #0x3]
100849b1c:     	tbnz	w10, #0x1f, 0x100849b30 <_js_json_stringify+0x504>
100849b20:     	add	x8, x8, #0x4
100849b24:     	cmp	x8, x9
100849b28:     	b.ne	0x100849b00 <_js_json_stringify+0x4d4>
100849b2c:     	b	0x100849a40 <_js_json_stringify+0x414>
100849b30:     	mov	w1, w22
100849b34:     	mov	x0, x21
100849b38:     	bl	0x1005ed520 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
100849b3c:     	mov	x25, x0
100849b40:     	bl	0x1004f2a40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100849b44:     	add	x0, x24, #0x14
100849b48:     	mov	w1, #0x3                ; =3
100849b4c:     	bl	0x10045ad00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
100849b50:     	mov	x23, x0
100849b54:     	stp	w25, w22, [x0]
100849b58:     	stp	wzr, wzr, [x0, #0xc]
100849b5c:     	str	w22, [x0, #0x8]
100849b60:     	add	x0, x0, #0x14
100849b64:     	mov	x1, x21
100849b68:     	mov	x2, x24
100849b6c:     	bl	0x100b666ac <_writev+0x100b666ac>
100849b70:     	adrp	x8, 0x100f86000 <__MergedGlobals.1917+0xc8>
100849b74:     	ldr	w21, [x8, #0x590]
100849b78:     	cmp	w21, #0x300
100849b7c:     	b.hs	0x100849c58 <_js_json_stringify+0x62c>
100849b80:     	adrp	x8, 0x100f84000 <_perry_global_worker_ts__1>
100849b84:     	ldr	x8, [x8, #0x48]
100849b88:     	cmn	x8, #0x1
100849b8c:     	b.eq	0x100849c48 <_js_json_stringify+0x61c>
100849b90:     	mrs	x9, TPIDRRO_EL0
100849b94:     	and	x9, x9, #0xfffffffffffffff8
100849b98:     	ldr	x0, [x9, x8, lsl #3]
100849b9c:     	cbz	x0, 0x100849c48 <_js_json_stringify+0x61c>
100849ba0:     	add	x8, x0, x21, lsl #3
100849ba4:     	ldr	x0, [x8, #0x1e8]
100849ba8:     	cbz	x0, 0x100849c58 <_js_json_stringify+0x62c>
100849bac:     	ldr	x8, [x0]
100849bb0:     	adds	x8, x8, x24
100849bb4:     	csinv	x8, x8, xzr, lo
100849bb8:     	str	x8, [x0]
100849bbc:     	lsr	x8, x8, #25
100849bc0:     	cbz	x8, 0x100849bc8 <_js_json_stringify+0x59c>
100849bc4:     	bl	0x100461c34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100849bc8:     	ldp	x22, x21, [sp, #0x8]
100849bcc:     	ldrb	w8, [x20, #0x18]
100849bd0:     	cmp	w8, #0x1
100849bd4:     	b.ne	0x100849cb0 <_js_json_stringify+0x684>
100849bd8:     	ldp	x8, x0, [x20]
100849bdc:     	stp	x22, x21, [x20]
100849be0:     	str	xzr, [x20, #0x10]
100849be4:     	sub	x8, x8, #0x1
100849be8:     	cmn	x8, #0x2
100849bec:     	b.hs	0x100849bf4 <_js_json_stringify+0x5c8>
100849bf0:     	bl	0x100b63800 <_mi_free>
100849bf4:     	cbz	w26, 0x100849c00 <_js_json_stringify+0x5d4>
100849bf8:     	bl	0x10032aa68 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100849bfc:     	b	0x100849c04 <_js_json_stringify+0x5d8>
100849c00:     	bl	0x10032a898 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100849c04:     	ldr	w8, [x19]
100849c08:     	sub	w8, w8, #0x1
100849c0c:     	str	w8, [x19]
100849c10:     	mov	x0, x23
100849c14:     	ldp	x29, x30, [sp, #0x70]
100849c18:     	ldp	x20, x19, [sp, #0x60]
100849c1c:     	ldp	x22, x21, [sp, #0x50]
100849c20:     	ldp	x24, x23, [sp, #0x40]
100849c24:     	ldp	x26, x25, [sp, #0x30]
100849c28:     	ldp	d9, d8, [sp, #0x20]
100849c2c:     	add	sp, sp, #0x80
100849c30:     	ret
100849c34:     	mov	x22, x0
100849c38:     	add	x0, x0, #0x8
100849c3c:     	bl	0x100b40550 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100849c40:     	mov	x0, x22
100849c44:     	b	0x100849770 <_js_json_stringify+0x144>
100849c48:     	bl	0x100b43bfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100849c4c:     	add	x8, x0, x21, lsl #3
100849c50:     	ldr	x0, [x8, #0x1e8]
100849c54:     	cbnz	x0, 0x100849bac <_js_json_stringify+0x580>
100849c58:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100849c5c:     	add	x0, x0, #0x78
100849c60:     	bl	0x100b4141c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100849c64:     	ldr	x8, [x0]
100849c68:     	adds	x8, x8, x24
100849c6c:     	csinv	x8, x8, xzr, lo
100849c70:     	str	x8, [x0]
100849c74:     	lsr	x8, x8, #25
100849c78:     	cbnz	x8, 0x100849bc4 <_js_json_stringify+0x598>
100849c7c:     	b	0x100849bc8 <_js_json_stringify+0x59c>
100849c80:     	bl	0x100b43bfc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100849c84:     	add	x8, x0, x20, lsl #3
100849c88:     	ldr	x0, [x8, #0x1e8]
100849c8c:     	cbnz	x0, 0x100849804 <_js_json_stringify+0x1d8>
100849c90:     	adrp	x0, 0x100f14000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100849c94:     	add	x0, x0, #0x138
100849c98:     	bl	0x100b4141c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100849c9c:     	b	0x100849804 <_js_json_stringify+0x1d8>
100849ca0:     	mov	x0, x20
100849ca4:     	bl	0x100b22d84 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100849ca8:     	cbnz	x0, 0x10084984c <_js_json_stringify+0x220>
100849cac:     	b	0x100849d50 <_js_json_stringify+0x724>
100849cb0:     	mov	x0, x20
100849cb4:     	bl	0x100b22d84 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100849cb8:     	mov	x20, x0
100849cbc:     	cbnz	x0, 0x100849bd8 <_js_json_stringify+0x5ac>
100849cc0:     	cbz	x22, 0x100849d50 <_js_json_stringify+0x724>
100849cc4:     	mov	x0, x21
100849cc8:     	bl	0x100b63800 <_mi_free>
100849ccc:     	b	0x100849d50 <_js_json_stringify+0x724>
100849cd0:     	cmp	w8, #0x2
100849cd4:     	b.eq	0x100849d50 <_js_json_stringify+0x724>
100849cd8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
100849cdc:     	add	x1, x1, #0xef8
100849ce0:     	mov	x22, x0
100849ce4:     	bl	0x100a24c5c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100849ce8:     	mov	x0, x22
100849cec:     	strb	wzr, [x22, #0x20]
100849cf0:     	ldr	x8, [x22]
100849cf4:     	cbz	x8, 0x1008498a8 <_js_json_stringify+0x27c>
100849cf8:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100849cfc:     	add	x0, x0, #0xdb8
100849d00:     	bl	0x100b16f2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100849d04:     	bl	0x100b22ee4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100849d08:     	cbnz	x0, 0x100849750 <_js_json_stringify+0x124>
100849d0c:     	b	0x100849d50 <_js_json_stringify+0x724>
100849d10:     	adrp	x0, 0x100efe000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100849d14:     	add	x0, x0, #0x440
100849d18:     	bl	0x100b16f2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100849d1c:     	cmp	w8, #0x1
100849d20:     	b.ne	0x100849d50 <_js_json_stringify+0x724>
100849d24:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_9reactions16OverflowReactionEEKj1_EEB1a_+0xe4>
100849d28:     	add	x1, x1, #0x898
100849d2c:     	mov	x20, x0
100849d30:     	bl	0x100a24c5c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100849d34:     	mov	x0, x20
100849d38:     	strb	wzr, [x20, #0x20]
100849d3c:     	ldr	x8, [x20]
100849d40:     	cbz	x8, 0x100849828 <_js_json_stringify+0x1fc>
100849d44:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100849d48:     	add	x0, x0, #0xd88
100849d4c:     	bl	0x100b16f2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100849d50:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100849d54:     	add	x0, x0, #0xc18
100849d58:     	bl	0x100b5ce5c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
