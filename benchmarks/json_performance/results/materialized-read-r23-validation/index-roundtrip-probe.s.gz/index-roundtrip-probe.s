	.build_version macos, 11, 0
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	__RINvNtCs8BpVhDwHqJW_3std2rt10lang_startuECsbukuFQpaN3d_21index_roundtrip_probe
	.globl	__RINvNtCs8BpVhDwHqJW_3std2rt10lang_startuECsbukuFQpaN3d_21index_roundtrip_probe
	.p2align	2
__RINvNtCs8BpVhDwHqJW_3std2rt10lang_startuECsbukuFQpaN3d_21index_roundtrip_probe:
	.cfi_startproc
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x4, x3
	mov	x3, x2
	mov	x2, x1
	str	x0, [sp, #8]
Lloh0:
	adrp	x1, l_anon.cc796cd23bdcfc0714215e28034588ed.0@PAGE
Lloh1:
	add	x1, x1, l_anon.cc796cd23bdcfc0714215e28034588ed.0@PAGEOFF
	add	x0, sp, #8
	bl	__RNvNtCs8BpVhDwHqJW_3std2rt19lang_start_internal
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.loh AdrpAdd	Lloh0, Lloh1
	.cfi_endproc

	.p2align	2
__RINvNtCsjgY6bXVaRmE_4core9panicking13assert_failedINtNtB4_6option6OptionmEBM_ECsbukuFQpaN3d_21index_roundtrip_probe:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x7, x4
	mov	x6, x3
	mov	x5, x2
	stp	x0, x1, [sp]
Lloh2:
	adrp	x2, l_anon.cc796cd23bdcfc0714215e28034588ed.1@PAGE
Lloh3:
	add	x2, x2, l_anon.cc796cd23bdcfc0714215e28034588ed.1@PAGEOFF
	mov	x1, sp
	add	x3, sp, #8
	mov	w0, #0
	mov	x4, x2
	bl	__RNvNtCsjgY6bXVaRmE_4core9panicking19assert_failed_inner
	.loh AdrpAdd	Lloh2, Lloh3
	.cfi_endproc

	.p2align	2
__RINvNtNtCs8BpVhDwHqJW_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsbukuFQpaN3d_21index_roundtrip_probe:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	blr	x0
	; InlineAsm Start
	; InlineAsm End
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNCINvNtCs8BpVhDwHqJW_3std2rt10lang_startuE0CsbukuFQpaN3d_21index_roundtrip_probe:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0]
	bl	__RINvNtNtCs8BpVhDwHqJW_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsbukuFQpaN3d_21index_roundtrip_probe
	mov	w0, #0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.p2align	2
__RNSNvYNCINvNtCs8BpVhDwHqJW_3std2rt10lang_startuE0INtNtNtCsjgY6bXVaRmE_4core3ops8function6FnOnceuE9call_once6vtableCsbukuFQpaN3d_21index_roundtrip_probe:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	ldr	x0, [x0]
	bl	__RINvNtNtCs8BpVhDwHqJW_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECsbukuFQpaN3d_21index_roundtrip_probe
	mov	w0, #0
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
	.cfi_endproc

	.section	__TEXT,__literal16,16byte_literals
	.p2align	4, 0x0
lCPI5_0:
	.quad	0
	.quad	15
lCPI5_1:
	.quad	0x0000000000000000
	.quad	0x8000000000000000
lCPI5_2:
	.quad	0x3ff0000000000000
	.quad	0xbff0000000000000
lCPI5_3:
	.quad	0x3fe0000000000000
	.quad	0xbfe0000000000000
lCPI5_4:
	.quad	0x0010000000000000
	.quad	0x7ff0000000000000
lCPI5_5:
	.quad	0xfff0000000000000
	.quad	0x7ff8000000000000
lCPI5_6:
	.quad	0x41dfffffffc00000
	.quad	0x41e0000000000000
lCPI5_7:
	.quad	0x41efffffffc00000
	.quad	0x41efffffffe00000
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	__RNvCsbukuFQpaN3d_21index_roundtrip_probe4main
	.globl	__RNvCsbukuFQpaN3d_21index_roundtrip_probe4main
	.p2align	2
__RNvCsbukuFQpaN3d_21index_roundtrip_probe4main:
	.cfi_startproc
	sub	sp, sp, #336
	.cfi_def_cfa_offset 336
	stp	d9, d8, [sp, #224]
	stp	x28, x27, [sp, #240]
	stp	x26, x25, [sp, #256]
	stp	x24, x23, [sp, #272]
	stp	x22, x21, [sp, #288]
	stp	x20, x19, [sp, #304]
	stp	x29, x30, [sp, #320]
	add	x29, sp, #320
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_offset w19, -24
	.cfi_offset w20, -32
	.cfi_offset w21, -40
	.cfi_offset w22, -48
	.cfi_offset w23, -56
	.cfi_offset w24, -64
	.cfi_offset w25, -72
	.cfi_offset w26, -80
	.cfi_offset w27, -88
	.cfi_offset w28, -96
	.cfi_offset b8, -104
	.cfi_offset b9, -112
	.cfi_remember_state
	mov	x21, #0
	stp	xzr, xzr, [sp]
	mov	x22, #281474976710655
	mov	x23, #39612
	movk	x23, #22136, lsl #16
	movk	x23, #4660, lsl #32
	mov	w24, #-1
	mov	w25, #2147483647
	mov	w26, #65535
	mov	w27, #65536
	sub	x28, x29, #120
	b	LBB5_3
LBB5_1:
	cbnz	w19, LBB5_71
LBB5_2:
	ldp	x8, x9, [sp]
	add	x8, x8, #1
	cmp	w19, #1
	cinc	x9, x9, eq
	mov	x10, #281474976710656
	add	x22, x22, x10
	add	x23, x23, x10
	add	x24, x24, x10
	stp	x8, x9, [sp]
	add	x25, x25, x10
	add	x26, x26, x10
	add	x21, x21, x10
	subs	x27, x27, #1
	b.eq	LBB5_34
LBB5_3:
	stp	x21, x21, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_6
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_7
	b	LBB5_71
LBB5_6:
	cbnz	w19, LBB5_71
LBB5_7:
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	add	x8, x21, #1
	stp	x8, x8, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_10
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_11
	b	LBB5_71
LBB5_10:
	cbnz	w19, LBB5_71
LBB5_11:
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	add	x8, x21, #255
	stp	x8, x8, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_14
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_15
	b	LBB5_71
LBB5_14:
	cbnz	w19, LBB5_71
LBB5_15:
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	stp	x26, x26, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_18
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_19
	b	LBB5_71
LBB5_18:
	cbnz	w19, LBB5_71
LBB5_19:
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	stp	x25, x25, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_22
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_23
	b	LBB5_71
LBB5_22:
	cbnz	w19, LBB5_71
LBB5_23:
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	stp	x24, x24, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_26
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_27
	b	LBB5_71
LBB5_26:
	cbnz	w19, LBB5_71
LBB5_27:
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	stp	x23, x23, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_30
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_31
	b	LBB5_71
LBB5_30:
	cbnz	w19, LBB5_71
LBB5_31:
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	stp	x22, x22, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_1
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_2
	b	LBB5_71
LBB5_34:
	mov	x21, #0
	mov	x26, #0
	sub	x22, x29, #120
	mov	x23, #9222809086901354496
	mov	x24, #1
	movk	x24, #32770, lsl #48
	mov	w25, #16960
	movk	w25, #15, lsl #16
	b	LBB5_37
LBB5_35:
	cbnz	w19, LBB5_71
LBB5_36:
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	sub	x21, x21, #1
	add	x26, x26, x24
	cmp	x26, x25
	b.eq	LBB5_56
LBB5_37:
	ucvtf	d9, x26
	stp	d9, d9, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_40
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_41
	b	LBB5_71
LBB5_40:
	cbnz	w19, LBB5_71
LBB5_41:
	fmov	x27, d9
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	add	x8, x27, #1
	stp	x8, x8, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_44
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_45
	b	LBB5_71
LBB5_44:
	cbnz	w19, LBB5_71
LBB5_45:
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	sub	x8, x27, #1
	stp	x8, x8, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_48
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_49
	b	LBB5_71
LBB5_48:
	cbnz	w19, LBB5_71
LBB5_49:
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	add	x26, x26, x23
	stp	x26, x26, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_52
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_53
	b	LBB5_71
LBB5_52:
	cbnz	w19, LBB5_71
LBB5_53:
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	mov	x8, #9222809086901354496
	bfxil	x8, x21, #0, #32
	stp	x8, x8, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_35
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_36
	b	LBB5_71
LBB5_56:
	mov	x21, #0
Lloh4:
	adrp	x8, lCPI5_0@PAGE
Lloh5:
	ldr	q0, [x8, lCPI5_0@PAGEOFF]
Lloh6:
	adrp	x8, lCPI5_1@PAGE
Lloh7:
	ldr	q1, [x8, lCPI5_1@PAGEOFF]
	add	x8, sp, #16
	add	x22, x8, #16
	stp	q0, q1, [sp, #16]
Lloh8:
	adrp	x8, lCPI5_2@PAGE
Lloh9:
	ldr	q0, [x8, lCPI5_2@PAGEOFF]
Lloh10:
	adrp	x8, lCPI5_3@PAGE
Lloh11:
	ldr	q1, [x8, lCPI5_3@PAGEOFF]
	stp	q0, q1, [sp, #48]
Lloh12:
	adrp	x8, lCPI5_4@PAGE
Lloh13:
	ldr	q0, [x8, lCPI5_4@PAGEOFF]
Lloh14:
	adrp	x8, lCPI5_5@PAGE
Lloh15:
	ldr	q1, [x8, lCPI5_5@PAGEOFF]
	stp	q0, q1, [sp, #80]
Lloh16:
	adrp	x8, lCPI5_6@PAGE
Lloh17:
	ldr	q0, [x8, lCPI5_6@PAGEOFF]
Lloh18:
	adrp	x8, lCPI5_7@PAGE
Lloh19:
	ldr	q1, [x8, lCPI5_7@PAGEOFF]
	mov	x8, #4751297606875873280
	str	x8, [sp, #144]
	sub	x23, x29, #128
	stp	q0, q1, [sp, #112]
	b	LBB5_58
LBB5_57:
	cmp	x21, #15
	b.eq	LBB5_65
LBB5_58:
	ldr	x8, [x22, x21, lsl #3]
	add	x21, x21, #1
	sub	x24, x8, #32
	mov	w25, #65
	b	LBB5_61
LBB5_59:
	cbnz	w19, LBB5_64
LBB5_60:
	ldp	x10, x8, [sp]
	add	x9, x10, #1
	cmp	w19, #1
	cinc	x8, x8, eq
	stp	x9, x8, [sp]
	add	x24, x24, #1
	subs	x25, x25, #1
	b.eq	LBB5_57
LBB5_61:
	str	x24, [sp, #152]
	stur	x24, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-128]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-120]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [x29, #-112]
	tbz	w0, #0, LBB5_59
	tbz	w19, #0, LBB5_64
	cmp	w1, w20
	b.eq	LBB5_60
LBB5_64:
	add	x8, sp, #152
Lloh20:
	adrp	x9, __RNvXsC_NtNtCsjgY6bXVaRmE_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPAGE
Lloh21:
	ldr	x9, [x9, __RNvXsC_NtNtCsjgY6bXVaRmE_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPAGEOFF]
	stp	x8, x9, [sp, #160]
	sub	x8, x29, #128
Lloh22:
	adrp	x9, __RNvXs6_NtNtCsjgY6bXVaRmE_4core3fmt5floatdNtB7_5Debug3fmt@GOTPAGE
Lloh23:
	ldr	x9, [x9, __RNvXs6_NtNtCsjgY6bXVaRmE_4core3fmt5floatdNtB7_5Debug3fmt@GOTPAGEOFF]
	stp	x8, x9, [sp, #176]
Lloh24:
	adrp	x2, l_anon.cc796cd23bdcfc0714215e28034588ed.2@PAGE
Lloh25:
	add	x2, x2, l_anon.cc796cd23bdcfc0714215e28034588ed.2@PAGEOFF
Lloh26:
	adrp	x4, l_anon.cc796cd23bdcfc0714215e28034588ed.4@PAGE
Lloh27:
	add	x4, x4, l_anon.cc796cd23bdcfc0714215e28034588ed.4@PAGEOFF
	sub	x0, x29, #112
	sub	x1, x29, #120
	add	x3, sp, #160
	bl	__RINvNtCsjgY6bXVaRmE_4core9panicking13assert_failedINtNtB4_6option6OptionmEBM_ECsbukuFQpaN3d_21index_roundtrip_probe
LBB5_65:
	mov	x22, #16161
	movk	x22, #20880, lsl #16
	movk	x22, #51827, lsl #32
	movk	x22, #55362, lsl #48
	mov	w21, #38528
	movk	w21, #152, lsl #16
	sub	x23, x29, #120
	b	LBB5_68
LBB5_66:
	cbnz	w19, LBB5_71
LBB5_67:
	ldp	x8, x9, [sp]
	add	x8, x8, #1
	cmp	w19, #1
	cinc	x9, x9, eq
	stp	x8, x9, [sp]
	subs	w21, w21, #1
	b.eq	LBB5_72
LBB5_68:
	eor	x8, x22, x22, lsl #13
	eor	x8, x8, x8, lsr #7
	eor	x22, x8, x8, lsl #17
	stp	x22, x22, [x29, #-128]
	; InlineAsm Start
	; InlineAsm End
	ldur	d8, [x29, #-120]
	mov.16b	v0, v8
	bl	_original_index
	mov	x19, x0
	mov	x20, x1
	stp	w0, w1, [x29, #-112]
	mov.16b	v0, v8
	bl	_proposed_index
	stp	w0, w1, [sp, #160]
	tbz	w0, #0, LBB5_66
	tbz	w19, #0, LBB5_71
	cmp	w1, w20
	b.eq	LBB5_67
LBB5_71:
	sub	x8, x29, #128
Lloh28:
	adrp	x9, __RNvXsC_NtNtCsjgY6bXVaRmE_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPAGE
Lloh29:
	ldr	x9, [x9, __RNvXsC_NtNtCsjgY6bXVaRmE_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPAGEOFF]
	stp	x8, x9, [sp, #16]
	sub	x8, x29, #120
Lloh30:
	adrp	x9, __RNvXs6_NtNtCsjgY6bXVaRmE_4core3fmt5floatdNtB7_5Debug3fmt@GOTPAGE
Lloh31:
	ldr	x9, [x9, __RNvXs6_NtNtCsjgY6bXVaRmE_4core3fmt5floatdNtB7_5Debug3fmt@GOTPAGEOFF]
	stp	x8, x9, [sp, #32]
Lloh32:
	adrp	x2, l_anon.cc796cd23bdcfc0714215e28034588ed.2@PAGE
Lloh33:
	add	x2, x2, l_anon.cc796cd23bdcfc0714215e28034588ed.2@PAGEOFF
Lloh34:
	adrp	x4, l_anon.cc796cd23bdcfc0714215e28034588ed.4@PAGE
Lloh35:
	add	x4, x4, l_anon.cc796cd23bdcfc0714215e28034588ed.4@PAGEOFF
	add	x0, sp, #160
	sub	x1, x29, #112
	add	x3, sp, #16
	bl	__RINvNtCsjgY6bXVaRmE_4core9panicking13assert_failedINtNtB4_6option6OptionmEBM_ECsbukuFQpaN3d_21index_roundtrip_probe
LBB5_72:
	mov	w10, #33920
	movk	w10, #30, lsl #16
	cmp	x9, x10
	b.ls	LBB5_86
	mov	w10, #38528
	movk	w10, #152, lsl #16
	sub	x19, x8, x9
	cmp	x19, x10
	b.ls	LBB5_87
	mov	w8, #1
	str	x8, [sp, #160]
	movi.2d	v0, #0000000000000000
	bl	_proposed_index
	stp	w0, w1, [sp, #16]
	tbz	w0, #0, LBB5_81
	cbnz	w1, LBB5_81
	mov	w8, #1
	str	x8, [sp, #160]
	mov	x8, #-9223372036854775808
	fmov	d0, x8
	bl	_proposed_index
	stp	w0, w1, [sp, #16]
	tbz	w0, #0, LBB5_81
	cbnz	w1, LBB5_81
	str	wzr, [sp, #160]
	fmov	d0, #0.50000000
	bl	_proposed_index
	stp	w0, w1, [sp, #16]
	tbnz	w0, #0, LBB5_81
	str	wzr, [sp, #160]
	fmov	d0, #-1.00000000
	bl	_proposed_index
	stp	w0, w1, [sp, #16]
	tbnz	w0, #0, LBB5_81
	mov	x8, #-8589934591
	str	x8, [sp, #160]
	mov	x8, #281474972516352
	movk	x8, #16879, lsl #48
	fmov	d0, x8
	bl	_proposed_index
	stp	w0, w1, [sp, #16]
	cmn	w1, #2
	cset	w8, eq
	tst	w0, w8
	b.ne	LBB5_82
LBB5_81:
Lloh36:
	adrp	x4, l_anon.cc796cd23bdcfc0714215e28034588ed.10@PAGE
Lloh37:
	add	x4, x4, l_anon.cc796cd23bdcfc0714215e28034588ed.10@PAGEOFF
	add	x0, sp, #16
	add	x1, sp, #160
	mov	x2, #0
	bl	__RINvNtCsjgY6bXVaRmE_4core9panicking13assert_failedINtNtB4_6option6OptionmEBM_ECsbukuFQpaN3d_21index_roundtrip_probe
LBB5_82:
	str	wzr, [sp, #160]
	mov	x8, #281474974613504
	movk	x8, #16879, lsl #48
	fmov	d0, x8
	bl	_proposed_index
	stp	w0, w1, [sp, #16]
	tbnz	w0, #0, LBB5_81
	str	wzr, [sp, #160]
	mov	x8, #9221120237041090560
	fmov	d0, x8
	bl	_proposed_index
	stp	w0, w1, [sp, #16]
	tbnz	w0, #0, LBB5_81
	str	wzr, [sp, #160]
	mov	x8, #9218868437227405312
	fmov	d0, x8
	bl	_proposed_index
	stp	w0, w1, [sp, #16]
	tbnz	w0, #0, LBB5_81
	str	x19, [sp, #160]
	mov	x8, sp
Lloh38:
	adrp	x9, __RNvXsd_NtNtNtCsjgY6bXVaRmE_4core3fmt3num3impyNtB9_7Display3fmt@GOTPAGE
Lloh39:
	ldr	x9, [x9, __RNvXsd_NtNtNtCsjgY6bXVaRmE_4core3fmt3num3impyNtB9_7Display3fmt@GOTPAGEOFF]
	stp	x8, x9, [sp, #16]
	add	x8, sp, #8
	stp	x8, x9, [sp, #32]
	add	x8, sp, #160
	stp	x8, x9, [sp, #48]
Lloh40:
	adrp	x0, l_anon.cc796cd23bdcfc0714215e28034588ed.9@PAGE
Lloh41:
	add	x0, x0, l_anon.cc796cd23bdcfc0714215e28034588ed.9@PAGEOFF
	add	x1, sp, #16
	bl	__RNvNtNtCs8BpVhDwHqJW_3std2io5stdio6__print
	.cfi_def_cfa wsp, 336
	ldp	x29, x30, [sp, #320]
	ldp	x20, x19, [sp, #304]
	ldp	x22, x21, [sp, #288]
	ldp	x24, x23, [sp, #272]
	ldp	x26, x25, [sp, #256]
	ldp	x28, x27, [sp, #240]
	ldp	d9, d8, [sp, #224]
	add	sp, sp, #336
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore b8
	.cfi_restore b9
	ret
LBB5_86:
	.cfi_restore_state
Lloh42:
	adrp	x0, l_anon.cc796cd23bdcfc0714215e28034588ed.5@PAGE
Lloh43:
	add	x0, x0, l_anon.cc796cd23bdcfc0714215e28034588ed.5@PAGEOFF
Lloh44:
	adrp	x2, l_anon.cc796cd23bdcfc0714215e28034588ed.6@PAGE
Lloh45:
	add	x2, x2, l_anon.cc796cd23bdcfc0714215e28034588ed.6@PAGEOFF
	mov	w1, #38
	bl	__RNvNtCsjgY6bXVaRmE_4core9panicking5panic
LBB5_87:
Lloh46:
	adrp	x0, l_anon.cc796cd23bdcfc0714215e28034588ed.7@PAGE
Lloh47:
	add	x0, x0, l_anon.cc796cd23bdcfc0714215e28034588ed.7@PAGEOFF
Lloh48:
	adrp	x2, l_anon.cc796cd23bdcfc0714215e28034588ed.8@PAGE
Lloh49:
	add	x2, x2, l_anon.cc796cd23bdcfc0714215e28034588ed.8@PAGEOFF
	mov	w1, #47
	bl	__RNvNtCsjgY6bXVaRmE_4core9panicking5panic
	.loh AdrpLdr	Lloh18, Lloh19
	.loh AdrpAdrp	Lloh16, Lloh18
	.loh AdrpLdr	Lloh16, Lloh17
	.loh AdrpAdrp	Lloh14, Lloh16
	.loh AdrpLdr	Lloh14, Lloh15
	.loh AdrpAdrp	Lloh12, Lloh14
	.loh AdrpLdr	Lloh12, Lloh13
	.loh AdrpAdrp	Lloh10, Lloh12
	.loh AdrpLdr	Lloh10, Lloh11
	.loh AdrpAdrp	Lloh8, Lloh10
	.loh AdrpLdr	Lloh8, Lloh9
	.loh AdrpLdr	Lloh6, Lloh7
	.loh AdrpAdrp	Lloh4, Lloh6
	.loh AdrpLdr	Lloh4, Lloh5
	.loh AdrpAdd	Lloh26, Lloh27
	.loh AdrpAdd	Lloh24, Lloh25
	.loh AdrpLdrGot	Lloh22, Lloh23
	.loh AdrpLdrGot	Lloh20, Lloh21
	.loh AdrpAdd	Lloh34, Lloh35
	.loh AdrpAdd	Lloh32, Lloh33
	.loh AdrpLdrGot	Lloh30, Lloh31
	.loh AdrpLdrGot	Lloh28, Lloh29
	.loh AdrpAdd	Lloh36, Lloh37
	.loh AdrpAdd	Lloh40, Lloh41
	.loh AdrpLdrGot	Lloh38, Lloh39
	.loh AdrpAdd	Lloh44, Lloh45
	.loh AdrpAdd	Lloh42, Lloh43
	.loh AdrpAdd	Lloh48, Lloh49
	.loh AdrpAdd	Lloh46, Lloh47
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsjgY6bXVaRmE_4core3fmtRINtNtB8_6option6OptionmENtB6_5Debug3fmtCsbukuFQpaN3d_21index_roundtrip_probe:
	.cfi_startproc
	mov	x8, x1
	ldr	x9, [x0]
	ldr	w10, [x9], #4
	cbz	w10, LBB6_2
	sub	sp, sp, #32
	.cfi_def_cfa_offset 32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	str	x9, [sp, #8]
Lloh50:
	adrp	x1, l_anon.cc796cd23bdcfc0714215e28034588ed.13@PAGE
Lloh51:
	add	x1, x1, l_anon.cc796cd23bdcfc0714215e28034588ed.13@PAGEOFF
Lloh52:
	adrp	x4, l_anon.cc796cd23bdcfc0714215e28034588ed.12@PAGE
Lloh53:
	add	x4, x4, l_anon.cc796cd23bdcfc0714215e28034588ed.12@PAGEOFF
	add	x3, sp, #8
	mov	x0, x8
	mov	w2, #4
	bl	__RNvMsa_NtCsjgY6bXVaRmE_4core3fmtNtB5_9Formatter25debug_tuple_field1_finish
	.cfi_def_cfa wsp, 32
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
LBB6_2:
Lloh54:
	adrp	x1, l_anon.cc796cd23bdcfc0714215e28034588ed.11@PAGE
Lloh55:
	add	x1, x1, l_anon.cc796cd23bdcfc0714215e28034588ed.11@PAGEOFF
	mov	x0, x8
	mov	w2, #4
	b	__RNvMsa_NtCsjgY6bXVaRmE_4core3fmtNtB5_9Formatter9write_str
	.loh AdrpAdd	Lloh52, Lloh53
	.loh AdrpAdd	Lloh50, Lloh51
	.loh AdrpAdd	Lloh54, Lloh55
	.cfi_endproc

	.p2align	2
__RNvXs1g_NtCsjgY6bXVaRmE_4core3fmtRmNtB6_5Debug3fmtCsbukuFQpaN3d_21index_roundtrip_probe:
	.cfi_startproc
	ldr	x0, [x0]
	ldr	w8, [x1, #16]
	tbnz	w8, #25, LBB7_3
	tbnz	w8, #26, LBB7_4
	b	__RNvXs8_NtNtNtCsjgY6bXVaRmE_4core3fmt3num3impmNtB9_7Display3fmt
LBB7_3:
	b	__RNvXsu_NtNtCsjgY6bXVaRmE_4core3fmt3nummNtB7_8LowerHex3fmt
LBB7_4:
	b	__RNvXsw_NtNtCsjgY6bXVaRmE_4core3fmt3nummNtB7_8UpperHex3fmt
	.cfi_endproc

	.globl	_original_index
	.p2align	2
_original_index:
	.cfi_startproc
	fmov	x8, d0
	mov	w9, #2147352576
	mvn	w10, w8
	lsr	w10, w10, #31
	and	x11, x8, #0xffff000000000000
	fmov	x12, d0
	ands	x13, x12, #0x7fffffffffffffff
	cset	w14, eq
	sub	x15, x12, #1
	mov	x16, #4503599627370495
	cmp	x15, x16
	mov	x15, #-9223090561878065153
	csinc	w14, w14, wzr, hs
	mov	x16, #-4503599627370496
	add	x13, x13, x16
	lsr	x13, x13, #53
	cmp	x13, #1023
	ccmn	x12, #1, #4, lo
	csinc	w12, w14, wzr, le
	mov	x13, #-1688849860263937
	add	x11, x11, x15
	cmp	x11, x13
	csel	w11, wzr, w12, hs
	frintz	d1, d0
	fcmp	d0, d1
	csel	w11, wzr, w11, ne
	mov	x12, #281474972516352
	movk	x12, #16879, lsl #48
	fmov	d1, x12
	fcmp	d0, d1
	fcvtzu	w12, d0
	csel	w11, wzr, w11, hi
	cmp	x9, x8, lsr #32
	csel	w1, w8, w12, eq
	csel	w0, w10, w11, eq
	ret
	.cfi_endproc

	.globl	_proposed_index
	.p2align	2
_proposed_index:
	.cfi_startproc
	fcvtzu	w8, d0
	ucvtf	d1, w8
	fcmp	d0, d1
	fmov	x9, d0
	mov	w10, #2147352576
	mvn	w11, w9
	lsr	w11, w11, #31
	ccmn	w8, #1, #4, eq
	cset	w12, ne
	cmp	x10, x9, lsr #32
	csel	w1, w9, w8, eq
	csel	w0, w11, w12, eq
	ret
	.cfi_endproc

	.globl	_main
	.p2align	2
_main:
	.cfi_startproc
	sub	sp, sp, #32
	stp	x29, x30, [sp, #16]
	add	x29, sp, #16
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x3, x1
	sxtw	x2, w0
Lloh56:
	adrp	x8, __RNvCsbukuFQpaN3d_21index_roundtrip_probe4main@PAGE
Lloh57:
	add	x8, x8, __RNvCsbukuFQpaN3d_21index_roundtrip_probe4main@PAGEOFF
	str	x8, [sp, #8]
Lloh58:
	adrp	x1, l_anon.cc796cd23bdcfc0714215e28034588ed.0@PAGE
Lloh59:
	add	x1, x1, l_anon.cc796cd23bdcfc0714215e28034588ed.0@PAGEOFF
	add	x0, sp, #8
	mov	w4, #0
	bl	__RNvNtCs8BpVhDwHqJW_3std2rt19lang_start_internal
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #32
	ret
	.loh AdrpAdd	Lloh58, Lloh59
	.loh AdrpAdd	Lloh56, Lloh57
	.cfi_endproc

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.cc796cd23bdcfc0714215e28034588ed.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNSNvYNCINvNtCs8BpVhDwHqJW_3std2rt10lang_startuE0INtNtNtCsjgY6bXVaRmE_4core3ops8function6FnOnceuE9call_once6vtableCsbukuFQpaN3d_21index_roundtrip_probe
	.quad	__RNCINvNtCs8BpVhDwHqJW_3std2rt10lang_startuE0CsbukuFQpaN3d_21index_roundtrip_probe
	.quad	__RNCINvNtCs8BpVhDwHqJW_3std2rt10lang_startuE0CsbukuFQpaN3d_21index_roundtrip_probe

	.p2align	3, 0x0
l_anon.cc796cd23bdcfc0714215e28034588ed.1:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsjgY6bXVaRmE_4core3fmtRINtNtB8_6option6OptionmENtB6_5Debug3fmtCsbukuFQpaN3d_21index_roundtrip_probe

	.section	__TEXT,__const
l_anon.cc796cd23bdcfc0714215e28034588ed.2:
	.asciz	"\005bits=\303 \000\000i\020\000\b, value=\300"

	.section	__TEXT,__cstring,cstring_literals
l_anon.cc796cd23bdcfc0714215e28034588ed.3:
	.asciz	"benchmarks/json_performance/.work/materialized-read-r23/index-roundtrip-probe.rs"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.cc796cd23bdcfc0714215e28034588ed.4:
	.quad	l_anon.cc796cd23bdcfc0714215e28034588ed.3
	.asciz	"P\000\000\000\000\000\000\0002\000\000\000\003\000\000"

	.section	__TEXT,__const
l_anon.cc796cd23bdcfc0714215e28034588ed.5:
	.ascii	"assertion failed: accepted > 2_000_000"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.cc796cd23bdcfc0714215e28034588ed.6:
	.quad	l_anon.cc796cd23bdcfc0714215e28034588ed.3
	.asciz	"P\000\000\000\000\000\000\000B\000\000\000\002\000\000"

	.section	__TEXT,__const
l_anon.cc796cd23bdcfc0714215e28034588ed.7:
	.ascii	"assertion failed: total - accepted > 10_000_000"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.cc796cd23bdcfc0714215e28034588ed.8:
	.quad	l_anon.cc796cd23bdcfc0714215e28034588ed.3
	.asciz	"P\000\000\000\000\000\000\000B\000\000\000\036\000\000"

	.section	__TEXT,__cstring,cstring_literals
l_anon.cc796cd23bdcfc0714215e28034588ed.9:
	.asciz	"\tverified \300\017 bit patterns: \300\013 accepted, \300\n rejected\n"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.cc796cd23bdcfc0714215e28034588ed.10:
	.quad	l_anon.cc796cd23bdcfc0714215e28034588ed.3
	.asciz	"P\000\000\000\000\000\000\000C\000\000\000\252\000\000"

	.section	__TEXT,__literal4,4byte_literals
l_anon.cc796cd23bdcfc0714215e28034588ed.11:
	.ascii	"None"

	.section	__DATA,__const
	.p2align	3, 0x0
l_anon.cc796cd23bdcfc0714215e28034588ed.12:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	__RNvXs1g_NtCsjgY6bXVaRmE_4core3fmtRmNtB6_5Debug3fmtCsbukuFQpaN3d_21index_roundtrip_probe

	.section	__TEXT,__literal4,4byte_literals
l_anon.cc796cd23bdcfc0714215e28034588ed.13:
	.ascii	"Some"

.subsections_via_symbols
