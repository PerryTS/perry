
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/candidate-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010089c2a0 <_js_packed_arraylike_index_get>:
10089c2a0:     	sub	sp, sp, #0x90
10089c2a4:     	stp	d9, d8, [sp, #0x20]
10089c2a8:     	stp	x28, x27, [sp, #0x30]
10089c2ac:     	stp	x26, x25, [sp, #0x40]
10089c2b0:     	stp	x24, x23, [sp, #0x50]
10089c2b4:     	stp	x22, x21, [sp, #0x60]
10089c2b8:     	stp	x20, x19, [sp, #0x70]
10089c2bc:     	stp	x29, x30, [sp, #0x80]
10089c2c0:     	add	x29, sp, #0x80
10089c2c4:     	fmov	x1, d1
10089c2c8:     	mov	w8, #0x7ffe0000         ; =2147352576
10089c2cc:     	cmp	x8, x1, lsr #32
10089c2d0:     	b.ne	0x10089c2ec <_js_packed_arraylike_index_get+0x4c>
10089c2d4:     	tbnz	w1, #0x1f, 0x10089c570 <_js_packed_arraylike_index_get+0x2d0>
10089c2d8:     	fmov	x8, d0
10089c2dc:     	mov	w9, #0x7ffd             ; =32765
10089c2e0:     	cmp	x9, x8, lsr #48
10089c2e4:     	b.eq	0x10089c374 <_js_packed_arraylike_index_get+0xd4>
10089c2e8:     	b	0x10089c570 <_js_packed_arraylike_index_get+0x2d0>
10089c2ec:     	and	x8, x1, #0xffff000000000000
10089c2f0:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10089c2f4:     	cmp	x1, x9
10089c2f8:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10089c2fc:     	ccmp	x8, x9, #0x2, hs
10089c300:     	cset	w8, hi
10089c304:     	fmov	x9, d1
10089c308:     	ands	x10, x9, #0x7fffffffffffffff
10089c30c:     	cset	w11, eq
10089c310:     	sub	x12, x9, #0x1
10089c314:     	mov	x13, #0xfffffffffffff   ; =4503599627370495
10089c318:     	cmp	x12, x13
10089c31c:     	csinc	w11, w11, wzr, hs
10089c320:     	mov	x12, #-0x10000000000000 ; =-4503599627370496
10089c324:     	add	x10, x10, x12
10089c328:     	lsr	x10, x10, #53
10089c32c:     	cmp	x10, #0x3ff
10089c330:     	ccmn	x9, #0x1, #0x4, lo
10089c334:     	csinc	w9, w11, wzr, le
10089c338:     	mov	x10, #0xffffffc00000    ; =281474972516352
10089c33c:     	movk	x10, #0x41ef, lsl #48
10089c340:     	fmov	d2, x10
10089c344:     	fcmp	d1, d2
10089c348:     	b.hi	0x10089c570 <_js_packed_arraylike_index_get+0x2d0>
10089c34c:     	frintz	d2, d1
10089c350:     	fcmp	d1, d2
10089c354:     	b.ne	0x10089c570 <_js_packed_arraylike_index_get+0x2d0>
10089c358:     	cbz	w9, 0x10089c570 <_js_packed_arraylike_index_get+0x2d0>
10089c35c:     	cbz	w8, 0x10089c570 <_js_packed_arraylike_index_get+0x2d0>
10089c360:     	fcvtzu	w1, d1
10089c364:     	fmov	x8, d0
10089c368:     	mov	w9, #0x7ffd             ; =32765
10089c36c:     	cmp	x9, x8, lsr #48
10089c370:     	b.ne	0x10089c570 <_js_packed_arraylike_index_get+0x2d0>
10089c374:     	and	x19, x8, #0xffffffffffff
10089c378:     	sub	x8, x19, #0x100, lsl #12 ; =0x100000
10089c37c:     	mov	x9, #0x7fffffffffff     ; =140737488355327
10089c380:     	movk	x9, #0xffef, lsl #16
10089c384:     	cmp	x8, x9
10089c388:     	b.hi	0x10089c570 <_js_packed_arraylike_index_get+0x2d0>
10089c38c:     	ldurb	w8, [x19, #-0x8]
10089c390:     	cmp	w8, #0x9
10089c394:     	b.eq	0x10089c3a8 <_js_packed_arraylike_index_get+0x108>
10089c398:     	cmp	w8, #0x2
10089c39c:     	b.eq	0x10089c3d0 <_js_packed_arraylike_index_get+0x130>
10089c3a0:     	cmp	w8, #0x1
10089c3a4:     	b.ne	0x10089c570 <_js_packed_arraylike_index_get+0x2d0>
10089c3a8:     	mov	x0, x19
10089c3ac:     	ldp	x29, x30, [sp, #0x80]
10089c3b0:     	ldp	x20, x19, [sp, #0x70]
10089c3b4:     	ldp	x22, x21, [sp, #0x60]
10089c3b8:     	ldp	x24, x23, [sp, #0x50]
10089c3bc:     	ldp	x26, x25, [sp, #0x40]
10089c3c0:     	ldp	x28, x27, [sp, #0x30]
10089c3c4:     	ldp	d9, d8, [sp, #0x20]
10089c3c8:     	add	sp, sp, #0x90
10089c3cc:     	b	0x1007bcc90 <_js_array_get_f64>
10089c3d0:     	ldursb	w8, [x19, #-0x7]
10089c3d4:     	tbnz	w8, #0x1f, 0x10089c570 <_js_packed_arraylike_index_get+0x2d0>
10089c3d8:     	ldr	x8, [x19, #0x8]
10089c3dc:     	cbz	x8, 0x10089c418 <_js_packed_arraylike_index_get+0x178>
10089c3e0:     	ldr	x8, [x8, #0x60]
10089c3e4:     	cbz	x8, 0x10089c418 <_js_packed_arraylike_index_get+0x178>
10089c3e8:     	ldr	w9, [x8]
10089c3ec:     	cmp	w1, w9
10089c3f0:     	b.hs	0x10089c570 <_js_packed_arraylike_index_get+0x2d0>
10089c3f4:     	add	x8, x8, w1, uxtw #3
10089c3f8:     	ldr	x8, [x8, #0x8]
10089c3fc:     	mov	x9, #0x1                ; =1
10089c400:     	movk	x9, #0x7ffc, lsl #48
10089c404:     	add	x9, x9, #0xf
10089c408:     	cmp	x8, x9
10089c40c:     	b.eq	0x10089c570 <_js_packed_arraylike_index_get+0x2d0>
10089c410:     	fmov	d0, x8
10089c414:     	b	0x10089c628 <_js_packed_arraylike_index_get+0x388>
10089c418:     	mov	x21, x0
10089c41c:     	mov	x22, x1
10089c420:     	mov.16b	v8, v0
10089c424:     	mov.16b	v9, v1
10089c428:     	add	x0, sp, #0xc
10089c42c:     	mov	x1, x19
10089c430:     	bl	0x100547764 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33dense_layout_for_validated_object>
10089c434:     	ldr	w8, [sp, #0xc]
10089c438:     	cbz	w8, 0x10089c568 <_js_packed_arraylike_index_get+0x2c8>
10089c43c:     	ldp	w20, w25, [sp, #0x10]
10089c440:     	adrp	x24, 0x100f7d000 <__MergedGlobals+0xd0>
10089c444:     	add	x24, x24, #0x390
10089c448:     	adrp	x23, 0x100f7d000 <__MergedGlobals+0xd0>
10089c44c:     	ldp	w27, w26, [sp, #0x18]
10089c450:     	cbz	x21, 0x10089c494 <_js_packed_arraylike_index_get+0x1f4>
10089c454:     	mov	x0, x21
10089c458:     	ldapr	x8, [x24]
10089c45c:     	cbnz	x8, 0x10089c4e8 <_js_packed_arraylike_index_get+0x248>
10089c460:     	ldrb	w8, [x23, #0x398]
10089c464:     	tbz	w8, #0x0, 0x10089c494 <_js_packed_arraylike_index_get+0x1f4>
10089c468:     	ldapr	x21, [x0]
10089c46c:     	cbz	x21, 0x10089c5d4 <_js_packed_arraylike_index_get+0x334>
10089c470:     	mov	x0, x19
10089c474:     	mov	x1, x20
10089c478:     	bl	0x100548640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass42array_subclass_named_prefix_token_for_slot>
10089c47c:     	stp	x20, x25, [x21, #0x8]
10089c480:     	stp	x27, x26, [x21, #0x18]
10089c484:     	cbnz	x0, 0x10089c490 <_js_packed_arraylike_index_get+0x1f0>
10089c488:     	ldp	w9, w8, [x19]
10089c48c:     	orr	x0, x8, x9, lsl #32
10089c490:     	str	x0, [x21]
10089c494:     	cmp	w20, w26
10089c498:     	b.hs	0x10089c4a8 <_js_packed_arraylike_index_get+0x208>
10089c49c:     	add	x8, x19, x20, lsl #3
10089c4a0:     	ldr	x0, [x8, #0x10]
10089c4a4:     	b	0x10089c530 <_js_packed_arraylike_index_get+0x290>
10089c4a8:     	ldapr	x8, [x24]
10089c4ac:     	cbnz	x8, 0x10089c4fc <_js_packed_arraylike_index_get+0x25c>
10089c4b0:     	mov	x0, #0x1                ; =1
10089c4b4:     	movk	x0, #0x7ffc, lsl #48
10089c4b8:     	ldrb	w8, [x23, #0x398]
10089c4bc:     	tbz	w8, #0x0, 0x10089c510 <_js_packed_arraylike_index_get+0x270>
10089c4c0:     	ldr	x8, [x19, #0x8]
10089c4c4:     	cbz	x8, 0x10089c530 <_js_packed_arraylike_index_get+0x290>
10089c4c8:     	ldr	x8, [x8, #0x20]
10089c4cc:     	cbz	x8, 0x10089c530 <_js_packed_arraylike_index_get+0x290>
10089c4d0:     	ldr	w9, [x8]
10089c4d4:     	cmp	w20, w9
10089c4d8:     	b.hs	0x10089c530 <_js_packed_arraylike_index_get+0x290>
10089c4dc:     	add	x8, x8, x20, lsl #3
10089c4e0:     	ldr	x0, [x8, #0x8]
10089c4e4:     	b	0x10089c530 <_js_packed_arraylike_index_get+0x290>
10089c4e8:     	bl	0x100b183ec <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill20object_spill_enabled0E0zEB1A_>
10089c4ec:     	mov	x0, x21
10089c4f0:     	ldrb	w8, [x23, #0x398]
10089c4f4:     	tbnz	w8, #0x0, 0x10089c468 <_js_packed_arraylike_index_get+0x1c8>
10089c4f8:     	b	0x10089c494 <_js_packed_arraylike_index_get+0x1f4>
10089c4fc:     	bl	0x100b183ec <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill20object_spill_enabled0E0zEB1A_>
10089c500:     	mov	x0, #0x1                ; =1
10089c504:     	movk	x0, #0x7ffc, lsl #48
10089c508:     	ldrb	w8, [x23, #0x398]
10089c50c:     	tbnz	w8, #0x0, 0x10089c4c0 <_js_packed_arraylike_index_get+0x220>
10089c510:     	mov	x0, x19
10089c514:     	mov	x1, x20
10089c518:     	bl	0x1005d9b5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill12overflow_get>
10089c51c:     	mov	x8, x0
10089c520:     	mov	x0, #0x1                ; =1
10089c524:     	movk	x0, #0x7ffc, lsl #48
10089c528:     	tst	w8, #0x1
10089c52c:     	csel	x0, x1, x0, ne
10089c530:     	bl	0x100546460 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22nonnegative_u32_length>
10089c534:     	cmp	w0, #0x1
10089c538:     	b.ne	0x10089c568 <_js_packed_arraylike_index_get+0x2c8>
10089c53c:     	cmp	w22, w1
10089c540:     	b.hs	0x10089c568 <_js_packed_arraylike_index_get+0x2c8>
10089c544:     	cmp	w22, w27
10089c548:     	b.hs	0x10089c568 <_js_packed_arraylike_index_get+0x2c8>
10089c54c:     	adds	w1, w25, w22
10089c550:     	b.hs	0x10089c568 <_js_packed_arraylike_index_get+0x2c8>
10089c554:     	cmp	w1, w26
10089c558:     	b.hs	0x10089c594 <_js_packed_arraylike_index_get+0x2f4>
10089c55c:     	add	x8, x19, w1, uxtw #3
10089c560:     	ldr	x20, [x8, #0x10]
10089c564:     	b	0x10089c624 <_js_packed_arraylike_index_get+0x384>
10089c568:     	mov.16b	v1, v9
10089c56c:     	mov.16b	v0, v8
10089c570:     	ldp	x29, x30, [sp, #0x80]
10089c574:     	ldp	x20, x19, [sp, #0x70]
10089c578:     	ldp	x22, x21, [sp, #0x60]
10089c57c:     	ldp	x24, x23, [sp, #0x50]
10089c580:     	ldp	x26, x25, [sp, #0x40]
10089c584:     	ldp	x28, x27, [sp, #0x30]
10089c588:     	ldp	d9, d8, [sp, #0x20]
10089c58c:     	add	sp, sp, #0x90
10089c590:     	b	0x10081b2f4 <_js_dyn_index_get>
10089c594:     	ldapr	x8, [x24]
10089c598:     	cbnz	x8, 0x10089c5f8 <_js_packed_arraylike_index_get+0x358>
10089c59c:     	mov	x20, #0x1               ; =1
10089c5a0:     	movk	x20, #0x7ffc, lsl #48
10089c5a4:     	ldrb	w8, [x23, #0x398]
10089c5a8:     	tbz	w8, #0x0, 0x10089c614 <_js_packed_arraylike_index_get+0x374>
10089c5ac:     	ldr	x8, [x19, #0x8]
10089c5b0:     	cbz	x8, 0x10089c624 <_js_packed_arraylike_index_get+0x384>
10089c5b4:     	ldr	x8, [x8, #0x20]
10089c5b8:     	cbz	x8, 0x10089c624 <_js_packed_arraylike_index_get+0x384>
10089c5bc:     	ldr	w9, [x8]
10089c5c0:     	cmp	w1, w9
10089c5c4:     	b.hs	0x10089c624 <_js_packed_arraylike_index_get+0x384>
10089c5c8:     	add	x8, x8, w1, uxtw #3
10089c5cc:     	ldr	x20, [x8, #0x8]
10089c5d0:     	b	0x10089c624 <_js_packed_arraylike_index_get+0x384>
10089c5d4:     	bl	0x100b37fa8 <__RINvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set7ic_slot16pic_slot_publishAyj5_EB8_>
10089c5d8:     	mov	x21, x0
10089c5dc:     	mov	x0, x19
10089c5e0:     	mov	x1, x20
10089c5e4:     	bl	0x100548640 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass42array_subclass_named_prefix_token_for_slot>
10089c5e8:     	stp	x20, x25, [x21, #0x8]
10089c5ec:     	stp	x27, x26, [x21, #0x18]
10089c5f0:     	cbnz	x0, 0x10089c490 <_js_packed_arraylike_index_get+0x1f0>
10089c5f4:     	b	0x10089c488 <_js_packed_arraylike_index_get+0x1e8>
10089c5f8:     	mov	x20, x1
10089c5fc:     	bl	0x100b183ec <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill20object_spill_enabled0E0zEB1A_>
10089c600:     	mov	x1, x20
10089c604:     	mov	x20, #0x1               ; =1
10089c608:     	movk	x20, #0x7ffc, lsl #48
10089c60c:     	ldrb	w8, [x23, #0x398]
10089c610:     	tbnz	w8, #0x0, 0x10089c5ac <_js_packed_arraylike_index_get+0x30c>
10089c614:     	mov	x0, x19
10089c618:     	bl	0x1005d9b5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill12overflow_get>
10089c61c:     	tst	w0, #0x1
10089c620:     	csel	x20, x1, x20, ne
10089c624:     	fmov	d0, x20
10089c628:     	ldp	x29, x30, [sp, #0x80]
10089c62c:     	ldp	x20, x19, [sp, #0x70]
10089c630:     	ldp	x22, x21, [sp, #0x60]
10089c634:     	ldp	x24, x23, [sp, #0x50]
10089c638:     	ldp	x26, x25, [sp, #0x40]
10089c63c:     	ldp	x28, x27, [sp, #0x30]
10089c640:     	ldp	d9, d8, [sp, #0x20]
10089c644:     	add	sp, sp, #0x90
10089c648:     	ret
10089c64c:     	nop
10089c650:     	nop
10089c654:     	nop
10089c658:     	nop
10089c65c:     	nop
10089c660:     	nop
10089c664:     	nop
10089c668:     	nop
10089c66c:     	nop
10089c670:     	nop
10089c674:     	nop
10089c678:     	nop
10089c67c:     	nop
