
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/main-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007bcc50 <_js_array_get_f64>:
1007bcc50:     	sub	sp, sp, #0x70
1007bcc54:     	stp	x26, x25, [sp, #0x20]
1007bcc58:     	stp	x24, x23, [sp, #0x30]
1007bcc5c:     	stp	x22, x21, [sp, #0x40]
1007bcc60:     	stp	x20, x19, [sp, #0x50]
1007bcc64:     	stp	x29, x30, [sp, #0x60]
1007bcc68:     	add	x29, sp, #0x60
1007bcc6c:     	mov	x19, x1
1007bcc70:     	mov	x22, x0
1007bcc74:     	lsr	x25, x0, #51
1007bcc78:     	mov	x20, x0
1007bcc7c:     	cmp	x25, #0xfff
1007bcc80:     	b.lo	0x1007bcc9c <_js_array_get_f64+0x4c>
1007bcc84:     	mov	w8, #0x7ffc             ; =32764
1007bcc88:     	cmp	x8, x22, lsr #48
1007bcc8c:     	b.ne	0x1007bcc98 <_js_array_get_f64+0x48>
1007bcc90:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007bcc94:     	b	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bcc98:     	and	x20, x22, #0xffffffffffff
1007bcc9c:     	lsr	x8, x20, #3
1007bcca0:     	cmp	x8, #0x200
1007bcca4:     	b.ls	0x1007bccdc <_js_array_get_f64+0x8c>
1007bcca8:     	ldurb	w8, [x20, #-0x8]
1007bccac:     	cmp	w8, #0x9
1007bccb0:     	b.ne	0x1007bccdc <_js_array_get_f64+0x8c>
1007bccb4:     	ldr	w8, [x20, #0x4]
1007bccb8:     	mov	w9, #0x5841             ; =22593
1007bccbc:     	movk	w9, #0x4c5a, lsl #16
1007bccc0:     	cmp	w8, w9
1007bccc4:     	b.ne	0x1007bccdc <_js_array_get_f64+0x8c>
1007bccc8:     	mov	x0, x20
1007bcccc:     	mov	x1, x19
1007bccd0:     	bl	0x10037773c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get>
1007bccd4:     	fmov	d0, x0
1007bccd8:     	b	0x1007bd34c <_js_array_get_f64+0x6fc>
1007bccdc:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bcce0:     	b.lo	0x1007bcd90 <_js_array_get_f64+0x140>
1007bcce4:     	tst	x20, #0xffff800000000000
1007bcce8:     	mov	w8, #0x1000             ; =4096
1007bccec:     	ccmp	x20, x8, #0x0, eq
1007bccf0:     	b.lo	0x1007bcd90 <_js_array_get_f64+0x140>
1007bccf4:     	ldurb	w24, [x20, #-0x8]
1007bccf8:     	ldurh	w23, [x20, #-0x6]
1007bccfc:     	cmp	w24, #0xa
1007bcd00:     	b.gt	0x1007bcea8 <_js_array_get_f64+0x258>
1007bcd04:     	cmp	w24, #0x2
1007bcd08:     	b.eq	0x1007bcf30 <_js_array_get_f64+0x2e0>
1007bcd0c:     	cmp	w24, #0x8
1007bcd10:     	b.ne	0x1007bcd98 <_js_array_get_f64+0x148>
1007bcd14:     	mov	x0, x20
1007bcd18:     	bl	0x100304028 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007bcd1c:     	cbz	w0, 0x1007bcfc0 <_js_array_get_f64+0x370>
1007bcd20:     	mov	x22, #0x1               ; =1
1007bcd24:     	movk	x22, #0x7ffc, lsl #48
1007bcd28:     	lsr	x8, x20, #51
1007bcd2c:     	cmp	x8, #0xfff
1007bcd30:     	b.lo	0x1007bcd44 <_js_array_get_f64+0xf4>
1007bcd34:     	mov	w8, #0x7ffc             ; =32764
1007bcd38:     	cmp	x8, x20, lsr #48
1007bcd3c:     	b.eq	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bcd40:     	and	x20, x20, #0xffffffffffff
1007bcd44:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bcd48:     	b.lo	0x1007bcd68 <_js_array_get_f64+0x118>
1007bcd4c:     	tst	x20, #0xffff800000000000
1007bcd50:     	mov	w8, #0x1000             ; =4096
1007bcd54:     	ccmp	x20, x8, #0x0, eq
1007bcd58:     	b.lo	0x1007bcd68 <_js_array_get_f64+0x118>
1007bcd5c:     	ldurb	w8, [x20, #-0x8]
1007bcd60:     	cmp	w8, #0x2
1007bcd64:     	b.eq	0x1007bd634 <_js_array_get_f64+0x9e4>
1007bcd68:     	cbz	x20, 0x1007bd348 <_js_array_get_f64+0x6f8>
1007bcd6c:     	mov	x0, x20
1007bcd70:     	mov	x1, x19
1007bcd74:     	bl	0x1003041d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007bcd78:     	cmp	w0, #0x1
1007bcd7c:     	b.ne	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bcd80:     	ldr	x8, [x20, #0x8]
1007bcd84:     	ubfiz	x9, x1, #4, #32
1007bcd88:     	ldr	x22, [x8, x9]
1007bcd8c:     	b	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bcd90:     	mov	w23, #0x0               ; =0
1007bcd94:     	mov	w24, #0x0               ; =0
1007bcd98:     	mov	x21, x22
1007bcd9c:     	cmp	x25, #0xfff
1007bcda0:     	b.lo	0x1007bcdb8 <_js_array_get_f64+0x168>
1007bcda4:     	mov	w8, #0x7ffc             ; =32764
1007bcda8:     	cmp	x8, x22, lsr #48
1007bcdac:     	b.eq	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bcdb0:     	ands	x21, x22, #0xffffffffffff
1007bcdb4:     	b.eq	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bcdb8:     	and	x8, x21, #0xfffffffffff00000
1007bcdbc:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007bcdc0:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007bcdc4:     	cmp	x9, x10
1007bcdc8:     	ccmp	x8, #0x0, #0x4, lo
1007bcdcc:     	b.eq	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bcdd0:     	tst	x21, #0x3
1007bcdd4:     	ccmp	x21, #0x7, #0x0, eq
1007bcdd8:     	b.ls	0x1007bd088 <_js_array_get_f64+0x438>
1007bcddc:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bcde0:     	ldr	x8, [x8, #0x30]
1007bcde4:     	cmn	x8, #0x1
1007bcde8:     	b.eq	0x1007bcfd8 <_js_array_get_f64+0x388>
1007bcdec:     	mrs	x9, TPIDRRO_EL0
1007bcdf0:     	and	x9, x9, #0xfffffffffffffff8
1007bcdf4:     	ldr	x0, [x9, x8, lsl #3]
1007bcdf8:     	cbz	x0, 0x1007bcfd8 <_js_array_get_f64+0x388>
1007bcdfc:     	lsr	x1, x21, #20
1007bce00:     	ldr	x8, [x0, #0x10]
1007bce04:     	ldrb	w9, [x8]
1007bce08:     	cmp	w9, #0x2
1007bce0c:     	b.ne	0x1007bcff0 <_js_array_get_f64+0x3a0>
1007bce10:     	ldrb	w9, [x8, #0x88]
1007bce14:     	tbz	w9, #0x0, 0x1007bce34 <_js_array_get_f64+0x1e4>
1007bce18:     	ldr	x9, [x8, #0x80]
1007bce1c:     	cmp	x9, x1
1007bce20:     	b.ne	0x1007bce34 <_js_array_get_f64+0x1e4>
1007bce24:     	ldp	x9, x10, [x8, #0x60]
1007bce28:     	cmp	x9, x21
1007bce2c:     	ccmp	x10, x21, #0x0, ls
1007bce30:     	b.hi	0x1007bcfd0 <_js_array_get_f64+0x380>
1007bce34:     	ldrb	w9, [x8, #0xb8]
1007bce38:     	cbz	w9, 0x1007bce58 <_js_array_get_f64+0x208>
1007bce3c:     	ldr	x9, [x8, #0xb0]
1007bce40:     	cmp	x9, x1
1007bce44:     	b.ne	0x1007bce58 <_js_array_get_f64+0x208>
1007bce48:     	ldp	x9, x10, [x8, #0x90]
1007bce4c:     	cmp	x9, x21
1007bce50:     	ccmp	x10, x21, #0x0, ls
1007bce54:     	b.hi	0x1007bd498 <_js_array_get_f64+0x848>
1007bce58:     	ldrb	w9, [x8, #0xe8]
1007bce5c:     	cbz	w9, 0x1007bce7c <_js_array_get_f64+0x22c>
1007bce60:     	ldr	x9, [x8, #0xe0]
1007bce64:     	cmp	x9, x1
1007bce68:     	b.ne	0x1007bce7c <_js_array_get_f64+0x22c>
1007bce6c:     	ldp	x9, x10, [x8, #0xc0]
1007bce70:     	cmp	x9, x21
1007bce74:     	ccmp	x10, x21, #0x0, ls
1007bce78:     	b.hi	0x1007bd580 <_js_array_get_f64+0x930>
1007bce7c:     	ldrb	w9, [x8, #0x118]
1007bce80:     	cbz	w9, 0x1007bd050 <_js_array_get_f64+0x400>
1007bce84:     	ldr	x9, [x8, #0x110]
1007bce88:     	cmp	x9, x1
1007bce8c:     	b.ne	0x1007bd050 <_js_array_get_f64+0x400>
1007bce90:     	ldp	x9, x10, [x8, #0xf0]
1007bce94:     	cmp	x9, x21
1007bce98:     	ccmp	x10, x21, #0x0, ls
1007bce9c:     	b.ls	0x1007bd050 <_js_array_get_f64+0x400>
1007bcea0:     	add	x9, x8, #0xf0
1007bcea4:     	b	0x1007bd584 <_js_array_get_f64+0x934>
1007bcea8:     	cmp	w24, #0xb
1007bceac:     	b.eq	0x1007bcf48 <_js_array_get_f64+0x2f8>
1007bceb0:     	cmp	w24, #0xc
1007bceb4:     	b.ne	0x1007bcd98 <_js_array_get_f64+0x148>
1007bceb8:     	mov	x0, x20
1007bcebc:     	bl	0x100309db8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007bcec0:     	cbz	w0, 0x1007bcfc8 <_js_array_get_f64+0x378>
1007bcec4:     	mov	x22, #0x1               ; =1
1007bcec8:     	movk	x22, #0x7ffc, lsl #48
1007bcecc:     	lsr	x8, x20, #51
1007bced0:     	cmp	x8, #0xfff
1007bced4:     	b.lo	0x1007bcee8 <_js_array_get_f64+0x298>
1007bced8:     	mov	w8, #0x7ffc             ; =32764
1007bcedc:     	cmp	x8, x20, lsr #48
1007bcee0:     	b.eq	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bcee4:     	and	x20, x20, #0xffffffffffff
1007bcee8:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bceec:     	b.lo	0x1007bcf0c <_js_array_get_f64+0x2bc>
1007bcef0:     	tst	x20, #0xffff800000000000
1007bcef4:     	mov	w8, #0x1000             ; =4096
1007bcef8:     	ccmp	x20, x8, #0x0, eq
1007bcefc:     	b.lo	0x1007bcf0c <_js_array_get_f64+0x2bc>
1007bcf00:     	ldurb	w8, [x20, #-0x8]
1007bcf04:     	cmp	w8, #0x2
1007bcf08:     	b.eq	0x1007bd64c <_js_array_get_f64+0x9fc>
1007bcf0c:     	cbz	x20, 0x1007bd348 <_js_array_get_f64+0x6f8>
1007bcf10:     	mov	x0, x20
1007bcf14:     	mov	x1, x19
1007bcf18:     	bl	0x10030ba30 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007bcf1c:     	cmp	w0, #0x1
1007bcf20:     	b.ne	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bcf24:     	ldr	x8, [x20, #0x8]
1007bcf28:     	ldr	x22, [x8, w1, uxtw #3]
1007bcf2c:     	b	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bcf30:     	mov	x0, x22
1007bcf34:     	mov	x1, x19
1007bcf38:     	bl	0x10054748c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bcf3c:     	tbnz	w0, #0x0, 0x1007bd344 <_js_array_get_f64+0x6f4>
1007bcf40:     	mov	w24, #0x2               ; =2
1007bcf44:     	b	0x1007bcd98 <_js_array_get_f64+0x148>
1007bcf48:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bcf4c:     	add	x8, x8, #0xe80
1007bcf50:     	ldaprb	w8, [x8]
1007bcf54:     	cbz	w8, 0x1007bcfb8 <_js_array_get_f64+0x368>
1007bcf58:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bcf5c:     	add	x8, x8, #0x40
1007bcf60:     	ldapr	x8, [x8]
1007bcf64:     	cmp	x20, x8
1007bcf68:     	b.lo	0x1007bcfb8 <_js_array_get_f64+0x368>
1007bcf6c:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bcf70:     	add	x8, x8, #0x48
1007bcf74:     	ldapr	x8, [x8]
1007bcf78:     	cmp	x20, x8
1007bcf7c:     	b.hi	0x1007bcfb8 <_js_array_get_f64+0x368>
1007bcf80:     	mov	x0, x20
1007bcf84:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bcf88:     	tbz	w0, #0x0, 0x1007bcfb8 <_js_array_get_f64+0x368>
1007bcf8c:     	add	x0, sp, #0x8
1007bcf90:     	mov	x1, x20
1007bcf94:     	bl	0x1002a392c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007bcf98:     	ldr	x8, [sp, #0x8]
1007bcf9c:     	cbz	x8, 0x1007bd5c4 <_js_array_get_f64+0x974>
1007bcfa0:     	cmp	x8, #0x1
1007bcfa4:     	b.ne	0x1007bd608 <_js_array_get_f64+0x9b8>
1007bcfa8:     	ldr	d0, [sp, #0x10]
1007bcfac:     	scvtf	d1, w19
1007bcfb0:     	bl	0x10081b1f4 <_js_dyn_index_get>
1007bcfb4:     	b	0x1007bd344 <_js_array_get_f64+0x6f4>
1007bcfb8:     	mov	w24, #0xb               ; =11
1007bcfbc:     	b	0x1007bcd98 <_js_array_get_f64+0x148>
1007bcfc0:     	mov	w24, #0x8               ; =8
1007bcfc4:     	b	0x1007bcd98 <_js_array_get_f64+0x148>
1007bcfc8:     	mov	w24, #0xc               ; =12
1007bcfcc:     	b	0x1007bcd98 <_js_array_get_f64+0x148>
1007bcfd0:     	add	x9, x8, #0x60
1007bcfd4:     	b	0x1007bd584 <_js_array_get_f64+0x934>
1007bcfd8:     	bl	0x100b3de7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007bcfdc:     	lsr	x1, x21, #20
1007bcfe0:     	ldr	x8, [x0, #0x10]
1007bcfe4:     	ldrb	w9, [x8]
1007bcfe8:     	cmp	w9, #0x2
1007bcfec:     	b.eq	0x1007bce10 <_js_array_get_f64+0x1c0>
1007bcff0:     	ldr	x9, [x8, #0x8]
1007bcff4:     	ldr	x10, [x8, #0x28]
1007bcff8:     	sub	x9, x1, x9
1007bcffc:     	cmp	x9, x10
1007bd000:     	b.hs	0x1007bd044 <_js_array_get_f64+0x3f4>
1007bd004:     	ldr	x10, [x8, #0x20]
1007bd008:     	mov	w11, #0x28              ; =40
1007bd00c:     	madd	x9, x9, x11, x10
1007bd010:     	ldr	x10, [x9]
1007bd014:     	ldr	x11, [x8, #0x10]
1007bd018:     	cmp	x10, x11
1007bd01c:     	b.ne	0x1007bd050 <_js_array_get_f64+0x400>
1007bd020:     	ldp	x10, x11, [x9, #0x8]
1007bd024:     	cmp	x10, x21
1007bd028:     	ccmp	x11, x21, #0x0, ls
1007bd02c:     	b.ls	0x1007bd050 <_js_array_get_f64+0x400>
1007bd030:     	ldr	x10, [x8, #0x30]
1007bd034:     	add	x10, x10, #0x1
1007bd038:     	str	x10, [x8, #0x30]
1007bd03c:     	add	x8, x9, #0x21
1007bd040:     	b	0x1007bd594 <_js_array_get_f64+0x944>
1007bd044:     	ldr	x9, [x8, #0x58]
1007bd048:     	add	x9, x9, #0x1
1007bd04c:     	str	x9, [x8, #0x58]
1007bd050:     	ldr	x9, [x8, #0x38]
1007bd054:     	add	x9, x9, #0x1
1007bd058:     	str	x9, [x8, #0x38]
1007bd05c:     	mov	x0, x21
1007bd060:     	bl	0x10051d1c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007bd064:     	and	w8, w0, #0xff
1007bd068:     	cbz	w8, 0x1007bd088 <_js_array_get_f64+0x438>
1007bd06c:     	ldurb	w8, [x21, #-0x8]
1007bd070:     	ldurb	w9, [x21, #-0x7]
1007bd074:     	mov	w10, #0x82              ; =130
1007bd078:     	and	w9, w9, w10
1007bd07c:     	cmp	w9, #0x2
1007bd080:     	ccmp	w8, #0x1, #0x0, eq
1007bd084:     	b.eq	0x1007bd158 <_js_array_get_f64+0x508>
1007bd088:     	mov	x0, x21
1007bd08c:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd090:     	cbz	x0, 0x1007bd0b8 <_js_array_get_f64+0x468>
1007bd094:     	ldrb	w9, [x0]
1007bd098:     	cmp	w9, #0x1
1007bd09c:     	b.ne	0x1007bd0d4 <_js_array_get_f64+0x484>
1007bd0a0:     	ldrsb	w8, [x0, #0x1]
1007bd0a4:     	tbnz	w8, #0x1f, 0x1007bd180 <_js_array_get_f64+0x530>
1007bd0a8:     	ldp	w10, w9, [x21]
1007bd0ac:     	cmp	w10, w9
1007bd0b0:     	b.hi	0x1007bd20c <_js_array_get_f64+0x5bc>
1007bd0b4:     	b	0x1007bd224 <_js_array_get_f64+0x5d4>
1007bd0b8:     	mov	x25, x0
1007bd0bc:     	mov	x0, x21
1007bd0c0:     	bl	0x100588074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd0c4:     	tbz	w0, #0x0, 0x1007bd110 <_js_array_get_f64+0x4c0>
1007bd0c8:     	mov	x0, #0x0                ; =0
1007bd0cc:     	mov	x8, x25
1007bd0d0:     	b	0x1007bd1fc <_js_array_get_f64+0x5ac>
1007bd0d4:     	mov	x8, x0
1007bd0d8:     	cmp	w9, #0x1
1007bd0dc:     	b.eq	0x1007bd1fc <_js_array_get_f64+0x5ac>
1007bd0e0:     	cmp	w9, #0x9
1007bd0e4:     	b.ne	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd0e8:     	ldr	w8, [x21, #0x4]
1007bd0ec:     	mov	w9, #0x5841             ; =22593
1007bd0f0:     	movk	w9, #0x4c5a, lsl #16
1007bd0f4:     	cmp	w8, w9
1007bd0f8:     	b.ne	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd0fc:     	mov	x0, x21
1007bd100:     	bl	0x100374830 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007bd104:     	cbz	x0, 0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd108:     	mov	x21, x0
1007bd10c:     	b	0x1007bd240 <_js_array_get_f64+0x5f0>
1007bd110:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd114:     	add	x8, x8, #0xe80
1007bd118:     	ldaprb	w8, [x8]
1007bd11c:     	cbz	w8, 0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd120:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd124:     	add	x8, x8, #0x40
1007bd128:     	ldapr	x8, [x8]
1007bd12c:     	cmp	x8, x21
1007bd130:     	b.hi	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd134:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd138:     	add	x8, x8, #0x48
1007bd13c:     	ldapr	x8, [x8]
1007bd140:     	cmp	x8, x21
1007bd144:     	b.lo	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd148:     	mov	x0, x21
1007bd14c:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd150:     	tbnz	w0, #0x0, 0x1007bd0c8 <_js_array_get_f64+0x478>
1007bd154:     	b	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd158:     	ldr	w8, [x21]
1007bd15c:     	mov	w9, #0xe100             ; =57600
1007bd160:     	movk	w9, #0x5f5, lsl #16
1007bd164:     	orr	w9, w9, #0x1
1007bd168:     	cmp	w8, w9
1007bd16c:     	b.hs	0x1007bd088 <_js_array_get_f64+0x438>
1007bd170:     	ldr	w9, [x21, #0x4]
1007bd174:     	cmp	w8, w9
1007bd178:     	b.ls	0x1007bd240 <_js_array_get_f64+0x5f0>
1007bd17c:     	b	0x1007bd088 <_js_array_get_f64+0x438>
1007bd180:     	mov	x25, x0
1007bd184:     	ldr	x21, [x0, #0x8]
1007bd188:     	mov	x0, x21
1007bd18c:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd190:     	cbz	x0, 0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd194:     	ldrb	w8, [x0]
1007bd198:     	cmp	w8, #0x1
1007bd19c:     	b.ne	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd1a0:     	ldrsb	w8, [x0, #0x1]
1007bd1a4:     	tbz	w8, #0x1f, 0x1007bd0a8 <_js_array_get_f64+0x458>
1007bd1a8:     	mov	w26, #0x1               ; =1
1007bd1ac:     	ldr	x21, [x0, #0x8]
1007bd1b0:     	mov	x0, x21
1007bd1b4:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd1b8:     	cbz	x0, 0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd1bc:     	ldrb	w8, [x0]
1007bd1c0:     	cmp	w8, #0x1
1007bd1c4:     	b.ne	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd1c8:     	cmp	w26, #0x3f
1007bd1cc:     	b.hi	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd1d0:     	add	w26, w26, #0x1
1007bd1d4:     	ldrsb	w8, [x0, #0x1]
1007bd1d8:     	tbnz	w8, #0x1f, 0x1007bd1ac <_js_array_get_f64+0x55c>
1007bd1dc:     	str	x21, [x25, #0x8]
1007bd1e0:     	ldrb	w8, [x25, #0x1]
1007bd1e4:     	orr	w9, w8, #0x80
1007bd1e8:     	mov	x8, x25
1007bd1ec:     	strb	w9, [x25, #0x1]
1007bd1f0:     	ldrb	w9, [x0]
1007bd1f4:     	cmp	w9, #0x1
1007bd1f8:     	b.ne	0x1007bd0e0 <_js_array_get_f64+0x490>
1007bd1fc:     	ldp	w10, w9, [x21]
1007bd200:     	cmp	w10, w9
1007bd204:     	b.ls	0x1007bd224 <_js_array_get_f64+0x5d4>
1007bd208:     	cbz	x8, 0x1007bd234 <_js_array_get_f64+0x5e4>
1007bd20c:     	ldr	w8, [x0, #0x4]
1007bd210:     	ubfiz	x9, x9, #3, #32
1007bd214:     	add	x9, x9, #0x10
1007bd218:     	cmp	x9, x8
1007bd21c:     	b.eq	0x1007bd240 <_js_array_get_f64+0x5f0>
1007bd220:     	b	0x1007bd234 <_js_array_get_f64+0x5e4>
1007bd224:     	mov	w8, #0xe100             ; =57600
1007bd228:     	movk	w8, #0x5f5, lsl #16
1007bd22c:     	cmp	w10, w8
1007bd230:     	b.ls	0x1007bd240 <_js_array_get_f64+0x5f0>
1007bd234:     	mov	x0, x21
1007bd238:     	bl	0x100588074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd23c:     	tbz	w0, #0x0, 0x1007bd2f0 <_js_array_get_f64+0x6a0>
1007bd240:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd244:     	add	x8, x8, #0xe80
1007bd248:     	ldaprb	w8, [x8]
1007bd24c:     	cbz	w8, 0x1007bd294 <_js_array_get_f64+0x644>
1007bd250:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd254:     	add	x8, x8, #0x40
1007bd258:     	ldapr	x8, [x8]
1007bd25c:     	cmp	x21, x8
1007bd260:     	b.lo	0x1007bd294 <_js_array_get_f64+0x644>
1007bd264:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd268:     	add	x8, x8, #0x48
1007bd26c:     	ldapr	x8, [x8]
1007bd270:     	cmp	x21, x8
1007bd274:     	b.hi	0x1007bd294 <_js_array_get_f64+0x644>
1007bd278:     	mov	x0, x21
1007bd27c:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd280:     	tbz	w0, #0x0, 0x1007bd294 <_js_array_get_f64+0x644>
1007bd284:     	mov	x0, x21
1007bd288:     	mov	x1, x19
1007bd28c:     	bl	0x1008faf48 <_js_typed_array_get>
1007bd290:     	b	0x1007bd344 <_js_array_get_f64+0x6f4>
1007bd294:     	mov	x0, x21
1007bd298:     	bl	0x100588074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd29c:     	tbz	w0, #0x0, 0x1007bd2c4 <_js_array_get_f64+0x674>
1007bd2a0:     	mov	x0, x21
1007bd2a4:     	mov	x1, x19
1007bd2a8:     	bl	0x10058539c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007bd2ac:     	and	w8, w1, #0xff
1007bd2b0:     	ucvtf	d0, w8
1007bd2b4:     	fmov	x8, d0
1007bd2b8:     	tst	w0, #0x1
1007bd2bc:     	csel	x22, x8, xzr, ne
1007bd2c0:     	b	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bd2c4:     	cmp	x21, x20
1007bd2c8:     	b.eq	0x1007bd370 <_js_array_get_f64+0x720>
1007bd2cc:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007bd2d0:     	b.lo	0x1007bd368 <_js_array_get_f64+0x718>
1007bd2d4:     	tst	x21, #0xffff800000000000
1007bd2d8:     	mov	w8, #0x1000             ; =4096
1007bd2dc:     	ccmp	x21, x8, #0x0, eq
1007bd2e0:     	b.lo	0x1007bd368 <_js_array_get_f64+0x718>
1007bd2e4:     	ldurb	w24, [x21, #-0x8]
1007bd2e8:     	ldurh	w23, [x21, #-0x6]
1007bd2ec:     	b	0x1007bd370 <_js_array_get_f64+0x720>
1007bd2f0:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd2f4:     	add	x8, x8, #0xe80
1007bd2f8:     	ldaprb	w8, [x8]
1007bd2fc:     	cbz	w8, 0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd300:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd304:     	add	x8, x8, #0x40
1007bd308:     	ldapr	x8, [x8]
1007bd30c:     	cmp	x21, x8
1007bd310:     	b.lo	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd314:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd318:     	add	x8, x8, #0x48
1007bd31c:     	ldapr	x8, [x8]
1007bd320:     	cmp	x21, x8
1007bd324:     	b.hi	0x1007bd334 <_js_array_get_f64+0x6e4>
1007bd328:     	mov	x0, x21
1007bd32c:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd330:     	tbnz	w0, #0x0, 0x1007bd240 <_js_array_get_f64+0x5f0>
1007bd334:     	mov	x0, x22
1007bd338:     	mov	x1, x19
1007bd33c:     	bl	0x10054748c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bd340:     	tbz	w0, #0x0, 0x1007bd618 <_js_array_get_f64+0x9c8>
1007bd344:     	fmov	x22, d0
1007bd348:     	fmov	d0, x22
1007bd34c:     	ldp	x29, x30, [sp, #0x60]
1007bd350:     	ldp	x20, x19, [sp, #0x50]
1007bd354:     	ldp	x22, x21, [sp, #0x40]
1007bd358:     	ldp	x24, x23, [sp, #0x30]
1007bd35c:     	ldp	x26, x25, [sp, #0x20]
1007bd360:     	add	sp, sp, #0x70
1007bd364:     	ret
1007bd368:     	mov	w23, #0x0               ; =0
1007bd36c:     	mov	w24, #0x0               ; =0
1007bd370:     	cmp	w24, #0x1
1007bd374:     	b.ne	0x1007bd528 <_js_array_get_f64+0x8d8>
1007bd378:     	tbz	w23, #0xa, 0x1007bd528 <_js_array_get_f64+0x8d8>
1007bd37c:     	adrp	x8, 0x100b63000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data28default_ignorable_code_point7OFFSETS+0x3>
1007bd380:     	add	x8, x8, #0x88c
1007bd384:     	cmp	w19, #0x3e8
1007bd388:     	b.lo	0x1007bd400 <_js_array_get_f64+0x7b0>
1007bd38c:     	mov	x9, #0x0                ; =0
1007bd390:     	mov	w11, #0x1759            ; =5977
1007bd394:     	movk	w11, #0xd1b7, lsl #16
1007bd398:     	mov	w12, #0x2710            ; =10000
1007bd39c:     	mov	w13, #0x147b            ; =5243
1007bd3a0:     	mov	w14, #0x64              ; =100
1007bd3a4:     	add	x15, sp, #0x8
1007bd3a8:     	mov	w16, #0x967f            ; =38527
1007bd3ac:     	movk	w16, #0x98, lsl #16
1007bd3b0:     	mov	x10, x19
1007bd3b4:     	mov	x17, x10
1007bd3b8:     	umull	x10, w10, w11
1007bd3bc:     	lsr	x10, x10, #45
1007bd3c0:     	msub	w0, w10, w12, w17
1007bd3c4:     	ubfx	w1, w0, #2, #14
1007bd3c8:     	mul	w1, w1, w13
1007bd3cc:     	lsr	w1, w1, #17
1007bd3d0:     	msub	w0, w1, w14, w0
1007bd3d4:     	add	x2, x15, x9
1007bd3d8:     	ldrh	w1, [x8, w1, uxtw #1]
1007bd3dc:     	strh	w1, [x2, #0x6]
1007bd3e0:     	and	x0, x0, #0xffff
1007bd3e4:     	ldrh	w0, [x8, x0, lsl #1]
1007bd3e8:     	strh	w0, [x2, #0x8]
1007bd3ec:     	sub	x9, x9, #0x4
1007bd3f0:     	cmp	w17, w16
1007bd3f4:     	b.hi	0x1007bd3b4 <_js_array_get_f64+0x764>
1007bd3f8:     	add	x9, x9, #0xa
1007bd3fc:     	b	0x1007bd408 <_js_array_get_f64+0x7b8>
1007bd400:     	mov	w9, #0xa                ; =10
1007bd404:     	mov	x10, x19
1007bd408:     	cmp	w10, #0x9
1007bd40c:     	b.ls	0x1007bd440 <_js_array_get_f64+0x7f0>
1007bd410:     	sub	x9, x9, #0x2
1007bd414:     	ubfx	w11, w10, #2, #14
1007bd418:     	mov	w12, #0x147b            ; =5243
1007bd41c:     	mul	w11, w11, w12
1007bd420:     	lsr	w11, w11, #17
1007bd424:     	mov	w12, #0x64              ; =100
1007bd428:     	msub	w10, w11, w12, w10
1007bd42c:     	and	x10, x10, #0xffff
1007bd430:     	ldrh	w10, [x8, x10, lsl #1]
1007bd434:     	add	x12, sp, #0x8
1007bd438:     	strh	w10, [x12, x9]
1007bd43c:     	mov	x10, x11
1007bd440:     	cbz	w19, 0x1007bd478 <_js_array_get_f64+0x828>
1007bd444:     	cbnz	w10, 0x1007bd478 <_js_array_get_f64+0x828>
1007bd448:     	cmp	x9, #0xa
1007bd44c:     	b.ne	0x1007bd4a0 <_js_array_get_f64+0x850>
1007bd450:     	mov	w23, #0x1               ; =1
1007bd454:     	add	x0, sp, #0x8
1007bd458:     	mov	x1, x21
1007bd45c:     	mov	w2, #0x1                ; =1
1007bd460:     	mov	x3, #0x0                ; =0
1007bd464:     	bl	0x1005b177c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bd468:     	ldr	x8, [sp, #0x8]
1007bd46c:     	mov	w20, #0x1               ; =1
1007bd470:     	cbnz	x8, 0x1007bd4f0 <_js_array_get_f64+0x8a0>
1007bd474:     	b	0x1007bd528 <_js_array_get_f64+0x8d8>
1007bd478:     	sub	x23, x9, #0x1
1007bd47c:     	ubfiz	w10, w10, #1, #4
1007bd480:     	add	x8, x8, x10
1007bd484:     	ldrb	w8, [x8, #0x1]
1007bd488:     	add	x10, sp, #0x8
1007bd48c:     	strb	w8, [x10, x23]
1007bd490:     	mov	w8, #0xb                ; =11
1007bd494:     	b	0x1007bd4a8 <_js_array_get_f64+0x858>
1007bd498:     	add	x9, x8, #0x90
1007bd49c:     	b	0x1007bd584 <_js_array_get_f64+0x934>
1007bd4a0:     	mov	w8, #0xa                ; =10
1007bd4a4:     	mov	x23, x9
1007bd4a8:     	sub	x22, x8, x9
1007bd4ac:     	mov	x0, x22
1007bd4b0:     	mov	w1, #0x1                ; =1
1007bd4b4:     	bl	0x100b5dcc8 <_mi_malloc_aligned>
1007bd4b8:     	cbz	x0, 0x1007bd664 <_js_array_get_f64+0xa14>
1007bd4bc:     	mov	x20, x0
1007bd4c0:     	add	x8, sp, #0x8
1007bd4c4:     	add	x1, x8, x23
1007bd4c8:     	mov	x2, x22
1007bd4cc:     	bl	0x100b608ec <_writev+0x100b608ec>
1007bd4d0:     	add	x0, sp, #0x8
1007bd4d4:     	mov	x1, x21
1007bd4d8:     	mov	x2, x20
1007bd4dc:     	mov	x3, x22
1007bd4e0:     	bl	0x1005b177c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bd4e4:     	ldr	w8, [sp, #0x8]
1007bd4e8:     	tbz	w8, #0x0, 0x1007bd520 <_js_array_get_f64+0x8d0>
1007bd4ec:     	mov	w23, #0x0               ; =0
1007bd4f0:     	mov	x22, #0x1               ; =1
1007bd4f4:     	movk	x22, #0x7ffc, lsl #48
1007bd4f8:     	ldr	x0, [sp, #0x10]
1007bd4fc:     	cbz	x0, 0x1007bd5b4 <_js_array_get_f64+0x964>
1007bd500:     	cbz	x21, 0x1007bd5a4 <_js_array_get_f64+0x954>
1007bd504:     	lsr	x8, x21, #52
1007bd508:     	cmp	x8, #0x7fe
1007bd50c:     	b.hi	0x1007bd5a8 <_js_array_get_f64+0x958>
1007bd510:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007bd514:     	bfxil	x8, x21, #0, #48
1007bd518:     	mov	x21, x8
1007bd51c:     	b	0x1007bd5a8 <_js_array_get_f64+0x958>
1007bd520:     	mov	x0, x20
1007bd524:     	bl	0x100b5da40 <_mi_free>
1007bd528:     	ldr	w8, [x21]
1007bd52c:     	cmp	w19, w8
1007bd530:     	b.hs	0x1007bd570 <_js_array_get_f64+0x920>
1007bd534:     	ldr	w8, [x21, #0x4]
1007bd538:     	cmp	w19, w8
1007bd53c:     	b.hs	0x1007bd560 <_js_array_get_f64+0x910>
1007bd540:     	add	x8, x21, w19, uxtw #3
1007bd544:     	ldr	x22, [x8, #0x8]
1007bd548:     	mov	x8, #0x1                ; =1
1007bd54c:     	movk	x8, #0x7ffc, lsl #48
1007bd550:     	add	x8, x8, #0xf
1007bd554:     	cmp	x22, x8
1007bd558:     	b.ne	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bd55c:     	b	0x1007bd570 <_js_array_get_f64+0x920>
1007bd560:     	mov	x0, x21
1007bd564:     	mov	x1, x19
1007bd568:     	bl	0x100529884 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007bd56c:     	tbnz	w0, #0x0, 0x1007bd344 <_js_array_get_f64+0x6f4>
1007bd570:     	mov	x0, x21
1007bd574:     	mov	x1, x19
1007bd578:     	bl	0x1006c6098 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007bd57c:     	b	0x1007bd344 <_js_array_get_f64+0x6f4>
1007bd580:     	add	x9, x8, #0xc0
1007bd584:     	ldr	x10, [x8, #0x30]
1007bd588:     	add	x10, x10, #0x1
1007bd58c:     	str	x10, [x8, #0x30]
1007bd590:     	add	x8, x9, #0x19
1007bd594:     	ldrb	w8, [x8]
1007bd598:     	cmp	w8, #0xff
1007bd59c:     	b.ne	0x1007bd068 <_js_array_get_f64+0x418>
1007bd5a0:     	b	0x1007bd05c <_js_array_get_f64+0x40c>
1007bd5a4:     	add	x21, x22, #0x1
1007bd5a8:     	fmov	d0, x21
1007bd5ac:     	bl	0x1006fbebc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007bd5b0:     	mov	x22, x0
1007bd5b4:     	tbnz	w23, #0x0, 0x1007bd348 <_js_array_get_f64+0x6f8>
1007bd5b8:     	mov	x0, x20
1007bd5bc:     	bl	0x100b5da40 <_mi_free>
1007bd5c0:     	b	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bd5c4:     	ldr	x20, [sp, #0x10]
1007bd5c8:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd5cc:     	ldr	x8, [x8, #0xe98]
1007bd5d0:     	cbz	x8, 0x1007bd5e8 <_js_array_get_f64+0x998>
1007bd5d4:     	mov	x0, x20
1007bd5d8:     	bl	0x10013bbc0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007bd5dc:     	tbz	w0, #0x0, 0x1007bd5e8 <_js_array_get_f64+0x998>
1007bd5e0:     	mov	x0, x20
1007bd5e4:     	bl	0x1002bdd00 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007bd5e8:     	tbnz	w19, #0x1f, 0x1007bd608 <_js_array_get_f64+0x9b8>
1007bd5ec:     	ldr	w8, [x20]
1007bd5f0:     	cmp	w19, w8
1007bd5f4:     	b.hs	0x1007bd608 <_js_array_get_f64+0x9b8>
1007bd5f8:     	mov	w1, w19
1007bd5fc:     	mov	x0, x20
1007bd600:     	bl	0x1002a3f8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007bd604:     	b	0x1007bd344 <_js_array_get_f64+0x6f4>
1007bd608:     	mov	x8, #0x1                ; =1
1007bd60c:     	movk	x8, #0x7ffc, lsl #48
1007bd610:     	mov	x22, x8
1007bd614:     	b	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bd618:     	mov	x0, x22
1007bd61c:     	bl	0x100b463b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007bd620:     	cmp	x0, #0x1
1007bd624:     	b.ne	0x1007bcc90 <_js_array_get_f64+0x40>
1007bd628:     	mov	x0, x19
1007bd62c:     	bl	0x100b463d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007bd630:     	b	0x1007bd344 <_js_array_get_f64+0x6f4>
1007bd634:     	mov	x0, x20
1007bd638:     	mov	w1, #0x0                ; =0
1007bd63c:     	bl	0x100b48940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bd640:     	mov	x20, x0
1007bd644:     	cbnz	x0, 0x1007bcd6c <_js_array_get_f64+0x11c>
1007bd648:     	b	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bd64c:     	mov	x0, x20
1007bd650:     	mov	w1, #0x1                ; =1
1007bd654:     	bl	0x100b48940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bd658:     	mov	x20, x0
1007bd65c:     	cbnz	x0, 0x1007bcf10 <_js_array_get_f64+0x2c0>
1007bd660:     	b	0x1007bd348 <_js_array_get_f64+0x6f8>
1007bd664:     	mov	w0, #0x1                ; =1
1007bd668:     	mov	x1, x22
1007bd66c:     	bl	0x100b10e00 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
