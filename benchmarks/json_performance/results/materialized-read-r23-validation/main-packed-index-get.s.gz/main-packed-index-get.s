
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/main-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010089c1a0 <_js_packed_arraylike_index_get>:
10089c1a0:     	sub	sp, sp, #0x90
10089c1a4:     	stp	d9, d8, [sp, #0x20]
10089c1a8:     	stp	x28, x27, [sp, #0x30]
10089c1ac:     	stp	x26, x25, [sp, #0x40]
10089c1b0:     	stp	x24, x23, [sp, #0x50]
10089c1b4:     	stp	x22, x21, [sp, #0x60]
10089c1b8:     	stp	x20, x19, [sp, #0x70]
10089c1bc:     	stp	x29, x30, [sp, #0x80]
10089c1c0:     	add	x29, sp, #0x80
10089c1c4:     	fmov	x1, d1
10089c1c8:     	mov	w8, #0x7ffe0000         ; =2147352576
10089c1cc:     	cmp	x8, x1, lsr #32
10089c1d0:     	b.ne	0x10089c1ec <_js_packed_arraylike_index_get+0x4c>
10089c1d4:     	tbnz	w1, #0x1f, 0x10089c470 <_js_packed_arraylike_index_get+0x2d0>
10089c1d8:     	fmov	x8, d0
10089c1dc:     	mov	w9, #0x7ffd             ; =32765
10089c1e0:     	cmp	x9, x8, lsr #48
10089c1e4:     	b.eq	0x10089c274 <_js_packed_arraylike_index_get+0xd4>
10089c1e8:     	b	0x10089c470 <_js_packed_arraylike_index_get+0x2d0>
10089c1ec:     	and	x8, x1, #0xffff000000000000
10089c1f0:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10089c1f4:     	cmp	x1, x9
10089c1f8:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10089c1fc:     	ccmp	x8, x9, #0x2, hs
10089c200:     	cset	w8, hi
10089c204:     	fmov	x9, d1
10089c208:     	ands	x10, x9, #0x7fffffffffffffff
10089c20c:     	cset	w11, eq
10089c210:     	sub	x12, x9, #0x1
10089c214:     	mov	x13, #0xfffffffffffff   ; =4503599627370495
10089c218:     	cmp	x12, x13
10089c21c:     	csinc	w11, w11, wzr, hs
10089c220:     	mov	x12, #-0x10000000000000 ; =-4503599627370496
10089c224:     	add	x10, x10, x12
10089c228:     	lsr	x10, x10, #53
10089c22c:     	cmp	x10, #0x3ff
10089c230:     	ccmn	x9, #0x1, #0x4, lo
10089c234:     	csinc	w9, w11, wzr, le
10089c238:     	mov	x10, #0xffffffc00000    ; =281474972516352
10089c23c:     	movk	x10, #0x41ef, lsl #48
10089c240:     	fmov	d2, x10
10089c244:     	fcmp	d1, d2
10089c248:     	b.hi	0x10089c470 <_js_packed_arraylike_index_get+0x2d0>
10089c24c:     	frintz	d2, d1
10089c250:     	fcmp	d1, d2
10089c254:     	b.ne	0x10089c470 <_js_packed_arraylike_index_get+0x2d0>
10089c258:     	cbz	w9, 0x10089c470 <_js_packed_arraylike_index_get+0x2d0>
10089c25c:     	cbz	w8, 0x10089c470 <_js_packed_arraylike_index_get+0x2d0>
10089c260:     	fcvtzu	w1, d1
10089c264:     	fmov	x8, d0
10089c268:     	mov	w9, #0x7ffd             ; =32765
10089c26c:     	cmp	x9, x8, lsr #48
10089c270:     	b.ne	0x10089c470 <_js_packed_arraylike_index_get+0x2d0>
10089c274:     	and	x19, x8, #0xffffffffffff
10089c278:     	sub	x8, x19, #0x100, lsl #12 ; =0x100000
10089c27c:     	mov	x9, #0x7fffffffffff     ; =140737488355327
10089c280:     	movk	x9, #0xffef, lsl #16
10089c284:     	cmp	x8, x9
10089c288:     	b.hi	0x10089c470 <_js_packed_arraylike_index_get+0x2d0>
10089c28c:     	ldurb	w8, [x19, #-0x8]
10089c290:     	cmp	w8, #0x9
10089c294:     	b.eq	0x10089c2a8 <_js_packed_arraylike_index_get+0x108>
10089c298:     	cmp	w8, #0x2
10089c29c:     	b.eq	0x10089c2d0 <_js_packed_arraylike_index_get+0x130>
10089c2a0:     	cmp	w8, #0x1
10089c2a4:     	b.ne	0x10089c470 <_js_packed_arraylike_index_get+0x2d0>
10089c2a8:     	mov	x0, x19
10089c2ac:     	ldp	x29, x30, [sp, #0x80]
10089c2b0:     	ldp	x20, x19, [sp, #0x70]
10089c2b4:     	ldp	x22, x21, [sp, #0x60]
10089c2b8:     	ldp	x24, x23, [sp, #0x50]
10089c2bc:     	ldp	x26, x25, [sp, #0x40]
10089c2c0:     	ldp	x28, x27, [sp, #0x30]
10089c2c4:     	ldp	d9, d8, [sp, #0x20]
10089c2c8:     	add	sp, sp, #0x90
10089c2cc:     	b	0x1007bcc50 <_js_array_get_f64>
10089c2d0:     	ldursb	w8, [x19, #-0x7]
10089c2d4:     	tbnz	w8, #0x1f, 0x10089c470 <_js_packed_arraylike_index_get+0x2d0>
10089c2d8:     	ldr	x8, [x19, #0x8]
10089c2dc:     	cbz	x8, 0x10089c318 <_js_packed_arraylike_index_get+0x178>
10089c2e0:     	ldr	x8, [x8, #0x60]
10089c2e4:     	cbz	x8, 0x10089c318 <_js_packed_arraylike_index_get+0x178>
10089c2e8:     	ldr	w9, [x8]
10089c2ec:     	cmp	w1, w9
10089c2f0:     	b.hs	0x10089c470 <_js_packed_arraylike_index_get+0x2d0>
10089c2f4:     	add	x8, x8, w1, uxtw #3
10089c2f8:     	ldr	x8, [x8, #0x8]
10089c2fc:     	mov	x9, #0x1                ; =1
10089c300:     	movk	x9, #0x7ffc, lsl #48
10089c304:     	add	x9, x9, #0xf
10089c308:     	cmp	x8, x9
10089c30c:     	b.eq	0x10089c470 <_js_packed_arraylike_index_get+0x2d0>
10089c310:     	fmov	d0, x8
10089c314:     	b	0x10089c528 <_js_packed_arraylike_index_get+0x388>
10089c318:     	mov	x21, x0
10089c31c:     	mov	x22, x1
10089c320:     	mov.16b	v8, v0
10089c324:     	mov.16b	v9, v1
10089c328:     	add	x0, sp, #0xc
10089c32c:     	mov	x1, x19
10089c330:     	bl	0x100547724 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33dense_layout_for_validated_object>
10089c334:     	ldr	w8, [sp, #0xc]
10089c338:     	cbz	w8, 0x10089c468 <_js_packed_arraylike_index_get+0x2c8>
10089c33c:     	ldp	w20, w25, [sp, #0x10]
10089c340:     	adrp	x24, 0x100f7d000 <__MergedGlobals+0xd0>
10089c344:     	add	x24, x24, #0x390
10089c348:     	adrp	x23, 0x100f7d000 <__MergedGlobals+0xd0>
10089c34c:     	ldp	w27, w26, [sp, #0x18]
10089c350:     	cbz	x21, 0x10089c394 <_js_packed_arraylike_index_get+0x1f4>
10089c354:     	mov	x0, x21
10089c358:     	ldapr	x8, [x24]
10089c35c:     	cbnz	x8, 0x10089c3e8 <_js_packed_arraylike_index_get+0x248>
10089c360:     	ldrb	w8, [x23, #0x398]
10089c364:     	tbz	w8, #0x0, 0x10089c394 <_js_packed_arraylike_index_get+0x1f4>
10089c368:     	ldapr	x21, [x0]
10089c36c:     	cbz	x21, 0x10089c4d4 <_js_packed_arraylike_index_get+0x334>
10089c370:     	mov	x0, x19
10089c374:     	mov	x1, x20
10089c378:     	bl	0x100548600 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass42array_subclass_named_prefix_token_for_slot>
10089c37c:     	stp	x20, x25, [x21, #0x8]
10089c380:     	stp	x27, x26, [x21, #0x18]
10089c384:     	cbnz	x0, 0x10089c390 <_js_packed_arraylike_index_get+0x1f0>
10089c388:     	ldp	w9, w8, [x19]
10089c38c:     	orr	x0, x8, x9, lsl #32
10089c390:     	str	x0, [x21]
10089c394:     	cmp	w20, w26
10089c398:     	b.hs	0x10089c3a8 <_js_packed_arraylike_index_get+0x208>
10089c39c:     	add	x8, x19, x20, lsl #3
10089c3a0:     	ldr	x0, [x8, #0x10]
10089c3a4:     	b	0x10089c430 <_js_packed_arraylike_index_get+0x290>
10089c3a8:     	ldapr	x8, [x24]
10089c3ac:     	cbnz	x8, 0x10089c3fc <_js_packed_arraylike_index_get+0x25c>
10089c3b0:     	mov	x0, #0x1                ; =1
10089c3b4:     	movk	x0, #0x7ffc, lsl #48
10089c3b8:     	ldrb	w8, [x23, #0x398]
10089c3bc:     	tbz	w8, #0x0, 0x10089c410 <_js_packed_arraylike_index_get+0x270>
10089c3c0:     	ldr	x8, [x19, #0x8]
10089c3c4:     	cbz	x8, 0x10089c430 <_js_packed_arraylike_index_get+0x290>
10089c3c8:     	ldr	x8, [x8, #0x20]
10089c3cc:     	cbz	x8, 0x10089c430 <_js_packed_arraylike_index_get+0x290>
10089c3d0:     	ldr	w9, [x8]
10089c3d4:     	cmp	w20, w9
10089c3d8:     	b.hs	0x10089c430 <_js_packed_arraylike_index_get+0x290>
10089c3dc:     	add	x8, x8, x20, lsl #3
10089c3e0:     	ldr	x0, [x8, #0x8]
10089c3e4:     	b	0x10089c430 <_js_packed_arraylike_index_get+0x290>
10089c3e8:     	bl	0x100b182ec <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill20object_spill_enabled0E0zEB1A_>
10089c3ec:     	mov	x0, x21
10089c3f0:     	ldrb	w8, [x23, #0x398]
10089c3f4:     	tbnz	w8, #0x0, 0x10089c368 <_js_packed_arraylike_index_get+0x1c8>
10089c3f8:     	b	0x10089c394 <_js_packed_arraylike_index_get+0x1f4>
10089c3fc:     	bl	0x100b182ec <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill20object_spill_enabled0E0zEB1A_>
10089c400:     	mov	x0, #0x1                ; =1
10089c404:     	movk	x0, #0x7ffc, lsl #48
10089c408:     	ldrb	w8, [x23, #0x398]
10089c40c:     	tbnz	w8, #0x0, 0x10089c3c0 <_js_packed_arraylike_index_get+0x220>
10089c410:     	mov	x0, x19
10089c414:     	mov	x1, x20
10089c418:     	bl	0x1005d9b1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill12overflow_get>
10089c41c:     	mov	x8, x0
10089c420:     	mov	x0, #0x1                ; =1
10089c424:     	movk	x0, #0x7ffc, lsl #48
10089c428:     	tst	w8, #0x1
10089c42c:     	csel	x0, x1, x0, ne
10089c430:     	bl	0x100546420 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22nonnegative_u32_length>
10089c434:     	cmp	w0, #0x1
10089c438:     	b.ne	0x10089c468 <_js_packed_arraylike_index_get+0x2c8>
10089c43c:     	cmp	w22, w1
10089c440:     	b.hs	0x10089c468 <_js_packed_arraylike_index_get+0x2c8>
10089c444:     	cmp	w22, w27
10089c448:     	b.hs	0x10089c468 <_js_packed_arraylike_index_get+0x2c8>
10089c44c:     	adds	w1, w25, w22
10089c450:     	b.hs	0x10089c468 <_js_packed_arraylike_index_get+0x2c8>
10089c454:     	cmp	w1, w26
10089c458:     	b.hs	0x10089c494 <_js_packed_arraylike_index_get+0x2f4>
10089c45c:     	add	x8, x19, w1, uxtw #3
10089c460:     	ldr	x20, [x8, #0x10]
10089c464:     	b	0x10089c524 <_js_packed_arraylike_index_get+0x384>
10089c468:     	mov.16b	v1, v9
10089c46c:     	mov.16b	v0, v8
10089c470:     	ldp	x29, x30, [sp, #0x80]
10089c474:     	ldp	x20, x19, [sp, #0x70]
10089c478:     	ldp	x22, x21, [sp, #0x60]
10089c47c:     	ldp	x24, x23, [sp, #0x50]
10089c480:     	ldp	x26, x25, [sp, #0x40]
10089c484:     	ldp	x28, x27, [sp, #0x30]
10089c488:     	ldp	d9, d8, [sp, #0x20]
10089c48c:     	add	sp, sp, #0x90
10089c490:     	b	0x10081b1f4 <_js_dyn_index_get>
10089c494:     	ldapr	x8, [x24]
10089c498:     	cbnz	x8, 0x10089c4f8 <_js_packed_arraylike_index_get+0x358>
10089c49c:     	mov	x20, #0x1               ; =1
10089c4a0:     	movk	x20, #0x7ffc, lsl #48
10089c4a4:     	ldrb	w8, [x23, #0x398]
10089c4a8:     	tbz	w8, #0x0, 0x10089c514 <_js_packed_arraylike_index_get+0x374>
10089c4ac:     	ldr	x8, [x19, #0x8]
10089c4b0:     	cbz	x8, 0x10089c524 <_js_packed_arraylike_index_get+0x384>
10089c4b4:     	ldr	x8, [x8, #0x20]
10089c4b8:     	cbz	x8, 0x10089c524 <_js_packed_arraylike_index_get+0x384>
10089c4bc:     	ldr	w9, [x8]
10089c4c0:     	cmp	w1, w9
10089c4c4:     	b.hs	0x10089c524 <_js_packed_arraylike_index_get+0x384>
10089c4c8:     	add	x8, x8, w1, uxtw #3
10089c4cc:     	ldr	x20, [x8, #0x8]
10089c4d0:     	b	0x10089c524 <_js_packed_arraylike_index_get+0x384>
10089c4d4:     	bl	0x100b37ea8 <__RINvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set7ic_slot16pic_slot_publishAyj5_EB8_>
10089c4d8:     	mov	x21, x0
10089c4dc:     	mov	x0, x19
10089c4e0:     	mov	x1, x20
10089c4e4:     	bl	0x100548600 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass42array_subclass_named_prefix_token_for_slot>
10089c4e8:     	stp	x20, x25, [x21, #0x8]
10089c4ec:     	stp	x27, x26, [x21, #0x18]
10089c4f0:     	cbnz	x0, 0x10089c390 <_js_packed_arraylike_index_get+0x1f0>
10089c4f4:     	b	0x10089c388 <_js_packed_arraylike_index_get+0x1e8>
10089c4f8:     	mov	x20, x1
10089c4fc:     	bl	0x100b182ec <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill20object_spill_enabled0E0zEB1A_>
10089c500:     	mov	x1, x20
10089c504:     	mov	x20, #0x1               ; =1
10089c508:     	movk	x20, #0x7ffc, lsl #48
10089c50c:     	ldrb	w8, [x23, #0x398]
10089c510:     	tbnz	w8, #0x0, 0x10089c4ac <_js_packed_arraylike_index_get+0x30c>
10089c514:     	mov	x0, x19
10089c518:     	bl	0x1005d9b1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object5spill12overflow_get>
10089c51c:     	tst	w0, #0x1
10089c520:     	csel	x20, x1, x20, ne
10089c524:     	fmov	d0, x20
10089c528:     	ldp	x29, x30, [sp, #0x80]
10089c52c:     	ldp	x20, x19, [sp, #0x70]
10089c530:     	ldp	x22, x21, [sp, #0x60]
10089c534:     	ldp	x24, x23, [sp, #0x50]
10089c538:     	ldp	x26, x25, [sp, #0x40]
10089c53c:     	ldp	x28, x27, [sp, #0x30]
10089c540:     	ldp	d9, d8, [sp, #0x20]
10089c544:     	add	sp, sp, #0x90
10089c548:     	ret
10089c54c:     	nop
10089c550:     	nop
10089c554:     	nop
10089c558:     	nop
10089c55c:     	nop
10089c560:     	nop
10089c564:     	nop
10089c568:     	nop
10089c56c:     	nop
10089c570:     	nop
10089c574:     	nop
10089c578:     	nop
10089c57c:     	nop
