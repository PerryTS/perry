
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/main-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001006870dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>:
1006870dc:     	stp	x24, x23, [sp, #-0x40]!
1006870e0:     	stp	x22, x21, [sp, #0x10]
1006870e4:     	stp	x20, x19, [sp, #0x20]
1006870e8:     	stp	x29, x30, [sp, #0x30]
1006870ec:     	add	x29, sp, #0x30
1006870f0:     	mov	x20, x0
1006870f4:     	ldr	x23, [x20, #0x20]!
1006870f8:     	cbz	x23, 0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006870fc:     	mov	x19, x0
100687100:     	lsr	x8, x23, #51
100687104:     	mov	x21, x23
100687108:     	cmp	x8, #0xfff
10068710c:     	b.lo	0x100687124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x48>
100687110:     	mov	w8, #0x7ffc             ; =32764
100687114:     	cmp	x8, x23, lsr #48
100687118:     	b.eq	0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068711c:     	ands	x21, x23, #0xffffffffffff
100687120:     	b.eq	0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687124:     	and	x8, x21, #0xfffffffffff00000
100687128:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
10068712c:     	mov	x10, #0x7ffffffff000    ; =140737488351232
100687130:     	cmp	x9, x10
100687134:     	ccmp	x8, #0x0, #0x4, lo
100687138:     	b.eq	0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068713c:     	tst	x21, #0x3
100687140:     	ccmp	x21, #0x7, #0x0, eq
100687144:     	b.ls	0x1006872cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
100687148:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
10068714c:     	ldr	x8, [x8, #0x30]
100687150:     	cmn	x8, #0x1
100687154:     	b.eq	0x10068721c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x140>
100687158:     	mrs	x9, TPIDRRO_EL0
10068715c:     	and	x9, x9, #0xfffffffffffffff8
100687160:     	ldr	x0, [x9, x8, lsl #3]
100687164:     	cbz	x0, 0x10068721c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x140>
100687168:     	lsr	x1, x21, #20
10068716c:     	ldr	x8, [x0, #0x10]
100687170:     	ldrb	w9, [x8]
100687174:     	cmp	w9, #0x2
100687178:     	b.ne	0x100687234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x158>
10068717c:     	ldrb	w9, [x8, #0x88]
100687180:     	tbz	w9, #0x0, 0x1006871a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xc4>
100687184:     	ldr	x9, [x8, #0x80]
100687188:     	cmp	x9, x1
10068718c:     	b.ne	0x1006871a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xc4>
100687190:     	ldp	x9, x10, [x8, #0x60]
100687194:     	cmp	x9, x21
100687198:     	ccmp	x10, x21, #0x0, ls
10068719c:     	b.hi	0x100687214 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x138>
1006871a0:     	ldrb	w9, [x8, #0xb8]
1006871a4:     	cbz	w9, 0x1006871c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xe8>
1006871a8:     	ldr	x9, [x8, #0xb0]
1006871ac:     	cmp	x9, x1
1006871b0:     	b.ne	0x1006871c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xe8>
1006871b4:     	ldp	x9, x10, [x8, #0x90]
1006871b8:     	cmp	x9, x21
1006871bc:     	ccmp	x10, x21, #0x0, ls
1006871c0:     	b.hi	0x100687540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x464>
1006871c4:     	ldrb	w9, [x8, #0xe8]
1006871c8:     	cbz	w9, 0x1006871e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x10c>
1006871cc:     	ldr	x9, [x8, #0xe0]
1006871d0:     	cmp	x9, x1
1006871d4:     	b.ne	0x1006871e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x10c>
1006871d8:     	ldp	x9, x10, [x8, #0xc0]
1006871dc:     	cmp	x9, x21
1006871e0:     	ccmp	x10, x21, #0x0, ls
1006871e4:     	b.hi	0x100687548 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x46c>
1006871e8:     	ldrb	w9, [x8, #0x118]
1006871ec:     	cbz	w9, 0x100687294 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
1006871f0:     	ldr	x9, [x8, #0x110]
1006871f4:     	cmp	x9, x1
1006871f8:     	b.ne	0x100687294 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
1006871fc:     	ldp	x9, x10, [x8, #0xf0]
100687200:     	cmp	x9, x21
100687204:     	ccmp	x10, x21, #0x0, ls
100687208:     	b.ls	0x100687294 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
10068720c:     	add	x9, x8, #0xf0
100687210:     	b	0x10068754c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x470>
100687214:     	add	x9, x8, #0x60
100687218:     	b	0x10068754c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x470>
10068721c:     	bl	0x100b3de7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100687220:     	lsr	x1, x21, #20
100687224:     	ldr	x8, [x0, #0x10]
100687228:     	ldrb	w9, [x8]
10068722c:     	cmp	w9, #0x2
100687230:     	b.eq	0x10068717c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xa0>
100687234:     	ldr	x9, [x8, #0x8]
100687238:     	ldr	x10, [x8, #0x28]
10068723c:     	sub	x9, x1, x9
100687240:     	cmp	x9, x10
100687244:     	b.hs	0x100687288 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1ac>
100687248:     	ldr	x10, [x8, #0x20]
10068724c:     	mov	w11, #0x28              ; =40
100687250:     	madd	x9, x9, x11, x10
100687254:     	ldr	x10, [x9]
100687258:     	ldr	x11, [x8, #0x10]
10068725c:     	cmp	x10, x11
100687260:     	b.ne	0x100687294 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
100687264:     	ldp	x10, x11, [x9, #0x8]
100687268:     	cmp	x10, x21
10068726c:     	ccmp	x11, x21, #0x0, ls
100687270:     	b.ls	0x100687294 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
100687274:     	ldr	x10, [x8, #0x30]
100687278:     	add	x10, x10, #0x1
10068727c:     	str	x10, [x8, #0x30]
100687280:     	add	x8, x9, #0x21
100687284:     	b	0x10068755c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x480>
100687288:     	ldr	x9, [x8, #0x58]
10068728c:     	add	x9, x9, #0x1
100687290:     	str	x9, [x8, #0x58]
100687294:     	ldr	x9, [x8, #0x38]
100687298:     	add	x9, x9, #0x1
10068729c:     	str	x9, [x8, #0x38]
1006872a0:     	mov	x0, x21
1006872a4:     	bl	0x10051d1c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1006872a8:     	and	w8, w0, #0xff
1006872ac:     	cbz	w8, 0x1006872cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
1006872b0:     	ldurb	w8, [x21, #-0x8]
1006872b4:     	ldurb	w9, [x21, #-0x7]
1006872b8:     	mov	w10, #0x82              ; =130
1006872bc:     	and	w9, w9, w10
1006872c0:     	cmp	w9, #0x2
1006872c4:     	ccmp	w8, #0x1, #0x0, eq
1006872c8:     	b.eq	0x10068743c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x360>
1006872cc:     	mov	x0, x21
1006872d0:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1006872d4:     	mov	x22, x0
1006872d8:     	cbz	x0, 0x100687304 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x228>
1006872dc:     	ldrb	w8, [x22]
1006872e0:     	cmp	w8, #0x1
1006872e4:     	b.ne	0x100687318 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x23c>
1006872e8:     	ldrsb	w8, [x22, #0x1]
1006872ec:     	tbnz	w8, #0x1f, 0x1006874a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x3cc>
1006872f0:     	mov	x0, x22
1006872f4:     	ldp	w9, w8, [x21]
1006872f8:     	cmp	w9, w8
1006872fc:     	b.ls	0x1006873d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2f4>
100687300:     	b	0x1006873b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2d8>
100687304:     	mov	x0, x21
100687308:     	bl	0x100588074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10068730c:     	tbz	w0, #0x0, 0x100687354 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x278>
100687310:     	mov	x0, #0x0                ; =0
100687314:     	b	0x1006873a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2c8>
100687318:     	mov	x0, x22
10068731c:     	cmp	w8, #0x1
100687320:     	b.eq	0x1006873a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2c8>
100687324:     	cmp	w8, #0x9
100687328:     	b.ne	0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068732c:     	ldr	w8, [x21, #0x4]
100687330:     	mov	w9, #0x5841             ; =22593
100687334:     	movk	w9, #0x4c5a, lsl #16
100687338:     	cmp	w8, w9
10068733c:     	b.ne	0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687340:     	mov	x0, x21
100687344:     	bl	0x100374830 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100687348:     	mov	x8, x0
10068734c:     	cbnz	x0, 0x100687464 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
100687350:     	b	0x100687528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
100687354:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100687358:     	add	x8, x8, #0xe80
10068735c:     	ldaprb	w8, [x8]
100687360:     	cbz	w8, 0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687364:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100687368:     	add	x8, x8, #0x40
10068736c:     	ldapr	x8, [x8]
100687370:     	cmp	x8, x21
100687374:     	b.hi	0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687378:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
10068737c:     	add	x8, x8, #0x48
100687380:     	ldapr	x8, [x8]
100687384:     	cmp	x8, x21
100687388:     	b.lo	0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068738c:     	mov	x0, x21
100687390:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
100687394:     	mov	x9, x0
100687398:     	mov	x0, #0x0                ; =0
10068739c:     	mov	x8, #0x0                ; =0
1006873a0:     	tbz	w9, #0x0, 0x100687528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
1006873a4:     	ldp	w9, w8, [x21]
1006873a8:     	cmp	w9, w8
1006873ac:     	b.ls	0x1006873d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2f4>
1006873b0:     	cbz	x22, 0x1006873e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x308>
1006873b4:     	ldr	w9, [x0, #0x4]
1006873b8:     	ubfiz	x8, x8, #3, #32
1006873bc:     	add	x10, x8, #0x10
1006873c0:     	mov	x8, x21
1006873c4:     	cmp	x10, x9
1006873c8:     	b.ne	0x1006873e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x308>
1006873cc:     	b	0x100687464 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
1006873d0:     	mov	w10, #0xe100            ; =57600
1006873d4:     	movk	w10, #0x5f5, lsl #16
1006873d8:     	mov	x8, x21
1006873dc:     	cmp	w9, w10
1006873e0:     	b.ls	0x100687464 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
1006873e4:     	mov	x0, x21
1006873e8:     	bl	0x100588074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1006873ec:     	tbnz	w0, #0x0, 0x100687460 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x384>
1006873f0:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1006873f4:     	add	x8, x8, #0xe80
1006873f8:     	ldaprb	w8, [x8]
1006873fc:     	cbz	w8, 0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687400:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100687404:     	add	x8, x8, #0x40
100687408:     	ldapr	x8, [x8]
10068740c:     	cmp	x21, x8
100687410:     	b.lo	0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687414:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100687418:     	add	x8, x8, #0x48
10068741c:     	ldapr	x8, [x8]
100687420:     	cmp	x21, x8
100687424:     	b.hi	0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687428:     	mov	x0, x21
10068742c:     	bl	0x1002a3af8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
100687430:     	mov	x8, x21
100687434:     	tbz	w0, #0x0, 0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687438:     	b	0x100687464 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
10068743c:     	ldr	w8, [x21]
100687440:     	mov	w9, #0xe100             ; =57600
100687444:     	movk	w9, #0x5f5, lsl #16
100687448:     	orr	w9, w9, #0x1
10068744c:     	cmp	w8, w9
100687450:     	b.hs	0x1006872cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
100687454:     	ldr	w9, [x21, #0x4]
100687458:     	cmp	w8, w9
10068745c:     	b.hi	0x1006872cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
100687460:     	mov	x8, x21
100687464:     	cmp	x8, x23
100687468:     	b.eq	0x1006875c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4ec>
10068746c:     	str	x8, [x19, #0x20]
100687470:     	adrp	x9, 0x100f7d000 <__MergedGlobals+0xd0>
100687474:     	add	x9, x9, #0x260
100687478:     	ldapr	x9, [x9]
10068747c:     	cbnz	x9, 0x10068756c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x490>
100687480:     	adrp	x9, 0x100f7d000 <__MergedGlobals+0xd0>
100687484:     	ldrb	w9, [x9, #0x268]
100687488:     	tbz	w9, #0x0, 0x100687584 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4a8>
10068748c:     	mov	x21, x8
100687490:     	mov	x0, x19
100687494:     	mov	x1, x20
100687498:     	mov	x2, x8
10068749c:     	mov	w3, #0x0                ; =0
1006874a0:     	bl	0x100473c00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier26write_barrier_slot_decoded>
1006874a4:     	b	0x10068759c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4c0>
1006874a8:     	ldr	x21, [x22, #0x8]
1006874ac:     	mov	x0, x21
1006874b0:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1006874b4:     	cbz	x0, 0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006874b8:     	ldrb	w8, [x0]
1006874bc:     	cmp	w8, #0x1
1006874c0:     	b.ne	0x100687524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006874c4:     	ldrsb	w8, [x0, #0x1]
1006874c8:     	tbz	w8, #0x1f, 0x1006872f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x218>
1006874cc:     	mov	w24, #0x1               ; =1
1006874d0:     	ldr	x21, [x0, #0x8]
1006874d4:     	mov	x0, x21
1006874d8:     	bl	0x100579840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1006874dc:     	mov	x8, #0x0                ; =0
1006874e0:     	cbz	x0, 0x100687528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
1006874e4:     	ldrb	w9, [x0]
1006874e8:     	cmp	w9, #0x1
1006874ec:     	b.ne	0x100687528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
1006874f0:     	cmp	w24, #0x3f
1006874f4:     	b.hi	0x100687528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
1006874f8:     	add	w24, w24, #0x1
1006874fc:     	ldrsb	w8, [x0, #0x1]
100687500:     	tbnz	w8, #0x1f, 0x1006874d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x3f4>
100687504:     	str	x21, [x22, #0x8]
100687508:     	ldrb	w8, [x22, #0x1]
10068750c:     	orr	w8, w8, #0x80
100687510:     	strb	w8, [x22, #0x1]
100687514:     	ldrb	w8, [x0]
100687518:     	cmp	w8, #0x1
10068751c:     	b.ne	0x100687324 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x248>
100687520:     	b	0x1006873a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2c8>
100687524:     	mov	x8, #0x0                ; =0
100687528:     	mov	x0, x8
10068752c:     	ldp	x29, x30, [sp, #0x30]
100687530:     	ldp	x20, x19, [sp, #0x20]
100687534:     	ldp	x22, x21, [sp, #0x10]
100687538:     	ldp	x24, x23, [sp], #0x40
10068753c:     	ret
100687540:     	add	x9, x8, #0x90
100687544:     	b	0x10068754c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x470>
100687548:     	add	x9, x8, #0xc0
10068754c:     	ldr	x10, [x8, #0x30]
100687550:     	add	x10, x10, #0x1
100687554:     	str	x10, [x8, #0x30]
100687558:     	add	x8, x9, #0x19
10068755c:     	ldrb	w8, [x8]
100687560:     	cmp	w8, #0xff
100687564:     	b.ne	0x1006872ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1d0>
100687568:     	b	0x1006872a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1c4>
10068756c:     	mov	x21, x8
100687570:     	bl	0x100b17fa4 <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier22write_barriers_enabled0E0zEB1A_>
100687574:     	mov	x8, x21
100687578:     	adrp	x9, 0x100f7d000 <__MergedGlobals+0xd0>
10068757c:     	ldrb	w9, [x9, #0x268]
100687580:     	tbnz	w9, #0x0, 0x10068748c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x3b0>
100687584:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100687588:     	ldr	w9, [x9, #0x824]
10068758c:     	cbz	w9, 0x1006875a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4c4>
100687590:     	mov	x21, x8
100687594:     	mov	x0, x8
100687598:     	bl	0x1004755b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
10068759c:     	mov	x8, x21
1006875a0:     	ldr	x9, [x20]
1006875a4:     	cbz	x9, 0x1006875c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4ec>
1006875a8:     	ldr	x9, [x19, #0x10]
1006875ac:     	cbz	x9, 0x1006875c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4ec>
1006875b0:     	mov	x20, x8
1006875b4:     	mov	x0, x19
1006875b8:     	bl	0x1002dce7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime15json_tape_store7release>
1006875bc:     	mov	x8, x20
1006875c0:     	str	xzr, [x19, #0x10]
1006875c4:     	str	wzr, [x19, #0xc]
1006875c8:     	ldr	w9, [x8]
1006875cc:     	str	w9, [x19]
1006875d0:     	b	0x100687528 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
