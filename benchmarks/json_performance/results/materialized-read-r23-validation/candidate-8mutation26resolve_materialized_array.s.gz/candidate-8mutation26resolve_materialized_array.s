
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/candidate-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010068711c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>:
10068711c:     	stp	x24, x23, [sp, #-0x40]!
100687120:     	stp	x22, x21, [sp, #0x10]
100687124:     	stp	x20, x19, [sp, #0x20]
100687128:     	stp	x29, x30, [sp, #0x30]
10068712c:     	add	x29, sp, #0x30
100687130:     	mov	x20, x0
100687134:     	ldr	x23, [x20, #0x20]!
100687138:     	cbz	x23, 0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068713c:     	mov	x19, x0
100687140:     	lsr	x8, x23, #51
100687144:     	mov	x21, x23
100687148:     	cmp	x8, #0xfff
10068714c:     	b.lo	0x100687164 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x48>
100687150:     	mov	w8, #0x7ffc             ; =32764
100687154:     	cmp	x8, x23, lsr #48
100687158:     	b.eq	0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068715c:     	ands	x21, x23, #0xffffffffffff
100687160:     	b.eq	0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687164:     	and	x8, x21, #0xfffffffffff00000
100687168:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
10068716c:     	mov	x10, #0x7ffffffff000    ; =140737488351232
100687170:     	cmp	x9, x10
100687174:     	ccmp	x8, #0x0, #0x4, lo
100687178:     	b.eq	0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068717c:     	tst	x21, #0x3
100687180:     	ccmp	x21, #0x7, #0x0, eq
100687184:     	b.ls	0x10068730c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
100687188:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
10068718c:     	ldr	x8, [x8, #0x30]
100687190:     	cmn	x8, #0x1
100687194:     	b.eq	0x10068725c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x140>
100687198:     	mrs	x9, TPIDRRO_EL0
10068719c:     	and	x9, x9, #0xfffffffffffffff8
1006871a0:     	ldr	x0, [x9, x8, lsl #3]
1006871a4:     	cbz	x0, 0x10068725c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x140>
1006871a8:     	lsr	x1, x21, #20
1006871ac:     	ldr	x8, [x0, #0x10]
1006871b0:     	ldrb	w9, [x8]
1006871b4:     	cmp	w9, #0x2
1006871b8:     	b.ne	0x100687274 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x158>
1006871bc:     	ldrb	w9, [x8, #0x88]
1006871c0:     	tbz	w9, #0x0, 0x1006871e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xc4>
1006871c4:     	ldr	x9, [x8, #0x80]
1006871c8:     	cmp	x9, x1
1006871cc:     	b.ne	0x1006871e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xc4>
1006871d0:     	ldp	x9, x10, [x8, #0x60]
1006871d4:     	cmp	x9, x21
1006871d8:     	ccmp	x10, x21, #0x0, ls
1006871dc:     	b.hi	0x100687254 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x138>
1006871e0:     	ldrb	w9, [x8, #0xb8]
1006871e4:     	cbz	w9, 0x100687204 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xe8>
1006871e8:     	ldr	x9, [x8, #0xb0]
1006871ec:     	cmp	x9, x1
1006871f0:     	b.ne	0x100687204 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xe8>
1006871f4:     	ldp	x9, x10, [x8, #0x90]
1006871f8:     	cmp	x9, x21
1006871fc:     	ccmp	x10, x21, #0x0, ls
100687200:     	b.hi	0x100687580 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x464>
100687204:     	ldrb	w9, [x8, #0xe8]
100687208:     	cbz	w9, 0x100687228 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x10c>
10068720c:     	ldr	x9, [x8, #0xe0]
100687210:     	cmp	x9, x1
100687214:     	b.ne	0x100687228 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x10c>
100687218:     	ldp	x9, x10, [x8, #0xc0]
10068721c:     	cmp	x9, x21
100687220:     	ccmp	x10, x21, #0x0, ls
100687224:     	b.hi	0x100687588 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x46c>
100687228:     	ldrb	w9, [x8, #0x118]
10068722c:     	cbz	w9, 0x1006872d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
100687230:     	ldr	x9, [x8, #0x110]
100687234:     	cmp	x9, x1
100687238:     	b.ne	0x1006872d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
10068723c:     	ldp	x9, x10, [x8, #0xf0]
100687240:     	cmp	x9, x21
100687244:     	ccmp	x10, x21, #0x0, ls
100687248:     	b.ls	0x1006872d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
10068724c:     	add	x9, x8, #0xf0
100687250:     	b	0x10068758c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x470>
100687254:     	add	x9, x8, #0x60
100687258:     	b	0x10068758c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x470>
10068725c:     	bl	0x100b3df7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100687260:     	lsr	x1, x21, #20
100687264:     	ldr	x8, [x0, #0x10]
100687268:     	ldrb	w9, [x8]
10068726c:     	cmp	w9, #0x2
100687270:     	b.eq	0x1006871bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0xa0>
100687274:     	ldr	x9, [x8, #0x8]
100687278:     	ldr	x10, [x8, #0x28]
10068727c:     	sub	x9, x1, x9
100687280:     	cmp	x9, x10
100687284:     	b.hs	0x1006872c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1ac>
100687288:     	ldr	x10, [x8, #0x20]
10068728c:     	mov	w11, #0x28              ; =40
100687290:     	madd	x9, x9, x11, x10
100687294:     	ldr	x10, [x9]
100687298:     	ldr	x11, [x8, #0x10]
10068729c:     	cmp	x10, x11
1006872a0:     	b.ne	0x1006872d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
1006872a4:     	ldp	x10, x11, [x9, #0x8]
1006872a8:     	cmp	x10, x21
1006872ac:     	ccmp	x11, x21, #0x0, ls
1006872b0:     	b.ls	0x1006872d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1b8>
1006872b4:     	ldr	x10, [x8, #0x30]
1006872b8:     	add	x10, x10, #0x1
1006872bc:     	str	x10, [x8, #0x30]
1006872c0:     	add	x8, x9, #0x21
1006872c4:     	b	0x10068759c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x480>
1006872c8:     	ldr	x9, [x8, #0x58]
1006872cc:     	add	x9, x9, #0x1
1006872d0:     	str	x9, [x8, #0x58]
1006872d4:     	ldr	x9, [x8, #0x38]
1006872d8:     	add	x9, x9, #0x1
1006872dc:     	str	x9, [x8, #0x38]
1006872e0:     	mov	x0, x21
1006872e4:     	bl	0x10051d208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1006872e8:     	and	w8, w0, #0xff
1006872ec:     	cbz	w8, 0x10068730c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
1006872f0:     	ldurb	w8, [x21, #-0x8]
1006872f4:     	ldurb	w9, [x21, #-0x7]
1006872f8:     	mov	w10, #0x82              ; =130
1006872fc:     	and	w9, w9, w10
100687300:     	cmp	w9, #0x2
100687304:     	ccmp	w8, #0x1, #0x0, eq
100687308:     	b.eq	0x10068747c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x360>
10068730c:     	mov	x0, x21
100687310:     	bl	0x100579880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100687314:     	mov	x22, x0
100687318:     	cbz	x0, 0x100687344 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x228>
10068731c:     	ldrb	w8, [x22]
100687320:     	cmp	w8, #0x1
100687324:     	b.ne	0x100687358 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x23c>
100687328:     	ldrsb	w8, [x22, #0x1]
10068732c:     	tbnz	w8, #0x1f, 0x1006874e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x3cc>
100687330:     	mov	x0, x22
100687334:     	ldp	w9, w8, [x21]
100687338:     	cmp	w9, w8
10068733c:     	b.ls	0x100687410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2f4>
100687340:     	b	0x1006873f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2d8>
100687344:     	mov	x0, x21
100687348:     	bl	0x1005880b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10068734c:     	tbz	w0, #0x0, 0x100687394 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x278>
100687350:     	mov	x0, #0x0                ; =0
100687354:     	b	0x1006873e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2c8>
100687358:     	mov	x0, x22
10068735c:     	cmp	w8, #0x1
100687360:     	b.eq	0x1006873e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2c8>
100687364:     	cmp	w8, #0x9
100687368:     	b.ne	0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
10068736c:     	ldr	w8, [x21, #0x4]
100687370:     	mov	w9, #0x5841             ; =22593
100687374:     	movk	w9, #0x4c5a, lsl #16
100687378:     	cmp	w8, w9
10068737c:     	b.ne	0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687380:     	mov	x0, x21
100687384:     	bl	0x100374d0c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100687388:     	mov	x8, x0
10068738c:     	cbnz	x0, 0x1006874a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
100687390:     	b	0x100687568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
100687394:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100687398:     	add	x8, x8, #0xe80
10068739c:     	ldaprb	w8, [x8]
1006873a0:     	cbz	w8, 0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006873a4:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1006873a8:     	add	x8, x8, #0x40
1006873ac:     	ldapr	x8, [x8]
1006873b0:     	cmp	x8, x21
1006873b4:     	b.hi	0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006873b8:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1006873bc:     	add	x8, x8, #0x48
1006873c0:     	ldapr	x8, [x8]
1006873c4:     	cmp	x8, x21
1006873c8:     	b.lo	0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006873cc:     	mov	x0, x21
1006873d0:     	bl	0x1002a3b38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1006873d4:     	mov	x9, x0
1006873d8:     	mov	x0, #0x0                ; =0
1006873dc:     	mov	x8, #0x0                ; =0
1006873e0:     	tbz	w9, #0x0, 0x100687568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
1006873e4:     	ldp	w9, w8, [x21]
1006873e8:     	cmp	w9, w8
1006873ec:     	b.ls	0x100687410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2f4>
1006873f0:     	cbz	x22, 0x100687424 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x308>
1006873f4:     	ldr	w9, [x0, #0x4]
1006873f8:     	ubfiz	x8, x8, #3, #32
1006873fc:     	add	x10, x8, #0x10
100687400:     	mov	x8, x21
100687404:     	cmp	x10, x9
100687408:     	b.ne	0x100687424 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x308>
10068740c:     	b	0x1006874a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
100687410:     	mov	w10, #0xe100            ; =57600
100687414:     	movk	w10, #0x5f5, lsl #16
100687418:     	mov	x8, x21
10068741c:     	cmp	w9, w10
100687420:     	b.ls	0x1006874a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
100687424:     	mov	x0, x21
100687428:     	bl	0x1005880b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
10068742c:     	tbnz	w0, #0x0, 0x1006874a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x384>
100687430:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100687434:     	add	x8, x8, #0xe80
100687438:     	ldaprb	w8, [x8]
10068743c:     	cbz	w8, 0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687440:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100687444:     	add	x8, x8, #0x40
100687448:     	ldapr	x8, [x8]
10068744c:     	cmp	x21, x8
100687450:     	b.lo	0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687454:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
100687458:     	add	x8, x8, #0x48
10068745c:     	ldapr	x8, [x8]
100687460:     	cmp	x21, x8
100687464:     	b.hi	0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687468:     	mov	x0, x21
10068746c:     	bl	0x1002a3b38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
100687470:     	mov	x8, x21
100687474:     	tbz	w0, #0x0, 0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687478:     	b	0x1006874a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x388>
10068747c:     	ldr	w8, [x21]
100687480:     	mov	w9, #0xe100             ; =57600
100687484:     	movk	w9, #0x5f5, lsl #16
100687488:     	orr	w9, w9, #0x1
10068748c:     	cmp	w8, w9
100687490:     	b.hs	0x10068730c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
100687494:     	ldr	w9, [x21, #0x4]
100687498:     	cmp	w8, w9
10068749c:     	b.hi	0x10068730c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1f0>
1006874a0:     	mov	x8, x21
1006874a4:     	cmp	x8, x23
1006874a8:     	b.eq	0x100687608 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4ec>
1006874ac:     	str	x8, [x19, #0x20]
1006874b0:     	adrp	x9, 0x100f7d000 <__MergedGlobals+0xd0>
1006874b4:     	add	x9, x9, #0x260
1006874b8:     	ldapr	x9, [x9]
1006874bc:     	cbnz	x9, 0x1006875ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x490>
1006874c0:     	adrp	x9, 0x100f7d000 <__MergedGlobals+0xd0>
1006874c4:     	ldrb	w9, [x9, #0x268]
1006874c8:     	tbz	w9, #0x0, 0x1006875c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4a8>
1006874cc:     	mov	x21, x8
1006874d0:     	mov	x0, x19
1006874d4:     	mov	x1, x20
1006874d8:     	mov	x2, x8
1006874dc:     	mov	w3, #0x0                ; =0
1006874e0:     	bl	0x100473c40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier26write_barrier_slot_decoded>
1006874e4:     	b	0x1006875dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4c0>
1006874e8:     	ldr	x21, [x22, #0x8]
1006874ec:     	mov	x0, x21
1006874f0:     	bl	0x100579880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1006874f4:     	cbz	x0, 0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
1006874f8:     	ldrb	w8, [x0]
1006874fc:     	cmp	w8, #0x1
100687500:     	b.ne	0x100687564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x448>
100687504:     	ldrsb	w8, [x0, #0x1]
100687508:     	tbz	w8, #0x1f, 0x100687334 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x218>
10068750c:     	mov	w24, #0x1               ; =1
100687510:     	ldr	x21, [x0, #0x8]
100687514:     	mov	x0, x21
100687518:     	bl	0x100579880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10068751c:     	mov	x8, #0x0                ; =0
100687520:     	cbz	x0, 0x100687568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
100687524:     	ldrb	w9, [x0]
100687528:     	cmp	w9, #0x1
10068752c:     	b.ne	0x100687568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
100687530:     	cmp	w24, #0x3f
100687534:     	b.hi	0x100687568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
100687538:     	add	w24, w24, #0x1
10068753c:     	ldrsb	w8, [x0, #0x1]
100687540:     	tbnz	w8, #0x1f, 0x100687510 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x3f4>
100687544:     	str	x21, [x22, #0x8]
100687548:     	ldrb	w8, [x22, #0x1]
10068754c:     	orr	w8, w8, #0x80
100687550:     	strb	w8, [x22, #0x1]
100687554:     	ldrb	w8, [x0]
100687558:     	cmp	w8, #0x1
10068755c:     	b.ne	0x100687364 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x248>
100687560:     	b	0x1006873e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x2c8>
100687564:     	mov	x8, #0x0                ; =0
100687568:     	mov	x0, x8
10068756c:     	ldp	x29, x30, [sp, #0x30]
100687570:     	ldp	x20, x19, [sp, #0x20]
100687574:     	ldp	x22, x21, [sp, #0x10]
100687578:     	ldp	x24, x23, [sp], #0x40
10068757c:     	ret
100687580:     	add	x9, x8, #0x90
100687584:     	b	0x10068758c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x470>
100687588:     	add	x9, x8, #0xc0
10068758c:     	ldr	x10, [x8, #0x30]
100687590:     	add	x10, x10, #0x1
100687594:     	str	x10, [x8, #0x30]
100687598:     	add	x8, x9, #0x19
10068759c:     	ldrb	w8, [x8]
1006875a0:     	cmp	w8, #0xff
1006875a4:     	b.ne	0x1006872ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1d0>
1006875a8:     	b	0x1006872e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x1c4>
1006875ac:     	mov	x21, x8
1006875b0:     	bl	0x100b180a4 <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockbE10initializeNCINvB2_11get_or_initNCNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier22write_barriers_enabled0E0zEB1A_>
1006875b4:     	mov	x8, x21
1006875b8:     	adrp	x9, 0x100f7d000 <__MergedGlobals+0xd0>
1006875bc:     	ldrb	w9, [x9, #0x268]
1006875c0:     	tbnz	w9, #0x0, 0x1006874cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x3b0>
1006875c4:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1006875c8:     	ldr	w9, [x9, #0x824]
1006875cc:     	cbz	w9, 0x1006875e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4c4>
1006875d0:     	mov	x21, x8
1006875d4:     	mov	x0, x8
1006875d8:     	bl	0x1004755f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1006875dc:     	mov	x8, x21
1006875e0:     	ldr	x9, [x20]
1006875e4:     	cbz	x9, 0x100687608 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4ec>
1006875e8:     	ldr	x9, [x19, #0x10]
1006875ec:     	cbz	x9, 0x100687608 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x4ec>
1006875f0:     	mov	x20, x8
1006875f4:     	mov	x0, x19
1006875f8:     	bl	0x1002dcebc <__RNvNtCs3gRpqoBkMHm_13perry_runtime15json_tape_store7release>
1006875fc:     	mov	x8, x20
100687600:     	str	xzr, [x19, #0x10]
100687604:     	str	wzr, [x19, #0xc]
100687608:     	ldr	w9, [x8]
10068760c:     	str	w9, [x19]
100687610:     	b	0x100687568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array+0x44c>
