
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/candidate-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007bcc90 <_js_array_get_f64>:
1007bcc90:     	sub	sp, sp, #0x70
1007bcc94:     	stp	x26, x25, [sp, #0x20]
1007bcc98:     	stp	x24, x23, [sp, #0x30]
1007bcc9c:     	stp	x22, x21, [sp, #0x40]
1007bcca0:     	stp	x20, x19, [sp, #0x50]
1007bcca4:     	stp	x29, x30, [sp, #0x60]
1007bcca8:     	add	x29, sp, #0x60
1007bccac:     	mov	x19, x1
1007bccb0:     	mov	x22, x0
1007bccb4:     	lsr	x25, x0, #51
1007bccb8:     	mov	x20, x0
1007bccbc:     	cmp	x25, #0xfff
1007bccc0:     	b.lo	0x1007bccdc <_js_array_get_f64+0x4c>
1007bccc4:     	mov	w8, #0x7ffc             ; =32764
1007bccc8:     	cmp	x8, x22, lsr #48
1007bcccc:     	b.ne	0x1007bccd8 <_js_array_get_f64+0x48>
1007bccd0:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007bccd4:     	b	0x1007bd420 <_js_array_get_f64+0x790>
1007bccd8:     	and	x20, x22, #0xffffffffffff
1007bccdc:     	lsr	x8, x20, #3
1007bcce0:     	cmp	x8, #0x200
1007bcce4:     	b.ls	0x1007bcd5c <_js_array_get_f64+0xcc>
1007bcce8:     	ldurb	w8, [x20, #-0x8]
1007bccec:     	cmp	w8, #0x9
1007bccf0:     	b.ne	0x1007bcd5c <_js_array_get_f64+0xcc>
1007bccf4:     	ldr	w8, [x20, #0x4]
1007bccf8:     	mov	w9, #0x5841             ; =22593
1007bccfc:     	movk	w9, #0x4c5a, lsl #16
1007bcd00:     	cmp	w8, w9
1007bcd04:     	b.ne	0x1007bcd5c <_js_array_get_f64+0xcc>
1007bcd08:     	ldr	x8, [x20, #0x20]
1007bcd0c:     	cbz	x8, 0x1007bcfb0 <_js_array_get_f64+0x320>
1007bcd10:     	mov	x0, x20
1007bcd14:     	bl	0x10068711c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1007bcd18:     	cbz	x0, 0x1007bcfe8 <_js_array_get_f64+0x358>
1007bcd1c:     	ldurh	w8, [x0, #-0x6]
1007bcd20:     	tbnz	w8, #0xa, 0x1007bcfe8 <_js_array_get_f64+0x358>
1007bcd24:     	ldr	w8, [x0]
1007bcd28:     	cmp	w19, w8
1007bcd2c:     	b.hs	0x1007bcfe8 <_js_array_get_f64+0x358>
1007bcd30:     	ldr	w8, [x0, #0x4]
1007bcd34:     	cmp	w19, w8
1007bcd38:     	b.hs	0x1007bcfe8 <_js_array_get_f64+0x358>
1007bcd3c:     	add	x8, x0, w19, uxtw #3
1007bcd40:     	ldr	x22, [x8, #0x8]
1007bcd44:     	mov	x8, #0x1                ; =1
1007bcd48:     	movk	x8, #0x7ffc, lsl #48
1007bcd4c:     	add	x8, x8, #0xf
1007bcd50:     	cmp	x22, x8
1007bcd54:     	b.ne	0x1007bd420 <_js_array_get_f64+0x790>
1007bcd58:     	b	0x1007bcfe8 <_js_array_get_f64+0x358>
1007bcd5c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bcd60:     	b.lo	0x1007bce10 <_js_array_get_f64+0x180>
1007bcd64:     	tst	x20, #0xffff800000000000
1007bcd68:     	mov	w8, #0x1000             ; =4096
1007bcd6c:     	ccmp	x20, x8, #0x0, eq
1007bcd70:     	b.lo	0x1007bce10 <_js_array_get_f64+0x180>
1007bcd74:     	ldurb	w24, [x20, #-0x8]
1007bcd78:     	ldurh	w23, [x20, #-0x6]
1007bcd7c:     	cmp	w24, #0xa
1007bcd80:     	b.gt	0x1007bcf28 <_js_array_get_f64+0x298>
1007bcd84:     	cmp	w24, #0x2
1007bcd88:     	b.eq	0x1007bcffc <_js_array_get_f64+0x36c>
1007bcd8c:     	cmp	w24, #0x8
1007bcd90:     	b.ne	0x1007bce18 <_js_array_get_f64+0x188>
1007bcd94:     	mov	x0, x20
1007bcd98:     	bl	0x100304068 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007bcd9c:     	cbz	w0, 0x1007bd098 <_js_array_get_f64+0x408>
1007bcda0:     	mov	x22, #0x1               ; =1
1007bcda4:     	movk	x22, #0x7ffc, lsl #48
1007bcda8:     	lsr	x8, x20, #51
1007bcdac:     	cmp	x8, #0xfff
1007bcdb0:     	b.lo	0x1007bcdc4 <_js_array_get_f64+0x134>
1007bcdb4:     	mov	w8, #0x7ffc             ; =32764
1007bcdb8:     	cmp	x8, x20, lsr #48
1007bcdbc:     	b.eq	0x1007bd420 <_js_array_get_f64+0x790>
1007bcdc0:     	and	x20, x20, #0xffffffffffff
1007bcdc4:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bcdc8:     	b.lo	0x1007bcde8 <_js_array_get_f64+0x158>
1007bcdcc:     	tst	x20, #0xffff800000000000
1007bcdd0:     	mov	w8, #0x1000             ; =4096
1007bcdd4:     	ccmp	x20, x8, #0x0, eq
1007bcdd8:     	b.lo	0x1007bcde8 <_js_array_get_f64+0x158>
1007bcddc:     	ldurb	w8, [x20, #-0x8]
1007bcde0:     	cmp	w8, #0x2
1007bcde4:     	b.eq	0x1007bd70c <_js_array_get_f64+0xa7c>
1007bcde8:     	cbz	x20, 0x1007bd420 <_js_array_get_f64+0x790>
1007bcdec:     	mov	x0, x20
1007bcdf0:     	mov	x1, x19
1007bcdf4:     	bl	0x100304218 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007bcdf8:     	cmp	w0, #0x1
1007bcdfc:     	b.ne	0x1007bd420 <_js_array_get_f64+0x790>
1007bce00:     	ldr	x8, [x20, #0x8]
1007bce04:     	ubfiz	x9, x1, #4, #32
1007bce08:     	ldr	x22, [x8, x9]
1007bce0c:     	b	0x1007bd420 <_js_array_get_f64+0x790>
1007bce10:     	mov	w23, #0x0               ; =0
1007bce14:     	mov	w24, #0x0               ; =0
1007bce18:     	mov	x21, x22
1007bce1c:     	cmp	x25, #0xfff
1007bce20:     	b.lo	0x1007bce38 <_js_array_get_f64+0x1a8>
1007bce24:     	mov	w8, #0x7ffc             ; =32764
1007bce28:     	cmp	x8, x22, lsr #48
1007bce2c:     	b.eq	0x1007bd40c <_js_array_get_f64+0x77c>
1007bce30:     	ands	x21, x22, #0xffffffffffff
1007bce34:     	b.eq	0x1007bd40c <_js_array_get_f64+0x77c>
1007bce38:     	and	x8, x21, #0xfffffffffff00000
1007bce3c:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007bce40:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007bce44:     	cmp	x9, x10
1007bce48:     	ccmp	x8, #0x0, #0x4, lo
1007bce4c:     	b.eq	0x1007bd40c <_js_array_get_f64+0x77c>
1007bce50:     	tst	x21, #0x3
1007bce54:     	ccmp	x21, #0x7, #0x0, eq
1007bce58:     	b.ls	0x1007bd160 <_js_array_get_f64+0x4d0>
1007bce5c:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bce60:     	ldr	x8, [x8, #0x30]
1007bce64:     	cmn	x8, #0x1
1007bce68:     	b.eq	0x1007bd0b0 <_js_array_get_f64+0x420>
1007bce6c:     	mrs	x9, TPIDRRO_EL0
1007bce70:     	and	x9, x9, #0xfffffffffffffff8
1007bce74:     	ldr	x0, [x9, x8, lsl #3]
1007bce78:     	cbz	x0, 0x1007bd0b0 <_js_array_get_f64+0x420>
1007bce7c:     	lsr	x1, x21, #20
1007bce80:     	ldr	x8, [x0, #0x10]
1007bce84:     	ldrb	w9, [x8]
1007bce88:     	cmp	w9, #0x2
1007bce8c:     	b.ne	0x1007bd0c8 <_js_array_get_f64+0x438>
1007bce90:     	ldrb	w9, [x8, #0x88]
1007bce94:     	tbz	w9, #0x0, 0x1007bceb4 <_js_array_get_f64+0x224>
1007bce98:     	ldr	x9, [x8, #0x80]
1007bce9c:     	cmp	x9, x1
1007bcea0:     	b.ne	0x1007bceb4 <_js_array_get_f64+0x224>
1007bcea4:     	ldp	x9, x10, [x8, #0x60]
1007bcea8:     	cmp	x9, x21
1007bceac:     	ccmp	x10, x21, #0x0, ls
1007bceb0:     	b.hi	0x1007bd0a8 <_js_array_get_f64+0x418>
1007bceb4:     	ldrb	w9, [x8, #0xb8]
1007bceb8:     	cbz	w9, 0x1007bced8 <_js_array_get_f64+0x248>
1007bcebc:     	ldr	x9, [x8, #0xb0]
1007bcec0:     	cmp	x9, x1
1007bcec4:     	b.ne	0x1007bced8 <_js_array_get_f64+0x248>
1007bcec8:     	ldp	x9, x10, [x8, #0x90]
1007bcecc:     	cmp	x9, x21
1007bced0:     	ccmp	x10, x21, #0x0, ls
1007bced4:     	b.hi	0x1007bd570 <_js_array_get_f64+0x8e0>
1007bced8:     	ldrb	w9, [x8, #0xe8]
1007bcedc:     	cbz	w9, 0x1007bcefc <_js_array_get_f64+0x26c>
1007bcee0:     	ldr	x9, [x8, #0xe0]
1007bcee4:     	cmp	x9, x1
1007bcee8:     	b.ne	0x1007bcefc <_js_array_get_f64+0x26c>
1007bceec:     	ldp	x9, x10, [x8, #0xc0]
1007bcef0:     	cmp	x9, x21
1007bcef4:     	ccmp	x10, x21, #0x0, ls
1007bcef8:     	b.hi	0x1007bd658 <_js_array_get_f64+0x9c8>
1007bcefc:     	ldrb	w9, [x8, #0x118]
1007bcf00:     	cbz	w9, 0x1007bd128 <_js_array_get_f64+0x498>
1007bcf04:     	ldr	x9, [x8, #0x110]
1007bcf08:     	cmp	x9, x1
1007bcf0c:     	b.ne	0x1007bd128 <_js_array_get_f64+0x498>
1007bcf10:     	ldp	x9, x10, [x8, #0xf0]
1007bcf14:     	cmp	x9, x21
1007bcf18:     	ccmp	x10, x21, #0x0, ls
1007bcf1c:     	b.ls	0x1007bd128 <_js_array_get_f64+0x498>
1007bcf20:     	add	x9, x8, #0xf0
1007bcf24:     	b	0x1007bd65c <_js_array_get_f64+0x9cc>
1007bcf28:     	cmp	w24, #0xb
1007bcf2c:     	b.eq	0x1007bd014 <_js_array_get_f64+0x384>
1007bcf30:     	cmp	w24, #0xc
1007bcf34:     	b.ne	0x1007bce18 <_js_array_get_f64+0x188>
1007bcf38:     	mov	x0, x20
1007bcf3c:     	bl	0x100309df8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007bcf40:     	cbz	w0, 0x1007bd0a0 <_js_array_get_f64+0x410>
1007bcf44:     	mov	x22, #0x1               ; =1
1007bcf48:     	movk	x22, #0x7ffc, lsl #48
1007bcf4c:     	lsr	x8, x20, #51
1007bcf50:     	cmp	x8, #0xfff
1007bcf54:     	b.lo	0x1007bcf68 <_js_array_get_f64+0x2d8>
1007bcf58:     	mov	w8, #0x7ffc             ; =32764
1007bcf5c:     	cmp	x8, x20, lsr #48
1007bcf60:     	b.eq	0x1007bd420 <_js_array_get_f64+0x790>
1007bcf64:     	and	x20, x20, #0xffffffffffff
1007bcf68:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bcf6c:     	b.lo	0x1007bcf8c <_js_array_get_f64+0x2fc>
1007bcf70:     	tst	x20, #0xffff800000000000
1007bcf74:     	mov	w8, #0x1000             ; =4096
1007bcf78:     	ccmp	x20, x8, #0x0, eq
1007bcf7c:     	b.lo	0x1007bcf8c <_js_array_get_f64+0x2fc>
1007bcf80:     	ldurb	w8, [x20, #-0x8]
1007bcf84:     	cmp	w8, #0x2
1007bcf88:     	b.eq	0x1007bd724 <_js_array_get_f64+0xa94>
1007bcf8c:     	cbz	x20, 0x1007bd420 <_js_array_get_f64+0x790>
1007bcf90:     	mov	x0, x20
1007bcf94:     	mov	x1, x19
1007bcf98:     	bl	0x10030ba70 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007bcf9c:     	cmp	w0, #0x1
1007bcfa0:     	b.ne	0x1007bd420 <_js_array_get_f64+0x790>
1007bcfa4:     	ldr	x8, [x20, #0x8]
1007bcfa8:     	ldr	x22, [x8, w1, uxtw #3]
1007bcfac:     	b	0x1007bd420 <_js_array_get_f64+0x790>
1007bcfb0:     	ldr	w8, [x20]
1007bcfb4:     	cmp	w19, w8
1007bcfb8:     	b.hs	0x1007bd08c <_js_array_get_f64+0x3fc>
1007bcfbc:     	ldr	x9, [x20, #0x30]
1007bcfc0:     	cbz	x9, 0x1007bcfe8 <_js_array_get_f64+0x358>
1007bcfc4:     	ldr	x8, [x20, #0x28]
1007bcfc8:     	cbz	x8, 0x1007bcfe8 <_js_array_get_f64+0x358>
1007bcfcc:     	mov	w10, w19
1007bcfd0:     	lsr	x11, x10, #6
1007bcfd4:     	ldr	x9, [x9, x11, lsl #3]
1007bcfd8:     	lsr	x9, x9, x19
1007bcfdc:     	tbz	w9, #0x0, 0x1007bcfe8 <_js_array_get_f64+0x358>
1007bcfe0:     	ldr	x22, [x8, x10, lsl #3]
1007bcfe4:     	b	0x1007bd420 <_js_array_get_f64+0x790>
1007bcfe8:     	mov	x0, x20
1007bcfec:     	mov	x1, x19
1007bcff0:     	bl	0x10037451c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15lazy_get_rooted>
1007bcff4:     	fmov	d0, x0
1007bcff8:     	b	0x1007bd424 <_js_array_get_f64+0x794>
1007bcffc:     	mov	x0, x22
1007bd000:     	mov	x1, x19
1007bd004:     	bl	0x1005474cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bd008:     	tbnz	w0, #0x0, 0x1007bd41c <_js_array_get_f64+0x78c>
1007bd00c:     	mov	w24, #0x2               ; =2
1007bd010:     	b	0x1007bce18 <_js_array_get_f64+0x188>
1007bd014:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd018:     	add	x8, x8, #0xe80
1007bd01c:     	ldaprb	w8, [x8]
1007bd020:     	cbz	w8, 0x1007bd084 <_js_array_get_f64+0x3f4>
1007bd024:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd028:     	add	x8, x8, #0x40
1007bd02c:     	ldapr	x8, [x8]
1007bd030:     	cmp	x20, x8
1007bd034:     	b.lo	0x1007bd084 <_js_array_get_f64+0x3f4>
1007bd038:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd03c:     	add	x8, x8, #0x48
1007bd040:     	ldapr	x8, [x8]
1007bd044:     	cmp	x20, x8
1007bd048:     	b.hi	0x1007bd084 <_js_array_get_f64+0x3f4>
1007bd04c:     	mov	x0, x20
1007bd050:     	bl	0x1002a3b38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd054:     	tbz	w0, #0x0, 0x1007bd084 <_js_array_get_f64+0x3f4>
1007bd058:     	add	x0, sp, #0x8
1007bd05c:     	mov	x1, x20
1007bd060:     	bl	0x1002a396c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007bd064:     	ldr	x8, [sp, #0x8]
1007bd068:     	cbz	x8, 0x1007bd69c <_js_array_get_f64+0xa0c>
1007bd06c:     	cmp	x8, #0x1
1007bd070:     	b.ne	0x1007bd6e0 <_js_array_get_f64+0xa50>
1007bd074:     	ldr	d0, [sp, #0x10]
1007bd078:     	scvtf	d1, w19
1007bd07c:     	bl	0x10081b2f4 <_js_dyn_index_get>
1007bd080:     	b	0x1007bd41c <_js_array_get_f64+0x78c>
1007bd084:     	mov	w24, #0xb               ; =11
1007bd088:     	b	0x1007bce18 <_js_array_get_f64+0x188>
1007bd08c:     	mov	x22, #0x1               ; =1
1007bd090:     	movk	x22, #0x7ffc, lsl #48
1007bd094:     	b	0x1007bd420 <_js_array_get_f64+0x790>
1007bd098:     	mov	w24, #0x8               ; =8
1007bd09c:     	b	0x1007bce18 <_js_array_get_f64+0x188>
1007bd0a0:     	mov	w24, #0xc               ; =12
1007bd0a4:     	b	0x1007bce18 <_js_array_get_f64+0x188>
1007bd0a8:     	add	x9, x8, #0x60
1007bd0ac:     	b	0x1007bd65c <_js_array_get_f64+0x9cc>
1007bd0b0:     	bl	0x100b3df7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007bd0b4:     	lsr	x1, x21, #20
1007bd0b8:     	ldr	x8, [x0, #0x10]
1007bd0bc:     	ldrb	w9, [x8]
1007bd0c0:     	cmp	w9, #0x2
1007bd0c4:     	b.eq	0x1007bce90 <_js_array_get_f64+0x200>
1007bd0c8:     	ldr	x9, [x8, #0x8]
1007bd0cc:     	ldr	x10, [x8, #0x28]
1007bd0d0:     	sub	x9, x1, x9
1007bd0d4:     	cmp	x9, x10
1007bd0d8:     	b.hs	0x1007bd11c <_js_array_get_f64+0x48c>
1007bd0dc:     	ldr	x10, [x8, #0x20]
1007bd0e0:     	mov	w11, #0x28              ; =40
1007bd0e4:     	madd	x9, x9, x11, x10
1007bd0e8:     	ldr	x10, [x9]
1007bd0ec:     	ldr	x11, [x8, #0x10]
1007bd0f0:     	cmp	x10, x11
1007bd0f4:     	b.ne	0x1007bd128 <_js_array_get_f64+0x498>
1007bd0f8:     	ldp	x10, x11, [x9, #0x8]
1007bd0fc:     	cmp	x10, x21
1007bd100:     	ccmp	x11, x21, #0x0, ls
1007bd104:     	b.ls	0x1007bd128 <_js_array_get_f64+0x498>
1007bd108:     	ldr	x10, [x8, #0x30]
1007bd10c:     	add	x10, x10, #0x1
1007bd110:     	str	x10, [x8, #0x30]
1007bd114:     	add	x8, x9, #0x21
1007bd118:     	b	0x1007bd66c <_js_array_get_f64+0x9dc>
1007bd11c:     	ldr	x9, [x8, #0x58]
1007bd120:     	add	x9, x9, #0x1
1007bd124:     	str	x9, [x8, #0x58]
1007bd128:     	ldr	x9, [x8, #0x38]
1007bd12c:     	add	x9, x9, #0x1
1007bd130:     	str	x9, [x8, #0x38]
1007bd134:     	mov	x0, x21
1007bd138:     	bl	0x10051d208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007bd13c:     	and	w8, w0, #0xff
1007bd140:     	cbz	w8, 0x1007bd160 <_js_array_get_f64+0x4d0>
1007bd144:     	ldurb	w8, [x21, #-0x8]
1007bd148:     	ldurb	w9, [x21, #-0x7]
1007bd14c:     	mov	w10, #0x82              ; =130
1007bd150:     	and	w9, w9, w10
1007bd154:     	cmp	w9, #0x2
1007bd158:     	ccmp	w8, #0x1, #0x0, eq
1007bd15c:     	b.eq	0x1007bd230 <_js_array_get_f64+0x5a0>
1007bd160:     	mov	x0, x21
1007bd164:     	bl	0x100579880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd168:     	cbz	x0, 0x1007bd190 <_js_array_get_f64+0x500>
1007bd16c:     	ldrb	w9, [x0]
1007bd170:     	cmp	w9, #0x1
1007bd174:     	b.ne	0x1007bd1ac <_js_array_get_f64+0x51c>
1007bd178:     	ldrsb	w8, [x0, #0x1]
1007bd17c:     	tbnz	w8, #0x1f, 0x1007bd258 <_js_array_get_f64+0x5c8>
1007bd180:     	ldp	w10, w9, [x21]
1007bd184:     	cmp	w10, w9
1007bd188:     	b.hi	0x1007bd2e4 <_js_array_get_f64+0x654>
1007bd18c:     	b	0x1007bd2fc <_js_array_get_f64+0x66c>
1007bd190:     	mov	x25, x0
1007bd194:     	mov	x0, x21
1007bd198:     	bl	0x1005880b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd19c:     	tbz	w0, #0x0, 0x1007bd1e8 <_js_array_get_f64+0x558>
1007bd1a0:     	mov	x0, #0x0                ; =0
1007bd1a4:     	mov	x8, x25
1007bd1a8:     	b	0x1007bd2d4 <_js_array_get_f64+0x644>
1007bd1ac:     	mov	x8, x0
1007bd1b0:     	cmp	w9, #0x1
1007bd1b4:     	b.eq	0x1007bd2d4 <_js_array_get_f64+0x644>
1007bd1b8:     	cmp	w9, #0x9
1007bd1bc:     	b.ne	0x1007bd40c <_js_array_get_f64+0x77c>
1007bd1c0:     	ldr	w8, [x21, #0x4]
1007bd1c4:     	mov	w9, #0x5841             ; =22593
1007bd1c8:     	movk	w9, #0x4c5a, lsl #16
1007bd1cc:     	cmp	w8, w9
1007bd1d0:     	b.ne	0x1007bd40c <_js_array_get_f64+0x77c>
1007bd1d4:     	mov	x0, x21
1007bd1d8:     	bl	0x100374d0c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007bd1dc:     	cbz	x0, 0x1007bd40c <_js_array_get_f64+0x77c>
1007bd1e0:     	mov	x21, x0
1007bd1e4:     	b	0x1007bd318 <_js_array_get_f64+0x688>
1007bd1e8:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd1ec:     	add	x8, x8, #0xe80
1007bd1f0:     	ldaprb	w8, [x8]
1007bd1f4:     	cbz	w8, 0x1007bd40c <_js_array_get_f64+0x77c>
1007bd1f8:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd1fc:     	add	x8, x8, #0x40
1007bd200:     	ldapr	x8, [x8]
1007bd204:     	cmp	x8, x21
1007bd208:     	b.hi	0x1007bd40c <_js_array_get_f64+0x77c>
1007bd20c:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd210:     	add	x8, x8, #0x48
1007bd214:     	ldapr	x8, [x8]
1007bd218:     	cmp	x8, x21
1007bd21c:     	b.lo	0x1007bd40c <_js_array_get_f64+0x77c>
1007bd220:     	mov	x0, x21
1007bd224:     	bl	0x1002a3b38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd228:     	tbnz	w0, #0x0, 0x1007bd1a0 <_js_array_get_f64+0x510>
1007bd22c:     	b	0x1007bd40c <_js_array_get_f64+0x77c>
1007bd230:     	ldr	w8, [x21]
1007bd234:     	mov	w9, #0xe100             ; =57600
1007bd238:     	movk	w9, #0x5f5, lsl #16
1007bd23c:     	orr	w9, w9, #0x1
1007bd240:     	cmp	w8, w9
1007bd244:     	b.hs	0x1007bd160 <_js_array_get_f64+0x4d0>
1007bd248:     	ldr	w9, [x21, #0x4]
1007bd24c:     	cmp	w8, w9
1007bd250:     	b.ls	0x1007bd318 <_js_array_get_f64+0x688>
1007bd254:     	b	0x1007bd160 <_js_array_get_f64+0x4d0>
1007bd258:     	mov	x25, x0
1007bd25c:     	ldr	x21, [x0, #0x8]
1007bd260:     	mov	x0, x21
1007bd264:     	bl	0x100579880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd268:     	cbz	x0, 0x1007bd40c <_js_array_get_f64+0x77c>
1007bd26c:     	ldrb	w8, [x0]
1007bd270:     	cmp	w8, #0x1
1007bd274:     	b.ne	0x1007bd40c <_js_array_get_f64+0x77c>
1007bd278:     	ldrsb	w8, [x0, #0x1]
1007bd27c:     	tbz	w8, #0x1f, 0x1007bd180 <_js_array_get_f64+0x4f0>
1007bd280:     	mov	w26, #0x1               ; =1
1007bd284:     	ldr	x21, [x0, #0x8]
1007bd288:     	mov	x0, x21
1007bd28c:     	bl	0x100579880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bd290:     	cbz	x0, 0x1007bd40c <_js_array_get_f64+0x77c>
1007bd294:     	ldrb	w8, [x0]
1007bd298:     	cmp	w8, #0x1
1007bd29c:     	b.ne	0x1007bd40c <_js_array_get_f64+0x77c>
1007bd2a0:     	cmp	w26, #0x3f
1007bd2a4:     	b.hi	0x1007bd40c <_js_array_get_f64+0x77c>
1007bd2a8:     	add	w26, w26, #0x1
1007bd2ac:     	ldrsb	w8, [x0, #0x1]
1007bd2b0:     	tbnz	w8, #0x1f, 0x1007bd284 <_js_array_get_f64+0x5f4>
1007bd2b4:     	str	x21, [x25, #0x8]
1007bd2b8:     	ldrb	w8, [x25, #0x1]
1007bd2bc:     	orr	w9, w8, #0x80
1007bd2c0:     	mov	x8, x25
1007bd2c4:     	strb	w9, [x25, #0x1]
1007bd2c8:     	ldrb	w9, [x0]
1007bd2cc:     	cmp	w9, #0x1
1007bd2d0:     	b.ne	0x1007bd1b8 <_js_array_get_f64+0x528>
1007bd2d4:     	ldp	w10, w9, [x21]
1007bd2d8:     	cmp	w10, w9
1007bd2dc:     	b.ls	0x1007bd2fc <_js_array_get_f64+0x66c>
1007bd2e0:     	cbz	x8, 0x1007bd30c <_js_array_get_f64+0x67c>
1007bd2e4:     	ldr	w8, [x0, #0x4]
1007bd2e8:     	ubfiz	x9, x9, #3, #32
1007bd2ec:     	add	x9, x9, #0x10
1007bd2f0:     	cmp	x9, x8
1007bd2f4:     	b.eq	0x1007bd318 <_js_array_get_f64+0x688>
1007bd2f8:     	b	0x1007bd30c <_js_array_get_f64+0x67c>
1007bd2fc:     	mov	w8, #0xe100             ; =57600
1007bd300:     	movk	w8, #0x5f5, lsl #16
1007bd304:     	cmp	w10, w8
1007bd308:     	b.ls	0x1007bd318 <_js_array_get_f64+0x688>
1007bd30c:     	mov	x0, x21
1007bd310:     	bl	0x1005880b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd314:     	tbz	w0, #0x0, 0x1007bd3c8 <_js_array_get_f64+0x738>
1007bd318:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd31c:     	add	x8, x8, #0xe80
1007bd320:     	ldaprb	w8, [x8]
1007bd324:     	cbz	w8, 0x1007bd36c <_js_array_get_f64+0x6dc>
1007bd328:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd32c:     	add	x8, x8, #0x40
1007bd330:     	ldapr	x8, [x8]
1007bd334:     	cmp	x21, x8
1007bd338:     	b.lo	0x1007bd36c <_js_array_get_f64+0x6dc>
1007bd33c:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd340:     	add	x8, x8, #0x48
1007bd344:     	ldapr	x8, [x8]
1007bd348:     	cmp	x21, x8
1007bd34c:     	b.hi	0x1007bd36c <_js_array_get_f64+0x6dc>
1007bd350:     	mov	x0, x21
1007bd354:     	bl	0x1002a3b38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd358:     	tbz	w0, #0x0, 0x1007bd36c <_js_array_get_f64+0x6dc>
1007bd35c:     	mov	x0, x21
1007bd360:     	mov	x1, x19
1007bd364:     	bl	0x1008fb048 <_js_typed_array_get>
1007bd368:     	b	0x1007bd41c <_js_array_get_f64+0x78c>
1007bd36c:     	mov	x0, x21
1007bd370:     	bl	0x1005880b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bd374:     	tbz	w0, #0x0, 0x1007bd39c <_js_array_get_f64+0x70c>
1007bd378:     	mov	x0, x21
1007bd37c:     	mov	x1, x19
1007bd380:     	bl	0x1005853dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007bd384:     	and	w8, w1, #0xff
1007bd388:     	ucvtf	d0, w8
1007bd38c:     	fmov	x8, d0
1007bd390:     	tst	w0, #0x1
1007bd394:     	csel	x22, x8, xzr, ne
1007bd398:     	b	0x1007bd420 <_js_array_get_f64+0x790>
1007bd39c:     	cmp	x21, x20
1007bd3a0:     	b.eq	0x1007bd448 <_js_array_get_f64+0x7b8>
1007bd3a4:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007bd3a8:     	b.lo	0x1007bd440 <_js_array_get_f64+0x7b0>
1007bd3ac:     	tst	x21, #0xffff800000000000
1007bd3b0:     	mov	w8, #0x1000             ; =4096
1007bd3b4:     	ccmp	x21, x8, #0x0, eq
1007bd3b8:     	b.lo	0x1007bd440 <_js_array_get_f64+0x7b0>
1007bd3bc:     	ldurb	w24, [x21, #-0x8]
1007bd3c0:     	ldurh	w23, [x21, #-0x6]
1007bd3c4:     	b	0x1007bd448 <_js_array_get_f64+0x7b8>
1007bd3c8:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd3cc:     	add	x8, x8, #0xe80
1007bd3d0:     	ldaprb	w8, [x8]
1007bd3d4:     	cbz	w8, 0x1007bd40c <_js_array_get_f64+0x77c>
1007bd3d8:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd3dc:     	add	x8, x8, #0x40
1007bd3e0:     	ldapr	x8, [x8]
1007bd3e4:     	cmp	x21, x8
1007bd3e8:     	b.lo	0x1007bd40c <_js_array_get_f64+0x77c>
1007bd3ec:     	adrp	x8, 0x100f7c000 <_perry_global_access_worker_ts__1>
1007bd3f0:     	add	x8, x8, #0x48
1007bd3f4:     	ldapr	x8, [x8]
1007bd3f8:     	cmp	x21, x8
1007bd3fc:     	b.hi	0x1007bd40c <_js_array_get_f64+0x77c>
1007bd400:     	mov	x0, x21
1007bd404:     	bl	0x1002a3b38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bd408:     	tbnz	w0, #0x0, 0x1007bd318 <_js_array_get_f64+0x688>
1007bd40c:     	mov	x0, x22
1007bd410:     	mov	x1, x19
1007bd414:     	bl	0x1005474cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bd418:     	tbz	w0, #0x0, 0x1007bd6f0 <_js_array_get_f64+0xa60>
1007bd41c:     	fmov	x22, d0
1007bd420:     	fmov	d0, x22
1007bd424:     	ldp	x29, x30, [sp, #0x60]
1007bd428:     	ldp	x20, x19, [sp, #0x50]
1007bd42c:     	ldp	x22, x21, [sp, #0x40]
1007bd430:     	ldp	x24, x23, [sp, #0x30]
1007bd434:     	ldp	x26, x25, [sp, #0x20]
1007bd438:     	add	sp, sp, #0x70
1007bd43c:     	ret
1007bd440:     	mov	w23, #0x0               ; =0
1007bd444:     	mov	w24, #0x0               ; =0
1007bd448:     	cmp	w24, #0x1
1007bd44c:     	b.ne	0x1007bd600 <_js_array_get_f64+0x970>
1007bd450:     	tbz	w23, #0xa, 0x1007bd600 <_js_array_get_f64+0x970>
1007bd454:     	adrp	x8, 0x100b63000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data1n7OFFSETS+0x26>
1007bd458:     	add	x8, x8, #0x98c
1007bd45c:     	cmp	w19, #0x3e8
1007bd460:     	b.lo	0x1007bd4d8 <_js_array_get_f64+0x848>
1007bd464:     	mov	x9, #0x0                ; =0
1007bd468:     	mov	w11, #0x1759            ; =5977
1007bd46c:     	movk	w11, #0xd1b7, lsl #16
1007bd470:     	mov	w12, #0x2710            ; =10000
1007bd474:     	mov	w13, #0x147b            ; =5243
1007bd478:     	mov	w14, #0x64              ; =100
1007bd47c:     	add	x15, sp, #0x8
1007bd480:     	mov	w16, #0x967f            ; =38527
1007bd484:     	movk	w16, #0x98, lsl #16
1007bd488:     	mov	x10, x19
1007bd48c:     	mov	x17, x10
1007bd490:     	umull	x10, w10, w11
1007bd494:     	lsr	x10, x10, #45
1007bd498:     	msub	w0, w10, w12, w17
1007bd49c:     	ubfx	w1, w0, #2, #14
1007bd4a0:     	mul	w1, w1, w13
1007bd4a4:     	lsr	w1, w1, #17
1007bd4a8:     	msub	w0, w1, w14, w0
1007bd4ac:     	add	x2, x15, x9
1007bd4b0:     	ldrh	w1, [x8, w1, uxtw #1]
1007bd4b4:     	strh	w1, [x2, #0x6]
1007bd4b8:     	and	x0, x0, #0xffff
1007bd4bc:     	ldrh	w0, [x8, x0, lsl #1]
1007bd4c0:     	strh	w0, [x2, #0x8]
1007bd4c4:     	sub	x9, x9, #0x4
1007bd4c8:     	cmp	w17, w16
1007bd4cc:     	b.hi	0x1007bd48c <_js_array_get_f64+0x7fc>
1007bd4d0:     	add	x9, x9, #0xa
1007bd4d4:     	b	0x1007bd4e0 <_js_array_get_f64+0x850>
1007bd4d8:     	mov	w9, #0xa                ; =10
1007bd4dc:     	mov	x10, x19
1007bd4e0:     	cmp	w10, #0x9
1007bd4e4:     	b.ls	0x1007bd518 <_js_array_get_f64+0x888>
1007bd4e8:     	sub	x9, x9, #0x2
1007bd4ec:     	ubfx	w11, w10, #2, #14
1007bd4f0:     	mov	w12, #0x147b            ; =5243
1007bd4f4:     	mul	w11, w11, w12
1007bd4f8:     	lsr	w11, w11, #17
1007bd4fc:     	mov	w12, #0x64              ; =100
1007bd500:     	msub	w10, w11, w12, w10
1007bd504:     	and	x10, x10, #0xffff
1007bd508:     	ldrh	w10, [x8, x10, lsl #1]
1007bd50c:     	add	x12, sp, #0x8
1007bd510:     	strh	w10, [x12, x9]
1007bd514:     	mov	x10, x11
1007bd518:     	cbz	w19, 0x1007bd550 <_js_array_get_f64+0x8c0>
1007bd51c:     	cbnz	w10, 0x1007bd550 <_js_array_get_f64+0x8c0>
1007bd520:     	cmp	x9, #0xa
1007bd524:     	b.ne	0x1007bd578 <_js_array_get_f64+0x8e8>
1007bd528:     	mov	w23, #0x1               ; =1
1007bd52c:     	add	x0, sp, #0x8
1007bd530:     	mov	x1, x21
1007bd534:     	mov	w2, #0x1                ; =1
1007bd538:     	mov	x3, #0x0                ; =0
1007bd53c:     	bl	0x1005b17bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bd540:     	ldr	x8, [sp, #0x8]
1007bd544:     	mov	w20, #0x1               ; =1
1007bd548:     	cbnz	x8, 0x1007bd5c8 <_js_array_get_f64+0x938>
1007bd54c:     	b	0x1007bd600 <_js_array_get_f64+0x970>
1007bd550:     	sub	x23, x9, #0x1
1007bd554:     	ubfiz	w10, w10, #1, #4
1007bd558:     	add	x8, x8, x10
1007bd55c:     	ldrb	w8, [x8, #0x1]
1007bd560:     	add	x10, sp, #0x8
1007bd564:     	strb	w8, [x10, x23]
1007bd568:     	mov	w8, #0xb                ; =11
1007bd56c:     	b	0x1007bd580 <_js_array_get_f64+0x8f0>
1007bd570:     	add	x9, x8, #0x90
1007bd574:     	b	0x1007bd65c <_js_array_get_f64+0x9cc>
1007bd578:     	mov	w8, #0xa                ; =10
1007bd57c:     	mov	x23, x9
1007bd580:     	sub	x22, x8, x9
1007bd584:     	mov	x0, x22
1007bd588:     	mov	w1, #0x1                ; =1
1007bd58c:     	bl	0x100b5ddc8 <_mi_malloc_aligned>
1007bd590:     	cbz	x0, 0x1007bd73c <_js_array_get_f64+0xaac>
1007bd594:     	mov	x20, x0
1007bd598:     	add	x8, sp, #0x8
1007bd59c:     	add	x1, x8, x23
1007bd5a0:     	mov	x2, x22
1007bd5a4:     	bl	0x100b609ec <_writev+0x100b609ec>
1007bd5a8:     	add	x0, sp, #0x8
1007bd5ac:     	mov	x1, x21
1007bd5b0:     	mov	x2, x20
1007bd5b4:     	mov	x3, x22
1007bd5b8:     	bl	0x1005b17bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bd5bc:     	ldr	w8, [sp, #0x8]
1007bd5c0:     	tbz	w8, #0x0, 0x1007bd5f8 <_js_array_get_f64+0x968>
1007bd5c4:     	mov	w23, #0x0               ; =0
1007bd5c8:     	mov	x22, #0x1               ; =1
1007bd5cc:     	movk	x22, #0x7ffc, lsl #48
1007bd5d0:     	ldr	x0, [sp, #0x10]
1007bd5d4:     	cbz	x0, 0x1007bd68c <_js_array_get_f64+0x9fc>
1007bd5d8:     	cbz	x21, 0x1007bd67c <_js_array_get_f64+0x9ec>
1007bd5dc:     	lsr	x8, x21, #52
1007bd5e0:     	cmp	x8, #0x7fe
1007bd5e4:     	b.hi	0x1007bd680 <_js_array_get_f64+0x9f0>
1007bd5e8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007bd5ec:     	bfxil	x8, x21, #0, #48
1007bd5f0:     	mov	x21, x8
1007bd5f4:     	b	0x1007bd680 <_js_array_get_f64+0x9f0>
1007bd5f8:     	mov	x0, x20
1007bd5fc:     	bl	0x100b5db40 <_mi_free>
1007bd600:     	ldr	w8, [x21]
1007bd604:     	cmp	w19, w8
1007bd608:     	b.hs	0x1007bd648 <_js_array_get_f64+0x9b8>
1007bd60c:     	ldr	w8, [x21, #0x4]
1007bd610:     	cmp	w19, w8
1007bd614:     	b.hs	0x1007bd638 <_js_array_get_f64+0x9a8>
1007bd618:     	add	x8, x21, w19, uxtw #3
1007bd61c:     	ldr	x22, [x8, #0x8]
1007bd620:     	mov	x8, #0x1                ; =1
1007bd624:     	movk	x8, #0x7ffc, lsl #48
1007bd628:     	add	x8, x8, #0xf
1007bd62c:     	cmp	x22, x8
1007bd630:     	b.ne	0x1007bd420 <_js_array_get_f64+0x790>
1007bd634:     	b	0x1007bd648 <_js_array_get_f64+0x9b8>
1007bd638:     	mov	x0, x21
1007bd63c:     	mov	x1, x19
1007bd640:     	bl	0x1005298c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007bd644:     	tbnz	w0, #0x0, 0x1007bd41c <_js_array_get_f64+0x78c>
1007bd648:     	mov	x0, x21
1007bd64c:     	mov	x1, x19
1007bd650:     	bl	0x1006c60d8 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007bd654:     	b	0x1007bd41c <_js_array_get_f64+0x78c>
1007bd658:     	add	x9, x8, #0xc0
1007bd65c:     	ldr	x10, [x8, #0x30]
1007bd660:     	add	x10, x10, #0x1
1007bd664:     	str	x10, [x8, #0x30]
1007bd668:     	add	x8, x9, #0x19
1007bd66c:     	ldrb	w8, [x8]
1007bd670:     	cmp	w8, #0xff
1007bd674:     	b.ne	0x1007bd140 <_js_array_get_f64+0x4b0>
1007bd678:     	b	0x1007bd134 <_js_array_get_f64+0x4a4>
1007bd67c:     	add	x21, x22, #0x1
1007bd680:     	fmov	d0, x21
1007bd684:     	bl	0x1006fbefc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007bd688:     	mov	x22, x0
1007bd68c:     	tbnz	w23, #0x0, 0x1007bd420 <_js_array_get_f64+0x790>
1007bd690:     	mov	x0, x20
1007bd694:     	bl	0x100b5db40 <_mi_free>
1007bd698:     	b	0x1007bd420 <_js_array_get_f64+0x790>
1007bd69c:     	ldr	x20, [sp, #0x10]
1007bd6a0:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
1007bd6a4:     	ldr	x8, [x8, #0xe98]
1007bd6a8:     	cbz	x8, 0x1007bd6c0 <_js_array_get_f64+0xa30>
1007bd6ac:     	mov	x0, x20
1007bd6b0:     	bl	0x10013bbc0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007bd6b4:     	tbz	w0, #0x0, 0x1007bd6c0 <_js_array_get_f64+0xa30>
1007bd6b8:     	mov	x0, x20
1007bd6bc:     	bl	0x1002bdd40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007bd6c0:     	tbnz	w19, #0x1f, 0x1007bd6e0 <_js_array_get_f64+0xa50>
1007bd6c4:     	ldr	w8, [x20]
1007bd6c8:     	cmp	w19, w8
1007bd6cc:     	b.hs	0x1007bd6e0 <_js_array_get_f64+0xa50>
1007bd6d0:     	mov	w1, w19
1007bd6d4:     	mov	x0, x20
1007bd6d8:     	bl	0x1002a3fcc <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007bd6dc:     	b	0x1007bd41c <_js_array_get_f64+0x78c>
1007bd6e0:     	mov	x8, #0x1                ; =1
1007bd6e4:     	movk	x8, #0x7ffc, lsl #48
1007bd6e8:     	mov	x22, x8
1007bd6ec:     	b	0x1007bd420 <_js_array_get_f64+0x790>
1007bd6f0:     	mov	x0, x22
1007bd6f4:     	bl	0x100b464b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007bd6f8:     	cmp	x0, #0x1
1007bd6fc:     	b.ne	0x1007bccd0 <_js_array_get_f64+0x40>
1007bd700:     	mov	x0, x19
1007bd704:     	bl	0x100b464d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007bd708:     	b	0x1007bd41c <_js_array_get_f64+0x78c>
1007bd70c:     	mov	x0, x20
1007bd710:     	mov	w1, #0x0                ; =0
1007bd714:     	bl	0x100b48a40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bd718:     	mov	x20, x0
1007bd71c:     	cbnz	x0, 0x1007bcdec <_js_array_get_f64+0x15c>
1007bd720:     	b	0x1007bd420 <_js_array_get_f64+0x790>
1007bd724:     	mov	x0, x20
1007bd728:     	mov	w1, #0x1                ; =1
1007bd72c:     	bl	0x100b48a40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bd730:     	mov	x20, x0
1007bd734:     	cbnz	x0, 0x1007bcf90 <_js_array_get_f64+0x300>
1007bd738:     	b	0x1007bd420 <_js_array_get_f64+0x790>
1007bd73c:     	mov	w0, #0x1                ; =1
1007bd740:     	mov	x1, x22
1007bd744:     	bl	0x100b10f00 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
