
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/materialized-read-r23/main-access-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010037773c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get>:
10037773c:     	sub	sp, sp, #0xc0
100377740:     	stp	x28, x27, [sp, #0x60]
100377744:     	stp	x26, x25, [sp, #0x70]
100377748:     	stp	x24, x23, [sp, #0x80]
10037774c:     	stp	x22, x21, [sp, #0x90]
100377750:     	stp	x20, x19, [sp, #0xa0]
100377754:     	stp	x29, x30, [sp, #0xb0]
100377758:     	add	x29, sp, #0xb0
10037775c:     	mov	x20, #0x1               ; =1
100377760:     	movk	x20, #0x7ffc, lsl #48
100377764:     	cbz	x0, 0x100377b94 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x458>
100377768:     	mov	x19, x1
10037776c:     	mov	x21, x0
100377770:     	bl	0x10028a298 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100377774:     	str	x0, [sp, #0x10]
100377778:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10037777c:     	stp	x21, x8, [sp, #0x28]
100377780:     	mov	w8, #0x1                ; =1
100377784:     	str	x8, [sp, #0x20]
100377788:     	add	x0, sp, #0x20
10037778c:     	bl	0x10028a3a0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100377790:     	mov	x21, x0
100377794:     	str	x0, [sp, #0x18]
100377798:     	adrp	x24, 0x100f7c000 <_perry_global_access_worker_ts__1>
10037779c:     	ldr	x8, [x24, #0x30]
1003777a0:     	cmn	x8, #0x1
1003777a4:     	b.eq	0x10037780c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0xd0>
1003777a8:     	mrs	x9, TPIDRRO_EL0
1003777ac:     	and	x9, x9, #0xfffffffffffffff8
1003777b0:     	ldr	x8, [x9, x8, lsl #3]
1003777b4:     	cbz	x8, 0x10037780c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0xd0>
1003777b8:     	ldr	x8, [x8, #0x19e8]
1003777bc:     	cbz	x8, 0x10037780c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0xd0>
1003777c0:     	ldr	x9, [x8]
1003777c4:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1003777c8:     	cmp	x9, x10
1003777cc:     	b.hs	0x100377bb8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x47c>
1003777d0:     	add	x10, x9, #0x1
1003777d4:     	str	x10, [x8]
1003777d8:     	ldr	x10, [x8, #0x18]
1003777dc:     	cmp	x21, x10
1003777e0:     	b.hs	0x100377bc4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x488>
1003777e4:     	ldr	x10, [x8, #0x10]
1003777e8:     	mov	w11, #0x18              ; =24
1003777ec:     	madd	x10, x21, x11, x10
1003777f0:     	ldr	x11, [x10]
1003777f4:     	cmp	x11, #0x1
1003777f8:     	b.ne	0x100377bc8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x48c>
1003777fc:     	ldr	x22, [x10, #0x8]
100377800:     	str	x9, [x8]
100377804:     	cbnz	x22, 0x10037781c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0xe0>
100377808:     	b	0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
10037780c:     	mov	x0, x21
100377810:     	bl	0x10013b118 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100377814:     	mov	x22, x0
100377818:     	cbz	x0, 0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
10037781c:     	mov	x0, x22
100377820:     	bl	0x1006870dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100377824:     	cbz	x0, 0x100377838 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0xfc>
100377828:     	mov	x1, x19
10037782c:     	bl	0x1007bcc50 <_js_array_get_f64>
100377830:     	fmov	x20, d0
100377834:     	b	0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
100377838:     	ldr	w23, [x22]
10037783c:     	cmp	w19, w23
100377840:     	b.hs	0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
100377844:     	ldr	x9, [x22, #0x30]
100377848:     	cbz	x9, 0x100377870 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x134>
10037784c:     	ldr	x8, [x22, #0x28]
100377850:     	cbz	x8, 0x100377870 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x134>
100377854:     	mov	w10, w19
100377858:     	lsr	x11, x10, #6
10037785c:     	ldr	x9, [x9, x11, lsl #3]
100377860:     	lsr	x9, x9, x10
100377864:     	tbz	w9, #0x0, 0x100377870 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x134>
100377868:     	ldr	x20, [x8, x10, lsl #3]
10037786c:     	b	0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
100377870:     	stp	xzr, x21, [sp, #0x20]
100377874:     	ldr	w25, [x22, #0x8]
100377878:     	ldr	x8, [x24, #0x30]
10037787c:     	cmn	x8, #0x1
100377880:     	b.eq	0x1003778e4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x1a8>
100377884:     	mrs	x9, TPIDRRO_EL0
100377888:     	and	x9, x9, #0xfffffffffffffff8
10037788c:     	ldr	x8, [x9, x8, lsl #3]
100377890:     	cbz	x8, 0x1003778e4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x1a8>
100377894:     	ldr	x8, [x8, #0x19e8]
100377898:     	cbz	x8, 0x1003778e4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x1a8>
10037789c:     	ldr	x9, [x8]
1003778a0:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1003778a4:     	cmp	x9, x10
1003778a8:     	b.hs	0x100377bb8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x47c>
1003778ac:     	add	x10, x9, #0x1
1003778b0:     	str	x10, [x8]
1003778b4:     	ldr	x10, [x8, #0x18]
1003778b8:     	cmp	x21, x10
1003778bc:     	b.hs	0x100377bc4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x488>
1003778c0:     	ldr	x10, [x8, #0x10]
1003778c4:     	mov	w11, #0x18              ; =24
1003778c8:     	madd	x10, x21, x11, x10
1003778cc:     	ldr	x11, [x10]
1003778d0:     	cmp	x11, #0x1
1003778d4:     	b.ne	0x100377bc8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x48c>
1003778d8:     	ldr	x0, [x10, #0x8]
1003778dc:     	str	x9, [x8]
1003778e0:     	b	0x1003778ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x1b0>
1003778e4:     	mov	x0, x21
1003778e8:     	bl	0x10013b118 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
1003778ec:     	cbz	x0, 0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
1003778f0:     	ldr	w8, [x0, #0xc]
1003778f4:     	cmp	w25, w8
1003778f8:     	b.hs	0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
1003778fc:     	ldr	x8, [x0, #0x10]
100377900:     	cbz	x8, 0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
100377904:     	mov	w9, #0xc                ; =12
100377908:     	umaddl	x8, w25, w9, x8
10037790c:     	ldrb	w9, [x8, #0x8]
100377910:     	cmp	w9, #0x3
100377914:     	b.ne	0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
100377918:     	ldr	w28, [x8, #0x4]
10037791c:     	ldr	w26, [x22, #0x38]
100377920:     	cmn	w26, #0x1
100377924:     	b.eq	0x10037793c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x200>
100377928:     	cmp	w19, w26
10037792c:     	b.lo	0x10037793c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x200>
100377930:     	ldr	w25, [x22, #0x3c]
100377934:     	mov	x9, x26
100377938:     	b	0x100377944 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x208>
10037793c:     	mov	w9, #0x0                ; =0
100377940:     	add	x25, x25, #0x1
100377944:     	str	x25, [sp, #0x40]
100377948:     	cmp	x25, x28
10037794c:     	cset	w8, lo
100377950:     	str	w9, [sp, #0xc]
100377954:     	b.hs	0x100377a2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x2f0>
100377958:     	cmp	w19, w9
10037795c:     	b.ls	0x100377a2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x2f0>
100377960:     	add	w27, w9, #0x1
100377964:     	ldr	x8, [x24, #0x30]
100377968:     	cmn	x8, #0x1
10037796c:     	b.eq	0x1003779d0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x294>
100377970:     	mrs	x9, TPIDRRO_EL0
100377974:     	and	x9, x9, #0xfffffffffffffff8
100377978:     	ldr	x8, [x9, x8, lsl #3]
10037797c:     	cbz	x8, 0x1003779d0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x294>
100377980:     	ldr	x8, [x8, #0x19e8]
100377984:     	cbz	x8, 0x1003779d0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x294>
100377988:     	ldr	x9, [x8]
10037798c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100377990:     	cmp	x9, x10
100377994:     	b.hs	0x100377bb8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x47c>
100377998:     	add	x10, x9, #0x1
10037799c:     	str	x10, [x8]
1003779a0:     	ldr	x10, [x8, #0x18]
1003779a4:     	cmp	x21, x10
1003779a8:     	b.hs	0x100377bc4 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x488>
1003779ac:     	ldr	x10, [x8, #0x10]
1003779b0:     	mov	w11, #0x18              ; =24
1003779b4:     	madd	x10, x21, x11, x10
1003779b8:     	ldr	x11, [x10]
1003779bc:     	cmp	x11, #0x1
1003779c0:     	b.ne	0x100377bc8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x48c>
1003779c4:     	ldr	x0, [x10, #0x8]
1003779c8:     	str	x9, [x8]
1003779cc:     	b	0x1003779d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x29c>
1003779d0:     	mov	x0, x21
1003779d4:     	bl	0x10013b118 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
1003779d8:     	cbz	x0, 0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
1003779dc:     	ldr	w8, [x0, #0xc]
1003779e0:     	cmp	x25, x8
1003779e4:     	b.hs	0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
1003779e8:     	ldr	x8, [x0, #0x10]
1003779ec:     	cbz	x8, 0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
1003779f0:     	mov	w9, #0xc                ; =12
1003779f4:     	madd	x8, x25, x9, x8
1003779f8:     	ldrb	w9, [x8, #0x8]
1003779fc:     	orr	w9, w9, #0x2
100377a00:     	cmp	w9, #0x3
100377a04:     	b.ne	0x100377a0c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x2d0>
100377a08:     	ldr	w25, [x8, #0x4]
100377a0c:     	add	x25, x25, #0x1
100377a10:     	str	x25, [sp, #0x40]
100377a14:     	cmp	x25, x28
100377a18:     	cset	w8, lo
100377a1c:     	b.hs	0x100377a2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x2f0>
100377a20:     	cmp	w27, w19
100377a24:     	add	w27, w27, #0x1
100377a28:     	b.lo	0x100377964 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x228>
100377a2c:     	tbz	w8, #0x0, 0x100377b8c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x450>
100377a30:     	ldr	w8, [sp, #0xc]
100377a34:     	sub	w8, w19, w8
100377a38:     	add	w9, w26, #0x1
100377a3c:     	cmp	w19, w9
100377a40:     	ccmn	w26, #0x1, #0x4, eq
100377a44:     	b.eq	0x100377a58 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x31c>
100377a48:     	ldr	w9, [x22, #0x48]
100377a4c:     	adds	w9, w9, #0x1
100377a50:     	csinv	w21, w9, wzr, lo
100377a54:     	b	0x100377a5c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x320>
100377a58:     	mov	w21, #0x1               ; =1
100377a5c:     	str	w21, [x22, #0x48]
100377a60:     	stp	w19, w25, [x22, #0x38]
100377a64:     	ldr	x9, [x22, #0x40]
100377a68:     	adds	x8, x9, x8
100377a6c:     	csinv	x8, x8, xzr, lo
100377a70:     	str	x8, [x22, #0x40]
100377a74:     	add	x8, sp, #0x20
100377a78:     	add	x9, sp, #0x10
100377a7c:     	stp	x8, x9, [sp, #0x48]
100377a80:     	add	x8, sp, #0x40
100377a84:     	str	x8, [sp, #0x58]
100377a88:     	cmp	w21, #0x1
100377a8c:     	b.ls	0x100377aac <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x370>
100377a90:     	add	x0, sp, #0x48
100377a94:     	bl	0x100215184 <__RNCNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get0B5_>
100377a98:     	mov	x8, x0
100377a9c:     	tbz	w8, #0x0, 0x100377aa8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x36c>
100377aa0:     	mov	x0, x1
100377aa4:     	b	0x100377abc <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x380>
100377aa8:     	ldr	x25, [sp, #0x40]
100377aac:     	str	x25, [sp, #0x48]
100377ab0:     	add	x0, sp, #0x20
100377ab4:     	add	x1, sp, #0x48
100377ab8:     	bl	0x100376c60 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24materialize_value_source>
100377abc:     	stp	xzr, x0, [sp, #0x48]
100377ac0:     	add	x0, sp, #0x48
100377ac4:     	bl	0x10028a3a0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100377ac8:     	str	x0, [sp, #0x48]
100377acc:     	add	x0, sp, #0x18
100377ad0:     	bl	0x10013f958 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle10across_mutNtNtBc_9json_tape15LazyArrayHeaderuNCNvB1D_19reparse_materializes_0EBc_>
100377ad4:     	ldr	x22, [x0, #0x30]
100377ad8:     	cbz	x22, 0x100377b24 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x3e8>
100377adc:     	ldr	x24, [x0, #0x28]
100377ae0:     	cbz	x24, 0x100377b24 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x3e8>
100377ae4:     	mov	x20, x0
100377ae8:     	add	x0, sp, #0x48
100377aec:     	bl	0x100266aec <__RNvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB5_13RuntimeHandle14get_nanbox_u64>
100377af0:     	mov	x2, x0
100377af4:     	mov	w25, w19
100377af8:     	add	x1, x24, w19, uxtw #3
100377afc:     	str	x0, [x1]
100377b00:     	mov	x0, x20
100377b04:     	bl	0x1003747b0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape20note_lazy_cache_slot>
100377b08:     	mov	w8, #0x1                ; =1
100377b0c:     	lsl	x8, x8, x25
100377b10:     	lsr	x9, x25, #3
100377b14:     	and	x9, x9, #0x1ffffff8
100377b18:     	ldr	x10, [x22, x9]
100377b1c:     	orr	x8, x10, x8
100377b20:     	str	x8, [x22, x9]
100377b24:     	add	x0, sp, #0x18
100377b28:     	bl	0x10013f958 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle10across_mutNtNtBc_9json_tape15LazyArrayHeaderuNCNvB1D_19reparse_materializes_0EBc_>
100377b2c:     	lsr	w8, w23, #6
100377b30:     	mov	w9, #0x40               ; =64
100377b34:     	cmp	w8, #0x40
100377b38:     	csel	w8, w8, w9, hi
100377b3c:     	cmp	w21, w8
100377b40:     	b.hs	0x100377b54 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x418>
100377b44:     	ldr	x8, [x0, #0x40]
100377b48:     	cmp	x8, x23, lsl #1
100377b4c:     	b.hi	0x100377b7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x440>
100377b50:     	b	0x100377b80 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x444>
100377b54:     	mov	x19, x0
100377b58:     	bl	0x1003744dc <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape17lazy_cached_count>
100377b5c:     	mov	x8, x0
100377b60:     	mov	x0, x19
100377b64:     	ldr	x9, [x19, #0x40]
100377b68:     	cmp	x9, x23, lsl #1
100377b6c:     	b.hi	0x100377b7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x440>
100377b70:     	lsl	x8, x8, #1
100377b74:     	cmp	x8, x23
100377b78:     	b.hs	0x100377b80 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape8lazy_get+0x444>
100377b7c:     	bl	0x100374830 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100377b80:     	add	x0, sp, #0x48
100377b84:     	bl	0x100266aec <__RNvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB5_13RuntimeHandle14get_nanbox_u64>
100377b88:     	mov	x20, x0
100377b8c:     	add	x0, sp, #0x10
100377b90:     	bl	0x100165cfc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100377b94:     	mov	x0, x20
100377b98:     	ldp	x29, x30, [sp, #0xb0]
100377b9c:     	ldp	x20, x19, [sp, #0xa0]
100377ba0:     	ldp	x22, x21, [sp, #0x90]
100377ba4:     	ldp	x24, x23, [sp, #0x80]
100377ba8:     	ldp	x26, x25, [sp, #0x70]
100377bac:     	ldp	x28, x27, [sp, #0x60]
100377bb0:     	add	sp, sp, #0xc0
100377bb4:     	ret
100377bb8:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100377bbc:     	add	x0, x0, #0xd70
100377bc0:     	bl	0x100b111dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100377bc4:     	bl	0x100b4a3d4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
100377bc8:     	adrp	x0, 0x100c40000 <_anon.3a0f55142d697dd4d6c50f8035b0d3d6.3+0x54c0>
100377bcc:     	add	x0, x0, #0xc67
100377bd0:     	mov	w1, #0xb                ; =11
100377bd4:     	bl	0x100b4a39c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
