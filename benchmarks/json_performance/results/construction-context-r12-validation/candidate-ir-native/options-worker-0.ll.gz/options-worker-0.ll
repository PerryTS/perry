; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/construction-context-r12/candidate-ir-native/options-worker/.perry-trace/llvm/options_worker_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@options_worker_ts_.str.0 = private unnamed_addr constant [125 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/construction-context-r12/options-worker.ts\00"
@options_worker_ts_.str.0.bytes = private unnamed_addr constant [6 x i8] c"plain\00"
@options_worker_ts_.str.1.bytes = private unnamed_addr constant [7 x i8] c"length\00"
@options_worker_ts_.str.2.bytes = private unnamed_addr constant [13 x i8] c"dynamic-zero\00"
@options_worker_ts_.str.3.bytes = private unnamed_addr constant [5 x i8] c"zero\00"
@options_worker_ts_.str.4.bytes = private unnamed_addr constant [7 x i8] c"pretty\00"
@options_worker_ts_.str.5.bytes = private unnamed_addr constant [5 x i8] c"keys\00"
@options_worker_ts_.str.6.bytes = private unnamed_addr constant [9 x i8] c"callback\00"
@options_worker_ts_.str.7.bytes = private unnamed_addr constant [3 x i8] c"fs\00"
@options_worker_ts_.str.8.bytes = private unnamed_addr constant [13 x i8] c"readFileSync\00"
@options_worker_ts_.str.9.bytes = private unnamed_addr constant [5 x i8] c"utf8\00"
@options_worker_ts_.str.10.bytes = private unnamed_addr constant [2 x i8] c"0\00"
@options_worker_ts_.str.11.bytes = private unnamed_addr constant [9 x i8] c"{\22data\22:\00"
@options_worker_ts_.str.12.bytes = private unnamed_addr constant [2 x i8] c"}\00"
@options_worker_ts_.str.13.bytes = private unnamed_addr constant [5 x i8] c"data\00"
@options_worker_ts_.str.14.bytes = private unnamed_addr constant [3 x i8] c"id\00"
@options_worker_ts_.str.15.bytes = private unnamed_addr constant [5 x i8] c"name\00"
@options_worker_ts_.str.16.bytes = private unnamed_addr constant [6 x i8] c"email\00"
@options_worker_ts_.str.17.bytes = private unnamed_addr constant [7 x i8] c"active\00"
@options_worker_ts_.str.18.bytes = private unnamed_addr constant [6 x i8] c"score\00"
@options_worker_ts_.str.19.bytes = private unnamed_addr constant [5 x i8] c"tags\00"
@options_worker_ts_.str.20.bytes = private unnamed_addr constant [4 x i8] c"rss\00"
@options_worker_ts_.str.21.bytes = private unnamed_addr constant [7 x i8] c"RESULT\00"
@options_worker_ts_.str.22.bytes = private unnamed_addr constant [5 x i8] c"user\00"
@options_worker_ts_.str.23.bytes = private unnamed_addr constant [7 x i8] c"system\00"
@options_worker_ts_.str.24.bytes = private unnamed_addr constant [7 x i8] c"verify\00"
@options_worker_ts_.str.25.bytes = private unnamed_addr constant [7 x i8] c"VERIFY\00"
@options_worker_ts_.str.26.bytes = private unnamed_addr constant [5 x i8] c"KEEP\00"
@options_worker_ts_.str.1 = private unnamed_addr constant [9 x i8] c"identity\00"
@options_worker_ts_.str.2 = private unnamed_addr constant [4 x i8] c"run\00"
@options_worker_ts_.str.3 = private unnamed_addr constant [66 x i8] c"function identity(key: string, value: any): any { return value; }\00"
@options_worker_ts_.str.4 = private unnamed_addr constant [1282 x i8] c"function run(count: number): number {\0A    let sum = 0;\0A    if (operation === 'plain') {\0A        for (let i = 0; i < count; i++) {\0A            const result = JSON.stringify(input);\0A            sum += result.length; last = result;\0A        }\0A    } else if (operation === 'dynamic-zero') {\0A        for (let i = 0; i < count; i++) {\0A            const result = JSON.stringify(input, null, dynamicSpacer);\0A            sum += result.length; last = result;\0A        }\0A    } else if (operation === 'zero') {\0A        for (let i = 0; i < count; i++) {\0A            const result = JSON.stringify(input, null, 0);\0A            sum += result.length; last = result;\0A        }\0A    } else if (operation === 'pretty') {\0A        for (let i = 0; i < count; i++) {\0A            const result = JSON.stringify(input, null, 2);\0A            sum += result.length; last = result;\0A        }\0A    } else if (operation === 'keys') {\0A        for (let i = 0; i < count; i++) {\0A            const result = JSON.stringify(input, keys);\0A            sum += result.length; last = result;\0A        }\0A    } else if (operation === 'callback') {\0A        for (let i = 0; i < count; i++) {\0A            const result = JSON.stringify(input, identity);\0A            sum += result.length; last = result;\0A        }\0A    }\0A    return sum;\0A}\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_options_worker_ts = internal global i32 0
@perry_global_options_worker_ts__1 = global double 0x7FFC000000000001
@perry_global_options_worker_ts__2 = global double 0x7FFC000000000001
@perry_global_options_worker_ts__5 = global double 0x7FFC000000000001
@perry_global_options_worker_ts__6 = global double 0x7FFC000000000001
@perry_global_options_worker_ts__7 = global double 0x7FFC000000000001
@perry_ic_options_worker_ts__1 = private global ptr null
@perry_ic_options_worker_ts__3 = private global ptr null
@perry_ic_options_worker_ts__5 = private global ptr null
@perry_ic_options_worker_ts__7 = private global ptr null
@perry_ic_options_worker_ts__9 = private global ptr null
@perry_ic_options_worker_ts__11 = private global ptr null
@perry_ic_options_worker_ts__13 = private global ptr null
@perry_ic_options_worker_ts__15 = private global ptr null
@perry_ic_options_worker_ts__17 = private global ptr null
@perry_ic_options_worker_ts__19 = private global ptr null
@perry_ic_options_worker_ts__21 = private global ptr null
@perry_ic_options_worker_ts__23 = private global ptr null
@perry_ic_options_worker_ts__30 = private global ptr null
@perry_ic_options_worker_ts__32 = private global ptr null
@perry_ic_options_worker_ts__34 = private global ptr null
@perry_ic_options_worker_ts__36 = private global ptr null
@perry_ic_options_worker_ts__38 = private global ptr null
@perry_ic_options_worker_ts__40 = private global ptr null
@perry_ic_options_worker_ts__42 = private global ptr null
@options_worker_ts_.str.0.handle = internal global double 0.000000e+00
@options_worker_ts_.str.1.handle = internal global double 0.000000e+00
@options_worker_ts_.str.2.handle = internal global double 0.000000e+00
@options_worker_ts_.str.3.handle = internal global double 0.000000e+00
@options_worker_ts_.str.4.handle = internal global double 0.000000e+00
@options_worker_ts_.str.5.handle = internal global double 0.000000e+00
@options_worker_ts_.str.6.handle = internal global double 0.000000e+00
@options_worker_ts_.str.7.handle = internal global double 0.000000e+00
@options_worker_ts_.str.8.handle = internal global double 0.000000e+00
@options_worker_ts_.str.9.handle = internal global double 0.000000e+00
@options_worker_ts_.str.10.handle = internal global double 0.000000e+00
@options_worker_ts_.str.11.handle = internal global double 0.000000e+00
@options_worker_ts_.str.12.handle = internal global double 0.000000e+00
@options_worker_ts_.str.13.handle = internal global double 0.000000e+00
@options_worker_ts_.str.14.handle = internal global double 0.000000e+00
@options_worker_ts_.str.15.handle = internal global double 0.000000e+00
@options_worker_ts_.str.16.handle = internal global double 0.000000e+00
@options_worker_ts_.str.17.handle = internal global double 0.000000e+00
@options_worker_ts_.str.18.handle = internal global double 0.000000e+00
@options_worker_ts_.str.19.handle = internal global double 0.000000e+00
@options_worker_ts_.str.20.handle = internal global double 0.000000e+00
@options_worker_ts_.str.21.handle = internal global double 0.000000e+00
@options_worker_ts_.str.22.handle = internal global double 0.000000e+00
@options_worker_ts_.str.23.handle = internal global double 0.000000e+00
@options_worker_ts_.str.24.handle = internal global double 0.000000e+00
@options_worker_ts_.str.25.handle = internal global double 0.000000e+00
@options_worker_ts_.str.26.handle = internal global double 0.000000e+00

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_1()

declare double @__ic_decl_3()

declare double @__ic_decl_5()

declare double @__ic_decl_7()

declare double @__ic_decl_9()

declare double @__ic_decl_11()

declare double @__ic_decl_13()

declare double @__ic_decl_15()

declare double @__ic_decl_17()

declare double @__ic_decl_19()

declare double @__ic_decl_21()

declare double @__ic_decl_23()

declare double @__ic_decl_30()

declare double @__ic_decl_32()

declare double @__ic_decl_34()

declare double @__ic_decl_36()

declare double @__ic_decl_38()

declare double @__ic_decl_40()

declare double @__ic_decl_42()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define internal double @"perry_fn_options_worker_ts__identity$spec_b_b"(double %arg14, double %arg15) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %arg14 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg15 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  ret double %r3
}

; Function Attrs: optsize
define internal double @"perry_fn_options_worker_ts__run$spec_b"(double %arg16) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b7 = bitcast double %arg16 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r3 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r4 = load double, ptr @options_worker_ts_.str.0.handle, align 8
  %r5 = bitcast double %r3 to i64
  %r6 = bitcast double %r4 to i64
  %r7 = icmp eq i64 %r5, %r6
  br i1 %r7, label %streqlit.true.7, label %streqlit.sso.1

streqlit.sso.1:                                   ; preds = %entry.0
  %r8 = icmp eq i64 %r5, 9221407683790335088
  br i1 %r8, label %streqlit.true.7, label %streqlit.tag.2

streqlit.tag.2:                                   ; preds = %streqlit.sso.1
  %r9 = lshr i64 %r5, 48
  %r10 = icmp eq i64 %r9, 32767
  %r11 = and i64 %r5, 281474976710655
  %r12 = icmp ugt i64 %r11, 4095
  %r13 = and i1 %r10, %r12
  br i1 %r13, label %streqlit.len.3, label %streqlit.false.8

streqlit.len.3:                                   ; preds = %streqlit.tag.2
  %r14 = inttoptr i64 %r11 to ptr
  %r15 = getelementptr inbounds nuw i8, ptr %r14, i64 4
  %r16 = load i32, ptr %r15, align 4
  %r17 = icmp eq i32 %r16, 5
  br i1 %r17, label %streqlit.b0.4, label %streqlit.false.8

streqlit.b0.4:                                    ; preds = %streqlit.len.3
  %r18 = getelementptr inbounds nuw i8, ptr %r14, i64 20
  %r19 = load i8, ptr %r18, align 1
  %r20 = icmp eq i8 %r19, 112
  br i1 %r20, label %streqlit.bl.5, label %streqlit.false.8

streqlit.bl.5:                                    ; preds = %streqlit.b0.4
  %r21 = getelementptr inbounds nuw i8, ptr %r14, i64 24
  %r22 = load i8, ptr %r21, align 1
  %r23 = icmp eq i8 %r22, 110
  br i1 %r23, label %streqlit.slow.6, label %streqlit.false.8

streqlit.slow.6:                                  ; preds = %streqlit.bl.5
  %r24 = and i64 %r6, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r11, i64 %r24, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7) ]
  %r254 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s7, %rs4gc.s7)
  %r26 = icmp ne i32 %r254, 0
  br label %streqlit.merge.9

streqlit.true.7:                                  ; preds = %streqlit.sso.1, %entry.0
  br label %streqlit.merge.9

streqlit.false.8:                                 ; preds = %streqlit.bl.5, %streqlit.b0.4, %streqlit.len.3, %streqlit.tag.2
  br label %streqlit.merge.9

streqlit.merge.9:                                 ; preds = %streqlit.false.8, %streqlit.true.7, %streqlit.slow.6
  %.0 = phi ptr addrspace(1) [ %rs4gc.s7, %streqlit.true.7 ], [ %rs4gc.s7.relocated, %streqlit.slow.6 ], [ %rs4gc.s7, %streqlit.false.8 ]
  %r27 = phi i1 [ true, %streqlit.true.7 ], [ false, %streqlit.false.8 ], [ %r26, %streqlit.slow.6 ]
  %r28 = select i1 %r27, i64 9222246136947933188, i64 9222246136947933187
  %r29 = bitcast i64 %r28 to double
  %r30 = icmp eq i64 %r28, 9222246136947933188
  br i1 %r30, label %if.then.10, label %if.else.11

if.then.10:                                       ; preds = %streqlit.merge.9
  %r35.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r35.rs4o = call i64 asm "", "=r,0"(i64 %r35.rs4i) #9
  %r35 = bitcast i64 %r35.rs4o to double
  %r36 = bitcast double %r35 to i64
  %r37 = and i64 %r36, -281474976710656
  %r38 = icmp ult i64 %r37, 9221401712017801216
  %r39 = icmp ugt i64 %r37, 9223090561878065152
  %r40 = or i1 %r38, %r39
  br i1 %r40, label %for.bound_i32.number.13, label %for.bound_i32.merge.15

if.else.11:                                       ; preds = %streqlit.merge.9
  %r258 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r259 = load double, ptr @options_worker_ts_.str.2.handle, align 8
  %r260 = bitcast double %r258 to i64
  %r261 = bitcast double %r259 to i64
  %r262 = icmp eq i64 %r260, %r261
  br i1 %r262, label %streqlit.true.75, label %streqlit.tag.70

if.merge.12:                                      ; preds = %if.merge.80, %for.exit.21
  %r2.0 = phi double [ %r2.1, %for.exit.21 ], [ %r2.2, %if.merge.80 ]
  ret double %r2.0

for.bound_i32.number.13:                          ; preds = %if.then.10
  %r41 = fcmp oge double %r35, 0xC1E0000000000000
  %r42 = fcmp ole double %r35, 0x41DFFFFFFFC00000
  %r43 = and i1 %r41, %r42
  br i1 %r43, label %for.bound_i32.convert.14, label %for.bound_i32.merge.15

for.bound_i32.convert.14:                         ; preds = %for.bound_i32.number.13
  %r44 = fptosi double %r35 to i32
  %r45 = sitofp i32 %r44 to double
  %r46 = fcmp oeq double %r45, %r35
  br i1 %r46, label %for.counter_i32.range.16, label %for.bound_i32.merge.15

for.bound_i32.merge.15:                           ; preds = %for.counter_i32.convert.17, %for.bound_i32.convert.14, %for.bound_i32.number.13, %if.then.10
  %r34.0 = phi i32 [ %r44, %for.counter_i32.convert.17 ], [ 0, %if.then.10 ], [ %r44, %for.bound_i32.convert.14 ], [ 0, %for.bound_i32.number.13 ]
  %r33.0 = phi i1 [ true, %for.counter_i32.convert.17 ], [ false, %if.then.10 ], [ false, %for.bound_i32.convert.14 ], [ false, %for.bound_i32.number.13 ]
  br label %for.cond.18

for.counter_i32.range.16:                         ; preds = %for.bound_i32.convert.14
  br label %for.counter_i32.convert.17

for.counter_i32.convert.17:                       ; preds = %for.counter_i32.range.16
  br label %for.bound_i32.merge.15

for.cond.18:                                      ; preds = %for.update.20, %for.bound_i32.merge.15
  %.1 = phi ptr addrspace(1) [ %.0, %for.bound_i32.merge.15 ], [ %.7, %for.update.20 ]
  %r32.1 = phi i32 [ 0, %for.bound_i32.merge.15 ], [ %r257, %for.update.20 ]
  %r31.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.15 ], [ %r255, %for.update.20 ]
  %r2.1 = phi double [ 0.000000e+00, %for.bound_i32.merge.15 ], [ %r246, %for.update.20 ]
  br i1 %r33.0, label %for.cond.fast.22, label %for.cond.slow.23

for.body.19:                                      ; preds = %gcpoll.done.25, %for.cond.fast.22
  %.2 = phi ptr addrspace(1) [ %.1, %for.cond.fast.22 ], [ %.3, %gcpoll.done.25 ]
  %r67 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r67, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r6810 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token5)
  %rs4gc.s7.relocated11 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 0, i32 0) ; (%.2, %.2)
  %r69 = bitcast i64 %r6810 to double
  %rs4gc.b8 = bitcast double %r69 to i64
  %rs4gc.s8 = inttoptr i64 %rs4gc.b8 to ptr addrspace(1)
  %r70.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r70 = call i64 asm "", "=r,0"(i64 %r70.rs4i) #9
  %r71 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r72 = icmp ne i32 %r71, 0
  br i1 %r72, label %shadow.root.barrier.26, label %shadow.root.barrier.done.27

for.update.20:                                    ; preds = %gcpoll.done.69
  %r255 = fadd double %r31.0, 1.000000e+00
  %r257 = add i32 %r32.1, 1
  br label %for.cond.18

for.exit.21:                                      ; preds = %gcpoll.done.25, %for.cond.fast.22
  br label %if.merge.12

for.cond.fast.22:                                 ; preds = %for.cond.18
  %r57 = icmp slt i32 %r32.1, %r34.0
  br i1 %r57, label %for.body.19, label %for.exit.21

for.cond.slow.23:                                 ; preds = %for.cond.18
  %r59.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r59.rs4o = call i64 asm "", "=r,0"(i64 %r59.rs4i) #9
  %r59 = bitcast i64 %r59.rs4o to double
  %r60 = fcmp olt double %r31.0, %r59
  %r61 = select i1 %r60, i64 9222246136947933188, i64 9222246136947933187
  %r62 = bitcast i64 %r61 to double
  %r64 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r65 = icmp ne i32 %r64, 0
  br i1 %r65, label %gcpoll.24, label %gcpoll.done.25

gcpoll.24:                                        ; preds = %for.cond.slow.23
  %statepoint_token12 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1) ]
  %rs4gc.s7.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token12, i32 0, i32 0) ; (%.1, %.1)
  br label %gcpoll.done.25

gcpoll.done.25:                                   ; preds = %gcpoll.24, %for.cond.slow.23
  %.3 = phi ptr addrspace(1) [ %rs4gc.s7.relocated13, %gcpoll.24 ], [ %.1, %for.cond.slow.23 ]
  %r63 = icmp eq i64 %r61, 9222246136947933188
  br i1 %r63, label %for.body.19, label %for.exit.21

shadow.root.barrier.26:                           ; preds = %for.body.19
  call void @js_write_barrier_root_nanbox(i64 %r70) #9
  br label %shadow.root.barrier.done.27

shadow.root.barrier.done.27:                      ; preds = %shadow.root.barrier.26, %for.body.19
  %r74 = bitcast double %r2.1 to i64
  %rs4gc.s9 = inttoptr i64 %r74 to ptr addrspace(1)
  %r76.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r76 = call i64 asm "", "=r,0"(i64 %r76.rs4i) #9
  %r77 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r78 = icmp ne i32 %r77, 0
  br i1 %r78, label %shadow.root.barrier.28, label %shadow.root.barrier.done.29

shadow.root.barrier.28:                           ; preds = %shadow.root.barrier.done.27
  call void @js_write_barrier_root_nanbox(i64 %r76) #9
  br label %shadow.root.barrier.done.29

shadow.root.barrier.done.29:                      ; preds = %shadow.root.barrier.28, %shadow.root.barrier.done.27
  %r79.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r79.rs4o = call i64 asm "", "=r,0"(i64 %r79.rs4i) #9
  %r79 = bitcast i64 %r79.rs4o to double
  %r80 = bitcast double %r79 to i64
  %r81 = and i64 %r80, 281474976710655
  %r82 = lshr i64 %r80, 48
  %r83 = and i64 %r82, 65533
  %r84 = icmp eq i64 %r83, 32765
  br i1 %r84, label %pget.recv_ok.31, label %pget.recv_other.36

pget.recv_sso.30:                                 ; preds = %pget.recv_other.36
  %r223 = lshr i64 %r80, 40
  %r224 = and i64 %r223, 255
  %r225 = uitofp nneg i64 %r224 to double
  br label %pget.recv_merge.34

pget.recv_ok.31:                                  ; preds = %shadow.root.barrier.done.29
  %r91 = icmp eq i64 %r82, 32767
  br i1 %r91, label %pget.strlen_heap.35, label %pget.recv_obj.38

pget.recv_bad.32:                                 ; preds = %pget.check_class_ref.37
  %r215 = icmp eq i64 %r80, 9222246136947933185
  %r216 = icmp eq i64 %r80, 9222246136947933186
  %r217 = or i1 %r215, %r216
  br i1 %r217, label %pget.throw_nullish.61, label %pget.recv_undef_return.62

pget.recv_class_ref.33:                           ; preds = %pget.check_class_ref.37
  %r87 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r88 = bitcast double %r87 to i64
  %r89 = and i64 %r88, 281474976710655
  %statepoint_token14 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532864, i64 %r80, i64 %r89, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated11, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r9015 = call double @llvm.experimental.gc.result.f64(token %statepoint_token14)
  %rs4gc.s7.relocated16 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token14, i32 0, i32 0) ; (%rs4gc.s7.relocated11, %rs4gc.s7.relocated11)
  %rs4gc.s8.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token14, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token14, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pget.recv_merge.34

pget.recv_merge.34:                               ; preds = %pget.recv_undef_return.62, %pic.merge.53, %pget.strlen_heap.35, %pget.recv_class_ref.33, %pget.recv_sso.30
  %.0210 = phi ptr addrspace(1) [ %rs4gc.s9, %pget.strlen_heap.35 ], [ %.1211, %pic.merge.53 ], [ %rs4gc.s9, %pget.recv_sso.30 ], [ %rs4gc.s9.relocated, %pget.recv_class_ref.33 ], [ %rs4gc.s9.relocated32, %pget.recv_undef_return.62 ]
  %.0207 = phi ptr addrspace(1) [ %rs4gc.s8, %pget.strlen_heap.35 ], [ %.1208, %pic.merge.53 ], [ %rs4gc.s8, %pget.recv_sso.30 ], [ %rs4gc.s8.relocated, %pget.recv_class_ref.33 ], [ %rs4gc.s8.relocated31, %pget.recv_undef_return.62 ]
  %.4 = phi ptr addrspace(1) [ %rs4gc.s7.relocated11, %pget.strlen_heap.35 ], [ %.5, %pic.merge.53 ], [ %rs4gc.s7.relocated11, %pget.recv_sso.30 ], [ %rs4gc.s7.relocated16, %pget.recv_class_ref.33 ], [ %rs4gc.s7.relocated30, %pget.recv_undef_return.62 ]
  %r231 = phi double [ %r214, %pic.merge.53 ], [ %r22229, %pget.recv_undef_return.62 ], [ %r225, %pget.recv_sso.30 ], [ %r9015, %pget.recv_class_ref.33 ], [ %r230, %pget.strlen_heap.35 ]
  %r232.rs4i = ptrtoint ptr addrspace(1) %.0210 to i64
  %r232 = call i64 asm "", "=r,0"(i64 %r232.rs4i) #9
  %r233 = bitcast i64 %r232 to double
  %r234 = and i64 %r232, -281474976710656
  %r235 = icmp ult i64 %r234, 9221401712017801216
  %r236 = icmp ugt i64 %r234, 9223090561878065152
  %r237 = or i1 %r235, %r236
  %r238 = bitcast double %r231 to i64
  %r239 = and i64 %r238, -281474976710656
  %r240 = icmp ult i64 %r239, 9221401712017801216
  %r241 = icmp ugt i64 %r239, 9223090561878065152
  %r242 = or i1 %r240, %r241
  %r243 = and i1 %r237, %r242
  br i1 %r243, label %guarded_add.numeric.63, label %guarded_add.dynamic.64

pget.strlen_heap.35:                              ; preds = %pget.recv_ok.31
  %r226 = icmp ult i64 %r81, 4096
  %r227 = inttoptr i64 %r81 to ptr
  %r228 = select i1 %r226, ptr @perry_null_guard_zero_options_worker_ts, ptr %r227
  %r229 = load i32, ptr %r228, align 4
  %r230 = uitofp i32 %r229 to double
  br label %pget.recv_merge.34

pget.recv_other.36:                               ; preds = %shadow.root.barrier.done.29
  %r85 = icmp eq i64 %r82, 32761
  br i1 %r85, label %pget.recv_sso.30, label %pget.check_class_ref.37

pget.check_class_ref.37:                          ; preds = %pget.recv_other.36
  %r86 = icmp eq i64 %r82, 32766
  br i1 %r86, label %pget.recv_class_ref.33, label %pget.recv_bad.32

pget.recv_obj.38:                                 ; preds = %pget.recv_ok.31
  %r92 = icmp ugt i64 %r81, 1048575
  br i1 %r92, label %pic.recv_hdr.54, label %pic.miss.cold.51

pic.hit.39:                                       ; preds = %pic.token.55
  %r117 = getelementptr i64, ptr %r102, i64 1
  %r118 = load i64, ptr %r117, align 8
  %r119 = and i64 %r118, 1073741824
  %r120 = icmp ne i64 %r119, 0
  br i1 %r120, label %pic.hit.overflow.56, label %pic.hit.inline.57

pic.hit.live.40:                                  ; preds = %pic.hit.inline.57
  br label %pic.merge.53

pic.prefix.guard.41:                              ; preds = %pic.token.55
  %r133 = getelementptr i64, ptr %r102, i64 2
  %r134 = load i64, ptr %r133, align 8
  %r135 = icmp ne i64 %r134, 0
  br i1 %r135, label %pic.prefix.meta.42, label %pic.miss.50

pic.prefix.meta.42:                               ; preds = %pic.prefix.guard.41
  %r136 = add nuw nsw i64 %r81, 8
  %r137 = inttoptr i64 %r136 to ptr
  %r138 = load i64, ptr %r137, align 8
  %r139 = icmp ne i64 %r138, 0
  br i1 %r139, label %pic.prefix.token.43, label %pic.miss.50

pic.prefix.token.43:                              ; preds = %pic.prefix.meta.42
  %r140 = inttoptr i64 %r138 to ptr
  %r141 = getelementptr i64, ptr %r140, i64 6
  %r142 = load i64, ptr %r141, align 8
  %r143 = icmp eq i64 %r142, %r134
  br i1 %r143, label %pic.prefix.hit.44, label %pic.miss.50

pic.prefix.hit.44:                                ; preds = %pic.prefix.token.43
  %r144 = getelementptr i64, ptr %r102, i64 1
  %r145 = load i64, ptr %r144, align 8
  %r146 = shl i64 %r145, 3
  %r147 = add nuw nsw i64 %r81, 16
  %r148 = add i64 %r147, %r146
  %r149 = inttoptr i64 %r148 to ptr
  %r150 = load double, ptr %r149, align 8
  br label %pic.merge.53

pic.desc.classify.45:                             ; preds = %pic.recv_hdr.54
  %r106 = and i1 %r96, %r103
  br i1 %r106, label %pic.desc.prefix.guard.46, label %pic.miss.cold.51

pic.desc.prefix.guard.46:                         ; preds = %pic.desc.classify.45
  %r151 = getelementptr i64, ptr %r102, i64 2
  %r152 = load i64, ptr %r151, align 8
  %r153 = icmp ne i64 %r152, 0
  br i1 %r153, label %pic.desc.prefix.meta.47, label %pic.miss.cold.51

pic.desc.prefix.meta.47:                          ; preds = %pic.desc.prefix.guard.46
  %r154 = add nuw nsw i64 %r81, 8
  %r155 = inttoptr i64 %r154 to ptr
  %r156 = load i64, ptr %r155, align 8
  %r157 = icmp ne i64 %r156, 0
  br i1 %r157, label %pic.desc.prefix.token.48, label %pic.miss.cold.51

pic.desc.prefix.token.48:                         ; preds = %pic.desc.prefix.meta.47
  %r158 = inttoptr i64 %r156 to ptr
  %r159 = getelementptr i64, ptr %r158, i64 6
  %r160 = load i64, ptr %r159, align 8
  %r161 = icmp eq i64 %r160, %r152
  br i1 %r161, label %pic.desc.prefix.hit.49, label %pic.miss.cold.51

pic.desc.prefix.hit.49:                           ; preds = %pic.desc.prefix.token.48
  %r162 = getelementptr i64, ptr %r102, i64 1
  %r163 = load i64, ptr %r162, align 8
  %r164 = shl i64 %r163, 3
  %r165 = add nuw nsw i64 %r81, 16
  %r166 = add i64 %r165, %r164
  %r167 = inttoptr i64 %r166 to ptr
  %r168 = load double, ptr %r167, align 8
  br label %pic.merge.53

pic.miss.50:                                      ; preds = %pic.hit.inline.57, %pic.prefix.token.43, %pic.prefix.meta.42, %pic.prefix.guard.41
  %r169 = getelementptr i64, ptr %r102, i64 3
  %r170 = load i64, ptr %r169, align 8
  %r171 = icmp sgt i64 %r170, 0
  br i1 %r171, label %pic.ways.58, label %pic.miss.call.52

pic.miss.cold.51:                                 ; preds = %pic.desc.prefix.token.48, %pic.desc.prefix.meta.47, %pic.desc.prefix.guard.46, %pic.desc.classify.45, %pget.recv_obj.38
  br label %pic.miss.call.52

pic.miss.call.52:                                 ; preds = %pic.way.load.59, %pic.ways.58, %pic.miss.cold.51, %pic.miss.50
  %r210 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r211 = bitcast double %r210 to i64
  %r212 = and i64 %r211, 281474976710655
  %statepoint_token17 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r81, i64 %r212, ptr @perry_ic_options_worker_ts__1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated11, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r21318 = call double @llvm.experimental.gc.result.f64(token %statepoint_token17)
  %rs4gc.s7.relocated19 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token17, i32 0, i32 0) ; (%rs4gc.s7.relocated11, %rs4gc.s7.relocated11)
  %rs4gc.s8.relocated20 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token17, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated21 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token17, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pic.merge.53

pic.merge.53:                                     ; preds = %pic.way.live.60, %pic.hit.overflow.56, %pic.miss.call.52, %pic.desc.prefix.hit.49, %pic.prefix.hit.44, %pic.hit.live.40
  %.1211 = phi ptr addrspace(1) [ %rs4gc.s9.relocated26, %pic.hit.overflow.56 ], [ %rs4gc.s9.relocated21, %pic.miss.call.52 ], [ %rs4gc.s9, %pic.way.live.60 ], [ %rs4gc.s9, %pic.hit.live.40 ], [ %rs4gc.s9, %pic.prefix.hit.44 ], [ %rs4gc.s9, %pic.desc.prefix.hit.49 ]
  %.1208 = phi ptr addrspace(1) [ %rs4gc.s8.relocated25, %pic.hit.overflow.56 ], [ %rs4gc.s8.relocated20, %pic.miss.call.52 ], [ %rs4gc.s8, %pic.way.live.60 ], [ %rs4gc.s8, %pic.hit.live.40 ], [ %rs4gc.s8, %pic.prefix.hit.44 ], [ %rs4gc.s8, %pic.desc.prefix.hit.49 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s7.relocated24, %pic.hit.overflow.56 ], [ %rs4gc.s7.relocated19, %pic.miss.call.52 ], [ %rs4gc.s7.relocated11, %pic.way.live.60 ], [ %rs4gc.s7.relocated11, %pic.hit.live.40 ], [ %rs4gc.s7.relocated11, %pic.prefix.hit.44 ], [ %rs4gc.s7.relocated11, %pic.desc.prefix.hit.49 ]
  %r214 = phi double [ %r130, %pic.hit.live.40 ], [ %r12523, %pic.hit.overflow.56 ], [ %r150, %pic.prefix.hit.44 ], [ %r168, %pic.desc.prefix.hit.49 ], [ %r207, %pic.way.live.60 ], [ %r21318, %pic.miss.call.52 ]
  br label %pget.recv_merge.34

pic.recv_hdr.54:                                  ; preds = %pget.recv_obj.38
  %r93 = sub nuw nsw i64 %r81, 8
  %r94 = inttoptr i64 %r93 to ptr
  %r95 = load i8, ptr %r94, align 1
  %r96 = icmp eq i8 %r95, 2
  %r97 = sub nuw nsw i64 %r81, 6
  %r98 = inttoptr i64 %r97 to ptr
  %r99 = load i16, ptr %r98, align 2
  %r100 = and i16 %r99, 2048
  %r101 = icmp eq i16 %r100, 0
  %r102 = load ptr, ptr @perry_ic_options_worker_ts__1, align 8
  %r103 = icmp ne ptr %r102, null
  %r104 = and i1 %r96, %r101
  %r105 = and i1 %r104, %r103
  br i1 %r105, label %pic.token.55, label %pic.desc.classify.45

pic.token.55:                                     ; preds = %pic.recv_hdr.54
  %r107 = add nuw nsw i64 %r81, 4
  %r108 = inttoptr i64 %r107 to ptr
  %r109 = load i32, ptr %r108, align 4
  %r110 = zext i32 %r109 to i64
  %r111 = or i64 %r110, 4611686018427387904
  %r112 = icmp ne i32 %r109, 0
  %r113 = getelementptr i64, ptr %r102, i64 0
  %r114 = load i64, ptr %r113, align 8
  %r115 = icmp eq i64 %r111, %r114
  %r116 = and i1 %r115, %r112
  br i1 %r116, label %pic.hit.39, label %pic.prefix.guard.41

pic.hit.overflow.56:                              ; preds = %pic.hit.39
  %r121 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r122 = bitcast double %r121 to i64
  %r123 = and i64 %r122, 281474976710655
  %r124 = trunc i64 %r118 to i32
  %statepoint_token22 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r81, i64 %r123, i32 %r124, ptr @perry_ic_options_worker_ts__1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated11, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r12523 = call double @llvm.experimental.gc.result.f64(token %statepoint_token22)
  %rs4gc.s7.relocated24 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 0, i32 0) ; (%rs4gc.s7.relocated11, %rs4gc.s7.relocated11)
  %rs4gc.s8.relocated25 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated26 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pic.merge.53

pic.hit.inline.57:                                ; preds = %pic.hit.39
  %r126 = shl i64 %r118, 3
  %r127 = add nuw nsw i64 %r81, 16
  %r128 = add i64 %r127, %r126
  %r129 = inttoptr i64 %r128 to ptr
  %r130 = load double, ptr %r129, align 8
  %r131 = bitcast double %r130 to i64
  %r132 = icmp eq i64 %r131, 9222246136947933200
  br i1 %r132, label %pic.miss.50, label %pic.hit.live.40

pic.ways.58:                                      ; preds = %pic.miss.50
  %r172 = getelementptr i64, ptr %r102, i64 4
  %r173 = load i64, ptr %r172, align 8
  %r174 = icmp eq i64 %r173, %r111
  %r175 = getelementptr i64, ptr %r102, i64 5
  %r176 = load i64, ptr %r175, align 8
  %r177 = select i1 %r174, i64 %r176, i64 0
  %r178 = getelementptr i64, ptr %r102, i64 6
  %r179 = load i64, ptr %r178, align 8
  %r180 = icmp eq i64 %r179, %r111
  %r181 = getelementptr i64, ptr %r102, i64 7
  %r182 = load i64, ptr %r181, align 8
  %r183 = select i1 %r180, i64 %r182, i64 0
  %r184 = getelementptr i64, ptr %r102, i64 8
  %r185 = load i64, ptr %r184, align 8
  %r186 = icmp eq i64 %r185, %r111
  %r187 = getelementptr i64, ptr %r102, i64 9
  %r188 = load i64, ptr %r187, align 8
  %r189 = select i1 %r186, i64 %r188, i64 0
  %r190 = getelementptr i64, ptr %r102, i64 10
  %r191 = load i64, ptr %r190, align 8
  %r192 = icmp eq i64 %r191, %r111
  %r193 = getelementptr i64, ptr %r102, i64 11
  %r194 = load i64, ptr %r193, align 8
  %r195 = select i1 %r192, i64 %r194, i64 0
  %r196 = or i1 %r174, %r180
  %r197 = select i1 %r174, i64 %r177, i64 %r183
  %r198 = or i1 %r186, %r192
  %r199 = select i1 %r186, i64 %r189, i64 %r195
  %r200 = or i1 %r196, %r198
  %r201 = select i1 %r196, i64 %r197, i64 %r199
  %r202 = and i1 %r112, %r200
  br i1 %r202, label %pic.way.load.59, label %pic.miss.call.52

pic.way.load.59:                                  ; preds = %pic.ways.58
  %r203 = shl i64 %r201, 3
  %r204 = add nuw nsw i64 %r81, 16
  %r205 = add i64 %r204, %r203
  %r206 = inttoptr i64 %r205 to ptr
  %r207 = load double, ptr %r206, align 8
  %r208 = bitcast double %r207 to i64
  %r209 = icmp eq i64 %r208, 9222246136947933200
  br i1 %r209, label %pic.miss.call.52, label %pic.way.live.60

pic.way.live.60:                                  ; preds = %pic.way.load.59
  br label %pic.merge.53

pget.throw_nullish.61:                            ; preds = %pget.recv_bad.32
  %r218 = zext i1 %r216 to i32
  %statepoint_token27 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r218, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.62:                        ; preds = %pget.recv_bad.32
  %r219 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r220 = bitcast double %r219 to i64
  %r221 = and i64 %r220, 281474976710655
  %statepoint_token28 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r80, i64 %r221, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated11, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r22229 = call double @llvm.experimental.gc.result.f64(token %statepoint_token28)
  %rs4gc.s7.relocated30 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 0, i32 0) ; (%rs4gc.s7.relocated11, %rs4gc.s7.relocated11)
  %rs4gc.s8.relocated31 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated32 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pget.recv_merge.34

guarded_add.numeric.63:                           ; preds = %pget.recv_merge.34
  %r244 = fadd double %r233, %r231
  br label %guarded_add.merge.65

guarded_add.dynamic.64:                           ; preds = %pget.recv_merge.34
  %statepoint_token33 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r233, double %r231, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.0207) ]
  %r24534 = call double @llvm.experimental.gc.result.f64(token %statepoint_token33)
  %rs4gc.s7.relocated35 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 0, i32 0) ; (%.4, %.4)
  %rs4gc.s8.relocated36 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 1, i32 1) ; (%.0207, %.0207)
  br label %guarded_add.merge.65

guarded_add.merge.65:                             ; preds = %guarded_add.dynamic.64, %guarded_add.numeric.63
  %.2209 = phi ptr addrspace(1) [ %.0207, %guarded_add.numeric.63 ], [ %rs4gc.s8.relocated36, %guarded_add.dynamic.64 ]
  %.6 = phi ptr addrspace(1) [ %.4, %guarded_add.numeric.63 ], [ %rs4gc.s7.relocated35, %guarded_add.dynamic.64 ]
  %r246 = phi double [ %r244, %guarded_add.numeric.63 ], [ %r24534, %guarded_add.dynamic.64 ]
  %r247.rs4i = ptrtoint ptr addrspace(1) %.2209 to i64
  %r247.rs4o = call i64 asm "", "=r,0"(i64 %r247.rs4i) #9
  %r247 = bitcast i64 %r247.rs4o to double
  %r248 = bitcast double %r247 to i64
  %r249 = and i64 %r248, -281474976710656
  %r250 = icmp ne i64 %r249, 9223090561878065152
  br i1 %r250, label %str_addref.done.67, label %str_addref.call.66

str_addref.call.66:                               ; preds = %guarded_add.merge.65
  call void @js_string_addref_if_heap_string(double %r247) #9
  br label %str_addref.done.67

str_addref.done.67:                               ; preds = %str_addref.call.66, %guarded_add.merge.65
  %r1554.rs4i = ptrtoint ptr addrspace(1) %.2209 to i64
  %r1554.rs4o = call i64 asm "", "=r,0"(i64 %r1554.rs4i) #9
  %r1554 = bitcast i64 %r1554.rs4o to double
  store double %r1554, ptr @perry_global_options_worker_ts__7, align 8
  %r1553.rs4i = ptrtoint ptr addrspace(1) %.2209 to i64
  %r1553.rs4o = call i64 asm "", "=r,0"(i64 %r1553.rs4i) #9
  %r1553 = bitcast i64 %r1553.rs4o to double
  %r251 = bitcast double %r1553 to i64
  %r1551.rs4i = ptrtoint ptr addrspace(1) %.2209 to i64
  %r1551.rs4o = call i64 asm "", "=r,0"(i64 %r1551.rs4i) #9
  %r1551 = bitcast i64 %r1551.rs4o to double
  %r1552 = bitcast double %r1551 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1552) #9
  %r252 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r253 = icmp ne i32 %r252, 0
  br i1 %r253, label %gcpoll.68, label %gcpoll.done.69

gcpoll.68:                                        ; preds = %str_addref.done.67
  %statepoint_token37 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6) ]
  %rs4gc.s7.relocated38 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token37, i32 0, i32 0) ; (%.6, %.6)
  br label %gcpoll.done.69

gcpoll.done.69:                                   ; preds = %gcpoll.68, %str_addref.done.67
  %.7 = phi ptr addrspace(1) [ %rs4gc.s7.relocated38, %gcpoll.68 ], [ %.6, %str_addref.done.67 ]
  br label %for.update.20

streqlit.tag.70:                                  ; preds = %if.else.11
  %r263 = lshr i64 %r260, 48
  %r264 = icmp eq i64 %r263, 32767
  %r265 = and i64 %r260, 281474976710655
  %r266 = icmp ugt i64 %r265, 4095
  %r267 = and i1 %r264, %r266
  br i1 %r267, label %streqlit.len.71, label %streqlit.false.76

streqlit.len.71:                                  ; preds = %streqlit.tag.70
  %r268 = inttoptr i64 %r265 to ptr
  %r269 = getelementptr inbounds nuw i8, ptr %r268, i64 4
  %r270 = load i32, ptr %r269, align 4
  %r271 = icmp eq i32 %r270, 12
  br i1 %r271, label %streqlit.b0.72, label %streqlit.false.76

streqlit.b0.72:                                   ; preds = %streqlit.len.71
  %r272 = getelementptr inbounds nuw i8, ptr %r268, i64 20
  %r273 = load i8, ptr %r272, align 1
  %r274 = icmp eq i8 %r273, 100
  br i1 %r274, label %streqlit.bl.73, label %streqlit.false.76

streqlit.bl.73:                                   ; preds = %streqlit.b0.72
  %r275 = getelementptr inbounds nuw i8, ptr %r268, i64 31
  %r276 = load i8, ptr %r275, align 1
  %r277 = icmp eq i8 %r276, 111
  br i1 %r277, label %streqlit.slow.74, label %streqlit.false.76

streqlit.slow.74:                                 ; preds = %streqlit.bl.73
  %r278 = and i64 %r261, 281474976710655
  %statepoint_token39 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r265, i64 %r278, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r27940 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token39)
  %rs4gc.s7.relocated41 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token39, i32 0, i32 0) ; (%.0, %.0)
  %r280 = icmp ne i32 %r27940, 0
  br label %streqlit.merge.77

streqlit.true.75:                                 ; preds = %if.else.11
  br label %streqlit.merge.77

streqlit.false.76:                                ; preds = %streqlit.bl.73, %streqlit.b0.72, %streqlit.len.71, %streqlit.tag.70
  br label %streqlit.merge.77

streqlit.merge.77:                                ; preds = %streqlit.false.76, %streqlit.true.75, %streqlit.slow.74
  %.8 = phi ptr addrspace(1) [ %.0, %streqlit.true.75 ], [ %rs4gc.s7.relocated41, %streqlit.slow.74 ], [ %.0, %streqlit.false.76 ]
  %r281 = phi i1 [ true, %streqlit.true.75 ], [ false, %streqlit.false.76 ], [ %r280, %streqlit.slow.74 ]
  %r282 = select i1 %r281, i64 9222246136947933188, i64 9222246136947933187
  %r283 = bitcast i64 %r282 to double
  %r284 = icmp eq i64 %r282, 9222246136947933188
  br i1 %r284, label %if.then.78, label %if.else.79

if.then.78:                                       ; preds = %streqlit.merge.77
  %r289.rs4i = ptrtoint ptr addrspace(1) %.8 to i64
  %r289.rs4o = call i64 asm "", "=r,0"(i64 %r289.rs4i) #9
  %r289 = bitcast i64 %r289.rs4o to double
  %r290 = bitcast double %r289 to i64
  %r291 = and i64 %r290, -281474976710656
  %r292 = icmp ult i64 %r291, 9221401712017801216
  %r293 = icmp ugt i64 %r291, 9223090561878065152
  %r294 = or i1 %r292, %r293
  br i1 %r294, label %for.bound_i32.number.81, label %for.bound_i32.merge.83

if.else.79:                                       ; preds = %streqlit.merge.77
  %r512 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r513 = load double, ptr @options_worker_ts_.str.3.handle, align 8
  %r514 = bitcast double %r512 to i64
  %r515 = bitcast double %r513 to i64
  %r516 = icmp eq i64 %r514, %r515
  br i1 %r516, label %streqlit.true.144, label %streqlit.sso.138

if.merge.80:                                      ; preds = %if.merge.149, %for.exit.89
  %r2.2 = phi double [ %r2.3, %for.exit.89 ], [ %r2.4, %if.merge.149 ]
  br label %if.merge.12

for.bound_i32.number.81:                          ; preds = %if.then.78
  %r295 = fcmp oge double %r289, 0xC1E0000000000000
  %r296 = fcmp ole double %r289, 0x41DFFFFFFFC00000
  %r297 = and i1 %r295, %r296
  br i1 %r297, label %for.bound_i32.convert.82, label %for.bound_i32.merge.83

for.bound_i32.convert.82:                         ; preds = %for.bound_i32.number.81
  %r298 = fptosi double %r289 to i32
  %r299 = sitofp i32 %r298 to double
  %r300 = fcmp oeq double %r299, %r289
  br i1 %r300, label %for.counter_i32.range.84, label %for.bound_i32.merge.83

for.bound_i32.merge.83:                           ; preds = %for.counter_i32.convert.85, %for.bound_i32.convert.82, %for.bound_i32.number.81, %if.then.78
  %r288.0 = phi i32 [ %r298, %for.counter_i32.convert.85 ], [ 0, %if.then.78 ], [ %r298, %for.bound_i32.convert.82 ], [ 0, %for.bound_i32.number.81 ]
  %r287.0 = phi i1 [ true, %for.counter_i32.convert.85 ], [ false, %if.then.78 ], [ false, %for.bound_i32.convert.82 ], [ false, %for.bound_i32.number.81 ]
  br label %for.cond.86

for.counter_i32.range.84:                         ; preds = %for.bound_i32.convert.82
  br label %for.counter_i32.convert.85

for.counter_i32.convert.85:                       ; preds = %for.counter_i32.range.84
  br label %for.bound_i32.merge.83

for.cond.86:                                      ; preds = %for.update.88, %for.bound_i32.merge.83
  %.9 = phi ptr addrspace(1) [ %.8, %for.bound_i32.merge.83 ], [ %.15, %for.update.88 ]
  %r286.1 = phi i32 [ 0, %for.bound_i32.merge.83 ], [ %r511, %for.update.88 ]
  %r285.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.83 ], [ %r509, %for.update.88 ]
  %r2.3 = phi double [ 0.000000e+00, %for.bound_i32.merge.83 ], [ %r500, %for.update.88 ]
  br i1 %r287.0, label %for.cond.fast.90, label %for.cond.slow.91

for.body.87:                                      ; preds = %gcpoll.done.93, %for.cond.fast.90
  %.10 = phi ptr addrspace(1) [ %.9, %for.cond.fast.90 ], [ %.11, %gcpoll.done.93 ]
  %r321 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %r322 = load double, ptr @perry_global_options_worker_ts__2, align 8
  %statepoint_token42 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r321, double 0x7FFC000000000002, double %r322, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10) ]
  %r32343 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token42)
  %rs4gc.s7.relocated44 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token42, i32 0, i32 0) ; (%.10, %.10)
  %r324 = bitcast i64 %r32343 to double
  %rs4gc.b10 = bitcast double %r324 to i64
  %rs4gc.s10 = inttoptr i64 %rs4gc.b10 to ptr addrspace(1)
  %r325.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r325 = call i64 asm "", "=r,0"(i64 %r325.rs4i) #9
  %r326 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r327 = icmp ne i32 %r326, 0
  br i1 %r327, label %shadow.root.barrier.94, label %shadow.root.barrier.done.95

for.update.88:                                    ; preds = %gcpoll.done.137
  %r509 = fadd double %r285.0, 1.000000e+00
  %r511 = add i32 %r286.1, 1
  br label %for.cond.86

for.exit.89:                                      ; preds = %gcpoll.done.93, %for.cond.fast.90
  br label %if.merge.80

for.cond.fast.90:                                 ; preds = %for.cond.86
  %r311 = icmp slt i32 %r286.1, %r288.0
  br i1 %r311, label %for.body.87, label %for.exit.89

for.cond.slow.91:                                 ; preds = %for.cond.86
  %r313.rs4i = ptrtoint ptr addrspace(1) %.9 to i64
  %r313.rs4o = call i64 asm "", "=r,0"(i64 %r313.rs4i) #9
  %r313 = bitcast i64 %r313.rs4o to double
  %r314 = fcmp olt double %r285.0, %r313
  %r315 = select i1 %r314, i64 9222246136947933188, i64 9222246136947933187
  %r316 = bitcast i64 %r315 to double
  %r318 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r319 = icmp ne i32 %r318, 0
  br i1 %r319, label %gcpoll.92, label %gcpoll.done.93

gcpoll.92:                                        ; preds = %for.cond.slow.91
  %statepoint_token45 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9) ]
  %rs4gc.s7.relocated46 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token45, i32 0, i32 0) ; (%.9, %.9)
  br label %gcpoll.done.93

gcpoll.done.93:                                   ; preds = %gcpoll.92, %for.cond.slow.91
  %.11 = phi ptr addrspace(1) [ %rs4gc.s7.relocated46, %gcpoll.92 ], [ %.9, %for.cond.slow.91 ]
  %r317 = icmp eq i64 %r315, 9222246136947933188
  br i1 %r317, label %for.body.87, label %for.exit.89

shadow.root.barrier.94:                           ; preds = %for.body.87
  call void @js_write_barrier_root_nanbox(i64 %r325) #9
  br label %shadow.root.barrier.done.95

shadow.root.barrier.done.95:                      ; preds = %shadow.root.barrier.94, %for.body.87
  %r329 = bitcast double %r2.3 to i64
  %rs4gc.s11 = inttoptr i64 %r329 to ptr addrspace(1)
  %r330.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11 to i64
  %r330 = call i64 asm "", "=r,0"(i64 %r330.rs4i) #9
  %r331 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r332 = icmp ne i32 %r331, 0
  br i1 %r332, label %shadow.root.barrier.96, label %shadow.root.barrier.done.97

shadow.root.barrier.96:                           ; preds = %shadow.root.barrier.done.95
  call void @js_write_barrier_root_nanbox(i64 %r330) #9
  br label %shadow.root.barrier.done.97

shadow.root.barrier.done.97:                      ; preds = %shadow.root.barrier.96, %shadow.root.barrier.done.95
  %r333.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r333.rs4o = call i64 asm "", "=r,0"(i64 %r333.rs4i) #9
  %r333 = bitcast i64 %r333.rs4o to double
  %r334 = bitcast double %r333 to i64
  %r335 = and i64 %r334, 281474976710655
  %r336 = lshr i64 %r334, 48
  %r337 = and i64 %r336, 65533
  %r338 = icmp eq i64 %r337, 32765
  br i1 %r338, label %pget.recv_ok.99, label %pget.recv_other.104

pget.recv_sso.98:                                 ; preds = %pget.recv_other.104
  %r477 = lshr i64 %r334, 40
  %r478 = and i64 %r477, 255
  %r479 = uitofp nneg i64 %r478 to double
  br label %pget.recv_merge.102

pget.recv_ok.99:                                  ; preds = %shadow.root.barrier.done.97
  %r345 = icmp eq i64 %r336, 32767
  br i1 %r345, label %pget.strlen_heap.103, label %pget.recv_obj.106

pget.recv_bad.100:                                ; preds = %pget.check_class_ref.105
  %r469 = icmp eq i64 %r334, 9222246136947933185
  %r470 = icmp eq i64 %r334, 9222246136947933186
  %r471 = or i1 %r469, %r470
  br i1 %r471, label %pget.throw_nullish.129, label %pget.recv_undef_return.130

pget.recv_class_ref.101:                          ; preds = %pget.check_class_ref.105
  %r341 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r342 = bitcast double %r341 to i64
  %r343 = and i64 %r342, 281474976710655
  %statepoint_token47 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532866, i64 %r334, i64 %r343, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated44, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r34448 = call double @llvm.experimental.gc.result.f64(token %statepoint_token47)
  %rs4gc.s7.relocated49 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token47, i32 0, i32 0) ; (%rs4gc.s7.relocated44, %rs4gc.s7.relocated44)
  %rs4gc.s10.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token47, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token47, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pget.recv_merge.102

pget.recv_merge.102:                              ; preds = %pget.recv_undef_return.130, %pic.merge.121, %pget.strlen_heap.103, %pget.recv_class_ref.101, %pget.recv_sso.98
  %.0215 = phi ptr addrspace(1) [ %rs4gc.s11, %pget.strlen_heap.103 ], [ %.1216, %pic.merge.121 ], [ %rs4gc.s11, %pget.recv_sso.98 ], [ %rs4gc.s11.relocated, %pget.recv_class_ref.101 ], [ %rs4gc.s11.relocated65, %pget.recv_undef_return.130 ]
  %.0212 = phi ptr addrspace(1) [ %rs4gc.s10, %pget.strlen_heap.103 ], [ %.1213, %pic.merge.121 ], [ %rs4gc.s10, %pget.recv_sso.98 ], [ %rs4gc.s10.relocated, %pget.recv_class_ref.101 ], [ %rs4gc.s10.relocated64, %pget.recv_undef_return.130 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s7.relocated44, %pget.strlen_heap.103 ], [ %.13, %pic.merge.121 ], [ %rs4gc.s7.relocated44, %pget.recv_sso.98 ], [ %rs4gc.s7.relocated49, %pget.recv_class_ref.101 ], [ %rs4gc.s7.relocated63, %pget.recv_undef_return.130 ]
  %r485 = phi double [ %r468, %pic.merge.121 ], [ %r47662, %pget.recv_undef_return.130 ], [ %r479, %pget.recv_sso.98 ], [ %r34448, %pget.recv_class_ref.101 ], [ %r484, %pget.strlen_heap.103 ]
  %r486.rs4i = ptrtoint ptr addrspace(1) %.0215 to i64
  %r486 = call i64 asm "", "=r,0"(i64 %r486.rs4i) #9
  %r487 = bitcast i64 %r486 to double
  %r488 = and i64 %r486, -281474976710656
  %r489 = icmp ult i64 %r488, 9221401712017801216
  %r490 = icmp ugt i64 %r488, 9223090561878065152
  %r491 = or i1 %r489, %r490
  %r492 = bitcast double %r485 to i64
  %r493 = and i64 %r492, -281474976710656
  %r494 = icmp ult i64 %r493, 9221401712017801216
  %r495 = icmp ugt i64 %r493, 9223090561878065152
  %r496 = or i1 %r494, %r495
  %r497 = and i1 %r491, %r496
  br i1 %r497, label %guarded_add.numeric.131, label %guarded_add.dynamic.132

pget.strlen_heap.103:                             ; preds = %pget.recv_ok.99
  %r480 = icmp ult i64 %r335, 4096
  %r481 = inttoptr i64 %r335 to ptr
  %r482 = select i1 %r480, ptr @perry_null_guard_zero_options_worker_ts, ptr %r481
  %r483 = load i32, ptr %r482, align 4
  %r484 = uitofp i32 %r483 to double
  br label %pget.recv_merge.102

pget.recv_other.104:                              ; preds = %shadow.root.barrier.done.97
  %r339 = icmp eq i64 %r336, 32761
  br i1 %r339, label %pget.recv_sso.98, label %pget.check_class_ref.105

pget.check_class_ref.105:                         ; preds = %pget.recv_other.104
  %r340 = icmp eq i64 %r336, 32766
  br i1 %r340, label %pget.recv_class_ref.101, label %pget.recv_bad.100

pget.recv_obj.106:                                ; preds = %pget.recv_ok.99
  %r346 = icmp ugt i64 %r335, 1048575
  br i1 %r346, label %pic.recv_hdr.122, label %pic.miss.cold.119

pic.hit.107:                                      ; preds = %pic.token.123
  %r371 = getelementptr i64, ptr %r356, i64 1
  %r372 = load i64, ptr %r371, align 8
  %r373 = and i64 %r372, 1073741824
  %r374 = icmp ne i64 %r373, 0
  br i1 %r374, label %pic.hit.overflow.124, label %pic.hit.inline.125

pic.hit.live.108:                                 ; preds = %pic.hit.inline.125
  br label %pic.merge.121

pic.prefix.guard.109:                             ; preds = %pic.token.123
  %r387 = getelementptr i64, ptr %r356, i64 2
  %r388 = load i64, ptr %r387, align 8
  %r389 = icmp ne i64 %r388, 0
  br i1 %r389, label %pic.prefix.meta.110, label %pic.miss.118

pic.prefix.meta.110:                              ; preds = %pic.prefix.guard.109
  %r390 = add nuw nsw i64 %r335, 8
  %r391 = inttoptr i64 %r390 to ptr
  %r392 = load i64, ptr %r391, align 8
  %r393 = icmp ne i64 %r392, 0
  br i1 %r393, label %pic.prefix.token.111, label %pic.miss.118

pic.prefix.token.111:                             ; preds = %pic.prefix.meta.110
  %r394 = inttoptr i64 %r392 to ptr
  %r395 = getelementptr i64, ptr %r394, i64 6
  %r396 = load i64, ptr %r395, align 8
  %r397 = icmp eq i64 %r396, %r388
  br i1 %r397, label %pic.prefix.hit.112, label %pic.miss.118

pic.prefix.hit.112:                               ; preds = %pic.prefix.token.111
  %r398 = getelementptr i64, ptr %r356, i64 1
  %r399 = load i64, ptr %r398, align 8
  %r400 = shl i64 %r399, 3
  %r401 = add nuw nsw i64 %r335, 16
  %r402 = add i64 %r401, %r400
  %r403 = inttoptr i64 %r402 to ptr
  %r404 = load double, ptr %r403, align 8
  br label %pic.merge.121

pic.desc.classify.113:                            ; preds = %pic.recv_hdr.122
  %r360 = and i1 %r350, %r357
  br i1 %r360, label %pic.desc.prefix.guard.114, label %pic.miss.cold.119

pic.desc.prefix.guard.114:                        ; preds = %pic.desc.classify.113
  %r405 = getelementptr i64, ptr %r356, i64 2
  %r406 = load i64, ptr %r405, align 8
  %r407 = icmp ne i64 %r406, 0
  br i1 %r407, label %pic.desc.prefix.meta.115, label %pic.miss.cold.119

pic.desc.prefix.meta.115:                         ; preds = %pic.desc.prefix.guard.114
  %r408 = add nuw nsw i64 %r335, 8
  %r409 = inttoptr i64 %r408 to ptr
  %r410 = load i64, ptr %r409, align 8
  %r411 = icmp ne i64 %r410, 0
  br i1 %r411, label %pic.desc.prefix.token.116, label %pic.miss.cold.119

pic.desc.prefix.token.116:                        ; preds = %pic.desc.prefix.meta.115
  %r412 = inttoptr i64 %r410 to ptr
  %r413 = getelementptr i64, ptr %r412, i64 6
  %r414 = load i64, ptr %r413, align 8
  %r415 = icmp eq i64 %r414, %r406
  br i1 %r415, label %pic.desc.prefix.hit.117, label %pic.miss.cold.119

pic.desc.prefix.hit.117:                          ; preds = %pic.desc.prefix.token.116
  %r416 = getelementptr i64, ptr %r356, i64 1
  %r417 = load i64, ptr %r416, align 8
  %r418 = shl i64 %r417, 3
  %r419 = add nuw nsw i64 %r335, 16
  %r420 = add i64 %r419, %r418
  %r421 = inttoptr i64 %r420 to ptr
  %r422 = load double, ptr %r421, align 8
  br label %pic.merge.121

pic.miss.118:                                     ; preds = %pic.hit.inline.125, %pic.prefix.token.111, %pic.prefix.meta.110, %pic.prefix.guard.109
  %r423 = getelementptr i64, ptr %r356, i64 3
  %r424 = load i64, ptr %r423, align 8
  %r425 = icmp sgt i64 %r424, 0
  br i1 %r425, label %pic.ways.126, label %pic.miss.call.120

pic.miss.cold.119:                                ; preds = %pic.desc.prefix.token.116, %pic.desc.prefix.meta.115, %pic.desc.prefix.guard.114, %pic.desc.classify.113, %pget.recv_obj.106
  br label %pic.miss.call.120

pic.miss.call.120:                                ; preds = %pic.way.load.127, %pic.ways.126, %pic.miss.cold.119, %pic.miss.118
  %r464 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r465 = bitcast double %r464 to i64
  %r466 = and i64 %r465, 281474976710655
  %statepoint_token50 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r335, i64 %r466, ptr @perry_ic_options_worker_ts__3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated44, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r46751 = call double @llvm.experimental.gc.result.f64(token %statepoint_token50)
  %rs4gc.s7.relocated52 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token50, i32 0, i32 0) ; (%rs4gc.s7.relocated44, %rs4gc.s7.relocated44)
  %rs4gc.s10.relocated53 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token50, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated54 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token50, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pic.merge.121

pic.merge.121:                                    ; preds = %pic.way.live.128, %pic.hit.overflow.124, %pic.miss.call.120, %pic.desc.prefix.hit.117, %pic.prefix.hit.112, %pic.hit.live.108
  %.1216 = phi ptr addrspace(1) [ %rs4gc.s11.relocated59, %pic.hit.overflow.124 ], [ %rs4gc.s11.relocated54, %pic.miss.call.120 ], [ %rs4gc.s11, %pic.way.live.128 ], [ %rs4gc.s11, %pic.hit.live.108 ], [ %rs4gc.s11, %pic.prefix.hit.112 ], [ %rs4gc.s11, %pic.desc.prefix.hit.117 ]
  %.1213 = phi ptr addrspace(1) [ %rs4gc.s10.relocated58, %pic.hit.overflow.124 ], [ %rs4gc.s10.relocated53, %pic.miss.call.120 ], [ %rs4gc.s10, %pic.way.live.128 ], [ %rs4gc.s10, %pic.hit.live.108 ], [ %rs4gc.s10, %pic.prefix.hit.112 ], [ %rs4gc.s10, %pic.desc.prefix.hit.117 ]
  %.13 = phi ptr addrspace(1) [ %rs4gc.s7.relocated57, %pic.hit.overflow.124 ], [ %rs4gc.s7.relocated52, %pic.miss.call.120 ], [ %rs4gc.s7.relocated44, %pic.way.live.128 ], [ %rs4gc.s7.relocated44, %pic.hit.live.108 ], [ %rs4gc.s7.relocated44, %pic.prefix.hit.112 ], [ %rs4gc.s7.relocated44, %pic.desc.prefix.hit.117 ]
  %r468 = phi double [ %r384, %pic.hit.live.108 ], [ %r37956, %pic.hit.overflow.124 ], [ %r404, %pic.prefix.hit.112 ], [ %r422, %pic.desc.prefix.hit.117 ], [ %r461, %pic.way.live.128 ], [ %r46751, %pic.miss.call.120 ]
  br label %pget.recv_merge.102

pic.recv_hdr.122:                                 ; preds = %pget.recv_obj.106
  %r347 = sub nuw nsw i64 %r335, 8
  %r348 = inttoptr i64 %r347 to ptr
  %r349 = load i8, ptr %r348, align 1
  %r350 = icmp eq i8 %r349, 2
  %r351 = sub nuw nsw i64 %r335, 6
  %r352 = inttoptr i64 %r351 to ptr
  %r353 = load i16, ptr %r352, align 2
  %r354 = and i16 %r353, 2048
  %r355 = icmp eq i16 %r354, 0
  %r356 = load ptr, ptr @perry_ic_options_worker_ts__3, align 8
  %r357 = icmp ne ptr %r356, null
  %r358 = and i1 %r350, %r355
  %r359 = and i1 %r358, %r357
  br i1 %r359, label %pic.token.123, label %pic.desc.classify.113

pic.token.123:                                    ; preds = %pic.recv_hdr.122
  %r361 = add nuw nsw i64 %r335, 4
  %r362 = inttoptr i64 %r361 to ptr
  %r363 = load i32, ptr %r362, align 4
  %r364 = zext i32 %r363 to i64
  %r365 = or i64 %r364, 4611686018427387904
  %r366 = icmp ne i32 %r363, 0
  %r367 = getelementptr i64, ptr %r356, i64 0
  %r368 = load i64, ptr %r367, align 8
  %r369 = icmp eq i64 %r365, %r368
  %r370 = and i1 %r369, %r366
  br i1 %r370, label %pic.hit.107, label %pic.prefix.guard.109

pic.hit.overflow.124:                             ; preds = %pic.hit.107
  %r375 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r376 = bitcast double %r375 to i64
  %r377 = and i64 %r376, 281474976710655
  %r378 = trunc i64 %r372 to i32
  %statepoint_token55 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r335, i64 %r377, i32 %r378, ptr @perry_ic_options_worker_ts__3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated44, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r37956 = call double @llvm.experimental.gc.result.f64(token %statepoint_token55)
  %rs4gc.s7.relocated57 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 0, i32 0) ; (%rs4gc.s7.relocated44, %rs4gc.s7.relocated44)
  %rs4gc.s10.relocated58 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated59 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pic.merge.121

pic.hit.inline.125:                               ; preds = %pic.hit.107
  %r380 = shl i64 %r372, 3
  %r381 = add nuw nsw i64 %r335, 16
  %r382 = add i64 %r381, %r380
  %r383 = inttoptr i64 %r382 to ptr
  %r384 = load double, ptr %r383, align 8
  %r385 = bitcast double %r384 to i64
  %r386 = icmp eq i64 %r385, 9222246136947933200
  br i1 %r386, label %pic.miss.118, label %pic.hit.live.108

pic.ways.126:                                     ; preds = %pic.miss.118
  %r426 = getelementptr i64, ptr %r356, i64 4
  %r427 = load i64, ptr %r426, align 8
  %r428 = icmp eq i64 %r427, %r365
  %r429 = getelementptr i64, ptr %r356, i64 5
  %r430 = load i64, ptr %r429, align 8
  %r431 = select i1 %r428, i64 %r430, i64 0
  %r432 = getelementptr i64, ptr %r356, i64 6
  %r433 = load i64, ptr %r432, align 8
  %r434 = icmp eq i64 %r433, %r365
  %r435 = getelementptr i64, ptr %r356, i64 7
  %r436 = load i64, ptr %r435, align 8
  %r437 = select i1 %r434, i64 %r436, i64 0
  %r438 = getelementptr i64, ptr %r356, i64 8
  %r439 = load i64, ptr %r438, align 8
  %r440 = icmp eq i64 %r439, %r365
  %r441 = getelementptr i64, ptr %r356, i64 9
  %r442 = load i64, ptr %r441, align 8
  %r443 = select i1 %r440, i64 %r442, i64 0
  %r444 = getelementptr i64, ptr %r356, i64 10
  %r445 = load i64, ptr %r444, align 8
  %r446 = icmp eq i64 %r445, %r365
  %r447 = getelementptr i64, ptr %r356, i64 11
  %r448 = load i64, ptr %r447, align 8
  %r449 = select i1 %r446, i64 %r448, i64 0
  %r450 = or i1 %r428, %r434
  %r451 = select i1 %r428, i64 %r431, i64 %r437
  %r452 = or i1 %r440, %r446
  %r453 = select i1 %r440, i64 %r443, i64 %r449
  %r454 = or i1 %r450, %r452
  %r455 = select i1 %r450, i64 %r451, i64 %r453
  %r456 = and i1 %r366, %r454
  br i1 %r456, label %pic.way.load.127, label %pic.miss.call.120

pic.way.load.127:                                 ; preds = %pic.ways.126
  %r457 = shl i64 %r455, 3
  %r458 = add nuw nsw i64 %r335, 16
  %r459 = add i64 %r458, %r457
  %r460 = inttoptr i64 %r459 to ptr
  %r461 = load double, ptr %r460, align 8
  %r462 = bitcast double %r461 to i64
  %r463 = icmp eq i64 %r462, 9222246136947933200
  br i1 %r463, label %pic.miss.call.120, label %pic.way.live.128

pic.way.live.128:                                 ; preds = %pic.way.load.127
  br label %pic.merge.121

pget.throw_nullish.129:                           ; preds = %pget.recv_bad.100
  %r472 = zext i1 %r470 to i32
  %statepoint_token60 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r472, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.130:                       ; preds = %pget.recv_bad.100
  %r473 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r474 = bitcast double %r473 to i64
  %r475 = and i64 %r474, 281474976710655
  %statepoint_token61 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r334, i64 %r475, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated44, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r47662 = call double @llvm.experimental.gc.result.f64(token %statepoint_token61)
  %rs4gc.s7.relocated63 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token61, i32 0, i32 0) ; (%rs4gc.s7.relocated44, %rs4gc.s7.relocated44)
  %rs4gc.s10.relocated64 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token61, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated65 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token61, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pget.recv_merge.102

guarded_add.numeric.131:                          ; preds = %pget.recv_merge.102
  %r498 = fadd double %r487, %r485
  br label %guarded_add.merge.133

guarded_add.dynamic.132:                          ; preds = %pget.recv_merge.102
  %statepoint_token66 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r487, double %r485, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12, ptr addrspace(1) %.0212) ]
  %r49967 = call double @llvm.experimental.gc.result.f64(token %statepoint_token66)
  %rs4gc.s7.relocated68 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 0, i32 0) ; (%.12, %.12)
  %rs4gc.s10.relocated69 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token66, i32 1, i32 1) ; (%.0212, %.0212)
  br label %guarded_add.merge.133

guarded_add.merge.133:                            ; preds = %guarded_add.dynamic.132, %guarded_add.numeric.131
  %.2214 = phi ptr addrspace(1) [ %.0212, %guarded_add.numeric.131 ], [ %rs4gc.s10.relocated69, %guarded_add.dynamic.132 ]
  %.14 = phi ptr addrspace(1) [ %.12, %guarded_add.numeric.131 ], [ %rs4gc.s7.relocated68, %guarded_add.dynamic.132 ]
  %r500 = phi double [ %r498, %guarded_add.numeric.131 ], [ %r49967, %guarded_add.dynamic.132 ]
  %r501.rs4i = ptrtoint ptr addrspace(1) %.2214 to i64
  %r501.rs4o = call i64 asm "", "=r,0"(i64 %r501.rs4i) #9
  %r501 = bitcast i64 %r501.rs4o to double
  %r502 = bitcast double %r501 to i64
  %r503 = and i64 %r502, -281474976710656
  %r504 = icmp ne i64 %r503, 9223090561878065152
  br i1 %r504, label %str_addref.done.135, label %str_addref.call.134

str_addref.call.134:                              ; preds = %guarded_add.merge.133
  call void @js_string_addref_if_heap_string(double %r501) #9
  br label %str_addref.done.135

str_addref.done.135:                              ; preds = %str_addref.call.134, %guarded_add.merge.133
  %r1550.rs4i = ptrtoint ptr addrspace(1) %.2214 to i64
  %r1550.rs4o = call i64 asm "", "=r,0"(i64 %r1550.rs4i) #9
  %r1550 = bitcast i64 %r1550.rs4o to double
  store double %r1550, ptr @perry_global_options_worker_ts__7, align 8
  %r1549.rs4i = ptrtoint ptr addrspace(1) %.2214 to i64
  %r1549.rs4o = call i64 asm "", "=r,0"(i64 %r1549.rs4i) #9
  %r1549 = bitcast i64 %r1549.rs4o to double
  %r505 = bitcast double %r1549 to i64
  %r1547.rs4i = ptrtoint ptr addrspace(1) %.2214 to i64
  %r1547.rs4o = call i64 asm "", "=r,0"(i64 %r1547.rs4i) #9
  %r1547 = bitcast i64 %r1547.rs4o to double
  %r1548 = bitcast double %r1547 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1548) #9
  %r506 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r507 = icmp ne i32 %r506, 0
  br i1 %r507, label %gcpoll.136, label %gcpoll.done.137

gcpoll.136:                                       ; preds = %str_addref.done.135
  %statepoint_token70 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.14) ]
  %rs4gc.s7.relocated71 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token70, i32 0, i32 0) ; (%.14, %.14)
  br label %gcpoll.done.137

gcpoll.done.137:                                  ; preds = %gcpoll.136, %str_addref.done.135
  %.15 = phi ptr addrspace(1) [ %rs4gc.s7.relocated71, %gcpoll.136 ], [ %.14, %str_addref.done.135 ]
  br label %for.update.88

streqlit.sso.138:                                 ; preds = %if.else.79
  %r517 = icmp eq i64 %r514, 9221406111934080378
  br i1 %r517, label %streqlit.true.144, label %streqlit.tag.139

streqlit.tag.139:                                 ; preds = %streqlit.sso.138
  %r518 = lshr i64 %r514, 48
  %r519 = icmp eq i64 %r518, 32767
  %r520 = and i64 %r514, 281474976710655
  %r521 = icmp ugt i64 %r520, 4095
  %r522 = and i1 %r519, %r521
  br i1 %r522, label %streqlit.len.140, label %streqlit.false.145

streqlit.len.140:                                 ; preds = %streqlit.tag.139
  %r523 = inttoptr i64 %r520 to ptr
  %r524 = getelementptr inbounds nuw i8, ptr %r523, i64 4
  %r525 = load i32, ptr %r524, align 4
  %r526 = icmp eq i32 %r525, 4
  br i1 %r526, label %streqlit.b0.141, label %streqlit.false.145

streqlit.b0.141:                                  ; preds = %streqlit.len.140
  %r527 = getelementptr inbounds nuw i8, ptr %r523, i64 20
  %r528 = load i8, ptr %r527, align 1
  %r529 = icmp eq i8 %r528, 122
  br i1 %r529, label %streqlit.bl.142, label %streqlit.false.145

streqlit.bl.142:                                  ; preds = %streqlit.b0.141
  %r530 = getelementptr inbounds nuw i8, ptr %r523, i64 23
  %r531 = load i8, ptr %r530, align 1
  %r532 = icmp eq i8 %r531, 111
  br i1 %r532, label %streqlit.slow.143, label %streqlit.false.145

streqlit.slow.143:                                ; preds = %streqlit.bl.142
  %r533 = and i64 %r515, 281474976710655
  %statepoint_token72 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r520, i64 %r533, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8) ]
  %r53473 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token72)
  %rs4gc.s7.relocated74 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token72, i32 0, i32 0) ; (%.8, %.8)
  %r535 = icmp ne i32 %r53473, 0
  br label %streqlit.merge.146

streqlit.true.144:                                ; preds = %streqlit.sso.138, %if.else.79
  br label %streqlit.merge.146

streqlit.false.145:                               ; preds = %streqlit.bl.142, %streqlit.b0.141, %streqlit.len.140, %streqlit.tag.139
  br label %streqlit.merge.146

streqlit.merge.146:                               ; preds = %streqlit.false.145, %streqlit.true.144, %streqlit.slow.143
  %.16 = phi ptr addrspace(1) [ %.8, %streqlit.true.144 ], [ %rs4gc.s7.relocated74, %streqlit.slow.143 ], [ %.8, %streqlit.false.145 ]
  %r536 = phi i1 [ true, %streqlit.true.144 ], [ false, %streqlit.false.145 ], [ %r535, %streqlit.slow.143 ]
  %r537 = select i1 %r536, i64 9222246136947933188, i64 9222246136947933187
  %r538 = bitcast i64 %r537 to double
  %r539 = icmp eq i64 %r537, 9222246136947933188
  br i1 %r539, label %if.then.147, label %if.else.148

if.then.147:                                      ; preds = %streqlit.merge.146
  %r544.rs4i = ptrtoint ptr addrspace(1) %.16 to i64
  %r544.rs4o = call i64 asm "", "=r,0"(i64 %r544.rs4i) #9
  %r544 = bitcast i64 %r544.rs4o to double
  %r545 = bitcast double %r544 to i64
  %r546 = and i64 %r545, -281474976710656
  %r547 = icmp ult i64 %r546, 9221401712017801216
  %r548 = icmp ugt i64 %r546, 9223090561878065152
  %r549 = or i1 %r547, %r548
  br i1 %r549, label %for.bound_i32.number.150, label %for.bound_i32.merge.152

if.else.148:                                      ; preds = %streqlit.merge.146
  %r766 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r767 = load double, ptr @options_worker_ts_.str.4.handle, align 8
  %r768 = bitcast double %r766 to i64
  %r769 = bitcast double %r767 to i64
  %r770 = icmp eq i64 %r768, %r769
  br i1 %r770, label %streqlit.true.212, label %streqlit.tag.207

if.merge.149:                                     ; preds = %if.merge.217, %for.exit.158
  %r2.4 = phi double [ %r2.5, %for.exit.158 ], [ %r2.6, %if.merge.217 ]
  br label %if.merge.80

for.bound_i32.number.150:                         ; preds = %if.then.147
  %r550 = fcmp oge double %r544, 0xC1E0000000000000
  %r551 = fcmp ole double %r544, 0x41DFFFFFFFC00000
  %r552 = and i1 %r550, %r551
  br i1 %r552, label %for.bound_i32.convert.151, label %for.bound_i32.merge.152

for.bound_i32.convert.151:                        ; preds = %for.bound_i32.number.150
  %r553 = fptosi double %r544 to i32
  %r554 = sitofp i32 %r553 to double
  %r555 = fcmp oeq double %r554, %r544
  br i1 %r555, label %for.counter_i32.range.153, label %for.bound_i32.merge.152

for.bound_i32.merge.152:                          ; preds = %for.counter_i32.convert.154, %for.bound_i32.convert.151, %for.bound_i32.number.150, %if.then.147
  %r543.0 = phi i32 [ %r553, %for.counter_i32.convert.154 ], [ 0, %if.then.147 ], [ %r553, %for.bound_i32.convert.151 ], [ 0, %for.bound_i32.number.150 ]
  %r542.0 = phi i1 [ true, %for.counter_i32.convert.154 ], [ false, %if.then.147 ], [ false, %for.bound_i32.convert.151 ], [ false, %for.bound_i32.number.150 ]
  br label %for.cond.155

for.counter_i32.range.153:                        ; preds = %for.bound_i32.convert.151
  br label %for.counter_i32.convert.154

for.counter_i32.convert.154:                      ; preds = %for.counter_i32.range.153
  br label %for.bound_i32.merge.152

for.cond.155:                                     ; preds = %for.update.157, %for.bound_i32.merge.152
  %.17 = phi ptr addrspace(1) [ %.16, %for.bound_i32.merge.152 ], [ %.23, %for.update.157 ]
  %r541.1 = phi i32 [ 0, %for.bound_i32.merge.152 ], [ %r765, %for.update.157 ]
  %r540.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.152 ], [ %r763, %for.update.157 ]
  %r2.5 = phi double [ 0.000000e+00, %for.bound_i32.merge.152 ], [ %r754, %for.update.157 ]
  br i1 %r542.0, label %for.cond.fast.159, label %for.cond.slow.160

for.body.156:                                     ; preds = %gcpoll.done.162, %for.cond.fast.159
  %.18 = phi ptr addrspace(1) [ %.17, %for.cond.fast.159 ], [ %.19, %gcpoll.done.162 ]
  %r576 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %statepoint_token75 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r576, double 0x7FFC000000000002, double 0.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.18) ]
  %r57776 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token75)
  %rs4gc.s7.relocated77 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token75, i32 0, i32 0) ; (%.18, %.18)
  %r578 = bitcast i64 %r57776 to double
  %rs4gc.b12 = bitcast double %r578 to i64
  %rs4gc.s12 = inttoptr i64 %rs4gc.b12 to ptr addrspace(1)
  %r579.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r579 = call i64 asm "", "=r,0"(i64 %r579.rs4i) #9
  %r580 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r581 = icmp ne i32 %r580, 0
  br i1 %r581, label %shadow.root.barrier.163, label %shadow.root.barrier.done.164

for.update.157:                                   ; preds = %gcpoll.done.206
  %r763 = fadd double %r540.0, 1.000000e+00
  %r765 = add i32 %r541.1, 1
  br label %for.cond.155

for.exit.158:                                     ; preds = %gcpoll.done.162, %for.cond.fast.159
  br label %if.merge.149

for.cond.fast.159:                                ; preds = %for.cond.155
  %r566 = icmp slt i32 %r541.1, %r543.0
  br i1 %r566, label %for.body.156, label %for.exit.158

for.cond.slow.160:                                ; preds = %for.cond.155
  %r568.rs4i = ptrtoint ptr addrspace(1) %.17 to i64
  %r568.rs4o = call i64 asm "", "=r,0"(i64 %r568.rs4i) #9
  %r568 = bitcast i64 %r568.rs4o to double
  %r569 = fcmp olt double %r540.0, %r568
  %r570 = select i1 %r569, i64 9222246136947933188, i64 9222246136947933187
  %r571 = bitcast i64 %r570 to double
  %r573 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r574 = icmp ne i32 %r573, 0
  br i1 %r574, label %gcpoll.161, label %gcpoll.done.162

gcpoll.161:                                       ; preds = %for.cond.slow.160
  %statepoint_token78 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.17) ]
  %rs4gc.s7.relocated79 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token78, i32 0, i32 0) ; (%.17, %.17)
  br label %gcpoll.done.162

gcpoll.done.162:                                  ; preds = %gcpoll.161, %for.cond.slow.160
  %.19 = phi ptr addrspace(1) [ %rs4gc.s7.relocated79, %gcpoll.161 ], [ %.17, %for.cond.slow.160 ]
  %r572 = icmp eq i64 %r570, 9222246136947933188
  br i1 %r572, label %for.body.156, label %for.exit.158

shadow.root.barrier.163:                          ; preds = %for.body.156
  call void @js_write_barrier_root_nanbox(i64 %r579) #9
  br label %shadow.root.barrier.done.164

shadow.root.barrier.done.164:                     ; preds = %shadow.root.barrier.163, %for.body.156
  %r583 = bitcast double %r2.5 to i64
  %rs4gc.s13 = inttoptr i64 %r583 to ptr addrspace(1)
  %r584.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r584 = call i64 asm "", "=r,0"(i64 %r584.rs4i) #9
  %r585 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r586 = icmp ne i32 %r585, 0
  br i1 %r586, label %shadow.root.barrier.165, label %shadow.root.barrier.done.166

shadow.root.barrier.165:                          ; preds = %shadow.root.barrier.done.164
  call void @js_write_barrier_root_nanbox(i64 %r584) #9
  br label %shadow.root.barrier.done.166

shadow.root.barrier.done.166:                     ; preds = %shadow.root.barrier.165, %shadow.root.barrier.done.164
  %r587.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r587.rs4o = call i64 asm "", "=r,0"(i64 %r587.rs4i) #9
  %r587 = bitcast i64 %r587.rs4o to double
  %r588 = bitcast double %r587 to i64
  %r589 = and i64 %r588, 281474976710655
  %r590 = lshr i64 %r588, 48
  %r591 = and i64 %r590, 65533
  %r592 = icmp eq i64 %r591, 32765
  br i1 %r592, label %pget.recv_ok.168, label %pget.recv_other.173

pget.recv_sso.167:                                ; preds = %pget.recv_other.173
  %r731 = lshr i64 %r588, 40
  %r732 = and i64 %r731, 255
  %r733 = uitofp nneg i64 %r732 to double
  br label %pget.recv_merge.171

pget.recv_ok.168:                                 ; preds = %shadow.root.barrier.done.166
  %r599 = icmp eq i64 %r590, 32767
  br i1 %r599, label %pget.strlen_heap.172, label %pget.recv_obj.175

pget.recv_bad.169:                                ; preds = %pget.check_class_ref.174
  %r723 = icmp eq i64 %r588, 9222246136947933185
  %r724 = icmp eq i64 %r588, 9222246136947933186
  %r725 = or i1 %r723, %r724
  br i1 %r725, label %pget.throw_nullish.198, label %pget.recv_undef_return.199

pget.recv_class_ref.170:                          ; preds = %pget.check_class_ref.174
  %r595 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r596 = bitcast double %r595 to i64
  %r597 = and i64 %r596, 281474976710655
  %statepoint_token80 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532868, i64 %r588, i64 %r597, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated77, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r59881 = call double @llvm.experimental.gc.result.f64(token %statepoint_token80)
  %rs4gc.s7.relocated82 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 0, i32 0) ; (%rs4gc.s7.relocated77, %rs4gc.s7.relocated77)
  %rs4gc.s12.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pget.recv_merge.171

pget.recv_merge.171:                              ; preds = %pget.recv_undef_return.199, %pic.merge.190, %pget.strlen_heap.172, %pget.recv_class_ref.170, %pget.recv_sso.167
  %.0220 = phi ptr addrspace(1) [ %rs4gc.s13, %pget.strlen_heap.172 ], [ %.1221, %pic.merge.190 ], [ %rs4gc.s13, %pget.recv_sso.167 ], [ %rs4gc.s13.relocated, %pget.recv_class_ref.170 ], [ %rs4gc.s13.relocated98, %pget.recv_undef_return.199 ]
  %.0217 = phi ptr addrspace(1) [ %rs4gc.s12, %pget.strlen_heap.172 ], [ %.1218, %pic.merge.190 ], [ %rs4gc.s12, %pget.recv_sso.167 ], [ %rs4gc.s12.relocated, %pget.recv_class_ref.170 ], [ %rs4gc.s12.relocated97, %pget.recv_undef_return.199 ]
  %.20 = phi ptr addrspace(1) [ %rs4gc.s7.relocated77, %pget.strlen_heap.172 ], [ %.21, %pic.merge.190 ], [ %rs4gc.s7.relocated77, %pget.recv_sso.167 ], [ %rs4gc.s7.relocated82, %pget.recv_class_ref.170 ], [ %rs4gc.s7.relocated96, %pget.recv_undef_return.199 ]
  %r739 = phi double [ %r722, %pic.merge.190 ], [ %r73095, %pget.recv_undef_return.199 ], [ %r733, %pget.recv_sso.167 ], [ %r59881, %pget.recv_class_ref.170 ], [ %r738, %pget.strlen_heap.172 ]
  %r740.rs4i = ptrtoint ptr addrspace(1) %.0220 to i64
  %r740 = call i64 asm "", "=r,0"(i64 %r740.rs4i) #9
  %r741 = bitcast i64 %r740 to double
  %r742 = and i64 %r740, -281474976710656
  %r743 = icmp ult i64 %r742, 9221401712017801216
  %r744 = icmp ugt i64 %r742, 9223090561878065152
  %r745 = or i1 %r743, %r744
  %r746 = bitcast double %r739 to i64
  %r747 = and i64 %r746, -281474976710656
  %r748 = icmp ult i64 %r747, 9221401712017801216
  %r749 = icmp ugt i64 %r747, 9223090561878065152
  %r750 = or i1 %r748, %r749
  %r751 = and i1 %r745, %r750
  br i1 %r751, label %guarded_add.numeric.200, label %guarded_add.dynamic.201

pget.strlen_heap.172:                             ; preds = %pget.recv_ok.168
  %r734 = icmp ult i64 %r589, 4096
  %r735 = inttoptr i64 %r589 to ptr
  %r736 = select i1 %r734, ptr @perry_null_guard_zero_options_worker_ts, ptr %r735
  %r737 = load i32, ptr %r736, align 4
  %r738 = uitofp i32 %r737 to double
  br label %pget.recv_merge.171

pget.recv_other.173:                              ; preds = %shadow.root.barrier.done.166
  %r593 = icmp eq i64 %r590, 32761
  br i1 %r593, label %pget.recv_sso.167, label %pget.check_class_ref.174

pget.check_class_ref.174:                         ; preds = %pget.recv_other.173
  %r594 = icmp eq i64 %r590, 32766
  br i1 %r594, label %pget.recv_class_ref.170, label %pget.recv_bad.169

pget.recv_obj.175:                                ; preds = %pget.recv_ok.168
  %r600 = icmp ugt i64 %r589, 1048575
  br i1 %r600, label %pic.recv_hdr.191, label %pic.miss.cold.188

pic.hit.176:                                      ; preds = %pic.token.192
  %r625 = getelementptr i64, ptr %r610, i64 1
  %r626 = load i64, ptr %r625, align 8
  %r627 = and i64 %r626, 1073741824
  %r628 = icmp ne i64 %r627, 0
  br i1 %r628, label %pic.hit.overflow.193, label %pic.hit.inline.194

pic.hit.live.177:                                 ; preds = %pic.hit.inline.194
  br label %pic.merge.190

pic.prefix.guard.178:                             ; preds = %pic.token.192
  %r641 = getelementptr i64, ptr %r610, i64 2
  %r642 = load i64, ptr %r641, align 8
  %r643 = icmp ne i64 %r642, 0
  br i1 %r643, label %pic.prefix.meta.179, label %pic.miss.187

pic.prefix.meta.179:                              ; preds = %pic.prefix.guard.178
  %r644 = add nuw nsw i64 %r589, 8
  %r645 = inttoptr i64 %r644 to ptr
  %r646 = load i64, ptr %r645, align 8
  %r647 = icmp ne i64 %r646, 0
  br i1 %r647, label %pic.prefix.token.180, label %pic.miss.187

pic.prefix.token.180:                             ; preds = %pic.prefix.meta.179
  %r648 = inttoptr i64 %r646 to ptr
  %r649 = getelementptr i64, ptr %r648, i64 6
  %r650 = load i64, ptr %r649, align 8
  %r651 = icmp eq i64 %r650, %r642
  br i1 %r651, label %pic.prefix.hit.181, label %pic.miss.187

pic.prefix.hit.181:                               ; preds = %pic.prefix.token.180
  %r652 = getelementptr i64, ptr %r610, i64 1
  %r653 = load i64, ptr %r652, align 8
  %r654 = shl i64 %r653, 3
  %r655 = add nuw nsw i64 %r589, 16
  %r656 = add i64 %r655, %r654
  %r657 = inttoptr i64 %r656 to ptr
  %r658 = load double, ptr %r657, align 8
  br label %pic.merge.190

pic.desc.classify.182:                            ; preds = %pic.recv_hdr.191
  %r614 = and i1 %r604, %r611
  br i1 %r614, label %pic.desc.prefix.guard.183, label %pic.miss.cold.188

pic.desc.prefix.guard.183:                        ; preds = %pic.desc.classify.182
  %r659 = getelementptr i64, ptr %r610, i64 2
  %r660 = load i64, ptr %r659, align 8
  %r661 = icmp ne i64 %r660, 0
  br i1 %r661, label %pic.desc.prefix.meta.184, label %pic.miss.cold.188

pic.desc.prefix.meta.184:                         ; preds = %pic.desc.prefix.guard.183
  %r662 = add nuw nsw i64 %r589, 8
  %r663 = inttoptr i64 %r662 to ptr
  %r664 = load i64, ptr %r663, align 8
  %r665 = icmp ne i64 %r664, 0
  br i1 %r665, label %pic.desc.prefix.token.185, label %pic.miss.cold.188

pic.desc.prefix.token.185:                        ; preds = %pic.desc.prefix.meta.184
  %r666 = inttoptr i64 %r664 to ptr
  %r667 = getelementptr i64, ptr %r666, i64 6
  %r668 = load i64, ptr %r667, align 8
  %r669 = icmp eq i64 %r668, %r660
  br i1 %r669, label %pic.desc.prefix.hit.186, label %pic.miss.cold.188

pic.desc.prefix.hit.186:                          ; preds = %pic.desc.prefix.token.185
  %r670 = getelementptr i64, ptr %r610, i64 1
  %r671 = load i64, ptr %r670, align 8
  %r672 = shl i64 %r671, 3
  %r673 = add nuw nsw i64 %r589, 16
  %r674 = add i64 %r673, %r672
  %r675 = inttoptr i64 %r674 to ptr
  %r676 = load double, ptr %r675, align 8
  br label %pic.merge.190

pic.miss.187:                                     ; preds = %pic.hit.inline.194, %pic.prefix.token.180, %pic.prefix.meta.179, %pic.prefix.guard.178
  %r677 = getelementptr i64, ptr %r610, i64 3
  %r678 = load i64, ptr %r677, align 8
  %r679 = icmp sgt i64 %r678, 0
  br i1 %r679, label %pic.ways.195, label %pic.miss.call.189

pic.miss.cold.188:                                ; preds = %pic.desc.prefix.token.185, %pic.desc.prefix.meta.184, %pic.desc.prefix.guard.183, %pic.desc.classify.182, %pget.recv_obj.175
  br label %pic.miss.call.189

pic.miss.call.189:                                ; preds = %pic.way.load.196, %pic.ways.195, %pic.miss.cold.188, %pic.miss.187
  %r718 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r719 = bitcast double %r718 to i64
  %r720 = and i64 %r719, 281474976710655
  %statepoint_token83 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r589, i64 %r720, ptr @perry_ic_options_worker_ts__5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated77, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r72184 = call double @llvm.experimental.gc.result.f64(token %statepoint_token83)
  %rs4gc.s7.relocated85 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token83, i32 0, i32 0) ; (%rs4gc.s7.relocated77, %rs4gc.s7.relocated77)
  %rs4gc.s12.relocated86 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token83, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated87 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token83, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pic.merge.190

pic.merge.190:                                    ; preds = %pic.way.live.197, %pic.hit.overflow.193, %pic.miss.call.189, %pic.desc.prefix.hit.186, %pic.prefix.hit.181, %pic.hit.live.177
  %.1221 = phi ptr addrspace(1) [ %rs4gc.s13.relocated92, %pic.hit.overflow.193 ], [ %rs4gc.s13.relocated87, %pic.miss.call.189 ], [ %rs4gc.s13, %pic.way.live.197 ], [ %rs4gc.s13, %pic.hit.live.177 ], [ %rs4gc.s13, %pic.prefix.hit.181 ], [ %rs4gc.s13, %pic.desc.prefix.hit.186 ]
  %.1218 = phi ptr addrspace(1) [ %rs4gc.s12.relocated91, %pic.hit.overflow.193 ], [ %rs4gc.s12.relocated86, %pic.miss.call.189 ], [ %rs4gc.s12, %pic.way.live.197 ], [ %rs4gc.s12, %pic.hit.live.177 ], [ %rs4gc.s12, %pic.prefix.hit.181 ], [ %rs4gc.s12, %pic.desc.prefix.hit.186 ]
  %.21 = phi ptr addrspace(1) [ %rs4gc.s7.relocated90, %pic.hit.overflow.193 ], [ %rs4gc.s7.relocated85, %pic.miss.call.189 ], [ %rs4gc.s7.relocated77, %pic.way.live.197 ], [ %rs4gc.s7.relocated77, %pic.hit.live.177 ], [ %rs4gc.s7.relocated77, %pic.prefix.hit.181 ], [ %rs4gc.s7.relocated77, %pic.desc.prefix.hit.186 ]
  %r722 = phi double [ %r638, %pic.hit.live.177 ], [ %r63389, %pic.hit.overflow.193 ], [ %r658, %pic.prefix.hit.181 ], [ %r676, %pic.desc.prefix.hit.186 ], [ %r715, %pic.way.live.197 ], [ %r72184, %pic.miss.call.189 ]
  br label %pget.recv_merge.171

pic.recv_hdr.191:                                 ; preds = %pget.recv_obj.175
  %r601 = sub nuw nsw i64 %r589, 8
  %r602 = inttoptr i64 %r601 to ptr
  %r603 = load i8, ptr %r602, align 1
  %r604 = icmp eq i8 %r603, 2
  %r605 = sub nuw nsw i64 %r589, 6
  %r606 = inttoptr i64 %r605 to ptr
  %r607 = load i16, ptr %r606, align 2
  %r608 = and i16 %r607, 2048
  %r609 = icmp eq i16 %r608, 0
  %r610 = load ptr, ptr @perry_ic_options_worker_ts__5, align 8
  %r611 = icmp ne ptr %r610, null
  %r612 = and i1 %r604, %r609
  %r613 = and i1 %r612, %r611
  br i1 %r613, label %pic.token.192, label %pic.desc.classify.182

pic.token.192:                                    ; preds = %pic.recv_hdr.191
  %r615 = add nuw nsw i64 %r589, 4
  %r616 = inttoptr i64 %r615 to ptr
  %r617 = load i32, ptr %r616, align 4
  %r618 = zext i32 %r617 to i64
  %r619 = or i64 %r618, 4611686018427387904
  %r620 = icmp ne i32 %r617, 0
  %r621 = getelementptr i64, ptr %r610, i64 0
  %r622 = load i64, ptr %r621, align 8
  %r623 = icmp eq i64 %r619, %r622
  %r624 = and i1 %r623, %r620
  br i1 %r624, label %pic.hit.176, label %pic.prefix.guard.178

pic.hit.overflow.193:                             ; preds = %pic.hit.176
  %r629 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r630 = bitcast double %r629 to i64
  %r631 = and i64 %r630, 281474976710655
  %r632 = trunc i64 %r626 to i32
  %statepoint_token88 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r589, i64 %r631, i32 %r632, ptr @perry_ic_options_worker_ts__5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated77, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r63389 = call double @llvm.experimental.gc.result.f64(token %statepoint_token88)
  %rs4gc.s7.relocated90 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token88, i32 0, i32 0) ; (%rs4gc.s7.relocated77, %rs4gc.s7.relocated77)
  %rs4gc.s12.relocated91 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token88, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated92 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token88, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pic.merge.190

pic.hit.inline.194:                               ; preds = %pic.hit.176
  %r634 = shl i64 %r626, 3
  %r635 = add nuw nsw i64 %r589, 16
  %r636 = add i64 %r635, %r634
  %r637 = inttoptr i64 %r636 to ptr
  %r638 = load double, ptr %r637, align 8
  %r639 = bitcast double %r638 to i64
  %r640 = icmp eq i64 %r639, 9222246136947933200
  br i1 %r640, label %pic.miss.187, label %pic.hit.live.177

pic.ways.195:                                     ; preds = %pic.miss.187
  %r680 = getelementptr i64, ptr %r610, i64 4
  %r681 = load i64, ptr %r680, align 8
  %r682 = icmp eq i64 %r681, %r619
  %r683 = getelementptr i64, ptr %r610, i64 5
  %r684 = load i64, ptr %r683, align 8
  %r685 = select i1 %r682, i64 %r684, i64 0
  %r686 = getelementptr i64, ptr %r610, i64 6
  %r687 = load i64, ptr %r686, align 8
  %r688 = icmp eq i64 %r687, %r619
  %r689 = getelementptr i64, ptr %r610, i64 7
  %r690 = load i64, ptr %r689, align 8
  %r691 = select i1 %r688, i64 %r690, i64 0
  %r692 = getelementptr i64, ptr %r610, i64 8
  %r693 = load i64, ptr %r692, align 8
  %r694 = icmp eq i64 %r693, %r619
  %r695 = getelementptr i64, ptr %r610, i64 9
  %r696 = load i64, ptr %r695, align 8
  %r697 = select i1 %r694, i64 %r696, i64 0
  %r698 = getelementptr i64, ptr %r610, i64 10
  %r699 = load i64, ptr %r698, align 8
  %r700 = icmp eq i64 %r699, %r619
  %r701 = getelementptr i64, ptr %r610, i64 11
  %r702 = load i64, ptr %r701, align 8
  %r703 = select i1 %r700, i64 %r702, i64 0
  %r704 = or i1 %r682, %r688
  %r705 = select i1 %r682, i64 %r685, i64 %r691
  %r706 = or i1 %r694, %r700
  %r707 = select i1 %r694, i64 %r697, i64 %r703
  %r708 = or i1 %r704, %r706
  %r709 = select i1 %r704, i64 %r705, i64 %r707
  %r710 = and i1 %r620, %r708
  br i1 %r710, label %pic.way.load.196, label %pic.miss.call.189

pic.way.load.196:                                 ; preds = %pic.ways.195
  %r711 = shl i64 %r709, 3
  %r712 = add nuw nsw i64 %r589, 16
  %r713 = add i64 %r712, %r711
  %r714 = inttoptr i64 %r713 to ptr
  %r715 = load double, ptr %r714, align 8
  %r716 = bitcast double %r715 to i64
  %r717 = icmp eq i64 %r716, 9222246136947933200
  br i1 %r717, label %pic.miss.call.189, label %pic.way.live.197

pic.way.live.197:                                 ; preds = %pic.way.load.196
  br label %pic.merge.190

pget.throw_nullish.198:                           ; preds = %pget.recv_bad.169
  %r726 = zext i1 %r724 to i32
  %statepoint_token93 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r726, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.199:                       ; preds = %pget.recv_bad.169
  %r727 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r728 = bitcast double %r727 to i64
  %r729 = and i64 %r728, 281474976710655
  %statepoint_token94 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r588, i64 %r729, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated77, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r73095 = call double @llvm.experimental.gc.result.f64(token %statepoint_token94)
  %rs4gc.s7.relocated96 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 0, i32 0) ; (%rs4gc.s7.relocated77, %rs4gc.s7.relocated77)
  %rs4gc.s12.relocated97 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated98 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pget.recv_merge.171

guarded_add.numeric.200:                          ; preds = %pget.recv_merge.171
  %r752 = fadd double %r741, %r739
  br label %guarded_add.merge.202

guarded_add.dynamic.201:                          ; preds = %pget.recv_merge.171
  %statepoint_token99 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r741, double %r739, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.20, ptr addrspace(1) %.0217) ]
  %r753100 = call double @llvm.experimental.gc.result.f64(token %statepoint_token99)
  %rs4gc.s7.relocated101 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 0, i32 0) ; (%.20, %.20)
  %rs4gc.s12.relocated102 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 1, i32 1) ; (%.0217, %.0217)
  br label %guarded_add.merge.202

guarded_add.merge.202:                            ; preds = %guarded_add.dynamic.201, %guarded_add.numeric.200
  %.2219 = phi ptr addrspace(1) [ %.0217, %guarded_add.numeric.200 ], [ %rs4gc.s12.relocated102, %guarded_add.dynamic.201 ]
  %.22 = phi ptr addrspace(1) [ %.20, %guarded_add.numeric.200 ], [ %rs4gc.s7.relocated101, %guarded_add.dynamic.201 ]
  %r754 = phi double [ %r752, %guarded_add.numeric.200 ], [ %r753100, %guarded_add.dynamic.201 ]
  %r755.rs4i = ptrtoint ptr addrspace(1) %.2219 to i64
  %r755.rs4o = call i64 asm "", "=r,0"(i64 %r755.rs4i) #9
  %r755 = bitcast i64 %r755.rs4o to double
  %r756 = bitcast double %r755 to i64
  %r757 = and i64 %r756, -281474976710656
  %r758 = icmp ne i64 %r757, 9223090561878065152
  br i1 %r758, label %str_addref.done.204, label %str_addref.call.203

str_addref.call.203:                              ; preds = %guarded_add.merge.202
  call void @js_string_addref_if_heap_string(double %r755) #9
  br label %str_addref.done.204

str_addref.done.204:                              ; preds = %str_addref.call.203, %guarded_add.merge.202
  %r1546.rs4i = ptrtoint ptr addrspace(1) %.2219 to i64
  %r1546.rs4o = call i64 asm "", "=r,0"(i64 %r1546.rs4i) #9
  %r1546 = bitcast i64 %r1546.rs4o to double
  store double %r1546, ptr @perry_global_options_worker_ts__7, align 8
  %r1545.rs4i = ptrtoint ptr addrspace(1) %.2219 to i64
  %r1545.rs4o = call i64 asm "", "=r,0"(i64 %r1545.rs4i) #9
  %r1545 = bitcast i64 %r1545.rs4o to double
  %r759 = bitcast double %r1545 to i64
  %r1543.rs4i = ptrtoint ptr addrspace(1) %.2219 to i64
  %r1543.rs4o = call i64 asm "", "=r,0"(i64 %r1543.rs4i) #9
  %r1543 = bitcast i64 %r1543.rs4o to double
  %r1544 = bitcast double %r1543 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1544) #9
  %r760 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r761 = icmp ne i32 %r760, 0
  br i1 %r761, label %gcpoll.205, label %gcpoll.done.206

gcpoll.205:                                       ; preds = %str_addref.done.204
  %statepoint_token103 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.22) ]
  %rs4gc.s7.relocated104 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token103, i32 0, i32 0) ; (%.22, %.22)
  br label %gcpoll.done.206

gcpoll.done.206:                                  ; preds = %gcpoll.205, %str_addref.done.204
  %.23 = phi ptr addrspace(1) [ %rs4gc.s7.relocated104, %gcpoll.205 ], [ %.22, %str_addref.done.204 ]
  br label %for.update.157

streqlit.tag.207:                                 ; preds = %if.else.148
  %r771 = lshr i64 %r768, 48
  %r772 = icmp eq i64 %r771, 32767
  %r773 = and i64 %r768, 281474976710655
  %r774 = icmp ugt i64 %r773, 4095
  %r775 = and i1 %r772, %r774
  br i1 %r775, label %streqlit.len.208, label %streqlit.false.213

streqlit.len.208:                                 ; preds = %streqlit.tag.207
  %r776 = inttoptr i64 %r773 to ptr
  %r777 = getelementptr inbounds nuw i8, ptr %r776, i64 4
  %r778 = load i32, ptr %r777, align 4
  %r779 = icmp eq i32 %r778, 6
  br i1 %r779, label %streqlit.b0.209, label %streqlit.false.213

streqlit.b0.209:                                  ; preds = %streqlit.len.208
  %r780 = getelementptr inbounds nuw i8, ptr %r776, i64 20
  %r781 = load i8, ptr %r780, align 1
  %r782 = icmp eq i8 %r781, 112
  br i1 %r782, label %streqlit.bl.210, label %streqlit.false.213

streqlit.bl.210:                                  ; preds = %streqlit.b0.209
  %r783 = getelementptr inbounds nuw i8, ptr %r776, i64 25
  %r784 = load i8, ptr %r783, align 1
  %r785 = icmp eq i8 %r784, 121
  br i1 %r785, label %streqlit.slow.211, label %streqlit.false.213

streqlit.slow.211:                                ; preds = %streqlit.bl.210
  %r786 = and i64 %r769, 281474976710655
  %statepoint_token105 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r773, i64 %r786, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.16) ]
  %r787106 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token105)
  %rs4gc.s7.relocated107 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 0, i32 0) ; (%.16, %.16)
  %r788 = icmp ne i32 %r787106, 0
  br label %streqlit.merge.214

streqlit.true.212:                                ; preds = %if.else.148
  br label %streqlit.merge.214

streqlit.false.213:                               ; preds = %streqlit.bl.210, %streqlit.b0.209, %streqlit.len.208, %streqlit.tag.207
  br label %streqlit.merge.214

streqlit.merge.214:                               ; preds = %streqlit.false.213, %streqlit.true.212, %streqlit.slow.211
  %.24 = phi ptr addrspace(1) [ %.16, %streqlit.true.212 ], [ %rs4gc.s7.relocated107, %streqlit.slow.211 ], [ %.16, %streqlit.false.213 ]
  %r789 = phi i1 [ true, %streqlit.true.212 ], [ false, %streqlit.false.213 ], [ %r788, %streqlit.slow.211 ]
  %r790 = select i1 %r789, i64 9222246136947933188, i64 9222246136947933187
  %r791 = bitcast i64 %r790 to double
  %r792 = icmp eq i64 %r790, 9222246136947933188
  br i1 %r792, label %if.then.215, label %if.else.216

if.then.215:                                      ; preds = %streqlit.merge.214
  %r797.rs4i = ptrtoint ptr addrspace(1) %.24 to i64
  %r797.rs4o = call i64 asm "", "=r,0"(i64 %r797.rs4i) #9
  %r797 = bitcast i64 %r797.rs4o to double
  %r798 = bitcast double %r797 to i64
  %r799 = and i64 %r798, -281474976710656
  %r800 = icmp ult i64 %r799, 9221401712017801216
  %r801 = icmp ugt i64 %r799, 9223090561878065152
  %r802 = or i1 %r800, %r801
  br i1 %r802, label %for.bound_i32.number.218, label %for.bound_i32.merge.220

if.else.216:                                      ; preds = %streqlit.merge.214
  %r1019 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r1020 = load double, ptr @options_worker_ts_.str.5.handle, align 8
  %r1021 = bitcast double %r1019 to i64
  %r1022 = bitcast double %r1020 to i64
  %r1023 = icmp eq i64 %r1021, %r1022
  br i1 %r1023, label %streqlit.true.281, label %streqlit.sso.275

if.merge.217:                                     ; preds = %if.merge.286, %for.exit.226
  %r2.6 = phi double [ %r2.7, %for.exit.226 ], [ %r2.8, %if.merge.286 ]
  br label %if.merge.149

for.bound_i32.number.218:                         ; preds = %if.then.215
  %r803 = fcmp oge double %r797, 0xC1E0000000000000
  %r804 = fcmp ole double %r797, 0x41DFFFFFFFC00000
  %r805 = and i1 %r803, %r804
  br i1 %r805, label %for.bound_i32.convert.219, label %for.bound_i32.merge.220

for.bound_i32.convert.219:                        ; preds = %for.bound_i32.number.218
  %r806 = fptosi double %r797 to i32
  %r807 = sitofp i32 %r806 to double
  %r808 = fcmp oeq double %r807, %r797
  br i1 %r808, label %for.counter_i32.range.221, label %for.bound_i32.merge.220

for.bound_i32.merge.220:                          ; preds = %for.counter_i32.convert.222, %for.bound_i32.convert.219, %for.bound_i32.number.218, %if.then.215
  %r796.0 = phi i32 [ %r806, %for.counter_i32.convert.222 ], [ 0, %if.then.215 ], [ %r806, %for.bound_i32.convert.219 ], [ 0, %for.bound_i32.number.218 ]
  %r795.0 = phi i1 [ true, %for.counter_i32.convert.222 ], [ false, %if.then.215 ], [ false, %for.bound_i32.convert.219 ], [ false, %for.bound_i32.number.218 ]
  br label %for.cond.223

for.counter_i32.range.221:                        ; preds = %for.bound_i32.convert.219
  br label %for.counter_i32.convert.222

for.counter_i32.convert.222:                      ; preds = %for.counter_i32.range.221
  br label %for.bound_i32.merge.220

for.cond.223:                                     ; preds = %for.update.225, %for.bound_i32.merge.220
  %.25 = phi ptr addrspace(1) [ %.24, %for.bound_i32.merge.220 ], [ %.31, %for.update.225 ]
  %r794.1 = phi i32 [ 0, %for.bound_i32.merge.220 ], [ %r1018, %for.update.225 ]
  %r793.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.220 ], [ %r1016, %for.update.225 ]
  %r2.7 = phi double [ 0.000000e+00, %for.bound_i32.merge.220 ], [ %r1007, %for.update.225 ]
  br i1 %r795.0, label %for.cond.fast.227, label %for.cond.slow.228

for.body.224:                                     ; preds = %gcpoll.done.230, %for.cond.fast.227
  %.26 = phi ptr addrspace(1) [ %.25, %for.cond.fast.227 ], [ %.27, %gcpoll.done.230 ]
  %r829 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %statepoint_token108 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r829, double 0x7FFC000000000002, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.26) ]
  %r830109 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token108)
  %rs4gc.s7.relocated110 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 0, i32 0) ; (%.26, %.26)
  %r831 = bitcast i64 %r830109 to double
  %rs4gc.b14 = bitcast double %r831 to i64
  %rs4gc.s14 = inttoptr i64 %rs4gc.b14 to ptr addrspace(1)
  %r832.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r832 = call i64 asm "", "=r,0"(i64 %r832.rs4i) #9
  %r833 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r834 = icmp ne i32 %r833, 0
  br i1 %r834, label %shadow.root.barrier.231, label %shadow.root.barrier.done.232

for.update.225:                                   ; preds = %gcpoll.done.274
  %r1016 = fadd double %r793.0, 1.000000e+00
  %r1018 = add i32 %r794.1, 1
  br label %for.cond.223

for.exit.226:                                     ; preds = %gcpoll.done.230, %for.cond.fast.227
  br label %if.merge.217

for.cond.fast.227:                                ; preds = %for.cond.223
  %r819 = icmp slt i32 %r794.1, %r796.0
  br i1 %r819, label %for.body.224, label %for.exit.226

for.cond.slow.228:                                ; preds = %for.cond.223
  %r821.rs4i = ptrtoint ptr addrspace(1) %.25 to i64
  %r821.rs4o = call i64 asm "", "=r,0"(i64 %r821.rs4i) #9
  %r821 = bitcast i64 %r821.rs4o to double
  %r822 = fcmp olt double %r793.0, %r821
  %r823 = select i1 %r822, i64 9222246136947933188, i64 9222246136947933187
  %r824 = bitcast i64 %r823 to double
  %r826 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r827 = icmp ne i32 %r826, 0
  br i1 %r827, label %gcpoll.229, label %gcpoll.done.230

gcpoll.229:                                       ; preds = %for.cond.slow.228
  %statepoint_token111 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.25) ]
  %rs4gc.s7.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token111, i32 0, i32 0) ; (%.25, %.25)
  br label %gcpoll.done.230

gcpoll.done.230:                                  ; preds = %gcpoll.229, %for.cond.slow.228
  %.27 = phi ptr addrspace(1) [ %rs4gc.s7.relocated112, %gcpoll.229 ], [ %.25, %for.cond.slow.228 ]
  %r825 = icmp eq i64 %r823, 9222246136947933188
  br i1 %r825, label %for.body.224, label %for.exit.226

shadow.root.barrier.231:                          ; preds = %for.body.224
  call void @js_write_barrier_root_nanbox(i64 %r832) #9
  br label %shadow.root.barrier.done.232

shadow.root.barrier.done.232:                     ; preds = %shadow.root.barrier.231, %for.body.224
  %r836 = bitcast double %r2.7 to i64
  %rs4gc.s15 = inttoptr i64 %r836 to ptr addrspace(1)
  %r837.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r837 = call i64 asm "", "=r,0"(i64 %r837.rs4i) #9
  %r838 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r839 = icmp ne i32 %r838, 0
  br i1 %r839, label %shadow.root.barrier.233, label %shadow.root.barrier.done.234

shadow.root.barrier.233:                          ; preds = %shadow.root.barrier.done.232
  call void @js_write_barrier_root_nanbox(i64 %r837) #9
  br label %shadow.root.barrier.done.234

shadow.root.barrier.done.234:                     ; preds = %shadow.root.barrier.233, %shadow.root.barrier.done.232
  %r840.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r840.rs4o = call i64 asm "", "=r,0"(i64 %r840.rs4i) #9
  %r840 = bitcast i64 %r840.rs4o to double
  %r841 = bitcast double %r840 to i64
  %r842 = and i64 %r841, 281474976710655
  %r843 = lshr i64 %r841, 48
  %r844 = and i64 %r843, 65533
  %r845 = icmp eq i64 %r844, 32765
  br i1 %r845, label %pget.recv_ok.236, label %pget.recv_other.241

pget.recv_sso.235:                                ; preds = %pget.recv_other.241
  %r984 = lshr i64 %r841, 40
  %r985 = and i64 %r984, 255
  %r986 = uitofp nneg i64 %r985 to double
  br label %pget.recv_merge.239

pget.recv_ok.236:                                 ; preds = %shadow.root.barrier.done.234
  %r852 = icmp eq i64 %r843, 32767
  br i1 %r852, label %pget.strlen_heap.240, label %pget.recv_obj.243

pget.recv_bad.237:                                ; preds = %pget.check_class_ref.242
  %r976 = icmp eq i64 %r841, 9222246136947933185
  %r977 = icmp eq i64 %r841, 9222246136947933186
  %r978 = or i1 %r976, %r977
  br i1 %r978, label %pget.throw_nullish.266, label %pget.recv_undef_return.267

pget.recv_class_ref.238:                          ; preds = %pget.check_class_ref.242
  %r848 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r849 = bitcast double %r848 to i64
  %r850 = and i64 %r849, 281474976710655
  %statepoint_token113 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532870, i64 %r841, i64 %r850, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated110, ptr addrspace(1) %rs4gc.s14, ptr addrspace(1) %rs4gc.s15) ]
  %r851114 = call double @llvm.experimental.gc.result.f64(token %statepoint_token113)
  %rs4gc.s7.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 0, i32 0) ; (%rs4gc.s7.relocated110, %rs4gc.s7.relocated110)
  %rs4gc.s14.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 1, i32 1) ; (%rs4gc.s14, %rs4gc.s14)
  %rs4gc.s15.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 2, i32 2) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.239

pget.recv_merge.239:                              ; preds = %pget.recv_undef_return.267, %pic.merge.258, %pget.strlen_heap.240, %pget.recv_class_ref.238, %pget.recv_sso.235
  %.0225 = phi ptr addrspace(1) [ %rs4gc.s15, %pget.strlen_heap.240 ], [ %.1226, %pic.merge.258 ], [ %rs4gc.s15, %pget.recv_sso.235 ], [ %rs4gc.s15.relocated, %pget.recv_class_ref.238 ], [ %rs4gc.s15.relocated131, %pget.recv_undef_return.267 ]
  %.0222 = phi ptr addrspace(1) [ %rs4gc.s14, %pget.strlen_heap.240 ], [ %.1223, %pic.merge.258 ], [ %rs4gc.s14, %pget.recv_sso.235 ], [ %rs4gc.s14.relocated, %pget.recv_class_ref.238 ], [ %rs4gc.s14.relocated130, %pget.recv_undef_return.267 ]
  %.28 = phi ptr addrspace(1) [ %rs4gc.s7.relocated110, %pget.strlen_heap.240 ], [ %.29, %pic.merge.258 ], [ %rs4gc.s7.relocated110, %pget.recv_sso.235 ], [ %rs4gc.s7.relocated115, %pget.recv_class_ref.238 ], [ %rs4gc.s7.relocated129, %pget.recv_undef_return.267 ]
  %r992 = phi double [ %r975, %pic.merge.258 ], [ %r983128, %pget.recv_undef_return.267 ], [ %r986, %pget.recv_sso.235 ], [ %r851114, %pget.recv_class_ref.238 ], [ %r991, %pget.strlen_heap.240 ]
  %r993.rs4i = ptrtoint ptr addrspace(1) %.0225 to i64
  %r993 = call i64 asm "", "=r,0"(i64 %r993.rs4i) #9
  %r994 = bitcast i64 %r993 to double
  %r995 = and i64 %r993, -281474976710656
  %r996 = icmp ult i64 %r995, 9221401712017801216
  %r997 = icmp ugt i64 %r995, 9223090561878065152
  %r998 = or i1 %r996, %r997
  %r999 = bitcast double %r992 to i64
  %r1000 = and i64 %r999, -281474976710656
  %r1001 = icmp ult i64 %r1000, 9221401712017801216
  %r1002 = icmp ugt i64 %r1000, 9223090561878065152
  %r1003 = or i1 %r1001, %r1002
  %r1004 = and i1 %r998, %r1003
  br i1 %r1004, label %guarded_add.numeric.268, label %guarded_add.dynamic.269

pget.strlen_heap.240:                             ; preds = %pget.recv_ok.236
  %r987 = icmp ult i64 %r842, 4096
  %r988 = inttoptr i64 %r842 to ptr
  %r989 = select i1 %r987, ptr @perry_null_guard_zero_options_worker_ts, ptr %r988
  %r990 = load i32, ptr %r989, align 4
  %r991 = uitofp i32 %r990 to double
  br label %pget.recv_merge.239

pget.recv_other.241:                              ; preds = %shadow.root.barrier.done.234
  %r846 = icmp eq i64 %r843, 32761
  br i1 %r846, label %pget.recv_sso.235, label %pget.check_class_ref.242

pget.check_class_ref.242:                         ; preds = %pget.recv_other.241
  %r847 = icmp eq i64 %r843, 32766
  br i1 %r847, label %pget.recv_class_ref.238, label %pget.recv_bad.237

pget.recv_obj.243:                                ; preds = %pget.recv_ok.236
  %r853 = icmp ugt i64 %r842, 1048575
  br i1 %r853, label %pic.recv_hdr.259, label %pic.miss.cold.256

pic.hit.244:                                      ; preds = %pic.token.260
  %r878 = getelementptr i64, ptr %r863, i64 1
  %r879 = load i64, ptr %r878, align 8
  %r880 = and i64 %r879, 1073741824
  %r881 = icmp ne i64 %r880, 0
  br i1 %r881, label %pic.hit.overflow.261, label %pic.hit.inline.262

pic.hit.live.245:                                 ; preds = %pic.hit.inline.262
  br label %pic.merge.258

pic.prefix.guard.246:                             ; preds = %pic.token.260
  %r894 = getelementptr i64, ptr %r863, i64 2
  %r895 = load i64, ptr %r894, align 8
  %r896 = icmp ne i64 %r895, 0
  br i1 %r896, label %pic.prefix.meta.247, label %pic.miss.255

pic.prefix.meta.247:                              ; preds = %pic.prefix.guard.246
  %r897 = add nuw nsw i64 %r842, 8
  %r898 = inttoptr i64 %r897 to ptr
  %r899 = load i64, ptr %r898, align 8
  %r900 = icmp ne i64 %r899, 0
  br i1 %r900, label %pic.prefix.token.248, label %pic.miss.255

pic.prefix.token.248:                             ; preds = %pic.prefix.meta.247
  %r901 = inttoptr i64 %r899 to ptr
  %r902 = getelementptr i64, ptr %r901, i64 6
  %r903 = load i64, ptr %r902, align 8
  %r904 = icmp eq i64 %r903, %r895
  br i1 %r904, label %pic.prefix.hit.249, label %pic.miss.255

pic.prefix.hit.249:                               ; preds = %pic.prefix.token.248
  %r905 = getelementptr i64, ptr %r863, i64 1
  %r906 = load i64, ptr %r905, align 8
  %r907 = shl i64 %r906, 3
  %r908 = add nuw nsw i64 %r842, 16
  %r909 = add i64 %r908, %r907
  %r910 = inttoptr i64 %r909 to ptr
  %r911 = load double, ptr %r910, align 8
  br label %pic.merge.258

pic.desc.classify.250:                            ; preds = %pic.recv_hdr.259
  %r867 = and i1 %r857, %r864
  br i1 %r867, label %pic.desc.prefix.guard.251, label %pic.miss.cold.256

pic.desc.prefix.guard.251:                        ; preds = %pic.desc.classify.250
  %r912 = getelementptr i64, ptr %r863, i64 2
  %r913 = load i64, ptr %r912, align 8
  %r914 = icmp ne i64 %r913, 0
  br i1 %r914, label %pic.desc.prefix.meta.252, label %pic.miss.cold.256

pic.desc.prefix.meta.252:                         ; preds = %pic.desc.prefix.guard.251
  %r915 = add nuw nsw i64 %r842, 8
  %r916 = inttoptr i64 %r915 to ptr
  %r917 = load i64, ptr %r916, align 8
  %r918 = icmp ne i64 %r917, 0
  br i1 %r918, label %pic.desc.prefix.token.253, label %pic.miss.cold.256

pic.desc.prefix.token.253:                        ; preds = %pic.desc.prefix.meta.252
  %r919 = inttoptr i64 %r917 to ptr
  %r920 = getelementptr i64, ptr %r919, i64 6
  %r921 = load i64, ptr %r920, align 8
  %r922 = icmp eq i64 %r921, %r913
  br i1 %r922, label %pic.desc.prefix.hit.254, label %pic.miss.cold.256

pic.desc.prefix.hit.254:                          ; preds = %pic.desc.prefix.token.253
  %r923 = getelementptr i64, ptr %r863, i64 1
  %r924 = load i64, ptr %r923, align 8
  %r925 = shl i64 %r924, 3
  %r926 = add nuw nsw i64 %r842, 16
  %r927 = add i64 %r926, %r925
  %r928 = inttoptr i64 %r927 to ptr
  %r929 = load double, ptr %r928, align 8
  br label %pic.merge.258

pic.miss.255:                                     ; preds = %pic.hit.inline.262, %pic.prefix.token.248, %pic.prefix.meta.247, %pic.prefix.guard.246
  %r930 = getelementptr i64, ptr %r863, i64 3
  %r931 = load i64, ptr %r930, align 8
  %r932 = icmp sgt i64 %r931, 0
  br i1 %r932, label %pic.ways.263, label %pic.miss.call.257

pic.miss.cold.256:                                ; preds = %pic.desc.prefix.token.253, %pic.desc.prefix.meta.252, %pic.desc.prefix.guard.251, %pic.desc.classify.250, %pget.recv_obj.243
  br label %pic.miss.call.257

pic.miss.call.257:                                ; preds = %pic.way.load.264, %pic.ways.263, %pic.miss.cold.256, %pic.miss.255
  %r971 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r972 = bitcast double %r971 to i64
  %r973 = and i64 %r972, 281474976710655
  %statepoint_token116 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r842, i64 %r973, ptr @perry_ic_options_worker_ts__7, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated110, ptr addrspace(1) %rs4gc.s14, ptr addrspace(1) %rs4gc.s15) ]
  %r974117 = call double @llvm.experimental.gc.result.f64(token %statepoint_token116)
  %rs4gc.s7.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 0, i32 0) ; (%rs4gc.s7.relocated110, %rs4gc.s7.relocated110)
  %rs4gc.s14.relocated119 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 1, i32 1) ; (%rs4gc.s14, %rs4gc.s14)
  %rs4gc.s15.relocated120 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 2, i32 2) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pic.merge.258

pic.merge.258:                                    ; preds = %pic.way.live.265, %pic.hit.overflow.261, %pic.miss.call.257, %pic.desc.prefix.hit.254, %pic.prefix.hit.249, %pic.hit.live.245
  %.1226 = phi ptr addrspace(1) [ %rs4gc.s15.relocated125, %pic.hit.overflow.261 ], [ %rs4gc.s15.relocated120, %pic.miss.call.257 ], [ %rs4gc.s15, %pic.way.live.265 ], [ %rs4gc.s15, %pic.hit.live.245 ], [ %rs4gc.s15, %pic.prefix.hit.249 ], [ %rs4gc.s15, %pic.desc.prefix.hit.254 ]
  %.1223 = phi ptr addrspace(1) [ %rs4gc.s14.relocated124, %pic.hit.overflow.261 ], [ %rs4gc.s14.relocated119, %pic.miss.call.257 ], [ %rs4gc.s14, %pic.way.live.265 ], [ %rs4gc.s14, %pic.hit.live.245 ], [ %rs4gc.s14, %pic.prefix.hit.249 ], [ %rs4gc.s14, %pic.desc.prefix.hit.254 ]
  %.29 = phi ptr addrspace(1) [ %rs4gc.s7.relocated123, %pic.hit.overflow.261 ], [ %rs4gc.s7.relocated118, %pic.miss.call.257 ], [ %rs4gc.s7.relocated110, %pic.way.live.265 ], [ %rs4gc.s7.relocated110, %pic.hit.live.245 ], [ %rs4gc.s7.relocated110, %pic.prefix.hit.249 ], [ %rs4gc.s7.relocated110, %pic.desc.prefix.hit.254 ]
  %r975 = phi double [ %r891, %pic.hit.live.245 ], [ %r886122, %pic.hit.overflow.261 ], [ %r911, %pic.prefix.hit.249 ], [ %r929, %pic.desc.prefix.hit.254 ], [ %r968, %pic.way.live.265 ], [ %r974117, %pic.miss.call.257 ]
  br label %pget.recv_merge.239

pic.recv_hdr.259:                                 ; preds = %pget.recv_obj.243
  %r854 = sub nuw nsw i64 %r842, 8
  %r855 = inttoptr i64 %r854 to ptr
  %r856 = load i8, ptr %r855, align 1
  %r857 = icmp eq i8 %r856, 2
  %r858 = sub nuw nsw i64 %r842, 6
  %r859 = inttoptr i64 %r858 to ptr
  %r860 = load i16, ptr %r859, align 2
  %r861 = and i16 %r860, 2048
  %r862 = icmp eq i16 %r861, 0
  %r863 = load ptr, ptr @perry_ic_options_worker_ts__7, align 8
  %r864 = icmp ne ptr %r863, null
  %r865 = and i1 %r857, %r862
  %r866 = and i1 %r865, %r864
  br i1 %r866, label %pic.token.260, label %pic.desc.classify.250

pic.token.260:                                    ; preds = %pic.recv_hdr.259
  %r868 = add nuw nsw i64 %r842, 4
  %r869 = inttoptr i64 %r868 to ptr
  %r870 = load i32, ptr %r869, align 4
  %r871 = zext i32 %r870 to i64
  %r872 = or i64 %r871, 4611686018427387904
  %r873 = icmp ne i32 %r870, 0
  %r874 = getelementptr i64, ptr %r863, i64 0
  %r875 = load i64, ptr %r874, align 8
  %r876 = icmp eq i64 %r872, %r875
  %r877 = and i1 %r876, %r873
  br i1 %r877, label %pic.hit.244, label %pic.prefix.guard.246

pic.hit.overflow.261:                             ; preds = %pic.hit.244
  %r882 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r883 = bitcast double %r882 to i64
  %r884 = and i64 %r883, 281474976710655
  %r885 = trunc i64 %r879 to i32
  %statepoint_token121 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r842, i64 %r884, i32 %r885, ptr @perry_ic_options_worker_ts__7, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated110, ptr addrspace(1) %rs4gc.s14, ptr addrspace(1) %rs4gc.s15) ]
  %r886122 = call double @llvm.experimental.gc.result.f64(token %statepoint_token121)
  %rs4gc.s7.relocated123 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token121, i32 0, i32 0) ; (%rs4gc.s7.relocated110, %rs4gc.s7.relocated110)
  %rs4gc.s14.relocated124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token121, i32 1, i32 1) ; (%rs4gc.s14, %rs4gc.s14)
  %rs4gc.s15.relocated125 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token121, i32 2, i32 2) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pic.merge.258

pic.hit.inline.262:                               ; preds = %pic.hit.244
  %r887 = shl i64 %r879, 3
  %r888 = add nuw nsw i64 %r842, 16
  %r889 = add i64 %r888, %r887
  %r890 = inttoptr i64 %r889 to ptr
  %r891 = load double, ptr %r890, align 8
  %r892 = bitcast double %r891 to i64
  %r893 = icmp eq i64 %r892, 9222246136947933200
  br i1 %r893, label %pic.miss.255, label %pic.hit.live.245

pic.ways.263:                                     ; preds = %pic.miss.255
  %r933 = getelementptr i64, ptr %r863, i64 4
  %r934 = load i64, ptr %r933, align 8
  %r935 = icmp eq i64 %r934, %r872
  %r936 = getelementptr i64, ptr %r863, i64 5
  %r937 = load i64, ptr %r936, align 8
  %r938 = select i1 %r935, i64 %r937, i64 0
  %r939 = getelementptr i64, ptr %r863, i64 6
  %r940 = load i64, ptr %r939, align 8
  %r941 = icmp eq i64 %r940, %r872
  %r942 = getelementptr i64, ptr %r863, i64 7
  %r943 = load i64, ptr %r942, align 8
  %r944 = select i1 %r941, i64 %r943, i64 0
  %r945 = getelementptr i64, ptr %r863, i64 8
  %r946 = load i64, ptr %r945, align 8
  %r947 = icmp eq i64 %r946, %r872
  %r948 = getelementptr i64, ptr %r863, i64 9
  %r949 = load i64, ptr %r948, align 8
  %r950 = select i1 %r947, i64 %r949, i64 0
  %r951 = getelementptr i64, ptr %r863, i64 10
  %r952 = load i64, ptr %r951, align 8
  %r953 = icmp eq i64 %r952, %r872
  %r954 = getelementptr i64, ptr %r863, i64 11
  %r955 = load i64, ptr %r954, align 8
  %r956 = select i1 %r953, i64 %r955, i64 0
  %r957 = or i1 %r935, %r941
  %r958 = select i1 %r935, i64 %r938, i64 %r944
  %r959 = or i1 %r947, %r953
  %r960 = select i1 %r947, i64 %r950, i64 %r956
  %r961 = or i1 %r957, %r959
  %r962 = select i1 %r957, i64 %r958, i64 %r960
  %r963 = and i1 %r873, %r961
  br i1 %r963, label %pic.way.load.264, label %pic.miss.call.257

pic.way.load.264:                                 ; preds = %pic.ways.263
  %r964 = shl i64 %r962, 3
  %r965 = add nuw nsw i64 %r842, 16
  %r966 = add i64 %r965, %r964
  %r967 = inttoptr i64 %r966 to ptr
  %r968 = load double, ptr %r967, align 8
  %r969 = bitcast double %r968 to i64
  %r970 = icmp eq i64 %r969, 9222246136947933200
  br i1 %r970, label %pic.miss.call.257, label %pic.way.live.265

pic.way.live.265:                                 ; preds = %pic.way.load.264
  br label %pic.merge.258

pget.throw_nullish.266:                           ; preds = %pget.recv_bad.237
  %r979 = zext i1 %r977 to i32
  %statepoint_token126 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r979, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.267:                       ; preds = %pget.recv_bad.237
  %r980 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r981 = bitcast double %r980 to i64
  %r982 = and i64 %r981, 281474976710655
  %statepoint_token127 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r841, i64 %r982, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated110, ptr addrspace(1) %rs4gc.s14, ptr addrspace(1) %rs4gc.s15) ]
  %r983128 = call double @llvm.experimental.gc.result.f64(token %statepoint_token127)
  %rs4gc.s7.relocated129 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 0, i32 0) ; (%rs4gc.s7.relocated110, %rs4gc.s7.relocated110)
  %rs4gc.s14.relocated130 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 1, i32 1) ; (%rs4gc.s14, %rs4gc.s14)
  %rs4gc.s15.relocated131 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 2, i32 2) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.239

guarded_add.numeric.268:                          ; preds = %pget.recv_merge.239
  %r1005 = fadd double %r994, %r992
  br label %guarded_add.merge.270

guarded_add.dynamic.269:                          ; preds = %pget.recv_merge.239
  %statepoint_token132 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r994, double %r992, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.28, ptr addrspace(1) %.0222) ]
  %r1006133 = call double @llvm.experimental.gc.result.f64(token %statepoint_token132)
  %rs4gc.s7.relocated134 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 0, i32 0) ; (%.28, %.28)
  %rs4gc.s14.relocated135 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token132, i32 1, i32 1) ; (%.0222, %.0222)
  br label %guarded_add.merge.270

guarded_add.merge.270:                            ; preds = %guarded_add.dynamic.269, %guarded_add.numeric.268
  %.2224 = phi ptr addrspace(1) [ %.0222, %guarded_add.numeric.268 ], [ %rs4gc.s14.relocated135, %guarded_add.dynamic.269 ]
  %.30 = phi ptr addrspace(1) [ %.28, %guarded_add.numeric.268 ], [ %rs4gc.s7.relocated134, %guarded_add.dynamic.269 ]
  %r1007 = phi double [ %r1005, %guarded_add.numeric.268 ], [ %r1006133, %guarded_add.dynamic.269 ]
  %r1008.rs4i = ptrtoint ptr addrspace(1) %.2224 to i64
  %r1008.rs4o = call i64 asm "", "=r,0"(i64 %r1008.rs4i) #9
  %r1008 = bitcast i64 %r1008.rs4o to double
  %r1009 = bitcast double %r1008 to i64
  %r1010 = and i64 %r1009, -281474976710656
  %r1011 = icmp ne i64 %r1010, 9223090561878065152
  br i1 %r1011, label %str_addref.done.272, label %str_addref.call.271

str_addref.call.271:                              ; preds = %guarded_add.merge.270
  call void @js_string_addref_if_heap_string(double %r1008) #9
  br label %str_addref.done.272

str_addref.done.272:                              ; preds = %str_addref.call.271, %guarded_add.merge.270
  %r1542.rs4i = ptrtoint ptr addrspace(1) %.2224 to i64
  %r1542.rs4o = call i64 asm "", "=r,0"(i64 %r1542.rs4i) #9
  %r1542 = bitcast i64 %r1542.rs4o to double
  store double %r1542, ptr @perry_global_options_worker_ts__7, align 8
  %r1541.rs4i = ptrtoint ptr addrspace(1) %.2224 to i64
  %r1541.rs4o = call i64 asm "", "=r,0"(i64 %r1541.rs4i) #9
  %r1541 = bitcast i64 %r1541.rs4o to double
  %r1012 = bitcast double %r1541 to i64
  %r1539.rs4i = ptrtoint ptr addrspace(1) %.2224 to i64
  %r1539.rs4o = call i64 asm "", "=r,0"(i64 %r1539.rs4i) #9
  %r1539 = bitcast i64 %r1539.rs4o to double
  %r1540 = bitcast double %r1539 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1540) #9
  %r1013 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1014 = icmp ne i32 %r1013, 0
  br i1 %r1014, label %gcpoll.273, label %gcpoll.done.274

gcpoll.273:                                       ; preds = %str_addref.done.272
  %statepoint_token136 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.30) ]
  %rs4gc.s7.relocated137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token136, i32 0, i32 0) ; (%.30, %.30)
  br label %gcpoll.done.274

gcpoll.done.274:                                  ; preds = %gcpoll.273, %str_addref.done.272
  %.31 = phi ptr addrspace(1) [ %rs4gc.s7.relocated137, %gcpoll.273 ], [ %.30, %str_addref.done.272 ]
  br label %for.update.225

streqlit.sso.275:                                 ; preds = %if.else.216
  %r1024 = icmp eq i64 %r1021, 9221406112001647979
  br i1 %r1024, label %streqlit.true.281, label %streqlit.tag.276

streqlit.tag.276:                                 ; preds = %streqlit.sso.275
  %r1025 = lshr i64 %r1021, 48
  %r1026 = icmp eq i64 %r1025, 32767
  %r1027 = and i64 %r1021, 281474976710655
  %r1028 = icmp ugt i64 %r1027, 4095
  %r1029 = and i1 %r1026, %r1028
  br i1 %r1029, label %streqlit.len.277, label %streqlit.false.282

streqlit.len.277:                                 ; preds = %streqlit.tag.276
  %r1030 = inttoptr i64 %r1027 to ptr
  %r1031 = getelementptr inbounds nuw i8, ptr %r1030, i64 4
  %r1032 = load i32, ptr %r1031, align 4
  %r1033 = icmp eq i32 %r1032, 4
  br i1 %r1033, label %streqlit.b0.278, label %streqlit.false.282

streqlit.b0.278:                                  ; preds = %streqlit.len.277
  %r1034 = getelementptr inbounds nuw i8, ptr %r1030, i64 20
  %r1035 = load i8, ptr %r1034, align 1
  %r1036 = icmp eq i8 %r1035, 107
  br i1 %r1036, label %streqlit.bl.279, label %streqlit.false.282

streqlit.bl.279:                                  ; preds = %streqlit.b0.278
  %r1037 = getelementptr inbounds nuw i8, ptr %r1030, i64 23
  %r1038 = load i8, ptr %r1037, align 1
  %r1039 = icmp eq i8 %r1038, 115
  br i1 %r1039, label %streqlit.slow.280, label %streqlit.false.282

streqlit.slow.280:                                ; preds = %streqlit.bl.279
  %r1040 = and i64 %r1022, 281474976710655
  %statepoint_token138 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1027, i64 %r1040, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.24) ]
  %r1041139 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token138)
  %rs4gc.s7.relocated140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token138, i32 0, i32 0) ; (%.24, %.24)
  %r1042 = icmp ne i32 %r1041139, 0
  br label %streqlit.merge.283

streqlit.true.281:                                ; preds = %streqlit.sso.275, %if.else.216
  br label %streqlit.merge.283

streqlit.false.282:                               ; preds = %streqlit.bl.279, %streqlit.b0.278, %streqlit.len.277, %streqlit.tag.276
  br label %streqlit.merge.283

streqlit.merge.283:                               ; preds = %streqlit.false.282, %streqlit.true.281, %streqlit.slow.280
  %.32 = phi ptr addrspace(1) [ %.24, %streqlit.true.281 ], [ %rs4gc.s7.relocated140, %streqlit.slow.280 ], [ %.24, %streqlit.false.282 ]
  %r1043 = phi i1 [ true, %streqlit.true.281 ], [ false, %streqlit.false.282 ], [ %r1042, %streqlit.slow.280 ]
  %r1044 = select i1 %r1043, i64 9222246136947933188, i64 9222246136947933187
  %r1045 = bitcast i64 %r1044 to double
  %r1046 = icmp eq i64 %r1044, 9222246136947933188
  br i1 %r1046, label %if.then.284, label %if.else.285

if.then.284:                                      ; preds = %streqlit.merge.283
  %r1051.rs4i = ptrtoint ptr addrspace(1) %.32 to i64
  %r1051.rs4o = call i64 asm "", "=r,0"(i64 %r1051.rs4i) #9
  %r1051 = bitcast i64 %r1051.rs4o to double
  %r1052 = bitcast double %r1051 to i64
  %r1053 = and i64 %r1052, -281474976710656
  %r1054 = icmp ult i64 %r1053, 9221401712017801216
  %r1055 = icmp ugt i64 %r1053, 9223090561878065152
  %r1056 = or i1 %r1054, %r1055
  br i1 %r1056, label %for.bound_i32.number.287, label %for.bound_i32.merge.289

if.else.285:                                      ; preds = %streqlit.merge.283
  %r1274 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r1275 = load double, ptr @options_worker_ts_.str.6.handle, align 8
  %r1276 = bitcast double %r1274 to i64
  %r1277 = bitcast double %r1275 to i64
  %r1278 = icmp eq i64 %r1276, %r1277
  br i1 %r1278, label %streqlit.true.349, label %streqlit.tag.344

if.merge.286:                                     ; preds = %if.merge.354, %for.exit.295
  %r2.8 = phi double [ %r2.9, %for.exit.295 ], [ %r2.10, %if.merge.354 ]
  br label %if.merge.217

for.bound_i32.number.287:                         ; preds = %if.then.284
  %r1057 = fcmp oge double %r1051, 0xC1E0000000000000
  %r1058 = fcmp ole double %r1051, 0x41DFFFFFFFC00000
  %r1059 = and i1 %r1057, %r1058
  br i1 %r1059, label %for.bound_i32.convert.288, label %for.bound_i32.merge.289

for.bound_i32.convert.288:                        ; preds = %for.bound_i32.number.287
  %r1060 = fptosi double %r1051 to i32
  %r1061 = sitofp i32 %r1060 to double
  %r1062 = fcmp oeq double %r1061, %r1051
  br i1 %r1062, label %for.counter_i32.range.290, label %for.bound_i32.merge.289

for.bound_i32.merge.289:                          ; preds = %for.counter_i32.convert.291, %for.bound_i32.convert.288, %for.bound_i32.number.287, %if.then.284
  %r1050.0 = phi i32 [ %r1060, %for.counter_i32.convert.291 ], [ 0, %if.then.284 ], [ %r1060, %for.bound_i32.convert.288 ], [ 0, %for.bound_i32.number.287 ]
  %r1049.0 = phi i1 [ true, %for.counter_i32.convert.291 ], [ false, %if.then.284 ], [ false, %for.bound_i32.convert.288 ], [ false, %for.bound_i32.number.287 ]
  br label %for.cond.292

for.counter_i32.range.290:                        ; preds = %for.bound_i32.convert.288
  br label %for.counter_i32.convert.291

for.counter_i32.convert.291:                      ; preds = %for.counter_i32.range.290
  br label %for.bound_i32.merge.289

for.cond.292:                                     ; preds = %for.update.294, %for.bound_i32.merge.289
  %.33 = phi ptr addrspace(1) [ %.32, %for.bound_i32.merge.289 ], [ %.39, %for.update.294 ]
  %r1048.1 = phi i32 [ 0, %for.bound_i32.merge.289 ], [ %r1273, %for.update.294 ]
  %r1047.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.289 ], [ %r1271, %for.update.294 ]
  %r2.9 = phi double [ 0.000000e+00, %for.bound_i32.merge.289 ], [ %r1262, %for.update.294 ]
  br i1 %r1049.0, label %for.cond.fast.296, label %for.cond.slow.297

for.body.293:                                     ; preds = %gcpoll.done.299, %for.cond.fast.296
  %.34 = phi ptr addrspace(1) [ %.33, %for.cond.fast.296 ], [ %.35, %gcpoll.done.299 ]
  %r1083 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %r1084 = load double, ptr @perry_global_options_worker_ts__6, align 8
  %statepoint_token141 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1083, double %r1084, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.34) ]
  %r1085142 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token141)
  %rs4gc.s7.relocated143 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 0, i32 0) ; (%.34, %.34)
  %r1086 = bitcast i64 %r1085142 to double
  %rs4gc.b16 = bitcast double %r1086 to i64
  %rs4gc.s16 = inttoptr i64 %rs4gc.b16 to ptr addrspace(1)
  %r1087.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r1087 = call i64 asm "", "=r,0"(i64 %r1087.rs4i) #9
  %r1088 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1089 = icmp ne i32 %r1088, 0
  br i1 %r1089, label %shadow.root.barrier.300, label %shadow.root.barrier.done.301

for.update.294:                                   ; preds = %gcpoll.done.343
  %r1271 = fadd double %r1047.0, 1.000000e+00
  %r1273 = add i32 %r1048.1, 1
  br label %for.cond.292

for.exit.295:                                     ; preds = %gcpoll.done.299, %for.cond.fast.296
  br label %if.merge.286

for.cond.fast.296:                                ; preds = %for.cond.292
  %r1073 = icmp slt i32 %r1048.1, %r1050.0
  br i1 %r1073, label %for.body.293, label %for.exit.295

for.cond.slow.297:                                ; preds = %for.cond.292
  %r1075.rs4i = ptrtoint ptr addrspace(1) %.33 to i64
  %r1075.rs4o = call i64 asm "", "=r,0"(i64 %r1075.rs4i) #9
  %r1075 = bitcast i64 %r1075.rs4o to double
  %r1076 = fcmp olt double %r1047.0, %r1075
  %r1077 = select i1 %r1076, i64 9222246136947933188, i64 9222246136947933187
  %r1078 = bitcast i64 %r1077 to double
  %r1080 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1081 = icmp ne i32 %r1080, 0
  br i1 %r1081, label %gcpoll.298, label %gcpoll.done.299

gcpoll.298:                                       ; preds = %for.cond.slow.297
  %statepoint_token144 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.33) ]
  %rs4gc.s7.relocated145 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token144, i32 0, i32 0) ; (%.33, %.33)
  br label %gcpoll.done.299

gcpoll.done.299:                                  ; preds = %gcpoll.298, %for.cond.slow.297
  %.35 = phi ptr addrspace(1) [ %rs4gc.s7.relocated145, %gcpoll.298 ], [ %.33, %for.cond.slow.297 ]
  %r1079 = icmp eq i64 %r1077, 9222246136947933188
  br i1 %r1079, label %for.body.293, label %for.exit.295

shadow.root.barrier.300:                          ; preds = %for.body.293
  call void @js_write_barrier_root_nanbox(i64 %r1087) #9
  br label %shadow.root.barrier.done.301

shadow.root.barrier.done.301:                     ; preds = %shadow.root.barrier.300, %for.body.293
  %r1091 = bitcast double %r2.9 to i64
  %rs4gc.s17 = inttoptr i64 %r1091 to ptr addrspace(1)
  %r1092.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r1092 = call i64 asm "", "=r,0"(i64 %r1092.rs4i) #9
  %r1093 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1094 = icmp ne i32 %r1093, 0
  br i1 %r1094, label %shadow.root.barrier.302, label %shadow.root.barrier.done.303

shadow.root.barrier.302:                          ; preds = %shadow.root.barrier.done.301
  call void @js_write_barrier_root_nanbox(i64 %r1092) #9
  br label %shadow.root.barrier.done.303

shadow.root.barrier.done.303:                     ; preds = %shadow.root.barrier.302, %shadow.root.barrier.done.301
  %r1095.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r1095.rs4o = call i64 asm "", "=r,0"(i64 %r1095.rs4i) #9
  %r1095 = bitcast i64 %r1095.rs4o to double
  %r1096 = bitcast double %r1095 to i64
  %r1097 = and i64 %r1096, 281474976710655
  %r1098 = lshr i64 %r1096, 48
  %r1099 = and i64 %r1098, 65533
  %r1100 = icmp eq i64 %r1099, 32765
  br i1 %r1100, label %pget.recv_ok.305, label %pget.recv_other.310

pget.recv_sso.304:                                ; preds = %pget.recv_other.310
  %r1239 = lshr i64 %r1096, 40
  %r1240 = and i64 %r1239, 255
  %r1241 = uitofp nneg i64 %r1240 to double
  br label %pget.recv_merge.308

pget.recv_ok.305:                                 ; preds = %shadow.root.barrier.done.303
  %r1107 = icmp eq i64 %r1098, 32767
  br i1 %r1107, label %pget.strlen_heap.309, label %pget.recv_obj.312

pget.recv_bad.306:                                ; preds = %pget.check_class_ref.311
  %r1231 = icmp eq i64 %r1096, 9222246136947933185
  %r1232 = icmp eq i64 %r1096, 9222246136947933186
  %r1233 = or i1 %r1231, %r1232
  br i1 %r1233, label %pget.throw_nullish.335, label %pget.recv_undef_return.336

pget.recv_class_ref.307:                          ; preds = %pget.check_class_ref.311
  %r1103 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1104 = bitcast double %r1103 to i64
  %r1105 = and i64 %r1104, 281474976710655
  %statepoint_token146 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532872, i64 %r1096, i64 %r1105, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated143, ptr addrspace(1) %rs4gc.s16, ptr addrspace(1) %rs4gc.s17) ]
  %r1106147 = call double @llvm.experimental.gc.result.f64(token %statepoint_token146)
  %rs4gc.s7.relocated148 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token146, i32 0, i32 0) ; (%rs4gc.s7.relocated143, %rs4gc.s7.relocated143)
  %rs4gc.s16.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token146, i32 1, i32 1) ; (%rs4gc.s16, %rs4gc.s16)
  %rs4gc.s17.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token146, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pget.recv_merge.308

pget.recv_merge.308:                              ; preds = %pget.recv_undef_return.336, %pic.merge.327, %pget.strlen_heap.309, %pget.recv_class_ref.307, %pget.recv_sso.304
  %.0230 = phi ptr addrspace(1) [ %rs4gc.s17, %pget.strlen_heap.309 ], [ %.1231, %pic.merge.327 ], [ %rs4gc.s17, %pget.recv_sso.304 ], [ %rs4gc.s17.relocated, %pget.recv_class_ref.307 ], [ %rs4gc.s17.relocated164, %pget.recv_undef_return.336 ]
  %.0227 = phi ptr addrspace(1) [ %rs4gc.s16, %pget.strlen_heap.309 ], [ %.1228, %pic.merge.327 ], [ %rs4gc.s16, %pget.recv_sso.304 ], [ %rs4gc.s16.relocated, %pget.recv_class_ref.307 ], [ %rs4gc.s16.relocated163, %pget.recv_undef_return.336 ]
  %.36 = phi ptr addrspace(1) [ %rs4gc.s7.relocated143, %pget.strlen_heap.309 ], [ %.37, %pic.merge.327 ], [ %rs4gc.s7.relocated143, %pget.recv_sso.304 ], [ %rs4gc.s7.relocated148, %pget.recv_class_ref.307 ], [ %rs4gc.s7.relocated162, %pget.recv_undef_return.336 ]
  %r1247 = phi double [ %r1230, %pic.merge.327 ], [ %r1238161, %pget.recv_undef_return.336 ], [ %r1241, %pget.recv_sso.304 ], [ %r1106147, %pget.recv_class_ref.307 ], [ %r1246, %pget.strlen_heap.309 ]
  %r1248.rs4i = ptrtoint ptr addrspace(1) %.0230 to i64
  %r1248 = call i64 asm "", "=r,0"(i64 %r1248.rs4i) #9
  %r1249 = bitcast i64 %r1248 to double
  %r1250 = and i64 %r1248, -281474976710656
  %r1251 = icmp ult i64 %r1250, 9221401712017801216
  %r1252 = icmp ugt i64 %r1250, 9223090561878065152
  %r1253 = or i1 %r1251, %r1252
  %r1254 = bitcast double %r1247 to i64
  %r1255 = and i64 %r1254, -281474976710656
  %r1256 = icmp ult i64 %r1255, 9221401712017801216
  %r1257 = icmp ugt i64 %r1255, 9223090561878065152
  %r1258 = or i1 %r1256, %r1257
  %r1259 = and i1 %r1253, %r1258
  br i1 %r1259, label %guarded_add.numeric.337, label %guarded_add.dynamic.338

pget.strlen_heap.309:                             ; preds = %pget.recv_ok.305
  %r1242 = icmp ult i64 %r1097, 4096
  %r1243 = inttoptr i64 %r1097 to ptr
  %r1244 = select i1 %r1242, ptr @perry_null_guard_zero_options_worker_ts, ptr %r1243
  %r1245 = load i32, ptr %r1244, align 4
  %r1246 = uitofp i32 %r1245 to double
  br label %pget.recv_merge.308

pget.recv_other.310:                              ; preds = %shadow.root.barrier.done.303
  %r1101 = icmp eq i64 %r1098, 32761
  br i1 %r1101, label %pget.recv_sso.304, label %pget.check_class_ref.311

pget.check_class_ref.311:                         ; preds = %pget.recv_other.310
  %r1102 = icmp eq i64 %r1098, 32766
  br i1 %r1102, label %pget.recv_class_ref.307, label %pget.recv_bad.306

pget.recv_obj.312:                                ; preds = %pget.recv_ok.305
  %r1108 = icmp ugt i64 %r1097, 1048575
  br i1 %r1108, label %pic.recv_hdr.328, label %pic.miss.cold.325

pic.hit.313:                                      ; preds = %pic.token.329
  %r1133 = getelementptr i64, ptr %r1118, i64 1
  %r1134 = load i64, ptr %r1133, align 8
  %r1135 = and i64 %r1134, 1073741824
  %r1136 = icmp ne i64 %r1135, 0
  br i1 %r1136, label %pic.hit.overflow.330, label %pic.hit.inline.331

pic.hit.live.314:                                 ; preds = %pic.hit.inline.331
  br label %pic.merge.327

pic.prefix.guard.315:                             ; preds = %pic.token.329
  %r1149 = getelementptr i64, ptr %r1118, i64 2
  %r1150 = load i64, ptr %r1149, align 8
  %r1151 = icmp ne i64 %r1150, 0
  br i1 %r1151, label %pic.prefix.meta.316, label %pic.miss.324

pic.prefix.meta.316:                              ; preds = %pic.prefix.guard.315
  %r1152 = add nuw nsw i64 %r1097, 8
  %r1153 = inttoptr i64 %r1152 to ptr
  %r1154 = load i64, ptr %r1153, align 8
  %r1155 = icmp ne i64 %r1154, 0
  br i1 %r1155, label %pic.prefix.token.317, label %pic.miss.324

pic.prefix.token.317:                             ; preds = %pic.prefix.meta.316
  %r1156 = inttoptr i64 %r1154 to ptr
  %r1157 = getelementptr i64, ptr %r1156, i64 6
  %r1158 = load i64, ptr %r1157, align 8
  %r1159 = icmp eq i64 %r1158, %r1150
  br i1 %r1159, label %pic.prefix.hit.318, label %pic.miss.324

pic.prefix.hit.318:                               ; preds = %pic.prefix.token.317
  %r1160 = getelementptr i64, ptr %r1118, i64 1
  %r1161 = load i64, ptr %r1160, align 8
  %r1162 = shl i64 %r1161, 3
  %r1163 = add nuw nsw i64 %r1097, 16
  %r1164 = add i64 %r1163, %r1162
  %r1165 = inttoptr i64 %r1164 to ptr
  %r1166 = load double, ptr %r1165, align 8
  br label %pic.merge.327

pic.desc.classify.319:                            ; preds = %pic.recv_hdr.328
  %r1122 = and i1 %r1112, %r1119
  br i1 %r1122, label %pic.desc.prefix.guard.320, label %pic.miss.cold.325

pic.desc.prefix.guard.320:                        ; preds = %pic.desc.classify.319
  %r1167 = getelementptr i64, ptr %r1118, i64 2
  %r1168 = load i64, ptr %r1167, align 8
  %r1169 = icmp ne i64 %r1168, 0
  br i1 %r1169, label %pic.desc.prefix.meta.321, label %pic.miss.cold.325

pic.desc.prefix.meta.321:                         ; preds = %pic.desc.prefix.guard.320
  %r1170 = add nuw nsw i64 %r1097, 8
  %r1171 = inttoptr i64 %r1170 to ptr
  %r1172 = load i64, ptr %r1171, align 8
  %r1173 = icmp ne i64 %r1172, 0
  br i1 %r1173, label %pic.desc.prefix.token.322, label %pic.miss.cold.325

pic.desc.prefix.token.322:                        ; preds = %pic.desc.prefix.meta.321
  %r1174 = inttoptr i64 %r1172 to ptr
  %r1175 = getelementptr i64, ptr %r1174, i64 6
  %r1176 = load i64, ptr %r1175, align 8
  %r1177 = icmp eq i64 %r1176, %r1168
  br i1 %r1177, label %pic.desc.prefix.hit.323, label %pic.miss.cold.325

pic.desc.prefix.hit.323:                          ; preds = %pic.desc.prefix.token.322
  %r1178 = getelementptr i64, ptr %r1118, i64 1
  %r1179 = load i64, ptr %r1178, align 8
  %r1180 = shl i64 %r1179, 3
  %r1181 = add nuw nsw i64 %r1097, 16
  %r1182 = add i64 %r1181, %r1180
  %r1183 = inttoptr i64 %r1182 to ptr
  %r1184 = load double, ptr %r1183, align 8
  br label %pic.merge.327

pic.miss.324:                                     ; preds = %pic.hit.inline.331, %pic.prefix.token.317, %pic.prefix.meta.316, %pic.prefix.guard.315
  %r1185 = getelementptr i64, ptr %r1118, i64 3
  %r1186 = load i64, ptr %r1185, align 8
  %r1187 = icmp sgt i64 %r1186, 0
  br i1 %r1187, label %pic.ways.332, label %pic.miss.call.326

pic.miss.cold.325:                                ; preds = %pic.desc.prefix.token.322, %pic.desc.prefix.meta.321, %pic.desc.prefix.guard.320, %pic.desc.classify.319, %pget.recv_obj.312
  br label %pic.miss.call.326

pic.miss.call.326:                                ; preds = %pic.way.load.333, %pic.ways.332, %pic.miss.cold.325, %pic.miss.324
  %r1226 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1227 = bitcast double %r1226 to i64
  %r1228 = and i64 %r1227, 281474976710655
  %statepoint_token149 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1097, i64 %r1228, ptr @perry_ic_options_worker_ts__9, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated143, ptr addrspace(1) %rs4gc.s16, ptr addrspace(1) %rs4gc.s17) ]
  %r1229150 = call double @llvm.experimental.gc.result.f64(token %statepoint_token149)
  %rs4gc.s7.relocated151 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token149, i32 0, i32 0) ; (%rs4gc.s7.relocated143, %rs4gc.s7.relocated143)
  %rs4gc.s16.relocated152 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token149, i32 1, i32 1) ; (%rs4gc.s16, %rs4gc.s16)
  %rs4gc.s17.relocated153 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token149, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pic.merge.327

pic.merge.327:                                    ; preds = %pic.way.live.334, %pic.hit.overflow.330, %pic.miss.call.326, %pic.desc.prefix.hit.323, %pic.prefix.hit.318, %pic.hit.live.314
  %.1231 = phi ptr addrspace(1) [ %rs4gc.s17.relocated158, %pic.hit.overflow.330 ], [ %rs4gc.s17.relocated153, %pic.miss.call.326 ], [ %rs4gc.s17, %pic.way.live.334 ], [ %rs4gc.s17, %pic.hit.live.314 ], [ %rs4gc.s17, %pic.prefix.hit.318 ], [ %rs4gc.s17, %pic.desc.prefix.hit.323 ]
  %.1228 = phi ptr addrspace(1) [ %rs4gc.s16.relocated157, %pic.hit.overflow.330 ], [ %rs4gc.s16.relocated152, %pic.miss.call.326 ], [ %rs4gc.s16, %pic.way.live.334 ], [ %rs4gc.s16, %pic.hit.live.314 ], [ %rs4gc.s16, %pic.prefix.hit.318 ], [ %rs4gc.s16, %pic.desc.prefix.hit.323 ]
  %.37 = phi ptr addrspace(1) [ %rs4gc.s7.relocated156, %pic.hit.overflow.330 ], [ %rs4gc.s7.relocated151, %pic.miss.call.326 ], [ %rs4gc.s7.relocated143, %pic.way.live.334 ], [ %rs4gc.s7.relocated143, %pic.hit.live.314 ], [ %rs4gc.s7.relocated143, %pic.prefix.hit.318 ], [ %rs4gc.s7.relocated143, %pic.desc.prefix.hit.323 ]
  %r1230 = phi double [ %r1146, %pic.hit.live.314 ], [ %r1141155, %pic.hit.overflow.330 ], [ %r1166, %pic.prefix.hit.318 ], [ %r1184, %pic.desc.prefix.hit.323 ], [ %r1223, %pic.way.live.334 ], [ %r1229150, %pic.miss.call.326 ]
  br label %pget.recv_merge.308

pic.recv_hdr.328:                                 ; preds = %pget.recv_obj.312
  %r1109 = sub nuw nsw i64 %r1097, 8
  %r1110 = inttoptr i64 %r1109 to ptr
  %r1111 = load i8, ptr %r1110, align 1
  %r1112 = icmp eq i8 %r1111, 2
  %r1113 = sub nuw nsw i64 %r1097, 6
  %r1114 = inttoptr i64 %r1113 to ptr
  %r1115 = load i16, ptr %r1114, align 2
  %r1116 = and i16 %r1115, 2048
  %r1117 = icmp eq i16 %r1116, 0
  %r1118 = load ptr, ptr @perry_ic_options_worker_ts__9, align 8
  %r1119 = icmp ne ptr %r1118, null
  %r1120 = and i1 %r1112, %r1117
  %r1121 = and i1 %r1120, %r1119
  br i1 %r1121, label %pic.token.329, label %pic.desc.classify.319

pic.token.329:                                    ; preds = %pic.recv_hdr.328
  %r1123 = add nuw nsw i64 %r1097, 4
  %r1124 = inttoptr i64 %r1123 to ptr
  %r1125 = load i32, ptr %r1124, align 4
  %r1126 = zext i32 %r1125 to i64
  %r1127 = or i64 %r1126, 4611686018427387904
  %r1128 = icmp ne i32 %r1125, 0
  %r1129 = getelementptr i64, ptr %r1118, i64 0
  %r1130 = load i64, ptr %r1129, align 8
  %r1131 = icmp eq i64 %r1127, %r1130
  %r1132 = and i1 %r1131, %r1128
  br i1 %r1132, label %pic.hit.313, label %pic.prefix.guard.315

pic.hit.overflow.330:                             ; preds = %pic.hit.313
  %r1137 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1138 = bitcast double %r1137 to i64
  %r1139 = and i64 %r1138, 281474976710655
  %r1140 = trunc i64 %r1134 to i32
  %statepoint_token154 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1097, i64 %r1139, i32 %r1140, ptr @perry_ic_options_worker_ts__9, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated143, ptr addrspace(1) %rs4gc.s16, ptr addrspace(1) %rs4gc.s17) ]
  %r1141155 = call double @llvm.experimental.gc.result.f64(token %statepoint_token154)
  %rs4gc.s7.relocated156 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token154, i32 0, i32 0) ; (%rs4gc.s7.relocated143, %rs4gc.s7.relocated143)
  %rs4gc.s16.relocated157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token154, i32 1, i32 1) ; (%rs4gc.s16, %rs4gc.s16)
  %rs4gc.s17.relocated158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token154, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pic.merge.327

pic.hit.inline.331:                               ; preds = %pic.hit.313
  %r1142 = shl i64 %r1134, 3
  %r1143 = add nuw nsw i64 %r1097, 16
  %r1144 = add i64 %r1143, %r1142
  %r1145 = inttoptr i64 %r1144 to ptr
  %r1146 = load double, ptr %r1145, align 8
  %r1147 = bitcast double %r1146 to i64
  %r1148 = icmp eq i64 %r1147, 9222246136947933200
  br i1 %r1148, label %pic.miss.324, label %pic.hit.live.314

pic.ways.332:                                     ; preds = %pic.miss.324
  %r1188 = getelementptr i64, ptr %r1118, i64 4
  %r1189 = load i64, ptr %r1188, align 8
  %r1190 = icmp eq i64 %r1189, %r1127
  %r1191 = getelementptr i64, ptr %r1118, i64 5
  %r1192 = load i64, ptr %r1191, align 8
  %r1193 = select i1 %r1190, i64 %r1192, i64 0
  %r1194 = getelementptr i64, ptr %r1118, i64 6
  %r1195 = load i64, ptr %r1194, align 8
  %r1196 = icmp eq i64 %r1195, %r1127
  %r1197 = getelementptr i64, ptr %r1118, i64 7
  %r1198 = load i64, ptr %r1197, align 8
  %r1199 = select i1 %r1196, i64 %r1198, i64 0
  %r1200 = getelementptr i64, ptr %r1118, i64 8
  %r1201 = load i64, ptr %r1200, align 8
  %r1202 = icmp eq i64 %r1201, %r1127
  %r1203 = getelementptr i64, ptr %r1118, i64 9
  %r1204 = load i64, ptr %r1203, align 8
  %r1205 = select i1 %r1202, i64 %r1204, i64 0
  %r1206 = getelementptr i64, ptr %r1118, i64 10
  %r1207 = load i64, ptr %r1206, align 8
  %r1208 = icmp eq i64 %r1207, %r1127
  %r1209 = getelementptr i64, ptr %r1118, i64 11
  %r1210 = load i64, ptr %r1209, align 8
  %r1211 = select i1 %r1208, i64 %r1210, i64 0
  %r1212 = or i1 %r1190, %r1196
  %r1213 = select i1 %r1190, i64 %r1193, i64 %r1199
  %r1214 = or i1 %r1202, %r1208
  %r1215 = select i1 %r1202, i64 %r1205, i64 %r1211
  %r1216 = or i1 %r1212, %r1214
  %r1217 = select i1 %r1212, i64 %r1213, i64 %r1215
  %r1218 = and i1 %r1128, %r1216
  br i1 %r1218, label %pic.way.load.333, label %pic.miss.call.326

pic.way.load.333:                                 ; preds = %pic.ways.332
  %r1219 = shl i64 %r1217, 3
  %r1220 = add nuw nsw i64 %r1097, 16
  %r1221 = add i64 %r1220, %r1219
  %r1222 = inttoptr i64 %r1221 to ptr
  %r1223 = load double, ptr %r1222, align 8
  %r1224 = bitcast double %r1223 to i64
  %r1225 = icmp eq i64 %r1224, 9222246136947933200
  br i1 %r1225, label %pic.miss.call.326, label %pic.way.live.334

pic.way.live.334:                                 ; preds = %pic.way.load.333
  br label %pic.merge.327

pget.throw_nullish.335:                           ; preds = %pget.recv_bad.306
  %r1234 = zext i1 %r1232 to i32
  %statepoint_token159 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1234, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.336:                       ; preds = %pget.recv_bad.306
  %r1235 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1236 = bitcast double %r1235 to i64
  %r1237 = and i64 %r1236, 281474976710655
  %statepoint_token160 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1096, i64 %r1237, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated143, ptr addrspace(1) %rs4gc.s16, ptr addrspace(1) %rs4gc.s17) ]
  %r1238161 = call double @llvm.experimental.gc.result.f64(token %statepoint_token160)
  %rs4gc.s7.relocated162 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 0, i32 0) ; (%rs4gc.s7.relocated143, %rs4gc.s7.relocated143)
  %rs4gc.s16.relocated163 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 1, i32 1) ; (%rs4gc.s16, %rs4gc.s16)
  %rs4gc.s17.relocated164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pget.recv_merge.308

guarded_add.numeric.337:                          ; preds = %pget.recv_merge.308
  %r1260 = fadd double %r1249, %r1247
  br label %guarded_add.merge.339

guarded_add.dynamic.338:                          ; preds = %pget.recv_merge.308
  %statepoint_token165 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r1249, double %r1247, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.36, ptr addrspace(1) %.0227) ]
  %r1261166 = call double @llvm.experimental.gc.result.f64(token %statepoint_token165)
  %rs4gc.s7.relocated167 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 0, i32 0) ; (%.36, %.36)
  %rs4gc.s16.relocated168 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 1, i32 1) ; (%.0227, %.0227)
  br label %guarded_add.merge.339

guarded_add.merge.339:                            ; preds = %guarded_add.dynamic.338, %guarded_add.numeric.337
  %.2229 = phi ptr addrspace(1) [ %.0227, %guarded_add.numeric.337 ], [ %rs4gc.s16.relocated168, %guarded_add.dynamic.338 ]
  %.38 = phi ptr addrspace(1) [ %.36, %guarded_add.numeric.337 ], [ %rs4gc.s7.relocated167, %guarded_add.dynamic.338 ]
  %r1262 = phi double [ %r1260, %guarded_add.numeric.337 ], [ %r1261166, %guarded_add.dynamic.338 ]
  %r1263.rs4i = ptrtoint ptr addrspace(1) %.2229 to i64
  %r1263.rs4o = call i64 asm "", "=r,0"(i64 %r1263.rs4i) #9
  %r1263 = bitcast i64 %r1263.rs4o to double
  %r1264 = bitcast double %r1263 to i64
  %r1265 = and i64 %r1264, -281474976710656
  %r1266 = icmp ne i64 %r1265, 9223090561878065152
  br i1 %r1266, label %str_addref.done.341, label %str_addref.call.340

str_addref.call.340:                              ; preds = %guarded_add.merge.339
  call void @js_string_addref_if_heap_string(double %r1263) #9
  br label %str_addref.done.341

str_addref.done.341:                              ; preds = %str_addref.call.340, %guarded_add.merge.339
  %r1538.rs4i = ptrtoint ptr addrspace(1) %.2229 to i64
  %r1538.rs4o = call i64 asm "", "=r,0"(i64 %r1538.rs4i) #9
  %r1538 = bitcast i64 %r1538.rs4o to double
  store double %r1538, ptr @perry_global_options_worker_ts__7, align 8
  %r1537.rs4i = ptrtoint ptr addrspace(1) %.2229 to i64
  %r1537.rs4o = call i64 asm "", "=r,0"(i64 %r1537.rs4i) #9
  %r1537 = bitcast i64 %r1537.rs4o to double
  %r1267 = bitcast double %r1537 to i64
  %r1535.rs4i = ptrtoint ptr addrspace(1) %.2229 to i64
  %r1535.rs4o = call i64 asm "", "=r,0"(i64 %r1535.rs4i) #9
  %r1535 = bitcast i64 %r1535.rs4o to double
  %r1536 = bitcast double %r1535 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1536) #9
  %r1268 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1269 = icmp ne i32 %r1268, 0
  br i1 %r1269, label %gcpoll.342, label %gcpoll.done.343

gcpoll.342:                                       ; preds = %str_addref.done.341
  %statepoint_token169 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.38) ]
  %rs4gc.s7.relocated170 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token169, i32 0, i32 0) ; (%.38, %.38)
  br label %gcpoll.done.343

gcpoll.done.343:                                  ; preds = %gcpoll.342, %str_addref.done.341
  %.39 = phi ptr addrspace(1) [ %rs4gc.s7.relocated170, %gcpoll.342 ], [ %.38, %str_addref.done.341 ]
  br label %for.update.294

streqlit.tag.344:                                 ; preds = %if.else.285
  %r1279 = lshr i64 %r1276, 48
  %r1280 = icmp eq i64 %r1279, 32767
  %r1281 = and i64 %r1276, 281474976710655
  %r1282 = icmp ugt i64 %r1281, 4095
  %r1283 = and i1 %r1280, %r1282
  br i1 %r1283, label %streqlit.len.345, label %streqlit.false.350

streqlit.len.345:                                 ; preds = %streqlit.tag.344
  %r1284 = inttoptr i64 %r1281 to ptr
  %r1285 = getelementptr inbounds nuw i8, ptr %r1284, i64 4
  %r1286 = load i32, ptr %r1285, align 4
  %r1287 = icmp eq i32 %r1286, 8
  br i1 %r1287, label %streqlit.b0.346, label %streqlit.false.350

streqlit.b0.346:                                  ; preds = %streqlit.len.345
  %r1288 = getelementptr inbounds nuw i8, ptr %r1284, i64 20
  %r1289 = load i8, ptr %r1288, align 1
  %r1290 = icmp eq i8 %r1289, 99
  br i1 %r1290, label %streqlit.bl.347, label %streqlit.false.350

streqlit.bl.347:                                  ; preds = %streqlit.b0.346
  %r1291 = getelementptr inbounds nuw i8, ptr %r1284, i64 27
  %r1292 = load i8, ptr %r1291, align 1
  %r1293 = icmp eq i8 %r1292, 107
  br i1 %r1293, label %streqlit.slow.348, label %streqlit.false.350

streqlit.slow.348:                                ; preds = %streqlit.bl.347
  %r1294 = and i64 %r1277, 281474976710655
  %statepoint_token171 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1281, i64 %r1294, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.32) ]
  %r1295172 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token171)
  %rs4gc.s7.relocated173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 0, i32 0) ; (%.32, %.32)
  %r1296 = icmp ne i32 %r1295172, 0
  br label %streqlit.merge.351

streqlit.true.349:                                ; preds = %if.else.285
  br label %streqlit.merge.351

streqlit.false.350:                               ; preds = %streqlit.bl.347, %streqlit.b0.346, %streqlit.len.345, %streqlit.tag.344
  br label %streqlit.merge.351

streqlit.merge.351:                               ; preds = %streqlit.false.350, %streqlit.true.349, %streqlit.slow.348
  %.40 = phi ptr addrspace(1) [ %.32, %streqlit.true.349 ], [ %rs4gc.s7.relocated173, %streqlit.slow.348 ], [ %.32, %streqlit.false.350 ]
  %r1297 = phi i1 [ true, %streqlit.true.349 ], [ false, %streqlit.false.350 ], [ %r1296, %streqlit.slow.348 ]
  %r1298 = select i1 %r1297, i64 9222246136947933188, i64 9222246136947933187
  %r1299 = bitcast i64 %r1298 to double
  %r1300 = icmp eq i64 %r1298, 9222246136947933188
  br i1 %r1300, label %if.then.352, label %if.else.353

if.then.352:                                      ; preds = %streqlit.merge.351
  %r1305.rs4i = ptrtoint ptr addrspace(1) %.40 to i64
  %r1305.rs4o = call i64 asm "", "=r,0"(i64 %r1305.rs4i) #9
  %r1305 = bitcast i64 %r1305.rs4o to double
  %r1306 = bitcast double %r1305 to i64
  %r1307 = and i64 %r1306, -281474976710656
  %r1308 = icmp ult i64 %r1307, 9221401712017801216
  %r1309 = icmp ugt i64 %r1307, 9223090561878065152
  %r1310 = or i1 %r1308, %r1309
  br i1 %r1310, label %for.bound_i32.number.355, label %for.bound_i32.merge.357

if.else.353:                                      ; preds = %streqlit.merge.351
  br label %if.merge.354

if.merge.354:                                     ; preds = %for.exit.363, %if.else.353
  %r2.10 = phi double [ %r2.11, %for.exit.363 ], [ 0.000000e+00, %if.else.353 ]
  br label %if.merge.286

for.bound_i32.number.355:                         ; preds = %if.then.352
  %r1311 = fcmp oge double %r1305, 0xC1E0000000000000
  %r1312 = fcmp ole double %r1305, 0x41DFFFFFFFC00000
  %r1313 = and i1 %r1311, %r1312
  br i1 %r1313, label %for.bound_i32.convert.356, label %for.bound_i32.merge.357

for.bound_i32.convert.356:                        ; preds = %for.bound_i32.number.355
  %r1314 = fptosi double %r1305 to i32
  %r1315 = sitofp i32 %r1314 to double
  %r1316 = fcmp oeq double %r1315, %r1305
  br i1 %r1316, label %for.counter_i32.range.358, label %for.bound_i32.merge.357

for.bound_i32.merge.357:                          ; preds = %for.counter_i32.convert.359, %for.bound_i32.convert.356, %for.bound_i32.number.355, %if.then.352
  %r1304.0 = phi i32 [ %r1314, %for.counter_i32.convert.359 ], [ 0, %if.then.352 ], [ %r1314, %for.bound_i32.convert.356 ], [ 0, %for.bound_i32.number.355 ]
  %r1303.0 = phi i1 [ true, %for.counter_i32.convert.359 ], [ false, %if.then.352 ], [ false, %for.bound_i32.convert.356 ], [ false, %for.bound_i32.number.355 ]
  br label %for.cond.360

for.counter_i32.range.358:                        ; preds = %for.bound_i32.convert.356
  br label %for.counter_i32.convert.359

for.counter_i32.convert.359:                      ; preds = %for.counter_i32.range.358
  br label %for.bound_i32.merge.357

for.cond.360:                                     ; preds = %for.update.362, %for.bound_i32.merge.357
  %.41 = phi ptr addrspace(1) [ %.40, %for.bound_i32.merge.357 ], [ %.47, %for.update.362 ]
  %r1302.1 = phi i32 [ 0, %for.bound_i32.merge.357 ], [ %r1529, %for.update.362 ]
  %r1301.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.357 ], [ %r1527, %for.update.362 ]
  %r2.11 = phi double [ 0.000000e+00, %for.bound_i32.merge.357 ], [ %r1518, %for.update.362 ]
  br i1 %r1303.0, label %for.cond.fast.364, label %for.cond.slow.365

for.body.361:                                     ; preds = %gcpoll.done.367, %for.cond.fast.364
  %.42 = phi ptr addrspace(1) [ %.41, %for.cond.fast.364 ], [ %.43, %gcpoll.done.367 ]
  %r1337 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %statepoint_token174 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr)) @js_closure_alloc_singleton, i32 1, i32 0, ptr @__perry_wrap_perry_fn_options_worker_ts__identity, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.42) ]
  %r1338175 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token174)
  %rs4gc.s7.relocated176 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token174, i32 0, i32 0) ; (%.42, %.42)
  %r1339 = or i64 %r1338175, 9222527611924643840
  %r1340 = bitcast i64 %r1339 to double
  %statepoint_token177 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1337, double %r1340, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated176) ]
  %r1341178 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token177)
  %rs4gc.s7.relocated179 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token177, i32 0, i32 0) ; (%rs4gc.s7.relocated176, %rs4gc.s7.relocated176)
  %r1342 = bitcast i64 %r1341178 to double
  %rs4gc.b18 = bitcast double %r1342 to i64
  %rs4gc.s18 = inttoptr i64 %rs4gc.b18 to ptr addrspace(1)
  %r1343.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r1343 = call i64 asm "", "=r,0"(i64 %r1343.rs4i) #9
  %r1344 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1345 = icmp ne i32 %r1344, 0
  br i1 %r1345, label %shadow.root.barrier.368, label %shadow.root.barrier.done.369

for.update.362:                                   ; preds = %gcpoll.done.411
  %r1527 = fadd double %r1301.0, 1.000000e+00
  %r1529 = add i32 %r1302.1, 1
  br label %for.cond.360

for.exit.363:                                     ; preds = %gcpoll.done.367, %for.cond.fast.364
  br label %if.merge.354

for.cond.fast.364:                                ; preds = %for.cond.360
  %r1327 = icmp slt i32 %r1302.1, %r1304.0
  br i1 %r1327, label %for.body.361, label %for.exit.363

for.cond.slow.365:                                ; preds = %for.cond.360
  %r1329.rs4i = ptrtoint ptr addrspace(1) %.41 to i64
  %r1329.rs4o = call i64 asm "", "=r,0"(i64 %r1329.rs4i) #9
  %r1329 = bitcast i64 %r1329.rs4o to double
  %r1330 = fcmp olt double %r1301.0, %r1329
  %r1331 = select i1 %r1330, i64 9222246136947933188, i64 9222246136947933187
  %r1332 = bitcast i64 %r1331 to double
  %r1334 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1335 = icmp ne i32 %r1334, 0
  br i1 %r1335, label %gcpoll.366, label %gcpoll.done.367

gcpoll.366:                                       ; preds = %for.cond.slow.365
  %statepoint_token180 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41) ]
  %rs4gc.s7.relocated181 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token180, i32 0, i32 0) ; (%.41, %.41)
  br label %gcpoll.done.367

gcpoll.done.367:                                  ; preds = %gcpoll.366, %for.cond.slow.365
  %.43 = phi ptr addrspace(1) [ %rs4gc.s7.relocated181, %gcpoll.366 ], [ %.41, %for.cond.slow.365 ]
  %r1333 = icmp eq i64 %r1331, 9222246136947933188
  br i1 %r1333, label %for.body.361, label %for.exit.363

shadow.root.barrier.368:                          ; preds = %for.body.361
  call void @js_write_barrier_root_nanbox(i64 %r1343) #9
  br label %shadow.root.barrier.done.369

shadow.root.barrier.done.369:                     ; preds = %shadow.root.barrier.368, %for.body.361
  %r1347 = bitcast double %r2.11 to i64
  %rs4gc.s19 = inttoptr i64 %r1347 to ptr addrspace(1)
  %r1348.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r1348 = call i64 asm "", "=r,0"(i64 %r1348.rs4i) #9
  %r1349 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1350 = icmp ne i32 %r1349, 0
  br i1 %r1350, label %shadow.root.barrier.370, label %shadow.root.barrier.done.371

shadow.root.barrier.370:                          ; preds = %shadow.root.barrier.done.369
  call void @js_write_barrier_root_nanbox(i64 %r1348) #9
  br label %shadow.root.barrier.done.371

shadow.root.barrier.done.371:                     ; preds = %shadow.root.barrier.370, %shadow.root.barrier.done.369
  %r1351.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r1351.rs4o = call i64 asm "", "=r,0"(i64 %r1351.rs4i) #9
  %r1351 = bitcast i64 %r1351.rs4o to double
  %r1352 = bitcast double %r1351 to i64
  %r1353 = and i64 %r1352, 281474976710655
  %r1354 = lshr i64 %r1352, 48
  %r1355 = and i64 %r1354, 65533
  %r1356 = icmp eq i64 %r1355, 32765
  br i1 %r1356, label %pget.recv_ok.373, label %pget.recv_other.378

pget.recv_sso.372:                                ; preds = %pget.recv_other.378
  %r1495 = lshr i64 %r1352, 40
  %r1496 = and i64 %r1495, 255
  %r1497 = uitofp nneg i64 %r1496 to double
  br label %pget.recv_merge.376

pget.recv_ok.373:                                 ; preds = %shadow.root.barrier.done.371
  %r1363 = icmp eq i64 %r1354, 32767
  br i1 %r1363, label %pget.strlen_heap.377, label %pget.recv_obj.380

pget.recv_bad.374:                                ; preds = %pget.check_class_ref.379
  %r1487 = icmp eq i64 %r1352, 9222246136947933185
  %r1488 = icmp eq i64 %r1352, 9222246136947933186
  %r1489 = or i1 %r1487, %r1488
  br i1 %r1489, label %pget.throw_nullish.403, label %pget.recv_undef_return.404

pget.recv_class_ref.375:                          ; preds = %pget.check_class_ref.379
  %r1359 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1360 = bitcast double %r1359 to i64
  %r1361 = and i64 %r1360, 281474976710655
  %statepoint_token182 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532874, i64 %r1352, i64 %r1361, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated179, ptr addrspace(1) %rs4gc.s18, ptr addrspace(1) %rs4gc.s19) ]
  %r1362183 = call double @llvm.experimental.gc.result.f64(token %statepoint_token182)
  %rs4gc.s7.relocated184 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token182, i32 0, i32 0) ; (%rs4gc.s7.relocated179, %rs4gc.s7.relocated179)
  %rs4gc.s18.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token182, i32 1, i32 1) ; (%rs4gc.s18, %rs4gc.s18)
  %rs4gc.s19.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token182, i32 2, i32 2) ; (%rs4gc.s19, %rs4gc.s19)
  br label %pget.recv_merge.376

pget.recv_merge.376:                              ; preds = %pget.recv_undef_return.404, %pic.merge.395, %pget.strlen_heap.377, %pget.recv_class_ref.375, %pget.recv_sso.372
  %.0235 = phi ptr addrspace(1) [ %rs4gc.s19, %pget.strlen_heap.377 ], [ %.1236, %pic.merge.395 ], [ %rs4gc.s19, %pget.recv_sso.372 ], [ %rs4gc.s19.relocated, %pget.recv_class_ref.375 ], [ %rs4gc.s19.relocated200, %pget.recv_undef_return.404 ]
  %.0232 = phi ptr addrspace(1) [ %rs4gc.s18, %pget.strlen_heap.377 ], [ %.1233, %pic.merge.395 ], [ %rs4gc.s18, %pget.recv_sso.372 ], [ %rs4gc.s18.relocated, %pget.recv_class_ref.375 ], [ %rs4gc.s18.relocated199, %pget.recv_undef_return.404 ]
  %.44 = phi ptr addrspace(1) [ %rs4gc.s7.relocated179, %pget.strlen_heap.377 ], [ %.45, %pic.merge.395 ], [ %rs4gc.s7.relocated179, %pget.recv_sso.372 ], [ %rs4gc.s7.relocated184, %pget.recv_class_ref.375 ], [ %rs4gc.s7.relocated198, %pget.recv_undef_return.404 ]
  %r1503 = phi double [ %r1486, %pic.merge.395 ], [ %r1494197, %pget.recv_undef_return.404 ], [ %r1497, %pget.recv_sso.372 ], [ %r1362183, %pget.recv_class_ref.375 ], [ %r1502, %pget.strlen_heap.377 ]
  %r1504.rs4i = ptrtoint ptr addrspace(1) %.0235 to i64
  %r1504 = call i64 asm "", "=r,0"(i64 %r1504.rs4i) #9
  %r1505 = bitcast i64 %r1504 to double
  %r1506 = and i64 %r1504, -281474976710656
  %r1507 = icmp ult i64 %r1506, 9221401712017801216
  %r1508 = icmp ugt i64 %r1506, 9223090561878065152
  %r1509 = or i1 %r1507, %r1508
  %r1510 = bitcast double %r1503 to i64
  %r1511 = and i64 %r1510, -281474976710656
  %r1512 = icmp ult i64 %r1511, 9221401712017801216
  %r1513 = icmp ugt i64 %r1511, 9223090561878065152
  %r1514 = or i1 %r1512, %r1513
  %r1515 = and i1 %r1509, %r1514
  br i1 %r1515, label %guarded_add.numeric.405, label %guarded_add.dynamic.406

pget.strlen_heap.377:                             ; preds = %pget.recv_ok.373
  %r1498 = icmp ult i64 %r1353, 4096
  %r1499 = inttoptr i64 %r1353 to ptr
  %r1500 = select i1 %r1498, ptr @perry_null_guard_zero_options_worker_ts, ptr %r1499
  %r1501 = load i32, ptr %r1500, align 4
  %r1502 = uitofp i32 %r1501 to double
  br label %pget.recv_merge.376

pget.recv_other.378:                              ; preds = %shadow.root.barrier.done.371
  %r1357 = icmp eq i64 %r1354, 32761
  br i1 %r1357, label %pget.recv_sso.372, label %pget.check_class_ref.379

pget.check_class_ref.379:                         ; preds = %pget.recv_other.378
  %r1358 = icmp eq i64 %r1354, 32766
  br i1 %r1358, label %pget.recv_class_ref.375, label %pget.recv_bad.374

pget.recv_obj.380:                                ; preds = %pget.recv_ok.373
  %r1364 = icmp ugt i64 %r1353, 1048575
  br i1 %r1364, label %pic.recv_hdr.396, label %pic.miss.cold.393

pic.hit.381:                                      ; preds = %pic.token.397
  %r1389 = getelementptr i64, ptr %r1374, i64 1
  %r1390 = load i64, ptr %r1389, align 8
  %r1391 = and i64 %r1390, 1073741824
  %r1392 = icmp ne i64 %r1391, 0
  br i1 %r1392, label %pic.hit.overflow.398, label %pic.hit.inline.399

pic.hit.live.382:                                 ; preds = %pic.hit.inline.399
  br label %pic.merge.395

pic.prefix.guard.383:                             ; preds = %pic.token.397
  %r1405 = getelementptr i64, ptr %r1374, i64 2
  %r1406 = load i64, ptr %r1405, align 8
  %r1407 = icmp ne i64 %r1406, 0
  br i1 %r1407, label %pic.prefix.meta.384, label %pic.miss.392

pic.prefix.meta.384:                              ; preds = %pic.prefix.guard.383
  %r1408 = add nuw nsw i64 %r1353, 8
  %r1409 = inttoptr i64 %r1408 to ptr
  %r1410 = load i64, ptr %r1409, align 8
  %r1411 = icmp ne i64 %r1410, 0
  br i1 %r1411, label %pic.prefix.token.385, label %pic.miss.392

pic.prefix.token.385:                             ; preds = %pic.prefix.meta.384
  %r1412 = inttoptr i64 %r1410 to ptr
  %r1413 = getelementptr i64, ptr %r1412, i64 6
  %r1414 = load i64, ptr %r1413, align 8
  %r1415 = icmp eq i64 %r1414, %r1406
  br i1 %r1415, label %pic.prefix.hit.386, label %pic.miss.392

pic.prefix.hit.386:                               ; preds = %pic.prefix.token.385
  %r1416 = getelementptr i64, ptr %r1374, i64 1
  %r1417 = load i64, ptr %r1416, align 8
  %r1418 = shl i64 %r1417, 3
  %r1419 = add nuw nsw i64 %r1353, 16
  %r1420 = add i64 %r1419, %r1418
  %r1421 = inttoptr i64 %r1420 to ptr
  %r1422 = load double, ptr %r1421, align 8
  br label %pic.merge.395

pic.desc.classify.387:                            ; preds = %pic.recv_hdr.396
  %r1378 = and i1 %r1368, %r1375
  br i1 %r1378, label %pic.desc.prefix.guard.388, label %pic.miss.cold.393

pic.desc.prefix.guard.388:                        ; preds = %pic.desc.classify.387
  %r1423 = getelementptr i64, ptr %r1374, i64 2
  %r1424 = load i64, ptr %r1423, align 8
  %r1425 = icmp ne i64 %r1424, 0
  br i1 %r1425, label %pic.desc.prefix.meta.389, label %pic.miss.cold.393

pic.desc.prefix.meta.389:                         ; preds = %pic.desc.prefix.guard.388
  %r1426 = add nuw nsw i64 %r1353, 8
  %r1427 = inttoptr i64 %r1426 to ptr
  %r1428 = load i64, ptr %r1427, align 8
  %r1429 = icmp ne i64 %r1428, 0
  br i1 %r1429, label %pic.desc.prefix.token.390, label %pic.miss.cold.393

pic.desc.prefix.token.390:                        ; preds = %pic.desc.prefix.meta.389
  %r1430 = inttoptr i64 %r1428 to ptr
  %r1431 = getelementptr i64, ptr %r1430, i64 6
  %r1432 = load i64, ptr %r1431, align 8
  %r1433 = icmp eq i64 %r1432, %r1424
  br i1 %r1433, label %pic.desc.prefix.hit.391, label %pic.miss.cold.393

pic.desc.prefix.hit.391:                          ; preds = %pic.desc.prefix.token.390
  %r1434 = getelementptr i64, ptr %r1374, i64 1
  %r1435 = load i64, ptr %r1434, align 8
  %r1436 = shl i64 %r1435, 3
  %r1437 = add nuw nsw i64 %r1353, 16
  %r1438 = add i64 %r1437, %r1436
  %r1439 = inttoptr i64 %r1438 to ptr
  %r1440 = load double, ptr %r1439, align 8
  br label %pic.merge.395

pic.miss.392:                                     ; preds = %pic.hit.inline.399, %pic.prefix.token.385, %pic.prefix.meta.384, %pic.prefix.guard.383
  %r1441 = getelementptr i64, ptr %r1374, i64 3
  %r1442 = load i64, ptr %r1441, align 8
  %r1443 = icmp sgt i64 %r1442, 0
  br i1 %r1443, label %pic.ways.400, label %pic.miss.call.394

pic.miss.cold.393:                                ; preds = %pic.desc.prefix.token.390, %pic.desc.prefix.meta.389, %pic.desc.prefix.guard.388, %pic.desc.classify.387, %pget.recv_obj.380
  br label %pic.miss.call.394

pic.miss.call.394:                                ; preds = %pic.way.load.401, %pic.ways.400, %pic.miss.cold.393, %pic.miss.392
  %r1482 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1483 = bitcast double %r1482 to i64
  %r1484 = and i64 %r1483, 281474976710655
  %statepoint_token185 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1353, i64 %r1484, ptr @perry_ic_options_worker_ts__11, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated179, ptr addrspace(1) %rs4gc.s18, ptr addrspace(1) %rs4gc.s19) ]
  %r1485186 = call double @llvm.experimental.gc.result.f64(token %statepoint_token185)
  %rs4gc.s7.relocated187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token185, i32 0, i32 0) ; (%rs4gc.s7.relocated179, %rs4gc.s7.relocated179)
  %rs4gc.s18.relocated188 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token185, i32 1, i32 1) ; (%rs4gc.s18, %rs4gc.s18)
  %rs4gc.s19.relocated189 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token185, i32 2, i32 2) ; (%rs4gc.s19, %rs4gc.s19)
  br label %pic.merge.395

pic.merge.395:                                    ; preds = %pic.way.live.402, %pic.hit.overflow.398, %pic.miss.call.394, %pic.desc.prefix.hit.391, %pic.prefix.hit.386, %pic.hit.live.382
  %.1236 = phi ptr addrspace(1) [ %rs4gc.s19.relocated194, %pic.hit.overflow.398 ], [ %rs4gc.s19.relocated189, %pic.miss.call.394 ], [ %rs4gc.s19, %pic.way.live.402 ], [ %rs4gc.s19, %pic.hit.live.382 ], [ %rs4gc.s19, %pic.prefix.hit.386 ], [ %rs4gc.s19, %pic.desc.prefix.hit.391 ]
  %.1233 = phi ptr addrspace(1) [ %rs4gc.s18.relocated193, %pic.hit.overflow.398 ], [ %rs4gc.s18.relocated188, %pic.miss.call.394 ], [ %rs4gc.s18, %pic.way.live.402 ], [ %rs4gc.s18, %pic.hit.live.382 ], [ %rs4gc.s18, %pic.prefix.hit.386 ], [ %rs4gc.s18, %pic.desc.prefix.hit.391 ]
  %.45 = phi ptr addrspace(1) [ %rs4gc.s7.relocated192, %pic.hit.overflow.398 ], [ %rs4gc.s7.relocated187, %pic.miss.call.394 ], [ %rs4gc.s7.relocated179, %pic.way.live.402 ], [ %rs4gc.s7.relocated179, %pic.hit.live.382 ], [ %rs4gc.s7.relocated179, %pic.prefix.hit.386 ], [ %rs4gc.s7.relocated179, %pic.desc.prefix.hit.391 ]
  %r1486 = phi double [ %r1402, %pic.hit.live.382 ], [ %r1397191, %pic.hit.overflow.398 ], [ %r1422, %pic.prefix.hit.386 ], [ %r1440, %pic.desc.prefix.hit.391 ], [ %r1479, %pic.way.live.402 ], [ %r1485186, %pic.miss.call.394 ]
  br label %pget.recv_merge.376

pic.recv_hdr.396:                                 ; preds = %pget.recv_obj.380
  %r1365 = sub nuw nsw i64 %r1353, 8
  %r1366 = inttoptr i64 %r1365 to ptr
  %r1367 = load i8, ptr %r1366, align 1
  %r1368 = icmp eq i8 %r1367, 2
  %r1369 = sub nuw nsw i64 %r1353, 6
  %r1370 = inttoptr i64 %r1369 to ptr
  %r1371 = load i16, ptr %r1370, align 2
  %r1372 = and i16 %r1371, 2048
  %r1373 = icmp eq i16 %r1372, 0
  %r1374 = load ptr, ptr @perry_ic_options_worker_ts__11, align 8
  %r1375 = icmp ne ptr %r1374, null
  %r1376 = and i1 %r1368, %r1373
  %r1377 = and i1 %r1376, %r1375
  br i1 %r1377, label %pic.token.397, label %pic.desc.classify.387

pic.token.397:                                    ; preds = %pic.recv_hdr.396
  %r1379 = add nuw nsw i64 %r1353, 4
  %r1380 = inttoptr i64 %r1379 to ptr
  %r1381 = load i32, ptr %r1380, align 4
  %r1382 = zext i32 %r1381 to i64
  %r1383 = or i64 %r1382, 4611686018427387904
  %r1384 = icmp ne i32 %r1381, 0
  %r1385 = getelementptr i64, ptr %r1374, i64 0
  %r1386 = load i64, ptr %r1385, align 8
  %r1387 = icmp eq i64 %r1383, %r1386
  %r1388 = and i1 %r1387, %r1384
  br i1 %r1388, label %pic.hit.381, label %pic.prefix.guard.383

pic.hit.overflow.398:                             ; preds = %pic.hit.381
  %r1393 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1394 = bitcast double %r1393 to i64
  %r1395 = and i64 %r1394, 281474976710655
  %r1396 = trunc i64 %r1390 to i32
  %statepoint_token190 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1353, i64 %r1395, i32 %r1396, ptr @perry_ic_options_worker_ts__11, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated179, ptr addrspace(1) %rs4gc.s18, ptr addrspace(1) %rs4gc.s19) ]
  %r1397191 = call double @llvm.experimental.gc.result.f64(token %statepoint_token190)
  %rs4gc.s7.relocated192 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token190, i32 0, i32 0) ; (%rs4gc.s7.relocated179, %rs4gc.s7.relocated179)
  %rs4gc.s18.relocated193 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token190, i32 1, i32 1) ; (%rs4gc.s18, %rs4gc.s18)
  %rs4gc.s19.relocated194 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token190, i32 2, i32 2) ; (%rs4gc.s19, %rs4gc.s19)
  br label %pic.merge.395

pic.hit.inline.399:                               ; preds = %pic.hit.381
  %r1398 = shl i64 %r1390, 3
  %r1399 = add nuw nsw i64 %r1353, 16
  %r1400 = add i64 %r1399, %r1398
  %r1401 = inttoptr i64 %r1400 to ptr
  %r1402 = load double, ptr %r1401, align 8
  %r1403 = bitcast double %r1402 to i64
  %r1404 = icmp eq i64 %r1403, 9222246136947933200
  br i1 %r1404, label %pic.miss.392, label %pic.hit.live.382

pic.ways.400:                                     ; preds = %pic.miss.392
  %r1444 = getelementptr i64, ptr %r1374, i64 4
  %r1445 = load i64, ptr %r1444, align 8
  %r1446 = icmp eq i64 %r1445, %r1383
  %r1447 = getelementptr i64, ptr %r1374, i64 5
  %r1448 = load i64, ptr %r1447, align 8
  %r1449 = select i1 %r1446, i64 %r1448, i64 0
  %r1450 = getelementptr i64, ptr %r1374, i64 6
  %r1451 = load i64, ptr %r1450, align 8
  %r1452 = icmp eq i64 %r1451, %r1383
  %r1453 = getelementptr i64, ptr %r1374, i64 7
  %r1454 = load i64, ptr %r1453, align 8
  %r1455 = select i1 %r1452, i64 %r1454, i64 0
  %r1456 = getelementptr i64, ptr %r1374, i64 8
  %r1457 = load i64, ptr %r1456, align 8
  %r1458 = icmp eq i64 %r1457, %r1383
  %r1459 = getelementptr i64, ptr %r1374, i64 9
  %r1460 = load i64, ptr %r1459, align 8
  %r1461 = select i1 %r1458, i64 %r1460, i64 0
  %r1462 = getelementptr i64, ptr %r1374, i64 10
  %r1463 = load i64, ptr %r1462, align 8
  %r1464 = icmp eq i64 %r1463, %r1383
  %r1465 = getelementptr i64, ptr %r1374, i64 11
  %r1466 = load i64, ptr %r1465, align 8
  %r1467 = select i1 %r1464, i64 %r1466, i64 0
  %r1468 = or i1 %r1446, %r1452
  %r1469 = select i1 %r1446, i64 %r1449, i64 %r1455
  %r1470 = or i1 %r1458, %r1464
  %r1471 = select i1 %r1458, i64 %r1461, i64 %r1467
  %r1472 = or i1 %r1468, %r1470
  %r1473 = select i1 %r1468, i64 %r1469, i64 %r1471
  %r1474 = and i1 %r1384, %r1472
  br i1 %r1474, label %pic.way.load.401, label %pic.miss.call.394

pic.way.load.401:                                 ; preds = %pic.ways.400
  %r1475 = shl i64 %r1473, 3
  %r1476 = add nuw nsw i64 %r1353, 16
  %r1477 = add i64 %r1476, %r1475
  %r1478 = inttoptr i64 %r1477 to ptr
  %r1479 = load double, ptr %r1478, align 8
  %r1480 = bitcast double %r1479 to i64
  %r1481 = icmp eq i64 %r1480, 9222246136947933200
  br i1 %r1481, label %pic.miss.call.394, label %pic.way.live.402

pic.way.live.402:                                 ; preds = %pic.way.load.401
  br label %pic.merge.395

pget.throw_nullish.403:                           ; preds = %pget.recv_bad.374
  %r1490 = zext i1 %r1488 to i32
  %statepoint_token195 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1490, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.404:                       ; preds = %pget.recv_bad.374
  %r1491 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1492 = bitcast double %r1491 to i64
  %r1493 = and i64 %r1492, 281474976710655
  %statepoint_token196 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1352, i64 %r1493, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated179, ptr addrspace(1) %rs4gc.s18, ptr addrspace(1) %rs4gc.s19) ]
  %r1494197 = call double @llvm.experimental.gc.result.f64(token %statepoint_token196)
  %rs4gc.s7.relocated198 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token196, i32 0, i32 0) ; (%rs4gc.s7.relocated179, %rs4gc.s7.relocated179)
  %rs4gc.s18.relocated199 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token196, i32 1, i32 1) ; (%rs4gc.s18, %rs4gc.s18)
  %rs4gc.s19.relocated200 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token196, i32 2, i32 2) ; (%rs4gc.s19, %rs4gc.s19)
  br label %pget.recv_merge.376

guarded_add.numeric.405:                          ; preds = %pget.recv_merge.376
  %r1516 = fadd double %r1505, %r1503
  br label %guarded_add.merge.407

guarded_add.dynamic.406:                          ; preds = %pget.recv_merge.376
  %statepoint_token201 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r1505, double %r1503, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.44, ptr addrspace(1) %.0232) ]
  %r1517202 = call double @llvm.experimental.gc.result.f64(token %statepoint_token201)
  %rs4gc.s7.relocated203 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token201, i32 0, i32 0) ; (%.44, %.44)
  %rs4gc.s18.relocated204 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token201, i32 1, i32 1) ; (%.0232, %.0232)
  br label %guarded_add.merge.407

guarded_add.merge.407:                            ; preds = %guarded_add.dynamic.406, %guarded_add.numeric.405
  %.2234 = phi ptr addrspace(1) [ %.0232, %guarded_add.numeric.405 ], [ %rs4gc.s18.relocated204, %guarded_add.dynamic.406 ]
  %.46 = phi ptr addrspace(1) [ %.44, %guarded_add.numeric.405 ], [ %rs4gc.s7.relocated203, %guarded_add.dynamic.406 ]
  %r1518 = phi double [ %r1516, %guarded_add.numeric.405 ], [ %r1517202, %guarded_add.dynamic.406 ]
  %r1519.rs4i = ptrtoint ptr addrspace(1) %.2234 to i64
  %r1519.rs4o = call i64 asm "", "=r,0"(i64 %r1519.rs4i) #9
  %r1519 = bitcast i64 %r1519.rs4o to double
  %r1520 = bitcast double %r1519 to i64
  %r1521 = and i64 %r1520, -281474976710656
  %r1522 = icmp ne i64 %r1521, 9223090561878065152
  br i1 %r1522, label %str_addref.done.409, label %str_addref.call.408

str_addref.call.408:                              ; preds = %guarded_add.merge.407
  call void @js_string_addref_if_heap_string(double %r1519) #9
  br label %str_addref.done.409

str_addref.done.409:                              ; preds = %str_addref.call.408, %guarded_add.merge.407
  %r1534.rs4i = ptrtoint ptr addrspace(1) %.2234 to i64
  %r1534.rs4o = call i64 asm "", "=r,0"(i64 %r1534.rs4i) #9
  %r1534 = bitcast i64 %r1534.rs4o to double
  store double %r1534, ptr @perry_global_options_worker_ts__7, align 8
  %r1533.rs4i = ptrtoint ptr addrspace(1) %.2234 to i64
  %r1533.rs4o = call i64 asm "", "=r,0"(i64 %r1533.rs4i) #9
  %r1533 = bitcast i64 %r1533.rs4o to double
  %r1523 = bitcast double %r1533 to i64
  %r1531.rs4i = ptrtoint ptr addrspace(1) %.2234 to i64
  %r1531.rs4o = call i64 asm "", "=r,0"(i64 %r1531.rs4i) #9
  %r1531 = bitcast i64 %r1531.rs4o to double
  %r1532 = bitcast double %r1531 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1532) #9
  %r1524 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1525 = icmp ne i32 %r1524, 0
  br i1 %r1525, label %gcpoll.410, label %gcpoll.done.411

gcpoll.410:                                       ; preds = %str_addref.done.409
  %statepoint_token205 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.46) ]
  %rs4gc.s7.relocated206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token205, i32 0, i32 0) ; (%.46, %.46)
  br label %gcpoll.done.411

gcpoll.done.411:                                  ; preds = %gcpoll.410, %str_addref.done.409
  %.47 = phi ptr addrspace(1) [ %rs4gc.s7.relocated206, %gcpoll.410 ], [ %.46, %str_addref.done.409 ]
  br label %for.update.362
}

; Function Attrs: inlinehint optsize
define internal double @"perry_fn_options_worker_ts__identity$generic"(double %arg14, double %arg15) #7 gc "statepoint-example" {
entry.0:
  %rs4gc.b1 = bitcast double %arg14 to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg15 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r3.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r3.rs4o = call i64 asm "", "=r,0"(i64 %r3.rs4i) #9
  %r3 = bitcast i64 %r3.rs4o to double
  ret double %r3
}

; Function Attrs: noinline optsize
define double @perry_fn_options_worker_ts__identity(double %arg14, double %arg15) #8 {
entry.0:
  %r1 = call i32 @js_typed_string_arg_guard(double %arg14)
  %r2 = icmp ne i32 %r1, 0
  br i1 %r2, label %spec_public.fast.1, label %spec_public.fallback.2

spec_public.fast.1:                               ; preds = %entry.0
  %r3 = call double @"perry_fn_options_worker_ts__identity$spec_b_b"(double %arg14, double %arg15)
  ret double %r3

spec_public.fallback.2:                           ; preds = %entry.0
  %r4 = call double @"perry_fn_options_worker_ts__identity$generic"(double %arg14, double %arg15)
  ret double %r4
}

; Function Attrs: optsize
define internal double @"perry_fn_options_worker_ts__run$generic"(double %arg16) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b7 = bitcast double %arg16 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r3 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r4 = load double, ptr @options_worker_ts_.str.0.handle, align 8
  %r5 = bitcast double %r3 to i64
  %r6 = bitcast double %r4 to i64
  %r7 = icmp eq i64 %r5, %r6
  br i1 %r7, label %streqlit.true.7, label %streqlit.sso.1

streqlit.sso.1:                                   ; preds = %entry.0
  %r8 = icmp eq i64 %r5, 9221407683790335088
  br i1 %r8, label %streqlit.true.7, label %streqlit.tag.2

streqlit.tag.2:                                   ; preds = %streqlit.sso.1
  %r9 = lshr i64 %r5, 48
  %r10 = icmp eq i64 %r9, 32767
  %r11 = and i64 %r5, 281474976710655
  %r12 = icmp ugt i64 %r11, 4095
  %r13 = and i1 %r10, %r12
  br i1 %r13, label %streqlit.len.3, label %streqlit.false.8

streqlit.len.3:                                   ; preds = %streqlit.tag.2
  %r14 = inttoptr i64 %r11 to ptr
  %r15 = getelementptr inbounds nuw i8, ptr %r14, i64 4
  %r16 = load i32, ptr %r15, align 4
  %r17 = icmp eq i32 %r16, 5
  br i1 %r17, label %streqlit.b0.4, label %streqlit.false.8

streqlit.b0.4:                                    ; preds = %streqlit.len.3
  %r18 = getelementptr inbounds nuw i8, ptr %r14, i64 20
  %r19 = load i8, ptr %r18, align 1
  %r20 = icmp eq i8 %r19, 112
  br i1 %r20, label %streqlit.bl.5, label %streqlit.false.8

streqlit.bl.5:                                    ; preds = %streqlit.b0.4
  %r21 = getelementptr inbounds nuw i8, ptr %r14, i64 24
  %r22 = load i8, ptr %r21, align 1
  %r23 = icmp eq i8 %r22, 110
  br i1 %r23, label %streqlit.slow.6, label %streqlit.false.8

streqlit.slow.6:                                  ; preds = %streqlit.bl.5
  %r24 = and i64 %r6, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r11, i64 %r24, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7) ]
  %r2510 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s7, %rs4gc.s7)
  %r26 = icmp ne i32 %r2510, 0
  br label %streqlit.merge.9

streqlit.true.7:                                  ; preds = %streqlit.sso.1, %entry.0
  br label %streqlit.merge.9

streqlit.false.8:                                 ; preds = %streqlit.bl.5, %streqlit.b0.4, %streqlit.len.3, %streqlit.tag.2
  br label %streqlit.merge.9

streqlit.merge.9:                                 ; preds = %streqlit.false.8, %streqlit.true.7, %streqlit.slow.6
  %.0 = phi ptr addrspace(1) [ %rs4gc.s7, %streqlit.true.7 ], [ %rs4gc.s7.relocated, %streqlit.slow.6 ], [ %rs4gc.s7, %streqlit.false.8 ]
  %r27 = phi i1 [ true, %streqlit.true.7 ], [ false, %streqlit.false.8 ], [ %r26, %streqlit.slow.6 ]
  %r28 = select i1 %r27, i64 9222246136947933188, i64 9222246136947933187
  %r29 = bitcast i64 %r28 to double
  %r30 = icmp eq i64 %r28, 9222246136947933188
  br i1 %r30, label %if.then.10, label %if.else.11

if.then.10:                                       ; preds = %streqlit.merge.9
  %r35.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r35.rs4o = call i64 asm "", "=r,0"(i64 %r35.rs4i) #9
  %r35 = bitcast i64 %r35.rs4o to double
  %r36 = bitcast double %r35 to i64
  %r37 = and i64 %r36, -281474976710656
  %r38 = icmp ult i64 %r37, 9221401712017801216
  %r39 = icmp ugt i64 %r37, 9223090561878065152
  %r40 = or i1 %r38, %r39
  br i1 %r40, label %for.bound_i32.number.13, label %for.bound_i32.merge.15

if.else.11:                                       ; preds = %streqlit.merge.9
  %r287 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r288 = load double, ptr @options_worker_ts_.str.2.handle, align 8
  %r289 = bitcast double %r287 to i64
  %r290 = bitcast double %r288 to i64
  %r291 = icmp eq i64 %r289, %r290
  br i1 %r291, label %streqlit.true.78, label %streqlit.tag.73

if.merge.12:                                      ; preds = %if.merge.83, %for.exit.21
  %r2.0 = phi double [ %r2.1, %for.exit.21 ], [ %r2.2, %if.merge.83 ]
  ret double %r2.0

for.bound_i32.number.13:                          ; preds = %if.then.10
  %r41 = fcmp oge double %r35, 0xC1E0000000000000
  %r42 = fcmp ole double %r35, 0x41DFFFFFFFC00000
  %r43 = and i1 %r41, %r42
  br i1 %r43, label %for.bound_i32.convert.14, label %for.bound_i32.merge.15

for.bound_i32.convert.14:                         ; preds = %for.bound_i32.number.13
  %r44 = fptosi double %r35 to i32
  %r45 = sitofp i32 %r44 to double
  %r46 = fcmp oeq double %r45, %r35
  br i1 %r46, label %for.counter_i32.range.16, label %for.bound_i32.merge.15

for.bound_i32.merge.15:                           ; preds = %for.counter_i32.convert.17, %for.bound_i32.convert.14, %for.bound_i32.number.13, %if.then.10
  %r34.0 = phi i32 [ %r44, %for.counter_i32.convert.17 ], [ 0, %if.then.10 ], [ %r44, %for.bound_i32.convert.14 ], [ 0, %for.bound_i32.number.13 ]
  %r33.0 = phi i1 [ true, %for.counter_i32.convert.17 ], [ false, %if.then.10 ], [ false, %for.bound_i32.convert.14 ], [ false, %for.bound_i32.number.13 ]
  br label %for.cond.18

for.counter_i32.range.16:                         ; preds = %for.bound_i32.convert.14
  br label %for.counter_i32.convert.17

for.counter_i32.convert.17:                       ; preds = %for.counter_i32.range.16
  br label %for.bound_i32.merge.15

for.cond.18:                                      ; preds = %for.update.20, %for.bound_i32.merge.15
  %.1 = phi ptr addrspace(1) [ %.0, %for.bound_i32.merge.15 ], [ %.8, %for.update.20 ]
  %r32.1 = phi i32 [ 0, %for.bound_i32.merge.15 ], [ %r286, %for.update.20 ]
  %r31.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.15 ], [ %r284, %for.update.20 ]
  %r2.1 = phi double [ 0.000000e+00, %for.bound_i32.merge.15 ], [ %r275, %for.update.20 ]
  br i1 %r33.0, label %for.cond.fast.22, label %for.cond.slow.23

for.body.19:                                      ; preds = %gcpoll.done.28, %for.cond.fast.22
  %.2 = phi ptr addrspace(1) [ %.1, %for.cond.fast.22 ], [ %.4, %gcpoll.done.28 ]
  %r96 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r96, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r9712 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token11)
  %rs4gc.s7.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 0, i32 0) ; (%.2, %.2)
  %r98 = bitcast i64 %r9712 to double
  %rs4gc.b8 = bitcast double %r98 to i64
  %rs4gc.s8 = inttoptr i64 %rs4gc.b8 to ptr addrspace(1)
  %r99.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r99 = call i64 asm "", "=r,0"(i64 %r99.rs4i) #9
  %r100 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r101 = icmp ne i32 %r100, 0
  br i1 %r101, label %shadow.root.barrier.29, label %shadow.root.barrier.done.30

for.update.20:                                    ; preds = %gcpoll.done.72
  %r284 = fadd double %r31.0, 1.000000e+00
  %r286 = add i32 %r32.1, 1
  br label %for.cond.18

for.exit.21:                                      ; preds = %gcpoll.done.28, %for.cond.fast.22
  br label %if.merge.12

for.cond.fast.22:                                 ; preds = %for.cond.18
  %r57 = icmp slt i32 %r32.1, %r34.0
  br i1 %r57, label %for.body.19, label %for.exit.21

for.cond.slow.23:                                 ; preds = %for.cond.18
  %r59.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r59.rs4o = call i64 asm "", "=r,0"(i64 %r59.rs4i) #9
  %r59 = bitcast i64 %r59.rs4o to double
  %r60 = bitcast double %r59 to i64
  %r61 = lshr i64 %r60, 48
  %r62 = icmp ult i64 %r61, 32761
  %r63 = icmp ugt i64 %r61, 32767
  %r64 = or i1 %r62, %r63
  %r65 = icmp eq i64 %r61, 32766
  %r66 = icmp eq i64 %r60, 9222246136947933185
  %r67 = icmp eq i64 %r60, 9222246136947933186
  %r68 = icmp eq i64 %r60, 9222246136947933187
  %r69 = icmp eq i64 %r60, 9222246136947933188
  %r70 = or i1 %r67, %r68
  %r71 = or i1 %r64, %r65
  %r72 = or i1 %r71, %r66
  %r73 = or i1 %r72, %r70
  %r74 = or i1 %r73, %r69
  br i1 %r74, label %relnum.fast.24, label %relnum.slow.25

relnum.fast.24:                                   ; preds = %for.cond.slow.23
  %r75 = trunc i64 %r60 to i32
  %r76 = sitofp i32 %r75 to double
  %r77 = select i1 %r65, double %r76, double %r59
  %r78 = select i1 %r70, double 0.000000e+00, double %r77
  %r79 = select i1 %r69, double 1.000000e+00, double %r78
  %r80 = bitcast double %r31.0 to i64
  %r81 = lshr i64 %r80, 48
  %r82 = icmp eq i64 %r81, 32766
  %r83 = trunc i64 %r80 to i32
  %r84 = sitofp i32 %r83 to double
  %r85 = select i1 %r82, double %r84, double %r31.0
  %r86 = fcmp olt double %r85, %r79
  %r87 = select i1 %r86, i64 9222246136947933188, i64 9222246136947933187
  %r88 = bitcast i64 %r87 to double
  br label %relnum.merge.26

relnum.slow.25:                                   ; preds = %for.cond.slow.23
  %statepoint_token14 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r31.0, double %r59, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1) ]
  %r8915 = call double @llvm.experimental.gc.result.f64(token %statepoint_token14)
  %rs4gc.s7.relocated16 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token14, i32 0, i32 0) ; (%.1, %.1)
  br label %relnum.merge.26

relnum.merge.26:                                  ; preds = %relnum.slow.25, %relnum.fast.24
  %.3 = phi ptr addrspace(1) [ %.1, %relnum.fast.24 ], [ %rs4gc.s7.relocated16, %relnum.slow.25 ]
  %r90 = phi double [ %r88, %relnum.fast.24 ], [ %r8915, %relnum.slow.25 ]
  %r91 = bitcast double %r90 to i64
  %r93 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r94 = icmp ne i32 %r93, 0
  br i1 %r94, label %gcpoll.27, label %gcpoll.done.28

gcpoll.27:                                        ; preds = %relnum.merge.26
  %statepoint_token17 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3) ]
  %rs4gc.s7.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token17, i32 0, i32 0) ; (%.3, %.3)
  br label %gcpoll.done.28

gcpoll.done.28:                                   ; preds = %gcpoll.27, %relnum.merge.26
  %.4 = phi ptr addrspace(1) [ %rs4gc.s7.relocated18, %gcpoll.27 ], [ %.3, %relnum.merge.26 ]
  %r92 = icmp eq i64 %r91, 9222246136947933188
  br i1 %r92, label %for.body.19, label %for.exit.21

shadow.root.barrier.29:                           ; preds = %for.body.19
  call void @js_write_barrier_root_nanbox(i64 %r99) #9
  br label %shadow.root.barrier.done.30

shadow.root.barrier.done.30:                      ; preds = %shadow.root.barrier.29, %for.body.19
  %r103 = bitcast double %r2.1 to i64
  %rs4gc.s9 = inttoptr i64 %r103 to ptr addrspace(1)
  %r105.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r105 = call i64 asm "", "=r,0"(i64 %r105.rs4i) #9
  %r106 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r107 = icmp ne i32 %r106, 0
  br i1 %r107, label %shadow.root.barrier.31, label %shadow.root.barrier.done.32

shadow.root.barrier.31:                           ; preds = %shadow.root.barrier.done.30
  call void @js_write_barrier_root_nanbox(i64 %r105) #9
  br label %shadow.root.barrier.done.32

shadow.root.barrier.done.32:                      ; preds = %shadow.root.barrier.31, %shadow.root.barrier.done.30
  %r108.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r108.rs4o = call i64 asm "", "=r,0"(i64 %r108.rs4i) #9
  %r108 = bitcast i64 %r108.rs4o to double
  %r109 = bitcast double %r108 to i64
  %r110 = and i64 %r109, 281474976710655
  %r111 = lshr i64 %r109, 48
  %r112 = and i64 %r111, 65533
  %r113 = icmp eq i64 %r112, 32765
  br i1 %r113, label %pget.recv_ok.34, label %pget.recv_other.39

pget.recv_sso.33:                                 ; preds = %pget.recv_other.39
  %r252 = lshr i64 %r109, 40
  %r253 = and i64 %r252, 255
  %r254 = uitofp nneg i64 %r253 to double
  br label %pget.recv_merge.37

pget.recv_ok.34:                                  ; preds = %shadow.root.barrier.done.32
  %r120 = icmp eq i64 %r111, 32767
  br i1 %r120, label %pget.strlen_heap.38, label %pget.recv_obj.41

pget.recv_bad.35:                                 ; preds = %pget.check_class_ref.40
  %r244 = icmp eq i64 %r109, 9222246136947933185
  %r245 = icmp eq i64 %r109, 9222246136947933186
  %r246 = or i1 %r244, %r245
  br i1 %r246, label %pget.throw_nullish.64, label %pget.recv_undef_return.65

pget.recv_class_ref.36:                           ; preds = %pget.check_class_ref.40
  %r116 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r117 = bitcast double %r116 to i64
  %r118 = and i64 %r117, 281474976710655
  %statepoint_token19 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532876, i64 %r109, i64 %r118, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated13, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r11920 = call double @llvm.experimental.gc.result.f64(token %statepoint_token19)
  %rs4gc.s7.relocated21 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 0, i32 0) ; (%rs4gc.s7.relocated13, %rs4gc.s7.relocated13)
  %rs4gc.s8.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pget.recv_merge.37

pget.recv_merge.37:                               ; preds = %pget.recv_undef_return.65, %pic.merge.56, %pget.strlen_heap.38, %pget.recv_class_ref.36, %pget.recv_sso.33
  %.0230 = phi ptr addrspace(1) [ %rs4gc.s9, %pget.strlen_heap.38 ], [ %.1231, %pic.merge.56 ], [ %rs4gc.s9, %pget.recv_sso.33 ], [ %rs4gc.s9.relocated, %pget.recv_class_ref.36 ], [ %rs4gc.s9.relocated37, %pget.recv_undef_return.65 ]
  %.0227 = phi ptr addrspace(1) [ %rs4gc.s8, %pget.strlen_heap.38 ], [ %.1228, %pic.merge.56 ], [ %rs4gc.s8, %pget.recv_sso.33 ], [ %rs4gc.s8.relocated, %pget.recv_class_ref.36 ], [ %rs4gc.s8.relocated36, %pget.recv_undef_return.65 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s7.relocated13, %pget.strlen_heap.38 ], [ %.6, %pic.merge.56 ], [ %rs4gc.s7.relocated13, %pget.recv_sso.33 ], [ %rs4gc.s7.relocated21, %pget.recv_class_ref.36 ], [ %rs4gc.s7.relocated35, %pget.recv_undef_return.65 ]
  %r260 = phi double [ %r243, %pic.merge.56 ], [ %r25134, %pget.recv_undef_return.65 ], [ %r254, %pget.recv_sso.33 ], [ %r11920, %pget.recv_class_ref.36 ], [ %r259, %pget.strlen_heap.38 ]
  %r261.rs4i = ptrtoint ptr addrspace(1) %.0230 to i64
  %r261 = call i64 asm "", "=r,0"(i64 %r261.rs4i) #9
  %r262 = bitcast i64 %r261 to double
  %r263 = and i64 %r261, -281474976710656
  %r264 = icmp ult i64 %r263, 9221401712017801216
  %r265 = icmp ugt i64 %r263, 9223090561878065152
  %r266 = or i1 %r264, %r265
  %r267 = bitcast double %r260 to i64
  %r268 = and i64 %r267, -281474976710656
  %r269 = icmp ult i64 %r268, 9221401712017801216
  %r270 = icmp ugt i64 %r268, 9223090561878065152
  %r271 = or i1 %r269, %r270
  %r272 = and i1 %r266, %r271
  br i1 %r272, label %guarded_add.numeric.66, label %guarded_add.dynamic.67

pget.strlen_heap.38:                              ; preds = %pget.recv_ok.34
  %r255 = icmp ult i64 %r110, 4096
  %r256 = inttoptr i64 %r110 to ptr
  %r257 = select i1 %r255, ptr @perry_null_guard_zero_options_worker_ts, ptr %r256
  %r258 = load i32, ptr %r257, align 4
  %r259 = uitofp i32 %r258 to double
  br label %pget.recv_merge.37

pget.recv_other.39:                               ; preds = %shadow.root.barrier.done.32
  %r114 = icmp eq i64 %r111, 32761
  br i1 %r114, label %pget.recv_sso.33, label %pget.check_class_ref.40

pget.check_class_ref.40:                          ; preds = %pget.recv_other.39
  %r115 = icmp eq i64 %r111, 32766
  br i1 %r115, label %pget.recv_class_ref.36, label %pget.recv_bad.35

pget.recv_obj.41:                                 ; preds = %pget.recv_ok.34
  %r121 = icmp ugt i64 %r110, 1048575
  br i1 %r121, label %pic.recv_hdr.57, label %pic.miss.cold.54

pic.hit.42:                                       ; preds = %pic.token.58
  %r146 = getelementptr i64, ptr %r131, i64 1
  %r147 = load i64, ptr %r146, align 8
  %r148 = and i64 %r147, 1073741824
  %r149 = icmp ne i64 %r148, 0
  br i1 %r149, label %pic.hit.overflow.59, label %pic.hit.inline.60

pic.hit.live.43:                                  ; preds = %pic.hit.inline.60
  br label %pic.merge.56

pic.prefix.guard.44:                              ; preds = %pic.token.58
  %r162 = getelementptr i64, ptr %r131, i64 2
  %r163 = load i64, ptr %r162, align 8
  %r164 = icmp ne i64 %r163, 0
  br i1 %r164, label %pic.prefix.meta.45, label %pic.miss.53

pic.prefix.meta.45:                               ; preds = %pic.prefix.guard.44
  %r165 = add nuw nsw i64 %r110, 8
  %r166 = inttoptr i64 %r165 to ptr
  %r167 = load i64, ptr %r166, align 8
  %r168 = icmp ne i64 %r167, 0
  br i1 %r168, label %pic.prefix.token.46, label %pic.miss.53

pic.prefix.token.46:                              ; preds = %pic.prefix.meta.45
  %r169 = inttoptr i64 %r167 to ptr
  %r170 = getelementptr i64, ptr %r169, i64 6
  %r171 = load i64, ptr %r170, align 8
  %r172 = icmp eq i64 %r171, %r163
  br i1 %r172, label %pic.prefix.hit.47, label %pic.miss.53

pic.prefix.hit.47:                                ; preds = %pic.prefix.token.46
  %r173 = getelementptr i64, ptr %r131, i64 1
  %r174 = load i64, ptr %r173, align 8
  %r175 = shl i64 %r174, 3
  %r176 = add nuw nsw i64 %r110, 16
  %r177 = add i64 %r176, %r175
  %r178 = inttoptr i64 %r177 to ptr
  %r179 = load double, ptr %r178, align 8
  br label %pic.merge.56

pic.desc.classify.48:                             ; preds = %pic.recv_hdr.57
  %r135 = and i1 %r125, %r132
  br i1 %r135, label %pic.desc.prefix.guard.49, label %pic.miss.cold.54

pic.desc.prefix.guard.49:                         ; preds = %pic.desc.classify.48
  %r180 = getelementptr i64, ptr %r131, i64 2
  %r181 = load i64, ptr %r180, align 8
  %r182 = icmp ne i64 %r181, 0
  br i1 %r182, label %pic.desc.prefix.meta.50, label %pic.miss.cold.54

pic.desc.prefix.meta.50:                          ; preds = %pic.desc.prefix.guard.49
  %r183 = add nuw nsw i64 %r110, 8
  %r184 = inttoptr i64 %r183 to ptr
  %r185 = load i64, ptr %r184, align 8
  %r186 = icmp ne i64 %r185, 0
  br i1 %r186, label %pic.desc.prefix.token.51, label %pic.miss.cold.54

pic.desc.prefix.token.51:                         ; preds = %pic.desc.prefix.meta.50
  %r187 = inttoptr i64 %r185 to ptr
  %r188 = getelementptr i64, ptr %r187, i64 6
  %r189 = load i64, ptr %r188, align 8
  %r190 = icmp eq i64 %r189, %r181
  br i1 %r190, label %pic.desc.prefix.hit.52, label %pic.miss.cold.54

pic.desc.prefix.hit.52:                           ; preds = %pic.desc.prefix.token.51
  %r191 = getelementptr i64, ptr %r131, i64 1
  %r192 = load i64, ptr %r191, align 8
  %r193 = shl i64 %r192, 3
  %r194 = add nuw nsw i64 %r110, 16
  %r195 = add i64 %r194, %r193
  %r196 = inttoptr i64 %r195 to ptr
  %r197 = load double, ptr %r196, align 8
  br label %pic.merge.56

pic.miss.53:                                      ; preds = %pic.hit.inline.60, %pic.prefix.token.46, %pic.prefix.meta.45, %pic.prefix.guard.44
  %r198 = getelementptr i64, ptr %r131, i64 3
  %r199 = load i64, ptr %r198, align 8
  %r200 = icmp sgt i64 %r199, 0
  br i1 %r200, label %pic.ways.61, label %pic.miss.call.55

pic.miss.cold.54:                                 ; preds = %pic.desc.prefix.token.51, %pic.desc.prefix.meta.50, %pic.desc.prefix.guard.49, %pic.desc.classify.48, %pget.recv_obj.41
  br label %pic.miss.call.55

pic.miss.call.55:                                 ; preds = %pic.way.load.62, %pic.ways.61, %pic.miss.cold.54, %pic.miss.53
  %r239 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r240 = bitcast double %r239 to i64
  %r241 = and i64 %r240, 281474976710655
  %statepoint_token22 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r110, i64 %r241, ptr @perry_ic_options_worker_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated13, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r24223 = call double @llvm.experimental.gc.result.f64(token %statepoint_token22)
  %rs4gc.s7.relocated24 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 0, i32 0) ; (%rs4gc.s7.relocated13, %rs4gc.s7.relocated13)
  %rs4gc.s8.relocated25 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated26 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pic.merge.56

pic.merge.56:                                     ; preds = %pic.way.live.63, %pic.hit.overflow.59, %pic.miss.call.55, %pic.desc.prefix.hit.52, %pic.prefix.hit.47, %pic.hit.live.43
  %.1231 = phi ptr addrspace(1) [ %rs4gc.s9.relocated31, %pic.hit.overflow.59 ], [ %rs4gc.s9.relocated26, %pic.miss.call.55 ], [ %rs4gc.s9, %pic.way.live.63 ], [ %rs4gc.s9, %pic.hit.live.43 ], [ %rs4gc.s9, %pic.prefix.hit.47 ], [ %rs4gc.s9, %pic.desc.prefix.hit.52 ]
  %.1228 = phi ptr addrspace(1) [ %rs4gc.s8.relocated30, %pic.hit.overflow.59 ], [ %rs4gc.s8.relocated25, %pic.miss.call.55 ], [ %rs4gc.s8, %pic.way.live.63 ], [ %rs4gc.s8, %pic.hit.live.43 ], [ %rs4gc.s8, %pic.prefix.hit.47 ], [ %rs4gc.s8, %pic.desc.prefix.hit.52 ]
  %.6 = phi ptr addrspace(1) [ %rs4gc.s7.relocated29, %pic.hit.overflow.59 ], [ %rs4gc.s7.relocated24, %pic.miss.call.55 ], [ %rs4gc.s7.relocated13, %pic.way.live.63 ], [ %rs4gc.s7.relocated13, %pic.hit.live.43 ], [ %rs4gc.s7.relocated13, %pic.prefix.hit.47 ], [ %rs4gc.s7.relocated13, %pic.desc.prefix.hit.52 ]
  %r243 = phi double [ %r159, %pic.hit.live.43 ], [ %r15428, %pic.hit.overflow.59 ], [ %r179, %pic.prefix.hit.47 ], [ %r197, %pic.desc.prefix.hit.52 ], [ %r236, %pic.way.live.63 ], [ %r24223, %pic.miss.call.55 ]
  br label %pget.recv_merge.37

pic.recv_hdr.57:                                  ; preds = %pget.recv_obj.41
  %r122 = sub nuw nsw i64 %r110, 8
  %r123 = inttoptr i64 %r122 to ptr
  %r124 = load i8, ptr %r123, align 1
  %r125 = icmp eq i8 %r124, 2
  %r126 = sub nuw nsw i64 %r110, 6
  %r127 = inttoptr i64 %r126 to ptr
  %r128 = load i16, ptr %r127, align 2
  %r129 = and i16 %r128, 2048
  %r130 = icmp eq i16 %r129, 0
  %r131 = load ptr, ptr @perry_ic_options_worker_ts__13, align 8
  %r132 = icmp ne ptr %r131, null
  %r133 = and i1 %r125, %r130
  %r134 = and i1 %r133, %r132
  br i1 %r134, label %pic.token.58, label %pic.desc.classify.48

pic.token.58:                                     ; preds = %pic.recv_hdr.57
  %r136 = add nuw nsw i64 %r110, 4
  %r137 = inttoptr i64 %r136 to ptr
  %r138 = load i32, ptr %r137, align 4
  %r139 = zext i32 %r138 to i64
  %r140 = or i64 %r139, 4611686018427387904
  %r141 = icmp ne i32 %r138, 0
  %r142 = getelementptr i64, ptr %r131, i64 0
  %r143 = load i64, ptr %r142, align 8
  %r144 = icmp eq i64 %r140, %r143
  %r145 = and i1 %r144, %r141
  br i1 %r145, label %pic.hit.42, label %pic.prefix.guard.44

pic.hit.overflow.59:                              ; preds = %pic.hit.42
  %r150 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r151 = bitcast double %r150 to i64
  %r152 = and i64 %r151, 281474976710655
  %r153 = trunc i64 %r147 to i32
  %statepoint_token27 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r110, i64 %r152, i32 %r153, ptr @perry_ic_options_worker_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated13, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r15428 = call double @llvm.experimental.gc.result.f64(token %statepoint_token27)
  %rs4gc.s7.relocated29 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token27, i32 0, i32 0) ; (%rs4gc.s7.relocated13, %rs4gc.s7.relocated13)
  %rs4gc.s8.relocated30 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token27, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated31 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token27, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pic.merge.56

pic.hit.inline.60:                                ; preds = %pic.hit.42
  %r155 = shl i64 %r147, 3
  %r156 = add nuw nsw i64 %r110, 16
  %r157 = add i64 %r156, %r155
  %r158 = inttoptr i64 %r157 to ptr
  %r159 = load double, ptr %r158, align 8
  %r160 = bitcast double %r159 to i64
  %r161 = icmp eq i64 %r160, 9222246136947933200
  br i1 %r161, label %pic.miss.53, label %pic.hit.live.43

pic.ways.61:                                      ; preds = %pic.miss.53
  %r201 = getelementptr i64, ptr %r131, i64 4
  %r202 = load i64, ptr %r201, align 8
  %r203 = icmp eq i64 %r202, %r140
  %r204 = getelementptr i64, ptr %r131, i64 5
  %r205 = load i64, ptr %r204, align 8
  %r206 = select i1 %r203, i64 %r205, i64 0
  %r207 = getelementptr i64, ptr %r131, i64 6
  %r208 = load i64, ptr %r207, align 8
  %r209 = icmp eq i64 %r208, %r140
  %r210 = getelementptr i64, ptr %r131, i64 7
  %r211 = load i64, ptr %r210, align 8
  %r212 = select i1 %r209, i64 %r211, i64 0
  %r213 = getelementptr i64, ptr %r131, i64 8
  %r214 = load i64, ptr %r213, align 8
  %r215 = icmp eq i64 %r214, %r140
  %r216 = getelementptr i64, ptr %r131, i64 9
  %r217 = load i64, ptr %r216, align 8
  %r218 = select i1 %r215, i64 %r217, i64 0
  %r219 = getelementptr i64, ptr %r131, i64 10
  %r220 = load i64, ptr %r219, align 8
  %r221 = icmp eq i64 %r220, %r140
  %r222 = getelementptr i64, ptr %r131, i64 11
  %r223 = load i64, ptr %r222, align 8
  %r224 = select i1 %r221, i64 %r223, i64 0
  %r225 = or i1 %r203, %r209
  %r226 = select i1 %r203, i64 %r206, i64 %r212
  %r227 = or i1 %r215, %r221
  %r228 = select i1 %r215, i64 %r218, i64 %r224
  %r229 = or i1 %r225, %r227
  %r230 = select i1 %r225, i64 %r226, i64 %r228
  %r231 = and i1 %r141, %r229
  br i1 %r231, label %pic.way.load.62, label %pic.miss.call.55

pic.way.load.62:                                  ; preds = %pic.ways.61
  %r232 = shl i64 %r230, 3
  %r233 = add nuw nsw i64 %r110, 16
  %r234 = add i64 %r233, %r232
  %r235 = inttoptr i64 %r234 to ptr
  %r236 = load double, ptr %r235, align 8
  %r237 = bitcast double %r236 to i64
  %r238 = icmp eq i64 %r237, 9222246136947933200
  br i1 %r238, label %pic.miss.call.55, label %pic.way.live.63

pic.way.live.63:                                  ; preds = %pic.way.load.62
  br label %pic.merge.56

pget.throw_nullish.64:                            ; preds = %pget.recv_bad.35
  %r247 = zext i1 %r245 to i32
  %statepoint_token32 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r247, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.65:                        ; preds = %pget.recv_bad.35
  %r248 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r249 = bitcast double %r248 to i64
  %r250 = and i64 %r249, 281474976710655
  %statepoint_token33 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r109, i64 %r250, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated13, ptr addrspace(1) %rs4gc.s8, ptr addrspace(1) %rs4gc.s9) ]
  %r25134 = call double @llvm.experimental.gc.result.f64(token %statepoint_token33)
  %rs4gc.s7.relocated35 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 0, i32 0) ; (%rs4gc.s7.relocated13, %rs4gc.s7.relocated13)
  %rs4gc.s8.relocated36 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.s9.relocated37 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 2, i32 2) ; (%rs4gc.s9, %rs4gc.s9)
  br label %pget.recv_merge.37

guarded_add.numeric.66:                           ; preds = %pget.recv_merge.37
  %r273 = fadd double %r262, %r260
  br label %guarded_add.merge.68

guarded_add.dynamic.67:                           ; preds = %pget.recv_merge.37
  %statepoint_token38 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r262, double %r260, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5, ptr addrspace(1) %.0227) ]
  %r27439 = call double @llvm.experimental.gc.result.f64(token %statepoint_token38)
  %rs4gc.s7.relocated40 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 0, i32 0) ; (%.5, %.5)
  %rs4gc.s8.relocated41 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 1, i32 1) ; (%.0227, %.0227)
  br label %guarded_add.merge.68

guarded_add.merge.68:                             ; preds = %guarded_add.dynamic.67, %guarded_add.numeric.66
  %.2229 = phi ptr addrspace(1) [ %.0227, %guarded_add.numeric.66 ], [ %rs4gc.s8.relocated41, %guarded_add.dynamic.67 ]
  %.7 = phi ptr addrspace(1) [ %.5, %guarded_add.numeric.66 ], [ %rs4gc.s7.relocated40, %guarded_add.dynamic.67 ]
  %r275 = phi double [ %r273, %guarded_add.numeric.66 ], [ %r27439, %guarded_add.dynamic.67 ]
  %r276.rs4i = ptrtoint ptr addrspace(1) %.2229 to i64
  %r276.rs4o = call i64 asm "", "=r,0"(i64 %r276.rs4i) #9
  %r276 = bitcast i64 %r276.rs4o to double
  %r277 = bitcast double %r276 to i64
  %r278 = and i64 %r277, -281474976710656
  %r279 = icmp ne i64 %r278, 9223090561878065152
  br i1 %r279, label %str_addref.done.70, label %str_addref.call.69

str_addref.call.69:                               ; preds = %guarded_add.merge.68
  call void @js_string_addref_if_heap_string(double %r276) #9
  br label %str_addref.done.70

str_addref.done.70:                               ; preds = %str_addref.call.69, %guarded_add.merge.68
  %r1728.rs4i = ptrtoint ptr addrspace(1) %.2229 to i64
  %r1728.rs4o = call i64 asm "", "=r,0"(i64 %r1728.rs4i) #9
  %r1728 = bitcast i64 %r1728.rs4o to double
  store double %r1728, ptr @perry_global_options_worker_ts__7, align 8
  %r1727.rs4i = ptrtoint ptr addrspace(1) %.2229 to i64
  %r1727.rs4o = call i64 asm "", "=r,0"(i64 %r1727.rs4i) #9
  %r1727 = bitcast i64 %r1727.rs4o to double
  %r280 = bitcast double %r1727 to i64
  %r1725.rs4i = ptrtoint ptr addrspace(1) %.2229 to i64
  %r1725.rs4o = call i64 asm "", "=r,0"(i64 %r1725.rs4i) #9
  %r1725 = bitcast i64 %r1725.rs4o to double
  %r1726 = bitcast double %r1725 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1726) #9
  %r281 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r282 = icmp ne i32 %r281, 0
  br i1 %r282, label %gcpoll.71, label %gcpoll.done.72

gcpoll.71:                                        ; preds = %str_addref.done.70
  %statepoint_token42 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.7) ]
  %rs4gc.s7.relocated43 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token42, i32 0, i32 0) ; (%.7, %.7)
  br label %gcpoll.done.72

gcpoll.done.72:                                   ; preds = %gcpoll.71, %str_addref.done.70
  %.8 = phi ptr addrspace(1) [ %rs4gc.s7.relocated43, %gcpoll.71 ], [ %.7, %str_addref.done.70 ]
  br label %for.update.20

streqlit.tag.73:                                  ; preds = %if.else.11
  %r292 = lshr i64 %r289, 48
  %r293 = icmp eq i64 %r292, 32767
  %r294 = and i64 %r289, 281474976710655
  %r295 = icmp ugt i64 %r294, 4095
  %r296 = and i1 %r293, %r295
  br i1 %r296, label %streqlit.len.74, label %streqlit.false.79

streqlit.len.74:                                  ; preds = %streqlit.tag.73
  %r297 = inttoptr i64 %r294 to ptr
  %r298 = getelementptr inbounds nuw i8, ptr %r297, i64 4
  %r299 = load i32, ptr %r298, align 4
  %r300 = icmp eq i32 %r299, 12
  br i1 %r300, label %streqlit.b0.75, label %streqlit.false.79

streqlit.b0.75:                                   ; preds = %streqlit.len.74
  %r301 = getelementptr inbounds nuw i8, ptr %r297, i64 20
  %r302 = load i8, ptr %r301, align 1
  %r303 = icmp eq i8 %r302, 100
  br i1 %r303, label %streqlit.bl.76, label %streqlit.false.79

streqlit.bl.76:                                   ; preds = %streqlit.b0.75
  %r304 = getelementptr inbounds nuw i8, ptr %r297, i64 31
  %r305 = load i8, ptr %r304, align 1
  %r306 = icmp eq i8 %r305, 111
  br i1 %r306, label %streqlit.slow.77, label %streqlit.false.79

streqlit.slow.77:                                 ; preds = %streqlit.bl.76
  %r307 = and i64 %r290, 281474976710655
  %statepoint_token44 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r294, i64 %r307, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r30845 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token44)
  %rs4gc.s7.relocated46 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token44, i32 0, i32 0) ; (%.0, %.0)
  %r309 = icmp ne i32 %r30845, 0
  br label %streqlit.merge.80

streqlit.true.78:                                 ; preds = %if.else.11
  br label %streqlit.merge.80

streqlit.false.79:                                ; preds = %streqlit.bl.76, %streqlit.b0.75, %streqlit.len.74, %streqlit.tag.73
  br label %streqlit.merge.80

streqlit.merge.80:                                ; preds = %streqlit.false.79, %streqlit.true.78, %streqlit.slow.77
  %.9 = phi ptr addrspace(1) [ %.0, %streqlit.true.78 ], [ %rs4gc.s7.relocated46, %streqlit.slow.77 ], [ %.0, %streqlit.false.79 ]
  %r310 = phi i1 [ true, %streqlit.true.78 ], [ false, %streqlit.false.79 ], [ %r309, %streqlit.slow.77 ]
  %r311 = select i1 %r310, i64 9222246136947933188, i64 9222246136947933187
  %r312 = bitcast i64 %r311 to double
  %r313 = icmp eq i64 %r311, 9222246136947933188
  br i1 %r313, label %if.then.81, label %if.else.82

if.then.81:                                       ; preds = %streqlit.merge.80
  %r318.rs4i = ptrtoint ptr addrspace(1) %.9 to i64
  %r318.rs4o = call i64 asm "", "=r,0"(i64 %r318.rs4i) #9
  %r318 = bitcast i64 %r318.rs4o to double
  %r319 = bitcast double %r318 to i64
  %r320 = and i64 %r319, -281474976710656
  %r321 = icmp ult i64 %r320, 9221401712017801216
  %r322 = icmp ugt i64 %r320, 9223090561878065152
  %r323 = or i1 %r321, %r322
  br i1 %r323, label %for.bound_i32.number.84, label %for.bound_i32.merge.86

if.else.82:                                       ; preds = %streqlit.merge.80
  %r570 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r571 = load double, ptr @options_worker_ts_.str.3.handle, align 8
  %r572 = bitcast double %r570 to i64
  %r573 = bitcast double %r571 to i64
  %r574 = icmp eq i64 %r572, %r573
  br i1 %r574, label %streqlit.true.150, label %streqlit.sso.144

if.merge.83:                                      ; preds = %if.merge.155, %for.exit.92
  %r2.2 = phi double [ %r2.3, %for.exit.92 ], [ %r2.4, %if.merge.155 ]
  br label %if.merge.12

for.bound_i32.number.84:                          ; preds = %if.then.81
  %r324 = fcmp oge double %r318, 0xC1E0000000000000
  %r325 = fcmp ole double %r318, 0x41DFFFFFFFC00000
  %r326 = and i1 %r324, %r325
  br i1 %r326, label %for.bound_i32.convert.85, label %for.bound_i32.merge.86

for.bound_i32.convert.85:                         ; preds = %for.bound_i32.number.84
  %r327 = fptosi double %r318 to i32
  %r328 = sitofp i32 %r327 to double
  %r329 = fcmp oeq double %r328, %r318
  br i1 %r329, label %for.counter_i32.range.87, label %for.bound_i32.merge.86

for.bound_i32.merge.86:                           ; preds = %for.counter_i32.convert.88, %for.bound_i32.convert.85, %for.bound_i32.number.84, %if.then.81
  %r317.0 = phi i32 [ %r327, %for.counter_i32.convert.88 ], [ 0, %if.then.81 ], [ %r327, %for.bound_i32.convert.85 ], [ 0, %for.bound_i32.number.84 ]
  %r316.0 = phi i1 [ true, %for.counter_i32.convert.88 ], [ false, %if.then.81 ], [ false, %for.bound_i32.convert.85 ], [ false, %for.bound_i32.number.84 ]
  br label %for.cond.89

for.counter_i32.range.87:                         ; preds = %for.bound_i32.convert.85
  br label %for.counter_i32.convert.88

for.counter_i32.convert.88:                       ; preds = %for.counter_i32.range.87
  br label %for.bound_i32.merge.86

for.cond.89:                                      ; preds = %for.update.91, %for.bound_i32.merge.86
  %.10 = phi ptr addrspace(1) [ %.9, %for.bound_i32.merge.86 ], [ %.17, %for.update.91 ]
  %r315.1 = phi i32 [ 0, %for.bound_i32.merge.86 ], [ %r569, %for.update.91 ]
  %r314.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.86 ], [ %r567, %for.update.91 ]
  %r2.3 = phi double [ 0.000000e+00, %for.bound_i32.merge.86 ], [ %r558, %for.update.91 ]
  br i1 %r316.0, label %for.cond.fast.93, label %for.cond.slow.94

for.body.90:                                      ; preds = %gcpoll.done.99, %for.cond.fast.93
  %.11 = phi ptr addrspace(1) [ %.10, %for.cond.fast.93 ], [ %.13, %gcpoll.done.99 ]
  %r379 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %r380 = load double, ptr @perry_global_options_worker_ts__2, align 8
  %statepoint_token47 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r379, double 0x7FFC000000000002, double %r380, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11) ]
  %r38148 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token47)
  %rs4gc.s7.relocated49 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token47, i32 0, i32 0) ; (%.11, %.11)
  %r382 = bitcast i64 %r38148 to double
  %rs4gc.b10 = bitcast double %r382 to i64
  %rs4gc.s10 = inttoptr i64 %rs4gc.b10 to ptr addrspace(1)
  %r383.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r383 = call i64 asm "", "=r,0"(i64 %r383.rs4i) #9
  %r384 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r385 = icmp ne i32 %r384, 0
  br i1 %r385, label %shadow.root.barrier.100, label %shadow.root.barrier.done.101

for.update.91:                                    ; preds = %gcpoll.done.143
  %r567 = fadd double %r314.0, 1.000000e+00
  %r569 = add i32 %r315.1, 1
  br label %for.cond.89

for.exit.92:                                      ; preds = %gcpoll.done.99, %for.cond.fast.93
  br label %if.merge.83

for.cond.fast.93:                                 ; preds = %for.cond.89
  %r340 = icmp slt i32 %r315.1, %r317.0
  br i1 %r340, label %for.body.90, label %for.exit.92

for.cond.slow.94:                                 ; preds = %for.cond.89
  %r342.rs4i = ptrtoint ptr addrspace(1) %.10 to i64
  %r342.rs4o = call i64 asm "", "=r,0"(i64 %r342.rs4i) #9
  %r342 = bitcast i64 %r342.rs4o to double
  %r343 = bitcast double %r342 to i64
  %r344 = lshr i64 %r343, 48
  %r345 = icmp ult i64 %r344, 32761
  %r346 = icmp ugt i64 %r344, 32767
  %r347 = or i1 %r345, %r346
  %r348 = icmp eq i64 %r344, 32766
  %r349 = icmp eq i64 %r343, 9222246136947933185
  %r350 = icmp eq i64 %r343, 9222246136947933186
  %r351 = icmp eq i64 %r343, 9222246136947933187
  %r352 = icmp eq i64 %r343, 9222246136947933188
  %r353 = or i1 %r350, %r351
  %r354 = or i1 %r347, %r348
  %r355 = or i1 %r354, %r349
  %r356 = or i1 %r355, %r353
  %r357 = or i1 %r356, %r352
  br i1 %r357, label %relnum.fast.95, label %relnum.slow.96

relnum.fast.95:                                   ; preds = %for.cond.slow.94
  %r358 = trunc i64 %r343 to i32
  %r359 = sitofp i32 %r358 to double
  %r360 = select i1 %r348, double %r359, double %r342
  %r361 = select i1 %r353, double 0.000000e+00, double %r360
  %r362 = select i1 %r352, double 1.000000e+00, double %r361
  %r363 = bitcast double %r314.0 to i64
  %r364 = lshr i64 %r363, 48
  %r365 = icmp eq i64 %r364, 32766
  %r366 = trunc i64 %r363 to i32
  %r367 = sitofp i32 %r366 to double
  %r368 = select i1 %r365, double %r367, double %r314.0
  %r369 = fcmp olt double %r368, %r362
  %r370 = select i1 %r369, i64 9222246136947933188, i64 9222246136947933187
  %r371 = bitcast i64 %r370 to double
  br label %relnum.merge.97

relnum.slow.96:                                   ; preds = %for.cond.slow.94
  %statepoint_token50 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r314.0, double %r342, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10) ]
  %r37251 = call double @llvm.experimental.gc.result.f64(token %statepoint_token50)
  %rs4gc.s7.relocated52 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token50, i32 0, i32 0) ; (%.10, %.10)
  br label %relnum.merge.97

relnum.merge.97:                                  ; preds = %relnum.slow.96, %relnum.fast.95
  %.12 = phi ptr addrspace(1) [ %.10, %relnum.fast.95 ], [ %rs4gc.s7.relocated52, %relnum.slow.96 ]
  %r373 = phi double [ %r371, %relnum.fast.95 ], [ %r37251, %relnum.slow.96 ]
  %r374 = bitcast double %r373 to i64
  %r376 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r377 = icmp ne i32 %r376, 0
  br i1 %r377, label %gcpoll.98, label %gcpoll.done.99

gcpoll.98:                                        ; preds = %relnum.merge.97
  %statepoint_token53 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12) ]
  %rs4gc.s7.relocated54 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token53, i32 0, i32 0) ; (%.12, %.12)
  br label %gcpoll.done.99

gcpoll.done.99:                                   ; preds = %gcpoll.98, %relnum.merge.97
  %.13 = phi ptr addrspace(1) [ %rs4gc.s7.relocated54, %gcpoll.98 ], [ %.12, %relnum.merge.97 ]
  %r375 = icmp eq i64 %r374, 9222246136947933188
  br i1 %r375, label %for.body.90, label %for.exit.92

shadow.root.barrier.100:                          ; preds = %for.body.90
  call void @js_write_barrier_root_nanbox(i64 %r383) #9
  br label %shadow.root.barrier.done.101

shadow.root.barrier.done.101:                     ; preds = %shadow.root.barrier.100, %for.body.90
  %r387 = bitcast double %r2.3 to i64
  %rs4gc.s11 = inttoptr i64 %r387 to ptr addrspace(1)
  %r388.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11 to i64
  %r388 = call i64 asm "", "=r,0"(i64 %r388.rs4i) #9
  %r389 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r390 = icmp ne i32 %r389, 0
  br i1 %r390, label %shadow.root.barrier.102, label %shadow.root.barrier.done.103

shadow.root.barrier.102:                          ; preds = %shadow.root.barrier.done.101
  call void @js_write_barrier_root_nanbox(i64 %r388) #9
  br label %shadow.root.barrier.done.103

shadow.root.barrier.done.103:                     ; preds = %shadow.root.barrier.102, %shadow.root.barrier.done.101
  %r391.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r391.rs4o = call i64 asm "", "=r,0"(i64 %r391.rs4i) #9
  %r391 = bitcast i64 %r391.rs4o to double
  %r392 = bitcast double %r391 to i64
  %r393 = and i64 %r392, 281474976710655
  %r394 = lshr i64 %r392, 48
  %r395 = and i64 %r394, 65533
  %r396 = icmp eq i64 %r395, 32765
  br i1 %r396, label %pget.recv_ok.105, label %pget.recv_other.110

pget.recv_sso.104:                                ; preds = %pget.recv_other.110
  %r535 = lshr i64 %r392, 40
  %r536 = and i64 %r535, 255
  %r537 = uitofp nneg i64 %r536 to double
  br label %pget.recv_merge.108

pget.recv_ok.105:                                 ; preds = %shadow.root.barrier.done.103
  %r403 = icmp eq i64 %r394, 32767
  br i1 %r403, label %pget.strlen_heap.109, label %pget.recv_obj.112

pget.recv_bad.106:                                ; preds = %pget.check_class_ref.111
  %r527 = icmp eq i64 %r392, 9222246136947933185
  %r528 = icmp eq i64 %r392, 9222246136947933186
  %r529 = or i1 %r527, %r528
  br i1 %r529, label %pget.throw_nullish.135, label %pget.recv_undef_return.136

pget.recv_class_ref.107:                          ; preds = %pget.check_class_ref.111
  %r399 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r400 = bitcast double %r399 to i64
  %r401 = and i64 %r400, 281474976710655
  %statepoint_token55 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532878, i64 %r392, i64 %r401, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated49, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r40256 = call double @llvm.experimental.gc.result.f64(token %statepoint_token55)
  %rs4gc.s7.relocated57 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 0, i32 0) ; (%rs4gc.s7.relocated49, %rs4gc.s7.relocated49)
  %rs4gc.s10.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token55, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pget.recv_merge.108

pget.recv_merge.108:                              ; preds = %pget.recv_undef_return.136, %pic.merge.127, %pget.strlen_heap.109, %pget.recv_class_ref.107, %pget.recv_sso.104
  %.0235 = phi ptr addrspace(1) [ %rs4gc.s11, %pget.strlen_heap.109 ], [ %.1236, %pic.merge.127 ], [ %rs4gc.s11, %pget.recv_sso.104 ], [ %rs4gc.s11.relocated, %pget.recv_class_ref.107 ], [ %rs4gc.s11.relocated73, %pget.recv_undef_return.136 ]
  %.0232 = phi ptr addrspace(1) [ %rs4gc.s10, %pget.strlen_heap.109 ], [ %.1233, %pic.merge.127 ], [ %rs4gc.s10, %pget.recv_sso.104 ], [ %rs4gc.s10.relocated, %pget.recv_class_ref.107 ], [ %rs4gc.s10.relocated72, %pget.recv_undef_return.136 ]
  %.14 = phi ptr addrspace(1) [ %rs4gc.s7.relocated49, %pget.strlen_heap.109 ], [ %.15, %pic.merge.127 ], [ %rs4gc.s7.relocated49, %pget.recv_sso.104 ], [ %rs4gc.s7.relocated57, %pget.recv_class_ref.107 ], [ %rs4gc.s7.relocated71, %pget.recv_undef_return.136 ]
  %r543 = phi double [ %r526, %pic.merge.127 ], [ %r53470, %pget.recv_undef_return.136 ], [ %r537, %pget.recv_sso.104 ], [ %r40256, %pget.recv_class_ref.107 ], [ %r542, %pget.strlen_heap.109 ]
  %r544.rs4i = ptrtoint ptr addrspace(1) %.0235 to i64
  %r544 = call i64 asm "", "=r,0"(i64 %r544.rs4i) #9
  %r545 = bitcast i64 %r544 to double
  %r546 = and i64 %r544, -281474976710656
  %r547 = icmp ult i64 %r546, 9221401712017801216
  %r548 = icmp ugt i64 %r546, 9223090561878065152
  %r549 = or i1 %r547, %r548
  %r550 = bitcast double %r543 to i64
  %r551 = and i64 %r550, -281474976710656
  %r552 = icmp ult i64 %r551, 9221401712017801216
  %r553 = icmp ugt i64 %r551, 9223090561878065152
  %r554 = or i1 %r552, %r553
  %r555 = and i1 %r549, %r554
  br i1 %r555, label %guarded_add.numeric.137, label %guarded_add.dynamic.138

pget.strlen_heap.109:                             ; preds = %pget.recv_ok.105
  %r538 = icmp ult i64 %r393, 4096
  %r539 = inttoptr i64 %r393 to ptr
  %r540 = select i1 %r538, ptr @perry_null_guard_zero_options_worker_ts, ptr %r539
  %r541 = load i32, ptr %r540, align 4
  %r542 = uitofp i32 %r541 to double
  br label %pget.recv_merge.108

pget.recv_other.110:                              ; preds = %shadow.root.barrier.done.103
  %r397 = icmp eq i64 %r394, 32761
  br i1 %r397, label %pget.recv_sso.104, label %pget.check_class_ref.111

pget.check_class_ref.111:                         ; preds = %pget.recv_other.110
  %r398 = icmp eq i64 %r394, 32766
  br i1 %r398, label %pget.recv_class_ref.107, label %pget.recv_bad.106

pget.recv_obj.112:                                ; preds = %pget.recv_ok.105
  %r404 = icmp ugt i64 %r393, 1048575
  br i1 %r404, label %pic.recv_hdr.128, label %pic.miss.cold.125

pic.hit.113:                                      ; preds = %pic.token.129
  %r429 = getelementptr i64, ptr %r414, i64 1
  %r430 = load i64, ptr %r429, align 8
  %r431 = and i64 %r430, 1073741824
  %r432 = icmp ne i64 %r431, 0
  br i1 %r432, label %pic.hit.overflow.130, label %pic.hit.inline.131

pic.hit.live.114:                                 ; preds = %pic.hit.inline.131
  br label %pic.merge.127

pic.prefix.guard.115:                             ; preds = %pic.token.129
  %r445 = getelementptr i64, ptr %r414, i64 2
  %r446 = load i64, ptr %r445, align 8
  %r447 = icmp ne i64 %r446, 0
  br i1 %r447, label %pic.prefix.meta.116, label %pic.miss.124

pic.prefix.meta.116:                              ; preds = %pic.prefix.guard.115
  %r448 = add nuw nsw i64 %r393, 8
  %r449 = inttoptr i64 %r448 to ptr
  %r450 = load i64, ptr %r449, align 8
  %r451 = icmp ne i64 %r450, 0
  br i1 %r451, label %pic.prefix.token.117, label %pic.miss.124

pic.prefix.token.117:                             ; preds = %pic.prefix.meta.116
  %r452 = inttoptr i64 %r450 to ptr
  %r453 = getelementptr i64, ptr %r452, i64 6
  %r454 = load i64, ptr %r453, align 8
  %r455 = icmp eq i64 %r454, %r446
  br i1 %r455, label %pic.prefix.hit.118, label %pic.miss.124

pic.prefix.hit.118:                               ; preds = %pic.prefix.token.117
  %r456 = getelementptr i64, ptr %r414, i64 1
  %r457 = load i64, ptr %r456, align 8
  %r458 = shl i64 %r457, 3
  %r459 = add nuw nsw i64 %r393, 16
  %r460 = add i64 %r459, %r458
  %r461 = inttoptr i64 %r460 to ptr
  %r462 = load double, ptr %r461, align 8
  br label %pic.merge.127

pic.desc.classify.119:                            ; preds = %pic.recv_hdr.128
  %r418 = and i1 %r408, %r415
  br i1 %r418, label %pic.desc.prefix.guard.120, label %pic.miss.cold.125

pic.desc.prefix.guard.120:                        ; preds = %pic.desc.classify.119
  %r463 = getelementptr i64, ptr %r414, i64 2
  %r464 = load i64, ptr %r463, align 8
  %r465 = icmp ne i64 %r464, 0
  br i1 %r465, label %pic.desc.prefix.meta.121, label %pic.miss.cold.125

pic.desc.prefix.meta.121:                         ; preds = %pic.desc.prefix.guard.120
  %r466 = add nuw nsw i64 %r393, 8
  %r467 = inttoptr i64 %r466 to ptr
  %r468 = load i64, ptr %r467, align 8
  %r469 = icmp ne i64 %r468, 0
  br i1 %r469, label %pic.desc.prefix.token.122, label %pic.miss.cold.125

pic.desc.prefix.token.122:                        ; preds = %pic.desc.prefix.meta.121
  %r470 = inttoptr i64 %r468 to ptr
  %r471 = getelementptr i64, ptr %r470, i64 6
  %r472 = load i64, ptr %r471, align 8
  %r473 = icmp eq i64 %r472, %r464
  br i1 %r473, label %pic.desc.prefix.hit.123, label %pic.miss.cold.125

pic.desc.prefix.hit.123:                          ; preds = %pic.desc.prefix.token.122
  %r474 = getelementptr i64, ptr %r414, i64 1
  %r475 = load i64, ptr %r474, align 8
  %r476 = shl i64 %r475, 3
  %r477 = add nuw nsw i64 %r393, 16
  %r478 = add i64 %r477, %r476
  %r479 = inttoptr i64 %r478 to ptr
  %r480 = load double, ptr %r479, align 8
  br label %pic.merge.127

pic.miss.124:                                     ; preds = %pic.hit.inline.131, %pic.prefix.token.117, %pic.prefix.meta.116, %pic.prefix.guard.115
  %r481 = getelementptr i64, ptr %r414, i64 3
  %r482 = load i64, ptr %r481, align 8
  %r483 = icmp sgt i64 %r482, 0
  br i1 %r483, label %pic.ways.132, label %pic.miss.call.126

pic.miss.cold.125:                                ; preds = %pic.desc.prefix.token.122, %pic.desc.prefix.meta.121, %pic.desc.prefix.guard.120, %pic.desc.classify.119, %pget.recv_obj.112
  br label %pic.miss.call.126

pic.miss.call.126:                                ; preds = %pic.way.load.133, %pic.ways.132, %pic.miss.cold.125, %pic.miss.124
  %r522 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r523 = bitcast double %r522 to i64
  %r524 = and i64 %r523, 281474976710655
  %statepoint_token58 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r393, i64 %r524, ptr @perry_ic_options_worker_ts__15, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated49, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r52559 = call double @llvm.experimental.gc.result.f64(token %statepoint_token58)
  %rs4gc.s7.relocated60 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token58, i32 0, i32 0) ; (%rs4gc.s7.relocated49, %rs4gc.s7.relocated49)
  %rs4gc.s10.relocated61 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token58, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated62 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token58, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pic.merge.127

pic.merge.127:                                    ; preds = %pic.way.live.134, %pic.hit.overflow.130, %pic.miss.call.126, %pic.desc.prefix.hit.123, %pic.prefix.hit.118, %pic.hit.live.114
  %.1236 = phi ptr addrspace(1) [ %rs4gc.s11.relocated67, %pic.hit.overflow.130 ], [ %rs4gc.s11.relocated62, %pic.miss.call.126 ], [ %rs4gc.s11, %pic.way.live.134 ], [ %rs4gc.s11, %pic.hit.live.114 ], [ %rs4gc.s11, %pic.prefix.hit.118 ], [ %rs4gc.s11, %pic.desc.prefix.hit.123 ]
  %.1233 = phi ptr addrspace(1) [ %rs4gc.s10.relocated66, %pic.hit.overflow.130 ], [ %rs4gc.s10.relocated61, %pic.miss.call.126 ], [ %rs4gc.s10, %pic.way.live.134 ], [ %rs4gc.s10, %pic.hit.live.114 ], [ %rs4gc.s10, %pic.prefix.hit.118 ], [ %rs4gc.s10, %pic.desc.prefix.hit.123 ]
  %.15 = phi ptr addrspace(1) [ %rs4gc.s7.relocated65, %pic.hit.overflow.130 ], [ %rs4gc.s7.relocated60, %pic.miss.call.126 ], [ %rs4gc.s7.relocated49, %pic.way.live.134 ], [ %rs4gc.s7.relocated49, %pic.hit.live.114 ], [ %rs4gc.s7.relocated49, %pic.prefix.hit.118 ], [ %rs4gc.s7.relocated49, %pic.desc.prefix.hit.123 ]
  %r526 = phi double [ %r442, %pic.hit.live.114 ], [ %r43764, %pic.hit.overflow.130 ], [ %r462, %pic.prefix.hit.118 ], [ %r480, %pic.desc.prefix.hit.123 ], [ %r519, %pic.way.live.134 ], [ %r52559, %pic.miss.call.126 ]
  br label %pget.recv_merge.108

pic.recv_hdr.128:                                 ; preds = %pget.recv_obj.112
  %r405 = sub nuw nsw i64 %r393, 8
  %r406 = inttoptr i64 %r405 to ptr
  %r407 = load i8, ptr %r406, align 1
  %r408 = icmp eq i8 %r407, 2
  %r409 = sub nuw nsw i64 %r393, 6
  %r410 = inttoptr i64 %r409 to ptr
  %r411 = load i16, ptr %r410, align 2
  %r412 = and i16 %r411, 2048
  %r413 = icmp eq i16 %r412, 0
  %r414 = load ptr, ptr @perry_ic_options_worker_ts__15, align 8
  %r415 = icmp ne ptr %r414, null
  %r416 = and i1 %r408, %r413
  %r417 = and i1 %r416, %r415
  br i1 %r417, label %pic.token.129, label %pic.desc.classify.119

pic.token.129:                                    ; preds = %pic.recv_hdr.128
  %r419 = add nuw nsw i64 %r393, 4
  %r420 = inttoptr i64 %r419 to ptr
  %r421 = load i32, ptr %r420, align 4
  %r422 = zext i32 %r421 to i64
  %r423 = or i64 %r422, 4611686018427387904
  %r424 = icmp ne i32 %r421, 0
  %r425 = getelementptr i64, ptr %r414, i64 0
  %r426 = load i64, ptr %r425, align 8
  %r427 = icmp eq i64 %r423, %r426
  %r428 = and i1 %r427, %r424
  br i1 %r428, label %pic.hit.113, label %pic.prefix.guard.115

pic.hit.overflow.130:                             ; preds = %pic.hit.113
  %r433 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r434 = bitcast double %r433 to i64
  %r435 = and i64 %r434, 281474976710655
  %r436 = trunc i64 %r430 to i32
  %statepoint_token63 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r393, i64 %r435, i32 %r436, ptr @perry_ic_options_worker_ts__15, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated49, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r43764 = call double @llvm.experimental.gc.result.f64(token %statepoint_token63)
  %rs4gc.s7.relocated65 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 0, i32 0) ; (%rs4gc.s7.relocated49, %rs4gc.s7.relocated49)
  %rs4gc.s10.relocated66 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated67 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pic.merge.127

pic.hit.inline.131:                               ; preds = %pic.hit.113
  %r438 = shl i64 %r430, 3
  %r439 = add nuw nsw i64 %r393, 16
  %r440 = add i64 %r439, %r438
  %r441 = inttoptr i64 %r440 to ptr
  %r442 = load double, ptr %r441, align 8
  %r443 = bitcast double %r442 to i64
  %r444 = icmp eq i64 %r443, 9222246136947933200
  br i1 %r444, label %pic.miss.124, label %pic.hit.live.114

pic.ways.132:                                     ; preds = %pic.miss.124
  %r484 = getelementptr i64, ptr %r414, i64 4
  %r485 = load i64, ptr %r484, align 8
  %r486 = icmp eq i64 %r485, %r423
  %r487 = getelementptr i64, ptr %r414, i64 5
  %r488 = load i64, ptr %r487, align 8
  %r489 = select i1 %r486, i64 %r488, i64 0
  %r490 = getelementptr i64, ptr %r414, i64 6
  %r491 = load i64, ptr %r490, align 8
  %r492 = icmp eq i64 %r491, %r423
  %r493 = getelementptr i64, ptr %r414, i64 7
  %r494 = load i64, ptr %r493, align 8
  %r495 = select i1 %r492, i64 %r494, i64 0
  %r496 = getelementptr i64, ptr %r414, i64 8
  %r497 = load i64, ptr %r496, align 8
  %r498 = icmp eq i64 %r497, %r423
  %r499 = getelementptr i64, ptr %r414, i64 9
  %r500 = load i64, ptr %r499, align 8
  %r501 = select i1 %r498, i64 %r500, i64 0
  %r502 = getelementptr i64, ptr %r414, i64 10
  %r503 = load i64, ptr %r502, align 8
  %r504 = icmp eq i64 %r503, %r423
  %r505 = getelementptr i64, ptr %r414, i64 11
  %r506 = load i64, ptr %r505, align 8
  %r507 = select i1 %r504, i64 %r506, i64 0
  %r508 = or i1 %r486, %r492
  %r509 = select i1 %r486, i64 %r489, i64 %r495
  %r510 = or i1 %r498, %r504
  %r511 = select i1 %r498, i64 %r501, i64 %r507
  %r512 = or i1 %r508, %r510
  %r513 = select i1 %r508, i64 %r509, i64 %r511
  %r514 = and i1 %r424, %r512
  br i1 %r514, label %pic.way.load.133, label %pic.miss.call.126

pic.way.load.133:                                 ; preds = %pic.ways.132
  %r515 = shl i64 %r513, 3
  %r516 = add nuw nsw i64 %r393, 16
  %r517 = add i64 %r516, %r515
  %r518 = inttoptr i64 %r517 to ptr
  %r519 = load double, ptr %r518, align 8
  %r520 = bitcast double %r519 to i64
  %r521 = icmp eq i64 %r520, 9222246136947933200
  br i1 %r521, label %pic.miss.call.126, label %pic.way.live.134

pic.way.live.134:                                 ; preds = %pic.way.load.133
  br label %pic.merge.127

pget.throw_nullish.135:                           ; preds = %pget.recv_bad.106
  %r530 = zext i1 %r528 to i32
  %statepoint_token68 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r530, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.136:                       ; preds = %pget.recv_bad.106
  %r531 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r532 = bitcast double %r531 to i64
  %r533 = and i64 %r532, 281474976710655
  %statepoint_token69 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r392, i64 %r533, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated49, ptr addrspace(1) %rs4gc.s10, ptr addrspace(1) %rs4gc.s11) ]
  %r53470 = call double @llvm.experimental.gc.result.f64(token %statepoint_token69)
  %rs4gc.s7.relocated71 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token69, i32 0, i32 0) ; (%rs4gc.s7.relocated49, %rs4gc.s7.relocated49)
  %rs4gc.s10.relocated72 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token69, i32 1, i32 1) ; (%rs4gc.s10, %rs4gc.s10)
  %rs4gc.s11.relocated73 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token69, i32 2, i32 2) ; (%rs4gc.s11, %rs4gc.s11)
  br label %pget.recv_merge.108

guarded_add.numeric.137:                          ; preds = %pget.recv_merge.108
  %r556 = fadd double %r545, %r543
  br label %guarded_add.merge.139

guarded_add.dynamic.138:                          ; preds = %pget.recv_merge.108
  %statepoint_token74 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r545, double %r543, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.14, ptr addrspace(1) %.0232) ]
  %r55775 = call double @llvm.experimental.gc.result.f64(token %statepoint_token74)
  %rs4gc.s7.relocated76 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token74, i32 0, i32 0) ; (%.14, %.14)
  %rs4gc.s10.relocated77 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token74, i32 1, i32 1) ; (%.0232, %.0232)
  br label %guarded_add.merge.139

guarded_add.merge.139:                            ; preds = %guarded_add.dynamic.138, %guarded_add.numeric.137
  %.2234 = phi ptr addrspace(1) [ %.0232, %guarded_add.numeric.137 ], [ %rs4gc.s10.relocated77, %guarded_add.dynamic.138 ]
  %.16 = phi ptr addrspace(1) [ %.14, %guarded_add.numeric.137 ], [ %rs4gc.s7.relocated76, %guarded_add.dynamic.138 ]
  %r558 = phi double [ %r556, %guarded_add.numeric.137 ], [ %r55775, %guarded_add.dynamic.138 ]
  %r559.rs4i = ptrtoint ptr addrspace(1) %.2234 to i64
  %r559.rs4o = call i64 asm "", "=r,0"(i64 %r559.rs4i) #9
  %r559 = bitcast i64 %r559.rs4o to double
  %r560 = bitcast double %r559 to i64
  %r561 = and i64 %r560, -281474976710656
  %r562 = icmp ne i64 %r561, 9223090561878065152
  br i1 %r562, label %str_addref.done.141, label %str_addref.call.140

str_addref.call.140:                              ; preds = %guarded_add.merge.139
  call void @js_string_addref_if_heap_string(double %r559) #9
  br label %str_addref.done.141

str_addref.done.141:                              ; preds = %str_addref.call.140, %guarded_add.merge.139
  %r1724.rs4i = ptrtoint ptr addrspace(1) %.2234 to i64
  %r1724.rs4o = call i64 asm "", "=r,0"(i64 %r1724.rs4i) #9
  %r1724 = bitcast i64 %r1724.rs4o to double
  store double %r1724, ptr @perry_global_options_worker_ts__7, align 8
  %r1723.rs4i = ptrtoint ptr addrspace(1) %.2234 to i64
  %r1723.rs4o = call i64 asm "", "=r,0"(i64 %r1723.rs4i) #9
  %r1723 = bitcast i64 %r1723.rs4o to double
  %r563 = bitcast double %r1723 to i64
  %r1721.rs4i = ptrtoint ptr addrspace(1) %.2234 to i64
  %r1721.rs4o = call i64 asm "", "=r,0"(i64 %r1721.rs4i) #9
  %r1721 = bitcast i64 %r1721.rs4o to double
  %r1722 = bitcast double %r1721 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1722) #9
  %r564 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r565 = icmp ne i32 %r564, 0
  br i1 %r565, label %gcpoll.142, label %gcpoll.done.143

gcpoll.142:                                       ; preds = %str_addref.done.141
  %statepoint_token78 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.16) ]
  %rs4gc.s7.relocated79 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token78, i32 0, i32 0) ; (%.16, %.16)
  br label %gcpoll.done.143

gcpoll.done.143:                                  ; preds = %gcpoll.142, %str_addref.done.141
  %.17 = phi ptr addrspace(1) [ %rs4gc.s7.relocated79, %gcpoll.142 ], [ %.16, %str_addref.done.141 ]
  br label %for.update.91

streqlit.sso.144:                                 ; preds = %if.else.82
  %r575 = icmp eq i64 %r572, 9221406111934080378
  br i1 %r575, label %streqlit.true.150, label %streqlit.tag.145

streqlit.tag.145:                                 ; preds = %streqlit.sso.144
  %r576 = lshr i64 %r572, 48
  %r577 = icmp eq i64 %r576, 32767
  %r578 = and i64 %r572, 281474976710655
  %r579 = icmp ugt i64 %r578, 4095
  %r580 = and i1 %r577, %r579
  br i1 %r580, label %streqlit.len.146, label %streqlit.false.151

streqlit.len.146:                                 ; preds = %streqlit.tag.145
  %r581 = inttoptr i64 %r578 to ptr
  %r582 = getelementptr inbounds nuw i8, ptr %r581, i64 4
  %r583 = load i32, ptr %r582, align 4
  %r584 = icmp eq i32 %r583, 4
  br i1 %r584, label %streqlit.b0.147, label %streqlit.false.151

streqlit.b0.147:                                  ; preds = %streqlit.len.146
  %r585 = getelementptr inbounds nuw i8, ptr %r581, i64 20
  %r586 = load i8, ptr %r585, align 1
  %r587 = icmp eq i8 %r586, 122
  br i1 %r587, label %streqlit.bl.148, label %streqlit.false.151

streqlit.bl.148:                                  ; preds = %streqlit.b0.147
  %r588 = getelementptr inbounds nuw i8, ptr %r581, i64 23
  %r589 = load i8, ptr %r588, align 1
  %r590 = icmp eq i8 %r589, 111
  br i1 %r590, label %streqlit.slow.149, label %streqlit.false.151

streqlit.slow.149:                                ; preds = %streqlit.bl.148
  %r591 = and i64 %r573, 281474976710655
  %statepoint_token80 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r578, i64 %r591, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9) ]
  %r59281 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token80)
  %rs4gc.s7.relocated82 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 0, i32 0) ; (%.9, %.9)
  %r593 = icmp ne i32 %r59281, 0
  br label %streqlit.merge.152

streqlit.true.150:                                ; preds = %streqlit.sso.144, %if.else.82
  br label %streqlit.merge.152

streqlit.false.151:                               ; preds = %streqlit.bl.148, %streqlit.b0.147, %streqlit.len.146, %streqlit.tag.145
  br label %streqlit.merge.152

streqlit.merge.152:                               ; preds = %streqlit.false.151, %streqlit.true.150, %streqlit.slow.149
  %.18 = phi ptr addrspace(1) [ %.9, %streqlit.true.150 ], [ %rs4gc.s7.relocated82, %streqlit.slow.149 ], [ %.9, %streqlit.false.151 ]
  %r594 = phi i1 [ true, %streqlit.true.150 ], [ false, %streqlit.false.151 ], [ %r593, %streqlit.slow.149 ]
  %r595 = select i1 %r594, i64 9222246136947933188, i64 9222246136947933187
  %r596 = bitcast i64 %r595 to double
  %r597 = icmp eq i64 %r595, 9222246136947933188
  br i1 %r597, label %if.then.153, label %if.else.154

if.then.153:                                      ; preds = %streqlit.merge.152
  %r602.rs4i = ptrtoint ptr addrspace(1) %.18 to i64
  %r602.rs4o = call i64 asm "", "=r,0"(i64 %r602.rs4i) #9
  %r602 = bitcast i64 %r602.rs4o to double
  %r603 = bitcast double %r602 to i64
  %r604 = and i64 %r603, -281474976710656
  %r605 = icmp ult i64 %r604, 9221401712017801216
  %r606 = icmp ugt i64 %r604, 9223090561878065152
  %r607 = or i1 %r605, %r606
  br i1 %r607, label %for.bound_i32.number.156, label %for.bound_i32.merge.158

if.else.154:                                      ; preds = %streqlit.merge.152
  %r853 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r854 = load double, ptr @options_worker_ts_.str.4.handle, align 8
  %r855 = bitcast double %r853 to i64
  %r856 = bitcast double %r854 to i64
  %r857 = icmp eq i64 %r855, %r856
  br i1 %r857, label %streqlit.true.221, label %streqlit.tag.216

if.merge.155:                                     ; preds = %if.merge.226, %for.exit.164
  %r2.4 = phi double [ %r2.5, %for.exit.164 ], [ %r2.6, %if.merge.226 ]
  br label %if.merge.83

for.bound_i32.number.156:                         ; preds = %if.then.153
  %r608 = fcmp oge double %r602, 0xC1E0000000000000
  %r609 = fcmp ole double %r602, 0x41DFFFFFFFC00000
  %r610 = and i1 %r608, %r609
  br i1 %r610, label %for.bound_i32.convert.157, label %for.bound_i32.merge.158

for.bound_i32.convert.157:                        ; preds = %for.bound_i32.number.156
  %r611 = fptosi double %r602 to i32
  %r612 = sitofp i32 %r611 to double
  %r613 = fcmp oeq double %r612, %r602
  br i1 %r613, label %for.counter_i32.range.159, label %for.bound_i32.merge.158

for.bound_i32.merge.158:                          ; preds = %for.counter_i32.convert.160, %for.bound_i32.convert.157, %for.bound_i32.number.156, %if.then.153
  %r601.0 = phi i32 [ %r611, %for.counter_i32.convert.160 ], [ 0, %if.then.153 ], [ %r611, %for.bound_i32.convert.157 ], [ 0, %for.bound_i32.number.156 ]
  %r600.0 = phi i1 [ true, %for.counter_i32.convert.160 ], [ false, %if.then.153 ], [ false, %for.bound_i32.convert.157 ], [ false, %for.bound_i32.number.156 ]
  br label %for.cond.161

for.counter_i32.range.159:                        ; preds = %for.bound_i32.convert.157
  br label %for.counter_i32.convert.160

for.counter_i32.convert.160:                      ; preds = %for.counter_i32.range.159
  br label %for.bound_i32.merge.158

for.cond.161:                                     ; preds = %for.update.163, %for.bound_i32.merge.158
  %.19 = phi ptr addrspace(1) [ %.18, %for.bound_i32.merge.158 ], [ %.26, %for.update.163 ]
  %r599.1 = phi i32 [ 0, %for.bound_i32.merge.158 ], [ %r852, %for.update.163 ]
  %r598.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.158 ], [ %r850, %for.update.163 ]
  %r2.5 = phi double [ 0.000000e+00, %for.bound_i32.merge.158 ], [ %r841, %for.update.163 ]
  br i1 %r600.0, label %for.cond.fast.165, label %for.cond.slow.166

for.body.162:                                     ; preds = %gcpoll.done.171, %for.cond.fast.165
  %.20 = phi ptr addrspace(1) [ %.19, %for.cond.fast.165 ], [ %.22, %gcpoll.done.171 ]
  %r663 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %statepoint_token83 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r663, double 0x7FFC000000000002, double 0.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.20) ]
  %r66484 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token83)
  %rs4gc.s7.relocated85 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token83, i32 0, i32 0) ; (%.20, %.20)
  %r665 = bitcast i64 %r66484 to double
  %rs4gc.b12 = bitcast double %r665 to i64
  %rs4gc.s12 = inttoptr i64 %rs4gc.b12 to ptr addrspace(1)
  %r666.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r666 = call i64 asm "", "=r,0"(i64 %r666.rs4i) #9
  %r667 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r668 = icmp ne i32 %r667, 0
  br i1 %r668, label %shadow.root.barrier.172, label %shadow.root.barrier.done.173

for.update.163:                                   ; preds = %gcpoll.done.215
  %r850 = fadd double %r598.0, 1.000000e+00
  %r852 = add i32 %r599.1, 1
  br label %for.cond.161

for.exit.164:                                     ; preds = %gcpoll.done.171, %for.cond.fast.165
  br label %if.merge.155

for.cond.fast.165:                                ; preds = %for.cond.161
  %r624 = icmp slt i32 %r599.1, %r601.0
  br i1 %r624, label %for.body.162, label %for.exit.164

for.cond.slow.166:                                ; preds = %for.cond.161
  %r626.rs4i = ptrtoint ptr addrspace(1) %.19 to i64
  %r626.rs4o = call i64 asm "", "=r,0"(i64 %r626.rs4i) #9
  %r626 = bitcast i64 %r626.rs4o to double
  %r627 = bitcast double %r626 to i64
  %r628 = lshr i64 %r627, 48
  %r629 = icmp ult i64 %r628, 32761
  %r630 = icmp ugt i64 %r628, 32767
  %r631 = or i1 %r629, %r630
  %r632 = icmp eq i64 %r628, 32766
  %r633 = icmp eq i64 %r627, 9222246136947933185
  %r634 = icmp eq i64 %r627, 9222246136947933186
  %r635 = icmp eq i64 %r627, 9222246136947933187
  %r636 = icmp eq i64 %r627, 9222246136947933188
  %r637 = or i1 %r634, %r635
  %r638 = or i1 %r631, %r632
  %r639 = or i1 %r638, %r633
  %r640 = or i1 %r639, %r637
  %r641 = or i1 %r640, %r636
  br i1 %r641, label %relnum.fast.167, label %relnum.slow.168

relnum.fast.167:                                  ; preds = %for.cond.slow.166
  %r642 = trunc i64 %r627 to i32
  %r643 = sitofp i32 %r642 to double
  %r644 = select i1 %r632, double %r643, double %r626
  %r645 = select i1 %r637, double 0.000000e+00, double %r644
  %r646 = select i1 %r636, double 1.000000e+00, double %r645
  %r647 = bitcast double %r598.0 to i64
  %r648 = lshr i64 %r647, 48
  %r649 = icmp eq i64 %r648, 32766
  %r650 = trunc i64 %r647 to i32
  %r651 = sitofp i32 %r650 to double
  %r652 = select i1 %r649, double %r651, double %r598.0
  %r653 = fcmp olt double %r652, %r646
  %r654 = select i1 %r653, i64 9222246136947933188, i64 9222246136947933187
  %r655 = bitcast i64 %r654 to double
  br label %relnum.merge.169

relnum.slow.168:                                  ; preds = %for.cond.slow.166
  %statepoint_token86 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r598.0, double %r626, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.19) ]
  %r65687 = call double @llvm.experimental.gc.result.f64(token %statepoint_token86)
  %rs4gc.s7.relocated88 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token86, i32 0, i32 0) ; (%.19, %.19)
  br label %relnum.merge.169

relnum.merge.169:                                 ; preds = %relnum.slow.168, %relnum.fast.167
  %.21 = phi ptr addrspace(1) [ %.19, %relnum.fast.167 ], [ %rs4gc.s7.relocated88, %relnum.slow.168 ]
  %r657 = phi double [ %r655, %relnum.fast.167 ], [ %r65687, %relnum.slow.168 ]
  %r658 = bitcast double %r657 to i64
  %r660 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r661 = icmp ne i32 %r660, 0
  br i1 %r661, label %gcpoll.170, label %gcpoll.done.171

gcpoll.170:                                       ; preds = %relnum.merge.169
  %statepoint_token89 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21) ]
  %rs4gc.s7.relocated90 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token89, i32 0, i32 0) ; (%.21, %.21)
  br label %gcpoll.done.171

gcpoll.done.171:                                  ; preds = %gcpoll.170, %relnum.merge.169
  %.22 = phi ptr addrspace(1) [ %rs4gc.s7.relocated90, %gcpoll.170 ], [ %.21, %relnum.merge.169 ]
  %r659 = icmp eq i64 %r658, 9222246136947933188
  br i1 %r659, label %for.body.162, label %for.exit.164

shadow.root.barrier.172:                          ; preds = %for.body.162
  call void @js_write_barrier_root_nanbox(i64 %r666) #9
  br label %shadow.root.barrier.done.173

shadow.root.barrier.done.173:                     ; preds = %shadow.root.barrier.172, %for.body.162
  %r670 = bitcast double %r2.5 to i64
  %rs4gc.s13 = inttoptr i64 %r670 to ptr addrspace(1)
  %r671.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r671 = call i64 asm "", "=r,0"(i64 %r671.rs4i) #9
  %r672 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r673 = icmp ne i32 %r672, 0
  br i1 %r673, label %shadow.root.barrier.174, label %shadow.root.barrier.done.175

shadow.root.barrier.174:                          ; preds = %shadow.root.barrier.done.173
  call void @js_write_barrier_root_nanbox(i64 %r671) #9
  br label %shadow.root.barrier.done.175

shadow.root.barrier.done.175:                     ; preds = %shadow.root.barrier.174, %shadow.root.barrier.done.173
  %r674.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r674.rs4o = call i64 asm "", "=r,0"(i64 %r674.rs4i) #9
  %r674 = bitcast i64 %r674.rs4o to double
  %r675 = bitcast double %r674 to i64
  %r676 = and i64 %r675, 281474976710655
  %r677 = lshr i64 %r675, 48
  %r678 = and i64 %r677, 65533
  %r679 = icmp eq i64 %r678, 32765
  br i1 %r679, label %pget.recv_ok.177, label %pget.recv_other.182

pget.recv_sso.176:                                ; preds = %pget.recv_other.182
  %r818 = lshr i64 %r675, 40
  %r819 = and i64 %r818, 255
  %r820 = uitofp nneg i64 %r819 to double
  br label %pget.recv_merge.180

pget.recv_ok.177:                                 ; preds = %shadow.root.barrier.done.175
  %r686 = icmp eq i64 %r677, 32767
  br i1 %r686, label %pget.strlen_heap.181, label %pget.recv_obj.184

pget.recv_bad.178:                                ; preds = %pget.check_class_ref.183
  %r810 = icmp eq i64 %r675, 9222246136947933185
  %r811 = icmp eq i64 %r675, 9222246136947933186
  %r812 = or i1 %r810, %r811
  br i1 %r812, label %pget.throw_nullish.207, label %pget.recv_undef_return.208

pget.recv_class_ref.179:                          ; preds = %pget.check_class_ref.183
  %r682 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r683 = bitcast double %r682 to i64
  %r684 = and i64 %r683, 281474976710655
  %statepoint_token91 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532880, i64 %r675, i64 %r684, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated85, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r68592 = call double @llvm.experimental.gc.result.f64(token %statepoint_token91)
  %rs4gc.s7.relocated93 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 0, i32 0) ; (%rs4gc.s7.relocated85, %rs4gc.s7.relocated85)
  %rs4gc.s12.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pget.recv_merge.180

pget.recv_merge.180:                              ; preds = %pget.recv_undef_return.208, %pic.merge.199, %pget.strlen_heap.181, %pget.recv_class_ref.179, %pget.recv_sso.176
  %.0240 = phi ptr addrspace(1) [ %rs4gc.s13, %pget.strlen_heap.181 ], [ %.1241, %pic.merge.199 ], [ %rs4gc.s13, %pget.recv_sso.176 ], [ %rs4gc.s13.relocated, %pget.recv_class_ref.179 ], [ %rs4gc.s13.relocated109, %pget.recv_undef_return.208 ]
  %.0237 = phi ptr addrspace(1) [ %rs4gc.s12, %pget.strlen_heap.181 ], [ %.1238, %pic.merge.199 ], [ %rs4gc.s12, %pget.recv_sso.176 ], [ %rs4gc.s12.relocated, %pget.recv_class_ref.179 ], [ %rs4gc.s12.relocated108, %pget.recv_undef_return.208 ]
  %.23 = phi ptr addrspace(1) [ %rs4gc.s7.relocated85, %pget.strlen_heap.181 ], [ %.24, %pic.merge.199 ], [ %rs4gc.s7.relocated85, %pget.recv_sso.176 ], [ %rs4gc.s7.relocated93, %pget.recv_class_ref.179 ], [ %rs4gc.s7.relocated107, %pget.recv_undef_return.208 ]
  %r826 = phi double [ %r809, %pic.merge.199 ], [ %r817106, %pget.recv_undef_return.208 ], [ %r820, %pget.recv_sso.176 ], [ %r68592, %pget.recv_class_ref.179 ], [ %r825, %pget.strlen_heap.181 ]
  %r827.rs4i = ptrtoint ptr addrspace(1) %.0240 to i64
  %r827 = call i64 asm "", "=r,0"(i64 %r827.rs4i) #9
  %r828 = bitcast i64 %r827 to double
  %r829 = and i64 %r827, -281474976710656
  %r830 = icmp ult i64 %r829, 9221401712017801216
  %r831 = icmp ugt i64 %r829, 9223090561878065152
  %r832 = or i1 %r830, %r831
  %r833 = bitcast double %r826 to i64
  %r834 = and i64 %r833, -281474976710656
  %r835 = icmp ult i64 %r834, 9221401712017801216
  %r836 = icmp ugt i64 %r834, 9223090561878065152
  %r837 = or i1 %r835, %r836
  %r838 = and i1 %r832, %r837
  br i1 %r838, label %guarded_add.numeric.209, label %guarded_add.dynamic.210

pget.strlen_heap.181:                             ; preds = %pget.recv_ok.177
  %r821 = icmp ult i64 %r676, 4096
  %r822 = inttoptr i64 %r676 to ptr
  %r823 = select i1 %r821, ptr @perry_null_guard_zero_options_worker_ts, ptr %r822
  %r824 = load i32, ptr %r823, align 4
  %r825 = uitofp i32 %r824 to double
  br label %pget.recv_merge.180

pget.recv_other.182:                              ; preds = %shadow.root.barrier.done.175
  %r680 = icmp eq i64 %r677, 32761
  br i1 %r680, label %pget.recv_sso.176, label %pget.check_class_ref.183

pget.check_class_ref.183:                         ; preds = %pget.recv_other.182
  %r681 = icmp eq i64 %r677, 32766
  br i1 %r681, label %pget.recv_class_ref.179, label %pget.recv_bad.178

pget.recv_obj.184:                                ; preds = %pget.recv_ok.177
  %r687 = icmp ugt i64 %r676, 1048575
  br i1 %r687, label %pic.recv_hdr.200, label %pic.miss.cold.197

pic.hit.185:                                      ; preds = %pic.token.201
  %r712 = getelementptr i64, ptr %r697, i64 1
  %r713 = load i64, ptr %r712, align 8
  %r714 = and i64 %r713, 1073741824
  %r715 = icmp ne i64 %r714, 0
  br i1 %r715, label %pic.hit.overflow.202, label %pic.hit.inline.203

pic.hit.live.186:                                 ; preds = %pic.hit.inline.203
  br label %pic.merge.199

pic.prefix.guard.187:                             ; preds = %pic.token.201
  %r728 = getelementptr i64, ptr %r697, i64 2
  %r729 = load i64, ptr %r728, align 8
  %r730 = icmp ne i64 %r729, 0
  br i1 %r730, label %pic.prefix.meta.188, label %pic.miss.196

pic.prefix.meta.188:                              ; preds = %pic.prefix.guard.187
  %r731 = add nuw nsw i64 %r676, 8
  %r732 = inttoptr i64 %r731 to ptr
  %r733 = load i64, ptr %r732, align 8
  %r734 = icmp ne i64 %r733, 0
  br i1 %r734, label %pic.prefix.token.189, label %pic.miss.196

pic.prefix.token.189:                             ; preds = %pic.prefix.meta.188
  %r735 = inttoptr i64 %r733 to ptr
  %r736 = getelementptr i64, ptr %r735, i64 6
  %r737 = load i64, ptr %r736, align 8
  %r738 = icmp eq i64 %r737, %r729
  br i1 %r738, label %pic.prefix.hit.190, label %pic.miss.196

pic.prefix.hit.190:                               ; preds = %pic.prefix.token.189
  %r739 = getelementptr i64, ptr %r697, i64 1
  %r740 = load i64, ptr %r739, align 8
  %r741 = shl i64 %r740, 3
  %r742 = add nuw nsw i64 %r676, 16
  %r743 = add i64 %r742, %r741
  %r744 = inttoptr i64 %r743 to ptr
  %r745 = load double, ptr %r744, align 8
  br label %pic.merge.199

pic.desc.classify.191:                            ; preds = %pic.recv_hdr.200
  %r701 = and i1 %r691, %r698
  br i1 %r701, label %pic.desc.prefix.guard.192, label %pic.miss.cold.197

pic.desc.prefix.guard.192:                        ; preds = %pic.desc.classify.191
  %r746 = getelementptr i64, ptr %r697, i64 2
  %r747 = load i64, ptr %r746, align 8
  %r748 = icmp ne i64 %r747, 0
  br i1 %r748, label %pic.desc.prefix.meta.193, label %pic.miss.cold.197

pic.desc.prefix.meta.193:                         ; preds = %pic.desc.prefix.guard.192
  %r749 = add nuw nsw i64 %r676, 8
  %r750 = inttoptr i64 %r749 to ptr
  %r751 = load i64, ptr %r750, align 8
  %r752 = icmp ne i64 %r751, 0
  br i1 %r752, label %pic.desc.prefix.token.194, label %pic.miss.cold.197

pic.desc.prefix.token.194:                        ; preds = %pic.desc.prefix.meta.193
  %r753 = inttoptr i64 %r751 to ptr
  %r754 = getelementptr i64, ptr %r753, i64 6
  %r755 = load i64, ptr %r754, align 8
  %r756 = icmp eq i64 %r755, %r747
  br i1 %r756, label %pic.desc.prefix.hit.195, label %pic.miss.cold.197

pic.desc.prefix.hit.195:                          ; preds = %pic.desc.prefix.token.194
  %r757 = getelementptr i64, ptr %r697, i64 1
  %r758 = load i64, ptr %r757, align 8
  %r759 = shl i64 %r758, 3
  %r760 = add nuw nsw i64 %r676, 16
  %r761 = add i64 %r760, %r759
  %r762 = inttoptr i64 %r761 to ptr
  %r763 = load double, ptr %r762, align 8
  br label %pic.merge.199

pic.miss.196:                                     ; preds = %pic.hit.inline.203, %pic.prefix.token.189, %pic.prefix.meta.188, %pic.prefix.guard.187
  %r764 = getelementptr i64, ptr %r697, i64 3
  %r765 = load i64, ptr %r764, align 8
  %r766 = icmp sgt i64 %r765, 0
  br i1 %r766, label %pic.ways.204, label %pic.miss.call.198

pic.miss.cold.197:                                ; preds = %pic.desc.prefix.token.194, %pic.desc.prefix.meta.193, %pic.desc.prefix.guard.192, %pic.desc.classify.191, %pget.recv_obj.184
  br label %pic.miss.call.198

pic.miss.call.198:                                ; preds = %pic.way.load.205, %pic.ways.204, %pic.miss.cold.197, %pic.miss.196
  %r805 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r806 = bitcast double %r805 to i64
  %r807 = and i64 %r806, 281474976710655
  %statepoint_token94 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r676, i64 %r807, ptr @perry_ic_options_worker_ts__17, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated85, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r80895 = call double @llvm.experimental.gc.result.f64(token %statepoint_token94)
  %rs4gc.s7.relocated96 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 0, i32 0) ; (%rs4gc.s7.relocated85, %rs4gc.s7.relocated85)
  %rs4gc.s12.relocated97 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated98 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pic.merge.199

pic.merge.199:                                    ; preds = %pic.way.live.206, %pic.hit.overflow.202, %pic.miss.call.198, %pic.desc.prefix.hit.195, %pic.prefix.hit.190, %pic.hit.live.186
  %.1241 = phi ptr addrspace(1) [ %rs4gc.s13.relocated103, %pic.hit.overflow.202 ], [ %rs4gc.s13.relocated98, %pic.miss.call.198 ], [ %rs4gc.s13, %pic.way.live.206 ], [ %rs4gc.s13, %pic.hit.live.186 ], [ %rs4gc.s13, %pic.prefix.hit.190 ], [ %rs4gc.s13, %pic.desc.prefix.hit.195 ]
  %.1238 = phi ptr addrspace(1) [ %rs4gc.s12.relocated102, %pic.hit.overflow.202 ], [ %rs4gc.s12.relocated97, %pic.miss.call.198 ], [ %rs4gc.s12, %pic.way.live.206 ], [ %rs4gc.s12, %pic.hit.live.186 ], [ %rs4gc.s12, %pic.prefix.hit.190 ], [ %rs4gc.s12, %pic.desc.prefix.hit.195 ]
  %.24 = phi ptr addrspace(1) [ %rs4gc.s7.relocated101, %pic.hit.overflow.202 ], [ %rs4gc.s7.relocated96, %pic.miss.call.198 ], [ %rs4gc.s7.relocated85, %pic.way.live.206 ], [ %rs4gc.s7.relocated85, %pic.hit.live.186 ], [ %rs4gc.s7.relocated85, %pic.prefix.hit.190 ], [ %rs4gc.s7.relocated85, %pic.desc.prefix.hit.195 ]
  %r809 = phi double [ %r725, %pic.hit.live.186 ], [ %r720100, %pic.hit.overflow.202 ], [ %r745, %pic.prefix.hit.190 ], [ %r763, %pic.desc.prefix.hit.195 ], [ %r802, %pic.way.live.206 ], [ %r80895, %pic.miss.call.198 ]
  br label %pget.recv_merge.180

pic.recv_hdr.200:                                 ; preds = %pget.recv_obj.184
  %r688 = sub nuw nsw i64 %r676, 8
  %r689 = inttoptr i64 %r688 to ptr
  %r690 = load i8, ptr %r689, align 1
  %r691 = icmp eq i8 %r690, 2
  %r692 = sub nuw nsw i64 %r676, 6
  %r693 = inttoptr i64 %r692 to ptr
  %r694 = load i16, ptr %r693, align 2
  %r695 = and i16 %r694, 2048
  %r696 = icmp eq i16 %r695, 0
  %r697 = load ptr, ptr @perry_ic_options_worker_ts__17, align 8
  %r698 = icmp ne ptr %r697, null
  %r699 = and i1 %r691, %r696
  %r700 = and i1 %r699, %r698
  br i1 %r700, label %pic.token.201, label %pic.desc.classify.191

pic.token.201:                                    ; preds = %pic.recv_hdr.200
  %r702 = add nuw nsw i64 %r676, 4
  %r703 = inttoptr i64 %r702 to ptr
  %r704 = load i32, ptr %r703, align 4
  %r705 = zext i32 %r704 to i64
  %r706 = or i64 %r705, 4611686018427387904
  %r707 = icmp ne i32 %r704, 0
  %r708 = getelementptr i64, ptr %r697, i64 0
  %r709 = load i64, ptr %r708, align 8
  %r710 = icmp eq i64 %r706, %r709
  %r711 = and i1 %r710, %r707
  br i1 %r711, label %pic.hit.185, label %pic.prefix.guard.187

pic.hit.overflow.202:                             ; preds = %pic.hit.185
  %r716 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r717 = bitcast double %r716 to i64
  %r718 = and i64 %r717, 281474976710655
  %r719 = trunc i64 %r713 to i32
  %statepoint_token99 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r676, i64 %r718, i32 %r719, ptr @perry_ic_options_worker_ts__17, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated85, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r720100 = call double @llvm.experimental.gc.result.f64(token %statepoint_token99)
  %rs4gc.s7.relocated101 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 0, i32 0) ; (%rs4gc.s7.relocated85, %rs4gc.s7.relocated85)
  %rs4gc.s12.relocated102 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pic.merge.199

pic.hit.inline.203:                               ; preds = %pic.hit.185
  %r721 = shl i64 %r713, 3
  %r722 = add nuw nsw i64 %r676, 16
  %r723 = add i64 %r722, %r721
  %r724 = inttoptr i64 %r723 to ptr
  %r725 = load double, ptr %r724, align 8
  %r726 = bitcast double %r725 to i64
  %r727 = icmp eq i64 %r726, 9222246136947933200
  br i1 %r727, label %pic.miss.196, label %pic.hit.live.186

pic.ways.204:                                     ; preds = %pic.miss.196
  %r767 = getelementptr i64, ptr %r697, i64 4
  %r768 = load i64, ptr %r767, align 8
  %r769 = icmp eq i64 %r768, %r706
  %r770 = getelementptr i64, ptr %r697, i64 5
  %r771 = load i64, ptr %r770, align 8
  %r772 = select i1 %r769, i64 %r771, i64 0
  %r773 = getelementptr i64, ptr %r697, i64 6
  %r774 = load i64, ptr %r773, align 8
  %r775 = icmp eq i64 %r774, %r706
  %r776 = getelementptr i64, ptr %r697, i64 7
  %r777 = load i64, ptr %r776, align 8
  %r778 = select i1 %r775, i64 %r777, i64 0
  %r779 = getelementptr i64, ptr %r697, i64 8
  %r780 = load i64, ptr %r779, align 8
  %r781 = icmp eq i64 %r780, %r706
  %r782 = getelementptr i64, ptr %r697, i64 9
  %r783 = load i64, ptr %r782, align 8
  %r784 = select i1 %r781, i64 %r783, i64 0
  %r785 = getelementptr i64, ptr %r697, i64 10
  %r786 = load i64, ptr %r785, align 8
  %r787 = icmp eq i64 %r786, %r706
  %r788 = getelementptr i64, ptr %r697, i64 11
  %r789 = load i64, ptr %r788, align 8
  %r790 = select i1 %r787, i64 %r789, i64 0
  %r791 = or i1 %r769, %r775
  %r792 = select i1 %r769, i64 %r772, i64 %r778
  %r793 = or i1 %r781, %r787
  %r794 = select i1 %r781, i64 %r784, i64 %r790
  %r795 = or i1 %r791, %r793
  %r796 = select i1 %r791, i64 %r792, i64 %r794
  %r797 = and i1 %r707, %r795
  br i1 %r797, label %pic.way.load.205, label %pic.miss.call.198

pic.way.load.205:                                 ; preds = %pic.ways.204
  %r798 = shl i64 %r796, 3
  %r799 = add nuw nsw i64 %r676, 16
  %r800 = add i64 %r799, %r798
  %r801 = inttoptr i64 %r800 to ptr
  %r802 = load double, ptr %r801, align 8
  %r803 = bitcast double %r802 to i64
  %r804 = icmp eq i64 %r803, 9222246136947933200
  br i1 %r804, label %pic.miss.call.198, label %pic.way.live.206

pic.way.live.206:                                 ; preds = %pic.way.load.205
  br label %pic.merge.199

pget.throw_nullish.207:                           ; preds = %pget.recv_bad.178
  %r813 = zext i1 %r811 to i32
  %statepoint_token104 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r813, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.208:                       ; preds = %pget.recv_bad.178
  %r814 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r815 = bitcast double %r814 to i64
  %r816 = and i64 %r815, 281474976710655
  %statepoint_token105 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r675, i64 %r816, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated85, ptr addrspace(1) %rs4gc.s12, ptr addrspace(1) %rs4gc.s13) ]
  %r817106 = call double @llvm.experimental.gc.result.f64(token %statepoint_token105)
  %rs4gc.s7.relocated107 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 0, i32 0) ; (%rs4gc.s7.relocated85, %rs4gc.s7.relocated85)
  %rs4gc.s12.relocated108 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 1, i32 1) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13.relocated109 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  br label %pget.recv_merge.180

guarded_add.numeric.209:                          ; preds = %pget.recv_merge.180
  %r839 = fadd double %r828, %r826
  br label %guarded_add.merge.211

guarded_add.dynamic.210:                          ; preds = %pget.recv_merge.180
  %statepoint_token110 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r828, double %r826, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.23, ptr addrspace(1) %.0237) ]
  %r840111 = call double @llvm.experimental.gc.result.f64(token %statepoint_token110)
  %rs4gc.s7.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 0, i32 0) ; (%.23, %.23)
  %rs4gc.s12.relocated113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 1, i32 1) ; (%.0237, %.0237)
  br label %guarded_add.merge.211

guarded_add.merge.211:                            ; preds = %guarded_add.dynamic.210, %guarded_add.numeric.209
  %.2239 = phi ptr addrspace(1) [ %.0237, %guarded_add.numeric.209 ], [ %rs4gc.s12.relocated113, %guarded_add.dynamic.210 ]
  %.25 = phi ptr addrspace(1) [ %.23, %guarded_add.numeric.209 ], [ %rs4gc.s7.relocated112, %guarded_add.dynamic.210 ]
  %r841 = phi double [ %r839, %guarded_add.numeric.209 ], [ %r840111, %guarded_add.dynamic.210 ]
  %r842.rs4i = ptrtoint ptr addrspace(1) %.2239 to i64
  %r842.rs4o = call i64 asm "", "=r,0"(i64 %r842.rs4i) #9
  %r842 = bitcast i64 %r842.rs4o to double
  %r843 = bitcast double %r842 to i64
  %r844 = and i64 %r843, -281474976710656
  %r845 = icmp ne i64 %r844, 9223090561878065152
  br i1 %r845, label %str_addref.done.213, label %str_addref.call.212

str_addref.call.212:                              ; preds = %guarded_add.merge.211
  call void @js_string_addref_if_heap_string(double %r842) #9
  br label %str_addref.done.213

str_addref.done.213:                              ; preds = %str_addref.call.212, %guarded_add.merge.211
  %r1720.rs4i = ptrtoint ptr addrspace(1) %.2239 to i64
  %r1720.rs4o = call i64 asm "", "=r,0"(i64 %r1720.rs4i) #9
  %r1720 = bitcast i64 %r1720.rs4o to double
  store double %r1720, ptr @perry_global_options_worker_ts__7, align 8
  %r1719.rs4i = ptrtoint ptr addrspace(1) %.2239 to i64
  %r1719.rs4o = call i64 asm "", "=r,0"(i64 %r1719.rs4i) #9
  %r1719 = bitcast i64 %r1719.rs4o to double
  %r846 = bitcast double %r1719 to i64
  %r1717.rs4i = ptrtoint ptr addrspace(1) %.2239 to i64
  %r1717.rs4o = call i64 asm "", "=r,0"(i64 %r1717.rs4i) #9
  %r1717 = bitcast i64 %r1717.rs4o to double
  %r1718 = bitcast double %r1717 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1718) #9
  %r847 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r848 = icmp ne i32 %r847, 0
  br i1 %r848, label %gcpoll.214, label %gcpoll.done.215

gcpoll.214:                                       ; preds = %str_addref.done.213
  %statepoint_token114 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.25) ]
  %rs4gc.s7.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token114, i32 0, i32 0) ; (%.25, %.25)
  br label %gcpoll.done.215

gcpoll.done.215:                                  ; preds = %gcpoll.214, %str_addref.done.213
  %.26 = phi ptr addrspace(1) [ %rs4gc.s7.relocated115, %gcpoll.214 ], [ %.25, %str_addref.done.213 ]
  br label %for.update.163

streqlit.tag.216:                                 ; preds = %if.else.154
  %r858 = lshr i64 %r855, 48
  %r859 = icmp eq i64 %r858, 32767
  %r860 = and i64 %r855, 281474976710655
  %r861 = icmp ugt i64 %r860, 4095
  %r862 = and i1 %r859, %r861
  br i1 %r862, label %streqlit.len.217, label %streqlit.false.222

streqlit.len.217:                                 ; preds = %streqlit.tag.216
  %r863 = inttoptr i64 %r860 to ptr
  %r864 = getelementptr inbounds nuw i8, ptr %r863, i64 4
  %r865 = load i32, ptr %r864, align 4
  %r866 = icmp eq i32 %r865, 6
  br i1 %r866, label %streqlit.b0.218, label %streqlit.false.222

streqlit.b0.218:                                  ; preds = %streqlit.len.217
  %r867 = getelementptr inbounds nuw i8, ptr %r863, i64 20
  %r868 = load i8, ptr %r867, align 1
  %r869 = icmp eq i8 %r868, 112
  br i1 %r869, label %streqlit.bl.219, label %streqlit.false.222

streqlit.bl.219:                                  ; preds = %streqlit.b0.218
  %r870 = getelementptr inbounds nuw i8, ptr %r863, i64 25
  %r871 = load i8, ptr %r870, align 1
  %r872 = icmp eq i8 %r871, 121
  br i1 %r872, label %streqlit.slow.220, label %streqlit.false.222

streqlit.slow.220:                                ; preds = %streqlit.bl.219
  %r873 = and i64 %r856, 281474976710655
  %statepoint_token116 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r860, i64 %r873, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.18) ]
  %r874117 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token116)
  %rs4gc.s7.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 0, i32 0) ; (%.18, %.18)
  %r875 = icmp ne i32 %r874117, 0
  br label %streqlit.merge.223

streqlit.true.221:                                ; preds = %if.else.154
  br label %streqlit.merge.223

streqlit.false.222:                               ; preds = %streqlit.bl.219, %streqlit.b0.218, %streqlit.len.217, %streqlit.tag.216
  br label %streqlit.merge.223

streqlit.merge.223:                               ; preds = %streqlit.false.222, %streqlit.true.221, %streqlit.slow.220
  %.27 = phi ptr addrspace(1) [ %.18, %streqlit.true.221 ], [ %rs4gc.s7.relocated118, %streqlit.slow.220 ], [ %.18, %streqlit.false.222 ]
  %r876 = phi i1 [ true, %streqlit.true.221 ], [ false, %streqlit.false.222 ], [ %r875, %streqlit.slow.220 ]
  %r877 = select i1 %r876, i64 9222246136947933188, i64 9222246136947933187
  %r878 = bitcast i64 %r877 to double
  %r879 = icmp eq i64 %r877, 9222246136947933188
  br i1 %r879, label %if.then.224, label %if.else.225

if.then.224:                                      ; preds = %streqlit.merge.223
  %r884.rs4i = ptrtoint ptr addrspace(1) %.27 to i64
  %r884.rs4o = call i64 asm "", "=r,0"(i64 %r884.rs4i) #9
  %r884 = bitcast i64 %r884.rs4o to double
  %r885 = bitcast double %r884 to i64
  %r886 = and i64 %r885, -281474976710656
  %r887 = icmp ult i64 %r886, 9221401712017801216
  %r888 = icmp ugt i64 %r886, 9223090561878065152
  %r889 = or i1 %r887, %r888
  br i1 %r889, label %for.bound_i32.number.227, label %for.bound_i32.merge.229

if.else.225:                                      ; preds = %streqlit.merge.223
  %r1135 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r1136 = load double, ptr @options_worker_ts_.str.5.handle, align 8
  %r1137 = bitcast double %r1135 to i64
  %r1138 = bitcast double %r1136 to i64
  %r1139 = icmp eq i64 %r1137, %r1138
  br i1 %r1139, label %streqlit.true.293, label %streqlit.sso.287

if.merge.226:                                     ; preds = %if.merge.298, %for.exit.235
  %r2.6 = phi double [ %r2.7, %for.exit.235 ], [ %r2.8, %if.merge.298 ]
  br label %if.merge.155

for.bound_i32.number.227:                         ; preds = %if.then.224
  %r890 = fcmp oge double %r884, 0xC1E0000000000000
  %r891 = fcmp ole double %r884, 0x41DFFFFFFFC00000
  %r892 = and i1 %r890, %r891
  br i1 %r892, label %for.bound_i32.convert.228, label %for.bound_i32.merge.229

for.bound_i32.convert.228:                        ; preds = %for.bound_i32.number.227
  %r893 = fptosi double %r884 to i32
  %r894 = sitofp i32 %r893 to double
  %r895 = fcmp oeq double %r894, %r884
  br i1 %r895, label %for.counter_i32.range.230, label %for.bound_i32.merge.229

for.bound_i32.merge.229:                          ; preds = %for.counter_i32.convert.231, %for.bound_i32.convert.228, %for.bound_i32.number.227, %if.then.224
  %r883.0 = phi i32 [ %r893, %for.counter_i32.convert.231 ], [ 0, %if.then.224 ], [ %r893, %for.bound_i32.convert.228 ], [ 0, %for.bound_i32.number.227 ]
  %r882.0 = phi i1 [ true, %for.counter_i32.convert.231 ], [ false, %if.then.224 ], [ false, %for.bound_i32.convert.228 ], [ false, %for.bound_i32.number.227 ]
  br label %for.cond.232

for.counter_i32.range.230:                        ; preds = %for.bound_i32.convert.228
  br label %for.counter_i32.convert.231

for.counter_i32.convert.231:                      ; preds = %for.counter_i32.range.230
  br label %for.bound_i32.merge.229

for.cond.232:                                     ; preds = %for.update.234, %for.bound_i32.merge.229
  %.28 = phi ptr addrspace(1) [ %.27, %for.bound_i32.merge.229 ], [ %.35, %for.update.234 ]
  %r881.1 = phi i32 [ 0, %for.bound_i32.merge.229 ], [ %r1134, %for.update.234 ]
  %r880.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.229 ], [ %r1132, %for.update.234 ]
  %r2.7 = phi double [ 0.000000e+00, %for.bound_i32.merge.229 ], [ %r1123, %for.update.234 ]
  br i1 %r882.0, label %for.cond.fast.236, label %for.cond.slow.237

for.body.233:                                     ; preds = %gcpoll.done.242, %for.cond.fast.236
  %.29 = phi ptr addrspace(1) [ %.28, %for.cond.fast.236 ], [ %.31, %gcpoll.done.242 ]
  %r945 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %statepoint_token119 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r945, double 0x7FFC000000000002, double 2.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.29) ]
  %r946120 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token119)
  %rs4gc.s7.relocated121 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 0, i32 0) ; (%.29, %.29)
  %r947 = bitcast i64 %r946120 to double
  %rs4gc.b14 = bitcast double %r947 to i64
  %rs4gc.s14 = inttoptr i64 %rs4gc.b14 to ptr addrspace(1)
  %r948.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r948 = call i64 asm "", "=r,0"(i64 %r948.rs4i) #9
  %r949 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r950 = icmp ne i32 %r949, 0
  br i1 %r950, label %shadow.root.barrier.243, label %shadow.root.barrier.done.244

for.update.234:                                   ; preds = %gcpoll.done.286
  %r1132 = fadd double %r880.0, 1.000000e+00
  %r1134 = add i32 %r881.1, 1
  br label %for.cond.232

for.exit.235:                                     ; preds = %gcpoll.done.242, %for.cond.fast.236
  br label %if.merge.226

for.cond.fast.236:                                ; preds = %for.cond.232
  %r906 = icmp slt i32 %r881.1, %r883.0
  br i1 %r906, label %for.body.233, label %for.exit.235

for.cond.slow.237:                                ; preds = %for.cond.232
  %r908.rs4i = ptrtoint ptr addrspace(1) %.28 to i64
  %r908.rs4o = call i64 asm "", "=r,0"(i64 %r908.rs4i) #9
  %r908 = bitcast i64 %r908.rs4o to double
  %r909 = bitcast double %r908 to i64
  %r910 = lshr i64 %r909, 48
  %r911 = icmp ult i64 %r910, 32761
  %r912 = icmp ugt i64 %r910, 32767
  %r913 = or i1 %r911, %r912
  %r914 = icmp eq i64 %r910, 32766
  %r915 = icmp eq i64 %r909, 9222246136947933185
  %r916 = icmp eq i64 %r909, 9222246136947933186
  %r917 = icmp eq i64 %r909, 9222246136947933187
  %r918 = icmp eq i64 %r909, 9222246136947933188
  %r919 = or i1 %r916, %r917
  %r920 = or i1 %r913, %r914
  %r921 = or i1 %r920, %r915
  %r922 = or i1 %r921, %r919
  %r923 = or i1 %r922, %r918
  br i1 %r923, label %relnum.fast.238, label %relnum.slow.239

relnum.fast.238:                                  ; preds = %for.cond.slow.237
  %r924 = trunc i64 %r909 to i32
  %r925 = sitofp i32 %r924 to double
  %r926 = select i1 %r914, double %r925, double %r908
  %r927 = select i1 %r919, double 0.000000e+00, double %r926
  %r928 = select i1 %r918, double 1.000000e+00, double %r927
  %r929 = bitcast double %r880.0 to i64
  %r930 = lshr i64 %r929, 48
  %r931 = icmp eq i64 %r930, 32766
  %r932 = trunc i64 %r929 to i32
  %r933 = sitofp i32 %r932 to double
  %r934 = select i1 %r931, double %r933, double %r880.0
  %r935 = fcmp olt double %r934, %r928
  %r936 = select i1 %r935, i64 9222246136947933188, i64 9222246136947933187
  %r937 = bitcast i64 %r936 to double
  br label %relnum.merge.240

relnum.slow.239:                                  ; preds = %for.cond.slow.237
  %statepoint_token122 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r880.0, double %r908, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.28) ]
  %r938123 = call double @llvm.experimental.gc.result.f64(token %statepoint_token122)
  %rs4gc.s7.relocated124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token122, i32 0, i32 0) ; (%.28, %.28)
  br label %relnum.merge.240

relnum.merge.240:                                 ; preds = %relnum.slow.239, %relnum.fast.238
  %.30 = phi ptr addrspace(1) [ %.28, %relnum.fast.238 ], [ %rs4gc.s7.relocated124, %relnum.slow.239 ]
  %r939 = phi double [ %r937, %relnum.fast.238 ], [ %r938123, %relnum.slow.239 ]
  %r940 = bitcast double %r939 to i64
  %r942 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r943 = icmp ne i32 %r942, 0
  br i1 %r943, label %gcpoll.241, label %gcpoll.done.242

gcpoll.241:                                       ; preds = %relnum.merge.240
  %statepoint_token125 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.30) ]
  %rs4gc.s7.relocated126 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 0, i32 0) ; (%.30, %.30)
  br label %gcpoll.done.242

gcpoll.done.242:                                  ; preds = %gcpoll.241, %relnum.merge.240
  %.31 = phi ptr addrspace(1) [ %rs4gc.s7.relocated126, %gcpoll.241 ], [ %.30, %relnum.merge.240 ]
  %r941 = icmp eq i64 %r940, 9222246136947933188
  br i1 %r941, label %for.body.233, label %for.exit.235

shadow.root.barrier.243:                          ; preds = %for.body.233
  call void @js_write_barrier_root_nanbox(i64 %r948) #9
  br label %shadow.root.barrier.done.244

shadow.root.barrier.done.244:                     ; preds = %shadow.root.barrier.243, %for.body.233
  %r952 = bitcast double %r2.7 to i64
  %rs4gc.s15 = inttoptr i64 %r952 to ptr addrspace(1)
  %r953.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r953 = call i64 asm "", "=r,0"(i64 %r953.rs4i) #9
  %r954 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r955 = icmp ne i32 %r954, 0
  br i1 %r955, label %shadow.root.barrier.245, label %shadow.root.barrier.done.246

shadow.root.barrier.245:                          ; preds = %shadow.root.barrier.done.244
  call void @js_write_barrier_root_nanbox(i64 %r953) #9
  br label %shadow.root.barrier.done.246

shadow.root.barrier.done.246:                     ; preds = %shadow.root.barrier.245, %shadow.root.barrier.done.244
  %r956.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r956.rs4o = call i64 asm "", "=r,0"(i64 %r956.rs4i) #9
  %r956 = bitcast i64 %r956.rs4o to double
  %r957 = bitcast double %r956 to i64
  %r958 = and i64 %r957, 281474976710655
  %r959 = lshr i64 %r957, 48
  %r960 = and i64 %r959, 65533
  %r961 = icmp eq i64 %r960, 32765
  br i1 %r961, label %pget.recv_ok.248, label %pget.recv_other.253

pget.recv_sso.247:                                ; preds = %pget.recv_other.253
  %r1100 = lshr i64 %r957, 40
  %r1101 = and i64 %r1100, 255
  %r1102 = uitofp nneg i64 %r1101 to double
  br label %pget.recv_merge.251

pget.recv_ok.248:                                 ; preds = %shadow.root.barrier.done.246
  %r968 = icmp eq i64 %r959, 32767
  br i1 %r968, label %pget.strlen_heap.252, label %pget.recv_obj.255

pget.recv_bad.249:                                ; preds = %pget.check_class_ref.254
  %r1092 = icmp eq i64 %r957, 9222246136947933185
  %r1093 = icmp eq i64 %r957, 9222246136947933186
  %r1094 = or i1 %r1092, %r1093
  br i1 %r1094, label %pget.throw_nullish.278, label %pget.recv_undef_return.279

pget.recv_class_ref.250:                          ; preds = %pget.check_class_ref.254
  %r964 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r965 = bitcast double %r964 to i64
  %r966 = and i64 %r965, 281474976710655
  %statepoint_token127 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532882, i64 %r957, i64 %r966, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated121, ptr addrspace(1) %rs4gc.s14, ptr addrspace(1) %rs4gc.s15) ]
  %r967128 = call double @llvm.experimental.gc.result.f64(token %statepoint_token127)
  %rs4gc.s7.relocated129 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 0, i32 0) ; (%rs4gc.s7.relocated121, %rs4gc.s7.relocated121)
  %rs4gc.s14.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 1, i32 1) ; (%rs4gc.s14, %rs4gc.s14)
  %rs4gc.s15.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 2, i32 2) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.251

pget.recv_merge.251:                              ; preds = %pget.recv_undef_return.279, %pic.merge.270, %pget.strlen_heap.252, %pget.recv_class_ref.250, %pget.recv_sso.247
  %.0245 = phi ptr addrspace(1) [ %rs4gc.s15, %pget.strlen_heap.252 ], [ %.1246, %pic.merge.270 ], [ %rs4gc.s15, %pget.recv_sso.247 ], [ %rs4gc.s15.relocated, %pget.recv_class_ref.250 ], [ %rs4gc.s15.relocated145, %pget.recv_undef_return.279 ]
  %.0242 = phi ptr addrspace(1) [ %rs4gc.s14, %pget.strlen_heap.252 ], [ %.1243, %pic.merge.270 ], [ %rs4gc.s14, %pget.recv_sso.247 ], [ %rs4gc.s14.relocated, %pget.recv_class_ref.250 ], [ %rs4gc.s14.relocated144, %pget.recv_undef_return.279 ]
  %.32 = phi ptr addrspace(1) [ %rs4gc.s7.relocated121, %pget.strlen_heap.252 ], [ %.33, %pic.merge.270 ], [ %rs4gc.s7.relocated121, %pget.recv_sso.247 ], [ %rs4gc.s7.relocated129, %pget.recv_class_ref.250 ], [ %rs4gc.s7.relocated143, %pget.recv_undef_return.279 ]
  %r1108 = phi double [ %r1091, %pic.merge.270 ], [ %r1099142, %pget.recv_undef_return.279 ], [ %r1102, %pget.recv_sso.247 ], [ %r967128, %pget.recv_class_ref.250 ], [ %r1107, %pget.strlen_heap.252 ]
  %r1109.rs4i = ptrtoint ptr addrspace(1) %.0245 to i64
  %r1109 = call i64 asm "", "=r,0"(i64 %r1109.rs4i) #9
  %r1110 = bitcast i64 %r1109 to double
  %r1111 = and i64 %r1109, -281474976710656
  %r1112 = icmp ult i64 %r1111, 9221401712017801216
  %r1113 = icmp ugt i64 %r1111, 9223090561878065152
  %r1114 = or i1 %r1112, %r1113
  %r1115 = bitcast double %r1108 to i64
  %r1116 = and i64 %r1115, -281474976710656
  %r1117 = icmp ult i64 %r1116, 9221401712017801216
  %r1118 = icmp ugt i64 %r1116, 9223090561878065152
  %r1119 = or i1 %r1117, %r1118
  %r1120 = and i1 %r1114, %r1119
  br i1 %r1120, label %guarded_add.numeric.280, label %guarded_add.dynamic.281

pget.strlen_heap.252:                             ; preds = %pget.recv_ok.248
  %r1103 = icmp ult i64 %r958, 4096
  %r1104 = inttoptr i64 %r958 to ptr
  %r1105 = select i1 %r1103, ptr @perry_null_guard_zero_options_worker_ts, ptr %r1104
  %r1106 = load i32, ptr %r1105, align 4
  %r1107 = uitofp i32 %r1106 to double
  br label %pget.recv_merge.251

pget.recv_other.253:                              ; preds = %shadow.root.barrier.done.246
  %r962 = icmp eq i64 %r959, 32761
  br i1 %r962, label %pget.recv_sso.247, label %pget.check_class_ref.254

pget.check_class_ref.254:                         ; preds = %pget.recv_other.253
  %r963 = icmp eq i64 %r959, 32766
  br i1 %r963, label %pget.recv_class_ref.250, label %pget.recv_bad.249

pget.recv_obj.255:                                ; preds = %pget.recv_ok.248
  %r969 = icmp ugt i64 %r958, 1048575
  br i1 %r969, label %pic.recv_hdr.271, label %pic.miss.cold.268

pic.hit.256:                                      ; preds = %pic.token.272
  %r994 = getelementptr i64, ptr %r979, i64 1
  %r995 = load i64, ptr %r994, align 8
  %r996 = and i64 %r995, 1073741824
  %r997 = icmp ne i64 %r996, 0
  br i1 %r997, label %pic.hit.overflow.273, label %pic.hit.inline.274

pic.hit.live.257:                                 ; preds = %pic.hit.inline.274
  br label %pic.merge.270

pic.prefix.guard.258:                             ; preds = %pic.token.272
  %r1010 = getelementptr i64, ptr %r979, i64 2
  %r1011 = load i64, ptr %r1010, align 8
  %r1012 = icmp ne i64 %r1011, 0
  br i1 %r1012, label %pic.prefix.meta.259, label %pic.miss.267

pic.prefix.meta.259:                              ; preds = %pic.prefix.guard.258
  %r1013 = add nuw nsw i64 %r958, 8
  %r1014 = inttoptr i64 %r1013 to ptr
  %r1015 = load i64, ptr %r1014, align 8
  %r1016 = icmp ne i64 %r1015, 0
  br i1 %r1016, label %pic.prefix.token.260, label %pic.miss.267

pic.prefix.token.260:                             ; preds = %pic.prefix.meta.259
  %r1017 = inttoptr i64 %r1015 to ptr
  %r1018 = getelementptr i64, ptr %r1017, i64 6
  %r1019 = load i64, ptr %r1018, align 8
  %r1020 = icmp eq i64 %r1019, %r1011
  br i1 %r1020, label %pic.prefix.hit.261, label %pic.miss.267

pic.prefix.hit.261:                               ; preds = %pic.prefix.token.260
  %r1021 = getelementptr i64, ptr %r979, i64 1
  %r1022 = load i64, ptr %r1021, align 8
  %r1023 = shl i64 %r1022, 3
  %r1024 = add nuw nsw i64 %r958, 16
  %r1025 = add i64 %r1024, %r1023
  %r1026 = inttoptr i64 %r1025 to ptr
  %r1027 = load double, ptr %r1026, align 8
  br label %pic.merge.270

pic.desc.classify.262:                            ; preds = %pic.recv_hdr.271
  %r983 = and i1 %r973, %r980
  br i1 %r983, label %pic.desc.prefix.guard.263, label %pic.miss.cold.268

pic.desc.prefix.guard.263:                        ; preds = %pic.desc.classify.262
  %r1028 = getelementptr i64, ptr %r979, i64 2
  %r1029 = load i64, ptr %r1028, align 8
  %r1030 = icmp ne i64 %r1029, 0
  br i1 %r1030, label %pic.desc.prefix.meta.264, label %pic.miss.cold.268

pic.desc.prefix.meta.264:                         ; preds = %pic.desc.prefix.guard.263
  %r1031 = add nuw nsw i64 %r958, 8
  %r1032 = inttoptr i64 %r1031 to ptr
  %r1033 = load i64, ptr %r1032, align 8
  %r1034 = icmp ne i64 %r1033, 0
  br i1 %r1034, label %pic.desc.prefix.token.265, label %pic.miss.cold.268

pic.desc.prefix.token.265:                        ; preds = %pic.desc.prefix.meta.264
  %r1035 = inttoptr i64 %r1033 to ptr
  %r1036 = getelementptr i64, ptr %r1035, i64 6
  %r1037 = load i64, ptr %r1036, align 8
  %r1038 = icmp eq i64 %r1037, %r1029
  br i1 %r1038, label %pic.desc.prefix.hit.266, label %pic.miss.cold.268

pic.desc.prefix.hit.266:                          ; preds = %pic.desc.prefix.token.265
  %r1039 = getelementptr i64, ptr %r979, i64 1
  %r1040 = load i64, ptr %r1039, align 8
  %r1041 = shl i64 %r1040, 3
  %r1042 = add nuw nsw i64 %r958, 16
  %r1043 = add i64 %r1042, %r1041
  %r1044 = inttoptr i64 %r1043 to ptr
  %r1045 = load double, ptr %r1044, align 8
  br label %pic.merge.270

pic.miss.267:                                     ; preds = %pic.hit.inline.274, %pic.prefix.token.260, %pic.prefix.meta.259, %pic.prefix.guard.258
  %r1046 = getelementptr i64, ptr %r979, i64 3
  %r1047 = load i64, ptr %r1046, align 8
  %r1048 = icmp sgt i64 %r1047, 0
  br i1 %r1048, label %pic.ways.275, label %pic.miss.call.269

pic.miss.cold.268:                                ; preds = %pic.desc.prefix.token.265, %pic.desc.prefix.meta.264, %pic.desc.prefix.guard.263, %pic.desc.classify.262, %pget.recv_obj.255
  br label %pic.miss.call.269

pic.miss.call.269:                                ; preds = %pic.way.load.276, %pic.ways.275, %pic.miss.cold.268, %pic.miss.267
  %r1087 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1088 = bitcast double %r1087 to i64
  %r1089 = and i64 %r1088, 281474976710655
  %statepoint_token130 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r958, i64 %r1089, ptr @perry_ic_options_worker_ts__19, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated121, ptr addrspace(1) %rs4gc.s14, ptr addrspace(1) %rs4gc.s15) ]
  %r1090131 = call double @llvm.experimental.gc.result.f64(token %statepoint_token130)
  %rs4gc.s7.relocated132 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token130, i32 0, i32 0) ; (%rs4gc.s7.relocated121, %rs4gc.s7.relocated121)
  %rs4gc.s14.relocated133 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token130, i32 1, i32 1) ; (%rs4gc.s14, %rs4gc.s14)
  %rs4gc.s15.relocated134 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token130, i32 2, i32 2) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pic.merge.270

pic.merge.270:                                    ; preds = %pic.way.live.277, %pic.hit.overflow.273, %pic.miss.call.269, %pic.desc.prefix.hit.266, %pic.prefix.hit.261, %pic.hit.live.257
  %.1246 = phi ptr addrspace(1) [ %rs4gc.s15.relocated139, %pic.hit.overflow.273 ], [ %rs4gc.s15.relocated134, %pic.miss.call.269 ], [ %rs4gc.s15, %pic.way.live.277 ], [ %rs4gc.s15, %pic.hit.live.257 ], [ %rs4gc.s15, %pic.prefix.hit.261 ], [ %rs4gc.s15, %pic.desc.prefix.hit.266 ]
  %.1243 = phi ptr addrspace(1) [ %rs4gc.s14.relocated138, %pic.hit.overflow.273 ], [ %rs4gc.s14.relocated133, %pic.miss.call.269 ], [ %rs4gc.s14, %pic.way.live.277 ], [ %rs4gc.s14, %pic.hit.live.257 ], [ %rs4gc.s14, %pic.prefix.hit.261 ], [ %rs4gc.s14, %pic.desc.prefix.hit.266 ]
  %.33 = phi ptr addrspace(1) [ %rs4gc.s7.relocated137, %pic.hit.overflow.273 ], [ %rs4gc.s7.relocated132, %pic.miss.call.269 ], [ %rs4gc.s7.relocated121, %pic.way.live.277 ], [ %rs4gc.s7.relocated121, %pic.hit.live.257 ], [ %rs4gc.s7.relocated121, %pic.prefix.hit.261 ], [ %rs4gc.s7.relocated121, %pic.desc.prefix.hit.266 ]
  %r1091 = phi double [ %r1007, %pic.hit.live.257 ], [ %r1002136, %pic.hit.overflow.273 ], [ %r1027, %pic.prefix.hit.261 ], [ %r1045, %pic.desc.prefix.hit.266 ], [ %r1084, %pic.way.live.277 ], [ %r1090131, %pic.miss.call.269 ]
  br label %pget.recv_merge.251

pic.recv_hdr.271:                                 ; preds = %pget.recv_obj.255
  %r970 = sub nuw nsw i64 %r958, 8
  %r971 = inttoptr i64 %r970 to ptr
  %r972 = load i8, ptr %r971, align 1
  %r973 = icmp eq i8 %r972, 2
  %r974 = sub nuw nsw i64 %r958, 6
  %r975 = inttoptr i64 %r974 to ptr
  %r976 = load i16, ptr %r975, align 2
  %r977 = and i16 %r976, 2048
  %r978 = icmp eq i16 %r977, 0
  %r979 = load ptr, ptr @perry_ic_options_worker_ts__19, align 8
  %r980 = icmp ne ptr %r979, null
  %r981 = and i1 %r973, %r978
  %r982 = and i1 %r981, %r980
  br i1 %r982, label %pic.token.272, label %pic.desc.classify.262

pic.token.272:                                    ; preds = %pic.recv_hdr.271
  %r984 = add nuw nsw i64 %r958, 4
  %r985 = inttoptr i64 %r984 to ptr
  %r986 = load i32, ptr %r985, align 4
  %r987 = zext i32 %r986 to i64
  %r988 = or i64 %r987, 4611686018427387904
  %r989 = icmp ne i32 %r986, 0
  %r990 = getelementptr i64, ptr %r979, i64 0
  %r991 = load i64, ptr %r990, align 8
  %r992 = icmp eq i64 %r988, %r991
  %r993 = and i1 %r992, %r989
  br i1 %r993, label %pic.hit.256, label %pic.prefix.guard.258

pic.hit.overflow.273:                             ; preds = %pic.hit.256
  %r998 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r999 = bitcast double %r998 to i64
  %r1000 = and i64 %r999, 281474976710655
  %r1001 = trunc i64 %r995 to i32
  %statepoint_token135 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r958, i64 %r1000, i32 %r1001, ptr @perry_ic_options_worker_ts__19, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated121, ptr addrspace(1) %rs4gc.s14, ptr addrspace(1) %rs4gc.s15) ]
  %r1002136 = call double @llvm.experimental.gc.result.f64(token %statepoint_token135)
  %rs4gc.s7.relocated137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 0, i32 0) ; (%rs4gc.s7.relocated121, %rs4gc.s7.relocated121)
  %rs4gc.s14.relocated138 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 1, i32 1) ; (%rs4gc.s14, %rs4gc.s14)
  %rs4gc.s15.relocated139 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token135, i32 2, i32 2) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pic.merge.270

pic.hit.inline.274:                               ; preds = %pic.hit.256
  %r1003 = shl i64 %r995, 3
  %r1004 = add nuw nsw i64 %r958, 16
  %r1005 = add i64 %r1004, %r1003
  %r1006 = inttoptr i64 %r1005 to ptr
  %r1007 = load double, ptr %r1006, align 8
  %r1008 = bitcast double %r1007 to i64
  %r1009 = icmp eq i64 %r1008, 9222246136947933200
  br i1 %r1009, label %pic.miss.267, label %pic.hit.live.257

pic.ways.275:                                     ; preds = %pic.miss.267
  %r1049 = getelementptr i64, ptr %r979, i64 4
  %r1050 = load i64, ptr %r1049, align 8
  %r1051 = icmp eq i64 %r1050, %r988
  %r1052 = getelementptr i64, ptr %r979, i64 5
  %r1053 = load i64, ptr %r1052, align 8
  %r1054 = select i1 %r1051, i64 %r1053, i64 0
  %r1055 = getelementptr i64, ptr %r979, i64 6
  %r1056 = load i64, ptr %r1055, align 8
  %r1057 = icmp eq i64 %r1056, %r988
  %r1058 = getelementptr i64, ptr %r979, i64 7
  %r1059 = load i64, ptr %r1058, align 8
  %r1060 = select i1 %r1057, i64 %r1059, i64 0
  %r1061 = getelementptr i64, ptr %r979, i64 8
  %r1062 = load i64, ptr %r1061, align 8
  %r1063 = icmp eq i64 %r1062, %r988
  %r1064 = getelementptr i64, ptr %r979, i64 9
  %r1065 = load i64, ptr %r1064, align 8
  %r1066 = select i1 %r1063, i64 %r1065, i64 0
  %r1067 = getelementptr i64, ptr %r979, i64 10
  %r1068 = load i64, ptr %r1067, align 8
  %r1069 = icmp eq i64 %r1068, %r988
  %r1070 = getelementptr i64, ptr %r979, i64 11
  %r1071 = load i64, ptr %r1070, align 8
  %r1072 = select i1 %r1069, i64 %r1071, i64 0
  %r1073 = or i1 %r1051, %r1057
  %r1074 = select i1 %r1051, i64 %r1054, i64 %r1060
  %r1075 = or i1 %r1063, %r1069
  %r1076 = select i1 %r1063, i64 %r1066, i64 %r1072
  %r1077 = or i1 %r1073, %r1075
  %r1078 = select i1 %r1073, i64 %r1074, i64 %r1076
  %r1079 = and i1 %r989, %r1077
  br i1 %r1079, label %pic.way.load.276, label %pic.miss.call.269

pic.way.load.276:                                 ; preds = %pic.ways.275
  %r1080 = shl i64 %r1078, 3
  %r1081 = add nuw nsw i64 %r958, 16
  %r1082 = add i64 %r1081, %r1080
  %r1083 = inttoptr i64 %r1082 to ptr
  %r1084 = load double, ptr %r1083, align 8
  %r1085 = bitcast double %r1084 to i64
  %r1086 = icmp eq i64 %r1085, 9222246136947933200
  br i1 %r1086, label %pic.miss.call.269, label %pic.way.live.277

pic.way.live.277:                                 ; preds = %pic.way.load.276
  br label %pic.merge.270

pget.throw_nullish.278:                           ; preds = %pget.recv_bad.249
  %r1095 = zext i1 %r1093 to i32
  %statepoint_token140 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1095, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.279:                       ; preds = %pget.recv_bad.249
  %r1096 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1097 = bitcast double %r1096 to i64
  %r1098 = and i64 %r1097, 281474976710655
  %statepoint_token141 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r957, i64 %r1098, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated121, ptr addrspace(1) %rs4gc.s14, ptr addrspace(1) %rs4gc.s15) ]
  %r1099142 = call double @llvm.experimental.gc.result.f64(token %statepoint_token141)
  %rs4gc.s7.relocated143 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 0, i32 0) ; (%rs4gc.s7.relocated121, %rs4gc.s7.relocated121)
  %rs4gc.s14.relocated144 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 1, i32 1) ; (%rs4gc.s14, %rs4gc.s14)
  %rs4gc.s15.relocated145 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 2, i32 2) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.251

guarded_add.numeric.280:                          ; preds = %pget.recv_merge.251
  %r1121 = fadd double %r1110, %r1108
  br label %guarded_add.merge.282

guarded_add.dynamic.281:                          ; preds = %pget.recv_merge.251
  %statepoint_token146 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r1110, double %r1108, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.32, ptr addrspace(1) %.0242) ]
  %r1122147 = call double @llvm.experimental.gc.result.f64(token %statepoint_token146)
  %rs4gc.s7.relocated148 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token146, i32 0, i32 0) ; (%.32, %.32)
  %rs4gc.s14.relocated149 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token146, i32 1, i32 1) ; (%.0242, %.0242)
  br label %guarded_add.merge.282

guarded_add.merge.282:                            ; preds = %guarded_add.dynamic.281, %guarded_add.numeric.280
  %.2244 = phi ptr addrspace(1) [ %.0242, %guarded_add.numeric.280 ], [ %rs4gc.s14.relocated149, %guarded_add.dynamic.281 ]
  %.34 = phi ptr addrspace(1) [ %.32, %guarded_add.numeric.280 ], [ %rs4gc.s7.relocated148, %guarded_add.dynamic.281 ]
  %r1123 = phi double [ %r1121, %guarded_add.numeric.280 ], [ %r1122147, %guarded_add.dynamic.281 ]
  %r1124.rs4i = ptrtoint ptr addrspace(1) %.2244 to i64
  %r1124.rs4o = call i64 asm "", "=r,0"(i64 %r1124.rs4i) #9
  %r1124 = bitcast i64 %r1124.rs4o to double
  %r1125 = bitcast double %r1124 to i64
  %r1126 = and i64 %r1125, -281474976710656
  %r1127 = icmp ne i64 %r1126, 9223090561878065152
  br i1 %r1127, label %str_addref.done.284, label %str_addref.call.283

str_addref.call.283:                              ; preds = %guarded_add.merge.282
  call void @js_string_addref_if_heap_string(double %r1124) #9
  br label %str_addref.done.284

str_addref.done.284:                              ; preds = %str_addref.call.283, %guarded_add.merge.282
  %r1716.rs4i = ptrtoint ptr addrspace(1) %.2244 to i64
  %r1716.rs4o = call i64 asm "", "=r,0"(i64 %r1716.rs4i) #9
  %r1716 = bitcast i64 %r1716.rs4o to double
  store double %r1716, ptr @perry_global_options_worker_ts__7, align 8
  %r1715.rs4i = ptrtoint ptr addrspace(1) %.2244 to i64
  %r1715.rs4o = call i64 asm "", "=r,0"(i64 %r1715.rs4i) #9
  %r1715 = bitcast i64 %r1715.rs4o to double
  %r1128 = bitcast double %r1715 to i64
  %r1713.rs4i = ptrtoint ptr addrspace(1) %.2244 to i64
  %r1713.rs4o = call i64 asm "", "=r,0"(i64 %r1713.rs4i) #9
  %r1713 = bitcast i64 %r1713.rs4o to double
  %r1714 = bitcast double %r1713 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1714) #9
  %r1129 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1130 = icmp ne i32 %r1129, 0
  br i1 %r1130, label %gcpoll.285, label %gcpoll.done.286

gcpoll.285:                                       ; preds = %str_addref.done.284
  %statepoint_token150 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.34) ]
  %rs4gc.s7.relocated151 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 0, i32 0) ; (%.34, %.34)
  br label %gcpoll.done.286

gcpoll.done.286:                                  ; preds = %gcpoll.285, %str_addref.done.284
  %.35 = phi ptr addrspace(1) [ %rs4gc.s7.relocated151, %gcpoll.285 ], [ %.34, %str_addref.done.284 ]
  br label %for.update.234

streqlit.sso.287:                                 ; preds = %if.else.225
  %r1140 = icmp eq i64 %r1137, 9221406112001647979
  br i1 %r1140, label %streqlit.true.293, label %streqlit.tag.288

streqlit.tag.288:                                 ; preds = %streqlit.sso.287
  %r1141 = lshr i64 %r1137, 48
  %r1142 = icmp eq i64 %r1141, 32767
  %r1143 = and i64 %r1137, 281474976710655
  %r1144 = icmp ugt i64 %r1143, 4095
  %r1145 = and i1 %r1142, %r1144
  br i1 %r1145, label %streqlit.len.289, label %streqlit.false.294

streqlit.len.289:                                 ; preds = %streqlit.tag.288
  %r1146 = inttoptr i64 %r1143 to ptr
  %r1147 = getelementptr inbounds nuw i8, ptr %r1146, i64 4
  %r1148 = load i32, ptr %r1147, align 4
  %r1149 = icmp eq i32 %r1148, 4
  br i1 %r1149, label %streqlit.b0.290, label %streqlit.false.294

streqlit.b0.290:                                  ; preds = %streqlit.len.289
  %r1150 = getelementptr inbounds nuw i8, ptr %r1146, i64 20
  %r1151 = load i8, ptr %r1150, align 1
  %r1152 = icmp eq i8 %r1151, 107
  br i1 %r1152, label %streqlit.bl.291, label %streqlit.false.294

streqlit.bl.291:                                  ; preds = %streqlit.b0.290
  %r1153 = getelementptr inbounds nuw i8, ptr %r1146, i64 23
  %r1154 = load i8, ptr %r1153, align 1
  %r1155 = icmp eq i8 %r1154, 115
  br i1 %r1155, label %streqlit.slow.292, label %streqlit.false.294

streqlit.slow.292:                                ; preds = %streqlit.bl.291
  %r1156 = and i64 %r1138, 281474976710655
  %statepoint_token152 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1143, i64 %r1156, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.27) ]
  %r1157153 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token152)
  %rs4gc.s7.relocated154 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token152, i32 0, i32 0) ; (%.27, %.27)
  %r1158 = icmp ne i32 %r1157153, 0
  br label %streqlit.merge.295

streqlit.true.293:                                ; preds = %streqlit.sso.287, %if.else.225
  br label %streqlit.merge.295

streqlit.false.294:                               ; preds = %streqlit.bl.291, %streqlit.b0.290, %streqlit.len.289, %streqlit.tag.288
  br label %streqlit.merge.295

streqlit.merge.295:                               ; preds = %streqlit.false.294, %streqlit.true.293, %streqlit.slow.292
  %.36 = phi ptr addrspace(1) [ %.27, %streqlit.true.293 ], [ %rs4gc.s7.relocated154, %streqlit.slow.292 ], [ %.27, %streqlit.false.294 ]
  %r1159 = phi i1 [ true, %streqlit.true.293 ], [ false, %streqlit.false.294 ], [ %r1158, %streqlit.slow.292 ]
  %r1160 = select i1 %r1159, i64 9222246136947933188, i64 9222246136947933187
  %r1161 = bitcast i64 %r1160 to double
  %r1162 = icmp eq i64 %r1160, 9222246136947933188
  br i1 %r1162, label %if.then.296, label %if.else.297

if.then.296:                                      ; preds = %streqlit.merge.295
  %r1167.rs4i = ptrtoint ptr addrspace(1) %.36 to i64
  %r1167.rs4o = call i64 asm "", "=r,0"(i64 %r1167.rs4i) #9
  %r1167 = bitcast i64 %r1167.rs4o to double
  %r1168 = bitcast double %r1167 to i64
  %r1169 = and i64 %r1168, -281474976710656
  %r1170 = icmp ult i64 %r1169, 9221401712017801216
  %r1171 = icmp ugt i64 %r1169, 9223090561878065152
  %r1172 = or i1 %r1170, %r1171
  br i1 %r1172, label %for.bound_i32.number.299, label %for.bound_i32.merge.301

if.else.297:                                      ; preds = %streqlit.merge.295
  %r1419 = load double, ptr @perry_global_options_worker_ts__1, align 8
  %r1420 = load double, ptr @options_worker_ts_.str.6.handle, align 8
  %r1421 = bitcast double %r1419 to i64
  %r1422 = bitcast double %r1420 to i64
  %r1423 = icmp eq i64 %r1421, %r1422
  br i1 %r1423, label %streqlit.true.364, label %streqlit.tag.359

if.merge.298:                                     ; preds = %if.merge.369, %for.exit.307
  %r2.8 = phi double [ %r2.9, %for.exit.307 ], [ %r2.10, %if.merge.369 ]
  br label %if.merge.226

for.bound_i32.number.299:                         ; preds = %if.then.296
  %r1173 = fcmp oge double %r1167, 0xC1E0000000000000
  %r1174 = fcmp ole double %r1167, 0x41DFFFFFFFC00000
  %r1175 = and i1 %r1173, %r1174
  br i1 %r1175, label %for.bound_i32.convert.300, label %for.bound_i32.merge.301

for.bound_i32.convert.300:                        ; preds = %for.bound_i32.number.299
  %r1176 = fptosi double %r1167 to i32
  %r1177 = sitofp i32 %r1176 to double
  %r1178 = fcmp oeq double %r1177, %r1167
  br i1 %r1178, label %for.counter_i32.range.302, label %for.bound_i32.merge.301

for.bound_i32.merge.301:                          ; preds = %for.counter_i32.convert.303, %for.bound_i32.convert.300, %for.bound_i32.number.299, %if.then.296
  %r1166.0 = phi i32 [ %r1176, %for.counter_i32.convert.303 ], [ 0, %if.then.296 ], [ %r1176, %for.bound_i32.convert.300 ], [ 0, %for.bound_i32.number.299 ]
  %r1165.0 = phi i1 [ true, %for.counter_i32.convert.303 ], [ false, %if.then.296 ], [ false, %for.bound_i32.convert.300 ], [ false, %for.bound_i32.number.299 ]
  br label %for.cond.304

for.counter_i32.range.302:                        ; preds = %for.bound_i32.convert.300
  br label %for.counter_i32.convert.303

for.counter_i32.convert.303:                      ; preds = %for.counter_i32.range.302
  br label %for.bound_i32.merge.301

for.cond.304:                                     ; preds = %for.update.306, %for.bound_i32.merge.301
  %.37 = phi ptr addrspace(1) [ %.36, %for.bound_i32.merge.301 ], [ %.44, %for.update.306 ]
  %r1164.1 = phi i32 [ 0, %for.bound_i32.merge.301 ], [ %r1418, %for.update.306 ]
  %r1163.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.301 ], [ %r1416, %for.update.306 ]
  %r2.9 = phi double [ 0.000000e+00, %for.bound_i32.merge.301 ], [ %r1407, %for.update.306 ]
  br i1 %r1165.0, label %for.cond.fast.308, label %for.cond.slow.309

for.body.305:                                     ; preds = %gcpoll.done.314, %for.cond.fast.308
  %.38 = phi ptr addrspace(1) [ %.37, %for.cond.fast.308 ], [ %.40, %gcpoll.done.314 ]
  %r1228 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %r1229 = load double, ptr @perry_global_options_worker_ts__6, align 8
  %statepoint_token155 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1228, double %r1229, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.38) ]
  %r1230156 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token155)
  %rs4gc.s7.relocated157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 0, i32 0) ; (%.38, %.38)
  %r1231 = bitcast i64 %r1230156 to double
  %rs4gc.b16 = bitcast double %r1231 to i64
  %rs4gc.s16 = inttoptr i64 %rs4gc.b16 to ptr addrspace(1)
  %r1232.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r1232 = call i64 asm "", "=r,0"(i64 %r1232.rs4i) #9
  %r1233 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1234 = icmp ne i32 %r1233, 0
  br i1 %r1234, label %shadow.root.barrier.315, label %shadow.root.barrier.done.316

for.update.306:                                   ; preds = %gcpoll.done.358
  %r1416 = fadd double %r1163.0, 1.000000e+00
  %r1418 = add i32 %r1164.1, 1
  br label %for.cond.304

for.exit.307:                                     ; preds = %gcpoll.done.314, %for.cond.fast.308
  br label %if.merge.298

for.cond.fast.308:                                ; preds = %for.cond.304
  %r1189 = icmp slt i32 %r1164.1, %r1166.0
  br i1 %r1189, label %for.body.305, label %for.exit.307

for.cond.slow.309:                                ; preds = %for.cond.304
  %r1191.rs4i = ptrtoint ptr addrspace(1) %.37 to i64
  %r1191.rs4o = call i64 asm "", "=r,0"(i64 %r1191.rs4i) #9
  %r1191 = bitcast i64 %r1191.rs4o to double
  %r1192 = bitcast double %r1191 to i64
  %r1193 = lshr i64 %r1192, 48
  %r1194 = icmp ult i64 %r1193, 32761
  %r1195 = icmp ugt i64 %r1193, 32767
  %r1196 = or i1 %r1194, %r1195
  %r1197 = icmp eq i64 %r1193, 32766
  %r1198 = icmp eq i64 %r1192, 9222246136947933185
  %r1199 = icmp eq i64 %r1192, 9222246136947933186
  %r1200 = icmp eq i64 %r1192, 9222246136947933187
  %r1201 = icmp eq i64 %r1192, 9222246136947933188
  %r1202 = or i1 %r1199, %r1200
  %r1203 = or i1 %r1196, %r1197
  %r1204 = or i1 %r1203, %r1198
  %r1205 = or i1 %r1204, %r1202
  %r1206 = or i1 %r1205, %r1201
  br i1 %r1206, label %relnum.fast.310, label %relnum.slow.311

relnum.fast.310:                                  ; preds = %for.cond.slow.309
  %r1207 = trunc i64 %r1192 to i32
  %r1208 = sitofp i32 %r1207 to double
  %r1209 = select i1 %r1197, double %r1208, double %r1191
  %r1210 = select i1 %r1202, double 0.000000e+00, double %r1209
  %r1211 = select i1 %r1201, double 1.000000e+00, double %r1210
  %r1212 = bitcast double %r1163.0 to i64
  %r1213 = lshr i64 %r1212, 48
  %r1214 = icmp eq i64 %r1213, 32766
  %r1215 = trunc i64 %r1212 to i32
  %r1216 = sitofp i32 %r1215 to double
  %r1217 = select i1 %r1214, double %r1216, double %r1163.0
  %r1218 = fcmp olt double %r1217, %r1211
  %r1219 = select i1 %r1218, i64 9222246136947933188, i64 9222246136947933187
  %r1220 = bitcast i64 %r1219 to double
  br label %relnum.merge.312

relnum.slow.311:                                  ; preds = %for.cond.slow.309
  %statepoint_token158 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r1163.0, double %r1191, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.37) ]
  %r1221159 = call double @llvm.experimental.gc.result.f64(token %statepoint_token158)
  %rs4gc.s7.relocated160 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token158, i32 0, i32 0) ; (%.37, %.37)
  br label %relnum.merge.312

relnum.merge.312:                                 ; preds = %relnum.slow.311, %relnum.fast.310
  %.39 = phi ptr addrspace(1) [ %.37, %relnum.fast.310 ], [ %rs4gc.s7.relocated160, %relnum.slow.311 ]
  %r1222 = phi double [ %r1220, %relnum.fast.310 ], [ %r1221159, %relnum.slow.311 ]
  %r1223 = bitcast double %r1222 to i64
  %r1225 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1226 = icmp ne i32 %r1225, 0
  br i1 %r1226, label %gcpoll.313, label %gcpoll.done.314

gcpoll.313:                                       ; preds = %relnum.merge.312
  %statepoint_token161 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.39) ]
  %rs4gc.s7.relocated162 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token161, i32 0, i32 0) ; (%.39, %.39)
  br label %gcpoll.done.314

gcpoll.done.314:                                  ; preds = %gcpoll.313, %relnum.merge.312
  %.40 = phi ptr addrspace(1) [ %rs4gc.s7.relocated162, %gcpoll.313 ], [ %.39, %relnum.merge.312 ]
  %r1224 = icmp eq i64 %r1223, 9222246136947933188
  br i1 %r1224, label %for.body.305, label %for.exit.307

shadow.root.barrier.315:                          ; preds = %for.body.305
  call void @js_write_barrier_root_nanbox(i64 %r1232) #9
  br label %shadow.root.barrier.done.316

shadow.root.barrier.done.316:                     ; preds = %shadow.root.barrier.315, %for.body.305
  %r1236 = bitcast double %r2.9 to i64
  %rs4gc.s17 = inttoptr i64 %r1236 to ptr addrspace(1)
  %r1237.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r1237 = call i64 asm "", "=r,0"(i64 %r1237.rs4i) #9
  %r1238 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1239 = icmp ne i32 %r1238, 0
  br i1 %r1239, label %shadow.root.barrier.317, label %shadow.root.barrier.done.318

shadow.root.barrier.317:                          ; preds = %shadow.root.barrier.done.316
  call void @js_write_barrier_root_nanbox(i64 %r1237) #9
  br label %shadow.root.barrier.done.318

shadow.root.barrier.done.318:                     ; preds = %shadow.root.barrier.317, %shadow.root.barrier.done.316
  %r1240.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r1240.rs4o = call i64 asm "", "=r,0"(i64 %r1240.rs4i) #9
  %r1240 = bitcast i64 %r1240.rs4o to double
  %r1241 = bitcast double %r1240 to i64
  %r1242 = and i64 %r1241, 281474976710655
  %r1243 = lshr i64 %r1241, 48
  %r1244 = and i64 %r1243, 65533
  %r1245 = icmp eq i64 %r1244, 32765
  br i1 %r1245, label %pget.recv_ok.320, label %pget.recv_other.325

pget.recv_sso.319:                                ; preds = %pget.recv_other.325
  %r1384 = lshr i64 %r1241, 40
  %r1385 = and i64 %r1384, 255
  %r1386 = uitofp nneg i64 %r1385 to double
  br label %pget.recv_merge.323

pget.recv_ok.320:                                 ; preds = %shadow.root.barrier.done.318
  %r1252 = icmp eq i64 %r1243, 32767
  br i1 %r1252, label %pget.strlen_heap.324, label %pget.recv_obj.327

pget.recv_bad.321:                                ; preds = %pget.check_class_ref.326
  %r1376 = icmp eq i64 %r1241, 9222246136947933185
  %r1377 = icmp eq i64 %r1241, 9222246136947933186
  %r1378 = or i1 %r1376, %r1377
  br i1 %r1378, label %pget.throw_nullish.350, label %pget.recv_undef_return.351

pget.recv_class_ref.322:                          ; preds = %pget.check_class_ref.326
  %r1248 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1249 = bitcast double %r1248 to i64
  %r1250 = and i64 %r1249, 281474976710655
  %statepoint_token163 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532884, i64 %r1241, i64 %r1250, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated157, ptr addrspace(1) %rs4gc.s16, ptr addrspace(1) %rs4gc.s17) ]
  %r1251164 = call double @llvm.experimental.gc.result.f64(token %statepoint_token163)
  %rs4gc.s7.relocated165 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token163, i32 0, i32 0) ; (%rs4gc.s7.relocated157, %rs4gc.s7.relocated157)
  %rs4gc.s16.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token163, i32 1, i32 1) ; (%rs4gc.s16, %rs4gc.s16)
  %rs4gc.s17.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token163, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pget.recv_merge.323

pget.recv_merge.323:                              ; preds = %pget.recv_undef_return.351, %pic.merge.342, %pget.strlen_heap.324, %pget.recv_class_ref.322, %pget.recv_sso.319
  %.0250 = phi ptr addrspace(1) [ %rs4gc.s17, %pget.strlen_heap.324 ], [ %.1251, %pic.merge.342 ], [ %rs4gc.s17, %pget.recv_sso.319 ], [ %rs4gc.s17.relocated, %pget.recv_class_ref.322 ], [ %rs4gc.s17.relocated181, %pget.recv_undef_return.351 ]
  %.0247 = phi ptr addrspace(1) [ %rs4gc.s16, %pget.strlen_heap.324 ], [ %.1248, %pic.merge.342 ], [ %rs4gc.s16, %pget.recv_sso.319 ], [ %rs4gc.s16.relocated, %pget.recv_class_ref.322 ], [ %rs4gc.s16.relocated180, %pget.recv_undef_return.351 ]
  %.41 = phi ptr addrspace(1) [ %rs4gc.s7.relocated157, %pget.strlen_heap.324 ], [ %.42, %pic.merge.342 ], [ %rs4gc.s7.relocated157, %pget.recv_sso.319 ], [ %rs4gc.s7.relocated165, %pget.recv_class_ref.322 ], [ %rs4gc.s7.relocated179, %pget.recv_undef_return.351 ]
  %r1392 = phi double [ %r1375, %pic.merge.342 ], [ %r1383178, %pget.recv_undef_return.351 ], [ %r1386, %pget.recv_sso.319 ], [ %r1251164, %pget.recv_class_ref.322 ], [ %r1391, %pget.strlen_heap.324 ]
  %r1393.rs4i = ptrtoint ptr addrspace(1) %.0250 to i64
  %r1393 = call i64 asm "", "=r,0"(i64 %r1393.rs4i) #9
  %r1394 = bitcast i64 %r1393 to double
  %r1395 = and i64 %r1393, -281474976710656
  %r1396 = icmp ult i64 %r1395, 9221401712017801216
  %r1397 = icmp ugt i64 %r1395, 9223090561878065152
  %r1398 = or i1 %r1396, %r1397
  %r1399 = bitcast double %r1392 to i64
  %r1400 = and i64 %r1399, -281474976710656
  %r1401 = icmp ult i64 %r1400, 9221401712017801216
  %r1402 = icmp ugt i64 %r1400, 9223090561878065152
  %r1403 = or i1 %r1401, %r1402
  %r1404 = and i1 %r1398, %r1403
  br i1 %r1404, label %guarded_add.numeric.352, label %guarded_add.dynamic.353

pget.strlen_heap.324:                             ; preds = %pget.recv_ok.320
  %r1387 = icmp ult i64 %r1242, 4096
  %r1388 = inttoptr i64 %r1242 to ptr
  %r1389 = select i1 %r1387, ptr @perry_null_guard_zero_options_worker_ts, ptr %r1388
  %r1390 = load i32, ptr %r1389, align 4
  %r1391 = uitofp i32 %r1390 to double
  br label %pget.recv_merge.323

pget.recv_other.325:                              ; preds = %shadow.root.barrier.done.318
  %r1246 = icmp eq i64 %r1243, 32761
  br i1 %r1246, label %pget.recv_sso.319, label %pget.check_class_ref.326

pget.check_class_ref.326:                         ; preds = %pget.recv_other.325
  %r1247 = icmp eq i64 %r1243, 32766
  br i1 %r1247, label %pget.recv_class_ref.322, label %pget.recv_bad.321

pget.recv_obj.327:                                ; preds = %pget.recv_ok.320
  %r1253 = icmp ugt i64 %r1242, 1048575
  br i1 %r1253, label %pic.recv_hdr.343, label %pic.miss.cold.340

pic.hit.328:                                      ; preds = %pic.token.344
  %r1278 = getelementptr i64, ptr %r1263, i64 1
  %r1279 = load i64, ptr %r1278, align 8
  %r1280 = and i64 %r1279, 1073741824
  %r1281 = icmp ne i64 %r1280, 0
  br i1 %r1281, label %pic.hit.overflow.345, label %pic.hit.inline.346

pic.hit.live.329:                                 ; preds = %pic.hit.inline.346
  br label %pic.merge.342

pic.prefix.guard.330:                             ; preds = %pic.token.344
  %r1294 = getelementptr i64, ptr %r1263, i64 2
  %r1295 = load i64, ptr %r1294, align 8
  %r1296 = icmp ne i64 %r1295, 0
  br i1 %r1296, label %pic.prefix.meta.331, label %pic.miss.339

pic.prefix.meta.331:                              ; preds = %pic.prefix.guard.330
  %r1297 = add nuw nsw i64 %r1242, 8
  %r1298 = inttoptr i64 %r1297 to ptr
  %r1299 = load i64, ptr %r1298, align 8
  %r1300 = icmp ne i64 %r1299, 0
  br i1 %r1300, label %pic.prefix.token.332, label %pic.miss.339

pic.prefix.token.332:                             ; preds = %pic.prefix.meta.331
  %r1301 = inttoptr i64 %r1299 to ptr
  %r1302 = getelementptr i64, ptr %r1301, i64 6
  %r1303 = load i64, ptr %r1302, align 8
  %r1304 = icmp eq i64 %r1303, %r1295
  br i1 %r1304, label %pic.prefix.hit.333, label %pic.miss.339

pic.prefix.hit.333:                               ; preds = %pic.prefix.token.332
  %r1305 = getelementptr i64, ptr %r1263, i64 1
  %r1306 = load i64, ptr %r1305, align 8
  %r1307 = shl i64 %r1306, 3
  %r1308 = add nuw nsw i64 %r1242, 16
  %r1309 = add i64 %r1308, %r1307
  %r1310 = inttoptr i64 %r1309 to ptr
  %r1311 = load double, ptr %r1310, align 8
  br label %pic.merge.342

pic.desc.classify.334:                            ; preds = %pic.recv_hdr.343
  %r1267 = and i1 %r1257, %r1264
  br i1 %r1267, label %pic.desc.prefix.guard.335, label %pic.miss.cold.340

pic.desc.prefix.guard.335:                        ; preds = %pic.desc.classify.334
  %r1312 = getelementptr i64, ptr %r1263, i64 2
  %r1313 = load i64, ptr %r1312, align 8
  %r1314 = icmp ne i64 %r1313, 0
  br i1 %r1314, label %pic.desc.prefix.meta.336, label %pic.miss.cold.340

pic.desc.prefix.meta.336:                         ; preds = %pic.desc.prefix.guard.335
  %r1315 = add nuw nsw i64 %r1242, 8
  %r1316 = inttoptr i64 %r1315 to ptr
  %r1317 = load i64, ptr %r1316, align 8
  %r1318 = icmp ne i64 %r1317, 0
  br i1 %r1318, label %pic.desc.prefix.token.337, label %pic.miss.cold.340

pic.desc.prefix.token.337:                        ; preds = %pic.desc.prefix.meta.336
  %r1319 = inttoptr i64 %r1317 to ptr
  %r1320 = getelementptr i64, ptr %r1319, i64 6
  %r1321 = load i64, ptr %r1320, align 8
  %r1322 = icmp eq i64 %r1321, %r1313
  br i1 %r1322, label %pic.desc.prefix.hit.338, label %pic.miss.cold.340

pic.desc.prefix.hit.338:                          ; preds = %pic.desc.prefix.token.337
  %r1323 = getelementptr i64, ptr %r1263, i64 1
  %r1324 = load i64, ptr %r1323, align 8
  %r1325 = shl i64 %r1324, 3
  %r1326 = add nuw nsw i64 %r1242, 16
  %r1327 = add i64 %r1326, %r1325
  %r1328 = inttoptr i64 %r1327 to ptr
  %r1329 = load double, ptr %r1328, align 8
  br label %pic.merge.342

pic.miss.339:                                     ; preds = %pic.hit.inline.346, %pic.prefix.token.332, %pic.prefix.meta.331, %pic.prefix.guard.330
  %r1330 = getelementptr i64, ptr %r1263, i64 3
  %r1331 = load i64, ptr %r1330, align 8
  %r1332 = icmp sgt i64 %r1331, 0
  br i1 %r1332, label %pic.ways.347, label %pic.miss.call.341

pic.miss.cold.340:                                ; preds = %pic.desc.prefix.token.337, %pic.desc.prefix.meta.336, %pic.desc.prefix.guard.335, %pic.desc.classify.334, %pget.recv_obj.327
  br label %pic.miss.call.341

pic.miss.call.341:                                ; preds = %pic.way.load.348, %pic.ways.347, %pic.miss.cold.340, %pic.miss.339
  %r1371 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1372 = bitcast double %r1371 to i64
  %r1373 = and i64 %r1372, 281474976710655
  %statepoint_token166 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1242, i64 %r1373, ptr @perry_ic_options_worker_ts__21, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated157, ptr addrspace(1) %rs4gc.s16, ptr addrspace(1) %rs4gc.s17) ]
  %r1374167 = call double @llvm.experimental.gc.result.f64(token %statepoint_token166)
  %rs4gc.s7.relocated168 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token166, i32 0, i32 0) ; (%rs4gc.s7.relocated157, %rs4gc.s7.relocated157)
  %rs4gc.s16.relocated169 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token166, i32 1, i32 1) ; (%rs4gc.s16, %rs4gc.s16)
  %rs4gc.s17.relocated170 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token166, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pic.merge.342

pic.merge.342:                                    ; preds = %pic.way.live.349, %pic.hit.overflow.345, %pic.miss.call.341, %pic.desc.prefix.hit.338, %pic.prefix.hit.333, %pic.hit.live.329
  %.1251 = phi ptr addrspace(1) [ %rs4gc.s17.relocated175, %pic.hit.overflow.345 ], [ %rs4gc.s17.relocated170, %pic.miss.call.341 ], [ %rs4gc.s17, %pic.way.live.349 ], [ %rs4gc.s17, %pic.hit.live.329 ], [ %rs4gc.s17, %pic.prefix.hit.333 ], [ %rs4gc.s17, %pic.desc.prefix.hit.338 ]
  %.1248 = phi ptr addrspace(1) [ %rs4gc.s16.relocated174, %pic.hit.overflow.345 ], [ %rs4gc.s16.relocated169, %pic.miss.call.341 ], [ %rs4gc.s16, %pic.way.live.349 ], [ %rs4gc.s16, %pic.hit.live.329 ], [ %rs4gc.s16, %pic.prefix.hit.333 ], [ %rs4gc.s16, %pic.desc.prefix.hit.338 ]
  %.42 = phi ptr addrspace(1) [ %rs4gc.s7.relocated173, %pic.hit.overflow.345 ], [ %rs4gc.s7.relocated168, %pic.miss.call.341 ], [ %rs4gc.s7.relocated157, %pic.way.live.349 ], [ %rs4gc.s7.relocated157, %pic.hit.live.329 ], [ %rs4gc.s7.relocated157, %pic.prefix.hit.333 ], [ %rs4gc.s7.relocated157, %pic.desc.prefix.hit.338 ]
  %r1375 = phi double [ %r1291, %pic.hit.live.329 ], [ %r1286172, %pic.hit.overflow.345 ], [ %r1311, %pic.prefix.hit.333 ], [ %r1329, %pic.desc.prefix.hit.338 ], [ %r1368, %pic.way.live.349 ], [ %r1374167, %pic.miss.call.341 ]
  br label %pget.recv_merge.323

pic.recv_hdr.343:                                 ; preds = %pget.recv_obj.327
  %r1254 = sub nuw nsw i64 %r1242, 8
  %r1255 = inttoptr i64 %r1254 to ptr
  %r1256 = load i8, ptr %r1255, align 1
  %r1257 = icmp eq i8 %r1256, 2
  %r1258 = sub nuw nsw i64 %r1242, 6
  %r1259 = inttoptr i64 %r1258 to ptr
  %r1260 = load i16, ptr %r1259, align 2
  %r1261 = and i16 %r1260, 2048
  %r1262 = icmp eq i16 %r1261, 0
  %r1263 = load ptr, ptr @perry_ic_options_worker_ts__21, align 8
  %r1264 = icmp ne ptr %r1263, null
  %r1265 = and i1 %r1257, %r1262
  %r1266 = and i1 %r1265, %r1264
  br i1 %r1266, label %pic.token.344, label %pic.desc.classify.334

pic.token.344:                                    ; preds = %pic.recv_hdr.343
  %r1268 = add nuw nsw i64 %r1242, 4
  %r1269 = inttoptr i64 %r1268 to ptr
  %r1270 = load i32, ptr %r1269, align 4
  %r1271 = zext i32 %r1270 to i64
  %r1272 = or i64 %r1271, 4611686018427387904
  %r1273 = icmp ne i32 %r1270, 0
  %r1274 = getelementptr i64, ptr %r1263, i64 0
  %r1275 = load i64, ptr %r1274, align 8
  %r1276 = icmp eq i64 %r1272, %r1275
  %r1277 = and i1 %r1276, %r1273
  br i1 %r1277, label %pic.hit.328, label %pic.prefix.guard.330

pic.hit.overflow.345:                             ; preds = %pic.hit.328
  %r1282 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1283 = bitcast double %r1282 to i64
  %r1284 = and i64 %r1283, 281474976710655
  %r1285 = trunc i64 %r1279 to i32
  %statepoint_token171 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1242, i64 %r1284, i32 %r1285, ptr @perry_ic_options_worker_ts__21, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated157, ptr addrspace(1) %rs4gc.s16, ptr addrspace(1) %rs4gc.s17) ]
  %r1286172 = call double @llvm.experimental.gc.result.f64(token %statepoint_token171)
  %rs4gc.s7.relocated173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 0, i32 0) ; (%rs4gc.s7.relocated157, %rs4gc.s7.relocated157)
  %rs4gc.s16.relocated174 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 1, i32 1) ; (%rs4gc.s16, %rs4gc.s16)
  %rs4gc.s17.relocated175 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pic.merge.342

pic.hit.inline.346:                               ; preds = %pic.hit.328
  %r1287 = shl i64 %r1279, 3
  %r1288 = add nuw nsw i64 %r1242, 16
  %r1289 = add i64 %r1288, %r1287
  %r1290 = inttoptr i64 %r1289 to ptr
  %r1291 = load double, ptr %r1290, align 8
  %r1292 = bitcast double %r1291 to i64
  %r1293 = icmp eq i64 %r1292, 9222246136947933200
  br i1 %r1293, label %pic.miss.339, label %pic.hit.live.329

pic.ways.347:                                     ; preds = %pic.miss.339
  %r1333 = getelementptr i64, ptr %r1263, i64 4
  %r1334 = load i64, ptr %r1333, align 8
  %r1335 = icmp eq i64 %r1334, %r1272
  %r1336 = getelementptr i64, ptr %r1263, i64 5
  %r1337 = load i64, ptr %r1336, align 8
  %r1338 = select i1 %r1335, i64 %r1337, i64 0
  %r1339 = getelementptr i64, ptr %r1263, i64 6
  %r1340 = load i64, ptr %r1339, align 8
  %r1341 = icmp eq i64 %r1340, %r1272
  %r1342 = getelementptr i64, ptr %r1263, i64 7
  %r1343 = load i64, ptr %r1342, align 8
  %r1344 = select i1 %r1341, i64 %r1343, i64 0
  %r1345 = getelementptr i64, ptr %r1263, i64 8
  %r1346 = load i64, ptr %r1345, align 8
  %r1347 = icmp eq i64 %r1346, %r1272
  %r1348 = getelementptr i64, ptr %r1263, i64 9
  %r1349 = load i64, ptr %r1348, align 8
  %r1350 = select i1 %r1347, i64 %r1349, i64 0
  %r1351 = getelementptr i64, ptr %r1263, i64 10
  %r1352 = load i64, ptr %r1351, align 8
  %r1353 = icmp eq i64 %r1352, %r1272
  %r1354 = getelementptr i64, ptr %r1263, i64 11
  %r1355 = load i64, ptr %r1354, align 8
  %r1356 = select i1 %r1353, i64 %r1355, i64 0
  %r1357 = or i1 %r1335, %r1341
  %r1358 = select i1 %r1335, i64 %r1338, i64 %r1344
  %r1359 = or i1 %r1347, %r1353
  %r1360 = select i1 %r1347, i64 %r1350, i64 %r1356
  %r1361 = or i1 %r1357, %r1359
  %r1362 = select i1 %r1357, i64 %r1358, i64 %r1360
  %r1363 = and i1 %r1273, %r1361
  br i1 %r1363, label %pic.way.load.348, label %pic.miss.call.341

pic.way.load.348:                                 ; preds = %pic.ways.347
  %r1364 = shl i64 %r1362, 3
  %r1365 = add nuw nsw i64 %r1242, 16
  %r1366 = add i64 %r1365, %r1364
  %r1367 = inttoptr i64 %r1366 to ptr
  %r1368 = load double, ptr %r1367, align 8
  %r1369 = bitcast double %r1368 to i64
  %r1370 = icmp eq i64 %r1369, 9222246136947933200
  br i1 %r1370, label %pic.miss.call.341, label %pic.way.live.349

pic.way.live.349:                                 ; preds = %pic.way.load.348
  br label %pic.merge.342

pget.throw_nullish.350:                           ; preds = %pget.recv_bad.321
  %r1379 = zext i1 %r1377 to i32
  %statepoint_token176 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1379, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.351:                       ; preds = %pget.recv_bad.321
  %r1380 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1381 = bitcast double %r1380 to i64
  %r1382 = and i64 %r1381, 281474976710655
  %statepoint_token177 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1241, i64 %r1382, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated157, ptr addrspace(1) %rs4gc.s16, ptr addrspace(1) %rs4gc.s17) ]
  %r1383178 = call double @llvm.experimental.gc.result.f64(token %statepoint_token177)
  %rs4gc.s7.relocated179 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token177, i32 0, i32 0) ; (%rs4gc.s7.relocated157, %rs4gc.s7.relocated157)
  %rs4gc.s16.relocated180 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token177, i32 1, i32 1) ; (%rs4gc.s16, %rs4gc.s16)
  %rs4gc.s17.relocated181 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token177, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  br label %pget.recv_merge.323

guarded_add.numeric.352:                          ; preds = %pget.recv_merge.323
  %r1405 = fadd double %r1394, %r1392
  br label %guarded_add.merge.354

guarded_add.dynamic.353:                          ; preds = %pget.recv_merge.323
  %statepoint_token182 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r1394, double %r1392, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41, ptr addrspace(1) %.0247) ]
  %r1406183 = call double @llvm.experimental.gc.result.f64(token %statepoint_token182)
  %rs4gc.s7.relocated184 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token182, i32 0, i32 0) ; (%.41, %.41)
  %rs4gc.s16.relocated185 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token182, i32 1, i32 1) ; (%.0247, %.0247)
  br label %guarded_add.merge.354

guarded_add.merge.354:                            ; preds = %guarded_add.dynamic.353, %guarded_add.numeric.352
  %.2249 = phi ptr addrspace(1) [ %.0247, %guarded_add.numeric.352 ], [ %rs4gc.s16.relocated185, %guarded_add.dynamic.353 ]
  %.43 = phi ptr addrspace(1) [ %.41, %guarded_add.numeric.352 ], [ %rs4gc.s7.relocated184, %guarded_add.dynamic.353 ]
  %r1407 = phi double [ %r1405, %guarded_add.numeric.352 ], [ %r1406183, %guarded_add.dynamic.353 ]
  %r1408.rs4i = ptrtoint ptr addrspace(1) %.2249 to i64
  %r1408.rs4o = call i64 asm "", "=r,0"(i64 %r1408.rs4i) #9
  %r1408 = bitcast i64 %r1408.rs4o to double
  %r1409 = bitcast double %r1408 to i64
  %r1410 = and i64 %r1409, -281474976710656
  %r1411 = icmp ne i64 %r1410, 9223090561878065152
  br i1 %r1411, label %str_addref.done.356, label %str_addref.call.355

str_addref.call.355:                              ; preds = %guarded_add.merge.354
  call void @js_string_addref_if_heap_string(double %r1408) #9
  br label %str_addref.done.356

str_addref.done.356:                              ; preds = %str_addref.call.355, %guarded_add.merge.354
  %r1712.rs4i = ptrtoint ptr addrspace(1) %.2249 to i64
  %r1712.rs4o = call i64 asm "", "=r,0"(i64 %r1712.rs4i) #9
  %r1712 = bitcast i64 %r1712.rs4o to double
  store double %r1712, ptr @perry_global_options_worker_ts__7, align 8
  %r1711.rs4i = ptrtoint ptr addrspace(1) %.2249 to i64
  %r1711.rs4o = call i64 asm "", "=r,0"(i64 %r1711.rs4i) #9
  %r1711 = bitcast i64 %r1711.rs4o to double
  %r1412 = bitcast double %r1711 to i64
  %r1709.rs4i = ptrtoint ptr addrspace(1) %.2249 to i64
  %r1709.rs4o = call i64 asm "", "=r,0"(i64 %r1709.rs4i) #9
  %r1709 = bitcast i64 %r1709.rs4o to double
  %r1710 = bitcast double %r1709 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1710) #9
  %r1413 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1414 = icmp ne i32 %r1413, 0
  br i1 %r1414, label %gcpoll.357, label %gcpoll.done.358

gcpoll.357:                                       ; preds = %str_addref.done.356
  %statepoint_token186 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.43) ]
  %rs4gc.s7.relocated187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token186, i32 0, i32 0) ; (%.43, %.43)
  br label %gcpoll.done.358

gcpoll.done.358:                                  ; preds = %gcpoll.357, %str_addref.done.356
  %.44 = phi ptr addrspace(1) [ %rs4gc.s7.relocated187, %gcpoll.357 ], [ %.43, %str_addref.done.356 ]
  br label %for.update.306

streqlit.tag.359:                                 ; preds = %if.else.297
  %r1424 = lshr i64 %r1421, 48
  %r1425 = icmp eq i64 %r1424, 32767
  %r1426 = and i64 %r1421, 281474976710655
  %r1427 = icmp ugt i64 %r1426, 4095
  %r1428 = and i1 %r1425, %r1427
  br i1 %r1428, label %streqlit.len.360, label %streqlit.false.365

streqlit.len.360:                                 ; preds = %streqlit.tag.359
  %r1429 = inttoptr i64 %r1426 to ptr
  %r1430 = getelementptr inbounds nuw i8, ptr %r1429, i64 4
  %r1431 = load i32, ptr %r1430, align 4
  %r1432 = icmp eq i32 %r1431, 8
  br i1 %r1432, label %streqlit.b0.361, label %streqlit.false.365

streqlit.b0.361:                                  ; preds = %streqlit.len.360
  %r1433 = getelementptr inbounds nuw i8, ptr %r1429, i64 20
  %r1434 = load i8, ptr %r1433, align 1
  %r1435 = icmp eq i8 %r1434, 99
  br i1 %r1435, label %streqlit.bl.362, label %streqlit.false.365

streqlit.bl.362:                                  ; preds = %streqlit.b0.361
  %r1436 = getelementptr inbounds nuw i8, ptr %r1429, i64 27
  %r1437 = load i8, ptr %r1436, align 1
  %r1438 = icmp eq i8 %r1437, 107
  br i1 %r1438, label %streqlit.slow.363, label %streqlit.false.365

streqlit.slow.363:                                ; preds = %streqlit.bl.362
  %r1439 = and i64 %r1422, 281474976710655
  %statepoint_token188 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1426, i64 %r1439, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.36) ]
  %r1440189 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token188)
  %rs4gc.s7.relocated190 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token188, i32 0, i32 0) ; (%.36, %.36)
  %r1441 = icmp ne i32 %r1440189, 0
  br label %streqlit.merge.366

streqlit.true.364:                                ; preds = %if.else.297
  br label %streqlit.merge.366

streqlit.false.365:                               ; preds = %streqlit.bl.362, %streqlit.b0.361, %streqlit.len.360, %streqlit.tag.359
  br label %streqlit.merge.366

streqlit.merge.366:                               ; preds = %streqlit.false.365, %streqlit.true.364, %streqlit.slow.363
  %.45 = phi ptr addrspace(1) [ %.36, %streqlit.true.364 ], [ %rs4gc.s7.relocated190, %streqlit.slow.363 ], [ %.36, %streqlit.false.365 ]
  %r1442 = phi i1 [ true, %streqlit.true.364 ], [ false, %streqlit.false.365 ], [ %r1441, %streqlit.slow.363 ]
  %r1443 = select i1 %r1442, i64 9222246136947933188, i64 9222246136947933187
  %r1444 = bitcast i64 %r1443 to double
  %r1445 = icmp eq i64 %r1443, 9222246136947933188
  br i1 %r1445, label %if.then.367, label %if.else.368

if.then.367:                                      ; preds = %streqlit.merge.366
  %r1450.rs4i = ptrtoint ptr addrspace(1) %.45 to i64
  %r1450.rs4o = call i64 asm "", "=r,0"(i64 %r1450.rs4i) #9
  %r1450 = bitcast i64 %r1450.rs4o to double
  %r1451 = bitcast double %r1450 to i64
  %r1452 = and i64 %r1451, -281474976710656
  %r1453 = icmp ult i64 %r1452, 9221401712017801216
  %r1454 = icmp ugt i64 %r1452, 9223090561878065152
  %r1455 = or i1 %r1453, %r1454
  br i1 %r1455, label %for.bound_i32.number.370, label %for.bound_i32.merge.372

if.else.368:                                      ; preds = %streqlit.merge.366
  br label %if.merge.369

if.merge.369:                                     ; preds = %for.exit.378, %if.else.368
  %r2.10 = phi double [ %r2.11, %for.exit.378 ], [ 0.000000e+00, %if.else.368 ]
  br label %if.merge.298

for.bound_i32.number.370:                         ; preds = %if.then.367
  %r1456 = fcmp oge double %r1450, 0xC1E0000000000000
  %r1457 = fcmp ole double %r1450, 0x41DFFFFFFFC00000
  %r1458 = and i1 %r1456, %r1457
  br i1 %r1458, label %for.bound_i32.convert.371, label %for.bound_i32.merge.372

for.bound_i32.convert.371:                        ; preds = %for.bound_i32.number.370
  %r1459 = fptosi double %r1450 to i32
  %r1460 = sitofp i32 %r1459 to double
  %r1461 = fcmp oeq double %r1460, %r1450
  br i1 %r1461, label %for.counter_i32.range.373, label %for.bound_i32.merge.372

for.bound_i32.merge.372:                          ; preds = %for.counter_i32.convert.374, %for.bound_i32.convert.371, %for.bound_i32.number.370, %if.then.367
  %r1449.0 = phi i32 [ %r1459, %for.counter_i32.convert.374 ], [ 0, %if.then.367 ], [ %r1459, %for.bound_i32.convert.371 ], [ 0, %for.bound_i32.number.370 ]
  %r1448.0 = phi i1 [ true, %for.counter_i32.convert.374 ], [ false, %if.then.367 ], [ false, %for.bound_i32.convert.371 ], [ false, %for.bound_i32.number.370 ]
  br label %for.cond.375

for.counter_i32.range.373:                        ; preds = %for.bound_i32.convert.371
  br label %for.counter_i32.convert.374

for.counter_i32.convert.374:                      ; preds = %for.counter_i32.range.373
  br label %for.bound_i32.merge.372

for.cond.375:                                     ; preds = %for.update.377, %for.bound_i32.merge.372
  %.46 = phi ptr addrspace(1) [ %.45, %for.bound_i32.merge.372 ], [ %.53, %for.update.377 ]
  %r1447.1 = phi i32 [ 0, %for.bound_i32.merge.372 ], [ %r1703, %for.update.377 ]
  %r1446.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.372 ], [ %r1701, %for.update.377 ]
  %r2.11 = phi double [ 0.000000e+00, %for.bound_i32.merge.372 ], [ %r1692, %for.update.377 ]
  br i1 %r1448.0, label %for.cond.fast.379, label %for.cond.slow.380

for.body.376:                                     ; preds = %gcpoll.done.385, %for.cond.fast.379
  %.47 = phi ptr addrspace(1) [ %.46, %for.cond.fast.379 ], [ %.49, %gcpoll.done.385 ]
  %r1511 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %statepoint_token191 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr)) @js_closure_alloc_singleton, i32 1, i32 0, ptr @__perry_wrap_perry_fn_options_worker_ts__identity, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.47) ]
  %r1512192 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token191)
  %rs4gc.s7.relocated193 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token191, i32 0, i32 0) ; (%.47, %.47)
  %r1513 = or i64 %r1512192, 9222527611924643840
  %r1514 = bitcast i64 %r1513 to double
  %statepoint_token194 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1511, double %r1514, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated193) ]
  %r1515195 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token194)
  %rs4gc.s7.relocated196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token194, i32 0, i32 0) ; (%rs4gc.s7.relocated193, %rs4gc.s7.relocated193)
  %r1516 = bitcast i64 %r1515195 to double
  %rs4gc.b18 = bitcast double %r1516 to i64
  %rs4gc.s18 = inttoptr i64 %rs4gc.b18 to ptr addrspace(1)
  %r1517.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r1517 = call i64 asm "", "=r,0"(i64 %r1517.rs4i) #9
  %r1518 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1519 = icmp ne i32 %r1518, 0
  br i1 %r1519, label %shadow.root.barrier.386, label %shadow.root.barrier.done.387

for.update.377:                                   ; preds = %gcpoll.done.429
  %r1701 = fadd double %r1446.0, 1.000000e+00
  %r1703 = add i32 %r1447.1, 1
  br label %for.cond.375

for.exit.378:                                     ; preds = %gcpoll.done.385, %for.cond.fast.379
  br label %if.merge.369

for.cond.fast.379:                                ; preds = %for.cond.375
  %r1472 = icmp slt i32 %r1447.1, %r1449.0
  br i1 %r1472, label %for.body.376, label %for.exit.378

for.cond.slow.380:                                ; preds = %for.cond.375
  %r1474.rs4i = ptrtoint ptr addrspace(1) %.46 to i64
  %r1474.rs4o = call i64 asm "", "=r,0"(i64 %r1474.rs4i) #9
  %r1474 = bitcast i64 %r1474.rs4o to double
  %r1475 = bitcast double %r1474 to i64
  %r1476 = lshr i64 %r1475, 48
  %r1477 = icmp ult i64 %r1476, 32761
  %r1478 = icmp ugt i64 %r1476, 32767
  %r1479 = or i1 %r1477, %r1478
  %r1480 = icmp eq i64 %r1476, 32766
  %r1481 = icmp eq i64 %r1475, 9222246136947933185
  %r1482 = icmp eq i64 %r1475, 9222246136947933186
  %r1483 = icmp eq i64 %r1475, 9222246136947933187
  %r1484 = icmp eq i64 %r1475, 9222246136947933188
  %r1485 = or i1 %r1482, %r1483
  %r1486 = or i1 %r1479, %r1480
  %r1487 = or i1 %r1486, %r1481
  %r1488 = or i1 %r1487, %r1485
  %r1489 = or i1 %r1488, %r1484
  br i1 %r1489, label %relnum.fast.381, label %relnum.slow.382

relnum.fast.381:                                  ; preds = %for.cond.slow.380
  %r1490 = trunc i64 %r1475 to i32
  %r1491 = sitofp i32 %r1490 to double
  %r1492 = select i1 %r1480, double %r1491, double %r1474
  %r1493 = select i1 %r1485, double 0.000000e+00, double %r1492
  %r1494 = select i1 %r1484, double 1.000000e+00, double %r1493
  %r1495 = bitcast double %r1446.0 to i64
  %r1496 = lshr i64 %r1495, 48
  %r1497 = icmp eq i64 %r1496, 32766
  %r1498 = trunc i64 %r1495 to i32
  %r1499 = sitofp i32 %r1498 to double
  %r1500 = select i1 %r1497, double %r1499, double %r1446.0
  %r1501 = fcmp olt double %r1500, %r1494
  %r1502 = select i1 %r1501, i64 9222246136947933188, i64 9222246136947933187
  %r1503 = bitcast i64 %r1502 to double
  br label %relnum.merge.383

relnum.slow.382:                                  ; preds = %for.cond.slow.380
  %statepoint_token197 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r1446.0, double %r1474, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.46) ]
  %r1504198 = call double @llvm.experimental.gc.result.f64(token %statepoint_token197)
  %rs4gc.s7.relocated199 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token197, i32 0, i32 0) ; (%.46, %.46)
  br label %relnum.merge.383

relnum.merge.383:                                 ; preds = %relnum.slow.382, %relnum.fast.381
  %.48 = phi ptr addrspace(1) [ %.46, %relnum.fast.381 ], [ %rs4gc.s7.relocated199, %relnum.slow.382 ]
  %r1505 = phi double [ %r1503, %relnum.fast.381 ], [ %r1504198, %relnum.slow.382 ]
  %r1506 = bitcast double %r1505 to i64
  %r1508 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1509 = icmp ne i32 %r1508, 0
  br i1 %r1509, label %gcpoll.384, label %gcpoll.done.385

gcpoll.384:                                       ; preds = %relnum.merge.383
  %statepoint_token200 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.48) ]
  %rs4gc.s7.relocated201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token200, i32 0, i32 0) ; (%.48, %.48)
  br label %gcpoll.done.385

gcpoll.done.385:                                  ; preds = %gcpoll.384, %relnum.merge.383
  %.49 = phi ptr addrspace(1) [ %rs4gc.s7.relocated201, %gcpoll.384 ], [ %.48, %relnum.merge.383 ]
  %r1507 = icmp eq i64 %r1506, 9222246136947933188
  br i1 %r1507, label %for.body.376, label %for.exit.378

shadow.root.barrier.386:                          ; preds = %for.body.376
  call void @js_write_barrier_root_nanbox(i64 %r1517) #9
  br label %shadow.root.barrier.done.387

shadow.root.barrier.done.387:                     ; preds = %shadow.root.barrier.386, %for.body.376
  %r1521 = bitcast double %r2.11 to i64
  %rs4gc.s19 = inttoptr i64 %r1521 to ptr addrspace(1)
  %r1522.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r1522 = call i64 asm "", "=r,0"(i64 %r1522.rs4i) #9
  %r1523 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1524 = icmp ne i32 %r1523, 0
  br i1 %r1524, label %shadow.root.barrier.388, label %shadow.root.barrier.done.389

shadow.root.barrier.388:                          ; preds = %shadow.root.barrier.done.387
  call void @js_write_barrier_root_nanbox(i64 %r1522) #9
  br label %shadow.root.barrier.done.389

shadow.root.barrier.done.389:                     ; preds = %shadow.root.barrier.388, %shadow.root.barrier.done.387
  %r1525.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r1525.rs4o = call i64 asm "", "=r,0"(i64 %r1525.rs4i) #9
  %r1525 = bitcast i64 %r1525.rs4o to double
  %r1526 = bitcast double %r1525 to i64
  %r1527 = and i64 %r1526, 281474976710655
  %r1528 = lshr i64 %r1526, 48
  %r1529 = and i64 %r1528, 65533
  %r1530 = icmp eq i64 %r1529, 32765
  br i1 %r1530, label %pget.recv_ok.391, label %pget.recv_other.396

pget.recv_sso.390:                                ; preds = %pget.recv_other.396
  %r1669 = lshr i64 %r1526, 40
  %r1670 = and i64 %r1669, 255
  %r1671 = uitofp nneg i64 %r1670 to double
  br label %pget.recv_merge.394

pget.recv_ok.391:                                 ; preds = %shadow.root.barrier.done.389
  %r1537 = icmp eq i64 %r1528, 32767
  br i1 %r1537, label %pget.strlen_heap.395, label %pget.recv_obj.398

pget.recv_bad.392:                                ; preds = %pget.check_class_ref.397
  %r1661 = icmp eq i64 %r1526, 9222246136947933185
  %r1662 = icmp eq i64 %r1526, 9222246136947933186
  %r1663 = or i1 %r1661, %r1662
  br i1 %r1663, label %pget.throw_nullish.421, label %pget.recv_undef_return.422

pget.recv_class_ref.393:                          ; preds = %pget.check_class_ref.397
  %r1533 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1534 = bitcast double %r1533 to i64
  %r1535 = and i64 %r1534, 281474976710655
  %statepoint_token202 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532886, i64 %r1526, i64 %r1535, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated196, ptr addrspace(1) %rs4gc.s18, ptr addrspace(1) %rs4gc.s19) ]
  %r1536203 = call double @llvm.experimental.gc.result.f64(token %statepoint_token202)
  %rs4gc.s7.relocated204 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token202, i32 0, i32 0) ; (%rs4gc.s7.relocated196, %rs4gc.s7.relocated196)
  %rs4gc.s18.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token202, i32 1, i32 1) ; (%rs4gc.s18, %rs4gc.s18)
  %rs4gc.s19.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token202, i32 2, i32 2) ; (%rs4gc.s19, %rs4gc.s19)
  br label %pget.recv_merge.394

pget.recv_merge.394:                              ; preds = %pget.recv_undef_return.422, %pic.merge.413, %pget.strlen_heap.395, %pget.recv_class_ref.393, %pget.recv_sso.390
  %.0255 = phi ptr addrspace(1) [ %rs4gc.s19, %pget.strlen_heap.395 ], [ %.1256, %pic.merge.413 ], [ %rs4gc.s19, %pget.recv_sso.390 ], [ %rs4gc.s19.relocated, %pget.recv_class_ref.393 ], [ %rs4gc.s19.relocated220, %pget.recv_undef_return.422 ]
  %.0252 = phi ptr addrspace(1) [ %rs4gc.s18, %pget.strlen_heap.395 ], [ %.1253, %pic.merge.413 ], [ %rs4gc.s18, %pget.recv_sso.390 ], [ %rs4gc.s18.relocated, %pget.recv_class_ref.393 ], [ %rs4gc.s18.relocated219, %pget.recv_undef_return.422 ]
  %.50 = phi ptr addrspace(1) [ %rs4gc.s7.relocated196, %pget.strlen_heap.395 ], [ %.51, %pic.merge.413 ], [ %rs4gc.s7.relocated196, %pget.recv_sso.390 ], [ %rs4gc.s7.relocated204, %pget.recv_class_ref.393 ], [ %rs4gc.s7.relocated218, %pget.recv_undef_return.422 ]
  %r1677 = phi double [ %r1660, %pic.merge.413 ], [ %r1668217, %pget.recv_undef_return.422 ], [ %r1671, %pget.recv_sso.390 ], [ %r1536203, %pget.recv_class_ref.393 ], [ %r1676, %pget.strlen_heap.395 ]
  %r1678.rs4i = ptrtoint ptr addrspace(1) %.0255 to i64
  %r1678 = call i64 asm "", "=r,0"(i64 %r1678.rs4i) #9
  %r1679 = bitcast i64 %r1678 to double
  %r1680 = and i64 %r1678, -281474976710656
  %r1681 = icmp ult i64 %r1680, 9221401712017801216
  %r1682 = icmp ugt i64 %r1680, 9223090561878065152
  %r1683 = or i1 %r1681, %r1682
  %r1684 = bitcast double %r1677 to i64
  %r1685 = and i64 %r1684, -281474976710656
  %r1686 = icmp ult i64 %r1685, 9221401712017801216
  %r1687 = icmp ugt i64 %r1685, 9223090561878065152
  %r1688 = or i1 %r1686, %r1687
  %r1689 = and i1 %r1683, %r1688
  br i1 %r1689, label %guarded_add.numeric.423, label %guarded_add.dynamic.424

pget.strlen_heap.395:                             ; preds = %pget.recv_ok.391
  %r1672 = icmp ult i64 %r1527, 4096
  %r1673 = inttoptr i64 %r1527 to ptr
  %r1674 = select i1 %r1672, ptr @perry_null_guard_zero_options_worker_ts, ptr %r1673
  %r1675 = load i32, ptr %r1674, align 4
  %r1676 = uitofp i32 %r1675 to double
  br label %pget.recv_merge.394

pget.recv_other.396:                              ; preds = %shadow.root.barrier.done.389
  %r1531 = icmp eq i64 %r1528, 32761
  br i1 %r1531, label %pget.recv_sso.390, label %pget.check_class_ref.397

pget.check_class_ref.397:                         ; preds = %pget.recv_other.396
  %r1532 = icmp eq i64 %r1528, 32766
  br i1 %r1532, label %pget.recv_class_ref.393, label %pget.recv_bad.392

pget.recv_obj.398:                                ; preds = %pget.recv_ok.391
  %r1538 = icmp ugt i64 %r1527, 1048575
  br i1 %r1538, label %pic.recv_hdr.414, label %pic.miss.cold.411

pic.hit.399:                                      ; preds = %pic.token.415
  %r1563 = getelementptr i64, ptr %r1548, i64 1
  %r1564 = load i64, ptr %r1563, align 8
  %r1565 = and i64 %r1564, 1073741824
  %r1566 = icmp ne i64 %r1565, 0
  br i1 %r1566, label %pic.hit.overflow.416, label %pic.hit.inline.417

pic.hit.live.400:                                 ; preds = %pic.hit.inline.417
  br label %pic.merge.413

pic.prefix.guard.401:                             ; preds = %pic.token.415
  %r1579 = getelementptr i64, ptr %r1548, i64 2
  %r1580 = load i64, ptr %r1579, align 8
  %r1581 = icmp ne i64 %r1580, 0
  br i1 %r1581, label %pic.prefix.meta.402, label %pic.miss.410

pic.prefix.meta.402:                              ; preds = %pic.prefix.guard.401
  %r1582 = add nuw nsw i64 %r1527, 8
  %r1583 = inttoptr i64 %r1582 to ptr
  %r1584 = load i64, ptr %r1583, align 8
  %r1585 = icmp ne i64 %r1584, 0
  br i1 %r1585, label %pic.prefix.token.403, label %pic.miss.410

pic.prefix.token.403:                             ; preds = %pic.prefix.meta.402
  %r1586 = inttoptr i64 %r1584 to ptr
  %r1587 = getelementptr i64, ptr %r1586, i64 6
  %r1588 = load i64, ptr %r1587, align 8
  %r1589 = icmp eq i64 %r1588, %r1580
  br i1 %r1589, label %pic.prefix.hit.404, label %pic.miss.410

pic.prefix.hit.404:                               ; preds = %pic.prefix.token.403
  %r1590 = getelementptr i64, ptr %r1548, i64 1
  %r1591 = load i64, ptr %r1590, align 8
  %r1592 = shl i64 %r1591, 3
  %r1593 = add nuw nsw i64 %r1527, 16
  %r1594 = add i64 %r1593, %r1592
  %r1595 = inttoptr i64 %r1594 to ptr
  %r1596 = load double, ptr %r1595, align 8
  br label %pic.merge.413

pic.desc.classify.405:                            ; preds = %pic.recv_hdr.414
  %r1552 = and i1 %r1542, %r1549
  br i1 %r1552, label %pic.desc.prefix.guard.406, label %pic.miss.cold.411

pic.desc.prefix.guard.406:                        ; preds = %pic.desc.classify.405
  %r1597 = getelementptr i64, ptr %r1548, i64 2
  %r1598 = load i64, ptr %r1597, align 8
  %r1599 = icmp ne i64 %r1598, 0
  br i1 %r1599, label %pic.desc.prefix.meta.407, label %pic.miss.cold.411

pic.desc.prefix.meta.407:                         ; preds = %pic.desc.prefix.guard.406
  %r1600 = add nuw nsw i64 %r1527, 8
  %r1601 = inttoptr i64 %r1600 to ptr
  %r1602 = load i64, ptr %r1601, align 8
  %r1603 = icmp ne i64 %r1602, 0
  br i1 %r1603, label %pic.desc.prefix.token.408, label %pic.miss.cold.411

pic.desc.prefix.token.408:                        ; preds = %pic.desc.prefix.meta.407
  %r1604 = inttoptr i64 %r1602 to ptr
  %r1605 = getelementptr i64, ptr %r1604, i64 6
  %r1606 = load i64, ptr %r1605, align 8
  %r1607 = icmp eq i64 %r1606, %r1598
  br i1 %r1607, label %pic.desc.prefix.hit.409, label %pic.miss.cold.411

pic.desc.prefix.hit.409:                          ; preds = %pic.desc.prefix.token.408
  %r1608 = getelementptr i64, ptr %r1548, i64 1
  %r1609 = load i64, ptr %r1608, align 8
  %r1610 = shl i64 %r1609, 3
  %r1611 = add nuw nsw i64 %r1527, 16
  %r1612 = add i64 %r1611, %r1610
  %r1613 = inttoptr i64 %r1612 to ptr
  %r1614 = load double, ptr %r1613, align 8
  br label %pic.merge.413

pic.miss.410:                                     ; preds = %pic.hit.inline.417, %pic.prefix.token.403, %pic.prefix.meta.402, %pic.prefix.guard.401
  %r1615 = getelementptr i64, ptr %r1548, i64 3
  %r1616 = load i64, ptr %r1615, align 8
  %r1617 = icmp sgt i64 %r1616, 0
  br i1 %r1617, label %pic.ways.418, label %pic.miss.call.412

pic.miss.cold.411:                                ; preds = %pic.desc.prefix.token.408, %pic.desc.prefix.meta.407, %pic.desc.prefix.guard.406, %pic.desc.classify.405, %pget.recv_obj.398
  br label %pic.miss.call.412

pic.miss.call.412:                                ; preds = %pic.way.load.419, %pic.ways.418, %pic.miss.cold.411, %pic.miss.410
  %r1656 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1657 = bitcast double %r1656 to i64
  %r1658 = and i64 %r1657, 281474976710655
  %statepoint_token205 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1527, i64 %r1658, ptr @perry_ic_options_worker_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated196, ptr addrspace(1) %rs4gc.s18, ptr addrspace(1) %rs4gc.s19) ]
  %r1659206 = call double @llvm.experimental.gc.result.f64(token %statepoint_token205)
  %rs4gc.s7.relocated207 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token205, i32 0, i32 0) ; (%rs4gc.s7.relocated196, %rs4gc.s7.relocated196)
  %rs4gc.s18.relocated208 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token205, i32 1, i32 1) ; (%rs4gc.s18, %rs4gc.s18)
  %rs4gc.s19.relocated209 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token205, i32 2, i32 2) ; (%rs4gc.s19, %rs4gc.s19)
  br label %pic.merge.413

pic.merge.413:                                    ; preds = %pic.way.live.420, %pic.hit.overflow.416, %pic.miss.call.412, %pic.desc.prefix.hit.409, %pic.prefix.hit.404, %pic.hit.live.400
  %.1256 = phi ptr addrspace(1) [ %rs4gc.s19.relocated214, %pic.hit.overflow.416 ], [ %rs4gc.s19.relocated209, %pic.miss.call.412 ], [ %rs4gc.s19, %pic.way.live.420 ], [ %rs4gc.s19, %pic.hit.live.400 ], [ %rs4gc.s19, %pic.prefix.hit.404 ], [ %rs4gc.s19, %pic.desc.prefix.hit.409 ]
  %.1253 = phi ptr addrspace(1) [ %rs4gc.s18.relocated213, %pic.hit.overflow.416 ], [ %rs4gc.s18.relocated208, %pic.miss.call.412 ], [ %rs4gc.s18, %pic.way.live.420 ], [ %rs4gc.s18, %pic.hit.live.400 ], [ %rs4gc.s18, %pic.prefix.hit.404 ], [ %rs4gc.s18, %pic.desc.prefix.hit.409 ]
  %.51 = phi ptr addrspace(1) [ %rs4gc.s7.relocated212, %pic.hit.overflow.416 ], [ %rs4gc.s7.relocated207, %pic.miss.call.412 ], [ %rs4gc.s7.relocated196, %pic.way.live.420 ], [ %rs4gc.s7.relocated196, %pic.hit.live.400 ], [ %rs4gc.s7.relocated196, %pic.prefix.hit.404 ], [ %rs4gc.s7.relocated196, %pic.desc.prefix.hit.409 ]
  %r1660 = phi double [ %r1576, %pic.hit.live.400 ], [ %r1571211, %pic.hit.overflow.416 ], [ %r1596, %pic.prefix.hit.404 ], [ %r1614, %pic.desc.prefix.hit.409 ], [ %r1653, %pic.way.live.420 ], [ %r1659206, %pic.miss.call.412 ]
  br label %pget.recv_merge.394

pic.recv_hdr.414:                                 ; preds = %pget.recv_obj.398
  %r1539 = sub nuw nsw i64 %r1527, 8
  %r1540 = inttoptr i64 %r1539 to ptr
  %r1541 = load i8, ptr %r1540, align 1
  %r1542 = icmp eq i8 %r1541, 2
  %r1543 = sub nuw nsw i64 %r1527, 6
  %r1544 = inttoptr i64 %r1543 to ptr
  %r1545 = load i16, ptr %r1544, align 2
  %r1546 = and i16 %r1545, 2048
  %r1547 = icmp eq i16 %r1546, 0
  %r1548 = load ptr, ptr @perry_ic_options_worker_ts__23, align 8
  %r1549 = icmp ne ptr %r1548, null
  %r1550 = and i1 %r1542, %r1547
  %r1551 = and i1 %r1550, %r1549
  br i1 %r1551, label %pic.token.415, label %pic.desc.classify.405

pic.token.415:                                    ; preds = %pic.recv_hdr.414
  %r1553 = add nuw nsw i64 %r1527, 4
  %r1554 = inttoptr i64 %r1553 to ptr
  %r1555 = load i32, ptr %r1554, align 4
  %r1556 = zext i32 %r1555 to i64
  %r1557 = or i64 %r1556, 4611686018427387904
  %r1558 = icmp ne i32 %r1555, 0
  %r1559 = getelementptr i64, ptr %r1548, i64 0
  %r1560 = load i64, ptr %r1559, align 8
  %r1561 = icmp eq i64 %r1557, %r1560
  %r1562 = and i1 %r1561, %r1558
  br i1 %r1562, label %pic.hit.399, label %pic.prefix.guard.401

pic.hit.overflow.416:                             ; preds = %pic.hit.399
  %r1567 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1568 = bitcast double %r1567 to i64
  %r1569 = and i64 %r1568, 281474976710655
  %r1570 = trunc i64 %r1564 to i32
  %statepoint_token210 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1527, i64 %r1569, i32 %r1570, ptr @perry_ic_options_worker_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated196, ptr addrspace(1) %rs4gc.s18, ptr addrspace(1) %rs4gc.s19) ]
  %r1571211 = call double @llvm.experimental.gc.result.f64(token %statepoint_token210)
  %rs4gc.s7.relocated212 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token210, i32 0, i32 0) ; (%rs4gc.s7.relocated196, %rs4gc.s7.relocated196)
  %rs4gc.s18.relocated213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token210, i32 1, i32 1) ; (%rs4gc.s18, %rs4gc.s18)
  %rs4gc.s19.relocated214 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token210, i32 2, i32 2) ; (%rs4gc.s19, %rs4gc.s19)
  br label %pic.merge.413

pic.hit.inline.417:                               ; preds = %pic.hit.399
  %r1572 = shl i64 %r1564, 3
  %r1573 = add nuw nsw i64 %r1527, 16
  %r1574 = add i64 %r1573, %r1572
  %r1575 = inttoptr i64 %r1574 to ptr
  %r1576 = load double, ptr %r1575, align 8
  %r1577 = bitcast double %r1576 to i64
  %r1578 = icmp eq i64 %r1577, 9222246136947933200
  br i1 %r1578, label %pic.miss.410, label %pic.hit.live.400

pic.ways.418:                                     ; preds = %pic.miss.410
  %r1618 = getelementptr i64, ptr %r1548, i64 4
  %r1619 = load i64, ptr %r1618, align 8
  %r1620 = icmp eq i64 %r1619, %r1557
  %r1621 = getelementptr i64, ptr %r1548, i64 5
  %r1622 = load i64, ptr %r1621, align 8
  %r1623 = select i1 %r1620, i64 %r1622, i64 0
  %r1624 = getelementptr i64, ptr %r1548, i64 6
  %r1625 = load i64, ptr %r1624, align 8
  %r1626 = icmp eq i64 %r1625, %r1557
  %r1627 = getelementptr i64, ptr %r1548, i64 7
  %r1628 = load i64, ptr %r1627, align 8
  %r1629 = select i1 %r1626, i64 %r1628, i64 0
  %r1630 = getelementptr i64, ptr %r1548, i64 8
  %r1631 = load i64, ptr %r1630, align 8
  %r1632 = icmp eq i64 %r1631, %r1557
  %r1633 = getelementptr i64, ptr %r1548, i64 9
  %r1634 = load i64, ptr %r1633, align 8
  %r1635 = select i1 %r1632, i64 %r1634, i64 0
  %r1636 = getelementptr i64, ptr %r1548, i64 10
  %r1637 = load i64, ptr %r1636, align 8
  %r1638 = icmp eq i64 %r1637, %r1557
  %r1639 = getelementptr i64, ptr %r1548, i64 11
  %r1640 = load i64, ptr %r1639, align 8
  %r1641 = select i1 %r1638, i64 %r1640, i64 0
  %r1642 = or i1 %r1620, %r1626
  %r1643 = select i1 %r1620, i64 %r1623, i64 %r1629
  %r1644 = or i1 %r1632, %r1638
  %r1645 = select i1 %r1632, i64 %r1635, i64 %r1641
  %r1646 = or i1 %r1642, %r1644
  %r1647 = select i1 %r1642, i64 %r1643, i64 %r1645
  %r1648 = and i1 %r1558, %r1646
  br i1 %r1648, label %pic.way.load.419, label %pic.miss.call.412

pic.way.load.419:                                 ; preds = %pic.ways.418
  %r1649 = shl i64 %r1647, 3
  %r1650 = add nuw nsw i64 %r1527, 16
  %r1651 = add i64 %r1650, %r1649
  %r1652 = inttoptr i64 %r1651 to ptr
  %r1653 = load double, ptr %r1652, align 8
  %r1654 = bitcast double %r1653 to i64
  %r1655 = icmp eq i64 %r1654, 9222246136947933200
  br i1 %r1655, label %pic.miss.call.412, label %pic.way.live.420

pic.way.live.420:                                 ; preds = %pic.way.load.419
  br label %pic.merge.413

pget.throw_nullish.421:                           ; preds = %pget.recv_bad.392
  %r1664 = zext i1 %r1662 to i32
  %statepoint_token215 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1664, ptr @options_worker_ts_.str.1.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.422:                       ; preds = %pget.recv_bad.392
  %r1665 = load double, ptr @options_worker_ts_.str.1.handle, align 8
  %r1666 = bitcast double %r1665 to i64
  %r1667 = and i64 %r1666, 281474976710655
  %statepoint_token216 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1526, i64 %r1667, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated196, ptr addrspace(1) %rs4gc.s18, ptr addrspace(1) %rs4gc.s19) ]
  %r1668217 = call double @llvm.experimental.gc.result.f64(token %statepoint_token216)
  %rs4gc.s7.relocated218 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token216, i32 0, i32 0) ; (%rs4gc.s7.relocated196, %rs4gc.s7.relocated196)
  %rs4gc.s18.relocated219 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token216, i32 1, i32 1) ; (%rs4gc.s18, %rs4gc.s18)
  %rs4gc.s19.relocated220 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token216, i32 2, i32 2) ; (%rs4gc.s19, %rs4gc.s19)
  br label %pget.recv_merge.394

guarded_add.numeric.423:                          ; preds = %pget.recv_merge.394
  %r1690 = fadd double %r1679, %r1677
  br label %guarded_add.merge.425

guarded_add.dynamic.424:                          ; preds = %pget.recv_merge.394
  %statepoint_token221 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r1679, double %r1677, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.50, ptr addrspace(1) %.0252) ]
  %r1691222 = call double @llvm.experimental.gc.result.f64(token %statepoint_token221)
  %rs4gc.s7.relocated223 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 0, i32 0) ; (%.50, %.50)
  %rs4gc.s18.relocated224 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token221, i32 1, i32 1) ; (%.0252, %.0252)
  br label %guarded_add.merge.425

guarded_add.merge.425:                            ; preds = %guarded_add.dynamic.424, %guarded_add.numeric.423
  %.2254 = phi ptr addrspace(1) [ %.0252, %guarded_add.numeric.423 ], [ %rs4gc.s18.relocated224, %guarded_add.dynamic.424 ]
  %.52 = phi ptr addrspace(1) [ %.50, %guarded_add.numeric.423 ], [ %rs4gc.s7.relocated223, %guarded_add.dynamic.424 ]
  %r1692 = phi double [ %r1690, %guarded_add.numeric.423 ], [ %r1691222, %guarded_add.dynamic.424 ]
  %r1693.rs4i = ptrtoint ptr addrspace(1) %.2254 to i64
  %r1693.rs4o = call i64 asm "", "=r,0"(i64 %r1693.rs4i) #9
  %r1693 = bitcast i64 %r1693.rs4o to double
  %r1694 = bitcast double %r1693 to i64
  %r1695 = and i64 %r1694, -281474976710656
  %r1696 = icmp ne i64 %r1695, 9223090561878065152
  br i1 %r1696, label %str_addref.done.427, label %str_addref.call.426

str_addref.call.426:                              ; preds = %guarded_add.merge.425
  call void @js_string_addref_if_heap_string(double %r1693) #9
  br label %str_addref.done.427

str_addref.done.427:                              ; preds = %str_addref.call.426, %guarded_add.merge.425
  %r1708.rs4i = ptrtoint ptr addrspace(1) %.2254 to i64
  %r1708.rs4o = call i64 asm "", "=r,0"(i64 %r1708.rs4i) #9
  %r1708 = bitcast i64 %r1708.rs4o to double
  store double %r1708, ptr @perry_global_options_worker_ts__7, align 8
  %r1707.rs4i = ptrtoint ptr addrspace(1) %.2254 to i64
  %r1707.rs4o = call i64 asm "", "=r,0"(i64 %r1707.rs4i) #9
  %r1707 = bitcast i64 %r1707.rs4o to double
  %r1697 = bitcast double %r1707 to i64
  %r1705.rs4i = ptrtoint ptr addrspace(1) %.2254 to i64
  %r1705.rs4o = call i64 asm "", "=r,0"(i64 %r1705.rs4i) #9
  %r1705 = bitcast i64 %r1705.rs4o to double
  %r1706 = bitcast double %r1705 to i64
  call void @js_write_barrier_root_nanbox(i64 %r1706) #9
  %r1698 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1699 = icmp ne i32 %r1698, 0
  br i1 %r1699, label %gcpoll.428, label %gcpoll.done.429

gcpoll.428:                                       ; preds = %str_addref.done.427
  %statepoint_token225 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.52) ]
  %rs4gc.s7.relocated226 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token225, i32 0, i32 0) ; (%.52, %.52)
  br label %gcpoll.done.429

gcpoll.done.429:                                  ; preds = %gcpoll.428, %str_addref.done.427
  %.53 = phi ptr addrspace(1) [ %rs4gc.s7.relocated226, %gcpoll.428 ], [ %.52, %str_addref.done.427 ]
  br label %for.update.377
}

; Function Attrs: noinline optsize
define double @perry_fn_options_worker_ts__run(double %arg16) #8 {
entry.0:
  %r1 = bitcast double %arg16 to i64
  %r2 = lshr i64 %r1, 48
  %r3 = icmp ult i64 %r2, 32761
  %r4 = icmp ugt i64 %r2, 32767
  %r5 = or i1 %r3, %r4
  %r6 = and i64 %r1, -4294967296
  %r7 = icmp eq i64 %r6, 9222809086901354496
  %r8 = or i1 %r5, %r7
  br i1 %r8, label %spec_public.fast.1, label %spec_public.fallback.2

spec_public.fast.1:                               ; preds = %entry.0
  %r9 = call double @"perry_fn_options_worker_ts__run$spec_b"(double %arg16)
  ret double %r9

spec_public.fallback.2:                           ; preds = %entry.0
  %r10 = call double @"perry_fn_options_worker_ts__run$generic"(double %arg16)
  ret double %r10
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_options_worker_ts__identity(i64 %this_closure, double %a0, double %a1) #6 {
entry.0:
  %r1 = call double @perry_fn_options_worker_ts__identity(double %a0, double %a1)
  ret double %r1
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_options_worker_ts__run(i64 %this_closure, double %a0) #6 {
entry.0:
  %r1 = call double @perry_fn_options_worker_ts__run(double %a0)
  ret double %r1
}

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_options_worker_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @options_worker_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" {
entry.0:
  %r416 = alloca [32 x double], align 8
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @options_worker_ts_.str.0, i32 124, i32 0, i32 0)
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token3 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token4 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_options_worker_ts, i32 0, i32 0, i32 0, i32 0)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_options_worker_ts__1 to i64)) #9
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_options_worker_ts__2 to i64)) #9
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_options_worker_ts__5 to i64)) #9
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_options_worker_ts__6 to i64)) #9
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_options_worker_ts__7 to i64)) #9
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_mark_entry_module_esm, i32 0, i32 0, i32 0, i32 0)
  %r6 = load double, ptr @options_worker_ts_.str.7.handle, align 8
  %r7 = load double, ptr @options_worker_ts_.str.8.handle, align 8
  %statepoint_token6 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_native_module_named_esm_export_value, i32 2, i32 0, double %r6, double %r7, i32 0, i32 0)
  %statepoint_token7 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0)
  %r10100 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token7)
  %r11 = or i64 %r10100, 9222527611924643840
  %r12 = bitcast i64 %r11 to double
  %r13 = and i64 %r11, 281474976710655
  %r14 = lshr i64 %r11, 48
  %r15 = icmp eq i64 %r14, 32765
  %r16 = icmp ugt i64 %r13, 1048575
  %r17 = and i1 %r15, %r16
  br i1 %r17, label %arr.guard.deref.5, label %arr.fallback.2

arr.fast.1:                                       ; preds = %arr.guard.range.7
  %r76 = add i64 %r32, 24
  %r77 = inttoptr i64 %r76 to ptr
  %r78 = load double, ptr %r77, align 8
  %r79 = bitcast double %r78 to i64
  %r80 = icmp eq i64 %r79, 9222246136947933200
  %r82 = select i1 %r80, double 0x7FFC000000000001, double %r78
  br label %arr.merge.4

arr.fallback.2:                                   ; preds = %arr.guard.live.6, %arr.guard.deref.5, %entry.0
  %statepoint_token101 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7760974052394532888, double %r12, double 2.000000e+00, i32 0, i32 0)
  %r72102 = call double @llvm.experimental.gc.result.f64(token %statepoint_token101)
  br label %arr.merge.4

arr.guard.oob.3:                                  ; preds = %arr.guard.range.7
  br label %arr.merge.4

arr.merge.4:                                      ; preds = %arr.guard.oob.3, %arr.fallback.2, %arr.fast.1
  %r83 = phi double [ %r82, %arr.fast.1 ], [ %r72102, %arr.fallback.2 ], [ 0x7FFC000000000001, %arr.guard.oob.3 ]
  %r84 = load double, ptr @options_worker_ts_.str.9.handle, align 8
  %statepoint_token103 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_fs_read_file_dispatch, i32 2, i32 0, double %r83, double %r84, i32 0, i32 0)
  %r85104 = call double @llvm.experimental.gc.result.f64(token %statepoint_token103)
  %rs4gc.b6 = bitcast double %r85104 to i64
  %rs4gc.s6 = inttoptr i64 %rs4gc.b6 to ptr addrspace(1)
  %r86.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r86 = call i64 asm "", "=r,0"(i64 %r86.rs4i) #9
  %r87 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r88 = icmp ne i32 %r87, 0
  br i1 %r88, label %shadow.root.barrier.8, label %shadow.root.barrier.done.9

arr.guard.deref.5:                                ; preds = %entry.0
  %r18 = bitcast double %r12 to i64
  %r19 = and i64 %r18, 281474976710655
  %r20 = sub nsw i64 %r19, 8
  %r21 = inttoptr i64 %r20 to ptr
  %r22 = load i8, ptr %r21, align 1
  %r23 = icmp eq i8 %r22, 1
  %r24 = sub nsw i64 %r19, 7
  %r25 = inttoptr i64 %r24 to ptr
  %r26 = load i8, ptr %r25, align 1
  %r27 = and i8 %r26, -128
  %r28 = icmp ne i8 %r27, 0
  %r29 = inttoptr i64 %r19 to ptr
  %r30 = load i64, ptr %r29, align 8
  %r31 = and i1 %r23, %r28
  %r32 = select i1 %r31, i64 %r30, i64 %r19
  %r33 = lshr i64 %r32, 48
  %r34 = icmp eq i64 %r33, 0
  %r35 = icmp ugt i64 %r32, 1048575
  %r36 = and i1 %r34, %r35
  br i1 %r36, label %arr.guard.live.6, label %arr.fallback.2

arr.guard.live.6:                                 ; preds = %arr.guard.deref.5
  %r37 = sub nuw i64 %r32, 8
  %r38 = inttoptr i64 %r37 to ptr
  %r39 = load i8, ptr %r38, align 1
  %r40 = icmp eq i8 %r39, 1
  %r41 = sub nuw i64 %r32, 7
  %r42 = inttoptr i64 %r41 to ptr
  %r43 = load i8, ptr %r42, align 1
  %r44 = and i8 %r43, -128
  %r45 = icmp eq i8 %r44, 0
  %r46 = sub nuw i64 %r32, 6
  %r47 = inttoptr i64 %r46 to ptr
  %r48 = load i16, ptr %r47, align 2
  %r49 = and i16 %r48, 1024
  %r50 = icmp eq i16 %r49, 0
  %r51 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r52 = icmp eq i8 %r51, 0
  %r53 = inttoptr i64 %r32 to ptr
  %r54 = load i32, ptr %r53, align 4
  %r55 = getelementptr i8, ptr %r53, i64 4
  %r56 = load i32, ptr %r55, align 4
  %r60 = icmp ule i32 %r54, 16000000
  %r61 = icmp ule i32 %r56, 16000000
  %r62 = icmp ule i32 %r54, %r56
  %r63 = and i1 %r40, %r45
  %r64 = and i1 %r63, %r50
  %r65 = and i1 %r64, %r52
  %r67 = and i1 %r65, %r60
  %r68 = and i1 %r67, %r61
  %r69 = and i1 %r68, %r62
  br i1 %r69, label %arr.guard.range.7, label %arr.fallback.2

arr.guard.range.7:                                ; preds = %arr.guard.live.6
  %r59 = icmp ult i32 2, %r54
  br i1 %r59, label %arr.fast.1, label %arr.guard.oob.3

shadow.root.barrier.8:                            ; preds = %arr.merge.4
  call void @js_write_barrier_root_nanbox(i64 %r86) #9
  br label %shadow.root.barrier.done.9

shadow.root.barrier.done.9:                       ; preds = %shadow.root.barrier.8, %arr.merge.4
  %statepoint_token105 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6) ]
  %r89106 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token105)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 0, i32 0) ; (%rs4gc.s6, %rs4gc.s6)
  %r90 = or i64 %r89106, 9222527611924643840
  %r91 = bitcast i64 %r90 to double
  %r92 = and i64 %r90, 281474976710655
  %r93 = lshr i64 %r90, 48
  %r94 = icmp eq i64 %r93, 32765
  %r95 = icmp ugt i64 %r92, 1048575
  %r96 = and i1 %r94, %r95
  br i1 %r96, label %arr.guard.deref.14, label %arr.fallback.11

arr.fast.10:                                      ; preds = %arr.guard.range.16
  %r155 = add i64 %r111, 32
  %r156 = inttoptr i64 %r155 to ptr
  %r157 = load double, ptr %r156, align 8
  %r158 = bitcast double %r157 to i64
  %r159 = icmp eq i64 %r158, 9222246136947933200
  %r161 = select i1 %r159, double 0x7FFC000000000001, double %r157
  br label %arr.merge.13

arr.fallback.11:                                  ; preds = %arr.guard.live.15, %arr.guard.deref.14, %shadow.root.barrier.done.9
  %statepoint_token107 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7760974052394532889, double %r91, double 3.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated) ]
  %r151108 = call double @llvm.experimental.gc.result.f64(token %statepoint_token107)
  %rs4gc.s6.relocated109 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token107, i32 0, i32 0) ; (%rs4gc.s6.relocated, %rs4gc.s6.relocated)
  br label %arr.merge.13

arr.guard.oob.12:                                 ; preds = %arr.guard.range.16
  br label %arr.merge.13

arr.merge.13:                                     ; preds = %arr.guard.oob.12, %arr.fallback.11, %arr.fast.10
  %.0 = phi ptr addrspace(1) [ %rs4gc.s6.relocated, %arr.fast.10 ], [ %rs4gc.s6.relocated, %arr.guard.oob.12 ], [ %rs4gc.s6.relocated109, %arr.fallback.11 ]
  %r162 = phi double [ %r161, %arr.fast.10 ], [ %r151108, %arr.fallback.11 ], [ 0x7FFC000000000001, %arr.guard.oob.12 ]
  store double %r162, ptr @perry_global_options_worker_ts__1, align 8
  %r163 = bitcast double %r162 to i64
  call void @js_write_barrier_root_nanbox(i64 %r163) #9
  %statepoint_token110 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r164111 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token110)
  %rs4gc.s6.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 0, i32 0) ; (%.0, %.0)
  %r165 = or i64 %r164111, 9222527611924643840
  %r166 = bitcast i64 %r165 to double
  %r167 = and i64 %r165, 281474976710655
  %r168 = lshr i64 %r165, 48
  %r169 = icmp eq i64 %r168, 32765
  %r170 = icmp ugt i64 %r167, 1048575
  %r171 = and i1 %r169, %r170
  br i1 %r171, label %arr.guard.deref.21, label %arr.fallback.18

arr.guard.deref.14:                               ; preds = %shadow.root.barrier.done.9
  %r97 = bitcast double %r91 to i64
  %r98 = and i64 %r97, 281474976710655
  %r99 = sub nsw i64 %r98, 8
  %r100 = inttoptr i64 %r99 to ptr
  %r101 = load i8, ptr %r100, align 1
  %r102 = icmp eq i8 %r101, 1
  %r103 = sub nsw i64 %r98, 7
  %r104 = inttoptr i64 %r103 to ptr
  %r105 = load i8, ptr %r104, align 1
  %r106 = and i8 %r105, -128
  %r107 = icmp ne i8 %r106, 0
  %r108 = inttoptr i64 %r98 to ptr
  %r109 = load i64, ptr %r108, align 8
  %r110 = and i1 %r102, %r107
  %r111 = select i1 %r110, i64 %r109, i64 %r98
  %r112 = lshr i64 %r111, 48
  %r113 = icmp eq i64 %r112, 0
  %r114 = icmp ugt i64 %r111, 1048575
  %r115 = and i1 %r113, %r114
  br i1 %r115, label %arr.guard.live.15, label %arr.fallback.11

arr.guard.live.15:                                ; preds = %arr.guard.deref.14
  %r116 = sub nuw i64 %r111, 8
  %r117 = inttoptr i64 %r116 to ptr
  %r118 = load i8, ptr %r117, align 1
  %r119 = icmp eq i8 %r118, 1
  %r120 = sub nuw i64 %r111, 7
  %r121 = inttoptr i64 %r120 to ptr
  %r122 = load i8, ptr %r121, align 1
  %r123 = and i8 %r122, -128
  %r124 = icmp eq i8 %r123, 0
  %r125 = sub nuw i64 %r111, 6
  %r126 = inttoptr i64 %r125 to ptr
  %r127 = load i16, ptr %r126, align 2
  %r128 = and i16 %r127, 1024
  %r129 = icmp eq i16 %r128, 0
  %r130 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r131 = icmp eq i8 %r130, 0
  %r132 = inttoptr i64 %r111 to ptr
  %r133 = load i32, ptr %r132, align 4
  %r134 = getelementptr i8, ptr %r132, i64 4
  %r135 = load i32, ptr %r134, align 4
  %r139 = icmp ule i32 %r133, 16000000
  %r140 = icmp ule i32 %r135, 16000000
  %r141 = icmp ule i32 %r133, %r135
  %r142 = and i1 %r119, %r124
  %r143 = and i1 %r142, %r129
  %r144 = and i1 %r143, %r131
  %r146 = and i1 %r144, %r139
  %r147 = and i1 %r146, %r140
  %r148 = and i1 %r147, %r141
  br i1 %r148, label %arr.guard.range.16, label %arr.fallback.11

arr.guard.range.16:                               ; preds = %arr.guard.live.15
  %r138 = icmp ult i32 3, %r133
  br i1 %r138, label %arr.fast.10, label %arr.guard.oob.12

arr.fast.17:                                      ; preds = %arr.guard.range.23
  %r230 = add i64 %r186, 64
  %r231 = inttoptr i64 %r230 to ptr
  %r232 = load double, ptr %r231, align 8
  %r233 = bitcast double %r232 to i64
  %r234 = icmp eq i64 %r233, 9222246136947933200
  %r236 = select i1 %r234, double 0x7FFC000000000001, double %r232
  br label %arr.merge.20

arr.fallback.18:                                  ; preds = %arr.guard.live.22, %arr.guard.deref.21, %arr.merge.13
  %statepoint_token113 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7760974052394532890, double %r166, double 7.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated112) ]
  %r226114 = call double @llvm.experimental.gc.result.f64(token %statepoint_token113)
  %rs4gc.s6.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 0, i32 0) ; (%rs4gc.s6.relocated112, %rs4gc.s6.relocated112)
  br label %arr.merge.20

arr.guard.oob.19:                                 ; preds = %arr.guard.range.23
  br label %arr.merge.20

arr.merge.20:                                     ; preds = %arr.guard.oob.19, %arr.fallback.18, %arr.fast.17
  %.1 = phi ptr addrspace(1) [ %rs4gc.s6.relocated112, %arr.fast.17 ], [ %rs4gc.s6.relocated112, %arr.guard.oob.19 ], [ %rs4gc.s6.relocated115, %arr.fallback.18 ]
  %r237 = phi double [ %r236, %arr.fast.17 ], [ %r226114, %arr.fallback.18 ], [ 0x7FFC000000000001, %arr.guard.oob.19 ]
  %r238 = bitcast double %r237 to i64
  %r239 = and i64 %r238, 9221120237041090560
  %r240 = icmp ne i64 %r239, 9221120237041090560
  br i1 %r240, label %truthy.num.24, label %truthy.tag.25

arr.guard.deref.21:                               ; preds = %arr.merge.13
  %r172 = bitcast double %r166 to i64
  %r173 = and i64 %r172, 281474976710655
  %r174 = sub nsw i64 %r173, 8
  %r175 = inttoptr i64 %r174 to ptr
  %r176 = load i8, ptr %r175, align 1
  %r177 = icmp eq i8 %r176, 1
  %r178 = sub nsw i64 %r173, 7
  %r179 = inttoptr i64 %r178 to ptr
  %r180 = load i8, ptr %r179, align 1
  %r181 = and i8 %r180, -128
  %r182 = icmp ne i8 %r181, 0
  %r183 = inttoptr i64 %r173 to ptr
  %r184 = load i64, ptr %r183, align 8
  %r185 = and i1 %r177, %r182
  %r186 = select i1 %r185, i64 %r184, i64 %r173
  %r187 = lshr i64 %r186, 48
  %r188 = icmp eq i64 %r187, 0
  %r189 = icmp ugt i64 %r186, 1048575
  %r190 = and i1 %r188, %r189
  br i1 %r190, label %arr.guard.live.22, label %arr.fallback.18

arr.guard.live.22:                                ; preds = %arr.guard.deref.21
  %r191 = sub nuw i64 %r186, 8
  %r192 = inttoptr i64 %r191 to ptr
  %r193 = load i8, ptr %r192, align 1
  %r194 = icmp eq i8 %r193, 1
  %r195 = sub nuw i64 %r186, 7
  %r196 = inttoptr i64 %r195 to ptr
  %r197 = load i8, ptr %r196, align 1
  %r198 = and i8 %r197, -128
  %r199 = icmp eq i8 %r198, 0
  %r200 = sub nuw i64 %r186, 6
  %r201 = inttoptr i64 %r200 to ptr
  %r202 = load i16, ptr %r201, align 2
  %r203 = and i16 %r202, 1024
  %r204 = icmp eq i16 %r203, 0
  %r205 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r206 = icmp eq i8 %r205, 0
  %r207 = inttoptr i64 %r186 to ptr
  %r208 = load i32, ptr %r207, align 4
  %r209 = getelementptr i8, ptr %r207, i64 4
  %r210 = load i32, ptr %r209, align 4
  %r214 = icmp ule i32 %r208, 16000000
  %r215 = icmp ule i32 %r210, 16000000
  %r216 = icmp ule i32 %r208, %r210
  %r217 = and i1 %r194, %r199
  %r218 = and i1 %r217, %r204
  %r219 = and i1 %r218, %r206
  %r221 = and i1 %r219, %r214
  %r222 = and i1 %r221, %r215
  %r223 = and i1 %r222, %r216
  br i1 %r223, label %arr.guard.range.23, label %arr.fallback.18

arr.guard.range.23:                               ; preds = %arr.guard.live.22
  %r213 = icmp ult i32 7, %r208
  br i1 %r213, label %arr.fast.17, label %arr.guard.oob.19

truthy.num.24:                                    ; preds = %arr.merge.20
  %r241 = fcmp one double %r237, 0.000000e+00
  br label %truthy.merge.27

truthy.tag.25:                                    ; preds = %arr.merge.20
  %r242 = icmp eq i64 %r238, 9222246136947933188
  %r243 = icmp eq i64 %r238, 9222246136947933187
  %r244 = icmp eq i64 %r238, 9222246136947933185
  %r245 = icmp eq i64 %r238, 9222246136947933186
  %r246 = or i1 %r243, %r244
  %r247 = or i1 %r246, %r245
  %r248 = or i1 %r242, %r247
  br i1 %r248, label %truthy.merge.27, label %truthy.obj.28

truthy.slow.26:                                   ; preds = %truthy.obj.28
  %r254 = call i32 @js_is_truthy(double %r237) #9
  %r255 = icmp ne i32 %r254, 0
  br label %truthy.merge.27

truthy.merge.27:                                  ; preds = %truthy.obj.28, %truthy.slow.26, %truthy.tag.25, %truthy.num.24
  %r256 = phi i1 [ %r241, %truthy.num.24 ], [ %r242, %truthy.tag.25 ], [ true, %truthy.obj.28 ], [ %r255, %truthy.slow.26 ]
  br i1 %r256, label %logical.merge.30, label %logical.then.29

truthy.obj.28:                                    ; preds = %truthy.tag.25
  %r249 = lshr i64 %r238, 48
  %r250 = icmp eq i64 %r249, 32765
  %r251 = and i64 %r238, 281474976710655
  %r252 = icmp ne i64 %r251, 0
  %r253 = and i1 %r250, %r252
  br i1 %r253, label %truthy.merge.27, label %truthy.slow.26

logical.then.29:                                  ; preds = %truthy.merge.27
  %r257 = load double, ptr @options_worker_ts_.str.10.handle, align 8
  br label %logical.merge.30

logical.merge.30:                                 ; preds = %logical.then.29, %truthy.merge.27
  %r258 = phi double [ %r237, %truthy.merge.27 ], [ %r257, %logical.then.29 ]
  %statepoint_token116 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_number_coerce, i32 1, i32 0, double %r258, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1) ]
  %r259117 = call double @llvm.experimental.gc.result.f64(token %statepoint_token116)
  %rs4gc.s6.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 0, i32 0) ; (%.1, %.1)
  store double %r259117, ptr @perry_global_options_worker_ts__2, align 8
  %r260 = bitcast double %r259117 to i64
  call void @js_write_barrier_root_nanbox(i64 %r260) #9
  %statepoint_token119 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated118) ]
  %r262120 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token119)
  %rs4gc.s6.relocated121 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 0, i32 0) ; (%rs4gc.s6.relocated118, %rs4gc.s6.relocated118)
  %r263 = or i64 %r262120, 9222527611924643840
  %r264 = bitcast i64 %r263 to double
  %r265 = and i64 %r263, 281474976710655
  %r266 = lshr i64 %r263, 48
  %r267 = icmp eq i64 %r266, 32765
  %r268 = icmp ugt i64 %r265, 1048575
  %r269 = and i1 %r267, %r268
  br i1 %r269, label %arr.guard.deref.35, label %arr.fallback.32

arr.fast.31:                                      ; preds = %arr.guard.range.37
  %r328 = add i64 %r284, 40
  %r329 = inttoptr i64 %r328 to ptr
  %r330 = load double, ptr %r329, align 8
  %r331 = bitcast double %r330 to i64
  %r332 = icmp eq i64 %r331, 9222246136947933200
  %r334 = select i1 %r332, double 0x7FFC000000000001, double %r330
  br label %arr.merge.34

arr.fallback.32:                                  ; preds = %arr.guard.live.36, %arr.guard.deref.35, %logical.merge.30
  %statepoint_token122 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7760974052394532891, double %r264, double 4.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated121) ]
  %r324123 = call double @llvm.experimental.gc.result.f64(token %statepoint_token122)
  %rs4gc.s6.relocated124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token122, i32 0, i32 0) ; (%rs4gc.s6.relocated121, %rs4gc.s6.relocated121)
  br label %arr.merge.34

arr.guard.oob.33:                                 ; preds = %arr.guard.range.37
  br label %arr.merge.34

arr.merge.34:                                     ; preds = %arr.guard.oob.33, %arr.fallback.32, %arr.fast.31
  %.2 = phi ptr addrspace(1) [ %rs4gc.s6.relocated121, %arr.fast.31 ], [ %rs4gc.s6.relocated121, %arr.guard.oob.33 ], [ %rs4gc.s6.relocated124, %arr.fallback.32 ]
  %r335 = phi double [ %r334, %arr.fast.31 ], [ %r324123, %arr.fallback.32 ], [ 0x7FFC000000000001, %arr.guard.oob.33 ]
  %statepoint_token125 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_number_coerce, i32 1, i32 0, double %r335, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r336126 = call double @llvm.experimental.gc.result.f64(token %statepoint_token125)
  %rs4gc.s6.relocated127 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token125, i32 0, i32 0) ; (%.2, %.2)
  %statepoint_token128 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated127) ]
  %r338129 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token128)
  %rs4gc.s6.relocated130 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token128, i32 0, i32 0) ; (%rs4gc.s6.relocated127, %rs4gc.s6.relocated127)
  %r339 = or i64 %r338129, 9222527611924643840
  %r340 = bitcast i64 %r339 to double
  %r341 = and i64 %r339, 281474976710655
  %r342 = lshr i64 %r339, 48
  %r343 = icmp eq i64 %r342, 32765
  %r344 = icmp ugt i64 %r341, 1048575
  %r345 = and i1 %r343, %r344
  br i1 %r345, label %arr.guard.deref.42, label %arr.fallback.39

arr.guard.deref.35:                               ; preds = %logical.merge.30
  %r270 = bitcast double %r264 to i64
  %r271 = and i64 %r270, 281474976710655
  %r272 = sub nsw i64 %r271, 8
  %r273 = inttoptr i64 %r272 to ptr
  %r274 = load i8, ptr %r273, align 1
  %r275 = icmp eq i8 %r274, 1
  %r276 = sub nsw i64 %r271, 7
  %r277 = inttoptr i64 %r276 to ptr
  %r278 = load i8, ptr %r277, align 1
  %r279 = and i8 %r278, -128
  %r280 = icmp ne i8 %r279, 0
  %r281 = inttoptr i64 %r271 to ptr
  %r282 = load i64, ptr %r281, align 8
  %r283 = and i1 %r275, %r280
  %r284 = select i1 %r283, i64 %r282, i64 %r271
  %r285 = lshr i64 %r284, 48
  %r286 = icmp eq i64 %r285, 0
  %r287 = icmp ugt i64 %r284, 1048575
  %r288 = and i1 %r286, %r287
  br i1 %r288, label %arr.guard.live.36, label %arr.fallback.32

arr.guard.live.36:                                ; preds = %arr.guard.deref.35
  %r289 = sub nuw i64 %r284, 8
  %r290 = inttoptr i64 %r289 to ptr
  %r291 = load i8, ptr %r290, align 1
  %r292 = icmp eq i8 %r291, 1
  %r293 = sub nuw i64 %r284, 7
  %r294 = inttoptr i64 %r293 to ptr
  %r295 = load i8, ptr %r294, align 1
  %r296 = and i8 %r295, -128
  %r297 = icmp eq i8 %r296, 0
  %r298 = sub nuw i64 %r284, 6
  %r299 = inttoptr i64 %r298 to ptr
  %r300 = load i16, ptr %r299, align 2
  %r301 = and i16 %r300, 1024
  %r302 = icmp eq i16 %r301, 0
  %r303 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r304 = icmp eq i8 %r303, 0
  %r305 = inttoptr i64 %r284 to ptr
  %r306 = load i32, ptr %r305, align 4
  %r307 = getelementptr i8, ptr %r305, i64 4
  %r308 = load i32, ptr %r307, align 4
  %r312 = icmp ule i32 %r306, 16000000
  %r313 = icmp ule i32 %r308, 16000000
  %r314 = icmp ule i32 %r306, %r308
  %r315 = and i1 %r292, %r297
  %r316 = and i1 %r315, %r302
  %r317 = and i1 %r316, %r304
  %r319 = and i1 %r317, %r312
  %r320 = and i1 %r319, %r313
  %r321 = and i1 %r320, %r314
  br i1 %r321, label %arr.guard.range.37, label %arr.fallback.32

arr.guard.range.37:                               ; preds = %arr.guard.live.36
  %r311 = icmp ult i32 4, %r306
  br i1 %r311, label %arr.fast.31, label %arr.guard.oob.33

arr.fast.38:                                      ; preds = %arr.guard.range.44
  %r404 = add i64 %r360, 48
  %r405 = inttoptr i64 %r404 to ptr
  %r406 = load double, ptr %r405, align 8
  %r407 = bitcast double %r406 to i64
  %r408 = icmp eq i64 %r407, 9222246136947933200
  %r410 = select i1 %r408, double 0x7FFC000000000001, double %r406
  br label %arr.merge.41

arr.fallback.39:                                  ; preds = %arr.guard.live.43, %arr.guard.deref.42, %arr.merge.34
  %statepoint_token131 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7760974052394532892, double %r340, double 5.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated130) ]
  %r400132 = call double @llvm.experimental.gc.result.f64(token %statepoint_token131)
  %rs4gc.s6.relocated133 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token131, i32 0, i32 0) ; (%rs4gc.s6.relocated130, %rs4gc.s6.relocated130)
  br label %arr.merge.41

arr.guard.oob.40:                                 ; preds = %arr.guard.range.44
  br label %arr.merge.41

arr.merge.41:                                     ; preds = %arr.guard.oob.40, %arr.fallback.39, %arr.fast.38
  %.3 = phi ptr addrspace(1) [ %rs4gc.s6.relocated130, %arr.fast.38 ], [ %rs4gc.s6.relocated130, %arr.guard.oob.40 ], [ %rs4gc.s6.relocated133, %arr.fallback.39 ]
  %r411 = phi double [ %r410, %arr.fast.38 ], [ %r400132, %arr.fallback.39 ], [ 0x7FFC000000000001, %arr.guard.oob.40 ]
  %statepoint_token134 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_number_coerce, i32 1, i32 0, double %r411, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3) ]
  %r412135 = call double @llvm.experimental.gc.result.f64(token %statepoint_token134)
  %rs4gc.s6.relocated136 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 0, i32 0) ; (%.3, %.3)
  %r413 = load double, ptr @options_worker_ts_.str.11.handle, align 8
  %r414.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6.relocated136 to i64
  %r414.rs4o = call i64 asm "", "=r,0"(i64 %r414.rs4i) #9
  %r414 = bitcast i64 %r414.rs4o to double
  %r415 = load double, ptr @options_worker_ts_.str.12.handle, align 8
  %r417 = getelementptr double, ptr %r416, i64 0
  store double %r413, ptr %r417, align 8
  %r418 = getelementptr double, ptr %r416, i64 1
  store double %r414, ptr %r418, align 8
  %r419 = getelementptr double, ptr %r416, i64 2
  store double %r415, ptr %r419, align 8
  %r420 = ptrtoint ptr %r416 to i64
  %statepoint_token137 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r420, i32 3, i32 0, i32 0)
  %r421138 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token137)
  %r422 = or i64 %r421138, 9223090561878065152
  %r423 = bitcast i64 %r422 to double
  %statepoint_token139 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r423, i32 0, i32 0)
  %r424140 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token139)
  %statepoint_token141 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r424140, i32 0, i32 0)
  %r425142 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token141)
  %r426 = bitcast i64 %r425142 to double
  %r427 = and i64 %r425142, 281474976710655
  %r428 = lshr i64 %r425142, 48
  %r429 = and i64 %r428, 65533
  %r430 = icmp eq i64 %r429, 32765
  br i1 %r430, label %pget.recv_ok.46, label %pget.recv_other.50

arr.guard.deref.42:                               ; preds = %arr.merge.34
  %r346 = bitcast double %r340 to i64
  %r347 = and i64 %r346, 281474976710655
  %r348 = sub nsw i64 %r347, 8
  %r349 = inttoptr i64 %r348 to ptr
  %r350 = load i8, ptr %r349, align 1
  %r351 = icmp eq i8 %r350, 1
  %r352 = sub nsw i64 %r347, 7
  %r353 = inttoptr i64 %r352 to ptr
  %r354 = load i8, ptr %r353, align 1
  %r355 = and i8 %r354, -128
  %r356 = icmp ne i8 %r355, 0
  %r357 = inttoptr i64 %r347 to ptr
  %r358 = load i64, ptr %r357, align 8
  %r359 = and i1 %r351, %r356
  %r360 = select i1 %r359, i64 %r358, i64 %r347
  %r361 = lshr i64 %r360, 48
  %r362 = icmp eq i64 %r361, 0
  %r363 = icmp ugt i64 %r360, 1048575
  %r364 = and i1 %r362, %r363
  br i1 %r364, label %arr.guard.live.43, label %arr.fallback.39

arr.guard.live.43:                                ; preds = %arr.guard.deref.42
  %r365 = sub nuw i64 %r360, 8
  %r366 = inttoptr i64 %r365 to ptr
  %r367 = load i8, ptr %r366, align 1
  %r368 = icmp eq i8 %r367, 1
  %r369 = sub nuw i64 %r360, 7
  %r370 = inttoptr i64 %r369 to ptr
  %r371 = load i8, ptr %r370, align 1
  %r372 = and i8 %r371, -128
  %r373 = icmp eq i8 %r372, 0
  %r374 = sub nuw i64 %r360, 6
  %r375 = inttoptr i64 %r374 to ptr
  %r376 = load i16, ptr %r375, align 2
  %r377 = and i16 %r376, 1024
  %r378 = icmp eq i16 %r377, 0
  %r379 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r380 = icmp eq i8 %r379, 0
  %r381 = inttoptr i64 %r360 to ptr
  %r382 = load i32, ptr %r381, align 4
  %r383 = getelementptr i8, ptr %r381, i64 4
  %r384 = load i32, ptr %r383, align 4
  %r388 = icmp ule i32 %r382, 16000000
  %r389 = icmp ule i32 %r384, 16000000
  %r390 = icmp ule i32 %r382, %r384
  %r391 = and i1 %r368, %r373
  %r392 = and i1 %r391, %r378
  %r393 = and i1 %r392, %r380
  %r395 = and i1 %r393, %r388
  %r396 = and i1 %r395, %r389
  %r397 = and i1 %r396, %r390
  br i1 %r397, label %arr.guard.range.44, label %arr.fallback.39

arr.guard.range.44:                               ; preds = %arr.guard.live.43
  %r387 = icmp ult i32 5, %r382
  br i1 %r387, label %arr.fast.38, label %arr.guard.oob.40

pget.recv_sso.45:                                 ; preds = %pget.recv_other.50
  %r568 = load double, ptr @options_worker_ts_.str.13.handle, align 8
  %r569 = bitcast double %r568 to i64
  %r570 = and i64 %r569, 281474976710655
  %statepoint_token143 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r425142, i64 %r570, i32 0, i32 0)
  %r571144 = call double @llvm.experimental.gc.result.f64(token %statepoint_token143)
  br label %pget.recv_merge.49

pget.recv_ok.46:                                  ; preds = %arr.merge.41
  %r437 = icmp ugt i64 %r427, 1048575
  br i1 %r437, label %pic.recv_hdr.67, label %pic.miss.cold.64

pget.recv_bad.47:                                 ; preds = %pget.check_class_ref.51
  %r560 = icmp eq i64 %r425142, 9222246136947933185
  %r561 = icmp eq i64 %r425142, 9222246136947933186
  %r562 = or i1 %r560, %r561
  br i1 %r562, label %pget.throw_nullish.74, label %pget.recv_undef_return.75

pget.recv_class_ref.48:                           ; preds = %pget.check_class_ref.51
  %r433 = load double, ptr @options_worker_ts_.str.13.handle, align 8
  %r434 = bitcast double %r433 to i64
  %r435 = and i64 %r434, 281474976710655
  %statepoint_token145 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532893, i64 %r425142, i64 %r435, i32 0, i32 0)
  %r436146 = call double @llvm.experimental.gc.result.f64(token %statepoint_token145)
  br label %pget.recv_merge.49

pget.recv_merge.49:                               ; preds = %pget.recv_undef_return.75, %pic.merge.66, %pget.recv_class_ref.48, %pget.recv_sso.45
  %r572 = phi double [ %r559, %pic.merge.66 ], [ %r567153, %pget.recv_undef_return.75 ], [ %r571144, %pget.recv_sso.45 ], [ %r436146, %pget.recv_class_ref.48 ]
  store double %r572, ptr @perry_global_options_worker_ts__5, align 8
  %r573 = bitcast double %r572 to i64
  call void @js_write_barrier_root_nanbox(i64 %r573) #9
  %r574 = load double, ptr @options_worker_ts_.str.14.handle, align 8
  %r575 = load double, ptr @options_worker_ts_.str.15.handle, align 8
  %r576 = load double, ptr @options_worker_ts_.str.16.handle, align 8
  %r577 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r578 = load double, ptr @options_worker_ts_.str.18.handle, align 8
  %r579 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  br label %arena_state.init.76

pget.recv_other.50:                               ; preds = %arr.merge.41
  %r431 = icmp eq i64 %r428, 32761
  br i1 %r431, label %pget.recv_sso.45, label %pget.check_class_ref.51

pget.check_class_ref.51:                          ; preds = %pget.recv_other.50
  %r432 = icmp eq i64 %r428, 32766
  br i1 %r432, label %pget.recv_class_ref.48, label %pget.recv_bad.47

pic.hit.52:                                       ; preds = %pic.token.68
  %r462 = getelementptr i64, ptr %r447, i64 1
  %r463 = load i64, ptr %r462, align 8
  %r464 = and i64 %r463, 1073741824
  %r465 = icmp ne i64 %r464, 0
  br i1 %r465, label %pic.hit.overflow.69, label %pic.hit.inline.70

pic.hit.live.53:                                  ; preds = %pic.hit.inline.70
  br label %pic.merge.66

pic.prefix.guard.54:                              ; preds = %pic.token.68
  %r478 = getelementptr i64, ptr %r447, i64 2
  %r479 = load i64, ptr %r478, align 8
  %r480 = icmp ne i64 %r479, 0
  br i1 %r480, label %pic.prefix.meta.55, label %pic.miss.63

pic.prefix.meta.55:                               ; preds = %pic.prefix.guard.54
  %r481 = add nuw nsw i64 %r427, 8
  %r482 = inttoptr i64 %r481 to ptr
  %r483 = load i64, ptr %r482, align 8
  %r484 = icmp ne i64 %r483, 0
  br i1 %r484, label %pic.prefix.token.56, label %pic.miss.63

pic.prefix.token.56:                              ; preds = %pic.prefix.meta.55
  %r485 = inttoptr i64 %r483 to ptr
  %r486 = getelementptr i64, ptr %r485, i64 6
  %r487 = load i64, ptr %r486, align 8
  %r488 = icmp eq i64 %r487, %r479
  br i1 %r488, label %pic.prefix.hit.57, label %pic.miss.63

pic.prefix.hit.57:                                ; preds = %pic.prefix.token.56
  %r489 = getelementptr i64, ptr %r447, i64 1
  %r490 = load i64, ptr %r489, align 8
  %r491 = shl i64 %r490, 3
  %r492 = add nuw nsw i64 %r427, 16
  %r493 = add i64 %r492, %r491
  %r494 = inttoptr i64 %r493 to ptr
  %r495 = load double, ptr %r494, align 8
  br label %pic.merge.66

pic.desc.classify.58:                             ; preds = %pic.recv_hdr.67
  %r451 = and i1 %r441, %r448
  br i1 %r451, label %pic.desc.prefix.guard.59, label %pic.miss.cold.64

pic.desc.prefix.guard.59:                         ; preds = %pic.desc.classify.58
  %r496 = getelementptr i64, ptr %r447, i64 2
  %r497 = load i64, ptr %r496, align 8
  %r498 = icmp ne i64 %r497, 0
  br i1 %r498, label %pic.desc.prefix.meta.60, label %pic.miss.cold.64

pic.desc.prefix.meta.60:                          ; preds = %pic.desc.prefix.guard.59
  %r499 = add nuw nsw i64 %r427, 8
  %r500 = inttoptr i64 %r499 to ptr
  %r501 = load i64, ptr %r500, align 8
  %r502 = icmp ne i64 %r501, 0
  br i1 %r502, label %pic.desc.prefix.token.61, label %pic.miss.cold.64

pic.desc.prefix.token.61:                         ; preds = %pic.desc.prefix.meta.60
  %r503 = inttoptr i64 %r501 to ptr
  %r504 = getelementptr i64, ptr %r503, i64 6
  %r505 = load i64, ptr %r504, align 8
  %r506 = icmp eq i64 %r505, %r497
  br i1 %r506, label %pic.desc.prefix.hit.62, label %pic.miss.cold.64

pic.desc.prefix.hit.62:                           ; preds = %pic.desc.prefix.token.61
  %r507 = getelementptr i64, ptr %r447, i64 1
  %r508 = load i64, ptr %r507, align 8
  %r509 = shl i64 %r508, 3
  %r510 = add nuw nsw i64 %r427, 16
  %r511 = add i64 %r510, %r509
  %r512 = inttoptr i64 %r511 to ptr
  %r513 = load double, ptr %r512, align 8
  br label %pic.merge.66

pic.miss.63:                                      ; preds = %pic.hit.inline.70, %pic.prefix.token.56, %pic.prefix.meta.55, %pic.prefix.guard.54
  %r514 = getelementptr i64, ptr %r447, i64 3
  %r515 = load i64, ptr %r514, align 8
  %r516 = icmp sgt i64 %r515, 0
  br i1 %r516, label %pic.ways.71, label %pic.miss.call.65

pic.miss.cold.64:                                 ; preds = %pic.desc.prefix.token.61, %pic.desc.prefix.meta.60, %pic.desc.prefix.guard.59, %pic.desc.classify.58, %pget.recv_ok.46
  br label %pic.miss.call.65

pic.miss.call.65:                                 ; preds = %pic.way.load.72, %pic.ways.71, %pic.miss.cold.64, %pic.miss.63
  %r555 = load double, ptr @options_worker_ts_.str.13.handle, align 8
  %r556 = bitcast double %r555 to i64
  %r557 = and i64 %r556, 281474976710655
  %statepoint_token147 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r427, i64 %r557, ptr @perry_ic_options_worker_ts__30, i32 0, i32 0)
  %r558148 = call double @llvm.experimental.gc.result.f64(token %statepoint_token147)
  br label %pic.merge.66

pic.merge.66:                                     ; preds = %pic.way.live.73, %pic.hit.overflow.69, %pic.miss.call.65, %pic.desc.prefix.hit.62, %pic.prefix.hit.57, %pic.hit.live.53
  %r559 = phi double [ %r475, %pic.hit.live.53 ], [ %r470150, %pic.hit.overflow.69 ], [ %r495, %pic.prefix.hit.57 ], [ %r513, %pic.desc.prefix.hit.62 ], [ %r552, %pic.way.live.73 ], [ %r558148, %pic.miss.call.65 ]
  br label %pget.recv_merge.49

pic.recv_hdr.67:                                  ; preds = %pget.recv_ok.46
  %r438 = sub nuw nsw i64 %r427, 8
  %r439 = inttoptr i64 %r438 to ptr
  %r440 = load i8, ptr %r439, align 1
  %r441 = icmp eq i8 %r440, 2
  %r442 = sub nuw nsw i64 %r427, 6
  %r443 = inttoptr i64 %r442 to ptr
  %r444 = load i16, ptr %r443, align 2
  %r445 = and i16 %r444, 2048
  %r446 = icmp eq i16 %r445, 0
  %r447 = load ptr, ptr @perry_ic_options_worker_ts__30, align 8
  %r448 = icmp ne ptr %r447, null
  %r449 = and i1 %r441, %r446
  %r450 = and i1 %r449, %r448
  br i1 %r450, label %pic.token.68, label %pic.desc.classify.58

pic.token.68:                                     ; preds = %pic.recv_hdr.67
  %r452 = add nuw nsw i64 %r427, 4
  %r453 = inttoptr i64 %r452 to ptr
  %r454 = load i32, ptr %r453, align 4
  %r455 = zext i32 %r454 to i64
  %r456 = or i64 %r455, 4611686018427387904
  %r457 = icmp ne i32 %r454, 0
  %r458 = getelementptr i64, ptr %r447, i64 0
  %r459 = load i64, ptr %r458, align 8
  %r460 = icmp eq i64 %r456, %r459
  %r461 = and i1 %r460, %r457
  br i1 %r461, label %pic.hit.52, label %pic.prefix.guard.54

pic.hit.overflow.69:                              ; preds = %pic.hit.52
  %r466 = load double, ptr @options_worker_ts_.str.13.handle, align 8
  %r467 = bitcast double %r466 to i64
  %r468 = and i64 %r467, 281474976710655
  %r469 = trunc i64 %r463 to i32
  %statepoint_token149 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r427, i64 %r468, i32 %r469, ptr @perry_ic_options_worker_ts__30, i32 0, i32 0)
  %r470150 = call double @llvm.experimental.gc.result.f64(token %statepoint_token149)
  br label %pic.merge.66

pic.hit.inline.70:                                ; preds = %pic.hit.52
  %r471 = shl i64 %r463, 3
  %r472 = add nuw nsw i64 %r427, 16
  %r473 = add i64 %r472, %r471
  %r474 = inttoptr i64 %r473 to ptr
  %r475 = load double, ptr %r474, align 8
  %r476 = bitcast double %r475 to i64
  %r477 = icmp eq i64 %r476, 9222246136947933200
  br i1 %r477, label %pic.miss.63, label %pic.hit.live.53

pic.ways.71:                                      ; preds = %pic.miss.63
  %r517 = getelementptr i64, ptr %r447, i64 4
  %r518 = load i64, ptr %r517, align 8
  %r519 = icmp eq i64 %r518, %r456
  %r520 = getelementptr i64, ptr %r447, i64 5
  %r521 = load i64, ptr %r520, align 8
  %r522 = select i1 %r519, i64 %r521, i64 0
  %r523 = getelementptr i64, ptr %r447, i64 6
  %r524 = load i64, ptr %r523, align 8
  %r525 = icmp eq i64 %r524, %r456
  %r526 = getelementptr i64, ptr %r447, i64 7
  %r527 = load i64, ptr %r526, align 8
  %r528 = select i1 %r525, i64 %r527, i64 0
  %r529 = getelementptr i64, ptr %r447, i64 8
  %r530 = load i64, ptr %r529, align 8
  %r531 = icmp eq i64 %r530, %r456
  %r532 = getelementptr i64, ptr %r447, i64 9
  %r533 = load i64, ptr %r532, align 8
  %r534 = select i1 %r531, i64 %r533, i64 0
  %r535 = getelementptr i64, ptr %r447, i64 10
  %r536 = load i64, ptr %r535, align 8
  %r537 = icmp eq i64 %r536, %r456
  %r538 = getelementptr i64, ptr %r447, i64 11
  %r539 = load i64, ptr %r538, align 8
  %r540 = select i1 %r537, i64 %r539, i64 0
  %r541 = or i1 %r519, %r525
  %r542 = select i1 %r519, i64 %r522, i64 %r528
  %r543 = or i1 %r531, %r537
  %r544 = select i1 %r531, i64 %r534, i64 %r540
  %r545 = or i1 %r541, %r543
  %r546 = select i1 %r541, i64 %r542, i64 %r544
  %r547 = and i1 %r457, %r545
  br i1 %r547, label %pic.way.load.72, label %pic.miss.call.65

pic.way.load.72:                                  ; preds = %pic.ways.71
  %r548 = shl i64 %r546, 3
  %r549 = add nuw nsw i64 %r427, 16
  %r550 = add i64 %r549, %r548
  %r551 = inttoptr i64 %r550 to ptr
  %r552 = load double, ptr %r551, align 8
  %r553 = bitcast double %r552 to i64
  %r554 = icmp eq i64 %r553, 9222246136947933200
  br i1 %r554, label %pic.miss.call.65, label %pic.way.live.73

pic.way.live.73:                                  ; preds = %pic.way.load.72
  br label %pic.merge.66

pget.throw_nullish.74:                            ; preds = %pget.recv_bad.47
  %r563 = zext i1 %r561 to i32
  %statepoint_token151 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r563, ptr @options_worker_ts_.str.13.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.75:                        ; preds = %pget.recv_bad.47
  %r564 = load double, ptr @options_worker_ts_.str.13.handle, align 8
  %r565 = bitcast double %r564 to i64
  %r566 = and i64 %r565, 281474976710655
  %statepoint_token152 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r425142, i64 %r566, i32 0, i32 0)
  %r567153 = call double @llvm.experimental.gc.result.f64(token %statepoint_token152)
  br label %pget.recv_merge.49

arena_state.init.76:                              ; preds = %pget.recv_merge.49
  %r583 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r584 = icmp ne i64 %r583, -1
  br i1 %r584, label %arena_state.hot_tls.tsd.78, label %arena_state.hot_tls.slow.80

arena_state.ready.77:                             ; preds = %arena_state.hot_tls.resolved.82
  %r599 = getelementptr i8, ptr %r597, i64 8
  %r600 = load i64, ptr %r599, align 8
  %r601 = add i64 %r600, 64
  %r602 = getelementptr i8, ptr %r597, i64 16
  %r603 = load i64, ptr %r602, align 8
  %r604 = icmp ule i64 %r601, %r603
  br i1 %r604, label %arrlit.fast.83, label %arrlit.slow.84

arena_state.hot_tls.tsd.78:                       ; preds = %arena_state.init.76
  %r585 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #9
  %r586 = and i64 %r585, -8
  %r587 = shl i64 %r583, 3
  %r588 = add i64 %r586, %r587
  %r589 = inttoptr i64 %r588 to ptr
  %r590 = load ptr, ptr %r589, align 8
  %r591 = icmp ne ptr %r590, null
  br i1 %r591, label %arena_state.hot_tls.fast.79, label %arena_state.hot_tls.slow.80

arena_state.hot_tls.fast.79:                      ; preds = %arena_state.hot_tls.tsd.78
  %r592 = getelementptr i8, ptr %r590, i64 8
  %r593 = load ptr, ptr %r592, align 8
  %r594 = load ptr, ptr %r593, align 8
  %r595 = icmp ne ptr %r594, null
  br i1 %r595, label %arena_state.hot_tls.ready.81, label %arena_state.hot_tls.slow.80

arena_state.hot_tls.slow.80:                      ; preds = %arena_state.hot_tls.fast.79, %arena_state.hot_tls.tsd.78, %arena_state.init.76
  %statepoint_token154 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0)
  %r596155 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token154)
  br label %arena_state.hot_tls.resolved.82

arena_state.hot_tls.ready.81:                     ; preds = %arena_state.hot_tls.fast.79
  br label %arena_state.hot_tls.resolved.82

arena_state.hot_tls.resolved.82:                  ; preds = %arena_state.hot_tls.ready.81, %arena_state.hot_tls.slow.80
  %r597 = phi ptr [ %r593, %arena_state.hot_tls.ready.81 ], [ %r596155, %arena_state.hot_tls.slow.80 ]
  br label %arena_state.ready.77

arrlit.fast.83:                                   ; preds = %arena_state.ready.77
  store i64 %r601, ptr %r599, align 8
  %r605 = load ptr, ptr %r597, align 8
  %r606 = getelementptr i8, ptr %r605, i64 %r600
  br label %arrlit.merge.85

arrlit.slow.84:                                   ; preds = %arena_state.ready.77
  %statepoint_token156 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r597, i64 64, i64 8, i32 0, i32 0)
  %r607157 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token156)
  br label %arrlit.merge.85

arrlit.merge.85:                                  ; preds = %arrlit.slow.84, %arrlit.fast.83
  %r608 = phi ptr [ %r606, %arrlit.fast.83 ], [ %r607157, %arrlit.slow.84 ]
  store i64 275951649281, ptr %r608, align 8
  %r609 = getelementptr i8, ptr %r608, i64 8
  store i64 25769803782, ptr %r609, align 8
  %r610 = getelementptr i8, ptr %r608, i64 8
  %r611 = ptrtoint ptr %r610 to i64
  %r612 = getelementptr inbounds nuw i8, ptr %r608, i64 16
  %r1887 = load double, ptr @options_worker_ts_.str.14.handle, align 8
  store double %r1887, ptr %r612, align 8
  %r1886 = load double, ptr @options_worker_ts_.str.14.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1886) #9
  %r1885 = load double, ptr @options_worker_ts_.str.14.handle, align 8
  %r613 = bitcast double %r1885 to i64
  %r1883 = load double, ptr @options_worker_ts_.str.14.handle, align 8
  %r1884 = bitcast double %r1883 to i64
  call void @js_gc_note_slot_layout(i64 %r611, i32 0, i64 %r1884) #9
  %r614 = getelementptr inbounds nuw i8, ptr %r608, i64 24
  %r1882 = load double, ptr @options_worker_ts_.str.15.handle, align 8
  store double %r1882, ptr %r614, align 8
  %r1881 = load double, ptr @options_worker_ts_.str.15.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1881) #9
  %r1880 = load double, ptr @options_worker_ts_.str.15.handle, align 8
  %r615 = bitcast double %r1880 to i64
  %r1878 = load double, ptr @options_worker_ts_.str.15.handle, align 8
  %r1879 = bitcast double %r1878 to i64
  call void @js_gc_note_slot_layout(i64 %r611, i32 1, i64 %r1879) #9
  %r616 = getelementptr inbounds nuw i8, ptr %r608, i64 32
  %r1877 = load double, ptr @options_worker_ts_.str.16.handle, align 8
  store double %r1877, ptr %r616, align 8
  %r1876 = load double, ptr @options_worker_ts_.str.16.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1876) #9
  %r1875 = load double, ptr @options_worker_ts_.str.16.handle, align 8
  %r617 = bitcast double %r1875 to i64
  %r1873 = load double, ptr @options_worker_ts_.str.16.handle, align 8
  %r1874 = bitcast double %r1873 to i64
  call void @js_gc_note_slot_layout(i64 %r611, i32 2, i64 %r1874) #9
  %r618 = getelementptr inbounds nuw i8, ptr %r608, i64 40
  %r1872 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  store double %r1872, ptr %r618, align 8
  %r1871 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1871) #9
  %r1870 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r619 = bitcast double %r1870 to i64
  %r1868 = load double, ptr @options_worker_ts_.str.17.handle, align 8
  %r1869 = bitcast double %r1868 to i64
  call void @js_gc_note_slot_layout(i64 %r611, i32 3, i64 %r1869) #9
  %r620 = getelementptr inbounds nuw i8, ptr %r608, i64 48
  %r1867 = load double, ptr @options_worker_ts_.str.18.handle, align 8
  store double %r1867, ptr %r620, align 8
  %r1866 = load double, ptr @options_worker_ts_.str.18.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1866) #9
  %r1865 = load double, ptr @options_worker_ts_.str.18.handle, align 8
  %r621 = bitcast double %r1865 to i64
  %r1863 = load double, ptr @options_worker_ts_.str.18.handle, align 8
  %r1864 = bitcast double %r1863 to i64
  call void @js_gc_note_slot_layout(i64 %r611, i32 4, i64 %r1864) #9
  %r622 = getelementptr inbounds nuw i8, ptr %r608, i64 56
  %r1862 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  store double %r1862, ptr %r622, align 8
  %r1861 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  call void @js_string_addref_if_heap_string(double %r1861) #9
  %r1860 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  %r623 = bitcast double %r1860 to i64
  %r1858 = load double, ptr @options_worker_ts_.str.19.handle, align 8
  %r1859 = bitcast double %r1858 to i64
  call void @js_gc_note_slot_layout(i64 %r611, i32 5, i64 %r1859) #9
  %r624 = or i64 %r611, 9222527611924643840
  %r625 = bitcast i64 %r624 to double
  store double %r625, ptr @perry_global_options_worker_ts__6, align 8
  call void @js_write_barrier_root_nanbox(i64 %r624) #9
  store double 0x7FFC000000000002, ptr @perry_global_options_worker_ts__7, align 8
  call void @js_write_barrier_root_nanbox(i64 9222246136947933186) #9
  %statepoint_token158 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @"perry_fn_options_worker_ts__run$spec_b", i32 1, i32 0, double %r412135, i32 0, i32 0)
  %r629159 = call double @llvm.experimental.gc.result.f64(token %statepoint_token158)
  %rs4gc.b7 = bitcast double %r629159 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r630.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r630 = call i64 asm "", "=r,0"(i64 %r630.rs4i) #9
  %r631 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r632 = icmp ne i32 %r631, 0
  br i1 %r632, label %shadow.root.barrier.86, label %shadow.root.barrier.done.87

shadow.root.barrier.86:                           ; preds = %arrlit.merge.85
  call void @js_write_barrier_root_nanbox(i64 %r630) #9
  br label %shadow.root.barrier.done.87

shadow.root.barrier.done.87:                      ; preds = %shadow.root.barrier.86, %arrlit.merge.85
  %statepoint_token160 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_process_memory_usage, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7) ]
  %r634161 = call double @llvm.experimental.gc.result.f64(token %statepoint_token160)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 0, i32 0) ; (%rs4gc.s7, %rs4gc.s7)
  %r635 = bitcast double %r634161 to i64
  %r636 = and i64 %r635, 281474976710655
  %r637 = lshr i64 %r635, 48
  %r638 = and i64 %r637, 65533
  %r639 = icmp eq i64 %r638, 32765
  br i1 %r639, label %pget.recv_ok.89, label %pget.recv_other.93

pget.recv_sso.88:                                 ; preds = %pget.recv_other.93
  %r777 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r778 = bitcast double %r777 to i64
  %r779 = and i64 %r778, 281474976710655
  %statepoint_token162 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r635, i64 %r779, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r780163 = call double @llvm.experimental.gc.result.f64(token %statepoint_token162)
  %rs4gc.s7.relocated164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token162, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pget.recv_merge.92

pget.recv_ok.89:                                  ; preds = %shadow.root.barrier.done.87
  %r646 = icmp ugt i64 %r636, 1048575
  br i1 %r646, label %pic.recv_hdr.110, label %pic.miss.cold.107

pget.recv_bad.90:                                 ; preds = %pget.check_class_ref.94
  %r769 = icmp eq i64 %r635, 9222246136947933185
  %r770 = icmp eq i64 %r635, 9222246136947933186
  %r771 = or i1 %r769, %r770
  br i1 %r771, label %pget.throw_nullish.117, label %pget.recv_undef_return.118

pget.recv_class_ref.91:                           ; preds = %pget.check_class_ref.94
  %r642 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r643 = bitcast double %r642 to i64
  %r644 = and i64 %r643, 281474976710655
  %statepoint_token165 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532895, i64 %r635, i64 %r644, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r645166 = call double @llvm.experimental.gc.result.f64(token %statepoint_token165)
  %rs4gc.s7.relocated167 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token165, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pget.recv_merge.92

pget.recv_merge.92:                               ; preds = %pget.recv_undef_return.118, %pic.merge.109, %pget.recv_class_ref.91, %pget.recv_sso.88
  %.0482 = phi ptr addrspace(1) [ %.1483, %pic.merge.109 ], [ %rs4gc.s7.relocated164, %pget.recv_sso.88 ], [ %rs4gc.s7.relocated167, %pget.recv_class_ref.91 ], [ %rs4gc.s7.relocated177, %pget.recv_undef_return.118 ]
  %r781 = phi double [ %r768, %pic.merge.109 ], [ %r776176, %pget.recv_undef_return.118 ], [ %r780163, %pget.recv_sso.88 ], [ %r645166, %pget.recv_class_ref.91 ]
  %rs4gc.b8 = bitcast double %r781 to i64
  %rs4gc.s8 = inttoptr i64 %rs4gc.b8 to ptr addrspace(1)
  %r782.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r782 = call i64 asm "", "=r,0"(i64 %r782.rs4i) #9
  %r783 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r784 = icmp ne i32 %r783, 0
  br i1 %r784, label %shadow.root.barrier.119, label %shadow.root.barrier.done.120

pget.recv_other.93:                               ; preds = %shadow.root.barrier.done.87
  %r640 = icmp eq i64 %r637, 32761
  br i1 %r640, label %pget.recv_sso.88, label %pget.check_class_ref.94

pget.check_class_ref.94:                          ; preds = %pget.recv_other.93
  %r641 = icmp eq i64 %r637, 32766
  br i1 %r641, label %pget.recv_class_ref.91, label %pget.recv_bad.90

pic.hit.95:                                       ; preds = %pic.token.111
  %r671 = getelementptr i64, ptr %r656, i64 1
  %r672 = load i64, ptr %r671, align 8
  %r673 = and i64 %r672, 1073741824
  %r674 = icmp ne i64 %r673, 0
  br i1 %r674, label %pic.hit.overflow.112, label %pic.hit.inline.113

pic.hit.live.96:                                  ; preds = %pic.hit.inline.113
  br label %pic.merge.109

pic.prefix.guard.97:                              ; preds = %pic.token.111
  %r687 = getelementptr i64, ptr %r656, i64 2
  %r688 = load i64, ptr %r687, align 8
  %r689 = icmp ne i64 %r688, 0
  br i1 %r689, label %pic.prefix.meta.98, label %pic.miss.106

pic.prefix.meta.98:                               ; preds = %pic.prefix.guard.97
  %r690 = add nuw nsw i64 %r636, 8
  %r691 = inttoptr i64 %r690 to ptr
  %r692 = load i64, ptr %r691, align 8
  %r693 = icmp ne i64 %r692, 0
  br i1 %r693, label %pic.prefix.token.99, label %pic.miss.106

pic.prefix.token.99:                              ; preds = %pic.prefix.meta.98
  %r694 = inttoptr i64 %r692 to ptr
  %r695 = getelementptr i64, ptr %r694, i64 6
  %r696 = load i64, ptr %r695, align 8
  %r697 = icmp eq i64 %r696, %r688
  br i1 %r697, label %pic.prefix.hit.100, label %pic.miss.106

pic.prefix.hit.100:                               ; preds = %pic.prefix.token.99
  %r698 = getelementptr i64, ptr %r656, i64 1
  %r699 = load i64, ptr %r698, align 8
  %r700 = shl i64 %r699, 3
  %r701 = add nuw nsw i64 %r636, 16
  %r702 = add i64 %r701, %r700
  %r703 = inttoptr i64 %r702 to ptr
  %r704 = load double, ptr %r703, align 8
  br label %pic.merge.109

pic.desc.classify.101:                            ; preds = %pic.recv_hdr.110
  %r660 = and i1 %r650, %r657
  br i1 %r660, label %pic.desc.prefix.guard.102, label %pic.miss.cold.107

pic.desc.prefix.guard.102:                        ; preds = %pic.desc.classify.101
  %r705 = getelementptr i64, ptr %r656, i64 2
  %r706 = load i64, ptr %r705, align 8
  %r707 = icmp ne i64 %r706, 0
  br i1 %r707, label %pic.desc.prefix.meta.103, label %pic.miss.cold.107

pic.desc.prefix.meta.103:                         ; preds = %pic.desc.prefix.guard.102
  %r708 = add nuw nsw i64 %r636, 8
  %r709 = inttoptr i64 %r708 to ptr
  %r710 = load i64, ptr %r709, align 8
  %r711 = icmp ne i64 %r710, 0
  br i1 %r711, label %pic.desc.prefix.token.104, label %pic.miss.cold.107

pic.desc.prefix.token.104:                        ; preds = %pic.desc.prefix.meta.103
  %r712 = inttoptr i64 %r710 to ptr
  %r713 = getelementptr i64, ptr %r712, i64 6
  %r714 = load i64, ptr %r713, align 8
  %r715 = icmp eq i64 %r714, %r706
  br i1 %r715, label %pic.desc.prefix.hit.105, label %pic.miss.cold.107

pic.desc.prefix.hit.105:                          ; preds = %pic.desc.prefix.token.104
  %r716 = getelementptr i64, ptr %r656, i64 1
  %r717 = load i64, ptr %r716, align 8
  %r718 = shl i64 %r717, 3
  %r719 = add nuw nsw i64 %r636, 16
  %r720 = add i64 %r719, %r718
  %r721 = inttoptr i64 %r720 to ptr
  %r722 = load double, ptr %r721, align 8
  br label %pic.merge.109

pic.miss.106:                                     ; preds = %pic.hit.inline.113, %pic.prefix.token.99, %pic.prefix.meta.98, %pic.prefix.guard.97
  %r723 = getelementptr i64, ptr %r656, i64 3
  %r724 = load i64, ptr %r723, align 8
  %r725 = icmp sgt i64 %r724, 0
  br i1 %r725, label %pic.ways.114, label %pic.miss.call.108

pic.miss.cold.107:                                ; preds = %pic.desc.prefix.token.104, %pic.desc.prefix.meta.103, %pic.desc.prefix.guard.102, %pic.desc.classify.101, %pget.recv_ok.89
  br label %pic.miss.call.108

pic.miss.call.108:                                ; preds = %pic.way.load.115, %pic.ways.114, %pic.miss.cold.107, %pic.miss.106
  %r764 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r765 = bitcast double %r764 to i64
  %r766 = and i64 %r765, 281474976710655
  %statepoint_token168 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r636, i64 %r766, ptr @perry_ic_options_worker_ts__32, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r767169 = call double @llvm.experimental.gc.result.f64(token %statepoint_token168)
  %rs4gc.s7.relocated170 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token168, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pic.merge.109

pic.merge.109:                                    ; preds = %pic.way.live.116, %pic.hit.overflow.112, %pic.miss.call.108, %pic.desc.prefix.hit.105, %pic.prefix.hit.100, %pic.hit.live.96
  %.1483 = phi ptr addrspace(1) [ %rs4gc.s7.relocated173, %pic.hit.overflow.112 ], [ %rs4gc.s7.relocated170, %pic.miss.call.108 ], [ %rs4gc.s7.relocated, %pic.way.live.116 ], [ %rs4gc.s7.relocated, %pic.hit.live.96 ], [ %rs4gc.s7.relocated, %pic.prefix.hit.100 ], [ %rs4gc.s7.relocated, %pic.desc.prefix.hit.105 ]
  %r768 = phi double [ %r684, %pic.hit.live.96 ], [ %r679172, %pic.hit.overflow.112 ], [ %r704, %pic.prefix.hit.100 ], [ %r722, %pic.desc.prefix.hit.105 ], [ %r761, %pic.way.live.116 ], [ %r767169, %pic.miss.call.108 ]
  br label %pget.recv_merge.92

pic.recv_hdr.110:                                 ; preds = %pget.recv_ok.89
  %r647 = sub nuw nsw i64 %r636, 8
  %r648 = inttoptr i64 %r647 to ptr
  %r649 = load i8, ptr %r648, align 1
  %r650 = icmp eq i8 %r649, 2
  %r651 = sub nuw nsw i64 %r636, 6
  %r652 = inttoptr i64 %r651 to ptr
  %r653 = load i16, ptr %r652, align 2
  %r654 = and i16 %r653, 2048
  %r655 = icmp eq i16 %r654, 0
  %r656 = load ptr, ptr @perry_ic_options_worker_ts__32, align 8
  %r657 = icmp ne ptr %r656, null
  %r658 = and i1 %r650, %r655
  %r659 = and i1 %r658, %r657
  br i1 %r659, label %pic.token.111, label %pic.desc.classify.101

pic.token.111:                                    ; preds = %pic.recv_hdr.110
  %r661 = add nuw nsw i64 %r636, 4
  %r662 = inttoptr i64 %r661 to ptr
  %r663 = load i32, ptr %r662, align 4
  %r664 = zext i32 %r663 to i64
  %r665 = or i64 %r664, 4611686018427387904
  %r666 = icmp ne i32 %r663, 0
  %r667 = getelementptr i64, ptr %r656, i64 0
  %r668 = load i64, ptr %r667, align 8
  %r669 = icmp eq i64 %r665, %r668
  %r670 = and i1 %r669, %r666
  br i1 %r670, label %pic.hit.95, label %pic.prefix.guard.97

pic.hit.overflow.112:                             ; preds = %pic.hit.95
  %r675 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r676 = bitcast double %r675 to i64
  %r677 = and i64 %r676, 281474976710655
  %r678 = trunc i64 %r672 to i32
  %statepoint_token171 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r636, i64 %r677, i32 %r678, ptr @perry_ic_options_worker_ts__32, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r679172 = call double @llvm.experimental.gc.result.f64(token %statepoint_token171)
  %rs4gc.s7.relocated173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token171, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pic.merge.109

pic.hit.inline.113:                               ; preds = %pic.hit.95
  %r680 = shl i64 %r672, 3
  %r681 = add nuw nsw i64 %r636, 16
  %r682 = add i64 %r681, %r680
  %r683 = inttoptr i64 %r682 to ptr
  %r684 = load double, ptr %r683, align 8
  %r685 = bitcast double %r684 to i64
  %r686 = icmp eq i64 %r685, 9222246136947933200
  br i1 %r686, label %pic.miss.106, label %pic.hit.live.96

pic.ways.114:                                     ; preds = %pic.miss.106
  %r726 = getelementptr i64, ptr %r656, i64 4
  %r727 = load i64, ptr %r726, align 8
  %r728 = icmp eq i64 %r727, %r665
  %r729 = getelementptr i64, ptr %r656, i64 5
  %r730 = load i64, ptr %r729, align 8
  %r731 = select i1 %r728, i64 %r730, i64 0
  %r732 = getelementptr i64, ptr %r656, i64 6
  %r733 = load i64, ptr %r732, align 8
  %r734 = icmp eq i64 %r733, %r665
  %r735 = getelementptr i64, ptr %r656, i64 7
  %r736 = load i64, ptr %r735, align 8
  %r737 = select i1 %r734, i64 %r736, i64 0
  %r738 = getelementptr i64, ptr %r656, i64 8
  %r739 = load i64, ptr %r738, align 8
  %r740 = icmp eq i64 %r739, %r665
  %r741 = getelementptr i64, ptr %r656, i64 9
  %r742 = load i64, ptr %r741, align 8
  %r743 = select i1 %r740, i64 %r742, i64 0
  %r744 = getelementptr i64, ptr %r656, i64 10
  %r745 = load i64, ptr %r744, align 8
  %r746 = icmp eq i64 %r745, %r665
  %r747 = getelementptr i64, ptr %r656, i64 11
  %r748 = load i64, ptr %r747, align 8
  %r749 = select i1 %r746, i64 %r748, i64 0
  %r750 = or i1 %r728, %r734
  %r751 = select i1 %r728, i64 %r731, i64 %r737
  %r752 = or i1 %r740, %r746
  %r753 = select i1 %r740, i64 %r743, i64 %r749
  %r754 = or i1 %r750, %r752
  %r755 = select i1 %r750, i64 %r751, i64 %r753
  %r756 = and i1 %r666, %r754
  br i1 %r756, label %pic.way.load.115, label %pic.miss.call.108

pic.way.load.115:                                 ; preds = %pic.ways.114
  %r757 = shl i64 %r755, 3
  %r758 = add nuw nsw i64 %r636, 16
  %r759 = add i64 %r758, %r757
  %r760 = inttoptr i64 %r759 to ptr
  %r761 = load double, ptr %r760, align 8
  %r762 = bitcast double %r761 to i64
  %r763 = icmp eq i64 %r762, 9222246136947933200
  br i1 %r763, label %pic.miss.call.108, label %pic.way.live.116

pic.way.live.116:                                 ; preds = %pic.way.load.115
  br label %pic.merge.109

pget.throw_nullish.117:                           ; preds = %pget.recv_bad.90
  %r772 = zext i1 %r770 to i32
  %statepoint_token174 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r772, ptr @options_worker_ts_.str.20.bytes, i64 3, i32 0, i32 0)
  unreachable

pget.recv_undef_return.118:                       ; preds = %pget.recv_bad.90
  %r773 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r774 = bitcast double %r773 to i64
  %r775 = and i64 %r774, 281474976710655
  %statepoint_token175 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r635, i64 %r775, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r776176 = call double @llvm.experimental.gc.result.f64(token %statepoint_token175)
  %rs4gc.s7.relocated177 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token175, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pget.recv_merge.92

shadow.root.barrier.119:                          ; preds = %pget.recv_merge.92
  call void @js_write_barrier_root_nanbox(i64 %r782) #9
  br label %shadow.root.barrier.done.120

shadow.root.barrier.done.120:                     ; preds = %shadow.root.barrier.119, %pget.recv_merge.92
  %statepoint_token178 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_process_cpu_usage, i32 1, i32 0, double 0x7FFC000000000001, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0482, ptr addrspace(1) %rs4gc.s8) ]
  %r786179 = call double @llvm.experimental.gc.result.f64(token %statepoint_token178)
  %rs4gc.s7.relocated180 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 0, i32 0) ; (%.0482, %.0482)
  %rs4gc.s8.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.b9 = bitcast double %r786179 to i64
  %rs4gc.s9 = inttoptr i64 %rs4gc.b9 to ptr addrspace(1)
  %r787.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r787 = call i64 asm "", "=r,0"(i64 %r787.rs4i) #9
  %r788 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r789 = icmp ne i32 %r788, 0
  br i1 %r789, label %shadow.root.barrier.121, label %shadow.root.barrier.done.122

shadow.root.barrier.121:                          ; preds = %shadow.root.barrier.done.120
  call void @js_write_barrier_root_nanbox(i64 %r787) #9
  br label %shadow.root.barrier.done.122

shadow.root.barrier.done.122:                     ; preds = %shadow.root.barrier.121, %shadow.root.barrier.done.120
  %statepoint_token181 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_performance_now, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated, ptr addrspace(1) %rs4gc.s9, ptr addrspace(1) %rs4gc.s7.relocated180) ]
  %r791182 = call double @llvm.experimental.gc.result.f64(token %statepoint_token181)
  %rs4gc.s8.relocated183 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token181, i32 0, i32 0) ; (%rs4gc.s8.relocated, %rs4gc.s8.relocated)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token181, i32 1, i32 1) ; (%rs4gc.s9, %rs4gc.s9)
  %rs4gc.s7.relocated184 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token181, i32 2, i32 2) ; (%rs4gc.s7.relocated180, %rs4gc.s7.relocated180)
  %r792.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7.relocated184 to i64
  %r792.rs4o = call i64 asm "", "=r,0"(i64 %r792.rs4i) #9
  %r792 = bitcast i64 %r792.rs4o to double
  %r793 = bitcast double %r792 to i64
  %rs4gc.s10 = inttoptr i64 %r793 to ptr addrspace(1)
  %r795.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r795 = call i64 asm "", "=r,0"(i64 %r795.rs4i) #9
  %r796 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r797 = icmp ne i32 %r796, 0
  br i1 %r797, label %shadow.root.barrier.123, label %shadow.root.barrier.done.124

shadow.root.barrier.123:                          ; preds = %shadow.root.barrier.done.122
  call void @js_write_barrier_root_nanbox(i64 %r795) #9
  br label %shadow.root.barrier.done.124

shadow.root.barrier.done.124:                     ; preds = %shadow.root.barrier.123, %shadow.root.barrier.done.122
  %statepoint_token185 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @"perry_fn_options_worker_ts__run$spec_b", i32 1, i32 0, double %r336126, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated183, ptr addrspace(1) %rs4gc.s9.relocated, ptr addrspace(1) %rs4gc.s10) ]
  %r799186 = call double @llvm.experimental.gc.result.f64(token %statepoint_token185)
  %rs4gc.s8.relocated187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token185, i32 0, i32 0) ; (%rs4gc.s8.relocated183, %rs4gc.s8.relocated183)
  %rs4gc.s9.relocated188 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token185, i32 1, i32 1) ; (%rs4gc.s9.relocated, %rs4gc.s9.relocated)
  %rs4gc.s10.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token185, i32 2, i32 2) ; (%rs4gc.s10, %rs4gc.s10)
  %r800.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10.relocated to i64
  %r800 = call i64 asm "", "=r,0"(i64 %r800.rs4i) #9
  %r801 = bitcast i64 %r800 to double
  %r802 = and i64 %r800, -281474976710656
  %r803 = icmp ult i64 %r802, 9221401712017801216
  %r804 = icmp ugt i64 %r802, 9223090561878065152
  %r805 = or i1 %r803, %r804
  %r806 = bitcast double %r799186 to i64
  %r807 = and i64 %r806, -281474976710656
  %r808 = icmp ult i64 %r807, 9221401712017801216
  %r809 = icmp ugt i64 %r807, 9223090561878065152
  %r810 = or i1 %r808, %r809
  %r811 = and i1 %r805, %r810
  br i1 %r811, label %guarded_add.numeric.125, label %guarded_add.dynamic.126

guarded_add.numeric.125:                          ; preds = %shadow.root.barrier.done.124
  %r812 = fadd double %r801, %r799186
  br label %guarded_add.merge.127

guarded_add.dynamic.126:                          ; preds = %shadow.root.barrier.done.124
  %statepoint_token189 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r801, double %r799186, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated187, ptr addrspace(1) %rs4gc.s9.relocated188) ]
  %r813190 = call double @llvm.experimental.gc.result.f64(token %statepoint_token189)
  %rs4gc.s8.relocated191 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 0, i32 0) ; (%rs4gc.s8.relocated187, %rs4gc.s8.relocated187)
  %rs4gc.s9.relocated192 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token189, i32 1, i32 1) ; (%rs4gc.s9.relocated188, %rs4gc.s9.relocated188)
  br label %guarded_add.merge.127

guarded_add.merge.127:                            ; preds = %guarded_add.dynamic.126, %guarded_add.numeric.125
  %.0488 = phi ptr addrspace(1) [ %rs4gc.s9.relocated188, %guarded_add.numeric.125 ], [ %rs4gc.s9.relocated192, %guarded_add.dynamic.126 ]
  %.0484 = phi ptr addrspace(1) [ %rs4gc.s8.relocated187, %guarded_add.numeric.125 ], [ %rs4gc.s8.relocated191, %guarded_add.dynamic.126 ]
  %r814 = phi double [ %r812, %guarded_add.numeric.125 ], [ %r813190, %guarded_add.dynamic.126 ]
  %rs4gc.b11 = bitcast double %r814 to i64
  %rs4gc.s11 = inttoptr i64 %rs4gc.b11 to ptr addrspace(1)
  %r815.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11 to i64
  %r815 = call i64 asm "", "=r,0"(i64 %r815.rs4i) #9
  %r816 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r817 = icmp ne i32 %r816, 0
  br i1 %r817, label %shadow.root.barrier.128, label %shadow.root.barrier.done.129

shadow.root.barrier.128:                          ; preds = %guarded_add.merge.127
  call void @js_write_barrier_root_nanbox(i64 %r815) #9
  br label %shadow.root.barrier.done.129

shadow.root.barrier.done.129:                     ; preds = %shadow.root.barrier.128, %guarded_add.merge.127
  %statepoint_token193 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_performance_now, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11, ptr addrspace(1) %.0484, ptr addrspace(1) %.0488) ]
  %r819194 = call double @llvm.experimental.gc.result.f64(token %statepoint_token193)
  %rs4gc.s11.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 0, i32 0) ; (%rs4gc.s11, %rs4gc.s11)
  %rs4gc.s8.relocated195 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 1, i32 1) ; (%.0484, %.0484)
  %rs4gc.s9.relocated196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token193, i32 2, i32 2) ; (%.0488, %.0488)
  %r821 = bitcast double %r819194 to i64
  %r822 = and i64 %r821, -281474976710656
  %r823 = icmp ult i64 %r822, 9221401712017801216
  %r824 = icmp ugt i64 %r822, 9223090561878065152
  %r825 = or i1 %r823, %r824
  %r826 = bitcast double %r791182 to i64
  %r827 = and i64 %r826, -281474976710656
  %r828 = icmp ult i64 %r827, 9221401712017801216
  %r829 = icmp ugt i64 %r827, 9223090561878065152
  %r830 = or i1 %r828, %r829
  %r831 = and i1 %r825, %r830
  br i1 %r831, label %guarded_arith.numeric.130, label %guarded_arith.dynamic.131

guarded_arith.numeric.130:                        ; preds = %shadow.root.barrier.done.129
  %r832 = fsub double %r819194, %r791182
  br label %guarded_arith.merge.132

guarded_arith.dynamic.131:                        ; preds = %shadow.root.barrier.done.129
  %statepoint_token197 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_sub, i32 2, i32 0, double %r819194, double %r791182, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated, ptr addrspace(1) %rs4gc.s8.relocated195, ptr addrspace(1) %rs4gc.s9.relocated196) ]
  %r833198 = call double @llvm.experimental.gc.result.f64(token %statepoint_token197)
  %rs4gc.s11.relocated199 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token197, i32 0, i32 0) ; (%rs4gc.s11.relocated, %rs4gc.s11.relocated)
  %rs4gc.s8.relocated200 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token197, i32 1, i32 1) ; (%rs4gc.s8.relocated195, %rs4gc.s8.relocated195)
  %rs4gc.s9.relocated201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token197, i32 2, i32 2) ; (%rs4gc.s9.relocated196, %rs4gc.s9.relocated196)
  br label %guarded_arith.merge.132

guarded_arith.merge.132:                          ; preds = %guarded_arith.dynamic.131, %guarded_arith.numeric.130
  %.0497 = phi ptr addrspace(1) [ %rs4gc.s11.relocated, %guarded_arith.numeric.130 ], [ %rs4gc.s11.relocated199, %guarded_arith.dynamic.131 ]
  %.1489 = phi ptr addrspace(1) [ %rs4gc.s9.relocated196, %guarded_arith.numeric.130 ], [ %rs4gc.s9.relocated201, %guarded_arith.dynamic.131 ]
  %.1485 = phi ptr addrspace(1) [ %rs4gc.s8.relocated195, %guarded_arith.numeric.130 ], [ %rs4gc.s8.relocated200, %guarded_arith.dynamic.131 ]
  %r834 = phi double [ %r832, %guarded_arith.numeric.130 ], [ %r833198, %guarded_arith.dynamic.131 ]
  %statepoint_token202 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_process_cpu_usage, i32 1, i32 0, double 0x7FFC000000000001, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0497, ptr addrspace(1) %.1485, ptr addrspace(1) %.1489) ]
  %r836203 = call double @llvm.experimental.gc.result.f64(token %statepoint_token202)
  %rs4gc.s11.relocated204 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token202, i32 0, i32 0) ; (%.0497, %.0497)
  %rs4gc.s8.relocated205 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token202, i32 1, i32 1) ; (%.1485, %.1485)
  %rs4gc.s9.relocated206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token202, i32 2, i32 2) ; (%.1489, %.1489)
  %rs4gc.b12 = bitcast double %r836203 to i64
  %rs4gc.s12 = inttoptr i64 %rs4gc.b12 to ptr addrspace(1)
  %r837.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r837 = call i64 asm "", "=r,0"(i64 %r837.rs4i) #9
  %r838 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r839 = icmp ne i32 %r838, 0
  br i1 %r839, label %shadow.root.barrier.133, label %shadow.root.barrier.done.134

shadow.root.barrier.133:                          ; preds = %guarded_arith.merge.132
  call void @js_write_barrier_root_nanbox(i64 %r837) #9
  br label %shadow.root.barrier.done.134

shadow.root.barrier.done.134:                     ; preds = %shadow.root.barrier.133, %guarded_arith.merge.132
  %statepoint_token207 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated204, ptr addrspace(1) %rs4gc.s8.relocated205, ptr addrspace(1) %rs4gc.s9.relocated206, ptr addrspace(1) %rs4gc.s12) ]
  %r840208 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token207)
  %rs4gc.s11.relocated209 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 0, i32 0) ; (%rs4gc.s11.relocated204, %rs4gc.s11.relocated204)
  %rs4gc.s8.relocated210 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 1, i32 1) ; (%rs4gc.s8.relocated205, %rs4gc.s8.relocated205)
  %rs4gc.s9.relocated211 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 2, i32 2) ; (%rs4gc.s9.relocated206, %rs4gc.s9.relocated206)
  %rs4gc.s12.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 3, i32 3) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13 = inttoptr i64 %r840208 to ptr addrspace(1)
  %r841.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r841 = call i64 asm "", "=r,0"(i64 %r841.rs4i) #9
  %r842 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r843 = icmp ne i32 %r842, 0
  br i1 %r843, label %shadow.root.barrier.135, label %shadow.root.barrier.done.136

shadow.root.barrier.135:                          ; preds = %shadow.root.barrier.done.134
  call void @js_write_barrier_root_nanbox(i64 %r841) #9
  br label %shadow.root.barrier.done.136

shadow.root.barrier.done.136:                     ; preds = %shadow.root.barrier.135, %shadow.root.barrier.done.134
  %r844 = load double, ptr @options_worker_ts_.str.21.handle, align 8
  %r845.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r845 = call i64 asm "", "=r,0"(i64 %r845.rs4i) #9
  %statepoint_token212 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r845, double %r844, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated209, ptr addrspace(1) %rs4gc.s8.relocated210, ptr addrspace(1) %rs4gc.s9.relocated211, ptr addrspace(1) %rs4gc.s12.relocated) ]
  %r846213 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token212)
  %rs4gc.s11.relocated214 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 0, i32 0) ; (%rs4gc.s11.relocated209, %rs4gc.s11.relocated209)
  %rs4gc.s8.relocated215 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 1, i32 1) ; (%rs4gc.s8.relocated210, %rs4gc.s8.relocated210)
  %rs4gc.s9.relocated216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 2, i32 2) ; (%rs4gc.s9.relocated211, %rs4gc.s9.relocated211)
  %rs4gc.s12.relocated217 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token212, i32 3, i32 3) ; (%rs4gc.s12.relocated, %rs4gc.s12.relocated)
  %rs4gc.s14 = inttoptr i64 %r846213 to ptr addrspace(1)
  %r847.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r847 = call i64 asm "", "=r,0"(i64 %r847.rs4i) #9
  %r848 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r849 = icmp ne i32 %r848, 0
  br i1 %r849, label %shadow.root.barrier.137, label %shadow.root.barrier.done.138

shadow.root.barrier.137:                          ; preds = %shadow.root.barrier.done.136
  call void @js_write_barrier_root_nanbox(i64 %r847) #9
  br label %shadow.root.barrier.done.138

shadow.root.barrier.done.138:                     ; preds = %shadow.root.barrier.137, %shadow.root.barrier.done.136
  %r851.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r851 = call i64 asm "", "=r,0"(i64 %r851.rs4i) #9
  %statepoint_token218 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r851, double %r834, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated214, ptr addrspace(1) %rs4gc.s8.relocated215, ptr addrspace(1) %rs4gc.s9.relocated216, ptr addrspace(1) %rs4gc.s12.relocated217) ]
  %r852219 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token218)
  %rs4gc.s11.relocated220 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 0, i32 0) ; (%rs4gc.s11.relocated214, %rs4gc.s11.relocated214)
  %rs4gc.s8.relocated221 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 1, i32 1) ; (%rs4gc.s8.relocated215, %rs4gc.s8.relocated215)
  %rs4gc.s9.relocated222 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 2, i32 2) ; (%rs4gc.s9.relocated216, %rs4gc.s9.relocated216)
  %rs4gc.s12.relocated223 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 3, i32 3) ; (%rs4gc.s12.relocated217, %rs4gc.s12.relocated217)
  %rs4gc.s15 = inttoptr i64 %r852219 to ptr addrspace(1)
  %r853.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r853 = call i64 asm "", "=r,0"(i64 %r853.rs4i) #9
  %r854 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r855 = icmp ne i32 %r854, 0
  br i1 %r855, label %shadow.root.barrier.139, label %shadow.root.barrier.done.140

shadow.root.barrier.139:                          ; preds = %shadow.root.barrier.done.138
  call void @js_write_barrier_root_nanbox(i64 %r853) #9
  br label %shadow.root.barrier.done.140

shadow.root.barrier.done.140:                     ; preds = %shadow.root.barrier.139, %shadow.root.barrier.done.138
  %r856.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12.relocated223 to i64
  %r856.rs4o = call i64 asm "", "=r,0"(i64 %r856.rs4i) #9
  %r856 = bitcast i64 %r856.rs4o to double
  %r857 = bitcast double %r856 to i64
  %r858 = and i64 %r857, 281474976710655
  %r859 = lshr i64 %r857, 48
  %r860 = and i64 %r859, 65533
  %r861 = icmp eq i64 %r860, 32765
  br i1 %r861, label %pget.recv_ok.142, label %pget.recv_other.146

pget.recv_sso.141:                                ; preds = %pget.recv_other.146
  %r999 = load double, ptr @options_worker_ts_.str.22.handle, align 8
  %r1000 = bitcast double %r999 to i64
  %r1001 = and i64 %r1000, 281474976710655
  %statepoint_token224 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r857, i64 %r1001, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated220, ptr addrspace(1) %rs4gc.s8.relocated221, ptr addrspace(1) %rs4gc.s9.relocated222, ptr addrspace(1) %rs4gc.s12.relocated223, ptr addrspace(1) %rs4gc.s15) ]
  %r1002225 = call double @llvm.experimental.gc.result.f64(token %statepoint_token224)
  %rs4gc.s11.relocated226 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token224, i32 0, i32 0) ; (%rs4gc.s11.relocated220, %rs4gc.s11.relocated220)
  %rs4gc.s8.relocated227 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token224, i32 1, i32 1) ; (%rs4gc.s8.relocated221, %rs4gc.s8.relocated221)
  %rs4gc.s9.relocated228 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token224, i32 2, i32 2) ; (%rs4gc.s9.relocated222, %rs4gc.s9.relocated222)
  %rs4gc.s12.relocated229 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token224, i32 3, i32 3) ; (%rs4gc.s12.relocated223, %rs4gc.s12.relocated223)
  %rs4gc.s15.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token224, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.145

pget.recv_ok.142:                                 ; preds = %shadow.root.barrier.done.140
  %r868 = icmp ugt i64 %r858, 1048575
  br i1 %r868, label %pic.recv_hdr.163, label %pic.miss.cold.160

pget.recv_bad.143:                                ; preds = %pget.check_class_ref.147
  %r991 = icmp eq i64 %r857, 9222246136947933185
  %r992 = icmp eq i64 %r857, 9222246136947933186
  %r993 = or i1 %r991, %r992
  br i1 %r993, label %pget.throw_nullish.170, label %pget.recv_undef_return.171

pget.recv_class_ref.144:                          ; preds = %pget.check_class_ref.147
  %r864 = load double, ptr @options_worker_ts_.str.22.handle, align 8
  %r865 = bitcast double %r864 to i64
  %r866 = and i64 %r865, 281474976710655
  %statepoint_token230 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532897, i64 %r857, i64 %r866, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated220, ptr addrspace(1) %rs4gc.s8.relocated221, ptr addrspace(1) %rs4gc.s9.relocated222, ptr addrspace(1) %rs4gc.s12.relocated223, ptr addrspace(1) %rs4gc.s15) ]
  %r867231 = call double @llvm.experimental.gc.result.f64(token %statepoint_token230)
  %rs4gc.s11.relocated232 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 0, i32 0) ; (%rs4gc.s11.relocated220, %rs4gc.s11.relocated220)
  %rs4gc.s8.relocated233 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 1, i32 1) ; (%rs4gc.s8.relocated221, %rs4gc.s8.relocated221)
  %rs4gc.s9.relocated234 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 2, i32 2) ; (%rs4gc.s9.relocated222, %rs4gc.s9.relocated222)
  %rs4gc.s12.relocated235 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 3, i32 3) ; (%rs4gc.s12.relocated223, %rs4gc.s12.relocated223)
  %rs4gc.s15.relocated236 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.145

pget.recv_merge.145:                              ; preds = %pget.recv_undef_return.171, %pic.merge.162, %pget.recv_class_ref.144, %pget.recv_sso.141
  %.0514 = phi ptr addrspace(1) [ %.1515, %pic.merge.162 ], [ %rs4gc.s15.relocated, %pget.recv_sso.141 ], [ %rs4gc.s15.relocated236, %pget.recv_class_ref.144 ], [ %rs4gc.s15.relocated258, %pget.recv_undef_return.171 ]
  %.0509 = phi ptr addrspace(1) [ %.1510, %pic.merge.162 ], [ %rs4gc.s12.relocated229, %pget.recv_sso.141 ], [ %rs4gc.s12.relocated235, %pget.recv_class_ref.144 ], [ %rs4gc.s12.relocated257, %pget.recv_undef_return.171 ]
  %.1498 = phi ptr addrspace(1) [ %.2499, %pic.merge.162 ], [ %rs4gc.s11.relocated226, %pget.recv_sso.141 ], [ %rs4gc.s11.relocated232, %pget.recv_class_ref.144 ], [ %rs4gc.s11.relocated254, %pget.recv_undef_return.171 ]
  %.2490 = phi ptr addrspace(1) [ %.3491, %pic.merge.162 ], [ %rs4gc.s9.relocated228, %pget.recv_sso.141 ], [ %rs4gc.s9.relocated234, %pget.recv_class_ref.144 ], [ %rs4gc.s9.relocated256, %pget.recv_undef_return.171 ]
  %.2486 = phi ptr addrspace(1) [ %.3487, %pic.merge.162 ], [ %rs4gc.s8.relocated227, %pget.recv_sso.141 ], [ %rs4gc.s8.relocated233, %pget.recv_class_ref.144 ], [ %rs4gc.s8.relocated255, %pget.recv_undef_return.171 ]
  %r1003 = phi double [ %r990, %pic.merge.162 ], [ %r998253, %pget.recv_undef_return.171 ], [ %r1002225, %pget.recv_sso.141 ], [ %r867231, %pget.recv_class_ref.144 ]
  %r1004 = bitcast double %r1003 to i64
  %rs4gc.s16 = inttoptr i64 %r1004 to ptr addrspace(1)
  %r1006.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r1006 = call i64 asm "", "=r,0"(i64 %r1006.rs4i) #9
  %r1007 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1008 = icmp ne i32 %r1007, 0
  br i1 %r1008, label %shadow.root.barrier.172, label %shadow.root.barrier.done.173

pget.recv_other.146:                              ; preds = %shadow.root.barrier.done.140
  %r862 = icmp eq i64 %r859, 32761
  br i1 %r862, label %pget.recv_sso.141, label %pget.check_class_ref.147

pget.check_class_ref.147:                         ; preds = %pget.recv_other.146
  %r863 = icmp eq i64 %r859, 32766
  br i1 %r863, label %pget.recv_class_ref.144, label %pget.recv_bad.143

pic.hit.148:                                      ; preds = %pic.token.164
  %r893 = getelementptr i64, ptr %r878, i64 1
  %r894 = load i64, ptr %r893, align 8
  %r895 = and i64 %r894, 1073741824
  %r896 = icmp ne i64 %r895, 0
  br i1 %r896, label %pic.hit.overflow.165, label %pic.hit.inline.166

pic.hit.live.149:                                 ; preds = %pic.hit.inline.166
  br label %pic.merge.162

pic.prefix.guard.150:                             ; preds = %pic.token.164
  %r909 = getelementptr i64, ptr %r878, i64 2
  %r910 = load i64, ptr %r909, align 8
  %r911 = icmp ne i64 %r910, 0
  br i1 %r911, label %pic.prefix.meta.151, label %pic.miss.159

pic.prefix.meta.151:                              ; preds = %pic.prefix.guard.150
  %r912 = add nuw nsw i64 %r858, 8
  %r913 = inttoptr i64 %r912 to ptr
  %r914 = load i64, ptr %r913, align 8
  %r915 = icmp ne i64 %r914, 0
  br i1 %r915, label %pic.prefix.token.152, label %pic.miss.159

pic.prefix.token.152:                             ; preds = %pic.prefix.meta.151
  %r916 = inttoptr i64 %r914 to ptr
  %r917 = getelementptr i64, ptr %r916, i64 6
  %r918 = load i64, ptr %r917, align 8
  %r919 = icmp eq i64 %r918, %r910
  br i1 %r919, label %pic.prefix.hit.153, label %pic.miss.159

pic.prefix.hit.153:                               ; preds = %pic.prefix.token.152
  %r920 = getelementptr i64, ptr %r878, i64 1
  %r921 = load i64, ptr %r920, align 8
  %r922 = shl i64 %r921, 3
  %r923 = add nuw nsw i64 %r858, 16
  %r924 = add i64 %r923, %r922
  %r925 = inttoptr i64 %r924 to ptr
  %r926 = load double, ptr %r925, align 8
  br label %pic.merge.162

pic.desc.classify.154:                            ; preds = %pic.recv_hdr.163
  %r882 = and i1 %r872, %r879
  br i1 %r882, label %pic.desc.prefix.guard.155, label %pic.miss.cold.160

pic.desc.prefix.guard.155:                        ; preds = %pic.desc.classify.154
  %r927 = getelementptr i64, ptr %r878, i64 2
  %r928 = load i64, ptr %r927, align 8
  %r929 = icmp ne i64 %r928, 0
  br i1 %r929, label %pic.desc.prefix.meta.156, label %pic.miss.cold.160

pic.desc.prefix.meta.156:                         ; preds = %pic.desc.prefix.guard.155
  %r930 = add nuw nsw i64 %r858, 8
  %r931 = inttoptr i64 %r930 to ptr
  %r932 = load i64, ptr %r931, align 8
  %r933 = icmp ne i64 %r932, 0
  br i1 %r933, label %pic.desc.prefix.token.157, label %pic.miss.cold.160

pic.desc.prefix.token.157:                        ; preds = %pic.desc.prefix.meta.156
  %r934 = inttoptr i64 %r932 to ptr
  %r935 = getelementptr i64, ptr %r934, i64 6
  %r936 = load i64, ptr %r935, align 8
  %r937 = icmp eq i64 %r936, %r928
  br i1 %r937, label %pic.desc.prefix.hit.158, label %pic.miss.cold.160

pic.desc.prefix.hit.158:                          ; preds = %pic.desc.prefix.token.157
  %r938 = getelementptr i64, ptr %r878, i64 1
  %r939 = load i64, ptr %r938, align 8
  %r940 = shl i64 %r939, 3
  %r941 = add nuw nsw i64 %r858, 16
  %r942 = add i64 %r941, %r940
  %r943 = inttoptr i64 %r942 to ptr
  %r944 = load double, ptr %r943, align 8
  br label %pic.merge.162

pic.miss.159:                                     ; preds = %pic.hit.inline.166, %pic.prefix.token.152, %pic.prefix.meta.151, %pic.prefix.guard.150
  %r945 = getelementptr i64, ptr %r878, i64 3
  %r946 = load i64, ptr %r945, align 8
  %r947 = icmp sgt i64 %r946, 0
  br i1 %r947, label %pic.ways.167, label %pic.miss.call.161

pic.miss.cold.160:                                ; preds = %pic.desc.prefix.token.157, %pic.desc.prefix.meta.156, %pic.desc.prefix.guard.155, %pic.desc.classify.154, %pget.recv_ok.142
  br label %pic.miss.call.161

pic.miss.call.161:                                ; preds = %pic.way.load.168, %pic.ways.167, %pic.miss.cold.160, %pic.miss.159
  %r986 = load double, ptr @options_worker_ts_.str.22.handle, align 8
  %r987 = bitcast double %r986 to i64
  %r988 = and i64 %r987, 281474976710655
  %statepoint_token237 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r858, i64 %r988, ptr @perry_ic_options_worker_ts__34, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated220, ptr addrspace(1) %rs4gc.s8.relocated221, ptr addrspace(1) %rs4gc.s9.relocated222, ptr addrspace(1) %rs4gc.s12.relocated223, ptr addrspace(1) %rs4gc.s15) ]
  %r989238 = call double @llvm.experimental.gc.result.f64(token %statepoint_token237)
  %rs4gc.s11.relocated239 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token237, i32 0, i32 0) ; (%rs4gc.s11.relocated220, %rs4gc.s11.relocated220)
  %rs4gc.s8.relocated240 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token237, i32 1, i32 1) ; (%rs4gc.s8.relocated221, %rs4gc.s8.relocated221)
  %rs4gc.s9.relocated241 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token237, i32 2, i32 2) ; (%rs4gc.s9.relocated222, %rs4gc.s9.relocated222)
  %rs4gc.s12.relocated242 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token237, i32 3, i32 3) ; (%rs4gc.s12.relocated223, %rs4gc.s12.relocated223)
  %rs4gc.s15.relocated243 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token237, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pic.merge.162

pic.merge.162:                                    ; preds = %pic.way.live.169, %pic.hit.overflow.165, %pic.miss.call.161, %pic.desc.prefix.hit.158, %pic.prefix.hit.153, %pic.hit.live.149
  %.1515 = phi ptr addrspace(1) [ %rs4gc.s15.relocated250, %pic.hit.overflow.165 ], [ %rs4gc.s15.relocated243, %pic.miss.call.161 ], [ %rs4gc.s15, %pic.way.live.169 ], [ %rs4gc.s15, %pic.hit.live.149 ], [ %rs4gc.s15, %pic.prefix.hit.153 ], [ %rs4gc.s15, %pic.desc.prefix.hit.158 ]
  %.1510 = phi ptr addrspace(1) [ %rs4gc.s12.relocated249, %pic.hit.overflow.165 ], [ %rs4gc.s12.relocated242, %pic.miss.call.161 ], [ %rs4gc.s12.relocated223, %pic.way.live.169 ], [ %rs4gc.s12.relocated223, %pic.hit.live.149 ], [ %rs4gc.s12.relocated223, %pic.prefix.hit.153 ], [ %rs4gc.s12.relocated223, %pic.desc.prefix.hit.158 ]
  %.2499 = phi ptr addrspace(1) [ %rs4gc.s11.relocated246, %pic.hit.overflow.165 ], [ %rs4gc.s11.relocated239, %pic.miss.call.161 ], [ %rs4gc.s11.relocated220, %pic.way.live.169 ], [ %rs4gc.s11.relocated220, %pic.hit.live.149 ], [ %rs4gc.s11.relocated220, %pic.prefix.hit.153 ], [ %rs4gc.s11.relocated220, %pic.desc.prefix.hit.158 ]
  %.3491 = phi ptr addrspace(1) [ %rs4gc.s9.relocated248, %pic.hit.overflow.165 ], [ %rs4gc.s9.relocated241, %pic.miss.call.161 ], [ %rs4gc.s9.relocated222, %pic.way.live.169 ], [ %rs4gc.s9.relocated222, %pic.hit.live.149 ], [ %rs4gc.s9.relocated222, %pic.prefix.hit.153 ], [ %rs4gc.s9.relocated222, %pic.desc.prefix.hit.158 ]
  %.3487 = phi ptr addrspace(1) [ %rs4gc.s8.relocated247, %pic.hit.overflow.165 ], [ %rs4gc.s8.relocated240, %pic.miss.call.161 ], [ %rs4gc.s8.relocated221, %pic.way.live.169 ], [ %rs4gc.s8.relocated221, %pic.hit.live.149 ], [ %rs4gc.s8.relocated221, %pic.prefix.hit.153 ], [ %rs4gc.s8.relocated221, %pic.desc.prefix.hit.158 ]
  %r990 = phi double [ %r906, %pic.hit.live.149 ], [ %r901245, %pic.hit.overflow.165 ], [ %r926, %pic.prefix.hit.153 ], [ %r944, %pic.desc.prefix.hit.158 ], [ %r983, %pic.way.live.169 ], [ %r989238, %pic.miss.call.161 ]
  br label %pget.recv_merge.145

pic.recv_hdr.163:                                 ; preds = %pget.recv_ok.142
  %r869 = sub nuw nsw i64 %r858, 8
  %r870 = inttoptr i64 %r869 to ptr
  %r871 = load i8, ptr %r870, align 1
  %r872 = icmp eq i8 %r871, 2
  %r873 = sub nuw nsw i64 %r858, 6
  %r874 = inttoptr i64 %r873 to ptr
  %r875 = load i16, ptr %r874, align 2
  %r876 = and i16 %r875, 2048
  %r877 = icmp eq i16 %r876, 0
  %r878 = load ptr, ptr @perry_ic_options_worker_ts__34, align 8
  %r879 = icmp ne ptr %r878, null
  %r880 = and i1 %r872, %r877
  %r881 = and i1 %r880, %r879
  br i1 %r881, label %pic.token.164, label %pic.desc.classify.154

pic.token.164:                                    ; preds = %pic.recv_hdr.163
  %r883 = add nuw nsw i64 %r858, 4
  %r884 = inttoptr i64 %r883 to ptr
  %r885 = load i32, ptr %r884, align 4
  %r886 = zext i32 %r885 to i64
  %r887 = or i64 %r886, 4611686018427387904
  %r888 = icmp ne i32 %r885, 0
  %r889 = getelementptr i64, ptr %r878, i64 0
  %r890 = load i64, ptr %r889, align 8
  %r891 = icmp eq i64 %r887, %r890
  %r892 = and i1 %r891, %r888
  br i1 %r892, label %pic.hit.148, label %pic.prefix.guard.150

pic.hit.overflow.165:                             ; preds = %pic.hit.148
  %r897 = load double, ptr @options_worker_ts_.str.22.handle, align 8
  %r898 = bitcast double %r897 to i64
  %r899 = and i64 %r898, 281474976710655
  %r900 = trunc i64 %r894 to i32
  %statepoint_token244 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r858, i64 %r899, i32 %r900, ptr @perry_ic_options_worker_ts__34, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated220, ptr addrspace(1) %rs4gc.s8.relocated221, ptr addrspace(1) %rs4gc.s9.relocated222, ptr addrspace(1) %rs4gc.s12.relocated223, ptr addrspace(1) %rs4gc.s15) ]
  %r901245 = call double @llvm.experimental.gc.result.f64(token %statepoint_token244)
  %rs4gc.s11.relocated246 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 0, i32 0) ; (%rs4gc.s11.relocated220, %rs4gc.s11.relocated220)
  %rs4gc.s8.relocated247 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 1, i32 1) ; (%rs4gc.s8.relocated221, %rs4gc.s8.relocated221)
  %rs4gc.s9.relocated248 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 2, i32 2) ; (%rs4gc.s9.relocated222, %rs4gc.s9.relocated222)
  %rs4gc.s12.relocated249 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 3, i32 3) ; (%rs4gc.s12.relocated223, %rs4gc.s12.relocated223)
  %rs4gc.s15.relocated250 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token244, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pic.merge.162

pic.hit.inline.166:                               ; preds = %pic.hit.148
  %r902 = shl i64 %r894, 3
  %r903 = add nuw nsw i64 %r858, 16
  %r904 = add i64 %r903, %r902
  %r905 = inttoptr i64 %r904 to ptr
  %r906 = load double, ptr %r905, align 8
  %r907 = bitcast double %r906 to i64
  %r908 = icmp eq i64 %r907, 9222246136947933200
  br i1 %r908, label %pic.miss.159, label %pic.hit.live.149

pic.ways.167:                                     ; preds = %pic.miss.159
  %r948 = getelementptr i64, ptr %r878, i64 4
  %r949 = load i64, ptr %r948, align 8
  %r950 = icmp eq i64 %r949, %r887
  %r951 = getelementptr i64, ptr %r878, i64 5
  %r952 = load i64, ptr %r951, align 8
  %r953 = select i1 %r950, i64 %r952, i64 0
  %r954 = getelementptr i64, ptr %r878, i64 6
  %r955 = load i64, ptr %r954, align 8
  %r956 = icmp eq i64 %r955, %r887
  %r957 = getelementptr i64, ptr %r878, i64 7
  %r958 = load i64, ptr %r957, align 8
  %r959 = select i1 %r956, i64 %r958, i64 0
  %r960 = getelementptr i64, ptr %r878, i64 8
  %r961 = load i64, ptr %r960, align 8
  %r962 = icmp eq i64 %r961, %r887
  %r963 = getelementptr i64, ptr %r878, i64 9
  %r964 = load i64, ptr %r963, align 8
  %r965 = select i1 %r962, i64 %r964, i64 0
  %r966 = getelementptr i64, ptr %r878, i64 10
  %r967 = load i64, ptr %r966, align 8
  %r968 = icmp eq i64 %r967, %r887
  %r969 = getelementptr i64, ptr %r878, i64 11
  %r970 = load i64, ptr %r969, align 8
  %r971 = select i1 %r968, i64 %r970, i64 0
  %r972 = or i1 %r950, %r956
  %r973 = select i1 %r950, i64 %r953, i64 %r959
  %r974 = or i1 %r962, %r968
  %r975 = select i1 %r962, i64 %r965, i64 %r971
  %r976 = or i1 %r972, %r974
  %r977 = select i1 %r972, i64 %r973, i64 %r975
  %r978 = and i1 %r888, %r976
  br i1 %r978, label %pic.way.load.168, label %pic.miss.call.161

pic.way.load.168:                                 ; preds = %pic.ways.167
  %r979 = shl i64 %r977, 3
  %r980 = add nuw nsw i64 %r858, 16
  %r981 = add i64 %r980, %r979
  %r982 = inttoptr i64 %r981 to ptr
  %r983 = load double, ptr %r982, align 8
  %r984 = bitcast double %r983 to i64
  %r985 = icmp eq i64 %r984, 9222246136947933200
  br i1 %r985, label %pic.miss.call.161, label %pic.way.live.169

pic.way.live.169:                                 ; preds = %pic.way.load.168
  br label %pic.merge.162

pget.throw_nullish.170:                           ; preds = %pget.recv_bad.143
  %r994 = zext i1 %r992 to i32
  %statepoint_token251 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r994, ptr @options_worker_ts_.str.22.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.171:                       ; preds = %pget.recv_bad.143
  %r995 = load double, ptr @options_worker_ts_.str.22.handle, align 8
  %r996 = bitcast double %r995 to i64
  %r997 = and i64 %r996, 281474976710655
  %statepoint_token252 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r857, i64 %r997, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated220, ptr addrspace(1) %rs4gc.s8.relocated221, ptr addrspace(1) %rs4gc.s9.relocated222, ptr addrspace(1) %rs4gc.s12.relocated223, ptr addrspace(1) %rs4gc.s15) ]
  %r998253 = call double @llvm.experimental.gc.result.f64(token %statepoint_token252)
  %rs4gc.s11.relocated254 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 0, i32 0) ; (%rs4gc.s11.relocated220, %rs4gc.s11.relocated220)
  %rs4gc.s8.relocated255 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 1, i32 1) ; (%rs4gc.s8.relocated221, %rs4gc.s8.relocated221)
  %rs4gc.s9.relocated256 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 2, i32 2) ; (%rs4gc.s9.relocated222, %rs4gc.s9.relocated222)
  %rs4gc.s12.relocated257 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 3, i32 3) ; (%rs4gc.s12.relocated223, %rs4gc.s12.relocated223)
  %rs4gc.s15.relocated258 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token252, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.145

shadow.root.barrier.172:                          ; preds = %pget.recv_merge.145
  call void @js_write_barrier_root_nanbox(i64 %r1006) #9
  br label %shadow.root.barrier.done.173

shadow.root.barrier.done.173:                     ; preds = %shadow.root.barrier.172, %pget.recv_merge.145
  %r1009.rs4i = ptrtoint ptr addrspace(1) %.2490 to i64
  %r1009.rs4o = call i64 asm "", "=r,0"(i64 %r1009.rs4i) #9
  %r1009 = bitcast i64 %r1009.rs4o to double
  %r1010 = bitcast double %r1009 to i64
  %r1011 = and i64 %r1010, 281474976710655
  %r1012 = lshr i64 %r1010, 48
  %r1013 = and i64 %r1012, 65533
  %r1014 = icmp eq i64 %r1013, 32765
  br i1 %r1014, label %pget.recv_ok.175, label %pget.recv_other.179

pget.recv_sso.174:                                ; preds = %pget.recv_other.179
  %r1152 = load double, ptr @options_worker_ts_.str.22.handle, align 8
  %r1153 = bitcast double %r1152 to i64
  %r1154 = and i64 %r1153, 281474976710655
  %statepoint_token259 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1010, i64 %r1154, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1498, ptr addrspace(1) %.2486, ptr addrspace(1) %.2490, ptr addrspace(1) %.0509, ptr addrspace(1) %.0514, ptr addrspace(1) %rs4gc.s16) ]
  %r1155260 = call double @llvm.experimental.gc.result.f64(token %statepoint_token259)
  %rs4gc.s11.relocated261 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 0, i32 0) ; (%.1498, %.1498)
  %rs4gc.s8.relocated262 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 1, i32 1) ; (%.2486, %.2486)
  %rs4gc.s9.relocated263 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 2, i32 2) ; (%.2490, %.2490)
  %rs4gc.s12.relocated264 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 3, i32 3) ; (%.0509, %.0509)
  %rs4gc.s15.relocated265 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 4, i32 4) ; (%.0514, %.0514)
  %rs4gc.s16.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pget.recv_merge.178

pget.recv_ok.175:                                 ; preds = %shadow.root.barrier.done.173
  %r1021 = icmp ugt i64 %r1011, 1048575
  br i1 %r1021, label %pic.recv_hdr.196, label %pic.miss.cold.193

pget.recv_bad.176:                                ; preds = %pget.check_class_ref.180
  %r1144 = icmp eq i64 %r1010, 9222246136947933185
  %r1145 = icmp eq i64 %r1010, 9222246136947933186
  %r1146 = or i1 %r1144, %r1145
  br i1 %r1146, label %pget.throw_nullish.203, label %pget.recv_undef_return.204

pget.recv_class_ref.177:                          ; preds = %pget.check_class_ref.180
  %r1017 = load double, ptr @options_worker_ts_.str.22.handle, align 8
  %r1018 = bitcast double %r1017 to i64
  %r1019 = and i64 %r1018, 281474976710655
  %statepoint_token266 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532899, i64 %r1010, i64 %r1019, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1498, ptr addrspace(1) %.2486, ptr addrspace(1) %.2490, ptr addrspace(1) %.0509, ptr addrspace(1) %.0514, ptr addrspace(1) %rs4gc.s16) ]
  %r1020267 = call double @llvm.experimental.gc.result.f64(token %statepoint_token266)
  %rs4gc.s11.relocated268 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token266, i32 0, i32 0) ; (%.1498, %.1498)
  %rs4gc.s8.relocated269 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token266, i32 1, i32 1) ; (%.2486, %.2486)
  %rs4gc.s9.relocated270 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token266, i32 2, i32 2) ; (%.2490, %.2490)
  %rs4gc.s12.relocated271 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token266, i32 3, i32 3) ; (%.0509, %.0509)
  %rs4gc.s15.relocated272 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token266, i32 4, i32 4) ; (%.0514, %.0514)
  %rs4gc.s16.relocated273 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token266, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pget.recv_merge.178

pget.recv_merge.178:                              ; preds = %pget.recv_undef_return.204, %pic.merge.195, %pget.recv_class_ref.177, %pget.recv_sso.174
  %.0519 = phi ptr addrspace(1) [ %.1520, %pic.merge.195 ], [ %rs4gc.s16.relocated, %pget.recv_sso.174 ], [ %rs4gc.s16.relocated273, %pget.recv_class_ref.177 ], [ %rs4gc.s16.relocated298, %pget.recv_undef_return.204 ]
  %.2516 = phi ptr addrspace(1) [ %.3517, %pic.merge.195 ], [ %rs4gc.s15.relocated265, %pget.recv_sso.174 ], [ %rs4gc.s15.relocated272, %pget.recv_class_ref.177 ], [ %rs4gc.s15.relocated297, %pget.recv_undef_return.204 ]
  %.2511 = phi ptr addrspace(1) [ %.3512, %pic.merge.195 ], [ %rs4gc.s12.relocated264, %pget.recv_sso.174 ], [ %rs4gc.s12.relocated271, %pget.recv_class_ref.177 ], [ %rs4gc.s12.relocated296, %pget.recv_undef_return.204 ]
  %.3500 = phi ptr addrspace(1) [ %.4501, %pic.merge.195 ], [ %rs4gc.s11.relocated261, %pget.recv_sso.174 ], [ %rs4gc.s11.relocated268, %pget.recv_class_ref.177 ], [ %rs4gc.s11.relocated293, %pget.recv_undef_return.204 ]
  %.4492 = phi ptr addrspace(1) [ %.5493, %pic.merge.195 ], [ %rs4gc.s9.relocated263, %pget.recv_sso.174 ], [ %rs4gc.s9.relocated270, %pget.recv_class_ref.177 ], [ %rs4gc.s9.relocated295, %pget.recv_undef_return.204 ]
  %.4 = phi ptr addrspace(1) [ %.5, %pic.merge.195 ], [ %rs4gc.s8.relocated262, %pget.recv_sso.174 ], [ %rs4gc.s8.relocated269, %pget.recv_class_ref.177 ], [ %rs4gc.s8.relocated294, %pget.recv_undef_return.204 ]
  %r1156 = phi double [ %r1143, %pic.merge.195 ], [ %r1151292, %pget.recv_undef_return.204 ], [ %r1155260, %pget.recv_sso.174 ], [ %r1020267, %pget.recv_class_ref.177 ]
  %r1157.rs4i = ptrtoint ptr addrspace(1) %.0519 to i64
  %r1157 = call i64 asm "", "=r,0"(i64 %r1157.rs4i) #9
  %r1158 = bitcast i64 %r1157 to double
  %r1159 = and i64 %r1157, -281474976710656
  %r1160 = icmp ult i64 %r1159, 9221401712017801216
  %r1161 = icmp ugt i64 %r1159, 9223090561878065152
  %r1162 = or i1 %r1160, %r1161
  %r1163 = bitcast double %r1156 to i64
  %r1164 = and i64 %r1163, -281474976710656
  %r1165 = icmp ult i64 %r1164, 9221401712017801216
  %r1166 = icmp ugt i64 %r1164, 9223090561878065152
  %r1167 = or i1 %r1165, %r1166
  %r1168 = and i1 %r1162, %r1167
  br i1 %r1168, label %guarded_arith.numeric.205, label %guarded_arith.dynamic.206

pget.recv_other.179:                              ; preds = %shadow.root.barrier.done.173
  %r1015 = icmp eq i64 %r1012, 32761
  br i1 %r1015, label %pget.recv_sso.174, label %pget.check_class_ref.180

pget.check_class_ref.180:                         ; preds = %pget.recv_other.179
  %r1016 = icmp eq i64 %r1012, 32766
  br i1 %r1016, label %pget.recv_class_ref.177, label %pget.recv_bad.176

pic.hit.181:                                      ; preds = %pic.token.197
  %r1046 = getelementptr i64, ptr %r1031, i64 1
  %r1047 = load i64, ptr %r1046, align 8
  %r1048 = and i64 %r1047, 1073741824
  %r1049 = icmp ne i64 %r1048, 0
  br i1 %r1049, label %pic.hit.overflow.198, label %pic.hit.inline.199

pic.hit.live.182:                                 ; preds = %pic.hit.inline.199
  br label %pic.merge.195

pic.prefix.guard.183:                             ; preds = %pic.token.197
  %r1062 = getelementptr i64, ptr %r1031, i64 2
  %r1063 = load i64, ptr %r1062, align 8
  %r1064 = icmp ne i64 %r1063, 0
  br i1 %r1064, label %pic.prefix.meta.184, label %pic.miss.192

pic.prefix.meta.184:                              ; preds = %pic.prefix.guard.183
  %r1065 = add nuw nsw i64 %r1011, 8
  %r1066 = inttoptr i64 %r1065 to ptr
  %r1067 = load i64, ptr %r1066, align 8
  %r1068 = icmp ne i64 %r1067, 0
  br i1 %r1068, label %pic.prefix.token.185, label %pic.miss.192

pic.prefix.token.185:                             ; preds = %pic.prefix.meta.184
  %r1069 = inttoptr i64 %r1067 to ptr
  %r1070 = getelementptr i64, ptr %r1069, i64 6
  %r1071 = load i64, ptr %r1070, align 8
  %r1072 = icmp eq i64 %r1071, %r1063
  br i1 %r1072, label %pic.prefix.hit.186, label %pic.miss.192

pic.prefix.hit.186:                               ; preds = %pic.prefix.token.185
  %r1073 = getelementptr i64, ptr %r1031, i64 1
  %r1074 = load i64, ptr %r1073, align 8
  %r1075 = shl i64 %r1074, 3
  %r1076 = add nuw nsw i64 %r1011, 16
  %r1077 = add i64 %r1076, %r1075
  %r1078 = inttoptr i64 %r1077 to ptr
  %r1079 = load double, ptr %r1078, align 8
  br label %pic.merge.195

pic.desc.classify.187:                            ; preds = %pic.recv_hdr.196
  %r1035 = and i1 %r1025, %r1032
  br i1 %r1035, label %pic.desc.prefix.guard.188, label %pic.miss.cold.193

pic.desc.prefix.guard.188:                        ; preds = %pic.desc.classify.187
  %r1080 = getelementptr i64, ptr %r1031, i64 2
  %r1081 = load i64, ptr %r1080, align 8
  %r1082 = icmp ne i64 %r1081, 0
  br i1 %r1082, label %pic.desc.prefix.meta.189, label %pic.miss.cold.193

pic.desc.prefix.meta.189:                         ; preds = %pic.desc.prefix.guard.188
  %r1083 = add nuw nsw i64 %r1011, 8
  %r1084 = inttoptr i64 %r1083 to ptr
  %r1085 = load i64, ptr %r1084, align 8
  %r1086 = icmp ne i64 %r1085, 0
  br i1 %r1086, label %pic.desc.prefix.token.190, label %pic.miss.cold.193

pic.desc.prefix.token.190:                        ; preds = %pic.desc.prefix.meta.189
  %r1087 = inttoptr i64 %r1085 to ptr
  %r1088 = getelementptr i64, ptr %r1087, i64 6
  %r1089 = load i64, ptr %r1088, align 8
  %r1090 = icmp eq i64 %r1089, %r1081
  br i1 %r1090, label %pic.desc.prefix.hit.191, label %pic.miss.cold.193

pic.desc.prefix.hit.191:                          ; preds = %pic.desc.prefix.token.190
  %r1091 = getelementptr i64, ptr %r1031, i64 1
  %r1092 = load i64, ptr %r1091, align 8
  %r1093 = shl i64 %r1092, 3
  %r1094 = add nuw nsw i64 %r1011, 16
  %r1095 = add i64 %r1094, %r1093
  %r1096 = inttoptr i64 %r1095 to ptr
  %r1097 = load double, ptr %r1096, align 8
  br label %pic.merge.195

pic.miss.192:                                     ; preds = %pic.hit.inline.199, %pic.prefix.token.185, %pic.prefix.meta.184, %pic.prefix.guard.183
  %r1098 = getelementptr i64, ptr %r1031, i64 3
  %r1099 = load i64, ptr %r1098, align 8
  %r1100 = icmp sgt i64 %r1099, 0
  br i1 %r1100, label %pic.ways.200, label %pic.miss.call.194

pic.miss.cold.193:                                ; preds = %pic.desc.prefix.token.190, %pic.desc.prefix.meta.189, %pic.desc.prefix.guard.188, %pic.desc.classify.187, %pget.recv_ok.175
  br label %pic.miss.call.194

pic.miss.call.194:                                ; preds = %pic.way.load.201, %pic.ways.200, %pic.miss.cold.193, %pic.miss.192
  %r1139 = load double, ptr @options_worker_ts_.str.22.handle, align 8
  %r1140 = bitcast double %r1139 to i64
  %r1141 = and i64 %r1140, 281474976710655
  %statepoint_token274 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1011, i64 %r1141, ptr @perry_ic_options_worker_ts__36, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1498, ptr addrspace(1) %.2486, ptr addrspace(1) %.2490, ptr addrspace(1) %.0509, ptr addrspace(1) %.0514, ptr addrspace(1) %rs4gc.s16) ]
  %r1142275 = call double @llvm.experimental.gc.result.f64(token %statepoint_token274)
  %rs4gc.s11.relocated276 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 0, i32 0) ; (%.1498, %.1498)
  %rs4gc.s8.relocated277 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 1, i32 1) ; (%.2486, %.2486)
  %rs4gc.s9.relocated278 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 2, i32 2) ; (%.2490, %.2490)
  %rs4gc.s12.relocated279 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 3, i32 3) ; (%.0509, %.0509)
  %rs4gc.s15.relocated280 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 4, i32 4) ; (%.0514, %.0514)
  %rs4gc.s16.relocated281 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token274, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pic.merge.195

pic.merge.195:                                    ; preds = %pic.way.live.202, %pic.hit.overflow.198, %pic.miss.call.194, %pic.desc.prefix.hit.191, %pic.prefix.hit.186, %pic.hit.live.182
  %.1520 = phi ptr addrspace(1) [ %rs4gc.s16.relocated289, %pic.hit.overflow.198 ], [ %rs4gc.s16.relocated281, %pic.miss.call.194 ], [ %rs4gc.s16, %pic.way.live.202 ], [ %rs4gc.s16, %pic.hit.live.182 ], [ %rs4gc.s16, %pic.prefix.hit.186 ], [ %rs4gc.s16, %pic.desc.prefix.hit.191 ]
  %.3517 = phi ptr addrspace(1) [ %rs4gc.s15.relocated288, %pic.hit.overflow.198 ], [ %rs4gc.s15.relocated280, %pic.miss.call.194 ], [ %.0514, %pic.way.live.202 ], [ %.0514, %pic.hit.live.182 ], [ %.0514, %pic.prefix.hit.186 ], [ %.0514, %pic.desc.prefix.hit.191 ]
  %.3512 = phi ptr addrspace(1) [ %rs4gc.s12.relocated287, %pic.hit.overflow.198 ], [ %rs4gc.s12.relocated279, %pic.miss.call.194 ], [ %.0509, %pic.way.live.202 ], [ %.0509, %pic.hit.live.182 ], [ %.0509, %pic.prefix.hit.186 ], [ %.0509, %pic.desc.prefix.hit.191 ]
  %.4501 = phi ptr addrspace(1) [ %rs4gc.s11.relocated284, %pic.hit.overflow.198 ], [ %rs4gc.s11.relocated276, %pic.miss.call.194 ], [ %.1498, %pic.way.live.202 ], [ %.1498, %pic.hit.live.182 ], [ %.1498, %pic.prefix.hit.186 ], [ %.1498, %pic.desc.prefix.hit.191 ]
  %.5493 = phi ptr addrspace(1) [ %rs4gc.s9.relocated286, %pic.hit.overflow.198 ], [ %rs4gc.s9.relocated278, %pic.miss.call.194 ], [ %.2490, %pic.way.live.202 ], [ %.2490, %pic.hit.live.182 ], [ %.2490, %pic.prefix.hit.186 ], [ %.2490, %pic.desc.prefix.hit.191 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s8.relocated285, %pic.hit.overflow.198 ], [ %rs4gc.s8.relocated277, %pic.miss.call.194 ], [ %.2486, %pic.way.live.202 ], [ %.2486, %pic.hit.live.182 ], [ %.2486, %pic.prefix.hit.186 ], [ %.2486, %pic.desc.prefix.hit.191 ]
  %r1143 = phi double [ %r1059, %pic.hit.live.182 ], [ %r1054283, %pic.hit.overflow.198 ], [ %r1079, %pic.prefix.hit.186 ], [ %r1097, %pic.desc.prefix.hit.191 ], [ %r1136, %pic.way.live.202 ], [ %r1142275, %pic.miss.call.194 ]
  br label %pget.recv_merge.178

pic.recv_hdr.196:                                 ; preds = %pget.recv_ok.175
  %r1022 = sub nuw nsw i64 %r1011, 8
  %r1023 = inttoptr i64 %r1022 to ptr
  %r1024 = load i8, ptr %r1023, align 1
  %r1025 = icmp eq i8 %r1024, 2
  %r1026 = sub nuw nsw i64 %r1011, 6
  %r1027 = inttoptr i64 %r1026 to ptr
  %r1028 = load i16, ptr %r1027, align 2
  %r1029 = and i16 %r1028, 2048
  %r1030 = icmp eq i16 %r1029, 0
  %r1031 = load ptr, ptr @perry_ic_options_worker_ts__36, align 8
  %r1032 = icmp ne ptr %r1031, null
  %r1033 = and i1 %r1025, %r1030
  %r1034 = and i1 %r1033, %r1032
  br i1 %r1034, label %pic.token.197, label %pic.desc.classify.187

pic.token.197:                                    ; preds = %pic.recv_hdr.196
  %r1036 = add nuw nsw i64 %r1011, 4
  %r1037 = inttoptr i64 %r1036 to ptr
  %r1038 = load i32, ptr %r1037, align 4
  %r1039 = zext i32 %r1038 to i64
  %r1040 = or i64 %r1039, 4611686018427387904
  %r1041 = icmp ne i32 %r1038, 0
  %r1042 = getelementptr i64, ptr %r1031, i64 0
  %r1043 = load i64, ptr %r1042, align 8
  %r1044 = icmp eq i64 %r1040, %r1043
  %r1045 = and i1 %r1044, %r1041
  br i1 %r1045, label %pic.hit.181, label %pic.prefix.guard.183

pic.hit.overflow.198:                             ; preds = %pic.hit.181
  %r1050 = load double, ptr @options_worker_ts_.str.22.handle, align 8
  %r1051 = bitcast double %r1050 to i64
  %r1052 = and i64 %r1051, 281474976710655
  %r1053 = trunc i64 %r1047 to i32
  %statepoint_token282 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1011, i64 %r1052, i32 %r1053, ptr @perry_ic_options_worker_ts__36, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1498, ptr addrspace(1) %.2486, ptr addrspace(1) %.2490, ptr addrspace(1) %.0509, ptr addrspace(1) %.0514, ptr addrspace(1) %rs4gc.s16) ]
  %r1054283 = call double @llvm.experimental.gc.result.f64(token %statepoint_token282)
  %rs4gc.s11.relocated284 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token282, i32 0, i32 0) ; (%.1498, %.1498)
  %rs4gc.s8.relocated285 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token282, i32 1, i32 1) ; (%.2486, %.2486)
  %rs4gc.s9.relocated286 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token282, i32 2, i32 2) ; (%.2490, %.2490)
  %rs4gc.s12.relocated287 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token282, i32 3, i32 3) ; (%.0509, %.0509)
  %rs4gc.s15.relocated288 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token282, i32 4, i32 4) ; (%.0514, %.0514)
  %rs4gc.s16.relocated289 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token282, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pic.merge.195

pic.hit.inline.199:                               ; preds = %pic.hit.181
  %r1055 = shl i64 %r1047, 3
  %r1056 = add nuw nsw i64 %r1011, 16
  %r1057 = add i64 %r1056, %r1055
  %r1058 = inttoptr i64 %r1057 to ptr
  %r1059 = load double, ptr %r1058, align 8
  %r1060 = bitcast double %r1059 to i64
  %r1061 = icmp eq i64 %r1060, 9222246136947933200
  br i1 %r1061, label %pic.miss.192, label %pic.hit.live.182

pic.ways.200:                                     ; preds = %pic.miss.192
  %r1101 = getelementptr i64, ptr %r1031, i64 4
  %r1102 = load i64, ptr %r1101, align 8
  %r1103 = icmp eq i64 %r1102, %r1040
  %r1104 = getelementptr i64, ptr %r1031, i64 5
  %r1105 = load i64, ptr %r1104, align 8
  %r1106 = select i1 %r1103, i64 %r1105, i64 0
  %r1107 = getelementptr i64, ptr %r1031, i64 6
  %r1108 = load i64, ptr %r1107, align 8
  %r1109 = icmp eq i64 %r1108, %r1040
  %r1110 = getelementptr i64, ptr %r1031, i64 7
  %r1111 = load i64, ptr %r1110, align 8
  %r1112 = select i1 %r1109, i64 %r1111, i64 0
  %r1113 = getelementptr i64, ptr %r1031, i64 8
  %r1114 = load i64, ptr %r1113, align 8
  %r1115 = icmp eq i64 %r1114, %r1040
  %r1116 = getelementptr i64, ptr %r1031, i64 9
  %r1117 = load i64, ptr %r1116, align 8
  %r1118 = select i1 %r1115, i64 %r1117, i64 0
  %r1119 = getelementptr i64, ptr %r1031, i64 10
  %r1120 = load i64, ptr %r1119, align 8
  %r1121 = icmp eq i64 %r1120, %r1040
  %r1122 = getelementptr i64, ptr %r1031, i64 11
  %r1123 = load i64, ptr %r1122, align 8
  %r1124 = select i1 %r1121, i64 %r1123, i64 0
  %r1125 = or i1 %r1103, %r1109
  %r1126 = select i1 %r1103, i64 %r1106, i64 %r1112
  %r1127 = or i1 %r1115, %r1121
  %r1128 = select i1 %r1115, i64 %r1118, i64 %r1124
  %r1129 = or i1 %r1125, %r1127
  %r1130 = select i1 %r1125, i64 %r1126, i64 %r1128
  %r1131 = and i1 %r1041, %r1129
  br i1 %r1131, label %pic.way.load.201, label %pic.miss.call.194

pic.way.load.201:                                 ; preds = %pic.ways.200
  %r1132 = shl i64 %r1130, 3
  %r1133 = add nuw nsw i64 %r1011, 16
  %r1134 = add i64 %r1133, %r1132
  %r1135 = inttoptr i64 %r1134 to ptr
  %r1136 = load double, ptr %r1135, align 8
  %r1137 = bitcast double %r1136 to i64
  %r1138 = icmp eq i64 %r1137, 9222246136947933200
  br i1 %r1138, label %pic.miss.call.194, label %pic.way.live.202

pic.way.live.202:                                 ; preds = %pic.way.load.201
  br label %pic.merge.195

pget.throw_nullish.203:                           ; preds = %pget.recv_bad.176
  %r1147 = zext i1 %r1145 to i32
  %statepoint_token290 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1147, ptr @options_worker_ts_.str.22.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.204:                       ; preds = %pget.recv_bad.176
  %r1148 = load double, ptr @options_worker_ts_.str.22.handle, align 8
  %r1149 = bitcast double %r1148 to i64
  %r1150 = and i64 %r1149, 281474976710655
  %statepoint_token291 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1010, i64 %r1150, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1498, ptr addrspace(1) %.2486, ptr addrspace(1) %.2490, ptr addrspace(1) %.0509, ptr addrspace(1) %.0514, ptr addrspace(1) %rs4gc.s16) ]
  %r1151292 = call double @llvm.experimental.gc.result.f64(token %statepoint_token291)
  %rs4gc.s11.relocated293 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 0, i32 0) ; (%.1498, %.1498)
  %rs4gc.s8.relocated294 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 1, i32 1) ; (%.2486, %.2486)
  %rs4gc.s9.relocated295 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 2, i32 2) ; (%.2490, %.2490)
  %rs4gc.s12.relocated296 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 3, i32 3) ; (%.0509, %.0509)
  %rs4gc.s15.relocated297 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 4, i32 4) ; (%.0514, %.0514)
  %rs4gc.s16.relocated298 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token291, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pget.recv_merge.178

guarded_arith.numeric.205:                        ; preds = %pget.recv_merge.178
  %r1169 = fsub double %r1158, %r1156
  br label %guarded_arith.merge.207

guarded_arith.dynamic.206:                        ; preds = %pget.recv_merge.178
  %statepoint_token299 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_sub, i32 2, i32 0, double %r1158, double %r1156, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3500, ptr addrspace(1) %.4, ptr addrspace(1) %.4492, ptr addrspace(1) %.2511, ptr addrspace(1) %.2516) ]
  %r1170300 = call double @llvm.experimental.gc.result.f64(token %statepoint_token299)
  %rs4gc.s11.relocated301 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token299, i32 0, i32 0) ; (%.3500, %.3500)
  %rs4gc.s8.relocated302 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token299, i32 1, i32 1) ; (%.4, %.4)
  %rs4gc.s9.relocated303 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token299, i32 2, i32 2) ; (%.4492, %.4492)
  %rs4gc.s12.relocated304 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token299, i32 3, i32 3) ; (%.2511, %.2511)
  %rs4gc.s15.relocated305 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token299, i32 4, i32 4) ; (%.2516, %.2516)
  br label %guarded_arith.merge.207

guarded_arith.merge.207:                          ; preds = %guarded_arith.dynamic.206, %guarded_arith.numeric.205
  %.4518 = phi ptr addrspace(1) [ %.2516, %guarded_arith.numeric.205 ], [ %rs4gc.s15.relocated305, %guarded_arith.dynamic.206 ]
  %.4513 = phi ptr addrspace(1) [ %.2511, %guarded_arith.numeric.205 ], [ %rs4gc.s12.relocated304, %guarded_arith.dynamic.206 ]
  %.5502 = phi ptr addrspace(1) [ %.3500, %guarded_arith.numeric.205 ], [ %rs4gc.s11.relocated301, %guarded_arith.dynamic.206 ]
  %.6494 = phi ptr addrspace(1) [ %.4492, %guarded_arith.numeric.205 ], [ %rs4gc.s9.relocated303, %guarded_arith.dynamic.206 ]
  %.6 = phi ptr addrspace(1) [ %.4, %guarded_arith.numeric.205 ], [ %rs4gc.s8.relocated302, %guarded_arith.dynamic.206 ]
  %r1171 = phi double [ %r1169, %guarded_arith.numeric.205 ], [ %r1170300, %guarded_arith.dynamic.206 ]
  %r1172.rs4i = ptrtoint ptr addrspace(1) %.4518 to i64
  %r1172 = call i64 asm "", "=r,0"(i64 %r1172.rs4i) #9
  %statepoint_token306 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1172, double %r1171, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5502, ptr addrspace(1) %.6, ptr addrspace(1) %.6494, ptr addrspace(1) %.4513) ]
  %r1173307 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token306)
  %rs4gc.s11.relocated308 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token306, i32 0, i32 0) ; (%.5502, %.5502)
  %rs4gc.s8.relocated309 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token306, i32 1, i32 1) ; (%.6, %.6)
  %rs4gc.s9.relocated310 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token306, i32 2, i32 2) ; (%.6494, %.6494)
  %rs4gc.s12.relocated311 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token306, i32 3, i32 3) ; (%.4513, %.4513)
  %rs4gc.s17 = inttoptr i64 %r1173307 to ptr addrspace(1)
  %r1174.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r1174 = call i64 asm "", "=r,0"(i64 %r1174.rs4i) #9
  %r1175 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1176 = icmp ne i32 %r1175, 0
  br i1 %r1176, label %shadow.root.barrier.208, label %shadow.root.barrier.done.209

shadow.root.barrier.208:                          ; preds = %guarded_arith.merge.207
  call void @js_write_barrier_root_nanbox(i64 %r1174) #9
  br label %shadow.root.barrier.done.209

shadow.root.barrier.done.209:                     ; preds = %shadow.root.barrier.208, %guarded_arith.merge.207
  %r1177.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12.relocated311 to i64
  %r1177.rs4o = call i64 asm "", "=r,0"(i64 %r1177.rs4i) #9
  %r1177 = bitcast i64 %r1177.rs4o to double
  %r1178 = bitcast double %r1177 to i64
  %r1179 = and i64 %r1178, 281474976710655
  %r1180 = lshr i64 %r1178, 48
  %r1181 = and i64 %r1180, 65533
  %r1182 = icmp eq i64 %r1181, 32765
  br i1 %r1182, label %pget.recv_ok.211, label %pget.recv_other.215

pget.recv_sso.210:                                ; preds = %pget.recv_other.215
  %r1320 = load double, ptr @options_worker_ts_.str.23.handle, align 8
  %r1321 = bitcast double %r1320 to i64
  %r1322 = and i64 %r1321, 281474976710655
  %statepoint_token312 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1178, i64 %r1322, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated308, ptr addrspace(1) %rs4gc.s8.relocated309, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated310) ]
  %r1323313 = call double @llvm.experimental.gc.result.f64(token %statepoint_token312)
  %rs4gc.s11.relocated314 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token312, i32 0, i32 0) ; (%rs4gc.s11.relocated308, %rs4gc.s11.relocated308)
  %rs4gc.s8.relocated315 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token312, i32 1, i32 1) ; (%rs4gc.s8.relocated309, %rs4gc.s8.relocated309)
  %rs4gc.s17.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token312, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated316 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token312, i32 3, i32 3) ; (%rs4gc.s9.relocated310, %rs4gc.s9.relocated310)
  br label %pget.recv_merge.214

pget.recv_ok.211:                                 ; preds = %shadow.root.barrier.done.209
  %r1189 = icmp ugt i64 %r1179, 1048575
  br i1 %r1189, label %pic.recv_hdr.232, label %pic.miss.cold.229

pget.recv_bad.212:                                ; preds = %pget.check_class_ref.216
  %r1312 = icmp eq i64 %r1178, 9222246136947933185
  %r1313 = icmp eq i64 %r1178, 9222246136947933186
  %r1314 = or i1 %r1312, %r1313
  br i1 %r1314, label %pget.throw_nullish.239, label %pget.recv_undef_return.240

pget.recv_class_ref.213:                          ; preds = %pget.check_class_ref.216
  %r1185 = load double, ptr @options_worker_ts_.str.23.handle, align 8
  %r1186 = bitcast double %r1185 to i64
  %r1187 = and i64 %r1186, 281474976710655
  %statepoint_token317 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532901, i64 %r1178, i64 %r1187, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated308, ptr addrspace(1) %rs4gc.s8.relocated309, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated310) ]
  %r1188318 = call double @llvm.experimental.gc.result.f64(token %statepoint_token317)
  %rs4gc.s11.relocated319 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 0, i32 0) ; (%rs4gc.s11.relocated308, %rs4gc.s11.relocated308)
  %rs4gc.s8.relocated320 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 1, i32 1) ; (%rs4gc.s8.relocated309, %rs4gc.s8.relocated309)
  %rs4gc.s17.relocated321 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated322 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 3, i32 3) ; (%rs4gc.s9.relocated310, %rs4gc.s9.relocated310)
  br label %pget.recv_merge.214

pget.recv_merge.214:                              ; preds = %pget.recv_undef_return.240, %pic.merge.231, %pget.recv_class_ref.213, %pget.recv_sso.210
  %.0521 = phi ptr addrspace(1) [ %.1522, %pic.merge.231 ], [ %rs4gc.s17.relocated, %pget.recv_sso.210 ], [ %rs4gc.s17.relocated321, %pget.recv_class_ref.213 ], [ %rs4gc.s17.relocated340, %pget.recv_undef_return.240 ]
  %.6503 = phi ptr addrspace(1) [ %.7504, %pic.merge.231 ], [ %rs4gc.s11.relocated314, %pget.recv_sso.210 ], [ %rs4gc.s11.relocated319, %pget.recv_class_ref.213 ], [ %rs4gc.s11.relocated338, %pget.recv_undef_return.240 ]
  %.7495 = phi ptr addrspace(1) [ %.8496, %pic.merge.231 ], [ %rs4gc.s9.relocated316, %pget.recv_sso.210 ], [ %rs4gc.s9.relocated322, %pget.recv_class_ref.213 ], [ %rs4gc.s9.relocated341, %pget.recv_undef_return.240 ]
  %.7 = phi ptr addrspace(1) [ %.8, %pic.merge.231 ], [ %rs4gc.s8.relocated315, %pget.recv_sso.210 ], [ %rs4gc.s8.relocated320, %pget.recv_class_ref.213 ], [ %rs4gc.s8.relocated339, %pget.recv_undef_return.240 ]
  %r1324 = phi double [ %r1311, %pic.merge.231 ], [ %r1319337, %pget.recv_undef_return.240 ], [ %r1323313, %pget.recv_sso.210 ], [ %r1188318, %pget.recv_class_ref.213 ]
  %r1325 = bitcast double %r1324 to i64
  %rs4gc.s18 = inttoptr i64 %r1325 to ptr addrspace(1)
  %r1326.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r1326 = call i64 asm "", "=r,0"(i64 %r1326.rs4i) #9
  %r1327 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1328 = icmp ne i32 %r1327, 0
  br i1 %r1328, label %shadow.root.barrier.241, label %shadow.root.barrier.done.242

pget.recv_other.215:                              ; preds = %shadow.root.barrier.done.209
  %r1183 = icmp eq i64 %r1180, 32761
  br i1 %r1183, label %pget.recv_sso.210, label %pget.check_class_ref.216

pget.check_class_ref.216:                         ; preds = %pget.recv_other.215
  %r1184 = icmp eq i64 %r1180, 32766
  br i1 %r1184, label %pget.recv_class_ref.213, label %pget.recv_bad.212

pic.hit.217:                                      ; preds = %pic.token.233
  %r1214 = getelementptr i64, ptr %r1199, i64 1
  %r1215 = load i64, ptr %r1214, align 8
  %r1216 = and i64 %r1215, 1073741824
  %r1217 = icmp ne i64 %r1216, 0
  br i1 %r1217, label %pic.hit.overflow.234, label %pic.hit.inline.235

pic.hit.live.218:                                 ; preds = %pic.hit.inline.235
  br label %pic.merge.231

pic.prefix.guard.219:                             ; preds = %pic.token.233
  %r1230 = getelementptr i64, ptr %r1199, i64 2
  %r1231 = load i64, ptr %r1230, align 8
  %r1232 = icmp ne i64 %r1231, 0
  br i1 %r1232, label %pic.prefix.meta.220, label %pic.miss.228

pic.prefix.meta.220:                              ; preds = %pic.prefix.guard.219
  %r1233 = add nuw nsw i64 %r1179, 8
  %r1234 = inttoptr i64 %r1233 to ptr
  %r1235 = load i64, ptr %r1234, align 8
  %r1236 = icmp ne i64 %r1235, 0
  br i1 %r1236, label %pic.prefix.token.221, label %pic.miss.228

pic.prefix.token.221:                             ; preds = %pic.prefix.meta.220
  %r1237 = inttoptr i64 %r1235 to ptr
  %r1238 = getelementptr i64, ptr %r1237, i64 6
  %r1239 = load i64, ptr %r1238, align 8
  %r1240 = icmp eq i64 %r1239, %r1231
  br i1 %r1240, label %pic.prefix.hit.222, label %pic.miss.228

pic.prefix.hit.222:                               ; preds = %pic.prefix.token.221
  %r1241 = getelementptr i64, ptr %r1199, i64 1
  %r1242 = load i64, ptr %r1241, align 8
  %r1243 = shl i64 %r1242, 3
  %r1244 = add nuw nsw i64 %r1179, 16
  %r1245 = add i64 %r1244, %r1243
  %r1246 = inttoptr i64 %r1245 to ptr
  %r1247 = load double, ptr %r1246, align 8
  br label %pic.merge.231

pic.desc.classify.223:                            ; preds = %pic.recv_hdr.232
  %r1203 = and i1 %r1193, %r1200
  br i1 %r1203, label %pic.desc.prefix.guard.224, label %pic.miss.cold.229

pic.desc.prefix.guard.224:                        ; preds = %pic.desc.classify.223
  %r1248 = getelementptr i64, ptr %r1199, i64 2
  %r1249 = load i64, ptr %r1248, align 8
  %r1250 = icmp ne i64 %r1249, 0
  br i1 %r1250, label %pic.desc.prefix.meta.225, label %pic.miss.cold.229

pic.desc.prefix.meta.225:                         ; preds = %pic.desc.prefix.guard.224
  %r1251 = add nuw nsw i64 %r1179, 8
  %r1252 = inttoptr i64 %r1251 to ptr
  %r1253 = load i64, ptr %r1252, align 8
  %r1254 = icmp ne i64 %r1253, 0
  br i1 %r1254, label %pic.desc.prefix.token.226, label %pic.miss.cold.229

pic.desc.prefix.token.226:                        ; preds = %pic.desc.prefix.meta.225
  %r1255 = inttoptr i64 %r1253 to ptr
  %r1256 = getelementptr i64, ptr %r1255, i64 6
  %r1257 = load i64, ptr %r1256, align 8
  %r1258 = icmp eq i64 %r1257, %r1249
  br i1 %r1258, label %pic.desc.prefix.hit.227, label %pic.miss.cold.229

pic.desc.prefix.hit.227:                          ; preds = %pic.desc.prefix.token.226
  %r1259 = getelementptr i64, ptr %r1199, i64 1
  %r1260 = load i64, ptr %r1259, align 8
  %r1261 = shl i64 %r1260, 3
  %r1262 = add nuw nsw i64 %r1179, 16
  %r1263 = add i64 %r1262, %r1261
  %r1264 = inttoptr i64 %r1263 to ptr
  %r1265 = load double, ptr %r1264, align 8
  br label %pic.merge.231

pic.miss.228:                                     ; preds = %pic.hit.inline.235, %pic.prefix.token.221, %pic.prefix.meta.220, %pic.prefix.guard.219
  %r1266 = getelementptr i64, ptr %r1199, i64 3
  %r1267 = load i64, ptr %r1266, align 8
  %r1268 = icmp sgt i64 %r1267, 0
  br i1 %r1268, label %pic.ways.236, label %pic.miss.call.230

pic.miss.cold.229:                                ; preds = %pic.desc.prefix.token.226, %pic.desc.prefix.meta.225, %pic.desc.prefix.guard.224, %pic.desc.classify.223, %pget.recv_ok.211
  br label %pic.miss.call.230

pic.miss.call.230:                                ; preds = %pic.way.load.237, %pic.ways.236, %pic.miss.cold.229, %pic.miss.228
  %r1307 = load double, ptr @options_worker_ts_.str.23.handle, align 8
  %r1308 = bitcast double %r1307 to i64
  %r1309 = and i64 %r1308, 281474976710655
  %statepoint_token323 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1179, i64 %r1309, ptr @perry_ic_options_worker_ts__38, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated308, ptr addrspace(1) %rs4gc.s8.relocated309, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated310) ]
  %r1310324 = call double @llvm.experimental.gc.result.f64(token %statepoint_token323)
  %rs4gc.s11.relocated325 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token323, i32 0, i32 0) ; (%rs4gc.s11.relocated308, %rs4gc.s11.relocated308)
  %rs4gc.s8.relocated326 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token323, i32 1, i32 1) ; (%rs4gc.s8.relocated309, %rs4gc.s8.relocated309)
  %rs4gc.s17.relocated327 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token323, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated328 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token323, i32 3, i32 3) ; (%rs4gc.s9.relocated310, %rs4gc.s9.relocated310)
  br label %pic.merge.231

pic.merge.231:                                    ; preds = %pic.way.live.238, %pic.hit.overflow.234, %pic.miss.call.230, %pic.desc.prefix.hit.227, %pic.prefix.hit.222, %pic.hit.live.218
  %.1522 = phi ptr addrspace(1) [ %rs4gc.s17.relocated333, %pic.hit.overflow.234 ], [ %rs4gc.s17.relocated327, %pic.miss.call.230 ], [ %rs4gc.s17, %pic.way.live.238 ], [ %rs4gc.s17, %pic.hit.live.218 ], [ %rs4gc.s17, %pic.prefix.hit.222 ], [ %rs4gc.s17, %pic.desc.prefix.hit.227 ]
  %.7504 = phi ptr addrspace(1) [ %rs4gc.s11.relocated331, %pic.hit.overflow.234 ], [ %rs4gc.s11.relocated325, %pic.miss.call.230 ], [ %rs4gc.s11.relocated308, %pic.way.live.238 ], [ %rs4gc.s11.relocated308, %pic.hit.live.218 ], [ %rs4gc.s11.relocated308, %pic.prefix.hit.222 ], [ %rs4gc.s11.relocated308, %pic.desc.prefix.hit.227 ]
  %.8496 = phi ptr addrspace(1) [ %rs4gc.s9.relocated334, %pic.hit.overflow.234 ], [ %rs4gc.s9.relocated328, %pic.miss.call.230 ], [ %rs4gc.s9.relocated310, %pic.way.live.238 ], [ %rs4gc.s9.relocated310, %pic.hit.live.218 ], [ %rs4gc.s9.relocated310, %pic.prefix.hit.222 ], [ %rs4gc.s9.relocated310, %pic.desc.prefix.hit.227 ]
  %.8 = phi ptr addrspace(1) [ %rs4gc.s8.relocated332, %pic.hit.overflow.234 ], [ %rs4gc.s8.relocated326, %pic.miss.call.230 ], [ %rs4gc.s8.relocated309, %pic.way.live.238 ], [ %rs4gc.s8.relocated309, %pic.hit.live.218 ], [ %rs4gc.s8.relocated309, %pic.prefix.hit.222 ], [ %rs4gc.s8.relocated309, %pic.desc.prefix.hit.227 ]
  %r1311 = phi double [ %r1227, %pic.hit.live.218 ], [ %r1222330, %pic.hit.overflow.234 ], [ %r1247, %pic.prefix.hit.222 ], [ %r1265, %pic.desc.prefix.hit.227 ], [ %r1304, %pic.way.live.238 ], [ %r1310324, %pic.miss.call.230 ]
  br label %pget.recv_merge.214

pic.recv_hdr.232:                                 ; preds = %pget.recv_ok.211
  %r1190 = sub nuw nsw i64 %r1179, 8
  %r1191 = inttoptr i64 %r1190 to ptr
  %r1192 = load i8, ptr %r1191, align 1
  %r1193 = icmp eq i8 %r1192, 2
  %r1194 = sub nuw nsw i64 %r1179, 6
  %r1195 = inttoptr i64 %r1194 to ptr
  %r1196 = load i16, ptr %r1195, align 2
  %r1197 = and i16 %r1196, 2048
  %r1198 = icmp eq i16 %r1197, 0
  %r1199 = load ptr, ptr @perry_ic_options_worker_ts__38, align 8
  %r1200 = icmp ne ptr %r1199, null
  %r1201 = and i1 %r1193, %r1198
  %r1202 = and i1 %r1201, %r1200
  br i1 %r1202, label %pic.token.233, label %pic.desc.classify.223

pic.token.233:                                    ; preds = %pic.recv_hdr.232
  %r1204 = add nuw nsw i64 %r1179, 4
  %r1205 = inttoptr i64 %r1204 to ptr
  %r1206 = load i32, ptr %r1205, align 4
  %r1207 = zext i32 %r1206 to i64
  %r1208 = or i64 %r1207, 4611686018427387904
  %r1209 = icmp ne i32 %r1206, 0
  %r1210 = getelementptr i64, ptr %r1199, i64 0
  %r1211 = load i64, ptr %r1210, align 8
  %r1212 = icmp eq i64 %r1208, %r1211
  %r1213 = and i1 %r1212, %r1209
  br i1 %r1213, label %pic.hit.217, label %pic.prefix.guard.219

pic.hit.overflow.234:                             ; preds = %pic.hit.217
  %r1218 = load double, ptr @options_worker_ts_.str.23.handle, align 8
  %r1219 = bitcast double %r1218 to i64
  %r1220 = and i64 %r1219, 281474976710655
  %r1221 = trunc i64 %r1215 to i32
  %statepoint_token329 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1179, i64 %r1220, i32 %r1221, ptr @perry_ic_options_worker_ts__38, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated308, ptr addrspace(1) %rs4gc.s8.relocated309, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated310) ]
  %r1222330 = call double @llvm.experimental.gc.result.f64(token %statepoint_token329)
  %rs4gc.s11.relocated331 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 0, i32 0) ; (%rs4gc.s11.relocated308, %rs4gc.s11.relocated308)
  %rs4gc.s8.relocated332 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 1, i32 1) ; (%rs4gc.s8.relocated309, %rs4gc.s8.relocated309)
  %rs4gc.s17.relocated333 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated334 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 3, i32 3) ; (%rs4gc.s9.relocated310, %rs4gc.s9.relocated310)
  br label %pic.merge.231

pic.hit.inline.235:                               ; preds = %pic.hit.217
  %r1223 = shl i64 %r1215, 3
  %r1224 = add nuw nsw i64 %r1179, 16
  %r1225 = add i64 %r1224, %r1223
  %r1226 = inttoptr i64 %r1225 to ptr
  %r1227 = load double, ptr %r1226, align 8
  %r1228 = bitcast double %r1227 to i64
  %r1229 = icmp eq i64 %r1228, 9222246136947933200
  br i1 %r1229, label %pic.miss.228, label %pic.hit.live.218

pic.ways.236:                                     ; preds = %pic.miss.228
  %r1269 = getelementptr i64, ptr %r1199, i64 4
  %r1270 = load i64, ptr %r1269, align 8
  %r1271 = icmp eq i64 %r1270, %r1208
  %r1272 = getelementptr i64, ptr %r1199, i64 5
  %r1273 = load i64, ptr %r1272, align 8
  %r1274 = select i1 %r1271, i64 %r1273, i64 0
  %r1275 = getelementptr i64, ptr %r1199, i64 6
  %r1276 = load i64, ptr %r1275, align 8
  %r1277 = icmp eq i64 %r1276, %r1208
  %r1278 = getelementptr i64, ptr %r1199, i64 7
  %r1279 = load i64, ptr %r1278, align 8
  %r1280 = select i1 %r1277, i64 %r1279, i64 0
  %r1281 = getelementptr i64, ptr %r1199, i64 8
  %r1282 = load i64, ptr %r1281, align 8
  %r1283 = icmp eq i64 %r1282, %r1208
  %r1284 = getelementptr i64, ptr %r1199, i64 9
  %r1285 = load i64, ptr %r1284, align 8
  %r1286 = select i1 %r1283, i64 %r1285, i64 0
  %r1287 = getelementptr i64, ptr %r1199, i64 10
  %r1288 = load i64, ptr %r1287, align 8
  %r1289 = icmp eq i64 %r1288, %r1208
  %r1290 = getelementptr i64, ptr %r1199, i64 11
  %r1291 = load i64, ptr %r1290, align 8
  %r1292 = select i1 %r1289, i64 %r1291, i64 0
  %r1293 = or i1 %r1271, %r1277
  %r1294 = select i1 %r1271, i64 %r1274, i64 %r1280
  %r1295 = or i1 %r1283, %r1289
  %r1296 = select i1 %r1283, i64 %r1286, i64 %r1292
  %r1297 = or i1 %r1293, %r1295
  %r1298 = select i1 %r1293, i64 %r1294, i64 %r1296
  %r1299 = and i1 %r1209, %r1297
  br i1 %r1299, label %pic.way.load.237, label %pic.miss.call.230

pic.way.load.237:                                 ; preds = %pic.ways.236
  %r1300 = shl i64 %r1298, 3
  %r1301 = add nuw nsw i64 %r1179, 16
  %r1302 = add i64 %r1301, %r1300
  %r1303 = inttoptr i64 %r1302 to ptr
  %r1304 = load double, ptr %r1303, align 8
  %r1305 = bitcast double %r1304 to i64
  %r1306 = icmp eq i64 %r1305, 9222246136947933200
  br i1 %r1306, label %pic.miss.call.230, label %pic.way.live.238

pic.way.live.238:                                 ; preds = %pic.way.load.237
  br label %pic.merge.231

pget.throw_nullish.239:                           ; preds = %pget.recv_bad.212
  %r1315 = zext i1 %r1313 to i32
  %statepoint_token335 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1315, ptr @options_worker_ts_.str.23.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.240:                       ; preds = %pget.recv_bad.212
  %r1316 = load double, ptr @options_worker_ts_.str.23.handle, align 8
  %r1317 = bitcast double %r1316 to i64
  %r1318 = and i64 %r1317, 281474976710655
  %statepoint_token336 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1178, i64 %r1318, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated308, ptr addrspace(1) %rs4gc.s8.relocated309, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated310) ]
  %r1319337 = call double @llvm.experimental.gc.result.f64(token %statepoint_token336)
  %rs4gc.s11.relocated338 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 0, i32 0) ; (%rs4gc.s11.relocated308, %rs4gc.s11.relocated308)
  %rs4gc.s8.relocated339 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 1, i32 1) ; (%rs4gc.s8.relocated309, %rs4gc.s8.relocated309)
  %rs4gc.s17.relocated340 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated341 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token336, i32 3, i32 3) ; (%rs4gc.s9.relocated310, %rs4gc.s9.relocated310)
  br label %pget.recv_merge.214

shadow.root.barrier.241:                          ; preds = %pget.recv_merge.214
  call void @js_write_barrier_root_nanbox(i64 %r1326) #9
  br label %shadow.root.barrier.done.242

shadow.root.barrier.done.242:                     ; preds = %shadow.root.barrier.241, %pget.recv_merge.214
  %r1329.rs4i = ptrtoint ptr addrspace(1) %.7495 to i64
  %r1329.rs4o = call i64 asm "", "=r,0"(i64 %r1329.rs4i) #9
  %r1329 = bitcast i64 %r1329.rs4o to double
  %r1330 = bitcast double %r1329 to i64
  %r1331 = and i64 %r1330, 281474976710655
  %r1332 = lshr i64 %r1330, 48
  %r1333 = and i64 %r1332, 65533
  %r1334 = icmp eq i64 %r1333, 32765
  br i1 %r1334, label %pget.recv_ok.244, label %pget.recv_other.248

pget.recv_sso.243:                                ; preds = %pget.recv_other.248
  %r1472 = load double, ptr @options_worker_ts_.str.23.handle, align 8
  %r1473 = bitcast double %r1472 to i64
  %r1474 = and i64 %r1473, 281474976710655
  %statepoint_token342 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1330, i64 %r1474, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6503, ptr addrspace(1) %.7, ptr addrspace(1) %.0521, ptr addrspace(1) %rs4gc.s18) ]
  %r1475343 = call double @llvm.experimental.gc.result.f64(token %statepoint_token342)
  %rs4gc.s11.relocated344 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 0, i32 0) ; (%.6503, %.6503)
  %rs4gc.s8.relocated345 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated346 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 2, i32 2) ; (%.0521, %.0521)
  %rs4gc.s18.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token342, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pget.recv_merge.247

pget.recv_ok.244:                                 ; preds = %shadow.root.barrier.done.242
  %r1341 = icmp ugt i64 %r1331, 1048575
  br i1 %r1341, label %pic.recv_hdr.265, label %pic.miss.cold.262

pget.recv_bad.245:                                ; preds = %pget.check_class_ref.249
  %r1464 = icmp eq i64 %r1330, 9222246136947933185
  %r1465 = icmp eq i64 %r1330, 9222246136947933186
  %r1466 = or i1 %r1464, %r1465
  br i1 %r1466, label %pget.throw_nullish.272, label %pget.recv_undef_return.273

pget.recv_class_ref.246:                          ; preds = %pget.check_class_ref.249
  %r1337 = load double, ptr @options_worker_ts_.str.23.handle, align 8
  %r1338 = bitcast double %r1337 to i64
  %r1339 = and i64 %r1338, 281474976710655
  %statepoint_token347 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532903, i64 %r1330, i64 %r1339, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6503, ptr addrspace(1) %.7, ptr addrspace(1) %.0521, ptr addrspace(1) %rs4gc.s18) ]
  %r1340348 = call double @llvm.experimental.gc.result.f64(token %statepoint_token347)
  %rs4gc.s11.relocated349 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token347, i32 0, i32 0) ; (%.6503, %.6503)
  %rs4gc.s8.relocated350 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token347, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated351 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token347, i32 2, i32 2) ; (%.0521, %.0521)
  %rs4gc.s18.relocated352 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token347, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pget.recv_merge.247

pget.recv_merge.247:                              ; preds = %pget.recv_undef_return.273, %pic.merge.264, %pget.recv_class_ref.246, %pget.recv_sso.243
  %.0526 = phi ptr addrspace(1) [ %.1527, %pic.merge.264 ], [ %rs4gc.s18.relocated, %pget.recv_sso.243 ], [ %rs4gc.s18.relocated352, %pget.recv_class_ref.246 ], [ %rs4gc.s18.relocated371, %pget.recv_undef_return.273 ]
  %.2523 = phi ptr addrspace(1) [ %.3524, %pic.merge.264 ], [ %rs4gc.s17.relocated346, %pget.recv_sso.243 ], [ %rs4gc.s17.relocated351, %pget.recv_class_ref.246 ], [ %rs4gc.s17.relocated370, %pget.recv_undef_return.273 ]
  %.8505 = phi ptr addrspace(1) [ %.9506, %pic.merge.264 ], [ %rs4gc.s11.relocated344, %pget.recv_sso.243 ], [ %rs4gc.s11.relocated349, %pget.recv_class_ref.246 ], [ %rs4gc.s11.relocated368, %pget.recv_undef_return.273 ]
  %.9 = phi ptr addrspace(1) [ %.10, %pic.merge.264 ], [ %rs4gc.s8.relocated345, %pget.recv_sso.243 ], [ %rs4gc.s8.relocated350, %pget.recv_class_ref.246 ], [ %rs4gc.s8.relocated369, %pget.recv_undef_return.273 ]
  %r1476 = phi double [ %r1463, %pic.merge.264 ], [ %r1471367, %pget.recv_undef_return.273 ], [ %r1475343, %pget.recv_sso.243 ], [ %r1340348, %pget.recv_class_ref.246 ]
  %r1477.rs4i = ptrtoint ptr addrspace(1) %.0526 to i64
  %r1477 = call i64 asm "", "=r,0"(i64 %r1477.rs4i) #9
  %r1478 = bitcast i64 %r1477 to double
  %r1479 = and i64 %r1477, -281474976710656
  %r1480 = icmp ult i64 %r1479, 9221401712017801216
  %r1481 = icmp ugt i64 %r1479, 9223090561878065152
  %r1482 = or i1 %r1480, %r1481
  %r1483 = bitcast double %r1476 to i64
  %r1484 = and i64 %r1483, -281474976710656
  %r1485 = icmp ult i64 %r1484, 9221401712017801216
  %r1486 = icmp ugt i64 %r1484, 9223090561878065152
  %r1487 = or i1 %r1485, %r1486
  %r1488 = and i1 %r1482, %r1487
  br i1 %r1488, label %guarded_arith.numeric.274, label %guarded_arith.dynamic.275

pget.recv_other.248:                              ; preds = %shadow.root.barrier.done.242
  %r1335 = icmp eq i64 %r1332, 32761
  br i1 %r1335, label %pget.recv_sso.243, label %pget.check_class_ref.249

pget.check_class_ref.249:                         ; preds = %pget.recv_other.248
  %r1336 = icmp eq i64 %r1332, 32766
  br i1 %r1336, label %pget.recv_class_ref.246, label %pget.recv_bad.245

pic.hit.250:                                      ; preds = %pic.token.266
  %r1366 = getelementptr i64, ptr %r1351, i64 1
  %r1367 = load i64, ptr %r1366, align 8
  %r1368 = and i64 %r1367, 1073741824
  %r1369 = icmp ne i64 %r1368, 0
  br i1 %r1369, label %pic.hit.overflow.267, label %pic.hit.inline.268

pic.hit.live.251:                                 ; preds = %pic.hit.inline.268
  br label %pic.merge.264

pic.prefix.guard.252:                             ; preds = %pic.token.266
  %r1382 = getelementptr i64, ptr %r1351, i64 2
  %r1383 = load i64, ptr %r1382, align 8
  %r1384 = icmp ne i64 %r1383, 0
  br i1 %r1384, label %pic.prefix.meta.253, label %pic.miss.261

pic.prefix.meta.253:                              ; preds = %pic.prefix.guard.252
  %r1385 = add nuw nsw i64 %r1331, 8
  %r1386 = inttoptr i64 %r1385 to ptr
  %r1387 = load i64, ptr %r1386, align 8
  %r1388 = icmp ne i64 %r1387, 0
  br i1 %r1388, label %pic.prefix.token.254, label %pic.miss.261

pic.prefix.token.254:                             ; preds = %pic.prefix.meta.253
  %r1389 = inttoptr i64 %r1387 to ptr
  %r1390 = getelementptr i64, ptr %r1389, i64 6
  %r1391 = load i64, ptr %r1390, align 8
  %r1392 = icmp eq i64 %r1391, %r1383
  br i1 %r1392, label %pic.prefix.hit.255, label %pic.miss.261

pic.prefix.hit.255:                               ; preds = %pic.prefix.token.254
  %r1393 = getelementptr i64, ptr %r1351, i64 1
  %r1394 = load i64, ptr %r1393, align 8
  %r1395 = shl i64 %r1394, 3
  %r1396 = add nuw nsw i64 %r1331, 16
  %r1397 = add i64 %r1396, %r1395
  %r1398 = inttoptr i64 %r1397 to ptr
  %r1399 = load double, ptr %r1398, align 8
  br label %pic.merge.264

pic.desc.classify.256:                            ; preds = %pic.recv_hdr.265
  %r1355 = and i1 %r1345, %r1352
  br i1 %r1355, label %pic.desc.prefix.guard.257, label %pic.miss.cold.262

pic.desc.prefix.guard.257:                        ; preds = %pic.desc.classify.256
  %r1400 = getelementptr i64, ptr %r1351, i64 2
  %r1401 = load i64, ptr %r1400, align 8
  %r1402 = icmp ne i64 %r1401, 0
  br i1 %r1402, label %pic.desc.prefix.meta.258, label %pic.miss.cold.262

pic.desc.prefix.meta.258:                         ; preds = %pic.desc.prefix.guard.257
  %r1403 = add nuw nsw i64 %r1331, 8
  %r1404 = inttoptr i64 %r1403 to ptr
  %r1405 = load i64, ptr %r1404, align 8
  %r1406 = icmp ne i64 %r1405, 0
  br i1 %r1406, label %pic.desc.prefix.token.259, label %pic.miss.cold.262

pic.desc.prefix.token.259:                        ; preds = %pic.desc.prefix.meta.258
  %r1407 = inttoptr i64 %r1405 to ptr
  %r1408 = getelementptr i64, ptr %r1407, i64 6
  %r1409 = load i64, ptr %r1408, align 8
  %r1410 = icmp eq i64 %r1409, %r1401
  br i1 %r1410, label %pic.desc.prefix.hit.260, label %pic.miss.cold.262

pic.desc.prefix.hit.260:                          ; preds = %pic.desc.prefix.token.259
  %r1411 = getelementptr i64, ptr %r1351, i64 1
  %r1412 = load i64, ptr %r1411, align 8
  %r1413 = shl i64 %r1412, 3
  %r1414 = add nuw nsw i64 %r1331, 16
  %r1415 = add i64 %r1414, %r1413
  %r1416 = inttoptr i64 %r1415 to ptr
  %r1417 = load double, ptr %r1416, align 8
  br label %pic.merge.264

pic.miss.261:                                     ; preds = %pic.hit.inline.268, %pic.prefix.token.254, %pic.prefix.meta.253, %pic.prefix.guard.252
  %r1418 = getelementptr i64, ptr %r1351, i64 3
  %r1419 = load i64, ptr %r1418, align 8
  %r1420 = icmp sgt i64 %r1419, 0
  br i1 %r1420, label %pic.ways.269, label %pic.miss.call.263

pic.miss.cold.262:                                ; preds = %pic.desc.prefix.token.259, %pic.desc.prefix.meta.258, %pic.desc.prefix.guard.257, %pic.desc.classify.256, %pget.recv_ok.244
  br label %pic.miss.call.263

pic.miss.call.263:                                ; preds = %pic.way.load.270, %pic.ways.269, %pic.miss.cold.262, %pic.miss.261
  %r1459 = load double, ptr @options_worker_ts_.str.23.handle, align 8
  %r1460 = bitcast double %r1459 to i64
  %r1461 = and i64 %r1460, 281474976710655
  %statepoint_token353 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1331, i64 %r1461, ptr @perry_ic_options_worker_ts__40, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6503, ptr addrspace(1) %.7, ptr addrspace(1) %.0521, ptr addrspace(1) %rs4gc.s18) ]
  %r1462354 = call double @llvm.experimental.gc.result.f64(token %statepoint_token353)
  %rs4gc.s11.relocated355 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token353, i32 0, i32 0) ; (%.6503, %.6503)
  %rs4gc.s8.relocated356 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token353, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated357 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token353, i32 2, i32 2) ; (%.0521, %.0521)
  %rs4gc.s18.relocated358 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token353, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pic.merge.264

pic.merge.264:                                    ; preds = %pic.way.live.271, %pic.hit.overflow.267, %pic.miss.call.263, %pic.desc.prefix.hit.260, %pic.prefix.hit.255, %pic.hit.live.251
  %.1527 = phi ptr addrspace(1) [ %rs4gc.s18.relocated364, %pic.hit.overflow.267 ], [ %rs4gc.s18.relocated358, %pic.miss.call.263 ], [ %rs4gc.s18, %pic.way.live.271 ], [ %rs4gc.s18, %pic.hit.live.251 ], [ %rs4gc.s18, %pic.prefix.hit.255 ], [ %rs4gc.s18, %pic.desc.prefix.hit.260 ]
  %.3524 = phi ptr addrspace(1) [ %rs4gc.s17.relocated363, %pic.hit.overflow.267 ], [ %rs4gc.s17.relocated357, %pic.miss.call.263 ], [ %.0521, %pic.way.live.271 ], [ %.0521, %pic.hit.live.251 ], [ %.0521, %pic.prefix.hit.255 ], [ %.0521, %pic.desc.prefix.hit.260 ]
  %.9506 = phi ptr addrspace(1) [ %rs4gc.s11.relocated361, %pic.hit.overflow.267 ], [ %rs4gc.s11.relocated355, %pic.miss.call.263 ], [ %.6503, %pic.way.live.271 ], [ %.6503, %pic.hit.live.251 ], [ %.6503, %pic.prefix.hit.255 ], [ %.6503, %pic.desc.prefix.hit.260 ]
  %.10 = phi ptr addrspace(1) [ %rs4gc.s8.relocated362, %pic.hit.overflow.267 ], [ %rs4gc.s8.relocated356, %pic.miss.call.263 ], [ %.7, %pic.way.live.271 ], [ %.7, %pic.hit.live.251 ], [ %.7, %pic.prefix.hit.255 ], [ %.7, %pic.desc.prefix.hit.260 ]
  %r1463 = phi double [ %r1379, %pic.hit.live.251 ], [ %r1374360, %pic.hit.overflow.267 ], [ %r1399, %pic.prefix.hit.255 ], [ %r1417, %pic.desc.prefix.hit.260 ], [ %r1456, %pic.way.live.271 ], [ %r1462354, %pic.miss.call.263 ]
  br label %pget.recv_merge.247

pic.recv_hdr.265:                                 ; preds = %pget.recv_ok.244
  %r1342 = sub nuw nsw i64 %r1331, 8
  %r1343 = inttoptr i64 %r1342 to ptr
  %r1344 = load i8, ptr %r1343, align 1
  %r1345 = icmp eq i8 %r1344, 2
  %r1346 = sub nuw nsw i64 %r1331, 6
  %r1347 = inttoptr i64 %r1346 to ptr
  %r1348 = load i16, ptr %r1347, align 2
  %r1349 = and i16 %r1348, 2048
  %r1350 = icmp eq i16 %r1349, 0
  %r1351 = load ptr, ptr @perry_ic_options_worker_ts__40, align 8
  %r1352 = icmp ne ptr %r1351, null
  %r1353 = and i1 %r1345, %r1350
  %r1354 = and i1 %r1353, %r1352
  br i1 %r1354, label %pic.token.266, label %pic.desc.classify.256

pic.token.266:                                    ; preds = %pic.recv_hdr.265
  %r1356 = add nuw nsw i64 %r1331, 4
  %r1357 = inttoptr i64 %r1356 to ptr
  %r1358 = load i32, ptr %r1357, align 4
  %r1359 = zext i32 %r1358 to i64
  %r1360 = or i64 %r1359, 4611686018427387904
  %r1361 = icmp ne i32 %r1358, 0
  %r1362 = getelementptr i64, ptr %r1351, i64 0
  %r1363 = load i64, ptr %r1362, align 8
  %r1364 = icmp eq i64 %r1360, %r1363
  %r1365 = and i1 %r1364, %r1361
  br i1 %r1365, label %pic.hit.250, label %pic.prefix.guard.252

pic.hit.overflow.267:                             ; preds = %pic.hit.250
  %r1370 = load double, ptr @options_worker_ts_.str.23.handle, align 8
  %r1371 = bitcast double %r1370 to i64
  %r1372 = and i64 %r1371, 281474976710655
  %r1373 = trunc i64 %r1367 to i32
  %statepoint_token359 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1331, i64 %r1372, i32 %r1373, ptr @perry_ic_options_worker_ts__40, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6503, ptr addrspace(1) %.7, ptr addrspace(1) %.0521, ptr addrspace(1) %rs4gc.s18) ]
  %r1374360 = call double @llvm.experimental.gc.result.f64(token %statepoint_token359)
  %rs4gc.s11.relocated361 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token359, i32 0, i32 0) ; (%.6503, %.6503)
  %rs4gc.s8.relocated362 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token359, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated363 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token359, i32 2, i32 2) ; (%.0521, %.0521)
  %rs4gc.s18.relocated364 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token359, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pic.merge.264

pic.hit.inline.268:                               ; preds = %pic.hit.250
  %r1375 = shl i64 %r1367, 3
  %r1376 = add nuw nsw i64 %r1331, 16
  %r1377 = add i64 %r1376, %r1375
  %r1378 = inttoptr i64 %r1377 to ptr
  %r1379 = load double, ptr %r1378, align 8
  %r1380 = bitcast double %r1379 to i64
  %r1381 = icmp eq i64 %r1380, 9222246136947933200
  br i1 %r1381, label %pic.miss.261, label %pic.hit.live.251

pic.ways.269:                                     ; preds = %pic.miss.261
  %r1421 = getelementptr i64, ptr %r1351, i64 4
  %r1422 = load i64, ptr %r1421, align 8
  %r1423 = icmp eq i64 %r1422, %r1360
  %r1424 = getelementptr i64, ptr %r1351, i64 5
  %r1425 = load i64, ptr %r1424, align 8
  %r1426 = select i1 %r1423, i64 %r1425, i64 0
  %r1427 = getelementptr i64, ptr %r1351, i64 6
  %r1428 = load i64, ptr %r1427, align 8
  %r1429 = icmp eq i64 %r1428, %r1360
  %r1430 = getelementptr i64, ptr %r1351, i64 7
  %r1431 = load i64, ptr %r1430, align 8
  %r1432 = select i1 %r1429, i64 %r1431, i64 0
  %r1433 = getelementptr i64, ptr %r1351, i64 8
  %r1434 = load i64, ptr %r1433, align 8
  %r1435 = icmp eq i64 %r1434, %r1360
  %r1436 = getelementptr i64, ptr %r1351, i64 9
  %r1437 = load i64, ptr %r1436, align 8
  %r1438 = select i1 %r1435, i64 %r1437, i64 0
  %r1439 = getelementptr i64, ptr %r1351, i64 10
  %r1440 = load i64, ptr %r1439, align 8
  %r1441 = icmp eq i64 %r1440, %r1360
  %r1442 = getelementptr i64, ptr %r1351, i64 11
  %r1443 = load i64, ptr %r1442, align 8
  %r1444 = select i1 %r1441, i64 %r1443, i64 0
  %r1445 = or i1 %r1423, %r1429
  %r1446 = select i1 %r1423, i64 %r1426, i64 %r1432
  %r1447 = or i1 %r1435, %r1441
  %r1448 = select i1 %r1435, i64 %r1438, i64 %r1444
  %r1449 = or i1 %r1445, %r1447
  %r1450 = select i1 %r1445, i64 %r1446, i64 %r1448
  %r1451 = and i1 %r1361, %r1449
  br i1 %r1451, label %pic.way.load.270, label %pic.miss.call.263

pic.way.load.270:                                 ; preds = %pic.ways.269
  %r1452 = shl i64 %r1450, 3
  %r1453 = add nuw nsw i64 %r1331, 16
  %r1454 = add i64 %r1453, %r1452
  %r1455 = inttoptr i64 %r1454 to ptr
  %r1456 = load double, ptr %r1455, align 8
  %r1457 = bitcast double %r1456 to i64
  %r1458 = icmp eq i64 %r1457, 9222246136947933200
  br i1 %r1458, label %pic.miss.call.263, label %pic.way.live.271

pic.way.live.271:                                 ; preds = %pic.way.load.270
  br label %pic.merge.264

pget.throw_nullish.272:                           ; preds = %pget.recv_bad.245
  %r1467 = zext i1 %r1465 to i32
  %statepoint_token365 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1467, ptr @options_worker_ts_.str.23.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.273:                       ; preds = %pget.recv_bad.245
  %r1468 = load double, ptr @options_worker_ts_.str.23.handle, align 8
  %r1469 = bitcast double %r1468 to i64
  %r1470 = and i64 %r1469, 281474976710655
  %statepoint_token366 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1330, i64 %r1470, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6503, ptr addrspace(1) %.7, ptr addrspace(1) %.0521, ptr addrspace(1) %rs4gc.s18) ]
  %r1471367 = call double @llvm.experimental.gc.result.f64(token %statepoint_token366)
  %rs4gc.s11.relocated368 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token366, i32 0, i32 0) ; (%.6503, %.6503)
  %rs4gc.s8.relocated369 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token366, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated370 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token366, i32 2, i32 2) ; (%.0521, %.0521)
  %rs4gc.s18.relocated371 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token366, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pget.recv_merge.247

guarded_arith.numeric.274:                        ; preds = %pget.recv_merge.247
  %r1489 = fsub double %r1478, %r1476
  br label %guarded_arith.merge.276

guarded_arith.dynamic.275:                        ; preds = %pget.recv_merge.247
  %statepoint_token372 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_sub, i32 2, i32 0, double %r1478, double %r1476, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8505, ptr addrspace(1) %.9, ptr addrspace(1) %.2523) ]
  %r1490373 = call double @llvm.experimental.gc.result.f64(token %statepoint_token372)
  %rs4gc.s11.relocated374 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 0, i32 0) ; (%.8505, %.8505)
  %rs4gc.s8.relocated375 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 1, i32 1) ; (%.9, %.9)
  %rs4gc.s17.relocated376 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token372, i32 2, i32 2) ; (%.2523, %.2523)
  br label %guarded_arith.merge.276

guarded_arith.merge.276:                          ; preds = %guarded_arith.dynamic.275, %guarded_arith.numeric.274
  %.4525 = phi ptr addrspace(1) [ %.2523, %guarded_arith.numeric.274 ], [ %rs4gc.s17.relocated376, %guarded_arith.dynamic.275 ]
  %.10507 = phi ptr addrspace(1) [ %.8505, %guarded_arith.numeric.274 ], [ %rs4gc.s11.relocated374, %guarded_arith.dynamic.275 ]
  %.11 = phi ptr addrspace(1) [ %.9, %guarded_arith.numeric.274 ], [ %rs4gc.s8.relocated375, %guarded_arith.dynamic.275 ]
  %r1491 = phi double [ %r1489, %guarded_arith.numeric.274 ], [ %r1490373, %guarded_arith.dynamic.275 ]
  %r1492.rs4i = ptrtoint ptr addrspace(1) %.4525 to i64
  %r1492 = call i64 asm "", "=r,0"(i64 %r1492.rs4i) #9
  %statepoint_token377 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1492, double %r1491, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10507, ptr addrspace(1) %.11) ]
  %r1493378 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token377)
  %rs4gc.s11.relocated379 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 0, i32 0) ; (%.10507, %.10507)
  %rs4gc.s8.relocated380 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 1, i32 1) ; (%.11, %.11)
  %rs4gc.s19 = inttoptr i64 %r1493378 to ptr addrspace(1)
  %r1494.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r1494 = call i64 asm "", "=r,0"(i64 %r1494.rs4i) #9
  %r1495 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1496 = icmp ne i32 %r1495, 0
  br i1 %r1496, label %shadow.root.barrier.277, label %shadow.root.barrier.done.278

shadow.root.barrier.277:                          ; preds = %guarded_arith.merge.276
  call void @js_write_barrier_root_nanbox(i64 %r1494) #9
  br label %shadow.root.barrier.done.278

shadow.root.barrier.done.278:                     ; preds = %shadow.root.barrier.277, %guarded_arith.merge.276
  %r1497.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8.relocated380 to i64
  %r1497.rs4o = call i64 asm "", "=r,0"(i64 %r1497.rs4i) #9
  %r1497 = bitcast i64 %r1497.rs4o to double
  %r1498.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r1498 = call i64 asm "", "=r,0"(i64 %r1498.rs4i) #9
  %statepoint_token381 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1498, double %r1497, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated379) ]
  %r1499382 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token381)
  %rs4gc.s11.relocated383 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token381, i32 0, i32 0) ; (%rs4gc.s11.relocated379, %rs4gc.s11.relocated379)
  %rs4gc.s20 = inttoptr i64 %r1499382 to ptr addrspace(1)
  %r1500.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r1500 = call i64 asm "", "=r,0"(i64 %r1500.rs4i) #9
  %r1501 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1502 = icmp ne i32 %r1501, 0
  br i1 %r1502, label %shadow.root.barrier.279, label %shadow.root.barrier.done.280

shadow.root.barrier.279:                          ; preds = %shadow.root.barrier.done.278
  call void @js_write_barrier_root_nanbox(i64 %r1500) #9
  br label %shadow.root.barrier.done.280

shadow.root.barrier.done.280:                     ; preds = %shadow.root.barrier.279, %shadow.root.barrier.done.278
  %statepoint_token384 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_process_memory_usage, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated383, ptr addrspace(1) %rs4gc.s20) ]
  %r1503385 = call double @llvm.experimental.gc.result.f64(token %statepoint_token384)
  %rs4gc.s11.relocated386 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token384, i32 0, i32 0) ; (%rs4gc.s11.relocated383, %rs4gc.s11.relocated383)
  %rs4gc.s20.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token384, i32 1, i32 1) ; (%rs4gc.s20, %rs4gc.s20)
  %r1504 = bitcast double %r1503385 to i64
  %r1505 = and i64 %r1504, 281474976710655
  %r1506 = lshr i64 %r1504, 48
  %r1507 = and i64 %r1506, 65533
  %r1508 = icmp eq i64 %r1507, 32765
  br i1 %r1508, label %pget.recv_ok.282, label %pget.recv_other.286

pget.recv_sso.281:                                ; preds = %pget.recv_other.286
  %r1646 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1647 = bitcast double %r1646 to i64
  %r1648 = and i64 %r1647, 281474976710655
  %statepoint_token387 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1504, i64 %r1648, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated386, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1649388 = call double @llvm.experimental.gc.result.f64(token %statepoint_token387)
  %rs4gc.s11.relocated389 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token387, i32 0, i32 0) ; (%rs4gc.s11.relocated386, %rs4gc.s11.relocated386)
  %rs4gc.s20.relocated390 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token387, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pget.recv_merge.285

pget.recv_ok.282:                                 ; preds = %shadow.root.barrier.done.280
  %r1515 = icmp ugt i64 %r1505, 1048575
  br i1 %r1515, label %pic.recv_hdr.303, label %pic.miss.cold.300

pget.recv_bad.283:                                ; preds = %pget.check_class_ref.287
  %r1638 = icmp eq i64 %r1504, 9222246136947933185
  %r1639 = icmp eq i64 %r1504, 9222246136947933186
  %r1640 = or i1 %r1638, %r1639
  br i1 %r1640, label %pget.throw_nullish.310, label %pget.recv_undef_return.311

pget.recv_class_ref.284:                          ; preds = %pget.check_class_ref.287
  %r1511 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1512 = bitcast double %r1511 to i64
  %r1513 = and i64 %r1512, 281474976710655
  %statepoint_token391 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 7760974052394532905, i64 %r1504, i64 %r1513, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated386, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1514392 = call double @llvm.experimental.gc.result.f64(token %statepoint_token391)
  %rs4gc.s11.relocated393 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 0, i32 0) ; (%rs4gc.s11.relocated386, %rs4gc.s11.relocated386)
  %rs4gc.s20.relocated394 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token391, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pget.recv_merge.285

pget.recv_merge.285:                              ; preds = %pget.recv_undef_return.311, %pic.merge.302, %pget.recv_class_ref.284, %pget.recv_sso.281
  %.0528 = phi ptr addrspace(1) [ %.1529, %pic.merge.302 ], [ %rs4gc.s20.relocated390, %pget.recv_sso.281 ], [ %rs4gc.s20.relocated394, %pget.recv_class_ref.284 ], [ %rs4gc.s20.relocated410, %pget.recv_undef_return.311 ]
  %.11508 = phi ptr addrspace(1) [ %.12, %pic.merge.302 ], [ %rs4gc.s11.relocated389, %pget.recv_sso.281 ], [ %rs4gc.s11.relocated393, %pget.recv_class_ref.284 ], [ %rs4gc.s11.relocated409, %pget.recv_undef_return.311 ]
  %r1650 = phi double [ %r1637, %pic.merge.302 ], [ %r1645408, %pget.recv_undef_return.311 ], [ %r1649388, %pget.recv_sso.281 ], [ %r1514392, %pget.recv_class_ref.284 ]
  %r1651.rs4i = ptrtoint ptr addrspace(1) %.0528 to i64
  %r1651 = call i64 asm "", "=r,0"(i64 %r1651.rs4i) #9
  %statepoint_token395 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1651, double %r1650, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11508) ]
  %r1652396 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token395)
  %rs4gc.s11.relocated397 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token395, i32 0, i32 0) ; (%.11508, %.11508)
  %rs4gc.s21 = inttoptr i64 %r1652396 to ptr addrspace(1)
  %r1653.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r1653 = call i64 asm "", "=r,0"(i64 %r1653.rs4i) #9
  %r1654 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1655 = icmp ne i32 %r1654, 0
  br i1 %r1655, label %shadow.root.barrier.312, label %shadow.root.barrier.done.313

pget.recv_other.286:                              ; preds = %shadow.root.barrier.done.280
  %r1509 = icmp eq i64 %r1506, 32761
  br i1 %r1509, label %pget.recv_sso.281, label %pget.check_class_ref.287

pget.check_class_ref.287:                         ; preds = %pget.recv_other.286
  %r1510 = icmp eq i64 %r1506, 32766
  br i1 %r1510, label %pget.recv_class_ref.284, label %pget.recv_bad.283

pic.hit.288:                                      ; preds = %pic.token.304
  %r1540 = getelementptr i64, ptr %r1525, i64 1
  %r1541 = load i64, ptr %r1540, align 8
  %r1542 = and i64 %r1541, 1073741824
  %r1543 = icmp ne i64 %r1542, 0
  br i1 %r1543, label %pic.hit.overflow.305, label %pic.hit.inline.306

pic.hit.live.289:                                 ; preds = %pic.hit.inline.306
  br label %pic.merge.302

pic.prefix.guard.290:                             ; preds = %pic.token.304
  %r1556 = getelementptr i64, ptr %r1525, i64 2
  %r1557 = load i64, ptr %r1556, align 8
  %r1558 = icmp ne i64 %r1557, 0
  br i1 %r1558, label %pic.prefix.meta.291, label %pic.miss.299

pic.prefix.meta.291:                              ; preds = %pic.prefix.guard.290
  %r1559 = add nuw nsw i64 %r1505, 8
  %r1560 = inttoptr i64 %r1559 to ptr
  %r1561 = load i64, ptr %r1560, align 8
  %r1562 = icmp ne i64 %r1561, 0
  br i1 %r1562, label %pic.prefix.token.292, label %pic.miss.299

pic.prefix.token.292:                             ; preds = %pic.prefix.meta.291
  %r1563 = inttoptr i64 %r1561 to ptr
  %r1564 = getelementptr i64, ptr %r1563, i64 6
  %r1565 = load i64, ptr %r1564, align 8
  %r1566 = icmp eq i64 %r1565, %r1557
  br i1 %r1566, label %pic.prefix.hit.293, label %pic.miss.299

pic.prefix.hit.293:                               ; preds = %pic.prefix.token.292
  %r1567 = getelementptr i64, ptr %r1525, i64 1
  %r1568 = load i64, ptr %r1567, align 8
  %r1569 = shl i64 %r1568, 3
  %r1570 = add nuw nsw i64 %r1505, 16
  %r1571 = add i64 %r1570, %r1569
  %r1572 = inttoptr i64 %r1571 to ptr
  %r1573 = load double, ptr %r1572, align 8
  br label %pic.merge.302

pic.desc.classify.294:                            ; preds = %pic.recv_hdr.303
  %r1529 = and i1 %r1519, %r1526
  br i1 %r1529, label %pic.desc.prefix.guard.295, label %pic.miss.cold.300

pic.desc.prefix.guard.295:                        ; preds = %pic.desc.classify.294
  %r1574 = getelementptr i64, ptr %r1525, i64 2
  %r1575 = load i64, ptr %r1574, align 8
  %r1576 = icmp ne i64 %r1575, 0
  br i1 %r1576, label %pic.desc.prefix.meta.296, label %pic.miss.cold.300

pic.desc.prefix.meta.296:                         ; preds = %pic.desc.prefix.guard.295
  %r1577 = add nuw nsw i64 %r1505, 8
  %r1578 = inttoptr i64 %r1577 to ptr
  %r1579 = load i64, ptr %r1578, align 8
  %r1580 = icmp ne i64 %r1579, 0
  br i1 %r1580, label %pic.desc.prefix.token.297, label %pic.miss.cold.300

pic.desc.prefix.token.297:                        ; preds = %pic.desc.prefix.meta.296
  %r1581 = inttoptr i64 %r1579 to ptr
  %r1582 = getelementptr i64, ptr %r1581, i64 6
  %r1583 = load i64, ptr %r1582, align 8
  %r1584 = icmp eq i64 %r1583, %r1575
  br i1 %r1584, label %pic.desc.prefix.hit.298, label %pic.miss.cold.300

pic.desc.prefix.hit.298:                          ; preds = %pic.desc.prefix.token.297
  %r1585 = getelementptr i64, ptr %r1525, i64 1
  %r1586 = load i64, ptr %r1585, align 8
  %r1587 = shl i64 %r1586, 3
  %r1588 = add nuw nsw i64 %r1505, 16
  %r1589 = add i64 %r1588, %r1587
  %r1590 = inttoptr i64 %r1589 to ptr
  %r1591 = load double, ptr %r1590, align 8
  br label %pic.merge.302

pic.miss.299:                                     ; preds = %pic.hit.inline.306, %pic.prefix.token.292, %pic.prefix.meta.291, %pic.prefix.guard.290
  %r1592 = getelementptr i64, ptr %r1525, i64 3
  %r1593 = load i64, ptr %r1592, align 8
  %r1594 = icmp sgt i64 %r1593, 0
  br i1 %r1594, label %pic.ways.307, label %pic.miss.call.301

pic.miss.cold.300:                                ; preds = %pic.desc.prefix.token.297, %pic.desc.prefix.meta.296, %pic.desc.prefix.guard.295, %pic.desc.classify.294, %pget.recv_ok.282
  br label %pic.miss.call.301

pic.miss.call.301:                                ; preds = %pic.way.load.308, %pic.ways.307, %pic.miss.cold.300, %pic.miss.299
  %r1633 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1634 = bitcast double %r1633 to i64
  %r1635 = and i64 %r1634, 281474976710655
  %statepoint_token398 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1505, i64 %r1635, ptr @perry_ic_options_worker_ts__42, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated386, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1636399 = call double @llvm.experimental.gc.result.f64(token %statepoint_token398)
  %rs4gc.s11.relocated400 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 0, i32 0) ; (%rs4gc.s11.relocated386, %rs4gc.s11.relocated386)
  %rs4gc.s20.relocated401 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token398, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pic.merge.302

pic.merge.302:                                    ; preds = %pic.way.live.309, %pic.hit.overflow.305, %pic.miss.call.301, %pic.desc.prefix.hit.298, %pic.prefix.hit.293, %pic.hit.live.289
  %.1529 = phi ptr addrspace(1) [ %rs4gc.s20.relocated405, %pic.hit.overflow.305 ], [ %rs4gc.s20.relocated401, %pic.miss.call.301 ], [ %rs4gc.s20.relocated, %pic.way.live.309 ], [ %rs4gc.s20.relocated, %pic.hit.live.289 ], [ %rs4gc.s20.relocated, %pic.prefix.hit.293 ], [ %rs4gc.s20.relocated, %pic.desc.prefix.hit.298 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s11.relocated404, %pic.hit.overflow.305 ], [ %rs4gc.s11.relocated400, %pic.miss.call.301 ], [ %rs4gc.s11.relocated386, %pic.way.live.309 ], [ %rs4gc.s11.relocated386, %pic.hit.live.289 ], [ %rs4gc.s11.relocated386, %pic.prefix.hit.293 ], [ %rs4gc.s11.relocated386, %pic.desc.prefix.hit.298 ]
  %r1637 = phi double [ %r1553, %pic.hit.live.289 ], [ %r1548403, %pic.hit.overflow.305 ], [ %r1573, %pic.prefix.hit.293 ], [ %r1591, %pic.desc.prefix.hit.298 ], [ %r1630, %pic.way.live.309 ], [ %r1636399, %pic.miss.call.301 ]
  br label %pget.recv_merge.285

pic.recv_hdr.303:                                 ; preds = %pget.recv_ok.282
  %r1516 = sub nuw nsw i64 %r1505, 8
  %r1517 = inttoptr i64 %r1516 to ptr
  %r1518 = load i8, ptr %r1517, align 1
  %r1519 = icmp eq i8 %r1518, 2
  %r1520 = sub nuw nsw i64 %r1505, 6
  %r1521 = inttoptr i64 %r1520 to ptr
  %r1522 = load i16, ptr %r1521, align 2
  %r1523 = and i16 %r1522, 2048
  %r1524 = icmp eq i16 %r1523, 0
  %r1525 = load ptr, ptr @perry_ic_options_worker_ts__42, align 8
  %r1526 = icmp ne ptr %r1525, null
  %r1527 = and i1 %r1519, %r1524
  %r1528 = and i1 %r1527, %r1526
  br i1 %r1528, label %pic.token.304, label %pic.desc.classify.294

pic.token.304:                                    ; preds = %pic.recv_hdr.303
  %r1530 = add nuw nsw i64 %r1505, 4
  %r1531 = inttoptr i64 %r1530 to ptr
  %r1532 = load i32, ptr %r1531, align 4
  %r1533 = zext i32 %r1532 to i64
  %r1534 = or i64 %r1533, 4611686018427387904
  %r1535 = icmp ne i32 %r1532, 0
  %r1536 = getelementptr i64, ptr %r1525, i64 0
  %r1537 = load i64, ptr %r1536, align 8
  %r1538 = icmp eq i64 %r1534, %r1537
  %r1539 = and i1 %r1538, %r1535
  br i1 %r1539, label %pic.hit.288, label %pic.prefix.guard.290

pic.hit.overflow.305:                             ; preds = %pic.hit.288
  %r1544 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1545 = bitcast double %r1544 to i64
  %r1546 = and i64 %r1545, 281474976710655
  %r1547 = trunc i64 %r1541 to i32
  %statepoint_token402 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1505, i64 %r1546, i32 %r1547, ptr @perry_ic_options_worker_ts__42, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated386, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1548403 = call double @llvm.experimental.gc.result.f64(token %statepoint_token402)
  %rs4gc.s11.relocated404 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token402, i32 0, i32 0) ; (%rs4gc.s11.relocated386, %rs4gc.s11.relocated386)
  %rs4gc.s20.relocated405 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token402, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pic.merge.302

pic.hit.inline.306:                               ; preds = %pic.hit.288
  %r1549 = shl i64 %r1541, 3
  %r1550 = add nuw nsw i64 %r1505, 16
  %r1551 = add i64 %r1550, %r1549
  %r1552 = inttoptr i64 %r1551 to ptr
  %r1553 = load double, ptr %r1552, align 8
  %r1554 = bitcast double %r1553 to i64
  %r1555 = icmp eq i64 %r1554, 9222246136947933200
  br i1 %r1555, label %pic.miss.299, label %pic.hit.live.289

pic.ways.307:                                     ; preds = %pic.miss.299
  %r1595 = getelementptr i64, ptr %r1525, i64 4
  %r1596 = load i64, ptr %r1595, align 8
  %r1597 = icmp eq i64 %r1596, %r1534
  %r1598 = getelementptr i64, ptr %r1525, i64 5
  %r1599 = load i64, ptr %r1598, align 8
  %r1600 = select i1 %r1597, i64 %r1599, i64 0
  %r1601 = getelementptr i64, ptr %r1525, i64 6
  %r1602 = load i64, ptr %r1601, align 8
  %r1603 = icmp eq i64 %r1602, %r1534
  %r1604 = getelementptr i64, ptr %r1525, i64 7
  %r1605 = load i64, ptr %r1604, align 8
  %r1606 = select i1 %r1603, i64 %r1605, i64 0
  %r1607 = getelementptr i64, ptr %r1525, i64 8
  %r1608 = load i64, ptr %r1607, align 8
  %r1609 = icmp eq i64 %r1608, %r1534
  %r1610 = getelementptr i64, ptr %r1525, i64 9
  %r1611 = load i64, ptr %r1610, align 8
  %r1612 = select i1 %r1609, i64 %r1611, i64 0
  %r1613 = getelementptr i64, ptr %r1525, i64 10
  %r1614 = load i64, ptr %r1613, align 8
  %r1615 = icmp eq i64 %r1614, %r1534
  %r1616 = getelementptr i64, ptr %r1525, i64 11
  %r1617 = load i64, ptr %r1616, align 8
  %r1618 = select i1 %r1615, i64 %r1617, i64 0
  %r1619 = or i1 %r1597, %r1603
  %r1620 = select i1 %r1597, i64 %r1600, i64 %r1606
  %r1621 = or i1 %r1609, %r1615
  %r1622 = select i1 %r1609, i64 %r1612, i64 %r1618
  %r1623 = or i1 %r1619, %r1621
  %r1624 = select i1 %r1619, i64 %r1620, i64 %r1622
  %r1625 = and i1 %r1535, %r1623
  br i1 %r1625, label %pic.way.load.308, label %pic.miss.call.301

pic.way.load.308:                                 ; preds = %pic.ways.307
  %r1626 = shl i64 %r1624, 3
  %r1627 = add nuw nsw i64 %r1505, 16
  %r1628 = add i64 %r1627, %r1626
  %r1629 = inttoptr i64 %r1628 to ptr
  %r1630 = load double, ptr %r1629, align 8
  %r1631 = bitcast double %r1630 to i64
  %r1632 = icmp eq i64 %r1631, 9222246136947933200
  br i1 %r1632, label %pic.miss.call.301, label %pic.way.live.309

pic.way.live.309:                                 ; preds = %pic.way.load.308
  br label %pic.merge.302

pget.throw_nullish.310:                           ; preds = %pget.recv_bad.283
  %r1641 = zext i1 %r1639 to i32
  %statepoint_token406 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1641, ptr @options_worker_ts_.str.20.bytes, i64 3, i32 0, i32 0)
  unreachable

pget.recv_undef_return.311:                       ; preds = %pget.recv_bad.283
  %r1642 = load double, ptr @options_worker_ts_.str.20.handle, align 8
  %r1643 = bitcast double %r1642 to i64
  %r1644 = and i64 %r1643, 281474976710655
  %statepoint_token407 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1504, i64 %r1644, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated386, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1645408 = call double @llvm.experimental.gc.result.f64(token %statepoint_token407)
  %rs4gc.s11.relocated409 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 0, i32 0) ; (%rs4gc.s11.relocated386, %rs4gc.s11.relocated386)
  %rs4gc.s20.relocated410 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token407, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pget.recv_merge.285

shadow.root.barrier.312:                          ; preds = %pget.recv_merge.285
  call void @js_write_barrier_root_nanbox(i64 %r1653) #9
  br label %shadow.root.barrier.done.313

shadow.root.barrier.done.313:                     ; preds = %shadow.root.barrier.312, %pget.recv_merge.285
  %r1656.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11.relocated397 to i64
  %r1656.rs4o = call i64 asm "", "=r,0"(i64 %r1656.rs4i) #9
  %r1656 = bitcast i64 %r1656.rs4o to double
  %r1657.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r1657 = call i64 asm "", "=r,0"(i64 %r1657.rs4i) #9
  %statepoint_token411 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1657, double %r1656, i32 0, i32 0)
  %r1658412 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token411)
  %rs4gc.s22 = inttoptr i64 %r1658412 to ptr addrspace(1)
  %r1659.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r1659 = call i64 asm "", "=r,0"(i64 %r1659.rs4i) #9
  %r1660 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1661 = icmp ne i32 %r1660, 0
  br i1 %r1661, label %shadow.root.barrier.314, label %shadow.root.barrier.done.315

shadow.root.barrier.314:                          ; preds = %shadow.root.barrier.done.313
  call void @js_write_barrier_root_nanbox(i64 %r1659) #9
  br label %shadow.root.barrier.done.315

shadow.root.barrier.done.315:                     ; preds = %shadow.root.barrier.314, %shadow.root.barrier.done.313
  %r1662.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r1662 = call i64 asm "", "=r,0"(i64 %r1662.rs4i) #9
  %statepoint_token413 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1662, double 0.000000e+00, i32 0, i32 0)
  %r1663414 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token413)
  %rs4gc.s23 = inttoptr i64 %r1663414 to ptr addrspace(1)
  %r1664.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r1664 = call i64 asm "", "=r,0"(i64 %r1664.rs4i) #9
  %r1665 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1666 = icmp ne i32 %r1665, 0
  br i1 %r1666, label %shadow.root.barrier.316, label %shadow.root.barrier.done.317

shadow.root.barrier.316:                          ; preds = %shadow.root.barrier.done.315
  call void @js_write_barrier_root_nanbox(i64 %r1664) #9
  br label %shadow.root.barrier.done.317

shadow.root.barrier.done.317:                     ; preds = %shadow.root.barrier.316, %shadow.root.barrier.done.315
  %r1667.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r1667 = call i64 asm "", "=r,0"(i64 %r1667.rs4i) #9
  %statepoint_token415 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1667, i32 0, i32 0)
  %statepoint_token416 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0)
  %r1668417 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token416)
  %r1669 = or i64 %r1668417, 9222527611924643840
  %r1670 = bitcast i64 %r1669 to double
  %r1671 = and i64 %r1669, 281474976710655
  %r1672 = lshr i64 %r1669, 48
  %r1673 = icmp eq i64 %r1672, 32765
  %r1674 = icmp ugt i64 %r1671, 1048575
  %r1675 = and i1 %r1673, %r1674
  br i1 %r1675, label %arr.guard.deref.322, label %arr.fallback.319

arr.fast.318:                                     ; preds = %arr.guard.range.324
  %r1734 = add i64 %r1690, 56
  %r1735 = inttoptr i64 %r1734 to ptr
  %r1736 = load double, ptr %r1735, align 8
  %r1737 = bitcast double %r1736 to i64
  %r1738 = icmp eq i64 %r1737, 9222246136947933200
  %r1740 = select i1 %r1738, double 0x7FFC000000000001, double %r1736
  br label %arr.merge.321

arr.fallback.319:                                 ; preds = %arr.guard.live.323, %arr.guard.deref.322, %shadow.root.barrier.done.317
  %statepoint_token418 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 7760974052394532907, double %r1670, double 6.000000e+00, i32 0, i32 0)
  %r1730419 = call double @llvm.experimental.gc.result.f64(token %statepoint_token418)
  br label %arr.merge.321

arr.guard.oob.320:                                ; preds = %arr.guard.range.324
  br label %arr.merge.321

arr.merge.321:                                    ; preds = %arr.guard.oob.320, %arr.fallback.319, %arr.fast.318
  %r1741 = phi double [ %r1740, %arr.fast.318 ], [ %r1730419, %arr.fallback.319 ], [ 0x7FFC000000000001, %arr.guard.oob.320 ]
  %r1742 = load double, ptr @options_worker_ts_.str.24.handle, align 8
  %r1743 = bitcast double %r1741 to i64
  %r1744 = bitcast double %r1742 to i64
  %r1745 = icmp eq i64 %r1743, %r1744
  br i1 %r1745, label %streqlit.true.330, label %streqlit.tag.325

arr.guard.deref.322:                              ; preds = %shadow.root.barrier.done.317
  %r1676 = bitcast double %r1670 to i64
  %r1677 = and i64 %r1676, 281474976710655
  %r1678 = sub nsw i64 %r1677, 8
  %r1679 = inttoptr i64 %r1678 to ptr
  %r1680 = load i8, ptr %r1679, align 1
  %r1681 = icmp eq i8 %r1680, 1
  %r1682 = sub nsw i64 %r1677, 7
  %r1683 = inttoptr i64 %r1682 to ptr
  %r1684 = load i8, ptr %r1683, align 1
  %r1685 = and i8 %r1684, -128
  %r1686 = icmp ne i8 %r1685, 0
  %r1687 = inttoptr i64 %r1677 to ptr
  %r1688 = load i64, ptr %r1687, align 8
  %r1689 = and i1 %r1681, %r1686
  %r1690 = select i1 %r1689, i64 %r1688, i64 %r1677
  %r1691 = lshr i64 %r1690, 48
  %r1692 = icmp eq i64 %r1691, 0
  %r1693 = icmp ugt i64 %r1690, 1048575
  %r1694 = and i1 %r1692, %r1693
  br i1 %r1694, label %arr.guard.live.323, label %arr.fallback.319

arr.guard.live.323:                               ; preds = %arr.guard.deref.322
  %r1695 = sub nuw i64 %r1690, 8
  %r1696 = inttoptr i64 %r1695 to ptr
  %r1697 = load i8, ptr %r1696, align 1
  %r1698 = icmp eq i8 %r1697, 1
  %r1699 = sub nuw i64 %r1690, 7
  %r1700 = inttoptr i64 %r1699 to ptr
  %r1701 = load i8, ptr %r1700, align 1
  %r1702 = and i8 %r1701, -128
  %r1703 = icmp eq i8 %r1702, 0
  %r1704 = sub nuw i64 %r1690, 6
  %r1705 = inttoptr i64 %r1704 to ptr
  %r1706 = load i16, ptr %r1705, align 2
  %r1707 = and i16 %r1706, 1024
  %r1708 = icmp eq i16 %r1707, 0
  %r1709 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1710 = icmp eq i8 %r1709, 0
  %r1711 = inttoptr i64 %r1690 to ptr
  %r1712 = load i32, ptr %r1711, align 4
  %r1713 = getelementptr i8, ptr %r1711, i64 4
  %r1714 = load i32, ptr %r1713, align 4
  %r1718 = icmp ule i32 %r1712, 16000000
  %r1719 = icmp ule i32 %r1714, 16000000
  %r1720 = icmp ule i32 %r1712, %r1714
  %r1721 = and i1 %r1698, %r1703
  %r1722 = and i1 %r1721, %r1708
  %r1723 = and i1 %r1722, %r1710
  %r1725 = and i1 %r1723, %r1718
  %r1726 = and i1 %r1725, %r1719
  %r1727 = and i1 %r1726, %r1720
  br i1 %r1727, label %arr.guard.range.324, label %arr.fallback.319

arr.guard.range.324:                              ; preds = %arr.guard.live.323
  %r1717 = icmp ult i32 6, %r1712
  br i1 %r1717, label %arr.fast.318, label %arr.guard.oob.320

streqlit.tag.325:                                 ; preds = %arr.merge.321
  %r1746 = lshr i64 %r1743, 48
  %r1747 = icmp eq i64 %r1746, 32767
  %r1748 = and i64 %r1743, 281474976710655
  %r1749 = icmp ugt i64 %r1748, 4095
  %r1750 = and i1 %r1747, %r1749
  br i1 %r1750, label %streqlit.len.326, label %streqlit.false.331

streqlit.len.326:                                 ; preds = %streqlit.tag.325
  %r1751 = inttoptr i64 %r1748 to ptr
  %r1752 = getelementptr inbounds nuw i8, ptr %r1751, i64 4
  %r1753 = load i32, ptr %r1752, align 4
  %r1754 = icmp eq i32 %r1753, 6
  br i1 %r1754, label %streqlit.b0.327, label %streqlit.false.331

streqlit.b0.327:                                  ; preds = %streqlit.len.326
  %r1755 = getelementptr inbounds nuw i8, ptr %r1751, i64 20
  %r1756 = load i8, ptr %r1755, align 1
  %r1757 = icmp eq i8 %r1756, 118
  br i1 %r1757, label %streqlit.bl.328, label %streqlit.false.331

streqlit.bl.328:                                  ; preds = %streqlit.b0.327
  %r1758 = getelementptr inbounds nuw i8, ptr %r1751, i64 25
  %r1759 = load i8, ptr %r1758, align 1
  %r1760 = icmp eq i8 %r1759, 121
  br i1 %r1760, label %streqlit.slow.329, label %streqlit.false.331

streqlit.slow.329:                                ; preds = %streqlit.bl.328
  %r1761 = and i64 %r1744, 281474976710655
  %statepoint_token420 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1748, i64 %r1761, i32 0, i32 0)
  %r1762421 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token420)
  %r1763 = icmp ne i32 %r1762421, 0
  br label %streqlit.merge.332

streqlit.true.330:                                ; preds = %arr.merge.321
  br label %streqlit.merge.332

streqlit.false.331:                               ; preds = %streqlit.bl.328, %streqlit.b0.327, %streqlit.len.326, %streqlit.tag.325
  br label %streqlit.merge.332

streqlit.merge.332:                               ; preds = %streqlit.false.331, %streqlit.true.330, %streqlit.slow.329
  %r1764 = phi i1 [ true, %streqlit.true.330 ], [ false, %streqlit.false.331 ], [ %r1763, %streqlit.slow.329 ]
  %r1765 = select i1 %r1764, i64 9222246136947933188, i64 9222246136947933187
  %r1766 = bitcast i64 %r1765 to double
  %r1767 = icmp eq i64 %r1765, 9222246136947933188
  br i1 %r1767, label %if.then.333, label %if.else.334

if.then.333:                                      ; preds = %streqlit.merge.332
  %statepoint_token422 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 2, i32 0, i32 0)
  %r1768423 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token422)
  %rs4gc.s24 = inttoptr i64 %r1768423 to ptr addrspace(1)
  %r1769.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r1769 = call i64 asm "", "=r,0"(i64 %r1769.rs4i) #9
  %r1770 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1771 = icmp ne i32 %r1770, 0
  br i1 %r1771, label %shadow.root.barrier.336, label %shadow.root.barrier.done.337

if.else.334:                                      ; preds = %streqlit.merge.332
  br label %if.merge.335

if.merge.335:                                     ; preds = %shadow.root.barrier.done.341, %if.else.334
  %statepoint_token424 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0)
  %r1785425 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token424)
  %rs4gc.s25 = inttoptr i64 %r1785425 to ptr addrspace(1)
  %r1786.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r1786 = call i64 asm "", "=r,0"(i64 %r1786.rs4i) #9
  %r1787 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1788 = icmp ne i32 %r1787, 0
  br i1 %r1788, label %shadow.root.barrier.342, label %shadow.root.barrier.done.343

shadow.root.barrier.336:                          ; preds = %if.then.333
  call void @js_write_barrier_root_nanbox(i64 %r1769) #9
  br label %shadow.root.barrier.done.337

shadow.root.barrier.done.337:                     ; preds = %shadow.root.barrier.336, %if.then.333
  %r1772 = load double, ptr @options_worker_ts_.str.25.handle, align 8
  %r1773.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r1773 = call i64 asm "", "=r,0"(i64 %r1773.rs4i) #9
  %statepoint_token426 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1773, double %r1772, i32 0, i32 0)
  %r1774427 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token426)
  %rs4gc.s26 = inttoptr i64 %r1774427 to ptr addrspace(1)
  %r1775.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r1775 = call i64 asm "", "=r,0"(i64 %r1775.rs4i) #9
  %r1776 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1777 = icmp ne i32 %r1776, 0
  br i1 %r1777, label %shadow.root.barrier.338, label %shadow.root.barrier.done.339

shadow.root.barrier.338:                          ; preds = %shadow.root.barrier.done.337
  call void @js_write_barrier_root_nanbox(i64 %r1775) #9
  br label %shadow.root.barrier.done.339

shadow.root.barrier.done.339:                     ; preds = %shadow.root.barrier.338, %shadow.root.barrier.done.337
  %r1778 = load double, ptr @perry_global_options_worker_ts__7, align 8
  %r1779.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r1779 = call i64 asm "", "=r,0"(i64 %r1779.rs4i) #9
  %statepoint_token428 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1779, double %r1778, i32 0, i32 0)
  %r1780429 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token428)
  %rs4gc.s27 = inttoptr i64 %r1780429 to ptr addrspace(1)
  %r1781.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r1781 = call i64 asm "", "=r,0"(i64 %r1781.rs4i) #9
  %r1782 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1783 = icmp ne i32 %r1782, 0
  br i1 %r1783, label %shadow.root.barrier.340, label %shadow.root.barrier.done.341

shadow.root.barrier.340:                          ; preds = %shadow.root.barrier.done.339
  call void @js_write_barrier_root_nanbox(i64 %r1781) #9
  br label %shadow.root.barrier.done.341

shadow.root.barrier.done.341:                     ; preds = %shadow.root.barrier.340, %shadow.root.barrier.done.339
  %r1784.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r1784 = call i64 asm "", "=r,0"(i64 %r1784.rs4i) #9
  %statepoint_token430 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1784, i32 0, i32 0)
  br label %if.merge.335

shadow.root.barrier.342:                          ; preds = %if.merge.335
  call void @js_write_barrier_root_nanbox(i64 %r1786) #9
  br label %shadow.root.barrier.done.343

shadow.root.barrier.done.343:                     ; preds = %shadow.root.barrier.342, %if.merge.335
  %r1789 = load double, ptr @options_worker_ts_.str.26.handle, align 8
  %r1790.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r1790 = call i64 asm "", "=r,0"(i64 %r1790.rs4i) #9
  %statepoint_token431 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1790, double %r1789, i32 0, i32 0)
  %r1791432 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token431)
  %rs4gc.s28 = inttoptr i64 %r1791432 to ptr addrspace(1)
  %r1792.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r1792 = call i64 asm "", "=r,0"(i64 %r1792.rs4i) #9
  %r1793 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1794 = icmp ne i32 %r1793, 0
  br i1 %r1794, label %shadow.root.barrier.344, label %shadow.root.barrier.done.345

shadow.root.barrier.344:                          ; preds = %shadow.root.barrier.done.343
  call void @js_write_barrier_root_nanbox(i64 %r1792) #9
  br label %shadow.root.barrier.done.345

shadow.root.barrier.done.345:                     ; preds = %shadow.root.barrier.344, %shadow.root.barrier.done.343
  %r1795 = load double, ptr @perry_global_options_worker_ts__5, align 8
  %r1796 = bitcast double %r1795 to i64
  %r1798 = icmp eq i64 %r1796, 9222246136947933186
  %r1799 = select i1 %r1798, i64 9222246136947933188, i64 9222246136947933187
  %r1800 = bitcast i64 %r1799 to double
  %r1801 = icmp eq i64 %r1799, 9222246136947933188
  br i1 %r1801, label %ternary.then.346, label %ternary.else.347

ternary.then.346:                                 ; preds = %shadow.root.barrier.done.345
  br label %ternary.merge.348

ternary.else.347:                                 ; preds = %shadow.root.barrier.done.345
  br label %ternary.merge.348

ternary.merge.348:                                ; preds = %ternary.else.347, %ternary.then.346
  %r1802 = phi double [ 0.000000e+00, %ternary.then.346 ], [ 1.000000e+00, %ternary.else.347 ]
  %r1803.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r1803 = call i64 asm "", "=r,0"(i64 %r1803.rs4i) #9
  %statepoint_token433 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1803, double %r1802, i32 0, i32 0)
  %r1804434 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token433)
  %rs4gc.s29 = inttoptr i64 %r1804434 to ptr addrspace(1)
  %r1805.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r1805 = call i64 asm "", "=r,0"(i64 %r1805.rs4i) #9
  %r1806 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1807 = icmp ne i32 %r1806, 0
  br i1 %r1807, label %shadow.root.barrier.349, label %shadow.root.barrier.done.350

shadow.root.barrier.349:                          ; preds = %ternary.merge.348
  call void @js_write_barrier_root_nanbox(i64 %r1805) #9
  br label %shadow.root.barrier.done.350

shadow.root.barrier.done.350:                     ; preds = %shadow.root.barrier.349, %ternary.merge.348
  %r1808 = load double, ptr @perry_global_options_worker_ts__7, align 8
  %r1809 = bitcast double %r1808 to i64
  %r1811 = icmp eq i64 %r1809, 9222246136947933186
  %r1812 = select i1 %r1811, i64 9222246136947933188, i64 9222246136947933187
  %r1813 = bitcast i64 %r1812 to double
  %r1814 = icmp eq i64 %r1812, 9222246136947933188
  br i1 %r1814, label %ternary.then.351, label %ternary.else.352

ternary.then.351:                                 ; preds = %shadow.root.barrier.done.350
  br label %ternary.merge.353

ternary.else.352:                                 ; preds = %shadow.root.barrier.done.350
  br label %ternary.merge.353

ternary.merge.353:                                ; preds = %ternary.else.352, %ternary.then.351
  %r1815 = phi double [ 0.000000e+00, %ternary.then.351 ], [ 1.000000e+00, %ternary.else.352 ]
  %r1816.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r1816 = call i64 asm "", "=r,0"(i64 %r1816.rs4i) #9
  %statepoint_token435 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1816, double %r1815, i32 0, i32 0)
  %r1817436 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token435)
  %rs4gc.s30 = inttoptr i64 %r1817436 to ptr addrspace(1)
  %r1818.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r1818 = call i64 asm "", "=r,0"(i64 %r1818.rs4i) #9
  %r1819 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1820 = icmp ne i32 %r1819, 0
  br i1 %r1820, label %shadow.root.barrier.354, label %shadow.root.barrier.done.355

shadow.root.barrier.354:                          ; preds = %ternary.merge.353
  call void @js_write_barrier_root_nanbox(i64 %r1818) #9
  br label %shadow.root.barrier.done.355

shadow.root.barrier.done.355:                     ; preds = %shadow.root.barrier.354, %ternary.merge.353
  %r1821.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r1821 = call i64 asm "", "=r,0"(i64 %r1821.rs4i) #9
  %statepoint_token437 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1821, i32 0, i32 0)
  %statepoint_token438 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token439 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token440 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token441 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token442 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.356

event_loop.header.356:                            ; preds = %event_loop.body_wait.361, %event_loop.body_check.360, %shadow.root.barrier.done.355
  %statepoint_token443 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r1826444 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token443)
  %r1827 = icmp ne i32 %r1826444, 0
  br i1 %r1827, label %event_loop.host_return.358, label %event_loop.check_pending.357

event_loop.check_pending.357:                     ; preds = %event_loop.header.356
  %statepoint_token445 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1828446 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token445)
  %statepoint_token447 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1829448 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token447)
  %statepoint_token449 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1830450 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token449)
  %statepoint_token451 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r1831452 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token451)
  %statepoint_token453 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r1832454 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token453)
  %statepoint_token455 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r1833456 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token455)
  %r1834 = or i32 %r1828446, %r1829448
  %r1835 = or i32 %r1830450, %r1831452
  %r1836 = or i32 %r1835, %r1832454
  %r1837 = or i32 %r1834, %r1836
  %r1838 = or i32 %r1837, 0
  %r1839 = or i32 %r1838, %r1833456
  %r1840 = icmp ne i32 %r1839, 0
  br i1 %r1840, label %event_loop.body.359, label %event_loop.exit.362

event_loop.host_return.358:                       ; preds = %event_loop.header.356
  call void @js_typed_feedback_maybe_dump_trace() #9
  ret i32 0

event_loop.body.359:                              ; preds = %event_loop.check_pending.357
  %statepoint_token457 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token458 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.360

event_loop.body_check.360:                        ; preds = %event_loop.body.359
  %statepoint_token459 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1842460 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token459)
  %statepoint_token461 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1843462 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token461)
  %statepoint_token463 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1844464 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token463)
  %statepoint_token465 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r1845466 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token465)
  %statepoint_token467 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r1846468 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token467)
  %statepoint_token469 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r1847470 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token469)
  %r1848 = or i32 %r1842460, %r1843462
  %r1849 = or i32 %r1844464, %r1845466
  %r1850 = or i32 %r1849, %r1846468
  %r1851 = or i32 %r1848, %r1850
  %r1852 = or i32 %r1851, 0
  %r1853 = or i32 %r1852, %r1847470
  %r1854 = icmp ne i32 %r1853, 0
  br i1 %r1854, label %event_loop.body_wait.361, label %event_loop.header.356

event_loop.body_wait.361:                         ; preds = %event_loop.body_check.360
  %statepoint_token471 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.356

event_loop.exit.362:                              ; preds = %event_loop.check_pending.357
  %statepoint_token472 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token473 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token474 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token475 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token476 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token477 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token478 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token479 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token480 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r1857481 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token480)
  call void @js_typed_feedback_maybe_dump_trace() #9
  ret i32 %r1857481
}

; Function Attrs: optsize
define void @__perry_init_strings_options_worker_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.0.bytes, i32 5)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @options_worker_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.1.bytes, i32 6)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @options_worker_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.2.bytes, i32 12)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @options_worker_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.3.bytes, i32 4)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @options_worker_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.4.bytes, i32 6)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @options_worker_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.5.bytes, i32 4)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @options_worker_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.6.bytes, i32 8)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @options_worker_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.7.bytes, i32 2)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @options_worker_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.7.handle to i64))
  %r25 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.8.bytes, i32 12)
  %r26 = call double @js_nanbox_string(i64 %r25)
  store double %r26, ptr @options_worker_ts_.str.8.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.8.handle to i64))
  %r28 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.9.bytes, i32 4)
  %r29 = call double @js_nanbox_string(i64 %r28)
  store double %r29, ptr @options_worker_ts_.str.9.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.9.handle to i64))
  %r31 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.10.bytes, i32 1)
  %r32 = call double @js_nanbox_string(i64 %r31)
  store double %r32, ptr @options_worker_ts_.str.10.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.10.handle to i64))
  %r34 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.11.bytes, i32 8)
  %r35 = call double @js_nanbox_string(i64 %r34)
  store double %r35, ptr @options_worker_ts_.str.11.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.11.handle to i64))
  %r37 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.12.bytes, i32 1)
  %r38 = call double @js_nanbox_string(i64 %r37)
  store double %r38, ptr @options_worker_ts_.str.12.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.12.handle to i64))
  %r40 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.13.bytes, i32 4)
  %r41 = call double @js_nanbox_string(i64 %r40)
  store double %r41, ptr @options_worker_ts_.str.13.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.13.handle to i64))
  %r43 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.14.bytes, i32 2)
  %r44 = call double @js_nanbox_string(i64 %r43)
  store double %r44, ptr @options_worker_ts_.str.14.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.14.handle to i64))
  %r46 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.15.bytes, i32 4)
  %r47 = call double @js_nanbox_string(i64 %r46)
  store double %r47, ptr @options_worker_ts_.str.15.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.15.handle to i64))
  %r49 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.16.bytes, i32 5)
  %r50 = call double @js_nanbox_string(i64 %r49)
  store double %r50, ptr @options_worker_ts_.str.16.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.16.handle to i64))
  %r52 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.17.bytes, i32 6)
  %r53 = call double @js_nanbox_string(i64 %r52)
  store double %r53, ptr @options_worker_ts_.str.17.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.17.handle to i64))
  %r55 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.18.bytes, i32 5)
  %r56 = call double @js_nanbox_string(i64 %r55)
  store double %r56, ptr @options_worker_ts_.str.18.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.18.handle to i64))
  %r58 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.19.bytes, i32 4)
  %r59 = call double @js_nanbox_string(i64 %r58)
  store double %r59, ptr @options_worker_ts_.str.19.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.19.handle to i64))
  %r61 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.20.bytes, i32 3)
  %r62 = call double @js_nanbox_string(i64 %r61)
  store double %r62, ptr @options_worker_ts_.str.20.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.20.handle to i64))
  %r64 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.21.bytes, i32 6)
  %r65 = call double @js_nanbox_string(i64 %r64)
  store double %r65, ptr @options_worker_ts_.str.21.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.21.handle to i64))
  %r67 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.22.bytes, i32 4)
  %r68 = call double @js_nanbox_string(i64 %r67)
  store double %r68, ptr @options_worker_ts_.str.22.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.22.handle to i64))
  %r70 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.23.bytes, i32 6)
  %r71 = call double @js_nanbox_string(i64 %r70)
  store double %r71, ptr @options_worker_ts_.str.23.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.23.handle to i64))
  %r73 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.24.bytes, i32 6)
  %r74 = call double @js_nanbox_string(i64 %r73)
  store double %r74, ptr @options_worker_ts_.str.24.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.24.handle to i64))
  %r76 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.25.bytes, i32 6)
  %r77 = call double @js_nanbox_string(i64 %r76)
  store double %r77, ptr @options_worker_ts_.str.25.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.25.handle to i64))
  %r79 = call i64 @js_string_from_bytes(ptr @options_worker_ts_.str.26.bytes, i32 4)
  %r80 = call double @js_nanbox_string(i64 %r79)
  store double %r80, ptr @options_worker_ts_.str.26.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @options_worker_ts_.str.26.handle to i64))
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_options_worker_ts__identity, ptr @options_worker_ts_.str.1, i32 8)
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_options_worker_ts__run, ptr @options_worker_ts_.str.2, i32 3)
  call void @js_register_function_name_static(ptr @perry_fn_options_worker_ts__identity, ptr @options_worker_ts_.str.1, i32 8)
  call void @js_register_function_name_static(ptr @perry_fn_options_worker_ts__run, ptr @options_worker_ts_.str.2, i32 3)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_options_worker_ts__identity, ptr @options_worker_ts_.str.3, i32 65, i32 0)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_options_worker_ts__run, ptr @options_worker_ts_.str.4, i32 1281, i32 0)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_options_worker_ts__identity, i32 2)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_options_worker_ts__run, i32 1)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_options_worker_ts__identity, i32 2)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_options_worker_ts__run, i32 1)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_options_worker_ts__identity)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_options_worker_ts__run)
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_options_worker_ts() #6 {
entry.0:
  call void @__perry_init_strings_options_worker_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { inlinehint optsize "frame-pointer"="non-leaf" }
attributes #8 = { noinline optsize "frame-pointer"="non-leaf" }
attributes #9 = { "gc-leaf-function" }
