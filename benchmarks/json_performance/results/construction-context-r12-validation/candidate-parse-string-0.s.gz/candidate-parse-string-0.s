
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/construction-context-r12/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010016e56c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_>:
10016e56c:     	sub	sp, sp, #0x60
10016e570:     	stp	x24, x23, [sp, #0x20]
10016e574:     	stp	x22, x21, [sp, #0x30]
10016e578:     	stp	x20, x19, [sp, #0x40]
10016e57c:     	stp	x29, x30, [sp, #0x50]
10016e580:     	add	x29, sp, #0x50
10016e584:     	lsr	w8, w2, #19
10016e588:     	cbz	w8, 0x10016e5a4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x38>
10016e58c:     	ldp	x29, x30, [sp, #0x50]
10016e590:     	ldp	x20, x19, [sp, #0x40]
10016e594:     	ldp	x22, x21, [sp, #0x30]
10016e598:     	ldp	x24, x23, [sp, #0x20]
10016e59c:     	add	sp, sp, #0x60
10016e5a0:     	b	0x10016f38c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_>
10016e5a4:     	cmp	x2, #0x40
10016e5a8:     	b.hs	0x10016e6dc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x170>
10016e5ac:     	ands	x8, x2, #0x38
10016e5b0:     	b.eq	0x10016e5d4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x68>
10016e5b4:     	and	x9, x2, #0x38
10016e5b8:     	neg	x9, x9
10016e5bc:     	mov	x10, x1
10016e5c0:     	ldr	x11, [x10], #0x8
10016e5c4:     	tst	x11, #0x8080808080808080
10016e5c8:     	b.ne	0x10016e668 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xfc>
10016e5cc:     	adds	x9, x9, #0x8
10016e5d0:     	b.ne	0x10016e5c0 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x54>
10016e5d4:     	mov	x19, x2
10016e5d8:     	and	x9, x2, #0x7
10016e5dc:     	cbz	x9, 0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e5e0:     	add	x8, x1, x8
10016e5e4:     	ldrsb	w10, [x8]
10016e5e8:     	tbnz	w10, #0x1f, 0x10016e668 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xfc>
10016e5ec:     	mov	x19, x2
10016e5f0:     	cmp	x9, #0x1
10016e5f4:     	b.eq	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e5f8:     	ldrsb	w10, [x8, #0x1]
10016e5fc:     	tbnz	w10, #0x1f, 0x10016e668 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xfc>
10016e600:     	mov	x19, x2
10016e604:     	cmp	x9, #0x2
10016e608:     	b.eq	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e60c:     	ldrsb	w10, [x8, #0x2]
10016e610:     	tbnz	w10, #0x1f, 0x10016e668 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xfc>
10016e614:     	mov	x19, x2
10016e618:     	cmp	x9, #0x3
10016e61c:     	b.eq	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e620:     	ldrsb	w10, [x8, #0x3]
10016e624:     	tbnz	w10, #0x1f, 0x10016e668 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xfc>
10016e628:     	mov	x19, x2
10016e62c:     	cmp	x9, #0x4
10016e630:     	b.eq	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e634:     	ldrsb	w10, [x8, #0x4]
10016e638:     	tbnz	w10, #0x1f, 0x10016e668 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xfc>
10016e63c:     	mov	x19, x2
10016e640:     	cmp	x9, #0x5
10016e644:     	b.eq	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e648:     	ldrsb	w10, [x8, #0x5]
10016e64c:     	tbnz	w10, #0x1f, 0x10016e668 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xfc>
10016e650:     	mov	x19, x2
10016e654:     	cmp	x9, #0x6
10016e658:     	b.eq	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e65c:     	ldrsb	w8, [x8, #0x6]
10016e660:     	mov	x19, x2
10016e664:     	tbz	w8, #0x1f, 0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e668:     	cbz	w2, 0x10016e860 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f4>
10016e66c:     	mov	x19, x2
10016e670:     	ands	x20, x2, #0x7ffff
10016e674:     	b.eq	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e678:     	mov	x8, x1
10016e67c:     	ands	x9, x2, #0x3
10016e680:     	b.eq	0x10016e69c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x130>
10016e684:     	mov	x8, x1
10016e688:     	ldrsb	w10, [x8]
10016e68c:     	tbnz	w10, #0x1f, 0x10016e76c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x200>
10016e690:     	add	x8, x8, #0x1
10016e694:     	subs	x9, x9, #0x1
10016e698:     	b.ne	0x10016e688 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x11c>
10016e69c:     	mov	x19, x2
10016e6a0:     	cmp	x20, #0x4
10016e6a4:     	b.lo	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e6a8:     	add	x9, x1, x20
10016e6ac:     	ldrsb	w10, [x8]
10016e6b0:     	tbnz	w10, #0x1f, 0x10016e76c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x200>
10016e6b4:     	ldrsb	w10, [x8, #0x1]
10016e6b8:     	tbnz	w10, #0x1f, 0x10016e76c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x200>
10016e6bc:     	ldrsb	w10, [x8, #0x2]
10016e6c0:     	tbnz	w10, #0x1f, 0x10016e76c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x200>
10016e6c4:     	ldrsb	w10, [x8, #0x3]
10016e6c8:     	tbnz	w10, #0x1f, 0x10016e76c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x200>
10016e6cc:     	add	x8, x8, #0x4
10016e6d0:     	cmp	x8, x9
10016e6d4:     	b.ne	0x10016e6ac <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x140>
10016e6d8:     	b	0x10016e764 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1f8>
10016e6dc:     	and	x8, x2, #0x7fffffffffffffc0
10016e6e0:     	and	x8, x8, #0xffffffff0007ffff
10016e6e4:     	add	x8, x1, x8
10016e6e8:     	mov	x9, x1
10016e6ec:     	ldp	q0, q1, [x9]
10016e6f0:     	ldp	q2, q3, [x9, #0x20]
10016e6f4:     	orr.16b	v0, v1, v0
10016e6f8:     	orr.16b	v1, v2, v3
10016e6fc:     	orr.16b	v0, v0, v1
10016e700:     	umaxv.16b	b0, v0
10016e704:     	fmov	w10, s0
10016e708:     	tbnz	w10, #0x7, 0x10016e668 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xfc>
10016e70c:     	add	x9, x9, #0x40
10016e710:     	cmp	x9, x8
10016e714:     	b.ne	0x10016e6ec <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x180>
10016e718:     	ands	x9, x2, #0x30
10016e71c:     	b.eq	0x10016e740 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1d4>
10016e720:     	mov	x10, x9
10016e724:     	mov	x11, x8
10016e728:     	ldr	q0, [x11], #0x10
10016e72c:     	umaxv.16b	b0, v0
10016e730:     	fmov	w12, s0
10016e734:     	tbnz	w12, #0x7, 0x10016e668 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xfc>
10016e738:     	subs	x10, x10, #0x10
10016e73c:     	b.ne	0x10016e728 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1bc>
10016e740:     	mov	x19, x2
10016e744:     	and	x10, x2, #0xf
10016e748:     	cbz	x10, 0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e74c:     	add	x8, x8, x9
10016e750:     	ldrsb	w9, [x8]
10016e754:     	tbnz	w9, #0x1f, 0x10016e668 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xfc>
10016e758:     	add	x8, x8, #0x1
10016e75c:     	subs	x10, x10, #0x1
10016e760:     	b.ne	0x10016e750 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1e4>
10016e764:     	mov	x19, x2
10016e768:     	b	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e76c:     	mov	x21, x0
10016e770:     	mov	x22, x2
10016e774:     	cmp	w2, #0x3f
10016e778:     	b.ls	0x10016e7a0 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x234>
10016e77c:     	mov	x0, x1
10016e780:     	mov	x19, x1
10016e784:     	mov	x1, x20
10016e788:     	bl	0x1005e6c20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
10016e78c:     	mov	x1, x19
10016e790:     	mov	x19, x0
10016e794:     	mov	x2, x22
10016e798:     	mov	x0, x21
10016e79c:     	b	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e7a0:     	add	x8, sp, #0x8
10016e7a4:     	mov	x23, x1
10016e7a8:     	mov	x0, x1
10016e7ac:     	mov	x1, x20
10016e7b0:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10016e7b4:     	ldr	x8, [sp, #0x8]
10016e7b8:     	cbz	x8, 0x10016e834 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2c8>
10016e7bc:     	mov	w19, #0x0               ; =0
10016e7c0:     	mov	x8, #0x0                ; =0
10016e7c4:     	mov	w9, #0x2                ; =2
10016e7c8:     	mov	w10, #0x3               ; =3
10016e7cc:     	mov	w11, #0x4               ; =4
10016e7d0:     	mov	x2, x22
10016e7d4:     	mov	x1, x23
10016e7d8:     	mov	x0, x21
10016e7dc:     	b	0x10016e7f4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x288>
10016e7e0:     	add	w19, w19, #0x1
10016e7e4:     	mov	w12, #0x1               ; =1
10016e7e8:     	add	x8, x12, x8
10016e7ec:     	cmp	x8, x20
10016e7f0:     	b.hs	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e7f4:     	ldrsb	w12, [x1, x8]
10016e7f8:     	tbz	w12, #0x1f, 0x10016e7e0 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x274>
10016e7fc:     	and	w12, w12, #0xff
10016e800:     	cmp	w12, #0xc0
10016e804:     	b.lo	0x10016e7e4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x278>
10016e808:     	cmp	w12, #0xf0
10016e80c:     	add	w13, w19, #0x2
10016e810:     	csel	x14, x10, x11, lo
10016e814:     	csinc	w13, w13, w19, hs
10016e818:     	cmp	w12, #0xe0
10016e81c:     	csel	x12, x9, x14, lo
10016e820:     	csinc	w19, w13, w19, hs
10016e824:     	add	x8, x12, x8
10016e828:     	cmp	x8, x20
10016e82c:     	b.lo	0x10016e7f4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x288>
10016e830:     	b	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016e834:     	ldr	x8, [sp, #0x18]
10016e838:     	mov	x2, x22
10016e83c:     	mov	x1, x23
10016e840:     	mov	x0, x21
10016e844:     	cbz	x8, 0x10016e860 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f4>
10016e848:     	ldr	x9, [sp, #0x10]
10016e84c:     	cmp	x8, #0x8
10016e850:     	b.hs	0x10016e978 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x40c>
10016e854:     	mov	x10, #0x0               ; =0
10016e858:     	mov	w19, #0x0               ; =0
10016e85c:     	b	0x10016ec40 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x6d4>
10016e860:     	mov	w19, #0x0               ; =0
10016e864:     	ldr	x8, [x0]
10016e868:     	cbz	x8, 0x10016e8ac <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x340>
10016e86c:     	add	x8, x2, #0x23
10016e870:     	and	x8, x8, #0x7ffffffffffffff8
10016e874:     	and	x8, x8, #0xffffffff000fffff
10016e878:     	cmp	x8, #0x4, lsl #12       ; =0x4000
10016e87c:     	b.hi	0x10016e8ac <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x340>
10016e880:     	ldr	x9, [x0, #0x10]
10016e884:     	ldrb	w9, [x9]
10016e888:     	tbnz	w9, #0x0, 0x10016e8ac <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x340>
10016e88c:     	ldr	x10, [x0, #0x8]
10016e890:     	ldp	x9, x12, [x10, #0x8]
10016e894:     	add	x9, x9, #0x7
10016e898:     	and	x11, x9, #0xfffffffffffffff8
10016e89c:     	subs	x9, x12, x11
10016e8a0:     	csel	x9, xzr, x9, lo
10016e8a4:     	cmp	x8, x9
10016e8a8:     	b.ls	0x10016e8fc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x390>
10016e8ac:     	mov	x0, x2
10016e8b0:     	mov	x21, x2
10016e8b4:     	mov	x22, x1
10016e8b8:     	bl	0x1003464ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10016e8bc:     	mov	x20, x0
10016e8c0:     	mov	x0, x1
10016e8c4:     	stp	w19, w21, [x20]
10016e8c8:     	str	w21, [x20, #0x8]
10016e8cc:     	mov	x8, #0x200000000        ; =8589934592
10016e8d0:     	stur	x8, [x20, #0xc]
10016e8d4:     	mov	x1, x22
10016e8d8:     	mov	x2, x21
10016e8dc:     	bl	0x100b5872c <_writev+0x100b5872c>
10016e8e0:     	mov	x0, x20
10016e8e4:     	ldp	x29, x30, [sp, #0x50]
10016e8e8:     	ldp	x20, x19, [sp, #0x40]
10016e8ec:     	ldp	x22, x21, [sp, #0x30]
10016e8f0:     	ldp	x24, x23, [sp, #0x20]
10016e8f4:     	add	sp, sp, #0x60
10016e8f8:     	ret
10016e8fc:     	add	x9, x2, #0x14
10016e900:     	ldr	x12, [x10]
10016e904:     	add	x21, x12, x11
10016e908:     	add	x11, x11, x8
10016e90c:     	str	x11, [x10, #0x8]
10016e910:     	mov	w10, #0x203             ; =515
10016e914:     	stp	w10, w8, [x21]
10016e918:     	add	x20, x21, #0x8
10016e91c:     	subs	x8, x8, #0x8
10016e920:     	csel	x10, xzr, x8, lo
10016e924:     	subs	x8, x10, x9
10016e928:     	csel	x8, xzr, x8, lo
10016e92c:     	b.ls	0x10016e960 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x3f4>
10016e930:     	cmp	x8, #0x9
10016e934:     	b.hs	0x10016e944 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x3d8>
10016e938:     	add	x8, x20, x10
10016e93c:     	stur	xzr, [x8, #-0x8]
10016e940:     	b	0x10016e960 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x3f4>
10016e944:     	add	x0, x20, x9
10016e948:     	mov	x22, x1
10016e94c:     	mov	x1, x8
10016e950:     	mov	x23, x2
10016e954:     	bl	0x100b58264 <_writev+0x100b58264>
10016e958:     	mov	x1, x22
10016e95c:     	mov	x2, x23
10016e960:     	stp	w19, w2, [x21, #0x8]
10016e964:     	str	w2, [x21, #0x10]
10016e968:     	mov	x8, #0x200000000        ; =8589934592
10016e96c:     	stur	x8, [x21, #0x14]
10016e970:     	add	x0, x21, #0x1c
10016e974:     	b	0x10016e8dc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x370>
10016e978:     	cmp	x8, #0x20
10016e97c:     	b.hs	0x10016e98c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x420>
10016e980:     	mov	x10, #0x0               ; =0
10016e984:     	mov	w19, #0x0               ; =0
10016e988:     	b	0x10016eb90 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x624>
10016e98c:     	movi.2d	v0, #0000000000000000
10016e990:     	and	x11, x8, #0x18
10016e994:     	movi.16b	v1, #0xf0
10016e998:     	and	x10, x8, #0xffffffffffffffe0
10016e99c:     	movi.4s	v2, #0x2
10016e9a0:     	add	x12, x9, #0x10
10016e9a4:     	movi.16b	v4, #0xc0
10016e9a8:     	and	x13, x8, #0xffffffffffffffe0
10016e9ac:     	movi.2d	v3, #0000000000000000
10016e9b0:     	movi.2d	v6, #0000000000000000
10016e9b4:     	movi.2d	v5, #0000000000000000
10016e9b8:     	movi.2d	v7, #0000000000000000
10016e9bc:     	movi.2d	v16, #0000000000000000
10016e9c0:     	movi.2d	v17, #0000000000000000
10016e9c4:     	movi.2d	v18, #0000000000000000
10016e9c8:     	ldp	q20, q19, [x12, #-0x10]
10016e9cc:     	cmhi.16b	v21, v1, v20
10016e9d0:     	sshll2.8h	v22, v21, #0x0
10016e9d4:     	sshll2.4s	v23, v22, #0x0
10016e9d8:     	sshll.4s	v24, v22, #0x0
10016e9dc:     	sshll.8h	v21, v21, #0x0
10016e9e0:     	sshll2.4s	v25, v21, #0x0
10016e9e4:     	sshll.4s	v26, v21, #0x0
10016e9e8:     	cmhi.16b	v27, v1, v19
10016e9ec:     	sshll2.8h	v28, v27, #0x0
10016e9f0:     	sshll2.4s	v29, v28, #0x0
10016e9f4:     	sshll.4s	v30, v28, #0x0
10016e9f8:     	sshll.8h	v27, v27, #0x0
10016e9fc:     	sshll2.4s	v31, v27, #0x0
10016ea00:     	bic.16b	v26, v2, v26
10016ea04:     	ssubw.4s	v26, v26, v21
10016ea08:     	bic.16b	v25, v2, v25
10016ea0c:     	ssubw2.4s	v25, v25, v21
10016ea10:     	sshll.4s	v21, v27, #0x0
10016ea14:     	bic.16b	v24, v2, v24
10016ea18:     	ssubw.4s	v24, v24, v22
10016ea1c:     	bic.16b	v23, v2, v23
10016ea20:     	ssubw2.4s	v22, v23, v22
10016ea24:     	bic.16b	v21, v2, v21
10016ea28:     	ssubw.4s	v21, v21, v27
10016ea2c:     	bic.16b	v23, v2, v31
10016ea30:     	ssubw2.4s	v23, v23, v27
10016ea34:     	bic.16b	v27, v2, v30
10016ea38:     	ssubw.4s	v27, v27, v28
10016ea3c:     	bic.16b	v29, v2, v29
10016ea40:     	ssubw2.4s	v28, v29, v28
10016ea44:     	cmgt.16b	v29, v4, v20
10016ea48:     	sshll2.8h	v30, v29, #0x0
10016ea4c:     	ushll2.4s	v31, v30, #0x0
10016ea50:     	bic.16b	v22, v22, v31
10016ea54:     	cmlt.16b	v20, v20, #0
10016ea58:     	sshll.8h	v29, v29, #0x0
10016ea5c:     	ushll.4s	v30, v30, #0x0
10016ea60:     	bic.16b	v24, v24, v30
10016ea64:     	ushll2.4s	v30, v29, #0x0
10016ea68:     	bic.16b	v25, v25, v30
10016ea6c:     	sshll2.8h	v30, v20, #0x0
10016ea70:     	sshll.8h	v20, v20, #0x0
10016ea74:     	ushll.4s	v29, v29, #0x0
10016ea78:     	bic.16b	v26, v26, v29
10016ea7c:     	sshll.4s	v29, v20, #0x0
10016ea80:     	and.16b	v26, v26, v29
10016ea84:     	mvn.16b	v29, v29
10016ea88:     	sub.4s	v26, v26, v29
10016ea8c:     	sshll2.4s	v29, v30, #0x0
10016ea90:     	sshll.4s	v30, v30, #0x0
10016ea94:     	sshll2.4s	v20, v20, #0x0
10016ea98:     	and.16b	v25, v25, v20
10016ea9c:     	mvn.16b	v20, v20
10016eaa0:     	sub.4s	v20, v25, v20
10016eaa4:     	cmgt.16b	v25, v4, v19
10016eaa8:     	and.16b	v24, v24, v30
10016eaac:     	mvn.16b	v30, v30
10016eab0:     	sub.4s	v24, v24, v30
10016eab4:     	sshll2.8h	v30, v25, #0x0
10016eab8:     	and.16b	v22, v22, v29
10016eabc:     	mvn.16b	v29, v29
10016eac0:     	sub.4s	v22, v22, v29
10016eac4:     	ushll2.4s	v29, v30, #0x0
10016eac8:     	bic.16b	v28, v28, v29
10016eacc:     	cmlt.16b	v19, v19, #0
10016ead0:     	sshll.8h	v25, v25, #0x0
10016ead4:     	ushll.4s	v29, v30, #0x0
10016ead8:     	bic.16b	v27, v27, v29
10016eadc:     	ushll2.4s	v29, v25, #0x0
10016eae0:     	bic.16b	v23, v23, v29
10016eae4:     	sshll.8h	v29, v19, #0x0
10016eae8:     	ushll.4s	v25, v25, #0x0
10016eaec:     	bic.16b	v21, v21, v25
10016eaf0:     	sshll.4s	v25, v29, #0x0
10016eaf4:     	and.16b	v21, v21, v25
10016eaf8:     	mvn.16b	v25, v25
10016eafc:     	sub.4s	v21, v21, v25
10016eb00:     	sshll2.8h	v19, v19, #0x0
10016eb04:     	sshll2.4s	v25, v29, #0x0
10016eb08:     	and.16b	v23, v23, v25
10016eb0c:     	mvn.16b	v25, v25
10016eb10:     	sub.4s	v23, v23, v25
10016eb14:     	sshll.4s	v25, v19, #0x0
10016eb18:     	and.16b	v27, v27, v25
10016eb1c:     	mvn.16b	v25, v25
10016eb20:     	sub.4s	v25, v27, v25
10016eb24:     	sshll2.4s	v19, v19, #0x0
10016eb28:     	and.16b	v27, v28, v19
10016eb2c:     	mvn.16b	v19, v19
10016eb30:     	sub.4s	v19, v27, v19
10016eb34:     	add.4s	v7, v22, v7
10016eb38:     	add.4s	v5, v24, v5
10016eb3c:     	add.4s	v6, v20, v6
10016eb40:     	add.4s	v3, v26, v3
10016eb44:     	add.4s	v18, v19, v18
10016eb48:     	add.4s	v17, v25, v17
10016eb4c:     	add.4s	v0, v23, v0
10016eb50:     	add.4s	v16, v21, v16
10016eb54:     	add	x12, x12, #0x20
10016eb58:     	subs	x13, x13, #0x20
10016eb5c:     	b.ne	0x10016e9c8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x45c>
10016eb60:     	add.4s	v0, v0, v6
10016eb64:     	add.4s	v1, v18, v7
10016eb68:     	add.4s	v2, v16, v3
10016eb6c:     	add.4s	v3, v17, v5
10016eb70:     	add.4s	v2, v2, v3
10016eb74:     	add.4s	v0, v0, v1
10016eb78:     	add.4s	v0, v2, v0
10016eb7c:     	addv.4s	s0, v0
10016eb80:     	fmov	w19, s0
10016eb84:     	cmp	x8, x10
10016eb88:     	b.eq	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016eb8c:     	cbz	x11, 0x10016ec40 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x6d4>
10016eb90:     	mov	x12, x10
10016eb94:     	and	x10, x8, #0xfffffffffffffff8
10016eb98:     	movi.2d	v0, #0000000000000000
10016eb9c:     	mov.s	v0[0], w19
10016eba0:     	movi.2d	v1, #0000000000000000
10016eba4:     	sub	x11, x12, x10
10016eba8:     	add	x12, x9, x12
10016ebac:     	movi.8b	v2, #0xf0
10016ebb0:     	movi.4s	v3, #0x2
10016ebb4:     	movi.8b	v4, #0xc0
10016ebb8:     	ldr	d5, [x12], #0x8
10016ebbc:     	sshll.8h	v6, v5, #0x0
10016ebc0:     	cmlt.8h	v6, v6, #0
10016ebc4:     	sshll2.4s	v7, v6, #0x0
10016ebc8:     	sshll.4s	v6, v6, #0x0
10016ebcc:     	cmhi.8b	v16, v2, v5
10016ebd0:     	sshll.8h	v16, v16, #0x0
10016ebd4:     	sshll2.4s	v17, v16, #0x0
10016ebd8:     	sshll.4s	v18, v16, #0x0
10016ebdc:     	bic.16b	v18, v3, v18
10016ebe0:     	ssubw.4s	v18, v18, v16
10016ebe4:     	bic.16b	v17, v3, v17
10016ebe8:     	ssubw2.4s	v16, v17, v16
10016ebec:     	cmgt.8b	v5, v4, v5
10016ebf0:     	sshll.8h	v5, v5, #0x0
10016ebf4:     	ushll.4s	v17, v5, #0x0
10016ebf8:     	ushll2.4s	v5, v5, #0x0
10016ebfc:     	bic.16b	v5, v16, v5
10016ec00:     	bic.16b	v16, v18, v17
10016ec04:     	and.16b	v16, v16, v6
10016ec08:     	mvn.16b	v6, v6
10016ec0c:     	sub.4s	v6, v16, v6
10016ec10:     	and.16b	v5, v5, v7
10016ec14:     	mvn.16b	v7, v7
10016ec18:     	sub.4s	v5, v5, v7
10016ec1c:     	add.4s	v1, v5, v1
10016ec20:     	add.4s	v0, v6, v0
10016ec24:     	adds	x11, x11, #0x8
10016ec28:     	b.ne	0x10016ebb8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x64c>
10016ec2c:     	add.4s	v0, v0, v1
10016ec30:     	addv.4s	s0, v0
10016ec34:     	fmov	w19, s0
10016ec38:     	cmp	x8, x10
10016ec3c:     	b.eq	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
10016ec40:     	sub	x8, x8, x10
10016ec44:     	add	x9, x9, x10
10016ec48:     	mov	w10, #0x1               ; =1
10016ec4c:     	ldrsb	w11, [x9], #0x1
10016ec50:     	and	w12, w11, #0xff
10016ec54:     	cmp	w12, #0xf0
10016ec58:     	cinc	w13, w10, hs
10016ec5c:     	cmp	w12, #0xc0
10016ec60:     	csel	w12, wzr, w13, lo
10016ec64:     	tst	w11, #0x80000000
10016ec68:     	csinc	w11, w12, wzr, ne
10016ec6c:     	add	w19, w11, w19
10016ec70:     	subs	x8, x8, #0x1
10016ec74:     	b.ne	0x10016ec4c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x6e0>
10016ec78:     	b	0x10016e864 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2f8>
