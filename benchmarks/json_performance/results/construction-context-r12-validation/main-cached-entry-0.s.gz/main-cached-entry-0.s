
benchmarks/json_performance/.work/construction-context-r12/main-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100842654 <_js_json_parse>:
100842654:     	stp	x29, x30, [sp, #-0x10]!
100842658:     	mov	x29, sp
10084265c:     	cbz	x0, 0x1008426b4 <_js_json_parse+0x60>
100842660:     	ldr	w1, [x0, #0x4]
100842664:     	cmp	w1, #0x2
100842668:     	b.eq	0x100842678 <_js_json_parse+0x24>
10084266c:     	cbz	w1, 0x1008426b4 <_js_json_parse+0x60>
100842670:     	ldrb	w8, [x0, #0x14]
100842674:     	b	0x100842698 <_js_json_parse+0x44>
100842678:     	ldrb	w8, [x0, #0x14]
10084267c:     	cmp	w8, #0x7b
100842680:     	b.ne	0x100842698 <_js_json_parse+0x44>
100842684:     	ldrb	w8, [x0, #0x15]
100842688:     	cmp	w8, #0x7d
10084268c:     	b.ne	0x1008426a4 <_js_json_parse+0x50>
100842690:     	ldp	x29, x30, [sp], #0x10
100842694:     	b	0x1004ea480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100842698:     	orr	w8, w8, #0x20
10084269c:     	cmp	w8, #0x7b
1008426a0:     	b.ne	0x1008426ac <_js_json_parse+0x58>
1008426a4:     	ldp	x29, x30, [sp], #0x10
1008426a8:     	b	0x1005038f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
1008426ac:     	ldp	x29, x30, [sp], #0x10
1008426b0:     	b	0x100505f74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
1008426b4:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x719c>
1008426b8:     	add	x0, x0, #0x341
1008426bc:     	mov	w1, #0x1c               ; =28
1008426c0:     	bl	0x1005063a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
