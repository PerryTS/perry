
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/construction-context-r12/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005e71e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len>:
1005e71e0:     	cbz	x2, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e71e4:     	ldr	w8, [x2, #0x4]
1005e71e8:     	adds	x11, x3, x1
1005e71ec:     	cset	w9, hs
1005e71f0:     	subs	x10, x8, x11
1005e71f4:     	csinc	w9, w9, wzr, hs
1005e71f8:     	tbnz	w9, #0x0, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e71fc:     	subs	x8, x8, x1
1005e7200:     	b.lo	0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7204:     	cmp	x8, x1, lsr #3
1005e7208:     	b.hi	0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e720c:     	add	x12, x2, #0x14
1005e7210:     	ldr	w9, [x2]
1005e7214:     	cbz	x1, 0x1005e7234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x54>
1005e7218:     	add	x13, x12, x3
1005e721c:     	add	x13, x13, x1
1005e7220:     	ldurb	w14, [x13, #-0x1]
1005e7224:     	cmp	w14, #0xc0
1005e7228:     	b.hs	0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e722c:     	cmp	x1, #0x1
1005e7230:     	b.ne	0x1005e7408 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x228>
1005e7234:     	cmp	x3, #0x40
1005e7238:     	b.hs	0x1005e72dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0xfc>
1005e723c:     	ands	x14, x3, #0x38
1005e7240:     	b.eq	0x1005e7264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x84>
1005e7244:     	and	x13, x3, #0x38
1005e7248:     	neg	x13, x13
1005e724c:     	mov	x15, x12
1005e7250:     	ldr	x16, [x15], #0x8
1005e7254:     	tst	x16, #0x8080808080808080
1005e7258:     	b.ne	0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e725c:     	adds	x13, x13, #0x8
1005e7260:     	b.ne	0x1005e7250 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x70>
1005e7264:     	and	x13, x3, #0x7
1005e7268:     	cbz	x13, 0x1005e735c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e726c:     	add	x14, x12, x14
1005e7270:     	ldrsb	w15, [x14]
1005e7274:     	tbnz	w15, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7278:     	cmp	x13, #0x1
1005e727c:     	b.eq	0x1005e735c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e7280:     	ldrsb	w15, [x14, #0x1]
1005e7284:     	tbnz	w15, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7288:     	cmp	x13, #0x2
1005e728c:     	b.eq	0x1005e735c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e7290:     	ldrsb	w15, [x14, #0x2]
1005e7294:     	tbnz	w15, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7298:     	cmp	x13, #0x3
1005e729c:     	b.eq	0x1005e735c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e72a0:     	ldrsb	w15, [x14, #0x3]
1005e72a4:     	tbnz	w15, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e72a8:     	cmp	x13, #0x4
1005e72ac:     	b.eq	0x1005e735c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e72b0:     	ldrsb	w15, [x14, #0x4]
1005e72b4:     	tbnz	w15, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e72b8:     	cmp	x13, #0x5
1005e72bc:     	b.eq	0x1005e735c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e72c0:     	ldrsb	w15, [x14, #0x5]
1005e72c4:     	tbnz	w15, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e72c8:     	cmp	x13, #0x6
1005e72cc:     	b.eq	0x1005e735c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e72d0:     	ldrsb	w13, [x14, #0x6]
1005e72d4:     	tbz	w13, #0x1f, 0x1005e735c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e72d8:     	b	0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e72dc:     	and	x13, x3, #0x7fffffffffffffc0
1005e72e0:     	add	x13, x12, x13
1005e72e4:     	mov	x14, x12
1005e72e8:     	ldp	q0, q1, [x14]
1005e72ec:     	ldp	q2, q3, [x14, #0x20]
1005e72f0:     	orr.16b	v0, v1, v0
1005e72f4:     	orr.16b	v1, v2, v3
1005e72f8:     	orr.16b	v0, v0, v1
1005e72fc:     	umaxv.16b	b0, v0
1005e7300:     	fmov	w15, s0
1005e7304:     	tbnz	w15, #0x7, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7308:     	add	x14, x14, #0x40
1005e730c:     	cmp	x14, x13
1005e7310:     	b.ne	0x1005e72e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x108>
1005e7314:     	ands	x14, x3, #0x30
1005e7318:     	b.eq	0x1005e733c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x15c>
1005e731c:     	mov	x15, x14
1005e7320:     	mov	x16, x13
1005e7324:     	ldr	q0, [x16], #0x10
1005e7328:     	umaxv.16b	b0, v0
1005e732c:     	fmov	w17, s0
1005e7330:     	tbnz	w17, #0x7, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7334:     	subs	x15, x15, #0x10
1005e7338:     	b.ne	0x1005e7324 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x144>
1005e733c:     	and	x15, x3, #0xf
1005e7340:     	cbz	x15, 0x1005e735c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e7344:     	add	x13, x13, x14
1005e7348:     	ldrsb	w14, [x13]
1005e734c:     	tbnz	w14, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7350:     	add	x13, x13, #0x1
1005e7354:     	subs	x15, x15, #0x1
1005e7358:     	b.ne	0x1005e7348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x168>
1005e735c:     	add	x11, x12, x11
1005e7360:     	cmp	x10, #0x40
1005e7364:     	b.hs	0x1005e7430 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x250>
1005e7368:     	ands	x12, x10, #0x38
1005e736c:     	b.eq	0x1005e7390 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x1b0>
1005e7370:     	and	x13, x10, #0x38
1005e7374:     	neg	x13, x13
1005e7378:     	mov	x14, x11
1005e737c:     	ldr	x15, [x14], #0x8
1005e7380:     	tst	x15, #0x8080808080808080
1005e7384:     	b.ne	0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7388:     	adds	x13, x13, #0x8
1005e738c:     	b.ne	0x1005e737c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x19c>
1005e7390:     	and	x10, x10, #0x7
1005e7394:     	cbz	x10, 0x1005e74ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e7398:     	add	x11, x11, x12
1005e739c:     	ldrsb	w12, [x11]
1005e73a0:     	tbnz	w12, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e73a4:     	cmp	x10, #0x1
1005e73a8:     	b.eq	0x1005e74ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e73ac:     	ldrsb	w12, [x11, #0x1]
1005e73b0:     	tbnz	w12, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e73b4:     	cmp	x10, #0x2
1005e73b8:     	b.eq	0x1005e74ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e73bc:     	ldrsb	w12, [x11, #0x2]
1005e73c0:     	tbnz	w12, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e73c4:     	cmp	x10, #0x3
1005e73c8:     	b.eq	0x1005e74ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e73cc:     	ldrsb	w12, [x11, #0x3]
1005e73d0:     	tbnz	w12, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e73d4:     	cmp	x10, #0x4
1005e73d8:     	b.eq	0x1005e74ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e73dc:     	ldrsb	w12, [x11, #0x4]
1005e73e0:     	tbnz	w12, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e73e4:     	cmp	x10, #0x5
1005e73e8:     	b.eq	0x1005e74ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e73ec:     	ldrsb	w12, [x11, #0x5]
1005e73f0:     	tbnz	w12, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e73f4:     	cmp	x10, #0x6
1005e73f8:     	b.eq	0x1005e74ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e73fc:     	ldrsb	w10, [x11, #0x6]
1005e7400:     	tbz	w10, #0x1f, 0x1005e74ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e7404:     	b	0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7408:     	ldurb	w14, [x13, #-0x2]
1005e740c:     	cmp	w14, #0xdf
1005e7410:     	b.hi	0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7414:     	cmp	x1, #0x3
1005e7418:     	b.lo	0x1005e7234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x54>
1005e741c:     	ldurb	w13, [x13, #-0x3]
1005e7420:     	cmp	w13, #0xef
1005e7424:     	b.ls	0x1005e7234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x54>
1005e7428:     	mov	w0, #0x0                ; =0
1005e742c:     	ret
1005e7430:     	and	x12, x10, #0xffffffc0
1005e7434:     	add	x12, x11, x12
1005e7438:     	ldp	q0, q1, [x11]
1005e743c:     	ldp	q2, q3, [x11, #0x20]
1005e7440:     	orr.16b	v0, v1, v0
1005e7444:     	orr.16b	v1, v2, v3
1005e7448:     	orr.16b	v0, v0, v1
1005e744c:     	umaxv.16b	b0, v0
1005e7450:     	fmov	w13, s0
1005e7454:     	tbnz	w13, #0x7, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7458:     	add	x11, x11, #0x40
1005e745c:     	cmp	x11, x12
1005e7460:     	b.ne	0x1005e7438 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x258>
1005e7464:     	ands	x11, x10, #0x30
1005e7468:     	b.eq	0x1005e748c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2ac>
1005e746c:     	mov	x13, x11
1005e7470:     	mov	x14, x12
1005e7474:     	ldr	q0, [x14], #0x10
1005e7478:     	umaxv.16b	b0, v0
1005e747c:     	fmov	w15, s0
1005e7480:     	tbnz	w15, #0x7, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7484:     	subs	x13, x13, #0x10
1005e7488:     	b.ne	0x1005e7474 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x294>
1005e748c:     	and	x10, x10, #0xf
1005e7490:     	cbz	x10, 0x1005e74ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e7494:     	add	x11, x12, x11
1005e7498:     	ldrsb	w12, [x11]
1005e749c:     	tbnz	w12, #0x1f, 0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e74a0:     	add	x11, x11, #0x1
1005e74a4:     	subs	x10, x10, #0x1
1005e74a8:     	b.ne	0x1005e7498 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2b8>
1005e74ac:     	subs	w1, w9, w8
1005e74b0:     	cset	w0, hs
1005e74b4:     	ret
