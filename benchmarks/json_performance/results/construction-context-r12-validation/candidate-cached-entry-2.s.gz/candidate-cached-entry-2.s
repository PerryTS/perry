
benchmarks/json_performance/.work/construction-context-r12/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100500b38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>:
100500b38:     	stp	x28, x27, [sp, #-0x60]!
100500b3c:     	stp	x26, x25, [sp, #0x10]
100500b40:     	stp	x24, x23, [sp, #0x20]
100500b44:     	stp	x22, x21, [sp, #0x30]
100500b48:     	stp	x20, x19, [sp, #0x40]
100500b4c:     	stp	x29, x30, [sp, #0x50]
100500b50:     	add	x29, sp, #0x50
100500b54:     	sub	sp, sp, #0x1a0
100500b58:     	mov	x19, x1
100500b5c:     	mov	x21, x0
100500b60:     	bl	0x1004e7d90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template>
100500b64:     	cmp	x0, #0x1
100500b68:     	b.ne	0x100500b94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c>
100500b6c:     	mov	x23, x1
100500b70:     	mov	x0, x23
100500b74:     	add	sp, sp, #0x1a0
100500b78:     	ldp	x29, x30, [sp, #0x50]
100500b7c:     	ldp	x20, x19, [sp, #0x40]
100500b80:     	ldp	x22, x21, [sp, #0x30]
100500b84:     	ldp	x24, x23, [sp, #0x20]
100500b88:     	ldp	x26, x25, [sp, #0x10]
100500b8c:     	ldp	x28, x27, [sp], #0x60
100500b90:     	ret
100500b94:     	add	x24, x21, #0x14
100500b98:     	cmp	x19, #0x2
100500b9c:     	b.ne	0x100500bb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c>
100500ba0:     	ldrh	w8, [x24]
100500ba4:     	mov	w9, #0x7d7b             ; =32123
100500ba8:     	cmp	w8, w9
100500bac:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500bb0:     	b	0x100500c4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x114>
100500bb4:     	cmp	x19, #0x3
100500bb8:     	b.hs	0x100500c20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe8>
100500bbc:     	add	x0, sp, #0xa0
100500bc0:     	add	x1, x21, #0x14
100500bc4:     	mov	x2, x19
100500bc8:     	bl	0x1004f04fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object6decode>
100500bcc:     	ldr	w8, [sp, #0xa0]
100500bd0:     	tbz	w8, #0x0, 0x100500d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100500bd4:     	add	x8, sp, #0xa0
100500bd8:     	ldr	x9, [sp, #0x128]
100500bdc:     	str	x9, [sp, #0x90]
100500be0:     	ldur	q0, [x8, #0x48]
100500be4:     	ldur	q1, [x8, #0x58]
100500be8:     	stp	q0, q1, [sp, #0x50]
100500bec:     	ldur	q0, [x8, #0x68]
100500bf0:     	ldur	q1, [x8, #0x78]
100500bf4:     	stp	q0, q1, [sp, #0x70]
100500bf8:     	ldur	q0, [x8, #0x8]
100500bfc:     	ldur	q1, [x8, #0x18]
100500c00:     	stp	q0, q1, [sp, #0x10]
100500c04:     	ldur	q0, [x8, #0x28]
100500c08:     	ldur	q1, [x8, #0x38]
100500c0c:     	stp	q0, q1, [sp, #0x30]
100500c10:     	add	x0, sp, #0x10
100500c14:     	bl	0x1004f0cac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object8allocate>
100500c18:     	tbnz	w0, #0x0, 0x100500b6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x34>
100500c1c:     	b	0x100500d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100500c20:     	ldrb	w20, [x24]
100500c24:     	cmp	w20, #0x20
100500c28:     	b.hi	0x100500c6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x134>
100500c2c:     	mov	x8, #0x2600             ; =9728
100500c30:     	movk	x8, #0x1, lsl #32
100500c34:     	lsr	x8, x8, x20
100500c38:     	tbz	w8, #0x0, 0x100500c6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x134>
100500c3c:     	add	x0, x21, #0x14
100500c40:     	mov	x1, x19
100500c44:     	bl	0x1004e6f64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty19padded_empty_object>
100500c48:     	tbz	w0, #0x0, 0x100500c98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160>
100500c4c:     	add	sp, sp, #0x1a0
100500c50:     	ldp	x29, x30, [sp, #0x50]
100500c54:     	ldp	x20, x19, [sp, #0x40]
100500c58:     	ldp	x22, x21, [sp, #0x30]
100500c5c:     	ldp	x24, x23, [sp, #0x20]
100500c60:     	ldp	x26, x25, [sp, #0x10]
100500c64:     	ldp	x28, x27, [sp], #0x60
100500c68:     	b	0x1004e7040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100500c6c:     	cmp	w20, #0x7b
100500c70:     	b.ne	0x100500c98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x160>
100500c74:     	ldrb	w8, [x21, #0x15]
100500c78:     	cmp	w8, #0x20
100500c7c:     	b.hi	0x100500c90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x158>
100500c80:     	mov	x9, #0x2600             ; =9728
100500c84:     	movk	x9, #0x1, lsl #32
100500c88:     	lsr	x9, x9, x8
100500c8c:     	tbnz	w9, #0x0, 0x100500c3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100500c90:     	cmp	w8, #0x7d
100500c94:     	b.eq	0x100500c3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100500c98:     	cmp	x19, #0x41
100500c9c:     	b.hs	0x100500d24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1ec>
100500ca0:     	cmp	w20, #0x7b
100500ca4:     	ccmp	x19, #0x7, #0x0, eq
100500ca8:     	b.lo	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500cac:     	add	x8, x24, x19
100500cb0:     	ldurb	w8, [x8, #-0x1]
100500cb4:     	cmp	w8, #0x7d
100500cb8:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500cbc:     	ldrb	w8, [x21, #0x15]
100500cc0:     	cmp	w8, #0x22
100500cc4:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500cc8:     	sub	x9, x19, #0x1
100500ccc:     	mov	x22, x21
100500cd0:     	ldrb	w25, [x22, #0x16]!
100500cd4:     	cmp	w25, #0x22
100500cd8:     	b.ne	0x100500d68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x230>
100500cdc:     	mov	w23, #0x0               ; =0
100500ce0:     	mov	w28, #0x0               ; =0
100500ce4:     	mov	w27, #0x0               ; =0
100500ce8:     	mov	w26, #0x0               ; =0
100500cec:     	mov	x20, #0x0               ; =0
100500cf0:     	cmp	w25, #0x22
100500cf4:     	b.ne	0x100500d94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x25c>
100500cf8:     	add	x8, sp, #0xa0
100500cfc:     	mov	x0, x22
100500d00:     	mov	x1, x20
100500d04:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100500d08:     	sub	x11, x19, #0x1
100500d0c:     	ldr	w8, [sp, #0xa0]
100500d10:     	tbnz	w8, #0x0, 0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500d14:     	cmp	w25, #0x22
100500d18:     	b.ne	0x100500e38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x300>
100500d1c:     	mov	x8, #0x0                ; =0
100500d20:     	b	0x100500e6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100500d24:     	adrp	x8, 0x100f75000 <__MergedGlobals+0xb8>
100500d28:     	add	x8, x8, #0x2d8
100500d2c:     	ldapr	x8, [x8]
100500d30:     	cbnz	x8, 0x100500f04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3cc>
100500d34:     	adrp	x8, 0x100f75000 <__MergedGlobals+0xb8>
100500d38:     	ldrb	w8, [x8, #0x2e0]
100500d3c:     	adrp	x12, 0x100f76000 <__MergedGlobals.1914+0xc8>
100500d40:     	adrp	x27, 0x100f74000 <_perry_global_rotating_worker_ts__1>
100500d44:     	cbz	w8, 0x100500f1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3e4>
100500d48:     	cmp	w8, #0x1
100500d4c:     	b.ne	0x100500f58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100500d50:     	mov	w28, #0x1               ; =1
100500d54:     	mov	w8, #0x1000000          ; =16777216
100500d58:     	mov	w22, #0x1               ; =1
100500d5c:     	cmp	x19, x8
100500d60:     	b.hi	0x100500f5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x424>
100500d64:     	b	0x100501040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x508>
100500d68:     	cmp	x9, #0x3
100500d6c:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500d70:     	ldrb	w8, [x21, #0x17]
100500d74:     	cmp	w8, #0x22
100500d78:     	b.ne	0x100500e0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x2d4>
100500d7c:     	mov	w28, #0x0               ; =0
100500d80:     	mov	w27, #0x0               ; =0
100500d84:     	mov	w26, #0x0               ; =0
100500d88:     	mov	w23, #0x1               ; =1
100500d8c:     	mov	w20, #0x1               ; =1
100500d90:     	b	0x100500cf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100500d94:     	ldrb	w8, [x22]
100500d98:     	cmp	w8, #0x20
100500d9c:     	b.lo	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500da0:     	cmp	w8, #0x5c
100500da4:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500da8:     	tbnz	w23, #0x0, 0x100500cf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100500dac:     	ldrb	w8, [x21, #0x17]
100500db0:     	cmp	w8, #0x20
100500db4:     	b.lo	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500db8:     	cmp	w8, #0x5c
100500dbc:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500dc0:     	tbnz	w28, #0x0, 0x100500cf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100500dc4:     	ldrb	w8, [x21, #0x18]
100500dc8:     	cmp	w8, #0x20
100500dcc:     	b.lo	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500dd0:     	cmp	w8, #0x5c
100500dd4:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500dd8:     	tbnz	w27, #0x0, 0x100500cf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100500ddc:     	ldrb	w8, [x21, #0x19]
100500de0:     	cmp	w8, #0x20
100500de4:     	b.lo	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500de8:     	cmp	w8, #0x5c
100500dec:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500df0:     	tbnz	w26, #0x0, 0x100500cf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100500df4:     	ldrb	w8, [x21, #0x1a]
100500df8:     	cmp	w8, #0x20
100500dfc:     	b.lo	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500e00:     	cmp	w8, #0x5c
100500e04:     	b.ne	0x100500cf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1c0>
100500e08:     	b	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500e0c:     	cmp	x9, #0x4
100500e10:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500e14:     	ldrb	w8, [x21, #0x18]
100500e18:     	cmp	w8, #0x22
100500e1c:     	b.ne	0x100500ed8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3a0>
100500e20:     	mov	w23, #0x0               ; =0
100500e24:     	mov	w27, #0x0               ; =0
100500e28:     	mov	w26, #0x0               ; =0
100500e2c:     	mov	w28, #0x1               ; =1
100500e30:     	mov	w20, #0x2               ; =2
100500e34:     	b	0x100500cf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100500e38:     	ldrb	w8, [x22]
100500e3c:     	tbnz	w23, #0x0, 0x100500e6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100500e40:     	ldrb	w9, [x21, #0x17]
100500e44:     	orr	x8, x8, x9, lsl #8
100500e48:     	tbnz	w28, #0x0, 0x100500e6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100500e4c:     	ldrb	w9, [x21, #0x18]
100500e50:     	orr	x8, x8, x9, lsl #16
100500e54:     	tbnz	w27, #0x0, 0x100500e6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100500e58:     	ldrb	w9, [x21, #0x19]
100500e5c:     	orr	x8, x8, x9, lsl #24
100500e60:     	tbnz	w26, #0x0, 0x100500e6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x334>
100500e64:     	ldrb	w9, [x21, #0x1a]
100500e68:     	orr	x8, x8, x9, lsl #32
100500e6c:     	add	x9, x20, #0x3
100500e70:     	cmp	x9, x19
100500e74:     	b.hs	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500e78:     	ldrb	w9, [x24, x9]
100500e7c:     	cmp	w9, #0x3a
100500e80:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500e84:     	add	x10, x20, #0x4
100500e88:     	subs	x9, x11, x10
100500e8c:     	b.lo	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500e90:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500e94:     	orr	x25, x8, x20, lsl #40
100500e98:     	mov	x26, #0x7ff9000000000000 ; =9221401712017801216
100500e9c:     	add	x8, x24, x10
100500ea0:     	mov	x10, #0x2600            ; =9728
100500ea4:     	movk	x10, #0x1, lsl #32
100500ea8:     	mov	x11, x9
100500eac:     	mov	x12, x8
100500eb0:     	b	0x100500ec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x388>
100500eb4:     	add	x12, x12, #0x1
100500eb8:     	subs	x11, x11, #0x1
100500ebc:     	b.eq	0x100501e28 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f0>
100500ec0:     	ldrb	w13, [x12]
100500ec4:     	cmp	w13, #0x20
100500ec8:     	b.hi	0x100500eb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x37c>
100500ecc:     	lsr	x13, x10, x13
100500ed0:     	tbz	w13, #0x0, 0x100500eb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x37c>
100500ed4:     	b	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500ed8:     	cmp	x9, #0x5
100500edc:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100500ee0:     	ldrb	w8, [x21, #0x19]
100500ee4:     	cmp	w8, #0x22
100500ee8:     	b.ne	0x100501d74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x123c>
100500eec:     	mov	w23, #0x0               ; =0
100500ef0:     	mov	w28, #0x0               ; =0
100500ef4:     	mov	w26, #0x0               ; =0
100500ef8:     	mov	w27, #0x1               ; =1
100500efc:     	mov	w20, #0x3               ; =3
100500f00:     	b	0x100500cf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100500f04:     	bl	0x100b0f688 <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockNtNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api8TapeModeE10initializeNCINvB2_11get_or_initNCNvBV_18tape_mode_from_env0E0zEBZ_>
100500f08:     	adrp	x8, 0x100f75000 <__MergedGlobals+0xb8>
100500f0c:     	ldrb	w8, [x8, #0x2e0]
100500f10:     	adrp	x12, 0x100f76000 <__MergedGlobals.1914+0xc8>
100500f14:     	adrp	x27, 0x100f74000 <_perry_global_rotating_worker_ts__1>
100500f18:     	cbnz	w8, 0x100500d48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x210>
100500f1c:     	sub	x8, x19, #0x400
100500f20:     	mov	w9, #0xfffc00           ; =16776192
100500f24:     	cmp	x8, x9
100500f28:     	b.hi	0x100500f58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100500f2c:     	mov	x8, #0x0                ; =0
100500f30:     	mov	x9, #0x2600             ; =9728
100500f34:     	movk	x9, #0x1, lsl #32
100500f38:     	ldrb	w10, [x24, x8]
100500f3c:     	cmp	w10, #0x20
100500f40:     	b.hi	0x100501474 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x93c>
100500f44:     	lsr	x11, x9, x10
100500f48:     	tbz	w11, #0x0, 0x100501474 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x93c>
100500f4c:     	add	x8, x8, #0x1
100500f50:     	cmp	x19, x8
100500f54:     	b.ne	0x100500f38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x400>
100500f58:     	mov	w22, #0x0               ; =0
100500f5c:     	ldr	w20, [x12, #0x560]
100500f60:     	cmp	w20, #0x300
100500f64:     	b.hs	0x10050144c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x914>
100500f68:     	ldr	x8, [x27, #0x48]
100500f6c:     	cmn	x8, #0x1
100500f70:     	b.eq	0x10050143c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x904>
100500f74:     	mrs	x9, TPIDRRO_EL0
100500f78:     	and	x9, x9, #0xfffffffffffffff8
100500f7c:     	ldr	x0, [x9, x8, lsl #3]
100500f80:     	cbz	x0, 0x10050143c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x904>
100500f84:     	add	x8, x0, x20, lsl #3
100500f88:     	ldr	x0, [x8, #0x1e8]
100500f8c:     	cbz	x0, 0x10050144c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x914>
100500f90:     	ldr	x8, [x0]
100500f94:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100500f98:     	cmp	x8, x9
100500f9c:     	b.hs	0x100501468 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x930>
100500fa0:     	ldrb	w8, [x0, #0x24]
100500fa4:     	cmp	w8, #0x2
100500fa8:     	b.eq	0x100500fb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x480>
100500fac:     	ldr	x9, [x0, #0x8]
100500fb0:     	cmp	x9, x21
100500fb4:     	b.eq	0x100501020 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4e8>
100500fb8:     	cmp	x19, #0x3e9
100500fbc:     	b.lo	0x10050103c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100500fc0:     	mov	x8, #0x0                ; =0
100500fc4:     	mov	x9, #0x2600             ; =9728
100500fc8:     	movk	x9, #0x1, lsl #32
100500fcc:     	add	x10, x21, x8
100500fd0:     	ldrb	w10, [x10, #0x14]
100500fd4:     	cmp	w10, #0x20
100500fd8:     	b.hi	0x100500ff4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4bc>
100500fdc:     	lsr	x11, x9, x10
100500fe0:     	tbz	w11, #0x0, 0x100500ff4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4bc>
100500fe4:     	add	x8, x8, #0x1
100500fe8:     	cmp	x19, x8
100500fec:     	b.ne	0x100500fcc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x494>
100500ff0:     	b	0x10050103c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100500ff4:     	cmp	w10, #0x5b
100500ff8:     	b.eq	0x100501004 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4cc>
100500ffc:     	cmp	w10, #0x7b
100501000:     	b.ne	0x10050103c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100501004:     	add	x0, x21, #0x14
100501008:     	mov	x1, x19
10050100c:     	mov	w2, #0x3e8              ; =1000
100501010:     	bl	0x1006be3d4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
100501014:     	cbz	w0, 0x10050103c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x504>
100501018:     	mov	x0, x21
10050101c:     	b	0x100501d34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11fc>
100501020:     	ldr	w9, [x0, #0x18]
100501024:     	cmp	x19, x9
100501028:     	cset	w9, eq
10050102c:     	and	w8, w9, w8
100501030:     	cmp	x19, #0x3e9
100501034:     	csinc	w8, w8, wzr, hs
100501038:     	tbz	w8, #0x0, 0x100500fc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x488>
10050103c:     	mov	w28, #0x0               ; =0
100501040:     	adrp	x0, 0x100f7b000 <_theap_main+0x1f80>
100501044:     	add	x0, x0, #0xce8
100501048:     	ldr	x8, [x0]
10050104c:     	blr	x8
100501050:     	mov	x20, x0
100501054:     	ldrb	w8, [x0, #0x20]
100501058:     	cbnz	w8, 0x100501c8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1154>
10050105c:     	ldr	x8, [x20]
100501060:     	cbnz	x8, 0x100501d08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11d0>
100501064:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
100501068:     	bfxil	x23, x21, #0, #48
10050106c:     	mov	x8, #-0x1               ; =-1
100501070:     	str	x8, [x20]
100501074:     	ldr	x21, [x20, #0x18]
100501078:     	ldr	x8, [x20, #0x8]
10050107c:     	cmp	x21, x8
100501080:     	b.eq	0x1005013fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8c4>
100501084:     	ldr	x8, [x20, #0x10]
100501088:     	str	x23, [x8, x21, lsl #3]
10050108c:     	add	x8, x21, #0x1
100501090:     	str	x8, [x20, #0x18]
100501094:     	ldr	x8, [x20]
100501098:     	add	x8, x8, #0x1
10050109c:     	str	x8, [x20]
1005010a0:     	adrp	x24, 0x100f74000 <_perry_global_rotating_worker_ts__1>
1005010a4:     	ldr	w23, [x24, #0x948]
1005010a8:     	cmp	w23, #0x300
1005010ac:     	b.hs	0x100501418 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8e0>
1005010b0:     	ldr	x8, [x27, #0x48]
1005010b4:     	cmn	x8, #0x1
1005010b8:     	b.eq	0x100501408 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d0>
1005010bc:     	mrs	x9, TPIDRRO_EL0
1005010c0:     	and	x9, x9, #0xfffffffffffffff8
1005010c4:     	ldr	x0, [x9, x8, lsl #3]
1005010c8:     	cbz	x0, 0x100501408 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8d0>
1005010cc:     	add	x8, x0, x23, lsl #3
1005010d0:     	ldr	x0, [x8, #0x1e8]
1005010d4:     	cbz	x0, 0x100501418 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8e0>
1005010d8:     	ldrb	w8, [x0]
1005010dc:     	cbnz	w8, 0x10050142c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8f4>
1005010e0:     	adrp	x26, 0x100f76000 <__MergedGlobals.1914+0xc8>
1005010e4:     	tbz	w22, #0x0, 0x1005017ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc74>
1005010e8:     	ldrb	w8, [x20, #0x20]
1005010ec:     	cbnz	w8, 0x100501d44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x120c>
1005010f0:     	ldr	x8, [x20]
1005010f4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005010f8:     	cmp	x8, x9
1005010fc:     	b.hs	0x100501e88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1350>
100501100:     	add	x9, x8, #0x1
100501104:     	str	x9, [x20]
100501108:     	ldr	x9, [x20, #0x18]
10050110c:     	cmp	x21, x9
100501110:     	b.hs	0x100501124 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5ec>
100501114:     	ldr	x9, [x20, #0x10]
100501118:     	ldr	x9, [x9, x21, lsl #3]
10050111c:     	and	x23, x9, #0xffffffffffff
100501120:     	b	0x100501128 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5f0>
100501124:     	mov	w23, #0x1               ; =1
100501128:     	str	x8, [x20]
10050112c:     	adrp	x0, 0x100f7c000 <__RNvNCNKNvNtCs3gRpqoBkMHm_13perry_runtime7process29PROCESS_FINALIZATION_EXIT_RAN0s_023___RUST_STD_INTERNAL_VAL>
100501130:     	add	x0, x0, #0x168
100501134:     	ldr	x8, [x0]
100501138:     	blr	x8
10050113c:     	mov	x22, x0
100501140:     	ldrb	w8, [x0, #0x30]
100501144:     	cmp	w8, #0x1
100501148:     	b.ne	0x100501d14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11dc>
10050114c:     	ldr	x8, [x22]
100501150:     	mov	x10, #-0x1              ; =-1
100501154:     	mov	x9, x22
100501158:     	str	x10, [x9], #0x8
10050115c:     	cmn	x8, #0x1
100501160:     	b.eq	0x100501180 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x648>
100501164:     	add	x10, sp, #0xa0
100501168:     	ldp	q0, q1, [x9]
10050116c:     	ldr	x9, [x9, #0x20]
100501170:     	stur	x9, [x10, #0x28]
100501174:     	stur	q1, [x10, #0x18]
100501178:     	stur	q0, [x10, #0x8]
10050117c:     	b	0x100501194 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x65c>
100501180:     	mov	x8, #0x0                ; =0
100501184:     	mov	w9, #0x4                ; =4
100501188:     	stp	x9, xzr, [sp, #0xa8]
10050118c:     	stp	xzr, x9, [sp, #0xb8]
100501190:     	str	xzr, [sp, #0xc8]
100501194:     	str	x8, [sp, #0xa0]
100501198:     	stur	xzr, [x29, #-0x78]
10050119c:     	add	x8, sp, #0xa0
1005011a0:     	add	x0, x23, #0x14
1005011a4:     	add	x2, sp, #0xa0
1005011a8:     	add	x3, x8, #0x18
1005011ac:     	sub	x4, x29, #0x78
1005011b0:     	mov	x1, x19
1005011b4:     	bl	0x10014d1c0 <__RINvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15build_tape_intoKb1_EB4_>
1005011b8:     	tbz	w0, #0x0, 0x1005012fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c4>
1005011bc:     	ldur	x23, [x29, #-0x78]
1005011c0:     	ldr	w24, [x24, #0x948]
1005011c4:     	cmp	w24, #0x300
1005011c8:     	b.hs	0x100501b74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x103c>
1005011cc:     	ldr	x8, [x27, #0x48]
1005011d0:     	cmn	x8, #0x1
1005011d4:     	b.eq	0x100501b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x102c>
1005011d8:     	mrs	x9, TPIDRRO_EL0
1005011dc:     	and	x9, x9, #0xfffffffffffffff8
1005011e0:     	ldr	x0, [x9, x8, lsl #3]
1005011e4:     	cbz	x0, 0x100501b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x102c>
1005011e8:     	add	x8, x0, x24, lsl #3
1005011ec:     	ldr	x0, [x8, #0x1e8]
1005011f0:     	cbz	x0, 0x100501b74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x103c>
1005011f4:     	ldrb	w8, [x0]
1005011f8:     	cbnz	w8, 0x100501b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1050>
1005011fc:     	ldr	w24, [x26, #0x590]
100501200:     	cmp	w24, #0x300
100501204:     	b.hs	0x100501bac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1074>
100501208:     	ldr	x8, [x27, #0x48]
10050120c:     	cmn	x8, #0x1
100501210:     	b.eq	0x100501b9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1064>
100501214:     	mrs	x9, TPIDRRO_EL0
100501218:     	and	x9, x9, #0xfffffffffffffff8
10050121c:     	ldr	x0, [x9, x8, lsl #3]
100501220:     	cbz	x0, 0x100501b9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1064>
100501224:     	add	x8, x0, x24, lsl #3
100501228:     	ldr	x0, [x8, #0x1e8]
10050122c:     	cbz	x0, 0x100501bac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1074>
100501230:     	bl	0x100219cb0 <__RNCNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary0B7_>
100501234:     	bl	0x100455200 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
100501238:     	mov	x0, x19
10050123c:     	bl	0x10022ec6c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
100501240:     	mov	x24, x0
100501244:     	mov	x25, x1
100501248:     	bl	0x100455014 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
10050124c:     	ldrb	w8, [x20, #0x20]
100501250:     	cbnz	w8, 0x100501dd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1298>
100501254:     	ldr	x8, [x20]
100501258:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10050125c:     	cmp	x8, x9
100501260:     	b.hs	0x100501e88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1350>
100501264:     	add	x9, x8, #0x1
100501268:     	str	x9, [x20]
10050126c:     	ldr	x9, [x20, #0x18]
100501270:     	cmp	x21, x9
100501274:     	b.hs	0x100501394 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x85c>
100501278:     	ldr	x9, [x20, #0x10]
10050127c:     	ldr	x9, [x9, x21, lsl #3]
100501280:     	and	x2, x9, #0xffffffffffff
100501284:     	stp	x25, x24, [sp]
100501288:     	str	x8, [x20]
10050128c:     	add	x26, x2, #0x14
100501290:     	cmp	x23, #0x3e8
100501294:     	b.hi	0x1005013ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x874>
100501298:     	ldp	x24, x25, [sp, #0xa8]
10050129c:     	cbz	x25, 0x1005013c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x890>
1005012a0:     	ldrb	w8, [x24, #0x8]
1005012a4:     	cmp	w8, #0x3
1005012a8:     	b.ne	0x1005013c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x890>
1005012ac:     	ldr	w8, [x24, #0x4]
1005012b0:     	cmp	w8, #0x2
1005012b4:     	b.lo	0x10050149c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x964>
1005012b8:     	mov	w1, #0x0                ; =0
1005012bc:     	mov	w0, #0x1                ; =1
1005012c0:     	mov	w9, #0xc                ; =12
1005012c4:     	b	0x1005012d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7a0>
1005012c8:     	add	x0, x0, #0x1
1005012cc:     	add	w1, w1, #0x1
1005012d0:     	cmp	x0, x8
1005012d4:     	b.hs	0x1005014a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x968>
1005012d8:     	cmp	x0, x25
1005012dc:     	b.hs	0x100501f84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x144c>
1005012e0:     	madd	x10, x0, x9, x24
1005012e4:     	ldrb	w11, [x10, #0x8]
1005012e8:     	orr	w11, w11, #0x2
1005012ec:     	cmp	w11, #0x3
1005012f0:     	b.ne	0x1005012c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x790>
1005012f4:     	ldr	w0, [x10, #0x4]
1005012f8:     	b	0x1005012c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x790>
1005012fc:     	str	xzr, [sp, #0xb0]
100501300:     	str	xzr, [sp, #0xc8]
100501304:     	ldr	x8, [sp, #0xa0]
100501308:     	add	x9, x8, x8, lsl #1
10050130c:     	lsl	x9, x9, #2
100501310:     	cmp	x9, #0x100, lsl #12     ; =0x100000
100501314:     	b.ls	0x100501330 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7f8>
100501318:     	cbz	x8, 0x100501324 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7ec>
10050131c:     	ldr	x0, [sp, #0xa8]
100501320:     	bl	0x100b55880 <_mi_free>
100501324:     	mov	w8, #0x4                ; =4
100501328:     	stp	xzr, x8, [sp, #0xa0]
10050132c:     	str	xzr, [sp, #0xb0]
100501330:     	ldr	x8, [sp, #0xb8]
100501334:     	lsl	x9, x8, #2
100501338:     	cmp	x9, #0x10, lsl #12      ; =0x10000
10050133c:     	b.ls	0x100501358 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x820>
100501340:     	cbz	x8, 0x10050134c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x814>
100501344:     	ldr	x0, [sp, #0xc0]
100501348:     	bl	0x100b55880 <_mi_free>
10050134c:     	mov	w8, #0x4                ; =4
100501350:     	stp	xzr, x8, [sp, #0xb8]
100501354:     	str	xzr, [sp, #0xc8]
100501358:     	ldp	x8, x0, [x22]
10050135c:     	ldp	x24, x23, [x22, #0x18]
100501360:     	ldp	q1, q0, [sp, #0xb0]
100501364:     	ldr	q2, [sp, #0xa0]
100501368:     	stp	q2, q1, [x22]
10050136c:     	str	q0, [x22, #0x20]
100501370:     	cmn	x8, #0x1
100501374:     	b.eq	0x10050138c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x854>
100501378:     	cbz	x8, 0x100501380 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x848>
10050137c:     	bl	0x100b55880 <_mi_free>
100501380:     	cbz	x24, 0x10050138c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x854>
100501384:     	mov	x0, x23
100501388:     	bl	0x100b55880 <_mi_free>
10050138c:     	ldrb	w8, [x20, #0x20]
100501390:     	b	0x1005016cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb94>
100501394:     	mov	w2, #0x1                ; =1
100501398:     	stp	x25, x24, [sp]
10050139c:     	str	x8, [x20]
1005013a0:     	add	x26, x2, #0x14
1005013a4:     	cmp	x23, #0x3e8
1005013a8:     	b.ls	0x100501298 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x760>
1005013ac:     	ldp	x0, x1, [sp, #0xa8]
1005013b0:     	mov	x2, x26
1005013b4:     	mov	x3, x19
1005013b8:     	bl	0x100681e94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape9iterative21materialize_iterative>
1005013bc:     	tbz	w0, #0x0, 0x1005013f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8bc>
1005013c0:     	mov	x25, x1
1005013c4:     	b	0x1005014f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9b8>
1005013c8:     	bl	0x100288018 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
1005013cc:     	stp	x0, xzr, [x29, #-0x70]
1005013d0:     	stp	x24, x25, [sp, #0x10]
1005013d4:     	stp	x26, x19, [sp, #0x20]
1005013d8:     	add	x0, sp, #0x10
1005013dc:     	sub	x1, x29, #0x68
1005013e0:     	bl	0x100373120 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24materialize_value_source>
1005013e4:     	mov	x25, x0
1005013e8:     	sub	x0, x29, #0x70
1005013ec:     	bl	0x1001633fc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1005013f0:     	b	0x1005014f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9b8>
1005013f4:     	mov	w25, #0x0               ; =0
1005013f8:     	b	0x100501538 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa00>
1005013fc:     	add	x0, x20, #0x8
100501400:     	bl	0x100b3252c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100501404:     	b	0x100501084 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x54c>
100501408:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10050140c:     	add	x8, x0, x23, lsl #3
100501410:     	ldr	x0, [x8, #0x1e8]
100501414:     	cbnz	x0, 0x1005010d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5a0>
100501418:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
10050141c:     	add	x0, x0, #0xca8
100501420:     	bl	0x100b334a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100501424:     	ldrb	w8, [x0]
100501428:     	cbz	w8, 0x1005010e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5a8>
10050142c:     	bl	0x100b3abdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
100501430:     	adrp	x26, 0x100f76000 <__MergedGlobals.1914+0xc8>
100501434:     	tbnz	w22, #0x0, 0x1005010e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5b0>
100501438:     	b	0x1005017ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc74>
10050143c:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501440:     	add	x8, x0, x20, lsl #3
100501444:     	ldr	x0, [x8, #0x1e8]
100501448:     	cbnz	x0, 0x100500f90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x458>
10050144c:     	adrp	x0, 0x100f03000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
100501450:     	add	x0, x0, #0xfa0
100501454:     	bl	0x100b3345c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100501458:     	ldr	x8, [x0]
10050145c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501460:     	cmp	x8, x9
100501464:     	b.lo	0x100500fa0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x468>
100501468:     	adrp	x0, 0x100ef1000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10050146c:     	add	x0, x0, #0xd10
100501470:     	bl	0x100b08fdc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100501474:     	cmp	w10, #0x5b
100501478:     	cset	w22, eq
10050147c:     	mov	w8, #0x1000000          ; =16777216
100501480:     	cmp	x19, x8
100501484:     	mov	w8, #0x5b               ; =91
100501488:     	ccmp	w10, w8, #0x0, ls
10050148c:     	b.ne	0x100500f5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x424>
100501490:     	mov	w28, #0x1               ; =1
100501494:     	mov	w22, #0x1               ; =1
100501498:     	b	0x100501040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x508>
10050149c:     	mov	w1, #0x0                ; =0
1005014a0:     	ldr	x8, [sp, #0xa0]
1005014a4:     	add	x8, x8, x8, lsl #1
1005014a8:     	lsl	x8, x8, #2
1005014ac:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1005014b0:     	b.ls	0x1005014d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x99c>
1005014b4:     	ldr	q0, [sp, #0xa0]
1005014b8:     	str	q0, [sp, #0x10]
1005014bc:     	ldr	x8, [sp, #0xb0]
1005014c0:     	str	x8, [sp, #0x20]
1005014c4:     	mov	w8, #0x4                ; =4
1005014c8:     	stp	xzr, x8, [sp, #0xa0]
1005014cc:     	str	xzr, [sp, #0xb0]
1005014d0:     	b	0x1005014e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9a8>
1005014d4:     	stp	x24, x25, [sp, #0x18]
1005014d8:     	mov	x8, #-0x1               ; =-1
1005014dc:     	str	x8, [sp, #0x10]
1005014e0:     	add	x0, sp, #0x10
1005014e4:     	bl	0x100372270 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24alloc_lazy_array_backing>
1005014e8:     	mov	x25, #0x7ffd000000000000 ; =9222527611924643840
1005014ec:     	bfxil	x25, x0, #0, #48
1005014f0:     	ldrb	w8, [x20, #0x20]
1005014f4:     	cbnz	w8, 0x100501e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12c8>
1005014f8:     	ldr	x8, [x20]
1005014fc:     	cbnz	x8, 0x100501d08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11d0>
100501500:     	mov	x8, #-0x1               ; =-1
100501504:     	str	x8, [x20]
100501508:     	ldr	x26, [x20, #0x18]
10050150c:     	ldr	x8, [x20, #0x8]
100501510:     	cmp	x26, x8
100501514:     	b.eq	0x100501c30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10f8>
100501518:     	ldr	x8, [x20, #0x10]
10050151c:     	str	x25, [x8, x26, lsl #3]
100501520:     	add	x8, x26, #0x1
100501524:     	str	x8, [x20, #0x18]
100501528:     	ldr	x8, [x20]
10050152c:     	add	x8, x8, #0x1
100501530:     	str	x8, [x20]
100501534:     	mov	w25, #0x1               ; =1
100501538:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
10050153c:     	ldr	w24, [x8, #0x308]
100501540:     	cmp	w24, #0x300
100501544:     	b.hs	0x100501bcc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1094>
100501548:     	ldr	x8, [x27, #0x48]
10050154c:     	cmn	x8, #0x1
100501550:     	b.eq	0x100501bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1084>
100501554:     	mrs	x9, TPIDRRO_EL0
100501558:     	and	x9, x9, #0xfffffffffffffff8
10050155c:     	ldr	x0, [x9, x8, lsl #3]
100501560:     	cbz	x0, 0x100501bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1084>
100501564:     	add	x8, x0, x24, lsl #3
100501568:     	ldr	x0, [x8, #0x1e8]
10050156c:     	cbz	x0, 0x100501bcc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1094>
100501570:     	ldrb	w8, [x0]
100501574:     	and	w8, w8, #0xfffffffd
100501578:     	strb	w8, [x0]
10050157c:     	mov	w0, #0x0                ; =0
100501580:     	bl	0x100458940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
100501584:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
100501588:     	ldr	w24, [x8, #0x590]
10050158c:     	cmp	w24, #0x300
100501590:     	b.hs	0x100501bec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10b4>
100501594:     	ldr	x8, [x27, #0x48]
100501598:     	cmn	x8, #0x1
10050159c:     	b.eq	0x100501bdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10a4>
1005015a0:     	mrs	x9, TPIDRRO_EL0
1005015a4:     	and	x9, x9, #0xfffffffffffffff8
1005015a8:     	ldr	x0, [x9, x8, lsl #3]
1005015ac:     	cbz	x0, 0x100501bdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10a4>
1005015b0:     	add	x8, x0, x24, lsl #3
1005015b4:     	ldr	x0, [x8, #0x1e8]
1005015b8:     	cbz	x0, 0x100501bec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10b4>
1005015bc:     	ldr	x8, [x0]
1005015c0:     	lsr	x8, x8, #25
1005015c4:     	cbz	x8, 0x100501c04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10cc>
1005015c8:     	bl	0x10045a8f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005015cc:     	cmp	x23, #0x3e8
1005015d0:     	b.hi	0x100501c0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10d4>
1005015d4:     	ldp	x1, x0, [sp]
1005015d8:     	bl	0x10022edb8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005015dc:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1005015e0:     	ldr	x8, [x8, #0x758]
1005015e4:     	cbnz	x8, 0x100501c24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10ec>
1005015e8:     	tbz	w25, #0x0, 0x100501630 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xaf8>
1005015ec:     	ldrb	w8, [x20, #0x20]
1005015f0:     	cbnz	w8, 0x100501e5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1324>
1005015f4:     	ldr	x8, [x20]
1005015f8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005015fc:     	cmp	x8, x9
100501600:     	b.hs	0x100501e88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1350>
100501604:     	add	x9, x8, #0x1
100501608:     	str	x9, [x20]
10050160c:     	ldr	x9, [x20, #0x18]
100501610:     	cmp	x26, x9
100501614:     	b.hs	0x100501624 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xaec>
100501618:     	ldr	x9, [x20, #0x10]
10050161c:     	ldr	x23, [x9, x26, lsl #3]
100501620:     	b	0x10050162c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xaf4>
100501624:     	mov	x23, #0x1               ; =1
100501628:     	movk	x23, #0x7ffc, lsl #48
10050162c:     	str	x8, [x20]
100501630:     	str	xzr, [sp, #0xb0]
100501634:     	str	xzr, [sp, #0xc8]
100501638:     	ldr	x8, [sp, #0xa0]
10050163c:     	add	x9, x8, x8, lsl #1
100501640:     	lsl	x9, x9, #2
100501644:     	cmp	x9, #0x100, lsl #12     ; =0x100000
100501648:     	b.ls	0x100501664 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb2c>
10050164c:     	cbz	x8, 0x100501658 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb20>
100501650:     	ldr	x0, [sp, #0xa8]
100501654:     	bl	0x100b55880 <_mi_free>
100501658:     	mov	w8, #0x4                ; =4
10050165c:     	stp	xzr, x8, [sp, #0xa0]
100501660:     	str	xzr, [sp, #0xb0]
100501664:     	ldr	x8, [sp, #0xb8]
100501668:     	lsl	x9, x8, #2
10050166c:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100501670:     	b.ls	0x10050168c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb54>
100501674:     	cbz	x8, 0x100501680 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb48>
100501678:     	ldr	x0, [sp, #0xc0]
10050167c:     	bl	0x100b55880 <_mi_free>
100501680:     	mov	w8, #0x4                ; =4
100501684:     	stp	xzr, x8, [sp, #0xb8]
100501688:     	str	xzr, [sp, #0xc8]
10050168c:     	ldp	x8, x0, [x22]
100501690:     	ldp	x26, x24, [x22, #0x18]
100501694:     	ldp	q1, q0, [sp, #0xb0]
100501698:     	ldr	q2, [sp, #0xa0]
10050169c:     	stp	q2, q1, [x22]
1005016a0:     	str	q0, [x22, #0x20]
1005016a4:     	cmn	x8, #0x1
1005016a8:     	b.eq	0x10050175c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc24>
1005016ac:     	cbz	x8, 0x1005016b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb7c>
1005016b0:     	bl	0x100b55880 <_mi_free>
1005016b4:     	cbz	x26, 0x10050175c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc24>
1005016b8:     	mov	x0, x24
1005016bc:     	bl	0x100b55880 <_mi_free>
1005016c0:     	ldrb	w8, [x20, #0x20]
1005016c4:     	adrp	x26, 0x100f76000 <__MergedGlobals.1914+0xc8>
1005016c8:     	tbnz	w25, #0x0, 0x100501768 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc30>
1005016cc:     	cbnz	w8, 0x100501da0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1268>
1005016d0:     	ldr	x8, [x20]
1005016d4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005016d8:     	cmp	x8, x9
1005016dc:     	b.hs	0x100501e88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1350>
1005016e0:     	add	x9, x8, #0x1
1005016e4:     	str	x9, [x20]
1005016e8:     	ldr	x9, [x20, #0x18]
1005016ec:     	cmp	x21, x9
1005016f0:     	b.hs	0x100501714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbdc>
1005016f4:     	ldr	x9, [x20, #0x10]
1005016f8:     	ldr	x9, [x9, x21, lsl #3]
1005016fc:     	and	x22, x9, #0xffffffffffff
100501700:     	str	x8, [x20]
100501704:     	cmp	x19, #0x3e8
100501708:     	csel	w8, wzr, w28, ls
10050170c:     	cbnz	w8, 0x100501728 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbf0>
100501710:     	b	0x1005017ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc74>
100501714:     	mov	w22, #0x1               ; =1
100501718:     	str	x8, [x20]
10050171c:     	cmp	x19, #0x3e8
100501720:     	csel	w8, wzr, w28, ls
100501724:     	cbz	w8, 0x1005017ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc74>
100501728:     	mov	x8, #0x0                ; =0
10050172c:     	mov	x9, #0x2600             ; =9728
100501730:     	movk	x9, #0x1, lsl #32
100501734:     	add	x10, x22, x8
100501738:     	ldrb	w10, [x10, #0x14]
10050173c:     	cmp	w10, #0x20
100501740:     	b.hi	0x100501788 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc50>
100501744:     	lsr	x11, x9, x10
100501748:     	tbz	w11, #0x0, 0x100501788 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc50>
10050174c:     	add	x8, x8, #0x1
100501750:     	cmp	x19, x8
100501754:     	b.ne	0x100501734 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbfc>
100501758:     	b	0x1005017ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc74>
10050175c:     	ldrb	w8, [x20, #0x20]
100501760:     	adrp	x26, 0x100f76000 <__MergedGlobals.1914+0xc8>
100501764:     	cbz	w25, 0x1005016cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb94>
100501768:     	cbnz	w8, 0x100501e94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x135c>
10050176c:     	ldr	x8, [x20]
100501770:     	cbnz	x8, 0x100501f38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1400>
100501774:     	ldr	x8, [x20, #0x18]
100501778:     	cmp	x21, x8
10050177c:     	b.hi	0x100500b70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100501780:     	str	x21, [x20, #0x18]
100501784:     	b	0x100500b70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100501788:     	cmp	w10, #0x5b
10050178c:     	b.eq	0x100501798 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc60>
100501790:     	cmp	w10, #0x7b
100501794:     	b.ne	0x1005017ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc74>
100501798:     	add	x0, x22, #0x14
10050179c:     	mov	x1, x19
1005017a0:     	mov	w2, #0x3e8              ; =1000
1005017a4:     	bl	0x1006be3d4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
1005017a8:     	cbnz	w0, 0x100501d28 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11f0>
1005017ac:     	ldr	w22, [x26, #0x590]
1005017b0:     	cmp	w22, #0x300
1005017b4:     	b.hs	0x100501a5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf24>
1005017b8:     	ldr	x8, [x27, #0x48]
1005017bc:     	cmn	x8, #0x1
1005017c0:     	b.eq	0x100501a4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf14>
1005017c4:     	mrs	x9, TPIDRRO_EL0
1005017c8:     	and	x9, x9, #0xfffffffffffffff8
1005017cc:     	ldr	x0, [x9, x8, lsl #3]
1005017d0:     	cbz	x0, 0x100501a4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf14>
1005017d4:     	add	x8, x0, x22, lsl #3
1005017d8:     	ldr	x0, [x8, #0x1e8]
1005017dc:     	cbz	x0, 0x100501a5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf24>
1005017e0:     	bl	0x100219cb0 <__RNCNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary0B7_>
1005017e4:     	bl	0x100455200 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
1005017e8:     	mov	x0, x19
1005017ec:     	bl	0x10022ec6c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
1005017f0:     	mov	x24, x0
1005017f4:     	mov	x22, x1
1005017f8:     	bl	0x100455014 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
1005017fc:     	ldrb	w8, [x20, #0x20]
100501800:     	cbnz	w8, 0x100501cb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x117c>
100501804:     	ldr	x8, [x20]
100501808:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10050180c:     	cmp	x8, x9
100501810:     	b.hs	0x100501e88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1350>
100501814:     	add	x9, x8, #0x1
100501818:     	str	x9, [x20]
10050181c:     	ldr	x9, [x20, #0x18]
100501820:     	cmp	x21, x9
100501824:     	b.hs	0x10050183c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd04>
100501828:     	ldr	x9, [x20, #0x10]
10050182c:     	ldr	x9, [x9, x21, lsl #3]
100501830:     	and	x25, x9, #0xffffffffffff
100501834:     	add	x1, x25, #0x14
100501838:     	b	0x100501844 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd0c>
10050183c:     	mov	w25, #0x1               ; =1
100501840:     	mov	w1, #0x15               ; =21
100501844:     	str	x8, [x20]
100501848:     	add	x0, sp, #0xa0
10050184c:     	mov	x2, x19
100501850:     	mov	x3, x25
100501854:     	bl	0x10025c460 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23new_batched_from_string>
100501858:     	add	x0, sp, #0xa0
10050185c:     	bl	0x10025959c <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
100501860:     	mov	x23, x0
100501864:     	ldp	x26, x28, [sp, #0x108]
100501868:     	cmp	x28, x26
10050186c:     	b.hs	0x1005018a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd68>
100501870:     	ldr	x8, [sp, #0x100]
100501874:     	mov	x9, #0x2600             ; =9728
100501878:     	movk	x9, #0x1, lsl #32
10050187c:     	ldrb	w10, [x8, x28]
100501880:     	cmp	w10, #0x20
100501884:     	b.hi	0x1005018a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd68>
100501888:     	lsr	x10, x9, x10
10050188c:     	tbz	w10, #0x0, 0x1005018a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd68>
100501890:     	add	x28, x28, #0x1
100501894:     	cmp	x26, x28
100501898:     	b.ne	0x10050187c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd44>
10050189c:     	mov	x28, x26
1005018a0:     	ldrb	w8, [sp, #0x176]
1005018a4:     	tbnz	w8, #0x0, 0x100501c3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1104>
1005018a8:     	cmp	x28, x26
1005018ac:     	b.ne	0x100501c48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1110>
1005018b0:     	ldrb	w8, [sp, #0x174]
1005018b4:     	tbz	w8, #0x0, 0x100501c48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1110>
1005018b8:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
1005018bc:     	ldr	w26, [x8, #0x560]
1005018c0:     	cmp	w26, #0x300
1005018c4:     	b.hs	0x100501a7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf44>
1005018c8:     	ldr	x8, [x27, #0x48]
1005018cc:     	cmn	x8, #0x1
1005018d0:     	b.eq	0x100501a6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf34>
1005018d4:     	mrs	x9, TPIDRRO_EL0
1005018d8:     	and	x9, x9, #0xfffffffffffffff8
1005018dc:     	ldr	x0, [x9, x8, lsl #3]
1005018e0:     	cbz	x0, 0x100501a6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf34>
1005018e4:     	add	x8, x0, x26, lsl #3
1005018e8:     	ldr	x0, [x8, #0x1e8]
1005018ec:     	cbz	x0, 0x100501a7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf44>
1005018f0:     	ldr	x8, [x0]
1005018f4:     	cbnz	x8, 0x100501a90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf58>
1005018f8:     	ldrb	w8, [x0, #0x24]
1005018fc:     	cmp	w8, #0x2
100501900:     	adrp	x26, 0x100f76000 <__MergedGlobals.1914+0xc8>
100501904:     	b.eq	0x100501928 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdf0>
100501908:     	ldr	x8, [x0, #0x8]
10050190c:     	cmp	x8, x25
100501910:     	b.ne	0x100501928 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdf0>
100501914:     	ldr	w8, [x0, #0x18]
100501918:     	cmp	x19, x8
10050191c:     	b.ne	0x100501928 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdf0>
100501920:     	mov	w8, #0x1                ; =1
100501924:     	strb	w8, [x0, #0x24]
100501928:     	mov	x0, x25
10050192c:     	mov	x1, x19
100501930:     	mov	x2, x23
100501934:     	bl	0x1004e7780 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template>
100501938:     	ldrb	w8, [x20, #0x20]
10050193c:     	cbnz	w8, 0x100501ce4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11ac>
100501940:     	ldr	x8, [x20]
100501944:     	cbnz	x8, 0x100501d08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11d0>
100501948:     	mov	x8, #-0x1               ; =-1
10050194c:     	str	x8, [x20]
100501950:     	ldr	x19, [x20, #0x18]
100501954:     	ldr	x8, [x20, #0x8]
100501958:     	cmp	x19, x8
10050195c:     	b.eq	0x100501a9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf64>
100501960:     	ldr	x8, [x20, #0x10]
100501964:     	str	x23, [x8, x19, lsl #3]
100501968:     	add	x8, x19, #0x1
10050196c:     	str	x8, [x20, #0x18]
100501970:     	ldr	x8, [x20]
100501974:     	add	x8, x8, #0x1
100501978:     	str	x8, [x20]
10050197c:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
100501980:     	ldr	w19, [x8, #0x308]
100501984:     	cmp	w19, #0x300
100501988:     	b.hs	0x100501ab8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf80>
10050198c:     	ldr	x8, [x27, #0x48]
100501990:     	cmn	x8, #0x1
100501994:     	b.eq	0x100501aa8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf70>
100501998:     	mrs	x9, TPIDRRO_EL0
10050199c:     	and	x9, x9, #0xfffffffffffffff8
1005019a0:     	ldr	x0, [x9, x8, lsl #3]
1005019a4:     	cbz	x0, 0x100501aa8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf70>
1005019a8:     	add	x8, x0, x19, lsl #3
1005019ac:     	ldr	x0, [x8, #0x1e8]
1005019b0:     	cbz	x0, 0x100501ab8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf80>
1005019b4:     	ldrb	w8, [x0]
1005019b8:     	and	w8, w8, #0xfffffffd
1005019bc:     	strb	w8, [x0]
1005019c0:     	mov	w0, #0x0                ; =0
1005019c4:     	bl	0x100458940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
1005019c8:     	ldr	w19, [x26, #0x590]
1005019cc:     	cmp	w19, #0x300
1005019d0:     	b.hs	0x100501ad8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa0>
1005019d4:     	ldr	x8, [x27, #0x48]
1005019d8:     	cmn	x8, #0x1
1005019dc:     	b.eq	0x100501ac8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf90>
1005019e0:     	mrs	x9, TPIDRRO_EL0
1005019e4:     	and	x9, x9, #0xfffffffffffffff8
1005019e8:     	ldr	x0, [x9, x8, lsl #3]
1005019ec:     	cbz	x0, 0x100501ac8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf90>
1005019f0:     	add	x8, x0, x19, lsl #3
1005019f4:     	ldr	x0, [x8, #0x1e8]
1005019f8:     	cbz	x0, 0x100501ad8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa0>
1005019fc:     	ldr	x8, [x0]
100501a00:     	lsr	x8, x8, #25
100501a04:     	cbz	x8, 0x100501af0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfb8>
100501a08:     	bl	0x10045a8f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100501a0c:     	bl	0x10045cc20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100501a10:     	mov	x0, x24
100501a14:     	mov	x1, x22
100501a18:     	bl	0x10022edb8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100501a1c:     	ldrb	w8, [x20, #0x20]
100501a20:     	cbz	w8, 0x100501b08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd0>
100501a24:     	cmp	w8, #0x2
100501a28:     	b.eq	0x100501e9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1364>
100501a2c:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501a30:     	add	x1, x1, #0x58
100501a34:     	mov	x0, x20
100501a38:     	bl	0x100a16cdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501a3c:     	strb	wzr, [x20, #0x20]
100501a40:     	ldr	x8, [x20]
100501a44:     	cbz	x8, 0x100501b10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd8>
100501a48:     	b	0x100501f38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1400>
100501a4c:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501a50:     	add	x8, x0, x22, lsl #3
100501a54:     	ldr	x0, [x8, #0x1e8]
100501a58:     	cbnz	x0, 0x1005017e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xca8>
100501a5c:     	adrp	x0, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100501a60:     	add	x0, x0, #0x78
100501a64:     	bl	0x100b3345c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100501a68:     	b	0x1005017e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xca8>
100501a6c:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501a70:     	add	x8, x0, x26, lsl #3
100501a74:     	ldr	x0, [x8, #0x1e8]
100501a78:     	cbnz	x0, 0x1005018f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdb8>
100501a7c:     	adrp	x0, 0x100f03000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
100501a80:     	add	x0, x0, #0xfa0
100501a84:     	bl	0x100b3345c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100501a88:     	ldr	x8, [x0]
100501a8c:     	cbz	x8, 0x1005018f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdc0>
100501a90:     	adrp	x0, 0x100ef1000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100501a94:     	add	x0, x0, #0xcf8
100501a98:     	bl	0x100b08fac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100501a9c:     	add	x0, x20, #0x8
100501aa0:     	bl	0x100b3252c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100501aa4:     	b	0x100501960 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe28>
100501aa8:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501aac:     	add	x8, x0, x19, lsl #3
100501ab0:     	ldr	x0, [x8, #0x1e8]
100501ab4:     	cbnz	x0, 0x1005019b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe7c>
100501ab8:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
100501abc:     	add	x0, x0, #0xcd8
100501ac0:     	bl	0x100b334a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100501ac4:     	b	0x1005019b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe7c>
100501ac8:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501acc:     	add	x8, x0, x19, lsl #3
100501ad0:     	ldr	x0, [x8, #0x1e8]
100501ad4:     	cbnz	x0, 0x1005019fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xec4>
100501ad8:     	adrp	x0, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100501adc:     	add	x0, x0, #0x78
100501ae0:     	bl	0x100b3345c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100501ae4:     	ldr	x8, [x0]
100501ae8:     	lsr	x8, x8, #25
100501aec:     	cbnz	x8, 0x100501a08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xed0>
100501af0:     	bl	0x10045cc20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100501af4:     	mov	x0, x24
100501af8:     	mov	x1, x22
100501afc:     	bl	0x10022edb8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100501b00:     	ldrb	w8, [x20, #0x20]
100501b04:     	cbnz	w8, 0x100501a24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeec>
100501b08:     	ldr	x8, [x20]
100501b0c:     	cbnz	x8, 0x100501f38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1400>
100501b10:     	ldr	x8, [x20, #0x18]
100501b14:     	cmp	x21, x8
100501b18:     	b.ls	0x100501b40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1008>
100501b1c:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100501b20:     	ldr	x8, [x8, #0x758]
100501b24:     	cbnz	x8, 0x100501b50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1018>
100501b28:     	ldr	x8, [sp, #0xd8]
100501b2c:     	cmp	x8, #0x1
100501b30:     	b.lt	0x100500b70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100501b34:     	ldr	x0, [sp, #0xe0]
100501b38:     	bl	0x100b55880 <_mi_free>
100501b3c:     	b	0x100500b70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100501b40:     	str	x21, [x20, #0x18]
100501b44:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100501b48:     	ldr	x8, [x8, #0x758]
100501b4c:     	cbz	x8, 0x100501b28 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff0>
100501b50:     	bl	0x100b3c330 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100501b54:     	ldr	x8, [sp, #0xd8]
100501b58:     	cmp	x8, #0x1
100501b5c:     	b.ge	0x100501b34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xffc>
100501b60:     	b	0x100500b70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100501b64:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501b68:     	add	x8, x0, x24, lsl #3
100501b6c:     	ldr	x0, [x8, #0x1e8]
100501b70:     	cbnz	x0, 0x1005011f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6bc>
100501b74:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
100501b78:     	add	x0, x0, #0xca8
100501b7c:     	bl	0x100b334a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100501b80:     	ldrb	w8, [x0]
100501b84:     	cbz	w8, 0x1005011fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6c4>
100501b88:     	bl	0x100b3abdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
100501b8c:     	ldr	w24, [x26, #0x590]
100501b90:     	cmp	w24, #0x300
100501b94:     	b.lo	0x100501208 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6d0>
100501b98:     	b	0x100501bac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1074>
100501b9c:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501ba0:     	add	x8, x0, x24, lsl #3
100501ba4:     	ldr	x0, [x8, #0x1e8]
100501ba8:     	cbnz	x0, 0x100501230 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6f8>
100501bac:     	adrp	x0, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100501bb0:     	add	x0, x0, #0x78
100501bb4:     	bl	0x100b3345c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100501bb8:     	b	0x100501230 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6f8>
100501bbc:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501bc0:     	add	x8, x0, x24, lsl #3
100501bc4:     	ldr	x0, [x8, #0x1e8]
100501bc8:     	cbnz	x0, 0x100501570 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa38>
100501bcc:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
100501bd0:     	add	x0, x0, #0xcd8
100501bd4:     	bl	0x100b334a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100501bd8:     	b	0x100501570 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa38>
100501bdc:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501be0:     	add	x8, x0, x24, lsl #3
100501be4:     	ldr	x0, [x8, #0x1e8]
100501be8:     	cbnz	x0, 0x1005015bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa84>
100501bec:     	adrp	x0, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100501bf0:     	add	x0, x0, #0x78
100501bf4:     	bl	0x100b3345c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100501bf8:     	ldr	x8, [x0]
100501bfc:     	lsr	x8, x8, #25
100501c00:     	cbnz	x8, 0x1005015c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa90>
100501c04:     	cmp	x23, #0x3e8
100501c08:     	b.ls	0x1005015d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa9c>
100501c0c:     	bl	0x10045cc20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100501c10:     	ldp	x1, x0, [sp]
100501c14:     	bl	0x10022edb8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100501c18:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100501c1c:     	ldr	x8, [x8, #0x758]
100501c20:     	cbz	x8, 0x1005015e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xab0>
100501c24:     	bl	0x100b3c330 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100501c28:     	tbnz	w25, #0x0, 0x1005015ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xab4>
100501c2c:     	b	0x100501630 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xaf8>
100501c30:     	add	x0, x20, #0x8
100501c34:     	bl	0x100b3252c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100501c38:     	b	0x100501518 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9e0>
100501c3c:     	bl	0x100b3c104 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar15clear_key_cache>
100501c40:     	cmp	x28, x26
100501c44:     	b.eq	0x1005018b0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd78>
100501c48:     	mov	x0, x23
100501c4c:     	bl	0x100323308 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15parse_root_push>
100501c50:     	bl	0x10045517c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy13gc_unsuppress>
100501c54:     	bl	0x1004ea5a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat26finish_parse_gc_accounting>
100501c58:     	bl	0x10045cc20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100501c5c:     	mov	x0, x24
100501c60:     	mov	x1, x22
100501c64:     	bl	0x10022edb8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100501c68:     	mov	x0, x21
100501c6c:     	bl	0x100323518 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100501c70:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100501c74:     	ldr	x8, [x8, #0x758]
100501c78:     	cbnz	x8, 0x1005021e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x16a8>
100501c7c:     	adrp	x0, 0x100c6b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x661c>
100501c80:     	add	x0, x0, #0xea0
100501c84:     	mov	w1, #0x21               ; =33
100501c88:     	bl	0x100503714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
100501c8c:     	cmp	w8, #0x2
100501c90:     	b.eq	0x100501e9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1364>
100501c94:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501c98:     	add	x1, x1, #0x58
100501c9c:     	mov	x0, x20
100501ca0:     	bl	0x100a16cdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501ca4:     	strb	wzr, [x20, #0x20]
100501ca8:     	ldr	x8, [x20]
100501cac:     	cbz	x8, 0x100501064 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x52c>
100501cb0:     	b	0x100501d08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11d0>
100501cb4:     	cmp	w8, #0x2
100501cb8:     	b.eq	0x100501e9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1364>
100501cbc:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501cc0:     	add	x1, x1, #0x58
100501cc4:     	mov	x0, x20
100501cc8:     	bl	0x100a16cdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501ccc:     	strb	wzr, [x20, #0x20]
100501cd0:     	ldr	x8, [x20]
100501cd4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501cd8:     	cmp	x8, x9
100501cdc:     	b.lo	0x100501814 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcdc>
100501ce0:     	b	0x100501e88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1350>
100501ce4:     	cmp	w8, #0x2
100501ce8:     	b.eq	0x100501e9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1364>
100501cec:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501cf0:     	add	x1, x1, #0x58
100501cf4:     	mov	x0, x20
100501cf8:     	bl	0x100a16cdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501cfc:     	strb	wzr, [x20, #0x20]
100501d00:     	ldr	x8, [x20]
100501d04:     	cbz	x8, 0x100501948 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe10>
100501d08:     	adrp	x0, 0x100eee000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100501d0c:     	add	x0, x0, #0x428
100501d10:     	bl	0x100b08fac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100501d14:     	mov	x0, x22
100501d18:     	bl	0x100b14dac <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11TapeScratchEEuE16get_or_init_slowNvNvB2b_12TAPE_SCRATCH27___rust_std_internal_init_fnEB2d_>
100501d1c:     	mov	x22, x0
100501d20:     	cbnz	x0, 0x10050114c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x614>
100501d24:     	b	0x100501e9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1364>
100501d28:     	mov	x0, x21
100501d2c:     	bl	0x100323518 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100501d30:     	mov	x0, x22
100501d34:     	mov	x1, x19
100501d38:     	bl	0x100b3c6a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api19parse_deep_or_throw>
100501d3c:     	mov	x23, x0
100501d40:     	b	0x100500b70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x38>
100501d44:     	cmp	w8, #0x2
100501d48:     	b.eq	0x100501e9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1364>
100501d4c:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501d50:     	add	x1, x1, #0x58
100501d54:     	mov	x0, x20
100501d58:     	bl	0x100a16cdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501d5c:     	strb	wzr, [x20, #0x20]
100501d60:     	ldr	x8, [x20]
100501d64:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501d68:     	cmp	x8, x9
100501d6c:     	b.lo	0x100501100 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c8>
100501d70:     	b	0x100501e88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1350>
100501d74:     	cmp	x9, #0x6
100501d78:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100501d7c:     	ldrb	w8, [x21, #0x1a]
100501d80:     	cmp	w8, #0x22
100501d84:     	b.ne	0x100501ea8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1370>
100501d88:     	mov	w23, #0x0               ; =0
100501d8c:     	mov	w28, #0x0               ; =0
100501d90:     	mov	w27, #0x0               ; =0
100501d94:     	mov	w26, #0x1               ; =1
100501d98:     	mov	w20, #0x4               ; =4
100501d9c:     	b	0x100500cf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100501da0:     	cmp	w8, #0x2
100501da4:     	b.eq	0x100501e9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1364>
100501da8:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501dac:     	add	x1, x1, #0x58
100501db0:     	mov	x0, x20
100501db4:     	bl	0x100a16cdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501db8:     	strb	wzr, [x20, #0x20]
100501dbc:     	ldr	x8, [x20]
100501dc0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501dc4:     	cmp	x8, x9
100501dc8:     	b.lo	0x1005016e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xba8>
100501dcc:     	b	0x100501e88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1350>
100501dd0:     	cmp	w8, #0x2
100501dd4:     	b.eq	0x100501e9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1364>
100501dd8:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501ddc:     	add	x1, x1, #0x58
100501de0:     	mov	x0, x20
100501de4:     	bl	0x100a16cdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501de8:     	strb	wzr, [x20, #0x20]
100501dec:     	ldr	x8, [x20]
100501df0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501df4:     	cmp	x8, x9
100501df8:     	b.lo	0x100501264 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x72c>
100501dfc:     	b	0x100501e88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1350>
100501e00:     	cmp	w8, #0x2
100501e04:     	b.eq	0x100501e9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1364>
100501e08:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501e0c:     	add	x1, x1, #0x58
100501e10:     	mov	x0, x20
100501e14:     	bl	0x100a16cdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501e18:     	strb	wzr, [x20, #0x20]
100501e1c:     	ldr	x8, [x20]
100501e20:     	cbz	x8, 0x100501500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9c8>
100501e24:     	b	0x100501d08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11d0>
100501e28:     	cmp	x9, #0x1
100501e2c:     	b.ne	0x100501ed8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13a0>
100501e30:     	ldrb	w8, [x8]
100501e34:     	sub	w9, w8, #0x30
100501e38:     	cmp	w9, #0xa
100501e3c:     	b.hs	0x100501edc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13a4>
100501e40:     	and	w8, w9, #0xff
100501e44:     	ucvtf	d0, w8
100501e48:     	fmov	x1, d0
100501e4c:     	orr	x0, x25, x26
100501e50:     	bl	0x1004f04d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object18allocate_one_field>
100501e54:     	tbnz	w0, #0x0, 0x100500b6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x34>
100501e58:     	b	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100501e5c:     	cmp	w8, #0x2
100501e60:     	b.eq	0x100501e9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1364>
100501e64:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501e68:     	add	x1, x1, #0x58
100501e6c:     	mov	x0, x20
100501e70:     	bl	0x100a16cdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501e74:     	strb	wzr, [x20, #0x20]
100501e78:     	ldr	x8, [x20]
100501e7c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501e80:     	cmp	x8, x9
100501e84:     	b.lo	0x100501604 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xacc>
100501e88:     	adrp	x0, 0x100eee000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100501e8c:     	add	x0, x0, #0x3f8
100501e90:     	bl	0x100b08fdc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100501e94:     	cmp	w8, #0x2
100501e98:     	b.ne	0x100501f1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13e4>
100501e9c:     	adrp	x0, 0x100eea000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100501ea0:     	add	x0, x0, #0xc18
100501ea4:     	bl	0x100b4eedc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100501ea8:     	sub	x8, x19, #0x1
100501eac:     	cmp	x8, #0x7
100501eb0:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100501eb4:     	ldrb	w8, [x21, #0x1b]
100501eb8:     	cmp	w8, #0x22
100501ebc:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100501ec0:     	mov	w23, #0x0               ; =0
100501ec4:     	mov	w28, #0x0               ; =0
100501ec8:     	mov	w27, #0x0               ; =0
100501ecc:     	mov	w26, #0x0               ; =0
100501ed0:     	mov	w20, #0x5               ; =5
100501ed4:     	b	0x100500cf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b8>
100501ed8:     	ldrb	w8, [x8]
100501edc:     	orr	w8, w8, #0x20
100501ee0:     	cmp	w8, #0x7b
100501ee4:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100501ee8:     	sub	x11, x19, #0x5
100501eec:     	mov	x10, #0x2600            ; =9728
100501ef0:     	movk	x10, #0x1, lsl #32
100501ef4:     	add	x8, x21, x20
100501ef8:     	ldrb	w9, [x8, #0x18]
100501efc:     	cmp	w9, #0x20
100501f00:     	b.hi	0x100501f44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x140c>
100501f04:     	lsr	x12, x10, x9
100501f08:     	tbz	w12, #0x0, 0x100501f44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x140c>
100501f0c:     	add	x20, x20, #0x1
100501f10:     	cmp	x11, x20
100501f14:     	b.ne	0x100501ef4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13bc>
100501f18:     	b	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100501f1c:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501f20:     	add	x1, x1, #0x58
100501f24:     	mov	x0, x20
100501f28:     	bl	0x100a16cdc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501f2c:     	strb	wzr, [x20, #0x20]
100501f30:     	ldr	x8, [x20]
100501f34:     	cbz	x8, 0x100501774 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc3c>
100501f38:     	adrp	x0, 0x100eee000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100501f3c:     	add	x0, x0, #0x488
100501f40:     	bl	0x100b08fac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100501f44:     	cmp	x11, x20
100501f48:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100501f4c:     	add	x13, x21, #0x12
100501f50:     	mov	x14, #0x2600            ; =9728
100501f54:     	movk	x14, #0x1, lsl #32
100501f58:     	mov	x10, x20
100501f5c:     	ldrb	w12, [x13, x19]
100501f60:     	cmp	w12, #0x20
100501f64:     	b.hi	0x100501f94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x145c>
100501f68:     	lsr	x15, x14, x12
100501f6c:     	tbz	w15, #0x0, 0x100501f94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x145c>
100501f70:     	sub	x13, x13, #0x1
100501f74:     	add	x10, x10, #0x1
100501f78:     	cmp	x11, x10
100501f7c:     	b.ne	0x100501f5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1424>
100501f80:     	b	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100501f84:     	adrp	x2, 0x100eff000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime7promise28ITER_RESULT_VALUE_IS_RAW_I32+0x40>
100501f88:     	add	x2, x2, #0x170
100501f8c:     	mov	x1, x25
100501f90:     	bl	0x100b0910c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100501f94:     	sub	x11, x19, x10
100501f98:     	sub	x1, x11, #0x5
100501f9c:     	cmp	x1, #0x4
100501fa0:     	b.eq	0x10050200c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14d4>
100501fa4:     	cmp	x1, #0x5
100501fa8:     	b.ne	0x100502014 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14dc>
100501fac:     	cmp	w9, #0x22
100501fb0:     	b.eq	0x100502040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1508>
100501fb4:     	cmp	w9, #0x2d
100501fb8:     	b.eq	0x100502030 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14f8>
100501fbc:     	cmp	w9, #0x66
100501fc0:     	b.ne	0x100502024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ec>
100501fc4:     	add	x8, x21, x20
100501fc8:     	ldrb	w9, [x8, #0x19]
100501fcc:     	cmp	w9, #0x61
100501fd0:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100501fd4:     	ldrb	w8, [x8, #0x1a]
100501fd8:     	cmp	w8, #0x6c
100501fdc:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100501fe0:     	add	x8, x21, x20
100501fe4:     	ldrb	w9, [x8, #0x1b]
100501fe8:     	cmp	w9, #0x73
100501fec:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100501ff0:     	ldrb	w8, [x8, #0x1c]
100501ff4:     	cmp	w8, #0x65
100501ff8:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100501ffc:     	mov	x8, #0x1                ; =1
100502000:     	movk	x8, #0x7ffc, lsl #48
100502004:     	orr	x1, x8, #0x2
100502008:     	b	0x100501e4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1314>
10050200c:     	cmp	w9, #0x6d
100502010:     	b.gt	0x1005020ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1574>
100502014:     	cmp	w9, #0x22
100502018:     	b.eq	0x100502040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1508>
10050201c:     	cmp	w9, #0x2d
100502020:     	b.eq	0x100502030 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14f8>
100502024:     	sub	w9, w9, #0x30
100502028:     	cmp	w9, #0xa
10050202c:     	b.hs	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100502030:     	add	x0, x8, #0x18
100502034:     	bl	0x1004e8388 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar12parse_number>
100502038:     	tbz	w0, #0x0, 0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
10050203c:     	b	0x100501e4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1314>
100502040:     	sub	x8, x19, #0x6
100502044:     	cmp	x8, x10
100502048:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
10050204c:     	cmp	x1, #0x7
100502050:     	b.hi	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100502054:     	cmp	w12, #0x22
100502058:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
10050205c:     	sub	x23, x11, #0x7
100502060:     	sub	x8, x19, #0x7
100502064:     	add	x9, x21, x20
100502068:     	add	x22, x9, #0x19
10050206c:     	cmp	x8, x10
100502070:     	b.ne	0x100502134 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15fc>
100502074:     	add	x8, sp, #0xa0
100502078:     	mov	x0, x22
10050207c:     	mov	x1, x23
100502080:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100502084:     	ldr	x8, [sp, #0xa0]
100502088:     	cbnz	x8, 0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
10050208c:     	cmp	x23, #0x2
100502090:     	b.gt	0x100502164 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x162c>
100502094:     	cbz	x23, 0x100502180 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1648>
100502098:     	cmp	x23, #0x1
10050209c:     	b.ne	0x100502188 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1650>
1005020a0:     	ldrb	w8, [x22]
1005020a4:     	mov	x9, #0x10000000000      ; =1099511627776
1005020a8:     	b	0x1005021d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x169c>
1005020ac:     	cmp	w9, #0x74
1005020b0:     	b.eq	0x1005020f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15c0>
1005020b4:     	cmp	w9, #0x6e
1005020b8:     	b.ne	0x100502024 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ec>
1005020bc:     	add	x8, x21, x20
1005020c0:     	ldrb	w9, [x8, #0x19]
1005020c4:     	cmp	w9, #0x75
1005020c8:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005020cc:     	ldrb	w8, [x8, #0x1a]
1005020d0:     	cmp	w8, #0x6c
1005020d4:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005020d8:     	add	x8, x21, x20
1005020dc:     	ldrb	w8, [x8, #0x1b]
1005020e0:     	cmp	w8, #0x6c
1005020e4:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
1005020e8:     	mov	x8, #0x1                ; =1
1005020ec:     	movk	x8, #0x7ffc, lsl #48
1005020f0:     	add	x1, x8, #0x1
1005020f4:     	b	0x100501e4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1314>
1005020f8:     	add	x8, x21, x20
1005020fc:     	ldrb	w9, [x8, #0x19]
100502100:     	cmp	w9, #0x72
100502104:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100502108:     	ldrb	w8, [x8, #0x1a]
10050210c:     	cmp	w8, #0x75
100502110:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100502114:     	add	x8, x21, x20
100502118:     	ldrb	w8, [x8, #0x1b]
10050211c:     	cmp	w8, #0x65
100502120:     	b.ne	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100502124:     	mov	x8, #0x1                ; =1
100502128:     	movk	x8, #0x7ffc, lsl #48
10050212c:     	add	x1, x8, #0x3
100502130:     	b	0x100501e4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1314>
100502134:     	mov	x8, x23
100502138:     	mov	x9, x22
10050213c:     	ldrb	w10, [x9], #0x1
100502140:     	cmp	w10, #0x20
100502144:     	b.lo	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100502148:     	cmp	w10, #0x22
10050214c:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100502150:     	cmp	w10, #0x5c
100502154:     	b.eq	0x100500bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x84>
100502158:     	subs	x8, x8, #0x1
10050215c:     	b.ne	0x10050213c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1604>
100502160:     	b	0x100502074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x153c>
100502164:     	cmp	x23, #0x3
100502168:     	b.eq	0x1005021a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1668>
10050216c:     	cmp	x23, #0x4
100502170:     	b.ne	0x1005021c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1688>
100502174:     	ldr	w8, [x22]
100502178:     	mov	x9, #0x40000000000      ; =4398046511104
10050217c:     	b	0x1005021d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x169c>
100502180:     	mov	x1, #0x7ff9000000000000 ; =9221401712017801216
100502184:     	b	0x100501e4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1314>
100502188:     	ldrb	w8, [x22]
10050218c:     	add	x9, x21, x20
100502190:     	ldrb	w9, [x9, #0x1a]
100502194:     	orr	x8, x8, x9, lsl #8
100502198:     	mov	x9, #0x20000000000      ; =2199023255552
10050219c:     	b	0x1005021d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x169c>
1005021a0:     	ldrb	w8, [x22]
1005021a4:     	add	x9, x21, x20
1005021a8:     	ldrb	w10, [x9, #0x1a]
1005021ac:     	ldrb	w9, [x9, #0x1b]
1005021b0:     	orr	x8, x8, x10, lsl #8
1005021b4:     	orr	x8, x8, x9, lsl #16
1005021b8:     	mov	x9, #0x30000000000      ; =3298534883328
1005021bc:     	b	0x1005021d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x169c>
1005021c0:     	ldr	w8, [x22]
1005021c4:     	add	x9, x21, x20
1005021c8:     	ldrb	w9, [x9, #0x1d]
1005021cc:     	orr	x8, x8, x9, lsl #32
1005021d0:     	mov	x9, #0x50000000000      ; =5497558138880
1005021d4:     	movk	x9, #0x7ff9, lsl #48
1005021d8:     	orr	x1, x8, x9
1005021dc:     	b	0x100501e4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1314>
1005021e0:     	bl	0x100b3c330 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
1005021e4:     	adrp	x0, 0x100c6b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x661c>
1005021e8:     	add	x0, x0, #0xea0
1005021ec:     	mov	w1, #0x21               ; =33
1005021f0:     	bl	0x100503714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
