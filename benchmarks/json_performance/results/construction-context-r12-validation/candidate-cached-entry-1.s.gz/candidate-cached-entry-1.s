
benchmarks/json_performance/.work/construction-context-r12/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004e7d90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template>:
1004e7d90:     	stp	x28, x27, [sp, #-0x60]!
1004e7d94:     	stp	x26, x25, [sp, #0x10]
1004e7d98:     	stp	x24, x23, [sp, #0x20]
1004e7d9c:     	stp	x22, x21, [sp, #0x30]
1004e7da0:     	stp	x20, x19, [sp, #0x40]
1004e7da4:     	stp	x29, x30, [sp, #0x50]
1004e7da8:     	add	x29, sp, #0x50
1004e7dac:     	sub	sp, sp, #0x330
1004e7db0:     	sub	x8, x1, #0x801
1004e7db4:     	cmn	x8, #0x7c0
1004e7db8:     	b.lo	0x1004e7ebc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x12c>
1004e7dbc:     	adrp	x19, 0x100f76000 <__MergedGlobals.1914+0xc8>
1004e7dc0:     	ldr	w20, [x19, #0x578]
1004e7dc4:     	adrp	x23, 0x100f74000 <_perry_global_rotating_worker_ts__1>
1004e7dc8:     	cmp	w20, #0x300
1004e7dcc:     	b.hs	0x1004e7f08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x178>
1004e7dd0:     	ldr	x8, [x23, #0x48]
1004e7dd4:     	cmn	x8, #0x1
1004e7dd8:     	b.eq	0x1004e7ee4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x154>
1004e7ddc:     	mrs	x9, TPIDRRO_EL0
1004e7de0:     	and	x9, x9, #0xfffffffffffffff8
1004e7de4:     	ldr	x8, [x9, x8, lsl #3]
1004e7de8:     	cbz	x8, 0x1004e7ee4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x154>
1004e7dec:     	add	x8, x8, x20, lsl #3
1004e7df0:     	ldr	x8, [x8, #0x1e8]
1004e7df4:     	cbz	x8, 0x1004e7f08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x178>
1004e7df8:     	ldr	x9, [x8]
1004e7dfc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1004e7e00:     	cmp	x9, x10
1004e7e04:     	b.hs	0x1004e7f3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x1ac>
1004e7e08:     	ldrb	w9, [x8, #0x8]
1004e7e0c:     	cmp	w9, #0x2
1004e7e10:     	b.eq	0x1004e7ebc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x12c>
1004e7e14:     	ldr	x9, [x8, #0x248]
1004e7e18:     	cmp	x9, x0
1004e7e1c:     	b.ne	0x1004e7ebc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x12c>
1004e7e20:     	ldrh	w8, [x8, #0x25c]
1004e7e24:     	cmp	x1, x8
1004e7e28:     	b.ne	0x1004e7ebc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x12c>
1004e7e2c:     	adrp	x8, 0x100f74000 <_perry_global_rotating_worker_ts__1>
1004e7e30:     	ldr	w20, [x8, #0x948]
1004e7e34:     	cmp	w20, #0x300
1004e7e38:     	b.hs	0x1004e8280 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4f0>
1004e7e3c:     	ldr	x8, [x23, #0x48]
1004e7e40:     	cmn	x8, #0x1
1004e7e44:     	b.eq	0x1004e8270 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4e0>
1004e7e48:     	mrs	x9, TPIDRRO_EL0
1004e7e4c:     	and	x9, x9, #0xfffffffffffffff8
1004e7e50:     	ldr	x0, [x9, x8, lsl #3]
1004e7e54:     	cbz	x0, 0x1004e8270 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4e0>
1004e7e58:     	add	x8, x0, x20, lsl #3
1004e7e5c:     	ldr	x0, [x8, #0x1e8]
1004e7e60:     	cbz	x0, 0x1004e8280 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4f0>
1004e7e64:     	ldrb	w8, [x0]
1004e7e68:     	cbnz	w8, 0x1004e8294 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x504>
1004e7e6c:     	ldr	w19, [x19, #0x578]
1004e7e70:     	cmp	w19, #0x300
1004e7e74:     	b.hs	0x1004e82b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x528>
1004e7e78:     	ldr	x8, [x23, #0x48]
1004e7e7c:     	cmn	x8, #0x1
1004e7e80:     	b.eq	0x1004e82a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x518>
1004e7e84:     	mrs	x9, TPIDRRO_EL0
1004e7e88:     	and	x9, x9, #0xfffffffffffffff8
1004e7e8c:     	ldr	x0, [x9, x8, lsl #3]
1004e7e90:     	cbz	x0, 0x1004e82a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x518>
1004e7e94:     	add	x8, x0, x19, lsl #3
1004e7e98:     	ldr	x22, [x8, #0x1e8]
1004e7e9c:     	cbz	x22, 0x1004e82b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x528>
1004e7ea0:     	ldr	x8, [x22]
1004e7ea4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1004e7ea8:     	cmp	x8, x9
1004e7eac:     	b.hs	0x1004e82d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x548>
1004e7eb0:     	ldrb	w20, [x22, #0x8]
1004e7eb4:     	cmp	w20, #0x2
1004e7eb8:     	b.ne	0x1004e7f48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x1b8>
1004e7ebc:     	mov	x0, #0x0                ; =0
1004e7ec0:     	mov	x1, x19
1004e7ec4:     	add	sp, sp, #0x330
1004e7ec8:     	ldp	x29, x30, [sp, #0x50]
1004e7ecc:     	ldp	x20, x19, [sp, #0x40]
1004e7ed0:     	ldp	x22, x21, [sp, #0x30]
1004e7ed4:     	ldp	x24, x23, [sp, #0x20]
1004e7ed8:     	ldp	x26, x25, [sp, #0x10]
1004e7edc:     	ldp	x28, x27, [sp], #0x60
1004e7ee0:     	ret
1004e7ee4:     	mov	x22, x1
1004e7ee8:     	mov	x21, x0
1004e7eec:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004e7ef0:     	mov	x1, x22
1004e7ef4:     	mov	x8, x0
1004e7ef8:     	mov	x0, x21
1004e7efc:     	add	x8, x8, x20, lsl #3
1004e7f00:     	ldr	x8, [x8, #0x1e8]
1004e7f04:     	cbnz	x8, 0x1004e7df8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x68>
1004e7f08:     	adrp	x8, 0x100f03000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004e7f0c:     	add	x8, x8, #0xfb8
1004e7f10:     	mov	x20, x0
1004e7f14:     	mov	x0, x8
1004e7f18:     	mov	x21, x1
1004e7f1c:     	bl	0x100b3345c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004e7f20:     	mov	x1, x21
1004e7f24:     	mov	x8, x0
1004e7f28:     	mov	x0, x20
1004e7f2c:     	ldr	x9, [x8]
1004e7f30:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1004e7f34:     	cmp	x9, x10
1004e7f38:     	b.lo	0x1004e7e08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x78>
1004e7f3c:     	adrp	x0, 0x100ef1000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004e7f40:     	add	x0, x0, #0xd40
1004e7f44:     	bl	0x100b08fdc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1004e7f48:     	add	x19, sp, #0x20
1004e7f4c:     	orr	x0, x19, #0x1
1004e7f50:     	add	x1, x22, #0x9
1004e7f54:     	mov	w2, #0x247              ; =583
1004e7f58:     	bl	0x100b5872c <_writev+0x100b5872c>
1004e7f5c:     	ldr	x10, [x22, #0x250]
1004e7f60:     	ldr	w11, [x22, #0x258]
1004e7f64:     	ldrh	w8, [x22, #0x25c]
1004e7f68:     	ldrb	w21, [x22, #0x25e]
1004e7f6c:     	ldrb	w9, [x22, #0x25f]
1004e7f70:     	strb	w20, [sp, #0x20]
1004e7f74:     	str	x10, [sp, #0x8]
1004e7f78:     	str	x10, [sp, #0x268]
1004e7f7c:     	str	w11, [sp, #0x4]
1004e7f80:     	str	w11, [sp, #0x270]
1004e7f84:     	strh	w8, [sp, #0x274]
1004e7f88:     	strb	w21, [sp, #0x276]
1004e7f8c:     	strb	w9, [sp, #0x277]
1004e7f90:     	bl	0x10027e644 <__RNvMs7_NtNtCs3gRpqoBkMHm_13perry_runtime2gc6policyNtB5_15GcSuppressScope3new>
1004e7f94:     	str	w0, [sp]
1004e7f98:     	add	x0, sp, #0x278
1004e7f9c:     	bl	0x100234e3c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime5arena12constructionNtB2_17ConstructionBatch3new>
1004e7fa0:     	adrp	x1, 0x100c92000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x7570>
1004e7fa4:     	add	x1, x1, #0x560
1004e7fa8:     	sub	x0, x29, #0xf0
1004e7fac:     	mov	w2, #0x40               ; =64
1004e7fb0:     	bl	0x100b58750 <_writev+0x100b58750>
1004e7fb4:     	cmp	w21, #0x9
1004e7fb8:     	b.hs	0x1004e8370 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5e0>
1004e7fbc:     	str	x21, [sp, #0x10]
1004e7fc0:     	cbz	w21, 0x1004e8178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3e8>
1004e7fc4:     	mov	x27, #0x0               ; =0
1004e7fc8:     	mov	w8, #0x48               ; =72
1004e7fcc:     	ldr	x9, [sp, #0x10]
1004e7fd0:     	umaddl	x28, w9, w8, x19
1004e7fd4:     	add	x8, sp, #0x20
1004e7fd8:     	ldr	x9, [sp, #0x278]
1004e7fdc:     	str	x9, [sp, #0x18]
1004e7fe0:     	mov	x22, #0x7ffd000000000000 ; =9222527611924643840
1004e7fe4:     	mov	x20, #-0x3000000000000  ; =-844424930131968
1004e7fe8:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
1004e7fec:     	mov	x19, #0x7ff9000000000000 ; =9221401712017801216
1004e7ff0:     	sub	x23, x29, #0xf0
1004e7ff4:     	mov	x26, x8
1004e7ff8:     	b	0x1004e8014 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x284>
1004e7ffc:     	ldr	x8, [x8, #0x8]
1004e8000:     	str	x8, [x23, x27, lsl #3]
1004e8004:     	add	x27, x27, #0x1
1004e8008:     	mov	x8, x26
1004e800c:     	cmp	x26, x28
1004e8010:     	b.eq	0x1004e8178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3e8>
1004e8014:     	ldrb	w9, [x26], #0x48
1004e8018:     	tbz	w9, #0x0, 0x1004e7ffc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x26c>
1004e801c:     	ldur	q0, [x8, #0x8]
1004e8020:     	ldur	q1, [x8, #0x18]
1004e8024:     	stp	q0, q1, [x29, #-0xb0]
1004e8028:     	ldur	q0, [x8, #0x28]
1004e802c:     	ldur	q1, [x8, #0x38]
1004e8030:     	stp	q0, q1, [x29, #-0x90]
1004e8034:     	ldrb	w25, [x8, #0x1]
1004e8038:     	sub	x0, x29, #0x68
1004e803c:     	add	x1, sp, #0x278
1004e8040:     	mov	x2, x25
1004e8044:     	bl	0x100232890 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray3new>
1004e8048:     	cmp	w25, #0x9
1004e804c:     	b.hs	0x1004e8358 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5c8>
1004e8050:     	ldur	x24, [x29, #-0x68]
1004e8054:     	cbz	w25, 0x1004e8150 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3c0>
1004e8058:     	lsl	x25, x25, #3
1004e805c:     	sub	x23, x29, #0xb0
1004e8060:     	b	0x1004e80b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x328>
1004e8064:     	add	x9, x24, w8, uxtw #3
1004e8068:     	str	x2, [x9, #0x8]
1004e806c:     	and	x9, x2, x20
1004e8070:     	cmp	x9, x22
1004e8074:     	cset	w9, eq
1004e8078:     	ldurb	w10, [x29, #-0x5f]
1004e807c:     	orr	w9, w10, w9
1004e8080:     	sturb	w9, [x29, #-0x5f]
1004e8084:     	ldurb	w9, [x29, #-0x5e]
1004e8088:     	csel	w9, w9, wzr, eq
1004e808c:     	sturb	w9, [x29, #-0x5e]
1004e8090:     	and	x9, x2, #0xffff000000000000
1004e8094:     	cmp	x9, x21
1004e8098:     	ccmp	x2, x19, #0x0, ls
1004e809c:     	ldurb	w9, [x29, #-0x5d]
1004e80a0:     	csel	w9, w9, wzr, lo
1004e80a4:     	sturb	w9, [x29, #-0x5d]
1004e80a8:     	add	w8, w8, #0x1
1004e80ac:     	str	w8, [x24]
1004e80b0:     	subs	x25, x25, #0x8
1004e80b4:     	b.eq	0x1004e8148 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3b8>
1004e80b8:     	ldr	x2, [x23], #0x8
1004e80bc:     	ldp	w8, w9, [x24]
1004e80c0:     	cmp	w8, w9
1004e80c4:     	b.eq	0x1004e8120 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x390>
1004e80c8:     	ldurb	w9, [x29, #-0x60]
1004e80cc:     	tbnz	w9, #0x0, 0x1004e8064 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x2d4>
1004e80d0:     	ldr	w9, [x24, #0x4]
1004e80d4:     	cmp	w8, w9
1004e80d8:     	b.hs	0x1004e8100 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x370>
1004e80dc:     	mov	w1, w8
1004e80e0:     	mov	x0, x24
1004e80e4:     	bl	0x1005243f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array15header_gc_slots27note_array_slot_layout_only>
1004e80e8:     	ldr	w8, [x24]
1004e80ec:     	add	w8, w8, #0x1
1004e80f0:     	str	w8, [x24]
1004e80f4:     	subs	x25, x25, #0x8
1004e80f8:     	b.ne	0x1004e80b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x328>
1004e80fc:     	b	0x1004e8148 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3b8>
1004e8100:     	fmov	d0, x2
1004e8104:     	mov	x0, x24
1004e8108:     	bl	0x1007c1418 <_js_array_push_f64>
1004e810c:     	mov	x24, x0
1004e8110:     	stur	x0, [x29, #-0x68]
1004e8114:     	subs	x25, x25, #0x8
1004e8118:     	b.ne	0x1004e80b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x328>
1004e811c:     	b	0x1004e8148 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x3b8>
1004e8120:     	sub	x0, x29, #0x68
1004e8124:     	add	x1, sp, #0x278
1004e8128:     	mov	x24, x2
1004e812c:     	bl	0x100b312cc <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray4grow>
1004e8130:     	mov	x2, x24
1004e8134:     	ldur	x24, [x29, #-0x68]
1004e8138:     	ldr	w8, [x24]
1004e813c:     	ldurb	w9, [x29, #-0x60]
1004e8140:     	tbnz	w9, #0x0, 0x1004e8064 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x2d4>
1004e8144:     	b	0x1004e80d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x340>
1004e8148:     	ldur	x24, [x29, #-0x68]
1004e814c:     	sub	x23, x29, #0xf0
1004e8150:     	sub	x0, x29, #0x68
1004e8154:     	ldr	x1, [sp, #0x18]
1004e8158:     	bl	0x1002326cc <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray13finish_layout>
1004e815c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1004e8160:     	bfxil	x8, x24, #0, #48
1004e8164:     	str	x8, [x23, x27, lsl #3]
1004e8168:     	add	x27, x27, #0x1
1004e816c:     	mov	x8, x26
1004e8170:     	cmp	x26, x28
1004e8174:     	b.ne	0x1004e8014 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x284>
1004e8178:     	add	x0, sp, #0x278
1004e817c:     	sub	x3, x29, #0xf0
1004e8180:     	ldp	x1, x4, [sp, #0x8]
1004e8184:     	ldr	w2, [sp, #0x4]
1004e8188:     	bl	0x1005b8bc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
1004e818c:     	adrp	x21, 0x100f74000 <_perry_global_rotating_worker_ts__1>
1004e8190:     	ldr	w8, [sp]
1004e8194:     	tbz	w8, #0x0, 0x1004e81fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x46c>
1004e8198:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1004e819c:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1004e81a0:     	ldr	x8, [x8, #0x758]
1004e81a4:     	cbnz	x8, 0x1004e8250 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4c0>
1004e81a8:     	bfxil	x19, x0, #0, #48
1004e81ac:     	adrp	x8, 0x100f74000 <_perry_global_rotating_worker_ts__1>
1004e81b0:     	ldr	w20, [x8, #0x930]
1004e81b4:     	cmp	w20, #0x300
1004e81b8:     	b.hs	0x1004e82f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x564>
1004e81bc:     	ldr	x8, [x21, #0x48]
1004e81c0:     	cmn	x8, #0x1
1004e81c4:     	b.eq	0x1004e82e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x554>
1004e81c8:     	mrs	x9, TPIDRRO_EL0
1004e81cc:     	and	x9, x9, #0xfffffffffffffff8
1004e81d0:     	ldr	x0, [x9, x8, lsl #3]
1004e81d4:     	cbz	x0, 0x1004e82e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x554>
1004e81d8:     	add	x8, x0, x20, lsl #3
1004e81dc:     	ldr	x0, [x8, #0x1e8]
1004e81e0:     	cbz	x0, 0x1004e82f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x564>
1004e81e4:     	ldrb	w8, [x0]
1004e81e8:     	cbz	w8, 0x1004e8308 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x578>
1004e81ec:     	sub	w8, w8, #0x1
1004e81f0:     	strb	w8, [x0]
1004e81f4:     	mov	w0, #0x1                ; =1
1004e81f8:     	b	0x1004e7ec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x130>
1004e81fc:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
1004e8200:     	ldr	w19, [x8, #0x308]
1004e8204:     	cmp	w19, #0x300
1004e8208:     	b.hs	0x1004e8338 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5a8>
1004e820c:     	ldr	x8, [x21, #0x48]
1004e8210:     	cmn	x8, #0x1
1004e8214:     	b.eq	0x1004e831c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x58c>
1004e8218:     	mrs	x9, TPIDRRO_EL0
1004e821c:     	and	x9, x9, #0xfffffffffffffff8
1004e8220:     	ldr	x8, [x9, x8, lsl #3]
1004e8224:     	cbz	x8, 0x1004e831c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x58c>
1004e8228:     	add	x8, x8, x19, lsl #3
1004e822c:     	ldr	x8, [x8, #0x1e8]
1004e8230:     	cbz	x8, 0x1004e8338 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x5a8>
1004e8234:     	ldrb	w9, [x8]
1004e8238:     	and	w9, w9, #0xfffffffd
1004e823c:     	strb	w9, [x8]
1004e8240:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1004e8244:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1004e8248:     	ldr	x8, [x8, #0x758]
1004e824c:     	cbz	x8, 0x1004e81a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x418>
1004e8250:     	mov	x20, x0
1004e8254:     	bl	0x100b3c330 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
1004e8258:     	bfxil	x19, x20, #0, #48
1004e825c:     	adrp	x8, 0x100f74000 <_perry_global_rotating_worker_ts__1>
1004e8260:     	ldr	w20, [x8, #0x930]
1004e8264:     	cmp	w20, #0x300
1004e8268:     	b.lo	0x1004e81bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x42c>
1004e826c:     	b	0x1004e82f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x564>
1004e8270:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004e8274:     	add	x8, x0, x20, lsl #3
1004e8278:     	ldr	x0, [x8, #0x1e8]
1004e827c:     	cbnz	x0, 0x1004e7e64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0xd4>
1004e8280:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1004e8284:     	add	x0, x0, #0xca8
1004e8288:     	bl	0x100b334a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004e828c:     	ldrb	w8, [x0]
1004e8290:     	cbz	w8, 0x1004e7e6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0xdc>
1004e8294:     	bl	0x100b3abdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
1004e8298:     	ldr	w19, [x19, #0x578]
1004e829c:     	cmp	w19, #0x300
1004e82a0:     	b.lo	0x1004e7e78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0xe8>
1004e82a4:     	b	0x1004e82b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x528>
1004e82a8:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004e82ac:     	add	x8, x0, x19, lsl #3
1004e82b0:     	ldr	x22, [x8, #0x1e8]
1004e82b4:     	cbnz	x22, 0x1004e7ea0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x110>
1004e82b8:     	adrp	x0, 0x100f03000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004e82bc:     	add	x0, x0, #0xfb8
1004e82c0:     	bl	0x100b3345c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004e82c4:     	mov	x22, x0
1004e82c8:     	ldr	x8, [x0]
1004e82cc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1004e82d0:     	cmp	x8, x9
1004e82d4:     	b.lo	0x1004e7eb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x120>
1004e82d8:     	adrp	x0, 0x100ef1000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004e82dc:     	add	x0, x0, #0xd58
1004e82e0:     	bl	0x100b08fdc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1004e82e4:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004e82e8:     	add	x8, x0, x20, lsl #3
1004e82ec:     	ldr	x0, [x8, #0x1e8]
1004e82f0:     	cbnz	x0, 0x1004e81e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x454>
1004e82f4:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1004e82f8:     	add	x0, x0, #0xc78
1004e82fc:     	bl	0x100b334a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004e8300:     	ldrb	w8, [x0]
1004e8304:     	cbnz	w8, 0x1004e81ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x45c>
1004e8308:     	mov	w8, #0x3f               ; =63
1004e830c:     	strb	w8, [x0]
1004e8310:     	bl	0x10045cc20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
1004e8314:     	mov	w0, #0x1                ; =1
1004e8318:     	b	0x1004e7ec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x130>
1004e831c:     	mov	x20, x0
1004e8320:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004e8324:     	mov	x8, x0
1004e8328:     	mov	x0, x20
1004e832c:     	add	x8, x8, x19, lsl #3
1004e8330:     	ldr	x8, [x8, #0x1e8]
1004e8334:     	cbnz	x8, 0x1004e8234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4a4>
1004e8338:     	adrp	x8, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x240>
1004e833c:     	add	x8, x8, #0xcd8
1004e8340:     	mov	x19, x0
1004e8344:     	mov	x0, x8
1004e8348:     	bl	0x100b334a8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004e834c:     	mov	x8, x0
1004e8350:     	mov	x0, x19
1004e8354:     	b	0x1004e8234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse31try_reuse_parse_object_template+0x4a4>
1004e8358:     	adrp	x3, 0x100f03000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1004e835c:     	add	x3, x3, #0xfe8
1004e8360:     	mov	x0, #0x0                ; =0
1004e8364:     	mov	x1, x25
1004e8368:     	mov	w2, #0x8                ; =8
1004e836c:     	bl	0x100b092cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1004e8370:     	adrp	x3, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1004e8374:     	add	x3, x3, #0x0
1004e8378:     	mov	x0, #0x0                ; =0
1004e837c:     	mov	x1, x21
1004e8380:     	mov	w2, #0x8                ; =8
1004e8384:     	bl	0x100b092cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
