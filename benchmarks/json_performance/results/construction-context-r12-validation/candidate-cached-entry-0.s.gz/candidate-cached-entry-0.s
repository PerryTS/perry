
benchmarks/json_performance/.work/construction-context-r12/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010083b944 <_js_json_parse>:
10083b944:     	stp	x29, x30, [sp, #-0x10]!
10083b948:     	mov	x29, sp
10083b94c:     	cbz	x0, 0x10083b9a4 <_js_json_parse+0x60>
10083b950:     	ldr	w1, [x0, #0x4]
10083b954:     	cmp	w1, #0x2
10083b958:     	b.eq	0x10083b968 <_js_json_parse+0x24>
10083b95c:     	cbz	w1, 0x10083b9a4 <_js_json_parse+0x60>
10083b960:     	ldrb	w8, [x0, #0x14]
10083b964:     	b	0x10083b988 <_js_json_parse+0x44>
10083b968:     	ldrb	w8, [x0, #0x14]
10083b96c:     	cmp	w8, #0x7b
10083b970:     	b.ne	0x10083b988 <_js_json_parse+0x44>
10083b974:     	ldrb	w8, [x0, #0x15]
10083b978:     	cmp	w8, #0x7d
10083b97c:     	b.ne	0x10083b994 <_js_json_parse+0x50>
10083b980:     	ldp	x29, x30, [sp], #0x10
10083b984:     	b	0x1004e7040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
10083b988:     	orr	w8, w8, #0x20
10083b98c:     	cmp	w8, #0x7b
10083b990:     	b.ne	0x10083b99c <_js_json_parse+0x58>
10083b994:     	ldp	x29, x30, [sp], #0x10
10083b998:     	b	0x100500b38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
10083b99c:     	ldp	x29, x30, [sp], #0x10
10083b9a0:     	b	0x1005032e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
10083b9a4:     	adrp	x0, 0x100c6b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x661c>
10083b9a8:     	add	x0, x0, #0xec1
10083b9ac:     	mov	w1, #0x1c               ; =28
10083b9b0:     	bl	0x100503714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
