
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/construction-context-r12/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010016f38c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_>:
10016f38c:     	sub	sp, sp, #0x60
10016f390:     	stp	x24, x23, [sp, #0x20]
10016f394:     	stp	x22, x21, [sp, #0x30]
10016f398:     	stp	x20, x19, [sp, #0x40]
10016f39c:     	stp	x29, x30, [sp, #0x50]
10016f3a0:     	add	x29, sp, #0x50
10016f3a4:     	mov	x19, x2
10016f3a8:     	mov	x20, x1
10016f3ac:     	cmp	x2, #0x40
10016f3b0:     	b.hs	0x10016f4bc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x130>
10016f3b4:     	ands	x9, x19, #0x38
10016f3b8:     	b.eq	0x10016f3dc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x50>
10016f3bc:     	and	x8, x19, #0x38
10016f3c0:     	neg	x8, x8
10016f3c4:     	mov	x10, x20
10016f3c8:     	ldr	x11, [x10], #0x8
10016f3cc:     	tst	x11, #0x8080808080808080
10016f3d0:     	b.ne	0x10016f450 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xc4>
10016f3d4:     	adds	x8, x8, #0x8
10016f3d8:     	b.ne	0x10016f3c8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x3c>
10016f3dc:     	and	x8, x19, #0x7
10016f3e0:     	cbz	x8, 0x10016f53c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b0>
10016f3e4:     	add	x9, x20, x9
10016f3e8:     	ldrsb	w10, [x9]
10016f3ec:     	tbnz	w10, #0x1f, 0x10016f450 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xc4>
10016f3f0:     	cmp	x8, #0x1
10016f3f4:     	b.eq	0x10016f53c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b0>
10016f3f8:     	ldrsb	w10, [x9, #0x1]
10016f3fc:     	tbnz	w10, #0x1f, 0x10016f450 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xc4>
10016f400:     	cmp	x8, #0x2
10016f404:     	b.eq	0x10016f53c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b0>
10016f408:     	ldrsb	w10, [x9, #0x2]
10016f40c:     	tbnz	w10, #0x1f, 0x10016f450 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xc4>
10016f410:     	cmp	x8, #0x3
10016f414:     	b.eq	0x10016f53c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b0>
10016f418:     	ldrsb	w10, [x9, #0x3]
10016f41c:     	tbnz	w10, #0x1f, 0x10016f450 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xc4>
10016f420:     	cmp	x8, #0x4
10016f424:     	b.eq	0x10016f53c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b0>
10016f428:     	ldrsb	w10, [x9, #0x4]
10016f42c:     	tbnz	w10, #0x1f, 0x10016f450 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xc4>
10016f430:     	cmp	x8, #0x5
10016f434:     	b.eq	0x10016f53c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b0>
10016f438:     	ldrsb	w10, [x9, #0x5]
10016f43c:     	tbnz	w10, #0x1f, 0x10016f450 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xc4>
10016f440:     	cmp	x8, #0x6
10016f444:     	b.eq	0x10016f53c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b0>
10016f448:     	ldrsb	w8, [x9, #0x6]
10016f44c:     	tbz	w8, #0x1f, 0x10016f53c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b0>
10016f450:     	cbz	w19, 0x10016f5ec <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x260>
10016f454:     	mov	w22, w19
10016f458:     	cbz	x22, 0x10016f53c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b0>
10016f45c:     	mov	x8, x20
10016f460:     	ands	x9, x19, #0x3
10016f464:     	b.eq	0x10016f480 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xf4>
10016f468:     	mov	x8, x20
10016f46c:     	ldrsb	w10, [x8]
10016f470:     	tbnz	w10, #0x1f, 0x10016f68c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x300>
10016f474:     	add	x8, x8, #0x1
10016f478:     	subs	x9, x9, #0x1
10016f47c:     	b.ne	0x10016f46c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xe0>
10016f480:     	cmp	x22, #0x4
10016f484:     	b.lo	0x10016f53c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b0>
10016f488:     	add	x9, x20, x22
10016f48c:     	ldrsb	w10, [x8]
10016f490:     	tbnz	w10, #0x1f, 0x10016f68c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x300>
10016f494:     	ldrsb	w10, [x8, #0x1]
10016f498:     	tbnz	w10, #0x1f, 0x10016f68c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x300>
10016f49c:     	ldrsb	w10, [x8, #0x2]
10016f4a0:     	tbnz	w10, #0x1f, 0x10016f68c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x300>
10016f4a4:     	ldrsb	w10, [x8, #0x3]
10016f4a8:     	tbnz	w10, #0x1f, 0x10016f68c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x300>
10016f4ac:     	add	x8, x8, #0x4
10016f4b0:     	cmp	x8, x9
10016f4b4:     	b.ne	0x10016f48c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x100>
10016f4b8:     	b	0x10016f53c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b0>
10016f4bc:     	and	x8, x19, #0x7fffffffffffffc0
10016f4c0:     	add	x8, x20, x8
10016f4c4:     	mov	x9, x20
10016f4c8:     	ldp	q0, q1, [x9]
10016f4cc:     	ldp	q2, q3, [x9, #0x20]
10016f4d0:     	orr.16b	v0, v1, v0
10016f4d4:     	orr.16b	v1, v2, v3
10016f4d8:     	orr.16b	v0, v0, v1
10016f4dc:     	umaxv.16b	b0, v0
10016f4e0:     	fmov	w10, s0
10016f4e4:     	tbnz	w10, #0x7, 0x10016f450 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xc4>
10016f4e8:     	add	x9, x9, #0x40
10016f4ec:     	cmp	x9, x8
10016f4f0:     	b.ne	0x10016f4c8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x13c>
10016f4f4:     	ands	x9, x19, #0x30
10016f4f8:     	b.eq	0x10016f51c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x190>
10016f4fc:     	mov	x10, x9
10016f500:     	mov	x11, x8
10016f504:     	ldr	q0, [x11], #0x10
10016f508:     	umaxv.16b	b0, v0
10016f50c:     	fmov	w12, s0
10016f510:     	tbnz	w12, #0x7, 0x10016f450 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xc4>
10016f514:     	subs	x10, x10, #0x10
10016f518:     	b.ne	0x10016f504 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x178>
10016f51c:     	and	x10, x19, #0xf
10016f520:     	cbz	x10, 0x10016f53c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b0>
10016f524:     	add	x8, x8, x9
10016f528:     	ldrsb	w9, [x8]
10016f52c:     	tbnz	w9, #0x1f, 0x10016f450 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0xc4>
10016f530:     	add	x8, x8, #0x1
10016f534:     	subs	x10, x10, #0x1
10016f538:     	b.ne	0x10016f528 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x19c>
10016f53c:     	mov	x22, x19
10016f540:     	mov	x21, x19
10016f544:     	lsr	w8, w22, #19
10016f548:     	cbz	w8, 0x10016f5dc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x250>
10016f54c:     	mov	w24, w19
10016f550:     	add	x0, x24, #0x14
10016f554:     	mov	w1, #0x3                ; =3
10016f558:     	bl	0x1004537c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
10016f55c:     	mov	x23, x0
10016f560:     	stp	w21, w22, [x0]
10016f564:     	str	w22, [x0, #0x8]
10016f568:     	mov	x8, #0x200000000        ; =8589934592
10016f56c:     	stur	x8, [x0, #0xc]
10016f570:     	add	x0, x0, #0x14
10016f574:     	mov	x1, x20
10016f578:     	mov	x2, x19
10016f57c:     	bl	0x100b5872c <_writev+0x100b5872c>
10016f580:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
10016f584:     	ldr	w19, [x8, #0x590]
10016f588:     	cmp	w19, #0x300
10016f58c:     	b.hs	0x10016f7b4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x428>
10016f590:     	adrp	x8, 0x100f74000 <_perry_global_rotating_worker_ts__1>
10016f594:     	ldr	x8, [x8, #0x48]
10016f598:     	cmn	x8, #0x1
10016f59c:     	b.eq	0x10016f7a4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x418>
10016f5a0:     	mrs	x9, TPIDRRO_EL0
10016f5a4:     	and	x9, x9, #0xfffffffffffffff8
10016f5a8:     	ldr	x0, [x9, x8, lsl #3]
10016f5ac:     	cbz	x0, 0x10016f7a4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x418>
10016f5b0:     	add	x8, x0, x19, lsl #3
10016f5b4:     	ldr	x0, [x8, #0x1e8]
10016f5b8:     	cbz	x0, 0x10016f7b4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x428>
10016f5bc:     	ldr	x8, [x0]
10016f5c0:     	adds	x8, x8, x24
10016f5c4:     	csinv	x8, x8, xzr, lo
10016f5c8:     	str	x8, [x0]
10016f5cc:     	lsr	x8, x8, #25
10016f5d0:     	cbz	x8, 0x10016f670 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2e4>
10016f5d4:     	bl	0x10045a8f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
10016f5d8:     	b	0x10016f670 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2e4>
10016f5dc:     	add	x8, x19, #0x14
10016f5e0:     	ldr	x9, [x0]
10016f5e4:     	cbnz	x9, 0x10016f604 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x278>
10016f5e8:     	b	0x10016f644 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2b8>
10016f5ec:     	mov	w21, #0x0               ; =0
10016f5f0:     	mov	w22, #0x0               ; =0
10016f5f4:     	mov	w8, #0x14               ; =20
10016f5f8:     	orr	x8, x19, x8
10016f5fc:     	ldr	x9, [x0]
10016f600:     	cbz	x9, 0x10016f644 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2b8>
10016f604:     	add	x9, x19, #0x23
10016f608:     	and	x9, x9, #0x7ffffffffffffff8
10016f60c:     	and	x9, x9, #0xffffffff000fffff
10016f610:     	cmp	x9, #0x4, lsl #12       ; =0x4000
10016f614:     	b.hi	0x10016f644 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2b8>
10016f618:     	ldr	x10, [x0, #0x10]
10016f61c:     	ldrb	w10, [x10]
10016f620:     	tbnz	w10, #0x0, 0x10016f644 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2b8>
10016f624:     	ldr	x10, [x0, #0x8]
10016f628:     	ldp	x11, x12, [x10, #0x8]
10016f62c:     	add	x11, x11, #0x7
10016f630:     	and	x11, x11, #0xfffffffffffffff8
10016f634:     	subs	x12, x12, x11
10016f638:     	csel	x12, xzr, x12, lo
10016f63c:     	cmp	x9, x12
10016f640:     	b.ls	0x10016f73c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x3b0>
10016f644:     	mov	x0, x22
10016f648:     	bl	0x1003464ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10016f64c:     	mov	x23, x0
10016f650:     	mov	x0, x1
10016f654:     	stp	w21, w22, [x23]
10016f658:     	str	w22, [x23, #0x8]
10016f65c:     	mov	x8, #0x200000000        ; =8589934592
10016f660:     	stur	x8, [x23, #0xc]
10016f664:     	mov	x1, x20
10016f668:     	mov	x2, x19
10016f66c:     	bl	0x100b5872c <_writev+0x100b5872c>
10016f670:     	mov	x0, x23
10016f674:     	ldp	x29, x30, [sp, #0x50]
10016f678:     	ldp	x20, x19, [sp, #0x40]
10016f67c:     	ldp	x22, x21, [sp, #0x30]
10016f680:     	ldp	x24, x23, [sp, #0x20]
10016f684:     	add	sp, sp, #0x60
10016f688:     	ret
10016f68c:     	mov	x23, x0
10016f690:     	cmp	w19, #0x3f
10016f694:     	b.ls	0x10016f6b4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x328>
10016f698:     	mov	x0, x20
10016f69c:     	mov	x1, x22
10016f6a0:     	bl	0x1005e6c20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
10016f6a4:     	mov	x21, x0
10016f6a8:     	mov	x22, x19
10016f6ac:     	mov	x0, x23
10016f6b0:     	b	0x10016f544 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b8>
10016f6b4:     	add	x8, sp, #0x8
10016f6b8:     	mov	x0, x20
10016f6bc:     	mov	x1, x22
10016f6c0:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10016f6c4:     	ldr	x8, [sp, #0x8]
10016f6c8:     	cbz	x8, 0x10016f780 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x3f4>
10016f6cc:     	mov	w21, #0x0               ; =0
10016f6d0:     	mov	x8, #0x0                ; =0
10016f6d4:     	mov	w9, #0x2                ; =2
10016f6d8:     	mov	w10, #0x3               ; =3
10016f6dc:     	mov	w11, #0x4               ; =4
10016f6e0:     	mov	x0, x23
10016f6e4:     	b	0x10016f6fc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x370>
10016f6e8:     	add	w21, w21, #0x1
10016f6ec:     	mov	w12, #0x1               ; =1
10016f6f0:     	add	x8, x12, x8
10016f6f4:     	cmp	x8, x22
10016f6f8:     	b.hs	0x10016fb08 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x77c>
10016f6fc:     	ldrsb	w12, [x20, x8]
10016f700:     	tbz	w12, #0x1f, 0x10016f6e8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x35c>
10016f704:     	and	w12, w12, #0xff
10016f708:     	cmp	w12, #0xc0
10016f70c:     	b.lo	0x10016f6ec <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x360>
10016f710:     	cmp	w12, #0xf0
10016f714:     	add	w13, w21, #0x2
10016f718:     	csel	x14, x10, x11, lo
10016f71c:     	csinc	w13, w13, w21, hs
10016f720:     	cmp	w12, #0xe0
10016f724:     	csel	x12, x9, x14, lo
10016f728:     	csinc	w21, w13, w21, hs
10016f72c:     	add	x8, x12, x8
10016f730:     	cmp	x8, x22
10016f734:     	b.lo	0x10016f6fc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x370>
10016f738:     	b	0x10016fb08 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x77c>
10016f73c:     	ldr	x12, [x10]
10016f740:     	add	x24, x12, x11
10016f744:     	add	x11, x11, x9
10016f748:     	str	x11, [x10, #0x8]
10016f74c:     	mov	w10, #0x203             ; =515
10016f750:     	stp	w10, w9, [x24]
10016f754:     	add	x23, x24, #0x8
10016f758:     	subs	x9, x9, #0x8
10016f75c:     	csel	x9, xzr, x9, lo
10016f760:     	subs	x10, x9, x8
10016f764:     	csel	x1, xzr, x10, lo
10016f768:     	b.ls	0x10016f804 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x478>
10016f76c:     	cmp	x1, #0x9
10016f770:     	b.hs	0x10016f7fc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x470>
10016f774:     	add	x8, x23, x9
10016f778:     	stur	xzr, [x8, #-0x8]
10016f77c:     	b	0x10016f804 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x478>
10016f780:     	ldr	x8, [sp, #0x18]
10016f784:     	mov	x0, x23
10016f788:     	cbz	x8, 0x10016f7dc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x450>
10016f78c:     	ldr	x9, [sp, #0x10]
10016f790:     	cmp	x8, #0x8
10016f794:     	b.hs	0x10016f7e8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x45c>
10016f798:     	mov	x10, #0x0               ; =0
10016f79c:     	mov	w21, #0x0               ; =0
10016f7a0:     	b	0x10016fad0 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x744>
10016f7a4:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10016f7a8:     	add	x8, x0, x19, lsl #3
10016f7ac:     	ldr	x0, [x8, #0x1e8]
10016f7b0:     	cbnz	x0, 0x10016f5bc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x230>
10016f7b4:     	adrp	x0, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10016f7b8:     	add	x0, x0, #0x78
10016f7bc:     	bl	0x100b3345c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10016f7c0:     	ldr	x8, [x0]
10016f7c4:     	adds	x8, x8, x24
10016f7c8:     	csinv	x8, x8, xzr, lo
10016f7cc:     	str	x8, [x0]
10016f7d0:     	lsr	x8, x8, #25
10016f7d4:     	cbnz	x8, 0x10016f5d4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x248>
10016f7d8:     	b	0x10016f670 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2e4>
10016f7dc:     	mov	w21, #0x0               ; =0
10016f7e0:     	mov	x22, x19
10016f7e4:     	b	0x10016f544 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b8>
10016f7e8:     	cmp	x8, #0x20
10016f7ec:     	b.hs	0x10016f81c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x490>
10016f7f0:     	mov	x10, #0x0               ; =0
10016f7f4:     	mov	w21, #0x0               ; =0
10016f7f8:     	b	0x10016fa20 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x694>
10016f7fc:     	add	x0, x23, x8
10016f800:     	bl	0x100b58264 <_writev+0x100b58264>
10016f804:     	stp	w21, w22, [x24, #0x8]
10016f808:     	str	w22, [x24, #0x10]
10016f80c:     	mov	x8, #0x200000000        ; =8589934592
10016f810:     	stur	x8, [x24, #0x14]
10016f814:     	add	x0, x24, #0x1c
10016f818:     	b	0x10016f664 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x2d8>
10016f81c:     	movi.2d	v0, #0000000000000000
10016f820:     	and	x11, x8, #0x18
10016f824:     	movi.16b	v1, #0xf0
10016f828:     	and	x10, x8, #0xffffffffffffffe0
10016f82c:     	movi.4s	v2, #0x2
10016f830:     	add	x12, x9, #0x10
10016f834:     	movi.16b	v4, #0xc0
10016f838:     	and	x13, x8, #0xffffffffffffffe0
10016f83c:     	movi.2d	v3, #0000000000000000
10016f840:     	movi.2d	v6, #0000000000000000
10016f844:     	movi.2d	v5, #0000000000000000
10016f848:     	movi.2d	v7, #0000000000000000
10016f84c:     	movi.2d	v16, #0000000000000000
10016f850:     	movi.2d	v17, #0000000000000000
10016f854:     	movi.2d	v18, #0000000000000000
10016f858:     	ldp	q20, q19, [x12, #-0x10]
10016f85c:     	cmhi.16b	v21, v1, v20
10016f860:     	sshll2.8h	v22, v21, #0x0
10016f864:     	sshll2.4s	v23, v22, #0x0
10016f868:     	sshll.4s	v24, v22, #0x0
10016f86c:     	sshll.8h	v21, v21, #0x0
10016f870:     	sshll2.4s	v25, v21, #0x0
10016f874:     	sshll.4s	v26, v21, #0x0
10016f878:     	cmhi.16b	v27, v1, v19
10016f87c:     	sshll2.8h	v28, v27, #0x0
10016f880:     	sshll2.4s	v29, v28, #0x0
10016f884:     	sshll.4s	v30, v28, #0x0
10016f888:     	sshll.8h	v27, v27, #0x0
10016f88c:     	sshll2.4s	v31, v27, #0x0
10016f890:     	bic.16b	v26, v2, v26
10016f894:     	ssubw.4s	v26, v26, v21
10016f898:     	bic.16b	v25, v2, v25
10016f89c:     	ssubw2.4s	v25, v25, v21
10016f8a0:     	sshll.4s	v21, v27, #0x0
10016f8a4:     	bic.16b	v24, v2, v24
10016f8a8:     	ssubw.4s	v24, v24, v22
10016f8ac:     	bic.16b	v23, v2, v23
10016f8b0:     	ssubw2.4s	v22, v23, v22
10016f8b4:     	bic.16b	v21, v2, v21
10016f8b8:     	ssubw.4s	v21, v21, v27
10016f8bc:     	bic.16b	v23, v2, v31
10016f8c0:     	ssubw2.4s	v23, v23, v27
10016f8c4:     	bic.16b	v27, v2, v30
10016f8c8:     	ssubw.4s	v27, v27, v28
10016f8cc:     	bic.16b	v29, v2, v29
10016f8d0:     	ssubw2.4s	v28, v29, v28
10016f8d4:     	cmgt.16b	v29, v4, v20
10016f8d8:     	sshll2.8h	v30, v29, #0x0
10016f8dc:     	ushll2.4s	v31, v30, #0x0
10016f8e0:     	bic.16b	v22, v22, v31
10016f8e4:     	cmlt.16b	v20, v20, #0
10016f8e8:     	sshll.8h	v29, v29, #0x0
10016f8ec:     	ushll.4s	v30, v30, #0x0
10016f8f0:     	bic.16b	v24, v24, v30
10016f8f4:     	ushll2.4s	v30, v29, #0x0
10016f8f8:     	bic.16b	v25, v25, v30
10016f8fc:     	sshll2.8h	v30, v20, #0x0
10016f900:     	sshll.8h	v20, v20, #0x0
10016f904:     	ushll.4s	v29, v29, #0x0
10016f908:     	bic.16b	v26, v26, v29
10016f90c:     	sshll.4s	v29, v20, #0x0
10016f910:     	and.16b	v26, v26, v29
10016f914:     	mvn.16b	v29, v29
10016f918:     	sub.4s	v26, v26, v29
10016f91c:     	sshll2.4s	v29, v30, #0x0
10016f920:     	sshll.4s	v30, v30, #0x0
10016f924:     	sshll2.4s	v20, v20, #0x0
10016f928:     	and.16b	v25, v25, v20
10016f92c:     	mvn.16b	v20, v20
10016f930:     	sub.4s	v20, v25, v20
10016f934:     	cmgt.16b	v25, v4, v19
10016f938:     	and.16b	v24, v24, v30
10016f93c:     	mvn.16b	v30, v30
10016f940:     	sub.4s	v24, v24, v30
10016f944:     	sshll2.8h	v30, v25, #0x0
10016f948:     	and.16b	v22, v22, v29
10016f94c:     	mvn.16b	v29, v29
10016f950:     	sub.4s	v22, v22, v29
10016f954:     	ushll2.4s	v29, v30, #0x0
10016f958:     	bic.16b	v28, v28, v29
10016f95c:     	cmlt.16b	v19, v19, #0
10016f960:     	sshll.8h	v25, v25, #0x0
10016f964:     	ushll.4s	v29, v30, #0x0
10016f968:     	bic.16b	v27, v27, v29
10016f96c:     	ushll2.4s	v29, v25, #0x0
10016f970:     	bic.16b	v23, v23, v29
10016f974:     	sshll.8h	v29, v19, #0x0
10016f978:     	ushll.4s	v25, v25, #0x0
10016f97c:     	bic.16b	v21, v21, v25
10016f980:     	sshll.4s	v25, v29, #0x0
10016f984:     	and.16b	v21, v21, v25
10016f988:     	mvn.16b	v25, v25
10016f98c:     	sub.4s	v21, v21, v25
10016f990:     	sshll2.8h	v19, v19, #0x0
10016f994:     	sshll2.4s	v25, v29, #0x0
10016f998:     	and.16b	v23, v23, v25
10016f99c:     	mvn.16b	v25, v25
10016f9a0:     	sub.4s	v23, v23, v25
10016f9a4:     	sshll.4s	v25, v19, #0x0
10016f9a8:     	and.16b	v27, v27, v25
10016f9ac:     	mvn.16b	v25, v25
10016f9b0:     	sub.4s	v25, v27, v25
10016f9b4:     	sshll2.4s	v19, v19, #0x0
10016f9b8:     	and.16b	v27, v28, v19
10016f9bc:     	mvn.16b	v19, v19
10016f9c0:     	sub.4s	v19, v27, v19
10016f9c4:     	add.4s	v7, v22, v7
10016f9c8:     	add.4s	v5, v24, v5
10016f9cc:     	add.4s	v6, v20, v6
10016f9d0:     	add.4s	v3, v26, v3
10016f9d4:     	add.4s	v18, v19, v18
10016f9d8:     	add.4s	v17, v25, v17
10016f9dc:     	add.4s	v0, v23, v0
10016f9e0:     	add.4s	v16, v21, v16
10016f9e4:     	add	x12, x12, #0x20
10016f9e8:     	subs	x13, x13, #0x20
10016f9ec:     	b.ne	0x10016f858 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x4cc>
10016f9f0:     	add.4s	v0, v0, v6
10016f9f4:     	add.4s	v1, v18, v7
10016f9f8:     	add.4s	v2, v16, v3
10016f9fc:     	add.4s	v3, v17, v5
10016fa00:     	add.4s	v2, v2, v3
10016fa04:     	add.4s	v0, v0, v1
10016fa08:     	add.4s	v0, v2, v0
10016fa0c:     	addv.4s	s0, v0
10016fa10:     	fmov	w21, s0
10016fa14:     	cmp	x8, x10
10016fa18:     	b.eq	0x10016fb08 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x77c>
10016fa1c:     	cbz	x11, 0x10016fad0 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x744>
10016fa20:     	mov	x12, x10
10016fa24:     	and	x10, x8, #0xfffffffffffffff8
10016fa28:     	movi.2d	v0, #0000000000000000
10016fa2c:     	mov.s	v0[0], w21
10016fa30:     	movi.2d	v1, #0000000000000000
10016fa34:     	sub	x11, x12, x10
10016fa38:     	add	x12, x9, x12
10016fa3c:     	movi.8b	v2, #0xf0
10016fa40:     	movi.4s	v3, #0x2
10016fa44:     	movi.8b	v4, #0xc0
10016fa48:     	ldr	d5, [x12], #0x8
10016fa4c:     	sshll.8h	v6, v5, #0x0
10016fa50:     	cmlt.8h	v6, v6, #0
10016fa54:     	sshll2.4s	v7, v6, #0x0
10016fa58:     	sshll.4s	v6, v6, #0x0
10016fa5c:     	cmhi.8b	v16, v2, v5
10016fa60:     	sshll.8h	v16, v16, #0x0
10016fa64:     	sshll2.4s	v17, v16, #0x0
10016fa68:     	sshll.4s	v18, v16, #0x0
10016fa6c:     	bic.16b	v18, v3, v18
10016fa70:     	ssubw.4s	v18, v18, v16
10016fa74:     	bic.16b	v17, v3, v17
10016fa78:     	ssubw2.4s	v16, v17, v16
10016fa7c:     	cmgt.8b	v5, v4, v5
10016fa80:     	sshll.8h	v5, v5, #0x0
10016fa84:     	ushll.4s	v17, v5, #0x0
10016fa88:     	ushll2.4s	v5, v5, #0x0
10016fa8c:     	bic.16b	v5, v16, v5
10016fa90:     	bic.16b	v16, v18, v17
10016fa94:     	and.16b	v16, v16, v6
10016fa98:     	mvn.16b	v6, v6
10016fa9c:     	sub.4s	v6, v16, v6
10016faa0:     	and.16b	v5, v5, v7
10016faa4:     	mvn.16b	v7, v7
10016faa8:     	sub.4s	v5, v5, v7
10016faac:     	add.4s	v1, v5, v1
10016fab0:     	add.4s	v0, v6, v0
10016fab4:     	adds	x11, x11, #0x8
10016fab8:     	b.ne	0x10016fa48 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x6bc>
10016fabc:     	add.4s	v0, v0, v1
10016fac0:     	addv.4s	s0, v0
10016fac4:     	fmov	w21, s0
10016fac8:     	cmp	x8, x10
10016facc:     	b.eq	0x10016fb08 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x77c>
10016fad0:     	sub	x8, x8, x10
10016fad4:     	add	x9, x9, x10
10016fad8:     	mov	w10, #0x1               ; =1
10016fadc:     	ldrsb	w11, [x9], #0x1
10016fae0:     	and	w12, w11, #0xff
10016fae4:     	cmp	w12, #0xf0
10016fae8:     	cinc	w13, w10, hs
10016faec:     	cmp	w12, #0xc0
10016faf0:     	csel	w12, wzr, w13, lo
10016faf4:     	tst	w11, #0x80000000
10016faf8:     	csinc	w11, w12, wzr, ne
10016fafc:     	add	w21, w11, w21
10016fb00:     	subs	x8, x8, #0x1
10016fb04:     	b.ne	0x10016fadc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x750>
10016fb08:     	mov	x22, x19
10016fb0c:     	b	0x10016f544 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesINtNtCsjgY6bXVaRmE_4core6option6OptionNtNtNtB6_5arena12construction17ConstructionBatchEEB6_+0x1b8>
