
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/construction-context-r12/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010025aa9c <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value>:
10025aa9c:     	sub	sp, sp, #0x60
10025aaa0:     	stp	x24, x23, [sp, #0x20]
10025aaa4:     	stp	x22, x21, [sp, #0x30]
10025aaa8:     	stp	x20, x19, [sp, #0x40]
10025aaac:     	stp	x29, x30, [sp, #0x50]
10025aab0:     	add	x29, sp, #0x50
10025aab4:     	mov	x21, x0
10025aab8:     	ldr	x23, [x0, #0x70]
10025aabc:     	ldp	x8, x9, [x0]
10025aac0:     	cmp	x8, #0x0
10025aac4:     	ccmp	x9, x23, #0x0, ne
10025aac8:     	b.eq	0x10025aaf4 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x58>
10025aacc:     	add	x0, sp, #0x8
10025aad0:     	mov	x1, x21
10025aad4:     	bl	0x10025a64c <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
10025aad8:     	ldr	x22, [sp, #0x8]
10025aadc:     	cmn	x22, #0x2
10025aae0:     	b.ne	0x10025ab1c <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x80>
10025aae4:     	strb	wzr, [x21, #0xd4]
10025aae8:     	mov	x0, #0x2                ; =2
10025aaec:     	movk	x0, #0x7ffc, lsl #48
10025aaf0:     	b	0x10025ab04 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
10025aaf4:     	ldp	x8, x9, [x21, #0x10]
10025aaf8:     	str	x8, [x21, #0x70]
10025aafc:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
10025ab00:     	bfxil	x0, x9, #0, #48
10025ab04:     	ldp	x29, x30, [sp, #0x50]
10025ab08:     	ldp	x20, x19, [sp, #0x40]
10025ab0c:     	ldp	x22, x21, [sp, #0x30]
10025ab10:     	ldp	x24, x23, [sp, #0x20]
10025ab14:     	add	sp, sp, #0x60
10025ab18:     	ret
10025ab1c:     	ldp	x20, x19, [sp, #0x10]
10025ab20:     	cmp	x19, #0x6
10025ab24:     	b.hs	0x10025abb4 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
10025ab28:     	subs	x8, x19, #0x3
10025ab2c:     	b.lo	0x10025abe0 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
10025ab30:     	ldrb	w9, [x20]
10025ab34:     	cmp	w9, #0xed
10025ab38:     	b.ne	0x10025ab58 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xbc>
10025ab3c:     	ldrb	w9, [x20, #0x1]
10025ab40:     	and	w9, w9, #0xe0
10025ab44:     	cmp	w9, #0xa0
10025ab48:     	b.ne	0x10025ab58 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xbc>
10025ab4c:     	ldrsb	w9, [x20, #0x2]
10025ab50:     	cmn	w9, #0x40
10025ab54:     	b.lt	0x10025abb4 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
10025ab58:     	cbz	x8, 0x10025abe0 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
10025ab5c:     	ldrb	w9, [x20, #0x1]
10025ab60:     	cmp	w9, #0xed
10025ab64:     	b.ne	0x10025ab84 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xe8>
10025ab68:     	ldrb	w9, [x20, #0x2]
10025ab6c:     	and	w9, w9, #0xe0
10025ab70:     	cmp	w9, #0xa0
10025ab74:     	b.ne	0x10025ab84 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xe8>
10025ab78:     	ldrsb	w9, [x20, #0x3]
10025ab7c:     	cmn	w9, #0x40
10025ab80:     	b.lt	0x10025abb4 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
10025ab84:     	cmp	x8, #0x1
10025ab88:     	b.eq	0x10025abe0 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
10025ab8c:     	ldrb	w8, [x20, #0x2]
10025ab90:     	cmp	w8, #0xed
10025ab94:     	b.ne	0x10025abe0 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
10025ab98:     	ldrb	w8, [x20, #0x3]
10025ab9c:     	and	w8, w8, #0xe0
10025aba0:     	cmp	w8, #0xa0
10025aba4:     	b.ne	0x10025abe0 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
10025aba8:     	ldrsb	w8, [x20, #0x4]
10025abac:     	cmn	w8, #0x40
10025abb0:     	b.ge	0x10025abe0 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
10025abb4:     	cmn	x22, #0x1
10025abb8:     	b.eq	0x10025abfc <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x160>
10025abbc:     	mov	x0, x20
10025abc0:     	mov	x1, x19
10025abc4:     	bl	0x100346b30 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
10025abc8:     	mov	x8, x0
10025abcc:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
10025abd0:     	bfxil	x0, x8, #0, #48
10025abd4:     	cmp	x22, #0x1
10025abd8:     	b.ge	0x10025ad8c <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2f0>
10025abdc:     	b	0x10025ab04 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
10025abe0:     	cbz	x19, 0x10025acc0 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x224>
10025abe4:     	cmp	x19, #0x4
10025abe8:     	b.hs	0x10025acc8 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x22c>
10025abec:     	mov	x10, #0x0               ; =0
10025abf0:     	mov	x9, #0x0                ; =0
10025abf4:     	mov	x8, x20
10025abf8:     	b	0x10025ad58 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2bc>
10025abfc:     	mov	x0, x21
10025ac00:     	mov	x1, x20
10025ac04:     	mov	x2, x19
10025ac08:     	bl	0x10016ec7c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_>
10025ac0c:     	ldr	x22, [x21, #0x68]
10025ac10:     	cmp	x22, #0x200, lsl #12    ; =0x200000
10025ac14:     	b.hi	0x10025ae00 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
10025ac18:     	cmp	x19, #0x100
10025ac1c:     	b.lo	0x10025ae00 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
10025ac20:     	cbz	x0, 0x10025ae00 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
10025ac24:     	ldr	x20, [x21, #0xc8]
10025ac28:     	cbz	x20, 0x10025ae00 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
10025ac2c:     	ldr	x21, [x21, #0x70]
10025ac30:     	sub	x8, x22, x22, lsr #1
10025ac34:     	cmp	x19, x8
10025ac38:     	orr	x8, x21, x23
10025ac3c:     	and	x8, x8, #0xffffffff00000000
10025ac40:     	ccmp	x8, #0x0, #0x0, hs
10025ac44:     	b.ne	0x10025ae00 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
10025ac48:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
10025ac4c:     	ldr	w19, [x8, #0x560]
10025ac50:     	cmp	w19, #0x300
10025ac54:     	b.hs	0x10025ae2c <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x390>
10025ac58:     	adrp	x8, 0x100f74000 <_perry_global_rotating_worker_ts__1>
10025ac5c:     	ldr	x8, [x8, #0x48]
10025ac60:     	cmn	x8, #0x1
10025ac64:     	b.eq	0x10025ae10 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x374>
10025ac68:     	mrs	x9, TPIDRRO_EL0
10025ac6c:     	and	x9, x9, #0xfffffffffffffff8
10025ac70:     	ldr	x8, [x9, x8, lsl #3]
10025ac74:     	cbz	x8, 0x10025ae10 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x374>
10025ac78:     	add	x8, x8, x19, lsl #3
10025ac7c:     	ldr	x19, [x8, #0x1e8]
10025ac80:     	cbz	x19, 0x10025ae2c <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x390>
10025ac84:     	ldr	x8, [x19]
10025ac88:     	cbnz	x8, 0x10025ae4c <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3b0>
10025ac8c:     	mov	x8, #-0x1               ; =-1
10025ac90:     	str	x8, [x19]
10025ac94:     	ldrb	w8, [x19, #0x24]
10025ac98:     	cmp	w8, #0x2
10025ac9c:     	b.eq	0x10025ada0 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
10025aca0:     	ldr	x8, [x19, #0x8]
10025aca4:     	cmp	x8, x20
10025aca8:     	b.ne	0x10025ada0 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
10025acac:     	ldr	w8, [x19, #0x18]
10025acb0:     	cmp	w8, w22
10025acb4:     	b.ne	0x10025ada0 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
10025acb8:     	mov	x8, #0x0                ; =0
10025acbc:     	b	0x10025adfc <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x360>
10025acc0:     	mov	x10, #0x0               ; =0
10025acc4:     	b	0x10025ad78 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2dc>
10025acc8:     	and	x9, x19, #0x4
10025accc:     	add	x8, x20, x9
10025acd0:     	adrp	x10, 0x100c90000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5570>
10025acd4:     	ldr	q0, [x10, #0x300]
10025acd8:     	adrp	x10, 0x100c30000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33d7a>
10025acdc:     	ldr	q2, [x10, #0x200]
10025ace0:     	movi.2d	v1, #0000000000000000
10025ace4:     	movi.2d	v3, #0x000000000000ff
10025ace8:     	mov	w10, #0x4               ; =4
10025acec:     	dup.2d	v4, x10
10025acf0:     	mov	x10, x20
10025acf4:     	and	x11, x19, #0x4
10025acf8:     	movi.2d	v5, #0000000000000000
10025acfc:     	ldr	s6, [x10], #0x4
10025ad00:     	ushll.8h	v6, v6, #0x0
10025ad04:     	ushll.4s	v6, v6, #0x0
10025ad08:     	ushll2.2d	v7, v6, #0x0
10025ad0c:     	and.16b	v7, v7, v3
10025ad10:     	ushll.2d	v6, v6, #0x0
10025ad14:     	and.16b	v6, v6, v3
10025ad18:     	shl.2d	v16, v0, #0x3
10025ad1c:     	shl.2d	v17, v2, #0x3
10025ad20:     	ushl.2d	v6, v6, v17
10025ad24:     	ushl.2d	v7, v7, v16
10025ad28:     	orr.16b	v1, v7, v1
10025ad2c:     	orr.16b	v5, v6, v5
10025ad30:     	add.2d	v0, v0, v4
10025ad34:     	add.2d	v2, v2, v4
10025ad38:     	subs	x11, x11, #0x4
10025ad3c:     	b.ne	0x10025acfc <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x260>
10025ad40:     	orr.16b	v0, v5, v1
10025ad44:     	mov	d1, v0[1]
10025ad48:     	orr.8b	v0, v0, v1
10025ad4c:     	fmov	x10, d0
10025ad50:     	cmp	x19, x9
10025ad54:     	b.eq	0x10025ad78 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2dc>
10025ad58:     	add	x11, x20, x19
10025ad5c:     	lsl	x9, x9, #3
10025ad60:     	ldrb	w12, [x8], #0x1
10025ad64:     	lsl	x12, x12, x9
10025ad68:     	orr	x10, x12, x10
10025ad6c:     	add	x9, x9, #0x8
10025ad70:     	cmp	x8, x11
10025ad74:     	b.ne	0x10025ad60 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2c4>
10025ad78:     	orr	x8, x10, x19, lsl #40
10025ad7c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10025ad80:     	orr	x0, x8, x9
10025ad84:     	cmp	x22, #0x1
10025ad88:     	b.lt	0x10025ab04 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
10025ad8c:     	mov	x19, x0
10025ad90:     	mov	x0, x20
10025ad94:     	bl	0x100b55880 <_mi_free>
10025ad98:     	mov	x0, x19
10025ad9c:     	b	0x10025ab04 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
10025ada0:     	stp	x20, x0, [x19, #0x8]
10025ada4:     	stp	w22, w23, [x19, #0x18]
10025ada8:     	str	w21, [x19, #0x20]
10025adac:     	strb	wzr, [x19, #0x24]
10025adb0:     	adrp	x21, 0x101055000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf85c>
10025adb4:     	ldr	w8, [x21, #0x7a4]
10025adb8:     	cbz	w8, 0x10025add4 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x338>
10025adbc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10025adc0:     	bfxil	x8, x20, #0, #48
10025adc4:     	mov	x20, x0
10025adc8:     	mov	x0, x8
10025adcc:     	bl	0x100471d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
10025add0:     	mov	x0, x20
10025add4:     	ldr	w8, [x21, #0x7a4]
10025add8:     	cbz	w8, 0x10025adf4 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x358>
10025addc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10025ade0:     	bfxil	x8, x0, #0, #48
10025ade4:     	mov	x20, x0
10025ade8:     	mov	x0, x8
10025adec:     	bl	0x100471d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
10025adf0:     	mov	x0, x20
10025adf4:     	ldr	x8, [x19]
10025adf8:     	add	x8, x8, #0x1
10025adfc:     	str	x8, [x19]
10025ae00:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
10025ae04:     	bfxil	x8, x0, #0, #48
10025ae08:     	mov	x0, x8
10025ae0c:     	b	0x10025ab04 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
10025ae10:     	mov	x24, x0
10025ae14:     	bl	0x100b35c3c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10025ae18:     	mov	x8, x0
10025ae1c:     	mov	x0, x24
10025ae20:     	add	x8, x8, x19, lsl #3
10025ae24:     	ldr	x19, [x8, #0x1e8]
10025ae28:     	cbnz	x19, 0x10025ac84 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1e8>
10025ae2c:     	str	x0, [sp]
10025ae30:     	adrp	x0, 0x100f03000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
10025ae34:     	add	x0, x0, #0xfa0
10025ae38:     	bl	0x100b3345c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10025ae3c:     	mov	x19, x0
10025ae40:     	ldr	x0, [sp]
10025ae44:     	ldr	x8, [x19]
10025ae48:     	cbz	x8, 0x10025ac8c <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1f0>
10025ae4c:     	adrp	x0, 0x100ef1000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
10025ae50:     	add	x0, x0, #0xce0
10025ae54:     	bl	0x100b08fac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
		...
