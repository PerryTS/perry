; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/borrowed-template-r13/candidate-ir-native/test_json_cached_template_borrow/.perry-trace/llvm/test_json_cached_template_borrow_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@test_json_cached_template_borrow_ts_.str.0 = private unnamed_addr constant [140 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/borrowed-template-r13/test_json_cached_template_borrow.ts\00"
@test_json_cached_template_borrow_ts_.str.0.bytes = private unnamed_addr constant [6 x i8] c"value\00"
@test_json_cached_template_borrow_ts_.str.1.bytes = private unnamed_addr constant [9 x i8] c"expected\00"
@test_json_cached_template_borrow_ts_.str.2.bytes = private unnamed_addr constant [3 x i8] c"id\00"
@test_json_cached_template_borrow_ts_.str.3.bytes = private unnamed_addr constant [5 x i8] c"name\00"
@test_json_cached_template_borrow_ts_.str.4.bytes = private unnamed_addr constant [107 x i8] c"{\22padding\22:\22enough-padding-to-enter-the-small-object-template-path\22,\22items\22:[\22alpha-value\22,2,true],\22id\22:7}\00"
@test_json_cached_template_borrow_ts_.str.5.bytes = private unnamed_addr constant [108 x i8] c"{\22padding\22:\22another-padding-to-enter-the-small-object-template-path\22,\22items\22:[\22beta-value\22,false,3],\22id\22:8}\00"
@test_json_cached_template_borrow_ts_.str.6.bytes = private unnamed_addr constant [110 x i8] c"{\22padding\22:\22different-padding-to-enter-the-small-object-template-path\22,\22items\22:[\22gamma-value\22,4,null],\22id\22:9}\00"
@test_json_cached_template_borrow_ts_.str.7.bytes = private unnamed_addr constant [6 x i8] c"items\00"
@test_json_cached_template_borrow_ts_.str.8.bytes = private unnamed_addr constant [8 x i8] c"changed\00"
@test_json_cached_template_borrow_ts_.str.9.bytes = private unnamed_addr constant [5 x i8] c"push\00"
@test_json_cached_template_borrow_ts_.str.10.bytes = private unnamed_addr constant [7 x i8] c"length\00"
@test_json_cached_template_borrow_ts_.str.11.bytes = private unnamed_addr constant [32 x i8] c"cached mutable array was shared\00"
@test_json_cached_template_borrow_ts_.str.12.bytes = private unnamed_addr constant [24 x i8] c"cached template changed\00"
@test_json_cached_template_borrow_ts_.str.13.bytes = private unnamed_addr constant [10 x i8] c"pressure-\00"
@test_json_cached_template_borrow_ts_.str.14.bytes = private unnamed_addr constant [23 x i8] c"retained value changed\00"
@test_json_cached_template_borrow_ts_.str.15.bytes = private unnamed_addr constant [6 x i8] c"saved\00"
@test_json_cached_template_borrow_ts_.str.16.bytes = private unnamed_addr constant [5 x i8] c"done\00"
@perry_class_keys_packed_test_json_cached_template_borrow_ts__0 = private unnamed_addr constant [16 x i8] c"value\00expected\00\00"
@perry_class_keys_packed_test_json_cached_template_borrow_ts__1 = private unnamed_addr constant [9 x i8] c"id\00name\00\00"
@test_json_cached_template_borrow_ts_.str.1 = private unnamed_addr constant [33 x i8] c"new __AnonShape_a0fce79cb5df4a18\00"
@test_json_cached_template_borrow_ts_.str.2 = private unnamed_addr constant [33 x i8] c"new __AnonShape_570a27fd5b93ea38\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_test_json_cached_template_borrow_ts = internal global i32 0
@perry_class_keys_test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18 = internal global i64 0
@perry_class_shape_id_test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18 = global i32 0
@perry_class_header_image_test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18 = internal global <2 x i64> zeroinitializer
@perry_class_keys_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38 = internal global i64 0
@perry_class_shape_id_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38 = global i32 0
@perry_class_header_image_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38 = internal global <2 x i64> zeroinitializer
@perry_ic_test_json_cached_template_borrow_ts__6 = private global ptr null
@perry_ic_test_json_cached_template_borrow_ts__8 = private global ptr null
@perry_ic_test_json_cached_template_borrow_ts__11 = private global ptr null
@perry_ic_test_json_cached_template_borrow_ts__13 = private global ptr null
@perry_ic_test_json_cached_template_borrow_ts__15 = private global ptr null
@perry_ic_test_json_cached_template_borrow_ts__16 = private global ptr null
@perry_ic_test_json_cached_template_borrow_ts__19 = private global ptr null
@perry_ic_test_json_cached_template_borrow_ts__22 = private global ptr null
@perry_ic_test_json_cached_template_borrow_ts__23 = private global ptr null
@perry_ic_test_json_cached_template_borrow_ts__29 = private global ptr null
@perry_ic_test_json_cached_template_borrow_ts__32 = private global ptr null
@perry_ic_test_json_cached_template_borrow_ts__33 = private global ptr null
@perry_ic_test_json_cached_template_borrow_ts__34 = private global ptr null
@perry_concat_site_test_json_cached_template_borrow_ts__17 = private global [32 x i64] zeroinitializer
@test_json_cached_template_borrow_ts_.str.0.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.1.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.2.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.3.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.4.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.5.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.6.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.7.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.8.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.9.dispatch = private unnamed_addr constant { i32, i32, i64, ptr } { i32 4, i32 0, i64 7818252312440358301, ptr @test_json_cached_template_borrow_ts_.str.9.bytes }
@test_json_cached_template_borrow_ts_.str.9.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.10.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.11.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.12.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.13.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.14.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.15.handle = internal global double 0.000000e+00
@test_json_cached_template_borrow_ts_.str.16.handle = internal global double 0.000000e+00
@perry_typed_shape_mask_test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18 = private unnamed_addr constant [1 x i64] [i64 3]
@perry_typed_shape_raw_f64_mask_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38 = private unnamed_addr constant [1 x i64] [i64 1]
@perry_typed_shape_mask_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38 = private unnamed_addr constant [1 x i64] [i64 2]

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_6()

declare double @__ic_decl_8()

declare double @__ic_decl_11()

declare double @__ic_decl_13()

declare double @__ic_decl_15()

declare double @__ic_decl_19()

declare double @__ic_decl_22()

declare double @__ic_decl_29()

declare double @__ic_decl_32()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define double @test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18_constructor(double %this_arg, double %arg8, double %arg9) #6 gc "statepoint-example" {
entry.0:
  %r8 = load i32, ptr @perry_class_shape_id_test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg8 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg9 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #7
  %r5 = bitcast i64 %r5.rs4o to double
  %r6.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r6.rs4o = call i64 asm "", "=r,0"(i64 %r6.rs4i) #7
  %r6 = bitcast i64 %r6.rs4o to double
  %r10 = bitcast double %r5 to i64
  %r11 = and i64 %r10, 281474976710655
  %r12 = load double, ptr @test_json_cached_template_borrow_ts_.str.0.handle, align 8
  %r13 = bitcast double %r12 to i64
  %r14 = and i64 %r13, 281474976710655
  %r15 = bitcast double %r6 to i64
  %r16 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r17 = icmp eq i8 %r16, 0
  %r18 = lshr i64 %r10, 48
  %r19 = icmp eq i64 %r18, 32765
  %r20 = icmp ugt i64 %r11, 1048575
  %r21 = and i1 %r19, %r20
  %r22 = and i1 %r21, %r17
  br i1 %r22, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.14
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r230.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r230.rs4o = call i64 asm "", "=r,0"(i64 %r230.rs4i) #7
  %r230 = bitcast i64 %r230.rs4o to double
  %r231 = bitcast double %r230 to i64
  %r232 = and i64 %r231, 281474976710655
  %r53 = inttoptr i64 %r232 to ptr
  %r226.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r226.rs4o = call i64 asm "", "=r,0"(i64 %r226.rs4i) #7
  %r226 = bitcast i64 %r226.rs4o to double
  %r227 = bitcast double %r226 to i64
  %r228 = and i64 %r227, 281474976710655
  %r229 = inttoptr i64 %r228 to ptr
  %r54 = getelementptr i8, ptr %r229, i64 16
  %r55 = getelementptr double, ptr %r54, i64 0
  %r56 = ptrtoint ptr %r55 to i64
  %r225.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r225.rs4o = call i64 asm "", "=r,0"(i64 %r225.rs4i) #7
  %r225 = bitcast i64 %r225.rs4o to double
  store double %r225, ptr %r55, align 8
  %r224.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r224.rs4o = call i64 asm "", "=r,0"(i64 %r224.rs4i) #7
  %r224 = bitcast i64 %r224.rs4o to double
  %r57 = bitcast double %r224 to i64
  %r222.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r222.rs4o = call i64 asm "", "=r,0"(i64 %r222.rs4i) #7
  %r222 = bitcast i64 %r222.rs4o to double
  %r223 = bitcast double %r222 to i64
  %r58 = lshr i64 %r223, 48
  %r59 = icmp eq i64 %r58, 0
  %r220.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r220.rs4o = call i64 asm "", "=r,0"(i64 %r220.rs4i) #7
  %r220 = bitcast i64 %r220.rs4o to double
  %r221 = bitcast double %r220 to i64
  %r60 = icmp uge i64 %r221, 4096
  %r61 = and i1 %r59, %r60
  %r62 = icmp eq i64 %r58, 32765
  %r63 = icmp eq i64 %r58, 32767
  %r64 = icmp eq i64 %r58, 32762
  %r65 = or i1 %r62, %r63
  %r66 = or i1 %r65, %r64
  %r67 = or i1 %r66, %r61
  br i1 %r67, label %class_field_set.gc_bookkeeping.7, label %class_field_set.gc_bookkeeping.done.8

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r214.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r214.rs4o = call i64 asm "", "=r,0"(i64 %r214.rs4i) #7
  %r214 = bitcast i64 %r214.rs4o to double
  %r215 = bitcast double %r214 to i64
  %r216.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r216.rs4o = call i64 asm "", "=r,0"(i64 %r216.rs4i) #7
  %r216 = bitcast i64 %r216.rs4o to double
  %r217 = load double, ptr @test_json_cached_template_borrow_ts_.str.0.handle, align 8
  %r218 = bitcast double %r217 to i64
  %r219 = and i64 %r218, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 8988321885632593920, i64 %r215, i64 %r219, double %r216, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s1) ]
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s1, %rs4gc.s1)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.gc_bookkeeping.done.8, %class_field_set.fallback.3
  %.02 = phi ptr addrspace(1) [ %rs4gc.s1, %class_field_set.gc_bookkeeping.done.8 ], [ %rs4gc.s1.relocated, %class_field_set.fallback.3 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %class_field_set.gc_bookkeeping.done.8 ], [ %rs4gc.s3.relocated, %class_field_set.fallback.3 ]
  %r81.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r81.rs4o = call i64 asm "", "=r,0"(i64 %r81.rs4i) #7
  %r81 = bitcast i64 %r81.rs4o to double
  %r82.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r82.rs4o = call i64 asm "", "=r,0"(i64 %r82.rs4i) #7
  %r82 = bitcast i64 %r82.rs4o to double
  %r84 = bitcast double %r81 to i64
  %r85 = and i64 %r84, 281474976710655
  %r86 = load double, ptr @test_json_cached_template_borrow_ts_.str.1.handle, align 8
  %r87 = bitcast double %r86 to i64
  %r88 = and i64 %r87, 281474976710655
  %r89 = bitcast double %r82 to i64
  %r90 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r91 = icmp eq i8 %r90, 0
  %r92 = lshr i64 %r84, 48
  %r93 = icmp eq i64 %r92, 32765
  %r94 = icmp ugt i64 %r85, 1048575
  %r95 = and i1 %r93, %r94
  %r96 = and i1 %r95, %r91
  br i1 %r96, label %class_field_inline.deref.15, label %class_field_inline.guardcall.16

class_field_inline.deref.5:                       ; preds = %entry.0
  %r23 = inttoptr i64 %r11 to ptr
  %r24 = getelementptr i8, ptr %r23, i64 -8
  %r25 = load i8, ptr %r24, align 1
  %r26 = icmp eq i8 %r25, 2
  %r27 = getelementptr i8, ptr %r23, i64 -7
  %r28 = load i8, ptr %r27, align 1
  %r29 = and i8 %r28, -128
  %r30 = icmp eq i8 %r29, 0
  %r31 = getelementptr i8, ptr %r23, i64 -6
  %r32 = load i16, ptr %r31, align 2
  %r33 = getelementptr i8, ptr %r23, i64 0
  %r34 = load i32, ptr %r33, align 4
  %r35 = icmp eq i32 %r34, 1
  %r36 = getelementptr i8, ptr %r23, i64 4
  %r37 = load i32, ptr %r36, align 4
  %r38 = icmp eq i32 %r37, %r8
  %r39 = and i1 %r26, %r30
  %r40 = and i1 %r39, %r35
  %r41 = and i1 %r40, %r38
  %r42 = and i16 %r32, 3072
  %r43 = icmp eq i16 %r42, 0
  %r44 = and i1 %r41, %r43
  %r45 = and i16 %r32, 1
  %r46 = icmp eq i16 %r45, 0
  %r47 = and i1 %r44, %r46
  %r48 = and i16 %r32, 128
  %r49 = icmp eq i16 %r48, 0
  %r50 = and i1 %r47, %r49
  br i1 %r50, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r51 = call i32 @js_typed_feedback_class_field_set_guard(i64 8988321885632593920, double %r5, i32 1, i32 %r8, i64 %r14, i32 0, double %r6, i32 0) #7
  %r52 = icmp ne i32 %r51, 0
  br i1 %r52, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.gc_bookkeeping.7:                 ; preds = %class_field_set.fast.2
  %r213.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r213.rs4o = call i64 asm "", "=r,0"(i64 %r213.rs4i) #7
  %r213 = bitcast i64 %r213.rs4o to double
  call void @js_string_addref_if_heap_string(double %r213) #7
  %r210.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r210.rs4o = call i64 asm "", "=r,0"(i64 %r210.rs4i) #7
  %r210 = bitcast i64 %r210.rs4o to double
  %r211 = bitcast double %r210 to i64
  %r212 = and i64 %r211, 281474976710655
  %r68 = inttoptr i64 %r212 to ptr
  %r206.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r206.rs4o = call i64 asm "", "=r,0"(i64 %r206.rs4i) #7
  %r206 = bitcast i64 %r206.rs4o to double
  %r207 = bitcast double %r206 to i64
  %r208 = and i64 %r207, 281474976710655
  %r209 = inttoptr i64 %r208 to ptr
  %r69 = getelementptr i8, ptr %r209, i64 -6
  %r70 = load i16, ptr %r69, align 2
  %r71 = and i16 %r70, -12288
  %r72 = icmp eq i16 %r71, -28672
  br i1 %r72, label %class_field_set.layout_note.done.10, label %class_field_set.layout_note.9

class_field_set.gc_bookkeeping.done.8:            ; preds = %class_field_set.barrier.11, %class_field_set.layout_note.done.10, %class_field_set.fast.2
  br label %class_field_set.merge.4

class_field_set.layout_note.9:                    ; preds = %class_field_set.gc_bookkeeping.7
  %r201.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r201.rs4o = call i64 asm "", "=r,0"(i64 %r201.rs4i) #7
  %r201 = bitcast i64 %r201.rs4o to double
  %r202 = bitcast double %r201 to i64
  %r203 = and i64 %r202, 281474976710655
  %r204.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r204.rs4o = call i64 asm "", "=r,0"(i64 %r204.rs4i) #7
  %r204 = bitcast i64 %r204.rs4o to double
  %r205 = bitcast double %r204 to i64
  call void @js_gc_note_slot_layout(i64 %r203, i32 0, i64 %r205) #7
  br label %class_field_set.layout_note.done.10

class_field_set.layout_note.done.10:              ; preds = %class_field_set.layout_note.9, %class_field_set.gc_bookkeeping.7
  %r198.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r198.rs4o = call i64 asm "", "=r,0"(i64 %r198.rs4i) #7
  %r198 = bitcast i64 %r198.rs4o to double
  %r199 = bitcast double %r198 to i64
  %r200 = and i64 %r199, 281474976710655
  %r73 = sub nsw i64 %r200, 7
  %r74 = inttoptr i64 %r73 to ptr
  %r75 = load i8, ptr %r74, align 1
  %r76 = and i8 %r75, 32
  %r77 = icmp ne i8 %r76, 0
  %r78 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r79 = icmp ne i32 %r78, 0
  %r80 = or i1 %r77, %r79
  br i1 %r80, label %class_field_set.barrier.11, label %class_field_set.gc_bookkeeping.done.8

class_field_set.barrier.11:                       ; preds = %class_field_set.layout_note.done.10
  %r194.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r194.rs4o = call i64 asm "", "=r,0"(i64 %r194.rs4i) #7
  %r194 = bitcast i64 %r194.rs4o to double
  %r195 = bitcast double %r194 to i64
  %r196.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r196.rs4o = call i64 asm "", "=r,0"(i64 %r196.rs4i) #7
  %r196 = bitcast i64 %r196.rs4o to double
  %r197 = bitcast double %r196 to i64
  call void @js_write_barrier_slot(i64 %r195, i64 %r56, i64 %r197) #7
  br label %class_field_set.gc_bookkeeping.done.8

class_field_set.fast.12:                          ; preds = %class_field_inline.guardcall.16, %class_field_inline.deref.15
  %r191.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r191.rs4o = call i64 asm "", "=r,0"(i64 %r191.rs4i) #7
  %r191 = bitcast i64 %r191.rs4o to double
  %r192 = bitcast double %r191 to i64
  %r193 = and i64 %r192, 281474976710655
  %r127 = inttoptr i64 %r193 to ptr
  %r187.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r187.rs4o = call i64 asm "", "=r,0"(i64 %r187.rs4i) #7
  %r187 = bitcast i64 %r187.rs4o to double
  %r188 = bitcast double %r187 to i64
  %r189 = and i64 %r188, 281474976710655
  %r190 = inttoptr i64 %r189 to ptr
  %r128 = getelementptr i8, ptr %r190, i64 16
  %r129 = getelementptr double, ptr %r128, i64 1
  %r130 = ptrtoint ptr %r129 to i64
  %r186.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r186.rs4o = call i64 asm "", "=r,0"(i64 %r186.rs4i) #7
  %r186 = bitcast i64 %r186.rs4o to double
  store double %r186, ptr %r129, align 8
  %r185.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r185.rs4o = call i64 asm "", "=r,0"(i64 %r185.rs4i) #7
  %r185 = bitcast i64 %r185.rs4o to double
  %r131 = bitcast double %r185 to i64
  %r183.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r183.rs4o = call i64 asm "", "=r,0"(i64 %r183.rs4i) #7
  %r183 = bitcast i64 %r183.rs4o to double
  %r184 = bitcast double %r183 to i64
  %r132 = lshr i64 %r184, 48
  %r133 = icmp eq i64 %r132, 0
  %r181.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r181.rs4o = call i64 asm "", "=r,0"(i64 %r181.rs4i) #7
  %r181 = bitcast i64 %r181.rs4o to double
  %r182 = bitcast double %r181 to i64
  %r134 = icmp uge i64 %r182, 4096
  %r135 = and i1 %r133, %r134
  %r136 = icmp eq i64 %r132, 32765
  %r137 = icmp eq i64 %r132, 32767
  %r138 = icmp eq i64 %r132, 32762
  %r139 = or i1 %r136, %r137
  %r140 = or i1 %r139, %r138
  %r141 = or i1 %r140, %r135
  br i1 %r141, label %class_field_set.gc_bookkeeping.17, label %class_field_set.gc_bookkeeping.done.18

class_field_set.fallback.13:                      ; preds = %class_field_inline.guardcall.16
  %r175.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r175.rs4o = call i64 asm "", "=r,0"(i64 %r175.rs4i) #7
  %r175 = bitcast i64 %r175.rs4o to double
  %r176 = bitcast double %r175 to i64
  %r177.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r177.rs4o = call i64 asm "", "=r,0"(i64 %r177.rs4i) #7
  %r177 = bitcast i64 %r177.rs4o to double
  %r178 = load double, ptr @test_json_cached_template_borrow_ts_.str.1.handle, align 8
  %r179 = bitcast double %r178 to i64
  %r180 = and i64 %r179, 281474976710655
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 8988321885632593921, i64 %r176, i64 %r180, double %r177, i32 0, i32 0)
  br label %class_field_set.merge.14

class_field_set.merge.14:                         ; preds = %class_field_set.gc_bookkeeping.done.18, %class_field_set.fallback.13
  br label %standalone.ctor.return.after.1

class_field_inline.deref.15:                      ; preds = %class_field_set.merge.4
  %r97 = inttoptr i64 %r85 to ptr
  %r98 = getelementptr i8, ptr %r97, i64 -8
  %r99 = load i8, ptr %r98, align 1
  %r100 = icmp eq i8 %r99, 2
  %r101 = getelementptr i8, ptr %r97, i64 -7
  %r102 = load i8, ptr %r101, align 1
  %r103 = and i8 %r102, -128
  %r104 = icmp eq i8 %r103, 0
  %r105 = getelementptr i8, ptr %r97, i64 -6
  %r106 = load i16, ptr %r105, align 2
  %r107 = getelementptr i8, ptr %r97, i64 0
  %r108 = load i32, ptr %r107, align 4
  %r109 = icmp eq i32 %r108, 1
  %r110 = getelementptr i8, ptr %r97, i64 4
  %r111 = load i32, ptr %r110, align 4
  %r112 = icmp eq i32 %r111, %r8
  %r113 = and i1 %r100, %r104
  %r114 = and i1 %r113, %r109
  %r115 = and i1 %r114, %r112
  %r116 = and i16 %r106, 3072
  %r117 = icmp eq i16 %r116, 0
  %r118 = and i1 %r115, %r117
  %r119 = and i16 %r106, 1
  %r120 = icmp eq i16 %r119, 0
  %r121 = and i1 %r118, %r120
  %r122 = and i16 %r106, 128
  %r123 = icmp eq i16 %r122, 0
  %r124 = and i1 %r121, %r123
  br i1 %r124, label %class_field_set.fast.12, label %class_field_inline.guardcall.16

class_field_inline.guardcall.16:                  ; preds = %class_field_inline.deref.15, %class_field_set.merge.4
  %r125 = call i32 @js_typed_feedback_class_field_set_guard(i64 8988321885632593921, double %r81, i32 1, i32 %r8, i64 %r88, i32 1, double %r82, i32 0) #7
  %r126 = icmp ne i32 %r125, 0
  br i1 %r126, label %class_field_set.fast.12, label %class_field_set.fallback.13

class_field_set.gc_bookkeeping.17:                ; preds = %class_field_set.fast.12
  %r174.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r174.rs4o = call i64 asm "", "=r,0"(i64 %r174.rs4i) #7
  %r174 = bitcast i64 %r174.rs4o to double
  call void @js_string_addref_if_heap_string(double %r174) #7
  %r171.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r171.rs4o = call i64 asm "", "=r,0"(i64 %r171.rs4i) #7
  %r171 = bitcast i64 %r171.rs4o to double
  %r172 = bitcast double %r171 to i64
  %r173 = and i64 %r172, 281474976710655
  %r142 = inttoptr i64 %r173 to ptr
  %r167.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r167.rs4o = call i64 asm "", "=r,0"(i64 %r167.rs4i) #7
  %r167 = bitcast i64 %r167.rs4o to double
  %r168 = bitcast double %r167 to i64
  %r169 = and i64 %r168, 281474976710655
  %r170 = inttoptr i64 %r169 to ptr
  %r143 = getelementptr i8, ptr %r170, i64 -6
  %r144 = load i16, ptr %r143, align 2
  %r145 = and i16 %r144, -12288
  %r146 = icmp eq i16 %r145, -28672
  br i1 %r146, label %class_field_set.layout_note.done.20, label %class_field_set.layout_note.19

class_field_set.gc_bookkeeping.done.18:           ; preds = %class_field_set.barrier.21, %class_field_set.layout_note.done.20, %class_field_set.fast.12
  br label %class_field_set.merge.14

class_field_set.layout_note.19:                   ; preds = %class_field_set.gc_bookkeeping.17
  %r162.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r162.rs4o = call i64 asm "", "=r,0"(i64 %r162.rs4i) #7
  %r162 = bitcast i64 %r162.rs4o to double
  %r163 = bitcast double %r162 to i64
  %r164 = and i64 %r163, 281474976710655
  %r165.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r165.rs4o = call i64 asm "", "=r,0"(i64 %r165.rs4i) #7
  %r165 = bitcast i64 %r165.rs4o to double
  %r166 = bitcast double %r165 to i64
  call void @js_gc_note_slot_layout(i64 %r164, i32 1, i64 %r166) #7
  br label %class_field_set.layout_note.done.20

class_field_set.layout_note.done.20:              ; preds = %class_field_set.layout_note.19, %class_field_set.gc_bookkeeping.17
  %r159.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r159.rs4o = call i64 asm "", "=r,0"(i64 %r159.rs4i) #7
  %r159 = bitcast i64 %r159.rs4o to double
  %r160 = bitcast double %r159 to i64
  %r161 = and i64 %r160, 281474976710655
  %r147 = sub nsw i64 %r161, 7
  %r148 = inttoptr i64 %r147 to ptr
  %r149 = load i8, ptr %r148, align 1
  %r150 = and i8 %r149, 32
  %r151 = icmp ne i8 %r150, 0
  %r152 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r153 = icmp ne i32 %r152, 0
  %r154 = or i1 %r151, %r153
  br i1 %r154, label %class_field_set.barrier.21, label %class_field_set.gc_bookkeeping.done.18

class_field_set.barrier.21:                       ; preds = %class_field_set.layout_note.done.20
  %r155.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r155.rs4o = call i64 asm "", "=r,0"(i64 %r155.rs4i) #7
  %r155 = bitcast i64 %r155.rs4o to double
  %r156 = bitcast double %r155 to i64
  %r157.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r157.rs4o = call i64 asm "", "=r,0"(i64 %r157.rs4i) #7
  %r157 = bitcast i64 %r157.rs4o to double
  %r158 = bitcast double %r157 to i64
  call void @js_write_barrier_slot(i64 %r156, i64 %r130, i64 %r158) #7
  br label %class_field_set.gc_bookkeeping.done.18
}

; Function Attrs: optsize
define double @test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38_constructor(double %this_arg, double %arg12, double %arg13) #6 gc "statepoint-example" {
entry.0:
  %r8 = load i32, ptr @perry_class_shape_id_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg12 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg13 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #7
  %r5 = bitcast i64 %r5.rs4o to double
  %r6.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r6.rs4o = call i64 asm "", "=r,0"(i64 %r6.rs4i) #7
  %r6 = bitcast i64 %r6.rs4o to double
  %r10 = bitcast double %r5 to i64
  %r11 = and i64 %r10, 281474976710655
  %r12 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r13 = bitcast double %r12 to i64
  %r14 = and i64 %r13, 281474976710655
  %r15 = bitcast double %r6 to i64
  %r16 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r17 = icmp eq i8 %r16, 0
  %r18 = lshr i64 %r10, 48
  %r19 = icmp eq i64 %r18, 32765
  %r20 = icmp ugt i64 %r11, 1048575
  %r21 = and i1 %r19, %r20
  %r22 = and i1 %r21, %r17
  br i1 %r22, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.9
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r187.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r187.rs4o = call i64 asm "", "=r,0"(i64 %r187.rs4i) #7
  %r187 = bitcast i64 %r187.rs4o to double
  %r188 = bitcast double %r187 to i64
  %r189 = and i64 %r188, 281474976710655
  %r59 = inttoptr i64 %r189 to ptr
  %r183.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r183.rs4o = call i64 asm "", "=r,0"(i64 %r183.rs4i) #7
  %r183 = bitcast i64 %r183.rs4o to double
  %r184 = bitcast double %r183 to i64
  %r185 = and i64 %r184, 281474976710655
  %r186 = inttoptr i64 %r185 to ptr
  %r60 = getelementptr i8, ptr %r186, i64 16
  %r61 = getelementptr double, ptr %r60, i64 0
  %r182.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r182.rs4o = call i64 asm "", "=r,0"(i64 %r182.rs4i) #7
  %r182 = bitcast i64 %r182.rs4o to double
  %r62 = call double @js_array_numeric_value_to_raw_f64(double %r182) #7
  store double %r62, ptr %r61, align 8
  br label %class_field_set.merge.4

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r176.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r176.rs4o = call i64 asm "", "=r,0"(i64 %r176.rs4i) #7
  %r176 = bitcast i64 %r176.rs4o to double
  %r177 = bitcast double %r176 to i64
  %r178.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r178.rs4o = call i64 asm "", "=r,0"(i64 %r178.rs4i) #7
  %r178 = bitcast i64 %r178.rs4o to double
  %r179 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r180 = bitcast double %r179 to i64
  %r181 = and i64 %r180, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 8988321885632593922, i64 %r177, i64 %r181, double %r178, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s1) ]
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s1, %rs4gc.s1)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.fallback.3, %class_field_set.fast.2
  %.02 = phi ptr addrspace(1) [ %rs4gc.s1, %class_field_set.fast.2 ], [ %rs4gc.s1.relocated, %class_field_set.fallback.3 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %class_field_set.fast.2 ], [ %rs4gc.s3.relocated, %class_field_set.fallback.3 ]
  %r63.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r63.rs4o = call i64 asm "", "=r,0"(i64 %r63.rs4i) #7
  %r63 = bitcast i64 %r63.rs4o to double
  %r64.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r64.rs4o = call i64 asm "", "=r,0"(i64 %r64.rs4i) #7
  %r64 = bitcast i64 %r64.rs4o to double
  %r66 = bitcast double %r63 to i64
  %r67 = and i64 %r66, 281474976710655
  %r68 = load double, ptr @test_json_cached_template_borrow_ts_.str.3.handle, align 8
  %r69 = bitcast double %r68 to i64
  %r70 = and i64 %r69, 281474976710655
  %r71 = bitcast double %r64 to i64
  %r72 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r73 = icmp eq i8 %r72, 0
  %r74 = lshr i64 %r66, 48
  %r75 = icmp eq i64 %r74, 32765
  %r76 = icmp ugt i64 %r67, 1048575
  %r77 = and i1 %r75, %r76
  %r78 = and i1 %r77, %r73
  br i1 %r78, label %class_field_inline.deref.10, label %class_field_inline.guardcall.11

class_field_inline.deref.5:                       ; preds = %entry.0
  %r23 = inttoptr i64 %r11 to ptr
  %r24 = getelementptr i8, ptr %r23, i64 -8
  %r25 = load i8, ptr %r24, align 1
  %r26 = icmp eq i8 %r25, 2
  %r27 = getelementptr i8, ptr %r23, i64 -7
  %r28 = load i8, ptr %r27, align 1
  %r29 = and i8 %r28, -128
  %r30 = icmp eq i8 %r29, 0
  %r31 = getelementptr i8, ptr %r23, i64 -6
  %r32 = load i16, ptr %r31, align 2
  %r33 = getelementptr i8, ptr %r23, i64 0
  %r34 = load i32, ptr %r33, align 4
  %r35 = icmp eq i32 %r34, 2
  %r36 = getelementptr i8, ptr %r23, i64 4
  %r37 = load i32, ptr %r36, align 4
  %r38 = icmp eq i32 %r37, %r8
  %r39 = and i1 %r26, %r30
  %r40 = and i1 %r39, %r35
  %r41 = and i1 %r40, %r38
  %r42 = and i16 %r32, 3072
  %r43 = icmp eq i16 %r42, 0
  %r44 = and i1 %r41, %r43
  %r45 = and i16 %r32, 4096
  %r46 = icmp ne i16 %r45, 0
  %r47 = and i1 %r44, %r46
  %r48 = and i16 %r32, 1
  %r49 = icmp eq i16 %r48, 0
  %r50 = and i1 %r47, %r49
  %r51 = and i16 %r32, 128
  %r52 = icmp eq i16 %r51, 0
  %r53 = and i1 %r50, %r52
  %r54 = and i64 %r15, 9218868437227405312
  %r55 = icmp ne i64 %r54, 9218868437227405312
  %r56 = and i1 %r53, %r55
  br i1 %r56, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r57 = call i32 @js_typed_feedback_class_field_set_guard(i64 8988321885632593922, double %r5, i32 2, i32 %r8, i64 %r14, i32 0, double %r6, i32 1) #7
  %r58 = icmp ne i32 %r57, 0
  br i1 %r58, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.fast.7:                           ; preds = %class_field_inline.guardcall.11, %class_field_inline.deref.10
  %r173.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r173.rs4o = call i64 asm "", "=r,0"(i64 %r173.rs4i) #7
  %r173 = bitcast i64 %r173.rs4o to double
  %r174 = bitcast double %r173 to i64
  %r175 = and i64 %r174, 281474976710655
  %r109 = inttoptr i64 %r175 to ptr
  %r169.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r169.rs4o = call i64 asm "", "=r,0"(i64 %r169.rs4i) #7
  %r169 = bitcast i64 %r169.rs4o to double
  %r170 = bitcast double %r169 to i64
  %r171 = and i64 %r170, 281474976710655
  %r172 = inttoptr i64 %r171 to ptr
  %r110 = getelementptr i8, ptr %r172, i64 16
  %r111 = getelementptr double, ptr %r110, i64 1
  %r112 = ptrtoint ptr %r111 to i64
  %r168.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r168.rs4o = call i64 asm "", "=r,0"(i64 %r168.rs4i) #7
  %r168 = bitcast i64 %r168.rs4o to double
  store double %r168, ptr %r111, align 8
  %r167.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r167.rs4o = call i64 asm "", "=r,0"(i64 %r167.rs4i) #7
  %r167 = bitcast i64 %r167.rs4o to double
  %r113 = bitcast double %r167 to i64
  %r165.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r165.rs4o = call i64 asm "", "=r,0"(i64 %r165.rs4i) #7
  %r165 = bitcast i64 %r165.rs4o to double
  %r166 = bitcast double %r165 to i64
  %r114 = lshr i64 %r166, 48
  %r115 = icmp eq i64 %r114, 0
  %r163.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r163.rs4o = call i64 asm "", "=r,0"(i64 %r163.rs4i) #7
  %r163 = bitcast i64 %r163.rs4o to double
  %r164 = bitcast double %r163 to i64
  %r116 = icmp uge i64 %r164, 4096
  %r117 = and i1 %r115, %r116
  %r118 = icmp eq i64 %r114, 32765
  %r119 = icmp eq i64 %r114, 32767
  %r120 = icmp eq i64 %r114, 32762
  %r121 = or i1 %r118, %r119
  %r122 = or i1 %r121, %r120
  %r123 = or i1 %r122, %r117
  br i1 %r123, label %class_field_set.gc_bookkeeping.12, label %class_field_set.gc_bookkeeping.done.13

class_field_set.fallback.8:                       ; preds = %class_field_inline.guardcall.11
  %r157.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r157.rs4o = call i64 asm "", "=r,0"(i64 %r157.rs4i) #7
  %r157 = bitcast i64 %r157.rs4o to double
  %r158 = bitcast double %r157 to i64
  %r159.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r159.rs4o = call i64 asm "", "=r,0"(i64 %r159.rs4i) #7
  %r159 = bitcast i64 %r159.rs4o to double
  %r160 = load double, ptr @test_json_cached_template_borrow_ts_.str.3.handle, align 8
  %r161 = bitcast double %r160 to i64
  %r162 = and i64 %r161, 281474976710655
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 8988321885632593923, i64 %r158, i64 %r162, double %r159, i32 0, i32 0)
  br label %class_field_set.merge.9

class_field_set.merge.9:                          ; preds = %class_field_set.gc_bookkeeping.done.13, %class_field_set.fallback.8
  br label %standalone.ctor.return.after.1

class_field_inline.deref.10:                      ; preds = %class_field_set.merge.4
  %r79 = inttoptr i64 %r67 to ptr
  %r80 = getelementptr i8, ptr %r79, i64 -8
  %r81 = load i8, ptr %r80, align 1
  %r82 = icmp eq i8 %r81, 2
  %r83 = getelementptr i8, ptr %r79, i64 -7
  %r84 = load i8, ptr %r83, align 1
  %r85 = and i8 %r84, -128
  %r86 = icmp eq i8 %r85, 0
  %r87 = getelementptr i8, ptr %r79, i64 -6
  %r88 = load i16, ptr %r87, align 2
  %r89 = getelementptr i8, ptr %r79, i64 0
  %r90 = load i32, ptr %r89, align 4
  %r91 = icmp eq i32 %r90, 2
  %r92 = getelementptr i8, ptr %r79, i64 4
  %r93 = load i32, ptr %r92, align 4
  %r94 = icmp eq i32 %r93, %r8
  %r95 = and i1 %r82, %r86
  %r96 = and i1 %r95, %r91
  %r97 = and i1 %r96, %r94
  %r98 = and i16 %r88, 3072
  %r99 = icmp eq i16 %r98, 0
  %r100 = and i1 %r97, %r99
  %r101 = and i16 %r88, 1
  %r102 = icmp eq i16 %r101, 0
  %r103 = and i1 %r100, %r102
  %r104 = and i16 %r88, 128
  %r105 = icmp eq i16 %r104, 0
  %r106 = and i1 %r103, %r105
  br i1 %r106, label %class_field_set.fast.7, label %class_field_inline.guardcall.11

class_field_inline.guardcall.11:                  ; preds = %class_field_inline.deref.10, %class_field_set.merge.4
  %r107 = call i32 @js_typed_feedback_class_field_set_guard(i64 8988321885632593923, double %r63, i32 2, i32 %r8, i64 %r70, i32 1, double %r64, i32 0) #7
  %r108 = icmp ne i32 %r107, 0
  br i1 %r108, label %class_field_set.fast.7, label %class_field_set.fallback.8

class_field_set.gc_bookkeeping.12:                ; preds = %class_field_set.fast.7
  %r156.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r156.rs4o = call i64 asm "", "=r,0"(i64 %r156.rs4i) #7
  %r156 = bitcast i64 %r156.rs4o to double
  call void @js_string_addref_if_heap_string(double %r156) #7
  %r153.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r153.rs4o = call i64 asm "", "=r,0"(i64 %r153.rs4i) #7
  %r153 = bitcast i64 %r153.rs4o to double
  %r154 = bitcast double %r153 to i64
  %r155 = and i64 %r154, 281474976710655
  %r124 = inttoptr i64 %r155 to ptr
  %r149.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r149.rs4o = call i64 asm "", "=r,0"(i64 %r149.rs4i) #7
  %r149 = bitcast i64 %r149.rs4o to double
  %r150 = bitcast double %r149 to i64
  %r151 = and i64 %r150, 281474976710655
  %r152 = inttoptr i64 %r151 to ptr
  %r125 = getelementptr i8, ptr %r152, i64 -6
  %r126 = load i16, ptr %r125, align 2
  %r127 = and i16 %r126, -12288
  %r128 = icmp eq i16 %r127, -28672
  br i1 %r128, label %class_field_set.layout_note.done.15, label %class_field_set.layout_note.14

class_field_set.gc_bookkeeping.done.13:           ; preds = %class_field_set.barrier.16, %class_field_set.layout_note.done.15, %class_field_set.fast.7
  br label %class_field_set.merge.9

class_field_set.layout_note.14:                   ; preds = %class_field_set.gc_bookkeeping.12
  %r144.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r144.rs4o = call i64 asm "", "=r,0"(i64 %r144.rs4i) #7
  %r144 = bitcast i64 %r144.rs4o to double
  %r145 = bitcast double %r144 to i64
  %r146 = and i64 %r145, 281474976710655
  %r147.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r147.rs4o = call i64 asm "", "=r,0"(i64 %r147.rs4i) #7
  %r147 = bitcast i64 %r147.rs4o to double
  %r148 = bitcast double %r147 to i64
  call void @js_gc_note_slot_layout(i64 %r146, i32 1, i64 %r148) #7
  br label %class_field_set.layout_note.done.15

class_field_set.layout_note.done.15:              ; preds = %class_field_set.layout_note.14, %class_field_set.gc_bookkeeping.12
  %r141.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r141.rs4o = call i64 asm "", "=r,0"(i64 %r141.rs4i) #7
  %r141 = bitcast i64 %r141.rs4o to double
  %r142 = bitcast double %r141 to i64
  %r143 = and i64 %r142, 281474976710655
  %r129 = sub nsw i64 %r143, 7
  %r130 = inttoptr i64 %r129 to ptr
  %r131 = load i8, ptr %r130, align 1
  %r132 = and i8 %r131, 32
  %r133 = icmp ne i8 %r132, 0
  %r134 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r135 = icmp ne i32 %r134, 0
  %r136 = or i1 %r133, %r135
  br i1 %r136, label %class_field_set.barrier.16, label %class_field_set.gc_bookkeeping.done.13

class_field_set.barrier.16:                       ; preds = %class_field_set.layout_note.done.15
  %r137.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r137.rs4o = call i64 asm "", "=r,0"(i64 %r137.rs4i) #7
  %r137 = bitcast i64 %r137.rs4o to double
  %r138 = bitcast double %r137 to i64
  %r139.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r139.rs4o = call i64 asm "", "=r,0"(i64 %r139.rs4i) #7
  %r139 = bitcast i64 %r139.rs4o to double
  %r140 = bitcast double %r139 to i64
  call void @js_write_barrier_slot(i64 %r138, i64 %r112, i64 %r140) #7
  br label %class_field_set.gc_bookkeeping.done.13
}

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_test_json_cached_template_borrow_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @test_json_cached_template_borrow_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" {
entry.0:
  %r570 = alloca [1 x double], align 8
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @test_json_cached_template_borrow_ts_.str.0, i32 139, i32 0, i32 0)
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token3 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token4 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_test_json_cached_template_borrow_ts, i32 0, i32 0, i32 0, i32 0)
  %r1458 = load <2 x i64>, ptr @perry_class_header_image_test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18, align 16
  %r1699 = load <2 x i64>, ptr @perry_class_header_image_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38, align 16
  %r2462 = load i32, ptr @perry_class_shape_id_test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18, align 4
  %r2 = load double, ptr @test_json_cached_template_borrow_ts_.str.4.handle, align 8
  %r3 = load double, ptr @test_json_cached_template_borrow_ts_.str.5.handle, align 8
  %r4 = load double, ptr @test_json_cached_template_borrow_ts_.str.6.handle, align 8
  br label %arena_state.init.1

arena_state.init.1:                               ; preds = %entry.0
  %r8 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r9 = icmp ne i64 %r8, -1
  br i1 %r9, label %arena_state.hot_tls.tsd.3, label %arena_state.hot_tls.slow.5

arena_state.ready.2:                              ; preds = %arena_state.hot_tls.resolved.7
  %r24 = getelementptr i8, ptr %r22, i64 8
  %r25 = load i64, ptr %r24, align 8
  %r26 = add i64 %r25, 40
  %r27 = getelementptr i8, ptr %r22, i64 16
  %r28 = load i64, ptr %r27, align 8
  %r29 = icmp ule i64 %r26, %r28
  br i1 %r29, label %arrlit.fast.8, label %arrlit.slow.9

arena_state.hot_tls.tsd.3:                        ; preds = %arena_state.init.1
  %r10 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #7
  %r11 = and i64 %r10, -8
  %r12 = shl i64 %r8, 3
  %r13 = add i64 %r11, %r12
  %r14 = inttoptr i64 %r13 to ptr
  %r15 = load ptr, ptr %r14, align 8
  %r16 = icmp ne ptr %r15, null
  br i1 %r16, label %arena_state.hot_tls.fast.4, label %arena_state.hot_tls.slow.5

arena_state.hot_tls.fast.4:                       ; preds = %arena_state.hot_tls.tsd.3
  %r17 = getelementptr i8, ptr %r15, i64 8
  %r18 = load ptr, ptr %r17, align 8
  %r19 = load ptr, ptr %r18, align 8
  %r20 = icmp ne ptr %r19, null
  br i1 %r20, label %arena_state.hot_tls.ready.6, label %arena_state.hot_tls.slow.5

arena_state.hot_tls.slow.5:                       ; preds = %arena_state.hot_tls.fast.4, %arena_state.hot_tls.tsd.3, %arena_state.init.1
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0)
  %r21100 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token5)
  br label %arena_state.hot_tls.resolved.7

arena_state.hot_tls.ready.6:                      ; preds = %arena_state.hot_tls.fast.4
  br label %arena_state.hot_tls.resolved.7

arena_state.hot_tls.resolved.7:                   ; preds = %arena_state.hot_tls.ready.6, %arena_state.hot_tls.slow.5
  %r5.1 = phi ptr [ %r18, %arena_state.hot_tls.ready.6 ], [ %r21100, %arena_state.hot_tls.slow.5 ]
  %r22 = phi ptr [ %r18, %arena_state.hot_tls.ready.6 ], [ %r21100, %arena_state.hot_tls.slow.5 ]
  br label %arena_state.ready.2

arrlit.fast.8:                                    ; preds = %arena_state.ready.2
  store i64 %r26, ptr %r24, align 8
  %r30 = load ptr, ptr %r22, align 8
  %r31 = getelementptr i8, ptr %r30, i64 %r25
  br label %arrlit.merge.10

arrlit.slow.9:                                    ; preds = %arena_state.ready.2
  %statepoint_token101 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r22, i64 40, i64 8, i32 0, i32 0)
  %r32102 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token101)
  br label %arrlit.merge.10

arrlit.merge.10:                                  ; preds = %arrlit.slow.9, %arrlit.fast.8
  %r33 = phi ptr [ %r31, %arrlit.fast.8 ], [ %r32102, %arrlit.slow.9 ]
  store i64 172872434177, ptr %r33, align 8
  %r34 = getelementptr i8, ptr %r33, i64 8
  store i64 12884901891, ptr %r34, align 8
  %r35 = getelementptr i8, ptr %r33, i64 8
  %r36 = ptrtoint ptr %r35 to i64
  %r37 = getelementptr inbounds nuw i8, ptr %r33, i64 16
  %r3522 = load double, ptr @test_json_cached_template_borrow_ts_.str.4.handle, align 8
  store double %r3522, ptr %r37, align 8
  %r3521 = load double, ptr @test_json_cached_template_borrow_ts_.str.4.handle, align 8
  call void @js_string_addref_if_heap_string(double %r3521) #7
  %r3520 = load double, ptr @test_json_cached_template_borrow_ts_.str.4.handle, align 8
  %r38 = bitcast double %r3520 to i64
  %r3518 = load double, ptr @test_json_cached_template_borrow_ts_.str.4.handle, align 8
  %r3519 = bitcast double %r3518 to i64
  call void @js_gc_note_slot_layout(i64 %r36, i32 0, i64 %r3519) #7
  %r39 = getelementptr inbounds nuw i8, ptr %r33, i64 24
  %r3517 = load double, ptr @test_json_cached_template_borrow_ts_.str.5.handle, align 8
  store double %r3517, ptr %r39, align 8
  %r3516 = load double, ptr @test_json_cached_template_borrow_ts_.str.5.handle, align 8
  call void @js_string_addref_if_heap_string(double %r3516) #7
  %r3515 = load double, ptr @test_json_cached_template_borrow_ts_.str.5.handle, align 8
  %r40 = bitcast double %r3515 to i64
  %r3513 = load double, ptr @test_json_cached_template_borrow_ts_.str.5.handle, align 8
  %r3514 = bitcast double %r3513 to i64
  call void @js_gc_note_slot_layout(i64 %r36, i32 1, i64 %r3514) #7
  %r41 = getelementptr inbounds nuw i8, ptr %r33, i64 32
  %r3512 = load double, ptr @test_json_cached_template_borrow_ts_.str.6.handle, align 8
  store double %r3512, ptr %r41, align 8
  %r3511 = load double, ptr @test_json_cached_template_borrow_ts_.str.6.handle, align 8
  call void @js_string_addref_if_heap_string(double %r3511) #7
  %r3510 = load double, ptr @test_json_cached_template_borrow_ts_.str.6.handle, align 8
  %r42 = bitcast double %r3510 to i64
  %r3508 = load double, ptr @test_json_cached_template_borrow_ts_.str.6.handle, align 8
  %r3509 = bitcast double %r3508 to i64
  call void @js_gc_note_slot_layout(i64 %r36, i32 2, i64 %r3509) #7
  %r43 = or i64 %r36, 9222527611924643840
  %r44 = bitcast i64 %r43 to double
  %rs4gc.b10 = bitcast double %r44 to i64
  %rs4gc.s10 = inttoptr i64 %rs4gc.b10 to ptr addrspace(1)
  %r45.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r45 = call i64 asm "", "=r,0"(i64 %r45.rs4i) #7
  %r46 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r47 = icmp ne i32 %r46, 0
  br i1 %r47, label %shadow.root.barrier.11, label %shadow.root.barrier.done.12

shadow.root.barrier.11:                           ; preds = %arrlit.merge.10
  call void @js_write_barrier_root_nanbox(i64 %r45) #7
  br label %shadow.root.barrier.done.12

shadow.root.barrier.done.12:                      ; preds = %shadow.root.barrier.11, %arrlit.merge.10
  %statepoint_token103 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s10) ]
  %r49104 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token103)
  %rs4gc.s10.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token103, i32 0, i32 0) ; (%rs4gc.s10, %rs4gc.s10)
  %r50 = or i64 %r49104, 9222527611924643840
  %r51 = bitcast i64 %r50 to double
  %rs4gc.b11 = bitcast double %r51 to i64
  %rs4gc.s11 = inttoptr i64 %rs4gc.b11 to ptr addrspace(1)
  %r52.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11 to i64
  %r52 = call i64 asm "", "=r,0"(i64 %r52.rs4i) #7
  %r53 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r54 = icmp ne i32 %r53, 0
  br i1 %r54, label %shadow.root.barrier.13, label %shadow.root.barrier.done.14

shadow.root.barrier.13:                           ; preds = %shadow.root.barrier.done.12
  call void @js_write_barrier_root_nanbox(i64 %r52) #7
  br label %shadow.root.barrier.done.14

shadow.root.barrier.done.14:                      ; preds = %shadow.root.barrier.13, %shadow.root.barrier.done.12
  %r55 = bitcast double %r51 to i64
  %r56 = and i64 %r55, 281474976710655
  call void @js_array_declare_all_pointer_elements(i64 %r56) #7
  br label %for.cond.15

for.cond.15:                                      ; preds = %for.update.17, %shadow.root.barrier.done.14
  %.0 = phi ptr addrspace(1) [ %rs4gc.s10.relocated, %shadow.root.barrier.done.14 ], [ %.42, %for.update.17 ]
  %r58.0 = phi i32 [ 0, %shadow.root.barrier.done.14 ], [ %r2263, %for.update.17 ]
  %r57.0 = phi ptr addrspace(1) [ null, %shadow.root.barrier.done.14 ], [ %.01174, %for.update.17 ]
  %r48.0.base = phi ptr addrspace(1) [ %rs4gc.s11, %shadow.root.barrier.done.14 ], [ %.151122, %for.update.17 ], !is_base_value !0
  %r48.0 = phi ptr addrspace(1) [ %rs4gc.s11, %shadow.root.barrier.done.14 ], [ %.151138, %for.update.17 ]
  %r5.2 = phi ptr [ %r5.1, %shadow.root.barrier.done.14 ], [ %r5.6, %for.update.17 ]
  %r60 = sitofp i32 %r58.0 to double
  %r61 = fcmp olt double %r60, 2.400000e+02
  %r62 = select i1 %r61, i64 9222246136947933188, i64 9222246136947933187
  %r63 = bitcast i64 %r62 to double
  %r64 = icmp eq i64 %r62, 9222246136947933188
  br i1 %r64, label %for.body.16, label %for.exit.18

for.body.16:                                      ; preds = %for.cond.15
  %r66.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r66.rs4o = call i64 asm "", "=r,0"(i64 %r66.rs4i) #7
  %r66 = bitcast i64 %r66.rs4o to double
  %r68 = sitofp i32 %r58.0 to double
  %r69 = fptosi double %r68 to i64
  %r71 = srem i64 %r69, 3
  %r72 = sitofp i64 %r71 to double
  %r73 = icmp eq i64 %r71, 0
  %r74 = fcmp olt double %r68, 0.000000e+00
  %r75 = and i1 %r73, %r74
  %r76 = fneg double %r72
  %r77 = select i1 %r75, double %r76, double %r72
  %r78 = fcmp oge double %r77, 0.000000e+00
  %r79 = fcmp ole double %r77, 0x41DFFFFFFFC00000
  %r80 = and i1 %r78, %r79
  %r81 = select i1 %r80, double %r77, double 0.000000e+00
  %r82 = fptosi double %r81 to i32
  %r83 = sitofp i32 %r82 to double
  %r84 = fcmp oeq double %r83, %r77
  %r85 = and i1 %r80, %r84
  %r86 = bitcast double %r77 to i64
  %r87 = lshr i64 %r86, 48
  %r88 = icmp eq i64 %r87, 32766
  %r89 = trunc i64 %r86 to i32
  %r90 = icmp sge i32 %r89, 0
  %r91 = and i1 %r88, %r90
  %r92 = or i1 %r85, %r91
  %r93 = select i1 %r88, i32 %r89, i32 %r82
  br i1 %r92, label %aidx.canonical.19, label %aidx.runtime_key.20

for.update.17:                                    ; preds = %gcpoll.done.461
  %r2263 = add i32 %r58.0, 1
  %r2264 = sitofp i32 %r58.0 to double
  %r2265 = sitofp i32 %r2263 to double
  br label %for.cond.15

for.exit.18:                                      ; preds = %for.cond.15
  br label %for.cond.462

aidx.canonical.19:                                ; preds = %for.body.16
  %r94 = bitcast double %r66 to i64
  %r95 = and i64 %r94, 281474976710655
  %r96 = lshr i64 %r94, 48
  %r97 = icmp eq i64 %r96, 32765
  %r98 = icmp ugt i64 %r95, 1048575
  %r99 = and i1 %r97, %r98
  br i1 %r99, label %aidx.dynamic.guard.deref.26, label %aidx.dynamic.fallback.23

aidx.runtime_key.20:                              ; preds = %for.body.16
  %r166 = bitcast double %r66 to i64
  %r167 = and i64 %r166, 281474976710655
  %statepoint_token105 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_array_get_index_or_string, i32 2, i32 0, i64 %r167, double %r77, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0, ptr addrspace(1) %r48.0.base, ptr addrspace(1) %.0, ptr addrspace(1) %r48.0) ]
  %r168106 = call double @llvm.experimental.gc.result.f64(token %statepoint_token105)
  %r57.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 0, i32 0) ; (%r57.0, %r57.0)
  %r48.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 1, i32 1) ; (%r48.0.base, %r48.0.base)
  %rs4gc.s10.relocated107 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 2, i32 2) ; (%.0, %.0)
  %r48.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 1, i32 3) ; (%r48.0.base, %r48.0)
  br label %aidx.dynamic_merge.21

aidx.dynamic_merge.21:                            ; preds = %aidx.dynamic.merge.25, %aidx.runtime_key.20
  %.11012 = phi ptr addrspace(1) [ %.21013, %aidx.dynamic.merge.25 ], [ %r48.0.relocated, %aidx.runtime_key.20 ]
  %.1972 = phi ptr addrspace(1) [ %.2973, %aidx.dynamic.merge.25 ], [ %r48.0.base.relocated, %aidx.runtime_key.20 ]
  %.1929 = phi ptr addrspace(1) [ %.2930, %aidx.dynamic.merge.25 ], [ %r57.0.relocated, %aidx.runtime_key.20 ]
  %.1 = phi ptr addrspace(1) [ %.2, %aidx.dynamic.merge.25 ], [ %rs4gc.s10.relocated107, %aidx.runtime_key.20 ]
  %r169 = phi double [ %r165, %aidx.dynamic.merge.25 ], [ %r168106, %aidx.runtime_key.20 ]
  %rs4gc.b13 = bitcast double %r169 to i64
  %rs4gc.s13 = inttoptr i64 %rs4gc.b13 to ptr addrspace(1)
  %r170 = bitcast double %r169 to i64
  %r171 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r172 = icmp ne i32 %r171, 0
  br i1 %r172, label %shadow.root.barrier.29, label %shadow.root.barrier.done.30

aidx.dynamic.fast.22:                             ; preds = %aidx.dynamic.guard.range.28
  %r155 = zext i32 %r93 to i64
  %r156 = shl nuw nsw i64 %r155, 3
  %r157 = add nuw nsw i64 %r156, 8
  %r158 = add i64 %r114, %r157
  %r159 = inttoptr i64 %r158 to ptr
  %r160 = load double, ptr %r159, align 8
  %r161 = bitcast double %r160 to i64
  %r162 = icmp eq i64 %r161, 9222246136947933200
  %r164 = select i1 %r162, double 0x7FFC000000000001, double %r160
  br label %aidx.dynamic.merge.25

aidx.dynamic.fallback.23:                         ; preds = %aidx.dynamic.guard.live.27, %aidx.dynamic.guard.deref.26, %aidx.canonical.19
  %r153 = sitofp i32 %r93 to double
  %statepoint_token108 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 8988321885632593924, double %r66, double %r153, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0, ptr addrspace(1) %r48.0.base, ptr addrspace(1) %.0, ptr addrspace(1) %r48.0) ]
  %r154109 = call double @llvm.experimental.gc.result.f64(token %statepoint_token108)
  %r57.0.relocated110 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 0, i32 0) ; (%r57.0, %r57.0)
  %r48.0.base.relocated111 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 1, i32 1) ; (%r48.0.base, %r48.0.base)
  %rs4gc.s10.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 2, i32 2) ; (%.0, %.0)
  %r48.0.relocated113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 1, i32 3) ; (%r48.0.base, %r48.0)
  br label %aidx.dynamic.merge.25

aidx.dynamic.guard.oob.24:                        ; preds = %aidx.dynamic.guard.range.28
  br label %aidx.dynamic.merge.25

aidx.dynamic.merge.25:                            ; preds = %aidx.dynamic.guard.oob.24, %aidx.dynamic.fallback.23, %aidx.dynamic.fast.22
  %.21013 = phi ptr addrspace(1) [ %r48.0, %aidx.dynamic.fast.22 ], [ %r48.0, %aidx.dynamic.guard.oob.24 ], [ %r48.0.relocated113, %aidx.dynamic.fallback.23 ]
  %.2973 = phi ptr addrspace(1) [ %r48.0.base, %aidx.dynamic.fast.22 ], [ %r48.0.base, %aidx.dynamic.guard.oob.24 ], [ %r48.0.base.relocated111, %aidx.dynamic.fallback.23 ]
  %.2930 = phi ptr addrspace(1) [ %r57.0, %aidx.dynamic.fast.22 ], [ %r57.0, %aidx.dynamic.guard.oob.24 ], [ %r57.0.relocated110, %aidx.dynamic.fallback.23 ]
  %.2 = phi ptr addrspace(1) [ %.0, %aidx.dynamic.fast.22 ], [ %.0, %aidx.dynamic.guard.oob.24 ], [ %rs4gc.s10.relocated112, %aidx.dynamic.fallback.23 ]
  %r165 = phi double [ %r164, %aidx.dynamic.fast.22 ], [ %r154109, %aidx.dynamic.fallback.23 ], [ 0x7FFC000000000001, %aidx.dynamic.guard.oob.24 ]
  br label %aidx.dynamic_merge.21

aidx.dynamic.guard.deref.26:                      ; preds = %aidx.canonical.19
  %r100 = bitcast double %r66 to i64
  %r101 = and i64 %r100, 281474976710655
  %r102 = sub nsw i64 %r101, 8
  %r103 = inttoptr i64 %r102 to ptr
  %r104 = load i8, ptr %r103, align 1
  %r105 = icmp eq i8 %r104, 1
  %r106 = sub nsw i64 %r101, 7
  %r107 = inttoptr i64 %r106 to ptr
  %r108 = load i8, ptr %r107, align 1
  %r109 = and i8 %r108, -128
  %r110 = icmp ne i8 %r109, 0
  %r111 = inttoptr i64 %r101 to ptr
  %r112 = load i64, ptr %r111, align 8
  %r113 = and i1 %r105, %r110
  %r114 = select i1 %r113, i64 %r112, i64 %r101
  %r115 = lshr i64 %r114, 48
  %r116 = icmp eq i64 %r115, 0
  %r117 = icmp ugt i64 %r114, 1048575
  %r118 = and i1 %r116, %r117
  br i1 %r118, label %aidx.dynamic.guard.live.27, label %aidx.dynamic.fallback.23

aidx.dynamic.guard.live.27:                       ; preds = %aidx.dynamic.guard.deref.26
  %r119 = sub nuw i64 %r114, 8
  %r120 = inttoptr i64 %r119 to ptr
  %r121 = load i8, ptr %r120, align 1
  %r122 = icmp eq i8 %r121, 1
  %r123 = sub nuw i64 %r114, 7
  %r124 = inttoptr i64 %r123 to ptr
  %r125 = load i8, ptr %r124, align 1
  %r126 = and i8 %r125, -128
  %r127 = icmp eq i8 %r126, 0
  %r128 = sub nuw i64 %r114, 6
  %r129 = inttoptr i64 %r128 to ptr
  %r130 = load i16, ptr %r129, align 2
  %r131 = and i16 %r130, 1024
  %r132 = icmp eq i16 %r131, 0
  %r133 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r134 = icmp eq i8 %r133, 0
  %r135 = inttoptr i64 %r114 to ptr
  %r136 = load i32, ptr %r135, align 4
  %r137 = getelementptr i8, ptr %r135, i64 4
  %r138 = load i32, ptr %r137, align 4
  %r139 = icmp slt i32 %r93, 0
  %r140 = icmp eq i1 %r139, false
  %r142 = icmp ule i32 %r136, 16000000
  %r143 = icmp ule i32 %r138, 16000000
  %r144 = icmp ule i32 %r136, %r138
  %r145 = and i1 %r122, %r127
  %r146 = and i1 %r145, %r132
  %r147 = and i1 %r146, %r134
  %r148 = and i1 %r147, %r140
  %r149 = and i1 %r148, %r142
  %r150 = and i1 %r149, %r143
  %r151 = and i1 %r150, %r144
  br i1 %r151, label %aidx.dynamic.guard.range.28, label %aidx.dynamic.fallback.23

aidx.dynamic.guard.range.28:                      ; preds = %aidx.dynamic.guard.live.27
  %r141 = icmp ult i32 %r93, %r136
  br i1 %r141, label %aidx.dynamic.fast.22, label %aidx.dynamic.guard.oob.24

shadow.root.barrier.29:                           ; preds = %aidx.dynamic_merge.21
  call void @js_write_barrier_root_nanbox(i64 %r170) #7
  br label %shadow.root.barrier.done.30

shadow.root.barrier.done.30:                      ; preds = %shadow.root.barrier.29, %aidx.dynamic_merge.21
  %r174.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r174.rs4o = call i64 asm "", "=r,0"(i64 %r174.rs4i) #7
  %r174 = bitcast i64 %r174.rs4o to double
  %statepoint_token114 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r174, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1929, ptr addrspace(1) %.1972, ptr addrspace(1) %rs4gc.s13, ptr addrspace(1) %.1, ptr addrspace(1) %.11012) ]
  %r175115 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token114)
  %r57.0.relocated116 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token114, i32 0, i32 0) ; (%.1929, %.1929)
  %r48.0.base.relocated117 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token114, i32 1, i32 1) ; (%.1972, %.1972)
  %rs4gc.s13.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token114, i32 2, i32 2) ; (%rs4gc.s13, %rs4gc.s13)
  %rs4gc.s10.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token114, i32 3, i32 3) ; (%.1, %.1)
  %r48.0.relocated119 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token114, i32 1, i32 4) ; (%.1972, %.11012)
  %statepoint_token120 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r175115, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated116, ptr addrspace(1) %r48.0.base.relocated117, ptr addrspace(1) %rs4gc.s13.relocated, ptr addrspace(1) %rs4gc.s10.relocated118, ptr addrspace(1) %r48.0.relocated119) ]
  %r176121 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token120)
  %r57.0.relocated122 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 0, i32 0) ; (%r57.0.relocated116, %r57.0.relocated116)
  %r48.0.base.relocated123 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 1, i32 1) ; (%r48.0.base.relocated117, %r48.0.base.relocated117)
  %rs4gc.s13.relocated124 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 2, i32 2) ; (%rs4gc.s13.relocated, %rs4gc.s13.relocated)
  %rs4gc.s10.relocated125 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 3, i32 3) ; (%rs4gc.s10.relocated118, %rs4gc.s10.relocated118)
  %r48.0.relocated126 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 1, i32 4) ; (%r48.0.base.relocated117, %r48.0.relocated119)
  %r177 = bitcast i64 %r176121 to double
  %rs4gc.b14 = bitcast double %r177 to i64
  %rs4gc.s14 = inttoptr i64 %rs4gc.b14 to ptr addrspace(1)
  %r178.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r178 = call i64 asm "", "=r,0"(i64 %r178.rs4i) #7
  %r179 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r180 = icmp ne i32 %r179, 0
  br i1 %r180, label %shadow.root.barrier.31, label %shadow.root.barrier.done.32

shadow.root.barrier.31:                           ; preds = %shadow.root.barrier.done.30
  call void @js_write_barrier_root_nanbox(i64 %r178) #7
  br label %shadow.root.barrier.done.32

shadow.root.barrier.done.32:                      ; preds = %shadow.root.barrier.31, %shadow.root.barrier.done.30
  %r182.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated124 to i64
  %r182.rs4o = call i64 asm "", "=r,0"(i64 %r182.rs4i) #7
  %r182 = bitcast i64 %r182.rs4o to double
  %statepoint_token127 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r182, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated122, ptr addrspace(1) %r48.0.base.relocated123, ptr addrspace(1) %rs4gc.s13.relocated124, ptr addrspace(1) %rs4gc.s10.relocated125, ptr addrspace(1) %r48.0.relocated126, ptr addrspace(1) %rs4gc.s14) ]
  %r183128 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token127)
  %r57.0.relocated129 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 0, i32 0) ; (%r57.0.relocated122, %r57.0.relocated122)
  %r48.0.base.relocated130 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 1, i32 1) ; (%r48.0.base.relocated123, %r48.0.base.relocated123)
  %rs4gc.s13.relocated131 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 2, i32 2) ; (%rs4gc.s13.relocated124, %rs4gc.s13.relocated124)
  %rs4gc.s10.relocated132 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 3, i32 3) ; (%rs4gc.s10.relocated125, %rs4gc.s10.relocated125)
  %r48.0.relocated133 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 1, i32 4) ; (%r48.0.base.relocated123, %r48.0.relocated126)
  %rs4gc.s14.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token127, i32 5, i32 5) ; (%rs4gc.s14, %rs4gc.s14)
  %statepoint_token134 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r183128, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated129, ptr addrspace(1) %r48.0.base.relocated130, ptr addrspace(1) %rs4gc.s13.relocated131, ptr addrspace(1) %rs4gc.s10.relocated132, ptr addrspace(1) %r48.0.relocated133, ptr addrspace(1) %rs4gc.s14.relocated) ]
  %r184135 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token134)
  %r57.0.relocated136 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 0, i32 0) ; (%r57.0.relocated129, %r57.0.relocated129)
  %r48.0.base.relocated137 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 1, i32 1) ; (%r48.0.base.relocated130, %r48.0.base.relocated130)
  %rs4gc.s13.relocated138 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 2, i32 2) ; (%rs4gc.s13.relocated131, %rs4gc.s13.relocated131)
  %rs4gc.s10.relocated139 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 3, i32 3) ; (%rs4gc.s10.relocated132, %rs4gc.s10.relocated132)
  %r48.0.relocated140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 1, i32 4) ; (%r48.0.base.relocated130, %r48.0.relocated133)
  %rs4gc.s14.relocated141 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token134, i32 5, i32 5) ; (%rs4gc.s14.relocated, %rs4gc.s14.relocated)
  %r185 = bitcast i64 %r184135 to double
  %rs4gc.b15 = bitcast double %r185 to i64
  %rs4gc.s15 = inttoptr i64 %rs4gc.b15 to ptr addrspace(1)
  %r186.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r186 = call i64 asm "", "=r,0"(i64 %r186.rs4i) #7
  %r187 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r188 = icmp ne i32 %r187, 0
  br i1 %r188, label %shadow.root.barrier.33, label %shadow.root.barrier.done.34

shadow.root.barrier.33:                           ; preds = %shadow.root.barrier.done.32
  call void @js_write_barrier_root_nanbox(i64 %r186) #7
  br label %shadow.root.barrier.done.34

shadow.root.barrier.done.34:                      ; preds = %shadow.root.barrier.33, %shadow.root.barrier.done.32
  %r189.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14.relocated141 to i64
  %r189.rs4o = call i64 asm "", "=r,0"(i64 %r189.rs4i) #7
  %r189 = bitcast i64 %r189.rs4o to double
  %r190 = bitcast double %r189 to i64
  %r191 = and i64 %r190, 281474976710655
  %r192 = lshr i64 %r190, 48
  %r193 = and i64 %r192, 65533
  %r194 = icmp eq i64 %r193, 32765
  br i1 %r194, label %pget.recv_ok.36, label %pget.recv_other.40

pget.recv_sso.35:                                 ; preds = %pget.recv_other.40
  %r332 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r333 = bitcast double %r332 to i64
  %r334 = and i64 %r333, 281474976710655
  %statepoint_token142 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r190, i64 %r334, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated136, ptr addrspace(1) %r48.0.base.relocated137, ptr addrspace(1) %rs4gc.s13.relocated138, ptr addrspace(1) %rs4gc.s15, ptr addrspace(1) %rs4gc.s10.relocated139, ptr addrspace(1) %r48.0.relocated140, ptr addrspace(1) %rs4gc.s14.relocated141) ]
  %r335143 = call double @llvm.experimental.gc.result.f64(token %statepoint_token142)
  %r57.0.relocated144 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 0, i32 0) ; (%r57.0.relocated136, %r57.0.relocated136)
  %r48.0.base.relocated145 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 1, i32 1) ; (%r48.0.base.relocated137, %r48.0.base.relocated137)
  %rs4gc.s13.relocated146 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 2, i32 2) ; (%rs4gc.s13.relocated138, %rs4gc.s13.relocated138)
  %rs4gc.s15.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 3, i32 3) ; (%rs4gc.s15, %rs4gc.s15)
  %rs4gc.s10.relocated147 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 4, i32 4) ; (%rs4gc.s10.relocated139, %rs4gc.s10.relocated139)
  %r48.0.relocated148 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 1, i32 5) ; (%r48.0.base.relocated137, %r48.0.relocated140)
  %rs4gc.s14.relocated149 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token142, i32 6, i32 6) ; (%rs4gc.s14.relocated141, %rs4gc.s14.relocated141)
  br label %pget.recv_merge.39

pget.recv_ok.36:                                  ; preds = %shadow.root.barrier.done.34
  %r201 = icmp ugt i64 %r191, 1048575
  br i1 %r201, label %pic.recv_hdr.57, label %pic.miss.cold.54

pget.recv_bad.37:                                 ; preds = %pget.check_class_ref.41
  %r324 = icmp eq i64 %r190, 9222246136947933185
  %r325 = icmp eq i64 %r190, 9222246136947933186
  %r326 = or i1 %r324, %r325
  br i1 %r326, label %pget.throw_nullish.64, label %pget.recv_undef_return.65

pget.recv_class_ref.38:                           ; preds = %pget.check_class_ref.41
  %r197 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r198 = bitcast double %r197 to i64
  %r199 = and i64 %r198, 281474976710655
  %statepoint_token150 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 8988321885632593925, i64 %r190, i64 %r199, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated136, ptr addrspace(1) %r48.0.base.relocated137, ptr addrspace(1) %rs4gc.s13.relocated138, ptr addrspace(1) %rs4gc.s15, ptr addrspace(1) %rs4gc.s10.relocated139, ptr addrspace(1) %r48.0.relocated140, ptr addrspace(1) %rs4gc.s14.relocated141) ]
  %r200151 = call double @llvm.experimental.gc.result.f64(token %statepoint_token150)
  %r57.0.relocated152 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 0, i32 0) ; (%r57.0.relocated136, %r57.0.relocated136)
  %r48.0.base.relocated153 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 1, i32 1) ; (%r48.0.base.relocated137, %r48.0.base.relocated137)
  %rs4gc.s13.relocated154 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 2, i32 2) ; (%rs4gc.s13.relocated138, %rs4gc.s13.relocated138)
  %rs4gc.s15.relocated155 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 3, i32 3) ; (%rs4gc.s15, %rs4gc.s15)
  %rs4gc.s10.relocated156 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 4, i32 4) ; (%rs4gc.s10.relocated139, %rs4gc.s10.relocated139)
  %r48.0.relocated157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 1, i32 5) ; (%r48.0.base.relocated137, %r48.0.relocated140)
  %rs4gc.s14.relocated158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 6, i32 6) ; (%rs4gc.s14.relocated141, %rs4gc.s14.relocated141)
  br label %pget.recv_merge.39

pget.recv_merge.39:                               ; preds = %pget.recv_undef_return.65, %pic.merge.56, %pget.recv_class_ref.38, %pget.recv_sso.35
  %.01071 = phi ptr addrspace(1) [ %.11072, %pic.merge.56 ], [ %rs4gc.s15.relocated, %pget.recv_sso.35 ], [ %rs4gc.s15.relocated155, %pget.recv_class_ref.38 ], [ %rs4gc.s15.relocated183, %pget.recv_undef_return.65 ]
  %.01068 = phi ptr addrspace(1) [ %.11069, %pic.merge.56 ], [ %rs4gc.s14.relocated149, %pget.recv_sso.35 ], [ %rs4gc.s14.relocated158, %pget.recv_class_ref.38 ], [ %rs4gc.s14.relocated186, %pget.recv_undef_return.65 ]
  %.01051 = phi ptr addrspace(1) [ %.11052, %pic.merge.56 ], [ %rs4gc.s13.relocated146, %pget.recv_sso.35 ], [ %rs4gc.s13.relocated154, %pget.recv_class_ref.38 ], [ %rs4gc.s13.relocated182, %pget.recv_undef_return.65 ]
  %.31014 = phi ptr addrspace(1) [ %.41015, %pic.merge.56 ], [ %r48.0.relocated148, %pget.recv_sso.35 ], [ %r48.0.relocated157, %pget.recv_class_ref.38 ], [ %r48.0.relocated185, %pget.recv_undef_return.65 ]
  %.3974 = phi ptr addrspace(1) [ %.4975, %pic.merge.56 ], [ %r48.0.base.relocated145, %pget.recv_sso.35 ], [ %r48.0.base.relocated153, %pget.recv_class_ref.38 ], [ %r48.0.base.relocated181, %pget.recv_undef_return.65 ]
  %.3931 = phi ptr addrspace(1) [ %.4932, %pic.merge.56 ], [ %r57.0.relocated144, %pget.recv_sso.35 ], [ %r57.0.relocated152, %pget.recv_class_ref.38 ], [ %r57.0.relocated180, %pget.recv_undef_return.65 ]
  %.3 = phi ptr addrspace(1) [ %.4, %pic.merge.56 ], [ %rs4gc.s10.relocated147, %pget.recv_sso.35 ], [ %rs4gc.s10.relocated156, %pget.recv_class_ref.38 ], [ %rs4gc.s10.relocated184, %pget.recv_undef_return.65 ]
  %r336 = phi double [ %r323, %pic.merge.56 ], [ %r331179, %pget.recv_undef_return.65 ], [ %r335143, %pget.recv_sso.35 ], [ %r200151, %pget.recv_class_ref.38 ]
  %r337 = load double, ptr @test_json_cached_template_borrow_ts_.str.8.handle, align 8
  %r338 = bitcast double %r337 to i64
  %r339 = bitcast double %r336 to i64
  %r340 = and i64 %r339, 281474976710655
  %r341 = and i64 %r339, -281474976710656
  %r342 = icmp eq i64 %r341, 9222527611924643840
  %r343 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r344 = icmp eq i64 %r343, 0
  %r345 = lshr i64 %r340, 3
  %r346 = and i64 %r345, 63
  %r347 = getelementptr [64 x i64], ptr @PERRY_TA_KIND_CACHE, i64 0, i64 %r346
  %r348 = load i64, ptr %r347, align 8
  %r349 = lshr i64 %r348, 8
  %r350 = icmp eq i64 %r349, %r340
  %r351 = and i64 %r348, 255
  %r352 = icmp ule i64 %r351, 7
  %r355 = and i1 %r342, %r344
  %r356 = and i1 %r355, %r350
  %r357 = and i1 %r356, %r352
  br i1 %r357, label %tav.set.fast.66, label %tav.set.slow.68

pget.recv_other.40:                               ; preds = %shadow.root.barrier.done.34
  %r195 = icmp eq i64 %r192, 32761
  br i1 %r195, label %pget.recv_sso.35, label %pget.check_class_ref.41

pget.check_class_ref.41:                          ; preds = %pget.recv_other.40
  %r196 = icmp eq i64 %r192, 32766
  br i1 %r196, label %pget.recv_class_ref.38, label %pget.recv_bad.37

pic.hit.42:                                       ; preds = %pic.token.58
  %r226 = getelementptr i64, ptr %r211, i64 1
  %r227 = load i64, ptr %r226, align 8
  %r228 = and i64 %r227, 1073741824
  %r229 = icmp ne i64 %r228, 0
  br i1 %r229, label %pic.hit.overflow.59, label %pic.hit.inline.60

pic.hit.live.43:                                  ; preds = %pic.hit.inline.60
  br label %pic.merge.56

pic.prefix.guard.44:                              ; preds = %pic.token.58
  %r242 = getelementptr i64, ptr %r211, i64 2
  %r243 = load i64, ptr %r242, align 8
  %r244 = icmp ne i64 %r243, 0
  br i1 %r244, label %pic.prefix.meta.45, label %pic.miss.53

pic.prefix.meta.45:                               ; preds = %pic.prefix.guard.44
  %r245 = add nuw nsw i64 %r191, 8
  %r246 = inttoptr i64 %r245 to ptr
  %r247 = load i64, ptr %r246, align 8
  %r248 = icmp ne i64 %r247, 0
  br i1 %r248, label %pic.prefix.token.46, label %pic.miss.53

pic.prefix.token.46:                              ; preds = %pic.prefix.meta.45
  %r249 = inttoptr i64 %r247 to ptr
  %r250 = getelementptr i64, ptr %r249, i64 6
  %r251 = load i64, ptr %r250, align 8
  %r252 = icmp eq i64 %r251, %r243
  br i1 %r252, label %pic.prefix.hit.47, label %pic.miss.53

pic.prefix.hit.47:                                ; preds = %pic.prefix.token.46
  %r253 = getelementptr i64, ptr %r211, i64 1
  %r254 = load i64, ptr %r253, align 8
  %r255 = shl i64 %r254, 3
  %r256 = add nuw nsw i64 %r191, 16
  %r257 = add i64 %r256, %r255
  %r258 = inttoptr i64 %r257 to ptr
  %r259 = load double, ptr %r258, align 8
  br label %pic.merge.56

pic.desc.classify.48:                             ; preds = %pic.recv_hdr.57
  %r215 = and i1 %r205, %r212
  br i1 %r215, label %pic.desc.prefix.guard.49, label %pic.miss.cold.54

pic.desc.prefix.guard.49:                         ; preds = %pic.desc.classify.48
  %r260 = getelementptr i64, ptr %r211, i64 2
  %r261 = load i64, ptr %r260, align 8
  %r262 = icmp ne i64 %r261, 0
  br i1 %r262, label %pic.desc.prefix.meta.50, label %pic.miss.cold.54

pic.desc.prefix.meta.50:                          ; preds = %pic.desc.prefix.guard.49
  %r263 = add nuw nsw i64 %r191, 8
  %r264 = inttoptr i64 %r263 to ptr
  %r265 = load i64, ptr %r264, align 8
  %r266 = icmp ne i64 %r265, 0
  br i1 %r266, label %pic.desc.prefix.token.51, label %pic.miss.cold.54

pic.desc.prefix.token.51:                         ; preds = %pic.desc.prefix.meta.50
  %r267 = inttoptr i64 %r265 to ptr
  %r268 = getelementptr i64, ptr %r267, i64 6
  %r269 = load i64, ptr %r268, align 8
  %r270 = icmp eq i64 %r269, %r261
  br i1 %r270, label %pic.desc.prefix.hit.52, label %pic.miss.cold.54

pic.desc.prefix.hit.52:                           ; preds = %pic.desc.prefix.token.51
  %r271 = getelementptr i64, ptr %r211, i64 1
  %r272 = load i64, ptr %r271, align 8
  %r273 = shl i64 %r272, 3
  %r274 = add nuw nsw i64 %r191, 16
  %r275 = add i64 %r274, %r273
  %r276 = inttoptr i64 %r275 to ptr
  %r277 = load double, ptr %r276, align 8
  br label %pic.merge.56

pic.miss.53:                                      ; preds = %pic.hit.inline.60, %pic.prefix.token.46, %pic.prefix.meta.45, %pic.prefix.guard.44
  %r278 = getelementptr i64, ptr %r211, i64 3
  %r279 = load i64, ptr %r278, align 8
  %r280 = icmp sgt i64 %r279, 0
  br i1 %r280, label %pic.ways.61, label %pic.miss.call.55

pic.miss.cold.54:                                 ; preds = %pic.desc.prefix.token.51, %pic.desc.prefix.meta.50, %pic.desc.prefix.guard.49, %pic.desc.classify.48, %pget.recv_ok.36
  br label %pic.miss.call.55

pic.miss.call.55:                                 ; preds = %pic.way.load.62, %pic.ways.61, %pic.miss.cold.54, %pic.miss.53
  %r319 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r320 = bitcast double %r319 to i64
  %r321 = and i64 %r320, 281474976710655
  %statepoint_token159 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r191, i64 %r321, ptr @perry_ic_test_json_cached_template_borrow_ts__6, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated136, ptr addrspace(1) %r48.0.base.relocated137, ptr addrspace(1) %rs4gc.s13.relocated138, ptr addrspace(1) %rs4gc.s15, ptr addrspace(1) %rs4gc.s10.relocated139, ptr addrspace(1) %r48.0.relocated140, ptr addrspace(1) %rs4gc.s14.relocated141) ]
  %r322160 = call double @llvm.experimental.gc.result.f64(token %statepoint_token159)
  %r57.0.relocated161 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token159, i32 0, i32 0) ; (%r57.0.relocated136, %r57.0.relocated136)
  %r48.0.base.relocated162 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token159, i32 1, i32 1) ; (%r48.0.base.relocated137, %r48.0.base.relocated137)
  %rs4gc.s13.relocated163 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token159, i32 2, i32 2) ; (%rs4gc.s13.relocated138, %rs4gc.s13.relocated138)
  %rs4gc.s15.relocated164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token159, i32 3, i32 3) ; (%rs4gc.s15, %rs4gc.s15)
  %rs4gc.s10.relocated165 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token159, i32 4, i32 4) ; (%rs4gc.s10.relocated139, %rs4gc.s10.relocated139)
  %r48.0.relocated166 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token159, i32 1, i32 5) ; (%r48.0.base.relocated137, %r48.0.relocated140)
  %rs4gc.s14.relocated167 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token159, i32 6, i32 6) ; (%rs4gc.s14.relocated141, %rs4gc.s14.relocated141)
  br label %pic.merge.56

pic.merge.56:                                     ; preds = %pic.way.live.63, %pic.hit.overflow.59, %pic.miss.call.55, %pic.desc.prefix.hit.52, %pic.prefix.hit.47, %pic.hit.live.43
  %.11072 = phi ptr addrspace(1) [ %rs4gc.s15.relocated173, %pic.hit.overflow.59 ], [ %rs4gc.s15.relocated164, %pic.miss.call.55 ], [ %rs4gc.s15, %pic.way.live.63 ], [ %rs4gc.s15, %pic.hit.live.43 ], [ %rs4gc.s15, %pic.prefix.hit.47 ], [ %rs4gc.s15, %pic.desc.prefix.hit.52 ]
  %.11069 = phi ptr addrspace(1) [ %rs4gc.s14.relocated176, %pic.hit.overflow.59 ], [ %rs4gc.s14.relocated167, %pic.miss.call.55 ], [ %rs4gc.s14.relocated141, %pic.way.live.63 ], [ %rs4gc.s14.relocated141, %pic.hit.live.43 ], [ %rs4gc.s14.relocated141, %pic.prefix.hit.47 ], [ %rs4gc.s14.relocated141, %pic.desc.prefix.hit.52 ]
  %.11052 = phi ptr addrspace(1) [ %rs4gc.s13.relocated172, %pic.hit.overflow.59 ], [ %rs4gc.s13.relocated163, %pic.miss.call.55 ], [ %rs4gc.s13.relocated138, %pic.way.live.63 ], [ %rs4gc.s13.relocated138, %pic.hit.live.43 ], [ %rs4gc.s13.relocated138, %pic.prefix.hit.47 ], [ %rs4gc.s13.relocated138, %pic.desc.prefix.hit.52 ]
  %.41015 = phi ptr addrspace(1) [ %r48.0.relocated175, %pic.hit.overflow.59 ], [ %r48.0.relocated166, %pic.miss.call.55 ], [ %r48.0.relocated140, %pic.way.live.63 ], [ %r48.0.relocated140, %pic.hit.live.43 ], [ %r48.0.relocated140, %pic.prefix.hit.47 ], [ %r48.0.relocated140, %pic.desc.prefix.hit.52 ]
  %.4975 = phi ptr addrspace(1) [ %r48.0.base.relocated171, %pic.hit.overflow.59 ], [ %r48.0.base.relocated162, %pic.miss.call.55 ], [ %r48.0.base.relocated137, %pic.way.live.63 ], [ %r48.0.base.relocated137, %pic.hit.live.43 ], [ %r48.0.base.relocated137, %pic.prefix.hit.47 ], [ %r48.0.base.relocated137, %pic.desc.prefix.hit.52 ]
  %.4932 = phi ptr addrspace(1) [ %r57.0.relocated170, %pic.hit.overflow.59 ], [ %r57.0.relocated161, %pic.miss.call.55 ], [ %r57.0.relocated136, %pic.way.live.63 ], [ %r57.0.relocated136, %pic.hit.live.43 ], [ %r57.0.relocated136, %pic.prefix.hit.47 ], [ %r57.0.relocated136, %pic.desc.prefix.hit.52 ]
  %.4 = phi ptr addrspace(1) [ %rs4gc.s10.relocated174, %pic.hit.overflow.59 ], [ %rs4gc.s10.relocated165, %pic.miss.call.55 ], [ %rs4gc.s10.relocated139, %pic.way.live.63 ], [ %rs4gc.s10.relocated139, %pic.hit.live.43 ], [ %rs4gc.s10.relocated139, %pic.prefix.hit.47 ], [ %rs4gc.s10.relocated139, %pic.desc.prefix.hit.52 ]
  %r323 = phi double [ %r239, %pic.hit.live.43 ], [ %r234169, %pic.hit.overflow.59 ], [ %r259, %pic.prefix.hit.47 ], [ %r277, %pic.desc.prefix.hit.52 ], [ %r316, %pic.way.live.63 ], [ %r322160, %pic.miss.call.55 ]
  br label %pget.recv_merge.39

pic.recv_hdr.57:                                  ; preds = %pget.recv_ok.36
  %r202 = sub nuw nsw i64 %r191, 8
  %r203 = inttoptr i64 %r202 to ptr
  %r204 = load i8, ptr %r203, align 1
  %r205 = icmp eq i8 %r204, 2
  %r206 = sub nuw nsw i64 %r191, 6
  %r207 = inttoptr i64 %r206 to ptr
  %r208 = load i16, ptr %r207, align 2
  %r209 = and i16 %r208, 2048
  %r210 = icmp eq i16 %r209, 0
  %r211 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__6, align 8
  %r212 = icmp ne ptr %r211, null
  %r213 = and i1 %r205, %r210
  %r214 = and i1 %r213, %r212
  br i1 %r214, label %pic.token.58, label %pic.desc.classify.48

pic.token.58:                                     ; preds = %pic.recv_hdr.57
  %r216 = add nuw nsw i64 %r191, 4
  %r217 = inttoptr i64 %r216 to ptr
  %r218 = load i32, ptr %r217, align 4
  %r219 = zext i32 %r218 to i64
  %r220 = or i64 %r219, 4611686018427387904
  %r221 = icmp ne i32 %r218, 0
  %r222 = getelementptr i64, ptr %r211, i64 0
  %r223 = load i64, ptr %r222, align 8
  %r224 = icmp eq i64 %r220, %r223
  %r225 = and i1 %r224, %r221
  br i1 %r225, label %pic.hit.42, label %pic.prefix.guard.44

pic.hit.overflow.59:                              ; preds = %pic.hit.42
  %r230 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r231 = bitcast double %r230 to i64
  %r232 = and i64 %r231, 281474976710655
  %r233 = trunc i64 %r227 to i32
  %statepoint_token168 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r191, i64 %r232, i32 %r233, ptr @perry_ic_test_json_cached_template_borrow_ts__6, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated136, ptr addrspace(1) %r48.0.base.relocated137, ptr addrspace(1) %rs4gc.s13.relocated138, ptr addrspace(1) %rs4gc.s15, ptr addrspace(1) %rs4gc.s10.relocated139, ptr addrspace(1) %r48.0.relocated140, ptr addrspace(1) %rs4gc.s14.relocated141) ]
  %r234169 = call double @llvm.experimental.gc.result.f64(token %statepoint_token168)
  %r57.0.relocated170 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token168, i32 0, i32 0) ; (%r57.0.relocated136, %r57.0.relocated136)
  %r48.0.base.relocated171 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token168, i32 1, i32 1) ; (%r48.0.base.relocated137, %r48.0.base.relocated137)
  %rs4gc.s13.relocated172 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token168, i32 2, i32 2) ; (%rs4gc.s13.relocated138, %rs4gc.s13.relocated138)
  %rs4gc.s15.relocated173 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token168, i32 3, i32 3) ; (%rs4gc.s15, %rs4gc.s15)
  %rs4gc.s10.relocated174 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token168, i32 4, i32 4) ; (%rs4gc.s10.relocated139, %rs4gc.s10.relocated139)
  %r48.0.relocated175 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token168, i32 1, i32 5) ; (%r48.0.base.relocated137, %r48.0.relocated140)
  %rs4gc.s14.relocated176 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token168, i32 6, i32 6) ; (%rs4gc.s14.relocated141, %rs4gc.s14.relocated141)
  br label %pic.merge.56

pic.hit.inline.60:                                ; preds = %pic.hit.42
  %r235 = shl i64 %r227, 3
  %r236 = add nuw nsw i64 %r191, 16
  %r237 = add i64 %r236, %r235
  %r238 = inttoptr i64 %r237 to ptr
  %r239 = load double, ptr %r238, align 8
  %r240 = bitcast double %r239 to i64
  %r241 = icmp eq i64 %r240, 9222246136947933200
  br i1 %r241, label %pic.miss.53, label %pic.hit.live.43

pic.ways.61:                                      ; preds = %pic.miss.53
  %r281 = getelementptr i64, ptr %r211, i64 4
  %r282 = load i64, ptr %r281, align 8
  %r283 = icmp eq i64 %r282, %r220
  %r284 = getelementptr i64, ptr %r211, i64 5
  %r285 = load i64, ptr %r284, align 8
  %r286 = select i1 %r283, i64 %r285, i64 0
  %r287 = getelementptr i64, ptr %r211, i64 6
  %r288 = load i64, ptr %r287, align 8
  %r289 = icmp eq i64 %r288, %r220
  %r290 = getelementptr i64, ptr %r211, i64 7
  %r291 = load i64, ptr %r290, align 8
  %r292 = select i1 %r289, i64 %r291, i64 0
  %r293 = getelementptr i64, ptr %r211, i64 8
  %r294 = load i64, ptr %r293, align 8
  %r295 = icmp eq i64 %r294, %r220
  %r296 = getelementptr i64, ptr %r211, i64 9
  %r297 = load i64, ptr %r296, align 8
  %r298 = select i1 %r295, i64 %r297, i64 0
  %r299 = getelementptr i64, ptr %r211, i64 10
  %r300 = load i64, ptr %r299, align 8
  %r301 = icmp eq i64 %r300, %r220
  %r302 = getelementptr i64, ptr %r211, i64 11
  %r303 = load i64, ptr %r302, align 8
  %r304 = select i1 %r301, i64 %r303, i64 0
  %r305 = or i1 %r283, %r289
  %r306 = select i1 %r283, i64 %r286, i64 %r292
  %r307 = or i1 %r295, %r301
  %r308 = select i1 %r295, i64 %r298, i64 %r304
  %r309 = or i1 %r305, %r307
  %r310 = select i1 %r305, i64 %r306, i64 %r308
  %r311 = and i1 %r221, %r309
  br i1 %r311, label %pic.way.load.62, label %pic.miss.call.55

pic.way.load.62:                                  ; preds = %pic.ways.61
  %r312 = shl i64 %r310, 3
  %r313 = add nuw nsw i64 %r191, 16
  %r314 = add i64 %r313, %r312
  %r315 = inttoptr i64 %r314 to ptr
  %r316 = load double, ptr %r315, align 8
  %r317 = bitcast double %r316 to i64
  %r318 = icmp eq i64 %r317, 9222246136947933200
  br i1 %r318, label %pic.miss.call.55, label %pic.way.live.63

pic.way.live.63:                                  ; preds = %pic.way.load.62
  br label %pic.merge.56

pget.throw_nullish.64:                            ; preds = %pget.recv_bad.37
  %r327 = zext i1 %r325 to i32
  %statepoint_token177 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r327, ptr @test_json_cached_template_borrow_ts_.str.7.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.65:                        ; preds = %pget.recv_bad.37
  %r328 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r329 = bitcast double %r328 to i64
  %r330 = and i64 %r329, 281474976710655
  %statepoint_token178 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r190, i64 %r330, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated136, ptr addrspace(1) %r48.0.base.relocated137, ptr addrspace(1) %rs4gc.s13.relocated138, ptr addrspace(1) %rs4gc.s15, ptr addrspace(1) %rs4gc.s10.relocated139, ptr addrspace(1) %r48.0.relocated140, ptr addrspace(1) %rs4gc.s14.relocated141) ]
  %r331179 = call double @llvm.experimental.gc.result.f64(token %statepoint_token178)
  %r57.0.relocated180 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 0, i32 0) ; (%r57.0.relocated136, %r57.0.relocated136)
  %r48.0.base.relocated181 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 1, i32 1) ; (%r48.0.base.relocated137, %r48.0.base.relocated137)
  %rs4gc.s13.relocated182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 2, i32 2) ; (%rs4gc.s13.relocated138, %rs4gc.s13.relocated138)
  %rs4gc.s15.relocated183 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 3, i32 3) ; (%rs4gc.s15, %rs4gc.s15)
  %rs4gc.s10.relocated184 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 4, i32 4) ; (%rs4gc.s10.relocated139, %rs4gc.s10.relocated139)
  %r48.0.relocated185 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 1, i32 5) ; (%r48.0.base.relocated137, %r48.0.relocated140)
  %rs4gc.s14.relocated186 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 6, i32 6) ; (%rs4gc.s14.relocated141, %rs4gc.s14.relocated141)
  br label %pget.recv_merge.39

tav.set.fast.66:                                  ; preds = %pget.recv_merge.39
  %r360 = bitcast double %r336 to i64
  %r361 = and i64 %r360, 281474976710655
  %r362 = lshr i64 %r361, 3
  %r363 = and i64 %r362, 63
  %r364 = getelementptr [64 x i64], ptr @PERRY_TA_KIND_CACHE, i64 0, i64 %r363
  %r365 = load i64, ptr %r364, align 8
  %r366 = and i64 %r365, 255
  %r370 = inttoptr i64 %r361 to ptr
  %r371 = load i32, ptr %r370, align 4
  %r372 = zext i32 %r371 to i64
  %r373 = icmp ult i64 0, %r372
  %r374 = and i1 true, %r373
  br i1 %r374, label %tav.set.store.67, label %tav.set.slow.68

tav.set.store.67:                                 ; preds = %tav.set.fast.66
  %r375 = add nuw nsw i64 %r361, 16
  %r376 = fcmp uno double %r337, 0.000000e+00
  %r377 = call double @llvm.fabs.f64(double %r337)
  %r378 = fcmp oeq double %r377, 0x7FF0000000000000
  %r379 = or i1 %r376, %r378
  %r380 = select i1 %r379, double 0.000000e+00, double %r337
  %r381 = fptosi double %r380 to i64
  %r382 = trunc i64 %r381 to i32
  %r383 = icmp eq i64 %r366, 0
  br i1 %r383, label %tav.s.i8.70, label %tav.sd1.78

tav.set.slow.68:                                  ; preds = %tav.set.fast.66, %pget.recv_merge.39
  %statepoint_token187 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double, i32)) @js_dyn_index_set_strict, i32 4, i32 0, double %r336, double 0.000000e+00, double %r337, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3931, ptr addrspace(1) %.3974, ptr addrspace(1) %.01051, ptr addrspace(1) %.01071, ptr addrspace(1) %.3, ptr addrspace(1) %.31014, ptr addrspace(1) %.01068) ]
  %r57.0.relocated188 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token187, i32 0, i32 0) ; (%.3931, %.3931)
  %r48.0.base.relocated189 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token187, i32 1, i32 1) ; (%.3974, %.3974)
  %rs4gc.s13.relocated190 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token187, i32 2, i32 2) ; (%.01051, %.01051)
  %rs4gc.s15.relocated191 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token187, i32 3, i32 3) ; (%.01071, %.01071)
  %rs4gc.s10.relocated192 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token187, i32 4, i32 4) ; (%.3, %.3)
  %r48.0.relocated193 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token187, i32 1, i32 5) ; (%.3974, %.31014)
  %rs4gc.s14.relocated194 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token187, i32 6, i32 6) ; (%.01068, %.01068)
  br label %tav.set.merge.69

tav.set.merge.69:                                 ; preds = %tav.s.f64.77, %tav.s.f32.76, %tav.s.u32.75, %tav.s.i32.74, %tav.s.u16.73, %tav.s.i16.72, %tav.s.u8.71, %tav.s.i8.70, %tav.set.slow.68
  %.21073 = phi ptr addrspace(1) [ %.01071, %tav.s.i8.70 ], [ %.01071, %tav.s.u8.71 ], [ %.01071, %tav.s.i16.72 ], [ %.01071, %tav.s.u16.73 ], [ %.01071, %tav.s.i32.74 ], [ %.01071, %tav.s.u32.75 ], [ %.01071, %tav.s.f32.76 ], [ %.01071, %tav.s.f64.77 ], [ %rs4gc.s15.relocated191, %tav.set.slow.68 ]
  %.21070 = phi ptr addrspace(1) [ %.01068, %tav.s.i8.70 ], [ %.01068, %tav.s.u8.71 ], [ %.01068, %tav.s.i16.72 ], [ %.01068, %tav.s.u16.73 ], [ %.01068, %tav.s.i32.74 ], [ %.01068, %tav.s.u32.75 ], [ %.01068, %tav.s.f32.76 ], [ %.01068, %tav.s.f64.77 ], [ %rs4gc.s14.relocated194, %tav.set.slow.68 ]
  %.21053 = phi ptr addrspace(1) [ %.01051, %tav.s.i8.70 ], [ %.01051, %tav.s.u8.71 ], [ %.01051, %tav.s.i16.72 ], [ %.01051, %tav.s.u16.73 ], [ %.01051, %tav.s.i32.74 ], [ %.01051, %tav.s.u32.75 ], [ %.01051, %tav.s.f32.76 ], [ %.01051, %tav.s.f64.77 ], [ %rs4gc.s13.relocated190, %tav.set.slow.68 ]
  %.51016 = phi ptr addrspace(1) [ %.31014, %tav.s.i8.70 ], [ %.31014, %tav.s.u8.71 ], [ %.31014, %tav.s.i16.72 ], [ %.31014, %tav.s.u16.73 ], [ %.31014, %tav.s.i32.74 ], [ %.31014, %tav.s.u32.75 ], [ %.31014, %tav.s.f32.76 ], [ %.31014, %tav.s.f64.77 ], [ %r48.0.relocated193, %tav.set.slow.68 ]
  %.5976 = phi ptr addrspace(1) [ %.3974, %tav.s.i8.70 ], [ %.3974, %tav.s.u8.71 ], [ %.3974, %tav.s.i16.72 ], [ %.3974, %tav.s.u16.73 ], [ %.3974, %tav.s.i32.74 ], [ %.3974, %tav.s.u32.75 ], [ %.3974, %tav.s.f32.76 ], [ %.3974, %tav.s.f64.77 ], [ %r48.0.base.relocated189, %tav.set.slow.68 ]
  %.5933 = phi ptr addrspace(1) [ %.3931, %tav.s.i8.70 ], [ %.3931, %tav.s.u8.71 ], [ %.3931, %tav.s.i16.72 ], [ %.3931, %tav.s.u16.73 ], [ %.3931, %tav.s.i32.74 ], [ %.3931, %tav.s.u32.75 ], [ %.3931, %tav.s.f32.76 ], [ %.3931, %tav.s.f64.77 ], [ %r57.0.relocated188, %tav.set.slow.68 ]
  %.5 = phi ptr addrspace(1) [ %.3, %tav.s.i8.70 ], [ %.3, %tav.s.u8.71 ], [ %.3, %tav.s.i16.72 ], [ %.3, %tav.s.u16.73 ], [ %.3, %tav.s.i32.74 ], [ %.3, %tav.s.u32.75 ], [ %.3, %tav.s.f32.76 ], [ %.3, %tav.s.f64.77 ], [ %rs4gc.s10.relocated192, %tav.set.slow.68 ]
  %r420.rs4i = ptrtoint ptr addrspace(1) %.21070 to i64
  %r420.rs4o = call i64 asm "", "=r,0"(i64 %r420.rs4i) #7
  %r420 = bitcast i64 %r420.rs4o to double
  %r421 = bitcast double %r420 to i64
  %r422 = and i64 %r421, 281474976710655
  %r423 = lshr i64 %r421, 48
  %r424 = and i64 %r423, 65533
  %r425 = icmp eq i64 %r424, 32765
  br i1 %r425, label %pget.recv_ok.85, label %pget.recv_other.89

tav.s.i8.70:                                      ; preds = %tav.set.store.67
  %r391 = add nuw nsw i64 %r375, 0
  %r392 = inttoptr i64 %r391 to ptr
  %r393 = trunc i32 %r382 to i8
  store i8 %r393, ptr %r392, align 1
  br label %tav.set.merge.69

tav.s.u8.71:                                      ; preds = %tav.sd1.78
  %r395 = add nuw nsw i64 %r375, 0
  %r396 = inttoptr i64 %r395 to ptr
  %r397 = trunc i32 %r382 to i8
  store i8 %r397, ptr %r396, align 1
  br label %tav.set.merge.69

tav.s.i16.72:                                     ; preds = %tav.sd2.79
  %r399 = add nuw nsw i64 %r375, 0
  %r400 = inttoptr i64 %r399 to ptr
  %r401 = trunc i32 %r382 to i16
  store i16 %r401, ptr %r400, align 2
  br label %tav.set.merge.69

tav.s.u16.73:                                     ; preds = %tav.sd3.80
  %r403 = add nuw nsw i64 %r375, 0
  %r404 = inttoptr i64 %r403 to ptr
  %r405 = trunc i32 %r382 to i16
  store i16 %r405, ptr %r404, align 2
  br label %tav.set.merge.69

tav.s.i32.74:                                     ; preds = %tav.sd4.81
  %r407 = add nuw nsw i64 %r375, 0
  %r408 = inttoptr i64 %r407 to ptr
  store i32 %r382, ptr %r408, align 4
  br label %tav.set.merge.69

tav.s.u32.75:                                     ; preds = %tav.sd5.82
  %r410 = add nuw nsw i64 %r375, 0
  %r411 = inttoptr i64 %r410 to ptr
  store i32 %r382, ptr %r411, align 4
  br label %tav.set.merge.69

tav.s.f32.76:                                     ; preds = %tav.sd6.83
  %r413 = add nuw nsw i64 %r375, 0
  %r414 = inttoptr i64 %r413 to ptr
  %r415 = fptrunc double %r337 to float
  store float %r415, ptr %r414, align 4
  br label %tav.set.merge.69

tav.s.f64.77:                                     ; preds = %tav.sd6.83
  %r417 = add nuw nsw i64 %r375, 0
  %r418 = inttoptr i64 %r417 to ptr
  store double %r337, ptr %r418, align 8
  br label %tav.set.merge.69

tav.sd1.78:                                       ; preds = %tav.set.store.67
  %r384 = icmp eq i64 %r366, 1
  br i1 %r384, label %tav.s.u8.71, label %tav.sd2.79

tav.sd2.79:                                       ; preds = %tav.sd1.78
  %r385 = icmp eq i64 %r366, 2
  br i1 %r385, label %tav.s.i16.72, label %tav.sd3.80

tav.sd3.80:                                       ; preds = %tav.sd2.79
  %r386 = icmp eq i64 %r366, 3
  br i1 %r386, label %tav.s.u16.73, label %tav.sd4.81

tav.sd4.81:                                       ; preds = %tav.sd3.80
  %r387 = icmp eq i64 %r366, 4
  br i1 %r387, label %tav.s.i32.74, label %tav.sd5.82

tav.sd5.82:                                       ; preds = %tav.sd4.81
  %r388 = icmp eq i64 %r366, 5
  br i1 %r388, label %tav.s.u32.75, label %tav.sd6.83

tav.sd6.83:                                       ; preds = %tav.sd5.82
  %r389 = icmp eq i64 %r366, 6
  br i1 %r389, label %tav.s.f32.76, label %tav.s.f64.77

pget.recv_sso.84:                                 ; preds = %pget.recv_other.89
  %r563 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r564 = bitcast double %r563 to i64
  %r565 = and i64 %r564, 281474976710655
  %statepoint_token195 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r421, i64 %r565, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5933, ptr addrspace(1) %.5, ptr addrspace(1) %.5976, ptr addrspace(1) %.51016, ptr addrspace(1) %.21053, ptr addrspace(1) %.21073) ]
  %r566196 = call double @llvm.experimental.gc.result.f64(token %statepoint_token195)
  %r57.0.relocated197 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token195, i32 0, i32 0) ; (%.5933, %.5933)
  %rs4gc.s10.relocated198 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token195, i32 1, i32 1) ; (%.5, %.5)
  %r48.0.base.relocated199 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token195, i32 2, i32 2) ; (%.5976, %.5976)
  %r48.0.relocated200 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token195, i32 2, i32 3) ; (%.5976, %.51016)
  %rs4gc.s13.relocated201 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token195, i32 4, i32 4) ; (%.21053, %.21053)
  %rs4gc.s15.relocated202 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token195, i32 5, i32 5) ; (%.21073, %.21073)
  br label %pget.recv_merge.88

pget.recv_ok.85:                                  ; preds = %tav.set.merge.69
  %r432 = icmp ugt i64 %r422, 1048575
  br i1 %r432, label %pic.recv_hdr.106, label %pic.miss.cold.103

pget.recv_bad.86:                                 ; preds = %pget.check_class_ref.90
  %r555 = icmp eq i64 %r421, 9222246136947933185
  %r556 = icmp eq i64 %r421, 9222246136947933186
  %r557 = or i1 %r555, %r556
  br i1 %r557, label %pget.throw_nullish.113, label %pget.recv_undef_return.114

pget.recv_class_ref.87:                           ; preds = %pget.check_class_ref.90
  %r428 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r429 = bitcast double %r428 to i64
  %r430 = and i64 %r429, 281474976710655
  %statepoint_token203 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 8988321885632593927, i64 %r421, i64 %r430, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5933, ptr addrspace(1) %.5, ptr addrspace(1) %.5976, ptr addrspace(1) %.51016, ptr addrspace(1) %.21053, ptr addrspace(1) %.21073) ]
  %r431204 = call double @llvm.experimental.gc.result.f64(token %statepoint_token203)
  %r57.0.relocated205 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 0, i32 0) ; (%.5933, %.5933)
  %rs4gc.s10.relocated206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 1, i32 1) ; (%.5, %.5)
  %r48.0.base.relocated207 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 2, i32 2) ; (%.5976, %.5976)
  %r48.0.relocated208 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 2, i32 3) ; (%.5976, %.51016)
  %rs4gc.s13.relocated209 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 4, i32 4) ; (%.21053, %.21053)
  %rs4gc.s15.relocated210 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token203, i32 5, i32 5) ; (%.21073, %.21073)
  br label %pget.recv_merge.88

pget.recv_merge.88:                               ; preds = %pget.recv_undef_return.114, %pic.merge.105, %pget.recv_class_ref.87, %pget.recv_sso.84
  %.31074 = phi ptr addrspace(1) [ %.41075, %pic.merge.105 ], [ %rs4gc.s15.relocated202, %pget.recv_sso.84 ], [ %rs4gc.s15.relocated210, %pget.recv_class_ref.87 ], [ %rs4gc.s15.relocated242, %pget.recv_undef_return.114 ]
  %.31054 = phi ptr addrspace(1) [ %.41055, %pic.merge.105 ], [ %rs4gc.s13.relocated201, %pget.recv_sso.84 ], [ %rs4gc.s13.relocated209, %pget.recv_class_ref.87 ], [ %rs4gc.s13.relocated241, %pget.recv_undef_return.114 ]
  %.61017 = phi ptr addrspace(1) [ %.71018, %pic.merge.105 ], [ %r48.0.relocated200, %pget.recv_sso.84 ], [ %r48.0.relocated208, %pget.recv_class_ref.87 ], [ %r48.0.relocated240, %pget.recv_undef_return.114 ]
  %.6977 = phi ptr addrspace(1) [ %.7978, %pic.merge.105 ], [ %r48.0.base.relocated199, %pget.recv_sso.84 ], [ %r48.0.base.relocated207, %pget.recv_class_ref.87 ], [ %r48.0.base.relocated239, %pget.recv_undef_return.114 ]
  %.6934 = phi ptr addrspace(1) [ %.7935, %pic.merge.105 ], [ %r57.0.relocated197, %pget.recv_sso.84 ], [ %r57.0.relocated205, %pget.recv_class_ref.87 ], [ %r57.0.relocated237, %pget.recv_undef_return.114 ]
  %.6 = phi ptr addrspace(1) [ %.7, %pic.merge.105 ], [ %rs4gc.s10.relocated198, %pget.recv_sso.84 ], [ %rs4gc.s10.relocated206, %pget.recv_class_ref.87 ], [ %rs4gc.s10.relocated238, %pget.recv_undef_return.114 ]
  %r567 = phi double [ %r554, %pic.merge.105 ], [ %r562236, %pget.recv_undef_return.114 ], [ %r566196, %pget.recv_sso.84 ], [ %r431204, %pget.recv_class_ref.87 ]
  %r569 = or i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.9.dispatch to i64), 9221120237041090560
  %r571 = getelementptr double, ptr %r570, i64 0
  store double 9.900000e+01, ptr %r571, align 8
  %statepoint_token211 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, i64, ptr, i64)) @js_typed_feedback_native_call_method_by_id, i32 5, i32 0, i64 8988321885632593929, double %r567, i64 %r569, ptr %r570, i64 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6934, ptr addrspace(1) %.6, ptr addrspace(1) %.6977, ptr addrspace(1) %.61017, ptr addrspace(1) %.31054, ptr addrspace(1) %.31074) ]
  %r57.0.relocated212 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 0, i32 0) ; (%.6934, %.6934)
  %rs4gc.s10.relocated213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 1, i32 1) ; (%.6, %.6)
  %r48.0.base.relocated214 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 2, i32 2) ; (%.6977, %.6977)
  %r48.0.relocated215 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 2, i32 3) ; (%.6977, %.61017)
  %rs4gc.s13.relocated216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 4, i32 4) ; (%.31054, %.31054)
  %rs4gc.s15.relocated217 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token211, i32 5, i32 5) ; (%.31074, %.31074)
  %r573.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15.relocated217 to i64
  %r573.rs4o = call i64 asm "", "=r,0"(i64 %r573.rs4i) #7
  %r573 = bitcast i64 %r573.rs4o to double
  %r574 = bitcast double %r573 to i64
  %r575 = and i64 %r574, 281474976710655
  %r576 = lshr i64 %r574, 48
  %r577 = and i64 %r576, 65533
  %r578 = icmp eq i64 %r577, 32765
  br i1 %r578, label %pget.recv_ok.116, label %pget.recv_other.120

pget.recv_other.89:                               ; preds = %tav.set.merge.69
  %r426 = icmp eq i64 %r423, 32761
  br i1 %r426, label %pget.recv_sso.84, label %pget.check_class_ref.90

pget.check_class_ref.90:                          ; preds = %pget.recv_other.89
  %r427 = icmp eq i64 %r423, 32766
  br i1 %r427, label %pget.recv_class_ref.87, label %pget.recv_bad.86

pic.hit.91:                                       ; preds = %pic.token.107
  %r457 = getelementptr i64, ptr %r442, i64 1
  %r458 = load i64, ptr %r457, align 8
  %r459 = and i64 %r458, 1073741824
  %r460 = icmp ne i64 %r459, 0
  br i1 %r460, label %pic.hit.overflow.108, label %pic.hit.inline.109

pic.hit.live.92:                                  ; preds = %pic.hit.inline.109
  br label %pic.merge.105

pic.prefix.guard.93:                              ; preds = %pic.token.107
  %r473 = getelementptr i64, ptr %r442, i64 2
  %r474 = load i64, ptr %r473, align 8
  %r475 = icmp ne i64 %r474, 0
  br i1 %r475, label %pic.prefix.meta.94, label %pic.miss.102

pic.prefix.meta.94:                               ; preds = %pic.prefix.guard.93
  %r476 = add nuw nsw i64 %r422, 8
  %r477 = inttoptr i64 %r476 to ptr
  %r478 = load i64, ptr %r477, align 8
  %r479 = icmp ne i64 %r478, 0
  br i1 %r479, label %pic.prefix.token.95, label %pic.miss.102

pic.prefix.token.95:                              ; preds = %pic.prefix.meta.94
  %r480 = inttoptr i64 %r478 to ptr
  %r481 = getelementptr i64, ptr %r480, i64 6
  %r482 = load i64, ptr %r481, align 8
  %r483 = icmp eq i64 %r482, %r474
  br i1 %r483, label %pic.prefix.hit.96, label %pic.miss.102

pic.prefix.hit.96:                                ; preds = %pic.prefix.token.95
  %r484 = getelementptr i64, ptr %r442, i64 1
  %r485 = load i64, ptr %r484, align 8
  %r486 = shl i64 %r485, 3
  %r487 = add nuw nsw i64 %r422, 16
  %r488 = add i64 %r487, %r486
  %r489 = inttoptr i64 %r488 to ptr
  %r490 = load double, ptr %r489, align 8
  br label %pic.merge.105

pic.desc.classify.97:                             ; preds = %pic.recv_hdr.106
  %r446 = and i1 %r436, %r443
  br i1 %r446, label %pic.desc.prefix.guard.98, label %pic.miss.cold.103

pic.desc.prefix.guard.98:                         ; preds = %pic.desc.classify.97
  %r491 = getelementptr i64, ptr %r442, i64 2
  %r492 = load i64, ptr %r491, align 8
  %r493 = icmp ne i64 %r492, 0
  br i1 %r493, label %pic.desc.prefix.meta.99, label %pic.miss.cold.103

pic.desc.prefix.meta.99:                          ; preds = %pic.desc.prefix.guard.98
  %r494 = add nuw nsw i64 %r422, 8
  %r495 = inttoptr i64 %r494 to ptr
  %r496 = load i64, ptr %r495, align 8
  %r497 = icmp ne i64 %r496, 0
  br i1 %r497, label %pic.desc.prefix.token.100, label %pic.miss.cold.103

pic.desc.prefix.token.100:                        ; preds = %pic.desc.prefix.meta.99
  %r498 = inttoptr i64 %r496 to ptr
  %r499 = getelementptr i64, ptr %r498, i64 6
  %r500 = load i64, ptr %r499, align 8
  %r501 = icmp eq i64 %r500, %r492
  br i1 %r501, label %pic.desc.prefix.hit.101, label %pic.miss.cold.103

pic.desc.prefix.hit.101:                          ; preds = %pic.desc.prefix.token.100
  %r502 = getelementptr i64, ptr %r442, i64 1
  %r503 = load i64, ptr %r502, align 8
  %r504 = shl i64 %r503, 3
  %r505 = add nuw nsw i64 %r422, 16
  %r506 = add i64 %r505, %r504
  %r507 = inttoptr i64 %r506 to ptr
  %r508 = load double, ptr %r507, align 8
  br label %pic.merge.105

pic.miss.102:                                     ; preds = %pic.hit.inline.109, %pic.prefix.token.95, %pic.prefix.meta.94, %pic.prefix.guard.93
  %r509 = getelementptr i64, ptr %r442, i64 3
  %r510 = load i64, ptr %r509, align 8
  %r511 = icmp sgt i64 %r510, 0
  br i1 %r511, label %pic.ways.110, label %pic.miss.call.104

pic.miss.cold.103:                                ; preds = %pic.desc.prefix.token.100, %pic.desc.prefix.meta.99, %pic.desc.prefix.guard.98, %pic.desc.classify.97, %pget.recv_ok.85
  br label %pic.miss.call.104

pic.miss.call.104:                                ; preds = %pic.way.load.111, %pic.ways.110, %pic.miss.cold.103, %pic.miss.102
  %r550 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r551 = bitcast double %r550 to i64
  %r552 = and i64 %r551, 281474976710655
  %statepoint_token218 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r422, i64 %r552, ptr @perry_ic_test_json_cached_template_borrow_ts__8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5933, ptr addrspace(1) %.5, ptr addrspace(1) %.5976, ptr addrspace(1) %.51016, ptr addrspace(1) %.21053, ptr addrspace(1) %.21073) ]
  %r553219 = call double @llvm.experimental.gc.result.f64(token %statepoint_token218)
  %r57.0.relocated220 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 0, i32 0) ; (%.5933, %.5933)
  %rs4gc.s10.relocated221 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 1, i32 1) ; (%.5, %.5)
  %r48.0.base.relocated222 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 2, i32 2) ; (%.5976, %.5976)
  %r48.0.relocated223 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 2, i32 3) ; (%.5976, %.51016)
  %rs4gc.s13.relocated224 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 4, i32 4) ; (%.21053, %.21053)
  %rs4gc.s15.relocated225 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token218, i32 5, i32 5) ; (%.21073, %.21073)
  br label %pic.merge.105

pic.merge.105:                                    ; preds = %pic.way.live.112, %pic.hit.overflow.108, %pic.miss.call.104, %pic.desc.prefix.hit.101, %pic.prefix.hit.96, %pic.hit.live.92
  %.41075 = phi ptr addrspace(1) [ %rs4gc.s15.relocated233, %pic.hit.overflow.108 ], [ %rs4gc.s15.relocated225, %pic.miss.call.104 ], [ %.21073, %pic.way.live.112 ], [ %.21073, %pic.hit.live.92 ], [ %.21073, %pic.prefix.hit.96 ], [ %.21073, %pic.desc.prefix.hit.101 ]
  %.41055 = phi ptr addrspace(1) [ %rs4gc.s13.relocated232, %pic.hit.overflow.108 ], [ %rs4gc.s13.relocated224, %pic.miss.call.104 ], [ %.21053, %pic.way.live.112 ], [ %.21053, %pic.hit.live.92 ], [ %.21053, %pic.prefix.hit.96 ], [ %.21053, %pic.desc.prefix.hit.101 ]
  %.71018 = phi ptr addrspace(1) [ %r48.0.relocated231, %pic.hit.overflow.108 ], [ %r48.0.relocated223, %pic.miss.call.104 ], [ %.51016, %pic.way.live.112 ], [ %.51016, %pic.hit.live.92 ], [ %.51016, %pic.prefix.hit.96 ], [ %.51016, %pic.desc.prefix.hit.101 ]
  %.7978 = phi ptr addrspace(1) [ %r48.0.base.relocated230, %pic.hit.overflow.108 ], [ %r48.0.base.relocated222, %pic.miss.call.104 ], [ %.5976, %pic.way.live.112 ], [ %.5976, %pic.hit.live.92 ], [ %.5976, %pic.prefix.hit.96 ], [ %.5976, %pic.desc.prefix.hit.101 ]
  %.7935 = phi ptr addrspace(1) [ %r57.0.relocated228, %pic.hit.overflow.108 ], [ %r57.0.relocated220, %pic.miss.call.104 ], [ %.5933, %pic.way.live.112 ], [ %.5933, %pic.hit.live.92 ], [ %.5933, %pic.prefix.hit.96 ], [ %.5933, %pic.desc.prefix.hit.101 ]
  %.7 = phi ptr addrspace(1) [ %rs4gc.s10.relocated229, %pic.hit.overflow.108 ], [ %rs4gc.s10.relocated221, %pic.miss.call.104 ], [ %.5, %pic.way.live.112 ], [ %.5, %pic.hit.live.92 ], [ %.5, %pic.prefix.hit.96 ], [ %.5, %pic.desc.prefix.hit.101 ]
  %r554 = phi double [ %r470, %pic.hit.live.92 ], [ %r465227, %pic.hit.overflow.108 ], [ %r490, %pic.prefix.hit.96 ], [ %r508, %pic.desc.prefix.hit.101 ], [ %r547, %pic.way.live.112 ], [ %r553219, %pic.miss.call.104 ]
  br label %pget.recv_merge.88

pic.recv_hdr.106:                                 ; preds = %pget.recv_ok.85
  %r433 = sub nuw nsw i64 %r422, 8
  %r434 = inttoptr i64 %r433 to ptr
  %r435 = load i8, ptr %r434, align 1
  %r436 = icmp eq i8 %r435, 2
  %r437 = sub nuw nsw i64 %r422, 6
  %r438 = inttoptr i64 %r437 to ptr
  %r439 = load i16, ptr %r438, align 2
  %r440 = and i16 %r439, 2048
  %r441 = icmp eq i16 %r440, 0
  %r442 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__8, align 8
  %r443 = icmp ne ptr %r442, null
  %r444 = and i1 %r436, %r441
  %r445 = and i1 %r444, %r443
  br i1 %r445, label %pic.token.107, label %pic.desc.classify.97

pic.token.107:                                    ; preds = %pic.recv_hdr.106
  %r447 = add nuw nsw i64 %r422, 4
  %r448 = inttoptr i64 %r447 to ptr
  %r449 = load i32, ptr %r448, align 4
  %r450 = zext i32 %r449 to i64
  %r451 = or i64 %r450, 4611686018427387904
  %r452 = icmp ne i32 %r449, 0
  %r453 = getelementptr i64, ptr %r442, i64 0
  %r454 = load i64, ptr %r453, align 8
  %r455 = icmp eq i64 %r451, %r454
  %r456 = and i1 %r455, %r452
  br i1 %r456, label %pic.hit.91, label %pic.prefix.guard.93

pic.hit.overflow.108:                             ; preds = %pic.hit.91
  %r461 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r462 = bitcast double %r461 to i64
  %r463 = and i64 %r462, 281474976710655
  %r464 = trunc i64 %r458 to i32
  %statepoint_token226 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r422, i64 %r463, i32 %r464, ptr @perry_ic_test_json_cached_template_borrow_ts__8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5933, ptr addrspace(1) %.5, ptr addrspace(1) %.5976, ptr addrspace(1) %.51016, ptr addrspace(1) %.21053, ptr addrspace(1) %.21073) ]
  %r465227 = call double @llvm.experimental.gc.result.f64(token %statepoint_token226)
  %r57.0.relocated228 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token226, i32 0, i32 0) ; (%.5933, %.5933)
  %rs4gc.s10.relocated229 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token226, i32 1, i32 1) ; (%.5, %.5)
  %r48.0.base.relocated230 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token226, i32 2, i32 2) ; (%.5976, %.5976)
  %r48.0.relocated231 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token226, i32 2, i32 3) ; (%.5976, %.51016)
  %rs4gc.s13.relocated232 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token226, i32 4, i32 4) ; (%.21053, %.21053)
  %rs4gc.s15.relocated233 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token226, i32 5, i32 5) ; (%.21073, %.21073)
  br label %pic.merge.105

pic.hit.inline.109:                               ; preds = %pic.hit.91
  %r466 = shl i64 %r458, 3
  %r467 = add nuw nsw i64 %r422, 16
  %r468 = add i64 %r467, %r466
  %r469 = inttoptr i64 %r468 to ptr
  %r470 = load double, ptr %r469, align 8
  %r471 = bitcast double %r470 to i64
  %r472 = icmp eq i64 %r471, 9222246136947933200
  br i1 %r472, label %pic.miss.102, label %pic.hit.live.92

pic.ways.110:                                     ; preds = %pic.miss.102
  %r512 = getelementptr i64, ptr %r442, i64 4
  %r513 = load i64, ptr %r512, align 8
  %r514 = icmp eq i64 %r513, %r451
  %r515 = getelementptr i64, ptr %r442, i64 5
  %r516 = load i64, ptr %r515, align 8
  %r517 = select i1 %r514, i64 %r516, i64 0
  %r518 = getelementptr i64, ptr %r442, i64 6
  %r519 = load i64, ptr %r518, align 8
  %r520 = icmp eq i64 %r519, %r451
  %r521 = getelementptr i64, ptr %r442, i64 7
  %r522 = load i64, ptr %r521, align 8
  %r523 = select i1 %r520, i64 %r522, i64 0
  %r524 = getelementptr i64, ptr %r442, i64 8
  %r525 = load i64, ptr %r524, align 8
  %r526 = icmp eq i64 %r525, %r451
  %r527 = getelementptr i64, ptr %r442, i64 9
  %r528 = load i64, ptr %r527, align 8
  %r529 = select i1 %r526, i64 %r528, i64 0
  %r530 = getelementptr i64, ptr %r442, i64 10
  %r531 = load i64, ptr %r530, align 8
  %r532 = icmp eq i64 %r531, %r451
  %r533 = getelementptr i64, ptr %r442, i64 11
  %r534 = load i64, ptr %r533, align 8
  %r535 = select i1 %r532, i64 %r534, i64 0
  %r536 = or i1 %r514, %r520
  %r537 = select i1 %r514, i64 %r517, i64 %r523
  %r538 = or i1 %r526, %r532
  %r539 = select i1 %r526, i64 %r529, i64 %r535
  %r540 = or i1 %r536, %r538
  %r541 = select i1 %r536, i64 %r537, i64 %r539
  %r542 = and i1 %r452, %r540
  br i1 %r542, label %pic.way.load.111, label %pic.miss.call.104

pic.way.load.111:                                 ; preds = %pic.ways.110
  %r543 = shl i64 %r541, 3
  %r544 = add nuw nsw i64 %r422, 16
  %r545 = add i64 %r544, %r543
  %r546 = inttoptr i64 %r545 to ptr
  %r547 = load double, ptr %r546, align 8
  %r548 = bitcast double %r547 to i64
  %r549 = icmp eq i64 %r548, 9222246136947933200
  br i1 %r549, label %pic.miss.call.104, label %pic.way.live.112

pic.way.live.112:                                 ; preds = %pic.way.load.111
  br label %pic.merge.105

pget.throw_nullish.113:                           ; preds = %pget.recv_bad.86
  %r558 = zext i1 %r556 to i32
  %statepoint_token234 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r558, ptr @test_json_cached_template_borrow_ts_.str.7.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.114:                       ; preds = %pget.recv_bad.86
  %r559 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r560 = bitcast double %r559 to i64
  %r561 = and i64 %r560, 281474976710655
  %statepoint_token235 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r421, i64 %r561, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5933, ptr addrspace(1) %.5, ptr addrspace(1) %.5976, ptr addrspace(1) %.51016, ptr addrspace(1) %.21053, ptr addrspace(1) %.21073) ]
  %r562236 = call double @llvm.experimental.gc.result.f64(token %statepoint_token235)
  %r57.0.relocated237 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 0, i32 0) ; (%.5933, %.5933)
  %rs4gc.s10.relocated238 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 1, i32 1) ; (%.5, %.5)
  %r48.0.base.relocated239 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 2, i32 2) ; (%.5976, %.5976)
  %r48.0.relocated240 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 2, i32 3) ; (%.5976, %.51016)
  %rs4gc.s13.relocated241 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 4, i32 4) ; (%.21053, %.21053)
  %rs4gc.s15.relocated242 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token235, i32 5, i32 5) ; (%.21073, %.21073)
  br label %pget.recv_merge.88

pget.recv_sso.115:                                ; preds = %pget.recv_other.120
  %r716 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r717 = bitcast double %r716 to i64
  %r718 = and i64 %r717, 281474976710655
  %statepoint_token243 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r574, i64 %r718, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated212, ptr addrspace(1) %rs4gc.s10.relocated213, ptr addrspace(1) %r48.0.base.relocated214, ptr addrspace(1) %r48.0.relocated215, ptr addrspace(1) %rs4gc.s13.relocated216, ptr addrspace(1) %rs4gc.s15.relocated217) ]
  %r719244 = call double @llvm.experimental.gc.result.f64(token %statepoint_token243)
  %r57.0.relocated245 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 0, i32 0) ; (%r57.0.relocated212, %r57.0.relocated212)
  %rs4gc.s10.relocated246 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 1, i32 1) ; (%rs4gc.s10.relocated213, %rs4gc.s10.relocated213)
  %r48.0.base.relocated247 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 2, i32 2) ; (%r48.0.base.relocated214, %r48.0.base.relocated214)
  %r48.0.relocated248 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 2, i32 3) ; (%r48.0.base.relocated214, %r48.0.relocated215)
  %rs4gc.s13.relocated249 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 4, i32 4) ; (%rs4gc.s13.relocated216, %rs4gc.s13.relocated216)
  %rs4gc.s15.relocated250 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token243, i32 5, i32 5) ; (%rs4gc.s15.relocated217, %rs4gc.s15.relocated217)
  br label %pget.recv_merge.119

pget.recv_ok.116:                                 ; preds = %pget.recv_merge.88
  %r585 = icmp ugt i64 %r575, 1048575
  br i1 %r585, label %pic.recv_hdr.137, label %pic.miss.cold.134

pget.recv_bad.117:                                ; preds = %pget.check_class_ref.121
  %r708 = icmp eq i64 %r574, 9222246136947933185
  %r709 = icmp eq i64 %r574, 9222246136947933186
  %r710 = or i1 %r708, %r709
  br i1 %r710, label %pget.throw_nullish.144, label %pget.recv_undef_return.145

pget.recv_class_ref.118:                          ; preds = %pget.check_class_ref.121
  %r581 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r582 = bitcast double %r581 to i64
  %r583 = and i64 %r582, 281474976710655
  %statepoint_token251 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 8988321885632593930, i64 %r574, i64 %r583, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated212, ptr addrspace(1) %rs4gc.s10.relocated213, ptr addrspace(1) %r48.0.base.relocated214, ptr addrspace(1) %r48.0.relocated215, ptr addrspace(1) %rs4gc.s13.relocated216, ptr addrspace(1) %rs4gc.s15.relocated217) ]
  %r584252 = call double @llvm.experimental.gc.result.f64(token %statepoint_token251)
  %r57.0.relocated253 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 0, i32 0) ; (%r57.0.relocated212, %r57.0.relocated212)
  %rs4gc.s10.relocated254 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 1, i32 1) ; (%rs4gc.s10.relocated213, %rs4gc.s10.relocated213)
  %r48.0.base.relocated255 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 2, i32 2) ; (%r48.0.base.relocated214, %r48.0.base.relocated214)
  %r48.0.relocated256 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 2, i32 3) ; (%r48.0.base.relocated214, %r48.0.relocated215)
  %rs4gc.s13.relocated257 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 4, i32 4) ; (%rs4gc.s13.relocated216, %rs4gc.s13.relocated216)
  %rs4gc.s15.relocated258 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token251, i32 5, i32 5) ; (%rs4gc.s15.relocated217, %rs4gc.s15.relocated217)
  br label %pget.recv_merge.119

pget.recv_merge.119:                              ; preds = %pget.recv_undef_return.145, %pic.merge.136, %pget.recv_class_ref.118, %pget.recv_sso.115
  %.51076 = phi ptr addrspace(1) [ %.61077, %pic.merge.136 ], [ %rs4gc.s15.relocated250, %pget.recv_sso.115 ], [ %rs4gc.s15.relocated258, %pget.recv_class_ref.118 ], [ %rs4gc.s15.relocated283, %pget.recv_undef_return.145 ]
  %.51056 = phi ptr addrspace(1) [ %.61057, %pic.merge.136 ], [ %rs4gc.s13.relocated249, %pget.recv_sso.115 ], [ %rs4gc.s13.relocated257, %pget.recv_class_ref.118 ], [ %rs4gc.s13.relocated282, %pget.recv_undef_return.145 ]
  %.81019 = phi ptr addrspace(1) [ %.91020, %pic.merge.136 ], [ %r48.0.relocated248, %pget.recv_sso.115 ], [ %r48.0.relocated256, %pget.recv_class_ref.118 ], [ %r48.0.relocated281, %pget.recv_undef_return.145 ]
  %.8979 = phi ptr addrspace(1) [ %.9980, %pic.merge.136 ], [ %r48.0.base.relocated247, %pget.recv_sso.115 ], [ %r48.0.base.relocated255, %pget.recv_class_ref.118 ], [ %r48.0.base.relocated280, %pget.recv_undef_return.145 ]
  %.8936 = phi ptr addrspace(1) [ %.9937, %pic.merge.136 ], [ %r57.0.relocated245, %pget.recv_sso.115 ], [ %r57.0.relocated253, %pget.recv_class_ref.118 ], [ %r57.0.relocated278, %pget.recv_undef_return.145 ]
  %.8 = phi ptr addrspace(1) [ %.9, %pic.merge.136 ], [ %rs4gc.s10.relocated246, %pget.recv_sso.115 ], [ %rs4gc.s10.relocated254, %pget.recv_class_ref.118 ], [ %rs4gc.s10.relocated279, %pget.recv_undef_return.145 ]
  %r720 = phi double [ %r707, %pic.merge.136 ], [ %r715277, %pget.recv_undef_return.145 ], [ %r719244, %pget.recv_sso.115 ], [ %r584252, %pget.recv_class_ref.118 ]
  %r721 = bitcast double %r720 to i64
  %r722 = and i64 %r721, 281474976710655
  %r723 = lshr i64 %r721, 48
  %r724 = and i64 %r723, 65533
  %r725 = icmp eq i64 %r724, 32765
  br i1 %r725, label %pget.recv_ok.147, label %pget.recv_other.152

pget.recv_other.120:                              ; preds = %pget.recv_merge.88
  %r579 = icmp eq i64 %r576, 32761
  br i1 %r579, label %pget.recv_sso.115, label %pget.check_class_ref.121

pget.check_class_ref.121:                         ; preds = %pget.recv_other.120
  %r580 = icmp eq i64 %r576, 32766
  br i1 %r580, label %pget.recv_class_ref.118, label %pget.recv_bad.117

pic.hit.122:                                      ; preds = %pic.token.138
  %r610 = getelementptr i64, ptr %r595, i64 1
  %r611 = load i64, ptr %r610, align 8
  %r612 = and i64 %r611, 1073741824
  %r613 = icmp ne i64 %r612, 0
  br i1 %r613, label %pic.hit.overflow.139, label %pic.hit.inline.140

pic.hit.live.123:                                 ; preds = %pic.hit.inline.140
  br label %pic.merge.136

pic.prefix.guard.124:                             ; preds = %pic.token.138
  %r626 = getelementptr i64, ptr %r595, i64 2
  %r627 = load i64, ptr %r626, align 8
  %r628 = icmp ne i64 %r627, 0
  br i1 %r628, label %pic.prefix.meta.125, label %pic.miss.133

pic.prefix.meta.125:                              ; preds = %pic.prefix.guard.124
  %r629 = add nuw nsw i64 %r575, 8
  %r630 = inttoptr i64 %r629 to ptr
  %r631 = load i64, ptr %r630, align 8
  %r632 = icmp ne i64 %r631, 0
  br i1 %r632, label %pic.prefix.token.126, label %pic.miss.133

pic.prefix.token.126:                             ; preds = %pic.prefix.meta.125
  %r633 = inttoptr i64 %r631 to ptr
  %r634 = getelementptr i64, ptr %r633, i64 6
  %r635 = load i64, ptr %r634, align 8
  %r636 = icmp eq i64 %r635, %r627
  br i1 %r636, label %pic.prefix.hit.127, label %pic.miss.133

pic.prefix.hit.127:                               ; preds = %pic.prefix.token.126
  %r637 = getelementptr i64, ptr %r595, i64 1
  %r638 = load i64, ptr %r637, align 8
  %r639 = shl i64 %r638, 3
  %r640 = add nuw nsw i64 %r575, 16
  %r641 = add i64 %r640, %r639
  %r642 = inttoptr i64 %r641 to ptr
  %r643 = load double, ptr %r642, align 8
  br label %pic.merge.136

pic.desc.classify.128:                            ; preds = %pic.recv_hdr.137
  %r599 = and i1 %r589, %r596
  br i1 %r599, label %pic.desc.prefix.guard.129, label %pic.miss.cold.134

pic.desc.prefix.guard.129:                        ; preds = %pic.desc.classify.128
  %r644 = getelementptr i64, ptr %r595, i64 2
  %r645 = load i64, ptr %r644, align 8
  %r646 = icmp ne i64 %r645, 0
  br i1 %r646, label %pic.desc.prefix.meta.130, label %pic.miss.cold.134

pic.desc.prefix.meta.130:                         ; preds = %pic.desc.prefix.guard.129
  %r647 = add nuw nsw i64 %r575, 8
  %r648 = inttoptr i64 %r647 to ptr
  %r649 = load i64, ptr %r648, align 8
  %r650 = icmp ne i64 %r649, 0
  br i1 %r650, label %pic.desc.prefix.token.131, label %pic.miss.cold.134

pic.desc.prefix.token.131:                        ; preds = %pic.desc.prefix.meta.130
  %r651 = inttoptr i64 %r649 to ptr
  %r652 = getelementptr i64, ptr %r651, i64 6
  %r653 = load i64, ptr %r652, align 8
  %r654 = icmp eq i64 %r653, %r645
  br i1 %r654, label %pic.desc.prefix.hit.132, label %pic.miss.cold.134

pic.desc.prefix.hit.132:                          ; preds = %pic.desc.prefix.token.131
  %r655 = getelementptr i64, ptr %r595, i64 1
  %r656 = load i64, ptr %r655, align 8
  %r657 = shl i64 %r656, 3
  %r658 = add nuw nsw i64 %r575, 16
  %r659 = add i64 %r658, %r657
  %r660 = inttoptr i64 %r659 to ptr
  %r661 = load double, ptr %r660, align 8
  br label %pic.merge.136

pic.miss.133:                                     ; preds = %pic.hit.inline.140, %pic.prefix.token.126, %pic.prefix.meta.125, %pic.prefix.guard.124
  %r662 = getelementptr i64, ptr %r595, i64 3
  %r663 = load i64, ptr %r662, align 8
  %r664 = icmp sgt i64 %r663, 0
  br i1 %r664, label %pic.ways.141, label %pic.miss.call.135

pic.miss.cold.134:                                ; preds = %pic.desc.prefix.token.131, %pic.desc.prefix.meta.130, %pic.desc.prefix.guard.129, %pic.desc.classify.128, %pget.recv_ok.116
  br label %pic.miss.call.135

pic.miss.call.135:                                ; preds = %pic.way.load.142, %pic.ways.141, %pic.miss.cold.134, %pic.miss.133
  %r703 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r704 = bitcast double %r703 to i64
  %r705 = and i64 %r704, 281474976710655
  %statepoint_token259 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r575, i64 %r705, ptr @perry_ic_test_json_cached_template_borrow_ts__11, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated212, ptr addrspace(1) %rs4gc.s10.relocated213, ptr addrspace(1) %r48.0.base.relocated214, ptr addrspace(1) %r48.0.relocated215, ptr addrspace(1) %rs4gc.s13.relocated216, ptr addrspace(1) %rs4gc.s15.relocated217) ]
  %r706260 = call double @llvm.experimental.gc.result.f64(token %statepoint_token259)
  %r57.0.relocated261 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 0, i32 0) ; (%r57.0.relocated212, %r57.0.relocated212)
  %rs4gc.s10.relocated262 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 1, i32 1) ; (%rs4gc.s10.relocated213, %rs4gc.s10.relocated213)
  %r48.0.base.relocated263 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 2, i32 2) ; (%r48.0.base.relocated214, %r48.0.base.relocated214)
  %r48.0.relocated264 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 2, i32 3) ; (%r48.0.base.relocated214, %r48.0.relocated215)
  %rs4gc.s13.relocated265 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 4, i32 4) ; (%rs4gc.s13.relocated216, %rs4gc.s13.relocated216)
  %rs4gc.s15.relocated266 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token259, i32 5, i32 5) ; (%rs4gc.s15.relocated217, %rs4gc.s15.relocated217)
  br label %pic.merge.136

pic.merge.136:                                    ; preds = %pic.way.live.143, %pic.hit.overflow.139, %pic.miss.call.135, %pic.desc.prefix.hit.132, %pic.prefix.hit.127, %pic.hit.live.123
  %.61077 = phi ptr addrspace(1) [ %rs4gc.s15.relocated274, %pic.hit.overflow.139 ], [ %rs4gc.s15.relocated266, %pic.miss.call.135 ], [ %rs4gc.s15.relocated217, %pic.way.live.143 ], [ %rs4gc.s15.relocated217, %pic.hit.live.123 ], [ %rs4gc.s15.relocated217, %pic.prefix.hit.127 ], [ %rs4gc.s15.relocated217, %pic.desc.prefix.hit.132 ]
  %.61057 = phi ptr addrspace(1) [ %rs4gc.s13.relocated273, %pic.hit.overflow.139 ], [ %rs4gc.s13.relocated265, %pic.miss.call.135 ], [ %rs4gc.s13.relocated216, %pic.way.live.143 ], [ %rs4gc.s13.relocated216, %pic.hit.live.123 ], [ %rs4gc.s13.relocated216, %pic.prefix.hit.127 ], [ %rs4gc.s13.relocated216, %pic.desc.prefix.hit.132 ]
  %.91020 = phi ptr addrspace(1) [ %r48.0.relocated272, %pic.hit.overflow.139 ], [ %r48.0.relocated264, %pic.miss.call.135 ], [ %r48.0.relocated215, %pic.way.live.143 ], [ %r48.0.relocated215, %pic.hit.live.123 ], [ %r48.0.relocated215, %pic.prefix.hit.127 ], [ %r48.0.relocated215, %pic.desc.prefix.hit.132 ]
  %.9980 = phi ptr addrspace(1) [ %r48.0.base.relocated271, %pic.hit.overflow.139 ], [ %r48.0.base.relocated263, %pic.miss.call.135 ], [ %r48.0.base.relocated214, %pic.way.live.143 ], [ %r48.0.base.relocated214, %pic.hit.live.123 ], [ %r48.0.base.relocated214, %pic.prefix.hit.127 ], [ %r48.0.base.relocated214, %pic.desc.prefix.hit.132 ]
  %.9937 = phi ptr addrspace(1) [ %r57.0.relocated269, %pic.hit.overflow.139 ], [ %r57.0.relocated261, %pic.miss.call.135 ], [ %r57.0.relocated212, %pic.way.live.143 ], [ %r57.0.relocated212, %pic.hit.live.123 ], [ %r57.0.relocated212, %pic.prefix.hit.127 ], [ %r57.0.relocated212, %pic.desc.prefix.hit.132 ]
  %.9 = phi ptr addrspace(1) [ %rs4gc.s10.relocated270, %pic.hit.overflow.139 ], [ %rs4gc.s10.relocated262, %pic.miss.call.135 ], [ %rs4gc.s10.relocated213, %pic.way.live.143 ], [ %rs4gc.s10.relocated213, %pic.hit.live.123 ], [ %rs4gc.s10.relocated213, %pic.prefix.hit.127 ], [ %rs4gc.s10.relocated213, %pic.desc.prefix.hit.132 ]
  %r707 = phi double [ %r623, %pic.hit.live.123 ], [ %r618268, %pic.hit.overflow.139 ], [ %r643, %pic.prefix.hit.127 ], [ %r661, %pic.desc.prefix.hit.132 ], [ %r700, %pic.way.live.143 ], [ %r706260, %pic.miss.call.135 ]
  br label %pget.recv_merge.119

pic.recv_hdr.137:                                 ; preds = %pget.recv_ok.116
  %r586 = sub nuw nsw i64 %r575, 8
  %r587 = inttoptr i64 %r586 to ptr
  %r588 = load i8, ptr %r587, align 1
  %r589 = icmp eq i8 %r588, 2
  %r590 = sub nuw nsw i64 %r575, 6
  %r591 = inttoptr i64 %r590 to ptr
  %r592 = load i16, ptr %r591, align 2
  %r593 = and i16 %r592, 2048
  %r594 = icmp eq i16 %r593, 0
  %r595 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__11, align 8
  %r596 = icmp ne ptr %r595, null
  %r597 = and i1 %r589, %r594
  %r598 = and i1 %r597, %r596
  br i1 %r598, label %pic.token.138, label %pic.desc.classify.128

pic.token.138:                                    ; preds = %pic.recv_hdr.137
  %r600 = add nuw nsw i64 %r575, 4
  %r601 = inttoptr i64 %r600 to ptr
  %r602 = load i32, ptr %r601, align 4
  %r603 = zext i32 %r602 to i64
  %r604 = or i64 %r603, 4611686018427387904
  %r605 = icmp ne i32 %r602, 0
  %r606 = getelementptr i64, ptr %r595, i64 0
  %r607 = load i64, ptr %r606, align 8
  %r608 = icmp eq i64 %r604, %r607
  %r609 = and i1 %r608, %r605
  br i1 %r609, label %pic.hit.122, label %pic.prefix.guard.124

pic.hit.overflow.139:                             ; preds = %pic.hit.122
  %r614 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r615 = bitcast double %r614 to i64
  %r616 = and i64 %r615, 281474976710655
  %r617 = trunc i64 %r611 to i32
  %statepoint_token267 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r575, i64 %r616, i32 %r617, ptr @perry_ic_test_json_cached_template_borrow_ts__11, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated212, ptr addrspace(1) %rs4gc.s10.relocated213, ptr addrspace(1) %r48.0.base.relocated214, ptr addrspace(1) %r48.0.relocated215, ptr addrspace(1) %rs4gc.s13.relocated216, ptr addrspace(1) %rs4gc.s15.relocated217) ]
  %r618268 = call double @llvm.experimental.gc.result.f64(token %statepoint_token267)
  %r57.0.relocated269 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 0, i32 0) ; (%r57.0.relocated212, %r57.0.relocated212)
  %rs4gc.s10.relocated270 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 1, i32 1) ; (%rs4gc.s10.relocated213, %rs4gc.s10.relocated213)
  %r48.0.base.relocated271 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 2, i32 2) ; (%r48.0.base.relocated214, %r48.0.base.relocated214)
  %r48.0.relocated272 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 2, i32 3) ; (%r48.0.base.relocated214, %r48.0.relocated215)
  %rs4gc.s13.relocated273 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 4, i32 4) ; (%rs4gc.s13.relocated216, %rs4gc.s13.relocated216)
  %rs4gc.s15.relocated274 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token267, i32 5, i32 5) ; (%rs4gc.s15.relocated217, %rs4gc.s15.relocated217)
  br label %pic.merge.136

pic.hit.inline.140:                               ; preds = %pic.hit.122
  %r619 = shl i64 %r611, 3
  %r620 = add nuw nsw i64 %r575, 16
  %r621 = add i64 %r620, %r619
  %r622 = inttoptr i64 %r621 to ptr
  %r623 = load double, ptr %r622, align 8
  %r624 = bitcast double %r623 to i64
  %r625 = icmp eq i64 %r624, 9222246136947933200
  br i1 %r625, label %pic.miss.133, label %pic.hit.live.123

pic.ways.141:                                     ; preds = %pic.miss.133
  %r665 = getelementptr i64, ptr %r595, i64 4
  %r666 = load i64, ptr %r665, align 8
  %r667 = icmp eq i64 %r666, %r604
  %r668 = getelementptr i64, ptr %r595, i64 5
  %r669 = load i64, ptr %r668, align 8
  %r670 = select i1 %r667, i64 %r669, i64 0
  %r671 = getelementptr i64, ptr %r595, i64 6
  %r672 = load i64, ptr %r671, align 8
  %r673 = icmp eq i64 %r672, %r604
  %r674 = getelementptr i64, ptr %r595, i64 7
  %r675 = load i64, ptr %r674, align 8
  %r676 = select i1 %r673, i64 %r675, i64 0
  %r677 = getelementptr i64, ptr %r595, i64 8
  %r678 = load i64, ptr %r677, align 8
  %r679 = icmp eq i64 %r678, %r604
  %r680 = getelementptr i64, ptr %r595, i64 9
  %r681 = load i64, ptr %r680, align 8
  %r682 = select i1 %r679, i64 %r681, i64 0
  %r683 = getelementptr i64, ptr %r595, i64 10
  %r684 = load i64, ptr %r683, align 8
  %r685 = icmp eq i64 %r684, %r604
  %r686 = getelementptr i64, ptr %r595, i64 11
  %r687 = load i64, ptr %r686, align 8
  %r688 = select i1 %r685, i64 %r687, i64 0
  %r689 = or i1 %r667, %r673
  %r690 = select i1 %r667, i64 %r670, i64 %r676
  %r691 = or i1 %r679, %r685
  %r692 = select i1 %r679, i64 %r682, i64 %r688
  %r693 = or i1 %r689, %r691
  %r694 = select i1 %r689, i64 %r690, i64 %r692
  %r695 = and i1 %r605, %r693
  br i1 %r695, label %pic.way.load.142, label %pic.miss.call.135

pic.way.load.142:                                 ; preds = %pic.ways.141
  %r696 = shl i64 %r694, 3
  %r697 = add nuw nsw i64 %r575, 16
  %r698 = add i64 %r697, %r696
  %r699 = inttoptr i64 %r698 to ptr
  %r700 = load double, ptr %r699, align 8
  %r701 = bitcast double %r700 to i64
  %r702 = icmp eq i64 %r701, 9222246136947933200
  br i1 %r702, label %pic.miss.call.135, label %pic.way.live.143

pic.way.live.143:                                 ; preds = %pic.way.load.142
  br label %pic.merge.136

pget.throw_nullish.144:                           ; preds = %pget.recv_bad.117
  %r711 = zext i1 %r709 to i32
  %statepoint_token275 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r711, ptr @test_json_cached_template_borrow_ts_.str.7.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.145:                       ; preds = %pget.recv_bad.117
  %r712 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r713 = bitcast double %r712 to i64
  %r714 = and i64 %r713, 281474976710655
  %statepoint_token276 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r574, i64 %r714, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated212, ptr addrspace(1) %rs4gc.s10.relocated213, ptr addrspace(1) %r48.0.base.relocated214, ptr addrspace(1) %r48.0.relocated215, ptr addrspace(1) %rs4gc.s13.relocated216, ptr addrspace(1) %rs4gc.s15.relocated217) ]
  %r715277 = call double @llvm.experimental.gc.result.f64(token %statepoint_token276)
  %r57.0.relocated278 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token276, i32 0, i32 0) ; (%r57.0.relocated212, %r57.0.relocated212)
  %rs4gc.s10.relocated279 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token276, i32 1, i32 1) ; (%rs4gc.s10.relocated213, %rs4gc.s10.relocated213)
  %r48.0.base.relocated280 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token276, i32 2, i32 2) ; (%r48.0.base.relocated214, %r48.0.base.relocated214)
  %r48.0.relocated281 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token276, i32 2, i32 3) ; (%r48.0.base.relocated214, %r48.0.relocated215)
  %rs4gc.s13.relocated282 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token276, i32 4, i32 4) ; (%rs4gc.s13.relocated216, %rs4gc.s13.relocated216)
  %rs4gc.s15.relocated283 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token276, i32 5, i32 5) ; (%rs4gc.s15.relocated217, %rs4gc.s15.relocated217)
  br label %pget.recv_merge.119

pget.recv_sso.146:                                ; preds = %pget.recv_other.152
  %r864 = lshr i64 %r721, 40
  %r865 = and i64 %r864, 255
  %r866 = uitofp nneg i64 %r865 to double
  br label %pget.recv_merge.150

pget.recv_ok.147:                                 ; preds = %pget.recv_merge.119
  %r732 = icmp eq i64 %r723, 32767
  br i1 %r732, label %pget.strlen_heap.151, label %pget.recv_obj.154

pget.recv_bad.148:                                ; preds = %pget.check_class_ref.153
  %r856 = icmp eq i64 %r721, 9222246136947933185
  %r857 = icmp eq i64 %r721, 9222246136947933186
  %r858 = or i1 %r856, %r857
  br i1 %r858, label %pget.throw_nullish.177, label %pget.recv_undef_return.178

pget.recv_class_ref.149:                          ; preds = %pget.check_class_ref.153
  %r728 = load double, ptr @test_json_cached_template_borrow_ts_.str.10.handle, align 8
  %r729 = bitcast double %r728 to i64
  %r730 = and i64 %r729, 281474976710655
  %statepoint_token284 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 8988321885632593932, i64 %r721, i64 %r730, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8936, ptr addrspace(1) %.8, ptr addrspace(1) %.8979, ptr addrspace(1) %.81019, ptr addrspace(1) %.51056, ptr addrspace(1) %.51076) ]
  %r731285 = call double @llvm.experimental.gc.result.f64(token %statepoint_token284)
  %r57.0.relocated286 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 0, i32 0) ; (%.8936, %.8936)
  %rs4gc.s10.relocated287 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 1, i32 1) ; (%.8, %.8)
  %r48.0.base.relocated288 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 2, i32 2) ; (%.8979, %.8979)
  %r48.0.relocated289 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 2, i32 3) ; (%.8979, %.81019)
  %rs4gc.s13.relocated290 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 4, i32 4) ; (%.51056, %.51056)
  %rs4gc.s15.relocated291 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 5, i32 5) ; (%.51076, %.51076)
  br label %pget.recv_merge.150

pget.recv_merge.150:                              ; preds = %pget.recv_undef_return.178, %pic.merge.169, %pget.strlen_heap.151, %pget.recv_class_ref.149, %pget.recv_sso.146
  %.71078 = phi ptr addrspace(1) [ %.51076, %pget.strlen_heap.151 ], [ %.81079, %pic.merge.169 ], [ %.51076, %pget.recv_sso.146 ], [ %rs4gc.s15.relocated291, %pget.recv_class_ref.149 ], [ %rs4gc.s15.relocated316, %pget.recv_undef_return.178 ]
  %.71058 = phi ptr addrspace(1) [ %.51056, %pget.strlen_heap.151 ], [ %.81059, %pic.merge.169 ], [ %.51056, %pget.recv_sso.146 ], [ %rs4gc.s13.relocated290, %pget.recv_class_ref.149 ], [ %rs4gc.s13.relocated315, %pget.recv_undef_return.178 ]
  %.101021 = phi ptr addrspace(1) [ %.81019, %pget.strlen_heap.151 ], [ %.111022, %pic.merge.169 ], [ %.81019, %pget.recv_sso.146 ], [ %r48.0.relocated289, %pget.recv_class_ref.149 ], [ %r48.0.relocated314, %pget.recv_undef_return.178 ]
  %.10981 = phi ptr addrspace(1) [ %.8979, %pget.strlen_heap.151 ], [ %.11982, %pic.merge.169 ], [ %.8979, %pget.recv_sso.146 ], [ %r48.0.base.relocated288, %pget.recv_class_ref.149 ], [ %r48.0.base.relocated313, %pget.recv_undef_return.178 ]
  %.10938 = phi ptr addrspace(1) [ %.8936, %pget.strlen_heap.151 ], [ %.11939, %pic.merge.169 ], [ %.8936, %pget.recv_sso.146 ], [ %r57.0.relocated286, %pget.recv_class_ref.149 ], [ %r57.0.relocated311, %pget.recv_undef_return.178 ]
  %.10 = phi ptr addrspace(1) [ %.8, %pget.strlen_heap.151 ], [ %.11, %pic.merge.169 ], [ %.8, %pget.recv_sso.146 ], [ %rs4gc.s10.relocated287, %pget.recv_class_ref.149 ], [ %rs4gc.s10.relocated312, %pget.recv_undef_return.178 ]
  %r872 = phi double [ %r855, %pic.merge.169 ], [ %r863310, %pget.recv_undef_return.178 ], [ %r866, %pget.recv_sso.146 ], [ %r731285, %pget.recv_class_ref.149 ], [ %r871, %pget.strlen_heap.151 ]
  %r873 = bitcast double %r872 to i64
  %r874 = lshr i64 %r873, 48
  %r875 = icmp eq i64 %r874, 32766
  %r876 = trunc i64 %r873 to i32
  %r877 = sitofp i32 %r876 to double
  %r878 = select i1 %r875, double %r877, double %r872
  %r885 = fcmp une double %r878, 3.000000e+00
  %r886 = select i1 %r885, i64 9222246136947933188, i64 9222246136947933187
  %r887 = bitcast i64 %r886 to double
  %r888 = icmp eq i64 %r886, 9222246136947933188
  br i1 %r888, label %logical.merge.180, label %logical.then.179

pget.strlen_heap.151:                             ; preds = %pget.recv_ok.147
  %r867 = icmp ult i64 %r722, 4096
  %r868 = inttoptr i64 %r722 to ptr
  %r869 = select i1 %r867, ptr @perry_null_guard_zero_test_json_cached_template_borrow_ts, ptr %r868
  %r870 = load i32, ptr %r869, align 4
  %r871 = uitofp i32 %r870 to double
  br label %pget.recv_merge.150

pget.recv_other.152:                              ; preds = %pget.recv_merge.119
  %r726 = icmp eq i64 %r723, 32761
  br i1 %r726, label %pget.recv_sso.146, label %pget.check_class_ref.153

pget.check_class_ref.153:                         ; preds = %pget.recv_other.152
  %r727 = icmp eq i64 %r723, 32766
  br i1 %r727, label %pget.recv_class_ref.149, label %pget.recv_bad.148

pget.recv_obj.154:                                ; preds = %pget.recv_ok.147
  %r733 = icmp ugt i64 %r722, 1048575
  br i1 %r733, label %pic.recv_hdr.170, label %pic.miss.cold.167

pic.hit.155:                                      ; preds = %pic.token.171
  %r758 = getelementptr i64, ptr %r743, i64 1
  %r759 = load i64, ptr %r758, align 8
  %r760 = and i64 %r759, 1073741824
  %r761 = icmp ne i64 %r760, 0
  br i1 %r761, label %pic.hit.overflow.172, label %pic.hit.inline.173

pic.hit.live.156:                                 ; preds = %pic.hit.inline.173
  br label %pic.merge.169

pic.prefix.guard.157:                             ; preds = %pic.token.171
  %r774 = getelementptr i64, ptr %r743, i64 2
  %r775 = load i64, ptr %r774, align 8
  %r776 = icmp ne i64 %r775, 0
  br i1 %r776, label %pic.prefix.meta.158, label %pic.miss.166

pic.prefix.meta.158:                              ; preds = %pic.prefix.guard.157
  %r777 = add nuw nsw i64 %r722, 8
  %r778 = inttoptr i64 %r777 to ptr
  %r779 = load i64, ptr %r778, align 8
  %r780 = icmp ne i64 %r779, 0
  br i1 %r780, label %pic.prefix.token.159, label %pic.miss.166

pic.prefix.token.159:                             ; preds = %pic.prefix.meta.158
  %r781 = inttoptr i64 %r779 to ptr
  %r782 = getelementptr i64, ptr %r781, i64 6
  %r783 = load i64, ptr %r782, align 8
  %r784 = icmp eq i64 %r783, %r775
  br i1 %r784, label %pic.prefix.hit.160, label %pic.miss.166

pic.prefix.hit.160:                               ; preds = %pic.prefix.token.159
  %r785 = getelementptr i64, ptr %r743, i64 1
  %r786 = load i64, ptr %r785, align 8
  %r787 = shl i64 %r786, 3
  %r788 = add nuw nsw i64 %r722, 16
  %r789 = add i64 %r788, %r787
  %r790 = inttoptr i64 %r789 to ptr
  %r791 = load double, ptr %r790, align 8
  br label %pic.merge.169

pic.desc.classify.161:                            ; preds = %pic.recv_hdr.170
  %r747 = and i1 %r737, %r744
  br i1 %r747, label %pic.desc.prefix.guard.162, label %pic.miss.cold.167

pic.desc.prefix.guard.162:                        ; preds = %pic.desc.classify.161
  %r792 = getelementptr i64, ptr %r743, i64 2
  %r793 = load i64, ptr %r792, align 8
  %r794 = icmp ne i64 %r793, 0
  br i1 %r794, label %pic.desc.prefix.meta.163, label %pic.miss.cold.167

pic.desc.prefix.meta.163:                         ; preds = %pic.desc.prefix.guard.162
  %r795 = add nuw nsw i64 %r722, 8
  %r796 = inttoptr i64 %r795 to ptr
  %r797 = load i64, ptr %r796, align 8
  %r798 = icmp ne i64 %r797, 0
  br i1 %r798, label %pic.desc.prefix.token.164, label %pic.miss.cold.167

pic.desc.prefix.token.164:                        ; preds = %pic.desc.prefix.meta.163
  %r799 = inttoptr i64 %r797 to ptr
  %r800 = getelementptr i64, ptr %r799, i64 6
  %r801 = load i64, ptr %r800, align 8
  %r802 = icmp eq i64 %r801, %r793
  br i1 %r802, label %pic.desc.prefix.hit.165, label %pic.miss.cold.167

pic.desc.prefix.hit.165:                          ; preds = %pic.desc.prefix.token.164
  %r803 = getelementptr i64, ptr %r743, i64 1
  %r804 = load i64, ptr %r803, align 8
  %r805 = shl i64 %r804, 3
  %r806 = add nuw nsw i64 %r722, 16
  %r807 = add i64 %r806, %r805
  %r808 = inttoptr i64 %r807 to ptr
  %r809 = load double, ptr %r808, align 8
  br label %pic.merge.169

pic.miss.166:                                     ; preds = %pic.hit.inline.173, %pic.prefix.token.159, %pic.prefix.meta.158, %pic.prefix.guard.157
  %r810 = getelementptr i64, ptr %r743, i64 3
  %r811 = load i64, ptr %r810, align 8
  %r812 = icmp sgt i64 %r811, 0
  br i1 %r812, label %pic.ways.174, label %pic.miss.call.168

pic.miss.cold.167:                                ; preds = %pic.desc.prefix.token.164, %pic.desc.prefix.meta.163, %pic.desc.prefix.guard.162, %pic.desc.classify.161, %pget.recv_obj.154
  br label %pic.miss.call.168

pic.miss.call.168:                                ; preds = %pic.way.load.175, %pic.ways.174, %pic.miss.cold.167, %pic.miss.166
  %r851 = load double, ptr @test_json_cached_template_borrow_ts_.str.10.handle, align 8
  %r852 = bitcast double %r851 to i64
  %r853 = and i64 %r852, 281474976710655
  %statepoint_token292 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r722, i64 %r853, ptr @perry_ic_test_json_cached_template_borrow_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8936, ptr addrspace(1) %.8, ptr addrspace(1) %.8979, ptr addrspace(1) %.81019, ptr addrspace(1) %.51056, ptr addrspace(1) %.51076) ]
  %r854293 = call double @llvm.experimental.gc.result.f64(token %statepoint_token292)
  %r57.0.relocated294 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token292, i32 0, i32 0) ; (%.8936, %.8936)
  %rs4gc.s10.relocated295 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token292, i32 1, i32 1) ; (%.8, %.8)
  %r48.0.base.relocated296 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token292, i32 2, i32 2) ; (%.8979, %.8979)
  %r48.0.relocated297 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token292, i32 2, i32 3) ; (%.8979, %.81019)
  %rs4gc.s13.relocated298 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token292, i32 4, i32 4) ; (%.51056, %.51056)
  %rs4gc.s15.relocated299 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token292, i32 5, i32 5) ; (%.51076, %.51076)
  br label %pic.merge.169

pic.merge.169:                                    ; preds = %pic.way.live.176, %pic.hit.overflow.172, %pic.miss.call.168, %pic.desc.prefix.hit.165, %pic.prefix.hit.160, %pic.hit.live.156
  %.81079 = phi ptr addrspace(1) [ %rs4gc.s15.relocated307, %pic.hit.overflow.172 ], [ %rs4gc.s15.relocated299, %pic.miss.call.168 ], [ %.51076, %pic.way.live.176 ], [ %.51076, %pic.hit.live.156 ], [ %.51076, %pic.prefix.hit.160 ], [ %.51076, %pic.desc.prefix.hit.165 ]
  %.81059 = phi ptr addrspace(1) [ %rs4gc.s13.relocated306, %pic.hit.overflow.172 ], [ %rs4gc.s13.relocated298, %pic.miss.call.168 ], [ %.51056, %pic.way.live.176 ], [ %.51056, %pic.hit.live.156 ], [ %.51056, %pic.prefix.hit.160 ], [ %.51056, %pic.desc.prefix.hit.165 ]
  %.111022 = phi ptr addrspace(1) [ %r48.0.relocated305, %pic.hit.overflow.172 ], [ %r48.0.relocated297, %pic.miss.call.168 ], [ %.81019, %pic.way.live.176 ], [ %.81019, %pic.hit.live.156 ], [ %.81019, %pic.prefix.hit.160 ], [ %.81019, %pic.desc.prefix.hit.165 ]
  %.11982 = phi ptr addrspace(1) [ %r48.0.base.relocated304, %pic.hit.overflow.172 ], [ %r48.0.base.relocated296, %pic.miss.call.168 ], [ %.8979, %pic.way.live.176 ], [ %.8979, %pic.hit.live.156 ], [ %.8979, %pic.prefix.hit.160 ], [ %.8979, %pic.desc.prefix.hit.165 ]
  %.11939 = phi ptr addrspace(1) [ %r57.0.relocated302, %pic.hit.overflow.172 ], [ %r57.0.relocated294, %pic.miss.call.168 ], [ %.8936, %pic.way.live.176 ], [ %.8936, %pic.hit.live.156 ], [ %.8936, %pic.prefix.hit.160 ], [ %.8936, %pic.desc.prefix.hit.165 ]
  %.11 = phi ptr addrspace(1) [ %rs4gc.s10.relocated303, %pic.hit.overflow.172 ], [ %rs4gc.s10.relocated295, %pic.miss.call.168 ], [ %.8, %pic.way.live.176 ], [ %.8, %pic.hit.live.156 ], [ %.8, %pic.prefix.hit.160 ], [ %.8, %pic.desc.prefix.hit.165 ]
  %r855 = phi double [ %r771, %pic.hit.live.156 ], [ %r766301, %pic.hit.overflow.172 ], [ %r791, %pic.prefix.hit.160 ], [ %r809, %pic.desc.prefix.hit.165 ], [ %r848, %pic.way.live.176 ], [ %r854293, %pic.miss.call.168 ]
  br label %pget.recv_merge.150

pic.recv_hdr.170:                                 ; preds = %pget.recv_obj.154
  %r734 = sub nuw nsw i64 %r722, 8
  %r735 = inttoptr i64 %r734 to ptr
  %r736 = load i8, ptr %r735, align 1
  %r737 = icmp eq i8 %r736, 2
  %r738 = sub nuw nsw i64 %r722, 6
  %r739 = inttoptr i64 %r738 to ptr
  %r740 = load i16, ptr %r739, align 2
  %r741 = and i16 %r740, 2048
  %r742 = icmp eq i16 %r741, 0
  %r743 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__13, align 8
  %r744 = icmp ne ptr %r743, null
  %r745 = and i1 %r737, %r742
  %r746 = and i1 %r745, %r744
  br i1 %r746, label %pic.token.171, label %pic.desc.classify.161

pic.token.171:                                    ; preds = %pic.recv_hdr.170
  %r748 = add nuw nsw i64 %r722, 4
  %r749 = inttoptr i64 %r748 to ptr
  %r750 = load i32, ptr %r749, align 4
  %r751 = zext i32 %r750 to i64
  %r752 = or i64 %r751, 4611686018427387904
  %r753 = icmp ne i32 %r750, 0
  %r754 = getelementptr i64, ptr %r743, i64 0
  %r755 = load i64, ptr %r754, align 8
  %r756 = icmp eq i64 %r752, %r755
  %r757 = and i1 %r756, %r753
  br i1 %r757, label %pic.hit.155, label %pic.prefix.guard.157

pic.hit.overflow.172:                             ; preds = %pic.hit.155
  %r762 = load double, ptr @test_json_cached_template_borrow_ts_.str.10.handle, align 8
  %r763 = bitcast double %r762 to i64
  %r764 = and i64 %r763, 281474976710655
  %r765 = trunc i64 %r759 to i32
  %statepoint_token300 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r722, i64 %r764, i32 %r765, ptr @perry_ic_test_json_cached_template_borrow_ts__13, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8936, ptr addrspace(1) %.8, ptr addrspace(1) %.8979, ptr addrspace(1) %.81019, ptr addrspace(1) %.51056, ptr addrspace(1) %.51076) ]
  %r766301 = call double @llvm.experimental.gc.result.f64(token %statepoint_token300)
  %r57.0.relocated302 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token300, i32 0, i32 0) ; (%.8936, %.8936)
  %rs4gc.s10.relocated303 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token300, i32 1, i32 1) ; (%.8, %.8)
  %r48.0.base.relocated304 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token300, i32 2, i32 2) ; (%.8979, %.8979)
  %r48.0.relocated305 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token300, i32 2, i32 3) ; (%.8979, %.81019)
  %rs4gc.s13.relocated306 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token300, i32 4, i32 4) ; (%.51056, %.51056)
  %rs4gc.s15.relocated307 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token300, i32 5, i32 5) ; (%.51076, %.51076)
  br label %pic.merge.169

pic.hit.inline.173:                               ; preds = %pic.hit.155
  %r767 = shl i64 %r759, 3
  %r768 = add nuw nsw i64 %r722, 16
  %r769 = add i64 %r768, %r767
  %r770 = inttoptr i64 %r769 to ptr
  %r771 = load double, ptr %r770, align 8
  %r772 = bitcast double %r771 to i64
  %r773 = icmp eq i64 %r772, 9222246136947933200
  br i1 %r773, label %pic.miss.166, label %pic.hit.live.156

pic.ways.174:                                     ; preds = %pic.miss.166
  %r813 = getelementptr i64, ptr %r743, i64 4
  %r814 = load i64, ptr %r813, align 8
  %r815 = icmp eq i64 %r814, %r752
  %r816 = getelementptr i64, ptr %r743, i64 5
  %r817 = load i64, ptr %r816, align 8
  %r818 = select i1 %r815, i64 %r817, i64 0
  %r819 = getelementptr i64, ptr %r743, i64 6
  %r820 = load i64, ptr %r819, align 8
  %r821 = icmp eq i64 %r820, %r752
  %r822 = getelementptr i64, ptr %r743, i64 7
  %r823 = load i64, ptr %r822, align 8
  %r824 = select i1 %r821, i64 %r823, i64 0
  %r825 = getelementptr i64, ptr %r743, i64 8
  %r826 = load i64, ptr %r825, align 8
  %r827 = icmp eq i64 %r826, %r752
  %r828 = getelementptr i64, ptr %r743, i64 9
  %r829 = load i64, ptr %r828, align 8
  %r830 = select i1 %r827, i64 %r829, i64 0
  %r831 = getelementptr i64, ptr %r743, i64 10
  %r832 = load i64, ptr %r831, align 8
  %r833 = icmp eq i64 %r832, %r752
  %r834 = getelementptr i64, ptr %r743, i64 11
  %r835 = load i64, ptr %r834, align 8
  %r836 = select i1 %r833, i64 %r835, i64 0
  %r837 = or i1 %r815, %r821
  %r838 = select i1 %r815, i64 %r818, i64 %r824
  %r839 = or i1 %r827, %r833
  %r840 = select i1 %r827, i64 %r830, i64 %r836
  %r841 = or i1 %r837, %r839
  %r842 = select i1 %r837, i64 %r838, i64 %r840
  %r843 = and i1 %r753, %r841
  br i1 %r843, label %pic.way.load.175, label %pic.miss.call.168

pic.way.load.175:                                 ; preds = %pic.ways.174
  %r844 = shl i64 %r842, 3
  %r845 = add nuw nsw i64 %r722, 16
  %r846 = add i64 %r845, %r844
  %r847 = inttoptr i64 %r846 to ptr
  %r848 = load double, ptr %r847, align 8
  %r849 = bitcast double %r848 to i64
  %r850 = icmp eq i64 %r849, 9222246136947933200
  br i1 %r850, label %pic.miss.call.168, label %pic.way.live.176

pic.way.live.176:                                 ; preds = %pic.way.load.175
  br label %pic.merge.169

pget.throw_nullish.177:                           ; preds = %pget.recv_bad.148
  %r859 = zext i1 %r857 to i32
  %statepoint_token308 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r859, ptr @test_json_cached_template_borrow_ts_.str.10.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.178:                       ; preds = %pget.recv_bad.148
  %r860 = load double, ptr @test_json_cached_template_borrow_ts_.str.10.handle, align 8
  %r861 = bitcast double %r860 to i64
  %r862 = and i64 %r861, 281474976710655
  %statepoint_token309 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r721, i64 %r862, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8936, ptr addrspace(1) %.8, ptr addrspace(1) %.8979, ptr addrspace(1) %.81019, ptr addrspace(1) %.51056, ptr addrspace(1) %.51076) ]
  %r863310 = call double @llvm.experimental.gc.result.f64(token %statepoint_token309)
  %r57.0.relocated311 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token309, i32 0, i32 0) ; (%.8936, %.8936)
  %rs4gc.s10.relocated312 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token309, i32 1, i32 1) ; (%.8, %.8)
  %r48.0.base.relocated313 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token309, i32 2, i32 2) ; (%.8979, %.8979)
  %r48.0.relocated314 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token309, i32 2, i32 3) ; (%.8979, %.81019)
  %rs4gc.s13.relocated315 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token309, i32 4, i32 4) ; (%.51056, %.51056)
  %rs4gc.s15.relocated316 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token309, i32 5, i32 5) ; (%.51076, %.51076)
  br label %pget.recv_merge.150

logical.then.179:                                 ; preds = %pget.recv_merge.150
  %r889.rs4i = ptrtoint ptr addrspace(1) %.71078 to i64
  %r889.rs4o = call i64 asm "", "=r,0"(i64 %r889.rs4i) #7
  %r889 = bitcast i64 %r889.rs4o to double
  %r890 = bitcast double %r889 to i64
  %r891 = and i64 %r890, 281474976710655
  %r892 = lshr i64 %r890, 48
  %r893 = and i64 %r892, 65533
  %r894 = icmp eq i64 %r893, 32765
  br i1 %r894, label %pget.recv_ok.182, label %pget.recv_other.186

logical.merge.180:                                ; preds = %streqlit.merge.266, %pget.recv_merge.150
  %.91080 = phi ptr addrspace(1) [ %.71078, %pget.recv_merge.150 ], [ %.101081, %streqlit.merge.266 ]
  %.91060 = phi ptr addrspace(1) [ %.71058, %pget.recv_merge.150 ], [ %.101061, %streqlit.merge.266 ]
  %.121023 = phi ptr addrspace(1) [ %.101021, %pget.recv_merge.150 ], [ %.131024, %streqlit.merge.266 ]
  %.12983 = phi ptr addrspace(1) [ %.10981, %pget.recv_merge.150 ], [ %.13984, %streqlit.merge.266 ]
  %.12940 = phi ptr addrspace(1) [ %.10938, %pget.recv_merge.150 ], [ %.13941, %streqlit.merge.266 ]
  %.12 = phi ptr addrspace(1) [ %.10, %pget.recv_merge.150 ], [ %.13, %streqlit.merge.266 ]
  %r1330 = phi double [ %r887, %pget.recv_merge.150 ], [ %r1328, %streqlit.merge.266 ]
  %r1331 = phi i1 [ true, %pget.recv_merge.150 ], [ %r1329, %streqlit.merge.266 ]
  br i1 %r1331, label %if.then.267, label %if.else.268

pget.recv_sso.181:                                ; preds = %pget.recv_other.186
  %r1032 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r1033 = bitcast double %r1032 to i64
  %r1034 = and i64 %r1033, 281474976710655
  %statepoint_token317 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r890, i64 %r1034, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10938, ptr addrspace(1) %.10, ptr addrspace(1) %.10981, ptr addrspace(1) %.101021, ptr addrspace(1) %.71058, ptr addrspace(1) %.71078) ]
  %r1035318 = call double @llvm.experimental.gc.result.f64(token %statepoint_token317)
  %r57.0.relocated319 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 0, i32 0) ; (%.10938, %.10938)
  %rs4gc.s10.relocated320 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 1, i32 1) ; (%.10, %.10)
  %r48.0.base.relocated321 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 2, i32 2) ; (%.10981, %.10981)
  %r48.0.relocated322 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 2, i32 3) ; (%.10981, %.101021)
  %rs4gc.s13.relocated323 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 4, i32 4) ; (%.71058, %.71058)
  %rs4gc.s15.relocated324 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token317, i32 5, i32 5) ; (%.71078, %.71078)
  br label %pget.recv_merge.185

pget.recv_ok.182:                                 ; preds = %logical.then.179
  %r901 = icmp ugt i64 %r891, 1048575
  br i1 %r901, label %pic.recv_hdr.203, label %pic.miss.cold.200

pget.recv_bad.183:                                ; preds = %pget.check_class_ref.187
  %r1024 = icmp eq i64 %r890, 9222246136947933185
  %r1025 = icmp eq i64 %r890, 9222246136947933186
  %r1026 = or i1 %r1024, %r1025
  br i1 %r1026, label %pget.throw_nullish.210, label %pget.recv_undef_return.211

pget.recv_class_ref.184:                          ; preds = %pget.check_class_ref.187
  %r897 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r898 = bitcast double %r897 to i64
  %r899 = and i64 %r898, 281474976710655
  %statepoint_token325 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 8988321885632593934, i64 %r890, i64 %r899, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10938, ptr addrspace(1) %.10, ptr addrspace(1) %.10981, ptr addrspace(1) %.101021, ptr addrspace(1) %.71058, ptr addrspace(1) %.71078) ]
  %r900326 = call double @llvm.experimental.gc.result.f64(token %statepoint_token325)
  %r57.0.relocated327 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token325, i32 0, i32 0) ; (%.10938, %.10938)
  %rs4gc.s10.relocated328 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token325, i32 1, i32 1) ; (%.10, %.10)
  %r48.0.base.relocated329 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token325, i32 2, i32 2) ; (%.10981, %.10981)
  %r48.0.relocated330 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token325, i32 2, i32 3) ; (%.10981, %.101021)
  %rs4gc.s13.relocated331 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token325, i32 4, i32 4) ; (%.71058, %.71058)
  %rs4gc.s15.relocated332 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token325, i32 5, i32 5) ; (%.71078, %.71078)
  br label %pget.recv_merge.185

pget.recv_merge.185:                              ; preds = %pget.recv_undef_return.211, %pic.merge.202, %pget.recv_class_ref.184, %pget.recv_sso.181
  %.111082 = phi ptr addrspace(1) [ %.121083, %pic.merge.202 ], [ %rs4gc.s15.relocated324, %pget.recv_sso.181 ], [ %rs4gc.s15.relocated332, %pget.recv_class_ref.184 ], [ %rs4gc.s15.relocated357, %pget.recv_undef_return.211 ]
  %.111062 = phi ptr addrspace(1) [ %.121063, %pic.merge.202 ], [ %rs4gc.s13.relocated323, %pget.recv_sso.181 ], [ %rs4gc.s13.relocated331, %pget.recv_class_ref.184 ], [ %rs4gc.s13.relocated356, %pget.recv_undef_return.211 ]
  %.141025 = phi ptr addrspace(1) [ %.151026, %pic.merge.202 ], [ %r48.0.relocated322, %pget.recv_sso.181 ], [ %r48.0.relocated330, %pget.recv_class_ref.184 ], [ %r48.0.relocated355, %pget.recv_undef_return.211 ]
  %.14985 = phi ptr addrspace(1) [ %.15986, %pic.merge.202 ], [ %r48.0.base.relocated321, %pget.recv_sso.181 ], [ %r48.0.base.relocated329, %pget.recv_class_ref.184 ], [ %r48.0.base.relocated354, %pget.recv_undef_return.211 ]
  %.14942 = phi ptr addrspace(1) [ %.15943, %pic.merge.202 ], [ %r57.0.relocated319, %pget.recv_sso.181 ], [ %r57.0.relocated327, %pget.recv_class_ref.184 ], [ %r57.0.relocated352, %pget.recv_undef_return.211 ]
  %.14 = phi ptr addrspace(1) [ %.15, %pic.merge.202 ], [ %rs4gc.s10.relocated320, %pget.recv_sso.181 ], [ %rs4gc.s10.relocated328, %pget.recv_class_ref.184 ], [ %rs4gc.s10.relocated353, %pget.recv_undef_return.211 ]
  %r1036 = phi double [ %r1023, %pic.merge.202 ], [ %r1031351, %pget.recv_undef_return.211 ], [ %r1035318, %pget.recv_sso.181 ], [ %r900326, %pget.recv_class_ref.184 ]
  %r1037 = bitcast double %r1036 to i64
  %r1038 = and i64 %r1037, 281474976710655
  %r1039 = and i64 %r1037, -281474976710656
  %r1040 = icmp eq i64 %r1039, 9222527611924643840
  %r1041 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r1042 = icmp eq i64 %r1041, 0
  %r1043 = icmp ugt i64 %r1038, 1048575
  %r1044 = icmp ult i64 %r1038, 140737488355328
  %r1045 = and i1 %r1043, %r1044
  %r1046 = and i1 %r1040, %r1042
  %r1047 = and i1 %r1046, %r1045
  br i1 %r1047, label %tav.get.brand.216, label %tav.get.slow.214

pget.recv_other.186:                              ; preds = %logical.then.179
  %r895 = icmp eq i64 %r892, 32761
  br i1 %r895, label %pget.recv_sso.181, label %pget.check_class_ref.187

pget.check_class_ref.187:                         ; preds = %pget.recv_other.186
  %r896 = icmp eq i64 %r892, 32766
  br i1 %r896, label %pget.recv_class_ref.184, label %pget.recv_bad.183

pic.hit.188:                                      ; preds = %pic.token.204
  %r926 = getelementptr i64, ptr %r911, i64 1
  %r927 = load i64, ptr %r926, align 8
  %r928 = and i64 %r927, 1073741824
  %r929 = icmp ne i64 %r928, 0
  br i1 %r929, label %pic.hit.overflow.205, label %pic.hit.inline.206

pic.hit.live.189:                                 ; preds = %pic.hit.inline.206
  br label %pic.merge.202

pic.prefix.guard.190:                             ; preds = %pic.token.204
  %r942 = getelementptr i64, ptr %r911, i64 2
  %r943 = load i64, ptr %r942, align 8
  %r944 = icmp ne i64 %r943, 0
  br i1 %r944, label %pic.prefix.meta.191, label %pic.miss.199

pic.prefix.meta.191:                              ; preds = %pic.prefix.guard.190
  %r945 = add nuw nsw i64 %r891, 8
  %r946 = inttoptr i64 %r945 to ptr
  %r947 = load i64, ptr %r946, align 8
  %r948 = icmp ne i64 %r947, 0
  br i1 %r948, label %pic.prefix.token.192, label %pic.miss.199

pic.prefix.token.192:                             ; preds = %pic.prefix.meta.191
  %r949 = inttoptr i64 %r947 to ptr
  %r950 = getelementptr i64, ptr %r949, i64 6
  %r951 = load i64, ptr %r950, align 8
  %r952 = icmp eq i64 %r951, %r943
  br i1 %r952, label %pic.prefix.hit.193, label %pic.miss.199

pic.prefix.hit.193:                               ; preds = %pic.prefix.token.192
  %r953 = getelementptr i64, ptr %r911, i64 1
  %r954 = load i64, ptr %r953, align 8
  %r955 = shl i64 %r954, 3
  %r956 = add nuw nsw i64 %r891, 16
  %r957 = add i64 %r956, %r955
  %r958 = inttoptr i64 %r957 to ptr
  %r959 = load double, ptr %r958, align 8
  br label %pic.merge.202

pic.desc.classify.194:                            ; preds = %pic.recv_hdr.203
  %r915 = and i1 %r905, %r912
  br i1 %r915, label %pic.desc.prefix.guard.195, label %pic.miss.cold.200

pic.desc.prefix.guard.195:                        ; preds = %pic.desc.classify.194
  %r960 = getelementptr i64, ptr %r911, i64 2
  %r961 = load i64, ptr %r960, align 8
  %r962 = icmp ne i64 %r961, 0
  br i1 %r962, label %pic.desc.prefix.meta.196, label %pic.miss.cold.200

pic.desc.prefix.meta.196:                         ; preds = %pic.desc.prefix.guard.195
  %r963 = add nuw nsw i64 %r891, 8
  %r964 = inttoptr i64 %r963 to ptr
  %r965 = load i64, ptr %r964, align 8
  %r966 = icmp ne i64 %r965, 0
  br i1 %r966, label %pic.desc.prefix.token.197, label %pic.miss.cold.200

pic.desc.prefix.token.197:                        ; preds = %pic.desc.prefix.meta.196
  %r967 = inttoptr i64 %r965 to ptr
  %r968 = getelementptr i64, ptr %r967, i64 6
  %r969 = load i64, ptr %r968, align 8
  %r970 = icmp eq i64 %r969, %r961
  br i1 %r970, label %pic.desc.prefix.hit.198, label %pic.miss.cold.200

pic.desc.prefix.hit.198:                          ; preds = %pic.desc.prefix.token.197
  %r971 = getelementptr i64, ptr %r911, i64 1
  %r972 = load i64, ptr %r971, align 8
  %r973 = shl i64 %r972, 3
  %r974 = add nuw nsw i64 %r891, 16
  %r975 = add i64 %r974, %r973
  %r976 = inttoptr i64 %r975 to ptr
  %r977 = load double, ptr %r976, align 8
  br label %pic.merge.202

pic.miss.199:                                     ; preds = %pic.hit.inline.206, %pic.prefix.token.192, %pic.prefix.meta.191, %pic.prefix.guard.190
  %r978 = getelementptr i64, ptr %r911, i64 3
  %r979 = load i64, ptr %r978, align 8
  %r980 = icmp sgt i64 %r979, 0
  br i1 %r980, label %pic.ways.207, label %pic.miss.call.201

pic.miss.cold.200:                                ; preds = %pic.desc.prefix.token.197, %pic.desc.prefix.meta.196, %pic.desc.prefix.guard.195, %pic.desc.classify.194, %pget.recv_ok.182
  br label %pic.miss.call.201

pic.miss.call.201:                                ; preds = %pic.way.load.208, %pic.ways.207, %pic.miss.cold.200, %pic.miss.199
  %r1019 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r1020 = bitcast double %r1019 to i64
  %r1021 = and i64 %r1020, 281474976710655
  %statepoint_token333 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r891, i64 %r1021, ptr @perry_ic_test_json_cached_template_borrow_ts__15, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10938, ptr addrspace(1) %.10, ptr addrspace(1) %.10981, ptr addrspace(1) %.101021, ptr addrspace(1) %.71058, ptr addrspace(1) %.71078) ]
  %r1022334 = call double @llvm.experimental.gc.result.f64(token %statepoint_token333)
  %r57.0.relocated335 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 0, i32 0) ; (%.10938, %.10938)
  %rs4gc.s10.relocated336 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 1, i32 1) ; (%.10, %.10)
  %r48.0.base.relocated337 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 2, i32 2) ; (%.10981, %.10981)
  %r48.0.relocated338 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 2, i32 3) ; (%.10981, %.101021)
  %rs4gc.s13.relocated339 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 4, i32 4) ; (%.71058, %.71058)
  %rs4gc.s15.relocated340 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token333, i32 5, i32 5) ; (%.71078, %.71078)
  br label %pic.merge.202

pic.merge.202:                                    ; preds = %pic.way.live.209, %pic.hit.overflow.205, %pic.miss.call.201, %pic.desc.prefix.hit.198, %pic.prefix.hit.193, %pic.hit.live.189
  %.121083 = phi ptr addrspace(1) [ %rs4gc.s15.relocated348, %pic.hit.overflow.205 ], [ %rs4gc.s15.relocated340, %pic.miss.call.201 ], [ %.71078, %pic.way.live.209 ], [ %.71078, %pic.hit.live.189 ], [ %.71078, %pic.prefix.hit.193 ], [ %.71078, %pic.desc.prefix.hit.198 ]
  %.121063 = phi ptr addrspace(1) [ %rs4gc.s13.relocated347, %pic.hit.overflow.205 ], [ %rs4gc.s13.relocated339, %pic.miss.call.201 ], [ %.71058, %pic.way.live.209 ], [ %.71058, %pic.hit.live.189 ], [ %.71058, %pic.prefix.hit.193 ], [ %.71058, %pic.desc.prefix.hit.198 ]
  %.151026 = phi ptr addrspace(1) [ %r48.0.relocated346, %pic.hit.overflow.205 ], [ %r48.0.relocated338, %pic.miss.call.201 ], [ %.101021, %pic.way.live.209 ], [ %.101021, %pic.hit.live.189 ], [ %.101021, %pic.prefix.hit.193 ], [ %.101021, %pic.desc.prefix.hit.198 ]
  %.15986 = phi ptr addrspace(1) [ %r48.0.base.relocated345, %pic.hit.overflow.205 ], [ %r48.0.base.relocated337, %pic.miss.call.201 ], [ %.10981, %pic.way.live.209 ], [ %.10981, %pic.hit.live.189 ], [ %.10981, %pic.prefix.hit.193 ], [ %.10981, %pic.desc.prefix.hit.198 ]
  %.15943 = phi ptr addrspace(1) [ %r57.0.relocated343, %pic.hit.overflow.205 ], [ %r57.0.relocated335, %pic.miss.call.201 ], [ %.10938, %pic.way.live.209 ], [ %.10938, %pic.hit.live.189 ], [ %.10938, %pic.prefix.hit.193 ], [ %.10938, %pic.desc.prefix.hit.198 ]
  %.15 = phi ptr addrspace(1) [ %rs4gc.s10.relocated344, %pic.hit.overflow.205 ], [ %rs4gc.s10.relocated336, %pic.miss.call.201 ], [ %.10, %pic.way.live.209 ], [ %.10, %pic.hit.live.189 ], [ %.10, %pic.prefix.hit.193 ], [ %.10, %pic.desc.prefix.hit.198 ]
  %r1023 = phi double [ %r939, %pic.hit.live.189 ], [ %r934342, %pic.hit.overflow.205 ], [ %r959, %pic.prefix.hit.193 ], [ %r977, %pic.desc.prefix.hit.198 ], [ %r1016, %pic.way.live.209 ], [ %r1022334, %pic.miss.call.201 ]
  br label %pget.recv_merge.185

pic.recv_hdr.203:                                 ; preds = %pget.recv_ok.182
  %r902 = sub nuw nsw i64 %r891, 8
  %r903 = inttoptr i64 %r902 to ptr
  %r904 = load i8, ptr %r903, align 1
  %r905 = icmp eq i8 %r904, 2
  %r906 = sub nuw nsw i64 %r891, 6
  %r907 = inttoptr i64 %r906 to ptr
  %r908 = load i16, ptr %r907, align 2
  %r909 = and i16 %r908, 2048
  %r910 = icmp eq i16 %r909, 0
  %r911 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__15, align 8
  %r912 = icmp ne ptr %r911, null
  %r913 = and i1 %r905, %r910
  %r914 = and i1 %r913, %r912
  br i1 %r914, label %pic.token.204, label %pic.desc.classify.194

pic.token.204:                                    ; preds = %pic.recv_hdr.203
  %r916 = add nuw nsw i64 %r891, 4
  %r917 = inttoptr i64 %r916 to ptr
  %r918 = load i32, ptr %r917, align 4
  %r919 = zext i32 %r918 to i64
  %r920 = or i64 %r919, 4611686018427387904
  %r921 = icmp ne i32 %r918, 0
  %r922 = getelementptr i64, ptr %r911, i64 0
  %r923 = load i64, ptr %r922, align 8
  %r924 = icmp eq i64 %r920, %r923
  %r925 = and i1 %r924, %r921
  br i1 %r925, label %pic.hit.188, label %pic.prefix.guard.190

pic.hit.overflow.205:                             ; preds = %pic.hit.188
  %r930 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r931 = bitcast double %r930 to i64
  %r932 = and i64 %r931, 281474976710655
  %r933 = trunc i64 %r927 to i32
  %statepoint_token341 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r891, i64 %r932, i32 %r933, ptr @perry_ic_test_json_cached_template_borrow_ts__15, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10938, ptr addrspace(1) %.10, ptr addrspace(1) %.10981, ptr addrspace(1) %.101021, ptr addrspace(1) %.71058, ptr addrspace(1) %.71078) ]
  %r934342 = call double @llvm.experimental.gc.result.f64(token %statepoint_token341)
  %r57.0.relocated343 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token341, i32 0, i32 0) ; (%.10938, %.10938)
  %rs4gc.s10.relocated344 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token341, i32 1, i32 1) ; (%.10, %.10)
  %r48.0.base.relocated345 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token341, i32 2, i32 2) ; (%.10981, %.10981)
  %r48.0.relocated346 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token341, i32 2, i32 3) ; (%.10981, %.101021)
  %rs4gc.s13.relocated347 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token341, i32 4, i32 4) ; (%.71058, %.71058)
  %rs4gc.s15.relocated348 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token341, i32 5, i32 5) ; (%.71078, %.71078)
  br label %pic.merge.202

pic.hit.inline.206:                               ; preds = %pic.hit.188
  %r935 = shl i64 %r927, 3
  %r936 = add nuw nsw i64 %r891, 16
  %r937 = add i64 %r936, %r935
  %r938 = inttoptr i64 %r937 to ptr
  %r939 = load double, ptr %r938, align 8
  %r940 = bitcast double %r939 to i64
  %r941 = icmp eq i64 %r940, 9222246136947933200
  br i1 %r941, label %pic.miss.199, label %pic.hit.live.189

pic.ways.207:                                     ; preds = %pic.miss.199
  %r981 = getelementptr i64, ptr %r911, i64 4
  %r982 = load i64, ptr %r981, align 8
  %r983 = icmp eq i64 %r982, %r920
  %r984 = getelementptr i64, ptr %r911, i64 5
  %r985 = load i64, ptr %r984, align 8
  %r986 = select i1 %r983, i64 %r985, i64 0
  %r987 = getelementptr i64, ptr %r911, i64 6
  %r988 = load i64, ptr %r987, align 8
  %r989 = icmp eq i64 %r988, %r920
  %r990 = getelementptr i64, ptr %r911, i64 7
  %r991 = load i64, ptr %r990, align 8
  %r992 = select i1 %r989, i64 %r991, i64 0
  %r993 = getelementptr i64, ptr %r911, i64 8
  %r994 = load i64, ptr %r993, align 8
  %r995 = icmp eq i64 %r994, %r920
  %r996 = getelementptr i64, ptr %r911, i64 9
  %r997 = load i64, ptr %r996, align 8
  %r998 = select i1 %r995, i64 %r997, i64 0
  %r999 = getelementptr i64, ptr %r911, i64 10
  %r1000 = load i64, ptr %r999, align 8
  %r1001 = icmp eq i64 %r1000, %r920
  %r1002 = getelementptr i64, ptr %r911, i64 11
  %r1003 = load i64, ptr %r1002, align 8
  %r1004 = select i1 %r1001, i64 %r1003, i64 0
  %r1005 = or i1 %r983, %r989
  %r1006 = select i1 %r983, i64 %r986, i64 %r992
  %r1007 = or i1 %r995, %r1001
  %r1008 = select i1 %r995, i64 %r998, i64 %r1004
  %r1009 = or i1 %r1005, %r1007
  %r1010 = select i1 %r1005, i64 %r1006, i64 %r1008
  %r1011 = and i1 %r921, %r1009
  br i1 %r1011, label %pic.way.load.208, label %pic.miss.call.201

pic.way.load.208:                                 ; preds = %pic.ways.207
  %r1012 = shl i64 %r1010, 3
  %r1013 = add nuw nsw i64 %r891, 16
  %r1014 = add i64 %r1013, %r1012
  %r1015 = inttoptr i64 %r1014 to ptr
  %r1016 = load double, ptr %r1015, align 8
  %r1017 = bitcast double %r1016 to i64
  %r1018 = icmp eq i64 %r1017, 9222246136947933200
  br i1 %r1018, label %pic.miss.call.201, label %pic.way.live.209

pic.way.live.209:                                 ; preds = %pic.way.load.208
  br label %pic.merge.202

pget.throw_nullish.210:                           ; preds = %pget.recv_bad.183
  %r1027 = zext i1 %r1025 to i32
  %statepoint_token349 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1027, ptr @test_json_cached_template_borrow_ts_.str.7.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.211:                       ; preds = %pget.recv_bad.183
  %r1028 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r1029 = bitcast double %r1028 to i64
  %r1030 = and i64 %r1029, 281474976710655
  %statepoint_token350 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r890, i64 %r1030, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10938, ptr addrspace(1) %.10, ptr addrspace(1) %.10981, ptr addrspace(1) %.101021, ptr addrspace(1) %.71058, ptr addrspace(1) %.71078) ]
  %r1031351 = call double @llvm.experimental.gc.result.f64(token %statepoint_token350)
  %r57.0.relocated352 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 0, i32 0) ; (%.10938, %.10938)
  %rs4gc.s10.relocated353 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 1, i32 1) ; (%.10, %.10)
  %r48.0.base.relocated354 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 2, i32 2) ; (%.10981, %.10981)
  %r48.0.relocated355 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 2, i32 3) ; (%.10981, %.101021)
  %rs4gc.s13.relocated356 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 4, i32 4) ; (%.71058, %.71058)
  %rs4gc.s15.relocated357 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 5, i32 5) ; (%.71078, %.71078)
  br label %pget.recv_merge.185

tav.get.fast.212:                                 ; preds = %tav.get.brand.216
  %r1064 = bitcast double %r1036 to i64
  %r1065 = and i64 %r1064, 281474976710655
  %r1066 = add nuw nsw i64 %r1065, 8
  %r1067 = inttoptr i64 %r1066 to ptr
  %r1068 = load i8, ptr %r1067, align 1
  %r1069 = zext i8 %r1068 to i64
  %r1073 = inttoptr i64 %r1065 to ptr
  %r1074 = load i32, ptr %r1073, align 4
  %r1075 = zext i32 %r1074 to i64
  %r1076 = icmp ult i64 0, %r1075
  %r1077 = and i1 true, %r1076
  br i1 %r1077, label %tav.get.load.213, label %tav.get.slow.214

tav.get.load.213:                                 ; preds = %tav.get.fast.212
  %r1078 = add nuw nsw i64 %r1065, 16
  %r1079 = icmp eq i64 %r1069, 0
  br i1 %r1079, label %tav.k.i8.217, label %tav.kd1.225

tav.get.slow.214:                                 ; preds = %tav.get.brand.216, %tav.get.fast.212, %pget.recv_merge.185
  %r1130 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__16, align 8
  %r1131 = icmp ne ptr %r1130, null
  %r1132 = select i1 %r1131, ptr %r1130, ptr @perry_ic_test_json_cached_template_borrow_ts__16
  %r1133 = bitcast double %r1036 to i64
  %r1134 = and i64 %r1133, 281474976710655
  %r1135 = and i64 %r1133, -281474976710656
  %r1136 = icmp eq i64 %r1135, 9222527611924643840
  %r1137 = icmp uge i64 %r1134, 2199023255552
  %r1138 = icmp ult i64 %r1134, 140737488355328
  %r1141 = and i1 %r1136, %r1137
  %r1142 = and i1 %r1141, %r1138
  br i1 %r1142, label %arrlike.ic.header.232, label %arrlike.ic.miss.251

tav.get.merge.215:                                ; preds = %arrlike.elem.value.257, %arrlike.ic.miss.251, %arrlike.ic.spill_load.250, %arrlike.ic.inline.247, %arrlike.ic.array_load.235, %tav.k.f64.224, %tav.k.f32.223, %tav.k.u32.222, %tav.k.i32.221, %tav.k.u16.220, %tav.k.i16.219, %tav.k.u8.218, %tav.k.i8.217
  %.131084 = phi ptr addrspace(1) [ %.111082, %tav.k.i8.217 ], [ %.111082, %tav.k.u8.218 ], [ %.111082, %tav.k.i16.219 ], [ %.111082, %tav.k.u16.220 ], [ %.111082, %tav.k.i32.221 ], [ %.111082, %tav.k.u32.222 ], [ %.111082, %tav.k.f32.223 ], [ %.111082, %tav.k.f64.224 ], [ %.111082, %arrlike.ic.array_load.235 ], [ %rs4gc.s15.relocated365, %arrlike.ic.miss.251 ], [ %.111082, %arrlike.elem.value.257 ], [ %.111082, %arrlike.ic.inline.247 ], [ %.111082, %arrlike.ic.spill_load.250 ]
  %.131064 = phi ptr addrspace(1) [ %.111062, %tav.k.i8.217 ], [ %.111062, %tav.k.u8.218 ], [ %.111062, %tav.k.i16.219 ], [ %.111062, %tav.k.u16.220 ], [ %.111062, %tav.k.i32.221 ], [ %.111062, %tav.k.u32.222 ], [ %.111062, %tav.k.f32.223 ], [ %.111062, %tav.k.f64.224 ], [ %.111062, %arrlike.ic.array_load.235 ], [ %rs4gc.s13.relocated364, %arrlike.ic.miss.251 ], [ %.111062, %arrlike.elem.value.257 ], [ %.111062, %arrlike.ic.inline.247 ], [ %.111062, %arrlike.ic.spill_load.250 ]
  %.161027 = phi ptr addrspace(1) [ %.141025, %tav.k.i8.217 ], [ %.141025, %tav.k.u8.218 ], [ %.141025, %tav.k.i16.219 ], [ %.141025, %tav.k.u16.220 ], [ %.141025, %tav.k.i32.221 ], [ %.141025, %tav.k.u32.222 ], [ %.141025, %tav.k.f32.223 ], [ %.141025, %tav.k.f64.224 ], [ %.141025, %arrlike.ic.array_load.235 ], [ %r48.0.relocated363, %arrlike.ic.miss.251 ], [ %.141025, %arrlike.elem.value.257 ], [ %.141025, %arrlike.ic.inline.247 ], [ %.141025, %arrlike.ic.spill_load.250 ]
  %.16987 = phi ptr addrspace(1) [ %.14985, %tav.k.i8.217 ], [ %.14985, %tav.k.u8.218 ], [ %.14985, %tav.k.i16.219 ], [ %.14985, %tav.k.u16.220 ], [ %.14985, %tav.k.i32.221 ], [ %.14985, %tav.k.u32.222 ], [ %.14985, %tav.k.f32.223 ], [ %.14985, %tav.k.f64.224 ], [ %.14985, %arrlike.ic.array_load.235 ], [ %r48.0.base.relocated362, %arrlike.ic.miss.251 ], [ %.14985, %arrlike.elem.value.257 ], [ %.14985, %arrlike.ic.inline.247 ], [ %.14985, %arrlike.ic.spill_load.250 ]
  %.16944 = phi ptr addrspace(1) [ %.14942, %tav.k.i8.217 ], [ %.14942, %tav.k.u8.218 ], [ %.14942, %tav.k.i16.219 ], [ %.14942, %tav.k.u16.220 ], [ %.14942, %tav.k.i32.221 ], [ %.14942, %tav.k.u32.222 ], [ %.14942, %tav.k.f32.223 ], [ %.14942, %tav.k.f64.224 ], [ %.14942, %arrlike.ic.array_load.235 ], [ %r57.0.relocated360, %arrlike.ic.miss.251 ], [ %.14942, %arrlike.elem.value.257 ], [ %.14942, %arrlike.ic.inline.247 ], [ %.14942, %arrlike.ic.spill_load.250 ]
  %.16 = phi ptr addrspace(1) [ %.14, %tav.k.i8.217 ], [ %.14, %tav.k.u8.218 ], [ %.14, %tav.k.i16.219 ], [ %.14, %tav.k.u16.220 ], [ %.14, %tav.k.i32.221 ], [ %.14, %tav.k.u32.222 ], [ %.14, %tav.k.f32.223 ], [ %.14, %tav.k.f64.224 ], [ %.14, %arrlike.ic.array_load.235 ], [ %rs4gc.s10.relocated361, %arrlike.ic.miss.251 ], [ %.14, %arrlike.elem.value.257 ], [ %.14, %arrlike.ic.inline.247 ], [ %.14, %arrlike.ic.spill_load.250 ]
  %r1303 = phi double [ %r1092, %tav.k.i8.217 ], [ %r1098, %tav.k.u8.218 ], [ %r1104, %tav.k.i16.219 ], [ %r1110, %tav.k.u16.220 ], [ %r1115, %tav.k.i32.221 ], [ %r1120, %tav.k.u32.222 ], [ %r1125, %tav.k.f32.223 ], [ %r1129, %tav.k.f64.224 ], [ %r1186, %arrlike.elem.value.257 ], [ %r1214, %arrlike.ic.array_load.235 ], [ %r1284, %arrlike.ic.inline.247 ], [ %r1301, %arrlike.ic.spill_load.250 ], [ %r1302359, %arrlike.ic.miss.251 ]
  %r1304 = load double, ptr @test_json_cached_template_borrow_ts_.str.8.handle, align 8
  %r1305 = bitcast double %r1303 to i64
  %r1306 = bitcast double %r1304 to i64
  %r1307 = icmp eq i64 %r1305, %r1306
  br i1 %r1307, label %streqlit.true.264, label %streqlit.tag.259

tav.get.brand.216:                                ; preds = %pget.recv_merge.185
  %r1048 = bitcast double %r1036 to i64
  %r1049 = and i64 %r1048, 281474976710655
  %r1050 = sub nsw i64 %r1049, 8
  %r1051 = inttoptr i64 %r1050 to ptr
  %r1052 = load i8, ptr %r1051, align 1
  %r1053 = icmp eq i8 %r1052, 11
  %r1054 = add nuw nsw i64 %r1049, 8
  %r1055 = inttoptr i64 %r1054 to ptr
  %r1056 = load i8, ptr %r1055, align 1
  %r1057 = zext i8 %r1056 to i64
  %r1058 = icmp ule i64 %r1057, 8
  %r1061 = and i1 %r1053, %r1058
  br i1 %r1061, label %tav.get.fast.212, label %tav.get.slow.214

tav.k.i8.217:                                     ; preds = %tav.get.load.213
  %r1088 = add nuw nsw i64 %r1078, 0
  %r1089 = inttoptr i64 %r1088 to ptr
  %r1090 = load i8, ptr %r1089, align 1
  %r1091 = sext i8 %r1090 to i32
  %r1092 = sitofp i32 %r1091 to double
  br label %tav.get.merge.215

tav.k.u8.218:                                     ; preds = %tav.kd7.231, %tav.kd1.225
  %r1094 = add nuw nsw i64 %r1078, 0
  %r1095 = inttoptr i64 %r1094 to ptr
  %r1096 = load i8, ptr %r1095, align 1
  %r1097 = zext i8 %r1096 to i32
  %r1098 = uitofp nneg i32 %r1097 to double
  br label %tav.get.merge.215

tav.k.i16.219:                                    ; preds = %tav.kd2.226
  %r1100 = add nuw nsw i64 %r1078, 0
  %r1101 = inttoptr i64 %r1100 to ptr
  %r1102 = load i16, ptr %r1101, align 2
  %r1103 = sext i16 %r1102 to i32
  %r1104 = sitofp i32 %r1103 to double
  br label %tav.get.merge.215

tav.k.u16.220:                                    ; preds = %tav.kd3.227
  %r1106 = add nuw nsw i64 %r1078, 0
  %r1107 = inttoptr i64 %r1106 to ptr
  %r1108 = load i16, ptr %r1107, align 2
  %r1109 = zext i16 %r1108 to i32
  %r1110 = uitofp nneg i32 %r1109 to double
  br label %tav.get.merge.215

tav.k.i32.221:                                    ; preds = %tav.kd4.228
  %r1112 = add nuw nsw i64 %r1078, 0
  %r1113 = inttoptr i64 %r1112 to ptr
  %r1114 = load i32, ptr %r1113, align 4
  %r1115 = sitofp i32 %r1114 to double
  br label %tav.get.merge.215

tav.k.u32.222:                                    ; preds = %tav.kd5.229
  %r1117 = add nuw nsw i64 %r1078, 0
  %r1118 = inttoptr i64 %r1117 to ptr
  %r1119 = load i32, ptr %r1118, align 4
  %r1120 = uitofp i32 %r1119 to double
  br label %tav.get.merge.215

tav.k.f32.223:                                    ; preds = %tav.kd6.230
  %r1122 = add nuw nsw i64 %r1078, 0
  %r1123 = inttoptr i64 %r1122 to ptr
  %r1124 = load float, ptr %r1123, align 4
  %r1125 = fpext float %r1124 to double
  br label %tav.get.merge.215

tav.k.f64.224:                                    ; preds = %tav.kd7.231
  %r1127 = add nuw nsw i64 %r1078, 0
  %r1128 = inttoptr i64 %r1127 to ptr
  %r1129 = load double, ptr %r1128, align 8
  br label %tav.get.merge.215

tav.kd1.225:                                      ; preds = %tav.get.load.213
  %r1080 = icmp eq i64 %r1069, 1
  br i1 %r1080, label %tav.k.u8.218, label %tav.kd2.226

tav.kd2.226:                                      ; preds = %tav.kd1.225
  %r1081 = icmp eq i64 %r1069, 2
  br i1 %r1081, label %tav.k.i16.219, label %tav.kd3.227

tav.kd3.227:                                      ; preds = %tav.kd2.226
  %r1082 = icmp eq i64 %r1069, 3
  br i1 %r1082, label %tav.k.u16.220, label %tav.kd4.228

tav.kd4.228:                                      ; preds = %tav.kd3.227
  %r1083 = icmp eq i64 %r1069, 4
  br i1 %r1083, label %tav.k.i32.221, label %tav.kd5.229

tav.kd5.229:                                      ; preds = %tav.kd4.228
  %r1084 = icmp eq i64 %r1069, 5
  br i1 %r1084, label %tav.k.u32.222, label %tav.kd6.230

tav.kd6.230:                                      ; preds = %tav.kd5.229
  %r1085 = icmp eq i64 %r1069, 6
  br i1 %r1085, label %tav.k.f32.223, label %tav.kd7.231

tav.kd7.231:                                      ; preds = %tav.kd6.230
  %r1086 = icmp eq i64 %r1069, 7
  br i1 %r1086, label %tav.k.f64.224, label %tav.k.u8.218

arrlike.ic.header.232:                            ; preds = %tav.get.slow.214
  %r1148 = sub nuw nsw i64 %r1134, 8
  %r1149 = inttoptr i64 %r1148 to ptr
  %r1150 = load i8, ptr %r1149, align 1
  %r1152 = sub nuw nsw i64 %r1134, 7
  %r1153 = inttoptr i64 %r1152 to ptr
  %r1154 = load i8, ptr %r1153, align 1
  %r1155 = and i8 %r1154, -128
  %r1156 = icmp eq i8 %r1155, 0
  %r1157 = and i1 true, %r1156
  br i1 %r1157, label %arrlike.ic.brand.233, label %arrlike.ic.miss.251

arrlike.ic.brand.233:                             ; preds = %arrlike.ic.header.232
  %r1151 = icmp eq i8 %r1150, 1
  br i1 %r1151, label %arrlike.ic.array_guard.234, label %arrlike.elem.kind.252

arrlike.ic.array_guard.234:                       ; preds = %arrlike.ic.brand.233
  %r1189 = sub nuw nsw i64 %r1134, 6
  %r1190 = inttoptr i64 %r1189 to ptr
  %r1191 = load i16, ptr %r1190, align 2
  %r1192 = and i16 %r1191, 1024
  %r1193 = icmp eq i16 %r1192, 0
  %r1194 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1195 = icmp eq i8 %r1194, 0
  %r1196 = inttoptr i64 %r1134 to ptr
  %r1197 = load i32, ptr %r1196, align 4
  %r1198 = add nuw nsw i64 %r1134, 4
  %r1199 = inttoptr i64 %r1198 to ptr
  %r1200 = load i32, ptr %r1199, align 4
  %r1201 = zext i32 %r1197 to i64
  %r1202 = zext i32 %r1200 to i64
  %r1203 = icmp ult i64 0, %r1201
  %r1204 = icmp ule i64 %r1201, %r1202
  %r1205 = and i1 %r1193, %r1195
  %r1206 = and i1 %r1205, %r1203
  %r1207 = and i1 %r1206, %r1204
  br i1 %r1207, label %arrlike.ic.array_load.235, label %arrlike.ic.miss.251

arrlike.ic.array_load.235:                        ; preds = %arrlike.ic.array_guard.234
  %r1209 = getelementptr inbounds nuw i64, ptr %r1196, i64 1
  %r1210 = load double, ptr %r1209, align 8
  %r1211 = bitcast double %r1210 to i64
  %r1212 = icmp eq i64 %r1211, 9222246136947933200
  %r1214 = select i1 %r1212, double 0x7FFC000000000001, double %r1210
  br label %tav.get.merge.215

arrlike.ic.shape.236:                             ; preds = %arrlike.elem.store.254, %arrlike.elem.meta.253
  %r1216 = inttoptr i64 %r1134 to ptr
  %r1217 = load i32, ptr %r1216, align 4
  %r1218 = add nuw nsw i64 %r1134, 4
  %r1219 = inttoptr i64 %r1218 to ptr
  %r1220 = load i32, ptr %r1219, align 4
  %r1221 = zext i32 %r1217 to i64
  %r1222 = zext i32 %r1220 to i64
  %r1223 = shl nuw i64 %r1221, 32
  %r1224 = or i64 %r1223, %r1222
  %r1225 = getelementptr i64, ptr %r1132, i64 0
  %r1226 = load i64, ptr %r1225, align 8
  %r1227 = icmp ne i64 %r1226, 0
  %r1228 = and i1 true, %r1227
  br i1 %r1228, label %arrlike.ic.identity.237, label %arrlike.ic.miss.251

arrlike.ic.identity.237:                          ; preds = %arrlike.ic.shape.236
  %r1229 = and i64 %r1226, -9223372036854775808
  %0 = icmp slt i64 %r1226, 0
  br i1 %0, label %arrlike.ic.family_meta.239, label %arrlike.ic.exact.238

arrlike.ic.exact.238:                             ; preds = %arrlike.ic.identity.237
  %r1231 = icmp eq i64 %r1224, %r1226
  br i1 %r1231, label %arrlike.ic.bounds.241, label %arrlike.ic.miss.251

arrlike.ic.family_meta.239:                       ; preds = %arrlike.ic.identity.237
  %r1232 = add nuw nsw i64 %r1134, 8
  %r1233 = inttoptr i64 %r1232 to ptr
  %r1234 = load i64, ptr %r1233, align 8
  %r1235 = icmp ne i64 %r1234, 0
  br i1 %r1235, label %arrlike.ic.family_token.240, label %arrlike.ic.miss.251

arrlike.ic.family_token.240:                      ; preds = %arrlike.ic.family_meta.239
  %r1236 = inttoptr i64 %r1234 to ptr
  %r1237 = getelementptr i64, ptr %r1236, i64 6
  %r1238 = load i64, ptr %r1237, align 8
  %r1239 = icmp eq i64 %r1238, %r1226
  br i1 %r1239, label %arrlike.ic.bounds.241, label %arrlike.ic.miss.251

arrlike.ic.bounds.241:                            ; preds = %arrlike.ic.family_token.240, %arrlike.ic.exact.238
  %r1240 = getelementptr i64, ptr %r1130, i64 1
  %r1241 = load i64, ptr %r1240, align 8
  %r1242 = getelementptr i64, ptr %r1130, i64 2
  %r1243 = load i64, ptr %r1242, align 8
  %r1244 = getelementptr i64, ptr %r1130, i64 3
  %r1245 = load i64, ptr %r1244, align 8
  %r1246 = getelementptr i64, ptr %r1130, i64 4
  %r1247 = load i64, ptr %r1246, align 8
  %r1248 = icmp ult i64 %r1241, %r1247
  br i1 %r1248, label %arrlike.ic.length_inline.242, label %arrlike.ic.length_spill_meta.243

arrlike.ic.length_inline.242:                     ; preds = %arrlike.ic.bounds.241
  %r1249 = shl i64 %r1241, 3
  %r1250 = add i64 %r1249, 16
  %r1251 = add i64 %r1134, %r1250
  %r1252 = inttoptr i64 %r1251 to ptr
  %r1253 = load double, ptr %r1252, align 8
  br label %arrlike.ic.range.246

arrlike.ic.length_spill_meta.243:                 ; preds = %arrlike.ic.bounds.241
  %r1254 = add nuw nsw i64 %r1134, 8
  %r1255 = inttoptr i64 %r1254 to ptr
  %r1256 = load i64, ptr %r1255, align 8
  %r1257 = icmp ne i64 %r1256, 0
  br i1 %r1257, label %arrlike.ic.length_spill_ptr.244, label %arrlike.ic.miss.251

arrlike.ic.length_spill_ptr.244:                  ; preds = %arrlike.ic.length_spill_meta.243
  %r1258 = inttoptr i64 %r1256 to ptr
  %r1259 = getelementptr i64, ptr %r1258, i64 4
  %r1260 = load i64, ptr %r1259, align 8
  %r1261 = icmp ne i64 %r1260, 0
  %r1262 = select i1 %r1261, i64 %r1260, i64 %r1256
  %r1263 = inttoptr i64 %r1262 to ptr
  %r1264 = load i32, ptr %r1263, align 4
  %r1265 = zext i32 %r1264 to i64
  %r1266 = icmp ult i64 %r1241, %r1265
  %r1267 = and i1 %r1261, %r1266
  br i1 %r1267, label %arrlike.ic.length_spill_load.245, label %arrlike.ic.miss.251

arrlike.ic.length_spill_load.245:                 ; preds = %arrlike.ic.length_spill_ptr.244
  %r1268 = add nuw nsw i64 %r1241, 1
  %r1269 = getelementptr inbounds nuw i64, ptr %r1263, i64 %r1268
  %r1270 = load double, ptr %r1269, align 8
  br label %arrlike.ic.range.246

arrlike.ic.range.246:                             ; preds = %arrlike.ic.length_spill_load.245, %arrlike.ic.length_inline.242
  %r1271 = phi double [ %r1253, %arrlike.ic.length_inline.242 ], [ %r1270, %arrlike.ic.length_spill_load.245 ]
  %r1272 = fcmp olt double 0.000000e+00, %r1271
  %r1273 = icmp ult i64 0, %r1245
  %r1274 = and i1 %r1272, %r1273
  %r1275 = add nuw nsw i64 %r1243, 0
  %r1276 = icmp ult i64 %r1275, %r1247
  %r1277 = and i1 %r1274, %r1276
  %r1278 = xor i1 %r1276, true
  %r1279 = and i1 %r1274, %r1278
  br i1 %r1277, label %arrlike.ic.inline.247, label %arrlike.ic.spill_or_miss.258

arrlike.ic.inline.247:                            ; preds = %arrlike.ic.range.246
  %r1280 = shl i64 %r1275, 3
  %r1281 = add i64 %r1280, 16
  %r1282 = add i64 %r1134, %r1281
  %r1283 = inttoptr i64 %r1282 to ptr
  %r1284 = load double, ptr %r1283, align 8
  br label %tav.get.merge.215

arrlike.ic.spill.248:                             ; preds = %arrlike.ic.spill_or_miss.258
  %r1285 = add nuw nsw i64 %r1134, 8
  %r1286 = inttoptr i64 %r1285 to ptr
  %r1287 = load i64, ptr %r1286, align 8
  %r1288 = icmp ne i64 %r1287, 0
  br i1 %r1288, label %arrlike.ic.spill_ptr.249, label %arrlike.ic.miss.251

arrlike.ic.spill_ptr.249:                         ; preds = %arrlike.ic.spill.248
  %r1289 = inttoptr i64 %r1287 to ptr
  %r1290 = getelementptr i64, ptr %r1289, i64 4
  %r1291 = load i64, ptr %r1290, align 8
  %r1292 = icmp ne i64 %r1291, 0
  %r1293 = select i1 %r1292, i64 %r1291, i64 %r1287
  %r1294 = inttoptr i64 %r1293 to ptr
  %r1295 = load i32, ptr %r1294, align 4
  %r1296 = zext i32 %r1295 to i64
  %r1297 = icmp ult i64 %r1275, %r1296
  %r1298 = and i1 %r1292, %r1297
  br i1 %r1298, label %arrlike.ic.spill_load.250, label %arrlike.ic.miss.251

arrlike.ic.spill_load.250:                        ; preds = %arrlike.ic.spill_ptr.249
  %r1299 = add nuw nsw i64 %r1275, 1
  %r1300 = getelementptr inbounds nuw i64, ptr %r1294, i64 %r1299
  %r1301 = load double, ptr %r1300, align 8
  br label %tav.get.merge.215

arrlike.ic.miss.251:                              ; preds = %arrlike.ic.spill_or_miss.258, %arrlike.elem.load.256, %arrlike.elem.bounds.255, %arrlike.elem.kind.252, %arrlike.ic.spill_ptr.249, %arrlike.ic.spill.248, %arrlike.ic.length_spill_ptr.244, %arrlike.ic.length_spill_meta.243, %arrlike.ic.family_token.240, %arrlike.ic.family_meta.239, %arrlike.ic.exact.238, %arrlike.ic.shape.236, %arrlike.ic.array_guard.234, %arrlike.ic.header.232, %tav.get.slow.214
  %statepoint_token358 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r1036, double 0.000000e+00, ptr @perry_ic_test_json_cached_template_borrow_ts__16, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.14942, ptr addrspace(1) %.14, ptr addrspace(1) %.14985, ptr addrspace(1) %.141025, ptr addrspace(1) %.111062, ptr addrspace(1) %.111082) ]
  %r1302359 = call double @llvm.experimental.gc.result.f64(token %statepoint_token358)
  %r57.0.relocated360 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 0, i32 0) ; (%.14942, %.14942)
  %rs4gc.s10.relocated361 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 1, i32 1) ; (%.14, %.14)
  %r48.0.base.relocated362 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 2, i32 2) ; (%.14985, %.14985)
  %r48.0.relocated363 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 2, i32 3) ; (%.14985, %.141025)
  %rs4gc.s13.relocated364 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 4, i32 4) ; (%.111062, %.111062)
  %rs4gc.s15.relocated365 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token358, i32 5, i32 5) ; (%.111082, %.111082)
  br label %tav.get.merge.215

arrlike.elem.kind.252:                            ; preds = %arrlike.ic.brand.233
  %r1158 = icmp eq i8 %r1150, 2
  br i1 %r1158, label %arrlike.elem.meta.253, label %arrlike.ic.miss.251

arrlike.elem.meta.253:                            ; preds = %arrlike.elem.kind.252
  %r1159 = add nuw nsw i64 %r1134, 8
  %r1160 = inttoptr i64 %r1159 to ptr
  %r1161 = load i64, ptr %r1160, align 8
  %r1162 = icmp ne i64 %r1161, 0
  br i1 %r1162, label %arrlike.elem.store.254, label %arrlike.ic.shape.236

arrlike.elem.store.254:                           ; preds = %arrlike.elem.meta.253
  %r1163 = inttoptr i64 %r1161 to ptr
  %r1164 = getelementptr i64, ptr %r1163, i64 12
  %r1165 = load i64, ptr %r1164, align 8
  %r1166 = icmp ne i64 %r1165, 0
  br i1 %r1166, label %arrlike.elem.bounds.255, label %arrlike.ic.shape.236

arrlike.elem.bounds.255:                          ; preds = %arrlike.elem.store.254
  %r1167 = sub i64 %r1165, 8
  %r1168 = inttoptr i64 %r1167 to ptr
  %r1169 = load i8, ptr %r1168, align 1
  %r1170 = icmp eq i8 %r1169, 1
  %r1171 = sub i64 %r1165, 7
  %r1172 = inttoptr i64 %r1171 to ptr
  %r1173 = load i8, ptr %r1172, align 1
  %r1174 = and i8 %r1173, -128
  %r1175 = icmp eq i8 %r1174, 0
  %r1176 = inttoptr i64 %r1165 to ptr
  %r1177 = load i32, ptr %r1176, align 4
  %r1178 = zext i32 %r1177 to i64
  %r1179 = icmp ult i64 0, %r1178
  %r1180 = and i1 %r1170, %r1175
  %r1181 = and i1 %r1180, %r1179
  br i1 %r1181, label %arrlike.elem.load.256, label %arrlike.ic.miss.251

arrlike.elem.load.256:                            ; preds = %arrlike.elem.bounds.255
  %r1183 = add i64 %r1165, 8
  %r1184 = add nuw nsw i64 %r1183, 0
  %r1185 = inttoptr i64 %r1184 to ptr
  %r1186 = load double, ptr %r1185, align 8
  %r1187 = bitcast double %r1186 to i64
  %r1188 = icmp eq i64 %r1187, 9222246136947933200
  br i1 %r1188, label %arrlike.ic.miss.251, label %arrlike.elem.value.257

arrlike.elem.value.257:                           ; preds = %arrlike.elem.load.256
  br label %tav.get.merge.215

arrlike.ic.spill_or_miss.258:                     ; preds = %arrlike.ic.range.246
  br i1 %r1279, label %arrlike.ic.spill.248, label %arrlike.ic.miss.251

streqlit.tag.259:                                 ; preds = %tav.get.merge.215
  %r1308 = lshr i64 %r1305, 48
  %r1309 = icmp eq i64 %r1308, 32767
  %r1310 = and i64 %r1305, 281474976710655
  %r1311 = icmp ugt i64 %r1310, 4095
  %r1312 = and i1 %r1309, %r1311
  br i1 %r1312, label %streqlit.len.260, label %streqlit.false.265

streqlit.len.260:                                 ; preds = %streqlit.tag.259
  %r1313 = inttoptr i64 %r1310 to ptr
  %r1314 = getelementptr inbounds nuw i8, ptr %r1313, i64 4
  %r1315 = load i32, ptr %r1314, align 4
  %r1316 = icmp eq i32 %r1315, 7
  br i1 %r1316, label %streqlit.b0.261, label %streqlit.false.265

streqlit.b0.261:                                  ; preds = %streqlit.len.260
  %r1317 = getelementptr inbounds nuw i8, ptr %r1313, i64 20
  %r1318 = load i8, ptr %r1317, align 1
  %r1319 = icmp eq i8 %r1318, 99
  br i1 %r1319, label %streqlit.bl.262, label %streqlit.false.265

streqlit.bl.262:                                  ; preds = %streqlit.b0.261
  %r1320 = getelementptr inbounds nuw i8, ptr %r1313, i64 26
  %r1321 = load i8, ptr %r1320, align 1
  %r1322 = icmp eq i8 %r1321, 100
  br i1 %r1322, label %streqlit.slow.263, label %streqlit.false.265

streqlit.slow.263:                                ; preds = %streqlit.bl.262
  %r1323 = and i64 %r1306, 281474976710655
  %statepoint_token366 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1310, i64 %r1323, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.16944, ptr addrspace(1) %.16, ptr addrspace(1) %.16987, ptr addrspace(1) %.161027, ptr addrspace(1) %.131064, ptr addrspace(1) %.131084) ]
  %r1324367 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token366)
  %r57.0.relocated368 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token366, i32 0, i32 0) ; (%.16944, %.16944)
  %rs4gc.s10.relocated369 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token366, i32 1, i32 1) ; (%.16, %.16)
  %r48.0.base.relocated370 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token366, i32 2, i32 2) ; (%.16987, %.16987)
  %r48.0.relocated371 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token366, i32 2, i32 3) ; (%.16987, %.161027)
  %rs4gc.s13.relocated372 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token366, i32 4, i32 4) ; (%.131064, %.131064)
  %rs4gc.s15.relocated373 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token366, i32 5, i32 5) ; (%.131084, %.131084)
  %r1325 = icmp ne i32 %r1324367, 0
  br label %streqlit.merge.266

streqlit.true.264:                                ; preds = %tav.get.merge.215
  br label %streqlit.merge.266

streqlit.false.265:                               ; preds = %streqlit.bl.262, %streqlit.b0.261, %streqlit.len.260, %streqlit.tag.259
  br label %streqlit.merge.266

streqlit.merge.266:                               ; preds = %streqlit.false.265, %streqlit.true.264, %streqlit.slow.263
  %.101081 = phi ptr addrspace(1) [ %.131084, %streqlit.true.264 ], [ %rs4gc.s15.relocated373, %streqlit.slow.263 ], [ %.131084, %streqlit.false.265 ]
  %.101061 = phi ptr addrspace(1) [ %.131064, %streqlit.true.264 ], [ %rs4gc.s13.relocated372, %streqlit.slow.263 ], [ %.131064, %streqlit.false.265 ]
  %.131024 = phi ptr addrspace(1) [ %.161027, %streqlit.true.264 ], [ %r48.0.relocated371, %streqlit.slow.263 ], [ %.161027, %streqlit.false.265 ]
  %.13984 = phi ptr addrspace(1) [ %.16987, %streqlit.true.264 ], [ %r48.0.base.relocated370, %streqlit.slow.263 ], [ %.16987, %streqlit.false.265 ]
  %.13941 = phi ptr addrspace(1) [ %.16944, %streqlit.true.264 ], [ %r57.0.relocated368, %streqlit.slow.263 ], [ %.16944, %streqlit.false.265 ]
  %.13 = phi ptr addrspace(1) [ %.16, %streqlit.true.264 ], [ %rs4gc.s10.relocated369, %streqlit.slow.263 ], [ %.16, %streqlit.false.265 ]
  %r1326 = phi i1 [ true, %streqlit.true.264 ], [ false, %streqlit.false.265 ], [ %r1325, %streqlit.slow.263 ]
  %r1327 = select i1 %r1326, i64 9222246136947933188, i64 9222246136947933187
  %r1328 = bitcast i64 %r1327 to double
  %r1329 = icmp eq i64 %r1327, 9222246136947933188
  br label %logical.merge.180

if.then.267:                                      ; preds = %logical.merge.180
  %r1332 = load double, ptr @test_json_cached_template_borrow_ts_.str.11.handle, align 8
  %statepoint_token374 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r1332, i32 0, i32 0)
  %r1333375 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token374)
  %r1334 = or i64 %r1333375, 9222527611924643840
  %r1335 = bitcast i64 %r1334 to double
  %statepoint_token376 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r1335, i32 0, i32 0)
  unreachable

if.else.268:                                      ; preds = %logical.merge.180
  br label %if.merge.269

if.merge.269:                                     ; preds = %if.else.268
  %r1337.rs4i = ptrtoint ptr addrspace(1) %.91060 to i64
  %r1337.rs4o = call i64 asm "", "=r,0"(i64 %r1337.rs4i) #7
  %r1337 = bitcast i64 %r1337.rs4o to double
  %statepoint_token377 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r1337, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12940, ptr addrspace(1) %.12, ptr addrspace(1) %.12983, ptr addrspace(1) %.121023, ptr addrspace(1) %.91060, ptr addrspace(1) %.91080) ]
  %r1338378 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token377)
  %r57.0.relocated379 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 0, i32 0) ; (%.12940, %.12940)
  %rs4gc.s10.relocated380 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 1, i32 1) ; (%.12, %.12)
  %r48.0.base.relocated381 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 2, i32 2) ; (%.12983, %.12983)
  %r48.0.relocated382 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 2, i32 3) ; (%.12983, %.121023)
  %rs4gc.s13.relocated383 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 4, i32 4) ; (%.91060, %.91060)
  %rs4gc.s15.relocated384 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token377, i32 5, i32 5) ; (%.91080, %.91080)
  %statepoint_token385 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r1338378, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r57.0.relocated379, ptr addrspace(1) %rs4gc.s10.relocated380, ptr addrspace(1) %r48.0.base.relocated381, ptr addrspace(1) %r48.0.relocated382, ptr addrspace(1) %rs4gc.s13.relocated383, ptr addrspace(1) %rs4gc.s15.relocated384) ]
  %r1339386 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token385)
  %r57.0.relocated387 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token385, i32 0, i32 0) ; (%r57.0.relocated379, %r57.0.relocated379)
  %rs4gc.s10.relocated388 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token385, i32 1, i32 1) ; (%rs4gc.s10.relocated380, %rs4gc.s10.relocated380)
  %r48.0.base.relocated389 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token385, i32 2, i32 2) ; (%r48.0.base.relocated381, %r48.0.base.relocated381)
  %r48.0.relocated390 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token385, i32 2, i32 3) ; (%r48.0.base.relocated381, %r48.0.relocated382)
  %rs4gc.s13.relocated391 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token385, i32 4, i32 4) ; (%rs4gc.s13.relocated383, %rs4gc.s13.relocated383)
  %rs4gc.s15.relocated392 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token385, i32 5, i32 5) ; (%rs4gc.s15.relocated384, %rs4gc.s15.relocated384)
  %r1340 = bitcast i64 %r1339386 to double
  %rs4gc.b16 = bitcast double %r1340 to i64
  %rs4gc.s16 = inttoptr i64 %rs4gc.b16 to ptr addrspace(1)
  %r1341.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r1341 = call i64 asm "", "=r,0"(i64 %r1341.rs4i) #7
  %r1342 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1343 = icmp ne i32 %r1342, 0
  br i1 %r1343, label %shadow.root.barrier.270, label %shadow.root.barrier.done.271

shadow.root.barrier.270:                          ; preds = %if.merge.269
  call void @js_write_barrier_root_nanbox(i64 %r1341) #7
  br label %shadow.root.barrier.done.271

shadow.root.barrier.done.271:                     ; preds = %shadow.root.barrier.270, %if.merge.269
  %r1344.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15.relocated392 to i64
  %r1344.rs4o = call i64 asm "", "=r,0"(i64 %r1344.rs4i) #7
  %r1344 = bitcast i64 %r1344.rs4o to double
  %statepoint_token393 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1344, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16, ptr addrspace(1) %r57.0.relocated387, ptr addrspace(1) %rs4gc.s10.relocated388, ptr addrspace(1) %r48.0.base.relocated389, ptr addrspace(1) %r48.0.relocated390, ptr addrspace(1) %rs4gc.s13.relocated391, ptr addrspace(1) %rs4gc.s15.relocated392) ]
  %r1345394 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token393)
  %rs4gc.s16.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token393, i32 0, i32 0) ; (%rs4gc.s16, %rs4gc.s16)
  %r57.0.relocated395 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token393, i32 1, i32 1) ; (%r57.0.relocated387, %r57.0.relocated387)
  %rs4gc.s10.relocated396 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token393, i32 2, i32 2) ; (%rs4gc.s10.relocated388, %rs4gc.s10.relocated388)
  %r48.0.base.relocated397 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token393, i32 3, i32 3) ; (%r48.0.base.relocated389, %r48.0.base.relocated389)
  %r48.0.relocated398 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token393, i32 3, i32 4) ; (%r48.0.base.relocated389, %r48.0.relocated390)
  %rs4gc.s13.relocated399 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token393, i32 5, i32 5) ; (%rs4gc.s13.relocated391, %rs4gc.s13.relocated391)
  %rs4gc.s15.relocated400 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token393, i32 6, i32 6) ; (%rs4gc.s15.relocated392, %rs4gc.s15.relocated392)
  %r1346 = bitcast i64 %r1345394 to double
  %r1347.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated399 to i64
  %r1347.rs4o = call i64 asm "", "=r,0"(i64 %r1347.rs4i) #7
  %r1347 = bitcast i64 %r1347.rs4o to double
  %r1348 = bitcast double %r1347 to i64
  %r1349 = icmp eq i64 %r1345394, %r1348
  br i1 %r1349, label %streq.true.276, label %streq.tag.272

streq.tag.272:                                    ; preds = %shadow.root.barrier.done.271
  %r1350 = lshr i64 %r1345394, 48
  %r1351 = lshr i64 %r1348, 48
  %r1352 = icmp eq i64 %r1350, 32767
  %r1353 = icmp eq i64 %r1351, 32767
  %r1354 = and i1 %r1352, %r1353
  br i1 %r1354, label %streq.heap.273, label %streq.ssochk.274

streq.heap.273:                                   ; preds = %streq.tag.272
  %r1355 = and i64 %r1345394, 281474976710655
  %r1356 = and i64 %r1348, 281474976710655
  %statepoint_token401 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1355, i64 %r1356, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16.relocated, ptr addrspace(1) %r57.0.relocated395, ptr addrspace(1) %rs4gc.s10.relocated396, ptr addrspace(1) %r48.0.base.relocated397, ptr addrspace(1) %r48.0.relocated398, ptr addrspace(1) %rs4gc.s13.relocated399, ptr addrspace(1) %rs4gc.s15.relocated400) ]
  %r1357402 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token401)
  %rs4gc.s16.relocated403 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 0, i32 0) ; (%rs4gc.s16.relocated, %rs4gc.s16.relocated)
  %r57.0.relocated404 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 1, i32 1) ; (%r57.0.relocated395, %r57.0.relocated395)
  %rs4gc.s10.relocated405 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 2, i32 2) ; (%rs4gc.s10.relocated396, %rs4gc.s10.relocated396)
  %r48.0.base.relocated406 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 3, i32 3) ; (%r48.0.base.relocated397, %r48.0.base.relocated397)
  %r48.0.relocated407 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 3, i32 4) ; (%r48.0.base.relocated397, %r48.0.relocated398)
  %rs4gc.s13.relocated408 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 5, i32 5) ; (%rs4gc.s13.relocated399, %rs4gc.s13.relocated399)
  %rs4gc.s15.relocated409 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token401, i32 6, i32 6) ; (%rs4gc.s15.relocated400, %rs4gc.s15.relocated400)
  br label %streq.merge.278

streq.ssochk.274:                                 ; preds = %streq.tag.272
  %r1358 = icmp eq i64 %r1350, 32761
  %r1359 = icmp eq i64 %r1351, 32761
  %r1360 = and i1 %r1358, %r1359
  br i1 %r1360, label %streq.false.277, label %streq.boxed.275

streq.boxed.275:                                  ; preds = %streq.ssochk.274
  %statepoint_token410 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r1346, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16.relocated, ptr addrspace(1) %r57.0.relocated395, ptr addrspace(1) %rs4gc.s10.relocated396, ptr addrspace(1) %r48.0.base.relocated397, ptr addrspace(1) %r48.0.relocated398, ptr addrspace(1) %rs4gc.s13.relocated399, ptr addrspace(1) %rs4gc.s15.relocated400) ]
  %r1361411 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token410)
  %rs4gc.s16.relocated412 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token410, i32 0, i32 0) ; (%rs4gc.s16.relocated, %rs4gc.s16.relocated)
  %r57.0.relocated413 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token410, i32 1, i32 1) ; (%r57.0.relocated395, %r57.0.relocated395)
  %rs4gc.s10.relocated414 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token410, i32 2, i32 2) ; (%rs4gc.s10.relocated396, %rs4gc.s10.relocated396)
  %r48.0.base.relocated415 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token410, i32 3, i32 3) ; (%r48.0.base.relocated397, %r48.0.base.relocated397)
  %r48.0.relocated416 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token410, i32 3, i32 4) ; (%r48.0.base.relocated397, %r48.0.relocated398)
  %rs4gc.s13.relocated417 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token410, i32 5, i32 5) ; (%rs4gc.s13.relocated399, %rs4gc.s13.relocated399)
  %rs4gc.s15.relocated418 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token410, i32 6, i32 6) ; (%rs4gc.s15.relocated400, %rs4gc.s15.relocated400)
  %r3507.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated417 to i64
  %r3507.rs4o = call i64 asm "", "=r,0"(i64 %r3507.rs4i) #7
  %r3507 = bitcast i64 %r3507.rs4o to double
  %statepoint_token419 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r3507, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16.relocated412, ptr addrspace(1) %r57.0.relocated413, ptr addrspace(1) %rs4gc.s10.relocated414, ptr addrspace(1) %r48.0.base.relocated415, ptr addrspace(1) %r48.0.relocated416, ptr addrspace(1) %rs4gc.s13.relocated417, ptr addrspace(1) %rs4gc.s15.relocated418) ]
  %r1362420 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token419)
  %rs4gc.s16.relocated421 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token419, i32 0, i32 0) ; (%rs4gc.s16.relocated412, %rs4gc.s16.relocated412)
  %r57.0.relocated422 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token419, i32 1, i32 1) ; (%r57.0.relocated413, %r57.0.relocated413)
  %rs4gc.s10.relocated423 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token419, i32 2, i32 2) ; (%rs4gc.s10.relocated414, %rs4gc.s10.relocated414)
  %r48.0.base.relocated424 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token419, i32 3, i32 3) ; (%r48.0.base.relocated415, %r48.0.base.relocated415)
  %r48.0.relocated425 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token419, i32 3, i32 4) ; (%r48.0.base.relocated415, %r48.0.relocated416)
  %rs4gc.s13.relocated426 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token419, i32 5, i32 5) ; (%rs4gc.s13.relocated417, %rs4gc.s13.relocated417)
  %rs4gc.s15.relocated427 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token419, i32 6, i32 6) ; (%rs4gc.s15.relocated418, %rs4gc.s15.relocated418)
  %statepoint_token428 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1361411, i64 %r1362420, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16.relocated421, ptr addrspace(1) %r57.0.relocated422, ptr addrspace(1) %rs4gc.s10.relocated423, ptr addrspace(1) %r48.0.base.relocated424, ptr addrspace(1) %r48.0.relocated425, ptr addrspace(1) %rs4gc.s13.relocated426, ptr addrspace(1) %rs4gc.s15.relocated427) ]
  %r1363429 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token428)
  %rs4gc.s16.relocated430 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token428, i32 0, i32 0) ; (%rs4gc.s16.relocated421, %rs4gc.s16.relocated421)
  %r57.0.relocated431 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token428, i32 1, i32 1) ; (%r57.0.relocated422, %r57.0.relocated422)
  %rs4gc.s10.relocated432 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token428, i32 2, i32 2) ; (%rs4gc.s10.relocated423, %rs4gc.s10.relocated423)
  %r48.0.base.relocated433 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token428, i32 3, i32 3) ; (%r48.0.base.relocated424, %r48.0.base.relocated424)
  %r48.0.relocated434 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token428, i32 3, i32 4) ; (%r48.0.base.relocated424, %r48.0.relocated425)
  %rs4gc.s13.relocated435 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token428, i32 5, i32 5) ; (%rs4gc.s13.relocated426, %rs4gc.s13.relocated426)
  %rs4gc.s15.relocated436 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token428, i32 6, i32 6) ; (%rs4gc.s15.relocated427, %rs4gc.s15.relocated427)
  br label %streq.merge.278

streq.true.276:                                   ; preds = %shadow.root.barrier.done.271
  br label %streq.merge.278

streq.false.277:                                  ; preds = %streq.ssochk.274
  br label %streq.merge.278

streq.merge.278:                                  ; preds = %streq.false.277, %streq.true.276, %streq.boxed.275, %streq.heap.273
  %.01088 = phi ptr addrspace(1) [ %rs4gc.s16.relocated, %streq.true.276 ], [ %rs4gc.s16.relocated403, %streq.heap.273 ], [ %rs4gc.s16.relocated, %streq.false.277 ], [ %rs4gc.s16.relocated430, %streq.boxed.275 ]
  %.141085 = phi ptr addrspace(1) [ %rs4gc.s15.relocated400, %streq.true.276 ], [ %rs4gc.s15.relocated409, %streq.heap.273 ], [ %rs4gc.s15.relocated400, %streq.false.277 ], [ %rs4gc.s15.relocated436, %streq.boxed.275 ]
  %.141065 = phi ptr addrspace(1) [ %rs4gc.s13.relocated399, %streq.true.276 ], [ %rs4gc.s13.relocated408, %streq.heap.273 ], [ %rs4gc.s13.relocated399, %streq.false.277 ], [ %rs4gc.s13.relocated435, %streq.boxed.275 ]
  %.171028 = phi ptr addrspace(1) [ %r48.0.relocated398, %streq.true.276 ], [ %r48.0.relocated407, %streq.heap.273 ], [ %r48.0.relocated398, %streq.false.277 ], [ %r48.0.relocated434, %streq.boxed.275 ]
  %.17988 = phi ptr addrspace(1) [ %r48.0.base.relocated397, %streq.true.276 ], [ %r48.0.base.relocated406, %streq.heap.273 ], [ %r48.0.base.relocated397, %streq.false.277 ], [ %r48.0.base.relocated433, %streq.boxed.275 ]
  %.17945 = phi ptr addrspace(1) [ %r57.0.relocated395, %streq.true.276 ], [ %r57.0.relocated404, %streq.heap.273 ], [ %r57.0.relocated395, %streq.false.277 ], [ %r57.0.relocated431, %streq.boxed.275 ]
  %.17 = phi ptr addrspace(1) [ %rs4gc.s10.relocated396, %streq.true.276 ], [ %rs4gc.s10.relocated405, %streq.heap.273 ], [ %rs4gc.s10.relocated396, %streq.false.277 ], [ %rs4gc.s10.relocated432, %streq.boxed.275 ]
  %r1364 = phi i32 [ 1, %streq.true.276 ], [ 0, %streq.false.277 ], [ %r1357402, %streq.heap.273 ], [ %r1363429, %streq.boxed.275 ]
  %r1365 = icmp ne i32 %r1364, 0
  %r1366 = xor i1 %r1365, true
  %r1367 = select i1 %r1366, i64 9222246136947933188, i64 9222246136947933187
  %r1368 = bitcast i64 %r1367 to double
  %r1369 = icmp eq i64 %r1367, 9222246136947933188
  br i1 %r1369, label %logical.merge.280, label %logical.then.279

logical.then.279:                                 ; preds = %streq.merge.278
  %r1370.rs4i = ptrtoint ptr addrspace(1) %.01088 to i64
  %r1370.rs4o = call i64 asm "", "=r,0"(i64 %r1370.rs4i) #7
  %r1370 = bitcast i64 %r1370.rs4o to double
  %statepoint_token437 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r1370, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01088, ptr addrspace(1) %.17945, ptr addrspace(1) %.17, ptr addrspace(1) %.17988, ptr addrspace(1) %.171028, ptr addrspace(1) %.141065, ptr addrspace(1) %.141085) ]
  %r1371438 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token437)
  %rs4gc.s16.relocated439 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token437, i32 0, i32 0) ; (%.01088, %.01088)
  %r57.0.relocated440 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token437, i32 1, i32 1) ; (%.17945, %.17945)
  %rs4gc.s10.relocated441 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token437, i32 2, i32 2) ; (%.17, %.17)
  %r48.0.base.relocated442 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token437, i32 3, i32 3) ; (%.17988, %.17988)
  %r48.0.relocated443 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token437, i32 3, i32 4) ; (%.17988, %.171028)
  %rs4gc.s13.relocated444 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token437, i32 5, i32 5) ; (%.141065, %.141065)
  %rs4gc.s15.relocated445 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token437, i32 6, i32 6) ; (%.141085, %.141085)
  %r1372 = bitcast i64 %r1371438 to double
  %r1373.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated444 to i64
  %r1373.rs4o = call i64 asm "", "=r,0"(i64 %r1373.rs4i) #7
  %r1373 = bitcast i64 %r1373.rs4o to double
  %r1374 = bitcast double %r1373 to i64
  %r1375 = icmp eq i64 %r1371438, %r1374
  br i1 %r1375, label %streq.true.285, label %streq.tag.281

logical.merge.280:                                ; preds = %streq.merge.287, %streq.merge.278
  %.11089 = phi ptr addrspace(1) [ %.01088, %streq.merge.278 ], [ %.21090, %streq.merge.287 ]
  %.151086 = phi ptr addrspace(1) [ %.141085, %streq.merge.278 ], [ %.161087, %streq.merge.287 ]
  %.151066 = phi ptr addrspace(1) [ %.141065, %streq.merge.278 ], [ %.161067, %streq.merge.287 ]
  %.181029 = phi ptr addrspace(1) [ %.171028, %streq.merge.278 ], [ %.191030, %streq.merge.287 ]
  %.18989 = phi ptr addrspace(1) [ %.17988, %streq.merge.278 ], [ %.19990, %streq.merge.287 ]
  %.18946 = phi ptr addrspace(1) [ %.17945, %streq.merge.278 ], [ %.19947, %streq.merge.287 ]
  %.18 = phi ptr addrspace(1) [ %.17, %streq.merge.278 ], [ %.19, %streq.merge.287 ]
  %r1396 = phi double [ %r1368, %streq.merge.278 ], [ %r1394, %streq.merge.287 ]
  %r1397 = phi i1 [ true, %streq.merge.278 ], [ %r1395, %streq.merge.287 ]
  br i1 %r1397, label %if.then.288, label %if.else.289

streq.tag.281:                                    ; preds = %logical.then.279
  %r1376 = lshr i64 %r1371438, 48
  %r1377 = lshr i64 %r1374, 48
  %r1378 = icmp eq i64 %r1376, 32767
  %r1379 = icmp eq i64 %r1377, 32767
  %r1380 = and i1 %r1378, %r1379
  br i1 %r1380, label %streq.heap.282, label %streq.ssochk.283

streq.heap.282:                                   ; preds = %streq.tag.281
  %r1381 = and i64 %r1371438, 281474976710655
  %r1382 = and i64 %r1374, 281474976710655
  %statepoint_token446 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1381, i64 %r1382, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16.relocated439, ptr addrspace(1) %r57.0.relocated440, ptr addrspace(1) %rs4gc.s10.relocated441, ptr addrspace(1) %r48.0.base.relocated442, ptr addrspace(1) %r48.0.relocated443, ptr addrspace(1) %rs4gc.s13.relocated444, ptr addrspace(1) %rs4gc.s15.relocated445) ]
  %r1383447 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token446)
  %rs4gc.s16.relocated448 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 0, i32 0) ; (%rs4gc.s16.relocated439, %rs4gc.s16.relocated439)
  %r57.0.relocated449 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 1, i32 1) ; (%r57.0.relocated440, %r57.0.relocated440)
  %rs4gc.s10.relocated450 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 2, i32 2) ; (%rs4gc.s10.relocated441, %rs4gc.s10.relocated441)
  %r48.0.base.relocated451 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 3, i32 3) ; (%r48.0.base.relocated442, %r48.0.base.relocated442)
  %r48.0.relocated452 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 3, i32 4) ; (%r48.0.base.relocated442, %r48.0.relocated443)
  %rs4gc.s13.relocated453 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 5, i32 5) ; (%rs4gc.s13.relocated444, %rs4gc.s13.relocated444)
  %rs4gc.s15.relocated454 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token446, i32 6, i32 6) ; (%rs4gc.s15.relocated445, %rs4gc.s15.relocated445)
  br label %streq.merge.287

streq.ssochk.283:                                 ; preds = %streq.tag.281
  %r1384 = icmp eq i64 %r1376, 32761
  %r1385 = icmp eq i64 %r1377, 32761
  %r1386 = and i1 %r1384, %r1385
  br i1 %r1386, label %streq.false.286, label %streq.boxed.284

streq.boxed.284:                                  ; preds = %streq.ssochk.283
  %statepoint_token455 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r1372, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16.relocated439, ptr addrspace(1) %r57.0.relocated440, ptr addrspace(1) %rs4gc.s10.relocated441, ptr addrspace(1) %r48.0.base.relocated442, ptr addrspace(1) %r48.0.relocated443, ptr addrspace(1) %rs4gc.s13.relocated444, ptr addrspace(1) %rs4gc.s15.relocated445) ]
  %r1387456 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token455)
  %rs4gc.s16.relocated457 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token455, i32 0, i32 0) ; (%rs4gc.s16.relocated439, %rs4gc.s16.relocated439)
  %r57.0.relocated458 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token455, i32 1, i32 1) ; (%r57.0.relocated440, %r57.0.relocated440)
  %rs4gc.s10.relocated459 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token455, i32 2, i32 2) ; (%rs4gc.s10.relocated441, %rs4gc.s10.relocated441)
  %r48.0.base.relocated460 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token455, i32 3, i32 3) ; (%r48.0.base.relocated442, %r48.0.base.relocated442)
  %r48.0.relocated461 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token455, i32 3, i32 4) ; (%r48.0.base.relocated442, %r48.0.relocated443)
  %rs4gc.s13.relocated462 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token455, i32 5, i32 5) ; (%rs4gc.s13.relocated444, %rs4gc.s13.relocated444)
  %rs4gc.s15.relocated463 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token455, i32 6, i32 6) ; (%rs4gc.s15.relocated445, %rs4gc.s15.relocated445)
  %r3506.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13.relocated462 to i64
  %r3506.rs4o = call i64 asm "", "=r,0"(i64 %r3506.rs4i) #7
  %r3506 = bitcast i64 %r3506.rs4o to double
  %statepoint_token464 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_get_string_pointer_unified, i32 1, i32 0, double %r3506, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16.relocated457, ptr addrspace(1) %r57.0.relocated458, ptr addrspace(1) %rs4gc.s10.relocated459, ptr addrspace(1) %r48.0.base.relocated460, ptr addrspace(1) %r48.0.relocated461, ptr addrspace(1) %rs4gc.s13.relocated462, ptr addrspace(1) %rs4gc.s15.relocated463) ]
  %r1388465 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token464)
  %rs4gc.s16.relocated466 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token464, i32 0, i32 0) ; (%rs4gc.s16.relocated457, %rs4gc.s16.relocated457)
  %r57.0.relocated467 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token464, i32 1, i32 1) ; (%r57.0.relocated458, %r57.0.relocated458)
  %rs4gc.s10.relocated468 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token464, i32 2, i32 2) ; (%rs4gc.s10.relocated459, %rs4gc.s10.relocated459)
  %r48.0.base.relocated469 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token464, i32 3, i32 3) ; (%r48.0.base.relocated460, %r48.0.base.relocated460)
  %r48.0.relocated470 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token464, i32 3, i32 4) ; (%r48.0.base.relocated460, %r48.0.relocated461)
  %rs4gc.s13.relocated471 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token464, i32 5, i32 5) ; (%rs4gc.s13.relocated462, %rs4gc.s13.relocated462)
  %rs4gc.s15.relocated472 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token464, i32 6, i32 6) ; (%rs4gc.s15.relocated463, %rs4gc.s15.relocated463)
  %statepoint_token473 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1387456, i64 %r1388465, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s16.relocated466, ptr addrspace(1) %r57.0.relocated467, ptr addrspace(1) %rs4gc.s10.relocated468, ptr addrspace(1) %r48.0.base.relocated469, ptr addrspace(1) %r48.0.relocated470, ptr addrspace(1) %rs4gc.s13.relocated471, ptr addrspace(1) %rs4gc.s15.relocated472) ]
  %r1389474 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token473)
  %rs4gc.s16.relocated475 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token473, i32 0, i32 0) ; (%rs4gc.s16.relocated466, %rs4gc.s16.relocated466)
  %r57.0.relocated476 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token473, i32 1, i32 1) ; (%r57.0.relocated467, %r57.0.relocated467)
  %rs4gc.s10.relocated477 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token473, i32 2, i32 2) ; (%rs4gc.s10.relocated468, %rs4gc.s10.relocated468)
  %r48.0.base.relocated478 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token473, i32 3, i32 3) ; (%r48.0.base.relocated469, %r48.0.base.relocated469)
  %r48.0.relocated479 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token473, i32 3, i32 4) ; (%r48.0.base.relocated469, %r48.0.relocated470)
  %rs4gc.s13.relocated480 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token473, i32 5, i32 5) ; (%rs4gc.s13.relocated471, %rs4gc.s13.relocated471)
  %rs4gc.s15.relocated481 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token473, i32 6, i32 6) ; (%rs4gc.s15.relocated472, %rs4gc.s15.relocated472)
  br label %streq.merge.287

streq.true.285:                                   ; preds = %logical.then.279
  br label %streq.merge.287

streq.false.286:                                  ; preds = %streq.ssochk.283
  br label %streq.merge.287

streq.merge.287:                                  ; preds = %streq.false.286, %streq.true.285, %streq.boxed.284, %streq.heap.282
  %.21090 = phi ptr addrspace(1) [ %rs4gc.s16.relocated439, %streq.true.285 ], [ %rs4gc.s16.relocated448, %streq.heap.282 ], [ %rs4gc.s16.relocated439, %streq.false.286 ], [ %rs4gc.s16.relocated475, %streq.boxed.284 ]
  %.161087 = phi ptr addrspace(1) [ %rs4gc.s15.relocated445, %streq.true.285 ], [ %rs4gc.s15.relocated454, %streq.heap.282 ], [ %rs4gc.s15.relocated445, %streq.false.286 ], [ %rs4gc.s15.relocated481, %streq.boxed.284 ]
  %.161067 = phi ptr addrspace(1) [ %rs4gc.s13.relocated444, %streq.true.285 ], [ %rs4gc.s13.relocated453, %streq.heap.282 ], [ %rs4gc.s13.relocated444, %streq.false.286 ], [ %rs4gc.s13.relocated480, %streq.boxed.284 ]
  %.191030 = phi ptr addrspace(1) [ %r48.0.relocated443, %streq.true.285 ], [ %r48.0.relocated452, %streq.heap.282 ], [ %r48.0.relocated443, %streq.false.286 ], [ %r48.0.relocated479, %streq.boxed.284 ]
  %.19990 = phi ptr addrspace(1) [ %r48.0.base.relocated442, %streq.true.285 ], [ %r48.0.base.relocated451, %streq.heap.282 ], [ %r48.0.base.relocated442, %streq.false.286 ], [ %r48.0.base.relocated478, %streq.boxed.284 ]
  %.19947 = phi ptr addrspace(1) [ %r57.0.relocated440, %streq.true.285 ], [ %r57.0.relocated449, %streq.heap.282 ], [ %r57.0.relocated440, %streq.false.286 ], [ %r57.0.relocated476, %streq.boxed.284 ]
  %.19 = phi ptr addrspace(1) [ %rs4gc.s10.relocated441, %streq.true.285 ], [ %rs4gc.s10.relocated450, %streq.heap.282 ], [ %rs4gc.s10.relocated441, %streq.false.286 ], [ %rs4gc.s10.relocated477, %streq.boxed.284 ]
  %r1390 = phi i32 [ 1, %streq.true.285 ], [ 0, %streq.false.286 ], [ %r1383447, %streq.heap.282 ], [ %r1389474, %streq.boxed.284 ]
  %r1391 = icmp ne i32 %r1390, 0
  %r1392 = xor i1 %r1391, true
  %r1393 = select i1 %r1392, i64 9222246136947933188, i64 9222246136947933187
  %r1394 = bitcast i64 %r1393 to double
  %r1395 = icmp eq i64 %r1393, 9222246136947933188
  br label %logical.merge.280

if.then.288:                                      ; preds = %logical.merge.280
  %r1398 = load double, ptr @test_json_cached_template_borrow_ts_.str.12.handle, align 8
  %statepoint_token482 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r1398, i32 0, i32 0)
  %r1399483 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token482)
  %r1400 = or i64 %r1399483, 9222527611924643840
  %r1401 = bitcast i64 %r1400 to double
  %statepoint_token484 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r1401, i32 0, i32 0)
  unreachable

if.else.289:                                      ; preds = %logical.merge.280
  br label %if.merge.290

if.merge.290:                                     ; preds = %if.else.289
  %r1403 = sitofp i32 %r58.0 to double
  %r1404 = fptosi double %r1403 to i64
  %r1406 = srem i64 %r1404, 23
  %r1407 = sitofp i64 %r1406 to double
  %r1408 = icmp eq i64 %r1406, 0
  %r1409 = fcmp olt double %r1403, 0.000000e+00
  %r1410 = and i1 %r1408, %r1409
  %r1411 = fneg double %r1407
  %r1412 = select i1 %r1410, double %r1411, double %r1407
  %r1413 = fcmp oeq double %r1412, 0.000000e+00
  %r1414 = select i1 %r1413, i64 9222246136947933188, i64 9222246136947933187
  %r1415 = bitcast i64 %r1414 to double
  %r1416 = icmp eq i64 %r1414, 9222246136947933188
  br i1 %r1416, label %if.then.291, label %if.else.292

if.then.291:                                      ; preds = %if.merge.290
  %r1417.rs4i = ptrtoint ptr addrspace(1) %.151086 to i64
  %r1417.rs4o = call i64 asm "", "=r,0"(i64 %r1417.rs4i) #7
  %r1417 = bitcast i64 %r1417.rs4o to double
  %r1418 = bitcast double %r1417 to i64
  %rs4gc.s17 = inttoptr i64 %r1418 to ptr addrspace(1)
  %r1420.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r1420 = call i64 asm "", "=r,0"(i64 %r1420.rs4i) #7
  %r1421 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1422 = icmp ne i32 %r1421, 0
  br i1 %r1422, label %shadow.root.barrier.294, label %shadow.root.barrier.done.295

if.else.292:                                      ; preds = %if.merge.290
  br label %if.merge.293

if.merge.293:                                     ; preds = %apush.merge.331, %if.else.292
  %.31091 = phi ptr addrspace(1) [ %.91097, %apush.merge.331 ], [ %.11089, %if.else.292 ]
  %.20948 = phi ptr addrspace(1) [ %.26954, %apush.merge.331 ], [ %.18946, %if.else.292 ]
  %.20 = phi ptr addrspace(1) [ %.26, %apush.merge.331 ], [ %.18, %if.else.292 ]
  %r48.1.base = phi ptr addrspace(1) [ %r48.2.base, %apush.merge.331 ], [ %.18989, %if.else.292 ], !is_base_value !0
  %r48.1 = phi ptr addrspace(1) [ %r48.2, %apush.merge.331 ], [ %.181029, %if.else.292 ]
  %r5.3 = phi ptr [ %r5.4, %apush.merge.331 ], [ %r5.2, %if.else.292 ]
  %statepoint_token485 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31091, ptr addrspace(1) %.20948, ptr addrspace(1) %r48.1.base, ptr addrspace(1) %.20, ptr addrspace(1) %r48.1) ]
  %r1629486 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token485)
  %rs4gc.s16.relocated487 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token485, i32 0, i32 0) ; (%.31091, %.31091)
  %r57.0.relocated488 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token485, i32 1, i32 1) ; (%.20948, %.20948)
  %r48.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token485, i32 2, i32 2) ; (%r48.1.base, %r48.1.base)
  %rs4gc.s10.relocated489 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token485, i32 3, i32 3) ; (%.20, %.20)
  %r48.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token485, i32 2, i32 4) ; (%r48.1.base, %r48.1)
  %r1630 = or i64 %r1629486, 9222527611924643840
  %r1631 = bitcast i64 %r1630 to double
  %rs4gc.b18 = bitcast double %r1631 to i64
  %rs4gc.s18 = inttoptr i64 %rs4gc.b18 to ptr addrspace(1)
  %r1632.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r1632 = call i64 asm "", "=r,0"(i64 %r1632.rs4i) #7
  %r1633 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1634 = icmp ne i32 %r1633, 0
  br i1 %r1634, label %shadow.root.barrier.334, label %shadow.root.barrier.done.335

shadow.root.barrier.294:                          ; preds = %if.then.291
  call void @js_write_barrier_root_nanbox(i64 %r1420) #7
  br label %shadow.root.barrier.done.295

shadow.root.barrier.done.295:                     ; preds = %shadow.root.barrier.294, %if.then.291
  %r1423.rs4i = ptrtoint ptr addrspace(1) %.151066 to i64
  %r1423.rs4o = call i64 asm "", "=r,0"(i64 %r1423.rs4i) #7
  %r1423 = bitcast i64 %r1423.rs4o to double
  %r1424 = bitcast double %r1423 to i64
  %rs4gc.s19 = inttoptr i64 %r1424 to ptr addrspace(1)
  %r1426.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r1426 = call i64 asm "", "=r,0"(i64 %r1426.rs4i) #7
  %r1427 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1428 = icmp ne i32 %r1427, 0
  br i1 %r1428, label %shadow.root.barrier.296, label %shadow.root.barrier.done.297

shadow.root.barrier.296:                          ; preds = %shadow.root.barrier.done.295
  call void @js_write_barrier_root_nanbox(i64 %r1426) #7
  br label %shadow.root.barrier.done.297

shadow.root.barrier.done.297:                     ; preds = %shadow.root.barrier.296, %shadow.root.barrier.done.295
  %r1430 = icmp eq ptr %r5.2, null
  br i1 %r1430, label %arena_state.init.298, label %arena_state.ready.299

arena_state.init.298:                             ; preds = %shadow.root.barrier.done.297
  %r1431 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r1432 = icmp ne i64 %r1431, -1
  br i1 %r1432, label %arena_state.hot_tls.tsd.300, label %arena_state.hot_tls.slow.302

arena_state.ready.299:                            ; preds = %arena_state.hot_tls.resolved.304, %shadow.root.barrier.done.297
  %.01142 = phi ptr addrspace(1) [ %.11143, %arena_state.hot_tls.resolved.304 ], [ %rs4gc.s17, %shadow.root.barrier.done.297 ]
  %.01139 = phi ptr addrspace(1) [ %.11140, %arena_state.hot_tls.resolved.304 ], [ %rs4gc.s19, %shadow.root.barrier.done.297 ]
  %.41092 = phi ptr addrspace(1) [ %.51093, %arena_state.hot_tls.resolved.304 ], [ %.11089, %shadow.root.barrier.done.297 ]
  %.201031 = phi ptr addrspace(1) [ %.211032, %arena_state.hot_tls.resolved.304 ], [ %.181029, %shadow.root.barrier.done.297 ]
  %.20991 = phi ptr addrspace(1) [ %.21992, %arena_state.hot_tls.resolved.304 ], [ %.18989, %shadow.root.barrier.done.297 ]
  %.21949 = phi ptr addrspace(1) [ %.22950, %arena_state.hot_tls.resolved.304 ], [ %.18946, %shadow.root.barrier.done.297 ]
  %.21 = phi ptr addrspace(1) [ %.22, %arena_state.hot_tls.resolved.304 ], [ %.18, %shadow.root.barrier.done.297 ]
  %r5.4 = phi ptr [ %r5.5, %arena_state.hot_tls.resolved.304 ], [ %r5.2, %shadow.root.barrier.done.297 ]
  %r1446 = phi ptr [ %r5.2, %shadow.root.barrier.done.297 ], [ %r1445, %arena_state.hot_tls.resolved.304 ]
  %r1447 = getelementptr i8, ptr %r1446, i64 8
  %r1448 = load i64, ptr %r1447, align 8
  %r1449 = add i64 %r1448, 40
  %r1450 = getelementptr i8, ptr %r1446, i64 16
  %r1451 = load i64, ptr %r1450, align 8
  %r1452 = icmp ule i64 %r1449, %r1451
  br i1 %r1452, label %alloc.fast.305, label %alloc.slow.306

arena_state.hot_tls.tsd.300:                      ; preds = %arena_state.init.298
  %r1433 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #7
  %r1434 = and i64 %r1433, -8
  %r1435 = shl i64 %r1431, 3
  %r1436 = add i64 %r1434, %r1435
  %r1437 = inttoptr i64 %r1436 to ptr
  %r1438 = load ptr, ptr %r1437, align 8
  %r1439 = icmp ne ptr %r1438, null
  br i1 %r1439, label %arena_state.hot_tls.fast.301, label %arena_state.hot_tls.slow.302

arena_state.hot_tls.fast.301:                     ; preds = %arena_state.hot_tls.tsd.300
  %r1440 = getelementptr i8, ptr %r1438, i64 8
  %r1441 = load ptr, ptr %r1440, align 8
  %r1442 = load ptr, ptr %r1441, align 8
  %r1443 = icmp ne ptr %r1442, null
  br i1 %r1443, label %arena_state.hot_tls.ready.303, label %arena_state.hot_tls.slow.302

arena_state.hot_tls.slow.302:                     ; preds = %arena_state.hot_tls.fast.301, %arena_state.hot_tls.tsd.300, %arena_state.init.298
  %statepoint_token490 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11089, ptr addrspace(1) %.18946, ptr addrspace(1) %.18, ptr addrspace(1) %.18989, ptr addrspace(1) %.181029, ptr addrspace(1) %rs4gc.s19, ptr addrspace(1) %rs4gc.s17) ]
  %r1444491 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token490)
  %rs4gc.s16.relocated492 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 0, i32 0) ; (%.11089, %.11089)
  %r57.0.relocated493 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 1, i32 1) ; (%.18946, %.18946)
  %rs4gc.s10.relocated494 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 2, i32 2) ; (%.18, %.18)
  %r48.0.base.relocated495 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 3, i32 3) ; (%.18989, %.18989)
  %r48.0.relocated496 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 3, i32 4) ; (%.18989, %.181029)
  %rs4gc.s19.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 5, i32 5) ; (%rs4gc.s19, %rs4gc.s19)
  %rs4gc.s17.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token490, i32 6, i32 6) ; (%rs4gc.s17, %rs4gc.s17)
  br label %arena_state.hot_tls.resolved.304

arena_state.hot_tls.ready.303:                    ; preds = %arena_state.hot_tls.fast.301
  br label %arena_state.hot_tls.resolved.304

arena_state.hot_tls.resolved.304:                 ; preds = %arena_state.hot_tls.ready.303, %arena_state.hot_tls.slow.302
  %.11143 = phi ptr addrspace(1) [ %rs4gc.s17, %arena_state.hot_tls.ready.303 ], [ %rs4gc.s17.relocated, %arena_state.hot_tls.slow.302 ]
  %.11140 = phi ptr addrspace(1) [ %rs4gc.s19, %arena_state.hot_tls.ready.303 ], [ %rs4gc.s19.relocated, %arena_state.hot_tls.slow.302 ]
  %.51093 = phi ptr addrspace(1) [ %.11089, %arena_state.hot_tls.ready.303 ], [ %rs4gc.s16.relocated492, %arena_state.hot_tls.slow.302 ]
  %.211032 = phi ptr addrspace(1) [ %.181029, %arena_state.hot_tls.ready.303 ], [ %r48.0.relocated496, %arena_state.hot_tls.slow.302 ]
  %.21992 = phi ptr addrspace(1) [ %.18989, %arena_state.hot_tls.ready.303 ], [ %r48.0.base.relocated495, %arena_state.hot_tls.slow.302 ]
  %.22950 = phi ptr addrspace(1) [ %.18946, %arena_state.hot_tls.ready.303 ], [ %r57.0.relocated493, %arena_state.hot_tls.slow.302 ]
  %.22 = phi ptr addrspace(1) [ %.18, %arena_state.hot_tls.ready.303 ], [ %rs4gc.s10.relocated494, %arena_state.hot_tls.slow.302 ]
  %r5.5 = phi ptr [ %r1441, %arena_state.hot_tls.ready.303 ], [ %r1444491, %arena_state.hot_tls.slow.302 ]
  %r1445 = phi ptr [ %r1441, %arena_state.hot_tls.ready.303 ], [ %r1444491, %arena_state.hot_tls.slow.302 ]
  br label %arena_state.ready.299

alloc.fast.305:                                   ; preds = %arena_state.ready.299
  store i64 %r1449, ptr %r1447, align 8
  %r1453 = load ptr, ptr %r1446, align 8
  %r1454 = getelementptr i8, ptr %r1453, i64 %r1448
  br label %alloc.merge.307

alloc.slow.306:                                   ; preds = %arena_state.ready.299
  %statepoint_token497 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r1446, i64 40, i64 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.41092, ptr addrspace(1) %.21949, ptr addrspace(1) %.21, ptr addrspace(1) %.20991, ptr addrspace(1) %.201031, ptr addrspace(1) %.01139, ptr addrspace(1) %.01142) ]
  %r1455498 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token497)
  %rs4gc.s16.relocated499 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token497, i32 0, i32 0) ; (%.41092, %.41092)
  %r57.0.relocated500 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token497, i32 1, i32 1) ; (%.21949, %.21949)
  %rs4gc.s10.relocated501 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token497, i32 2, i32 2) ; (%.21, %.21)
  %r48.0.base.relocated502 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token497, i32 3, i32 3) ; (%.20991, %.20991)
  %r48.0.relocated503 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token497, i32 3, i32 4) ; (%.20991, %.201031)
  %rs4gc.s19.relocated504 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token497, i32 5, i32 5) ; (%.01139, %.01139)
  %rs4gc.s17.relocated505 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token497, i32 6, i32 6) ; (%.01142, %.01142)
  br label %alloc.merge.307

alloc.merge.307:                                  ; preds = %alloc.slow.306, %alloc.fast.305
  %.21144 = phi ptr addrspace(1) [ %.01142, %alloc.fast.305 ], [ %rs4gc.s17.relocated505, %alloc.slow.306 ]
  %.21141 = phi ptr addrspace(1) [ %.01139, %alloc.fast.305 ], [ %rs4gc.s19.relocated504, %alloc.slow.306 ]
  %.61094 = phi ptr addrspace(1) [ %.41092, %alloc.fast.305 ], [ %rs4gc.s16.relocated499, %alloc.slow.306 ]
  %.221033 = phi ptr addrspace(1) [ %.201031, %alloc.fast.305 ], [ %r48.0.relocated503, %alloc.slow.306 ]
  %.22993 = phi ptr addrspace(1) [ %.20991, %alloc.fast.305 ], [ %r48.0.base.relocated502, %alloc.slow.306 ]
  %.23951 = phi ptr addrspace(1) [ %.21949, %alloc.fast.305 ], [ %r57.0.relocated500, %alloc.slow.306 ]
  %.23 = phi ptr addrspace(1) [ %.21, %alloc.fast.305 ], [ %rs4gc.s10.relocated501, %alloc.slow.306 ]
  %r1456 = phi ptr [ %r1454, %alloc.fast.305 ], [ %r1455498, %alloc.slow.306 ]
  store <2 x i64> %r1458, ptr %r1456, align 8
  %r1460 = getelementptr i8, ptr %r1456, i64 16
  store i64 0, ptr %r1460, align 8
  %r1461 = getelementptr i8, ptr %r1456, i64 24
  store i64 9222246136947933185, ptr %r1461, align 8
  %r1462 = getelementptr i8, ptr %r1456, i64 32
  store i64 9222246136947933185, ptr %r1462, align 8
  %r1463 = getelementptr i8, ptr %r1456, i64 8
  %r1464 = ptrtoint ptr %r1463 to i64
  %r1465 = load atomic i32, ptr @PERRY_PER_OBJECT_LAYOUTS_ANY monotonic, align 4
  %r1466 = icmp ne i32 %r1465, 0
  br i1 %r1466, label %layout_forget.young.308, label %layout_forget.done.311

layout_forget.young.308:                          ; preds = %alloc.merge.307
  %r1467 = load atomic i32, ptr @PERRY_YOUNG_LAYOUT_RECORDS monotonic, align 4
  %r1468 = icmp ne i32 %r1467, 0
  br i1 %r1468, label %layout_forget.sketch.309, label %layout_forget.done.311

layout_forget.sketch.309:                         ; preds = %layout_forget.young.308
  %r1469 = mul i64 %r1464, -7046029254386353131
  %r1470 = lshr i64 %r1469, 52
  %r1471 = lshr i64 %r1470, 6
  %r1472 = and i64 %r1470, 63
  %r1473 = shl nuw i64 1, %r1472
  %r1474 = getelementptr i64, ptr @PERRY_LAYOUT_ADDR_FILTER, i64 %r1471
  %r1475 = load atomic i64, ptr %r1474 monotonic, align 8
  %r1476 = and i64 %r1475, %r1473
  %r1477 = icmp ne i64 %r1476, 0
  br i1 %r1477, label %layout_forget.armed.310, label %layout_forget.done.311

layout_forget.armed.310:                          ; preds = %layout_forget.sketch.309
  call void @js_gc_forget_object_layout(i64 %r1464) #7
  br label %layout_forget.done.311

layout_forget.done.311:                           ; preds = %layout_forget.armed.310, %layout_forget.sketch.309, %layout_forget.young.308, %alloc.merge.307
  %rs4gc.s20 = inttoptr i64 %r1464 to ptr addrspace(1)
  %r1479.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r1479 = call i64 asm "", "=r,0"(i64 %r1479.rs4i) #7
  %r1480 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1481 = icmp ne i32 %r1480, 0
  br i1 %r1481, label %shadow.root.barrier.312, label %shadow.root.barrier.done.313

shadow.root.barrier.312:                          ; preds = %layout_forget.done.311
  call void @js_write_barrier_root_nanbox(i64 %r1479) #7
  br label %shadow.root.barrier.done.313

shadow.root.barrier.done.313:                     ; preds = %shadow.root.barrier.312, %layout_forget.done.311
  %r1482 = or i64 %r1464, 9222527611924643840
  %r1483 = bitcast i64 %r1482 to double
  %r1484.rs4i = ptrtoint ptr addrspace(1) %.21144 to i64
  %r1484 = call i64 asm "", "=r,0"(i64 %r1484.rs4i) #7
  %r1485 = bitcast i64 %r1484 to double
  %r1486.rs4i = ptrtoint ptr addrspace(1) %.21141 to i64
  %r1486 = call i64 asm "", "=r,0"(i64 %r1486.rs4i) #7
  %r1487 = bitcast i64 %r1486 to double
  %r1488 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r1489 = icmp eq i8 %r1488, 0
  br i1 %r1489, label %ctor_prologue.fast.314, label %ctor_prologue.slow.315

ctor_prologue.fast.314:                           ; preds = %shadow.root.barrier.done.313
  %r1490 = inttoptr i64 %r1464 to ptr
  %r1491 = getelementptr i8, ptr %r1490, i64 16
  %r1492 = bitcast double %r1483 to i64
  %r1493 = getelementptr double, ptr %r1491, i64 0
  store double %r1485, ptr %r1493, align 8
  %r1494 = ptrtoint ptr %r1493 to i64
  %r1495 = bitcast double %r1485 to i64
  %r1496 = lshr i64 %r1495, 48
  %r1497 = icmp eq i64 %r1496, 0
  %r1498 = icmp uge i64 %r1495, 4096
  %r1499 = and i1 %r1497, %r1498
  %r1500 = icmp eq i64 %r1496, 32765
  %r1501 = icmp eq i64 %r1496, 32767
  %r1502 = icmp eq i64 %r1496, 32762
  %r1503 = or i1 %r1500, %r1501
  %r1504 = or i1 %r1503, %r1502
  %r1505 = or i1 %r1504, %r1499
  br i1 %r1505, label %ctor_prologue.barrier.maybe.317, label %ctor_prologue.barrier.done.319

ctor_prologue.slow.315:                           ; preds = %shadow.root.barrier.done.313
  %statepoint_token506 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double)) @test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18_constructor, i32 3, i32 0, double %r1483, double %r1485, double %r1487, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.61094, ptr addrspace(1) %.23951, ptr addrspace(1) %.23, ptr addrspace(1) %.22993, ptr addrspace(1) %.221033, ptr addrspace(1) %rs4gc.s20) ]
  %r1535507 = call double @llvm.experimental.gc.result.f64(token %statepoint_token506)
  %rs4gc.s16.relocated508 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token506, i32 0, i32 0) ; (%.61094, %.61094)
  %r57.0.relocated509 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token506, i32 1, i32 1) ; (%.23951, %.23951)
  %rs4gc.s10.relocated510 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token506, i32 2, i32 2) ; (%.23, %.23)
  %r48.0.base.relocated511 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token506, i32 3, i32 3) ; (%.22993, %.22993)
  %r48.0.relocated512 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token506, i32 3, i32 4) ; (%.22993, %.221033)
  %rs4gc.s20.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token506, i32 5, i32 5) ; (%rs4gc.s20, %rs4gc.s20)
  br label %ctor_prologue.merge.316

ctor_prologue.merge.316:                          ; preds = %ctor_prologue.barrier.done.322, %ctor_prologue.slow.315
  %.01145 = phi ptr addrspace(1) [ %rs4gc.s20, %ctor_prologue.barrier.done.322 ], [ %rs4gc.s20.relocated, %ctor_prologue.slow.315 ]
  %.71095 = phi ptr addrspace(1) [ %.61094, %ctor_prologue.barrier.done.322 ], [ %rs4gc.s16.relocated508, %ctor_prologue.slow.315 ]
  %.231034 = phi ptr addrspace(1) [ %.221033, %ctor_prologue.barrier.done.322 ], [ %r48.0.relocated512, %ctor_prologue.slow.315 ]
  %.23994 = phi ptr addrspace(1) [ %.22993, %ctor_prologue.barrier.done.322 ], [ %r48.0.base.relocated511, %ctor_prologue.slow.315 ]
  %.24952 = phi ptr addrspace(1) [ %.23951, %ctor_prologue.barrier.done.322 ], [ %r57.0.relocated509, %ctor_prologue.slow.315 ]
  %.24 = phi ptr addrspace(1) [ %.23, %ctor_prologue.barrier.done.322 ], [ %rs4gc.s10.relocated510, %ctor_prologue.slow.315 ]
  %r1536 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.322 ], [ %r1535507, %ctor_prologue.slow.315 ]
  %r1537.rs4i = ptrtoint ptr addrspace(1) %.01145 to i64
  %r1537 = call i64 asm "", "=r,0"(i64 %r1537.rs4i) #7
  %r1538 = or i64 %r1537, 9222527611924643840
  %r1539 = bitcast i64 %r1538 to double
  %r1540 = bitcast double %r1536 to i64
  %r1541 = icmp eq i64 %r1540, 9222246136947933185
  br i1 %r1541, label %ctor_ret.merge.324, label %ctor_ret.override.323

ctor_prologue.barrier.maybe.317:                  ; preds = %ctor_prologue.fast.314
  %r1506 = sub i64 %r1464, 7
  %r1507 = inttoptr i64 %r1506 to ptr
  %r1508 = load i8, ptr %r1507, align 1
  %r1509 = and i8 %r1508, 32
  %r1510 = icmp ne i8 %r1509, 0
  %r1511 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1512 = icmp ne i32 %r1511, 0
  %r1513 = or i1 %r1510, %r1512
  br i1 %r1513, label %ctor_prologue.barrier.318, label %ctor_prologue.barrier.done.319

ctor_prologue.barrier.318:                        ; preds = %ctor_prologue.barrier.maybe.317
  call void @js_write_barrier_slot_validated_parent(i64 %r1464, i64 %r1494, i64 %r1495) #7
  br label %ctor_prologue.barrier.done.319

ctor_prologue.barrier.done.319:                   ; preds = %ctor_prologue.barrier.318, %ctor_prologue.barrier.maybe.317, %ctor_prologue.fast.314
  %r1514 = getelementptr double, ptr %r1491, i64 1
  store double %r1487, ptr %r1514, align 8
  %r1515 = ptrtoint ptr %r1514 to i64
  %r1516 = bitcast double %r1487 to i64
  %r1517 = lshr i64 %r1516, 48
  %r1518 = icmp eq i64 %r1517, 0
  %r1519 = icmp uge i64 %r1516, 4096
  %r1520 = and i1 %r1518, %r1519
  %r1521 = icmp eq i64 %r1517, 32765
  %r1522 = icmp eq i64 %r1517, 32767
  %r1523 = icmp eq i64 %r1517, 32762
  %r1524 = or i1 %r1521, %r1522
  %r1525 = or i1 %r1524, %r1523
  %r1526 = or i1 %r1525, %r1520
  br i1 %r1526, label %ctor_prologue.barrier.maybe.320, label %ctor_prologue.barrier.done.322

ctor_prologue.barrier.maybe.320:                  ; preds = %ctor_prologue.barrier.done.319
  %r1527 = sub i64 %r1464, 7
  %r1528 = inttoptr i64 %r1527 to ptr
  %r1529 = load i8, ptr %r1528, align 1
  %r1530 = and i8 %r1529, 32
  %r1531 = icmp ne i8 %r1530, 0
  %r1532 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1533 = icmp ne i32 %r1532, 0
  %r1534 = or i1 %r1531, %r1533
  br i1 %r1534, label %ctor_prologue.barrier.321, label %ctor_prologue.barrier.done.322

ctor_prologue.barrier.321:                        ; preds = %ctor_prologue.barrier.maybe.320
  call void @js_write_barrier_slot_validated_parent(i64 %r1464, i64 %r1515, i64 %r1516) #7
  br label %ctor_prologue.barrier.done.322

ctor_prologue.barrier.done.322:                   ; preds = %ctor_prologue.barrier.321, %ctor_prologue.barrier.maybe.320, %ctor_prologue.barrier.done.319
  br label %ctor_prologue.merge.316

ctor_ret.override.323:                            ; preds = %ctor_prologue.merge.316
  %statepoint_token513 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r1539, double %r1536, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.71095, ptr addrspace(1) %.24952, ptr addrspace(1) %.24, ptr addrspace(1) %.23994, ptr addrspace(1) %.231034) ]
  %r1542514 = call double @llvm.experimental.gc.result.f64(token %statepoint_token513)
  %rs4gc.s16.relocated515 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 0, i32 0) ; (%.71095, %.71095)
  %r57.0.relocated516 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 1, i32 1) ; (%.24952, %.24952)
  %rs4gc.s10.relocated517 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 2, i32 2) ; (%.24, %.24)
  %r48.0.base.relocated518 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 3, i32 3) ; (%.23994, %.23994)
  %r48.0.relocated519 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token513, i32 3, i32 4) ; (%.23994, %.231034)
  br label %ctor_ret.merge.324

ctor_ret.merge.324:                               ; preds = %ctor_ret.override.323, %ctor_prologue.merge.316
  %.81096 = phi ptr addrspace(1) [ %.71095, %ctor_prologue.merge.316 ], [ %rs4gc.s16.relocated515, %ctor_ret.override.323 ]
  %.241035 = phi ptr addrspace(1) [ %.231034, %ctor_prologue.merge.316 ], [ %r48.0.relocated519, %ctor_ret.override.323 ]
  %.24995 = phi ptr addrspace(1) [ %.23994, %ctor_prologue.merge.316 ], [ %r48.0.base.relocated518, %ctor_ret.override.323 ]
  %.25953 = phi ptr addrspace(1) [ %.24952, %ctor_prologue.merge.316 ], [ %r57.0.relocated516, %ctor_ret.override.323 ]
  %.25 = phi ptr addrspace(1) [ %.24, %ctor_prologue.merge.316 ], [ %rs4gc.s10.relocated517, %ctor_ret.override.323 ]
  %r1543 = phi double [ %r1539, %ctor_prologue.merge.316 ], [ %r1542514, %ctor_ret.override.323 ]
  %r1544 = bitcast double %r1543 to i64
  %r1545.rs4i = ptrtoint ptr addrspace(1) %.241035 to i64
  %r1545.rs4o = call i64 asm "", "=r,0"(i64 %r1545.rs4i) #7
  %r1545 = bitcast i64 %r1545.rs4o to double
  %r1546 = bitcast double %r1545 to i64
  %r1547 = and i64 %r1546, 281474976710655
  %r1548 = sub nsw i64 %r1547, 8
  %r1549 = inttoptr i64 %r1548 to ptr
  %r1550 = load i8, ptr %r1549, align 1
  %r1551 = icmp ne i8 %r1550, 1
  %r1552 = sub nsw i64 %r1547, 7
  %r1553 = inttoptr i64 %r1552 to ptr
  %r1554 = load i8, ptr %r1553, align 1
  %r1555 = and i8 %r1554, -128
  %r1556 = icmp ne i8 %r1555, 0
  %r1557 = or i1 %r1551, %r1556
  br i1 %r1556, label %apush.fwd.325, label %apush.elements.326

apush.fwd.325:                                    ; preds = %apush.elements.check.327, %ctor_ret.merge.324
  %statepoint_token520 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1547, double %r1543, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81096, ptr addrspace(1) %.25953, ptr addrspace(1) %.25) ]
  %r1584521 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token520)
  %rs4gc.s16.relocated522 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 0, i32 0) ; (%.81096, %.81096)
  %r57.0.relocated523 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 1, i32 1) ; (%.25953, %.25953)
  %rs4gc.s10.relocated524 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token520, i32 2, i32 2) ; (%.25, %.25)
  %r1585 = or i64 %r1584521, 9222527611924643840
  %r1586 = bitcast i64 %r1585 to double
  %rs4gc.b21 = bitcast double %r1586 to i64
  %rs4gc.s21 = inttoptr i64 %rs4gc.b21 to ptr addrspace(1)
  br label %apush.merge.331

apush.elements.326:                               ; preds = %ctor_ret.merge.324
  %r1559 = add nuw nsw i64 %r1547, 8
  %r1560 = inttoptr i64 %r1559 to ptr
  %r1561 = load i64, ptr %r1560, align 8
  %r1562 = icmp ne i64 %r1561, 0
  %r1563 = icmp eq i8 %r1550, 2
  %r1564 = and i1 %r1563, %r1562
  %r1565 = select i1 %r1564, i64 %r1561, i64 %r1547
  %r1566 = inttoptr i64 %r1565 to ptr
  %r1567 = getelementptr i64, ptr %r1566, i64 12
  %r1568 = load i64, ptr %r1567, align 8
  %r1569 = icmp ne i64 %r1568, 0
  %r1570 = and i1 %r1564, %r1569
  %r1571 = select i1 %r1570, i64 %r1568, i64 %r1547
  %r1558 = icmp eq i8 %r1550, 1
  br i1 %r1558, label %apush.nofwd.328, label %apush.elements.check.327

apush.elements.check.327:                         ; preds = %apush.elements.326
  %r1572 = icmp ne i64 %r1571, 0
  %r1573 = sub i64 %r1571, 8
  %r1574 = inttoptr i64 %r1573 to ptr
  %r1575 = load i8, ptr %r1574, align 1
  %r1576 = icmp eq i8 %r1575, 1
  %r1577 = sub i64 %r1571, 7
  %r1578 = inttoptr i64 %r1577 to ptr
  %r1579 = load i8, ptr %r1578, align 1
  %r1580 = and i8 %r1579, -128
  %r1581 = icmp eq i8 %r1580, 0
  %r1582 = and i1 %r1572, %r1576
  %r1583 = and i1 %r1582, %r1581
  br i1 %r1583, label %apush.nofwd.328, label %apush.fwd.325

apush.nofwd.328:                                  ; preds = %apush.elements.check.327, %apush.elements.326
  %r1587 = phi i64 [ %r1547, %apush.elements.326 ], [ %r1571, %apush.elements.check.327 ]
  %r1588 = sub i64 %r1587, 6
  %r1589 = inttoptr i64 %r1588 to ptr
  %r1590 = load i16, ptr %r1589, align 2
  %r1591 = and i16 %r1590, -2937
  %r1592 = icmp eq i16 %r1591, -24576
  %r1593 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1594 = icmp eq i8 %r1593, 0
  %r1595 = and i1 %r1592, %r1594
  %r1596 = icmp ult i64 %r1587, 4096
  %r1597 = inttoptr i64 %r1587 to ptr
  %r1598 = select i1 %r1596, ptr @perry_null_guard_zero_test_json_cached_template_borrow_ts, ptr %r1597
  %r1599 = load i32, ptr %r1598, align 4
  %r1600 = add i64 %r1587, 4
  %r1601 = inttoptr i64 %r1600 to ptr
  %r1602 = load i32, ptr %r1601, align 4
  %r1603 = icmp ult i32 %r1599, %r1602
  %r1604 = and i1 %r1603, %r1595
  br i1 %r1604, label %apush.inbounds.329, label %apush.realloc.330

apush.inbounds.329:                               ; preds = %apush.nofwd.328
  %r1605 = icmp ult i64 %r1587, 4096
  %r1606 = inttoptr i64 %r1587 to ptr
  %r1607 = select i1 %r1605, ptr @perry_null_guard_zero_test_json_cached_template_borrow_ts, ptr %r1606
  %r1608 = load i32, ptr %r1607, align 4
  %r1609 = zext i32 %r1608 to i64
  %r1610 = shl nuw nsw i64 %r1609, 3
  %r1611 = add nuw nsw i64 %r1610, 8
  %r1612 = add i64 %r1587, %r1611
  %r1613 = inttoptr i64 %r1612 to ptr
  store double %r1543, ptr %r1613, align 8
  call void @js_string_addref_if_heap_string(double %r1543) #7
  %r1614 = bitcast double %r1543 to i64
  %r1615 = sub i64 %r1587, 7
  %r1616 = inttoptr i64 %r1615 to ptr
  %r1617 = load i8, ptr %r1616, align 1
  %r1618 = and i8 %r1617, 32
  %r1619 = icmp ne i8 %r1618, 0
  %r1620 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1621 = icmp ne i32 %r1620, 0
  %r1622 = or i1 %r1619, %r1621
  br i1 %r1622, label %apush.barrier.332, label %apush.barrier.done.333

apush.realloc.330:                                ; preds = %apush.nofwd.328
  %statepoint_token525 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1547, double %r1543, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.81096, ptr addrspace(1) %.25953, ptr addrspace(1) %.25) ]
  %r1625526 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token525)
  %rs4gc.s16.relocated527 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token525, i32 0, i32 0) ; (%.81096, %.81096)
  %r57.0.relocated528 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token525, i32 1, i32 1) ; (%.25953, %.25953)
  %rs4gc.s10.relocated529 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token525, i32 2, i32 2) ; (%.25, %.25)
  %r1626 = or i64 %r1625526, 9222527611924643840
  %r1627 = bitcast i64 %r1626 to double
  %rs4gc.b22 = bitcast double %r1627 to i64
  %rs4gc.s22 = inttoptr i64 %rs4gc.b22 to ptr addrspace(1)
  br label %apush.merge.331

apush.merge.331:                                  ; preds = %apush.barrier.done.333, %apush.realloc.330, %apush.fwd.325
  %.91097 = phi ptr addrspace(1) [ %rs4gc.s16.relocated522, %apush.fwd.325 ], [ %.81096, %apush.barrier.done.333 ], [ %rs4gc.s16.relocated527, %apush.realloc.330 ]
  %.26954 = phi ptr addrspace(1) [ %r57.0.relocated523, %apush.fwd.325 ], [ %.25953, %apush.barrier.done.333 ], [ %r57.0.relocated528, %apush.realloc.330 ]
  %.26 = phi ptr addrspace(1) [ %rs4gc.s10.relocated524, %apush.fwd.325 ], [ %.25, %apush.barrier.done.333 ], [ %rs4gc.s10.relocated529, %apush.realloc.330 ]
  %r48.2.base = phi ptr addrspace(1) [ %rs4gc.s21, %apush.fwd.325 ], [ %.24995, %apush.barrier.done.333 ], [ %rs4gc.s22, %apush.realloc.330 ], !is_base_value !0
  %r48.2 = phi ptr addrspace(1) [ %rs4gc.s21, %apush.fwd.325 ], [ %.241035, %apush.barrier.done.333 ], [ %rs4gc.s22, %apush.realloc.330 ]
  br label %if.merge.293

apush.barrier.332:                                ; preds = %apush.inbounds.329
  call void @js_write_barrier_slot_validated_parent(i64 %r1587, i64 %r1612, i64 %r1614) #7
  br label %apush.barrier.done.333

apush.barrier.done.333:                           ; preds = %apush.barrier.332, %apush.inbounds.329
  %r1623 = add i32 %r1608, 1
  %r1624 = inttoptr i64 %r1587 to ptr
  store i32 %r1623, ptr %r1624, align 4
  br label %apush.merge.331

shadow.root.barrier.334:                          ; preds = %if.merge.293
  call void @js_write_barrier_root_nanbox(i64 %r1632) #7
  br label %shadow.root.barrier.done.335

shadow.root.barrier.done.335:                     ; preds = %shadow.root.barrier.334, %if.merge.293
  %r1635 = bitcast double %r1631 to i64
  %r1636 = and i64 %r1635, 281474976710655
  call void @js_array_declare_all_pointer_elements(i64 %r1636) #7
  br label %for.cond.336

for.cond.336:                                     ; preds = %for.update.338, %shadow.root.barrier.done.335
  %.01123 = phi ptr addrspace(1) [ %r48.1.relocated, %shadow.root.barrier.done.335 ], [ %.81131, %for.update.338 ]
  %.01107 = phi ptr addrspace(1) [ %r48.1.base.relocated, %shadow.root.barrier.done.335 ], [ %.81115, %for.update.338 ]
  %.101098 = phi ptr addrspace(1) [ %rs4gc.s16.relocated487, %shadow.root.barrier.done.335 ], [ %.181106, %for.update.338 ]
  %.27955 = phi ptr addrspace(1) [ %r57.0.relocated488, %shadow.root.barrier.done.335 ], [ %.35963, %for.update.338 ]
  %.27 = phi ptr addrspace(1) [ %rs4gc.s10.relocated489, %shadow.root.barrier.done.335 ], [ %.35, %for.update.338 ]
  %r1637.0 = phi double [ 0.000000e+00, %shadow.root.barrier.done.335 ], [ %r1855, %for.update.338 ]
  %r1628.0.base = phi ptr addrspace(1) [ %rs4gc.s18, %shadow.root.barrier.done.335 ], [ %.01164, %for.update.338 ], !is_base_value !0
  %r1628.0 = phi ptr addrspace(1) [ %rs4gc.s18, %shadow.root.barrier.done.335 ], [ %.01165, %for.update.338 ]
  %r5.6 = phi ptr [ %r5.3, %shadow.root.barrier.done.335 ], [ %r5.7, %for.update.338 ]
  %r1639 = fcmp olt double %r1637.0, 8.000000e+01
  %r1640 = select i1 %r1639, i64 9222246136947933188, i64 9222246136947933187
  %r1641 = bitcast i64 %r1640 to double
  %r1642 = icmp eq i64 %r1640, 9222246136947933188
  br i1 %r1642, label %for.body.337, label %for.exit.339

for.body.337:                                     ; preds = %for.cond.336
  %r1644 = load double, ptr @test_json_cached_template_borrow_ts_.str.13.handle, align 8
  %r1646 = fcmp oge double %r1637.0, 0.000000e+00
  %r1647 = fcmp olt double %r1637.0, 3.200000e+01
  %r1648 = and i1 %r1646, %r1647
  br i1 %r1648, label %csite.chk.340, label %csite.plain.343

for.update.338:                                   ; preds = %gcpoll.done.381
  %r1855 = fadd double %r1637.0, 1.000000e+00
  br label %for.cond.336

for.exit.339:                                     ; preds = %for.cond.336
  %r1856.rs4i = ptrtoint ptr addrspace(1) %.27955 to i64
  %r1856.rs4o = call i64 asm "", "=r,0"(i64 %r1856.rs4i) #7
  %r1856 = bitcast i64 %r1856.rs4o to double
  %r1857 = bitcast double %r1856 to i64
  %rs4gc.s23 = inttoptr i64 %r1857 to ptr addrspace(1)
  %r1858.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r1858 = call i64 asm "", "=r,0"(i64 %r1858.rs4i) #7
  %r1859 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1860 = icmp ne i32 %r1859, 0
  br i1 %r1860, label %shadow.root.barrier.382, label %shadow.root.barrier.done.383

csite.chk.340:                                    ; preds = %for.body.337
  %r1649 = fptosi double %r1637.0 to i32
  %r1650 = sitofp i32 %r1649 to double
  %r1651 = fcmp oeq double %r1650, %r1637.0
  %r1652 = sext i32 %r1649 to i64
  %r1653 = getelementptr [32 x i64], ptr @perry_concat_site_test_json_cached_template_borrow_ts__17, i64 0, i64 %r1652
  %r1654 = load i64, ptr %r1653, align 8
  %r1655 = icmp ne i64 %r1654, 0
  %r1656 = and i1 %r1651, %r1655
  br i1 %r1656, label %csite.hit.341, label %csite.fill.342

csite.hit.341:                                    ; preds = %csite.chk.340
  %r1657 = bitcast i64 %r1654 to double
  br label %csite.merge.344

csite.fill.342:                                   ; preds = %csite.chk.340
  %r1658 = bitcast double %r1644 to i64
  %r1659 = and i64 %r1658, 281474976710655
  %statepoint_token530 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, double)) @js_string_concat_site_value, i32 3, i32 0, i64 ptrtoint (ptr @perry_concat_site_test_json_cached_template_borrow_ts__17 to i64), i64 %r1659, double %r1637.0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.101098, ptr addrspace(1) %.27955, ptr addrspace(1) %.01107, ptr addrspace(1) %.27, ptr addrspace(1) %r1628.0.base, ptr addrspace(1) %r1628.0, ptr addrspace(1) %.01123) ]
  %r1661531 = call double @llvm.experimental.gc.result.f64(token %statepoint_token530)
  %rs4gc.s16.relocated532 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token530, i32 0, i32 0) ; (%.101098, %.101098)
  %r57.0.relocated533 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token530, i32 1, i32 1) ; (%.27955, %.27955)
  %r48.1.base.relocated534 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token530, i32 2, i32 2) ; (%.01107, %.01107)
  %rs4gc.s10.relocated535 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token530, i32 3, i32 3) ; (%.27, %.27)
  %r1628.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token530, i32 4, i32 4) ; (%r1628.0.base, %r1628.0.base)
  %r1628.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token530, i32 4, i32 5) ; (%r1628.0.base, %r1628.0)
  %r48.1.relocated536 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token530, i32 2, i32 6) ; (%.01107, %.01123)
  br label %csite.merge.344

csite.plain.343:                                  ; preds = %for.body.337
  %r1662 = bitcast double %r1644 to i64
  %r1663 = and i64 %r1662, 281474976710655
  %statepoint_token537 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r1663, double %r1637.0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.101098, ptr addrspace(1) %.27955, ptr addrspace(1) %.01107, ptr addrspace(1) %.27, ptr addrspace(1) %r1628.0.base, ptr addrspace(1) %r1628.0, ptr addrspace(1) %.01123) ]
  %r1664538 = call double @llvm.experimental.gc.result.f64(token %statepoint_token537)
  %rs4gc.s16.relocated539 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token537, i32 0, i32 0) ; (%.101098, %.101098)
  %r57.0.relocated540 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token537, i32 1, i32 1) ; (%.27955, %.27955)
  %r48.1.base.relocated541 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token537, i32 2, i32 2) ; (%.01107, %.01107)
  %rs4gc.s10.relocated542 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token537, i32 3, i32 3) ; (%.27, %.27)
  %r1628.0.base.relocated543 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token537, i32 4, i32 4) ; (%r1628.0.base, %r1628.0.base)
  %r1628.0.relocated544 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token537, i32 4, i32 5) ; (%r1628.0.base, %r1628.0)
  %r48.1.relocated545 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token537, i32 2, i32 6) ; (%.01107, %.01123)
  br label %csite.merge.344

csite.merge.344:                                  ; preds = %csite.plain.343, %csite.fill.342, %csite.hit.341
  %.01152 = phi ptr addrspace(1) [ %r1628.0, %csite.hit.341 ], [ %r1628.0.relocated, %csite.fill.342 ], [ %r1628.0.relocated544, %csite.plain.343 ]
  %.01146 = phi ptr addrspace(1) [ %r1628.0.base, %csite.hit.341 ], [ %r1628.0.base.relocated, %csite.fill.342 ], [ %r1628.0.base.relocated543, %csite.plain.343 ]
  %.11124 = phi ptr addrspace(1) [ %.01123, %csite.hit.341 ], [ %r48.1.relocated536, %csite.fill.342 ], [ %r48.1.relocated545, %csite.plain.343 ]
  %.11108 = phi ptr addrspace(1) [ %.01107, %csite.hit.341 ], [ %r48.1.base.relocated534, %csite.fill.342 ], [ %r48.1.base.relocated541, %csite.plain.343 ]
  %.111099 = phi ptr addrspace(1) [ %.101098, %csite.hit.341 ], [ %rs4gc.s16.relocated532, %csite.fill.342 ], [ %rs4gc.s16.relocated539, %csite.plain.343 ]
  %.28956 = phi ptr addrspace(1) [ %.27955, %csite.hit.341 ], [ %r57.0.relocated533, %csite.fill.342 ], [ %r57.0.relocated540, %csite.plain.343 ]
  %.28 = phi ptr addrspace(1) [ %.27, %csite.hit.341 ], [ %rs4gc.s10.relocated535, %csite.fill.342 ], [ %rs4gc.s10.relocated542, %csite.plain.343 ]
  %r1665 = phi double [ %r1657, %csite.hit.341 ], [ %r1661531, %csite.fill.342 ], [ %r1664538, %csite.plain.343 ]
  %r1666 = bitcast double %r1665 to i64
  %rs4gc.s24 = inttoptr i64 %r1666 to ptr addrspace(1)
  %r1667.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r1667 = call i64 asm "", "=r,0"(i64 %r1667.rs4i) #7
  %r1668 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1669 = icmp ne i32 %r1668, 0
  br i1 %r1669, label %shadow.root.barrier.345, label %shadow.root.barrier.done.346

shadow.root.barrier.345:                          ; preds = %csite.merge.344
  call void @js_write_barrier_root_nanbox(i64 %r1667) #7
  br label %shadow.root.barrier.done.346

shadow.root.barrier.done.346:                     ; preds = %shadow.root.barrier.345, %csite.merge.344
  %r1671 = icmp eq ptr %r5.6, null
  br i1 %r1671, label %arena_state.init.347, label %arena_state.ready.348

arena_state.init.347:                             ; preds = %shadow.root.barrier.done.346
  %r1672 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r1673 = icmp ne i64 %r1672, -1
  br i1 %r1673, label %arena_state.hot_tls.tsd.349, label %arena_state.hot_tls.slow.351

arena_state.ready.348:                            ; preds = %arena_state.hot_tls.resolved.353, %shadow.root.barrier.done.346
  %.01160 = phi ptr addrspace(1) [ %.11161, %arena_state.hot_tls.resolved.353 ], [ %rs4gc.s24, %shadow.root.barrier.done.346 ]
  %.11153 = phi ptr addrspace(1) [ %.21154, %arena_state.hot_tls.resolved.353 ], [ %.01152, %shadow.root.barrier.done.346 ]
  %.11147 = phi ptr addrspace(1) [ %.21148, %arena_state.hot_tls.resolved.353 ], [ %.01146, %shadow.root.barrier.done.346 ]
  %.21125 = phi ptr addrspace(1) [ %.31126, %arena_state.hot_tls.resolved.353 ], [ %.11124, %shadow.root.barrier.done.346 ]
  %.21109 = phi ptr addrspace(1) [ %.31110, %arena_state.hot_tls.resolved.353 ], [ %.11108, %shadow.root.barrier.done.346 ]
  %.121100 = phi ptr addrspace(1) [ %.131101, %arena_state.hot_tls.resolved.353 ], [ %.111099, %shadow.root.barrier.done.346 ]
  %.29957 = phi ptr addrspace(1) [ %.30958, %arena_state.hot_tls.resolved.353 ], [ %.28956, %shadow.root.barrier.done.346 ]
  %.29 = phi ptr addrspace(1) [ %.30, %arena_state.hot_tls.resolved.353 ], [ %.28, %shadow.root.barrier.done.346 ]
  %r5.7 = phi ptr [ %r5.8, %arena_state.hot_tls.resolved.353 ], [ %r5.6, %shadow.root.barrier.done.346 ]
  %r1687 = phi ptr [ %r5.6, %shadow.root.barrier.done.346 ], [ %r1686, %arena_state.hot_tls.resolved.353 ]
  %r1688 = getelementptr i8, ptr %r1687, i64 8
  %r1689 = load i64, ptr %r1688, align 8
  %r1690 = add i64 %r1689, 40
  %r1691 = getelementptr i8, ptr %r1687, i64 16
  %r1692 = load i64, ptr %r1691, align 8
  %r1693 = icmp ule i64 %r1690, %r1692
  br i1 %r1693, label %alloc.fast.354, label %alloc.slow.355

arena_state.hot_tls.tsd.349:                      ; preds = %arena_state.init.347
  %r1674 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #7
  %r1675 = and i64 %r1674, -8
  %r1676 = shl i64 %r1672, 3
  %r1677 = add i64 %r1675, %r1676
  %r1678 = inttoptr i64 %r1677 to ptr
  %r1679 = load ptr, ptr %r1678, align 8
  %r1680 = icmp ne ptr %r1679, null
  br i1 %r1680, label %arena_state.hot_tls.fast.350, label %arena_state.hot_tls.slow.351

arena_state.hot_tls.fast.350:                     ; preds = %arena_state.hot_tls.tsd.349
  %r1681 = getelementptr i8, ptr %r1679, i64 8
  %r1682 = load ptr, ptr %r1681, align 8
  %r1683 = load ptr, ptr %r1682, align 8
  %r1684 = icmp ne ptr %r1683, null
  br i1 %r1684, label %arena_state.hot_tls.ready.352, label %arena_state.hot_tls.slow.351

arena_state.hot_tls.slow.351:                     ; preds = %arena_state.hot_tls.fast.350, %arena_state.hot_tls.tsd.349, %arena_state.init.347
  %statepoint_token546 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111099, ptr addrspace(1) %.28956, ptr addrspace(1) %.11108, ptr addrspace(1) %.28, ptr addrspace(1) %.01146, ptr addrspace(1) %.01152, ptr addrspace(1) %rs4gc.s24, ptr addrspace(1) %.11124) ]
  %r1685547 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token546)
  %rs4gc.s16.relocated548 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token546, i32 0, i32 0) ; (%.111099, %.111099)
  %r57.0.relocated549 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token546, i32 1, i32 1) ; (%.28956, %.28956)
  %r48.1.base.relocated550 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token546, i32 2, i32 2) ; (%.11108, %.11108)
  %rs4gc.s10.relocated551 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token546, i32 3, i32 3) ; (%.28, %.28)
  %r1628.0.base.relocated552 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token546, i32 4, i32 4) ; (%.01146, %.01146)
  %r1628.0.relocated553 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token546, i32 4, i32 5) ; (%.01146, %.01152)
  %rs4gc.s24.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token546, i32 6, i32 6) ; (%rs4gc.s24, %rs4gc.s24)
  %r48.1.relocated554 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token546, i32 2, i32 7) ; (%.11108, %.11124)
  br label %arena_state.hot_tls.resolved.353

arena_state.hot_tls.ready.352:                    ; preds = %arena_state.hot_tls.fast.350
  br label %arena_state.hot_tls.resolved.353

arena_state.hot_tls.resolved.353:                 ; preds = %arena_state.hot_tls.ready.352, %arena_state.hot_tls.slow.351
  %.11161 = phi ptr addrspace(1) [ %rs4gc.s24, %arena_state.hot_tls.ready.352 ], [ %rs4gc.s24.relocated, %arena_state.hot_tls.slow.351 ]
  %.21154 = phi ptr addrspace(1) [ %.01152, %arena_state.hot_tls.ready.352 ], [ %r1628.0.relocated553, %arena_state.hot_tls.slow.351 ]
  %.21148 = phi ptr addrspace(1) [ %.01146, %arena_state.hot_tls.ready.352 ], [ %r1628.0.base.relocated552, %arena_state.hot_tls.slow.351 ]
  %.31126 = phi ptr addrspace(1) [ %.11124, %arena_state.hot_tls.ready.352 ], [ %r48.1.relocated554, %arena_state.hot_tls.slow.351 ]
  %.31110 = phi ptr addrspace(1) [ %.11108, %arena_state.hot_tls.ready.352 ], [ %r48.1.base.relocated550, %arena_state.hot_tls.slow.351 ]
  %.131101 = phi ptr addrspace(1) [ %.111099, %arena_state.hot_tls.ready.352 ], [ %rs4gc.s16.relocated548, %arena_state.hot_tls.slow.351 ]
  %.30958 = phi ptr addrspace(1) [ %.28956, %arena_state.hot_tls.ready.352 ], [ %r57.0.relocated549, %arena_state.hot_tls.slow.351 ]
  %.30 = phi ptr addrspace(1) [ %.28, %arena_state.hot_tls.ready.352 ], [ %rs4gc.s10.relocated551, %arena_state.hot_tls.slow.351 ]
  %r5.8 = phi ptr [ %r1682, %arena_state.hot_tls.ready.352 ], [ %r1685547, %arena_state.hot_tls.slow.351 ]
  %r1686 = phi ptr [ %r1682, %arena_state.hot_tls.ready.352 ], [ %r1685547, %arena_state.hot_tls.slow.351 ]
  br label %arena_state.ready.348

alloc.fast.354:                                   ; preds = %arena_state.ready.348
  store i64 %r1690, ptr %r1688, align 8
  %r1694 = load ptr, ptr %r1687, align 8
  %r1695 = getelementptr i8, ptr %r1694, i64 %r1689
  br label %alloc.merge.356

alloc.slow.355:                                   ; preds = %arena_state.ready.348
  %statepoint_token555 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r1687, i64 40, i64 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.121100, ptr addrspace(1) %.29957, ptr addrspace(1) %.21109, ptr addrspace(1) %.29, ptr addrspace(1) %.11147, ptr addrspace(1) %.11153, ptr addrspace(1) %.01160, ptr addrspace(1) %.21125) ]
  %r1696556 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token555)
  %rs4gc.s16.relocated557 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 0, i32 0) ; (%.121100, %.121100)
  %r57.0.relocated558 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 1, i32 1) ; (%.29957, %.29957)
  %r48.1.base.relocated559 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 2, i32 2) ; (%.21109, %.21109)
  %rs4gc.s10.relocated560 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 3, i32 3) ; (%.29, %.29)
  %r1628.0.base.relocated561 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 4, i32 4) ; (%.11147, %.11147)
  %r1628.0.relocated562 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 4, i32 5) ; (%.11147, %.11153)
  %rs4gc.s24.relocated563 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 6, i32 6) ; (%.01160, %.01160)
  %r48.1.relocated564 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token555, i32 2, i32 7) ; (%.21109, %.21125)
  br label %alloc.merge.356

alloc.merge.356:                                  ; preds = %alloc.slow.355, %alloc.fast.354
  %.21162 = phi ptr addrspace(1) [ %.01160, %alloc.fast.354 ], [ %rs4gc.s24.relocated563, %alloc.slow.355 ]
  %.31155 = phi ptr addrspace(1) [ %.11153, %alloc.fast.354 ], [ %r1628.0.relocated562, %alloc.slow.355 ]
  %.31149 = phi ptr addrspace(1) [ %.11147, %alloc.fast.354 ], [ %r1628.0.base.relocated561, %alloc.slow.355 ]
  %.41127 = phi ptr addrspace(1) [ %.21125, %alloc.fast.354 ], [ %r48.1.relocated564, %alloc.slow.355 ]
  %.41111 = phi ptr addrspace(1) [ %.21109, %alloc.fast.354 ], [ %r48.1.base.relocated559, %alloc.slow.355 ]
  %.141102 = phi ptr addrspace(1) [ %.121100, %alloc.fast.354 ], [ %rs4gc.s16.relocated557, %alloc.slow.355 ]
  %.31959 = phi ptr addrspace(1) [ %.29957, %alloc.fast.354 ], [ %r57.0.relocated558, %alloc.slow.355 ]
  %.31 = phi ptr addrspace(1) [ %.29, %alloc.fast.354 ], [ %rs4gc.s10.relocated560, %alloc.slow.355 ]
  %r1697 = phi ptr [ %r1695, %alloc.fast.354 ], [ %r1696556, %alloc.slow.355 ]
  store <2 x i64> %r1699, ptr %r1697, align 8
  %r1701 = getelementptr i8, ptr %r1697, i64 16
  store i64 0, ptr %r1701, align 8
  %r1702 = getelementptr i8, ptr %r1697, i64 24
  store i64 9222246136947933185, ptr %r1702, align 8
  %r1703 = getelementptr i8, ptr %r1697, i64 32
  store i64 9222246136947933185, ptr %r1703, align 8
  %r1704 = getelementptr i8, ptr %r1697, i64 8
  %r1705 = ptrtoint ptr %r1704 to i64
  %r1706 = load atomic i32, ptr @PERRY_PER_OBJECT_LAYOUTS_ANY monotonic, align 4
  %r1707 = icmp ne i32 %r1706, 0
  br i1 %r1707, label %layout_forget.young.357, label %layout_forget.done.360

layout_forget.young.357:                          ; preds = %alloc.merge.356
  %r1708 = load atomic i32, ptr @PERRY_YOUNG_LAYOUT_RECORDS monotonic, align 4
  %r1709 = icmp ne i32 %r1708, 0
  br i1 %r1709, label %layout_forget.sketch.358, label %layout_forget.done.360

layout_forget.sketch.358:                         ; preds = %layout_forget.young.357
  %r1710 = mul i64 %r1705, -7046029254386353131
  %r1711 = lshr i64 %r1710, 52
  %r1712 = lshr i64 %r1711, 6
  %r1713 = and i64 %r1711, 63
  %r1714 = shl nuw i64 1, %r1713
  %r1715 = getelementptr i64, ptr @PERRY_LAYOUT_ADDR_FILTER, i64 %r1712
  %r1716 = load atomic i64, ptr %r1715 monotonic, align 8
  %r1717 = and i64 %r1716, %r1714
  %r1718 = icmp ne i64 %r1717, 0
  br i1 %r1718, label %layout_forget.armed.359, label %layout_forget.done.360

layout_forget.armed.359:                          ; preds = %layout_forget.sketch.358
  call void @js_gc_forget_object_layout(i64 %r1705) #7
  br label %layout_forget.done.360

layout_forget.done.360:                           ; preds = %layout_forget.armed.359, %layout_forget.sketch.358, %layout_forget.young.357, %alloc.merge.356
  %rs4gc.s25 = inttoptr i64 %r1705 to ptr addrspace(1)
  %r1719.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r1719 = call i64 asm "", "=r,0"(i64 %r1719.rs4i) #7
  %r1720 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1721 = icmp ne i32 %r1720, 0
  br i1 %r1721, label %shadow.root.barrier.361, label %shadow.root.barrier.done.362

shadow.root.barrier.361:                          ; preds = %layout_forget.done.360
  call void @js_write_barrier_root_nanbox(i64 %r1719) #7
  br label %shadow.root.barrier.done.362

shadow.root.barrier.done.362:                     ; preds = %shadow.root.barrier.361, %layout_forget.done.360
  %r1722 = or i64 %r1705, 9222527611924643840
  %r1723 = bitcast i64 %r1722 to double
  %r1724.rs4i = ptrtoint ptr addrspace(1) %.21162 to i64
  %r1724 = call i64 asm "", "=r,0"(i64 %r1724.rs4i) #7
  %r1725 = bitcast i64 %r1724 to double
  %r1726 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r1727 = icmp eq i8 %r1726, 0
  %r1728 = bitcast double %r1637.0 to i64
  %r1729 = and i64 %r1728, 9218868437227405312
  %r1730 = icmp ne i64 %r1729, 9218868437227405312
  %r1731 = and i1 %r1727, %r1730
  br i1 %r1731, label %ctor_prologue.fast.363, label %ctor_prologue.slow.364

ctor_prologue.fast.363:                           ; preds = %shadow.root.barrier.done.362
  %r1732 = inttoptr i64 %r1705 to ptr
  %r1733 = getelementptr i8, ptr %r1732, i64 16
  %r1734 = bitcast double %r1723 to i64
  %r1735 = getelementptr double, ptr %r1733, i64 0
  store double %r1637.0, ptr %r1735, align 8
  %r1736 = ptrtoint ptr %r1735 to i64
  %r1737 = bitcast double %r1637.0 to i64
  %r1738 = getelementptr double, ptr %r1733, i64 1
  store double %r1725, ptr %r1738, align 8
  %r1739 = ptrtoint ptr %r1738 to i64
  %r1740 = bitcast double %r1725 to i64
  %r1741 = lshr i64 %r1740, 48
  %r1742 = icmp eq i64 %r1741, 0
  %r1743 = icmp uge i64 %r1740, 4096
  %r1744 = and i1 %r1742, %r1743
  %r1745 = icmp eq i64 %r1741, 32765
  %r1746 = icmp eq i64 %r1741, 32767
  %r1747 = icmp eq i64 %r1741, 32762
  %r1748 = or i1 %r1745, %r1746
  %r1749 = or i1 %r1748, %r1747
  %r1750 = or i1 %r1749, %r1744
  br i1 %r1750, label %ctor_prologue.barrier.maybe.366, label %ctor_prologue.barrier.done.368

ctor_prologue.slow.364:                           ; preds = %shadow.root.barrier.done.362
  %statepoint_token565 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double)) @test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38_constructor, i32 3, i32 0, double %r1723, double %r1637.0, double %r1725, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.141102, ptr addrspace(1) %.31959, ptr addrspace(1) %.41111, ptr addrspace(1) %.31, ptr addrspace(1) %.31149, ptr addrspace(1) %.31155, ptr addrspace(1) %rs4gc.s25, ptr addrspace(1) %.41127) ]
  %r1759566 = call double @llvm.experimental.gc.result.f64(token %statepoint_token565)
  %rs4gc.s16.relocated567 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token565, i32 0, i32 0) ; (%.141102, %.141102)
  %r57.0.relocated568 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token565, i32 1, i32 1) ; (%.31959, %.31959)
  %r48.1.base.relocated569 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token565, i32 2, i32 2) ; (%.41111, %.41111)
  %rs4gc.s10.relocated570 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token565, i32 3, i32 3) ; (%.31, %.31)
  %r1628.0.base.relocated571 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token565, i32 4, i32 4) ; (%.31149, %.31149)
  %r1628.0.relocated572 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token565, i32 4, i32 5) ; (%.31149, %.31155)
  %rs4gc.s25.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token565, i32 6, i32 6) ; (%rs4gc.s25, %rs4gc.s25)
  %r48.1.relocated573 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token565, i32 2, i32 7) ; (%.41111, %.41127)
  br label %ctor_prologue.merge.365

ctor_prologue.merge.365:                          ; preds = %ctor_prologue.barrier.done.368, %ctor_prologue.slow.364
  %.01163 = phi ptr addrspace(1) [ %rs4gc.s25, %ctor_prologue.barrier.done.368 ], [ %rs4gc.s25.relocated, %ctor_prologue.slow.364 ]
  %.41156 = phi ptr addrspace(1) [ %.31155, %ctor_prologue.barrier.done.368 ], [ %r1628.0.relocated572, %ctor_prologue.slow.364 ]
  %.41150 = phi ptr addrspace(1) [ %.31149, %ctor_prologue.barrier.done.368 ], [ %r1628.0.base.relocated571, %ctor_prologue.slow.364 ]
  %.51128 = phi ptr addrspace(1) [ %.41127, %ctor_prologue.barrier.done.368 ], [ %r48.1.relocated573, %ctor_prologue.slow.364 ]
  %.51112 = phi ptr addrspace(1) [ %.41111, %ctor_prologue.barrier.done.368 ], [ %r48.1.base.relocated569, %ctor_prologue.slow.364 ]
  %.151103 = phi ptr addrspace(1) [ %.141102, %ctor_prologue.barrier.done.368 ], [ %rs4gc.s16.relocated567, %ctor_prologue.slow.364 ]
  %.32960 = phi ptr addrspace(1) [ %.31959, %ctor_prologue.barrier.done.368 ], [ %r57.0.relocated568, %ctor_prologue.slow.364 ]
  %.32 = phi ptr addrspace(1) [ %.31, %ctor_prologue.barrier.done.368 ], [ %rs4gc.s10.relocated570, %ctor_prologue.slow.364 ]
  %r1760 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.368 ], [ %r1759566, %ctor_prologue.slow.364 ]
  %r1761.rs4i = ptrtoint ptr addrspace(1) %.01163 to i64
  %r1761 = call i64 asm "", "=r,0"(i64 %r1761.rs4i) #7
  %r1762 = or i64 %r1761, 9222527611924643840
  %r1763 = bitcast i64 %r1762 to double
  %r1764 = bitcast double %r1760 to i64
  %r1765 = icmp eq i64 %r1764, 9222246136947933185
  br i1 %r1765, label %ctor_ret.merge.370, label %ctor_ret.override.369

ctor_prologue.barrier.maybe.366:                  ; preds = %ctor_prologue.fast.363
  %r1751 = sub i64 %r1705, 7
  %r1752 = inttoptr i64 %r1751 to ptr
  %r1753 = load i8, ptr %r1752, align 1
  %r1754 = and i8 %r1753, 32
  %r1755 = icmp ne i8 %r1754, 0
  %r1756 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1757 = icmp ne i32 %r1756, 0
  %r1758 = or i1 %r1755, %r1757
  br i1 %r1758, label %ctor_prologue.barrier.367, label %ctor_prologue.barrier.done.368

ctor_prologue.barrier.367:                        ; preds = %ctor_prologue.barrier.maybe.366
  call void @js_write_barrier_slot_validated_parent(i64 %r1705, i64 %r1739, i64 %r1740) #7
  br label %ctor_prologue.barrier.done.368

ctor_prologue.barrier.done.368:                   ; preds = %ctor_prologue.barrier.367, %ctor_prologue.barrier.maybe.366, %ctor_prologue.fast.363
  br label %ctor_prologue.merge.365

ctor_ret.override.369:                            ; preds = %ctor_prologue.merge.365
  %statepoint_token574 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r1763, double %r1760, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.151103, ptr addrspace(1) %.32960, ptr addrspace(1) %.51112, ptr addrspace(1) %.32, ptr addrspace(1) %.41150, ptr addrspace(1) %.41156, ptr addrspace(1) %.51128) ]
  %r1766575 = call double @llvm.experimental.gc.result.f64(token %statepoint_token574)
  %rs4gc.s16.relocated576 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token574, i32 0, i32 0) ; (%.151103, %.151103)
  %r57.0.relocated577 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token574, i32 1, i32 1) ; (%.32960, %.32960)
  %r48.1.base.relocated578 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token574, i32 2, i32 2) ; (%.51112, %.51112)
  %rs4gc.s10.relocated579 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token574, i32 3, i32 3) ; (%.32, %.32)
  %r1628.0.base.relocated580 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token574, i32 4, i32 4) ; (%.41150, %.41150)
  %r1628.0.relocated581 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token574, i32 4, i32 5) ; (%.41150, %.41156)
  %r48.1.relocated582 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token574, i32 2, i32 6) ; (%.51112, %.51128)
  br label %ctor_ret.merge.370

ctor_ret.merge.370:                               ; preds = %ctor_ret.override.369, %ctor_prologue.merge.365
  %.51157 = phi ptr addrspace(1) [ %.41156, %ctor_prologue.merge.365 ], [ %r1628.0.relocated581, %ctor_ret.override.369 ]
  %.51151 = phi ptr addrspace(1) [ %.41150, %ctor_prologue.merge.365 ], [ %r1628.0.base.relocated580, %ctor_ret.override.369 ]
  %.61129 = phi ptr addrspace(1) [ %.51128, %ctor_prologue.merge.365 ], [ %r48.1.relocated582, %ctor_ret.override.369 ]
  %.61113 = phi ptr addrspace(1) [ %.51112, %ctor_prologue.merge.365 ], [ %r48.1.base.relocated578, %ctor_ret.override.369 ]
  %.161104 = phi ptr addrspace(1) [ %.151103, %ctor_prologue.merge.365 ], [ %rs4gc.s16.relocated576, %ctor_ret.override.369 ]
  %.33961 = phi ptr addrspace(1) [ %.32960, %ctor_prologue.merge.365 ], [ %r57.0.relocated577, %ctor_ret.override.369 ]
  %.33 = phi ptr addrspace(1) [ %.32, %ctor_prologue.merge.365 ], [ %rs4gc.s10.relocated579, %ctor_ret.override.369 ]
  %r1767 = phi double [ %r1763, %ctor_prologue.merge.365 ], [ %r1766575, %ctor_ret.override.369 ]
  %r1768 = bitcast double %r1767 to i64
  %r1769.rs4i = ptrtoint ptr addrspace(1) %.51157 to i64
  %r1769.rs4o = call i64 asm "", "=r,0"(i64 %r1769.rs4i) #7
  %r1769 = bitcast i64 %r1769.rs4o to double
  %r1770 = bitcast double %r1769 to i64
  %r1771 = and i64 %r1770, 281474976710655
  %r1772 = sub nsw i64 %r1771, 8
  %r1773 = inttoptr i64 %r1772 to ptr
  %r1774 = load i8, ptr %r1773, align 1
  %r1775 = icmp ne i8 %r1774, 1
  %r1776 = sub nsw i64 %r1771, 7
  %r1777 = inttoptr i64 %r1776 to ptr
  %r1778 = load i8, ptr %r1777, align 1
  %r1779 = and i8 %r1778, -128
  %r1780 = icmp ne i8 %r1779, 0
  %r1781 = or i1 %r1775, %r1780
  br i1 %r1780, label %apush.fwd.371, label %apush.elements.372

apush.fwd.371:                                    ; preds = %apush.elements.check.373, %ctor_ret.merge.370
  %statepoint_token583 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1771, double %r1767, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.161104, ptr addrspace(1) %.33961, ptr addrspace(1) %.61113, ptr addrspace(1) %.33, ptr addrspace(1) %.61129) ]
  %r1808584 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token583)
  %rs4gc.s16.relocated585 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token583, i32 0, i32 0) ; (%.161104, %.161104)
  %r57.0.relocated586 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token583, i32 1, i32 1) ; (%.33961, %.33961)
  %r48.1.base.relocated587 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token583, i32 2, i32 2) ; (%.61113, %.61113)
  %rs4gc.s10.relocated588 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token583, i32 3, i32 3) ; (%.33, %.33)
  %r48.1.relocated589 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token583, i32 2, i32 4) ; (%.61113, %.61129)
  %r1809 = or i64 %r1808584, 9222527611924643840
  %r1810 = bitcast i64 %r1809 to double
  %rs4gc.b26 = bitcast double %r1810 to i64
  %rs4gc.s26 = inttoptr i64 %rs4gc.b26 to ptr addrspace(1)
  br label %apush.merge.377

apush.elements.372:                               ; preds = %ctor_ret.merge.370
  %r1783 = add nuw nsw i64 %r1771, 8
  %r1784 = inttoptr i64 %r1783 to ptr
  %r1785 = load i64, ptr %r1784, align 8
  %r1786 = icmp ne i64 %r1785, 0
  %r1787 = icmp eq i8 %r1774, 2
  %r1788 = and i1 %r1787, %r1786
  %r1789 = select i1 %r1788, i64 %r1785, i64 %r1771
  %r1790 = inttoptr i64 %r1789 to ptr
  %r1791 = getelementptr i64, ptr %r1790, i64 12
  %r1792 = load i64, ptr %r1791, align 8
  %r1793 = icmp ne i64 %r1792, 0
  %r1794 = and i1 %r1788, %r1793
  %r1795 = select i1 %r1794, i64 %r1792, i64 %r1771
  %r1782 = icmp eq i8 %r1774, 1
  br i1 %r1782, label %apush.nofwd.374, label %apush.elements.check.373

apush.elements.check.373:                         ; preds = %apush.elements.372
  %r1796 = icmp ne i64 %r1795, 0
  %r1797 = sub i64 %r1795, 8
  %r1798 = inttoptr i64 %r1797 to ptr
  %r1799 = load i8, ptr %r1798, align 1
  %r1800 = icmp eq i8 %r1799, 1
  %r1801 = sub i64 %r1795, 7
  %r1802 = inttoptr i64 %r1801 to ptr
  %r1803 = load i8, ptr %r1802, align 1
  %r1804 = and i8 %r1803, -128
  %r1805 = icmp eq i8 %r1804, 0
  %r1806 = and i1 %r1796, %r1800
  %r1807 = and i1 %r1806, %r1805
  br i1 %r1807, label %apush.nofwd.374, label %apush.fwd.371

apush.nofwd.374:                                  ; preds = %apush.elements.check.373, %apush.elements.372
  %r1811 = phi i64 [ %r1771, %apush.elements.372 ], [ %r1795, %apush.elements.check.373 ]
  %r1812 = sub i64 %r1811, 6
  %r1813 = inttoptr i64 %r1812 to ptr
  %r1814 = load i16, ptr %r1813, align 2
  %r1815 = and i16 %r1814, -2937
  %r1816 = icmp eq i16 %r1815, -24576
  %r1817 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1818 = icmp eq i8 %r1817, 0
  %r1819 = and i1 %r1816, %r1818
  %r1820 = icmp ult i64 %r1811, 4096
  %r1821 = inttoptr i64 %r1811 to ptr
  %r1822 = select i1 %r1820, ptr @perry_null_guard_zero_test_json_cached_template_borrow_ts, ptr %r1821
  %r1823 = load i32, ptr %r1822, align 4
  %r1824 = add i64 %r1811, 4
  %r1825 = inttoptr i64 %r1824 to ptr
  %r1826 = load i32, ptr %r1825, align 4
  %r1827 = icmp ult i32 %r1823, %r1826
  %r1828 = and i1 %r1827, %r1819
  br i1 %r1828, label %apush.inbounds.375, label %apush.realloc.376

apush.inbounds.375:                               ; preds = %apush.nofwd.374
  %r1829 = icmp ult i64 %r1811, 4096
  %r1830 = inttoptr i64 %r1811 to ptr
  %r1831 = select i1 %r1829, ptr @perry_null_guard_zero_test_json_cached_template_borrow_ts, ptr %r1830
  %r1832 = load i32, ptr %r1831, align 4
  %r1833 = zext i32 %r1832 to i64
  %r1834 = shl nuw nsw i64 %r1833, 3
  %r1835 = add nuw nsw i64 %r1834, 8
  %r1836 = add i64 %r1811, %r1835
  %r1837 = inttoptr i64 %r1836 to ptr
  store double %r1767, ptr %r1837, align 8
  call void @js_string_addref_if_heap_string(double %r1767) #7
  %r1838 = bitcast double %r1767 to i64
  %r1839 = sub i64 %r1811, 7
  %r1840 = inttoptr i64 %r1839 to ptr
  %r1841 = load i8, ptr %r1840, align 1
  %r1842 = and i8 %r1841, 32
  %r1843 = icmp ne i8 %r1842, 0
  %r1844 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1845 = icmp ne i32 %r1844, 0
  %r1846 = or i1 %r1843, %r1845
  br i1 %r1846, label %apush.barrier.378, label %apush.barrier.done.379

apush.realloc.376:                                ; preds = %apush.nofwd.374
  %statepoint_token590 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r1771, double %r1767, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.161104, ptr addrspace(1) %.33961, ptr addrspace(1) %.61113, ptr addrspace(1) %.33, ptr addrspace(1) %.61129) ]
  %r1849591 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token590)
  %rs4gc.s16.relocated592 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token590, i32 0, i32 0) ; (%.161104, %.161104)
  %r57.0.relocated593 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token590, i32 1, i32 1) ; (%.33961, %.33961)
  %r48.1.base.relocated594 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token590, i32 2, i32 2) ; (%.61113, %.61113)
  %rs4gc.s10.relocated595 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token590, i32 3, i32 3) ; (%.33, %.33)
  %r48.1.relocated596 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token590, i32 2, i32 4) ; (%.61113, %.61129)
  %r1850 = or i64 %r1849591, 9222527611924643840
  %r1851 = bitcast i64 %r1850 to double
  %rs4gc.b27 = bitcast double %r1851 to i64
  %rs4gc.s27 = inttoptr i64 %rs4gc.b27 to ptr addrspace(1)
  br label %apush.merge.377

apush.merge.377:                                  ; preds = %apush.barrier.done.379, %apush.realloc.376, %apush.fwd.371
  %.71130 = phi ptr addrspace(1) [ %r48.1.relocated589, %apush.fwd.371 ], [ %.61129, %apush.barrier.done.379 ], [ %r48.1.relocated596, %apush.realloc.376 ]
  %.71114 = phi ptr addrspace(1) [ %r48.1.base.relocated587, %apush.fwd.371 ], [ %.61113, %apush.barrier.done.379 ], [ %r48.1.base.relocated594, %apush.realloc.376 ]
  %.171105 = phi ptr addrspace(1) [ %rs4gc.s16.relocated585, %apush.fwd.371 ], [ %.161104, %apush.barrier.done.379 ], [ %rs4gc.s16.relocated592, %apush.realloc.376 ]
  %.34962 = phi ptr addrspace(1) [ %r57.0.relocated586, %apush.fwd.371 ], [ %.33961, %apush.barrier.done.379 ], [ %r57.0.relocated593, %apush.realloc.376 ]
  %.34 = phi ptr addrspace(1) [ %rs4gc.s10.relocated588, %apush.fwd.371 ], [ %.33, %apush.barrier.done.379 ], [ %rs4gc.s10.relocated595, %apush.realloc.376 ]
  %r1628.1.base = phi ptr addrspace(1) [ %rs4gc.s26, %apush.fwd.371 ], [ %.51151, %apush.barrier.done.379 ], [ %rs4gc.s27, %apush.realloc.376 ], !is_base_value !0
  %r1628.1 = phi ptr addrspace(1) [ %rs4gc.s26, %apush.fwd.371 ], [ %.51157, %apush.barrier.done.379 ], [ %rs4gc.s27, %apush.realloc.376 ]
  %r1852 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r1853 = icmp ne i32 %r1852, 0
  br i1 %r1853, label %gcpoll.380, label %gcpoll.done.381

apush.barrier.378:                                ; preds = %apush.inbounds.375
  call void @js_write_barrier_slot_validated_parent(i64 %r1811, i64 %r1836, i64 %r1838) #7
  br label %apush.barrier.done.379

apush.barrier.done.379:                           ; preds = %apush.barrier.378, %apush.inbounds.375
  %r1847 = add i32 %r1832, 1
  %r1848 = inttoptr i64 %r1811 to ptr
  store i32 %r1847, ptr %r1848, align 4
  br label %apush.merge.377

gcpoll.380:                                       ; preds = %apush.merge.377
  %statepoint_token597 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r1628.1.base, ptr addrspace(1) %r1628.1, ptr addrspace(1) %.171105, ptr addrspace(1) %.34962, ptr addrspace(1) %.71114, ptr addrspace(1) %.34, ptr addrspace(1) %.71130) ]
  %r1628.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token597, i32 0, i32 0) ; (%r1628.1.base, %r1628.1.base)
  %r1628.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token597, i32 0, i32 1) ; (%r1628.1.base, %r1628.1)
  %rs4gc.s16.relocated598 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token597, i32 2, i32 2) ; (%.171105, %.171105)
  %r57.0.relocated599 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token597, i32 3, i32 3) ; (%.34962, %.34962)
  %r48.1.base.relocated600 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token597, i32 4, i32 4) ; (%.71114, %.71114)
  %rs4gc.s10.relocated601 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token597, i32 5, i32 5) ; (%.34, %.34)
  %r48.1.relocated602 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token597, i32 4, i32 6) ; (%.71114, %.71130)
  br label %gcpoll.done.381

gcpoll.done.381:                                  ; preds = %gcpoll.380, %apush.merge.377
  %.01165 = phi ptr addrspace(1) [ %r1628.1.relocated, %gcpoll.380 ], [ %r1628.1, %apush.merge.377 ]
  %.01164 = phi ptr addrspace(1) [ %r1628.1.base.relocated, %gcpoll.380 ], [ %r1628.1.base, %apush.merge.377 ]
  %.81131 = phi ptr addrspace(1) [ %r48.1.relocated602, %gcpoll.380 ], [ %.71130, %apush.merge.377 ]
  %.81115 = phi ptr addrspace(1) [ %r48.1.base.relocated600, %gcpoll.380 ], [ %.71114, %apush.merge.377 ]
  %.181106 = phi ptr addrspace(1) [ %rs4gc.s16.relocated598, %gcpoll.380 ], [ %.171105, %apush.merge.377 ]
  %.35963 = phi ptr addrspace(1) [ %r57.0.relocated599, %gcpoll.380 ], [ %.34962, %apush.merge.377 ]
  %.35 = phi ptr addrspace(1) [ %rs4gc.s10.relocated601, %gcpoll.380 ], [ %.34, %apush.merge.377 ]
  br label %for.update.338

shadow.root.barrier.382:                          ; preds = %for.exit.339
  call void @js_write_barrier_root_nanbox(i64 %r1858) #7
  br label %shadow.root.barrier.done.383

shadow.root.barrier.done.383:                     ; preds = %shadow.root.barrier.382, %for.exit.339
  %r1861.rs4i = ptrtoint ptr addrspace(1) %.101098 to i64
  %r1861.rs4o = call i64 asm "", "=r,0"(i64 %r1861.rs4i) #7
  %r1861 = bitcast i64 %r1861.rs4o to double
  %r1862 = bitcast double %r1861 to i64
  %r1863 = and i64 %r1862, 281474976710655
  %r1864 = lshr i64 %r1862, 48
  %r1865 = and i64 %r1864, 65533
  %r1866 = icmp eq i64 %r1865, 32765
  br i1 %r1866, label %pget.recv_ok.385, label %pget.recv_other.389

pget.recv_sso.384:                                ; preds = %pget.recv_other.389
  %r2004 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r2005 = bitcast double %r2004 to i64
  %r2006 = and i64 %r2005, 281474976710655
  %statepoint_token603 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1862, i64 %r2006, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s23, ptr addrspace(1) %.01107, ptr addrspace(1) %.27, ptr addrspace(1) %r1628.0, ptr addrspace(1) %.01123, ptr addrspace(1) %r1628.0.base) ]
  %r2007604 = call double @llvm.experimental.gc.result.f64(token %statepoint_token603)
  %rs4gc.s23.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token603, i32 0, i32 0) ; (%rs4gc.s23, %rs4gc.s23)
  %r48.1.base.relocated605 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token603, i32 1, i32 1) ; (%.01107, %.01107)
  %rs4gc.s10.relocated606 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token603, i32 2, i32 2) ; (%.27, %.27)
  %r1628.0.relocated607 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token603, i32 5, i32 3) ; (%r1628.0.base, %r1628.0)
  %r48.1.relocated608 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token603, i32 1, i32 4) ; (%.01107, %.01123)
  %r1628.0.base.relocated609 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token603, i32 5, i32 5) ; (%r1628.0.base, %r1628.0.base)
  br label %pget.recv_merge.388

pget.recv_ok.385:                                 ; preds = %shadow.root.barrier.done.383
  %r1873 = icmp ugt i64 %r1863, 1048575
  br i1 %r1873, label %pic.recv_hdr.406, label %pic.miss.cold.403

pget.recv_bad.386:                                ; preds = %pget.check_class_ref.390
  %r1996 = icmp eq i64 %r1862, 9222246136947933185
  %r1997 = icmp eq i64 %r1862, 9222246136947933186
  %r1998 = or i1 %r1996, %r1997
  br i1 %r1998, label %pget.throw_nullish.413, label %pget.recv_undef_return.414

pget.recv_class_ref.387:                          ; preds = %pget.check_class_ref.390
  %r1869 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r1870 = bitcast double %r1869 to i64
  %r1871 = and i64 %r1870, 281474976710655
  %statepoint_token610 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 8988321885632593938, i64 %r1862, i64 %r1871, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s23, ptr addrspace(1) %.01107, ptr addrspace(1) %.27, ptr addrspace(1) %r1628.0, ptr addrspace(1) %.01123, ptr addrspace(1) %r1628.0.base) ]
  %r1872611 = call double @llvm.experimental.gc.result.f64(token %statepoint_token610)
  %rs4gc.s23.relocated612 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token610, i32 0, i32 0) ; (%rs4gc.s23, %rs4gc.s23)
  %r48.1.base.relocated613 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token610, i32 1, i32 1) ; (%.01107, %.01107)
  %rs4gc.s10.relocated614 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token610, i32 2, i32 2) ; (%.27, %.27)
  %r1628.0.relocated615 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token610, i32 5, i32 3) ; (%r1628.0.base, %r1628.0)
  %r48.1.relocated616 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token610, i32 1, i32 4) ; (%.01107, %.01123)
  %r1628.0.base.relocated617 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token610, i32 5, i32 5) ; (%r1628.0.base, %r1628.0.base)
  br label %pget.recv_merge.388

pget.recv_merge.388:                              ; preds = %pget.recv_undef_return.414, %pic.merge.405, %pget.recv_class_ref.387, %pget.recv_sso.384
  %.01166 = phi ptr addrspace(1) [ %.11167, %pic.merge.405 ], [ %rs4gc.s23.relocated, %pget.recv_sso.384 ], [ %rs4gc.s23.relocated612, %pget.recv_class_ref.387 ], [ %rs4gc.s23.relocated637, %pget.recv_undef_return.414 ]
  %.61158 = phi ptr addrspace(1) [ %.71159, %pic.merge.405 ], [ %r1628.0.relocated607, %pget.recv_sso.384 ], [ %r1628.0.relocated615, %pget.recv_class_ref.387 ], [ %r1628.0.relocated640, %pget.recv_undef_return.414 ]
  %.91132 = phi ptr addrspace(1) [ %.101133, %pic.merge.405 ], [ %r48.1.relocated608, %pget.recv_sso.384 ], [ %r48.1.relocated616, %pget.recv_class_ref.387 ], [ %r48.1.relocated641, %pget.recv_undef_return.414 ]
  %.91116 = phi ptr addrspace(1) [ %.101117, %pic.merge.405 ], [ %r48.1.base.relocated605, %pget.recv_sso.384 ], [ %r48.1.base.relocated613, %pget.recv_class_ref.387 ], [ %r48.1.base.relocated638, %pget.recv_undef_return.414 ]
  %.36 = phi ptr addrspace(1) [ %.37, %pic.merge.405 ], [ %rs4gc.s10.relocated606, %pget.recv_sso.384 ], [ %rs4gc.s10.relocated614, %pget.recv_class_ref.387 ], [ %rs4gc.s10.relocated639, %pget.recv_undef_return.414 ]
  %r2008 = phi double [ %r1995, %pic.merge.405 ], [ %r2003636, %pget.recv_undef_return.414 ], [ %r2007604, %pget.recv_sso.384 ], [ %r1872611, %pget.recv_class_ref.387 ]
  %r2009 = bitcast double %r2008 to i64
  %rs4gc.s28 = inttoptr i64 %r2009 to ptr addrspace(1)
  %r2010.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r2010 = call i64 asm "", "=r,0"(i64 %r2010.rs4i) #7
  %r2011 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2012 = icmp ne i32 %r2011, 0
  br i1 %r2012, label %shadow.root.barrier.415, label %shadow.root.barrier.done.416

pget.recv_other.389:                              ; preds = %shadow.root.barrier.done.383
  %r1867 = icmp eq i64 %r1864, 32761
  br i1 %r1867, label %pget.recv_sso.384, label %pget.check_class_ref.390

pget.check_class_ref.390:                         ; preds = %pget.recv_other.389
  %r1868 = icmp eq i64 %r1864, 32766
  br i1 %r1868, label %pget.recv_class_ref.387, label %pget.recv_bad.386

pic.hit.391:                                      ; preds = %pic.token.407
  %r1898 = getelementptr i64, ptr %r1883, i64 1
  %r1899 = load i64, ptr %r1898, align 8
  %r1900 = and i64 %r1899, 1073741824
  %r1901 = icmp ne i64 %r1900, 0
  br i1 %r1901, label %pic.hit.overflow.408, label %pic.hit.inline.409

pic.hit.live.392:                                 ; preds = %pic.hit.inline.409
  br label %pic.merge.405

pic.prefix.guard.393:                             ; preds = %pic.token.407
  %r1914 = getelementptr i64, ptr %r1883, i64 2
  %r1915 = load i64, ptr %r1914, align 8
  %r1916 = icmp ne i64 %r1915, 0
  br i1 %r1916, label %pic.prefix.meta.394, label %pic.miss.402

pic.prefix.meta.394:                              ; preds = %pic.prefix.guard.393
  %r1917 = add nuw nsw i64 %r1863, 8
  %r1918 = inttoptr i64 %r1917 to ptr
  %r1919 = load i64, ptr %r1918, align 8
  %r1920 = icmp ne i64 %r1919, 0
  br i1 %r1920, label %pic.prefix.token.395, label %pic.miss.402

pic.prefix.token.395:                             ; preds = %pic.prefix.meta.394
  %r1921 = inttoptr i64 %r1919 to ptr
  %r1922 = getelementptr i64, ptr %r1921, i64 6
  %r1923 = load i64, ptr %r1922, align 8
  %r1924 = icmp eq i64 %r1923, %r1915
  br i1 %r1924, label %pic.prefix.hit.396, label %pic.miss.402

pic.prefix.hit.396:                               ; preds = %pic.prefix.token.395
  %r1925 = getelementptr i64, ptr %r1883, i64 1
  %r1926 = load i64, ptr %r1925, align 8
  %r1927 = shl i64 %r1926, 3
  %r1928 = add nuw nsw i64 %r1863, 16
  %r1929 = add i64 %r1928, %r1927
  %r1930 = inttoptr i64 %r1929 to ptr
  %r1931 = load double, ptr %r1930, align 8
  br label %pic.merge.405

pic.desc.classify.397:                            ; preds = %pic.recv_hdr.406
  %r1887 = and i1 %r1877, %r1884
  br i1 %r1887, label %pic.desc.prefix.guard.398, label %pic.miss.cold.403

pic.desc.prefix.guard.398:                        ; preds = %pic.desc.classify.397
  %r1932 = getelementptr i64, ptr %r1883, i64 2
  %r1933 = load i64, ptr %r1932, align 8
  %r1934 = icmp ne i64 %r1933, 0
  br i1 %r1934, label %pic.desc.prefix.meta.399, label %pic.miss.cold.403

pic.desc.prefix.meta.399:                         ; preds = %pic.desc.prefix.guard.398
  %r1935 = add nuw nsw i64 %r1863, 8
  %r1936 = inttoptr i64 %r1935 to ptr
  %r1937 = load i64, ptr %r1936, align 8
  %r1938 = icmp ne i64 %r1937, 0
  br i1 %r1938, label %pic.desc.prefix.token.400, label %pic.miss.cold.403

pic.desc.prefix.token.400:                        ; preds = %pic.desc.prefix.meta.399
  %r1939 = inttoptr i64 %r1937 to ptr
  %r1940 = getelementptr i64, ptr %r1939, i64 6
  %r1941 = load i64, ptr %r1940, align 8
  %r1942 = icmp eq i64 %r1941, %r1933
  br i1 %r1942, label %pic.desc.prefix.hit.401, label %pic.miss.cold.403

pic.desc.prefix.hit.401:                          ; preds = %pic.desc.prefix.token.400
  %r1943 = getelementptr i64, ptr %r1883, i64 1
  %r1944 = load i64, ptr %r1943, align 8
  %r1945 = shl i64 %r1944, 3
  %r1946 = add nuw nsw i64 %r1863, 16
  %r1947 = add i64 %r1946, %r1945
  %r1948 = inttoptr i64 %r1947 to ptr
  %r1949 = load double, ptr %r1948, align 8
  br label %pic.merge.405

pic.miss.402:                                     ; preds = %pic.hit.inline.409, %pic.prefix.token.395, %pic.prefix.meta.394, %pic.prefix.guard.393
  %r1950 = getelementptr i64, ptr %r1883, i64 3
  %r1951 = load i64, ptr %r1950, align 8
  %r1952 = icmp sgt i64 %r1951, 0
  br i1 %r1952, label %pic.ways.410, label %pic.miss.call.404

pic.miss.cold.403:                                ; preds = %pic.desc.prefix.token.400, %pic.desc.prefix.meta.399, %pic.desc.prefix.guard.398, %pic.desc.classify.397, %pget.recv_ok.385
  br label %pic.miss.call.404

pic.miss.call.404:                                ; preds = %pic.way.load.411, %pic.ways.410, %pic.miss.cold.403, %pic.miss.402
  %r1991 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r1992 = bitcast double %r1991 to i64
  %r1993 = and i64 %r1992, 281474976710655
  %statepoint_token618 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1863, i64 %r1993, ptr @perry_ic_test_json_cached_template_borrow_ts__19, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s23, ptr addrspace(1) %.01107, ptr addrspace(1) %.27, ptr addrspace(1) %r1628.0, ptr addrspace(1) %.01123, ptr addrspace(1) %r1628.0.base) ]
  %r1994619 = call double @llvm.experimental.gc.result.f64(token %statepoint_token618)
  %rs4gc.s23.relocated620 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 0, i32 0) ; (%rs4gc.s23, %rs4gc.s23)
  %r48.1.base.relocated621 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 1, i32 1) ; (%.01107, %.01107)
  %rs4gc.s10.relocated622 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 2, i32 2) ; (%.27, %.27)
  %r1628.0.relocated623 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 5, i32 3) ; (%r1628.0.base, %r1628.0)
  %r48.1.relocated624 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 1, i32 4) ; (%.01107, %.01123)
  %r1628.0.base.relocated625 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token618, i32 5, i32 5) ; (%r1628.0.base, %r1628.0.base)
  br label %pic.merge.405

pic.merge.405:                                    ; preds = %pic.way.live.412, %pic.hit.overflow.408, %pic.miss.call.404, %pic.desc.prefix.hit.401, %pic.prefix.hit.396, %pic.hit.live.392
  %.11167 = phi ptr addrspace(1) [ %rs4gc.s23.relocated628, %pic.hit.overflow.408 ], [ %rs4gc.s23.relocated620, %pic.miss.call.404 ], [ %rs4gc.s23, %pic.way.live.412 ], [ %rs4gc.s23, %pic.hit.live.392 ], [ %rs4gc.s23, %pic.prefix.hit.396 ], [ %rs4gc.s23, %pic.desc.prefix.hit.401 ]
  %.71159 = phi ptr addrspace(1) [ %r1628.0.relocated631, %pic.hit.overflow.408 ], [ %r1628.0.relocated623, %pic.miss.call.404 ], [ %r1628.0, %pic.way.live.412 ], [ %r1628.0, %pic.hit.live.392 ], [ %r1628.0, %pic.prefix.hit.396 ], [ %r1628.0, %pic.desc.prefix.hit.401 ]
  %.101133 = phi ptr addrspace(1) [ %r48.1.relocated632, %pic.hit.overflow.408 ], [ %r48.1.relocated624, %pic.miss.call.404 ], [ %.01123, %pic.way.live.412 ], [ %.01123, %pic.hit.live.392 ], [ %.01123, %pic.prefix.hit.396 ], [ %.01123, %pic.desc.prefix.hit.401 ]
  %.101117 = phi ptr addrspace(1) [ %r48.1.base.relocated629, %pic.hit.overflow.408 ], [ %r48.1.base.relocated621, %pic.miss.call.404 ], [ %.01107, %pic.way.live.412 ], [ %.01107, %pic.hit.live.392 ], [ %.01107, %pic.prefix.hit.396 ], [ %.01107, %pic.desc.prefix.hit.401 ]
  %.37 = phi ptr addrspace(1) [ %rs4gc.s10.relocated630, %pic.hit.overflow.408 ], [ %rs4gc.s10.relocated622, %pic.miss.call.404 ], [ %.27, %pic.way.live.412 ], [ %.27, %pic.hit.live.392 ], [ %.27, %pic.prefix.hit.396 ], [ %.27, %pic.desc.prefix.hit.401 ]
  %r1995 = phi double [ %r1911, %pic.hit.live.392 ], [ %r1906627, %pic.hit.overflow.408 ], [ %r1931, %pic.prefix.hit.396 ], [ %r1949, %pic.desc.prefix.hit.401 ], [ %r1988, %pic.way.live.412 ], [ %r1994619, %pic.miss.call.404 ]
  br label %pget.recv_merge.388

pic.recv_hdr.406:                                 ; preds = %pget.recv_ok.385
  %r1874 = sub nuw nsw i64 %r1863, 8
  %r1875 = inttoptr i64 %r1874 to ptr
  %r1876 = load i8, ptr %r1875, align 1
  %r1877 = icmp eq i8 %r1876, 2
  %r1878 = sub nuw nsw i64 %r1863, 6
  %r1879 = inttoptr i64 %r1878 to ptr
  %r1880 = load i16, ptr %r1879, align 2
  %r1881 = and i16 %r1880, 2048
  %r1882 = icmp eq i16 %r1881, 0
  %r1883 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__19, align 8
  %r1884 = icmp ne ptr %r1883, null
  %r1885 = and i1 %r1877, %r1882
  %r1886 = and i1 %r1885, %r1884
  br i1 %r1886, label %pic.token.407, label %pic.desc.classify.397

pic.token.407:                                    ; preds = %pic.recv_hdr.406
  %r1888 = add nuw nsw i64 %r1863, 4
  %r1889 = inttoptr i64 %r1888 to ptr
  %r1890 = load i32, ptr %r1889, align 4
  %r1891 = zext i32 %r1890 to i64
  %r1892 = or i64 %r1891, 4611686018427387904
  %r1893 = icmp ne i32 %r1890, 0
  %r1894 = getelementptr i64, ptr %r1883, i64 0
  %r1895 = load i64, ptr %r1894, align 8
  %r1896 = icmp eq i64 %r1892, %r1895
  %r1897 = and i1 %r1896, %r1893
  br i1 %r1897, label %pic.hit.391, label %pic.prefix.guard.393

pic.hit.overflow.408:                             ; preds = %pic.hit.391
  %r1902 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r1903 = bitcast double %r1902 to i64
  %r1904 = and i64 %r1903, 281474976710655
  %r1905 = trunc i64 %r1899 to i32
  %statepoint_token626 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1863, i64 %r1904, i32 %r1905, ptr @perry_ic_test_json_cached_template_borrow_ts__19, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s23, ptr addrspace(1) %.01107, ptr addrspace(1) %.27, ptr addrspace(1) %r1628.0, ptr addrspace(1) %.01123, ptr addrspace(1) %r1628.0.base) ]
  %r1906627 = call double @llvm.experimental.gc.result.f64(token %statepoint_token626)
  %rs4gc.s23.relocated628 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token626, i32 0, i32 0) ; (%rs4gc.s23, %rs4gc.s23)
  %r48.1.base.relocated629 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token626, i32 1, i32 1) ; (%.01107, %.01107)
  %rs4gc.s10.relocated630 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token626, i32 2, i32 2) ; (%.27, %.27)
  %r1628.0.relocated631 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token626, i32 5, i32 3) ; (%r1628.0.base, %r1628.0)
  %r48.1.relocated632 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token626, i32 1, i32 4) ; (%.01107, %.01123)
  %r1628.0.base.relocated633 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token626, i32 5, i32 5) ; (%r1628.0.base, %r1628.0.base)
  br label %pic.merge.405

pic.hit.inline.409:                               ; preds = %pic.hit.391
  %r1907 = shl i64 %r1899, 3
  %r1908 = add nuw nsw i64 %r1863, 16
  %r1909 = add i64 %r1908, %r1907
  %r1910 = inttoptr i64 %r1909 to ptr
  %r1911 = load double, ptr %r1910, align 8
  %r1912 = bitcast double %r1911 to i64
  %r1913 = icmp eq i64 %r1912, 9222246136947933200
  br i1 %r1913, label %pic.miss.402, label %pic.hit.live.392

pic.ways.410:                                     ; preds = %pic.miss.402
  %r1953 = getelementptr i64, ptr %r1883, i64 4
  %r1954 = load i64, ptr %r1953, align 8
  %r1955 = icmp eq i64 %r1954, %r1892
  %r1956 = getelementptr i64, ptr %r1883, i64 5
  %r1957 = load i64, ptr %r1956, align 8
  %r1958 = select i1 %r1955, i64 %r1957, i64 0
  %r1959 = getelementptr i64, ptr %r1883, i64 6
  %r1960 = load i64, ptr %r1959, align 8
  %r1961 = icmp eq i64 %r1960, %r1892
  %r1962 = getelementptr i64, ptr %r1883, i64 7
  %r1963 = load i64, ptr %r1962, align 8
  %r1964 = select i1 %r1961, i64 %r1963, i64 0
  %r1965 = getelementptr i64, ptr %r1883, i64 8
  %r1966 = load i64, ptr %r1965, align 8
  %r1967 = icmp eq i64 %r1966, %r1892
  %r1968 = getelementptr i64, ptr %r1883, i64 9
  %r1969 = load i64, ptr %r1968, align 8
  %r1970 = select i1 %r1967, i64 %r1969, i64 0
  %r1971 = getelementptr i64, ptr %r1883, i64 10
  %r1972 = load i64, ptr %r1971, align 8
  %r1973 = icmp eq i64 %r1972, %r1892
  %r1974 = getelementptr i64, ptr %r1883, i64 11
  %r1975 = load i64, ptr %r1974, align 8
  %r1976 = select i1 %r1973, i64 %r1975, i64 0
  %r1977 = or i1 %r1955, %r1961
  %r1978 = select i1 %r1955, i64 %r1958, i64 %r1964
  %r1979 = or i1 %r1967, %r1973
  %r1980 = select i1 %r1967, i64 %r1970, i64 %r1976
  %r1981 = or i1 %r1977, %r1979
  %r1982 = select i1 %r1977, i64 %r1978, i64 %r1980
  %r1983 = and i1 %r1893, %r1981
  br i1 %r1983, label %pic.way.load.411, label %pic.miss.call.404

pic.way.load.411:                                 ; preds = %pic.ways.410
  %r1984 = shl i64 %r1982, 3
  %r1985 = add nuw nsw i64 %r1863, 16
  %r1986 = add i64 %r1985, %r1984
  %r1987 = inttoptr i64 %r1986 to ptr
  %r1988 = load double, ptr %r1987, align 8
  %r1989 = bitcast double %r1988 to i64
  %r1990 = icmp eq i64 %r1989, 9222246136947933200
  br i1 %r1990, label %pic.miss.call.404, label %pic.way.live.412

pic.way.live.412:                                 ; preds = %pic.way.load.411
  br label %pic.merge.405

pget.throw_nullish.413:                           ; preds = %pget.recv_bad.386
  %r1999 = zext i1 %r1997 to i32
  %statepoint_token634 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1999, ptr @test_json_cached_template_borrow_ts_.str.2.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.414:                       ; preds = %pget.recv_bad.386
  %r2000 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r2001 = bitcast double %r2000 to i64
  %r2002 = and i64 %r2001, 281474976710655
  %statepoint_token635 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1862, i64 %r2002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s23, ptr addrspace(1) %.01107, ptr addrspace(1) %.27, ptr addrspace(1) %r1628.0, ptr addrspace(1) %.01123, ptr addrspace(1) %r1628.0.base) ]
  %r2003636 = call double @llvm.experimental.gc.result.f64(token %statepoint_token635)
  %rs4gc.s23.relocated637 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token635, i32 0, i32 0) ; (%rs4gc.s23, %rs4gc.s23)
  %r48.1.base.relocated638 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token635, i32 1, i32 1) ; (%.01107, %.01107)
  %rs4gc.s10.relocated639 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token635, i32 2, i32 2) ; (%.27, %.27)
  %r1628.0.relocated640 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token635, i32 5, i32 3) ; (%r1628.0.base, %r1628.0)
  %r48.1.relocated641 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token635, i32 1, i32 4) ; (%.01107, %.01123)
  %r1628.0.base.relocated642 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token635, i32 5, i32 5) ; (%r1628.0.base, %r1628.0.base)
  br label %pget.recv_merge.388

shadow.root.barrier.415:                          ; preds = %pget.recv_merge.388
  call void @js_write_barrier_root_nanbox(i64 %r2010) #7
  br label %shadow.root.barrier.done.416

shadow.root.barrier.done.416:                     ; preds = %shadow.root.barrier.415, %pget.recv_merge.388
  %r2013.rs4i = ptrtoint ptr addrspace(1) %.61158 to i64
  %r2013.rs4o = call i64 asm "", "=r,0"(i64 %r2013.rs4i) #7
  %r2013 = bitcast i64 %r2013.rs4o to double
  %r2014 = bitcast double %r2013 to i64
  %r2015 = and i64 %r2014, 281474976710655
  %r2016 = lshr i64 %r2014, 48
  %r2017 = icmp eq i64 %r2016, 32765
  %r2018 = icmp ugt i64 %r2015, 1048575
  %r2019 = and i1 %r2017, %r2018
  br i1 %r2019, label %arr.guard.deref.421, label %arr.fallback.418

arr.fast.417:                                     ; preds = %arr.guard.range.423
  %r2078 = add i64 %r2034, 640
  %r2079 = inttoptr i64 %r2078 to ptr
  %r2080 = load double, ptr %r2079, align 8
  %r2081 = bitcast double %r2080 to i64
  %r2082 = icmp eq i64 %r2081, 9222246136947933200
  %r2084 = select i1 %r2082, double 0x7FFC000000000001, double %r2080
  br label %arr.merge.420

arr.fallback.418:                                 ; preds = %arr.guard.live.422, %arr.guard.deref.421, %shadow.root.barrier.done.416
  %statepoint_token643 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 8988321885632593940, double %r2013, double 7.900000e+01, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s28, ptr addrspace(1) %.01166, ptr addrspace(1) %.91116, ptr addrspace(1) %.36, ptr addrspace(1) %.91132) ]
  %r2074644 = call double @llvm.experimental.gc.result.f64(token %statepoint_token643)
  %rs4gc.s28.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token643, i32 0, i32 0) ; (%rs4gc.s28, %rs4gc.s28)
  %rs4gc.s23.relocated645 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token643, i32 1, i32 1) ; (%.01166, %.01166)
  %r48.1.base.relocated646 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token643, i32 2, i32 2) ; (%.91116, %.91116)
  %rs4gc.s10.relocated647 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token643, i32 3, i32 3) ; (%.36, %.36)
  %r48.1.relocated648 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token643, i32 2, i32 4) ; (%.91116, %.91132)
  br label %arr.merge.420

arr.guard.oob.419:                                ; preds = %arr.guard.range.423
  br label %arr.merge.420

arr.merge.420:                                    ; preds = %arr.guard.oob.419, %arr.fallback.418, %arr.fast.417
  %.01171 = phi ptr addrspace(1) [ %rs4gc.s28, %arr.fast.417 ], [ %rs4gc.s28, %arr.guard.oob.419 ], [ %rs4gc.s28.relocated, %arr.fallback.418 ]
  %.21168 = phi ptr addrspace(1) [ %.01166, %arr.fast.417 ], [ %.01166, %arr.guard.oob.419 ], [ %rs4gc.s23.relocated645, %arr.fallback.418 ]
  %.111134 = phi ptr addrspace(1) [ %.91132, %arr.fast.417 ], [ %.91132, %arr.guard.oob.419 ], [ %r48.1.relocated648, %arr.fallback.418 ]
  %.111118 = phi ptr addrspace(1) [ %.91116, %arr.fast.417 ], [ %.91116, %arr.guard.oob.419 ], [ %r48.1.base.relocated646, %arr.fallback.418 ]
  %.38 = phi ptr addrspace(1) [ %.36, %arr.fast.417 ], [ %.36, %arr.guard.oob.419 ], [ %rs4gc.s10.relocated647, %arr.fallback.418 ]
  %r2085 = phi double [ %r2084, %arr.fast.417 ], [ %r2074644, %arr.fallback.418 ], [ 0x7FFC000000000001, %arr.guard.oob.419 ]
  %r2086 = bitcast double %r2085 to i64
  %r2087 = and i64 %r2086, 281474976710655
  %r2088 = lshr i64 %r2086, 48
  %r2089 = and i64 %r2088, 65533
  %r2090 = icmp eq i64 %r2089, 32765
  br i1 %r2090, label %pget.recv_ok.425, label %pget.recv_other.429

arr.guard.deref.421:                              ; preds = %shadow.root.barrier.done.416
  %r2020 = bitcast double %r2013 to i64
  %r2021 = and i64 %r2020, 281474976710655
  %r2022 = sub nsw i64 %r2021, 8
  %r2023 = inttoptr i64 %r2022 to ptr
  %r2024 = load i8, ptr %r2023, align 1
  %r2025 = icmp eq i8 %r2024, 1
  %r2026 = sub nsw i64 %r2021, 7
  %r2027 = inttoptr i64 %r2026 to ptr
  %r2028 = load i8, ptr %r2027, align 1
  %r2029 = and i8 %r2028, -128
  %r2030 = icmp ne i8 %r2029, 0
  %r2031 = inttoptr i64 %r2021 to ptr
  %r2032 = load i64, ptr %r2031, align 8
  %r2033 = and i1 %r2025, %r2030
  %r2034 = select i1 %r2033, i64 %r2032, i64 %r2021
  %r2035 = lshr i64 %r2034, 48
  %r2036 = icmp eq i64 %r2035, 0
  %r2037 = icmp ugt i64 %r2034, 1048575
  %r2038 = and i1 %r2036, %r2037
  br i1 %r2038, label %arr.guard.live.422, label %arr.fallback.418

arr.guard.live.422:                               ; preds = %arr.guard.deref.421
  %r2039 = sub nuw i64 %r2034, 8
  %r2040 = inttoptr i64 %r2039 to ptr
  %r2041 = load i8, ptr %r2040, align 1
  %r2042 = icmp eq i8 %r2041, 1
  %r2043 = sub nuw i64 %r2034, 7
  %r2044 = inttoptr i64 %r2043 to ptr
  %r2045 = load i8, ptr %r2044, align 1
  %r2046 = and i8 %r2045, -128
  %r2047 = icmp eq i8 %r2046, 0
  %r2048 = sub nuw i64 %r2034, 6
  %r2049 = inttoptr i64 %r2048 to ptr
  %r2050 = load i16, ptr %r2049, align 2
  %r2051 = and i16 %r2050, 1024
  %r2052 = icmp eq i16 %r2051, 0
  %r2053 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2054 = icmp eq i8 %r2053, 0
  %r2055 = inttoptr i64 %r2034 to ptr
  %r2056 = load i32, ptr %r2055, align 4
  %r2057 = getelementptr i8, ptr %r2055, i64 4
  %r2058 = load i32, ptr %r2057, align 4
  %r2062 = icmp ule i32 %r2056, 16000000
  %r2063 = icmp ule i32 %r2058, 16000000
  %r2064 = icmp ule i32 %r2056, %r2058
  %r2065 = and i1 %r2042, %r2047
  %r2066 = and i1 %r2065, %r2052
  %r2067 = and i1 %r2066, %r2054
  %r2069 = and i1 %r2067, %r2062
  %r2070 = and i1 %r2069, %r2063
  %r2071 = and i1 %r2070, %r2064
  br i1 %r2071, label %arr.guard.range.423, label %arr.fallback.418

arr.guard.range.423:                              ; preds = %arr.guard.live.422
  %r2061 = icmp ult i32 79, %r2056
  br i1 %r2061, label %arr.fast.417, label %arr.guard.oob.419

pget.recv_sso.424:                                ; preds = %pget.recv_other.429
  %r2228 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r2229 = bitcast double %r2228 to i64
  %r2230 = and i64 %r2229, 281474976710655
  %statepoint_token649 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2086, i64 %r2230, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111118, ptr addrspace(1) %.38, ptr addrspace(1) %.21168, ptr addrspace(1) %.01171, ptr addrspace(1) %.111134) ]
  %r2231650 = call double @llvm.experimental.gc.result.f64(token %statepoint_token649)
  %r48.1.base.relocated651 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token649, i32 0, i32 0) ; (%.111118, %.111118)
  %rs4gc.s10.relocated652 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token649, i32 1, i32 1) ; (%.38, %.38)
  %rs4gc.s23.relocated653 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token649, i32 2, i32 2) ; (%.21168, %.21168)
  %rs4gc.s28.relocated654 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token649, i32 3, i32 3) ; (%.01171, %.01171)
  %r48.1.relocated655 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token649, i32 0, i32 4) ; (%.111118, %.111134)
  br label %pget.recv_merge.428

pget.recv_ok.425:                                 ; preds = %arr.merge.420
  %r2097 = icmp ugt i64 %r2087, 1048575
  br i1 %r2097, label %pic.recv_hdr.446, label %pic.miss.cold.443

pget.recv_bad.426:                                ; preds = %pget.check_class_ref.430
  %r2220 = icmp eq i64 %r2086, 9222246136947933185
  %r2221 = icmp eq i64 %r2086, 9222246136947933186
  %r2222 = or i1 %r2220, %r2221
  br i1 %r2222, label %pget.throw_nullish.453, label %pget.recv_undef_return.454

pget.recv_class_ref.427:                          ; preds = %pget.check_class_ref.430
  %r2093 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r2094 = bitcast double %r2093 to i64
  %r2095 = and i64 %r2094, 281474976710655
  %statepoint_token656 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 8988321885632593941, i64 %r2086, i64 %r2095, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111118, ptr addrspace(1) %.38, ptr addrspace(1) %.21168, ptr addrspace(1) %.01171, ptr addrspace(1) %.111134) ]
  %r2096657 = call double @llvm.experimental.gc.result.f64(token %statepoint_token656)
  %r48.1.base.relocated658 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token656, i32 0, i32 0) ; (%.111118, %.111118)
  %rs4gc.s10.relocated659 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token656, i32 1, i32 1) ; (%.38, %.38)
  %rs4gc.s23.relocated660 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token656, i32 2, i32 2) ; (%.21168, %.21168)
  %rs4gc.s28.relocated661 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token656, i32 3, i32 3) ; (%.01171, %.01171)
  %r48.1.relocated662 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token656, i32 0, i32 4) ; (%.111118, %.111134)
  br label %pget.recv_merge.428

pget.recv_merge.428:                              ; preds = %pget.recv_undef_return.454, %pic.merge.445, %pget.recv_class_ref.427, %pget.recv_sso.424
  %.11172 = phi ptr addrspace(1) [ %.21173, %pic.merge.445 ], [ %rs4gc.s28.relocated654, %pget.recv_sso.424 ], [ %rs4gc.s28.relocated661, %pget.recv_class_ref.427 ], [ %rs4gc.s28.relocated683, %pget.recv_undef_return.454 ]
  %.31169 = phi ptr addrspace(1) [ %.41170, %pic.merge.445 ], [ %rs4gc.s23.relocated653, %pget.recv_sso.424 ], [ %rs4gc.s23.relocated660, %pget.recv_class_ref.427 ], [ %rs4gc.s23.relocated682, %pget.recv_undef_return.454 ]
  %.121135 = phi ptr addrspace(1) [ %.131136, %pic.merge.445 ], [ %r48.1.relocated655, %pget.recv_sso.424 ], [ %r48.1.relocated662, %pget.recv_class_ref.427 ], [ %r48.1.relocated684, %pget.recv_undef_return.454 ]
  %.121119 = phi ptr addrspace(1) [ %.131120, %pic.merge.445 ], [ %r48.1.base.relocated651, %pget.recv_sso.424 ], [ %r48.1.base.relocated658, %pget.recv_class_ref.427 ], [ %r48.1.base.relocated680, %pget.recv_undef_return.454 ]
  %.39 = phi ptr addrspace(1) [ %.40, %pic.merge.445 ], [ %rs4gc.s10.relocated652, %pget.recv_sso.424 ], [ %rs4gc.s10.relocated659, %pget.recv_class_ref.427 ], [ %rs4gc.s10.relocated681, %pget.recv_undef_return.454 ]
  %r2232 = phi double [ %r2219, %pic.merge.445 ], [ %r2227679, %pget.recv_undef_return.454 ], [ %r2231650, %pget.recv_sso.424 ], [ %r2096657, %pget.recv_class_ref.427 ]
  %r2233.rs4i = ptrtoint ptr addrspace(1) %.31169 to i64
  %r2233 = call i64 asm "", "=r,0"(i64 %r2233.rs4i) #7
  %r2234 = bitcast i64 %r2233 to double
  %r2235.rs4i = ptrtoint ptr addrspace(1) %.11172 to i64
  %r2235 = call i64 asm "", "=r,0"(i64 %r2235.rs4i) #7
  %r2236 = bitcast i64 %r2235 to double
  %r2237 = and i64 %r2233, -281474976710656
  %r2238 = icmp ult i64 %r2237, 9221401712017801216
  %r2239 = icmp ugt i64 %r2237, 9223090561878065152
  %r2240 = or i1 %r2238, %r2239
  %r2241 = and i64 %r2235, -281474976710656
  %r2242 = icmp ult i64 %r2241, 9221401712017801216
  %r2243 = icmp ugt i64 %r2241, 9223090561878065152
  %r2244 = or i1 %r2242, %r2243
  %r2245 = and i1 %r2240, %r2244
  %r2246 = bitcast double %r2232 to i64
  %r2247 = and i64 %r2246, -281474976710656
  %r2248 = icmp ult i64 %r2247, 9221401712017801216
  %r2249 = icmp ugt i64 %r2247, 9223090561878065152
  %r2250 = or i1 %r2248, %r2249
  %r2251 = and i1 %r2245, %r2250
  br i1 %r2251, label %guarded_add.numeric.455, label %guarded_add.dynamic.456

pget.recv_other.429:                              ; preds = %arr.merge.420
  %r2091 = icmp eq i64 %r2088, 32761
  br i1 %r2091, label %pget.recv_sso.424, label %pget.check_class_ref.430

pget.check_class_ref.430:                         ; preds = %pget.recv_other.429
  %r2092 = icmp eq i64 %r2088, 32766
  br i1 %r2092, label %pget.recv_class_ref.427, label %pget.recv_bad.426

pic.hit.431:                                      ; preds = %pic.token.447
  %r2122 = getelementptr i64, ptr %r2107, i64 1
  %r2123 = load i64, ptr %r2122, align 8
  %r2124 = and i64 %r2123, 1073741824
  %r2125 = icmp ne i64 %r2124, 0
  br i1 %r2125, label %pic.hit.overflow.448, label %pic.hit.inline.449

pic.hit.live.432:                                 ; preds = %pic.hit.inline.449
  br label %pic.merge.445

pic.prefix.guard.433:                             ; preds = %pic.token.447
  %r2138 = getelementptr i64, ptr %r2107, i64 2
  %r2139 = load i64, ptr %r2138, align 8
  %r2140 = icmp ne i64 %r2139, 0
  br i1 %r2140, label %pic.prefix.meta.434, label %pic.miss.442

pic.prefix.meta.434:                              ; preds = %pic.prefix.guard.433
  %r2141 = add nuw nsw i64 %r2087, 8
  %r2142 = inttoptr i64 %r2141 to ptr
  %r2143 = load i64, ptr %r2142, align 8
  %r2144 = icmp ne i64 %r2143, 0
  br i1 %r2144, label %pic.prefix.token.435, label %pic.miss.442

pic.prefix.token.435:                             ; preds = %pic.prefix.meta.434
  %r2145 = inttoptr i64 %r2143 to ptr
  %r2146 = getelementptr i64, ptr %r2145, i64 6
  %r2147 = load i64, ptr %r2146, align 8
  %r2148 = icmp eq i64 %r2147, %r2139
  br i1 %r2148, label %pic.prefix.hit.436, label %pic.miss.442

pic.prefix.hit.436:                               ; preds = %pic.prefix.token.435
  %r2149 = getelementptr i64, ptr %r2107, i64 1
  %r2150 = load i64, ptr %r2149, align 8
  %r2151 = shl i64 %r2150, 3
  %r2152 = add nuw nsw i64 %r2087, 16
  %r2153 = add i64 %r2152, %r2151
  %r2154 = inttoptr i64 %r2153 to ptr
  %r2155 = load double, ptr %r2154, align 8
  br label %pic.merge.445

pic.desc.classify.437:                            ; preds = %pic.recv_hdr.446
  %r2111 = and i1 %r2101, %r2108
  br i1 %r2111, label %pic.desc.prefix.guard.438, label %pic.miss.cold.443

pic.desc.prefix.guard.438:                        ; preds = %pic.desc.classify.437
  %r2156 = getelementptr i64, ptr %r2107, i64 2
  %r2157 = load i64, ptr %r2156, align 8
  %r2158 = icmp ne i64 %r2157, 0
  br i1 %r2158, label %pic.desc.prefix.meta.439, label %pic.miss.cold.443

pic.desc.prefix.meta.439:                         ; preds = %pic.desc.prefix.guard.438
  %r2159 = add nuw nsw i64 %r2087, 8
  %r2160 = inttoptr i64 %r2159 to ptr
  %r2161 = load i64, ptr %r2160, align 8
  %r2162 = icmp ne i64 %r2161, 0
  br i1 %r2162, label %pic.desc.prefix.token.440, label %pic.miss.cold.443

pic.desc.prefix.token.440:                        ; preds = %pic.desc.prefix.meta.439
  %r2163 = inttoptr i64 %r2161 to ptr
  %r2164 = getelementptr i64, ptr %r2163, i64 6
  %r2165 = load i64, ptr %r2164, align 8
  %r2166 = icmp eq i64 %r2165, %r2157
  br i1 %r2166, label %pic.desc.prefix.hit.441, label %pic.miss.cold.443

pic.desc.prefix.hit.441:                          ; preds = %pic.desc.prefix.token.440
  %r2167 = getelementptr i64, ptr %r2107, i64 1
  %r2168 = load i64, ptr %r2167, align 8
  %r2169 = shl i64 %r2168, 3
  %r2170 = add nuw nsw i64 %r2087, 16
  %r2171 = add i64 %r2170, %r2169
  %r2172 = inttoptr i64 %r2171 to ptr
  %r2173 = load double, ptr %r2172, align 8
  br label %pic.merge.445

pic.miss.442:                                     ; preds = %pic.hit.inline.449, %pic.prefix.token.435, %pic.prefix.meta.434, %pic.prefix.guard.433
  %r2174 = getelementptr i64, ptr %r2107, i64 3
  %r2175 = load i64, ptr %r2174, align 8
  %r2176 = icmp sgt i64 %r2175, 0
  br i1 %r2176, label %pic.ways.450, label %pic.miss.call.444

pic.miss.cold.443:                                ; preds = %pic.desc.prefix.token.440, %pic.desc.prefix.meta.439, %pic.desc.prefix.guard.438, %pic.desc.classify.437, %pget.recv_ok.425
  br label %pic.miss.call.444

pic.miss.call.444:                                ; preds = %pic.way.load.451, %pic.ways.450, %pic.miss.cold.443, %pic.miss.442
  %r2215 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r2216 = bitcast double %r2215 to i64
  %r2217 = and i64 %r2216, 281474976710655
  %statepoint_token663 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2087, i64 %r2217, ptr @perry_ic_test_json_cached_template_borrow_ts__22, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111118, ptr addrspace(1) %.38, ptr addrspace(1) %.21168, ptr addrspace(1) %.01171, ptr addrspace(1) %.111134) ]
  %r2218664 = call double @llvm.experimental.gc.result.f64(token %statepoint_token663)
  %r48.1.base.relocated665 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token663, i32 0, i32 0) ; (%.111118, %.111118)
  %rs4gc.s10.relocated666 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token663, i32 1, i32 1) ; (%.38, %.38)
  %rs4gc.s23.relocated667 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token663, i32 2, i32 2) ; (%.21168, %.21168)
  %rs4gc.s28.relocated668 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token663, i32 3, i32 3) ; (%.01171, %.01171)
  %r48.1.relocated669 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token663, i32 0, i32 4) ; (%.111118, %.111134)
  br label %pic.merge.445

pic.merge.445:                                    ; preds = %pic.way.live.452, %pic.hit.overflow.448, %pic.miss.call.444, %pic.desc.prefix.hit.441, %pic.prefix.hit.436, %pic.hit.live.432
  %.21173 = phi ptr addrspace(1) [ %rs4gc.s28.relocated675, %pic.hit.overflow.448 ], [ %rs4gc.s28.relocated668, %pic.miss.call.444 ], [ %.01171, %pic.way.live.452 ], [ %.01171, %pic.hit.live.432 ], [ %.01171, %pic.prefix.hit.436 ], [ %.01171, %pic.desc.prefix.hit.441 ]
  %.41170 = phi ptr addrspace(1) [ %rs4gc.s23.relocated674, %pic.hit.overflow.448 ], [ %rs4gc.s23.relocated667, %pic.miss.call.444 ], [ %.21168, %pic.way.live.452 ], [ %.21168, %pic.hit.live.432 ], [ %.21168, %pic.prefix.hit.436 ], [ %.21168, %pic.desc.prefix.hit.441 ]
  %.131136 = phi ptr addrspace(1) [ %r48.1.relocated676, %pic.hit.overflow.448 ], [ %r48.1.relocated669, %pic.miss.call.444 ], [ %.111134, %pic.way.live.452 ], [ %.111134, %pic.hit.live.432 ], [ %.111134, %pic.prefix.hit.436 ], [ %.111134, %pic.desc.prefix.hit.441 ]
  %.131120 = phi ptr addrspace(1) [ %r48.1.base.relocated672, %pic.hit.overflow.448 ], [ %r48.1.base.relocated665, %pic.miss.call.444 ], [ %.111118, %pic.way.live.452 ], [ %.111118, %pic.hit.live.432 ], [ %.111118, %pic.prefix.hit.436 ], [ %.111118, %pic.desc.prefix.hit.441 ]
  %.40 = phi ptr addrspace(1) [ %rs4gc.s10.relocated673, %pic.hit.overflow.448 ], [ %rs4gc.s10.relocated666, %pic.miss.call.444 ], [ %.38, %pic.way.live.452 ], [ %.38, %pic.hit.live.432 ], [ %.38, %pic.prefix.hit.436 ], [ %.38, %pic.desc.prefix.hit.441 ]
  %r2219 = phi double [ %r2135, %pic.hit.live.432 ], [ %r2130671, %pic.hit.overflow.448 ], [ %r2155, %pic.prefix.hit.436 ], [ %r2173, %pic.desc.prefix.hit.441 ], [ %r2212, %pic.way.live.452 ], [ %r2218664, %pic.miss.call.444 ]
  br label %pget.recv_merge.428

pic.recv_hdr.446:                                 ; preds = %pget.recv_ok.425
  %r2098 = sub nuw nsw i64 %r2087, 8
  %r2099 = inttoptr i64 %r2098 to ptr
  %r2100 = load i8, ptr %r2099, align 1
  %r2101 = icmp eq i8 %r2100, 2
  %r2102 = sub nuw nsw i64 %r2087, 6
  %r2103 = inttoptr i64 %r2102 to ptr
  %r2104 = load i16, ptr %r2103, align 2
  %r2105 = and i16 %r2104, 2048
  %r2106 = icmp eq i16 %r2105, 0
  %r2107 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__22, align 8
  %r2108 = icmp ne ptr %r2107, null
  %r2109 = and i1 %r2101, %r2106
  %r2110 = and i1 %r2109, %r2108
  br i1 %r2110, label %pic.token.447, label %pic.desc.classify.437

pic.token.447:                                    ; preds = %pic.recv_hdr.446
  %r2112 = add nuw nsw i64 %r2087, 4
  %r2113 = inttoptr i64 %r2112 to ptr
  %r2114 = load i32, ptr %r2113, align 4
  %r2115 = zext i32 %r2114 to i64
  %r2116 = or i64 %r2115, 4611686018427387904
  %r2117 = icmp ne i32 %r2114, 0
  %r2118 = getelementptr i64, ptr %r2107, i64 0
  %r2119 = load i64, ptr %r2118, align 8
  %r2120 = icmp eq i64 %r2116, %r2119
  %r2121 = and i1 %r2120, %r2117
  br i1 %r2121, label %pic.hit.431, label %pic.prefix.guard.433

pic.hit.overflow.448:                             ; preds = %pic.hit.431
  %r2126 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r2127 = bitcast double %r2126 to i64
  %r2128 = and i64 %r2127, 281474976710655
  %r2129 = trunc i64 %r2123 to i32
  %statepoint_token670 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2087, i64 %r2128, i32 %r2129, ptr @perry_ic_test_json_cached_template_borrow_ts__22, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111118, ptr addrspace(1) %.38, ptr addrspace(1) %.21168, ptr addrspace(1) %.01171, ptr addrspace(1) %.111134) ]
  %r2130671 = call double @llvm.experimental.gc.result.f64(token %statepoint_token670)
  %r48.1.base.relocated672 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token670, i32 0, i32 0) ; (%.111118, %.111118)
  %rs4gc.s10.relocated673 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token670, i32 1, i32 1) ; (%.38, %.38)
  %rs4gc.s23.relocated674 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token670, i32 2, i32 2) ; (%.21168, %.21168)
  %rs4gc.s28.relocated675 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token670, i32 3, i32 3) ; (%.01171, %.01171)
  %r48.1.relocated676 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token670, i32 0, i32 4) ; (%.111118, %.111134)
  br label %pic.merge.445

pic.hit.inline.449:                               ; preds = %pic.hit.431
  %r2131 = shl i64 %r2123, 3
  %r2132 = add nuw nsw i64 %r2087, 16
  %r2133 = add i64 %r2132, %r2131
  %r2134 = inttoptr i64 %r2133 to ptr
  %r2135 = load double, ptr %r2134, align 8
  %r2136 = bitcast double %r2135 to i64
  %r2137 = icmp eq i64 %r2136, 9222246136947933200
  br i1 %r2137, label %pic.miss.442, label %pic.hit.live.432

pic.ways.450:                                     ; preds = %pic.miss.442
  %r2177 = getelementptr i64, ptr %r2107, i64 4
  %r2178 = load i64, ptr %r2177, align 8
  %r2179 = icmp eq i64 %r2178, %r2116
  %r2180 = getelementptr i64, ptr %r2107, i64 5
  %r2181 = load i64, ptr %r2180, align 8
  %r2182 = select i1 %r2179, i64 %r2181, i64 0
  %r2183 = getelementptr i64, ptr %r2107, i64 6
  %r2184 = load i64, ptr %r2183, align 8
  %r2185 = icmp eq i64 %r2184, %r2116
  %r2186 = getelementptr i64, ptr %r2107, i64 7
  %r2187 = load i64, ptr %r2186, align 8
  %r2188 = select i1 %r2185, i64 %r2187, i64 0
  %r2189 = getelementptr i64, ptr %r2107, i64 8
  %r2190 = load i64, ptr %r2189, align 8
  %r2191 = icmp eq i64 %r2190, %r2116
  %r2192 = getelementptr i64, ptr %r2107, i64 9
  %r2193 = load i64, ptr %r2192, align 8
  %r2194 = select i1 %r2191, i64 %r2193, i64 0
  %r2195 = getelementptr i64, ptr %r2107, i64 10
  %r2196 = load i64, ptr %r2195, align 8
  %r2197 = icmp eq i64 %r2196, %r2116
  %r2198 = getelementptr i64, ptr %r2107, i64 11
  %r2199 = load i64, ptr %r2198, align 8
  %r2200 = select i1 %r2197, i64 %r2199, i64 0
  %r2201 = or i1 %r2179, %r2185
  %r2202 = select i1 %r2179, i64 %r2182, i64 %r2188
  %r2203 = or i1 %r2191, %r2197
  %r2204 = select i1 %r2191, i64 %r2194, i64 %r2200
  %r2205 = or i1 %r2201, %r2203
  %r2206 = select i1 %r2201, i64 %r2202, i64 %r2204
  %r2207 = and i1 %r2117, %r2205
  br i1 %r2207, label %pic.way.load.451, label %pic.miss.call.444

pic.way.load.451:                                 ; preds = %pic.ways.450
  %r2208 = shl i64 %r2206, 3
  %r2209 = add nuw nsw i64 %r2087, 16
  %r2210 = add i64 %r2209, %r2208
  %r2211 = inttoptr i64 %r2210 to ptr
  %r2212 = load double, ptr %r2211, align 8
  %r2213 = bitcast double %r2212 to i64
  %r2214 = icmp eq i64 %r2213, 9222246136947933200
  br i1 %r2214, label %pic.miss.call.444, label %pic.way.live.452

pic.way.live.452:                                 ; preds = %pic.way.load.451
  br label %pic.merge.445

pget.throw_nullish.453:                           ; preds = %pget.recv_bad.426
  %r2223 = zext i1 %r2221 to i32
  %statepoint_token677 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2223, ptr @test_json_cached_template_borrow_ts_.str.2.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.454:                       ; preds = %pget.recv_bad.426
  %r2224 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r2225 = bitcast double %r2224 to i64
  %r2226 = and i64 %r2225, 281474976710655
  %statepoint_token678 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2086, i64 %r2226, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.111118, ptr addrspace(1) %.38, ptr addrspace(1) %.21168, ptr addrspace(1) %.01171, ptr addrspace(1) %.111134) ]
  %r2227679 = call double @llvm.experimental.gc.result.f64(token %statepoint_token678)
  %r48.1.base.relocated680 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token678, i32 0, i32 0) ; (%.111118, %.111118)
  %rs4gc.s10.relocated681 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token678, i32 1, i32 1) ; (%.38, %.38)
  %rs4gc.s23.relocated682 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token678, i32 2, i32 2) ; (%.21168, %.21168)
  %rs4gc.s28.relocated683 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token678, i32 3, i32 3) ; (%.01171, %.01171)
  %r48.1.relocated684 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token678, i32 0, i32 4) ; (%.111118, %.111134)
  br label %pget.recv_merge.428

guarded_add.numeric.455:                          ; preds = %pget.recv_merge.428
  %r2252 = fadd double %r2236, %r2232
  %r2253 = fadd double %r2234, %r2252
  br label %guarded_add.merge.457

guarded_add.dynamic.456:                          ; preds = %pget.recv_merge.428
  %statepoint_token685 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r2236, double %r2232, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.121119, ptr addrspace(1) %.39, ptr addrspace(1) %.121135, ptr addrspace(1) %.31169) ]
  %r2254686 = call double @llvm.experimental.gc.result.f64(token %statepoint_token685)
  %r48.1.base.relocated687 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token685, i32 0, i32 0) ; (%.121119, %.121119)
  %rs4gc.s10.relocated688 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token685, i32 1, i32 1) ; (%.39, %.39)
  %r48.1.relocated689 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token685, i32 0, i32 2) ; (%.121119, %.121135)
  %rs4gc.s23.relocated690 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token685, i32 3, i32 3) ; (%.31169, %.31169)
  %r3504.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23.relocated690 to i64
  %r3504 = call i64 asm "", "=r,0"(i64 %r3504.rs4i) #7
  %r3505 = bitcast i64 %r3504 to double
  %statepoint_token691 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r3505, double %r2254686, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.1.base.relocated687, ptr addrspace(1) %rs4gc.s10.relocated688, ptr addrspace(1) %r48.1.relocated689) ]
  %r2255692 = call double @llvm.experimental.gc.result.f64(token %statepoint_token691)
  %r48.1.base.relocated693 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token691, i32 0, i32 0) ; (%r48.1.base.relocated687, %r48.1.base.relocated687)
  %rs4gc.s10.relocated694 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token691, i32 1, i32 1) ; (%rs4gc.s10.relocated688, %rs4gc.s10.relocated688)
  %r48.1.relocated695 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token691, i32 0, i32 2) ; (%r48.1.base.relocated687, %r48.1.relocated689)
  br label %guarded_add.merge.457

guarded_add.merge.457:                            ; preds = %guarded_add.dynamic.456, %guarded_add.numeric.455
  %.141137 = phi ptr addrspace(1) [ %.121135, %guarded_add.numeric.455 ], [ %r48.1.relocated695, %guarded_add.dynamic.456 ]
  %.141121 = phi ptr addrspace(1) [ %.121119, %guarded_add.numeric.455 ], [ %r48.1.base.relocated693, %guarded_add.dynamic.456 ]
  %.41 = phi ptr addrspace(1) [ %.39, %guarded_add.numeric.455 ], [ %rs4gc.s10.relocated694, %guarded_add.dynamic.456 ]
  %r2256 = phi double [ %r2253, %guarded_add.numeric.455 ], [ %r2255692, %guarded_add.dynamic.456 ]
  %rs4gc.b29 = bitcast double %r2256 to i64
  %rs4gc.s29 = inttoptr i64 %rs4gc.b29 to ptr addrspace(1)
  %r2257.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r2257 = call i64 asm "", "=r,0"(i64 %r2257.rs4i) #7
  %r2258 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2259 = icmp ne i32 %r2258, 0
  br i1 %r2259, label %shadow.root.barrier.458, label %shadow.root.barrier.done.459

shadow.root.barrier.458:                          ; preds = %guarded_add.merge.457
  call void @js_write_barrier_root_nanbox(i64 %r2257) #7
  br label %shadow.root.barrier.done.459

shadow.root.barrier.done.459:                     ; preds = %shadow.root.barrier.458, %guarded_add.merge.457
  %r2260 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r2261 = icmp ne i32 %r2260, 0
  br i1 %r2261, label %gcpoll.460, label %gcpoll.done.461

gcpoll.460:                                       ; preds = %shadow.root.barrier.done.459
  %statepoint_token696 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s29, ptr addrspace(1) %.141121, ptr addrspace(1) %.141137, ptr addrspace(1) %.41) ]
  %rs4gc.s29.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token696, i32 0, i32 0) ; (%rs4gc.s29, %rs4gc.s29)
  %r48.1.base.relocated697 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token696, i32 1, i32 1) ; (%.141121, %.141121)
  %r48.1.relocated698 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token696, i32 1, i32 2) ; (%.141121, %.141137)
  %rs4gc.s10.relocated699 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token696, i32 3, i32 3) ; (%.41, %.41)
  br label %gcpoll.done.461

gcpoll.done.461:                                  ; preds = %gcpoll.460, %shadow.root.barrier.done.459
  %.01174 = phi ptr addrspace(1) [ %rs4gc.s29.relocated, %gcpoll.460 ], [ %rs4gc.s29, %shadow.root.barrier.done.459 ]
  %.151138 = phi ptr addrspace(1) [ %r48.1.relocated698, %gcpoll.460 ], [ %.141137, %shadow.root.barrier.done.459 ]
  %.151122 = phi ptr addrspace(1) [ %r48.1.base.relocated697, %gcpoll.460 ], [ %.141121, %shadow.root.barrier.done.459 ]
  %.42 = phi ptr addrspace(1) [ %rs4gc.s10.relocated699, %gcpoll.460 ], [ %.41, %shadow.root.barrier.done.459 ]
  br label %for.update.17

for.cond.462:                                     ; preds = %for.update.464, %for.exit.18
  %.01011 = phi ptr addrspace(1) [ %r48.0, %for.exit.18 ], [ %.391050, %for.update.464 ]
  %.0971 = phi ptr addrspace(1) [ %r48.0.base, %for.exit.18 ], [ %.391010, %for.update.464 ]
  %.0928 = phi ptr addrspace(1) [ %r57.0, %for.exit.18 ], [ %.50, %for.update.464 ]
  %r2266.0 = phi i32 [ 0, %for.exit.18 ], [ %r3272, %for.update.464 ]
  %r2268 = sitofp i32 %r2266.0 to double
  %r2269.rs4i = ptrtoint ptr addrspace(1) %.01011 to i64
  %r2269.rs4o = call i64 asm "", "=r,0"(i64 %r2269.rs4i) #7
  %r2269 = bitcast i64 %r2269.rs4o to double
  %r2270 = bitcast double %r2269 to i64
  %r2271 = and i64 %r2270, 281474976710655
  %r2272 = lshr i64 %r2270, 48
  %r2273 = and i64 %r2272, 65533
  %r2274 = icmp eq i64 %r2273, 32765
  %r2275 = icmp ugt i64 %r2271, 1048575
  %r2276 = and i1 %r2274, %r2275
  br i1 %r2276, label %plen.check_gc.466, label %plen.slow.468

for.body.463:                                     ; preds = %gcpoll.done.488
  %r2383.rs4i = ptrtoint ptr addrspace(1) %.271038 to i64
  %r2383.rs4o = call i64 asm "", "=r,0"(i64 %r2383.rs4i) #7
  %r2383 = bitcast i64 %r2383.rs4o to double
  %r2385 = bitcast double %r2383 to i64
  %r2386 = and i64 %r2385, 281474976710655
  %r2387 = lshr i64 %r2385, 48
  %r2388 = icmp eq i64 %r2387, 32765
  %r2389 = icmp ugt i64 %r2386, 1048575
  %r2390 = and i1 %r2388, %r2389
  br i1 %r2390, label %arr.guard.deref.493, label %arr.fallback.490

for.update.464:                                   ; preds = %gcpoll.done.654
  %r3272 = add i32 %r2266.0, 1
  %r3273 = sitofp i32 %r2266.0 to double
  %r3274 = sitofp i32 %r3272 to double
  br label %for.cond.462

for.exit.465:                                     ; preds = %gcpoll.done.488
  %statepoint_token700 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.271038, ptr addrspace(1) %.27998, ptr addrspace(1) %.38966) ]
  %r3275701 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token700)
  %r48.0.relocated702 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token700, i32 1, i32 0) ; (%.27998, %.271038)
  %r48.0.base.relocated703 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token700, i32 1, i32 1) ; (%.27998, %.27998)
  %r57.0.relocated704 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token700, i32 2, i32 2) ; (%.38966, %.38966)
  %rs4gc.s30 = inttoptr i64 %r3275701 to ptr addrspace(1)
  %r3276.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r3276 = call i64 asm "", "=r,0"(i64 %r3276.rs4i) #7
  %r3277 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3278 = icmp ne i32 %r3277, 0
  br i1 %r3278, label %shadow.root.barrier.655, label %shadow.root.barrier.done.656

plen.check_gc.466:                                ; preds = %for.cond.462
  %r2277 = sub nuw nsw i64 %r2271, 8
  %r2278 = inttoptr i64 %r2277 to ptr
  %r2279 = load i8, ptr %r2278, align 1
  %r2280 = icmp eq i8 %r2279, 1
  %r2281 = icmp eq i8 %r2279, 3
  %r2282 = or i1 %r2280, %r2281
  %r2283 = sub nuw nsw i64 %r2271, 7
  %r2284 = inttoptr i64 %r2283 to ptr
  %r2285 = load i8, ptr %r2284, align 1
  %r2286 = and i8 %r2285, -128
  %r2287 = icmp eq i8 %r2286, 0
  %r2288 = and i1 %r2282, %r2287
  br i1 %r2288, label %plen.fast.467, label %plen.slow.468

plen.fast.467:                                    ; preds = %plen.check_gc.466
  %r2290 = inttoptr i64 %r2271 to ptr
  %r2291 = select i1 false, ptr @perry_null_guard_zero_test_json_cached_template_borrow_ts, ptr %r2290
  %r2292 = load i32, ptr %r2291, align 4
  %r2293 = uitofp i32 %r2292 to double
  br label %plen.merge.469

plen.slow.468:                                    ; preds = %plen.check_gc.466, %for.cond.462
  %r2294 = lshr i64 %r2270, 48
  %r2295 = icmp eq i64 %r2294, 32765
  %r2296 = icmp uge i64 %r2271, 2199023255552
  %r2297 = icmp ult i64 %r2271, 140737488355328
  %r2298 = and i1 %r2295, %r2296
  %r2299 = and i1 %r2298, %r2297
  %r2300 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__23, align 8
  br i1 %r2299, label %plen.ic.header.470, label %plen.ic.miss.482

plen.merge.469:                                   ; preds = %plen.ic.merge.483, %plen.fast.467
  %.251036 = phi ptr addrspace(1) [ %.01011, %plen.fast.467 ], [ %.261037, %plen.ic.merge.483 ]
  %.25996 = phi ptr addrspace(1) [ %.0971, %plen.fast.467 ], [ %.26997, %plen.ic.merge.483 ]
  %.36964 = phi ptr addrspace(1) [ %.0928, %plen.fast.467 ], [ %.37965, %plen.ic.merge.483 ]
  %r2375 = phi double [ %r2293, %plen.fast.467 ], [ %r2374, %plen.ic.merge.483 ]
  %r2376 = fcmp olt double %r2268, %r2375
  %r2377 = select i1 %r2376, i64 9222246136947933188, i64 9222246136947933187
  %r2378 = bitcast i64 %r2377 to double
  %r2380 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r2381 = icmp ne i32 %r2380, 0
  br i1 %r2381, label %gcpoll.487, label %gcpoll.done.488

plen.ic.header.470:                               ; preds = %plen.slow.468
  %r2302 = sub nuw nsw i64 %r2271, 8
  %r2303 = inttoptr i64 %r2302 to ptr
  %r2304 = load i8, ptr %r2303, align 1
  %r2305 = icmp eq i8 %r2304, 2
  %r2306 = sub nuw nsw i64 %r2271, 7
  %r2307 = inttoptr i64 %r2306 to ptr
  %r2308 = load i8, ptr %r2307, align 1
  %r2309 = and i8 %r2308, -128
  %r2310 = icmp eq i8 %r2309, 0
  %r2311 = and i1 %r2305, %r2310
  br i1 %r2311, label %plen.elem.meta.484, label %plen.ic.miss.482

plen.ic.shape.471:                                ; preds = %plen.elem.store.485, %plen.elem.meta.484
  %r2301 = icmp ne ptr %r2300, null
  br i1 %r2301, label %plen.ic.shape.probe.472, label %plen.ic.miss.482

plen.ic.shape.probe.472:                          ; preds = %plen.ic.shape.471
  %r2323 = inttoptr i64 %r2271 to ptr
  %r2324 = load i32, ptr %r2323, align 4
  %r2325 = add nuw nsw i64 %r2271, 4
  %r2326 = inttoptr i64 %r2325 to ptr
  %r2327 = load i32, ptr %r2326, align 4
  %r2328 = zext i32 %r2324 to i64
  %r2329 = zext i32 %r2327 to i64
  %r2330 = shl nuw i64 %r2328, 32
  %r2331 = or i64 %r2330, %r2329
  %r2332 = getelementptr i64, ptr %r2300, i64 0
  %r2333 = load i64, ptr %r2332, align 8
  %r2334 = icmp ne i64 %r2333, 0
  br i1 %r2334, label %plen.ic.identity.473, label %plen.ic.miss.482

plen.ic.identity.473:                             ; preds = %plen.ic.shape.probe.472
  %r2335 = and i64 %r2333, -9223372036854775808
  %1 = icmp slt i64 %r2333, 0
  br i1 %1, label %plen.ic.family_meta.475, label %plen.ic.exact.474

plen.ic.exact.474:                                ; preds = %plen.ic.identity.473
  %r2337 = icmp eq i64 %r2331, %r2333
  br i1 %r2337, label %plen.ic.slot.477, label %plen.ic.miss.482

plen.ic.family_meta.475:                          ; preds = %plen.ic.identity.473
  %r2338 = add nuw nsw i64 %r2271, 8
  %r2339 = inttoptr i64 %r2338 to ptr
  %r2340 = load i64, ptr %r2339, align 8
  %r2341 = icmp ne i64 %r2340, 0
  br i1 %r2341, label %plen.ic.family_token.476, label %plen.ic.miss.482

plen.ic.family_token.476:                         ; preds = %plen.ic.family_meta.475
  %r2342 = inttoptr i64 %r2340 to ptr
  %r2343 = getelementptr i64, ptr %r2342, i64 6
  %r2344 = load i64, ptr %r2343, align 8
  %r2345 = icmp eq i64 %r2344, %r2333
  br i1 %r2345, label %plen.ic.slot.477, label %plen.ic.miss.482

plen.ic.slot.477:                                 ; preds = %plen.ic.family_token.476, %plen.ic.exact.474
  %r2346 = getelementptr i64, ptr %r2300, i64 1
  %r2347 = load i64, ptr %r2346, align 8
  %r2348 = getelementptr i64, ptr %r2300, i64 2
  %r2349 = load i64, ptr %r2348, align 8
  %r2350 = icmp ult i64 %r2347, %r2349
  br i1 %r2350, label %plen.ic.inline.478, label %plen.ic.spill_meta.479

plen.ic.inline.478:                               ; preds = %plen.ic.slot.477
  %r2351 = shl i64 %r2347, 3
  %r2352 = add i64 %r2351, 16
  %r2353 = add i64 %r2271, %r2352
  %r2354 = inttoptr i64 %r2353 to ptr
  %r2355 = load double, ptr %r2354, align 8
  br label %plen.ic.merge.483

plen.ic.spill_meta.479:                           ; preds = %plen.ic.slot.477
  %r2356 = add nuw nsw i64 %r2271, 8
  %r2357 = inttoptr i64 %r2356 to ptr
  %r2358 = load i64, ptr %r2357, align 8
  %r2359 = icmp ne i64 %r2358, 0
  br i1 %r2359, label %plen.ic.spill_ptr.480, label %plen.ic.miss.482

plen.ic.spill_ptr.480:                            ; preds = %plen.ic.spill_meta.479
  %r2360 = inttoptr i64 %r2358 to ptr
  %r2361 = getelementptr i64, ptr %r2360, i64 4
  %r2362 = load i64, ptr %r2361, align 8
  %r2363 = icmp ne i64 %r2362, 0
  %r2364 = select i1 %r2363, i64 %r2362, i64 %r2358
  %r2365 = inttoptr i64 %r2364 to ptr
  %r2366 = load i32, ptr %r2365, align 4
  %r2367 = zext i32 %r2366 to i64
  %r2368 = icmp ult i64 %r2347, %r2367
  %r2369 = and i1 %r2363, %r2368
  br i1 %r2369, label %plen.ic.spill_load.481, label %plen.ic.miss.482

plen.ic.spill_load.481:                           ; preds = %plen.ic.spill_ptr.480
  %r2370 = add nuw nsw i64 %r2347, 1
  %r2371 = getelementptr inbounds nuw i64, ptr %r2365, i64 %r2370
  %r2372 = load double, ptr %r2371, align 8
  br label %plen.ic.merge.483

plen.ic.miss.482:                                 ; preds = %plen.ic.spill_ptr.480, %plen.ic.spill_meta.479, %plen.ic.family_token.476, %plen.ic.family_meta.475, %plen.ic.exact.474, %plen.ic.shape.probe.472, %plen.ic.shape.471, %plen.ic.header.470, %plen.slow.468
  %statepoint_token705 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r2269, ptr @perry_ic_test_json_cached_template_borrow_ts__23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0971, ptr addrspace(1) %.0928, ptr addrspace(1) %.01011) ]
  %r2373706 = call double @llvm.experimental.gc.result.f64(token %statepoint_token705)
  %r48.0.base.relocated707 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token705, i32 0, i32 0) ; (%.0971, %.0971)
  %r57.0.relocated708 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token705, i32 1, i32 1) ; (%.0928, %.0928)
  %r48.0.relocated709 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token705, i32 0, i32 2) ; (%.0971, %.01011)
  br label %plen.ic.merge.483

plen.ic.merge.483:                                ; preds = %plen.elem.length.486, %plen.ic.miss.482, %plen.ic.spill_load.481, %plen.ic.inline.478
  %.261037 = phi ptr addrspace(1) [ %.01011, %plen.elem.length.486 ], [ %.01011, %plen.ic.inline.478 ], [ %.01011, %plen.ic.spill_load.481 ], [ %r48.0.relocated709, %plen.ic.miss.482 ]
  %.26997 = phi ptr addrspace(1) [ %.0971, %plen.elem.length.486 ], [ %.0971, %plen.ic.inline.478 ], [ %.0971, %plen.ic.spill_load.481 ], [ %r48.0.base.relocated707, %plen.ic.miss.482 ]
  %.37965 = phi ptr addrspace(1) [ %.0928, %plen.elem.length.486 ], [ %.0928, %plen.ic.inline.478 ], [ %.0928, %plen.ic.spill_load.481 ], [ %r57.0.relocated708, %plen.ic.miss.482 ]
  %r2374 = phi double [ %r2322, %plen.elem.length.486 ], [ %r2355, %plen.ic.inline.478 ], [ %r2372, %plen.ic.spill_load.481 ], [ %r2373706, %plen.ic.miss.482 ]
  br label %plen.merge.469

plen.elem.meta.484:                               ; preds = %plen.ic.header.470
  %r2312 = add nuw nsw i64 %r2271, 8
  %r2313 = inttoptr i64 %r2312 to ptr
  %r2314 = load i64, ptr %r2313, align 8
  %r2315 = icmp ne i64 %r2314, 0
  br i1 %r2315, label %plen.elem.store.485, label %plen.ic.shape.471

plen.elem.store.485:                              ; preds = %plen.elem.meta.484
  %r2316 = inttoptr i64 %r2314 to ptr
  %r2317 = getelementptr i64, ptr %r2316, i64 12
  %r2318 = load i64, ptr %r2317, align 8
  %r2319 = icmp ne i64 %r2318, 0
  br i1 %r2319, label %plen.elem.length.486, label %plen.ic.shape.471

plen.elem.length.486:                             ; preds = %plen.elem.store.485
  %r2320 = inttoptr i64 %r2318 to ptr
  %r2321 = load i32, ptr %r2320, align 4
  %r2322 = uitofp i32 %r2321 to double
  br label %plen.ic.merge.483

gcpoll.487:                                       ; preds = %plen.merge.469
  %statepoint_token710 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.25996, ptr addrspace(1) %.36964, ptr addrspace(1) %.251036) ]
  %r48.0.base.relocated711 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token710, i32 0, i32 0) ; (%.25996, %.25996)
  %r57.0.relocated712 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token710, i32 1, i32 1) ; (%.36964, %.36964)
  %r48.0.relocated713 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token710, i32 0, i32 2) ; (%.25996, %.251036)
  br label %gcpoll.done.488

gcpoll.done.488:                                  ; preds = %gcpoll.487, %plen.merge.469
  %.271038 = phi ptr addrspace(1) [ %r48.0.relocated713, %gcpoll.487 ], [ %.251036, %plen.merge.469 ]
  %.27998 = phi ptr addrspace(1) [ %r48.0.base.relocated711, %gcpoll.487 ], [ %.25996, %plen.merge.469 ]
  %.38966 = phi ptr addrspace(1) [ %r57.0.relocated712, %gcpoll.487 ], [ %.36964, %plen.merge.469 ]
  %r2379 = icmp eq i64 %r2377, 9222246136947933188
  br i1 %r2379, label %for.body.463, label %for.exit.465

arr.fast.489:                                     ; preds = %arr.guard.range.495
  %r2446 = zext i32 %r2266.0 to i64
  %r2447 = shl nuw nsw i64 %r2446, 3
  %r2448 = add nuw nsw i64 %r2447, 8
  %r2449 = add i64 %r2405, %r2448
  %r2450 = inttoptr i64 %r2449 to ptr
  %r2451 = load double, ptr %r2450, align 8
  %r2452 = bitcast double %r2451 to i64
  %r2453 = icmp eq i64 %r2452, 9222246136947933200
  %r2455 = select i1 %r2453, double 0x7FFC000000000001, double %r2451
  br label %arr.merge.492

arr.fallback.490:                                 ; preds = %arr.guard.live.494, %arr.guard.deref.493, %for.body.463
  %r2444 = sitofp i32 %r2266.0 to double
  %statepoint_token714 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 8988321885632593944, double %r2383, double %r2444, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.27998, ptr addrspace(1) %.38966, ptr addrspace(1) %.271038) ]
  %r2445715 = call double @llvm.experimental.gc.result.f64(token %statepoint_token714)
  %r48.0.base.relocated716 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token714, i32 0, i32 0) ; (%.27998, %.27998)
  %r57.0.relocated717 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token714, i32 1, i32 1) ; (%.38966, %.38966)
  %r48.0.relocated718 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token714, i32 0, i32 2) ; (%.27998, %.271038)
  br label %arr.merge.492

arr.guard.oob.491:                                ; preds = %arr.guard.range.495
  br label %arr.merge.492

arr.merge.492:                                    ; preds = %arr.guard.oob.491, %arr.fallback.490, %arr.fast.489
  %.281039 = phi ptr addrspace(1) [ %.271038, %arr.fast.489 ], [ %.271038, %arr.guard.oob.491 ], [ %r48.0.relocated718, %arr.fallback.490 ]
  %.28999 = phi ptr addrspace(1) [ %.27998, %arr.fast.489 ], [ %.27998, %arr.guard.oob.491 ], [ %r48.0.base.relocated716, %arr.fallback.490 ]
  %.39967 = phi ptr addrspace(1) [ %.38966, %arr.fast.489 ], [ %.38966, %arr.guard.oob.491 ], [ %r57.0.relocated717, %arr.fallback.490 ]
  %r2456 = phi double [ %r2455, %arr.fast.489 ], [ %r2445715, %arr.fallback.490 ], [ 0x7FFC000000000001, %arr.guard.oob.491 ]
  %rs4gc.b31 = bitcast double %r2456 to i64
  %rs4gc.s31 = inttoptr i64 %rs4gc.b31 to ptr addrspace(1)
  %r2457 = bitcast double %r2456 to i64
  %r2458 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2459 = icmp ne i32 %r2458, 0
  br i1 %r2459, label %shadow.root.barrier.496, label %shadow.root.barrier.done.497

arr.guard.deref.493:                              ; preds = %for.body.463
  %r2391 = bitcast double %r2383 to i64
  %r2392 = and i64 %r2391, 281474976710655
  %r2393 = sub nsw i64 %r2392, 8
  %r2394 = inttoptr i64 %r2393 to ptr
  %r2395 = load i8, ptr %r2394, align 1
  %r2396 = icmp eq i8 %r2395, 1
  %r2397 = sub nsw i64 %r2392, 7
  %r2398 = inttoptr i64 %r2397 to ptr
  %r2399 = load i8, ptr %r2398, align 1
  %r2400 = and i8 %r2399, -128
  %r2401 = icmp ne i8 %r2400, 0
  %r2402 = inttoptr i64 %r2392 to ptr
  %r2403 = load i64, ptr %r2402, align 8
  %r2404 = and i1 %r2396, %r2401
  %r2405 = select i1 %r2404, i64 %r2403, i64 %r2392
  %r2406 = lshr i64 %r2405, 48
  %r2407 = icmp eq i64 %r2406, 0
  %r2408 = icmp ugt i64 %r2405, 1048575
  %r2409 = and i1 %r2407, %r2408
  br i1 %r2409, label %arr.guard.live.494, label %arr.fallback.490

arr.guard.live.494:                               ; preds = %arr.guard.deref.493
  %r2410 = sub nuw i64 %r2405, 8
  %r2411 = inttoptr i64 %r2410 to ptr
  %r2412 = load i8, ptr %r2411, align 1
  %r2413 = icmp eq i8 %r2412, 1
  %r2414 = sub nuw i64 %r2405, 7
  %r2415 = inttoptr i64 %r2414 to ptr
  %r2416 = load i8, ptr %r2415, align 1
  %r2417 = and i8 %r2416, -128
  %r2418 = icmp eq i8 %r2417, 0
  %r2419 = sub nuw i64 %r2405, 6
  %r2420 = inttoptr i64 %r2419 to ptr
  %r2421 = load i16, ptr %r2420, align 2
  %r2422 = and i16 %r2421, 1024
  %r2423 = icmp eq i16 %r2422, 0
  %r2424 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r2425 = icmp eq i8 %r2424, 0
  %r2426 = inttoptr i64 %r2405 to ptr
  %r2427 = load i32, ptr %r2426, align 4
  %r2428 = getelementptr i8, ptr %r2426, i64 4
  %r2429 = load i32, ptr %r2428, align 4
  %r2430 = icmp slt i32 %r2266.0, 0
  %r2431 = icmp eq i1 %r2430, false
  %r2433 = icmp ule i32 %r2427, 16000000
  %r2434 = icmp ule i32 %r2429, 16000000
  %r2435 = icmp ule i32 %r2427, %r2429
  %r2436 = and i1 %r2413, %r2418
  %r2437 = and i1 %r2436, %r2423
  %r2438 = and i1 %r2437, %r2425
  %r2439 = and i1 %r2438, %r2431
  %r2440 = and i1 %r2439, %r2433
  %r2441 = and i1 %r2440, %r2434
  %r2442 = and i1 %r2441, %r2435
  br i1 %r2442, label %arr.guard.range.495, label %arr.fallback.490

arr.guard.range.495:                              ; preds = %arr.guard.live.494
  %r2432 = icmp ult i32 %r2266.0, %r2427
  br i1 %r2432, label %arr.fast.489, label %arr.guard.oob.491

shadow.root.barrier.496:                          ; preds = %arr.merge.492
  call void @js_write_barrier_root_nanbox(i64 %r2457) #7
  br label %shadow.root.barrier.done.497

shadow.root.barrier.done.497:                     ; preds = %shadow.root.barrier.496, %arr.merge.492
  %r2460.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31 to i64
  %r2460.rs4o = call i64 asm "", "=r,0"(i64 %r2460.rs4i) #7
  %r2460 = bitcast i64 %r2460.rs4o to double
  %r2464 = bitcast double %r2460 to i64
  %r2465 = and i64 %r2464, 281474976710655
  %r2466 = load double, ptr @test_json_cached_template_borrow_ts_.str.0.handle, align 8
  %r2467 = bitcast double %r2466 to i64
  %r2468 = and i64 %r2467, 281474976710655
  %r2469 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r2470 = icmp eq i8 %r2469, 0
  %r2471 = lshr i64 %r2464, 48
  %r2472 = icmp eq i64 %r2471, 32765
  %r2473 = icmp ugt i64 %r2465, 1048575
  %r2474 = and i1 %r2472, %r2473
  %r2475 = and i1 %r2474, %r2470
  br i1 %r2475, label %class_field_inline.deref.501, label %class_field_inline.guardcall.502

class_field_get.fast.498:                         ; preds = %class_field_inline.guardcall.502, %class_field_inline.deref.501
  %r3501.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31 to i64
  %r3501.rs4o = call i64 asm "", "=r,0"(i64 %r3501.rs4i) #7
  %r3501 = bitcast i64 %r3501.rs4o to double
  %r3502 = bitcast double %r3501 to i64
  %r3503 = and i64 %r3502, 281474976710655
  %r2500 = inttoptr i64 %r3503 to ptr
  %r3497.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31 to i64
  %r3497.rs4o = call i64 asm "", "=r,0"(i64 %r3497.rs4i) #7
  %r3497 = bitcast i64 %r3497.rs4o to double
  %r3498 = bitcast double %r3497 to i64
  %r3499 = and i64 %r3498, 281474976710655
  %r3500 = inttoptr i64 %r3499 to ptr
  %r2501 = getelementptr i8, ptr %r3500, i64 16
  %r2502 = getelementptr double, ptr %r2501, i64 0
  %r2503 = load double, ptr %r2502, align 8
  br label %class_field_get.merge.500

class_field_get.fallback.499:                     ; preds = %class_field_inline.guardcall.502
  %r3495.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31 to i64
  %r3495.rs4o = call i64 asm "", "=r,0"(i64 %r3495.rs4i) #7
  %r3495 = bitcast i64 %r3495.rs4o to double
  %r3496 = bitcast double %r3495 to i64
  %r2504 = icmp eq i64 %r3496, 9222246136947933185
  %r3493.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31 to i64
  %r3493.rs4o = call i64 asm "", "=r,0"(i64 %r3493.rs4i) #7
  %r3493 = bitcast i64 %r3493.rs4o to double
  %r3494 = bitcast double %r3493 to i64
  %r2505 = icmp eq i64 %r3494, 9222246136947933186
  %r2506 = or i1 %r2504, %r2505
  br i1 %r2506, label %class_field_get.throw_nullish.503, label %class_field_get.fallback_lookup.504

class_field_get.merge.500:                        ; preds = %class_field_get.fallback_lookup.504, %class_field_get.fast.498
  %.01175 = phi ptr addrspace(1) [ %rs4gc.s31, %class_field_get.fast.498 ], [ %rs4gc.s31.relocated727, %class_field_get.fallback_lookup.504 ]
  %.291040 = phi ptr addrspace(1) [ %.281039, %class_field_get.fast.498 ], [ %r48.0.relocated730, %class_field_get.fallback_lookup.504 ]
  %.291000 = phi ptr addrspace(1) [ %.28999, %class_field_get.fast.498 ], [ %r48.0.base.relocated728, %class_field_get.fallback_lookup.504 ]
  %.40968 = phi ptr addrspace(1) [ %.39967, %class_field_get.fast.498 ], [ %r57.0.relocated729, %class_field_get.fallback_lookup.504 ]
  %r2509 = phi double [ %r2503, %class_field_get.fast.498 ], [ %r2508726, %class_field_get.fallback_lookup.504 ]
  %statepoint_token719 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r2509, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01175, ptr addrspace(1) %.291000, ptr addrspace(1) %.40968, ptr addrspace(1) %.291040) ]
  %r2510720 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token719)
  %rs4gc.s31.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token719, i32 0, i32 0) ; (%.01175, %.01175)
  %r48.0.base.relocated721 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token719, i32 1, i32 1) ; (%.291000, %.291000)
  %r57.0.relocated722 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token719, i32 2, i32 2) ; (%.40968, %.40968)
  %r48.0.relocated723 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token719, i32 1, i32 3) ; (%.291000, %.291040)
  %r2511 = bitcast i64 %r2510720 to double
  %rs4gc.s32 = inttoptr i64 %r2510720 to ptr addrspace(1)
  %r2512.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s32 to i64
  %r2512 = call i64 asm "", "=r,0"(i64 %r2512.rs4i) #7
  %r2513 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2514 = icmp ne i32 %r2513, 0
  br i1 %r2514, label %shadow.root.barrier.505, label %shadow.root.barrier.done.506

class_field_inline.deref.501:                     ; preds = %shadow.root.barrier.done.497
  %r2476 = inttoptr i64 %r2465 to ptr
  %r2477 = getelementptr i8, ptr %r2476, i64 -8
  %r2478 = load i8, ptr %r2477, align 1
  %r2479 = icmp eq i8 %r2478, 2
  %r2480 = getelementptr i8, ptr %r2476, i64 -7
  %r2481 = load i8, ptr %r2480, align 1
  %r2482 = and i8 %r2481, -128
  %r2483 = icmp eq i8 %r2482, 0
  %r2484 = getelementptr i8, ptr %r2476, i64 -6
  %r2485 = load i16, ptr %r2484, align 2
  %r2486 = getelementptr i8, ptr %r2476, i64 0
  %r2487 = load i32, ptr %r2486, align 4
  %r2488 = icmp eq i32 %r2487, 1
  %r2489 = getelementptr i8, ptr %r2476, i64 4
  %r2490 = load i32, ptr %r2489, align 4
  %r2491 = icmp eq i32 %r2490, %r2462
  %r2492 = and i1 %r2479, %r2483
  %r2493 = and i1 %r2492, %r2488
  %r2494 = and i1 %r2493, %r2491
  %r2495 = and i16 %r2485, 3072
  %r2496 = icmp eq i16 %r2495, 0
  %r2497 = and i1 %r2494, %r2496
  br i1 %r2497, label %class_field_get.fast.498, label %class_field_inline.guardcall.502

class_field_inline.guardcall.502:                 ; preds = %class_field_inline.deref.501, %shadow.root.barrier.done.497
  %r2498 = call i32 @js_typed_feedback_class_field_get_guard(i64 8988321885632593945, double %r2460, i32 1, i32 %r2462, i64 %r2468, i32 0, i32 0) #7
  %r2499 = icmp ne i32 %r2498, 0
  br i1 %r2499, label %class_field_get.fast.498, label %class_field_get.fallback.499

class_field_get.throw_nullish.503:                ; preds = %class_field_get.fallback.499
  %r2507 = zext i1 %r2505 to i32
  %statepoint_token724 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2507, ptr @test_json_cached_template_borrow_ts_.str.0.bytes, i64 5, i32 0, i32 0)
  unreachable

class_field_get.fallback_lookup.504:              ; preds = %class_field_get.fallback.499
  %r3488.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31 to i64
  %r3488.rs4o = call i64 asm "", "=r,0"(i64 %r3488.rs4i) #7
  %r3488 = bitcast i64 %r3488.rs4o to double
  %r3489 = bitcast double %r3488 to i64
  %r3490 = load double, ptr @test_json_cached_template_borrow_ts_.str.0.handle, align 8
  %r3491 = bitcast double %r3490 to i64
  %r3492 = and i64 %r3491, 281474976710655
  %statepoint_token725 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3489, i64 %r3492, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s31, ptr addrspace(1) %.28999, ptr addrspace(1) %.39967, ptr addrspace(1) %.281039) ]
  %r2508726 = call double @llvm.experimental.gc.result.f64(token %statepoint_token725)
  %rs4gc.s31.relocated727 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token725, i32 0, i32 0) ; (%rs4gc.s31, %rs4gc.s31)
  %r48.0.base.relocated728 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token725, i32 1, i32 1) ; (%.28999, %.28999)
  %r57.0.relocated729 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token725, i32 2, i32 2) ; (%.39967, %.39967)
  %r48.0.relocated730 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token725, i32 1, i32 3) ; (%.28999, %.281039)
  br label %class_field_get.merge.500

shadow.root.barrier.505:                          ; preds = %class_field_get.merge.500
  call void @js_write_barrier_root_nanbox(i64 %r2512) #7
  br label %shadow.root.barrier.done.506

shadow.root.barrier.done.506:                     ; preds = %shadow.root.barrier.505, %class_field_get.merge.500
  %r2515.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated to i64
  %r2515.rs4o = call i64 asm "", "=r,0"(i64 %r2515.rs4i) #7
  %r2515 = bitcast i64 %r2515.rs4o to double
  %r2517 = bitcast double %r2515 to i64
  %r2518 = and i64 %r2517, 281474976710655
  %r2519 = load double, ptr @test_json_cached_template_borrow_ts_.str.1.handle, align 8
  %r2520 = bitcast double %r2519 to i64
  %r2521 = and i64 %r2520, 281474976710655
  %r2522 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r2523 = icmp eq i8 %r2522, 0
  %r2524 = lshr i64 %r2517, 48
  %r2525 = icmp eq i64 %r2524, 32765
  %r2526 = icmp ugt i64 %r2518, 1048575
  %r2527 = and i1 %r2525, %r2526
  %r2528 = and i1 %r2527, %r2523
  br i1 %r2528, label %class_field_inline.deref.510, label %class_field_inline.guardcall.511

class_field_get.fast.507:                         ; preds = %class_field_inline.guardcall.511, %class_field_inline.deref.510
  %r3485.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated to i64
  %r3485.rs4o = call i64 asm "", "=r,0"(i64 %r3485.rs4i) #7
  %r3485 = bitcast i64 %r3485.rs4o to double
  %r3486 = bitcast double %r3485 to i64
  %r3487 = and i64 %r3486, 281474976710655
  %r2553 = inttoptr i64 %r3487 to ptr
  %r3481.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated to i64
  %r3481.rs4o = call i64 asm "", "=r,0"(i64 %r3481.rs4i) #7
  %r3481 = bitcast i64 %r3481.rs4o to double
  %r3482 = bitcast double %r3481 to i64
  %r3483 = and i64 %r3482, 281474976710655
  %r3484 = inttoptr i64 %r3483 to ptr
  %r2554 = getelementptr i8, ptr %r3484, i64 16
  %r2555 = getelementptr double, ptr %r2554, i64 1
  %r2556 = load double, ptr %r2555, align 8
  br label %class_field_get.merge.509

class_field_get.fallback.508:                     ; preds = %class_field_inline.guardcall.511
  %r3479.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated to i64
  %r3479.rs4o = call i64 asm "", "=r,0"(i64 %r3479.rs4i) #7
  %r3479 = bitcast i64 %r3479.rs4o to double
  %r3480 = bitcast double %r3479 to i64
  %r2557 = icmp eq i64 %r3480, 9222246136947933185
  %r3477.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated to i64
  %r3477.rs4o = call i64 asm "", "=r,0"(i64 %r3477.rs4i) #7
  %r3477 = bitcast i64 %r3477.rs4o to double
  %r3478 = bitcast double %r3477 to i64
  %r2558 = icmp eq i64 %r3478, 9222246136947933186
  %r2559 = or i1 %r2557, %r2558
  br i1 %r2559, label %class_field_get.throw_nullish.512, label %class_field_get.fallback_lookup.513

class_field_get.merge.509:                        ; preds = %class_field_get.fallback_lookup.513, %class_field_get.fast.507
  %.01181 = phi ptr addrspace(1) [ %rs4gc.s32, %class_field_get.fast.507 ], [ %rs4gc.s32.relocated, %class_field_get.fallback_lookup.513 ]
  %.11176 = phi ptr addrspace(1) [ %rs4gc.s31.relocated, %class_field_get.fast.507 ], [ %rs4gc.s31.relocated734, %class_field_get.fallback_lookup.513 ]
  %.301041 = phi ptr addrspace(1) [ %r48.0.relocated723, %class_field_get.fast.507 ], [ %r48.0.relocated737, %class_field_get.fallback_lookup.513 ]
  %.301001 = phi ptr addrspace(1) [ %r48.0.base.relocated721, %class_field_get.fast.507 ], [ %r48.0.base.relocated735, %class_field_get.fallback_lookup.513 ]
  %.41969 = phi ptr addrspace(1) [ %r57.0.relocated722, %class_field_get.fast.507 ], [ %r57.0.relocated736, %class_field_get.fallback_lookup.513 ]
  %r2562 = phi double [ %r2556, %class_field_get.fast.507 ], [ %r2561733, %class_field_get.fallback_lookup.513 ]
  %r2563.rs4i = ptrtoint ptr addrspace(1) %.01181 to i64
  %r2563 = call i64 asm "", "=r,0"(i64 %r2563.rs4i) #7
  %r2564 = bitcast i64 %r2563 to double
  %r2565 = bitcast double %r2562 to i64
  %r2566 = and i64 %r2563, 9221120237041090560
  %r2567 = icmp ne i64 %r2566, 9221120237041090560
  %r2568 = and i64 %r2565, 9221120237041090560
  %r2569 = icmp ne i64 %r2568, 9221120237041090560
  %r2570 = and i1 %r2567, %r2569
  br i1 %r2570, label %dyncmp.num.514, label %dyncmp.slow.515

class_field_inline.deref.510:                     ; preds = %shadow.root.barrier.done.506
  %r2529 = inttoptr i64 %r2518 to ptr
  %r2530 = getelementptr i8, ptr %r2529, i64 -8
  %r2531 = load i8, ptr %r2530, align 1
  %r2532 = icmp eq i8 %r2531, 2
  %r2533 = getelementptr i8, ptr %r2529, i64 -7
  %r2534 = load i8, ptr %r2533, align 1
  %r2535 = and i8 %r2534, -128
  %r2536 = icmp eq i8 %r2535, 0
  %r2537 = getelementptr i8, ptr %r2529, i64 -6
  %r2538 = load i16, ptr %r2537, align 2
  %r2539 = getelementptr i8, ptr %r2529, i64 0
  %r2540 = load i32, ptr %r2539, align 4
  %r2541 = icmp eq i32 %r2540, 1
  %r2542 = getelementptr i8, ptr %r2529, i64 4
  %r2543 = load i32, ptr %r2542, align 4
  %r2544 = icmp eq i32 %r2543, %r2462
  %r2545 = and i1 %r2532, %r2536
  %r2546 = and i1 %r2545, %r2541
  %r2547 = and i1 %r2546, %r2544
  %r2548 = and i16 %r2538, 3072
  %r2549 = icmp eq i16 %r2548, 0
  %r2550 = and i1 %r2547, %r2549
  br i1 %r2550, label %class_field_get.fast.507, label %class_field_inline.guardcall.511

class_field_inline.guardcall.511:                 ; preds = %class_field_inline.deref.510, %shadow.root.barrier.done.506
  %r2551 = call i32 @js_typed_feedback_class_field_get_guard(i64 8988321885632593946, double %r2515, i32 1, i32 %r2462, i64 %r2521, i32 1, i32 0) #7
  %r2552 = icmp ne i32 %r2551, 0
  br i1 %r2552, label %class_field_get.fast.507, label %class_field_get.fallback.508

class_field_get.throw_nullish.512:                ; preds = %class_field_get.fallback.508
  %r2560 = zext i1 %r2558 to i32
  %statepoint_token731 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2560, ptr @test_json_cached_template_borrow_ts_.str.1.bytes, i64 8, i32 0, i32 0)
  unreachable

class_field_get.fallback_lookup.513:              ; preds = %class_field_get.fallback.508
  %r3472.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated to i64
  %r3472.rs4o = call i64 asm "", "=r,0"(i64 %r3472.rs4i) #7
  %r3472 = bitcast i64 %r3472.rs4o to double
  %r3473 = bitcast double %r3472 to i64
  %r3474 = load double, ptr @test_json_cached_template_borrow_ts_.str.1.handle, align 8
  %r3475 = bitcast double %r3474 to i64
  %r3476 = and i64 %r3475, 281474976710655
  %statepoint_token732 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3473, i64 %r3476, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s31.relocated, ptr addrspace(1) %r48.0.base.relocated721, ptr addrspace(1) %r57.0.relocated722, ptr addrspace(1) %rs4gc.s32, ptr addrspace(1) %r48.0.relocated723) ]
  %r2561733 = call double @llvm.experimental.gc.result.f64(token %statepoint_token732)
  %rs4gc.s31.relocated734 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token732, i32 0, i32 0) ; (%rs4gc.s31.relocated, %rs4gc.s31.relocated)
  %r48.0.base.relocated735 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token732, i32 1, i32 1) ; (%r48.0.base.relocated721, %r48.0.base.relocated721)
  %r57.0.relocated736 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token732, i32 2, i32 2) ; (%r57.0.relocated722, %r57.0.relocated722)
  %rs4gc.s32.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token732, i32 3, i32 3) ; (%rs4gc.s32, %rs4gc.s32)
  %r48.0.relocated737 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token732, i32 1, i32 4) ; (%r48.0.base.relocated721, %r48.0.relocated723)
  br label %class_field_get.merge.509

dyncmp.num.514:                                   ; preds = %class_field_get.merge.509
  %r2571 = fcmp oeq double %r2564, %r2562
  %r2572 = select i1 %r2571, i64 9222246136947933188, i64 9222246136947933187
  br label %dyncmp.merge.516

dyncmp.slow.515:                                  ; preds = %class_field_get.merge.509
  %statepoint_token738 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i64)) @js_eq, i32 2, i32 0, i64 %r2563, i64 %r2565, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11176, ptr addrspace(1) %.301001, ptr addrspace(1) %.41969, ptr addrspace(1) %.301041) ]
  %r2573739 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token738)
  %rs4gc.s31.relocated740 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token738, i32 0, i32 0) ; (%.11176, %.11176)
  %r48.0.base.relocated741 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token738, i32 1, i32 1) ; (%.301001, %.301001)
  %r57.0.relocated742 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token738, i32 2, i32 2) ; (%.41969, %.41969)
  %r48.0.relocated743 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token738, i32 1, i32 3) ; (%.301001, %.301041)
  br label %dyncmp.merge.516

dyncmp.merge.516:                                 ; preds = %dyncmp.slow.515, %dyncmp.num.514
  %.21177 = phi ptr addrspace(1) [ %.11176, %dyncmp.num.514 ], [ %rs4gc.s31.relocated740, %dyncmp.slow.515 ]
  %.311042 = phi ptr addrspace(1) [ %.301041, %dyncmp.num.514 ], [ %r48.0.relocated743, %dyncmp.slow.515 ]
  %.311002 = phi ptr addrspace(1) [ %.301001, %dyncmp.num.514 ], [ %r48.0.base.relocated741, %dyncmp.slow.515 ]
  %.42970 = phi ptr addrspace(1) [ %.41969, %dyncmp.num.514 ], [ %r57.0.relocated742, %dyncmp.slow.515 ]
  %r2574 = phi i64 [ %r2572, %dyncmp.num.514 ], [ %r2573739, %dyncmp.slow.515 ]
  %r2575 = icmp eq i64 %r2574, 9222246136947933188
  %r2576 = xor i1 %r2575, true
  %r2577 = select i1 %r2576, i64 9222246136947933188, i64 9222246136947933187
  %r2578 = bitcast i64 %r2577 to double
  %r2579 = icmp eq i64 %r2577, 9222246136947933188
  br i1 %r2579, label %if.then.517, label %if.else.518

if.then.517:                                      ; preds = %dyncmp.merge.516
  %r2580 = load double, ptr @test_json_cached_template_borrow_ts_.str.14.handle, align 8
  %statepoint_token744 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_error_new_from_value, i32 1, i32 0, double %r2580, i32 0, i32 0)
  %r2581745 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token744)
  %r2582 = or i64 %r2581745, 9222527611924643840
  %r2583 = bitcast i64 %r2582 to double
  %statepoint_token746 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (double)) @js_throw, i32 1, i32 0, double %r2583, i32 0, i32 0)
  unreachable

if.else.518:                                      ; preds = %dyncmp.merge.516
  br label %if.merge.519

if.merge.519:                                     ; preds = %if.else.518
  %statepoint_token747 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 4, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.21177, ptr addrspace(1) %.311002, ptr addrspace(1) %.42970, ptr addrspace(1) %.311042) ]
  %r2584748 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token747)
  %rs4gc.s31.relocated749 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token747, i32 0, i32 0) ; (%.21177, %.21177)
  %r48.0.base.relocated750 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token747, i32 1, i32 1) ; (%.311002, %.311002)
  %r57.0.relocated751 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token747, i32 2, i32 2) ; (%.42970, %.42970)
  %r48.0.relocated752 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token747, i32 1, i32 3) ; (%.311002, %.311042)
  %rs4gc.s33 = inttoptr i64 %r2584748 to ptr addrspace(1)
  %r2585.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s33 to i64
  %r2585 = call i64 asm "", "=r,0"(i64 %r2585.rs4i) #7
  %r2586 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2587 = icmp ne i32 %r2586, 0
  br i1 %r2587, label %shadow.root.barrier.520, label %shadow.root.barrier.done.521

shadow.root.barrier.520:                          ; preds = %if.merge.519
  call void @js_write_barrier_root_nanbox(i64 %r2585) #7
  br label %shadow.root.barrier.done.521

shadow.root.barrier.done.521:                     ; preds = %shadow.root.barrier.520, %if.merge.519
  %r2588 = load double, ptr @test_json_cached_template_borrow_ts_.str.15.handle, align 8
  %r2589.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s33 to i64
  %r2589 = call i64 asm "", "=r,0"(i64 %r2589.rs4i) #7
  %statepoint_token753 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r2589, double %r2588, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s31.relocated749, ptr addrspace(1) %r48.0.base.relocated750, ptr addrspace(1) %r57.0.relocated751, ptr addrspace(1) %r48.0.relocated752) ]
  %r2590754 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token753)
  %rs4gc.s31.relocated755 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token753, i32 0, i32 0) ; (%rs4gc.s31.relocated749, %rs4gc.s31.relocated749)
  %r48.0.base.relocated756 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token753, i32 1, i32 1) ; (%r48.0.base.relocated750, %r48.0.base.relocated750)
  %r57.0.relocated757 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token753, i32 2, i32 2) ; (%r57.0.relocated751, %r57.0.relocated751)
  %r48.0.relocated758 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token753, i32 1, i32 3) ; (%r48.0.base.relocated750, %r48.0.relocated752)
  %rs4gc.s34 = inttoptr i64 %r2590754 to ptr addrspace(1)
  %r2591.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s34 to i64
  %r2591 = call i64 asm "", "=r,0"(i64 %r2591.rs4i) #7
  %r2592 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2593 = icmp ne i32 %r2592, 0
  br i1 %r2593, label %shadow.root.barrier.522, label %shadow.root.barrier.done.523

shadow.root.barrier.522:                          ; preds = %shadow.root.barrier.done.521
  call void @js_write_barrier_root_nanbox(i64 %r2591) #7
  br label %shadow.root.barrier.done.523

shadow.root.barrier.done.523:                     ; preds = %shadow.root.barrier.522, %shadow.root.barrier.done.521
  %r2595 = sitofp i32 %r2266.0 to double
  %r2596.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s34 to i64
  %r2596 = call i64 asm "", "=r,0"(i64 %r2596.rs4i) #7
  %statepoint_token759 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r2596, double %r2595, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s31.relocated755, ptr addrspace(1) %r48.0.base.relocated756, ptr addrspace(1) %r57.0.relocated757, ptr addrspace(1) %r48.0.relocated758) ]
  %r2597760 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token759)
  %rs4gc.s31.relocated761 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token759, i32 0, i32 0) ; (%rs4gc.s31.relocated755, %rs4gc.s31.relocated755)
  %r48.0.base.relocated762 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token759, i32 1, i32 1) ; (%r48.0.base.relocated756, %r48.0.base.relocated756)
  %r57.0.relocated763 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token759, i32 2, i32 2) ; (%r57.0.relocated757, %r57.0.relocated757)
  %r48.0.relocated764 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token759, i32 1, i32 3) ; (%r48.0.base.relocated756, %r48.0.relocated758)
  %rs4gc.s35 = inttoptr i64 %r2597760 to ptr addrspace(1)
  %r2598.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s35 to i64
  %r2598 = call i64 asm "", "=r,0"(i64 %r2598.rs4i) #7
  %r2599 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2600 = icmp ne i32 %r2599, 0
  br i1 %r2600, label %shadow.root.barrier.524, label %shadow.root.barrier.done.525

shadow.root.barrier.524:                          ; preds = %shadow.root.barrier.done.523
  call void @js_write_barrier_root_nanbox(i64 %r2598) #7
  br label %shadow.root.barrier.done.525

shadow.root.barrier.done.525:                     ; preds = %shadow.root.barrier.524, %shadow.root.barrier.done.523
  %r2601.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated761 to i64
  %r2601.rs4o = call i64 asm "", "=r,0"(i64 %r2601.rs4i) #7
  %r2601 = bitcast i64 %r2601.rs4o to double
  %r2603 = bitcast double %r2601 to i64
  %r2604 = and i64 %r2603, 281474976710655
  %r2605 = load double, ptr @test_json_cached_template_borrow_ts_.str.0.handle, align 8
  %r2606 = bitcast double %r2605 to i64
  %r2607 = and i64 %r2606, 281474976710655
  %r2608 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r2609 = icmp eq i8 %r2608, 0
  %r2610 = lshr i64 %r2603, 48
  %r2611 = icmp eq i64 %r2610, 32765
  %r2612 = icmp ugt i64 %r2604, 1048575
  %r2613 = and i1 %r2611, %r2612
  %r2614 = and i1 %r2613, %r2609
  br i1 %r2614, label %class_field_inline.deref.529, label %class_field_inline.guardcall.530

class_field_get.fast.526:                         ; preds = %class_field_inline.guardcall.530, %class_field_inline.deref.529
  %r3469.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated761 to i64
  %r3469.rs4o = call i64 asm "", "=r,0"(i64 %r3469.rs4i) #7
  %r3469 = bitcast i64 %r3469.rs4o to double
  %r3470 = bitcast double %r3469 to i64
  %r3471 = and i64 %r3470, 281474976710655
  %r2639 = inttoptr i64 %r3471 to ptr
  %r3465.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated761 to i64
  %r3465.rs4o = call i64 asm "", "=r,0"(i64 %r3465.rs4i) #7
  %r3465 = bitcast i64 %r3465.rs4o to double
  %r3466 = bitcast double %r3465 to i64
  %r3467 = and i64 %r3466, 281474976710655
  %r3468 = inttoptr i64 %r3467 to ptr
  %r2640 = getelementptr i8, ptr %r3468, i64 16
  %r2641 = getelementptr double, ptr %r2640, i64 0
  %r2642 = load double, ptr %r2641, align 8
  br label %class_field_get.merge.528

class_field_get.fallback.527:                     ; preds = %class_field_inline.guardcall.530
  %r3463.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated761 to i64
  %r3463.rs4o = call i64 asm "", "=r,0"(i64 %r3463.rs4i) #7
  %r3463 = bitcast i64 %r3463.rs4o to double
  %r3464 = bitcast double %r3463 to i64
  %r2643 = icmp eq i64 %r3464, 9222246136947933185
  %r3461.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated761 to i64
  %r3461.rs4o = call i64 asm "", "=r,0"(i64 %r3461.rs4i) #7
  %r3461 = bitcast i64 %r3461.rs4o to double
  %r3462 = bitcast double %r3461 to i64
  %r2644 = icmp eq i64 %r3462, 9222246136947933186
  %r2645 = or i1 %r2643, %r2644
  br i1 %r2645, label %class_field_get.throw_nullish.531, label %class_field_get.fallback_lookup.532

class_field_get.merge.528:                        ; preds = %class_field_get.fallback_lookup.532, %class_field_get.fast.526
  %.01182 = phi ptr addrspace(1) [ %rs4gc.s35, %class_field_get.fast.526 ], [ %rs4gc.s35.relocated, %class_field_get.fallback_lookup.532 ]
  %.31178 = phi ptr addrspace(1) [ %rs4gc.s31.relocated761, %class_field_get.fast.526 ], [ %rs4gc.s31.relocated768, %class_field_get.fallback_lookup.532 ]
  %.321043 = phi ptr addrspace(1) [ %r48.0.relocated764, %class_field_get.fast.526 ], [ %r48.0.relocated771, %class_field_get.fallback_lookup.532 ]
  %.321003 = phi ptr addrspace(1) [ %r48.0.base.relocated762, %class_field_get.fast.526 ], [ %r48.0.base.relocated769, %class_field_get.fallback_lookup.532 ]
  %.43 = phi ptr addrspace(1) [ %r57.0.relocated763, %class_field_get.fast.526 ], [ %r57.0.relocated770, %class_field_get.fallback_lookup.532 ]
  %r2648 = phi double [ %r2642, %class_field_get.fast.526 ], [ %r2647767, %class_field_get.fallback_lookup.532 ]
  %r2649 = bitcast double %r2648 to i64
  %r2650 = and i64 %r2649, 281474976710655
  %r2651 = lshr i64 %r2649, 48
  %r2652 = and i64 %r2651, 65533
  %r2653 = icmp eq i64 %r2652, 32765
  br i1 %r2653, label %pget.recv_ok.534, label %pget.recv_other.538

class_field_inline.deref.529:                     ; preds = %shadow.root.barrier.done.525
  %r2615 = inttoptr i64 %r2604 to ptr
  %r2616 = getelementptr i8, ptr %r2615, i64 -8
  %r2617 = load i8, ptr %r2616, align 1
  %r2618 = icmp eq i8 %r2617, 2
  %r2619 = getelementptr i8, ptr %r2615, i64 -7
  %r2620 = load i8, ptr %r2619, align 1
  %r2621 = and i8 %r2620, -128
  %r2622 = icmp eq i8 %r2621, 0
  %r2623 = getelementptr i8, ptr %r2615, i64 -6
  %r2624 = load i16, ptr %r2623, align 2
  %r2625 = getelementptr i8, ptr %r2615, i64 0
  %r2626 = load i32, ptr %r2625, align 4
  %r2627 = icmp eq i32 %r2626, 1
  %r2628 = getelementptr i8, ptr %r2615, i64 4
  %r2629 = load i32, ptr %r2628, align 4
  %r2630 = icmp eq i32 %r2629, %r2462
  %r2631 = and i1 %r2618, %r2622
  %r2632 = and i1 %r2631, %r2627
  %r2633 = and i1 %r2632, %r2630
  %r2634 = and i16 %r2624, 3072
  %r2635 = icmp eq i16 %r2634, 0
  %r2636 = and i1 %r2633, %r2635
  br i1 %r2636, label %class_field_get.fast.526, label %class_field_inline.guardcall.530

class_field_inline.guardcall.530:                 ; preds = %class_field_inline.deref.529, %shadow.root.barrier.done.525
  %r2637 = call i32 @js_typed_feedback_class_field_get_guard(i64 8988321885632593947, double %r2601, i32 1, i32 %r2462, i64 %r2607, i32 0, i32 0) #7
  %r2638 = icmp ne i32 %r2637, 0
  br i1 %r2638, label %class_field_get.fast.526, label %class_field_get.fallback.527

class_field_get.throw_nullish.531:                ; preds = %class_field_get.fallback.527
  %r2646 = zext i1 %r2644 to i32
  %statepoint_token765 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2646, ptr @test_json_cached_template_borrow_ts_.str.0.bytes, i64 5, i32 0, i32 0)
  unreachable

class_field_get.fallback_lookup.532:              ; preds = %class_field_get.fallback.527
  %r3456.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated761 to i64
  %r3456.rs4o = call i64 asm "", "=r,0"(i64 %r3456.rs4i) #7
  %r3456 = bitcast i64 %r3456.rs4o to double
  %r3457 = bitcast double %r3456 to i64
  %r3458 = load double, ptr @test_json_cached_template_borrow_ts_.str.0.handle, align 8
  %r3459 = bitcast double %r3458 to i64
  %r3460 = and i64 %r3459, 281474976710655
  %statepoint_token766 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3457, i64 %r3460, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s31.relocated761, ptr addrspace(1) %rs4gc.s35, ptr addrspace(1) %r48.0.base.relocated762, ptr addrspace(1) %r57.0.relocated763, ptr addrspace(1) %r48.0.relocated764) ]
  %r2647767 = call double @llvm.experimental.gc.result.f64(token %statepoint_token766)
  %rs4gc.s31.relocated768 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 0, i32 0) ; (%rs4gc.s31.relocated761, %rs4gc.s31.relocated761)
  %rs4gc.s35.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 1, i32 1) ; (%rs4gc.s35, %rs4gc.s35)
  %r48.0.base.relocated769 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 2, i32 2) ; (%r48.0.base.relocated762, %r48.0.base.relocated762)
  %r57.0.relocated770 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 3, i32 3) ; (%r57.0.relocated763, %r57.0.relocated763)
  %r48.0.relocated771 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token766, i32 2, i32 4) ; (%r48.0.base.relocated762, %r48.0.relocated764)
  br label %class_field_get.merge.528

pget.recv_sso.533:                                ; preds = %pget.recv_other.538
  %r2791 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r2792 = bitcast double %r2791 to i64
  %r2793 = and i64 %r2792, 281474976710655
  %statepoint_token772 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2649, i64 %r2793, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31178, ptr addrspace(1) %.321003, ptr addrspace(1) %.43, ptr addrspace(1) %.01182, ptr addrspace(1) %.321043) ]
  %r2794773 = call double @llvm.experimental.gc.result.f64(token %statepoint_token772)
  %rs4gc.s31.relocated774 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token772, i32 0, i32 0) ; (%.31178, %.31178)
  %r48.0.base.relocated775 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token772, i32 1, i32 1) ; (%.321003, %.321003)
  %r57.0.relocated776 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token772, i32 2, i32 2) ; (%.43, %.43)
  %rs4gc.s35.relocated777 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token772, i32 3, i32 3) ; (%.01182, %.01182)
  %r48.0.relocated778 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token772, i32 1, i32 4) ; (%.321003, %.321043)
  br label %pget.recv_merge.537

pget.recv_ok.534:                                 ; preds = %class_field_get.merge.528
  %r2660 = icmp ugt i64 %r2650, 1048575
  br i1 %r2660, label %pic.recv_hdr.555, label %pic.miss.cold.552

pget.recv_bad.535:                                ; preds = %pget.check_class_ref.539
  %r2783 = icmp eq i64 %r2649, 9222246136947933185
  %r2784 = icmp eq i64 %r2649, 9222246136947933186
  %r2785 = or i1 %r2783, %r2784
  br i1 %r2785, label %pget.throw_nullish.562, label %pget.recv_undef_return.563

pget.recv_class_ref.536:                          ; preds = %pget.check_class_ref.539
  %r2656 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r2657 = bitcast double %r2656 to i64
  %r2658 = and i64 %r2657, 281474976710655
  %statepoint_token779 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 8988321885632593948, i64 %r2649, i64 %r2658, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31178, ptr addrspace(1) %.321003, ptr addrspace(1) %.43, ptr addrspace(1) %.01182, ptr addrspace(1) %.321043) ]
  %r2659780 = call double @llvm.experimental.gc.result.f64(token %statepoint_token779)
  %rs4gc.s31.relocated781 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token779, i32 0, i32 0) ; (%.31178, %.31178)
  %r48.0.base.relocated782 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token779, i32 1, i32 1) ; (%.321003, %.321003)
  %r57.0.relocated783 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token779, i32 2, i32 2) ; (%.43, %.43)
  %rs4gc.s35.relocated784 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token779, i32 3, i32 3) ; (%.01182, %.01182)
  %r48.0.relocated785 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token779, i32 1, i32 4) ; (%.321003, %.321043)
  br label %pget.recv_merge.537

pget.recv_merge.537:                              ; preds = %pget.recv_undef_return.563, %pic.merge.554, %pget.recv_class_ref.536, %pget.recv_sso.533
  %.11183 = phi ptr addrspace(1) [ %.21184, %pic.merge.554 ], [ %rs4gc.s35.relocated777, %pget.recv_sso.533 ], [ %rs4gc.s35.relocated784, %pget.recv_class_ref.536 ], [ %rs4gc.s35.relocated812, %pget.recv_undef_return.563 ]
  %.41179 = phi ptr addrspace(1) [ %.51180, %pic.merge.554 ], [ %rs4gc.s31.relocated774, %pget.recv_sso.533 ], [ %rs4gc.s31.relocated781, %pget.recv_class_ref.536 ], [ %rs4gc.s31.relocated809, %pget.recv_undef_return.563 ]
  %.331044 = phi ptr addrspace(1) [ %.341045, %pic.merge.554 ], [ %r48.0.relocated778, %pget.recv_sso.533 ], [ %r48.0.relocated785, %pget.recv_class_ref.536 ], [ %r48.0.relocated813, %pget.recv_undef_return.563 ]
  %.331004 = phi ptr addrspace(1) [ %.341005, %pic.merge.554 ], [ %r48.0.base.relocated775, %pget.recv_sso.533 ], [ %r48.0.base.relocated782, %pget.recv_class_ref.536 ], [ %r48.0.base.relocated810, %pget.recv_undef_return.563 ]
  %.44 = phi ptr addrspace(1) [ %.45, %pic.merge.554 ], [ %r57.0.relocated776, %pget.recv_sso.533 ], [ %r57.0.relocated783, %pget.recv_class_ref.536 ], [ %r57.0.relocated811, %pget.recv_undef_return.563 ]
  %r2795 = phi double [ %r2782, %pic.merge.554 ], [ %r2790808, %pget.recv_undef_return.563 ], [ %r2794773, %pget.recv_sso.533 ], [ %r2659780, %pget.recv_class_ref.536 ]
  %r2796.rs4i = ptrtoint ptr addrspace(1) %.11183 to i64
  %r2796 = call i64 asm "", "=r,0"(i64 %r2796.rs4i) #7
  %statepoint_token786 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r2796, double %r2795, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.331004, ptr addrspace(1) %.44, ptr addrspace(1) %.41179, ptr addrspace(1) %.331044) ]
  %r2797787 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token786)
  %r48.0.base.relocated788 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token786, i32 0, i32 0) ; (%.331004, %.331004)
  %r57.0.relocated789 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token786, i32 1, i32 1) ; (%.44, %.44)
  %rs4gc.s31.relocated790 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token786, i32 2, i32 2) ; (%.41179, %.41179)
  %r48.0.relocated791 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token786, i32 0, i32 3) ; (%.331004, %.331044)
  %rs4gc.s36 = inttoptr i64 %r2797787 to ptr addrspace(1)
  %r2798.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s36 to i64
  %r2798 = call i64 asm "", "=r,0"(i64 %r2798.rs4i) #7
  %r2799 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r2800 = icmp ne i32 %r2799, 0
  br i1 %r2800, label %shadow.root.barrier.564, label %shadow.root.barrier.done.565

pget.recv_other.538:                              ; preds = %class_field_get.merge.528
  %r2654 = icmp eq i64 %r2651, 32761
  br i1 %r2654, label %pget.recv_sso.533, label %pget.check_class_ref.539

pget.check_class_ref.539:                         ; preds = %pget.recv_other.538
  %r2655 = icmp eq i64 %r2651, 32766
  br i1 %r2655, label %pget.recv_class_ref.536, label %pget.recv_bad.535

pic.hit.540:                                      ; preds = %pic.token.556
  %r2685 = getelementptr i64, ptr %r2670, i64 1
  %r2686 = load i64, ptr %r2685, align 8
  %r2687 = and i64 %r2686, 1073741824
  %r2688 = icmp ne i64 %r2687, 0
  br i1 %r2688, label %pic.hit.overflow.557, label %pic.hit.inline.558

pic.hit.live.541:                                 ; preds = %pic.hit.inline.558
  br label %pic.merge.554

pic.prefix.guard.542:                             ; preds = %pic.token.556
  %r2701 = getelementptr i64, ptr %r2670, i64 2
  %r2702 = load i64, ptr %r2701, align 8
  %r2703 = icmp ne i64 %r2702, 0
  br i1 %r2703, label %pic.prefix.meta.543, label %pic.miss.551

pic.prefix.meta.543:                              ; preds = %pic.prefix.guard.542
  %r2704 = add nuw nsw i64 %r2650, 8
  %r2705 = inttoptr i64 %r2704 to ptr
  %r2706 = load i64, ptr %r2705, align 8
  %r2707 = icmp ne i64 %r2706, 0
  br i1 %r2707, label %pic.prefix.token.544, label %pic.miss.551

pic.prefix.token.544:                             ; preds = %pic.prefix.meta.543
  %r2708 = inttoptr i64 %r2706 to ptr
  %r2709 = getelementptr i64, ptr %r2708, i64 6
  %r2710 = load i64, ptr %r2709, align 8
  %r2711 = icmp eq i64 %r2710, %r2702
  br i1 %r2711, label %pic.prefix.hit.545, label %pic.miss.551

pic.prefix.hit.545:                               ; preds = %pic.prefix.token.544
  %r2712 = getelementptr i64, ptr %r2670, i64 1
  %r2713 = load i64, ptr %r2712, align 8
  %r2714 = shl i64 %r2713, 3
  %r2715 = add nuw nsw i64 %r2650, 16
  %r2716 = add i64 %r2715, %r2714
  %r2717 = inttoptr i64 %r2716 to ptr
  %r2718 = load double, ptr %r2717, align 8
  br label %pic.merge.554

pic.desc.classify.546:                            ; preds = %pic.recv_hdr.555
  %r2674 = and i1 %r2664, %r2671
  br i1 %r2674, label %pic.desc.prefix.guard.547, label %pic.miss.cold.552

pic.desc.prefix.guard.547:                        ; preds = %pic.desc.classify.546
  %r2719 = getelementptr i64, ptr %r2670, i64 2
  %r2720 = load i64, ptr %r2719, align 8
  %r2721 = icmp ne i64 %r2720, 0
  br i1 %r2721, label %pic.desc.prefix.meta.548, label %pic.miss.cold.552

pic.desc.prefix.meta.548:                         ; preds = %pic.desc.prefix.guard.547
  %r2722 = add nuw nsw i64 %r2650, 8
  %r2723 = inttoptr i64 %r2722 to ptr
  %r2724 = load i64, ptr %r2723, align 8
  %r2725 = icmp ne i64 %r2724, 0
  br i1 %r2725, label %pic.desc.prefix.token.549, label %pic.miss.cold.552

pic.desc.prefix.token.549:                        ; preds = %pic.desc.prefix.meta.548
  %r2726 = inttoptr i64 %r2724 to ptr
  %r2727 = getelementptr i64, ptr %r2726, i64 6
  %r2728 = load i64, ptr %r2727, align 8
  %r2729 = icmp eq i64 %r2728, %r2720
  br i1 %r2729, label %pic.desc.prefix.hit.550, label %pic.miss.cold.552

pic.desc.prefix.hit.550:                          ; preds = %pic.desc.prefix.token.549
  %r2730 = getelementptr i64, ptr %r2670, i64 1
  %r2731 = load i64, ptr %r2730, align 8
  %r2732 = shl i64 %r2731, 3
  %r2733 = add nuw nsw i64 %r2650, 16
  %r2734 = add i64 %r2733, %r2732
  %r2735 = inttoptr i64 %r2734 to ptr
  %r2736 = load double, ptr %r2735, align 8
  br label %pic.merge.554

pic.miss.551:                                     ; preds = %pic.hit.inline.558, %pic.prefix.token.544, %pic.prefix.meta.543, %pic.prefix.guard.542
  %r2737 = getelementptr i64, ptr %r2670, i64 3
  %r2738 = load i64, ptr %r2737, align 8
  %r2739 = icmp sgt i64 %r2738, 0
  br i1 %r2739, label %pic.ways.559, label %pic.miss.call.553

pic.miss.cold.552:                                ; preds = %pic.desc.prefix.token.549, %pic.desc.prefix.meta.548, %pic.desc.prefix.guard.547, %pic.desc.classify.546, %pget.recv_ok.534
  br label %pic.miss.call.553

pic.miss.call.553:                                ; preds = %pic.way.load.560, %pic.ways.559, %pic.miss.cold.552, %pic.miss.551
  %r2778 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r2779 = bitcast double %r2778 to i64
  %r2780 = and i64 %r2779, 281474976710655
  %statepoint_token792 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2650, i64 %r2780, ptr @perry_ic_test_json_cached_template_borrow_ts__29, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31178, ptr addrspace(1) %.321003, ptr addrspace(1) %.43, ptr addrspace(1) %.01182, ptr addrspace(1) %.321043) ]
  %r2781793 = call double @llvm.experimental.gc.result.f64(token %statepoint_token792)
  %rs4gc.s31.relocated794 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token792, i32 0, i32 0) ; (%.31178, %.31178)
  %r48.0.base.relocated795 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token792, i32 1, i32 1) ; (%.321003, %.321003)
  %r57.0.relocated796 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token792, i32 2, i32 2) ; (%.43, %.43)
  %rs4gc.s35.relocated797 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token792, i32 3, i32 3) ; (%.01182, %.01182)
  %r48.0.relocated798 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token792, i32 1, i32 4) ; (%.321003, %.321043)
  br label %pic.merge.554

pic.merge.554:                                    ; preds = %pic.way.live.561, %pic.hit.overflow.557, %pic.miss.call.553, %pic.desc.prefix.hit.550, %pic.prefix.hit.545, %pic.hit.live.541
  %.21184 = phi ptr addrspace(1) [ %rs4gc.s35.relocated804, %pic.hit.overflow.557 ], [ %rs4gc.s35.relocated797, %pic.miss.call.553 ], [ %.01182, %pic.way.live.561 ], [ %.01182, %pic.hit.live.541 ], [ %.01182, %pic.prefix.hit.545 ], [ %.01182, %pic.desc.prefix.hit.550 ]
  %.51180 = phi ptr addrspace(1) [ %rs4gc.s31.relocated801, %pic.hit.overflow.557 ], [ %rs4gc.s31.relocated794, %pic.miss.call.553 ], [ %.31178, %pic.way.live.561 ], [ %.31178, %pic.hit.live.541 ], [ %.31178, %pic.prefix.hit.545 ], [ %.31178, %pic.desc.prefix.hit.550 ]
  %.341045 = phi ptr addrspace(1) [ %r48.0.relocated805, %pic.hit.overflow.557 ], [ %r48.0.relocated798, %pic.miss.call.553 ], [ %.321043, %pic.way.live.561 ], [ %.321043, %pic.hit.live.541 ], [ %.321043, %pic.prefix.hit.545 ], [ %.321043, %pic.desc.prefix.hit.550 ]
  %.341005 = phi ptr addrspace(1) [ %r48.0.base.relocated802, %pic.hit.overflow.557 ], [ %r48.0.base.relocated795, %pic.miss.call.553 ], [ %.321003, %pic.way.live.561 ], [ %.321003, %pic.hit.live.541 ], [ %.321003, %pic.prefix.hit.545 ], [ %.321003, %pic.desc.prefix.hit.550 ]
  %.45 = phi ptr addrspace(1) [ %r57.0.relocated803, %pic.hit.overflow.557 ], [ %r57.0.relocated796, %pic.miss.call.553 ], [ %.43, %pic.way.live.561 ], [ %.43, %pic.hit.live.541 ], [ %.43, %pic.prefix.hit.545 ], [ %.43, %pic.desc.prefix.hit.550 ]
  %r2782 = phi double [ %r2698, %pic.hit.live.541 ], [ %r2693800, %pic.hit.overflow.557 ], [ %r2718, %pic.prefix.hit.545 ], [ %r2736, %pic.desc.prefix.hit.550 ], [ %r2775, %pic.way.live.561 ], [ %r2781793, %pic.miss.call.553 ]
  br label %pget.recv_merge.537

pic.recv_hdr.555:                                 ; preds = %pget.recv_ok.534
  %r2661 = sub nuw nsw i64 %r2650, 8
  %r2662 = inttoptr i64 %r2661 to ptr
  %r2663 = load i8, ptr %r2662, align 1
  %r2664 = icmp eq i8 %r2663, 2
  %r2665 = sub nuw nsw i64 %r2650, 6
  %r2666 = inttoptr i64 %r2665 to ptr
  %r2667 = load i16, ptr %r2666, align 2
  %r2668 = and i16 %r2667, 2048
  %r2669 = icmp eq i16 %r2668, 0
  %r2670 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__29, align 8
  %r2671 = icmp ne ptr %r2670, null
  %r2672 = and i1 %r2664, %r2669
  %r2673 = and i1 %r2672, %r2671
  br i1 %r2673, label %pic.token.556, label %pic.desc.classify.546

pic.token.556:                                    ; preds = %pic.recv_hdr.555
  %r2675 = add nuw nsw i64 %r2650, 4
  %r2676 = inttoptr i64 %r2675 to ptr
  %r2677 = load i32, ptr %r2676, align 4
  %r2678 = zext i32 %r2677 to i64
  %r2679 = or i64 %r2678, 4611686018427387904
  %r2680 = icmp ne i32 %r2677, 0
  %r2681 = getelementptr i64, ptr %r2670, i64 0
  %r2682 = load i64, ptr %r2681, align 8
  %r2683 = icmp eq i64 %r2679, %r2682
  %r2684 = and i1 %r2683, %r2680
  br i1 %r2684, label %pic.hit.540, label %pic.prefix.guard.542

pic.hit.overflow.557:                             ; preds = %pic.hit.540
  %r2689 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r2690 = bitcast double %r2689 to i64
  %r2691 = and i64 %r2690, 281474976710655
  %r2692 = trunc i64 %r2686 to i32
  %statepoint_token799 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2650, i64 %r2691, i32 %r2692, ptr @perry_ic_test_json_cached_template_borrow_ts__29, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31178, ptr addrspace(1) %.321003, ptr addrspace(1) %.43, ptr addrspace(1) %.01182, ptr addrspace(1) %.321043) ]
  %r2693800 = call double @llvm.experimental.gc.result.f64(token %statepoint_token799)
  %rs4gc.s31.relocated801 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token799, i32 0, i32 0) ; (%.31178, %.31178)
  %r48.0.base.relocated802 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token799, i32 1, i32 1) ; (%.321003, %.321003)
  %r57.0.relocated803 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token799, i32 2, i32 2) ; (%.43, %.43)
  %rs4gc.s35.relocated804 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token799, i32 3, i32 3) ; (%.01182, %.01182)
  %r48.0.relocated805 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token799, i32 1, i32 4) ; (%.321003, %.321043)
  br label %pic.merge.554

pic.hit.inline.558:                               ; preds = %pic.hit.540
  %r2694 = shl i64 %r2686, 3
  %r2695 = add nuw nsw i64 %r2650, 16
  %r2696 = add i64 %r2695, %r2694
  %r2697 = inttoptr i64 %r2696 to ptr
  %r2698 = load double, ptr %r2697, align 8
  %r2699 = bitcast double %r2698 to i64
  %r2700 = icmp eq i64 %r2699, 9222246136947933200
  br i1 %r2700, label %pic.miss.551, label %pic.hit.live.541

pic.ways.559:                                     ; preds = %pic.miss.551
  %r2740 = getelementptr i64, ptr %r2670, i64 4
  %r2741 = load i64, ptr %r2740, align 8
  %r2742 = icmp eq i64 %r2741, %r2679
  %r2743 = getelementptr i64, ptr %r2670, i64 5
  %r2744 = load i64, ptr %r2743, align 8
  %r2745 = select i1 %r2742, i64 %r2744, i64 0
  %r2746 = getelementptr i64, ptr %r2670, i64 6
  %r2747 = load i64, ptr %r2746, align 8
  %r2748 = icmp eq i64 %r2747, %r2679
  %r2749 = getelementptr i64, ptr %r2670, i64 7
  %r2750 = load i64, ptr %r2749, align 8
  %r2751 = select i1 %r2748, i64 %r2750, i64 0
  %r2752 = getelementptr i64, ptr %r2670, i64 8
  %r2753 = load i64, ptr %r2752, align 8
  %r2754 = icmp eq i64 %r2753, %r2679
  %r2755 = getelementptr i64, ptr %r2670, i64 9
  %r2756 = load i64, ptr %r2755, align 8
  %r2757 = select i1 %r2754, i64 %r2756, i64 0
  %r2758 = getelementptr i64, ptr %r2670, i64 10
  %r2759 = load i64, ptr %r2758, align 8
  %r2760 = icmp eq i64 %r2759, %r2679
  %r2761 = getelementptr i64, ptr %r2670, i64 11
  %r2762 = load i64, ptr %r2761, align 8
  %r2763 = select i1 %r2760, i64 %r2762, i64 0
  %r2764 = or i1 %r2742, %r2748
  %r2765 = select i1 %r2742, i64 %r2745, i64 %r2751
  %r2766 = or i1 %r2754, %r2760
  %r2767 = select i1 %r2754, i64 %r2757, i64 %r2763
  %r2768 = or i1 %r2764, %r2766
  %r2769 = select i1 %r2764, i64 %r2765, i64 %r2767
  %r2770 = and i1 %r2680, %r2768
  br i1 %r2770, label %pic.way.load.560, label %pic.miss.call.553

pic.way.load.560:                                 ; preds = %pic.ways.559
  %r2771 = shl i64 %r2769, 3
  %r2772 = add nuw nsw i64 %r2650, 16
  %r2773 = add i64 %r2772, %r2771
  %r2774 = inttoptr i64 %r2773 to ptr
  %r2775 = load double, ptr %r2774, align 8
  %r2776 = bitcast double %r2775 to i64
  %r2777 = icmp eq i64 %r2776, 9222246136947933200
  br i1 %r2777, label %pic.miss.call.553, label %pic.way.live.561

pic.way.live.561:                                 ; preds = %pic.way.load.560
  br label %pic.merge.554

pget.throw_nullish.562:                           ; preds = %pget.recv_bad.535
  %r2786 = zext i1 %r2784 to i32
  %statepoint_token806 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2786, ptr @test_json_cached_template_borrow_ts_.str.2.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.563:                       ; preds = %pget.recv_bad.535
  %r2787 = load double, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  %r2788 = bitcast double %r2787 to i64
  %r2789 = and i64 %r2788, 281474976710655
  %statepoint_token807 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2649, i64 %r2789, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.31178, ptr addrspace(1) %.321003, ptr addrspace(1) %.43, ptr addrspace(1) %.01182, ptr addrspace(1) %.321043) ]
  %r2790808 = call double @llvm.experimental.gc.result.f64(token %statepoint_token807)
  %rs4gc.s31.relocated809 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token807, i32 0, i32 0) ; (%.31178, %.31178)
  %r48.0.base.relocated810 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token807, i32 1, i32 1) ; (%.321003, %.321003)
  %r57.0.relocated811 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token807, i32 2, i32 2) ; (%.43, %.43)
  %rs4gc.s35.relocated812 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token807, i32 3, i32 3) ; (%.01182, %.01182)
  %r48.0.relocated813 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token807, i32 1, i32 4) ; (%.321003, %.321043)
  br label %pget.recv_merge.537

shadow.root.barrier.564:                          ; preds = %pget.recv_merge.537
  call void @js_write_barrier_root_nanbox(i64 %r2798) #7
  br label %shadow.root.barrier.done.565

shadow.root.barrier.done.565:                     ; preds = %shadow.root.barrier.564, %pget.recv_merge.537
  %r2801.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated790 to i64
  %r2801.rs4o = call i64 asm "", "=r,0"(i64 %r2801.rs4i) #7
  %r2801 = bitcast i64 %r2801.rs4o to double
  %r2803 = bitcast double %r2801 to i64
  %r2804 = and i64 %r2803, 281474976710655
  %r2805 = load double, ptr @test_json_cached_template_borrow_ts_.str.0.handle, align 8
  %r2806 = bitcast double %r2805 to i64
  %r2807 = and i64 %r2806, 281474976710655
  %r2808 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r2809 = icmp eq i8 %r2808, 0
  %r2810 = lshr i64 %r2803, 48
  %r2811 = icmp eq i64 %r2810, 32765
  %r2812 = icmp ugt i64 %r2804, 1048575
  %r2813 = and i1 %r2811, %r2812
  %r2814 = and i1 %r2813, %r2809
  br i1 %r2814, label %class_field_inline.deref.569, label %class_field_inline.guardcall.570

class_field_get.fast.566:                         ; preds = %class_field_inline.guardcall.570, %class_field_inline.deref.569
  %r3453.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated790 to i64
  %r3453.rs4o = call i64 asm "", "=r,0"(i64 %r3453.rs4i) #7
  %r3453 = bitcast i64 %r3453.rs4o to double
  %r3454 = bitcast double %r3453 to i64
  %r3455 = and i64 %r3454, 281474976710655
  %r2839 = inttoptr i64 %r3455 to ptr
  %r3449.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated790 to i64
  %r3449.rs4o = call i64 asm "", "=r,0"(i64 %r3449.rs4i) #7
  %r3449 = bitcast i64 %r3449.rs4o to double
  %r3450 = bitcast double %r3449 to i64
  %r3451 = and i64 %r3450, 281474976710655
  %r3452 = inttoptr i64 %r3451 to ptr
  %r2840 = getelementptr i8, ptr %r3452, i64 16
  %r2841 = getelementptr double, ptr %r2840, i64 0
  %r2842 = load double, ptr %r2841, align 8
  br label %class_field_get.merge.568

class_field_get.fallback.567:                     ; preds = %class_field_inline.guardcall.570
  %r3447.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated790 to i64
  %r3447.rs4o = call i64 asm "", "=r,0"(i64 %r3447.rs4i) #7
  %r3447 = bitcast i64 %r3447.rs4o to double
  %r3448 = bitcast double %r3447 to i64
  %r2843 = icmp eq i64 %r3448, 9222246136947933185
  %r3445.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated790 to i64
  %r3445.rs4o = call i64 asm "", "=r,0"(i64 %r3445.rs4i) #7
  %r3445 = bitcast i64 %r3445.rs4o to double
  %r3446 = bitcast double %r3445 to i64
  %r2844 = icmp eq i64 %r3446, 9222246136947933186
  %r2845 = or i1 %r2843, %r2844
  br i1 %r2845, label %class_field_get.throw_nullish.571, label %class_field_get.fallback_lookup.572

class_field_get.merge.568:                        ; preds = %class_field_get.fallback_lookup.572, %class_field_get.fast.566
  %.01185 = phi ptr addrspace(1) [ %rs4gc.s36, %class_field_get.fast.566 ], [ %rs4gc.s36.relocated, %class_field_get.fallback_lookup.572 ]
  %.351046 = phi ptr addrspace(1) [ %r48.0.relocated791, %class_field_get.fast.566 ], [ %r48.0.relocated819, %class_field_get.fallback_lookup.572 ]
  %.351006 = phi ptr addrspace(1) [ %r48.0.base.relocated788, %class_field_get.fast.566 ], [ %r48.0.base.relocated817, %class_field_get.fallback_lookup.572 ]
  %.46 = phi ptr addrspace(1) [ %r57.0.relocated789, %class_field_get.fast.566 ], [ %r57.0.relocated818, %class_field_get.fallback_lookup.572 ]
  %r2848 = phi double [ %r2842, %class_field_get.fast.566 ], [ %r2847816, %class_field_get.fallback_lookup.572 ]
  %r2849 = bitcast double %r2848 to i64
  %r2850 = and i64 %r2849, 281474976710655
  %r2851 = lshr i64 %r2849, 48
  %r2852 = and i64 %r2851, 65533
  %r2853 = icmp eq i64 %r2852, 32765
  br i1 %r2853, label %pget.recv_ok.574, label %pget.recv_other.578

class_field_inline.deref.569:                     ; preds = %shadow.root.barrier.done.565
  %r2815 = inttoptr i64 %r2804 to ptr
  %r2816 = getelementptr i8, ptr %r2815, i64 -8
  %r2817 = load i8, ptr %r2816, align 1
  %r2818 = icmp eq i8 %r2817, 2
  %r2819 = getelementptr i8, ptr %r2815, i64 -7
  %r2820 = load i8, ptr %r2819, align 1
  %r2821 = and i8 %r2820, -128
  %r2822 = icmp eq i8 %r2821, 0
  %r2823 = getelementptr i8, ptr %r2815, i64 -6
  %r2824 = load i16, ptr %r2823, align 2
  %r2825 = getelementptr i8, ptr %r2815, i64 0
  %r2826 = load i32, ptr %r2825, align 4
  %r2827 = icmp eq i32 %r2826, 1
  %r2828 = getelementptr i8, ptr %r2815, i64 4
  %r2829 = load i32, ptr %r2828, align 4
  %r2830 = icmp eq i32 %r2829, %r2462
  %r2831 = and i1 %r2818, %r2822
  %r2832 = and i1 %r2831, %r2827
  %r2833 = and i1 %r2832, %r2830
  %r2834 = and i16 %r2824, 3072
  %r2835 = icmp eq i16 %r2834, 0
  %r2836 = and i1 %r2833, %r2835
  br i1 %r2836, label %class_field_get.fast.566, label %class_field_inline.guardcall.570

class_field_inline.guardcall.570:                 ; preds = %class_field_inline.deref.569, %shadow.root.barrier.done.565
  %r2837 = call i32 @js_typed_feedback_class_field_get_guard(i64 8988321885632593950, double %r2801, i32 1, i32 %r2462, i64 %r2807, i32 0, i32 0) #7
  %r2838 = icmp ne i32 %r2837, 0
  br i1 %r2838, label %class_field_get.fast.566, label %class_field_get.fallback.567

class_field_get.throw_nullish.571:                ; preds = %class_field_get.fallback.567
  %r2846 = zext i1 %r2844 to i32
  %statepoint_token814 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2846, ptr @test_json_cached_template_borrow_ts_.str.0.bytes, i64 5, i32 0, i32 0)
  unreachable

class_field_get.fallback_lookup.572:              ; preds = %class_field_get.fallback.567
  %r3440.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s31.relocated790 to i64
  %r3440.rs4o = call i64 asm "", "=r,0"(i64 %r3440.rs4i) #7
  %r3440 = bitcast i64 %r3440.rs4o to double
  %r3441 = bitcast double %r3440 to i64
  %r3442 = load double, ptr @test_json_cached_template_borrow_ts_.str.0.handle, align 8
  %r3443 = bitcast double %r3442 to i64
  %r3444 = and i64 %r3443, 281474976710655
  %statepoint_token815 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r3441, i64 %r3444, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s36, ptr addrspace(1) %r48.0.base.relocated788, ptr addrspace(1) %r57.0.relocated789, ptr addrspace(1) %r48.0.relocated791) ]
  %r2847816 = call double @llvm.experimental.gc.result.f64(token %statepoint_token815)
  %rs4gc.s36.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token815, i32 0, i32 0) ; (%rs4gc.s36, %rs4gc.s36)
  %r48.0.base.relocated817 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token815, i32 1, i32 1) ; (%r48.0.base.relocated788, %r48.0.base.relocated788)
  %r57.0.relocated818 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token815, i32 2, i32 2) ; (%r57.0.relocated789, %r57.0.relocated789)
  %r48.0.relocated819 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token815, i32 1, i32 3) ; (%r48.0.base.relocated788, %r48.0.relocated791)
  br label %class_field_get.merge.568

pget.recv_sso.573:                                ; preds = %pget.recv_other.578
  %r2991 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r2992 = bitcast double %r2991 to i64
  %r2993 = and i64 %r2992, 281474976710655
  %statepoint_token820 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2849, i64 %r2993, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01185, ptr addrspace(1) %.351006, ptr addrspace(1) %.46, ptr addrspace(1) %.351046) ]
  %r2994821 = call double @llvm.experimental.gc.result.f64(token %statepoint_token820)
  %rs4gc.s36.relocated822 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token820, i32 0, i32 0) ; (%.01185, %.01185)
  %r48.0.base.relocated823 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token820, i32 1, i32 1) ; (%.351006, %.351006)
  %r57.0.relocated824 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token820, i32 2, i32 2) ; (%.46, %.46)
  %r48.0.relocated825 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token820, i32 1, i32 3) ; (%.351006, %.351046)
  br label %pget.recv_merge.577

pget.recv_ok.574:                                 ; preds = %class_field_get.merge.568
  %r2860 = icmp ugt i64 %r2850, 1048575
  br i1 %r2860, label %pic.recv_hdr.595, label %pic.miss.cold.592

pget.recv_bad.575:                                ; preds = %pget.check_class_ref.579
  %r2983 = icmp eq i64 %r2849, 9222246136947933185
  %r2984 = icmp eq i64 %r2849, 9222246136947933186
  %r2985 = or i1 %r2983, %r2984
  br i1 %r2985, label %pget.throw_nullish.602, label %pget.recv_undef_return.603

pget.recv_class_ref.576:                          ; preds = %pget.check_class_ref.579
  %r2856 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r2857 = bitcast double %r2856 to i64
  %r2858 = and i64 %r2857, 281474976710655
  %statepoint_token826 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 8988321885632593951, i64 %r2849, i64 %r2858, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01185, ptr addrspace(1) %.351006, ptr addrspace(1) %.46, ptr addrspace(1) %.351046) ]
  %r2859827 = call double @llvm.experimental.gc.result.f64(token %statepoint_token826)
  %rs4gc.s36.relocated828 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token826, i32 0, i32 0) ; (%.01185, %.01185)
  %r48.0.base.relocated829 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token826, i32 1, i32 1) ; (%.351006, %.351006)
  %r57.0.relocated830 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token826, i32 2, i32 2) ; (%.46, %.46)
  %r48.0.relocated831 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token826, i32 1, i32 3) ; (%.351006, %.351046)
  br label %pget.recv_merge.577

pget.recv_merge.577:                              ; preds = %pget.recv_undef_return.603, %pic.merge.594, %pget.recv_class_ref.576, %pget.recv_sso.573
  %.11186 = phi ptr addrspace(1) [ %.21187, %pic.merge.594 ], [ %rs4gc.s36.relocated822, %pget.recv_sso.573 ], [ %rs4gc.s36.relocated828, %pget.recv_class_ref.576 ], [ %rs4gc.s36.relocated847, %pget.recv_undef_return.603 ]
  %.361047 = phi ptr addrspace(1) [ %.371048, %pic.merge.594 ], [ %r48.0.relocated825, %pget.recv_sso.573 ], [ %r48.0.relocated831, %pget.recv_class_ref.576 ], [ %r48.0.relocated850, %pget.recv_undef_return.603 ]
  %.361007 = phi ptr addrspace(1) [ %.371008, %pic.merge.594 ], [ %r48.0.base.relocated823, %pget.recv_sso.573 ], [ %r48.0.base.relocated829, %pget.recv_class_ref.576 ], [ %r48.0.base.relocated848, %pget.recv_undef_return.603 ]
  %.47 = phi ptr addrspace(1) [ %.48, %pic.merge.594 ], [ %r57.0.relocated824, %pget.recv_sso.573 ], [ %r57.0.relocated830, %pget.recv_class_ref.576 ], [ %r57.0.relocated849, %pget.recv_undef_return.603 ]
  %r2995 = phi double [ %r2982, %pic.merge.594 ], [ %r2990846, %pget.recv_undef_return.603 ], [ %r2994821, %pget.recv_sso.573 ], [ %r2859827, %pget.recv_class_ref.576 ]
  %r2996 = bitcast double %r2995 to i64
  %r2997 = and i64 %r2996, 281474976710655
  %r2998 = and i64 %r2996, -281474976710656
  %r2999 = icmp eq i64 %r2998, 9222527611924643840
  %r3000 = load i64, ptr @PERRY_TA_VIEW_GUARD, align 8
  %r3001 = icmp eq i64 %r3000, 0
  %r3002 = icmp ugt i64 %r2997, 1048575
  %r3003 = icmp ult i64 %r2997, 140737488355328
  %r3004 = and i1 %r3002, %r3003
  %r3005 = and i1 %r2999, %r3001
  %r3006 = and i1 %r3005, %r3004
  br i1 %r3006, label %tav.get.brand.608, label %tav.get.slow.606

pget.recv_other.578:                              ; preds = %class_field_get.merge.568
  %r2854 = icmp eq i64 %r2851, 32761
  br i1 %r2854, label %pget.recv_sso.573, label %pget.check_class_ref.579

pget.check_class_ref.579:                         ; preds = %pget.recv_other.578
  %r2855 = icmp eq i64 %r2851, 32766
  br i1 %r2855, label %pget.recv_class_ref.576, label %pget.recv_bad.575

pic.hit.580:                                      ; preds = %pic.token.596
  %r2885 = getelementptr i64, ptr %r2870, i64 1
  %r2886 = load i64, ptr %r2885, align 8
  %r2887 = and i64 %r2886, 1073741824
  %r2888 = icmp ne i64 %r2887, 0
  br i1 %r2888, label %pic.hit.overflow.597, label %pic.hit.inline.598

pic.hit.live.581:                                 ; preds = %pic.hit.inline.598
  br label %pic.merge.594

pic.prefix.guard.582:                             ; preds = %pic.token.596
  %r2901 = getelementptr i64, ptr %r2870, i64 2
  %r2902 = load i64, ptr %r2901, align 8
  %r2903 = icmp ne i64 %r2902, 0
  br i1 %r2903, label %pic.prefix.meta.583, label %pic.miss.591

pic.prefix.meta.583:                              ; preds = %pic.prefix.guard.582
  %r2904 = add nuw nsw i64 %r2850, 8
  %r2905 = inttoptr i64 %r2904 to ptr
  %r2906 = load i64, ptr %r2905, align 8
  %r2907 = icmp ne i64 %r2906, 0
  br i1 %r2907, label %pic.prefix.token.584, label %pic.miss.591

pic.prefix.token.584:                             ; preds = %pic.prefix.meta.583
  %r2908 = inttoptr i64 %r2906 to ptr
  %r2909 = getelementptr i64, ptr %r2908, i64 6
  %r2910 = load i64, ptr %r2909, align 8
  %r2911 = icmp eq i64 %r2910, %r2902
  br i1 %r2911, label %pic.prefix.hit.585, label %pic.miss.591

pic.prefix.hit.585:                               ; preds = %pic.prefix.token.584
  %r2912 = getelementptr i64, ptr %r2870, i64 1
  %r2913 = load i64, ptr %r2912, align 8
  %r2914 = shl i64 %r2913, 3
  %r2915 = add nuw nsw i64 %r2850, 16
  %r2916 = add i64 %r2915, %r2914
  %r2917 = inttoptr i64 %r2916 to ptr
  %r2918 = load double, ptr %r2917, align 8
  br label %pic.merge.594

pic.desc.classify.586:                            ; preds = %pic.recv_hdr.595
  %r2874 = and i1 %r2864, %r2871
  br i1 %r2874, label %pic.desc.prefix.guard.587, label %pic.miss.cold.592

pic.desc.prefix.guard.587:                        ; preds = %pic.desc.classify.586
  %r2919 = getelementptr i64, ptr %r2870, i64 2
  %r2920 = load i64, ptr %r2919, align 8
  %r2921 = icmp ne i64 %r2920, 0
  br i1 %r2921, label %pic.desc.prefix.meta.588, label %pic.miss.cold.592

pic.desc.prefix.meta.588:                         ; preds = %pic.desc.prefix.guard.587
  %r2922 = add nuw nsw i64 %r2850, 8
  %r2923 = inttoptr i64 %r2922 to ptr
  %r2924 = load i64, ptr %r2923, align 8
  %r2925 = icmp ne i64 %r2924, 0
  br i1 %r2925, label %pic.desc.prefix.token.589, label %pic.miss.cold.592

pic.desc.prefix.token.589:                        ; preds = %pic.desc.prefix.meta.588
  %r2926 = inttoptr i64 %r2924 to ptr
  %r2927 = getelementptr i64, ptr %r2926, i64 6
  %r2928 = load i64, ptr %r2927, align 8
  %r2929 = icmp eq i64 %r2928, %r2920
  br i1 %r2929, label %pic.desc.prefix.hit.590, label %pic.miss.cold.592

pic.desc.prefix.hit.590:                          ; preds = %pic.desc.prefix.token.589
  %r2930 = getelementptr i64, ptr %r2870, i64 1
  %r2931 = load i64, ptr %r2930, align 8
  %r2932 = shl i64 %r2931, 3
  %r2933 = add nuw nsw i64 %r2850, 16
  %r2934 = add i64 %r2933, %r2932
  %r2935 = inttoptr i64 %r2934 to ptr
  %r2936 = load double, ptr %r2935, align 8
  br label %pic.merge.594

pic.miss.591:                                     ; preds = %pic.hit.inline.598, %pic.prefix.token.584, %pic.prefix.meta.583, %pic.prefix.guard.582
  %r2937 = getelementptr i64, ptr %r2870, i64 3
  %r2938 = load i64, ptr %r2937, align 8
  %r2939 = icmp sgt i64 %r2938, 0
  br i1 %r2939, label %pic.ways.599, label %pic.miss.call.593

pic.miss.cold.592:                                ; preds = %pic.desc.prefix.token.589, %pic.desc.prefix.meta.588, %pic.desc.prefix.guard.587, %pic.desc.classify.586, %pget.recv_ok.574
  br label %pic.miss.call.593

pic.miss.call.593:                                ; preds = %pic.way.load.600, %pic.ways.599, %pic.miss.cold.592, %pic.miss.591
  %r2978 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r2979 = bitcast double %r2978 to i64
  %r2980 = and i64 %r2979, 281474976710655
  %statepoint_token832 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r2850, i64 %r2980, ptr @perry_ic_test_json_cached_template_borrow_ts__32, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01185, ptr addrspace(1) %.351006, ptr addrspace(1) %.46, ptr addrspace(1) %.351046) ]
  %r2981833 = call double @llvm.experimental.gc.result.f64(token %statepoint_token832)
  %rs4gc.s36.relocated834 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token832, i32 0, i32 0) ; (%.01185, %.01185)
  %r48.0.base.relocated835 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token832, i32 1, i32 1) ; (%.351006, %.351006)
  %r57.0.relocated836 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token832, i32 2, i32 2) ; (%.46, %.46)
  %r48.0.relocated837 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token832, i32 1, i32 3) ; (%.351006, %.351046)
  br label %pic.merge.594

pic.merge.594:                                    ; preds = %pic.way.live.601, %pic.hit.overflow.597, %pic.miss.call.593, %pic.desc.prefix.hit.590, %pic.prefix.hit.585, %pic.hit.live.581
  %.21187 = phi ptr addrspace(1) [ %rs4gc.s36.relocated840, %pic.hit.overflow.597 ], [ %rs4gc.s36.relocated834, %pic.miss.call.593 ], [ %.01185, %pic.way.live.601 ], [ %.01185, %pic.hit.live.581 ], [ %.01185, %pic.prefix.hit.585 ], [ %.01185, %pic.desc.prefix.hit.590 ]
  %.371048 = phi ptr addrspace(1) [ %r48.0.relocated843, %pic.hit.overflow.597 ], [ %r48.0.relocated837, %pic.miss.call.593 ], [ %.351046, %pic.way.live.601 ], [ %.351046, %pic.hit.live.581 ], [ %.351046, %pic.prefix.hit.585 ], [ %.351046, %pic.desc.prefix.hit.590 ]
  %.371008 = phi ptr addrspace(1) [ %r48.0.base.relocated841, %pic.hit.overflow.597 ], [ %r48.0.base.relocated835, %pic.miss.call.593 ], [ %.351006, %pic.way.live.601 ], [ %.351006, %pic.hit.live.581 ], [ %.351006, %pic.prefix.hit.585 ], [ %.351006, %pic.desc.prefix.hit.590 ]
  %.48 = phi ptr addrspace(1) [ %r57.0.relocated842, %pic.hit.overflow.597 ], [ %r57.0.relocated836, %pic.miss.call.593 ], [ %.46, %pic.way.live.601 ], [ %.46, %pic.hit.live.581 ], [ %.46, %pic.prefix.hit.585 ], [ %.46, %pic.desc.prefix.hit.590 ]
  %r2982 = phi double [ %r2898, %pic.hit.live.581 ], [ %r2893839, %pic.hit.overflow.597 ], [ %r2918, %pic.prefix.hit.585 ], [ %r2936, %pic.desc.prefix.hit.590 ], [ %r2975, %pic.way.live.601 ], [ %r2981833, %pic.miss.call.593 ]
  br label %pget.recv_merge.577

pic.recv_hdr.595:                                 ; preds = %pget.recv_ok.574
  %r2861 = sub nuw nsw i64 %r2850, 8
  %r2862 = inttoptr i64 %r2861 to ptr
  %r2863 = load i8, ptr %r2862, align 1
  %r2864 = icmp eq i8 %r2863, 2
  %r2865 = sub nuw nsw i64 %r2850, 6
  %r2866 = inttoptr i64 %r2865 to ptr
  %r2867 = load i16, ptr %r2866, align 2
  %r2868 = and i16 %r2867, 2048
  %r2869 = icmp eq i16 %r2868, 0
  %r2870 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__32, align 8
  %r2871 = icmp ne ptr %r2870, null
  %r2872 = and i1 %r2864, %r2869
  %r2873 = and i1 %r2872, %r2871
  br i1 %r2873, label %pic.token.596, label %pic.desc.classify.586

pic.token.596:                                    ; preds = %pic.recv_hdr.595
  %r2875 = add nuw nsw i64 %r2850, 4
  %r2876 = inttoptr i64 %r2875 to ptr
  %r2877 = load i32, ptr %r2876, align 4
  %r2878 = zext i32 %r2877 to i64
  %r2879 = or i64 %r2878, 4611686018427387904
  %r2880 = icmp ne i32 %r2877, 0
  %r2881 = getelementptr i64, ptr %r2870, i64 0
  %r2882 = load i64, ptr %r2881, align 8
  %r2883 = icmp eq i64 %r2879, %r2882
  %r2884 = and i1 %r2883, %r2880
  br i1 %r2884, label %pic.hit.580, label %pic.prefix.guard.582

pic.hit.overflow.597:                             ; preds = %pic.hit.580
  %r2889 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r2890 = bitcast double %r2889 to i64
  %r2891 = and i64 %r2890, 281474976710655
  %r2892 = trunc i64 %r2886 to i32
  %statepoint_token838 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r2850, i64 %r2891, i32 %r2892, ptr @perry_ic_test_json_cached_template_borrow_ts__32, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01185, ptr addrspace(1) %.351006, ptr addrspace(1) %.46, ptr addrspace(1) %.351046) ]
  %r2893839 = call double @llvm.experimental.gc.result.f64(token %statepoint_token838)
  %rs4gc.s36.relocated840 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token838, i32 0, i32 0) ; (%.01185, %.01185)
  %r48.0.base.relocated841 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token838, i32 1, i32 1) ; (%.351006, %.351006)
  %r57.0.relocated842 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token838, i32 2, i32 2) ; (%.46, %.46)
  %r48.0.relocated843 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token838, i32 1, i32 3) ; (%.351006, %.351046)
  br label %pic.merge.594

pic.hit.inline.598:                               ; preds = %pic.hit.580
  %r2894 = shl i64 %r2886, 3
  %r2895 = add nuw nsw i64 %r2850, 16
  %r2896 = add i64 %r2895, %r2894
  %r2897 = inttoptr i64 %r2896 to ptr
  %r2898 = load double, ptr %r2897, align 8
  %r2899 = bitcast double %r2898 to i64
  %r2900 = icmp eq i64 %r2899, 9222246136947933200
  br i1 %r2900, label %pic.miss.591, label %pic.hit.live.581

pic.ways.599:                                     ; preds = %pic.miss.591
  %r2940 = getelementptr i64, ptr %r2870, i64 4
  %r2941 = load i64, ptr %r2940, align 8
  %r2942 = icmp eq i64 %r2941, %r2879
  %r2943 = getelementptr i64, ptr %r2870, i64 5
  %r2944 = load i64, ptr %r2943, align 8
  %r2945 = select i1 %r2942, i64 %r2944, i64 0
  %r2946 = getelementptr i64, ptr %r2870, i64 6
  %r2947 = load i64, ptr %r2946, align 8
  %r2948 = icmp eq i64 %r2947, %r2879
  %r2949 = getelementptr i64, ptr %r2870, i64 7
  %r2950 = load i64, ptr %r2949, align 8
  %r2951 = select i1 %r2948, i64 %r2950, i64 0
  %r2952 = getelementptr i64, ptr %r2870, i64 8
  %r2953 = load i64, ptr %r2952, align 8
  %r2954 = icmp eq i64 %r2953, %r2879
  %r2955 = getelementptr i64, ptr %r2870, i64 9
  %r2956 = load i64, ptr %r2955, align 8
  %r2957 = select i1 %r2954, i64 %r2956, i64 0
  %r2958 = getelementptr i64, ptr %r2870, i64 10
  %r2959 = load i64, ptr %r2958, align 8
  %r2960 = icmp eq i64 %r2959, %r2879
  %r2961 = getelementptr i64, ptr %r2870, i64 11
  %r2962 = load i64, ptr %r2961, align 8
  %r2963 = select i1 %r2960, i64 %r2962, i64 0
  %r2964 = or i1 %r2942, %r2948
  %r2965 = select i1 %r2942, i64 %r2945, i64 %r2951
  %r2966 = or i1 %r2954, %r2960
  %r2967 = select i1 %r2954, i64 %r2957, i64 %r2963
  %r2968 = or i1 %r2964, %r2966
  %r2969 = select i1 %r2964, i64 %r2965, i64 %r2967
  %r2970 = and i1 %r2880, %r2968
  br i1 %r2970, label %pic.way.load.600, label %pic.miss.call.593

pic.way.load.600:                                 ; preds = %pic.ways.599
  %r2971 = shl i64 %r2969, 3
  %r2972 = add nuw nsw i64 %r2850, 16
  %r2973 = add i64 %r2972, %r2971
  %r2974 = inttoptr i64 %r2973 to ptr
  %r2975 = load double, ptr %r2974, align 8
  %r2976 = bitcast double %r2975 to i64
  %r2977 = icmp eq i64 %r2976, 9222246136947933200
  br i1 %r2977, label %pic.miss.call.593, label %pic.way.live.601

pic.way.live.601:                                 ; preds = %pic.way.load.600
  br label %pic.merge.594

pget.throw_nullish.602:                           ; preds = %pget.recv_bad.575
  %r2986 = zext i1 %r2984 to i32
  %statepoint_token844 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r2986, ptr @test_json_cached_template_borrow_ts_.str.7.bytes, i64 5, i32 0, i32 0)
  unreachable

pget.recv_undef_return.603:                       ; preds = %pget.recv_bad.575
  %r2987 = load double, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  %r2988 = bitcast double %r2987 to i64
  %r2989 = and i64 %r2988, 281474976710655
  %statepoint_token845 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r2849, i64 %r2989, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.01185, ptr addrspace(1) %.351006, ptr addrspace(1) %.46, ptr addrspace(1) %.351046) ]
  %r2990846 = call double @llvm.experimental.gc.result.f64(token %statepoint_token845)
  %rs4gc.s36.relocated847 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token845, i32 0, i32 0) ; (%.01185, %.01185)
  %r48.0.base.relocated848 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token845, i32 1, i32 1) ; (%.351006, %.351006)
  %r57.0.relocated849 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token845, i32 2, i32 2) ; (%.46, %.46)
  %r48.0.relocated850 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token845, i32 1, i32 3) ; (%.351006, %.351046)
  br label %pget.recv_merge.577

tav.get.fast.604:                                 ; preds = %tav.get.brand.608
  %r3023 = bitcast double %r2995 to i64
  %r3024 = and i64 %r3023, 281474976710655
  %r3025 = add nuw nsw i64 %r3024, 8
  %r3026 = inttoptr i64 %r3025 to ptr
  %r3027 = load i8, ptr %r3026, align 1
  %r3028 = zext i8 %r3027 to i64
  %r3032 = inttoptr i64 %r3024 to ptr
  %r3033 = load i32, ptr %r3032, align 4
  %r3034 = zext i32 %r3033 to i64
  %r3035 = icmp ult i64 0, %r3034
  %r3036 = and i1 true, %r3035
  br i1 %r3036, label %tav.get.load.605, label %tav.get.slow.606

tav.get.load.605:                                 ; preds = %tav.get.fast.604
  %r3037 = add nuw nsw i64 %r3024, 16
  %r3038 = icmp eq i64 %r3028, 0
  br i1 %r3038, label %tav.k.i8.609, label %tav.kd1.617

tav.get.slow.606:                                 ; preds = %tav.get.brand.608, %tav.get.fast.604, %pget.recv_merge.577
  %r3089 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__33, align 8
  %r3090 = icmp ne ptr %r3089, null
  %r3091 = select i1 %r3090, ptr %r3089, ptr @perry_ic_test_json_cached_template_borrow_ts__33
  %r3092 = bitcast double %r2995 to i64
  %r3093 = and i64 %r3092, 281474976710655
  %r3094 = and i64 %r3092, -281474976710656
  %r3095 = icmp eq i64 %r3094, 9222527611924643840
  %r3096 = icmp uge i64 %r3093, 2199023255552
  %r3097 = icmp ult i64 %r3093, 140737488355328
  %r3100 = and i1 %r3095, %r3096
  %r3101 = and i1 %r3100, %r3097
  br i1 %r3101, label %arrlike.ic.header.624, label %arrlike.ic.miss.643

tav.get.merge.607:                                ; preds = %arrlike.elem.value.649, %arrlike.ic.miss.643, %arrlike.ic.spill_load.642, %arrlike.ic.inline.639, %arrlike.ic.array_load.627, %tav.k.f64.616, %tav.k.f32.615, %tav.k.u32.614, %tav.k.i32.613, %tav.k.u16.612, %tav.k.i16.611, %tav.k.u8.610, %tav.k.i8.609
  %.31188 = phi ptr addrspace(1) [ %.11186, %tav.k.i8.609 ], [ %.11186, %tav.k.u8.610 ], [ %.11186, %tav.k.i16.611 ], [ %.11186, %tav.k.u16.612 ], [ %.11186, %tav.k.i32.613 ], [ %.11186, %tav.k.u32.614 ], [ %.11186, %tav.k.f32.615 ], [ %.11186, %tav.k.f64.616 ], [ %.11186, %arrlike.ic.array_load.627 ], [ %rs4gc.s36.relocated860, %arrlike.ic.miss.643 ], [ %.11186, %arrlike.elem.value.649 ], [ %.11186, %arrlike.ic.inline.639 ], [ %.11186, %arrlike.ic.spill_load.642 ]
  %.381049 = phi ptr addrspace(1) [ %.361047, %tav.k.i8.609 ], [ %.361047, %tav.k.u8.610 ], [ %.361047, %tav.k.i16.611 ], [ %.361047, %tav.k.u16.612 ], [ %.361047, %tav.k.i32.613 ], [ %.361047, %tav.k.u32.614 ], [ %.361047, %tav.k.f32.615 ], [ %.361047, %tav.k.f64.616 ], [ %.361047, %arrlike.ic.array_load.627 ], [ %r48.0.relocated861, %arrlike.ic.miss.643 ], [ %.361047, %arrlike.elem.value.649 ], [ %.361047, %arrlike.ic.inline.639 ], [ %.361047, %arrlike.ic.spill_load.642 ]
  %.381009 = phi ptr addrspace(1) [ %.361007, %tav.k.i8.609 ], [ %.361007, %tav.k.u8.610 ], [ %.361007, %tav.k.i16.611 ], [ %.361007, %tav.k.u16.612 ], [ %.361007, %tav.k.i32.613 ], [ %.361007, %tav.k.u32.614 ], [ %.361007, %tav.k.f32.615 ], [ %.361007, %tav.k.f64.616 ], [ %.361007, %arrlike.ic.array_load.627 ], [ %r48.0.base.relocated858, %arrlike.ic.miss.643 ], [ %.361007, %arrlike.elem.value.649 ], [ %.361007, %arrlike.ic.inline.639 ], [ %.361007, %arrlike.ic.spill_load.642 ]
  %.49 = phi ptr addrspace(1) [ %.47, %tav.k.i8.609 ], [ %.47, %tav.k.u8.610 ], [ %.47, %tav.k.i16.611 ], [ %.47, %tav.k.u16.612 ], [ %.47, %tav.k.i32.613 ], [ %.47, %tav.k.u32.614 ], [ %.47, %tav.k.f32.615 ], [ %.47, %tav.k.f64.616 ], [ %.47, %arrlike.ic.array_load.627 ], [ %r57.0.relocated859, %arrlike.ic.miss.643 ], [ %.47, %arrlike.elem.value.649 ], [ %.47, %arrlike.ic.inline.639 ], [ %.47, %arrlike.ic.spill_load.642 ]
  %r3262 = phi double [ %r3051, %tav.k.i8.609 ], [ %r3057, %tav.k.u8.610 ], [ %r3063, %tav.k.i16.611 ], [ %r3069, %tav.k.u16.612 ], [ %r3074, %tav.k.i32.613 ], [ %r3079, %tav.k.u32.614 ], [ %r3084, %tav.k.f32.615 ], [ %r3088, %tav.k.f64.616 ], [ %r3145, %arrlike.elem.value.649 ], [ %r3173, %arrlike.ic.array_load.627 ], [ %r3243, %arrlike.ic.inline.639 ], [ %r3260, %arrlike.ic.spill_load.642 ], [ %r3261857, %arrlike.ic.miss.643 ]
  %r3263.rs4i = ptrtoint ptr addrspace(1) %.31188 to i64
  %r3263 = call i64 asm "", "=r,0"(i64 %r3263.rs4i) #7
  %statepoint_token851 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3263, double %r3262, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.381009, ptr addrspace(1) %.49, ptr addrspace(1) %.381049) ]
  %r3264852 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token851)
  %r48.0.base.relocated853 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token851, i32 0, i32 0) ; (%.381009, %.381009)
  %r57.0.relocated854 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token851, i32 1, i32 1) ; (%.49, %.49)
  %r48.0.relocated855 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token851, i32 0, i32 2) ; (%.381009, %.381049)
  %rs4gc.s37 = inttoptr i64 %r3264852 to ptr addrspace(1)
  %r3265.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s37 to i64
  %r3265 = call i64 asm "", "=r,0"(i64 %r3265.rs4i) #7
  %r3266 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3267 = icmp ne i32 %r3266, 0
  br i1 %r3267, label %shadow.root.barrier.651, label %shadow.root.barrier.done.652

tav.get.brand.608:                                ; preds = %pget.recv_merge.577
  %r3007 = bitcast double %r2995 to i64
  %r3008 = and i64 %r3007, 281474976710655
  %r3009 = sub nsw i64 %r3008, 8
  %r3010 = inttoptr i64 %r3009 to ptr
  %r3011 = load i8, ptr %r3010, align 1
  %r3012 = icmp eq i8 %r3011, 11
  %r3013 = add nuw nsw i64 %r3008, 8
  %r3014 = inttoptr i64 %r3013 to ptr
  %r3015 = load i8, ptr %r3014, align 1
  %r3016 = zext i8 %r3015 to i64
  %r3017 = icmp ule i64 %r3016, 8
  %r3020 = and i1 %r3012, %r3017
  br i1 %r3020, label %tav.get.fast.604, label %tav.get.slow.606

tav.k.i8.609:                                     ; preds = %tav.get.load.605
  %r3047 = add nuw nsw i64 %r3037, 0
  %r3048 = inttoptr i64 %r3047 to ptr
  %r3049 = load i8, ptr %r3048, align 1
  %r3050 = sext i8 %r3049 to i32
  %r3051 = sitofp i32 %r3050 to double
  br label %tav.get.merge.607

tav.k.u8.610:                                     ; preds = %tav.kd7.623, %tav.kd1.617
  %r3053 = add nuw nsw i64 %r3037, 0
  %r3054 = inttoptr i64 %r3053 to ptr
  %r3055 = load i8, ptr %r3054, align 1
  %r3056 = zext i8 %r3055 to i32
  %r3057 = uitofp nneg i32 %r3056 to double
  br label %tav.get.merge.607

tav.k.i16.611:                                    ; preds = %tav.kd2.618
  %r3059 = add nuw nsw i64 %r3037, 0
  %r3060 = inttoptr i64 %r3059 to ptr
  %r3061 = load i16, ptr %r3060, align 2
  %r3062 = sext i16 %r3061 to i32
  %r3063 = sitofp i32 %r3062 to double
  br label %tav.get.merge.607

tav.k.u16.612:                                    ; preds = %tav.kd3.619
  %r3065 = add nuw nsw i64 %r3037, 0
  %r3066 = inttoptr i64 %r3065 to ptr
  %r3067 = load i16, ptr %r3066, align 2
  %r3068 = zext i16 %r3067 to i32
  %r3069 = uitofp nneg i32 %r3068 to double
  br label %tav.get.merge.607

tav.k.i32.613:                                    ; preds = %tav.kd4.620
  %r3071 = add nuw nsw i64 %r3037, 0
  %r3072 = inttoptr i64 %r3071 to ptr
  %r3073 = load i32, ptr %r3072, align 4
  %r3074 = sitofp i32 %r3073 to double
  br label %tav.get.merge.607

tav.k.u32.614:                                    ; preds = %tav.kd5.621
  %r3076 = add nuw nsw i64 %r3037, 0
  %r3077 = inttoptr i64 %r3076 to ptr
  %r3078 = load i32, ptr %r3077, align 4
  %r3079 = uitofp i32 %r3078 to double
  br label %tav.get.merge.607

tav.k.f32.615:                                    ; preds = %tav.kd6.622
  %r3081 = add nuw nsw i64 %r3037, 0
  %r3082 = inttoptr i64 %r3081 to ptr
  %r3083 = load float, ptr %r3082, align 4
  %r3084 = fpext float %r3083 to double
  br label %tav.get.merge.607

tav.k.f64.616:                                    ; preds = %tav.kd7.623
  %r3086 = add nuw nsw i64 %r3037, 0
  %r3087 = inttoptr i64 %r3086 to ptr
  %r3088 = load double, ptr %r3087, align 8
  br label %tav.get.merge.607

tav.kd1.617:                                      ; preds = %tav.get.load.605
  %r3039 = icmp eq i64 %r3028, 1
  br i1 %r3039, label %tav.k.u8.610, label %tav.kd2.618

tav.kd2.618:                                      ; preds = %tav.kd1.617
  %r3040 = icmp eq i64 %r3028, 2
  br i1 %r3040, label %tav.k.i16.611, label %tav.kd3.619

tav.kd3.619:                                      ; preds = %tav.kd2.618
  %r3041 = icmp eq i64 %r3028, 3
  br i1 %r3041, label %tav.k.u16.612, label %tav.kd4.620

tav.kd4.620:                                      ; preds = %tav.kd3.619
  %r3042 = icmp eq i64 %r3028, 4
  br i1 %r3042, label %tav.k.i32.613, label %tav.kd5.621

tav.kd5.621:                                      ; preds = %tav.kd4.620
  %r3043 = icmp eq i64 %r3028, 5
  br i1 %r3043, label %tav.k.u32.614, label %tav.kd6.622

tav.kd6.622:                                      ; preds = %tav.kd5.621
  %r3044 = icmp eq i64 %r3028, 6
  br i1 %r3044, label %tav.k.f32.615, label %tav.kd7.623

tav.kd7.623:                                      ; preds = %tav.kd6.622
  %r3045 = icmp eq i64 %r3028, 7
  br i1 %r3045, label %tav.k.f64.616, label %tav.k.u8.610

arrlike.ic.header.624:                            ; preds = %tav.get.slow.606
  %r3107 = sub nuw nsw i64 %r3093, 8
  %r3108 = inttoptr i64 %r3107 to ptr
  %r3109 = load i8, ptr %r3108, align 1
  %r3111 = sub nuw nsw i64 %r3093, 7
  %r3112 = inttoptr i64 %r3111 to ptr
  %r3113 = load i8, ptr %r3112, align 1
  %r3114 = and i8 %r3113, -128
  %r3115 = icmp eq i8 %r3114, 0
  %r3116 = and i1 true, %r3115
  br i1 %r3116, label %arrlike.ic.brand.625, label %arrlike.ic.miss.643

arrlike.ic.brand.625:                             ; preds = %arrlike.ic.header.624
  %r3110 = icmp eq i8 %r3109, 1
  br i1 %r3110, label %arrlike.ic.array_guard.626, label %arrlike.elem.kind.644

arrlike.ic.array_guard.626:                       ; preds = %arrlike.ic.brand.625
  %r3148 = sub nuw nsw i64 %r3093, 6
  %r3149 = inttoptr i64 %r3148 to ptr
  %r3150 = load i16, ptr %r3149, align 2
  %r3151 = and i16 %r3150, 1024
  %r3152 = icmp eq i16 %r3151, 0
  %r3153 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r3154 = icmp eq i8 %r3153, 0
  %r3155 = inttoptr i64 %r3093 to ptr
  %r3156 = load i32, ptr %r3155, align 4
  %r3157 = add nuw nsw i64 %r3093, 4
  %r3158 = inttoptr i64 %r3157 to ptr
  %r3159 = load i32, ptr %r3158, align 4
  %r3160 = zext i32 %r3156 to i64
  %r3161 = zext i32 %r3159 to i64
  %r3162 = icmp ult i64 0, %r3160
  %r3163 = icmp ule i64 %r3160, %r3161
  %r3164 = and i1 %r3152, %r3154
  %r3165 = and i1 %r3164, %r3162
  %r3166 = and i1 %r3165, %r3163
  br i1 %r3166, label %arrlike.ic.array_load.627, label %arrlike.ic.miss.643

arrlike.ic.array_load.627:                        ; preds = %arrlike.ic.array_guard.626
  %r3168 = getelementptr inbounds nuw i64, ptr %r3155, i64 1
  %r3169 = load double, ptr %r3168, align 8
  %r3170 = bitcast double %r3169 to i64
  %r3171 = icmp eq i64 %r3170, 9222246136947933200
  %r3173 = select i1 %r3171, double 0x7FFC000000000001, double %r3169
  br label %tav.get.merge.607

arrlike.ic.shape.628:                             ; preds = %arrlike.elem.store.646, %arrlike.elem.meta.645
  %r3175 = inttoptr i64 %r3093 to ptr
  %r3176 = load i32, ptr %r3175, align 4
  %r3177 = add nuw nsw i64 %r3093, 4
  %r3178 = inttoptr i64 %r3177 to ptr
  %r3179 = load i32, ptr %r3178, align 4
  %r3180 = zext i32 %r3176 to i64
  %r3181 = zext i32 %r3179 to i64
  %r3182 = shl nuw i64 %r3180, 32
  %r3183 = or i64 %r3182, %r3181
  %r3184 = getelementptr i64, ptr %r3091, i64 0
  %r3185 = load i64, ptr %r3184, align 8
  %r3186 = icmp ne i64 %r3185, 0
  %r3187 = and i1 true, %r3186
  br i1 %r3187, label %arrlike.ic.identity.629, label %arrlike.ic.miss.643

arrlike.ic.identity.629:                          ; preds = %arrlike.ic.shape.628
  %r3188 = and i64 %r3185, -9223372036854775808
  %2 = icmp slt i64 %r3185, 0
  br i1 %2, label %arrlike.ic.family_meta.631, label %arrlike.ic.exact.630

arrlike.ic.exact.630:                             ; preds = %arrlike.ic.identity.629
  %r3190 = icmp eq i64 %r3183, %r3185
  br i1 %r3190, label %arrlike.ic.bounds.633, label %arrlike.ic.miss.643

arrlike.ic.family_meta.631:                       ; preds = %arrlike.ic.identity.629
  %r3191 = add nuw nsw i64 %r3093, 8
  %r3192 = inttoptr i64 %r3191 to ptr
  %r3193 = load i64, ptr %r3192, align 8
  %r3194 = icmp ne i64 %r3193, 0
  br i1 %r3194, label %arrlike.ic.family_token.632, label %arrlike.ic.miss.643

arrlike.ic.family_token.632:                      ; preds = %arrlike.ic.family_meta.631
  %r3195 = inttoptr i64 %r3193 to ptr
  %r3196 = getelementptr i64, ptr %r3195, i64 6
  %r3197 = load i64, ptr %r3196, align 8
  %r3198 = icmp eq i64 %r3197, %r3185
  br i1 %r3198, label %arrlike.ic.bounds.633, label %arrlike.ic.miss.643

arrlike.ic.bounds.633:                            ; preds = %arrlike.ic.family_token.632, %arrlike.ic.exact.630
  %r3199 = getelementptr i64, ptr %r3089, i64 1
  %r3200 = load i64, ptr %r3199, align 8
  %r3201 = getelementptr i64, ptr %r3089, i64 2
  %r3202 = load i64, ptr %r3201, align 8
  %r3203 = getelementptr i64, ptr %r3089, i64 3
  %r3204 = load i64, ptr %r3203, align 8
  %r3205 = getelementptr i64, ptr %r3089, i64 4
  %r3206 = load i64, ptr %r3205, align 8
  %r3207 = icmp ult i64 %r3200, %r3206
  br i1 %r3207, label %arrlike.ic.length_inline.634, label %arrlike.ic.length_spill_meta.635

arrlike.ic.length_inline.634:                     ; preds = %arrlike.ic.bounds.633
  %r3208 = shl i64 %r3200, 3
  %r3209 = add i64 %r3208, 16
  %r3210 = add i64 %r3093, %r3209
  %r3211 = inttoptr i64 %r3210 to ptr
  %r3212 = load double, ptr %r3211, align 8
  br label %arrlike.ic.range.638

arrlike.ic.length_spill_meta.635:                 ; preds = %arrlike.ic.bounds.633
  %r3213 = add nuw nsw i64 %r3093, 8
  %r3214 = inttoptr i64 %r3213 to ptr
  %r3215 = load i64, ptr %r3214, align 8
  %r3216 = icmp ne i64 %r3215, 0
  br i1 %r3216, label %arrlike.ic.length_spill_ptr.636, label %arrlike.ic.miss.643

arrlike.ic.length_spill_ptr.636:                  ; preds = %arrlike.ic.length_spill_meta.635
  %r3217 = inttoptr i64 %r3215 to ptr
  %r3218 = getelementptr i64, ptr %r3217, i64 4
  %r3219 = load i64, ptr %r3218, align 8
  %r3220 = icmp ne i64 %r3219, 0
  %r3221 = select i1 %r3220, i64 %r3219, i64 %r3215
  %r3222 = inttoptr i64 %r3221 to ptr
  %r3223 = load i32, ptr %r3222, align 4
  %r3224 = zext i32 %r3223 to i64
  %r3225 = icmp ult i64 %r3200, %r3224
  %r3226 = and i1 %r3220, %r3225
  br i1 %r3226, label %arrlike.ic.length_spill_load.637, label %arrlike.ic.miss.643

arrlike.ic.length_spill_load.637:                 ; preds = %arrlike.ic.length_spill_ptr.636
  %r3227 = add nuw nsw i64 %r3200, 1
  %r3228 = getelementptr inbounds nuw i64, ptr %r3222, i64 %r3227
  %r3229 = load double, ptr %r3228, align 8
  br label %arrlike.ic.range.638

arrlike.ic.range.638:                             ; preds = %arrlike.ic.length_spill_load.637, %arrlike.ic.length_inline.634
  %r3230 = phi double [ %r3212, %arrlike.ic.length_inline.634 ], [ %r3229, %arrlike.ic.length_spill_load.637 ]
  %r3231 = fcmp olt double 0.000000e+00, %r3230
  %r3232 = icmp ult i64 0, %r3204
  %r3233 = and i1 %r3231, %r3232
  %r3234 = add nuw nsw i64 %r3202, 0
  %r3235 = icmp ult i64 %r3234, %r3206
  %r3236 = and i1 %r3233, %r3235
  %r3237 = xor i1 %r3235, true
  %r3238 = and i1 %r3233, %r3237
  br i1 %r3236, label %arrlike.ic.inline.639, label %arrlike.ic.spill_or_miss.650

arrlike.ic.inline.639:                            ; preds = %arrlike.ic.range.638
  %r3239 = shl i64 %r3234, 3
  %r3240 = add i64 %r3239, 16
  %r3241 = add i64 %r3093, %r3240
  %r3242 = inttoptr i64 %r3241 to ptr
  %r3243 = load double, ptr %r3242, align 8
  br label %tav.get.merge.607

arrlike.ic.spill.640:                             ; preds = %arrlike.ic.spill_or_miss.650
  %r3244 = add nuw nsw i64 %r3093, 8
  %r3245 = inttoptr i64 %r3244 to ptr
  %r3246 = load i64, ptr %r3245, align 8
  %r3247 = icmp ne i64 %r3246, 0
  br i1 %r3247, label %arrlike.ic.spill_ptr.641, label %arrlike.ic.miss.643

arrlike.ic.spill_ptr.641:                         ; preds = %arrlike.ic.spill.640
  %r3248 = inttoptr i64 %r3246 to ptr
  %r3249 = getelementptr i64, ptr %r3248, i64 4
  %r3250 = load i64, ptr %r3249, align 8
  %r3251 = icmp ne i64 %r3250, 0
  %r3252 = select i1 %r3251, i64 %r3250, i64 %r3246
  %r3253 = inttoptr i64 %r3252 to ptr
  %r3254 = load i32, ptr %r3253, align 4
  %r3255 = zext i32 %r3254 to i64
  %r3256 = icmp ult i64 %r3234, %r3255
  %r3257 = and i1 %r3251, %r3256
  br i1 %r3257, label %arrlike.ic.spill_load.642, label %arrlike.ic.miss.643

arrlike.ic.spill_load.642:                        ; preds = %arrlike.ic.spill_ptr.641
  %r3258 = add nuw nsw i64 %r3234, 1
  %r3259 = getelementptr inbounds nuw i64, ptr %r3253, i64 %r3258
  %r3260 = load double, ptr %r3259, align 8
  br label %tav.get.merge.607

arrlike.ic.miss.643:                              ; preds = %arrlike.ic.spill_or_miss.650, %arrlike.elem.load.648, %arrlike.elem.bounds.647, %arrlike.elem.kind.644, %arrlike.ic.spill_ptr.641, %arrlike.ic.spill.640, %arrlike.ic.length_spill_ptr.636, %arrlike.ic.length_spill_meta.635, %arrlike.ic.family_token.632, %arrlike.ic.family_meta.631, %arrlike.ic.exact.630, %arrlike.ic.shape.628, %arrlike.ic.array_guard.626, %arrlike.ic.header.624, %tav.get.slow.606
  %statepoint_token856 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, ptr)) @js_packed_arraylike_index_get, i32 3, i32 0, double %r2995, double 0.000000e+00, ptr @perry_ic_test_json_cached_template_borrow_ts__33, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.361007, ptr addrspace(1) %.47, ptr addrspace(1) %.11186, ptr addrspace(1) %.361047) ]
  %r3261857 = call double @llvm.experimental.gc.result.f64(token %statepoint_token856)
  %r48.0.base.relocated858 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token856, i32 0, i32 0) ; (%.361007, %.361007)
  %r57.0.relocated859 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token856, i32 1, i32 1) ; (%.47, %.47)
  %rs4gc.s36.relocated860 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token856, i32 2, i32 2) ; (%.11186, %.11186)
  %r48.0.relocated861 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token856, i32 0, i32 3) ; (%.361007, %.361047)
  br label %tav.get.merge.607

arrlike.elem.kind.644:                            ; preds = %arrlike.ic.brand.625
  %r3117 = icmp eq i8 %r3109, 2
  br i1 %r3117, label %arrlike.elem.meta.645, label %arrlike.ic.miss.643

arrlike.elem.meta.645:                            ; preds = %arrlike.elem.kind.644
  %r3118 = add nuw nsw i64 %r3093, 8
  %r3119 = inttoptr i64 %r3118 to ptr
  %r3120 = load i64, ptr %r3119, align 8
  %r3121 = icmp ne i64 %r3120, 0
  br i1 %r3121, label %arrlike.elem.store.646, label %arrlike.ic.shape.628

arrlike.elem.store.646:                           ; preds = %arrlike.elem.meta.645
  %r3122 = inttoptr i64 %r3120 to ptr
  %r3123 = getelementptr i64, ptr %r3122, i64 12
  %r3124 = load i64, ptr %r3123, align 8
  %r3125 = icmp ne i64 %r3124, 0
  br i1 %r3125, label %arrlike.elem.bounds.647, label %arrlike.ic.shape.628

arrlike.elem.bounds.647:                          ; preds = %arrlike.elem.store.646
  %r3126 = sub i64 %r3124, 8
  %r3127 = inttoptr i64 %r3126 to ptr
  %r3128 = load i8, ptr %r3127, align 1
  %r3129 = icmp eq i8 %r3128, 1
  %r3130 = sub i64 %r3124, 7
  %r3131 = inttoptr i64 %r3130 to ptr
  %r3132 = load i8, ptr %r3131, align 1
  %r3133 = and i8 %r3132, -128
  %r3134 = icmp eq i8 %r3133, 0
  %r3135 = inttoptr i64 %r3124 to ptr
  %r3136 = load i32, ptr %r3135, align 4
  %r3137 = zext i32 %r3136 to i64
  %r3138 = icmp ult i64 0, %r3137
  %r3139 = and i1 %r3129, %r3134
  %r3140 = and i1 %r3139, %r3138
  br i1 %r3140, label %arrlike.elem.load.648, label %arrlike.ic.miss.643

arrlike.elem.load.648:                            ; preds = %arrlike.elem.bounds.647
  %r3142 = add i64 %r3124, 8
  %r3143 = add nuw nsw i64 %r3142, 0
  %r3144 = inttoptr i64 %r3143 to ptr
  %r3145 = load double, ptr %r3144, align 8
  %r3146 = bitcast double %r3145 to i64
  %r3147 = icmp eq i64 %r3146, 9222246136947933200
  br i1 %r3147, label %arrlike.ic.miss.643, label %arrlike.elem.value.649

arrlike.elem.value.649:                           ; preds = %arrlike.elem.load.648
  br label %tav.get.merge.607

arrlike.ic.spill_or_miss.650:                     ; preds = %arrlike.ic.range.638
  br i1 %r3238, label %arrlike.ic.spill.640, label %arrlike.ic.miss.643

shadow.root.barrier.651:                          ; preds = %tav.get.merge.607
  call void @js_write_barrier_root_nanbox(i64 %r3265) #7
  br label %shadow.root.barrier.done.652

shadow.root.barrier.done.652:                     ; preds = %shadow.root.barrier.651, %tav.get.merge.607
  %r3268.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s37 to i64
  %r3268 = call i64 asm "", "=r,0"(i64 %r3268.rs4i) #7
  %statepoint_token862 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r3268, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.base.relocated853, ptr addrspace(1) %r57.0.relocated854, ptr addrspace(1) %r48.0.relocated855) ]
  %r48.0.base.relocated863 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token862, i32 0, i32 0) ; (%r48.0.base.relocated853, %r48.0.base.relocated853)
  %r57.0.relocated864 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token862, i32 1, i32 1) ; (%r57.0.relocated854, %r57.0.relocated854)
  %r48.0.relocated865 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token862, i32 0, i32 2) ; (%r48.0.base.relocated853, %r48.0.relocated855)
  %r3269 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r3270 = icmp ne i32 %r3269, 0
  br i1 %r3270, label %gcpoll.653, label %gcpoll.done.654

gcpoll.653:                                       ; preds = %shadow.root.barrier.done.652
  %statepoint_token866 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.base.relocated863, ptr addrspace(1) %r57.0.relocated864, ptr addrspace(1) %r48.0.relocated865) ]
  %r48.0.base.relocated867 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token866, i32 0, i32 0) ; (%r48.0.base.relocated863, %r48.0.base.relocated863)
  %r57.0.relocated868 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token866, i32 1, i32 1) ; (%r57.0.relocated864, %r57.0.relocated864)
  %r48.0.relocated869 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token866, i32 0, i32 2) ; (%r48.0.base.relocated863, %r48.0.relocated865)
  br label %gcpoll.done.654

gcpoll.done.654:                                  ; preds = %gcpoll.653, %shadow.root.barrier.done.652
  %.391050 = phi ptr addrspace(1) [ %r48.0.relocated869, %gcpoll.653 ], [ %r48.0.relocated865, %shadow.root.barrier.done.652 ]
  %.391010 = phi ptr addrspace(1) [ %r48.0.base.relocated867, %gcpoll.653 ], [ %r48.0.base.relocated863, %shadow.root.barrier.done.652 ]
  %.50 = phi ptr addrspace(1) [ %r57.0.relocated868, %gcpoll.653 ], [ %r57.0.relocated864, %shadow.root.barrier.done.652 ]
  br label %for.update.464

shadow.root.barrier.655:                          ; preds = %for.exit.465
  call void @js_write_barrier_root_nanbox(i64 %r3276) #7
  br label %shadow.root.barrier.done.656

shadow.root.barrier.done.656:                     ; preds = %shadow.root.barrier.655, %for.exit.465
  %r3279 = load double, ptr @test_json_cached_template_borrow_ts_.str.16.handle, align 8
  %r3280.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r3280 = call i64 asm "", "=r,0"(i64 %r3280.rs4i) #7
  %statepoint_token870 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3280, double %r3279, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.relocated702, ptr addrspace(1) %r48.0.base.relocated703, ptr addrspace(1) %r57.0.relocated704) ]
  %r3281871 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token870)
  %r48.0.relocated872 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token870, i32 1, i32 0) ; (%r48.0.base.relocated703, %r48.0.relocated702)
  %r48.0.base.relocated873 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token870, i32 1, i32 1) ; (%r48.0.base.relocated703, %r48.0.base.relocated703)
  %r57.0.relocated874 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token870, i32 2, i32 2) ; (%r57.0.relocated704, %r57.0.relocated704)
  %rs4gc.s38 = inttoptr i64 %r3281871 to ptr addrspace(1)
  %r3282.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s38 to i64
  %r3282 = call i64 asm "", "=r,0"(i64 %r3282.rs4i) #7
  %r3283 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3284 = icmp ne i32 %r3283, 0
  br i1 %r3284, label %shadow.root.barrier.657, label %shadow.root.barrier.done.658

shadow.root.barrier.657:                          ; preds = %shadow.root.barrier.done.656
  call void @js_write_barrier_root_nanbox(i64 %r3282) #7
  br label %shadow.root.barrier.done.658

shadow.root.barrier.done.658:                     ; preds = %shadow.root.barrier.657, %shadow.root.barrier.done.656
  %r3285.rs4i = ptrtoint ptr addrspace(1) %r57.0.relocated874 to i64
  %r3285.rs4o = call i64 asm "", "=r,0"(i64 %r3285.rs4i) #7
  %r3285 = bitcast i64 %r3285.rs4o to double
  %r3286.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s38 to i64
  %r3286 = call i64 asm "", "=r,0"(i64 %r3286.rs4i) #7
  %statepoint_token875 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3286, double %r3285, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %r48.0.relocated872, ptr addrspace(1) %r48.0.base.relocated873) ]
  %r3287876 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token875)
  %r48.0.relocated877 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token875, i32 1, i32 0) ; (%r48.0.base.relocated873, %r48.0.relocated872)
  %r48.0.base.relocated878 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token875, i32 1, i32 1) ; (%r48.0.base.relocated873, %r48.0.base.relocated873)
  %rs4gc.s39 = inttoptr i64 %r3287876 to ptr addrspace(1)
  %r3288.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s39 to i64
  %r3288 = call i64 asm "", "=r,0"(i64 %r3288.rs4i) #7
  %r3289 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3290 = icmp ne i32 %r3289, 0
  br i1 %r3290, label %shadow.root.barrier.659, label %shadow.root.barrier.done.660

shadow.root.barrier.659:                          ; preds = %shadow.root.barrier.done.658
  call void @js_write_barrier_root_nanbox(i64 %r3288) #7
  br label %shadow.root.barrier.done.660

shadow.root.barrier.done.660:                     ; preds = %shadow.root.barrier.659, %shadow.root.barrier.done.658
  %r3291.rs4i = ptrtoint ptr addrspace(1) %r48.0.relocated877 to i64
  %r3291.rs4o = call i64 asm "", "=r,0"(i64 %r3291.rs4i) #7
  %r3291 = bitcast i64 %r3291.rs4o to double
  %r3292 = bitcast double %r3291 to i64
  %r3293 = and i64 %r3292, 281474976710655
  %r3294 = lshr i64 %r3292, 48
  %r3295 = and i64 %r3294, 65533
  %r3296 = icmp eq i64 %r3295, 32765
  %r3297 = icmp ugt i64 %r3293, 1048575
  %r3298 = and i1 %r3296, %r3297
  br i1 %r3298, label %plen.check_gc.661, label %plen.slow.663

plen.check_gc.661:                                ; preds = %shadow.root.barrier.done.660
  %r3299 = sub nuw nsw i64 %r3293, 8
  %r3300 = inttoptr i64 %r3299 to ptr
  %r3301 = load i8, ptr %r3300, align 1
  %r3302 = icmp eq i8 %r3301, 1
  %r3303 = icmp eq i8 %r3301, 3
  %r3304 = or i1 %r3302, %r3303
  %r3305 = sub nuw nsw i64 %r3293, 7
  %r3306 = inttoptr i64 %r3305 to ptr
  %r3307 = load i8, ptr %r3306, align 1
  %r3308 = and i8 %r3307, -128
  %r3309 = icmp eq i8 %r3308, 0
  %r3310 = and i1 %r3304, %r3309
  br i1 %r3310, label %plen.fast.662, label %plen.slow.663

plen.fast.662:                                    ; preds = %plen.check_gc.661
  %r3312 = inttoptr i64 %r3293 to ptr
  %r3313 = select i1 false, ptr @perry_null_guard_zero_test_json_cached_template_borrow_ts, ptr %r3312
  %r3314 = load i32, ptr %r3313, align 4
  %r3315 = uitofp i32 %r3314 to double
  br label %plen.merge.664

plen.slow.663:                                    ; preds = %plen.check_gc.661, %shadow.root.barrier.done.660
  %r3316 = lshr i64 %r3292, 48
  %r3317 = icmp eq i64 %r3316, 32765
  %r3318 = icmp uge i64 %r3293, 2199023255552
  %r3319 = icmp ult i64 %r3293, 140737488355328
  %r3320 = and i1 %r3317, %r3318
  %r3321 = and i1 %r3320, %r3319
  %r3322 = load ptr, ptr @perry_ic_test_json_cached_template_borrow_ts__34, align 8
  br i1 %r3321, label %plen.ic.header.665, label %plen.ic.miss.677

plen.merge.664:                                   ; preds = %plen.ic.merge.678, %plen.fast.662
  %.01189 = phi ptr addrspace(1) [ %rs4gc.s39, %plen.fast.662 ], [ %.11190, %plen.ic.merge.678 ]
  %r3397 = phi double [ %r3315, %plen.fast.662 ], [ %r3396, %plen.ic.merge.678 ]
  %r3398.rs4i = ptrtoint ptr addrspace(1) %.01189 to i64
  %r3398 = call i64 asm "", "=r,0"(i64 %r3398.rs4i) #7
  %statepoint_token879 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r3398, double %r3397, i32 0, i32 0)
  %r3399880 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token879)
  %rs4gc.s40 = inttoptr i64 %r3399880 to ptr addrspace(1)
  %r3400.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s40 to i64
  %r3400 = call i64 asm "", "=r,0"(i64 %r3400.rs4i) #7
  %r3401 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r3402 = icmp ne i32 %r3401, 0
  br i1 %r3402, label %shadow.root.barrier.682, label %shadow.root.barrier.done.683

plen.ic.header.665:                               ; preds = %plen.slow.663
  %r3324 = sub nuw nsw i64 %r3293, 8
  %r3325 = inttoptr i64 %r3324 to ptr
  %r3326 = load i8, ptr %r3325, align 1
  %r3327 = icmp eq i8 %r3326, 2
  %r3328 = sub nuw nsw i64 %r3293, 7
  %r3329 = inttoptr i64 %r3328 to ptr
  %r3330 = load i8, ptr %r3329, align 1
  %r3331 = and i8 %r3330, -128
  %r3332 = icmp eq i8 %r3331, 0
  %r3333 = and i1 %r3327, %r3332
  br i1 %r3333, label %plen.elem.meta.679, label %plen.ic.miss.677

plen.ic.shape.666:                                ; preds = %plen.elem.store.680, %plen.elem.meta.679
  %r3323 = icmp ne ptr %r3322, null
  br i1 %r3323, label %plen.ic.shape.probe.667, label %plen.ic.miss.677

plen.ic.shape.probe.667:                          ; preds = %plen.ic.shape.666
  %r3345 = inttoptr i64 %r3293 to ptr
  %r3346 = load i32, ptr %r3345, align 4
  %r3347 = add nuw nsw i64 %r3293, 4
  %r3348 = inttoptr i64 %r3347 to ptr
  %r3349 = load i32, ptr %r3348, align 4
  %r3350 = zext i32 %r3346 to i64
  %r3351 = zext i32 %r3349 to i64
  %r3352 = shl nuw i64 %r3350, 32
  %r3353 = or i64 %r3352, %r3351
  %r3354 = getelementptr i64, ptr %r3322, i64 0
  %r3355 = load i64, ptr %r3354, align 8
  %r3356 = icmp ne i64 %r3355, 0
  br i1 %r3356, label %plen.ic.identity.668, label %plen.ic.miss.677

plen.ic.identity.668:                             ; preds = %plen.ic.shape.probe.667
  %r3357 = and i64 %r3355, -9223372036854775808
  %3 = icmp slt i64 %r3355, 0
  br i1 %3, label %plen.ic.family_meta.670, label %plen.ic.exact.669

plen.ic.exact.669:                                ; preds = %plen.ic.identity.668
  %r3359 = icmp eq i64 %r3353, %r3355
  br i1 %r3359, label %plen.ic.slot.672, label %plen.ic.miss.677

plen.ic.family_meta.670:                          ; preds = %plen.ic.identity.668
  %r3360 = add nuw nsw i64 %r3293, 8
  %r3361 = inttoptr i64 %r3360 to ptr
  %r3362 = load i64, ptr %r3361, align 8
  %r3363 = icmp ne i64 %r3362, 0
  br i1 %r3363, label %plen.ic.family_token.671, label %plen.ic.miss.677

plen.ic.family_token.671:                         ; preds = %plen.ic.family_meta.670
  %r3364 = inttoptr i64 %r3362 to ptr
  %r3365 = getelementptr i64, ptr %r3364, i64 6
  %r3366 = load i64, ptr %r3365, align 8
  %r3367 = icmp eq i64 %r3366, %r3355
  br i1 %r3367, label %plen.ic.slot.672, label %plen.ic.miss.677

plen.ic.slot.672:                                 ; preds = %plen.ic.family_token.671, %plen.ic.exact.669
  %r3368 = getelementptr i64, ptr %r3322, i64 1
  %r3369 = load i64, ptr %r3368, align 8
  %r3370 = getelementptr i64, ptr %r3322, i64 2
  %r3371 = load i64, ptr %r3370, align 8
  %r3372 = icmp ult i64 %r3369, %r3371
  br i1 %r3372, label %plen.ic.inline.673, label %plen.ic.spill_meta.674

plen.ic.inline.673:                               ; preds = %plen.ic.slot.672
  %r3373 = shl i64 %r3369, 3
  %r3374 = add i64 %r3373, 16
  %r3375 = add i64 %r3293, %r3374
  %r3376 = inttoptr i64 %r3375 to ptr
  %r3377 = load double, ptr %r3376, align 8
  br label %plen.ic.merge.678

plen.ic.spill_meta.674:                           ; preds = %plen.ic.slot.672
  %r3378 = add nuw nsw i64 %r3293, 8
  %r3379 = inttoptr i64 %r3378 to ptr
  %r3380 = load i64, ptr %r3379, align 8
  %r3381 = icmp ne i64 %r3380, 0
  br i1 %r3381, label %plen.ic.spill_ptr.675, label %plen.ic.miss.677

plen.ic.spill_ptr.675:                            ; preds = %plen.ic.spill_meta.674
  %r3382 = inttoptr i64 %r3380 to ptr
  %r3383 = getelementptr i64, ptr %r3382, i64 4
  %r3384 = load i64, ptr %r3383, align 8
  %r3385 = icmp ne i64 %r3384, 0
  %r3386 = select i1 %r3385, i64 %r3384, i64 %r3380
  %r3387 = inttoptr i64 %r3386 to ptr
  %r3388 = load i32, ptr %r3387, align 4
  %r3389 = zext i32 %r3388 to i64
  %r3390 = icmp ult i64 %r3369, %r3389
  %r3391 = and i1 %r3385, %r3390
  br i1 %r3391, label %plen.ic.spill_load.676, label %plen.ic.miss.677

plen.ic.spill_load.676:                           ; preds = %plen.ic.spill_ptr.675
  %r3392 = add nuw nsw i64 %r3369, 1
  %r3393 = getelementptr inbounds nuw i64, ptr %r3387, i64 %r3392
  %r3394 = load double, ptr %r3393, align 8
  br label %plen.ic.merge.678

plen.ic.miss.677:                                 ; preds = %plen.ic.spill_ptr.675, %plen.ic.spill_meta.674, %plen.ic.family_token.671, %plen.ic.family_meta.670, %plen.ic.exact.669, %plen.ic.shape.probe.667, %plen.ic.shape.666, %plen.ic.header.665, %plen.slow.663
  %statepoint_token881 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, ptr)) @js_value_length_property_ic_f64, i32 2, i32 0, double %r3291, ptr @perry_ic_test_json_cached_template_borrow_ts__34, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s39) ]
  %r3395882 = call double @llvm.experimental.gc.result.f64(token %statepoint_token881)
  %rs4gc.s39.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token881, i32 0, i32 0) ; (%rs4gc.s39, %rs4gc.s39)
  br label %plen.ic.merge.678

plen.ic.merge.678:                                ; preds = %plen.elem.length.681, %plen.ic.miss.677, %plen.ic.spill_load.676, %plen.ic.inline.673
  %.11190 = phi ptr addrspace(1) [ %rs4gc.s39, %plen.elem.length.681 ], [ %rs4gc.s39, %plen.ic.inline.673 ], [ %rs4gc.s39, %plen.ic.spill_load.676 ], [ %rs4gc.s39.relocated, %plen.ic.miss.677 ]
  %r3396 = phi double [ %r3344, %plen.elem.length.681 ], [ %r3377, %plen.ic.inline.673 ], [ %r3394, %plen.ic.spill_load.676 ], [ %r3395882, %plen.ic.miss.677 ]
  br label %plen.merge.664

plen.elem.meta.679:                               ; preds = %plen.ic.header.665
  %r3334 = add nuw nsw i64 %r3293, 8
  %r3335 = inttoptr i64 %r3334 to ptr
  %r3336 = load i64, ptr %r3335, align 8
  %r3337 = icmp ne i64 %r3336, 0
  br i1 %r3337, label %plen.elem.store.680, label %plen.ic.shape.666

plen.elem.store.680:                              ; preds = %plen.elem.meta.679
  %r3338 = inttoptr i64 %r3336 to ptr
  %r3339 = getelementptr i64, ptr %r3338, i64 12
  %r3340 = load i64, ptr %r3339, align 8
  %r3341 = icmp ne i64 %r3340, 0
  br i1 %r3341, label %plen.elem.length.681, label %plen.ic.shape.666

plen.elem.length.681:                             ; preds = %plen.elem.store.680
  %r3342 = inttoptr i64 %r3340 to ptr
  %r3343 = load i32, ptr %r3342, align 4
  %r3344 = uitofp i32 %r3343 to double
  br label %plen.ic.merge.678

shadow.root.barrier.682:                          ; preds = %plen.merge.664
  call void @js_write_barrier_root_nanbox(i64 %r3400) #7
  br label %shadow.root.barrier.done.683

shadow.root.barrier.done.683:                     ; preds = %shadow.root.barrier.682, %plen.merge.664
  %r3403.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s40 to i64
  %r3403 = call i64 asm "", "=r,0"(i64 %r3403.rs4i) #7
  %statepoint_token883 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r3403, i32 0, i32 0)
  %statepoint_token884 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token885 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token886 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token887 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token888 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.684

event_loop.header.684:                            ; preds = %event_loop.body_wait.689, %event_loop.body_check.688, %shadow.root.barrier.done.683
  %statepoint_token889 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r3408890 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token889)
  %r3409 = icmp ne i32 %r3408890, 0
  br i1 %r3409, label %event_loop.host_return.686, label %event_loop.check_pending.685

event_loop.check_pending.685:                     ; preds = %event_loop.header.684
  %statepoint_token891 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r3410892 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token891)
  %statepoint_token893 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r3411894 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token893)
  %statepoint_token895 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r3412896 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token895)
  %statepoint_token897 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r3413898 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token897)
  %statepoint_token899 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r3414900 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token899)
  %statepoint_token901 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r3415902 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token901)
  %r3416 = or i32 %r3410892, %r3411894
  %r3417 = or i32 %r3412896, %r3413898
  %r3418 = or i32 %r3417, %r3414900
  %r3419 = or i32 %r3416, %r3418
  %r3420 = or i32 %r3419, 0
  %r3421 = or i32 %r3420, %r3415902
  %r3422 = icmp ne i32 %r3421, 0
  br i1 %r3422, label %event_loop.body.687, label %event_loop.exit.690

event_loop.host_return.686:                       ; preds = %event_loop.header.684
  call void @js_typed_feedback_maybe_dump_trace() #7
  ret i32 0

event_loop.body.687:                              ; preds = %event_loop.check_pending.685
  %statepoint_token903 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token904 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.688

event_loop.body_check.688:                        ; preds = %event_loop.body.687
  %statepoint_token905 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r3424906 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token905)
  %statepoint_token907 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r3425908 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token907)
  %statepoint_token909 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r3426910 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token909)
  %statepoint_token911 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r3427912 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token911)
  %statepoint_token913 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r3428914 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token913)
  %statepoint_token915 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r3429916 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token915)
  %r3430 = or i32 %r3424906, %r3425908
  %r3431 = or i32 %r3426910, %r3427912
  %r3432 = or i32 %r3431, %r3428914
  %r3433 = or i32 %r3430, %r3432
  %r3434 = or i32 %r3433, 0
  %r3435 = or i32 %r3434, %r3429916
  %r3436 = icmp ne i32 %r3435, 0
  br i1 %r3436, label %event_loop.body_wait.689, label %event_loop.header.684

event_loop.body_wait.689:                         ; preds = %event_loop.body_check.688
  %statepoint_token917 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.684

event_loop.exit.690:                              ; preds = %event_loop.check_pending.685
  %statepoint_token918 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token919 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token920 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token921 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token922 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token923 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token924 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token925 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token926 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r3439927 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token926)
  call void @js_typed_feedback_maybe_dump_trace() #7
  ret i32 %r3439927
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_cached_template_borrow_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.0.bytes, i32 5)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @test_json_cached_template_borrow_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.1.bytes, i32 8)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @test_json_cached_template_borrow_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.2.bytes, i32 2)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @test_json_cached_template_borrow_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.3.bytes, i32 4)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @test_json_cached_template_borrow_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.4.bytes, i32 106)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @test_json_cached_template_borrow_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.5.bytes, i32 107)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @test_json_cached_template_borrow_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.6.bytes, i32 109)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @test_json_cached_template_borrow_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.7.bytes, i32 5)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @test_json_cached_template_borrow_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.7.handle to i64))
  %r25 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.8.bytes, i32 7)
  %r26 = call double @js_nanbox_string(i64 %r25)
  store double %r26, ptr @test_json_cached_template_borrow_ts_.str.8.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.8.handle to i64))
  %r28 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.9.bytes, i32 4)
  %r29 = call double @js_nanbox_string(i64 %r28)
  store double %r29, ptr @test_json_cached_template_borrow_ts_.str.9.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.9.handle to i64))
  %r31 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.10.bytes, i32 6)
  %r32 = call double @js_nanbox_string(i64 %r31)
  store double %r32, ptr @test_json_cached_template_borrow_ts_.str.10.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.10.handle to i64))
  %r34 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.11.bytes, i32 31)
  %r35 = call double @js_nanbox_string(i64 %r34)
  store double %r35, ptr @test_json_cached_template_borrow_ts_.str.11.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.11.handle to i64))
  %r37 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.12.bytes, i32 23)
  %r38 = call double @js_nanbox_string(i64 %r37)
  store double %r38, ptr @test_json_cached_template_borrow_ts_.str.12.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.12.handle to i64))
  %r40 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.13.bytes, i32 9)
  %r41 = call double @js_nanbox_string(i64 %r40)
  store double %r41, ptr @test_json_cached_template_borrow_ts_.str.13.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.13.handle to i64))
  %r43 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.14.bytes, i32 22)
  %r44 = call double @js_nanbox_string(i64 %r43)
  store double %r44, ptr @test_json_cached_template_borrow_ts_.str.14.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.14.handle to i64))
  %r46 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.15.bytes, i32 5)
  %r47 = call double @js_nanbox_string(i64 %r46)
  store double %r47, ptr @test_json_cached_template_borrow_ts_.str.15.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.15.handle to i64))
  %r49 = call i64 @js_string_from_bytes(ptr @test_json_cached_template_borrow_ts_.str.16.bytes, i32 4)
  %r50 = call double @js_nanbox_string(i64 %r49)
  store double %r50, ptr @test_json_cached_template_borrow_ts_.str.16.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @test_json_cached_template_borrow_ts_.str.16.handle to i64))
  call void @js_register_function_name_static(ptr @test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18_constructor, ptr @test_json_cached_template_borrow_ts_.str.1, i32 32)
  call void @js_register_function_name_static(ptr @test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38_constructor, ptr @test_json_cached_template_borrow_ts_.str.2, i32 32)
  %r52 = call i64 @js_build_class_keys_array(i32 1, i32 2, ptr @perry_class_keys_packed_test_json_cached_template_borrow_ts__0, i32 15)
  store i64 %r52, ptr @perry_class_keys_test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18, align 8
  call void @js_write_barrier_root_heap_word(i64 %r52)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18 to i64))
  %r54 = call i32 @js_gc_typed_shape_id_for_keys(i32 1, i64 %r52, i32 2, ptr null, i32 0, ptr @perry_typed_shape_mask_test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18, i32 1)
  store i32 %r54, ptr @perry_class_shape_id_test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18, align 4
  %r55 = zext i32 %r54 to i64
  %r56 = shl nuw i64 %r55, 32
  %r57 = or i64 %r56, 1
  %r58 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r57, i32 1
  store <2 x i64> %r58, ptr @perry_class_header_image_test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18, align 8
  %r59 = call i64 @js_build_class_keys_array(i32 2, i32 2, ptr @perry_class_keys_packed_test_json_cached_template_borrow_ts__1, i32 8)
  store i64 %r59, ptr @perry_class_keys_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38, align 8
  call void @js_write_barrier_root_heap_word(i64 %r59)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38 to i64))
  %r61 = call i32 @js_gc_typed_shape_id_for_keys(i32 2, i64 %r59, i32 2, ptr @perry_typed_shape_raw_f64_mask_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38, i32 1, ptr @perry_typed_shape_mask_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38, i32 1)
  store i32 %r61, ptr @perry_class_shape_id_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38, align 4
  %r62 = zext i32 %r61 to i64
  %r63 = shl nuw i64 %r62, 32
  %r64 = or i64 %r63, 2
  %r65 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r64, i32 1
  store <2 x i64> %r65, ptr @perry_class_header_image_test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38, align 8
  call void @js_register_class_constructor(i64 1, i64 ptrtoint (ptr @test_json_cached_template_borrow_ts____AnonShape_a0fce79cb5df4a18_constructor to i64), i64 2, i64 0)
  call void @js_register_class_constructor(i64 2, i64 ptrtoint (ptr @test_json_cached_template_borrow_ts____AnonShape_570a27fd5b93ea38_constructor to i64), i64 2, i64 0)
  call void @js_register_class_id(i32 1)
  call void @js_register_class_id(i32 2)
  call void @js_register_anon_shape_class_id(i32 1)
  call void @js_register_anon_shape_class_id(i32 2)
  call void @js_register_class_length(i32 1, i32 2)
  call void @js_register_class_length(i32 2, i32 2)
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_test_json_cached_template_borrow_ts() #6 {
entry.0:
  call void @__perry_init_strings_test_json_cached_template_borrow_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { "gc-leaf-function" }

!0 = !{}
