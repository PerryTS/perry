; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/borrowed-template-r13/candidate-ir-native/callback-only/.perry-trace/llvm/callback_only_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@callback_only_ts_.str.0 = private unnamed_addr constant [121 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/borrowed-template-r13/callback-only.ts\00"
@callback_only_ts_.str.0.bytes = private unnamed_addr constant [10 x i8] c"callback-\00"
@callback_only_ts_.str.1.bytes = private unnamed_addr constant [3 x i8] c"id\00"
@callback_only_ts_.str.2.bytes = private unnamed_addr constant [5 x i8] c"item\00"
@callback_only_ts_.str.3.bytes = private unnamed_addr constant [5 x i8] c"text\00"
@callback_only_ts_.str.4.bytes = private unnamed_addr constant [16 x i8] c"moving-callback\00"
@perry_class_keys_packed_callback_only_ts__0 = private unnamed_addr constant [4 x i8] c"id\00\00"
@perry_class_keys_packed_callback_only_ts__1 = private unnamed_addr constant [6 x i8] c"item\00\00"
@perry_class_keys_packed_callback_only_ts__2 = private unnamed_addr constant [9 x i8] c"id\00text\00\00"
@callback_only_ts_.str.1 = private unnamed_addr constant [33 x i8] c"new __AnonShape_4895323cc6307da4\00"
@callback_only_ts_.str.2 = private unnamed_addr constant [33 x i8] c"new __AnonShape_7924916bbe3686f7\00"
@callback_only_ts_.str.3 = private unnamed_addr constant [33 x i8] c"new __AnonShape_6ef7d34fbe1f1d2c\00"
@callback_only_ts_.str.4 = private unnamed_addr constant [256 x i8] c"function(key: string, value: any) {\0A    const keep: any[] = [];\0A    for (let j = 0; j < 64; j++) {\0A        keep.push({id: j, text: 'callback-' + j});\0A        callbackChecksum += keep[j].id;\0A    }\0A    if (key === 'id') return value + 1;\0A    return value;\0A}\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_callback_only_ts = internal global i32 0
@perry_class_keys_callback_only_ts____AnonShape_4895323cc6307da4 = internal global i64 0
@perry_class_shape_id_callback_only_ts____AnonShape_4895323cc6307da4 = global i32 0
@perry_class_header_image_callback_only_ts____AnonShape_4895323cc6307da4 = internal global <2 x i64> zeroinitializer
@perry_class_keys_callback_only_ts____AnonShape_7924916bbe3686f7 = internal global i64 0
@perry_class_shape_id_callback_only_ts____AnonShape_7924916bbe3686f7 = global i32 0
@perry_class_header_image_callback_only_ts____AnonShape_7924916bbe3686f7 = internal global <2 x i64> zeroinitializer
@perry_class_keys_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c = internal global i64 0
@perry_class_shape_id_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c = global i32 0
@perry_class_header_image_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c = internal global <2 x i64> zeroinitializer
@perry_global_callback_only_ts__0 = global double 0x7FFC000000000001
@perry_ic_callback_only_ts__3 = private global ptr null
@perry_concat_site_callback_only_ts__0 = private global [32 x i64] zeroinitializer
@callback_only_ts_.str.0.handle = internal global double 0.000000e+00
@callback_only_ts_.str.1.handle = internal global double 0.000000e+00
@callback_only_ts_.str.2.handle = internal global double 0.000000e+00
@callback_only_ts_.str.3.handle = internal global double 0.000000e+00
@callback_only_ts_.str.4.handle = internal global double 0.000000e+00
@perry_typed_shape_raw_f64_mask_callback_only_ts____AnonShape_4895323cc6307da4 = private unnamed_addr constant [1 x i64] [i64 1]
@perry_typed_shape_mask_callback_only_ts____AnonShape_7924916bbe3686f7 = private unnamed_addr constant [1 x i64] [i64 1]
@perry_typed_shape_raw_f64_mask_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c = private unnamed_addr constant [1 x i64] [i64 1]
@perry_typed_shape_mask_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c = private unnamed_addr constant [1 x i64] [i64 2]

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_3()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define double @perry_closure_callback_only_ts__2(i64 %this_closure, double %arg3, double %arg4) #6 gc "statepoint-example" {
entry.0:
  %r79 = load <2 x i64>, ptr @perry_class_header_image_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c, align 16
  %rs4gc.b2 = bitcast double %arg3 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg4 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s2) ]
  %r45 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s2, %rs4gc.s2)
  %r5 = or i64 %r45, 9222527611924643840
  %r6 = bitcast i64 %r5 to double
  %rs4gc.b4 = bitcast double %r6 to i64
  %rs4gc.s4 = inttoptr i64 %rs4gc.b4 to ptr addrspace(1)
  %r7.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s4 to i64
  %r7 = call i64 asm "", "=r,0"(i64 %r7.rs4i) #7
  %r8 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r9 = icmp ne i32 %r8, 0
  br i1 %r9, label %shadow.root.barrier.1, label %shadow.root.barrier.done.2

shadow.root.barrier.1:                            ; preds = %entry.0
  call void @js_write_barrier_root_nanbox(i64 %r7) #7
  br label %shadow.root.barrier.done.2

shadow.root.barrier.done.2:                       ; preds = %shadow.root.barrier.1, %entry.0
  %r10 = bitcast double %r6 to i64
  %r11 = and i64 %r10, 281474976710655
  call void @js_array_declare_all_pointer_elements(i64 %r11) #7
  br label %for.cond.3

for.cond.3:                                       ; preds = %for.update.5, %shadow.root.barrier.done.2
  %.0105 = phi ptr addrspace(1) [ %rs4gc.s2.relocated, %shadow.root.barrier.done.2 ], [ %.12117, %for.update.5 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3.relocated, %shadow.root.barrier.done.2 ], [ %.12, %for.update.5 ]
  %r49.0 = phi ptr [ null, %shadow.root.barrier.done.2 ], [ %r49.1, %for.update.5 ]
  %r12.0 = phi i32 [ 0, %shadow.root.barrier.done.2 ], [ %r478, %for.update.5 ]
  %r3.0.base = phi ptr addrspace(1) [ %rs4gc.s4, %shadow.root.barrier.done.2 ], [ %.4141, %for.update.5 ], !is_base_value !0
  %r3.0 = phi ptr addrspace(1) [ %rs4gc.s4, %shadow.root.barrier.done.2 ], [ %.4146, %for.update.5 ]
  %r14 = sitofp i32 %r12.0 to double
  %r15 = fcmp olt double %r14, 6.400000e+01
  %r16 = select i1 %r15, i64 9222246136947933188, i64 9222246136947933187
  %r17 = bitcast i64 %r16 to double
  %r18 = icmp eq i64 %r16, 9222246136947933188
  br i1 %r18, label %for.body.4, label %for.exit.6

for.body.4:                                       ; preds = %for.cond.3
  %r20 = sitofp i32 %r12.0 to double
  %r21 = load double, ptr @callback_only_ts_.str.0.handle, align 8
  %r23 = sitofp i32 %r12.0 to double
  %r24 = fcmp oge double %r23, 0.000000e+00
  %r25 = fcmp olt double %r23, 3.200000e+01
  %r26 = and i1 %r24, %r25
  br i1 %r26, label %csite.chk.7, label %csite.plain.10

for.update.5:                                     ; preds = %gcpoll.done.91
  %r478 = add i32 %r12.0, 1
  %r479 = sitofp i32 %r12.0 to double
  %r480 = sitofp i32 %r478 to double
  br label %for.cond.3

for.exit.6:                                       ; preds = %for.cond.3
  %r481.rs4i = ptrtoint ptr addrspace(1) %.0105 to i64
  %r481.rs4o = call i64 asm "", "=r,0"(i64 %r481.rs4i) #7
  %r481 = bitcast i64 %r481.rs4o to double
  %r482 = load double, ptr @callback_only_ts_.str.1.handle, align 8
  %r483 = bitcast double %r481 to i64
  %r484 = bitcast double %r482 to i64
  %r485 = icmp eq i64 %r483, %r484
  br i1 %r485, label %streqlit.true.97, label %streqlit.sso.92

csite.chk.7:                                      ; preds = %for.body.4
  %r27 = fptosi double %r23 to i32
  %r28 = sitofp i32 %r27 to double
  %r29 = fcmp oeq double %r28, %r23
  %r30 = sext i32 %r27 to i64
  %r31 = getelementptr [32 x i64], ptr @perry_concat_site_callback_only_ts__0, i64 0, i64 %r30
  %r32 = load i64, ptr %r31, align 8
  %r33 = icmp ne i64 %r32, 0
  %r34 = and i1 %r29, %r33
  br i1 %r34, label %csite.hit.8, label %csite.fill.9

csite.hit.8:                                      ; preds = %csite.chk.7
  %r35 = bitcast i64 %r32 to double
  br label %csite.merge.11

csite.fill.9:                                     ; preds = %csite.chk.7
  %r36 = bitcast double %r21 to i64
  %r37 = and i64 %r36, 281474976710655
  %statepoint_token6 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, double)) @js_string_concat_site_value, i32 3, i32 0, i64 ptrtoint (ptr @perry_concat_site_callback_only_ts__0 to i64), i64 %r37, double %r23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0, ptr addrspace(1) %.0105, ptr addrspace(1) %r3.0.base, ptr addrspace(1) %r3.0) ]
  %r3910 = call double @llvm.experimental.gc.result.f64(token %statepoint_token6)
  %rs4gc.s3.relocated11 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token6, i32 0, i32 0) ; (%.0, %.0)
  %rs4gc.s2.relocated12 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token6, i32 1, i32 1) ; (%.0105, %.0105)
  %r3.0.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token6, i32 2, i32 2) ; (%r3.0.base, %r3.0.base)
  %r3.0.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token6, i32 2, i32 3) ; (%r3.0.base, %r3.0)
  br label %csite.merge.11

csite.plain.10:                                   ; preds = %for.body.4
  %r40 = bitcast double %r21 to i64
  %r41 = and i64 %r40, 281474976710655
  %statepoint_token13 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double)) @js_string_concat_value_box, i32 2, i32 0, i64 %r41, double %r23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0, ptr addrspace(1) %.0105, ptr addrspace(1) %r3.0.base, ptr addrspace(1) %r3.0) ]
  %r4214 = call double @llvm.experimental.gc.result.f64(token %statepoint_token13)
  %rs4gc.s3.relocated15 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token13, i32 0, i32 0) ; (%.0, %.0)
  %rs4gc.s2.relocated16 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token13, i32 1, i32 1) ; (%.0105, %.0105)
  %r3.0.base.relocated17 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token13, i32 2, i32 2) ; (%r3.0.base, %r3.0.base)
  %r3.0.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token13, i32 2, i32 3) ; (%r3.0.base, %r3.0)
  br label %csite.merge.11

csite.merge.11:                                   ; preds = %csite.plain.10, %csite.fill.9, %csite.hit.8
  %.0124 = phi ptr addrspace(1) [ %r3.0, %csite.hit.8 ], [ %r3.0.relocated, %csite.fill.9 ], [ %r3.0.relocated18, %csite.plain.10 ]
  %.0118 = phi ptr addrspace(1) [ %r3.0.base, %csite.hit.8 ], [ %r3.0.base.relocated, %csite.fill.9 ], [ %r3.0.base.relocated17, %csite.plain.10 ]
  %.1106 = phi ptr addrspace(1) [ %.0105, %csite.hit.8 ], [ %rs4gc.s2.relocated12, %csite.fill.9 ], [ %rs4gc.s2.relocated16, %csite.plain.10 ]
  %.1 = phi ptr addrspace(1) [ %.0, %csite.hit.8 ], [ %rs4gc.s3.relocated11, %csite.fill.9 ], [ %rs4gc.s3.relocated15, %csite.plain.10 ]
  %r43 = phi double [ %r35, %csite.hit.8 ], [ %r3910, %csite.fill.9 ], [ %r4214, %csite.plain.10 ]
  %r44 = bitcast double %r43 to i64
  %rs4gc.s5 = inttoptr i64 %r44 to ptr addrspace(1)
  %r46.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s5 to i64
  %r46 = call i64 asm "", "=r,0"(i64 %r46.rs4i) #7
  %r47 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r48 = icmp ne i32 %r47, 0
  br i1 %r48, label %shadow.root.barrier.12, label %shadow.root.barrier.done.13

shadow.root.barrier.12:                           ; preds = %csite.merge.11
  call void @js_write_barrier_root_nanbox(i64 %r46) #7
  br label %shadow.root.barrier.done.13

shadow.root.barrier.done.13:                      ; preds = %shadow.root.barrier.12, %csite.merge.11
  %r51 = icmp eq ptr %r49.0, null
  br i1 %r51, label %arena_state.init.14, label %arena_state.ready.15

arena_state.init.14:                              ; preds = %shadow.root.barrier.done.13
  %r52 = load atomic i64, ptr @PERRY_HOT_TSD_KEY monotonic, align 8
  %r53 = icmp ne i64 %r52, -1
  br i1 %r53, label %arena_state.hot_tls.tsd.16, label %arena_state.hot_tls.slow.18

arena_state.ready.15:                             ; preds = %arena_state.hot_tls.resolved.20, %shadow.root.barrier.done.13
  %.0130 = phi ptr addrspace(1) [ %.1131, %arena_state.hot_tls.resolved.20 ], [ %rs4gc.s5, %shadow.root.barrier.done.13 ]
  %.1125 = phi ptr addrspace(1) [ %.2126, %arena_state.hot_tls.resolved.20 ], [ %.0124, %shadow.root.barrier.done.13 ]
  %.1119 = phi ptr addrspace(1) [ %.2120, %arena_state.hot_tls.resolved.20 ], [ %.0118, %shadow.root.barrier.done.13 ]
  %.2107 = phi ptr addrspace(1) [ %.3108, %arena_state.hot_tls.resolved.20 ], [ %.1106, %shadow.root.barrier.done.13 ]
  %.2 = phi ptr addrspace(1) [ %.3, %arena_state.hot_tls.resolved.20 ], [ %.1, %shadow.root.barrier.done.13 ]
  %r49.1 = phi ptr [ %r49.2, %arena_state.hot_tls.resolved.20 ], [ %r49.0, %shadow.root.barrier.done.13 ]
  %r67 = phi ptr [ %r49.0, %shadow.root.barrier.done.13 ], [ %r66, %arena_state.hot_tls.resolved.20 ]
  %r68 = getelementptr i8, ptr %r67, i64 8
  %r69 = load i64, ptr %r68, align 8
  %r70 = add i64 %r69, 40
  %r71 = getelementptr i8, ptr %r67, i64 16
  %r72 = load i64, ptr %r71, align 8
  %r73 = icmp ule i64 %r70, %r72
  br i1 %r73, label %alloc.fast.21, label %alloc.slow.22

arena_state.hot_tls.tsd.16:                       ; preds = %arena_state.init.14
  %r54 = call i64 asm sideeffect "mrs $0, tpidrro_el0", "=r"() #7
  %r55 = and i64 %r54, -8
  %r56 = shl i64 %r52, 3
  %r57 = add i64 %r55, %r56
  %r58 = inttoptr i64 %r57 to ptr
  %r59 = load ptr, ptr %r58, align 8
  %r60 = icmp ne ptr %r59, null
  br i1 %r60, label %arena_state.hot_tls.fast.17, label %arena_state.hot_tls.slow.18

arena_state.hot_tls.fast.17:                      ; preds = %arena_state.hot_tls.tsd.16
  %r61 = getelementptr i8, ptr %r59, i64 8
  %r62 = load ptr, ptr %r61, align 8
  %r63 = load ptr, ptr %r62, align 8
  %r64 = icmp ne ptr %r63, null
  br i1 %r64, label %arena_state.hot_tls.ready.19, label %arena_state.hot_tls.slow.18

arena_state.hot_tls.slow.18:                      ; preds = %arena_state.hot_tls.fast.17, %arena_state.hot_tls.tsd.16, %arena_state.init.14
  %statepoint_token19 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr ()) @js_inline_arena_state, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1, ptr addrspace(1) %.1106, ptr addrspace(1) %.0118, ptr addrspace(1) %.0124, ptr addrspace(1) %rs4gc.s5) ]
  %r6520 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token19)
  %rs4gc.s3.relocated21 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 0, i32 0) ; (%.1, %.1)
  %rs4gc.s2.relocated22 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 1, i32 1) ; (%.1106, %.1106)
  %r3.0.base.relocated23 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 2, i32 2) ; (%.0118, %.0118)
  %r3.0.relocated24 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 2, i32 3) ; (%.0118, %.0124)
  %rs4gc.s5.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 4, i32 4) ; (%rs4gc.s5, %rs4gc.s5)
  br label %arena_state.hot_tls.resolved.20

arena_state.hot_tls.ready.19:                     ; preds = %arena_state.hot_tls.fast.17
  br label %arena_state.hot_tls.resolved.20

arena_state.hot_tls.resolved.20:                  ; preds = %arena_state.hot_tls.ready.19, %arena_state.hot_tls.slow.18
  %.1131 = phi ptr addrspace(1) [ %rs4gc.s5, %arena_state.hot_tls.ready.19 ], [ %rs4gc.s5.relocated, %arena_state.hot_tls.slow.18 ]
  %.2126 = phi ptr addrspace(1) [ %.0124, %arena_state.hot_tls.ready.19 ], [ %r3.0.relocated24, %arena_state.hot_tls.slow.18 ]
  %.2120 = phi ptr addrspace(1) [ %.0118, %arena_state.hot_tls.ready.19 ], [ %r3.0.base.relocated23, %arena_state.hot_tls.slow.18 ]
  %.3108 = phi ptr addrspace(1) [ %.1106, %arena_state.hot_tls.ready.19 ], [ %rs4gc.s2.relocated22, %arena_state.hot_tls.slow.18 ]
  %.3 = phi ptr addrspace(1) [ %.1, %arena_state.hot_tls.ready.19 ], [ %rs4gc.s3.relocated21, %arena_state.hot_tls.slow.18 ]
  %r49.2 = phi ptr [ %r62, %arena_state.hot_tls.ready.19 ], [ %r6520, %arena_state.hot_tls.slow.18 ]
  %r66 = phi ptr [ %r62, %arena_state.hot_tls.ready.19 ], [ %r6520, %arena_state.hot_tls.slow.18 ]
  br label %arena_state.ready.15

alloc.fast.21:                                    ; preds = %arena_state.ready.15
  store i64 %r70, ptr %r68, align 8
  %r74 = load ptr, ptr %r67, align 8
  %r75 = getelementptr i8, ptr %r74, i64 %r69
  br label %alloc.merge.23

alloc.slow.22:                                    ; preds = %arena_state.ready.15
  %statepoint_token25 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(ptr (ptr, i64, i64)) @js_inline_arena_slow_alloc, i32 3, i32 0, ptr %r67, i64 40, i64 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2, ptr addrspace(1) %.2107, ptr addrspace(1) %.1119, ptr addrspace(1) %.1125, ptr addrspace(1) %.0130) ]
  %r7626 = call ptr @llvm.experimental.gc.result.p0(token %statepoint_token25)
  %rs4gc.s3.relocated27 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token25, i32 0, i32 0) ; (%.2, %.2)
  %rs4gc.s2.relocated28 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token25, i32 1, i32 1) ; (%.2107, %.2107)
  %r3.0.base.relocated29 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token25, i32 2, i32 2) ; (%.1119, %.1119)
  %r3.0.relocated30 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token25, i32 2, i32 3) ; (%.1119, %.1125)
  %rs4gc.s5.relocated31 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token25, i32 4, i32 4) ; (%.0130, %.0130)
  br label %alloc.merge.23

alloc.merge.23:                                   ; preds = %alloc.slow.22, %alloc.fast.21
  %.2132 = phi ptr addrspace(1) [ %.0130, %alloc.fast.21 ], [ %rs4gc.s5.relocated31, %alloc.slow.22 ]
  %.3127 = phi ptr addrspace(1) [ %.1125, %alloc.fast.21 ], [ %r3.0.relocated30, %alloc.slow.22 ]
  %.3121 = phi ptr addrspace(1) [ %.1119, %alloc.fast.21 ], [ %r3.0.base.relocated29, %alloc.slow.22 ]
  %.4109 = phi ptr addrspace(1) [ %.2107, %alloc.fast.21 ], [ %rs4gc.s2.relocated28, %alloc.slow.22 ]
  %.4 = phi ptr addrspace(1) [ %.2, %alloc.fast.21 ], [ %rs4gc.s3.relocated27, %alloc.slow.22 ]
  %r77 = phi ptr [ %r75, %alloc.fast.21 ], [ %r7626, %alloc.slow.22 ]
  store <2 x i64> %r79, ptr %r77, align 8
  %r81 = getelementptr i8, ptr %r77, i64 16
  store i64 0, ptr %r81, align 8
  %r82 = getelementptr i8, ptr %r77, i64 24
  store i64 9222246136947933185, ptr %r82, align 8
  %r83 = getelementptr i8, ptr %r77, i64 32
  store i64 9222246136947933185, ptr %r83, align 8
  %r84 = getelementptr i8, ptr %r77, i64 8
  %r85 = ptrtoint ptr %r84 to i64
  %r86 = load atomic i32, ptr @PERRY_PER_OBJECT_LAYOUTS_ANY monotonic, align 4
  %r87 = icmp ne i32 %r86, 0
  br i1 %r87, label %layout_forget.young.24, label %layout_forget.done.27

layout_forget.young.24:                           ; preds = %alloc.merge.23
  %r88 = load atomic i32, ptr @PERRY_YOUNG_LAYOUT_RECORDS monotonic, align 4
  %r89 = icmp ne i32 %r88, 0
  br i1 %r89, label %layout_forget.sketch.25, label %layout_forget.done.27

layout_forget.sketch.25:                          ; preds = %layout_forget.young.24
  %r90 = mul i64 %r85, -7046029254386353131
  %r91 = lshr i64 %r90, 52
  %r92 = lshr i64 %r91, 6
  %r93 = and i64 %r91, 63
  %r94 = shl nuw i64 1, %r93
  %r95 = getelementptr i64, ptr @PERRY_LAYOUT_ADDR_FILTER, i64 %r92
  %r96 = load atomic i64, ptr %r95 monotonic, align 8
  %r97 = and i64 %r96, %r94
  %r98 = icmp ne i64 %r97, 0
  br i1 %r98, label %layout_forget.armed.26, label %layout_forget.done.27

layout_forget.armed.26:                           ; preds = %layout_forget.sketch.25
  call void @js_gc_forget_object_layout(i64 %r85) #7
  br label %layout_forget.done.27

layout_forget.done.27:                            ; preds = %layout_forget.armed.26, %layout_forget.sketch.25, %layout_forget.young.24, %alloc.merge.23
  %rs4gc.s6 = inttoptr i64 %r85 to ptr addrspace(1)
  %r100.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r100 = call i64 asm "", "=r,0"(i64 %r100.rs4i) #7
  %r101 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r102 = icmp ne i32 %r101, 0
  br i1 %r102, label %shadow.root.barrier.28, label %shadow.root.barrier.done.29

shadow.root.barrier.28:                           ; preds = %layout_forget.done.27
  call void @js_write_barrier_root_nanbox(i64 %r100) #7
  br label %shadow.root.barrier.done.29

shadow.root.barrier.done.29:                      ; preds = %shadow.root.barrier.28, %layout_forget.done.27
  %r103 = or i64 %r85, 9222527611924643840
  %r104 = bitcast i64 %r103 to double
  %r105.rs4i = ptrtoint ptr addrspace(1) %.2132 to i64
  %r105 = call i64 asm "", "=r,0"(i64 %r105.rs4i) #7
  %r106 = bitcast i64 %r105 to double
  %r107 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r108 = icmp eq i8 %r107, 0
  %r109 = bitcast double %r20 to i64
  %r110 = and i64 %r109, 9218868437227405312
  %r111 = icmp ne i64 %r110, 9218868437227405312
  %r112 = and i1 %r108, %r111
  br i1 %r112, label %ctor_prologue.fast.30, label %ctor_prologue.slow.31

ctor_prologue.fast.30:                            ; preds = %shadow.root.barrier.done.29
  %r113 = inttoptr i64 %r85 to ptr
  %r114 = getelementptr i8, ptr %r113, i64 16
  %r115 = bitcast double %r104 to i64
  %r116 = getelementptr double, ptr %r114, i64 0
  store double %r20, ptr %r116, align 8
  %r117 = ptrtoint ptr %r116 to i64
  %r118 = bitcast double %r20 to i64
  %r119 = getelementptr double, ptr %r114, i64 1
  store double %r106, ptr %r119, align 8
  %r120 = ptrtoint ptr %r119 to i64
  %r121 = bitcast double %r106 to i64
  %r122 = lshr i64 %r121, 48
  %r123 = icmp eq i64 %r122, 0
  %r124 = icmp uge i64 %r121, 4096
  %r125 = and i1 %r123, %r124
  %r126 = icmp eq i64 %r122, 32765
  %r127 = icmp eq i64 %r122, 32767
  %r128 = icmp eq i64 %r122, 32762
  %r129 = or i1 %r126, %r127
  %r130 = or i1 %r129, %r128
  %r131 = or i1 %r130, %r125
  br i1 %r131, label %ctor_prologue.barrier.maybe.33, label %ctor_prologue.barrier.done.35

ctor_prologue.slow.31:                            ; preds = %shadow.root.barrier.done.29
  %statepoint_token32 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, double)) @callback_only_ts____AnonShape_6ef7d34fbe1f1d2c_constructor, i32 3, i32 0, double %r104, double %r20, double %r106, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4, ptr addrspace(1) %.4109, ptr addrspace(1) %.3121, ptr addrspace(1) %.3127, ptr addrspace(1) %rs4gc.s6) ]
  %r14033 = call double @llvm.experimental.gc.result.f64(token %statepoint_token32)
  %rs4gc.s3.relocated34 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token32, i32 0, i32 0) ; (%.4, %.4)
  %rs4gc.s2.relocated35 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token32, i32 1, i32 1) ; (%.4109, %.4109)
  %r3.0.base.relocated36 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token32, i32 2, i32 2) ; (%.3121, %.3121)
  %r3.0.relocated37 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token32, i32 2, i32 3) ; (%.3121, %.3127)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token32, i32 4, i32 4) ; (%rs4gc.s6, %rs4gc.s6)
  br label %ctor_prologue.merge.32

ctor_prologue.merge.32:                           ; preds = %ctor_prologue.barrier.done.35, %ctor_prologue.slow.31
  %.0133 = phi ptr addrspace(1) [ %rs4gc.s6, %ctor_prologue.barrier.done.35 ], [ %rs4gc.s6.relocated, %ctor_prologue.slow.31 ]
  %.4128 = phi ptr addrspace(1) [ %.3127, %ctor_prologue.barrier.done.35 ], [ %r3.0.relocated37, %ctor_prologue.slow.31 ]
  %.4122 = phi ptr addrspace(1) [ %.3121, %ctor_prologue.barrier.done.35 ], [ %r3.0.base.relocated36, %ctor_prologue.slow.31 ]
  %.5110 = phi ptr addrspace(1) [ %.4109, %ctor_prologue.barrier.done.35 ], [ %rs4gc.s2.relocated35, %ctor_prologue.slow.31 ]
  %.5 = phi ptr addrspace(1) [ %.4, %ctor_prologue.barrier.done.35 ], [ %rs4gc.s3.relocated34, %ctor_prologue.slow.31 ]
  %r141 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.35 ], [ %r14033, %ctor_prologue.slow.31 ]
  %r142.rs4i = ptrtoint ptr addrspace(1) %.0133 to i64
  %r142 = call i64 asm "", "=r,0"(i64 %r142.rs4i) #7
  %r143 = or i64 %r142, 9222527611924643840
  %r144 = bitcast i64 %r143 to double
  %r145 = bitcast double %r141 to i64
  %r146 = icmp eq i64 %r145, 9222246136947933185
  br i1 %r146, label %ctor_ret.merge.37, label %ctor_ret.override.36

ctor_prologue.barrier.maybe.33:                   ; preds = %ctor_prologue.fast.30
  %r132 = sub i64 %r85, 7
  %r133 = inttoptr i64 %r132 to ptr
  %r134 = load i8, ptr %r133, align 1
  %r135 = and i8 %r134, 32
  %r136 = icmp ne i8 %r135, 0
  %r137 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r138 = icmp ne i32 %r137, 0
  %r139 = or i1 %r136, %r138
  br i1 %r139, label %ctor_prologue.barrier.34, label %ctor_prologue.barrier.done.35

ctor_prologue.barrier.34:                         ; preds = %ctor_prologue.barrier.maybe.33
  call void @js_write_barrier_slot_validated_parent(i64 %r85, i64 %r120, i64 %r121) #7
  br label %ctor_prologue.barrier.done.35

ctor_prologue.barrier.done.35:                    ; preds = %ctor_prologue.barrier.34, %ctor_prologue.barrier.maybe.33, %ctor_prologue.fast.30
  br label %ctor_prologue.merge.32

ctor_ret.override.36:                             ; preds = %ctor_prologue.merge.32
  %statepoint_token38 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r144, double %r141, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5, ptr addrspace(1) %.5110, ptr addrspace(1) %.4122, ptr addrspace(1) %.4128) ]
  %r14739 = call double @llvm.experimental.gc.result.f64(token %statepoint_token38)
  %rs4gc.s3.relocated40 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 0, i32 0) ; (%.5, %.5)
  %rs4gc.s2.relocated41 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 1, i32 1) ; (%.5110, %.5110)
  %r3.0.base.relocated42 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 2, i32 2) ; (%.4122, %.4122)
  %r3.0.relocated43 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token38, i32 2, i32 3) ; (%.4122, %.4128)
  br label %ctor_ret.merge.37

ctor_ret.merge.37:                                ; preds = %ctor_ret.override.36, %ctor_prologue.merge.32
  %.5129 = phi ptr addrspace(1) [ %.4128, %ctor_prologue.merge.32 ], [ %r3.0.relocated43, %ctor_ret.override.36 ]
  %.5123 = phi ptr addrspace(1) [ %.4122, %ctor_prologue.merge.32 ], [ %r3.0.base.relocated42, %ctor_ret.override.36 ]
  %.6111 = phi ptr addrspace(1) [ %.5110, %ctor_prologue.merge.32 ], [ %rs4gc.s2.relocated41, %ctor_ret.override.36 ]
  %.6 = phi ptr addrspace(1) [ %.5, %ctor_prologue.merge.32 ], [ %rs4gc.s3.relocated40, %ctor_ret.override.36 ]
  %r148 = phi double [ %r144, %ctor_prologue.merge.32 ], [ %r14739, %ctor_ret.override.36 ]
  %r149 = bitcast double %r148 to i64
  %r150.rs4i = ptrtoint ptr addrspace(1) %.5129 to i64
  %r150.rs4o = call i64 asm "", "=r,0"(i64 %r150.rs4i) #7
  %r150 = bitcast i64 %r150.rs4o to double
  %r151 = bitcast double %r150 to i64
  %r152 = and i64 %r151, 281474976710655
  %r153 = sub nsw i64 %r152, 8
  %r154 = inttoptr i64 %r153 to ptr
  %r155 = load i8, ptr %r154, align 1
  %r156 = icmp ne i8 %r155, 1
  %r157 = sub nsw i64 %r152, 7
  %r158 = inttoptr i64 %r157 to ptr
  %r159 = load i8, ptr %r158, align 1
  %r160 = and i8 %r159, -128
  %r161 = icmp ne i8 %r160, 0
  %r162 = or i1 %r156, %r161
  br i1 %r161, label %apush.fwd.38, label %apush.elements.39

apush.fwd.38:                                     ; preds = %apush.elements.check.40, %ctor_ret.merge.37
  %statepoint_token44 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r152, double %r148, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6, ptr addrspace(1) %.6111) ]
  %r18945 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token44)
  %rs4gc.s3.relocated46 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token44, i32 0, i32 0) ; (%.6, %.6)
  %rs4gc.s2.relocated47 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token44, i32 1, i32 1) ; (%.6111, %.6111)
  %r190 = or i64 %r18945, 9222527611924643840
  %r191 = bitcast i64 %r190 to double
  %rs4gc.b7 = bitcast double %r191 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  br label %apush.merge.44

apush.elements.39:                                ; preds = %ctor_ret.merge.37
  %r164 = add nuw nsw i64 %r152, 8
  %r165 = inttoptr i64 %r164 to ptr
  %r166 = load i64, ptr %r165, align 8
  %r167 = icmp ne i64 %r166, 0
  %r168 = icmp eq i8 %r155, 2
  %r169 = and i1 %r168, %r167
  %r170 = select i1 %r169, i64 %r166, i64 %r152
  %r171 = inttoptr i64 %r170 to ptr
  %r172 = getelementptr i64, ptr %r171, i64 12
  %r173 = load i64, ptr %r172, align 8
  %r174 = icmp ne i64 %r173, 0
  %r175 = and i1 %r169, %r174
  %r176 = select i1 %r175, i64 %r173, i64 %r152
  %r163 = icmp eq i8 %r155, 1
  br i1 %r163, label %apush.nofwd.41, label %apush.elements.check.40

apush.elements.check.40:                          ; preds = %apush.elements.39
  %r177 = icmp ne i64 %r176, 0
  %r178 = sub i64 %r176, 8
  %r179 = inttoptr i64 %r178 to ptr
  %r180 = load i8, ptr %r179, align 1
  %r181 = icmp eq i8 %r180, 1
  %r182 = sub i64 %r176, 7
  %r183 = inttoptr i64 %r182 to ptr
  %r184 = load i8, ptr %r183, align 1
  %r185 = and i8 %r184, -128
  %r186 = icmp eq i8 %r185, 0
  %r187 = and i1 %r177, %r181
  %r188 = and i1 %r187, %r186
  br i1 %r188, label %apush.nofwd.41, label %apush.fwd.38

apush.nofwd.41:                                   ; preds = %apush.elements.check.40, %apush.elements.39
  %r192 = phi i64 [ %r152, %apush.elements.39 ], [ %r176, %apush.elements.check.40 ]
  %r193 = sub i64 %r192, 6
  %r194 = inttoptr i64 %r193 to ptr
  %r195 = load i16, ptr %r194, align 2
  %r196 = and i16 %r195, -2937
  %r197 = icmp eq i16 %r196, -24576
  %r198 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r199 = icmp eq i8 %r198, 0
  %r200 = and i1 %r197, %r199
  %r201 = icmp ult i64 %r192, 4096
  %r202 = inttoptr i64 %r192 to ptr
  %r203 = select i1 %r201, ptr @perry_null_guard_zero_callback_only_ts, ptr %r202
  %r204 = load i32, ptr %r203, align 4
  %r205 = add i64 %r192, 4
  %r206 = inttoptr i64 %r205 to ptr
  %r207 = load i32, ptr %r206, align 4
  %r208 = icmp ult i32 %r204, %r207
  %r209 = and i1 %r208, %r200
  br i1 %r209, label %apush.inbounds.42, label %apush.realloc.43

apush.inbounds.42:                                ; preds = %apush.nofwd.41
  %r210 = icmp ult i64 %r192, 4096
  %r211 = inttoptr i64 %r192 to ptr
  %r212 = select i1 %r210, ptr @perry_null_guard_zero_callback_only_ts, ptr %r211
  %r213 = load i32, ptr %r212, align 4
  %r214 = zext i32 %r213 to i64
  %r215 = shl nuw nsw i64 %r214, 3
  %r216 = add nuw nsw i64 %r215, 8
  %r217 = add i64 %r192, %r216
  %r218 = inttoptr i64 %r217 to ptr
  store double %r148, ptr %r218, align 8
  call void @js_string_addref_if_heap_string(double %r148) #7
  %r219 = bitcast double %r148 to i64
  %r220 = sub i64 %r192, 7
  %r221 = inttoptr i64 %r220 to ptr
  %r222 = load i8, ptr %r221, align 1
  %r223 = and i8 %r222, 32
  %r224 = icmp ne i8 %r223, 0
  %r225 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r226 = icmp ne i32 %r225, 0
  %r227 = or i1 %r224, %r226
  br i1 %r227, label %apush.barrier.45, label %apush.barrier.done.46

apush.realloc.43:                                 ; preds = %apush.nofwd.41
  %statepoint_token48 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64_spec, i32 2, i32 0, i64 %r152, double %r148, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6, ptr addrspace(1) %.6111) ]
  %r23049 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token48)
  %rs4gc.s3.relocated50 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token48, i32 0, i32 0) ; (%.6, %.6)
  %rs4gc.s2.relocated51 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token48, i32 1, i32 1) ; (%.6111, %.6111)
  %r231 = or i64 %r23049, 9222527611924643840
  %r232 = bitcast i64 %r231 to double
  %rs4gc.b8 = bitcast double %r232 to i64
  %rs4gc.s8 = inttoptr i64 %rs4gc.b8 to ptr addrspace(1)
  br label %apush.merge.44

apush.merge.44:                                   ; preds = %apush.barrier.done.46, %apush.realloc.43, %apush.fwd.38
  %.7112 = phi ptr addrspace(1) [ %rs4gc.s2.relocated47, %apush.fwd.38 ], [ %.6111, %apush.barrier.done.46 ], [ %rs4gc.s2.relocated51, %apush.realloc.43 ]
  %.7 = phi ptr addrspace(1) [ %rs4gc.s3.relocated46, %apush.fwd.38 ], [ %.6, %apush.barrier.done.46 ], [ %rs4gc.s3.relocated50, %apush.realloc.43 ]
  %r3.1.base = phi ptr addrspace(1) [ %rs4gc.s7, %apush.fwd.38 ], [ %.5123, %apush.barrier.done.46 ], [ %rs4gc.s8, %apush.realloc.43 ], !is_base_value !0
  %r3.1 = phi ptr addrspace(1) [ %rs4gc.s7, %apush.fwd.38 ], [ %.5129, %apush.barrier.done.46 ], [ %rs4gc.s8, %apush.realloc.43 ]
  %r233 = load double, ptr @perry_global_callback_only_ts__0, align 8
  %r234 = bitcast double %r233 to i64
  %rs4gc.s9 = inttoptr i64 %r234 to ptr addrspace(1)
  %r235.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r235 = call i64 asm "", "=r,0"(i64 %r235.rs4i) #7
  %r236 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r237 = icmp ne i32 %r236, 0
  br i1 %r237, label %shadow.root.barrier.47, label %shadow.root.barrier.done.48

apush.barrier.45:                                 ; preds = %apush.inbounds.42
  call void @js_write_barrier_slot_validated_parent(i64 %r192, i64 %r217, i64 %r219) #7
  br label %apush.barrier.done.46

apush.barrier.done.46:                            ; preds = %apush.barrier.45, %apush.inbounds.42
  %r228 = add i32 %r213, 1
  %r229 = inttoptr i64 %r192 to ptr
  store i32 %r228, ptr %r229, align 4
  br label %apush.merge.44

shadow.root.barrier.47:                           ; preds = %apush.merge.44
  call void @js_write_barrier_root_nanbox(i64 %r235) #7
  br label %shadow.root.barrier.done.48

shadow.root.barrier.done.48:                      ; preds = %shadow.root.barrier.47, %apush.merge.44
  %r238.rs4i = ptrtoint ptr addrspace(1) %r3.1 to i64
  %r238.rs4o = call i64 asm "", "=r,0"(i64 %r238.rs4i) #7
  %r238 = bitcast i64 %r238.rs4o to double
  %r240 = bitcast double %r238 to i64
  %r241 = and i64 %r240, 281474976710655
  %r242 = lshr i64 %r240, 48
  %r243 = icmp eq i64 %r242, 32765
  %r244 = icmp ugt i64 %r241, 1048575
  %r245 = and i1 %r243, %r244
  br i1 %r245, label %arr.guard.deref.53, label %arr.fallback.50

arr.fast.49:                                      ; preds = %arr.guard.range.55
  %r301 = zext i32 %r12.0 to i64
  %r302 = shl nuw nsw i64 %r301, 3
  %r303 = add nuw nsw i64 %r302, 8
  %r304 = add i64 %r260, %r303
  %r305 = inttoptr i64 %r304 to ptr
  %r306 = load double, ptr %r305, align 8
  %r307 = bitcast double %r306 to i64
  %r308 = icmp eq i64 %r307, 9222246136947933200
  %r310 = select i1 %r308, double 0x7FFC000000000001, double %r306
  br label %arr.merge.52

arr.fallback.50:                                  ; preds = %arr.guard.live.54, %arr.guard.deref.53, %shadow.root.barrier.done.48
  %r299 = sitofp i32 %r12.0 to double
  %statepoint_token52 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 4883850429458284545, double %r238, double %r299, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s9, ptr addrspace(1) %r3.1.base, ptr addrspace(1) %.7, ptr addrspace(1) %.7112, ptr addrspace(1) %r3.1) ]
  %r30053 = call double @llvm.experimental.gc.result.f64(token %statepoint_token52)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token52, i32 0, i32 0) ; (%rs4gc.s9, %rs4gc.s9)
  %r3.1.base.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token52, i32 1, i32 1) ; (%r3.1.base, %r3.1.base)
  %rs4gc.s3.relocated54 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token52, i32 2, i32 2) ; (%.7, %.7)
  %rs4gc.s2.relocated55 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token52, i32 3, i32 3) ; (%.7112, %.7112)
  %r3.1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token52, i32 1, i32 4) ; (%r3.1.base, %r3.1)
  br label %arr.merge.52

arr.guard.oob.51:                                 ; preds = %arr.guard.range.55
  br label %arr.merge.52

arr.merge.52:                                     ; preds = %arr.guard.oob.51, %arr.fallback.50, %arr.fast.49
  %.0142 = phi ptr addrspace(1) [ %r3.1, %arr.fast.49 ], [ %r3.1, %arr.guard.oob.51 ], [ %r3.1.relocated, %arr.fallback.50 ]
  %.0137 = phi ptr addrspace(1) [ %r3.1.base, %arr.fast.49 ], [ %r3.1.base, %arr.guard.oob.51 ], [ %r3.1.base.relocated, %arr.fallback.50 ]
  %.0134 = phi ptr addrspace(1) [ %rs4gc.s9, %arr.fast.49 ], [ %rs4gc.s9, %arr.guard.oob.51 ], [ %rs4gc.s9.relocated, %arr.fallback.50 ]
  %.8113 = phi ptr addrspace(1) [ %.7112, %arr.fast.49 ], [ %.7112, %arr.guard.oob.51 ], [ %rs4gc.s2.relocated55, %arr.fallback.50 ]
  %.8 = phi ptr addrspace(1) [ %.7, %arr.fast.49 ], [ %.7, %arr.guard.oob.51 ], [ %rs4gc.s3.relocated54, %arr.fallback.50 ]
  %r311 = phi double [ %r310, %arr.fast.49 ], [ %r30053, %arr.fallback.50 ], [ 0x7FFC000000000001, %arr.guard.oob.51 ]
  %r312 = bitcast double %r311 to i64
  %r313 = and i64 %r312, 281474976710655
  %r314 = lshr i64 %r312, 48
  %r315 = and i64 %r314, 65533
  %r316 = icmp eq i64 %r315, 32765
  br i1 %r316, label %pget.recv_ok.57, label %pget.recv_other.61

arr.guard.deref.53:                               ; preds = %shadow.root.barrier.done.48
  %r246 = bitcast double %r238 to i64
  %r247 = and i64 %r246, 281474976710655
  %r248 = sub nsw i64 %r247, 8
  %r249 = inttoptr i64 %r248 to ptr
  %r250 = load i8, ptr %r249, align 1
  %r251 = icmp eq i8 %r250, 1
  %r252 = sub nsw i64 %r247, 7
  %r253 = inttoptr i64 %r252 to ptr
  %r254 = load i8, ptr %r253, align 1
  %r255 = and i8 %r254, -128
  %r256 = icmp ne i8 %r255, 0
  %r257 = inttoptr i64 %r247 to ptr
  %r258 = load i64, ptr %r257, align 8
  %r259 = and i1 %r251, %r256
  %r260 = select i1 %r259, i64 %r258, i64 %r247
  %r261 = lshr i64 %r260, 48
  %r262 = icmp eq i64 %r261, 0
  %r263 = icmp ugt i64 %r260, 1048575
  %r264 = and i1 %r262, %r263
  br i1 %r264, label %arr.guard.live.54, label %arr.fallback.50

arr.guard.live.54:                                ; preds = %arr.guard.deref.53
  %r265 = sub nuw i64 %r260, 8
  %r266 = inttoptr i64 %r265 to ptr
  %r267 = load i8, ptr %r266, align 1
  %r268 = icmp eq i8 %r267, 1
  %r269 = sub nuw i64 %r260, 7
  %r270 = inttoptr i64 %r269 to ptr
  %r271 = load i8, ptr %r270, align 1
  %r272 = and i8 %r271, -128
  %r273 = icmp eq i8 %r272, 0
  %r274 = sub nuw i64 %r260, 6
  %r275 = inttoptr i64 %r274 to ptr
  %r276 = load i16, ptr %r275, align 2
  %r277 = and i16 %r276, 1024
  %r278 = icmp eq i16 %r277, 0
  %r279 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r280 = icmp eq i8 %r279, 0
  %r281 = inttoptr i64 %r260 to ptr
  %r282 = load i32, ptr %r281, align 4
  %r283 = getelementptr i8, ptr %r281, i64 4
  %r284 = load i32, ptr %r283, align 4
  %r285 = icmp slt i32 %r12.0, 0
  %r286 = icmp eq i1 %r285, false
  %r288 = icmp ule i32 %r282, 16000000
  %r289 = icmp ule i32 %r284, 16000000
  %r290 = icmp ule i32 %r282, %r284
  %r291 = and i1 %r268, %r273
  %r292 = and i1 %r291, %r278
  %r293 = and i1 %r292, %r280
  %r294 = and i1 %r293, %r286
  %r295 = and i1 %r294, %r288
  %r296 = and i1 %r295, %r289
  %r297 = and i1 %r296, %r290
  br i1 %r297, label %arr.guard.range.55, label %arr.fallback.50

arr.guard.range.55:                               ; preds = %arr.guard.live.54
  %r287 = icmp ult i32 %r12.0, %r282
  br i1 %r287, label %arr.fast.49, label %arr.guard.oob.51

pget.recv_sso.56:                                 ; preds = %pget.recv_other.61
  %r454 = load double, ptr @callback_only_ts_.str.1.handle, align 8
  %r455 = bitcast double %r454 to i64
  %r456 = and i64 %r455, 281474976710655
  %statepoint_token56 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r312, i64 %r456, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0137, ptr addrspace(1) %.8, ptr addrspace(1) %.8113, ptr addrspace(1) %.0134, ptr addrspace(1) %.0142) ]
  %r45757 = call double @llvm.experimental.gc.result.f64(token %statepoint_token56)
  %r3.1.base.relocated58 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token56, i32 0, i32 0) ; (%.0137, %.0137)
  %rs4gc.s3.relocated59 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token56, i32 1, i32 1) ; (%.8, %.8)
  %rs4gc.s2.relocated60 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token56, i32 2, i32 2) ; (%.8113, %.8113)
  %rs4gc.s9.relocated61 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token56, i32 3, i32 3) ; (%.0134, %.0134)
  %r3.1.relocated62 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token56, i32 0, i32 4) ; (%.0137, %.0142)
  br label %pget.recv_merge.60

pget.recv_ok.57:                                  ; preds = %arr.merge.52
  %r323 = icmp ugt i64 %r313, 1048575
  br i1 %r323, label %pic.recv_hdr.78, label %pic.miss.cold.75

pget.recv_bad.58:                                 ; preds = %pget.check_class_ref.62
  %r446 = icmp eq i64 %r312, 9222246136947933185
  %r447 = icmp eq i64 %r312, 9222246136947933186
  %r448 = or i1 %r446, %r447
  br i1 %r448, label %pget.throw_nullish.85, label %pget.recv_undef_return.86

pget.recv_class_ref.59:                           ; preds = %pget.check_class_ref.62
  %r319 = load double, ptr @callback_only_ts_.str.1.handle, align 8
  %r320 = bitcast double %r319 to i64
  %r321 = and i64 %r320, 281474976710655
  %statepoint_token63 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 4883850429458284546, i64 %r312, i64 %r321, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0137, ptr addrspace(1) %.8, ptr addrspace(1) %.8113, ptr addrspace(1) %.0134, ptr addrspace(1) %.0142) ]
  %r32264 = call double @llvm.experimental.gc.result.f64(token %statepoint_token63)
  %r3.1.base.relocated65 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 0, i32 0) ; (%.0137, %.0137)
  %rs4gc.s3.relocated66 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 1, i32 1) ; (%.8, %.8)
  %rs4gc.s2.relocated67 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 2, i32 2) ; (%.8113, %.8113)
  %rs4gc.s9.relocated68 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 3, i32 3) ; (%.0134, %.0134)
  %r3.1.relocated69 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 0, i32 4) ; (%.0137, %.0142)
  br label %pget.recv_merge.60

pget.recv_merge.60:                               ; preds = %pget.recv_undef_return.86, %pic.merge.77, %pget.recv_class_ref.59, %pget.recv_sso.56
  %.1143 = phi ptr addrspace(1) [ %.2144, %pic.merge.77 ], [ %r3.1.relocated62, %pget.recv_sso.56 ], [ %r3.1.relocated69, %pget.recv_class_ref.59 ], [ %r3.1.relocated91, %pget.recv_undef_return.86 ]
  %.1138 = phi ptr addrspace(1) [ %.2139, %pic.merge.77 ], [ %r3.1.base.relocated58, %pget.recv_sso.56 ], [ %r3.1.base.relocated65, %pget.recv_class_ref.59 ], [ %r3.1.base.relocated87, %pget.recv_undef_return.86 ]
  %.1135 = phi ptr addrspace(1) [ %.2136, %pic.merge.77 ], [ %rs4gc.s9.relocated61, %pget.recv_sso.56 ], [ %rs4gc.s9.relocated68, %pget.recv_class_ref.59 ], [ %rs4gc.s9.relocated90, %pget.recv_undef_return.86 ]
  %.9114 = phi ptr addrspace(1) [ %.10115, %pic.merge.77 ], [ %rs4gc.s2.relocated60, %pget.recv_sso.56 ], [ %rs4gc.s2.relocated67, %pget.recv_class_ref.59 ], [ %rs4gc.s2.relocated89, %pget.recv_undef_return.86 ]
  %.9 = phi ptr addrspace(1) [ %.10, %pic.merge.77 ], [ %rs4gc.s3.relocated59, %pget.recv_sso.56 ], [ %rs4gc.s3.relocated66, %pget.recv_class_ref.59 ], [ %rs4gc.s3.relocated88, %pget.recv_undef_return.86 ]
  %r458 = phi double [ %r445, %pic.merge.77 ], [ %r45386, %pget.recv_undef_return.86 ], [ %r45757, %pget.recv_sso.56 ], [ %r32264, %pget.recv_class_ref.59 ]
  %r459.rs4i = ptrtoint ptr addrspace(1) %.1135 to i64
  %r459 = call i64 asm "", "=r,0"(i64 %r459.rs4i) #7
  %r460 = bitcast i64 %r459 to double
  %r461 = and i64 %r459, -281474976710656
  %r462 = icmp ult i64 %r461, 9221401712017801216
  %r463 = icmp ugt i64 %r461, 9223090561878065152
  %r464 = or i1 %r462, %r463
  %r465 = bitcast double %r458 to i64
  %r466 = and i64 %r465, -281474976710656
  %r467 = icmp ult i64 %r466, 9221401712017801216
  %r468 = icmp ugt i64 %r466, 9223090561878065152
  %r469 = or i1 %r467, %r468
  %r470 = and i1 %r464, %r469
  br i1 %r470, label %guarded_add.numeric.87, label %guarded_add.dynamic.88

pget.recv_other.61:                               ; preds = %arr.merge.52
  %r317 = icmp eq i64 %r314, 32761
  br i1 %r317, label %pget.recv_sso.56, label %pget.check_class_ref.62

pget.check_class_ref.62:                          ; preds = %pget.recv_other.61
  %r318 = icmp eq i64 %r314, 32766
  br i1 %r318, label %pget.recv_class_ref.59, label %pget.recv_bad.58

pic.hit.63:                                       ; preds = %pic.token.79
  %r348 = getelementptr i64, ptr %r333, i64 1
  %r349 = load i64, ptr %r348, align 8
  %r350 = and i64 %r349, 1073741824
  %r351 = icmp ne i64 %r350, 0
  br i1 %r351, label %pic.hit.overflow.80, label %pic.hit.inline.81

pic.hit.live.64:                                  ; preds = %pic.hit.inline.81
  br label %pic.merge.77

pic.prefix.guard.65:                              ; preds = %pic.token.79
  %r364 = getelementptr i64, ptr %r333, i64 2
  %r365 = load i64, ptr %r364, align 8
  %r366 = icmp ne i64 %r365, 0
  br i1 %r366, label %pic.prefix.meta.66, label %pic.miss.74

pic.prefix.meta.66:                               ; preds = %pic.prefix.guard.65
  %r367 = add nuw nsw i64 %r313, 8
  %r368 = inttoptr i64 %r367 to ptr
  %r369 = load i64, ptr %r368, align 8
  %r370 = icmp ne i64 %r369, 0
  br i1 %r370, label %pic.prefix.token.67, label %pic.miss.74

pic.prefix.token.67:                              ; preds = %pic.prefix.meta.66
  %r371 = inttoptr i64 %r369 to ptr
  %r372 = getelementptr i64, ptr %r371, i64 6
  %r373 = load i64, ptr %r372, align 8
  %r374 = icmp eq i64 %r373, %r365
  br i1 %r374, label %pic.prefix.hit.68, label %pic.miss.74

pic.prefix.hit.68:                                ; preds = %pic.prefix.token.67
  %r375 = getelementptr i64, ptr %r333, i64 1
  %r376 = load i64, ptr %r375, align 8
  %r377 = shl i64 %r376, 3
  %r378 = add nuw nsw i64 %r313, 16
  %r379 = add i64 %r378, %r377
  %r380 = inttoptr i64 %r379 to ptr
  %r381 = load double, ptr %r380, align 8
  br label %pic.merge.77

pic.desc.classify.69:                             ; preds = %pic.recv_hdr.78
  %r337 = and i1 %r327, %r334
  br i1 %r337, label %pic.desc.prefix.guard.70, label %pic.miss.cold.75

pic.desc.prefix.guard.70:                         ; preds = %pic.desc.classify.69
  %r382 = getelementptr i64, ptr %r333, i64 2
  %r383 = load i64, ptr %r382, align 8
  %r384 = icmp ne i64 %r383, 0
  br i1 %r384, label %pic.desc.prefix.meta.71, label %pic.miss.cold.75

pic.desc.prefix.meta.71:                          ; preds = %pic.desc.prefix.guard.70
  %r385 = add nuw nsw i64 %r313, 8
  %r386 = inttoptr i64 %r385 to ptr
  %r387 = load i64, ptr %r386, align 8
  %r388 = icmp ne i64 %r387, 0
  br i1 %r388, label %pic.desc.prefix.token.72, label %pic.miss.cold.75

pic.desc.prefix.token.72:                         ; preds = %pic.desc.prefix.meta.71
  %r389 = inttoptr i64 %r387 to ptr
  %r390 = getelementptr i64, ptr %r389, i64 6
  %r391 = load i64, ptr %r390, align 8
  %r392 = icmp eq i64 %r391, %r383
  br i1 %r392, label %pic.desc.prefix.hit.73, label %pic.miss.cold.75

pic.desc.prefix.hit.73:                           ; preds = %pic.desc.prefix.token.72
  %r393 = getelementptr i64, ptr %r333, i64 1
  %r394 = load i64, ptr %r393, align 8
  %r395 = shl i64 %r394, 3
  %r396 = add nuw nsw i64 %r313, 16
  %r397 = add i64 %r396, %r395
  %r398 = inttoptr i64 %r397 to ptr
  %r399 = load double, ptr %r398, align 8
  br label %pic.merge.77

pic.miss.74:                                      ; preds = %pic.hit.inline.81, %pic.prefix.token.67, %pic.prefix.meta.66, %pic.prefix.guard.65
  %r400 = getelementptr i64, ptr %r333, i64 3
  %r401 = load i64, ptr %r400, align 8
  %r402 = icmp sgt i64 %r401, 0
  br i1 %r402, label %pic.ways.82, label %pic.miss.call.76

pic.miss.cold.75:                                 ; preds = %pic.desc.prefix.token.72, %pic.desc.prefix.meta.71, %pic.desc.prefix.guard.70, %pic.desc.classify.69, %pget.recv_ok.57
  br label %pic.miss.call.76

pic.miss.call.76:                                 ; preds = %pic.way.load.83, %pic.ways.82, %pic.miss.cold.75, %pic.miss.74
  %r441 = load double, ptr @callback_only_ts_.str.1.handle, align 8
  %r442 = bitcast double %r441 to i64
  %r443 = and i64 %r442, 281474976710655
  %statepoint_token70 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r313, i64 %r443, ptr @perry_ic_callback_only_ts__3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0137, ptr addrspace(1) %.8, ptr addrspace(1) %.8113, ptr addrspace(1) %.0134, ptr addrspace(1) %.0142) ]
  %r44471 = call double @llvm.experimental.gc.result.f64(token %statepoint_token70)
  %r3.1.base.relocated72 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token70, i32 0, i32 0) ; (%.0137, %.0137)
  %rs4gc.s3.relocated73 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token70, i32 1, i32 1) ; (%.8, %.8)
  %rs4gc.s2.relocated74 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token70, i32 2, i32 2) ; (%.8113, %.8113)
  %rs4gc.s9.relocated75 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token70, i32 3, i32 3) ; (%.0134, %.0134)
  %r3.1.relocated76 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token70, i32 0, i32 4) ; (%.0137, %.0142)
  br label %pic.merge.77

pic.merge.77:                                     ; preds = %pic.way.live.84, %pic.hit.overflow.80, %pic.miss.call.76, %pic.desc.prefix.hit.73, %pic.prefix.hit.68, %pic.hit.live.64
  %.2144 = phi ptr addrspace(1) [ %r3.1.relocated83, %pic.hit.overflow.80 ], [ %r3.1.relocated76, %pic.miss.call.76 ], [ %.0142, %pic.way.live.84 ], [ %.0142, %pic.hit.live.64 ], [ %.0142, %pic.prefix.hit.68 ], [ %.0142, %pic.desc.prefix.hit.73 ]
  %.2139 = phi ptr addrspace(1) [ %r3.1.base.relocated79, %pic.hit.overflow.80 ], [ %r3.1.base.relocated72, %pic.miss.call.76 ], [ %.0137, %pic.way.live.84 ], [ %.0137, %pic.hit.live.64 ], [ %.0137, %pic.prefix.hit.68 ], [ %.0137, %pic.desc.prefix.hit.73 ]
  %.2136 = phi ptr addrspace(1) [ %rs4gc.s9.relocated82, %pic.hit.overflow.80 ], [ %rs4gc.s9.relocated75, %pic.miss.call.76 ], [ %.0134, %pic.way.live.84 ], [ %.0134, %pic.hit.live.64 ], [ %.0134, %pic.prefix.hit.68 ], [ %.0134, %pic.desc.prefix.hit.73 ]
  %.10115 = phi ptr addrspace(1) [ %rs4gc.s2.relocated81, %pic.hit.overflow.80 ], [ %rs4gc.s2.relocated74, %pic.miss.call.76 ], [ %.8113, %pic.way.live.84 ], [ %.8113, %pic.hit.live.64 ], [ %.8113, %pic.prefix.hit.68 ], [ %.8113, %pic.desc.prefix.hit.73 ]
  %.10 = phi ptr addrspace(1) [ %rs4gc.s3.relocated80, %pic.hit.overflow.80 ], [ %rs4gc.s3.relocated73, %pic.miss.call.76 ], [ %.8, %pic.way.live.84 ], [ %.8, %pic.hit.live.64 ], [ %.8, %pic.prefix.hit.68 ], [ %.8, %pic.desc.prefix.hit.73 ]
  %r445 = phi double [ %r361, %pic.hit.live.64 ], [ %r35678, %pic.hit.overflow.80 ], [ %r381, %pic.prefix.hit.68 ], [ %r399, %pic.desc.prefix.hit.73 ], [ %r438, %pic.way.live.84 ], [ %r44471, %pic.miss.call.76 ]
  br label %pget.recv_merge.60

pic.recv_hdr.78:                                  ; preds = %pget.recv_ok.57
  %r324 = sub nuw nsw i64 %r313, 8
  %r325 = inttoptr i64 %r324 to ptr
  %r326 = load i8, ptr %r325, align 1
  %r327 = icmp eq i8 %r326, 2
  %r328 = sub nuw nsw i64 %r313, 6
  %r329 = inttoptr i64 %r328 to ptr
  %r330 = load i16, ptr %r329, align 2
  %r331 = and i16 %r330, 2048
  %r332 = icmp eq i16 %r331, 0
  %r333 = load ptr, ptr @perry_ic_callback_only_ts__3, align 8
  %r334 = icmp ne ptr %r333, null
  %r335 = and i1 %r327, %r332
  %r336 = and i1 %r335, %r334
  br i1 %r336, label %pic.token.79, label %pic.desc.classify.69

pic.token.79:                                     ; preds = %pic.recv_hdr.78
  %r338 = add nuw nsw i64 %r313, 4
  %r339 = inttoptr i64 %r338 to ptr
  %r340 = load i32, ptr %r339, align 4
  %r341 = zext i32 %r340 to i64
  %r342 = or i64 %r341, 4611686018427387904
  %r343 = icmp ne i32 %r340, 0
  %r344 = getelementptr i64, ptr %r333, i64 0
  %r345 = load i64, ptr %r344, align 8
  %r346 = icmp eq i64 %r342, %r345
  %r347 = and i1 %r346, %r343
  br i1 %r347, label %pic.hit.63, label %pic.prefix.guard.65

pic.hit.overflow.80:                              ; preds = %pic.hit.63
  %r352 = load double, ptr @callback_only_ts_.str.1.handle, align 8
  %r353 = bitcast double %r352 to i64
  %r354 = and i64 %r353, 281474976710655
  %r355 = trunc i64 %r349 to i32
  %statepoint_token77 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r313, i64 %r354, i32 %r355, ptr @perry_ic_callback_only_ts__3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0137, ptr addrspace(1) %.8, ptr addrspace(1) %.8113, ptr addrspace(1) %.0134, ptr addrspace(1) %.0142) ]
  %r35678 = call double @llvm.experimental.gc.result.f64(token %statepoint_token77)
  %r3.1.base.relocated79 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token77, i32 0, i32 0) ; (%.0137, %.0137)
  %rs4gc.s3.relocated80 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token77, i32 1, i32 1) ; (%.8, %.8)
  %rs4gc.s2.relocated81 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token77, i32 2, i32 2) ; (%.8113, %.8113)
  %rs4gc.s9.relocated82 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token77, i32 3, i32 3) ; (%.0134, %.0134)
  %r3.1.relocated83 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token77, i32 0, i32 4) ; (%.0137, %.0142)
  br label %pic.merge.77

pic.hit.inline.81:                                ; preds = %pic.hit.63
  %r357 = shl i64 %r349, 3
  %r358 = add nuw nsw i64 %r313, 16
  %r359 = add i64 %r358, %r357
  %r360 = inttoptr i64 %r359 to ptr
  %r361 = load double, ptr %r360, align 8
  %r362 = bitcast double %r361 to i64
  %r363 = icmp eq i64 %r362, 9222246136947933200
  br i1 %r363, label %pic.miss.74, label %pic.hit.live.64

pic.ways.82:                                      ; preds = %pic.miss.74
  %r403 = getelementptr i64, ptr %r333, i64 4
  %r404 = load i64, ptr %r403, align 8
  %r405 = icmp eq i64 %r404, %r342
  %r406 = getelementptr i64, ptr %r333, i64 5
  %r407 = load i64, ptr %r406, align 8
  %r408 = select i1 %r405, i64 %r407, i64 0
  %r409 = getelementptr i64, ptr %r333, i64 6
  %r410 = load i64, ptr %r409, align 8
  %r411 = icmp eq i64 %r410, %r342
  %r412 = getelementptr i64, ptr %r333, i64 7
  %r413 = load i64, ptr %r412, align 8
  %r414 = select i1 %r411, i64 %r413, i64 0
  %r415 = getelementptr i64, ptr %r333, i64 8
  %r416 = load i64, ptr %r415, align 8
  %r417 = icmp eq i64 %r416, %r342
  %r418 = getelementptr i64, ptr %r333, i64 9
  %r419 = load i64, ptr %r418, align 8
  %r420 = select i1 %r417, i64 %r419, i64 0
  %r421 = getelementptr i64, ptr %r333, i64 10
  %r422 = load i64, ptr %r421, align 8
  %r423 = icmp eq i64 %r422, %r342
  %r424 = getelementptr i64, ptr %r333, i64 11
  %r425 = load i64, ptr %r424, align 8
  %r426 = select i1 %r423, i64 %r425, i64 0
  %r427 = or i1 %r405, %r411
  %r428 = select i1 %r405, i64 %r408, i64 %r414
  %r429 = or i1 %r417, %r423
  %r430 = select i1 %r417, i64 %r420, i64 %r426
  %r431 = or i1 %r427, %r429
  %r432 = select i1 %r427, i64 %r428, i64 %r430
  %r433 = and i1 %r343, %r431
  br i1 %r433, label %pic.way.load.83, label %pic.miss.call.76

pic.way.load.83:                                  ; preds = %pic.ways.82
  %r434 = shl i64 %r432, 3
  %r435 = add nuw nsw i64 %r313, 16
  %r436 = add i64 %r435, %r434
  %r437 = inttoptr i64 %r436 to ptr
  %r438 = load double, ptr %r437, align 8
  %r439 = bitcast double %r438 to i64
  %r440 = icmp eq i64 %r439, 9222246136947933200
  br i1 %r440, label %pic.miss.call.76, label %pic.way.live.84

pic.way.live.84:                                  ; preds = %pic.way.load.83
  br label %pic.merge.77

pget.throw_nullish.85:                            ; preds = %pget.recv_bad.58
  %r449 = zext i1 %r447 to i32
  %statepoint_token84 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r449, ptr @callback_only_ts_.str.1.bytes, i64 2, i32 0, i32 0)
  unreachable

pget.recv_undef_return.86:                        ; preds = %pget.recv_bad.58
  %r450 = load double, ptr @callback_only_ts_.str.1.handle, align 8
  %r451 = bitcast double %r450 to i64
  %r452 = and i64 %r451, 281474976710655
  %statepoint_token85 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r312, i64 %r452, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0137, ptr addrspace(1) %.8, ptr addrspace(1) %.8113, ptr addrspace(1) %.0134, ptr addrspace(1) %.0142) ]
  %r45386 = call double @llvm.experimental.gc.result.f64(token %statepoint_token85)
  %r3.1.base.relocated87 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 0, i32 0) ; (%.0137, %.0137)
  %rs4gc.s3.relocated88 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 1, i32 1) ; (%.8, %.8)
  %rs4gc.s2.relocated89 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 2, i32 2) ; (%.8113, %.8113)
  %rs4gc.s9.relocated90 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 3, i32 3) ; (%.0134, %.0134)
  %r3.1.relocated91 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 0, i32 4) ; (%.0137, %.0142)
  br label %pget.recv_merge.60

guarded_add.numeric.87:                           ; preds = %pget.recv_merge.60
  %r471 = fadd double %r460, %r458
  br label %guarded_add.merge.89

guarded_add.dynamic.88:                           ; preds = %pget.recv_merge.60
  %statepoint_token92 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r460, double %r458, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1138, ptr addrspace(1) %.9, ptr addrspace(1) %.9114, ptr addrspace(1) %.1143) ]
  %r47293 = call double @llvm.experimental.gc.result.f64(token %statepoint_token92)
  %r3.1.base.relocated94 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token92, i32 0, i32 0) ; (%.1138, %.1138)
  %rs4gc.s3.relocated95 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token92, i32 1, i32 1) ; (%.9, %.9)
  %rs4gc.s2.relocated96 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token92, i32 2, i32 2) ; (%.9114, %.9114)
  %r3.1.relocated97 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token92, i32 0, i32 3) ; (%.1138, %.1143)
  br label %guarded_add.merge.89

guarded_add.merge.89:                             ; preds = %guarded_add.dynamic.88, %guarded_add.numeric.87
  %.3145 = phi ptr addrspace(1) [ %.1143, %guarded_add.numeric.87 ], [ %r3.1.relocated97, %guarded_add.dynamic.88 ]
  %.3140 = phi ptr addrspace(1) [ %.1138, %guarded_add.numeric.87 ], [ %r3.1.base.relocated94, %guarded_add.dynamic.88 ]
  %.11116 = phi ptr addrspace(1) [ %.9114, %guarded_add.numeric.87 ], [ %rs4gc.s2.relocated96, %guarded_add.dynamic.88 ]
  %.11 = phi ptr addrspace(1) [ %.9, %guarded_add.numeric.87 ], [ %rs4gc.s3.relocated95, %guarded_add.dynamic.88 ]
  %r473 = phi double [ %r471, %guarded_add.numeric.87 ], [ %r47293, %guarded_add.dynamic.88 ]
  store double %r473, ptr @perry_global_callback_only_ts__0, align 8
  %r474 = bitcast double %r473 to i64
  call void @js_write_barrier_root_nanbox(i64 %r474) #7
  %r475 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r476 = icmp ne i32 %r475, 0
  br i1 %r476, label %gcpoll.90, label %gcpoll.done.91

gcpoll.90:                                        ; preds = %guarded_add.merge.89
  %statepoint_token98 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3140, ptr addrspace(1) %.3145, ptr addrspace(1) %.11, ptr addrspace(1) %.11116) ]
  %r3.1.base.relocated99 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token98, i32 0, i32 0) ; (%.3140, %.3140)
  %r3.1.relocated100 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token98, i32 0, i32 1) ; (%.3140, %.3145)
  %rs4gc.s3.relocated101 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token98, i32 2, i32 2) ; (%.11, %.11)
  %rs4gc.s2.relocated102 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token98, i32 3, i32 3) ; (%.11116, %.11116)
  br label %gcpoll.done.91

gcpoll.done.91:                                   ; preds = %gcpoll.90, %guarded_add.merge.89
  %.4146 = phi ptr addrspace(1) [ %r3.1.relocated100, %gcpoll.90 ], [ %.3145, %guarded_add.merge.89 ]
  %.4141 = phi ptr addrspace(1) [ %r3.1.base.relocated99, %gcpoll.90 ], [ %.3140, %guarded_add.merge.89 ]
  %.12117 = phi ptr addrspace(1) [ %rs4gc.s2.relocated102, %gcpoll.90 ], [ %.11116, %guarded_add.merge.89 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s3.relocated101, %gcpoll.90 ], [ %.11, %guarded_add.merge.89 ]
  br label %for.update.5

streqlit.sso.92:                                  ; preds = %for.exit.6
  %r486 = icmp eq i64 %r483, 9221403911041082473
  br i1 %r486, label %streqlit.true.97, label %streqlit.tag.93

streqlit.tag.93:                                  ; preds = %streqlit.sso.92
  %r487 = lshr i64 %r483, 48
  %r488 = icmp eq i64 %r487, 32767
  %r489 = and i64 %r483, 281474976710655
  %r490 = icmp ugt i64 %r489, 4095
  %r491 = and i1 %r488, %r490
  br i1 %r491, label %streqlit.len.94, label %streqlit.false.98

streqlit.len.94:                                  ; preds = %streqlit.tag.93
  %r492 = inttoptr i64 %r489 to ptr
  %r493 = getelementptr inbounds nuw i8, ptr %r492, i64 4
  %r494 = load i32, ptr %r493, align 4
  %r495 = icmp eq i32 %r494, 2
  br i1 %r495, label %streqlit.b0.95, label %streqlit.false.98

streqlit.b0.95:                                   ; preds = %streqlit.len.94
  %r496 = getelementptr inbounds nuw i8, ptr %r492, i64 20
  %r497 = load i8, ptr %r496, align 1
  %r498 = icmp eq i8 %r497, 105
  br i1 %r498, label %streqlit.bl.96, label %streqlit.false.98

streqlit.bl.96:                                   ; preds = %streqlit.b0.95
  %r499 = getelementptr inbounds nuw i8, ptr %r492, i64 21
  %r500 = load i8, ptr %r499, align 1
  %r501 = icmp eq i8 %r500, 100
  br i1 %r501, label %streqlit.true.97, label %streqlit.false.98

streqlit.true.97:                                 ; preds = %streqlit.bl.96, %streqlit.sso.92, %for.exit.6
  br label %streqlit.merge.99

streqlit.false.98:                                ; preds = %streqlit.bl.96, %streqlit.b0.95, %streqlit.len.94, %streqlit.tag.93
  br label %streqlit.merge.99

streqlit.merge.99:                                ; preds = %streqlit.false.98, %streqlit.true.97
  %r502 = phi i1 [ true, %streqlit.true.97 ], [ false, %streqlit.false.98 ]
  %r503 = select i1 %r502, i64 9222246136947933188, i64 9222246136947933187
  %r504 = bitcast i64 %r503 to double
  %r505 = icmp eq i64 %r503, 9222246136947933188
  br i1 %r505, label %if.then.100, label %if.else.101

if.then.100:                                      ; preds = %streqlit.merge.99
  %r506.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r506.rs4o = call i64 asm "", "=r,0"(i64 %r506.rs4i) #7
  %r506 = bitcast i64 %r506.rs4o to double
  %r507 = bitcast double %r506 to i64
  %r508 = and i64 %r507, -281474976710656
  %r509 = icmp ult i64 %r508, 9221401712017801216
  %r510 = icmp ugt i64 %r508, 9223090561878065152
  %r511 = or i1 %r509, %r510
  br i1 %r511, label %guarded_add.numeric.103, label %guarded_add.dynamic.104

if.else.101:                                      ; preds = %streqlit.merge.99
  br label %if.merge.102

if.merge.102:                                     ; preds = %if.else.101
  %r515.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r515.rs4o = call i64 asm "", "=r,0"(i64 %r515.rs4i) #7
  %r515 = bitcast i64 %r515.rs4o to double
  ret double %r515

guarded_add.numeric.103:                          ; preds = %if.then.100
  %r512 = fadd double %r506, 1.000000e+00
  br label %guarded_add.merge.105

guarded_add.dynamic.104:                          ; preds = %if.then.100
  %statepoint_token103 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r506, double 1.000000e+00, i32 0, i32 0)
  %r513104 = call double @llvm.experimental.gc.result.f64(token %statepoint_token103)
  br label %guarded_add.merge.105

guarded_add.merge.105:                            ; preds = %guarded_add.dynamic.104, %guarded_add.numeric.103
  %r514 = phi double [ %r512, %guarded_add.numeric.103 ], [ %r513104, %guarded_add.dynamic.104 ]
  ret double %r514
}

; Function Attrs: optsize
define double @callback_only_ts____AnonShape_4895323cc6307da4_constructor(double %this_arg, double %arg1) #6 gc "statepoint-example" {
entry.0:
  %r7 = load i32, ptr @perry_class_shape_id_callback_only_ts____AnonShape_4895323cc6307da4, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg1 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r4.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r4.rs4o = call i64 asm "", "=r,0"(i64 %r4.rs4i) #7
  %r4 = bitcast i64 %r4.rs4o to double
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #7
  %r5 = bitcast i64 %r5.rs4o to double
  %r9 = bitcast double %r4 to i64
  %r10 = and i64 %r9, 281474976710655
  %r11 = load double, ptr @callback_only_ts_.str.1.handle, align 8
  %r12 = bitcast double %r11 to i64
  %r13 = and i64 %r12, 281474976710655
  %r14 = bitcast double %r5 to i64
  %r15 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r16 = icmp eq i8 %r15, 0
  %r17 = lshr i64 %r9, 48
  %r18 = icmp eq i64 %r17, 32765
  %r19 = icmp ugt i64 %r10, 1048575
  %r20 = and i1 %r18, %r19
  %r21 = and i1 %r20, %r16
  br i1 %r21, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.4
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r73.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r73.rs4o = call i64 asm "", "=r,0"(i64 %r73.rs4i) #7
  %r73 = bitcast i64 %r73.rs4o to double
  %r74 = bitcast double %r73 to i64
  %r75 = and i64 %r74, 281474976710655
  %r58 = inttoptr i64 %r75 to ptr
  %r69.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r69.rs4o = call i64 asm "", "=r,0"(i64 %r69.rs4i) #7
  %r69 = bitcast i64 %r69.rs4o to double
  %r70 = bitcast double %r69 to i64
  %r71 = and i64 %r70, 281474976710655
  %r72 = inttoptr i64 %r71 to ptr
  %r59 = getelementptr i8, ptr %r72, i64 16
  %r60 = getelementptr double, ptr %r59, i64 0
  %r68.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r68.rs4o = call i64 asm "", "=r,0"(i64 %r68.rs4i) #7
  %r68 = bitcast i64 %r68.rs4o to double
  %r61 = call double @js_array_numeric_value_to_raw_f64(double %r68) #7
  store double %r61, ptr %r60, align 8
  br label %class_field_set.merge.4

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r62.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r62.rs4o = call i64 asm "", "=r,0"(i64 %r62.rs4i) #7
  %r62 = bitcast i64 %r62.rs4o to double
  %r63 = bitcast double %r62 to i64
  %r64.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r64.rs4o = call i64 asm "", "=r,0"(i64 %r64.rs4i) #7
  %r64 = bitcast i64 %r64.rs4o to double
  %r65 = load double, ptr @callback_only_ts_.str.1.handle, align 8
  %r66 = bitcast double %r65 to i64
  %r67 = and i64 %r66, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 4883850429458284548, i64 %r63, i64 %r67, double %r64, i32 0, i32 0)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.fallback.3, %class_field_set.fast.2
  br label %standalone.ctor.return.after.1

class_field_inline.deref.5:                       ; preds = %entry.0
  %r22 = inttoptr i64 %r10 to ptr
  %r23 = getelementptr i8, ptr %r22, i64 -8
  %r24 = load i8, ptr %r23, align 1
  %r25 = icmp eq i8 %r24, 2
  %r26 = getelementptr i8, ptr %r22, i64 -7
  %r27 = load i8, ptr %r26, align 1
  %r28 = and i8 %r27, -128
  %r29 = icmp eq i8 %r28, 0
  %r30 = getelementptr i8, ptr %r22, i64 -6
  %r31 = load i16, ptr %r30, align 2
  %r32 = getelementptr i8, ptr %r22, i64 0
  %r33 = load i32, ptr %r32, align 4
  %r34 = icmp eq i32 %r33, 1
  %r35 = getelementptr i8, ptr %r22, i64 4
  %r36 = load i32, ptr %r35, align 4
  %r37 = icmp eq i32 %r36, %r7
  %r38 = and i1 %r25, %r29
  %r39 = and i1 %r38, %r34
  %r40 = and i1 %r39, %r37
  %r41 = and i16 %r31, 3072
  %r42 = icmp eq i16 %r41, 0
  %r43 = and i1 %r40, %r42
  %r44 = and i16 %r31, 4096
  %r45 = icmp ne i16 %r44, 0
  %r46 = and i1 %r43, %r45
  %r47 = and i16 %r31, 1
  %r48 = icmp eq i16 %r47, 0
  %r49 = and i1 %r46, %r48
  %r50 = and i16 %r31, 128
  %r51 = icmp eq i16 %r50, 0
  %r52 = and i1 %r49, %r51
  %r53 = and i64 %r14, 9218868437227405312
  %r54 = icmp ne i64 %r53, 9218868437227405312
  %r55 = and i1 %r52, %r54
  br i1 %r55, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r56 = call i32 @js_typed_feedback_class_field_set_guard(i64 4883850429458284548, double %r4, i32 1, i32 %r7, i64 %r13, i32 0, double %r5, i32 1) #7
  %r57 = icmp ne i32 %r56, 0
  br i1 %r57, label %class_field_set.fast.2, label %class_field_set.fallback.3
}

; Function Attrs: optsize
define double @callback_only_ts____AnonShape_7924916bbe3686f7_constructor(double %this_arg, double %arg2) #6 gc "statepoint-example" {
entry.0:
  %r7 = load i32, ptr @perry_class_shape_id_callback_only_ts____AnonShape_7924916bbe3686f7, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg2 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %r4.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r4.rs4o = call i64 asm "", "=r,0"(i64 %r4.rs4i) #7
  %r4 = bitcast i64 %r4.rs4o to double
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #7
  %r5 = bitcast i64 %r5.rs4o to double
  %r9 = bitcast double %r4 to i64
  %r10 = and i64 %r9, 281474976710655
  %r11 = load double, ptr @callback_only_ts_.str.2.handle, align 8
  %r12 = bitcast double %r11 to i64
  %r13 = and i64 %r12, 281474976710655
  %r14 = bitcast double %r5 to i64
  %r15 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r16 = icmp eq i8 %r15, 0
  %r17 = lshr i64 %r9, 48
  %r18 = icmp eq i64 %r17, 32765
  %r19 = icmp ugt i64 %r10, 1048575
  %r20 = and i1 %r18, %r19
  %r21 = and i1 %r20, %r16
  br i1 %r21, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.4
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r116.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r116.rs4o = call i64 asm "", "=r,0"(i64 %r116.rs4i) #7
  %r116 = bitcast i64 %r116.rs4o to double
  %r117 = bitcast double %r116 to i64
  %r118 = and i64 %r117, 281474976710655
  %r52 = inttoptr i64 %r118 to ptr
  %r112.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r112.rs4o = call i64 asm "", "=r,0"(i64 %r112.rs4i) #7
  %r112 = bitcast i64 %r112.rs4o to double
  %r113 = bitcast double %r112 to i64
  %r114 = and i64 %r113, 281474976710655
  %r115 = inttoptr i64 %r114 to ptr
  %r53 = getelementptr i8, ptr %r115, i64 16
  %r54 = getelementptr double, ptr %r53, i64 0
  %r55 = ptrtoint ptr %r54 to i64
  %r111.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r111.rs4o = call i64 asm "", "=r,0"(i64 %r111.rs4i) #7
  %r111 = bitcast i64 %r111.rs4o to double
  store double %r111, ptr %r54, align 8
  %r110.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r110.rs4o = call i64 asm "", "=r,0"(i64 %r110.rs4i) #7
  %r110 = bitcast i64 %r110.rs4o to double
  %r56 = bitcast double %r110 to i64
  %r108.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r108.rs4o = call i64 asm "", "=r,0"(i64 %r108.rs4i) #7
  %r108 = bitcast i64 %r108.rs4o to double
  %r109 = bitcast double %r108 to i64
  %r57 = lshr i64 %r109, 48
  %r58 = icmp eq i64 %r57, 0
  %r106.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r106.rs4o = call i64 asm "", "=r,0"(i64 %r106.rs4i) #7
  %r106 = bitcast i64 %r106.rs4o to double
  %r107 = bitcast double %r106 to i64
  %r59 = icmp uge i64 %r107, 4096
  %r60 = and i1 %r58, %r59
  %r61 = icmp eq i64 %r57, 32765
  %r62 = icmp eq i64 %r57, 32767
  %r63 = icmp eq i64 %r57, 32762
  %r64 = or i1 %r61, %r62
  %r65 = or i1 %r64, %r63
  %r66 = or i1 %r65, %r60
  br i1 %r66, label %class_field_set.gc_bookkeeping.7, label %class_field_set.gc_bookkeeping.done.8

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r100.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r100.rs4o = call i64 asm "", "=r,0"(i64 %r100.rs4i) #7
  %r100 = bitcast i64 %r100.rs4o to double
  %r101 = bitcast double %r100 to i64
  %r102.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r102.rs4o = call i64 asm "", "=r,0"(i64 %r102.rs4i) #7
  %r102 = bitcast i64 %r102.rs4o to double
  %r103 = load double, ptr @callback_only_ts_.str.2.handle, align 8
  %r104 = bitcast double %r103 to i64
  %r105 = and i64 %r104, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 4883850429458284549, i64 %r101, i64 %r105, double %r102, i32 0, i32 0)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.gc_bookkeeping.done.8, %class_field_set.fallback.3
  br label %standalone.ctor.return.after.1

class_field_inline.deref.5:                       ; preds = %entry.0
  %r22 = inttoptr i64 %r10 to ptr
  %r23 = getelementptr i8, ptr %r22, i64 -8
  %r24 = load i8, ptr %r23, align 1
  %r25 = icmp eq i8 %r24, 2
  %r26 = getelementptr i8, ptr %r22, i64 -7
  %r27 = load i8, ptr %r26, align 1
  %r28 = and i8 %r27, -128
  %r29 = icmp eq i8 %r28, 0
  %r30 = getelementptr i8, ptr %r22, i64 -6
  %r31 = load i16, ptr %r30, align 2
  %r32 = getelementptr i8, ptr %r22, i64 0
  %r33 = load i32, ptr %r32, align 4
  %r34 = icmp eq i32 %r33, 2
  %r35 = getelementptr i8, ptr %r22, i64 4
  %r36 = load i32, ptr %r35, align 4
  %r37 = icmp eq i32 %r36, %r7
  %r38 = and i1 %r25, %r29
  %r39 = and i1 %r38, %r34
  %r40 = and i1 %r39, %r37
  %r41 = and i16 %r31, 3072
  %r42 = icmp eq i16 %r41, 0
  %r43 = and i1 %r40, %r42
  %r44 = and i16 %r31, 1
  %r45 = icmp eq i16 %r44, 0
  %r46 = and i1 %r43, %r45
  %r47 = and i16 %r31, 128
  %r48 = icmp eq i16 %r47, 0
  %r49 = and i1 %r46, %r48
  br i1 %r49, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r50 = call i32 @js_typed_feedback_class_field_set_guard(i64 4883850429458284549, double %r4, i32 2, i32 %r7, i64 %r13, i32 0, double %r5, i32 0) #7
  %r51 = icmp ne i32 %r50, 0
  br i1 %r51, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.gc_bookkeeping.7:                 ; preds = %class_field_set.fast.2
  %r99.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r99.rs4o = call i64 asm "", "=r,0"(i64 %r99.rs4i) #7
  %r99 = bitcast i64 %r99.rs4o to double
  call void @js_string_addref_if_heap_string(double %r99) #7
  %r96.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r96.rs4o = call i64 asm "", "=r,0"(i64 %r96.rs4i) #7
  %r96 = bitcast i64 %r96.rs4o to double
  %r97 = bitcast double %r96 to i64
  %r98 = and i64 %r97, 281474976710655
  %r67 = inttoptr i64 %r98 to ptr
  %r92.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r92.rs4o = call i64 asm "", "=r,0"(i64 %r92.rs4i) #7
  %r92 = bitcast i64 %r92.rs4o to double
  %r93 = bitcast double %r92 to i64
  %r94 = and i64 %r93, 281474976710655
  %r95 = inttoptr i64 %r94 to ptr
  %r68 = getelementptr i8, ptr %r95, i64 -6
  %r69 = load i16, ptr %r68, align 2
  %r70 = and i16 %r69, -12288
  %r71 = icmp eq i16 %r70, -28672
  br i1 %r71, label %class_field_set.layout_note.done.10, label %class_field_set.layout_note.9

class_field_set.gc_bookkeeping.done.8:            ; preds = %class_field_set.barrier.11, %class_field_set.layout_note.done.10, %class_field_set.fast.2
  br label %class_field_set.merge.4

class_field_set.layout_note.9:                    ; preds = %class_field_set.gc_bookkeeping.7
  %r87.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r87.rs4o = call i64 asm "", "=r,0"(i64 %r87.rs4i) #7
  %r87 = bitcast i64 %r87.rs4o to double
  %r88 = bitcast double %r87 to i64
  %r89 = and i64 %r88, 281474976710655
  %r90.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r90.rs4o = call i64 asm "", "=r,0"(i64 %r90.rs4i) #7
  %r90 = bitcast i64 %r90.rs4o to double
  %r91 = bitcast double %r90 to i64
  call void @js_gc_note_slot_layout(i64 %r89, i32 0, i64 %r91) #7
  br label %class_field_set.layout_note.done.10

class_field_set.layout_note.done.10:              ; preds = %class_field_set.layout_note.9, %class_field_set.gc_bookkeeping.7
  %r84.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r84.rs4o = call i64 asm "", "=r,0"(i64 %r84.rs4i) #7
  %r84 = bitcast i64 %r84.rs4o to double
  %r85 = bitcast double %r84 to i64
  %r86 = and i64 %r85, 281474976710655
  %r72 = sub nsw i64 %r86, 7
  %r73 = inttoptr i64 %r72 to ptr
  %r74 = load i8, ptr %r73, align 1
  %r75 = and i8 %r74, 32
  %r76 = icmp ne i8 %r75, 0
  %r77 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r78 = icmp ne i32 %r77, 0
  %r79 = or i1 %r76, %r78
  br i1 %r79, label %class_field_set.barrier.11, label %class_field_set.gc_bookkeeping.done.8

class_field_set.barrier.11:                       ; preds = %class_field_set.layout_note.done.10
  %r80.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r80.rs4o = call i64 asm "", "=r,0"(i64 %r80.rs4i) #7
  %r80 = bitcast i64 %r80.rs4o to double
  %r81 = bitcast double %r80 to i64
  %r82.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r82.rs4o = call i64 asm "", "=r,0"(i64 %r82.rs4i) #7
  %r82 = bitcast i64 %r82.rs4o to double
  %r83 = bitcast double %r82 to i64
  call void @js_write_barrier_slot(i64 %r81, i64 %r55, i64 %r83) #7
  br label %class_field_set.gc_bookkeeping.done.8
}

; Function Attrs: optsize
define double @callback_only_ts____AnonShape_6ef7d34fbe1f1d2c_constructor(double %this_arg, double %arg7, double %arg8) #6 gc "statepoint-example" {
entry.0:
  %r8 = load i32, ptr @perry_class_shape_id_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c, align 4
  %rs4gc.b1 = bitcast double %this_arg to i64
  %rs4gc.s1 = inttoptr i64 %rs4gc.b1 to ptr addrspace(1)
  %rs4gc.b2 = bitcast double %arg7 to i64
  %rs4gc.s2 = inttoptr i64 %rs4gc.b2 to ptr addrspace(1)
  %rs4gc.b3 = bitcast double %arg8 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r5.rs4o = call i64 asm "", "=r,0"(i64 %r5.rs4i) #7
  %r5 = bitcast i64 %r5.rs4o to double
  %r6.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r6.rs4o = call i64 asm "", "=r,0"(i64 %r6.rs4i) #7
  %r6 = bitcast i64 %r6.rs4o to double
  %r10 = bitcast double %r5 to i64
  %r11 = and i64 %r10, 281474976710655
  %r12 = load double, ptr @callback_only_ts_.str.1.handle, align 8
  %r13 = bitcast double %r12 to i64
  %r14 = and i64 %r13, 281474976710655
  %r15 = bitcast double %r6 to i64
  %r16 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r17 = icmp eq i8 %r16, 0
  %r18 = lshr i64 %r10, 48
  %r19 = icmp eq i64 %r18, 32765
  %r20 = icmp ugt i64 %r11, 1048575
  %r21 = and i1 %r19, %r20
  %r22 = and i1 %r21, %r17
  br i1 %r22, label %class_field_inline.deref.5, label %class_field_inline.guardcall.6

standalone.ctor.return.after.1:                   ; preds = %class_field_set.merge.9
  ret double 0x7FFC000000000001

class_field_set.fast.2:                           ; preds = %class_field_inline.guardcall.6, %class_field_inline.deref.5
  %r187.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r187.rs4o = call i64 asm "", "=r,0"(i64 %r187.rs4i) #7
  %r187 = bitcast i64 %r187.rs4o to double
  %r188 = bitcast double %r187 to i64
  %r189 = and i64 %r188, 281474976710655
  %r59 = inttoptr i64 %r189 to ptr
  %r183.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r183.rs4o = call i64 asm "", "=r,0"(i64 %r183.rs4i) #7
  %r183 = bitcast i64 %r183.rs4o to double
  %r184 = bitcast double %r183 to i64
  %r185 = and i64 %r184, 281474976710655
  %r186 = inttoptr i64 %r185 to ptr
  %r60 = getelementptr i8, ptr %r186, i64 16
  %r61 = getelementptr double, ptr %r60, i64 0
  %r182.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r182.rs4o = call i64 asm "", "=r,0"(i64 %r182.rs4i) #7
  %r182 = bitcast i64 %r182.rs4o to double
  %r62 = call double @js_array_numeric_value_to_raw_f64(double %r182) #7
  store double %r62, ptr %r61, align 8
  br label %class_field_set.merge.4

class_field_set.fallback.3:                       ; preds = %class_field_inline.guardcall.6
  %r176.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1 to i64
  %r176.rs4o = call i64 asm "", "=r,0"(i64 %r176.rs4i) #7
  %r176 = bitcast i64 %r176.rs4o to double
  %r177 = bitcast double %r176 to i64
  %r178.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s2 to i64
  %r178.rs4o = call i64 asm "", "=r,0"(i64 %r178.rs4i) #7
  %r178 = bitcast i64 %r178.rs4o to double
  %r179 = load double, ptr @callback_only_ts_.str.1.handle, align 8
  %r180 = bitcast double %r179 to i64
  %r181 = and i64 %r180, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 4883850429458284550, i64 %r177, i64 %r181, double %r178, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3, ptr addrspace(1) %rs4gc.s1) ]
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 1, i32 1) ; (%rs4gc.s1, %rs4gc.s1)
  br label %class_field_set.merge.4

class_field_set.merge.4:                          ; preds = %class_field_set.fallback.3, %class_field_set.fast.2
  %.02 = phi ptr addrspace(1) [ %rs4gc.s1, %class_field_set.fast.2 ], [ %rs4gc.s1.relocated, %class_field_set.fallback.3 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %class_field_set.fast.2 ], [ %rs4gc.s3.relocated, %class_field_set.fallback.3 ]
  %r63.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r63.rs4o = call i64 asm "", "=r,0"(i64 %r63.rs4i) #7
  %r63 = bitcast i64 %r63.rs4o to double
  %r64.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r64.rs4o = call i64 asm "", "=r,0"(i64 %r64.rs4i) #7
  %r64 = bitcast i64 %r64.rs4o to double
  %r66 = bitcast double %r63 to i64
  %r67 = and i64 %r66, 281474976710655
  %r68 = load double, ptr @callback_only_ts_.str.3.handle, align 8
  %r69 = bitcast double %r68 to i64
  %r70 = and i64 %r69, 281474976710655
  %r71 = bitcast double %r64 to i64
  %r72 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r73 = icmp eq i8 %r72, 0
  %r74 = lshr i64 %r66, 48
  %r75 = icmp eq i64 %r74, 32765
  %r76 = icmp ugt i64 %r67, 1048575
  %r77 = and i1 %r75, %r76
  %r78 = and i1 %r77, %r73
  br i1 %r78, label %class_field_inline.deref.10, label %class_field_inline.guardcall.11

class_field_inline.deref.5:                       ; preds = %entry.0
  %r23 = inttoptr i64 %r11 to ptr
  %r24 = getelementptr i8, ptr %r23, i64 -8
  %r25 = load i8, ptr %r24, align 1
  %r26 = icmp eq i8 %r25, 2
  %r27 = getelementptr i8, ptr %r23, i64 -7
  %r28 = load i8, ptr %r27, align 1
  %r29 = and i8 %r28, -128
  %r30 = icmp eq i8 %r29, 0
  %r31 = getelementptr i8, ptr %r23, i64 -6
  %r32 = load i16, ptr %r31, align 2
  %r33 = getelementptr i8, ptr %r23, i64 0
  %r34 = load i32, ptr %r33, align 4
  %r35 = icmp eq i32 %r34, 3
  %r36 = getelementptr i8, ptr %r23, i64 4
  %r37 = load i32, ptr %r36, align 4
  %r38 = icmp eq i32 %r37, %r8
  %r39 = and i1 %r26, %r30
  %r40 = and i1 %r39, %r35
  %r41 = and i1 %r40, %r38
  %r42 = and i16 %r32, 3072
  %r43 = icmp eq i16 %r42, 0
  %r44 = and i1 %r41, %r43
  %r45 = and i16 %r32, 4096
  %r46 = icmp ne i16 %r45, 0
  %r47 = and i1 %r44, %r46
  %r48 = and i16 %r32, 1
  %r49 = icmp eq i16 %r48, 0
  %r50 = and i1 %r47, %r49
  %r51 = and i16 %r32, 128
  %r52 = icmp eq i16 %r51, 0
  %r53 = and i1 %r50, %r52
  %r54 = and i64 %r15, 9218868437227405312
  %r55 = icmp ne i64 %r54, 9218868437227405312
  %r56 = and i1 %r53, %r55
  br i1 %r56, label %class_field_set.fast.2, label %class_field_inline.guardcall.6

class_field_inline.guardcall.6:                   ; preds = %class_field_inline.deref.5, %entry.0
  %r57 = call i32 @js_typed_feedback_class_field_set_guard(i64 4883850429458284550, double %r5, i32 3, i32 %r8, i64 %r14, i32 0, double %r6, i32 1) #7
  %r58 = icmp ne i32 %r57, 0
  br i1 %r58, label %class_field_set.fast.2, label %class_field_set.fallback.3

class_field_set.fast.7:                           ; preds = %class_field_inline.guardcall.11, %class_field_inline.deref.10
  %r173.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r173.rs4o = call i64 asm "", "=r,0"(i64 %r173.rs4i) #7
  %r173 = bitcast i64 %r173.rs4o to double
  %r174 = bitcast double %r173 to i64
  %r175 = and i64 %r174, 281474976710655
  %r109 = inttoptr i64 %r175 to ptr
  %r169.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r169.rs4o = call i64 asm "", "=r,0"(i64 %r169.rs4i) #7
  %r169 = bitcast i64 %r169.rs4o to double
  %r170 = bitcast double %r169 to i64
  %r171 = and i64 %r170, 281474976710655
  %r172 = inttoptr i64 %r171 to ptr
  %r110 = getelementptr i8, ptr %r172, i64 16
  %r111 = getelementptr double, ptr %r110, i64 1
  %r112 = ptrtoint ptr %r111 to i64
  %r168.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r168.rs4o = call i64 asm "", "=r,0"(i64 %r168.rs4i) #7
  %r168 = bitcast i64 %r168.rs4o to double
  store double %r168, ptr %r111, align 8
  %r167.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r167.rs4o = call i64 asm "", "=r,0"(i64 %r167.rs4i) #7
  %r167 = bitcast i64 %r167.rs4o to double
  %r113 = bitcast double %r167 to i64
  %r165.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r165.rs4o = call i64 asm "", "=r,0"(i64 %r165.rs4i) #7
  %r165 = bitcast i64 %r165.rs4o to double
  %r166 = bitcast double %r165 to i64
  %r114 = lshr i64 %r166, 48
  %r115 = icmp eq i64 %r114, 0
  %r163.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r163.rs4o = call i64 asm "", "=r,0"(i64 %r163.rs4i) #7
  %r163 = bitcast i64 %r163.rs4o to double
  %r164 = bitcast double %r163 to i64
  %r116 = icmp uge i64 %r164, 4096
  %r117 = and i1 %r115, %r116
  %r118 = icmp eq i64 %r114, 32765
  %r119 = icmp eq i64 %r114, 32767
  %r120 = icmp eq i64 %r114, 32762
  %r121 = or i1 %r118, %r119
  %r122 = or i1 %r121, %r120
  %r123 = or i1 %r122, %r117
  br i1 %r123, label %class_field_set.gc_bookkeeping.12, label %class_field_set.gc_bookkeeping.done.13

class_field_set.fallback.8:                       ; preds = %class_field_inline.guardcall.11
  %r157.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r157.rs4o = call i64 asm "", "=r,0"(i64 %r157.rs4i) #7
  %r157 = bitcast i64 %r157.rs4o to double
  %r158 = bitcast double %r157 to i64
  %r159.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r159.rs4o = call i64 asm "", "=r,0"(i64 %r159.rs4i) #7
  %r159 = bitcast i64 %r159.rs4o to double
  %r160 = load double, ptr @callback_only_ts_.str.3.handle, align 8
  %r161 = bitcast double %r160 to i64
  %r162 = and i64 %r161, 281474976710655
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64, i64, i64, double)) @js_class_field_set_fallback, i32 4, i32 0, i64 4883850429458284551, i64 %r158, i64 %r162, double %r159, i32 0, i32 0)
  br label %class_field_set.merge.9

class_field_set.merge.9:                          ; preds = %class_field_set.gc_bookkeeping.done.13, %class_field_set.fallback.8
  br label %standalone.ctor.return.after.1

class_field_inline.deref.10:                      ; preds = %class_field_set.merge.4
  %r79 = inttoptr i64 %r67 to ptr
  %r80 = getelementptr i8, ptr %r79, i64 -8
  %r81 = load i8, ptr %r80, align 1
  %r82 = icmp eq i8 %r81, 2
  %r83 = getelementptr i8, ptr %r79, i64 -7
  %r84 = load i8, ptr %r83, align 1
  %r85 = and i8 %r84, -128
  %r86 = icmp eq i8 %r85, 0
  %r87 = getelementptr i8, ptr %r79, i64 -6
  %r88 = load i16, ptr %r87, align 2
  %r89 = getelementptr i8, ptr %r79, i64 0
  %r90 = load i32, ptr %r89, align 4
  %r91 = icmp eq i32 %r90, 3
  %r92 = getelementptr i8, ptr %r79, i64 4
  %r93 = load i32, ptr %r92, align 4
  %r94 = icmp eq i32 %r93, %r8
  %r95 = and i1 %r82, %r86
  %r96 = and i1 %r95, %r91
  %r97 = and i1 %r96, %r94
  %r98 = and i16 %r88, 3072
  %r99 = icmp eq i16 %r98, 0
  %r100 = and i1 %r97, %r99
  %r101 = and i16 %r88, 1
  %r102 = icmp eq i16 %r101, 0
  %r103 = and i1 %r100, %r102
  %r104 = and i16 %r88, 128
  %r105 = icmp eq i16 %r104, 0
  %r106 = and i1 %r103, %r105
  br i1 %r106, label %class_field_set.fast.7, label %class_field_inline.guardcall.11

class_field_inline.guardcall.11:                  ; preds = %class_field_inline.deref.10, %class_field_set.merge.4
  %r107 = call i32 @js_typed_feedback_class_field_set_guard(i64 4883850429458284551, double %r63, i32 3, i32 %r8, i64 %r70, i32 1, double %r64, i32 0) #7
  %r108 = icmp ne i32 %r107, 0
  br i1 %r108, label %class_field_set.fast.7, label %class_field_set.fallback.8

class_field_set.gc_bookkeeping.12:                ; preds = %class_field_set.fast.7
  %r156.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r156.rs4o = call i64 asm "", "=r,0"(i64 %r156.rs4i) #7
  %r156 = bitcast i64 %r156.rs4o to double
  call void @js_string_addref_if_heap_string(double %r156) #7
  %r153.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r153.rs4o = call i64 asm "", "=r,0"(i64 %r153.rs4i) #7
  %r153 = bitcast i64 %r153.rs4o to double
  %r154 = bitcast double %r153 to i64
  %r155 = and i64 %r154, 281474976710655
  %r124 = inttoptr i64 %r155 to ptr
  %r149.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r149.rs4o = call i64 asm "", "=r,0"(i64 %r149.rs4i) #7
  %r149 = bitcast i64 %r149.rs4o to double
  %r150 = bitcast double %r149 to i64
  %r151 = and i64 %r150, 281474976710655
  %r152 = inttoptr i64 %r151 to ptr
  %r125 = getelementptr i8, ptr %r152, i64 -6
  %r126 = load i16, ptr %r125, align 2
  %r127 = and i16 %r126, -12288
  %r128 = icmp eq i16 %r127, -28672
  br i1 %r128, label %class_field_set.layout_note.done.15, label %class_field_set.layout_note.14

class_field_set.gc_bookkeeping.done.13:           ; preds = %class_field_set.barrier.16, %class_field_set.layout_note.done.15, %class_field_set.fast.7
  br label %class_field_set.merge.9

class_field_set.layout_note.14:                   ; preds = %class_field_set.gc_bookkeeping.12
  %r144.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r144.rs4o = call i64 asm "", "=r,0"(i64 %r144.rs4i) #7
  %r144 = bitcast i64 %r144.rs4o to double
  %r145 = bitcast double %r144 to i64
  %r146 = and i64 %r145, 281474976710655
  %r147.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r147.rs4o = call i64 asm "", "=r,0"(i64 %r147.rs4i) #7
  %r147 = bitcast i64 %r147.rs4o to double
  %r148 = bitcast double %r147 to i64
  call void @js_gc_note_slot_layout(i64 %r146, i32 1, i64 %r148) #7
  br label %class_field_set.layout_note.done.15

class_field_set.layout_note.done.15:              ; preds = %class_field_set.layout_note.14, %class_field_set.gc_bookkeeping.12
  %r141.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r141.rs4o = call i64 asm "", "=r,0"(i64 %r141.rs4i) #7
  %r141 = bitcast i64 %r141.rs4o to double
  %r142 = bitcast double %r141 to i64
  %r143 = and i64 %r142, 281474976710655
  %r129 = sub nsw i64 %r143, 7
  %r130 = inttoptr i64 %r129 to ptr
  %r131 = load i8, ptr %r130, align 1
  %r132 = and i8 %r131, 32
  %r133 = icmp ne i8 %r132, 0
  %r134 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r135 = icmp ne i32 %r134, 0
  %r136 = or i1 %r133, %r135
  br i1 %r136, label %class_field_set.barrier.16, label %class_field_set.gc_bookkeeping.done.13

class_field_set.barrier.16:                       ; preds = %class_field_set.layout_note.done.15
  %r137.rs4i = ptrtoint ptr addrspace(1) %.02 to i64
  %r137.rs4o = call i64 asm "", "=r,0"(i64 %r137.rs4i) #7
  %r137 = bitcast i64 %r137.rs4o to double
  %r138 = bitcast double %r137 to i64
  %r139.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r139.rs4o = call i64 asm "", "=r,0"(i64 %r139.rs4i) #7
  %r139 = bitcast i64 %r139.rs4o to double
  %r140 = bitcast double %r139 to i64
  call void @js_write_barrier_slot(i64 %r138, i64 %r112, i64 %r140) #7
  br label %class_field_set.gc_bookkeeping.done.13
}

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_callback_only_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @callback_only_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" {
entry.0:
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @callback_only_ts_.str.0, i32 120, i32 0, i32 0)
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token3 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token4 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_callback_only_ts, i32 0, i32 0, i32 0, i32 0)
  %r15 = load i64, ptr @perry_class_keys_callback_only_ts____AnonShape_4895323cc6307da4, align 8
  %rs4gc.s1 = inttoptr i64 %r15 to ptr addrspace(1)
  %r18 = load i32, ptr @perry_class_shape_id_callback_only_ts____AnonShape_4895323cc6307da4, align 4
  %r59 = load i64, ptr @perry_class_keys_callback_only_ts____AnonShape_7924916bbe3686f7, align 8
  %rs4gc.s2 = inttoptr i64 %r59 to ptr addrspace(1)
  %r62 = load i32, ptr @perry_class_shape_id_callback_only_ts____AnonShape_7924916bbe3686f7, align 4
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_callback_only_ts__0 to i64)) #7
  store double 0.000000e+00, ptr @perry_global_callback_only_ts__0, align 8
  call void @js_write_barrier_root_nanbox(i64 0) #7
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s2, ptr addrspace(1) %rs4gc.s1) ]
  %r36 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token5)
  %rs4gc.s2.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 0, i32 0) ; (%rs4gc.s2, %rs4gc.s2)
  %rs4gc.s1.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token5, i32 1, i32 1) ; (%rs4gc.s1, %rs4gc.s1)
  %rs4gc.s3 = inttoptr i64 %r36 to ptr addrspace(1)
  %r5.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r5 = call i64 asm "", "=r,0"(i64 %r5.rs4i) #7
  %r6 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r7 = icmp ne i32 %r6, 0
  br i1 %r7, label %shadow.root.barrier.1, label %shadow.root.barrier.done.2

shadow.root.barrier.1:                            ; preds = %entry.0
  call void @js_write_barrier_root_nanbox(i64 %r5) #7
  br label %shadow.root.barrier.done.2

shadow.root.barrier.done.2:                       ; preds = %shadow.root.barrier.1, %entry.0
  %r8 = load double, ptr @callback_only_ts_.str.4.handle, align 8
  %r9.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s3 to i64
  %r9 = call i64 asm "", "=r,0"(i64 %r9.rs4i) #7
  %statepoint_token7 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r9, double %r8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s2.relocated, ptr addrspace(1) %rs4gc.s1.relocated) ]
  %r1010 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token7)
  %rs4gc.s2.relocated11 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token7, i32 0, i32 0) ; (%rs4gc.s2.relocated, %rs4gc.s2.relocated)
  %rs4gc.s1.relocated12 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token7, i32 1, i32 1) ; (%rs4gc.s1.relocated, %rs4gc.s1.relocated)
  %rs4gc.s4 = inttoptr i64 %r1010 to ptr addrspace(1)
  %r11.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s4 to i64
  %r11 = call i64 asm "", "=r,0"(i64 %r11.rs4i) #7
  %r12 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r13 = icmp ne i32 %r12, 0
  br i1 %r13, label %shadow.root.barrier.3, label %shadow.root.barrier.done.4

shadow.root.barrier.3:                            ; preds = %shadow.root.barrier.done.2
  call void @js_write_barrier_root_nanbox(i64 %r11) #7
  br label %shadow.root.barrier.done.4

shadow.root.barrier.done.4:                       ; preds = %shadow.root.barrier.3, %shadow.root.barrier.done.2
  %r16.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s1.relocated12 to i64
  %r16 = call i64 asm "", "=r,0"(i64 %r16.rs4i) #7
  %statepoint_token13 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 1, i32 0, i32 1, i64 %r16, i32 %r18, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s2.relocated11) ]
  %r2014 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token13)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token13, i32 0, i32 0) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s2.relocated15 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token13, i32 1, i32 1) ; (%rs4gc.s2.relocated11, %rs4gc.s2.relocated11)
  call void @js_gc_declare_typed_shape_layout(i64 %r2014, i32 1, ptr @perry_typed_shape_raw_f64_mask_callback_only_ts____AnonShape_4895323cc6307da4, i32 1, ptr null, i32 0) #7
  %rs4gc.s5 = inttoptr i64 %r2014 to ptr addrspace(1)
  %r22.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s5 to i64
  %r22 = call i64 asm "", "=r,0"(i64 %r22.rs4i) #7
  %r23 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r24 = icmp ne i32 %r23, 0
  br i1 %r24, label %shadow.root.barrier.5, label %shadow.root.barrier.done.6

shadow.root.barrier.5:                            ; preds = %shadow.root.barrier.done.4
  call void @js_write_barrier_root_nanbox(i64 %r22) #7
  br label %shadow.root.barrier.done.6

shadow.root.barrier.done.6:                       ; preds = %shadow.root.barrier.5, %shadow.root.barrier.done.4
  %r25 = or i64 %r2014, 9222527611924643840
  %r26 = bitcast i64 %r25 to double
  %r27 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r28 = icmp eq i8 %r27, 0
  %r29 = inttoptr i64 %r2014 to ptr
  %r30 = getelementptr i8, ptr %r29, i64 -6
  %r31 = load i16, ptr %r30, align 2
  %r32 = and i16 %r31, 4096
  %r33 = icmp ne i16 %r32, 0
  %r34 = and i1 %r28, %r33
  br i1 %r34, label %ctor_prologue.fast.7, label %ctor_prologue.slow.8

ctor_prologue.fast.7:                             ; preds = %shadow.root.barrier.done.6
  %r39 = inttoptr i64 %r2014 to ptr
  %r40 = getelementptr i8, ptr %r39, i64 16
  %r41 = bitcast double %r26 to i64
  %r42 = getelementptr double, ptr %r40, i64 0
  store double 7.000000e+00, ptr %r42, align 8
  %r43 = ptrtoint ptr %r42 to i64
  br label %ctor_prologue.merge.9

ctor_prologue.slow.8:                             ; preds = %shadow.root.barrier.done.6
  %statepoint_token16 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @callback_only_ts____AnonShape_4895323cc6307da4_constructor, i32 2, i32 0, double %r26, double 7.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated, ptr addrspace(1) %rs4gc.s2.relocated15, ptr addrspace(1) %rs4gc.s5) ]
  %r4517 = call double @llvm.experimental.gc.result.f64(token %statepoint_token16)
  %rs4gc.s4.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 0, i32 0) ; (%rs4gc.s4.relocated, %rs4gc.s4.relocated)
  %rs4gc.s2.relocated19 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 1, i32 1) ; (%rs4gc.s2.relocated15, %rs4gc.s2.relocated15)
  %rs4gc.s5.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 2, i32 2) ; (%rs4gc.s5, %rs4gc.s5)
  br label %ctor_prologue.merge.9

ctor_prologue.merge.9:                            ; preds = %ctor_prologue.slow.8, %ctor_prologue.fast.7
  %.090 = phi ptr addrspace(1) [ %rs4gc.s5, %ctor_prologue.fast.7 ], [ %rs4gc.s5.relocated, %ctor_prologue.slow.8 ]
  %.088 = phi ptr addrspace(1) [ %rs4gc.s4.relocated, %ctor_prologue.fast.7 ], [ %rs4gc.s4.relocated18, %ctor_prologue.slow.8 ]
  %.0 = phi ptr addrspace(1) [ %rs4gc.s2.relocated15, %ctor_prologue.fast.7 ], [ %rs4gc.s2.relocated19, %ctor_prologue.slow.8 ]
  %r46 = phi double [ 0x7FFC000000000001, %ctor_prologue.fast.7 ], [ %r4517, %ctor_prologue.slow.8 ]
  %r47.rs4i = ptrtoint ptr addrspace(1) %.090 to i64
  %r47 = call i64 asm "", "=r,0"(i64 %r47.rs4i) #7
  %r48 = or i64 %r47, 9222527611924643840
  %r49 = bitcast i64 %r48 to double
  %r50 = bitcast double %r46 to i64
  %r51 = icmp eq i64 %r50, 9222246136947933185
  br i1 %r51, label %ctor_ret.merge.11, label %ctor_ret.override.10

ctor_ret.override.10:                             ; preds = %ctor_prologue.merge.9
  %statepoint_token20 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r49, double %r46, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.088, ptr addrspace(1) %.0) ]
  %r5221 = call double @llvm.experimental.gc.result.f64(token %statepoint_token20)
  %rs4gc.s4.relocated22 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 0, i32 0) ; (%.088, %.088)
  %rs4gc.s2.relocated23 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token20, i32 1, i32 1) ; (%.0, %.0)
  br label %ctor_ret.merge.11

ctor_ret.merge.11:                                ; preds = %ctor_ret.override.10, %ctor_prologue.merge.9
  %.189 = phi ptr addrspace(1) [ %.088, %ctor_prologue.merge.9 ], [ %rs4gc.s4.relocated22, %ctor_ret.override.10 ]
  %.1 = phi ptr addrspace(1) [ %.0, %ctor_prologue.merge.9 ], [ %rs4gc.s2.relocated23, %ctor_ret.override.10 ]
  %r53 = phi double [ %r49, %ctor_prologue.merge.9 ], [ %r5221, %ctor_ret.override.10 ]
  %r54 = bitcast double %r53 to i64
  %rs4gc.s6 = inttoptr i64 %r54 to ptr addrspace(1)
  %r55.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r55 = call i64 asm "", "=r,0"(i64 %r55.rs4i) #7
  %r56 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r57 = icmp ne i32 %r56, 0
  br i1 %r57, label %shadow.root.barrier.12, label %shadow.root.barrier.done.13

shadow.root.barrier.12:                           ; preds = %ctor_ret.merge.11
  call void @js_write_barrier_root_nanbox(i64 %r55) #7
  br label %shadow.root.barrier.done.13

shadow.root.barrier.done.13:                      ; preds = %shadow.root.barrier.12, %ctor_ret.merge.11
  %r60.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r60 = call i64 asm "", "=r,0"(i64 %r60.rs4i) #7
  %statepoint_token24 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32, i32, i32, i64, i32)) @js_object_alloc_class_inline_keys_stamped, i32 5, i32 0, i32 2, i32 0, i32 1, i64 %r60, i32 %r62, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.189, ptr addrspace(1) %rs4gc.s6) ]
  %r6425 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token24)
  %rs4gc.s4.relocated26 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token24, i32 0, i32 0) ; (%.189, %.189)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token24, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  call void @js_gc_declare_typed_shape_layout(i64 %r6425, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_callback_only_ts____AnonShape_7924916bbe3686f7, i32 1) #7
  %rs4gc.s7 = inttoptr i64 %r6425 to ptr addrspace(1)
  %r66.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r66 = call i64 asm "", "=r,0"(i64 %r66.rs4i) #7
  %r67 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r68 = icmp ne i32 %r67, 0
  br i1 %r68, label %shadow.root.barrier.14, label %shadow.root.barrier.done.15

shadow.root.barrier.14:                           ; preds = %shadow.root.barrier.done.13
  call void @js_write_barrier_root_nanbox(i64 %r66) #7
  br label %shadow.root.barrier.done.15

shadow.root.barrier.done.15:                      ; preds = %shadow.root.barrier.14, %shadow.root.barrier.done.13
  %r69 = or i64 %r6425, 9222527611924643840
  %r70 = bitcast i64 %r69 to double
  %r71.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6.relocated to i64
  %r71 = call i64 asm "", "=r,0"(i64 %r71.rs4i) #7
  %r72 = bitcast i64 %r71 to double
  %r73 = load volatile i8, ptr @PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED, align 1
  %r74 = icmp eq i8 %r73, 0
  %r75 = inttoptr i64 %r6425 to ptr
  %r76 = getelementptr i8, ptr %r75, i64 -6
  %r77 = load i16, ptr %r76, align 2
  %r78 = and i16 %r77, 4096
  %r79 = icmp ne i16 %r78, 0
  %r80 = and i1 %r74, %r79
  br i1 %r80, label %ctor_prologue.fast.16, label %ctor_prologue.slow.17

ctor_prologue.fast.16:                            ; preds = %shadow.root.barrier.done.15
  %r81 = inttoptr i64 %r6425 to ptr
  %r82 = getelementptr i8, ptr %r81, i64 16
  %r83 = bitcast double %r70 to i64
  %r84 = getelementptr double, ptr %r82, i64 0
  store double %r72, ptr %r84, align 8
  %r85 = ptrtoint ptr %r84 to i64
  %r86 = bitcast double %r72 to i64
  %r87 = lshr i64 %r86, 48
  %r88 = icmp eq i64 %r87, 0
  %r89 = icmp uge i64 %r86, 4096
  %r90 = and i1 %r88, %r89
  %r91 = icmp eq i64 %r87, 32765
  %r92 = icmp eq i64 %r87, 32767
  %r93 = icmp eq i64 %r87, 32762
  %r94 = or i1 %r91, %r92
  %r95 = or i1 %r94, %r93
  %r96 = or i1 %r95, %r90
  br i1 %r96, label %ctor_prologue.barrier.maybe.19, label %ctor_prologue.barrier.done.21

ctor_prologue.slow.17:                            ; preds = %shadow.root.barrier.done.15
  %statepoint_token27 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @callback_only_ts____AnonShape_7924916bbe3686f7_constructor, i32 2, i32 0, double %r70, double %r72, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated26, ptr addrspace(1) %rs4gc.s7) ]
  %r10528 = call double @llvm.experimental.gc.result.f64(token %statepoint_token27)
  %rs4gc.s4.relocated29 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token27, i32 0, i32 0) ; (%rs4gc.s4.relocated26, %rs4gc.s4.relocated26)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token27, i32 1, i32 1) ; (%rs4gc.s7, %rs4gc.s7)
  br label %ctor_prologue.merge.18

ctor_prologue.merge.18:                           ; preds = %ctor_prologue.barrier.done.21, %ctor_prologue.slow.17
  %.091 = phi ptr addrspace(1) [ %rs4gc.s7, %ctor_prologue.barrier.done.21 ], [ %rs4gc.s7.relocated, %ctor_prologue.slow.17 ]
  %.2 = phi ptr addrspace(1) [ %rs4gc.s4.relocated26, %ctor_prologue.barrier.done.21 ], [ %rs4gc.s4.relocated29, %ctor_prologue.slow.17 ]
  %r106 = phi double [ 0x7FFC000000000001, %ctor_prologue.barrier.done.21 ], [ %r10528, %ctor_prologue.slow.17 ]
  %r107.rs4i = ptrtoint ptr addrspace(1) %.091 to i64
  %r107 = call i64 asm "", "=r,0"(i64 %r107.rs4i) #7
  %r108 = or i64 %r107, 9222527611924643840
  %r109 = bitcast i64 %r108 to double
  %r110 = bitcast double %r106 to i64
  %r111 = icmp eq i64 %r110, 9222246136947933185
  br i1 %r111, label %ctor_ret.merge.23, label %ctor_ret.override.22

ctor_prologue.barrier.maybe.19:                   ; preds = %ctor_prologue.fast.16
  %r97 = sub i64 %r6425, 7
  %r98 = inttoptr i64 %r97 to ptr
  %r99 = load i8, ptr %r98, align 1
  %r100 = and i8 %r99, 32
  %r101 = icmp ne i8 %r100, 0
  %r102 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r103 = icmp ne i32 %r102, 0
  %r104 = or i1 %r101, %r103
  br i1 %r104, label %ctor_prologue.barrier.20, label %ctor_prologue.barrier.done.21

ctor_prologue.barrier.20:                         ; preds = %ctor_prologue.barrier.maybe.19
  call void @js_write_barrier_slot_validated_parent(i64 %r6425, i64 %r85, i64 %r86) #7
  br label %ctor_prologue.barrier.done.21

ctor_prologue.barrier.done.21:                    ; preds = %ctor_prologue.barrier.20, %ctor_prologue.barrier.maybe.19, %ctor_prologue.fast.16
  br label %ctor_prologue.merge.18

ctor_ret.override.22:                             ; preds = %ctor_prologue.merge.18
  %statepoint_token30 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double, i32)) @js_ctor_return_override, i32 3, i32 0, double %r109, double %r106, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r11231 = call double @llvm.experimental.gc.result.f64(token %statepoint_token30)
  %rs4gc.s4.relocated32 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token30, i32 0, i32 0) ; (%.2, %.2)
  br label %ctor_ret.merge.23

ctor_ret.merge.23:                                ; preds = %ctor_ret.override.22, %ctor_prologue.merge.18
  %.3 = phi ptr addrspace(1) [ %.2, %ctor_prologue.merge.18 ], [ %rs4gc.s4.relocated32, %ctor_ret.override.22 ]
  %r113 = phi double [ %r109, %ctor_prologue.merge.18 ], [ %r11231, %ctor_ret.override.22 ]
  %statepoint_token33 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (ptr, i32)) @js_closure_alloc, i32 2, i32 0, ptr @perry_closure_callback_only_ts__2, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3) ]
  %r11434 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token33)
  %rs4gc.s4.relocated35 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token33, i32 0, i32 0) ; (%.3, %.3)
  %r115 = or i64 %r11434, 9222527611924643840
  %r116 = bitcast i64 %r115 to double
  %statepoint_token36 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r113, double %r116, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s4.relocated35) ]
  %r11737 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token36)
  %rs4gc.s4.relocated38 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token36, i32 0, i32 0) ; (%rs4gc.s4.relocated35, %rs4gc.s4.relocated35)
  %r118 = bitcast i64 %r11737 to double
  %r119.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s4.relocated38 to i64
  %r119 = call i64 asm "", "=r,0"(i64 %r119.rs4i) #7
  %statepoint_token39 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r119, double %r118, i32 0, i32 0)
  %r12040 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token39)
  %rs4gc.s8 = inttoptr i64 %r12040 to ptr addrspace(1)
  %r121.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r121 = call i64 asm "", "=r,0"(i64 %r121.rs4i) #7
  %r122 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r123 = icmp ne i32 %r122, 0
  br i1 %r123, label %shadow.root.barrier.24, label %shadow.root.barrier.done.25

shadow.root.barrier.24:                           ; preds = %ctor_ret.merge.23
  call void @js_write_barrier_root_nanbox(i64 %r121) #7
  br label %shadow.root.barrier.done.25

shadow.root.barrier.done.25:                      ; preds = %shadow.root.barrier.24, %ctor_ret.merge.23
  %r124 = load double, ptr @perry_global_callback_only_ts__0, align 8
  %r125.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r125 = call i64 asm "", "=r,0"(i64 %r125.rs4i) #7
  %statepoint_token41 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r125, double %r124, i32 0, i32 0)
  %r12642 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token41)
  %rs4gc.s9 = inttoptr i64 %r12642 to ptr addrspace(1)
  %r127.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r127 = call i64 asm "", "=r,0"(i64 %r127.rs4i) #7
  %r128 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r129 = icmp ne i32 %r128, 0
  br i1 %r129, label %shadow.root.barrier.26, label %shadow.root.barrier.done.27

shadow.root.barrier.26:                           ; preds = %shadow.root.barrier.done.25
  call void @js_write_barrier_root_nanbox(i64 %r127) #7
  br label %shadow.root.barrier.done.27

shadow.root.barrier.done.27:                      ; preds = %shadow.root.barrier.26, %shadow.root.barrier.done.25
  %r130.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r130 = call i64 asm "", "=r,0"(i64 %r130.rs4i) #7
  %statepoint_token43 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r130, i32 0, i32 0)
  %statepoint_token44 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token45 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token46 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token47 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token48 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.28

event_loop.header.28:                             ; preds = %event_loop.body_wait.33, %event_loop.body_check.32, %shadow.root.barrier.done.27
  %statepoint_token49 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r13550 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token49)
  %r136 = icmp ne i32 %r13550, 0
  br i1 %r136, label %event_loop.host_return.30, label %event_loop.check_pending.29

event_loop.check_pending.29:                      ; preds = %event_loop.header.28
  %statepoint_token51 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r13752 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token51)
  %statepoint_token53 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r13854 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token53)
  %statepoint_token55 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r13956 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token55)
  %statepoint_token57 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r14058 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token57)
  %statepoint_token59 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r14160 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token59)
  %statepoint_token61 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r14262 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token61)
  %r143 = or i32 %r13752, %r13854
  %r144 = or i32 %r13956, %r14058
  %r145 = or i32 %r144, %r14160
  %r146 = or i32 %r143, %r145
  %r147 = or i32 %r146, 0
  %r148 = or i32 %r147, %r14262
  %r149 = icmp ne i32 %r148, 0
  br i1 %r149, label %event_loop.body.31, label %event_loop.exit.34

event_loop.host_return.30:                        ; preds = %event_loop.header.28
  call void @js_typed_feedback_maybe_dump_trace() #7
  ret i32 0

event_loop.body.31:                               ; preds = %event_loop.check_pending.29
  %statepoint_token63 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token64 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.32

event_loop.body_check.32:                         ; preds = %event_loop.body.31
  %statepoint_token65 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r15166 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token65)
  %statepoint_token67 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r15268 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token67)
  %statepoint_token69 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r15370 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token69)
  %statepoint_token71 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r15472 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token71)
  %statepoint_token73 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r15574 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token73)
  %statepoint_token75 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r15676 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token75)
  %r157 = or i32 %r15166, %r15268
  %r158 = or i32 %r15370, %r15472
  %r159 = or i32 %r158, %r15574
  %r160 = or i32 %r157, %r159
  %r161 = or i32 %r160, 0
  %r162 = or i32 %r161, %r15676
  %r163 = icmp ne i32 %r162, 0
  br i1 %r163, label %event_loop.body_wait.33, label %event_loop.header.28

event_loop.body_wait.33:                          ; preds = %event_loop.body_check.32
  %statepoint_token77 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.28

event_loop.exit.34:                               ; preds = %event_loop.check_pending.29
  %statepoint_token78 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token79 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token80 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token81 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token82 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token83 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token84 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token85 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token86 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r16687 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token86)
  call void @js_typed_feedback_maybe_dump_trace() #7
  ret i32 %r16687
}

; Function Attrs: optsize
define void @__perry_init_strings_callback_only_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @callback_only_ts_.str.0.bytes, i32 9)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @callback_only_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @callback_only_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @callback_only_ts_.str.1.bytes, i32 2)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @callback_only_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @callback_only_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @callback_only_ts_.str.2.bytes, i32 4)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @callback_only_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @callback_only_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @callback_only_ts_.str.3.bytes, i32 4)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @callback_only_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @callback_only_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @callback_only_ts_.str.4.bytes, i32 15)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @callback_only_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @callback_only_ts_.str.4.handle to i64))
  call void @js_register_function_name_static(ptr @callback_only_ts____AnonShape_4895323cc6307da4_constructor, ptr @callback_only_ts_.str.1, i32 32)
  call void @js_register_function_name_static(ptr @callback_only_ts____AnonShape_7924916bbe3686f7_constructor, ptr @callback_only_ts_.str.2, i32 32)
  call void @js_register_function_name_static(ptr @callback_only_ts____AnonShape_6ef7d34fbe1f1d2c_constructor, ptr @callback_only_ts_.str.3, i32 32)
  call void @js_register_function_source_static(ptr @perry_closure_callback_only_ts__2, ptr @callback_only_ts_.str.4, i32 255, i32 0)
  %r16 = call i64 @js_build_class_keys_array(i32 1, i32 1, ptr @perry_class_keys_packed_callback_only_ts__0, i32 3)
  store i64 %r16, ptr @perry_class_keys_callback_only_ts____AnonShape_4895323cc6307da4, align 8
  call void @js_write_barrier_root_heap_word(i64 %r16)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_callback_only_ts____AnonShape_4895323cc6307da4 to i64))
  %r18 = call i32 @js_object_shape_id_for_keys(i64 %r16, i32 1)
  store i32 %r18, ptr @perry_class_shape_id_callback_only_ts____AnonShape_4895323cc6307da4, align 4
  %r19 = zext i32 %r18 to i64
  %r20 = shl nuw i64 %r19, 32
  %r21 = or i64 %r20, 1
  %r22 = insertelement <2 x i64> <i64 173140869634, i64 0>, i64 %r21, i32 1
  store <2 x i64> %r22, ptr @perry_class_header_image_callback_only_ts____AnonShape_4895323cc6307da4, align 8
  %r23 = call i64 @js_build_class_keys_array(i32 2, i32 1, ptr @perry_class_keys_packed_callback_only_ts__1, i32 5)
  store i64 %r23, ptr @perry_class_keys_callback_only_ts____AnonShape_7924916bbe3686f7, align 8
  call void @js_write_barrier_root_heap_word(i64 %r23)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_callback_only_ts____AnonShape_7924916bbe3686f7 to i64))
  %r25 = call i32 @js_gc_typed_shape_id_for_keys(i32 2, i64 %r23, i32 1, ptr null, i32 0, ptr @perry_typed_shape_mask_callback_only_ts____AnonShape_7924916bbe3686f7, i32 1)
  store i32 %r25, ptr @perry_class_shape_id_callback_only_ts____AnonShape_7924916bbe3686f7, align 4
  %r26 = zext i32 %r25 to i64
  %r27 = shl nuw i64 %r26, 32
  %r28 = or i64 %r27, 2
  %r29 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r28, i32 1
  store <2 x i64> %r29, ptr @perry_class_header_image_callback_only_ts____AnonShape_7924916bbe3686f7, align 8
  %r30 = call i64 @js_build_class_keys_array(i32 3, i32 2, ptr @perry_class_keys_packed_callback_only_ts__2, i32 8)
  store i64 %r30, ptr @perry_class_keys_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c, align 8
  call void @js_write_barrier_root_heap_word(i64 %r30)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_class_keys_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c to i64))
  %r32 = call i32 @js_gc_typed_shape_id_for_keys(i32 3, i64 %r30, i32 2, ptr @perry_typed_shape_raw_f64_mask_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c, i32 1, ptr @perry_typed_shape_mask_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c, i32 1)
  store i32 %r32, ptr @perry_class_shape_id_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c, align 4
  %r33 = zext i32 %r32 to i64
  %r34 = shl nuw i64 %r33, 32
  %r35 = or i64 %r34, 3
  %r36 = insertelement <2 x i64> <i64 174214611458, i64 0>, i64 %r35, i32 1
  store <2 x i64> %r36, ptr @perry_class_header_image_callback_only_ts____AnonShape_6ef7d34fbe1f1d2c, align 8
  call void @js_register_class_constructor(i64 1, i64 ptrtoint (ptr @callback_only_ts____AnonShape_4895323cc6307da4_constructor to i64), i64 1, i64 0)
  call void @js_register_class_constructor(i64 2, i64 ptrtoint (ptr @callback_only_ts____AnonShape_7924916bbe3686f7_constructor to i64), i64 1, i64 0)
  call void @js_register_class_constructor(i64 3, i64 ptrtoint (ptr @callback_only_ts____AnonShape_6ef7d34fbe1f1d2c_constructor to i64), i64 2, i64 0)
  call void @js_register_class_id(i32 1)
  call void @js_register_class_id(i32 2)
  call void @js_register_class_id(i32 3)
  call void @js_register_anon_shape_class_id(i32 1)
  call void @js_register_anon_shape_class_id(i32 2)
  call void @js_register_anon_shape_class_id(i32 3)
  call void @js_register_class_length(i32 1, i32 1)
  call void @js_register_class_length(i32 2, i32 1)
  call void @js_register_class_length(i32 3, i32 2)
  call void @js_register_closure_arity(ptr @perry_closure_callback_only_ts__2, i32 2)
  call void @js_register_closure_length(ptr @perry_closure_callback_only_ts__2, i32 2)
  call void @js_register_closure_strict_function(ptr @perry_closure_callback_only_ts__2)
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_callback_only_ts() #6 {
entry.0:
  call void @__perry_init_strings_callback_only_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { "gc-leaf-function" }

!0 = !{}
