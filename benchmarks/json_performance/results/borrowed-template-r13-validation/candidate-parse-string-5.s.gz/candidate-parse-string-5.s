
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/borrowed-template-r13/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001005e7320 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len>:
1005e7320:     	cbz	x2, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7324:     	ldr	w8, [x2, #0x4]
1005e7328:     	adds	x11, x3, x1
1005e732c:     	cset	w9, hs
1005e7330:     	subs	x10, x8, x11
1005e7334:     	csinc	w9, w9, wzr, hs
1005e7338:     	tbnz	w9, #0x0, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e733c:     	subs	x8, x8, x1
1005e7340:     	b.lo	0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7344:     	cmp	x8, x1, lsr #3
1005e7348:     	b.hi	0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e734c:     	add	x12, x2, #0x14
1005e7350:     	ldr	w9, [x2]
1005e7354:     	cbz	x1, 0x1005e7374 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x54>
1005e7358:     	add	x13, x12, x3
1005e735c:     	add	x13, x13, x1
1005e7360:     	ldurb	w14, [x13, #-0x1]
1005e7364:     	cmp	w14, #0xc0
1005e7368:     	b.hs	0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e736c:     	cmp	x1, #0x1
1005e7370:     	b.ne	0x1005e7548 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x228>
1005e7374:     	cmp	x3, #0x40
1005e7378:     	b.hs	0x1005e741c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0xfc>
1005e737c:     	ands	x14, x3, #0x38
1005e7380:     	b.eq	0x1005e73a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x84>
1005e7384:     	and	x13, x3, #0x38
1005e7388:     	neg	x13, x13
1005e738c:     	mov	x15, x12
1005e7390:     	ldr	x16, [x15], #0x8
1005e7394:     	tst	x16, #0x8080808080808080
1005e7398:     	b.ne	0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e739c:     	adds	x13, x13, #0x8
1005e73a0:     	b.ne	0x1005e7390 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x70>
1005e73a4:     	and	x13, x3, #0x7
1005e73a8:     	cbz	x13, 0x1005e749c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e73ac:     	add	x14, x12, x14
1005e73b0:     	ldrsb	w15, [x14]
1005e73b4:     	tbnz	w15, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e73b8:     	cmp	x13, #0x1
1005e73bc:     	b.eq	0x1005e749c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e73c0:     	ldrsb	w15, [x14, #0x1]
1005e73c4:     	tbnz	w15, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e73c8:     	cmp	x13, #0x2
1005e73cc:     	b.eq	0x1005e749c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e73d0:     	ldrsb	w15, [x14, #0x2]
1005e73d4:     	tbnz	w15, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e73d8:     	cmp	x13, #0x3
1005e73dc:     	b.eq	0x1005e749c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e73e0:     	ldrsb	w15, [x14, #0x3]
1005e73e4:     	tbnz	w15, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e73e8:     	cmp	x13, #0x4
1005e73ec:     	b.eq	0x1005e749c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e73f0:     	ldrsb	w15, [x14, #0x4]
1005e73f4:     	tbnz	w15, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e73f8:     	cmp	x13, #0x5
1005e73fc:     	b.eq	0x1005e749c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e7400:     	ldrsb	w15, [x14, #0x5]
1005e7404:     	tbnz	w15, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7408:     	cmp	x13, #0x6
1005e740c:     	b.eq	0x1005e749c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e7410:     	ldrsb	w13, [x14, #0x6]
1005e7414:     	tbz	w13, #0x1f, 0x1005e749c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e7418:     	b	0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e741c:     	and	x13, x3, #0x7fffffffffffffc0
1005e7420:     	add	x13, x12, x13
1005e7424:     	mov	x14, x12
1005e7428:     	ldp	q0, q1, [x14]
1005e742c:     	ldp	q2, q3, [x14, #0x20]
1005e7430:     	orr.16b	v0, v1, v0
1005e7434:     	orr.16b	v1, v2, v3
1005e7438:     	orr.16b	v0, v0, v1
1005e743c:     	umaxv.16b	b0, v0
1005e7440:     	fmov	w15, s0
1005e7444:     	tbnz	w15, #0x7, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7448:     	add	x14, x14, #0x40
1005e744c:     	cmp	x14, x13
1005e7450:     	b.ne	0x1005e7428 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x108>
1005e7454:     	ands	x14, x3, #0x30
1005e7458:     	b.eq	0x1005e747c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x15c>
1005e745c:     	mov	x15, x14
1005e7460:     	mov	x16, x13
1005e7464:     	ldr	q0, [x16], #0x10
1005e7468:     	umaxv.16b	b0, v0
1005e746c:     	fmov	w17, s0
1005e7470:     	tbnz	w17, #0x7, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7474:     	subs	x15, x15, #0x10
1005e7478:     	b.ne	0x1005e7464 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x144>
1005e747c:     	and	x15, x3, #0xf
1005e7480:     	cbz	x15, 0x1005e749c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x17c>
1005e7484:     	add	x13, x13, x14
1005e7488:     	ldrsb	w14, [x13]
1005e748c:     	tbnz	w14, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7490:     	add	x13, x13, #0x1
1005e7494:     	subs	x15, x15, #0x1
1005e7498:     	b.ne	0x1005e7488 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x168>
1005e749c:     	add	x11, x12, x11
1005e74a0:     	cmp	x10, #0x40
1005e74a4:     	b.hs	0x1005e7570 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x250>
1005e74a8:     	ands	x12, x10, #0x38
1005e74ac:     	b.eq	0x1005e74d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x1b0>
1005e74b0:     	and	x13, x10, #0x38
1005e74b4:     	neg	x13, x13
1005e74b8:     	mov	x14, x11
1005e74bc:     	ldr	x15, [x14], #0x8
1005e74c0:     	tst	x15, #0x8080808080808080
1005e74c4:     	b.ne	0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e74c8:     	adds	x13, x13, #0x8
1005e74cc:     	b.ne	0x1005e74bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x19c>
1005e74d0:     	and	x10, x10, #0x7
1005e74d4:     	cbz	x10, 0x1005e75ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e74d8:     	add	x11, x11, x12
1005e74dc:     	ldrsb	w12, [x11]
1005e74e0:     	tbnz	w12, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e74e4:     	cmp	x10, #0x1
1005e74e8:     	b.eq	0x1005e75ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e74ec:     	ldrsb	w12, [x11, #0x1]
1005e74f0:     	tbnz	w12, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e74f4:     	cmp	x10, #0x2
1005e74f8:     	b.eq	0x1005e75ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e74fc:     	ldrsb	w12, [x11, #0x2]
1005e7500:     	tbnz	w12, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7504:     	cmp	x10, #0x3
1005e7508:     	b.eq	0x1005e75ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e750c:     	ldrsb	w12, [x11, #0x3]
1005e7510:     	tbnz	w12, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7514:     	cmp	x10, #0x4
1005e7518:     	b.eq	0x1005e75ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e751c:     	ldrsb	w12, [x11, #0x4]
1005e7520:     	tbnz	w12, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7524:     	cmp	x10, #0x5
1005e7528:     	b.eq	0x1005e75ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e752c:     	ldrsb	w12, [x11, #0x5]
1005e7530:     	tbnz	w12, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7534:     	cmp	x10, #0x6
1005e7538:     	b.eq	0x1005e75ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e753c:     	ldrsb	w10, [x11, #0x6]
1005e7540:     	tbz	w10, #0x1f, 0x1005e75ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e7544:     	b	0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7548:     	ldurb	w14, [x13, #-0x2]
1005e754c:     	cmp	w14, #0xdf
1005e7550:     	b.hi	0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7554:     	cmp	x1, #0x3
1005e7558:     	b.lo	0x1005e7374 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x54>
1005e755c:     	ldurb	w13, [x13, #-0x3]
1005e7560:     	cmp	w13, #0xef
1005e7564:     	b.ls	0x1005e7374 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x54>
1005e7568:     	mov	w0, #0x0                ; =0
1005e756c:     	ret
1005e7570:     	and	x12, x10, #0xffffffc0
1005e7574:     	add	x12, x11, x12
1005e7578:     	ldp	q0, q1, [x11]
1005e757c:     	ldp	q2, q3, [x11, #0x20]
1005e7580:     	orr.16b	v0, v1, v0
1005e7584:     	orr.16b	v1, v2, v3
1005e7588:     	orr.16b	v0, v0, v1
1005e758c:     	umaxv.16b	b0, v0
1005e7590:     	fmov	w13, s0
1005e7594:     	tbnz	w13, #0x7, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e7598:     	add	x11, x11, #0x40
1005e759c:     	cmp	x11, x12
1005e75a0:     	b.ne	0x1005e7578 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x258>
1005e75a4:     	ands	x11, x10, #0x30
1005e75a8:     	b.eq	0x1005e75cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2ac>
1005e75ac:     	mov	x13, x11
1005e75b0:     	mov	x14, x12
1005e75b4:     	ldr	q0, [x14], #0x10
1005e75b8:     	umaxv.16b	b0, v0
1005e75bc:     	fmov	w15, s0
1005e75c0:     	tbnz	w15, #0x7, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e75c4:     	subs	x13, x13, #0x10
1005e75c8:     	b.ne	0x1005e75b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x294>
1005e75cc:     	and	x10, x10, #0xf
1005e75d0:     	cbz	x10, 0x1005e75ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2cc>
1005e75d4:     	add	x11, x12, x11
1005e75d8:     	ldrsb	w12, [x11]
1005e75dc:     	tbnz	w12, #0x1f, 0x1005e7568 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x248>
1005e75e0:     	add	x11, x11, #0x1
1005e75e4:     	subs	x10, x10, #0x1
1005e75e8:     	b.ne	0x1005e75d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len+0x2b8>
1005e75ec:     	subs	w1, w9, w8
1005e75f0:     	cset	w0, hs
1005e75f4:     	ret
