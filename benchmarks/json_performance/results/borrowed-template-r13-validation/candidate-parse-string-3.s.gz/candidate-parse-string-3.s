
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/borrowed-template-r13/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010016fb10 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_>:
10016fb10:     	sub	sp, sp, #0x60
10016fb14:     	stp	x24, x23, [sp, #0x20]
10016fb18:     	stp	x22, x21, [sp, #0x30]
10016fb1c:     	stp	x20, x19, [sp, #0x40]
10016fb20:     	stp	x29, x30, [sp, #0x50]
10016fb24:     	add	x29, sp, #0x50
10016fb28:     	mov	x19, x2
10016fb2c:     	mov	x20, x1
10016fb30:     	mov	x21, x0
10016fb34:     	ldr	x8, [x0, #0x70]
10016fb38:     	cmp	x8, x2
10016fb3c:     	b.ls	0x10016fb68 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x58>
10016fb40:     	ldr	x2, [x21, #0xc8]
10016fb44:     	mvn	x9, x19
10016fb48:     	add	x3, x8, x9
10016fb4c:     	mov	x1, x19
10016fb50:     	bl	0x1005e7320 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction27json_source_token_utf16_len>
10016fb54:     	cmp	w0, #0x1
10016fb58:     	b.ne	0x10016fb68 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x58>
10016fb5c:     	mov	x22, x1
10016fb60:     	mov	x23, x19
10016fb64:     	b	0x10016fd00 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1f0>
10016fb68:     	cmp	x19, #0x40
10016fb6c:     	b.hs	0x10016fc78 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x168>
10016fb70:     	ands	x9, x19, #0x38
10016fb74:     	b.eq	0x10016fb98 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x88>
10016fb78:     	and	x8, x19, #0x38
10016fb7c:     	neg	x8, x8
10016fb80:     	mov	x10, x20
10016fb84:     	ldr	x11, [x10], #0x8
10016fb88:     	tst	x11, #0x8080808080808080
10016fb8c:     	b.ne	0x10016fc0c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016fb90:     	adds	x8, x8, #0x8
10016fb94:     	b.ne	0x10016fb84 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x74>
10016fb98:     	and	x8, x19, #0x7
10016fb9c:     	cbz	x8, 0x10016fcf8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e8>
10016fba0:     	add	x9, x20, x9
10016fba4:     	ldrsb	w10, [x9]
10016fba8:     	tbnz	w10, #0x1f, 0x10016fc0c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016fbac:     	cmp	x8, #0x1
10016fbb0:     	b.eq	0x10016fcf8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e8>
10016fbb4:     	ldrsb	w10, [x9, #0x1]
10016fbb8:     	tbnz	w10, #0x1f, 0x10016fc0c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016fbbc:     	cmp	x8, #0x2
10016fbc0:     	b.eq	0x10016fcf8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e8>
10016fbc4:     	ldrsb	w10, [x9, #0x2]
10016fbc8:     	tbnz	w10, #0x1f, 0x10016fc0c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016fbcc:     	cmp	x8, #0x3
10016fbd0:     	b.eq	0x10016fcf8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e8>
10016fbd4:     	ldrsb	w10, [x9, #0x3]
10016fbd8:     	tbnz	w10, #0x1f, 0x10016fc0c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016fbdc:     	cmp	x8, #0x4
10016fbe0:     	b.eq	0x10016fcf8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e8>
10016fbe4:     	ldrsb	w10, [x9, #0x4]
10016fbe8:     	tbnz	w10, #0x1f, 0x10016fc0c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016fbec:     	cmp	x8, #0x5
10016fbf0:     	b.eq	0x10016fcf8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e8>
10016fbf4:     	ldrsb	w10, [x9, #0x5]
10016fbf8:     	tbnz	w10, #0x1f, 0x10016fc0c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016fbfc:     	cmp	x8, #0x6
10016fc00:     	b.eq	0x10016fcf8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e8>
10016fc04:     	ldrsb	w8, [x9, #0x6]
10016fc08:     	tbz	w8, #0x1f, 0x10016fcf8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e8>
10016fc0c:     	cbz	w19, 0x10016fda8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x298>
10016fc10:     	mov	w23, w19
10016fc14:     	cbz	x23, 0x10016fcf8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e8>
10016fc18:     	mov	x8, x20
10016fc1c:     	ands	x9, x19, #0x3
10016fc20:     	b.eq	0x10016fc3c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x12c>
10016fc24:     	mov	x8, x20
10016fc28:     	ldrsb	w10, [x8]
10016fc2c:     	tbnz	w10, #0x1f, 0x10016fe48 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x338>
10016fc30:     	add	x8, x8, #0x1
10016fc34:     	subs	x9, x9, #0x1
10016fc38:     	b.ne	0x10016fc28 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x118>
10016fc3c:     	cmp	x23, #0x4
10016fc40:     	b.lo	0x10016fcf8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e8>
10016fc44:     	add	x9, x20, x23
10016fc48:     	ldrsb	w10, [x8]
10016fc4c:     	tbnz	w10, #0x1f, 0x10016fe48 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x338>
10016fc50:     	ldrsb	w10, [x8, #0x1]
10016fc54:     	tbnz	w10, #0x1f, 0x10016fe48 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x338>
10016fc58:     	ldrsb	w10, [x8, #0x2]
10016fc5c:     	tbnz	w10, #0x1f, 0x10016fe48 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x338>
10016fc60:     	ldrsb	w10, [x8, #0x3]
10016fc64:     	tbnz	w10, #0x1f, 0x10016fe48 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x338>
10016fc68:     	add	x8, x8, #0x4
10016fc6c:     	cmp	x8, x9
10016fc70:     	b.ne	0x10016fc48 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x138>
10016fc74:     	b	0x10016fcf8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e8>
10016fc78:     	and	x8, x19, #0x7fffffffffffffc0
10016fc7c:     	add	x8, x20, x8
10016fc80:     	mov	x9, x20
10016fc84:     	ldp	q0, q1, [x9]
10016fc88:     	ldp	q2, q3, [x9, #0x20]
10016fc8c:     	orr.16b	v0, v1, v0
10016fc90:     	orr.16b	v1, v2, v3
10016fc94:     	orr.16b	v0, v0, v1
10016fc98:     	umaxv.16b	b0, v0
10016fc9c:     	fmov	w10, s0
10016fca0:     	tbnz	w10, #0x7, 0x10016fc0c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016fca4:     	add	x9, x9, #0x40
10016fca8:     	cmp	x9, x8
10016fcac:     	b.ne	0x10016fc84 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x174>
10016fcb0:     	ands	x9, x19, #0x30
10016fcb4:     	b.eq	0x10016fcd8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1c8>
10016fcb8:     	mov	x10, x9
10016fcbc:     	mov	x11, x8
10016fcc0:     	ldr	q0, [x11], #0x10
10016fcc4:     	umaxv.16b	b0, v0
10016fcc8:     	fmov	w12, s0
10016fccc:     	tbnz	w12, #0x7, 0x10016fc0c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016fcd0:     	subs	x10, x10, #0x10
10016fcd4:     	b.ne	0x10016fcc0 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1b0>
10016fcd8:     	and	x10, x19, #0xf
10016fcdc:     	cbz	x10, 0x10016fcf8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e8>
10016fce0:     	add	x8, x8, x9
10016fce4:     	ldrsb	w9, [x8]
10016fce8:     	tbnz	w9, #0x1f, 0x10016fc0c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016fcec:     	add	x8, x8, #0x1
10016fcf0:     	subs	x10, x10, #0x1
10016fcf4:     	b.ne	0x10016fce4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1d4>
10016fcf8:     	mov	x23, x19
10016fcfc:     	mov	x22, x19
10016fd00:     	lsr	w8, w23, #19
10016fd04:     	cbz	w8, 0x10016fd98 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x288>
10016fd08:     	mov	w24, w19
10016fd0c:     	add	x0, x24, #0x14
10016fd10:     	mov	w1, #0x3                ; =3
10016fd14:     	bl	0x1004537c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
10016fd18:     	mov	x21, x0
10016fd1c:     	stp	w22, w23, [x0]
10016fd20:     	str	w23, [x0, #0x8]
10016fd24:     	mov	x8, #0x200000000        ; =8589934592
10016fd28:     	stur	x8, [x0, #0xc]
10016fd2c:     	add	x0, x0, #0x14
10016fd30:     	mov	x1, x20
10016fd34:     	mov	x2, x19
10016fd38:     	bl	0x100b5882c <_writev+0x100b5882c>
10016fd3c:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
10016fd40:     	ldr	w19, [x8, #0x590]
10016fd44:     	cmp	w19, #0x300
10016fd48:     	b.hs	0x10016ff60 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x450>
10016fd4c:     	adrp	x8, 0x100f74000 <_perry_global_rotating_worker_ts__1>
10016fd50:     	ldr	x8, [x8, #0x48]
10016fd54:     	cmn	x8, #0x1
10016fd58:     	b.eq	0x10016ff50 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x440>
10016fd5c:     	mrs	x9, TPIDRRO_EL0
10016fd60:     	and	x9, x9, #0xfffffffffffffff8
10016fd64:     	ldr	x0, [x9, x8, lsl #3]
10016fd68:     	cbz	x0, 0x10016ff50 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x440>
10016fd6c:     	add	x8, x0, x19, lsl #3
10016fd70:     	ldr	x0, [x8, #0x1e8]
10016fd74:     	cbz	x0, 0x10016ff60 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x450>
10016fd78:     	ldr	x8, [x0]
10016fd7c:     	adds	x8, x8, x24
10016fd80:     	csinv	x8, x8, xzr, lo
10016fd84:     	str	x8, [x0]
10016fd88:     	lsr	x8, x8, #25
10016fd8c:     	cbz	x8, 0x10016fe2c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x31c>
10016fd90:     	bl	0x10045a8f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
10016fd94:     	b	0x10016fe2c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x31c>
10016fd98:     	add	x8, x19, #0x14
10016fd9c:     	ldr	x9, [x21, #0x20]
10016fda0:     	cbnz	x9, 0x10016fdc0 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2b0>
10016fda4:     	b	0x10016fe00 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f0>
10016fda8:     	mov	w22, #0x0               ; =0
10016fdac:     	mov	w23, #0x0               ; =0
10016fdb0:     	mov	w8, #0x14               ; =20
10016fdb4:     	orr	x8, x19, x8
10016fdb8:     	ldr	x9, [x21, #0x20]
10016fdbc:     	cbz	x9, 0x10016fe00 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f0>
10016fdc0:     	add	x9, x19, #0x23
10016fdc4:     	and	x9, x9, #0x7ffffffffffffff8
10016fdc8:     	and	x9, x9, #0xffffffff000fffff
10016fdcc:     	cmp	x9, #0x4, lsl #12       ; =0x4000
10016fdd0:     	b.hi	0x10016fe00 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f0>
10016fdd4:     	ldr	x10, [x21, #0x30]
10016fdd8:     	ldrb	w10, [x10]
10016fddc:     	tbnz	w10, #0x0, 0x10016fe00 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f0>
10016fde0:     	ldr	x10, [x21, #0x28]
10016fde4:     	ldp	x11, x12, [x10, #0x8]
10016fde8:     	add	x11, x11, #0x7
10016fdec:     	and	x11, x11, #0xfffffffffffffff8
10016fdf0:     	subs	x12, x12, x11
10016fdf4:     	csel	x12, xzr, x12, lo
10016fdf8:     	cmp	x9, x12
10016fdfc:     	b.ls	0x10016feec <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x3dc>
10016fe00:     	mov	x0, x23
10016fe04:     	bl	0x1003464ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10016fe08:     	mov	x21, x0
10016fe0c:     	mov	x0, x1
10016fe10:     	stp	w22, w23, [x21]
10016fe14:     	str	w23, [x21, #0x8]
10016fe18:     	mov	x8, #0x200000000        ; =8589934592
10016fe1c:     	stur	x8, [x21, #0xc]
10016fe20:     	mov	x1, x20
10016fe24:     	mov	x2, x19
10016fe28:     	bl	0x100b5882c <_writev+0x100b5882c>
10016fe2c:     	mov	x0, x21
10016fe30:     	ldp	x29, x30, [sp, #0x50]
10016fe34:     	ldp	x20, x19, [sp, #0x40]
10016fe38:     	ldp	x22, x21, [sp, #0x30]
10016fe3c:     	ldp	x24, x23, [sp, #0x20]
10016fe40:     	add	sp, sp, #0x60
10016fe44:     	ret
10016fe48:     	cmp	w19, #0x3f
10016fe4c:     	b.ls	0x10016fe68 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x358>
10016fe50:     	mov	x0, x20
10016fe54:     	mov	x1, x23
10016fe58:     	bl	0x1005e6d60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
10016fe5c:     	mov	x22, x0
10016fe60:     	mov	x23, x19
10016fe64:     	b	0x10016fd00 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1f0>
10016fe68:     	add	x8, sp, #0x8
10016fe6c:     	mov	x0, x20
10016fe70:     	mov	x1, x23
10016fe74:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10016fe78:     	ldr	x8, [sp, #0x8]
10016fe7c:     	cbz	x8, 0x10016ff30 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x420>
10016fe80:     	mov	w22, #0x0               ; =0
10016fe84:     	mov	x8, #0x0                ; =0
10016fe88:     	mov	w9, #0x2                ; =2
10016fe8c:     	mov	w10, #0x3               ; =3
10016fe90:     	mov	w11, #0x4               ; =4
10016fe94:     	b	0x10016feac <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x39c>
10016fe98:     	add	w22, w22, #0x1
10016fe9c:     	mov	w12, #0x1               ; =1
10016fea0:     	add	x8, x12, x8
10016fea4:     	cmp	x8, x23
10016fea8:     	b.hs	0x1001702b4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x7a4>
10016feac:     	ldrsb	w12, [x20, x8]
10016feb0:     	tbz	w12, #0x1f, 0x10016fe98 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x388>
10016feb4:     	and	w12, w12, #0xff
10016feb8:     	cmp	w12, #0xc0
10016febc:     	b.lo	0x10016fe9c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x38c>
10016fec0:     	cmp	w12, #0xf0
10016fec4:     	add	w13, w22, #0x2
10016fec8:     	csel	x14, x10, x11, lo
10016fecc:     	csinc	w13, w13, w22, hs
10016fed0:     	cmp	w12, #0xe0
10016fed4:     	csel	x12, x9, x14, lo
10016fed8:     	csinc	w22, w13, w22, hs
10016fedc:     	add	x8, x12, x8
10016fee0:     	cmp	x8, x23
10016fee4:     	b.lo	0x10016feac <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x39c>
10016fee8:     	b	0x1001702b4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x7a4>
10016feec:     	ldr	x12, [x10]
10016fef0:     	add	x24, x12, x11
10016fef4:     	add	x11, x11, x9
10016fef8:     	str	x11, [x10, #0x8]
10016fefc:     	mov	w10, #0x203             ; =515
10016ff00:     	stp	w10, w9, [x24]
10016ff04:     	add	x21, x24, #0x8
10016ff08:     	subs	x9, x9, #0x8
10016ff0c:     	csel	x9, xzr, x9, lo
10016ff10:     	subs	x10, x9, x8
10016ff14:     	csel	x1, xzr, x10, lo
10016ff18:     	b.ls	0x10016ff9c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x48c>
10016ff1c:     	cmp	x1, #0x9
10016ff20:     	b.hs	0x10016ff94 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x484>
10016ff24:     	add	x8, x21, x9
10016ff28:     	stur	xzr, [x8, #-0x8]
10016ff2c:     	b	0x10016ff9c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x48c>
10016ff30:     	ldr	x8, [sp, #0x18]
10016ff34:     	cbz	x8, 0x10016ff88 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x478>
10016ff38:     	ldr	x9, [sp, #0x10]
10016ff3c:     	cmp	x8, #0x8
10016ff40:     	b.hs	0x10016ffb4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x4a4>
10016ff44:     	mov	x10, #0x0               ; =0
10016ff48:     	mov	w22, #0x0               ; =0
10016ff4c:     	b	0x10017027c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x76c>
10016ff50:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10016ff54:     	add	x8, x0, x19, lsl #3
10016ff58:     	ldr	x0, [x8, #0x1e8]
10016ff5c:     	cbnz	x0, 0x10016fd78 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x268>
10016ff60:     	adrp	x0, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
10016ff64:     	add	x0, x0, #0x90
10016ff68:     	bl	0x100b3359c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10016ff6c:     	ldr	x8, [x0]
10016ff70:     	adds	x8, x8, x24
10016ff74:     	csinv	x8, x8, xzr, lo
10016ff78:     	str	x8, [x0]
10016ff7c:     	lsr	x8, x8, #25
10016ff80:     	cbnz	x8, 0x10016fd90 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x280>
10016ff84:     	b	0x10016fe2c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x31c>
10016ff88:     	mov	w22, #0x0               ; =0
10016ff8c:     	mov	x23, x19
10016ff90:     	b	0x10016fd00 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1f0>
10016ff94:     	add	x0, x21, x8
10016ff98:     	bl	0x100b58364 <_writev+0x100b58364>
10016ff9c:     	stp	w22, w23, [x24, #0x8]
10016ffa0:     	str	w23, [x24, #0x10]
10016ffa4:     	mov	x8, #0x200000000        ; =8589934592
10016ffa8:     	stur	x8, [x24, #0x14]
10016ffac:     	add	x0, x24, #0x1c
10016ffb0:     	b	0x10016fe20 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x310>
10016ffb4:     	cmp	x8, #0x20
10016ffb8:     	b.hs	0x10016ffc8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x4b8>
10016ffbc:     	mov	x10, #0x0               ; =0
10016ffc0:     	mov	w22, #0x0               ; =0
10016ffc4:     	b	0x1001701cc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x6bc>
10016ffc8:     	movi.2d	v0, #0000000000000000
10016ffcc:     	and	x11, x8, #0x18
10016ffd0:     	movi.16b	v1, #0xf0
10016ffd4:     	and	x10, x8, #0xffffffffffffffe0
10016ffd8:     	movi.4s	v2, #0x2
10016ffdc:     	add	x12, x9, #0x10
10016ffe0:     	movi.16b	v4, #0xc0
10016ffe4:     	and	x13, x8, #0xffffffffffffffe0
10016ffe8:     	movi.2d	v3, #0000000000000000
10016ffec:     	movi.2d	v6, #0000000000000000
10016fff0:     	movi.2d	v5, #0000000000000000
10016fff4:     	movi.2d	v7, #0000000000000000
10016fff8:     	movi.2d	v16, #0000000000000000
10016fffc:     	movi.2d	v17, #0000000000000000
100170000:     	movi.2d	v18, #0000000000000000
100170004:     	ldp	q20, q19, [x12, #-0x10]
100170008:     	cmhi.16b	v21, v1, v20
10017000c:     	sshll2.8h	v22, v21, #0x0
100170010:     	sshll2.4s	v23, v22, #0x0
100170014:     	sshll.4s	v24, v22, #0x0
100170018:     	sshll.8h	v21, v21, #0x0
10017001c:     	sshll2.4s	v25, v21, #0x0
100170020:     	sshll.4s	v26, v21, #0x0
100170024:     	cmhi.16b	v27, v1, v19
100170028:     	sshll2.8h	v28, v27, #0x0
10017002c:     	sshll2.4s	v29, v28, #0x0
100170030:     	sshll.4s	v30, v28, #0x0
100170034:     	sshll.8h	v27, v27, #0x0
100170038:     	sshll2.4s	v31, v27, #0x0
10017003c:     	bic.16b	v26, v2, v26
100170040:     	ssubw.4s	v26, v26, v21
100170044:     	bic.16b	v25, v2, v25
100170048:     	ssubw2.4s	v25, v25, v21
10017004c:     	sshll.4s	v21, v27, #0x0
100170050:     	bic.16b	v24, v2, v24
100170054:     	ssubw.4s	v24, v24, v22
100170058:     	bic.16b	v23, v2, v23
10017005c:     	ssubw2.4s	v22, v23, v22
100170060:     	bic.16b	v21, v2, v21
100170064:     	ssubw.4s	v21, v21, v27
100170068:     	bic.16b	v23, v2, v31
10017006c:     	ssubw2.4s	v23, v23, v27
100170070:     	bic.16b	v27, v2, v30
100170074:     	ssubw.4s	v27, v27, v28
100170078:     	bic.16b	v29, v2, v29
10017007c:     	ssubw2.4s	v28, v29, v28
100170080:     	cmgt.16b	v29, v4, v20
100170084:     	sshll2.8h	v30, v29, #0x0
100170088:     	ushll2.4s	v31, v30, #0x0
10017008c:     	bic.16b	v22, v22, v31
100170090:     	cmlt.16b	v20, v20, #0
100170094:     	sshll.8h	v29, v29, #0x0
100170098:     	ushll.4s	v30, v30, #0x0
10017009c:     	bic.16b	v24, v24, v30
1001700a0:     	ushll2.4s	v30, v29, #0x0
1001700a4:     	bic.16b	v25, v25, v30
1001700a8:     	sshll2.8h	v30, v20, #0x0
1001700ac:     	sshll.8h	v20, v20, #0x0
1001700b0:     	ushll.4s	v29, v29, #0x0
1001700b4:     	bic.16b	v26, v26, v29
1001700b8:     	sshll.4s	v29, v20, #0x0
1001700bc:     	and.16b	v26, v26, v29
1001700c0:     	mvn.16b	v29, v29
1001700c4:     	sub.4s	v26, v26, v29
1001700c8:     	sshll2.4s	v29, v30, #0x0
1001700cc:     	sshll.4s	v30, v30, #0x0
1001700d0:     	sshll2.4s	v20, v20, #0x0
1001700d4:     	and.16b	v25, v25, v20
1001700d8:     	mvn.16b	v20, v20
1001700dc:     	sub.4s	v20, v25, v20
1001700e0:     	cmgt.16b	v25, v4, v19
1001700e4:     	and.16b	v24, v24, v30
1001700e8:     	mvn.16b	v30, v30
1001700ec:     	sub.4s	v24, v24, v30
1001700f0:     	sshll2.8h	v30, v25, #0x0
1001700f4:     	and.16b	v22, v22, v29
1001700f8:     	mvn.16b	v29, v29
1001700fc:     	sub.4s	v22, v22, v29
100170100:     	ushll2.4s	v29, v30, #0x0
100170104:     	bic.16b	v28, v28, v29
100170108:     	cmlt.16b	v19, v19, #0
10017010c:     	sshll.8h	v25, v25, #0x0
100170110:     	ushll.4s	v29, v30, #0x0
100170114:     	bic.16b	v27, v27, v29
100170118:     	ushll2.4s	v29, v25, #0x0
10017011c:     	bic.16b	v23, v23, v29
100170120:     	sshll.8h	v29, v19, #0x0
100170124:     	ushll.4s	v25, v25, #0x0
100170128:     	bic.16b	v21, v21, v25
10017012c:     	sshll.4s	v25, v29, #0x0
100170130:     	and.16b	v21, v21, v25
100170134:     	mvn.16b	v25, v25
100170138:     	sub.4s	v21, v21, v25
10017013c:     	sshll2.8h	v19, v19, #0x0
100170140:     	sshll2.4s	v25, v29, #0x0
100170144:     	and.16b	v23, v23, v25
100170148:     	mvn.16b	v25, v25
10017014c:     	sub.4s	v23, v23, v25
100170150:     	sshll.4s	v25, v19, #0x0
100170154:     	and.16b	v27, v27, v25
100170158:     	mvn.16b	v25, v25
10017015c:     	sub.4s	v25, v27, v25
100170160:     	sshll2.4s	v19, v19, #0x0
100170164:     	and.16b	v27, v28, v19
100170168:     	mvn.16b	v19, v19
10017016c:     	sub.4s	v19, v27, v19
100170170:     	add.4s	v7, v22, v7
100170174:     	add.4s	v5, v24, v5
100170178:     	add.4s	v6, v20, v6
10017017c:     	add.4s	v3, v26, v3
100170180:     	add.4s	v18, v19, v18
100170184:     	add.4s	v17, v25, v17
100170188:     	add.4s	v0, v23, v0
10017018c:     	add.4s	v16, v21, v16
100170190:     	add	x12, x12, #0x20
100170194:     	subs	x13, x13, #0x20
100170198:     	b.ne	0x100170004 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x4f4>
10017019c:     	add.4s	v0, v0, v6
1001701a0:     	add.4s	v1, v18, v7
1001701a4:     	add.4s	v2, v16, v3
1001701a8:     	add.4s	v3, v17, v5
1001701ac:     	add.4s	v2, v2, v3
1001701b0:     	add.4s	v0, v0, v1
1001701b4:     	add.4s	v0, v2, v0
1001701b8:     	addv.4s	s0, v0
1001701bc:     	fmov	w22, s0
1001701c0:     	cmp	x8, x10
1001701c4:     	b.eq	0x1001702b4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x7a4>
1001701c8:     	cbz	x11, 0x10017027c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x76c>
1001701cc:     	mov	x12, x10
1001701d0:     	and	x10, x8, #0xfffffffffffffff8
1001701d4:     	movi.2d	v0, #0000000000000000
1001701d8:     	mov.s	v0[0], w22
1001701dc:     	movi.2d	v1, #0000000000000000
1001701e0:     	sub	x11, x12, x10
1001701e4:     	add	x12, x9, x12
1001701e8:     	movi.8b	v2, #0xf0
1001701ec:     	movi.4s	v3, #0x2
1001701f0:     	movi.8b	v4, #0xc0
1001701f4:     	ldr	d5, [x12], #0x8
1001701f8:     	sshll.8h	v6, v5, #0x0
1001701fc:     	cmlt.8h	v6, v6, #0
100170200:     	sshll2.4s	v7, v6, #0x0
100170204:     	sshll.4s	v6, v6, #0x0
100170208:     	cmhi.8b	v16, v2, v5
10017020c:     	sshll.8h	v16, v16, #0x0
100170210:     	sshll2.4s	v17, v16, #0x0
100170214:     	sshll.4s	v18, v16, #0x0
100170218:     	bic.16b	v18, v3, v18
10017021c:     	ssubw.4s	v18, v18, v16
100170220:     	bic.16b	v17, v3, v17
100170224:     	ssubw2.4s	v16, v17, v16
100170228:     	cmgt.8b	v5, v4, v5
10017022c:     	sshll.8h	v5, v5, #0x0
100170230:     	ushll.4s	v17, v5, #0x0
100170234:     	ushll2.4s	v5, v5, #0x0
100170238:     	bic.16b	v5, v16, v5
10017023c:     	bic.16b	v16, v18, v17
100170240:     	and.16b	v16, v16, v6
100170244:     	mvn.16b	v6, v6
100170248:     	sub.4s	v6, v16, v6
10017024c:     	and.16b	v5, v5, v7
100170250:     	mvn.16b	v7, v7
100170254:     	sub.4s	v5, v5, v7
100170258:     	add.4s	v1, v5, v1
10017025c:     	add.4s	v0, v6, v0
100170260:     	adds	x11, x11, #0x8
100170264:     	b.ne	0x1001701f4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x6e4>
100170268:     	add.4s	v0, v0, v1
10017026c:     	addv.4s	s0, v0
100170270:     	fmov	w22, s0
100170274:     	cmp	x8, x10
100170278:     	b.eq	0x1001702b4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x7a4>
10017027c:     	sub	x8, x8, x10
100170280:     	add	x9, x9, x10
100170284:     	mov	w10, #0x1               ; =1
100170288:     	ldrsb	w11, [x9], #0x1
10017028c:     	and	w12, w11, #0xff
100170290:     	cmp	w12, #0xf0
100170294:     	cinc	w13, w10, hs
100170298:     	cmp	w12, #0xc0
10017029c:     	csel	w12, wzr, w13, lo
1001702a0:     	tst	w11, #0x80000000
1001702a4:     	csinc	w11, w12, wzr, ne
1001702a8:     	add	w22, w11, w22
1001702ac:     	subs	x8, x8, #0x1
1001702b0:     	b.ne	0x100170288 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x778>
1001702b4:     	mov	x23, x19
1001702b8:     	b	0x10016fd00 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1f0>
1001702bc:     	nop
