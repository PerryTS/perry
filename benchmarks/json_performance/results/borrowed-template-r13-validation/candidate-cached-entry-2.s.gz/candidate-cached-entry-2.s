
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/borrowed-template-r13/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010083ba84 <_js_json_parse>:
10083ba84:     	stp	x29, x30, [sp, #-0x10]!
10083ba88:     	mov	x29, sp
10083ba8c:     	cbz	x0, 0x10083bae4 <_js_json_parse+0x60>
10083ba90:     	ldr	w1, [x0, #0x4]
10083ba94:     	cmp	w1, #0x2
10083ba98:     	b.eq	0x10083baa8 <_js_json_parse+0x24>
10083ba9c:     	cbz	w1, 0x10083bae4 <_js_json_parse+0x60>
10083baa0:     	ldrb	w8, [x0, #0x14]
10083baa4:     	b	0x10083bac8 <_js_json_parse+0x44>
10083baa8:     	ldrb	w8, [x0, #0x14]
10083baac:     	cmp	w8, #0x7b
10083bab0:     	b.ne	0x10083bac8 <_js_json_parse+0x44>
10083bab4:     	ldrb	w8, [x0, #0x15]
10083bab8:     	cmp	w8, #0x7d
10083babc:     	b.ne	0x10083bad4 <_js_json_parse+0x50>
10083bac0:     	ldp	x29, x30, [sp], #0x10
10083bac4:     	b	0x1004e7040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
10083bac8:     	orr	w8, w8, #0x20
10083bacc:     	cmp	w8, #0x7b
10083bad0:     	b.ne	0x10083badc <_js_json_parse+0x58>
10083bad4:     	ldp	x29, x30, [sp], #0x10
10083bad8:     	b	0x100500af8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
10083badc:     	ldp	x29, x30, [sp], #0x10
10083bae0:     	b	0x10050341c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
10083bae4:     	adrp	x0, 0x100c6b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x651c>
10083bae8:     	add	x0, x0, #0xfc1
10083baec:     	mov	w1, #0x1c               ; =28
10083baf0:     	bl	0x100503850 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
