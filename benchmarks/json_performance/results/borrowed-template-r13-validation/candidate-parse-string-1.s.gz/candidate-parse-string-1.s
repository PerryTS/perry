
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/borrowed-template-r13/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010016ec7c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_>:
10016ec7c:     	sub	sp, sp, #0x60
10016ec80:     	stp	x24, x23, [sp, #0x20]
10016ec84:     	stp	x22, x21, [sp, #0x30]
10016ec88:     	stp	x20, x19, [sp, #0x40]
10016ec8c:     	stp	x29, x30, [sp, #0x50]
10016ec90:     	add	x29, sp, #0x50
10016ec94:     	lsr	w8, w2, #19
10016ec98:     	cbz	w8, 0x10016ecb4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x38>
10016ec9c:     	ldp	x29, x30, [sp, #0x50]
10016eca0:     	ldp	x20, x19, [sp, #0x40]
10016eca4:     	ldp	x22, x21, [sp, #0x30]
10016eca8:     	ldp	x24, x23, [sp, #0x20]
10016ecac:     	add	sp, sp, #0x60
10016ecb0:     	b	0x10016fb10 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction28string_from_json_large_bytesNtNtNtB6_4json6parser12DirectParserEB6_>
10016ecb4:     	cmp	x2, #0x40
10016ecb8:     	b.hs	0x10016edec <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x170>
10016ecbc:     	ands	x8, x2, #0x38
10016ecc0:     	b.eq	0x10016ece4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x68>
10016ecc4:     	and	x9, x2, #0x38
10016ecc8:     	neg	x9, x9
10016eccc:     	mov	x10, x1
10016ecd0:     	ldr	x11, [x10], #0x8
10016ecd4:     	tst	x11, #0x8080808080808080
10016ecd8:     	b.ne	0x10016ed78 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016ecdc:     	adds	x9, x9, #0x8
10016ece0:     	b.ne	0x10016ecd0 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x54>
10016ece4:     	mov	x19, x2
10016ece8:     	and	x9, x2, #0x7
10016ecec:     	cbz	x9, 0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ecf0:     	add	x8, x1, x8
10016ecf4:     	ldrsb	w10, [x8]
10016ecf8:     	tbnz	w10, #0x1f, 0x10016ed78 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016ecfc:     	mov	x19, x2
10016ed00:     	cmp	x9, #0x1
10016ed04:     	b.eq	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ed08:     	ldrsb	w10, [x8, #0x1]
10016ed0c:     	tbnz	w10, #0x1f, 0x10016ed78 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016ed10:     	mov	x19, x2
10016ed14:     	cmp	x9, #0x2
10016ed18:     	b.eq	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ed1c:     	ldrsb	w10, [x8, #0x2]
10016ed20:     	tbnz	w10, #0x1f, 0x10016ed78 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016ed24:     	mov	x19, x2
10016ed28:     	cmp	x9, #0x3
10016ed2c:     	b.eq	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ed30:     	ldrsb	w10, [x8, #0x3]
10016ed34:     	tbnz	w10, #0x1f, 0x10016ed78 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016ed38:     	mov	x19, x2
10016ed3c:     	cmp	x9, #0x4
10016ed40:     	b.eq	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ed44:     	ldrsb	w10, [x8, #0x4]
10016ed48:     	tbnz	w10, #0x1f, 0x10016ed78 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016ed4c:     	mov	x19, x2
10016ed50:     	cmp	x9, #0x5
10016ed54:     	b.eq	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ed58:     	ldrsb	w10, [x8, #0x5]
10016ed5c:     	tbnz	w10, #0x1f, 0x10016ed78 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016ed60:     	mov	x19, x2
10016ed64:     	cmp	x9, #0x6
10016ed68:     	b.eq	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ed6c:     	ldrsb	w8, [x8, #0x6]
10016ed70:     	mov	x19, x2
10016ed74:     	tbz	w8, #0x1f, 0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ed78:     	cbz	w2, 0x10016ef70 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f4>
10016ed7c:     	mov	x19, x2
10016ed80:     	ands	x20, x2, #0x7ffff
10016ed84:     	b.eq	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ed88:     	mov	x8, x1
10016ed8c:     	ands	x9, x2, #0x3
10016ed90:     	b.eq	0x10016edac <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x130>
10016ed94:     	mov	x8, x1
10016ed98:     	ldrsb	w10, [x8]
10016ed9c:     	tbnz	w10, #0x1f, 0x10016ee7c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x200>
10016eda0:     	add	x8, x8, #0x1
10016eda4:     	subs	x9, x9, #0x1
10016eda8:     	b.ne	0x10016ed98 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x11c>
10016edac:     	mov	x19, x2
10016edb0:     	cmp	x20, #0x4
10016edb4:     	b.lo	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016edb8:     	add	x9, x1, x20
10016edbc:     	ldrsb	w10, [x8]
10016edc0:     	tbnz	w10, #0x1f, 0x10016ee7c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x200>
10016edc4:     	ldrsb	w10, [x8, #0x1]
10016edc8:     	tbnz	w10, #0x1f, 0x10016ee7c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x200>
10016edcc:     	ldrsb	w10, [x8, #0x2]
10016edd0:     	tbnz	w10, #0x1f, 0x10016ee7c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x200>
10016edd4:     	ldrsb	w10, [x8, #0x3]
10016edd8:     	tbnz	w10, #0x1f, 0x10016ee7c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x200>
10016eddc:     	add	x8, x8, #0x4
10016ede0:     	cmp	x8, x9
10016ede4:     	b.ne	0x10016edbc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x140>
10016ede8:     	b	0x10016ee74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1f8>
10016edec:     	and	x8, x2, #0x7fffffffffffffc0
10016edf0:     	and	x8, x8, #0xffffffff0007ffff
10016edf4:     	add	x8, x1, x8
10016edf8:     	mov	x9, x1
10016edfc:     	ldp	q0, q1, [x9]
10016ee00:     	ldp	q2, q3, [x9, #0x20]
10016ee04:     	orr.16b	v0, v1, v0
10016ee08:     	orr.16b	v1, v2, v3
10016ee0c:     	orr.16b	v0, v0, v1
10016ee10:     	umaxv.16b	b0, v0
10016ee14:     	fmov	w10, s0
10016ee18:     	tbnz	w10, #0x7, 0x10016ed78 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016ee1c:     	add	x9, x9, #0x40
10016ee20:     	cmp	x9, x8
10016ee24:     	b.ne	0x10016edfc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x180>
10016ee28:     	ands	x9, x2, #0x30
10016ee2c:     	b.eq	0x10016ee50 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1d4>
10016ee30:     	mov	x10, x9
10016ee34:     	mov	x11, x8
10016ee38:     	ldr	q0, [x11], #0x10
10016ee3c:     	umaxv.16b	b0, v0
10016ee40:     	fmov	w12, s0
10016ee44:     	tbnz	w12, #0x7, 0x10016ed78 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016ee48:     	subs	x10, x10, #0x10
10016ee4c:     	b.ne	0x10016ee38 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1bc>
10016ee50:     	mov	x19, x2
10016ee54:     	and	x10, x2, #0xf
10016ee58:     	cbz	x10, 0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ee5c:     	add	x8, x8, x9
10016ee60:     	ldrsb	w9, [x8]
10016ee64:     	tbnz	w9, #0x1f, 0x10016ed78 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0xfc>
10016ee68:     	add	x8, x8, #0x1
10016ee6c:     	subs	x10, x10, #0x1
10016ee70:     	b.ne	0x10016ee60 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x1e4>
10016ee74:     	mov	x19, x2
10016ee78:     	b	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ee7c:     	mov	x21, x0
10016ee80:     	mov	x22, x2
10016ee84:     	cmp	w2, #0x3f
10016ee88:     	b.ls	0x10016eeb0 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x234>
10016ee8c:     	mov	x0, x1
10016ee90:     	mov	x19, x1
10016ee94:     	mov	x1, x20
10016ee98:     	bl	0x1005e6d60 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
10016ee9c:     	mov	x1, x19
10016eea0:     	mov	x19, x0
10016eea4:     	mov	x2, x22
10016eea8:     	mov	x0, x21
10016eeac:     	b	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016eeb0:     	add	x8, sp, #0x8
10016eeb4:     	mov	x23, x1
10016eeb8:     	mov	x0, x1
10016eebc:     	mov	x1, x20
10016eec0:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10016eec4:     	ldr	x8, [sp, #0x8]
10016eec8:     	cbz	x8, 0x10016ef44 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2c8>
10016eecc:     	mov	w19, #0x0               ; =0
10016eed0:     	mov	x8, #0x0                ; =0
10016eed4:     	mov	w9, #0x2                ; =2
10016eed8:     	mov	w10, #0x3               ; =3
10016eedc:     	mov	w11, #0x4               ; =4
10016eee0:     	mov	x2, x22
10016eee4:     	mov	x1, x23
10016eee8:     	mov	x0, x21
10016eeec:     	b	0x10016ef04 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x288>
10016eef0:     	add	w19, w19, #0x1
10016eef4:     	mov	w12, #0x1               ; =1
10016eef8:     	add	x8, x12, x8
10016eefc:     	cmp	x8, x20
10016ef00:     	b.hs	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ef04:     	ldrsb	w12, [x1, x8]
10016ef08:     	tbz	w12, #0x1f, 0x10016eef0 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x274>
10016ef0c:     	and	w12, w12, #0xff
10016ef10:     	cmp	w12, #0xc0
10016ef14:     	b.lo	0x10016eef4 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x278>
10016ef18:     	cmp	w12, #0xf0
10016ef1c:     	add	w13, w19, #0x2
10016ef20:     	csel	x14, x10, x11, lo
10016ef24:     	csinc	w13, w13, w19, hs
10016ef28:     	cmp	w12, #0xe0
10016ef2c:     	csel	x12, x9, x14, lo
10016ef30:     	csinc	w19, w13, w19, hs
10016ef34:     	add	x8, x12, x8
10016ef38:     	cmp	x8, x20
10016ef3c:     	b.lo	0x10016ef04 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x288>
10016ef40:     	b	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016ef44:     	ldr	x8, [sp, #0x18]
10016ef48:     	mov	x2, x22
10016ef4c:     	mov	x1, x23
10016ef50:     	mov	x0, x21
10016ef54:     	cbz	x8, 0x10016ef70 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f4>
10016ef58:     	ldr	x9, [sp, #0x10]
10016ef5c:     	cmp	x8, #0x8
10016ef60:     	b.hs	0x10016f088 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x40c>
10016ef64:     	mov	x10, #0x0               ; =0
10016ef68:     	mov	w19, #0x0               ; =0
10016ef6c:     	b	0x10016f350 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x6d4>
10016ef70:     	mov	w19, #0x0               ; =0
10016ef74:     	ldr	x8, [x0, #0x20]
10016ef78:     	cbz	x8, 0x10016efbc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x340>
10016ef7c:     	add	x8, x2, #0x23
10016ef80:     	and	x8, x8, #0x7ffffffffffffff8
10016ef84:     	and	x8, x8, #0xffffffff000fffff
10016ef88:     	cmp	x8, #0x4, lsl #12       ; =0x4000
10016ef8c:     	b.hi	0x10016efbc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x340>
10016ef90:     	ldr	x9, [x0, #0x30]
10016ef94:     	ldrb	w9, [x9]
10016ef98:     	tbnz	w9, #0x0, 0x10016efbc <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x340>
10016ef9c:     	ldr	x10, [x0, #0x28]
10016efa0:     	ldp	x9, x12, [x10, #0x8]
10016efa4:     	add	x9, x9, #0x7
10016efa8:     	and	x11, x9, #0xfffffffffffffff8
10016efac:     	subs	x9, x12, x11
10016efb0:     	csel	x9, xzr, x9, lo
10016efb4:     	cmp	x8, x9
10016efb8:     	b.ls	0x10016f00c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x390>
10016efbc:     	mov	x0, x2
10016efc0:     	mov	x21, x2
10016efc4:     	mov	x22, x1
10016efc8:     	bl	0x1003464ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10016efcc:     	mov	x20, x0
10016efd0:     	mov	x0, x1
10016efd4:     	stp	w19, w21, [x20]
10016efd8:     	str	w21, [x20, #0x8]
10016efdc:     	mov	x8, #0x200000000        ; =8589934592
10016efe0:     	stur	x8, [x20, #0xc]
10016efe4:     	mov	x1, x22
10016efe8:     	mov	x2, x21
10016efec:     	bl	0x100b5882c <_writev+0x100b5882c>
10016eff0:     	mov	x0, x20
10016eff4:     	ldp	x29, x30, [sp, #0x50]
10016eff8:     	ldp	x20, x19, [sp, #0x40]
10016effc:     	ldp	x22, x21, [sp, #0x30]
10016f000:     	ldp	x24, x23, [sp, #0x20]
10016f004:     	add	sp, sp, #0x60
10016f008:     	ret
10016f00c:     	add	x9, x2, #0x14
10016f010:     	ldr	x12, [x10]
10016f014:     	add	x21, x12, x11
10016f018:     	add	x11, x11, x8
10016f01c:     	str	x11, [x10, #0x8]
10016f020:     	mov	w10, #0x203             ; =515
10016f024:     	stp	w10, w8, [x21]
10016f028:     	add	x20, x21, #0x8
10016f02c:     	subs	x8, x8, #0x8
10016f030:     	csel	x10, xzr, x8, lo
10016f034:     	subs	x8, x10, x9
10016f038:     	csel	x8, xzr, x8, lo
10016f03c:     	b.ls	0x10016f070 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x3f4>
10016f040:     	cmp	x8, #0x9
10016f044:     	b.hs	0x10016f054 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x3d8>
10016f048:     	add	x8, x20, x10
10016f04c:     	stur	xzr, [x8, #-0x8]
10016f050:     	b	0x10016f070 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x3f4>
10016f054:     	add	x0, x20, x9
10016f058:     	mov	x22, x1
10016f05c:     	mov	x1, x8
10016f060:     	mov	x23, x2
10016f064:     	bl	0x100b58364 <_writev+0x100b58364>
10016f068:     	mov	x1, x22
10016f06c:     	mov	x2, x23
10016f070:     	stp	w19, w2, [x21, #0x8]
10016f074:     	str	w2, [x21, #0x10]
10016f078:     	mov	x8, #0x200000000        ; =8589934592
10016f07c:     	stur	x8, [x21, #0x14]
10016f080:     	add	x0, x21, #0x1c
10016f084:     	b	0x10016efec <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x370>
10016f088:     	cmp	x8, #0x20
10016f08c:     	b.hs	0x10016f09c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x420>
10016f090:     	mov	x10, #0x0               ; =0
10016f094:     	mov	w19, #0x0               ; =0
10016f098:     	b	0x10016f2a0 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x624>
10016f09c:     	movi.2d	v0, #0000000000000000
10016f0a0:     	and	x11, x8, #0x18
10016f0a4:     	movi.16b	v1, #0xf0
10016f0a8:     	and	x10, x8, #0xffffffffffffffe0
10016f0ac:     	movi.4s	v2, #0x2
10016f0b0:     	add	x12, x9, #0x10
10016f0b4:     	movi.16b	v4, #0xc0
10016f0b8:     	and	x13, x8, #0xffffffffffffffe0
10016f0bc:     	movi.2d	v3, #0000000000000000
10016f0c0:     	movi.2d	v6, #0000000000000000
10016f0c4:     	movi.2d	v5, #0000000000000000
10016f0c8:     	movi.2d	v7, #0000000000000000
10016f0cc:     	movi.2d	v16, #0000000000000000
10016f0d0:     	movi.2d	v17, #0000000000000000
10016f0d4:     	movi.2d	v18, #0000000000000000
10016f0d8:     	ldp	q20, q19, [x12, #-0x10]
10016f0dc:     	cmhi.16b	v21, v1, v20
10016f0e0:     	sshll2.8h	v22, v21, #0x0
10016f0e4:     	sshll2.4s	v23, v22, #0x0
10016f0e8:     	sshll.4s	v24, v22, #0x0
10016f0ec:     	sshll.8h	v21, v21, #0x0
10016f0f0:     	sshll2.4s	v25, v21, #0x0
10016f0f4:     	sshll.4s	v26, v21, #0x0
10016f0f8:     	cmhi.16b	v27, v1, v19
10016f0fc:     	sshll2.8h	v28, v27, #0x0
10016f100:     	sshll2.4s	v29, v28, #0x0
10016f104:     	sshll.4s	v30, v28, #0x0
10016f108:     	sshll.8h	v27, v27, #0x0
10016f10c:     	sshll2.4s	v31, v27, #0x0
10016f110:     	bic.16b	v26, v2, v26
10016f114:     	ssubw.4s	v26, v26, v21
10016f118:     	bic.16b	v25, v2, v25
10016f11c:     	ssubw2.4s	v25, v25, v21
10016f120:     	sshll.4s	v21, v27, #0x0
10016f124:     	bic.16b	v24, v2, v24
10016f128:     	ssubw.4s	v24, v24, v22
10016f12c:     	bic.16b	v23, v2, v23
10016f130:     	ssubw2.4s	v22, v23, v22
10016f134:     	bic.16b	v21, v2, v21
10016f138:     	ssubw.4s	v21, v21, v27
10016f13c:     	bic.16b	v23, v2, v31
10016f140:     	ssubw2.4s	v23, v23, v27
10016f144:     	bic.16b	v27, v2, v30
10016f148:     	ssubw.4s	v27, v27, v28
10016f14c:     	bic.16b	v29, v2, v29
10016f150:     	ssubw2.4s	v28, v29, v28
10016f154:     	cmgt.16b	v29, v4, v20
10016f158:     	sshll2.8h	v30, v29, #0x0
10016f15c:     	ushll2.4s	v31, v30, #0x0
10016f160:     	bic.16b	v22, v22, v31
10016f164:     	cmlt.16b	v20, v20, #0
10016f168:     	sshll.8h	v29, v29, #0x0
10016f16c:     	ushll.4s	v30, v30, #0x0
10016f170:     	bic.16b	v24, v24, v30
10016f174:     	ushll2.4s	v30, v29, #0x0
10016f178:     	bic.16b	v25, v25, v30
10016f17c:     	sshll2.8h	v30, v20, #0x0
10016f180:     	sshll.8h	v20, v20, #0x0
10016f184:     	ushll.4s	v29, v29, #0x0
10016f188:     	bic.16b	v26, v26, v29
10016f18c:     	sshll.4s	v29, v20, #0x0
10016f190:     	and.16b	v26, v26, v29
10016f194:     	mvn.16b	v29, v29
10016f198:     	sub.4s	v26, v26, v29
10016f19c:     	sshll2.4s	v29, v30, #0x0
10016f1a0:     	sshll.4s	v30, v30, #0x0
10016f1a4:     	sshll2.4s	v20, v20, #0x0
10016f1a8:     	and.16b	v25, v25, v20
10016f1ac:     	mvn.16b	v20, v20
10016f1b0:     	sub.4s	v20, v25, v20
10016f1b4:     	cmgt.16b	v25, v4, v19
10016f1b8:     	and.16b	v24, v24, v30
10016f1bc:     	mvn.16b	v30, v30
10016f1c0:     	sub.4s	v24, v24, v30
10016f1c4:     	sshll2.8h	v30, v25, #0x0
10016f1c8:     	and.16b	v22, v22, v29
10016f1cc:     	mvn.16b	v29, v29
10016f1d0:     	sub.4s	v22, v22, v29
10016f1d4:     	ushll2.4s	v29, v30, #0x0
10016f1d8:     	bic.16b	v28, v28, v29
10016f1dc:     	cmlt.16b	v19, v19, #0
10016f1e0:     	sshll.8h	v25, v25, #0x0
10016f1e4:     	ushll.4s	v29, v30, #0x0
10016f1e8:     	bic.16b	v27, v27, v29
10016f1ec:     	ushll2.4s	v29, v25, #0x0
10016f1f0:     	bic.16b	v23, v23, v29
10016f1f4:     	sshll.8h	v29, v19, #0x0
10016f1f8:     	ushll.4s	v25, v25, #0x0
10016f1fc:     	bic.16b	v21, v21, v25
10016f200:     	sshll.4s	v25, v29, #0x0
10016f204:     	and.16b	v21, v21, v25
10016f208:     	mvn.16b	v25, v25
10016f20c:     	sub.4s	v21, v21, v25
10016f210:     	sshll2.8h	v19, v19, #0x0
10016f214:     	sshll2.4s	v25, v29, #0x0
10016f218:     	and.16b	v23, v23, v25
10016f21c:     	mvn.16b	v25, v25
10016f220:     	sub.4s	v23, v23, v25
10016f224:     	sshll.4s	v25, v19, #0x0
10016f228:     	and.16b	v27, v27, v25
10016f22c:     	mvn.16b	v25, v25
10016f230:     	sub.4s	v25, v27, v25
10016f234:     	sshll2.4s	v19, v19, #0x0
10016f238:     	and.16b	v27, v28, v19
10016f23c:     	mvn.16b	v19, v19
10016f240:     	sub.4s	v19, v27, v19
10016f244:     	add.4s	v7, v22, v7
10016f248:     	add.4s	v5, v24, v5
10016f24c:     	add.4s	v6, v20, v6
10016f250:     	add.4s	v3, v26, v3
10016f254:     	add.4s	v18, v19, v18
10016f258:     	add.4s	v17, v25, v17
10016f25c:     	add.4s	v0, v23, v0
10016f260:     	add.4s	v16, v21, v16
10016f264:     	add	x12, x12, #0x20
10016f268:     	subs	x13, x13, #0x20
10016f26c:     	b.ne	0x10016f0d8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x45c>
10016f270:     	add.4s	v0, v0, v6
10016f274:     	add.4s	v1, v18, v7
10016f278:     	add.4s	v2, v16, v3
10016f27c:     	add.4s	v3, v17, v5
10016f280:     	add.4s	v2, v2, v3
10016f284:     	add.4s	v0, v0, v1
10016f288:     	add.4s	v0, v2, v0
10016f28c:     	addv.4s	s0, v0
10016f290:     	fmov	w19, s0
10016f294:     	cmp	x8, x10
10016f298:     	b.eq	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016f29c:     	cbz	x11, 0x10016f350 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x6d4>
10016f2a0:     	mov	x12, x10
10016f2a4:     	and	x10, x8, #0xfffffffffffffff8
10016f2a8:     	movi.2d	v0, #0000000000000000
10016f2ac:     	mov.s	v0[0], w19
10016f2b0:     	movi.2d	v1, #0000000000000000
10016f2b4:     	sub	x11, x12, x10
10016f2b8:     	add	x12, x9, x12
10016f2bc:     	movi.8b	v2, #0xf0
10016f2c0:     	movi.4s	v3, #0x2
10016f2c4:     	movi.8b	v4, #0xc0
10016f2c8:     	ldr	d5, [x12], #0x8
10016f2cc:     	sshll.8h	v6, v5, #0x0
10016f2d0:     	cmlt.8h	v6, v6, #0
10016f2d4:     	sshll2.4s	v7, v6, #0x0
10016f2d8:     	sshll.4s	v6, v6, #0x0
10016f2dc:     	cmhi.8b	v16, v2, v5
10016f2e0:     	sshll.8h	v16, v16, #0x0
10016f2e4:     	sshll2.4s	v17, v16, #0x0
10016f2e8:     	sshll.4s	v18, v16, #0x0
10016f2ec:     	bic.16b	v18, v3, v18
10016f2f0:     	ssubw.4s	v18, v18, v16
10016f2f4:     	bic.16b	v17, v3, v17
10016f2f8:     	ssubw2.4s	v16, v17, v16
10016f2fc:     	cmgt.8b	v5, v4, v5
10016f300:     	sshll.8h	v5, v5, #0x0
10016f304:     	ushll.4s	v17, v5, #0x0
10016f308:     	ushll2.4s	v5, v5, #0x0
10016f30c:     	bic.16b	v5, v16, v5
10016f310:     	bic.16b	v16, v18, v17
10016f314:     	and.16b	v16, v16, v6
10016f318:     	mvn.16b	v6, v6
10016f31c:     	sub.4s	v6, v16, v6
10016f320:     	and.16b	v5, v5, v7
10016f324:     	mvn.16b	v7, v7
10016f328:     	sub.4s	v5, v5, v7
10016f32c:     	add.4s	v1, v5, v1
10016f330:     	add.4s	v0, v6, v0
10016f334:     	adds	x11, x11, #0x8
10016f338:     	b.ne	0x10016f2c8 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x64c>
10016f33c:     	add.4s	v0, v0, v1
10016f340:     	addv.4s	s0, v0
10016f344:     	fmov	w19, s0
10016f348:     	cmp	x8, x10
10016f34c:     	b.eq	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
10016f350:     	sub	x8, x8, x10
10016f354:     	add	x9, x9, x10
10016f358:     	mov	w10, #0x1               ; =1
10016f35c:     	ldrsb	w11, [x9], #0x1
10016f360:     	and	w12, w11, #0xff
10016f364:     	cmp	w12, #0xf0
10016f368:     	cinc	w13, w10, hs
10016f36c:     	cmp	w12, #0xc0
10016f370:     	csel	w12, wzr, w13, lo
10016f374:     	tst	w11, #0x80000000
10016f378:     	csinc	w11, w12, wzr, ne
10016f37c:     	add	w19, w11, w19
10016f380:     	subs	x8, x8, #0x1
10016f384:     	b.ne	0x10016f35c <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x6e0>
10016f388:     	b	0x10016ef74 <__RINvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytesNtNtNtB6_4json6parser12DirectParserEB6_+0x2f8>
