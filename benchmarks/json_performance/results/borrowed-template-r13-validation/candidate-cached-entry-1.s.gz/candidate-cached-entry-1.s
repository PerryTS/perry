
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/borrowed-template-r13/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100500af8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>:
100500af8:     	stp	x28, x27, [sp, #-0x60]!
100500afc:     	stp	x26, x25, [sp, #0x10]
100500b00:     	stp	x24, x23, [sp, #0x20]
100500b04:     	stp	x22, x21, [sp, #0x30]
100500b08:     	stp	x20, x19, [sp, #0x40]
100500b0c:     	stp	x29, x30, [sp, #0x50]
100500b10:     	add	x29, sp, #0x50
100500b14:     	sub	sp, sp, #0x1a0
100500b18:     	mov	x19, x1
100500b1c:     	mov	x21, x0
100500b20:     	add	x24, x0, #0x14
100500b24:     	sub	x8, x1, #0x801
100500b28:     	adrp	x27, 0x100f74000 <_perry_global_rotating_worker_ts__1>
100500b2c:     	cmn	x8, #0x7c0
100500b30:     	b.hs	0x100500b50 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x58>
100500b34:     	cmp	x19, #0x2
100500b38:     	b.ne	0x100500bc8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd0>
100500b3c:     	ldrh	w8, [x24]
100500b40:     	mov	w9, #0x7d7b             ; =32123
100500b44:     	cmp	w8, w9
100500b48:     	b.eq	0x100500bfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x104>
100500b4c:     	b	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500b50:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
100500b54:     	ldr	w20, [x8, #0x578]
100500b58:     	cmp	w20, #0x300
100500b5c:     	b.hs	0x100500ce8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1f0>
100500b60:     	ldr	x8, [x27, #0x48]
100500b64:     	cmn	x8, #0x1
100500b68:     	b.eq	0x100500cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1e0>
100500b6c:     	mrs	x9, TPIDRRO_EL0
100500b70:     	and	x9, x9, #0xfffffffffffffff8
100500b74:     	ldr	x0, [x9, x8, lsl #3]
100500b78:     	cbz	x0, 0x100500cd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1e0>
100500b7c:     	add	x8, x0, x20, lsl #3
100500b80:     	ldr	x0, [x8, #0x1e8]
100500b84:     	cbz	x0, 0x100500ce8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1f0>
100500b88:     	ldr	x8, [x0]
100500b8c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100500b90:     	cmp	x8, x9
100500b94:     	b.hs	0x100500d04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x20c>
100500b98:     	ldrb	w8, [x0, #0x8]
100500b9c:     	cmp	w8, #0x2
100500ba0:     	b.eq	0x100500bd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd8>
100500ba4:     	ldr	x8, [x0, #0x248]
100500ba8:     	cmp	x8, x21
100500bac:     	b.ne	0x100500bd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd8>
100500bb0:     	ldrh	w8, [x0, #0x25c]
100500bb4:     	cmp	x19, x8
100500bb8:     	b.ne	0x100500bd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd8>
100500bbc:     	bl	0x1004e776c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template>
100500bc0:     	tbz	w0, #0x0, 0x100500bd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd8>
100500bc4:     	b	0x100500ef0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3f8>
100500bc8:     	cmp	x19, #0x3
100500bcc:     	b.lo	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500bd0:     	ldrb	w20, [x24]
100500bd4:     	cmp	w20, #0x20
100500bd8:     	b.hi	0x100500c1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x124>
100500bdc:     	mov	x8, #0x2600             ; =9728
100500be0:     	movk	x8, #0x1, lsl #32
100500be4:     	lsr	x8, x8, x20
100500be8:     	tbz	w8, #0x0, 0x100500c1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x124>
100500bec:     	add	x0, x21, #0x14
100500bf0:     	mov	x1, x19
100500bf4:     	bl	0x1004e6f64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty19padded_empty_object>
100500bf8:     	tbz	w0, #0x0, 0x100500c48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x150>
100500bfc:     	add	sp, sp, #0x1a0
100500c00:     	ldp	x29, x30, [sp, #0x50]
100500c04:     	ldp	x20, x19, [sp, #0x40]
100500c08:     	ldp	x22, x21, [sp, #0x30]
100500c0c:     	ldp	x24, x23, [sp, #0x20]
100500c10:     	ldp	x26, x25, [sp, #0x10]
100500c14:     	ldp	x28, x27, [sp], #0x60
100500c18:     	b	0x1004e7040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100500c1c:     	cmp	w20, #0x7b
100500c20:     	b.ne	0x100500c48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x150>
100500c24:     	ldrb	w8, [x21, #0x15]
100500c28:     	cmp	w8, #0x20
100500c2c:     	b.hi	0x100500c40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x148>
100500c30:     	mov	x9, #0x2600             ; =9728
100500c34:     	movk	x9, #0x1, lsl #32
100500c38:     	lsr	x9, x9, x8
100500c3c:     	tbnz	w9, #0x0, 0x100500bec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf4>
100500c40:     	cmp	w8, #0x7d
100500c44:     	b.eq	0x100500bec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf4>
100500c48:     	cmp	x19, #0x41
100500c4c:     	b.hs	0x100500ef8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x400>
100500c50:     	cmp	w20, #0x7b
100500c54:     	ccmp	x19, #0x7, #0x0, eq
100500c58:     	b.lo	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500c5c:     	add	x8, x24, x19
100500c60:     	ldurb	w8, [x8, #-0x1]
100500c64:     	cmp	w8, #0x7d
100500c68:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500c6c:     	ldrb	w8, [x21, #0x15]
100500c70:     	cmp	w8, #0x22
100500c74:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500c78:     	sub	x9, x19, #0x1
100500c7c:     	mov	x22, x21
100500c80:     	ldrb	w25, [x22, #0x16]!
100500c84:     	cmp	w25, #0x22
100500c88:     	b.ne	0x100500d10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x218>
100500c8c:     	mov	w20, #0x0               ; =0
100500c90:     	mov	w23, #0x0               ; =0
100500c94:     	mov	w28, #0x0               ; =0
100500c98:     	str	wzr, [sp, #0x8]
100500c9c:     	mov	x26, #0x0               ; =0
100500ca0:     	cmp	w25, #0x22
100500ca4:     	b.ne	0x100500d3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x244>
100500ca8:     	add	x8, sp, #0xa0
100500cac:     	mov	x0, x22
100500cb0:     	mov	x1, x26
100500cb4:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100500cb8:     	sub	x12, x19, #0x1
100500cbc:     	ldr	w8, [sp, #0xa0]
100500cc0:     	tbnz	w8, #0x0, 0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500cc4:     	mov	x11, x26
100500cc8:     	cmp	w25, #0x22
100500ccc:     	b.ne	0x100500de4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x2ec>
100500cd0:     	mov	x8, #0x0                ; =0
100500cd4:     	b	0x100500e1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x324>
100500cd8:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100500cdc:     	add	x8, x0, x20, lsl #3
100500ce0:     	ldr	x0, [x8, #0x1e8]
100500ce4:     	cbnz	x0, 0x100500b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x90>
100500ce8:     	adrp	x0, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
100500cec:     	add	x0, x0, #0x0
100500cf0:     	bl	0x100b3359c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100500cf4:     	ldr	x8, [x0]
100500cf8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100500cfc:     	cmp	x8, x9
100500d00:     	b.lo	0x100500b98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa0>
100500d04:     	adrp	x0, 0x100ef1000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100500d08:     	add	x0, x0, #0xda0
100500d0c:     	bl	0x100b0911c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100500d10:     	cmp	x9, #0x3
100500d14:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500d18:     	ldrb	w8, [x21, #0x17]
100500d1c:     	cmp	w8, #0x22
100500d20:     	b.ne	0x100500db8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x2c0>
100500d24:     	mov	w23, #0x0               ; =0
100500d28:     	mov	w28, #0x0               ; =0
100500d2c:     	str	wzr, [sp, #0x8]
100500d30:     	mov	w20, #0x1               ; =1
100500d34:     	mov	w26, #0x1               ; =1
100500d38:     	b	0x100500ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1a8>
100500d3c:     	ldrb	w8, [x22]
100500d40:     	cmp	w8, #0x20
100500d44:     	b.lo	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500d48:     	cmp	w8, #0x5c
100500d4c:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500d50:     	tbnz	w20, #0x0, 0x100500ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b0>
100500d54:     	ldrb	w8, [x21, #0x17]
100500d58:     	cmp	w8, #0x20
100500d5c:     	b.lo	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500d60:     	cmp	w8, #0x5c
100500d64:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500d68:     	tbnz	w23, #0x0, 0x100500ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b0>
100500d6c:     	ldrb	w8, [x21, #0x18]
100500d70:     	cmp	w8, #0x20
100500d74:     	b.lo	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500d78:     	cmp	w8, #0x5c
100500d7c:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500d80:     	tbnz	w28, #0x0, 0x100500ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b0>
100500d84:     	ldrb	w8, [x21, #0x19]
100500d88:     	cmp	w8, #0x20
100500d8c:     	b.lo	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500d90:     	cmp	w8, #0x5c
100500d94:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500d98:     	ldr	w8, [sp, #0x8]
100500d9c:     	tbnz	w8, #0x0, 0x100500ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b0>
100500da0:     	ldrb	w8, [x21, #0x1a]
100500da4:     	cmp	w8, #0x20
100500da8:     	b.lo	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500dac:     	cmp	w8, #0x5c
100500db0:     	b.ne	0x100500ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1b0>
100500db4:     	b	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500db8:     	cmp	x9, #0x4
100500dbc:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500dc0:     	ldrb	w8, [x21, #0x18]
100500dc4:     	cmp	w8, #0x22
100500dc8:     	b.ne	0x100500e88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x390>
100500dcc:     	mov	w20, #0x0               ; =0
100500dd0:     	mov	w28, #0x0               ; =0
100500dd4:     	str	wzr, [sp, #0x8]
100500dd8:     	mov	w23, #0x1               ; =1
100500ddc:     	mov	w26, #0x2               ; =2
100500de0:     	b	0x100500ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1a8>
100500de4:     	ldrb	w8, [x22]
100500de8:     	tbnz	w20, #0x0, 0x100500e1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x324>
100500dec:     	ldrb	w9, [x21, #0x17]
100500df0:     	orr	x8, x8, x9, lsl #8
100500df4:     	tbnz	w23, #0x0, 0x100500e1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x324>
100500df8:     	ldrb	w9, [x21, #0x18]
100500dfc:     	orr	x8, x8, x9, lsl #16
100500e00:     	tbnz	w28, #0x0, 0x100500e1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x324>
100500e04:     	ldrb	w9, [x21, #0x19]
100500e08:     	orr	x8, x8, x9, lsl #24
100500e0c:     	ldr	w9, [sp, #0x8]
100500e10:     	tbnz	w9, #0x0, 0x100500e1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x324>
100500e14:     	ldrb	w9, [x21, #0x1a]
100500e18:     	orr	x8, x8, x9, lsl #32
100500e1c:     	add	x9, x11, #0x3
100500e20:     	cmp	x9, x19
100500e24:     	b.hs	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500e28:     	ldrb	w9, [x24, x9]
100500e2c:     	cmp	w9, #0x3a
100500e30:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500e34:     	add	x10, x11, #0x4
100500e38:     	subs	x9, x12, x10
100500e3c:     	b.lo	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500e40:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500e44:     	orr	x25, x8, x11, lsl #40
100500e48:     	mov	x28, #0x7ff9000000000000 ; =9221401712017801216
100500e4c:     	add	x8, x24, x10
100500e50:     	mov	x10, #0x2600            ; =9728
100500e54:     	movk	x10, #0x1, lsl #32
100500e58:     	mov	x11, x9
100500e5c:     	mov	x12, x8
100500e60:     	b	0x100500e70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x378>
100500e64:     	add	x12, x12, #0x1
100500e68:     	subs	x11, x11, #0x1
100500e6c:     	b.eq	0x100501e8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1394>
100500e70:     	ldrb	w13, [x12]
100500e74:     	cmp	w13, #0x20
100500e78:     	b.hi	0x100500e64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x36c>
100500e7c:     	lsr	x13, x10, x13
100500e80:     	tbz	w13, #0x0, 0x100500e64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x36c>
100500e84:     	b	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100500e88:     	cmp	x9, #0x5
100500e8c:     	b.ne	0x100500f38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x440>
100500e90:     	add	x0, sp, #0xa0
100500e94:     	add	x1, x21, #0x14
100500e98:     	mov	x2, x19
100500e9c:     	bl	0x1004f04bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object6decode>
100500ea0:     	ldr	w8, [sp, #0xa0]
100500ea4:     	tbz	w8, #0x0, 0x100500ef8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x400>
100500ea8:     	add	x8, sp, #0xa0
100500eac:     	ldr	x9, [sp, #0x128]
100500eb0:     	str	x9, [sp, #0x90]
100500eb4:     	ldur	q0, [x8, #0x48]
100500eb8:     	ldur	q1, [x8, #0x58]
100500ebc:     	stp	q0, q1, [sp, #0x50]
100500ec0:     	ldur	q0, [x8, #0x68]
100500ec4:     	ldur	q1, [x8, #0x78]
100500ec8:     	stp	q0, q1, [sp, #0x70]
100500ecc:     	ldur	q0, [x8, #0x8]
100500ed0:     	ldur	q1, [x8, #0x18]
100500ed4:     	stp	q0, q1, [sp, #0x10]
100500ed8:     	ldur	q0, [x8, #0x28]
100500edc:     	ldur	q1, [x8, #0x38]
100500ee0:     	stp	q0, q1, [sp, #0x30]
100500ee4:     	add	x0, sp, #0x10
100500ee8:     	bl	0x1004f0c6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object8allocate>
100500eec:     	tbz	w0, #0x0, 0x100500ef8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x400>
100500ef0:     	mov	x23, x1
100500ef4:     	b	0x100501b14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x101c>
100500ef8:     	adrp	x8, 0x100f75000 <__MergedGlobals+0xb8>
100500efc:     	add	x8, x8, #0x2d8
100500f00:     	ldapr	x8, [x8]
100500f04:     	cbnz	x8, 0x100500f5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x464>
100500f08:     	adrp	x8, 0x100f75000 <__MergedGlobals+0xb8>
100500f0c:     	ldrb	w8, [x8, #0x2e0]
100500f10:     	adrp	x12, 0x100f76000 <__MergedGlobals.1914+0xc8>
100500f14:     	cbz	w8, 0x100500f70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x478>
100500f18:     	cmp	w8, #0x1
100500f1c:     	b.ne	0x100500fac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4b4>
100500f20:     	mov	w28, #0x1               ; =1
100500f24:     	mov	w8, #0x1000000          ; =16777216
100500f28:     	mov	w22, #0x1               ; =1
100500f2c:     	cmp	x19, x8
100500f30:     	b.hi	0x100500fb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4b8>
100500f34:     	b	0x100501094 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x59c>
100500f38:     	ldrb	w8, [x21, #0x19]
100500f3c:     	cmp	w8, #0x22
100500f40:     	b.ne	0x100501d44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x124c>
100500f44:     	mov	w20, #0x0               ; =0
100500f48:     	mov	w23, #0x0               ; =0
100500f4c:     	str	wzr, [sp, #0x8]
100500f50:     	mov	w28, #0x1               ; =1
100500f54:     	mov	w26, #0x3               ; =3
100500f58:     	b	0x100500ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1a8>
100500f5c:     	bl	0x100b0f7c8 <__RINvMNtNtCs8BpVhDwHqJW_3std4sync9once_lockINtB3_8OnceLockNtNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api8TapeModeE10initializeNCINvB2_11get_or_initNCNvBV_18tape_mode_from_env0E0zEBZ_>
100500f60:     	adrp	x8, 0x100f75000 <__MergedGlobals+0xb8>
100500f64:     	ldrb	w8, [x8, #0x2e0]
100500f68:     	adrp	x12, 0x100f76000 <__MergedGlobals.1914+0xc8>
100500f6c:     	cbnz	w8, 0x100500f18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x420>
100500f70:     	sub	x8, x19, #0x400
100500f74:     	mov	w9, #0xfffc00           ; =16776192
100500f78:     	cmp	x8, x9
100500f7c:     	b.hi	0x100500fac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4b4>
100500f80:     	mov	x8, #0x0                ; =0
100500f84:     	mov	x9, #0x2600             ; =9728
100500f88:     	movk	x9, #0x1, lsl #32
100500f8c:     	ldrb	w10, [x24, x8]
100500f90:     	cmp	w10, #0x20
100500f94:     	b.hi	0x100501b94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x109c>
100500f98:     	lsr	x11, x9, x10
100500f9c:     	tbz	w11, #0x0, 0x100501b94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x109c>
100500fa0:     	add	x8, x8, #0x1
100500fa4:     	cmp	x19, x8
100500fa8:     	b.ne	0x100500f8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x494>
100500fac:     	mov	w22, #0x0               ; =0
100500fb0:     	ldr	w20, [x12, #0x560]
100500fb4:     	cmp	w20, #0x300
100500fb8:     	b.hs	0x100501b6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1074>
100500fbc:     	ldr	x8, [x27, #0x48]
100500fc0:     	cmn	x8, #0x1
100500fc4:     	b.eq	0x100501b5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1064>
100500fc8:     	mrs	x9, TPIDRRO_EL0
100500fcc:     	and	x9, x9, #0xfffffffffffffff8
100500fd0:     	ldr	x0, [x9, x8, lsl #3]
100500fd4:     	cbz	x0, 0x100501b5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1064>
100500fd8:     	add	x8, x0, x20, lsl #3
100500fdc:     	ldr	x0, [x8, #0x1e8]
100500fe0:     	cbz	x0, 0x100501b6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1074>
100500fe4:     	ldr	x8, [x0]
100500fe8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100500fec:     	cmp	x8, x9
100500ff0:     	b.hs	0x100501b88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1090>
100500ff4:     	ldrb	w8, [x0, #0x24]
100500ff8:     	cmp	w8, #0x2
100500ffc:     	b.eq	0x10050100c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x514>
100501000:     	ldr	x9, [x0, #0x8]
100501004:     	cmp	x9, x21
100501008:     	b.eq	0x100501074 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x57c>
10050100c:     	cmp	x19, #0x3e9
100501010:     	b.lo	0x100501090 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x598>
100501014:     	mov	x8, #0x0                ; =0
100501018:     	mov	x9, #0x2600             ; =9728
10050101c:     	movk	x9, #0x1, lsl #32
100501020:     	add	x10, x21, x8
100501024:     	ldrb	w10, [x10, #0x14]
100501028:     	cmp	w10, #0x20
10050102c:     	b.hi	0x100501048 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x550>
100501030:     	lsr	x11, x9, x10
100501034:     	tbz	w11, #0x0, 0x100501048 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x550>
100501038:     	add	x8, x8, #0x1
10050103c:     	cmp	x19, x8
100501040:     	b.ne	0x100501020 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x528>
100501044:     	b	0x100501090 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x598>
100501048:     	cmp	w10, #0x5b
10050104c:     	b.eq	0x100501058 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x560>
100501050:     	cmp	w10, #0x7b
100501054:     	b.ne	0x100501090 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x598>
100501058:     	add	x0, x21, #0x14
10050105c:     	mov	x1, x19
100501060:     	mov	w2, #0x3e8              ; =1000
100501064:     	bl	0x1006be514 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
100501068:     	cbz	w0, 0x100501090 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x598>
10050106c:     	mov	x0, x21
100501070:     	b	0x100501e1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1324>
100501074:     	ldr	w9, [x0, #0x18]
100501078:     	cmp	x19, x9
10050107c:     	cset	w9, eq
100501080:     	and	w8, w9, w8
100501084:     	cmp	x19, #0x3e9
100501088:     	csinc	w8, w8, wzr, hs
10050108c:     	tbz	w8, #0x0, 0x100501014 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x51c>
100501090:     	mov	w28, #0x0               ; =0
100501094:     	adrp	x0, 0x100f7b000 <_theap_main+0x1f80>
100501098:     	add	x0, x0, #0xce8
10050109c:     	ldr	x8, [x0]
1005010a0:     	blr	x8
1005010a4:     	mov	x20, x0
1005010a8:     	ldrb	w8, [x0, #0x20]
1005010ac:     	cbnz	w8, 0x100501d74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x127c>
1005010b0:     	ldr	x8, [x20]
1005010b4:     	cbnz	x8, 0x100501df0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f8>
1005010b8:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
1005010bc:     	bfxil	x23, x21, #0, #48
1005010c0:     	mov	x8, #-0x1               ; =-1
1005010c4:     	str	x8, [x20]
1005010c8:     	ldr	x21, [x20, #0x18]
1005010cc:     	ldr	x8, [x20, #0x8]
1005010d0:     	cmp	x21, x8
1005010d4:     	b.eq	0x1005019e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xeec>
1005010d8:     	ldr	x8, [x20, #0x10]
1005010dc:     	str	x23, [x8, x21, lsl #3]
1005010e0:     	add	x8, x21, #0x1
1005010e4:     	str	x8, [x20, #0x18]
1005010e8:     	ldr	x8, [x20]
1005010ec:     	add	x8, x8, #0x1
1005010f0:     	str	x8, [x20]
1005010f4:     	adrp	x24, 0x100f74000 <_perry_global_rotating_worker_ts__1>
1005010f8:     	ldr	w23, [x24, #0x948]
1005010fc:     	cmp	w23, #0x300
100501100:     	b.hs	0x100501a00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf08>
100501104:     	ldr	x8, [x27, #0x48]
100501108:     	cmn	x8, #0x1
10050110c:     	b.eq	0x1005019f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef8>
100501110:     	mrs	x9, TPIDRRO_EL0
100501114:     	and	x9, x9, #0xfffffffffffffff8
100501118:     	ldr	x0, [x9, x8, lsl #3]
10050111c:     	cbz	x0, 0x1005019f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xef8>
100501120:     	add	x8, x0, x23, lsl #3
100501124:     	ldr	x0, [x8, #0x1e8]
100501128:     	cbz	x0, 0x100501a00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf08>
10050112c:     	ldrb	w8, [x0]
100501130:     	cbnz	w8, 0x100501a14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf1c>
100501134:     	adrp	x26, 0x100f76000 <__MergedGlobals.1914+0xc8>
100501138:     	tbz	w22, #0x0, 0x100501744 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc4c>
10050113c:     	ldrb	w8, [x20, #0x20]
100501140:     	cbnz	w8, 0x100501e2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1334>
100501144:     	ldr	x8, [x20]
100501148:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10050114c:     	cmp	x8, x9
100501150:     	b.hs	0x100501f90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1498>
100501154:     	add	x9, x8, #0x1
100501158:     	str	x9, [x20]
10050115c:     	ldr	x9, [x20, #0x18]
100501160:     	cmp	x21, x9
100501164:     	b.hs	0x100501178 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x680>
100501168:     	ldr	x9, [x20, #0x10]
10050116c:     	ldr	x9, [x9, x21, lsl #3]
100501170:     	and	x23, x9, #0xffffffffffff
100501174:     	b	0x10050117c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x684>
100501178:     	mov	w23, #0x1               ; =1
10050117c:     	str	x8, [x20]
100501180:     	adrp	x0, 0x100f7c000 <__RNvNCNKNvNtCs3gRpqoBkMHm_13perry_runtime7process29PROCESS_FINALIZATION_EXIT_RAN0s_023___RUST_STD_INTERNAL_VAL>
100501184:     	add	x0, x0, #0x168
100501188:     	ldr	x8, [x0]
10050118c:     	blr	x8
100501190:     	mov	x22, x0
100501194:     	ldrb	w8, [x0, #0x30]
100501198:     	cmp	w8, #0x1
10050119c:     	b.ne	0x100501dfc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1304>
1005011a0:     	ldr	x8, [x22]
1005011a4:     	mov	x10, #-0x1              ; =-1
1005011a8:     	mov	x9, x22
1005011ac:     	str	x10, [x9], #0x8
1005011b0:     	cmn	x8, #0x1
1005011b4:     	b.eq	0x1005011d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6dc>
1005011b8:     	add	x10, sp, #0xa0
1005011bc:     	ldp	q0, q1, [x9]
1005011c0:     	ldr	x9, [x9, #0x20]
1005011c4:     	stur	x9, [x10, #0x28]
1005011c8:     	stur	q1, [x10, #0x18]
1005011cc:     	stur	q0, [x10, #0x8]
1005011d0:     	b	0x1005011e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6f0>
1005011d4:     	mov	x8, #0x0                ; =0
1005011d8:     	mov	w9, #0x4                ; =4
1005011dc:     	stp	x9, xzr, [sp, #0xa8]
1005011e0:     	stp	xzr, x9, [sp, #0xb8]
1005011e4:     	str	xzr, [sp, #0xc8]
1005011e8:     	str	x8, [sp, #0xa0]
1005011ec:     	stur	xzr, [x29, #-0x78]
1005011f0:     	add	x8, sp, #0xa0
1005011f4:     	add	x0, x23, #0x14
1005011f8:     	add	x2, sp, #0xa0
1005011fc:     	add	x3, x8, #0x18
100501200:     	sub	x4, x29, #0x78
100501204:     	mov	x1, x19
100501208:     	bl	0x10014d1c0 <__RINvNtCs3gRpqoBkMHm_13perry_runtime9json_tape15build_tape_intoKb1_EB4_>
10050120c:     	tbz	w0, #0x0, 0x100501350 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x858>
100501210:     	ldur	x23, [x29, #-0x78]
100501214:     	ldr	w24, [x24, #0x948]
100501218:     	cmp	w24, #0x300
10050121c:     	b.hs	0x100501c2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1134>
100501220:     	ldr	x8, [x27, #0x48]
100501224:     	cmn	x8, #0x1
100501228:     	b.eq	0x100501c1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1124>
10050122c:     	mrs	x9, TPIDRRO_EL0
100501230:     	and	x9, x9, #0xfffffffffffffff8
100501234:     	ldr	x0, [x9, x8, lsl #3]
100501238:     	cbz	x0, 0x100501c1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1124>
10050123c:     	add	x8, x0, x24, lsl #3
100501240:     	ldr	x0, [x8, #0x1e8]
100501244:     	cbz	x0, 0x100501c2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1134>
100501248:     	ldrb	w8, [x0]
10050124c:     	cbnz	w8, 0x100501c40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1148>
100501250:     	ldr	w24, [x26, #0x590]
100501254:     	cmp	w24, #0x300
100501258:     	b.hs	0x100501c64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x116c>
10050125c:     	ldr	x8, [x27, #0x48]
100501260:     	cmn	x8, #0x1
100501264:     	b.eq	0x100501c54 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x115c>
100501268:     	mrs	x9, TPIDRRO_EL0
10050126c:     	and	x9, x9, #0xfffffffffffffff8
100501270:     	ldr	x0, [x9, x8, lsl #3]
100501274:     	cbz	x0, 0x100501c54 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x115c>
100501278:     	add	x8, x0, x24, lsl #3
10050127c:     	ldr	x0, [x8, #0x1e8]
100501280:     	cbz	x0, 0x100501c64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x116c>
100501284:     	bl	0x100219cb0 <__RNCNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary0B7_>
100501288:     	bl	0x100455200 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
10050128c:     	mov	x0, x19
100501290:     	bl	0x10022ec6c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
100501294:     	mov	x24, x0
100501298:     	mov	x25, x1
10050129c:     	bl	0x100455014 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
1005012a0:     	ldrb	w8, [x20, #0x20]
1005012a4:     	cbnz	w8, 0x100501eec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13f4>
1005012a8:     	ldr	x8, [x20]
1005012ac:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005012b0:     	cmp	x8, x9
1005012b4:     	b.hs	0x100501f90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1498>
1005012b8:     	add	x9, x8, #0x1
1005012bc:     	str	x9, [x20]
1005012c0:     	ldr	x9, [x20, #0x18]
1005012c4:     	cmp	x21, x9
1005012c8:     	b.hs	0x1005013e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8f0>
1005012cc:     	ldr	x9, [x20, #0x10]
1005012d0:     	ldr	x9, [x9, x21, lsl #3]
1005012d4:     	and	x2, x9, #0xffffffffffff
1005012d8:     	stp	x25, x24, [sp]
1005012dc:     	str	x8, [x20]
1005012e0:     	add	x26, x2, #0x14
1005012e4:     	cmp	x23, #0x3e8
1005012e8:     	b.hi	0x100501400 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x908>
1005012ec:     	ldp	x24, x25, [sp, #0xa8]
1005012f0:     	cbz	x25, 0x100501448 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x950>
1005012f4:     	ldrb	w8, [x24, #0x8]
1005012f8:     	cmp	w8, #0x3
1005012fc:     	b.ne	0x100501448 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x950>
100501300:     	ldr	w8, [x24, #0x4]
100501304:     	cmp	w8, #0x2
100501308:     	b.lo	0x100501bbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10c4>
10050130c:     	mov	w1, #0x0                ; =0
100501310:     	mov	w0, #0x1                ; =1
100501314:     	mov	w9, #0xc                ; =12
100501318:     	b	0x10050132c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x834>
10050131c:     	add	x0, x0, #0x1
100501320:     	add	w1, w1, #0x1
100501324:     	cmp	x0, x8
100501328:     	b.hs	0x100501bc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10c8>
10050132c:     	cmp	x0, x25
100501330:     	b.hs	0x100502090 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1598>
100501334:     	madd	x10, x0, x9, x24
100501338:     	ldrb	w11, [x10, #0x8]
10050133c:     	orr	w11, w11, #0x2
100501340:     	cmp	w11, #0x3
100501344:     	b.ne	0x10050131c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x824>
100501348:     	ldr	w0, [x10, #0x4]
10050134c:     	b	0x10050131c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x824>
100501350:     	str	xzr, [sp, #0xb0]
100501354:     	str	xzr, [sp, #0xc8]
100501358:     	ldr	x8, [sp, #0xa0]
10050135c:     	add	x9, x8, x8, lsl #1
100501360:     	lsl	x9, x9, #2
100501364:     	cmp	x9, #0x100, lsl #12     ; =0x100000
100501368:     	b.ls	0x100501384 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x88c>
10050136c:     	cbz	x8, 0x100501378 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x880>
100501370:     	ldr	x0, [sp, #0xa8]
100501374:     	bl	0x100b55980 <_mi_free>
100501378:     	mov	w8, #0x4                ; =4
10050137c:     	stp	xzr, x8, [sp, #0xa0]
100501380:     	str	xzr, [sp, #0xb0]
100501384:     	ldr	x8, [sp, #0xb8]
100501388:     	lsl	x9, x8, #2
10050138c:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100501390:     	b.ls	0x1005013ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8b4>
100501394:     	cbz	x8, 0x1005013a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8a8>
100501398:     	ldr	x0, [sp, #0xc0]
10050139c:     	bl	0x100b55980 <_mi_free>
1005013a0:     	mov	w8, #0x4                ; =4
1005013a4:     	stp	xzr, x8, [sp, #0xb8]
1005013a8:     	str	xzr, [sp, #0xc8]
1005013ac:     	ldp	x8, x0, [x22]
1005013b0:     	ldp	x24, x23, [x22, #0x18]
1005013b4:     	ldp	q1, q0, [sp, #0xb0]
1005013b8:     	ldr	q2, [sp, #0xa0]
1005013bc:     	stp	q2, q1, [x22]
1005013c0:     	str	q0, [x22, #0x20]
1005013c4:     	cmn	x8, #0x1
1005013c8:     	b.eq	0x1005013e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8e8>
1005013cc:     	cbz	x8, 0x1005013d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8dc>
1005013d0:     	bl	0x100b55980 <_mi_free>
1005013d4:     	cbz	x24, 0x1005013e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x8e8>
1005013d8:     	mov	x0, x23
1005013dc:     	bl	0x100b55980 <_mi_free>
1005013e0:     	ldrb	w8, [x20, #0x20]
1005013e4:     	b	0x100501664 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb6c>
1005013e8:     	mov	w2, #0x1                ; =1
1005013ec:     	stp	x25, x24, [sp]
1005013f0:     	str	x8, [x20]
1005013f4:     	add	x26, x2, #0x14
1005013f8:     	cmp	x23, #0x3e8
1005013fc:     	b.ls	0x1005012ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7f4>
100501400:     	ldp	x0, x1, [sp, #0xa8]
100501404:     	mov	x2, x26
100501408:     	mov	x3, x19
10050140c:     	bl	0x100681fd4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape9iterative21materialize_iterative>
100501410:     	tbz	w0, #0x0, 0x1005014cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9d4>
100501414:     	mov	x25, x1
100501418:     	ldrb	w8, [x20, #0x20]
10050141c:     	cbz	w8, 0x100501478 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x980>
100501420:     	cmp	w8, #0x2
100501424:     	b.eq	0x100501fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ac>
100501428:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
10050142c:     	add	x1, x1, #0x58
100501430:     	mov	x0, x20
100501434:     	bl	0x100a16e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501438:     	strb	wzr, [x20, #0x20]
10050143c:     	ldr	x8, [x20]
100501440:     	cbz	x8, 0x100501480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x988>
100501444:     	b	0x100501df0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f8>
100501448:     	bl	0x100288018 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
10050144c:     	stp	x0, xzr, [x29, #-0x70]
100501450:     	stp	x24, x25, [sp, #0x10]
100501454:     	stp	x26, x19, [sp, #0x20]
100501458:     	add	x0, sp, #0x10
10050145c:     	sub	x1, x29, #0x68
100501460:     	bl	0x100373120 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24materialize_value_source>
100501464:     	mov	x25, x0
100501468:     	sub	x0, x29, #0x70
10050146c:     	bl	0x1001633fc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100501470:     	ldrb	w8, [x20, #0x20]
100501474:     	cbnz	w8, 0x100501420 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x928>
100501478:     	ldr	x8, [x20]
10050147c:     	cbnz	x8, 0x100501df0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f8>
100501480:     	mov	x8, #-0x1               ; =-1
100501484:     	str	x8, [x20]
100501488:     	ldr	x26, [x20, #0x18]
10050148c:     	ldr	x8, [x20, #0x8]
100501490:     	cmp	x26, x8
100501494:     	b.eq	0x100501ce8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11f0>
100501498:     	ldr	x8, [x20, #0x10]
10050149c:     	str	x25, [x8, x26, lsl #3]
1005014a0:     	add	x8, x26, #0x1
1005014a4:     	str	x8, [x20, #0x18]
1005014a8:     	ldr	x8, [x20]
1005014ac:     	add	x8, x8, #0x1
1005014b0:     	str	x8, [x20]
1005014b4:     	mov	w25, #0x1               ; =1
1005014b8:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
1005014bc:     	ldr	w24, [x8, #0x308]
1005014c0:     	cmp	w24, #0x300
1005014c4:     	b.lo	0x1005014e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9e8>
1005014c8:     	b	0x100501c84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x118c>
1005014cc:     	mov	w25, #0x0               ; =0
1005014d0:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
1005014d4:     	ldr	w24, [x8, #0x308]
1005014d8:     	cmp	w24, #0x300
1005014dc:     	b.hs	0x100501c84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x118c>
1005014e0:     	ldr	x8, [x27, #0x48]
1005014e4:     	cmn	x8, #0x1
1005014e8:     	b.eq	0x100501c74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x117c>
1005014ec:     	mrs	x9, TPIDRRO_EL0
1005014f0:     	and	x9, x9, #0xfffffffffffffff8
1005014f4:     	ldr	x0, [x9, x8, lsl #3]
1005014f8:     	cbz	x0, 0x100501c74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x117c>
1005014fc:     	add	x8, x0, x24, lsl #3
100501500:     	ldr	x0, [x8, #0x1e8]
100501504:     	cbz	x0, 0x100501c84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x118c>
100501508:     	ldrb	w8, [x0]
10050150c:     	and	w8, w8, #0xfffffffd
100501510:     	strb	w8, [x0]
100501514:     	mov	w0, #0x0                ; =0
100501518:     	bl	0x100458940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
10050151c:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
100501520:     	ldr	w24, [x8, #0x590]
100501524:     	cmp	w24, #0x300
100501528:     	b.hs	0x100501ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11ac>
10050152c:     	ldr	x8, [x27, #0x48]
100501530:     	cmn	x8, #0x1
100501534:     	b.eq	0x100501c94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x119c>
100501538:     	mrs	x9, TPIDRRO_EL0
10050153c:     	and	x9, x9, #0xfffffffffffffff8
100501540:     	ldr	x0, [x9, x8, lsl #3]
100501544:     	cbz	x0, 0x100501c94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x119c>
100501548:     	add	x8, x0, x24, lsl #3
10050154c:     	ldr	x0, [x8, #0x1e8]
100501550:     	cbz	x0, 0x100501ca4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11ac>
100501554:     	ldr	x8, [x0]
100501558:     	lsr	x8, x8, #25
10050155c:     	cbz	x8, 0x100501cbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11c4>
100501560:     	bl	0x10045a8f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100501564:     	cmp	x23, #0x3e8
100501568:     	b.hi	0x100501cc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11cc>
10050156c:     	ldp	x1, x0, [sp]
100501570:     	bl	0x10022edb8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100501574:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100501578:     	ldr	x8, [x8, #0x758]
10050157c:     	cbnz	x8, 0x100501cdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11e4>
100501580:     	tbz	w25, #0x0, 0x1005015c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xad0>
100501584:     	ldrb	w8, [x20, #0x20]
100501588:     	cbnz	w8, 0x100501f64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x146c>
10050158c:     	ldr	x8, [x20]
100501590:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501594:     	cmp	x8, x9
100501598:     	b.hs	0x100501f90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1498>
10050159c:     	add	x9, x8, #0x1
1005015a0:     	str	x9, [x20]
1005015a4:     	ldr	x9, [x20, #0x18]
1005015a8:     	cmp	x26, x9
1005015ac:     	b.hs	0x1005015bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xac4>
1005015b0:     	ldr	x9, [x20, #0x10]
1005015b4:     	ldr	x23, [x9, x26, lsl #3]
1005015b8:     	b	0x1005015c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xacc>
1005015bc:     	mov	x23, #0x1               ; =1
1005015c0:     	movk	x23, #0x7ffc, lsl #48
1005015c4:     	str	x8, [x20]
1005015c8:     	str	xzr, [sp, #0xb0]
1005015cc:     	str	xzr, [sp, #0xc8]
1005015d0:     	ldr	x8, [sp, #0xa0]
1005015d4:     	add	x9, x8, x8, lsl #1
1005015d8:     	lsl	x9, x9, #2
1005015dc:     	cmp	x9, #0x100, lsl #12     ; =0x100000
1005015e0:     	b.ls	0x1005015fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb04>
1005015e4:     	cbz	x8, 0x1005015f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xaf8>
1005015e8:     	ldr	x0, [sp, #0xa8]
1005015ec:     	bl	0x100b55980 <_mi_free>
1005015f0:     	mov	w8, #0x4                ; =4
1005015f4:     	stp	xzr, x8, [sp, #0xa0]
1005015f8:     	str	xzr, [sp, #0xb0]
1005015fc:     	ldr	x8, [sp, #0xb8]
100501600:     	lsl	x9, x8, #2
100501604:     	cmp	x9, #0x10, lsl #12      ; =0x10000
100501608:     	b.ls	0x100501624 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb2c>
10050160c:     	cbz	x8, 0x100501618 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb20>
100501610:     	ldr	x0, [sp, #0xc0]
100501614:     	bl	0x100b55980 <_mi_free>
100501618:     	mov	w8, #0x4                ; =4
10050161c:     	stp	xzr, x8, [sp, #0xb8]
100501620:     	str	xzr, [sp, #0xc8]
100501624:     	ldp	x8, x0, [x22]
100501628:     	ldp	x26, x24, [x22, #0x18]
10050162c:     	ldp	q1, q0, [sp, #0xb0]
100501630:     	ldr	q2, [sp, #0xa0]
100501634:     	stp	q2, q1, [x22]
100501638:     	str	q0, [x22, #0x20]
10050163c:     	cmn	x8, #0x1
100501640:     	b.eq	0x1005016f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbfc>
100501644:     	cbz	x8, 0x10050164c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb54>
100501648:     	bl	0x100b55980 <_mi_free>
10050164c:     	cbz	x26, 0x1005016f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbfc>
100501650:     	mov	x0, x24
100501654:     	bl	0x100b55980 <_mi_free>
100501658:     	ldrb	w8, [x20, #0x20]
10050165c:     	adrp	x26, 0x100f76000 <__MergedGlobals.1914+0xc8>
100501660:     	tbnz	w25, #0x0, 0x100501700 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc08>
100501664:     	cbnz	w8, 0x100501e5c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1364>
100501668:     	ldr	x8, [x20]
10050166c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501670:     	cmp	x8, x9
100501674:     	b.hs	0x100501f90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1498>
100501678:     	add	x9, x8, #0x1
10050167c:     	str	x9, [x20]
100501680:     	ldr	x9, [x20, #0x18]
100501684:     	cmp	x21, x9
100501688:     	b.hs	0x1005016ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbb4>
10050168c:     	ldr	x9, [x20, #0x10]
100501690:     	ldr	x9, [x9, x21, lsl #3]
100501694:     	and	x22, x9, #0xffffffffffff
100501698:     	str	x8, [x20]
10050169c:     	cmp	x19, #0x3e8
1005016a0:     	csel	w8, wzr, w28, ls
1005016a4:     	cbnz	w8, 0x1005016c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbc8>
1005016a8:     	b	0x100501744 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc4c>
1005016ac:     	mov	w22, #0x1               ; =1
1005016b0:     	str	x8, [x20]
1005016b4:     	cmp	x19, #0x3e8
1005016b8:     	csel	w8, wzr, w28, ls
1005016bc:     	cbz	w8, 0x100501744 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc4c>
1005016c0:     	mov	x8, #0x0                ; =0
1005016c4:     	mov	x9, #0x2600             ; =9728
1005016c8:     	movk	x9, #0x1, lsl #32
1005016cc:     	add	x10, x22, x8
1005016d0:     	ldrb	w10, [x10, #0x14]
1005016d4:     	cmp	w10, #0x20
1005016d8:     	b.hi	0x100501720 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc28>
1005016dc:     	lsr	x11, x9, x10
1005016e0:     	tbz	w11, #0x0, 0x100501720 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc28>
1005016e4:     	add	x8, x8, #0x1
1005016e8:     	cmp	x19, x8
1005016ec:     	b.ne	0x1005016cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xbd4>
1005016f0:     	b	0x100501744 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc4c>
1005016f4:     	ldrb	w8, [x20, #0x20]
1005016f8:     	adrp	x26, 0x100f76000 <__MergedGlobals.1914+0xc8>
1005016fc:     	cbz	w25, 0x100501664 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb6c>
100501700:     	cbnz	w8, 0x100501f9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14a4>
100501704:     	ldr	x8, [x20]
100501708:     	cbnz	x8, 0x100501fcc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14d4>
10050170c:     	ldr	x8, [x20, #0x18]
100501710:     	cmp	x21, x8
100501714:     	b.hi	0x100501b14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x101c>
100501718:     	str	x21, [x20, #0x18]
10050171c:     	b	0x100501b14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x101c>
100501720:     	cmp	w10, #0x5b
100501724:     	b.eq	0x100501730 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc38>
100501728:     	cmp	w10, #0x7b
10050172c:     	b.ne	0x100501744 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc4c>
100501730:     	add	x0, x22, #0x14
100501734:     	mov	x1, x19
100501738:     	mov	w2, #0x3e8              ; =1000
10050173c:     	bl	0x1006be514 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser12depth_blocks21nesting_depth_exceeds>
100501740:     	cbnz	w0, 0x100501e10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1318>
100501744:     	ldr	w22, [x26, #0x590]
100501748:     	cmp	w22, #0x300
10050174c:     	b.hs	0x100501a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf3c>
100501750:     	ldr	x8, [x27, #0x48]
100501754:     	cmn	x8, #0x1
100501758:     	b.eq	0x100501a24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf2c>
10050175c:     	mrs	x9, TPIDRRO_EL0
100501760:     	and	x9, x9, #0xfffffffffffffff8
100501764:     	ldr	x0, [x9, x8, lsl #3]
100501768:     	cbz	x0, 0x100501a24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf2c>
10050176c:     	add	x8, x0, x22, lsl #3
100501770:     	ldr	x0, [x8, #0x1e8]
100501774:     	cbz	x0, 0x100501a34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf3c>
100501778:     	bl	0x100219cb0 <__RNCNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary0B7_>
10050177c:     	bl	0x100455200 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy16gc_check_trigger>
100501780:     	mov	x0, x19
100501784:     	bl	0x10022ec6c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation5begin>
100501788:     	mov	x24, x0
10050178c:     	mov	x22, x1
100501790:     	bl	0x100455014 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy11gc_suppress>
100501794:     	ldrb	w8, [x20, #0x20]
100501798:     	cbnz	w8, 0x100501d9c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12a4>
10050179c:     	ldr	x8, [x20]
1005017a0:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1005017a4:     	cmp	x8, x9
1005017a8:     	b.hs	0x100501f90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1498>
1005017ac:     	add	x9, x8, #0x1
1005017b0:     	str	x9, [x20]
1005017b4:     	ldr	x9, [x20, #0x18]
1005017b8:     	cmp	x21, x9
1005017bc:     	b.hs	0x1005017d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcdc>
1005017c0:     	ldr	x9, [x20, #0x10]
1005017c4:     	ldr	x9, [x9, x21, lsl #3]
1005017c8:     	and	x25, x9, #0xffffffffffff
1005017cc:     	add	x1, x25, #0x14
1005017d0:     	b	0x1005017dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xce4>
1005017d4:     	mov	w25, #0x1               ; =1
1005017d8:     	mov	w1, #0x15               ; =21
1005017dc:     	str	x8, [x20]
1005017e0:     	add	x0, sp, #0xa0
1005017e4:     	mov	x2, x19
1005017e8:     	mov	x3, x25
1005017ec:     	bl	0x10025c460 <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23new_batched_from_string>
1005017f0:     	add	x0, sp, #0xa0
1005017f4:     	bl	0x10025959c <__RNvMs1_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
1005017f8:     	mov	x23, x0
1005017fc:     	ldp	x26, x28, [sp, #0x108]
100501800:     	cmp	x28, x26
100501804:     	b.hs	0x100501838 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd40>
100501808:     	ldr	x8, [sp, #0x100]
10050180c:     	mov	x9, #0x2600             ; =9728
100501810:     	movk	x9, #0x1, lsl #32
100501814:     	ldrb	w10, [x8, x28]
100501818:     	cmp	w10, #0x20
10050181c:     	b.hi	0x100501838 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd40>
100501820:     	lsr	x10, x9, x10
100501824:     	tbz	w10, #0x0, 0x100501838 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd40>
100501828:     	add	x28, x28, #0x1
10050182c:     	cmp	x26, x28
100501830:     	b.ne	0x100501814 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd1c>
100501834:     	mov	x28, x26
100501838:     	ldrb	w8, [sp, #0x176]
10050183c:     	tbnz	w8, #0x0, 0x100501cf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x11fc>
100501840:     	cmp	x28, x26
100501844:     	b.ne	0x100501d00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1208>
100501848:     	ldrb	w8, [sp, #0x174]
10050184c:     	tbz	w8, #0x0, 0x100501d00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1208>
100501850:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
100501854:     	ldr	w26, [x8, #0x560]
100501858:     	cmp	w26, #0x300
10050185c:     	b.hs	0x100501a54 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf5c>
100501860:     	ldr	x8, [x27, #0x48]
100501864:     	cmn	x8, #0x1
100501868:     	b.eq	0x100501a44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf4c>
10050186c:     	mrs	x9, TPIDRRO_EL0
100501870:     	and	x9, x9, #0xfffffffffffffff8
100501874:     	ldr	x0, [x9, x8, lsl #3]
100501878:     	cbz	x0, 0x100501a44 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf4c>
10050187c:     	add	x8, x0, x26, lsl #3
100501880:     	ldr	x0, [x8, #0x1e8]
100501884:     	cbz	x0, 0x100501a54 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf5c>
100501888:     	ldr	x8, [x0]
10050188c:     	cbnz	x8, 0x100501a68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf70>
100501890:     	ldrb	w8, [x0, #0x24]
100501894:     	cmp	w8, #0x2
100501898:     	b.eq	0x1005018bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdc4>
10050189c:     	ldr	x8, [x0, #0x8]
1005018a0:     	cmp	x8, x25
1005018a4:     	b.ne	0x1005018bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdc4>
1005018a8:     	ldr	w8, [x0, #0x18]
1005018ac:     	cmp	x19, x8
1005018b0:     	b.ne	0x1005018bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xdc4>
1005018b4:     	mov	w8, #0x1                ; =1
1005018b8:     	strb	w8, [x0, #0x24]
1005018bc:     	mov	x0, x25
1005018c0:     	mov	x1, x19
1005018c4:     	mov	x2, x23
1005018c8:     	bl	0x1004e7d00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse30remember_parse_object_template>
1005018cc:     	ldrb	w8, [x20, #0x20]
1005018d0:     	adrp	x25, 0x100f76000 <__MergedGlobals.1914+0xc8>
1005018d4:     	cbnz	w8, 0x100501dcc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12d4>
1005018d8:     	ldr	x8, [x20]
1005018dc:     	cbnz	x8, 0x100501df0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f8>
1005018e0:     	mov	x8, #-0x1               ; =-1
1005018e4:     	str	x8, [x20]
1005018e8:     	ldr	x19, [x20, #0x18]
1005018ec:     	ldr	x8, [x20, #0x8]
1005018f0:     	cmp	x19, x8
1005018f4:     	b.eq	0x100501a74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf7c>
1005018f8:     	ldr	x8, [x20, #0x10]
1005018fc:     	str	x23, [x8, x19, lsl #3]
100501900:     	add	x8, x19, #0x1
100501904:     	str	x8, [x20, #0x18]
100501908:     	ldr	x8, [x20]
10050190c:     	add	x8, x8, #0x1
100501910:     	str	x8, [x20]
100501914:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
100501918:     	ldr	w19, [x8, #0x308]
10050191c:     	cmp	w19, #0x300
100501920:     	b.hs	0x100501a90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf98>
100501924:     	ldr	x8, [x27, #0x48]
100501928:     	cmn	x8, #0x1
10050192c:     	b.eq	0x100501a80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf88>
100501930:     	mrs	x9, TPIDRRO_EL0
100501934:     	and	x9, x9, #0xfffffffffffffff8
100501938:     	ldr	x0, [x9, x8, lsl #3]
10050193c:     	cbz	x0, 0x100501a80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf88>
100501940:     	add	x8, x0, x19, lsl #3
100501944:     	ldr	x0, [x8, #0x1e8]
100501948:     	cbz	x0, 0x100501a90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xf98>
10050194c:     	ldrb	w8, [x0]
100501950:     	and	w8, w8, #0xfffffffd
100501954:     	strb	w8, [x0]
100501958:     	mov	w0, #0x0                ; =0
10050195c:     	bl	0x100458940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy28gc_bump_malloc_trigger_inner>
100501960:     	ldr	w19, [x25, #0x590]
100501964:     	cmp	w19, #0x300
100501968:     	b.hs	0x100501ab0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfb8>
10050196c:     	ldr	x8, [x27, #0x48]
100501970:     	cmn	x8, #0x1
100501974:     	b.eq	0x100501aa0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa8>
100501978:     	mrs	x9, TPIDRRO_EL0
10050197c:     	and	x9, x9, #0xfffffffffffffff8
100501980:     	ldr	x0, [x9, x8, lsl #3]
100501984:     	cbz	x0, 0x100501aa0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfa8>
100501988:     	add	x8, x0, x19, lsl #3
10050198c:     	ldr	x0, [x8, #0x1e8]
100501990:     	cbz	x0, 0x100501ab0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfb8>
100501994:     	ldr	x8, [x0]
100501998:     	lsr	x8, x8, #25
10050199c:     	cbz	x8, 0x100501ac8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfd0>
1005019a0:     	bl	0x10045a8f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1005019a4:     	bl	0x10045cc20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
1005019a8:     	mov	x0, x24
1005019ac:     	mov	x1, x22
1005019b0:     	bl	0x10022edb8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
1005019b4:     	ldrb	w8, [x20, #0x20]
1005019b8:     	cbz	w8, 0x100501ae0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xfe8>
1005019bc:     	cmp	w8, #0x2
1005019c0:     	b.eq	0x100501fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ac>
1005019c4:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
1005019c8:     	add	x1, x1, #0x58
1005019cc:     	mov	x0, x20
1005019d0:     	bl	0x100a16e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1005019d4:     	strb	wzr, [x20, #0x20]
1005019d8:     	ldr	x8, [x20]
1005019dc:     	cbz	x8, 0x100501ae8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xff0>
1005019e0:     	b	0x100501fcc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14d4>
1005019e4:     	add	x0, x20, #0x8
1005019e8:     	bl	0x100b3266c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1005019ec:     	b	0x1005010d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5e0>
1005019f0:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1005019f4:     	add	x8, x0, x23, lsl #3
1005019f8:     	ldr	x0, [x8, #0x1e8]
1005019fc:     	cbnz	x0, 0x10050112c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x634>
100501a00:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
100501a04:     	add	x0, x0, #0xcf0
100501a08:     	bl	0x100b335e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100501a0c:     	ldrb	w8, [x0]
100501a10:     	cbz	w8, 0x100501134 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x63c>
100501a14:     	bl	0x100b3ad1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
100501a18:     	adrp	x26, 0x100f76000 <__MergedGlobals.1914+0xc8>
100501a1c:     	tbnz	w22, #0x0, 0x10050113c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x644>
100501a20:     	b	0x100501744 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc4c>
100501a24:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501a28:     	add	x8, x0, x22, lsl #3
100501a2c:     	ldr	x0, [x8, #0x1e8]
100501a30:     	cbnz	x0, 0x100501778 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc80>
100501a34:     	adrp	x0, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
100501a38:     	add	x0, x0, #0x90
100501a3c:     	bl	0x100b3359c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100501a40:     	b	0x100501778 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc80>
100501a44:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501a48:     	add	x8, x0, x26, lsl #3
100501a4c:     	ldr	x0, [x8, #0x1e8]
100501a50:     	cbnz	x0, 0x100501888 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd90>
100501a54:     	adrp	x0, 0x100f03000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1e70>
100501a58:     	add	x0, x0, #0xfe8
100501a5c:     	bl	0x100b3359c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100501a60:     	ldr	x8, [x0]
100501a64:     	cbz	x8, 0x100501890 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd98>
100501a68:     	adrp	x0, 0x100ef1000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100501a6c:     	add	x0, x0, #0xcf8
100501a70:     	bl	0x100b090ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100501a74:     	add	x0, x20, #0x8
100501a78:     	bl	0x100b3266c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100501a7c:     	b	0x1005018f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe00>
100501a80:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501a84:     	add	x8, x0, x19, lsl #3
100501a88:     	ldr	x0, [x8, #0x1e8]
100501a8c:     	cbnz	x0, 0x10050194c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe54>
100501a90:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
100501a94:     	add	x0, x0, #0xd20
100501a98:     	bl	0x100b335e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100501a9c:     	b	0x10050194c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe54>
100501aa0:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501aa4:     	add	x8, x0, x19, lsl #3
100501aa8:     	ldr	x0, [x8, #0x1e8]
100501aac:     	cbnz	x0, 0x100501994 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xe9c>
100501ab0:     	adrp	x0, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
100501ab4:     	add	x0, x0, #0x90
100501ab8:     	bl	0x100b3359c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100501abc:     	ldr	x8, [x0]
100501ac0:     	lsr	x8, x8, #25
100501ac4:     	cbnz	x8, 0x1005019a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xea8>
100501ac8:     	bl	0x10045cc20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100501acc:     	mov	x0, x24
100501ad0:     	mov	x1, x22
100501ad4:     	bl	0x10022edb8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100501ad8:     	ldrb	w8, [x20, #0x20]
100501adc:     	cbnz	w8, 0x1005019bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xec4>
100501ae0:     	ldr	x8, [x20]
100501ae4:     	cbnz	x8, 0x100501fcc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14d4>
100501ae8:     	ldr	x8, [x20, #0x18]
100501aec:     	cmp	x21, x8
100501af0:     	b.ls	0x100501b38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1040>
100501af4:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100501af8:     	ldr	x8, [x8, #0x758]
100501afc:     	cbnz	x8, 0x100501b48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1050>
100501b00:     	ldr	x8, [sp, #0xd8]
100501b04:     	cmp	x8, #0x1
100501b08:     	b.lt	0x100501b14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x101c>
100501b0c:     	ldr	x0, [sp, #0xe0]
100501b10:     	bl	0x100b55980 <_mi_free>
100501b14:     	mov	x0, x23
100501b18:     	add	sp, sp, #0x1a0
100501b1c:     	ldp	x29, x30, [sp, #0x50]
100501b20:     	ldp	x20, x19, [sp, #0x40]
100501b24:     	ldp	x22, x21, [sp, #0x30]
100501b28:     	ldp	x24, x23, [sp, #0x20]
100501b2c:     	ldp	x26, x25, [sp, #0x10]
100501b30:     	ldp	x28, x27, [sp], #0x60
100501b34:     	ret
100501b38:     	str	x21, [x20, #0x18]
100501b3c:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100501b40:     	ldr	x8, [x8, #0x758]
100501b44:     	cbz	x8, 0x100501b00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1008>
100501b48:     	bl	0x100b3c438 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100501b4c:     	ldr	x8, [sp, #0xd8]
100501b50:     	cmp	x8, #0x1
100501b54:     	b.ge	0x100501b0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1014>
100501b58:     	b	0x100501b14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x101c>
100501b5c:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501b60:     	add	x8, x0, x20, lsl #3
100501b64:     	ldr	x0, [x8, #0x1e8]
100501b68:     	cbnz	x0, 0x100500fe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4ec>
100501b6c:     	adrp	x0, 0x100f03000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1e70>
100501b70:     	add	x0, x0, #0xfe8
100501b74:     	bl	0x100b3359c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100501b78:     	ldr	x8, [x0]
100501b7c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501b80:     	cmp	x8, x9
100501b84:     	b.lo	0x100500ff4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4fc>
100501b88:     	adrp	x0, 0x100ef1000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100501b8c:     	add	x0, x0, #0xd10
100501b90:     	bl	0x100b0911c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100501b94:     	cmp	w10, #0x5b
100501b98:     	cset	w22, eq
100501b9c:     	mov	w8, #0x1000000          ; =16777216
100501ba0:     	cmp	x19, x8
100501ba4:     	mov	w8, #0x5b               ; =91
100501ba8:     	ccmp	w10, w8, #0x0, ls
100501bac:     	b.ne	0x100500fb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x4b8>
100501bb0:     	mov	w28, #0x1               ; =1
100501bb4:     	mov	w22, #0x1               ; =1
100501bb8:     	b	0x100501094 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x59c>
100501bbc:     	mov	w1, #0x0                ; =0
100501bc0:     	ldr	x8, [sp, #0xa0]
100501bc4:     	add	x8, x8, x8, lsl #1
100501bc8:     	lsl	x8, x8, #2
100501bcc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100501bd0:     	b.ls	0x100501bf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x10fc>
100501bd4:     	ldr	q0, [sp, #0xa0]
100501bd8:     	str	q0, [sp, #0x10]
100501bdc:     	ldr	x8, [sp, #0xb0]
100501be0:     	str	x8, [sp, #0x20]
100501be4:     	mov	w8, #0x4                ; =4
100501be8:     	stp	xzr, x8, [sp, #0xa0]
100501bec:     	str	xzr, [sp, #0xb0]
100501bf0:     	b	0x100501c00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1108>
100501bf4:     	stp	x24, x25, [sp, #0x18]
100501bf8:     	mov	x8, #-0x1               ; =-1
100501bfc:     	str	x8, [sp, #0x10]
100501c00:     	add	x0, sp, #0x10
100501c04:     	bl	0x100372270 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape24alloc_lazy_array_backing>
100501c08:     	mov	x25, #0x7ffd000000000000 ; =9222527611924643840
100501c0c:     	bfxil	x25, x0, #0, #48
100501c10:     	ldrb	w8, [x20, #0x20]
100501c14:     	cbz	w8, 0x100501478 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x980>
100501c18:     	b	0x100501420 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x928>
100501c1c:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501c20:     	add	x8, x0, x24, lsl #3
100501c24:     	ldr	x0, [x8, #0x1e8]
100501c28:     	cbnz	x0, 0x100501248 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x750>
100501c2c:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
100501c30:     	add	x0, x0, #0xcf0
100501c34:     	bl	0x100b335e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100501c38:     	ldrb	w8, [x0]
100501c3c:     	cbz	w8, 0x100501250 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x758>
100501c40:     	bl	0x100b3ad1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
100501c44:     	ldr	w24, [x26, #0x590]
100501c48:     	cmp	w24, #0x300
100501c4c:     	b.lo	0x10050125c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x764>
100501c50:     	b	0x100501c64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x116c>
100501c54:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501c58:     	add	x8, x0, x24, lsl #3
100501c5c:     	ldr	x0, [x8, #0x1e8]
100501c60:     	cbnz	x0, 0x100501284 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x78c>
100501c64:     	adrp	x0, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
100501c68:     	add	x0, x0, #0x90
100501c6c:     	bl	0x100b3359c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100501c70:     	b	0x100501284 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x78c>
100501c74:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501c78:     	add	x8, x0, x24, lsl #3
100501c7c:     	ldr	x0, [x8, #0x1e8]
100501c80:     	cbnz	x0, 0x100501508 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa10>
100501c84:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
100501c88:     	add	x0, x0, #0xd20
100501c8c:     	bl	0x100b335e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
100501c90:     	b	0x100501508 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa10>
100501c94:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100501c98:     	add	x8, x0, x24, lsl #3
100501c9c:     	ldr	x0, [x8, #0x1e8]
100501ca0:     	cbnz	x0, 0x100501554 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa5c>
100501ca4:     	adrp	x0, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
100501ca8:     	add	x0, x0, #0x90
100501cac:     	bl	0x100b3359c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100501cb0:     	ldr	x8, [x0]
100501cb4:     	lsr	x8, x8, #25
100501cb8:     	cbnz	x8, 0x100501560 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa68>
100501cbc:     	cmp	x23, #0x3e8
100501cc0:     	b.ls	0x10050156c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa74>
100501cc4:     	bl	0x10045cc20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100501cc8:     	ldp	x1, x0, [sp]
100501ccc:     	bl	0x10022edb8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100501cd0:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100501cd4:     	ldr	x8, [x8, #0x758]
100501cd8:     	cbz	x8, 0x100501580 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa88>
100501cdc:     	bl	0x100b3c438 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100501ce0:     	tbnz	w25, #0x0, 0x100501584 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xa8c>
100501ce4:     	b	0x1005015c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xad0>
100501ce8:     	add	x0, x20, #0x8
100501cec:     	bl	0x100b3266c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100501cf0:     	b	0x100501498 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x9a0>
100501cf4:     	bl	0x100b3c20c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar15clear_key_cache>
100501cf8:     	cmp	x28, x26
100501cfc:     	b.eq	0x100501848 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xd50>
100501d00:     	mov	x0, x23
100501d04:     	bl	0x100323308 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15parse_root_push>
100501d08:     	bl	0x10045517c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy13gc_unsuppress>
100501d0c:     	bl	0x1004ea564 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat26finish_parse_gc_accounting>
100501d10:     	bl	0x10045cc20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
100501d14:     	mov	x0, x24
100501d18:     	mov	x1, x22
100501d1c:     	bl	0x10022edb8 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime2gc10json_deferNtB2_19JsonParseAllocation6finish>
100501d20:     	mov	x0, x21
100501d24:     	bl	0x100323518 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100501d28:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
100501d2c:     	ldr	x8, [x8, #0x758]
100501d30:     	cbnz	x8, 0x100502274 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x177c>
100501d34:     	adrp	x0, 0x100c6b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x651c>
100501d38:     	add	x0, x0, #0xfa0
100501d3c:     	mov	w1, #0x21               ; =33
100501d40:     	bl	0x100503850 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
100501d44:     	cmp	x9, #0x6
100501d48:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100501d4c:     	ldrb	w8, [x21, #0x1a]
100501d50:     	cmp	w8, #0x22
100501d54:     	b.ne	0x100501ec0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13c8>
100501d58:     	mov	w20, #0x0               ; =0
100501d5c:     	mov	w23, #0x0               ; =0
100501d60:     	mov	w28, #0x0               ; =0
100501d64:     	mov	w8, #0x1                ; =1
100501d68:     	str	w8, [sp, #0x8]
100501d6c:     	mov	w26, #0x4               ; =4
100501d70:     	b	0x100500ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1a8>
100501d74:     	cmp	w8, #0x2
100501d78:     	b.eq	0x100501fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ac>
100501d7c:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501d80:     	add	x1, x1, #0x58
100501d84:     	mov	x0, x20
100501d88:     	bl	0x100a16e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501d8c:     	strb	wzr, [x20, #0x20]
100501d90:     	ldr	x8, [x20]
100501d94:     	cbz	x8, 0x1005010b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x5c0>
100501d98:     	b	0x100501df0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x12f8>
100501d9c:     	cmp	w8, #0x2
100501da0:     	b.eq	0x100501fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ac>
100501da4:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501da8:     	add	x1, x1, #0x58
100501dac:     	mov	x0, x20
100501db0:     	bl	0x100a16e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501db4:     	strb	wzr, [x20, #0x20]
100501db8:     	ldr	x8, [x20]
100501dbc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501dc0:     	cmp	x8, x9
100501dc4:     	b.lo	0x1005017ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xcb4>
100501dc8:     	b	0x100501f90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1498>
100501dcc:     	cmp	w8, #0x2
100501dd0:     	b.eq	0x100501fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ac>
100501dd4:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501dd8:     	add	x1, x1, #0x58
100501ddc:     	mov	x0, x20
100501de0:     	bl	0x100a16e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501de4:     	strb	wzr, [x20, #0x20]
100501de8:     	ldr	x8, [x20]
100501dec:     	cbz	x8, 0x1005018e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xde8>
100501df0:     	adrp	x0, 0x100eee000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100501df4:     	add	x0, x0, #0x428
100501df8:     	bl	0x100b090ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100501dfc:     	mov	x0, x22
100501e00:     	bl	0x100b14eec <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11TapeScratchEEuE16get_or_init_slowNvNvB2b_12TAPE_SCRATCH27___rust_std_internal_init_fnEB2d_>
100501e04:     	mov	x22, x0
100501e08:     	cbnz	x0, 0x1005011a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x6a8>
100501e0c:     	b	0x100501fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ac>
100501e10:     	mov	x0, x21
100501e14:     	bl	0x100323518 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json18parse_root_restore>
100501e18:     	mov	x0, x22
100501e1c:     	mov	x1, x19
100501e20:     	bl	0x100b3c7a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api19parse_deep_or_throw>
100501e24:     	mov	x23, x0
100501e28:     	b	0x100501b14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x101c>
100501e2c:     	cmp	w8, #0x2
100501e30:     	b.eq	0x100501fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ac>
100501e34:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501e38:     	add	x1, x1, #0x58
100501e3c:     	mov	x0, x20
100501e40:     	bl	0x100a16e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501e44:     	strb	wzr, [x20, #0x20]
100501e48:     	ldr	x8, [x20]
100501e4c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501e50:     	cmp	x8, x9
100501e54:     	b.lo	0x100501154 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x65c>
100501e58:     	b	0x100501f90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1498>
100501e5c:     	cmp	w8, #0x2
100501e60:     	b.eq	0x100501fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ac>
100501e64:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501e68:     	add	x1, x1, #0x58
100501e6c:     	mov	x0, x20
100501e70:     	bl	0x100a16e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501e74:     	strb	wzr, [x20, #0x20]
100501e78:     	ldr	x8, [x20]
100501e7c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501e80:     	cmp	x8, x9
100501e84:     	b.lo	0x100501678 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xb80>
100501e88:     	b	0x100501f90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1498>
100501e8c:     	cmp	x9, #0x1
100501e90:     	b.ne	0x100501f1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1424>
100501e94:     	ldrb	w8, [x8]
100501e98:     	sub	w9, w8, #0x30
100501e9c:     	cmp	w9, #0xa
100501ea0:     	b.hs	0x100501f20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1428>
100501ea4:     	and	w8, w9, #0xff
100501ea8:     	ucvtf	d0, w8
100501eac:     	fmov	x1, d0
100501eb0:     	orr	x0, x25, x28
100501eb4:     	bl	0x1004f0494 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json19parse_inline_object18allocate_one_field>
100501eb8:     	tbz	w0, #0x0, 0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100501ebc:     	b	0x100500ef0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x3f8>
100501ec0:     	cmp	x9, #0x7
100501ec4:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100501ec8:     	ldrb	w8, [x21, #0x1b]
100501ecc:     	cmp	w8, #0x22
100501ed0:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100501ed4:     	mov	w20, #0x0               ; =0
100501ed8:     	mov	w23, #0x0               ; =0
100501edc:     	mov	w28, #0x0               ; =0
100501ee0:     	str	wzr, [sp, #0x8]
100501ee4:     	mov	w26, #0x5               ; =5
100501ee8:     	b	0x100500ca0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1a8>
100501eec:     	cmp	w8, #0x2
100501ef0:     	b.eq	0x100501fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ac>
100501ef4:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501ef8:     	add	x1, x1, #0x58
100501efc:     	mov	x0, x20
100501f00:     	bl	0x100a16e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501f04:     	strb	wzr, [x20, #0x20]
100501f08:     	ldr	x8, [x20]
100501f0c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501f10:     	cmp	x8, x9
100501f14:     	b.lo	0x1005012b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x7c0>
100501f18:     	b	0x100501f90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1498>
100501f1c:     	ldrb	w8, [x8]
100501f20:     	orr	w8, w8, #0x20
100501f24:     	cmp	w8, #0x7b
100501f28:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100501f2c:     	mov	x20, x26
100501f30:     	sub	x11, x19, #0x5
100501f34:     	mov	x10, #0x2600            ; =9728
100501f38:     	movk	x10, #0x1, lsl #32
100501f3c:     	add	x8, x21, x20
100501f40:     	ldrb	w9, [x8, #0x18]
100501f44:     	cmp	w9, #0x20
100501f48:     	b.hi	0x100501fd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14e0>
100501f4c:     	lsr	x12, x10, x9
100501f50:     	tbz	w12, #0x0, 0x100501fd8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14e0>
100501f54:     	add	x20, x20, #0x1
100501f58:     	cmp	x11, x20
100501f5c:     	b.ne	0x100501f3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1444>
100501f60:     	b	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100501f64:     	cmp	w8, #0x2
100501f68:     	b.eq	0x100501fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14ac>
100501f6c:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501f70:     	add	x1, x1, #0x58
100501f74:     	mov	x0, x20
100501f78:     	bl	0x100a16e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501f7c:     	strb	wzr, [x20, #0x20]
100501f80:     	ldr	x8, [x20]
100501f84:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100501f88:     	cmp	x8, x9
100501f8c:     	b.lo	0x10050159c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xaa4>
100501f90:     	adrp	x0, 0x100eee000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100501f94:     	add	x0, x0, #0x3f8
100501f98:     	bl	0x100b0911c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100501f9c:     	cmp	w8, #0x2
100501fa0:     	b.ne	0x100501fb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14b8>
100501fa4:     	adrp	x0, 0x100eea000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100501fa8:     	add	x0, x0, #0xc18
100501fac:     	bl	0x100b4efdc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100501fb0:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100501fb4:     	add	x1, x1, #0x58
100501fb8:     	mov	x0, x20
100501fbc:     	bl	0x100a16e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100501fc0:     	strb	wzr, [x20, #0x20]
100501fc4:     	ldr	x8, [x20]
100501fc8:     	cbz	x8, 0x10050170c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0xc14>
100501fcc:     	adrp	x0, 0x100eee000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100501fd0:     	add	x0, x0, #0x488
100501fd4:     	bl	0x100b090ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100501fd8:     	cmp	x11, x20
100501fdc:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100501fe0:     	add	x13, x21, #0x12
100501fe4:     	mov	x14, #0x2600            ; =9728
100501fe8:     	movk	x14, #0x1, lsl #32
100501fec:     	mov	x10, x20
100501ff0:     	ldrb	w12, [x13, x19]
100501ff4:     	cmp	w12, #0x20
100501ff8:     	b.hi	0x100502018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1520>
100501ffc:     	lsr	x15, x14, x12
100502000:     	tbz	w15, #0x0, 0x100502018 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1520>
100502004:     	sub	x13, x13, #0x1
100502008:     	add	x10, x10, #0x1
10050200c:     	cmp	x11, x10
100502010:     	b.ne	0x100501ff0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x14f8>
100502014:     	b	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100502018:     	sub	x11, x19, x10
10050201c:     	sub	x1, x11, #0x5
100502020:     	cmp	x1, #0x4
100502024:     	b.eq	0x1005020a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15a8>
100502028:     	cmp	x1, #0x5
10050202c:     	b.ne	0x1005020a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15b0>
100502030:     	cmp	w9, #0x22
100502034:     	b.eq	0x1005020d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15dc>
100502038:     	cmp	w9, #0x2d
10050203c:     	b.eq	0x1005020c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15cc>
100502040:     	cmp	w9, #0x66
100502044:     	b.ne	0x1005020b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15c0>
100502048:     	add	x8, x21, x20
10050204c:     	ldrb	w9, [x8, #0x19]
100502050:     	cmp	w9, #0x61
100502054:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100502058:     	ldrb	w8, [x8, #0x1a]
10050205c:     	cmp	w8, #0x6c
100502060:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100502064:     	add	x8, x21, x20
100502068:     	ldrb	w9, [x8, #0x1b]
10050206c:     	cmp	w9, #0x73
100502070:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100502074:     	ldrb	w8, [x8, #0x1c]
100502078:     	cmp	w8, #0x65
10050207c:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100502080:     	mov	x8, #0x1                ; =1
100502084:     	movk	x8, #0x7ffc, lsl #48
100502088:     	orr	x1, x8, #0x2
10050208c:     	b	0x100501eb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13b8>
100502090:     	adrp	x2, 0x100eff000 <__RNvNtCs3gRpqoBkMHm_13perry_runtime7promise28ITER_RESULT_VALUE_IS_RAW_F64+0x10>
100502094:     	add	x2, x2, #0x1b8
100502098:     	mov	x1, x25
10050209c:     	bl	0x100b0924c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
1005020a0:     	cmp	w9, #0x6d
1005020a4:     	b.gt	0x100502140 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1648>
1005020a8:     	cmp	w9, #0x22
1005020ac:     	b.eq	0x1005020d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15dc>
1005020b0:     	cmp	w9, #0x2d
1005020b4:     	b.eq	0x1005020c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15cc>
1005020b8:     	sub	w9, w9, #0x30
1005020bc:     	cmp	w9, #0xa
1005020c0:     	b.hs	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
1005020c4:     	add	x0, x8, #0x18
1005020c8:     	bl	0x1004e8310 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar12parse_number>
1005020cc:     	tbz	w0, #0x0, 0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
1005020d0:     	b	0x100501eb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13b8>
1005020d4:     	sub	x8, x19, #0x6
1005020d8:     	cmp	x8, x10
1005020dc:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
1005020e0:     	cmp	x1, #0x7
1005020e4:     	b.hi	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
1005020e8:     	cmp	w12, #0x22
1005020ec:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
1005020f0:     	sub	x23, x11, #0x7
1005020f4:     	sub	x8, x19, #0x7
1005020f8:     	add	x9, x21, x20
1005020fc:     	add	x22, x9, #0x19
100502100:     	cmp	x8, x10
100502104:     	b.ne	0x1005021c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x16d0>
100502108:     	add	x8, sp, #0xa0
10050210c:     	mov	x0, x22
100502110:     	mov	x1, x23
100502114:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100502118:     	ldr	x8, [sp, #0xa0]
10050211c:     	cbnz	x8, 0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100502120:     	cmp	x23, #0x2
100502124:     	b.gt	0x1005021f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1700>
100502128:     	cbz	x23, 0x100502214 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x171c>
10050212c:     	cmp	x23, #0x1
100502130:     	b.ne	0x10050221c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1724>
100502134:     	ldrb	w8, [x22]
100502138:     	mov	x9, #0x10000000000      ; =1099511627776
10050213c:     	b	0x100502268 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1770>
100502140:     	cmp	w9, #0x74
100502144:     	b.eq	0x10050218c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1694>
100502148:     	cmp	w9, #0x6e
10050214c:     	b.ne	0x1005020b8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x15c0>
100502150:     	add	x8, x21, x20
100502154:     	ldrb	w9, [x8, #0x19]
100502158:     	cmp	w9, #0x75
10050215c:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
100502160:     	ldrb	w8, [x8, #0x1a]
100502164:     	cmp	w8, #0x6c
100502168:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
10050216c:     	add	x8, x21, x20
100502170:     	ldrb	w8, [x8, #0x1b]
100502174:     	cmp	w8, #0x6c
100502178:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
10050217c:     	mov	x8, #0x1                ; =1
100502180:     	movk	x8, #0x7ffc, lsl #48
100502184:     	add	x1, x8, #0x1
100502188:     	b	0x100501eb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13b8>
10050218c:     	add	x8, x21, x20
100502190:     	ldrb	w9, [x8, #0x19]
100502194:     	cmp	w9, #0x72
100502198:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
10050219c:     	ldrb	w8, [x8, #0x1a]
1005021a0:     	cmp	w8, #0x75
1005021a4:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
1005021a8:     	add	x8, x21, x20
1005021ac:     	ldrb	w8, [x8, #0x1b]
1005021b0:     	cmp	w8, #0x65
1005021b4:     	b.ne	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
1005021b8:     	mov	x8, #0x1                ; =1
1005021bc:     	movk	x8, #0x7ffc, lsl #48
1005021c0:     	add	x1, x8, #0x3
1005021c4:     	b	0x100501eb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13b8>
1005021c8:     	mov	x8, x23
1005021cc:     	mov	x9, x22
1005021d0:     	ldrb	w10, [x9], #0x1
1005021d4:     	cmp	w10, #0x20
1005021d8:     	b.lo	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
1005021dc:     	cmp	w10, #0x22
1005021e0:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
1005021e4:     	cmp	w10, #0x5c
1005021e8:     	b.eq	0x100500e90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x398>
1005021ec:     	subs	x8, x8, #0x1
1005021f0:     	b.ne	0x1005021d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x16d8>
1005021f4:     	b	0x100502108 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1610>
1005021f8:     	cmp	x23, #0x3
1005021fc:     	b.eq	0x100502234 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x173c>
100502200:     	cmp	x23, #0x4
100502204:     	b.ne	0x100502254 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x175c>
100502208:     	ldr	w8, [x22]
10050220c:     	mov	x9, #0x40000000000      ; =4398046511104
100502210:     	b	0x100502268 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1770>
100502214:     	mov	x1, #0x7ff9000000000000 ; =9221401712017801216
100502218:     	b	0x100501eb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13b8>
10050221c:     	ldrb	w8, [x22]
100502220:     	add	x9, x21, x20
100502224:     	ldrb	w9, [x9, #0x1a]
100502228:     	orr	x8, x8, x9, lsl #8
10050222c:     	mov	x9, #0x20000000000      ; =2199023255552
100502230:     	b	0x100502268 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1770>
100502234:     	ldrb	w8, [x22]
100502238:     	add	x9, x21, x20
10050223c:     	ldrb	w10, [x9, #0x1a]
100502240:     	ldrb	w9, [x9, #0x1b]
100502244:     	orr	x8, x8, x10, lsl #8
100502248:     	orr	x8, x8, x9, lsl #16
10050224c:     	mov	x9, #0x30000000000      ; =3298534883328
100502250:     	b	0x100502268 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x1770>
100502254:     	ldr	w8, [x22]
100502258:     	add	x9, x21, x20
10050225c:     	ldrb	w9, [x9, #0x1d]
100502260:     	orr	x8, x8, x9, lsl #32
100502264:     	mov	x9, #0x50000000000      ; =5497558138880
100502268:     	movk	x9, #0x7ff9, lsl #48
10050226c:     	orr	x1, x8, x9
100502270:     	b	0x100501eb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow+0x13b8>
100502274:     	bl	0x100b3c438 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
100502278:     	adrp	x0, 0x100c6b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x651c>
10050227c:     	add	x0, x0, #0xfa0
100502280:     	mov	w1, #0x21               ; =33
100502284:     	bl	0x100503850 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
