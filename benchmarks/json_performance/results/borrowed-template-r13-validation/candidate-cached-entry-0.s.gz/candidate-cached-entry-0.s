
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/borrowed-template-r13/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004e776c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template>:
1004e776c:     	sub	sp, sp, #0xe0
1004e7770:     	stp	x28, x27, [sp, #0x80]
1004e7774:     	stp	x26, x25, [sp, #0x90]
1004e7778:     	stp	x24, x23, [sp, #0xa0]
1004e777c:     	stp	x22, x21, [sp, #0xb0]
1004e7780:     	stp	x20, x19, [sp, #0xc0]
1004e7784:     	stp	x29, x30, [sp, #0xd0]
1004e7788:     	add	x29, sp, #0xd0
1004e778c:     	adrp	x8, 0x100f74000 <_perry_global_rotating_worker_ts__1>
1004e7790:     	ldr	w19, [x8, #0x948]
1004e7794:     	adrp	x21, 0x100f74000 <_perry_global_rotating_worker_ts__1>
1004e7798:     	cmp	w19, #0x300
1004e779c:     	b.hs	0x1004e7b94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x428>
1004e77a0:     	ldr	x8, [x21, #0x48]
1004e77a4:     	cmn	x8, #0x1
1004e77a8:     	b.eq	0x1004e7b84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x418>
1004e77ac:     	mrs	x9, TPIDRRO_EL0
1004e77b0:     	and	x9, x9, #0xfffffffffffffff8
1004e77b4:     	ldr	x0, [x9, x8, lsl #3]
1004e77b8:     	cbz	x0, 0x1004e7b84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x418>
1004e77bc:     	add	x8, x0, x19, lsl #3
1004e77c0:     	ldr	x0, [x8, #0x1e8]
1004e77c4:     	cbz	x0, 0x1004e7b94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x428>
1004e77c8:     	ldrb	w8, [x0]
1004e77cc:     	cbnz	w8, 0x1004e7ba8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x43c>
1004e77d0:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
1004e77d4:     	ldr	w19, [x8, #0x578]
1004e77d8:     	cmp	w19, #0x300
1004e77dc:     	b.hs	0x1004e7bd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x464>
1004e77e0:     	ldr	x8, [x21, #0x48]
1004e77e4:     	cmn	x8, #0x1
1004e77e8:     	b.eq	0x1004e7bc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x454>
1004e77ec:     	mrs	x9, TPIDRRO_EL0
1004e77f0:     	and	x9, x9, #0xfffffffffffffff8
1004e77f4:     	ldr	x0, [x9, x8, lsl #3]
1004e77f8:     	cbz	x0, 0x1004e7bc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x454>
1004e77fc:     	add	x8, x0, x19, lsl #3
1004e7800:     	ldr	x20, [x8, #0x1e8]
1004e7804:     	cbz	x20, 0x1004e7bd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x464>
1004e7808:     	bl	0x10027e644 <__RNvMs7_NtNtCs3gRpqoBkMHm_13perry_runtime2gc6policyNtB5_15GcSuppressScope3new>
1004e780c:     	ldr	x8, [x20]
1004e7810:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1004e7814:     	cmp	x8, x9
1004e7818:     	b.hs	0x1004e7bf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x488>
1004e781c:     	mov	x22, x0
1004e7820:     	add	x9, x8, #0x1
1004e7824:     	str	x9, [x20]
1004e7828:     	mov	x19, x20
1004e782c:     	ldrb	w9, [x19, #0x8]!
1004e7830:     	cmp	w9, #0x2
1004e7834:     	b.ne	0x1004e7848 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0xdc>
1004e7838:     	str	x8, [x20]
1004e783c:     	tbz	w22, #0x0, 0x1004e7a3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x2d0>
1004e7840:     	mov	x0, #0x0                ; =0
1004e7844:     	b	0x1004e7c34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4c8>
1004e7848:     	add	x0, sp, #0x18
1004e784c:     	bl	0x100234e3c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime5arena12constructionNtB2_17ConstructionBatch3new>
1004e7850:     	adrp	x1, 0x100c92000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x7470>
1004e7854:     	add	x1, x1, #0x660
1004e7858:     	add	x0, sp, #0x30
1004e785c:     	mov	w2, #0x40               ; =64
1004e7860:     	bl	0x100b58850 <_writev+0x100b58850>
1004e7864:     	ldrb	w1, [x20, #0x25e]
1004e7868:     	cmp	w1, #0x9
1004e786c:     	b.hs	0x1004e7cd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x564>
1004e7870:     	cbz	w1, 0x1004e7a88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x31c>
1004e7874:     	str	w22, [sp, #0x4]
1004e7878:     	mov	x25, #0x0               ; =0
1004e787c:     	mov	w8, #0x48               ; =72
1004e7880:     	umaddl	x26, w1, w8, x19
1004e7884:     	mov	x27, #0x7ffd000000000000 ; =9222527611924643840
1004e7888:     	ldr	x8, [sp, #0x18]
1004e788c:     	stp	x20, x8, [sp, #0x8]
1004e7890:     	mov	x28, #-0x3000000000000  ; =-844424930131968
1004e7894:     	mov	x24, #0x7fff000000000000 ; =9223090561878065152
1004e7898:     	mov	x20, #0x7ff9000000000000 ; =9221401712017801216
1004e789c:     	add	x9, sp, #0x30
1004e78a0:     	mov	x21, x19
1004e78a4:     	b	0x1004e78c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x154>
1004e78a8:     	ldr	x8, [x19, #0x8]
1004e78ac:     	str	x8, [x9, x25, lsl #3]
1004e78b0:     	add	x25, x25, #0x1
1004e78b4:     	mov	x19, x21
1004e78b8:     	cmp	x21, x26
1004e78bc:     	b.eq	0x1004e7a0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x2a0>
1004e78c0:     	ldrb	w8, [x21], #0x48
1004e78c4:     	tbz	w8, #0x0, 0x1004e78a8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x13c>
1004e78c8:     	ldrb	w23, [x19, #0x1]
1004e78cc:     	sub	x0, x29, #0x60
1004e78d0:     	add	x1, sp, #0x18
1004e78d4:     	mov	x2, x23
1004e78d8:     	bl	0x100232890 <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray3new>
1004e78dc:     	cmp	w23, #0x9
1004e78e0:     	b.hs	0x1004e7cb8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x54c>
1004e78e4:     	ldur	x22, [x29, #-0x60]
1004e78e8:     	cbz	w23, 0x1004e79e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x274>
1004e78ec:     	add	x19, x19, #0x8
1004e78f0:     	lsl	x23, x23, #3
1004e78f4:     	b	0x1004e794c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x1e0>
1004e78f8:     	add	x9, x22, w8, uxtw #3
1004e78fc:     	str	x2, [x9, #0x8]
1004e7900:     	and	x9, x2, x28
1004e7904:     	cmp	x9, x27
1004e7908:     	cset	w9, eq
1004e790c:     	ldurb	w10, [x29, #-0x57]
1004e7910:     	orr	w9, w10, w9
1004e7914:     	sturb	w9, [x29, #-0x57]
1004e7918:     	ldurb	w9, [x29, #-0x56]
1004e791c:     	csel	w9, w9, wzr, eq
1004e7920:     	sturb	w9, [x29, #-0x56]
1004e7924:     	and	x9, x2, #0xffff000000000000
1004e7928:     	cmp	x9, x24
1004e792c:     	ccmp	x2, x20, #0x0, ls
1004e7930:     	ldurb	w9, [x29, #-0x55]
1004e7934:     	csel	w9, w9, wzr, lo
1004e7938:     	sturb	w9, [x29, #-0x55]
1004e793c:     	add	w8, w8, #0x1
1004e7940:     	str	w8, [x22]
1004e7944:     	subs	x23, x23, #0x8
1004e7948:     	b.eq	0x1004e79dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x270>
1004e794c:     	ldr	x2, [x19], #0x8
1004e7950:     	ldp	w8, w9, [x22]
1004e7954:     	cmp	w8, w9
1004e7958:     	b.eq	0x1004e79b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x248>
1004e795c:     	ldurb	w9, [x29, #-0x58]
1004e7960:     	tbnz	w9, #0x0, 0x1004e78f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x18c>
1004e7964:     	ldr	w9, [x22, #0x4]
1004e7968:     	cmp	w8, w9
1004e796c:     	b.hs	0x1004e7994 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x228>
1004e7970:     	mov	w1, w8
1004e7974:     	mov	x0, x22
1004e7978:     	bl	0x100524530 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array15header_gc_slots27note_array_slot_layout_only>
1004e797c:     	ldr	w8, [x22]
1004e7980:     	add	w8, w8, #0x1
1004e7984:     	str	w8, [x22]
1004e7988:     	subs	x23, x23, #0x8
1004e798c:     	b.ne	0x1004e794c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x1e0>
1004e7990:     	b	0x1004e79dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x270>
1004e7994:     	fmov	d0, x2
1004e7998:     	mov	x0, x22
1004e799c:     	bl	0x1007c1558 <_js_array_push_f64>
1004e79a0:     	mov	x22, x0
1004e79a4:     	stur	x0, [x29, #-0x60]
1004e79a8:     	subs	x23, x23, #0x8
1004e79ac:     	b.ne	0x1004e794c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x1e0>
1004e79b0:     	b	0x1004e79dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x270>
1004e79b4:     	sub	x0, x29, #0x60
1004e79b8:     	add	x1, sp, #0x18
1004e79bc:     	mov	x22, x2
1004e79c0:     	bl	0x100b3140c <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray4grow>
1004e79c4:     	mov	x2, x22
1004e79c8:     	ldur	x22, [x29, #-0x60]
1004e79cc:     	ldr	w8, [x22]
1004e79d0:     	ldurb	w9, [x29, #-0x58]
1004e79d4:     	tbnz	w9, #0x0, 0x1004e78f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x18c>
1004e79d8:     	b	0x1004e7964 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x1f8>
1004e79dc:     	ldur	x22, [x29, #-0x60]
1004e79e0:     	sub	x0, x29, #0x60
1004e79e4:     	ldr	x1, [sp, #0x10]
1004e79e8:     	bl	0x1002326cc <__RNvMNtNtCs3gRpqoBkMHm_13perry_runtime4json18construction_arrayNtB2_17ConstructionArray13finish_layout>
1004e79ec:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1004e79f0:     	bfxil	x8, x22, #0, #48
1004e79f4:     	add	x9, sp, #0x30
1004e79f8:     	str	x8, [x9, x25, lsl #3]
1004e79fc:     	add	x25, x25, #0x1
1004e7a00:     	mov	x19, x21
1004e7a04:     	cmp	x21, x26
1004e7a08:     	b.ne	0x1004e78c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x154>
1004e7a0c:     	ldr	x20, [sp, #0x8]
1004e7a10:     	ldrb	w4, [x20, #0x25e]
1004e7a14:     	cmp	x4, #0x9
1004e7a18:     	adrp	x21, 0x100f74000 <_perry_global_rotating_worker_ts__1>
1004e7a1c:     	ldr	w22, [sp, #0x4]
1004e7a20:     	b.lo	0x1004e7a8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x320>
1004e7a24:     	adrp	x3, 0x100ef1000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004e7a28:     	add	x3, x3, #0xd40
1004e7a2c:     	mov	x0, #0x0                ; =0
1004e7a30:     	mov	x1, x4
1004e7a34:     	mov	w2, #0x8                ; =8
1004e7a38:     	bl	0x100b0940c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1004e7a3c:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
1004e7a40:     	ldr	w19, [x8, #0x308]
1004e7a44:     	cmp	w19, #0x300
1004e7a48:     	b.hs	0x1004e7c68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4fc>
1004e7a4c:     	ldr	x8, [x21, #0x48]
1004e7a50:     	cmn	x8, #0x1
1004e7a54:     	b.eq	0x1004e7c58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4ec>
1004e7a58:     	mrs	x9, TPIDRRO_EL0
1004e7a5c:     	and	x9, x9, #0xfffffffffffffff8
1004e7a60:     	ldr	x0, [x9, x8, lsl #3]
1004e7a64:     	cbz	x0, 0x1004e7c58 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4ec>
1004e7a68:     	add	x8, x0, x19, lsl #3
1004e7a6c:     	ldr	x8, [x8, #0x1e8]
1004e7a70:     	cbz	x8, 0x1004e7c68 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4fc>
1004e7a74:     	mov	x0, #0x0                ; =0
1004e7a78:     	ldrb	w9, [x8]
1004e7a7c:     	and	w9, w9, #0xfffffffd
1004e7a80:     	strb	w9, [x8]
1004e7a84:     	b	0x1004e7c34 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4c8>
1004e7a88:     	mov	x4, #0x0                ; =0
1004e7a8c:     	ldr	w2, [x20, #0x258]
1004e7a90:     	ldr	x1, [x20, #0x250]
1004e7a94:     	add	x0, sp, #0x18
1004e7a98:     	add	x3, sp, #0x30
1004e7a9c:     	bl	0x1005b8d08 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
1004e7aa0:     	ldr	x8, [x20]
1004e7aa4:     	sub	x8, x8, #0x1
1004e7aa8:     	str	x8, [x20]
1004e7aac:     	tbz	w22, #0x0, 0x1004e7b10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x3a4>
1004e7ab0:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1004e7ab4:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1004e7ab8:     	ldr	x8, [x8, #0x758]
1004e7abc:     	cbnz	x8, 0x1004e7b64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x3f8>
1004e7ac0:     	bfxil	x19, x0, #0, #48
1004e7ac4:     	adrp	x8, 0x100f74000 <_perry_global_rotating_worker_ts__1>
1004e7ac8:     	ldr	w20, [x8, #0x930]
1004e7acc:     	cmp	w20, #0x300
1004e7ad0:     	b.hs	0x1004e7c10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4a4>
1004e7ad4:     	ldr	x8, [x21, #0x48]
1004e7ad8:     	cmn	x8, #0x1
1004e7adc:     	b.eq	0x1004e7c00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x494>
1004e7ae0:     	mrs	x9, TPIDRRO_EL0
1004e7ae4:     	and	x9, x9, #0xfffffffffffffff8
1004e7ae8:     	ldr	x0, [x9, x8, lsl #3]
1004e7aec:     	cbz	x0, 0x1004e7c00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x494>
1004e7af0:     	add	x8, x0, x20, lsl #3
1004e7af4:     	ldr	x0, [x8, #0x1e8]
1004e7af8:     	cbz	x0, 0x1004e7c10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4a4>
1004e7afc:     	ldrb	w8, [x0]
1004e7b00:     	cbz	w8, 0x1004e7c24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4b8>
1004e7b04:     	sub	w8, w8, #0x1
1004e7b08:     	strb	w8, [x0]
1004e7b0c:     	b	0x1004e7c30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4c4>
1004e7b10:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
1004e7b14:     	ldr	w19, [x8, #0x308]
1004e7b18:     	cmp	w19, #0x300
1004e7b1c:     	b.hs	0x1004e7c98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x52c>
1004e7b20:     	ldr	x8, [x21, #0x48]
1004e7b24:     	cmn	x8, #0x1
1004e7b28:     	b.eq	0x1004e7c7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x510>
1004e7b2c:     	mrs	x9, TPIDRRO_EL0
1004e7b30:     	and	x9, x9, #0xfffffffffffffff8
1004e7b34:     	ldr	x8, [x9, x8, lsl #3]
1004e7b38:     	cbz	x8, 0x1004e7c7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x510>
1004e7b3c:     	add	x8, x8, x19, lsl #3
1004e7b40:     	ldr	x8, [x8, #0x1e8]
1004e7b44:     	cbz	x8, 0x1004e7c98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x52c>
1004e7b48:     	ldrb	w9, [x8]
1004e7b4c:     	and	w9, w9, #0xfffffffd
1004e7b50:     	strb	w9, [x8]
1004e7b54:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1004e7b58:     	adrp	x8, 0x100fbe000 <__RNvNCNKNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6object9read_stub9READ_STUB7STORAGE0s_023___RUST_STD_INTERNAL_VAL$tlv$init+0x17ac0>
1004e7b5c:     	ldr	x8, [x8, #0x758]
1004e7b60:     	cbz	x8, 0x1004e7ac0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x354>
1004e7b64:     	mov	x20, x0
1004e7b68:     	bl	0x100b3c438 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json12parse_scalar30clear_oversized_key_cache_slow>
1004e7b6c:     	bfxil	x19, x20, #0, #48
1004e7b70:     	adrp	x8, 0x100f74000 <_perry_global_rotating_worker_ts__1>
1004e7b74:     	ldr	w20, [x8, #0x930]
1004e7b78:     	cmp	w20, #0x300
1004e7b7c:     	b.lo	0x1004e7ad4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x368>
1004e7b80:     	b	0x1004e7c10 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x4a4>
1004e7b84:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004e7b88:     	add	x8, x0, x19, lsl #3
1004e7b8c:     	ldr	x0, [x8, #0x1e8]
1004e7b90:     	cbnz	x0, 0x1004e77c8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x5c>
1004e7b94:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1004e7b98:     	add	x0, x0, #0xcf0
1004e7b9c:     	bl	0x100b335e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004e7ba0:     	ldrb	w8, [x0]
1004e7ba4:     	cbz	w8, 0x1004e77d0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x64>
1004e7ba8:     	bl	0x100b3ad1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy40gc_collect_pending_suppressed_parse_slow>
1004e7bac:     	adrp	x8, 0x100f76000 <__MergedGlobals.1914+0xc8>
1004e7bb0:     	ldr	w19, [x8, #0x578]
1004e7bb4:     	cmp	w19, #0x300
1004e7bb8:     	b.lo	0x1004e77e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x74>
1004e7bbc:     	b	0x1004e7bd0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x464>
1004e7bc0:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004e7bc4:     	add	x8, x0, x19, lsl #3
1004e7bc8:     	ldr	x20, [x8, #0x1e8]
1004e7bcc:     	cbnz	x20, 0x1004e7808 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x9c>
1004e7bd0:     	adrp	x0, 0x100f04000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
1004e7bd4:     	add	x0, x0, #0x0
1004e7bd8:     	bl	0x100b3359c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1004e7bdc:     	mov	x20, x0
1004e7be0:     	bl	0x10027e644 <__RNvMs7_NtNtCs3gRpqoBkMHm_13perry_runtime2gc6policyNtB5_15GcSuppressScope3new>
1004e7be4:     	ldr	x8, [x20]
1004e7be8:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1004e7bec:     	cmp	x8, x9
1004e7bf0:     	b.lo	0x1004e781c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0xb0>
1004e7bf4:     	adrp	x0, 0x100ef1000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004e7bf8:     	add	x0, x0, #0xd28
1004e7bfc:     	bl	0x100b0911c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1004e7c00:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004e7c04:     	add	x8, x0, x20, lsl #3
1004e7c08:     	ldr	x0, [x8, #0x1e8]
1004e7c0c:     	cbnz	x0, 0x1004e7afc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x390>
1004e7c10:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1004e7c14:     	add	x0, x0, #0xcc0
1004e7c18:     	bl	0x100b335e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004e7c1c:     	ldrb	w8, [x0]
1004e7c20:     	cbnz	w8, 0x1004e7b04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x398>
1004e7c24:     	mov	w8, #0x3f               ; =63
1004e7c28:     	strb	w8, [x0]
1004e7c2c:     	bl	0x10045cc20 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy49gc_schedule_parse_boundary_collection_if_pressure>
1004e7c30:     	mov	w0, #0x1                ; =1
1004e7c34:     	mov	x1, x19
1004e7c38:     	ldp	x29, x30, [sp, #0xd0]
1004e7c3c:     	ldp	x20, x19, [sp, #0xc0]
1004e7c40:     	ldp	x22, x21, [sp, #0xb0]
1004e7c44:     	ldp	x24, x23, [sp, #0xa0]
1004e7c48:     	ldp	x26, x25, [sp, #0x90]
1004e7c4c:     	ldp	x28, x27, [sp, #0x80]
1004e7c50:     	add	sp, sp, #0xe0
1004e7c54:     	ret
1004e7c58:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004e7c5c:     	add	x8, x0, x19, lsl #3
1004e7c60:     	ldr	x8, [x8, #0x1e8]
1004e7c64:     	cbnz	x8, 0x1004e7a74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x308>
1004e7c68:     	adrp	x0, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1004e7c6c:     	add	x0, x0, #0xd20
1004e7c70:     	bl	0x100b335e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004e7c74:     	mov	x8, x0
1004e7c78:     	b	0x1004e7a74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x308>
1004e7c7c:     	mov	x20, x0
1004e7c80:     	bl	0x100b35d7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1004e7c84:     	mov	x8, x0
1004e7c88:     	mov	x0, x20
1004e7c8c:     	add	x8, x8, x19, lsl #3
1004e7c90:     	ldr	x8, [x8, #0x1e8]
1004e7c94:     	cbnz	x8, 0x1004e7b48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x3dc>
1004e7c98:     	adrp	x8, 0x100f00000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc12idle_reclaim5STATE+0x1f8>
1004e7c9c:     	add	x8, x8, #0xd20
1004e7ca0:     	mov	x19, x0
1004e7ca4:     	mov	x0, x8
1004e7ca8:     	bl	0x100b335e8 <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyINtNtCsjgY6bXVaRmE_4core4cell4CellhEE8get_slowB7_>
1004e7cac:     	mov	x8, x0
1004e7cb0:     	mov	x0, x19
1004e7cb4:     	b	0x1004e7b48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse29reuse_matched_object_template+0x3dc>
1004e7cb8:     	adrp	x3, 0x100ef1000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004e7cbc:     	add	x3, x3, #0xd58
1004e7cc0:     	mov	x0, #0x0                ; =0
1004e7cc4:     	mov	x1, x23
1004e7cc8:     	mov	w2, #0x8                ; =8
1004e7ccc:     	bl	0x100b0940c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1004e7cd0:     	adrp	x3, 0x100ef1000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1004e7cd4:     	add	x3, x3, #0xd70
1004e7cd8:     	mov	x0, #0x0                ; =0
1004e7cdc:     	mov	w2, #0x8                ; =8
1004e7ce0:     	bl	0x100b0940c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
1004e7ce4:     	nop
1004e7ce8:     	nop
1004e7cec:     	nop
1004e7cf0:     	nop
1004e7cf4:     	nop
1004e7cf8:     	nop
1004e7cfc:     	nop
