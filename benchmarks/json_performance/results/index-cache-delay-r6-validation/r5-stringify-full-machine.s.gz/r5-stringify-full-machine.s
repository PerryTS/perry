
benchmarks/json_performance/.work/invariant-field-loop-r5/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100846880 <_js_json_stringify_full>:
100846880:     	sub	sp, sp, #0x110
100846884:     	stp	d9, d8, [sp, #0xa0]
100846888:     	stp	x28, x27, [sp, #0xb0]
10084688c:     	stp	x26, x25, [sp, #0xc0]
100846890:     	stp	x24, x23, [sp, #0xd0]
100846894:     	stp	x22, x21, [sp, #0xe0]
100846898:     	stp	x20, x19, [sp, #0xf0]
10084689c:     	stp	x29, x30, [sp, #0x100]
1008468a0:     	add	x29, sp, #0x100
1008468a4:     	mov.16b	v9, v2
1008468a8:     	mov.16b	v8, v0
1008468ac:     	mov	x26, #0x1               ; =1
1008468b0:     	movk	x26, #0x7ffc, lsl #48
1008468b4:     	fmov	x19, d8
1008468b8:     	fmov	x20, d1
1008468bc:     	fmov	x23, d9
1008468c0:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
1008468c4:     	add	x9, x23, x8
1008468c8:     	add	x27, x20, x8
1008468cc:     	cmp	x9, #0x2
1008468d0:     	b.hs	0x1008468ec <_js_json_stringify_full+0x6c>
1008468d4:     	cmp	x27, #0x2
1008468d8:     	b.lo	0x1008468fc <_js_json_stringify_full+0x7c>
1008468dc:     	mov	w21, #0x0               ; =0
1008468e0:     	cmp	x19, x26
1008468e4:     	b.eq	0x100847d4c <_js_json_stringify_full+0x14cc>
1008468e8:     	b	0x100846e74 <_js_json_stringify_full+0x5f4>
1008468ec:     	add	x8, x26, #0x2
1008468f0:     	cmp	x23, x8
1008468f4:     	ccmp	x27, #0x2, #0x2, eq
1008468f8:     	b.hs	0x1008468dc <_js_json_stringify_full+0x5c>
1008468fc:     	mov	x8, #-0x2               ; =-2
100846900:     	movk	x8, #0x8003, lsl #48
100846904:     	add	x8, x19, x8
100846908:     	cmp	x8, #0x3
10084690c:     	b.hs	0x100846920 <_js_json_stringify_full+0xa0>
100846910:     	adrp	x9, 0x100c9a000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4ff0>
100846914:     	add	x9, x9, #0x598
100846918:     	ldr	x21, [x9, x8, lsl #3]
10084691c:     	b	0x100847d54 <_js_json_stringify_full+0x14d4>
100846920:     	strb	wzr, [sp, #0x3c]
100846924:     	str	wzr, [sp, #0x38]
100846928:     	and	x8, x19, #0xffff000000000000
10084692c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846930:     	cmp	x8, x9
100846934:     	b.eq	0x1008469a8 <_js_json_stringify_full+0x128>
100846938:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084693c:     	cmp	x8, x9
100846940:     	b.ne	0x100846da4 <_js_json_stringify_full+0x524>
100846944:     	ubfx	x10, x19, #40, #8
100846948:     	cbz	x10, 0x100846998 <_js_json_stringify_full+0x118>
10084694c:     	strb	w19, [sp, #0x38]
100846950:     	cmp	x10, #0x1
100846954:     	b.eq	0x100846998 <_js_json_stringify_full+0x118>
100846958:     	lsr	x9, x19, #8
10084695c:     	strb	w9, [sp, #0x39]
100846960:     	cmp	x10, #0x2
100846964:     	b.eq	0x100846998 <_js_json_stringify_full+0x118>
100846968:     	lsr	x9, x19, #16
10084696c:     	strb	w9, [sp, #0x3a]
100846970:     	cmp	x10, #0x3
100846974:     	b.eq	0x100846998 <_js_json_stringify_full+0x118>
100846978:     	lsr	x9, x19, #24
10084697c:     	strb	w9, [sp, #0x3b]
100846980:     	cmp	x10, #0x4
100846984:     	b.eq	0x100846998 <_js_json_stringify_full+0x118>
100846988:     	lsr	x9, x19, #32
10084698c:     	strb	w9, [sp, #0x3c]
100846990:     	cmp	x10, #0x5
100846994:     	b.ne	0x100848540 <_js_json_stringify_full+0x1cc0>
100846998:     	add	x11, sp, #0x38
10084699c:     	cmp	w10, #0x3
1008469a0:     	b.ls	0x1008469c0 <_js_json_stringify_full+0x140>
1008469a4:     	b	0x100846da4 <_js_json_stringify_full+0x524>
1008469a8:     	ands	x9, x19, #0xffffffffffff
1008469ac:     	b.eq	0x100846e68 <_js_json_stringify_full+0x5e8>
1008469b0:     	add	x11, x9, #0x14
1008469b4:     	ldr	w10, [x9, #0x4]
1008469b8:     	cmp	w10, #0x3
1008469bc:     	b.hi	0x100846da4 <_js_json_stringify_full+0x524>
1008469c0:     	stur	wzr, [sp, #0x71]
1008469c4:     	mov	w9, #0x22               ; =34
1008469c8:     	strb	w9, [sp, #0x70]
1008469cc:     	cbz	w10, 0x100846a04 <_js_json_stringify_full+0x184>
1008469d0:     	add	x12, sp, #0x70
1008469d4:     	ldrb	w13, [x11]
1008469d8:     	sxtb	w15, w13
1008469dc:     	cmp	w13, #0xb
1008469e0:     	b.le	0x100846a0c <_js_json_stringify_full+0x18c>
1008469e4:     	cmp	w13, #0x21
1008469e8:     	b.gt	0x100846a2c <_js_json_stringify_full+0x1ac>
1008469ec:     	cmp	w13, #0xc
1008469f0:     	b.eq	0x100846a60 <_js_json_stringify_full+0x1e0>
1008469f4:     	cmp	w13, #0xd
1008469f8:     	b.ne	0x100846a3c <_js_json_stringify_full+0x1bc>
1008469fc:     	mov	w15, #0x72              ; =114
100846a00:     	b	0x100846a6c <_js_json_stringify_full+0x1ec>
100846a04:     	mov	w12, #0x1               ; =1
100846a08:     	b	0x100846a94 <_js_json_stringify_full+0x214>
100846a0c:     	cmp	w13, #0x8
100846a10:     	b.eq	0x100846a58 <_js_json_stringify_full+0x1d8>
100846a14:     	cmp	w13, #0x9
100846a18:     	b.eq	0x100846a68 <_js_json_stringify_full+0x1e8>
100846a1c:     	cmp	w13, #0xa
100846a20:     	b.ne	0x100846a3c <_js_json_stringify_full+0x1bc>
100846a24:     	mov	w15, #0x6e              ; =110
100846a28:     	b	0x100846a6c <_js_json_stringify_full+0x1ec>
100846a2c:     	cmp	w13, #0x22
100846a30:     	b.eq	0x100846a6c <_js_json_stringify_full+0x1ec>
100846a34:     	cmp	w13, #0x5c
100846a38:     	b.eq	0x100846a6c <_js_json_stringify_full+0x1ec>
100846a3c:     	cmp	w15, #0x20
100846a40:     	b.lt	0x100846da4 <_js_json_stringify_full+0x524>
100846a44:     	mov	w14, #0x0               ; =0
100846a48:     	add	x13, x12, #0x2
100846a4c:     	mov	w12, #0x2               ; =2
100846a50:     	mov	w16, #0x1               ; =1
100846a54:     	b	0x100846a84 <_js_json_stringify_full+0x204>
100846a58:     	mov	w15, #0x62              ; =98
100846a5c:     	b	0x100846a6c <_js_json_stringify_full+0x1ec>
100846a60:     	mov	w15, #0x66              ; =102
100846a64:     	b	0x100846a6c <_js_json_stringify_full+0x1ec>
100846a68:     	mov	w15, #0x74              ; =116
100846a6c:     	add	x13, x12, #0x3
100846a70:     	mov	w12, #0x5c              ; =92
100846a74:     	strb	w12, [sp, #0x71]
100846a78:     	mov	w14, #0x1               ; =1
100846a7c:     	mov	w12, #0x3               ; =3
100846a80:     	mov	w16, #0x2               ; =2
100846a84:     	add	x17, sp, #0x70
100846a88:     	strb	w15, [x17, x16]
100846a8c:     	cmp	w10, #0x1
100846a90:     	b.ne	0x100846acc <_js_json_stringify_full+0x24c>
100846a94:     	add	x10, sp, #0x70
100846a98:     	strb	w9, [x10, x12]
100846a9c:     	add	x8, x12, #0x1
100846aa0:     	cmp	x12, #0x3
100846aa4:     	b.hs	0x100846ab8 <_js_json_stringify_full+0x238>
100846aa8:     	mov	x13, #0x0               ; =0
100846aac:     	mov	x11, #0x0               ; =0
100846ab0:     	add	x9, sp, #0x70
100846ab4:     	b	0x100846d14 <_js_json_stringify_full+0x494>
100846ab8:     	cmp	x12, #0xf
100846abc:     	b.hs	0x100846afc <_js_json_stringify_full+0x27c>
100846ac0:     	mov	x11, #0x0               ; =0
100846ac4:     	mov	x13, #0x0               ; =0
100846ac8:     	b	0x100846c70 <_js_json_stringify_full+0x3f0>
100846acc:     	ldrb	w16, [x11, #0x1]
100846ad0:     	sxtb	w15, w16
100846ad4:     	cmp	w16, #0xb
100846ad8:     	b.le	0x100846d44 <_js_json_stringify_full+0x4c4>
100846adc:     	cmp	w16, #0x21
100846ae0:     	b.gt	0x100846d64 <_js_json_stringify_full+0x4e4>
100846ae4:     	cmp	w16, #0xc
100846ae8:     	b.eq	0x100846d94 <_js_json_stringify_full+0x514>
100846aec:     	cmp	w16, #0xd
100846af0:     	b.ne	0x100846d74 <_js_json_stringify_full+0x4f4>
100846af4:     	mov	w15, #0x72              ; =114
100846af8:     	b	0x100846da0 <_js_json_stringify_full+0x520>
100846afc:     	and	x12, x8, #0xc
100846b00:     	and	x11, x8, #0x10
100846b04:     	add	x13, sp, #0x70
100846b08:     	add	x9, x13, x11
100846b0c:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5ff0>
100846b10:     	ldr	q0, [x14, #0x710]
100846b14:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5ff0>
100846b18:     	ldr	q1, [x14, #0x720]
100846b1c:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5ff0>
100846b20:     	ldr	q2, [x14, #0x730]
100846b24:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5ff0>
100846b28:     	ldr	q3, [x14, #0x740]
100846b2c:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5ff0>
100846b30:     	ldr	q4, [x14, #0x750]
100846b34:     	movi.2d	v5, #0000000000000000
100846b38:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5ff0>
100846b3c:     	ldr	q6, [x14, #0x760]
100846b40:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4ff0>
100846b44:     	ldr	q7, [x14, #0x880]
100846b48:     	mov	w14, #0x10              ; =16
100846b4c:     	movi.2d	v16, #0000000000000000
100846b50:     	dup.2d	v17, x14
100846b54:     	adrp	x14, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x337fa>
100846b58:     	ldr	q19, [x14, #0x780]
100846b5c:     	and	x14, x8, #0x10
100846b60:     	movi.2d	v20, #0000000000000000
100846b64:     	movi.2d	v18, #0000000000000000
100846b68:     	movi.2d	v23, #0000000000000000
100846b6c:     	movi.2d	v21, #0000000000000000
100846b70:     	movi.2d	v24, #0000000000000000
100846b74:     	movi.2d	v22, #0000000000000000
100846b78:     	ldr	q25, [x13], #0x10
100846b7c:     	ushll.8h	v26, v25, #0x0
100846b80:     	ushll2.4s	v27, v26, #0x0
100846b84:     	ushll2.2d	v28, v27, #0x0
100846b88:     	ushll2.8h	v25, v25, #0x0
100846b8c:     	ushll.4s	v29, v25, #0x0
100846b90:     	ushll2.2d	v30, v29, #0x0
100846b94:     	ushll.2d	v29, v29, #0x0
100846b98:     	ushll.2d	v27, v27, #0x0
100846b9c:     	ushll.4s	v26, v26, #0x0
100846ba0:     	ushll2.2d	v31, v26, #0x0
100846ba4:     	ushll2.4s	v25, v25, #0x0
100846ba8:     	ushll.2d	v8, v25, #0x0
100846bac:     	ushll.2d	v26, v26, #0x0
100846bb0:     	ushll2.2d	v25, v25, #0x0
100846bb4:     	shl.2d	v9, v0, #0x3
100846bb8:     	ushl.2d	v25, v25, v9
100846bbc:     	shl.2d	v9, v19, #0x3
100846bc0:     	ushl.2d	v26, v26, v9
100846bc4:     	shl.2d	v9, v1, #0x3
100846bc8:     	ushl.2d	v8, v8, v9
100846bcc:     	shl.2d	v9, v7, #0x3
100846bd0:     	ushl.2d	v31, v31, v9
100846bd4:     	shl.2d	v9, v6, #0x3
100846bd8:     	ushl.2d	v27, v27, v9
100846bdc:     	shl.2d	v9, v3, #0x3
100846be0:     	ushl.2d	v29, v29, v9
100846be4:     	shl.2d	v9, v2, #0x3
100846be8:     	ushl.2d	v30, v30, v9
100846bec:     	shl.2d	v9, v4, #0x3
100846bf0:     	ushl.2d	v28, v28, v9
100846bf4:     	orr.16b	v18, v28, v18
100846bf8:     	orr.16b	v21, v30, v21
100846bfc:     	orr.16b	v23, v29, v23
100846c00:     	orr.16b	v20, v27, v20
100846c04:     	orr.16b	v5, v31, v5
100846c08:     	orr.16b	v24, v8, v24
100846c0c:     	orr.16b	v16, v26, v16
100846c10:     	orr.16b	v22, v25, v22
100846c14:     	add.2d	v6, v6, v17
100846c18:     	add.2d	v7, v7, v17
100846c1c:     	add.2d	v19, v19, v17
100846c20:     	add.2d	v4, v4, v17
100846c24:     	add.2d	v3, v3, v17
100846c28:     	add.2d	v2, v2, v17
100846c2c:     	add.2d	v1, v1, v17
100846c30:     	add.2d	v0, v0, v17
100846c34:     	subs	x14, x14, #0x10
100846c38:     	b.ne	0x100846b78 <_js_json_stringify_full+0x2f8>
100846c3c:     	orr.16b	v0, v16, v23
100846c40:     	orr.16b	v1, v20, v24
100846c44:     	orr.16b	v0, v0, v1
100846c48:     	orr.16b	v1, v5, v21
100846c4c:     	orr.16b	v2, v18, v22
100846c50:     	orr.16b	v1, v1, v2
100846c54:     	orr.16b	v0, v0, v1
100846c58:     	mov	d1, v0[1]
100846c5c:     	orr.8b	v0, v0, v1
100846c60:     	fmov	x13, d0
100846c64:     	cmp	x8, x11
100846c68:     	b.eq	0x100846d34 <_js_json_stringify_full+0x4b4>
100846c6c:     	cbz	x12, 0x100846d14 <_js_json_stringify_full+0x494>
100846c70:     	mov	x14, x11
100846c74:     	and	x11, x8, #0x1c
100846c78:     	add	x15, sp, #0x70
100846c7c:     	add	x9, x15, x11
100846c80:     	fmov	d0, x13
100846c84:     	movi.2d	v1, #0000000000000000
100846c88:     	dup.2d	v3, x14
100846c8c:     	adrp	x12, 0x100c9a000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4ff0>
100846c90:     	ldr	q2, [x12, #0x880]
100846c94:     	orr.16b	v2, v3, v2
100846c98:     	adrp	x12, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x337fa>
100846c9c:     	ldr	q4, [x12, #0x780]
100846ca0:     	orr.16b	v3, v3, v4
100846ca4:     	sub	x12, x14, x11
100846ca8:     	add	x13, x15, x14
100846cac:     	movi.2d	v4, #0x000000000000ff
100846cb0:     	mov	w14, #0x4               ; =4
100846cb4:     	dup.2d	v5, x14
100846cb8:     	ldr	s6, [x13], #0x4
100846cbc:     	ushll.8h	v6, v6, #0x0
100846cc0:     	ushll.4s	v6, v6, #0x0
100846cc4:     	ushll2.2d	v7, v6, #0x0
100846cc8:     	and.16b	v7, v7, v4
100846ccc:     	ushll.2d	v6, v6, #0x0
100846cd0:     	and.16b	v6, v6, v4
100846cd4:     	shl.2d	v16, v2, #0x3
100846cd8:     	shl.2d	v17, v3, #0x3
100846cdc:     	ushl.2d	v6, v6, v17
100846ce0:     	ushl.2d	v7, v7, v16
100846ce4:     	orr.16b	v1, v7, v1
100846ce8:     	orr.16b	v0, v6, v0
100846cec:     	add.2d	v2, v2, v5
100846cf0:     	add.2d	v3, v3, v5
100846cf4:     	adds	x12, x12, #0x4
100846cf8:     	b.ne	0x100846cb8 <_js_json_stringify_full+0x438>
100846cfc:     	orr.16b	v0, v0, v1
100846d00:     	mov	d1, v0[1]
100846d04:     	orr.8b	v0, v0, v1
100846d08:     	fmov	x13, d0
100846d0c:     	cmp	x8, x11
100846d10:     	b.eq	0x100846d34 <_js_json_stringify_full+0x4b4>
100846d14:     	add	x10, x10, x8
100846d18:     	lsl	x11, x11, #3
100846d1c:     	ldrb	w12, [x9], #0x1
100846d20:     	lsl	x12, x12, x11
100846d24:     	orr	x13, x12, x13
100846d28:     	add	x11, x11, #0x8
100846d2c:     	cmp	x9, x10
100846d30:     	b.ne	0x100846d1c <_js_json_stringify_full+0x49c>
100846d34:     	orr	x8, x13, x8, lsl #40
100846d38:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100846d3c:     	orr	x21, x8, x9
100846d40:     	b	0x100847d54 <_js_json_stringify_full+0x14d4>
100846d44:     	cmp	w16, #0x8
100846d48:     	b.eq	0x100846d8c <_js_json_stringify_full+0x50c>
100846d4c:     	cmp	w16, #0x9
100846d50:     	b.eq	0x100846d9c <_js_json_stringify_full+0x51c>
100846d54:     	cmp	w16, #0xa
100846d58:     	b.ne	0x100846d74 <_js_json_stringify_full+0x4f4>
100846d5c:     	mov	w15, #0x6e              ; =110
100846d60:     	b	0x100846da0 <_js_json_stringify_full+0x520>
100846d64:     	cmp	w16, #0x22
100846d68:     	b.eq	0x100846da0 <_js_json_stringify_full+0x520>
100846d6c:     	cmp	w16, #0x5c
100846d70:     	b.eq	0x100846da0 <_js_json_stringify_full+0x520>
100846d74:     	cmp	w15, #0x20
100846d78:     	b.lt	0x100846da4 <_js_json_stringify_full+0x524>
100846d7c:     	add	x13, sp, #0x70
100846d80:     	strb	w15, [x13, x12]
100846d84:     	add	x12, x12, #0x1
100846d88:     	b	0x100847320 <_js_json_stringify_full+0xaa0>
100846d8c:     	mov	w15, #0x62              ; =98
100846d90:     	b	0x100846da0 <_js_json_stringify_full+0x520>
100846d94:     	mov	w15, #0x66              ; =102
100846d98:     	b	0x100846da0 <_js_json_stringify_full+0x520>
100846d9c:     	mov	w15, #0x74              ; =116
100846da0:     	tbz	w14, #0x0, 0x10084730c <_js_json_stringify_full+0xa8c>
100846da4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846da8:     	cmp	x8, x9
100846dac:     	b.eq	0x100846df4 <_js_json_stringify_full+0x574>
100846db0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846db4:     	cmp	x8, x9
100846db8:     	b.ne	0x100846e68 <_js_json_stringify_full+0x5e8>
100846dbc:     	and	x8, x19, #0xffffffffffff
100846dc0:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
100846dc4:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100846dc8:     	movk	x10, #0xffef, lsl #16
100846dcc:     	cmp	x9, x10
100846dd0:     	b.hi	0x100846e68 <_js_json_stringify_full+0x5e8>
100846dd4:     	ldr	w8, [x8, #0x4]
100846dd8:     	cmp	w8, #0x40
100846ddc:     	b.lo	0x100846e68 <_js_json_stringify_full+0x5e8>
100846de0:     	and	x0, x19, #0xffffffffffff
100846de4:     	bl	0x1004f3068 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json16stringify_string17quote_heap_string>
100846de8:     	cmp	x0, #0x1
100846dec:     	b.ne	0x100846e68 <_js_json_stringify_full+0x5e8>
100846df0:     	b	0x100846fa8 <_js_json_stringify_full+0x728>
100846df4:     	and	x24, x19, #0xffffffffffff
100846df8:     	and	x0, x19, #0xffffffffffff
100846dfc:     	bl	0x10057ae80 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100846e00:     	cbz	x0, 0x100846e34 <_js_json_stringify_full+0x5b4>
100846e04:     	ldrb	w8, [x0]
100846e08:     	cmp	w8, #0x2
100846e0c:     	b.ne	0x100846e34 <_js_json_stringify_full+0x5b4>
100846e10:     	ldrsb	w8, [x0, #0x1]
100846e14:     	tbnz	w8, #0x1f, 0x100846e34 <_js_json_stringify_full+0x5b4>
100846e18:     	ldrh	w8, [x0, #0x2]
100846e1c:     	tbnz	w8, #0xb, 0x100846e34 <_js_json_stringify_full+0x5b4>
100846e20:     	ldr	w8, [x0, #0x4]
100846e24:     	cmp	w8, #0x18
100846e28:     	b.lo	0x100846e34 <_js_json_stringify_full+0x5b4>
100846e2c:     	ldr	w8, [x24]
100846e30:     	cbz	w8, 0x100847eb0 <_js_json_stringify_full+0x1630>
100846e34:     	and	x0, x19, #0xffffffffffff
100846e38:     	bl	0x10057ae80 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100846e3c:     	cbz	x0, 0x100846e68 <_js_json_stringify_full+0x5e8>
100846e40:     	ldrb	w8, [x0]
100846e44:     	cmp	w8, #0x2
100846e48:     	b.ne	0x100846e68 <_js_json_stringify_full+0x5e8>
100846e4c:     	ldrh	w8, [x0, #0x2]
100846e50:     	tbnz	w8, #0xb, 0x100846e68 <_js_json_stringify_full+0x5e8>
100846e54:     	ldr	w8, [x0, #0x4]
100846e58:     	cmp	w8, #0x18
100846e5c:     	b.lo	0x100846e68 <_js_json_stringify_full+0x5e8>
100846e60:     	ldr	w8, [x24]
100846e64:     	cbz	w8, 0x100847e54 <_js_json_stringify_full+0x15d4>
100846e68:     	mov	w21, #0x1               ; =1
100846e6c:     	cmp	x19, x26
100846e70:     	b.eq	0x100847d4c <_js_json_stringify_full+0x14cc>
100846e74:     	and	x22, x19, #0xffff000000000000
100846e78:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846e7c:     	cmp	x22, x8
100846e80:     	b.ne	0x100846eb8 <_js_json_stringify_full+0x638>
100846e84:     	and	x8, x19, #0xffffffffffff
100846e88:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846e8c:     	b.lo	0x100846ea4 <_js_json_stringify_full+0x624>
100846e90:     	ldr	w8, [x8, #0xc]
100846e94:     	mov	w9, #0x4f53             ; =20307
100846e98:     	movk	w9, #0x434c, lsl #16
100846e9c:     	cmp	w8, w9
100846ea0:     	b.eq	0x100847d4c <_js_json_stringify_full+0x14cc>
100846ea4:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846ea8:     	cmp	x22, x8
100846eac:     	b.ne	0x100846ee4 <_js_json_stringify_full+0x664>
100846eb0:     	and	x0, x19, #0xffffffffffff
100846eb4:     	b	0x100846f0c <_js_json_stringify_full+0x68c>
100846eb8:     	lsr	x8, x19, #52
100846ebc:     	cbnz	x8, 0x100846f94 <_js_json_stringify_full+0x714>
100846ec0:     	and	x8, x19, #0x7
100846ec4:     	cbz	x19, 0x100846ef0 <_js_json_stringify_full+0x670>
100846ec8:     	cbnz	x8, 0x100846ef0 <_js_json_stringify_full+0x670>
100846ecc:     	mov	x0, x19
100846ed0:     	bl	0x10050f4f8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846ed4:     	mov	x8, x19
100846ed8:     	tbnz	w0, #0x0, 0x100846e88 <_js_json_stringify_full+0x608>
100846edc:     	mov	x8, #0x0                ; =0
100846ee0:     	b	0x100846ef0 <_js_json_stringify_full+0x670>
100846ee4:     	lsr	x8, x19, #52
100846ee8:     	cbnz	x8, 0x100846f94 <_js_json_stringify_full+0x714>
100846eec:     	and	x8, x19, #0x7
100846ef0:     	cbz	x19, 0x100846f94 <_js_json_stringify_full+0x714>
100846ef4:     	cbnz	x8, 0x100846f94 <_js_json_stringify_full+0x714>
100846ef8:     	mov	x0, x19
100846efc:     	bl	0x10050f4f8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846f00:     	mov	x8, x0
100846f04:     	mov	x0, x19
100846f08:     	tbz	w8, #0x0, 0x100846f94 <_js_json_stringify_full+0x714>
100846f0c:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100846f10:     	b.lo	0x100846f94 <_js_json_stringify_full+0x714>
100846f14:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
100846f18:     	add	x8, x8, #0xfb0
100846f1c:     	ldaprb	w8, [x8]
100846f20:     	cbz	w8, 0x100846f94 <_js_json_stringify_full+0x714>
100846f24:     	lsr	x8, x0, #3
100846f28:     	mov	x9, #0x7c15             ; =31765
100846f2c:     	movk	x9, #0x7f4a, lsl #16
100846f30:     	movk	x9, #0x79b9, lsl #32
100846f34:     	movk	x9, #0x9e37, lsl #48
100846f38:     	mul	x8, x8, x9
100846f3c:     	lsr	x10, x8, #54
100846f40:     	lsr	x11, x8, #60
100846f44:     	adrp	x9, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
100846f48:     	add	x9, x9, #0xf30
100846f4c:     	add	x11, x9, x11, lsl #3
100846f50:     	ldapr	x11, [x11]
100846f54:     	lsr	x10, x11, x10
100846f58:     	tbz	w10, #0x0, 0x100846f94 <_js_json_stringify_full+0x714>
100846f5c:     	lsr	x10, x8, #44
100846f60:     	ubfx	x11, x8, #50, #4
100846f64:     	add	x11, x9, x11, lsl #3
100846f68:     	ldapr	x11, [x11]
100846f6c:     	lsr	x10, x11, x10
100846f70:     	tbz	w10, #0x0, 0x100846f94 <_js_json_stringify_full+0x714>
100846f74:     	lsr	x10, x8, #34
100846f78:     	ubfx	x8, x8, #40, #4
100846f7c:     	add	x8, x9, x8, lsl #3
100846f80:     	ldapr	x8, [x8]
100846f84:     	lsr	x8, x8, x10
100846f88:     	tbz	w8, #0x0, 0x100846f94 <_js_json_stringify_full+0x714>
100846f8c:     	bl	0x10034cdec <__RNvNtCs2EcWOpJ680c_13perry_runtime6symbol25is_registered_symbol_slow>
100846f90:     	tbnz	w0, #0x0, 0x100847d4c <_js_json_stringify_full+0x14cc>
100846f94:     	tbz	w21, #0x0, 0x100846fb4 <_js_json_stringify_full+0x734>
100846f98:     	mov.16b	v0, v8
100846f9c:     	bl	0x1004ee13c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100846fa0:     	cmp	x0, #0x1
100846fa4:     	b.ne	0x100846fb4 <_js_json_stringify_full+0x734>
100846fa8:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
100846fac:     	bfxil	x21, x1, #0, #48
100846fb0:     	b	0x100847d54 <_js_json_stringify_full+0x14d4>
100846fb4:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846fb8:     	cmp	x22, x8
100846fbc:     	b.ne	0x10084700c <_js_json_stringify_full+0x78c>
100846fc0:     	ands	x21, x19, #0xffffffffffff
100846fc4:     	b.eq	0x10084700c <_js_json_stringify_full+0x78c>
100846fc8:     	mov	x0, x21
100846fcc:     	bl	0x10050f4f8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846fd0:     	cbz	w0, 0x10084700c <_js_json_stringify_full+0x78c>
100846fd4:     	ldurb	w8, [x21, #-0x8]
100846fd8:     	cmp	w8, #0x9
100846fdc:     	b.ne	0x10084700c <_js_json_stringify_full+0x78c>
100846fe0:     	ldr	w8, [x21, #0x4]
100846fe4:     	mov	w9, #0x5841             ; =22593
100846fe8:     	movk	w9, #0x4c5a, lsl #16
100846fec:     	cmp	w8, w9
100846ff0:     	b.ne	0x10084700c <_js_json_stringify_full+0x78c>
100846ff4:     	mov	x0, x21
100846ff8:     	bl	0x100688f14 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100846ffc:     	cbz	x0, 0x10084700c <_js_json_stringify_full+0x78c>
100847000:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100847004:     	bfxil	x19, x0, #0, #48
100847008:     	fmov	d8, x19
10084700c:     	mov	w8, #0x7ffd             ; =32765
100847010:     	cmp	x8, x23, lsr #48
100847014:     	b.ne	0x100847028 <_js_json_stringify_full+0x7a8>
100847018:     	and	x1, x23, #0xffffffffffff
10084701c:     	cmp	x1, #0x100, lsl #12     ; =0x100000
100847020:     	b.hs	0x10084703c <_js_json_stringify_full+0x7bc>
100847024:     	b	0x100847090 <_js_json_stringify_full+0x810>
100847028:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
10084702c:     	mov	x9, #0xfffffff00000     ; =281474975662080
100847030:     	mov	x1, x23
100847034:     	cmp	x8, x9
100847038:     	b.hs	0x100847090 <_js_json_stringify_full+0x810>
10084703c:     	lsr	x8, x1, #47
100847040:     	cbnz	x8, 0x100847090 <_js_json_stringify_full+0x810>
100847044:     	add	x0, sp, #0x70
100847048:     	bl	0x10076ed2c <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
10084704c:     	ldr	w8, [sp, #0x70]
100847050:     	tbz	w8, #0x0, 0x100847090 <_js_json_stringify_full+0x810>
100847054:     	ldr	w8, [sp, #0x78]
100847058:     	mov	w9, #-0xff30            ; =-65328
10084705c:     	cmp	w8, w9
100847060:     	b.eq	0x100847084 <_js_json_stringify_full+0x804>
100847064:     	mov	w9, #-0xff2f            ; =-65327
100847068:     	cmp	w8, w9
10084706c:     	b.ne	0x100847090 <_js_json_stringify_full+0x810>
100847070:     	mov.16b	v0, v9
100847074:     	bl	0x1008491bc <_js_jsvalue_to_string>
100847078:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
10084707c:     	bfxil	x23, x0, #0, #48
100847080:     	b	0x100847090 <_js_json_stringify_full+0x810>
100847084:     	mov.16b	v0, v9
100847088:     	bl	0x100870760 <_js_number_coerce>
10084708c:     	fmov	x23, d0
100847090:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100847094:     	add	x8, x23, x8
100847098:     	cmp	x8, #0x3
10084709c:     	b.hs	0x1008470b4 <_js_json_stringify_full+0x834>
1008470a0:     	mov	x21, #0x0               ; =0
1008470a4:     	mov	w8, #0x1                ; =1
1008470a8:     	stp	xzr, x8, [sp]
1008470ac:     	str	xzr, [sp, #0x10]
1008470b0:     	b	0x100847368 <_js_json_stringify_full+0xae8>
1008470b4:     	and	x8, x23, #0xffff000000000000
1008470b8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008470bc:     	cmp	x8, x9
1008470c0:     	b.eq	0x1008470e4 <_js_json_stringify_full+0x864>
1008470c4:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
1008470c8:     	cmp	x8, x9
1008470cc:     	b.ne	0x100847170 <_js_json_stringify_full+0x8f0>
1008470d0:     	and	x8, x23, #0xffffffffffff
1008470d4:     	cmp	x8, #0x1, lsl #12       ; =0x1000
1008470d8:     	b.hs	0x1008471b8 <_js_json_stringify_full+0x938>
1008470dc:     	mov	x9, #0x0                ; =0
1008470e0:     	b	0x1008471c0 <_js_json_stringify_full+0x940>
1008470e4:     	strb	wzr, [sp, #0x3c]
1008470e8:     	str	wzr, [sp, #0x38]
1008470ec:     	ubfx	x1, x23, #40, #8
1008470f0:     	cbz	x1, 0x100847140 <_js_json_stringify_full+0x8c0>
1008470f4:     	strb	w23, [sp, #0x38]
1008470f8:     	cmp	x1, #0x1
1008470fc:     	b.eq	0x100847140 <_js_json_stringify_full+0x8c0>
100847100:     	lsr	x8, x23, #8
100847104:     	strb	w8, [sp, #0x39]
100847108:     	cmp	x1, #0x2
10084710c:     	b.eq	0x100847140 <_js_json_stringify_full+0x8c0>
100847110:     	lsr	x8, x23, #16
100847114:     	strb	w8, [sp, #0x3a]
100847118:     	cmp	x1, #0x3
10084711c:     	b.eq	0x100847140 <_js_json_stringify_full+0x8c0>
100847120:     	lsr	x8, x23, #24
100847124:     	strb	w8, [sp, #0x3b]
100847128:     	cmp	x1, #0x4
10084712c:     	b.eq	0x100847140 <_js_json_stringify_full+0x8c0>
100847130:     	lsr	x8, x23, #32
100847134:     	strb	w8, [sp, #0x3c]
100847138:     	cmp	x1, #0x5
10084713c:     	b.ne	0x100848540 <_js_json_stringify_full+0x1cc0>
100847140:     	add	x8, sp, #0x70
100847144:     	add	x0, sp, #0x38
100847148:     	bl	0x10002e158 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10084714c:     	ldr	w8, [sp, #0x70]
100847150:     	ldp	x9, x21, [sp, #0x78]
100847154:     	cmp	w8, #0x0
100847158:     	csinc	x22, x9, xzr, eq
10084715c:     	csel	x24, xzr, x21, ne
100847160:     	tbz	x24, #0x3f, 0x1008472a0 <_js_json_stringify_full+0xa20>
100847164:     	mov	x0, #0x0                ; =0
100847168:     	mov	x1, x21
10084716c:     	bl	0x100b13200 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847170:     	add	x8, x26, #0x3
100847174:     	cmp	x23, x8
100847178:     	b.eq	0x1008470a0 <_js_json_stringify_full+0x820>
10084717c:     	fmov	d0, x23
100847180:     	fcvtzu	x8, d0
100847184:     	mov	w9, #0xa                ; =10
100847188:     	cmp	x8, #0xa
10084718c:     	csel	x3, x8, x9, lo
100847190:     	adrp	x1, 0x100c44000 <_PERRY_EMPTY_STRING+0x1c34>
100847194:     	add	x1, x1, #0x55b
100847198:     	add	x0, sp, #0x70
10084719c:     	mov	w2, #0x1                ; =1
1008471a0:     	bl	0x100230a74 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs2EcWOpJ680c_13perry_runtime>
1008471a4:     	ldr	x21, [sp, #0x80]
1008471a8:     	str	x21, [sp, #0x10]
1008471ac:     	ldr	q0, [sp, #0x70]
1008471b0:     	str	q0, [sp]
1008471b4:     	b	0x100847368 <_js_json_stringify_full+0xae8>
1008471b8:     	ldr	w21, [x8, #0x4]
1008471bc:     	add	x9, x8, #0x14
1008471c0:     	mov	x14, #0x0               ; =0
1008471c4:     	mov	x8, #0x0                ; =0
1008471c8:     	cmp	x9, #0x0
1008471cc:     	csel	x23, xzr, x21, eq
1008471d0:     	csinc	x22, x9, xzr, ne
1008471d4:     	add	x9, x22, x23
1008471d8:     	mov	w10, #0x1               ; =1
1008471dc:     	mov	x11, x22
1008471e0:     	b	0x100847210 <_js_json_stringify_full+0x990>
1008471e4:     	add	x12, x11, #0x2
1008471e8:     	bfi	w15, w13, #6, #5
1008471ec:     	mov	x13, x15
1008471f0:     	sub	x11, x24, x11
1008471f4:     	add	x14, x11, x12
1008471f8:     	cmp	w13, #0x10, lsl #12     ; =0x10000
1008471fc:     	cinc	x11, x10, hs
100847200:     	add	x8, x11, x8
100847204:     	mov	x11, x12
100847208:     	cmp	x8, #0xa
10084720c:     	b.hi	0x1008472c8 <_js_json_stringify_full+0xa48>
100847210:     	cmp	x11, x9
100847214:     	b.eq	0x100847278 <_js_json_stringify_full+0x9f8>
100847218:     	mov	x24, x14
10084721c:     	mov	x12, x11
100847220:     	ldrsb	w14, [x12], #0x1
100847224:     	and	w13, w14, #0xff
100847228:     	tbz	w14, #0x1f, 0x1008471f0 <_js_json_stringify_full+0x970>
10084722c:     	ldrb	w12, [x11, #0x1]
100847230:     	and	w15, w12, #0x3f
100847234:     	cmp	w13, #0xe0
100847238:     	b.lo	0x1008471e4 <_js_json_stringify_full+0x964>
10084723c:     	and	w14, w13, #0x1f
100847240:     	ldrb	w12, [x11, #0x2]
100847244:     	and	w12, w12, #0x3f
100847248:     	orr	w15, w12, w15, lsl #6
10084724c:     	cmp	w13, #0xf0
100847250:     	b.lo	0x10084726c <_js_json_stringify_full+0x9ec>
100847254:     	add	x12, x11, #0x4
100847258:     	ldrb	w13, [x11, #0x3]
10084725c:     	and	w13, w13, #0x3f
100847260:     	orr	w13, w13, w15, lsl #6
100847264:     	bfi	w13, w14, #18, #3
100847268:     	b	0x1008471f0 <_js_json_stringify_full+0x970>
10084726c:     	add	x12, x11, #0x3
100847270:     	orr	w13, w15, w14, lsl #12
100847274:     	b	0x1008471f0 <_js_json_stringify_full+0x970>
100847278:     	cbz	x23, 0x1008472fc <_js_json_stringify_full+0xa7c>
10084727c:     	mov	x0, x23
100847280:     	mov	w1, #0x1                ; =1
100847284:     	bl	0x100b60088 <_mi_malloc_aligned>
100847288:     	cbz	x0, 0x100848528 <_js_json_stringify_full+0x1ca8>
10084728c:     	mov	x25, x0
100847290:     	mov	x1, x22
100847294:     	mov	x2, x23
100847298:     	bl	0x100b62cac <_writev+0x100b62cac>
10084729c:     	b	0x100847304 <_js_json_stringify_full+0xa84>
1008472a0:     	cbz	x24, 0x100847358 <_js_json_stringify_full+0xad8>
1008472a4:     	mov	x0, x24
1008472a8:     	mov	w1, #0x1                ; =1
1008472ac:     	bl	0x100b60088 <_mi_malloc_aligned>
1008472b0:     	cbz	x0, 0x100848534 <_js_json_stringify_full+0x1cb4>
1008472b4:     	mov	x23, x0
1008472b8:     	mov	x1, x22
1008472bc:     	mov	x2, x24
1008472c0:     	bl	0x100b62cac <_writev+0x100b62cac>
1008472c4:     	b	0x100847360 <_js_json_stringify_full+0xae0>
1008472c8:     	cbz	x24, 0x1008472fc <_js_json_stringify_full+0xa7c>
1008472cc:     	cmp	x24, x23
1008472d0:     	b.hs	0x100847da8 <_js_json_stringify_full+0x1528>
1008472d4:     	ldrsb	w8, [x22, x24]
1008472d8:     	cmn	w8, #0x40
1008472dc:     	b.ge	0x100847dac <_js_json_stringify_full+0x152c>
1008472e0:     	adrp	x4, 0x100f10000 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1008472e4:     	add	x4, x4, #0x270
1008472e8:     	mov	x0, x22
1008472ec:     	mov	x1, x23
1008472f0:     	mov	x2, #0x0                ; =0
1008472f4:     	mov	x3, x24
1008472f8:     	bl	0x100b13578 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
1008472fc:     	mov	x21, #0x0               ; =0
100847300:     	mov	w25, #0x1               ; =1
100847304:     	stp	x21, x25, [sp]
100847308:     	b	0x100847364 <_js_json_stringify_full+0xae4>
10084730c:     	add	x14, sp, #0x70
100847310:     	mov	w16, #0x5c              ; =92
100847314:     	strb	w16, [x14, x12]
100847318:     	add	x12, x12, #0x2
10084731c:     	strb	w15, [x13, #0x1]
100847320:     	cmp	w10, #0x2
100847324:     	b.eq	0x100846a94 <_js_json_stringify_full+0x214>
100847328:     	ldrb	w11, [x11, #0x2]
10084732c:     	sxtb	w10, w11
100847330:     	cmp	w11, #0xb
100847334:     	b.le	0x100847e34 <_js_json_stringify_full+0x15b4>
100847338:     	cmp	w11, #0x21
10084733c:     	b.gt	0x100847e80 <_js_json_stringify_full+0x1600>
100847340:     	cmp	w11, #0xc
100847344:     	b.eq	0x100847f0c <_js_json_stringify_full+0x168c>
100847348:     	cmp	w11, #0xd
10084734c:     	b.ne	0x100847e90 <_js_json_stringify_full+0x1610>
100847350:     	mov	w10, #0x72              ; =114
100847354:     	b	0x100847f18 <_js_json_stringify_full+0x1698>
100847358:     	mov	x21, #0x0               ; =0
10084735c:     	mov	w23, #0x1               ; =1
100847360:     	stp	x21, x23, [sp]
100847364:     	str	x21, [sp, #0x10]
100847368:     	cmp	x27, #0x2
10084736c:     	b.lo	0x1008474ac <_js_json_stringify_full+0xc2c>
100847370:     	and	x24, x20, #0xffff000000000000
100847374:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100847378:     	cmp	x24, x8
10084737c:     	b.ne	0x100847488 <_js_json_stringify_full+0xc08>
100847380:     	and	x22, x20, #0xffffffffffff
100847384:     	cmp	x22, #0x100, lsl #12    ; =0x100000
100847388:     	b.lo	0x1008474ac <_js_json_stringify_full+0xc2c>
10084738c:     	mov	x0, x22
100847390:     	bl	0x10050aa00 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify17is_object_pointer>
100847394:     	tbnz	w0, #0x0, 0x1008474ac <_js_json_stringify_full+0xc2c>
100847398:     	lsr	x8, x22, #51
10084739c:     	cmp	x8, #0xfff
1008473a0:     	b.lo	0x1008473b8 <_js_json_stringify_full+0xb38>
1008473a4:     	mov	w8, #0x7ffc             ; =32764
1008473a8:     	cmp	x8, x22, lsr #48
1008473ac:     	b.eq	0x1008474ac <_js_json_stringify_full+0xc2c>
1008473b0:     	ands	x22, x22, #0xffffffffffff
1008473b4:     	b.eq	0x1008474ac <_js_json_stringify_full+0xc2c>
1008473b8:     	and	x8, x22, #0xfffffffffff00000
1008473bc:     	lsr	x9, x22, #47
1008473c0:     	cmp	x9, #0x0
1008473c4:     	ccmp	x8, #0x0, #0x4, eq
1008473c8:     	b.eq	0x1008474ac <_js_json_stringify_full+0xc2c>
1008473cc:     	tst	x22, #0x3
1008473d0:     	ccmp	x22, #0x7, #0x0, eq
1008473d4:     	b.ls	0x100848148 <_js_json_stringify_full+0x18c8>
1008473d8:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1008473dc:     	ldr	x8, [x8, #0x48]
1008473e0:     	cmn	x8, #0x1
1008473e4:     	b.eq	0x100848098 <_js_json_stringify_full+0x1818>
1008473e8:     	mrs	x9, TPIDRRO_EL0
1008473ec:     	and	x9, x9, #0xfffffffffffffff8
1008473f0:     	ldr	x0, [x9, x8, lsl #3]
1008473f4:     	cbz	x0, 0x100848098 <_js_json_stringify_full+0x1818>
1008473f8:     	lsr	x1, x22, #20
1008473fc:     	ldr	x8, [x0, #0x10]
100847400:     	ldrb	w9, [x8]
100847404:     	cmp	w9, #0x2
100847408:     	b.ne	0x1008480b0 <_js_json_stringify_full+0x1830>
10084740c:     	ldrb	w9, [x8, #0x88]
100847410:     	tbz	w9, #0x0, 0x100847430 <_js_json_stringify_full+0xbb0>
100847414:     	ldr	x9, [x8, #0x80]
100847418:     	cmp	x9, x1
10084741c:     	b.ne	0x100847430 <_js_json_stringify_full+0xbb0>
100847420:     	ldp	x9, x10, [x8, #0x60]
100847424:     	cmp	x9, x22
100847428:     	ccmp	x10, x22, #0x0, ls
10084742c:     	b.hi	0x100848090 <_js_json_stringify_full+0x1810>
100847430:     	ldrb	w9, [x8, #0xb8]
100847434:     	cbz	w9, 0x100847454 <_js_json_stringify_full+0xbd4>
100847438:     	ldr	x9, [x8, #0xb0]
10084743c:     	cmp	x9, x1
100847440:     	b.ne	0x100847454 <_js_json_stringify_full+0xbd4>
100847444:     	ldp	x9, x10, [x8, #0x90]
100847448:     	cmp	x9, x22
10084744c:     	ccmp	x10, x22, #0x0, ls
100847450:     	b.hi	0x100848318 <_js_json_stringify_full+0x1a98>
100847454:     	ldrb	w9, [x8, #0xe8]
100847458:     	cbz	w9, 0x100847ed0 <_js_json_stringify_full+0x1650>
10084745c:     	ldr	x9, [x8, #0xe0]
100847460:     	cmp	x9, x1
100847464:     	b.ne	0x100847ed0 <_js_json_stringify_full+0x1650>
100847468:     	ldr	x9, [x8, #0xc0]
10084746c:     	cmp	x9, x22
100847470:     	b.hi	0x100847ed0 <_js_json_stringify_full+0x1650>
100847474:     	ldr	x9, [x8, #0xc8]
100847478:     	cmp	x9, x22
10084747c:     	b.ls	0x100847ed0 <_js_json_stringify_full+0x1650>
100847480:     	add	x9, x8, #0xc0
100847484:     	b	0x10084831c <_js_json_stringify_full+0x1a9c>
100847488:     	lsr	x8, x20, #52
10084748c:     	cbnz	x8, 0x1008474ac <_js_json_stringify_full+0xc2c>
100847490:     	cbz	x20, 0x1008474ac <_js_json_stringify_full+0xc2c>
100847494:     	and	x8, x20, #0x7
100847498:     	cbnz	x8, 0x1008474ac <_js_json_stringify_full+0xc2c>
10084749c:     	mov	x0, x20
1008474a0:     	bl	0x10050f4f8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008474a4:     	mov	x22, x20
1008474a8:     	cbnz	w0, 0x100847384 <_js_json_stringify_full+0xb04>
1008474ac:     	mov	x24, #-0x1              ; =-1
1008474b0:     	str	x24, [sp, #0x20]
1008474b4:     	mov	w23, #0x1               ; =1
1008474b8:     	cmp	x27, #0x1
1008474bc:     	cset	w8, hi
1008474c0:     	tst	w8, w23
1008474c4:     	b.eq	0x100847538 <_js_json_stringify_full+0xcb8>
1008474c8:     	and	x22, x20, #0xffff000000000000
1008474cc:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008474d0:     	cmp	x22, x8
1008474d4:     	b.ne	0x100847510 <_js_json_stringify_full+0xc90>
1008474d8:     	and	x8, x20, #0xffffffffffff
1008474dc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1008474e0:     	b.lo	0x100847538 <_js_json_stringify_full+0xcb8>
1008474e4:     	ldr	w8, [x8, #0xc]
1008474e8:     	mov	w9, #0x4f53             ; =20307
1008474ec:     	movk	w9, #0x434c, lsl #16
1008474f0:     	cmp	w8, w9
1008474f4:     	b.ne	0x100847538 <_js_json_stringify_full+0xcb8>
1008474f8:     	and	x8, x20, #0xffffffffffff
1008474fc:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100847500:     	cmp	x22, x9
100847504:     	csel	x28, x8, x20, eq
100847508:     	mov	w27, #0x1               ; =1
10084750c:     	b	0x10084753c <_js_json_stringify_full+0xcbc>
100847510:     	lsr	x8, x20, #52
100847514:     	cbnz	x8, 0x100847538 <_js_json_stringify_full+0xcb8>
100847518:     	mov	w27, #0x0               ; =0
10084751c:     	cbz	x20, 0x10084753c <_js_json_stringify_full+0xcbc>
100847520:     	and	x8, x20, #0x7
100847524:     	cbnz	x8, 0x10084753c <_js_json_stringify_full+0xcbc>
100847528:     	mov	x0, x20
10084752c:     	bl	0x10050f4f8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100847530:     	mov	x8, x20
100847534:     	tbnz	w0, #0x0, 0x1008474dc <_js_json_stringify_full+0xc5c>
100847538:     	mov	w27, #0x0               ; =0
10084753c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847540:     	add	x0, x0, #0xd78
100847544:     	ldr	x8, [x0]
100847548:     	blr	x8
10084754c:     	mov	x20, x0
100847550:     	ldr	w25, [x0]
100847554:     	add	w8, w25, #0x1
100847558:     	str	w8, [x0]
10084755c:     	cbz	w25, 0x1008475cc <_js_json_stringify_full+0xd4c>
100847560:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847564:     	add	x0, x0, #0xd00
100847568:     	ldr	x8, [x0]
10084756c:     	blr	x8
100847570:     	ldrb	w8, [x0, #0x20]
100847574:     	cmp	w8, #0x1
100847578:     	b.ne	0x100848388 <_js_json_stringify_full+0x1b08>
10084757c:     	ldr	x8, [x0]
100847580:     	cbnz	x8, 0x100848394 <_js_json_stringify_full+0x1b14>
100847584:     	mov	x8, #-0x1               ; =-1
100847588:     	str	x8, [x0]
10084758c:     	ldr	x22, [x0, #0x18]
100847590:     	ldr	x8, [x0, #0x8]
100847594:     	cmp	x22, x8
100847598:     	b.eq	0x100847d7c <_js_json_stringify_full+0x14fc>
10084759c:     	ldr	x8, [x0, #0x10]
1008475a0:     	mov	w9, #0x18               ; =24
1008475a4:     	madd	x8, x22, x9, x8
1008475a8:     	mov	w9, #0x8                ; =8
1008475ac:     	stp	xzr, x9, [x8]
1008475b0:     	str	xzr, [x8, #0x10]
1008475b4:     	add	x8, x22, #0x1
1008475b8:     	str	x8, [x0, #0x18]
1008475bc:     	ldr	x8, [x0]
1008475c0:     	add	x8, x8, #0x1
1008475c4:     	str	x8, [x0]
1008475c8:     	b	0x100847634 <_js_json_stringify_full+0xdb4>
1008475cc:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008475d0:     	add	x0, x0, #0xdc0
1008475d4:     	ldr	x8, [x0]
1008475d8:     	blr	x8
1008475dc:     	strb	wzr, [x0]
1008475e0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008475e4:     	add	x0, x0, #0xdf0
1008475e8:     	ldr	x8, [x0]
1008475ec:     	blr	x8
1008475f0:     	strb	wzr, [x0]
1008475f4:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
1008475f8:     	ldr	w22, [x8, #0x5a8]
1008475fc:     	cmp	w22, #0x300
100847600:     	b.hs	0x100847dcc <_js_json_stringify_full+0x154c>
100847604:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100847608:     	ldr	x8, [x8, #0x48]
10084760c:     	cmn	x8, #0x1
100847610:     	b.eq	0x100847dbc <_js_json_stringify_full+0x153c>
100847614:     	mrs	x9, TPIDRRO_EL0
100847618:     	and	x9, x9, #0xfffffffffffffff8
10084761c:     	ldr	x0, [x9, x8, lsl #3]
100847620:     	cbz	x0, 0x100847dbc <_js_json_stringify_full+0x153c>
100847624:     	add	x8, x0, x22, lsl #3
100847628:     	ldr	x0, [x8, #0x1e8]
10084762c:     	cbz	x0, 0x100847dcc <_js_json_stringify_full+0x154c>
100847630:     	str	xzr, [x0]
100847634:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847638:     	add	x0, x0, #0xd30
10084763c:     	ldr	x8, [x0]
100847640:     	blr	x8
100847644:     	mov	x22, x0
100847648:     	ldrb	w8, [x0, #0x18]
10084764c:     	cmp	w8, #0x1
100847650:     	b.ne	0x10084833c <_js_json_stringify_full+0x1abc>
100847654:     	ldr	x8, [x0]
100847658:     	mov	x9, #-0x1               ; =-1
10084765c:     	str	x9, [x0]
100847660:     	cmn	x8, #0x2
100847664:     	b.eq	0x1008484d4 <_js_json_stringify_full+0x1c54>
100847668:     	cmn	x8, #0x1
10084766c:     	b.eq	0x100847740 <_js_json_stringify_full+0xec0>
100847670:     	add	x9, sp, #0x38
100847674:     	ldur	q0, [x0, #0x8]
100847678:     	stur	q0, [x9, #0x8]
10084767c:     	str	x8, [sp, #0x38]
100847680:     	tbz	w23, #0x0, 0x100847754 <_js_json_stringify_full+0xed4>
100847684:     	tbz	w27, #0x0, 0x10084783c <_js_json_stringify_full+0xfbc>
100847688:     	bl	0x10028b898 <__RNvMs_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
10084768c:     	str	x0, [sp, #0x50]
100847690:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100847694:     	stp	x28, x8, [sp, #0x78]
100847698:     	mov	w8, #0x1                ; =1
10084769c:     	str	x8, [sp, #0x70]
1008476a0:     	add	x0, sp, #0x70
1008476a4:     	bl	0x10028b9a0 <__RNvMs_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
1008476a8:     	mov	x21, x0
1008476ac:     	str	x0, [sp, #0x58]
1008476b0:     	mov	w0, #0x0                ; =0
1008476b4:     	bl	0x10034b56c <__RNvNtCs2EcWOpJ680c_13perry_runtime6string20string_storage_alloc>
1008476b8:     	stp	xzr, xzr, [x0]
1008476bc:     	str	wzr, [x0, #0x10]
1008476c0:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008476c4:     	bfxil	x8, x0, #0, #48
1008476c8:     	fmov	d0, x8
1008476cc:     	bl	0x10020b5a4 <__RNCINvNtNtCs2EcWOpJ680c_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
1008476d0:     	mov	x19, x0
1008476d4:     	adrp	x23, 0x100f80000 <_perry_global_worker_ts__1>
1008476d8:     	ldr	x8, [x23, #0x48]
1008476dc:     	cmn	x8, #0x1
1008476e0:     	b.eq	0x1008478a0 <_js_json_stringify_full+0x1020>
1008476e4:     	mrs	x9, TPIDRRO_EL0
1008476e8:     	and	x9, x9, #0xfffffffffffffff8
1008476ec:     	ldr	x8, [x9, x8, lsl #3]
1008476f0:     	cbz	x8, 0x1008478a0 <_js_json_stringify_full+0x1020>
1008476f4:     	ldr	x8, [x8, #0x19e8]
1008476f8:     	cbz	x8, 0x1008478a0 <_js_json_stringify_full+0x1020>
1008476fc:     	ldr	x9, [x8]
100847700:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100847704:     	cmp	x9, x10
100847708:     	b.hs	0x10084840c <_js_json_stringify_full+0x1b8c>
10084770c:     	add	x10, x9, #0x1
100847710:     	str	x10, [x8]
100847714:     	ldr	x10, [x8, #0x18]
100847718:     	cmp	x19, x10
10084771c:     	b.hs	0x100848418 <_js_json_stringify_full+0x1b98>
100847720:     	ldr	x10, [x8, #0x10]
100847724:     	mov	w11, #0x18              ; =24
100847728:     	madd	x10, x19, x11, x10
10084772c:     	ldr	x11, [x10]
100847730:     	cbnz	x11, 0x100848478 <_js_json_stringify_full+0x1bf8>
100847734:     	ldr	x0, [x10, #0x8]
100847738:     	str	x9, [x8]
10084773c:     	b	0x1008478a8 <_js_json_stringify_full+0x1028>
100847740:     	mov	x8, #0x0                ; =0
100847744:     	mov	w9, #0x1                ; =1
100847748:     	stp	x9, xzr, [sp, #0x40]
10084774c:     	str	x8, [sp, #0x38]
100847750:     	tbnz	w23, #0x0, 0x100847684 <_js_json_stringify_full+0xe04>
100847754:     	cmp	x21, #0x0
100847758:     	cset	w6, ne
10084775c:     	ldp	x0, x1, [sp, #0x28]
100847760:     	ldp	x3, x4, [sp, #0x8]
100847764:     	add	x2, sp, #0x38
100847768:     	mov.16b	v0, v8
10084776c:     	mov	x5, #0x0                ; =0
100847770:     	bl	0x100503240 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
100847774:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847778:     	add	x0, x0, #0xd90
10084777c:     	ldr	x8, [x0]
100847780:     	blr	x8
100847784:     	ldrb	w8, [x0, #0x20]
100847788:     	cbnz	w8, 0x1008483a0 <_js_json_stringify_full+0x1b20>
10084778c:     	ldr	x8, [x0]
100847790:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100847794:     	cmp	x8, x9
100847798:     	b.hs	0x1008483d0 <_js_json_stringify_full+0x1b50>
10084779c:     	ldr	x9, [x0, #0x18]
1008477a0:     	cbz	x9, 0x1008477ac <_js_json_stringify_full+0xf2c>
1008477a4:     	cbnz	x8, 0x1008483dc <_js_json_stringify_full+0x1b5c>
1008477a8:     	str	xzr, [x0, #0x18]
1008477ac:     	ldp	x0, x1, [sp, #0x40]
1008477b0:     	cmp	x1, #0x5
1008477b4:     	b.hi	0x10084781c <_js_json_stringify_full+0xf9c>
1008477b8:     	cbz	x1, 0x100847a2c <_js_json_stringify_full+0x11ac>
1008477bc:     	ldrsb	w8, [x0]
1008477c0:     	tbnz	w8, #0x1f, 0x10084781c <_js_json_stringify_full+0xf9c>
1008477c4:     	cmp	x1, #0x1
1008477c8:     	b.eq	0x100847804 <_js_json_stringify_full+0xf84>
1008477cc:     	ldrsb	w8, [x0, #0x1]
1008477d0:     	tbnz	w8, #0x1f, 0x10084781c <_js_json_stringify_full+0xf9c>
1008477d4:     	cmp	x1, #0x2
1008477d8:     	b.eq	0x100847804 <_js_json_stringify_full+0xf84>
1008477dc:     	ldrsb	w8, [x0, #0x2]
1008477e0:     	tbnz	w8, #0x1f, 0x10084781c <_js_json_stringify_full+0xf9c>
1008477e4:     	cmp	x1, #0x3
1008477e8:     	b.eq	0x100847804 <_js_json_stringify_full+0xf84>
1008477ec:     	ldrsb	w8, [x0, #0x3]
1008477f0:     	tbnz	w8, #0x1f, 0x10084781c <_js_json_stringify_full+0xf9c>
1008477f4:     	cmp	x1, #0x4
1008477f8:     	b.eq	0x100847804 <_js_json_stringify_full+0xf84>
1008477fc:     	ldrsb	w8, [x0, #0x4]
100847800:     	tbnz	w8, #0x1f, 0x10084781c <_js_json_stringify_full+0xf9c>
100847804:     	cmp	x1, #0x4
100847808:     	b.hs	0x100847b6c <_js_json_stringify_full+0x12ec>
10084780c:     	mov	x10, #0x0               ; =0
100847810:     	mov	x9, #0x0                ; =0
100847814:     	mov	x8, x0
100847818:     	b	0x100847bfc <_js_json_stringify_full+0x137c>
10084781c:     	bl	0x10032a244 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json36json_string_from_native_output_bytes>
100847820:     	mov	x21, #0x7fff000000000000 ; =9223090561878065152
100847824:     	bfxil	x21, x0, #0, #48
100847828:     	ldp	x23, x0, [sp, #0x38]
10084782c:     	ldrb	w8, [x22, #0x18]
100847830:     	cmp	w8, #0x1
100847834:     	b.eq	0x100847c38 <_js_json_stringify_full+0x13b8>
100847838:     	b	0x100848368 <_js_json_stringify_full+0x1ae8>
10084783c:     	mov	w0, #0x0                ; =0
100847840:     	bl	0x10034b56c <__RNvNtCs2EcWOpJ680c_13perry_runtime6string20string_storage_alloc>
100847844:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100847848:     	bfxil	x8, x0, #0, #48
10084784c:     	fmov	d1, x8
100847850:     	stp	xzr, xzr, [x0]
100847854:     	str	wzr, [x0, #0x10]
100847858:     	mov.16b	v0, v8
10084785c:     	bl	0x1004ffcbc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer19apply_to_json_keyed>
100847860:     	mov.16b	v8, v0
100847864:     	fmov	x23, d8
100847868:     	cmp	x23, x26
10084786c:     	b.eq	0x100847ab4 <_js_json_stringify_full+0x1234>
100847870:     	mov	w8, #0x7ffd             ; =32765
100847874:     	cmp	x8, x23, lsr #48
100847878:     	b.ne	0x100847a84 <_js_json_stringify_full+0x1204>
10084787c:     	and	x8, x23, #0xffffffffffff
100847880:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100847884:     	b.lo	0x100847aa8 <_js_json_stringify_full+0x1228>
100847888:     	ldr	w8, [x8, #0xc]
10084788c:     	mov	w9, #0x4f53             ; =20307
100847890:     	movk	w9, #0x434c, lsl #16
100847894:     	cmp	w8, w9
100847898:     	b.ne	0x100847aa8 <_js_json_stringify_full+0x1228>
10084789c:     	b	0x100847ab4 <_js_json_stringify_full+0x1234>
1008478a0:     	mov	x0, x19
1008478a4:     	bl	0x10013c6a8 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
1008478a8:     	fmov	d1, x0
1008478ac:     	mov.16b	v0, v8
1008478b0:     	bl	0x1004ffcbc <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer19apply_to_json_keyed>
1008478b4:     	mov.16b	v8, v0
1008478b8:     	ldr	x8, [x23, #0x48]
1008478bc:     	cmn	x8, #0x1
1008478c0:     	b.eq	0x100847924 <_js_json_stringify_full+0x10a4>
1008478c4:     	mrs	x9, TPIDRRO_EL0
1008478c8:     	and	x9, x9, #0xfffffffffffffff8
1008478cc:     	ldr	x8, [x9, x8, lsl #3]
1008478d0:     	cbz	x8, 0x100847924 <_js_json_stringify_full+0x10a4>
1008478d4:     	ldr	x8, [x8, #0x19e8]
1008478d8:     	cbz	x8, 0x100847924 <_js_json_stringify_full+0x10a4>
1008478dc:     	ldr	x9, [x8]
1008478e0:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1008478e4:     	cmp	x9, x10
1008478e8:     	b.hs	0x10084840c <_js_json_stringify_full+0x1b8c>
1008478ec:     	add	x10, x9, #0x1
1008478f0:     	str	x10, [x8]
1008478f4:     	ldr	x10, [x8, #0x18]
1008478f8:     	cmp	x21, x10
1008478fc:     	b.hs	0x100848418 <_js_json_stringify_full+0x1b98>
100847900:     	ldr	x10, [x8, #0x10]
100847904:     	mov	w11, #0x18              ; =24
100847908:     	madd	x10, x21, x11, x10
10084790c:     	ldr	x11, [x10]
100847910:     	cmp	x11, #0x1
100847914:     	b.ne	0x1008484ec <_js_json_stringify_full+0x1c6c>
100847918:     	ldr	x21, [x10, #0x8]
10084791c:     	str	x9, [x8]
100847920:     	b	0x100847930 <_js_json_stringify_full+0x10b0>
100847924:     	mov	x0, x21
100847928:     	bl	0x10013c5d0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
10084792c:     	mov	x21, x0
100847930:     	ldr	x8, [x23, #0x48]
100847934:     	cmn	x8, #0x1
100847938:     	b.eq	0x100847998 <_js_json_stringify_full+0x1118>
10084793c:     	mrs	x9, TPIDRRO_EL0
100847940:     	and	x9, x9, #0xfffffffffffffff8
100847944:     	ldr	x8, [x9, x8, lsl #3]
100847948:     	cbz	x8, 0x100847998 <_js_json_stringify_full+0x1118>
10084794c:     	ldr	x8, [x8, #0x19e8]
100847950:     	cbz	x8, 0x100847998 <_js_json_stringify_full+0x1118>
100847954:     	ldr	x9, [x8]
100847958:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
10084795c:     	cmp	x9, x10
100847960:     	b.hs	0x10084840c <_js_json_stringify_full+0x1b8c>
100847964:     	add	x10, x9, #0x1
100847968:     	str	x10, [x8]
10084796c:     	ldr	x10, [x8, #0x18]
100847970:     	cmp	x19, x10
100847974:     	b.hs	0x100848418 <_js_json_stringify_full+0x1b98>
100847978:     	ldr	x10, [x8, #0x10]
10084797c:     	mov	w11, #0x18              ; =24
100847980:     	madd	x10, x19, x11, x10
100847984:     	ldr	x11, [x10]
100847988:     	cbnz	x11, 0x100848478 <_js_json_stringify_full+0x1bf8>
10084798c:     	ldr	x0, [x10, #0x8]
100847990:     	str	x9, [x8]
100847994:     	b	0x1008479a0 <_js_json_stringify_full+0x1120>
100847998:     	mov	x0, x19
10084799c:     	bl	0x10013c6a8 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
1008479a0:     	fmov	d9, x0
1008479a4:     	mov.16b	v0, v8
1008479a8:     	bl	0x1004ff7f4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer11root_holder>
1008479ac:     	mov.16b	v2, v0
1008479b0:     	mov	x0, x21
1008479b4:     	mov.16b	v0, v9
1008479b8:     	mov.16b	v1, v8
1008479bc:     	bl	0x1004ffad4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer13call_replacer>
1008479c0:     	str	d0, [sp, #0x60]
1008479c4:     	fmov	x19, d0
1008479c8:     	cmp	x19, x26
1008479cc:     	b.ne	0x100847a34 <_js_json_stringify_full+0x11b4>
1008479d0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008479d4:     	add	x0, x0, #0xd90
1008479d8:     	ldr	x8, [x0]
1008479dc:     	blr	x8
1008479e0:     	ldrb	w8, [x0, #0x20]
1008479e4:     	cbnz	w8, 0x1008484cc <_js_json_stringify_full+0x1c4c>
1008479e8:     	ldr	x8, [x0]
1008479ec:     	cbnz	x8, 0x10084851c <_js_json_stringify_full+0x1c9c>
1008479f0:     	str	xzr, [x0, #0x18]
1008479f4:     	ldp	x21, x19, [sp, #0x38]
1008479f8:     	ldrb	w8, [x22, #0x18]
1008479fc:     	cmp	w8, #0x1
100847a00:     	b.ne	0x100848450 <_js_json_stringify_full+0x1bd0>
100847a04:     	ldp	x8, x0, [x22]
100847a08:     	stp	x21, x19, [x22]
100847a0c:     	str	xzr, [x22, #0x10]
100847a10:     	sub	x8, x8, #0x1
100847a14:     	cmn	x8, #0x2
100847a18:     	b.hs	0x100847a20 <_js_json_stringify_full+0x11a0>
100847a1c:     	bl	0x100b5fe00 <_mi_free>
100847a20:     	cbz	w25, 0x100847ce0 <_js_json_stringify_full+0x1460>
100847a24:     	bl	0x1003284a4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json19restore_shape_cache>
100847a28:     	b	0x100847ce4 <_js_json_stringify_full+0x1464>
100847a2c:     	mov	x10, #0x0               ; =0
100847a30:     	b	0x100847c1c <_js_json_stringify_full+0x139c>
100847a34:     	add	x0, sp, #0x38
100847a38:     	bl	0x100500830 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer21write_replaced_scalar>
100847a3c:     	tbnz	w0, #0x0, 0x100847a78 <_js_json_stringify_full+0x11f8>
100847a40:     	mov	x0, x19
100847a44:     	bl	0x1003281a8 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json15extract_pointer>
100847a48:     	cmp	x0, #0x1
100847a4c:     	b.ne	0x1008484e0 <_js_json_stringify_full+0x1c60>
100847a50:     	add	x8, sp, #0x68
100847a54:     	add	x9, sp, #0x60
100847a58:     	stp	x1, x8, [sp, #0x68]
100847a5c:     	str	x9, [sp, #0x78]
100847a60:     	add	x8, sp, #0x38
100847a64:     	mov	x9, sp
100847a68:     	stp	x8, x9, [sp, #0x80]
100847a6c:     	add	x0, sp, #0x58
100847a70:     	add	x1, sp, #0x70
100847a74:     	bl	0x100144210 <__RINvMs2_NtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
100847a78:     	add	x0, sp, #0x50
100847a7c:     	bl	0x1001672fc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100847a80:     	b	0x100847774 <_js_json_stringify_full+0xef4>
100847a84:     	lsr	x8, x23, #52
100847a88:     	cbnz	x8, 0x100847aa8 <_js_json_stringify_full+0x1228>
100847a8c:     	cbz	x23, 0x100847aa8 <_js_json_stringify_full+0x1228>
100847a90:     	and	x8, x23, #0x7
100847a94:     	cbnz	x8, 0x100847aa8 <_js_json_stringify_full+0x1228>
100847a98:     	mov	x0, x23
100847a9c:     	bl	0x10050f4f8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100847aa0:     	mov	x8, x23
100847aa4:     	tbnz	w0, #0x0, 0x100847880 <_js_json_stringify_full+0x1000>
100847aa8:     	mov	x0, x23
100847aac:     	bl	0x100509854 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify15is_symbol_value>
100847ab0:     	tbz	w0, #0x0, 0x100847b40 <_js_json_stringify_full+0x12c0>
100847ab4:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847ab8:     	add	x0, x0, #0xd90
100847abc:     	ldr	x8, [x0]
100847ac0:     	blr	x8
100847ac4:     	ldrb	w8, [x0, #0x20]
100847ac8:     	cbnz	w8, 0x10084841c <_js_json_stringify_full+0x1b9c>
100847acc:     	ldr	x8, [x0]
100847ad0:     	cbnz	x8, 0x100848444 <_js_json_stringify_full+0x1bc4>
100847ad4:     	str	xzr, [x0, #0x18]
100847ad8:     	ldp	x21, x19, [sp, #0x38]
100847adc:     	ldrb	w8, [x22, #0x18]
100847ae0:     	cmp	w8, #0x1
100847ae4:     	b.ne	0x1008483f8 <_js_json_stringify_full+0x1b78>
100847ae8:     	ldp	x8, x0, [x22]
100847aec:     	stp	x21, x19, [x22]
100847af0:     	str	xzr, [x22, #0x10]
100847af4:     	sub	x8, x8, #0x1
100847af8:     	cmn	x8, #0x2
100847afc:     	b.hs	0x100847b04 <_js_json_stringify_full+0x1284>
100847b00:     	bl	0x100b5fe00 <_mi_free>
100847b04:     	cbz	w25, 0x100847b24 <_js_json_stringify_full+0x12a4>
100847b08:     	bl	0x1003284a4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json19restore_shape_cache>
100847b0c:     	ldr	w8, [x20]
100847b10:     	sub	w8, w8, #0x1
100847b14:     	str	w8, [x20]
100847b18:     	cmn	x24, #0x1
100847b1c:     	b.ne	0x100847d00 <_js_json_stringify_full+0x1480>
100847b20:     	b	0x100847d3c <_js_json_stringify_full+0x14bc>
100847b24:     	bl	0x1003282d4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json17clear_shape_cache>
100847b28:     	ldr	w8, [x20]
100847b2c:     	sub	w8, w8, #0x1
100847b30:     	str	w8, [x20]
100847b34:     	cmn	x24, #0x1
100847b38:     	b.ne	0x100847d00 <_js_json_stringify_full+0x1480>
100847b3c:     	b	0x100847d3c <_js_json_stringify_full+0x14bc>
100847b40:     	cmp	x19, x23
100847b44:     	b.eq	0x100847b50 <_js_json_stringify_full+0x12d0>
100847b48:     	mov.16b	v0, v8
100847b4c:     	bl	0x10050ec2c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify24arm_to_json_result_guard>
100847b50:     	cbz	x21, 0x100847ddc <_js_json_stringify_full+0x155c>
100847b54:     	ldp	x1, x2, [sp, #0x8]
100847b58:     	add	x0, sp, #0x38
100847b5c:     	mov.16b	v0, v8
100847b60:     	mov	x3, #0x0                ; =0
100847b64:     	bl	0x100501320 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer22stringify_value_pretty>
100847b68:     	b	0x100847dec <_js_json_stringify_full+0x156c>
100847b6c:     	and	x9, x1, #0x4
100847b70:     	add	x8, x0, x9
100847b74:     	adrp	x10, 0x100c9a000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4ff0>
100847b78:     	ldr	q0, [x10, #0x880]
100847b7c:     	adrp	x10, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x337fa>
100847b80:     	ldr	q2, [x10, #0x780]
100847b84:     	movi.2d	v1, #0000000000000000
100847b88:     	movi.2d	v3, #0x000000000000ff
100847b8c:     	mov	w10, #0x4               ; =4
100847b90:     	dup.2d	v4, x10
100847b94:     	mov	x10, x0
100847b98:     	and	x11, x1, #0x4
100847b9c:     	movi.2d	v5, #0000000000000000
100847ba0:     	ldr	s6, [x10], #0x4
100847ba4:     	ushll.8h	v6, v6, #0x0
100847ba8:     	ushll.4s	v6, v6, #0x0
100847bac:     	ushll2.2d	v7, v6, #0x0
100847bb0:     	and.16b	v7, v7, v3
100847bb4:     	ushll.2d	v6, v6, #0x0
100847bb8:     	and.16b	v6, v6, v3
100847bbc:     	shl.2d	v16, v0, #0x3
100847bc0:     	shl.2d	v17, v2, #0x3
100847bc4:     	ushl.2d	v6, v6, v17
100847bc8:     	ushl.2d	v7, v7, v16
100847bcc:     	orr.16b	v1, v7, v1
100847bd0:     	orr.16b	v5, v6, v5
100847bd4:     	add.2d	v0, v0, v4
100847bd8:     	add.2d	v2, v2, v4
100847bdc:     	subs	x11, x11, #0x4
100847be0:     	b.ne	0x100847ba0 <_js_json_stringify_full+0x1320>
100847be4:     	orr.16b	v0, v5, v1
100847be8:     	mov	d1, v0[1]
100847bec:     	orr.8b	v0, v0, v1
100847bf0:     	fmov	x10, d0
100847bf4:     	cmp	x1, x9
100847bf8:     	b.eq	0x100847c1c <_js_json_stringify_full+0x139c>
100847bfc:     	add	x11, x0, x1
100847c00:     	lsl	x9, x9, #3
100847c04:     	ldrb	w12, [x8], #0x1
100847c08:     	lsl	x12, x12, x9
100847c0c:     	orr	x10, x12, x10
100847c10:     	add	x9, x9, #0x8
100847c14:     	cmp	x8, x11
100847c18:     	b.ne	0x100847c04 <_js_json_stringify_full+0x1384>
100847c1c:     	orr	x8, x10, x1, lsl #40
100847c20:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100847c24:     	orr	x21, x8, x9
100847c28:     	ldr	x23, [sp, #0x38]
100847c2c:     	ldrb	w8, [x22, #0x18]
100847c30:     	cmp	w8, #0x1
100847c34:     	b.ne	0x100848368 <_js_json_stringify_full+0x1ae8>
100847c38:     	ldp	x9, x8, [x22]
100847c3c:     	stp	x23, x0, [x22]
100847c40:     	str	xzr, [x22, #0x10]
100847c44:     	sub	x9, x9, #0x1
100847c48:     	cmn	x9, #0x2
100847c4c:     	b.hs	0x100847c58 <_js_json_stringify_full+0x13d8>
100847c50:     	mov	x0, x8
100847c54:     	bl	0x100b5fe00 <_mi_free>
100847c58:     	cbz	w25, 0x100847c78 <_js_json_stringify_full+0x13f8>
100847c5c:     	bl	0x1003284a4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json19restore_shape_cache>
100847c60:     	ldr	w8, [x20]
100847c64:     	sub	w8, w8, #0x1
100847c68:     	str	w8, [x20]
100847c6c:     	cmn	x24, #0x1
100847c70:     	b.ne	0x100847c90 <_js_json_stringify_full+0x1410>
100847c74:     	b	0x100847ccc <_js_json_stringify_full+0x144c>
100847c78:     	bl	0x1003282d4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json17clear_shape_cache>
100847c7c:     	ldr	w8, [x20]
100847c80:     	sub	w8, w8, #0x1
100847c84:     	str	w8, [x20]
100847c88:     	cmn	x24, #0x1
100847c8c:     	b.eq	0x100847ccc <_js_json_stringify_full+0x144c>
100847c90:     	ldp	x19, x20, [sp, #0x28]
100847c94:     	cbz	x20, 0x100847cc0 <_js_json_stringify_full+0x1440>
100847c98:     	add	x22, x19, #0x8
100847c9c:     	b	0x100847cac <_js_json_stringify_full+0x142c>
100847ca0:     	add	x22, x22, #0x18
100847ca4:     	subs	x20, x20, #0x1
100847ca8:     	b.eq	0x100847cc0 <_js_json_stringify_full+0x1440>
100847cac:     	ldur	x8, [x22, #-0x8]
100847cb0:     	cbz	x8, 0x100847ca0 <_js_json_stringify_full+0x1420>
100847cb4:     	ldr	x0, [x22]
100847cb8:     	bl	0x100b5fe00 <_mi_free>
100847cbc:     	b	0x100847ca0 <_js_json_stringify_full+0x1420>
100847cc0:     	cbz	x24, 0x100847ccc <_js_json_stringify_full+0x144c>
100847cc4:     	mov	x0, x19
100847cc8:     	bl	0x100b5fe00 <_mi_free>
100847ccc:     	ldr	x8, [sp]
100847cd0:     	cbz	x8, 0x100847d54 <_js_json_stringify_full+0x14d4>
100847cd4:     	ldr	x0, [sp, #0x8]
100847cd8:     	bl	0x100b5fe00 <_mi_free>
100847cdc:     	b	0x100847d54 <_js_json_stringify_full+0x14d4>
100847ce0:     	bl	0x1003282d4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json17clear_shape_cache>
100847ce4:     	ldr	w8, [x20]
100847ce8:     	sub	w8, w8, #0x1
100847cec:     	str	w8, [x20]
100847cf0:     	add	x0, sp, #0x50
100847cf4:     	bl	0x1001672fc <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100847cf8:     	cmn	x24, #0x1
100847cfc:     	b.eq	0x100847d3c <_js_json_stringify_full+0x14bc>
100847d00:     	ldp	x19, x20, [sp, #0x28]
100847d04:     	cbz	x20, 0x100847d30 <_js_json_stringify_full+0x14b0>
100847d08:     	add	x21, x19, #0x8
100847d0c:     	b	0x100847d1c <_js_json_stringify_full+0x149c>
100847d10:     	add	x21, x21, #0x18
100847d14:     	subs	x20, x20, #0x1
100847d18:     	b.eq	0x100847d30 <_js_json_stringify_full+0x14b0>
100847d1c:     	ldur	x8, [x21, #-0x8]
100847d20:     	cbz	x8, 0x100847d10 <_js_json_stringify_full+0x1490>
100847d24:     	ldr	x0, [x21]
100847d28:     	bl	0x100b5fe00 <_mi_free>
100847d2c:     	b	0x100847d10 <_js_json_stringify_full+0x1490>
100847d30:     	cbz	x24, 0x100847d3c <_js_json_stringify_full+0x14bc>
100847d34:     	mov	x0, x19
100847d38:     	bl	0x100b5fe00 <_mi_free>
100847d3c:     	ldr	x8, [sp]
100847d40:     	cbz	x8, 0x100847d4c <_js_json_stringify_full+0x14cc>
100847d44:     	ldr	x0, [sp, #0x8]
100847d48:     	bl	0x100b5fe00 <_mi_free>
100847d4c:     	mov	x21, #0x1               ; =1
100847d50:     	movk	x21, #0x7ffc, lsl #48
100847d54:     	mov	x0, x21
100847d58:     	ldp	x29, x30, [sp, #0x100]
100847d5c:     	ldp	x20, x19, [sp, #0xf0]
100847d60:     	ldp	x22, x21, [sp, #0xe0]
100847d64:     	ldp	x24, x23, [sp, #0xd0]
100847d68:     	ldp	x26, x25, [sp, #0xc0]
100847d6c:     	ldp	x28, x27, [sp, #0xb0]
100847d70:     	ldp	d9, d8, [sp, #0xa0]
100847d74:     	add	sp, sp, #0x110
100847d78:     	ret
100847d7c:     	mov	x26, x21
100847d80:     	mov	x21, x28
100847d84:     	mov	x28, x0
100847d88:     	add	x0, x0, #0x8
100847d8c:     	bl	0x100b3cb90 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs2EcWOpJ680c_13perry_runtime>
100847d90:     	mov	x0, x28
100847d94:     	mov	x28, x21
100847d98:     	mov	x21, x26
100847d9c:     	mov	x26, #0x1               ; =1
100847da0:     	movk	x26, #0x7ffc, lsl #48
100847da4:     	b	0x10084759c <_js_json_stringify_full+0xd1c>
100847da8:     	b.ne	0x1008472e0 <_js_json_stringify_full+0xa60>
100847dac:     	tbz	x24, #0x3f, 0x100847e04 <_js_json_stringify_full+0x1584>
100847db0:     	mov	x0, #0x0                ; =0
100847db4:     	mov	x1, x24
100847db8:     	bl	0x100b13200 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847dbc:     	bl	0x100b4023c <__RNvNtCs2EcWOpJ680c_13perry_runtime7tls_hot12hot_uncached>
100847dc0:     	add	x8, x0, x22, lsl #3
100847dc4:     	ldr	x0, [x8, #0x1e8]
100847dc8:     	cbnz	x0, 0x100847630 <_js_json_stringify_full+0xdb0>
100847dcc:     	adrp	x0, 0x100f10000 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100847dd0:     	add	x0, x0, #0x138
100847dd4:     	bl	0x100b3da5c <__RNvMs5_NtCs2EcWOpJ680c_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100847dd8:     	b	0x100847630 <_js_json_stringify_full+0xdb0>
100847ddc:     	add	x1, sp, #0x38
100847de0:     	mov.16b	v0, v8
100847de4:     	mov	w0, #0x0                ; =0
100847de8:     	bl	0x10050992c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify15stringify_value>
100847dec:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847df0:     	add	x0, x0, #0xdc0
100847df4:     	ldr	x8, [x0]
100847df8:     	blr	x8
100847dfc:     	strb	wzr, [x0]
100847e00:     	b	0x100847774 <_js_json_stringify_full+0xef4>
100847e04:     	mov	x0, x24
100847e08:     	mov	w1, #0x1                ; =1
100847e0c:     	bl	0x100b60088 <_mi_malloc_aligned>
100847e10:     	mov	x25, x0
100847e14:     	mov	w0, #0x1                ; =1
100847e18:     	cbz	x25, 0x100847db4 <_js_json_stringify_full+0x1534>
100847e1c:     	mov	x0, x25
100847e20:     	mov	x1, x22
100847e24:     	mov	x2, x24
100847e28:     	bl	0x100b62cac <_writev+0x100b62cac>
100847e2c:     	mov	x21, x24
100847e30:     	b	0x100847304 <_js_json_stringify_full+0xa84>
100847e34:     	cmp	w11, #0x8
100847e38:     	b.eq	0x100847f04 <_js_json_stringify_full+0x1684>
100847e3c:     	cmp	w11, #0x9
100847e40:     	b.eq	0x100847f14 <_js_json_stringify_full+0x1694>
100847e44:     	cmp	w11, #0xa
100847e48:     	b.ne	0x100847e90 <_js_json_stringify_full+0x1610>
100847e4c:     	mov	w10, #0x6e              ; =110
100847e50:     	b	0x100847f18 <_js_json_stringify_full+0x1698>
100847e54:     	mov	x22, x0
100847e58:     	and	x0, x19, #0xffffffffffff
100847e5c:     	bl	0x100348000 <__RNvNtCs2EcWOpJ680c_13perry_runtime6object17object_keys_array>
100847e60:     	cbz	x0, 0x100847f3c <_js_json_stringify_full+0x16bc>
100847e64:     	ldr	w21, [x0]
100847e68:     	cmp	w21, #0x4
100847e6c:     	b.hi	0x100846e68 <_js_json_stringify_full+0x5e8>
100847e70:     	ldr	w8, [x0, #0x4]
100847e74:     	cmp	w21, w8
100847e78:     	b.hi	0x100846e68 <_js_json_stringify_full+0x5e8>
100847e7c:     	b	0x100847f40 <_js_json_stringify_full+0x16c0>
100847e80:     	cmp	w11, #0x22
100847e84:     	b.eq	0x100847f18 <_js_json_stringify_full+0x1698>
100847e88:     	cmp	w11, #0x5c
100847e8c:     	b.eq	0x100847f18 <_js_json_stringify_full+0x1698>
100847e90:     	cmp	x12, #0x3
100847e94:     	mov	w11, #0x20              ; =32
100847e98:     	ccmp	w10, w11, #0x8, ls
100847e9c:     	b.lt	0x100846da4 <_js_json_stringify_full+0x524>
100847ea0:     	add	x8, sp, #0x70
100847ea4:     	strb	w10, [x8, x12]
100847ea8:     	add	x12, x12, #0x1
100847eac:     	b	0x100846a94 <_js_json_stringify_full+0x214>
100847eb0:     	mov	x1, x0
100847eb4:     	and	x0, x19, #0xffffffffffff
100847eb8:     	mov	x22, x1
100847ebc:     	bl	0x1004f91c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json23stringify_record_output20emit_repeated_output>
100847ec0:     	cmp	x0, #0x1
100847ec4:     	b.ne	0x100847fe8 <_js_json_stringify_full+0x1768>
100847ec8:     	mov	x21, x1
100847ecc:     	b	0x100847d54 <_js_json_stringify_full+0x14d4>
100847ed0:     	ldrb	w9, [x8, #0x118]
100847ed4:     	cbz	w9, 0x100848110 <_js_json_stringify_full+0x1890>
100847ed8:     	ldr	x9, [x8, #0x110]
100847edc:     	cmp	x9, x1
100847ee0:     	b.ne	0x100848110 <_js_json_stringify_full+0x1890>
100847ee4:     	ldr	x9, [x8, #0xf0]
100847ee8:     	cmp	x9, x22
100847eec:     	b.hi	0x100848110 <_js_json_stringify_full+0x1890>
100847ef0:     	ldr	x9, [x8, #0xf8]
100847ef4:     	cmp	x9, x22
100847ef8:     	b.ls	0x100848110 <_js_json_stringify_full+0x1890>
100847efc:     	add	x9, x8, #0xf0
100847f00:     	b	0x10084831c <_js_json_stringify_full+0x1a9c>
100847f04:     	mov	w10, #0x62              ; =98
100847f08:     	b	0x100847f18 <_js_json_stringify_full+0x1698>
100847f0c:     	mov	w10, #0x66              ; =102
100847f10:     	b	0x100847f18 <_js_json_stringify_full+0x1698>
100847f14:     	mov	w10, #0x74              ; =116
100847f18:     	cmp	x12, #0x2
100847f1c:     	b.hi	0x100846da4 <_js_json_stringify_full+0x524>
100847f20:     	add	x8, sp, #0x70
100847f24:     	add	x8, x8, x12
100847f28:     	add	x12, x12, #0x2
100847f2c:     	mov	w11, #0x5c              ; =92
100847f30:     	strb	w11, [x8]
100847f34:     	strb	w10, [x8, #0x1]
100847f38:     	b	0x100846a94 <_js_json_stringify_full+0x214>
100847f3c:     	mov	x21, #0x0               ; =0
100847f40:     	ldr	w8, [x22, #0x4]
100847f44:     	lsl	x9, x21, #3
100847f48:     	add	x9, x9, #0x18
100847f4c:     	cmp	x9, x8
100847f50:     	b.hi	0x100846e68 <_js_json_stringify_full+0x5e8>
100847f54:     	ldr	w8, [x24, #0x4]
100847f58:     	mov	w9, #-0x40000000        ; =-1073741824
100847f5c:     	cmp	w8, w9
100847f60:     	csel	w8, w8, wzr, lt
100847f64:     	mov	x22, x0
100847f68:     	mov	x0, x8
100847f6c:     	bl	0x1005e5b64 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100847f70:     	mov	w9, #0x2                ; =2
100847f74:     	cmp	w1, #0x2
100847f78:     	csel	w10, w1, w9, hi
100847f7c:     	tst	w0, #0x1
100847f80:     	csel	x8, x10, x9, ne
100847f84:     	cmp	x21, x8
100847f88:     	b.hi	0x100846e68 <_js_json_stringify_full+0x5e8>
100847f8c:     	cbz	x21, 0x10084834c <_js_json_stringify_full+0x1acc>
100847f90:     	mov	x0, x22
100847f94:     	mov	x1, x21
100847f98:     	bl	0x1004f0180 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100847f9c:     	tbz	w0, #0x0, 0x100846e68 <_js_json_stringify_full+0x5e8>
100847fa0:     	cmp	x21, #0x1
100847fa4:     	b.eq	0x1008483e8 <_js_json_stringify_full+0x1b68>
100847fa8:     	cmp	x21, #0x2
100847fac:     	b.ne	0x1008484a0 <_js_json_stringify_full+0x1c20>
100847fb0:     	mov	x22, #0x0               ; =0
100847fb4:     	add	x24, x24, #0x10
100847fb8:     	mov	w8, #0x1                ; =1
100847fbc:     	mov	x25, x8
100847fc0:     	ldr	x1, [x24, x22, lsl #3]
100847fc4:     	add	x0, sp, #0x70
100847fc8:     	bl	0x1004f01d4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
100847fcc:     	ldr	w8, [sp, #0x70]
100847fd0:     	cmn	w8, #0x1
100847fd4:     	b.ne	0x100848488 <_js_json_stringify_full+0x1c08>
100847fd8:     	mov	w8, #0x0                ; =0
100847fdc:     	mov	w22, #0x1               ; =1
100847fe0:     	tbnz	w25, #0x0, 0x100847fbc <_js_json_stringify_full+0x173c>
100847fe4:     	b	0x1008484a0 <_js_json_stringify_full+0x1c20>
100847fe8:     	and	x0, x19, #0xffffffffffff
100847fec:     	bl	0x100348000 <__RNvNtCs2EcWOpJ680c_13perry_runtime6object17object_keys_array>
100847ff0:     	cbz	x0, 0x10084807c <_js_json_stringify_full+0x17fc>
100847ff4:     	ldr	w21, [x0]
100847ff8:     	cbz	w21, 0x10084807c <_js_json_stringify_full+0x17fc>
100847ffc:     	cmp	w21, #0x8
100848000:     	b.hi	0x100846e34 <_js_json_stringify_full+0x5b4>
100848004:     	ldr	w8, [x0, #0x4]
100848008:     	cmp	w21, w8
10084800c:     	b.hi	0x100846e34 <_js_json_stringify_full+0x5b4>
100848010:     	ldr	w8, [x22, #0x4]
100848014:     	lsl	x9, x21, #3
100848018:     	add	x9, x9, #0x18
10084801c:     	cmp	x9, x8
100848020:     	b.hi	0x100846e34 <_js_json_stringify_full+0x5b4>
100848024:     	ldr	w8, [x24, #0x4]
100848028:     	mov	w9, #-0x40000000        ; =-1073741824
10084802c:     	cmp	w8, w9
100848030:     	csel	w8, w8, wzr, lt
100848034:     	mov	x22, x0
100848038:     	mov	x0, x8
10084803c:     	bl	0x1005e5b64 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100848040:     	mov	w9, #0x2                ; =2
100848044:     	cmp	w1, #0x2
100848048:     	csel	w10, w1, w9, hi
10084804c:     	tst	w0, #0x1
100848050:     	csel	w8, w10, w9, ne
100848054:     	cmp	w21, w8
100848058:     	b.hi	0x100846e34 <_js_json_stringify_full+0x5b4>
10084805c:     	mov	x0, x22
100848060:     	mov	x1, x21
100848064:     	bl	0x1004f0180 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100848068:     	cbz	w0, 0x100846e34 <_js_json_stringify_full+0x5b4>
10084806c:     	and	x0, x19, #0xffffffffffff
100848070:     	mov	x1, x21
100848074:     	bl	0x1004f8300 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json23stringify_record_output11emit_record>
100848078:     	b	0x100848084 <_js_json_stringify_full+0x1804>
10084807c:     	and	x0, x19, #0xffffffffffff
100848080:     	bl	0x1004f9080 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json23stringify_record_output17emit_empty_object>
100848084:     	mov	x21, x1
100848088:     	tbz	w0, #0x0, 0x100846e34 <_js_json_stringify_full+0x5b4>
10084808c:     	b	0x100847d54 <_js_json_stringify_full+0x14d4>
100848090:     	add	x9, x8, #0x60
100848094:     	b	0x10084831c <_js_json_stringify_full+0x1a9c>
100848098:     	bl	0x100b4023c <__RNvNtCs2EcWOpJ680c_13perry_runtime7tls_hot12hot_uncached>
10084809c:     	lsr	x1, x22, #20
1008480a0:     	ldr	x8, [x0, #0x10]
1008480a4:     	ldrb	w9, [x8]
1008480a8:     	cmp	w9, #0x2
1008480ac:     	b.eq	0x10084740c <_js_json_stringify_full+0xb8c>
1008480b0:     	ldr	x9, [x8, #0x8]
1008480b4:     	ldr	x10, [x8, #0x28]
1008480b8:     	sub	x9, x1, x9
1008480bc:     	cmp	x9, x10
1008480c0:     	b.hs	0x100848104 <_js_json_stringify_full+0x1884>
1008480c4:     	ldr	x10, [x8, #0x20]
1008480c8:     	mov	w11, #0x28              ; =40
1008480cc:     	madd	x9, x9, x11, x10
1008480d0:     	ldr	x10, [x9]
1008480d4:     	ldr	x11, [x8, #0x10]
1008480d8:     	cmp	x10, x11
1008480dc:     	b.ne	0x100848110 <_js_json_stringify_full+0x1890>
1008480e0:     	ldp	x10, x11, [x9, #0x8]
1008480e4:     	cmp	x10, x22
1008480e8:     	ccmp	x11, x22, #0x0, ls
1008480ec:     	b.ls	0x100848110 <_js_json_stringify_full+0x1890>
1008480f0:     	ldr	x10, [x8, #0x30]
1008480f4:     	add	x10, x10, #0x1
1008480f8:     	str	x10, [x8, #0x30]
1008480fc:     	add	x8, x9, #0x21
100848100:     	b	0x10084832c <_js_json_stringify_full+0x1aac>
100848104:     	ldr	x9, [x8, #0x58]
100848108:     	add	x9, x9, #0x1
10084810c:     	str	x9, [x8, #0x58]
100848110:     	ldr	x9, [x8, #0x38]
100848114:     	add	x9, x9, #0x1
100848118:     	str	x9, [x8, #0x38]
10084811c:     	mov	x0, x22
100848120:     	bl	0x10051e708 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100848124:     	and	w8, w0, #0xff
100848128:     	cbz	w8, 0x100848148 <_js_json_stringify_full+0x18c8>
10084812c:     	ldurb	w8, [x22, #-0x8]
100848130:     	ldurb	w9, [x22, #-0x7]
100848134:     	mov	w10, #0x82              ; =130
100848138:     	and	w9, w9, w10
10084813c:     	cmp	w9, #0x2
100848140:     	ccmp	w8, #0x1, #0x0, eq
100848144:     	b.eq	0x1008481dc <_js_json_stringify_full+0x195c>
100848148:     	mov	x0, x22
10084814c:     	bl	0x10057ae80 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100848150:     	mov	x23, x0
100848154:     	cbz	x0, 0x100848180 <_js_json_stringify_full+0x1900>
100848158:     	ldrb	w8, [x23]
10084815c:     	cmp	w8, #0x1
100848160:     	b.ne	0x1008481a0 <_js_json_stringify_full+0x1920>
100848164:     	ldrsb	w8, [x23, #0x1]
100848168:     	tbnz	w8, #0x1f, 0x100848204 <_js_json_stringify_full+0x1984>
10084816c:     	mov	x0, x23
100848170:     	ldp	w9, w8, [x22]
100848174:     	cmp	w9, w8
100848178:     	b.hi	0x100848288 <_js_json_stringify_full+0x1a08>
10084817c:     	b	0x1008482a0 <_js_json_stringify_full+0x1a20>
100848180:     	mov	x0, x22
100848184:     	bl	0x1005896b4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6buffer6header20is_registered_buffer>
100848188:     	tbnz	w0, #0x0, 0x100848198 <_js_json_stringify_full+0x1918>
10084818c:     	mov	x0, x22
100848190:     	bl	0x1002a43c8 <__RNvNtCs2EcWOpJ680c_13perry_runtime10typedarray23lookup_typed_array_kind>
100848194:     	tbz	w0, #0x0, 0x1008474ac <_js_json_stringify_full+0xc2c>
100848198:     	mov	x0, #0x0                ; =0
10084819c:     	b	0x100848278 <_js_json_stringify_full+0x19f8>
1008481a0:     	mov	x0, x23
1008481a4:     	cmp	w8, #0x1
1008481a8:     	b.eq	0x100848278 <_js_json_stringify_full+0x19f8>
1008481ac:     	cmp	w8, #0x9
1008481b0:     	b.ne	0x1008474ac <_js_json_stringify_full+0xc2c>
1008481b4:     	ldr	w8, [x22, #0x4]
1008481b8:     	mov	w9, #0x5841             ; =22593
1008481bc:     	movk	w9, #0x4c5a, lsl #16
1008481c0:     	cmp	w8, w9
1008481c4:     	b.ne	0x1008474ac <_js_json_stringify_full+0xc2c>
1008481c8:     	mov	x0, x22
1008481cc:     	bl	0x100375d70 <__RNvNtCs2EcWOpJ680c_13perry_runtime9json_tape22force_materialize_lazy>
1008481d0:     	mov	x22, x0
1008481d4:     	cbnz	x0, 0x1008482c8 <_js_json_stringify_full+0x1a48>
1008481d8:     	b	0x1008474ac <_js_json_stringify_full+0xc2c>
1008481dc:     	ldr	w8, [x22]
1008481e0:     	mov	w9, #0xe100             ; =57600
1008481e4:     	movk	w9, #0x5f5, lsl #16
1008481e8:     	orr	w9, w9, #0x1
1008481ec:     	cmp	w8, w9
1008481f0:     	b.hs	0x100848148 <_js_json_stringify_full+0x18c8>
1008481f4:     	ldr	w9, [x22, #0x4]
1008481f8:     	cmp	w8, w9
1008481fc:     	b.ls	0x1008482c8 <_js_json_stringify_full+0x1a48>
100848200:     	b	0x100848148 <_js_json_stringify_full+0x18c8>
100848204:     	ldr	x22, [x23, #0x8]
100848208:     	mov	x0, x22
10084820c:     	bl	0x10057ae80 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100848210:     	cbz	x0, 0x1008474ac <_js_json_stringify_full+0xc2c>
100848214:     	ldrb	w8, [x0]
100848218:     	cmp	w8, #0x1
10084821c:     	b.ne	0x1008474ac <_js_json_stringify_full+0xc2c>
100848220:     	ldrsb	w8, [x0, #0x1]
100848224:     	tbz	w8, #0x1f, 0x100848170 <_js_json_stringify_full+0x18f0>
100848228:     	mov	w25, #0x1               ; =1
10084822c:     	ldr	x22, [x0, #0x8]
100848230:     	mov	x0, x22
100848234:     	bl	0x10057ae80 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100848238:     	cbz	x0, 0x1008474ac <_js_json_stringify_full+0xc2c>
10084823c:     	ldrb	w8, [x0]
100848240:     	cmp	w8, #0x1
100848244:     	b.ne	0x1008474ac <_js_json_stringify_full+0xc2c>
100848248:     	cmp	w25, #0x3f
10084824c:     	b.hi	0x1008474ac <_js_json_stringify_full+0xc2c>
100848250:     	add	w25, w25, #0x1
100848254:     	ldrsb	w8, [x0, #0x1]
100848258:     	tbnz	w8, #0x1f, 0x10084822c <_js_json_stringify_full+0x19ac>
10084825c:     	str	x22, [x23, #0x8]
100848260:     	ldrb	w8, [x23, #0x1]
100848264:     	orr	w8, w8, #0x80
100848268:     	strb	w8, [x23, #0x1]
10084826c:     	ldrb	w8, [x0]
100848270:     	cmp	w8, #0x1
100848274:     	b.ne	0x1008481ac <_js_json_stringify_full+0x192c>
100848278:     	ldp	w9, w8, [x22]
10084827c:     	cmp	w9, w8
100848280:     	b.ls	0x1008482a0 <_js_json_stringify_full+0x1a20>
100848284:     	cbz	x23, 0x1008482b0 <_js_json_stringify_full+0x1a30>
100848288:     	ldr	w9, [x0, #0x4]
10084828c:     	ubfiz	x8, x8, #3, #32
100848290:     	add	x8, x8, #0x10
100848294:     	cmp	x8, x9
100848298:     	b.eq	0x1008482c8 <_js_json_stringify_full+0x1a48>
10084829c:     	b	0x1008482b0 <_js_json_stringify_full+0x1a30>
1008482a0:     	mov	w8, #0xe100             ; =57600
1008482a4:     	movk	w8, #0x5f5, lsl #16
1008482a8:     	cmp	w9, w8
1008482ac:     	b.ls	0x1008482c8 <_js_json_stringify_full+0x1a48>
1008482b0:     	mov	x0, x22
1008482b4:     	bl	0x1005896b4 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6buffer6header20is_registered_buffer>
1008482b8:     	tbnz	w0, #0x0, 0x1008482c8 <_js_json_stringify_full+0x1a48>
1008482bc:     	mov	x0, x22
1008482c0:     	bl	0x1002a43c8 <__RNvNtCs2EcWOpJ680c_13perry_runtime10typedarray23lookup_typed_array_kind>
1008482c4:     	tbz	w0, #0x0, 0x1008474ac <_js_json_stringify_full+0xc2c>
1008482c8:     	ldp	w8, w9, [x22]
1008482cc:     	sub	w10, w9, #0x1
1008482d0:     	mov	w11, #0x270f            ; =9999
1008482d4:     	cmp	w10, w11
1008482d8:     	ccmp	w8, w9, #0x2, lo
1008482dc:     	b.hi	0x1008474ac <_js_json_stringify_full+0xc2c>
1008482e0:     	and	x8, x20, #0xffffffffffff
1008482e4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008482e8:     	cmp	x24, x9
1008482ec:     	csel	x1, x8, x20, eq
1008482f0:     	add	x0, sp, #0x20
1008482f4:     	bl	0x100500038 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json8replacer20extract_string_array>
1008482f8:     	ldr	x24, [sp, #0x20]
1008482fc:     	cmn	x24, #0x1
100848300:     	cset	w23, eq
100848304:     	cmp	x27, #0x1
100848308:     	cset	w8, hi
10084830c:     	tst	w8, w23
100848310:     	b.ne	0x1008474c8 <_js_json_stringify_full+0xc48>
100848314:     	b	0x100847538 <_js_json_stringify_full+0xcb8>
100848318:     	add	x9, x8, #0x90
10084831c:     	ldr	x10, [x8, #0x30]
100848320:     	add	x10, x10, #0x1
100848324:     	str	x10, [x8, #0x30]
100848328:     	add	x8, x9, #0x19
10084832c:     	ldrb	w8, [x8]
100848330:     	cmp	w8, #0xff
100848334:     	b.ne	0x100848128 <_js_json_stringify_full+0x18a8>
100848338:     	b	0x10084811c <_js_json_stringify_full+0x189c>
10084833c:     	mov	x0, x22
100848340:     	bl	0x100b1f404 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs2EcWOpJ680c_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100848344:     	cbnz	x0, 0x100847654 <_js_json_stringify_full+0xdd4>
100848348:     	b	0x1008484d4 <_js_json_stringify_full+0x1c54>
10084834c:     	and	x0, x19, #0xffffffffffff
100848350:     	bl	0x1004f8130 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
100848354:     	mov	w0, w0
100848358:     	mov	x21, #0x7d7b            ; =32123
10084835c:     	movk	x21, #0x200, lsl #32
100848360:     	movk	x21, #0x7ff9, lsl #48
100848364:     	b	0x1008484b8 <_js_json_stringify_full+0x1c38>
100848368:     	mov	x19, x0
10084836c:     	mov	x0, x22
100848370:     	bl	0x100b1f404 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs2EcWOpJ680c_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100848374:     	mov	x22, x0
100848378:     	mov	x0, x19
10084837c:     	cbnz	x22, 0x100847c38 <_js_json_stringify_full+0x13b8>
100848380:     	cbnz	x23, 0x100848464 <_js_json_stringify_full+0x1be4>
100848384:     	b	0x1008484d4 <_js_json_stringify_full+0x1c54>
100848388:     	bl	0x100b1f564 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs2EcWOpJ680c_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
10084838c:     	cbnz	x0, 0x10084757c <_js_json_stringify_full+0xcfc>
100848390:     	b	0x1008484d4 <_js_json_stringify_full+0x1c54>
100848394:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100848398:     	add	x0, x0, #0x408
10084839c:     	bl	0x100b135ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008483a0:     	cmp	w8, #0x1
1008483a4:     	b.ne	0x1008484d4 <_js_json_stringify_full+0x1c54>
1008483a8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs2EcWOpJ680c_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1a_13async_context20AsyncContextSnapshotEEKj1_EEB1a_+0x18>
1008483ac:     	add	x1, x1, #0xe18
1008483b0:     	mov	x19, x0
1008483b4:     	bl	0x100a212dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008483b8:     	mov	x0, x19
1008483bc:     	strb	wzr, [x19, #0x20]
1008483c0:     	ldr	x8, [x19]
1008483c4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1008483c8:     	cmp	x8, x9
1008483cc:     	b.lo	0x10084779c <_js_json_stringify_full+0xf1c>
1008483d0:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008483d4:     	add	x0, x0, #0xea8
1008483d8:     	bl	0x100b135dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1008483dc:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008483e0:     	add	x0, x0, #0xec0
1008483e4:     	bl	0x100b135ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008483e8:     	and	x0, x19, #0xffffffffffff
1008483ec:     	bl	0x1004efd80 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat21emit_one_field_object>
1008483f0:     	mov	x21, x1
1008483f4:     	b	0x1008484b8 <_js_json_stringify_full+0x1c38>
1008483f8:     	mov	x0, x22
1008483fc:     	bl	0x100b1f404 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs2EcWOpJ680c_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100848400:     	mov	x22, x0
100848404:     	cbnz	x0, 0x100847ae8 <_js_json_stringify_full+0x1268>
100848408:     	b	0x100848460 <_js_json_stringify_full+0x1be0>
10084840c:     	adrp	x0, 0x100ef7000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100848410:     	add	x0, x0, #0xd70
100848414:     	bl	0x100b135dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100848418:     	bl	0x100b4c794 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
10084841c:     	cmp	w8, #0x2
100848420:     	b.eq	0x1008484d4 <_js_json_stringify_full+0x1c54>
100848424:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs2EcWOpJ680c_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1a_13async_context20AsyncContextSnapshotEEKj1_EEB1a_+0x18>
100848428:     	add	x1, x1, #0xe18
10084842c:     	mov	x19, x0
100848430:     	bl	0x100a212dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100848434:     	mov	x0, x19
100848438:     	strb	wzr, [x19, #0x20]
10084843c:     	ldr	x8, [x19]
100848440:     	cbz	x8, 0x100847ad4 <_js_json_stringify_full+0x1254>
100848444:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100848448:     	add	x0, x0, #0xe90
10084844c:     	bl	0x100b135ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100848450:     	mov	x0, x22
100848454:     	bl	0x100b1f404 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs2EcWOpJ680c_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100848458:     	mov	x22, x0
10084845c:     	cbnz	x0, 0x100847a04 <_js_json_stringify_full+0x1184>
100848460:     	cbz	x21, 0x1008484d4 <_js_json_stringify_full+0x1c54>
100848464:     	mov	x0, x19
100848468:     	bl	0x100b5fe00 <_mi_free>
10084846c:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100848470:     	add	x0, x0, #0xc18
100848474:     	bl	0x100b5945c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100848478:     	adrp	x0, 0x100c43000 <_PERRY_EMPTY_STRING+0xc34>
10084847c:     	add	x0, x0, #0x2f0
100848480:     	mov	w1, #0xf                ; =15
100848484:     	bl	0x100b4c75c <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100848488:     	and	x0, x19, #0xffffffffffff
10084848c:     	add	x2, sp, #0x70
100848490:     	mov	x1, x22
100848494:     	bl	0x1004f0580 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
100848498:     	tbnz	w0, #0x0, 0x100847ec8 <_js_json_stringify_full+0x1648>
10084849c:     	mov	w21, #0x2               ; =2
1008484a0:     	and	x0, x19, #0xffffffffffff
1008484a4:     	mov	x1, x21
1008484a8:     	bl	0x1004eec00 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat11emit_object>
1008484ac:     	mov	x21, x1
1008484b0:     	mov	x26, #0x1               ; =1
1008484b4:     	movk	x26, #0x7ffc, lsl #48
1008484b8:     	tbnz	w0, #0x0, 0x100847d54 <_js_json_stringify_full+0x14d4>
1008484bc:     	mov	w21, #0x1               ; =1
1008484c0:     	cmp	x19, x26
1008484c4:     	b.eq	0x100847d4c <_js_json_stringify_full+0x14cc>
1008484c8:     	b	0x100846e74 <_js_json_stringify_full+0x5f4>
1008484cc:     	cmp	w8, #0x2
1008484d0:     	b.ne	0x1008484fc <_js_json_stringify_full+0x1c7c>
1008484d4:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
1008484d8:     	add	x0, x0, #0xc18
1008484dc:     	bl	0x100b5945c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
1008484e0:     	adrp	x0, 0x100f2f000 <__RNvNvNtNtCs2EcWOpJ680c_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x1d8>
1008484e4:     	add	x0, x0, #0x800
1008484e8:     	bl	0x100b13670 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
1008484ec:     	adrp	x0, 0x100c43000 <_PERRY_EMPTY_STRING+0xc34>
1008484f0:     	add	x0, x0, #0x27
1008484f4:     	mov	w1, #0xb                ; =11
1008484f8:     	bl	0x100b4c75c <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
1008484fc:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs2EcWOpJ680c_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1a_13async_context20AsyncContextSnapshotEEKj1_EEB1a_+0x18>
100848500:     	add	x1, x1, #0xe18
100848504:     	mov	x19, x0
100848508:     	bl	0x100a212dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10084850c:     	mov	x0, x19
100848510:     	strb	wzr, [x19, #0x20]
100848514:     	ldr	x8, [x19]
100848518:     	cbz	x8, 0x1008479f0 <_js_json_stringify_full+0x1170>
10084851c:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100848520:     	add	x0, x0, #0xe78
100848524:     	bl	0x100b135ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100848528:     	mov	w0, #0x1                ; =1
10084852c:     	mov	x1, x23
100848530:     	bl	0x100b13200 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100848534:     	mov	w0, #0x1                ; =1
100848538:     	mov	x1, x21
10084853c:     	bl	0x100b13200 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100848540:     	adrp	x2, 0x100ef8000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100848544:     	add	x2, x2, #0x3c8
100848548:     	mov	w0, #0x5                ; =5
10084854c:     	mov	w1, #0x5                ; =5
100848550:     	bl	0x100b1370c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
		...
