
benchmarks/json_performance/.work/invariant-field-loop-r5/worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010084612c <_js_json_stringify>:
10084612c:     	sub	sp, sp, #0x80
100846130:     	stp	d9, d8, [sp, #0x20]
100846134:     	stp	x26, x25, [sp, #0x30]
100846138:     	stp	x24, x23, [sp, #0x40]
10084613c:     	stp	x22, x21, [sp, #0x50]
100846140:     	stp	x20, x19, [sp, #0x60]
100846144:     	stp	x29, x30, [sp, #0x70]
100846148:     	add	x29, sp, #0x70
10084614c:     	mov	x21, x0
100846150:     	mov.16b	v8, v0
100846154:     	fmov	x19, d8
100846158:     	and	x20, x19, #0xffff000000000000
10084615c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846160:     	cmp	x20, x8
100846164:     	b.ne	0x10084618c <_js_json_stringify+0x60>
100846168:     	and	x0, x19, #0xffffffffffff
10084616c:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
100846170:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100846174:     	movk	x9, #0xffef, lsl #16
100846178:     	cmp	x8, x9
10084617c:     	b.hi	0x10084618c <_js_json_stringify+0x60>
100846180:     	ldr	w8, [x0, #0x4]
100846184:     	cmp	w8, #0x40
100846188:     	b.hs	0x1008461fc <_js_json_stringify+0xd0>
10084618c:     	mov.16b	v0, v8
100846190:     	bl	0x1004ee13c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100846194:     	tbz	w0, #0x0, 0x1008461a0 <_js_json_stringify+0x74>
100846198:     	mov	x23, x1
10084619c:     	b	0x100846710 <_js_json_stringify+0x5e4>
1008461a0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008461a4:     	cmp	x20, x8
1008461a8:     	b.ne	0x100846210 <_js_json_stringify+0xe4>
1008461ac:     	ands	x19, x19, #0xffffffffffff
1008461b0:     	b.eq	0x100846210 <_js_json_stringify+0xe4>
1008461b4:     	mov	x0, x19
1008461b8:     	bl	0x10050f4f8 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008461bc:     	cbz	w0, 0x100846210 <_js_json_stringify+0xe4>
1008461c0:     	ldurb	w8, [x19, #-0x8]
1008461c4:     	cmp	w8, #0x9
1008461c8:     	b.ne	0x100846210 <_js_json_stringify+0xe4>
1008461cc:     	ldr	w8, [x19, #0x4]
1008461d0:     	mov	w9, #0x5841             ; =22593
1008461d4:     	movk	w9, #0x4c5a, lsl #16
1008461d8:     	cmp	w8, w9
1008461dc:     	b.ne	0x100846210 <_js_json_stringify+0xe4>
1008461e0:     	mov	x0, x19
1008461e4:     	bl	0x100688f14 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1008461e8:     	cbz	x0, 0x100846210 <_js_json_stringify+0xe4>
1008461ec:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008461f0:     	bfxil	x8, x0, #0, #48
1008461f4:     	fmov	d8, x8
1008461f8:     	b	0x100846210 <_js_json_stringify+0xe4>
1008461fc:     	bl	0x1004f3068 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json16stringify_string17quote_heap_string>
100846200:     	tbnz	w0, #0x0, 0x100846198 <_js_json_stringify+0x6c>
100846204:     	mov.16b	v0, v8
100846208:     	bl	0x1004ee13c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084620c:     	tbnz	w0, #0x0, 0x100846198 <_js_json_stringify+0x6c>
100846210:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846214:     	add	x0, x0, #0xd78
100846218:     	ldr	x8, [x0]
10084621c:     	blr	x8
100846220:     	mov	x19, x0
100846224:     	ldr	w26, [x0]
100846228:     	add	w8, w26, #0x1
10084622c:     	str	w8, [x0]
100846230:     	cbz	w26, 0x1008462a0 <_js_json_stringify+0x174>
100846234:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846238:     	add	x0, x0, #0xd00
10084623c:     	ldr	x8, [x0]
100846240:     	blr	x8
100846244:     	ldrb	w8, [x0, #0x20]
100846248:     	cmp	w8, #0x1
10084624c:     	b.ne	0x100846804 <_js_json_stringify+0x6d8>
100846250:     	ldr	x8, [x0]
100846254:     	cbnz	x8, 0x100846810 <_js_json_stringify+0x6e4>
100846258:     	mov	x8, #-0x1               ; =-1
10084625c:     	str	x8, [x0]
100846260:     	ldr	x20, [x0, #0x18]
100846264:     	ldr	x8, [x0, #0x8]
100846268:     	cmp	x20, x8
10084626c:     	b.eq	0x100846734 <_js_json_stringify+0x608>
100846270:     	ldr	x8, [x0, #0x10]
100846274:     	mov	w9, #0x18               ; =24
100846278:     	madd	x8, x20, x9, x8
10084627c:     	mov	w9, #0x8                ; =8
100846280:     	stp	xzr, x9, [x8]
100846284:     	str	xzr, [x8, #0x10]
100846288:     	add	x8, x20, #0x1
10084628c:     	str	x8, [x0, #0x18]
100846290:     	ldr	x8, [x0]
100846294:     	add	x8, x8, #0x1
100846298:     	str	x8, [x0]
10084629c:     	b	0x10084632c <_js_json_stringify+0x200>
1008462a0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008462a4:     	add	x0, x0, #0xdc0
1008462a8:     	ldr	x8, [x0]
1008462ac:     	blr	x8
1008462b0:     	strb	wzr, [x0]
1008462b4:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008462b8:     	add	x0, x0, #0xdf0
1008462bc:     	ldr	x8, [x0]
1008462c0:     	blr	x8
1008462c4:     	strb	wzr, [x0]
1008462c8:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
1008462cc:     	ldr	w20, [x8, #0x5a8]
1008462d0:     	cmp	w20, #0x300
1008462d4:     	b.hs	0x100846790 <_js_json_stringify+0x664>
1008462d8:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1008462dc:     	ldr	x8, [x8, #0x48]
1008462e0:     	cmn	x8, #0x1
1008462e4:     	b.eq	0x100846780 <_js_json_stringify+0x654>
1008462e8:     	mrs	x9, TPIDRRO_EL0
1008462ec:     	and	x9, x9, #0xfffffffffffffff8
1008462f0:     	ldr	x0, [x9, x8, lsl #3]
1008462f4:     	cbz	x0, 0x100846780 <_js_json_stringify+0x654>
1008462f8:     	add	x8, x0, x20, lsl #3
1008462fc:     	ldr	x0, [x8, #0x1e8]
100846300:     	cbz	x0, 0x100846790 <_js_json_stringify+0x664>
100846304:     	str	xzr, [x0]
100846308:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
10084630c:     	add	x0, x0, #0xd90
100846310:     	ldr	x8, [x0]
100846314:     	blr	x8
100846318:     	ldrb	w8, [x0, #0x20]
10084631c:     	cbnz	w8, 0x10084681c <_js_json_stringify+0x6f0>
100846320:     	ldr	x8, [x0]
100846324:     	cbnz	x8, 0x100846844 <_js_json_stringify+0x718>
100846328:     	str	xzr, [x0, #0x18]
10084632c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846330:     	add	x0, x0, #0xd30
100846334:     	ldr	x8, [x0]
100846338:     	blr	x8
10084633c:     	mov	x20, x0
100846340:     	ldrb	w8, [x0, #0x18]
100846344:     	cmp	w8, #0x1
100846348:     	b.ne	0x1008467a0 <_js_json_stringify+0x674>
10084634c:     	ldr	x8, [x0]
100846350:     	mov	x9, #-0x1               ; =-1
100846354:     	str	x9, [x0]
100846358:     	cmn	x8, #0x2
10084635c:     	b.eq	0x100846850 <_js_json_stringify+0x724>
100846360:     	cmn	x8, #0x1
100846364:     	b.eq	0x100846378 <_js_json_stringify+0x24c>
100846368:     	add	x9, sp, #0x8
10084636c:     	ldur	q0, [x0, #0x8]
100846370:     	stur	q0, [x9, #0x8]
100846374:     	b	0x100846384 <_js_json_stringify+0x258>
100846378:     	mov	x8, #0x0                ; =0
10084637c:     	mov	w9, #0x1                ; =1
100846380:     	stp	x9, xzr, [sp, #0x10]
100846384:     	str	x8, [sp, #0x8]
100846388:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
10084638c:     	add	x0, x0, #0xd18
100846390:     	ldr	x8, [x0]
100846394:     	blr	x8
100846398:     	ldrb	w8, [x0, #0x20]
10084639c:     	cbnz	w8, 0x1008467d0 <_js_json_stringify+0x6a4>
1008463a0:     	ldr	x8, [x0]
1008463a4:     	cbnz	x8, 0x1008467f8 <_js_json_stringify+0x6cc>
1008463a8:     	str	xzr, [x0, #0x18]
1008463ac:     	add	x1, sp, #0x8
1008463b0:     	mov.16b	v0, v8
1008463b4:     	mov	x0, x21
1008463b8:     	bl	0x10050992c <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json9stringify15stringify_value>
1008463bc:     	ldp	x21, x22, [sp, #0x10]
1008463c0:     	cmp	w22, #0x80, lsl #12     ; =0x80000
1008463c4:     	b.hs	0x100846484 <_js_json_stringify+0x358>
1008463c8:     	cmp	x22, #0x40
1008463cc:     	b.hs	0x100846548 <_js_json_stringify+0x41c>
1008463d0:     	ands	x9, x22, #0x38
1008463d4:     	b.eq	0x1008463f8 <_js_json_stringify+0x2cc>
1008463d8:     	and	x8, x22, #0x38
1008463dc:     	neg	x8, x8
1008463e0:     	mov	x10, x21
1008463e4:     	ldr	x11, [x10], #0x8
1008463e8:     	tst	x11, #0x8080808080808080
1008463ec:     	b.ne	0x10084646c <_js_json_stringify+0x340>
1008463f0:     	adds	x8, x8, #0x8
1008463f4:     	b.ne	0x1008463e4 <_js_json_stringify+0x2b8>
1008463f8:     	and	x8, x22, #0x7
1008463fc:     	cbz	x8, 0x1008465cc <_js_json_stringify+0x4a0>
100846400:     	add	x9, x21, x9
100846404:     	ldrsb	w10, [x9]
100846408:     	tbnz	w10, #0x1f, 0x10084646c <_js_json_stringify+0x340>
10084640c:     	cmp	x8, #0x1
100846410:     	b.eq	0x1008465cc <_js_json_stringify+0x4a0>
100846414:     	ldrsb	w10, [x9, #0x1]
100846418:     	tbnz	w10, #0x1f, 0x10084646c <_js_json_stringify+0x340>
10084641c:     	cmp	x8, #0x2
100846420:     	b.eq	0x1008465cc <_js_json_stringify+0x4a0>
100846424:     	ldrsb	w10, [x9, #0x2]
100846428:     	tbnz	w10, #0x1f, 0x10084646c <_js_json_stringify+0x340>
10084642c:     	cmp	x8, #0x3
100846430:     	b.eq	0x1008465cc <_js_json_stringify+0x4a0>
100846434:     	ldrsb	w10, [x9, #0x3]
100846438:     	tbnz	w10, #0x1f, 0x10084646c <_js_json_stringify+0x340>
10084643c:     	cmp	x8, #0x4
100846440:     	b.eq	0x1008465cc <_js_json_stringify+0x4a0>
100846444:     	ldrsb	w10, [x9, #0x4]
100846448:     	tbnz	w10, #0x1f, 0x10084646c <_js_json_stringify+0x340>
10084644c:     	cmp	x8, #0x5
100846450:     	b.eq	0x1008465cc <_js_json_stringify+0x4a0>
100846454:     	ldrsb	w10, [x9, #0x5]
100846458:     	tbnz	w10, #0x1f, 0x10084646c <_js_json_stringify+0x340>
10084645c:     	cmp	x8, #0x6
100846460:     	b.eq	0x1008465cc <_js_json_stringify+0x4a0>
100846464:     	ldrsb	w8, [x9, #0x6]
100846468:     	tbz	w8, #0x1f, 0x1008465cc <_js_json_stringify+0x4a0>
10084646c:     	mov	x0, x21
100846470:     	mov	x1, x22
100846474:     	mov	x2, x22
100846478:     	bl	0x1008ddc40 <_js_string_from_bytes_with_capacity>
10084647c:     	mov	x23, x0
100846480:     	b	0x1008466c8 <_js_json_stringify+0x59c>
100846484:     	and	x8, x22, #0x7fffffffffffffc0
100846488:     	add	x8, x21, x8
10084648c:     	mov	x9, x21
100846490:     	ldp	q0, q1, [x9]
100846494:     	ldp	q2, q3, [x9, #0x20]
100846498:     	orr.16b	v0, v1, v0
10084649c:     	orr.16b	v1, v2, v3
1008464a0:     	orr.16b	v0, v0, v1
1008464a4:     	umaxv.16b	b0, v0
1008464a8:     	fmov	w10, s0
1008464ac:     	tbnz	w10, #0x7, 0x10084650c <_js_json_stringify+0x3e0>
1008464b0:     	add	x9, x9, #0x40
1008464b4:     	cmp	x9, x8
1008464b8:     	b.ne	0x100846490 <_js_json_stringify+0x364>
1008464bc:     	ands	x9, x22, #0x30
1008464c0:     	b.eq	0x1008464e4 <_js_json_stringify+0x3b8>
1008464c4:     	mov	x10, x9
1008464c8:     	mov	x11, x8
1008464cc:     	ldr	q0, [x11], #0x10
1008464d0:     	umaxv.16b	b0, v0
1008464d4:     	fmov	w12, s0
1008464d8:     	tbnz	w12, #0x7, 0x10084650c <_js_json_stringify+0x3e0>
1008464dc:     	subs	x10, x10, #0x10
1008464e0:     	b.ne	0x1008464cc <_js_json_stringify+0x3a0>
1008464e4:     	and	x10, x22, #0xf
1008464e8:     	cbz	x10, 0x100846504 <_js_json_stringify+0x3d8>
1008464ec:     	add	x8, x8, x9
1008464f0:     	ldrsb	w9, [x8]
1008464f4:     	tbnz	w9, #0x1f, 0x10084650c <_js_json_stringify+0x3e0>
1008464f8:     	add	x8, x8, #0x1
1008464fc:     	subs	x10, x10, #0x1
100846500:     	b.ne	0x1008464f0 <_js_json_stringify+0x3c4>
100846504:     	mov	w24, w22
100846508:     	b	0x100846540 <_js_json_stringify+0x414>
10084650c:     	mov	w24, w22
100846510:     	cbz	x24, 0x100846540 <_js_json_stringify+0x414>
100846514:     	mov	x8, x21
100846518:     	ands	x9, x22, #0x3
10084651c:     	b.eq	0x100846538 <_js_json_stringify+0x40c>
100846520:     	mov	x8, x21
100846524:     	ldrsb	w10, [x8]
100846528:     	tbnz	w10, #0x1f, 0x100846630 <_js_json_stringify+0x504>
10084652c:     	add	x8, x8, #0x1
100846530:     	subs	x9, x9, #0x1
100846534:     	b.ne	0x100846524 <_js_json_stringify+0x3f8>
100846538:     	cmp	x24, #0x4
10084653c:     	b.hs	0x1008465fc <_js_json_stringify+0x4d0>
100846540:     	mov	x25, x22
100846544:     	b	0x100846640 <_js_json_stringify+0x514>
100846548:     	and	x8, x22, #0x7fffffffffffffc0
10084654c:     	and	x8, x8, #0xffffffff0007ffff
100846550:     	add	x8, x21, x8
100846554:     	mov	x9, x21
100846558:     	ldp	q0, q1, [x9]
10084655c:     	ldp	q2, q3, [x9, #0x20]
100846560:     	orr.16b	v0, v1, v0
100846564:     	orr.16b	v1, v2, v3
100846568:     	orr.16b	v0, v0, v1
10084656c:     	umaxv.16b	b0, v0
100846570:     	fmov	w10, s0
100846574:     	tbnz	w10, #0x7, 0x10084646c <_js_json_stringify+0x340>
100846578:     	add	x9, x9, #0x40
10084657c:     	cmp	x9, x8
100846580:     	b.ne	0x100846558 <_js_json_stringify+0x42c>
100846584:     	ands	x9, x22, #0x30
100846588:     	b.eq	0x1008465ac <_js_json_stringify+0x480>
10084658c:     	mov	x10, x9
100846590:     	mov	x11, x8
100846594:     	ldr	q0, [x11], #0x10
100846598:     	umaxv.16b	b0, v0
10084659c:     	fmov	w12, s0
1008465a0:     	tbnz	w12, #0x7, 0x10084646c <_js_json_stringify+0x340>
1008465a4:     	subs	x10, x10, #0x10
1008465a8:     	b.ne	0x100846594 <_js_json_stringify+0x468>
1008465ac:     	and	x10, x22, #0xf
1008465b0:     	cbz	x10, 0x1008465cc <_js_json_stringify+0x4a0>
1008465b4:     	add	x8, x8, x9
1008465b8:     	ldrsb	w9, [x8]
1008465bc:     	tbnz	w9, #0x1f, 0x10084646c <_js_json_stringify+0x340>
1008465c0:     	add	x8, x8, #0x1
1008465c4:     	subs	x10, x10, #0x1
1008465c8:     	b.ne	0x1008465b8 <_js_json_stringify+0x48c>
1008465cc:     	mov	x0, x22
1008465d0:     	bl	0x10034b56c <__RNvNtCs2EcWOpJ680c_13perry_runtime6string20string_storage_alloc>
1008465d4:     	mov	x23, x0
1008465d8:     	stp	w22, w22, [x0]
1008465dc:     	stp	wzr, wzr, [x0, #0xc]
1008465e0:     	str	w22, [x0, #0x8]
1008465e4:     	cbz	w22, 0x1008466c8 <_js_json_stringify+0x59c>
1008465e8:     	and	x2, x22, #0x7ffff
1008465ec:     	mov	x0, x1
1008465f0:     	mov	x1, x21
1008465f4:     	bl	0x100b62cac <_writev+0x100b62cac>
1008465f8:     	b	0x1008466c8 <_js_json_stringify+0x59c>
1008465fc:     	add	x9, x21, x24
100846600:     	ldrsb	w10, [x8]
100846604:     	tbnz	w10, #0x1f, 0x100846630 <_js_json_stringify+0x504>
100846608:     	ldrsb	w10, [x8, #0x1]
10084660c:     	tbnz	w10, #0x1f, 0x100846630 <_js_json_stringify+0x504>
100846610:     	ldrsb	w10, [x8, #0x2]
100846614:     	tbnz	w10, #0x1f, 0x100846630 <_js_json_stringify+0x504>
100846618:     	ldrsb	w10, [x8, #0x3]
10084661c:     	tbnz	w10, #0x1f, 0x100846630 <_js_json_stringify+0x504>
100846620:     	add	x8, x8, #0x4
100846624:     	cmp	x8, x9
100846628:     	b.ne	0x100846600 <_js_json_stringify+0x4d4>
10084662c:     	b	0x100846540 <_js_json_stringify+0x414>
100846630:     	mov	w1, w22
100846634:     	mov	x0, x21
100846638:     	bl	0x1005eada0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime6string11utf16_count11count_bytes>
10084663c:     	mov	x25, x0
100846640:     	bl	0x1004f02c0 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100846644:     	add	x0, x24, #0x14
100846648:     	mov	w1, #0x3                ; =3
10084664c:     	bl	0x100458740 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime2gc6malloc9gc_malloc>
100846650:     	mov	x23, x0
100846654:     	stp	w25, w22, [x0]
100846658:     	stp	wzr, wzr, [x0, #0xc]
10084665c:     	str	w22, [x0, #0x8]
100846660:     	add	x0, x0, #0x14
100846664:     	mov	x1, x21
100846668:     	mov	x2, x24
10084666c:     	bl	0x100b62cac <_writev+0x100b62cac>
100846670:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100846674:     	ldr	w21, [x8, #0x590]
100846678:     	cmp	w21, #0x300
10084667c:     	b.hs	0x100846758 <_js_json_stringify+0x62c>
100846680:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100846684:     	ldr	x8, [x8, #0x48]
100846688:     	cmn	x8, #0x1
10084668c:     	b.eq	0x100846748 <_js_json_stringify+0x61c>
100846690:     	mrs	x9, TPIDRRO_EL0
100846694:     	and	x9, x9, #0xfffffffffffffff8
100846698:     	ldr	x0, [x9, x8, lsl #3]
10084669c:     	cbz	x0, 0x100846748 <_js_json_stringify+0x61c>
1008466a0:     	add	x8, x0, x21, lsl #3
1008466a4:     	ldr	x0, [x8, #0x1e8]
1008466a8:     	cbz	x0, 0x100846758 <_js_json_stringify+0x62c>
1008466ac:     	ldr	x8, [x0]
1008466b0:     	adds	x8, x8, x24
1008466b4:     	csinv	x8, x8, xzr, lo
1008466b8:     	str	x8, [x0]
1008466bc:     	lsr	x8, x8, #25
1008466c0:     	cbz	x8, 0x1008466c8 <_js_json_stringify+0x59c>
1008466c4:     	bl	0x10045f674 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1008466c8:     	ldp	x22, x21, [sp, #0x8]
1008466cc:     	ldrb	w8, [x20, #0x18]
1008466d0:     	cmp	w8, #0x1
1008466d4:     	b.ne	0x1008467b0 <_js_json_stringify+0x684>
1008466d8:     	ldp	x8, x0, [x20]
1008466dc:     	stp	x22, x21, [x20]
1008466e0:     	str	xzr, [x20, #0x10]
1008466e4:     	sub	x8, x8, #0x1
1008466e8:     	cmn	x8, #0x2
1008466ec:     	b.hs	0x1008466f4 <_js_json_stringify+0x5c8>
1008466f0:     	bl	0x100b5fe00 <_mi_free>
1008466f4:     	cbz	w26, 0x100846700 <_js_json_stringify+0x5d4>
1008466f8:     	bl	0x1003284a4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json19restore_shape_cache>
1008466fc:     	b	0x100846704 <_js_json_stringify+0x5d8>
100846700:     	bl	0x1003282d4 <__RNvNtCs2EcWOpJ680c_13perry_runtime4json17clear_shape_cache>
100846704:     	ldr	w8, [x19]
100846708:     	sub	w8, w8, #0x1
10084670c:     	str	w8, [x19]
100846710:     	mov	x0, x23
100846714:     	ldp	x29, x30, [sp, #0x70]
100846718:     	ldp	x20, x19, [sp, #0x60]
10084671c:     	ldp	x22, x21, [sp, #0x50]
100846720:     	ldp	x24, x23, [sp, #0x40]
100846724:     	ldp	x26, x25, [sp, #0x30]
100846728:     	ldp	d9, d8, [sp, #0x20]
10084672c:     	add	sp, sp, #0x80
100846730:     	ret
100846734:     	mov	x22, x0
100846738:     	add	x0, x0, #0x8
10084673c:     	bl	0x100b3cb90 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs2EcWOpJ680c_13perry_runtime>
100846740:     	mov	x0, x22
100846744:     	b	0x100846270 <_js_json_stringify+0x144>
100846748:     	bl	0x100b4023c <__RNvNtCs2EcWOpJ680c_13perry_runtime7tls_hot12hot_uncached>
10084674c:     	add	x8, x0, x21, lsl #3
100846750:     	ldr	x0, [x8, #0x1e8]
100846754:     	cbnz	x0, 0x1008466ac <_js_json_stringify+0x580>
100846758:     	adrp	x0, 0x100f10000 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084675c:     	add	x0, x0, #0x78
100846760:     	bl	0x100b3da5c <__RNvMs5_NtCs2EcWOpJ680c_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100846764:     	ldr	x8, [x0]
100846768:     	adds	x8, x8, x24
10084676c:     	csinv	x8, x8, xzr, lo
100846770:     	str	x8, [x0]
100846774:     	lsr	x8, x8, #25
100846778:     	cbnz	x8, 0x1008466c4 <_js_json_stringify+0x598>
10084677c:     	b	0x1008466c8 <_js_json_stringify+0x59c>
100846780:     	bl	0x100b4023c <__RNvNtCs2EcWOpJ680c_13perry_runtime7tls_hot12hot_uncached>
100846784:     	add	x8, x0, x20, lsl #3
100846788:     	ldr	x0, [x8, #0x1e8]
10084678c:     	cbnz	x0, 0x100846304 <_js_json_stringify+0x1d8>
100846790:     	adrp	x0, 0x100f10000 <__RNvNtNtCs2EcWOpJ680c_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846794:     	add	x0, x0, #0x138
100846798:     	bl	0x100b3da5c <__RNvMs5_NtCs2EcWOpJ680c_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084679c:     	b	0x100846304 <_js_json_stringify+0x1d8>
1008467a0:     	mov	x0, x20
1008467a4:     	bl	0x100b1f404 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs2EcWOpJ680c_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008467a8:     	cbnz	x0, 0x10084634c <_js_json_stringify+0x220>
1008467ac:     	b	0x100846850 <_js_json_stringify+0x724>
1008467b0:     	mov	x0, x20
1008467b4:     	bl	0x100b1f404 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs2EcWOpJ680c_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008467b8:     	mov	x20, x0
1008467bc:     	cbnz	x0, 0x1008466d8 <_js_json_stringify+0x5ac>
1008467c0:     	cbz	x22, 0x100846850 <_js_json_stringify+0x724>
1008467c4:     	mov	x0, x21
1008467c8:     	bl	0x100b5fe00 <_mi_free>
1008467cc:     	b	0x100846850 <_js_json_stringify+0x724>
1008467d0:     	cmp	w8, #0x2
1008467d4:     	b.eq	0x100846850 <_js_json_stringify+0x724>
1008467d8:     	adrp	x1, 0x100194000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs2EcWOpJ680c_13perry_runtime15node_submodules4test9MockStateEEEB2j_+0x18>
1008467dc:     	add	x1, x1, #0x478
1008467e0:     	mov	x22, x0
1008467e4:     	bl	0x100a212dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008467e8:     	mov	x0, x22
1008467ec:     	strb	wzr, [x22, #0x20]
1008467f0:     	ldr	x8, [x22]
1008467f4:     	cbz	x8, 0x1008463a8 <_js_json_stringify+0x27c>
1008467f8:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008467fc:     	add	x0, x0, #0xdb8
100846800:     	bl	0x100b135ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100846804:     	bl	0x100b1f564 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs2EcWOpJ680c_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100846808:     	cbnz	x0, 0x100846250 <_js_json_stringify+0x124>
10084680c:     	b	0x100846850 <_js_json_stringify+0x724>
100846810:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100846814:     	add	x0, x0, #0x408
100846818:     	bl	0x100b135ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084681c:     	cmp	w8, #0x1
100846820:     	b.ne	0x100846850 <_js_json_stringify+0x724>
100846824:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs2EcWOpJ680c_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1a_13async_context20AsyncContextSnapshotEEKj1_EEB1a_+0x18>
100846828:     	add	x1, x1, #0xe18
10084682c:     	mov	x20, x0
100846830:     	bl	0x100a212dc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100846834:     	mov	x0, x20
100846838:     	strb	wzr, [x20, #0x20]
10084683c:     	ldr	x8, [x20]
100846840:     	cbz	x8, 0x100846328 <_js_json_stringify+0x1fc>
100846844:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100846848:     	add	x0, x0, #0xd88
10084684c:     	bl	0x100b135ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100846850:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs2EcWOpJ680c_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100846854:     	add	x0, x0, #0xc18
100846858:     	bl	0x100b5945c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
