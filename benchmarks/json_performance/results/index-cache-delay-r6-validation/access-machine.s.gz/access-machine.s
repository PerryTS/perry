
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/index-cache-delay-r6/access-worker.o:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000000000000 <ltmp0>:
       0:      	sub	sp, sp, #0xc0
       4:      	stp	d15, d14, [sp, #0x20]
       8:      	stp	d13, d12, [sp, #0x30]
       c:      	stp	d11, d10, [sp, #0x40]
      10:      	stp	d9, d8, [sp, #0x50]
      14:      	stp	x28, x27, [sp, #0x60]
      18:      	stp	x26, x25, [sp, #0x70]
      1c:      	stp	x24, x23, [sp, #0x80]
      20:      	stp	x22, x21, [sp, #0x90]
      24:      	stp	x20, x19, [sp, #0xa0]
      28:      	stp	x29, x30, [sp, #0xb0]
      2c:      	add	x29, sp, #0xb0
      30:      	fmov	x28, d0
      34:      	fmov	x19, d1
      38:      	adrp	x20, 0x0 <ltmp0>
		0000000000000038:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__1
      3c:      	ldr	x8, [x20]
		000000000000003c:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
      40:      	adrp	x9, 0x0 <ltmp0>
		0000000000000040:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.0.handle
      44:      	ldr	x9, [x9]
		0000000000000044:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.0.handle
      48:      	cmp	x8, x9
      4c:      	b.ne	0x9c <ltmp0+0x9c>
      50:      	mov	x8, x19
      54:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
      58:      	cmp	x8, x9
      5c:      	b.lo	0x12c <ltmp0+0x12c>
      60:      	and	x9, x8, #0xffff000000000000
      64:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
      68:      	cmp	x9, x10
      6c:      	b.hi	0x12c <ltmp0+0x12c>
      70:      	mov	x8, x19
      74:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
      78:      	cmp	x8, x9
      7c:      	b.lo	0x2a8 <ltmp0+0x2a8>
      80:      	and	x9, x8, #0xffff000000000000
      84:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
      88:      	cmp	x9, x10
      8c:      	b.hi	0x2a8 <ltmp0+0x2a8>
      90:      	mov	w21, #0x0               ; =0
      94:      	mov	w25, #0x0               ; =0
      98:      	b	0x2e0 <ltmp0+0x2e0>
      9c:      	mov	w10, #0x7fff            ; =32767
      a0:      	cmp	x10, x8, lsr #48
      a4:      	b.ne	0xf0 <ltmp0+0xf0>
      a8:      	and	x0, x8, #0xffffffffffff
      ac:      	cmp	x0, #0x1, lsl #12       ; =0x1000
      b0:      	b.lo	0xf0 <ltmp0+0xf0>
      b4:      	ldr	w10, [x0, #0x4]
      b8:      	cmp	w10, #0x6
      bc:      	b.ne	0xf0 <ltmp0+0xf0>
      c0:      	ldrb	w10, [x0, #0x14]
      c4:      	cmp	w10, #0x72
      c8:      	b.ne	0xf0 <ltmp0+0xf0>
      cc:      	ldrb	w10, [x0, #0x19]
      d0:      	cmp	w10, #0x74
      d4:      	b.ne	0xf0 <ltmp0+0xf0>
      d8:      	stp	x28, x19, [sp, #0x10]
      dc:      	and	x1, x9, #0xffffffffffff
      e0:      	bl	0xe0 <ltmp0+0xe0>
		00000000000000e0:  ARM64_RELOC_BRANCH26	_js_string_equals
      e4:      	ldp	x28, x19, [sp, #0x10]
      e8:      	cbnz	w0, 0x50 <ltmp0+0x50>
      ec:      	ldr	x8, [x20]
		00000000000000ec:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
      f0:      	adrp	x9, 0x0 <ltmp0>
		00000000000000f0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.2.handle
      f4:      	ldr	x9, [x9]
		00000000000000f4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.2.handle
      f8:      	cmp	x8, x9
      fc:      	b.ne	0x208 <ltmp0+0x208>
     100:      	mov	x8, x19
     104:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
     108:      	cmp	x8, x9
     10c:      	b.lo	0x9f4 <ltmp0+0x9f4>
     110:      	and	x9, x8, #0xffff000000000000
     114:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
     118:      	cmp	x9, x10
     11c:      	b.hi	0x9f4 <ltmp0+0x9f4>
     120:      	mov	w23, #0x0               ; =0
     124:      	mov	w25, #0x0               ; =0
     128:      	b	0xb44 <ltmp0+0xb44>
     12c:      	fmov	d0, x8
     130:      	fcmp	d0, #0.0
     134:      	b.le	0x70 <ltmp0+0x70>
     138:      	adrp	x8, 0x0 <ltmp0>
		0000000000000138:  ARM64_RELOC_PAGE21	lCPI0_0
     13c:      	ldr	d1, [x8]
		000000000000013c:  ARM64_RELOC_PAGEOFF12	lCPI0_0
     140:      	fcmp	d0, d1
     144:      	b.hi	0x70 <ltmp0+0x70>
     148:      	fcvtzs	w20, d0
     14c:      	scvtf	d1, w20
     150:      	fcmp	d0, d1
     154:      	b.ne	0x70 <ltmp0+0x70>
     158:      	mov	x21, #0x0               ; =0
     15c:      	and	x22, x21, #0xffff000000000000
     160:      	mov	x8, x28
     164:      	fmov	d0, x8
     168:      	adrp	x1, 0x0 <ltmp0>
		0000000000000168:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
     16c:      	add	x1, x1, #0x0
		000000000000016c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
     170:      	mov	w0, #0x7                ; =7
     174:      	mov	w2, #0x2                ; =2
     178:      	bl	0x178 <ltmp0+0x178>
		0000000000000178:  ARM64_RELOC_BRANCH26	_js_array_index_own_number
     17c:      	fmov	x8, d0
     180:      	and	x9, x8, #0xffff000000000000
     184:      	mov	x10, #0x7ff9000000000000 ; =9221401712017801216
     188:      	cmp	x8, x10
     18c:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
     190:      	ccmp	x9, x8, #0x2, hs
     194:      	cset	w8, hi
     198:      	mov	x9, #0x1                ; =1
     19c:      	movk	x9, #0x7fff, lsl #48
     1a0:      	cmp	x22, x9
     1a4:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
     1a8:      	ccmp	x21, x9, #0x0, lo
     1ac:      	b.hi	0x70 <ltmp0+0x70>
     1b0:      	cbz	w8, 0x70 <ltmp0+0x70>
     1b4:      	mov	x8, #0x0                ; =0
     1b8:      	fmov	d1, x8
     1bc:      	cmp	w20, #0x1
     1c0:      	csinc	w8, w20, wzr, gt
     1c4:      	fadd	d1, d0, d1
     1c8:      	subs	w8, w8, #0x1
     1cc:      	b.ne	0x1c4 <ltmp0+0x1c4>
     1d0:      	fmov	x24, d1
     1d4:      	fmov	d0, x24
     1d8:      	ldp	x29, x30, [sp, #0xb0]
     1dc:      	ldp	x20, x19, [sp, #0xa0]
     1e0:      	ldp	x22, x21, [sp, #0x90]
     1e4:      	ldp	x24, x23, [sp, #0x80]
     1e8:      	ldp	x26, x25, [sp, #0x70]
     1ec:      	ldp	x28, x27, [sp, #0x60]
     1f0:      	ldp	d9, d8, [sp, #0x50]
     1f4:      	ldp	d11, d10, [sp, #0x40]
     1f8:      	ldp	d13, d12, [sp, #0x30]
     1fc:      	ldp	d15, d14, [sp, #0x20]
     200:      	add	sp, sp, #0xc0
     204:      	ret
     208:      	mov	w10, #0x7fff            ; =32767
     20c:      	cmp	x10, x8, lsr #48
     210:      	b.ne	0x25c <ltmp0+0x25c>
     214:      	and	x0, x8, #0xffffffffffff
     218:      	cmp	x0, #0x1, lsl #12       ; =0x1000
     21c:      	b.lo	0x25c <ltmp0+0x25c>
     220:      	ldr	w10, [x0, #0x4]
     224:      	cmp	w10, #0x6
     228:      	b.ne	0x25c <ltmp0+0x25c>
     22c:      	ldrb	w10, [x0, #0x14]
     230:      	cmp	w10, #0x72
     234:      	b.ne	0x25c <ltmp0+0x25c>
     238:      	ldrb	w10, [x0, #0x19]
     23c:      	cmp	w10, #0x6d
     240:      	b.ne	0x25c <ltmp0+0x25c>
     244:      	stp	x28, x19, [sp, #0x10]
     248:      	and	x1, x9, #0xffffffffffff
     24c:      	bl	0x24c <ltmp0+0x24c>
		000000000000024c:  ARM64_RELOC_BRANCH26	_js_string_equals
     250:      	ldp	x28, x19, [sp, #0x10]
     254:      	cbnz	w0, 0x100 <ltmp0+0x100>
     258:      	ldr	x8, [x20]
		0000000000000258:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
     25c:      	adrp	x9, 0x0 <ltmp0>
		000000000000025c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.3.handle
     260:      	ldr	x9, [x9]
		0000000000000260:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.3.handle
     264:      	adrp	x27, 0x0 <ltmp0>
		0000000000000264:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
     268:      	ldr	x27, [x27]
		0000000000000268:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
     26c:      	adrp	x23, 0x0 <ltmp0>
		000000000000026c:  ARM64_RELOC_PAGE21	lCPI0_1
     270:      	adrp	x11, 0x0 <ltmp0>
		0000000000000270:  ARM64_RELOC_PAGE21	lCPI0_2
     274:      	cmp	x8, x9
     278:      	b.ne	0xa38 <ltmp0+0xa38>
     27c:      	mov	x8, x19
     280:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
     284:      	cmp	x8, x9
     288:      	b.lo	0xabc <ltmp0+0xabc>
     28c:      	and	x9, x8, #0xffff000000000000
     290:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
     294:      	cmp	x9, x10
     298:      	b.hi	0xabc <ltmp0+0xabc>
     29c:      	mov	w21, #0x0               ; =0
     2a0:      	str	wzr, [sp, #0x4]
     2a4:      	b	0x1334 <ltmp0+0x1334>
     2a8:      	fmov	d0, x8
     2ac:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
     2b0:      	fmov	d1, x8
     2b4:      	fcmp	d0, d1
     2b8:      	b.lt	0x90 <ltmp0+0x90>
     2bc:      	fcvtzs	w8, d0
     2c0:      	scvtf	d1, w8
     2c4:      	adrp	x9, 0x0 <ltmp0>
		00000000000002c4:  ARM64_RELOC_PAGE21	lCPI0_0
     2c8:      	ldr	d2, [x9]
		00000000000002c8:  ARM64_RELOC_PAGEOFF12	lCPI0_0
     2cc:      	fcmp	d1, d0
     2d0:      	cset	w9, eq
     2d4:      	fcmp	d0, d2
     2d8:      	csel	w21, wzr, w8, hi
     2dc:      	csel	w25, wzr, w9, hi
     2e0:      	mov	w27, #0x0               ; =0
     2e4:      	mov	x24, #0x0               ; =0
     2e8:      	adrp	x26, 0x0 <ltmp0>
		00000000000002e8:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
     2ec:      	ldr	x26, [x26]
		00000000000002ec:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
     2f0:      	movi.2d	v8, #0000000000000000
     2f4:      	mov	x22, #0x7ffd000000000000 ; =9222527611924643840
     2f8:      	fmov	d9, #7.00000000
     2fc:      	adrp	x8, 0x0 <ltmp0>
		00000000000002fc:  ARM64_RELOC_PAGE21	lCPI0_2
     300:      	ldr	d10, [x8]
		0000000000000300:  ARM64_RELOC_PAGEOFF12	lCPI0_2
     304:      	mov	x20, #0x7ff9000000000000 ; =9221401712017801216
     308:      	adrp	x23, 0x0 <ltmp0>
		0000000000000308:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
     30c:      	ldr	x23, [x23]
		000000000000030c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
     310:      	fmov	d11, #1.00000000
     314:      	tbnz	w25, #0x0, 0x34c <ltmp0+0x34c>
     318:      	mov	x20, x19
     31c:      	ldr	w8, [x23]
     320:      	cbz	w8, 0x338 <ltmp0+0x338>
     324:      	stp	x28, x24, [sp, #0x10]
     328:      	str	x19, [sp, #0x8]
     32c:      	bl	0x32c <ltmp0+0x32c>
		000000000000032c:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
     330:      	ldp	x19, x28, [sp, #0x8]
     334:      	ldr	x24, [sp, #0x18]
     338:      	fmov	d0, x20
     33c:      	fcmp	d8, d0
     340:      	mov	x20, #0x7ff9000000000000 ; =9221401712017801216
     344:      	b.pl	0x1d4 <ltmp0+0x1d4>
     348:      	b	0x354 <ltmp0+0x354>
     34c:      	cmp	w27, w21
     350:      	b.ge	0x1d4 <ltmp0+0x1d4>
     354:      	mov	x0, x24
     358:      	ldr	w8, [x26]
     35c:      	cbz	w8, 0x364 <ltmp0+0x364>
     360:      	bl	0x360 <ltmp0+0x360>
		0000000000000360:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
     364:      	mov	x9, x28
     368:      	and	x8, x9, #0xffffffffffff
     36c:      	and	x11, x9, #0xffff000000000000
     370:      	cmp	x11, x22
     374:      	b.ne	0x3e0 <ltmp0+0x3e0>
     378:      	adrp	x10, 0x0 <ltmp0>
		0000000000000378:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
     37c:      	ldr	x10, [x10]
		000000000000037c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
     380:      	ldr	x10, [x10]
     384:      	sub	x12, x8, #0x100, lsl #12 ; =0x100000
     388:      	cmp	x10, #0x0
     38c:      	mov	x10, #0x7ffffff00000    ; =140737487306752
     390:      	ccmp	x12, x10, #0x2, eq
     394:      	b.hs	0x3e0 <ltmp0+0x3e0>
     398:      	ldurb	w12, [x8, #-0x8]
     39c:      	ldrb	w10, [x8, #0x8]
     3a0:      	cmp	w12, #0xb
     3a4:      	ccmp	w10, #0x9, #0x2, eq
     3a8:      	b.hs	0x3e0 <ltmp0+0x3e0>
     3ac:      	ldr	w12, [x8]
     3b0:      	cmp	w12, #0x8
     3b4:      	b.lo	0x3e0 <ltmp0+0x3e0>
     3b8:      	cmp	w10, #0x3
     3bc:      	b.le	0x508 <ltmp0+0x508>
     3c0:      	cmp	w10, #0x5
     3c4:      	b.gt	0x56c <ltmp0+0x56c>
     3c8:      	cmp	w10, #0x4
     3cc:      	b.eq	0x604 <ltmp0+0x604>
     3d0:      	cmp	w10, #0x5
     3d4:      	b.ne	0x5f8 <ltmp0+0x5f8>
     3d8:      	ldr	s0, [x8, #0x2c]
     3dc:      	b	0x5fc <ltmp0+0x5fc>
     3e0:      	cmp	x11, x22
     3e4:      	b.ne	0x714 <ltmp0+0x714>
     3e8:      	mov	x10, #-0x20000000000    ; =-2199023255552
     3ec:      	add	x10, x8, x10
     3f0:      	lsr	x10, x10, #41
     3f4:      	cmp	x10, #0x3f
     3f8:      	b.hs	0x714 <ltmp0+0x714>
     3fc:      	ldursb	w10, [x8, #-0x7]
     400:      	tbnz	w10, #0x1f, 0x714 <ltmp0+0x714>
     404:      	ldurb	w10, [x8, #-0x8]
     408:      	cmp	w10, #0x9
     40c:      	b.eq	0x4bc <ltmp0+0x4bc>
     410:      	cmp	w10, #0x2
     414:      	b.eq	0x470 <ltmp0+0x470>
     418:      	cmp	w10, #0x1
     41c:      	b.ne	0x714 <ltmp0+0x714>
     420:      	ldr	w9, [x8]
     424:      	mov	x10, x8
     428:      	ldurh	w12, [x8, #-0x6]
     42c:      	adrp	x11, 0x0 <ltmp0>
		000000000000042c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
     430:      	ldr	x11, [x11]
		0000000000000430:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
     434:      	ldrb	w11, [x11]
     438:      	tbnz	w12, #0xa, 0x714 <ltmp0+0x714>
     43c:      	cbnz	w11, 0x714 <ltmp0+0x714>
     440:      	cmp	w9, #0x8
     444:      	b.lo	0x714 <ltmp0+0x714>
     448:      	ldr	w8, [x8, #0x4]
     44c:      	cmp	w9, w8
     450:      	b.hi	0x714 <ltmp0+0x714>
     454:      	ldr	d0, [x10, #0x40]
     458:      	fmov	x8, d0
     45c:      	mov	x9, #0x10               ; =16
     460:      	movk	x9, #0x7ffc, lsl #48
     464:      	cmp	x8, x9
     468:      	fcsel	d0, d10, d0, eq
     46c:      	b	0x73c <ltmp0+0x73c>
     470:      	ldr	x9, [x8, #0x8]
     474:      	cbz	x9, 0x524 <ltmp0+0x524>
     478:      	ldr	x10, [x9, #0x60]
     47c:      	cbz	x10, 0x524 <ltmp0+0x524>
     480:      	ldurb	w8, [x10, #-0x8]
     484:      	cmp	w8, #0x1
     488:      	b.ne	0x714 <ltmp0+0x714>
     48c:      	ldursb	w8, [x10, #-0x7]
     490:      	tbnz	w8, #0x1f, 0x714 <ltmp0+0x714>
     494:      	ldr	w8, [x10]
     498:      	cmp	w8, #0x8
     49c:      	b.lo	0x714 <ltmp0+0x714>
     4a0:      	ldr	d0, [x10, #0x40]
     4a4:      	fmov	x8, d0
     4a8:      	mov	x9, #0x10               ; =16
     4ac:      	movk	x9, #0x7ffc, lsl #48
     4b0:      	cmp	x8, x9
     4b4:      	b.eq	0x714 <ltmp0+0x714>
     4b8:      	b	0x73c <ltmp0+0x73c>
     4bc:      	ldr	w11, [x8, #0x4]
     4c0:      	ldr	x10, [x8, #0x20]
     4c4:      	ldurh	w12, [x8, #-0x6]
     4c8:      	tst	w12, #0xc00
     4cc:      	mov	w12, #0x5841            ; =22593
     4d0:      	movk	w12, #0x4c5a, lsl #16
     4d4:      	ccmp	w11, w12, #0x0, eq
     4d8:      	cset	w11, eq
     4dc:      	cbz	x10, 0x584 <ltmp0+0x584>
     4e0:      	tbz	w11, #0x0, 0x584 <ltmp0+0x584>
     4e4:      	ldurb	w9, [x10, #-0x8]
     4e8:      	cmp	w9, #0x1
     4ec:      	b.ne	0x714 <ltmp0+0x714>
     4f0:      	ldursb	w9, [x10, #-0x7]
     4f4:      	tbnz	w9, #0x1f, 0x714 <ltmp0+0x714>
     4f8:      	ldr	w9, [x10]
     4fc:      	str	w9, [x8]
     500:      	mov	x8, x10
     504:      	b	0x428 <ltmp0+0x428>
     508:      	cbz	w10, 0x5f0 <ltmp0+0x5f0>
     50c:      	cmp	w10, #0x2
     510:      	b.eq	0x618 <ltmp0+0x618>
     514:      	cmp	w10, #0x3
     518:      	b.ne	0x5f8 <ltmp0+0x5f8>
     51c:      	ldr	h0, [x8, #0x1e]
     520:      	b	0x5fc <ltmp0+0x5fc>
     524:      	adrp	x10, 0x0 <ltmp0>
		0000000000000524:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__0
     528:      	add	x10, x10, #0x0
		0000000000000528:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__0
     52c:      	ldr	x11, [x10]
     530:      	cmp	x11, #0x0
     534:      	csel	x10, x10, x11, eq
     538:      	ldr	x10, [x10]
     53c:      	cbz	x10, 0x714 <ltmp0+0x714>
     540:      	tbnz	x10, #0x3f, 0x624 <ltmp0+0x624>
     544:      	ldp	w13, w12, [x8]
     548:      	orr	x12, x12, x13, lsl #32
     54c:      	cmp	x12, x10
     550:      	b.ne	0x714 <ltmp0+0x714>
     554:      	ldp	x13, x10, [x11, #0x8]
     558:      	ldp	x12, x11, [x11, #0x18]
     55c:      	cmp	x13, x11
     560:      	b.lo	0x644 <ltmp0+0x644>
     564:      	cbz	x9, 0x714 <ltmp0+0x714>
     568:      	b	0x658 <ltmp0+0x658>
     56c:      	cmp	w10, #0x6
     570:      	b.eq	0x60c <ltmp0+0x60c>
     574:      	cmp	w10, #0x7
     578:      	b.ne	0x5f8 <ltmp0+0x5f8>
     57c:      	ldr	d0, [x8, #0x48]
     580:      	b	0x73c <ltmp0+0x73c>
     584:      	cmp	x10, #0x0
     588:      	ldr	w13, [x8]
     58c:      	ldp	x10, x12, [x8, #0x28]
     590:      	ccmp	w13, #0x7, #0x0, eq
     594:      	ccmp	x10, #0x0, #0x4, hi
     598:      	ccmp	x12, #0x0, #0x4, ne
     59c:      	csel	w11, wzr, w11, eq
     5a0:      	tbz	w11, #0x0, 0x714 <ltmp0+0x714>
     5a4:      	ldrb	w11, [x12]
     5a8:      	tbnz	w11, #0x7, 0x650 <ltmp0+0x650>
     5ac:      	ldr	x8, [x8, #0x50]
     5b0:      	mov	w11, #0x6903            ; =26883
     5b4:      	movk	w11, #0x64, lsl #16
     5b8:      	cmp	x8, x11
     5bc:      	b.eq	0x5c4 <ltmp0+0x5c4>
     5c0:      	cbnz	x8, 0x714 <ltmp0+0x714>
     5c4:      	mov	w11, #0x6903            ; =26883
     5c8:      	movk	w11, #0x64, lsl #16
     5cc:      	cmp	x8, x11
     5d0:      	b.ne	0x6e4 <ltmp0+0x6e4>
     5d4:      	ldr	x8, [x10, #0x38]
     5d8:      	cbz	x8, 0x6e4 <ltmp0+0x6e4>
     5dc:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
     5e0:      	cmp	x8, x9
     5e4:      	csel	x8, xzr, x8, eq
     5e8:      	fmov	d1, x8
     5ec:      	b	0x940 <ltmp0+0x940>
     5f0:      	ldrsb	w8, [x8, #0x17]
     5f4:      	b	0x61c <ltmp0+0x61c>
     5f8:      	ldr	b0, [x8, #0x17]
     5fc:      	ucvtf	d0, d0
     600:      	b	0x73c <ltmp0+0x73c>
     604:      	ldr	w8, [x8, #0x2c]
     608:      	b	0x61c <ltmp0+0x61c>
     60c:      	ldr	s0, [x8, #0x2c]
     610:      	fcvt	d0, s0
     614:      	b	0x73c <ltmp0+0x73c>
     618:      	ldrsh	w8, [x8, #0x1e]
     61c:      	scvtf	d0, w8
     620:      	b	0x73c <ltmp0+0x73c>
     624:      	cbz	x9, 0x714 <ltmp0+0x714>
     628:      	ldr	x12, [x9, #0x30]
     62c:      	cmp	x12, x10
     630:      	b.ne	0x714 <ltmp0+0x714>
     634:      	ldp	x13, x10, [x11, #0x8]
     638:      	ldp	x12, x11, [x11, #0x18]
     63c:      	cmp	x13, x11
     640:      	b.hs	0x658 <ltmp0+0x658>
     644:      	add	x13, x8, x13, lsl #3
     648:      	add	x13, x13, #0x10
     64c:      	b	0x67c <ltmp0+0x67c>
     650:      	ldr	d0, [x10, #0x38]
     654:      	b	0x73c <ltmp0+0x73c>
     658:      	ldr	x15, [x9, #0x20]
     65c:      	cmp	x15, #0x0
     660:      	csel	x14, x15, x9, ne
     664:      	cbz	x15, 0x714 <ltmp0+0x714>
     668:      	ldr	w15, [x14]
     66c:      	cmp	x13, x15
     670:      	b.hs	0x714 <ltmp0+0x714>
     674:      	add	x13, x14, x13, lsl #3
     678:      	add	x13, x13, #0x8
     67c:      	ldr	d0, [x13]
     680:      	fcmp	d0, d9
     684:      	ccmp	x12, #0x7, #0x0, gt
     688:      	cset	w13, hi
     68c:      	add	x12, x10, #0x7
     690:      	cmp	x12, x11
     694:      	b.hs	0x6a8 <ltmp0+0x6a8>
     698:      	cbz	w13, 0x6a8 <ltmp0+0x6a8>
     69c:      	add	x8, x8, x12, lsl #3
     6a0:      	ldr	d0, [x8, #0x10]
     6a4:      	b	0x73c <ltmp0+0x73c>
     6a8:      	cbz	x9, 0x714 <ltmp0+0x714>
     6ac:      	cmp	x12, x11
     6b0:      	b.lo	0x714 <ltmp0+0x714>
     6b4:      	eor	w8, w13, #0x1
     6b8:      	tbnz	w8, #0x0, 0x714 <ltmp0+0x714>
     6bc:      	ldr	x11, [x9, #0x20]
     6c0:      	cmp	x11, #0x0
     6c4:      	csel	x8, x11, x9, ne
     6c8:      	cbz	x11, 0x714 <ltmp0+0x714>
     6cc:      	ldr	w9, [x8]
     6d0:      	cmp	x12, x9
     6d4:      	b.hs	0x714 <ltmp0+0x714>
     6d8:      	add	x8, x8, x10, lsl #3
     6dc:      	ldr	d0, [x8, #0x40]
     6e0:      	b	0x73c <ltmp0+0x73c>
     6e4:      	fmov	d0, x9
     6e8:      	fmov	d1, #7.00000000
     6ec:      	adrp	x0, 0x0 <ltmp0>
		00000000000006ec:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
     6f0:      	add	x0, x0, #0x0
		00000000000006f0:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
     6f4:      	mov	w1, #0x2                ; =2
     6f8:      	bl	0x6f8 <ltmp0+0x6f8>
		00000000000006f8:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
     6fc:      	mov.16b	v1, v0
     700:      	fmov	x8, d1
     704:      	mov	x9, #0x10               ; =16
     708:      	movk	x9, #0x7ffc, lsl #48
     70c:      	cmp	x8, x9
     710:      	b.ne	0x940 <ltmp0+0x940>
     714:      	mov	x8, x28
     718:      	stp	x19, x28, [sp, #0x10]
     71c:      	fmov	d0, x8
     720:      	str	x24, [sp, #0x8]
     724:      	fmov	d1, #7.00000000
     728:      	adrp	x0, 0x0 <ltmp0>
		0000000000000728:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__0
     72c:      	add	x0, x0, #0x0
		000000000000072c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__0
     730:      	bl	0x730 <ltmp0+0x730>
		0000000000000730:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
     734:      	ldp	x24, x19, [sp, #0x8]
     738:      	ldr	x28, [sp, #0x18]
     73c:      	fmov	x8, d0
     740:      	mov	x9, #-0x3000000000000   ; =-844424930131968
     744:      	and	x9, x8, x9
     748:      	cmp	x9, x22
     74c:      	b.ne	0x7c0 <ltmp0+0x7c0>
     750:      	and	x0, x8, #0xffffffffffff
     754:      	lsr	x8, x0, #20
     758:      	cbz	x8, 0x914 <ltmp0+0x914>
     75c:      	ldurb	w9, [x0, #-0x8]
     760:      	adrp	x8, 0x0 <ltmp0>
		0000000000000760:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__2
     764:      	ldr	x8, [x8]
		0000000000000764:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__2
     768:      	cbz	x8, 0x838 <ltmp0+0x838>
     76c:      	ldurh	w10, [x0, #-0x6]
     770:      	and	w10, w10, #0x800
     774:      	cmp	w9, #0x2
     778:      	ccmp	w10, #0x0, #0x0, eq
     77c:      	b.ne	0x838 <ltmp0+0x838>
     780:      	ldr	w10, [x0, #0x4]
     784:      	orr	x9, x10, #0x4000000000000000
     788:      	cbz	w10, 0x864 <ltmp0+0x864>
     78c:      	ldr	x11, [x8]
     790:      	cmp	x9, x11
     794:      	b.ne	0x864 <ltmp0+0x864>
     798:      	ldr	x2, [x8, #0x8]
     79c:      	tbnz	w2, #0x1e, 0x9d0 <ltmp0+0x9d0>
     7a0:      	add	x11, x0, x2, lsl #3
     7a4:      	ldr	d1, [x11, #0x10]
     7a8:      	fmov	x11, d1
     7ac:      	mov	x12, #0x10              ; =16
     7b0:      	movk	x12, #0x7ffc, lsl #48
     7b4:      	cmp	x11, x12
     7b8:      	b.ne	0x940 <ltmp0+0x940>
     7bc:      	b	0x890 <ltmp0+0x890>
     7c0:      	lsr	x9, x8, #48
     7c4:      	mov	w10, #0x7ff9            ; =32761
     7c8:      	cmp	x9, x10
     7cc:      	b.eq	0x818 <ltmp0+0x818>
     7d0:      	mov	w10, #0x7ffe            ; =32766
     7d4:      	cmp	w9, w10
     7d8:      	b.ne	0x808 <ltmp0+0x808>
     7dc:      	adrp	x9, 0x0 <ltmp0>
		00000000000007dc:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
     7e0:      	ldr	x9, [x9]
		00000000000007e0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
     7e4:      	stp	x28, x24, [sp, #0x10]
     7e8:      	str	x19, [sp, #0x8]
     7ec:      	and	x2, x9, #0xffffffffffff
     7f0:      	mov	x0, #0x1                ; =1
     7f4:      	movk	x0, #0xddae, lsl #32
     7f8:      	movk	x0, #0x5556, lsl #48
     7fc:      	mov	x1, x8
     800:      	bl	0x800 <ltmp0+0x800>
		0000000000000800:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
     804:      	b	0x934 <ltmp0+0x934>
     808:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
     80c:      	add	x9, x8, x9
     810:      	cmp	x9, #0x2
     814:      	b.lo	0x3024 <ltmp0+0x3024>
     818:      	adrp	x9, 0x0 <ltmp0>
		0000000000000818:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
     81c:      	ldr	x9, [x9]
		000000000000081c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
     820:      	stp	x28, x24, [sp, #0x10]
     824:      	str	x19, [sp, #0x8]
     828:      	and	x1, x9, #0xffffffffffff
     82c:      	mov	x0, x8
     830:      	bl	0x830 <ltmp0+0x830>
		0000000000000830:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
     834:      	b	0x934 <ltmp0+0x934>
     838:      	cmp	w9, #0x2
     83c:      	ccmp	x8, #0x0, #0x4, eq
     840:      	b.eq	0x914 <ltmp0+0x914>
     844:      	ldr	x9, [x8, #0x10]
     848:      	cbz	x9, 0x914 <ltmp0+0x914>
     84c:      	ldr	x10, [x0, #0x8]
     850:      	cbz	x10, 0x914 <ltmp0+0x914>
     854:      	ldr	x10, [x10, #0x30]
     858:      	cmp	x10, x9
     85c:      	b.eq	0x880 <ltmp0+0x880>
     860:      	b	0x914 <ltmp0+0x914>
     864:      	ldr	x11, [x8, #0x10]
     868:      	cbz	x11, 0x890 <ltmp0+0x890>
     86c:      	ldr	x12, [x0, #0x8]
     870:      	cbz	x12, 0x890 <ltmp0+0x890>
     874:      	ldr	x12, [x12, #0x30]
     878:      	cmp	x12, x11
     87c:      	b.ne	0x890 <ltmp0+0x890>
     880:      	ldr	x8, [x8, #0x8]
     884:      	add	x8, x0, x8, lsl #3
     888:      	ldr	d1, [x8, #0x10]
     88c:      	b	0x940 <ltmp0+0x940>
     890:      	ldr	x11, [x8, #0x18]
     894:      	cmp	x11, #0x0
     898:      	b.le	0x914 <ltmp0+0x914>
     89c:      	ldr	x11, [x8, #0x20]
     8a0:      	ldr	x12, [x8, #0x30]
     8a4:      	ldr	x13, [x8, #0x40]
     8a8:      	cmp	x13, x9
     8ac:      	ldr	x14, [x8, #0x50]
     8b0:      	ccmp	x14, x9, #0x4, ne
     8b4:      	ccmp	x12, x9, #0x4, ne
     8b8:      	ccmp	x11, x9, #0x4, ne
     8bc:      	cset	w15, eq
     8c0:      	cbz	w10, 0x914 <ltmp0+0x914>
     8c4:      	cbz	w15, 0x914 <ltmp0+0x914>
     8c8:      	ldr	x10, [x8, #0x48]
     8cc:      	ldr	x15, [x8, #0x58]
     8d0:      	cmp	x14, x9
     8d4:      	csel	x14, x15, xzr, eq
     8d8:      	cmp	x13, x9
     8dc:      	csel	x10, x10, x14, eq
     8e0:      	ldr	x13, [x8, #0x28]
     8e4:      	ldr	x8, [x8, #0x38]
     8e8:      	cmp	x12, x9
     8ec:      	csel	x8, x8, x10, eq
     8f0:      	cmp	x11, x9
     8f4:      	csel	x8, x13, x8, eq
     8f8:      	add	x8, x0, x8, lsl #3
     8fc:      	ldr	d1, [x8, #0x10]
     900:      	fmov	x8, d1
     904:      	mov	x9, #0x10               ; =16
     908:      	movk	x9, #0x7ffc, lsl #48
     90c:      	cmp	x8, x9
     910:      	b.ne	0x940 <ltmp0+0x940>
     914:      	adrp	x8, 0x0 <ltmp0>
		0000000000000914:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
     918:      	ldr	x8, [x8]
		0000000000000918:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
     91c:      	stp	x28, x24, [sp, #0x10]
     920:      	str	x19, [sp, #0x8]
     924:      	and	x1, x8, #0xffffffffffff
     928:      	adrp	x2, 0x0 <ltmp0>
		0000000000000928:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__2
     92c:      	add	x2, x2, #0x0
		000000000000092c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__2
     930:      	bl	0x930 <ltmp0+0x930>
		0000000000000930:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
     934:      	mov.16b	v1, v0
     938:      	ldp	x19, x28, [sp, #0x8]
     93c:      	ldr	x24, [sp, #0x18]
     940:      	fmov	d0, x24
     944:      	and	x9, x24, #0xffff000000000000
     948:      	fmov	x8, d1
     94c:      	and	x10, x8, #0xffff000000000000
     950:      	cmp	x8, x20
     954:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
     958:      	ccmp	x10, x8, #0x2, hs
     95c:      	cset	w8, hi
     960:      	mov	x10, #0x1               ; =1
     964:      	movk	x10, #0x7fff, lsl #48
     968:      	cmp	x9, x10
     96c:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
     970:      	ccmp	x24, x9, #0x0, lo
     974:      	b.hi	0x984 <ltmp0+0x984>
     978:      	tbz	w8, #0x0, 0x984 <ltmp0+0x984>
     97c:      	fadd	d0, d1, d0
     980:      	b	0x990 <ltmp0+0x990>
     984:      	stp	x19, x28, [sp, #0x10]
     988:      	bl	0x988 <ltmp0+0x988>
		0000000000000988:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
     98c:      	ldp	x19, x28, [sp, #0x10]
     990:      	fmov	x24, d0
     994:      	mov	x0, x24
     998:      	ldr	w8, [x26]
     99c:      	cbz	w8, 0x9a4 <ltmp0+0x9a4>
     9a0:      	bl	0x9a0 <ltmp0+0x9a0>
		00000000000009a0:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
     9a4:      	ldr	w8, [x23]
     9a8:      	cbz	w8, 0x9c0 <ltmp0+0x9c0>
     9ac:      	stp	x28, x19, [sp, #0x10]
     9b0:      	str	x24, [sp, #0x8]
     9b4:      	bl	0x9b4 <ltmp0+0x9b4>
		00000000000009b4:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
     9b8:      	ldp	x24, x28, [sp, #0x8]
     9bc:      	ldr	x19, [sp, #0x18]
     9c0:      	fadd	d8, d8, d11
     9c4:      	add	w27, w27, #0x1
     9c8:      	tbz	w25, #0x0, 0x318 <ltmp0+0x318>
     9cc:      	b	0x34c <ltmp0+0x34c>
     9d0:      	adrp	x8, 0x0 <ltmp0>
		00000000000009d0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
     9d4:      	ldr	x8, [x8]
		00000000000009d4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
     9d8:      	stp	x28, x24, [sp, #0x10]
     9dc:      	str	x19, [sp, #0x8]
     9e0:      	and	x1, x8, #0xffffffffffff
     9e4:      	adrp	x3, 0x0 <ltmp0>
		00000000000009e4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__2
     9e8:      	add	x3, x3, #0x0
		00000000000009e8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__2
     9ec:      	bl	0x9ec <ltmp0+0x9ec>
		00000000000009ec:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
     9f0:      	b	0x934 <ltmp0+0x934>
     9f4:      	mov	w23, #0x0               ; =0
     9f8:      	fmov	d0, x8
     9fc:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
     a00:      	fmov	d1, x8
     a04:      	fcmp	d0, d1
     a08:      	b.lt	0xb40 <ltmp0+0xb40>
     a0c:      	adrp	x8, 0x0 <ltmp0>
		0000000000000a0c:  ARM64_RELOC_PAGE21	lCPI0_0
     a10:      	ldr	d1, [x8]
		0000000000000a10:  ARM64_RELOC_PAGEOFF12	lCPI0_0
     a14:      	fcmp	d0, d1
     a18:      	mov	x25, x23
     a1c:      	b.hi	0xb44 <ltmp0+0xb44>
     a20:      	fcvtzs	w23, d0
     a24:      	scvtf	d1, w23
     a28:      	fcmp	d1, d0
     a2c:      	b.ne	0x124 <ltmp0+0x124>
     a30:      	mov	w25, #0x1               ; =1
     a34:      	b	0xb44 <ltmp0+0xb44>
     a38:      	mov	w10, #0x7fff            ; =32767
     a3c:      	cmp	x10, x8, lsr #48
     a40:      	b.ne	0xa90 <ltmp0+0xa90>
     a44:      	and	x0, x8, #0xffffffffffff
     a48:      	cmp	x0, #0x1, lsl #12       ; =0x1000
     a4c:      	b.lo	0xa90 <ltmp0+0xa90>
     a50:      	ldr	w8, [x0, #0x4]
     a54:      	cmp	w8, #0x6
     a58:      	b.ne	0xa90 <ltmp0+0xa90>
     a5c:      	ldrb	w8, [x0, #0x14]
     a60:      	cmp	w8, #0x66
     a64:      	b.ne	0xa90 <ltmp0+0xa90>
     a68:      	ldrb	w8, [x0, #0x19]
     a6c:      	cmp	w8, #0x73
     a70:      	b.ne	0xa90 <ltmp0+0xa90>
     a74:      	stp	x28, x19, [sp, #0x10]
     a78:      	and	x1, x9, #0xffffffffffff
     a7c:      	mov	x19, x11
     a80:      	bl	0xa80 <ltmp0+0xa80>
		0000000000000a80:  ARM64_RELOC_BRANCH26	_js_string_equals
     a84:      	mov	x11, x19
     a88:      	ldp	x28, x19, [sp, #0x10]
     a8c:      	cbnz	w0, 0x27c <ltmp0+0x27c>
     a90:      	mov	x8, x19
     a94:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
     a98:      	cmp	x8, x9
     a9c:      	b.lo	0xb00 <ltmp0+0xb00>
     aa0:      	and	x9, x8, #0xffff000000000000
     aa4:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
     aa8:      	cmp	x9, x10
     aac:      	b.hi	0xb00 <ltmp0+0xb00>
     ab0:      	mov	w22, #0x0               ; =0
     ab4:      	mov	w20, #0x0               ; =0
     ab8:      	b	0x28c8 <ltmp0+0x28c8>
     abc:      	mov	w21, #0x0               ; =0
     ac0:      	fmov	d0, x8
     ac4:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
     ac8:      	fmov	d1, x8
     acc:      	fcmp	d0, d1
     ad0:      	b.lt	0x1330 <ltmp0+0x1330>
     ad4:      	adrp	x8, 0x0 <ltmp0>
		0000000000000ad4:  ARM64_RELOC_PAGE21	lCPI0_0
     ad8:      	ldr	d1, [x8]
		0000000000000ad8:  ARM64_RELOC_PAGEOFF12	lCPI0_0
     adc:      	fcmp	d0, d1
     ae0:      	str	w21, [sp, #0x4]
     ae4:      	b.hi	0x1334 <ltmp0+0x1334>
     ae8:      	fcvtzs	w21, d0
     aec:      	frintz	d1, d0
     af0:      	fcmp	d1, d0
     af4:      	cset	w8, eq
     af8:      	str	w8, [sp, #0x4]
     afc:      	b	0x1334 <ltmp0+0x1334>
     b00:      	mov	w22, #0x0               ; =0
     b04:      	fmov	d0, x8
     b08:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
     b0c:      	fmov	d1, x8
     b10:      	fcmp	d0, d1
     b14:      	b.lt	0x28c4 <ltmp0+0x28c4>
     b18:      	adrp	x8, 0x0 <ltmp0>
		0000000000000b18:  ARM64_RELOC_PAGE21	lCPI0_0
     b1c:      	ldr	d1, [x8]
		0000000000000b1c:  ARM64_RELOC_PAGEOFF12	lCPI0_0
     b20:      	fcmp	d0, d1
     b24:      	mov	x20, x22
     b28:      	b.hi	0x28c8 <ltmp0+0x28c8>
     b2c:      	fcvtzs	w22, d0
     b30:      	frintz	d1, d0
     b34:      	fcmp	d1, d0
     b38:      	cset	w20, eq
     b3c:      	b	0x28c8 <ltmp0+0x28c8>
     b40:      	mov	x25, x23
     b44:      	mov	w27, #0x0               ; =0
     b48:      	mov	x24, #0x0               ; =0
     b4c:      	movi.2d	v8, #0000000000000000
     b50:      	mov	x20, #0x7ff9000000000000 ; =9221401712017801216
     b54:      	fmov	d9, #17.00000000
     b58:      	adrp	x22, 0x0 <ltmp0>
		0000000000000b58:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
     b5c:      	adrp	x26, 0x0 <ltmp0>
		0000000000000b5c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
     b60:      	ldr	x26, [x26]
		0000000000000b60:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
     b64:      	mov	x21, #0x7ffd000000000000 ; =9222527611924643840
     b68:      	fmov	d10, #7.00000000
     b6c:      	mov	x8, #0x41f0000000000000 ; =4751297606875873280
     b70:      	fmov	d11, x8
     b74:      	adrp	x8, 0x0 <ltmp0>
		0000000000000b74:  ARM64_RELOC_PAGE21	lCPI0_1
     b78:      	ldr	d12, [x8]
		0000000000000b78:  ARM64_RELOC_PAGEOFF12	lCPI0_1
     b7c:      	adrp	x8, 0x0 <ltmp0>
		0000000000000b7c:  ARM64_RELOC_PAGE21	lCPI0_2
     b80:      	ldr	d13, [x8]
		0000000000000b80:  ARM64_RELOC_PAGEOFF12	lCPI0_2
     b84:      	fmov	d14, #1.00000000
     b88:      	movi.2d	v15, #0000000000000000
     b8c:      	tbnz	w25, #0x0, 0xbdc <ltmp0+0xbdc>
     b90:      	mov	x20, x22
     b94:      	mov	x22, x23
     b98:      	mov	x23, x19
     b9c:      	adrp	x8, 0x0 <ltmp0>
		0000000000000b9c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
     ba0:      	ldr	x8, [x8]
		0000000000000ba0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
     ba4:      	ldr	w8, [x8]
     ba8:      	cbz	w8, 0xbc0 <ltmp0+0xbc0>
     bac:      	stp	x24, x19, [sp, #0x10]
     bb0:      	str	x28, [sp, #0x8]
     bb4:      	bl	0xbb4 <ltmp0+0xbb4>
		0000000000000bb4:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
     bb8:      	ldp	x28, x24, [sp, #0x8]
     bbc:      	ldr	x19, [sp, #0x18]
     bc0:      	fmov	d0, x23
     bc4:      	fcmp	d15, d0
     bc8:      	mov	x23, x22
     bcc:      	mov	x22, x20
     bd0:      	mov	x20, #0x7ff9000000000000 ; =9221401712017801216
     bd4:      	b.pl	0x1d4 <ltmp0+0x1d4>
     bd8:      	b	0xbe4 <ltmp0+0xbe4>
     bdc:      	cmp	w27, w23
     be0:      	b.ge	0x1d4 <ltmp0+0x1d4>
     be4:      	fmov	x8, d8
     be8:      	cmp	x8, x20
     bec:      	b.lo	0xc20 <ltmp0+0xc20>
     bf0:      	and	x8, x8, #0xffff000000000000
     bf4:      	mov	x9, #0x7fff000000000000 ; =9223090561878065152
     bf8:      	cmp	x8, x9
     bfc:      	b.hi	0xc20 <ltmp0+0xc20>
     c00:      	stp	x24, x19, [sp, #0x10]
     c04:      	str	x28, [sp, #0x8]
     c08:      	fmov	d1, #17.00000000
     c0c:      	mov.16b	v0, v8
     c10:      	bl	0xc10 <ltmp0+0xc10>
		0000000000000c10:  ARM64_RELOC_BRANCH26	_js_dynamic_mul
     c14:      	ldp	x28, x24, [sp, #0x8]
     c18:      	ldr	x19, [sp, #0x18]
     c1c:      	b	0xc24 <ltmp0+0xc24>
     c20:      	fmul	d0, d8, d9
     c24:      	fadd	d0, d0, d10
     c28:      	ldr	d1, [x22]
		0000000000000c28:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
     c2c:      	stp	x28, x24, [sp, #0x10]
     c30:      	str	x19, [sp, #0x8]
     c34:      	bl	0xc34 <ltmp0+0xc34>
		0000000000000c34:  ARM64_RELOC_BRANCH26	_js_dynamic_mod
     c38:      	mov.16b	v8, v0
     c3c:      	ldp	x19, x28, [sp, #0x8]
     c40:      	ldr	x24, [sp, #0x18]
     c44:      	fmov	x8, d8
     c48:      	mov	w9, #0x7fff             ; =32767
     c4c:      	cmp	x9, x8, lsr #48
     c50:      	b.ne	0xc5c <ltmp0+0xc5c>
     c54:      	mov.16b	v0, v8
     c58:      	bl	0xc58 <ltmp0+0xc58>
		0000000000000c58:  ARM64_RELOC_BRANCH26	_js_string_addref_if_heap_string
     c5c:      	mov	x0, x24
     c60:      	ldr	w8, [x26]
     c64:      	cbz	w8, 0xc6c <ltmp0+0xc6c>
     c68:      	bl	0xc68 <ltmp0+0xc68>
		0000000000000c68:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
     c6c:      	mov	x10, x28
     c70:      	and	x8, x10, #0xffffffffffff
     c74:      	and	x12, x10, #0xffff000000000000
     c78:      	cmp	x12, x21
     c7c:      	b.ne	0xcd8 <ltmp0+0xcd8>
     c80:      	adrp	x9, 0x0 <ltmp0>
		0000000000000c80:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
     c84:      	ldr	x9, [x9]
		0000000000000c84:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
     c88:      	ldr	x9, [x9]
     c8c:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
     c90:      	cmp	x9, #0x0
     c94:      	mov	x9, #0x7ffffff00000     ; =140737487306752
     c98:      	ccmp	x11, x9, #0x2, eq
     c9c:      	b.hs	0xcd8 <ltmp0+0xcd8>
     ca0:      	fcmp	d8, d11
     ca4:      	b.pl	0xcd8 <ltmp0+0xcd8>
     ca8:      	ldurb	w9, [x8, #-0x8]
     cac:      	ldrb	w11, [x8, #0x8]
     cb0:      	fcmp	d8, #0.0
     cb4:      	ccmp	w9, #0xb, #0x0, ge
     cb8:      	ccmp	w11, #0x9, #0x2, eq
     cbc:      	b.hs	0xcd8 <ltmp0+0xcd8>
     cc0:      	fcvtzs	x9, d8
     cc4:      	scvtf	d0, x9
     cc8:      	ldr	w13, [x8]
     ccc:      	fcmp	d8, d0
     cd0:      	ccmp	x9, x13, #0x2, eq
     cd4:      	b.lo	0xd8c <ltmp0+0xd8c>
     cd8:      	cmp	x12, x21
     cdc:      	b.ne	0x1068 <ltmp0+0x1068>
     ce0:      	fcmp	d8, #0.0
     ce4:      	b.lt	0x1068 <ltmp0+0x1068>
     ce8:      	fcmp	d8, d12
     cec:      	b.pl	0x1068 <ltmp0+0x1068>
     cf0:      	mov	x9, #-0x20000000000     ; =-2199023255552
     cf4:      	add	x9, x8, x9
     cf8:      	lsr	x9, x9, #41
     cfc:      	cmp	x9, #0x3f
     d00:      	b.hs	0x1068 <ltmp0+0x1068>
     d04:      	fcvtzs	x9, d8
     d08:      	scvtf	d0, x9
     d0c:      	fcmp	d8, d0
     d10:      	b.ne	0x1068 <ltmp0+0x1068>
     d14:      	ldursb	w11, [x8, #-0x7]
     d18:      	tbnz	w11, #0x1f, 0x1068 <ltmp0+0x1068>
     d1c:      	ldurb	w11, [x8, #-0x8]
     d20:      	cmp	w11, #0x9
     d24:      	b.eq	0xe24 <ltmp0+0xe24>
     d28:      	cmp	w11, #0x2
     d2c:      	b.eq	0xdd4 <ltmp0+0xdd4>
     d30:      	cmp	w11, #0x1
     d34:      	b.ne	0x1068 <ltmp0+0x1068>
     d38:      	ldr	w10, [x8]
     d3c:      	mov	x11, x8
     d40:      	ldurh	w13, [x8, #-0x6]
     d44:      	adrp	x12, 0x0 <ltmp0>
		0000000000000d44:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
     d48:      	ldr	x12, [x12]
		0000000000000d48:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
     d4c:      	ldrb	w12, [x12]
     d50:      	ldr	w8, [x8, #0x4]
     d54:      	cmp	x10, x8
     d58:      	b.hi	0x1068 <ltmp0+0x1068>
     d5c:      	tbnz	w13, #0xa, 0x1068 <ltmp0+0x1068>
     d60:      	cbnz	w12, 0x1068 <ltmp0+0x1068>
     d64:      	cmp	x9, x10
     d68:      	b.hs	0x1068 <ltmp0+0x1068>
     d6c:      	add	x8, x11, x9, lsl #3
     d70:      	ldr	d0, [x8, #0x8]
     d74:      	fmov	x8, d0
     d78:      	mov	x9, #0x10               ; =16
     d7c:      	movk	x9, #0x7ffc, lsl #48
     d80:      	cmp	x8, x9
     d84:      	fcsel	d0, d13, d0, eq
     d88:      	b	0x1088 <ltmp0+0x1088>
     d8c:      	add	x8, x8, #0x10
     d90:      	cmp	w11, #0x3
     d94:      	b.le	0xdb8 <ltmp0+0xdb8>
     d98:      	cmp	w11, #0x5
     d9c:      	b.gt	0xe70 <ltmp0+0xe70>
     da0:      	cmp	w11, #0x4
     da4:      	b.eq	0xf1c <ltmp0+0xf1c>
     da8:      	cmp	w11, #0x5
     dac:      	b.ne	0xf10 <ltmp0+0xf10>
     db0:      	ldr	s0, [x8, x9, lsl #2]
     db4:      	b	0xf14 <ltmp0+0xf14>
     db8:      	cbz	w11, 0xf08 <ltmp0+0xf08>
     dbc:      	cmp	w11, #0x2
     dc0:      	b.eq	0xf30 <ltmp0+0xf30>
     dc4:      	cmp	w11, #0x3
     dc8:      	b.ne	0xf10 <ltmp0+0xf10>
     dcc:      	ldr	h0, [x8, x9, lsl #1]
     dd0:      	b	0xf14 <ltmp0+0xf14>
     dd4:      	ldr	x10, [x8, #0x8]
     dd8:      	cbz	x10, 0xe88 <ltmp0+0xe88>
     ddc:      	ldr	x11, [x10, #0x60]
     de0:      	cbz	x11, 0xe88 <ltmp0+0xe88>
     de4:      	ldurb	w8, [x11, #-0x8]
     de8:      	cmp	w8, #0x1
     dec:      	b.ne	0x1068 <ltmp0+0x1068>
     df0:      	ldursb	w8, [x11, #-0x7]
     df4:      	tbnz	w8, #0x1f, 0x1068 <ltmp0+0x1068>
     df8:      	ldr	w8, [x11]
     dfc:      	cmp	x9, x8
     e00:      	b.hs	0x1068 <ltmp0+0x1068>
     e04:      	add	x8, x11, x9, lsl #3
     e08:      	ldr	d0, [x8, #0x8]
     e0c:      	fmov	x8, d0
     e10:      	mov	x9, #0x10               ; =16
     e14:      	movk	x9, #0x7ffc, lsl #48
     e18:      	cmp	x8, x9
     e1c:      	b.eq	0x1068 <ltmp0+0x1068>
     e20:      	b	0x1088 <ltmp0+0x1088>
     e24:      	ldr	w12, [x8, #0x4]
     e28:      	ldr	x11, [x8, #0x20]
     e2c:      	ldurh	w13, [x8, #-0x6]
     e30:      	tst	w13, #0xc00
     e34:      	mov	w13, #0x5841            ; =22593
     e38:      	movk	w13, #0x4c5a, lsl #16
     e3c:      	ccmp	w12, w13, #0x0, eq
     e40:      	cset	w12, eq
     e44:      	cbz	x11, 0xed0 <ltmp0+0xed0>
     e48:      	tbz	w12, #0x0, 0xed0 <ltmp0+0xed0>
     e4c:      	ldurb	w10, [x11, #-0x8]
     e50:      	cmp	w10, #0x1
     e54:      	b.ne	0x1068 <ltmp0+0x1068>
     e58:      	ldursb	w10, [x11, #-0x7]
     e5c:      	tbnz	w10, #0x1f, 0x1068 <ltmp0+0x1068>
     e60:      	ldr	w10, [x11]
     e64:      	str	w10, [x8]
     e68:      	mov	x8, x11
     e6c:      	b	0xd40 <ltmp0+0xd40>
     e70:      	cmp	w11, #0x6
     e74:      	b.eq	0xf24 <ltmp0+0xf24>
     e78:      	cmp	w11, #0x7
     e7c:      	b.ne	0xf10 <ltmp0+0xf10>
     e80:      	ldr	d0, [x8, x9, lsl #3]
     e84:      	b	0x1088 <ltmp0+0x1088>
     e88:      	adrp	x12, 0x0 <ltmp0>
		0000000000000e88:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__3
     e8c:      	add	x12, x12, #0x0
		0000000000000e8c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__3
     e90:      	ldr	x11, [x12]
     e94:      	cmp	x11, #0x0
     e98:      	csel	x12, x12, x11, eq
     e9c:      	ldr	x12, [x12]
     ea0:      	cbz	x12, 0x1068 <ltmp0+0x1068>
     ea4:      	tbnz	x12, #0x3f, 0xf3c <ltmp0+0xf3c>
     ea8:      	ldp	w14, w13, [x8]
     eac:      	orr	x13, x13, x14, lsl #32
     eb0:      	cmp	x13, x12
     eb4:      	b.ne	0x1068 <ltmp0+0x1068>
     eb8:      	ldp	x14, x12, [x11, #0x8]
     ebc:      	ldp	x13, x11, [x11, #0x18]
     ec0:      	cmp	x14, x11
     ec4:      	b.lo	0xf5c <ltmp0+0xf5c>
     ec8:      	cbz	x10, 0x1068 <ltmp0+0x1068>
     ecc:      	b	0xfac <ltmp0+0xfac>
     ed0:      	cmp	x11, #0x0
     ed4:      	ldr	w14, [x8]
     ed8:      	ldp	x11, x13, [x8, #0x28]
     edc:      	ccmp	x9, x14, #0x2, eq
     ee0:      	ccmp	x11, #0x0, #0x4, lo
     ee4:      	ccmp	x13, #0x0, #0x4, ne
     ee8:      	csel	w12, wzr, w12, eq
     eec:      	tbz	w12, #0x0, 0x1068 <ltmp0+0x1068>
     ef0:      	lsr	x12, x9, #6
     ef4:      	ldr	x12, [x13, x12, lsl #3]
     ef8:      	lsr	x12, x12, x9
     efc:      	tbz	w12, #0x0, 0xf68 <ltmp0+0xf68>
     f00:      	ldr	d0, [x11, x9, lsl #3]
     f04:      	b	0x1088 <ltmp0+0x1088>
     f08:      	ldrsb	w8, [x8, x9]
     f0c:      	b	0xf34 <ltmp0+0xf34>
     f10:      	ldr	b0, [x8, x9]
     f14:      	ucvtf	d0, d0
     f18:      	b	0x1088 <ltmp0+0x1088>
     f1c:      	ldr	w8, [x8, x9, lsl #2]
     f20:      	b	0xf34 <ltmp0+0xf34>
     f24:      	ldr	s0, [x8, x9, lsl #2]
     f28:      	fcvt	d0, s0
     f2c:      	b	0x1088 <ltmp0+0x1088>
     f30:      	ldrsh	w8, [x8, x9, lsl #1]
     f34:      	scvtf	d0, w8
     f38:      	b	0x1088 <ltmp0+0x1088>
     f3c:      	cbz	x10, 0x1068 <ltmp0+0x1068>
     f40:      	ldr	x13, [x10, #0x30]
     f44:      	cmp	x13, x12
     f48:      	b.ne	0x1068 <ltmp0+0x1068>
     f4c:      	ldp	x14, x12, [x11, #0x8]
     f50:      	ldp	x13, x11, [x11, #0x18]
     f54:      	cmp	x14, x11
     f58:      	b.hs	0xfac <ltmp0+0xfac>
     f5c:      	add	x14, x8, x14, lsl #3
     f60:      	add	x14, x14, #0x10
     f64:      	b	0xfd0 <ltmp0+0xfd0>
     f68:      	ldr	x8, [x8, #0x50]
     f6c:      	mov	w12, #0x6903            ; =26883
     f70:      	movk	w12, #0x64, lsl #16
     f74:      	cmp	x8, x12
     f78:      	b.eq	0xf80 <ltmp0+0xf80>
     f7c:      	cbnz	x8, 0x1068 <ltmp0+0x1068>
     f80:      	mov	w12, #0x6903            ; =26883
     f84:      	movk	w12, #0x64, lsl #16
     f88:      	cmp	x8, x12
     f8c:      	b.ne	0x1038 <ltmp0+0x1038>
     f90:      	ldr	x8, [x11, x9, lsl #3]
     f94:      	cbz	x8, 0x1038 <ltmp0+0x1038>
     f98:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
     f9c:      	cmp	x8, x9
     fa0:      	csel	x8, xzr, x8, eq
     fa4:      	fmov	d1, x8
     fa8:      	b	0x1280 <ltmp0+0x1280>
     fac:      	ldr	x16, [x10, #0x20]
     fb0:      	cmp	x16, #0x0
     fb4:      	csel	x15, x16, x10, ne
     fb8:      	cbz	x16, 0x1068 <ltmp0+0x1068>
     fbc:      	ldr	w16, [x15]
     fc0:      	cmp	x14, x16
     fc4:      	b.hs	0x1068 <ltmp0+0x1068>
     fc8:      	add	x14, x15, x14, lsl #3
     fcc:      	add	x14, x14, #0x8
     fd0:      	ldr	d0, [x14]
     fd4:      	fcmp	d8, d0
     fd8:      	ccmp	x13, x9, #0x0, mi
     fdc:      	cset	w13, hi
     fe0:      	add	x9, x12, x9
     fe4:      	cmp	x9, x11
     fe8:      	ccmp	w13, #0x0, #0x4, lo
     fec:      	b.ne	0x102c <ltmp0+0x102c>
     ff0:      	cbz	x10, 0x1068 <ltmp0+0x1068>
     ff4:      	cmp	x9, x11
     ff8:      	b.lo	0x1068 <ltmp0+0x1068>
     ffc:      	eor	w8, w13, #0x1
    1000:      	tbnz	w8, #0x0, 0x1068 <ltmp0+0x1068>
    1004:      	ldr	x11, [x10, #0x20]
    1008:      	cmp	x11, #0x0
    100c:      	csel	x8, x11, x10, ne
    1010:      	cbz	x11, 0x1068 <ltmp0+0x1068>
    1014:      	ldr	w10, [x8]
    1018:      	cmp	x9, x10
    101c:      	b.hs	0x1068 <ltmp0+0x1068>
    1020:      	add	x8, x8, x9, lsl #3
    1024:      	ldr	d0, [x8, #0x8]
    1028:      	b	0x1088 <ltmp0+0x1088>
    102c:      	add	x8, x8, x9, lsl #3
    1030:      	ldr	d0, [x8, #0x10]
    1034:      	b	0x1088 <ltmp0+0x1088>
    1038:      	fmov	d0, x10
    103c:      	mov.16b	v1, v8
    1040:      	adrp	x0, 0x1000 <ltmp0+0x1000>
		0000000000001040:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    1044:      	add	x0, x0, #0x0
		0000000000001044:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    1048:      	mov	w1, #0x2                ; =2
    104c:      	bl	0x104c <ltmp0+0x104c>
		000000000000104c:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    1050:      	mov.16b	v1, v0
    1054:      	fmov	x8, d1
    1058:      	mov	x9, #0x10               ; =16
    105c:      	movk	x9, #0x7ffc, lsl #48
    1060:      	cmp	x8, x9
    1064:      	b.ne	0x1280 <ltmp0+0x1280>
    1068:      	fmov	d0, x28
    106c:      	str	x24, [sp, #0x18]
    1070:      	mov.16b	v1, v8
    1074:      	adrp	x0, 0x1000 <ltmp0+0x1000>
		0000000000001074:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__3
    1078:      	add	x0, x0, #0x0
		0000000000001078:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__3
    107c:      	bl	0x107c <ltmp0+0x107c>
		000000000000107c:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    1080:      	ldp	x28, x24, [sp, #0x10]
    1084:      	ldr	x19, [sp, #0x8]
    1088:      	fmov	x8, d0
    108c:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    1090:      	and	x9, x8, x9
    1094:      	cmp	x9, x21
    1098:      	b.ne	0x1104 <ltmp0+0x1104>
    109c:      	and	x0, x8, #0xffffffffffff
    10a0:      	lsr	x8, x0, #20
    10a4:      	cbz	x8, 0x1258 <ltmp0+0x1258>
    10a8:      	ldurb	w9, [x0, #-0x8]
    10ac:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		00000000000010ac:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__5
    10b0:      	ldr	x8, [x8]
		00000000000010b0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__5
    10b4:      	cbz	x8, 0x1174 <ltmp0+0x1174>
    10b8:      	ldurh	w10, [x0, #-0x6]
    10bc:      	and	w10, w10, #0x800
    10c0:      	cmp	w9, #0x2
    10c4:      	ccmp	w10, #0x0, #0x0, eq
    10c8:      	b.ne	0x1174 <ltmp0+0x1174>
    10cc:      	ldr	w10, [x0, #0x4]
    10d0:      	orr	x9, x10, #0x4000000000000000
    10d4:      	ldr	x11, [x8]
    10d8:      	cmp	w10, #0x0
    10dc:      	ccmp	x9, x11, #0x0, ne
    10e0:      	b.eq	0x11ac <ltmp0+0x11ac>
    10e4:      	ldr	x11, [x8, #0x10]
    10e8:      	cbz	x11, 0x11d0 <ltmp0+0x11d0>
    10ec:      	ldr	x12, [x0, #0x8]
    10f0:      	cbz	x12, 0x11d0 <ltmp0+0x11d0>
    10f4:      	ldr	x12, [x12, #0x30]
    10f8:      	cmp	x12, x11
    10fc:      	b.eq	0x119c <ltmp0+0x119c>
    1100:      	b	0x11d0 <ltmp0+0x11d0>
    1104:      	lsr	x9, x8, #48
    1108:      	mov	w10, #0x7ff9            ; =32761
    110c:      	cmp	x9, x10
    1110:      	b.eq	0x1158 <ltmp0+0x1158>
    1114:      	mov	w10, #0x7ffe            ; =32766
    1118:      	cmp	w9, w10
    111c:      	b.ne	0x1148 <ltmp0+0x1148>
    1120:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		0000000000001120:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    1124:      	ldr	x9, [x9]
		0000000000001124:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    1128:      	str	x24, [sp, #0x18]
    112c:      	and	x2, x9, #0xffffffffffff
    1130:      	mov	x0, #0x4                ; =4
    1134:      	movk	x0, #0xddae, lsl #32
    1138:      	movk	x0, #0x5556, lsl #48
    113c:      	mov	x1, x8
    1140:      	bl	0x1140 <ltmp0+0x1140>
		0000000000001140:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    1144:      	b	0x1274 <ltmp0+0x1274>
    1148:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    114c:      	add	x9, x8, x9
    1150:      	cmp	x9, #0x2
    1154:      	b.lo	0x3024 <ltmp0+0x3024>
    1158:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		0000000000001158:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    115c:      	ldr	x9, [x9]
		000000000000115c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    1160:      	str	x24, [sp, #0x18]
    1164:      	and	x1, x9, #0xffffffffffff
    1168:      	mov	x0, x8
    116c:      	bl	0x116c <ltmp0+0x116c>
		000000000000116c:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    1170:      	b	0x1274 <ltmp0+0x1274>
    1174:      	cmp	w9, #0x2
    1178:      	ccmp	x8, #0x0, #0x4, eq
    117c:      	b.eq	0x1258 <ltmp0+0x1258>
    1180:      	ldr	x9, [x8, #0x10]
    1184:      	cbz	x9, 0x1258 <ltmp0+0x1258>
    1188:      	ldr	x10, [x0, #0x8]
    118c:      	cbz	x10, 0x1258 <ltmp0+0x1258>
    1190:      	ldr	x10, [x10, #0x30]
    1194:      	cmp	x10, x9
    1198:      	b.ne	0x1258 <ltmp0+0x1258>
    119c:      	ldr	x8, [x8, #0x8]
    11a0:      	add	x8, x0, x8, lsl #3
    11a4:      	ldr	d1, [x8, #0x10]
    11a8:      	b	0x1280 <ltmp0+0x1280>
    11ac:      	ldr	x2, [x8, #0x8]
    11b0:      	tbnz	w2, #0x1e, 0x1310 <ltmp0+0x1310>
    11b4:      	add	x11, x0, x2, lsl #3
    11b8:      	ldr	d1, [x11, #0x10]
    11bc:      	fmov	x11, d1
    11c0:      	mov	x12, #0x10              ; =16
    11c4:      	movk	x12, #0x7ffc, lsl #48
    11c8:      	cmp	x11, x12
    11cc:      	b.ne	0x1280 <ltmp0+0x1280>
    11d0:      	ldr	x11, [x8, #0x18]
    11d4:      	cmp	x11, #0x0
    11d8:      	b.le	0x1258 <ltmp0+0x1258>
    11dc:      	ldr	x11, [x8, #0x20]
    11e0:      	ldr	x12, [x8, #0x30]
    11e4:      	ldr	x13, [x8, #0x40]
    11e8:      	cmp	x13, x9
    11ec:      	ldr	x14, [x8, #0x50]
    11f0:      	ccmp	x14, x9, #0x4, ne
    11f4:      	ccmp	x12, x9, #0x4, ne
    11f8:      	ccmp	x11, x9, #0x4, ne
    11fc:      	cset	w15, eq
    1200:      	cmp	w10, #0x0
    1204:      	ccmp	w15, #0x0, #0x4, ne
    1208:      	b.eq	0x1258 <ltmp0+0x1258>
    120c:      	ldr	x10, [x8, #0x48]
    1210:      	ldr	x15, [x8, #0x58]
    1214:      	cmp	x14, x9
    1218:      	csel	x14, x15, xzr, eq
    121c:      	cmp	x13, x9
    1220:      	csel	x10, x10, x14, eq
    1224:      	ldr	x13, [x8, #0x28]
    1228:      	ldr	x8, [x8, #0x38]
    122c:      	cmp	x12, x9
    1230:      	csel	x8, x8, x10, eq
    1234:      	cmp	x11, x9
    1238:      	csel	x8, x13, x8, eq
    123c:      	add	x8, x0, x8, lsl #3
    1240:      	ldr	d1, [x8, #0x10]
    1244:      	fmov	x8, d1
    1248:      	mov	x9, #0x10               ; =16
    124c:      	movk	x9, #0x7ffc, lsl #48
    1250:      	cmp	x8, x9
    1254:      	b.ne	0x1280 <ltmp0+0x1280>
    1258:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		0000000000001258:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    125c:      	ldr	x8, [x8]
		000000000000125c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    1260:      	str	x24, [sp, #0x18]
    1264:      	and	x1, x8, #0xffffffffffff
    1268:      	adrp	x2, 0x1000 <ltmp0+0x1000>
		0000000000001268:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__5
    126c:      	add	x2, x2, #0x0
		000000000000126c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__5
    1270:      	bl	0x1270 <ltmp0+0x1270>
		0000000000001270:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    1274:      	mov.16b	v1, v0
    1278:      	ldp	x19, x28, [sp, #0x8]
    127c:      	ldr	x24, [sp, #0x18]
    1280:      	fmov	d0, x24
    1284:      	and	x9, x24, #0xffff000000000000
    1288:      	fmov	x8, d1
    128c:      	and	x10, x8, #0xffff000000000000
    1290:      	cmp	x8, x20
    1294:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    1298:      	ccmp	x10, x8, #0x2, hs
    129c:      	cset	w8, hi
    12a0:      	mov	x10, #0x1               ; =1
    12a4:      	movk	x10, #0x7fff, lsl #48
    12a8:      	cmp	x9, x10
    12ac:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    12b0:      	ccmp	x24, x9, #0x0, lo
    12b4:      	b.hi	0x12c4 <ltmp0+0x12c4>
    12b8:      	tbz	w8, #0x0, 0x12c4 <ltmp0+0x12c4>
    12bc:      	fadd	d0, d1, d0
    12c0:      	b	0x12cc <ltmp0+0x12cc>
    12c4:      	bl	0x12c4 <ltmp0+0x12c4>
		00000000000012c4:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    12c8:      	ldp	x19, x28, [sp, #0x8]
    12cc:      	fmov	x24, d0
    12d0:      	mov	x0, x24
    12d4:      	ldr	w8, [x26]
    12d8:      	cbz	w8, 0x12e0 <ltmp0+0x12e0>
    12dc:      	bl	0x12dc <ltmp0+0x12dc>
		00000000000012dc:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    12e0:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		00000000000012e0:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    12e4:      	ldr	x8, [x8]
		00000000000012e4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    12e8:      	ldr	w8, [x8]
    12ec:      	cbz	w8, 0x1300 <ltmp0+0x1300>
    12f0:      	str	x24, [sp, #0x18]
    12f4:      	bl	0x12f4 <ltmp0+0x12f4>
		00000000000012f4:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    12f8:      	ldp	x28, x24, [sp, #0x10]
    12fc:      	ldr	x19, [sp, #0x8]
    1300:      	fadd	d15, d15, d14
    1304:      	add	w27, w27, #0x1
    1308:      	tbz	w25, #0x0, 0xb90 <ltmp0+0xb90>
    130c:      	b	0xbdc <ltmp0+0xbdc>
    1310:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		0000000000001310:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    1314:      	ldr	x8, [x8]
		0000000000001314:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    1318:      	str	x24, [sp, #0x18]
    131c:      	and	x1, x8, #0xffffffffffff
    1320:      	adrp	x3, 0x1000 <ltmp0+0x1000>
		0000000000001320:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__5
    1324:      	add	x3, x3, #0x0
		0000000000001324:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__5
    1328:      	bl	0x1328 <ltmp0+0x1328>
		0000000000001328:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    132c:      	b	0x1274 <ltmp0+0x1274>
    1330:      	str	w21, [sp, #0x4]
    1334:      	mov	w25, #0x0               ; =0
    1338:      	mov	x24, #0x0               ; =0
    133c:      	mov	x22, #0x7ffd000000000000 ; =9222527611924643840
    1340:      	ldr	d9, [x23]
		0000000000001340:  ARM64_RELOC_PAGEOFF12	lCPI0_1
    1344:      	mov	x23, #0x7ffffff00000    ; =140737487306752
    1348:      	ldr	d10, [x11]
		0000000000001348:  ARM64_RELOC_PAGEOFF12	lCPI0_2
    134c:      	mov	x26, #0x7fff000000000000 ; =9223090561878065152
    1350:      	mov	x20, #0x7ff8ffffffffffff ; =9221401712017801215
    1354:      	mov	x8, #0x41f0000000000000 ; =4751297606875873280
    1358:      	fmov	d11, x8
    135c:      	ldr	w8, [sp, #0x4]
    1360:      	tbz	w8, #0x0, 0x1374 <ltmp0+0x1374>
    1364:      	cmp	w25, w21
    1368:      	b.ge	0x1d4 <ltmp0+0x1d4>
    136c:      	scvtf	d0, w25
    1370:      	b	0x13b8 <ltmp0+0x13b8>
    1374:      	mov	x23, x21
    1378:      	mov	x21, x19
    137c:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		000000000000137c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    1380:      	ldr	x8, [x8]
		0000000000001380:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    1384:      	ldr	w8, [x8]
    1388:      	cbz	w8, 0x13a0 <ltmp0+0x13a0>
    138c:      	stp	x28, x19, [sp, #0x10]
    1390:      	str	x24, [sp, #0x8]
    1394:      	bl	0x1394 <ltmp0+0x1394>
		0000000000001394:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    1398:      	ldp	x24, x28, [sp, #0x8]
    139c:      	ldr	x19, [sp, #0x18]
    13a0:      	scvtf	d0, w25
    13a4:      	fmov	d1, x21
    13a8:      	fcmp	d0, d1
    13ac:      	mov	x21, x23
    13b0:      	mov	x23, #0x7ffffff00000    ; =140737487306752
    13b4:      	b.pl	0x1d4 <ltmp0+0x1d4>
    13b8:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		00000000000013b8:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    13bc:      	ldr	d1, [x8]
		00000000000013bc:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    13c0:      	stp	x19, x24, [sp, #0x10]
    13c4:      	str	x28, [sp, #0x8]
    13c8:      	bl	0x13c8 <ltmp0+0x13c8>
		00000000000013c8:  ARM64_RELOC_BRANCH26	_js_dynamic_mod
    13cc:      	mov.16b	v8, v0
    13d0:      	ldp	x28, x19, [sp, #0x8]
    13d4:      	ldr	x24, [sp, #0x18]
    13d8:      	mov	x0, x24
    13dc:      	ldr	w8, [x27]
    13e0:      	cbz	w8, 0x13e8 <ltmp0+0x13e8>
    13e4:      	bl	0x13e4 <ltmp0+0x13e4>
		00000000000013e4:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    13e8:      	mov	x10, x28
    13ec:      	and	x8, x10, #0xffffffffffff
    13f0:      	and	x12, x10, #0xffff000000000000
    13f4:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		00000000000013f4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    13f8:      	ldr	x9, [x9]
		00000000000013f8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    13fc:      	ldr	x9, [x9]
    1400:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
    1404:      	cmp	x12, x22
    1408:      	ccmp	x9, #0x0, #0x0, eq
    140c:      	ccmp	x11, x23, #0x2, eq
    1410:      	b.hs	0x1454 <ltmp0+0x1454>
    1414:      	mov	x9, #0x41f0000000000000 ; =4751297606875873280
    1418:      	fmov	d0, x9
    141c:      	fcmp	d8, d0
    1420:      	b.pl	0x1454 <ltmp0+0x1454>
    1424:      	ldurb	w9, [x8, #-0x8]
    1428:      	ldrb	w11, [x8, #0x8]
    142c:      	fcmp	d8, #0.0
    1430:      	ccmp	w9, #0xb, #0x0, ge
    1434:      	ccmp	w11, #0x9, #0x2, eq
    1438:      	b.hs	0x1454 <ltmp0+0x1454>
    143c:      	fcvtzs	x9, d8
    1440:      	scvtf	d0, x9
    1444:      	ldr	w13, [x8]
    1448:      	fcmp	d8, d0
    144c:      	ccmp	x9, x13, #0x2, eq
    1450:      	b.lo	0x1508 <ltmp0+0x1508>
    1454:      	cmp	x12, x22
    1458:      	b.ne	0x17e4 <ltmp0+0x17e4>
    145c:      	fcmp	d8, #0.0
    1460:      	b.lt	0x17e4 <ltmp0+0x17e4>
    1464:      	fcmp	d8, d9
    1468:      	b.pl	0x17e4 <ltmp0+0x17e4>
    146c:      	mov	x9, #-0x20000000000     ; =-2199023255552
    1470:      	add	x9, x8, x9
    1474:      	lsr	x9, x9, #41
    1478:      	cmp	x9, #0x3f
    147c:      	b.hs	0x17e4 <ltmp0+0x17e4>
    1480:      	fcvtzs	x9, d8
    1484:      	scvtf	d0, x9
    1488:      	fcmp	d8, d0
    148c:      	b.ne	0x17e4 <ltmp0+0x17e4>
    1490:      	ldursb	w11, [x8, #-0x7]
    1494:      	tbnz	w11, #0x1f, 0x17e4 <ltmp0+0x17e4>
    1498:      	ldurb	w11, [x8, #-0x8]
    149c:      	cmp	w11, #0x9
    14a0:      	b.eq	0x15a0 <ltmp0+0x15a0>
    14a4:      	cmp	w11, #0x2
    14a8:      	b.eq	0x1550 <ltmp0+0x1550>
    14ac:      	cmp	w11, #0x1
    14b0:      	b.ne	0x17e4 <ltmp0+0x17e4>
    14b4:      	ldr	w10, [x8]
    14b8:      	mov	x11, x8
    14bc:      	ldurh	w13, [x8, #-0x6]
    14c0:      	adrp	x12, 0x1000 <ltmp0+0x1000>
		00000000000014c0:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    14c4:      	ldr	x12, [x12]
		00000000000014c4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    14c8:      	ldrb	w12, [x12]
    14cc:      	ldr	w8, [x8, #0x4]
    14d0:      	cmp	x10, x8
    14d4:      	b.hi	0x17e4 <ltmp0+0x17e4>
    14d8:      	tbnz	w13, #0xa, 0x17e4 <ltmp0+0x17e4>
    14dc:      	cbnz	w12, 0x17e4 <ltmp0+0x17e4>
    14e0:      	cmp	x9, x10
    14e4:      	b.hs	0x17e4 <ltmp0+0x17e4>
    14e8:      	add	x8, x11, x9, lsl #3
    14ec:      	ldr	d0, [x8, #0x8]
    14f0:      	fmov	x8, d0
    14f4:      	mov	x9, #0x10               ; =16
    14f8:      	movk	x9, #0x7ffc, lsl #48
    14fc:      	cmp	x8, x9
    1500:      	fcsel	d0, d10, d0, eq
    1504:      	b	0x1804 <ltmp0+0x1804>
    1508:      	add	x8, x8, #0x10
    150c:      	cmp	w11, #0x3
    1510:      	b.le	0x1534 <ltmp0+0x1534>
    1514:      	cmp	w11, #0x5
    1518:      	b.gt	0x15ec <ltmp0+0x15ec>
    151c:      	cmp	w11, #0x4
    1520:      	b.eq	0x1698 <ltmp0+0x1698>
    1524:      	cmp	w11, #0x5
    1528:      	b.ne	0x168c <ltmp0+0x168c>
    152c:      	ldr	s0, [x8, x9, lsl #2]
    1530:      	b	0x1690 <ltmp0+0x1690>
    1534:      	cbz	w11, 0x1684 <ltmp0+0x1684>
    1538:      	cmp	w11, #0x2
    153c:      	b.eq	0x16ac <ltmp0+0x16ac>
    1540:      	cmp	w11, #0x3
    1544:      	b.ne	0x168c <ltmp0+0x168c>
    1548:      	ldr	h0, [x8, x9, lsl #1]
    154c:      	b	0x1690 <ltmp0+0x1690>
    1550:      	ldr	x10, [x8, #0x8]
    1554:      	cbz	x10, 0x1604 <ltmp0+0x1604>
    1558:      	ldr	x11, [x10, #0x60]
    155c:      	cbz	x11, 0x1604 <ltmp0+0x1604>
    1560:      	ldurb	w8, [x11, #-0x8]
    1564:      	cmp	w8, #0x1
    1568:      	b.ne	0x17e4 <ltmp0+0x17e4>
    156c:      	ldursb	w8, [x11, #-0x7]
    1570:      	tbnz	w8, #0x1f, 0x17e4 <ltmp0+0x17e4>
    1574:      	ldr	w8, [x11]
    1578:      	cmp	x9, x8
    157c:      	b.hs	0x17e4 <ltmp0+0x17e4>
    1580:      	add	x8, x11, x9, lsl #3
    1584:      	ldr	d0, [x8, #0x8]
    1588:      	fmov	x8, d0
    158c:      	mov	x9, #0x10               ; =16
    1590:      	movk	x9, #0x7ffc, lsl #48
    1594:      	cmp	x8, x9
    1598:      	b.eq	0x17e4 <ltmp0+0x17e4>
    159c:      	b	0x1804 <ltmp0+0x1804>
    15a0:      	ldr	w12, [x8, #0x4]
    15a4:      	ldr	x11, [x8, #0x20]
    15a8:      	ldurh	w13, [x8, #-0x6]
    15ac:      	tst	w13, #0xc00
    15b0:      	mov	w13, #0x5841            ; =22593
    15b4:      	movk	w13, #0x4c5a, lsl #16
    15b8:      	ccmp	w12, w13, #0x0, eq
    15bc:      	cset	w12, eq
    15c0:      	cbz	x11, 0x164c <ltmp0+0x164c>
    15c4:      	tbz	w12, #0x0, 0x164c <ltmp0+0x164c>
    15c8:      	ldurb	w10, [x11, #-0x8]
    15cc:      	cmp	w10, #0x1
    15d0:      	b.ne	0x17e4 <ltmp0+0x17e4>
    15d4:      	ldursb	w10, [x11, #-0x7]
    15d8:      	tbnz	w10, #0x1f, 0x17e4 <ltmp0+0x17e4>
    15dc:      	ldr	w10, [x11]
    15e0:      	str	w10, [x8]
    15e4:      	mov	x8, x11
    15e8:      	b	0x14bc <ltmp0+0x14bc>
    15ec:      	cmp	w11, #0x6
    15f0:      	b.eq	0x16a0 <ltmp0+0x16a0>
    15f4:      	cmp	w11, #0x7
    15f8:      	b.ne	0x168c <ltmp0+0x168c>
    15fc:      	ldr	d0, [x8, x9, lsl #3]
    1600:      	b	0x1804 <ltmp0+0x1804>
    1604:      	adrp	x12, 0x1000 <ltmp0+0x1000>
		0000000000001604:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__6
    1608:      	add	x12, x12, #0x0
		0000000000001608:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__6
    160c:      	ldr	x11, [x12]
    1610:      	cmp	x11, #0x0
    1614:      	csel	x12, x12, x11, eq
    1618:      	ldr	x12, [x12]
    161c:      	cbz	x12, 0x17e4 <ltmp0+0x17e4>
    1620:      	tbnz	x12, #0x3f, 0x16b8 <ltmp0+0x16b8>
    1624:      	ldp	w14, w13, [x8]
    1628:      	orr	x13, x13, x14, lsl #32
    162c:      	cmp	x13, x12
    1630:      	b.ne	0x17e4 <ltmp0+0x17e4>
    1634:      	ldp	x14, x12, [x11, #0x8]
    1638:      	ldp	x13, x11, [x11, #0x18]
    163c:      	cmp	x14, x11
    1640:      	b.lo	0x16d8 <ltmp0+0x16d8>
    1644:      	cbz	x10, 0x17e4 <ltmp0+0x17e4>
    1648:      	b	0x1728 <ltmp0+0x1728>
    164c:      	cmp	x11, #0x0
    1650:      	ldr	w14, [x8]
    1654:      	ldp	x11, x13, [x8, #0x28]
    1658:      	ccmp	x9, x14, #0x2, eq
    165c:      	ccmp	x11, #0x0, #0x4, lo
    1660:      	ccmp	x13, #0x0, #0x4, ne
    1664:      	csel	w12, wzr, w12, eq
    1668:      	tbz	w12, #0x0, 0x17e4 <ltmp0+0x17e4>
    166c:      	lsr	x12, x9, #6
    1670:      	ldr	x12, [x13, x12, lsl #3]
    1674:      	lsr	x12, x12, x9
    1678:      	tbz	w12, #0x0, 0x16e4 <ltmp0+0x16e4>
    167c:      	ldr	d0, [x11, x9, lsl #3]
    1680:      	b	0x1804 <ltmp0+0x1804>
    1684:      	ldrsb	w8, [x8, x9]
    1688:      	b	0x16b0 <ltmp0+0x16b0>
    168c:      	ldr	b0, [x8, x9]
    1690:      	ucvtf	d0, d0
    1694:      	b	0x1804 <ltmp0+0x1804>
    1698:      	ldr	w8, [x8, x9, lsl #2]
    169c:      	b	0x16b0 <ltmp0+0x16b0>
    16a0:      	ldr	s0, [x8, x9, lsl #2]
    16a4:      	fcvt	d0, s0
    16a8:      	b	0x1804 <ltmp0+0x1804>
    16ac:      	ldrsh	w8, [x8, x9, lsl #1]
    16b0:      	scvtf	d0, w8
    16b4:      	b	0x1804 <ltmp0+0x1804>
    16b8:      	cbz	x10, 0x17e4 <ltmp0+0x17e4>
    16bc:      	ldr	x13, [x10, #0x30]
    16c0:      	cmp	x13, x12
    16c4:      	b.ne	0x17e4 <ltmp0+0x17e4>
    16c8:      	ldp	x14, x12, [x11, #0x8]
    16cc:      	ldp	x13, x11, [x11, #0x18]
    16d0:      	cmp	x14, x11
    16d4:      	b.hs	0x1728 <ltmp0+0x1728>
    16d8:      	add	x14, x8, x14, lsl #3
    16dc:      	add	x14, x14, #0x10
    16e0:      	b	0x174c <ltmp0+0x174c>
    16e4:      	ldr	x8, [x8, #0x50]
    16e8:      	mov	w12, #0x6903            ; =26883
    16ec:      	movk	w12, #0x64, lsl #16
    16f0:      	cmp	x8, x12
    16f4:      	b.eq	0x16fc <ltmp0+0x16fc>
    16f8:      	cbnz	x8, 0x17e4 <ltmp0+0x17e4>
    16fc:      	mov	w12, #0x6903            ; =26883
    1700:      	movk	w12, #0x64, lsl #16
    1704:      	cmp	x8, x12
    1708:      	b.ne	0x17b4 <ltmp0+0x17b4>
    170c:      	ldr	x8, [x11, x9, lsl #3]
    1710:      	cbz	x8, 0x17b4 <ltmp0+0x17b4>
    1714:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    1718:      	cmp	x8, x9
    171c:      	csel	x8, xzr, x8, eq
    1720:      	fmov	d1, x8
    1724:      	b	0x19fc <ltmp0+0x19fc>
    1728:      	ldr	x16, [x10, #0x20]
    172c:      	cmp	x16, #0x0
    1730:      	csel	x15, x16, x10, ne
    1734:      	cbz	x16, 0x17e4 <ltmp0+0x17e4>
    1738:      	ldr	w16, [x15]
    173c:      	cmp	x14, x16
    1740:      	b.hs	0x17e4 <ltmp0+0x17e4>
    1744:      	add	x14, x15, x14, lsl #3
    1748:      	add	x14, x14, #0x8
    174c:      	ldr	d0, [x14]
    1750:      	fcmp	d8, d0
    1754:      	ccmp	x13, x9, #0x0, mi
    1758:      	cset	w13, hi
    175c:      	add	x9, x12, x9
    1760:      	cmp	x9, x11
    1764:      	ccmp	w13, #0x0, #0x4, lo
    1768:      	b.ne	0x17a8 <ltmp0+0x17a8>
    176c:      	cbz	x10, 0x17e4 <ltmp0+0x17e4>
    1770:      	cmp	x9, x11
    1774:      	b.lo	0x17e4 <ltmp0+0x17e4>
    1778:      	eor	w8, w13, #0x1
    177c:      	tbnz	w8, #0x0, 0x17e4 <ltmp0+0x17e4>
    1780:      	ldr	x11, [x10, #0x20]
    1784:      	cmp	x11, #0x0
    1788:      	csel	x8, x11, x10, ne
    178c:      	cbz	x11, 0x17e4 <ltmp0+0x17e4>
    1790:      	ldr	w10, [x8]
    1794:      	cmp	x9, x10
    1798:      	b.hs	0x17e4 <ltmp0+0x17e4>
    179c:      	add	x8, x8, x9, lsl #3
    17a0:      	ldr	d0, [x8, #0x8]
    17a4:      	b	0x1804 <ltmp0+0x1804>
    17a8:      	add	x8, x8, x9, lsl #3
    17ac:      	ldr	d0, [x8, #0x10]
    17b0:      	b	0x1804 <ltmp0+0x1804>
    17b4:      	fmov	d0, x10
    17b8:      	mov.16b	v1, v8
    17bc:      	adrp	x0, 0x1000 <ltmp0+0x1000>
		00000000000017bc:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    17c0:      	add	x0, x0, #0x0
		00000000000017c0:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    17c4:      	mov	w1, #0x2                ; =2
    17c8:      	bl	0x17c8 <ltmp0+0x17c8>
		00000000000017c8:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    17cc:      	mov.16b	v1, v0
    17d0:      	fmov	x8, d1
    17d4:      	mov	x9, #0x10               ; =16
    17d8:      	movk	x9, #0x7ffc, lsl #48
    17dc:      	cmp	x8, x9
    17e0:      	b.ne	0x19fc <ltmp0+0x19fc>
    17e4:      	fmov	d0, x28
    17e8:      	str	x24, [sp, #0x18]
    17ec:      	mov.16b	v1, v8
    17f0:      	adrp	x0, 0x1000 <ltmp0+0x1000>
		00000000000017f0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__6
    17f4:      	add	x0, x0, #0x0
		00000000000017f4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__6
    17f8:      	bl	0x17f8 <ltmp0+0x17f8>
		00000000000017f8:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    17fc:      	ldp	x28, x19, [sp, #0x8]
    1800:      	ldr	x24, [sp, #0x18]
    1804:      	fmov	x8, d0
    1808:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    180c:      	and	x9, x8, x9
    1810:      	cmp	x9, x22
    1814:      	b.ne	0x1880 <ltmp0+0x1880>
    1818:      	and	x0, x8, #0xffffffffffff
    181c:      	lsr	x8, x0, #20
    1820:      	cbz	x8, 0x19d4 <ltmp0+0x19d4>
    1824:      	ldurb	w9, [x0, #-0x8]
    1828:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		0000000000001828:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__8
    182c:      	ldr	x8, [x8]
		000000000000182c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__8
    1830:      	cbz	x8, 0x18f0 <ltmp0+0x18f0>
    1834:      	ldurh	w10, [x0, #-0x6]
    1838:      	and	w10, w10, #0x800
    183c:      	cmp	w9, #0x2
    1840:      	ccmp	w10, #0x0, #0x0, eq
    1844:      	b.ne	0x18f0 <ltmp0+0x18f0>
    1848:      	ldr	w10, [x0, #0x4]
    184c:      	orr	x9, x10, #0x4000000000000000
    1850:      	ldr	x11, [x8]
    1854:      	cmp	w10, #0x0
    1858:      	ccmp	x9, x11, #0x0, ne
    185c:      	b.eq	0x1928 <ltmp0+0x1928>
    1860:      	ldr	x11, [x8, #0x10]
    1864:      	cbz	x11, 0x194c <ltmp0+0x194c>
    1868:      	ldr	x12, [x0, #0x8]
    186c:      	cbz	x12, 0x194c <ltmp0+0x194c>
    1870:      	ldr	x12, [x12, #0x30]
    1874:      	cmp	x12, x11
    1878:      	b.eq	0x1918 <ltmp0+0x1918>
    187c:      	b	0x194c <ltmp0+0x194c>
    1880:      	lsr	x9, x8, #48
    1884:      	mov	w10, #0x7ff9            ; =32761
    1888:      	cmp	x9, x10
    188c:      	b.eq	0x18d4 <ltmp0+0x18d4>
    1890:      	mov	w10, #0x7ffe            ; =32766
    1894:      	cmp	w9, w10
    1898:      	b.ne	0x18c4 <ltmp0+0x18c4>
    189c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		000000000000189c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    18a0:      	ldr	x9, [x9]
		00000000000018a0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    18a4:      	str	x24, [sp, #0x18]
    18a8:      	and	x2, x9, #0xffffffffffff
    18ac:      	mov	x0, #0x7                ; =7
    18b0:      	movk	x0, #0xddae, lsl #32
    18b4:      	movk	x0, #0x5556, lsl #48
    18b8:      	mov	x1, x8
    18bc:      	bl	0x18bc <ltmp0+0x18bc>
		00000000000018bc:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    18c0:      	b	0x19f0 <ltmp0+0x19f0>
    18c4:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    18c8:      	add	x9, x8, x9
    18cc:      	cmp	x9, #0x2
    18d0:      	b.lo	0x3024 <ltmp0+0x3024>
    18d4:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		00000000000018d4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    18d8:      	ldr	x9, [x9]
		00000000000018d8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    18dc:      	str	x24, [sp, #0x18]
    18e0:      	and	x1, x9, #0xffffffffffff
    18e4:      	mov	x0, x8
    18e8:      	bl	0x18e8 <ltmp0+0x18e8>
		00000000000018e8:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    18ec:      	b	0x19f0 <ltmp0+0x19f0>
    18f0:      	cmp	w9, #0x2
    18f4:      	ccmp	x8, #0x0, #0x4, eq
    18f8:      	b.eq	0x19d4 <ltmp0+0x19d4>
    18fc:      	ldr	x9, [x8, #0x10]
    1900:      	cbz	x9, 0x19d4 <ltmp0+0x19d4>
    1904:      	ldr	x10, [x0, #0x8]
    1908:      	cbz	x10, 0x19d4 <ltmp0+0x19d4>
    190c:      	ldr	x10, [x10, #0x30]
    1910:      	cmp	x10, x9
    1914:      	b.ne	0x19d4 <ltmp0+0x19d4>
    1918:      	ldr	x8, [x8, #0x8]
    191c:      	add	x8, x0, x8, lsl #3
    1920:      	ldr	d1, [x8, #0x10]
    1924:      	b	0x19fc <ltmp0+0x19fc>
    1928:      	ldr	x2, [x8, #0x8]
    192c:      	tbnz	w2, #0x1e, 0x1cd0 <ltmp0+0x1cd0>
    1930:      	add	x11, x0, x2, lsl #3
    1934:      	ldr	d1, [x11, #0x10]
    1938:      	fmov	x11, d1
    193c:      	mov	x12, #0x10              ; =16
    1940:      	movk	x12, #0x7ffc, lsl #48
    1944:      	cmp	x11, x12
    1948:      	b.ne	0x19fc <ltmp0+0x19fc>
    194c:      	ldr	x11, [x8, #0x18]
    1950:      	cmp	x11, #0x0
    1954:      	b.le	0x19d4 <ltmp0+0x19d4>
    1958:      	ldr	x11, [x8, #0x20]
    195c:      	ldr	x12, [x8, #0x30]
    1960:      	ldr	x13, [x8, #0x40]
    1964:      	cmp	x13, x9
    1968:      	ldr	x14, [x8, #0x50]
    196c:      	ccmp	x14, x9, #0x4, ne
    1970:      	ccmp	x12, x9, #0x4, ne
    1974:      	ccmp	x11, x9, #0x4, ne
    1978:      	cset	w15, eq
    197c:      	cmp	w10, #0x0
    1980:      	ccmp	w15, #0x0, #0x4, ne
    1984:      	b.eq	0x19d4 <ltmp0+0x19d4>
    1988:      	ldr	x10, [x8, #0x48]
    198c:      	ldr	x15, [x8, #0x58]
    1990:      	cmp	x14, x9
    1994:      	csel	x14, x15, xzr, eq
    1998:      	cmp	x13, x9
    199c:      	csel	x10, x10, x14, eq
    19a0:      	ldr	x13, [x8, #0x28]
    19a4:      	ldr	x8, [x8, #0x38]
    19a8:      	cmp	x12, x9
    19ac:      	csel	x8, x8, x10, eq
    19b0:      	cmp	x11, x9
    19b4:      	csel	x8, x13, x8, eq
    19b8:      	add	x8, x0, x8, lsl #3
    19bc:      	ldr	d1, [x8, #0x10]
    19c0:      	fmov	x8, d1
    19c4:      	mov	x9, #0x10               ; =16
    19c8:      	movk	x9, #0x7ffc, lsl #48
    19cc:      	cmp	x8, x9
    19d0:      	b.ne	0x19fc <ltmp0+0x19fc>
    19d4:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		00000000000019d4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    19d8:      	ldr	x8, [x8]
		00000000000019d8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    19dc:      	str	x24, [sp, #0x18]
    19e0:      	and	x1, x8, #0xffffffffffff
    19e4:      	adrp	x2, 0x1000 <ltmp0+0x1000>
		00000000000019e4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__8
    19e8:      	add	x2, x2, #0x0
		00000000000019e8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__8
    19ec:      	bl	0x19ec <ltmp0+0x19ec>
		00000000000019ec:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    19f0:      	mov.16b	v1, v0
    19f4:      	ldp	x28, x19, [sp, #0x8]
    19f8:      	ldr	x24, [sp, #0x18]
    19fc:      	fmov	d0, x24
    1a00:      	and	x9, x24, #0xffff000000000000
    1a04:      	fmov	x8, d1
    1a08:      	and	x10, x8, #0xffff000000000000
    1a0c:      	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
    1a10:      	cmp	x8, x11
    1a14:      	ccmp	x10, x26, #0x2, hs
    1a18:      	cset	w8, hi
    1a1c:      	mov	x10, #0x1               ; =1
    1a20:      	movk	x10, #0x7fff, lsl #48
    1a24:      	cmp	x9, x10
    1a28:      	ccmp	x24, x20, #0x0, lo
    1a2c:      	b.hi	0x1a3c <ltmp0+0x1a3c>
    1a30:      	tbz	w8, #0x0, 0x1a3c <ltmp0+0x1a3c>
    1a34:      	fadd	d0, d1, d0
    1a38:      	b	0x1a44 <ltmp0+0x1a44>
    1a3c:      	bl	0x1a3c <ltmp0+0x1a3c>
		0000000000001a3c:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    1a40:      	ldp	x28, x19, [sp, #0x8]
    1a44:      	fmov	x24, d0
    1a48:      	mov	x0, x24
    1a4c:      	ldr	w8, [x27]
    1a50:      	cbz	w8, 0x1a58 <ltmp0+0x1a58>
    1a54:      	bl	0x1a54 <ltmp0+0x1a54>
		0000000000001a54:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    1a58:      	mov	x0, x24
    1a5c:      	ldr	w8, [x27]
    1a60:      	cbz	w8, 0x1a68 <ltmp0+0x1a68>
    1a64:      	bl	0x1a64 <ltmp0+0x1a64>
		0000000000001a64:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    1a68:      	mov	x10, x28
    1a6c:      	and	x8, x10, #0xffffffffffff
    1a70:      	and	x12, x10, #0xffff000000000000
    1a74:      	cmp	x12, x22
    1a78:      	b.ne	0x1ad8 <ltmp0+0x1ad8>
    1a7c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		0000000000001a7c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    1a80:      	ldr	x9, [x9]
		0000000000001a80:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    1a84:      	ldr	x9, [x9]
    1a88:      	cbnz	x9, 0x1ad8 <ltmp0+0x1ad8>
    1a8c:      	sub	x9, x8, #0x100, lsl #12 ; =0x100000
    1a90:      	cmp	x9, x23
    1a94:      	b.hs	0x1ad8 <ltmp0+0x1ad8>
    1a98:      	fcmp	d8, d11
    1a9c:      	b.pl	0x1ad8 <ltmp0+0x1ad8>
    1aa0:      	fcmp	d8, #0.0
    1aa4:      	b.lt	0x1ad8 <ltmp0+0x1ad8>
    1aa8:      	ldurb	w9, [x8, #-0x8]
    1aac:      	cmp	w9, #0xb
    1ab0:      	b.ne	0x1ad8 <ltmp0+0x1ad8>
    1ab4:      	ldrb	w11, [x8, #0x8]
    1ab8:      	cmp	w11, #0x9
    1abc:      	b.hs	0x1ad8 <ltmp0+0x1ad8>
    1ac0:      	fcvtzs	x9, d8
    1ac4:      	scvtf	d0, x9
    1ac8:      	ldr	w13, [x8]
    1acc:      	fcmp	d8, d0
    1ad0:      	ccmp	x9, x13, #0x2, eq
    1ad4:      	b.lo	0x1b8c <ltmp0+0x1b8c>
    1ad8:      	cmp	x12, x22
    1adc:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1ae0:      	fcmp	d8, #0.0
    1ae4:      	b.lt	0x1e80 <ltmp0+0x1e80>
    1ae8:      	fcmp	d8, d9
    1aec:      	b.pl	0x1e80 <ltmp0+0x1e80>
    1af0:      	mov	x9, #-0x20000000000     ; =-2199023255552
    1af4:      	add	x9, x8, x9
    1af8:      	lsr	x9, x9, #41
    1afc:      	cmp	x9, #0x3f
    1b00:      	b.hs	0x1e80 <ltmp0+0x1e80>
    1b04:      	fcvtzs	x9, d8
    1b08:      	scvtf	d0, x9
    1b0c:      	fcmp	d8, d0
    1b10:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1b14:      	ldursb	w11, [x8, #-0x7]
    1b18:      	tbnz	w11, #0x1f, 0x1e80 <ltmp0+0x1e80>
    1b1c:      	ldurb	w11, [x8, #-0x8]
    1b20:      	cmp	w11, #0x9
    1b24:      	b.eq	0x1c24 <ltmp0+0x1c24>
    1b28:      	cmp	w11, #0x2
    1b2c:      	b.eq	0x1bd4 <ltmp0+0x1bd4>
    1b30:      	cmp	w11, #0x1
    1b34:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1b38:      	ldr	w10, [x8]
    1b3c:      	mov	x11, x8
    1b40:      	ldurh	w13, [x8, #-0x6]
    1b44:      	adrp	x12, 0x1000 <ltmp0+0x1000>
		0000000000001b44:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    1b48:      	ldr	x12, [x12]
		0000000000001b48:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    1b4c:      	ldrb	w12, [x12]
    1b50:      	ldr	w8, [x8, #0x4]
    1b54:      	cmp	x10, x8
    1b58:      	b.hi	0x1e80 <ltmp0+0x1e80>
    1b5c:      	tbnz	w13, #0xa, 0x1e80 <ltmp0+0x1e80>
    1b60:      	cbnz	w12, 0x1e80 <ltmp0+0x1e80>
    1b64:      	cmp	x9, x10
    1b68:      	b.hs	0x1e80 <ltmp0+0x1e80>
    1b6c:      	add	x8, x11, x9, lsl #3
    1b70:      	ldr	d0, [x8, #0x8]
    1b74:      	fmov	x8, d0
    1b78:      	mov	x9, #0x10               ; =16
    1b7c:      	movk	x9, #0x7ffc, lsl #48
    1b80:      	cmp	x8, x9
    1b84:      	fcsel	d0, d10, d0, eq
    1b88:      	b	0x1ea0 <ltmp0+0x1ea0>
    1b8c:      	add	x8, x8, #0x10
    1b90:      	cmp	w11, #0x3
    1b94:      	b.le	0x1bb8 <ltmp0+0x1bb8>
    1b98:      	cmp	w11, #0x5
    1b9c:      	b.gt	0x1c70 <ltmp0+0x1c70>
    1ba0:      	cmp	w11, #0x4
    1ba4:      	b.eq	0x1d3c <ltmp0+0x1d3c>
    1ba8:      	cmp	w11, #0x5
    1bac:      	b.ne	0x1d30 <ltmp0+0x1d30>
    1bb0:      	ldr	s0, [x8, x9, lsl #2]
    1bb4:      	b	0x1d34 <ltmp0+0x1d34>
    1bb8:      	cbz	w11, 0x1d28 <ltmp0+0x1d28>
    1bbc:      	cmp	w11, #0x2
    1bc0:      	b.eq	0x1d50 <ltmp0+0x1d50>
    1bc4:      	cmp	w11, #0x3
    1bc8:      	b.ne	0x1d30 <ltmp0+0x1d30>
    1bcc:      	ldr	h0, [x8, x9, lsl #1]
    1bd0:      	b	0x1d34 <ltmp0+0x1d34>
    1bd4:      	ldr	x10, [x8, #0x8]
    1bd8:      	cbz	x10, 0x1c88 <ltmp0+0x1c88>
    1bdc:      	ldr	x11, [x10, #0x60]
    1be0:      	cbz	x11, 0x1c88 <ltmp0+0x1c88>
    1be4:      	ldurb	w8, [x11, #-0x8]
    1be8:      	cmp	w8, #0x1
    1bec:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1bf0:      	ldursb	w8, [x11, #-0x7]
    1bf4:      	tbnz	w8, #0x1f, 0x1e80 <ltmp0+0x1e80>
    1bf8:      	ldr	w8, [x11]
    1bfc:      	cmp	x9, x8
    1c00:      	b.hs	0x1e80 <ltmp0+0x1e80>
    1c04:      	add	x8, x11, x9, lsl #3
    1c08:      	ldr	d0, [x8, #0x8]
    1c0c:      	fmov	x8, d0
    1c10:      	mov	x9, #0x10               ; =16
    1c14:      	movk	x9, #0x7ffc, lsl #48
    1c18:      	cmp	x8, x9
    1c1c:      	b.eq	0x1e80 <ltmp0+0x1e80>
    1c20:      	b	0x1ea0 <ltmp0+0x1ea0>
    1c24:      	ldr	w12, [x8, #0x4]
    1c28:      	ldr	x11, [x8, #0x20]
    1c2c:      	ldurh	w13, [x8, #-0x6]
    1c30:      	tst	w13, #0xc00
    1c34:      	mov	w13, #0x5841            ; =22593
    1c38:      	movk	w13, #0x4c5a, lsl #16
    1c3c:      	ccmp	w12, w13, #0x0, eq
    1c40:      	cset	w12, eq
    1c44:      	cbz	x11, 0x1cf0 <ltmp0+0x1cf0>
    1c48:      	tbz	w12, #0x0, 0x1cf0 <ltmp0+0x1cf0>
    1c4c:      	ldurb	w10, [x11, #-0x8]
    1c50:      	cmp	w10, #0x1
    1c54:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1c58:      	ldursb	w10, [x11, #-0x7]
    1c5c:      	tbnz	w10, #0x1f, 0x1e80 <ltmp0+0x1e80>
    1c60:      	ldr	w10, [x11]
    1c64:      	str	w10, [x8]
    1c68:      	mov	x8, x11
    1c6c:      	b	0x1b40 <ltmp0+0x1b40>
    1c70:      	cmp	w11, #0x6
    1c74:      	b.eq	0x1d44 <ltmp0+0x1d44>
    1c78:      	cmp	w11, #0x7
    1c7c:      	b.ne	0x1d30 <ltmp0+0x1d30>
    1c80:      	ldr	d0, [x8, x9, lsl #3]
    1c84:      	b	0x1ea0 <ltmp0+0x1ea0>
    1c88:      	adrp	x12, 0x1000 <ltmp0+0x1000>
		0000000000001c88:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__9
    1c8c:      	add	x12, x12, #0x0
		0000000000001c8c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__9
    1c90:      	ldr	x11, [x12]
    1c94:      	cmp	x11, #0x0
    1c98:      	csel	x12, x12, x11, eq
    1c9c:      	ldr	x12, [x12]
    1ca0:      	cbz	x12, 0x1e80 <ltmp0+0x1e80>
    1ca4:      	tbnz	x12, #0x3f, 0x1d5c <ltmp0+0x1d5c>
    1ca8:      	ldp	w14, w13, [x8]
    1cac:      	orr	x13, x13, x14, lsl #32
    1cb0:      	cmp	x13, x12
    1cb4:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1cb8:      	ldp	x14, x12, [x11, #0x8]
    1cbc:      	ldp	x13, x11, [x11, #0x18]
    1cc0:      	cmp	x14, x11
    1cc4:      	b.lo	0x1d7c <ltmp0+0x1d7c>
    1cc8:      	cbz	x10, 0x1e80 <ltmp0+0x1e80>
    1ccc:      	b	0x1dc8 <ltmp0+0x1dc8>
    1cd0:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		0000000000001cd0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    1cd4:      	ldr	x8, [x8]
		0000000000001cd4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    1cd8:      	str	x24, [sp, #0x18]
    1cdc:      	and	x1, x8, #0xffffffffffff
    1ce0:      	adrp	x3, 0x1000 <ltmp0+0x1000>
		0000000000001ce0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__8
    1ce4:      	add	x3, x3, #0x0
		0000000000001ce4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__8
    1ce8:      	bl	0x1ce8 <ltmp0+0x1ce8>
		0000000000001ce8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    1cec:      	b	0x19f0 <ltmp0+0x19f0>
    1cf0:      	cmp	x11, #0x0
    1cf4:      	ldr	w14, [x8]
    1cf8:      	ldp	x11, x13, [x8, #0x28]
    1cfc:      	ccmp	x9, x14, #0x2, eq
    1d00:      	ccmp	x11, #0x0, #0x4, lo
    1d04:      	ccmp	x13, #0x0, #0x4, ne
    1d08:      	csel	w12, wzr, w12, eq
    1d0c:      	tbz	w12, #0x0, 0x1e80 <ltmp0+0x1e80>
    1d10:      	lsr	x12, x9, #6
    1d14:      	ldr	x12, [x13, x12, lsl #3]
    1d18:      	lsr	x12, x12, x9
    1d1c:      	tbz	w12, #0x0, 0x1d88 <ltmp0+0x1d88>
    1d20:      	ldr	d0, [x11, x9, lsl #3]
    1d24:      	b	0x1ea0 <ltmp0+0x1ea0>
    1d28:      	ldrsb	w8, [x8, x9]
    1d2c:      	b	0x1d54 <ltmp0+0x1d54>
    1d30:      	ldr	b0, [x8, x9]
    1d34:      	ucvtf	d0, d0
    1d38:      	b	0x1ea0 <ltmp0+0x1ea0>
    1d3c:      	ldr	w8, [x8, x9, lsl #2]
    1d40:      	b	0x1d54 <ltmp0+0x1d54>
    1d44:      	ldr	s0, [x8, x9, lsl #2]
    1d48:      	fcvt	d0, s0
    1d4c:      	b	0x1ea0 <ltmp0+0x1ea0>
    1d50:      	ldrsh	w8, [x8, x9, lsl #1]
    1d54:      	scvtf	d0, w8
    1d58:      	b	0x1ea0 <ltmp0+0x1ea0>
    1d5c:      	cbz	x10, 0x1e80 <ltmp0+0x1e80>
    1d60:      	ldr	x13, [x10, #0x30]
    1d64:      	cmp	x13, x12
    1d68:      	b.ne	0x1e80 <ltmp0+0x1e80>
    1d6c:      	ldp	x14, x12, [x11, #0x8]
    1d70:      	ldp	x13, x11, [x11, #0x18]
    1d74:      	cmp	x14, x11
    1d78:      	b.hs	0x1dc8 <ltmp0+0x1dc8>
    1d7c:      	add	x14, x8, x14, lsl #3
    1d80:      	add	x14, x14, #0x10
    1d84:      	b	0x1dec <ltmp0+0x1dec>
    1d88:      	ldr	x8, [x8, #0x50]
    1d8c:      	mov	x12, #0x6e05            ; =28165
    1d90:      	movk	x12, #0x6d61, lsl #16
    1d94:      	movk	x12, #0x65, lsl #32
    1d98:      	cmp	x8, x12
    1d9c:      	b.eq	0x1da4 <ltmp0+0x1da4>
    1da0:      	cbnz	x8, 0x1e80 <ltmp0+0x1e80>
    1da4:      	cmp	x8, x12
    1da8:      	b.ne	0x1e54 <ltmp0+0x1e54>
    1dac:      	ldr	x8, [x11, x9, lsl #3]
    1db0:      	cbz	x8, 0x1e54 <ltmp0+0x1e54>
    1db4:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    1db8:      	cmp	x8, x9
    1dbc:      	csel	x8, xzr, x8, eq
    1dc0:      	fmov	d0, x8
    1dc4:      	b	0x2090 <ltmp0+0x2090>
    1dc8:      	ldr	x16, [x10, #0x20]
    1dcc:      	cmp	x16, #0x0
    1dd0:      	csel	x15, x16, x10, ne
    1dd4:      	cbz	x16, 0x1e80 <ltmp0+0x1e80>
    1dd8:      	ldr	w16, [x15]
    1ddc:      	cmp	x14, x16
    1de0:      	b.hs	0x1e80 <ltmp0+0x1e80>
    1de4:      	add	x14, x15, x14, lsl #3
    1de8:      	add	x14, x14, #0x8
    1dec:      	ldr	d0, [x14]
    1df0:      	fcmp	d8, d0
    1df4:      	ccmp	x13, x9, #0x0, mi
    1df8:      	cset	w13, hi
    1dfc:      	add	x9, x12, x9
    1e00:      	cmp	x9, x11
    1e04:      	b.hs	0x1e18 <ltmp0+0x1e18>
    1e08:      	cbz	w13, 0x1e18 <ltmp0+0x1e18>
    1e0c:      	add	x8, x8, x9, lsl #3
    1e10:      	ldr	d0, [x8, #0x10]
    1e14:      	b	0x1ea0 <ltmp0+0x1ea0>
    1e18:      	cbz	x10, 0x1e80 <ltmp0+0x1e80>
    1e1c:      	cmp	x9, x11
    1e20:      	b.lo	0x1e80 <ltmp0+0x1e80>
    1e24:      	eor	w8, w13, #0x1
    1e28:      	tbnz	w8, #0x0, 0x1e80 <ltmp0+0x1e80>
    1e2c:      	ldr	x11, [x10, #0x20]
    1e30:      	cmp	x11, #0x0
    1e34:      	csel	x8, x11, x10, ne
    1e38:      	cbz	x11, 0x1e80 <ltmp0+0x1e80>
    1e3c:      	ldr	w10, [x8]
    1e40:      	cmp	x9, x10
    1e44:      	b.hs	0x1e80 <ltmp0+0x1e80>
    1e48:      	add	x8, x8, x9, lsl #3
    1e4c:      	ldr	d0, [x8, #0x8]
    1e50:      	b	0x1ea0 <ltmp0+0x1ea0>
    1e54:      	fmov	d0, x10
    1e58:      	mov.16b	v1, v8
    1e5c:      	adrp	x0, 0x1000 <ltmp0+0x1000>
		0000000000001e5c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.4.bytes
    1e60:      	add	x0, x0, #0x0
		0000000000001e60:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.4.bytes
    1e64:      	mov	w1, #0x4                ; =4
    1e68:      	bl	0x1e68 <ltmp0+0x1e68>
		0000000000001e68:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    1e6c:      	fmov	x8, d0
    1e70:      	mov	x9, #0x10               ; =16
    1e74:      	movk	x9, #0x7ffc, lsl #48
    1e78:      	cmp	x8, x9
    1e7c:      	b.ne	0x2090 <ltmp0+0x2090>
    1e80:      	fmov	d0, x28
    1e84:      	str	x24, [sp, #0x18]
    1e88:      	mov.16b	v1, v8
    1e8c:      	adrp	x0, 0x1000 <ltmp0+0x1000>
		0000000000001e8c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__9
    1e90:      	add	x0, x0, #0x0
		0000000000001e90:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__9
    1e94:      	bl	0x1e94 <ltmp0+0x1e94>
		0000000000001e94:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    1e98:      	ldp	x28, x19, [sp, #0x8]
    1e9c:      	ldr	x24, [sp, #0x18]
    1ea0:      	fmov	x8, d0
    1ea4:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    1ea8:      	and	x9, x8, x9
    1eac:      	cmp	x9, x22
    1eb0:      	b.ne	0x1f20 <ltmp0+0x1f20>
    1eb4:      	and	x0, x8, #0xffffffffffff
    1eb8:      	lsr	x8, x0, #20
    1ebc:      	cbz	x8, 0x206c <ltmp0+0x206c>
    1ec0:      	ldurb	w9, [x0, #-0x8]
    1ec4:      	adrp	x8, 0x1000 <ltmp0+0x1000>
		0000000000001ec4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__11
    1ec8:      	ldr	x8, [x8]
		0000000000001ec8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__11
    1ecc:      	cbz	x8, 0x1f90 <ltmp0+0x1f90>
    1ed0:      	cmp	w9, #0x2
    1ed4:      	b.ne	0x1f90 <ltmp0+0x1f90>
    1ed8:      	ldurh	w10, [x0, #-0x6]
    1edc:      	tbnz	w10, #0xb, 0x1f90 <ltmp0+0x1f90>
    1ee0:      	ldr	w10, [x0, #0x4]
    1ee4:      	orr	x9, x10, #0x4000000000000000
    1ee8:      	cbz	w10, 0x1fbc <ltmp0+0x1fbc>
    1eec:      	ldr	x11, [x8]
    1ef0:      	cmp	x9, x11
    1ef4:      	b.ne	0x1fbc <ltmp0+0x1fbc>
    1ef8:      	ldr	x2, [x8, #0x8]
    1efc:      	tbnz	w2, #0x1e, 0x23d4 <ltmp0+0x23d4>
    1f00:      	add	x11, x0, x2, lsl #3
    1f04:      	ldr	d0, [x11, #0x10]
    1f08:      	fmov	x11, d0
    1f0c:      	mov	x12, #0x10              ; =16
    1f10:      	movk	x12, #0x7ffc, lsl #48
    1f14:      	cmp	x11, x12
    1f18:      	b.ne	0x2090 <ltmp0+0x2090>
    1f1c:      	b	0x1fe8 <ltmp0+0x1fe8>
    1f20:      	lsr	x9, x8, #48
    1f24:      	mov	w10, #0x7ff9            ; =32761
    1f28:      	cmp	x9, x10
    1f2c:      	b.eq	0x1f74 <ltmp0+0x1f74>
    1f30:      	mov	w10, #0x7ffe            ; =32766
    1f34:      	cmp	w9, w10
    1f38:      	b.ne	0x1f64 <ltmp0+0x1f64>
    1f3c:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		0000000000001f3c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    1f40:      	ldr	x9, [x9]
		0000000000001f40:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    1f44:      	str	x24, [sp, #0x18]
    1f48:      	and	x2, x9, #0xffffffffffff
    1f4c:      	mov	x0, #0xa                ; =10
    1f50:      	movk	x0, #0xddae, lsl #32
    1f54:      	movk	x0, #0x5556, lsl #48
    1f58:      	mov	x1, x8
    1f5c:      	bl	0x1f5c <ltmp0+0x1f5c>
		0000000000001f5c:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    1f60:      	b	0x2088 <ltmp0+0x2088>
    1f64:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    1f68:      	add	x9, x8, x9
    1f6c:      	cmp	x9, #0x2
    1f70:      	b.lo	0x304c <ltmp0+0x304c>
    1f74:      	adrp	x9, 0x1000 <ltmp0+0x1000>
		0000000000001f74:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    1f78:      	ldr	x9, [x9]
		0000000000001f78:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    1f7c:      	str	x24, [sp, #0x18]
    1f80:      	and	x1, x9, #0xffffffffffff
    1f84:      	mov	x0, x8
    1f88:      	bl	0x1f88 <ltmp0+0x1f88>
		0000000000001f88:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    1f8c:      	b	0x2088 <ltmp0+0x2088>
    1f90:      	cmp	w9, #0x2
    1f94:      	b.ne	0x206c <ltmp0+0x206c>
    1f98:      	cbz	x8, 0x206c <ltmp0+0x206c>
    1f9c:      	ldr	x9, [x8, #0x10]
    1fa0:      	cbz	x9, 0x206c <ltmp0+0x206c>
    1fa4:      	ldr	x10, [x0, #0x8]
    1fa8:      	cbz	x10, 0x206c <ltmp0+0x206c>
    1fac:      	ldr	x10, [x10, #0x30]
    1fb0:      	cmp	x10, x9
    1fb4:      	b.eq	0x1fd8 <ltmp0+0x1fd8>
    1fb8:      	b	0x206c <ltmp0+0x206c>
    1fbc:      	ldr	x11, [x8, #0x10]
    1fc0:      	cbz	x11, 0x1fe8 <ltmp0+0x1fe8>
    1fc4:      	ldr	x12, [x0, #0x8]
    1fc8:      	cbz	x12, 0x1fe8 <ltmp0+0x1fe8>
    1fcc:      	ldr	x12, [x12, #0x30]
    1fd0:      	cmp	x12, x11
    1fd4:      	b.ne	0x1fe8 <ltmp0+0x1fe8>
    1fd8:      	ldr	x8, [x8, #0x8]
    1fdc:      	add	x8, x0, x8, lsl #3
    1fe0:      	ldr	d0, [x8, #0x10]
    1fe4:      	b	0x2090 <ltmp0+0x2090>
    1fe8:      	ldr	x11, [x8, #0x18]
    1fec:      	cmp	x11, #0x0
    1ff0:      	b.le	0x206c <ltmp0+0x206c>
    1ff4:      	ldr	x11, [x8, #0x20]
    1ff8:      	ldr	x12, [x8, #0x30]
    1ffc:      	ldr	x13, [x8, #0x40]
    2000:      	cmp	x13, x9
    2004:      	ldr	x14, [x8, #0x50]
    2008:      	ccmp	x14, x9, #0x4, ne
    200c:      	ccmp	x12, x9, #0x4, ne
    2010:      	ccmp	x11, x9, #0x4, ne
    2014:      	cset	w15, eq
    2018:      	cbz	w10, 0x206c <ltmp0+0x206c>
    201c:      	cbz	w15, 0x206c <ltmp0+0x206c>
    2020:      	ldr	x10, [x8, #0x48]
    2024:      	ldr	x15, [x8, #0x58]
    2028:      	cmp	x14, x9
    202c:      	csel	x14, x15, xzr, eq
    2030:      	cmp	x13, x9
    2034:      	csel	x10, x10, x14, eq
    2038:      	ldr	x13, [x8, #0x28]
    203c:      	ldr	x8, [x8, #0x38]
    2040:      	cmp	x12, x9
    2044:      	csel	x8, x8, x10, eq
    2048:      	cmp	x11, x9
    204c:      	csel	x8, x13, x8, eq
    2050:      	add	x8, x0, x8, lsl #3
    2054:      	ldr	d0, [x8, #0x10]
    2058:      	fmov	x8, d0
    205c:      	mov	x9, #0x10               ; =16
    2060:      	movk	x9, #0x7ffc, lsl #48
    2064:      	cmp	x8, x9
    2068:      	b.ne	0x2090 <ltmp0+0x2090>
    206c:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		000000000000206c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    2070:      	ldr	x8, [x8]
		0000000000002070:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    2074:      	str	x24, [sp, #0x18]
    2078:      	and	x1, x8, #0xffffffffffff
    207c:      	adrp	x2, 0x2000 <ltmp0+0x2000>
		000000000000207c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__11
    2080:      	add	x2, x2, #0x0
		0000000000002080:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__11
    2084:      	bl	0x2084 <ltmp0+0x2084>
		0000000000002084:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    2088:      	ldp	x28, x19, [sp, #0x8]
    208c:      	ldr	x24, [sp, #0x18]
    2090:      	fmov	x8, d0
    2094:      	lsr	x9, x8, #48
    2098:      	mov	w10, #0x7ff9            ; =32761
    209c:      	cmp	x9, x10
    20a0:      	b.eq	0x20d0 <ltmp0+0x20d0>
    20a4:      	mov	w10, #0x7fff            ; =32767
    20a8:      	cmp	w9, w10
    20ac:      	b.ne	0x20dc <ltmp0+0x20dc>
    20b0:      	and	x9, x8, #0xffffffffffff
    20b4:      	tst	x8, #0xfffffffff000
    20b8:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		00000000000020b8:  ARM64_RELOC_PAGE21	_perry_null_guard_zero_access_worker_ts
    20bc:      	add	x8, x8, #0x0
		00000000000020bc:  ARM64_RELOC_PAGEOFF12	_perry_null_guard_zero_access_worker_ts
    20c0:      	csel	x8, x8, x9, eq
    20c4:      	ldr	s0, [x8]
    20c8:      	ucvtf	d1, d0
    20cc:      	b	0x20f0 <ltmp0+0x20f0>
    20d0:      	ubfx	x8, x8, #40, #8
    20d4:      	ucvtf	d1, x8
    20d8:      	b	0x20f0 <ltmp0+0x20f0>
    20dc:      	str	x24, [sp, #0x18]
    20e0:      	bl	0x20e0 <ltmp0+0x20e0>
		00000000000020e0:  ARM64_RELOC_BRANCH26	_js_value_length_property_f64
    20e4:      	mov.16b	v1, v0
    20e8:      	ldp	x28, x19, [sp, #0x8]
    20ec:      	ldr	x24, [sp, #0x18]
    20f0:      	fmov	d0, x24
    20f4:      	and	x9, x24, #0xffff000000000000
    20f8:      	fmov	x8, d1
    20fc:      	and	x10, x8, #0xffff000000000000
    2100:      	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
    2104:      	cmp	x8, x11
    2108:      	ccmp	x10, x26, #0x2, hs
    210c:      	cset	w8, hi
    2110:      	mov	x10, #0x1               ; =1
    2114:      	movk	x10, #0x7fff, lsl #48
    2118:      	cmp	x9, x10
    211c:      	ccmp	x24, x20, #0x0, lo
    2120:      	b.hi	0x2130 <ltmp0+0x2130>
    2124:      	cbz	w8, 0x2130 <ltmp0+0x2130>
    2128:      	fadd	d0, d1, d0
    212c:      	b	0x213c <ltmp0+0x213c>
    2130:      	stp	x19, x28, [sp, #0x10]
    2134:      	bl	0x2134 <ltmp0+0x2134>
		0000000000002134:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    2138:      	ldp	x19, x28, [sp, #0x10]
    213c:      	fmov	x24, d0
    2140:      	mov	x0, x24
    2144:      	ldr	w8, [x27]
    2148:      	cbz	w8, 0x2150 <ltmp0+0x2150>
    214c:      	bl	0x214c <ltmp0+0x214c>
		000000000000214c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    2150:      	mov	x0, x24
    2154:      	ldr	w8, [x27]
    2158:      	cbz	w8, 0x2160 <ltmp0+0x2160>
    215c:      	bl	0x215c <ltmp0+0x215c>
		000000000000215c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    2160:      	mov	x10, x28
    2164:      	and	x8, x10, #0xffffffffffff
    2168:      	and	x12, x10, #0xffff000000000000
    216c:      	cmp	x12, x22
    2170:      	b.ne	0x2208 <ltmp0+0x2208>
    2174:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		0000000000002174:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    2178:      	ldr	x9, [x9]
		0000000000002178:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    217c:      	ldr	x9, [x9]
    2180:      	cbnz	x9, 0x2208 <ltmp0+0x2208>
    2184:      	sub	x9, x8, #0x100, lsl #12 ; =0x100000
    2188:      	cmp	x9, x23
    218c:      	b.hs	0x2208 <ltmp0+0x2208>
    2190:      	mov	x9, #0x41f0000000000000 ; =4751297606875873280
    2194:      	fmov	d0, x9
    2198:      	fcmp	d8, d0
    219c:      	b.pl	0x2208 <ltmp0+0x2208>
    21a0:      	fcmp	d8, #0.0
    21a4:      	b.lt	0x2208 <ltmp0+0x2208>
    21a8:      	ldurb	w9, [x8, #-0x8]
    21ac:      	cmp	w9, #0xb
    21b0:      	b.ne	0x2208 <ltmp0+0x2208>
    21b4:      	ldrb	w11, [x8, #0x8]
    21b8:      	cmp	w11, #0x9
    21bc:      	b.hs	0x2208 <ltmp0+0x2208>
    21c0:      	fcvtzs	x9, d8
    21c4:      	scvtf	d0, x9
    21c8:      	fcmp	d8, d0
    21cc:      	b.ne	0x2208 <ltmp0+0x2208>
    21d0:      	ldr	w13, [x8]
    21d4:      	cmp	x9, x13
    21d8:      	b.hs	0x2208 <ltmp0+0x2208>
    21dc:      	add	x8, x8, #0x10
    21e0:      	cmp	w11, #0x3
    21e4:      	b.le	0x22bc <ltmp0+0x22bc>
    21e8:      	cmp	w11, #0x5
    21ec:      	b.gt	0x2374 <ltmp0+0x2374>
    21f0:      	cmp	w11, #0x4
    21f4:      	b.eq	0x2440 <ltmp0+0x2440>
    21f8:      	cmp	w11, #0x5
    21fc:      	b.ne	0x2434 <ltmp0+0x2434>
    2200:      	ldr	s0, [x8, x9, lsl #2]
    2204:      	b	0x2438 <ltmp0+0x2438>
    2208:      	cmp	x12, x22
    220c:      	b.ne	0x2588 <ltmp0+0x2588>
    2210:      	fcmp	d8, #0.0
    2214:      	b.lt	0x2588 <ltmp0+0x2588>
    2218:      	fcmp	d8, d9
    221c:      	b.pl	0x2588 <ltmp0+0x2588>
    2220:      	mov	x9, #-0x20000000000     ; =-2199023255552
    2224:      	add	x9, x8, x9
    2228:      	lsr	x9, x9, #41
    222c:      	cmp	x9, #0x3f
    2230:      	b.hs	0x2588 <ltmp0+0x2588>
    2234:      	fcvtzs	x9, d8
    2238:      	scvtf	d0, x9
    223c:      	fcmp	d8, d0
    2240:      	b.ne	0x2588 <ltmp0+0x2588>
    2244:      	ldursb	w11, [x8, #-0x7]
    2248:      	tbnz	w11, #0x1f, 0x2588 <ltmp0+0x2588>
    224c:      	ldurb	w11, [x8, #-0x8]
    2250:      	cmp	w11, #0x9
    2254:      	b.eq	0x2328 <ltmp0+0x2328>
    2258:      	cmp	w11, #0x2
    225c:      	b.eq	0x22d8 <ltmp0+0x22d8>
    2260:      	cmp	w11, #0x1
    2264:      	b.ne	0x2588 <ltmp0+0x2588>
    2268:      	ldr	w10, [x8]
    226c:      	mov	x11, x8
    2270:      	ldurh	w13, [x8, #-0x6]
    2274:      	adrp	x12, 0x2000 <ltmp0+0x2000>
		0000000000002274:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    2278:      	ldr	x12, [x12]
		0000000000002278:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    227c:      	ldrb	w12, [x12]
    2280:      	ldr	w8, [x8, #0x4]
    2284:      	cmp	x10, x8
    2288:      	b.hi	0x2588 <ltmp0+0x2588>
    228c:      	tbnz	w13, #0xa, 0x2588 <ltmp0+0x2588>
    2290:      	cbnz	w12, 0x2588 <ltmp0+0x2588>
    2294:      	cmp	x9, x10
    2298:      	b.hs	0x2588 <ltmp0+0x2588>
    229c:      	add	x8, x11, x9, lsl #3
    22a0:      	ldr	d0, [x8, #0x8]
    22a4:      	fmov	x8, d0
    22a8:      	mov	x9, #0x10               ; =16
    22ac:      	movk	x9, #0x7ffc, lsl #48
    22b0:      	cmp	x8, x9
    22b4:      	fcsel	d0, d10, d0, eq
    22b8:      	b	0x25b0 <ltmp0+0x25b0>
    22bc:      	cbz	w11, 0x242c <ltmp0+0x242c>
    22c0:      	cmp	w11, #0x2
    22c4:      	b.eq	0x2454 <ltmp0+0x2454>
    22c8:      	cmp	w11, #0x3
    22cc:      	b.ne	0x2434 <ltmp0+0x2434>
    22d0:      	ldr	h0, [x8, x9, lsl #1]
    22d4:      	b	0x2438 <ltmp0+0x2438>
    22d8:      	ldr	x10, [x8, #0x8]
    22dc:      	cbz	x10, 0x238c <ltmp0+0x238c>
    22e0:      	ldr	x11, [x10, #0x60]
    22e4:      	cbz	x11, 0x238c <ltmp0+0x238c>
    22e8:      	ldurb	w8, [x11, #-0x8]
    22ec:      	cmp	w8, #0x1
    22f0:      	b.ne	0x2588 <ltmp0+0x2588>
    22f4:      	ldursb	w8, [x11, #-0x7]
    22f8:      	tbnz	w8, #0x1f, 0x2588 <ltmp0+0x2588>
    22fc:      	ldr	w8, [x11]
    2300:      	cmp	x9, x8
    2304:      	b.hs	0x2588 <ltmp0+0x2588>
    2308:      	add	x8, x11, x9, lsl #3
    230c:      	ldr	d0, [x8, #0x8]
    2310:      	fmov	x8, d0
    2314:      	mov	x9, #0x10               ; =16
    2318:      	movk	x9, #0x7ffc, lsl #48
    231c:      	cmp	x8, x9
    2320:      	b.eq	0x2588 <ltmp0+0x2588>
    2324:      	b	0x25b0 <ltmp0+0x25b0>
    2328:      	ldr	w12, [x8, #0x4]
    232c:      	ldr	x11, [x8, #0x20]
    2330:      	ldurh	w13, [x8, #-0x6]
    2334:      	tst	w13, #0xc00
    2338:      	mov	w13, #0x5841            ; =22593
    233c:      	movk	w13, #0x4c5a, lsl #16
    2340:      	ccmp	w12, w13, #0x0, eq
    2344:      	cset	w12, eq
    2348:      	cbz	x11, 0x23f4 <ltmp0+0x23f4>
    234c:      	tbz	w12, #0x0, 0x23f4 <ltmp0+0x23f4>
    2350:      	ldurb	w10, [x11, #-0x8]
    2354:      	cmp	w10, #0x1
    2358:      	b.ne	0x2588 <ltmp0+0x2588>
    235c:      	ldursb	w10, [x11, #-0x7]
    2360:      	tbnz	w10, #0x1f, 0x2588 <ltmp0+0x2588>
    2364:      	ldr	w10, [x11]
    2368:      	str	w10, [x8]
    236c:      	mov	x8, x11
    2370:      	b	0x2270 <ltmp0+0x2270>
    2374:      	cmp	w11, #0x6
    2378:      	b.eq	0x2448 <ltmp0+0x2448>
    237c:      	cmp	w11, #0x7
    2380:      	b.ne	0x2434 <ltmp0+0x2434>
    2384:      	ldr	d0, [x8, x9, lsl #3]
    2388:      	b	0x25b0 <ltmp0+0x25b0>
    238c:      	adrp	x12, 0x2000 <ltmp0+0x2000>
		000000000000238c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__12
    2390:      	add	x12, x12, #0x0
		0000000000002390:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__12
    2394:      	ldr	x11, [x12]
    2398:      	cmp	x11, #0x0
    239c:      	csel	x12, x12, x11, eq
    23a0:      	ldr	x12, [x12]
    23a4:      	cbz	x12, 0x2588 <ltmp0+0x2588>
    23a8:      	tbnz	x12, #0x3f, 0x2460 <ltmp0+0x2460>
    23ac:      	ldp	w14, w13, [x8]
    23b0:      	orr	x13, x13, x14, lsl #32
    23b4:      	cmp	x13, x12
    23b8:      	b.ne	0x2588 <ltmp0+0x2588>
    23bc:      	ldp	x14, x12, [x11, #0x8]
    23c0:      	ldp	x13, x11, [x11, #0x18]
    23c4:      	cmp	x14, x11
    23c8:      	b.lo	0x2480 <ltmp0+0x2480>
    23cc:      	cbz	x10, 0x2588 <ltmp0+0x2588>
    23d0:      	b	0x24d0 <ltmp0+0x24d0>
    23d4:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		00000000000023d4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    23d8:      	ldr	x8, [x8]
		00000000000023d8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    23dc:      	str	x24, [sp, #0x18]
    23e0:      	and	x1, x8, #0xffffffffffff
    23e4:      	adrp	x3, 0x2000 <ltmp0+0x2000>
		00000000000023e4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__11
    23e8:      	add	x3, x3, #0x0
		00000000000023e8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__11
    23ec:      	bl	0x23ec <ltmp0+0x23ec>
		00000000000023ec:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    23f0:      	b	0x2088 <ltmp0+0x2088>
    23f4:      	cmp	x11, #0x0
    23f8:      	ldr	w14, [x8]
    23fc:      	ldp	x11, x13, [x8, #0x28]
    2400:      	ccmp	x9, x14, #0x2, eq
    2404:      	ccmp	x11, #0x0, #0x4, lo
    2408:      	ccmp	x13, #0x0, #0x4, ne
    240c:      	csel	w12, wzr, w12, eq
    2410:      	tbz	w12, #0x0, 0x2588 <ltmp0+0x2588>
    2414:      	lsr	x12, x9, #6
    2418:      	ldr	x12, [x13, x12, lsl #3]
    241c:      	lsr	x12, x12, x9
    2420:      	tbz	w12, #0x0, 0x248c <ltmp0+0x248c>
    2424:      	ldr	d0, [x11, x9, lsl #3]
    2428:      	b	0x25b0 <ltmp0+0x25b0>
    242c:      	ldrsb	w8, [x8, x9]
    2430:      	b	0x2458 <ltmp0+0x2458>
    2434:      	ldr	b0, [x8, x9]
    2438:      	ucvtf	d0, d0
    243c:      	b	0x25b0 <ltmp0+0x25b0>
    2440:      	ldr	w8, [x8, x9, lsl #2]
    2444:      	b	0x2458 <ltmp0+0x2458>
    2448:      	ldr	s0, [x8, x9, lsl #2]
    244c:      	fcvt	d0, s0
    2450:      	b	0x25b0 <ltmp0+0x25b0>
    2454:      	ldrsh	w8, [x8, x9, lsl #1]
    2458:      	scvtf	d0, w8
    245c:      	b	0x25b0 <ltmp0+0x25b0>
    2460:      	cbz	x10, 0x2588 <ltmp0+0x2588>
    2464:      	ldr	x13, [x10, #0x30]
    2468:      	cmp	x13, x12
    246c:      	b.ne	0x2588 <ltmp0+0x2588>
    2470:      	ldp	x14, x12, [x11, #0x8]
    2474:      	ldp	x13, x11, [x11, #0x18]
    2478:      	cmp	x14, x11
    247c:      	b.hs	0x24d0 <ltmp0+0x24d0>
    2480:      	add	x14, x8, x14, lsl #3
    2484:      	add	x14, x14, #0x10
    2488:      	b	0x24f4 <ltmp0+0x24f4>
    248c:      	ldr	x8, [x8, #0x50]
    2490:      	mov	x12, #0x6107            ; =24839
    2494:      	movk	x12, #0x7463, lsl #16
    2498:      	movk	x12, #0x7669, lsl #32
    249c:      	movk	x12, #0x65, lsl #48
    24a0:      	cmp	x8, x12
    24a4:      	b.eq	0x24ac <ltmp0+0x24ac>
    24a8:      	cbnz	x8, 0x2588 <ltmp0+0x2588>
    24ac:      	cmp	x8, x12
    24b0:      	b.ne	0x255c <ltmp0+0x255c>
    24b4:      	ldr	x8, [x11, x9, lsl #3]
    24b8:      	cbz	x8, 0x255c <ltmp0+0x255c>
    24bc:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    24c0:      	cmp	x8, x9
    24c4:      	csel	x8, xzr, x8, eq
    24c8:      	fmov	d0, x8
    24cc:      	b	0x27ac <ltmp0+0x27ac>
    24d0:      	ldr	x16, [x10, #0x20]
    24d4:      	cmp	x16, #0x0
    24d8:      	csel	x15, x16, x10, ne
    24dc:      	cbz	x16, 0x2588 <ltmp0+0x2588>
    24e0:      	ldr	w16, [x15]
    24e4:      	cmp	x14, x16
    24e8:      	b.hs	0x2588 <ltmp0+0x2588>
    24ec:      	add	x14, x15, x14, lsl #3
    24f0:      	add	x14, x14, #0x8
    24f4:      	ldr	d0, [x14]
    24f8:      	fcmp	d8, d0
    24fc:      	ccmp	x13, x9, #0x0, mi
    2500:      	cset	w13, hi
    2504:      	add	x9, x12, x9
    2508:      	cmp	x9, x11
    250c:      	b.hs	0x2520 <ltmp0+0x2520>
    2510:      	cbz	w13, 0x2520 <ltmp0+0x2520>
    2514:      	add	x8, x8, x9, lsl #3
    2518:      	ldr	d0, [x8, #0x10]
    251c:      	b	0x25b0 <ltmp0+0x25b0>
    2520:      	cbz	x10, 0x2588 <ltmp0+0x2588>
    2524:      	cmp	x9, x11
    2528:      	b.lo	0x2588 <ltmp0+0x2588>
    252c:      	eor	w8, w13, #0x1
    2530:      	tbnz	w8, #0x0, 0x2588 <ltmp0+0x2588>
    2534:      	ldr	x11, [x10, #0x20]
    2538:      	cmp	x11, #0x0
    253c:      	csel	x8, x11, x10, ne
    2540:      	cbz	x11, 0x2588 <ltmp0+0x2588>
    2544:      	ldr	w10, [x8]
    2548:      	cmp	x9, x10
    254c:      	b.hs	0x2588 <ltmp0+0x2588>
    2550:      	add	x8, x8, x9, lsl #3
    2554:      	ldr	d0, [x8, #0x8]
    2558:      	b	0x25b0 <ltmp0+0x25b0>
    255c:      	fmov	d0, x10
    2560:      	mov.16b	v1, v8
    2564:      	adrp	x0, 0x2000 <ltmp0+0x2000>
		0000000000002564:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.5.bytes
    2568:      	add	x0, x0, #0x0
		0000000000002568:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.5.bytes
    256c:      	mov	w1, #0x6                ; =6
    2570:      	bl	0x2570 <ltmp0+0x2570>
		0000000000002570:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    2574:      	fmov	x8, d0
    2578:      	mov	x9, #0x10               ; =16
    257c:      	movk	x9, #0x7ffc, lsl #48
    2580:      	cmp	x8, x9
    2584:      	b.ne	0x27ac <ltmp0+0x27ac>
    2588:      	mov	x8, x28
    258c:      	stp	x28, x24, [sp, #0x10]
    2590:      	fmov	d0, x8
    2594:      	str	x19, [sp, #0x8]
    2598:      	mov.16b	v1, v8
    259c:      	adrp	x0, 0x2000 <ltmp0+0x2000>
		000000000000259c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__12
    25a0:      	add	x0, x0, #0x0
		00000000000025a0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__12
    25a4:      	bl	0x25a4 <ltmp0+0x25a4>
		00000000000025a4:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    25a8:      	ldp	x19, x28, [sp, #0x8]
    25ac:      	ldr	x24, [sp, #0x18]
    25b0:      	fmov	x8, d0
    25b4:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    25b8:      	and	x9, x8, x9
    25bc:      	cmp	x9, x22
    25c0:      	b.ne	0x2630 <ltmp0+0x2630>
    25c4:      	and	x0, x8, #0xffffffffffff
    25c8:      	lsr	x8, x0, #20
    25cc:      	cbz	x8, 0x2784 <ltmp0+0x2784>
    25d0:      	ldurb	w9, [x0, #-0x8]
    25d4:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		00000000000025d4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__14
    25d8:      	ldr	x8, [x8]
		00000000000025d8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__14
    25dc:      	cbz	x8, 0x26a8 <ltmp0+0x26a8>
    25e0:      	cmp	w9, #0x2
    25e4:      	b.ne	0x26a8 <ltmp0+0x26a8>
    25e8:      	ldurh	w10, [x0, #-0x6]
    25ec:      	tbnz	w10, #0xb, 0x26a8 <ltmp0+0x26a8>
    25f0:      	ldr	w10, [x0, #0x4]
    25f4:      	orr	x9, x10, #0x4000000000000000
    25f8:      	cbz	w10, 0x26d4 <ltmp0+0x26d4>
    25fc:      	ldr	x11, [x8]
    2600:      	cmp	x9, x11
    2604:      	b.ne	0x26d4 <ltmp0+0x26d4>
    2608:      	ldr	x2, [x8, #0x8]
    260c:      	tbnz	w2, #0x1e, 0x28a0 <ltmp0+0x28a0>
    2610:      	add	x11, x0, x2, lsl #3
    2614:      	ldr	d0, [x11, #0x10]
    2618:      	fmov	x11, d0
    261c:      	mov	x12, #0x10              ; =16
    2620:      	movk	x12, #0x7ffc, lsl #48
    2624:      	cmp	x11, x12
    2628:      	b.ne	0x27ac <ltmp0+0x27ac>
    262c:      	b	0x2700 <ltmp0+0x2700>
    2630:      	lsr	x9, x8, #48
    2634:      	mov	w10, #0x7ff9            ; =32761
    2638:      	cmp	x9, x10
    263c:      	b.eq	0x2688 <ltmp0+0x2688>
    2640:      	mov	w10, #0x7ffe            ; =32766
    2644:      	cmp	w9, w10
    2648:      	b.ne	0x2678 <ltmp0+0x2678>
    264c:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		000000000000264c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    2650:      	ldr	x9, [x9]
		0000000000002650:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    2654:      	stp	x28, x24, [sp, #0x10]
    2658:      	str	x19, [sp, #0x8]
    265c:      	and	x2, x9, #0xffffffffffff
    2660:      	mov	x0, #0xd                ; =13
    2664:      	movk	x0, #0xddae, lsl #32
    2668:      	movk	x0, #0x5556, lsl #48
    266c:      	mov	x1, x8
    2670:      	bl	0x2670 <ltmp0+0x2670>
		0000000000002670:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    2674:      	b	0x27a4 <ltmp0+0x27a4>
    2678:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    267c:      	add	x9, x8, x9
    2680:      	cmp	x9, #0x2
    2684:      	b.lo	0x3070 <ltmp0+0x3070>
    2688:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		0000000000002688:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    268c:      	ldr	x9, [x9]
		000000000000268c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    2690:      	stp	x28, x24, [sp, #0x10]
    2694:      	str	x19, [sp, #0x8]
    2698:      	and	x1, x9, #0xffffffffffff
    269c:      	mov	x0, x8
    26a0:      	bl	0x26a0 <ltmp0+0x26a0>
		00000000000026a0:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    26a4:      	b	0x27a4 <ltmp0+0x27a4>
    26a8:      	cmp	w9, #0x2
    26ac:      	b.ne	0x2784 <ltmp0+0x2784>
    26b0:      	cbz	x8, 0x2784 <ltmp0+0x2784>
    26b4:      	ldr	x9, [x8, #0x10]
    26b8:      	cbz	x9, 0x2784 <ltmp0+0x2784>
    26bc:      	ldr	x10, [x0, #0x8]
    26c0:      	cbz	x10, 0x2784 <ltmp0+0x2784>
    26c4:      	ldr	x10, [x10, #0x30]
    26c8:      	cmp	x10, x9
    26cc:      	b.eq	0x26f0 <ltmp0+0x26f0>
    26d0:      	b	0x2784 <ltmp0+0x2784>
    26d4:      	ldr	x11, [x8, #0x10]
    26d8:      	cbz	x11, 0x2700 <ltmp0+0x2700>
    26dc:      	ldr	x12, [x0, #0x8]
    26e0:      	cbz	x12, 0x2700 <ltmp0+0x2700>
    26e4:      	ldr	x12, [x12, #0x30]
    26e8:      	cmp	x12, x11
    26ec:      	b.ne	0x2700 <ltmp0+0x2700>
    26f0:      	ldr	x8, [x8, #0x8]
    26f4:      	add	x8, x0, x8, lsl #3
    26f8:      	ldr	d0, [x8, #0x10]
    26fc:      	b	0x27ac <ltmp0+0x27ac>
    2700:      	ldr	x11, [x8, #0x18]
    2704:      	cmp	x11, #0x0
    2708:      	b.le	0x2784 <ltmp0+0x2784>
    270c:      	ldr	x11, [x8, #0x20]
    2710:      	ldr	x12, [x8, #0x30]
    2714:      	ldr	x13, [x8, #0x40]
    2718:      	cmp	x13, x9
    271c:      	ldr	x14, [x8, #0x50]
    2720:      	ccmp	x14, x9, #0x4, ne
    2724:      	ccmp	x12, x9, #0x4, ne
    2728:      	ccmp	x11, x9, #0x4, ne
    272c:      	cset	w15, eq
    2730:      	cbz	w10, 0x2784 <ltmp0+0x2784>
    2734:      	cbz	w15, 0x2784 <ltmp0+0x2784>
    2738:      	ldr	x10, [x8, #0x48]
    273c:      	ldr	x15, [x8, #0x58]
    2740:      	cmp	x14, x9
    2744:      	csel	x14, x15, xzr, eq
    2748:      	cmp	x13, x9
    274c:      	csel	x10, x10, x14, eq
    2750:      	ldr	x13, [x8, #0x28]
    2754:      	ldr	x8, [x8, #0x38]
    2758:      	cmp	x12, x9
    275c:      	csel	x8, x8, x10, eq
    2760:      	cmp	x11, x9
    2764:      	csel	x8, x13, x8, eq
    2768:      	add	x8, x0, x8, lsl #3
    276c:      	ldr	d0, [x8, #0x10]
    2770:      	fmov	x8, d0
    2774:      	mov	x9, #0x10               ; =16
    2778:      	movk	x9, #0x7ffc, lsl #48
    277c:      	cmp	x8, x9
    2780:      	b.ne	0x27ac <ltmp0+0x27ac>
    2784:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		0000000000002784:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    2788:      	ldr	x8, [x8]
		0000000000002788:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    278c:      	stp	x28, x24, [sp, #0x10]
    2790:      	str	x19, [sp, #0x8]
    2794:      	and	x1, x8, #0xffffffffffff
    2798:      	adrp	x2, 0x2000 <ltmp0+0x2000>
		0000000000002798:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__14
    279c:      	add	x2, x2, #0x0
		000000000000279c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__14
    27a0:      	bl	0x27a0 <ltmp0+0x27a0>
		00000000000027a0:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    27a4:      	ldp	x19, x28, [sp, #0x8]
    27a8:      	ldr	x24, [sp, #0x18]
    27ac:      	fmov	x8, d0
    27b0:      	mov	x9, #0x7ff8000000000000 ; =9221120237041090560
    27b4:      	bics	xzr, x9, x8
    27b8:      	b.ne	0x27e8 <ltmp0+0x27e8>
    27bc:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    27c0:      	add	x9, x8, x9
    27c4:      	cmp	x9, #0x4
    27c8:      	b.hs	0x27fc <ltmp0+0x27fc>
    27cc:      	mov	x9, #0x10               ; =16
    27d0:      	movk	x9, #0x7ffc, lsl #48
    27d4:      	sub	x9, x9, #0xc
    27d8:      	movi.2d	v1, #0000000000000000
    27dc:      	cmp	x8, x9
    27e0:      	b.eq	0x2818 <ltmp0+0x2818>
    27e4:      	b	0x281c <ltmp0+0x281c>
    27e8:      	movi.2d	v1, #0000000000000000
    27ec:      	fcmp	d0, #0.0
    27f0:      	b.eq	0x281c <ltmp0+0x281c>
    27f4:      	b.vs	0x281c <ltmp0+0x281c>
    27f8:      	b	0x2818 <ltmp0+0x2818>
    27fc:      	mov	w9, #0x7ffd             ; =32765
    2800:      	cmp	x9, x8, lsr #48
    2804:      	b.ne	0x2810 <ltmp0+0x2810>
    2808:      	and	x8, x8, #0xffffffffffff
    280c:      	cbnz	x8, 0x2818 <ltmp0+0x2818>
    2810:      	bl	0x2810 <ltmp0+0x2810>
		0000000000002810:  ARM64_RELOC_BRANCH26	_js_is_truthy
    2814:      	cbz	w0, 0x2898 <ltmp0+0x2898>
    2818:      	fmov	d1, #1.00000000
    281c:      	fmov	d0, x24
    2820:      	and	x8, x24, #0xffff000000000000
    2824:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    2828:      	cmp	x24, x9
    282c:      	ccmp	x8, x26, #0x2, hs
    2830:      	cset	w8, hi
    2834:      	fmov	x9, d1
    2838:      	cmp	x9, x20
    283c:      	b.hi	0x284c <ltmp0+0x284c>
    2840:      	tbz	w8, #0x0, 0x284c <ltmp0+0x284c>
    2844:      	fadd	d0, d1, d0
    2848:      	b	0x2858 <ltmp0+0x2858>
    284c:      	stp	x19, x28, [sp, #0x10]
    2850:      	bl	0x2850 <ltmp0+0x2850>
		0000000000002850:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    2854:      	ldp	x19, x28, [sp, #0x10]
    2858:      	fmov	x24, d0
    285c:      	mov	x0, x24
    2860:      	ldr	w8, [x27]
    2864:      	cbz	w8, 0x286c <ltmp0+0x286c>
    2868:      	bl	0x2868 <ltmp0+0x2868>
		0000000000002868:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    286c:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		000000000000286c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    2870:      	ldr	x8, [x8]
		0000000000002870:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    2874:      	ldr	w8, [x8]
    2878:      	cbz	w8, 0x2890 <ltmp0+0x2890>
    287c:      	stp	x28, x19, [sp, #0x10]
    2880:      	str	x24, [sp, #0x8]
    2884:      	bl	0x2884 <ltmp0+0x2884>
		0000000000002884:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    2888:      	ldp	x24, x28, [sp, #0x8]
    288c:      	ldr	x19, [sp, #0x18]
    2890:      	add	w25, w25, #0x1
    2894:      	b	0x135c <ltmp0+0x135c>
    2898:      	movi.2d	v1, #0000000000000000
    289c:      	b	0x281c <ltmp0+0x281c>
    28a0:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		00000000000028a0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    28a4:      	ldr	x8, [x8]
		00000000000028a4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    28a8:      	stp	x28, x24, [sp, #0x10]
    28ac:      	str	x19, [sp, #0x8]
    28b0:      	and	x1, x8, #0xffffffffffff
    28b4:      	adrp	x3, 0x2000 <ltmp0+0x2000>
		00000000000028b4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__14
    28b8:      	add	x3, x3, #0x0
		00000000000028b8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__14
    28bc:      	bl	0x28bc <ltmp0+0x28bc>
		00000000000028bc:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    28c0:      	b	0x27a4 <ltmp0+0x27a4>
    28c4:      	mov	x20, x22
    28c8:      	mov	w25, #0x0               ; =0
    28cc:      	mov	x24, #0x0               ; =0
    28d0:      	mov	x21, #0x7ffd000000000000 ; =9222527611924643840
    28d4:      	mov	x26, #0x7ffffff00000    ; =140737487306752
    28d8:      	ldr	d9, [x23]
		00000000000028d8:  ARM64_RELOC_PAGEOFF12	lCPI0_1
    28dc:      	ldr	d10, [x11]
		00000000000028dc:  ARM64_RELOC_PAGEOFF12	lCPI0_2
    28e0:      	mov	x23, #0x7ff8ffffffffffff ; =9221401712017801215
    28e4:      	mov	x8, #0x41f0000000000000 ; =4751297606875873280
    28e8:      	fmov	d11, x8
    28ec:      	tbnz	w20, #0x0, 0x2930 <ltmp0+0x2930>
    28f0:      	mov	x26, x19
    28f4:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		00000000000028f4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    28f8:      	ldr	x8, [x8]
		00000000000028f8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    28fc:      	ldr	w8, [x8]
    2900:      	cbz	w8, 0x2918 <ltmp0+0x2918>
    2904:      	stp	x28, x19, [sp, #0x10]
    2908:      	str	x24, [sp, #0x8]
    290c:      	bl	0x290c <ltmp0+0x290c>
		000000000000290c:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    2910:      	ldp	x24, x28, [sp, #0x8]
    2914:      	ldr	x19, [sp, #0x18]
    2918:      	scvtf	d0, w25
    291c:      	fmov	d1, x26
    2920:      	fcmp	d0, d1
    2924:      	mov	x26, #0x7ffffff00000    ; =140737487306752
    2928:      	b.pl	0x1d4 <ltmp0+0x1d4>
    292c:      	b	0x293c <ltmp0+0x293c>
    2930:      	cmp	w25, w22
    2934:      	b.ge	0x1d4 <ltmp0+0x1d4>
    2938:      	scvtf	d0, w25
    293c:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		000000000000293c:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    2940:      	ldr	d1, [x8]
		0000000000002940:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    2944:      	stp	x28, x24, [sp, #0x10]
    2948:      	str	x19, [sp, #0x8]
    294c:      	bl	0x294c <ltmp0+0x294c>
		000000000000294c:  ARM64_RELOC_BRANCH26	_js_dynamic_mod
    2950:      	mov.16b	v8, v0
    2954:      	ldp	x19, x28, [sp, #0x8]
    2958:      	ldr	x24, [sp, #0x18]
    295c:      	mov	x0, x24
    2960:      	ldr	w8, [x27]
    2964:      	cbz	w8, 0x296c <ltmp0+0x296c>
    2968:      	bl	0x2968 <ltmp0+0x2968>
		0000000000002968:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    296c:      	mov	x10, x28
    2970:      	and	x8, x10, #0xffffffffffff
    2974:      	and	x12, x10, #0xffff000000000000
    2978:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		0000000000002978:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    297c:      	ldr	x9, [x9]
		000000000000297c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    2980:      	ldr	x9, [x9]
    2984:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
    2988:      	cmp	x12, x21
    298c:      	ccmp	x9, #0x0, #0x0, eq
    2990:      	ccmp	x11, x26, #0x2, eq
    2994:      	b.hs	0x29d0 <ltmp0+0x29d0>
    2998:      	fcmp	d8, d11
    299c:      	b.pl	0x29d0 <ltmp0+0x29d0>
    29a0:      	ldurb	w9, [x8, #-0x8]
    29a4:      	ldrb	w11, [x8, #0x8]
    29a8:      	fcmp	d8, #0.0
    29ac:      	ccmp	w9, #0xb, #0x0, ge
    29b0:      	ccmp	w11, #0x9, #0x2, eq
    29b4:      	b.hs	0x29d0 <ltmp0+0x29d0>
    29b8:      	fcvtzs	x9, d8
    29bc:      	scvtf	d0, x9
    29c0:      	ldr	w13, [x8]
    29c4:      	fcmp	d8, d0
    29c8:      	ccmp	x9, x13, #0x2, eq
    29cc:      	b.lo	0x2a84 <ltmp0+0x2a84>
    29d0:      	cmp	x12, x21
    29d4:      	b.ne	0x2d60 <ltmp0+0x2d60>
    29d8:      	fcmp	d8, #0.0
    29dc:      	b.lt	0x2d60 <ltmp0+0x2d60>
    29e0:      	fcmp	d8, d9
    29e4:      	b.pl	0x2d60 <ltmp0+0x2d60>
    29e8:      	mov	x9, #-0x20000000000     ; =-2199023255552
    29ec:      	add	x9, x8, x9
    29f0:      	lsr	x9, x9, #41
    29f4:      	cmp	x9, #0x3f
    29f8:      	b.hs	0x2d60 <ltmp0+0x2d60>
    29fc:      	fcvtzs	x9, d8
    2a00:      	scvtf	d0, x9
    2a04:      	fcmp	d8, d0
    2a08:      	b.ne	0x2d60 <ltmp0+0x2d60>
    2a0c:      	ldursb	w11, [x8, #-0x7]
    2a10:      	tbnz	w11, #0x1f, 0x2d60 <ltmp0+0x2d60>
    2a14:      	ldurb	w11, [x8, #-0x8]
    2a18:      	cmp	w11, #0x9
    2a1c:      	b.eq	0x2b1c <ltmp0+0x2b1c>
    2a20:      	cmp	w11, #0x2
    2a24:      	b.eq	0x2acc <ltmp0+0x2acc>
    2a28:      	cmp	w11, #0x1
    2a2c:      	b.ne	0x2d60 <ltmp0+0x2d60>
    2a30:      	ldr	w10, [x8]
    2a34:      	mov	x11, x8
    2a38:      	ldurh	w13, [x8, #-0x6]
    2a3c:      	adrp	x12, 0x2000 <ltmp0+0x2000>
		0000000000002a3c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    2a40:      	ldr	x12, [x12]
		0000000000002a40:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    2a44:      	ldrb	w12, [x12]
    2a48:      	ldr	w8, [x8, #0x4]
    2a4c:      	cmp	x10, x8
    2a50:      	b.hi	0x2d60 <ltmp0+0x2d60>
    2a54:      	tbnz	w13, #0xa, 0x2d60 <ltmp0+0x2d60>
    2a58:      	cbnz	w12, 0x2d60 <ltmp0+0x2d60>
    2a5c:      	cmp	x9, x10
    2a60:      	b.hs	0x2d60 <ltmp0+0x2d60>
    2a64:      	add	x8, x11, x9, lsl #3
    2a68:      	ldr	d0, [x8, #0x8]
    2a6c:      	fmov	x8, d0
    2a70:      	mov	x9, #0x10               ; =16
    2a74:      	movk	x9, #0x7ffc, lsl #48
    2a78:      	cmp	x8, x9
    2a7c:      	fcsel	d0, d10, d0, eq
    2a80:      	b	0x2d80 <ltmp0+0x2d80>
    2a84:      	add	x8, x8, #0x10
    2a88:      	cmp	w11, #0x3
    2a8c:      	b.le	0x2ab0 <ltmp0+0x2ab0>
    2a90:      	cmp	w11, #0x5
    2a94:      	b.gt	0x2b68 <ltmp0+0x2b68>
    2a98:      	cmp	w11, #0x4
    2a9c:      	b.eq	0x2c14 <ltmp0+0x2c14>
    2aa0:      	cmp	w11, #0x5
    2aa4:      	b.ne	0x2c08 <ltmp0+0x2c08>
    2aa8:      	ldr	s0, [x8, x9, lsl #2]
    2aac:      	b	0x2c0c <ltmp0+0x2c0c>
    2ab0:      	cbz	w11, 0x2c00 <ltmp0+0x2c00>
    2ab4:      	cmp	w11, #0x2
    2ab8:      	b.eq	0x2c28 <ltmp0+0x2c28>
    2abc:      	cmp	w11, #0x3
    2ac0:      	b.ne	0x2c08 <ltmp0+0x2c08>
    2ac4:      	ldr	h0, [x8, x9, lsl #1]
    2ac8:      	b	0x2c0c <ltmp0+0x2c0c>
    2acc:      	ldr	x10, [x8, #0x8]
    2ad0:      	cbz	x10, 0x2b80 <ltmp0+0x2b80>
    2ad4:      	ldr	x11, [x10, #0x60]
    2ad8:      	cbz	x11, 0x2b80 <ltmp0+0x2b80>
    2adc:      	ldurb	w8, [x11, #-0x8]
    2ae0:      	cmp	w8, #0x1
    2ae4:      	b.ne	0x2d60 <ltmp0+0x2d60>
    2ae8:      	ldursb	w8, [x11, #-0x7]
    2aec:      	tbnz	w8, #0x1f, 0x2d60 <ltmp0+0x2d60>
    2af0:      	ldr	w8, [x11]
    2af4:      	cmp	x9, x8
    2af8:      	b.hs	0x2d60 <ltmp0+0x2d60>
    2afc:      	add	x8, x11, x9, lsl #3
    2b00:      	ldr	d0, [x8, #0x8]
    2b04:      	fmov	x8, d0
    2b08:      	mov	x9, #0x10               ; =16
    2b0c:      	movk	x9, #0x7ffc, lsl #48
    2b10:      	cmp	x8, x9
    2b14:      	b.eq	0x2d60 <ltmp0+0x2d60>
    2b18:      	b	0x2d80 <ltmp0+0x2d80>
    2b1c:      	ldr	w12, [x8, #0x4]
    2b20:      	ldr	x11, [x8, #0x20]
    2b24:      	ldurh	w13, [x8, #-0x6]
    2b28:      	tst	w13, #0xc00
    2b2c:      	mov	w13, #0x5841            ; =22593
    2b30:      	movk	w13, #0x4c5a, lsl #16
    2b34:      	ccmp	w12, w13, #0x0, eq
    2b38:      	cset	w12, eq
    2b3c:      	cbz	x11, 0x2bc8 <ltmp0+0x2bc8>
    2b40:      	tbz	w12, #0x0, 0x2bc8 <ltmp0+0x2bc8>
    2b44:      	ldurb	w10, [x11, #-0x8]
    2b48:      	cmp	w10, #0x1
    2b4c:      	b.ne	0x2d60 <ltmp0+0x2d60>
    2b50:      	ldursb	w10, [x11, #-0x7]
    2b54:      	tbnz	w10, #0x1f, 0x2d60 <ltmp0+0x2d60>
    2b58:      	ldr	w10, [x11]
    2b5c:      	str	w10, [x8]
    2b60:      	mov	x8, x11
    2b64:      	b	0x2a38 <ltmp0+0x2a38>
    2b68:      	cmp	w11, #0x6
    2b6c:      	b.eq	0x2c1c <ltmp0+0x2c1c>
    2b70:      	cmp	w11, #0x7
    2b74:      	b.ne	0x2c08 <ltmp0+0x2c08>
    2b78:      	ldr	d0, [x8, x9, lsl #3]
    2b7c:      	b	0x2d80 <ltmp0+0x2d80>
    2b80:      	adrp	x12, 0x2000 <ltmp0+0x2000>
		0000000000002b80:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__15
    2b84:      	add	x12, x12, #0x0
		0000000000002b84:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__15
    2b88:      	ldr	x11, [x12]
    2b8c:      	cmp	x11, #0x0
    2b90:      	csel	x12, x12, x11, eq
    2b94:      	ldr	x12, [x12]
    2b98:      	cbz	x12, 0x2d60 <ltmp0+0x2d60>
    2b9c:      	tbnz	x12, #0x3f, 0x2c34 <ltmp0+0x2c34>
    2ba0:      	ldp	w14, w13, [x8]
    2ba4:      	orr	x13, x13, x14, lsl #32
    2ba8:      	cmp	x13, x12
    2bac:      	b.ne	0x2d60 <ltmp0+0x2d60>
    2bb0:      	ldp	x14, x12, [x11, #0x8]
    2bb4:      	ldp	x13, x11, [x11, #0x18]
    2bb8:      	cmp	x14, x11
    2bbc:      	b.lo	0x2c54 <ltmp0+0x2c54>
    2bc0:      	cbz	x10, 0x2d60 <ltmp0+0x2d60>
    2bc4:      	b	0x2ca4 <ltmp0+0x2ca4>
    2bc8:      	cmp	x11, #0x0
    2bcc:      	ldr	w14, [x8]
    2bd0:      	ldp	x11, x13, [x8, #0x28]
    2bd4:      	ccmp	x9, x14, #0x2, eq
    2bd8:      	ccmp	x11, #0x0, #0x4, lo
    2bdc:      	ccmp	x13, #0x0, #0x4, ne
    2be0:      	csel	w12, wzr, w12, eq
    2be4:      	tbz	w12, #0x0, 0x2d60 <ltmp0+0x2d60>
    2be8:      	lsr	x12, x9, #6
    2bec:      	ldr	x12, [x13, x12, lsl #3]
    2bf0:      	lsr	x12, x12, x9
    2bf4:      	tbz	w12, #0x0, 0x2c60 <ltmp0+0x2c60>
    2bf8:      	ldr	d0, [x11, x9, lsl #3]
    2bfc:      	b	0x2d80 <ltmp0+0x2d80>
    2c00:      	ldrsb	w8, [x8, x9]
    2c04:      	b	0x2c2c <ltmp0+0x2c2c>
    2c08:      	ldr	b0, [x8, x9]
    2c0c:      	ucvtf	d0, d0
    2c10:      	b	0x2d80 <ltmp0+0x2d80>
    2c14:      	ldr	w8, [x8, x9, lsl #2]
    2c18:      	b	0x2c2c <ltmp0+0x2c2c>
    2c1c:      	ldr	s0, [x8, x9, lsl #2]
    2c20:      	fcvt	d0, s0
    2c24:      	b	0x2d80 <ltmp0+0x2d80>
    2c28:      	ldrsh	w8, [x8, x9, lsl #1]
    2c2c:      	scvtf	d0, w8
    2c30:      	b	0x2d80 <ltmp0+0x2d80>
    2c34:      	cbz	x10, 0x2d60 <ltmp0+0x2d60>
    2c38:      	ldr	x13, [x10, #0x30]
    2c3c:      	cmp	x13, x12
    2c40:      	b.ne	0x2d60 <ltmp0+0x2d60>
    2c44:      	ldp	x14, x12, [x11, #0x8]
    2c48:      	ldp	x13, x11, [x11, #0x18]
    2c4c:      	cmp	x14, x11
    2c50:      	b.hs	0x2ca4 <ltmp0+0x2ca4>
    2c54:      	add	x14, x8, x14, lsl #3
    2c58:      	add	x14, x14, #0x10
    2c5c:      	b	0x2cc8 <ltmp0+0x2cc8>
    2c60:      	ldr	x8, [x8, #0x50]
    2c64:      	mov	w12, #0x6903            ; =26883
    2c68:      	movk	w12, #0x64, lsl #16
    2c6c:      	cmp	x8, x12
    2c70:      	b.eq	0x2c78 <ltmp0+0x2c78>
    2c74:      	cbnz	x8, 0x2d60 <ltmp0+0x2d60>
    2c78:      	mov	w12, #0x6903            ; =26883
    2c7c:      	movk	w12, #0x64, lsl #16
    2c80:      	cmp	x8, x12
    2c84:      	b.ne	0x2d30 <ltmp0+0x2d30>
    2c88:      	ldr	x8, [x11, x9, lsl #3]
    2c8c:      	cbz	x8, 0x2d30 <ltmp0+0x2d30>
    2c90:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    2c94:      	cmp	x8, x9
    2c98:      	csel	x8, xzr, x8, eq
    2c9c:      	fmov	d1, x8
    2ca0:      	b	0x2f78 <ltmp0+0x2f78>
    2ca4:      	ldr	x16, [x10, #0x20]
    2ca8:      	cmp	x16, #0x0
    2cac:      	csel	x15, x16, x10, ne
    2cb0:      	cbz	x16, 0x2d60 <ltmp0+0x2d60>
    2cb4:      	ldr	w16, [x15]
    2cb8:      	cmp	x14, x16
    2cbc:      	b.hs	0x2d60 <ltmp0+0x2d60>
    2cc0:      	add	x14, x15, x14, lsl #3
    2cc4:      	add	x14, x14, #0x8
    2cc8:      	ldr	d0, [x14]
    2ccc:      	fcmp	d8, d0
    2cd0:      	ccmp	x13, x9, #0x0, mi
    2cd4:      	cset	w13, hi
    2cd8:      	add	x9, x12, x9
    2cdc:      	cmp	x9, x11
    2ce0:      	ccmp	w13, #0x0, #0x4, lo
    2ce4:      	b.ne	0x2d24 <ltmp0+0x2d24>
    2ce8:      	cbz	x10, 0x2d60 <ltmp0+0x2d60>
    2cec:      	cmp	x9, x11
    2cf0:      	b.lo	0x2d60 <ltmp0+0x2d60>
    2cf4:      	eor	w8, w13, #0x1
    2cf8:      	tbnz	w8, #0x0, 0x2d60 <ltmp0+0x2d60>
    2cfc:      	ldr	x11, [x10, #0x20]
    2d00:      	cmp	x11, #0x0
    2d04:      	csel	x8, x11, x10, ne
    2d08:      	cbz	x11, 0x2d60 <ltmp0+0x2d60>
    2d0c:      	ldr	w10, [x8]
    2d10:      	cmp	x9, x10
    2d14:      	b.hs	0x2d60 <ltmp0+0x2d60>
    2d18:      	add	x8, x8, x9, lsl #3
    2d1c:      	ldr	d0, [x8, #0x8]
    2d20:      	b	0x2d80 <ltmp0+0x2d80>
    2d24:      	add	x8, x8, x9, lsl #3
    2d28:      	ldr	d0, [x8, #0x10]
    2d2c:      	b	0x2d80 <ltmp0+0x2d80>
    2d30:      	fmov	d0, x10
    2d34:      	mov.16b	v1, v8
    2d38:      	adrp	x0, 0x2000 <ltmp0+0x2000>
		0000000000002d38:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    2d3c:      	add	x0, x0, #0x0
		0000000000002d3c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    2d40:      	mov	w1, #0x2                ; =2
    2d44:      	bl	0x2d44 <ltmp0+0x2d44>
		0000000000002d44:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    2d48:      	mov.16b	v1, v0
    2d4c:      	fmov	x8, d1
    2d50:      	mov	x9, #0x10               ; =16
    2d54:      	movk	x9, #0x7ffc, lsl #48
    2d58:      	cmp	x8, x9
    2d5c:      	b.ne	0x2f78 <ltmp0+0x2f78>
    2d60:      	fmov	d0, x28
    2d64:      	str	x24, [sp, #0x18]
    2d68:      	mov.16b	v1, v8
    2d6c:      	adrp	x0, 0x2000 <ltmp0+0x2000>
		0000000000002d6c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__15
    2d70:      	add	x0, x0, #0x0
		0000000000002d70:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__15
    2d74:      	bl	0x2d74 <ltmp0+0x2d74>
		0000000000002d74:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    2d78:      	ldp	x28, x24, [sp, #0x10]
    2d7c:      	ldr	x19, [sp, #0x8]
    2d80:      	fmov	x8, d0
    2d84:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    2d88:      	and	x9, x8, x9
    2d8c:      	cmp	x9, x21
    2d90:      	b.ne	0x2dfc <ltmp0+0x2dfc>
    2d94:      	and	x0, x8, #0xffffffffffff
    2d98:      	lsr	x8, x0, #20
    2d9c:      	cbz	x8, 0x2f50 <ltmp0+0x2f50>
    2da0:      	ldurb	w9, [x0, #-0x8]
    2da4:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		0000000000002da4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__17
    2da8:      	ldr	x8, [x8]
		0000000000002da8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__17
    2dac:      	cbz	x8, 0x2e6c <ltmp0+0x2e6c>
    2db0:      	ldurh	w10, [x0, #-0x6]
    2db4:      	and	w10, w10, #0x800
    2db8:      	cmp	w9, #0x2
    2dbc:      	ccmp	w10, #0x0, #0x0, eq
    2dc0:      	b.ne	0x2e6c <ltmp0+0x2e6c>
    2dc4:      	ldr	w10, [x0, #0x4]
    2dc8:      	orr	x9, x10, #0x4000000000000000
    2dcc:      	ldr	x11, [x8]
    2dd0:      	cmp	w10, #0x0
    2dd4:      	ccmp	x9, x11, #0x0, ne
    2dd8:      	b.eq	0x2ea4 <ltmp0+0x2ea4>
    2ddc:      	ldr	x11, [x8, #0x10]
    2de0:      	cbz	x11, 0x2ec8 <ltmp0+0x2ec8>
    2de4:      	ldr	x12, [x0, #0x8]
    2de8:      	cbz	x12, 0x2ec8 <ltmp0+0x2ec8>
    2dec:      	ldr	x12, [x12, #0x30]
    2df0:      	cmp	x12, x11
    2df4:      	b.eq	0x2e94 <ltmp0+0x2e94>
    2df8:      	b	0x2ec8 <ltmp0+0x2ec8>
    2dfc:      	lsr	x9, x8, #48
    2e00:      	mov	w10, #0x7ff9            ; =32761
    2e04:      	cmp	x9, x10
    2e08:      	b.eq	0x2e50 <ltmp0+0x2e50>
    2e0c:      	mov	w10, #0x7ffe            ; =32766
    2e10:      	cmp	w9, w10
    2e14:      	b.ne	0x2e40 <ltmp0+0x2e40>
    2e18:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		0000000000002e18:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    2e1c:      	ldr	x9, [x9]
		0000000000002e1c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    2e20:      	str	x24, [sp, #0x18]
    2e24:      	and	x2, x9, #0xffffffffffff
    2e28:      	mov	x0, #0x10               ; =16
    2e2c:      	movk	x0, #0xddae, lsl #32
    2e30:      	movk	x0, #0x5556, lsl #48
    2e34:      	mov	x1, x8
    2e38:      	bl	0x2e38 <ltmp0+0x2e38>
		0000000000002e38:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    2e3c:      	b	0x2f6c <ltmp0+0x2f6c>
    2e40:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    2e44:      	add	x9, x8, x9
    2e48:      	cmp	x9, #0x2
    2e4c:      	b.lo	0x3024 <ltmp0+0x3024>
    2e50:      	adrp	x9, 0x2000 <ltmp0+0x2000>
		0000000000002e50:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    2e54:      	ldr	x9, [x9]
		0000000000002e54:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    2e58:      	str	x24, [sp, #0x18]
    2e5c:      	and	x1, x9, #0xffffffffffff
    2e60:      	mov	x0, x8
    2e64:      	bl	0x2e64 <ltmp0+0x2e64>
		0000000000002e64:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    2e68:      	b	0x2f6c <ltmp0+0x2f6c>
    2e6c:      	cmp	w9, #0x2
    2e70:      	ccmp	x8, #0x0, #0x4, eq
    2e74:      	b.eq	0x2f50 <ltmp0+0x2f50>
    2e78:      	ldr	x9, [x8, #0x10]
    2e7c:      	cbz	x9, 0x2f50 <ltmp0+0x2f50>
    2e80:      	ldr	x10, [x0, #0x8]
    2e84:      	cbz	x10, 0x2f50 <ltmp0+0x2f50>
    2e88:      	ldr	x10, [x10, #0x30]
    2e8c:      	cmp	x10, x9
    2e90:      	b.ne	0x2f50 <ltmp0+0x2f50>
    2e94:      	ldr	x8, [x8, #0x8]
    2e98:      	add	x8, x0, x8, lsl #3
    2e9c:      	ldr	d1, [x8, #0x10]
    2ea0:      	b	0x2f78 <ltmp0+0x2f78>
    2ea4:      	ldr	x2, [x8, #0x8]
    2ea8:      	tbnz	w2, #0x1e, 0x3004 <ltmp0+0x3004>
    2eac:      	add	x11, x0, x2, lsl #3
    2eb0:      	ldr	d1, [x11, #0x10]
    2eb4:      	fmov	x11, d1
    2eb8:      	mov	x12, #0x10              ; =16
    2ebc:      	movk	x12, #0x7ffc, lsl #48
    2ec0:      	cmp	x11, x12
    2ec4:      	b.ne	0x2f78 <ltmp0+0x2f78>
    2ec8:      	ldr	x11, [x8, #0x18]
    2ecc:      	cmp	x11, #0x0
    2ed0:      	b.le	0x2f50 <ltmp0+0x2f50>
    2ed4:      	ldr	x11, [x8, #0x20]
    2ed8:      	ldr	x12, [x8, #0x30]
    2edc:      	ldr	x13, [x8, #0x40]
    2ee0:      	cmp	x13, x9
    2ee4:      	ldr	x14, [x8, #0x50]
    2ee8:      	ccmp	x14, x9, #0x4, ne
    2eec:      	ccmp	x12, x9, #0x4, ne
    2ef0:      	ccmp	x11, x9, #0x4, ne
    2ef4:      	cset	w15, eq
    2ef8:      	cmp	w10, #0x0
    2efc:      	ccmp	w15, #0x0, #0x4, ne
    2f00:      	b.eq	0x2f50 <ltmp0+0x2f50>
    2f04:      	ldr	x10, [x8, #0x48]
    2f08:      	ldr	x15, [x8, #0x58]
    2f0c:      	cmp	x14, x9
    2f10:      	csel	x14, x15, xzr, eq
    2f14:      	cmp	x13, x9
    2f18:      	csel	x10, x10, x14, eq
    2f1c:      	ldr	x13, [x8, #0x28]
    2f20:      	ldr	x8, [x8, #0x38]
    2f24:      	cmp	x12, x9
    2f28:      	csel	x8, x8, x10, eq
    2f2c:      	cmp	x11, x9
    2f30:      	csel	x8, x13, x8, eq
    2f34:      	add	x8, x0, x8, lsl #3
    2f38:      	ldr	d1, [x8, #0x10]
    2f3c:      	fmov	x8, d1
    2f40:      	mov	x9, #0x10               ; =16
    2f44:      	movk	x9, #0x7ffc, lsl #48
    2f48:      	cmp	x8, x9
    2f4c:      	b.ne	0x2f78 <ltmp0+0x2f78>
    2f50:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		0000000000002f50:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    2f54:      	ldr	x8, [x8]
		0000000000002f54:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    2f58:      	str	x24, [sp, #0x18]
    2f5c:      	and	x1, x8, #0xffffffffffff
    2f60:      	adrp	x2, 0x2000 <ltmp0+0x2000>
		0000000000002f60:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__17
    2f64:      	add	x2, x2, #0x0
		0000000000002f64:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__17
    2f68:      	bl	0x2f68 <ltmp0+0x2f68>
		0000000000002f68:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    2f6c:      	mov.16b	v1, v0
    2f70:      	ldp	x19, x28, [sp, #0x8]
    2f74:      	ldr	x24, [sp, #0x18]
    2f78:      	fmov	d0, x24
    2f7c:      	and	x9, x24, #0xffff000000000000
    2f80:      	fmov	x8, d1
    2f84:      	and	x10, x8, #0xffff000000000000
    2f88:      	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
    2f8c:      	cmp	x8, x11
    2f90:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    2f94:      	ccmp	x10, x8, #0x2, hs
    2f98:      	cset	w8, hi
    2f9c:      	mov	x10, #0x1               ; =1
    2fa0:      	movk	x10, #0x7fff, lsl #48
    2fa4:      	cmp	x9, x10
    2fa8:      	ccmp	x24, x23, #0x0, lo
    2fac:      	b.hi	0x2fbc <ltmp0+0x2fbc>
    2fb0:      	tbz	w8, #0x0, 0x2fbc <ltmp0+0x2fbc>
    2fb4:      	fadd	d0, d1, d0
    2fb8:      	b	0x2fc4 <ltmp0+0x2fc4>
    2fbc:      	bl	0x2fbc <ltmp0+0x2fbc>
		0000000000002fbc:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    2fc0:      	ldp	x19, x28, [sp, #0x8]
    2fc4:      	fmov	x24, d0
    2fc8:      	mov	x0, x24
    2fcc:      	ldr	w8, [x27]
    2fd0:      	cbz	w8, 0x2fd8 <ltmp0+0x2fd8>
    2fd4:      	bl	0x2fd4 <ltmp0+0x2fd4>
		0000000000002fd4:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    2fd8:      	adrp	x8, 0x2000 <ltmp0+0x2000>
		0000000000002fd8:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    2fdc:      	ldr	x8, [x8]
		0000000000002fdc:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    2fe0:      	ldr	w8, [x8]
    2fe4:      	cbz	w8, 0x2ff8 <ltmp0+0x2ff8>
    2fe8:      	str	x24, [sp, #0x18]
    2fec:      	bl	0x2fec <ltmp0+0x2fec>
		0000000000002fec:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    2ff0:      	ldp	x28, x24, [sp, #0x10]
    2ff4:      	ldr	x19, [sp, #0x8]
    2ff8:      	add	w25, w25, #0x1
    2ffc:      	tbz	w20, #0x0, 0x28f0 <ltmp0+0x28f0>
    3000:      	b	0x2930 <ltmp0+0x2930>
    3004:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003004:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    3008:      	ldr	x8, [x8]
		0000000000003008:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    300c:      	str	x24, [sp, #0x18]
    3010:      	and	x1, x8, #0xffffffffffff
    3014:      	adrp	x3, 0x3000 <ltmp0+0x3000>
		0000000000003014:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__17
    3018:      	add	x3, x3, #0x0
		0000000000003018:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__17
    301c:      	bl	0x301c <ltmp0+0x301c>
		000000000000301c:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    3020:      	b	0x2f6c <ltmp0+0x2f6c>
    3024:      	mov	x9, #0x10               ; =16
    3028:      	movk	x9, #0x7ffc, lsl #48
    302c:      	sub	x9, x9, #0xe
    3030:      	cmp	x8, x9
    3034:      	cset	w0, eq
    3038:      	adrp	x1, 0x3000 <ltmp0+0x3000>
		0000000000003038:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    303c:      	add	x1, x1, #0x0
		000000000000303c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    3040:      	mov	w2, #0x2                ; =2
    3044:      	bl	0x3044 <ltmp0+0x3044>
		0000000000003044:  ARM64_RELOC_BRANCH26	_js_throw_type_error_property_access
    3048:      	brk	#0x1
    304c:      	mov	x9, #0x10               ; =16
    3050:      	movk	x9, #0x7ffc, lsl #48
    3054:      	sub	x9, x9, #0xe
    3058:      	cmp	x8, x9
    305c:      	cset	w0, eq
    3060:      	adrp	x1, 0x3000 <ltmp0+0x3000>
		0000000000003060:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.4.bytes
    3064:      	add	x1, x1, #0x0
		0000000000003064:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.4.bytes
    3068:      	mov	w2, #0x4                ; =4
    306c:      	b	0x3044 <ltmp0+0x3044>
    3070:      	mov	x9, #0x10               ; =16
    3074:      	movk	x9, #0x7ffc, lsl #48
    3078:      	sub	x9, x9, #0xe
    307c:      	cmp	x8, x9
    3080:      	cset	w0, eq
    3084:      	adrp	x1, 0x3000 <ltmp0+0x3000>
		0000000000003084:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.5.bytes
    3088:      	add	x1, x1, #0x0
		0000000000003088:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.5.bytes
    308c:      	mov	w2, #0x6                ; =6
    3090:      	b	0x3044 <ltmp0+0x3044>

0000000000003094 <_perry_fn_access_worker_ts__run$generic>:
    3094:      	sub	sp, sp, #0xd0
    3098:      	stp	d15, d14, [sp, #0x30]
    309c:      	stp	d13, d12, [sp, #0x40]
    30a0:      	stp	d11, d10, [sp, #0x50]
    30a4:      	stp	d9, d8, [sp, #0x60]
    30a8:      	stp	x28, x27, [sp, #0x70]
    30ac:      	stp	x26, x25, [sp, #0x80]
    30b0:      	stp	x24, x23, [sp, #0x90]
    30b4:      	stp	x22, x21, [sp, #0xa0]
    30b8:      	stp	x20, x19, [sp, #0xb0]
    30bc:      	stp	x29, x30, [sp, #0xc0]
    30c0:      	add	x29, sp, #0xc0
    30c4:      	fmov	x28, d0
    30c8:      	fmov	x26, d1
    30cc:      	adrp	x19, 0x3000 <ltmp0+0x3000>
		00000000000030cc:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__1
    30d0:      	ldr	x8, [x19]
		00000000000030d0:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
    30d4:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		00000000000030d4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.0.handle
    30d8:      	ldr	x9, [x9]
		00000000000030d8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.0.handle
    30dc:      	cmp	x8, x9
    30e0:      	b.ne	0x3130 <_perry_fn_access_worker_ts__run$generic+0x9c>
    30e4:      	mov	x8, x26
    30e8:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    30ec:      	cmp	x8, x9
    30f0:      	b.lo	0x31c0 <_perry_fn_access_worker_ts__run$generic+0x12c>
    30f4:      	and	x9, x8, #0xffff000000000000
    30f8:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
    30fc:      	cmp	x9, x10
    3100:      	b.hi	0x31c0 <_perry_fn_access_worker_ts__run$generic+0x12c>
    3104:      	mov	x8, x26
    3108:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    310c:      	cmp	x8, x9
    3110:      	b.lo	0x3344 <_perry_fn_access_worker_ts__run$generic+0x2b0>
    3114:      	and	x9, x8, #0xffff000000000000
    3118:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
    311c:      	cmp	x9, x10
    3120:      	b.hi	0x3344 <_perry_fn_access_worker_ts__run$generic+0x2b0>
    3124:      	str	wzr, [sp, #0x14]
    3128:      	mov	w25, #0x0               ; =0
    312c:      	b	0x3380 <_perry_fn_access_worker_ts__run$generic+0x2ec>
    3130:      	mov	w10, #0x7fff            ; =32767
    3134:      	cmp	x10, x8, lsr #48
    3138:      	b.ne	0x3184 <_perry_fn_access_worker_ts__run$generic+0xf0>
    313c:      	and	x0, x8, #0xffffffffffff
    3140:      	cmp	x0, #0x1, lsl #12       ; =0x1000
    3144:      	b.lo	0x3184 <_perry_fn_access_worker_ts__run$generic+0xf0>
    3148:      	ldr	w10, [x0, #0x4]
    314c:      	cmp	w10, #0x6
    3150:      	b.ne	0x3184 <_perry_fn_access_worker_ts__run$generic+0xf0>
    3154:      	ldrb	w10, [x0, #0x14]
    3158:      	cmp	w10, #0x72
    315c:      	b.ne	0x3184 <_perry_fn_access_worker_ts__run$generic+0xf0>
    3160:      	ldrb	w10, [x0, #0x19]
    3164:      	cmp	w10, #0x74
    3168:      	b.ne	0x3184 <_perry_fn_access_worker_ts__run$generic+0xf0>
    316c:      	stp	x28, x26, [sp, #0x20]
    3170:      	and	x1, x9, #0xffffffffffff
    3174:      	bl	0x3174 <_perry_fn_access_worker_ts__run$generic+0xe0>
		0000000000003174:  ARM64_RELOC_BRANCH26	_js_string_equals
    3178:      	ldp	x28, x26, [sp, #0x20]
    317c:      	cbnz	w0, 0x30e4 <_perry_fn_access_worker_ts__run$generic+0x50>
    3180:      	ldr	x8, [x19]
		0000000000003180:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
    3184:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		0000000000003184:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.2.handle
    3188:      	ldr	x9, [x9]
		0000000000003188:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.2.handle
    318c:      	cmp	x8, x9
    3190:      	b.ne	0x329c <_perry_fn_access_worker_ts__run$generic+0x208>
    3194:      	mov	x8, x26
    3198:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    319c:      	cmp	x8, x9
    31a0:      	b.lo	0x3b20 <_perry_fn_access_worker_ts__run$generic+0xa8c>
    31a4:      	and	x9, x8, #0xffff000000000000
    31a8:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
    31ac:      	cmp	x9, x10
    31b0:      	b.hi	0x3b20 <_perry_fn_access_worker_ts__run$generic+0xa8c>
    31b4:      	mov	w9, #0x0                ; =0
    31b8:      	mov	w25, #0x0               ; =0
    31bc:      	b	0x3c70 <_perry_fn_access_worker_ts__run$generic+0xbdc>
    31c0:      	fmov	d0, x8
    31c4:      	fcmp	d0, #0.0
    31c8:      	b.le	0x3104 <_perry_fn_access_worker_ts__run$generic+0x70>
    31cc:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		00000000000031cc:  ARM64_RELOC_PAGE21	lCPI1_0
    31d0:      	ldr	d1, [x8]
		00000000000031d0:  ARM64_RELOC_PAGEOFF12	lCPI1_0
    31d4:      	fcmp	d0, d1
    31d8:      	b.hi	0x3104 <_perry_fn_access_worker_ts__run$generic+0x70>
    31dc:      	fcvtzs	w19, d0
    31e0:      	scvtf	d1, w19
    31e4:      	fcmp	d0, d1
    31e8:      	b.ne	0x3104 <_perry_fn_access_worker_ts__run$generic+0x70>
    31ec:      	mov	x20, #0x0               ; =0
    31f0:      	and	x21, x20, #0xffff000000000000
    31f4:      	mov	x8, x28
    31f8:      	fmov	d0, x8
    31fc:      	adrp	x1, 0x3000 <ltmp0+0x3000>
		00000000000031fc:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    3200:      	add	x1, x1, #0x0
		0000000000003200:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    3204:      	mov	w0, #0x7                ; =7
    3208:      	mov	w2, #0x2                ; =2
    320c:      	bl	0x320c <_perry_fn_access_worker_ts__run$generic+0x178>
		000000000000320c:  ARM64_RELOC_BRANCH26	_js_array_index_own_number
    3210:      	fmov	x8, d0
    3214:      	and	x9, x8, #0xffff000000000000
    3218:      	mov	x10, #0x7ff9000000000000 ; =9221401712017801216
    321c:      	cmp	x8, x10
    3220:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    3224:      	ccmp	x9, x8, #0x2, hs
    3228:      	cset	w8, hi
    322c:      	mov	x9, #0x1                ; =1
    3230:      	movk	x9, #0x7fff, lsl #48
    3234:      	cmp	x21, x9
    3238:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    323c:      	ccmp	x20, x9, #0x0, lo
    3240:      	b.hi	0x3104 <_perry_fn_access_worker_ts__run$generic+0x70>
    3244:      	cbz	w8, 0x3104 <_perry_fn_access_worker_ts__run$generic+0x70>
    3248:      	mov	x8, #0x0                ; =0
    324c:      	fmov	d1, x8
    3250:      	cmp	w19, #0x1
    3254:      	csinc	w8, w19, wzr, gt
    3258:      	fadd	d1, d0, d1
    325c:      	subs	w8, w8, #0x1
    3260:      	b.ne	0x3258 <_perry_fn_access_worker_ts__run$generic+0x1c4>
    3264:      	fmov	x23, d1
    3268:      	fmov	d0, x23
    326c:      	ldp	x29, x30, [sp, #0xc0]
    3270:      	ldp	x20, x19, [sp, #0xb0]
    3274:      	ldp	x22, x21, [sp, #0xa0]
    3278:      	ldp	x24, x23, [sp, #0x90]
    327c:      	ldp	x26, x25, [sp, #0x80]
    3280:      	ldp	x28, x27, [sp, #0x70]
    3284:      	ldp	d9, d8, [sp, #0x60]
    3288:      	ldp	d11, d10, [sp, #0x50]
    328c:      	ldp	d13, d12, [sp, #0x40]
    3290:      	ldp	d15, d14, [sp, #0x30]
    3294:      	add	sp, sp, #0xd0
    3298:      	ret
    329c:      	mov	w10, #0x7fff            ; =32767
    32a0:      	cmp	x10, x8, lsr #48
    32a4:      	b.ne	0x32f0 <_perry_fn_access_worker_ts__run$generic+0x25c>
    32a8:      	and	x0, x8, #0xffffffffffff
    32ac:      	cmp	x0, #0x1, lsl #12       ; =0x1000
    32b0:      	b.lo	0x32f0 <_perry_fn_access_worker_ts__run$generic+0x25c>
    32b4:      	ldr	w10, [x0, #0x4]
    32b8:      	cmp	w10, #0x6
    32bc:      	b.ne	0x32f0 <_perry_fn_access_worker_ts__run$generic+0x25c>
    32c0:      	ldrb	w10, [x0, #0x14]
    32c4:      	cmp	w10, #0x72
    32c8:      	b.ne	0x32f0 <_perry_fn_access_worker_ts__run$generic+0x25c>
    32cc:      	ldrb	w10, [x0, #0x19]
    32d0:      	cmp	w10, #0x6d
    32d4:      	b.ne	0x32f0 <_perry_fn_access_worker_ts__run$generic+0x25c>
    32d8:      	stp	x28, x26, [sp, #0x20]
    32dc:      	and	x1, x9, #0xffffffffffff
    32e0:      	bl	0x32e0 <_perry_fn_access_worker_ts__run$generic+0x24c>
		00000000000032e0:  ARM64_RELOC_BRANCH26	_js_string_equals
    32e4:      	ldp	x28, x26, [sp, #0x20]
    32e8:      	cbnz	w0, 0x3194 <_perry_fn_access_worker_ts__run$generic+0x100>
    32ec:      	ldr	x8, [x19]
		00000000000032ec:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
    32f0:      	mov	x19, #0x10              ; =16
    32f4:      	movk	x19, #0x7ffc, lsl #48
    32f8:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		00000000000032f8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.3.handle
    32fc:      	ldr	x9, [x9]
		00000000000032fc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.3.handle
    3300:      	adrp	x27, 0x3000 <ltmp0+0x3000>
		0000000000003300:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    3304:      	ldr	x27, [x27]
		0000000000003304:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    3308:      	adrp	x22, 0x3000 <ltmp0+0x3000>
		0000000000003308:  ARM64_RELOC_PAGE21	lCPI1_2
    330c:      	adrp	x11, 0x3000 <ltmp0+0x3000>
		000000000000330c:  ARM64_RELOC_PAGE21	lCPI1_3
    3310:      	cmp	x8, x9
    3314:      	b.ne	0x3b64 <_perry_fn_access_worker_ts__run$generic+0xad0>
    3318:      	mov	x8, x26
    331c:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    3320:      	cmp	x8, x9
    3324:      	b.lo	0x3be8 <_perry_fn_access_worker_ts__run$generic+0xb54>
    3328:      	and	x9, x8, #0xffff000000000000
    332c:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
    3330:      	cmp	x9, x10
    3334:      	b.hi	0x3be8 <_perry_fn_access_worker_ts__run$generic+0xb54>
    3338:      	mov	w9, #0x0                ; =0
    333c:      	str	wzr, [sp, #0x14]
    3340:      	b	0x44f4 <_perry_fn_access_worker_ts__run$generic+0x1460>
    3344:      	fmov	d0, x8
    3348:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
    334c:      	fmov	d1, x8
    3350:      	fcmp	d0, d1
    3354:      	b.lt	0x3124 <_perry_fn_access_worker_ts__run$generic+0x90>
    3358:      	fcvtzs	w8, d0
    335c:      	scvtf	d1, w8
    3360:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		0000000000003360:  ARM64_RELOC_PAGE21	lCPI1_0
    3364:      	ldr	d2, [x9]
		0000000000003364:  ARM64_RELOC_PAGEOFF12	lCPI1_0
    3368:      	fcmp	d1, d0
    336c:      	cset	w9, eq
    3370:      	fcmp	d0, d2
    3374:      	csel	w8, wzr, w8, hi
    3378:      	str	w8, [sp, #0x14]
    337c:      	csel	w25, wzr, w9, hi
    3380:      	mov	w27, #0x0               ; =0
    3384:      	mov	x23, #0x0               ; =0
    3388:      	mov	x19, #0x10              ; =16
    338c:      	movk	x19, #0x7ffc, lsl #48
    3390:      	adrp	x22, 0x3000 <ltmp0+0x3000>
		0000000000003390:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    3394:      	ldr	x22, [x22]
		0000000000003394:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    3398:      	movi.2d	v10, #0000000000000000
    339c:      	mov	x21, #0x7ffd000000000000 ; =9222527611924643840
    33a0:      	fmov	d11, #7.00000000
    33a4:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		00000000000033a4:  ARM64_RELOC_PAGE21	lCPI1_3
    33a8:      	ldr	d12, [x8]
		00000000000033a8:  ARM64_RELOC_PAGEOFF12	lCPI1_3
    33ac:      	mov	x20, #0x7ff9000000000000 ; =9221401712017801216
    33b0:      	adrp	x24, 0x3000 <ltmp0+0x3000>
		00000000000033b0:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    33b4:      	ldr	x24, [x24]
		00000000000033b4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    33b8:      	fmov	d13, #1.00000000
    33bc:      	movi.2d	v8, #0000000000000000
    33c0:      	tbnz	w25, #0x0, 0x349c <_perry_fn_access_worker_ts__run$generic+0x408>
    33c4:      	mov	x8, x26
    33c8:      	fmov	d1, x8
    33cc:      	and	x9, x8, #0xffff000000000000
    33d0:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    33d4:      	cmp	x9, x10
    33d8:      	b.eq	0x3414 <_perry_fn_access_worker_ts__run$generic+0x380>
    33dc:      	cmp	x8, x20
    33e0:      	b.lt	0x3414 <_perry_fn_access_worker_ts__run$generic+0x380>
    33e4:      	mov	x10, #-0x7ffc000000000001 ; =-9222246136947933185
    33e8:      	add	x10, x8, x10
    33ec:      	cmp	x10, #0x3
    33f0:      	b.ls	0x3414 <_perry_fn_access_worker_ts__run$generic+0x380>
    33f4:      	stp	x26, x23, [sp, #0x20]
    33f8:      	str	x28, [sp, #0x18]
    33fc:      	mov.16b	v0, v8
    3400:      	bl	0x3400 <_perry_fn_access_worker_ts__run$generic+0x36c>
		0000000000003400:  ARM64_RELOC_BRANCH26	_js_rel_lt
    3404:      	mov.16b	v9, v0
    3408:      	ldp	x28, x26, [sp, #0x18]
    340c:      	ldr	x23, [sp, #0x28]
    3410:      	b	0x346c <_perry_fn_access_worker_ts__run$generic+0x3d8>
    3414:      	sub	x10, x19, #0xc
    3418:      	and	x11, x8, #0xfffffffffffffffe
    341c:      	sub	x12, x19, #0xe
    3420:      	scvtf	d0, w8
    3424:      	mov	x13, #0x7ffe000000000000 ; =9222809086901354496
    3428:      	cmp	x9, x13
    342c:      	fcsel	d0, d0, d1, eq
    3430:      	cmp	x11, x12
    3434:      	fcsel	d0, d10, d0, eq
    3438:      	cmp	x8, x10
    343c:      	fcsel	d0, d13, d0, eq
    3440:      	fmov	x8, d8
    3444:      	scvtf	d1, w8
    3448:      	mov	w9, #0x7ffe             ; =32766
    344c:      	cmp	x9, x8, lsr #48
    3450:      	fcsel	d1, d1, d8, eq
    3454:      	fcmp	d1, d0
    3458:      	mov	w8, #0x8                ; =8
    345c:      	csel	x8, x8, xzr, mi
    3460:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		0000000000003460:  ARM64_RELOC_PAGE21	lCPI1_1
    3464:      	add	x9, x9, #0x0
		0000000000003464:  ARM64_RELOC_PAGEOFF12	lCPI1_1
    3468:      	ldr	d9, [x9, x8]
    346c:      	ldr	w8, [x24]
    3470:      	cbz	w8, 0x3488 <_perry_fn_access_worker_ts__run$generic+0x3f4>
    3474:      	stp	x28, x23, [sp, #0x20]
    3478:      	str	x26, [sp, #0x18]
    347c:      	bl	0x347c <_perry_fn_access_worker_ts__run$generic+0x3e8>
		000000000000347c:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    3480:      	ldp	x26, x28, [sp, #0x18]
    3484:      	ldr	x23, [sp, #0x28]
    3488:      	fmov	x8, d9
    348c:      	sub	x9, x19, #0xc
    3490:      	cmp	x8, x9
    3494:      	b.ne	0x3268 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    3498:      	b	0x34a8 <_perry_fn_access_worker_ts__run$generic+0x414>
    349c:      	ldr	w8, [sp, #0x14]
    34a0:      	cmp	w27, w8
    34a4:      	b.ge	0x3268 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    34a8:      	mov	x0, x23
    34ac:      	ldr	w8, [x22]
    34b0:      	cbz	w8, 0x34b8 <_perry_fn_access_worker_ts__run$generic+0x424>
    34b4:      	bl	0x34b4 <_perry_fn_access_worker_ts__run$generic+0x420>
		00000000000034b4:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    34b8:      	mov	x9, x28
    34bc:      	and	x8, x9, #0xffffffffffff
    34c0:      	and	x11, x9, #0xffff000000000000
    34c4:      	cmp	x11, x21
    34c8:      	b.ne	0x3534 <_perry_fn_access_worker_ts__run$generic+0x4a0>
    34cc:      	adrp	x10, 0x3000 <ltmp0+0x3000>
		00000000000034cc:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    34d0:      	ldr	x10, [x10]
		00000000000034d0:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    34d4:      	ldr	x10, [x10]
    34d8:      	sub	x12, x8, #0x100, lsl #12 ; =0x100000
    34dc:      	cmp	x10, #0x0
    34e0:      	mov	x10, #0x7ffffff00000    ; =140737487306752
    34e4:      	ccmp	x12, x10, #0x2, eq
    34e8:      	b.hs	0x3534 <_perry_fn_access_worker_ts__run$generic+0x4a0>
    34ec:      	ldurb	w12, [x8, #-0x8]
    34f0:      	ldrb	w10, [x8, #0x8]
    34f4:      	cmp	w12, #0xb
    34f8:      	ccmp	w10, #0x9, #0x2, eq
    34fc:      	b.hs	0x3534 <_perry_fn_access_worker_ts__run$generic+0x4a0>
    3500:      	ldr	w12, [x8]
    3504:      	cmp	w12, #0x8
    3508:      	b.lo	0x3534 <_perry_fn_access_worker_ts__run$generic+0x4a0>
    350c:      	cmp	w10, #0x3
    3510:      	b.le	0x364c <_perry_fn_access_worker_ts__run$generic+0x5b8>
    3514:      	cmp	w10, #0x5
    3518:      	b.gt	0x36b0 <_perry_fn_access_worker_ts__run$generic+0x61c>
    351c:      	cmp	w10, #0x4
    3520:      	b.eq	0x3748 <_perry_fn_access_worker_ts__run$generic+0x6b4>
    3524:      	cmp	w10, #0x5
    3528:      	b.ne	0x373c <_perry_fn_access_worker_ts__run$generic+0x6a8>
    352c:      	ldr	s0, [x8, #0x2c]
    3530:      	b	0x3740 <_perry_fn_access_worker_ts__run$generic+0x6ac>
    3534:      	cmp	x11, x21
    3538:      	b.ne	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    353c:      	mov	x10, #-0x20000000000    ; =-2199023255552
    3540:      	add	x10, x8, x10
    3544:      	lsr	x10, x10, #41
    3548:      	cmp	x10, #0x3f
    354c:      	b.hs	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    3550:      	ldursb	w10, [x8, #-0x7]
    3554:      	tbnz	w10, #0x1f, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    3558:      	ldurb	w10, [x8, #-0x8]
    355c:      	cmp	w10, #0x9
    3560:      	b.eq	0x3600 <_perry_fn_access_worker_ts__run$generic+0x56c>
    3564:      	cmp	w10, #0x2
    3568:      	b.eq	0x35bc <_perry_fn_access_worker_ts__run$generic+0x528>
    356c:      	cmp	w10, #0x1
    3570:      	b.ne	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    3574:      	ldr	w9, [x8]
    3578:      	mov	x10, x8
    357c:      	ldurh	w12, [x8, #-0x6]
    3580:      	adrp	x11, 0x3000 <ltmp0+0x3000>
		0000000000003580:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    3584:      	ldr	x11, [x11]
		0000000000003584:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    3588:      	ldrb	w11, [x11]
    358c:      	tbnz	w12, #0xa, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    3590:      	cbnz	w11, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    3594:      	cmp	w9, #0x8
    3598:      	b.lo	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    359c:      	ldr	w8, [x8, #0x4]
    35a0:      	cmp	w9, w8
    35a4:      	b.hi	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    35a8:      	ldr	d0, [x10, #0x40]
    35ac:      	fmov	x8, d0
    35b0:      	cmp	x8, x19
    35b4:      	fcsel	d0, d12, d0, eq
    35b8:      	b	0x3878 <_perry_fn_access_worker_ts__run$generic+0x7e4>
    35bc:      	ldr	x9, [x8, #0x8]
    35c0:      	cbz	x9, 0x3668 <_perry_fn_access_worker_ts__run$generic+0x5d4>
    35c4:      	ldr	x10, [x9, #0x60]
    35c8:      	cbz	x10, 0x3668 <_perry_fn_access_worker_ts__run$generic+0x5d4>
    35cc:      	ldurb	w8, [x10, #-0x8]
    35d0:      	cmp	w8, #0x1
    35d4:      	b.ne	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    35d8:      	ldursb	w8, [x10, #-0x7]
    35dc:      	tbnz	w8, #0x1f, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    35e0:      	ldr	w8, [x10]
    35e4:      	cmp	w8, #0x8
    35e8:      	b.lo	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    35ec:      	ldr	d0, [x10, #0x40]
    35f0:      	fmov	x8, d0
    35f4:      	cmp	x8, x19
    35f8:      	b.eq	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    35fc:      	b	0x3878 <_perry_fn_access_worker_ts__run$generic+0x7e4>
    3600:      	ldr	w11, [x8, #0x4]
    3604:      	ldr	x10, [x8, #0x20]
    3608:      	ldurh	w12, [x8, #-0x6]
    360c:      	tst	w12, #0xc00
    3610:      	mov	w12, #0x5841            ; =22593
    3614:      	movk	w12, #0x4c5a, lsl #16
    3618:      	ccmp	w11, w12, #0x0, eq
    361c:      	cset	w11, eq
    3620:      	cbz	x10, 0x36c8 <_perry_fn_access_worker_ts__run$generic+0x634>
    3624:      	tbz	w11, #0x0, 0x36c8 <_perry_fn_access_worker_ts__run$generic+0x634>
    3628:      	ldurb	w9, [x10, #-0x8]
    362c:      	cmp	w9, #0x1
    3630:      	b.ne	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    3634:      	ldursb	w9, [x10, #-0x7]
    3638:      	tbnz	w9, #0x1f, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    363c:      	ldr	w9, [x10]
    3640:      	str	w9, [x8]
    3644:      	mov	x8, x10
    3648:      	b	0x357c <_perry_fn_access_worker_ts__run$generic+0x4e8>
    364c:      	cbz	w10, 0x3734 <_perry_fn_access_worker_ts__run$generic+0x6a0>
    3650:      	cmp	w10, #0x2
    3654:      	b.eq	0x375c <_perry_fn_access_worker_ts__run$generic+0x6c8>
    3658:      	cmp	w10, #0x3
    365c:      	b.ne	0x373c <_perry_fn_access_worker_ts__run$generic+0x6a8>
    3660:      	ldr	h0, [x8, #0x1e]
    3664:      	b	0x3740 <_perry_fn_access_worker_ts__run$generic+0x6ac>
    3668:      	adrp	x10, 0x3000 <ltmp0+0x3000>
		0000000000003668:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__18
    366c:      	add	x10, x10, #0x0
		000000000000366c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__18
    3670:      	ldr	x11, [x10]
    3674:      	cmp	x11, #0x0
    3678:      	csel	x10, x10, x11, eq
    367c:      	ldr	x10, [x10]
    3680:      	cbz	x10, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    3684:      	tbnz	x10, #0x3f, 0x3768 <_perry_fn_access_worker_ts__run$generic+0x6d4>
    3688:      	ldp	w13, w12, [x8]
    368c:      	orr	x12, x12, x13, lsl #32
    3690:      	cmp	x12, x10
    3694:      	b.ne	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    3698:      	ldp	x13, x10, [x11, #0x8]
    369c:      	ldp	x12, x11, [x11, #0x18]
    36a0:      	cmp	x13, x11
    36a4:      	b.lo	0x3788 <_perry_fn_access_worker_ts__run$generic+0x6f4>
    36a8:      	cbz	x9, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    36ac:      	b	0x379c <_perry_fn_access_worker_ts__run$generic+0x708>
    36b0:      	cmp	w10, #0x6
    36b4:      	b.eq	0x3750 <_perry_fn_access_worker_ts__run$generic+0x6bc>
    36b8:      	cmp	w10, #0x7
    36bc:      	b.ne	0x373c <_perry_fn_access_worker_ts__run$generic+0x6a8>
    36c0:      	ldr	d0, [x8, #0x48]
    36c4:      	b	0x3878 <_perry_fn_access_worker_ts__run$generic+0x7e4>
    36c8:      	cmp	x10, #0x0
    36cc:      	ldr	w13, [x8]
    36d0:      	ldp	x10, x12, [x8, #0x28]
    36d4:      	ccmp	w13, #0x7, #0x0, eq
    36d8:      	ccmp	x10, #0x0, #0x4, hi
    36dc:      	ccmp	x12, #0x0, #0x4, ne
    36e0:      	csel	w11, wzr, w11, eq
    36e4:      	tbz	w11, #0x0, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    36e8:      	ldrb	w11, [x12]
    36ec:      	tbnz	w11, #0x7, 0x3794 <_perry_fn_access_worker_ts__run$generic+0x700>
    36f0:      	ldr	x8, [x8, #0x50]
    36f4:      	mov	w11, #0x6903            ; =26883
    36f8:      	movk	w11, #0x64, lsl #16
    36fc:      	cmp	x8, x11
    3700:      	b.eq	0x3708 <_perry_fn_access_worker_ts__run$generic+0x674>
    3704:      	cbnz	x8, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    3708:      	mov	w11, #0x6903            ; =26883
    370c:      	movk	w11, #0x64, lsl #16
    3710:      	cmp	x8, x11
    3714:      	b.ne	0x3828 <_perry_fn_access_worker_ts__run$generic+0x794>
    3718:      	ldr	x8, [x10, #0x38]
    371c:      	cbz	x8, 0x3828 <_perry_fn_access_worker_ts__run$generic+0x794>
    3720:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    3724:      	cmp	x8, x9
    3728:      	csel	x8, xzr, x8, eq
    372c:      	fmov	d1, x8
    3730:      	b	0x3a6c <_perry_fn_access_worker_ts__run$generic+0x9d8>
    3734:      	ldrsb	w8, [x8, #0x17]
    3738:      	b	0x3760 <_perry_fn_access_worker_ts__run$generic+0x6cc>
    373c:      	ldr	b0, [x8, #0x17]
    3740:      	ucvtf	d0, d0
    3744:      	b	0x3878 <_perry_fn_access_worker_ts__run$generic+0x7e4>
    3748:      	ldr	w8, [x8, #0x2c]
    374c:      	b	0x3760 <_perry_fn_access_worker_ts__run$generic+0x6cc>
    3750:      	ldr	s0, [x8, #0x2c]
    3754:      	fcvt	d0, s0
    3758:      	b	0x3878 <_perry_fn_access_worker_ts__run$generic+0x7e4>
    375c:      	ldrsh	w8, [x8, #0x1e]
    3760:      	scvtf	d0, w8
    3764:      	b	0x3878 <_perry_fn_access_worker_ts__run$generic+0x7e4>
    3768:      	cbz	x9, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    376c:      	ldr	x12, [x9, #0x30]
    3770:      	cmp	x12, x10
    3774:      	b.ne	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    3778:      	ldp	x13, x10, [x11, #0x8]
    377c:      	ldp	x12, x11, [x11, #0x18]
    3780:      	cmp	x13, x11
    3784:      	b.hs	0x379c <_perry_fn_access_worker_ts__run$generic+0x708>
    3788:      	add	x13, x8, x13, lsl #3
    378c:      	add	x13, x13, #0x10
    3790:      	b	0x37c0 <_perry_fn_access_worker_ts__run$generic+0x72c>
    3794:      	ldr	d0, [x10, #0x38]
    3798:      	b	0x3878 <_perry_fn_access_worker_ts__run$generic+0x7e4>
    379c:      	ldr	x15, [x9, #0x20]
    37a0:      	cmp	x15, #0x0
    37a4:      	csel	x14, x15, x9, ne
    37a8:      	cbz	x15, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    37ac:      	ldr	w15, [x14]
    37b0:      	cmp	x13, x15
    37b4:      	b.hs	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    37b8:      	add	x13, x14, x13, lsl #3
    37bc:      	add	x13, x13, #0x8
    37c0:      	ldr	d0, [x13]
    37c4:      	fcmp	d0, d11
    37c8:      	ccmp	x12, #0x7, #0x0, gt
    37cc:      	cset	w13, hi
    37d0:      	add	x12, x10, #0x7
    37d4:      	cmp	x12, x11
    37d8:      	b.hs	0x37ec <_perry_fn_access_worker_ts__run$generic+0x758>
    37dc:      	cbz	w13, 0x37ec <_perry_fn_access_worker_ts__run$generic+0x758>
    37e0:      	add	x8, x8, x12, lsl #3
    37e4:      	ldr	d0, [x8, #0x10]
    37e8:      	b	0x3878 <_perry_fn_access_worker_ts__run$generic+0x7e4>
    37ec:      	cbz	x9, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    37f0:      	cmp	x12, x11
    37f4:      	b.lo	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    37f8:      	eor	w8, w13, #0x1
    37fc:      	tbnz	w8, #0x0, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    3800:      	ldr	x11, [x9, #0x20]
    3804:      	cmp	x11, #0x0
    3808:      	csel	x8, x11, x9, ne
    380c:      	cbz	x11, 0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    3810:      	ldr	w9, [x8]
    3814:      	cmp	x12, x9
    3818:      	b.hs	0x3850 <_perry_fn_access_worker_ts__run$generic+0x7bc>
    381c:      	add	x8, x8, x10, lsl #3
    3820:      	ldr	d0, [x8, #0x40]
    3824:      	b	0x3878 <_perry_fn_access_worker_ts__run$generic+0x7e4>
    3828:      	fmov	d0, x9
    382c:      	fmov	d1, #7.00000000
    3830:      	adrp	x0, 0x3000 <ltmp0+0x3000>
		0000000000003830:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    3834:      	add	x0, x0, #0x0
		0000000000003834:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    3838:      	mov	w1, #0x2                ; =2
    383c:      	bl	0x383c <_perry_fn_access_worker_ts__run$generic+0x7a8>
		000000000000383c:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    3840:      	mov.16b	v1, v0
    3844:      	fmov	x8, d1
    3848:      	cmp	x8, x19
    384c:      	b.ne	0x3a6c <_perry_fn_access_worker_ts__run$generic+0x9d8>
    3850:      	mov	x8, x28
    3854:      	stp	x26, x28, [sp, #0x20]
    3858:      	fmov	d0, x8
    385c:      	str	x23, [sp, #0x18]
    3860:      	fmov	d1, #7.00000000
    3864:      	adrp	x0, 0x3000 <ltmp0+0x3000>
		0000000000003864:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__18
    3868:      	add	x0, x0, #0x0
		0000000000003868:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__18
    386c:      	bl	0x386c <_perry_fn_access_worker_ts__run$generic+0x7d8>
		000000000000386c:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    3870:      	ldp	x23, x26, [sp, #0x18]
    3874:      	ldr	x28, [sp, #0x28]
    3878:      	fmov	x8, d0
    387c:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    3880:      	and	x9, x8, x9
    3884:      	cmp	x9, x21
    3888:      	b.ne	0x38f4 <_perry_fn_access_worker_ts__run$generic+0x860>
    388c:      	and	x0, x8, #0xffffffffffff
    3890:      	lsr	x8, x0, #20
    3894:      	cbz	x8, 0x3a40 <_perry_fn_access_worker_ts__run$generic+0x9ac>
    3898:      	ldurb	w9, [x0, #-0x8]
    389c:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		000000000000389c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__20
    38a0:      	ldr	x8, [x8]
		00000000000038a0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__20
    38a4:      	cbz	x8, 0x396c <_perry_fn_access_worker_ts__run$generic+0x8d8>
    38a8:      	ldurh	w10, [x0, #-0x6]
    38ac:      	and	w10, w10, #0x800
    38b0:      	cmp	w9, #0x2
    38b4:      	ccmp	w10, #0x0, #0x0, eq
    38b8:      	b.ne	0x396c <_perry_fn_access_worker_ts__run$generic+0x8d8>
    38bc:      	ldr	w10, [x0, #0x4]
    38c0:      	orr	x9, x10, #0x4000000000000000
    38c4:      	cbz	w10, 0x3998 <_perry_fn_access_worker_ts__run$generic+0x904>
    38c8:      	ldr	x11, [x8]
    38cc:      	cmp	x9, x11
    38d0:      	b.ne	0x3998 <_perry_fn_access_worker_ts__run$generic+0x904>
    38d4:      	ldr	x2, [x8, #0x8]
    38d8:      	tbnz	w2, #0x1e, 0x3afc <_perry_fn_access_worker_ts__run$generic+0xa68>
    38dc:      	add	x11, x0, x2, lsl #3
    38e0:      	ldr	d1, [x11, #0x10]
    38e4:      	fmov	x11, d1
    38e8:      	cmp	x11, x19
    38ec:      	b.ne	0x3a6c <_perry_fn_access_worker_ts__run$generic+0x9d8>
    38f0:      	b	0x39c4 <_perry_fn_access_worker_ts__run$generic+0x930>
    38f4:      	lsr	x9, x8, #48
    38f8:      	mov	w10, #0x7ff9            ; =32761
    38fc:      	cmp	x9, x10
    3900:      	b.eq	0x394c <_perry_fn_access_worker_ts__run$generic+0x8b8>
    3904:      	mov	w10, #0x7ffe            ; =32766
    3908:      	cmp	w9, w10
    390c:      	b.ne	0x393c <_perry_fn_access_worker_ts__run$generic+0x8a8>
    3910:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		0000000000003910:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    3914:      	ldr	x9, [x9]
		0000000000003914:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    3918:      	stp	x28, x23, [sp, #0x20]
    391c:      	str	x26, [sp, #0x18]
    3920:      	and	x2, x9, #0xffffffffffff
    3924:      	mov	x0, #0x13               ; =19
    3928:      	movk	x0, #0xddae, lsl #32
    392c:      	movk	x0, #0x5556, lsl #48
    3930:      	mov	x1, x8
    3934:      	bl	0x3934 <_perry_fn_access_worker_ts__run$generic+0x8a0>
		0000000000003934:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    3938:      	b	0x3a60 <_perry_fn_access_worker_ts__run$generic+0x9cc>
    393c:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    3940:      	add	x9, x8, x9
    3944:      	cmp	x9, #0x2
    3948:      	b.lo	0x62bc <_perry_fn_access_worker_ts__run$generic+0x3228>
    394c:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		000000000000394c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    3950:      	ldr	x9, [x9]
		0000000000003950:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    3954:      	stp	x28, x23, [sp, #0x20]
    3958:      	str	x26, [sp, #0x18]
    395c:      	and	x1, x9, #0xffffffffffff
    3960:      	mov	x0, x8
    3964:      	bl	0x3964 <_perry_fn_access_worker_ts__run$generic+0x8d0>
		0000000000003964:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    3968:      	b	0x3a60 <_perry_fn_access_worker_ts__run$generic+0x9cc>
    396c:      	cmp	w9, #0x2
    3970:      	ccmp	x8, #0x0, #0x4, eq
    3974:      	b.eq	0x3a40 <_perry_fn_access_worker_ts__run$generic+0x9ac>
    3978:      	ldr	x9, [x8, #0x10]
    397c:      	cbz	x9, 0x3a40 <_perry_fn_access_worker_ts__run$generic+0x9ac>
    3980:      	ldr	x10, [x0, #0x8]
    3984:      	cbz	x10, 0x3a40 <_perry_fn_access_worker_ts__run$generic+0x9ac>
    3988:      	ldr	x10, [x10, #0x30]
    398c:      	cmp	x10, x9
    3990:      	b.eq	0x39b4 <_perry_fn_access_worker_ts__run$generic+0x920>
    3994:      	b	0x3a40 <_perry_fn_access_worker_ts__run$generic+0x9ac>
    3998:      	ldr	x11, [x8, #0x10]
    399c:      	cbz	x11, 0x39c4 <_perry_fn_access_worker_ts__run$generic+0x930>
    39a0:      	ldr	x12, [x0, #0x8]
    39a4:      	cbz	x12, 0x39c4 <_perry_fn_access_worker_ts__run$generic+0x930>
    39a8:      	ldr	x12, [x12, #0x30]
    39ac:      	cmp	x12, x11
    39b0:      	b.ne	0x39c4 <_perry_fn_access_worker_ts__run$generic+0x930>
    39b4:      	ldr	x8, [x8, #0x8]
    39b8:      	add	x8, x0, x8, lsl #3
    39bc:      	ldr	d1, [x8, #0x10]
    39c0:      	b	0x3a6c <_perry_fn_access_worker_ts__run$generic+0x9d8>
    39c4:      	ldr	x11, [x8, #0x18]
    39c8:      	cmp	x11, #0x0
    39cc:      	b.le	0x3a40 <_perry_fn_access_worker_ts__run$generic+0x9ac>
    39d0:      	ldr	x11, [x8, #0x20]
    39d4:      	ldr	x12, [x8, #0x30]
    39d8:      	ldr	x13, [x8, #0x40]
    39dc:      	cmp	x13, x9
    39e0:      	ldr	x14, [x8, #0x50]
    39e4:      	ccmp	x14, x9, #0x4, ne
    39e8:      	ccmp	x12, x9, #0x4, ne
    39ec:      	ccmp	x11, x9, #0x4, ne
    39f0:      	cset	w15, eq
    39f4:      	cbz	w10, 0x3a40 <_perry_fn_access_worker_ts__run$generic+0x9ac>
    39f8:      	cbz	w15, 0x3a40 <_perry_fn_access_worker_ts__run$generic+0x9ac>
    39fc:      	ldr	x10, [x8, #0x48]
    3a00:      	ldr	x15, [x8, #0x58]
    3a04:      	cmp	x14, x9
    3a08:      	csel	x14, x15, xzr, eq
    3a0c:      	cmp	x13, x9
    3a10:      	csel	x10, x10, x14, eq
    3a14:      	ldr	x13, [x8, #0x28]
    3a18:      	ldr	x8, [x8, #0x38]
    3a1c:      	cmp	x12, x9
    3a20:      	csel	x8, x8, x10, eq
    3a24:      	cmp	x11, x9
    3a28:      	csel	x8, x13, x8, eq
    3a2c:      	add	x8, x0, x8, lsl #3
    3a30:      	ldr	d1, [x8, #0x10]
    3a34:      	fmov	x8, d1
    3a38:      	cmp	x8, x19
    3a3c:      	b.ne	0x3a6c <_perry_fn_access_worker_ts__run$generic+0x9d8>
    3a40:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003a40:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    3a44:      	ldr	x8, [x8]
		0000000000003a44:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    3a48:      	stp	x28, x23, [sp, #0x20]
    3a4c:      	str	x26, [sp, #0x18]
    3a50:      	and	x1, x8, #0xffffffffffff
    3a54:      	adrp	x2, 0x3000 <ltmp0+0x3000>
		0000000000003a54:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__20
    3a58:      	add	x2, x2, #0x0
		0000000000003a58:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__20
    3a5c:      	bl	0x3a5c <_perry_fn_access_worker_ts__run$generic+0x9c8>
		0000000000003a5c:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    3a60:      	mov.16b	v1, v0
    3a64:      	ldp	x26, x28, [sp, #0x18]
    3a68:      	ldr	x23, [sp, #0x28]
    3a6c:      	fmov	d0, x23
    3a70:      	and	x9, x23, #0xffff000000000000
    3a74:      	fmov	x8, d1
    3a78:      	and	x10, x8, #0xffff000000000000
    3a7c:      	cmp	x8, x20
    3a80:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    3a84:      	ccmp	x10, x8, #0x2, hs
    3a88:      	cset	w8, hi
    3a8c:      	mov	x10, #0x1               ; =1
    3a90:      	movk	x10, #0x7fff, lsl #48
    3a94:      	cmp	x9, x10
    3a98:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    3a9c:      	ccmp	x23, x9, #0x0, lo
    3aa0:      	b.hi	0x3ab0 <_perry_fn_access_worker_ts__run$generic+0xa1c>
    3aa4:      	tbz	w8, #0x0, 0x3ab0 <_perry_fn_access_worker_ts__run$generic+0xa1c>
    3aa8:      	fadd	d0, d1, d0
    3aac:      	b	0x3abc <_perry_fn_access_worker_ts__run$generic+0xa28>
    3ab0:      	stp	x26, x28, [sp, #0x20]
    3ab4:      	bl	0x3ab4 <_perry_fn_access_worker_ts__run$generic+0xa20>
		0000000000003ab4:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    3ab8:      	ldp	x26, x28, [sp, #0x20]
    3abc:      	fmov	x23, d0
    3ac0:      	mov	x0, x23
    3ac4:      	ldr	w8, [x22]
    3ac8:      	cbz	w8, 0x3ad0 <_perry_fn_access_worker_ts__run$generic+0xa3c>
    3acc:      	bl	0x3acc <_perry_fn_access_worker_ts__run$generic+0xa38>
		0000000000003acc:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    3ad0:      	ldr	w8, [x24]
    3ad4:      	cbz	w8, 0x3aec <_perry_fn_access_worker_ts__run$generic+0xa58>
    3ad8:      	stp	x28, x26, [sp, #0x20]
    3adc:      	str	x23, [sp, #0x18]
    3ae0:      	bl	0x3ae0 <_perry_fn_access_worker_ts__run$generic+0xa4c>
		0000000000003ae0:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    3ae4:      	ldp	x23, x28, [sp, #0x18]
    3ae8:      	ldr	x26, [sp, #0x28]
    3aec:      	fadd	d8, d8, d13
    3af0:      	add	w27, w27, #0x1
    3af4:      	tbz	w25, #0x0, 0x33c4 <_perry_fn_access_worker_ts__run$generic+0x330>
    3af8:      	b	0x349c <_perry_fn_access_worker_ts__run$generic+0x408>
    3afc:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003afc:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    3b00:      	ldr	x8, [x8]
		0000000000003b00:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    3b04:      	stp	x28, x23, [sp, #0x20]
    3b08:      	str	x26, [sp, #0x18]
    3b0c:      	and	x1, x8, #0xffffffffffff
    3b10:      	adrp	x3, 0x3000 <ltmp0+0x3000>
		0000000000003b10:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__20
    3b14:      	add	x3, x3, #0x0
		0000000000003b14:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__20
    3b18:      	bl	0x3b18 <_perry_fn_access_worker_ts__run$generic+0xa84>
		0000000000003b18:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    3b1c:      	b	0x3a60 <_perry_fn_access_worker_ts__run$generic+0x9cc>
    3b20:      	mov	w9, #0x0                ; =0
    3b24:      	fmov	d0, x8
    3b28:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
    3b2c:      	fmov	d1, x8
    3b30:      	fcmp	d0, d1
    3b34:      	b.lt	0x3c6c <_perry_fn_access_worker_ts__run$generic+0xbd8>
    3b38:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003b38:  ARM64_RELOC_PAGE21	lCPI1_0
    3b3c:      	ldr	d1, [x8]
		0000000000003b3c:  ARM64_RELOC_PAGEOFF12	lCPI1_0
    3b40:      	fcmp	d0, d1
    3b44:      	mov	x25, x9
    3b48:      	b.hi	0x3c70 <_perry_fn_access_worker_ts__run$generic+0xbdc>
    3b4c:      	fcvtzs	w9, d0
    3b50:      	scvtf	d1, w9
    3b54:      	fcmp	d1, d0
    3b58:      	b.ne	0x31b8 <_perry_fn_access_worker_ts__run$generic+0x124>
    3b5c:      	mov	w25, #0x1               ; =1
    3b60:      	b	0x3c70 <_perry_fn_access_worker_ts__run$generic+0xbdc>
    3b64:      	mov	w10, #0x7fff            ; =32767
    3b68:      	cmp	x10, x8, lsr #48
    3b6c:      	b.ne	0x3bbc <_perry_fn_access_worker_ts__run$generic+0xb28>
    3b70:      	and	x0, x8, #0xffffffffffff
    3b74:      	cmp	x0, #0x1, lsl #12       ; =0x1000
    3b78:      	b.lo	0x3bbc <_perry_fn_access_worker_ts__run$generic+0xb28>
    3b7c:      	ldr	w8, [x0, #0x4]
    3b80:      	cmp	w8, #0x6
    3b84:      	b.ne	0x3bbc <_perry_fn_access_worker_ts__run$generic+0xb28>
    3b88:      	ldrb	w8, [x0, #0x14]
    3b8c:      	cmp	w8, #0x66
    3b90:      	b.ne	0x3bbc <_perry_fn_access_worker_ts__run$generic+0xb28>
    3b94:      	ldrb	w8, [x0, #0x19]
    3b98:      	cmp	w8, #0x73
    3b9c:      	b.ne	0x3bbc <_perry_fn_access_worker_ts__run$generic+0xb28>
    3ba0:      	stp	x28, x26, [sp, #0x20]
    3ba4:      	and	x1, x9, #0xffffffffffff
    3ba8:      	mov	x20, x11
    3bac:      	bl	0x3bac <_perry_fn_access_worker_ts__run$generic+0xb18>
		0000000000003bac:  ARM64_RELOC_BRANCH26	_js_string_equals
    3bb0:      	mov	x11, x20
    3bb4:      	ldp	x28, x26, [sp, #0x20]
    3bb8:      	cbnz	w0, 0x3318 <_perry_fn_access_worker_ts__run$generic+0x284>
    3bbc:      	mov	x8, x26
    3bc0:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    3bc4:      	cmp	x8, x9
    3bc8:      	b.lo	0x3c2c <_perry_fn_access_worker_ts__run$generic+0xb98>
    3bcc:      	and	x9, x8, #0xffff000000000000
    3bd0:      	mov	x10, #0x7fff000000000000 ; =9223090561878065152
    3bd4:      	cmp	x9, x10
    3bd8:      	b.hi	0x3c2c <_perry_fn_access_worker_ts__run$generic+0xb98>
    3bdc:      	mov	w20, #0x0               ; =0
    3be0:      	mov	w21, #0x0               ; =0
    3be4:      	b	0x5ac8 <_perry_fn_access_worker_ts__run$generic+0x2a34>
    3be8:      	mov	w9, #0x0                ; =0
    3bec:      	fmov	d0, x8
    3bf0:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
    3bf4:      	fmov	d1, x8
    3bf8:      	fcmp	d0, d1
    3bfc:      	b.lt	0x44f0 <_perry_fn_access_worker_ts__run$generic+0x145c>
    3c00:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003c00:  ARM64_RELOC_PAGE21	lCPI1_0
    3c04:      	ldr	d1, [x8]
		0000000000003c04:  ARM64_RELOC_PAGEOFF12	lCPI1_0
    3c08:      	fcmp	d0, d1
    3c0c:      	str	w9, [sp, #0x14]
    3c10:      	b.hi	0x44f4 <_perry_fn_access_worker_ts__run$generic+0x1460>
    3c14:      	fcvtzs	w9, d0
    3c18:      	frintz	d1, d0
    3c1c:      	fcmp	d1, d0
    3c20:      	cset	w8, eq
    3c24:      	str	w8, [sp, #0x14]
    3c28:      	b	0x44f4 <_perry_fn_access_worker_ts__run$generic+0x1460>
    3c2c:      	mov	w20, #0x0               ; =0
    3c30:      	fmov	d0, x8
    3c34:      	mov	x8, #-0x3e20000000000000 ; =-4476578029606273024
    3c38:      	fmov	d1, x8
    3c3c:      	fcmp	d0, d1
    3c40:      	b.lt	0x5ac4 <_perry_fn_access_worker_ts__run$generic+0x2a30>
    3c44:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003c44:  ARM64_RELOC_PAGE21	lCPI1_0
    3c48:      	ldr	d1, [x8]
		0000000000003c48:  ARM64_RELOC_PAGEOFF12	lCPI1_0
    3c4c:      	fcmp	d0, d1
    3c50:      	mov	x21, x20
    3c54:      	b.hi	0x5ac8 <_perry_fn_access_worker_ts__run$generic+0x2a34>
    3c58:      	fcvtzs	w20, d0
    3c5c:      	frintz	d1, d0
    3c60:      	fcmp	d1, d0
    3c64:      	cset	w21, eq
    3c68:      	b	0x5ac8 <_perry_fn_access_worker_ts__run$generic+0x2a34>
    3c6c:      	mov	x25, x9
    3c70:      	str	w9, [sp, #0x14]
    3c74:      	mov	w27, #0x0               ; =0
    3c78:      	mov	x23, #0x0               ; =0
    3c7c:      	mov	x19, #0x10              ; =16
    3c80:      	movk	x19, #0x7ffc, lsl #48
    3c84:      	mov	x21, #0x7ff9000000000000 ; =9221401712017801216
    3c88:      	fmov	d12, #17.00000000
    3c8c:      	adrp	x22, 0x3000 <ltmp0+0x3000>
		0000000000003c8c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    3c90:      	ldr	x22, [x22]
		0000000000003c90:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    3c94:      	mov	x20, #0x7ffd000000000000 ; =9222527611924643840
    3c98:      	fmov	d13, #7.00000000
    3c9c:      	mov	x8, #0x41f0000000000000 ; =4751297606875873280
    3ca0:      	fmov	d14, x8
    3ca4:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003ca4:  ARM64_RELOC_PAGE21	lCPI1_2
    3ca8:      	ldr	d15, [x8]
		0000000000003ca8:  ARM64_RELOC_PAGEOFF12	lCPI1_2
    3cac:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003cac:  ARM64_RELOC_PAGE21	lCPI1_3
    3cb0:      	ldr	d0, [x8]
		0000000000003cb0:  ARM64_RELOC_PAGEOFF12	lCPI1_3
    3cb4:      	str	d0, [sp, #0x8]
    3cb8:      	mov	x24, #0x7fff000000000000 ; =9223090561878065152
    3cbc:      	fmov	d11, #1.00000000
    3cc0:      	movi.2d	v8, #0000000000000000
    3cc4:      	movi.2d	v9, #0000000000000000
    3cc8:      	tbnz	w25, #0x0, 0x3dc0 <_perry_fn_access_worker_ts__run$generic+0xd2c>
    3ccc:      	mov	x8, x26
    3cd0:      	fmov	d1, x8
    3cd4:      	and	x9, x8, #0xffff000000000000
    3cd8:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    3cdc:      	cmp	x9, x10
    3ce0:      	b.eq	0x3d1c <_perry_fn_access_worker_ts__run$generic+0xc88>
    3ce4:      	cmp	x8, x21
    3ce8:      	b.lt	0x3d1c <_perry_fn_access_worker_ts__run$generic+0xc88>
    3cec:      	mov	x10, #-0x7ffc000000000001 ; =-9222246136947933185
    3cf0:      	add	x10, x8, x10
    3cf4:      	cmp	x10, #0x3
    3cf8:      	b.ls	0x3d1c <_perry_fn_access_worker_ts__run$generic+0xc88>
    3cfc:      	stp	x23, x26, [sp, #0x20]
    3d00:      	str	x28, [sp, #0x18]
    3d04:      	mov.16b	v0, v8
    3d08:      	bl	0x3d08 <_perry_fn_access_worker_ts__run$generic+0xc74>
		0000000000003d08:  ARM64_RELOC_BRANCH26	_js_rel_lt
    3d0c:      	mov.16b	v10, v0
    3d10:      	ldp	x28, x23, [sp, #0x18]
    3d14:      	ldr	x26, [sp, #0x28]
    3d18:      	b	0x3d88 <_perry_fn_access_worker_ts__run$generic+0xcf4>
    3d1c:      	mov	x12, #0x10              ; =16
    3d20:      	movk	x12, #0x7ffc, lsl #48
    3d24:      	sub	x10, x12, #0xc
    3d28:      	and	x11, x8, #0xfffffffffffffffe
    3d2c:      	mov	x19, #0x10              ; =16
    3d30:      	movk	x19, #0x7ffc, lsl #48
    3d34:      	sub	x12, x12, #0xe
    3d38:      	scvtf	d0, w8
    3d3c:      	mov	x13, #0x7ffe000000000000 ; =9222809086901354496
    3d40:      	cmp	x9, x13
    3d44:      	fcsel	d0, d0, d1, eq
    3d48:      	cmp	x11, x12
    3d4c:      	movi.2d	v1, #0000000000000000
    3d50:      	fcsel	d0, d1, d0, eq
    3d54:      	cmp	x8, x10
    3d58:      	fcsel	d0, d11, d0, eq
    3d5c:      	fmov	x8, d8
    3d60:      	scvtf	d1, w8
    3d64:      	mov	w9, #0x7ffe             ; =32766
    3d68:      	cmp	x9, x8, lsr #48
    3d6c:      	fcsel	d1, d1, d8, eq
    3d70:      	fcmp	d1, d0
    3d74:      	mov	w8, #0x8                ; =8
    3d78:      	csel	x8, x8, xzr, mi
    3d7c:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		0000000000003d7c:  ARM64_RELOC_PAGE21	lCPI1_1
    3d80:      	add	x9, x9, #0x0
		0000000000003d80:  ARM64_RELOC_PAGEOFF12	lCPI1_1
    3d84:      	ldr	d10, [x9, x8]
    3d88:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003d88:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    3d8c:      	ldr	x8, [x8]
		0000000000003d8c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    3d90:      	ldr	w8, [x8]
    3d94:      	cbz	w8, 0x3dac <_perry_fn_access_worker_ts__run$generic+0xd18>
    3d98:      	stp	x23, x26, [sp, #0x20]
    3d9c:      	str	x28, [sp, #0x18]
    3da0:      	bl	0x3da0 <_perry_fn_access_worker_ts__run$generic+0xd0c>
		0000000000003da0:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    3da4:      	ldp	x28, x23, [sp, #0x18]
    3da8:      	ldr	x26, [sp, #0x28]
    3dac:      	fmov	x8, d10
    3db0:      	sub	x9, x19, #0xc
    3db4:      	cmp	x8, x9
    3db8:      	b.ne	0x3268 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    3dbc:      	b	0x3dcc <_perry_fn_access_worker_ts__run$generic+0xd38>
    3dc0:      	ldr	w8, [sp, #0x14]
    3dc4:      	cmp	w27, w8
    3dc8:      	b.ge	0x3268 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    3dcc:      	fmov	x8, d9
    3dd0:      	cmp	x8, x21
    3dd4:      	b.lo	0x3e04 <_perry_fn_access_worker_ts__run$generic+0xd70>
    3dd8:      	and	x8, x8, #0xffff000000000000
    3ddc:      	cmp	x8, x24
    3de0:      	b.hi	0x3e04 <_perry_fn_access_worker_ts__run$generic+0xd70>
    3de4:      	stp	x23, x26, [sp, #0x20]
    3de8:      	str	x28, [sp, #0x18]
    3dec:      	fmov	d1, #17.00000000
    3df0:      	mov.16b	v0, v9
    3df4:      	bl	0x3df4 <_perry_fn_access_worker_ts__run$generic+0xd60>
		0000000000003df4:  ARM64_RELOC_BRANCH26	_js_dynamic_mul
    3df8:      	ldp	x28, x23, [sp, #0x18]
    3dfc:      	ldr	x26, [sp, #0x28]
    3e00:      	b	0x3e08 <_perry_fn_access_worker_ts__run$generic+0xd74>
    3e04:      	fmul	d0, d9, d12
    3e08:      	fadd	d0, d0, d13
    3e0c:      	adrp	x8, 0x3000 <ltmp0+0x3000>
		0000000000003e0c:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    3e10:      	ldr	d1, [x8]
		0000000000003e10:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    3e14:      	stp	x28, x23, [sp, #0x20]
    3e18:      	str	x26, [sp, #0x18]
    3e1c:      	bl	0x3e1c <_perry_fn_access_worker_ts__run$generic+0xd88>
		0000000000003e1c:  ARM64_RELOC_BRANCH26	_js_dynamic_mod
    3e20:      	mov.16b	v9, v0
    3e24:      	ldp	x26, x28, [sp, #0x18]
    3e28:      	ldr	x23, [sp, #0x28]
    3e2c:      	fmov	x8, d9
    3e30:      	mov	w9, #0x7fff             ; =32767
    3e34:      	cmp	x9, x8, lsr #48
    3e38:      	b.ne	0x3e44 <_perry_fn_access_worker_ts__run$generic+0xdb0>
    3e3c:      	mov.16b	v0, v9
    3e40:      	bl	0x3e40 <_perry_fn_access_worker_ts__run$generic+0xdac>
		0000000000003e40:  ARM64_RELOC_BRANCH26	_js_string_addref_if_heap_string
    3e44:      	mov	x0, x23
    3e48:      	ldr	w8, [x22]
    3e4c:      	cbz	w8, 0x3e54 <_perry_fn_access_worker_ts__run$generic+0xdc0>
    3e50:      	bl	0x3e50 <_perry_fn_access_worker_ts__run$generic+0xdbc>
		0000000000003e50:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    3e54:      	mov	x10, x28
    3e58:      	and	x8, x10, #0xffffffffffff
    3e5c:      	and	x12, x10, #0xffff000000000000
    3e60:      	cmp	x12, x20
    3e64:      	b.ne	0x3ec0 <_perry_fn_access_worker_ts__run$generic+0xe2c>
    3e68:      	adrp	x9, 0x3000 <ltmp0+0x3000>
		0000000000003e68:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    3e6c:      	ldr	x9, [x9]
		0000000000003e6c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    3e70:      	ldr	x9, [x9]
    3e74:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
    3e78:      	cmp	x9, #0x0
    3e7c:      	mov	x9, #0x7ffffff00000     ; =140737487306752
    3e80:      	ccmp	x11, x9, #0x2, eq
    3e84:      	b.hs	0x3ec0 <_perry_fn_access_worker_ts__run$generic+0xe2c>
    3e88:      	fcmp	d9, d14
    3e8c:      	b.pl	0x3ec0 <_perry_fn_access_worker_ts__run$generic+0xe2c>
    3e90:      	ldurb	w9, [x8, #-0x8]
    3e94:      	ldrb	w11, [x8, #0x8]
    3e98:      	fcmp	d9, #0.0
    3e9c:      	ccmp	w9, #0xb, #0x0, ge
    3ea0:      	ccmp	w11, #0x9, #0x2, eq
    3ea4:      	b.hs	0x3ec0 <_perry_fn_access_worker_ts__run$generic+0xe2c>
    3ea8:      	fcvtzs	x9, d9
    3eac:      	scvtf	d0, x9
    3eb0:      	ldr	w13, [x8]
    3eb4:      	fcmp	d9, d0
    3eb8:      	ccmp	x9, x13, #0x2, eq
    3ebc:      	b.lo	0x3f70 <_perry_fn_access_worker_ts__run$generic+0xedc>
    3ec0:      	cmp	x12, x20
    3ec4:      	b.ne	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3ec8:      	fcmp	d9, #0.0
    3ecc:      	b.lt	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3ed0:      	fcmp	d9, d15
    3ed4:      	b.pl	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3ed8:      	mov	x9, #-0x20000000000     ; =-2199023255552
    3edc:      	add	x9, x8, x9
    3ee0:      	lsr	x9, x9, #41
    3ee4:      	cmp	x9, #0x3f
    3ee8:      	b.hs	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3eec:      	fcvtzs	x9, d9
    3ef0:      	scvtf	d0, x9
    3ef4:      	fcmp	d9, d0
    3ef8:      	b.ne	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3efc:      	ldursb	w11, [x8, #-0x7]
    3f00:      	tbnz	w11, #0x1f, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3f04:      	ldurb	w11, [x8, #-0x8]
    3f08:      	cmp	w11, #0x9
    3f0c:      	b.eq	0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
    3f10:      	cmp	w11, #0x2
    3f14:      	b.eq	0x3fb8 <_perry_fn_access_worker_ts__run$generic+0xf24>
    3f18:      	cmp	w11, #0x1
    3f1c:      	b.ne	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3f20:      	ldr	w10, [x8]
    3f24:      	mov	x11, x8
    3f28:      	ldurh	w13, [x8, #-0x6]
    3f2c:      	adrp	x12, 0x3000 <ltmp0+0x3000>
		0000000000003f2c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    3f30:      	ldr	x12, [x12]
		0000000000003f30:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    3f34:      	ldrb	w12, [x12]
    3f38:      	ldr	w8, [x8, #0x4]
    3f3c:      	cmp	x10, x8
    3f40:      	b.hi	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3f44:      	tbnz	w13, #0xa, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3f48:      	cbnz	w12, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3f4c:      	cmp	x9, x10
    3f50:      	b.hs	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3f54:      	add	x8, x11, x9, lsl #3
    3f58:      	ldr	d0, [x8, #0x8]
    3f5c:      	fmov	x8, d0
    3f60:      	cmp	x8, x19
    3f64:      	ldr	d1, [sp, #0x8]
    3f68:      	fcsel	d0, d1, d0, eq
    3f6c:      	b	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c8>
    3f70:      	add	x8, x8, #0x10
    3f74:      	cmp	w11, #0x3
    3f78:      	b.le	0x3f9c <_perry_fn_access_worker_ts__run$generic+0xf08>
    3f7c:      	cmp	w11, #0x5
    3f80:      	b.gt	0x404c <_perry_fn_access_worker_ts__run$generic+0xfb8>
    3f84:      	cmp	w11, #0x4
    3f88:      	b.eq	0x40f8 <_perry_fn_access_worker_ts__run$generic+0x1064>
    3f8c:      	cmp	w11, #0x5
    3f90:      	b.ne	0x40ec <_perry_fn_access_worker_ts__run$generic+0x1058>
    3f94:      	ldr	s0, [x8, x9, lsl #2]
    3f98:      	b	0x40f0 <_perry_fn_access_worker_ts__run$generic+0x105c>
    3f9c:      	cbz	w11, 0x40e4 <_perry_fn_access_worker_ts__run$generic+0x1050>
    3fa0:      	cmp	w11, #0x2
    3fa4:      	b.eq	0x410c <_perry_fn_access_worker_ts__run$generic+0x1078>
    3fa8:      	cmp	w11, #0x3
    3fac:      	b.ne	0x40ec <_perry_fn_access_worker_ts__run$generic+0x1058>
    3fb0:      	ldr	h0, [x8, x9, lsl #1]
    3fb4:      	b	0x40f0 <_perry_fn_access_worker_ts__run$generic+0x105c>
    3fb8:      	ldr	x10, [x8, #0x8]
    3fbc:      	cbz	x10, 0x4064 <_perry_fn_access_worker_ts__run$generic+0xfd0>
    3fc0:      	ldr	x11, [x10, #0x60]
    3fc4:      	cbz	x11, 0x4064 <_perry_fn_access_worker_ts__run$generic+0xfd0>
    3fc8:      	ldurb	w8, [x11, #-0x8]
    3fcc:      	cmp	w8, #0x1
    3fd0:      	b.ne	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3fd4:      	ldursb	w8, [x11, #-0x7]
    3fd8:      	tbnz	w8, #0x1f, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3fdc:      	ldr	w8, [x11]
    3fe0:      	cmp	x9, x8
    3fe4:      	b.hs	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3fe8:      	add	x8, x11, x9, lsl #3
    3fec:      	ldr	d0, [x8, #0x8]
    3ff0:      	fmov	x8, d0
    3ff4:      	cmp	x8, x19
    3ff8:      	b.eq	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    3ffc:      	b	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c8>
    4000:      	ldr	w12, [x8, #0x4]
    4004:      	ldr	x11, [x8, #0x20]
    4008:      	ldurh	w13, [x8, #-0x6]
    400c:      	tst	w13, #0xc00
    4010:      	mov	w13, #0x5841            ; =22593
    4014:      	movk	w13, #0x4c5a, lsl #16
    4018:      	ccmp	w12, w13, #0x0, eq
    401c:      	cset	w12, eq
    4020:      	cbz	x11, 0x40ac <_perry_fn_access_worker_ts__run$generic+0x1018>
    4024:      	tbz	w12, #0x0, 0x40ac <_perry_fn_access_worker_ts__run$generic+0x1018>
    4028:      	ldurb	w10, [x11, #-0x8]
    402c:      	cmp	w10, #0x1
    4030:      	b.ne	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    4034:      	ldursb	w10, [x11, #-0x7]
    4038:      	tbnz	w10, #0x1f, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    403c:      	ldr	w10, [x11]
    4040:      	str	w10, [x8]
    4044:      	mov	x8, x11
    4048:      	b	0x3f28 <_perry_fn_access_worker_ts__run$generic+0xe94>
    404c:      	cmp	w11, #0x6
    4050:      	b.eq	0x4100 <_perry_fn_access_worker_ts__run$generic+0x106c>
    4054:      	cmp	w11, #0x7
    4058:      	b.ne	0x40ec <_perry_fn_access_worker_ts__run$generic+0x1058>
    405c:      	ldr	d0, [x8, x9, lsl #3]
    4060:      	b	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c8>
    4064:      	adrp	x12, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004064:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__21
    4068:      	add	x12, x12, #0x0
		0000000000004068:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__21
    406c:      	ldr	x11, [x12]
    4070:      	cmp	x11, #0x0
    4074:      	csel	x12, x12, x11, eq
    4078:      	ldr	x12, [x12]
    407c:      	cbz	x12, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    4080:      	tbnz	x12, #0x3f, 0x4118 <_perry_fn_access_worker_ts__run$generic+0x1084>
    4084:      	ldp	w14, w13, [x8]
    4088:      	orr	x13, x13, x14, lsl #32
    408c:      	cmp	x13, x12
    4090:      	b.ne	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    4094:      	ldp	x14, x12, [x11, #0x8]
    4098:      	ldp	x13, x11, [x11, #0x18]
    409c:      	cmp	x14, x11
    40a0:      	b.lo	0x4138 <_perry_fn_access_worker_ts__run$generic+0x10a4>
    40a4:      	cbz	x10, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    40a8:      	b	0x4188 <_perry_fn_access_worker_ts__run$generic+0x10f4>
    40ac:      	cmp	x11, #0x0
    40b0:      	ldr	w14, [x8]
    40b4:      	ldp	x11, x13, [x8, #0x28]
    40b8:      	ccmp	x9, x14, #0x2, eq
    40bc:      	ccmp	x11, #0x0, #0x4, lo
    40c0:      	ccmp	x13, #0x0, #0x4, ne
    40c4:      	csel	w12, wzr, w12, eq
    40c8:      	tbz	w12, #0x0, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    40cc:      	lsr	x12, x9, #6
    40d0:      	ldr	x12, [x13, x12, lsl #3]
    40d4:      	lsr	x12, x12, x9
    40d8:      	tbz	w12, #0x0, 0x4144 <_perry_fn_access_worker_ts__run$generic+0x10b0>
    40dc:      	ldr	d0, [x11, x9, lsl #3]
    40e0:      	b	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c8>
    40e4:      	ldrsb	w8, [x8, x9]
    40e8:      	b	0x4110 <_perry_fn_access_worker_ts__run$generic+0x107c>
    40ec:      	ldr	b0, [x8, x9]
    40f0:      	ucvtf	d0, d0
    40f4:      	b	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c8>
    40f8:      	ldr	w8, [x8, x9, lsl #2]
    40fc:      	b	0x4110 <_perry_fn_access_worker_ts__run$generic+0x107c>
    4100:      	ldr	s0, [x8, x9, lsl #2]
    4104:      	fcvt	d0, s0
    4108:      	b	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c8>
    410c:      	ldrsh	w8, [x8, x9, lsl #1]
    4110:      	scvtf	d0, w8
    4114:      	b	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c8>
    4118:      	cbz	x10, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    411c:      	ldr	x13, [x10, #0x30]
    4120:      	cmp	x13, x12
    4124:      	b.ne	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    4128:      	ldp	x14, x12, [x11, #0x8]
    412c:      	ldp	x13, x11, [x11, #0x18]
    4130:      	cmp	x14, x11
    4134:      	b.hs	0x4188 <_perry_fn_access_worker_ts__run$generic+0x10f4>
    4138:      	add	x14, x8, x14, lsl #3
    413c:      	add	x14, x14, #0x10
    4140:      	b	0x41ac <_perry_fn_access_worker_ts__run$generic+0x1118>
    4144:      	ldr	x8, [x8, #0x50]
    4148:      	mov	w12, #0x6903            ; =26883
    414c:      	movk	w12, #0x64, lsl #16
    4150:      	cmp	x8, x12
    4154:      	b.eq	0x415c <_perry_fn_access_worker_ts__run$generic+0x10c8>
    4158:      	cbnz	x8, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    415c:      	mov	w12, #0x6903            ; =26883
    4160:      	movk	w12, #0x64, lsl #16
    4164:      	cmp	x8, x12
    4168:      	b.ne	0x4214 <_perry_fn_access_worker_ts__run$generic+0x1180>
    416c:      	ldr	x8, [x11, x9, lsl #3]
    4170:      	cbz	x8, 0x4214 <_perry_fn_access_worker_ts__run$generic+0x1180>
    4174:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    4178:      	cmp	x8, x9
    417c:      	csel	x8, xzr, x8, eq
    4180:      	fmov	d1, x8
    4184:      	b	0x4444 <_perry_fn_access_worker_ts__run$generic+0x13b0>
    4188:      	ldr	x16, [x10, #0x20]
    418c:      	cmp	x16, #0x0
    4190:      	csel	x15, x16, x10, ne
    4194:      	cbz	x16, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    4198:      	ldr	w16, [x15]
    419c:      	cmp	x14, x16
    41a0:      	b.hs	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    41a4:      	add	x14, x15, x14, lsl #3
    41a8:      	add	x14, x14, #0x8
    41ac:      	ldr	d0, [x14]
    41b0:      	fcmp	d9, d0
    41b4:      	ccmp	x13, x9, #0x0, mi
    41b8:      	cset	w13, hi
    41bc:      	add	x9, x12, x9
    41c0:      	cmp	x9, x11
    41c4:      	ccmp	w13, #0x0, #0x4, lo
    41c8:      	b.ne	0x4208 <_perry_fn_access_worker_ts__run$generic+0x1174>
    41cc:      	cbz	x10, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    41d0:      	cmp	x9, x11
    41d4:      	b.lo	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    41d8:      	eor	w8, w13, #0x1
    41dc:      	tbnz	w8, #0x0, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    41e0:      	ldr	x11, [x10, #0x20]
    41e4:      	cmp	x11, #0x0
    41e8:      	csel	x8, x11, x10, ne
    41ec:      	cbz	x11, 0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    41f0:      	ldr	w10, [x8]
    41f4:      	cmp	x9, x10
    41f8:      	b.hs	0x423c <_perry_fn_access_worker_ts__run$generic+0x11a8>
    41fc:      	add	x8, x8, x9, lsl #3
    4200:      	ldr	d0, [x8, #0x8]
    4204:      	b	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c8>
    4208:      	add	x8, x8, x9, lsl #3
    420c:      	ldr	d0, [x8, #0x10]
    4210:      	b	0x425c <_perry_fn_access_worker_ts__run$generic+0x11c8>
    4214:      	fmov	d0, x10
    4218:      	mov.16b	v1, v9
    421c:      	adrp	x0, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		000000000000421c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    4220:      	add	x0, x0, #0x0
		0000000000004220:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    4224:      	mov	w1, #0x2                ; =2
    4228:      	bl	0x4228 <_perry_fn_access_worker_ts__run$generic+0x1194>
		0000000000004228:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    422c:      	mov.16b	v1, v0
    4230:      	fmov	x8, d1
    4234:      	cmp	x8, x19
    4238:      	b.ne	0x4444 <_perry_fn_access_worker_ts__run$generic+0x13b0>
    423c:      	fmov	d0, x28
    4240:      	str	x23, [sp, #0x28]
    4244:      	mov.16b	v1, v9
    4248:      	adrp	x0, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004248:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__21
    424c:      	add	x0, x0, #0x0
		000000000000424c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__21
    4250:      	bl	0x4250 <_perry_fn_access_worker_ts__run$generic+0x11bc>
		0000000000004250:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    4254:      	ldp	x28, x23, [sp, #0x20]
    4258:      	ldr	x26, [sp, #0x18]
    425c:      	fmov	x8, d0
    4260:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    4264:      	and	x9, x8, x9
    4268:      	cmp	x9, x20
    426c:      	b.ne	0x42d8 <_perry_fn_access_worker_ts__run$generic+0x1244>
    4270:      	and	x0, x8, #0xffffffffffff
    4274:      	lsr	x8, x0, #20
    4278:      	cbz	x8, 0x441c <_perry_fn_access_worker_ts__run$generic+0x1388>
    427c:      	ldurb	w9, [x0, #-0x8]
    4280:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004280:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__23
    4284:      	ldr	x8, [x8]
		0000000000004284:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__23
    4288:      	cbz	x8, 0x4348 <_perry_fn_access_worker_ts__run$generic+0x12b4>
    428c:      	ldurh	w10, [x0, #-0x6]
    4290:      	and	w10, w10, #0x800
    4294:      	cmp	w9, #0x2
    4298:      	ccmp	w10, #0x0, #0x0, eq
    429c:      	b.ne	0x4348 <_perry_fn_access_worker_ts__run$generic+0x12b4>
    42a0:      	ldr	w10, [x0, #0x4]
    42a4:      	orr	x9, x10, #0x4000000000000000
    42a8:      	ldr	x11, [x8]
    42ac:      	cmp	w10, #0x0
    42b0:      	ccmp	x9, x11, #0x0, ne
    42b4:      	b.eq	0x4380 <_perry_fn_access_worker_ts__run$generic+0x12ec>
    42b8:      	ldr	x11, [x8, #0x10]
    42bc:      	cbz	x11, 0x439c <_perry_fn_access_worker_ts__run$generic+0x1308>
    42c0:      	ldr	x12, [x0, #0x8]
    42c4:      	cbz	x12, 0x439c <_perry_fn_access_worker_ts__run$generic+0x1308>
    42c8:      	ldr	x12, [x12, #0x30]
    42cc:      	cmp	x12, x11
    42d0:      	b.eq	0x4370 <_perry_fn_access_worker_ts__run$generic+0x12dc>
    42d4:      	b	0x439c <_perry_fn_access_worker_ts__run$generic+0x1308>
    42d8:      	lsr	x9, x8, #48
    42dc:      	mov	w10, #0x7ff9            ; =32761
    42e0:      	cmp	x9, x10
    42e4:      	b.eq	0x432c <_perry_fn_access_worker_ts__run$generic+0x1298>
    42e8:      	mov	w10, #0x7ffe            ; =32766
    42ec:      	cmp	w9, w10
    42f0:      	b.ne	0x431c <_perry_fn_access_worker_ts__run$generic+0x1288>
    42f4:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		00000000000042f4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    42f8:      	ldr	x9, [x9]
		00000000000042f8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    42fc:      	str	x23, [sp, #0x28]
    4300:      	and	x2, x9, #0xffffffffffff
    4304:      	mov	x0, #0x16               ; =22
    4308:      	movk	x0, #0xddae, lsl #32
    430c:      	movk	x0, #0x5556, lsl #48
    4310:      	mov	x1, x8
    4314:      	bl	0x4314 <_perry_fn_access_worker_ts__run$generic+0x1280>
		0000000000004314:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    4318:      	b	0x4438 <_perry_fn_access_worker_ts__run$generic+0x13a4>
    431c:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    4320:      	add	x9, x8, x9
    4324:      	cmp	x9, #0x2
    4328:      	b.lo	0x62bc <_perry_fn_access_worker_ts__run$generic+0x3228>
    432c:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		000000000000432c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    4330:      	ldr	x9, [x9]
		0000000000004330:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4334:      	str	x23, [sp, #0x28]
    4338:      	and	x1, x9, #0xffffffffffff
    433c:      	mov	x0, x8
    4340:      	bl	0x4340 <_perry_fn_access_worker_ts__run$generic+0x12ac>
		0000000000004340:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    4344:      	b	0x4438 <_perry_fn_access_worker_ts__run$generic+0x13a4>
    4348:      	cmp	w9, #0x2
    434c:      	ccmp	x8, #0x0, #0x4, eq
    4350:      	b.eq	0x441c <_perry_fn_access_worker_ts__run$generic+0x1388>
    4354:      	ldr	x9, [x8, #0x10]
    4358:      	cbz	x9, 0x441c <_perry_fn_access_worker_ts__run$generic+0x1388>
    435c:      	ldr	x10, [x0, #0x8]
    4360:      	cbz	x10, 0x441c <_perry_fn_access_worker_ts__run$generic+0x1388>
    4364:      	ldr	x10, [x10, #0x30]
    4368:      	cmp	x10, x9
    436c:      	b.ne	0x441c <_perry_fn_access_worker_ts__run$generic+0x1388>
    4370:      	ldr	x8, [x8, #0x8]
    4374:      	add	x8, x0, x8, lsl #3
    4378:      	ldr	d1, [x8, #0x10]
    437c:      	b	0x4444 <_perry_fn_access_worker_ts__run$generic+0x13b0>
    4380:      	ldr	x2, [x8, #0x8]
    4384:      	tbnz	w2, #0x1e, 0x44d0 <_perry_fn_access_worker_ts__run$generic+0x143c>
    4388:      	add	x11, x0, x2, lsl #3
    438c:      	ldr	d1, [x11, #0x10]
    4390:      	fmov	x11, d1
    4394:      	cmp	x11, x19
    4398:      	b.ne	0x4444 <_perry_fn_access_worker_ts__run$generic+0x13b0>
    439c:      	ldr	x11, [x8, #0x18]
    43a0:      	cmp	x11, #0x0
    43a4:      	b.le	0x441c <_perry_fn_access_worker_ts__run$generic+0x1388>
    43a8:      	ldr	x11, [x8, #0x20]
    43ac:      	ldr	x12, [x8, #0x30]
    43b0:      	ldr	x13, [x8, #0x40]
    43b4:      	cmp	x13, x9
    43b8:      	ldr	x14, [x8, #0x50]
    43bc:      	ccmp	x14, x9, #0x4, ne
    43c0:      	ccmp	x12, x9, #0x4, ne
    43c4:      	ccmp	x11, x9, #0x4, ne
    43c8:      	cset	w15, eq
    43cc:      	cmp	w10, #0x0
    43d0:      	ccmp	w15, #0x0, #0x4, ne
    43d4:      	b.eq	0x441c <_perry_fn_access_worker_ts__run$generic+0x1388>
    43d8:      	ldr	x10, [x8, #0x48]
    43dc:      	ldr	x15, [x8, #0x58]
    43e0:      	cmp	x14, x9
    43e4:      	csel	x14, x15, xzr, eq
    43e8:      	cmp	x13, x9
    43ec:      	csel	x10, x10, x14, eq
    43f0:      	ldr	x13, [x8, #0x28]
    43f4:      	ldr	x8, [x8, #0x38]
    43f8:      	cmp	x12, x9
    43fc:      	csel	x8, x8, x10, eq
    4400:      	cmp	x11, x9
    4404:      	csel	x8, x13, x8, eq
    4408:      	add	x8, x0, x8, lsl #3
    440c:      	ldr	d1, [x8, #0x10]
    4410:      	fmov	x8, d1
    4414:      	cmp	x8, x19
    4418:      	b.ne	0x4444 <_perry_fn_access_worker_ts__run$generic+0x13b0>
    441c:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		000000000000441c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    4420:      	ldr	x8, [x8]
		0000000000004420:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4424:      	str	x23, [sp, #0x28]
    4428:      	and	x1, x8, #0xffffffffffff
    442c:      	adrp	x2, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		000000000000442c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__23
    4430:      	add	x2, x2, #0x0
		0000000000004430:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__23
    4434:      	bl	0x4434 <_perry_fn_access_worker_ts__run$generic+0x13a0>
		0000000000004434:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    4438:      	mov.16b	v1, v0
    443c:      	ldp	x26, x28, [sp, #0x18]
    4440:      	ldr	x23, [sp, #0x28]
    4444:      	fmov	d0, x23
    4448:      	and	x9, x23, #0xffff000000000000
    444c:      	fmov	x8, d1
    4450:      	and	x10, x8, #0xffff000000000000
    4454:      	cmp	x8, x21
    4458:      	ccmp	x10, x24, #0x2, hs
    445c:      	cset	w8, hi
    4460:      	mov	x10, #0x1               ; =1
    4464:      	movk	x10, #0x7fff, lsl #48
    4468:      	cmp	x9, x10
    446c:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    4470:      	ccmp	x23, x9, #0x0, lo
    4474:      	b.hi	0x4484 <_perry_fn_access_worker_ts__run$generic+0x13f0>
    4478:      	tbz	w8, #0x0, 0x4484 <_perry_fn_access_worker_ts__run$generic+0x13f0>
    447c:      	fadd	d0, d1, d0
    4480:      	b	0x448c <_perry_fn_access_worker_ts__run$generic+0x13f8>
    4484:      	bl	0x4484 <_perry_fn_access_worker_ts__run$generic+0x13f0>
		0000000000004484:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    4488:      	ldp	x26, x28, [sp, #0x18]
    448c:      	fmov	x23, d0
    4490:      	mov	x0, x23
    4494:      	ldr	w8, [x22]
    4498:      	cbz	w8, 0x44a0 <_perry_fn_access_worker_ts__run$generic+0x140c>
    449c:      	bl	0x449c <_perry_fn_access_worker_ts__run$generic+0x1408>
		000000000000449c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    44a0:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		00000000000044a0:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    44a4:      	ldr	x8, [x8]
		00000000000044a4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    44a8:      	ldr	w8, [x8]
    44ac:      	cbz	w8, 0x44c0 <_perry_fn_access_worker_ts__run$generic+0x142c>
    44b0:      	str	x23, [sp, #0x28]
    44b4:      	bl	0x44b4 <_perry_fn_access_worker_ts__run$generic+0x1420>
		00000000000044b4:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    44b8:      	ldp	x28, x23, [sp, #0x20]
    44bc:      	ldr	x26, [sp, #0x18]
    44c0:      	fadd	d8, d8, d11
    44c4:      	add	w27, w27, #0x1
    44c8:      	tbz	w25, #0x0, 0x3ccc <_perry_fn_access_worker_ts__run$generic+0xc38>
    44cc:      	b	0x3dc0 <_perry_fn_access_worker_ts__run$generic+0xd2c>
    44d0:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		00000000000044d0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    44d4:      	ldr	x8, [x8]
		00000000000044d4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    44d8:      	str	x23, [sp, #0x28]
    44dc:      	and	x1, x8, #0xffffffffffff
    44e0:      	adrp	x3, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		00000000000044e0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__23
    44e4:      	add	x3, x3, #0x0
		00000000000044e4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__23
    44e8:      	bl	0x44e8 <_perry_fn_access_worker_ts__run$generic+0x1454>
		00000000000044e8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    44ec:      	b	0x4438 <_perry_fn_access_worker_ts__run$generic+0x13a4>
    44f0:      	str	w9, [sp, #0x14]
    44f4:      	str	w9, [sp, #0x8]
    44f8:      	mov	w20, #0x0               ; =0
    44fc:      	mov	x23, #0x0               ; =0
    4500:      	mov	x24, #0x7ffd000000000000 ; =9222527611924643840
    4504:      	ldr	d10, [x22]
		0000000000004504:  ARM64_RELOC_PAGEOFF12	lCPI1_2
    4508:      	ldr	d11, [x11]
		0000000000004508:  ARM64_RELOC_PAGEOFF12	lCPI1_3
    450c:      	mov	x22, #0x7ff9000000000000 ; =9221401712017801216
    4510:      	mov	x25, #0x7fff000000000000 ; =9223090561878065152
    4514:      	mov	x21, #0x7ff8ffffffffffff ; =9221401712017801215
    4518:      	mov	x8, #0x41f0000000000000 ; =4751297606875873280
    451c:      	fmov	d12, x8
    4520:      	movi.2d	v13, #0000000000000000
    4524:      	fmov	d14, #1.00000000
    4528:      	ldr	w8, [sp, #0x14]
    452c:      	tbz	w8, #0x0, 0x4544 <_perry_fn_access_worker_ts__run$generic+0x14b0>
    4530:      	ldr	w8, [sp, #0x8]
    4534:      	cmp	w20, w8
    4538:      	b.ge	0x3268 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    453c:      	scvtf	d8, w20
    4540:      	b	0x4634 <_perry_fn_access_worker_ts__run$generic+0x15a0>
    4544:      	scvtf	d8, w20
    4548:      	mov	x8, x26
    454c:      	fmov	d1, x8
    4550:      	and	x9, x8, #0xffff000000000000
    4554:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    4558:      	cmp	x9, x10
    455c:      	b.eq	0x4598 <_perry_fn_access_worker_ts__run$generic+0x1504>
    4560:      	cmp	x8, x22
    4564:      	b.lt	0x4598 <_perry_fn_access_worker_ts__run$generic+0x1504>
    4568:      	mov	x10, #-0x7ffc000000000001 ; =-9222246136947933185
    456c:      	add	x10, x8, x10
    4570:      	cmp	x10, #0x3
    4574:      	b.ls	0x4598 <_perry_fn_access_worker_ts__run$generic+0x1504>
    4578:      	stp	x26, x23, [sp, #0x20]
    457c:      	str	x28, [sp, #0x18]
    4580:      	mov.16b	v0, v8
    4584:      	bl	0x4584 <_perry_fn_access_worker_ts__run$generic+0x14f0>
		0000000000004584:  ARM64_RELOC_BRANCH26	_js_rel_lt
    4588:      	mov.16b	v9, v0
    458c:      	ldp	x28, x26, [sp, #0x18]
    4590:      	ldr	x23, [sp, #0x28]
    4594:      	b	0x4600 <_perry_fn_access_worker_ts__run$generic+0x156c>
    4598:      	mov	x12, #0x10              ; =16
    459c:      	movk	x12, #0x7ffc, lsl #48
    45a0:      	sub	x10, x12, #0xc
    45a4:      	and	x11, x8, #0xfffffffffffffffe
    45a8:      	mov	x19, #0x10              ; =16
    45ac:      	movk	x19, #0x7ffc, lsl #48
    45b0:      	sub	x12, x12, #0xe
    45b4:      	scvtf	d0, w8
    45b8:      	mov	x13, #0x7ffe000000000000 ; =9222809086901354496
    45bc:      	cmp	x9, x13
    45c0:      	fcsel	d0, d0, d1, eq
    45c4:      	cmp	x11, x12
    45c8:      	fcsel	d0, d13, d0, eq
    45cc:      	cmp	x8, x10
    45d0:      	fcsel	d0, d14, d0, eq
    45d4:      	fmov	x8, d8
    45d8:      	scvtf	d1, w8
    45dc:      	mov	w9, #0x7ffe             ; =32766
    45e0:      	cmp	x9, x8, lsr #48
    45e4:      	fcsel	d1, d1, d8, eq
    45e8:      	fcmp	d1, d0
    45ec:      	mov	w8, #0x8                ; =8
    45f0:      	csel	x8, x8, xzr, mi
    45f4:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		00000000000045f4:  ARM64_RELOC_PAGE21	lCPI1_1
    45f8:      	add	x9, x9, #0x0
		00000000000045f8:  ARM64_RELOC_PAGEOFF12	lCPI1_1
    45fc:      	ldr	d9, [x9, x8]
    4600:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004600:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    4604:      	ldr	x8, [x8]
		0000000000004604:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    4608:      	ldr	w8, [x8]
    460c:      	cbz	w8, 0x4624 <_perry_fn_access_worker_ts__run$generic+0x1590>
    4610:      	stp	x28, x26, [sp, #0x20]
    4614:      	str	x23, [sp, #0x18]
    4618:      	bl	0x4618 <_perry_fn_access_worker_ts__run$generic+0x1584>
		0000000000004618:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    461c:      	ldp	x23, x28, [sp, #0x18]
    4620:      	ldr	x26, [sp, #0x28]
    4624:      	fmov	x8, d9
    4628:      	sub	x9, x19, #0xc
    462c:      	cmp	x8, x9
    4630:      	b.ne	0x3268 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    4634:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004634:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    4638:      	ldr	d1, [x8]
		0000000000004638:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    463c:      	stp	x26, x23, [sp, #0x20]
    4640:      	str	x28, [sp, #0x18]
    4644:      	mov.16b	v0, v8
    4648:      	bl	0x4648 <_perry_fn_access_worker_ts__run$generic+0x15b4>
		0000000000004648:  ARM64_RELOC_BRANCH26	_js_dynamic_mod
    464c:      	mov.16b	v8, v0
    4650:      	ldp	x28, x26, [sp, #0x18]
    4654:      	ldr	x23, [sp, #0x28]
    4658:      	mov	x0, x23
    465c:      	ldr	w8, [x27]
    4660:      	cbz	w8, 0x4668 <_perry_fn_access_worker_ts__run$generic+0x15d4>
    4664:      	bl	0x4664 <_perry_fn_access_worker_ts__run$generic+0x15d0>
		0000000000004664:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    4668:      	mov	x10, x28
    466c:      	and	x8, x10, #0xffffffffffff
    4670:      	and	x12, x10, #0xffff000000000000
    4674:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004674:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    4678:      	ldr	x9, [x9]
		0000000000004678:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    467c:      	ldr	x9, [x9]
    4680:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
    4684:      	cmp	x12, x24
    4688:      	ccmp	x9, #0x0, #0x0, eq
    468c:      	mov	x9, #0x7ffffff00000     ; =140737487306752
    4690:      	ccmp	x11, x9, #0x2, eq
    4694:      	b.hs	0x46d8 <_perry_fn_access_worker_ts__run$generic+0x1644>
    4698:      	mov	x9, #0x41f0000000000000 ; =4751297606875873280
    469c:      	fmov	d0, x9
    46a0:      	fcmp	d8, d0
    46a4:      	b.pl	0x46d8 <_perry_fn_access_worker_ts__run$generic+0x1644>
    46a8:      	ldurb	w9, [x8, #-0x8]
    46ac:      	ldrb	w11, [x8, #0x8]
    46b0:      	fcmp	d8, #0.0
    46b4:      	ccmp	w9, #0xb, #0x0, ge
    46b8:      	ccmp	w11, #0x9, #0x2, eq
    46bc:      	b.hs	0x46d8 <_perry_fn_access_worker_ts__run$generic+0x1644>
    46c0:      	fcvtzs	x9, d8
    46c4:      	scvtf	d0, x9
    46c8:      	ldr	w13, [x8]
    46cc:      	fcmp	d8, d0
    46d0:      	ccmp	x9, x13, #0x2, eq
    46d4:      	b.lo	0x4784 <_perry_fn_access_worker_ts__run$generic+0x16f0>
    46d8:      	cmp	x12, x24
    46dc:      	b.ne	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    46e0:      	fcmp	d8, #0.0
    46e4:      	b.lt	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    46e8:      	fcmp	d8, d10
    46ec:      	b.pl	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    46f0:      	mov	x9, #-0x20000000000     ; =-2199023255552
    46f4:      	add	x9, x8, x9
    46f8:      	lsr	x9, x9, #41
    46fc:      	cmp	x9, #0x3f
    4700:      	b.hs	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4704:      	fcvtzs	x9, d8
    4708:      	scvtf	d0, x9
    470c:      	fcmp	d8, d0
    4710:      	b.ne	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4714:      	ldursb	w11, [x8, #-0x7]
    4718:      	tbnz	w11, #0x1f, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    471c:      	ldurb	w11, [x8, #-0x8]
    4720:      	cmp	w11, #0x9
    4724:      	b.eq	0x4814 <_perry_fn_access_worker_ts__run$generic+0x1780>
    4728:      	cmp	w11, #0x2
    472c:      	b.eq	0x47cc <_perry_fn_access_worker_ts__run$generic+0x1738>
    4730:      	cmp	w11, #0x1
    4734:      	b.ne	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4738:      	ldr	w10, [x8]
    473c:      	mov	x11, x8
    4740:      	ldurh	w13, [x8, #-0x6]
    4744:      	adrp	x12, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004744:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    4748:      	ldr	x12, [x12]
		0000000000004748:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    474c:      	ldrb	w12, [x12]
    4750:      	ldr	w8, [x8, #0x4]
    4754:      	cmp	x10, x8
    4758:      	b.hi	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    475c:      	tbnz	w13, #0xa, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4760:      	cbnz	w12, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4764:      	cmp	x9, x10
    4768:      	b.hs	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    476c:      	add	x8, x11, x9, lsl #3
    4770:      	ldr	d0, [x8, #0x8]
    4774:      	fmov	x8, d0
    4778:      	cmp	x8, x19
    477c:      	fcsel	d0, d11, d0, eq
    4780:      	b	0x4a70 <_perry_fn_access_worker_ts__run$generic+0x19dc>
    4784:      	add	x8, x8, #0x10
    4788:      	cmp	w11, #0x3
    478c:      	b.le	0x47b0 <_perry_fn_access_worker_ts__run$generic+0x171c>
    4790:      	cmp	w11, #0x5
    4794:      	b.gt	0x4860 <_perry_fn_access_worker_ts__run$generic+0x17cc>
    4798:      	cmp	w11, #0x4
    479c:      	b.eq	0x490c <_perry_fn_access_worker_ts__run$generic+0x1878>
    47a0:      	cmp	w11, #0x5
    47a4:      	b.ne	0x4900 <_perry_fn_access_worker_ts__run$generic+0x186c>
    47a8:      	ldr	s0, [x8, x9, lsl #2]
    47ac:      	b	0x4904 <_perry_fn_access_worker_ts__run$generic+0x1870>
    47b0:      	cbz	w11, 0x48f8 <_perry_fn_access_worker_ts__run$generic+0x1864>
    47b4:      	cmp	w11, #0x2
    47b8:      	b.eq	0x4920 <_perry_fn_access_worker_ts__run$generic+0x188c>
    47bc:      	cmp	w11, #0x3
    47c0:      	b.ne	0x4900 <_perry_fn_access_worker_ts__run$generic+0x186c>
    47c4:      	ldr	h0, [x8, x9, lsl #1]
    47c8:      	b	0x4904 <_perry_fn_access_worker_ts__run$generic+0x1870>
    47cc:      	ldr	x10, [x8, #0x8]
    47d0:      	cbz	x10, 0x4878 <_perry_fn_access_worker_ts__run$generic+0x17e4>
    47d4:      	ldr	x11, [x10, #0x60]
    47d8:      	cbz	x11, 0x4878 <_perry_fn_access_worker_ts__run$generic+0x17e4>
    47dc:      	ldurb	w8, [x11, #-0x8]
    47e0:      	cmp	w8, #0x1
    47e4:      	b.ne	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    47e8:      	ldursb	w8, [x11, #-0x7]
    47ec:      	tbnz	w8, #0x1f, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    47f0:      	ldr	w8, [x11]
    47f4:      	cmp	x9, x8
    47f8:      	b.hs	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    47fc:      	add	x8, x11, x9, lsl #3
    4800:      	ldr	d0, [x8, #0x8]
    4804:      	fmov	x8, d0
    4808:      	cmp	x8, x19
    480c:      	b.eq	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4810:      	b	0x4a70 <_perry_fn_access_worker_ts__run$generic+0x19dc>
    4814:      	ldr	w12, [x8, #0x4]
    4818:      	ldr	x11, [x8, #0x20]
    481c:      	ldurh	w13, [x8, #-0x6]
    4820:      	tst	w13, #0xc00
    4824:      	mov	w13, #0x5841            ; =22593
    4828:      	movk	w13, #0x4c5a, lsl #16
    482c:      	ccmp	w12, w13, #0x0, eq
    4830:      	cset	w12, eq
    4834:      	cbz	x11, 0x48c0 <_perry_fn_access_worker_ts__run$generic+0x182c>
    4838:      	tbz	w12, #0x0, 0x48c0 <_perry_fn_access_worker_ts__run$generic+0x182c>
    483c:      	ldurb	w10, [x11, #-0x8]
    4840:      	cmp	w10, #0x1
    4844:      	b.ne	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4848:      	ldursb	w10, [x11, #-0x7]
    484c:      	tbnz	w10, #0x1f, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4850:      	ldr	w10, [x11]
    4854:      	str	w10, [x8]
    4858:      	mov	x8, x11
    485c:      	b	0x4740 <_perry_fn_access_worker_ts__run$generic+0x16ac>
    4860:      	cmp	w11, #0x6
    4864:      	b.eq	0x4914 <_perry_fn_access_worker_ts__run$generic+0x1880>
    4868:      	cmp	w11, #0x7
    486c:      	b.ne	0x4900 <_perry_fn_access_worker_ts__run$generic+0x186c>
    4870:      	ldr	d0, [x8, x9, lsl #3]
    4874:      	b	0x4a70 <_perry_fn_access_worker_ts__run$generic+0x19dc>
    4878:      	adrp	x12, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004878:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__24
    487c:      	add	x12, x12, #0x0
		000000000000487c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__24
    4880:      	ldr	x11, [x12]
    4884:      	cmp	x11, #0x0
    4888:      	csel	x12, x12, x11, eq
    488c:      	ldr	x12, [x12]
    4890:      	cbz	x12, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4894:      	tbnz	x12, #0x3f, 0x492c <_perry_fn_access_worker_ts__run$generic+0x1898>
    4898:      	ldp	w14, w13, [x8]
    489c:      	orr	x13, x13, x14, lsl #32
    48a0:      	cmp	x13, x12
    48a4:      	b.ne	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    48a8:      	ldp	x14, x12, [x11, #0x8]
    48ac:      	ldp	x13, x11, [x11, #0x18]
    48b0:      	cmp	x14, x11
    48b4:      	b.lo	0x494c <_perry_fn_access_worker_ts__run$generic+0x18b8>
    48b8:      	cbz	x10, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    48bc:      	b	0x499c <_perry_fn_access_worker_ts__run$generic+0x1908>
    48c0:      	cmp	x11, #0x0
    48c4:      	ldr	w14, [x8]
    48c8:      	ldp	x11, x13, [x8, #0x28]
    48cc:      	ccmp	x9, x14, #0x2, eq
    48d0:      	ccmp	x11, #0x0, #0x4, lo
    48d4:      	ccmp	x13, #0x0, #0x4, ne
    48d8:      	csel	w12, wzr, w12, eq
    48dc:      	tbz	w12, #0x0, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    48e0:      	lsr	x12, x9, #6
    48e4:      	ldr	x12, [x13, x12, lsl #3]
    48e8:      	lsr	x12, x12, x9
    48ec:      	tbz	w12, #0x0, 0x4958 <_perry_fn_access_worker_ts__run$generic+0x18c4>
    48f0:      	ldr	d0, [x11, x9, lsl #3]
    48f4:      	b	0x4a70 <_perry_fn_access_worker_ts__run$generic+0x19dc>
    48f8:      	ldrsb	w8, [x8, x9]
    48fc:      	b	0x4924 <_perry_fn_access_worker_ts__run$generic+0x1890>
    4900:      	ldr	b0, [x8, x9]
    4904:      	ucvtf	d0, d0
    4908:      	b	0x4a70 <_perry_fn_access_worker_ts__run$generic+0x19dc>
    490c:      	ldr	w8, [x8, x9, lsl #2]
    4910:      	b	0x4924 <_perry_fn_access_worker_ts__run$generic+0x1890>
    4914:      	ldr	s0, [x8, x9, lsl #2]
    4918:      	fcvt	d0, s0
    491c:      	b	0x4a70 <_perry_fn_access_worker_ts__run$generic+0x19dc>
    4920:      	ldrsh	w8, [x8, x9, lsl #1]
    4924:      	scvtf	d0, w8
    4928:      	b	0x4a70 <_perry_fn_access_worker_ts__run$generic+0x19dc>
    492c:      	cbz	x10, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4930:      	ldr	x13, [x10, #0x30]
    4934:      	cmp	x13, x12
    4938:      	b.ne	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    493c:      	ldp	x14, x12, [x11, #0x8]
    4940:      	ldp	x13, x11, [x11, #0x18]
    4944:      	cmp	x14, x11
    4948:      	b.hs	0x499c <_perry_fn_access_worker_ts__run$generic+0x1908>
    494c:      	add	x14, x8, x14, lsl #3
    4950:      	add	x14, x14, #0x10
    4954:      	b	0x49c0 <_perry_fn_access_worker_ts__run$generic+0x192c>
    4958:      	ldr	x8, [x8, #0x50]
    495c:      	mov	w12, #0x6903            ; =26883
    4960:      	movk	w12, #0x64, lsl #16
    4964:      	cmp	x8, x12
    4968:      	b.eq	0x4970 <_perry_fn_access_worker_ts__run$generic+0x18dc>
    496c:      	cbnz	x8, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4970:      	mov	w12, #0x6903            ; =26883
    4974:      	movk	w12, #0x64, lsl #16
    4978:      	cmp	x8, x12
    497c:      	b.ne	0x4a28 <_perry_fn_access_worker_ts__run$generic+0x1994>
    4980:      	ldr	x8, [x11, x9, lsl #3]
    4984:      	cbz	x8, 0x4a28 <_perry_fn_access_worker_ts__run$generic+0x1994>
    4988:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    498c:      	cmp	x8, x9
    4990:      	csel	x8, xzr, x8, eq
    4994:      	fmov	d1, x8
    4998:      	b	0x4c58 <_perry_fn_access_worker_ts__run$generic+0x1bc4>
    499c:      	ldr	x16, [x10, #0x20]
    49a0:      	cmp	x16, #0x0
    49a4:      	csel	x15, x16, x10, ne
    49a8:      	cbz	x16, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    49ac:      	ldr	w16, [x15]
    49b0:      	cmp	x14, x16
    49b4:      	b.hs	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    49b8:      	add	x14, x15, x14, lsl #3
    49bc:      	add	x14, x14, #0x8
    49c0:      	ldr	d0, [x14]
    49c4:      	fcmp	d8, d0
    49c8:      	ccmp	x13, x9, #0x0, mi
    49cc:      	cset	w13, hi
    49d0:      	add	x9, x12, x9
    49d4:      	cmp	x9, x11
    49d8:      	ccmp	w13, #0x0, #0x4, lo
    49dc:      	b.ne	0x4a1c <_perry_fn_access_worker_ts__run$generic+0x1988>
    49e0:      	cbz	x10, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    49e4:      	cmp	x9, x11
    49e8:      	b.lo	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    49ec:      	eor	w8, w13, #0x1
    49f0:      	tbnz	w8, #0x0, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    49f4:      	ldr	x11, [x10, #0x20]
    49f8:      	cmp	x11, #0x0
    49fc:      	csel	x8, x11, x10, ne
    4a00:      	cbz	x11, 0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4a04:      	ldr	w10, [x8]
    4a08:      	cmp	x9, x10
    4a0c:      	b.hs	0x4a50 <_perry_fn_access_worker_ts__run$generic+0x19bc>
    4a10:      	add	x8, x8, x9, lsl #3
    4a14:      	ldr	d0, [x8, #0x8]
    4a18:      	b	0x4a70 <_perry_fn_access_worker_ts__run$generic+0x19dc>
    4a1c:      	add	x8, x8, x9, lsl #3
    4a20:      	ldr	d0, [x8, #0x10]
    4a24:      	b	0x4a70 <_perry_fn_access_worker_ts__run$generic+0x19dc>
    4a28:      	fmov	d0, x10
    4a2c:      	mov.16b	v1, v8
    4a30:      	adrp	x0, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004a30:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    4a34:      	add	x0, x0, #0x0
		0000000000004a34:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    4a38:      	mov	w1, #0x2                ; =2
    4a3c:      	bl	0x4a3c <_perry_fn_access_worker_ts__run$generic+0x19a8>
		0000000000004a3c:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    4a40:      	mov.16b	v1, v0
    4a44:      	fmov	x8, d1
    4a48:      	cmp	x8, x19
    4a4c:      	b.ne	0x4c58 <_perry_fn_access_worker_ts__run$generic+0x1bc4>
    4a50:      	fmov	d0, x28
    4a54:      	str	x23, [sp, #0x28]
    4a58:      	mov.16b	v1, v8
    4a5c:      	adrp	x0, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004a5c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__24
    4a60:      	add	x0, x0, #0x0
		0000000000004a60:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__24
    4a64:      	bl	0x4a64 <_perry_fn_access_worker_ts__run$generic+0x19d0>
		0000000000004a64:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    4a68:      	ldp	x28, x26, [sp, #0x18]
    4a6c:      	ldr	x23, [sp, #0x28]
    4a70:      	fmov	x8, d0
    4a74:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    4a78:      	and	x9, x8, x9
    4a7c:      	cmp	x9, x24
    4a80:      	b.ne	0x4aec <_perry_fn_access_worker_ts__run$generic+0x1a58>
    4a84:      	and	x0, x8, #0xffffffffffff
    4a88:      	lsr	x8, x0, #20
    4a8c:      	cbz	x8, 0x4c30 <_perry_fn_access_worker_ts__run$generic+0x1b9c>
    4a90:      	ldurb	w9, [x0, #-0x8]
    4a94:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004a94:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__26
    4a98:      	ldr	x8, [x8]
		0000000000004a98:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__26
    4a9c:      	cbz	x8, 0x4b5c <_perry_fn_access_worker_ts__run$generic+0x1ac8>
    4aa0:      	ldurh	w10, [x0, #-0x6]
    4aa4:      	and	w10, w10, #0x800
    4aa8:      	cmp	w9, #0x2
    4aac:      	ccmp	w10, #0x0, #0x0, eq
    4ab0:      	b.ne	0x4b5c <_perry_fn_access_worker_ts__run$generic+0x1ac8>
    4ab4:      	ldr	w10, [x0, #0x4]
    4ab8:      	orr	x9, x10, #0x4000000000000000
    4abc:      	ldr	x11, [x8]
    4ac0:      	cmp	w10, #0x0
    4ac4:      	ccmp	x9, x11, #0x0, ne
    4ac8:      	b.eq	0x4b94 <_perry_fn_access_worker_ts__run$generic+0x1b00>
    4acc:      	ldr	x11, [x8, #0x10]
    4ad0:      	cbz	x11, 0x4bb0 <_perry_fn_access_worker_ts__run$generic+0x1b1c>
    4ad4:      	ldr	x12, [x0, #0x8]
    4ad8:      	cbz	x12, 0x4bb0 <_perry_fn_access_worker_ts__run$generic+0x1b1c>
    4adc:      	ldr	x12, [x12, #0x30]
    4ae0:      	cmp	x12, x11
    4ae4:      	b.eq	0x4b84 <_perry_fn_access_worker_ts__run$generic+0x1af0>
    4ae8:      	b	0x4bb0 <_perry_fn_access_worker_ts__run$generic+0x1b1c>
    4aec:      	lsr	x9, x8, #48
    4af0:      	mov	w10, #0x7ff9            ; =32761
    4af4:      	cmp	x9, x10
    4af8:      	b.eq	0x4b40 <_perry_fn_access_worker_ts__run$generic+0x1aac>
    4afc:      	mov	w10, #0x7ffe            ; =32766
    4b00:      	cmp	w9, w10
    4b04:      	b.ne	0x4b30 <_perry_fn_access_worker_ts__run$generic+0x1a9c>
    4b08:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004b08:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    4b0c:      	ldr	x9, [x9]
		0000000000004b0c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4b10:      	str	x23, [sp, #0x28]
    4b14:      	and	x2, x9, #0xffffffffffff
    4b18:      	mov	x0, #0x19               ; =25
    4b1c:      	movk	x0, #0xddae, lsl #32
    4b20:      	movk	x0, #0x5556, lsl #48
    4b24:      	mov	x1, x8
    4b28:      	bl	0x4b28 <_perry_fn_access_worker_ts__run$generic+0x1a94>
		0000000000004b28:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    4b2c:      	b	0x4c4c <_perry_fn_access_worker_ts__run$generic+0x1bb8>
    4b30:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    4b34:      	add	x9, x8, x9
    4b38:      	cmp	x9, #0x2
    4b3c:      	b.lo	0x62bc <_perry_fn_access_worker_ts__run$generic+0x3228>
    4b40:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004b40:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    4b44:      	ldr	x9, [x9]
		0000000000004b44:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4b48:      	str	x23, [sp, #0x28]
    4b4c:      	and	x1, x9, #0xffffffffffff
    4b50:      	mov	x0, x8
    4b54:      	bl	0x4b54 <_perry_fn_access_worker_ts__run$generic+0x1ac0>
		0000000000004b54:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    4b58:      	b	0x4c4c <_perry_fn_access_worker_ts__run$generic+0x1bb8>
    4b5c:      	cmp	w9, #0x2
    4b60:      	ccmp	x8, #0x0, #0x4, eq
    4b64:      	b.eq	0x4c30 <_perry_fn_access_worker_ts__run$generic+0x1b9c>
    4b68:      	ldr	x9, [x8, #0x10]
    4b6c:      	cbz	x9, 0x4c30 <_perry_fn_access_worker_ts__run$generic+0x1b9c>
    4b70:      	ldr	x10, [x0, #0x8]
    4b74:      	cbz	x10, 0x4c30 <_perry_fn_access_worker_ts__run$generic+0x1b9c>
    4b78:      	ldr	x10, [x10, #0x30]
    4b7c:      	cmp	x10, x9
    4b80:      	b.ne	0x4c30 <_perry_fn_access_worker_ts__run$generic+0x1b9c>
    4b84:      	ldr	x8, [x8, #0x8]
    4b88:      	add	x8, x0, x8, lsl #3
    4b8c:      	ldr	d1, [x8, #0x10]
    4b90:      	b	0x4c58 <_perry_fn_access_worker_ts__run$generic+0x1bc4>
    4b94:      	ldr	x2, [x8, #0x8]
    4b98:      	tbnz	w2, #0x1e, 0x4f1c <_perry_fn_access_worker_ts__run$generic+0x1e88>
    4b9c:      	add	x11, x0, x2, lsl #3
    4ba0:      	ldr	d1, [x11, #0x10]
    4ba4:      	fmov	x11, d1
    4ba8:      	cmp	x11, x19
    4bac:      	b.ne	0x4c58 <_perry_fn_access_worker_ts__run$generic+0x1bc4>
    4bb0:      	ldr	x11, [x8, #0x18]
    4bb4:      	cmp	x11, #0x0
    4bb8:      	b.le	0x4c30 <_perry_fn_access_worker_ts__run$generic+0x1b9c>
    4bbc:      	ldr	x11, [x8, #0x20]
    4bc0:      	ldr	x12, [x8, #0x30]
    4bc4:      	ldr	x13, [x8, #0x40]
    4bc8:      	cmp	x13, x9
    4bcc:      	ldr	x14, [x8, #0x50]
    4bd0:      	ccmp	x14, x9, #0x4, ne
    4bd4:      	ccmp	x12, x9, #0x4, ne
    4bd8:      	ccmp	x11, x9, #0x4, ne
    4bdc:      	cset	w15, eq
    4be0:      	cmp	w10, #0x0
    4be4:      	ccmp	w15, #0x0, #0x4, ne
    4be8:      	b.eq	0x4c30 <_perry_fn_access_worker_ts__run$generic+0x1b9c>
    4bec:      	ldr	x10, [x8, #0x48]
    4bf0:      	ldr	x15, [x8, #0x58]
    4bf4:      	cmp	x14, x9
    4bf8:      	csel	x14, x15, xzr, eq
    4bfc:      	cmp	x13, x9
    4c00:      	csel	x10, x10, x14, eq
    4c04:      	ldr	x13, [x8, #0x28]
    4c08:      	ldr	x8, [x8, #0x38]
    4c0c:      	cmp	x12, x9
    4c10:      	csel	x8, x8, x10, eq
    4c14:      	cmp	x11, x9
    4c18:      	csel	x8, x13, x8, eq
    4c1c:      	add	x8, x0, x8, lsl #3
    4c20:      	ldr	d1, [x8, #0x10]
    4c24:      	fmov	x8, d1
    4c28:      	cmp	x8, x19
    4c2c:      	b.ne	0x4c58 <_perry_fn_access_worker_ts__run$generic+0x1bc4>
    4c30:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004c30:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    4c34:      	ldr	x8, [x8]
		0000000000004c34:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4c38:      	str	x23, [sp, #0x28]
    4c3c:      	and	x1, x8, #0xffffffffffff
    4c40:      	adrp	x2, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004c40:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__26
    4c44:      	add	x2, x2, #0x0
		0000000000004c44:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__26
    4c48:      	bl	0x4c48 <_perry_fn_access_worker_ts__run$generic+0x1bb4>
		0000000000004c48:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    4c4c:      	mov.16b	v1, v0
    4c50:      	ldp	x28, x26, [sp, #0x18]
    4c54:      	ldr	x23, [sp, #0x28]
    4c58:      	fmov	d0, x23
    4c5c:      	and	x9, x23, #0xffff000000000000
    4c60:      	fmov	x8, d1
    4c64:      	and	x10, x8, #0xffff000000000000
    4c68:      	cmp	x8, x22
    4c6c:      	ccmp	x10, x25, #0x2, hs
    4c70:      	cset	w8, hi
    4c74:      	mov	x10, #0x1               ; =1
    4c78:      	movk	x10, #0x7fff, lsl #48
    4c7c:      	cmp	x9, x10
    4c80:      	ccmp	x23, x21, #0x0, lo
    4c84:      	b.hi	0x4c94 <_perry_fn_access_worker_ts__run$generic+0x1c00>
    4c88:      	tbz	w8, #0x0, 0x4c94 <_perry_fn_access_worker_ts__run$generic+0x1c00>
    4c8c:      	fadd	d0, d1, d0
    4c90:      	b	0x4c9c <_perry_fn_access_worker_ts__run$generic+0x1c08>
    4c94:      	bl	0x4c94 <_perry_fn_access_worker_ts__run$generic+0x1c00>
		0000000000004c94:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    4c98:      	ldp	x28, x26, [sp, #0x18]
    4c9c:      	fmov	x23, d0
    4ca0:      	mov	x0, x23
    4ca4:      	ldr	w8, [x27]
    4ca8:      	cbz	w8, 0x4cb0 <_perry_fn_access_worker_ts__run$generic+0x1c1c>
    4cac:      	bl	0x4cac <_perry_fn_access_worker_ts__run$generic+0x1c18>
		0000000000004cac:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    4cb0:      	mov	x0, x23
    4cb4:      	ldr	w8, [x27]
    4cb8:      	cbz	w8, 0x4cc0 <_perry_fn_access_worker_ts__run$generic+0x1c2c>
    4cbc:      	bl	0x4cbc <_perry_fn_access_worker_ts__run$generic+0x1c28>
		0000000000004cbc:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    4cc0:      	mov	x10, x28
    4cc4:      	and	x8, x10, #0xffffffffffff
    4cc8:      	and	x12, x10, #0xffff000000000000
    4ccc:      	cmp	x12, x24
    4cd0:      	b.ne	0x4d34 <_perry_fn_access_worker_ts__run$generic+0x1ca0>
    4cd4:      	adrp	x9, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004cd4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    4cd8:      	ldr	x9, [x9]
		0000000000004cd8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    4cdc:      	ldr	x9, [x9]
    4ce0:      	cbnz	x9, 0x4d34 <_perry_fn_access_worker_ts__run$generic+0x1ca0>
    4ce4:      	sub	x9, x8, #0x100, lsl #12 ; =0x100000
    4ce8:      	mov	x11, #0x7ffffff00000    ; =140737487306752
    4cec:      	cmp	x9, x11
    4cf0:      	b.hs	0x4d34 <_perry_fn_access_worker_ts__run$generic+0x1ca0>
    4cf4:      	fcmp	d8, d12
    4cf8:      	b.pl	0x4d34 <_perry_fn_access_worker_ts__run$generic+0x1ca0>
    4cfc:      	fcmp	d8, #0.0
    4d00:      	b.lt	0x4d34 <_perry_fn_access_worker_ts__run$generic+0x1ca0>
    4d04:      	ldurb	w9, [x8, #-0x8]
    4d08:      	cmp	w9, #0xb
    4d0c:      	b.ne	0x4d34 <_perry_fn_access_worker_ts__run$generic+0x1ca0>
    4d10:      	ldrb	w11, [x8, #0x8]
    4d14:      	cmp	w11, #0x9
    4d18:      	b.hs	0x4d34 <_perry_fn_access_worker_ts__run$generic+0x1ca0>
    4d1c:      	fcvtzs	x9, d8
    4d20:      	scvtf	d0, x9
    4d24:      	ldr	w13, [x8]
    4d28:      	fcmp	d8, d0
    4d2c:      	ccmp	x9, x13, #0x2, eq
    4d30:      	b.lo	0x4de0 <_perry_fn_access_worker_ts__run$generic+0x1d4c>
    4d34:      	cmp	x12, x24
    4d38:      	b.ne	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4d3c:      	fcmp	d8, #0.0
    4d40:      	b.lt	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4d44:      	fcmp	d8, d10
    4d48:      	b.pl	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4d4c:      	mov	x9, #-0x20000000000     ; =-2199023255552
    4d50:      	add	x9, x8, x9
    4d54:      	lsr	x9, x9, #41
    4d58:      	cmp	x9, #0x3f
    4d5c:      	b.hs	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4d60:      	fcvtzs	x9, d8
    4d64:      	scvtf	d0, x9
    4d68:      	fcmp	d8, d0
    4d6c:      	b.ne	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4d70:      	ldursb	w11, [x8, #-0x7]
    4d74:      	tbnz	w11, #0x1f, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4d78:      	ldurb	w11, [x8, #-0x8]
    4d7c:      	cmp	w11, #0x9
    4d80:      	b.eq	0x4e70 <_perry_fn_access_worker_ts__run$generic+0x1ddc>
    4d84:      	cmp	w11, #0x2
    4d88:      	b.eq	0x4e28 <_perry_fn_access_worker_ts__run$generic+0x1d94>
    4d8c:      	cmp	w11, #0x1
    4d90:      	b.ne	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4d94:      	ldr	w10, [x8]
    4d98:      	mov	x11, x8
    4d9c:      	ldurh	w13, [x8, #-0x6]
    4da0:      	adrp	x12, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004da0:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    4da4:      	ldr	x12, [x12]
		0000000000004da4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    4da8:      	ldrb	w12, [x12]
    4dac:      	ldr	w8, [x8, #0x4]
    4db0:      	cmp	x10, x8
    4db4:      	b.hi	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4db8:      	tbnz	w13, #0xa, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4dbc:      	cbnz	w12, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4dc0:      	cmp	x9, x10
    4dc4:      	b.hs	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4dc8:      	add	x8, x11, x9, lsl #3
    4dcc:      	ldr	d0, [x8, #0x8]
    4dd0:      	fmov	x8, d0
    4dd4:      	cmp	x8, x19
    4dd8:      	fcsel	d0, d11, d0, eq
    4ddc:      	b	0x50e4 <_perry_fn_access_worker_ts__run$generic+0x2050>
    4de0:      	add	x8, x8, #0x10
    4de4:      	cmp	w11, #0x3
    4de8:      	b.le	0x4e0c <_perry_fn_access_worker_ts__run$generic+0x1d78>
    4dec:      	cmp	w11, #0x5
    4df0:      	b.gt	0x4ebc <_perry_fn_access_worker_ts__run$generic+0x1e28>
    4df4:      	cmp	w11, #0x4
    4df8:      	b.eq	0x4f88 <_perry_fn_access_worker_ts__run$generic+0x1ef4>
    4dfc:      	cmp	w11, #0x5
    4e00:      	b.ne	0x4f7c <_perry_fn_access_worker_ts__run$generic+0x1ee8>
    4e04:      	ldr	s0, [x8, x9, lsl #2]
    4e08:      	b	0x4f80 <_perry_fn_access_worker_ts__run$generic+0x1eec>
    4e0c:      	cbz	w11, 0x4f74 <_perry_fn_access_worker_ts__run$generic+0x1ee0>
    4e10:      	cmp	w11, #0x2
    4e14:      	b.eq	0x4f9c <_perry_fn_access_worker_ts__run$generic+0x1f08>
    4e18:      	cmp	w11, #0x3
    4e1c:      	b.ne	0x4f7c <_perry_fn_access_worker_ts__run$generic+0x1ee8>
    4e20:      	ldr	h0, [x8, x9, lsl #1]
    4e24:      	b	0x4f80 <_perry_fn_access_worker_ts__run$generic+0x1eec>
    4e28:      	ldr	x10, [x8, #0x8]
    4e2c:      	cbz	x10, 0x4ed4 <_perry_fn_access_worker_ts__run$generic+0x1e40>
    4e30:      	ldr	x11, [x10, #0x60]
    4e34:      	cbz	x11, 0x4ed4 <_perry_fn_access_worker_ts__run$generic+0x1e40>
    4e38:      	ldurb	w8, [x11, #-0x8]
    4e3c:      	cmp	w8, #0x1
    4e40:      	b.ne	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4e44:      	ldursb	w8, [x11, #-0x7]
    4e48:      	tbnz	w8, #0x1f, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4e4c:      	ldr	w8, [x11]
    4e50:      	cmp	x9, x8
    4e54:      	b.hs	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4e58:      	add	x8, x11, x9, lsl #3
    4e5c:      	ldr	d0, [x8, #0x8]
    4e60:      	fmov	x8, d0
    4e64:      	cmp	x8, x19
    4e68:      	b.eq	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4e6c:      	b	0x50e4 <_perry_fn_access_worker_ts__run$generic+0x2050>
    4e70:      	ldr	w12, [x8, #0x4]
    4e74:      	ldr	x11, [x8, #0x20]
    4e78:      	ldurh	w13, [x8, #-0x6]
    4e7c:      	tst	w13, #0xc00
    4e80:      	mov	w13, #0x5841            ; =22593
    4e84:      	movk	w13, #0x4c5a, lsl #16
    4e88:      	ccmp	w12, w13, #0x0, eq
    4e8c:      	cset	w12, eq
    4e90:      	cbz	x11, 0x4f3c <_perry_fn_access_worker_ts__run$generic+0x1ea8>
    4e94:      	tbz	w12, #0x0, 0x4f3c <_perry_fn_access_worker_ts__run$generic+0x1ea8>
    4e98:      	ldurb	w10, [x11, #-0x8]
    4e9c:      	cmp	w10, #0x1
    4ea0:      	b.ne	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4ea4:      	ldursb	w10, [x11, #-0x7]
    4ea8:      	tbnz	w10, #0x1f, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4eac:      	ldr	w10, [x11]
    4eb0:      	str	w10, [x8]
    4eb4:      	mov	x8, x11
    4eb8:      	b	0x4d9c <_perry_fn_access_worker_ts__run$generic+0x1d08>
    4ebc:      	cmp	w11, #0x6
    4ec0:      	b.eq	0x4f90 <_perry_fn_access_worker_ts__run$generic+0x1efc>
    4ec4:      	cmp	w11, #0x7
    4ec8:      	b.ne	0x4f7c <_perry_fn_access_worker_ts__run$generic+0x1ee8>
    4ecc:      	ldr	d0, [x8, x9, lsl #3]
    4ed0:      	b	0x50e4 <_perry_fn_access_worker_ts__run$generic+0x2050>
    4ed4:      	adrp	x12, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004ed4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__27
    4ed8:      	add	x12, x12, #0x0
		0000000000004ed8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__27
    4edc:      	ldr	x11, [x12]
    4ee0:      	cmp	x11, #0x0
    4ee4:      	csel	x12, x12, x11, eq
    4ee8:      	ldr	x12, [x12]
    4eec:      	cbz	x12, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4ef0:      	tbnz	x12, #0x3f, 0x4fa8 <_perry_fn_access_worker_ts__run$generic+0x1f14>
    4ef4:      	ldp	w14, w13, [x8]
    4ef8:      	orr	x13, x13, x14, lsl #32
    4efc:      	cmp	x13, x12
    4f00:      	b.ne	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4f04:      	ldp	x14, x12, [x11, #0x8]
    4f08:      	ldp	x13, x11, [x11, #0x18]
    4f0c:      	cmp	x14, x11
    4f10:      	b.lo	0x4fc8 <_perry_fn_access_worker_ts__run$generic+0x1f34>
    4f14:      	cbz	x10, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4f18:      	b	0x5014 <_perry_fn_access_worker_ts__run$generic+0x1f80>
    4f1c:      	adrp	x8, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004f1c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    4f20:      	ldr	x8, [x8]
		0000000000004f20:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    4f24:      	str	x23, [sp, #0x28]
    4f28:      	and	x1, x8, #0xffffffffffff
    4f2c:      	adrp	x3, 0x4000 <_perry_fn_access_worker_ts__run$generic+0xf6c>
		0000000000004f2c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__26
    4f30:      	add	x3, x3, #0x0
		0000000000004f30:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__26
    4f34:      	bl	0x4f34 <_perry_fn_access_worker_ts__run$generic+0x1ea0>
		0000000000004f34:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    4f38:      	b	0x4c4c <_perry_fn_access_worker_ts__run$generic+0x1bb8>
    4f3c:      	cmp	x11, #0x0
    4f40:      	ldr	w14, [x8]
    4f44:      	ldp	x11, x13, [x8, #0x28]
    4f48:      	ccmp	x9, x14, #0x2, eq
    4f4c:      	ccmp	x11, #0x0, #0x4, lo
    4f50:      	ccmp	x13, #0x0, #0x4, ne
    4f54:      	csel	w12, wzr, w12, eq
    4f58:      	tbz	w12, #0x0, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4f5c:      	lsr	x12, x9, #6
    4f60:      	ldr	x12, [x13, x12, lsl #3]
    4f64:      	lsr	x12, x12, x9
    4f68:      	tbz	w12, #0x0, 0x4fd4 <_perry_fn_access_worker_ts__run$generic+0x1f40>
    4f6c:      	ldr	d0, [x11, x9, lsl #3]
    4f70:      	b	0x50e4 <_perry_fn_access_worker_ts__run$generic+0x2050>
    4f74:      	ldrsb	w8, [x8, x9]
    4f78:      	b	0x4fa0 <_perry_fn_access_worker_ts__run$generic+0x1f0c>
    4f7c:      	ldr	b0, [x8, x9]
    4f80:      	ucvtf	d0, d0
    4f84:      	b	0x50e4 <_perry_fn_access_worker_ts__run$generic+0x2050>
    4f88:      	ldr	w8, [x8, x9, lsl #2]
    4f8c:      	b	0x4fa0 <_perry_fn_access_worker_ts__run$generic+0x1f0c>
    4f90:      	ldr	s0, [x8, x9, lsl #2]
    4f94:      	fcvt	d0, s0
    4f98:      	b	0x50e4 <_perry_fn_access_worker_ts__run$generic+0x2050>
    4f9c:      	ldrsh	w8, [x8, x9, lsl #1]
    4fa0:      	scvtf	d0, w8
    4fa4:      	b	0x50e4 <_perry_fn_access_worker_ts__run$generic+0x2050>
    4fa8:      	cbz	x10, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4fac:      	ldr	x13, [x10, #0x30]
    4fb0:      	cmp	x13, x12
    4fb4:      	b.ne	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4fb8:      	ldp	x14, x12, [x11, #0x8]
    4fbc:      	ldp	x13, x11, [x11, #0x18]
    4fc0:      	cmp	x14, x11
    4fc4:      	b.hs	0x5014 <_perry_fn_access_worker_ts__run$generic+0x1f80>
    4fc8:      	add	x14, x8, x14, lsl #3
    4fcc:      	add	x14, x14, #0x10
    4fd0:      	b	0x5038 <_perry_fn_access_worker_ts__run$generic+0x1fa4>
    4fd4:      	ldr	x8, [x8, #0x50]
    4fd8:      	mov	x12, #0x6e05            ; =28165
    4fdc:      	movk	x12, #0x6d61, lsl #16
    4fe0:      	movk	x12, #0x65, lsl #32
    4fe4:      	cmp	x8, x12
    4fe8:      	b.eq	0x4ff0 <_perry_fn_access_worker_ts__run$generic+0x1f5c>
    4fec:      	cbnz	x8, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    4ff0:      	cmp	x8, x12
    4ff4:      	b.ne	0x50a0 <_perry_fn_access_worker_ts__run$generic+0x200c>
    4ff8:      	ldr	x8, [x11, x9, lsl #3]
    4ffc:      	cbz	x8, 0x50a0 <_perry_fn_access_worker_ts__run$generic+0x200c>
    5000:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    5004:      	cmp	x8, x9
    5008:      	csel	x8, xzr, x8, eq
    500c:      	fmov	d0, x8
    5010:      	b	0x52c4 <_perry_fn_access_worker_ts__run$generic+0x2230>
    5014:      	ldr	x16, [x10, #0x20]
    5018:      	cmp	x16, #0x0
    501c:      	csel	x15, x16, x10, ne
    5020:      	cbz	x16, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    5024:      	ldr	w16, [x15]
    5028:      	cmp	x14, x16
    502c:      	b.hs	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    5030:      	add	x14, x15, x14, lsl #3
    5034:      	add	x14, x14, #0x8
    5038:      	ldr	d0, [x14]
    503c:      	fcmp	d8, d0
    5040:      	ccmp	x13, x9, #0x0, mi
    5044:      	cset	w13, hi
    5048:      	add	x9, x12, x9
    504c:      	cmp	x9, x11
    5050:      	b.hs	0x5064 <_perry_fn_access_worker_ts__run$generic+0x1fd0>
    5054:      	cbz	w13, 0x5064 <_perry_fn_access_worker_ts__run$generic+0x1fd0>
    5058:      	add	x8, x8, x9, lsl #3
    505c:      	ldr	d0, [x8, #0x10]
    5060:      	b	0x50e4 <_perry_fn_access_worker_ts__run$generic+0x2050>
    5064:      	cbz	x10, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    5068:      	cmp	x9, x11
    506c:      	b.lo	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    5070:      	eor	w8, w13, #0x1
    5074:      	tbnz	w8, #0x0, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    5078:      	ldr	x11, [x10, #0x20]
    507c:      	cmp	x11, #0x0
    5080:      	csel	x8, x11, x10, ne
    5084:      	cbz	x11, 0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    5088:      	ldr	w10, [x8]
    508c:      	cmp	x9, x10
    5090:      	b.hs	0x50c4 <_perry_fn_access_worker_ts__run$generic+0x2030>
    5094:      	add	x8, x8, x9, lsl #3
    5098:      	ldr	d0, [x8, #0x8]
    509c:      	b	0x50e4 <_perry_fn_access_worker_ts__run$generic+0x2050>
    50a0:      	fmov	d0, x10
    50a4:      	mov.16b	v1, v8
    50a8:      	adrp	x0, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000050a8:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.4.bytes
    50ac:      	add	x0, x0, #0x0
		00000000000050ac:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.4.bytes
    50b0:      	mov	w1, #0x4                ; =4
    50b4:      	bl	0x50b4 <_perry_fn_access_worker_ts__run$generic+0x2020>
		00000000000050b4:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    50b8:      	fmov	x8, d0
    50bc:      	cmp	x8, x19
    50c0:      	b.ne	0x52c4 <_perry_fn_access_worker_ts__run$generic+0x2230>
    50c4:      	fmov	d0, x28
    50c8:      	str	x23, [sp, #0x28]
    50cc:      	mov.16b	v1, v8
    50d0:      	adrp	x0, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000050d0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__27
    50d4:      	add	x0, x0, #0x0
		00000000000050d4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__27
    50d8:      	bl	0x50d8 <_perry_fn_access_worker_ts__run$generic+0x2044>
		00000000000050d8:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    50dc:      	ldp	x28, x26, [sp, #0x18]
    50e0:      	ldr	x23, [sp, #0x28]
    50e4:      	fmov	x8, d0
    50e8:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    50ec:      	and	x9, x8, x9
    50f0:      	cmp	x9, x24
    50f4:      	b.ne	0x515c <_perry_fn_access_worker_ts__run$generic+0x20c8>
    50f8:      	and	x0, x8, #0xffffffffffff
    50fc:      	lsr	x8, x0, #20
    5100:      	cbz	x8, 0x52a0 <_perry_fn_access_worker_ts__run$generic+0x220c>
    5104:      	ldurb	w9, [x0, #-0x8]
    5108:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005108:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__29
    510c:      	ldr	x8, [x8]
		000000000000510c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__29
    5110:      	cbz	x8, 0x51cc <_perry_fn_access_worker_ts__run$generic+0x2138>
    5114:      	cmp	w9, #0x2
    5118:      	b.ne	0x51cc <_perry_fn_access_worker_ts__run$generic+0x2138>
    511c:      	ldurh	w10, [x0, #-0x6]
    5120:      	tbnz	w10, #0xb, 0x51cc <_perry_fn_access_worker_ts__run$generic+0x2138>
    5124:      	ldr	w10, [x0, #0x4]
    5128:      	orr	x9, x10, #0x4000000000000000
    512c:      	cbz	w10, 0x51f8 <_perry_fn_access_worker_ts__run$generic+0x2164>
    5130:      	ldr	x11, [x8]
    5134:      	cmp	x9, x11
    5138:      	b.ne	0x51f8 <_perry_fn_access_worker_ts__run$generic+0x2164>
    513c:      	ldr	x2, [x8, #0x8]
    5140:      	tbnz	w2, #0x1e, 0x55f8 <_perry_fn_access_worker_ts__run$generic+0x2564>
    5144:      	add	x11, x0, x2, lsl #3
    5148:      	ldr	d0, [x11, #0x10]
    514c:      	fmov	x11, d0
    5150:      	cmp	x11, x19
    5154:      	b.ne	0x52c4 <_perry_fn_access_worker_ts__run$generic+0x2230>
    5158:      	b	0x5224 <_perry_fn_access_worker_ts__run$generic+0x2190>
    515c:      	lsr	x9, x8, #48
    5160:      	mov	w10, #0x7ff9            ; =32761
    5164:      	cmp	x9, x10
    5168:      	b.eq	0x51b0 <_perry_fn_access_worker_ts__run$generic+0x211c>
    516c:      	mov	w10, #0x7ffe            ; =32766
    5170:      	cmp	w9, w10
    5174:      	b.ne	0x51a0 <_perry_fn_access_worker_ts__run$generic+0x210c>
    5178:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005178:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    517c:      	ldr	x9, [x9]
		000000000000517c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    5180:      	str	x23, [sp, #0x28]
    5184:      	and	x2, x9, #0xffffffffffff
    5188:      	mov	x0, #0x1c               ; =28
    518c:      	movk	x0, #0xddae, lsl #32
    5190:      	movk	x0, #0x5556, lsl #48
    5194:      	mov	x1, x8
    5198:      	bl	0x5198 <_perry_fn_access_worker_ts__run$generic+0x2104>
		0000000000005198:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    519c:      	b	0x52bc <_perry_fn_access_worker_ts__run$generic+0x2228>
    51a0:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    51a4:      	add	x9, x8, x9
    51a8:      	cmp	x9, #0x2
    51ac:      	b.lo	0x62dc <_perry_fn_access_worker_ts__run$generic+0x3248>
    51b0:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000051b0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    51b4:      	ldr	x9, [x9]
		00000000000051b4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    51b8:      	str	x23, [sp, #0x28]
    51bc:      	and	x1, x9, #0xffffffffffff
    51c0:      	mov	x0, x8
    51c4:      	bl	0x51c4 <_perry_fn_access_worker_ts__run$generic+0x2130>
		00000000000051c4:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    51c8:      	b	0x52bc <_perry_fn_access_worker_ts__run$generic+0x2228>
    51cc:      	cmp	w9, #0x2
    51d0:      	b.ne	0x52a0 <_perry_fn_access_worker_ts__run$generic+0x220c>
    51d4:      	cbz	x8, 0x52a0 <_perry_fn_access_worker_ts__run$generic+0x220c>
    51d8:      	ldr	x9, [x8, #0x10]
    51dc:      	cbz	x9, 0x52a0 <_perry_fn_access_worker_ts__run$generic+0x220c>
    51e0:      	ldr	x10, [x0, #0x8]
    51e4:      	cbz	x10, 0x52a0 <_perry_fn_access_worker_ts__run$generic+0x220c>
    51e8:      	ldr	x10, [x10, #0x30]
    51ec:      	cmp	x10, x9
    51f0:      	b.eq	0x5214 <_perry_fn_access_worker_ts__run$generic+0x2180>
    51f4:      	b	0x52a0 <_perry_fn_access_worker_ts__run$generic+0x220c>
    51f8:      	ldr	x11, [x8, #0x10]
    51fc:      	cbz	x11, 0x5224 <_perry_fn_access_worker_ts__run$generic+0x2190>
    5200:      	ldr	x12, [x0, #0x8]
    5204:      	cbz	x12, 0x5224 <_perry_fn_access_worker_ts__run$generic+0x2190>
    5208:      	ldr	x12, [x12, #0x30]
    520c:      	cmp	x12, x11
    5210:      	b.ne	0x5224 <_perry_fn_access_worker_ts__run$generic+0x2190>
    5214:      	ldr	x8, [x8, #0x8]
    5218:      	add	x8, x0, x8, lsl #3
    521c:      	ldr	d0, [x8, #0x10]
    5220:      	b	0x52c4 <_perry_fn_access_worker_ts__run$generic+0x2230>
    5224:      	ldr	x11, [x8, #0x18]
    5228:      	cmp	x11, #0x0
    522c:      	b.le	0x52a0 <_perry_fn_access_worker_ts__run$generic+0x220c>
    5230:      	ldr	x11, [x8, #0x20]
    5234:      	ldr	x12, [x8, #0x30]
    5238:      	ldr	x13, [x8, #0x40]
    523c:      	cmp	x13, x9
    5240:      	ldr	x14, [x8, #0x50]
    5244:      	ccmp	x14, x9, #0x4, ne
    5248:      	ccmp	x12, x9, #0x4, ne
    524c:      	ccmp	x11, x9, #0x4, ne
    5250:      	cset	w15, eq
    5254:      	cbz	w10, 0x52a0 <_perry_fn_access_worker_ts__run$generic+0x220c>
    5258:      	cbz	w15, 0x52a0 <_perry_fn_access_worker_ts__run$generic+0x220c>
    525c:      	ldr	x10, [x8, #0x48]
    5260:      	ldr	x15, [x8, #0x58]
    5264:      	cmp	x14, x9
    5268:      	csel	x14, x15, xzr, eq
    526c:      	cmp	x13, x9
    5270:      	csel	x10, x10, x14, eq
    5274:      	ldr	x13, [x8, #0x28]
    5278:      	ldr	x8, [x8, #0x38]
    527c:      	cmp	x12, x9
    5280:      	csel	x8, x8, x10, eq
    5284:      	cmp	x11, x9
    5288:      	csel	x8, x13, x8, eq
    528c:      	add	x8, x0, x8, lsl #3
    5290:      	ldr	d0, [x8, #0x10]
    5294:      	fmov	x8, d0
    5298:      	cmp	x8, x19
    529c:      	b.ne	0x52c4 <_perry_fn_access_worker_ts__run$generic+0x2230>
    52a0:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000052a0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    52a4:      	ldr	x8, [x8]
		00000000000052a4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    52a8:      	str	x23, [sp, #0x28]
    52ac:      	and	x1, x8, #0xffffffffffff
    52b0:      	adrp	x2, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000052b0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__29
    52b4:      	add	x2, x2, #0x0
		00000000000052b4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__29
    52b8:      	bl	0x52b8 <_perry_fn_access_worker_ts__run$generic+0x2224>
		00000000000052b8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    52bc:      	ldp	x28, x26, [sp, #0x18]
    52c0:      	ldr	x23, [sp, #0x28]
    52c4:      	fmov	x8, d0
    52c8:      	lsr	x9, x8, #48
    52cc:      	mov	w10, #0x7ff9            ; =32761
    52d0:      	cmp	x9, x10
    52d4:      	b.eq	0x5304 <_perry_fn_access_worker_ts__run$generic+0x2270>
    52d8:      	mov	w10, #0x7fff            ; =32767
    52dc:      	cmp	w9, w10
    52e0:      	b.ne	0x5310 <_perry_fn_access_worker_ts__run$generic+0x227c>
    52e4:      	and	x9, x8, #0xffffffffffff
    52e8:      	tst	x8, #0xfffffffff000
    52ec:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000052ec:  ARM64_RELOC_PAGE21	_perry_null_guard_zero_access_worker_ts
    52f0:      	add	x8, x8, #0x0
		00000000000052f0:  ARM64_RELOC_PAGEOFF12	_perry_null_guard_zero_access_worker_ts
    52f4:      	csel	x8, x8, x9, eq
    52f8:      	ldr	s0, [x8]
    52fc:      	ucvtf	d1, d0
    5300:      	b	0x5324 <_perry_fn_access_worker_ts__run$generic+0x2290>
    5304:      	ubfx	x8, x8, #40, #8
    5308:      	ucvtf	d1, x8
    530c:      	b	0x5324 <_perry_fn_access_worker_ts__run$generic+0x2290>
    5310:      	str	x23, [sp, #0x28]
    5314:      	bl	0x5314 <_perry_fn_access_worker_ts__run$generic+0x2280>
		0000000000005314:  ARM64_RELOC_BRANCH26	_js_value_length_property_f64
    5318:      	mov.16b	v1, v0
    531c:      	ldp	x28, x26, [sp, #0x18]
    5320:      	ldr	x23, [sp, #0x28]
    5324:      	fmov	d0, x23
    5328:      	and	x9, x23, #0xffff000000000000
    532c:      	fmov	x8, d1
    5330:      	and	x10, x8, #0xffff000000000000
    5334:      	cmp	x8, x22
    5338:      	ccmp	x10, x25, #0x2, hs
    533c:      	cset	w8, hi
    5340:      	mov	x10, #0x1               ; =1
    5344:      	movk	x10, #0x7fff, lsl #48
    5348:      	cmp	x9, x10
    534c:      	ccmp	x23, x21, #0x0, lo
    5350:      	b.hi	0x5360 <_perry_fn_access_worker_ts__run$generic+0x22cc>
    5354:      	cbz	w8, 0x5360 <_perry_fn_access_worker_ts__run$generic+0x22cc>
    5358:      	fadd	d0, d1, d0
    535c:      	b	0x536c <_perry_fn_access_worker_ts__run$generic+0x22d8>
    5360:      	stp	x26, x28, [sp, #0x20]
    5364:      	bl	0x5364 <_perry_fn_access_worker_ts__run$generic+0x22d0>
		0000000000005364:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    5368:      	ldp	x26, x28, [sp, #0x20]
    536c:      	fmov	x23, d0
    5370:      	mov	x0, x23
    5374:      	ldr	w8, [x27]
    5378:      	cbz	w8, 0x5380 <_perry_fn_access_worker_ts__run$generic+0x22ec>
    537c:      	bl	0x537c <_perry_fn_access_worker_ts__run$generic+0x22e8>
		000000000000537c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    5380:      	mov	x0, x23
    5384:      	ldr	w8, [x27]
    5388:      	cbz	w8, 0x5390 <_perry_fn_access_worker_ts__run$generic+0x22fc>
    538c:      	bl	0x538c <_perry_fn_access_worker_ts__run$generic+0x22f8>
		000000000000538c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    5390:      	mov	x10, x28
    5394:      	and	x8, x10, #0xffffffffffff
    5398:      	and	x12, x10, #0xffff000000000000
    539c:      	cmp	x12, x24
    53a0:      	b.ne	0x543c <_perry_fn_access_worker_ts__run$generic+0x23a8>
    53a4:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000053a4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    53a8:      	ldr	x9, [x9]
		00000000000053a8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    53ac:      	ldr	x9, [x9]
    53b0:      	cbnz	x9, 0x543c <_perry_fn_access_worker_ts__run$generic+0x23a8>
    53b4:      	sub	x9, x8, #0x100, lsl #12 ; =0x100000
    53b8:      	mov	x11, #0x7ffffff00000    ; =140737487306752
    53bc:      	cmp	x9, x11
    53c0:      	b.hs	0x543c <_perry_fn_access_worker_ts__run$generic+0x23a8>
    53c4:      	mov	x9, #0x41f0000000000000 ; =4751297606875873280
    53c8:      	fmov	d0, x9
    53cc:      	fcmp	d8, d0
    53d0:      	b.pl	0x543c <_perry_fn_access_worker_ts__run$generic+0x23a8>
    53d4:      	fcmp	d8, #0.0
    53d8:      	b.lt	0x543c <_perry_fn_access_worker_ts__run$generic+0x23a8>
    53dc:      	ldurb	w9, [x8, #-0x8]
    53e0:      	cmp	w9, #0xb
    53e4:      	b.ne	0x543c <_perry_fn_access_worker_ts__run$generic+0x23a8>
    53e8:      	ldrb	w11, [x8, #0x8]
    53ec:      	cmp	w11, #0x9
    53f0:      	b.hs	0x543c <_perry_fn_access_worker_ts__run$generic+0x23a8>
    53f4:      	fcvtzs	x9, d8
    53f8:      	scvtf	d0, x9
    53fc:      	fcmp	d8, d0
    5400:      	b.ne	0x543c <_perry_fn_access_worker_ts__run$generic+0x23a8>
    5404:      	ldr	w13, [x8]
    5408:      	cmp	x9, x13
    540c:      	b.hs	0x543c <_perry_fn_access_worker_ts__run$generic+0x23a8>
    5410:      	add	x8, x8, #0x10
    5414:      	cmp	w11, #0x3
    5418:      	b.le	0x54e8 <_perry_fn_access_worker_ts__run$generic+0x2454>
    541c:      	cmp	w11, #0x5
    5420:      	b.gt	0x5598 <_perry_fn_access_worker_ts__run$generic+0x2504>
    5424:      	cmp	w11, #0x4
    5428:      	b.eq	0x5664 <_perry_fn_access_worker_ts__run$generic+0x25d0>
    542c:      	cmp	w11, #0x5
    5430:      	b.ne	0x5658 <_perry_fn_access_worker_ts__run$generic+0x25c4>
    5434:      	ldr	s0, [x8, x9, lsl #2]
    5438:      	b	0x565c <_perry_fn_access_worker_ts__run$generic+0x25c8>
    543c:      	cmp	x12, x24
    5440:      	b.ne	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5444:      	fcmp	d8, #0.0
    5448:      	b.lt	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    544c:      	fcmp	d8, d10
    5450:      	b.pl	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5454:      	mov	x9, #-0x20000000000     ; =-2199023255552
    5458:      	add	x9, x8, x9
    545c:      	lsr	x9, x9, #41
    5460:      	cmp	x9, #0x3f
    5464:      	b.hs	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5468:      	fcvtzs	x9, d8
    546c:      	scvtf	d0, x9
    5470:      	fcmp	d8, d0
    5474:      	b.ne	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5478:      	ldursb	w11, [x8, #-0x7]
    547c:      	tbnz	w11, #0x1f, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5480:      	ldurb	w11, [x8, #-0x8]
    5484:      	cmp	w11, #0x9
    5488:      	b.eq	0x554c <_perry_fn_access_worker_ts__run$generic+0x24b8>
    548c:      	cmp	w11, #0x2
    5490:      	b.eq	0x5504 <_perry_fn_access_worker_ts__run$generic+0x2470>
    5494:      	cmp	w11, #0x1
    5498:      	b.ne	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    549c:      	ldr	w10, [x8]
    54a0:      	mov	x11, x8
    54a4:      	ldurh	w13, [x8, #-0x6]
    54a8:      	adrp	x12, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000054a8:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    54ac:      	ldr	x12, [x12]
		00000000000054ac:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    54b0:      	ldrb	w12, [x12]
    54b4:      	ldr	w8, [x8, #0x4]
    54b8:      	cmp	x10, x8
    54bc:      	b.hi	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    54c0:      	tbnz	w13, #0xa, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    54c4:      	cbnz	w12, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    54c8:      	cmp	x9, x10
    54cc:      	b.hs	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    54d0:      	add	x8, x11, x9, lsl #3
    54d4:      	ldr	d0, [x8, #0x8]
    54d8:      	fmov	x8, d0
    54dc:      	cmp	x8, x19
    54e0:      	fcsel	d0, d11, d0, eq
    54e4:      	b	0x57cc <_perry_fn_access_worker_ts__run$generic+0x2738>
    54e8:      	cbz	w11, 0x5650 <_perry_fn_access_worker_ts__run$generic+0x25bc>
    54ec:      	cmp	w11, #0x2
    54f0:      	b.eq	0x5678 <_perry_fn_access_worker_ts__run$generic+0x25e4>
    54f4:      	cmp	w11, #0x3
    54f8:      	b.ne	0x5658 <_perry_fn_access_worker_ts__run$generic+0x25c4>
    54fc:      	ldr	h0, [x8, x9, lsl #1]
    5500:      	b	0x565c <_perry_fn_access_worker_ts__run$generic+0x25c8>
    5504:      	ldr	x10, [x8, #0x8]
    5508:      	cbz	x10, 0x55b0 <_perry_fn_access_worker_ts__run$generic+0x251c>
    550c:      	ldr	x11, [x10, #0x60]
    5510:      	cbz	x11, 0x55b0 <_perry_fn_access_worker_ts__run$generic+0x251c>
    5514:      	ldurb	w8, [x11, #-0x8]
    5518:      	cmp	w8, #0x1
    551c:      	b.ne	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5520:      	ldursb	w8, [x11, #-0x7]
    5524:      	tbnz	w8, #0x1f, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5528:      	ldr	w8, [x11]
    552c:      	cmp	x9, x8
    5530:      	b.hs	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5534:      	add	x8, x11, x9, lsl #3
    5538:      	ldr	d0, [x8, #0x8]
    553c:      	fmov	x8, d0
    5540:      	cmp	x8, x19
    5544:      	b.eq	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5548:      	b	0x57cc <_perry_fn_access_worker_ts__run$generic+0x2738>
    554c:      	ldr	w12, [x8, #0x4]
    5550:      	ldr	x11, [x8, #0x20]
    5554:      	ldurh	w13, [x8, #-0x6]
    5558:      	tst	w13, #0xc00
    555c:      	mov	w13, #0x5841            ; =22593
    5560:      	movk	w13, #0x4c5a, lsl #16
    5564:      	ccmp	w12, w13, #0x0, eq
    5568:      	cset	w12, eq
    556c:      	cbz	x11, 0x5618 <_perry_fn_access_worker_ts__run$generic+0x2584>
    5570:      	tbz	w12, #0x0, 0x5618 <_perry_fn_access_worker_ts__run$generic+0x2584>
    5574:      	ldurb	w10, [x11, #-0x8]
    5578:      	cmp	w10, #0x1
    557c:      	b.ne	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5580:      	ldursb	w10, [x11, #-0x7]
    5584:      	tbnz	w10, #0x1f, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5588:      	ldr	w10, [x11]
    558c:      	str	w10, [x8]
    5590:      	mov	x8, x11
    5594:      	b	0x54a4 <_perry_fn_access_worker_ts__run$generic+0x2410>
    5598:      	cmp	w11, #0x6
    559c:      	b.eq	0x566c <_perry_fn_access_worker_ts__run$generic+0x25d8>
    55a0:      	cmp	w11, #0x7
    55a4:      	b.ne	0x5658 <_perry_fn_access_worker_ts__run$generic+0x25c4>
    55a8:      	ldr	d0, [x8, x9, lsl #3]
    55ac:      	b	0x57cc <_perry_fn_access_worker_ts__run$generic+0x2738>
    55b0:      	adrp	x12, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000055b0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__30
    55b4:      	add	x12, x12, #0x0
		00000000000055b4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__30
    55b8:      	ldr	x11, [x12]
    55bc:      	cmp	x11, #0x0
    55c0:      	csel	x12, x12, x11, eq
    55c4:      	ldr	x12, [x12]
    55c8:      	cbz	x12, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    55cc:      	tbnz	x12, #0x3f, 0x5684 <_perry_fn_access_worker_ts__run$generic+0x25f0>
    55d0:      	ldp	w14, w13, [x8]
    55d4:      	orr	x13, x13, x14, lsl #32
    55d8:      	cmp	x13, x12
    55dc:      	b.ne	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    55e0:      	ldp	x14, x12, [x11, #0x8]
    55e4:      	ldp	x13, x11, [x11, #0x18]
    55e8:      	cmp	x14, x11
    55ec:      	b.lo	0x56a4 <_perry_fn_access_worker_ts__run$generic+0x2610>
    55f0:      	cbz	x10, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    55f4:      	b	0x56f4 <_perry_fn_access_worker_ts__run$generic+0x2660>
    55f8:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000055f8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    55fc:      	ldr	x8, [x8]
		00000000000055fc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    5600:      	str	x23, [sp, #0x28]
    5604:      	and	x1, x8, #0xffffffffffff
    5608:      	adrp	x3, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005608:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__29
    560c:      	add	x3, x3, #0x0
		000000000000560c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__29
    5610:      	bl	0x5610 <_perry_fn_access_worker_ts__run$generic+0x257c>
		0000000000005610:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    5614:      	b	0x52bc <_perry_fn_access_worker_ts__run$generic+0x2228>
    5618:      	cmp	x11, #0x0
    561c:      	ldr	w14, [x8]
    5620:      	ldp	x11, x13, [x8, #0x28]
    5624:      	ccmp	x9, x14, #0x2, eq
    5628:      	ccmp	x11, #0x0, #0x4, lo
    562c:      	ccmp	x13, #0x0, #0x4, ne
    5630:      	csel	w12, wzr, w12, eq
    5634:      	tbz	w12, #0x0, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5638:      	lsr	x12, x9, #6
    563c:      	ldr	x12, [x13, x12, lsl #3]
    5640:      	lsr	x12, x12, x9
    5644:      	tbz	w12, #0x0, 0x56b0 <_perry_fn_access_worker_ts__run$generic+0x261c>
    5648:      	ldr	d0, [x11, x9, lsl #3]
    564c:      	b	0x57cc <_perry_fn_access_worker_ts__run$generic+0x2738>
    5650:      	ldrsb	w8, [x8, x9]
    5654:      	b	0x567c <_perry_fn_access_worker_ts__run$generic+0x25e8>
    5658:      	ldr	b0, [x8, x9]
    565c:      	ucvtf	d0, d0
    5660:      	b	0x57cc <_perry_fn_access_worker_ts__run$generic+0x2738>
    5664:      	ldr	w8, [x8, x9, lsl #2]
    5668:      	b	0x567c <_perry_fn_access_worker_ts__run$generic+0x25e8>
    566c:      	ldr	s0, [x8, x9, lsl #2]
    5670:      	fcvt	d0, s0
    5674:      	b	0x57cc <_perry_fn_access_worker_ts__run$generic+0x2738>
    5678:      	ldrsh	w8, [x8, x9, lsl #1]
    567c:      	scvtf	d0, w8
    5680:      	b	0x57cc <_perry_fn_access_worker_ts__run$generic+0x2738>
    5684:      	cbz	x10, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5688:      	ldr	x13, [x10, #0x30]
    568c:      	cmp	x13, x12
    5690:      	b.ne	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5694:      	ldp	x14, x12, [x11, #0x8]
    5698:      	ldp	x13, x11, [x11, #0x18]
    569c:      	cmp	x14, x11
    56a0:      	b.hs	0x56f4 <_perry_fn_access_worker_ts__run$generic+0x2660>
    56a4:      	add	x14, x8, x14, lsl #3
    56a8:      	add	x14, x14, #0x10
    56ac:      	b	0x5718 <_perry_fn_access_worker_ts__run$generic+0x2684>
    56b0:      	ldr	x8, [x8, #0x50]
    56b4:      	mov	x12, #0x6107            ; =24839
    56b8:      	movk	x12, #0x7463, lsl #16
    56bc:      	movk	x12, #0x7669, lsl #32
    56c0:      	movk	x12, #0x65, lsl #48
    56c4:      	cmp	x8, x12
    56c8:      	b.eq	0x56d0 <_perry_fn_access_worker_ts__run$generic+0x263c>
    56cc:      	cbnz	x8, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    56d0:      	cmp	x8, x12
    56d4:      	b.ne	0x5780 <_perry_fn_access_worker_ts__run$generic+0x26ec>
    56d8:      	ldr	x8, [x11, x9, lsl #3]
    56dc:      	cbz	x8, 0x5780 <_perry_fn_access_worker_ts__run$generic+0x26ec>
    56e0:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    56e4:      	cmp	x8, x9
    56e8:      	csel	x8, xzr, x8, eq
    56ec:      	fmov	d0, x8
    56f0:      	b	0x59b8 <_perry_fn_access_worker_ts__run$generic+0x2924>
    56f4:      	ldr	x16, [x10, #0x20]
    56f8:      	cmp	x16, #0x0
    56fc:      	csel	x15, x16, x10, ne
    5700:      	cbz	x16, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5704:      	ldr	w16, [x15]
    5708:      	cmp	x14, x16
    570c:      	b.hs	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5710:      	add	x14, x15, x14, lsl #3
    5714:      	add	x14, x14, #0x8
    5718:      	ldr	d0, [x14]
    571c:      	fcmp	d8, d0
    5720:      	ccmp	x13, x9, #0x0, mi
    5724:      	cset	w13, hi
    5728:      	add	x9, x12, x9
    572c:      	cmp	x9, x11
    5730:      	b.hs	0x5744 <_perry_fn_access_worker_ts__run$generic+0x26b0>
    5734:      	cbz	w13, 0x5744 <_perry_fn_access_worker_ts__run$generic+0x26b0>
    5738:      	add	x8, x8, x9, lsl #3
    573c:      	ldr	d0, [x8, #0x10]
    5740:      	b	0x57cc <_perry_fn_access_worker_ts__run$generic+0x2738>
    5744:      	cbz	x10, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5748:      	cmp	x9, x11
    574c:      	b.lo	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5750:      	eor	w8, w13, #0x1
    5754:      	tbnz	w8, #0x0, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5758:      	ldr	x11, [x10, #0x20]
    575c:      	cmp	x11, #0x0
    5760:      	csel	x8, x11, x10, ne
    5764:      	cbz	x11, 0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5768:      	ldr	w10, [x8]
    576c:      	cmp	x9, x10
    5770:      	b.hs	0x57a4 <_perry_fn_access_worker_ts__run$generic+0x2710>
    5774:      	add	x8, x8, x9, lsl #3
    5778:      	ldr	d0, [x8, #0x8]
    577c:      	b	0x57cc <_perry_fn_access_worker_ts__run$generic+0x2738>
    5780:      	fmov	d0, x10
    5784:      	mov.16b	v1, v8
    5788:      	adrp	x0, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005788:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.5.bytes
    578c:      	add	x0, x0, #0x0
		000000000000578c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.5.bytes
    5790:      	mov	w1, #0x6                ; =6
    5794:      	bl	0x5794 <_perry_fn_access_worker_ts__run$generic+0x2700>
		0000000000005794:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    5798:      	fmov	x8, d0
    579c:      	cmp	x8, x19
    57a0:      	b.ne	0x59b8 <_perry_fn_access_worker_ts__run$generic+0x2924>
    57a4:      	mov	x8, x28
    57a8:      	stp	x28, x23, [sp, #0x20]
    57ac:      	fmov	d0, x8
    57b0:      	str	x26, [sp, #0x18]
    57b4:      	mov.16b	v1, v8
    57b8:      	adrp	x0, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000057b8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__30
    57bc:      	add	x0, x0, #0x0
		00000000000057bc:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__30
    57c0:      	bl	0x57c0 <_perry_fn_access_worker_ts__run$generic+0x272c>
		00000000000057c0:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    57c4:      	ldp	x26, x28, [sp, #0x18]
    57c8:      	ldr	x23, [sp, #0x28]
    57cc:      	fmov	x8, d0
    57d0:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    57d4:      	and	x9, x8, x9
    57d8:      	cmp	x9, x24
    57dc:      	b.ne	0x5844 <_perry_fn_access_worker_ts__run$generic+0x27b0>
    57e0:      	and	x0, x8, #0xffffffffffff
    57e4:      	lsr	x8, x0, #20
    57e8:      	cbz	x8, 0x5990 <_perry_fn_access_worker_ts__run$generic+0x28fc>
    57ec:      	ldurb	w9, [x0, #-0x8]
    57f0:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000057f0:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__32
    57f4:      	ldr	x8, [x8]
		00000000000057f4:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__32
    57f8:      	cbz	x8, 0x58bc <_perry_fn_access_worker_ts__run$generic+0x2828>
    57fc:      	cmp	w9, #0x2
    5800:      	b.ne	0x58bc <_perry_fn_access_worker_ts__run$generic+0x2828>
    5804:      	ldurh	w10, [x0, #-0x6]
    5808:      	tbnz	w10, #0xb, 0x58bc <_perry_fn_access_worker_ts__run$generic+0x2828>
    580c:      	ldr	w10, [x0, #0x4]
    5810:      	orr	x9, x10, #0x4000000000000000
    5814:      	cbz	w10, 0x58e8 <_perry_fn_access_worker_ts__run$generic+0x2854>
    5818:      	ldr	x11, [x8]
    581c:      	cmp	x9, x11
    5820:      	b.ne	0x58e8 <_perry_fn_access_worker_ts__run$generic+0x2854>
    5824:      	ldr	x2, [x8, #0x8]
    5828:      	tbnz	w2, #0x1e, 0x5aa0 <_perry_fn_access_worker_ts__run$generic+0x2a0c>
    582c:      	add	x11, x0, x2, lsl #3
    5830:      	ldr	d0, [x11, #0x10]
    5834:      	fmov	x11, d0
    5838:      	cmp	x11, x19
    583c:      	b.ne	0x59b8 <_perry_fn_access_worker_ts__run$generic+0x2924>
    5840:      	b	0x5914 <_perry_fn_access_worker_ts__run$generic+0x2880>
    5844:      	lsr	x9, x8, #48
    5848:      	mov	w10, #0x7ff9            ; =32761
    584c:      	cmp	x9, x10
    5850:      	b.eq	0x589c <_perry_fn_access_worker_ts__run$generic+0x2808>
    5854:      	mov	w10, #0x7ffe            ; =32766
    5858:      	cmp	w9, w10
    585c:      	b.ne	0x588c <_perry_fn_access_worker_ts__run$generic+0x27f8>
    5860:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005860:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    5864:      	ldr	x9, [x9]
		0000000000005864:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    5868:      	stp	x28, x23, [sp, #0x20]
    586c:      	str	x26, [sp, #0x18]
    5870:      	and	x2, x9, #0xffffffffffff
    5874:      	mov	x0, #0x1f               ; =31
    5878:      	movk	x0, #0xddae, lsl #32
    587c:      	movk	x0, #0x5556, lsl #48
    5880:      	mov	x1, x8
    5884:      	bl	0x5884 <_perry_fn_access_worker_ts__run$generic+0x27f0>
		0000000000005884:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    5888:      	b	0x59b0 <_perry_fn_access_worker_ts__run$generic+0x291c>
    588c:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    5890:      	add	x9, x8, x9
    5894:      	cmp	x9, #0x2
    5898:      	b.lo	0x62f8 <_perry_fn_access_worker_ts__run$generic+0x3264>
    589c:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		000000000000589c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    58a0:      	ldr	x9, [x9]
		00000000000058a0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    58a4:      	stp	x28, x23, [sp, #0x20]
    58a8:      	str	x26, [sp, #0x18]
    58ac:      	and	x1, x9, #0xffffffffffff
    58b0:      	mov	x0, x8
    58b4:      	bl	0x58b4 <_perry_fn_access_worker_ts__run$generic+0x2820>
		00000000000058b4:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    58b8:      	b	0x59b0 <_perry_fn_access_worker_ts__run$generic+0x291c>
    58bc:      	cmp	w9, #0x2
    58c0:      	b.ne	0x5990 <_perry_fn_access_worker_ts__run$generic+0x28fc>
    58c4:      	cbz	x8, 0x5990 <_perry_fn_access_worker_ts__run$generic+0x28fc>
    58c8:      	ldr	x9, [x8, #0x10]
    58cc:      	cbz	x9, 0x5990 <_perry_fn_access_worker_ts__run$generic+0x28fc>
    58d0:      	ldr	x10, [x0, #0x8]
    58d4:      	cbz	x10, 0x5990 <_perry_fn_access_worker_ts__run$generic+0x28fc>
    58d8:      	ldr	x10, [x10, #0x30]
    58dc:      	cmp	x10, x9
    58e0:      	b.eq	0x5904 <_perry_fn_access_worker_ts__run$generic+0x2870>
    58e4:      	b	0x5990 <_perry_fn_access_worker_ts__run$generic+0x28fc>
    58e8:      	ldr	x11, [x8, #0x10]
    58ec:      	cbz	x11, 0x5914 <_perry_fn_access_worker_ts__run$generic+0x2880>
    58f0:      	ldr	x12, [x0, #0x8]
    58f4:      	cbz	x12, 0x5914 <_perry_fn_access_worker_ts__run$generic+0x2880>
    58f8:      	ldr	x12, [x12, #0x30]
    58fc:      	cmp	x12, x11
    5900:      	b.ne	0x5914 <_perry_fn_access_worker_ts__run$generic+0x2880>
    5904:      	ldr	x8, [x8, #0x8]
    5908:      	add	x8, x0, x8, lsl #3
    590c:      	ldr	d0, [x8, #0x10]
    5910:      	b	0x59b8 <_perry_fn_access_worker_ts__run$generic+0x2924>
    5914:      	ldr	x11, [x8, #0x18]
    5918:      	cmp	x11, #0x0
    591c:      	b.le	0x5990 <_perry_fn_access_worker_ts__run$generic+0x28fc>
    5920:      	ldr	x11, [x8, #0x20]
    5924:      	ldr	x12, [x8, #0x30]
    5928:      	ldr	x13, [x8, #0x40]
    592c:      	cmp	x13, x9
    5930:      	ldr	x14, [x8, #0x50]
    5934:      	ccmp	x14, x9, #0x4, ne
    5938:      	ccmp	x12, x9, #0x4, ne
    593c:      	ccmp	x11, x9, #0x4, ne
    5940:      	cset	w15, eq
    5944:      	cbz	w10, 0x5990 <_perry_fn_access_worker_ts__run$generic+0x28fc>
    5948:      	cbz	w15, 0x5990 <_perry_fn_access_worker_ts__run$generic+0x28fc>
    594c:      	ldr	x10, [x8, #0x48]
    5950:      	ldr	x15, [x8, #0x58]
    5954:      	cmp	x14, x9
    5958:      	csel	x14, x15, xzr, eq
    595c:      	cmp	x13, x9
    5960:      	csel	x10, x10, x14, eq
    5964:      	ldr	x13, [x8, #0x28]
    5968:      	ldr	x8, [x8, #0x38]
    596c:      	cmp	x12, x9
    5970:      	csel	x8, x8, x10, eq
    5974:      	cmp	x11, x9
    5978:      	csel	x8, x13, x8, eq
    597c:      	add	x8, x0, x8, lsl #3
    5980:      	ldr	d0, [x8, #0x10]
    5984:      	fmov	x8, d0
    5988:      	cmp	x8, x19
    598c:      	b.ne	0x59b8 <_perry_fn_access_worker_ts__run$generic+0x2924>
    5990:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005990:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    5994:      	ldr	x8, [x8]
		0000000000005994:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    5998:      	stp	x28, x23, [sp, #0x20]
    599c:      	str	x26, [sp, #0x18]
    59a0:      	and	x1, x8, #0xffffffffffff
    59a4:      	adrp	x2, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		00000000000059a4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__32
    59a8:      	add	x2, x2, #0x0
		00000000000059a8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__32
    59ac:      	bl	0x59ac <_perry_fn_access_worker_ts__run$generic+0x2918>
		00000000000059ac:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    59b0:      	ldp	x26, x28, [sp, #0x18]
    59b4:      	ldr	x23, [sp, #0x28]
    59b8:      	fmov	x8, d0
    59bc:      	mov	x9, #0x7ff8000000000000 ; =9221120237041090560
    59c0:      	bics	xzr, x9, x8
    59c4:      	b.ne	0x59ec <_perry_fn_access_worker_ts__run$generic+0x2958>
    59c8:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    59cc:      	add	x9, x8, x9
    59d0:      	cmp	x9, #0x4
    59d4:      	b.hs	0x5a00 <_perry_fn_access_worker_ts__run$generic+0x296c>
    59d8:      	sub	x9, x19, #0xc
    59dc:      	movi.2d	v1, #0000000000000000
    59e0:      	cmp	x8, x9
    59e4:      	b.eq	0x5a1c <_perry_fn_access_worker_ts__run$generic+0x2988>
    59e8:      	b	0x5a20 <_perry_fn_access_worker_ts__run$generic+0x298c>
    59ec:      	movi.2d	v1, #0000000000000000
    59f0:      	fcmp	d0, #0.0
    59f4:      	b.eq	0x5a20 <_perry_fn_access_worker_ts__run$generic+0x298c>
    59f8:      	b.vs	0x5a20 <_perry_fn_access_worker_ts__run$generic+0x298c>
    59fc:      	b	0x5a1c <_perry_fn_access_worker_ts__run$generic+0x2988>
    5a00:      	mov	w9, #0x7ffd             ; =32765
    5a04:      	cmp	x9, x8, lsr #48
    5a08:      	b.ne	0x5a14 <_perry_fn_access_worker_ts__run$generic+0x2980>
    5a0c:      	and	x8, x8, #0xffffffffffff
    5a10:      	cbnz	x8, 0x5a1c <_perry_fn_access_worker_ts__run$generic+0x2988>
    5a14:      	bl	0x5a14 <_perry_fn_access_worker_ts__run$generic+0x2980>
		0000000000005a14:  ARM64_RELOC_BRANCH26	_js_is_truthy
    5a18:      	cbz	w0, 0x5a98 <_perry_fn_access_worker_ts__run$generic+0x2a04>
    5a1c:      	fmov	d1, #1.00000000
    5a20:      	fmov	d0, x23
    5a24:      	and	x8, x23, #0xffff000000000000
    5a28:      	cmp	x23, x22
    5a2c:      	ccmp	x8, x25, #0x2, hs
    5a30:      	cset	w8, hi
    5a34:      	fmov	x9, d1
    5a38:      	cmp	x9, x21
    5a3c:      	b.hi	0x5a4c <_perry_fn_access_worker_ts__run$generic+0x29b8>
    5a40:      	tbz	w8, #0x0, 0x5a4c <_perry_fn_access_worker_ts__run$generic+0x29b8>
    5a44:      	fadd	d0, d1, d0
    5a48:      	b	0x5a58 <_perry_fn_access_worker_ts__run$generic+0x29c4>
    5a4c:      	stp	x26, x28, [sp, #0x20]
    5a50:      	bl	0x5a50 <_perry_fn_access_worker_ts__run$generic+0x29bc>
		0000000000005a50:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    5a54:      	ldp	x26, x28, [sp, #0x20]
    5a58:      	fmov	x23, d0
    5a5c:      	mov	x0, x23
    5a60:      	ldr	w8, [x27]
    5a64:      	cbz	w8, 0x5a6c <_perry_fn_access_worker_ts__run$generic+0x29d8>
    5a68:      	bl	0x5a68 <_perry_fn_access_worker_ts__run$generic+0x29d4>
		0000000000005a68:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    5a6c:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005a6c:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    5a70:      	ldr	x8, [x8]
		0000000000005a70:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    5a74:      	ldr	w8, [x8]
    5a78:      	cbz	w8, 0x5a90 <_perry_fn_access_worker_ts__run$generic+0x29fc>
    5a7c:      	stp	x28, x26, [sp, #0x20]
    5a80:      	str	x23, [sp, #0x18]
    5a84:      	bl	0x5a84 <_perry_fn_access_worker_ts__run$generic+0x29f0>
		0000000000005a84:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    5a88:      	ldp	x23, x28, [sp, #0x18]
    5a8c:      	ldr	x26, [sp, #0x28]
    5a90:      	add	w20, w20, #0x1
    5a94:      	b	0x4528 <_perry_fn_access_worker_ts__run$generic+0x1494>
    5a98:      	movi.2d	v1, #0000000000000000
    5a9c:      	b	0x5a20 <_perry_fn_access_worker_ts__run$generic+0x298c>
    5aa0:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005aa0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    5aa4:      	ldr	x8, [x8]
		0000000000005aa4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    5aa8:      	stp	x28, x23, [sp, #0x20]
    5aac:      	str	x26, [sp, #0x18]
    5ab0:      	and	x1, x8, #0xffffffffffff
    5ab4:      	adrp	x3, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005ab4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__32
    5ab8:      	add	x3, x3, #0x0
		0000000000005ab8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__32
    5abc:      	bl	0x5abc <_perry_fn_access_worker_ts__run$generic+0x2a28>
		0000000000005abc:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    5ac0:      	b	0x59b0 <_perry_fn_access_worker_ts__run$generic+0x291c>
    5ac4:      	mov	x21, x20
    5ac8:      	mov	w24, #0x0               ; =0
    5acc:      	mov	x23, #0x0               ; =0
    5ad0:      	mov	x25, #0x7ffd000000000000 ; =9222527611924643840
    5ad4:      	ldr	d10, [x22]
		0000000000005ad4:  ARM64_RELOC_PAGEOFF12	lCPI1_2
    5ad8:      	ldr	d11, [x11]
		0000000000005ad8:  ARM64_RELOC_PAGEOFF12	lCPI1_3
    5adc:      	mov	x22, #0x7ff9000000000000 ; =9221401712017801216
    5ae0:      	mov	x8, #0x41f0000000000000 ; =4751297606875873280
    5ae4:      	fmov	d12, x8
    5ae8:      	movi.2d	v13, #0000000000000000
    5aec:      	fmov	d14, #1.00000000
    5af0:      	tbnz	w21, #0x0, 0x5be8 <_perry_fn_access_worker_ts__run$generic+0x2b54>
    5af4:      	scvtf	d8, w24
    5af8:      	mov	x8, x26
    5afc:      	fmov	d1, x8
    5b00:      	and	x9, x8, #0xffff000000000000
    5b04:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    5b08:      	cmp	x9, x10
    5b0c:      	b.eq	0x5b48 <_perry_fn_access_worker_ts__run$generic+0x2ab4>
    5b10:      	cmp	x8, x22
    5b14:      	b.lt	0x5b48 <_perry_fn_access_worker_ts__run$generic+0x2ab4>
    5b18:      	mov	x10, #-0x7ffc000000000001 ; =-9222246136947933185
    5b1c:      	add	x10, x8, x10
    5b20:      	cmp	x10, #0x3
    5b24:      	b.ls	0x5b48 <_perry_fn_access_worker_ts__run$generic+0x2ab4>
    5b28:      	stp	x26, x23, [sp, #0x20]
    5b2c:      	str	x28, [sp, #0x18]
    5b30:      	mov.16b	v0, v8
    5b34:      	bl	0x5b34 <_perry_fn_access_worker_ts__run$generic+0x2aa0>
		0000000000005b34:  ARM64_RELOC_BRANCH26	_js_rel_lt
    5b38:      	mov.16b	v9, v0
    5b3c:      	ldp	x28, x26, [sp, #0x18]
    5b40:      	ldr	x23, [sp, #0x28]
    5b44:      	b	0x5bb0 <_perry_fn_access_worker_ts__run$generic+0x2b1c>
    5b48:      	mov	x12, #0x10              ; =16
    5b4c:      	movk	x12, #0x7ffc, lsl #48
    5b50:      	sub	x10, x12, #0xc
    5b54:      	and	x11, x8, #0xfffffffffffffffe
    5b58:      	mov	x19, #0x10              ; =16
    5b5c:      	movk	x19, #0x7ffc, lsl #48
    5b60:      	sub	x12, x12, #0xe
    5b64:      	scvtf	d0, w8
    5b68:      	mov	x13, #0x7ffe000000000000 ; =9222809086901354496
    5b6c:      	cmp	x9, x13
    5b70:      	fcsel	d0, d0, d1, eq
    5b74:      	cmp	x11, x12
    5b78:      	fcsel	d0, d13, d0, eq
    5b7c:      	cmp	x8, x10
    5b80:      	fcsel	d0, d14, d0, eq
    5b84:      	fmov	x8, d8
    5b88:      	scvtf	d1, w8
    5b8c:      	mov	w9, #0x7ffe             ; =32766
    5b90:      	cmp	x9, x8, lsr #48
    5b94:      	fcsel	d1, d1, d8, eq
    5b98:      	fcmp	d1, d0
    5b9c:      	mov	w8, #0x8                ; =8
    5ba0:      	csel	x8, x8, xzr, mi
    5ba4:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005ba4:  ARM64_RELOC_PAGE21	lCPI1_1
    5ba8:      	add	x9, x9, #0x0
		0000000000005ba8:  ARM64_RELOC_PAGEOFF12	lCPI1_1
    5bac:      	ldr	d9, [x9, x8]
    5bb0:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005bb0:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    5bb4:      	ldr	x8, [x8]
		0000000000005bb4:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    5bb8:      	ldr	w8, [x8]
    5bbc:      	cbz	w8, 0x5bd4 <_perry_fn_access_worker_ts__run$generic+0x2b40>
    5bc0:      	stp	x28, x26, [sp, #0x20]
    5bc4:      	str	x23, [sp, #0x18]
    5bc8:      	bl	0x5bc8 <_perry_fn_access_worker_ts__run$generic+0x2b34>
		0000000000005bc8:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    5bcc:      	ldp	x23, x28, [sp, #0x18]
    5bd0:      	ldr	x26, [sp, #0x28]
    5bd4:      	fmov	x8, d9
    5bd8:      	sub	x9, x19, #0xc
    5bdc:      	cmp	x8, x9
    5be0:      	b.ne	0x3268 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    5be4:      	b	0x5bf4 <_perry_fn_access_worker_ts__run$generic+0x2b60>
    5be8:      	cmp	w24, w20
    5bec:      	b.ge	0x3268 <_perry_fn_access_worker_ts__run$generic+0x1d4>
    5bf0:      	scvtf	d8, w24
    5bf4:      	adrp	x8, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005bf4:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    5bf8:      	ldr	d1, [x8]
		0000000000005bf8:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    5bfc:      	stp	x28, x23, [sp, #0x20]
    5c00:      	str	x26, [sp, #0x18]
    5c04:      	mov.16b	v0, v8
    5c08:      	bl	0x5c08 <_perry_fn_access_worker_ts__run$generic+0x2b74>
		0000000000005c08:  ARM64_RELOC_BRANCH26	_js_dynamic_mod
    5c0c:      	mov.16b	v8, v0
    5c10:      	ldp	x26, x28, [sp, #0x18]
    5c14:      	ldr	x23, [sp, #0x28]
    5c18:      	mov	x0, x23
    5c1c:      	ldr	w8, [x27]
    5c20:      	cbz	w8, 0x5c28 <_perry_fn_access_worker_ts__run$generic+0x2b94>
    5c24:      	bl	0x5c24 <_perry_fn_access_worker_ts__run$generic+0x2b90>
		0000000000005c24:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    5c28:      	mov	x10, x28
    5c2c:      	and	x8, x10, #0xffffffffffff
    5c30:      	and	x12, x10, #0xffff000000000000
    5c34:      	adrp	x9, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005c34:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_TA_VIEW_GUARD
    5c38:      	ldr	x9, [x9]
		0000000000005c38:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_TA_VIEW_GUARD
    5c3c:      	ldr	x9, [x9]
    5c40:      	sub	x11, x8, #0x100, lsl #12 ; =0x100000
    5c44:      	cmp	x12, x25
    5c48:      	ccmp	x9, #0x0, #0x0, eq
    5c4c:      	mov	x9, #0x7ffffff00000     ; =140737487306752
    5c50:      	ccmp	x11, x9, #0x2, eq
    5c54:      	b.hs	0x5c90 <_perry_fn_access_worker_ts__run$generic+0x2bfc>
    5c58:      	fcmp	d8, d12
    5c5c:      	b.pl	0x5c90 <_perry_fn_access_worker_ts__run$generic+0x2bfc>
    5c60:      	ldurb	w9, [x8, #-0x8]
    5c64:      	ldrb	w11, [x8, #0x8]
    5c68:      	fcmp	d8, #0.0
    5c6c:      	ccmp	w9, #0xb, #0x0, ge
    5c70:      	ccmp	w11, #0x9, #0x2, eq
    5c74:      	b.hs	0x5c90 <_perry_fn_access_worker_ts__run$generic+0x2bfc>
    5c78:      	fcvtzs	x9, d8
    5c7c:      	scvtf	d0, x9
    5c80:      	ldr	w13, [x8]
    5c84:      	fcmp	d8, d0
    5c88:      	ccmp	x9, x13, #0x2, eq
    5c8c:      	b.lo	0x5d3c <_perry_fn_access_worker_ts__run$generic+0x2ca8>
    5c90:      	cmp	x12, x25
    5c94:      	b.ne	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5c98:      	fcmp	d8, #0.0
    5c9c:      	b.lt	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5ca0:      	fcmp	d8, d10
    5ca4:      	b.pl	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5ca8:      	mov	x9, #-0x20000000000     ; =-2199023255552
    5cac:      	add	x9, x8, x9
    5cb0:      	lsr	x9, x9, #41
    5cb4:      	cmp	x9, #0x3f
    5cb8:      	b.hs	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5cbc:      	fcvtzs	x9, d8
    5cc0:      	scvtf	d0, x9
    5cc4:      	fcmp	d8, d0
    5cc8:      	b.ne	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5ccc:      	ldursb	w11, [x8, #-0x7]
    5cd0:      	tbnz	w11, #0x1f, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5cd4:      	ldurb	w11, [x8, #-0x8]
    5cd8:      	cmp	w11, #0x9
    5cdc:      	b.eq	0x5dcc <_perry_fn_access_worker_ts__run$generic+0x2d38>
    5ce0:      	cmp	w11, #0x2
    5ce4:      	b.eq	0x5d84 <_perry_fn_access_worker_ts__run$generic+0x2cf0>
    5ce8:      	cmp	w11, #0x1
    5cec:      	b.ne	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5cf0:      	ldr	w10, [x8]
    5cf4:      	mov	x11, x8
    5cf8:      	ldurh	w13, [x8, #-0x6]
    5cfc:      	adrp	x12, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005cfc:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    5d00:      	ldr	x12, [x12]
		0000000000005d00:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    5d04:      	ldrb	w12, [x12]
    5d08:      	ldr	w8, [x8, #0x4]
    5d0c:      	cmp	x10, x8
    5d10:      	b.hi	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5d14:      	tbnz	w13, #0xa, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5d18:      	cbnz	w12, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5d1c:      	cmp	x9, x10
    5d20:      	b.hs	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5d24:      	add	x8, x11, x9, lsl #3
    5d28:      	ldr	d0, [x8, #0x8]
    5d2c:      	fmov	x8, d0
    5d30:      	cmp	x8, x19
    5d34:      	fcsel	d0, d11, d0, eq
    5d38:      	b	0x6028 <_perry_fn_access_worker_ts__run$generic+0x2f94>
    5d3c:      	add	x8, x8, #0x10
    5d40:      	cmp	w11, #0x3
    5d44:      	b.le	0x5d68 <_perry_fn_access_worker_ts__run$generic+0x2cd4>
    5d48:      	cmp	w11, #0x5
    5d4c:      	b.gt	0x5e18 <_perry_fn_access_worker_ts__run$generic+0x2d84>
    5d50:      	cmp	w11, #0x4
    5d54:      	b.eq	0x5ec4 <_perry_fn_access_worker_ts__run$generic+0x2e30>
    5d58:      	cmp	w11, #0x5
    5d5c:      	b.ne	0x5eb8 <_perry_fn_access_worker_ts__run$generic+0x2e24>
    5d60:      	ldr	s0, [x8, x9, lsl #2]
    5d64:      	b	0x5ebc <_perry_fn_access_worker_ts__run$generic+0x2e28>
    5d68:      	cbz	w11, 0x5eb0 <_perry_fn_access_worker_ts__run$generic+0x2e1c>
    5d6c:      	cmp	w11, #0x2
    5d70:      	b.eq	0x5ed8 <_perry_fn_access_worker_ts__run$generic+0x2e44>
    5d74:      	cmp	w11, #0x3
    5d78:      	b.ne	0x5eb8 <_perry_fn_access_worker_ts__run$generic+0x2e24>
    5d7c:      	ldr	h0, [x8, x9, lsl #1]
    5d80:      	b	0x5ebc <_perry_fn_access_worker_ts__run$generic+0x2e28>
    5d84:      	ldr	x10, [x8, #0x8]
    5d88:      	cbz	x10, 0x5e30 <_perry_fn_access_worker_ts__run$generic+0x2d9c>
    5d8c:      	ldr	x11, [x10, #0x60]
    5d90:      	cbz	x11, 0x5e30 <_perry_fn_access_worker_ts__run$generic+0x2d9c>
    5d94:      	ldurb	w8, [x11, #-0x8]
    5d98:      	cmp	w8, #0x1
    5d9c:      	b.ne	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5da0:      	ldursb	w8, [x11, #-0x7]
    5da4:      	tbnz	w8, #0x1f, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5da8:      	ldr	w8, [x11]
    5dac:      	cmp	x9, x8
    5db0:      	b.hs	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5db4:      	add	x8, x11, x9, lsl #3
    5db8:      	ldr	d0, [x8, #0x8]
    5dbc:      	fmov	x8, d0
    5dc0:      	cmp	x8, x19
    5dc4:      	b.eq	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5dc8:      	b	0x6028 <_perry_fn_access_worker_ts__run$generic+0x2f94>
    5dcc:      	ldr	w12, [x8, #0x4]
    5dd0:      	ldr	x11, [x8, #0x20]
    5dd4:      	ldurh	w13, [x8, #-0x6]
    5dd8:      	tst	w13, #0xc00
    5ddc:      	mov	w13, #0x5841            ; =22593
    5de0:      	movk	w13, #0x4c5a, lsl #16
    5de4:      	ccmp	w12, w13, #0x0, eq
    5de8:      	cset	w12, eq
    5dec:      	cbz	x11, 0x5e78 <_perry_fn_access_worker_ts__run$generic+0x2de4>
    5df0:      	tbz	w12, #0x0, 0x5e78 <_perry_fn_access_worker_ts__run$generic+0x2de4>
    5df4:      	ldurb	w10, [x11, #-0x8]
    5df8:      	cmp	w10, #0x1
    5dfc:      	b.ne	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5e00:      	ldursb	w10, [x11, #-0x7]
    5e04:      	tbnz	w10, #0x1f, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5e08:      	ldr	w10, [x11]
    5e0c:      	str	w10, [x8]
    5e10:      	mov	x8, x11
    5e14:      	b	0x5cf8 <_perry_fn_access_worker_ts__run$generic+0x2c64>
    5e18:      	cmp	w11, #0x6
    5e1c:      	b.eq	0x5ecc <_perry_fn_access_worker_ts__run$generic+0x2e38>
    5e20:      	cmp	w11, #0x7
    5e24:      	b.ne	0x5eb8 <_perry_fn_access_worker_ts__run$generic+0x2e24>
    5e28:      	ldr	d0, [x8, x9, lsl #3]
    5e2c:      	b	0x6028 <_perry_fn_access_worker_ts__run$generic+0x2f94>
    5e30:      	adrp	x12, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005e30:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__33
    5e34:      	add	x12, x12, #0x0
		0000000000005e34:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__33
    5e38:      	ldr	x11, [x12]
    5e3c:      	cmp	x11, #0x0
    5e40:      	csel	x12, x12, x11, eq
    5e44:      	ldr	x12, [x12]
    5e48:      	cbz	x12, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5e4c:      	tbnz	x12, #0x3f, 0x5ee4 <_perry_fn_access_worker_ts__run$generic+0x2e50>
    5e50:      	ldp	w14, w13, [x8]
    5e54:      	orr	x13, x13, x14, lsl #32
    5e58:      	cmp	x13, x12
    5e5c:      	b.ne	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5e60:      	ldp	x14, x12, [x11, #0x8]
    5e64:      	ldp	x13, x11, [x11, #0x18]
    5e68:      	cmp	x14, x11
    5e6c:      	b.lo	0x5f04 <_perry_fn_access_worker_ts__run$generic+0x2e70>
    5e70:      	cbz	x10, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5e74:      	b	0x5f54 <_perry_fn_access_worker_ts__run$generic+0x2ec0>
    5e78:      	cmp	x11, #0x0
    5e7c:      	ldr	w14, [x8]
    5e80:      	ldp	x11, x13, [x8, #0x28]
    5e84:      	ccmp	x9, x14, #0x2, eq
    5e88:      	ccmp	x11, #0x0, #0x4, lo
    5e8c:      	ccmp	x13, #0x0, #0x4, ne
    5e90:      	csel	w12, wzr, w12, eq
    5e94:      	tbz	w12, #0x0, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5e98:      	lsr	x12, x9, #6
    5e9c:      	ldr	x12, [x13, x12, lsl #3]
    5ea0:      	lsr	x12, x12, x9
    5ea4:      	tbz	w12, #0x0, 0x5f10 <_perry_fn_access_worker_ts__run$generic+0x2e7c>
    5ea8:      	ldr	d0, [x11, x9, lsl #3]
    5eac:      	b	0x6028 <_perry_fn_access_worker_ts__run$generic+0x2f94>
    5eb0:      	ldrsb	w8, [x8, x9]
    5eb4:      	b	0x5edc <_perry_fn_access_worker_ts__run$generic+0x2e48>
    5eb8:      	ldr	b0, [x8, x9]
    5ebc:      	ucvtf	d0, d0
    5ec0:      	b	0x6028 <_perry_fn_access_worker_ts__run$generic+0x2f94>
    5ec4:      	ldr	w8, [x8, x9, lsl #2]
    5ec8:      	b	0x5edc <_perry_fn_access_worker_ts__run$generic+0x2e48>
    5ecc:      	ldr	s0, [x8, x9, lsl #2]
    5ed0:      	fcvt	d0, s0
    5ed4:      	b	0x6028 <_perry_fn_access_worker_ts__run$generic+0x2f94>
    5ed8:      	ldrsh	w8, [x8, x9, lsl #1]
    5edc:      	scvtf	d0, w8
    5ee0:      	b	0x6028 <_perry_fn_access_worker_ts__run$generic+0x2f94>
    5ee4:      	cbz	x10, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5ee8:      	ldr	x13, [x10, #0x30]
    5eec:      	cmp	x13, x12
    5ef0:      	b.ne	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5ef4:      	ldp	x14, x12, [x11, #0x8]
    5ef8:      	ldp	x13, x11, [x11, #0x18]
    5efc:      	cmp	x14, x11
    5f00:      	b.hs	0x5f54 <_perry_fn_access_worker_ts__run$generic+0x2ec0>
    5f04:      	add	x14, x8, x14, lsl #3
    5f08:      	add	x14, x14, #0x10
    5f0c:      	b	0x5f78 <_perry_fn_access_worker_ts__run$generic+0x2ee4>
    5f10:      	ldr	x8, [x8, #0x50]
    5f14:      	mov	w12, #0x6903            ; =26883
    5f18:      	movk	w12, #0x64, lsl #16
    5f1c:      	cmp	x8, x12
    5f20:      	b.eq	0x5f28 <_perry_fn_access_worker_ts__run$generic+0x2e94>
    5f24:      	cbnz	x8, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5f28:      	mov	w12, #0x6903            ; =26883
    5f2c:      	movk	w12, #0x64, lsl #16
    5f30:      	cmp	x8, x12
    5f34:      	b.ne	0x5fe0 <_perry_fn_access_worker_ts__run$generic+0x2f4c>
    5f38:      	ldr	x8, [x11, x9, lsl #3]
    5f3c:      	cbz	x8, 0x5fe0 <_perry_fn_access_worker_ts__run$generic+0x2f4c>
    5f40:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    5f44:      	cmp	x8, x9
    5f48:      	csel	x8, xzr, x8, eq
    5f4c:      	fmov	d1, x8
    5f50:      	b	0x6210 <_perry_fn_access_worker_ts__run$generic+0x317c>
    5f54:      	ldr	x16, [x10, #0x20]
    5f58:      	cmp	x16, #0x0
    5f5c:      	csel	x15, x16, x10, ne
    5f60:      	cbz	x16, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5f64:      	ldr	w16, [x15]
    5f68:      	cmp	x14, x16
    5f6c:      	b.hs	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5f70:      	add	x14, x15, x14, lsl #3
    5f74:      	add	x14, x14, #0x8
    5f78:      	ldr	d0, [x14]
    5f7c:      	fcmp	d8, d0
    5f80:      	ccmp	x13, x9, #0x0, mi
    5f84:      	cset	w13, hi
    5f88:      	add	x9, x12, x9
    5f8c:      	cmp	x9, x11
    5f90:      	ccmp	w13, #0x0, #0x4, lo
    5f94:      	b.ne	0x5fd4 <_perry_fn_access_worker_ts__run$generic+0x2f40>
    5f98:      	cbz	x10, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5f9c:      	cmp	x9, x11
    5fa0:      	b.lo	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5fa4:      	eor	w8, w13, #0x1
    5fa8:      	tbnz	w8, #0x0, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5fac:      	ldr	x11, [x10, #0x20]
    5fb0:      	cmp	x11, #0x0
    5fb4:      	csel	x8, x11, x10, ne
    5fb8:      	cbz	x11, 0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5fbc:      	ldr	w10, [x8]
    5fc0:      	cmp	x9, x10
    5fc4:      	b.hs	0x6008 <_perry_fn_access_worker_ts__run$generic+0x2f74>
    5fc8:      	add	x8, x8, x9, lsl #3
    5fcc:      	ldr	d0, [x8, #0x8]
    5fd0:      	b	0x6028 <_perry_fn_access_worker_ts__run$generic+0x2f94>
    5fd4:      	add	x8, x8, x9, lsl #3
    5fd8:      	ldr	d0, [x8, #0x10]
    5fdc:      	b	0x6028 <_perry_fn_access_worker_ts__run$generic+0x2f94>
    5fe0:      	fmov	d0, x10
    5fe4:      	mov.16b	v1, v8
    5fe8:      	adrp	x0, 0x5000 <_perry_fn_access_worker_ts__run$generic+0x1f6c>
		0000000000005fe8:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    5fec:      	add	x0, x0, #0x0
		0000000000005fec:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    5ff0:      	mov	w1, #0x2                ; =2
    5ff4:      	bl	0x5ff4 <_perry_fn_access_worker_ts__run$generic+0x2f60>
		0000000000005ff4:  ARM64_RELOC_BRANCH26	_js_json_lazy_index_scalar
    5ff8:      	mov.16b	v1, v0
    5ffc:      	fmov	x8, d1
    6000:      	cmp	x8, x19
    6004:      	b.ne	0x6210 <_perry_fn_access_worker_ts__run$generic+0x317c>
    6008:      	fmov	d0, x28
    600c:      	str	x23, [sp, #0x28]
    6010:      	mov.16b	v1, v8
    6014:      	adrp	x0, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006014:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__33
    6018:      	add	x0, x0, #0x0
		0000000000006018:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__33
    601c:      	bl	0x601c <_perry_fn_access_worker_ts__run$generic+0x2f88>
		000000000000601c:  ARM64_RELOC_BRANCH26	_js_packed_arraylike_index_get
    6020:      	ldp	x28, x23, [sp, #0x20]
    6024:      	ldr	x26, [sp, #0x18]
    6028:      	fmov	x8, d0
    602c:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    6030:      	and	x9, x8, x9
    6034:      	cmp	x9, x25
    6038:      	b.ne	0x60a4 <_perry_fn_access_worker_ts__run$generic+0x3010>
    603c:      	and	x0, x8, #0xffffffffffff
    6040:      	lsr	x8, x0, #20
    6044:      	cbz	x8, 0x61e8 <_perry_fn_access_worker_ts__run$generic+0x3154>
    6048:      	ldurb	w9, [x0, #-0x8]
    604c:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		000000000000604c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__35
    6050:      	ldr	x8, [x8]
		0000000000006050:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__35
    6054:      	cbz	x8, 0x6114 <_perry_fn_access_worker_ts__run$generic+0x3080>
    6058:      	ldurh	w10, [x0, #-0x6]
    605c:      	and	w10, w10, #0x800
    6060:      	cmp	w9, #0x2
    6064:      	ccmp	w10, #0x0, #0x0, eq
    6068:      	b.ne	0x6114 <_perry_fn_access_worker_ts__run$generic+0x3080>
    606c:      	ldr	w10, [x0, #0x4]
    6070:      	orr	x9, x10, #0x4000000000000000
    6074:      	ldr	x11, [x8]
    6078:      	cmp	w10, #0x0
    607c:      	ccmp	x9, x11, #0x0, ne
    6080:      	b.eq	0x614c <_perry_fn_access_worker_ts__run$generic+0x30b8>
    6084:      	ldr	x11, [x8, #0x10]
    6088:      	cbz	x11, 0x6168 <_perry_fn_access_worker_ts__run$generic+0x30d4>
    608c:      	ldr	x12, [x0, #0x8]
    6090:      	cbz	x12, 0x6168 <_perry_fn_access_worker_ts__run$generic+0x30d4>
    6094:      	ldr	x12, [x12, #0x30]
    6098:      	cmp	x12, x11
    609c:      	b.eq	0x613c <_perry_fn_access_worker_ts__run$generic+0x30a8>
    60a0:      	b	0x6168 <_perry_fn_access_worker_ts__run$generic+0x30d4>
    60a4:      	lsr	x9, x8, #48
    60a8:      	mov	w10, #0x7ff9            ; =32761
    60ac:      	cmp	x9, x10
    60b0:      	b.eq	0x60f8 <_perry_fn_access_worker_ts__run$generic+0x3064>
    60b4:      	mov	w10, #0x7ffe            ; =32766
    60b8:      	cmp	w9, w10
    60bc:      	b.ne	0x60e8 <_perry_fn_access_worker_ts__run$generic+0x3054>
    60c0:      	adrp	x9, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000060c0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    60c4:      	ldr	x9, [x9]
		00000000000060c4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    60c8:      	str	x23, [sp, #0x28]
    60cc:      	and	x2, x9, #0xffffffffffff
    60d0:      	mov	x0, #0x22               ; =34
    60d4:      	movk	x0, #0xddae, lsl #32
    60d8:      	movk	x0, #0x5556, lsl #48
    60dc:      	mov	x1, x8
    60e0:      	bl	0x60e0 <_perry_fn_access_worker_ts__run$generic+0x304c>
		00000000000060e0:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    60e4:      	b	0x6204 <_perry_fn_access_worker_ts__run$generic+0x3170>
    60e8:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    60ec:      	add	x9, x8, x9
    60f0:      	cmp	x9, #0x2
    60f4:      	b.lo	0x62bc <_perry_fn_access_worker_ts__run$generic+0x3228>
    60f8:      	adrp	x9, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000060f8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    60fc:      	ldr	x9, [x9]
		00000000000060fc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    6100:      	str	x23, [sp, #0x28]
    6104:      	and	x1, x9, #0xffffffffffff
    6108:      	mov	x0, x8
    610c:      	bl	0x610c <_perry_fn_access_worker_ts__run$generic+0x3078>
		000000000000610c:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    6110:      	b	0x6204 <_perry_fn_access_worker_ts__run$generic+0x3170>
    6114:      	cmp	w9, #0x2
    6118:      	ccmp	x8, #0x0, #0x4, eq
    611c:      	b.eq	0x61e8 <_perry_fn_access_worker_ts__run$generic+0x3154>
    6120:      	ldr	x9, [x8, #0x10]
    6124:      	cbz	x9, 0x61e8 <_perry_fn_access_worker_ts__run$generic+0x3154>
    6128:      	ldr	x10, [x0, #0x8]
    612c:      	cbz	x10, 0x61e8 <_perry_fn_access_worker_ts__run$generic+0x3154>
    6130:      	ldr	x10, [x10, #0x30]
    6134:      	cmp	x10, x9
    6138:      	b.ne	0x61e8 <_perry_fn_access_worker_ts__run$generic+0x3154>
    613c:      	ldr	x8, [x8, #0x8]
    6140:      	add	x8, x0, x8, lsl #3
    6144:      	ldr	d1, [x8, #0x10]
    6148:      	b	0x6210 <_perry_fn_access_worker_ts__run$generic+0x317c>
    614c:      	ldr	x2, [x8, #0x8]
    6150:      	tbnz	w2, #0x1e, 0x629c <_perry_fn_access_worker_ts__run$generic+0x3208>
    6154:      	add	x11, x0, x2, lsl #3
    6158:      	ldr	d1, [x11, #0x10]
    615c:      	fmov	x11, d1
    6160:      	cmp	x11, x19
    6164:      	b.ne	0x6210 <_perry_fn_access_worker_ts__run$generic+0x317c>
    6168:      	ldr	x11, [x8, #0x18]
    616c:      	cmp	x11, #0x0
    6170:      	b.le	0x61e8 <_perry_fn_access_worker_ts__run$generic+0x3154>
    6174:      	ldr	x11, [x8, #0x20]
    6178:      	ldr	x12, [x8, #0x30]
    617c:      	ldr	x13, [x8, #0x40]
    6180:      	cmp	x13, x9
    6184:      	ldr	x14, [x8, #0x50]
    6188:      	ccmp	x14, x9, #0x4, ne
    618c:      	ccmp	x12, x9, #0x4, ne
    6190:      	ccmp	x11, x9, #0x4, ne
    6194:      	cset	w15, eq
    6198:      	cmp	w10, #0x0
    619c:      	ccmp	w15, #0x0, #0x4, ne
    61a0:      	b.eq	0x61e8 <_perry_fn_access_worker_ts__run$generic+0x3154>
    61a4:      	ldr	x10, [x8, #0x48]
    61a8:      	ldr	x15, [x8, #0x58]
    61ac:      	cmp	x14, x9
    61b0:      	csel	x14, x15, xzr, eq
    61b4:      	cmp	x13, x9
    61b8:      	csel	x10, x10, x14, eq
    61bc:      	ldr	x13, [x8, #0x28]
    61c0:      	ldr	x8, [x8, #0x38]
    61c4:      	cmp	x12, x9
    61c8:      	csel	x8, x8, x10, eq
    61cc:      	cmp	x11, x9
    61d0:      	csel	x8, x13, x8, eq
    61d4:      	add	x8, x0, x8, lsl #3
    61d8:      	ldr	d1, [x8, #0x10]
    61dc:      	fmov	x8, d1
    61e0:      	cmp	x8, x19
    61e4:      	b.ne	0x6210 <_perry_fn_access_worker_ts__run$generic+0x317c>
    61e8:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000061e8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    61ec:      	ldr	x8, [x8]
		00000000000061ec:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    61f0:      	str	x23, [sp, #0x28]
    61f4:      	and	x1, x8, #0xffffffffffff
    61f8:      	adrp	x2, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000061f8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__35
    61fc:      	add	x2, x2, #0x0
		00000000000061fc:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__35
    6200:      	bl	0x6200 <_perry_fn_access_worker_ts__run$generic+0x316c>
		0000000000006200:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    6204:      	mov.16b	v1, v0
    6208:      	ldp	x26, x28, [sp, #0x18]
    620c:      	ldr	x23, [sp, #0x28]
    6210:      	fmov	d0, x23
    6214:      	and	x9, x23, #0xffff000000000000
    6218:      	fmov	x8, d1
    621c:      	and	x10, x8, #0xffff000000000000
    6220:      	cmp	x8, x22
    6224:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    6228:      	ccmp	x10, x8, #0x2, hs
    622c:      	cset	w8, hi
    6230:      	mov	x10, #0x1               ; =1
    6234:      	movk	x10, #0x7fff, lsl #48
    6238:      	cmp	x9, x10
    623c:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    6240:      	ccmp	x23, x9, #0x0, lo
    6244:      	b.hi	0x6254 <_perry_fn_access_worker_ts__run$generic+0x31c0>
    6248:      	tbz	w8, #0x0, 0x6254 <_perry_fn_access_worker_ts__run$generic+0x31c0>
    624c:      	fadd	d0, d1, d0
    6250:      	b	0x625c <_perry_fn_access_worker_ts__run$generic+0x31c8>
    6254:      	bl	0x6254 <_perry_fn_access_worker_ts__run$generic+0x31c0>
		0000000000006254:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    6258:      	ldp	x26, x28, [sp, #0x18]
    625c:      	fmov	x23, d0
    6260:      	mov	x0, x23
    6264:      	ldr	w8, [x27]
    6268:      	cbz	w8, 0x6270 <_perry_fn_access_worker_ts__run$generic+0x31dc>
    626c:      	bl	0x626c <_perry_fn_access_worker_ts__run$generic+0x31d8>
		000000000000626c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6270:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006270:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_GC_POLL_ARMED
    6274:      	ldr	x8, [x8]
		0000000000006274:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_GC_POLL_ARMED
    6278:      	ldr	w8, [x8]
    627c:      	cbz	w8, 0x6290 <_perry_fn_access_worker_ts__run$generic+0x31fc>
    6280:      	str	x23, [sp, #0x28]
    6284:      	bl	0x6284 <_perry_fn_access_worker_ts__run$generic+0x31f0>
		0000000000006284:  ARM64_RELOC_BRANCH26	_js_gc_loop_safepoint
    6288:      	ldp	x28, x23, [sp, #0x20]
    628c:      	ldr	x26, [sp, #0x18]
    6290:      	add	w24, w24, #0x1
    6294:      	tbz	w21, #0x0, 0x5af4 <_perry_fn_access_worker_ts__run$generic+0x2a60>
    6298:      	b	0x5be8 <_perry_fn_access_worker_ts__run$generic+0x2b54>
    629c:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		000000000000629c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    62a0:      	ldr	x8, [x8]
		00000000000062a0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    62a4:      	str	x23, [sp, #0x28]
    62a8:      	and	x1, x8, #0xffffffffffff
    62ac:      	adrp	x3, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000062ac:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__35
    62b0:      	add	x3, x3, #0x0
		00000000000062b0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__35
    62b4:      	bl	0x62b4 <_perry_fn_access_worker_ts__run$generic+0x3220>
		00000000000062b4:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    62b8:      	b	0x6204 <_perry_fn_access_worker_ts__run$generic+0x3170>
    62bc:      	sub	x9, x19, #0xe
    62c0:      	cmp	x8, x9
    62c4:      	cset	w0, eq
    62c8:      	adrp	x1, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000062c8:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    62cc:      	add	x1, x1, #0x0
		00000000000062cc:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    62d0:      	mov	w2, #0x2                ; =2
    62d4:      	bl	0x62d4 <_perry_fn_access_worker_ts__run$generic+0x3240>
		00000000000062d4:  ARM64_RELOC_BRANCH26	_js_throw_type_error_property_access
    62d8:      	brk	#0x1
    62dc:      	sub	x9, x19, #0xe
    62e0:      	cmp	x8, x9
    62e4:      	cset	w0, eq
    62e8:      	adrp	x1, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000062e8:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.4.bytes
    62ec:      	add	x1, x1, #0x0
		00000000000062ec:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.4.bytes
    62f0:      	mov	w2, #0x4                ; =4
    62f4:      	b	0x62d4 <_perry_fn_access_worker_ts__run$generic+0x3240>
    62f8:      	sub	x9, x19, #0xe
    62fc:      	cmp	x8, x9
    6300:      	cset	w0, eq
    6304:      	adrp	x1, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006304:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.5.bytes
    6308:      	add	x1, x1, #0x0
		0000000000006308:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.5.bytes
    630c:      	mov	w2, #0x6                ; =6
    6310:      	b	0x62d4 <_perry_fn_access_worker_ts__run$generic+0x3240>

0000000000006314 <_perry_fn_access_worker_ts__run>:
    6314:      	fmov	x8, d1
    6318:      	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
    631c:      	cmp	x8, x9
    6320:      	b.lt	0x6338 <_perry_fn_access_worker_ts__run+0x24>
    6324:      	and	x8, x8, #0xffffffff00000000
    6328:      	mov	x9, #0x7ffe000000000000 ; =9222809086901354496
    632c:      	cmp	x8, x9
    6330:      	b.eq	0x6338 <_perry_fn_access_worker_ts__run+0x24>
    6334:      	b	0x6334 <_perry_fn_access_worker_ts__run+0x20>
		0000000000006334:  ARM64_RELOC_BRANCH26	_perry_fn_access_worker_ts__run$generic
    6338:      	b	0x6338 <_perry_fn_access_worker_ts__run+0x24>
		0000000000006338:  ARM64_RELOC_BRANCH26	_perry_fn_access_worker_ts__run$spec_b_b

000000000000633c <___perry_wrap_perry_fn_access_worker_ts__run>:
    633c:      	b	0x633c <___perry_wrap_perry_fn_access_worker_ts__run>
		000000000000633c:  ARM64_RELOC_BRANCH26	_perry_fn_access_worker_ts__run

0000000000006340 <_access_worker_ts__init>:
    6340:      	ret

0000000000006344 <_main>:
    6344:      	sub	sp, sp, #0xa0
    6348:      	stp	d11, d10, [sp, #0x40]
    634c:      	stp	d9, d8, [sp, #0x50]
    6350:      	stp	x24, x23, [sp, #0x60]
    6354:      	stp	x22, x21, [sp, #0x70]
    6358:      	stp	x20, x19, [sp, #0x80]
    635c:      	stp	x29, x30, [sp, #0x90]
    6360:      	add	x29, sp, #0x90
    6364:      	mov	w19, #0x2401            ; =9217
    6368:      	movk	w19, #0xf4, lsl #16
    636c:      	adrp	x0, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		000000000000636c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.0
    6370:      	add	x0, x0, #0x0
		0000000000006370:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.0
    6374:      	mov	w1, #0x5c               ; =92
    6378:      	bl	0x6378 <_main+0x34>
		0000000000006378:  ARM64_RELOC_BRANCH26	_js_set_process_entry_path
    637c:      	bl	0x637c <_main+0x38>
		000000000000637c:  ARM64_RELOC_BRANCH26	_js_gc_init
    6380:      	mov	w0, #0x1                ; =1
    6384:      	bl	0x6384 <_main+0x40>
		0000000000006384:  ARM64_RELOC_BRANCH26	_js_gc_write_barriers_emitted
    6388:      	bl	0x6388 <_main+0x44>
		0000000000006388:  ARM64_RELOC_BRANCH26	_perry_macos_bundle_chdir
    638c:      	bl	0x638c <_main+0x48>
		000000000000638c:  ARM64_RELOC_BRANCH26	___perry_init_strings_access_worker_ts
    6390:      	adrp	x0, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006390:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__1
    6394:      	add	x0, x0, #0x0
		0000000000006394:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
    6398:      	bl	0x6398 <_main+0x54>
		0000000000006398:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    639c:      	adrp	x0, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		000000000000639c:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    63a0:      	add	x0, x0, #0x0
		00000000000063a0:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    63a4:      	bl	0x63a4 <_main+0x60>
		00000000000063a4:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    63a8:      	bl	0x63a8 <_main+0x64>
		00000000000063a8:  ARM64_RELOC_BRANCH26	_js_mark_entry_module_esm
    63ac:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000063ac:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.6.handle
    63b0:      	ldr	d0, [x8]
		00000000000063b0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.6.handle
    63b4:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000063b4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.7.handle
    63b8:      	ldr	d1, [x8]
		00000000000063b8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.7.handle
    63bc:      	bl	0x63bc <_main+0x78>
		00000000000063bc:  ARM64_RELOC_BRANCH26	_js_native_module_named_esm_export_value
    63c0:      	bl	0x63c0 <_main+0x7c>
		00000000000063c0:  ARM64_RELOC_BRANCH26	_js_process_argv
    63c4:      	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
    63c8:      	orr	x8, x0, x8
    63cc:      	and	x9, x0, #0xffffffffffff
    63d0:      	adrp	x20, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000063d0:  ARM64_RELOC_PAGE21	lCPI5_0
    63d4:      	cmp	x9, #0x100, lsl #12     ; =0x100000
    63d8:      	b.lo	0x6478 <_main+0x134>
    63dc:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    63e0:      	cmp	x8, x10
    63e4:      	b.hs	0x6478 <_main+0x134>
    63e8:      	ldurb	w10, [x9, #-0x8]
    63ec:      	ldursb	w11, [x9, #-0x7]
    63f0:      	cmp	w11, #0x0
    63f4:      	ccmp	w10, #0x1, #0x0, mi
    63f8:      	ldr	x10, [x9]
    63fc:      	csel	x9, x10, x9, eq
    6400:      	sub	x10, x9, #0x100, lsl #12 ; =0x100000
    6404:      	mov	x11, #-0x100001         ; =-1048577
    6408:      	movk	x11, #0x0, lsl #48
    640c:      	cmp	x10, x11
    6410:      	b.hi	0x6478 <_main+0x134>
    6414:      	ldurb	w13, [x9, #-0x8]
    6418:      	ldursb	w12, [x9, #-0x7]
    641c:      	ldurh	w10, [x9, #-0x6]
    6420:      	adrp	x11, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006420:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    6424:      	ldr	x11, [x11]
		0000000000006424:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    6428:      	ldrb	w14, [x11]
    642c:      	ldp	w11, w15, [x9]
    6430:      	cmp	w11, w15
    6434:      	ccmp	w15, w19, #0x2, ls
    6438:      	ccmp	w11, w19, #0x2, lo
    643c:      	ccmp	w14, #0x0, #0x0, lo
    6440:      	ccmp	w13, #0x1, #0x0, eq
    6444:      	b.ne	0x6478 <_main+0x134>
    6448:      	tbnz	w12, #0x1f, 0x6478 <_main+0x134>
    644c:      	tbnz	w10, #0xa, 0x6478 <_main+0x134>
    6450:      	cmp	w11, #0x2
    6454:      	b.ls	0x68b0 <_main+0x56c>
    6458:      	ldr	d0, [x9, #0x18]
    645c:      	fmov	x8, d0
    6460:      	mov	x9, #0x10               ; =16
    6464:      	movk	x9, #0x7ffc, lsl #48
    6468:      	cmp	x8, x9
    646c:      	ldr	d1, [x20]
		000000000000646c:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    6470:      	fcsel	d0, d1, d0, eq
    6474:      	b	0x6490 <_main+0x14c>
    6478:      	fmov	d0, x8
    647c:      	mov	x0, #0x24               ; =36
    6480:      	movk	x0, #0xddae, lsl #32
    6484:      	movk	x0, #0x5556, lsl #48
    6488:      	fmov	d1, #2.00000000
    648c:      	bl	0x648c <_main+0x148>
		000000000000648c:  ARM64_RELOC_BRANCH26	_js_typed_feedback_array_index_get_fallback_boxed
    6490:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006490:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.8.handle
    6494:      	ldr	d1, [x8]
		0000000000006494:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.8.handle
    6498:      	bl	0x6498 <_main+0x154>
		0000000000006498:  ARM64_RELOC_BRANCH26	_js_fs_read_file_dispatch
    649c:      	fmov	x0, d0
    64a0:      	mov	x21, x0
    64a4:      	adrp	x22, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000064a4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    64a8:      	ldr	x22, [x22]
		00000000000064a8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT
    64ac:      	ldr	w8, [x22]
    64b0:      	cbz	w8, 0x64b8 <_main+0x174>
    64b4:      	bl	0x64b4 <_main+0x170>
		00000000000064b4:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    64b8:      	str	x21, [sp, #0x38]
    64bc:      	bl	0x64bc <_main+0x178>
		00000000000064bc:  ARM64_RELOC_BRANCH26	_js_process_argv
    64c0:      	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
    64c4:      	orr	x8, x0, x8
    64c8:      	and	x9, x0, #0xffffffffffff
    64cc:      	cmp	x9, #0x100, lsl #12     ; =0x100000
    64d0:      	b.lo	0x6570 <_main+0x22c>
    64d4:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    64d8:      	cmp	x8, x10
    64dc:      	b.hs	0x6570 <_main+0x22c>
    64e0:      	ldurb	w10, [x9, #-0x8]
    64e4:      	ldursb	w11, [x9, #-0x7]
    64e8:      	cmp	w11, #0x0
    64ec:      	ccmp	w10, #0x1, #0x0, mi
    64f0:      	ldr	x10, [x9]
    64f4:      	csel	x9, x10, x9, eq
    64f8:      	sub	x10, x9, #0x100, lsl #12 ; =0x100000
    64fc:      	mov	x11, #-0x100001         ; =-1048577
    6500:      	movk	x11, #0x0, lsl #48
    6504:      	cmp	x10, x11
    6508:      	b.hi	0x6570 <_main+0x22c>
    650c:      	ldurb	w13, [x9, #-0x8]
    6510:      	ldursb	w12, [x9, #-0x7]
    6514:      	ldurh	w10, [x9, #-0x6]
    6518:      	adrp	x11, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006518:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    651c:      	ldr	x11, [x11]
		000000000000651c:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    6520:      	ldrb	w14, [x11]
    6524:      	ldp	w11, w15, [x9]
    6528:      	cmp	w11, w15
    652c:      	ccmp	w15, w19, #0x2, ls
    6530:      	ccmp	w11, w19, #0x2, lo
    6534:      	ccmp	w14, #0x0, #0x0, lo
    6538:      	ccmp	w13, #0x1, #0x0, eq
    653c:      	b.ne	0x6570 <_main+0x22c>
    6540:      	tbnz	w12, #0x1f, 0x6570 <_main+0x22c>
    6544:      	tbnz	w10, #0xa, 0x6570 <_main+0x22c>
    6548:      	cmp	w11, #0x3
    654c:      	b.ls	0x68b8 <_main+0x574>
    6550:      	ldr	d0, [x9, #0x20]
    6554:      	fmov	x8, d0
    6558:      	mov	x9, #0x10               ; =16
    655c:      	movk	x9, #0x7ffc, lsl #48
    6560:      	cmp	x8, x9
    6564:      	ldr	d1, [x20]
		0000000000006564:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    6568:      	fcsel	d0, d1, d0, eq
    656c:      	b	0x6588 <_main+0x244>
    6570:      	fmov	d0, x8
    6574:      	mov	x0, #0x25               ; =37
    6578:      	movk	x0, #0xddae, lsl #32
    657c:      	movk	x0, #0x5556, lsl #48
    6580:      	fmov	d1, #3.00000000
    6584:      	bl	0x6584 <_main+0x240>
		0000000000006584:  ARM64_RELOC_BRANCH26	_js_typed_feedback_array_index_get_fallback_boxed
    6588:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006588:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__1
    658c:      	str	d0, [x8]
		000000000000658c:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__1
    6590:      	fmov	x0, d0
    6594:      	bl	0x6594 <_main+0x250>
		0000000000006594:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6598:      	bl	0x6598 <_main+0x254>
		0000000000006598:  ARM64_RELOC_BRANCH26	_js_process_argv
    659c:      	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
    65a0:      	orr	x8, x0, x8
    65a4:      	and	x9, x0, #0xffffffffffff
    65a8:      	cmp	x9, #0x100, lsl #12     ; =0x100000
    65ac:      	b.lo	0x6658 <_main+0x314>
    65b0:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    65b4:      	cmp	x8, x10
    65b8:      	b.hs	0x6658 <_main+0x314>
    65bc:      	ldurb	w10, [x9, #-0x8]
    65c0:      	ldursb	w11, [x9, #-0x7]
    65c4:      	cmp	w11, #0x0
    65c8:      	ccmp	w10, #0x1, #0x0, mi
    65cc:      	ldr	x10, [x9]
    65d0:      	csel	x9, x10, x9, eq
    65d4:      	sub	x10, x9, #0x100, lsl #12 ; =0x100000
    65d8:      	mov	x11, #-0x100001         ; =-1048577
    65dc:      	movk	x11, #0x0, lsl #48
    65e0:      	cmp	x10, x11
    65e4:      	b.hi	0x6658 <_main+0x314>
    65e8:      	ldurb	w13, [x9, #-0x8]
    65ec:      	ldursb	w12, [x9, #-0x7]
    65f0:      	ldurh	w10, [x9, #-0x6]
    65f4:      	adrp	x11, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000065f4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    65f8:      	ldr	x11, [x11]
		00000000000065f8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    65fc:      	ldrb	w14, [x11]
    6600:      	ldp	w11, w15, [x9]
    6604:      	cmp	w11, w15
    6608:      	b.hi	0x6658 <_main+0x314>
    660c:      	cmp	w15, w19
    6610:      	b.hs	0x6658 <_main+0x314>
    6614:      	cmp	w11, w19
    6618:      	b.hs	0x6658 <_main+0x314>
    661c:      	cbnz	w14, 0x6658 <_main+0x314>
    6620:      	cmp	w13, #0x1
    6624:      	b.ne	0x6658 <_main+0x314>
    6628:      	tbnz	w12, #0x1f, 0x6658 <_main+0x314>
    662c:      	tbnz	w10, #0xa, 0x6658 <_main+0x314>
    6630:      	cmp	w11, #0x4
    6634:      	b.ls	0x68a0 <_main+0x55c>
    6638:      	ldr	d0, [x9, #0x28]
    663c:      	fmov	x8, d0
    6640:      	mov	x9, #0x10               ; =16
    6644:      	movk	x9, #0x7ffc, lsl #48
    6648:      	cmp	x8, x9
    664c:      	ldr	d1, [x20]
		000000000000664c:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    6650:      	fcsel	d0, d1, d0, eq
    6654:      	b	0x6670 <_main+0x32c>
    6658:      	fmov	d0, x8
    665c:      	mov	x0, #0x26               ; =38
    6660:      	movk	x0, #0xddae, lsl #32
    6664:      	movk	x0, #0x5556, lsl #48
    6668:      	fmov	d1, #4.00000000
    666c:      	bl	0x666c <_main+0x328>
		000000000000666c:  ARM64_RELOC_BRANCH26	_js_typed_feedback_array_index_get_fallback_boxed
    6670:      	bl	0x6670 <_main+0x32c>
		0000000000006670:  ARM64_RELOC_BRANCH26	_js_number_coerce
    6674:      	mov.16b	v8, v0
    6678:      	bl	0x6678 <_main+0x334>
		0000000000006678:  ARM64_RELOC_BRANCH26	_js_process_argv
    667c:      	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
    6680:      	orr	x8, x0, x8
    6684:      	and	x9, x0, #0xffffffffffff
    6688:      	cmp	x9, #0x100, lsl #12     ; =0x100000
    668c:      	b.lo	0x6738 <_main+0x3f4>
    6690:      	mov	x10, #0x7ffe000000000000 ; =9222809086901354496
    6694:      	cmp	x8, x10
    6698:      	b.hs	0x6738 <_main+0x3f4>
    669c:      	ldurb	w10, [x9, #-0x8]
    66a0:      	ldursb	w11, [x9, #-0x7]
    66a4:      	cmp	w11, #0x0
    66a8:      	ccmp	w10, #0x1, #0x0, mi
    66ac:      	ldr	x10, [x9]
    66b0:      	csel	x9, x10, x9, eq
    66b4:      	sub	x10, x9, #0x100, lsl #12 ; =0x100000
    66b8:      	mov	x11, #-0x100001         ; =-1048577
    66bc:      	movk	x11, #0x0, lsl #48
    66c0:      	cmp	x10, x11
    66c4:      	b.hi	0x6738 <_main+0x3f4>
    66c8:      	ldurb	w13, [x9, #-0x8]
    66cc:      	ldursb	w12, [x9, #-0x7]
    66d0:      	ldurh	w10, [x9, #-0x6]
    66d4:      	adrp	x11, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000066d4:  ARM64_RELOC_GOT_LOAD_PAGE21	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    66d8:      	ldr	x11, [x11]
		00000000000066d8:  ARM64_RELOC_GOT_LOAD_PAGEOFF12	_PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED
    66dc:      	ldrb	w14, [x11]
    66e0:      	ldp	w11, w15, [x9]
    66e4:      	cmp	w11, w15
    66e8:      	b.hi	0x6738 <_main+0x3f4>
    66ec:      	cmp	w15, w19
    66f0:      	b.hs	0x6738 <_main+0x3f4>
    66f4:      	cmp	w11, w19
    66f8:      	b.hs	0x6738 <_main+0x3f4>
    66fc:      	cbnz	w14, 0x6738 <_main+0x3f4>
    6700:      	cmp	w13, #0x1
    6704:      	b.ne	0x6738 <_main+0x3f4>
    6708:      	tbnz	w12, #0x1f, 0x6738 <_main+0x3f4>
    670c:      	tbnz	w10, #0xa, 0x6738 <_main+0x3f4>
    6710:      	cmp	w11, #0x5
    6714:      	b.ls	0x68a8 <_main+0x564>
    6718:      	ldr	d0, [x9, #0x30]
    671c:      	fmov	x8, d0
    6720:      	mov	x9, #0x10               ; =16
    6724:      	movk	x9, #0x7ffc, lsl #48
    6728:      	cmp	x8, x9
    672c:      	ldr	d1, [x20]
		000000000000672c:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    6730:      	fcsel	d0, d1, d0, eq
    6734:      	b	0x6750 <_main+0x40c>
    6738:      	fmov	d0, x8
    673c:      	mov	x0, #0x27               ; =39
    6740:      	movk	x0, #0xddae, lsl #32
    6744:      	movk	x0, #0x5556, lsl #48
    6748:      	fmov	d1, #5.00000000
    674c:      	bl	0x674c <_main+0x408>
		000000000000674c:  ARM64_RELOC_BRANCH26	_js_typed_feedback_array_index_get_fallback_boxed
    6750:      	bl	0x6750 <_main+0x40c>
		0000000000006750:  ARM64_RELOC_BRANCH26	_js_number_coerce
    6754:      	mov.16b	v9, v0
    6758:      	ldr	x8, [sp, #0x38]
    675c:      	fmov	d0, x8
    6760:      	bl	0x6760 <_main+0x41c>
		0000000000006760:  ARM64_RELOC_BRANCH26	_js_json_text_to_string
    6764:      	bl	0x6764 <_main+0x420>
		0000000000006764:  ARM64_RELOC_BRANCH26	_js_json_parse
    6768:      	mov	x19, x0
    676c:      	ldr	w8, [x22]
    6770:      	cbz	w8, 0x6778 <_main+0x434>
    6774:      	bl	0x6774 <_main+0x430>
		0000000000006774:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6778:      	mov	x8, x19
    677c:      	lsr	x9, x8, #48
    6780:      	mov	x10, #-0x3000000000000  ; =-844424930131968
    6784:      	and	x10, x8, x10
    6788:      	mov	x11, #0x7ffd000000000000 ; =9222527611924643840
    678c:      	cmp	x10, x11
    6790:      	b.ne	0x67c0 <_main+0x47c>
    6794:      	and	x0, x8, #0xffffffffffff
    6798:      	mov	w8, #0x7fff             ; =32767
    679c:      	cmp	x9, x8
    67a0:      	b.ne	0x6800 <_main+0x4bc>
    67a4:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000067a4:  ARM64_RELOC_PAGE21	_perry_null_guard_zero_access_worker_ts
    67a8:      	add	x8, x8, #0x0
		00000000000067a8:  ARM64_RELOC_PAGEOFF12	_perry_null_guard_zero_access_worker_ts
    67ac:      	cmp	x0, #0x1, lsl #12       ; =0x1000
    67b0:      	csel	x8, x8, x0, lo
    67b4:      	ldr	s0, [x8]
    67b8:      	ucvtf	d0, d0
    67bc:      	b	0x69bc <_main+0x678>
    67c0:      	mov	w10, #0x7ff9            ; =32761
    67c4:      	cmp	x9, x10
    67c8:      	b.eq	0x6868 <_main+0x524>
    67cc:      	mov	w10, #0x7ffe            ; =32766
    67d0:      	cmp	w9, w10
    67d4:      	b.ne	0x6874 <_main+0x530>
    67d8:      	adrp	x9, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000067d8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    67dc:      	ldr	x9, [x9]
		00000000000067dc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    67e0:      	str	x19, [sp, #0x38]
    67e4:      	mov	x0, #0x28               ; =40
    67e8:      	movk	x0, #0xddae, lsl #32
    67ec:      	movk	x0, #0x5556, lsl #48
    67f0:      	and	x2, x9, #0xffffffffffff
    67f4:      	mov	x1, x8
    67f8:      	bl	0x67f8 <_main+0x4b4>
		00000000000067f8:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    67fc:      	b	0x69b8 <_main+0x674>
    6800:      	lsr	x8, x0, #20
    6804:      	cbz	x8, 0x699c <_main+0x658>
    6808:      	ldurb	w9, [x0, #-0x8]
    680c:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		000000000000680c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__41
    6810:      	ldr	x8, [x8]
		0000000000006810:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__41
    6814:      	cbz	x8, 0x68c0 <_main+0x57c>
    6818:      	cmp	w9, #0x2
    681c:      	b.ne	0x68c0 <_main+0x57c>
    6820:      	ldurh	w10, [x0, #-0x6]
    6824:      	tbnz	w10, #0xb, 0x68c0 <_main+0x57c>
    6828:      	ldr	w10, [x0, #0x4]
    682c:      	orr	x9, x10, #0x4000000000000000
    6830:      	cbz	w10, 0x68ec <_main+0x5a8>
    6834:      	ldr	x11, [x8]
    6838:      	cmp	x9, x11
    683c:      	b.ne	0x68ec <_main+0x5a8>
    6840:      	ldr	x2, [x8, #0x8]
    6844:      	tbnz	w2, #0x1e, 0x7cf0 <_main+0x19ac>
    6848:      	add	x11, x0, x2, lsl #3
    684c:      	ldr	d0, [x11, #0x10]
    6850:      	fmov	x11, d0
    6854:      	mov	x12, #0x10              ; =16
    6858:      	movk	x12, #0x7ffc, lsl #48
    685c:      	cmp	x11, x12
    6860:      	b.ne	0x69bc <_main+0x678>
    6864:      	b	0x6918 <_main+0x5d4>
    6868:      	ubfx	x8, x8, #40, #8
    686c:      	ucvtf	d0, x8
    6870:      	b	0x69bc <_main+0x678>
    6874:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    6878:      	add	x9, x8, x9
    687c:      	cmp	x9, #0x2
    6880:      	b.lo	0x7d54 <_main+0x1a10>
    6884:      	adrp	x9, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006884:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    6888:      	ldr	x9, [x9]
		0000000000006888:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    688c:      	str	x19, [sp, #0x38]
    6890:      	and	x1, x9, #0xffffffffffff
    6894:      	mov	x0, x8
    6898:      	bl	0x6898 <_main+0x554>
		0000000000006898:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    689c:      	b	0x69b8 <_main+0x674>
    68a0:      	ldr	d0, [x20]
		00000000000068a0:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    68a4:      	b	0x6670 <_main+0x32c>
    68a8:      	ldr	d0, [x20]
		00000000000068a8:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    68ac:      	b	0x6750 <_main+0x40c>
    68b0:      	ldr	d0, [x20]
		00000000000068b0:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    68b4:      	b	0x6490 <_main+0x14c>
    68b8:      	ldr	d0, [x20]
		00000000000068b8:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    68bc:      	b	0x6588 <_main+0x244>
    68c0:      	cmp	w9, #0x2
    68c4:      	b.ne	0x699c <_main+0x658>
    68c8:      	cbz	x8, 0x699c <_main+0x658>
    68cc:      	ldr	x9, [x8, #0x10]
    68d0:      	cbz	x9, 0x699c <_main+0x658>
    68d4:      	ldr	x10, [x0, #0x8]
    68d8:      	cbz	x10, 0x699c <_main+0x658>
    68dc:      	ldr	x10, [x10, #0x30]
    68e0:      	cmp	x10, x9
    68e4:      	b.eq	0x6908 <_main+0x5c4>
    68e8:      	b	0x699c <_main+0x658>
    68ec:      	ldr	x11, [x8, #0x10]
    68f0:      	cbz	x11, 0x6918 <_main+0x5d4>
    68f4:      	ldr	x12, [x0, #0x8]
    68f8:      	cbz	x12, 0x6918 <_main+0x5d4>
    68fc:      	ldr	x12, [x12, #0x30]
    6900:      	cmp	x12, x11
    6904:      	b.ne	0x6918 <_main+0x5d4>
    6908:      	ldr	x8, [x8, #0x8]
    690c:      	add	x8, x0, x8, lsl #3
    6910:      	ldr	d0, [x8, #0x10]
    6914:      	b	0x69bc <_main+0x678>
    6918:      	ldr	x11, [x8, #0x18]
    691c:      	cmp	x11, #0x0
    6920:      	b.le	0x699c <_main+0x658>
    6924:      	ldr	x11, [x8, #0x20]
    6928:      	ldr	x12, [x8, #0x30]
    692c:      	ldr	x13, [x8, #0x40]
    6930:      	cmp	x13, x9
    6934:      	ldr	x14, [x8, #0x50]
    6938:      	ccmp	x14, x9, #0x4, ne
    693c:      	ccmp	x12, x9, #0x4, ne
    6940:      	ccmp	x11, x9, #0x4, ne
    6944:      	cset	w15, eq
    6948:      	cbz	w10, 0x699c <_main+0x658>
    694c:      	cbz	w15, 0x699c <_main+0x658>
    6950:      	ldr	x10, [x8, #0x48]
    6954:      	ldr	x15, [x8, #0x58]
    6958:      	cmp	x14, x9
    695c:      	csel	x14, x15, xzr, eq
    6960:      	cmp	x13, x9
    6964:      	csel	x10, x10, x14, eq
    6968:      	ldr	x13, [x8, #0x28]
    696c:      	ldr	x8, [x8, #0x38]
    6970:      	cmp	x12, x9
    6974:      	csel	x8, x8, x10, eq
    6978:      	cmp	x11, x9
    697c:      	csel	x8, x13, x8, eq
    6980:      	add	x8, x0, x8, lsl #3
    6984:      	ldr	d0, [x8, #0x10]
    6988:      	fmov	x8, d0
    698c:      	mov	x9, #0x10               ; =16
    6990:      	movk	x9, #0x7ffc, lsl #48
    6994:      	cmp	x8, x9
    6998:      	b.ne	0x69bc <_main+0x678>
    699c:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		000000000000699c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    69a0:      	ldr	x8, [x8]
		00000000000069a0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    69a4:      	str	x19, [sp, #0x38]
    69a8:      	adrp	x2, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000069a8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__41
    69ac:      	add	x2, x2, #0x0
		00000000000069ac:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__41
    69b0:      	and	x1, x8, #0xffffffffffff
    69b4:      	bl	0x69b4 <_main+0x670>
		00000000000069b4:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    69b8:      	ldr	x19, [sp, #0x38]
    69bc:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		00000000000069bc:  ARM64_RELOC_PAGE21	_perry_global_access_worker_ts__5
    69c0:      	str	d0, [x8]
		00000000000069c0:  ARM64_RELOC_PAGEOFF12	_perry_global_access_worker_ts__5
    69c4:      	fmov	x0, d0
    69c8:      	bl	0x69c8 <_main+0x684>
		00000000000069c8:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    69cc:      	mov	x8, x19
    69d0:      	fmov	d0, x8
    69d4:      	str	x19, [sp, #0x38]
    69d8:      	mov.16b	v1, v9
    69dc:      	bl	0x69dc <_main+0x698>
		00000000000069dc:  ARM64_RELOC_BRANCH26	_perry_fn_access_worker_ts__run$spec_b_b
    69e0:      	fmov	x0, d0
    69e4:      	mov	x19, x0
    69e8:      	ldr	w8, [x22]
    69ec:      	cbz	w8, 0x69f4 <_main+0x6b0>
    69f0:      	bl	0x69f0 <_main+0x6ac>
		00000000000069f0:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    69f4:      	str	x19, [sp, #0x30]
    69f8:      	bl	0x69f8 <_main+0x6b4>
		00000000000069f8:  ARM64_RELOC_BRANCH26	_js_process_memory_usage
    69fc:      	fmov	x8, d0
    6a00:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    6a04:      	and	x9, x8, x9
    6a08:      	mov	x10, #0x7ffd000000000000 ; =9222527611924643840
    6a0c:      	cmp	x9, x10
    6a10:      	b.ne	0x6a80 <_main+0x73c>
    6a14:      	and	x0, x8, #0xffffffffffff
    6a18:      	lsr	x8, x0, #20
    6a1c:      	cbz	x8, 0x6bc4 <_main+0x880>
    6a20:      	ldurb	w9, [x0, #-0x8]
    6a24:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006a24:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__43
    6a28:      	ldr	x8, [x8]
		0000000000006a28:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__43
    6a2c:      	cbz	x8, 0x6ae8 <_main+0x7a4>
    6a30:      	cmp	w9, #0x2
    6a34:      	b.ne	0x6ae8 <_main+0x7a4>
    6a38:      	ldurh	w10, [x0, #-0x6]
    6a3c:      	tbnz	w10, #0xb, 0x6ae8 <_main+0x7a4>
    6a40:      	ldr	w10, [x0, #0x4]
    6a44:      	orr	x9, x10, #0x4000000000000000
    6a48:      	cbz	w10, 0x6b14 <_main+0x7d0>
    6a4c:      	ldr	x11, [x8]
    6a50:      	cmp	x9, x11
    6a54:      	b.ne	0x6b14 <_main+0x7d0>
    6a58:      	ldr	x2, [x8, #0x8]
    6a5c:      	tbnz	w2, #0x1e, 0x7a38 <_main+0x16f4>
    6a60:      	add	x11, x0, x2, lsl #3
    6a64:      	ldr	d0, [x11, #0x10]
    6a68:      	fmov	x11, d0
    6a6c:      	mov	x12, #0x10              ; =16
    6a70:      	movk	x12, #0x7ffc, lsl #48
    6a74:      	cmp	x11, x12
    6a78:      	b.ne	0x6bdc <_main+0x898>
    6a7c:      	b	0x6b40 <_main+0x7fc>
    6a80:      	lsr	x9, x8, #48
    6a84:      	mov	w10, #0x7ff9            ; =32761
    6a88:      	cmp	x9, x10
    6a8c:      	b.eq	0x6ad0 <_main+0x78c>
    6a90:      	mov	w10, #0x7ffe            ; =32766
    6a94:      	cmp	w9, w10
    6a98:      	b.ne	0x6ac0 <_main+0x77c>
    6a9c:      	adrp	x9, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006a9c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    6aa0:      	ldr	x9, [x9]
		0000000000006aa0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    6aa4:      	mov	x0, #0x2a               ; =42
    6aa8:      	movk	x0, #0xddae, lsl #32
    6aac:      	movk	x0, #0x5556, lsl #48
    6ab0:      	and	x2, x9, #0xffffffffffff
    6ab4:      	mov	x1, x8
    6ab8:      	bl	0x6ab8 <_main+0x774>
		0000000000006ab8:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    6abc:      	b	0x6bdc <_main+0x898>
    6ac0:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    6ac4:      	add	x9, x8, x9
    6ac8:      	cmp	x9, #0x2
    6acc:      	b.lo	0x7d30 <_main+0x19ec>
    6ad0:      	adrp	x9, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006ad0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    6ad4:      	ldr	x9, [x9]
		0000000000006ad4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    6ad8:      	and	x1, x9, #0xffffffffffff
    6adc:      	mov	x0, x8
    6ae0:      	bl	0x6ae0 <_main+0x79c>
		0000000000006ae0:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    6ae4:      	b	0x6bdc <_main+0x898>
    6ae8:      	cmp	w9, #0x2
    6aec:      	b.ne	0x6bc4 <_main+0x880>
    6af0:      	cbz	x8, 0x6bc4 <_main+0x880>
    6af4:      	ldr	x9, [x8, #0x10]
    6af8:      	cbz	x9, 0x6bc4 <_main+0x880>
    6afc:      	ldr	x10, [x0, #0x8]
    6b00:      	cbz	x10, 0x6bc4 <_main+0x880>
    6b04:      	ldr	x10, [x10, #0x30]
    6b08:      	cmp	x10, x9
    6b0c:      	b.eq	0x6b30 <_main+0x7ec>
    6b10:      	b	0x6bc4 <_main+0x880>
    6b14:      	ldr	x11, [x8, #0x10]
    6b18:      	cbz	x11, 0x6b40 <_main+0x7fc>
    6b1c:      	ldr	x12, [x0, #0x8]
    6b20:      	cbz	x12, 0x6b40 <_main+0x7fc>
    6b24:      	ldr	x12, [x12, #0x30]
    6b28:      	cmp	x12, x11
    6b2c:      	b.ne	0x6b40 <_main+0x7fc>
    6b30:      	ldr	x8, [x8, #0x8]
    6b34:      	add	x8, x0, x8, lsl #3
    6b38:      	ldr	d0, [x8, #0x10]
    6b3c:      	b	0x6bdc <_main+0x898>
    6b40:      	ldr	x11, [x8, #0x18]
    6b44:      	cmp	x11, #0x0
    6b48:      	b.le	0x6bc4 <_main+0x880>
    6b4c:      	ldr	x11, [x8, #0x20]
    6b50:      	ldr	x12, [x8, #0x30]
    6b54:      	ldr	x13, [x8, #0x40]
    6b58:      	cmp	x13, x9
    6b5c:      	ldr	x14, [x8, #0x50]
    6b60:      	ccmp	x14, x9, #0x4, ne
    6b64:      	ccmp	x12, x9, #0x4, ne
    6b68:      	ccmp	x11, x9, #0x4, ne
    6b6c:      	cset	w15, eq
    6b70:      	cbz	w10, 0x6bc4 <_main+0x880>
    6b74:      	cbz	w15, 0x6bc4 <_main+0x880>
    6b78:      	ldr	x10, [x8, #0x48]
    6b7c:      	ldr	x15, [x8, #0x58]
    6b80:      	cmp	x14, x9
    6b84:      	csel	x14, x15, xzr, eq
    6b88:      	cmp	x13, x9
    6b8c:      	csel	x10, x10, x14, eq
    6b90:      	ldr	x13, [x8, #0x28]
    6b94:      	ldr	x8, [x8, #0x38]
    6b98:      	cmp	x12, x9
    6b9c:      	csel	x8, x8, x10, eq
    6ba0:      	cmp	x11, x9
    6ba4:      	csel	x8, x13, x8, eq
    6ba8:      	add	x8, x0, x8, lsl #3
    6bac:      	ldr	d0, [x8, #0x10]
    6bb0:      	fmov	x8, d0
    6bb4:      	mov	x9, #0x10               ; =16
    6bb8:      	movk	x9, #0x7ffc, lsl #48
    6bbc:      	cmp	x8, x9
    6bc0:      	b.ne	0x6bdc <_main+0x898>
    6bc4:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006bc4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    6bc8:      	ldr	x8, [x8]
		0000000000006bc8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    6bcc:      	adrp	x2, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006bcc:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__43
    6bd0:      	add	x2, x2, #0x0
		0000000000006bd0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__43
    6bd4:      	and	x1, x8, #0xffffffffffff
    6bd8:      	bl	0x6bd8 <_main+0x894>
		0000000000006bd8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    6bdc:      	fmov	x0, d0
    6be0:      	mov	x19, x0
    6be4:      	ldr	w8, [x22]
    6be8:      	cbz	w8, 0x6bf0 <_main+0x8ac>
    6bec:      	bl	0x6bec <_main+0x8a8>
		0000000000006bec:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6bf0:      	str	x19, [sp, #0x28]
    6bf4:      	ldr	d9, [x20]
		0000000000006bf4:  ARM64_RELOC_PAGEOFF12	lCPI5_0
    6bf8:      	mov.16b	v0, v9
    6bfc:      	bl	0x6bfc <_main+0x8b8>
		0000000000006bfc:  ARM64_RELOC_BRANCH26	_js_process_cpu_usage
    6c00:      	fmov	x0, d0
    6c04:      	mov	x19, x0
    6c08:      	ldr	w8, [x22]
    6c0c:      	cbz	w8, 0x6c14 <_main+0x8d0>
    6c10:      	bl	0x6c10 <_main+0x8cc>
		0000000000006c10:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6c14:      	str	x19, [sp, #0x20]
    6c18:      	bl	0x6c18 <_main+0x8d4>
		0000000000006c18:  ARM64_RELOC_BRANCH26	_js_performance_now
    6c1c:      	mov.16b	v10, v0
    6c20:      	ldp	x0, x19, [sp, #0x30]
    6c24:      	mov	x20, x0
    6c28:      	ldr	w8, [x22]
    6c2c:      	cbz	w8, 0x6c34 <_main+0x8f0>
    6c30:      	bl	0x6c30 <_main+0x8ec>
		0000000000006c30:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6c34:      	fmov	d0, x19
    6c38:      	str	x20, [sp, #0x30]
    6c3c:      	mov.16b	v1, v8
    6c40:      	bl	0x6c40 <_main+0x8fc>
		0000000000006c40:  ARM64_RELOC_BRANCH26	_perry_fn_access_worker_ts__run$spec_b_b
    6c44:      	mov.16b	v1, v0
    6c48:      	ldr	x8, [sp, #0x30]
    6c4c:      	and	x9, x8, #0xffff000000000000
    6c50:      	mov	x10, #0x7ff9000000000000 ; =9221401712017801216
    6c54:      	cmp	x8, x10
    6c58:      	fmov	d0, x8
    6c5c:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    6c60:      	ccmp	x9, x8, #0x2, hs
    6c64:      	cset	w8, hi
    6c68:      	fmov	x9, d1
    6c6c:      	and	x10, x9, #0xffff000000000000
    6c70:      	mov	x11, #0x1               ; =1
    6c74:      	movk	x11, #0x7fff, lsl #48
    6c78:      	cmp	x10, x11
    6c7c:      	mov	x10, #0x7ff8ffffffffffff ; =9221401712017801215
    6c80:      	ccmp	x9, x10, #0x0, lo
    6c84:      	b.hi	0x6c94 <_main+0x950>
    6c88:      	cbz	w8, 0x6c94 <_main+0x950>
    6c8c:      	fadd	d0, d1, d0
    6c90:      	b	0x6c98 <_main+0x954>
    6c94:      	bl	0x6c94 <_main+0x950>
		0000000000006c94:  ARM64_RELOC_BRANCH26	_js_dynamic_string_or_number_add
    6c98:      	fmov	x0, d0
    6c9c:      	mov	x19, x0
    6ca0:      	ldr	w8, [x22]
    6ca4:      	cbz	w8, 0x6cac <_main+0x968>
    6ca8:      	bl	0x6ca8 <_main+0x964>
		0000000000006ca8:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6cac:      	str	x19, [sp, #0x30]
    6cb0:      	bl	0x6cb0 <_main+0x96c>
		0000000000006cb0:  ARM64_RELOC_BRANCH26	_js_performance_now
    6cb4:      	fmov	x8, d0
    6cb8:      	and	x9, x8, #0xffff000000000000
    6cbc:      	mov	x10, #0x7ff9000000000000 ; =9221401712017801216
    6cc0:      	cmp	x8, x10
    6cc4:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    6cc8:      	ccmp	x9, x8, #0x2, hs
    6ccc:      	cset	w8, hi
    6cd0:      	fmov	x9, d10
    6cd4:      	and	x10, x9, #0xffff000000000000
    6cd8:      	mov	x11, #0x1               ; =1
    6cdc:      	movk	x11, #0x7fff, lsl #48
    6ce0:      	cmp	x10, x11
    6ce4:      	mov	x10, #0x7ff8ffffffffffff ; =9221401712017801215
    6ce8:      	ccmp	x9, x10, #0x0, lo
    6cec:      	b.hi	0x6cfc <_main+0x9b8>
    6cf0:      	cbz	w8, 0x6cfc <_main+0x9b8>
    6cf4:      	fsub	d8, d0, d10
    6cf8:      	b	0x6d08 <_main+0x9c4>
    6cfc:      	mov.16b	v1, v10
    6d00:      	bl	0x6d00 <_main+0x9bc>
		0000000000006d00:  ARM64_RELOC_BRANCH26	_js_dynamic_sub
    6d04:      	mov.16b	v8, v0
    6d08:      	mov.16b	v0, v9
    6d0c:      	bl	0x6d0c <_main+0x9c8>
		0000000000006d0c:  ARM64_RELOC_BRANCH26	_js_process_cpu_usage
    6d10:      	fmov	x0, d0
    6d14:      	mov	x19, x0
    6d18:      	ldr	w8, [x22]
    6d1c:      	cbz	w8, 0x6d24 <_main+0x9e0>
    6d20:      	bl	0x6d20 <_main+0x9dc>
		0000000000006d20:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6d24:      	str	x19, [sp, #0x18]
    6d28:      	mov	w0, #0x8                ; =8
    6d2c:      	bl	0x6d2c <_main+0x9e8>
		0000000000006d2c:  ARM64_RELOC_BRANCH26	_js_array_alloc
    6d30:      	mov	x19, x0
    6d34:      	ldr	w8, [x22]
    6d38:      	cbz	w8, 0x6d40 <_main+0x9fc>
    6d3c:      	bl	0x6d3c <_main+0x9f8>
		0000000000006d3c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6d40:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006d40:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.11.handle
    6d44:      	ldr	d0, [x8]
		0000000000006d44:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.11.handle
    6d48:      	mov	x0, x19
    6d4c:      	bl	0x6d4c <_main+0xa08>
		0000000000006d4c:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    6d50:      	mov	x19, x0
    6d54:      	ldr	w8, [x22]
    6d58:      	cbz	w8, 0x6d60 <_main+0xa1c>
    6d5c:      	bl	0x6d5c <_main+0xa18>
		0000000000006d5c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6d60:      	mov	x0, x19
    6d64:      	mov.16b	v0, v8
    6d68:      	bl	0x6d68 <_main+0xa24>
		0000000000006d68:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    6d6c:      	mov	x19, x0
    6d70:      	ldp	x21, x20, [sp, #0x18]
    6d74:      	ldr	w8, [x22]
    6d78:      	cbz	w8, 0x6d80 <_main+0xa3c>
    6d7c:      	bl	0x6d7c <_main+0xa38>
		0000000000006d7c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6d80:      	mov	x8, #-0x3000000000000   ; =-844424930131968
    6d84:      	and	x8, x21, x8
    6d88:      	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
    6d8c:      	cmp	x8, x9
    6d90:      	b.ne	0x6e00 <_main+0xabc>
    6d94:      	and	x0, x21, #0xffffffffffff
    6d98:      	lsr	x8, x0, #20
    6d9c:      	cbz	x8, 0x6f4c <_main+0xc08>
    6da0:      	ldurb	w9, [x0, #-0x8]
    6da4:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006da4:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__45
    6da8:      	ldr	x8, [x8]
		0000000000006da8:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__45
    6dac:      	cbz	x8, 0x6e70 <_main+0xb2c>
    6db0:      	cmp	w9, #0x2
    6db4:      	b.ne	0x6e70 <_main+0xb2c>
    6db8:      	ldurh	w10, [x0, #-0x6]
    6dbc:      	tbnz	w10, #0xb, 0x6e70 <_main+0xb2c>
    6dc0:      	ldr	w10, [x0, #0x4]
    6dc4:      	orr	x9, x10, #0x4000000000000000
    6dc8:      	cbz	w10, 0x6e9c <_main+0xb58>
    6dcc:      	ldr	x11, [x8]
    6dd0:      	cmp	x9, x11
    6dd4:      	b.ne	0x6e9c <_main+0xb58>
    6dd8:      	ldr	x2, [x8, #0x8]
    6ddc:      	tbnz	w2, #0x1e, 0x7c50 <_main+0x190c>
    6de0:      	add	x11, x0, x2, lsl #3
    6de4:      	ldr	d0, [x11, #0x10]
    6de8:      	fmov	x11, d0
    6dec:      	mov	x12, #0x10              ; =16
    6df0:      	movk	x12, #0x7ffc, lsl #48
    6df4:      	cmp	x11, x12
    6df8:      	b.ne	0x6f70 <_main+0xc2c>
    6dfc:      	b	0x6ec8 <_main+0xb84>
    6e00:      	lsr	x8, x21, #48
    6e04:      	mov	w9, #0x7ff9             ; =32761
    6e08:      	cmp	x8, x9
    6e0c:      	b.eq	0x6e54 <_main+0xb10>
    6e10:      	mov	w9, #0x7ffe             ; =32766
    6e14:      	cmp	w8, w9
    6e18:      	b.ne	0x6e44 <_main+0xb00>
    6e1c:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006e1c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    6e20:      	ldr	x8, [x8]
		0000000000006e20:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    6e24:      	str	x19, [sp, #0x10]
    6e28:      	mov	x0, #0x2c               ; =44
    6e2c:      	movk	x0, #0xddae, lsl #32
    6e30:      	movk	x0, #0x5556, lsl #48
    6e34:      	and	x2, x8, #0xffffffffffff
    6e38:      	mov	x1, x21
    6e3c:      	bl	0x6e3c <_main+0xaf8>
		0000000000006e3c:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    6e40:      	b	0x6f68 <_main+0xc24>
    6e44:      	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
    6e48:      	add	x8, x21, x8
    6e4c:      	cmp	x8, #0x2
    6e50:      	b.lo	0x7d68 <_main+0x1a24>
    6e54:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006e54:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    6e58:      	ldr	x8, [x8]
		0000000000006e58:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    6e5c:      	str	x19, [sp, #0x10]
    6e60:      	and	x1, x8, #0xffffffffffff
    6e64:      	mov	x0, x21
    6e68:      	bl	0x6e68 <_main+0xb24>
		0000000000006e68:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    6e6c:      	b	0x6f68 <_main+0xc24>
    6e70:      	cmp	w9, #0x2
    6e74:      	b.ne	0x6f4c <_main+0xc08>
    6e78:      	cbz	x8, 0x6f4c <_main+0xc08>
    6e7c:      	ldr	x9, [x8, #0x10]
    6e80:      	cbz	x9, 0x6f4c <_main+0xc08>
    6e84:      	ldr	x10, [x0, #0x8]
    6e88:      	cbz	x10, 0x6f4c <_main+0xc08>
    6e8c:      	ldr	x10, [x10, #0x30]
    6e90:      	cmp	x10, x9
    6e94:      	b.eq	0x6eb8 <_main+0xb74>
    6e98:      	b	0x6f4c <_main+0xc08>
    6e9c:      	ldr	x11, [x8, #0x10]
    6ea0:      	cbz	x11, 0x6ec8 <_main+0xb84>
    6ea4:      	ldr	x12, [x0, #0x8]
    6ea8:      	cbz	x12, 0x6ec8 <_main+0xb84>
    6eac:      	ldr	x12, [x12, #0x30]
    6eb0:      	cmp	x12, x11
    6eb4:      	b.ne	0x6ec8 <_main+0xb84>
    6eb8:      	ldr	x8, [x8, #0x8]
    6ebc:      	add	x8, x0, x8, lsl #3
    6ec0:      	ldr	d0, [x8, #0x10]
    6ec4:      	b	0x6f70 <_main+0xc2c>
    6ec8:      	ldr	x11, [x8, #0x18]
    6ecc:      	cmp	x11, #0x0
    6ed0:      	b.le	0x6f4c <_main+0xc08>
    6ed4:      	ldr	x11, [x8, #0x20]
    6ed8:      	ldr	x12, [x8, #0x30]
    6edc:      	ldr	x13, [x8, #0x40]
    6ee0:      	cmp	x13, x9
    6ee4:      	ldr	x14, [x8, #0x50]
    6ee8:      	ccmp	x14, x9, #0x4, ne
    6eec:      	ccmp	x12, x9, #0x4, ne
    6ef0:      	ccmp	x11, x9, #0x4, ne
    6ef4:      	cset	w15, eq
    6ef8:      	cbz	w10, 0x6f4c <_main+0xc08>
    6efc:      	cbz	w15, 0x6f4c <_main+0xc08>
    6f00:      	ldr	x10, [x8, #0x48]
    6f04:      	ldr	x15, [x8, #0x58]
    6f08:      	cmp	x14, x9
    6f0c:      	csel	x14, x15, xzr, eq
    6f10:      	cmp	x13, x9
    6f14:      	csel	x10, x10, x14, eq
    6f18:      	ldr	x13, [x8, #0x28]
    6f1c:      	ldr	x8, [x8, #0x38]
    6f20:      	cmp	x12, x9
    6f24:      	csel	x8, x8, x10, eq
    6f28:      	cmp	x11, x9
    6f2c:      	csel	x8, x13, x8, eq
    6f30:      	add	x8, x0, x8, lsl #3
    6f34:      	ldr	d0, [x8, #0x10]
    6f38:      	fmov	x8, d0
    6f3c:      	mov	x9, #0x10               ; =16
    6f40:      	movk	x9, #0x7ffc, lsl #48
    6f44:      	cmp	x8, x9
    6f48:      	b.ne	0x6f70 <_main+0xc2c>
    6f4c:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006f4c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    6f50:      	ldr	x8, [x8]
		0000000000006f50:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    6f54:      	str	x19, [sp, #0x10]
    6f58:      	adrp	x2, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006f58:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__45
    6f5c:      	add	x2, x2, #0x0
		0000000000006f5c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__45
    6f60:      	and	x1, x8, #0xffffffffffff
    6f64:      	bl	0x6f64 <_main+0xc20>
		0000000000006f64:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    6f68:      	ldr	x20, [sp, #0x20]
    6f6c:      	ldr	x19, [sp, #0x10]
    6f70:      	fmov	x21, d0
    6f74:      	mov	x0, x21
    6f78:      	ldr	w8, [x22]
    6f7c:      	cbz	w8, 0x6f84 <_main+0xc40>
    6f80:      	bl	0x6f80 <_main+0xc3c>
		0000000000006f80:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    6f84:      	mov	x8, #-0x3000000000000   ; =-844424930131968
    6f88:      	and	x8, x20, x8
    6f8c:      	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
    6f90:      	cmp	x8, x9
    6f94:      	b.ne	0x7004 <_main+0xcc0>
    6f98:      	and	x0, x20, #0xffffffffffff
    6f9c:      	lsr	x8, x0, #20
    6fa0:      	cbz	x8, 0x7150 <_main+0xe0c>
    6fa4:      	ldurb	w9, [x0, #-0x8]
    6fa8:      	adrp	x8, 0x6000 <_perry_fn_access_worker_ts__run$generic+0x2f6c>
		0000000000006fa8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__47
    6fac:      	ldr	x8, [x8]
		0000000000006fac:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__47
    6fb0:      	cbz	x8, 0x7074 <_main+0xd30>
    6fb4:      	cmp	w9, #0x2
    6fb8:      	b.ne	0x7074 <_main+0xd30>
    6fbc:      	ldurh	w10, [x0, #-0x6]
    6fc0:      	tbnz	w10, #0xb, 0x7074 <_main+0xd30>
    6fc4:      	ldr	w10, [x0, #0x4]
    6fc8:      	orr	x9, x10, #0x4000000000000000
    6fcc:      	cbz	w10, 0x70a0 <_main+0xd5c>
    6fd0:      	ldr	x11, [x8]
    6fd4:      	cmp	x9, x11
    6fd8:      	b.ne	0x70a0 <_main+0xd5c>
    6fdc:      	ldr	x2, [x8, #0x8]
    6fe0:      	tbnz	w2, #0x1e, 0x7c70 <_main+0x192c>
    6fe4:      	add	x11, x0, x2, lsl #3
    6fe8:      	ldr	d1, [x11, #0x10]
    6fec:      	fmov	x11, d1
    6ff0:      	mov	x12, #0x10              ; =16
    6ff4:      	movk	x12, #0x7ffc, lsl #48
    6ff8:      	cmp	x11, x12
    6ffc:      	b.ne	0x7174 <_main+0xe30>
    7000:      	b	0x70cc <_main+0xd88>
    7004:      	lsr	x8, x20, #48
    7008:      	mov	w9, #0x7ff9             ; =32761
    700c:      	cmp	x8, x9
    7010:      	b.eq	0x7058 <_main+0xd14>
    7014:      	mov	w9, #0x7ffe             ; =32766
    7018:      	cmp	w8, w9
    701c:      	b.ne	0x7048 <_main+0xd04>
    7020:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007020:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    7024:      	ldr	x8, [x8]
		0000000000007024:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    7028:      	stp	x19, x21, [sp, #0x8]
    702c:      	mov	x0, #0x2e               ; =46
    7030:      	movk	x0, #0xddae, lsl #32
    7034:      	movk	x0, #0x5556, lsl #48
    7038:      	and	x2, x8, #0xffffffffffff
    703c:      	mov	x1, x20
    7040:      	bl	0x7040 <_main+0xcfc>
		0000000000007040:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    7044:      	b	0x716c <_main+0xe28>
    7048:      	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
    704c:      	add	x8, x20, x8
    7050:      	cmp	x8, #0x2
    7054:      	b.lo	0x7d7c <_main+0x1a38>
    7058:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007058:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    705c:      	ldr	x8, [x8]
		000000000000705c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    7060:      	stp	x19, x21, [sp, #0x8]
    7064:      	and	x1, x8, #0xffffffffffff
    7068:      	mov	x0, x20
    706c:      	bl	0x706c <_main+0xd28>
		000000000000706c:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    7070:      	b	0x716c <_main+0xe28>
    7074:      	cmp	w9, #0x2
    7078:      	b.ne	0x7150 <_main+0xe0c>
    707c:      	cbz	x8, 0x7150 <_main+0xe0c>
    7080:      	ldr	x9, [x8, #0x10]
    7084:      	cbz	x9, 0x7150 <_main+0xe0c>
    7088:      	ldr	x10, [x0, #0x8]
    708c:      	cbz	x10, 0x7150 <_main+0xe0c>
    7090:      	ldr	x10, [x10, #0x30]
    7094:      	cmp	x10, x9
    7098:      	b.eq	0x70bc <_main+0xd78>
    709c:      	b	0x7150 <_main+0xe0c>
    70a0:      	ldr	x11, [x8, #0x10]
    70a4:      	cbz	x11, 0x70cc <_main+0xd88>
    70a8:      	ldr	x12, [x0, #0x8]
    70ac:      	cbz	x12, 0x70cc <_main+0xd88>
    70b0:      	ldr	x12, [x12, #0x30]
    70b4:      	cmp	x12, x11
    70b8:      	b.ne	0x70cc <_main+0xd88>
    70bc:      	ldr	x8, [x8, #0x8]
    70c0:      	add	x8, x0, x8, lsl #3
    70c4:      	ldr	d1, [x8, #0x10]
    70c8:      	b	0x7174 <_main+0xe30>
    70cc:      	ldr	x11, [x8, #0x18]
    70d0:      	cmp	x11, #0x0
    70d4:      	b.le	0x7150 <_main+0xe0c>
    70d8:      	ldr	x11, [x8, #0x20]
    70dc:      	ldr	x12, [x8, #0x30]
    70e0:      	ldr	x13, [x8, #0x40]
    70e4:      	cmp	x13, x9
    70e8:      	ldr	x14, [x8, #0x50]
    70ec:      	ccmp	x14, x9, #0x4, ne
    70f0:      	ccmp	x12, x9, #0x4, ne
    70f4:      	ccmp	x11, x9, #0x4, ne
    70f8:      	cset	w15, eq
    70fc:      	cbz	w10, 0x7150 <_main+0xe0c>
    7100:      	cbz	w15, 0x7150 <_main+0xe0c>
    7104:      	ldr	x10, [x8, #0x48]
    7108:      	ldr	x15, [x8, #0x58]
    710c:      	cmp	x14, x9
    7110:      	csel	x14, x15, xzr, eq
    7114:      	cmp	x13, x9
    7118:      	csel	x10, x10, x14, eq
    711c:      	ldr	x13, [x8, #0x28]
    7120:      	ldr	x8, [x8, #0x38]
    7124:      	cmp	x12, x9
    7128:      	csel	x8, x8, x10, eq
    712c:      	cmp	x11, x9
    7130:      	csel	x8, x13, x8, eq
    7134:      	add	x8, x0, x8, lsl #3
    7138:      	ldr	d1, [x8, #0x10]
    713c:      	fmov	x8, d1
    7140:      	mov	x9, #0x10               ; =16
    7144:      	movk	x9, #0x7ffc, lsl #48
    7148:      	cmp	x8, x9
    714c:      	b.ne	0x7174 <_main+0xe30>
    7150:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007150:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    7154:      	ldr	x8, [x8]
		0000000000007154:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    7158:      	stp	x19, x21, [sp, #0x8]
    715c:      	adrp	x2, 0x7000 <_main+0xcbc>
		000000000000715c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__47
    7160:      	add	x2, x2, #0x0
		0000000000007160:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__47
    7164:      	and	x1, x8, #0xffffffffffff
    7168:      	bl	0x7168 <_main+0xe24>
		0000000000007168:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    716c:      	mov.16b	v1, v0
    7170:      	ldp	x19, x21, [sp, #0x8]
    7174:      	fmov	d0, x21
    7178:      	and	x9, x21, #0xffff000000000000
    717c:      	fmov	x8, d1
    7180:      	and	x10, x8, #0xffff000000000000
    7184:      	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
    7188:      	cmp	x8, x11
    718c:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    7190:      	ccmp	x10, x8, #0x2, hs
    7194:      	cset	w8, hi
    7198:      	mov	x10, #0x1               ; =1
    719c:      	movk	x10, #0x7fff, lsl #48
    71a0:      	cmp	x9, x10
    71a4:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    71a8:      	ccmp	x21, x9, #0x0, lo
    71ac:      	b.hi	0x71bc <_main+0xe78>
    71b0:      	tbz	w8, #0x0, 0x71bc <_main+0xe78>
    71b4:      	fsub	d0, d0, d1
    71b8:      	b	0x71c8 <_main+0xe84>
    71bc:      	str	x19, [sp, #0x10]
    71c0:      	bl	0x71c0 <_main+0xe7c>
		00000000000071c0:  ARM64_RELOC_BRANCH26	_js_dynamic_sub
    71c4:      	ldr	x19, [sp, #0x10]
    71c8:      	mov	x0, x19
    71cc:      	bl	0x71cc <_main+0xe88>
		00000000000071cc:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    71d0:      	mov	x19, x0
    71d4:      	ldp	x21, x20, [sp, #0x18]
    71d8:      	ldr	w8, [x22]
    71dc:      	cbz	w8, 0x71e4 <_main+0xea0>
    71e0:      	bl	0x71e0 <_main+0xe9c>
		00000000000071e0:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    71e4:      	mov	x8, #-0x3000000000000   ; =-844424930131968
    71e8:      	and	x8, x21, x8
    71ec:      	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
    71f0:      	cmp	x8, x9
    71f4:      	b.ne	0x7264 <_main+0xf20>
    71f8:      	and	x0, x21, #0xffffffffffff
    71fc:      	lsr	x8, x0, #20
    7200:      	cbz	x8, 0x73b0 <_main+0x106c>
    7204:      	ldurb	w9, [x0, #-0x8]
    7208:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007208:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__49
    720c:      	ldr	x8, [x8]
		000000000000720c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__49
    7210:      	cbz	x8, 0x72d4 <_main+0xf90>
    7214:      	cmp	w9, #0x2
    7218:      	b.ne	0x72d4 <_main+0xf90>
    721c:      	ldurh	w10, [x0, #-0x6]
    7220:      	tbnz	w10, #0xb, 0x72d4 <_main+0xf90>
    7224:      	ldr	w10, [x0, #0x4]
    7228:      	orr	x9, x10, #0x4000000000000000
    722c:      	cbz	w10, 0x7300 <_main+0xfbc>
    7230:      	ldr	x11, [x8]
    7234:      	cmp	x9, x11
    7238:      	b.ne	0x7300 <_main+0xfbc>
    723c:      	ldr	x2, [x8, #0x8]
    7240:      	tbnz	w2, #0x1e, 0x7c90 <_main+0x194c>
    7244:      	add	x11, x0, x2, lsl #3
    7248:      	ldr	d0, [x11, #0x10]
    724c:      	fmov	x11, d0
    7250:      	mov	x12, #0x10              ; =16
    7254:      	movk	x12, #0x7ffc, lsl #48
    7258:      	cmp	x11, x12
    725c:      	b.ne	0x73d0 <_main+0x108c>
    7260:      	b	0x732c <_main+0xfe8>
    7264:      	lsr	x8, x21, #48
    7268:      	mov	w9, #0x7ff9             ; =32761
    726c:      	cmp	x8, x9
    7270:      	b.eq	0x72b8 <_main+0xf74>
    7274:      	mov	w9, #0x7ffe             ; =32766
    7278:      	cmp	w8, w9
    727c:      	b.ne	0x72a8 <_main+0xf64>
    7280:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007280:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    7284:      	ldr	x8, [x8]
		0000000000007284:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    7288:      	str	x19, [sp, #0x18]
    728c:      	mov	x0, #0x30               ; =48
    7290:      	movk	x0, #0xddae, lsl #32
    7294:      	movk	x0, #0x5556, lsl #48
    7298:      	and	x2, x8, #0xffffffffffff
    729c:      	mov	x1, x21
    72a0:      	bl	0x72a0 <_main+0xf5c>
		00000000000072a0:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    72a4:      	b	0x73cc <_main+0x1088>
    72a8:      	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
    72ac:      	add	x8, x21, x8
    72b0:      	cmp	x8, #0x2
    72b4:      	b.lo	0x7da0 <_main+0x1a5c>
    72b8:      	adrp	x8, 0x7000 <_main+0xcbc>
		00000000000072b8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    72bc:      	ldr	x8, [x8]
		00000000000072bc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    72c0:      	str	x19, [sp, #0x18]
    72c4:      	and	x1, x8, #0xffffffffffff
    72c8:      	mov	x0, x21
    72cc:      	bl	0x72cc <_main+0xf88>
		00000000000072cc:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    72d0:      	b	0x73cc <_main+0x1088>
    72d4:      	cmp	w9, #0x2
    72d8:      	b.ne	0x73b0 <_main+0x106c>
    72dc:      	cbz	x8, 0x73b0 <_main+0x106c>
    72e0:      	ldr	x9, [x8, #0x10]
    72e4:      	cbz	x9, 0x73b0 <_main+0x106c>
    72e8:      	ldr	x10, [x0, #0x8]
    72ec:      	cbz	x10, 0x73b0 <_main+0x106c>
    72f0:      	ldr	x10, [x10, #0x30]
    72f4:      	cmp	x10, x9
    72f8:      	b.eq	0x731c <_main+0xfd8>
    72fc:      	b	0x73b0 <_main+0x106c>
    7300:      	ldr	x11, [x8, #0x10]
    7304:      	cbz	x11, 0x732c <_main+0xfe8>
    7308:      	ldr	x12, [x0, #0x8]
    730c:      	cbz	x12, 0x732c <_main+0xfe8>
    7310:      	ldr	x12, [x12, #0x30]
    7314:      	cmp	x12, x11
    7318:      	b.ne	0x732c <_main+0xfe8>
    731c:      	ldr	x8, [x8, #0x8]
    7320:      	add	x8, x0, x8, lsl #3
    7324:      	ldr	d0, [x8, #0x10]
    7328:      	b	0x73d0 <_main+0x108c>
    732c:      	ldr	x11, [x8, #0x18]
    7330:      	cmp	x11, #0x0
    7334:      	b.le	0x73b0 <_main+0x106c>
    7338:      	ldr	x11, [x8, #0x20]
    733c:      	ldr	x12, [x8, #0x30]
    7340:      	ldr	x13, [x8, #0x40]
    7344:      	cmp	x13, x9
    7348:      	ldr	x14, [x8, #0x50]
    734c:      	ccmp	x14, x9, #0x4, ne
    7350:      	ccmp	x12, x9, #0x4, ne
    7354:      	ccmp	x11, x9, #0x4, ne
    7358:      	cset	w15, eq
    735c:      	cbz	w10, 0x73b0 <_main+0x106c>
    7360:      	cbz	w15, 0x73b0 <_main+0x106c>
    7364:      	ldr	x10, [x8, #0x48]
    7368:      	ldr	x15, [x8, #0x58]
    736c:      	cmp	x14, x9
    7370:      	csel	x14, x15, xzr, eq
    7374:      	cmp	x13, x9
    7378:      	csel	x10, x10, x14, eq
    737c:      	ldr	x13, [x8, #0x28]
    7380:      	ldr	x8, [x8, #0x38]
    7384:      	cmp	x12, x9
    7388:      	csel	x8, x8, x10, eq
    738c:      	cmp	x11, x9
    7390:      	csel	x8, x13, x8, eq
    7394:      	add	x8, x0, x8, lsl #3
    7398:      	ldr	d0, [x8, #0x10]
    739c:      	fmov	x8, d0
    73a0:      	mov	x9, #0x10               ; =16
    73a4:      	movk	x9, #0x7ffc, lsl #48
    73a8:      	cmp	x8, x9
    73ac:      	b.ne	0x73d0 <_main+0x108c>
    73b0:      	adrp	x8, 0x7000 <_main+0xcbc>
		00000000000073b0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    73b4:      	ldr	x8, [x8]
		00000000000073b4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    73b8:      	str	x19, [sp, #0x18]
    73bc:      	adrp	x2, 0x7000 <_main+0xcbc>
		00000000000073bc:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__49
    73c0:      	add	x2, x2, #0x0
		00000000000073c0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__49
    73c4:      	and	x1, x8, #0xffffffffffff
    73c8:      	bl	0x73c8 <_main+0x1084>
		00000000000073c8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    73cc:      	ldp	x19, x20, [sp, #0x18]
    73d0:      	fmov	x21, d0
    73d4:      	mov	x0, x21
    73d8:      	ldr	w8, [x22]
    73dc:      	cbz	w8, 0x73e4 <_main+0x10a0>
    73e0:      	bl	0x73e0 <_main+0x109c>
		00000000000073e0:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    73e4:      	mov	x8, #-0x3000000000000   ; =-844424930131968
    73e8:      	and	x8, x20, x8
    73ec:      	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
    73f0:      	cmp	x8, x9
    73f4:      	b.ne	0x7464 <_main+0x1120>
    73f8:      	and	x0, x20, #0xffffffffffff
    73fc:      	lsr	x8, x0, #20
    7400:      	cbz	x8, 0x75b0 <_main+0x126c>
    7404:      	ldurb	w9, [x0, #-0x8]
    7408:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007408:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__51
    740c:      	ldr	x8, [x8]
		000000000000740c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__51
    7410:      	cbz	x8, 0x74d4 <_main+0x1190>
    7414:      	cmp	w9, #0x2
    7418:      	b.ne	0x74d4 <_main+0x1190>
    741c:      	ldurh	w10, [x0, #-0x6]
    7420:      	tbnz	w10, #0xb, 0x74d4 <_main+0x1190>
    7424:      	ldr	w10, [x0, #0x4]
    7428:      	orr	x9, x10, #0x4000000000000000
    742c:      	cbz	w10, 0x7500 <_main+0x11bc>
    7430:      	ldr	x11, [x8]
    7434:      	cmp	x9, x11
    7438:      	b.ne	0x7500 <_main+0x11bc>
    743c:      	ldr	x2, [x8, #0x8]
    7440:      	tbnz	w2, #0x1e, 0x7cb0 <_main+0x196c>
    7444:      	add	x11, x0, x2, lsl #3
    7448:      	ldr	d1, [x11, #0x10]
    744c:      	fmov	x11, d1
    7450:      	mov	x12, #0x10              ; =16
    7454:      	movk	x12, #0x7ffc, lsl #48
    7458:      	cmp	x11, x12
    745c:      	b.ne	0x75d4 <_main+0x1290>
    7460:      	b	0x752c <_main+0x11e8>
    7464:      	lsr	x8, x20, #48
    7468:      	mov	w9, #0x7ff9             ; =32761
    746c:      	cmp	x8, x9
    7470:      	b.eq	0x74b8 <_main+0x1174>
    7474:      	mov	w9, #0x7ffe             ; =32766
    7478:      	cmp	w8, w9
    747c:      	b.ne	0x74a8 <_main+0x1164>
    7480:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007480:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    7484:      	ldr	x8, [x8]
		0000000000007484:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    7488:      	stp	x19, x21, [sp, #0x18]
    748c:      	mov	x0, #0x32               ; =50
    7490:      	movk	x0, #0xddae, lsl #32
    7494:      	movk	x0, #0x5556, lsl #48
    7498:      	and	x2, x8, #0xffffffffffff
    749c:      	mov	x1, x20
    74a0:      	bl	0x74a0 <_main+0x115c>
		00000000000074a0:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    74a4:      	b	0x75cc <_main+0x1288>
    74a8:      	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
    74ac:      	add	x8, x20, x8
    74b0:      	cmp	x8, #0x2
    74b4:      	b.lo	0x7db4 <_main+0x1a70>
    74b8:      	adrp	x8, 0x7000 <_main+0xcbc>
		00000000000074b8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    74bc:      	ldr	x8, [x8]
		00000000000074bc:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    74c0:      	stp	x19, x21, [sp, #0x18]
    74c4:      	and	x1, x8, #0xffffffffffff
    74c8:      	mov	x0, x20
    74cc:      	bl	0x74cc <_main+0x1188>
		00000000000074cc:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    74d0:      	b	0x75cc <_main+0x1288>
    74d4:      	cmp	w9, #0x2
    74d8:      	b.ne	0x75b0 <_main+0x126c>
    74dc:      	cbz	x8, 0x75b0 <_main+0x126c>
    74e0:      	ldr	x9, [x8, #0x10]
    74e4:      	cbz	x9, 0x75b0 <_main+0x126c>
    74e8:      	ldr	x10, [x0, #0x8]
    74ec:      	cbz	x10, 0x75b0 <_main+0x126c>
    74f0:      	ldr	x10, [x10, #0x30]
    74f4:      	cmp	x10, x9
    74f8:      	b.eq	0x751c <_main+0x11d8>
    74fc:      	b	0x75b0 <_main+0x126c>
    7500:      	ldr	x11, [x8, #0x10]
    7504:      	cbz	x11, 0x752c <_main+0x11e8>
    7508:      	ldr	x12, [x0, #0x8]
    750c:      	cbz	x12, 0x752c <_main+0x11e8>
    7510:      	ldr	x12, [x12, #0x30]
    7514:      	cmp	x12, x11
    7518:      	b.ne	0x752c <_main+0x11e8>
    751c:      	ldr	x8, [x8, #0x8]
    7520:      	add	x8, x0, x8, lsl #3
    7524:      	ldr	d1, [x8, #0x10]
    7528:      	b	0x75d4 <_main+0x1290>
    752c:      	ldr	x11, [x8, #0x18]
    7530:      	cmp	x11, #0x0
    7534:      	b.le	0x75b0 <_main+0x126c>
    7538:      	ldr	x11, [x8, #0x20]
    753c:      	ldr	x12, [x8, #0x30]
    7540:      	ldr	x13, [x8, #0x40]
    7544:      	cmp	x13, x9
    7548:      	ldr	x14, [x8, #0x50]
    754c:      	ccmp	x14, x9, #0x4, ne
    7550:      	ccmp	x12, x9, #0x4, ne
    7554:      	ccmp	x11, x9, #0x4, ne
    7558:      	cset	w15, eq
    755c:      	cbz	w10, 0x75b0 <_main+0x126c>
    7560:      	cbz	w15, 0x75b0 <_main+0x126c>
    7564:      	ldr	x10, [x8, #0x48]
    7568:      	ldr	x15, [x8, #0x58]
    756c:      	cmp	x14, x9
    7570:      	csel	x14, x15, xzr, eq
    7574:      	cmp	x13, x9
    7578:      	csel	x10, x10, x14, eq
    757c:      	ldr	x13, [x8, #0x28]
    7580:      	ldr	x8, [x8, #0x38]
    7584:      	cmp	x12, x9
    7588:      	csel	x8, x8, x10, eq
    758c:      	cmp	x11, x9
    7590:      	csel	x8, x13, x8, eq
    7594:      	add	x8, x0, x8, lsl #3
    7598:      	ldr	d1, [x8, #0x10]
    759c:      	fmov	x8, d1
    75a0:      	mov	x9, #0x10               ; =16
    75a4:      	movk	x9, #0x7ffc, lsl #48
    75a8:      	cmp	x8, x9
    75ac:      	b.ne	0x75d4 <_main+0x1290>
    75b0:      	adrp	x8, 0x7000 <_main+0xcbc>
		00000000000075b0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    75b4:      	ldr	x8, [x8]
		00000000000075b4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    75b8:      	stp	x19, x21, [sp, #0x18]
    75bc:      	adrp	x2, 0x7000 <_main+0xcbc>
		00000000000075bc:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__51
    75c0:      	add	x2, x2, #0x0
		00000000000075c0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__51
    75c4:      	and	x1, x8, #0xffffffffffff
    75c8:      	bl	0x75c8 <_main+0x1284>
		00000000000075c8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    75cc:      	mov.16b	v1, v0
    75d0:      	ldp	x19, x21, [sp, #0x18]
    75d4:      	fmov	d0, x21
    75d8:      	and	x9, x21, #0xffff000000000000
    75dc:      	fmov	x8, d1
    75e0:      	and	x10, x8, #0xffff000000000000
    75e4:      	mov	x11, #0x7ff9000000000000 ; =9221401712017801216
    75e8:      	cmp	x8, x11
    75ec:      	mov	x8, #0x7fff000000000000 ; =9223090561878065152
    75f0:      	ccmp	x10, x8, #0x2, hs
    75f4:      	cset	w8, hi
    75f8:      	mov	x10, #0x1               ; =1
    75fc:      	movk	x10, #0x7fff, lsl #48
    7600:      	cmp	x9, x10
    7604:      	mov	x9, #0x7ff8ffffffffffff ; =9221401712017801215
    7608:      	ccmp	x21, x9, #0x0, lo
    760c:      	b.hi	0x761c <_main+0x12d8>
    7610:      	tbz	w8, #0x0, 0x761c <_main+0x12d8>
    7614:      	fsub	d0, d0, d1
    7618:      	b	0x7628 <_main+0x12e4>
    761c:      	str	x19, [sp, #0x20]
    7620:      	bl	0x7620 <_main+0x12dc>
		0000000000007620:  ARM64_RELOC_BRANCH26	_js_dynamic_sub
    7624:      	ldr	x19, [sp, #0x20]
    7628:      	mov	x0, x19
    762c:      	bl	0x762c <_main+0x12e8>
		000000000000762c:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    7630:      	mov	x19, x0
    7634:      	ldr	x20, [sp, #0x28]
    7638:      	ldr	w8, [x22]
    763c:      	cbz	w8, 0x7644 <_main+0x1300>
    7640:      	bl	0x7640 <_main+0x12fc>
		0000000000007640:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    7644:      	fmov	d0, x20
    7648:      	mov	x0, x19
    764c:      	bl	0x764c <_main+0x1308>
		000000000000764c:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    7650:      	mov	x19, x0
    7654:      	ldr	w8, [x22]
    7658:      	cbz	w8, 0x7660 <_main+0x131c>
    765c:      	bl	0x765c <_main+0x1318>
		000000000000765c:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    7660:      	str	x19, [sp, #0x28]
    7664:      	bl	0x7664 <_main+0x1320>
		0000000000007664:  ARM64_RELOC_BRANCH26	_js_process_memory_usage
    7668:      	fmov	x8, d0
    766c:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    7670:      	and	x9, x8, x9
    7674:      	mov	x10, #0x7ffd000000000000 ; =9222527611924643840
    7678:      	cmp	x9, x10
    767c:      	b.ne	0x76f0 <_main+0x13ac>
    7680:      	and	x8, x8, #0xffffffffffff
    7684:      	lsr	x9, x8, #20
    7688:      	cbz	x9, 0x7834 <_main+0x14f0>
    768c:      	ldr	x0, [sp, #0x28]
    7690:      	ldurb	w10, [x8, #-0x8]
    7694:      	adrp	x9, 0x7000 <_main+0xcbc>
		0000000000007694:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__53
    7698:      	ldr	x9, [x9]
		0000000000007698:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__53
    769c:      	cbz	x9, 0x7758 <_main+0x1414>
    76a0:      	cmp	w10, #0x2
    76a4:      	b.ne	0x7758 <_main+0x1414>
    76a8:      	ldurh	w11, [x8, #-0x6]
    76ac:      	tbnz	w11, #0xb, 0x7758 <_main+0x1414>
    76b0:      	ldr	w11, [x8, #0x4]
    76b4:      	orr	x10, x11, #0x4000000000000000
    76b8:      	cbz	w11, 0x7784 <_main+0x1440>
    76bc:      	ldr	x12, [x9]
    76c0:      	cmp	x10, x12
    76c4:      	b.ne	0x7784 <_main+0x1440>
    76c8:      	ldr	x2, [x9, #0x8]
    76cc:      	tbnz	w2, #0x1e, 0x7cd0 <_main+0x198c>
    76d0:      	add	x12, x8, x2, lsl #3
    76d4:      	ldr	d0, [x12, #0x10]
    76d8:      	fmov	x12, d0
    76dc:      	mov	x13, #0x10              ; =16
    76e0:      	movk	x13, #0x7ffc, lsl #48
    76e4:      	cmp	x12, x13
    76e8:      	b.ne	0x7854 <_main+0x1510>
    76ec:      	b	0x77b0 <_main+0x146c>
    76f0:      	lsr	x9, x8, #48
    76f4:      	mov	w10, #0x7ff9            ; =32761
    76f8:      	cmp	x9, x10
    76fc:      	b.eq	0x7740 <_main+0x13fc>
    7700:      	mov	w10, #0x7ffe            ; =32766
    7704:      	cmp	w9, w10
    7708:      	b.ne	0x7730 <_main+0x13ec>
    770c:      	adrp	x9, 0x7000 <_main+0xcbc>
		000000000000770c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    7710:      	ldr	x9, [x9]
		0000000000007710:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    7714:      	mov	x0, #0x34               ; =52
    7718:      	movk	x0, #0xddae, lsl #32
    771c:      	movk	x0, #0x5556, lsl #48
    7720:      	and	x2, x9, #0xffffffffffff
    7724:      	mov	x1, x8
    7728:      	bl	0x7728 <_main+0x13e4>
		0000000000007728:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    772c:      	b	0x7850 <_main+0x150c>
    7730:      	mov	x9, #-0x7ffc000000000001 ; =-9222246136947933185
    7734:      	add	x9, x8, x9
    7738:      	cmp	x9, #0x2
    773c:      	b.lo	0x7d30 <_main+0x19ec>
    7740:      	adrp	x9, 0x7000 <_main+0xcbc>
		0000000000007740:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    7744:      	ldr	x9, [x9]
		0000000000007744:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    7748:      	and	x1, x9, #0xffffffffffff
    774c:      	mov	x0, x8
    7750:      	bl	0x7750 <_main+0x140c>
		0000000000007750:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    7754:      	b	0x7850 <_main+0x150c>
    7758:      	cmp	w10, #0x2
    775c:      	b.ne	0x7834 <_main+0x14f0>
    7760:      	cbz	x9, 0x7834 <_main+0x14f0>
    7764:      	ldr	x10, [x9, #0x10]
    7768:      	cbz	x10, 0x7834 <_main+0x14f0>
    776c:      	ldr	x11, [x8, #0x8]
    7770:      	cbz	x11, 0x7834 <_main+0x14f0>
    7774:      	ldr	x11, [x11, #0x30]
    7778:      	cmp	x11, x10
    777c:      	b.eq	0x77a0 <_main+0x145c>
    7780:      	b	0x7834 <_main+0x14f0>
    7784:      	ldr	x12, [x9, #0x10]
    7788:      	cbz	x12, 0x77b0 <_main+0x146c>
    778c:      	ldr	x13, [x8, #0x8]
    7790:      	cbz	x13, 0x77b0 <_main+0x146c>
    7794:      	ldr	x13, [x13, #0x30]
    7798:      	cmp	x13, x12
    779c:      	b.ne	0x77b0 <_main+0x146c>
    77a0:      	ldr	x9, [x9, #0x8]
    77a4:      	add	x8, x8, x9, lsl #3
    77a8:      	ldr	d0, [x8, #0x10]
    77ac:      	b	0x7854 <_main+0x1510>
    77b0:      	ldr	x12, [x9, #0x18]
    77b4:      	cmp	x12, #0x0
    77b8:      	b.le	0x7834 <_main+0x14f0>
    77bc:      	ldr	x12, [x9, #0x20]
    77c0:      	ldr	x13, [x9, #0x30]
    77c4:      	ldr	x14, [x9, #0x40]
    77c8:      	cmp	x14, x10
    77cc:      	ldr	x15, [x9, #0x50]
    77d0:      	ccmp	x15, x10, #0x4, ne
    77d4:      	ccmp	x13, x10, #0x4, ne
    77d8:      	ccmp	x12, x10, #0x4, ne
    77dc:      	cset	w16, eq
    77e0:      	cbz	w11, 0x7834 <_main+0x14f0>
    77e4:      	cbz	w16, 0x7834 <_main+0x14f0>
    77e8:      	ldr	x11, [x9, #0x48]
    77ec:      	ldr	x16, [x9, #0x58]
    77f0:      	cmp	x15, x10
    77f4:      	csel	x15, x16, xzr, eq
    77f8:      	cmp	x14, x10
    77fc:      	csel	x11, x11, x15, eq
    7800:      	ldr	x14, [x9, #0x28]
    7804:      	ldr	x9, [x9, #0x38]
    7808:      	cmp	x13, x10
    780c:      	csel	x9, x9, x11, eq
    7810:      	cmp	x12, x10
    7814:      	csel	x9, x14, x9, eq
    7818:      	add	x9, x8, x9, lsl #3
    781c:      	ldr	d0, [x9, #0x10]
    7820:      	fmov	x9, d0
    7824:      	mov	x10, #0x10              ; =16
    7828:      	movk	x10, #0x7ffc, lsl #48
    782c:      	cmp	x9, x10
    7830:      	b.ne	0x7854 <_main+0x1510>
    7834:      	adrp	x9, 0x7000 <_main+0xcbc>
		0000000000007834:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    7838:      	ldr	x9, [x9]
		0000000000007838:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    783c:      	adrp	x2, 0x7000 <_main+0xcbc>
		000000000000783c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__53
    7840:      	add	x2, x2, #0x0
		0000000000007840:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__53
    7844:      	and	x1, x9, #0xffffffffffff
    7848:      	mov	x0, x8
    784c:      	bl	0x784c <_main+0x1508>
		000000000000784c:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    7850:      	ldr	x0, [sp, #0x28]
    7854:      	bl	0x7854 <_main+0x1510>
		0000000000007854:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    7858:      	mov	x19, x0
    785c:      	ldr	x20, [sp, #0x30]
    7860:      	ldr	w8, [x22]
    7864:      	cbz	w8, 0x786c <_main+0x1528>
    7868:      	bl	0x7868 <_main+0x1524>
		0000000000007868:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    786c:      	fmov	d0, x20
    7870:      	mov	x0, x19
    7874:      	bl	0x7874 <_main+0x1530>
		0000000000007874:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    7878:      	mov	x19, x0
    787c:      	ldr	w8, [x22]
    7880:      	cbz	w8, 0x7888 <_main+0x1544>
    7884:      	bl	0x7884 <_main+0x1540>
		0000000000007884:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    7888:      	movi.2d	v0, #0000000000000000
    788c:      	mov	x0, x19
    7890:      	bl	0x7890 <_main+0x154c>
		0000000000007890:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    7894:      	mov	x19, x0
    7898:      	ldr	w8, [x22]
    789c:      	cbz	w8, 0x78a4 <_main+0x1560>
    78a0:      	bl	0x78a0 <_main+0x155c>
		00000000000078a0:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    78a4:      	mov	x0, x19
    78a8:      	bl	0x78a8 <_main+0x1564>
		00000000000078a8:  ARM64_RELOC_BRANCH26	_js_console_log_spread
    78ac:      	mov	w0, #0x2                ; =2
    78b0:      	bl	0x78b0 <_main+0x156c>
		00000000000078b0:  ARM64_RELOC_BRANCH26	_js_array_alloc
    78b4:      	mov	x19, x0
    78b8:      	ldr	w8, [x22]
    78bc:      	cbz	w8, 0x78c4 <_main+0x1580>
    78c0:      	bl	0x78c0 <_main+0x157c>
		00000000000078c0:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    78c4:      	adrp	x8, 0x7000 <_main+0xcbc>
		00000000000078c4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.14.handle
    78c8:      	ldr	d0, [x8]
		00000000000078c8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.14.handle
    78cc:      	mov	x0, x19
    78d0:      	bl	0x78d0 <_main+0x158c>
		00000000000078d0:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    78d4:      	mov	x19, x0
    78d8:      	ldr	x20, [sp, #0x38]
    78dc:      	ldr	w8, [x22]
    78e0:      	cbz	w8, 0x78e8 <_main+0x15a4>
    78e4:      	bl	0x78e4 <_main+0x15a0>
		00000000000078e4:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    78e8:      	lsr	x8, x20, #48
    78ec:      	mov	x9, #-0x3000000000000   ; =-844424930131968
    78f0:      	and	x9, x20, x9
    78f4:      	mov	x10, #0x7ffd000000000000 ; =9222527611924643840
    78f8:      	cmp	x9, x10
    78fc:      	b.ne	0x792c <_main+0x15e8>
    7900:      	and	x0, x20, #0xffffffffffff
    7904:      	mov	w9, #0x7fff             ; =32767
    7908:      	cmp	x8, x9
    790c:      	b.ne	0x796c <_main+0x1628>
    7910:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007910:  ARM64_RELOC_PAGE21	_perry_null_guard_zero_access_worker_ts
    7914:      	add	x8, x8, #0x0
		0000000000007914:  ARM64_RELOC_PAGEOFF12	_perry_null_guard_zero_access_worker_ts
    7918:      	cmp	x0, #0x1, lsl #12       ; =0x1000
    791c:      	csel	x8, x8, x0, lo
    7920:      	ldr	s0, [x8]
    7924:      	ucvtf	d0, d0
    7928:      	b	0x7b24 <_main+0x17e0>
    792c:      	mov	w9, #0x7ff9             ; =32761
    7930:      	cmp	x8, x9
    7934:      	b.eq	0x79d4 <_main+0x1690>
    7938:      	mov	w9, #0x7ffe             ; =32766
    793c:      	cmp	w8, w9
    7940:      	b.ne	0x79e0 <_main+0x169c>
    7944:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007944:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    7948:      	ldr	x8, [x8]
		0000000000007948:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    794c:      	str	x19, [sp, #0x38]
    7950:      	mov	x0, #0x36               ; =54
    7954:      	movk	x0, #0xddae, lsl #32
    7958:      	movk	x0, #0x5556, lsl #48
    795c:      	and	x2, x8, #0xffffffffffff
    7960:      	mov	x1, x20
    7964:      	bl	0x7964 <_main+0x1620>
		0000000000007964:  ARM64_RELOC_BRANCH26	_js_typed_feedback_object_get_field_by_name_f64
    7968:      	b	0x7b20 <_main+0x17dc>
    796c:      	lsr	x8, x0, #20
    7970:      	cbz	x8, 0x7b04 <_main+0x17c0>
    7974:      	ldurb	w9, [x0, #-0x8]
    7978:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007978:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__55
    797c:      	ldr	x8, [x8]
		000000000000797c:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__55
    7980:      	cbz	x8, 0x7a0c <_main+0x16c8>
    7984:      	cmp	w9, #0x2
    7988:      	b.ne	0x7a0c <_main+0x16c8>
    798c:      	ldurh	w10, [x0, #-0x6]
    7990:      	tbnz	w10, #0xb, 0x7a0c <_main+0x16c8>
    7994:      	ldr	w10, [x0, #0x4]
    7998:      	orr	x9, x10, #0x4000000000000000
    799c:      	cbz	w10, 0x7a54 <_main+0x1710>
    79a0:      	ldr	x11, [x8]
    79a4:      	cmp	x9, x11
    79a8:      	b.ne	0x7a54 <_main+0x1710>
    79ac:      	ldr	x2, [x8, #0x8]
    79b0:      	tbnz	w2, #0x1e, 0x7d10 <_main+0x19cc>
    79b4:      	add	x11, x0, x2, lsl #3
    79b8:      	ldr	d0, [x11, #0x10]
    79bc:      	fmov	x11, d0
    79c0:      	mov	x12, #0x10              ; =16
    79c4:      	movk	x12, #0x7ffc, lsl #48
    79c8:      	cmp	x11, x12
    79cc:      	b.ne	0x7b24 <_main+0x17e0>
    79d0:      	b	0x7a80 <_main+0x173c>
    79d4:      	ubfx	x8, x20, #40, #8
    79d8:      	ucvtf	d0, x8
    79dc:      	b	0x7b24 <_main+0x17e0>
    79e0:      	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
    79e4:      	add	x8, x20, x8
    79e8:      	cmp	x8, #0x2
    79ec:      	b.lo	0x7dd4 <_main+0x1a90>
    79f0:      	adrp	x8, 0x7000 <_main+0xcbc>
		00000000000079f0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    79f4:      	ldr	x8, [x8]
		00000000000079f4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    79f8:      	str	x19, [sp, #0x38]
    79fc:      	and	x1, x8, #0xffffffffffff
    7a00:      	mov	x0, x20
    7a04:      	bl	0x7a04 <_main+0x16c0>
		0000000000007a04:  ARM64_RELOC_BRANCH26	_js_object_get_field_by_name_f64
    7a08:      	b	0x7b20 <_main+0x17dc>
    7a0c:      	cmp	w9, #0x2
    7a10:      	b.ne	0x7b04 <_main+0x17c0>
    7a14:      	cbz	x8, 0x7b04 <_main+0x17c0>
    7a18:      	ldr	x9, [x8, #0x10]
    7a1c:      	cbz	x9, 0x7b04 <_main+0x17c0>
    7a20:      	ldr	x10, [x0, #0x8]
    7a24:      	cbz	x10, 0x7b04 <_main+0x17c0>
    7a28:      	ldr	x10, [x10, #0x30]
    7a2c:      	cmp	x10, x9
    7a30:      	b.eq	0x7a70 <_main+0x172c>
    7a34:      	b	0x7b04 <_main+0x17c0>
    7a38:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007a38:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    7a3c:      	ldr	x8, [x8]
		0000000000007a3c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    7a40:      	adrp	x3, 0x7000 <_main+0xcbc>
		0000000000007a40:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__43
    7a44:      	add	x3, x3, #0x0
		0000000000007a44:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__43
    7a48:      	and	x1, x8, #0xffffffffffff
    7a4c:      	bl	0x7a4c <_main+0x1708>
		0000000000007a4c:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7a50:      	b	0x6bdc <_main+0x898>
    7a54:      	ldr	x11, [x8, #0x10]
    7a58:      	cbz	x11, 0x7a80 <_main+0x173c>
    7a5c:      	ldr	x12, [x0, #0x8]
    7a60:      	cbz	x12, 0x7a80 <_main+0x173c>
    7a64:      	ldr	x12, [x12, #0x30]
    7a68:      	cmp	x12, x11
    7a6c:      	b.ne	0x7a80 <_main+0x173c>
    7a70:      	ldr	x8, [x8, #0x8]
    7a74:      	add	x8, x0, x8, lsl #3
    7a78:      	ldr	d0, [x8, #0x10]
    7a7c:      	b	0x7b24 <_main+0x17e0>
    7a80:      	ldr	x11, [x8, #0x18]
    7a84:      	cmp	x11, #0x0
    7a88:      	b.le	0x7b04 <_main+0x17c0>
    7a8c:      	ldr	x11, [x8, #0x20]
    7a90:      	ldr	x12, [x8, #0x30]
    7a94:      	ldr	x13, [x8, #0x40]
    7a98:      	cmp	x13, x9
    7a9c:      	ldr	x14, [x8, #0x50]
    7aa0:      	ccmp	x14, x9, #0x4, ne
    7aa4:      	ccmp	x12, x9, #0x4, ne
    7aa8:      	ccmp	x11, x9, #0x4, ne
    7aac:      	cset	w15, eq
    7ab0:      	cbz	w10, 0x7b04 <_main+0x17c0>
    7ab4:      	cbz	w15, 0x7b04 <_main+0x17c0>
    7ab8:      	ldr	x10, [x8, #0x48]
    7abc:      	ldr	x15, [x8, #0x58]
    7ac0:      	cmp	x14, x9
    7ac4:      	csel	x14, x15, xzr, eq
    7ac8:      	cmp	x13, x9
    7acc:      	csel	x10, x10, x14, eq
    7ad0:      	ldr	x13, [x8, #0x28]
    7ad4:      	ldr	x8, [x8, #0x38]
    7ad8:      	cmp	x12, x9
    7adc:      	csel	x8, x8, x10, eq
    7ae0:      	cmp	x11, x9
    7ae4:      	csel	x8, x13, x8, eq
    7ae8:      	add	x8, x0, x8, lsl #3
    7aec:      	ldr	d0, [x8, #0x10]
    7af0:      	fmov	x8, d0
    7af4:      	mov	x9, #0x10               ; =16
    7af8:      	movk	x9, #0x7ffc, lsl #48
    7afc:      	cmp	x8, x9
    7b00:      	b.ne	0x7b24 <_main+0x17e0>
    7b04:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007b04:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    7b08:      	ldr	x8, [x8]
		0000000000007b08:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    7b0c:      	str	x19, [sp, #0x38]
    7b10:      	adrp	x2, 0x7000 <_main+0xcbc>
		0000000000007b10:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__55
    7b14:      	add	x2, x2, #0x0
		0000000000007b14:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__55
    7b18:      	and	x1, x8, #0xffffffffffff
    7b1c:      	bl	0x7b1c <_main+0x17d8>
		0000000000007b1c:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_miss
    7b20:      	ldr	x19, [sp, #0x38]
    7b24:      	mov	x0, x19
    7b28:      	bl	0x7b28 <_main+0x17e4>
		0000000000007b28:  ARM64_RELOC_BRANCH26	_js_array_push_f64
    7b2c:      	mov	x19, x0
    7b30:      	ldr	w8, [x22]
    7b34:      	cbz	w8, 0x7b3c <_main+0x17f8>
    7b38:      	bl	0x7b38 <_main+0x17f4>
		0000000000007b38:  ARM64_RELOC_BRANCH26	_js_write_barrier_root_nanbox
    7b3c:      	mov	x0, x19
    7b40:      	bl	0x7b40 <_main+0x17fc>
		0000000000007b40:  ARM64_RELOC_BRANCH26	_js_console_log_spread
    7b44:      	bl	0x7b44 <_main+0x1800>
		0000000000007b44:  ARM64_RELOC_BRANCH26	_js_promise_run_microtasks_event_loop
    7b48:      	bl	0x7b48 <_main+0x1804>
		0000000000007b48:  ARM64_RELOC_BRANCH26	_js_promise_run_microtasks_event_loop
    7b4c:      	bl	0x7b4c <_main+0x1808>
		0000000000007b4c:  ARM64_RELOC_BRANCH26	_js_promise_run_microtasks_event_loop
    7b50:      	bl	0x7b50 <_main+0x180c>
		0000000000007b50:  ARM64_RELOC_BRANCH26	_js_promise_run_microtasks_event_loop
    7b54:      	bl	0x7b54 <_main+0x1810>
		0000000000007b54:  ARM64_RELOC_BRANCH26	_js_run_stdlib_pump
    7b58:      	bl	0x7b58 <_main+0x1814>
		0000000000007b58:  ARM64_RELOC_BRANCH26	_js_event_loop_host_driven
    7b5c:      	cbnz	w0, 0x7bf8 <_main+0x18b4>
    7b60:      	bl	0x7b60 <_main+0x181c>
		0000000000007b60:  ARM64_RELOC_BRANCH26	_js_timer_has_pending
    7b64:      	mov	x19, x0
    7b68:      	bl	0x7b68 <_main+0x1824>
		0000000000007b68:  ARM64_RELOC_BRANCH26	_js_callback_timer_has_pending
    7b6c:      	mov	x20, x0
    7b70:      	bl	0x7b70 <_main+0x182c>
		0000000000007b70:  ARM64_RELOC_BRANCH26	_js_interval_timer_has_pending
    7b74:      	mov	x21, x0
    7b78:      	bl	0x7b78 <_main+0x1834>
		0000000000007b78:  ARM64_RELOC_BRANCH26	_js_stdlib_has_active_handles
    7b7c:      	mov	x22, x0
    7b80:      	bl	0x7b80 <_main+0x183c>
		0000000000007b80:  ARM64_RELOC_BRANCH26	_js_bun_ffi_has_active_threadsafe_callbacks
    7b84:      	mov	x23, x0
    7b88:      	bl	0x7b88 <_main+0x1844>
		0000000000007b88:  ARM64_RELOC_BRANCH26	_js_microtasks_pending
    7b8c:      	orr	w8, w20, w19
    7b90:      	orr	w9, w21, w22
    7b94:      	orr	w8, w8, w9
    7b98:      	orr	w9, w23, w0
    7b9c:      	orr	w8, w8, w9
    7ba0:      	cbz	w8, 0x7c24 <_main+0x18e0>
    7ba4:      	bl	0x7ba4 <_main+0x1860>
		0000000000007ba4:  ARM64_RELOC_BRANCH26	_js_promise_run_microtasks_event_loop
    7ba8:      	bl	0x7ba8 <_main+0x1864>
		0000000000007ba8:  ARM64_RELOC_BRANCH26	_js_run_stdlib_pump
    7bac:      	bl	0x7bac <_main+0x1868>
		0000000000007bac:  ARM64_RELOC_BRANCH26	_js_timer_has_pending
    7bb0:      	mov	x19, x0
    7bb4:      	bl	0x7bb4 <_main+0x1870>
		0000000000007bb4:  ARM64_RELOC_BRANCH26	_js_callback_timer_has_pending
    7bb8:      	mov	x20, x0
    7bbc:      	bl	0x7bbc <_main+0x1878>
		0000000000007bbc:  ARM64_RELOC_BRANCH26	_js_interval_timer_has_pending
    7bc0:      	mov	x21, x0
    7bc4:      	bl	0x7bc4 <_main+0x1880>
		0000000000007bc4:  ARM64_RELOC_BRANCH26	_js_stdlib_has_active_handles
    7bc8:      	mov	x22, x0
    7bcc:      	bl	0x7bcc <_main+0x1888>
		0000000000007bcc:  ARM64_RELOC_BRANCH26	_js_bun_ffi_has_active_threadsafe_callbacks
    7bd0:      	mov	x23, x0
    7bd4:      	bl	0x7bd4 <_main+0x1890>
		0000000000007bd4:  ARM64_RELOC_BRANCH26	_js_microtasks_pending
    7bd8:      	orr	w8, w20, w19
    7bdc:      	orr	w9, w21, w22
    7be0:      	orr	w8, w8, w9
    7be4:      	orr	w9, w23, w0
    7be8:      	orr	w8, w8, w9
    7bec:      	cbz	w8, 0x7b58 <_main+0x1814>
    7bf0:      	bl	0x7bf0 <_main+0x18ac>
		0000000000007bf0:  ARM64_RELOC_BRANCH26	_js_wait_for_event
    7bf4:      	b	0x7b58 <_main+0x1814>
    7bf8:      	mov	w19, #0x0               ; =0
    7bfc:      	bl	0x7bfc <_main+0x18b8>
		0000000000007bfc:  ARM64_RELOC_BRANCH26	_js_typed_feedback_maybe_dump_trace
    7c00:      	mov	x0, x19
    7c04:      	ldp	x29, x30, [sp, #0x90]
    7c08:      	ldp	x20, x19, [sp, #0x80]
    7c0c:      	ldp	x22, x21, [sp, #0x70]
    7c10:      	ldp	x24, x23, [sp, #0x60]
    7c14:      	ldp	d9, d8, [sp, #0x50]
    7c18:      	ldp	d11, d10, [sp, #0x40]
    7c1c:      	add	sp, sp, #0xa0
    7c20:      	ret
    7c24:      	bl	0x7c24 <_main+0x18e0>
		0000000000007c24:  ARM64_RELOC_BRANCH26	_js_process_emit_before_exit_pending
    7c28:      	bl	0x7c28 <_main+0x18e4>
		0000000000007c28:  ARM64_RELOC_BRANCH26	_js_promise_run_microtasks_event_loop
    7c2c:      	bl	0x7c2c <_main+0x18e8>
		0000000000007c2c:  ARM64_RELOC_BRANCH26	_js_process_run_exit_sequence
    7c30:      	bl	0x7c30 <_main+0x18ec>
		0000000000007c30:  ARM64_RELOC_BRANCH26	_js_process_run_finalization_exit
    7c34:      	bl	0x7c34 <_main+0x18f0>
		0000000000007c34:  ARM64_RELOC_BRANCH26	_js_promise_run_promise_jobs
    7c38:      	bl	0x7c38 <_main+0x18f4>
		0000000000007c38:  ARM64_RELOC_BRANCH26	_js_trace_events_flush_output
    7c3c:      	bl	0x7c3c <_main+0x18f8>
		0000000000007c3c:  ARM64_RELOC_BRANCH26	_js_promise_report_unhandled_rejections
    7c40:      	bl	0x7c40 <_main+0x18fc>
		0000000000007c40:  ARM64_RELOC_BRANCH26	_js_gc_release_current_thread_collection_side_allocations
    7c44:      	bl	0x7c44 <_main+0x1900>
		0000000000007c44:  ARM64_RELOC_BRANCH26	_js_process_pending_exit_code
    7c48:      	mov	x19, x0
    7c4c:      	b	0x7bfc <_main+0x18b8>
    7c50:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007c50:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    7c54:      	ldr	x8, [x8]
		0000000000007c54:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    7c58:      	str	x19, [sp, #0x10]
    7c5c:      	adrp	x3, 0x7000 <_main+0xcbc>
		0000000000007c5c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__45
    7c60:      	add	x3, x3, #0x0
		0000000000007c60:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__45
    7c64:      	and	x1, x8, #0xffffffffffff
    7c68:      	bl	0x7c68 <_main+0x1924>
		0000000000007c68:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7c6c:      	b	0x6f68 <_main+0xc24>
    7c70:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007c70:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    7c74:      	ldr	x8, [x8]
		0000000000007c74:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    7c78:      	stp	x19, x21, [sp, #0x8]
    7c7c:      	adrp	x3, 0x7000 <_main+0xcbc>
		0000000000007c7c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__47
    7c80:      	add	x3, x3, #0x0
		0000000000007c80:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__47
    7c84:      	and	x1, x8, #0xffffffffffff
    7c88:      	bl	0x7c88 <_main+0x1944>
		0000000000007c88:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7c8c:      	b	0x716c <_main+0xe28>
    7c90:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007c90:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    7c94:      	ldr	x8, [x8]
		0000000000007c94:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    7c98:      	str	x19, [sp, #0x18]
    7c9c:      	adrp	x3, 0x7000 <_main+0xcbc>
		0000000000007c9c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__49
    7ca0:      	add	x3, x3, #0x0
		0000000000007ca0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__49
    7ca4:      	and	x1, x8, #0xffffffffffff
    7ca8:      	bl	0x7ca8 <_main+0x1964>
		0000000000007ca8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7cac:      	b	0x73cc <_main+0x1088>
    7cb0:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007cb0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    7cb4:      	ldr	x8, [x8]
		0000000000007cb4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    7cb8:      	stp	x19, x21, [sp, #0x18]
    7cbc:      	adrp	x3, 0x7000 <_main+0xcbc>
		0000000000007cbc:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__51
    7cc0:      	add	x3, x3, #0x0
		0000000000007cc0:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__51
    7cc4:      	and	x1, x8, #0xffffffffffff
    7cc8:      	bl	0x7cc8 <_main+0x1984>
		0000000000007cc8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7ccc:      	b	0x75cc <_main+0x1288>
    7cd0:      	adrp	x9, 0x7000 <_main+0xcbc>
		0000000000007cd0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    7cd4:      	ldr	x9, [x9]
		0000000000007cd4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    7cd8:      	adrp	x3, 0x7000 <_main+0xcbc>
		0000000000007cd8:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__53
    7cdc:      	add	x3, x3, #0x0
		0000000000007cdc:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__53
    7ce0:      	and	x1, x9, #0xffffffffffff
    7ce4:      	mov	x0, x8
    7ce8:      	bl	0x7ce8 <_main+0x19a4>
		0000000000007ce8:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7cec:      	b	0x7850 <_main+0x150c>
    7cf0:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007cf0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    7cf4:      	ldr	x8, [x8]
		0000000000007cf4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    7cf8:      	str	x19, [sp, #0x38]
    7cfc:      	adrp	x3, 0x7000 <_main+0xcbc>
		0000000000007cfc:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__41
    7d00:      	add	x3, x3, #0x0
		0000000000007d00:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__41
    7d04:      	and	x1, x8, #0xffffffffffff
    7d08:      	bl	0x7d08 <_main+0x19c4>
		0000000000007d08:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7d0c:      	b	0x69b8 <_main+0x674>
    7d10:      	adrp	x8, 0x7000 <_main+0xcbc>
		0000000000007d10:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    7d14:      	ldr	x8, [x8]
		0000000000007d14:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    7d18:      	str	x19, [sp, #0x38]
    7d1c:      	adrp	x3, 0x7000 <_main+0xcbc>
		0000000000007d1c:  ARM64_RELOC_PAGE21	l_perry_ic_access_worker_ts__55
    7d20:      	add	x3, x3, #0x0
		0000000000007d20:  ARM64_RELOC_PAGEOFF12	l_perry_ic_access_worker_ts__55
    7d24:      	and	x1, x8, #0xffffffffffff
    7d28:      	bl	0x7d28 <_main+0x19e4>
		0000000000007d28:  ARM64_RELOC_BRANCH26	_js_object_get_field_ic_overflow_load
    7d2c:      	b	0x7b20 <_main+0x17dc>
    7d30:      	mov	x9, #0x10               ; =16
    7d34:      	movk	x9, #0x7ffc, lsl #48
    7d38:      	sub	x9, x9, #0xe
    7d3c:      	cmp	x8, x9
    7d40:      	cset	w0, eq
    7d44:      	adrp	x1, 0x7000 <_main+0xcbc>
		0000000000007d44:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.10.bytes
    7d48:      	add	x1, x1, #0x0
		0000000000007d48:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.10.bytes
    7d4c:      	mov	w2, #0x3                ; =3
    7d50:      	b	0x7df4 <_main+0x1ab0>
    7d54:      	mov	x9, #0x10               ; =16
    7d58:      	movk	x9, #0x7ffc, lsl #48
    7d5c:      	sub	x9, x9, #0xe
    7d60:      	cmp	x8, x9
    7d64:      	b	0x7de4 <_main+0x1aa0>
    7d68:      	mov	x8, #0x10               ; =16
    7d6c:      	movk	x8, #0x7ffc, lsl #48
    7d70:      	sub	x8, x8, #0xe
    7d74:      	cmp	x21, x8
    7d78:      	b	0x7d8c <_main+0x1a48>
    7d7c:      	mov	x8, #0x10               ; =16
    7d80:      	movk	x8, #0x7ffc, lsl #48
    7d84:      	sub	x8, x8, #0xe
    7d88:      	cmp	x20, x8
    7d8c:      	cset	w0, eq
    7d90:      	adrp	x1, 0x7000 <_main+0xcbc>
		0000000000007d90:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.12.bytes
    7d94:      	add	x1, x1, #0x0
		0000000000007d94:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.12.bytes
    7d98:      	mov	w2, #0x4                ; =4
    7d9c:      	b	0x7df4 <_main+0x1ab0>
    7da0:      	mov	x8, #0x10               ; =16
    7da4:      	movk	x8, #0x7ffc, lsl #48
    7da8:      	sub	x8, x8, #0xe
    7dac:      	cmp	x21, x8
    7db0:      	b	0x7dc4 <_main+0x1a80>
    7db4:      	mov	x8, #0x10               ; =16
    7db8:      	movk	x8, #0x7ffc, lsl #48
    7dbc:      	sub	x8, x8, #0xe
    7dc0:      	cmp	x20, x8
    7dc4:      	cset	w0, eq
    7dc8:      	adrp	x1, 0x7000 <_main+0xcbc>
		0000000000007dc8:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.13.bytes
    7dcc:      	add	x1, x1, #0x0
		0000000000007dcc:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.13.bytes
    7dd0:      	b	0x7df0 <_main+0x1aac>
    7dd4:      	mov	x8, #0x10               ; =16
    7dd8:      	movk	x8, #0x7ffc, lsl #48
    7ddc:      	sub	x8, x8, #0xe
    7de0:      	cmp	x20, x8
    7de4:      	cset	w0, eq
    7de8:      	adrp	x1, 0x7000 <_main+0xcbc>
		0000000000007de8:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.9.bytes
    7dec:      	add	x1, x1, #0x0
		0000000000007dec:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.9.bytes
    7df0:      	mov	w2, #0x6                ; =6
    7df4:      	bl	0x7df4 <_main+0x1ab0>
		0000000000007df4:  ARM64_RELOC_BRANCH26	_js_throw_type_error_property_access
    7df8:      	brk	#0x1

0000000000007dfc <___perry_init_strings_access_worker_ts_chunk0>:
    7dfc:      	stp	x20, x19, [sp, #-0x20]!
    7e00:      	stp	x29, x30, [sp, #0x10]
    7e04:      	add	x29, sp, #0x10
    7e08:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007e08:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.0.bytes
    7e0c:      	add	x0, x0, #0x0
		0000000000007e0c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.0.bytes
    7e10:      	mov	w1, #0x6                ; =6
    7e14:      	bl	0x7e14 <___perry_init_strings_access_worker_ts_chunk0+0x18>
		0000000000007e14:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7e18:      	bl	0x7e18 <___perry_init_strings_access_worker_ts_chunk0+0x1c>
		0000000000007e18:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7e1c:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007e1c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.0.handle
    7e20:      	add	x0, x0, #0x0
		0000000000007e20:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.0.handle
    7e24:      	str	d0, [x0]
    7e28:      	bl	0x7e28 <___perry_init_strings_access_worker_ts_chunk0+0x2c>
		0000000000007e28:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7e2c:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007e2c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1.bytes
    7e30:      	add	x0, x0, #0x0
		0000000000007e30:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1.bytes
    7e34:      	mov	w1, #0x2                ; =2
    7e38:      	bl	0x7e38 <___perry_init_strings_access_worker_ts_chunk0+0x3c>
		0000000000007e38:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7e3c:      	bl	0x7e3c <___perry_init_strings_access_worker_ts_chunk0+0x40>
		0000000000007e3c:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7e40:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007e40:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.1.handle
    7e44:      	add	x0, x0, #0x0
		0000000000007e44:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.1.handle
    7e48:      	str	d0, [x0]
    7e4c:      	bl	0x7e4c <___perry_init_strings_access_worker_ts_chunk0+0x50>
		0000000000007e4c:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7e50:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007e50:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.2.bytes
    7e54:      	add	x0, x0, #0x0
		0000000000007e54:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.2.bytes
    7e58:      	mov	w1, #0x6                ; =6
    7e5c:      	bl	0x7e5c <___perry_init_strings_access_worker_ts_chunk0+0x60>
		0000000000007e5c:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7e60:      	bl	0x7e60 <___perry_init_strings_access_worker_ts_chunk0+0x64>
		0000000000007e60:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7e64:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007e64:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.2.handle
    7e68:      	add	x0, x0, #0x0
		0000000000007e68:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.2.handle
    7e6c:      	str	d0, [x0]
    7e70:      	bl	0x7e70 <___perry_init_strings_access_worker_ts_chunk0+0x74>
		0000000000007e70:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7e74:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007e74:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.3.bytes
    7e78:      	add	x0, x0, #0x0
		0000000000007e78:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.3.bytes
    7e7c:      	mov	w1, #0x6                ; =6
    7e80:      	bl	0x7e80 <___perry_init_strings_access_worker_ts_chunk0+0x84>
		0000000000007e80:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7e84:      	bl	0x7e84 <___perry_init_strings_access_worker_ts_chunk0+0x88>
		0000000000007e84:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7e88:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007e88:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.3.handle
    7e8c:      	add	x0, x0, #0x0
		0000000000007e8c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.3.handle
    7e90:      	str	d0, [x0]
    7e94:      	bl	0x7e94 <___perry_init_strings_access_worker_ts_chunk0+0x98>
		0000000000007e94:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7e98:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007e98:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.4.bytes
    7e9c:      	add	x0, x0, #0x0
		0000000000007e9c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.4.bytes
    7ea0:      	mov	w1, #0x4                ; =4
    7ea4:      	bl	0x7ea4 <___perry_init_strings_access_worker_ts_chunk0+0xa8>
		0000000000007ea4:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7ea8:      	bl	0x7ea8 <___perry_init_strings_access_worker_ts_chunk0+0xac>
		0000000000007ea8:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7eac:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007eac:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.4.handle
    7eb0:      	add	x0, x0, #0x0
		0000000000007eb0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.4.handle
    7eb4:      	str	d0, [x0]
    7eb8:      	bl	0x7eb8 <___perry_init_strings_access_worker_ts_chunk0+0xbc>
		0000000000007eb8:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7ebc:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007ebc:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.5.bytes
    7ec0:      	add	x0, x0, #0x0
		0000000000007ec0:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.5.bytes
    7ec4:      	mov	w1, #0x6                ; =6
    7ec8:      	bl	0x7ec8 <___perry_init_strings_access_worker_ts_chunk0+0xcc>
		0000000000007ec8:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7ecc:      	bl	0x7ecc <___perry_init_strings_access_worker_ts_chunk0+0xd0>
		0000000000007ecc:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7ed0:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007ed0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.5.handle
    7ed4:      	add	x0, x0, #0x0
		0000000000007ed4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.5.handle
    7ed8:      	str	d0, [x0]
    7edc:      	bl	0x7edc <___perry_init_strings_access_worker_ts_chunk0+0xe0>
		0000000000007edc:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7ee0:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007ee0:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.6.bytes
    7ee4:      	add	x0, x0, #0x0
		0000000000007ee4:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.6.bytes
    7ee8:      	mov	w1, #0x2                ; =2
    7eec:      	bl	0x7eec <___perry_init_strings_access_worker_ts_chunk0+0xf0>
		0000000000007eec:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7ef0:      	bl	0x7ef0 <___perry_init_strings_access_worker_ts_chunk0+0xf4>
		0000000000007ef0:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7ef4:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007ef4:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.6.handle
    7ef8:      	add	x0, x0, #0x0
		0000000000007ef8:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.6.handle
    7efc:      	str	d0, [x0]
    7f00:      	bl	0x7f00 <___perry_init_strings_access_worker_ts_chunk0+0x104>
		0000000000007f00:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7f04:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007f04:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.7.bytes
    7f08:      	add	x0, x0, #0x0
		0000000000007f08:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.7.bytes
    7f0c:      	mov	w1, #0xc                ; =12
    7f10:      	bl	0x7f10 <___perry_init_strings_access_worker_ts_chunk0+0x114>
		0000000000007f10:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7f14:      	bl	0x7f14 <___perry_init_strings_access_worker_ts_chunk0+0x118>
		0000000000007f14:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7f18:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007f18:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.7.handle
    7f1c:      	add	x0, x0, #0x0
		0000000000007f1c:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.7.handle
    7f20:      	str	d0, [x0]
    7f24:      	bl	0x7f24 <___perry_init_strings_access_worker_ts_chunk0+0x128>
		0000000000007f24:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7f28:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007f28:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.8.bytes
    7f2c:      	add	x0, x0, #0x0
		0000000000007f2c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.8.bytes
    7f30:      	mov	w1, #0x4                ; =4
    7f34:      	bl	0x7f34 <___perry_init_strings_access_worker_ts_chunk0+0x138>
		0000000000007f34:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7f38:      	bl	0x7f38 <___perry_init_strings_access_worker_ts_chunk0+0x13c>
		0000000000007f38:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7f3c:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007f3c:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.8.handle
    7f40:      	add	x0, x0, #0x0
		0000000000007f40:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.8.handle
    7f44:      	str	d0, [x0]
    7f48:      	bl	0x7f48 <___perry_init_strings_access_worker_ts_chunk0+0x14c>
		0000000000007f48:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7f4c:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007f4c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.9.bytes
    7f50:      	add	x0, x0, #0x0
		0000000000007f50:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.9.bytes
    7f54:      	mov	w1, #0x6                ; =6
    7f58:      	bl	0x7f58 <___perry_init_strings_access_worker_ts_chunk0+0x15c>
		0000000000007f58:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7f5c:      	bl	0x7f5c <___perry_init_strings_access_worker_ts_chunk0+0x160>
		0000000000007f5c:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7f60:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007f60:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.9.handle
    7f64:      	add	x0, x0, #0x0
		0000000000007f64:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.9.handle
    7f68:      	str	d0, [x0]
    7f6c:      	bl	0x7f6c <___perry_init_strings_access_worker_ts_chunk0+0x170>
		0000000000007f6c:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7f70:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007f70:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.10.bytes
    7f74:      	add	x0, x0, #0x0
		0000000000007f74:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.10.bytes
    7f78:      	mov	w1, #0x3                ; =3
    7f7c:      	bl	0x7f7c <___perry_init_strings_access_worker_ts_chunk0+0x180>
		0000000000007f7c:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7f80:      	bl	0x7f80 <___perry_init_strings_access_worker_ts_chunk0+0x184>
		0000000000007f80:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7f84:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007f84:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.10.handle
    7f88:      	add	x0, x0, #0x0
		0000000000007f88:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.10.handle
    7f8c:      	str	d0, [x0]
    7f90:      	bl	0x7f90 <___perry_init_strings_access_worker_ts_chunk0+0x194>
		0000000000007f90:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7f94:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007f94:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.11.bytes
    7f98:      	add	x0, x0, #0x0
		0000000000007f98:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.11.bytes
    7f9c:      	mov	w1, #0x6                ; =6
    7fa0:      	bl	0x7fa0 <___perry_init_strings_access_worker_ts_chunk0+0x1a4>
		0000000000007fa0:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7fa4:      	bl	0x7fa4 <___perry_init_strings_access_worker_ts_chunk0+0x1a8>
		0000000000007fa4:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7fa8:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007fa8:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.11.handle
    7fac:      	add	x0, x0, #0x0
		0000000000007fac:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.11.handle
    7fb0:      	str	d0, [x0]
    7fb4:      	bl	0x7fb4 <___perry_init_strings_access_worker_ts_chunk0+0x1b8>
		0000000000007fb4:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7fb8:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007fb8:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.12.bytes
    7fbc:      	add	x0, x0, #0x0
		0000000000007fbc:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.12.bytes
    7fc0:      	mov	w1, #0x4                ; =4
    7fc4:      	bl	0x7fc4 <___perry_init_strings_access_worker_ts_chunk0+0x1c8>
		0000000000007fc4:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7fc8:      	bl	0x7fc8 <___perry_init_strings_access_worker_ts_chunk0+0x1cc>
		0000000000007fc8:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7fcc:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007fcc:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.12.handle
    7fd0:      	add	x0, x0, #0x0
		0000000000007fd0:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.12.handle
    7fd4:      	str	d0, [x0]
    7fd8:      	bl	0x7fd8 <___perry_init_strings_access_worker_ts_chunk0+0x1dc>
		0000000000007fd8:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    7fdc:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007fdc:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.13.bytes
    7fe0:      	add	x0, x0, #0x0
		0000000000007fe0:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.13.bytes
    7fe4:      	mov	w1, #0x6                ; =6
    7fe8:      	bl	0x7fe8 <___perry_init_strings_access_worker_ts_chunk0+0x1ec>
		0000000000007fe8:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    7fec:      	bl	0x7fec <___perry_init_strings_access_worker_ts_chunk0+0x1f0>
		0000000000007fec:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    7ff0:      	adrp	x0, 0x7000 <_main+0xcbc>
		0000000000007ff0:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.13.handle
    7ff4:      	add	x0, x0, #0x0
		0000000000007ff4:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.13.handle
    7ff8:      	str	d0, [x0]
    7ffc:      	bl	0x7ffc <___perry_init_strings_access_worker_ts_chunk0+0x200>
		0000000000007ffc:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    8000:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x204>
		0000000000008000:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.14.bytes
    8004:      	add	x0, x0, #0x0
		0000000000008004:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.14.bytes
    8008:      	mov	w1, #0x4                ; =4
    800c:      	bl	0x800c <___perry_init_strings_access_worker_ts_chunk0+0x210>
		000000000000800c:  ARM64_RELOC_BRANCH26	_js_string_from_bytes
    8010:      	bl	0x8010 <___perry_init_strings_access_worker_ts_chunk0+0x214>
		0000000000008010:  ARM64_RELOC_BRANCH26	_js_nanbox_string
    8014:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x204>
		0000000000008014:  ARM64_RELOC_PAGE21	_access_worker_ts_.str.14.handle
    8018:      	add	x0, x0, #0x0
		0000000000008018:  ARM64_RELOC_PAGEOFF12	_access_worker_ts_.str.14.handle
    801c:      	str	d0, [x0]
    8020:      	bl	0x8020 <___perry_init_strings_access_worker_ts_chunk0+0x224>
		0000000000008020:  ARM64_RELOC_BRANCH26	_js_gc_register_global_root
    8024:      	adrp	x19, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x204>
		0000000000008024:  ARM64_RELOC_PAGE21	___perry_wrap_perry_fn_access_worker_ts__run
    8028:      	add	x19, x19, #0x0
		0000000000008028:  ARM64_RELOC_PAGEOFF12	___perry_wrap_perry_fn_access_worker_ts__run
    802c:      	adrp	x20, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x204>
		000000000000802c:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.1
    8030:      	add	x20, x20, #0x0
		0000000000008030:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.1
    8034:      	mov	x0, x19
    8038:      	mov	x1, x20
    803c:      	mov	w2, #0x3                ; =3
    8040:      	bl	0x8040 <___perry_init_strings_access_worker_ts_chunk0+0x244>
		0000000000008040:  ARM64_RELOC_BRANCH26	_js_register_function_name_static
    8044:      	adrp	x0, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x204>
		0000000000008044:  ARM64_RELOC_PAGE21	_perry_fn_access_worker_ts__run
    8048:      	add	x0, x0, #0x0
		0000000000008048:  ARM64_RELOC_PAGEOFF12	_perry_fn_access_worker_ts__run
    804c:      	mov	x1, x20
    8050:      	mov	w2, #0x3                ; =3
    8054:      	bl	0x8054 <___perry_init_strings_access_worker_ts_chunk0+0x258>
		0000000000008054:  ARM64_RELOC_BRANCH26	_js_register_function_name_static
    8058:      	adrp	x1, 0x8000 <___perry_init_strings_access_worker_ts_chunk0+0x204>
		0000000000008058:  ARM64_RELOC_PAGE21	l_access_worker_ts_.str.2
    805c:      	add	x1, x1, #0x0
		000000000000805c:  ARM64_RELOC_PAGEOFF12	l_access_worker_ts_.str.2
    8060:      	mov	x0, x19
    8064:      	mov	w2, #0x319              ; =793
    8068:      	mov	w3, #0x0                ; =0
    806c:      	bl	0x806c <___perry_init_strings_access_worker_ts_chunk0+0x270>
		000000000000806c:  ARM64_RELOC_BRANCH26	_js_register_function_source_static
    8070:      	mov	x0, x19
    8074:      	mov	w1, #0x2                ; =2
    8078:      	bl	0x8078 <___perry_init_strings_access_worker_ts_chunk0+0x27c>
		0000000000008078:  ARM64_RELOC_BRANCH26	_js_register_closure_arity
    807c:      	mov	x0, x19
    8080:      	mov	w1, #0x2                ; =2
    8084:      	bl	0x8084 <___perry_init_strings_access_worker_ts_chunk0+0x288>
		0000000000008084:  ARM64_RELOC_BRANCH26	_js_register_closure_length
    8088:      	mov	x0, x19
    808c:      	ldp	x29, x30, [sp, #0x10]
    8090:      	ldp	x20, x19, [sp], #0x20
    8094:      	b	0x8094 <___perry_init_strings_access_worker_ts_chunk0+0x298>
		0000000000008094:  ARM64_RELOC_BRANCH26	_js_register_closure_strict_function

0000000000008098 <___perry_init_strings_access_worker_ts>:
    8098:      	b	0x8098 <___perry_init_strings_access_worker_ts>
		0000000000008098:  ARM64_RELOC_BRANCH26	___perry_init_strings_access_worker_ts_chunk0
