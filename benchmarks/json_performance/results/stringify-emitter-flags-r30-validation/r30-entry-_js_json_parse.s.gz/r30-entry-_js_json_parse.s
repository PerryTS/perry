
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-emitter-flags-r30/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100844814 <_js_json_parse>:
100844814:     	stp	x29, x30, [sp, #-0x10]!
100844818:     	mov	x29, sp
10084481c:     	cbz	x0, 0x100844874 <_js_json_parse+0x60>
100844820:     	ldr	w1, [x0, #0x4]
100844824:     	cmp	w1, #0x2
100844828:     	b.eq	0x100844838 <_js_json_parse+0x24>
10084482c:     	cbz	w1, 0x100844874 <_js_json_parse+0x60>
100844830:     	ldrb	w8, [x0, #0x14]
100844834:     	b	0x100844858 <_js_json_parse+0x44>
100844838:     	ldrb	w8, [x0, #0x14]
10084483c:     	cmp	w8, #0x7b
100844840:     	b.ne	0x100844858 <_js_json_parse+0x44>
100844844:     	ldrb	w8, [x0, #0x15]
100844848:     	cmp	w8, #0x7d
10084484c:     	b.ne	0x100844864 <_js_json_parse+0x50>
100844850:     	ldp	x29, x30, [sp], #0x10
100844854:     	b	0x1004ec900 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100844858:     	orr	w8, w8, #0x20
10084485c:     	cmp	w8, #0x7b
100844860:     	b.ne	0x10084486c <_js_json_parse+0x58>
100844864:     	ldp	x29, x30, [sp], #0x10
100844868:     	b	0x100505f48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
10084486c:     	ldp	x29, x30, [sp], #0x10
100844870:     	b	0x1005085c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100844874:     	adrp	x0, 0x100c75000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x6d5c>
100844878:     	add	x0, x0, #0x781
10084487c:     	mov	w1, #0x1c               ; =28
100844880:     	bl	0x1005089f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
