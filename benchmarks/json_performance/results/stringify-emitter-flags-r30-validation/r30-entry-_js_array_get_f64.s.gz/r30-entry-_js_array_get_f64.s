
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-emitter-flags-r30/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007be090 <_js_array_get_f64>:
1007be090:     	sub	sp, sp, #0x70
1007be094:     	stp	x26, x25, [sp, #0x20]
1007be098:     	stp	x24, x23, [sp, #0x30]
1007be09c:     	stp	x22, x21, [sp, #0x40]
1007be0a0:     	stp	x20, x19, [sp, #0x50]
1007be0a4:     	stp	x29, x30, [sp, #0x60]
1007be0a8:     	add	x29, sp, #0x60
1007be0ac:     	mov	x19, x1
1007be0b0:     	mov	x22, x0
1007be0b4:     	lsr	x25, x0, #51
1007be0b8:     	mov	x20, x0
1007be0bc:     	cmp	x25, #0xfff
1007be0c0:     	b.lo	0x1007be0dc <_js_array_get_f64+0x4c>
1007be0c4:     	mov	w8, #0x7ffc             ; =32764
1007be0c8:     	cmp	x8, x22, lsr #48
1007be0cc:     	b.ne	0x1007be0d8 <_js_array_get_f64+0x48>
1007be0d0:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007be0d4:     	b	0x1007be788 <_js_array_get_f64+0x6f8>
1007be0d8:     	and	x20, x22, #0xffffffffffff
1007be0dc:     	lsr	x8, x20, #3
1007be0e0:     	cmp	x8, #0x200
1007be0e4:     	b.ls	0x1007be11c <_js_array_get_f64+0x8c>
1007be0e8:     	ldurb	w8, [x20, #-0x8]
1007be0ec:     	cmp	w8, #0x9
1007be0f0:     	b.ne	0x1007be11c <_js_array_get_f64+0x8c>
1007be0f4:     	ldr	w8, [x20, #0x4]
1007be0f8:     	mov	w9, #0x5841             ; =22593
1007be0fc:     	movk	w9, #0x4c5a, lsl #16
1007be100:     	cmp	w8, w9
1007be104:     	b.ne	0x1007be11c <_js_array_get_f64+0x8c>
1007be108:     	mov	x0, x20
1007be10c:     	mov	x1, x19
1007be110:     	bl	0x1006880c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007be114:     	fmov	d0, x0
1007be118:     	b	0x1007be78c <_js_array_get_f64+0x6fc>
1007be11c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be120:     	b.lo	0x1007be1d0 <_js_array_get_f64+0x140>
1007be124:     	tst	x20, #0xffff800000000000
1007be128:     	mov	w8, #0x1000             ; =4096
1007be12c:     	ccmp	x20, x8, #0x0, eq
1007be130:     	b.lo	0x1007be1d0 <_js_array_get_f64+0x140>
1007be134:     	ldurb	w24, [x20, #-0x8]
1007be138:     	ldurh	w23, [x20, #-0x6]
1007be13c:     	cmp	w24, #0xa
1007be140:     	b.gt	0x1007be2e8 <_js_array_get_f64+0x258>
1007be144:     	cmp	w24, #0x2
1007be148:     	b.eq	0x1007be370 <_js_array_get_f64+0x2e0>
1007be14c:     	cmp	w24, #0x8
1007be150:     	b.ne	0x1007be1d8 <_js_array_get_f64+0x148>
1007be154:     	mov	x0, x20
1007be158:     	bl	0x1003051a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007be15c:     	cbz	w0, 0x1007be400 <_js_array_get_f64+0x370>
1007be160:     	mov	x22, #0x1               ; =1
1007be164:     	movk	x22, #0x7ffc, lsl #48
1007be168:     	lsr	x8, x20, #51
1007be16c:     	cmp	x8, #0xfff
1007be170:     	b.lo	0x1007be184 <_js_array_get_f64+0xf4>
1007be174:     	mov	w8, #0x7ffc             ; =32764
1007be178:     	cmp	x8, x20, lsr #48
1007be17c:     	b.eq	0x1007be788 <_js_array_get_f64+0x6f8>
1007be180:     	and	x20, x20, #0xffffffffffff
1007be184:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be188:     	b.lo	0x1007be1a8 <_js_array_get_f64+0x118>
1007be18c:     	tst	x20, #0xffff800000000000
1007be190:     	mov	w8, #0x1000             ; =4096
1007be194:     	ccmp	x20, x8, #0x0, eq
1007be198:     	b.lo	0x1007be1a8 <_js_array_get_f64+0x118>
1007be19c:     	ldurb	w8, [x20, #-0x8]
1007be1a0:     	cmp	w8, #0x2
1007be1a4:     	b.eq	0x1007bea74 <_js_array_get_f64+0x9e4>
1007be1a8:     	cbz	x20, 0x1007be788 <_js_array_get_f64+0x6f8>
1007be1ac:     	mov	x0, x20
1007be1b0:     	mov	x1, x19
1007be1b4:     	bl	0x100305358 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007be1b8:     	cmp	w0, #0x1
1007be1bc:     	b.ne	0x1007be788 <_js_array_get_f64+0x6f8>
1007be1c0:     	ldr	x8, [x20, #0x8]
1007be1c4:     	ubfiz	x9, x1, #4, #32
1007be1c8:     	ldr	x22, [x8, x9]
1007be1cc:     	b	0x1007be788 <_js_array_get_f64+0x6f8>
1007be1d0:     	mov	w23, #0x0               ; =0
1007be1d4:     	mov	w24, #0x0               ; =0
1007be1d8:     	mov	x21, x22
1007be1dc:     	cmp	x25, #0xfff
1007be1e0:     	b.lo	0x1007be1f8 <_js_array_get_f64+0x168>
1007be1e4:     	mov	w8, #0x7ffc             ; =32764
1007be1e8:     	cmp	x8, x22, lsr #48
1007be1ec:     	b.eq	0x1007be774 <_js_array_get_f64+0x6e4>
1007be1f0:     	ands	x21, x22, #0xffffffffffff
1007be1f4:     	b.eq	0x1007be774 <_js_array_get_f64+0x6e4>
1007be1f8:     	and	x8, x21, #0xfffffffffff00000
1007be1fc:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007be200:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007be204:     	cmp	x9, x10
1007be208:     	ccmp	x8, #0x0, #0x4, lo
1007be20c:     	b.eq	0x1007be774 <_js_array_get_f64+0x6e4>
1007be210:     	tst	x21, #0x3
1007be214:     	ccmp	x21, #0x7, #0x0, eq
1007be218:     	b.ls	0x1007be4c8 <_js_array_get_f64+0x438>
1007be21c:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be220:     	ldr	x8, [x8, #0x48]
1007be224:     	cmn	x8, #0x1
1007be228:     	b.eq	0x1007be418 <_js_array_get_f64+0x388>
1007be22c:     	mrs	x9, TPIDRRO_EL0
1007be230:     	and	x9, x9, #0xfffffffffffffff8
1007be234:     	ldr	x0, [x9, x8, lsl #3]
1007be238:     	cbz	x0, 0x1007be418 <_js_array_get_f64+0x388>
1007be23c:     	lsr	x1, x21, #20
1007be240:     	ldr	x8, [x0, #0x10]
1007be244:     	ldrb	w9, [x8]
1007be248:     	cmp	w9, #0x2
1007be24c:     	b.ne	0x1007be430 <_js_array_get_f64+0x3a0>
1007be250:     	ldrb	w9, [x8, #0x88]
1007be254:     	tbz	w9, #0x0, 0x1007be274 <_js_array_get_f64+0x1e4>
1007be258:     	ldr	x9, [x8, #0x80]
1007be25c:     	cmp	x9, x1
1007be260:     	b.ne	0x1007be274 <_js_array_get_f64+0x1e4>
1007be264:     	ldp	x9, x10, [x8, #0x60]
1007be268:     	cmp	x9, x21
1007be26c:     	ccmp	x10, x21, #0x0, ls
1007be270:     	b.hi	0x1007be410 <_js_array_get_f64+0x380>
1007be274:     	ldrb	w9, [x8, #0xb8]
1007be278:     	cbz	w9, 0x1007be298 <_js_array_get_f64+0x208>
1007be27c:     	ldr	x9, [x8, #0xb0]
1007be280:     	cmp	x9, x1
1007be284:     	b.ne	0x1007be298 <_js_array_get_f64+0x208>
1007be288:     	ldp	x9, x10, [x8, #0x90]
1007be28c:     	cmp	x9, x21
1007be290:     	ccmp	x10, x21, #0x0, ls
1007be294:     	b.hi	0x1007be8d8 <_js_array_get_f64+0x848>
1007be298:     	ldrb	w9, [x8, #0xe8]
1007be29c:     	cbz	w9, 0x1007be2bc <_js_array_get_f64+0x22c>
1007be2a0:     	ldr	x9, [x8, #0xe0]
1007be2a4:     	cmp	x9, x1
1007be2a8:     	b.ne	0x1007be2bc <_js_array_get_f64+0x22c>
1007be2ac:     	ldp	x9, x10, [x8, #0xc0]
1007be2b0:     	cmp	x9, x21
1007be2b4:     	ccmp	x10, x21, #0x0, ls
1007be2b8:     	b.hi	0x1007be9c0 <_js_array_get_f64+0x930>
1007be2bc:     	ldrb	w9, [x8, #0x118]
1007be2c0:     	cbz	w9, 0x1007be490 <_js_array_get_f64+0x400>
1007be2c4:     	ldr	x9, [x8, #0x110]
1007be2c8:     	cmp	x9, x1
1007be2cc:     	b.ne	0x1007be490 <_js_array_get_f64+0x400>
1007be2d0:     	ldp	x9, x10, [x8, #0xf0]
1007be2d4:     	cmp	x9, x21
1007be2d8:     	ccmp	x10, x21, #0x0, ls
1007be2dc:     	b.ls	0x1007be490 <_js_array_get_f64+0x400>
1007be2e0:     	add	x9, x8, #0xf0
1007be2e4:     	b	0x1007be9c4 <_js_array_get_f64+0x934>
1007be2e8:     	cmp	w24, #0xb
1007be2ec:     	b.eq	0x1007be388 <_js_array_get_f64+0x2f8>
1007be2f0:     	cmp	w24, #0xc
1007be2f4:     	b.ne	0x1007be1d8 <_js_array_get_f64+0x148>
1007be2f8:     	mov	x0, x20
1007be2fc:     	bl	0x10030af38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007be300:     	cbz	w0, 0x1007be408 <_js_array_get_f64+0x378>
1007be304:     	mov	x22, #0x1               ; =1
1007be308:     	movk	x22, #0x7ffc, lsl #48
1007be30c:     	lsr	x8, x20, #51
1007be310:     	cmp	x8, #0xfff
1007be314:     	b.lo	0x1007be328 <_js_array_get_f64+0x298>
1007be318:     	mov	w8, #0x7ffc             ; =32764
1007be31c:     	cmp	x8, x20, lsr #48
1007be320:     	b.eq	0x1007be788 <_js_array_get_f64+0x6f8>
1007be324:     	and	x20, x20, #0xffffffffffff
1007be328:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be32c:     	b.lo	0x1007be34c <_js_array_get_f64+0x2bc>
1007be330:     	tst	x20, #0xffff800000000000
1007be334:     	mov	w8, #0x1000             ; =4096
1007be338:     	ccmp	x20, x8, #0x0, eq
1007be33c:     	b.lo	0x1007be34c <_js_array_get_f64+0x2bc>
1007be340:     	ldurb	w8, [x20, #-0x8]
1007be344:     	cmp	w8, #0x2
1007be348:     	b.eq	0x1007bea8c <_js_array_get_f64+0x9fc>
1007be34c:     	cbz	x20, 0x1007be788 <_js_array_get_f64+0x6f8>
1007be350:     	mov	x0, x20
1007be354:     	mov	x1, x19
1007be358:     	bl	0x10030cbb0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007be35c:     	cmp	w0, #0x1
1007be360:     	b.ne	0x1007be788 <_js_array_get_f64+0x6f8>
1007be364:     	ldr	x8, [x20, #0x8]
1007be368:     	ldr	x22, [x8, w1, uxtw #3]
1007be36c:     	b	0x1007be788 <_js_array_get_f64+0x6f8>
1007be370:     	mov	x0, x22
1007be374:     	mov	x1, x19
1007be378:     	bl	0x1005487cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be37c:     	tbnz	w0, #0x0, 0x1007be784 <_js_array_get_f64+0x6f4>
1007be380:     	mov	w24, #0x2               ; =2
1007be384:     	b	0x1007be1d8 <_js_array_get_f64+0x148>
1007be388:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be38c:     	add	x8, x8, #0xec0
1007be390:     	ldaprb	w8, [x8]
1007be394:     	cbz	w8, 0x1007be3f8 <_js_array_get_f64+0x368>
1007be398:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be39c:     	add	x8, x8, #0x58
1007be3a0:     	ldapr	x8, [x8]
1007be3a4:     	cmp	x20, x8
1007be3a8:     	b.lo	0x1007be3f8 <_js_array_get_f64+0x368>
1007be3ac:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be3b0:     	add	x8, x8, #0x60
1007be3b4:     	ldapr	x8, [x8]
1007be3b8:     	cmp	x20, x8
1007be3bc:     	b.hi	0x1007be3f8 <_js_array_get_f64+0x368>
1007be3c0:     	mov	x0, x20
1007be3c4:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be3c8:     	tbz	w0, #0x0, 0x1007be3f8 <_js_array_get_f64+0x368>
1007be3cc:     	add	x0, sp, #0x8
1007be3d0:     	mov	x1, x20
1007be3d4:     	bl	0x1002a4aac <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007be3d8:     	ldr	x8, [sp, #0x8]
1007be3dc:     	cbz	x8, 0x1007bea04 <_js_array_get_f64+0x974>
1007be3e0:     	cmp	x8, #0x1
1007be3e4:     	b.ne	0x1007bea48 <_js_array_get_f64+0x9b8>
1007be3e8:     	ldr	d0, [sp, #0x10]
1007be3ec:     	scvtf	d1, w19
1007be3f0:     	bl	0x10081c634 <_js_dyn_index_get>
1007be3f4:     	b	0x1007be784 <_js_array_get_f64+0x6f4>
1007be3f8:     	mov	w24, #0xb               ; =11
1007be3fc:     	b	0x1007be1d8 <_js_array_get_f64+0x148>
1007be400:     	mov	w24, #0x8               ; =8
1007be404:     	b	0x1007be1d8 <_js_array_get_f64+0x148>
1007be408:     	mov	w24, #0xc               ; =12
1007be40c:     	b	0x1007be1d8 <_js_array_get_f64+0x148>
1007be410:     	add	x9, x8, #0x60
1007be414:     	b	0x1007be9c4 <_js_array_get_f64+0x934>
1007be418:     	bl	0x100b3f53c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007be41c:     	lsr	x1, x21, #20
1007be420:     	ldr	x8, [x0, #0x10]
1007be424:     	ldrb	w9, [x8]
1007be428:     	cmp	w9, #0x2
1007be42c:     	b.eq	0x1007be250 <_js_array_get_f64+0x1c0>
1007be430:     	ldr	x9, [x8, #0x8]
1007be434:     	ldr	x10, [x8, #0x28]
1007be438:     	sub	x9, x1, x9
1007be43c:     	cmp	x9, x10
1007be440:     	b.hs	0x1007be484 <_js_array_get_f64+0x3f4>
1007be444:     	ldr	x10, [x8, #0x20]
1007be448:     	mov	w11, #0x28              ; =40
1007be44c:     	madd	x9, x9, x11, x10
1007be450:     	ldr	x10, [x9]
1007be454:     	ldr	x11, [x8, #0x10]
1007be458:     	cmp	x10, x11
1007be45c:     	b.ne	0x1007be490 <_js_array_get_f64+0x400>
1007be460:     	ldp	x10, x11, [x9, #0x8]
1007be464:     	cmp	x10, x21
1007be468:     	ccmp	x11, x21, #0x0, ls
1007be46c:     	b.ls	0x1007be490 <_js_array_get_f64+0x400>
1007be470:     	ldr	x10, [x8, #0x30]
1007be474:     	add	x10, x10, #0x1
1007be478:     	str	x10, [x8, #0x30]
1007be47c:     	add	x8, x9, #0x21
1007be480:     	b	0x1007be9d4 <_js_array_get_f64+0x944>
1007be484:     	ldr	x9, [x8, #0x58]
1007be488:     	add	x9, x9, #0x1
1007be48c:     	str	x9, [x8, #0x58]
1007be490:     	ldr	x9, [x8, #0x38]
1007be494:     	add	x9, x9, #0x1
1007be498:     	str	x9, [x8, #0x38]
1007be49c:     	mov	x0, x21
1007be4a0:     	bl	0x10051e508 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007be4a4:     	and	w8, w0, #0xff
1007be4a8:     	cbz	w8, 0x1007be4c8 <_js_array_get_f64+0x438>
1007be4ac:     	ldurb	w8, [x21, #-0x8]
1007be4b0:     	ldurb	w9, [x21, #-0x7]
1007be4b4:     	mov	w10, #0x82              ; =130
1007be4b8:     	and	w9, w9, w10
1007be4bc:     	cmp	w9, #0x2
1007be4c0:     	ccmp	w8, #0x1, #0x0, eq
1007be4c4:     	b.eq	0x1007be598 <_js_array_get_f64+0x508>
1007be4c8:     	mov	x0, x21
1007be4cc:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be4d0:     	cbz	x0, 0x1007be4f8 <_js_array_get_f64+0x468>
1007be4d4:     	ldrb	w9, [x0]
1007be4d8:     	cmp	w9, #0x1
1007be4dc:     	b.ne	0x1007be514 <_js_array_get_f64+0x484>
1007be4e0:     	ldrsb	w8, [x0, #0x1]
1007be4e4:     	tbnz	w8, #0x1f, 0x1007be5c0 <_js_array_get_f64+0x530>
1007be4e8:     	ldp	w10, w9, [x21]
1007be4ec:     	cmp	w10, w9
1007be4f0:     	b.hi	0x1007be64c <_js_array_get_f64+0x5bc>
1007be4f4:     	b	0x1007be664 <_js_array_get_f64+0x5d4>
1007be4f8:     	mov	x25, x0
1007be4fc:     	mov	x0, x21
1007be500:     	bl	0x1005893b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be504:     	tbz	w0, #0x0, 0x1007be550 <_js_array_get_f64+0x4c0>
1007be508:     	mov	x0, #0x0                ; =0
1007be50c:     	mov	x8, x25
1007be510:     	b	0x1007be63c <_js_array_get_f64+0x5ac>
1007be514:     	mov	x8, x0
1007be518:     	cmp	w9, #0x1
1007be51c:     	b.eq	0x1007be63c <_js_array_get_f64+0x5ac>
1007be520:     	cmp	w9, #0x9
1007be524:     	b.ne	0x1007be774 <_js_array_get_f64+0x6e4>
1007be528:     	ldr	w8, [x21, #0x4]
1007be52c:     	mov	w9, #0x5841             ; =22593
1007be530:     	movk	w9, #0x4c5a, lsl #16
1007be534:     	cmp	w8, w9
1007be538:     	b.ne	0x1007be774 <_js_array_get_f64+0x6e4>
1007be53c:     	mov	x0, x21
1007be540:     	bl	0x100375e50 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007be544:     	cbz	x0, 0x1007be774 <_js_array_get_f64+0x6e4>
1007be548:     	mov	x21, x0
1007be54c:     	b	0x1007be680 <_js_array_get_f64+0x5f0>
1007be550:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be554:     	add	x8, x8, #0xec0
1007be558:     	ldaprb	w8, [x8]
1007be55c:     	cbz	w8, 0x1007be774 <_js_array_get_f64+0x6e4>
1007be560:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be564:     	add	x8, x8, #0x58
1007be568:     	ldapr	x8, [x8]
1007be56c:     	cmp	x8, x21
1007be570:     	b.hi	0x1007be774 <_js_array_get_f64+0x6e4>
1007be574:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be578:     	add	x8, x8, #0x60
1007be57c:     	ldapr	x8, [x8]
1007be580:     	cmp	x8, x21
1007be584:     	b.lo	0x1007be774 <_js_array_get_f64+0x6e4>
1007be588:     	mov	x0, x21
1007be58c:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be590:     	tbnz	w0, #0x0, 0x1007be508 <_js_array_get_f64+0x478>
1007be594:     	b	0x1007be774 <_js_array_get_f64+0x6e4>
1007be598:     	ldr	w8, [x21]
1007be59c:     	mov	w9, #0xe100             ; =57600
1007be5a0:     	movk	w9, #0x5f5, lsl #16
1007be5a4:     	orr	w9, w9, #0x1
1007be5a8:     	cmp	w8, w9
1007be5ac:     	b.hs	0x1007be4c8 <_js_array_get_f64+0x438>
1007be5b0:     	ldr	w9, [x21, #0x4]
1007be5b4:     	cmp	w8, w9
1007be5b8:     	b.ls	0x1007be680 <_js_array_get_f64+0x5f0>
1007be5bc:     	b	0x1007be4c8 <_js_array_get_f64+0x438>
1007be5c0:     	mov	x25, x0
1007be5c4:     	ldr	x21, [x0, #0x8]
1007be5c8:     	mov	x0, x21
1007be5cc:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be5d0:     	cbz	x0, 0x1007be774 <_js_array_get_f64+0x6e4>
1007be5d4:     	ldrb	w8, [x0]
1007be5d8:     	cmp	w8, #0x1
1007be5dc:     	b.ne	0x1007be774 <_js_array_get_f64+0x6e4>
1007be5e0:     	ldrsb	w8, [x0, #0x1]
1007be5e4:     	tbz	w8, #0x1f, 0x1007be4e8 <_js_array_get_f64+0x458>
1007be5e8:     	mov	w26, #0x1               ; =1
1007be5ec:     	ldr	x21, [x0, #0x8]
1007be5f0:     	mov	x0, x21
1007be5f4:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be5f8:     	cbz	x0, 0x1007be774 <_js_array_get_f64+0x6e4>
1007be5fc:     	ldrb	w8, [x0]
1007be600:     	cmp	w8, #0x1
1007be604:     	b.ne	0x1007be774 <_js_array_get_f64+0x6e4>
1007be608:     	cmp	w26, #0x3f
1007be60c:     	b.hi	0x1007be774 <_js_array_get_f64+0x6e4>
1007be610:     	add	w26, w26, #0x1
1007be614:     	ldrsb	w8, [x0, #0x1]
1007be618:     	tbnz	w8, #0x1f, 0x1007be5ec <_js_array_get_f64+0x55c>
1007be61c:     	str	x21, [x25, #0x8]
1007be620:     	ldrb	w8, [x25, #0x1]
1007be624:     	orr	w9, w8, #0x80
1007be628:     	mov	x8, x25
1007be62c:     	strb	w9, [x25, #0x1]
1007be630:     	ldrb	w9, [x0]
1007be634:     	cmp	w9, #0x1
1007be638:     	b.ne	0x1007be520 <_js_array_get_f64+0x490>
1007be63c:     	ldp	w10, w9, [x21]
1007be640:     	cmp	w10, w9
1007be644:     	b.ls	0x1007be664 <_js_array_get_f64+0x5d4>
1007be648:     	cbz	x8, 0x1007be674 <_js_array_get_f64+0x5e4>
1007be64c:     	ldr	w8, [x0, #0x4]
1007be650:     	ubfiz	x9, x9, #3, #32
1007be654:     	add	x9, x9, #0x10
1007be658:     	cmp	x9, x8
1007be65c:     	b.eq	0x1007be680 <_js_array_get_f64+0x5f0>
1007be660:     	b	0x1007be674 <_js_array_get_f64+0x5e4>
1007be664:     	mov	w8, #0xe100             ; =57600
1007be668:     	movk	w8, #0x5f5, lsl #16
1007be66c:     	cmp	w10, w8
1007be670:     	b.ls	0x1007be680 <_js_array_get_f64+0x5f0>
1007be674:     	mov	x0, x21
1007be678:     	bl	0x1005893b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be67c:     	tbz	w0, #0x0, 0x1007be730 <_js_array_get_f64+0x6a0>
1007be680:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be684:     	add	x8, x8, #0xec0
1007be688:     	ldaprb	w8, [x8]
1007be68c:     	cbz	w8, 0x1007be6d4 <_js_array_get_f64+0x644>
1007be690:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be694:     	add	x8, x8, #0x58
1007be698:     	ldapr	x8, [x8]
1007be69c:     	cmp	x21, x8
1007be6a0:     	b.lo	0x1007be6d4 <_js_array_get_f64+0x644>
1007be6a4:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be6a8:     	add	x8, x8, #0x60
1007be6ac:     	ldapr	x8, [x8]
1007be6b0:     	cmp	x21, x8
1007be6b4:     	b.hi	0x1007be6d4 <_js_array_get_f64+0x644>
1007be6b8:     	mov	x0, x21
1007be6bc:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be6c0:     	tbz	w0, #0x0, 0x1007be6d4 <_js_array_get_f64+0x644>
1007be6c4:     	mov	x0, x21
1007be6c8:     	mov	x1, x19
1007be6cc:     	bl	0x1008fc348 <_js_typed_array_get>
1007be6d0:     	b	0x1007be784 <_js_array_get_f64+0x6f4>
1007be6d4:     	mov	x0, x21
1007be6d8:     	bl	0x1005893b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be6dc:     	tbz	w0, #0x0, 0x1007be704 <_js_array_get_f64+0x674>
1007be6e0:     	mov	x0, x21
1007be6e4:     	mov	x1, x19
1007be6e8:     	bl	0x1005866dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007be6ec:     	and	w8, w1, #0xff
1007be6f0:     	ucvtf	d0, w8
1007be6f4:     	fmov	x8, d0
1007be6f8:     	tst	w0, #0x1
1007be6fc:     	csel	x22, x8, xzr, ne
1007be700:     	b	0x1007be788 <_js_array_get_f64+0x6f8>
1007be704:     	cmp	x21, x20
1007be708:     	b.eq	0x1007be7b0 <_js_array_get_f64+0x720>
1007be70c:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007be710:     	b.lo	0x1007be7a8 <_js_array_get_f64+0x718>
1007be714:     	tst	x21, #0xffff800000000000
1007be718:     	mov	w8, #0x1000             ; =4096
1007be71c:     	ccmp	x21, x8, #0x0, eq
1007be720:     	b.lo	0x1007be7a8 <_js_array_get_f64+0x718>
1007be724:     	ldurb	w24, [x21, #-0x8]
1007be728:     	ldurh	w23, [x21, #-0x6]
1007be72c:     	b	0x1007be7b0 <_js_array_get_f64+0x720>
1007be730:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be734:     	add	x8, x8, #0xec0
1007be738:     	ldaprb	w8, [x8]
1007be73c:     	cbz	w8, 0x1007be774 <_js_array_get_f64+0x6e4>
1007be740:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be744:     	add	x8, x8, #0x58
1007be748:     	ldapr	x8, [x8]
1007be74c:     	cmp	x21, x8
1007be750:     	b.lo	0x1007be774 <_js_array_get_f64+0x6e4>
1007be754:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1007be758:     	add	x8, x8, #0x60
1007be75c:     	ldapr	x8, [x8]
1007be760:     	cmp	x21, x8
1007be764:     	b.hi	0x1007be774 <_js_array_get_f64+0x6e4>
1007be768:     	mov	x0, x21
1007be76c:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be770:     	tbnz	w0, #0x0, 0x1007be680 <_js_array_get_f64+0x5f0>
1007be774:     	mov	x0, x22
1007be778:     	mov	x1, x19
1007be77c:     	bl	0x1005487cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be780:     	tbz	w0, #0x0, 0x1007bea58 <_js_array_get_f64+0x9c8>
1007be784:     	fmov	x22, d0
1007be788:     	fmov	d0, x22
1007be78c:     	ldp	x29, x30, [sp, #0x60]
1007be790:     	ldp	x20, x19, [sp, #0x50]
1007be794:     	ldp	x22, x21, [sp, #0x40]
1007be798:     	ldp	x24, x23, [sp, #0x30]
1007be79c:     	ldp	x26, x25, [sp, #0x20]
1007be7a0:     	add	sp, sp, #0x70
1007be7a4:     	ret
1007be7a8:     	mov	w23, #0x0               ; =0
1007be7ac:     	mov	w24, #0x0               ; =0
1007be7b0:     	cmp	w24, #0x1
1007be7b4:     	b.ne	0x1007be968 <_js_array_get_f64+0x8d8>
1007be7b8:     	tbz	w23, #0xa, 0x1007be968 <_js_array_get_f64+0x8d8>
1007be7bc:     	adrp	x8, 0x100b64000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data14case_ignorable7OFFSETS+0xbc>
1007be7c0:     	add	x8, x8, #0xf8c
1007be7c4:     	cmp	w19, #0x3e8
1007be7c8:     	b.lo	0x1007be840 <_js_array_get_f64+0x7b0>
1007be7cc:     	mov	x9, #0x0                ; =0
1007be7d0:     	mov	w11, #0x1759            ; =5977
1007be7d4:     	movk	w11, #0xd1b7, lsl #16
1007be7d8:     	mov	w12, #0x2710            ; =10000
1007be7dc:     	mov	w13, #0x147b            ; =5243
1007be7e0:     	mov	w14, #0x64              ; =100
1007be7e4:     	add	x15, sp, #0x8
1007be7e8:     	mov	w16, #0x967f            ; =38527
1007be7ec:     	movk	w16, #0x98, lsl #16
1007be7f0:     	mov	x10, x19
1007be7f4:     	mov	x17, x10
1007be7f8:     	umull	x10, w10, w11
1007be7fc:     	lsr	x10, x10, #45
1007be800:     	msub	w0, w10, w12, w17
1007be804:     	ubfx	w1, w0, #2, #14
1007be808:     	mul	w1, w1, w13
1007be80c:     	lsr	w1, w1, #17
1007be810:     	msub	w0, w1, w14, w0
1007be814:     	add	x2, x15, x9
1007be818:     	ldrh	w1, [x8, w1, uxtw #1]
1007be81c:     	strh	w1, [x2, #0x6]
1007be820:     	and	x0, x0, #0xffff
1007be824:     	ldrh	w0, [x8, x0, lsl #1]
1007be828:     	strh	w0, [x2, #0x8]
1007be82c:     	sub	x9, x9, #0x4
1007be830:     	cmp	w17, w16
1007be834:     	b.hi	0x1007be7f4 <_js_array_get_f64+0x764>
1007be838:     	add	x9, x9, #0xa
1007be83c:     	b	0x1007be848 <_js_array_get_f64+0x7b8>
1007be840:     	mov	w9, #0xa                ; =10
1007be844:     	mov	x10, x19
1007be848:     	cmp	w10, #0x9
1007be84c:     	b.ls	0x1007be880 <_js_array_get_f64+0x7f0>
1007be850:     	sub	x9, x9, #0x2
1007be854:     	ubfx	w11, w10, #2, #14
1007be858:     	mov	w12, #0x147b            ; =5243
1007be85c:     	mul	w11, w11, w12
1007be860:     	lsr	w11, w11, #17
1007be864:     	mov	w12, #0x64              ; =100
1007be868:     	msub	w10, w11, w12, w10
1007be86c:     	and	x10, x10, #0xffff
1007be870:     	ldrh	w10, [x8, x10, lsl #1]
1007be874:     	add	x12, sp, #0x8
1007be878:     	strh	w10, [x12, x9]
1007be87c:     	mov	x10, x11
1007be880:     	cbz	w19, 0x1007be8b8 <_js_array_get_f64+0x828>
1007be884:     	cbnz	w10, 0x1007be8b8 <_js_array_get_f64+0x828>
1007be888:     	cmp	x9, #0xa
1007be88c:     	b.ne	0x1007be8e0 <_js_array_get_f64+0x850>
1007be890:     	mov	w23, #0x1               ; =1
1007be894:     	add	x0, sp, #0x8
1007be898:     	mov	x1, x21
1007be89c:     	mov	w2, #0x1                ; =1
1007be8a0:     	mov	x3, #0x0                ; =0
1007be8a4:     	bl	0x1005b2abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007be8a8:     	ldr	x8, [sp, #0x8]
1007be8ac:     	mov	w20, #0x1               ; =1
1007be8b0:     	cbnz	x8, 0x1007be930 <_js_array_get_f64+0x8a0>
1007be8b4:     	b	0x1007be968 <_js_array_get_f64+0x8d8>
1007be8b8:     	sub	x23, x9, #0x1
1007be8bc:     	ubfiz	w10, w10, #1, #4
1007be8c0:     	add	x8, x8, x10
1007be8c4:     	ldrb	w8, [x8, #0x1]
1007be8c8:     	add	x10, sp, #0x8
1007be8cc:     	strb	w8, [x10, x23]
1007be8d0:     	mov	w8, #0xb                ; =11
1007be8d4:     	b	0x1007be8e8 <_js_array_get_f64+0x858>
1007be8d8:     	add	x9, x8, #0x90
1007be8dc:     	b	0x1007be9c4 <_js_array_get_f64+0x934>
1007be8e0:     	mov	w8, #0xa                ; =10
1007be8e4:     	mov	x23, x9
1007be8e8:     	sub	x22, x8, x9
1007be8ec:     	mov	x0, x22
1007be8f0:     	mov	w1, #0x1                ; =1
1007be8f4:     	bl	0x100b5f3c8 <_mi_malloc_aligned>
1007be8f8:     	cbz	x0, 0x1007beaa4 <_js_array_get_f64+0xa14>
1007be8fc:     	mov	x20, x0
1007be900:     	add	x8, sp, #0x8
1007be904:     	add	x1, x8, x23
1007be908:     	mov	x2, x22
1007be90c:     	bl	0x100b61fec <_writev+0x100b61fec>
1007be910:     	add	x0, sp, #0x8
1007be914:     	mov	x1, x21
1007be918:     	mov	x2, x20
1007be91c:     	mov	x3, x22
1007be920:     	bl	0x1005b2abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007be924:     	ldr	w8, [sp, #0x8]
1007be928:     	tbz	w8, #0x0, 0x1007be960 <_js_array_get_f64+0x8d0>
1007be92c:     	mov	w23, #0x0               ; =0
1007be930:     	mov	x22, #0x1               ; =1
1007be934:     	movk	x22, #0x7ffc, lsl #48
1007be938:     	ldr	x0, [sp, #0x10]
1007be93c:     	cbz	x0, 0x1007be9f4 <_js_array_get_f64+0x964>
1007be940:     	cbz	x21, 0x1007be9e4 <_js_array_get_f64+0x954>
1007be944:     	lsr	x8, x21, #52
1007be948:     	cmp	x8, #0x7fe
1007be94c:     	b.hi	0x1007be9e8 <_js_array_get_f64+0x958>
1007be950:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007be954:     	bfxil	x8, x21, #0, #48
1007be958:     	mov	x21, x8
1007be95c:     	b	0x1007be9e8 <_js_array_get_f64+0x958>
1007be960:     	mov	x0, x20
1007be964:     	bl	0x100b5f140 <_mi_free>
1007be968:     	ldr	w8, [x21]
1007be96c:     	cmp	w19, w8
1007be970:     	b.hs	0x1007be9b0 <_js_array_get_f64+0x920>
1007be974:     	ldr	w8, [x21, #0x4]
1007be978:     	cmp	w19, w8
1007be97c:     	b.hs	0x1007be9a0 <_js_array_get_f64+0x910>
1007be980:     	add	x8, x21, w19, uxtw #3
1007be984:     	ldr	x22, [x8, #0x8]
1007be988:     	mov	x8, #0x1                ; =1
1007be98c:     	movk	x8, #0x7ffc, lsl #48
1007be990:     	add	x8, x8, #0xf
1007be994:     	cmp	x22, x8
1007be998:     	b.ne	0x1007be788 <_js_array_get_f64+0x6f8>
1007be99c:     	b	0x1007be9b0 <_js_array_get_f64+0x920>
1007be9a0:     	mov	x0, x21
1007be9a4:     	mov	x1, x19
1007be9a8:     	bl	0x10052abc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007be9ac:     	tbnz	w0, #0x0, 0x1007be784 <_js_array_get_f64+0x6f4>
1007be9b0:     	mov	x0, x21
1007be9b4:     	mov	x1, x19
1007be9b8:     	bl	0x1006c74d8 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007be9bc:     	b	0x1007be784 <_js_array_get_f64+0x6f4>
1007be9c0:     	add	x9, x8, #0xc0
1007be9c4:     	ldr	x10, [x8, #0x30]
1007be9c8:     	add	x10, x10, #0x1
1007be9cc:     	str	x10, [x8, #0x30]
1007be9d0:     	add	x8, x9, #0x19
1007be9d4:     	ldrb	w8, [x8]
1007be9d8:     	cmp	w8, #0xff
1007be9dc:     	b.ne	0x1007be4a8 <_js_array_get_f64+0x418>
1007be9e0:     	b	0x1007be49c <_js_array_get_f64+0x40c>
1007be9e4:     	add	x21, x22, #0x1
1007be9e8:     	fmov	d0, x21
1007be9ec:     	bl	0x1006fd2fc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007be9f0:     	mov	x22, x0
1007be9f4:     	tbnz	w23, #0x0, 0x1007be788 <_js_array_get_f64+0x6f8>
1007be9f8:     	mov	x0, x20
1007be9fc:     	bl	0x100b5f140 <_mi_free>
1007bea00:     	b	0x1007be788 <_js_array_get_f64+0x6f8>
1007bea04:     	ldr	x20, [sp, #0x10]
1007bea08:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bea0c:     	ldr	x8, [x8, #0xed8]
1007bea10:     	cbz	x8, 0x1007bea28 <_js_array_get_f64+0x998>
1007bea14:     	mov	x0, x20
1007bea18:     	bl	0x10013cd40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007bea1c:     	tbz	w0, #0x0, 0x1007bea28 <_js_array_get_f64+0x998>
1007bea20:     	mov	x0, x20
1007bea24:     	bl	0x1002bee80 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007bea28:     	tbnz	w19, #0x1f, 0x1007bea48 <_js_array_get_f64+0x9b8>
1007bea2c:     	ldr	w8, [x20]
1007bea30:     	cmp	w19, w8
1007bea34:     	b.hs	0x1007bea48 <_js_array_get_f64+0x9b8>
1007bea38:     	mov	w1, w19
1007bea3c:     	mov	x0, x20
1007bea40:     	bl	0x1002a510c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007bea44:     	b	0x1007be784 <_js_array_get_f64+0x6f4>
1007bea48:     	mov	x8, #0x1                ; =1
1007bea4c:     	movk	x8, #0x7ffc, lsl #48
1007bea50:     	mov	x22, x8
1007bea54:     	b	0x1007be788 <_js_array_get_f64+0x6f8>
1007bea58:     	mov	x0, x22
1007bea5c:     	bl	0x100b47ab0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007bea60:     	cmp	x0, #0x1
1007bea64:     	b.ne	0x1007be0d0 <_js_array_get_f64+0x40>
1007bea68:     	mov	x0, x19
1007bea6c:     	bl	0x100b47ad0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007bea70:     	b	0x1007be784 <_js_array_get_f64+0x6f4>
1007bea74:     	mov	x0, x20
1007bea78:     	mov	w1, #0x0                ; =0
1007bea7c:     	bl	0x100b4a040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bea80:     	mov	x20, x0
1007bea84:     	cbnz	x0, 0x1007be1ac <_js_array_get_f64+0x11c>
1007bea88:     	b	0x1007be788 <_js_array_get_f64+0x6f8>
1007bea8c:     	mov	x0, x20
1007bea90:     	mov	w1, #0x1                ; =1
1007bea94:     	bl	0x100b4a040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bea98:     	mov	x20, x0
1007bea9c:     	cbnz	x0, 0x1007be350 <_js_array_get_f64+0x2c0>
1007beaa0:     	b	0x1007be788 <_js_array_get_f64+0x6f8>
1007beaa4:     	mov	w0, #0x1                ; =1
1007beaa8:     	mov	x1, x22
1007beaac:     	bl	0x100b124c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
