
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-emitter-flags-r30/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010084552c <_js_json_stringify>:
10084552c:     	sub	sp, sp, #0x80
100845530:     	stp	d9, d8, [sp, #0x20]
100845534:     	stp	x26, x25, [sp, #0x30]
100845538:     	stp	x24, x23, [sp, #0x40]
10084553c:     	stp	x22, x21, [sp, #0x50]
100845540:     	stp	x20, x19, [sp, #0x60]
100845544:     	stp	x29, x30, [sp, #0x70]
100845548:     	add	x29, sp, #0x70
10084554c:     	mov	x21, x0
100845550:     	mov.16b	v8, v0
100845554:     	fmov	x19, d8
100845558:     	and	x20, x19, #0xffff000000000000
10084555c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100845560:     	cmp	x20, x8
100845564:     	b.ne	0x10084558c <_js_json_stringify+0x60>
100845568:     	and	x0, x19, #0xffffffffffff
10084556c:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
100845570:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100845574:     	movk	x9, #0xffef, lsl #16
100845578:     	cmp	x8, x9
10084557c:     	b.hi	0x10084558c <_js_json_stringify+0x60>
100845580:     	ldr	w8, [x0, #0x4]
100845584:     	cmp	w8, #0x40
100845588:     	b.hs	0x1008455fc <_js_json_stringify+0xd0>
10084558c:     	mov.16b	v0, v8
100845590:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100845594:     	tbz	w0, #0x0, 0x1008455a0 <_js_json_stringify+0x74>
100845598:     	mov	x23, x1
10084559c:     	b	0x100845b10 <_js_json_stringify+0x5e4>
1008455a0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008455a4:     	cmp	x20, x8
1008455a8:     	b.ne	0x100845610 <_js_json_stringify+0xe4>
1008455ac:     	ands	x19, x19, #0xffffffffffff
1008455b0:     	b.eq	0x100845610 <_js_json_stringify+0xe4>
1008455b4:     	mov	x0, x19
1008455b8:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008455bc:     	cbz	w0, 0x100845610 <_js_json_stringify+0xe4>
1008455c0:     	ldurb	w8, [x19, #-0x8]
1008455c4:     	cmp	w8, #0x9
1008455c8:     	b.ne	0x100845610 <_js_json_stringify+0xe4>
1008455cc:     	ldr	w8, [x19, #0x4]
1008455d0:     	mov	w9, #0x5841             ; =22593
1008455d4:     	movk	w9, #0x4c5a, lsl #16
1008455d8:     	cmp	w8, w9
1008455dc:     	b.ne	0x100845610 <_js_json_stringify+0xe4>
1008455e0:     	mov	x0, x19
1008455e4:     	bl	0x100688524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1008455e8:     	cbz	x0, 0x100845610 <_js_json_stringify+0xe4>
1008455ec:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008455f0:     	bfxil	x8, x0, #0, #48
1008455f4:     	fmov	d8, x8
1008455f8:     	b	0x100845610 <_js_json_stringify+0xe4>
1008455fc:     	bl	0x1004f2ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100845600:     	tbnz	w0, #0x0, 0x100845598 <_js_json_stringify+0x6c>
100845604:     	mov.16b	v0, v8
100845608:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084560c:     	tbnz	w0, #0x0, 0x100845598 <_js_json_stringify+0x6c>
100845610:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845614:     	add	x0, x0, #0xd78
100845618:     	ldr	x8, [x0]
10084561c:     	blr	x8
100845620:     	mov	x19, x0
100845624:     	ldr	w26, [x0]
100845628:     	add	w8, w26, #0x1
10084562c:     	str	w8, [x0]
100845630:     	cbz	w26, 0x1008456a0 <_js_json_stringify+0x174>
100845634:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845638:     	add	x0, x0, #0xd00
10084563c:     	ldr	x8, [x0]
100845640:     	blr	x8
100845644:     	ldrb	w8, [x0, #0x20]
100845648:     	cmp	w8, #0x1
10084564c:     	b.ne	0x100845c04 <_js_json_stringify+0x6d8>
100845650:     	ldr	x8, [x0]
100845654:     	cbnz	x8, 0x100845c10 <_js_json_stringify+0x6e4>
100845658:     	mov	x8, #-0x1               ; =-1
10084565c:     	str	x8, [x0]
100845660:     	ldr	x20, [x0, #0x18]
100845664:     	ldr	x8, [x0, #0x8]
100845668:     	cmp	x20, x8
10084566c:     	b.eq	0x100845b34 <_js_json_stringify+0x608>
100845670:     	ldr	x8, [x0, #0x10]
100845674:     	mov	w9, #0x18               ; =24
100845678:     	madd	x8, x20, x9, x8
10084567c:     	mov	w9, #0x8                ; =8
100845680:     	stp	xzr, x9, [x8]
100845684:     	str	xzr, [x8, #0x10]
100845688:     	add	x8, x20, #0x1
10084568c:     	str	x8, [x0, #0x18]
100845690:     	ldr	x8, [x0]
100845694:     	add	x8, x8, #0x1
100845698:     	str	x8, [x0]
10084569c:     	b	0x10084572c <_js_json_stringify+0x200>
1008456a0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008456a4:     	add	x0, x0, #0xdc0
1008456a8:     	ldr	x8, [x0]
1008456ac:     	blr	x8
1008456b0:     	strb	wzr, [x0]
1008456b4:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008456b8:     	add	x0, x0, #0xdf0
1008456bc:     	ldr	x8, [x0]
1008456c0:     	blr	x8
1008456c4:     	strb	wzr, [x0]
1008456c8:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1008456cc:     	ldr	w20, [x8, #0x5a8]
1008456d0:     	cmp	w20, #0x300
1008456d4:     	b.hs	0x100845b90 <_js_json_stringify+0x664>
1008456d8:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1008456dc:     	ldr	x8, [x8, #0x48]
1008456e0:     	cmn	x8, #0x1
1008456e4:     	b.eq	0x100845b80 <_js_json_stringify+0x654>
1008456e8:     	mrs	x9, TPIDRRO_EL0
1008456ec:     	and	x9, x9, #0xfffffffffffffff8
1008456f0:     	ldr	x0, [x9, x8, lsl #3]
1008456f4:     	cbz	x0, 0x100845b80 <_js_json_stringify+0x654>
1008456f8:     	add	x8, x0, x20, lsl #3
1008456fc:     	ldr	x0, [x8, #0x1e8]
100845700:     	cbz	x0, 0x100845b90 <_js_json_stringify+0x664>
100845704:     	str	xzr, [x0]
100845708:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084570c:     	add	x0, x0, #0xd90
100845710:     	ldr	x8, [x0]
100845714:     	blr	x8
100845718:     	ldrb	w8, [x0, #0x20]
10084571c:     	cbnz	w8, 0x100845c1c <_js_json_stringify+0x6f0>
100845720:     	ldr	x8, [x0]
100845724:     	cbnz	x8, 0x100845c44 <_js_json_stringify+0x718>
100845728:     	str	xzr, [x0, #0x18]
10084572c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100845730:     	add	x0, x0, #0xd30
100845734:     	ldr	x8, [x0]
100845738:     	blr	x8
10084573c:     	mov	x20, x0
100845740:     	ldrb	w8, [x0, #0x18]
100845744:     	cmp	w8, #0x1
100845748:     	b.ne	0x100845ba0 <_js_json_stringify+0x674>
10084574c:     	ldr	x8, [x0]
100845750:     	mov	x9, #-0x1               ; =-1
100845754:     	str	x9, [x0]
100845758:     	cmn	x8, #0x2
10084575c:     	b.eq	0x100845c50 <_js_json_stringify+0x724>
100845760:     	cmn	x8, #0x1
100845764:     	b.eq	0x100845778 <_js_json_stringify+0x24c>
100845768:     	add	x9, sp, #0x8
10084576c:     	ldur	q0, [x0, #0x8]
100845770:     	stur	q0, [x9, #0x8]
100845774:     	b	0x100845784 <_js_json_stringify+0x258>
100845778:     	mov	x8, #0x0                ; =0
10084577c:     	mov	w9, #0x1                ; =1
100845780:     	stp	x9, xzr, [sp, #0x10]
100845784:     	str	x8, [sp, #0x8]
100845788:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084578c:     	add	x0, x0, #0xd18
100845790:     	ldr	x8, [x0]
100845794:     	blr	x8
100845798:     	ldrb	w8, [x0, #0x20]
10084579c:     	cbnz	w8, 0x100845bd0 <_js_json_stringify+0x6a4>
1008457a0:     	ldr	x8, [x0]
1008457a4:     	cbnz	x8, 0x100845bf8 <_js_json_stringify+0x6cc>
1008457a8:     	str	xzr, [x0, #0x18]
1008457ac:     	add	x1, sp, #0x8
1008457b0:     	mov.16b	v0, v8
1008457b4:     	mov	x0, x21
1008457b8:     	bl	0x10050973c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
1008457bc:     	ldp	x21, x22, [sp, #0x10]
1008457c0:     	cmp	w22, #0x80, lsl #12     ; =0x80000
1008457c4:     	b.hs	0x100845884 <_js_json_stringify+0x358>
1008457c8:     	cmp	x22, #0x40
1008457cc:     	b.hs	0x100845948 <_js_json_stringify+0x41c>
1008457d0:     	ands	x9, x22, #0x38
1008457d4:     	b.eq	0x1008457f8 <_js_json_stringify+0x2cc>
1008457d8:     	and	x8, x22, #0x38
1008457dc:     	neg	x8, x8
1008457e0:     	mov	x10, x21
1008457e4:     	ldr	x11, [x10], #0x8
1008457e8:     	tst	x11, #0x8080808080808080
1008457ec:     	b.ne	0x10084586c <_js_json_stringify+0x340>
1008457f0:     	adds	x8, x8, #0x8
1008457f4:     	b.ne	0x1008457e4 <_js_json_stringify+0x2b8>
1008457f8:     	and	x8, x22, #0x7
1008457fc:     	cbz	x8, 0x1008459cc <_js_json_stringify+0x4a0>
100845800:     	add	x9, x21, x9
100845804:     	ldrsb	w10, [x9]
100845808:     	tbnz	w10, #0x1f, 0x10084586c <_js_json_stringify+0x340>
10084580c:     	cmp	x8, #0x1
100845810:     	b.eq	0x1008459cc <_js_json_stringify+0x4a0>
100845814:     	ldrsb	w10, [x9, #0x1]
100845818:     	tbnz	w10, #0x1f, 0x10084586c <_js_json_stringify+0x340>
10084581c:     	cmp	x8, #0x2
100845820:     	b.eq	0x1008459cc <_js_json_stringify+0x4a0>
100845824:     	ldrsb	w10, [x9, #0x2]
100845828:     	tbnz	w10, #0x1f, 0x10084586c <_js_json_stringify+0x340>
10084582c:     	cmp	x8, #0x3
100845830:     	b.eq	0x1008459cc <_js_json_stringify+0x4a0>
100845834:     	ldrsb	w10, [x9, #0x3]
100845838:     	tbnz	w10, #0x1f, 0x10084586c <_js_json_stringify+0x340>
10084583c:     	cmp	x8, #0x4
100845840:     	b.eq	0x1008459cc <_js_json_stringify+0x4a0>
100845844:     	ldrsb	w10, [x9, #0x4]
100845848:     	tbnz	w10, #0x1f, 0x10084586c <_js_json_stringify+0x340>
10084584c:     	cmp	x8, #0x5
100845850:     	b.eq	0x1008459cc <_js_json_stringify+0x4a0>
100845854:     	ldrsb	w10, [x9, #0x5]
100845858:     	tbnz	w10, #0x1f, 0x10084586c <_js_json_stringify+0x340>
10084585c:     	cmp	x8, #0x6
100845860:     	b.eq	0x1008459cc <_js_json_stringify+0x4a0>
100845864:     	ldrsb	w8, [x9, #0x6]
100845868:     	tbz	w8, #0x1f, 0x1008459cc <_js_json_stringify+0x4a0>
10084586c:     	mov	x0, x21
100845870:     	mov	x1, x22
100845874:     	mov	x2, x22
100845878:     	bl	0x1008dcf00 <_js_string_from_bytes_with_capacity>
10084587c:     	mov	x23, x0
100845880:     	b	0x100845ac8 <_js_json_stringify+0x59c>
100845884:     	and	x8, x22, #0x7fffffffffffffc0
100845888:     	add	x8, x21, x8
10084588c:     	mov	x9, x21
100845890:     	ldp	q0, q1, [x9]
100845894:     	ldp	q2, q3, [x9, #0x20]
100845898:     	orr.16b	v0, v1, v0
10084589c:     	orr.16b	v1, v2, v3
1008458a0:     	orr.16b	v0, v0, v1
1008458a4:     	umaxv.16b	b0, v0
1008458a8:     	fmov	w10, s0
1008458ac:     	tbnz	w10, #0x7, 0x10084590c <_js_json_stringify+0x3e0>
1008458b0:     	add	x9, x9, #0x40
1008458b4:     	cmp	x9, x8
1008458b8:     	b.ne	0x100845890 <_js_json_stringify+0x364>
1008458bc:     	ands	x9, x22, #0x30
1008458c0:     	b.eq	0x1008458e4 <_js_json_stringify+0x3b8>
1008458c4:     	mov	x10, x9
1008458c8:     	mov	x11, x8
1008458cc:     	ldr	q0, [x11], #0x10
1008458d0:     	umaxv.16b	b0, v0
1008458d4:     	fmov	w12, s0
1008458d8:     	tbnz	w12, #0x7, 0x10084590c <_js_json_stringify+0x3e0>
1008458dc:     	subs	x10, x10, #0x10
1008458e0:     	b.ne	0x1008458cc <_js_json_stringify+0x3a0>
1008458e4:     	and	x10, x22, #0xf
1008458e8:     	cbz	x10, 0x100845904 <_js_json_stringify+0x3d8>
1008458ec:     	add	x8, x8, x9
1008458f0:     	ldrsb	w9, [x8]
1008458f4:     	tbnz	w9, #0x1f, 0x10084590c <_js_json_stringify+0x3e0>
1008458f8:     	add	x8, x8, #0x1
1008458fc:     	subs	x10, x10, #0x1
100845900:     	b.ne	0x1008458f0 <_js_json_stringify+0x3c4>
100845904:     	mov	w24, w22
100845908:     	b	0x100845940 <_js_json_stringify+0x414>
10084590c:     	mov	w24, w22
100845910:     	cbz	x24, 0x100845940 <_js_json_stringify+0x414>
100845914:     	mov	x8, x21
100845918:     	ands	x9, x22, #0x3
10084591c:     	b.eq	0x100845938 <_js_json_stringify+0x40c>
100845920:     	mov	x8, x21
100845924:     	ldrsb	w10, [x8]
100845928:     	tbnz	w10, #0x1f, 0x100845a30 <_js_json_stringify+0x504>
10084592c:     	add	x8, x8, #0x1
100845930:     	subs	x9, x9, #0x1
100845934:     	b.ne	0x100845924 <_js_json_stringify+0x3f8>
100845938:     	cmp	x24, #0x4
10084593c:     	b.hs	0x1008459fc <_js_json_stringify+0x4d0>
100845940:     	mov	x25, x22
100845944:     	b	0x100845a40 <_js_json_stringify+0x514>
100845948:     	and	x8, x22, #0x7fffffffffffffc0
10084594c:     	and	x8, x8, #0xffffffff0007ffff
100845950:     	add	x8, x21, x8
100845954:     	mov	x9, x21
100845958:     	ldp	q0, q1, [x9]
10084595c:     	ldp	q2, q3, [x9, #0x20]
100845960:     	orr.16b	v0, v1, v0
100845964:     	orr.16b	v1, v2, v3
100845968:     	orr.16b	v0, v0, v1
10084596c:     	umaxv.16b	b0, v0
100845970:     	fmov	w10, s0
100845974:     	tbnz	w10, #0x7, 0x10084586c <_js_json_stringify+0x340>
100845978:     	add	x9, x9, #0x40
10084597c:     	cmp	x9, x8
100845980:     	b.ne	0x100845958 <_js_json_stringify+0x42c>
100845984:     	ands	x9, x22, #0x30
100845988:     	b.eq	0x1008459ac <_js_json_stringify+0x480>
10084598c:     	mov	x10, x9
100845990:     	mov	x11, x8
100845994:     	ldr	q0, [x11], #0x10
100845998:     	umaxv.16b	b0, v0
10084599c:     	fmov	w12, s0
1008459a0:     	tbnz	w12, #0x7, 0x10084586c <_js_json_stringify+0x340>
1008459a4:     	subs	x10, x10, #0x10
1008459a8:     	b.ne	0x100845994 <_js_json_stringify+0x468>
1008459ac:     	and	x10, x22, #0xf
1008459b0:     	cbz	x10, 0x1008459cc <_js_json_stringify+0x4a0>
1008459b4:     	add	x8, x8, x9
1008459b8:     	ldrsb	w9, [x8]
1008459bc:     	tbnz	w9, #0x1f, 0x10084586c <_js_json_stringify+0x340>
1008459c0:     	add	x8, x8, #0x1
1008459c4:     	subs	x10, x10, #0x1
1008459c8:     	b.ne	0x1008459b8 <_js_json_stringify+0x48c>
1008459cc:     	mov	x0, x22
1008459d0:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1008459d4:     	mov	x23, x0
1008459d8:     	stp	w22, w22, [x0]
1008459dc:     	stp	wzr, wzr, [x0, #0xc]
1008459e0:     	str	w22, [x0, #0x8]
1008459e4:     	cbz	w22, 0x100845ac8 <_js_json_stringify+0x59c>
1008459e8:     	and	x2, x22, #0x7ffff
1008459ec:     	mov	x0, x1
1008459f0:     	mov	x1, x21
1008459f4:     	bl	0x100b61fec <_writev+0x100b61fec>
1008459f8:     	b	0x100845ac8 <_js_json_stringify+0x59c>
1008459fc:     	add	x9, x21, x24
100845a00:     	ldrsb	w10, [x8]
100845a04:     	tbnz	w10, #0x1f, 0x100845a30 <_js_json_stringify+0x504>
100845a08:     	ldrsb	w10, [x8, #0x1]
100845a0c:     	tbnz	w10, #0x1f, 0x100845a30 <_js_json_stringify+0x504>
100845a10:     	ldrsb	w10, [x8, #0x2]
100845a14:     	tbnz	w10, #0x1f, 0x100845a30 <_js_json_stringify+0x504>
100845a18:     	ldrsb	w10, [x8, #0x3]
100845a1c:     	tbnz	w10, #0x1f, 0x100845a30 <_js_json_stringify+0x504>
100845a20:     	add	x8, x8, #0x4
100845a24:     	cmp	x8, x9
100845a28:     	b.ne	0x100845a00 <_js_json_stringify+0x4d4>
100845a2c:     	b	0x100845940 <_js_json_stringify+0x414>
100845a30:     	mov	w1, w22
100845a34:     	mov	x0, x21
100845a38:     	bl	0x1005eaae0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
100845a3c:     	mov	x25, x0
100845a40:     	bl	0x1004eff00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100845a44:     	add	x0, x24, #0x14
100845a48:     	mov	w1, #0x3                ; =3
100845a4c:     	bl	0x100458380 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
100845a50:     	mov	x23, x0
100845a54:     	stp	w25, w22, [x0]
100845a58:     	stp	wzr, wzr, [x0, #0xc]
100845a5c:     	str	w22, [x0, #0x8]
100845a60:     	add	x0, x0, #0x14
100845a64:     	mov	x1, x21
100845a68:     	mov	x2, x24
100845a6c:     	bl	0x100b61fec <_writev+0x100b61fec>
100845a70:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100845a74:     	ldr	w21, [x8, #0x590]
100845a78:     	cmp	w21, #0x300
100845a7c:     	b.hs	0x100845b58 <_js_json_stringify+0x62c>
100845a80:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100845a84:     	ldr	x8, [x8, #0x48]
100845a88:     	cmn	x8, #0x1
100845a8c:     	b.eq	0x100845b48 <_js_json_stringify+0x61c>
100845a90:     	mrs	x9, TPIDRRO_EL0
100845a94:     	and	x9, x9, #0xfffffffffffffff8
100845a98:     	ldr	x0, [x9, x8, lsl #3]
100845a9c:     	cbz	x0, 0x100845b48 <_js_json_stringify+0x61c>
100845aa0:     	add	x8, x0, x21, lsl #3
100845aa4:     	ldr	x0, [x8, #0x1e8]
100845aa8:     	cbz	x0, 0x100845b58 <_js_json_stringify+0x62c>
100845aac:     	ldr	x8, [x0]
100845ab0:     	adds	x8, x8, x24
100845ab4:     	csinv	x8, x8, xzr, lo
100845ab8:     	str	x8, [x0]
100845abc:     	lsr	x8, x8, #25
100845ac0:     	cbz	x8, 0x100845ac8 <_js_json_stringify+0x59c>
100845ac4:     	bl	0x10045f2b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100845ac8:     	ldp	x22, x21, [sp, #0x8]
100845acc:     	ldrb	w8, [x20, #0x18]
100845ad0:     	cmp	w8, #0x1
100845ad4:     	b.ne	0x100845bb0 <_js_json_stringify+0x684>
100845ad8:     	ldp	x8, x0, [x20]
100845adc:     	stp	x22, x21, [x20]
100845ae0:     	str	xzr, [x20, #0x10]
100845ae4:     	sub	x8, x8, #0x1
100845ae8:     	cmn	x8, #0x2
100845aec:     	b.hs	0x100845af4 <_js_json_stringify+0x5c8>
100845af0:     	bl	0x100b5f140 <_mi_free>
100845af4:     	cbz	w26, 0x100845b00 <_js_json_stringify+0x5d4>
100845af8:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100845afc:     	b	0x100845b04 <_js_json_stringify+0x5d8>
100845b00:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100845b04:     	ldr	w8, [x19]
100845b08:     	sub	w8, w8, #0x1
100845b0c:     	str	w8, [x19]
100845b10:     	mov	x0, x23
100845b14:     	ldp	x29, x30, [sp, #0x70]
100845b18:     	ldp	x20, x19, [sp, #0x60]
100845b1c:     	ldp	x22, x21, [sp, #0x50]
100845b20:     	ldp	x24, x23, [sp, #0x40]
100845b24:     	ldp	x26, x25, [sp, #0x30]
100845b28:     	ldp	d9, d8, [sp, #0x20]
100845b2c:     	add	sp, sp, #0x80
100845b30:     	ret
100845b34:     	mov	x22, x0
100845b38:     	add	x0, x0, #0x8
100845b3c:     	bl	0x100b3be90 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100845b40:     	mov	x0, x22
100845b44:     	b	0x100845670 <_js_json_stringify+0x144>
100845b48:     	bl	0x100b3f53c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100845b4c:     	add	x8, x0, x21, lsl #3
100845b50:     	ldr	x0, [x8, #0x1e8]
100845b54:     	cbnz	x0, 0x100845aac <_js_json_stringify+0x580>
100845b58:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100845b5c:     	add	x0, x0, #0x78
100845b60:     	bl	0x100b3cd5c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100845b64:     	ldr	x8, [x0]
100845b68:     	adds	x8, x8, x24
100845b6c:     	csinv	x8, x8, xzr, lo
100845b70:     	str	x8, [x0]
100845b74:     	lsr	x8, x8, #25
100845b78:     	cbnz	x8, 0x100845ac4 <_js_json_stringify+0x598>
100845b7c:     	b	0x100845ac8 <_js_json_stringify+0x59c>
100845b80:     	bl	0x100b3f53c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100845b84:     	add	x8, x0, x20, lsl #3
100845b88:     	ldr	x0, [x8, #0x1e8]
100845b8c:     	cbnz	x0, 0x100845704 <_js_json_stringify+0x1d8>
100845b90:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100845b94:     	add	x0, x0, #0x138
100845b98:     	bl	0x100b3cd5c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100845b9c:     	b	0x100845704 <_js_json_stringify+0x1d8>
100845ba0:     	mov	x0, x20
100845ba4:     	bl	0x100b1e6c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100845ba8:     	cbnz	x0, 0x10084574c <_js_json_stringify+0x220>
100845bac:     	b	0x100845c50 <_js_json_stringify+0x724>
100845bb0:     	mov	x0, x20
100845bb4:     	bl	0x100b1e6c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100845bb8:     	mov	x20, x0
100845bbc:     	cbnz	x0, 0x100845ad8 <_js_json_stringify+0x5ac>
100845bc0:     	cbz	x22, 0x100845c50 <_js_json_stringify+0x724>
100845bc4:     	mov	x0, x21
100845bc8:     	bl	0x100b5f140 <_mi_free>
100845bcc:     	b	0x100845c50 <_js_json_stringify+0x724>
100845bd0:     	cmp	w8, #0x2
100845bd4:     	b.eq	0x100845c50 <_js_json_stringify+0x724>
100845bd8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100845bdc:     	add	x1, x1, #0xff8
100845be0:     	mov	x22, x0
100845be4:     	bl	0x100a2059c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845be8:     	mov	x0, x22
100845bec:     	strb	wzr, [x22, #0x20]
100845bf0:     	ldr	x8, [x22]
100845bf4:     	cbz	x8, 0x1008457a8 <_js_json_stringify+0x27c>
100845bf8:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845bfc:     	add	x0, x0, #0xdb8
100845c00:     	bl	0x100b1286c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845c04:     	bl	0x100b1e824 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100845c08:     	cbnz	x0, 0x100845650 <_js_json_stringify+0x124>
100845c0c:     	b	0x100845c50 <_js_json_stringify+0x724>
100845c10:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100845c14:     	add	x0, x0, #0x440
100845c18:     	bl	0x100b1286c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845c1c:     	cmp	w8, #0x1
100845c20:     	b.ne	0x100845c50 <_js_json_stringify+0x724>
100845c24:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100845c28:     	add	x1, x1, #0x998
100845c2c:     	mov	x20, x0
100845c30:     	bl	0x100a2059c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845c34:     	mov	x0, x20
100845c38:     	strb	wzr, [x20, #0x20]
100845c3c:     	ldr	x8, [x20]
100845c40:     	cbz	x8, 0x100845728 <_js_json_stringify+0x1fc>
100845c44:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845c48:     	add	x0, x0, #0xd88
100845c4c:     	bl	0x100b1286c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845c50:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100845c54:     	add	x0, x0, #0xc18
100845c58:     	bl	0x100b5879c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
