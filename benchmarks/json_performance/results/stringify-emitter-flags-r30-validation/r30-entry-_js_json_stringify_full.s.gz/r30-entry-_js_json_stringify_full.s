
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-emitter-flags-r30/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100845c80 <_js_json_stringify_full>:
100845c80:     	sub	sp, sp, #0x120
100845c84:     	stp	d9, d8, [sp, #0xb0]
100845c88:     	stp	x28, x27, [sp, #0xc0]
100845c8c:     	stp	x26, x25, [sp, #0xd0]
100845c90:     	stp	x24, x23, [sp, #0xe0]
100845c94:     	stp	x22, x21, [sp, #0xf0]
100845c98:     	stp	x20, x19, [sp, #0x100]
100845c9c:     	stp	x29, x30, [sp, #0x110]
100845ca0:     	add	x29, sp, #0x110
100845ca4:     	mov.16b	v9, v2
100845ca8:     	mov.16b	v8, v0
100845cac:     	fmov	x19, d8
100845cb0:     	fmov	x21, d1
100845cb4:     	fmov	x23, d9
100845cb8:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100845cbc:     	add	x27, x21, x8
100845cc0:     	add	x24, x23, x8
100845cc4:     	fcmp	d2, #0.0
100845cc8:     	ccmp	x24, #0x2, #0x0, ne
100845ccc:     	b.hi	0x100845cdc <_js_json_stringify_full+0x5c>
100845cd0:     	cmp	x27, #0x2
100845cd4:     	b.lo	0x100845cec <_js_json_stringify_full+0x6c>
100845cd8:     	b	0x100846258 <_js_json_stringify_full+0x5d8>
100845cdc:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
100845ce0:     	cmp	x23, x8
100845ce4:     	ccmp	x27, #0x2, #0x2, eq
100845ce8:     	b.hs	0x100846258 <_js_json_stringify_full+0x5d8>
100845cec:     	mov	x8, #-0x2               ; =-2
100845cf0:     	movk	x8, #0x8003, lsl #48
100845cf4:     	add	x8, x19, x8
100845cf8:     	cmp	x8, #0x3
100845cfc:     	b.hs	0x100845d10 <_js_json_stringify_full+0x90>
100845d00:     	adrp	x9, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4cb0>
100845d04:     	add	x9, x9, #0x8d8
100845d08:     	ldr	x20, [x9, x8, lsl #3]
100845d0c:     	b	0x100847128 <_js_json_stringify_full+0x14a8>
100845d10:     	strb	wzr, [sp, #0x4c]
100845d14:     	str	wzr, [sp, #0x48]
100845d18:     	and	x8, x19, #0xffff000000000000
100845d1c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845d20:     	cmp	x8, x9
100845d24:     	b.eq	0x100845d98 <_js_json_stringify_full+0x118>
100845d28:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845d2c:     	cmp	x8, x9
100845d30:     	b.ne	0x100846194 <_js_json_stringify_full+0x514>
100845d34:     	ubfx	x10, x19, #40, #8
100845d38:     	cbz	x10, 0x100845d88 <_js_json_stringify_full+0x108>
100845d3c:     	strb	w19, [sp, #0x48]
100845d40:     	cmp	x10, #0x1
100845d44:     	b.eq	0x100845d88 <_js_json_stringify_full+0x108>
100845d48:     	lsr	x9, x19, #8
100845d4c:     	strb	w9, [sp, #0x49]
100845d50:     	cmp	x10, #0x2
100845d54:     	b.eq	0x100845d88 <_js_json_stringify_full+0x108>
100845d58:     	lsr	x9, x19, #16
100845d5c:     	strb	w9, [sp, #0x4a]
100845d60:     	cmp	x10, #0x3
100845d64:     	b.eq	0x100845d88 <_js_json_stringify_full+0x108>
100845d68:     	lsr	x9, x19, #24
100845d6c:     	strb	w9, [sp, #0x4b]
100845d70:     	cmp	x10, #0x4
100845d74:     	b.eq	0x100845d88 <_js_json_stringify_full+0x108>
100845d78:     	lsr	x9, x19, #32
100845d7c:     	strb	w9, [sp, #0x4c]
100845d80:     	cmp	x10, #0x5
100845d84:     	b.ne	0x1008478fc <_js_json_stringify_full+0x1c7c>
100845d88:     	add	x11, sp, #0x48
100845d8c:     	cmp	w10, #0x3
100845d90:     	b.ls	0x100845db0 <_js_json_stringify_full+0x130>
100845d94:     	b	0x100846194 <_js_json_stringify_full+0x514>
100845d98:     	ands	x9, x19, #0xffffffffffff
100845d9c:     	b.eq	0x100846258 <_js_json_stringify_full+0x5d8>
100845da0:     	add	x11, x9, #0x14
100845da4:     	ldr	w10, [x9, #0x4]
100845da8:     	cmp	w10, #0x3
100845dac:     	b.hi	0x100846194 <_js_json_stringify_full+0x514>
100845db0:     	stur	wzr, [sp, #0x81]
100845db4:     	mov	w9, #0x22               ; =34
100845db8:     	strb	w9, [sp, #0x80]
100845dbc:     	cbz	w10, 0x100845df4 <_js_json_stringify_full+0x174>
100845dc0:     	add	x12, sp, #0x80
100845dc4:     	ldrb	w13, [x11]
100845dc8:     	sxtb	w15, w13
100845dcc:     	cmp	w13, #0xb
100845dd0:     	b.le	0x100845dfc <_js_json_stringify_full+0x17c>
100845dd4:     	cmp	w13, #0x21
100845dd8:     	b.gt	0x100845e1c <_js_json_stringify_full+0x19c>
100845ddc:     	cmp	w13, #0xc
100845de0:     	b.eq	0x100845e50 <_js_json_stringify_full+0x1d0>
100845de4:     	cmp	w13, #0xd
100845de8:     	b.ne	0x100845e2c <_js_json_stringify_full+0x1ac>
100845dec:     	mov	w15, #0x72              ; =114
100845df0:     	b	0x100845e5c <_js_json_stringify_full+0x1dc>
100845df4:     	mov	w12, #0x1               ; =1
100845df8:     	b	0x100845e84 <_js_json_stringify_full+0x204>
100845dfc:     	cmp	w13, #0x8
100845e00:     	b.eq	0x100845e48 <_js_json_stringify_full+0x1c8>
100845e04:     	cmp	w13, #0x9
100845e08:     	b.eq	0x100845e58 <_js_json_stringify_full+0x1d8>
100845e0c:     	cmp	w13, #0xa
100845e10:     	b.ne	0x100845e2c <_js_json_stringify_full+0x1ac>
100845e14:     	mov	w15, #0x6e              ; =110
100845e18:     	b	0x100845e5c <_js_json_stringify_full+0x1dc>
100845e1c:     	cmp	w13, #0x22
100845e20:     	b.eq	0x100845e5c <_js_json_stringify_full+0x1dc>
100845e24:     	cmp	w13, #0x5c
100845e28:     	b.eq	0x100845e5c <_js_json_stringify_full+0x1dc>
100845e2c:     	cmp	w15, #0x20
100845e30:     	b.lt	0x100846194 <_js_json_stringify_full+0x514>
100845e34:     	mov	w14, #0x0               ; =0
100845e38:     	add	x13, x12, #0x2
100845e3c:     	mov	w12, #0x2               ; =2
100845e40:     	mov	w16, #0x1               ; =1
100845e44:     	b	0x100845e74 <_js_json_stringify_full+0x1f4>
100845e48:     	mov	w15, #0x62              ; =98
100845e4c:     	b	0x100845e5c <_js_json_stringify_full+0x1dc>
100845e50:     	mov	w15, #0x66              ; =102
100845e54:     	b	0x100845e5c <_js_json_stringify_full+0x1dc>
100845e58:     	mov	w15, #0x74              ; =116
100845e5c:     	add	x13, x12, #0x3
100845e60:     	mov	w12, #0x5c              ; =92
100845e64:     	strb	w12, [sp, #0x81]
100845e68:     	mov	w14, #0x1               ; =1
100845e6c:     	mov	w12, #0x3               ; =3
100845e70:     	mov	w16, #0x2               ; =2
100845e74:     	add	x17, sp, #0x80
100845e78:     	strb	w15, [x17, x16]
100845e7c:     	cmp	w10, #0x1
100845e80:     	b.ne	0x100845ebc <_js_json_stringify_full+0x23c>
100845e84:     	add	x10, sp, #0x80
100845e88:     	strb	w9, [x10, x12]
100845e8c:     	add	x8, x12, #0x1
100845e90:     	cmp	x12, #0x3
100845e94:     	b.hs	0x100845ea8 <_js_json_stringify_full+0x228>
100845e98:     	mov	x13, #0x0               ; =0
100845e9c:     	mov	x11, #0x0               ; =0
100845ea0:     	add	x9, sp, #0x80
100845ea4:     	b	0x100846104 <_js_json_stringify_full+0x484>
100845ea8:     	cmp	x12, #0xf
100845eac:     	b.hs	0x100845eec <_js_json_stringify_full+0x26c>
100845eb0:     	mov	x11, #0x0               ; =0
100845eb4:     	mov	x13, #0x0               ; =0
100845eb8:     	b	0x100846060 <_js_json_stringify_full+0x3e0>
100845ebc:     	ldrb	w16, [x11, #0x1]
100845ec0:     	sxtb	w15, w16
100845ec4:     	cmp	w16, #0xb
100845ec8:     	b.le	0x100846134 <_js_json_stringify_full+0x4b4>
100845ecc:     	cmp	w16, #0x21
100845ed0:     	b.gt	0x100846154 <_js_json_stringify_full+0x4d4>
100845ed4:     	cmp	w16, #0xc
100845ed8:     	b.eq	0x100846184 <_js_json_stringify_full+0x504>
100845edc:     	cmp	w16, #0xd
100845ee0:     	b.ne	0x100846164 <_js_json_stringify_full+0x4e4>
100845ee4:     	mov	w15, #0x72              ; =114
100845ee8:     	b	0x100846190 <_js_json_stringify_full+0x510>
100845eec:     	and	x12, x8, #0xc
100845ef0:     	and	x11, x8, #0x10
100845ef4:     	add	x13, sp, #0x80
100845ef8:     	add	x9, x13, x11
100845efc:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5cb0>
100845f00:     	ldr	q0, [x14, #0xa50]
100845f04:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5cb0>
100845f08:     	ldr	q1, [x14, #0xa60]
100845f0c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5cb0>
100845f10:     	ldr	q2, [x14, #0xa70]
100845f14:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5cb0>
100845f18:     	ldr	q3, [x14, #0xa80]
100845f1c:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5cb0>
100845f20:     	ldr	q4, [x14, #0xa90]
100845f24:     	movi.2d	v5, #0000000000000000
100845f28:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5cb0>
100845f2c:     	ldr	q6, [x14, #0xaa0]
100845f30:     	adrp	x14, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4cb0>
100845f34:     	ldr	q7, [x14, #0xbc0]
100845f38:     	mov	w14, #0x10              ; =16
100845f3c:     	movi.2d	v16, #0000000000000000
100845f40:     	dup.2d	v17, x14
100845f44:     	adrp	x14, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x334ba>
100845f48:     	ldr	q19, [x14, #0xac0]
100845f4c:     	and	x14, x8, #0x10
100845f50:     	movi.2d	v20, #0000000000000000
100845f54:     	movi.2d	v18, #0000000000000000
100845f58:     	movi.2d	v23, #0000000000000000
100845f5c:     	movi.2d	v21, #0000000000000000
100845f60:     	movi.2d	v24, #0000000000000000
100845f64:     	movi.2d	v22, #0000000000000000
100845f68:     	ldr	q25, [x13], #0x10
100845f6c:     	ushll.8h	v26, v25, #0x0
100845f70:     	ushll2.4s	v27, v26, #0x0
100845f74:     	ushll2.2d	v28, v27, #0x0
100845f78:     	ushll2.8h	v25, v25, #0x0
100845f7c:     	ushll.4s	v29, v25, #0x0
100845f80:     	ushll2.2d	v30, v29, #0x0
100845f84:     	ushll.2d	v29, v29, #0x0
100845f88:     	ushll.2d	v27, v27, #0x0
100845f8c:     	ushll.4s	v26, v26, #0x0
100845f90:     	ushll2.2d	v31, v26, #0x0
100845f94:     	ushll2.4s	v25, v25, #0x0
100845f98:     	ushll.2d	v8, v25, #0x0
100845f9c:     	ushll.2d	v26, v26, #0x0
100845fa0:     	ushll2.2d	v25, v25, #0x0
100845fa4:     	shl.2d	v9, v0, #0x3
100845fa8:     	ushl.2d	v25, v25, v9
100845fac:     	shl.2d	v9, v19, #0x3
100845fb0:     	ushl.2d	v26, v26, v9
100845fb4:     	shl.2d	v9, v1, #0x3
100845fb8:     	ushl.2d	v8, v8, v9
100845fbc:     	shl.2d	v9, v7, #0x3
100845fc0:     	ushl.2d	v31, v31, v9
100845fc4:     	shl.2d	v9, v6, #0x3
100845fc8:     	ushl.2d	v27, v27, v9
100845fcc:     	shl.2d	v9, v3, #0x3
100845fd0:     	ushl.2d	v29, v29, v9
100845fd4:     	shl.2d	v9, v2, #0x3
100845fd8:     	ushl.2d	v30, v30, v9
100845fdc:     	shl.2d	v9, v4, #0x3
100845fe0:     	ushl.2d	v28, v28, v9
100845fe4:     	orr.16b	v18, v28, v18
100845fe8:     	orr.16b	v21, v30, v21
100845fec:     	orr.16b	v23, v29, v23
100845ff0:     	orr.16b	v20, v27, v20
100845ff4:     	orr.16b	v5, v31, v5
100845ff8:     	orr.16b	v24, v8, v24
100845ffc:     	orr.16b	v16, v26, v16
100846000:     	orr.16b	v22, v25, v22
100846004:     	add.2d	v6, v6, v17
100846008:     	add.2d	v7, v7, v17
10084600c:     	add.2d	v19, v19, v17
100846010:     	add.2d	v4, v4, v17
100846014:     	add.2d	v3, v3, v17
100846018:     	add.2d	v2, v2, v17
10084601c:     	add.2d	v1, v1, v17
100846020:     	add.2d	v0, v0, v17
100846024:     	subs	x14, x14, #0x10
100846028:     	b.ne	0x100845f68 <_js_json_stringify_full+0x2e8>
10084602c:     	orr.16b	v0, v16, v23
100846030:     	orr.16b	v1, v20, v24
100846034:     	orr.16b	v0, v0, v1
100846038:     	orr.16b	v1, v5, v21
10084603c:     	orr.16b	v2, v18, v22
100846040:     	orr.16b	v1, v1, v2
100846044:     	orr.16b	v0, v0, v1
100846048:     	mov	d1, v0[1]
10084604c:     	orr.8b	v0, v0, v1
100846050:     	fmov	x13, d0
100846054:     	cmp	x8, x11
100846058:     	b.eq	0x100846124 <_js_json_stringify_full+0x4a4>
10084605c:     	cbz	x12, 0x100846104 <_js_json_stringify_full+0x484>
100846060:     	mov	x14, x11
100846064:     	and	x11, x8, #0x1c
100846068:     	add	x15, sp, #0x80
10084606c:     	add	x9, x15, x11
100846070:     	fmov	d0, x13
100846074:     	movi.2d	v1, #0000000000000000
100846078:     	dup.2d	v3, x14
10084607c:     	adrp	x12, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4cb0>
100846080:     	ldr	q2, [x12, #0xbc0]
100846084:     	orr.16b	v2, v3, v2
100846088:     	adrp	x12, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x334ba>
10084608c:     	ldr	q4, [x12, #0xac0]
100846090:     	orr.16b	v3, v3, v4
100846094:     	sub	x12, x14, x11
100846098:     	add	x13, x15, x14
10084609c:     	movi.2d	v4, #0x000000000000ff
1008460a0:     	mov	w14, #0x4               ; =4
1008460a4:     	dup.2d	v5, x14
1008460a8:     	ldr	s6, [x13], #0x4
1008460ac:     	ushll.8h	v6, v6, #0x0
1008460b0:     	ushll.4s	v6, v6, #0x0
1008460b4:     	ushll2.2d	v7, v6, #0x0
1008460b8:     	and.16b	v7, v7, v4
1008460bc:     	ushll.2d	v6, v6, #0x0
1008460c0:     	and.16b	v6, v6, v4
1008460c4:     	shl.2d	v16, v2, #0x3
1008460c8:     	shl.2d	v17, v3, #0x3
1008460cc:     	ushl.2d	v6, v6, v17
1008460d0:     	ushl.2d	v7, v7, v16
1008460d4:     	orr.16b	v1, v7, v1
1008460d8:     	orr.16b	v0, v6, v0
1008460dc:     	add.2d	v2, v2, v5
1008460e0:     	add.2d	v3, v3, v5
1008460e4:     	adds	x12, x12, #0x4
1008460e8:     	b.ne	0x1008460a8 <_js_json_stringify_full+0x428>
1008460ec:     	orr.16b	v0, v0, v1
1008460f0:     	mov	d1, v0[1]
1008460f4:     	orr.8b	v0, v0, v1
1008460f8:     	fmov	x13, d0
1008460fc:     	cmp	x8, x11
100846100:     	b.eq	0x100846124 <_js_json_stringify_full+0x4a4>
100846104:     	add	x10, x10, x8
100846108:     	lsl	x11, x11, #3
10084610c:     	ldrb	w12, [x9], #0x1
100846110:     	lsl	x12, x12, x11
100846114:     	orr	x13, x12, x13
100846118:     	add	x11, x11, #0x8
10084611c:     	cmp	x9, x10
100846120:     	b.ne	0x10084610c <_js_json_stringify_full+0x48c>
100846124:     	orr	x8, x13, x8, lsl #40
100846128:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
10084612c:     	orr	x20, x8, x9
100846130:     	b	0x100847128 <_js_json_stringify_full+0x14a8>
100846134:     	cmp	w16, #0x8
100846138:     	b.eq	0x10084617c <_js_json_stringify_full+0x4fc>
10084613c:     	cmp	w16, #0x9
100846140:     	b.eq	0x10084618c <_js_json_stringify_full+0x50c>
100846144:     	cmp	w16, #0xa
100846148:     	b.ne	0x100846164 <_js_json_stringify_full+0x4e4>
10084614c:     	mov	w15, #0x6e              ; =110
100846150:     	b	0x100846190 <_js_json_stringify_full+0x510>
100846154:     	cmp	w16, #0x22
100846158:     	b.eq	0x100846190 <_js_json_stringify_full+0x510>
10084615c:     	cmp	w16, #0x5c
100846160:     	b.eq	0x100846190 <_js_json_stringify_full+0x510>
100846164:     	cmp	w15, #0x20
100846168:     	b.lt	0x100846194 <_js_json_stringify_full+0x514>
10084616c:     	add	x13, sp, #0x80
100846170:     	strb	w15, [x13, x12]
100846174:     	add	x12, x12, #0x1
100846178:     	b	0x10084671c <_js_json_stringify_full+0xa9c>
10084617c:     	mov	w15, #0x62              ; =98
100846180:     	b	0x100846190 <_js_json_stringify_full+0x510>
100846184:     	mov	w15, #0x66              ; =102
100846188:     	b	0x100846190 <_js_json_stringify_full+0x510>
10084618c:     	mov	w15, #0x74              ; =116
100846190:     	tbz	w14, #0x0, 0x100846708 <_js_json_stringify_full+0xa88>
100846194:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846198:     	cmp	x8, x9
10084619c:     	b.eq	0x1008461e4 <_js_json_stringify_full+0x564>
1008461a0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
1008461a4:     	cmp	x8, x9
1008461a8:     	b.ne	0x100846258 <_js_json_stringify_full+0x5d8>
1008461ac:     	and	x8, x19, #0xffffffffffff
1008461b0:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
1008461b4:     	mov	x10, #0x7fffffffffff    ; =140737488355327
1008461b8:     	movk	x10, #0xffef, lsl #16
1008461bc:     	cmp	x9, x10
1008461c0:     	b.hi	0x100846258 <_js_json_stringify_full+0x5d8>
1008461c4:     	ldr	w8, [x8, #0x4]
1008461c8:     	cmp	w8, #0x40
1008461cc:     	b.lo	0x100846258 <_js_json_stringify_full+0x5d8>
1008461d0:     	and	x0, x19, #0xffffffffffff
1008461d4:     	bl	0x1004f2ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
1008461d8:     	cmp	x0, #0x1
1008461dc:     	b.ne	0x100846258 <_js_json_stringify_full+0x5d8>
1008461e0:     	b	0x1008463a4 <_js_json_stringify_full+0x724>
1008461e4:     	and	x25, x19, #0xffffffffffff
1008461e8:     	and	x0, x19, #0xffffffffffff
1008461ec:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008461f0:     	cbz	x0, 0x100846224 <_js_json_stringify_full+0x5a4>
1008461f4:     	ldrb	w8, [x0]
1008461f8:     	cmp	w8, #0x2
1008461fc:     	b.ne	0x100846224 <_js_json_stringify_full+0x5a4>
100846200:     	ldrsb	w8, [x0, #0x1]
100846204:     	tbnz	w8, #0x1f, 0x100846224 <_js_json_stringify_full+0x5a4>
100846208:     	ldrh	w8, [x0, #0x2]
10084620c:     	tbnz	w8, #0xb, 0x100846224 <_js_json_stringify_full+0x5a4>
100846210:     	ldr	w8, [x0, #0x4]
100846214:     	cmp	w8, #0x18
100846218:     	b.lo	0x100846224 <_js_json_stringify_full+0x5a4>
10084621c:     	ldr	w8, [x25]
100846220:     	cbz	w8, 0x10084727c <_js_json_stringify_full+0x15fc>
100846224:     	and	x0, x19, #0xffffffffffff
100846228:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084622c:     	cbz	x0, 0x100846258 <_js_json_stringify_full+0x5d8>
100846230:     	ldrb	w8, [x0]
100846234:     	cmp	w8, #0x2
100846238:     	b.ne	0x100846258 <_js_json_stringify_full+0x5d8>
10084623c:     	ldrh	w8, [x0, #0x2]
100846240:     	tbnz	w8, #0xb, 0x100846258 <_js_json_stringify_full+0x5d8>
100846244:     	ldr	w8, [x0, #0x4]
100846248:     	cmp	w8, #0x18
10084624c:     	b.lo	0x100846258 <_js_json_stringify_full+0x5d8>
100846250:     	ldr	w8, [x25]
100846254:     	cbz	w8, 0x100847220 <_js_json_stringify_full+0x15a0>
100846258:     	mov	x20, #0x1               ; =1
10084625c:     	movk	x20, #0x7ffc, lsl #48
100846260:     	cmp	x19, x20
100846264:     	b.eq	0x100847128 <_js_json_stringify_full+0x14a8>
100846268:     	and	x22, x19, #0xffff000000000000
10084626c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846270:     	cmp	x22, x8
100846274:     	b.ne	0x1008462ac <_js_json_stringify_full+0x62c>
100846278:     	and	x8, x19, #0xffffffffffff
10084627c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846280:     	b.lo	0x100846298 <_js_json_stringify_full+0x618>
100846284:     	ldr	w8, [x8, #0xc]
100846288:     	mov	w9, #0x4f53             ; =20307
10084628c:     	movk	w9, #0x434c, lsl #16
100846290:     	cmp	w8, w9
100846294:     	b.eq	0x100847128 <_js_json_stringify_full+0x14a8>
100846298:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084629c:     	cmp	x22, x8
1008462a0:     	b.ne	0x1008462d8 <_js_json_stringify_full+0x658>
1008462a4:     	and	x0, x19, #0xffffffffffff
1008462a8:     	b	0x100846300 <_js_json_stringify_full+0x680>
1008462ac:     	lsr	x8, x19, #52
1008462b0:     	cbnz	x8, 0x100846388 <_js_json_stringify_full+0x708>
1008462b4:     	and	x8, x19, #0x7
1008462b8:     	cbz	x19, 0x1008462e4 <_js_json_stringify_full+0x664>
1008462bc:     	cbnz	x8, 0x1008462e4 <_js_json_stringify_full+0x664>
1008462c0:     	mov	x0, x19
1008462c4:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008462c8:     	mov	x8, x19
1008462cc:     	tbnz	w0, #0x0, 0x10084627c <_js_json_stringify_full+0x5fc>
1008462d0:     	mov	x8, #0x0                ; =0
1008462d4:     	b	0x1008462e4 <_js_json_stringify_full+0x664>
1008462d8:     	lsr	x8, x19, #52
1008462dc:     	cbnz	x8, 0x100846388 <_js_json_stringify_full+0x708>
1008462e0:     	and	x8, x19, #0x7
1008462e4:     	cbz	x19, 0x100846388 <_js_json_stringify_full+0x708>
1008462e8:     	cbnz	x8, 0x100846388 <_js_json_stringify_full+0x708>
1008462ec:     	mov	x0, x19
1008462f0:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008462f4:     	mov	x8, x0
1008462f8:     	mov	x0, x19
1008462fc:     	tbz	w8, #0x0, 0x100846388 <_js_json_stringify_full+0x708>
100846300:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100846304:     	b.lo	0x100846388 <_js_json_stringify_full+0x708>
100846308:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084630c:     	add	x8, x8, #0xfb0
100846310:     	ldaprb	w8, [x8]
100846314:     	cbz	w8, 0x100846388 <_js_json_stringify_full+0x708>
100846318:     	lsr	x8, x0, #3
10084631c:     	mov	x9, #0x7c15             ; =31765
100846320:     	movk	x9, #0x7f4a, lsl #16
100846324:     	movk	x9, #0x79b9, lsl #32
100846328:     	movk	x9, #0x9e37, lsl #48
10084632c:     	mul	x8, x8, x9
100846330:     	lsr	x10, x8, #54
100846334:     	lsr	x11, x8, #60
100846338:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084633c:     	add	x9, x9, #0xf30
100846340:     	add	x11, x9, x11, lsl #3
100846344:     	ldapr	x11, [x11]
100846348:     	lsr	x10, x11, x10
10084634c:     	tbz	w10, #0x0, 0x100846388 <_js_json_stringify_full+0x708>
100846350:     	lsr	x10, x8, #44
100846354:     	ubfx	x11, x8, #50, #4
100846358:     	add	x11, x9, x11, lsl #3
10084635c:     	ldapr	x11, [x11]
100846360:     	lsr	x10, x11, x10
100846364:     	tbz	w10, #0x0, 0x100846388 <_js_json_stringify_full+0x708>
100846368:     	lsr	x10, x8, #34
10084636c:     	ubfx	x8, x8, #40, #4
100846370:     	add	x8, x9, x8, lsl #3
100846374:     	ldapr	x8, [x8]
100846378:     	lsr	x8, x8, x10
10084637c:     	tbz	w8, #0x0, 0x100846388 <_js_json_stringify_full+0x708>
100846380:     	bl	0x10034ca2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
100846384:     	tbnz	w0, #0x0, 0x100847128 <_js_json_stringify_full+0x14a8>
100846388:     	cmp	x24, #0x3
10084638c:     	ccmp	x27, #0x2, #0x2, lo
100846390:     	b.hs	0x1008463b0 <_js_json_stringify_full+0x730>
100846394:     	mov.16b	v0, v8
100846398:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084639c:     	cmp	x0, #0x1
1008463a0:     	b.ne	0x1008463b0 <_js_json_stringify_full+0x730>
1008463a4:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
1008463a8:     	bfxil	x20, x1, #0, #48
1008463ac:     	b	0x100847128 <_js_json_stringify_full+0x14a8>
1008463b0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008463b4:     	cmp	x22, x8
1008463b8:     	b.ne	0x100846408 <_js_json_stringify_full+0x788>
1008463bc:     	ands	x22, x19, #0xffffffffffff
1008463c0:     	b.eq	0x100846408 <_js_json_stringify_full+0x788>
1008463c4:     	mov	x0, x22
1008463c8:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008463cc:     	cbz	w0, 0x100846408 <_js_json_stringify_full+0x788>
1008463d0:     	ldurb	w8, [x22, #-0x8]
1008463d4:     	cmp	w8, #0x9
1008463d8:     	b.ne	0x100846408 <_js_json_stringify_full+0x788>
1008463dc:     	ldr	w8, [x22, #0x4]
1008463e0:     	mov	w9, #0x5841             ; =22593
1008463e4:     	movk	w9, #0x4c5a, lsl #16
1008463e8:     	cmp	w8, w9
1008463ec:     	b.ne	0x100846408 <_js_json_stringify_full+0x788>
1008463f0:     	mov	x0, x22
1008463f4:     	bl	0x100688524 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1008463f8:     	cbz	x0, 0x100846408 <_js_json_stringify_full+0x788>
1008463fc:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100846400:     	bfxil	x19, x0, #0, #48
100846404:     	fmov	d8, x19
100846408:     	mov	w8, #0x7ffd             ; =32765
10084640c:     	cmp	x8, x23, lsr #48
100846410:     	b.ne	0x100846424 <_js_json_stringify_full+0x7a4>
100846414:     	and	x1, x23, #0xffffffffffff
100846418:     	cmp	x1, #0x100, lsl #12     ; =0x100000
10084641c:     	b.hs	0x100846438 <_js_json_stringify_full+0x7b8>
100846420:     	b	0x10084648c <_js_json_stringify_full+0x80c>
100846424:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
100846428:     	mov	x9, #0xfffffff00000     ; =281474975662080
10084642c:     	mov	x1, x23
100846430:     	cmp	x8, x9
100846434:     	b.hs	0x10084648c <_js_json_stringify_full+0x80c>
100846438:     	lsr	x8, x1, #47
10084643c:     	cbnz	x8, 0x10084648c <_js_json_stringify_full+0x80c>
100846440:     	add	x0, sp, #0x80
100846444:     	bl	0x10076e32c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
100846448:     	ldr	w8, [sp, #0x80]
10084644c:     	tbz	w8, #0x0, 0x10084648c <_js_json_stringify_full+0x80c>
100846450:     	ldr	w8, [sp, #0x88]
100846454:     	mov	w9, #-0xff30            ; =-65328
100846458:     	cmp	w8, w9
10084645c:     	b.eq	0x100846480 <_js_json_stringify_full+0x800>
100846460:     	mov	w9, #-0xff2f            ; =-65327
100846464:     	cmp	w8, w9
100846468:     	b.ne	0x10084648c <_js_json_stringify_full+0x80c>
10084646c:     	mov.16b	v0, v9
100846470:     	bl	0x10084853c <_js_jsvalue_to_string>
100846474:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
100846478:     	bfxil	x23, x0, #0, #48
10084647c:     	b	0x10084648c <_js_json_stringify_full+0x80c>
100846480:     	mov.16b	v0, v9
100846484:     	bl	0x10086fae0 <_js_number_coerce>
100846488:     	fmov	x23, d0
10084648c:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100846490:     	add	x8, x23, x8
100846494:     	cmp	x8, #0x3
100846498:     	b.hs	0x1008464b0 <_js_json_stringify_full+0x830>
10084649c:     	mov	x22, #0x0               ; =0
1008464a0:     	mov	w8, #0x1                ; =1
1008464a4:     	stp	xzr, x8, [sp, #0x10]
1008464a8:     	str	xzr, [sp, #0x20]
1008464ac:     	b	0x100846764 <_js_json_stringify_full+0xae4>
1008464b0:     	and	x8, x23, #0xffff000000000000
1008464b4:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008464b8:     	cmp	x8, x9
1008464bc:     	b.eq	0x1008464e0 <_js_json_stringify_full+0x860>
1008464c0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
1008464c4:     	cmp	x8, x9
1008464c8:     	b.ne	0x10084656c <_js_json_stringify_full+0x8ec>
1008464cc:     	and	x8, x23, #0xffffffffffff
1008464d0:     	cmp	x8, #0x1, lsl #12       ; =0x1000
1008464d4:     	b.hs	0x1008465b4 <_js_json_stringify_full+0x934>
1008464d8:     	mov	x9, #0x0                ; =0
1008464dc:     	b	0x1008465bc <_js_json_stringify_full+0x93c>
1008464e0:     	strb	wzr, [sp, #0x4c]
1008464e4:     	str	wzr, [sp, #0x48]
1008464e8:     	ubfx	x1, x23, #40, #8
1008464ec:     	cbz	x1, 0x10084653c <_js_json_stringify_full+0x8bc>
1008464f0:     	strb	w23, [sp, #0x48]
1008464f4:     	cmp	x1, #0x1
1008464f8:     	b.eq	0x10084653c <_js_json_stringify_full+0x8bc>
1008464fc:     	lsr	x8, x23, #8
100846500:     	strb	w8, [sp, #0x49]
100846504:     	cmp	x1, #0x2
100846508:     	b.eq	0x10084653c <_js_json_stringify_full+0x8bc>
10084650c:     	lsr	x8, x23, #16
100846510:     	strb	w8, [sp, #0x4a]
100846514:     	cmp	x1, #0x3
100846518:     	b.eq	0x10084653c <_js_json_stringify_full+0x8bc>
10084651c:     	lsr	x8, x23, #24
100846520:     	strb	w8, [sp, #0x4b]
100846524:     	cmp	x1, #0x4
100846528:     	b.eq	0x10084653c <_js_json_stringify_full+0x8bc>
10084652c:     	lsr	x8, x23, #32
100846530:     	strb	w8, [sp, #0x4c]
100846534:     	cmp	x1, #0x5
100846538:     	b.ne	0x1008478fc <_js_json_stringify_full+0x1c7c>
10084653c:     	add	x8, sp, #0x80
100846540:     	add	x0, sp, #0x48
100846544:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100846548:     	ldr	w8, [sp, #0x80]
10084654c:     	ldp	x9, x22, [sp, #0x88]
100846550:     	cmp	w8, #0x0
100846554:     	csinc	x23, x9, xzr, eq
100846558:     	csel	x25, xzr, x22, ne
10084655c:     	tbz	x25, #0x3f, 0x10084669c <_js_json_stringify_full+0xa1c>
100846560:     	mov	x0, #0x0                ; =0
100846564:     	mov	x1, x22
100846568:     	bl	0x100b124c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084656c:     	add	x8, x20, #0x3
100846570:     	cmp	x23, x8
100846574:     	b.eq	0x10084649c <_js_json_stringify_full+0x81c>
100846578:     	fmov	d0, x23
10084657c:     	fcvtzu	x8, d0
100846580:     	mov	w9, #0xa                ; =10
100846584:     	cmp	x8, #0xa
100846588:     	csel	x3, x8, x9, lo
10084658c:     	adrp	x1, 0x100c43000 <_PERRY_EMPTY_STRING+0x18f4>
100846590:     	add	x1, x1, #0x89c
100846594:     	add	x0, sp, #0x80
100846598:     	mov	w2, #0x1                ; =1
10084659c:     	bl	0x1002305f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
1008465a0:     	ldr	x22, [sp, #0x90]
1008465a4:     	str	x22, [sp, #0x20]
1008465a8:     	ldr	q0, [sp, #0x80]
1008465ac:     	str	q0, [sp, #0x10]
1008465b0:     	b	0x100846764 <_js_json_stringify_full+0xae4>
1008465b4:     	ldr	w22, [x8, #0x4]
1008465b8:     	add	x9, x8, #0x14
1008465bc:     	mov	x14, #0x0               ; =0
1008465c0:     	mov	x8, #0x0                ; =0
1008465c4:     	cmp	x9, #0x0
1008465c8:     	csel	x24, xzr, x22, eq
1008465cc:     	csinc	x23, x9, xzr, ne
1008465d0:     	add	x9, x23, x24
1008465d4:     	mov	w10, #0x1               ; =1
1008465d8:     	mov	x11, x23
1008465dc:     	b	0x10084660c <_js_json_stringify_full+0x98c>
1008465e0:     	add	x12, x11, #0x2
1008465e4:     	bfi	w15, w13, #6, #5
1008465e8:     	mov	x13, x15
1008465ec:     	sub	x11, x25, x11
1008465f0:     	add	x14, x11, x12
1008465f4:     	cmp	w13, #0x10, lsl #12     ; =0x10000
1008465f8:     	cinc	x11, x10, hs
1008465fc:     	add	x8, x11, x8
100846600:     	mov	x11, x12
100846604:     	cmp	x8, #0xa
100846608:     	b.hi	0x1008466c4 <_js_json_stringify_full+0xa44>
10084660c:     	cmp	x11, x9
100846610:     	b.eq	0x100846674 <_js_json_stringify_full+0x9f4>
100846614:     	mov	x25, x14
100846618:     	mov	x12, x11
10084661c:     	ldrsb	w14, [x12], #0x1
100846620:     	and	w13, w14, #0xff
100846624:     	tbz	w14, #0x1f, 0x1008465ec <_js_json_stringify_full+0x96c>
100846628:     	ldrb	w12, [x11, #0x1]
10084662c:     	and	w15, w12, #0x3f
100846630:     	cmp	w13, #0xe0
100846634:     	b.lo	0x1008465e0 <_js_json_stringify_full+0x960>
100846638:     	and	w14, w13, #0x1f
10084663c:     	ldrb	w12, [x11, #0x2]
100846640:     	and	w12, w12, #0x3f
100846644:     	orr	w15, w12, w15, lsl #6
100846648:     	cmp	w13, #0xf0
10084664c:     	b.lo	0x100846668 <_js_json_stringify_full+0x9e8>
100846650:     	add	x12, x11, #0x4
100846654:     	ldrb	w13, [x11, #0x3]
100846658:     	and	w13, w13, #0x3f
10084665c:     	orr	w13, w13, w15, lsl #6
100846660:     	bfi	w13, w14, #18, #3
100846664:     	b	0x1008465ec <_js_json_stringify_full+0x96c>
100846668:     	add	x12, x11, #0x3
10084666c:     	orr	w13, w15, w14, lsl #12
100846670:     	b	0x1008465ec <_js_json_stringify_full+0x96c>
100846674:     	cbz	x24, 0x1008466f8 <_js_json_stringify_full+0xa78>
100846678:     	mov	x0, x24
10084667c:     	mov	w1, #0x1                ; =1
100846680:     	bl	0x100b5f3c8 <_mi_malloc_aligned>
100846684:     	cbz	x0, 0x1008478e4 <_js_json_stringify_full+0x1c64>
100846688:     	mov	x26, x0
10084668c:     	mov	x1, x23
100846690:     	mov	x2, x24
100846694:     	bl	0x100b61fec <_writev+0x100b61fec>
100846698:     	b	0x100846700 <_js_json_stringify_full+0xa80>
10084669c:     	cbz	x25, 0x100846754 <_js_json_stringify_full+0xad4>
1008466a0:     	mov	x0, x25
1008466a4:     	mov	w1, #0x1                ; =1
1008466a8:     	bl	0x100b5f3c8 <_mi_malloc_aligned>
1008466ac:     	cbz	x0, 0x1008478f0 <_js_json_stringify_full+0x1c70>
1008466b0:     	mov	x24, x0
1008466b4:     	mov	x1, x23
1008466b8:     	mov	x2, x25
1008466bc:     	bl	0x100b61fec <_writev+0x100b61fec>
1008466c0:     	b	0x10084675c <_js_json_stringify_full+0xadc>
1008466c4:     	cbz	x25, 0x1008466f8 <_js_json_stringify_full+0xa78>
1008466c8:     	cmp	x25, x24
1008466cc:     	b.hs	0x100847174 <_js_json_stringify_full+0x14f4>
1008466d0:     	ldrsb	w8, [x23, x25]
1008466d4:     	cmn	w8, #0x40
1008466d8:     	b.ge	0x100847178 <_js_json_stringify_full+0x14f8>
1008466dc:     	adrp	x4, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1008466e0:     	add	x4, x4, #0x270
1008466e4:     	mov	x0, x23
1008466e8:     	mov	x1, x24
1008466ec:     	mov	x2, #0x0                ; =0
1008466f0:     	mov	x3, x25
1008466f4:     	bl	0x100b12838 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
1008466f8:     	mov	x22, #0x0               ; =0
1008466fc:     	mov	w26, #0x1               ; =1
100846700:     	stp	x22, x26, [sp, #0x10]
100846704:     	b	0x100846760 <_js_json_stringify_full+0xae0>
100846708:     	add	x14, sp, #0x80
10084670c:     	mov	w16, #0x5c              ; =92
100846710:     	strb	w16, [x14, x12]
100846714:     	add	x12, x12, #0x2
100846718:     	strb	w15, [x13, #0x1]
10084671c:     	cmp	w10, #0x2
100846720:     	b.eq	0x100845e84 <_js_json_stringify_full+0x204>
100846724:     	ldrb	w11, [x11, #0x2]
100846728:     	sxtb	w10, w11
10084672c:     	cmp	w11, #0xb
100846730:     	b.le	0x100847200 <_js_json_stringify_full+0x1580>
100846734:     	cmp	w11, #0x21
100846738:     	b.gt	0x10084724c <_js_json_stringify_full+0x15cc>
10084673c:     	cmp	w11, #0xc
100846740:     	b.eq	0x1008472d8 <_js_json_stringify_full+0x1658>
100846744:     	cmp	w11, #0xd
100846748:     	b.ne	0x10084725c <_js_json_stringify_full+0x15dc>
10084674c:     	mov	w10, #0x72              ; =114
100846750:     	b	0x1008472e4 <_js_json_stringify_full+0x1664>
100846754:     	mov	x22, #0x0               ; =0
100846758:     	mov	w24, #0x1               ; =1
10084675c:     	stp	x22, x24, [sp, #0x10]
100846760:     	str	x22, [sp, #0x20]
100846764:     	cmp	x27, #0x2
100846768:     	b.lo	0x1008468a8 <_js_json_stringify_full+0xc28>
10084676c:     	and	x25, x21, #0xffff000000000000
100846770:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846774:     	cmp	x25, x8
100846778:     	b.ne	0x100846884 <_js_json_stringify_full+0xc04>
10084677c:     	and	x23, x21, #0xffffffffffff
100846780:     	cmp	x23, #0x100, lsl #12    ; =0x100000
100846784:     	b.lo	0x1008468a8 <_js_json_stringify_full+0xc28>
100846788:     	mov	x0, x23
10084678c:     	bl	0x10050a800 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
100846790:     	tbnz	w0, #0x0, 0x1008468a8 <_js_json_stringify_full+0xc28>
100846794:     	lsr	x8, x23, #51
100846798:     	cmp	x8, #0xfff
10084679c:     	b.lo	0x1008467b4 <_js_json_stringify_full+0xb34>
1008467a0:     	mov	w8, #0x7ffc             ; =32764
1008467a4:     	cmp	x8, x23, lsr #48
1008467a8:     	b.eq	0x1008468a8 <_js_json_stringify_full+0xc28>
1008467ac:     	ands	x23, x23, #0xffffffffffff
1008467b0:     	b.eq	0x1008468a8 <_js_json_stringify_full+0xc28>
1008467b4:     	and	x8, x23, #0xfffffffffff00000
1008467b8:     	lsr	x9, x23, #47
1008467bc:     	cmp	x9, #0x0
1008467c0:     	ccmp	x8, #0x0, #0x4, eq
1008467c4:     	b.eq	0x1008468a8 <_js_json_stringify_full+0xc28>
1008467c8:     	tst	x23, #0x3
1008467cc:     	ccmp	x23, #0x7, #0x0, eq
1008467d0:     	b.ls	0x100847514 <_js_json_stringify_full+0x1894>
1008467d4:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
1008467d8:     	ldr	x8, [x8, #0x48]
1008467dc:     	cmn	x8, #0x1
1008467e0:     	b.eq	0x100847464 <_js_json_stringify_full+0x17e4>
1008467e4:     	mrs	x9, TPIDRRO_EL0
1008467e8:     	and	x9, x9, #0xfffffffffffffff8
1008467ec:     	ldr	x0, [x9, x8, lsl #3]
1008467f0:     	cbz	x0, 0x100847464 <_js_json_stringify_full+0x17e4>
1008467f4:     	lsr	x1, x23, #20
1008467f8:     	ldr	x8, [x0, #0x10]
1008467fc:     	ldrb	w9, [x8]
100846800:     	cmp	w9, #0x2
100846804:     	b.ne	0x10084747c <_js_json_stringify_full+0x17fc>
100846808:     	ldrb	w9, [x8, #0x88]
10084680c:     	tbz	w9, #0x0, 0x10084682c <_js_json_stringify_full+0xbac>
100846810:     	ldr	x9, [x8, #0x80]
100846814:     	cmp	x9, x1
100846818:     	b.ne	0x10084682c <_js_json_stringify_full+0xbac>
10084681c:     	ldp	x9, x10, [x8, #0x60]
100846820:     	cmp	x9, x23
100846824:     	ccmp	x10, x23, #0x0, ls
100846828:     	b.hi	0x10084745c <_js_json_stringify_full+0x17dc>
10084682c:     	ldrb	w9, [x8, #0xb8]
100846830:     	cbz	w9, 0x100846850 <_js_json_stringify_full+0xbd0>
100846834:     	ldr	x9, [x8, #0xb0]
100846838:     	cmp	x9, x1
10084683c:     	b.ne	0x100846850 <_js_json_stringify_full+0xbd0>
100846840:     	ldp	x9, x10, [x8, #0x90]
100846844:     	cmp	x9, x23
100846848:     	ccmp	x10, x23, #0x0, ls
10084684c:     	b.hi	0x1008476e4 <_js_json_stringify_full+0x1a64>
100846850:     	ldrb	w9, [x8, #0xe8]
100846854:     	cbz	w9, 0x10084729c <_js_json_stringify_full+0x161c>
100846858:     	ldr	x9, [x8, #0xe0]
10084685c:     	cmp	x9, x1
100846860:     	b.ne	0x10084729c <_js_json_stringify_full+0x161c>
100846864:     	ldr	x9, [x8, #0xc0]
100846868:     	cmp	x9, x23
10084686c:     	b.hi	0x10084729c <_js_json_stringify_full+0x161c>
100846870:     	ldr	x9, [x8, #0xc8]
100846874:     	cmp	x9, x23
100846878:     	b.ls	0x10084729c <_js_json_stringify_full+0x161c>
10084687c:     	add	x9, x8, #0xc0
100846880:     	b	0x1008476e8 <_js_json_stringify_full+0x1a68>
100846884:     	lsr	x8, x21, #52
100846888:     	cbnz	x8, 0x1008468a8 <_js_json_stringify_full+0xc28>
10084688c:     	cbz	x21, 0x1008468a8 <_js_json_stringify_full+0xc28>
100846890:     	and	x8, x21, #0x7
100846894:     	cbnz	x8, 0x1008468a8 <_js_json_stringify_full+0xc28>
100846898:     	mov	x0, x21
10084689c:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008468a0:     	mov	x23, x21
1008468a4:     	cbnz	w0, 0x100846780 <_js_json_stringify_full+0xb00>
1008468a8:     	mov	x25, #-0x1              ; =-1
1008468ac:     	str	x25, [sp, #0x30]
1008468b0:     	mov	w24, #0x1               ; =1
1008468b4:     	cmp	x27, #0x1
1008468b8:     	cset	w8, hi
1008468bc:     	tst	w8, w24
1008468c0:     	b.eq	0x100846934 <_js_json_stringify_full+0xcb4>
1008468c4:     	and	x23, x21, #0xffff000000000000
1008468c8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008468cc:     	cmp	x23, x8
1008468d0:     	b.ne	0x10084690c <_js_json_stringify_full+0xc8c>
1008468d4:     	and	x8, x21, #0xffffffffffff
1008468d8:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1008468dc:     	b.lo	0x100846934 <_js_json_stringify_full+0xcb4>
1008468e0:     	ldr	w8, [x8, #0xc]
1008468e4:     	mov	w9, #0x4f53             ; =20307
1008468e8:     	movk	w9, #0x434c, lsl #16
1008468ec:     	cmp	w8, w9
1008468f0:     	b.ne	0x100846934 <_js_json_stringify_full+0xcb4>
1008468f4:     	and	x8, x21, #0xffffffffffff
1008468f8:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008468fc:     	cmp	x23, x9
100846900:     	csel	x28, x8, x21, eq
100846904:     	mov	w27, #0x1               ; =1
100846908:     	b	0x100846938 <_js_json_stringify_full+0xcb8>
10084690c:     	lsr	x8, x21, #52
100846910:     	cbnz	x8, 0x100846934 <_js_json_stringify_full+0xcb4>
100846914:     	mov	w27, #0x0               ; =0
100846918:     	cbz	x21, 0x100846938 <_js_json_stringify_full+0xcb8>
10084691c:     	and	x8, x21, #0x7
100846920:     	cbnz	x8, 0x100846938 <_js_json_stringify_full+0xcb8>
100846924:     	mov	x0, x21
100846928:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084692c:     	mov	x8, x21
100846930:     	tbnz	w0, #0x0, 0x1008468d8 <_js_json_stringify_full+0xc58>
100846934:     	mov	w27, #0x0               ; =0
100846938:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084693c:     	add	x0, x0, #0xd78
100846940:     	ldr	x8, [x0]
100846944:     	blr	x8
100846948:     	mov	x21, x0
10084694c:     	ldr	w26, [x0]
100846950:     	add	w8, w26, #0x1
100846954:     	str	w8, [x0]
100846958:     	cbz	w26, 0x1008469c8 <_js_json_stringify_full+0xd48>
10084695c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846960:     	add	x0, x0, #0xd00
100846964:     	ldr	x8, [x0]
100846968:     	blr	x8
10084696c:     	ldrb	w8, [x0, #0x20]
100846970:     	cmp	w8, #0x1
100846974:     	b.ne	0x100847754 <_js_json_stringify_full+0x1ad4>
100846978:     	ldr	x8, [x0]
10084697c:     	cbnz	x8, 0x100847760 <_js_json_stringify_full+0x1ae0>
100846980:     	mov	x8, #-0x1               ; =-1
100846984:     	str	x8, [x0]
100846988:     	ldr	x23, [x0, #0x18]
10084698c:     	ldr	x8, [x0, #0x8]
100846990:     	cmp	x23, x8
100846994:     	b.eq	0x100847150 <_js_json_stringify_full+0x14d0>
100846998:     	ldr	x8, [x0, #0x10]
10084699c:     	mov	w9, #0x18               ; =24
1008469a0:     	madd	x8, x23, x9, x8
1008469a4:     	mov	w9, #0x8                ; =8
1008469a8:     	stp	xzr, x9, [x8]
1008469ac:     	str	xzr, [x8, #0x10]
1008469b0:     	add	x8, x23, #0x1
1008469b4:     	str	x8, [x0, #0x18]
1008469b8:     	ldr	x8, [x0]
1008469bc:     	add	x8, x8, #0x1
1008469c0:     	str	x8, [x0]
1008469c4:     	b	0x100846a30 <_js_json_stringify_full+0xdb0>
1008469c8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008469cc:     	add	x0, x0, #0xdc0
1008469d0:     	ldr	x8, [x0]
1008469d4:     	blr	x8
1008469d8:     	strb	wzr, [x0]
1008469dc:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008469e0:     	add	x0, x0, #0xdf0
1008469e4:     	ldr	x8, [x0]
1008469e8:     	blr	x8
1008469ec:     	strb	wzr, [x0]
1008469f0:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1008469f4:     	ldr	w23, [x8, #0x5a8]
1008469f8:     	cmp	w23, #0x300
1008469fc:     	b.hs	0x100847198 <_js_json_stringify_full+0x1518>
100846a00:     	adrp	x8, 0x100f7c000 <_perry_global_worker_ts__1>
100846a04:     	ldr	x8, [x8, #0x48]
100846a08:     	cmn	x8, #0x1
100846a0c:     	b.eq	0x100847188 <_js_json_stringify_full+0x1508>
100846a10:     	mrs	x9, TPIDRRO_EL0
100846a14:     	and	x9, x9, #0xfffffffffffffff8
100846a18:     	ldr	x0, [x9, x8, lsl #3]
100846a1c:     	cbz	x0, 0x100847188 <_js_json_stringify_full+0x1508>
100846a20:     	add	x8, x0, x23, lsl #3
100846a24:     	ldr	x0, [x8, #0x1e8]
100846a28:     	cbz	x0, 0x100847198 <_js_json_stringify_full+0x1518>
100846a2c:     	str	xzr, [x0]
100846a30:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846a34:     	add	x0, x0, #0xd30
100846a38:     	ldr	x8, [x0]
100846a3c:     	blr	x8
100846a40:     	mov	x23, x0
100846a44:     	ldrb	w8, [x0, #0x18]
100846a48:     	cmp	w8, #0x1
100846a4c:     	b.ne	0x100847708 <_js_json_stringify_full+0x1a88>
100846a50:     	ldr	x8, [x0]
100846a54:     	mov	x9, #-0x1               ; =-1
100846a58:     	str	x9, [x0]
100846a5c:     	cmn	x8, #0x2
100846a60:     	b.eq	0x100847890 <_js_json_stringify_full+0x1c10>
100846a64:     	cmn	x8, #0x1
100846a68:     	b.eq	0x100846b3c <_js_json_stringify_full+0xebc>
100846a6c:     	add	x9, sp, #0x48
100846a70:     	ldur	q0, [x0, #0x8]
100846a74:     	stur	q0, [x9, #0x8]
100846a78:     	str	x8, [sp, #0x48]
100846a7c:     	tbz	w24, #0x0, 0x100846b50 <_js_json_stringify_full+0xed0>
100846a80:     	tbz	w27, #0x0, 0x100846c38 <_js_json_stringify_full+0xfb8>
100846a84:     	bl	0x10028b418 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100846a88:     	str	x0, [sp, #0x60]
100846a8c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846a90:     	stp	x28, x8, [sp, #0x88]
100846a94:     	mov	w8, #0x1                ; =1
100846a98:     	str	x8, [sp, #0x80]
100846a9c:     	add	x0, sp, #0x80
100846aa0:     	bl	0x10028b520 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100846aa4:     	mov	x22, x0
100846aa8:     	str	x0, [sp, #0x68]
100846aac:     	mov	w0, #0x0                ; =0
100846ab0:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846ab4:     	stp	xzr, xzr, [x0]
100846ab8:     	str	wzr, [x0, #0x10]
100846abc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846ac0:     	bfxil	x8, x0, #0, #48
100846ac4:     	fmov	d0, x8
100846ac8:     	bl	0x10020b124 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
100846acc:     	mov	x19, x0
100846ad0:     	adrp	x24, 0x100f7c000 <_perry_global_worker_ts__1>
100846ad4:     	ldr	x8, [x24, #0x48]
100846ad8:     	cmn	x8, #0x1
100846adc:     	b.eq	0x100846c9c <_js_json_stringify_full+0x101c>
100846ae0:     	mrs	x9, TPIDRRO_EL0
100846ae4:     	and	x9, x9, #0xfffffffffffffff8
100846ae8:     	ldr	x8, [x9, x8, lsl #3]
100846aec:     	cbz	x8, 0x100846c9c <_js_json_stringify_full+0x101c>
100846af0:     	ldr	x8, [x8, #0x19e8]
100846af4:     	cbz	x8, 0x100846c9c <_js_json_stringify_full+0x101c>
100846af8:     	ldr	x9, [x8]
100846afc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846b00:     	cmp	x9, x10
100846b04:     	b.hs	0x1008477dc <_js_json_stringify_full+0x1b5c>
100846b08:     	add	x10, x9, #0x1
100846b0c:     	str	x10, [x8]
100846b10:     	ldr	x10, [x8, #0x18]
100846b14:     	cmp	x19, x10
100846b18:     	b.hs	0x1008477e8 <_js_json_stringify_full+0x1b68>
100846b1c:     	ldr	x10, [x8, #0x10]
100846b20:     	mov	w11, #0x18              ; =24
100846b24:     	madd	x10, x19, x11, x10
100846b28:     	ldr	x11, [x10]
100846b2c:     	cbnz	x11, 0x100847848 <_js_json_stringify_full+0x1bc8>
100846b30:     	ldr	x0, [x10, #0x8]
100846b34:     	str	x9, [x8]
100846b38:     	b	0x100846ca4 <_js_json_stringify_full+0x1024>
100846b3c:     	mov	x8, #0x0                ; =0
100846b40:     	mov	w9, #0x1                ; =1
100846b44:     	stp	x9, xzr, [sp, #0x50]
100846b48:     	str	x8, [sp, #0x48]
100846b4c:     	tbnz	w24, #0x0, 0x100846a80 <_js_json_stringify_full+0xe00>
100846b50:     	cmp	x22, #0x0
100846b54:     	cset	w6, ne
100846b58:     	ldp	x0, x1, [sp, #0x38]
100846b5c:     	ldp	x3, x4, [sp, #0x18]
100846b60:     	add	x2, sp, #0x48
100846b64:     	mov.16b	v0, v8
100846b68:     	mov	x5, #0x0                ; =0
100846b6c:     	bl	0x100502e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
100846b70:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846b74:     	add	x0, x0, #0xd90
100846b78:     	ldr	x8, [x0]
100846b7c:     	blr	x8
100846b80:     	ldrb	w8, [x0, #0x20]
100846b84:     	cbnz	w8, 0x10084776c <_js_json_stringify_full+0x1aec>
100846b88:     	ldr	x8, [x0]
100846b8c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100846b90:     	cmp	x8, x9
100846b94:     	b.hs	0x10084779c <_js_json_stringify_full+0x1b1c>
100846b98:     	ldr	x9, [x0, #0x18]
100846b9c:     	cbz	x9, 0x100846ba8 <_js_json_stringify_full+0xf28>
100846ba0:     	cbnz	x8, 0x1008477a8 <_js_json_stringify_full+0x1b28>
100846ba4:     	str	xzr, [x0, #0x18]
100846ba8:     	ldp	x0, x1, [sp, #0x50]
100846bac:     	cmp	x1, #0x5
100846bb0:     	b.hi	0x100846c18 <_js_json_stringify_full+0xf98>
100846bb4:     	cbz	x1, 0x100846e28 <_js_json_stringify_full+0x11a8>
100846bb8:     	ldrsb	w8, [x0]
100846bbc:     	tbnz	w8, #0x1f, 0x100846c18 <_js_json_stringify_full+0xf98>
100846bc0:     	cmp	x1, #0x1
100846bc4:     	b.eq	0x100846c00 <_js_json_stringify_full+0xf80>
100846bc8:     	ldrsb	w8, [x0, #0x1]
100846bcc:     	tbnz	w8, #0x1f, 0x100846c18 <_js_json_stringify_full+0xf98>
100846bd0:     	cmp	x1, #0x2
100846bd4:     	b.eq	0x100846c00 <_js_json_stringify_full+0xf80>
100846bd8:     	ldrsb	w8, [x0, #0x2]
100846bdc:     	tbnz	w8, #0x1f, 0x100846c18 <_js_json_stringify_full+0xf98>
100846be0:     	cmp	x1, #0x3
100846be4:     	b.eq	0x100846c00 <_js_json_stringify_full+0xf80>
100846be8:     	ldrsb	w8, [x0, #0x3]
100846bec:     	tbnz	w8, #0x1f, 0x100846c18 <_js_json_stringify_full+0xf98>
100846bf0:     	cmp	x1, #0x4
100846bf4:     	b.eq	0x100846c00 <_js_json_stringify_full+0xf80>
100846bf8:     	ldrsb	w8, [x0, #0x4]
100846bfc:     	tbnz	w8, #0x1f, 0x100846c18 <_js_json_stringify_full+0xf98>
100846c00:     	cmp	x1, #0x4
100846c04:     	b.hs	0x100846f68 <_js_json_stringify_full+0x12e8>
100846c08:     	mov	x10, #0x0               ; =0
100846c0c:     	mov	x9, #0x0                ; =0
100846c10:     	mov	x8, x0
100846c14:     	b	0x100846ff8 <_js_json_stringify_full+0x1378>
100846c18:     	bl	0x100329e88 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
100846c1c:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100846c20:     	bfxil	x20, x0, #0, #48
100846c24:     	ldp	x22, x0, [sp, #0x48]
100846c28:     	ldrb	w8, [x23, #0x18]
100846c2c:     	cmp	w8, #0x1
100846c30:     	b.eq	0x100847034 <_js_json_stringify_full+0x13b4>
100846c34:     	b	0x100847738 <_js_json_stringify_full+0x1ab8>
100846c38:     	mov	w0, #0x0                ; =0
100846c3c:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846c40:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846c44:     	bfxil	x8, x0, #0, #48
100846c48:     	fmov	d1, x8
100846c4c:     	stp	xzr, xzr, [x0]
100846c50:     	str	wzr, [x0, #0x10]
100846c54:     	mov.16b	v0, v8
100846c58:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846c5c:     	mov.16b	v8, v0
100846c60:     	fmov	x24, d8
100846c64:     	cmp	x24, x20
100846c68:     	b.eq	0x100846eb0 <_js_json_stringify_full+0x1230>
100846c6c:     	mov	w8, #0x7ffd             ; =32765
100846c70:     	cmp	x8, x24, lsr #48
100846c74:     	b.ne	0x100846e80 <_js_json_stringify_full+0x1200>
100846c78:     	and	x8, x24, #0xffffffffffff
100846c7c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846c80:     	b.lo	0x100846ea4 <_js_json_stringify_full+0x1224>
100846c84:     	ldr	w8, [x8, #0xc]
100846c88:     	mov	w9, #0x4f53             ; =20307
100846c8c:     	movk	w9, #0x434c, lsl #16
100846c90:     	cmp	w8, w9
100846c94:     	b.ne	0x100846ea4 <_js_json_stringify_full+0x1224>
100846c98:     	b	0x100846eb0 <_js_json_stringify_full+0x1230>
100846c9c:     	mov	x0, x19
100846ca0:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846ca4:     	fmov	d1, x0
100846ca8:     	mov.16b	v0, v8
100846cac:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846cb0:     	mov.16b	v8, v0
100846cb4:     	ldr	x8, [x24, #0x48]
100846cb8:     	cmn	x8, #0x1
100846cbc:     	b.eq	0x100846d20 <_js_json_stringify_full+0x10a0>
100846cc0:     	mrs	x9, TPIDRRO_EL0
100846cc4:     	and	x9, x9, #0xfffffffffffffff8
100846cc8:     	ldr	x8, [x9, x8, lsl #3]
100846ccc:     	cbz	x8, 0x100846d20 <_js_json_stringify_full+0x10a0>
100846cd0:     	ldr	x8, [x8, #0x19e8]
100846cd4:     	cbz	x8, 0x100846d20 <_js_json_stringify_full+0x10a0>
100846cd8:     	ldr	x9, [x8]
100846cdc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846ce0:     	cmp	x9, x10
100846ce4:     	b.hs	0x1008477dc <_js_json_stringify_full+0x1b5c>
100846ce8:     	add	x10, x9, #0x1
100846cec:     	str	x10, [x8]
100846cf0:     	ldr	x10, [x8, #0x18]
100846cf4:     	cmp	x22, x10
100846cf8:     	b.hs	0x1008477e8 <_js_json_stringify_full+0x1b68>
100846cfc:     	ldr	x10, [x8, #0x10]
100846d00:     	mov	w11, #0x18              ; =24
100846d04:     	madd	x10, x22, x11, x10
100846d08:     	ldr	x11, [x10]
100846d0c:     	cmp	x11, #0x1
100846d10:     	b.ne	0x1008478a8 <_js_json_stringify_full+0x1c28>
100846d14:     	ldr	x22, [x10, #0x8]
100846d18:     	str	x9, [x8]
100846d1c:     	b	0x100846d2c <_js_json_stringify_full+0x10ac>
100846d20:     	mov	x0, x22
100846d24:     	bl	0x10013c298 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100846d28:     	mov	x22, x0
100846d2c:     	ldr	x8, [x24, #0x48]
100846d30:     	cmn	x8, #0x1
100846d34:     	b.eq	0x100846d94 <_js_json_stringify_full+0x1114>
100846d38:     	mrs	x9, TPIDRRO_EL0
100846d3c:     	and	x9, x9, #0xfffffffffffffff8
100846d40:     	ldr	x8, [x9, x8, lsl #3]
100846d44:     	cbz	x8, 0x100846d94 <_js_json_stringify_full+0x1114>
100846d48:     	ldr	x8, [x8, #0x19e8]
100846d4c:     	cbz	x8, 0x100846d94 <_js_json_stringify_full+0x1114>
100846d50:     	ldr	x9, [x8]
100846d54:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846d58:     	cmp	x9, x10
100846d5c:     	b.hs	0x1008477dc <_js_json_stringify_full+0x1b5c>
100846d60:     	add	x10, x9, #0x1
100846d64:     	str	x10, [x8]
100846d68:     	ldr	x10, [x8, #0x18]
100846d6c:     	cmp	x19, x10
100846d70:     	b.hs	0x1008477e8 <_js_json_stringify_full+0x1b68>
100846d74:     	ldr	x10, [x8, #0x10]
100846d78:     	mov	w11, #0x18              ; =24
100846d7c:     	madd	x10, x19, x11, x10
100846d80:     	ldr	x11, [x10]
100846d84:     	cbnz	x11, 0x100847848 <_js_json_stringify_full+0x1bc8>
100846d88:     	ldr	x0, [x10, #0x8]
100846d8c:     	str	x9, [x8]
100846d90:     	b	0x100846d9c <_js_json_stringify_full+0x111c>
100846d94:     	mov	x0, x19
100846d98:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846d9c:     	fmov	d9, x0
100846da0:     	mov.16b	v0, v8
100846da4:     	bl	0x1004ff434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100846da8:     	mov.16b	v2, v0
100846dac:     	mov	x0, x22
100846db0:     	mov.16b	v0, v9
100846db4:     	mov.16b	v1, v8
100846db8:     	bl	0x1004ff714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
100846dbc:     	str	d0, [sp, #0x70]
100846dc0:     	fmov	x19, d0
100846dc4:     	cmp	x19, x20
100846dc8:     	b.ne	0x100846e30 <_js_json_stringify_full+0x11b0>
100846dcc:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846dd0:     	add	x0, x0, #0xd90
100846dd4:     	ldr	x8, [x0]
100846dd8:     	blr	x8
100846ddc:     	ldrb	w8, [x0, #0x20]
100846de0:     	cbnz	w8, 0x100847888 <_js_json_stringify_full+0x1c08>
100846de4:     	ldr	x8, [x0]
100846de8:     	cbnz	x8, 0x1008478d8 <_js_json_stringify_full+0x1c58>
100846dec:     	str	xzr, [x0, #0x18]
100846df0:     	ldp	x22, x19, [sp, #0x48]
100846df4:     	ldrb	w8, [x23, #0x18]
100846df8:     	cmp	w8, #0x1
100846dfc:     	b.ne	0x100847820 <_js_json_stringify_full+0x1ba0>
100846e00:     	ldp	x8, x0, [x23]
100846e04:     	stp	x22, x19, [x23]
100846e08:     	str	xzr, [x23, #0x10]
100846e0c:     	sub	x8, x8, #0x1
100846e10:     	cmn	x8, #0x2
100846e14:     	b.hs	0x100846e1c <_js_json_stringify_full+0x119c>
100846e18:     	bl	0x100b5f140 <_mi_free>
100846e1c:     	cbz	w26, 0x1008470bc <_js_json_stringify_full+0x143c>
100846e20:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846e24:     	b	0x1008470c0 <_js_json_stringify_full+0x1440>
100846e28:     	mov	x10, #0x0               ; =0
100846e2c:     	b	0x100847018 <_js_json_stringify_full+0x1398>
100846e30:     	add	x0, sp, #0x48
100846e34:     	bl	0x100500470 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
100846e38:     	tbnz	w0, #0x0, 0x100846e74 <_js_json_stringify_full+0x11f4>
100846e3c:     	mov	x0, x19
100846e40:     	bl	0x100327dec <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
100846e44:     	cmp	x0, #0x1
100846e48:     	b.ne	0x10084789c <_js_json_stringify_full+0x1c1c>
100846e4c:     	add	x8, sp, #0x78
100846e50:     	add	x9, sp, #0x70
100846e54:     	stp	x1, x8, [sp, #0x78]
100846e58:     	str	x9, [sp, #0x88]
100846e5c:     	add	x8, sp, #0x48
100846e60:     	add	x9, sp, #0x10
100846e64:     	stp	x8, x9, [sp, #0x90]
100846e68:     	add	x0, sp, #0x68
100846e6c:     	add	x1, sp, #0x80
100846e70:     	bl	0x100143d90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
100846e74:     	add	x0, sp, #0x60
100846e78:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100846e7c:     	b	0x100846b70 <_js_json_stringify_full+0xef0>
100846e80:     	lsr	x8, x24, #52
100846e84:     	cbnz	x8, 0x100846ea4 <_js_json_stringify_full+0x1224>
100846e88:     	cbz	x24, 0x100846ea4 <_js_json_stringify_full+0x1224>
100846e8c:     	and	x8, x24, #0x7
100846e90:     	cbnz	x8, 0x100846ea4 <_js_json_stringify_full+0x1224>
100846e94:     	mov	x0, x24
100846e98:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846e9c:     	mov	x8, x24
100846ea0:     	tbnz	w0, #0x0, 0x100846c7c <_js_json_stringify_full+0xffc>
100846ea4:     	mov	x0, x24
100846ea8:     	bl	0x100509664 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
100846eac:     	tbz	w0, #0x0, 0x100846f3c <_js_json_stringify_full+0x12bc>
100846eb0:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100846eb4:     	add	x0, x0, #0xd90
100846eb8:     	ldr	x8, [x0]
100846ebc:     	blr	x8
100846ec0:     	ldrb	w8, [x0, #0x20]
100846ec4:     	cbnz	w8, 0x1008477ec <_js_json_stringify_full+0x1b6c>
100846ec8:     	ldr	x8, [x0]
100846ecc:     	cbnz	x8, 0x100847814 <_js_json_stringify_full+0x1b94>
100846ed0:     	str	xzr, [x0, #0x18]
100846ed4:     	ldp	x22, x19, [sp, #0x48]
100846ed8:     	ldrb	w8, [x23, #0x18]
100846edc:     	cmp	w8, #0x1
100846ee0:     	b.ne	0x1008477c8 <_js_json_stringify_full+0x1b48>
100846ee4:     	ldp	x8, x0, [x23]
100846ee8:     	stp	x22, x19, [x23]
100846eec:     	str	xzr, [x23, #0x10]
100846ef0:     	sub	x8, x8, #0x1
100846ef4:     	cmn	x8, #0x2
100846ef8:     	b.hs	0x100846f00 <_js_json_stringify_full+0x1280>
100846efc:     	bl	0x100b5f140 <_mi_free>
100846f00:     	cbz	w26, 0x100846f20 <_js_json_stringify_full+0x12a0>
100846f04:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100846f08:     	ldr	w8, [x21]
100846f0c:     	sub	w8, w8, #0x1
100846f10:     	str	w8, [x21]
100846f14:     	cmn	x25, #0x1
100846f18:     	b.ne	0x1008470dc <_js_json_stringify_full+0x145c>
100846f1c:     	b	0x100847118 <_js_json_stringify_full+0x1498>
100846f20:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846f24:     	ldr	w8, [x21]
100846f28:     	sub	w8, w8, #0x1
100846f2c:     	str	w8, [x21]
100846f30:     	cmn	x25, #0x1
100846f34:     	b.ne	0x1008470dc <_js_json_stringify_full+0x145c>
100846f38:     	b	0x100847118 <_js_json_stringify_full+0x1498>
100846f3c:     	cmp	x19, x24
100846f40:     	b.eq	0x100846f4c <_js_json_stringify_full+0x12cc>
100846f44:     	mov.16b	v0, v8
100846f48:     	bl	0x10050ea2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
100846f4c:     	cbz	x22, 0x1008471a8 <_js_json_stringify_full+0x1528>
100846f50:     	ldp	x1, x2, [sp, #0x18]
100846f54:     	add	x0, sp, #0x48
100846f58:     	mov.16b	v0, v8
100846f5c:     	mov	x3, #0x0                ; =0
100846f60:     	bl	0x100500ee8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
100846f64:     	b	0x1008471b8 <_js_json_stringify_full+0x1538>
100846f68:     	and	x9, x1, #0x4
100846f6c:     	add	x8, x0, x9
100846f70:     	adrp	x10, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4cb0>
100846f74:     	ldr	q0, [x10, #0xbc0]
100846f78:     	adrp	x10, 0x100c39000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x334ba>
100846f7c:     	ldr	q2, [x10, #0xac0]
100846f80:     	movi.2d	v1, #0000000000000000
100846f84:     	movi.2d	v3, #0x000000000000ff
100846f88:     	mov	w10, #0x4               ; =4
100846f8c:     	dup.2d	v4, x10
100846f90:     	mov	x10, x0
100846f94:     	and	x11, x1, #0x4
100846f98:     	movi.2d	v5, #0000000000000000
100846f9c:     	ldr	s6, [x10], #0x4
100846fa0:     	ushll.8h	v6, v6, #0x0
100846fa4:     	ushll.4s	v6, v6, #0x0
100846fa8:     	ushll2.2d	v7, v6, #0x0
100846fac:     	and.16b	v7, v7, v3
100846fb0:     	ushll.2d	v6, v6, #0x0
100846fb4:     	and.16b	v6, v6, v3
100846fb8:     	shl.2d	v16, v0, #0x3
100846fbc:     	shl.2d	v17, v2, #0x3
100846fc0:     	ushl.2d	v6, v6, v17
100846fc4:     	ushl.2d	v7, v7, v16
100846fc8:     	orr.16b	v1, v7, v1
100846fcc:     	orr.16b	v5, v6, v5
100846fd0:     	add.2d	v0, v0, v4
100846fd4:     	add.2d	v2, v2, v4
100846fd8:     	subs	x11, x11, #0x4
100846fdc:     	b.ne	0x100846f9c <_js_json_stringify_full+0x131c>
100846fe0:     	orr.16b	v0, v5, v1
100846fe4:     	mov	d1, v0[1]
100846fe8:     	orr.8b	v0, v0, v1
100846fec:     	fmov	x10, d0
100846ff0:     	cmp	x1, x9
100846ff4:     	b.eq	0x100847018 <_js_json_stringify_full+0x1398>
100846ff8:     	add	x11, x0, x1
100846ffc:     	lsl	x9, x9, #3
100847000:     	ldrb	w12, [x8], #0x1
100847004:     	lsl	x12, x12, x9
100847008:     	orr	x10, x12, x10
10084700c:     	add	x9, x9, #0x8
100847010:     	cmp	x8, x11
100847014:     	b.ne	0x100847000 <_js_json_stringify_full+0x1380>
100847018:     	orr	x8, x10, x1, lsl #40
10084701c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100847020:     	orr	x20, x8, x9
100847024:     	ldr	x22, [sp, #0x48]
100847028:     	ldrb	w8, [x23, #0x18]
10084702c:     	cmp	w8, #0x1
100847030:     	b.ne	0x100847738 <_js_json_stringify_full+0x1ab8>
100847034:     	ldp	x9, x8, [x23]
100847038:     	stp	x22, x0, [x23]
10084703c:     	str	xzr, [x23, #0x10]
100847040:     	sub	x9, x9, #0x1
100847044:     	cmn	x9, #0x2
100847048:     	b.hs	0x100847054 <_js_json_stringify_full+0x13d4>
10084704c:     	mov	x0, x8
100847050:     	bl	0x100b5f140 <_mi_free>
100847054:     	cbz	w26, 0x100847074 <_js_json_stringify_full+0x13f4>
100847058:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084705c:     	ldr	w8, [x21]
100847060:     	sub	w8, w8, #0x1
100847064:     	str	w8, [x21]
100847068:     	cmn	x25, #0x1
10084706c:     	b.ne	0x10084708c <_js_json_stringify_full+0x140c>
100847070:     	b	0x100847118 <_js_json_stringify_full+0x1498>
100847074:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100847078:     	ldr	w8, [x21]
10084707c:     	sub	w8, w8, #0x1
100847080:     	str	w8, [x21]
100847084:     	cmn	x25, #0x1
100847088:     	b.eq	0x100847118 <_js_json_stringify_full+0x1498>
10084708c:     	ldp	x19, x21, [sp, #0x38]
100847090:     	cbz	x21, 0x10084710c <_js_json_stringify_full+0x148c>
100847094:     	add	x22, x19, #0x8
100847098:     	b	0x1008470a8 <_js_json_stringify_full+0x1428>
10084709c:     	add	x22, x22, #0x18
1008470a0:     	subs	x21, x21, #0x1
1008470a4:     	b.eq	0x10084710c <_js_json_stringify_full+0x148c>
1008470a8:     	ldur	x8, [x22, #-0x8]
1008470ac:     	cbz	x8, 0x10084709c <_js_json_stringify_full+0x141c>
1008470b0:     	ldr	x0, [x22]
1008470b4:     	bl	0x100b5f140 <_mi_free>
1008470b8:     	b	0x10084709c <_js_json_stringify_full+0x141c>
1008470bc:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
1008470c0:     	ldr	w8, [x21]
1008470c4:     	sub	w8, w8, #0x1
1008470c8:     	str	w8, [x21]
1008470cc:     	add	x0, sp, #0x60
1008470d0:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1008470d4:     	cmn	x25, #0x1
1008470d8:     	b.eq	0x100847118 <_js_json_stringify_full+0x1498>
1008470dc:     	ldp	x19, x21, [sp, #0x38]
1008470e0:     	cbz	x21, 0x10084710c <_js_json_stringify_full+0x148c>
1008470e4:     	add	x22, x19, #0x8
1008470e8:     	b	0x1008470f8 <_js_json_stringify_full+0x1478>
1008470ec:     	add	x22, x22, #0x18
1008470f0:     	subs	x21, x21, #0x1
1008470f4:     	b.eq	0x10084710c <_js_json_stringify_full+0x148c>
1008470f8:     	ldur	x8, [x22, #-0x8]
1008470fc:     	cbz	x8, 0x1008470ec <_js_json_stringify_full+0x146c>
100847100:     	ldr	x0, [x22]
100847104:     	bl	0x100b5f140 <_mi_free>
100847108:     	b	0x1008470ec <_js_json_stringify_full+0x146c>
10084710c:     	cbz	x25, 0x100847118 <_js_json_stringify_full+0x1498>
100847110:     	mov	x0, x19
100847114:     	bl	0x100b5f140 <_mi_free>
100847118:     	ldr	x8, [sp, #0x10]
10084711c:     	cbz	x8, 0x100847128 <_js_json_stringify_full+0x14a8>
100847120:     	ldr	x0, [sp, #0x18]
100847124:     	bl	0x100b5f140 <_mi_free>
100847128:     	mov	x0, x20
10084712c:     	ldp	x29, x30, [sp, #0x110]
100847130:     	ldp	x20, x19, [sp, #0x100]
100847134:     	ldp	x22, x21, [sp, #0xf0]
100847138:     	ldp	x24, x23, [sp, #0xe0]
10084713c:     	ldp	x26, x25, [sp, #0xd0]
100847140:     	ldp	x28, x27, [sp, #0xc0]
100847144:     	ldp	d9, d8, [sp, #0xb0]
100847148:     	add	sp, sp, #0x120
10084714c:     	ret
100847150:     	str	x22, [sp, #0x8]
100847154:     	mov	x22, x28
100847158:     	mov	x28, x0
10084715c:     	add	x0, x0, #0x8
100847160:     	bl	0x100b3be90 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100847164:     	mov	x0, x28
100847168:     	mov	x28, x22
10084716c:     	ldr	x22, [sp, #0x8]
100847170:     	b	0x100846998 <_js_json_stringify_full+0xd18>
100847174:     	b.ne	0x1008466dc <_js_json_stringify_full+0xa5c>
100847178:     	tbz	x25, #0x3f, 0x1008471d0 <_js_json_stringify_full+0x1550>
10084717c:     	mov	x0, #0x0                ; =0
100847180:     	mov	x1, x25
100847184:     	bl	0x100b124c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847188:     	bl	0x100b3f53c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084718c:     	add	x8, x0, x23, lsl #3
100847190:     	ldr	x0, [x8, #0x1e8]
100847194:     	cbnz	x0, 0x100846a2c <_js_json_stringify_full+0xdac>
100847198:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084719c:     	add	x0, x0, #0x138
1008471a0:     	bl	0x100b3cd5c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1008471a4:     	b	0x100846a2c <_js_json_stringify_full+0xdac>
1008471a8:     	add	x1, sp, #0x48
1008471ac:     	mov.16b	v0, v8
1008471b0:     	mov	w0, #0x0                ; =0
1008471b4:     	bl	0x10050973c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
1008471b8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008471bc:     	add	x0, x0, #0xdc0
1008471c0:     	ldr	x8, [x0]
1008471c4:     	blr	x8
1008471c8:     	strb	wzr, [x0]
1008471cc:     	b	0x100846b70 <_js_json_stringify_full+0xef0>
1008471d0:     	mov	x0, x25
1008471d4:     	mov	w1, #0x1                ; =1
1008471d8:     	bl	0x100b5f3c8 <_mi_malloc_aligned>
1008471dc:     	mov	x26, x0
1008471e0:     	mov	w0, #0x1                ; =1
1008471e4:     	cbz	x26, 0x100847180 <_js_json_stringify_full+0x1500>
1008471e8:     	mov	x0, x26
1008471ec:     	mov	x1, x23
1008471f0:     	mov	x2, x25
1008471f4:     	bl	0x100b61fec <_writev+0x100b61fec>
1008471f8:     	mov	x22, x25
1008471fc:     	b	0x100846700 <_js_json_stringify_full+0xa80>
100847200:     	cmp	w11, #0x8
100847204:     	b.eq	0x1008472d0 <_js_json_stringify_full+0x1650>
100847208:     	cmp	w11, #0x9
10084720c:     	b.eq	0x1008472e0 <_js_json_stringify_full+0x1660>
100847210:     	cmp	w11, #0xa
100847214:     	b.ne	0x10084725c <_js_json_stringify_full+0x15dc>
100847218:     	mov	w10, #0x6e              ; =110
10084721c:     	b	0x1008472e4 <_js_json_stringify_full+0x1664>
100847220:     	mov	x22, x0
100847224:     	and	x0, x19, #0xffffffffffff
100847228:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084722c:     	cbz	x0, 0x100847308 <_js_json_stringify_full+0x1688>
100847230:     	ldr	w20, [x0]
100847234:     	cmp	w20, #0x4
100847238:     	b.hi	0x100846258 <_js_json_stringify_full+0x5d8>
10084723c:     	ldr	w8, [x0, #0x4]
100847240:     	cmp	w20, w8
100847244:     	b.hi	0x100846258 <_js_json_stringify_full+0x5d8>
100847248:     	b	0x10084730c <_js_json_stringify_full+0x168c>
10084724c:     	cmp	w11, #0x22
100847250:     	b.eq	0x1008472e4 <_js_json_stringify_full+0x1664>
100847254:     	cmp	w11, #0x5c
100847258:     	b.eq	0x1008472e4 <_js_json_stringify_full+0x1664>
10084725c:     	cmp	x12, #0x3
100847260:     	mov	w11, #0x20              ; =32
100847264:     	ccmp	w10, w11, #0x8, ls
100847268:     	b.lt	0x100846194 <_js_json_stringify_full+0x514>
10084726c:     	add	x8, sp, #0x80
100847270:     	strb	w10, [x8, x12]
100847274:     	add	x12, x12, #0x1
100847278:     	b	0x100845e84 <_js_json_stringify_full+0x204>
10084727c:     	mov	x1, x0
100847280:     	and	x0, x19, #0xffffffffffff
100847284:     	mov	x22, x1
100847288:     	bl	0x1004f8e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
10084728c:     	cmp	x0, #0x1
100847290:     	b.ne	0x1008473b4 <_js_json_stringify_full+0x1734>
100847294:     	mov	x20, x1
100847298:     	b	0x100847128 <_js_json_stringify_full+0x14a8>
10084729c:     	ldrb	w9, [x8, #0x118]
1008472a0:     	cbz	w9, 0x1008474dc <_js_json_stringify_full+0x185c>
1008472a4:     	ldr	x9, [x8, #0x110]
1008472a8:     	cmp	x9, x1
1008472ac:     	b.ne	0x1008474dc <_js_json_stringify_full+0x185c>
1008472b0:     	ldr	x9, [x8, #0xf0]
1008472b4:     	cmp	x9, x23
1008472b8:     	b.hi	0x1008474dc <_js_json_stringify_full+0x185c>
1008472bc:     	ldr	x9, [x8, #0xf8]
1008472c0:     	cmp	x9, x23
1008472c4:     	b.ls	0x1008474dc <_js_json_stringify_full+0x185c>
1008472c8:     	add	x9, x8, #0xf0
1008472cc:     	b	0x1008476e8 <_js_json_stringify_full+0x1a68>
1008472d0:     	mov	w10, #0x62              ; =98
1008472d4:     	b	0x1008472e4 <_js_json_stringify_full+0x1664>
1008472d8:     	mov	w10, #0x66              ; =102
1008472dc:     	b	0x1008472e4 <_js_json_stringify_full+0x1664>
1008472e0:     	mov	w10, #0x74              ; =116
1008472e4:     	cmp	x12, #0x2
1008472e8:     	b.hi	0x100846194 <_js_json_stringify_full+0x514>
1008472ec:     	add	x8, sp, #0x80
1008472f0:     	add	x8, x8, x12
1008472f4:     	add	x12, x12, #0x2
1008472f8:     	mov	w11, #0x5c              ; =92
1008472fc:     	strb	w11, [x8]
100847300:     	strb	w10, [x8, #0x1]
100847304:     	b	0x100845e84 <_js_json_stringify_full+0x204>
100847308:     	mov	x20, #0x0               ; =0
10084730c:     	ldr	w8, [x22, #0x4]
100847310:     	lsl	x9, x20, #3
100847314:     	add	x9, x9, #0x18
100847318:     	cmp	x9, x8
10084731c:     	b.hi	0x100846258 <_js_json_stringify_full+0x5d8>
100847320:     	ldr	w8, [x25, #0x4]
100847324:     	mov	w9, #-0x40000000        ; =-1073741824
100847328:     	cmp	w8, w9
10084732c:     	csel	w8, w8, wzr, lt
100847330:     	mov	x22, x0
100847334:     	mov	x0, x8
100847338:     	bl	0x1005e58a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084733c:     	mov	w9, #0x2                ; =2
100847340:     	cmp	w1, #0x2
100847344:     	csel	w10, w1, w9, hi
100847348:     	tst	w0, #0x1
10084734c:     	csel	x8, x10, x9, ne
100847350:     	cmp	x20, x8
100847354:     	b.hi	0x100846258 <_js_json_stringify_full+0x5d8>
100847358:     	cbz	x20, 0x100847718 <_js_json_stringify_full+0x1a98>
10084735c:     	mov	x0, x22
100847360:     	mov	x1, x20
100847364:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100847368:     	tbz	w0, #0x0, 0x100846258 <_js_json_stringify_full+0x5d8>
10084736c:     	cmp	x20, #0x1
100847370:     	b.eq	0x1008477b4 <_js_json_stringify_full+0x1b34>
100847374:     	cmp	x20, #0x2
100847378:     	b.ne	0x100847870 <_js_json_stringify_full+0x1bf0>
10084737c:     	mov	x22, #0x0               ; =0
100847380:     	add	x25, x25, #0x10
100847384:     	mov	w8, #0x1                ; =1
100847388:     	mov	x26, x8
10084738c:     	ldr	x1, [x25, x22, lsl #3]
100847390:     	add	x0, sp, #0x80
100847394:     	bl	0x1004efe14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
100847398:     	ldr	w8, [sp, #0x80]
10084739c:     	cmn	w8, #0x1
1008473a0:     	b.ne	0x100847858 <_js_json_stringify_full+0x1bd8>
1008473a4:     	mov	w8, #0x0                ; =0
1008473a8:     	mov	w22, #0x1               ; =1
1008473ac:     	tbnz	w26, #0x0, 0x100847388 <_js_json_stringify_full+0x1708>
1008473b0:     	b	0x100847870 <_js_json_stringify_full+0x1bf0>
1008473b4:     	and	x0, x19, #0xffffffffffff
1008473b8:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1008473bc:     	cbz	x0, 0x100847448 <_js_json_stringify_full+0x17c8>
1008473c0:     	ldr	w20, [x0]
1008473c4:     	cbz	w20, 0x100847448 <_js_json_stringify_full+0x17c8>
1008473c8:     	cmp	w20, #0x8
1008473cc:     	b.hi	0x100846224 <_js_json_stringify_full+0x5a4>
1008473d0:     	ldr	w8, [x0, #0x4]
1008473d4:     	cmp	w20, w8
1008473d8:     	b.hi	0x100846224 <_js_json_stringify_full+0x5a4>
1008473dc:     	ldr	w8, [x22, #0x4]
1008473e0:     	lsl	x9, x20, #3
1008473e4:     	add	x9, x9, #0x18
1008473e8:     	cmp	x9, x8
1008473ec:     	b.hi	0x100846224 <_js_json_stringify_full+0x5a4>
1008473f0:     	ldr	w8, [x25, #0x4]
1008473f4:     	mov	w9, #-0x40000000        ; =-1073741824
1008473f8:     	cmp	w8, w9
1008473fc:     	csel	w8, w8, wzr, lt
100847400:     	mov	x22, x0
100847404:     	mov	x0, x8
100847408:     	bl	0x1005e58a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084740c:     	mov	w9, #0x2                ; =2
100847410:     	cmp	w1, #0x2
100847414:     	csel	w10, w1, w9, hi
100847418:     	tst	w0, #0x1
10084741c:     	csel	w8, w10, w9, ne
100847420:     	cmp	w20, w8
100847424:     	b.hi	0x100846224 <_js_json_stringify_full+0x5a4>
100847428:     	mov	x0, x22
10084742c:     	mov	x1, x20
100847430:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100847434:     	cbz	w0, 0x100846224 <_js_json_stringify_full+0x5a4>
100847438:     	and	x0, x19, #0xffffffffffff
10084743c:     	mov	x1, x20
100847440:     	bl	0x1004f7f40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
100847444:     	b	0x100847450 <_js_json_stringify_full+0x17d0>
100847448:     	and	x0, x19, #0xffffffffffff
10084744c:     	bl	0x1004f8cc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
100847450:     	mov	x20, x1
100847454:     	tbz	w0, #0x0, 0x100846224 <_js_json_stringify_full+0x5a4>
100847458:     	b	0x100847128 <_js_json_stringify_full+0x14a8>
10084745c:     	add	x9, x8, #0x60
100847460:     	b	0x1008476e8 <_js_json_stringify_full+0x1a68>
100847464:     	bl	0x100b3f53c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100847468:     	lsr	x1, x23, #20
10084746c:     	ldr	x8, [x0, #0x10]
100847470:     	ldrb	w9, [x8]
100847474:     	cmp	w9, #0x2
100847478:     	b.eq	0x100846808 <_js_json_stringify_full+0xb88>
10084747c:     	ldr	x9, [x8, #0x8]
100847480:     	ldr	x10, [x8, #0x28]
100847484:     	sub	x9, x1, x9
100847488:     	cmp	x9, x10
10084748c:     	b.hs	0x1008474d0 <_js_json_stringify_full+0x1850>
100847490:     	ldr	x10, [x8, #0x20]
100847494:     	mov	w11, #0x28              ; =40
100847498:     	madd	x9, x9, x11, x10
10084749c:     	ldr	x10, [x9]
1008474a0:     	ldr	x11, [x8, #0x10]
1008474a4:     	cmp	x10, x11
1008474a8:     	b.ne	0x1008474dc <_js_json_stringify_full+0x185c>
1008474ac:     	ldp	x10, x11, [x9, #0x8]
1008474b0:     	cmp	x10, x23
1008474b4:     	ccmp	x11, x23, #0x0, ls
1008474b8:     	b.ls	0x1008474dc <_js_json_stringify_full+0x185c>
1008474bc:     	ldr	x10, [x8, #0x30]
1008474c0:     	add	x10, x10, #0x1
1008474c4:     	str	x10, [x8, #0x30]
1008474c8:     	add	x8, x9, #0x21
1008474cc:     	b	0x1008476f8 <_js_json_stringify_full+0x1a78>
1008474d0:     	ldr	x9, [x8, #0x58]
1008474d4:     	add	x9, x9, #0x1
1008474d8:     	str	x9, [x8, #0x58]
1008474dc:     	ldr	x9, [x8, #0x38]
1008474e0:     	add	x9, x9, #0x1
1008474e4:     	str	x9, [x8, #0x38]
1008474e8:     	mov	x0, x23
1008474ec:     	bl	0x10051e508 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1008474f0:     	and	w8, w0, #0xff
1008474f4:     	cbz	w8, 0x100847514 <_js_json_stringify_full+0x1894>
1008474f8:     	ldurb	w8, [x23, #-0x8]
1008474fc:     	ldurb	w9, [x23, #-0x7]
100847500:     	mov	w10, #0x82              ; =130
100847504:     	and	w9, w9, w10
100847508:     	cmp	w9, #0x2
10084750c:     	ccmp	w8, #0x1, #0x0, eq
100847510:     	b.eq	0x1008475a8 <_js_json_stringify_full+0x1928>
100847514:     	mov	x0, x23
100847518:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084751c:     	mov	x24, x0
100847520:     	cbz	x0, 0x10084754c <_js_json_stringify_full+0x18cc>
100847524:     	ldrb	w8, [x24]
100847528:     	cmp	w8, #0x1
10084752c:     	b.ne	0x10084756c <_js_json_stringify_full+0x18ec>
100847530:     	ldrsb	w8, [x24, #0x1]
100847534:     	tbnz	w8, #0x1f, 0x1008475d0 <_js_json_stringify_full+0x1950>
100847538:     	mov	x0, x24
10084753c:     	ldp	w9, w8, [x23]
100847540:     	cmp	w9, w8
100847544:     	b.hi	0x100847654 <_js_json_stringify_full+0x19d4>
100847548:     	b	0x10084766c <_js_json_stringify_full+0x19ec>
10084754c:     	mov	x0, x23
100847550:     	bl	0x1005893b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100847554:     	tbnz	w0, #0x0, 0x100847564 <_js_json_stringify_full+0x18e4>
100847558:     	mov	x0, x23
10084755c:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100847560:     	tbz	w0, #0x0, 0x1008468a8 <_js_json_stringify_full+0xc28>
100847564:     	mov	x0, #0x0                ; =0
100847568:     	b	0x100847644 <_js_json_stringify_full+0x19c4>
10084756c:     	mov	x0, x24
100847570:     	cmp	w8, #0x1
100847574:     	b.eq	0x100847644 <_js_json_stringify_full+0x19c4>
100847578:     	cmp	w8, #0x9
10084757c:     	b.ne	0x1008468a8 <_js_json_stringify_full+0xc28>
100847580:     	ldr	w8, [x23, #0x4]
100847584:     	mov	w9, #0x5841             ; =22593
100847588:     	movk	w9, #0x4c5a, lsl #16
10084758c:     	cmp	w8, w9
100847590:     	b.ne	0x1008468a8 <_js_json_stringify_full+0xc28>
100847594:     	mov	x0, x23
100847598:     	bl	0x100375e50 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
10084759c:     	mov	x23, x0
1008475a0:     	cbnz	x0, 0x100847694 <_js_json_stringify_full+0x1a14>
1008475a4:     	b	0x1008468a8 <_js_json_stringify_full+0xc28>
1008475a8:     	ldr	w8, [x23]
1008475ac:     	mov	w9, #0xe100             ; =57600
1008475b0:     	movk	w9, #0x5f5, lsl #16
1008475b4:     	orr	w9, w9, #0x1
1008475b8:     	cmp	w8, w9
1008475bc:     	b.hs	0x100847514 <_js_json_stringify_full+0x1894>
1008475c0:     	ldr	w9, [x23, #0x4]
1008475c4:     	cmp	w8, w9
1008475c8:     	b.ls	0x100847694 <_js_json_stringify_full+0x1a14>
1008475cc:     	b	0x100847514 <_js_json_stringify_full+0x1894>
1008475d0:     	ldr	x23, [x24, #0x8]
1008475d4:     	mov	x0, x23
1008475d8:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008475dc:     	cbz	x0, 0x1008468a8 <_js_json_stringify_full+0xc28>
1008475e0:     	ldrb	w8, [x0]
1008475e4:     	cmp	w8, #0x1
1008475e8:     	b.ne	0x1008468a8 <_js_json_stringify_full+0xc28>
1008475ec:     	ldrsb	w8, [x0, #0x1]
1008475f0:     	tbz	w8, #0x1f, 0x10084753c <_js_json_stringify_full+0x18bc>
1008475f4:     	mov	w26, #0x1               ; =1
1008475f8:     	ldr	x23, [x0, #0x8]
1008475fc:     	mov	x0, x23
100847600:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847604:     	cbz	x0, 0x1008468a8 <_js_json_stringify_full+0xc28>
100847608:     	ldrb	w8, [x0]
10084760c:     	cmp	w8, #0x1
100847610:     	b.ne	0x1008468a8 <_js_json_stringify_full+0xc28>
100847614:     	cmp	w26, #0x3f
100847618:     	b.hi	0x1008468a8 <_js_json_stringify_full+0xc28>
10084761c:     	add	w26, w26, #0x1
100847620:     	ldrsb	w8, [x0, #0x1]
100847624:     	tbnz	w8, #0x1f, 0x1008475f8 <_js_json_stringify_full+0x1978>
100847628:     	str	x23, [x24, #0x8]
10084762c:     	ldrb	w8, [x24, #0x1]
100847630:     	orr	w8, w8, #0x80
100847634:     	strb	w8, [x24, #0x1]
100847638:     	ldrb	w8, [x0]
10084763c:     	cmp	w8, #0x1
100847640:     	b.ne	0x100847578 <_js_json_stringify_full+0x18f8>
100847644:     	ldp	w9, w8, [x23]
100847648:     	cmp	w9, w8
10084764c:     	b.ls	0x10084766c <_js_json_stringify_full+0x19ec>
100847650:     	cbz	x24, 0x10084767c <_js_json_stringify_full+0x19fc>
100847654:     	ldr	w9, [x0, #0x4]
100847658:     	ubfiz	x8, x8, #3, #32
10084765c:     	add	x8, x8, #0x10
100847660:     	cmp	x8, x9
100847664:     	b.eq	0x100847694 <_js_json_stringify_full+0x1a14>
100847668:     	b	0x10084767c <_js_json_stringify_full+0x19fc>
10084766c:     	mov	w8, #0xe100             ; =57600
100847670:     	movk	w8, #0x5f5, lsl #16
100847674:     	cmp	w9, w8
100847678:     	b.ls	0x100847694 <_js_json_stringify_full+0x1a14>
10084767c:     	mov	x0, x23
100847680:     	bl	0x1005893b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100847684:     	tbnz	w0, #0x0, 0x100847694 <_js_json_stringify_full+0x1a14>
100847688:     	mov	x0, x23
10084768c:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100847690:     	tbz	w0, #0x0, 0x1008468a8 <_js_json_stringify_full+0xc28>
100847694:     	ldp	w8, w9, [x23]
100847698:     	sub	w10, w9, #0x1
10084769c:     	mov	w11, #0x270f            ; =9999
1008476a0:     	cmp	w10, w11
1008476a4:     	ccmp	w8, w9, #0x2, lo
1008476a8:     	b.hi	0x1008468a8 <_js_json_stringify_full+0xc28>
1008476ac:     	and	x8, x21, #0xffffffffffff
1008476b0:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008476b4:     	cmp	x25, x9
1008476b8:     	csel	x1, x8, x21, eq
1008476bc:     	add	x0, sp, #0x30
1008476c0:     	bl	0x1004ffc78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
1008476c4:     	ldr	x25, [sp, #0x30]
1008476c8:     	cmn	x25, #0x1
1008476cc:     	cset	w24, eq
1008476d0:     	cmp	x27, #0x1
1008476d4:     	cset	w8, hi
1008476d8:     	tst	w8, w24
1008476dc:     	b.ne	0x1008468c4 <_js_json_stringify_full+0xc44>
1008476e0:     	b	0x100846934 <_js_json_stringify_full+0xcb4>
1008476e4:     	add	x9, x8, #0x90
1008476e8:     	ldr	x10, [x8, #0x30]
1008476ec:     	add	x10, x10, #0x1
1008476f0:     	str	x10, [x8, #0x30]
1008476f4:     	add	x8, x9, #0x19
1008476f8:     	ldrb	w8, [x8]
1008476fc:     	cmp	w8, #0xff
100847700:     	b.ne	0x1008474f4 <_js_json_stringify_full+0x1874>
100847704:     	b	0x1008474e8 <_js_json_stringify_full+0x1868>
100847708:     	mov	x0, x23
10084770c:     	bl	0x100b1e6c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847710:     	cbnz	x0, 0x100846a50 <_js_json_stringify_full+0xdd0>
100847714:     	b	0x100847890 <_js_json_stringify_full+0x1c10>
100847718:     	and	x0, x19, #0xffffffffffff
10084771c:     	bl	0x1004f7d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
100847720:     	mov	w0, w0
100847724:     	mov	x20, #0x7d7b            ; =32123
100847728:     	movk	x20, #0x200, lsl #32
10084772c:     	movk	x20, #0x7ff9, lsl #48
100847730:     	tbz	w0, #0x0, 0x100846258 <_js_json_stringify_full+0x5d8>
100847734:     	b	0x100847128 <_js_json_stringify_full+0x14a8>
100847738:     	mov	x19, x0
10084773c:     	mov	x0, x23
100847740:     	bl	0x100b1e6c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847744:     	mov	x23, x0
100847748:     	mov	x0, x19
10084774c:     	cbnz	x23, 0x100847034 <_js_json_stringify_full+0x13b4>
100847750:     	b	0x100847830 <_js_json_stringify_full+0x1bb0>
100847754:     	bl	0x100b1e824 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100847758:     	cbnz	x0, 0x100846978 <_js_json_stringify_full+0xcf8>
10084775c:     	b	0x100847890 <_js_json_stringify_full+0x1c10>
100847760:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100847764:     	add	x0, x0, #0x440
100847768:     	bl	0x100b1286c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084776c:     	cmp	w8, #0x1
100847770:     	b.ne	0x100847890 <_js_json_stringify_full+0x1c10>
100847774:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847778:     	add	x1, x1, #0x998
10084777c:     	mov	x19, x0
100847780:     	bl	0x100a2059c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847784:     	mov	x0, x19
100847788:     	strb	wzr, [x19, #0x20]
10084778c:     	ldr	x8, [x19]
100847790:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100847794:     	cmp	x8, x9
100847798:     	b.lo	0x100846b98 <_js_json_stringify_full+0xf18>
10084779c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008477a0:     	add	x0, x0, #0xea8
1008477a4:     	bl	0x100b1289c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1008477a8:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008477ac:     	add	x0, x0, #0xec0
1008477b0:     	bl	0x100b1286c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008477b4:     	and	x0, x19, #0xffffffffffff
1008477b8:     	bl	0x1004ef9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
1008477bc:     	mov	x20, x1
1008477c0:     	tbz	w0, #0x0, 0x100846258 <_js_json_stringify_full+0x5d8>
1008477c4:     	b	0x100847128 <_js_json_stringify_full+0x14a8>
1008477c8:     	mov	x0, x23
1008477cc:     	bl	0x100b1e6c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008477d0:     	mov	x23, x0
1008477d4:     	cbnz	x0, 0x100846ee4 <_js_json_stringify_full+0x1264>
1008477d8:     	b	0x100847830 <_js_json_stringify_full+0x1bb0>
1008477dc:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
1008477e0:     	add	x0, x0, #0xd70
1008477e4:     	bl	0x100b1289c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1008477e8:     	bl	0x100b4bad4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
1008477ec:     	cmp	w8, #0x2
1008477f0:     	b.eq	0x100847890 <_js_json_stringify_full+0x1c10>
1008477f4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008477f8:     	add	x1, x1, #0x998
1008477fc:     	mov	x19, x0
100847800:     	bl	0x100a2059c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847804:     	mov	x0, x19
100847808:     	strb	wzr, [x19, #0x20]
10084780c:     	ldr	x8, [x19]
100847810:     	cbz	x8, 0x100846ed0 <_js_json_stringify_full+0x1250>
100847814:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847818:     	add	x0, x0, #0xe90
10084781c:     	bl	0x100b1286c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847820:     	mov	x0, x23
100847824:     	bl	0x100b1e6c4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847828:     	mov	x23, x0
10084782c:     	cbnz	x0, 0x100846e00 <_js_json_stringify_full+0x1180>
100847830:     	cbz	x22, 0x100847890 <_js_json_stringify_full+0x1c10>
100847834:     	mov	x0, x19
100847838:     	bl	0x100b5f140 <_mi_free>
10084783c:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847840:     	add	x0, x0, #0xc18
100847844:     	bl	0x100b5879c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100847848:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0x8f4>
10084784c:     	add	x0, x0, #0x630
100847850:     	mov	w1, #0xf                ; =15
100847854:     	bl	0x100b4ba9c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100847858:     	and	x0, x19, #0xffffffffffff
10084785c:     	add	x2, sp, #0x80
100847860:     	mov	x1, x22
100847864:     	bl	0x1004f01c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
100847868:     	tbnz	w0, #0x0, 0x100847294 <_js_json_stringify_full+0x1614>
10084786c:     	mov	w20, #0x2               ; =2
100847870:     	and	x0, x19, #0xffffffffffff
100847874:     	mov	x1, x20
100847878:     	bl	0x1004ee840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
10084787c:     	mov	x20, x1
100847880:     	tbz	w0, #0x0, 0x100846258 <_js_json_stringify_full+0x5d8>
100847884:     	b	0x100847128 <_js_json_stringify_full+0x14a8>
100847888:     	cmp	w8, #0x2
10084788c:     	b.ne	0x1008478b8 <_js_json_stringify_full+0x1c38>
100847890:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847894:     	add	x0, x0, #0xc18
100847898:     	bl	0x100b5879c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084789c:     	adrp	x0, 0x100f2b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x1d8>
1008478a0:     	add	x0, x0, #0x800
1008478a4:     	bl	0x100b12930 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
1008478a8:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0x8f4>
1008478ac:     	add	x0, x0, #0x367
1008478b0:     	mov	w1, #0xb                ; =11
1008478b4:     	bl	0x100b4ba9c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
1008478b8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008478bc:     	add	x1, x1, #0x998
1008478c0:     	mov	x19, x0
1008478c4:     	bl	0x100a2059c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008478c8:     	mov	x0, x19
1008478cc:     	strb	wzr, [x19, #0x20]
1008478d0:     	ldr	x8, [x19]
1008478d4:     	cbz	x8, 0x100846dec <_js_json_stringify_full+0x116c>
1008478d8:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008478dc:     	add	x0, x0, #0xe78
1008478e0:     	bl	0x100b1286c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008478e4:     	mov	w0, #0x1                ; =1
1008478e8:     	mov	x1, x24
1008478ec:     	bl	0x100b124c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008478f0:     	mov	w0, #0x1                ; =1
1008478f4:     	mov	x1, x22
1008478f8:     	bl	0x100b124c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008478fc:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100847900:     	add	x2, x2, #0x3c8
100847904:     	mov	w0, #0x5                ; =5
100847908:     	mov	w1, #0x5                ; =5
10084790c:     	bl	0x100b129cc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
