
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/compact-json-token-scan-r35/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100844b94 <_js_json_parse>:
100844b94:     	stp	x29, x30, [sp, #-0x10]!
100844b98:     	mov	x29, sp
100844b9c:     	cbz	x0, 0x100844bf4 <_js_json_parse+0x60>
100844ba0:     	ldr	w1, [x0, #0x4]
100844ba4:     	cmp	w1, #0x2
100844ba8:     	b.eq	0x100844bb8 <_js_json_parse+0x24>
100844bac:     	cbz	w1, 0x100844bf4 <_js_json_parse+0x60>
100844bb0:     	ldrb	w8, [x0, #0x14]
100844bb4:     	b	0x100844bd8 <_js_json_parse+0x44>
100844bb8:     	ldrb	w8, [x0, #0x14]
100844bbc:     	cmp	w8, #0x7b
100844bc0:     	b.ne	0x100844bd8 <_js_json_parse+0x44>
100844bc4:     	ldrb	w8, [x0, #0x15]
100844bc8:     	cmp	w8, #0x7d
100844bcc:     	b.ne	0x100844be4 <_js_json_parse+0x50>
100844bd0:     	ldp	x29, x30, [sp], #0x10
100844bd4:     	b	0x1004ed3c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100844bd8:     	orr	w8, w8, #0x20
100844bdc:     	cmp	w8, #0x7b
100844be0:     	b.ne	0x100844bec <_js_json_parse+0x58>
100844be4:     	ldp	x29, x30, [sp], #0x10
100844be8:     	b	0x100506688 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
100844bec:     	ldp	x29, x30, [sp], #0x10
100844bf0:     	b	0x100508d04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100844bf4:     	adrp	x0, 0x100c76000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x741c>
100844bf8:     	add	x0, x0, #0xc1
100844bfc:     	mov	w1, #0x1c               ; =28
100844c00:     	bl	0x100509138 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
