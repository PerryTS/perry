
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/compact-json-token-scan-r35/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007be410 <_js_array_get_f64>:
1007be410:     	sub	sp, sp, #0x70
1007be414:     	stp	x26, x25, [sp, #0x20]
1007be418:     	stp	x24, x23, [sp, #0x30]
1007be41c:     	stp	x22, x21, [sp, #0x40]
1007be420:     	stp	x20, x19, [sp, #0x50]
1007be424:     	stp	x29, x30, [sp, #0x60]
1007be428:     	add	x29, sp, #0x60
1007be42c:     	mov	x19, x1
1007be430:     	mov	x22, x0
1007be434:     	lsr	x25, x0, #51
1007be438:     	mov	x20, x0
1007be43c:     	cmp	x25, #0xfff
1007be440:     	b.lo	0x1007be45c <_js_array_get_f64+0x4c>
1007be444:     	mov	w8, #0x7ffc             ; =32764
1007be448:     	cmp	x8, x22, lsr #48
1007be44c:     	b.ne	0x1007be458 <_js_array_get_f64+0x48>
1007be450:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007be454:     	b	0x1007beb08 <_js_array_get_f64+0x6f8>
1007be458:     	and	x20, x22, #0xffffffffffff
1007be45c:     	lsr	x8, x20, #3
1007be460:     	cmp	x8, #0x200
1007be464:     	b.ls	0x1007be49c <_js_array_get_f64+0x8c>
1007be468:     	ldurb	w8, [x20, #-0x8]
1007be46c:     	cmp	w8, #0x9
1007be470:     	b.ne	0x1007be49c <_js_array_get_f64+0x8c>
1007be474:     	ldr	w8, [x20, #0x4]
1007be478:     	mov	w9, #0x5841             ; =22593
1007be47c:     	movk	w9, #0x4c5a, lsl #16
1007be480:     	cmp	w8, w9
1007be484:     	b.ne	0x1007be49c <_js_array_get_f64+0x8c>
1007be488:     	mov	x0, x20
1007be48c:     	mov	x1, x19
1007be490:     	bl	0x100688084 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007be494:     	fmov	d0, x0
1007be498:     	b	0x1007beb0c <_js_array_get_f64+0x6fc>
1007be49c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be4a0:     	b.lo	0x1007be550 <_js_array_get_f64+0x140>
1007be4a4:     	tst	x20, #0xffff800000000000
1007be4a8:     	mov	w8, #0x1000             ; =4096
1007be4ac:     	ccmp	x20, x8, #0x0, eq
1007be4b0:     	b.lo	0x1007be550 <_js_array_get_f64+0x140>
1007be4b4:     	ldurb	w24, [x20, #-0x8]
1007be4b8:     	ldurh	w23, [x20, #-0x6]
1007be4bc:     	cmp	w24, #0xa
1007be4c0:     	b.gt	0x1007be668 <_js_array_get_f64+0x258>
1007be4c4:     	cmp	w24, #0x2
1007be4c8:     	b.eq	0x1007be6f0 <_js_array_get_f64+0x2e0>
1007be4cc:     	cmp	w24, #0x8
1007be4d0:     	b.ne	0x1007be558 <_js_array_get_f64+0x148>
1007be4d4:     	mov	x0, x20
1007be4d8:     	bl	0x100305c68 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007be4dc:     	cbz	w0, 0x1007be780 <_js_array_get_f64+0x370>
1007be4e0:     	mov	x22, #0x1               ; =1
1007be4e4:     	movk	x22, #0x7ffc, lsl #48
1007be4e8:     	lsr	x8, x20, #51
1007be4ec:     	cmp	x8, #0xfff
1007be4f0:     	b.lo	0x1007be504 <_js_array_get_f64+0xf4>
1007be4f4:     	mov	w8, #0x7ffc             ; =32764
1007be4f8:     	cmp	x8, x20, lsr #48
1007be4fc:     	b.eq	0x1007beb08 <_js_array_get_f64+0x6f8>
1007be500:     	and	x20, x20, #0xffffffffffff
1007be504:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be508:     	b.lo	0x1007be528 <_js_array_get_f64+0x118>
1007be50c:     	tst	x20, #0xffff800000000000
1007be510:     	mov	w8, #0x1000             ; =4096
1007be514:     	ccmp	x20, x8, #0x0, eq
1007be518:     	b.lo	0x1007be528 <_js_array_get_f64+0x118>
1007be51c:     	ldurb	w8, [x20, #-0x8]
1007be520:     	cmp	w8, #0x2
1007be524:     	b.eq	0x1007bedf4 <_js_array_get_f64+0x9e4>
1007be528:     	cbz	x20, 0x1007beb08 <_js_array_get_f64+0x6f8>
1007be52c:     	mov	x0, x20
1007be530:     	mov	x1, x19
1007be534:     	bl	0x100305e18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007be538:     	cmp	w0, #0x1
1007be53c:     	b.ne	0x1007beb08 <_js_array_get_f64+0x6f8>
1007be540:     	ldr	x8, [x20, #0x8]
1007be544:     	ubfiz	x9, x1, #4, #32
1007be548:     	ldr	x22, [x8, x9]
1007be54c:     	b	0x1007beb08 <_js_array_get_f64+0x6f8>
1007be550:     	mov	w23, #0x0               ; =0
1007be554:     	mov	w24, #0x0               ; =0
1007be558:     	mov	x21, x22
1007be55c:     	cmp	x25, #0xfff
1007be560:     	b.lo	0x1007be578 <_js_array_get_f64+0x168>
1007be564:     	mov	w8, #0x7ffc             ; =32764
1007be568:     	cmp	x8, x22, lsr #48
1007be56c:     	b.eq	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be570:     	ands	x21, x22, #0xffffffffffff
1007be574:     	b.eq	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be578:     	and	x8, x21, #0xfffffffffff00000
1007be57c:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007be580:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007be584:     	cmp	x9, x10
1007be588:     	ccmp	x8, #0x0, #0x4, lo
1007be58c:     	b.eq	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be590:     	tst	x21, #0x3
1007be594:     	ccmp	x21, #0x7, #0x0, eq
1007be598:     	b.ls	0x1007be848 <_js_array_get_f64+0x438>
1007be59c:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be5a0:     	ldr	x8, [x8, #0x48]
1007be5a4:     	cmn	x8, #0x1
1007be5a8:     	b.eq	0x1007be798 <_js_array_get_f64+0x388>
1007be5ac:     	mrs	x9, TPIDRRO_EL0
1007be5b0:     	and	x9, x9, #0xfffffffffffffff8
1007be5b4:     	ldr	x0, [x9, x8, lsl #3]
1007be5b8:     	cbz	x0, 0x1007be798 <_js_array_get_f64+0x388>
1007be5bc:     	lsr	x1, x21, #20
1007be5c0:     	ldr	x8, [x0, #0x10]
1007be5c4:     	ldrb	w9, [x8]
1007be5c8:     	cmp	w9, #0x2
1007be5cc:     	b.ne	0x1007be7b0 <_js_array_get_f64+0x3a0>
1007be5d0:     	ldrb	w9, [x8, #0x88]
1007be5d4:     	tbz	w9, #0x0, 0x1007be5f4 <_js_array_get_f64+0x1e4>
1007be5d8:     	ldr	x9, [x8, #0x80]
1007be5dc:     	cmp	x9, x1
1007be5e0:     	b.ne	0x1007be5f4 <_js_array_get_f64+0x1e4>
1007be5e4:     	ldp	x9, x10, [x8, #0x60]
1007be5e8:     	cmp	x9, x21
1007be5ec:     	ccmp	x10, x21, #0x0, ls
1007be5f0:     	b.hi	0x1007be790 <_js_array_get_f64+0x380>
1007be5f4:     	ldrb	w9, [x8, #0xb8]
1007be5f8:     	cbz	w9, 0x1007be618 <_js_array_get_f64+0x208>
1007be5fc:     	ldr	x9, [x8, #0xb0]
1007be600:     	cmp	x9, x1
1007be604:     	b.ne	0x1007be618 <_js_array_get_f64+0x208>
1007be608:     	ldp	x9, x10, [x8, #0x90]
1007be60c:     	cmp	x9, x21
1007be610:     	ccmp	x10, x21, #0x0, ls
1007be614:     	b.hi	0x1007bec58 <_js_array_get_f64+0x848>
1007be618:     	ldrb	w9, [x8, #0xe8]
1007be61c:     	cbz	w9, 0x1007be63c <_js_array_get_f64+0x22c>
1007be620:     	ldr	x9, [x8, #0xe0]
1007be624:     	cmp	x9, x1
1007be628:     	b.ne	0x1007be63c <_js_array_get_f64+0x22c>
1007be62c:     	ldp	x9, x10, [x8, #0xc0]
1007be630:     	cmp	x9, x21
1007be634:     	ccmp	x10, x21, #0x0, ls
1007be638:     	b.hi	0x1007bed40 <_js_array_get_f64+0x930>
1007be63c:     	ldrb	w9, [x8, #0x118]
1007be640:     	cbz	w9, 0x1007be810 <_js_array_get_f64+0x400>
1007be644:     	ldr	x9, [x8, #0x110]
1007be648:     	cmp	x9, x1
1007be64c:     	b.ne	0x1007be810 <_js_array_get_f64+0x400>
1007be650:     	ldp	x9, x10, [x8, #0xf0]
1007be654:     	cmp	x9, x21
1007be658:     	ccmp	x10, x21, #0x0, ls
1007be65c:     	b.ls	0x1007be810 <_js_array_get_f64+0x400>
1007be660:     	add	x9, x8, #0xf0
1007be664:     	b	0x1007bed44 <_js_array_get_f64+0x934>
1007be668:     	cmp	w24, #0xb
1007be66c:     	b.eq	0x1007be708 <_js_array_get_f64+0x2f8>
1007be670:     	cmp	w24, #0xc
1007be674:     	b.ne	0x1007be558 <_js_array_get_f64+0x148>
1007be678:     	mov	x0, x20
1007be67c:     	bl	0x10030b9f8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007be680:     	cbz	w0, 0x1007be788 <_js_array_get_f64+0x378>
1007be684:     	mov	x22, #0x1               ; =1
1007be688:     	movk	x22, #0x7ffc, lsl #48
1007be68c:     	lsr	x8, x20, #51
1007be690:     	cmp	x8, #0xfff
1007be694:     	b.lo	0x1007be6a8 <_js_array_get_f64+0x298>
1007be698:     	mov	w8, #0x7ffc             ; =32764
1007be69c:     	cmp	x8, x20, lsr #48
1007be6a0:     	b.eq	0x1007beb08 <_js_array_get_f64+0x6f8>
1007be6a4:     	and	x20, x20, #0xffffffffffff
1007be6a8:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be6ac:     	b.lo	0x1007be6cc <_js_array_get_f64+0x2bc>
1007be6b0:     	tst	x20, #0xffff800000000000
1007be6b4:     	mov	w8, #0x1000             ; =4096
1007be6b8:     	ccmp	x20, x8, #0x0, eq
1007be6bc:     	b.lo	0x1007be6cc <_js_array_get_f64+0x2bc>
1007be6c0:     	ldurb	w8, [x20, #-0x8]
1007be6c4:     	cmp	w8, #0x2
1007be6c8:     	b.eq	0x1007bee0c <_js_array_get_f64+0x9fc>
1007be6cc:     	cbz	x20, 0x1007beb08 <_js_array_get_f64+0x6f8>
1007be6d0:     	mov	x0, x20
1007be6d4:     	mov	x1, x19
1007be6d8:     	bl	0x10030d670 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007be6dc:     	cmp	w0, #0x1
1007be6e0:     	b.ne	0x1007beb08 <_js_array_get_f64+0x6f8>
1007be6e4:     	ldr	x8, [x20, #0x8]
1007be6e8:     	ldr	x22, [x8, w1, uxtw #3]
1007be6ec:     	b	0x1007beb08 <_js_array_get_f64+0x6f8>
1007be6f0:     	mov	x0, x22
1007be6f4:     	mov	x1, x19
1007be6f8:     	bl	0x100548f0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be6fc:     	tbnz	w0, #0x0, 0x1007beb04 <_js_array_get_f64+0x6f4>
1007be700:     	mov	w24, #0x2               ; =2
1007be704:     	b	0x1007be558 <_js_array_get_f64+0x148>
1007be708:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be70c:     	add	x8, x8, #0xec0
1007be710:     	ldaprb	w8, [x8]
1007be714:     	cbz	w8, 0x1007be778 <_js_array_get_f64+0x368>
1007be718:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be71c:     	add	x8, x8, #0x58
1007be720:     	ldapr	x8, [x8]
1007be724:     	cmp	x20, x8
1007be728:     	b.lo	0x1007be778 <_js_array_get_f64+0x368>
1007be72c:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be730:     	add	x8, x8, #0x60
1007be734:     	ldapr	x8, [x8]
1007be738:     	cmp	x20, x8
1007be73c:     	b.hi	0x1007be778 <_js_array_get_f64+0x368>
1007be740:     	mov	x0, x20
1007be744:     	bl	0x1002a5738 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be748:     	tbz	w0, #0x0, 0x1007be778 <_js_array_get_f64+0x368>
1007be74c:     	add	x0, sp, #0x8
1007be750:     	mov	x1, x20
1007be754:     	bl	0x1002a556c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007be758:     	ldr	x8, [sp, #0x8]
1007be75c:     	cbz	x8, 0x1007bed84 <_js_array_get_f64+0x974>
1007be760:     	cmp	x8, #0x1
1007be764:     	b.ne	0x1007bedc8 <_js_array_get_f64+0x9b8>
1007be768:     	ldr	d0, [sp, #0x10]
1007be76c:     	scvtf	d1, w19
1007be770:     	bl	0x10081c9b4 <_js_dyn_index_get>
1007be774:     	b	0x1007beb04 <_js_array_get_f64+0x6f4>
1007be778:     	mov	w24, #0xb               ; =11
1007be77c:     	b	0x1007be558 <_js_array_get_f64+0x148>
1007be780:     	mov	w24, #0x8               ; =8
1007be784:     	b	0x1007be558 <_js_array_get_f64+0x148>
1007be788:     	mov	w24, #0xc               ; =12
1007be78c:     	b	0x1007be558 <_js_array_get_f64+0x148>
1007be790:     	add	x9, x8, #0x60
1007be794:     	b	0x1007bed44 <_js_array_get_f64+0x934>
1007be798:     	bl	0x100b3fe7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007be79c:     	lsr	x1, x21, #20
1007be7a0:     	ldr	x8, [x0, #0x10]
1007be7a4:     	ldrb	w9, [x8]
1007be7a8:     	cmp	w9, #0x2
1007be7ac:     	b.eq	0x1007be5d0 <_js_array_get_f64+0x1c0>
1007be7b0:     	ldr	x9, [x8, #0x8]
1007be7b4:     	ldr	x10, [x8, #0x28]
1007be7b8:     	sub	x9, x1, x9
1007be7bc:     	cmp	x9, x10
1007be7c0:     	b.hs	0x1007be804 <_js_array_get_f64+0x3f4>
1007be7c4:     	ldr	x10, [x8, #0x20]
1007be7c8:     	mov	w11, #0x28              ; =40
1007be7cc:     	madd	x9, x9, x11, x10
1007be7d0:     	ldr	x10, [x9]
1007be7d4:     	ldr	x11, [x8, #0x10]
1007be7d8:     	cmp	x10, x11
1007be7dc:     	b.ne	0x1007be810 <_js_array_get_f64+0x400>
1007be7e0:     	ldp	x10, x11, [x9, #0x8]
1007be7e4:     	cmp	x10, x21
1007be7e8:     	ccmp	x11, x21, #0x0, ls
1007be7ec:     	b.ls	0x1007be810 <_js_array_get_f64+0x400>
1007be7f0:     	ldr	x10, [x8, #0x30]
1007be7f4:     	add	x10, x10, #0x1
1007be7f8:     	str	x10, [x8, #0x30]
1007be7fc:     	add	x8, x9, #0x21
1007be800:     	b	0x1007bed54 <_js_array_get_f64+0x944>
1007be804:     	ldr	x9, [x8, #0x58]
1007be808:     	add	x9, x9, #0x1
1007be80c:     	str	x9, [x8, #0x58]
1007be810:     	ldr	x9, [x8, #0x38]
1007be814:     	add	x9, x9, #0x1
1007be818:     	str	x9, [x8, #0x38]
1007be81c:     	mov	x0, x21
1007be820:     	bl	0x10051ec48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007be824:     	and	w8, w0, #0xff
1007be828:     	cbz	w8, 0x1007be848 <_js_array_get_f64+0x438>
1007be82c:     	ldurb	w8, [x21, #-0x8]
1007be830:     	ldurb	w9, [x21, #-0x7]
1007be834:     	mov	w10, #0x82              ; =130
1007be838:     	and	w9, w9, w10
1007be83c:     	cmp	w9, #0x2
1007be840:     	ccmp	w8, #0x1, #0x0, eq
1007be844:     	b.eq	0x1007be918 <_js_array_get_f64+0x508>
1007be848:     	mov	x0, x21
1007be84c:     	bl	0x10057b2c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be850:     	cbz	x0, 0x1007be878 <_js_array_get_f64+0x468>
1007be854:     	ldrb	w9, [x0]
1007be858:     	cmp	w9, #0x1
1007be85c:     	b.ne	0x1007be894 <_js_array_get_f64+0x484>
1007be860:     	ldrsb	w8, [x0, #0x1]
1007be864:     	tbnz	w8, #0x1f, 0x1007be940 <_js_array_get_f64+0x530>
1007be868:     	ldp	w10, w9, [x21]
1007be86c:     	cmp	w10, w9
1007be870:     	b.hi	0x1007be9cc <_js_array_get_f64+0x5bc>
1007be874:     	b	0x1007be9e4 <_js_array_get_f64+0x5d4>
1007be878:     	mov	x25, x0
1007be87c:     	mov	x0, x21
1007be880:     	bl	0x100589af4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be884:     	tbz	w0, #0x0, 0x1007be8d0 <_js_array_get_f64+0x4c0>
1007be888:     	mov	x0, #0x0                ; =0
1007be88c:     	mov	x8, x25
1007be890:     	b	0x1007be9bc <_js_array_get_f64+0x5ac>
1007be894:     	mov	x8, x0
1007be898:     	cmp	w9, #0x1
1007be89c:     	b.eq	0x1007be9bc <_js_array_get_f64+0x5ac>
1007be8a0:     	cmp	w9, #0x9
1007be8a4:     	b.ne	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be8a8:     	ldr	w8, [x21, #0x4]
1007be8ac:     	mov	w9, #0x5841             ; =22593
1007be8b0:     	movk	w9, #0x4c5a, lsl #16
1007be8b4:     	cmp	w8, w9
1007be8b8:     	b.ne	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be8bc:     	mov	x0, x21
1007be8c0:     	bl	0x100376910 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007be8c4:     	cbz	x0, 0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be8c8:     	mov	x21, x0
1007be8cc:     	b	0x1007bea00 <_js_array_get_f64+0x5f0>
1007be8d0:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be8d4:     	add	x8, x8, #0xec0
1007be8d8:     	ldaprb	w8, [x8]
1007be8dc:     	cbz	w8, 0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be8e0:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be8e4:     	add	x8, x8, #0x58
1007be8e8:     	ldapr	x8, [x8]
1007be8ec:     	cmp	x8, x21
1007be8f0:     	b.hi	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be8f4:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be8f8:     	add	x8, x8, #0x60
1007be8fc:     	ldapr	x8, [x8]
1007be900:     	cmp	x8, x21
1007be904:     	b.lo	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be908:     	mov	x0, x21
1007be90c:     	bl	0x1002a5738 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be910:     	tbnz	w0, #0x0, 0x1007be888 <_js_array_get_f64+0x478>
1007be914:     	b	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be918:     	ldr	w8, [x21]
1007be91c:     	mov	w9, #0xe100             ; =57600
1007be920:     	movk	w9, #0x5f5, lsl #16
1007be924:     	orr	w9, w9, #0x1
1007be928:     	cmp	w8, w9
1007be92c:     	b.hs	0x1007be848 <_js_array_get_f64+0x438>
1007be930:     	ldr	w9, [x21, #0x4]
1007be934:     	cmp	w8, w9
1007be938:     	b.ls	0x1007bea00 <_js_array_get_f64+0x5f0>
1007be93c:     	b	0x1007be848 <_js_array_get_f64+0x438>
1007be940:     	mov	x25, x0
1007be944:     	ldr	x21, [x0, #0x8]
1007be948:     	mov	x0, x21
1007be94c:     	bl	0x10057b2c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be950:     	cbz	x0, 0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be954:     	ldrb	w8, [x0]
1007be958:     	cmp	w8, #0x1
1007be95c:     	b.ne	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be960:     	ldrsb	w8, [x0, #0x1]
1007be964:     	tbz	w8, #0x1f, 0x1007be868 <_js_array_get_f64+0x458>
1007be968:     	mov	w26, #0x1               ; =1
1007be96c:     	ldr	x21, [x0, #0x8]
1007be970:     	mov	x0, x21
1007be974:     	bl	0x10057b2c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be978:     	cbz	x0, 0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be97c:     	ldrb	w8, [x0]
1007be980:     	cmp	w8, #0x1
1007be984:     	b.ne	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be988:     	cmp	w26, #0x3f
1007be98c:     	b.hi	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007be990:     	add	w26, w26, #0x1
1007be994:     	ldrsb	w8, [x0, #0x1]
1007be998:     	tbnz	w8, #0x1f, 0x1007be96c <_js_array_get_f64+0x55c>
1007be99c:     	str	x21, [x25, #0x8]
1007be9a0:     	ldrb	w8, [x25, #0x1]
1007be9a4:     	orr	w9, w8, #0x80
1007be9a8:     	mov	x8, x25
1007be9ac:     	strb	w9, [x25, #0x1]
1007be9b0:     	ldrb	w9, [x0]
1007be9b4:     	cmp	w9, #0x1
1007be9b8:     	b.ne	0x1007be8a0 <_js_array_get_f64+0x490>
1007be9bc:     	ldp	w10, w9, [x21]
1007be9c0:     	cmp	w10, w9
1007be9c4:     	b.ls	0x1007be9e4 <_js_array_get_f64+0x5d4>
1007be9c8:     	cbz	x8, 0x1007be9f4 <_js_array_get_f64+0x5e4>
1007be9cc:     	ldr	w8, [x0, #0x4]
1007be9d0:     	ubfiz	x9, x9, #3, #32
1007be9d4:     	add	x9, x9, #0x10
1007be9d8:     	cmp	x9, x8
1007be9dc:     	b.eq	0x1007bea00 <_js_array_get_f64+0x5f0>
1007be9e0:     	b	0x1007be9f4 <_js_array_get_f64+0x5e4>
1007be9e4:     	mov	w8, #0xe100             ; =57600
1007be9e8:     	movk	w8, #0x5f5, lsl #16
1007be9ec:     	cmp	w10, w8
1007be9f0:     	b.ls	0x1007bea00 <_js_array_get_f64+0x5f0>
1007be9f4:     	mov	x0, x21
1007be9f8:     	bl	0x100589af4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be9fc:     	tbz	w0, #0x0, 0x1007beab0 <_js_array_get_f64+0x6a0>
1007bea00:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bea04:     	add	x8, x8, #0xec0
1007bea08:     	ldaprb	w8, [x8]
1007bea0c:     	cbz	w8, 0x1007bea54 <_js_array_get_f64+0x644>
1007bea10:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bea14:     	add	x8, x8, #0x58
1007bea18:     	ldapr	x8, [x8]
1007bea1c:     	cmp	x21, x8
1007bea20:     	b.lo	0x1007bea54 <_js_array_get_f64+0x644>
1007bea24:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bea28:     	add	x8, x8, #0x60
1007bea2c:     	ldapr	x8, [x8]
1007bea30:     	cmp	x21, x8
1007bea34:     	b.hi	0x1007bea54 <_js_array_get_f64+0x644>
1007bea38:     	mov	x0, x21
1007bea3c:     	bl	0x1002a5738 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bea40:     	tbz	w0, #0x0, 0x1007bea54 <_js_array_get_f64+0x644>
1007bea44:     	mov	x0, x21
1007bea48:     	mov	x1, x19
1007bea4c:     	bl	0x1008fc6c8 <_js_typed_array_get>
1007bea50:     	b	0x1007beb04 <_js_array_get_f64+0x6f4>
1007bea54:     	mov	x0, x21
1007bea58:     	bl	0x100589af4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bea5c:     	tbz	w0, #0x0, 0x1007bea84 <_js_array_get_f64+0x674>
1007bea60:     	mov	x0, x21
1007bea64:     	mov	x1, x19
1007bea68:     	bl	0x100586e1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007bea6c:     	and	w8, w1, #0xff
1007bea70:     	ucvtf	d0, w8
1007bea74:     	fmov	x8, d0
1007bea78:     	tst	w0, #0x1
1007bea7c:     	csel	x22, x8, xzr, ne
1007bea80:     	b	0x1007beb08 <_js_array_get_f64+0x6f8>
1007bea84:     	cmp	x21, x20
1007bea88:     	b.eq	0x1007beb30 <_js_array_get_f64+0x720>
1007bea8c:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007bea90:     	b.lo	0x1007beb28 <_js_array_get_f64+0x718>
1007bea94:     	tst	x21, #0xffff800000000000
1007bea98:     	mov	w8, #0x1000             ; =4096
1007bea9c:     	ccmp	x21, x8, #0x0, eq
1007beaa0:     	b.lo	0x1007beb28 <_js_array_get_f64+0x718>
1007beaa4:     	ldurb	w24, [x21, #-0x8]
1007beaa8:     	ldurh	w23, [x21, #-0x6]
1007beaac:     	b	0x1007beb30 <_js_array_get_f64+0x720>
1007beab0:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007beab4:     	add	x8, x8, #0xec0
1007beab8:     	ldaprb	w8, [x8]
1007beabc:     	cbz	w8, 0x1007beaf4 <_js_array_get_f64+0x6e4>
1007beac0:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007beac4:     	add	x8, x8, #0x58
1007beac8:     	ldapr	x8, [x8]
1007beacc:     	cmp	x21, x8
1007bead0:     	b.lo	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007bead4:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bead8:     	add	x8, x8, #0x60
1007beadc:     	ldapr	x8, [x8]
1007beae0:     	cmp	x21, x8
1007beae4:     	b.hi	0x1007beaf4 <_js_array_get_f64+0x6e4>
1007beae8:     	mov	x0, x21
1007beaec:     	bl	0x1002a5738 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007beaf0:     	tbnz	w0, #0x0, 0x1007bea00 <_js_array_get_f64+0x5f0>
1007beaf4:     	mov	x0, x22
1007beaf8:     	mov	x1, x19
1007beafc:     	bl	0x100548f0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007beb00:     	tbz	w0, #0x0, 0x1007bedd8 <_js_array_get_f64+0x9c8>
1007beb04:     	fmov	x22, d0
1007beb08:     	fmov	d0, x22
1007beb0c:     	ldp	x29, x30, [sp, #0x60]
1007beb10:     	ldp	x20, x19, [sp, #0x50]
1007beb14:     	ldp	x22, x21, [sp, #0x40]
1007beb18:     	ldp	x24, x23, [sp, #0x30]
1007beb1c:     	ldp	x26, x25, [sp, #0x20]
1007beb20:     	add	sp, sp, #0x70
1007beb24:     	ret
1007beb28:     	mov	w23, #0x0               ; =0
1007beb2c:     	mov	w24, #0x0               ; =0
1007beb30:     	cmp	w24, #0x1
1007beb34:     	b.ne	0x1007bece8 <_js_array_get_f64+0x8d8>
1007beb38:     	tbz	w23, #0xa, 0x1007bece8 <_js_array_get_f64+0x8d8>
1007beb3c:     	adrp	x8, 0x100b65000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data1n7OFFSETS+0xe6>
1007beb40:     	add	x8, x8, #0x8cc
1007beb44:     	cmp	w19, #0x3e8
1007beb48:     	b.lo	0x1007bebc0 <_js_array_get_f64+0x7b0>
1007beb4c:     	mov	x9, #0x0                ; =0
1007beb50:     	mov	w11, #0x1759            ; =5977
1007beb54:     	movk	w11, #0xd1b7, lsl #16
1007beb58:     	mov	w12, #0x2710            ; =10000
1007beb5c:     	mov	w13, #0x147b            ; =5243
1007beb60:     	mov	w14, #0x64              ; =100
1007beb64:     	add	x15, sp, #0x8
1007beb68:     	mov	w16, #0x967f            ; =38527
1007beb6c:     	movk	w16, #0x98, lsl #16
1007beb70:     	mov	x10, x19
1007beb74:     	mov	x17, x10
1007beb78:     	umull	x10, w10, w11
1007beb7c:     	lsr	x10, x10, #45
1007beb80:     	msub	w0, w10, w12, w17
1007beb84:     	ubfx	w1, w0, #2, #14
1007beb88:     	mul	w1, w1, w13
1007beb8c:     	lsr	w1, w1, #17
1007beb90:     	msub	w0, w1, w14, w0
1007beb94:     	add	x2, x15, x9
1007beb98:     	ldrh	w1, [x8, w1, uxtw #1]
1007beb9c:     	strh	w1, [x2, #0x6]
1007beba0:     	and	x0, x0, #0xffff
1007beba4:     	ldrh	w0, [x8, x0, lsl #1]
1007beba8:     	strh	w0, [x2, #0x8]
1007bebac:     	sub	x9, x9, #0x4
1007bebb0:     	cmp	w17, w16
1007bebb4:     	b.hi	0x1007beb74 <_js_array_get_f64+0x764>
1007bebb8:     	add	x9, x9, #0xa
1007bebbc:     	b	0x1007bebc8 <_js_array_get_f64+0x7b8>
1007bebc0:     	mov	w9, #0xa                ; =10
1007bebc4:     	mov	x10, x19
1007bebc8:     	cmp	w10, #0x9
1007bebcc:     	b.ls	0x1007bec00 <_js_array_get_f64+0x7f0>
1007bebd0:     	sub	x9, x9, #0x2
1007bebd4:     	ubfx	w11, w10, #2, #14
1007bebd8:     	mov	w12, #0x147b            ; =5243
1007bebdc:     	mul	w11, w11, w12
1007bebe0:     	lsr	w11, w11, #17
1007bebe4:     	mov	w12, #0x64              ; =100
1007bebe8:     	msub	w10, w11, w12, w10
1007bebec:     	and	x10, x10, #0xffff
1007bebf0:     	ldrh	w10, [x8, x10, lsl #1]
1007bebf4:     	add	x12, sp, #0x8
1007bebf8:     	strh	w10, [x12, x9]
1007bebfc:     	mov	x10, x11
1007bec00:     	cbz	w19, 0x1007bec38 <_js_array_get_f64+0x828>
1007bec04:     	cbnz	w10, 0x1007bec38 <_js_array_get_f64+0x828>
1007bec08:     	cmp	x9, #0xa
1007bec0c:     	b.ne	0x1007bec60 <_js_array_get_f64+0x850>
1007bec10:     	mov	w23, #0x1               ; =1
1007bec14:     	add	x0, sp, #0x8
1007bec18:     	mov	x1, x21
1007bec1c:     	mov	w2, #0x1                ; =1
1007bec20:     	mov	x3, #0x0                ; =0
1007bec24:     	bl	0x1005b31fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bec28:     	ldr	x8, [sp, #0x8]
1007bec2c:     	mov	w20, #0x1               ; =1
1007bec30:     	cbnz	x8, 0x1007becb0 <_js_array_get_f64+0x8a0>
1007bec34:     	b	0x1007bece8 <_js_array_get_f64+0x8d8>
1007bec38:     	sub	x23, x9, #0x1
1007bec3c:     	ubfiz	w10, w10, #1, #4
1007bec40:     	add	x8, x8, x10
1007bec44:     	ldrb	w8, [x8, #0x1]
1007bec48:     	add	x10, sp, #0x8
1007bec4c:     	strb	w8, [x10, x23]
1007bec50:     	mov	w8, #0xb                ; =11
1007bec54:     	b	0x1007bec68 <_js_array_get_f64+0x858>
1007bec58:     	add	x9, x8, #0x90
1007bec5c:     	b	0x1007bed44 <_js_array_get_f64+0x934>
1007bec60:     	mov	w8, #0xa                ; =10
1007bec64:     	mov	x23, x9
1007bec68:     	sub	x22, x8, x9
1007bec6c:     	mov	x0, x22
1007bec70:     	mov	w1, #0x1                ; =1
1007bec74:     	bl	0x100b5fd08 <_mi_malloc_aligned>
1007bec78:     	cbz	x0, 0x1007bee24 <_js_array_get_f64+0xa14>
1007bec7c:     	mov	x20, x0
1007bec80:     	add	x8, sp, #0x8
1007bec84:     	add	x1, x8, x23
1007bec88:     	mov	x2, x22
1007bec8c:     	bl	0x100b6292c <_writev+0x100b6292c>
1007bec90:     	add	x0, sp, #0x8
1007bec94:     	mov	x1, x21
1007bec98:     	mov	x2, x20
1007bec9c:     	mov	x3, x22
1007beca0:     	bl	0x1005b31fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007beca4:     	ldr	w8, [sp, #0x8]
1007beca8:     	tbz	w8, #0x0, 0x1007bece0 <_js_array_get_f64+0x8d0>
1007becac:     	mov	w23, #0x0               ; =0
1007becb0:     	mov	x22, #0x1               ; =1
1007becb4:     	movk	x22, #0x7ffc, lsl #48
1007becb8:     	ldr	x0, [sp, #0x10]
1007becbc:     	cbz	x0, 0x1007bed74 <_js_array_get_f64+0x964>
1007becc0:     	cbz	x21, 0x1007bed64 <_js_array_get_f64+0x954>
1007becc4:     	lsr	x8, x21, #52
1007becc8:     	cmp	x8, #0x7fe
1007beccc:     	b.hi	0x1007bed68 <_js_array_get_f64+0x958>
1007becd0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007becd4:     	bfxil	x8, x21, #0, #48
1007becd8:     	mov	x21, x8
1007becdc:     	b	0x1007bed68 <_js_array_get_f64+0x958>
1007bece0:     	mov	x0, x20
1007bece4:     	bl	0x100b5fa80 <_mi_free>
1007bece8:     	ldr	w8, [x21]
1007becec:     	cmp	w19, w8
1007becf0:     	b.hs	0x1007bed30 <_js_array_get_f64+0x920>
1007becf4:     	ldr	w8, [x21, #0x4]
1007becf8:     	cmp	w19, w8
1007becfc:     	b.hs	0x1007bed20 <_js_array_get_f64+0x910>
1007bed00:     	add	x8, x21, w19, uxtw #3
1007bed04:     	ldr	x22, [x8, #0x8]
1007bed08:     	mov	x8, #0x1                ; =1
1007bed0c:     	movk	x8, #0x7ffc, lsl #48
1007bed10:     	add	x8, x8, #0xf
1007bed14:     	cmp	x22, x8
1007bed18:     	b.ne	0x1007beb08 <_js_array_get_f64+0x6f8>
1007bed1c:     	b	0x1007bed30 <_js_array_get_f64+0x920>
1007bed20:     	mov	x0, x21
1007bed24:     	mov	x1, x19
1007bed28:     	bl	0x10052b304 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007bed2c:     	tbnz	w0, #0x0, 0x1007beb04 <_js_array_get_f64+0x6f4>
1007bed30:     	mov	x0, x21
1007bed34:     	mov	x1, x19
1007bed38:     	bl	0x1006c7854 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007bed3c:     	b	0x1007beb04 <_js_array_get_f64+0x6f4>
1007bed40:     	add	x9, x8, #0xc0
1007bed44:     	ldr	x10, [x8, #0x30]
1007bed48:     	add	x10, x10, #0x1
1007bed4c:     	str	x10, [x8, #0x30]
1007bed50:     	add	x8, x9, #0x19
1007bed54:     	ldrb	w8, [x8]
1007bed58:     	cmp	w8, #0xff
1007bed5c:     	b.ne	0x1007be828 <_js_array_get_f64+0x418>
1007bed60:     	b	0x1007be81c <_js_array_get_f64+0x40c>
1007bed64:     	add	x21, x22, #0x1
1007bed68:     	fmov	d0, x21
1007bed6c:     	bl	0x1006fd67c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007bed70:     	mov	x22, x0
1007bed74:     	tbnz	w23, #0x0, 0x1007beb08 <_js_array_get_f64+0x6f8>
1007bed78:     	mov	x0, x20
1007bed7c:     	bl	0x100b5fa80 <_mi_free>
1007bed80:     	b	0x1007beb08 <_js_array_get_f64+0x6f8>
1007bed84:     	ldr	x20, [sp, #0x10]
1007bed88:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bed8c:     	ldr	x8, [x8, #0xed8]
1007bed90:     	cbz	x8, 0x1007beda8 <_js_array_get_f64+0x998>
1007bed94:     	mov	x0, x20
1007bed98:     	bl	0x10013cd40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007bed9c:     	tbz	w0, #0x0, 0x1007beda8 <_js_array_get_f64+0x998>
1007beda0:     	mov	x0, x20
1007beda4:     	bl	0x1002bf940 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007beda8:     	tbnz	w19, #0x1f, 0x1007bedc8 <_js_array_get_f64+0x9b8>
1007bedac:     	ldr	w8, [x20]
1007bedb0:     	cmp	w19, w8
1007bedb4:     	b.hs	0x1007bedc8 <_js_array_get_f64+0x9b8>
1007bedb8:     	mov	w1, w19
1007bedbc:     	mov	x0, x20
1007bedc0:     	bl	0x1002a5bcc <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007bedc4:     	b	0x1007beb04 <_js_array_get_f64+0x6f4>
1007bedc8:     	mov	x8, #0x1                ; =1
1007bedcc:     	movk	x8, #0x7ffc, lsl #48
1007bedd0:     	mov	x22, x8
1007bedd4:     	b	0x1007beb08 <_js_array_get_f64+0x6f8>
1007bedd8:     	mov	x0, x22
1007beddc:     	bl	0x100b483f0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007bede0:     	cmp	x0, #0x1
1007bede4:     	b.ne	0x1007be450 <_js_array_get_f64+0x40>
1007bede8:     	mov	x0, x19
1007bedec:     	bl	0x100b48410 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007bedf0:     	b	0x1007beb04 <_js_array_get_f64+0x6f4>
1007bedf4:     	mov	x0, x20
1007bedf8:     	mov	w1, #0x0                ; =0
1007bedfc:     	bl	0x100b4a980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bee00:     	mov	x20, x0
1007bee04:     	cbnz	x0, 0x1007be52c <_js_array_get_f64+0x11c>
1007bee08:     	b	0x1007beb08 <_js_array_get_f64+0x6f8>
1007bee0c:     	mov	x0, x20
1007bee10:     	mov	w1, #0x1                ; =1
1007bee14:     	bl	0x100b4a980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bee18:     	mov	x20, x0
1007bee1c:     	cbnz	x0, 0x1007be6d0 <_js_array_get_f64+0x2c0>
1007bee20:     	b	0x1007beb08 <_js_array_get_f64+0x6f8>
1007bee24:     	mov	w0, #0x1                ; =1
1007bee28:     	mov	x1, x22
1007bee2c:     	bl	0x100b12e00 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
