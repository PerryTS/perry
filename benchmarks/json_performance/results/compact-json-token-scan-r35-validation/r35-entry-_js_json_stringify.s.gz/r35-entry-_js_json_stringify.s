
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/compact-json-token-scan-r35/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008458ac <_js_json_stringify>:
1008458ac:     	sub	sp, sp, #0x80
1008458b0:     	stp	d9, d8, [sp, #0x20]
1008458b4:     	stp	x26, x25, [sp, #0x30]
1008458b8:     	stp	x24, x23, [sp, #0x40]
1008458bc:     	stp	x22, x21, [sp, #0x50]
1008458c0:     	stp	x20, x19, [sp, #0x60]
1008458c4:     	stp	x29, x30, [sp, #0x70]
1008458c8:     	add	x29, sp, #0x70
1008458cc:     	mov	x21, x0
1008458d0:     	mov.16b	v8, v0
1008458d4:     	fmov	x19, d8
1008458d8:     	and	x20, x19, #0xffff000000000000
1008458dc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008458e0:     	cmp	x20, x8
1008458e4:     	b.ne	0x10084590c <_js_json_stringify+0x60>
1008458e8:     	and	x0, x19, #0xffffffffffff
1008458ec:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
1008458f0:     	mov	x9, #0x7fffffffffff     ; =140737488355327
1008458f4:     	movk	x9, #0xffef, lsl #16
1008458f8:     	cmp	x8, x9
1008458fc:     	b.hi	0x10084590c <_js_json_stringify+0x60>
100845900:     	ldr	w8, [x0, #0x4]
100845904:     	cmp	w8, #0x40
100845908:     	b.hs	0x10084597c <_js_json_stringify+0xd0>
10084590c:     	mov.16b	v0, v8
100845910:     	bl	0x1004ee83c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100845914:     	tbz	w0, #0x0, 0x100845920 <_js_json_stringify+0x74>
100845918:     	mov	x23, x1
10084591c:     	b	0x100845e90 <_js_json_stringify+0x5e4>
100845920:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845924:     	cmp	x20, x8
100845928:     	b.ne	0x100845990 <_js_json_stringify+0xe4>
10084592c:     	ands	x19, x19, #0xffffffffffff
100845930:     	b.eq	0x100845990 <_js_json_stringify+0xe4>
100845934:     	mov	x0, x19
100845938:     	bl	0x10050fa38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084593c:     	cbz	w0, 0x100845990 <_js_json_stringify+0xe4>
100845940:     	ldurb	w8, [x19, #-0x8]
100845944:     	cmp	w8, #0x9
100845948:     	b.ne	0x100845990 <_js_json_stringify+0xe4>
10084594c:     	ldr	w8, [x19, #0x4]
100845950:     	mov	w9, #0x5841             ; =22593
100845954:     	movk	w9, #0x4c5a, lsl #16
100845958:     	cmp	w8, w9
10084595c:     	b.ne	0x100845990 <_js_json_stringify+0xe4>
100845960:     	mov	x0, x19
100845964:     	bl	0x1006884e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100845968:     	cbz	x0, 0x100845990 <_js_json_stringify+0xe4>
10084596c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845970:     	bfxil	x8, x0, #0, #48
100845974:     	fmov	d8, x8
100845978:     	b	0x100845990 <_js_json_stringify+0xe4>
10084597c:     	bl	0x1004f3768 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100845980:     	tbnz	w0, #0x0, 0x100845918 <_js_json_stringify+0x6c>
100845984:     	mov.16b	v0, v8
100845988:     	bl	0x1004ee83c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084598c:     	tbnz	w0, #0x0, 0x100845918 <_js_json_stringify+0x6c>
100845990:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845994:     	add	x0, x0, #0xd78
100845998:     	ldr	x8, [x0]
10084599c:     	blr	x8
1008459a0:     	mov	x19, x0
1008459a4:     	ldr	w26, [x0]
1008459a8:     	add	w8, w26, #0x1
1008459ac:     	str	w8, [x0]
1008459b0:     	cbz	w26, 0x100845a20 <_js_json_stringify+0x174>
1008459b4:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008459b8:     	add	x0, x0, #0xd00
1008459bc:     	ldr	x8, [x0]
1008459c0:     	blr	x8
1008459c4:     	ldrb	w8, [x0, #0x20]
1008459c8:     	cmp	w8, #0x1
1008459cc:     	b.ne	0x100845f84 <_js_json_stringify+0x6d8>
1008459d0:     	ldr	x8, [x0]
1008459d4:     	cbnz	x8, 0x100845f90 <_js_json_stringify+0x6e4>
1008459d8:     	mov	x8, #-0x1               ; =-1
1008459dc:     	str	x8, [x0]
1008459e0:     	ldr	x20, [x0, #0x18]
1008459e4:     	ldr	x8, [x0, #0x8]
1008459e8:     	cmp	x20, x8
1008459ec:     	b.eq	0x100845eb4 <_js_json_stringify+0x608>
1008459f0:     	ldr	x8, [x0, #0x10]
1008459f4:     	mov	w9, #0x18               ; =24
1008459f8:     	madd	x8, x20, x9, x8
1008459fc:     	mov	w9, #0x8                ; =8
100845a00:     	stp	xzr, x9, [x8]
100845a04:     	str	xzr, [x8, #0x10]
100845a08:     	add	x8, x20, #0x1
100845a0c:     	str	x8, [x0, #0x18]
100845a10:     	ldr	x8, [x0]
100845a14:     	add	x8, x8, #0x1
100845a18:     	str	x8, [x0]
100845a1c:     	b	0x100845aac <_js_json_stringify+0x200>
100845a20:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845a24:     	add	x0, x0, #0xdc0
100845a28:     	ldr	x8, [x0]
100845a2c:     	blr	x8
100845a30:     	strb	wzr, [x0]
100845a34:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845a38:     	add	x0, x0, #0xdf0
100845a3c:     	ldr	x8, [x0]
100845a40:     	blr	x8
100845a44:     	strb	wzr, [x0]
100845a48:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100845a4c:     	ldr	w20, [x8, #0x5a8]
100845a50:     	cmp	w20, #0x300
100845a54:     	b.hs	0x100845f10 <_js_json_stringify+0x664>
100845a58:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100845a5c:     	ldr	x8, [x8, #0x48]
100845a60:     	cmn	x8, #0x1
100845a64:     	b.eq	0x100845f00 <_js_json_stringify+0x654>
100845a68:     	mrs	x9, TPIDRRO_EL0
100845a6c:     	and	x9, x9, #0xfffffffffffffff8
100845a70:     	ldr	x0, [x9, x8, lsl #3]
100845a74:     	cbz	x0, 0x100845f00 <_js_json_stringify+0x654>
100845a78:     	add	x8, x0, x20, lsl #3
100845a7c:     	ldr	x0, [x8, #0x1e8]
100845a80:     	cbz	x0, 0x100845f10 <_js_json_stringify+0x664>
100845a84:     	str	xzr, [x0]
100845a88:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845a8c:     	add	x0, x0, #0xd90
100845a90:     	ldr	x8, [x0]
100845a94:     	blr	x8
100845a98:     	ldrb	w8, [x0, #0x20]
100845a9c:     	cbnz	w8, 0x100845f9c <_js_json_stringify+0x6f0>
100845aa0:     	ldr	x8, [x0]
100845aa4:     	cbnz	x8, 0x100845fc4 <_js_json_stringify+0x718>
100845aa8:     	str	xzr, [x0, #0x18]
100845aac:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845ab0:     	add	x0, x0, #0xd30
100845ab4:     	ldr	x8, [x0]
100845ab8:     	blr	x8
100845abc:     	mov	x20, x0
100845ac0:     	ldrb	w8, [x0, #0x18]
100845ac4:     	cmp	w8, #0x1
100845ac8:     	b.ne	0x100845f20 <_js_json_stringify+0x674>
100845acc:     	ldr	x8, [x0]
100845ad0:     	mov	x9, #-0x1               ; =-1
100845ad4:     	str	x9, [x0]
100845ad8:     	cmn	x8, #0x2
100845adc:     	b.eq	0x100845fd0 <_js_json_stringify+0x724>
100845ae0:     	cmn	x8, #0x1
100845ae4:     	b.eq	0x100845af8 <_js_json_stringify+0x24c>
100845ae8:     	add	x9, sp, #0x8
100845aec:     	ldur	q0, [x0, #0x8]
100845af0:     	stur	q0, [x9, #0x8]
100845af4:     	b	0x100845b04 <_js_json_stringify+0x258>
100845af8:     	mov	x8, #0x0                ; =0
100845afc:     	mov	w9, #0x1                ; =1
100845b00:     	stp	x9, xzr, [sp, #0x10]
100845b04:     	str	x8, [sp, #0x8]
100845b08:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845b0c:     	add	x0, x0, #0xd18
100845b10:     	ldr	x8, [x0]
100845b14:     	blr	x8
100845b18:     	ldrb	w8, [x0, #0x20]
100845b1c:     	cbnz	w8, 0x100845f50 <_js_json_stringify+0x6a4>
100845b20:     	ldr	x8, [x0]
100845b24:     	cbnz	x8, 0x100845f78 <_js_json_stringify+0x6cc>
100845b28:     	str	xzr, [x0, #0x18]
100845b2c:     	add	x1, sp, #0x8
100845b30:     	mov.16b	v0, v8
100845b34:     	mov	x0, x21
100845b38:     	bl	0x100509e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100845b3c:     	ldp	x21, x22, [sp, #0x10]
100845b40:     	cmp	w22, #0x80, lsl #12     ; =0x80000
100845b44:     	b.hs	0x100845c04 <_js_json_stringify+0x358>
100845b48:     	cmp	x22, #0x40
100845b4c:     	b.hs	0x100845cc8 <_js_json_stringify+0x41c>
100845b50:     	ands	x9, x22, #0x38
100845b54:     	b.eq	0x100845b78 <_js_json_stringify+0x2cc>
100845b58:     	and	x8, x22, #0x38
100845b5c:     	neg	x8, x8
100845b60:     	mov	x10, x21
100845b64:     	ldr	x11, [x10], #0x8
100845b68:     	tst	x11, #0x8080808080808080
100845b6c:     	b.ne	0x100845bec <_js_json_stringify+0x340>
100845b70:     	adds	x8, x8, #0x8
100845b74:     	b.ne	0x100845b64 <_js_json_stringify+0x2b8>
100845b78:     	and	x8, x22, #0x7
100845b7c:     	cbz	x8, 0x100845d4c <_js_json_stringify+0x4a0>
100845b80:     	add	x9, x21, x9
100845b84:     	ldrsb	w10, [x9]
100845b88:     	tbnz	w10, #0x1f, 0x100845bec <_js_json_stringify+0x340>
100845b8c:     	cmp	x8, #0x1
100845b90:     	b.eq	0x100845d4c <_js_json_stringify+0x4a0>
100845b94:     	ldrsb	w10, [x9, #0x1]
100845b98:     	tbnz	w10, #0x1f, 0x100845bec <_js_json_stringify+0x340>
100845b9c:     	cmp	x8, #0x2
100845ba0:     	b.eq	0x100845d4c <_js_json_stringify+0x4a0>
100845ba4:     	ldrsb	w10, [x9, #0x2]
100845ba8:     	tbnz	w10, #0x1f, 0x100845bec <_js_json_stringify+0x340>
100845bac:     	cmp	x8, #0x3
100845bb0:     	b.eq	0x100845d4c <_js_json_stringify+0x4a0>
100845bb4:     	ldrsb	w10, [x9, #0x3]
100845bb8:     	tbnz	w10, #0x1f, 0x100845bec <_js_json_stringify+0x340>
100845bbc:     	cmp	x8, #0x4
100845bc0:     	b.eq	0x100845d4c <_js_json_stringify+0x4a0>
100845bc4:     	ldrsb	w10, [x9, #0x4]
100845bc8:     	tbnz	w10, #0x1f, 0x100845bec <_js_json_stringify+0x340>
100845bcc:     	cmp	x8, #0x5
100845bd0:     	b.eq	0x100845d4c <_js_json_stringify+0x4a0>
100845bd4:     	ldrsb	w10, [x9, #0x5]
100845bd8:     	tbnz	w10, #0x1f, 0x100845bec <_js_json_stringify+0x340>
100845bdc:     	cmp	x8, #0x6
100845be0:     	b.eq	0x100845d4c <_js_json_stringify+0x4a0>
100845be4:     	ldrsb	w8, [x9, #0x6]
100845be8:     	tbz	w8, #0x1f, 0x100845d4c <_js_json_stringify+0x4a0>
100845bec:     	mov	x0, x21
100845bf0:     	mov	x1, x22
100845bf4:     	mov	x2, x22
100845bf8:     	bl	0x1008dd280 <_js_string_from_bytes_with_capacity>
100845bfc:     	mov	x23, x0
100845c00:     	b	0x100845e48 <_js_json_stringify+0x59c>
100845c04:     	and	x8, x22, #0x7fffffffffffffc0
100845c08:     	add	x8, x21, x8
100845c0c:     	mov	x9, x21
100845c10:     	ldp	q0, q1, [x9]
100845c14:     	ldp	q2, q3, [x9, #0x20]
100845c18:     	orr.16b	v0, v1, v0
100845c1c:     	orr.16b	v1, v2, v3
100845c20:     	orr.16b	v0, v0, v1
100845c24:     	umaxv.16b	b0, v0
100845c28:     	fmov	w10, s0
100845c2c:     	tbnz	w10, #0x7, 0x100845c8c <_js_json_stringify+0x3e0>
100845c30:     	add	x9, x9, #0x40
100845c34:     	cmp	x9, x8
100845c38:     	b.ne	0x100845c10 <_js_json_stringify+0x364>
100845c3c:     	ands	x9, x22, #0x30
100845c40:     	b.eq	0x100845c64 <_js_json_stringify+0x3b8>
100845c44:     	mov	x10, x9
100845c48:     	mov	x11, x8
100845c4c:     	ldr	q0, [x11], #0x10
100845c50:     	umaxv.16b	b0, v0
100845c54:     	fmov	w12, s0
100845c58:     	tbnz	w12, #0x7, 0x100845c8c <_js_json_stringify+0x3e0>
100845c5c:     	subs	x10, x10, #0x10
100845c60:     	b.ne	0x100845c4c <_js_json_stringify+0x3a0>
100845c64:     	and	x10, x22, #0xf
100845c68:     	cbz	x10, 0x100845c84 <_js_json_stringify+0x3d8>
100845c6c:     	add	x8, x8, x9
100845c70:     	ldrsb	w9, [x8]
100845c74:     	tbnz	w9, #0x1f, 0x100845c8c <_js_json_stringify+0x3e0>
100845c78:     	add	x8, x8, #0x1
100845c7c:     	subs	x10, x10, #0x1
100845c80:     	b.ne	0x100845c70 <_js_json_stringify+0x3c4>
100845c84:     	mov	w24, w22
100845c88:     	b	0x100845cc0 <_js_json_stringify+0x414>
100845c8c:     	mov	w24, w22
100845c90:     	cbz	x24, 0x100845cc0 <_js_json_stringify+0x414>
100845c94:     	mov	x8, x21
100845c98:     	ands	x9, x22, #0x3
100845c9c:     	b.eq	0x100845cb8 <_js_json_stringify+0x40c>
100845ca0:     	mov	x8, x21
100845ca4:     	ldrsb	w10, [x8]
100845ca8:     	tbnz	w10, #0x1f, 0x100845db0 <_js_json_stringify+0x504>
100845cac:     	add	x8, x8, #0x1
100845cb0:     	subs	x9, x9, #0x1
100845cb4:     	b.ne	0x100845ca4 <_js_json_stringify+0x3f8>
100845cb8:     	cmp	x24, #0x4
100845cbc:     	b.hs	0x100845d7c <_js_json_stringify+0x4d0>
100845cc0:     	mov	x25, x22
100845cc4:     	b	0x100845dc0 <_js_json_stringify+0x514>
100845cc8:     	and	x8, x22, #0x7fffffffffffffc0
100845ccc:     	and	x8, x8, #0xffffffff0007ffff
100845cd0:     	add	x8, x21, x8
100845cd4:     	mov	x9, x21
100845cd8:     	ldp	q0, q1, [x9]
100845cdc:     	ldp	q2, q3, [x9, #0x20]
100845ce0:     	orr.16b	v0, v1, v0
100845ce4:     	orr.16b	v1, v2, v3
100845ce8:     	orr.16b	v0, v0, v1
100845cec:     	umaxv.16b	b0, v0
100845cf0:     	fmov	w10, s0
100845cf4:     	tbnz	w10, #0x7, 0x100845bec <_js_json_stringify+0x340>
100845cf8:     	add	x9, x9, #0x40
100845cfc:     	cmp	x9, x8
100845d00:     	b.ne	0x100845cd8 <_js_json_stringify+0x42c>
100845d04:     	ands	x9, x22, #0x30
100845d08:     	b.eq	0x100845d2c <_js_json_stringify+0x480>
100845d0c:     	mov	x10, x9
100845d10:     	mov	x11, x8
100845d14:     	ldr	q0, [x11], #0x10
100845d18:     	umaxv.16b	b0, v0
100845d1c:     	fmov	w12, s0
100845d20:     	tbnz	w12, #0x7, 0x100845bec <_js_json_stringify+0x340>
100845d24:     	subs	x10, x10, #0x10
100845d28:     	b.ne	0x100845d14 <_js_json_stringify+0x468>
100845d2c:     	and	x10, x22, #0xf
100845d30:     	cbz	x10, 0x100845d4c <_js_json_stringify+0x4a0>
100845d34:     	add	x8, x8, x9
100845d38:     	ldrsb	w9, [x8]
100845d3c:     	tbnz	w9, #0x1f, 0x100845bec <_js_json_stringify+0x340>
100845d40:     	add	x8, x8, #0x1
100845d44:     	subs	x10, x10, #0x1
100845d48:     	b.ne	0x100845d38 <_js_json_stringify+0x48c>
100845d4c:     	mov	x0, x22
100845d50:     	bl	0x10034bc6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100845d54:     	mov	x23, x0
100845d58:     	stp	w22, w22, [x0]
100845d5c:     	stp	wzr, wzr, [x0, #0xc]
100845d60:     	str	w22, [x0, #0x8]
100845d64:     	cbz	w22, 0x100845e48 <_js_json_stringify+0x59c>
100845d68:     	and	x2, x22, #0x7ffff
100845d6c:     	mov	x0, x1
100845d70:     	mov	x1, x21
100845d74:     	bl	0x100b6292c <_writev+0x100b6292c>
100845d78:     	b	0x100845e48 <_js_json_stringify+0x59c>
100845d7c:     	add	x9, x21, x24
100845d80:     	ldrsb	w10, [x8]
100845d84:     	tbnz	w10, #0x1f, 0x100845db0 <_js_json_stringify+0x504>
100845d88:     	ldrsb	w10, [x8, #0x1]
100845d8c:     	tbnz	w10, #0x1f, 0x100845db0 <_js_json_stringify+0x504>
100845d90:     	ldrsb	w10, [x8, #0x2]
100845d94:     	tbnz	w10, #0x1f, 0x100845db0 <_js_json_stringify+0x504>
100845d98:     	ldrsb	w10, [x8, #0x3]
100845d9c:     	tbnz	w10, #0x1f, 0x100845db0 <_js_json_stringify+0x504>
100845da0:     	add	x8, x8, #0x4
100845da4:     	cmp	x8, x9
100845da8:     	b.ne	0x100845d80 <_js_json_stringify+0x4d4>
100845dac:     	b	0x100845cc0 <_js_json_stringify+0x414>
100845db0:     	mov	w1, w22
100845db4:     	mov	x0, x21
100845db8:     	bl	0x1005eb220 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
100845dbc:     	mov	x25, x0
100845dc0:     	bl	0x1004f09c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100845dc4:     	add	x0, x24, #0x14
100845dc8:     	mov	w1, #0x3                ; =3
100845dcc:     	bl	0x100458e40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
100845dd0:     	mov	x23, x0
100845dd4:     	stp	w25, w22, [x0]
100845dd8:     	stp	wzr, wzr, [x0, #0xc]
100845ddc:     	str	w22, [x0, #0x8]
100845de0:     	add	x0, x0, #0x14
100845de4:     	mov	x1, x21
100845de8:     	mov	x2, x24
100845dec:     	bl	0x100b6292c <_writev+0x100b6292c>
100845df0:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100845df4:     	ldr	w21, [x8, #0x590]
100845df8:     	cmp	w21, #0x300
100845dfc:     	b.hs	0x100845ed8 <_js_json_stringify+0x62c>
100845e00:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100845e04:     	ldr	x8, [x8, #0x48]
100845e08:     	cmn	x8, #0x1
100845e0c:     	b.eq	0x100845ec8 <_js_json_stringify+0x61c>
100845e10:     	mrs	x9, TPIDRRO_EL0
100845e14:     	and	x9, x9, #0xfffffffffffffff8
100845e18:     	ldr	x0, [x9, x8, lsl #3]
100845e1c:     	cbz	x0, 0x100845ec8 <_js_json_stringify+0x61c>
100845e20:     	add	x8, x0, x21, lsl #3
100845e24:     	ldr	x0, [x8, #0x1e8]
100845e28:     	cbz	x0, 0x100845ed8 <_js_json_stringify+0x62c>
100845e2c:     	ldr	x8, [x0]
100845e30:     	adds	x8, x8, x24
100845e34:     	csinv	x8, x8, xzr, lo
100845e38:     	str	x8, [x0]
100845e3c:     	lsr	x8, x8, #25
100845e40:     	cbz	x8, 0x100845e48 <_js_json_stringify+0x59c>
100845e44:     	bl	0x10045fd74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100845e48:     	ldp	x22, x21, [sp, #0x8]
100845e4c:     	ldrb	w8, [x20, #0x18]
100845e50:     	cmp	w8, #0x1
100845e54:     	b.ne	0x100845f30 <_js_json_stringify+0x684>
100845e58:     	ldp	x8, x0, [x20]
100845e5c:     	stp	x22, x21, [x20]
100845e60:     	str	xzr, [x20, #0x10]
100845e64:     	sub	x8, x8, #0x1
100845e68:     	cmn	x8, #0x2
100845e6c:     	b.hs	0x100845e74 <_js_json_stringify+0x5c8>
100845e70:     	bl	0x100b5fa80 <_mi_free>
100845e74:     	cbz	w26, 0x100845e80 <_js_json_stringify+0x5d4>
100845e78:     	bl	0x100328ba8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100845e7c:     	b	0x100845e84 <_js_json_stringify+0x5d8>
100845e80:     	bl	0x1003289d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100845e84:     	ldr	w8, [x19]
100845e88:     	sub	w8, w8, #0x1
100845e8c:     	str	w8, [x19]
100845e90:     	mov	x0, x23
100845e94:     	ldp	x29, x30, [sp, #0x70]
100845e98:     	ldp	x20, x19, [sp, #0x60]
100845e9c:     	ldp	x22, x21, [sp, #0x50]
100845ea0:     	ldp	x24, x23, [sp, #0x40]
100845ea4:     	ldp	x26, x25, [sp, #0x30]
100845ea8:     	ldp	d9, d8, [sp, #0x20]
100845eac:     	add	sp, sp, #0x80
100845eb0:     	ret
100845eb4:     	mov	x22, x0
100845eb8:     	add	x0, x0, #0x8
100845ebc:     	bl	0x100b3c7d0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100845ec0:     	mov	x0, x22
100845ec4:     	b	0x1008459f0 <_js_json_stringify+0x144>
100845ec8:     	bl	0x100b3fe7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100845ecc:     	add	x8, x0, x21, lsl #3
100845ed0:     	ldr	x0, [x8, #0x1e8]
100845ed4:     	cbnz	x0, 0x100845e2c <_js_json_stringify+0x580>
100845ed8:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100845edc:     	add	x0, x0, #0x78
100845ee0:     	bl	0x100b3d69c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100845ee4:     	ldr	x8, [x0]
100845ee8:     	adds	x8, x8, x24
100845eec:     	csinv	x8, x8, xzr, lo
100845ef0:     	str	x8, [x0]
100845ef4:     	lsr	x8, x8, #25
100845ef8:     	cbnz	x8, 0x100845e44 <_js_json_stringify+0x598>
100845efc:     	b	0x100845e48 <_js_json_stringify+0x59c>
100845f00:     	bl	0x100b3fe7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100845f04:     	add	x8, x0, x20, lsl #3
100845f08:     	ldr	x0, [x8, #0x1e8]
100845f0c:     	cbnz	x0, 0x100845a84 <_js_json_stringify+0x1d8>
100845f10:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100845f14:     	add	x0, x0, #0x138
100845f18:     	bl	0x100b3d69c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100845f1c:     	b	0x100845a84 <_js_json_stringify+0x1d8>
100845f20:     	mov	x0, x20
100845f24:     	bl	0x100b1f004 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100845f28:     	cbnz	x0, 0x100845acc <_js_json_stringify+0x220>
100845f2c:     	b	0x100845fd0 <_js_json_stringify+0x724>
100845f30:     	mov	x0, x20
100845f34:     	bl	0x100b1f004 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100845f38:     	mov	x20, x0
100845f3c:     	cbnz	x0, 0x100845e58 <_js_json_stringify+0x5ac>
100845f40:     	cbz	x22, 0x100845fd0 <_js_json_stringify+0x724>
100845f44:     	mov	x0, x21
100845f48:     	bl	0x100b5fa80 <_mi_free>
100845f4c:     	b	0x100845fd0 <_js_json_stringify+0x724>
100845f50:     	cmp	w8, #0x2
100845f54:     	b.eq	0x100845fd0 <_js_json_stringify+0x724>
100845f58:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime13async_context12ContextGuardEEEB2h_+0xf8>
100845f5c:     	add	x1, x1, #0x7b8
100845f60:     	mov	x22, x0
100845f64:     	bl	0x100a20edc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845f68:     	mov	x0, x22
100845f6c:     	strb	wzr, [x22, #0x20]
100845f70:     	ldr	x8, [x22]
100845f74:     	cbz	x8, 0x100845b28 <_js_json_stringify+0x27c>
100845f78:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845f7c:     	add	x0, x0, #0xdb8
100845f80:     	bl	0x100b131ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845f84:     	bl	0x100b1f164 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100845f88:     	cbnz	x0, 0x1008459d0 <_js_json_stringify+0x124>
100845f8c:     	b	0x100845fd0 <_js_json_stringify+0x724>
100845f90:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100845f94:     	add	x0, x0, #0x440
100845f98:     	bl	0x100b131ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845f9c:     	cmp	w8, #0x1
100845fa0:     	b.ne	0x100845fd0 <_js_json_stringify+0x724>
100845fa4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime13async_context12ContextGuardEEEB2h_+0xf8>
100845fa8:     	add	x1, x1, #0x158
100845fac:     	mov	x20, x0
100845fb0:     	bl	0x100a20edc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845fb4:     	mov	x0, x20
100845fb8:     	strb	wzr, [x20, #0x20]
100845fbc:     	ldr	x8, [x20]
100845fc0:     	cbz	x8, 0x100845aa8 <_js_json_stringify+0x1fc>
100845fc4:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845fc8:     	add	x0, x0, #0xd88
100845fcc:     	bl	0x100b131ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845fd0:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100845fd4:     	add	x0, x0, #0xc18
100845fd8:     	bl	0x100b590dc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
