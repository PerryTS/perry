
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/compact-json-token-scan-r35/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100846000 <_js_json_stringify_full>:
100846000:     	sub	sp, sp, #0x120
100846004:     	stp	d9, d8, [sp, #0xb0]
100846008:     	stp	x28, x27, [sp, #0xc0]
10084600c:     	stp	x26, x25, [sp, #0xd0]
100846010:     	stp	x24, x23, [sp, #0xe0]
100846014:     	stp	x22, x21, [sp, #0xf0]
100846018:     	stp	x20, x19, [sp, #0x100]
10084601c:     	stp	x29, x30, [sp, #0x110]
100846020:     	add	x29, sp, #0x110
100846024:     	mov.16b	v9, v2
100846028:     	mov.16b	v8, v0
10084602c:     	fmov	x19, d8
100846030:     	fmov	x21, d1
100846034:     	fmov	x23, d9
100846038:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
10084603c:     	add	x27, x21, x8
100846040:     	add	x24, x23, x8
100846044:     	fcmp	d2, #0.0
100846048:     	ccmp	x24, #0x2, #0x0, ne
10084604c:     	b.hi	0x10084605c <_js_json_stringify_full+0x5c>
100846050:     	cmp	x27, #0x2
100846054:     	b.lo	0x10084606c <_js_json_stringify_full+0x6c>
100846058:     	b	0x1008465d8 <_js_json_stringify_full+0x5d8>
10084605c:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
100846060:     	cmp	x23, x8
100846064:     	ccmp	x27, #0x2, #0x2, eq
100846068:     	b.hs	0x1008465d8 <_js_json_stringify_full+0x5d8>
10084606c:     	mov	x8, #-0x2               ; =-2
100846070:     	movk	x8, #0x8003, lsl #48
100846074:     	add	x8, x19, x8
100846078:     	cmp	x8, #0x3
10084607c:     	b.hs	0x100846090 <_js_json_stringify_full+0x90>
100846080:     	adrp	x9, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5370>
100846084:     	add	x9, x9, #0x218
100846088:     	ldr	x20, [x9, x8, lsl #3]
10084608c:     	b	0x1008474a8 <_js_json_stringify_full+0x14a8>
100846090:     	strb	wzr, [sp, #0x4c]
100846094:     	str	wzr, [sp, #0x48]
100846098:     	and	x8, x19, #0xffff000000000000
10084609c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
1008460a0:     	cmp	x8, x9
1008460a4:     	b.eq	0x100846118 <_js_json_stringify_full+0x118>
1008460a8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008460ac:     	cmp	x8, x9
1008460b0:     	b.ne	0x100846514 <_js_json_stringify_full+0x514>
1008460b4:     	ubfx	x10, x19, #40, #8
1008460b8:     	cbz	x10, 0x100846108 <_js_json_stringify_full+0x108>
1008460bc:     	strb	w19, [sp, #0x48]
1008460c0:     	cmp	x10, #0x1
1008460c4:     	b.eq	0x100846108 <_js_json_stringify_full+0x108>
1008460c8:     	lsr	x9, x19, #8
1008460cc:     	strb	w9, [sp, #0x49]
1008460d0:     	cmp	x10, #0x2
1008460d4:     	b.eq	0x100846108 <_js_json_stringify_full+0x108>
1008460d8:     	lsr	x9, x19, #16
1008460dc:     	strb	w9, [sp, #0x4a]
1008460e0:     	cmp	x10, #0x3
1008460e4:     	b.eq	0x100846108 <_js_json_stringify_full+0x108>
1008460e8:     	lsr	x9, x19, #24
1008460ec:     	strb	w9, [sp, #0x4b]
1008460f0:     	cmp	x10, #0x4
1008460f4:     	b.eq	0x100846108 <_js_json_stringify_full+0x108>
1008460f8:     	lsr	x9, x19, #32
1008460fc:     	strb	w9, [sp, #0x4c]
100846100:     	cmp	x10, #0x5
100846104:     	b.ne	0x100847c7c <_js_json_stringify_full+0x1c7c>
100846108:     	add	x11, sp, #0x48
10084610c:     	cmp	w10, #0x3
100846110:     	b.ls	0x100846130 <_js_json_stringify_full+0x130>
100846114:     	b	0x100846514 <_js_json_stringify_full+0x514>
100846118:     	ands	x9, x19, #0xffffffffffff
10084611c:     	b.eq	0x1008465d8 <_js_json_stringify_full+0x5d8>
100846120:     	add	x11, x9, #0x14
100846124:     	ldr	w10, [x9, #0x4]
100846128:     	cmp	w10, #0x3
10084612c:     	b.hi	0x100846514 <_js_json_stringify_full+0x514>
100846130:     	stur	wzr, [sp, #0x81]
100846134:     	mov	w9, #0x22               ; =34
100846138:     	strb	w9, [sp, #0x80]
10084613c:     	cbz	w10, 0x100846174 <_js_json_stringify_full+0x174>
100846140:     	add	x12, sp, #0x80
100846144:     	ldrb	w13, [x11]
100846148:     	sxtb	w15, w13
10084614c:     	cmp	w13, #0xb
100846150:     	b.le	0x10084617c <_js_json_stringify_full+0x17c>
100846154:     	cmp	w13, #0x21
100846158:     	b.gt	0x10084619c <_js_json_stringify_full+0x19c>
10084615c:     	cmp	w13, #0xc
100846160:     	b.eq	0x1008461d0 <_js_json_stringify_full+0x1d0>
100846164:     	cmp	w13, #0xd
100846168:     	b.ne	0x1008461ac <_js_json_stringify_full+0x1ac>
10084616c:     	mov	w15, #0x72              ; =114
100846170:     	b	0x1008461dc <_js_json_stringify_full+0x1dc>
100846174:     	mov	w12, #0x1               ; =1
100846178:     	b	0x100846204 <_js_json_stringify_full+0x204>
10084617c:     	cmp	w13, #0x8
100846180:     	b.eq	0x1008461c8 <_js_json_stringify_full+0x1c8>
100846184:     	cmp	w13, #0x9
100846188:     	b.eq	0x1008461d8 <_js_json_stringify_full+0x1d8>
10084618c:     	cmp	w13, #0xa
100846190:     	b.ne	0x1008461ac <_js_json_stringify_full+0x1ac>
100846194:     	mov	w15, #0x6e              ; =110
100846198:     	b	0x1008461dc <_js_json_stringify_full+0x1dc>
10084619c:     	cmp	w13, #0x22
1008461a0:     	b.eq	0x1008461dc <_js_json_stringify_full+0x1dc>
1008461a4:     	cmp	w13, #0x5c
1008461a8:     	b.eq	0x1008461dc <_js_json_stringify_full+0x1dc>
1008461ac:     	cmp	w15, #0x20
1008461b0:     	b.lt	0x100846514 <_js_json_stringify_full+0x514>
1008461b4:     	mov	w14, #0x0               ; =0
1008461b8:     	add	x13, x12, #0x2
1008461bc:     	mov	w12, #0x2               ; =2
1008461c0:     	mov	w16, #0x1               ; =1
1008461c4:     	b	0x1008461f4 <_js_json_stringify_full+0x1f4>
1008461c8:     	mov	w15, #0x62              ; =98
1008461cc:     	b	0x1008461dc <_js_json_stringify_full+0x1dc>
1008461d0:     	mov	w15, #0x66              ; =102
1008461d4:     	b	0x1008461dc <_js_json_stringify_full+0x1dc>
1008461d8:     	mov	w15, #0x74              ; =116
1008461dc:     	add	x13, x12, #0x3
1008461e0:     	mov	w12, #0x5c              ; =92
1008461e4:     	strb	w12, [sp, #0x81]
1008461e8:     	mov	w14, #0x1               ; =1
1008461ec:     	mov	w12, #0x3               ; =3
1008461f0:     	mov	w16, #0x2               ; =2
1008461f4:     	add	x17, sp, #0x80
1008461f8:     	strb	w15, [x17, x16]
1008461fc:     	cmp	w10, #0x1
100846200:     	b.ne	0x10084623c <_js_json_stringify_full+0x23c>
100846204:     	add	x10, sp, #0x80
100846208:     	strb	w9, [x10, x12]
10084620c:     	add	x8, x12, #0x1
100846210:     	cmp	x12, #0x3
100846214:     	b.hs	0x100846228 <_js_json_stringify_full+0x228>
100846218:     	mov	x13, #0x0               ; =0
10084621c:     	mov	x11, #0x0               ; =0
100846220:     	add	x9, sp, #0x80
100846224:     	b	0x100846484 <_js_json_stringify_full+0x484>
100846228:     	cmp	x12, #0xf
10084622c:     	b.hs	0x10084626c <_js_json_stringify_full+0x26c>
100846230:     	mov	x11, #0x0               ; =0
100846234:     	mov	x13, #0x0               ; =0
100846238:     	b	0x1008463e0 <_js_json_stringify_full+0x3e0>
10084623c:     	ldrb	w16, [x11, #0x1]
100846240:     	sxtb	w15, w16
100846244:     	cmp	w16, #0xb
100846248:     	b.le	0x1008464b4 <_js_json_stringify_full+0x4b4>
10084624c:     	cmp	w16, #0x21
100846250:     	b.gt	0x1008464d4 <_js_json_stringify_full+0x4d4>
100846254:     	cmp	w16, #0xc
100846258:     	b.eq	0x100846504 <_js_json_stringify_full+0x504>
10084625c:     	cmp	w16, #0xd
100846260:     	b.ne	0x1008464e4 <_js_json_stringify_full+0x4e4>
100846264:     	mov	w15, #0x72              ; =114
100846268:     	b	0x100846510 <_js_json_stringify_full+0x510>
10084626c:     	and	x12, x8, #0xc
100846270:     	and	x11, x8, #0x10
100846274:     	add	x13, sp, #0x80
100846278:     	add	x9, x13, x11
10084627c:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6370>
100846280:     	ldr	q0, [x14, #0x390]
100846284:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6370>
100846288:     	ldr	q1, [x14, #0x3a0]
10084628c:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6370>
100846290:     	ldr	q2, [x14, #0x3b0]
100846294:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6370>
100846298:     	ldr	q3, [x14, #0x3c0]
10084629c:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6370>
1008462a0:     	ldr	q4, [x14, #0x3d0]
1008462a4:     	movi.2d	v5, #0000000000000000
1008462a8:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6370>
1008462ac:     	ldr	q6, [x14, #0x3e0]
1008462b0:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5370>
1008462b4:     	ldr	q7, [x14, #0x500]
1008462b8:     	mov	w14, #0x10              ; =16
1008462bc:     	movi.2d	v16, #0000000000000000
1008462c0:     	dup.2d	v17, x14
1008462c4:     	adrp	x14, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33b7a>
1008462c8:     	ldr	q19, [x14, #0x400]
1008462cc:     	and	x14, x8, #0x10
1008462d0:     	movi.2d	v20, #0000000000000000
1008462d4:     	movi.2d	v18, #0000000000000000
1008462d8:     	movi.2d	v23, #0000000000000000
1008462dc:     	movi.2d	v21, #0000000000000000
1008462e0:     	movi.2d	v24, #0000000000000000
1008462e4:     	movi.2d	v22, #0000000000000000
1008462e8:     	ldr	q25, [x13], #0x10
1008462ec:     	ushll.8h	v26, v25, #0x0
1008462f0:     	ushll2.4s	v27, v26, #0x0
1008462f4:     	ushll2.2d	v28, v27, #0x0
1008462f8:     	ushll2.8h	v25, v25, #0x0
1008462fc:     	ushll.4s	v29, v25, #0x0
100846300:     	ushll2.2d	v30, v29, #0x0
100846304:     	ushll.2d	v29, v29, #0x0
100846308:     	ushll.2d	v27, v27, #0x0
10084630c:     	ushll.4s	v26, v26, #0x0
100846310:     	ushll2.2d	v31, v26, #0x0
100846314:     	ushll2.4s	v25, v25, #0x0
100846318:     	ushll.2d	v8, v25, #0x0
10084631c:     	ushll.2d	v26, v26, #0x0
100846320:     	ushll2.2d	v25, v25, #0x0
100846324:     	shl.2d	v9, v0, #0x3
100846328:     	ushl.2d	v25, v25, v9
10084632c:     	shl.2d	v9, v19, #0x3
100846330:     	ushl.2d	v26, v26, v9
100846334:     	shl.2d	v9, v1, #0x3
100846338:     	ushl.2d	v8, v8, v9
10084633c:     	shl.2d	v9, v7, #0x3
100846340:     	ushl.2d	v31, v31, v9
100846344:     	shl.2d	v9, v6, #0x3
100846348:     	ushl.2d	v27, v27, v9
10084634c:     	shl.2d	v9, v3, #0x3
100846350:     	ushl.2d	v29, v29, v9
100846354:     	shl.2d	v9, v2, #0x3
100846358:     	ushl.2d	v30, v30, v9
10084635c:     	shl.2d	v9, v4, #0x3
100846360:     	ushl.2d	v28, v28, v9
100846364:     	orr.16b	v18, v28, v18
100846368:     	orr.16b	v21, v30, v21
10084636c:     	orr.16b	v23, v29, v23
100846370:     	orr.16b	v20, v27, v20
100846374:     	orr.16b	v5, v31, v5
100846378:     	orr.16b	v24, v8, v24
10084637c:     	orr.16b	v16, v26, v16
100846380:     	orr.16b	v22, v25, v22
100846384:     	add.2d	v6, v6, v17
100846388:     	add.2d	v7, v7, v17
10084638c:     	add.2d	v19, v19, v17
100846390:     	add.2d	v4, v4, v17
100846394:     	add.2d	v3, v3, v17
100846398:     	add.2d	v2, v2, v17
10084639c:     	add.2d	v1, v1, v17
1008463a0:     	add.2d	v0, v0, v17
1008463a4:     	subs	x14, x14, #0x10
1008463a8:     	b.ne	0x1008462e8 <_js_json_stringify_full+0x2e8>
1008463ac:     	orr.16b	v0, v16, v23
1008463b0:     	orr.16b	v1, v20, v24
1008463b4:     	orr.16b	v0, v0, v1
1008463b8:     	orr.16b	v1, v5, v21
1008463bc:     	orr.16b	v2, v18, v22
1008463c0:     	orr.16b	v1, v1, v2
1008463c4:     	orr.16b	v0, v0, v1
1008463c8:     	mov	d1, v0[1]
1008463cc:     	orr.8b	v0, v0, v1
1008463d0:     	fmov	x13, d0
1008463d4:     	cmp	x8, x11
1008463d8:     	b.eq	0x1008464a4 <_js_json_stringify_full+0x4a4>
1008463dc:     	cbz	x12, 0x100846484 <_js_json_stringify_full+0x484>
1008463e0:     	mov	x14, x11
1008463e4:     	and	x11, x8, #0x1c
1008463e8:     	add	x15, sp, #0x80
1008463ec:     	add	x9, x15, x11
1008463f0:     	fmov	d0, x13
1008463f4:     	movi.2d	v1, #0000000000000000
1008463f8:     	dup.2d	v3, x14
1008463fc:     	adrp	x12, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5370>
100846400:     	ldr	q2, [x12, #0x500]
100846404:     	orr.16b	v2, v3, v2
100846408:     	adrp	x12, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33b7a>
10084640c:     	ldr	q4, [x12, #0x400]
100846410:     	orr.16b	v3, v3, v4
100846414:     	sub	x12, x14, x11
100846418:     	add	x13, x15, x14
10084641c:     	movi.2d	v4, #0x000000000000ff
100846420:     	mov	w14, #0x4               ; =4
100846424:     	dup.2d	v5, x14
100846428:     	ldr	s6, [x13], #0x4
10084642c:     	ushll.8h	v6, v6, #0x0
100846430:     	ushll.4s	v6, v6, #0x0
100846434:     	ushll2.2d	v7, v6, #0x0
100846438:     	and.16b	v7, v7, v4
10084643c:     	ushll.2d	v6, v6, #0x0
100846440:     	and.16b	v6, v6, v4
100846444:     	shl.2d	v16, v2, #0x3
100846448:     	shl.2d	v17, v3, #0x3
10084644c:     	ushl.2d	v6, v6, v17
100846450:     	ushl.2d	v7, v7, v16
100846454:     	orr.16b	v1, v7, v1
100846458:     	orr.16b	v0, v6, v0
10084645c:     	add.2d	v2, v2, v5
100846460:     	add.2d	v3, v3, v5
100846464:     	adds	x12, x12, #0x4
100846468:     	b.ne	0x100846428 <_js_json_stringify_full+0x428>
10084646c:     	orr.16b	v0, v0, v1
100846470:     	mov	d1, v0[1]
100846474:     	orr.8b	v0, v0, v1
100846478:     	fmov	x13, d0
10084647c:     	cmp	x8, x11
100846480:     	b.eq	0x1008464a4 <_js_json_stringify_full+0x4a4>
100846484:     	add	x10, x10, x8
100846488:     	lsl	x11, x11, #3
10084648c:     	ldrb	w12, [x9], #0x1
100846490:     	lsl	x12, x12, x11
100846494:     	orr	x13, x12, x13
100846498:     	add	x11, x11, #0x8
10084649c:     	cmp	x9, x10
1008464a0:     	b.ne	0x10084648c <_js_json_stringify_full+0x48c>
1008464a4:     	orr	x8, x13, x8, lsl #40
1008464a8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008464ac:     	orr	x20, x8, x9
1008464b0:     	b	0x1008474a8 <_js_json_stringify_full+0x14a8>
1008464b4:     	cmp	w16, #0x8
1008464b8:     	b.eq	0x1008464fc <_js_json_stringify_full+0x4fc>
1008464bc:     	cmp	w16, #0x9
1008464c0:     	b.eq	0x10084650c <_js_json_stringify_full+0x50c>
1008464c4:     	cmp	w16, #0xa
1008464c8:     	b.ne	0x1008464e4 <_js_json_stringify_full+0x4e4>
1008464cc:     	mov	w15, #0x6e              ; =110
1008464d0:     	b	0x100846510 <_js_json_stringify_full+0x510>
1008464d4:     	cmp	w16, #0x22
1008464d8:     	b.eq	0x100846510 <_js_json_stringify_full+0x510>
1008464dc:     	cmp	w16, #0x5c
1008464e0:     	b.eq	0x100846510 <_js_json_stringify_full+0x510>
1008464e4:     	cmp	w15, #0x20
1008464e8:     	b.lt	0x100846514 <_js_json_stringify_full+0x514>
1008464ec:     	add	x13, sp, #0x80
1008464f0:     	strb	w15, [x13, x12]
1008464f4:     	add	x12, x12, #0x1
1008464f8:     	b	0x100846a9c <_js_json_stringify_full+0xa9c>
1008464fc:     	mov	w15, #0x62              ; =98
100846500:     	b	0x100846510 <_js_json_stringify_full+0x510>
100846504:     	mov	w15, #0x66              ; =102
100846508:     	b	0x100846510 <_js_json_stringify_full+0x510>
10084650c:     	mov	w15, #0x74              ; =116
100846510:     	tbz	w14, #0x0, 0x100846a88 <_js_json_stringify_full+0xa88>
100846514:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846518:     	cmp	x8, x9
10084651c:     	b.eq	0x100846564 <_js_json_stringify_full+0x564>
100846520:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846524:     	cmp	x8, x9
100846528:     	b.ne	0x1008465d8 <_js_json_stringify_full+0x5d8>
10084652c:     	and	x8, x19, #0xffffffffffff
100846530:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
100846534:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100846538:     	movk	x10, #0xffef, lsl #16
10084653c:     	cmp	x9, x10
100846540:     	b.hi	0x1008465d8 <_js_json_stringify_full+0x5d8>
100846544:     	ldr	w8, [x8, #0x4]
100846548:     	cmp	w8, #0x40
10084654c:     	b.lo	0x1008465d8 <_js_json_stringify_full+0x5d8>
100846550:     	and	x0, x19, #0xffffffffffff
100846554:     	bl	0x1004f3768 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100846558:     	cmp	x0, #0x1
10084655c:     	b.ne	0x1008465d8 <_js_json_stringify_full+0x5d8>
100846560:     	b	0x100846724 <_js_json_stringify_full+0x724>
100846564:     	and	x25, x19, #0xffffffffffff
100846568:     	and	x0, x19, #0xffffffffffff
10084656c:     	bl	0x10057b2c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100846570:     	cbz	x0, 0x1008465a4 <_js_json_stringify_full+0x5a4>
100846574:     	ldrb	w8, [x0]
100846578:     	cmp	w8, #0x2
10084657c:     	b.ne	0x1008465a4 <_js_json_stringify_full+0x5a4>
100846580:     	ldrsb	w8, [x0, #0x1]
100846584:     	tbnz	w8, #0x1f, 0x1008465a4 <_js_json_stringify_full+0x5a4>
100846588:     	ldrh	w8, [x0, #0x2]
10084658c:     	tbnz	w8, #0xb, 0x1008465a4 <_js_json_stringify_full+0x5a4>
100846590:     	ldr	w8, [x0, #0x4]
100846594:     	cmp	w8, #0x18
100846598:     	b.lo	0x1008465a4 <_js_json_stringify_full+0x5a4>
10084659c:     	ldr	w8, [x25]
1008465a0:     	cbz	w8, 0x1008475fc <_js_json_stringify_full+0x15fc>
1008465a4:     	and	x0, x19, #0xffffffffffff
1008465a8:     	bl	0x10057b2c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008465ac:     	cbz	x0, 0x1008465d8 <_js_json_stringify_full+0x5d8>
1008465b0:     	ldrb	w8, [x0]
1008465b4:     	cmp	w8, #0x2
1008465b8:     	b.ne	0x1008465d8 <_js_json_stringify_full+0x5d8>
1008465bc:     	ldrh	w8, [x0, #0x2]
1008465c0:     	tbnz	w8, #0xb, 0x1008465d8 <_js_json_stringify_full+0x5d8>
1008465c4:     	ldr	w8, [x0, #0x4]
1008465c8:     	cmp	w8, #0x18
1008465cc:     	b.lo	0x1008465d8 <_js_json_stringify_full+0x5d8>
1008465d0:     	ldr	w8, [x25]
1008465d4:     	cbz	w8, 0x1008475a0 <_js_json_stringify_full+0x15a0>
1008465d8:     	mov	x20, #0x1               ; =1
1008465dc:     	movk	x20, #0x7ffc, lsl #48
1008465e0:     	cmp	x19, x20
1008465e4:     	b.eq	0x1008474a8 <_js_json_stringify_full+0x14a8>
1008465e8:     	and	x22, x19, #0xffff000000000000
1008465ec:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008465f0:     	cmp	x22, x8
1008465f4:     	b.ne	0x10084662c <_js_json_stringify_full+0x62c>
1008465f8:     	and	x8, x19, #0xffffffffffff
1008465fc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846600:     	b.lo	0x100846618 <_js_json_stringify_full+0x618>
100846604:     	ldr	w8, [x8, #0xc]
100846608:     	mov	w9, #0x4f53             ; =20307
10084660c:     	movk	w9, #0x434c, lsl #16
100846610:     	cmp	w8, w9
100846614:     	b.eq	0x1008474a8 <_js_json_stringify_full+0x14a8>
100846618:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084661c:     	cmp	x22, x8
100846620:     	b.ne	0x100846658 <_js_json_stringify_full+0x658>
100846624:     	and	x0, x19, #0xffffffffffff
100846628:     	b	0x100846680 <_js_json_stringify_full+0x680>
10084662c:     	lsr	x8, x19, #52
100846630:     	cbnz	x8, 0x100846708 <_js_json_stringify_full+0x708>
100846634:     	and	x8, x19, #0x7
100846638:     	cbz	x19, 0x100846664 <_js_json_stringify_full+0x664>
10084663c:     	cbnz	x8, 0x100846664 <_js_json_stringify_full+0x664>
100846640:     	mov	x0, x19
100846644:     	bl	0x10050fa38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846648:     	mov	x8, x19
10084664c:     	tbnz	w0, #0x0, 0x1008465fc <_js_json_stringify_full+0x5fc>
100846650:     	mov	x8, #0x0                ; =0
100846654:     	b	0x100846664 <_js_json_stringify_full+0x664>
100846658:     	lsr	x8, x19, #52
10084665c:     	cbnz	x8, 0x100846708 <_js_json_stringify_full+0x708>
100846660:     	and	x8, x19, #0x7
100846664:     	cbz	x19, 0x100846708 <_js_json_stringify_full+0x708>
100846668:     	cbnz	x8, 0x100846708 <_js_json_stringify_full+0x708>
10084666c:     	mov	x0, x19
100846670:     	bl	0x10050fa38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846674:     	mov	x8, x0
100846678:     	mov	x0, x19
10084667c:     	tbz	w8, #0x0, 0x100846708 <_js_json_stringify_full+0x708>
100846680:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100846684:     	b.lo	0x100846708 <_js_json_stringify_full+0x708>
100846688:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084668c:     	add	x8, x8, #0xfb0
100846690:     	ldaprb	w8, [x8]
100846694:     	cbz	w8, 0x100846708 <_js_json_stringify_full+0x708>
100846698:     	lsr	x8, x0, #3
10084669c:     	mov	x9, #0x7c15             ; =31765
1008466a0:     	movk	x9, #0x7f4a, lsl #16
1008466a4:     	movk	x9, #0x79b9, lsl #32
1008466a8:     	movk	x9, #0x9e37, lsl #48
1008466ac:     	mul	x8, x8, x9
1008466b0:     	lsr	x10, x8, #54
1008466b4:     	lsr	x11, x8, #60
1008466b8:     	adrp	x9, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1008466bc:     	add	x9, x9, #0xf30
1008466c0:     	add	x11, x9, x11, lsl #3
1008466c4:     	ldapr	x11, [x11]
1008466c8:     	lsr	x10, x11, x10
1008466cc:     	tbz	w10, #0x0, 0x100846708 <_js_json_stringify_full+0x708>
1008466d0:     	lsr	x10, x8, #44
1008466d4:     	ubfx	x11, x8, #50, #4
1008466d8:     	add	x11, x9, x11, lsl #3
1008466dc:     	ldapr	x11, [x11]
1008466e0:     	lsr	x10, x11, x10
1008466e4:     	tbz	w10, #0x0, 0x100846708 <_js_json_stringify_full+0x708>
1008466e8:     	lsr	x10, x8, #34
1008466ec:     	ubfx	x8, x8, #40, #4
1008466f0:     	add	x8, x9, x8, lsl #3
1008466f4:     	ldapr	x8, [x8]
1008466f8:     	lsr	x8, x8, x10
1008466fc:     	tbz	w8, #0x0, 0x100846708 <_js_json_stringify_full+0x708>
100846700:     	bl	0x10034d4ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
100846704:     	tbnz	w0, #0x0, 0x1008474a8 <_js_json_stringify_full+0x14a8>
100846708:     	cmp	x24, #0x3
10084670c:     	ccmp	x27, #0x2, #0x2, lo
100846710:     	b.hs	0x100846730 <_js_json_stringify_full+0x730>
100846714:     	mov.16b	v0, v8
100846718:     	bl	0x1004ee83c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084671c:     	cmp	x0, #0x1
100846720:     	b.ne	0x100846730 <_js_json_stringify_full+0x730>
100846724:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100846728:     	bfxil	x20, x1, #0, #48
10084672c:     	b	0x1008474a8 <_js_json_stringify_full+0x14a8>
100846730:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846734:     	cmp	x22, x8
100846738:     	b.ne	0x100846788 <_js_json_stringify_full+0x788>
10084673c:     	ands	x22, x19, #0xffffffffffff
100846740:     	b.eq	0x100846788 <_js_json_stringify_full+0x788>
100846744:     	mov	x0, x22
100846748:     	bl	0x10050fa38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084674c:     	cbz	w0, 0x100846788 <_js_json_stringify_full+0x788>
100846750:     	ldurb	w8, [x22, #-0x8]
100846754:     	cmp	w8, #0x9
100846758:     	b.ne	0x100846788 <_js_json_stringify_full+0x788>
10084675c:     	ldr	w8, [x22, #0x4]
100846760:     	mov	w9, #0x5841             ; =22593
100846764:     	movk	w9, #0x4c5a, lsl #16
100846768:     	cmp	w8, w9
10084676c:     	b.ne	0x100846788 <_js_json_stringify_full+0x788>
100846770:     	mov	x0, x22
100846774:     	bl	0x1006884e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100846778:     	cbz	x0, 0x100846788 <_js_json_stringify_full+0x788>
10084677c:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100846780:     	bfxil	x19, x0, #0, #48
100846784:     	fmov	d8, x19
100846788:     	mov	w8, #0x7ffd             ; =32765
10084678c:     	cmp	x8, x23, lsr #48
100846790:     	b.ne	0x1008467a4 <_js_json_stringify_full+0x7a4>
100846794:     	and	x1, x23, #0xffffffffffff
100846798:     	cmp	x1, #0x100, lsl #12     ; =0x100000
10084679c:     	b.hs	0x1008467b8 <_js_json_stringify_full+0x7b8>
1008467a0:     	b	0x10084680c <_js_json_stringify_full+0x80c>
1008467a4:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
1008467a8:     	mov	x9, #0xfffffff00000     ; =281474975662080
1008467ac:     	mov	x1, x23
1008467b0:     	cmp	x8, x9
1008467b4:     	b.hs	0x10084680c <_js_json_stringify_full+0x80c>
1008467b8:     	lsr	x8, x1, #47
1008467bc:     	cbnz	x8, 0x10084680c <_js_json_stringify_full+0x80c>
1008467c0:     	add	x0, sp, #0x80
1008467c4:     	bl	0x10076e6ac <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
1008467c8:     	ldr	w8, [sp, #0x80]
1008467cc:     	tbz	w8, #0x0, 0x10084680c <_js_json_stringify_full+0x80c>
1008467d0:     	ldr	w8, [sp, #0x88]
1008467d4:     	mov	w9, #-0xff30            ; =-65328
1008467d8:     	cmp	w8, w9
1008467dc:     	b.eq	0x100846800 <_js_json_stringify_full+0x800>
1008467e0:     	mov	w9, #-0xff2f            ; =-65327
1008467e4:     	cmp	w8, w9
1008467e8:     	b.ne	0x10084680c <_js_json_stringify_full+0x80c>
1008467ec:     	mov.16b	v0, v9
1008467f0:     	bl	0x1008488bc <_js_jsvalue_to_string>
1008467f4:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
1008467f8:     	bfxil	x23, x0, #0, #48
1008467fc:     	b	0x10084680c <_js_json_stringify_full+0x80c>
100846800:     	mov.16b	v0, v9
100846804:     	bl	0x10086fe60 <_js_number_coerce>
100846808:     	fmov	x23, d0
10084680c:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100846810:     	add	x8, x23, x8
100846814:     	cmp	x8, #0x3
100846818:     	b.hs	0x100846830 <_js_json_stringify_full+0x830>
10084681c:     	mov	x22, #0x0               ; =0
100846820:     	mov	w8, #0x1                ; =1
100846824:     	stp	xzr, x8, [sp, #0x10]
100846828:     	str	xzr, [sp, #0x20]
10084682c:     	b	0x100846ae4 <_js_json_stringify_full+0xae4>
100846830:     	and	x8, x23, #0xffff000000000000
100846834:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100846838:     	cmp	x8, x9
10084683c:     	b.eq	0x100846860 <_js_json_stringify_full+0x860>
100846840:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846844:     	cmp	x8, x9
100846848:     	b.ne	0x1008468ec <_js_json_stringify_full+0x8ec>
10084684c:     	and	x8, x23, #0xffffffffffff
100846850:     	cmp	x8, #0x1, lsl #12       ; =0x1000
100846854:     	b.hs	0x100846934 <_js_json_stringify_full+0x934>
100846858:     	mov	x9, #0x0                ; =0
10084685c:     	b	0x10084693c <_js_json_stringify_full+0x93c>
100846860:     	strb	wzr, [sp, #0x4c]
100846864:     	str	wzr, [sp, #0x48]
100846868:     	ubfx	x1, x23, #40, #8
10084686c:     	cbz	x1, 0x1008468bc <_js_json_stringify_full+0x8bc>
100846870:     	strb	w23, [sp, #0x48]
100846874:     	cmp	x1, #0x1
100846878:     	b.eq	0x1008468bc <_js_json_stringify_full+0x8bc>
10084687c:     	lsr	x8, x23, #8
100846880:     	strb	w8, [sp, #0x49]
100846884:     	cmp	x1, #0x2
100846888:     	b.eq	0x1008468bc <_js_json_stringify_full+0x8bc>
10084688c:     	lsr	x8, x23, #16
100846890:     	strb	w8, [sp, #0x4a]
100846894:     	cmp	x1, #0x3
100846898:     	b.eq	0x1008468bc <_js_json_stringify_full+0x8bc>
10084689c:     	lsr	x8, x23, #24
1008468a0:     	strb	w8, [sp, #0x4b]
1008468a4:     	cmp	x1, #0x4
1008468a8:     	b.eq	0x1008468bc <_js_json_stringify_full+0x8bc>
1008468ac:     	lsr	x8, x23, #32
1008468b0:     	strb	w8, [sp, #0x4c]
1008468b4:     	cmp	x1, #0x5
1008468b8:     	b.ne	0x100847c7c <_js_json_stringify_full+0x1c7c>
1008468bc:     	add	x8, sp, #0x80
1008468c0:     	add	x0, sp, #0x48
1008468c4:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
1008468c8:     	ldr	w8, [sp, #0x80]
1008468cc:     	ldp	x9, x22, [sp, #0x88]
1008468d0:     	cmp	w8, #0x0
1008468d4:     	csinc	x23, x9, xzr, eq
1008468d8:     	csel	x25, xzr, x22, ne
1008468dc:     	tbz	x25, #0x3f, 0x100846a1c <_js_json_stringify_full+0xa1c>
1008468e0:     	mov	x0, #0x0                ; =0
1008468e4:     	mov	x1, x22
1008468e8:     	bl	0x100b12e00 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008468ec:     	add	x8, x20, #0x3
1008468f0:     	cmp	x23, x8
1008468f4:     	b.eq	0x10084681c <_js_json_stringify_full+0x81c>
1008468f8:     	fmov	d0, x23
1008468fc:     	fcvtzu	x8, d0
100846900:     	mov	w9, #0xa                ; =10
100846904:     	cmp	x8, #0xa
100846908:     	csel	x3, x8, x9, lo
10084690c:     	adrp	x1, 0x100c44000 <_PERRY_EMPTY_STRING+0x1fb4>
100846910:     	add	x1, x1, #0x1dc
100846914:     	add	x0, sp, #0x80
100846918:     	mov	w2, #0x1                ; =1
10084691c:     	bl	0x10022fdb4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
100846920:     	ldr	x22, [sp, #0x90]
100846924:     	str	x22, [sp, #0x20]
100846928:     	ldr	q0, [sp, #0x80]
10084692c:     	str	q0, [sp, #0x10]
100846930:     	b	0x100846ae4 <_js_json_stringify_full+0xae4>
100846934:     	ldr	w22, [x8, #0x4]
100846938:     	add	x9, x8, #0x14
10084693c:     	mov	x14, #0x0               ; =0
100846940:     	mov	x8, #0x0                ; =0
100846944:     	cmp	x9, #0x0
100846948:     	csel	x24, xzr, x22, eq
10084694c:     	csinc	x23, x9, xzr, ne
100846950:     	add	x9, x23, x24
100846954:     	mov	w10, #0x1               ; =1
100846958:     	mov	x11, x23
10084695c:     	b	0x10084698c <_js_json_stringify_full+0x98c>
100846960:     	add	x12, x11, #0x2
100846964:     	bfi	w15, w13, #6, #5
100846968:     	mov	x13, x15
10084696c:     	sub	x11, x25, x11
100846970:     	add	x14, x11, x12
100846974:     	cmp	w13, #0x10, lsl #12     ; =0x10000
100846978:     	cinc	x11, x10, hs
10084697c:     	add	x8, x11, x8
100846980:     	mov	x11, x12
100846984:     	cmp	x8, #0xa
100846988:     	b.hi	0x100846a44 <_js_json_stringify_full+0xa44>
10084698c:     	cmp	x11, x9
100846990:     	b.eq	0x1008469f4 <_js_json_stringify_full+0x9f4>
100846994:     	mov	x25, x14
100846998:     	mov	x12, x11
10084699c:     	ldrsb	w14, [x12], #0x1
1008469a0:     	and	w13, w14, #0xff
1008469a4:     	tbz	w14, #0x1f, 0x10084696c <_js_json_stringify_full+0x96c>
1008469a8:     	ldrb	w12, [x11, #0x1]
1008469ac:     	and	w15, w12, #0x3f
1008469b0:     	cmp	w13, #0xe0
1008469b4:     	b.lo	0x100846960 <_js_json_stringify_full+0x960>
1008469b8:     	and	w14, w13, #0x1f
1008469bc:     	ldrb	w12, [x11, #0x2]
1008469c0:     	and	w12, w12, #0x3f
1008469c4:     	orr	w15, w12, w15, lsl #6
1008469c8:     	cmp	w13, #0xf0
1008469cc:     	b.lo	0x1008469e8 <_js_json_stringify_full+0x9e8>
1008469d0:     	add	x12, x11, #0x4
1008469d4:     	ldrb	w13, [x11, #0x3]
1008469d8:     	and	w13, w13, #0x3f
1008469dc:     	orr	w13, w13, w15, lsl #6
1008469e0:     	bfi	w13, w14, #18, #3
1008469e4:     	b	0x10084696c <_js_json_stringify_full+0x96c>
1008469e8:     	add	x12, x11, #0x3
1008469ec:     	orr	w13, w15, w14, lsl #12
1008469f0:     	b	0x10084696c <_js_json_stringify_full+0x96c>
1008469f4:     	cbz	x24, 0x100846a78 <_js_json_stringify_full+0xa78>
1008469f8:     	mov	x0, x24
1008469fc:     	mov	w1, #0x1                ; =1
100846a00:     	bl	0x100b5fd08 <_mi_malloc_aligned>
100846a04:     	cbz	x0, 0x100847c64 <_js_json_stringify_full+0x1c64>
100846a08:     	mov	x26, x0
100846a0c:     	mov	x1, x23
100846a10:     	mov	x2, x24
100846a14:     	bl	0x100b6292c <_writev+0x100b6292c>
100846a18:     	b	0x100846a80 <_js_json_stringify_full+0xa80>
100846a1c:     	cbz	x25, 0x100846ad4 <_js_json_stringify_full+0xad4>
100846a20:     	mov	x0, x25
100846a24:     	mov	w1, #0x1                ; =1
100846a28:     	bl	0x100b5fd08 <_mi_malloc_aligned>
100846a2c:     	cbz	x0, 0x100847c70 <_js_json_stringify_full+0x1c70>
100846a30:     	mov	x24, x0
100846a34:     	mov	x1, x23
100846a38:     	mov	x2, x25
100846a3c:     	bl	0x100b6292c <_writev+0x100b6292c>
100846a40:     	b	0x100846adc <_js_json_stringify_full+0xadc>
100846a44:     	cbz	x25, 0x100846a78 <_js_json_stringify_full+0xa78>
100846a48:     	cmp	x25, x24
100846a4c:     	b.hs	0x1008474f4 <_js_json_stringify_full+0x14f4>
100846a50:     	ldrsb	w8, [x23, x25]
100846a54:     	cmn	w8, #0x40
100846a58:     	b.ge	0x1008474f8 <_js_json_stringify_full+0x14f8>
100846a5c:     	adrp	x4, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846a60:     	add	x4, x4, #0x270
100846a64:     	mov	x0, x23
100846a68:     	mov	x1, x24
100846a6c:     	mov	x2, #0x0                ; =0
100846a70:     	mov	x3, x25
100846a74:     	bl	0x100b13178 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
100846a78:     	mov	x22, #0x0               ; =0
100846a7c:     	mov	w26, #0x1               ; =1
100846a80:     	stp	x22, x26, [sp, #0x10]
100846a84:     	b	0x100846ae0 <_js_json_stringify_full+0xae0>
100846a88:     	add	x14, sp, #0x80
100846a8c:     	mov	w16, #0x5c              ; =92
100846a90:     	strb	w16, [x14, x12]
100846a94:     	add	x12, x12, #0x2
100846a98:     	strb	w15, [x13, #0x1]
100846a9c:     	cmp	w10, #0x2
100846aa0:     	b.eq	0x100846204 <_js_json_stringify_full+0x204>
100846aa4:     	ldrb	w11, [x11, #0x2]
100846aa8:     	sxtb	w10, w11
100846aac:     	cmp	w11, #0xb
100846ab0:     	b.le	0x100847580 <_js_json_stringify_full+0x1580>
100846ab4:     	cmp	w11, #0x21
100846ab8:     	b.gt	0x1008475cc <_js_json_stringify_full+0x15cc>
100846abc:     	cmp	w11, #0xc
100846ac0:     	b.eq	0x100847658 <_js_json_stringify_full+0x1658>
100846ac4:     	cmp	w11, #0xd
100846ac8:     	b.ne	0x1008475dc <_js_json_stringify_full+0x15dc>
100846acc:     	mov	w10, #0x72              ; =114
100846ad0:     	b	0x100847664 <_js_json_stringify_full+0x1664>
100846ad4:     	mov	x22, #0x0               ; =0
100846ad8:     	mov	w24, #0x1               ; =1
100846adc:     	stp	x22, x24, [sp, #0x10]
100846ae0:     	str	x22, [sp, #0x20]
100846ae4:     	cmp	x27, #0x2
100846ae8:     	b.lo	0x100846c28 <_js_json_stringify_full+0xc28>
100846aec:     	and	x25, x21, #0xffff000000000000
100846af0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846af4:     	cmp	x25, x8
100846af8:     	b.ne	0x100846c04 <_js_json_stringify_full+0xc04>
100846afc:     	and	x23, x21, #0xffffffffffff
100846b00:     	cmp	x23, #0x100, lsl #12    ; =0x100000
100846b04:     	b.lo	0x100846c28 <_js_json_stringify_full+0xc28>
100846b08:     	mov	x0, x23
100846b0c:     	bl	0x10050af40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
100846b10:     	tbnz	w0, #0x0, 0x100846c28 <_js_json_stringify_full+0xc28>
100846b14:     	lsr	x8, x23, #51
100846b18:     	cmp	x8, #0xfff
100846b1c:     	b.lo	0x100846b34 <_js_json_stringify_full+0xb34>
100846b20:     	mov	w8, #0x7ffc             ; =32764
100846b24:     	cmp	x8, x23, lsr #48
100846b28:     	b.eq	0x100846c28 <_js_json_stringify_full+0xc28>
100846b2c:     	ands	x23, x23, #0xffffffffffff
100846b30:     	b.eq	0x100846c28 <_js_json_stringify_full+0xc28>
100846b34:     	and	x8, x23, #0xfffffffffff00000
100846b38:     	lsr	x9, x23, #47
100846b3c:     	cmp	x9, #0x0
100846b40:     	ccmp	x8, #0x0, #0x4, eq
100846b44:     	b.eq	0x100846c28 <_js_json_stringify_full+0xc28>
100846b48:     	tst	x23, #0x3
100846b4c:     	ccmp	x23, #0x7, #0x0, eq
100846b50:     	b.ls	0x100847894 <_js_json_stringify_full+0x1894>
100846b54:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100846b58:     	ldr	x8, [x8, #0x48]
100846b5c:     	cmn	x8, #0x1
100846b60:     	b.eq	0x1008477e4 <_js_json_stringify_full+0x17e4>
100846b64:     	mrs	x9, TPIDRRO_EL0
100846b68:     	and	x9, x9, #0xfffffffffffffff8
100846b6c:     	ldr	x0, [x9, x8, lsl #3]
100846b70:     	cbz	x0, 0x1008477e4 <_js_json_stringify_full+0x17e4>
100846b74:     	lsr	x1, x23, #20
100846b78:     	ldr	x8, [x0, #0x10]
100846b7c:     	ldrb	w9, [x8]
100846b80:     	cmp	w9, #0x2
100846b84:     	b.ne	0x1008477fc <_js_json_stringify_full+0x17fc>
100846b88:     	ldrb	w9, [x8, #0x88]
100846b8c:     	tbz	w9, #0x0, 0x100846bac <_js_json_stringify_full+0xbac>
100846b90:     	ldr	x9, [x8, #0x80]
100846b94:     	cmp	x9, x1
100846b98:     	b.ne	0x100846bac <_js_json_stringify_full+0xbac>
100846b9c:     	ldp	x9, x10, [x8, #0x60]
100846ba0:     	cmp	x9, x23
100846ba4:     	ccmp	x10, x23, #0x0, ls
100846ba8:     	b.hi	0x1008477dc <_js_json_stringify_full+0x17dc>
100846bac:     	ldrb	w9, [x8, #0xb8]
100846bb0:     	cbz	w9, 0x100846bd0 <_js_json_stringify_full+0xbd0>
100846bb4:     	ldr	x9, [x8, #0xb0]
100846bb8:     	cmp	x9, x1
100846bbc:     	b.ne	0x100846bd0 <_js_json_stringify_full+0xbd0>
100846bc0:     	ldp	x9, x10, [x8, #0x90]
100846bc4:     	cmp	x9, x23
100846bc8:     	ccmp	x10, x23, #0x0, ls
100846bcc:     	b.hi	0x100847a64 <_js_json_stringify_full+0x1a64>
100846bd0:     	ldrb	w9, [x8, #0xe8]
100846bd4:     	cbz	w9, 0x10084761c <_js_json_stringify_full+0x161c>
100846bd8:     	ldr	x9, [x8, #0xe0]
100846bdc:     	cmp	x9, x1
100846be0:     	b.ne	0x10084761c <_js_json_stringify_full+0x161c>
100846be4:     	ldr	x9, [x8, #0xc0]
100846be8:     	cmp	x9, x23
100846bec:     	b.hi	0x10084761c <_js_json_stringify_full+0x161c>
100846bf0:     	ldr	x9, [x8, #0xc8]
100846bf4:     	cmp	x9, x23
100846bf8:     	b.ls	0x10084761c <_js_json_stringify_full+0x161c>
100846bfc:     	add	x9, x8, #0xc0
100846c00:     	b	0x100847a68 <_js_json_stringify_full+0x1a68>
100846c04:     	lsr	x8, x21, #52
100846c08:     	cbnz	x8, 0x100846c28 <_js_json_stringify_full+0xc28>
100846c0c:     	cbz	x21, 0x100846c28 <_js_json_stringify_full+0xc28>
100846c10:     	and	x8, x21, #0x7
100846c14:     	cbnz	x8, 0x100846c28 <_js_json_stringify_full+0xc28>
100846c18:     	mov	x0, x21
100846c1c:     	bl	0x10050fa38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846c20:     	mov	x23, x21
100846c24:     	cbnz	w0, 0x100846b00 <_js_json_stringify_full+0xb00>
100846c28:     	mov	x25, #-0x1              ; =-1
100846c2c:     	str	x25, [sp, #0x30]
100846c30:     	mov	w24, #0x1               ; =1
100846c34:     	cmp	x27, #0x1
100846c38:     	cset	w8, hi
100846c3c:     	tst	w8, w24
100846c40:     	b.eq	0x100846cb4 <_js_json_stringify_full+0xcb4>
100846c44:     	and	x23, x21, #0xffff000000000000
100846c48:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846c4c:     	cmp	x23, x8
100846c50:     	b.ne	0x100846c8c <_js_json_stringify_full+0xc8c>
100846c54:     	and	x8, x21, #0xffffffffffff
100846c58:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846c5c:     	b.lo	0x100846cb4 <_js_json_stringify_full+0xcb4>
100846c60:     	ldr	w8, [x8, #0xc]
100846c64:     	mov	w9, #0x4f53             ; =20307
100846c68:     	movk	w9, #0x434c, lsl #16
100846c6c:     	cmp	w8, w9
100846c70:     	b.ne	0x100846cb4 <_js_json_stringify_full+0xcb4>
100846c74:     	and	x8, x21, #0xffffffffffff
100846c78:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846c7c:     	cmp	x23, x9
100846c80:     	csel	x28, x8, x21, eq
100846c84:     	mov	w27, #0x1               ; =1
100846c88:     	b	0x100846cb8 <_js_json_stringify_full+0xcb8>
100846c8c:     	lsr	x8, x21, #52
100846c90:     	cbnz	x8, 0x100846cb4 <_js_json_stringify_full+0xcb4>
100846c94:     	mov	w27, #0x0               ; =0
100846c98:     	cbz	x21, 0x100846cb8 <_js_json_stringify_full+0xcb8>
100846c9c:     	and	x8, x21, #0x7
100846ca0:     	cbnz	x8, 0x100846cb8 <_js_json_stringify_full+0xcb8>
100846ca4:     	mov	x0, x21
100846ca8:     	bl	0x10050fa38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846cac:     	mov	x8, x21
100846cb0:     	tbnz	w0, #0x0, 0x100846c58 <_js_json_stringify_full+0xc58>
100846cb4:     	mov	w27, #0x0               ; =0
100846cb8:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846cbc:     	add	x0, x0, #0xd78
100846cc0:     	ldr	x8, [x0]
100846cc4:     	blr	x8
100846cc8:     	mov	x21, x0
100846ccc:     	ldr	w26, [x0]
100846cd0:     	add	w8, w26, #0x1
100846cd4:     	str	w8, [x0]
100846cd8:     	cbz	w26, 0x100846d48 <_js_json_stringify_full+0xd48>
100846cdc:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846ce0:     	add	x0, x0, #0xd00
100846ce4:     	ldr	x8, [x0]
100846ce8:     	blr	x8
100846cec:     	ldrb	w8, [x0, #0x20]
100846cf0:     	cmp	w8, #0x1
100846cf4:     	b.ne	0x100847ad4 <_js_json_stringify_full+0x1ad4>
100846cf8:     	ldr	x8, [x0]
100846cfc:     	cbnz	x8, 0x100847ae0 <_js_json_stringify_full+0x1ae0>
100846d00:     	mov	x8, #-0x1               ; =-1
100846d04:     	str	x8, [x0]
100846d08:     	ldr	x23, [x0, #0x18]
100846d0c:     	ldr	x8, [x0, #0x8]
100846d10:     	cmp	x23, x8
100846d14:     	b.eq	0x1008474d0 <_js_json_stringify_full+0x14d0>
100846d18:     	ldr	x8, [x0, #0x10]
100846d1c:     	mov	w9, #0x18               ; =24
100846d20:     	madd	x8, x23, x9, x8
100846d24:     	mov	w9, #0x8                ; =8
100846d28:     	stp	xzr, x9, [x8]
100846d2c:     	str	xzr, [x8, #0x10]
100846d30:     	add	x8, x23, #0x1
100846d34:     	str	x8, [x0, #0x18]
100846d38:     	ldr	x8, [x0]
100846d3c:     	add	x8, x8, #0x1
100846d40:     	str	x8, [x0]
100846d44:     	b	0x100846db0 <_js_json_stringify_full+0xdb0>
100846d48:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846d4c:     	add	x0, x0, #0xdc0
100846d50:     	ldr	x8, [x0]
100846d54:     	blr	x8
100846d58:     	strb	wzr, [x0]
100846d5c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846d60:     	add	x0, x0, #0xdf0
100846d64:     	ldr	x8, [x0]
100846d68:     	blr	x8
100846d6c:     	strb	wzr, [x0]
100846d70:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100846d74:     	ldr	w23, [x8, #0x5a8]
100846d78:     	cmp	w23, #0x300
100846d7c:     	b.hs	0x100847518 <_js_json_stringify_full+0x1518>
100846d80:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100846d84:     	ldr	x8, [x8, #0x48]
100846d88:     	cmn	x8, #0x1
100846d8c:     	b.eq	0x100847508 <_js_json_stringify_full+0x1508>
100846d90:     	mrs	x9, TPIDRRO_EL0
100846d94:     	and	x9, x9, #0xfffffffffffffff8
100846d98:     	ldr	x0, [x9, x8, lsl #3]
100846d9c:     	cbz	x0, 0x100847508 <_js_json_stringify_full+0x1508>
100846da0:     	add	x8, x0, x23, lsl #3
100846da4:     	ldr	x0, [x8, #0x1e8]
100846da8:     	cbz	x0, 0x100847518 <_js_json_stringify_full+0x1518>
100846dac:     	str	xzr, [x0]
100846db0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846db4:     	add	x0, x0, #0xd30
100846db8:     	ldr	x8, [x0]
100846dbc:     	blr	x8
100846dc0:     	mov	x23, x0
100846dc4:     	ldrb	w8, [x0, #0x18]
100846dc8:     	cmp	w8, #0x1
100846dcc:     	b.ne	0x100847a88 <_js_json_stringify_full+0x1a88>
100846dd0:     	ldr	x8, [x0]
100846dd4:     	mov	x9, #-0x1               ; =-1
100846dd8:     	str	x9, [x0]
100846ddc:     	cmn	x8, #0x2
100846de0:     	b.eq	0x100847c10 <_js_json_stringify_full+0x1c10>
100846de4:     	cmn	x8, #0x1
100846de8:     	b.eq	0x100846ebc <_js_json_stringify_full+0xebc>
100846dec:     	add	x9, sp, #0x48
100846df0:     	ldur	q0, [x0, #0x8]
100846df4:     	stur	q0, [x9, #0x8]
100846df8:     	str	x8, [sp, #0x48]
100846dfc:     	tbz	w24, #0x0, 0x100846ed0 <_js_json_stringify_full+0xed0>
100846e00:     	tbz	w27, #0x0, 0x100846fb8 <_js_json_stringify_full+0xfb8>
100846e04:     	bl	0x10028bed8 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100846e08:     	str	x0, [sp, #0x60]
100846e0c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846e10:     	stp	x28, x8, [sp, #0x88]
100846e14:     	mov	w8, #0x1                ; =1
100846e18:     	str	x8, [sp, #0x80]
100846e1c:     	add	x0, sp, #0x80
100846e20:     	bl	0x10028bfe0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100846e24:     	mov	x22, x0
100846e28:     	str	x0, [sp, #0x68]
100846e2c:     	mov	w0, #0x0                ; =0
100846e30:     	bl	0x10034bc6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846e34:     	stp	xzr, xzr, [x0]
100846e38:     	str	wzr, [x0, #0x10]
100846e3c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846e40:     	bfxil	x8, x0, #0, #48
100846e44:     	fmov	d0, x8
100846e48:     	bl	0x10020a8e4 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
100846e4c:     	mov	x19, x0
100846e50:     	adrp	x24, 0x100f80000 <_perry_global_worker_ts__1>
100846e54:     	ldr	x8, [x24, #0x48]
100846e58:     	cmn	x8, #0x1
100846e5c:     	b.eq	0x10084701c <_js_json_stringify_full+0x101c>
100846e60:     	mrs	x9, TPIDRRO_EL0
100846e64:     	and	x9, x9, #0xfffffffffffffff8
100846e68:     	ldr	x8, [x9, x8, lsl #3]
100846e6c:     	cbz	x8, 0x10084701c <_js_json_stringify_full+0x101c>
100846e70:     	ldr	x8, [x8, #0x19e8]
100846e74:     	cbz	x8, 0x10084701c <_js_json_stringify_full+0x101c>
100846e78:     	ldr	x9, [x8]
100846e7c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846e80:     	cmp	x9, x10
100846e84:     	b.hs	0x100847b5c <_js_json_stringify_full+0x1b5c>
100846e88:     	add	x10, x9, #0x1
100846e8c:     	str	x10, [x8]
100846e90:     	ldr	x10, [x8, #0x18]
100846e94:     	cmp	x19, x10
100846e98:     	b.hs	0x100847b68 <_js_json_stringify_full+0x1b68>
100846e9c:     	ldr	x10, [x8, #0x10]
100846ea0:     	mov	w11, #0x18              ; =24
100846ea4:     	madd	x10, x19, x11, x10
100846ea8:     	ldr	x11, [x10]
100846eac:     	cbnz	x11, 0x100847bc8 <_js_json_stringify_full+0x1bc8>
100846eb0:     	ldr	x0, [x10, #0x8]
100846eb4:     	str	x9, [x8]
100846eb8:     	b	0x100847024 <_js_json_stringify_full+0x1024>
100846ebc:     	mov	x8, #0x0                ; =0
100846ec0:     	mov	w9, #0x1                ; =1
100846ec4:     	stp	x9, xzr, [sp, #0x50]
100846ec8:     	str	x8, [sp, #0x48]
100846ecc:     	tbnz	w24, #0x0, 0x100846e00 <_js_json_stringify_full+0xe00>
100846ed0:     	cmp	x22, #0x0
100846ed4:     	cset	w6, ne
100846ed8:     	ldp	x0, x1, [sp, #0x38]
100846edc:     	ldp	x3, x4, [sp, #0x18]
100846ee0:     	add	x2, sp, #0x48
100846ee4:     	mov.16b	v0, v8
100846ee8:     	mov	x5, #0x0                ; =0
100846eec:     	bl	0x100503540 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
100846ef0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846ef4:     	add	x0, x0, #0xd90
100846ef8:     	ldr	x8, [x0]
100846efc:     	blr	x8
100846f00:     	ldrb	w8, [x0, #0x20]
100846f04:     	cbnz	w8, 0x100847aec <_js_json_stringify_full+0x1aec>
100846f08:     	ldr	x8, [x0]
100846f0c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100846f10:     	cmp	x8, x9
100846f14:     	b.hs	0x100847b1c <_js_json_stringify_full+0x1b1c>
100846f18:     	ldr	x9, [x0, #0x18]
100846f1c:     	cbz	x9, 0x100846f28 <_js_json_stringify_full+0xf28>
100846f20:     	cbnz	x8, 0x100847b28 <_js_json_stringify_full+0x1b28>
100846f24:     	str	xzr, [x0, #0x18]
100846f28:     	ldp	x0, x1, [sp, #0x50]
100846f2c:     	cmp	x1, #0x5
100846f30:     	b.hi	0x100846f98 <_js_json_stringify_full+0xf98>
100846f34:     	cbz	x1, 0x1008471a8 <_js_json_stringify_full+0x11a8>
100846f38:     	ldrsb	w8, [x0]
100846f3c:     	tbnz	w8, #0x1f, 0x100846f98 <_js_json_stringify_full+0xf98>
100846f40:     	cmp	x1, #0x1
100846f44:     	b.eq	0x100846f80 <_js_json_stringify_full+0xf80>
100846f48:     	ldrsb	w8, [x0, #0x1]
100846f4c:     	tbnz	w8, #0x1f, 0x100846f98 <_js_json_stringify_full+0xf98>
100846f50:     	cmp	x1, #0x2
100846f54:     	b.eq	0x100846f80 <_js_json_stringify_full+0xf80>
100846f58:     	ldrsb	w8, [x0, #0x2]
100846f5c:     	tbnz	w8, #0x1f, 0x100846f98 <_js_json_stringify_full+0xf98>
100846f60:     	cmp	x1, #0x3
100846f64:     	b.eq	0x100846f80 <_js_json_stringify_full+0xf80>
100846f68:     	ldrsb	w8, [x0, #0x3]
100846f6c:     	tbnz	w8, #0x1f, 0x100846f98 <_js_json_stringify_full+0xf98>
100846f70:     	cmp	x1, #0x4
100846f74:     	b.eq	0x100846f80 <_js_json_stringify_full+0xf80>
100846f78:     	ldrsb	w8, [x0, #0x4]
100846f7c:     	tbnz	w8, #0x1f, 0x100846f98 <_js_json_stringify_full+0xf98>
100846f80:     	cmp	x1, #0x4
100846f84:     	b.hs	0x1008472e8 <_js_json_stringify_full+0x12e8>
100846f88:     	mov	x10, #0x0               ; =0
100846f8c:     	mov	x9, #0x0                ; =0
100846f90:     	mov	x8, x0
100846f94:     	b	0x100847378 <_js_json_stringify_full+0x1378>
100846f98:     	bl	0x10032a948 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
100846f9c:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100846fa0:     	bfxil	x20, x0, #0, #48
100846fa4:     	ldp	x22, x0, [sp, #0x48]
100846fa8:     	ldrb	w8, [x23, #0x18]
100846fac:     	cmp	w8, #0x1
100846fb0:     	b.eq	0x1008473b4 <_js_json_stringify_full+0x13b4>
100846fb4:     	b	0x100847ab8 <_js_json_stringify_full+0x1ab8>
100846fb8:     	mov	w0, #0x0                ; =0
100846fbc:     	bl	0x10034bc6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846fc0:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846fc4:     	bfxil	x8, x0, #0, #48
100846fc8:     	fmov	d1, x8
100846fcc:     	stp	xzr, xzr, [x0]
100846fd0:     	str	wzr, [x0, #0x10]
100846fd4:     	mov.16b	v0, v8
100846fd8:     	bl	0x1006c65d0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
100846fdc:     	mov.16b	v8, v0
100846fe0:     	fmov	x24, d8
100846fe4:     	cmp	x24, x20
100846fe8:     	b.eq	0x100847230 <_js_json_stringify_full+0x1230>
100846fec:     	mov	w8, #0x7ffd             ; =32765
100846ff0:     	cmp	x8, x24, lsr #48
100846ff4:     	b.ne	0x100847200 <_js_json_stringify_full+0x1200>
100846ff8:     	and	x8, x24, #0xffffffffffff
100846ffc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100847000:     	b.lo	0x100847224 <_js_json_stringify_full+0x1224>
100847004:     	ldr	w8, [x8, #0xc]
100847008:     	mov	w9, #0x4f53             ; =20307
10084700c:     	movk	w9, #0x434c, lsl #16
100847010:     	cmp	w8, w9
100847014:     	b.ne	0x100847224 <_js_json_stringify_full+0x1224>
100847018:     	b	0x100847230 <_js_json_stringify_full+0x1230>
10084701c:     	mov	x0, x19
100847020:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100847024:     	fmov	d1, x0
100847028:     	mov.16b	v0, v8
10084702c:     	bl	0x1006c65d0 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
100847030:     	mov.16b	v8, v0
100847034:     	ldr	x8, [x24, #0x48]
100847038:     	cmn	x8, #0x1
10084703c:     	b.eq	0x1008470a0 <_js_json_stringify_full+0x10a0>
100847040:     	mrs	x9, TPIDRRO_EL0
100847044:     	and	x9, x9, #0xfffffffffffffff8
100847048:     	ldr	x8, [x9, x8, lsl #3]
10084704c:     	cbz	x8, 0x1008470a0 <_js_json_stringify_full+0x10a0>
100847050:     	ldr	x8, [x8, #0x19e8]
100847054:     	cbz	x8, 0x1008470a0 <_js_json_stringify_full+0x10a0>
100847058:     	ldr	x9, [x8]
10084705c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100847060:     	cmp	x9, x10
100847064:     	b.hs	0x100847b5c <_js_json_stringify_full+0x1b5c>
100847068:     	add	x10, x9, #0x1
10084706c:     	str	x10, [x8]
100847070:     	ldr	x10, [x8, #0x18]
100847074:     	cmp	x22, x10
100847078:     	b.hs	0x100847b68 <_js_json_stringify_full+0x1b68>
10084707c:     	ldr	x10, [x8, #0x10]
100847080:     	mov	w11, #0x18              ; =24
100847084:     	madd	x10, x22, x11, x10
100847088:     	ldr	x11, [x10]
10084708c:     	cmp	x11, #0x1
100847090:     	b.ne	0x100847c28 <_js_json_stringify_full+0x1c28>
100847094:     	ldr	x22, [x10, #0x8]
100847098:     	str	x9, [x8]
10084709c:     	b	0x1008470ac <_js_json_stringify_full+0x10ac>
1008470a0:     	mov	x0, x22
1008470a4:     	bl	0x10013c298 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
1008470a8:     	mov	x22, x0
1008470ac:     	ldr	x8, [x24, #0x48]
1008470b0:     	cmn	x8, #0x1
1008470b4:     	b.eq	0x100847114 <_js_json_stringify_full+0x1114>
1008470b8:     	mrs	x9, TPIDRRO_EL0
1008470bc:     	and	x9, x9, #0xfffffffffffffff8
1008470c0:     	ldr	x8, [x9, x8, lsl #3]
1008470c4:     	cbz	x8, 0x100847114 <_js_json_stringify_full+0x1114>
1008470c8:     	ldr	x8, [x8, #0x19e8]
1008470cc:     	cbz	x8, 0x100847114 <_js_json_stringify_full+0x1114>
1008470d0:     	ldr	x9, [x8]
1008470d4:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1008470d8:     	cmp	x9, x10
1008470dc:     	b.hs	0x100847b5c <_js_json_stringify_full+0x1b5c>
1008470e0:     	add	x10, x9, #0x1
1008470e4:     	str	x10, [x8]
1008470e8:     	ldr	x10, [x8, #0x18]
1008470ec:     	cmp	x19, x10
1008470f0:     	b.hs	0x100847b68 <_js_json_stringify_full+0x1b68>
1008470f4:     	ldr	x10, [x8, #0x10]
1008470f8:     	mov	w11, #0x18              ; =24
1008470fc:     	madd	x10, x19, x11, x10
100847100:     	ldr	x11, [x10]
100847104:     	cbnz	x11, 0x100847bc8 <_js_json_stringify_full+0x1bc8>
100847108:     	ldr	x0, [x10, #0x8]
10084710c:     	str	x9, [x8]
100847110:     	b	0x10084711c <_js_json_stringify_full+0x111c>
100847114:     	mov	x0, x19
100847118:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
10084711c:     	fmov	d9, x0
100847120:     	mov.16b	v0, v8
100847124:     	bl	0x1004ffef4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100847128:     	mov.16b	v2, v0
10084712c:     	mov	x0, x22
100847130:     	mov.16b	v0, v9
100847134:     	mov.16b	v1, v8
100847138:     	bl	0x1005001d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
10084713c:     	str	d0, [sp, #0x70]
100847140:     	fmov	x19, d0
100847144:     	cmp	x19, x20
100847148:     	b.ne	0x1008471b0 <_js_json_stringify_full+0x11b0>
10084714c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847150:     	add	x0, x0, #0xd90
100847154:     	ldr	x8, [x0]
100847158:     	blr	x8
10084715c:     	ldrb	w8, [x0, #0x20]
100847160:     	cbnz	w8, 0x100847c08 <_js_json_stringify_full+0x1c08>
100847164:     	ldr	x8, [x0]
100847168:     	cbnz	x8, 0x100847c58 <_js_json_stringify_full+0x1c58>
10084716c:     	str	xzr, [x0, #0x18]
100847170:     	ldp	x22, x19, [sp, #0x48]
100847174:     	ldrb	w8, [x23, #0x18]
100847178:     	cmp	w8, #0x1
10084717c:     	b.ne	0x100847ba0 <_js_json_stringify_full+0x1ba0>
100847180:     	ldp	x8, x0, [x23]
100847184:     	stp	x22, x19, [x23]
100847188:     	str	xzr, [x23, #0x10]
10084718c:     	sub	x8, x8, #0x1
100847190:     	cmn	x8, #0x2
100847194:     	b.hs	0x10084719c <_js_json_stringify_full+0x119c>
100847198:     	bl	0x100b5fa80 <_mi_free>
10084719c:     	cbz	w26, 0x10084743c <_js_json_stringify_full+0x143c>
1008471a0:     	bl	0x100328ba8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
1008471a4:     	b	0x100847440 <_js_json_stringify_full+0x1440>
1008471a8:     	mov	x10, #0x0               ; =0
1008471ac:     	b	0x100847398 <_js_json_stringify_full+0x1398>
1008471b0:     	add	x0, sp, #0x48
1008471b4:     	bl	0x100500bb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
1008471b8:     	tbnz	w0, #0x0, 0x1008471f4 <_js_json_stringify_full+0x11f4>
1008471bc:     	mov	x0, x19
1008471c0:     	bl	0x1003288ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
1008471c4:     	cmp	x0, #0x1
1008471c8:     	b.ne	0x100847c1c <_js_json_stringify_full+0x1c1c>
1008471cc:     	add	x8, sp, #0x78
1008471d0:     	add	x9, sp, #0x70
1008471d4:     	stp	x1, x8, [sp, #0x78]
1008471d8:     	str	x9, [sp, #0x88]
1008471dc:     	add	x8, sp, #0x48
1008471e0:     	add	x9, sp, #0x10
1008471e4:     	stp	x8, x9, [sp, #0x90]
1008471e8:     	add	x0, sp, #0x68
1008471ec:     	add	x1, sp, #0x80
1008471f0:     	bl	0x100143d90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
1008471f4:     	add	x0, sp, #0x60
1008471f8:     	bl	0x10016663c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1008471fc:     	b	0x100846ef0 <_js_json_stringify_full+0xef0>
100847200:     	lsr	x8, x24, #52
100847204:     	cbnz	x8, 0x100847224 <_js_json_stringify_full+0x1224>
100847208:     	cbz	x24, 0x100847224 <_js_json_stringify_full+0x1224>
10084720c:     	and	x8, x24, #0x7
100847210:     	cbnz	x8, 0x100847224 <_js_json_stringify_full+0x1224>
100847214:     	mov	x0, x24
100847218:     	bl	0x10050fa38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084721c:     	mov	x8, x24
100847220:     	tbnz	w0, #0x0, 0x100846ffc <_js_json_stringify_full+0xffc>
100847224:     	mov	x0, x24
100847228:     	bl	0x100509da4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
10084722c:     	tbz	w0, #0x0, 0x1008472bc <_js_json_stringify_full+0x12bc>
100847230:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847234:     	add	x0, x0, #0xd90
100847238:     	ldr	x8, [x0]
10084723c:     	blr	x8
100847240:     	ldrb	w8, [x0, #0x20]
100847244:     	cbnz	w8, 0x100847b6c <_js_json_stringify_full+0x1b6c>
100847248:     	ldr	x8, [x0]
10084724c:     	cbnz	x8, 0x100847b94 <_js_json_stringify_full+0x1b94>
100847250:     	str	xzr, [x0, #0x18]
100847254:     	ldp	x22, x19, [sp, #0x48]
100847258:     	ldrb	w8, [x23, #0x18]
10084725c:     	cmp	w8, #0x1
100847260:     	b.ne	0x100847b48 <_js_json_stringify_full+0x1b48>
100847264:     	ldp	x8, x0, [x23]
100847268:     	stp	x22, x19, [x23]
10084726c:     	str	xzr, [x23, #0x10]
100847270:     	sub	x8, x8, #0x1
100847274:     	cmn	x8, #0x2
100847278:     	b.hs	0x100847280 <_js_json_stringify_full+0x1280>
10084727c:     	bl	0x100b5fa80 <_mi_free>
100847280:     	cbz	w26, 0x1008472a0 <_js_json_stringify_full+0x12a0>
100847284:     	bl	0x100328ba8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100847288:     	ldr	w8, [x21]
10084728c:     	sub	w8, w8, #0x1
100847290:     	str	w8, [x21]
100847294:     	cmn	x25, #0x1
100847298:     	b.ne	0x10084745c <_js_json_stringify_full+0x145c>
10084729c:     	b	0x100847498 <_js_json_stringify_full+0x1498>
1008472a0:     	bl	0x1003289d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
1008472a4:     	ldr	w8, [x21]
1008472a8:     	sub	w8, w8, #0x1
1008472ac:     	str	w8, [x21]
1008472b0:     	cmn	x25, #0x1
1008472b4:     	b.ne	0x10084745c <_js_json_stringify_full+0x145c>
1008472b8:     	b	0x100847498 <_js_json_stringify_full+0x1498>
1008472bc:     	cmp	x19, x24
1008472c0:     	b.eq	0x1008472cc <_js_json_stringify_full+0x12cc>
1008472c4:     	mov.16b	v0, v8
1008472c8:     	bl	0x10050f16c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
1008472cc:     	cbz	x22, 0x100847528 <_js_json_stringify_full+0x1528>
1008472d0:     	ldp	x1, x2, [sp, #0x18]
1008472d4:     	add	x0, sp, #0x48
1008472d8:     	mov.16b	v0, v8
1008472dc:     	mov	x3, #0x0                ; =0
1008472e0:     	bl	0x10050162c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
1008472e4:     	b	0x100847538 <_js_json_stringify_full+0x1538>
1008472e8:     	and	x9, x1, #0x4
1008472ec:     	add	x8, x0, x9
1008472f0:     	adrp	x10, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5370>
1008472f4:     	ldr	q0, [x10, #0x500]
1008472f8:     	adrp	x10, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33b7a>
1008472fc:     	ldr	q2, [x10, #0x400]
100847300:     	movi.2d	v1, #0000000000000000
100847304:     	movi.2d	v3, #0x000000000000ff
100847308:     	mov	w10, #0x4               ; =4
10084730c:     	dup.2d	v4, x10
100847310:     	mov	x10, x0
100847314:     	and	x11, x1, #0x4
100847318:     	movi.2d	v5, #0000000000000000
10084731c:     	ldr	s6, [x10], #0x4
100847320:     	ushll.8h	v6, v6, #0x0
100847324:     	ushll.4s	v6, v6, #0x0
100847328:     	ushll2.2d	v7, v6, #0x0
10084732c:     	and.16b	v7, v7, v3
100847330:     	ushll.2d	v6, v6, #0x0
100847334:     	and.16b	v6, v6, v3
100847338:     	shl.2d	v16, v0, #0x3
10084733c:     	shl.2d	v17, v2, #0x3
100847340:     	ushl.2d	v6, v6, v17
100847344:     	ushl.2d	v7, v7, v16
100847348:     	orr.16b	v1, v7, v1
10084734c:     	orr.16b	v5, v6, v5
100847350:     	add.2d	v0, v0, v4
100847354:     	add.2d	v2, v2, v4
100847358:     	subs	x11, x11, #0x4
10084735c:     	b.ne	0x10084731c <_js_json_stringify_full+0x131c>
100847360:     	orr.16b	v0, v5, v1
100847364:     	mov	d1, v0[1]
100847368:     	orr.8b	v0, v0, v1
10084736c:     	fmov	x10, d0
100847370:     	cmp	x1, x9
100847374:     	b.eq	0x100847398 <_js_json_stringify_full+0x1398>
100847378:     	add	x11, x0, x1
10084737c:     	lsl	x9, x9, #3
100847380:     	ldrb	w12, [x8], #0x1
100847384:     	lsl	x12, x12, x9
100847388:     	orr	x10, x12, x10
10084738c:     	add	x9, x9, #0x8
100847390:     	cmp	x8, x11
100847394:     	b.ne	0x100847380 <_js_json_stringify_full+0x1380>
100847398:     	orr	x8, x10, x1, lsl #40
10084739c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008473a0:     	orr	x20, x8, x9
1008473a4:     	ldr	x22, [sp, #0x48]
1008473a8:     	ldrb	w8, [x23, #0x18]
1008473ac:     	cmp	w8, #0x1
1008473b0:     	b.ne	0x100847ab8 <_js_json_stringify_full+0x1ab8>
1008473b4:     	ldp	x9, x8, [x23]
1008473b8:     	stp	x22, x0, [x23]
1008473bc:     	str	xzr, [x23, #0x10]
1008473c0:     	sub	x9, x9, #0x1
1008473c4:     	cmn	x9, #0x2
1008473c8:     	b.hs	0x1008473d4 <_js_json_stringify_full+0x13d4>
1008473cc:     	mov	x0, x8
1008473d0:     	bl	0x100b5fa80 <_mi_free>
1008473d4:     	cbz	w26, 0x1008473f4 <_js_json_stringify_full+0x13f4>
1008473d8:     	bl	0x100328ba8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
1008473dc:     	ldr	w8, [x21]
1008473e0:     	sub	w8, w8, #0x1
1008473e4:     	str	w8, [x21]
1008473e8:     	cmn	x25, #0x1
1008473ec:     	b.ne	0x10084740c <_js_json_stringify_full+0x140c>
1008473f0:     	b	0x100847498 <_js_json_stringify_full+0x1498>
1008473f4:     	bl	0x1003289d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
1008473f8:     	ldr	w8, [x21]
1008473fc:     	sub	w8, w8, #0x1
100847400:     	str	w8, [x21]
100847404:     	cmn	x25, #0x1
100847408:     	b.eq	0x100847498 <_js_json_stringify_full+0x1498>
10084740c:     	ldp	x19, x21, [sp, #0x38]
100847410:     	cbz	x21, 0x10084748c <_js_json_stringify_full+0x148c>
100847414:     	add	x22, x19, #0x8
100847418:     	b	0x100847428 <_js_json_stringify_full+0x1428>
10084741c:     	add	x22, x22, #0x18
100847420:     	subs	x21, x21, #0x1
100847424:     	b.eq	0x10084748c <_js_json_stringify_full+0x148c>
100847428:     	ldur	x8, [x22, #-0x8]
10084742c:     	cbz	x8, 0x10084741c <_js_json_stringify_full+0x141c>
100847430:     	ldr	x0, [x22]
100847434:     	bl	0x100b5fa80 <_mi_free>
100847438:     	b	0x10084741c <_js_json_stringify_full+0x141c>
10084743c:     	bl	0x1003289d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100847440:     	ldr	w8, [x21]
100847444:     	sub	w8, w8, #0x1
100847448:     	str	w8, [x21]
10084744c:     	add	x0, sp, #0x60
100847450:     	bl	0x10016663c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100847454:     	cmn	x25, #0x1
100847458:     	b.eq	0x100847498 <_js_json_stringify_full+0x1498>
10084745c:     	ldp	x19, x21, [sp, #0x38]
100847460:     	cbz	x21, 0x10084748c <_js_json_stringify_full+0x148c>
100847464:     	add	x22, x19, #0x8
100847468:     	b	0x100847478 <_js_json_stringify_full+0x1478>
10084746c:     	add	x22, x22, #0x18
100847470:     	subs	x21, x21, #0x1
100847474:     	b.eq	0x10084748c <_js_json_stringify_full+0x148c>
100847478:     	ldur	x8, [x22, #-0x8]
10084747c:     	cbz	x8, 0x10084746c <_js_json_stringify_full+0x146c>
100847480:     	ldr	x0, [x22]
100847484:     	bl	0x100b5fa80 <_mi_free>
100847488:     	b	0x10084746c <_js_json_stringify_full+0x146c>
10084748c:     	cbz	x25, 0x100847498 <_js_json_stringify_full+0x1498>
100847490:     	mov	x0, x19
100847494:     	bl	0x100b5fa80 <_mi_free>
100847498:     	ldr	x8, [sp, #0x10]
10084749c:     	cbz	x8, 0x1008474a8 <_js_json_stringify_full+0x14a8>
1008474a0:     	ldr	x0, [sp, #0x18]
1008474a4:     	bl	0x100b5fa80 <_mi_free>
1008474a8:     	mov	x0, x20
1008474ac:     	ldp	x29, x30, [sp, #0x110]
1008474b0:     	ldp	x20, x19, [sp, #0x100]
1008474b4:     	ldp	x22, x21, [sp, #0xf0]
1008474b8:     	ldp	x24, x23, [sp, #0xe0]
1008474bc:     	ldp	x26, x25, [sp, #0xd0]
1008474c0:     	ldp	x28, x27, [sp, #0xc0]
1008474c4:     	ldp	d9, d8, [sp, #0xb0]
1008474c8:     	add	sp, sp, #0x120
1008474cc:     	ret
1008474d0:     	str	x22, [sp, #0x8]
1008474d4:     	mov	x22, x28
1008474d8:     	mov	x28, x0
1008474dc:     	add	x0, x0, #0x8
1008474e0:     	bl	0x100b3c7d0 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1008474e4:     	mov	x0, x28
1008474e8:     	mov	x28, x22
1008474ec:     	ldr	x22, [sp, #0x8]
1008474f0:     	b	0x100846d18 <_js_json_stringify_full+0xd18>
1008474f4:     	b.ne	0x100846a5c <_js_json_stringify_full+0xa5c>
1008474f8:     	tbz	x25, #0x3f, 0x100847550 <_js_json_stringify_full+0x1550>
1008474fc:     	mov	x0, #0x0                ; =0
100847500:     	mov	x1, x25
100847504:     	bl	0x100b12e00 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847508:     	bl	0x100b3fe7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084750c:     	add	x8, x0, x23, lsl #3
100847510:     	ldr	x0, [x8, #0x1e8]
100847514:     	cbnz	x0, 0x100846dac <_js_json_stringify_full+0xdac>
100847518:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084751c:     	add	x0, x0, #0x138
100847520:     	bl	0x100b3d69c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100847524:     	b	0x100846dac <_js_json_stringify_full+0xdac>
100847528:     	add	x1, sp, #0x48
10084752c:     	mov.16b	v0, v8
100847530:     	mov	w0, #0x0                ; =0
100847534:     	bl	0x100509e7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100847538:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
10084753c:     	add	x0, x0, #0xdc0
100847540:     	ldr	x8, [x0]
100847544:     	blr	x8
100847548:     	strb	wzr, [x0]
10084754c:     	b	0x100846ef0 <_js_json_stringify_full+0xef0>
100847550:     	mov	x0, x25
100847554:     	mov	w1, #0x1                ; =1
100847558:     	bl	0x100b5fd08 <_mi_malloc_aligned>
10084755c:     	mov	x26, x0
100847560:     	mov	w0, #0x1                ; =1
100847564:     	cbz	x26, 0x100847500 <_js_json_stringify_full+0x1500>
100847568:     	mov	x0, x26
10084756c:     	mov	x1, x23
100847570:     	mov	x2, x25
100847574:     	bl	0x100b6292c <_writev+0x100b6292c>
100847578:     	mov	x22, x25
10084757c:     	b	0x100846a80 <_js_json_stringify_full+0xa80>
100847580:     	cmp	w11, #0x8
100847584:     	b.eq	0x100847650 <_js_json_stringify_full+0x1650>
100847588:     	cmp	w11, #0x9
10084758c:     	b.eq	0x100847660 <_js_json_stringify_full+0x1660>
100847590:     	cmp	w11, #0xa
100847594:     	b.ne	0x1008475dc <_js_json_stringify_full+0x15dc>
100847598:     	mov	w10, #0x6e              ; =110
10084759c:     	b	0x100847664 <_js_json_stringify_full+0x1664>
1008475a0:     	mov	x22, x0
1008475a4:     	and	x0, x19, #0xffffffffffff
1008475a8:     	bl	0x100348700 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1008475ac:     	cbz	x0, 0x100847688 <_js_json_stringify_full+0x1688>
1008475b0:     	ldr	w20, [x0]
1008475b4:     	cmp	w20, #0x4
1008475b8:     	b.hi	0x1008465d8 <_js_json_stringify_full+0x5d8>
1008475bc:     	ldr	w8, [x0, #0x4]
1008475c0:     	cmp	w20, w8
1008475c4:     	b.hi	0x1008465d8 <_js_json_stringify_full+0x5d8>
1008475c8:     	b	0x10084768c <_js_json_stringify_full+0x168c>
1008475cc:     	cmp	w11, #0x22
1008475d0:     	b.eq	0x100847664 <_js_json_stringify_full+0x1664>
1008475d4:     	cmp	w11, #0x5c
1008475d8:     	b.eq	0x100847664 <_js_json_stringify_full+0x1664>
1008475dc:     	cmp	x12, #0x3
1008475e0:     	mov	w11, #0x20              ; =32
1008475e4:     	ccmp	w10, w11, #0x8, ls
1008475e8:     	b.lt	0x100846514 <_js_json_stringify_full+0x514>
1008475ec:     	add	x8, sp, #0x80
1008475f0:     	strb	w10, [x8, x12]
1008475f4:     	add	x12, x12, #0x1
1008475f8:     	b	0x100846204 <_js_json_stringify_full+0x204>
1008475fc:     	mov	x1, x0
100847600:     	and	x0, x19, #0xffffffffffff
100847604:     	mov	x22, x1
100847608:     	bl	0x1004f98c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
10084760c:     	cmp	x0, #0x1
100847610:     	b.ne	0x100847734 <_js_json_stringify_full+0x1734>
100847614:     	mov	x20, x1
100847618:     	b	0x1008474a8 <_js_json_stringify_full+0x14a8>
10084761c:     	ldrb	w9, [x8, #0x118]
100847620:     	cbz	w9, 0x10084785c <_js_json_stringify_full+0x185c>
100847624:     	ldr	x9, [x8, #0x110]
100847628:     	cmp	x9, x1
10084762c:     	b.ne	0x10084785c <_js_json_stringify_full+0x185c>
100847630:     	ldr	x9, [x8, #0xf0]
100847634:     	cmp	x9, x23
100847638:     	b.hi	0x10084785c <_js_json_stringify_full+0x185c>
10084763c:     	ldr	x9, [x8, #0xf8]
100847640:     	cmp	x9, x23
100847644:     	b.ls	0x10084785c <_js_json_stringify_full+0x185c>
100847648:     	add	x9, x8, #0xf0
10084764c:     	b	0x100847a68 <_js_json_stringify_full+0x1a68>
100847650:     	mov	w10, #0x62              ; =98
100847654:     	b	0x100847664 <_js_json_stringify_full+0x1664>
100847658:     	mov	w10, #0x66              ; =102
10084765c:     	b	0x100847664 <_js_json_stringify_full+0x1664>
100847660:     	mov	w10, #0x74              ; =116
100847664:     	cmp	x12, #0x2
100847668:     	b.hi	0x100846514 <_js_json_stringify_full+0x514>
10084766c:     	add	x8, sp, #0x80
100847670:     	add	x8, x8, x12
100847674:     	add	x12, x12, #0x2
100847678:     	mov	w11, #0x5c              ; =92
10084767c:     	strb	w11, [x8]
100847680:     	strb	w10, [x8, #0x1]
100847684:     	b	0x100846204 <_js_json_stringify_full+0x204>
100847688:     	mov	x20, #0x0               ; =0
10084768c:     	ldr	w8, [x22, #0x4]
100847690:     	lsl	x9, x20, #3
100847694:     	add	x9, x9, #0x18
100847698:     	cmp	x9, x8
10084769c:     	b.hi	0x1008465d8 <_js_json_stringify_full+0x5d8>
1008476a0:     	ldr	w8, [x25, #0x4]
1008476a4:     	mov	w9, #-0x40000000        ; =-1073741824
1008476a8:     	cmp	w8, w9
1008476ac:     	csel	w8, w8, wzr, lt
1008476b0:     	mov	x22, x0
1008476b4:     	mov	x0, x8
1008476b8:     	bl	0x1005e5fe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
1008476bc:     	mov	w9, #0x2                ; =2
1008476c0:     	cmp	w1, #0x2
1008476c4:     	csel	w10, w1, w9, hi
1008476c8:     	tst	w0, #0x1
1008476cc:     	csel	x8, x10, x9, ne
1008476d0:     	cmp	x20, x8
1008476d4:     	b.hi	0x1008465d8 <_js_json_stringify_full+0x5d8>
1008476d8:     	cbz	x20, 0x100847a98 <_js_json_stringify_full+0x1a98>
1008476dc:     	mov	x0, x22
1008476e0:     	mov	x1, x20
1008476e4:     	bl	0x1004f0880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008476e8:     	tbz	w0, #0x0, 0x1008465d8 <_js_json_stringify_full+0x5d8>
1008476ec:     	cmp	x20, #0x1
1008476f0:     	b.eq	0x100847b34 <_js_json_stringify_full+0x1b34>
1008476f4:     	cmp	x20, #0x2
1008476f8:     	b.ne	0x100847bf0 <_js_json_stringify_full+0x1bf0>
1008476fc:     	mov	x22, #0x0               ; =0
100847700:     	add	x25, x25, #0x10
100847704:     	mov	w8, #0x1                ; =1
100847708:     	mov	x26, x8
10084770c:     	ldr	x1, [x25, x22, lsl #3]
100847710:     	add	x0, sp, #0x80
100847714:     	bl	0x1004f08d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
100847718:     	ldr	w8, [sp, #0x80]
10084771c:     	cmn	w8, #0x1
100847720:     	b.ne	0x100847bd8 <_js_json_stringify_full+0x1bd8>
100847724:     	mov	w8, #0x0                ; =0
100847728:     	mov	w22, #0x1               ; =1
10084772c:     	tbnz	w26, #0x0, 0x100847708 <_js_json_stringify_full+0x1708>
100847730:     	b	0x100847bf0 <_js_json_stringify_full+0x1bf0>
100847734:     	and	x0, x19, #0xffffffffffff
100847738:     	bl	0x100348700 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084773c:     	cbz	x0, 0x1008477c8 <_js_json_stringify_full+0x17c8>
100847740:     	ldr	w20, [x0]
100847744:     	cbz	w20, 0x1008477c8 <_js_json_stringify_full+0x17c8>
100847748:     	cmp	w20, #0x8
10084774c:     	b.hi	0x1008465a4 <_js_json_stringify_full+0x5a4>
100847750:     	ldr	w8, [x0, #0x4]
100847754:     	cmp	w20, w8
100847758:     	b.hi	0x1008465a4 <_js_json_stringify_full+0x5a4>
10084775c:     	ldr	w8, [x22, #0x4]
100847760:     	lsl	x9, x20, #3
100847764:     	add	x9, x9, #0x18
100847768:     	cmp	x9, x8
10084776c:     	b.hi	0x1008465a4 <_js_json_stringify_full+0x5a4>
100847770:     	ldr	w8, [x25, #0x4]
100847774:     	mov	w9, #-0x40000000        ; =-1073741824
100847778:     	cmp	w8, w9
10084777c:     	csel	w8, w8, wzr, lt
100847780:     	mov	x22, x0
100847784:     	mov	x0, x8
100847788:     	bl	0x1005e5fe4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084778c:     	mov	w9, #0x2                ; =2
100847790:     	cmp	w1, #0x2
100847794:     	csel	w10, w1, w9, hi
100847798:     	tst	w0, #0x1
10084779c:     	csel	w8, w10, w9, ne
1008477a0:     	cmp	w20, w8
1008477a4:     	b.hi	0x1008465a4 <_js_json_stringify_full+0x5a4>
1008477a8:     	mov	x0, x22
1008477ac:     	mov	x1, x20
1008477b0:     	bl	0x1004f0880 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008477b4:     	cbz	w0, 0x1008465a4 <_js_json_stringify_full+0x5a4>
1008477b8:     	and	x0, x19, #0xffffffffffff
1008477bc:     	mov	x1, x20
1008477c0:     	bl	0x1004f8a00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
1008477c4:     	b	0x1008477d0 <_js_json_stringify_full+0x17d0>
1008477c8:     	and	x0, x19, #0xffffffffffff
1008477cc:     	bl	0x1004f9780 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
1008477d0:     	mov	x20, x1
1008477d4:     	tbz	w0, #0x0, 0x1008465a4 <_js_json_stringify_full+0x5a4>
1008477d8:     	b	0x1008474a8 <_js_json_stringify_full+0x14a8>
1008477dc:     	add	x9, x8, #0x60
1008477e0:     	b	0x100847a68 <_js_json_stringify_full+0x1a68>
1008477e4:     	bl	0x100b3fe7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1008477e8:     	lsr	x1, x23, #20
1008477ec:     	ldr	x8, [x0, #0x10]
1008477f0:     	ldrb	w9, [x8]
1008477f4:     	cmp	w9, #0x2
1008477f8:     	b.eq	0x100846b88 <_js_json_stringify_full+0xb88>
1008477fc:     	ldr	x9, [x8, #0x8]
100847800:     	ldr	x10, [x8, #0x28]
100847804:     	sub	x9, x1, x9
100847808:     	cmp	x9, x10
10084780c:     	b.hs	0x100847850 <_js_json_stringify_full+0x1850>
100847810:     	ldr	x10, [x8, #0x20]
100847814:     	mov	w11, #0x28              ; =40
100847818:     	madd	x9, x9, x11, x10
10084781c:     	ldr	x10, [x9]
100847820:     	ldr	x11, [x8, #0x10]
100847824:     	cmp	x10, x11
100847828:     	b.ne	0x10084785c <_js_json_stringify_full+0x185c>
10084782c:     	ldp	x10, x11, [x9, #0x8]
100847830:     	cmp	x10, x23
100847834:     	ccmp	x11, x23, #0x0, ls
100847838:     	b.ls	0x10084785c <_js_json_stringify_full+0x185c>
10084783c:     	ldr	x10, [x8, #0x30]
100847840:     	add	x10, x10, #0x1
100847844:     	str	x10, [x8, #0x30]
100847848:     	add	x8, x9, #0x21
10084784c:     	b	0x100847a78 <_js_json_stringify_full+0x1a78>
100847850:     	ldr	x9, [x8, #0x58]
100847854:     	add	x9, x9, #0x1
100847858:     	str	x9, [x8, #0x58]
10084785c:     	ldr	x9, [x8, #0x38]
100847860:     	add	x9, x9, #0x1
100847864:     	str	x9, [x8, #0x38]
100847868:     	mov	x0, x23
10084786c:     	bl	0x10051ec48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100847870:     	and	w8, w0, #0xff
100847874:     	cbz	w8, 0x100847894 <_js_json_stringify_full+0x1894>
100847878:     	ldurb	w8, [x23, #-0x8]
10084787c:     	ldurb	w9, [x23, #-0x7]
100847880:     	mov	w10, #0x82              ; =130
100847884:     	and	w9, w9, w10
100847888:     	cmp	w9, #0x2
10084788c:     	ccmp	w8, #0x1, #0x0, eq
100847890:     	b.eq	0x100847928 <_js_json_stringify_full+0x1928>
100847894:     	mov	x0, x23
100847898:     	bl	0x10057b2c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084789c:     	mov	x24, x0
1008478a0:     	cbz	x0, 0x1008478cc <_js_json_stringify_full+0x18cc>
1008478a4:     	ldrb	w8, [x24]
1008478a8:     	cmp	w8, #0x1
1008478ac:     	b.ne	0x1008478ec <_js_json_stringify_full+0x18ec>
1008478b0:     	ldrsb	w8, [x24, #0x1]
1008478b4:     	tbnz	w8, #0x1f, 0x100847950 <_js_json_stringify_full+0x1950>
1008478b8:     	mov	x0, x24
1008478bc:     	ldp	w9, w8, [x23]
1008478c0:     	cmp	w9, w8
1008478c4:     	b.hi	0x1008479d4 <_js_json_stringify_full+0x19d4>
1008478c8:     	b	0x1008479ec <_js_json_stringify_full+0x19ec>
1008478cc:     	mov	x0, x23
1008478d0:     	bl	0x100589af4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1008478d4:     	tbnz	w0, #0x0, 0x1008478e4 <_js_json_stringify_full+0x18e4>
1008478d8:     	mov	x0, x23
1008478dc:     	bl	0x1002a4a08 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
1008478e0:     	tbz	w0, #0x0, 0x100846c28 <_js_json_stringify_full+0xc28>
1008478e4:     	mov	x0, #0x0                ; =0
1008478e8:     	b	0x1008479c4 <_js_json_stringify_full+0x19c4>
1008478ec:     	mov	x0, x24
1008478f0:     	cmp	w8, #0x1
1008478f4:     	b.eq	0x1008479c4 <_js_json_stringify_full+0x19c4>
1008478f8:     	cmp	w8, #0x9
1008478fc:     	b.ne	0x100846c28 <_js_json_stringify_full+0xc28>
100847900:     	ldr	w8, [x23, #0x4]
100847904:     	mov	w9, #0x5841             ; =22593
100847908:     	movk	w9, #0x4c5a, lsl #16
10084790c:     	cmp	w8, w9
100847910:     	b.ne	0x100846c28 <_js_json_stringify_full+0xc28>
100847914:     	mov	x0, x23
100847918:     	bl	0x100376910 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
10084791c:     	mov	x23, x0
100847920:     	cbnz	x0, 0x100847a14 <_js_json_stringify_full+0x1a14>
100847924:     	b	0x100846c28 <_js_json_stringify_full+0xc28>
100847928:     	ldr	w8, [x23]
10084792c:     	mov	w9, #0xe100             ; =57600
100847930:     	movk	w9, #0x5f5, lsl #16
100847934:     	orr	w9, w9, #0x1
100847938:     	cmp	w8, w9
10084793c:     	b.hs	0x100847894 <_js_json_stringify_full+0x1894>
100847940:     	ldr	w9, [x23, #0x4]
100847944:     	cmp	w8, w9
100847948:     	b.ls	0x100847a14 <_js_json_stringify_full+0x1a14>
10084794c:     	b	0x100847894 <_js_json_stringify_full+0x1894>
100847950:     	ldr	x23, [x24, #0x8]
100847954:     	mov	x0, x23
100847958:     	bl	0x10057b2c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084795c:     	cbz	x0, 0x100846c28 <_js_json_stringify_full+0xc28>
100847960:     	ldrb	w8, [x0]
100847964:     	cmp	w8, #0x1
100847968:     	b.ne	0x100846c28 <_js_json_stringify_full+0xc28>
10084796c:     	ldrsb	w8, [x0, #0x1]
100847970:     	tbz	w8, #0x1f, 0x1008478bc <_js_json_stringify_full+0x18bc>
100847974:     	mov	w26, #0x1               ; =1
100847978:     	ldr	x23, [x0, #0x8]
10084797c:     	mov	x0, x23
100847980:     	bl	0x10057b2c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100847984:     	cbz	x0, 0x100846c28 <_js_json_stringify_full+0xc28>
100847988:     	ldrb	w8, [x0]
10084798c:     	cmp	w8, #0x1
100847990:     	b.ne	0x100846c28 <_js_json_stringify_full+0xc28>
100847994:     	cmp	w26, #0x3f
100847998:     	b.hi	0x100846c28 <_js_json_stringify_full+0xc28>
10084799c:     	add	w26, w26, #0x1
1008479a0:     	ldrsb	w8, [x0, #0x1]
1008479a4:     	tbnz	w8, #0x1f, 0x100847978 <_js_json_stringify_full+0x1978>
1008479a8:     	str	x23, [x24, #0x8]
1008479ac:     	ldrb	w8, [x24, #0x1]
1008479b0:     	orr	w8, w8, #0x80
1008479b4:     	strb	w8, [x24, #0x1]
1008479b8:     	ldrb	w8, [x0]
1008479bc:     	cmp	w8, #0x1
1008479c0:     	b.ne	0x1008478f8 <_js_json_stringify_full+0x18f8>
1008479c4:     	ldp	w9, w8, [x23]
1008479c8:     	cmp	w9, w8
1008479cc:     	b.ls	0x1008479ec <_js_json_stringify_full+0x19ec>
1008479d0:     	cbz	x24, 0x1008479fc <_js_json_stringify_full+0x19fc>
1008479d4:     	ldr	w9, [x0, #0x4]
1008479d8:     	ubfiz	x8, x8, #3, #32
1008479dc:     	add	x8, x8, #0x10
1008479e0:     	cmp	x8, x9
1008479e4:     	b.eq	0x100847a14 <_js_json_stringify_full+0x1a14>
1008479e8:     	b	0x1008479fc <_js_json_stringify_full+0x19fc>
1008479ec:     	mov	w8, #0xe100             ; =57600
1008479f0:     	movk	w8, #0x5f5, lsl #16
1008479f4:     	cmp	w9, w8
1008479f8:     	b.ls	0x100847a14 <_js_json_stringify_full+0x1a14>
1008479fc:     	mov	x0, x23
100847a00:     	bl	0x100589af4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100847a04:     	tbnz	w0, #0x0, 0x100847a14 <_js_json_stringify_full+0x1a14>
100847a08:     	mov	x0, x23
100847a0c:     	bl	0x1002a4a08 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100847a10:     	tbz	w0, #0x0, 0x100846c28 <_js_json_stringify_full+0xc28>
100847a14:     	ldp	w8, w9, [x23]
100847a18:     	sub	w10, w9, #0x1
100847a1c:     	mov	w11, #0x270f            ; =9999
100847a20:     	cmp	w10, w11
100847a24:     	ccmp	w8, w9, #0x2, lo
100847a28:     	b.hi	0x100846c28 <_js_json_stringify_full+0xc28>
100847a2c:     	and	x8, x21, #0xffffffffffff
100847a30:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100847a34:     	cmp	x25, x9
100847a38:     	csel	x1, x8, x21, eq
100847a3c:     	add	x0, sp, #0x30
100847a40:     	bl	0x1005003bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
100847a44:     	ldr	x25, [sp, #0x30]
100847a48:     	cmn	x25, #0x1
100847a4c:     	cset	w24, eq
100847a50:     	cmp	x27, #0x1
100847a54:     	cset	w8, hi
100847a58:     	tst	w8, w24
100847a5c:     	b.ne	0x100846c44 <_js_json_stringify_full+0xc44>
100847a60:     	b	0x100846cb4 <_js_json_stringify_full+0xcb4>
100847a64:     	add	x9, x8, #0x90
100847a68:     	ldr	x10, [x8, #0x30]
100847a6c:     	add	x10, x10, #0x1
100847a70:     	str	x10, [x8, #0x30]
100847a74:     	add	x8, x9, #0x19
100847a78:     	ldrb	w8, [x8]
100847a7c:     	cmp	w8, #0xff
100847a80:     	b.ne	0x100847874 <_js_json_stringify_full+0x1874>
100847a84:     	b	0x100847868 <_js_json_stringify_full+0x1868>
100847a88:     	mov	x0, x23
100847a8c:     	bl	0x100b1f004 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847a90:     	cbnz	x0, 0x100846dd0 <_js_json_stringify_full+0xdd0>
100847a94:     	b	0x100847c10 <_js_json_stringify_full+0x1c10>
100847a98:     	and	x0, x19, #0xffffffffffff
100847a9c:     	bl	0x1004f8830 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
100847aa0:     	mov	w0, w0
100847aa4:     	mov	x20, #0x7d7b            ; =32123
100847aa8:     	movk	x20, #0x200, lsl #32
100847aac:     	movk	x20, #0x7ff9, lsl #48
100847ab0:     	tbz	w0, #0x0, 0x1008465d8 <_js_json_stringify_full+0x5d8>
100847ab4:     	b	0x1008474a8 <_js_json_stringify_full+0x14a8>
100847ab8:     	mov	x19, x0
100847abc:     	mov	x0, x23
100847ac0:     	bl	0x100b1f004 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847ac4:     	mov	x23, x0
100847ac8:     	mov	x0, x19
100847acc:     	cbnz	x23, 0x1008473b4 <_js_json_stringify_full+0x13b4>
100847ad0:     	b	0x100847bb0 <_js_json_stringify_full+0x1bb0>
100847ad4:     	bl	0x100b1f164 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100847ad8:     	cbnz	x0, 0x100846cf8 <_js_json_stringify_full+0xcf8>
100847adc:     	b	0x100847c10 <_js_json_stringify_full+0x1c10>
100847ae0:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100847ae4:     	add	x0, x0, #0x440
100847ae8:     	bl	0x100b131ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847aec:     	cmp	w8, #0x1
100847af0:     	b.ne	0x100847c10 <_js_json_stringify_full+0x1c10>
100847af4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime13async_context12ContextGuardEEEB2h_+0xf8>
100847af8:     	add	x1, x1, #0x158
100847afc:     	mov	x19, x0
100847b00:     	bl	0x100a20edc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847b04:     	mov	x0, x19
100847b08:     	strb	wzr, [x19, #0x20]
100847b0c:     	ldr	x8, [x19]
100847b10:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100847b14:     	cmp	x8, x9
100847b18:     	b.lo	0x100846f18 <_js_json_stringify_full+0xf18>
100847b1c:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847b20:     	add	x0, x0, #0xea8
100847b24:     	bl	0x100b131dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100847b28:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847b2c:     	add	x0, x0, #0xec0
100847b30:     	bl	0x100b131ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847b34:     	and	x0, x19, #0xffffffffffff
100847b38:     	bl	0x1004f0480 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
100847b3c:     	mov	x20, x1
100847b40:     	tbz	w0, #0x0, 0x1008465d8 <_js_json_stringify_full+0x5d8>
100847b44:     	b	0x1008474a8 <_js_json_stringify_full+0x14a8>
100847b48:     	mov	x0, x23
100847b4c:     	bl	0x100b1f004 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847b50:     	mov	x23, x0
100847b54:     	cbnz	x0, 0x100847264 <_js_json_stringify_full+0x1264>
100847b58:     	b	0x100847bb0 <_js_json_stringify_full+0x1bb0>
100847b5c:     	adrp	x0, 0x100ef7000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100847b60:     	add	x0, x0, #0xd70
100847b64:     	bl	0x100b131dc <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100847b68:     	bl	0x100b4c414 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
100847b6c:     	cmp	w8, #0x2
100847b70:     	b.eq	0x100847c10 <_js_json_stringify_full+0x1c10>
100847b74:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime13async_context12ContextGuardEEEB2h_+0xf8>
100847b78:     	add	x1, x1, #0x158
100847b7c:     	mov	x19, x0
100847b80:     	bl	0x100a20edc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847b84:     	mov	x0, x19
100847b88:     	strb	wzr, [x19, #0x20]
100847b8c:     	ldr	x8, [x19]
100847b90:     	cbz	x8, 0x100847250 <_js_json_stringify_full+0x1250>
100847b94:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847b98:     	add	x0, x0, #0xe90
100847b9c:     	bl	0x100b131ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847ba0:     	mov	x0, x23
100847ba4:     	bl	0x100b1f004 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847ba8:     	mov	x23, x0
100847bac:     	cbnz	x0, 0x100847180 <_js_json_stringify_full+0x1180>
100847bb0:     	cbz	x22, 0x100847c10 <_js_json_stringify_full+0x1c10>
100847bb4:     	mov	x0, x19
100847bb8:     	bl	0x100b5fa80 <_mi_free>
100847bbc:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847bc0:     	add	x0, x0, #0xc18
100847bc4:     	bl	0x100b590dc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100847bc8:     	adrp	x0, 0x100c42000 <_anon.3a0f55142d697dd4d6c50f8035b0d3d6.3+0x5480>
100847bcc:     	add	x0, x0, #0xf70
100847bd0:     	mov	w1, #0xf                ; =15
100847bd4:     	bl	0x100b4c3dc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100847bd8:     	and	x0, x19, #0xffffffffffff
100847bdc:     	add	x2, sp, #0x80
100847be0:     	mov	x1, x22
100847be4:     	bl	0x1004f0c80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
100847be8:     	tbnz	w0, #0x0, 0x100847614 <_js_json_stringify_full+0x1614>
100847bec:     	mov	w20, #0x2               ; =2
100847bf0:     	and	x0, x19, #0xffffffffffff
100847bf4:     	mov	x1, x20
100847bf8:     	bl	0x1004ef300 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
100847bfc:     	mov	x20, x1
100847c00:     	tbz	w0, #0x0, 0x1008465d8 <_js_json_stringify_full+0x5d8>
100847c04:     	b	0x1008474a8 <_js_json_stringify_full+0x14a8>
100847c08:     	cmp	w8, #0x2
100847c0c:     	b.ne	0x100847c38 <_js_json_stringify_full+0x1c38>
100847c10:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847c14:     	add	x0, x0, #0xc18
100847c18:     	bl	0x100b590dc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100847c1c:     	adrp	x0, 0x100f2f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x190>
100847c20:     	add	x0, x0, #0x848
100847c24:     	bl	0x100b13270 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100847c28:     	adrp	x0, 0x100c42000 <_anon.3a0f55142d697dd4d6c50f8035b0d3d6.3+0x5480>
100847c2c:     	add	x0, x0, #0xca7
100847c30:     	mov	w1, #0xb                ; =11
100847c34:     	bl	0x100b4c3dc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100847c38:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime13async_context12ContextGuardEEEB2h_+0xf8>
100847c3c:     	add	x1, x1, #0x158
100847c40:     	mov	x19, x0
100847c44:     	bl	0x100a20edc <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847c48:     	mov	x0, x19
100847c4c:     	strb	wzr, [x19, #0x20]
100847c50:     	ldr	x8, [x19]
100847c54:     	cbz	x8, 0x10084716c <_js_json_stringify_full+0x116c>
100847c58:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847c5c:     	add	x0, x0, #0xe78
100847c60:     	bl	0x100b131ac <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847c64:     	mov	w0, #0x1                ; =1
100847c68:     	mov	x1, x24
100847c6c:     	bl	0x100b12e00 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847c70:     	mov	w0, #0x1                ; =1
100847c74:     	mov	x1, x22
100847c78:     	bl	0x100b12e00 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847c7c:     	adrp	x2, 0x100ef8000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100847c80:     	add	x2, x2, #0x3c8
100847c84:     	mov	w0, #0x5                ; =5
100847c88:     	mov	w1, #0x5                ; =5
100847c8c:     	bl	0x100b1330c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
