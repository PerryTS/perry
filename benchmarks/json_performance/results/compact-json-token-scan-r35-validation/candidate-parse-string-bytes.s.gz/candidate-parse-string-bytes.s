
benchmarks/json_performance/.work/compact-json-token-scan-r35/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100245138 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>:
100245138:     	stp	x26, x25, [sp, #-0x50]!
10024513c:     	stp	x24, x23, [sp, #0x10]
100245140:     	stp	x22, x21, [sp, #0x20]
100245144:     	stp	x20, x19, [sp, #0x30]
100245148:     	stp	x29, x30, [sp, #0x40]
10024514c:     	add	x29, sp, #0x40
100245150:     	ldp	x2, x13, [x1, #0x68]
100245154:     	cmp	x13, x2
100245158:     	b.hs	0x1002455d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x498>
10024515c:     	ldr	x15, [x1, #0x60]
100245160:     	ldrb	w8, [x15, x13]
100245164:     	cmp	w8, #0x22
100245168:     	b.ne	0x1002455d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x498>
10024516c:     	add	x8, x13, #0x1
100245170:     	str	x8, [x1, #0x70]
100245174:     	sub	x9, x2, x8
100245178:     	add	x14, x15, x8
10024517c:     	cmp	x9, #0x10
100245180:     	b.lo	0x100245290 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x158>
100245184:     	mov	x10, #0x0               ; =0
100245188:     	movi.16b	v0, #0x22
10024518c:     	movi.16b	v1, #0x5c
100245190:     	movi.16b	v2, #0x20
100245194:     	movi.16b	v3, #0xed
100245198:     	b	0x1002451ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x74>
10024519c:     	add	x10, x10, #0x10
1002451a0:     	sub	x11, x9, x10
1002451a4:     	cmp	x11, #0xf
1002451a8:     	b.ls	0x100245610 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x4d8>
1002451ac:     	ldr	q4, [x14, x10]
1002451b0:     	cmeq.16b	v5, v4, v0
1002451b4:     	cmeq.16b	v6, v4, v1
1002451b8:     	orr.16b	v5, v6, v5
1002451bc:     	cmhi.16b	v6, v2, v4
1002451c0:     	cmeq.16b	v4, v4, v3
1002451c4:     	orr.16b	v4, v4, v6
1002451c8:     	orr.16b	v4, v4, v5
1002451cc:     	addp.2d	d5, v4
1002451d0:     	fmov	x11, d5
1002451d4:     	cbz	x11, 0x10024519c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x64>
1002451d8:     	fmov	x11, d4
1002451dc:     	ands	x12, x11, #0x8080808080808080
1002451e0:     	b.ne	0x100245200 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0xc8>
1002451e4:     	mov.d	x11, v4[1]
1002451e8:     	ands	x12, x11, #0x8080808080808080
1002451ec:     	b.ne	0x10024524c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x114>
1002451f0:     	b	0x10024519c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x64>
1002451f4:     	sub	x11, x12, #0x2
1002451f8:     	ands	x12, x11, x12
1002451fc:     	b.eq	0x1002451e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0xac>
100245200:     	rbit	x11, x12
100245204:     	clz	x11, x11
100245208:     	orr	x11, x10, x11, lsr #3
10024520c:     	cmp	x11, x9
100245210:     	b.hs	0x100245664 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x52c>
100245214:     	ldrb	w16, [x14, x11]
100245218:     	cmp	w16, #0xed
10024521c:     	b.ne	0x10024558c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x454>
100245220:     	add	x16, x11, #0x1
100245224:     	cmp	x16, x9
100245228:     	b.hs	0x1002451f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0xbc>
10024522c:     	ldrb	w16, [x14, x16]
100245230:     	and	w16, w16, #0xe0
100245234:     	cmp	w16, #0xa0
100245238:     	b.ne	0x1002451f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0xbc>
10024523c:     	b	0x10024558c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x454>
100245240:     	sub	x11, x12, #0x2
100245244:     	ands	x12, x11, x12
100245248:     	b.eq	0x10024519c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x64>
10024524c:     	rbit	x11, x12
100245250:     	clz	x11, x11
100245254:     	orr	x16, x10, x11, lsr #3
100245258:     	orr	x11, x16, #0x8
10024525c:     	cmp	x11, x9
100245260:     	b.hs	0x100245664 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x52c>
100245264:     	ldrb	w17, [x14, x11]
100245268:     	cmp	w17, #0xed
10024526c:     	b.ne	0x10024558c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x454>
100245270:     	add	x16, x16, #0x9
100245274:     	cmp	x16, x9
100245278:     	b.hs	0x100245240 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x108>
10024527c:     	ldrb	w16, [x14, x16]
100245280:     	and	w16, w16, #0xe0
100245284:     	cmp	w16, #0xa0
100245288:     	b.ne	0x100245240 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x108>
10024528c:     	b	0x10024558c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x454>
100245290:     	mov	x10, #0x0               ; =0
100245294:     	mov	x23, #0x0               ; =0
100245298:     	mov	x16, #0x101010101010101 ; =72340172838076673
10024529c:     	movk	x16, #0x100
1002452a0:     	add	x11, x10, x13
1002452a4:     	add	x17, x15, x11
1002452a8:     	mvn	x12, x10
1002452ac:     	add	x12, x12, x2
1002452b0:     	sub	x3, x12, x13
1002452b4:     	sub	x11, x11, x2
1002452b8:     	add	x4, x11, #0x1
1002452bc:     	mov	x5, #-0x7f7f7f7f7f7f7f80 ; =-9187201950435737472
1002452c0:     	mov	x6, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
1002452c4:     	orr	x6, x6, #0x4444444444444444
1002452c8:     	mov	x7, #0x2020202020202020 ; =2314885530818453536
1002452cc:     	movk	x7, #0x201f
1002452d0:     	mov	x19, #-0x3333333333333334 ; =-3689348814741910324
1002452d4:     	orr	x19, x19, #0xe1e1e1e1e1e1e1e1
1002452d8:     	mov	x20, #-0x101010101010102 ; =-72340172838076674
1002452dc:     	movk	x20, #0xfeff
1002452e0:     	mov	w21, #0x20              ; =32
1002452e4:     	mov	x25, #0x0               ; =0
1002452e8:     	mov	x22, x23
1002452ec:     	sub	x12, x9, x23
1002452f0:     	add	x24, x17, x23
1002452f4:     	mov	x11, x25
1002452f8:     	add	x23, x25, #0x8
1002452fc:     	cmp	x23, x12
100245300:     	b.hi	0x1002453b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x27c>
100245304:     	add	x23, x24, x11
100245308:     	ldur	x23, [x23, #0x1]
10024530c:     	eor	x25, x23, #0x2222222222222222
100245310:     	sub	x25, x16, x25
100245314:     	orr	x25, x25, x23
100245318:     	bics	xzr, x5, x25
10024531c:     	b.ne	0x10024535c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x224>
100245320:     	eor	x25, x23, x6
100245324:     	sub	x25, x16, x25
100245328:     	orr	x25, x25, x23
10024532c:     	bics	xzr, x5, x25
100245330:     	b.ne	0x10024535c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x224>
100245334:     	sub	x25, x7, x23
100245338:     	orr	x25, x25, x23
10024533c:     	bics	xzr, x5, x25
100245340:     	b.ne	0x10024535c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x224>
100245344:     	eor	x25, x23, x19
100245348:     	add	x25, x25, x20
10024534c:     	and	x26, x23, x25
100245350:     	add	x25, x11, #0x8
100245354:     	tst	x26, #0x8080808080808080
100245358:     	b.eq	0x1002452f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x1bc>
10024535c:     	mov	x12, #0x0               ; =0
100245360:     	and	w24, w23, #0xff
100245364:     	cmp	w24, #0x22
100245368:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
10024536c:     	cmp	w24, #0x5c
100245370:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
100245374:     	mov	x12, #0x0               ; =0
100245378:     	cmp	w24, #0x20
10024537c:     	b.lo	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
100245380:     	cmp	w24, #0xed
100245384:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
100245388:     	ubfx	w24, w23, #8, #8
10024538c:     	mov	w12, #0x1               ; =1
100245390:     	cmp	w24, #0x22
100245394:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
100245398:     	cmp	w24, #0x5c
10024539c:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
1002453a0:     	cmp	w24, #0xed
1002453a4:     	ccmp	w24, w21, #0x0, ne
1002453a8:     	b.hs	0x100245474 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x33c>
1002453ac:     	mov	w12, #0x1               ; =1
1002453b0:     	b	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
1002453b4:     	cmp	x11, x12
1002453b8:     	b.hi	0x100245620 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x4e8>
1002453bc:     	sub	x12, x3, x22
1002453c0:     	cmp	x12, x11
1002453c4:     	b.eq	0x1002455d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x498>
1002453c8:     	mov	x12, #0x0               ; =0
1002453cc:     	add	x23, x17, x22
1002453d0:     	add	x23, x23, x11
1002453d4:     	add	x23, x23, #0x1
1002453d8:     	add	x24, x4, x22
1002453dc:     	add	x24, x24, x11
1002453e0:     	ldrb	w25, [x23], #0x1
1002453e4:     	cmp	w25, #0x22
1002453e8:     	b.eq	0x100245414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2dc>
1002453ec:     	cmp	w25, #0x5c
1002453f0:     	b.eq	0x100245414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2dc>
1002453f4:     	cmp	w25, #0x20
1002453f8:     	b.lo	0x100245414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2dc>
1002453fc:     	cmp	w25, #0xed
100245400:     	b.eq	0x100245414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2dc>
100245404:     	sub	x12, x12, #0x1
100245408:     	cmp	x24, x12
10024540c:     	b.ne	0x1002453e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2a8>
100245410:     	b	0x1002455d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x498>
100245414:     	neg	x12, x12
100245418:     	add	x23, x22, x11
10024541c:     	add	x23, x12, x23
100245420:     	cmp	x23, x9
100245424:     	b.hs	0x100245678 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x540>
100245428:     	add	x23, x17, x22
10024542c:     	add	x23, x23, x12
100245430:     	add	x23, x23, x11
100245434:     	ldrb	w23, [x23, #0x1]
100245438:     	cmp	w23, #0xed
10024543c:     	b.ne	0x100245580 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x448>
100245440:     	add	x23, x12, x22
100245444:     	add	x23, x23, x11
100245448:     	add	x23, x23, #0x1
10024544c:     	cmp	x23, x9
100245450:     	b.hs	0x1002452e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x1ac>
100245454:     	add	x24, x17, x22
100245458:     	add	x24, x24, x12
10024545c:     	add	x24, x24, x11
100245460:     	ldrb	w24, [x24, #0x2]
100245464:     	and	w24, w24, #0xe0
100245468:     	cmp	w24, #0xa0
10024546c:     	b.ne	0x1002452e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x1ac>
100245470:     	b	0x100245580 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x448>
100245474:     	ubfx	w24, w23, #16, #8
100245478:     	mov	w12, #0x2               ; =2
10024547c:     	cmp	w24, #0x22
100245480:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
100245484:     	cmp	w24, #0x5c
100245488:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
10024548c:     	cmp	w24, #0xed
100245490:     	ccmp	w24, w21, #0x0, ne
100245494:     	b.hs	0x1002454a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x368>
100245498:     	mov	w12, #0x2               ; =2
10024549c:     	b	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
1002454a0:     	lsr	w24, w23, #24
1002454a4:     	mov	w12, #0x3               ; =3
1002454a8:     	cmp	w24, #0x22
1002454ac:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
1002454b0:     	cmp	w24, #0x5c
1002454b4:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
1002454b8:     	cmp	w24, #0xed
1002454bc:     	ccmp	w24, w21, #0x0, ne
1002454c0:     	b.hs	0x1002454cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x394>
1002454c4:     	mov	w12, #0x3               ; =3
1002454c8:     	b	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
1002454cc:     	ubfx	x24, x23, #32, #8
1002454d0:     	mov	w12, #0x4               ; =4
1002454d4:     	cmp	w24, #0x22
1002454d8:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
1002454dc:     	cmp	w24, #0x5c
1002454e0:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
1002454e4:     	cmp	w24, #0xed
1002454e8:     	ccmp	w24, w21, #0x0, ne
1002454ec:     	b.hs	0x1002454f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3c0>
1002454f0:     	mov	w12, #0x4               ; =4
1002454f4:     	b	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
1002454f8:     	ubfx	x24, x23, #40, #8
1002454fc:     	mov	w12, #0x5               ; =5
100245500:     	cmp	w24, #0x22
100245504:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
100245508:     	cmp	w24, #0x5c
10024550c:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
100245510:     	cmp	w24, #0xed
100245514:     	ccmp	w24, w21, #0x0, ne
100245518:     	b.hs	0x100245524 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x3ec>
10024551c:     	mov	w12, #0x5               ; =5
100245520:     	b	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
100245524:     	ubfx	x24, x23, #48, #8
100245528:     	mov	w12, #0x6               ; =6
10024552c:     	cmp	w24, #0x22
100245530:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
100245534:     	cmp	w24, #0x5c
100245538:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
10024553c:     	cmp	w24, #0xed
100245540:     	ccmp	w24, w21, #0x0, ne
100245544:     	b.hs	0x100245550 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x418>
100245548:     	mov	w12, #0x6               ; =6
10024554c:     	b	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
100245550:     	lsr	x24, x23, #56
100245554:     	cmp	w24, #0x22
100245558:     	b.eq	0x100245578 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x440>
10024555c:     	mov	w12, #0x7               ; =7
100245560:     	cmp	w24, #0x5c
100245564:     	b.eq	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
100245568:     	and	x12, x23, #0xe000000000000000
10024556c:     	cmp	x24, #0xed
100245570:     	ccmp	x12, #0x0, #0x4, ne
100245574:     	b.ne	0x1002455d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x498>
100245578:     	mov	w12, #0x7               ; =7
10024557c:     	b	0x100245418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x2e0>
100245580:     	add	x9, x10, x22
100245584:     	add	x9, x9, x12
100245588:     	add	x11, x9, x11
10024558c:     	add	x9, x11, x8
100245590:     	cmp	x9, x2
100245594:     	str	x9, [x1, #0x70]
100245598:     	b.hs	0x100245690 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x558>
10024559c:     	ldrb	w10, [x15, x9]
1002455a0:     	cmp	w10, #0x22
1002455a4:     	b.ne	0x1002455c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x490>
1002455a8:     	cmp	x9, x13
1002455ac:     	b.ls	0x100245638 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x500>
1002455b0:     	add	x8, x9, #0x1
1002455b4:     	str	x8, [x1, #0x70]
1002455b8:     	mov	x8, #-0x1               ; =-1
1002455bc:     	stp	x8, x14, [x0]
1002455c0:     	str	x11, [x0, #0x10]
1002455c4:     	b	0x1002455dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x4a4>
1002455c8:     	cmp	w10, #0x20
1002455cc:     	b.hs	0x1002455f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x4bc>
1002455d0:     	strb	wzr, [x1, #0xd4]
1002455d4:     	mov	x8, #-0x2               ; =-2
1002455d8:     	str	x8, [x0]
1002455dc:     	ldp	x29, x30, [sp, #0x40]
1002455e0:     	ldp	x20, x19, [sp, #0x30]
1002455e4:     	ldp	x22, x21, [sp, #0x20]
1002455e8:     	ldp	x24, x23, [sp, #0x10]
1002455ec:     	ldp	x26, x25, [sp], #0x50
1002455f0:     	ret
1002455f4:     	mov	x2, x8
1002455f8:     	ldp	x29, x30, [sp, #0x40]
1002455fc:     	ldp	x20, x19, [sp, #0x30]
100245600:     	ldp	x22, x21, [sp, #0x20]
100245604:     	ldp	x24, x23, [sp, #0x10]
100245608:     	ldp	x26, x25, [sp], #0x50
10024560c:     	b	0x100248368 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow>
100245610:     	cmp	x9, x10
100245614:     	b.lo	0x10024564c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x514>
100245618:     	mov	x9, x11
10024561c:     	b	0x100245294 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes+0x15c>
100245620:     	adrp	x3, 0x100ef7000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100245624:     	add	x3, x3, #0xd0
100245628:     	mov	x0, x11
10024562c:     	mov	x1, x12
100245630:     	mov	x2, x12
100245634:     	bl	0x100b134cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245638:     	adrp	x3, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024563c:     	add	x3, x3, #0x650
100245640:     	mov	x0, x8
100245644:     	mov	x1, x9
100245648:     	bl	0x100b134cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
10024564c:     	adrp	x3, 0x100f1c000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots10stack_maps17LAST_REWRITE_WALK+0x6470>
100245650:     	add	x3, x3, #0x5a0
100245654:     	mov	x0, x10
100245658:     	mov	x1, x9
10024565c:     	mov	x2, x9
100245660:     	bl	0x100b134cc <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245664:     	adrp	x2, 0x100f1c000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots10stack_maps17LAST_REWRITE_WALK+0x6470>
100245668:     	add	x2, x2, #0x5b8
10024566c:     	mov	x0, x11
100245670:     	mov	x1, x9
100245674:     	bl	0x100b1330c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245678:     	add	x8, x12, x22
10024567c:     	adrp	x2, 0x100f1c000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots10stack_maps17LAST_REWRITE_WALK+0x6470>
100245680:     	add	x2, x2, #0x588
100245684:     	add	x0, x8, x11
100245688:     	mov	x1, x9
10024568c:     	bl	0x100b1330c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245690:     	adrp	x8, 0x100f05000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245694:     	add	x8, x8, #0x638
100245698:     	mov	x0, x9
10024569c:     	mov	x1, x2
1002456a0:     	mov	x2, x8
1002456a4:     	bl	0x100b1330c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
