
benchmarks/json_performance/.work/parse-regression-r35-profiles/r35-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100245ee8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow>:
100245ee8:     	sub	sp, sp, #0x90
100245eec:     	stp	x28, x27, [sp, #0x30]
100245ef0:     	stp	x26, x25, [sp, #0x40]
100245ef4:     	stp	x24, x23, [sp, #0x50]
100245ef8:     	stp	x22, x21, [sp, #0x60]
100245efc:     	stp	x20, x19, [sp, #0x70]
100245f00:     	stp	x29, x30, [sp, #0x80]
100245f04:     	add	x29, sp, #0x80
100245f08:     	ldp	x20, x22, [x1, #0x68]
100245f0c:     	subs	x23, x22, x2
100245f10:     	b.lo	0x100246b4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc64>
100245f14:     	cmp	x22, x20
100245f18:     	b.hi	0x100246b4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc64>
100245f1c:     	tbz	x23, #0x3f, 0x100245f30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x48>
100245f20:     	mov	x24, #0x0               ; =0
100245f24:     	mov	x0, x24
100245f28:     	mov	x1, x23
100245f2c:     	bl	0x100b10c40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100245f30:     	mov	x21, x1
100245f34:     	ldr	x25, [x1, #0x60]
100245f38:     	cmp	x22, x2
100245f3c:     	str	x0, [sp, #0x8]
100245f40:     	b.ne	0x100245f54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6c>
100245f44:     	mov	w8, #0x1                ; =1
100245f48:     	stp	x23, x8, [sp, #0x10]
100245f4c:     	str	xzr, [sp, #0x20]
100245f50:     	b	0x100245f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x98>
100245f54:     	mov	x19, x2
100245f58:     	mov	w24, #0x1               ; =1
100245f5c:     	mov	x0, x23
100245f60:     	mov	w1, #0x1                ; =1
100245f64:     	bl	0x100b5db48 <_mi_malloc_aligned>
100245f68:     	cbz	x0, 0x100245f24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3c>
100245f6c:     	stp	x23, x0, [sp, #0x10]
100245f70:     	add	x1, x25, x19
100245f74:     	mov	x2, x23
100245f78:     	bl	0x100b6076c <_writev+0x100b6076c>
100245f7c:     	str	x23, [sp, #0x20]
100245f80:     	adds	x8, x22, #0x40
100245f84:     	csinv	x8, x8, xzr, lo
100245f88:     	cmp	x8, x20
100245f8c:     	csel	x28, x8, x20, lo
100245f90:     	mov	w8, #0xdc00             ; =56320
100245f94:     	movk	w8, #0x370, lsl #16
100245f98:     	sub	w8, w8, #0x100, lsl #12 ; =0x100000
100245f9c:     	str	w8, [sp, #0x4]
100245fa0:     	b	0x100245fb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcc>
100245fa4:     	ldr	x8, [sp, #0x18]
100245fa8:     	strb	w19, [x8, x23]
100245fac:     	add	x8, x23, #0x1
100245fb0:     	str	x8, [sp, #0x20]
100245fb4:     	cmp	x22, x28
100245fb8:     	b.lo	0x1002465a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6bc>
100245fbc:     	sub	x8, x20, x22
100245fc0:     	cmp	x8, #0x40
100245fc4:     	b.lo	0x10024658c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6a4>
100245fc8:     	ldp	x28, x24, [sp, #0x18]
100245fcc:     	ldr	x8, [sp, #0x10]
100245fd0:     	sub	x8, x8, x24
100245fd4:     	cmp	x8, #0x3f
100245fd8:     	b.ls	0x10024658c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6a4>
100245fdc:     	cmn	x22, #0x35
100245fe0:     	b.hi	0x100246570 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x688>
100245fe4:     	mov	x26, #0x0               ; =0
100245fe8:     	add	x27, x28, x24
100245fec:     	add	x19, x22, #0x34
100245ff0:     	mov	x8, x22
100245ff4:     	add	x9, x25, x8
100245ff8:     	ldrb	w10, [x9]
100245ffc:     	add	x22, x8, #0x1
100246000:     	cmp	w10, #0x5c
100246004:     	b.eq	0x100246030 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x148>
100246008:     	cmp	w10, #0x22
10024600c:     	b.eq	0x100246afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc14>
100246010:     	cmp	w10, #0x20
100246014:     	b.lo	0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
100246018:     	strb	w10, [x27, x26]
10024601c:     	add	x26, x26, #0x1
100246020:     	mov	x8, x22
100246024:     	cmp	x22, x19
100246028:     	b.lo	0x100245ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
10024602c:     	b	0x100246574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
100246030:     	ldrb	w10, [x25, x22]
100246034:     	add	x22, x8, #0x2
100246038:     	cmp	w10, #0x65
10024603c:     	b.le	0x1002460b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x1d0>
100246040:     	cmp	w10, #0x71
100246044:     	b.le	0x100246118 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x230>
100246048:     	cmp	w10, #0x72
10024604c:     	b.eq	0x100246198 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2b0>
100246050:     	cmp	w10, #0x74
100246054:     	b.eq	0x100246144 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x25c>
100246058:     	cmp	w10, #0x75
10024605c:     	b.ne	0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
100246060:     	add	x11, x25, x22
100246064:     	ldrb	w12, [x11]
100246068:     	sub	w10, w12, #0x30
10024606c:     	cmp	w10, #0xa
100246070:     	b.lo	0x100246084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x19c>
100246074:     	sub	w10, w12, #0x61
100246078:     	cmp	w10, #0x6
10024607c:     	b.hs	0x1002461d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2e8>
100246080:     	sub	w10, w12, #0x57
100246084:     	ldrb	w13, [x11, #0x1]
100246088:     	sub	w12, w13, #0x30
10024608c:     	cmp	w12, #0xa
100246090:     	b.hs	0x1002461f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x308>
100246094:     	ldrb	w14, [x11, #0x2]
100246098:     	sub	w13, w14, #0x30
10024609c:     	cmp	w13, #0xa
1002460a0:     	b.hs	0x100246210 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x328>
1002460a4:     	ldrb	w11, [x11, #0x3]
1002460a8:     	sub	w14, w11, #0x30
1002460ac:     	cmp	w14, #0xa
1002460b0:     	b.lo	0x10024629c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3b4>
1002460b4:     	b	0x100246278 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x390>
1002460b8:     	cmp	w10, #0x5b
1002460bc:     	b.gt	0x1002460ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x204>
1002460c0:     	cmp	w10, #0x22
1002460c4:     	b.eq	0x100246160 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x278>
1002460c8:     	cmp	w10, #0x2f
1002460cc:     	b.ne	0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
1002460d0:     	mov	w8, #0x2f               ; =47
1002460d4:     	strb	w8, [x27, x26]
1002460d8:     	add	x26, x26, #0x1
1002460dc:     	mov	x8, x22
1002460e0:     	cmp	x22, x19
1002460e4:     	b.lo	0x100245ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
1002460e8:     	b	0x100246574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
1002460ec:     	cmp	w10, #0x5c
1002460f0:     	b.eq	0x10024617c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x294>
1002460f4:     	cmp	w10, #0x62
1002460f8:     	b.ne	0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
1002460fc:     	mov	w8, #0x8                ; =8
100246100:     	strb	w8, [x27, x26]
100246104:     	add	x26, x26, #0x1
100246108:     	mov	x8, x22
10024610c:     	cmp	x22, x19
100246110:     	b.lo	0x100245ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
100246114:     	b	0x100246574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
100246118:     	cmp	w10, #0x66
10024611c:     	b.eq	0x1002461b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2cc>
100246120:     	cmp	w10, #0x6e
100246124:     	b.ne	0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
100246128:     	mov	w8, #0xa                ; =10
10024612c:     	strb	w8, [x27, x26]
100246130:     	add	x26, x26, #0x1
100246134:     	mov	x8, x22
100246138:     	cmp	x22, x19
10024613c:     	b.lo	0x100245ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
100246140:     	b	0x100246574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
100246144:     	mov	w8, #0x9                ; =9
100246148:     	strb	w8, [x27, x26]
10024614c:     	add	x26, x26, #0x1
100246150:     	mov	x8, x22
100246154:     	cmp	x22, x19
100246158:     	b.lo	0x100245ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
10024615c:     	b	0x100246574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
100246160:     	mov	w8, #0x22               ; =34
100246164:     	strb	w8, [x27, x26]
100246168:     	add	x26, x26, #0x1
10024616c:     	mov	x8, x22
100246170:     	cmp	x22, x19
100246174:     	b.lo	0x100245ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
100246178:     	b	0x100246574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
10024617c:     	mov	w8, #0x5c               ; =92
100246180:     	strb	w8, [x27, x26]
100246184:     	add	x26, x26, #0x1
100246188:     	mov	x8, x22
10024618c:     	cmp	x22, x19
100246190:     	b.lo	0x100245ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
100246194:     	b	0x100246574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
100246198:     	mov	w8, #0xd                ; =13
10024619c:     	strb	w8, [x27, x26]
1002461a0:     	add	x26, x26, #0x1
1002461a4:     	mov	x8, x22
1002461a8:     	cmp	x22, x19
1002461ac:     	b.lo	0x100245ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
1002461b0:     	b	0x100246574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
1002461b4:     	mov	w8, #0xc                ; =12
1002461b8:     	strb	w8, [x27, x26]
1002461bc:     	add	x26, x26, #0x1
1002461c0:     	mov	x8, x22
1002461c4:     	cmp	x22, x19
1002461c8:     	b.lo	0x100245ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
1002461cc:     	b	0x100246574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
1002461d0:     	sub	w10, w12, #0x41
1002461d4:     	cmp	w10, #0x6
1002461d8:     	b.hs	0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
1002461dc:     	sub	w10, w12, #0x37
1002461e0:     	ldrb	w13, [x11, #0x1]
1002461e4:     	sub	w12, w13, #0x30
1002461e8:     	cmp	w12, #0xa
1002461ec:     	b.lo	0x100246094 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x1ac>
1002461f0:     	sub	w12, w13, #0x61
1002461f4:     	cmp	w12, #0x6
1002461f8:     	b.hs	0x100246234 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x34c>
1002461fc:     	sub	w12, w13, #0x57
100246200:     	ldrb	w14, [x11, #0x2]
100246204:     	sub	w13, w14, #0x30
100246208:     	cmp	w13, #0xa
10024620c:     	b.lo	0x1002460a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x1bc>
100246210:     	sub	w13, w14, #0x61
100246214:     	cmp	w13, #0x6
100246218:     	b.hs	0x100246258 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x370>
10024621c:     	sub	w13, w14, #0x57
100246220:     	ldrb	w11, [x11, #0x3]
100246224:     	sub	w14, w11, #0x30
100246228:     	cmp	w14, #0xa
10024622c:     	b.hs	0x100246278 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x390>
100246230:     	b	0x10024629c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3b4>
100246234:     	sub	w12, w13, #0x41
100246238:     	cmp	w12, #0x5
10024623c:     	b.hi	0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
100246240:     	sub	w12, w13, #0x37
100246244:     	ldrb	w14, [x11, #0x2]
100246248:     	sub	w13, w14, #0x30
10024624c:     	cmp	w13, #0xa
100246250:     	b.hs	0x100246210 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x328>
100246254:     	b	0x1002460a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x1bc>
100246258:     	sub	w13, w14, #0x41
10024625c:     	cmp	w13, #0x5
100246260:     	b.hi	0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
100246264:     	sub	w13, w14, #0x37
100246268:     	ldrb	w11, [x11, #0x3]
10024626c:     	sub	w14, w11, #0x30
100246270:     	cmp	w14, #0xa
100246274:     	b.lo	0x10024629c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3b4>
100246278:     	sub	w14, w11, #0x61
10024627c:     	cmp	w14, #0x6
100246280:     	b.hs	0x10024628c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3a4>
100246284:     	sub	w14, w11, #0x57
100246288:     	b	0x10024629c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3b4>
10024628c:     	sub	w14, w11, #0x41
100246290:     	cmp	w14, #0x5
100246294:     	b.hi	0x100246ad4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbec>
100246298:     	sub	w14, w11, #0x37
10024629c:     	add	x22, x8, #0x6
1002462a0:     	and	w10, w10, #0xff
1002462a4:     	and	w11, w12, #0xff
1002462a8:     	lsl	w11, w11, #4
1002462ac:     	orr	w11, w11, w10, lsl #8
1002462b0:     	and	w10, w13, #0xff
1002462b4:     	orr	w12, w11, w10
1002462b8:     	lsl	w13, w12, #4
1002462bc:     	and	w10, w14, #0xff
1002462c0:     	orr	w10, w13, w10
1002462c4:     	cmp	w11, #0xd80
1002462c8:     	b.hs	0x100246304 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x41c>
1002462cc:     	str	wzr, [sp, #0x2c]
1002462d0:     	and	w8, w13, #0xffff
1002462d4:     	mov	w9, #0xd800             ; =55296
1002462d8:     	movk	w9, #0xffef, lsl #16
1002462dc:     	eor	w8, w8, w9
1002462e0:     	mov	w9, #0x800              ; =2048
1002462e4:     	movk	w9, #0xffef, lsl #16
1002462e8:     	cmp	w8, w9
1002462ec:     	b.lo	0x100246b64 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc7c>
1002462f0:     	cmp	w12, #0x8
1002462f4:     	b.hs	0x10024635c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x474>
1002462f8:     	strb	w10, [sp, #0x2c]
1002462fc:     	mov	w23, #0x1               ; =1
100246300:     	b	0x100246524 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x63c>
100246304:     	cmp	w12, #0xdbf
100246308:     	b.hi	0x100246384 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x49c>
10024630c:     	cmp	x22, x20
100246310:     	b.hs	0x100246bd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcf0>
100246314:     	ldrb	w12, [x25, x22]
100246318:     	cmp	w12, #0x5c
10024631c:     	b.ne	0x1002464f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x610>
100246320:     	add	x0, x8, #0x7
100246324:     	cmp	x0, x20
100246328:     	b.hs	0x100246bec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd04>
10024632c:     	ldrb	w12, [x25, x0]
100246330:     	cmp	w12, #0x75
100246334:     	b.ne	0x1002464f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x610>
100246338:     	ldrb	w13, [x9, #0x8]
10024633c:     	sub	w12, w13, #0x30
100246340:     	cmp	w12, #0xa
100246344:     	b.lo	0x1002463c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4d8>
100246348:     	sub	w12, w13, #0x61
10024634c:     	cmp	w12, #0x6
100246350:     	b.hs	0x1002463b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4c8>
100246354:     	sub	w12, w13, #0x57
100246358:     	b	0x1002463c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4d8>
10024635c:     	mov	w8, #-0x80              ; =-128
100246360:     	bfxil	w8, w10, #0, #6
100246364:     	cmp	w11, #0x80
100246368:     	b.hs	0x100246394 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4ac>
10024636c:     	lsr	w9, w10, #6
100246370:     	orr	w9, w9, #0xc0
100246374:     	strb	w9, [sp, #0x2c]
100246378:     	strb	w8, [sp, #0x2d]
10024637c:     	mov	w23, #0x2               ; =2
100246380:     	b	0x100246524 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x63c>
100246384:     	str	wzr, [sp, #0x2c]
100246388:     	cmp	w11, #0xe00
10024638c:     	b.hs	0x1002462d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3e8>
100246390:     	b	0x1002464fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x614>
100246394:     	lsr	w9, w11, #8
100246398:     	mov	w11, #0x80              ; =128
10024639c:     	orr	w9, w9, #0xe0
1002463a0:     	strb	w9, [sp, #0x2c]
1002463a4:     	bfxil	w11, w10, #6, #6
1002463a8:     	strb	w11, [sp, #0x2d]
1002463ac:     	b	0x10024651c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x634>
1002463b0:     	sub	w12, w13, #0x41
1002463b4:     	cmp	w12, #0x6
1002463b8:     	b.hs	0x1002464f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x610>
1002463bc:     	sub	w12, w13, #0x37
1002463c0:     	ldrb	w14, [x9, #0x9]
1002463c4:     	sub	w13, w14, #0x30
1002463c8:     	cmp	w13, #0xa
1002463cc:     	b.lo	0x1002463f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x50c>
1002463d0:     	sub	w13, w14, #0x61
1002463d4:     	cmp	w13, #0x6
1002463d8:     	b.hs	0x1002463e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4fc>
1002463dc:     	sub	w13, w14, #0x57
1002463e0:     	b	0x1002463f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x50c>
1002463e4:     	sub	w13, w14, #0x41
1002463e8:     	cmp	w13, #0x5
1002463ec:     	b.hi	0x1002464f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x610>
1002463f0:     	sub	w13, w14, #0x37
1002463f4:     	ldrb	w15, [x9, #0xa]
1002463f8:     	sub	w14, w15, #0x30
1002463fc:     	cmp	w14, #0xa
100246400:     	b.lo	0x100246428 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x540>
100246404:     	sub	w14, w15, #0x61
100246408:     	cmp	w14, #0x6
10024640c:     	b.hs	0x100246418 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x530>
100246410:     	sub	w14, w15, #0x57
100246414:     	b	0x100246428 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x540>
100246418:     	sub	w14, w15, #0x41
10024641c:     	cmp	w14, #0x5
100246420:     	b.hi	0x1002464f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x610>
100246424:     	sub	w14, w15, #0x37
100246428:     	ldrb	w15, [x9, #0xb]
10024642c:     	sub	w9, w15, #0x30
100246430:     	cmp	w9, #0xa
100246434:     	b.lo	0x10024645c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x574>
100246438:     	sub	w9, w15, #0x61
10024643c:     	cmp	w9, #0x6
100246440:     	b.hs	0x10024644c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x564>
100246444:     	sub	w9, w15, #0x57
100246448:     	b	0x10024645c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x574>
10024644c:     	sub	w9, w15, #0x41
100246450:     	cmp	w9, #0x5
100246454:     	b.hi	0x1002464f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x610>
100246458:     	sub	w9, w15, #0x37
10024645c:     	and	w12, w12, #0xff
100246460:     	and	w13, w13, #0xff
100246464:     	lsl	w13, w13, #4
100246468:     	orr	w12, w13, w12, lsl #8
10024646c:     	and	w13, w14, #0xff
100246470:     	orr	w12, w12, w13
100246474:     	and	w13, w12, #0xfc0
100246478:     	str	wzr, [sp, #0x2c]
10024647c:     	cmp	w13, #0xdc0
100246480:     	b.ne	0x1002464fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x614>
100246484:     	and	w9, w9, #0xff
100246488:     	orr	w11, w9, w12, lsl #4
10024648c:     	and	w9, w10, #0xffff
100246490:     	lsl	w9, w9, #10
100246494:     	add	w12, w9, w11, uxth
100246498:     	mov	w9, #0x2400             ; =9216
10024649c:     	movk	w9, #0xfca0, lsl #16
1002464a0:     	add	w9, w12, w9
1002464a4:     	mov	w10, #0xd800            ; =55296
1002464a8:     	eor	w10, w9, w10
1002464ac:     	mov	w13, #0x800             ; =2048
1002464b0:     	movk	w13, #0xffef, lsl #16
1002464b4:     	add	w10, w10, w13
1002464b8:     	sub	w10, w10, #0x800
1002464bc:     	cmp	w10, w13
1002464c0:     	b.lo	0x100246ba0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcb8>
1002464c4:     	add	x22, x8, #0xc
1002464c8:     	mov	w8, #-0x80              ; =-128
1002464cc:     	bfxil	w8, w11, #0, #6
1002464d0:     	mov	w10, #-0x80             ; =-128
1002464d4:     	bfxil	w10, w9, #6, #6
1002464d8:     	ldr	w11, [sp, #0x4]
1002464dc:     	cmp	w12, w11
1002464e0:     	b.hs	0x100246548 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x660>
1002464e4:     	lsr	w9, w9, #12
1002464e8:     	orr	w9, w9, #0xe0
1002464ec:     	strb	w9, [sp, #0x2c]
1002464f0:     	strb	w10, [sp, #0x2d]
1002464f4:     	b	0x10024651c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x634>
1002464f8:     	str	wzr, [sp, #0x2c]
1002464fc:     	lsr	w8, w11, #8
100246500:     	orr	w8, w8, #0xe0
100246504:     	strb	w8, [sp, #0x2c]
100246508:     	mov	w8, #0x80               ; =128
10024650c:     	bfxil	w8, w10, #6, #6
100246510:     	strb	w8, [sp, #0x2d]
100246514:     	mov	w8, #0x80               ; =128
100246518:     	bfxil	w8, w10, #0, #6
10024651c:     	strb	w8, [sp, #0x2e]
100246520:     	mov	w23, #0x3               ; =3
100246524:     	add	x0, x27, x26
100246528:     	add	x1, sp, #0x2c
10024652c:     	mov	x2, x23
100246530:     	bl	0x100b6076c <_writev+0x100b6076c>
100246534:     	add	x26, x23, x26
100246538:     	mov	x8, x22
10024653c:     	cmp	x22, x19
100246540:     	b.lo	0x100245ff4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x10c>
100246544:     	b	0x100246574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68c>
100246548:     	lsr	w11, w9, #18
10024654c:     	orr	w11, w11, #0xf0
100246550:     	mov	w12, #0x80              ; =128
100246554:     	strb	w11, [sp, #0x2c]
100246558:     	bfxil	w12, w9, #12, #6
10024655c:     	strb	w12, [sp, #0x2d]
100246560:     	strb	w10, [sp, #0x2e]
100246564:     	strb	w8, [sp, #0x2f]
100246568:     	mov	w23, #0x4               ; =4
10024656c:     	b	0x100246524 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x63c>
100246570:     	mov	x26, #0x0               ; =0
100246574:     	str	x22, [x21, #0x70]
100246578:     	add	x24, x26, x24
10024657c:     	str	x24, [sp, #0x20]
100246580:     	sub	x8, x20, x22
100246584:     	cmp	x8, #0x40
100246588:     	b.hs	0x100245fcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xe4>
10024658c:     	adds	x8, x22, #0x40
100246590:     	csinv	x8, x8, xzr, lo
100246594:     	cmp	x8, x20
100246598:     	csel	x28, x8, x20, lo
10024659c:     	cmp	x22, x20
1002465a0:     	b.hs	0x100246ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
1002465a4:     	mov	x8, x22
1002465a8:     	ldrb	w19, [x25, x22]
1002465ac:     	add	x22, x22, #0x1
1002465b0:     	str	x22, [x21, #0x70]
1002465b4:     	cmp	w19, #0x5c
1002465b8:     	b.eq	0x1002465e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x700>
1002465bc:     	cmp	w19, #0x22
1002465c0:     	b.eq	0x100246b38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc50>
1002465c4:     	cmp	w19, #0x20
1002465c8:     	b.lo	0x100246ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
1002465cc:     	ldr	x23, [sp, #0x20]
1002465d0:     	ldr	x8, [sp, #0x10]
1002465d4:     	cmp	x23, x8
1002465d8:     	b.ne	0x100245fa4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbc>
1002465dc:     	add	x0, sp, #0x10
1002465e0:     	bl	0x100b10b28 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002465e4:     	b	0x100245fa4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbc>
1002465e8:     	cmp	x22, x20
1002465ec:     	b.hs	0x100246ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
1002465f0:     	ldrb	w9, [x25, x22]
1002465f4:     	add	x22, x8, #0x2
1002465f8:     	str	x22, [x21, #0x70]
1002465fc:     	cmp	w9, #0x65
100246600:     	b.le	0x100246660 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x778>
100246604:     	cmp	w9, #0x71
100246608:     	b.le	0x1002466d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x7e8>
10024660c:     	cmp	w9, #0x72
100246610:     	b.eq	0x100246770 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x888>
100246614:     	cmp	w9, #0x74
100246618:     	b.eq	0x100246704 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x81c>
10024661c:     	cmp	w9, #0x75
100246620:     	b.ne	0x100246ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100246624:     	add	x23, x8, #0x6
100246628:     	cmp	x23, x20
10024662c:     	b.hi	0x100246ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100246630:     	cmp	x23, x22
100246634:     	b.lo	0x100246b70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc88>
100246638:     	add	x10, x25, x22
10024663c:     	ldrb	w11, [x10]
100246640:     	sub	w9, w11, #0x30
100246644:     	cmp	w9, #0xa
100246648:     	b.lo	0x1002467d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8ec>
10024664c:     	sub	w9, w11, #0x61
100246650:     	cmp	w9, #0x6
100246654:     	b.hs	0x1002467c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8dc>
100246658:     	sub	w9, w11, #0x57
10024665c:     	b	0x1002467d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8ec>
100246660:     	cmp	w9, #0x5b
100246664:     	b.gt	0x10024669c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x7b4>
100246668:     	cmp	w9, #0x22
10024666c:     	b.eq	0x100246728 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x840>
100246670:     	cmp	w9, #0x2f
100246674:     	b.ne	0x100246ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100246678:     	ldr	x19, [sp, #0x20]
10024667c:     	ldr	x8, [sp, #0x10]
100246680:     	cmp	x19, x8
100246684:     	b.ne	0x100246690 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x7a8>
100246688:     	add	x0, sp, #0x10
10024668c:     	bl	0x100b10b28 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246690:     	ldr	x8, [sp, #0x18]
100246694:     	mov	w9, #0x2f               ; =47
100246698:     	b	0x1002467b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
10024669c:     	cmp	w9, #0x5c
1002466a0:     	b.eq	0x10024674c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x864>
1002466a4:     	cmp	w9, #0x62
1002466a8:     	b.ne	0x100246ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
1002466ac:     	ldr	x19, [sp, #0x20]
1002466b0:     	ldr	x8, [sp, #0x10]
1002466b4:     	cmp	x19, x8
1002466b8:     	b.ne	0x1002466c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x7dc>
1002466bc:     	add	x0, sp, #0x10
1002466c0:     	bl	0x100b10b28 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002466c4:     	ldr	x8, [sp, #0x18]
1002466c8:     	mov	w9, #0x8                ; =8
1002466cc:     	b	0x1002467b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
1002466d0:     	cmp	w9, #0x66
1002466d4:     	b.eq	0x100246794 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8ac>
1002466d8:     	cmp	w9, #0x6e
1002466dc:     	b.ne	0x100246ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
1002466e0:     	ldr	x19, [sp, #0x20]
1002466e4:     	ldr	x8, [sp, #0x10]
1002466e8:     	cmp	x19, x8
1002466ec:     	b.ne	0x1002466f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x810>
1002466f0:     	add	x0, sp, #0x10
1002466f4:     	bl	0x100b10b28 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002466f8:     	ldr	x8, [sp, #0x18]
1002466fc:     	mov	w9, #0xa                ; =10
100246700:     	b	0x1002467b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
100246704:     	ldr	x19, [sp, #0x20]
100246708:     	ldr	x8, [sp, #0x10]
10024670c:     	cmp	x19, x8
100246710:     	b.ne	0x10024671c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x834>
100246714:     	add	x0, sp, #0x10
100246718:     	bl	0x100b10b28 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
10024671c:     	ldr	x8, [sp, #0x18]
100246720:     	mov	w9, #0x9                ; =9
100246724:     	b	0x1002467b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
100246728:     	ldr	x19, [sp, #0x20]
10024672c:     	ldr	x8, [sp, #0x10]
100246730:     	cmp	x19, x8
100246734:     	b.ne	0x100246740 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x858>
100246738:     	add	x0, sp, #0x10
10024673c:     	bl	0x100b10b28 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246740:     	ldr	x8, [sp, #0x18]
100246744:     	mov	w9, #0x22               ; =34
100246748:     	b	0x1002467b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
10024674c:     	ldr	x19, [sp, #0x20]
100246750:     	ldr	x8, [sp, #0x10]
100246754:     	cmp	x19, x8
100246758:     	b.ne	0x100246764 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x87c>
10024675c:     	add	x0, sp, #0x10
100246760:     	bl	0x100b10b28 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246764:     	ldr	x8, [sp, #0x18]
100246768:     	mov	w9, #0x5c               ; =92
10024676c:     	b	0x1002467b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
100246770:     	ldr	x19, [sp, #0x20]
100246774:     	ldr	x8, [sp, #0x10]
100246778:     	cmp	x19, x8
10024677c:     	b.ne	0x100246788 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8a0>
100246780:     	add	x0, sp, #0x10
100246784:     	bl	0x100b10b28 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246788:     	ldr	x8, [sp, #0x18]
10024678c:     	mov	w9, #0xd                ; =13
100246790:     	b	0x1002467b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8cc>
100246794:     	ldr	x19, [sp, #0x20]
100246798:     	ldr	x8, [sp, #0x10]
10024679c:     	cmp	x19, x8
1002467a0:     	b.ne	0x1002467ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8c4>
1002467a4:     	add	x0, sp, #0x10
1002467a8:     	bl	0x100b10b28 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002467ac:     	ldr	x8, [sp, #0x18]
1002467b0:     	mov	w9, #0xc                ; =12
1002467b4:     	strb	w9, [x8, x19]
1002467b8:     	add	x8, x19, #0x1
1002467bc:     	str	x8, [sp, #0x20]
1002467c0:     	b	0x100245fb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcc>
1002467c4:     	sub	w9, w11, #0x41
1002467c8:     	cmp	w9, #0x6
1002467cc:     	b.hs	0x100246ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
1002467d0:     	sub	w9, w11, #0x37
1002467d4:     	ldrb	w12, [x10, #0x1]
1002467d8:     	sub	w11, w12, #0x30
1002467dc:     	cmp	w11, #0xa
1002467e0:     	b.lo	0x100246808 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x920>
1002467e4:     	sub	w11, w12, #0x61
1002467e8:     	cmp	w11, #0x6
1002467ec:     	b.hs	0x1002467f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x910>
1002467f0:     	sub	w11, w12, #0x57
1002467f4:     	b	0x100246808 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x920>
1002467f8:     	sub	w11, w12, #0x41
1002467fc:     	cmp	w11, #0x5
100246800:     	b.hi	0x100246ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100246804:     	sub	w11, w12, #0x37
100246808:     	ldrb	w13, [x10, #0x2]
10024680c:     	sub	w12, w13, #0x30
100246810:     	cmp	w12, #0xa
100246814:     	b.lo	0x10024683c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x954>
100246818:     	sub	w12, w13, #0x61
10024681c:     	cmp	w12, #0x6
100246820:     	b.hs	0x10024682c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x944>
100246824:     	sub	w12, w13, #0x57
100246828:     	b	0x10024683c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x954>
10024682c:     	sub	w12, w13, #0x41
100246830:     	cmp	w12, #0x5
100246834:     	b.hi	0x100246ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
100246838:     	sub	w12, w13, #0x37
10024683c:     	ldrb	w13, [x10, #0x3]
100246840:     	sub	w10, w13, #0x30
100246844:     	cmp	w10, #0xa
100246848:     	b.lo	0x100246870 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x988>
10024684c:     	sub	w10, w13, #0x61
100246850:     	cmp	w10, #0x6
100246854:     	b.hs	0x100246860 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x978>
100246858:     	sub	w10, w13, #0x57
10024685c:     	b	0x100246870 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x988>
100246860:     	sub	w10, w13, #0x41
100246864:     	cmp	w10, #0x5
100246868:     	b.hi	0x100246ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbf0>
10024686c:     	sub	w10, w13, #0x37
100246870:     	and	w9, w9, #0xff
100246874:     	and	w11, w11, #0xff
100246878:     	lsl	w11, w11, #4
10024687c:     	orr	w24, w11, w9, lsl #8
100246880:     	and	w9, w12, #0xff
100246884:     	orr	w26, w24, w9
100246888:     	lsl	w27, w26, #4
10024688c:     	and	w9, w10, #0xff
100246890:     	orr	w19, w27, w9
100246894:     	str	x23, [x21, #0x70]
100246898:     	cmp	w24, #0xd80
10024689c:     	b.lo	0x10024696c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa84>
1002468a0:     	cmp	w26, #0xdbf
1002468a4:     	b.hi	0x10024696c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa84>
1002468a8:     	add	x22, x8, #0xc
1002468ac:     	cmp	x22, x20
1002468b0:     	b.hi	0x10024696c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa84>
1002468b4:     	cmp	x23, x20
1002468b8:     	b.hs	0x100246bfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd14>
1002468bc:     	ldrb	w9, [x25, x23]
1002468c0:     	cmp	w9, #0x5c
1002468c4:     	b.ne	0x10024696c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa84>
1002468c8:     	add	x0, x8, #0x7
1002468cc:     	cmp	x0, x20
1002468d0:     	b.hs	0x100246c10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd28>
1002468d4:     	ldrb	w9, [x25, x0]
1002468d8:     	cmp	w9, #0x75
1002468dc:     	b.ne	0x10024696c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa84>
1002468e0:     	add	x0, x8, #0x8
1002468e4:     	cmp	x22, x0
1002468e8:     	b.lo	0x100246bac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcc4>
1002468ec:     	add	x0, x25, x0
1002468f0:     	bl	0x1004fad38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser14decode_hex_u16>
1002468f4:     	ubfx	w8, w1, #10, #6
1002468f8:     	cmp	w8, #0x37
1002468fc:     	cset	w8, eq
100246900:     	and	w8, w0, w8
100246904:     	tbz	w8, #0x0, 0x10024696c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa84>
100246908:     	str	x22, [x21, #0x70]
10024690c:     	and	w8, w19, #0xffff
100246910:     	lsl	w8, w8, #10
100246914:     	add	w8, w8, w1, uxth
100246918:     	mov	w9, #0x2400             ; =9216
10024691c:     	movk	w9, #0xfca0, lsl #16
100246920:     	add	w0, w8, w9
100246924:     	mov	w8, #0xd800             ; =55296
100246928:     	eor	w8, w0, w8
10024692c:     	mov	w9, #0x800              ; =2048
100246930:     	movk	w9, #0xffef, lsl #16
100246934:     	add	w8, w8, w9
100246938:     	sub	w8, w8, #0x800
10024693c:     	cmp	w8, w9
100246940:     	b.lo	0x100246bc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcd8>
100246944:     	str	wzr, [sp, #0x2c]
100246948:     	add	x1, sp, #0x2c
10024694c:     	bl	0x100688bd0 <__RNvNtNtCsjgY6bXVaRmE_4core4char7methods15encode_utf8_raw>
100246950:     	mov	x2, x0
100246954:     	mov	x3, x1
100246958:     	add	x0, sp, #0x10
10024695c:     	mov	x1, x2
100246960:     	mov	x2, x3
100246964:     	bl	0x100283710 <__RNvMs_NtCsctvjasLqLe9_5alloc3vecINtB4_3VechE15append_elementsCs3gRpqoBkMHm_13perry_runtime>
100246968:     	b	0x100245fb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcc>
10024696c:     	and	w8, w24, #0xf80
100246970:     	cmp	w8, #0xd80
100246974:     	b.ne	0x1002469fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb14>
100246978:     	ldr	x22, [sp, #0x20]
10024697c:     	ldr	x8, [sp, #0x10]
100246980:     	cmp	x22, x8
100246984:     	b.ne	0x100246990 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xaa8>
100246988:     	add	x0, sp, #0x10
10024698c:     	bl	0x100b10b28 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246990:     	ldr	x8, [sp, #0x18]
100246994:     	mov	w9, #0xed               ; =237
100246998:     	strb	w9, [x8, x22]
10024699c:     	add	x24, x22, #0x1
1002469a0:     	str	x24, [sp, #0x20]
1002469a4:     	ldr	x8, [sp, #0x10]
1002469a8:     	cmp	x24, x8
1002469ac:     	b.ne	0x1002469b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xad0>
1002469b0:     	add	x0, sp, #0x10
1002469b4:     	bl	0x100b10b28 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002469b8:     	mov	w8, #-0x80              ; =-128
1002469bc:     	bfxil	w8, w19, #6, #6
1002469c0:     	ldr	x9, [sp, #0x18]
1002469c4:     	strb	w8, [x9, x24]
1002469c8:     	add	x24, x22, #0x2
1002469cc:     	str	x24, [sp, #0x20]
1002469d0:     	ldr	x8, [sp, #0x10]
1002469d4:     	cmp	x24, x8
1002469d8:     	b.ne	0x1002469e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xafc>
1002469dc:     	add	x0, sp, #0x10
1002469e0:     	bl	0x100b10b28 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002469e4:     	mov	w8, #-0x80              ; =-128
1002469e8:     	bfxil	w8, w19, #0, #6
1002469ec:     	ldr	x9, [sp, #0x18]
1002469f0:     	strb	w8, [x9, x24]
1002469f4:     	add	x8, x22, #0x3
1002469f8:     	b	0x100246aa8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbc0>
1002469fc:     	and	w8, w27, #0xffff
100246a00:     	mov	w9, #0xd800             ; =55296
100246a04:     	movk	w9, #0xffef, lsl #16
100246a08:     	eor	w8, w8, w9
100246a0c:     	mov	w9, #0x800              ; =2048
100246a10:     	movk	w9, #0xffef, lsl #16
100246a14:     	cmp	w8, w9
100246a18:     	b.lo	0x100246b88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xca0>
100246a1c:     	str	wzr, [sp, #0x2c]
100246a20:     	cmp	w26, #0x8
100246a24:     	b.hs	0x100246a34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb4c>
100246a28:     	strb	w19, [sp, #0x2c]
100246a2c:     	mov	w22, #0x1               ; =1
100246a30:     	b	0x100246a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb94>
100246a34:     	mov	w8, #-0x80              ; =-128
100246a38:     	bfxil	w8, w19, #0, #6
100246a3c:     	cmp	w24, #0x80
100246a40:     	b.hs	0x100246a5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb74>
100246a44:     	lsr	w9, w19, #6
100246a48:     	orr	w9, w9, #0xc0
100246a4c:     	strb	w9, [sp, #0x2c]
100246a50:     	strb	w8, [sp, #0x2d]
100246a54:     	mov	w22, #0x2               ; =2
100246a58:     	b	0x100246a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb94>
100246a5c:     	lsr	w9, w24, #8
100246a60:     	mov	w10, #0x80              ; =128
100246a64:     	orr	w9, w9, #0xe0
100246a68:     	strb	w9, [sp, #0x2c]
100246a6c:     	bfxil	w10, w19, #6, #6
100246a70:     	strb	w10, [sp, #0x2d]
100246a74:     	strb	w8, [sp, #0x2e]
100246a78:     	mov	w22, #0x3               ; =3
100246a7c:     	ldr	x24, [sp, #0x20]
100246a80:     	ldr	x8, [sp, #0x10]
100246a84:     	sub	x8, x8, x24
100246a88:     	cmp	x22, x8
100246a8c:     	b.hi	0x100246ab4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbcc>
100246a90:     	ldr	x8, [sp, #0x18]
100246a94:     	add	x0, x8, x24
100246a98:     	add	x1, sp, #0x2c
100246a9c:     	mov	x2, x22
100246aa0:     	bl	0x100b6076c <_writev+0x100b6076c>
100246aa4:     	add	x8, x24, x22
100246aa8:     	str	x8, [sp, #0x20]
100246aac:     	mov	x22, x23
100246ab0:     	b	0x100245fb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcc>
100246ab4:     	add	x0, sp, #0x10
100246ab8:     	mov	x1, x24
100246abc:     	mov	x2, x22
100246ac0:     	mov	w3, #0x1                ; =1
100246ac4:     	mov	w4, #0x1                ; =1
100246ac8:     	bl	0x100b37d50 <__RINvNvMs2_NtCsctvjasLqLe9_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs3gRpqoBkMHm_13perry_runtime>
100246acc:     	ldr	x24, [sp, #0x20]
100246ad0:     	b	0x100246a90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xba8>
100246ad4:     	str	x22, [x21, #0x70]
100246ad8:     	strb	wzr, [x21, #0xd4]
100246adc:     	mov	x8, #-0x2               ; =-2
100246ae0:     	ldr	x9, [sp, #0x8]
100246ae4:     	str	x8, [x9]
100246ae8:     	ldr	x8, [sp, #0x10]
100246aec:     	cbz	x8, 0x100246b18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc30>
100246af0:     	ldr	x0, [sp, #0x18]
100246af4:     	bl	0x100b5d8c0 <_mi_free>
100246af8:     	b	0x100246b18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc30>
100246afc:     	str	x22, [x21, #0x70]
100246b00:     	add	x8, x26, x24
100246b04:     	str	x8, [sp, #0x20]
100246b08:     	ldr	q0, [sp, #0x10]
100246b0c:     	ldr	x9, [sp, #0x8]
100246b10:     	str	q0, [x9]
100246b14:     	str	x8, [x9, #0x10]
100246b18:     	ldp	x29, x30, [sp, #0x80]
100246b1c:     	ldp	x20, x19, [sp, #0x70]
100246b20:     	ldp	x22, x21, [sp, #0x60]
100246b24:     	ldp	x24, x23, [sp, #0x50]
100246b28:     	ldp	x26, x25, [sp, #0x40]
100246b2c:     	ldp	x28, x27, [sp, #0x30]
100246b30:     	add	sp, sp, #0x90
100246b34:     	ret
100246b38:     	ldr	q0, [sp, #0x10]
100246b3c:     	ldr	x9, [sp, #0x8]
100246b40:     	str	q0, [x9]
100246b44:     	ldr	x8, [sp, #0x20]
100246b48:     	b	0x100246b14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc2c>
100246b4c:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246b50:     	add	x3, x3, #0x7a0
100246b54:     	mov	x0, x2
100246b58:     	mov	x1, x22
100246b5c:     	mov	x2, x20
100246b60:     	bl	0x100b1130c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100246b64:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246b68:     	add	x0, x0, #0x348
100246b6c:     	bl	0x100b110b0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100246b70:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246b74:     	add	x3, x3, #0x788
100246b78:     	mov	x0, x22
100246b7c:     	mov	x1, x23
100246b80:     	mov	x2, x20
100246b84:     	bl	0x100b1130c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100246b88:     	adrp	x0, 0x100c73000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x65dc>
100246b8c:     	add	x0, x0, #0xe95
100246b90:     	adrp	x2, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100246b94:     	add	x2, x2, #0x258
100246b98:     	mov	w1, #0x2d               ; =45
100246b9c:     	bl	0x100b11080 <__RNvNtCsjgY6bXVaRmE_4core6option13expect_failed>
100246ba0:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246ba4:     	add	x0, x0, #0x330
100246ba8:     	bl	0x100b110b0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100246bac:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246bb0:     	add	x3, x3, #0x770
100246bb4:     	mov	x1, x22
100246bb8:     	mov	x2, x20
100246bbc:     	bl	0x100b1130c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100246bc0:     	adrp	x0, 0x100c44000 <_PERRY_EMPTY_STRING+0x4174>
100246bc4:     	add	x0, x0, #0xdb8
100246bc8:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246bcc:     	add	x2, x2, #0x758
100246bd0:     	mov	w1, #0x22               ; =34
100246bd4:     	bl	0x100b11080 <__RNvNtCsjgY6bXVaRmE_4core6option13expect_failed>
100246bd8:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246bdc:     	add	x2, x2, #0x300
100246be0:     	mov	x0, x22
100246be4:     	mov	x1, x20
100246be8:     	bl	0x100b1114c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100246bec:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246bf0:     	add	x2, x2, #0x318
100246bf4:     	mov	x1, x20
100246bf8:     	bl	0x100b1114c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100246bfc:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246c00:     	add	x2, x2, #0x728
100246c04:     	mov	x0, x23
100246c08:     	mov	x1, x20
100246c0c:     	bl	0x100b1114c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100246c10:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246c14:     	add	x2, x2, #0x740
100246c18:     	mov	x1, x20
100246c1c:     	bl	0x100b1114c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
