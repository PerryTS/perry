
benchmarks/json_performance/.work/parse-regression-r35-profiles/r35-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100243d34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped>:
100243d34:     	stp	d15, d14, [sp, #-0xa0]!
100243d38:     	stp	d13, d12, [sp, #0x10]
100243d3c:     	stp	d11, d10, [sp, #0x20]
100243d40:     	stp	d9, d8, [sp, #0x30]
100243d44:     	stp	x28, x27, [sp, #0x40]
100243d48:     	stp	x26, x25, [sp, #0x50]
100243d4c:     	stp	x24, x23, [sp, #0x60]
100243d50:     	stp	x22, x21, [sp, #0x70]
100243d54:     	stp	x20, x19, [sp, #0x80]
100243d58:     	stp	x29, x30, [sp, #0x90]
100243d5c:     	add	x29, sp, #0x90
100243d60:     	sub	sp, sp, #0x2e0
100243d64:     	mov	x19, x0
100243d68:     	ldp	x8, x9, [x0, #0x68]
100243d6c:     	add	x9, x9, #0x1
100243d70:     	str	x9, [x0, #0x70]
100243d74:     	cmp	x9, x8
100243d78:     	b.hs	0x100243dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x78>
100243d7c:     	ldr	x10, [x19, #0x60]
100243d80:     	mov	x11, #0x2600            ; =9728
100243d84:     	movk	x11, #0x1, lsl #32
100243d88:     	ldrb	w12, [x10, x9]
100243d8c:     	cmp	w12, #0x20
100243d90:     	b.hi	0x100243dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x78>
100243d94:     	lsr	x12, x11, x12
100243d98:     	tbz	w12, #0x0, 0x100243dac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x78>
100243d9c:     	add	x9, x9, #0x1
100243da0:     	str	x9, [x19, #0x70]
100243da4:     	cmp	x8, x9
100243da8:     	b.ne	0x100243d88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x54>
100243dac:     	ldrb	w8, [x19, #0xd5]
100243db0:     	tbz	w8, #0x0, 0x100243ddc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa8>
100243db4:     	strb	wzr, [x19, #0xd5]
100243db8:     	ldr	x28, [x19, #0x78]
100243dbc:     	ldp	q0, q1, [x19, #0x80]
100243dc0:     	stur	q0, [sp, #0xa8]
100243dc4:     	stur	q1, [sp, #0xb8]
100243dc8:     	ldp	q0, q1, [x19, #0xa0]
100243dcc:     	stur	q0, [sp, #0xc8]
100243dd0:     	stur	q1, [sp, #0xd8]
100243dd4:     	ldr	x21, [x19, #0xc0]
100243dd8:     	b	0x100243e0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd8>
100243ddc:     	str	wzr, [sp, #0x9c]
100243de0:     	mov	x8, #0x0                ; =0
100243de4:     	ldr	x28, [x19, #0x78]
100243de8:     	cbz	x28, 0x1002459b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c7c>
100243dec:     	ldr	x21, [x19, #0xc0]
100243df0:     	cbz	x21, 0x100243e28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf4>
100243df4:     	ldp	q0, q1, [x19, #0x80]
100243df8:     	stur	q0, [sp, #0xa8]
100243dfc:     	stur	q1, [sp, #0xb8]
100243e00:     	ldp	q0, q1, [x19, #0xa0]
100243e04:     	stur	q0, [sp, #0xc8]
100243e08:     	stur	q1, [sp, #0xd8]
100243e0c:     	ldr	w8, [x19, #0xd0]
100243e10:     	stp	x28, x21, [sp, #0xe8]
100243e14:     	str	w8, [sp, #0x64]
100243e18:     	str	w8, [sp, #0xf8]
100243e1c:     	mov	w8, #0x1                ; =1
100243e20:     	mov	w9, #0x1                ; =1
100243e24:     	str	w9, [sp, #0x9c]
100243e28:     	str	x8, [sp, #0xa0]
100243e2c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100243e30:     	add	x0, x0, #0xce8
100243e34:     	ldr	x8, [x0]
100243e38:     	blr	x8
100243e3c:     	mov	x20, x0
100243e40:     	ldrb	w8, [x0, #0x20]
100243e44:     	cbnz	w8, 0x100245c6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1f38>
100243e48:     	ldr	x8, [x20]
100243e4c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100243e50:     	cmp	x8, x9
100243e54:     	b.hs	0x100245c98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1f64>
100243e58:     	ldr	x27, [x20, #0x18]
100243e5c:     	ldp	x23, x24, [x19, #0x68]
100243e60:     	cmp	x24, x23
100243e64:     	b.hs	0x100243e98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x164>
100243e68:     	ldr	x8, [x19, #0x60]
100243e6c:     	ldrb	w8, [x8, x24]
100243e70:     	cmp	w8, #0x7d
100243e74:     	b.ne	0x100243e98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x164>
100243e78:     	add	x8, x24, #0x1
100243e7c:     	str	x8, [x19, #0x70]
100243e80:     	ldr	x8, [x19, #0x78]
100243e84:     	cbnz	x8, 0x1002459b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c80>
100243e88:     	ldr	x1, [x19, #0xc0]
100243e8c:     	cbz	x1, 0x1002459b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c80>
100243e90:     	ldr	w2, [x19, #0xd0]
100243e94:     	b	0x1002459d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ca0>
100243e98:     	str	x27, [sp, #0x88]
100243e9c:     	movi.2d	v0, #0000000000000000
100243ea0:     	stp	q0, q0, [sp, #0x120]
100243ea4:     	stp	q0, q0, [sp, #0x100]
100243ea8:     	adrp	x1, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x7530>
100243eac:     	add	x1, x1, #0x5b0
100243eb0:     	add	x0, sp, #0x148
100243eb4:     	mov	w2, #0x40               ; =64
100243eb8:     	bl	0x100b60790 <_writev+0x100b60790>
100243ebc:     	mov	x14, #0x0               ; =0
100243ec0:     	mov	x22, #0x0               ; =0
100243ec4:     	mov	x8, #-0x1               ; =-1
100243ec8:     	str	x8, [sp, #0x188]
100243ecc:     	add	x8, sp, #0xa0
100243ed0:     	add	x8, x8, #0x8
100243ed4:     	stp	x8, xzr, [sp, #0x68]
100243ed8:     	adrp	x8, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5530>
100243edc:     	ldr	q0, [x8, #0x360]
100243ee0:     	str	q0, [sp, #0x40]
100243ee4:     	adrp	x8, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5530>
100243ee8:     	ldr	q0, [x8, #0x370]
100243eec:     	str	q0, [sp, #0x30]
100243ef0:     	mov	x25, #0x2600            ; =9728
100243ef4:     	movk	x25, #0x1, lsl #32
100243ef8:     	adrp	x8, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5530>
100243efc:     	ldr	q0, [x8, #0x350]
100243f00:     	str	q0, [sp, #0x50]
100243f04:     	movi.8b	v8, #0xf0
100243f08:     	movi.8b	v9, #0xc0
100243f0c:     	mvni.4h	v10, #0x40
100243f10:     	movi.4h	v11, #0xef
100243f14:     	ldr	w8, [sp, #0x9c]
100243f18:     	mov	x27, x8
100243f1c:     	str	w8, [sp, #0x80]
100243f20:     	str	x28, [sp, #0x90]
100243f24:     	cmp	x24, x23
100243f28:     	b.hs	0x100243f58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x224>
100243f2c:     	ldr	x8, [x19, #0x60]
100243f30:     	ldrb	w9, [x8, x24]
100243f34:     	cmp	w9, #0x20
100243f38:     	b.hi	0x100243f58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x224>
100243f3c:     	lsr	x9, x25, x9
100243f40:     	tbz	w9, #0x0, 0x100243f58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x224>
100243f44:     	add	x24, x24, #0x1
100243f48:     	str	x24, [x19, #0x70]
100243f4c:     	cmp	x23, x24
100243f50:     	b.ne	0x100243f30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1fc>
100243f54:     	mov	x24, x23
100243f58:     	ldr	w8, [sp, #0x9c]
100243f5c:     	str	w27, [sp, #0x78]
100243f60:     	cbz	w8, 0x10024401c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100243f64:     	cmp	x14, x28
100243f68:     	cset	w8, lo
100243f6c:     	tst	w27, w8
100243f70:     	b.eq	0x10024401c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100243f74:     	cmp	x14, #0x8
100243f78:     	b.hs	0x100245d44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2010>
100243f7c:     	cmp	x24, x23
100243f80:     	b.hs	0x10024401c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100243f84:     	ldr	x8, [sp, #0x68]
100243f88:     	ldr	x9, [x8, x14, lsl #3]
100243f8c:     	cbz	x9, 0x10024401c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100243f90:     	ldr	x10, [x19, #0x60]
100243f94:     	ldrb	w8, [x10, x24]
100243f98:     	cmp	w8, #0x22
100243f9c:     	b.ne	0x10024401c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100243fa0:     	add	x11, x24, #0x1
100243fa4:     	ldr	w15, [x9, #0x4]
100243fa8:     	add	x8, x11, x15
100243fac:     	cmp	x8, x23
100243fb0:     	ccmp	x8, x24, #0x0, lo
100243fb4:     	b.ls	0x10024401c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100243fb8:     	ldrb	w12, [x10, x8]
100243fbc:     	cmp	w12, #0x22
100243fc0:     	b.ne	0x10024401c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100243fc4:     	add	x24, x10, x11
100243fc8:     	cbz	w15, 0x100244004 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2d0>
100243fcc:     	add	x9, x9, #0x14
100243fd0:     	mov	x10, x15
100243fd4:     	mov	x11, x24
100243fd8:     	ldrb	w12, [x11], #0x1
100243fdc:     	cmp	w12, #0x5c
100243fe0:     	b.eq	0x10024401c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100243fe4:     	cmp	w12, #0x22
100243fe8:     	b.eq	0x10024401c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100243fec:     	ldrb	w13, [x9], #0x1
100243ff0:     	cmp	w12, #0x20
100243ff4:     	ccmp	w12, w13, #0x0, hs
100243ff8:     	b.ne	0x10024401c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100243ffc:     	subs	x10, x10, #0x1
100244000:     	b.ne	0x100243fd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2a4>
100244004:     	mov	x27, x14
100244008:     	add	x8, x8, #0x1
10024400c:     	str	x8, [x19, #0x70]
100244010:     	mov	w23, #0x1               ; =1
100244014:     	mov	x28, #-0x1              ; =-1
100244018:     	b	0x100244040 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x30c>
10024401c:     	mov	x27, x14
100244020:     	sub	x0, x29, #0x100
100244024:     	mov	x1, x19
100244028:     	bl	0x100242cb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
10024402c:     	ldur	x28, [x29, #-0x100]
100244030:     	cmn	x28, #0x2
100244034:     	b.eq	0x1002457f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ac4>
100244038:     	mov	w23, #0x0               ; =0
10024403c:     	ldp	x24, x15, [x29, #-0xf8]
100244040:     	ldp	x9, x8, [x19, #0x68]
100244044:     	cmp	x8, x9
100244048:     	b.hs	0x1002457e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ab0>
10024404c:     	ldr	x10, [x19, #0x60]
100244050:     	ldrb	w11, [x10, x8]
100244054:     	cmp	w11, #0x3a
100244058:     	b.hi	0x1002457e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ab0>
10024405c:     	lsr	x12, x25, x11
100244060:     	tbz	w12, #0x0, 0x100244078 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x344>
100244064:     	add	x8, x8, #0x1
100244068:     	str	x8, [x19, #0x70]
10024406c:     	cmp	x9, x8
100244070:     	b.ne	0x100244050 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x31c>
100244074:     	b	0x1002457e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ab0>
100244078:     	cmp	x11, #0x3a
10024407c:     	b.ne	0x1002457e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ab0>
100244080:     	str	x15, [sp, #0x28]
100244084:     	add	x8, x8, #0x1
100244088:     	str	x8, [x19, #0x70]
10024408c:     	mov	x0, x19
100244090:     	bl	0x100241c08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
100244094:     	str	x0, [sp, #0x10]
100244098:     	ldrb	w8, [x19, #0xd4]
10024409c:     	tbz	w8, #0x0, 0x1002457e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ab4>
1002440a0:     	ldr	x8, [sp, #0x188]
1002440a4:     	cmn	x8, #0x1
1002440a8:     	str	x24, [sp, #0x18]
1002440ac:     	b.eq	0x100244170 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x43c>
1002440b0:     	ldr	x8, [sp, #0x1b8]
1002440b4:     	ldr	x1, [sp, #0x198]
1002440b8:     	cmn	x8, #0x1
1002440bc:     	ldr	x2, [sp, #0x28]
1002440c0:     	str	x22, [sp]
1002440c4:     	b.eq	0x1002441b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x484>
1002440c8:     	mov	x26, #0x7f2d            ; =32557
1002440cc:     	movk	x26, #0x4c95, lsl #16
1002440d0:     	movk	x26, #0xf42d, lsl #32
1002440d4:     	movk	x26, #0x5851, lsl #48
1002440d8:     	ldp	x8, x11, [sp, #0x1f0]
1002440dc:     	ldr	x10, [sp, #0x200]
1002440e0:     	ldr	x9, [sp, #0x208]
1002440e4:     	eor	x11, x11, x2
1002440e8:     	mul	x12, x11, x26
1002440ec:     	umulh	x11, x11, x26
1002440f0:     	eor	x11, x11, x12
1002440f4:     	add	x11, x2, x11
1002440f8:     	mul	x11, x11, x26
1002440fc:     	cmp	x2, #0x8
100244100:     	b.ls	0x1002443e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6b4>
100244104:     	cmp	x2, #0x10
100244108:     	b.ls	0x1002444d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7a0>
10024410c:     	add	x12, x24, x2
100244110:     	ldp	x12, x13, [x12, #-0x10]
100244114:     	eor	x12, x10, x12
100244118:     	eor	x13, x13, x9
10024411c:     	mul	x14, x13, x12
100244120:     	umulh	x12, x13, x12
100244124:     	eor	x12, x12, x14
100244128:     	add	x11, x11, x8
10024412c:     	eor	x11, x11, x12
100244130:     	ror	x11, x11, #0x29
100244134:     	mov	x13, x24
100244138:     	mov	x12, x2
10024413c:     	ldp	x15, x14, [x13], #0x10
100244140:     	sub	x12, x12, #0x10
100244144:     	eor	x15, x10, x15
100244148:     	eor	x14, x14, x9
10024414c:     	mul	x16, x14, x15
100244150:     	umulh	x14, x14, x15
100244154:     	eor	x14, x14, x16
100244158:     	add	x11, x11, x8
10024415c:     	eor	x11, x11, x14
100244160:     	ror	x11, x11, #0x29
100244164:     	cmp	x12, #0x10
100244168:     	b.hi	0x10024413c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x408>
10024416c:     	b	0x100244528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7f4>
100244170:     	ldr	w8, [sp, #0x80]
100244174:     	ldr	x1, [sp, #0x28]
100244178:     	tbz	w8, #0x0, 0x100244408 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6d4>
10024417c:     	ldr	w8, [sp, #0x9c]
100244180:     	tbz	w8, #0x0, 0x100245d38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2004>
100244184:     	mov	x14, x27
100244188:     	ldr	x8, [sp, #0x90]
10024418c:     	cmp	x27, x8
100244190:     	ldr	w27, [sp, #0x78]
100244194:     	b.hs	0x1002448f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbc0>
100244198:     	tbz	w23, #0x0, 0x1002448b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb84>
10024419c:     	cmp	x14, #0x7
1002441a0:     	b.hi	0x100245da4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2070>
1002441a4:     	ldr	x8, [sp, #0x68]
1002441a8:     	ldr	x10, [x8, x14, lsl #3]
1002441ac:     	add	x14, x14, #0x1
1002441b0:     	mov	w8, #0x1                ; =1
1002441b4:     	b	0x100244910 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbdc>
1002441b8:     	ldr	x23, [sp, #0x190]
1002441bc:     	cmp	x1, #0x80
1002441c0:     	mov	x26, #0x7f2d            ; =32557
1002441c4:     	movk	x26, #0x4c95, lsl #16
1002441c8:     	movk	x26, #0xf42d, lsl #32
1002441cc:     	movk	x26, #0x5851, lsl #48
1002441d0:     	b.ne	0x100244424 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6f0>
1002441d4:     	mov	w8, #0x1                ; =1
1002441d8:     	strb	w8, [x19, #0xd6]
1002441dc:     	adrp	x8, 0x10104d000 <_out_buf+0x3a48>
1002441e0:     	add	x8, x8, #0x780
1002441e4:     	ldapr	x8, [x8]
1002441e8:     	cbz	x8, 0x100245798 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a64>
1002441ec:     	ldp	x0, x22, [x8]
1002441f0:     	adrp	x8, 0x10104d000 <_out_buf+0x3a48>
1002441f4:     	add	x8, x8, #0x788
1002441f8:     	ldapr	x24, [x8]
1002441fc:     	cbz	x24, 0x1002457b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a84>
100244200:     	ldr	x8, [x22, #0x18]
100244204:     	blr	x8
100244208:     	mov	x2, x0
10024420c:     	sub	x8, x29, #0x100
100244210:     	add	x8, x8, #0x38
100244214:     	add	x1, x24, #0x20
100244218:     	mov	x0, x24
10024421c:     	bl	0x100006d70 <__RNvMs1_NtCs3SoQS4yp3pP_5ahash12random_stateNtB5_11RandomState9from_keys>
100244220:     	mov	w0, #0x1108             ; =4360
100244224:     	mov	w1, #0x8                ; =8
100244228:     	bl	0x100b5db48 <_mi_malloc_aligned>
10024422c:     	cbz	x0, 0x100245d78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2044>
100244230:     	mov	x24, #0x0               ; =0
100244234:     	mov	x2, #0x0                ; =0
100244238:     	movi.2d	v0, #0xffffffffffffffff
10024423c:     	str	q0, [x0, #0x10f0]
100244240:     	str	q0, [x0, #0x10e0]
100244244:     	str	q0, [x0, #0x10d0]
100244248:     	str	q0, [x0, #0x10c0]
10024424c:     	str	q0, [x0, #0x10b0]
100244250:     	str	q0, [x0, #0x10a0]
100244254:     	str	q0, [x0, #0x1090]
100244258:     	str	q0, [x0, #0x1080]
10024425c:     	str	q0, [x0, #0x1070]
100244260:     	str	q0, [x0, #0x1060]
100244264:     	str	q0, [x0, #0x1050]
100244268:     	str	q0, [x0, #0x1040]
10024426c:     	str	q0, [x0, #0x1030]
100244270:     	str	q0, [x0, #0x1020]
100244274:     	str	q0, [x0, #0x1010]
100244278:     	str	q0, [x0, #0x1000]
10024427c:     	str	d0, [x0, #0x1100]
100244280:     	add	x8, x0, #0x1, lsl #12   ; =0x1000
100244284:     	stur	xzr, [x29, #-0xd0]
100244288:     	ldr	q0, [sp, #0x50]
10024428c:     	stur	q0, [x29, #-0xe0]
100244290:     	mov	w9, #0x8                ; =8
100244294:     	stp	xzr, x9, [x29, #-0x100]
100244298:     	stp	xzr, x8, [x29, #-0xf0]
10024429c:     	b	0x1002442f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x5c4>
1002442a0:     	ldr	w11, [x11]
1002442a4:     	ldur	w12, [x14, #-0x4]
1002442a8:     	eor	x10, x11, x10
1002442ac:     	eor	x9, x12, x9
1002442b0:     	mul	x11, x9, x10
1002442b4:     	umulh	x9, x9, x10
1002442b8:     	eor	x9, x9, x11
1002442bc:     	add	x10, x13, x8
1002442c0:     	eor	x9, x10, x9
1002442c4:     	ror	x13, x9, #0x29
1002442c8:     	add	x24, x24, #0x8
1002442cc:     	add	x22, x2, #0x1
1002442d0:     	mul	x9, x13, x8
1002442d4:     	umulh	x8, x13, x8
1002442d8:     	eor	x8, x8, x9
1002442dc:     	neg	w9, w13
1002442e0:     	ror	x1, x8, x9
1002442e4:     	sub	x0, x29, #0x100
1002442e8:     	bl	0x10028734c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
1002442ec:     	mov	x2, x22
1002442f0:     	cmp	x24, #0x400
1002442f4:     	b.eq	0x10024442c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6f8>
1002442f8:     	ldr	x8, [x23, x24]
1002442fc:     	add	x11, x8, #0x14
100244300:     	ldr	w12, [x8, #0x4]
100244304:     	ldp	x8, x13, [x29, #-0xc8]
100244308:     	ldp	x10, x9, [x29, #-0xb8]
10024430c:     	eor	x13, x13, x12
100244310:     	mul	x14, x13, x26
100244314:     	umulh	x13, x13, x26
100244318:     	eor	x13, x13, x14
10024431c:     	add	x13, x13, x12
100244320:     	mul	x13, x13, x26
100244324:     	cmp	w12, #0x8
100244328:     	b.ls	0x100244390 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x65c>
10024432c:     	cmp	w12, #0x10
100244330:     	b.ls	0x1002443b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x67c>
100244334:     	add	x14, x11, x12
100244338:     	ldp	x14, x15, [x14, #-0x10]
10024433c:     	eor	x14, x10, x14
100244340:     	eor	x15, x15, x9
100244344:     	mul	x16, x15, x14
100244348:     	umulh	x14, x15, x14
10024434c:     	eor	x14, x14, x16
100244350:     	add	x13, x13, x8
100244354:     	eor	x13, x13, x14
100244358:     	ror	x13, x13, #0x29
10024435c:     	ldp	x15, x14, [x11], #0x10
100244360:     	sub	x12, x12, #0x10
100244364:     	eor	x15, x10, x15
100244368:     	eor	x14, x14, x9
10024436c:     	mul	x16, x14, x15
100244370:     	umulh	x14, x14, x15
100244374:     	eor	x14, x14, x16
100244378:     	add	x13, x13, x8
10024437c:     	eor	x13, x13, x14
100244380:     	ror	x13, x13, #0x29
100244384:     	cmp	x12, #0x10
100244388:     	b.hi	0x10024435c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x628>
10024438c:     	b	0x1002442c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x594>
100244390:     	cmp	w12, #0x1
100244394:     	b.ls	0x1002443c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x694>
100244398:     	add	x14, x11, x12
10024439c:     	cmp	w12, #0x3
1002443a0:     	b.hi	0x1002442a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x56c>
1002443a4:     	ldrh	w11, [x11]
1002443a8:     	ldurb	w12, [x14, #-0x1]
1002443ac:     	b	0x1002442a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x574>
1002443b0:     	ldr	x14, [x11]
1002443b4:     	add	x11, x11, x12
1002443b8:     	ldur	x11, [x11, #-0x8]
1002443bc:     	eor	x10, x14, x10
1002443c0:     	eor	x9, x11, x9
1002443c4:     	b	0x1002442b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x57c>
1002443c8:     	cmp	w12, #0x1
1002443cc:     	b.ne	0x1002443dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6a8>
1002443d0:     	ldrb	w11, [x11]
1002443d4:     	mov	x12, x11
1002443d8:     	b	0x1002442a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x574>
1002443dc:     	mov	x11, #0x0               ; =0
1002443e0:     	mov	x12, #0x0               ; =0
1002443e4:     	b	0x1002442a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x574>
1002443e8:     	cmp	x2, #0x1
1002443ec:     	b.ls	0x1002444e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
1002443f0:     	add	x13, x24, x2
1002443f4:     	cmp	x2, #0x3
1002443f8:     	b.ls	0x1002444f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7c0>
1002443fc:     	ldr	w12, [x24]
100244400:     	ldur	w13, [x13, #-0x4]
100244404:     	b	0x100244508 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7d4>
100244408:     	mov	x0, x24
10024440c:     	bl	0x10032687c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100244410:     	mov	x10, x0
100244414:     	mov	w8, #0x0                ; =0
100244418:     	mov	x14, x27
10024441c:     	ldr	w27, [sp, #0x78]
100244420:     	b	0x100244910 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbdc>
100244424:     	str	x1, [sp, #0x20]
100244428:     	b	0x100244cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfa0>
10024442c:     	ldur	q2, [x29, #-0xc0]
100244430:     	ldur	x8, [x29, #-0xb0]
100244434:     	str	x8, [sp, #0x260]
100244438:     	ldp	q0, q1, [x29, #-0x100]
10024443c:     	stp	q0, q1, [sp, #0x210]
100244440:     	ldp	q0, q1, [x29, #-0xe0]
100244444:     	str	q0, [sp, #0x230]
100244448:     	stp	q1, q2, [sp, #0x240]
10024444c:     	ldr	x22, [sp, #0x1b8]
100244450:     	cmn	x22, #0x1
100244454:     	ldr	x24, [sp, #0x18]
100244458:     	ldr	x2, [sp, #0x28]
10024445c:     	b.eq	0x10024449c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x768>
100244460:     	ldr	x9, [sp, #0x1d8]
100244464:     	cbz	x9, 0x10024448c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x758>
100244468:     	lsl	x8, x9, #4
10024446c:     	add	x9, x8, x9
100244470:     	cmn	x9, #0x19
100244474:     	b.eq	0x10024448c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x758>
100244478:     	ldr	x9, [sp, #0x1d0]
10024447c:     	sub	x8, x9, x8
100244480:     	sub	x0, x8, #0x10
100244484:     	bl	0x100b5d8c0 <_mi_free>
100244488:     	ldr	x2, [sp, #0x28]
10024448c:     	cbz	x22, 0x10024449c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x768>
100244490:     	ldr	x0, [sp, #0x1c0]
100244494:     	bl	0x100b5d8c0 <_mi_free>
100244498:     	ldr	x2, [sp, #0x28]
10024449c:     	ldr	x8, [sp, #0x260]
1002444a0:     	add	x9, sp, #0x188
1002444a4:     	stur	x8, [x9, #0x80]
1002444a8:     	ldr	q2, [sp, #0x250]
1002444ac:     	ldp	q0, q1, [sp, #0x210]
1002444b0:     	stp	q0, q1, [x9, #0x30]
1002444b4:     	ldp	q0, q1, [sp, #0x230]
1002444b8:     	stur	q0, [x9, #0x50]
1002444bc:     	stp	q1, q2, [x9, #0x60]
1002444c0:     	ldr	x8, [sp, #0x1b8]
1002444c4:     	cmn	x8, #0x1
1002444c8:     	b.eq	0x100244ccc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf98>
1002444cc:     	ldr	x1, [sp, #0x198]
1002444d0:     	b	0x1002440d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x3a4>
1002444d4:     	ldr	x12, [x24]
1002444d8:     	add	x13, x24, x2
1002444dc:     	ldur	x13, [x13, #-0x8]
1002444e0:     	b	0x100244508 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7d4>
1002444e4:     	b.ne	0x100244500 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7cc>
1002444e8:     	ldrb	w12, [x24]
1002444ec:     	mov	x13, x12
1002444f0:     	b	0x100244508 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7d4>
1002444f4:     	ldrh	w12, [x24]
1002444f8:     	ldurb	w13, [x13, #-0x1]
1002444fc:     	b	0x100244508 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7d4>
100244500:     	mov	x12, #0x0               ; =0
100244504:     	mov	x13, #0x0               ; =0
100244508:     	eor	x10, x12, x10
10024450c:     	eor	x9, x13, x9
100244510:     	mul	x12, x9, x10
100244514:     	umulh	x9, x9, x10
100244518:     	eor	x9, x9, x12
10024451c:     	add	x10, x11, x8
100244520:     	eor	x9, x10, x9
100244524:     	ror	x11, x9, #0x29
100244528:     	mul	x9, x11, x8
10024452c:     	umulh	x8, x11, x8
100244530:     	eor	x8, x8, x9
100244534:     	neg	w9, w11
100244538:     	ror	x15, x8, x9
10024453c:     	ldr	x8, [sp, #0x1e8]
100244540:     	mov	x14, x27
100244544:     	str	x1, [sp, #0x20]
100244548:     	str	x15, [sp, #0x8]
10024454c:     	cbz	x8, 0x1002446c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x98c>
100244550:     	mov	x8, #0x0                ; =0
100244554:     	mov	x9, #0x7c15             ; =31765
100244558:     	movk	x9, #0x7f4a, lsl #16
10024455c:     	movk	x9, #0x79b9, lsl #32
100244560:     	movk	x9, #0x9e37, lsl #48
100244564:     	mul	x9, x15, x9
100244568:     	eor	x11, x9, x9, lsr #32
10024456c:     	lsr	x12, x9, #57
100244570:     	ldp	x10, x9, [sp, #0x1d0]
100244574:     	ldr	x23, [sp, #0x190]
100244578:     	dup.8b	v0, w12
10024457c:     	and	x11, x11, x9
100244580:     	ldr	d1, [x10, x11]
100244584:     	cmeq.8b	v2, v1, v0
100244588:     	fmov	x12, d2
10024458c:     	ands	x12, x12, #0x8080808080808080
100244590:     	b.eq	0x1002445c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x894>
100244594:     	mov	x27, x14
100244598:     	rbit	x13, x12
10024459c:     	clz	x13, x13
1002445a0:     	add	x13, x11, x13, lsr #3
1002445a4:     	and	x13, x13, x9
1002445a8:     	sub	x13, x10, x13, lsl #4
1002445ac:     	ldur	x14, [x13, #-0x10]
1002445b0:     	cmp	x15, x14
1002445b4:     	b.eq	0x1002445fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8c8>
1002445b8:     	sub	x13, x12, #0x2
1002445bc:     	ands	x12, x13, x12
1002445c0:     	mov	x14, x27
1002445c4:     	b.ne	0x100244594 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x860>
1002445c8:     	movi.2d	v2, #0xffffffffffffffff
1002445cc:     	cmeq.8b	v1, v1, v2
1002445d0:     	fmov	x12, d1
1002445d4:     	cbnz	x12, 0x1002446c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x98c>
1002445d8:     	add	x8, x8, #0x8
1002445dc:     	add	x11, x11, x8
1002445e0:     	and	x11, x11, x9
1002445e4:     	ldr	d1, [x10, x11]
1002445e8:     	cmeq.8b	v2, v1, v0
1002445ec:     	fmov	x12, d2
1002445f0:     	ands	x12, x12, #0x8080808080808080
1002445f4:     	b.ne	0x100244594 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x860>
1002445f8:     	b	0x1002445c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x894>
1002445fc:     	ldur	x24, [x13, #-0x8]
100244600:     	cmp	x24, x1
100244604:     	b.hs	0x100245d68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2034>
100244608:     	mov	x14, x27
10024460c:     	ldr	x8, [x23, x24, lsl #3]
100244610:     	ldr	w9, [x8, #0x4]
100244614:     	cmp	x2, x9
100244618:     	b.ne	0x10024463c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x908>
10024461c:     	add	x0, x8, #0x14
100244620:     	ldr	x1, [sp, #0x18]
100244624:     	ldr	x2, [sp, #0x28]
100244628:     	bl	0x100b60760 <_writev+0x100b60760>
10024462c:     	ldr	x15, [sp, #0x8]
100244630:     	ldp	x1, x2, [sp, #0x20]
100244634:     	mov	x14, x27
100244638:     	cbz	w0, 0x1002446a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x974>
10024463c:     	ldr	x8, [sp, #0x1c8]
100244640:     	cbz	x8, 0x1002446c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x98c>
100244644:     	ldr	x9, [sp, #0x1c0]
100244648:     	lsl	x26, x8, #4
10024464c:     	add	x22, x9, #0x8
100244650:     	b	0x100244660 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x92c>
100244654:     	add	x22, x22, #0x10
100244658:     	subs	x26, x26, #0x10
10024465c:     	b.eq	0x1002446c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x98c>
100244660:     	ldur	x8, [x22, #-0x8]
100244664:     	cmp	x8, x15
100244668:     	b.ne	0x100244654 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x920>
10024466c:     	ldr	x24, [x22]
100244670:     	cmp	x24, x1
100244674:     	b.hs	0x100245d58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2024>
100244678:     	ldr	x8, [x23, x24, lsl #3]
10024467c:     	ldr	w9, [x8, #0x4]
100244680:     	cmp	x2, x9
100244684:     	b.ne	0x100244654 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x920>
100244688:     	add	x0, x8, #0x14
10024468c:     	ldr	x1, [sp, #0x18]
100244690:     	ldr	x2, [sp, #0x28]
100244694:     	bl	0x100b60760 <_writev+0x100b60760>
100244698:     	ldr	x15, [sp, #0x8]
10024469c:     	ldp	x1, x2, [sp, #0x20]
1002446a0:     	mov	x14, x27
1002446a4:     	cbnz	w0, 0x100244654 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x920>
1002446a8:     	ldr	x1, [sp, #0x1b0]
1002446ac:     	cmp	x24, x1
1002446b0:     	b.hs	0x100245d94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2060>
1002446b4:     	ldr	x26, [sp, #0x1a8]
1002446b8:     	ldr	x8, [sp, #0x10]
1002446bc:     	b	0x100244d70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x103c>
1002446c0:     	cmn	x28, #0x1
1002446c4:     	b.eq	0x1002446ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9b8>
1002446c8:     	mov	x27, x14
1002446cc:     	ldr	x24, [sp, #0x18]
1002446d0:     	mov	x0, x24
1002446d4:     	mov	x1, x2
1002446d8:     	bl	0x100349e30 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
1002446dc:     	ldr	x1, [sp, #0x8]
1002446e0:     	ldr	x2, [sp, #0x20]
1002446e4:     	mov	x26, x0
1002446e8:     	b	0x1002455cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1898>
1002446ec:     	cmp	x2, #0x40
1002446f0:     	b.hs	0x100244800 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xacc>
1002446f4:     	ands	x8, x2, #0x38
1002446f8:     	b.eq	0x10024471c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9e8>
1002446fc:     	and	x9, x2, #0x38
100244700:     	neg	x9, x9
100244704:     	ldr	x10, [sp, #0x18]
100244708:     	ldr	x11, [x10], #0x8
10024470c:     	tst	x11, #0x8080808080808080
100244710:     	b.ne	0x1002447b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244714:     	adds	x9, x9, #0x8
100244718:     	b.ne	0x100244708 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9d4>
10024471c:     	mov	x24, x2
100244720:     	and	x9, x2, #0x7
100244724:     	cbz	x9, 0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244728:     	ldr	x10, [sp, #0x18]
10024472c:     	add	x8, x10, x8
100244730:     	ldrsb	w10, [x8]
100244734:     	tbnz	w10, #0x1f, 0x1002447b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244738:     	mov	x24, x2
10024473c:     	cmp	x9, #0x1
100244740:     	b.eq	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244744:     	ldrsb	w10, [x8, #0x1]
100244748:     	tbnz	w10, #0x1f, 0x1002447b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
10024474c:     	mov	x24, x2
100244750:     	cmp	x9, #0x2
100244754:     	b.eq	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244758:     	ldrsb	w10, [x8, #0x2]
10024475c:     	tbnz	w10, #0x1f, 0x1002447b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244760:     	mov	x24, x2
100244764:     	cmp	x9, #0x3
100244768:     	b.eq	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
10024476c:     	ldrsb	w10, [x8, #0x3]
100244770:     	tbnz	w10, #0x1f, 0x1002447b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244774:     	mov	x24, x2
100244778:     	cmp	x9, #0x4
10024477c:     	b.eq	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244780:     	ldrsb	w10, [x8, #0x4]
100244784:     	tbnz	w10, #0x1f, 0x1002447b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244788:     	mov	x24, x2
10024478c:     	cmp	x9, #0x5
100244790:     	b.eq	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244794:     	ldrsb	w10, [x8, #0x5]
100244798:     	tbnz	w10, #0x1f, 0x1002447b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
10024479c:     	mov	x24, x2
1002447a0:     	cmp	x9, #0x6
1002447a4:     	b.eq	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
1002447a8:     	ldrsb	w8, [x8, #0x6]
1002447ac:     	mov	x24, x2
1002447b0:     	tbz	w8, #0x1f, 0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
1002447b4:     	mov	x27, x14
1002447b8:     	cmp	x2, #0x40
1002447bc:     	b.hs	0x10024488c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb58>
1002447c0:     	sub	x8, x29, #0x100
1002447c4:     	ldr	x24, [sp, #0x18]
1002447c8:     	mov	x0, x24
1002447cc:     	mov	x1, x2
1002447d0:     	mov	x22, x2
1002447d4:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
1002447d8:     	ldur	x8, [x29, #-0x100]
1002447dc:     	cbnz	x8, 0x1002448a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb70>
1002447e0:     	mov	x2, x22
1002447e4:     	cbz	x22, 0x100244e7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1148>
1002447e8:     	cmp	x2, #0x8
1002447ec:     	mov	x14, x27
1002447f0:     	b.hs	0x100244ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x116c>
1002447f4:     	mov	x8, #0x0                ; =0
1002447f8:     	mov	w24, #0x0               ; =0
1002447fc:     	b	0x100245250 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x151c>
100244800:     	and	x8, x2, #0x7fffffffffffffc0
100244804:     	ldr	x10, [sp, #0x18]
100244808:     	add	x8, x10, x8
10024480c:     	mov	x9, x8
100244810:     	ldp	q0, q1, [x10]
100244814:     	ldp	q2, q3, [x10, #0x20]
100244818:     	orr.16b	v0, v1, v0
10024481c:     	orr.16b	v1, v2, v3
100244820:     	orr.16b	v0, v0, v1
100244824:     	umaxv.16b	b0, v0
100244828:     	fmov	w11, s0
10024482c:     	tbnz	w11, #0x7, 0x1002447b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244830:     	add	x10, x10, #0x40
100244834:     	cmp	x10, x8
100244838:     	b.ne	0x100244810 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xadc>
10024483c:     	ands	x10, x2, #0x30
100244840:     	mov	x11, x10
100244844:     	b.eq	0x100244860 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb2c>
100244848:     	ldr	q0, [x9], #0x10
10024484c:     	umaxv.16b	b0, v0
100244850:     	fmov	w12, s0
100244854:     	tbnz	w12, #0x7, 0x1002447b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244858:     	subs	x11, x11, #0x10
10024485c:     	b.ne	0x100244848 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb14>
100244860:     	mov	x24, x2
100244864:     	and	x9, x2, #0xf
100244868:     	cbz	x9, 0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
10024486c:     	add	x8, x8, x10
100244870:     	ldrsb	w10, [x8]
100244874:     	tbnz	w10, #0x1f, 0x1002447b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244878:     	add	x8, x8, #0x1
10024487c:     	subs	x9, x9, #0x1
100244880:     	b.ne	0x100244870 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb3c>
100244884:     	mov	x24, x2
100244888:     	b	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
10024488c:     	ldr	x24, [sp, #0x18]
100244890:     	mov	x0, x24
100244894:     	mov	x1, x2
100244898:     	mov	x22, x2
10024489c:     	bl	0x1009f405c <__RNvNtNtCsvoDT44C053_8simdutf814implementation7aarch6424validate_utf8_basic_neon>
1002448a0:     	tbz	w0, #0x0, 0x100244dd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x109c>
1002448a4:     	mov	x0, x24
1002448a8:     	mov	x1, x22
1002448ac:     	bl	0x100349e30 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
1002448b0:     	mov	x26, x0
1002448b4:     	b	0x1002455c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1890>
1002448b8:     	cmp	x14, #0x8
1002448bc:     	b.hs	0x100245db8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2084>
1002448c0:     	ldr	x8, [sp, #0x68]
1002448c4:     	ldr	x23, [x8, x14, lsl #3]
1002448c8:     	ldr	w8, [x23, #0x4]
1002448cc:     	cmp	x1, x8
1002448d0:     	b.ne	0x1002448f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbc0>
1002448d4:     	add	x0, x23, #0x14
1002448d8:     	mov	x1, x24
1002448dc:     	ldr	x2, [sp, #0x28]
1002448e0:     	str	x14, [sp, #0x80]
1002448e4:     	bl	0x100b60760 <_writev+0x100b60760>
1002448e8:     	ldr	x1, [sp, #0x28]
1002448ec:     	ldr	x14, [sp, #0x80]
1002448f0:     	cbz	w0, 0x100244e98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1164>
1002448f4:     	mov	x0, x24
1002448f8:     	mov	x23, x14
1002448fc:     	bl	0x10032687c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100244900:     	mov	x14, x23
100244904:     	mov	x10, x0
100244908:     	mov	w27, #0x0               ; =0
10024490c:     	mov	w8, #0x0                ; =0
100244910:     	cmp	x14, #0x0
100244914:     	str	w8, [sp, #0x80]
100244918:     	csinc	w23, w8, wzr, ne
10024491c:     	cmp	x22, #0x9
100244920:     	b.hs	0x100245cf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1fc4>
100244924:     	ldr	x2, [sp, #0x28]
100244928:     	cbz	x22, 0x100244c98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
10024492c:     	ldr	x8, [sp, #0x100]
100244930:     	cmp	x8, x10
100244934:     	b.eq	0x100244cb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf84>
100244938:     	tbnz	w23, #0x0, 0x100244974 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xc40>
10024493c:     	ldr	w9, [x8, #0x4]
100244940:     	cmp	x2, x9
100244944:     	b.ne	0x100244974 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xc40>
100244948:     	add	x0, x8, #0x14
10024494c:     	mov	x1, x24
100244950:     	ldr	x2, [sp, #0x28]
100244954:     	mov	x24, x14
100244958:     	str	x10, [sp, #0x78]
10024495c:     	bl	0x100b60760 <_writev+0x100b60760>
100244960:     	ldr	x10, [sp, #0x78]
100244964:     	ldr	x2, [sp, #0x28]
100244968:     	mov	x14, x24
10024496c:     	ldr	x24, [sp, #0x18]
100244970:     	cbz	w0, 0x100244cb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf84>
100244974:     	cmp	x22, #0x1
100244978:     	b.eq	0x100244c98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
10024497c:     	ldr	x9, [sp, #0x108]
100244980:     	add	x8, sp, #0x148
100244984:     	add	x8, x8, #0x8
100244988:     	cmp	x9, x10
10024498c:     	b.eq	0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244990:     	tbnz	w23, #0x0, 0x1002449d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xca0>
100244994:     	ldr	w8, [x9, #0x4]
100244998:     	cmp	x2, x8
10024499c:     	b.ne	0x1002449d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xca0>
1002449a0:     	add	x0, x9, #0x14
1002449a4:     	mov	x1, x24
1002449a8:     	ldr	x2, [sp, #0x28]
1002449ac:     	mov	x24, x14
1002449b0:     	str	x10, [sp, #0x78]
1002449b4:     	bl	0x100b60760 <_writev+0x100b60760>
1002449b8:     	ldr	x10, [sp, #0x78]
1002449bc:     	ldr	x2, [sp, #0x28]
1002449c0:     	mov	x14, x24
1002449c4:     	ldr	x24, [sp, #0x18]
1002449c8:     	add	x8, sp, #0x148
1002449cc:     	add	x8, x8, #0x8
1002449d0:     	cbz	w0, 0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
1002449d4:     	cmp	x22, #0x2
1002449d8:     	b.eq	0x100244c98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
1002449dc:     	ldr	x9, [sp, #0x110]
1002449e0:     	add	x8, sp, #0x148
1002449e4:     	add	x8, x8, #0x10
1002449e8:     	cmp	x9, x10
1002449ec:     	b.eq	0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
1002449f0:     	tbnz	w23, #0x0, 0x100244a34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd00>
1002449f4:     	ldr	w8, [x9, #0x4]
1002449f8:     	cmp	x2, x8
1002449fc:     	b.ne	0x100244a34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd00>
100244a00:     	add	x0, x9, #0x14
100244a04:     	mov	x1, x24
100244a08:     	ldr	x2, [sp, #0x28]
100244a0c:     	mov	x24, x14
100244a10:     	str	x10, [sp, #0x78]
100244a14:     	bl	0x100b60760 <_writev+0x100b60760>
100244a18:     	ldr	x10, [sp, #0x78]
100244a1c:     	ldr	x2, [sp, #0x28]
100244a20:     	mov	x14, x24
100244a24:     	ldr	x24, [sp, #0x18]
100244a28:     	add	x8, sp, #0x148
100244a2c:     	add	x8, x8, #0x10
100244a30:     	cbz	w0, 0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244a34:     	cmp	x22, #0x3
100244a38:     	b.eq	0x100244c98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244a3c:     	ldr	x9, [sp, #0x118]
100244a40:     	add	x8, sp, #0x148
100244a44:     	add	x8, x8, #0x18
100244a48:     	cmp	x9, x10
100244a4c:     	b.eq	0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244a50:     	tbnz	w23, #0x0, 0x100244a94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd60>
100244a54:     	ldr	w8, [x9, #0x4]
100244a58:     	cmp	x2, x8
100244a5c:     	b.ne	0x100244a94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd60>
100244a60:     	add	x0, x9, #0x14
100244a64:     	mov	x1, x24
100244a68:     	ldr	x2, [sp, #0x28]
100244a6c:     	mov	x24, x14
100244a70:     	str	x10, [sp, #0x78]
100244a74:     	bl	0x100b60760 <_writev+0x100b60760>
100244a78:     	ldr	x10, [sp, #0x78]
100244a7c:     	ldr	x2, [sp, #0x28]
100244a80:     	mov	x14, x24
100244a84:     	ldr	x24, [sp, #0x18]
100244a88:     	add	x8, sp, #0x148
100244a8c:     	add	x8, x8, #0x18
100244a90:     	cbz	w0, 0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244a94:     	cmp	x22, #0x4
100244a98:     	b.eq	0x100244c98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244a9c:     	ldr	x9, [sp, #0x120]
100244aa0:     	add	x8, sp, #0x148
100244aa4:     	add	x8, x8, #0x20
100244aa8:     	cmp	x9, x10
100244aac:     	b.eq	0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244ab0:     	tbnz	w23, #0x0, 0x100244af4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdc0>
100244ab4:     	ldr	w8, [x9, #0x4]
100244ab8:     	cmp	x2, x8
100244abc:     	b.ne	0x100244af4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdc0>
100244ac0:     	add	x0, x9, #0x14
100244ac4:     	mov	x1, x24
100244ac8:     	ldr	x2, [sp, #0x28]
100244acc:     	mov	x24, x14
100244ad0:     	str	x10, [sp, #0x78]
100244ad4:     	bl	0x100b60760 <_writev+0x100b60760>
100244ad8:     	ldr	x10, [sp, #0x78]
100244adc:     	ldr	x2, [sp, #0x28]
100244ae0:     	mov	x14, x24
100244ae4:     	ldr	x24, [sp, #0x18]
100244ae8:     	add	x8, sp, #0x148
100244aec:     	add	x8, x8, #0x20
100244af0:     	cbz	w0, 0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244af4:     	cmp	x22, #0x5
100244af8:     	b.eq	0x100244c98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244afc:     	ldr	x9, [sp, #0x128]
100244b00:     	add	x8, sp, #0x148
100244b04:     	add	x8, x8, #0x28
100244b08:     	cmp	x9, x10
100244b0c:     	b.eq	0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244b10:     	tbnz	w23, #0x0, 0x100244b54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe20>
100244b14:     	ldr	w8, [x9, #0x4]
100244b18:     	cmp	x2, x8
100244b1c:     	b.ne	0x100244b54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe20>
100244b20:     	add	x0, x9, #0x14
100244b24:     	mov	x1, x24
100244b28:     	ldr	x2, [sp, #0x28]
100244b2c:     	mov	x24, x14
100244b30:     	str	x10, [sp, #0x78]
100244b34:     	bl	0x100b60760 <_writev+0x100b60760>
100244b38:     	ldr	x10, [sp, #0x78]
100244b3c:     	ldr	x2, [sp, #0x28]
100244b40:     	mov	x14, x24
100244b44:     	ldr	x24, [sp, #0x18]
100244b48:     	add	x8, sp, #0x148
100244b4c:     	add	x8, x8, #0x28
100244b50:     	cbz	w0, 0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244b54:     	cmp	x22, #0x6
100244b58:     	b.eq	0x100244c98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244b5c:     	ldr	x9, [sp, #0x130]
100244b60:     	add	x8, sp, #0x148
100244b64:     	add	x8, x8, #0x30
100244b68:     	cmp	x9, x10
100244b6c:     	b.eq	0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244b70:     	tbnz	w23, #0x0, 0x100244bb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe80>
100244b74:     	ldr	w8, [x9, #0x4]
100244b78:     	cmp	x2, x8
100244b7c:     	b.ne	0x100244bb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe80>
100244b80:     	add	x0, x9, #0x14
100244b84:     	mov	x1, x24
100244b88:     	ldr	x2, [sp, #0x28]
100244b8c:     	mov	x24, x14
100244b90:     	str	x10, [sp, #0x78]
100244b94:     	bl	0x100b60760 <_writev+0x100b60760>
100244b98:     	ldr	x10, [sp, #0x78]
100244b9c:     	ldr	x2, [sp, #0x28]
100244ba0:     	mov	x14, x24
100244ba4:     	ldr	x24, [sp, #0x18]
100244ba8:     	add	x8, sp, #0x148
100244bac:     	add	x8, x8, #0x30
100244bb0:     	cbz	w0, 0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244bb4:     	cmp	x22, #0x7
100244bb8:     	b.eq	0x100244c98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244bbc:     	ldr	x9, [sp, #0x138]
100244bc0:     	add	x8, sp, #0x148
100244bc4:     	add	x8, x8, #0x38
100244bc8:     	cmp	x9, x10
100244bcc:     	b.eq	0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244bd0:     	tbnz	w23, #0x0, 0x100244c08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xed4>
100244bd4:     	ldr	w8, [x9, #0x4]
100244bd8:     	cmp	x2, x8
100244bdc:     	b.ne	0x100244c08 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xed4>
100244be0:     	add	x0, x9, #0x14
100244be4:     	mov	x1, x24
100244be8:     	mov	x23, x14
100244bec:     	str	x10, [sp, #0x78]
100244bf0:     	bl	0x100b60760 <_writev+0x100b60760>
100244bf4:     	ldr	x10, [sp, #0x78]
100244bf8:     	mov	x14, x23
100244bfc:     	add	x8, sp, #0x148
100244c00:     	add	x8, x8, #0x38
100244c04:     	cbz	w0, 0x100244cbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244c08:     	cmp	x22, #0x8
100244c0c:     	b.ne	0x100244c98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244c10:     	mov	x24, x10
100244c14:     	mov	x23, x14
100244c18:     	mov	w0, #0x80               ; =128
100244c1c:     	mov	w1, #0x8                ; =8
100244c20:     	bl	0x100b5db48 <_mi_malloc_aligned>
100244c24:     	cbz	x0, 0x100245dcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2098>
100244c28:     	mov	x22, x0
100244c2c:     	mov	w0, #0x80               ; =128
100244c30:     	mov	w1, #0x8                ; =8
100244c34:     	bl	0x100b5db48 <_mi_malloc_aligned>
100244c38:     	cbz	x0, 0x100245dcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2098>
100244c3c:     	mov	x26, x0
100244c40:     	ldp	q0, q1, [sp, #0x100]
100244c44:     	stp	q0, q1, [x22]
100244c48:     	ldp	q0, q1, [sp, #0x120]
100244c4c:     	stp	q0, q1, [x22, #0x20]
100244c50:     	add	x8, sp, #0x148
100244c54:     	ldp	q0, q1, [x8]
100244c58:     	stp	q0, q1, [x0]
100244c5c:     	ldp	q0, q1, [x8, #0x20]
100244c60:     	stp	q0, q1, [x0, #0x20]
100244c64:     	str	x24, [x22, #0x40]
100244c68:     	ldp	x9, x24, [sp, #0x10]
100244c6c:     	str	x9, [x0, #0x40]
100244c70:     	mov	w9, #0x10               ; =16
100244c74:     	stp	x9, x22, [sp, #0x188]
100244c78:     	ldp	q0, q1, [sp, #0x30]
100244c7c:     	str	q1, [x8, #0x50]
100244c80:     	str	x0, [sp, #0x1a8]
100244c84:     	mov	w1, #0x9                ; =9
100244c88:     	mov	w22, #0x8               ; =8
100244c8c:     	stur	q0, [x8, #0x68]
100244c90:     	mov	x14, x23
100244c94:     	b	0x100245628 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x18f4>
100244c98:     	add	x8, sp, #0x100
100244c9c:     	str	x10, [x8, x22, lsl #3]
100244ca0:     	add	x8, sp, #0x148
100244ca4:     	ldr	x9, [sp, #0x10]
100244ca8:     	str	x9, [x8, x22, lsl #3]
100244cac:     	add	x22, x22, #0x1
100244cb0:     	str	x22, [sp, #0x70]
100244cb4:     	b	0x100244cc4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf90>
100244cb8:     	add	x8, sp, #0x148
100244cbc:     	ldr	x9, [sp, #0x10]
100244cc0:     	str	x9, [x8]
100244cc4:     	ldr	x1, [sp, #0x20]
100244cc8:     	b	0x100245628 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x18f4>
100244ccc:     	ldp	x23, x8, [sp, #0x190]
100244cd0:     	str	x8, [sp, #0x20]
100244cd4:     	str	x21, [sp, #0x8]
100244cd8:     	mov	x0, x24
100244cdc:     	mov	x1, x2
100244ce0:     	bl	0x10032687c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100244ce4:     	mov	x26, x0
100244ce8:     	mov	x14, x27
100244cec:     	cmp	x27, #0x0
100244cf0:     	cset	w8, eq
100244cf4:     	ldr	w9, [sp, #0x80]
100244cf8:     	ldr	x11, [sp, #0x20]
100244cfc:     	cbz	x11, 0x100244d84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1050>
100244d00:     	mov	x24, #0x0               ; =0
100244d04:     	orr	w22, w8, w9
100244d08:     	lsl	x27, x11, #3
100244d0c:     	b	0x100244d1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfe8>
100244d10:     	add	x24, x24, #0x1
100244d14:     	subs	x27, x27, #0x8
100244d18:     	b.eq	0x100244d84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1050>
100244d1c:     	ldr	x8, [x23, x24, lsl #3]
100244d20:     	cmp	x8, x26
100244d24:     	b.eq	0x100244d5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
100244d28:     	tbnz	w22, #0x0, 0x100244d10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfdc>
100244d2c:     	ldr	w9, [x8, #0x4]
100244d30:     	ldr	x10, [sp, #0x28]
100244d34:     	cmp	x10, x9
100244d38:     	b.ne	0x100244d10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfdc>
100244d3c:     	add	x0, x8, #0x14
100244d40:     	ldr	x1, [sp, #0x18]
100244d44:     	ldr	x2, [sp, #0x28]
100244d48:     	mov	x21, x14
100244d4c:     	bl	0x100b60760 <_writev+0x100b60760>
100244d50:     	ldr	x11, [sp, #0x20]
100244d54:     	mov	x14, x21
100244d58:     	cbnz	w0, 0x100244d10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfdc>
100244d5c:     	ldr	x1, [sp, #0x1b0]
100244d60:     	cmp	x24, x1
100244d64:     	b.hs	0x100245d84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2050>
100244d68:     	ldr	x26, [sp, #0x1a8]
100244d6c:     	ldp	x21, x8, [sp, #0x8]
100244d70:     	str	x8, [x26, x24, lsl #3]
100244d74:     	ldr	x22, [sp]
100244d78:     	ldr	w27, [sp, #0x78]
100244d7c:     	ldr	x24, [sp, #0x18]
100244d80:     	b	0x100245628 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x18f4>
100244d84:     	ldr	x8, [sp, #0x188]
100244d88:     	cmp	x11, x8
100244d8c:     	ldr	x21, [sp, #0x8]
100244d90:     	ldr	w27, [sp, #0x78]
100244d94:     	b.eq	0x100244f70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x123c>
100244d98:     	str	x26, [x23, x11, lsl #3]
100244d9c:     	add	x8, x11, #0x1
100244da0:     	str	x8, [sp, #0x198]
100244da4:     	ldr	x22, [sp, #0x1b0]
100244da8:     	ldr	x8, [sp, #0x1a0]
100244dac:     	cmp	x22, x8
100244db0:     	b.eq	0x100244f90 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x125c>
100244db4:     	ldr	x26, [sp, #0x1a8]
100244db8:     	ldp	x8, x24, [sp, #0x10]
100244dbc:     	str	x8, [x26, x22, lsl #3]
100244dc0:     	add	x1, x22, #0x1
100244dc4:     	str	x1, [sp, #0x1b0]
100244dc8:     	ldr	x22, [sp]
100244dcc:     	b	0x100245628 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x18f4>
100244dd0:     	mov	x8, x24
100244dd4:     	mov	w24, #0x0               ; =0
100244dd8:     	add	x8, x8, #0x20
100244ddc:     	mov	x9, x22
100244de0:     	movi.16b	v4, #0xbf
100244de4:     	movi.16b	v5, #0x1
100244de8:     	movi.16b	v6, #0xef
100244dec:     	mov	x2, x22
100244df0:     	ldp	q0, q1, [x8, #-0x20]
100244df4:     	cmgt.16b	v2, v0, v4
100244df8:     	and.16b	v2, v2, v5
100244dfc:     	cmhi.16b	v0, v0, v6
100244e00:     	sub.16b	v0, v2, v0
100244e04:     	cmgt.16b	v2, v1, v4
100244e08:     	cmhi.16b	v1, v1, v6
100244e0c:     	sub.16b	v0, v0, v2
100244e10:     	sub.16b	v0, v0, v1
100244e14:     	ldp	q1, q2, [x8], #0x40
100244e18:     	cmgt.16b	v3, v1, v4
100244e1c:     	sub.16b	v0, v0, v3
100244e20:     	cmhi.16b	v1, v1, v6
100244e24:     	sub.16b	v0, v0, v1
100244e28:     	cmgt.16b	v1, v2, v4
100244e2c:     	cmhi.16b	v2, v2, v6
100244e30:     	sub.16b	v0, v0, v1
100244e34:     	sub.16b	v0, v0, v2
100244e38:     	uaddlv.16b	h0, v0
100244e3c:     	fmov	w10, s0
100244e40:     	add	w24, w10, w24
100244e44:     	sub	x9, x9, #0x40
100244e48:     	cmp	x9, #0x3f
100244e4c:     	b.hi	0x100244df0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10bc>
100244e50:     	and	x13, x2, #0x7fffffffffffffc0
100244e54:     	cmp	x13, x2
100244e58:     	mov	x14, x27
100244e5c:     	b.eq	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244e60:     	ldr	x8, [sp, #0x18]
100244e64:     	add	x9, x8, x13
100244e68:     	and	x10, x2, #0x800000000000003f
100244e6c:     	cmp	x10, #0x4
100244e70:     	b.hs	0x100244f60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x122c>
100244e74:     	mov	x8, x9
100244e78:     	b	0x100245488 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1754>
100244e7c:     	mov	w24, #0x0               ; =0
100244e80:     	ldur	w8, [x19, #0x20]
100244e84:     	tbz	w8, #0x0, 0x100245590 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x185c>
100244e88:     	mov	x14, x27
100244e8c:     	mov	w9, #0x20               ; =32
100244e90:     	mov	w8, #0x14               ; =20
100244e94:     	b	0x100245580 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x184c>
100244e98:     	mov	x10, x23
100244e9c:     	b	0x1002441ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x478>
100244ea0:     	cmp	x2, #0x10
100244ea4:     	b.hs	0x100244fac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1278>
100244ea8:     	mov	x8, #0x0                ; =0
100244eac:     	mov	w24, #0x0               ; =0
100244eb0:     	mov	x10, x8
100244eb4:     	and	x8, x2, #0x38
100244eb8:     	movi.2d	v0, #0000000000000000
100244ebc:     	movi.2d	v1, #0000000000000000
100244ec0:     	mov.s	v1[0], w24
100244ec4:     	sub	x9, x10, x8
100244ec8:     	ldr	x11, [sp, #0x18]
100244ecc:     	add	x10, x11, x10
100244ed0:     	movi.4s	v16, #0x2
100244ed4:     	ldr	d2, [x10], #0x8
100244ed8:     	sshll.8h	v3, v2, #0x0
100244edc:     	cmlt.8h	v3, v3, #0
100244ee0:     	sshll2.4s	v4, v3, #0x0
100244ee4:     	sshll.4s	v3, v3, #0x0
100244ee8:     	cmhi.8b	v5, v8, v2
100244eec:     	sshll.8h	v5, v5, #0x0
100244ef0:     	sshll2.4s	v6, v5, #0x0
100244ef4:     	sshll.4s	v7, v5, #0x0
100244ef8:     	bic.16b	v7, v16, v7
100244efc:     	ssubw.4s	v7, v7, v5
100244f00:     	bic.16b	v6, v16, v6
100244f04:     	ssubw2.4s	v5, v6, v5
100244f08:     	cmgt.8b	v2, v9, v2
100244f0c:     	sshll.8h	v2, v2, #0x0
100244f10:     	ushll.4s	v6, v2, #0x0
100244f14:     	ushll2.4s	v2, v2, #0x0
100244f18:     	bic.16b	v2, v5, v2
100244f1c:     	bic.16b	v5, v7, v6
100244f20:     	and.16b	v5, v5, v3
100244f24:     	mvn.16b	v3, v3
100244f28:     	sub.4s	v3, v5, v3
100244f2c:     	and.16b	v2, v2, v4
100244f30:     	mvn.16b	v4, v4
100244f34:     	sub.4s	v2, v2, v4
100244f38:     	add.4s	v0, v2, v0
100244f3c:     	add.4s	v1, v3, v1
100244f40:     	adds	x9, x9, #0x8
100244f44:     	b.ne	0x100244ed4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11a0>
100244f48:     	add.4s	v0, v1, v0
100244f4c:     	addv.4s	s0, v0
100244f50:     	fmov	w24, s0
100244f54:     	cmp	x2, x8
100244f58:     	b.ne	0x100245250 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x151c>
100244f5c:     	b	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244f60:     	cmp	x10, #0x20
100244f64:     	b.hs	0x100245290 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x155c>
100244f68:     	mov	x11, #0x0               ; =0
100244f6c:     	b	0x10024541c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x16e8>
100244f70:     	add	x0, sp, #0x188
100244f74:     	mov	x21, x14
100244f78:     	bl	0x100b3a5ac <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100244f7c:     	ldr	x11, [sp, #0x20]
100244f80:     	mov	x14, x21
100244f84:     	ldr	x21, [sp, #0x8]
100244f88:     	ldr	x23, [sp, #0x190]
100244f8c:     	b	0x100244d98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1064>
100244f90:     	add	x8, sp, #0x188
100244f94:     	add	x0, x8, #0x18
100244f98:     	mov	x21, x14
100244f9c:     	bl	0x100b3a5ac <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100244fa0:     	mov	x14, x21
100244fa4:     	ldr	x21, [sp, #0x8]
100244fa8:     	b	0x100244db4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1080>
100244fac:     	and	x8, x2, #0x30
100244fb0:     	ldp	d0, d1, [x24]
100244fb4:     	sshll.8h	v2, v0, #0x0
100244fb8:     	cmlt.8h	v2, v2, #0
100244fbc:     	sshll.4s	v3, v2, #0x0
100244fc0:     	sshll2.4s	v2, v2, #0x0
100244fc4:     	sshll.8h	v4, v1, #0x0
100244fc8:     	cmlt.8h	v4, v4, #0
100244fcc:     	sshll.4s	v5, v4, #0x0
100244fd0:     	sshll2.4s	v4, v4, #0x0
100244fd4:     	cmhi.8b	v6, v8, v0
100244fd8:     	sshll.8h	v6, v6, #0x0
100244fdc:     	sshll.4s	v7, v6, #0x0
100244fe0:     	sshll2.4s	v16, v6, #0x0
100244fe4:     	cmhi.8b	v17, v8, v1
100244fe8:     	sshll.8h	v17, v17, #0x0
100244fec:     	sshll.4s	v18, v17, #0x0
100244ff0:     	sshll2.4s	v19, v17, #0x0
100244ff4:     	movi.4s	v24, #0x2
100244ff8:     	bic.16b	v16, v24, v16
100244ffc:     	ssubw2.4s	v16, v16, v6
100245000:     	bic.16b	v7, v24, v7
100245004:     	ssubw.4s	v6, v7, v6
100245008:     	bic.16b	v7, v24, v19
10024500c:     	ssubw2.4s	v7, v7, v17
100245010:     	bic.16b	v18, v24, v18
100245014:     	ssubw.4s	v17, v18, v17
100245018:     	cmgt.8b	v0, v9, v0
10024501c:     	sshll.8h	v0, v0, #0x0
100245020:     	ushll2.4s	v18, v0, #0x0
100245024:     	ushll.4s	v0, v0, #0x0
100245028:     	cmgt.8b	v1, v9, v1
10024502c:     	sshll.8h	v1, v1, #0x0
100245030:     	ushll2.4s	v19, v1, #0x0
100245034:     	ushll.4s	v20, v1, #0x0
100245038:     	bic.16b	v1, v6, v0
10024503c:     	bic.16b	v0, v16, v18
100245040:     	and.16b	v0, v0, v2
100245044:     	mvn.16b	v2, v2
100245048:     	sub.4s	v0, v0, v2
10024504c:     	and.16b	v1, v1, v3
100245050:     	mvn.16b	v2, v3
100245054:     	sub.4s	v1, v1, v2
100245058:     	bic.16b	v3, v17, v20
10024505c:     	bic.16b	v2, v7, v19
100245060:     	and.16b	v2, v2, v4
100245064:     	mvn.16b	v4, v4
100245068:     	sub.4s	v2, v2, v4
10024506c:     	and.16b	v3, v3, v5
100245070:     	mvn.16b	v4, v5
100245074:     	sub.4s	v3, v3, v4
100245078:     	cmp	x8, #0x10
10024507c:     	b.eq	0x100245230 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14fc>
100245080:     	ldp	d4, d5, [x24, #0x10]
100245084:     	sshll.8h	v6, v4, #0x0
100245088:     	cmlt.8h	v6, v6, #0
10024508c:     	sshll2.4s	v7, v6, #0x0
100245090:     	sshll.4s	v6, v6, #0x0
100245094:     	sshll.8h	v16, v5, #0x0
100245098:     	cmlt.8h	v16, v16, #0
10024509c:     	sshll2.4s	v17, v16, #0x0
1002450a0:     	sshll.4s	v16, v16, #0x0
1002450a4:     	cmhi.8b	v18, v8, v4
1002450a8:     	sshll.8h	v18, v18, #0x0
1002450ac:     	sshll2.4s	v19, v18, #0x0
1002450b0:     	sshll.4s	v20, v18, #0x0
1002450b4:     	cmhi.8b	v21, v8, v5
1002450b8:     	sshll.8h	v21, v21, #0x0
1002450bc:     	sshll2.4s	v22, v21, #0x0
1002450c0:     	sshll.4s	v23, v21, #0x0
1002450c4:     	bic.16b	v20, v24, v20
1002450c8:     	ssubw.4s	v20, v20, v18
1002450cc:     	bic.16b	v19, v24, v19
1002450d0:     	ssubw2.4s	v18, v19, v18
1002450d4:     	bic.16b	v19, v24, v23
1002450d8:     	ssubw.4s	v19, v19, v21
1002450dc:     	bic.16b	v22, v24, v22
1002450e0:     	ssubw2.4s	v21, v22, v21
1002450e4:     	cmgt.8b	v4, v9, v4
1002450e8:     	sshll.8h	v4, v4, #0x0
1002450ec:     	ushll.4s	v22, v4, #0x0
1002450f0:     	ushll2.4s	v4, v4, #0x0
1002450f4:     	cmgt.8b	v5, v9, v5
1002450f8:     	sshll.8h	v5, v5, #0x0
1002450fc:     	ushll.4s	v23, v5, #0x0
100245100:     	ushll2.4s	v5, v5, #0x0
100245104:     	bic.16b	v4, v18, v4
100245108:     	bic.16b	v18, v20, v22
10024510c:     	and.16b	v18, v18, v6
100245110:     	mvn.16b	v6, v6
100245114:     	sub.4s	v6, v18, v6
100245118:     	and.16b	v4, v4, v7
10024511c:     	mvn.16b	v7, v7
100245120:     	sub.4s	v4, v4, v7
100245124:     	bic.16b	v5, v21, v5
100245128:     	bic.16b	v7, v19, v23
10024512c:     	and.16b	v7, v7, v16
100245130:     	mvn.16b	v16, v16
100245134:     	sub.4s	v7, v7, v16
100245138:     	and.16b	v5, v5, v17
10024513c:     	mvn.16b	v16, v17
100245140:     	sub.4s	v5, v5, v16
100245144:     	add.4s	v0, v4, v0
100245148:     	add.4s	v1, v6, v1
10024514c:     	add.4s	v2, v5, v2
100245150:     	add.4s	v3, v7, v3
100245154:     	cmp	x8, #0x20
100245158:     	b.eq	0x100245230 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14fc>
10024515c:     	ldp	d4, d5, [x24, #0x20]
100245160:     	sshll.8h	v6, v4, #0x0
100245164:     	cmlt.8h	v6, v6, #0
100245168:     	sshll2.4s	v7, v6, #0x0
10024516c:     	sshll.4s	v6, v6, #0x0
100245170:     	sshll.8h	v16, v5, #0x0
100245174:     	cmlt.8h	v16, v16, #0
100245178:     	sshll2.4s	v17, v16, #0x0
10024517c:     	sshll.4s	v16, v16, #0x0
100245180:     	cmhi.8b	v18, v8, v4
100245184:     	sshll.8h	v18, v18, #0x0
100245188:     	sshll2.4s	v19, v18, #0x0
10024518c:     	sshll.4s	v20, v18, #0x0
100245190:     	cmhi.8b	v21, v8, v5
100245194:     	sshll.8h	v21, v21, #0x0
100245198:     	sshll2.4s	v22, v21, #0x0
10024519c:     	sshll.4s	v23, v21, #0x0
1002451a0:     	bic.16b	v20, v24, v20
1002451a4:     	ssubw.4s	v20, v20, v18
1002451a8:     	bic.16b	v19, v24, v19
1002451ac:     	ssubw2.4s	v18, v19, v18
1002451b0:     	bic.16b	v19, v24, v23
1002451b4:     	ssubw.4s	v19, v19, v21
1002451b8:     	bic.16b	v22, v24, v22
1002451bc:     	ssubw2.4s	v21, v22, v21
1002451c0:     	cmgt.8b	v4, v9, v4
1002451c4:     	sshll.8h	v4, v4, #0x0
1002451c8:     	ushll.4s	v22, v4, #0x0
1002451cc:     	ushll2.4s	v4, v4, #0x0
1002451d0:     	cmgt.8b	v5, v9, v5
1002451d4:     	sshll.8h	v5, v5, #0x0
1002451d8:     	ushll.4s	v23, v5, #0x0
1002451dc:     	ushll2.4s	v5, v5, #0x0
1002451e0:     	bic.16b	v4, v18, v4
1002451e4:     	bic.16b	v18, v20, v22
1002451e8:     	and.16b	v18, v18, v6
1002451ec:     	mvn.16b	v6, v6
1002451f0:     	sub.4s	v6, v18, v6
1002451f4:     	and.16b	v4, v4, v7
1002451f8:     	mvn.16b	v7, v7
1002451fc:     	sub.4s	v4, v4, v7
100245200:     	bic.16b	v5, v21, v5
100245204:     	bic.16b	v7, v19, v23
100245208:     	and.16b	v7, v7, v16
10024520c:     	mvn.16b	v16, v16
100245210:     	sub.4s	v7, v7, v16
100245214:     	and.16b	v5, v5, v17
100245218:     	mvn.16b	v16, v17
10024521c:     	sub.4s	v5, v5, v16
100245220:     	add.4s	v0, v4, v0
100245224:     	add.4s	v1, v6, v1
100245228:     	add.4s	v2, v5, v2
10024522c:     	add.4s	v3, v7, v3
100245230:     	add.4s	v1, v3, v1
100245234:     	add.4s	v0, v2, v0
100245238:     	add.4s	v0, v1, v0
10024523c:     	addv.4s	s0, v0
100245240:     	fmov	w24, s0
100245244:     	cmp	x2, x8
100245248:     	b.eq	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
10024524c:     	tbnz	w2, #0x3, 0x100244eb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x117c>
100245250:     	sub	x9, x2, x8
100245254:     	ldr	x10, [sp, #0x18]
100245258:     	add	x8, x10, x8
10024525c:     	ldrsb	w10, [x8], #0x1
100245260:     	and	w11, w10, #0xff
100245264:     	cmp	w11, #0xf0
100245268:     	mov	w12, #0x1               ; =1
10024526c:     	cinc	w12, w12, hs
100245270:     	cmp	w11, #0xc0
100245274:     	csel	w11, wzr, w12, lo
100245278:     	tst	w10, #0x80000000
10024527c:     	csinc	w10, w11, wzr, ne
100245280:     	add	w24, w10, w24
100245284:     	subs	x9, x9, #0x1
100245288:     	b.ne	0x10024525c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1528>
10024528c:     	b	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100245290:     	and	x12, x2, #0x1c
100245294:     	movi.2d	v0, #0000000000000000
100245298:     	movi.2d	v1, #0000000000000000
10024529c:     	mov.s	v1[0], w24
1002452a0:     	mov	x8, #-0x7               ; =-7
1002452a4:     	movk	x8, #0x7fff, lsl #48
1002452a8:     	add	x8, x8, #0x27
1002452ac:     	and	x11, x2, x8
1002452b0:     	add	x8, x9, x11
1002452b4:     	ldr	x14, [sp, #0x18]
1002452b8:     	add	x13, x14, x13
1002452bc:     	add	x13, x13, #0x10
1002452c0:     	mov	x14, x11
1002452c4:     	movi.2d	v3, #0000000000000000
1002452c8:     	movi.2d	v2, #0000000000000000
1002452cc:     	movi.2d	v7, #0000000000000000
1002452d0:     	movi.2d	v6, #0000000000000000
1002452d4:     	movi.2d	v4, #0000000000000000
1002452d8:     	movi.2d	v5, #0000000000000000
1002452dc:     	movi.16b	v12, #0xbf
1002452e0:     	movi.16b	v13, #0xef
1002452e4:     	movi.4s	v14, #0x1
1002452e8:     	ldp	q16, q17, [x13, #-0x10]
1002452ec:     	cmgt.16b	v18, v16, v12
1002452f0:     	ushll.8h	v19, v18, #0x0
1002452f4:     	ushll.4s	v20, v19, #0x0
1002452f8:     	and.16b	v20, v20, v14
1002452fc:     	ushll2.4s	v19, v19, #0x0
100245300:     	and.16b	v19, v19, v14
100245304:     	ushll2.8h	v18, v18, #0x0
100245308:     	ushll.4s	v21, v18, #0x0
10024530c:     	and.16b	v21, v21, v14
100245310:     	ushll2.4s	v18, v18, #0x0
100245314:     	and.16b	v18, v18, v14
100245318:     	cmgt.16b	v22, v17, v12
10024531c:     	ushll.8h	v23, v22, #0x0
100245320:     	ushll.4s	v24, v23, #0x0
100245324:     	and.16b	v24, v24, v14
100245328:     	ushll2.4s	v23, v23, #0x0
10024532c:     	and.16b	v23, v23, v14
100245330:     	ushll2.8h	v22, v22, #0x0
100245334:     	ushll.4s	v25, v22, #0x0
100245338:     	and.16b	v25, v25, v14
10024533c:     	ushll2.4s	v22, v22, #0x0
100245340:     	and.16b	v22, v22, v14
100245344:     	cmhi.16b	v16, v16, v13
100245348:     	ushll2.8h	v26, v16, #0x0
10024534c:     	ushll2.4s	v27, v26, #0x0
100245350:     	and.16b	v27, v27, v14
100245354:     	ushll.4s	v26, v26, #0x0
100245358:     	and.16b	v26, v26, v14
10024535c:     	ushll.8h	v16, v16, #0x0
100245360:     	ushll2.4s	v28, v16, #0x0
100245364:     	and.16b	v28, v28, v14
100245368:     	ushll.4s	v16, v16, #0x0
10024536c:     	and.16b	v16, v16, v14
100245370:     	cmhi.16b	v17, v17, v13
100245374:     	ushll2.8h	v29, v17, #0x0
100245378:     	ushll2.4s	v30, v29, #0x0
10024537c:     	and.16b	v30, v30, v14
100245380:     	ushll.4s	v29, v29, #0x0
100245384:     	and.16b	v29, v29, v14
100245388:     	ushll.8h	v17, v17, #0x0
10024538c:     	ushll2.4s	v31, v17, #0x0
100245390:     	and.16b	v31, v31, v14
100245394:     	ushll.4s	v17, v17, #0x0
100245398:     	and.16b	v17, v17, v14
10024539c:     	add.4s	v1, v1, v16
1002453a0:     	add.4s	v3, v3, v28
1002453a4:     	add.4s	v0, v0, v26
1002453a8:     	add.4s	v2, v2, v27
1002453ac:     	add.4s	v7, v7, v17
1002453b0:     	add.4s	v6, v6, v31
1002453b4:     	add.4s	v4, v4, v29
1002453b8:     	add.4s	v5, v5, v30
1002453bc:     	add.4s	v2, v2, v18
1002453c0:     	add.4s	v0, v0, v21
1002453c4:     	add.4s	v3, v3, v19
1002453c8:     	add.4s	v1, v1, v20
1002453cc:     	add.4s	v5, v5, v22
1002453d0:     	add.4s	v4, v4, v25
1002453d4:     	add.4s	v6, v6, v23
1002453d8:     	add	x13, x13, #0x20
1002453dc:     	add.4s	v7, v7, v24
1002453e0:     	subs	x14, x14, #0x20
1002453e4:     	b.ne	0x1002452e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15b4>
1002453e8:     	add.4s	v3, v6, v3
1002453ec:     	add.4s	v2, v5, v2
1002453f0:     	add.4s	v1, v7, v1
1002453f4:     	add.4s	v0, v4, v0
1002453f8:     	add.4s	v0, v1, v0
1002453fc:     	add.4s	v1, v3, v2
100245400:     	add.4s	v0, v0, v1
100245404:     	addv.4s	s0, v0
100245408:     	fmov	w24, s0
10024540c:     	cmp	x10, x11
100245410:     	mov	x14, x27
100245414:     	b.eq	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100245418:     	cbz	x12, 0x100245488 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1754>
10024541c:     	mov	x8, #-0x7               ; =-7
100245420:     	movk	x8, #0x7fff, lsl #48
100245424:     	add	x8, x8, #0x43
100245428:     	and	x12, x2, x8
10024542c:     	add	x8, x9, x12
100245430:     	movi.2d	v0, #0000000000000000
100245434:     	mov.s	v0[0], w24
100245438:     	movi.4s	v3, #0x1
10024543c:     	ldr	s1, [x9, x11]
100245440:     	ushll.8h	v1, v1, #0x0
100245444:     	shl.4h	v2, v1, #0x8
100245448:     	sshr.4h	v2, v2, #0x8
10024544c:     	cmgt.4h	v2, v2, v10
100245450:     	ushll.4s	v2, v2, #0x0
100245454:     	and.16b	v2, v2, v3
100245458:     	cmhi.4h	v1, v1, v11
10024545c:     	ushll.4s	v1, v1, #0x0
100245460:     	and.16b	v1, v1, v3
100245464:     	add.4s	v0, v0, v1
100245468:     	add.4s	v0, v0, v2
10024546c:     	add	x11, x11, #0x4
100245470:     	cmp	x12, x11
100245474:     	b.ne	0x10024543c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1708>
100245478:     	addv.4s	s0, v0
10024547c:     	fmov	w24, s0
100245480:     	cmp	x10, x12
100245484:     	b.eq	0x1002454b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100245488:     	ldr	x9, [sp, #0x18]
10024548c:     	add	x9, x9, x2
100245490:     	ldrb	w10, [x8], #0x1
100245494:     	sxtb	w11, w10
100245498:     	cmp	w10, #0xef
10024549c:     	cinc	w10, w24, hi
1002454a0:     	cmn	w11, #0x41
1002454a4:     	cinc	w24, w10, gt
1002454a8:     	cmp	x8, x9
1002454ac:     	b.ne	0x100245490 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x175c>
1002454b0:     	lsr	w8, w2, #19
1002454b4:     	cbz	w8, 0x100245554 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1820>
1002454b8:     	mov	x27, x14
1002454bc:     	mov	w23, w2
1002454c0:     	add	x0, x23, #0x14
1002454c4:     	mov	w1, #0x3                ; =3
1002454c8:     	mov	x22, x2
1002454cc:     	bl	0x1004569c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
1002454d0:     	mov	x26, x0
1002454d4:     	stp	w24, w22, [x0]
1002454d8:     	str	w22, [x0, #0x8]
1002454dc:     	mov	x8, #0x200000000        ; =8589934592
1002454e0:     	stur	x8, [x0, #0xc]
1002454e4:     	add	x0, x0, #0x14
1002454e8:     	ldr	x24, [sp, #0x18]
1002454ec:     	mov	x1, x24
1002454f0:     	mov	x2, x22
1002454f4:     	bl	0x100b6076c <_writev+0x100b6076c>
1002454f8:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1002454fc:     	ldr	w22, [x8, #0x590]
100245500:     	cmp	w22, #0x300
100245504:     	b.hs	0x100245744 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a10>
100245508:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
10024550c:     	ldr	x8, [x8, #0x48]
100245510:     	cmn	x8, #0x1
100245514:     	b.eq	0x100245734 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a00>
100245518:     	mrs	x9, TPIDRRO_EL0
10024551c:     	and	x9, x9, #0xfffffffffffffff8
100245520:     	ldr	x0, [x9, x8, lsl #3]
100245524:     	cbz	x0, 0x100245734 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a00>
100245528:     	add	x8, x0, x22, lsl #3
10024552c:     	ldr	x0, [x8, #0x1e8]
100245530:     	cbz	x0, 0x100245744 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a10>
100245534:     	ldr	x8, [x0]
100245538:     	adds	x8, x8, x23
10024553c:     	csinv	x8, x8, xzr, lo
100245540:     	str	x8, [x0]
100245544:     	lsr	x8, x8, #25
100245548:     	cbz	x8, 0x1002455c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1890>
10024554c:     	bl	0x10045d8f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100245550:     	b	0x1002455c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1890>
100245554:     	ldur	x8, [x19, #0x20]
100245558:     	cbz	x8, 0x10024558c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1858>
10024555c:     	cmn	x2, #0x23
100245560:     	b.hs	0x10024558c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1858>
100245564:     	add	x8, x2, #0x23
100245568:     	mov	x9, #-0x8               ; =-8
10024556c:     	movk	x9, #0xf, lsl #16
100245570:     	and	x9, x8, x9
100245574:     	cmp	x9, #0x4, lsl #12       ; =0x4000
100245578:     	b.hi	0x10024558c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1858>
10024557c:     	add	x8, x2, #0x14
100245580:     	ldr	x10, [x19, #0x30]
100245584:     	ldrb	w10, [x10]
100245588:     	tbz	w10, #0x0, 0x1002456cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1998>
10024558c:     	mov	x27, x14
100245590:     	mov	x0, x2
100245594:     	mov	x22, x2
100245598:     	bl	0x1003497ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
10024559c:     	mov	x26, x0
1002455a0:     	mov	x0, x1
1002455a4:     	stp	w24, w22, [x26]
1002455a8:     	str	w22, [x26, #0x8]
1002455ac:     	mov	x8, #0x200000000        ; =8589934592
1002455b0:     	stur	x8, [x26, #0xc]
1002455b4:     	ldr	x24, [sp, #0x18]
1002455b8:     	mov	x1, x24
1002455bc:     	mov	x2, x22
1002455c0:     	bl	0x100b6076c <_writev+0x100b6076c>
1002455c4:     	ldr	x2, [sp, #0x20]
1002455c8:     	ldr	x1, [sp, #0x8]
1002455cc:     	add	x8, sp, #0x188
1002455d0:     	add	x0, x8, #0x30
1002455d4:     	bl	0x10028734c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
1002455d8:     	ldr	x22, [sp, #0x198]
1002455dc:     	ldr	x8, [sp, #0x188]
1002455e0:     	cmp	x22, x8
1002455e4:     	b.eq	0x1002456b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x197c>
1002455e8:     	ldr	x8, [sp, #0x190]
1002455ec:     	str	x26, [x8, x22, lsl #3]
1002455f0:     	add	x8, x22, #0x1
1002455f4:     	str	x8, [sp, #0x198]
1002455f8:     	ldr	x22, [sp, #0x1b0]
1002455fc:     	ldr	x8, [sp, #0x1a0]
100245600:     	cmp	x22, x8
100245604:     	b.eq	0x1002456bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1988>
100245608:     	ldr	x26, [sp, #0x1a8]
10024560c:     	ldr	x8, [sp, #0x10]
100245610:     	str	x8, [x26, x22, lsl #3]
100245614:     	add	x1, x22, #0x1
100245618:     	str	x1, [sp, #0x1b0]
10024561c:     	ldr	x22, [sp]
100245620:     	mov	x14, x27
100245624:     	ldr	w27, [sp, #0x78]
100245628:     	ldp	x23, x8, [x19, #0x68]
10024562c:     	cmp	x8, x23
100245630:     	str	x1, [sp, #0x20]
100245634:     	b.hs	0x100245664 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1930>
100245638:     	ldr	x9, [x19, #0x60]
10024563c:     	ldrb	w10, [x9, x8]
100245640:     	cmp	w10, #0x20
100245644:     	b.hi	0x100245664 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1930>
100245648:     	lsr	x10, x25, x10
10024564c:     	tbz	w10, #0x0, 0x100245664 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1930>
100245650:     	add	x8, x8, #0x1
100245654:     	str	x8, [x19, #0x70]
100245658:     	cmp	x23, x8
10024565c:     	b.ne	0x10024563c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1908>
100245660:     	b	0x100245a0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cd8>
100245664:     	cmp	x8, x23
100245668:     	b.hs	0x100245a0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cd8>
10024566c:     	ldr	x9, [x19, #0x60]
100245670:     	ldrb	w9, [x9, x8]
100245674:     	cmp	w9, #0x2c
100245678:     	b.ne	0x100245a0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cd8>
10024567c:     	add	x24, x8, #0x1
100245680:     	str	x24, [x19, #0x70]
100245684:     	cmp	x28, #0x1
100245688:     	ldr	x28, [sp, #0x90]
10024568c:     	b.lt	0x100243f24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1f0>
100245690:     	ldr	x0, [sp, #0x18]
100245694:     	mov	x23, x21
100245698:     	mov	x21, x14
10024569c:     	bl	0x100b5d8c0 <_mi_free>
1002456a0:     	mov	x14, x21
1002456a4:     	mov	x21, x23
1002456a8:     	ldp	x23, x24, [x19, #0x68]
1002456ac:     	b	0x100243f24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1f0>
1002456b0:     	add	x0, sp, #0x188
1002456b4:     	bl	0x100b3a5ac <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1002456b8:     	b	0x1002455e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x18b4>
1002456bc:     	add	x8, sp, #0x188
1002456c0:     	add	x0, x8, #0x18
1002456c4:     	bl	0x100b3a5ac <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1002456c8:     	b	0x100245608 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x18d4>
1002456cc:     	ldr	x10, [x19, #0x28]
1002456d0:     	ldp	x11, x12, [x10, #0x8]
1002456d4:     	add	x11, x11, #0x7
1002456d8:     	and	x11, x11, #0xfffffffffffffff8
1002456dc:     	subs	x12, x12, x11
1002456e0:     	csel	x12, xzr, x12, lo
1002456e4:     	mov	x27, x14
1002456e8:     	cmp	x9, x12
1002456ec:     	b.hi	0x100245590 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x185c>
1002456f0:     	ldr	x12, [x10]
1002456f4:     	add	x22, x12, x11
1002456f8:     	add	x11, x11, x9
1002456fc:     	str	x11, [x10, #0x8]
100245700:     	mov	w10, #0x203             ; =515
100245704:     	stp	w10, w9, [x22]
100245708:     	add	x26, x22, #0x8
10024570c:     	subs	x9, x9, #0x8
100245710:     	csel	x9, xzr, x9, lo
100245714:     	subs	x10, x9, x8
100245718:     	csel	x1, xzr, x10, lo
10024571c:     	b.ls	0x100245778 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a44>
100245720:     	cmp	x1, #0x9
100245724:     	b.hs	0x10024576c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a38>
100245728:     	add	x8, x26, x9
10024572c:     	stur	xzr, [x8, #-0x8]
100245730:     	b	0x100245778 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a44>
100245734:     	bl	0x100b3dcbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100245738:     	add	x8, x0, x22, lsl #3
10024573c:     	ldr	x0, [x8, #0x1e8]
100245740:     	cbnz	x0, 0x100245534 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1800>
100245744:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100245748:     	add	x0, x0, #0x78
10024574c:     	bl	0x100b3b4dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100245750:     	ldr	x8, [x0]
100245754:     	adds	x8, x8, x23
100245758:     	csinv	x8, x8, xzr, lo
10024575c:     	str	x8, [x0]
100245760:     	lsr	x8, x8, #25
100245764:     	cbnz	x8, 0x10024554c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1818>
100245768:     	b	0x1002455c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1890>
10024576c:     	add	x0, x26, x8
100245770:     	bl	0x100b602a4 <_writev+0x100b602a4>
100245774:     	ldr	x2, [sp, #0x28]
100245778:     	stp	w24, w2, [x22, #0x8]
10024577c:     	str	w2, [x22, #0x10]
100245780:     	mov	x8, #0x200000000        ; =8589934592
100245784:     	stur	x8, [x22, #0x14]
100245788:     	add	x0, x22, #0x1c
10024578c:     	ldr	x24, [sp, #0x18]
100245790:     	mov	x1, x24
100245794:     	b	0x1002455c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x188c>
100245798:     	adrp	x0, 0x10104d000 <_out_buf+0x3a48>
10024579c:     	add	x0, x0, #0x780
1002457a0:     	bl	0x100b20080 <__RINvMs1_NtNtCs4KWsSNcQanT_9once_cell4race8once_boxINtB6_7OnceBoxINtNtCsctvjasLqLe9_5alloc5boxed3BoxDNtNtCs3SoQS4yp3pP_5ahash12random_state12RandomSourceNtNtCsjgY6bXVaRmE_4core6marker4SendNtB2s_4SyncEL_EE4initNtNvMs1_B6_IBN_pE11get_or_init4VoidNCINvB2_11get_or_initNCNvB1C_7get_src0E0ECs3gRpqoBkMHm_13perry_runtime>
1002457a4:     	ldp	x0, x22, [x0]
1002457a8:     	adrp	x8, 0x10104d000 <_out_buf+0x3a48>
1002457ac:     	add	x8, x8, #0x788
1002457b0:     	ldapr	x24, [x8]
1002457b4:     	cbnz	x24, 0x100244200 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x4cc>
1002457b8:     	mov	x26, x0
1002457bc:     	adrp	x0, 0x10104d000 <_out_buf+0x3a48>
1002457c0:     	add	x0, x0, #0x788
1002457c4:     	bl	0x100b1ffc0 <__RINvMs1_NtNtCs4KWsSNcQanT_9once_cell4race8once_boxINtB6_7OnceBoxAAyj4_j2_E4initNtNvMs1_B6_IBN_pE11get_or_init4VoidNCINvB2_11get_or_initNCNvNtCs3SoQS4yp3pP_5ahash12random_state15get_fixed_seeds0E0ECs3gRpqoBkMHm_13perry_runtime>
1002457c8:     	mov	x24, x0
1002457cc:     	mov	x0, x26
1002457d0:     	mov	x26, #0x7f2d            ; =32557
1002457d4:     	movk	x26, #0x4c95, lsl #16
1002457d8:     	movk	x26, #0xf42d, lsl #32
1002457dc:     	movk	x26, #0x5851, lsl #48
1002457e0:     	b	0x100244200 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x4cc>
1002457e4:     	strb	wzr, [x19, #0xd4]
1002457e8:     	cmp	x28, #0x1
1002457ec:     	b.lt	0x1002457f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ac4>
1002457f0:     	mov	x0, x24
1002457f4:     	bl	0x100b5d8c0 <_mi_free>
1002457f8:     	ldr	x14, [sp, #0x90]
1002457fc:     	ldp	x9, x8, [x19, #0x68]
100245800:     	cmp	x8, x9
100245804:     	b.hs	0x10024588c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b58>
100245808:     	ldr	x10, [x19, #0x60]
10024580c:     	mov	x11, #0x2600            ; =9728
100245810:     	movk	x11, #0x1, lsl #32
100245814:     	ldrb	w12, [x10, x8]
100245818:     	cmp	w12, #0x20
10024581c:     	b.hi	0x10024583c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b08>
100245820:     	lsr	x13, x11, x12
100245824:     	tbz	w13, #0x0, 0x10024583c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b08>
100245828:     	add	x8, x8, #0x1
10024582c:     	str	x8, [x19, #0x70]
100245830:     	cmp	x9, x8
100245834:     	b.ne	0x100245814 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ae0>
100245838:     	b	0x10024588c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b58>
10024583c:     	cmp	w12, #0x7d
100245840:     	b.ne	0x10024588c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b58>
100245844:     	add	x8, x8, #0x1
100245848:     	str	x8, [x19, #0x70]
10024584c:     	ldr	x8, [sp, #0x188]
100245850:     	cmn	x8, #0x1
100245854:     	b.ne	0x10024589c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b68>
100245858:     	ldr	w8, [sp, #0x9c]
10024585c:     	ldr	w9, [sp, #0x80]
100245860:     	and	w8, w8, w9
100245864:     	tbz	w8, #0x0, 0x100245948 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c14>
100245868:     	ldr	x8, [sp, #0x70]
10024586c:     	cmp	x14, x8
100245870:     	b.ne	0x100245948 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c14>
100245874:     	cmp	x27, x14
100245878:     	b.ne	0x100245948 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c14>
10024587c:     	cmp	x22, #0x9
100245880:     	ldr	w2, [sp, #0x64]
100245884:     	b.lo	0x100245a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d10>
100245888:     	b	0x100245910 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1bdc>
10024588c:     	strb	wzr, [x19, #0xd4]
100245890:     	ldr	x8, [sp, #0x188]
100245894:     	cmn	x8, #0x1
100245898:     	b.eq	0x100245858 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b24>
10024589c:     	ldp	x0, x1, [sp, #0x190]
1002458a0:     	cmp	x1, #0x9
1002458a4:     	b.hs	0x100245928 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1bf4>
1002458a8:     	ldr	x8, [x19, #0x78]
1002458ac:     	cmp	x1, x8
1002458b0:     	b.ne	0x1002458d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
1002458b4:     	ldr	x21, [x19, #0xc0]
1002458b8:     	cbz	x21, 0x1002458d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
1002458bc:     	cbz	x1, 0x100245a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
1002458c0:     	ldr	x8, [x19, #0x80]
1002458c4:     	ldr	x9, [x0]
1002458c8:     	cmp	x8, x9
1002458cc:     	b.eq	0x100245a1c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ce8>
1002458d0:     	mov	x24, x0
1002458d4:     	mov	x25, x1
1002458d8:     	bl	0x100327f5c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
1002458dc:     	mov	x21, x0
1002458e0:     	mov	x23, x1
1002458e4:     	str	x25, [x19, #0x78]
1002458e8:     	lsl	x2, x25, #3
1002458ec:     	add	x0, x19, #0x80
1002458f0:     	mov	x1, x24
1002458f4:     	bl	0x100b6076c <_writev+0x100b6076c>
1002458f8:     	mov	x2, x23
1002458fc:     	str	x21, [x19, #0xc0]
100245900:     	str	w23, [x19, #0xd0]
100245904:     	cmp	x22, #0x9
100245908:     	ldr	x8, [sp, #0x20]
10024590c:     	b.lo	0x100245940 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c0c>
100245910:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245914:     	add	x3, x3, #0x710
100245918:     	mov	x0, #0x0                ; =0
10024591c:     	mov	x1, x22
100245920:     	mov	w2, #0x8                ; =8
100245924:     	bl	0x100b1130c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245928:     	bl	0x100327f5c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
10024592c:     	mov	x21, x0
100245930:     	mov	x2, x1
100245934:     	cmp	x22, #0x9
100245938:     	ldr	x8, [sp, #0x20]
10024593c:     	b.hs	0x100245910 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1bdc>
100245940:     	mov	x22, x8
100245944:     	b	0x100245a48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d14>
100245948:     	cmp	x22, #0x9
10024594c:     	b.hs	0x100245ccc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1f98>
100245950:     	ldr	x8, [x19, #0x78]
100245954:     	cmp	x22, x8
100245958:     	b.ne	0x100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
10024595c:     	ldr	x21, [x19, #0xc0]
100245960:     	cbz	x21, 0x100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245964:     	cbz	x22, 0x100245a40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245968:     	ldr	x8, [x19, #0x80]
10024596c:     	ldr	x9, [sp, #0x100]
100245970:     	cmp	x8, x9
100245974:     	b.eq	0x100245a38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d04>
100245978:     	add	x0, sp, #0x100
10024597c:     	mov	x1, x22
100245980:     	bl	0x100327f5c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100245984:     	mov	x21, x0
100245988:     	mov	x23, x1
10024598c:     	str	x22, [x19, #0x78]
100245990:     	lsl	x2, x22, #3
100245994:     	add	x0, x19, #0x80
100245998:     	add	x1, sp, #0x100
10024599c:     	bl	0x100b6076c <_writev+0x100b6076c>
1002459a0:     	mov	x2, x23
1002459a4:     	str	x21, [x19, #0xc0]
1002459a8:     	str	w23, [x19, #0xd0]
1002459ac:     	b	0x100245a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d10>
1002459b0:     	b	0x100243e28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf4>
1002459b4:     	sub	x0, x29, #0xa8
1002459b8:     	mov	x1, #0x0                ; =0
1002459bc:     	bl	0x100327f5c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
1002459c0:     	mov	x2, x1
1002459c4:     	mov	x1, x0
1002459c8:     	str	xzr, [x19, #0x78]
1002459cc:     	str	x0, [x19, #0xc0]
1002459d0:     	str	w2, [x19, #0xd0]
1002459d4:     	add	x0, x19, #0x20
1002459d8:     	mov	w3, #0x8                ; =8
1002459dc:     	mov	x4, #0x0                ; =0
1002459e0:     	bl	0x1005bac48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
1002459e4:     	mov	x19, x0
1002459e8:     	ldrb	w8, [x20, #0x20]
1002459ec:     	cbnz	w8, 0x100245ce4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1fb0>
1002459f0:     	ldr	x8, [x20]
1002459f4:     	cbnz	x8, 0x100245d2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ff8>
1002459f8:     	ldr	x8, [x20, #0x18]
1002459fc:     	cmp	x27, x8
100245a00:     	b.hi	0x100245aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1db8>
100245a04:     	str	x27, [x20, #0x18]
100245a08:     	b	0x100245aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1db8>
100245a0c:     	mov	x27, x14
100245a10:     	cmp	x28, #0x1
100245a14:     	b.ge	0x1002457f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1abc>
100245a18:     	b	0x1002457f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ac4>
100245a1c:     	cmp	x1, #0x1
100245a20:     	b.ne	0x100245b24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1df0>
100245a24:     	ldr	w2, [x19, #0xd0]
100245a28:     	cmp	x22, #0x9
100245a2c:     	ldr	x8, [sp, #0x20]
100245a30:     	b.lo	0x100245940 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c0c>
100245a34:     	b	0x100245910 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1bdc>
100245a38:     	cmp	x22, #0x1
100245a3c:     	b.ne	0x100245bc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1e94>
100245a40:     	ldr	w2, [x19, #0xd0]
100245a44:     	add	x26, sp, #0x148
100245a48:     	add	x0, x19, #0x20
100245a4c:     	mov	x1, x21
100245a50:     	mov	x3, x26
100245a54:     	mov	x4, x22
100245a58:     	bl	0x1005bac48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100245a5c:     	mov	x19, x0
100245a60:     	ldrb	w8, [x20, #0x20]
100245a64:     	ldr	x21, [sp, #0x88]
100245a68:     	cbnz	w8, 0x100245ca4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1f70>
100245a6c:     	ldr	x8, [x20]
100245a70:     	cbnz	x8, 0x100245d2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ff8>
100245a74:     	ldr	x8, [x20, #0x18]
100245a78:     	cmp	x21, x8
100245a7c:     	b.hi	0x100245a84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d50>
100245a80:     	str	x21, [x20, #0x18]
100245a84:     	ldr	x8, [sp, #0x188]
100245a88:     	cmn	x8, #0x1
100245a8c:     	b.eq	0x100245aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1db8>
100245a90:     	cbz	x8, 0x100245a9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d68>
100245a94:     	ldr	x0, [sp, #0x190]
100245a98:     	bl	0x100b5d8c0 <_mi_free>
100245a9c:     	ldr	x8, [sp, #0x1a0]
100245aa0:     	cbz	x8, 0x100245aac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d78>
100245aa4:     	ldr	x0, [sp, #0x1a8]
100245aa8:     	bl	0x100b5d8c0 <_mi_free>
100245aac:     	ldr	x20, [sp, #0x1b8]
100245ab0:     	cmn	x20, #0x1
100245ab4:     	b.eq	0x100245aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1db8>
100245ab8:     	ldr	x9, [sp, #0x1d8]
100245abc:     	cbz	x9, 0x100245ae0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1dac>
100245ac0:     	lsl	x8, x9, #4
100245ac4:     	add	x9, x8, x9
100245ac8:     	cmn	x9, #0x19
100245acc:     	b.eq	0x100245ae0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1dac>
100245ad0:     	ldr	x9, [sp, #0x1d0]
100245ad4:     	sub	x8, x9, x8
100245ad8:     	sub	x0, x8, #0x10
100245adc:     	bl	0x100b5d8c0 <_mi_free>
100245ae0:     	cbz	x20, 0x100245aec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1db8>
100245ae4:     	ldr	x0, [sp, #0x1c0]
100245ae8:     	bl	0x100b5d8c0 <_mi_free>
100245aec:     	mov	x0, #0x7ffd000000000000 ; =9222527611924643840
100245af0:     	bfxil	x0, x19, #0, #48
100245af4:     	add	sp, sp, #0x2e0
100245af8:     	ldp	x29, x30, [sp, #0x90]
100245afc:     	ldp	x20, x19, [sp, #0x80]
100245b00:     	ldp	x22, x21, [sp, #0x70]
100245b04:     	ldp	x24, x23, [sp, #0x60]
100245b08:     	ldp	x26, x25, [sp, #0x50]
100245b0c:     	ldp	x28, x27, [sp, #0x40]
100245b10:     	ldp	d9, d8, [sp, #0x30]
100245b14:     	ldp	d11, d10, [sp, #0x20]
100245b18:     	ldp	d13, d12, [sp, #0x10]
100245b1c:     	ldp	d15, d14, [sp], #0xa0
100245b20:     	ret
100245b24:     	ldr	x8, [x19, #0x88]
100245b28:     	ldr	x9, [x0, #0x8]
100245b2c:     	cmp	x8, x9
100245b30:     	b.ne	0x1002458d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245b34:     	cmp	x1, #0x2
100245b38:     	b.eq	0x100245a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245b3c:     	ldr	x8, [x19, #0x90]
100245b40:     	ldr	x9, [x0, #0x10]
100245b44:     	cmp	x8, x9
100245b48:     	b.ne	0x1002458d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245b4c:     	cmp	x1, #0x3
100245b50:     	b.eq	0x100245a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245b54:     	ldr	x8, [x19, #0x98]
100245b58:     	ldr	x9, [x0, #0x18]
100245b5c:     	cmp	x8, x9
100245b60:     	b.ne	0x1002458d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245b64:     	cmp	x1, #0x4
100245b68:     	b.eq	0x100245a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245b6c:     	ldr	x8, [x19, #0xa0]
100245b70:     	ldr	x9, [x0, #0x20]
100245b74:     	cmp	x8, x9
100245b78:     	b.ne	0x1002458d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245b7c:     	cmp	x1, #0x5
100245b80:     	b.eq	0x100245a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245b84:     	ldr	x8, [x19, #0xa8]
100245b88:     	ldr	x9, [x0, #0x28]
100245b8c:     	cmp	x8, x9
100245b90:     	b.ne	0x1002458d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245b94:     	cmp	x1, #0x6
100245b98:     	b.eq	0x100245a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245b9c:     	ldr	x8, [x19, #0xb0]
100245ba0:     	ldr	x9, [x0, #0x30]
100245ba4:     	cmp	x8, x9
100245ba8:     	b.ne	0x1002458d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245bac:     	cmp	x1, #0x7
100245bb0:     	b.eq	0x100245a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245bb4:     	ldr	x8, [x19, #0xb8]
100245bb8:     	ldr	x9, [x0, #0x38]
100245bbc:     	cmp	x8, x9
100245bc0:     	b.ne	0x1002458d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245bc4:     	b	0x100245a24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245bc8:     	ldr	x8, [x19, #0x88]
100245bcc:     	ldr	x9, [sp, #0x108]
100245bd0:     	cmp	x8, x9
100245bd4:     	b.ne	0x100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245bd8:     	cmp	x22, #0x2
100245bdc:     	b.eq	0x100245a40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245be0:     	ldr	x8, [x19, #0x90]
100245be4:     	ldr	x9, [sp, #0x110]
100245be8:     	cmp	x8, x9
100245bec:     	b.ne	0x100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245bf0:     	cmp	x22, #0x3
100245bf4:     	b.eq	0x100245a40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245bf8:     	ldr	x8, [x19, #0x98]
100245bfc:     	ldr	x9, [sp, #0x118]
100245c00:     	cmp	x8, x9
100245c04:     	b.ne	0x100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245c08:     	cmp	x22, #0x4
100245c0c:     	b.eq	0x100245a40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245c10:     	ldr	x8, [x19, #0xa0]
100245c14:     	ldr	x9, [sp, #0x120]
100245c18:     	cmp	x8, x9
100245c1c:     	b.ne	0x100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245c20:     	cmp	x22, #0x5
100245c24:     	b.eq	0x100245a40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245c28:     	ldr	x8, [x19, #0xa8]
100245c2c:     	ldr	x9, [sp, #0x128]
100245c30:     	cmp	x8, x9
100245c34:     	b.ne	0x100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245c38:     	cmp	x22, #0x6
100245c3c:     	b.eq	0x100245a40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245c40:     	ldr	x8, [x19, #0xb0]
100245c44:     	ldr	x9, [sp, #0x130]
100245c48:     	cmp	x8, x9
100245c4c:     	b.ne	0x100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245c50:     	cmp	x22, #0x7
100245c54:     	b.eq	0x100245a40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245c58:     	ldr	x8, [x19, #0xb8]
100245c5c:     	ldr	x9, [sp, #0x138]
100245c60:     	cmp	x8, x9
100245c64:     	b.ne	0x100245978 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245c68:     	b	0x100245a40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245c6c:     	cmp	w8, #0x1
100245c70:     	b.ne	0x100245cec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1fb8>
100245c74:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1a_14perf_histogram9HistogramEEKj1_EEB1a_+0x48>
100245c78:     	add	x1, x1, #0xcd8
100245c7c:     	mov	x0, x20
100245c80:     	bl	0x100a1ed1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100245c84:     	strb	wzr, [x20, #0x20]
100245c88:     	ldr	x8, [x20]
100245c8c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100245c90:     	cmp	x8, x9
100245c94:     	b.lo	0x100243e58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x124>
100245c98:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100245c9c:     	add	x0, x0, #0x4a0
100245ca0:     	bl	0x100b1101c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100245ca4:     	cmp	w8, #0x2
100245ca8:     	b.eq	0x100245cec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1fb8>
100245cac:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1a_14perf_histogram9HistogramEEKj1_EEB1a_+0x48>
100245cb0:     	add	x1, x1, #0xcd8
100245cb4:     	mov	x0, x20
100245cb8:     	bl	0x100a1ed1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100245cbc:     	strb	wzr, [x20, #0x20]
100245cc0:     	ldr	x8, [x20]
100245cc4:     	cbz	x8, 0x100245a74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d40>
100245cc8:     	b	0x100245d2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ff8>
100245ccc:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245cd0:     	add	x3, x3, #0x6f8
100245cd4:     	mov	x0, #0x0                ; =0
100245cd8:     	mov	x1, x22
100245cdc:     	mov	w2, #0x8                ; =8
100245ce0:     	bl	0x100b1130c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245ce4:     	cmp	w8, #0x2
100245ce8:     	b.ne	0x100245d10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1fdc>
100245cec:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100245cf0:     	add	x0, x0, #0xc18
100245cf4:     	bl	0x100b56f1c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100245cf8:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245cfc:     	add	x3, x3, #0x6b0
100245d00:     	mov	x0, #0x0                ; =0
100245d04:     	mov	x1, x22
100245d08:     	mov	w2, #0x8                ; =8
100245d0c:     	bl	0x100b1130c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245d10:     	adrp	x1, 0x100190000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtB1a_14perf_histogram9HistogramEEKj1_EEB1a_+0x48>
100245d14:     	add	x1, x1, #0xcd8
100245d18:     	mov	x0, x20
100245d1c:     	bl	0x100a1ed1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100245d20:     	strb	wzr, [x20, #0x20]
100245d24:     	ldr	x8, [x20]
100245d28:     	cbz	x8, 0x1002459f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cc4>
100245d2c:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100245d30:     	add	x0, x0, #0x488
100245d34:     	bl	0x100b10fec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100245d38:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245d3c:     	add	x0, x0, #0x668
100245d40:     	bl	0x100b110b0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100245d44:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100245d48:     	add	x2, x2, #0x800
100245d4c:     	mov	x0, x14
100245d50:     	mov	w1, #0x8                ; =8
100245d54:     	bl	0x100b1114c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245d58:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100245d5c:     	add	x2, x2, #0xab8
100245d60:     	mov	x0, x24
100245d64:     	bl	0x100b1114c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245d68:     	adrp	x2, 0x100f02000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x10ed0>
100245d6c:     	add	x2, x2, #0x320
100245d70:     	mov	x0, x24
100245d74:     	bl	0x100b1114c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245d78:     	mov	w0, #0x8                ; =8
100245d7c:     	mov	w1, #0x1108             ; =4360
100245d80:     	bl	0x100b10c28 <__RNvNtCsctvjasLqLe9_5alloc5alloc18handle_alloc_error>
100245d84:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245d88:     	add	x2, x2, #0x6e0
100245d8c:     	mov	x0, x24
100245d90:     	bl	0x100b1114c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245d94:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245d98:     	add	x2, x2, #0x6c8
100245d9c:     	mov	x0, x24
100245da0:     	bl	0x100b1114c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245da4:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245da8:     	add	x2, x2, #0x698
100245dac:     	mov	x0, x14
100245db0:     	mov	w1, #0x8                ; =8
100245db4:     	bl	0x100b1114c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245db8:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245dbc:     	add	x2, x2, #0x680
100245dc0:     	mov	x0, x14
100245dc4:     	mov	w1, #0x8                ; =8
100245dc8:     	bl	0x100b1114c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245dcc:     	mov	w0, #0x8                ; =8
100245dd0:     	mov	w1, #0x80               ; =128
100245dd4:     	bl	0x100b10c40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
