
benchmarks/json_performance/.work/parse-regression-r35-profiles/r35-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100243228 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value>:
100243228:     	sub	sp, sp, #0x80
10024322c:     	stp	x26, x25, [sp, #0x30]
100243230:     	stp	x24, x23, [sp, #0x40]
100243234:     	stp	x22, x21, [sp, #0x50]
100243238:     	stp	x20, x19, [sp, #0x60]
10024323c:     	stp	x29, x30, [sp, #0x70]
100243240:     	add	x29, sp, #0x70
100243244:     	mov	x21, x0
100243248:     	ldr	x25, [x0, #0x70]
10024324c:     	ldp	x8, x9, [x0]
100243250:     	cmp	x8, #0x0
100243254:     	ccmp	x9, x25, #0x0, ne
100243258:     	b.eq	0x100243284 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x5c>
10024325c:     	mov	x0, sp
100243260:     	mov	x1, x21
100243264:     	bl	0x100242cb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
100243268:     	ldr	x24, [sp]
10024326c:     	cmn	x24, #0x2
100243270:     	b.ne	0x100243298 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x70>
100243274:     	strb	wzr, [x21, #0xd4]
100243278:     	mov	x0, #0x2                ; =2
10024327c:     	movk	x0, #0x7ffc, lsl #48
100243280:     	b	0x100243368 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x140>
100243284:     	ldp	x8, x9, [x21, #0x10]
100243288:     	str	x8, [x21, #0x70]
10024328c:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100243290:     	bfxil	x0, x9, #0, #48
100243294:     	b	0x100243368 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x140>
100243298:     	ldp	x19, x20, [sp, #0x8]
10024329c:     	cmp	x20, #0x6
1002432a0:     	b.hs	0x100243330 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x108>
1002432a4:     	subs	x8, x20, #0x3
1002432a8:     	b.lo	0x100243384 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x15c>
1002432ac:     	ldrb	w9, [x19]
1002432b0:     	cmp	w9, #0xed
1002432b4:     	b.ne	0x1002432d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xac>
1002432b8:     	ldrb	w9, [x19, #0x1]
1002432bc:     	and	w9, w9, #0xe0
1002432c0:     	cmp	w9, #0xa0
1002432c4:     	b.ne	0x1002432d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xac>
1002432c8:     	ldrsb	w9, [x19, #0x2]
1002432cc:     	cmn	w9, #0x40
1002432d0:     	b.lt	0x100243330 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x108>
1002432d4:     	cbz	x8, 0x100243384 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x15c>
1002432d8:     	ldrb	w9, [x19, #0x1]
1002432dc:     	cmp	w9, #0xed
1002432e0:     	b.ne	0x100243300 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xd8>
1002432e4:     	ldrb	w9, [x19, #0x2]
1002432e8:     	and	w9, w9, #0xe0
1002432ec:     	cmp	w9, #0xa0
1002432f0:     	b.ne	0x100243300 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xd8>
1002432f4:     	ldrsb	w9, [x19, #0x3]
1002432f8:     	cmn	w9, #0x40
1002432fc:     	b.lt	0x100243330 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x108>
100243300:     	cmp	x8, #0x1
100243304:     	b.eq	0x100243384 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x15c>
100243308:     	ldrb	w8, [x19, #0x2]
10024330c:     	cmp	w8, #0xed
100243310:     	b.ne	0x100243384 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x15c>
100243314:     	ldrb	w8, [x19, #0x3]
100243318:     	and	w8, w8, #0xe0
10024331c:     	cmp	w8, #0xa0
100243320:     	b.ne	0x100243384 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x15c>
100243324:     	ldrsb	w8, [x19, #0x4]
100243328:     	cmn	w8, #0x40
10024332c:     	b.ge	0x100243384 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x15c>
100243330:     	cmn	x24, #0x1
100243334:     	b.eq	0x1002433a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x178>
100243338:     	mov	x0, x19
10024333c:     	mov	x1, x20
100243340:     	bl	0x100349e30 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
100243344:     	mov	x23, x0
100243348:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
10024334c:     	bfxil	x0, x23, #0, #48
100243350:     	cmp	x24, #0x1
100243354:     	b.lt	0x100243368 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x140>
100243358:     	mov	x20, x0
10024335c:     	mov	x0, x19
100243360:     	bl	0x100b5d8c0 <_mi_free>
100243364:     	mov	x0, x20
100243368:     	ldp	x29, x30, [sp, #0x70]
10024336c:     	ldp	x20, x19, [sp, #0x60]
100243370:     	ldp	x22, x21, [sp, #0x50]
100243374:     	ldp	x24, x23, [sp, #0x40]
100243378:     	ldp	x26, x25, [sp, #0x30]
10024337c:     	add	sp, sp, #0x80
100243380:     	ret
100243384:     	cbz	x20, 0x1002434d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2b0>
100243388:     	cmp	x20, #0x4
10024338c:     	b.hs	0x1002434e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2b8>
100243390:     	mov	x10, #0x0               ; =0
100243394:     	mov	x9, #0x0                ; =0
100243398:     	mov	x8, x19
10024339c:     	b	0x100243570 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x348>
1002433a0:     	cmp	x20, #0x40
1002433a4:     	b.hs	0x1002435a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x380>
1002433a8:     	ands	x8, x20, #0x38
1002433ac:     	b.eq	0x1002433d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1a8>
1002433b0:     	and	x9, x20, #0x38
1002433b4:     	neg	x9, x9
1002433b8:     	mov	x10, x19
1002433bc:     	ldr	x11, [x10], #0x8
1002433c0:     	tst	x11, #0x8080808080808080
1002433c4:     	b.ne	0x100243464 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x23c>
1002433c8:     	adds	x9, x9, #0x8
1002433cc:     	b.ne	0x1002433bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x194>
1002433d0:     	mov	x22, x20
1002433d4:     	and	x9, x20, #0x7
1002433d8:     	cbz	x9, 0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
1002433dc:     	add	x8, x19, x8
1002433e0:     	ldrsb	w10, [x8]
1002433e4:     	tbnz	w10, #0x1f, 0x100243464 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x23c>
1002433e8:     	mov	x22, x20
1002433ec:     	cmp	x9, #0x1
1002433f0:     	b.eq	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
1002433f4:     	ldrsb	w10, [x8, #0x1]
1002433f8:     	tbnz	w10, #0x1f, 0x100243464 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x23c>
1002433fc:     	mov	x22, x20
100243400:     	cmp	x9, #0x2
100243404:     	b.eq	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
100243408:     	ldrsb	w10, [x8, #0x2]
10024340c:     	tbnz	w10, #0x1f, 0x100243464 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x23c>
100243410:     	mov	x22, x20
100243414:     	cmp	x9, #0x3
100243418:     	b.eq	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
10024341c:     	ldrsb	w10, [x8, #0x3]
100243420:     	tbnz	w10, #0x1f, 0x100243464 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x23c>
100243424:     	mov	x22, x20
100243428:     	cmp	x9, #0x4
10024342c:     	b.eq	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
100243430:     	ldrsb	w10, [x8, #0x4]
100243434:     	tbnz	w10, #0x1f, 0x100243464 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x23c>
100243438:     	mov	x22, x20
10024343c:     	cmp	x9, #0x5
100243440:     	b.eq	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
100243444:     	ldrsb	w10, [x8, #0x5]
100243448:     	tbnz	w10, #0x1f, 0x100243464 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x23c>
10024344c:     	mov	x22, x20
100243450:     	cmp	x9, #0x6
100243454:     	b.eq	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
100243458:     	ldrsb	w8, [x8, #0x6]
10024345c:     	mov	x22, x20
100243460:     	tbz	w8, #0x1f, 0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
100243464:     	cbz	w20, 0x100243634 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x40c>
100243468:     	mov	x22, x20
10024346c:     	mov	w23, w20
100243470:     	cbz	x23, 0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
100243474:     	mov	x8, x19
100243478:     	ands	x9, x20, #0x3
10024347c:     	b.eq	0x100243498 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x270>
100243480:     	mov	x8, x19
100243484:     	ldrsb	w10, [x8]
100243488:     	tbnz	w10, #0x1f, 0x100243644 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x41c>
10024348c:     	add	x8, x8, #0x1
100243490:     	subs	x9, x9, #0x1
100243494:     	b.ne	0x100243484 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x25c>
100243498:     	mov	x22, x20
10024349c:     	cmp	x23, #0x4
1002434a0:     	b.lo	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
1002434a4:     	add	x9, x19, x23
1002434a8:     	ldrsb	w10, [x8]
1002434ac:     	tbnz	w10, #0x1f, 0x100243644 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x41c>
1002434b0:     	ldrsb	w10, [x8, #0x1]
1002434b4:     	tbnz	w10, #0x1f, 0x100243644 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x41c>
1002434b8:     	ldrsb	w10, [x8, #0x2]
1002434bc:     	tbnz	w10, #0x1f, 0x100243644 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x41c>
1002434c0:     	ldrsb	w10, [x8, #0x3]
1002434c4:     	tbnz	w10, #0x1f, 0x100243644 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x41c>
1002434c8:     	add	x8, x8, #0x4
1002434cc:     	cmp	x8, x9
1002434d0:     	b.ne	0x1002434a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x280>
1002434d4:     	b	0x10024362c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x404>
1002434d8:     	mov	x10, #0x0               ; =0
1002434dc:     	b	0x100243590 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x368>
1002434e0:     	and	x9, x20, #0x4
1002434e4:     	add	x8, x19, x9
1002434e8:     	adrp	x10, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5530>
1002434ec:     	ldr	q0, [x10, #0x340]
1002434f0:     	adrp	x10, 0x100c38000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33d3a>
1002434f4:     	ldr	q2, [x10, #0x240]
1002434f8:     	movi.2d	v1, #0000000000000000
1002434fc:     	movi.2d	v3, #0x000000000000ff
100243500:     	mov	w10, #0x4               ; =4
100243504:     	dup.2d	v4, x10
100243508:     	mov	x10, x19
10024350c:     	and	x11, x20, #0x4
100243510:     	movi.2d	v5, #0000000000000000
100243514:     	ldr	s6, [x10], #0x4
100243518:     	ushll.8h	v6, v6, #0x0
10024351c:     	ushll.4s	v6, v6, #0x0
100243520:     	ushll2.2d	v7, v6, #0x0
100243524:     	and.16b	v7, v7, v3
100243528:     	ushll.2d	v6, v6, #0x0
10024352c:     	and.16b	v6, v6, v3
100243530:     	shl.2d	v16, v0, #0x3
100243534:     	shl.2d	v17, v2, #0x3
100243538:     	ushl.2d	v6, v6, v17
10024353c:     	ushl.2d	v7, v7, v16
100243540:     	orr.16b	v1, v7, v1
100243544:     	orr.16b	v5, v6, v5
100243548:     	add.2d	v0, v0, v4
10024354c:     	add.2d	v2, v2, v4
100243550:     	subs	x11, x11, #0x4
100243554:     	b.ne	0x100243514 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2ec>
100243558:     	orr.16b	v0, v5, v1
10024355c:     	mov	d1, v0[1]
100243560:     	orr.8b	v0, v0, v1
100243564:     	fmov	x10, d0
100243568:     	cmp	x20, x9
10024356c:     	b.eq	0x100243590 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x368>
100243570:     	add	x11, x19, x20
100243574:     	lsl	x9, x9, #3
100243578:     	ldrb	w12, [x8], #0x1
10024357c:     	lsl	x12, x12, x9
100243580:     	orr	x10, x12, x10
100243584:     	add	x9, x9, #0x8
100243588:     	cmp	x8, x11
10024358c:     	b.ne	0x100243578 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x350>
100243590:     	orr	x8, x10, x20, lsl #40
100243594:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100243598:     	orr	x0, x8, x9
10024359c:     	cmp	x24, #0x1
1002435a0:     	b.ge	0x100243358 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x130>
1002435a4:     	b	0x100243368 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x140>
1002435a8:     	and	x8, x20, #0x7fffffffffffffc0
1002435ac:     	add	x8, x19, x8
1002435b0:     	mov	x9, x19
1002435b4:     	ldp	q0, q1, [x9]
1002435b8:     	ldp	q2, q3, [x9, #0x20]
1002435bc:     	orr.16b	v0, v1, v0
1002435c0:     	orr.16b	v1, v2, v3
1002435c4:     	orr.16b	v0, v0, v1
1002435c8:     	umaxv.16b	b0, v0
1002435cc:     	fmov	w10, s0
1002435d0:     	tbnz	w10, #0x7, 0x100243464 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x23c>
1002435d4:     	add	x9, x9, #0x40
1002435d8:     	cmp	x9, x8
1002435dc:     	b.ne	0x1002435b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x38c>
1002435e0:     	ands	x9, x20, #0x30
1002435e4:     	b.eq	0x100243608 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3e0>
1002435e8:     	mov	x10, x9
1002435ec:     	mov	x11, x8
1002435f0:     	ldr	q0, [x11], #0x10
1002435f4:     	umaxv.16b	b0, v0
1002435f8:     	fmov	w12, s0
1002435fc:     	tbnz	w12, #0x7, 0x100243464 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x23c>
100243600:     	subs	x10, x10, #0x10
100243604:     	b.ne	0x1002435f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3c8>
100243608:     	mov	x22, x20
10024360c:     	and	x10, x20, #0xf
100243610:     	cbz	x10, 0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
100243614:     	add	x8, x8, x9
100243618:     	ldrsb	w9, [x8]
10024361c:     	tbnz	w9, #0x1f, 0x100243464 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x23c>
100243620:     	add	x8, x8, #0x1
100243624:     	subs	x10, x10, #0x1
100243628:     	b.ne	0x100243618 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3f0>
10024362c:     	mov	x22, x20
100243630:     	b	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
100243634:     	mov	w22, #0x0               ; =0
100243638:     	mov	w8, #0x14               ; =20
10024363c:     	orr	x8, x20, x8
100243640:     	b	0x100243704 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x4dc>
100243644:     	cmp	w20, #0x3f
100243648:     	b.ls	0x10024378c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x564>
10024364c:     	mov	x0, x19
100243650:     	mov	x1, x23
100243654:     	bl	0x1005e8da0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
100243658:     	mov	x22, x0
10024365c:     	lsr	w8, w20, #19
100243660:     	cbz	w8, 0x100243700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x4d8>
100243664:     	mov	w26, w20
100243668:     	add	x0, x26, #0x14
10024366c:     	mov	w1, #0x3                ; =3
100243670:     	bl	0x1004569c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
100243674:     	mov	x23, x0
100243678:     	stp	w22, w20, [x0]
10024367c:     	str	w20, [x0, #0x8]
100243680:     	mov	x8, #0x200000000        ; =8589934592
100243684:     	stur	x8, [x0, #0xc]
100243688:     	add	x0, x0, #0x14
10024368c:     	mov	x1, x19
100243690:     	mov	x2, x20
100243694:     	bl	0x100b6076c <_writev+0x100b6076c>
100243698:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
10024369c:     	ldr	w22, [x8, #0x590]
1002436a0:     	cmp	w22, #0x300
1002436a4:     	b.hs	0x100243880 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x658>
1002436a8:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1002436ac:     	ldr	x8, [x8, #0x48]
1002436b0:     	cmn	x8, #0x1
1002436b4:     	b.eq	0x100243870 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x648>
1002436b8:     	mrs	x9, TPIDRRO_EL0
1002436bc:     	and	x9, x9, #0xfffffffffffffff8
1002436c0:     	ldr	x0, [x9, x8, lsl #3]
1002436c4:     	cbz	x0, 0x100243870 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x648>
1002436c8:     	add	x8, x0, x22, lsl #3
1002436cc:     	ldr	x0, [x8, #0x1e8]
1002436d0:     	cbz	x0, 0x100243880 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x658>
1002436d4:     	ldr	x8, [x0]
1002436d8:     	adds	x8, x8, x26
1002436dc:     	csinv	x8, x8, xzr, lo
1002436e0:     	str	x8, [x0]
1002436e4:     	lsr	x8, x8, #25
1002436e8:     	cbz	x8, 0x1002438a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x67c>
1002436ec:     	bl	0x10045d8f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1002436f0:     	ldr	x26, [x21, #0x68]
1002436f4:     	cmp	x26, #0x200, lsl #12    ; =0x200000
1002436f8:     	b.ls	0x1002438b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x688>
1002436fc:     	b	0x100243348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x120>
100243700:     	add	x8, x20, #0x14
100243704:     	ldr	x9, [x21, #0x20]
100243708:     	cbz	x9, 0x100243750 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x528>
10024370c:     	cmn	x8, #0x10
100243710:     	b.hi	0x100243750 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x528>
100243714:     	add	x9, x8, #0xf
100243718:     	and	x9, x9, #0xfffffffffffffff8
10024371c:     	cmp	x9, #0x4, lsl #12       ; =0x4000
100243720:     	b.hi	0x100243750 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x528>
100243724:     	ldr	x10, [x21, #0x30]
100243728:     	ldrb	w10, [x10]
10024372c:     	tbnz	w10, #0x0, 0x100243750 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x528>
100243730:     	ldr	x10, [x21, #0x28]
100243734:     	ldp	x11, x12, [x10, #0x8]
100243738:     	add	x11, x11, #0x7
10024373c:     	and	x11, x11, #0xfffffffffffffff8
100243740:     	subs	x12, x12, x11
100243744:     	csel	x12, xzr, x12, lo
100243748:     	cmp	x9, x12
10024374c:     	b.ls	0x100243810 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x5e8>
100243750:     	mov	x0, x20
100243754:     	bl	0x1003497ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100243758:     	mov	x23, x0
10024375c:     	mov	x0, x1
100243760:     	stp	w22, w20, [x23]
100243764:     	str	w20, [x23, #0x8]
100243768:     	mov	x8, #0x200000000        ; =8589934592
10024376c:     	stur	x8, [x23, #0xc]
100243770:     	mov	x1, x19
100243774:     	mov	x2, x20
100243778:     	bl	0x100b6076c <_writev+0x100b6076c>
10024377c:     	ldr	x26, [x21, #0x68]
100243780:     	cmp	x26, #0x200, lsl #12    ; =0x200000
100243784:     	b.ls	0x1002438b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x688>
100243788:     	b	0x100243348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x120>
10024378c:     	add	x8, sp, #0x18
100243790:     	mov	x0, x19
100243794:     	mov	x1, x23
100243798:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
10024379c:     	ldr	x8, [sp, #0x18]
1002437a0:     	cbz	x8, 0x100243850 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x628>
1002437a4:     	mov	w22, #0x0               ; =0
1002437a8:     	mov	x8, #0x0                ; =0
1002437ac:     	mov	w9, #0x2                ; =2
1002437b0:     	mov	w10, #0x3               ; =3
1002437b4:     	mov	w11, #0x4               ; =4
1002437b8:     	b	0x1002437d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x5a8>
1002437bc:     	add	w22, w22, #0x1
1002437c0:     	mov	w12, #0x1               ; =1
1002437c4:     	add	x8, x12, x8
1002437c8:     	cmp	x8, x23
1002437cc:     	b.hs	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
1002437d0:     	ldrsb	w12, [x19, x8]
1002437d4:     	tbz	w12, #0x1f, 0x1002437bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x594>
1002437d8:     	and	w12, w12, #0xff
1002437dc:     	cmp	w12, #0xc0
1002437e0:     	b.lo	0x1002437c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x598>
1002437e4:     	cmp	w12, #0xf0
1002437e8:     	add	w13, w22, #0x2
1002437ec:     	csel	x14, x10, x11, lo
1002437f0:     	csinc	w13, w13, w22, hs
1002437f4:     	cmp	w12, #0xe0
1002437f8:     	csel	x12, x9, x14, lo
1002437fc:     	csinc	w22, w13, w22, hs
100243800:     	add	x8, x12, x8
100243804:     	cmp	x8, x23
100243808:     	b.lo	0x1002437d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x5a8>
10024380c:     	b	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
100243810:     	ldr	x12, [x10]
100243814:     	add	x26, x12, x11
100243818:     	add	x11, x11, x9
10024381c:     	str	x11, [x10, #0x8]
100243820:     	mov	w10, #0x203             ; =515
100243824:     	stp	w10, w9, [x26]
100243828:     	add	x23, x26, #0x8
10024382c:     	sub	x10, x9, #0x8
100243830:     	subs	x10, x10, x8
100243834:     	csel	x1, xzr, x10, lo
100243838:     	b.ls	0x100243a18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x7f0>
10024383c:     	cmp	x1, #0x9
100243840:     	b.hs	0x100243a10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x7e8>
100243844:     	add	x8, x26, x9
100243848:     	stur	xzr, [x8, #-0x8]
10024384c:     	b	0x100243a18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x7f0>
100243850:     	ldr	x8, [sp, #0x28]
100243854:     	cbz	x8, 0x1002439f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x7cc>
100243858:     	ldr	x9, [sp, #0x20]
10024385c:     	cmp	x8, #0x8
100243860:     	b.hs	0x1002439fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x7d4>
100243864:     	mov	x10, #0x0               ; =0
100243868:     	mov	w22, #0x0               ; =0
10024386c:     	b	0x100243ce4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xabc>
100243870:     	bl	0x100b3dcbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100243874:     	add	x8, x0, x22, lsl #3
100243878:     	ldr	x0, [x8, #0x1e8]
10024387c:     	cbnz	x0, 0x1002436d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x4ac>
100243880:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100243884:     	add	x0, x0, #0x78
100243888:     	bl	0x100b3b4dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10024388c:     	ldr	x8, [x0]
100243890:     	adds	x8, x8, x26
100243894:     	csinv	x8, x8, xzr, lo
100243898:     	str	x8, [x0]
10024389c:     	lsr	x8, x8, #25
1002438a0:     	cbnz	x8, 0x1002436ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x4c4>
1002438a4:     	ldr	x26, [x21, #0x68]
1002438a8:     	cmp	x26, #0x200, lsl #12    ; =0x200000
1002438ac:     	b.hi	0x100243348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x120>
1002438b0:     	cmp	x20, #0x100
1002438b4:     	b.lo	0x100243348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x120>
1002438b8:     	ldr	x22, [x21, #0xc8]
1002438bc:     	cbz	x22, 0x100243348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x120>
1002438c0:     	ldr	x21, [x21, #0x70]
1002438c4:     	sub	x8, x26, x26, lsr #1
1002438c8:     	cmp	x20, x8
1002438cc:     	orr	x8, x21, x25
1002438d0:     	and	x8, x8, #0xffffffff00000000
1002438d4:     	ccmp	x8, #0x0, #0x0, hs
1002438d8:     	b.ne	0x100243348 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x120>
1002438dc:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
1002438e0:     	ldr	w20, [x8, #0x560]
1002438e4:     	cmp	w20, #0x300
1002438e8:     	b.hs	0x1002439d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x7a8>
1002438ec:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
1002438f0:     	ldr	x8, [x8, #0x48]
1002438f4:     	cmn	x8, #0x1
1002438f8:     	b.eq	0x1002439c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x798>
1002438fc:     	mrs	x9, TPIDRRO_EL0
100243900:     	and	x9, x9, #0xfffffffffffffff8
100243904:     	ldr	x0, [x9, x8, lsl #3]
100243908:     	cbz	x0, 0x1002439c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x798>
10024390c:     	add	x8, x0, x20, lsl #3
100243910:     	ldr	x20, [x8, #0x1e8]
100243914:     	cbz	x20, 0x1002439d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x7a8>
100243918:     	ldr	x8, [x20]
10024391c:     	cbnz	x8, 0x1002439e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x7c0>
100243920:     	mov	x8, #-0x1               ; =-1
100243924:     	str	x8, [x20]
100243928:     	ldrb	w8, [x20, #0x24]
10024392c:     	cmp	w8, #0x2
100243930:     	b.eq	0x100243964 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x73c>
100243934:     	ldr	x8, [x20, #0x8]
100243938:     	cmp	x8, x22
10024393c:     	b.ne	0x100243964 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x73c>
100243940:     	ldr	w8, [x20, #0x18]
100243944:     	cmp	w8, w26
100243948:     	b.ne	0x100243964 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x73c>
10024394c:     	str	xzr, [x20]
100243950:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100243954:     	bfxil	x0, x23, #0, #48
100243958:     	cmp	x24, #0x1
10024395c:     	b.ge	0x100243358 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x130>
100243960:     	b	0x100243368 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x140>
100243964:     	stp	x22, x23, [x20, #0x8]
100243968:     	stp	w26, w25, [x20, #0x18]
10024396c:     	str	w21, [x20, #0x20]
100243970:     	strb	wzr, [x20, #0x24]
100243974:     	adrp	x21, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf85c>
100243978:     	ldr	w8, [x21, #0x7a4]
10024397c:     	cbz	w8, 0x10024398c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x764>
100243980:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100243984:     	bfxil	x0, x22, #0, #48
100243988:     	bl	0x100474d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
10024398c:     	ldr	w8, [x21, #0x7a4]
100243990:     	cbz	w8, 0x1002439a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x778>
100243994:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100243998:     	bfxil	x0, x23, #0, #48
10024399c:     	bl	0x100474d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
1002439a0:     	ldr	x8, [x20]
1002439a4:     	add	x8, x8, #0x1
1002439a8:     	str	x8, [x20]
1002439ac:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
1002439b0:     	bfxil	x0, x23, #0, #48
1002439b4:     	cmp	x24, #0x1
1002439b8:     	b.ge	0x100243358 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x130>
1002439bc:     	b	0x100243368 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x140>
1002439c0:     	bl	0x100b3dcbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1002439c4:     	add	x8, x0, x20, lsl #3
1002439c8:     	ldr	x20, [x8, #0x1e8]
1002439cc:     	cbnz	x20, 0x100243918 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x6f0>
1002439d0:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
1002439d4:     	add	x0, x0, #0xfa0
1002439d8:     	bl	0x100b3b4dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
1002439dc:     	mov	x20, x0
1002439e0:     	ldr	x8, [x0]
1002439e4:     	cbz	x8, 0x100243920 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x6f8>
1002439e8:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1002439ec:     	add	x0, x0, #0xce0
1002439f0:     	bl	0x100b10fec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1002439f4:     	mov	w22, #0x0               ; =0
1002439f8:     	b	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
1002439fc:     	cmp	x8, #0x20
100243a00:     	b.hs	0x100243a30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x808>
100243a04:     	mov	x10, #0x0               ; =0
100243a08:     	mov	w22, #0x0               ; =0
100243a0c:     	b	0x100243c34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xa0c>
100243a10:     	add	x0, x23, x8
100243a14:     	bl	0x100b602a4 <_writev+0x100b602a4>
100243a18:     	stp	w22, w20, [x26, #0x8]
100243a1c:     	str	w20, [x26, #0x10]
100243a20:     	mov	x8, #0x200000000        ; =8589934592
100243a24:     	stur	x8, [x26, #0x14]
100243a28:     	add	x0, x26, #0x1c
100243a2c:     	b	0x100243770 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x548>
100243a30:     	movi.2d	v0, #0000000000000000
100243a34:     	and	x11, x8, #0x18
100243a38:     	movi.16b	v1, #0xf0
100243a3c:     	and	x10, x8, #0xffffffffffffffe0
100243a40:     	movi.4s	v2, #0x2
100243a44:     	add	x12, x9, #0x10
100243a48:     	movi.16b	v4, #0xc0
100243a4c:     	and	x13, x8, #0xffffffffffffffe0
100243a50:     	movi.2d	v3, #0000000000000000
100243a54:     	movi.2d	v6, #0000000000000000
100243a58:     	movi.2d	v5, #0000000000000000
100243a5c:     	movi.2d	v7, #0000000000000000
100243a60:     	movi.2d	v16, #0000000000000000
100243a64:     	movi.2d	v17, #0000000000000000
100243a68:     	movi.2d	v18, #0000000000000000
100243a6c:     	ldp	q20, q19, [x12, #-0x10]
100243a70:     	cmhi.16b	v21, v1, v20
100243a74:     	sshll2.8h	v22, v21, #0x0
100243a78:     	sshll2.4s	v23, v22, #0x0
100243a7c:     	sshll.4s	v24, v22, #0x0
100243a80:     	sshll.8h	v21, v21, #0x0
100243a84:     	sshll2.4s	v25, v21, #0x0
100243a88:     	sshll.4s	v26, v21, #0x0
100243a8c:     	cmhi.16b	v27, v1, v19
100243a90:     	sshll2.8h	v28, v27, #0x0
100243a94:     	sshll2.4s	v29, v28, #0x0
100243a98:     	sshll.4s	v30, v28, #0x0
100243a9c:     	sshll.8h	v27, v27, #0x0
100243aa0:     	sshll2.4s	v31, v27, #0x0
100243aa4:     	bic.16b	v26, v2, v26
100243aa8:     	ssubw.4s	v26, v26, v21
100243aac:     	bic.16b	v25, v2, v25
100243ab0:     	ssubw2.4s	v25, v25, v21
100243ab4:     	sshll.4s	v21, v27, #0x0
100243ab8:     	bic.16b	v24, v2, v24
100243abc:     	ssubw.4s	v24, v24, v22
100243ac0:     	bic.16b	v23, v2, v23
100243ac4:     	ssubw2.4s	v22, v23, v22
100243ac8:     	bic.16b	v21, v2, v21
100243acc:     	ssubw.4s	v21, v21, v27
100243ad0:     	bic.16b	v23, v2, v31
100243ad4:     	ssubw2.4s	v23, v23, v27
100243ad8:     	bic.16b	v27, v2, v30
100243adc:     	ssubw.4s	v27, v27, v28
100243ae0:     	bic.16b	v29, v2, v29
100243ae4:     	ssubw2.4s	v28, v29, v28
100243ae8:     	cmgt.16b	v29, v4, v20
100243aec:     	sshll2.8h	v30, v29, #0x0
100243af0:     	ushll2.4s	v31, v30, #0x0
100243af4:     	bic.16b	v22, v22, v31
100243af8:     	cmlt.16b	v20, v20, #0
100243afc:     	sshll.8h	v29, v29, #0x0
100243b00:     	ushll.4s	v30, v30, #0x0
100243b04:     	bic.16b	v24, v24, v30
100243b08:     	ushll2.4s	v30, v29, #0x0
100243b0c:     	bic.16b	v25, v25, v30
100243b10:     	sshll2.8h	v30, v20, #0x0
100243b14:     	sshll.8h	v20, v20, #0x0
100243b18:     	ushll.4s	v29, v29, #0x0
100243b1c:     	bic.16b	v26, v26, v29
100243b20:     	sshll.4s	v29, v20, #0x0
100243b24:     	and.16b	v26, v26, v29
100243b28:     	mvn.16b	v29, v29
100243b2c:     	sub.4s	v26, v26, v29
100243b30:     	sshll2.4s	v29, v30, #0x0
100243b34:     	sshll.4s	v30, v30, #0x0
100243b38:     	sshll2.4s	v20, v20, #0x0
100243b3c:     	and.16b	v25, v25, v20
100243b40:     	mvn.16b	v20, v20
100243b44:     	sub.4s	v20, v25, v20
100243b48:     	cmgt.16b	v25, v4, v19
100243b4c:     	and.16b	v24, v24, v30
100243b50:     	mvn.16b	v30, v30
100243b54:     	sub.4s	v24, v24, v30
100243b58:     	sshll2.8h	v30, v25, #0x0
100243b5c:     	and.16b	v22, v22, v29
100243b60:     	mvn.16b	v29, v29
100243b64:     	sub.4s	v22, v22, v29
100243b68:     	ushll2.4s	v29, v30, #0x0
100243b6c:     	bic.16b	v28, v28, v29
100243b70:     	cmlt.16b	v19, v19, #0
100243b74:     	sshll.8h	v25, v25, #0x0
100243b78:     	ushll.4s	v29, v30, #0x0
100243b7c:     	bic.16b	v27, v27, v29
100243b80:     	ushll2.4s	v29, v25, #0x0
100243b84:     	bic.16b	v23, v23, v29
100243b88:     	sshll.8h	v29, v19, #0x0
100243b8c:     	ushll.4s	v25, v25, #0x0
100243b90:     	bic.16b	v21, v21, v25
100243b94:     	sshll.4s	v25, v29, #0x0
100243b98:     	and.16b	v21, v21, v25
100243b9c:     	mvn.16b	v25, v25
100243ba0:     	sub.4s	v21, v21, v25
100243ba4:     	sshll2.8h	v19, v19, #0x0
100243ba8:     	sshll2.4s	v25, v29, #0x0
100243bac:     	and.16b	v23, v23, v25
100243bb0:     	mvn.16b	v25, v25
100243bb4:     	sub.4s	v23, v23, v25
100243bb8:     	sshll.4s	v25, v19, #0x0
100243bbc:     	and.16b	v27, v27, v25
100243bc0:     	mvn.16b	v25, v25
100243bc4:     	sub.4s	v25, v27, v25
100243bc8:     	sshll2.4s	v19, v19, #0x0
100243bcc:     	and.16b	v27, v28, v19
100243bd0:     	mvn.16b	v19, v19
100243bd4:     	sub.4s	v19, v27, v19
100243bd8:     	add.4s	v7, v22, v7
100243bdc:     	add.4s	v5, v24, v5
100243be0:     	add.4s	v6, v20, v6
100243be4:     	add.4s	v3, v26, v3
100243be8:     	add.4s	v18, v19, v18
100243bec:     	add.4s	v17, v25, v17
100243bf0:     	add.4s	v0, v23, v0
100243bf4:     	add.4s	v16, v21, v16
100243bf8:     	add	x12, x12, #0x20
100243bfc:     	subs	x13, x13, #0x20
100243c00:     	b.ne	0x100243a6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x844>
100243c04:     	add.4s	v0, v0, v6
100243c08:     	add.4s	v1, v18, v7
100243c0c:     	add.4s	v2, v16, v3
100243c10:     	add.4s	v3, v17, v5
100243c14:     	add.4s	v2, v2, v3
100243c18:     	add.4s	v0, v0, v1
100243c1c:     	add.4s	v0, v2, v0
100243c20:     	addv.4s	s0, v0
100243c24:     	fmov	w22, s0
100243c28:     	cmp	x8, x10
100243c2c:     	b.eq	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
100243c30:     	cbz	x11, 0x100243ce4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xabc>
100243c34:     	mov	x12, x10
100243c38:     	and	x10, x8, #0xfffffffffffffff8
100243c3c:     	movi.2d	v0, #0000000000000000
100243c40:     	mov.s	v0[0], w22
100243c44:     	movi.2d	v1, #0000000000000000
100243c48:     	sub	x11, x12, x10
100243c4c:     	add	x12, x9, x12
100243c50:     	movi.8b	v2, #0xf0
100243c54:     	movi.4s	v3, #0x2
100243c58:     	movi.8b	v4, #0xc0
100243c5c:     	ldr	d5, [x12], #0x8
100243c60:     	sshll.8h	v6, v5, #0x0
100243c64:     	cmlt.8h	v6, v6, #0
100243c68:     	sshll2.4s	v7, v6, #0x0
100243c6c:     	sshll.4s	v6, v6, #0x0
100243c70:     	cmhi.8b	v16, v2, v5
100243c74:     	sshll.8h	v16, v16, #0x0
100243c78:     	sshll2.4s	v17, v16, #0x0
100243c7c:     	sshll.4s	v18, v16, #0x0
100243c80:     	bic.16b	v18, v3, v18
100243c84:     	ssubw.4s	v18, v18, v16
100243c88:     	bic.16b	v17, v3, v17
100243c8c:     	ssubw2.4s	v16, v17, v16
100243c90:     	cmgt.8b	v5, v4, v5
100243c94:     	sshll.8h	v5, v5, #0x0
100243c98:     	ushll.4s	v17, v5, #0x0
100243c9c:     	ushll2.4s	v5, v5, #0x0
100243ca0:     	bic.16b	v5, v16, v5
100243ca4:     	bic.16b	v16, v18, v17
100243ca8:     	and.16b	v16, v16, v6
100243cac:     	mvn.16b	v6, v6
100243cb0:     	sub.4s	v6, v16, v6
100243cb4:     	and.16b	v5, v5, v7
100243cb8:     	mvn.16b	v7, v7
100243cbc:     	sub.4s	v5, v5, v7
100243cc0:     	add.4s	v1, v5, v1
100243cc4:     	add.4s	v0, v6, v0
100243cc8:     	adds	x11, x11, #0x8
100243ccc:     	b.ne	0x100243c5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xa34>
100243cd0:     	add.4s	v0, v0, v1
100243cd4:     	addv.4s	s0, v0
100243cd8:     	fmov	w22, s0
100243cdc:     	cmp	x8, x10
100243ce0:     	b.eq	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
100243ce4:     	sub	x8, x8, x10
100243ce8:     	add	x9, x9, x10
100243cec:     	mov	w10, #0x1               ; =1
100243cf0:     	ldrsb	w11, [x9], #0x1
100243cf4:     	and	w12, w11, #0xff
100243cf8:     	cmp	w12, #0xf0
100243cfc:     	cinc	w13, w10, hs
100243d00:     	cmp	w12, #0xc0
100243d04:     	csel	w12, wzr, w13, lo
100243d08:     	tst	w11, #0x80000000
100243d0c:     	csinc	w11, w12, wzr, ne
100243d10:     	add	w22, w11, w22
100243d14:     	subs	x8, x8, #0x1
100243d18:     	b.ne	0x100243cf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xac8>
100243d1c:     	b	0x10024365c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x434>
		...
