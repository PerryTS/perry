
benchmarks/json_performance/.work/parse-regression-r35-profiles/r26-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100243d18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped>:
100243d18:     	stp	x28, x27, [sp, #-0x60]!
100243d1c:     	stp	x26, x25, [sp, #0x10]
100243d20:     	stp	x24, x23, [sp, #0x20]
100243d24:     	stp	x22, x21, [sp, #0x30]
100243d28:     	stp	x20, x19, [sp, #0x40]
100243d2c:     	stp	x29, x30, [sp, #0x50]
100243d30:     	add	x29, sp, #0x50
100243d34:     	sub	sp, sp, #0x2e0
100243d38:     	mov	x19, x0
100243d3c:     	ldp	x8, x9, [x0, #0x68]
100243d40:     	add	x9, x9, #0x1
100243d44:     	str	x9, [x0, #0x70]
100243d48:     	cmp	x9, x8
100243d4c:     	b.hs	0x100243d80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x68>
100243d50:     	ldr	x10, [x19, #0x60]
100243d54:     	mov	x11, #0x2600            ; =9728
100243d58:     	movk	x11, #0x1, lsl #32
100243d5c:     	ldrb	w12, [x10, x9]
100243d60:     	cmp	w12, #0x20
100243d64:     	b.hi	0x100243d80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x68>
100243d68:     	lsr	x12, x11, x12
100243d6c:     	tbz	w12, #0x0, 0x100243d80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x68>
100243d70:     	add	x9, x9, #0x1
100243d74:     	str	x9, [x19, #0x70]
100243d78:     	cmp	x8, x9
100243d7c:     	b.ne	0x100243d5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x44>
100243d80:     	ldrb	w8, [x19, #0xd5]
100243d84:     	tbz	w8, #0x0, 0x100243db0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x98>
100243d88:     	strb	wzr, [x19, #0xd5]
100243d8c:     	ldr	x21, [x19, #0x78]
100243d90:     	ldp	q0, q1, [x19, #0x80]
100243d94:     	stur	q0, [sp, #0xa8]
100243d98:     	stur	q1, [sp, #0xb8]
100243d9c:     	ldp	q0, q1, [x19, #0xa0]
100243da0:     	stur	q0, [sp, #0xc8]
100243da4:     	stur	q1, [sp, #0xd8]
100243da8:     	ldr	x9, [x19, #0xc0]
100243dac:     	b	0x100243de8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd0>
100243db0:     	mov	w26, #0x0               ; =0
100243db4:     	mov	x8, #0x0                ; =0
100243db8:     	ldr	x21, [x19, #0x78]
100243dbc:     	cbz	x21, 0x100244f14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11fc>
100243dc0:     	ldr	x10, [x19, #0xc0]
100243dc4:     	str	x10, [sp, #0x88]
100243dc8:     	cbz	x10, 0x100243e04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec>
100243dcc:     	ldp	q0, q1, [x19, #0x80]
100243dd0:     	stur	q0, [sp, #0xa8]
100243dd4:     	stur	q1, [sp, #0xb8]
100243dd8:     	ldp	q0, q1, [x19, #0xa0]
100243ddc:     	stur	q0, [sp, #0xc8]
100243de0:     	stur	q1, [sp, #0xd8]
100243de4:     	ldr	x9, [sp, #0x88]
100243de8:     	ldr	w8, [x19, #0xd0]
100243dec:     	stp	x21, x9, [sp, #0xe8]
100243df0:     	str	x9, [sp, #0x88]
100243df4:     	str	w8, [sp, #0x64]
100243df8:     	str	w8, [sp, #0xf8]
100243dfc:     	mov	w8, #0x1                ; =1
100243e00:     	mov	w26, #0x1               ; =1
100243e04:     	str	x8, [sp, #0xa0]
100243e08:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100243e0c:     	add	x0, x0, #0xce8
100243e10:     	ldr	x8, [x0]
100243e14:     	blr	x8
100243e18:     	mov	x20, x0
100243e1c:     	ldrb	w8, [x0, #0x20]
100243e20:     	cbnz	w8, 0x1002451ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1494>
100243e24:     	ldr	x8, [x20]
100243e28:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100243e2c:     	cmp	x8, x9
100243e30:     	b.hs	0x1002451d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14c0>
100243e34:     	ldr	x22, [x20, #0x18]
100243e38:     	ldp	x23, x24, [x19, #0x68]
100243e3c:     	cmp	x24, x23
100243e40:     	b.hs	0x100243e74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15c>
100243e44:     	ldr	x8, [x19, #0x60]
100243e48:     	ldrb	w8, [x8, x24]
100243e4c:     	cmp	w8, #0x7d
100243e50:     	b.ne	0x100243e74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15c>
100243e54:     	add	x8, x24, #0x1
100243e58:     	str	x8, [x19, #0x70]
100243e5c:     	ldr	x8, [x19, #0x78]
100243e60:     	cbnz	x8, 0x100244f18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1200>
100243e64:     	ldr	x1, [x19, #0xc0]
100243e68:     	cbz	x1, 0x100244f18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1200>
100243e6c:     	ldr	w2, [x19, #0xd0]
100243e70:     	b	0x100244f38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1220>
100243e74:     	movi.2d	v0, #0000000000000000
100243e78:     	stp	q0, q0, [sp, #0x120]
100243e7c:     	stp	q0, q0, [sp, #0x100]
100243e80:     	adrp	x1, 0x100c99000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x7070>
100243e84:     	add	x1, x1, #0xa70
100243e88:     	add	x0, sp, #0x148
100243e8c:     	mov	w2, #0x40               ; =64
100243e90:     	bl	0x100b5fc50 <_writev+0x100b5fc50>
100243e94:     	mov	x27, #0x0               ; =0
100243e98:     	str	xzr, [sp, #0x90]
100243e9c:     	mov	x8, #-0x1               ; =-1
100243ea0:     	str	x8, [sp, #0x188]
100243ea4:     	add	x8, sp, #0xa0
100243ea8:     	add	x8, x8, #0x8
100243eac:     	stp	x8, xzr, [sp, #0x68]
100243eb0:     	mov	x25, #0x2600            ; =9728
100243eb4:     	movk	x25, #0x1, lsl #32
100243eb8:     	adrp	x8, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5070>
100243ebc:     	ldr	q0, [x8, #0x820]
100243ec0:     	str	q0, [sp, #0x40]
100243ec4:     	adrp	x8, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5070>
100243ec8:     	ldr	q0, [x8, #0x830]
100243ecc:     	str	q0, [sp, #0x30]
100243ed0:     	adrp	x8, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5070>
100243ed4:     	ldr	q0, [x8, #0x810]
100243ed8:     	str	q0, [sp, #0x50]
100243edc:     	mov	x11, x26
100243ee0:     	mov	x8, x26
100243ee4:     	str	w26, [sp, #0x80]
100243ee8:     	str	w8, [sp, #0x84]
100243eec:     	cmp	x24, x23
100243ef0:     	b.hs	0x100243f20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x208>
100243ef4:     	ldr	x8, [x19, #0x60]
100243ef8:     	ldrb	w9, [x8, x24]
100243efc:     	cmp	w9, #0x20
100243f00:     	b.hi	0x100243f20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x208>
100243f04:     	lsr	x9, x25, x9
100243f08:     	tbz	w9, #0x0, 0x100243f20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x208>
100243f0c:     	add	x24, x24, #0x1
100243f10:     	str	x24, [x19, #0x70]
100243f14:     	cmp	x23, x24
100243f18:     	b.ne	0x100243ef8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1e0>
100243f1c:     	mov	x24, x23
100243f20:     	str	w11, [sp, #0x7c]
100243f24:     	str	x27, [sp, #0x98]
100243f28:     	cbz	w26, 0x100243fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100243f2c:     	cmp	x27, x21
100243f30:     	cset	w8, lo
100243f34:     	tst	w11, w8
100243f38:     	b.eq	0x100243fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100243f3c:     	cmp	x27, #0x8
100243f40:     	b.hs	0x100245280 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1568>
100243f44:     	cmp	x24, x23
100243f48:     	b.hs	0x100243fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100243f4c:     	ldr	x8, [sp, #0x68]
100243f50:     	ldr	x9, [x8, x27, lsl #3]
100243f54:     	cbz	x9, 0x100243fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100243f58:     	ldr	x10, [x19, #0x60]
100243f5c:     	ldrb	w8, [x10, x24]
100243f60:     	cmp	w8, #0x22
100243f64:     	b.ne	0x100243fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100243f68:     	add	x11, x24, #0x1
100243f6c:     	ldr	w14, [x9, #0x4]
100243f70:     	add	x8, x11, x14
100243f74:     	cmp	x8, x23
100243f78:     	ccmp	x8, x24, #0x0, lo
100243f7c:     	b.ls	0x100243fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100243f80:     	ldrb	w12, [x10, x8]
100243f84:     	cmp	w12, #0x22
100243f88:     	b.ne	0x100243fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100243f8c:     	add	x24, x10, x11
100243f90:     	cbz	w14, 0x100243fcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2b4>
100243f94:     	add	x9, x9, #0x14
100243f98:     	mov	x10, x14
100243f9c:     	mov	x11, x24
100243fa0:     	ldrb	w12, [x11], #0x1
100243fa4:     	cmp	w12, #0x5c
100243fa8:     	b.eq	0x100243fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100243fac:     	cmp	w12, #0x22
100243fb0:     	b.eq	0x100243fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100243fb4:     	ldrb	w13, [x9], #0x1
100243fb8:     	cmp	w12, #0x20
100243fbc:     	ccmp	w12, w13, #0x0, hs
100243fc0:     	b.ne	0x100243fe0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2c8>
100243fc4:     	subs	x10, x10, #0x1
100243fc8:     	b.ne	0x100243fa0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x288>
100243fcc:     	add	x8, x8, #0x1
100243fd0:     	str	x8, [x19, #0x70]
100243fd4:     	mov	w23, #0x1               ; =1
100243fd8:     	mov	x27, #-0x1              ; =-1
100243fdc:     	b	0x100244000 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100243fe0:     	sub	x0, x29, #0xc0
100243fe4:     	mov	x1, x19
100243fe8:     	bl	0x1002434f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
100243fec:     	ldur	x27, [x29, #-0xc0]
100243ff0:     	cmn	x27, #0x2
100243ff4:     	b.eq	0x100244d50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1038>
100243ff8:     	mov	w23, #0x0               ; =0
100243ffc:     	ldp	x24, x14, [x29, #-0xb8]
100244000:     	ldp	x9, x8, [x19, #0x68]
100244004:     	cmp	x8, x9
100244008:     	b.hs	0x100244d3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1024>
10024400c:     	ldr	x10, [x19, #0x60]
100244010:     	ldrb	w11, [x10, x8]
100244014:     	cmp	w11, #0x3a
100244018:     	b.hi	0x100244d3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1024>
10024401c:     	lsr	x12, x25, x11
100244020:     	tbz	w12, #0x0, 0x100244038 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x320>
100244024:     	add	x8, x8, #0x1
100244028:     	str	x8, [x19, #0x70]
10024402c:     	cmp	x9, x8
100244030:     	b.ne	0x100244010 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2f8>
100244034:     	b	0x100244d3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1024>
100244038:     	cmp	x11, #0x3a
10024403c:     	b.ne	0x100244d3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1024>
100244040:     	str	x14, [sp, #0x28]
100244044:     	add	x8, x8, #0x1
100244048:     	str	x8, [x19, #0x70]
10024404c:     	mov	x0, x19
100244050:     	bl	0x100242448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
100244054:     	str	x0, [sp, #0x10]
100244058:     	ldrb	w8, [x19, #0xd4]
10024405c:     	tbz	w8, #0x0, 0x100244d40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
100244060:     	ldr	x8, [sp, #0x188]
100244064:     	cmn	x8, #0x1
100244068:     	str	x24, [sp, #0x18]
10024406c:     	b.eq	0x100244130 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x418>
100244070:     	ldr	x8, [sp, #0x1b8]
100244074:     	ldr	x1, [sp, #0x198]
100244078:     	cmn	x8, #0x1
10024407c:     	ldr	x2, [sp, #0x28]
100244080:     	str	x22, [sp, #0x8]
100244084:     	b.eq	0x10024417c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x464>
100244088:     	mov	x28, #0x7f2d            ; =32557
10024408c:     	movk	x28, #0x4c95, lsl #16
100244090:     	movk	x28, #0xf42d, lsl #32
100244094:     	movk	x28, #0x5851, lsl #48
100244098:     	ldp	x8, x11, [sp, #0x1f0]
10024409c:     	ldr	x10, [sp, #0x200]
1002440a0:     	ldr	x9, [sp, #0x208]
1002440a4:     	eor	x11, x11, x2
1002440a8:     	mul	x12, x11, x28
1002440ac:     	umulh	x11, x11, x28
1002440b0:     	eor	x11, x11, x12
1002440b4:     	add	x11, x2, x11
1002440b8:     	mul	x11, x11, x28
1002440bc:     	cmp	x2, #0x8
1002440c0:     	b.ls	0x1002443ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x694>
1002440c4:     	cmp	x2, #0x10
1002440c8:     	b.ls	0x100244494 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x77c>
1002440cc:     	add	x12, x24, x2
1002440d0:     	ldp	x12, x13, [x12, #-0x10]
1002440d4:     	eor	x12, x10, x12
1002440d8:     	eor	x13, x13, x9
1002440dc:     	mul	x14, x13, x12
1002440e0:     	umulh	x12, x13, x12
1002440e4:     	eor	x12, x12, x14
1002440e8:     	add	x11, x11, x8
1002440ec:     	eor	x11, x11, x12
1002440f0:     	ror	x11, x11, #0x29
1002440f4:     	mov	x13, x24
1002440f8:     	mov	x12, x2
1002440fc:     	ldp	x15, x14, [x13], #0x10
100244100:     	sub	x12, x12, #0x10
100244104:     	eor	x15, x10, x15
100244108:     	eor	x14, x14, x9
10024410c:     	mul	x16, x14, x15
100244110:     	umulh	x14, x14, x15
100244114:     	eor	x14, x14, x16
100244118:     	add	x11, x11, x8
10024411c:     	eor	x11, x11, x14
100244120:     	ror	x11, x11, #0x29
100244124:     	cmp	x12, #0x10
100244128:     	b.hi	0x1002440fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x3e4>
10024412c:     	b	0x1002444e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7d0>
100244130:     	ldr	w8, [sp, #0x84]
100244134:     	ldr	x1, [sp, #0x28]
100244138:     	tbz	w8, #0x0, 0x1002443cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6b4>
10024413c:     	ldr	w8, [sp, #0x80]
100244140:     	tbz	w8, #0x0, 0x100245274 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x155c>
100244144:     	ldr	x8, [sp, #0x98]
100244148:     	cmp	x8, x21
10024414c:     	ldr	w11, [sp, #0x7c]
100244150:     	b.hs	0x100244700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9e8>
100244154:     	tbz	w23, #0x0, 0x1002446c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9ac>
100244158:     	ldr	x0, [sp, #0x98]
10024415c:     	cmp	x0, #0x7
100244160:     	b.hi	0x1002452e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15c8>
100244164:     	ldr	x8, [sp, #0x68]
100244168:     	ldr	x10, [x8, x0, lsl #3]
10024416c:     	add	x0, x0, #0x1
100244170:     	str	x0, [sp, #0x98]
100244174:     	mov	w8, #0x1                ; =1
100244178:     	b	0x100244714 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9fc>
10024417c:     	ldr	x26, [sp, #0x190]
100244180:     	cmp	x1, #0x80
100244184:     	mov	x28, #0x7f2d            ; =32557
100244188:     	movk	x28, #0x4c95, lsl #16
10024418c:     	movk	x28, #0xf42d, lsl #32
100244190:     	movk	x28, #0x5851, lsl #48
100244194:     	b.ne	0x1002443e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6cc>
100244198:     	mov	w8, #0x1                ; =1
10024419c:     	strb	w8, [x19, #0xd6]
1002441a0:     	adrp	x8, 0x10104d000 <_out_buf+0x3a48>
1002441a4:     	add	x8, x8, #0x780
1002441a8:     	ldapr	x8, [x8]
1002441ac:     	cbz	x8, 0x100244d00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfe8>
1002441b0:     	ldp	x0, x22, [x8]
1002441b4:     	adrp	x8, 0x10104d000 <_out_buf+0x3a48>
1002441b8:     	add	x8, x8, #0x788
1002441bc:     	ldapr	x24, [x8]
1002441c0:     	cbz	x24, 0x100244d20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1008>
1002441c4:     	ldr	x8, [x22, #0x18]
1002441c8:     	blr	x8
1002441cc:     	mov	x2, x0
1002441d0:     	sub	x8, x29, #0xc0
1002441d4:     	add	x8, x8, #0x38
1002441d8:     	add	x1, x24, #0x20
1002441dc:     	mov	x0, x24
1002441e0:     	bl	0x100006d70 <__RNvMs1_NtCs3SoQS4yp3pP_5ahash12random_stateNtB5_11RandomState9from_keys>
1002441e4:     	mov	w0, #0x1108             ; =4360
1002441e8:     	mov	w1, #0x8                ; =8
1002441ec:     	bl	0x100b5d008 <_mi_malloc_aligned>
1002441f0:     	cbz	x0, 0x1002452b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x159c>
1002441f4:     	mov	x24, #0x0               ; =0
1002441f8:     	mov	x2, #0x0                ; =0
1002441fc:     	movi.2d	v0, #0xffffffffffffffff
100244200:     	str	q0, [x0, #0x10f0]
100244204:     	str	q0, [x0, #0x10e0]
100244208:     	str	q0, [x0, #0x10d0]
10024420c:     	str	q0, [x0, #0x10c0]
100244210:     	str	q0, [x0, #0x10b0]
100244214:     	str	q0, [x0, #0x10a0]
100244218:     	str	q0, [x0, #0x1090]
10024421c:     	str	q0, [x0, #0x1080]
100244220:     	str	q0, [x0, #0x1070]
100244224:     	str	q0, [x0, #0x1060]
100244228:     	str	q0, [x0, #0x1050]
10024422c:     	str	q0, [x0, #0x1040]
100244230:     	str	q0, [x0, #0x1030]
100244234:     	str	q0, [x0, #0x1020]
100244238:     	str	q0, [x0, #0x1010]
10024423c:     	str	q0, [x0, #0x1000]
100244240:     	str	d0, [x0, #0x1100]
100244244:     	add	x8, x0, #0x1, lsl #12   ; =0x1000
100244248:     	stur	xzr, [x29, #-0x90]
10024424c:     	ldr	q0, [sp, #0x50]
100244250:     	stur	q0, [x29, #-0xa0]
100244254:     	mov	w9, #0x8                ; =8
100244258:     	stp	xzr, x9, [x29, #-0xc0]
10024425c:     	stp	xzr, x8, [x29, #-0xb0]
100244260:     	b	0x1002442bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x5a4>
100244264:     	ldr	w11, [x11]
100244268:     	ldur	w12, [x14, #-0x4]
10024426c:     	eor	x10, x11, x10
100244270:     	eor	x9, x12, x9
100244274:     	mul	x11, x9, x10
100244278:     	umulh	x9, x9, x10
10024427c:     	eor	x9, x9, x11
100244280:     	add	x10, x13, x8
100244284:     	eor	x9, x10, x9
100244288:     	ror	x13, x9, #0x29
10024428c:     	add	x24, x24, #0x8
100244290:     	add	x22, x2, #0x1
100244294:     	mul	x9, x13, x8
100244298:     	umulh	x8, x13, x8
10024429c:     	eor	x8, x8, x9
1002442a0:     	neg	w9, w13
1002442a4:     	ror	x1, x8, x9
1002442a8:     	sub	x0, x29, #0xc0
1002442ac:     	bl	0x10028688c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
1002442b0:     	mov	x2, x22
1002442b4:     	cmp	x24, #0x400
1002442b8:     	b.eq	0x1002443ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6d4>
1002442bc:     	ldr	x8, [x26, x24]
1002442c0:     	add	x11, x8, #0x14
1002442c4:     	ldr	w12, [x8, #0x4]
1002442c8:     	ldp	x8, x13, [x29, #-0x88]
1002442cc:     	ldp	x10, x9, [x29, #-0x78]
1002442d0:     	eor	x13, x13, x12
1002442d4:     	mul	x14, x13, x28
1002442d8:     	umulh	x13, x13, x28
1002442dc:     	eor	x13, x13, x14
1002442e0:     	add	x13, x13, x12
1002442e4:     	mul	x13, x13, x28
1002442e8:     	cmp	w12, #0x8
1002442ec:     	b.ls	0x100244354 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x63c>
1002442f0:     	cmp	w12, #0x10
1002442f4:     	b.ls	0x100244374 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x65c>
1002442f8:     	add	x14, x11, x12
1002442fc:     	ldp	x14, x15, [x14, #-0x10]
100244300:     	eor	x14, x10, x14
100244304:     	eor	x15, x15, x9
100244308:     	mul	x16, x15, x14
10024430c:     	umulh	x14, x15, x14
100244310:     	eor	x14, x14, x16
100244314:     	add	x13, x13, x8
100244318:     	eor	x13, x13, x14
10024431c:     	ror	x13, x13, #0x29
100244320:     	ldp	x15, x14, [x11], #0x10
100244324:     	sub	x12, x12, #0x10
100244328:     	eor	x15, x10, x15
10024432c:     	eor	x14, x14, x9
100244330:     	mul	x16, x14, x15
100244334:     	umulh	x14, x14, x15
100244338:     	eor	x14, x14, x16
10024433c:     	add	x13, x13, x8
100244340:     	eor	x13, x13, x14
100244344:     	ror	x13, x13, #0x29
100244348:     	cmp	x12, #0x10
10024434c:     	b.hi	0x100244320 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x608>
100244350:     	b	0x10024428c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x574>
100244354:     	cmp	w12, #0x1
100244358:     	b.ls	0x10024438c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x674>
10024435c:     	add	x14, x11, x12
100244360:     	cmp	w12, #0x3
100244364:     	b.hi	0x100244264 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x54c>
100244368:     	ldrh	w11, [x11]
10024436c:     	ldurb	w12, [x14, #-0x1]
100244370:     	b	0x10024426c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x554>
100244374:     	ldr	x14, [x11]
100244378:     	add	x11, x11, x12
10024437c:     	ldur	x11, [x11, #-0x8]
100244380:     	eor	x10, x14, x10
100244384:     	eor	x9, x11, x9
100244388:     	b	0x100244274 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x55c>
10024438c:     	cmp	w12, #0x1
100244390:     	b.ne	0x1002443a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x688>
100244394:     	ldrb	w11, [x11]
100244398:     	mov	x12, x11
10024439c:     	b	0x10024426c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x554>
1002443a0:     	mov	x11, #0x0               ; =0
1002443a4:     	mov	x12, #0x0               ; =0
1002443a8:     	b	0x10024426c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x554>
1002443ac:     	cmp	x2, #0x1
1002443b0:     	b.ls	0x1002444a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x78c>
1002443b4:     	add	x13, x24, x2
1002443b8:     	cmp	x2, #0x3
1002443bc:     	b.ls	0x1002444b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x79c>
1002443c0:     	ldr	w12, [x24]
1002443c4:     	ldur	w13, [x13, #-0x4]
1002443c8:     	b	0x1002444c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
1002443cc:     	mov	x0, x24
1002443d0:     	bl	0x100325dbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
1002443d4:     	mov	x10, x0
1002443d8:     	mov	w8, #0x0                ; =0
1002443dc:     	ldr	w11, [sp, #0x7c]
1002443e0:     	b	0x100244714 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9fc>
1002443e4:     	str	x1, [sp, #0x20]
1002443e8:     	b	0x100244b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe10>
1002443ec:     	ldur	q2, [x29, #-0x80]
1002443f0:     	ldur	x8, [x29, #-0x70]
1002443f4:     	str	x8, [sp, #0x260]
1002443f8:     	ldp	q0, q1, [x29, #-0xc0]
1002443fc:     	stp	q0, q1, [sp, #0x210]
100244400:     	ldp	q0, q1, [x29, #-0xa0]
100244404:     	str	q0, [sp, #0x230]
100244408:     	stp	q1, q2, [sp, #0x240]
10024440c:     	ldr	x22, [sp, #0x1b8]
100244410:     	cmn	x22, #0x1
100244414:     	ldr	x24, [sp, #0x18]
100244418:     	ldr	x2, [sp, #0x28]
10024441c:     	b.eq	0x10024445c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x744>
100244420:     	ldr	x9, [sp, #0x1d8]
100244424:     	cbz	x9, 0x10024444c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x734>
100244428:     	lsl	x8, x9, #4
10024442c:     	add	x9, x8, x9
100244430:     	cmn	x9, #0x19
100244434:     	b.eq	0x10024444c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x734>
100244438:     	ldr	x9, [sp, #0x1d0]
10024443c:     	sub	x8, x9, x8
100244440:     	sub	x0, x8, #0x10
100244444:     	bl	0x100b5cd80 <_mi_free>
100244448:     	ldr	x2, [sp, #0x28]
10024444c:     	cbz	x22, 0x10024445c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x744>
100244450:     	ldr	x0, [sp, #0x1c0]
100244454:     	bl	0x100b5cd80 <_mi_free>
100244458:     	ldr	x2, [sp, #0x28]
10024445c:     	ldr	x8, [sp, #0x260]
100244460:     	add	x9, sp, #0x188
100244464:     	stur	x8, [x9, #0x80]
100244468:     	ldr	q2, [sp, #0x250]
10024446c:     	ldp	q0, q1, [sp, #0x210]
100244470:     	stp	q0, q1, [x9, #0x30]
100244474:     	ldp	q0, q1, [sp, #0x230]
100244478:     	stur	q0, [x9, #0x50]
10024447c:     	stp	q1, q2, [x9, #0x60]
100244480:     	ldr	x8, [sp, #0x1b8]
100244484:     	cmn	x8, #0x1
100244488:     	b.eq	0x100244b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe08>
10024448c:     	ldr	x1, [sp, #0x198]
100244490:     	b	0x100244098 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x380>
100244494:     	ldr	x12, [x24]
100244498:     	add	x13, x24, x2
10024449c:     	ldur	x13, [x13, #-0x8]
1002444a0:     	b	0x1002444c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
1002444a4:     	b.ne	0x1002444c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7a8>
1002444a8:     	ldrb	w12, [x24]
1002444ac:     	mov	x13, x12
1002444b0:     	b	0x1002444c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
1002444b4:     	ldrh	w12, [x24]
1002444b8:     	ldurb	w13, [x13, #-0x1]
1002444bc:     	b	0x1002444c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
1002444c0:     	mov	x12, #0x0               ; =0
1002444c4:     	mov	x13, #0x0               ; =0
1002444c8:     	eor	x10, x12, x10
1002444cc:     	eor	x9, x13, x9
1002444d0:     	mul	x12, x9, x10
1002444d4:     	umulh	x9, x9, x10
1002444d8:     	eor	x9, x9, x12
1002444dc:     	add	x10, x11, x8
1002444e0:     	eor	x9, x10, x9
1002444e4:     	ror	x11, x9, #0x29
1002444e8:     	mul	x9, x11, x8
1002444ec:     	umulh	x8, x11, x8
1002444f0:     	eor	x8, x8, x9
1002444f4:     	neg	w9, w11
1002444f8:     	ror	x28, x8, x9
1002444fc:     	ldr	x8, [sp, #0x1e8]
100244500:     	cbz	x8, 0x100244654 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x93c>
100244504:     	mov	x8, #0x0                ; =0
100244508:     	mov	x9, #0x7c15             ; =31765
10024450c:     	movk	x9, #0x7f4a, lsl #16
100244510:     	movk	x9, #0x79b9, lsl #32
100244514:     	movk	x9, #0x9e37, lsl #48
100244518:     	mul	x9, x28, x9
10024451c:     	eor	x11, x9, x9, lsr #32
100244520:     	lsr	x12, x9, #57
100244524:     	ldp	x10, x9, [sp, #0x1d0]
100244528:     	ldr	x26, [sp, #0x190]
10024452c:     	dup.8b	v0, w12
100244530:     	and	x11, x11, x9
100244534:     	ldr	d1, [x10, x11]
100244538:     	cmeq.8b	v2, v1, v0
10024453c:     	fmov	x12, d2
100244540:     	ands	x12, x12, #0x8080808080808080
100244544:     	b.eq	0x100244574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x85c>
100244548:     	rbit	x13, x12
10024454c:     	clz	x13, x13
100244550:     	add	x13, x11, x13, lsr #3
100244554:     	and	x13, x13, x9
100244558:     	sub	x13, x10, x13, lsl #4
10024455c:     	ldur	x14, [x13, #-0x10]
100244560:     	cmp	x28, x14
100244564:     	b.eq	0x1002445a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x890>
100244568:     	sub	x13, x12, #0x2
10024456c:     	ands	x12, x13, x12
100244570:     	b.ne	0x100244548 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x830>
100244574:     	movi.2d	v2, #0xffffffffffffffff
100244578:     	cmeq.8b	v1, v1, v2
10024457c:     	fmov	x12, d1
100244580:     	cbnz	x12, 0x100244654 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x93c>
100244584:     	add	x8, x8, #0x8
100244588:     	add	x11, x11, x8
10024458c:     	and	x11, x11, x9
100244590:     	ldr	d1, [x10, x11]
100244594:     	cmeq.8b	v2, v1, v0
100244598:     	fmov	x12, d2
10024459c:     	ands	x12, x12, #0x8080808080808080
1002445a0:     	b.ne	0x100244548 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x830>
1002445a4:     	b	0x100244574 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x85c>
1002445a8:     	ldur	x24, [x13, #-0x8]
1002445ac:     	cmp	x24, x1
1002445b0:     	b.hs	0x1002452a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x158c>
1002445b4:     	ldr	x8, [x26, x24, lsl #3]
1002445b8:     	ldr	w9, [x8, #0x4]
1002445bc:     	cmp	x2, x9
1002445c0:     	str	x1, [sp, #0x20]
1002445c4:     	b.ne	0x1002445e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8c8>
1002445c8:     	add	x0, x8, #0x14
1002445cc:     	ldr	x1, [sp, #0x18]
1002445d0:     	ldr	x2, [sp, #0x28]
1002445d4:     	bl	0x100b5fc20 <_writev+0x100b5fc20>
1002445d8:     	ldp	x1, x2, [sp, #0x20]
1002445dc:     	cbz	w0, 0x100244644 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x92c>
1002445e0:     	ldr	x8, [sp, #0x1c8]
1002445e4:     	cbz	x8, 0x100244654 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x93c>
1002445e8:     	ldr	x9, [sp, #0x1c0]
1002445ec:     	lsl	x23, x8, #4
1002445f0:     	add	x22, x9, #0x8
1002445f4:     	b	0x100244604 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8ec>
1002445f8:     	add	x22, x22, #0x10
1002445fc:     	subs	x23, x23, #0x10
100244600:     	b.eq	0x100244654 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x93c>
100244604:     	ldur	x8, [x22, #-0x8]
100244608:     	cmp	x8, x28
10024460c:     	b.ne	0x1002445f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8e0>
100244610:     	ldr	x24, [x22]
100244614:     	cmp	x24, x1
100244618:     	b.hs	0x100245294 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x157c>
10024461c:     	ldr	x8, [x26, x24, lsl #3]
100244620:     	ldr	w9, [x8, #0x4]
100244624:     	cmp	x2, x9
100244628:     	b.ne	0x1002445f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8e0>
10024462c:     	add	x0, x8, #0x14
100244630:     	ldr	x1, [sp, #0x18]
100244634:     	ldr	x2, [sp, #0x28]
100244638:     	bl	0x100b5fc20 <_writev+0x100b5fc20>
10024463c:     	ldp	x1, x2, [sp, #0x20]
100244640:     	cbnz	w0, 0x1002445f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8e0>
100244644:     	ldr	x1, [sp, #0x1b0]
100244648:     	cmp	x24, x1
10024464c:     	b.lo	0x100244bb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe98>
100244650:     	b	0x1002452d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15b8>
100244654:     	add	x0, x19, #0x20
100244658:     	mov	x22, x1
10024465c:     	ldr	x1, [sp, #0x18]
100244660:     	bl	0x1005e8a84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction22string_from_json_bytes>
100244664:     	mov	x24, x0
100244668:     	add	x8, sp, #0x188
10024466c:     	add	x0, x8, #0x30
100244670:     	mov	x1, x28
100244674:     	mov	x2, x22
100244678:     	bl	0x10028688c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
10024467c:     	ldr	x22, [sp, #0x198]
100244680:     	ldr	x8, [sp, #0x188]
100244684:     	cmp	x22, x8
100244688:     	b.eq	0x100244ca4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf8c>
10024468c:     	ldr	x8, [sp, #0x190]
100244690:     	str	x24, [x8, x22, lsl #3]
100244694:     	add	x8, x22, #0x1
100244698:     	str	x8, [sp, #0x198]
10024469c:     	ldr	x22, [sp, #0x1b0]
1002446a0:     	ldr	x8, [sp, #0x1a0]
1002446a4:     	cmp	x22, x8
1002446a8:     	b.eq	0x100244cb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf98>
1002446ac:     	ldr	x28, [sp, #0x1a8]
1002446b0:     	ldr	x8, [sp, #0x10]
1002446b4:     	str	x8, [x28, x22, lsl #3]
1002446b8:     	add	x1, x22, #0x1
1002446bc:     	str	x1, [sp, #0x1b0]
1002446c0:     	b	0x100244bbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xea4>
1002446c4:     	ldr	x0, [sp, #0x98]
1002446c8:     	cmp	x0, #0x8
1002446cc:     	b.hs	0x1002452f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15d8>
1002446d0:     	ldr	x8, [sp, #0x68]
1002446d4:     	ldr	x23, [x8, x0, lsl #3]
1002446d8:     	ldr	w8, [x23, #0x4]
1002446dc:     	cmp	x1, x8
1002446e0:     	b.ne	0x100244700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9e8>
1002446e4:     	add	x0, x23, #0x14
1002446e8:     	mov	x1, x24
1002446ec:     	ldr	x2, [sp, #0x28]
1002446f0:     	bl	0x100b5fc20 <_writev+0x100b5fc20>
1002446f4:     	ldr	x1, [sp, #0x28]
1002446f8:     	ldr	w11, [sp, #0x7c]
1002446fc:     	cbz	w0, 0x100244cc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfa8>
100244700:     	mov	x0, x24
100244704:     	bl	0x100325dbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100244708:     	mov	x10, x0
10024470c:     	mov	w11, #0x0               ; =0
100244710:     	mov	w8, #0x0                ; =0
100244714:     	ldp	x1, x9, [sp, #0x90]
100244718:     	cmp	x9, #0x0
10024471c:     	str	w8, [sp, #0x84]
100244720:     	csinc	w23, w8, wzr, ne
100244724:     	cmp	x1, #0x9
100244728:     	b.hs	0x100245238 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1520>
10024472c:     	ldr	x2, [sp, #0x28]
100244730:     	cbz	x1, 0x100244ac4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100244734:     	ldr	x8, [sp, #0x100]
100244738:     	cmp	x8, x10
10024473c:     	b.eq	0x100244afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde4>
100244740:     	tbnz	w23, #0x0, 0x10024477c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa64>
100244744:     	ldr	w9, [x8, #0x4]
100244748:     	cmp	x2, x9
10024474c:     	b.ne	0x10024477c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa64>
100244750:     	add	x0, x8, #0x14
100244754:     	mov	x1, x24
100244758:     	ldr	x2, [sp, #0x28]
10024475c:     	str	w11, [sp, #0x7c]
100244760:     	mov	x24, x10
100244764:     	bl	0x100b5fc20 <_writev+0x100b5fc20>
100244768:     	mov	x10, x24
10024476c:     	ldr	x2, [sp, #0x28]
100244770:     	ldr	w11, [sp, #0x7c]
100244774:     	ldr	x24, [sp, #0x18]
100244778:     	cbz	w0, 0x100244afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde4>
10024477c:     	ldr	x1, [sp, #0x90]
100244780:     	cmp	x1, #0x1
100244784:     	b.eq	0x100244ac4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100244788:     	ldr	x9, [sp, #0x108]
10024478c:     	add	x8, sp, #0x148
100244790:     	add	x8, x8, #0x8
100244794:     	cmp	x9, x10
100244798:     	b.eq	0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
10024479c:     	tbnz	w23, #0x0, 0x1002447e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xac8>
1002447a0:     	ldr	w8, [x9, #0x4]
1002447a4:     	cmp	x2, x8
1002447a8:     	b.ne	0x1002447e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xac8>
1002447ac:     	add	x0, x9, #0x14
1002447b0:     	mov	x1, x24
1002447b4:     	ldr	x2, [sp, #0x28]
1002447b8:     	str	w11, [sp, #0x7c]
1002447bc:     	mov	x24, x10
1002447c0:     	bl	0x100b5fc20 <_writev+0x100b5fc20>
1002447c4:     	mov	x10, x24
1002447c8:     	ldr	x2, [sp, #0x28]
1002447cc:     	ldr	w11, [sp, #0x7c]
1002447d0:     	ldr	x24, [sp, #0x18]
1002447d4:     	add	x8, sp, #0x148
1002447d8:     	add	x8, x8, #0x8
1002447dc:     	cbz	w0, 0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
1002447e0:     	ldr	x1, [sp, #0x90]
1002447e4:     	cmp	x1, #0x2
1002447e8:     	b.eq	0x100244ac4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
1002447ec:     	ldr	x9, [sp, #0x110]
1002447f0:     	add	x8, sp, #0x148
1002447f4:     	add	x8, x8, #0x10
1002447f8:     	cmp	x9, x10
1002447fc:     	b.eq	0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100244800:     	tbnz	w23, #0x0, 0x100244844 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb2c>
100244804:     	ldr	w8, [x9, #0x4]
100244808:     	cmp	x2, x8
10024480c:     	b.ne	0x100244844 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb2c>
100244810:     	add	x0, x9, #0x14
100244814:     	mov	x1, x24
100244818:     	ldr	x2, [sp, #0x28]
10024481c:     	str	w11, [sp, #0x7c]
100244820:     	mov	x24, x10
100244824:     	bl	0x100b5fc20 <_writev+0x100b5fc20>
100244828:     	mov	x10, x24
10024482c:     	ldr	x2, [sp, #0x28]
100244830:     	ldr	w11, [sp, #0x7c]
100244834:     	ldr	x24, [sp, #0x18]
100244838:     	add	x8, sp, #0x148
10024483c:     	add	x8, x8, #0x10
100244840:     	cbz	w0, 0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100244844:     	ldr	x1, [sp, #0x90]
100244848:     	cmp	x1, #0x3
10024484c:     	b.eq	0x100244ac4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100244850:     	ldr	x9, [sp, #0x118]
100244854:     	add	x8, sp, #0x148
100244858:     	add	x8, x8, #0x18
10024485c:     	cmp	x9, x10
100244860:     	b.eq	0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100244864:     	tbnz	w23, #0x0, 0x1002448a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb90>
100244868:     	ldr	w8, [x9, #0x4]
10024486c:     	cmp	x2, x8
100244870:     	b.ne	0x1002448a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb90>
100244874:     	add	x0, x9, #0x14
100244878:     	mov	x1, x24
10024487c:     	ldr	x2, [sp, #0x28]
100244880:     	str	w11, [sp, #0x7c]
100244884:     	mov	x24, x10
100244888:     	bl	0x100b5fc20 <_writev+0x100b5fc20>
10024488c:     	mov	x10, x24
100244890:     	ldr	x2, [sp, #0x28]
100244894:     	ldr	w11, [sp, #0x7c]
100244898:     	ldr	x24, [sp, #0x18]
10024489c:     	add	x8, sp, #0x148
1002448a0:     	add	x8, x8, #0x18
1002448a4:     	cbz	w0, 0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
1002448a8:     	ldr	x1, [sp, #0x90]
1002448ac:     	cmp	x1, #0x4
1002448b0:     	b.eq	0x100244ac4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
1002448b4:     	ldr	x9, [sp, #0x120]
1002448b8:     	add	x8, sp, #0x148
1002448bc:     	add	x8, x8, #0x20
1002448c0:     	cmp	x9, x10
1002448c4:     	b.eq	0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
1002448c8:     	tbnz	w23, #0x0, 0x10024490c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbf4>
1002448cc:     	ldr	w8, [x9, #0x4]
1002448d0:     	cmp	x2, x8
1002448d4:     	b.ne	0x10024490c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbf4>
1002448d8:     	add	x0, x9, #0x14
1002448dc:     	mov	x1, x24
1002448e0:     	ldr	x2, [sp, #0x28]
1002448e4:     	str	w11, [sp, #0x7c]
1002448e8:     	mov	x24, x10
1002448ec:     	bl	0x100b5fc20 <_writev+0x100b5fc20>
1002448f0:     	mov	x10, x24
1002448f4:     	ldr	x2, [sp, #0x28]
1002448f8:     	ldr	w11, [sp, #0x7c]
1002448fc:     	ldr	x24, [sp, #0x18]
100244900:     	add	x8, sp, #0x148
100244904:     	add	x8, x8, #0x20
100244908:     	cbz	w0, 0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
10024490c:     	ldr	x1, [sp, #0x90]
100244910:     	cmp	x1, #0x5
100244914:     	b.eq	0x100244ac4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100244918:     	ldr	x9, [sp, #0x128]
10024491c:     	add	x8, sp, #0x148
100244920:     	add	x8, x8, #0x28
100244924:     	cmp	x9, x10
100244928:     	b.eq	0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
10024492c:     	tbnz	w23, #0x0, 0x100244970 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xc58>
100244930:     	ldr	w8, [x9, #0x4]
100244934:     	cmp	x2, x8
100244938:     	b.ne	0x100244970 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xc58>
10024493c:     	add	x0, x9, #0x14
100244940:     	mov	x1, x24
100244944:     	ldr	x2, [sp, #0x28]
100244948:     	str	w11, [sp, #0x7c]
10024494c:     	mov	x24, x10
100244950:     	bl	0x100b5fc20 <_writev+0x100b5fc20>
100244954:     	mov	x10, x24
100244958:     	ldr	x2, [sp, #0x28]
10024495c:     	ldr	w11, [sp, #0x7c]
100244960:     	ldr	x24, [sp, #0x18]
100244964:     	add	x8, sp, #0x148
100244968:     	add	x8, x8, #0x28
10024496c:     	cbz	w0, 0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100244970:     	ldr	x1, [sp, #0x90]
100244974:     	cmp	x1, #0x6
100244978:     	b.eq	0x100244ac4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
10024497c:     	ldr	x9, [sp, #0x130]
100244980:     	add	x8, sp, #0x148
100244984:     	add	x8, x8, #0x30
100244988:     	cmp	x9, x10
10024498c:     	b.eq	0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100244990:     	tbnz	w23, #0x0, 0x1002449d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xcbc>
100244994:     	ldr	w8, [x9, #0x4]
100244998:     	cmp	x2, x8
10024499c:     	b.ne	0x1002449d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xcbc>
1002449a0:     	add	x0, x9, #0x14
1002449a4:     	mov	x1, x24
1002449a8:     	ldr	x2, [sp, #0x28]
1002449ac:     	str	w11, [sp, #0x7c]
1002449b0:     	mov	x24, x10
1002449b4:     	bl	0x100b5fc20 <_writev+0x100b5fc20>
1002449b8:     	mov	x10, x24
1002449bc:     	ldr	x2, [sp, #0x28]
1002449c0:     	ldr	w11, [sp, #0x7c]
1002449c4:     	ldr	x24, [sp, #0x18]
1002449c8:     	add	x8, sp, #0x148
1002449cc:     	add	x8, x8, #0x30
1002449d0:     	cbz	w0, 0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
1002449d4:     	ldr	x1, [sp, #0x90]
1002449d8:     	cmp	x1, #0x7
1002449dc:     	b.eq	0x100244ac4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
1002449e0:     	ldr	x9, [sp, #0x138]
1002449e4:     	add	x8, sp, #0x148
1002449e8:     	add	x8, x8, #0x38
1002449ec:     	cmp	x9, x10
1002449f0:     	b.eq	0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
1002449f4:     	tbnz	w23, #0x0, 0x100244a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd14>
1002449f8:     	ldr	w8, [x9, #0x4]
1002449fc:     	cmp	x2, x8
100244a00:     	b.ne	0x100244a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd14>
100244a04:     	add	x0, x9, #0x14
100244a08:     	mov	x1, x24
100244a0c:     	str	w11, [sp, #0x7c]
100244a10:     	mov	x23, x10
100244a14:     	bl	0x100b5fc20 <_writev+0x100b5fc20>
100244a18:     	mov	x10, x23
100244a1c:     	ldr	w11, [sp, #0x7c]
100244a20:     	add	x8, sp, #0x148
100244a24:     	add	x8, x8, #0x38
100244a28:     	cbz	w0, 0x100244b00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xde8>
100244a2c:     	ldr	x1, [sp, #0x90]
100244a30:     	cmp	x1, #0x8
100244a34:     	b.ne	0x100244ac4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdac>
100244a38:     	mov	x24, x10
100244a3c:     	str	w11, [sp, #0x7c]
100244a40:     	mov	x23, x22
100244a44:     	mov	w0, #0x80               ; =128
100244a48:     	bl	0x100b5d008 <_mi_malloc_aligned>
100244a4c:     	cbz	x0, 0x100245300 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15e8>
100244a50:     	mov	x22, x0
100244a54:     	mov	w0, #0x80               ; =128
100244a58:     	mov	w1, #0x8                ; =8
100244a5c:     	bl	0x100b5d008 <_mi_malloc_aligned>
100244a60:     	cbz	x0, 0x100245300 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15e8>
100244a64:     	mov	x28, x0
100244a68:     	ldp	q0, q1, [sp, #0x100]
100244a6c:     	stp	q0, q1, [x22]
100244a70:     	ldp	q0, q1, [sp, #0x120]
100244a74:     	stp	q0, q1, [x22, #0x20]
100244a78:     	add	x9, sp, #0x148
100244a7c:     	ldp	q0, q1, [x9]
100244a80:     	stp	q0, q1, [x0]
100244a84:     	ldp	q0, q1, [x9, #0x20]
100244a88:     	stp	q0, q1, [x0, #0x20]
100244a8c:     	str	x24, [x22, #0x40]
100244a90:     	ldr	x8, [sp, #0x10]
100244a94:     	str	x8, [x0, #0x40]
100244a98:     	mov	w8, #0x10               ; =16
100244a9c:     	stp	x8, x22, [sp, #0x188]
100244aa0:     	ldp	q0, q1, [sp, #0x30]
100244aa4:     	str	q1, [x9, #0x50]
100244aa8:     	str	x0, [sp, #0x1a8]
100244aac:     	mov	w8, #0x8                ; =8
100244ab0:     	str	x8, [sp, #0x90]
100244ab4:     	stur	q0, [x9, #0x68]
100244ab8:     	mov	w1, #0x9                ; =9
100244abc:     	mov	x22, x23
100244ac0:     	b	0x100244bc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xea8>
100244ac4:     	add	x8, sp, #0x100
100244ac8:     	str	x10, [x8, x1, lsl #3]
100244acc:     	add	x8, sp, #0x148
100244ad0:     	ldr	x9, [sp, #0x10]
100244ad4:     	str	x9, [x8, x1, lsl #3]
100244ad8:     	add	x8, x1, #0x1
100244adc:     	str	x8, [sp, #0x70]
100244ae0:     	str	x8, [sp, #0x90]
100244ae4:     	ldr	x1, [sp, #0x20]
100244ae8:     	ldp	x23, x8, [x19, #0x68]
100244aec:     	cmp	x8, x23
100244af0:     	str	x1, [sp, #0x20]
100244af4:     	b.lo	0x100244bd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec0>
100244af8:     	b	0x100244c58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100244afc:     	add	x8, sp, #0x148
100244b00:     	ldr	x9, [sp, #0x10]
100244b04:     	str	x9, [x8]
100244b08:     	ldr	x1, [sp, #0x20]
100244b0c:     	ldp	x23, x8, [x19, #0x68]
100244b10:     	cmp	x8, x23
100244b14:     	str	x1, [sp, #0x20]
100244b18:     	b.lo	0x100244bd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec0>
100244b1c:     	b	0x100244c58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100244b20:     	ldp	x26, x8, [sp, #0x190]
100244b24:     	str	x8, [sp, #0x20]
100244b28:     	mov	x0, x24
100244b2c:     	mov	x1, x2
100244b30:     	bl	0x100325dbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100244b34:     	mov	x28, x0
100244b38:     	ldr	x8, [sp, #0x98]
100244b3c:     	cmp	x8, #0x0
100244b40:     	cset	w8, eq
100244b44:     	ldr	x12, [sp, #0x20]
100244b48:     	cbz	x12, 0x100244c04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xeec>
100244b4c:     	mov	x24, #0x0               ; =0
100244b50:     	ldr	w9, [sp, #0x84]
100244b54:     	orr	w22, w8, w9
100244b58:     	lsl	x23, x12, #3
100244b5c:     	b	0x100244b6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe54>
100244b60:     	add	x24, x24, #0x1
100244b64:     	subs	x23, x23, #0x8
100244b68:     	b.eq	0x100244c04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xeec>
100244b6c:     	ldr	x8, [x26, x24, lsl #3]
100244b70:     	cmp	x8, x28
100244b74:     	b.eq	0x100244ba4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe8c>
100244b78:     	tbnz	w22, #0x0, 0x100244b60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe48>
100244b7c:     	ldr	w9, [x8, #0x4]
100244b80:     	ldr	x10, [sp, #0x28]
100244b84:     	cmp	x10, x9
100244b88:     	b.ne	0x100244b60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe48>
100244b8c:     	add	x0, x8, #0x14
100244b90:     	ldr	x1, [sp, #0x18]
100244b94:     	ldr	x2, [sp, #0x28]
100244b98:     	bl	0x100b5fc20 <_writev+0x100b5fc20>
100244b9c:     	ldr	x12, [sp, #0x20]
100244ba0:     	cbnz	w0, 0x100244b60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe48>
100244ba4:     	ldr	x1, [sp, #0x1b0]
100244ba8:     	cmp	x24, x1
100244bac:     	b.hs	0x1002452c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15a8>
100244bb0:     	ldr	x28, [sp, #0x1a8]
100244bb4:     	ldr	x8, [sp, #0x10]
100244bb8:     	str	x8, [x28, x24, lsl #3]
100244bbc:     	ldr	x22, [sp, #0x8]
100244bc0:     	ldr	w11, [sp, #0x7c]
100244bc4:     	ldr	x24, [sp, #0x18]
100244bc8:     	ldp	x23, x8, [x19, #0x68]
100244bcc:     	cmp	x8, x23
100244bd0:     	str	x1, [sp, #0x20]
100244bd4:     	b.hs	0x100244c58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100244bd8:     	ldr	x9, [x19, #0x60]
100244bdc:     	ldrb	w10, [x9, x8]
100244be0:     	cmp	w10, #0x20
100244be4:     	b.hi	0x100244c58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100244be8:     	lsr	x10, x25, x10
100244bec:     	tbz	w10, #0x0, 0x100244c58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf40>
100244bf0:     	add	x8, x8, #0x1
100244bf4:     	str	x8, [x19, #0x70]
100244bf8:     	cmp	x23, x8
100244bfc:     	b.ne	0x100244bdc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec4>
100244c00:     	b	0x100244d40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
100244c04:     	ldr	x8, [sp, #0x188]
100244c08:     	cmp	x12, x8
100244c0c:     	ldr	w11, [sp, #0x7c]
100244c10:     	b.eq	0x100244ccc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfb4>
100244c14:     	str	x28, [x26, x12, lsl #3]
100244c18:     	add	x8, x12, #0x1
100244c1c:     	str	x8, [sp, #0x198]
100244c20:     	ldr	x22, [sp, #0x1b0]
100244c24:     	ldr	x8, [sp, #0x1a0]
100244c28:     	cmp	x22, x8
100244c2c:     	b.eq	0x100244ce8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfd0>
100244c30:     	ldr	x28, [sp, #0x1a8]
100244c34:     	ldp	x8, x24, [sp, #0x10]
100244c38:     	str	x8, [x28, x22, lsl #3]
100244c3c:     	add	x1, x22, #0x1
100244c40:     	str	x1, [sp, #0x1b0]
100244c44:     	ldr	x22, [sp, #0x8]
100244c48:     	ldp	x23, x8, [x19, #0x68]
100244c4c:     	cmp	x8, x23
100244c50:     	str	x1, [sp, #0x20]
100244c54:     	b.lo	0x100244bd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec0>
100244c58:     	cmp	x8, x23
100244c5c:     	b.hs	0x100244d40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
100244c60:     	ldr	x9, [x19, #0x60]
100244c64:     	ldrb	w9, [x9, x8]
100244c68:     	cmp	w9, #0x2c
100244c6c:     	b.ne	0x100244d40 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
100244c70:     	add	x24, x8, #0x1
100244c74:     	str	x24, [x19, #0x70]
100244c78:     	cmp	x27, #0x1
100244c7c:     	ldr	x27, [sp, #0x98]
100244c80:     	ldp	w26, w8, [sp, #0x80]
100244c84:     	b.lt	0x100243ee8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0>
100244c88:     	ldr	x0, [sp, #0x18]
100244c8c:     	mov	x23, x11
100244c90:     	bl	0x100b5cd80 <_mi_free>
100244c94:     	mov	x11, x23
100244c98:     	ldr	w8, [sp, #0x84]
100244c9c:     	ldp	x23, x24, [x19, #0x68]
100244ca0:     	b	0x100243ee8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0>
100244ca4:     	add	x0, sp, #0x188
100244ca8:     	bl	0x100b39aac <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100244cac:     	b	0x10024468c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x974>
100244cb0:     	add	x8, sp, #0x188
100244cb4:     	add	x0, x8, #0x18
100244cb8:     	bl	0x100b39aac <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100244cbc:     	b	0x1002446ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x994>
100244cc0:     	mov	x10, x23
100244cc4:     	ldr	x0, [sp, #0x98]
100244cc8:     	b	0x10024416c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x454>
100244ccc:     	add	x0, sp, #0x188
100244cd0:     	mov	x22, x11
100244cd4:     	bl	0x100b39aac <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100244cd8:     	ldr	x12, [sp, #0x20]
100244cdc:     	mov	x11, x22
100244ce0:     	ldr	x26, [sp, #0x190]
100244ce4:     	b	0x100244c14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xefc>
100244ce8:     	add	x8, sp, #0x188
100244cec:     	add	x0, x8, #0x18
100244cf0:     	mov	x23, x11
100244cf4:     	bl	0x100b39aac <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100244cf8:     	mov	x11, x23
100244cfc:     	b	0x100244c30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf18>
100244d00:     	adrp	x0, 0x10104d000 <_out_buf+0x3a48>
100244d04:     	add	x0, x0, #0x780
100244d08:     	bl	0x100b1f580 <__RINvMs1_NtNtCs4KWsSNcQanT_9once_cell4race8once_boxINtB6_7OnceBoxINtNtCsctvjasLqLe9_5alloc5boxed3BoxDNtNtCs3SoQS4yp3pP_5ahash12random_state12RandomSourceNtNtCsjgY6bXVaRmE_4core6marker4SendNtB2s_4SyncEL_EE4initNtNvMs1_B6_IBN_pE11get_or_init4VoidNCINvB2_11get_or_initNCNvB1C_7get_src0E0ECs3gRpqoBkMHm_13perry_runtime>
100244d0c:     	ldp	x0, x22, [x0]
100244d10:     	adrp	x8, 0x10104d000 <_out_buf+0x3a48>
100244d14:     	add	x8, x8, #0x788
100244d18:     	ldapr	x24, [x8]
100244d1c:     	cbnz	x24, 0x1002441c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x4ac>
100244d20:     	mov	x23, x0
100244d24:     	adrp	x0, 0x10104d000 <_out_buf+0x3a48>
100244d28:     	add	x0, x0, #0x788
100244d2c:     	bl	0x100b1f4c0 <__RINvMs1_NtNtCs4KWsSNcQanT_9once_cell4race8once_boxINtB6_7OnceBoxAAyj4_j2_E4initNtNvMs1_B6_IBN_pE11get_or_init4VoidNCINvB2_11get_or_initNCNvNtCs3SoQS4yp3pP_5ahash12random_state15get_fixed_seeds0E0ECs3gRpqoBkMHm_13perry_runtime>
100244d30:     	mov	x24, x0
100244d34:     	mov	x0, x23
100244d38:     	b	0x1002441c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x4ac>
100244d3c:     	strb	wzr, [x19, #0xd4]
100244d40:     	cmp	x27, #0x1
100244d44:     	b.lt	0x100244d50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1038>
100244d48:     	mov	x0, x24
100244d4c:     	bl	0x100b5cd80 <_mi_free>
100244d50:     	ldr	x26, [sp, #0x98]
100244d54:     	ldp	x9, x8, [x19, #0x68]
100244d58:     	cmp	x8, x9
100244d5c:     	b.hs	0x100244de4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10cc>
100244d60:     	ldr	x10, [x19, #0x60]
100244d64:     	mov	x11, #0x2600            ; =9728
100244d68:     	movk	x11, #0x1, lsl #32
100244d6c:     	ldrb	w12, [x10, x8]
100244d70:     	cmp	w12, #0x20
100244d74:     	b.hi	0x100244d94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x107c>
100244d78:     	lsr	x13, x11, x12
100244d7c:     	tbz	w13, #0x0, 0x100244d94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x107c>
100244d80:     	add	x8, x8, #0x1
100244d84:     	str	x8, [x19, #0x70]
100244d88:     	cmp	x9, x8
100244d8c:     	b.ne	0x100244d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1054>
100244d90:     	b	0x100244de4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10cc>
100244d94:     	cmp	w12, #0x7d
100244d98:     	b.ne	0x100244de4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10cc>
100244d9c:     	add	x8, x8, #0x1
100244da0:     	str	x8, [x19, #0x70]
100244da4:     	ldr	x8, [sp, #0x188]
100244da8:     	cmn	x8, #0x1
100244dac:     	b.ne	0x100244df4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10dc>
100244db0:     	ldp	w8, w9, [sp, #0x80]
100244db4:     	and	w8, w8, w9
100244db8:     	tbz	w8, #0x0, 0x100244ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1190>
100244dbc:     	ldr	x8, [sp, #0x70]
100244dc0:     	cmp	x21, x8
100244dc4:     	b.ne	0x100244ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1190>
100244dc8:     	cmp	x26, x21
100244dcc:     	b.ne	0x100244ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1190>
100244dd0:     	ldp	x21, x23, [sp, #0x88]
100244dd4:     	cmp	x23, #0x9
100244dd8:     	ldr	w2, [sp, #0x64]
100244ddc:     	b.lo	0x100244f98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1280>
100244de0:     	b	0x100244e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1154>
100244de4:     	strb	wzr, [x19, #0xd4]
100244de8:     	ldr	x8, [sp, #0x188]
100244dec:     	cmn	x8, #0x1
100244df0:     	b.eq	0x100244db0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1098>
100244df4:     	ldp	x0, x1, [sp, #0x190]
100244df8:     	cmp	x1, #0x9
100244dfc:     	b.hs	0x100244e84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x116c>
100244e00:     	ldr	x8, [x19, #0x78]
100244e04:     	cmp	x1, x8
100244e08:     	ldr	x23, [sp, #0x90]
100244e0c:     	b.ne	0x100244e2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100244e10:     	ldr	x21, [x19, #0xc0]
100244e14:     	cbz	x21, 0x100244e2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100244e18:     	cbz	x1, 0x100244f78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100244e1c:     	ldr	x8, [x19, #0x80]
100244e20:     	ldr	x9, [x0]
100244e24:     	cmp	x8, x9
100244e28:     	b.eq	0x100244f70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1258>
100244e2c:     	mov	x24, x0
100244e30:     	mov	x25, x1
100244e34:     	bl	0x10032749c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100244e38:     	mov	x21, x0
100244e3c:     	mov	x26, x1
100244e40:     	str	x25, [x19, #0x78]
100244e44:     	lsl	x2, x25, #3
100244e48:     	add	x0, x19, #0x80
100244e4c:     	mov	x1, x24
100244e50:     	bl	0x100b5fc2c <_writev+0x100b5fc2c>
100244e54:     	mov	x2, x26
100244e58:     	str	x21, [x19, #0xc0]
100244e5c:     	str	w26, [x19, #0xd0]
100244e60:     	cmp	x23, #0x9
100244e64:     	ldr	x8, [sp, #0x20]
100244e68:     	b.lo	0x100244ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1188>
100244e6c:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100244e70:     	add	x3, x3, #0x710
100244e74:     	mov	x0, #0x0                ; =0
100244e78:     	mov	x1, x23
100244e7c:     	mov	w2, #0x8                ; =8
100244e80:     	bl	0x100b1080c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100244e84:     	bl	0x10032749c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100244e88:     	mov	x21, x0
100244e8c:     	mov	x2, x1
100244e90:     	ldr	x23, [sp, #0x90]
100244e94:     	cmp	x23, #0x9
100244e98:     	ldr	x8, [sp, #0x20]
100244e9c:     	b.hs	0x100244e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1154>
100244ea0:     	mov	x23, x8
100244ea4:     	b	0x100244f9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1284>
100244ea8:     	ldr	x23, [sp, #0x90]
100244eac:     	cmp	x23, #0x9
100244eb0:     	b.hs	0x10024520c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14f4>
100244eb4:     	ldr	x8, [x19, #0x78]
100244eb8:     	cmp	x23, x8
100244ebc:     	b.ne	0x100244edc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100244ec0:     	ldr	x21, [x19, #0xc0]
100244ec4:     	cbz	x21, 0x100244edc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100244ec8:     	cbz	x23, 0x100244f94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
100244ecc:     	ldr	x8, [x19, #0x80]
100244ed0:     	ldr	x9, [sp, #0x100]
100244ed4:     	cmp	x8, x9
100244ed8:     	b.eq	0x100244f8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1274>
100244edc:     	add	x0, sp, #0x100
100244ee0:     	mov	x1, x23
100244ee4:     	bl	0x10032749c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100244ee8:     	mov	x21, x0
100244eec:     	mov	x24, x1
100244ef0:     	str	x23, [x19, #0x78]
100244ef4:     	lsl	x2, x23, #3
100244ef8:     	add	x0, x19, #0x80
100244efc:     	add	x1, sp, #0x100
100244f00:     	bl	0x100b5fc2c <_writev+0x100b5fc2c>
100244f04:     	mov	x2, x24
100244f08:     	str	x21, [x19, #0xc0]
100244f0c:     	str	w24, [x19, #0xd0]
100244f10:     	b	0x100244f98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1280>
100244f14:     	b	0x100243e04 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xec>
100244f18:     	sub	x0, x29, #0x68
100244f1c:     	mov	x1, #0x0                ; =0
100244f20:     	bl	0x10032749c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100244f24:     	mov	x2, x1
100244f28:     	mov	x1, x0
100244f2c:     	str	xzr, [x19, #0x78]
100244f30:     	str	x0, [x19, #0xc0]
100244f34:     	str	w2, [x19, #0xd0]
100244f38:     	add	x0, x19, #0x20
100244f3c:     	mov	w3, #0x8                ; =8
100244f40:     	mov	x4, #0x0                ; =0
100244f44:     	bl	0x1005ba348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100244f48:     	mov	x19, x0
100244f4c:     	ldrb	w8, [x20, #0x20]
100244f50:     	cbnz	w8, 0x100245224 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x150c>
100244f54:     	ldr	x8, [x20]
100244f58:     	cbnz	x8, 0x100245268 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1550>
100244f5c:     	ldr	x8, [x20, #0x18]
100244f60:     	cmp	x22, x8
100244f64:     	b.hi	0x10024503c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
100244f68:     	str	x22, [x20, #0x18]
100244f6c:     	b	0x10024503c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
100244f70:     	cmp	x1, #0x1
100244f74:     	b.ne	0x100245064 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x134c>
100244f78:     	ldr	w2, [x19, #0xd0]
100244f7c:     	cmp	x23, #0x9
100244f80:     	ldr	x8, [sp, #0x20]
100244f84:     	b.lo	0x100244ea0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1188>
100244f88:     	b	0x100244e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1154>
100244f8c:     	cmp	x23, #0x1
100244f90:     	b.ne	0x100245108 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x13f0>
100244f94:     	ldr	w2, [x19, #0xd0]
100244f98:     	add	x28, sp, #0x148
100244f9c:     	add	x0, x19, #0x20
100244fa0:     	mov	x1, x21
100244fa4:     	mov	x3, x28
100244fa8:     	mov	x4, x23
100244fac:     	bl	0x1005ba348 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100244fb0:     	mov	x19, x0
100244fb4:     	ldrb	w8, [x20, #0x20]
100244fb8:     	cbnz	w8, 0x1002451e4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14cc>
100244fbc:     	ldr	x8, [x20]
100244fc0:     	cbnz	x8, 0x100245268 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1550>
100244fc4:     	ldr	x8, [x20, #0x18]
100244fc8:     	cmp	x22, x8
100244fcc:     	b.hi	0x100244fd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x12bc>
100244fd0:     	str	x22, [x20, #0x18]
100244fd4:     	ldr	x8, [sp, #0x188]
100244fd8:     	cmn	x8, #0x1
100244fdc:     	b.eq	0x10024503c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
100244fe0:     	cbz	x8, 0x100244fec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x12d4>
100244fe4:     	ldr	x0, [sp, #0x190]
100244fe8:     	bl	0x100b5cd80 <_mi_free>
100244fec:     	ldr	x8, [sp, #0x1a0]
100244ff0:     	cbz	x8, 0x100244ffc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x12e4>
100244ff4:     	ldr	x0, [sp, #0x1a8]
100244ff8:     	bl	0x100b5cd80 <_mi_free>
100244ffc:     	ldr	x20, [sp, #0x1b8]
100245000:     	cmn	x20, #0x1
100245004:     	b.eq	0x10024503c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
100245008:     	ldr	x9, [sp, #0x1d8]
10024500c:     	cbz	x9, 0x100245030 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1318>
100245010:     	lsl	x8, x9, #4
100245014:     	add	x9, x8, x9
100245018:     	cmn	x9, #0x19
10024501c:     	b.eq	0x100245030 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1318>
100245020:     	ldr	x9, [sp, #0x1d0]
100245024:     	sub	x8, x9, x8
100245028:     	sub	x0, x8, #0x10
10024502c:     	bl	0x100b5cd80 <_mi_free>
100245030:     	cbz	x20, 0x10024503c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1324>
100245034:     	ldr	x0, [sp, #0x1c0]
100245038:     	bl	0x100b5cd80 <_mi_free>
10024503c:     	mov	x0, #0x7ffd000000000000 ; =9222527611924643840
100245040:     	bfxil	x0, x19, #0, #48
100245044:     	add	sp, sp, #0x2e0
100245048:     	ldp	x29, x30, [sp, #0x50]
10024504c:     	ldp	x20, x19, [sp, #0x40]
100245050:     	ldp	x22, x21, [sp, #0x30]
100245054:     	ldp	x24, x23, [sp, #0x20]
100245058:     	ldp	x26, x25, [sp, #0x10]
10024505c:     	ldp	x28, x27, [sp], #0x60
100245060:     	ret
100245064:     	ldr	x8, [x19, #0x88]
100245068:     	ldr	x9, [x0, #0x8]
10024506c:     	cmp	x8, x9
100245070:     	b.ne	0x100244e2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100245074:     	cmp	x1, #0x2
100245078:     	b.eq	0x100244f78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
10024507c:     	ldr	x8, [x19, #0x90]
100245080:     	ldr	x9, [x0, #0x10]
100245084:     	cmp	x8, x9
100245088:     	b.ne	0x100244e2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
10024508c:     	cmp	x1, #0x3
100245090:     	b.eq	0x100244f78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100245094:     	ldr	x8, [x19, #0x98]
100245098:     	ldr	x9, [x0, #0x18]
10024509c:     	cmp	x8, x9
1002450a0:     	b.ne	0x100244e2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
1002450a4:     	cmp	x1, #0x4
1002450a8:     	b.eq	0x100244f78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
1002450ac:     	ldr	x8, [x19, #0xa0]
1002450b0:     	ldr	x9, [x0, #0x20]
1002450b4:     	cmp	x8, x9
1002450b8:     	b.ne	0x100244e2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
1002450bc:     	cmp	x1, #0x5
1002450c0:     	b.eq	0x100244f78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
1002450c4:     	ldr	x8, [x19, #0xa8]
1002450c8:     	ldr	x9, [x0, #0x28]
1002450cc:     	cmp	x8, x9
1002450d0:     	b.ne	0x100244e2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
1002450d4:     	cmp	x1, #0x6
1002450d8:     	b.eq	0x100244f78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
1002450dc:     	ldr	x8, [x19, #0xb0]
1002450e0:     	ldr	x9, [x0, #0x30]
1002450e4:     	cmp	x8, x9
1002450e8:     	b.ne	0x100244e2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
1002450ec:     	cmp	x1, #0x7
1002450f0:     	b.eq	0x100244f78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
1002450f4:     	ldr	x8, [x19, #0xb8]
1002450f8:     	ldr	x9, [x0, #0x38]
1002450fc:     	cmp	x8, x9
100245100:     	b.ne	0x100244e2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1114>
100245104:     	b	0x100244f78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1260>
100245108:     	ldr	x8, [x19, #0x88]
10024510c:     	ldr	x9, [sp, #0x108]
100245110:     	cmp	x8, x9
100245114:     	b.ne	0x100244edc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100245118:     	cmp	x23, #0x2
10024511c:     	b.eq	0x100244f94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
100245120:     	ldr	x8, [x19, #0x90]
100245124:     	ldr	x9, [sp, #0x110]
100245128:     	cmp	x8, x9
10024512c:     	b.ne	0x100244edc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100245130:     	cmp	x23, #0x3
100245134:     	b.eq	0x100244f94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
100245138:     	ldr	x8, [x19, #0x98]
10024513c:     	ldr	x9, [sp, #0x118]
100245140:     	cmp	x8, x9
100245144:     	b.ne	0x100244edc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100245148:     	cmp	x23, #0x4
10024514c:     	b.eq	0x100244f94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
100245150:     	ldr	x8, [x19, #0xa0]
100245154:     	ldr	x9, [sp, #0x120]
100245158:     	cmp	x8, x9
10024515c:     	b.ne	0x100244edc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100245160:     	cmp	x23, #0x5
100245164:     	b.eq	0x100244f94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
100245168:     	ldr	x8, [x19, #0xa8]
10024516c:     	ldr	x9, [sp, #0x128]
100245170:     	cmp	x8, x9
100245174:     	b.ne	0x100244edc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100245178:     	cmp	x23, #0x6
10024517c:     	b.eq	0x100244f94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
100245180:     	ldr	x8, [x19, #0xb0]
100245184:     	ldr	x9, [sp, #0x130]
100245188:     	cmp	x8, x9
10024518c:     	b.ne	0x100244edc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
100245190:     	cmp	x23, #0x7
100245194:     	b.eq	0x100244f94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
100245198:     	ldr	x8, [x19, #0xb8]
10024519c:     	ldr	x9, [sp, #0x138]
1002451a0:     	cmp	x8, x9
1002451a4:     	b.ne	0x100244edc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c4>
1002451a8:     	b	0x100244f94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x127c>
1002451ac:     	cmp	w8, #0x1
1002451b0:     	b.ne	0x10024522c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1514>
1002451b4:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
1002451b8:     	add	x1, x1, #0x518
1002451bc:     	mov	x0, x20
1002451c0:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1002451c4:     	strb	wzr, [x20, #0x20]
1002451c8:     	ldr	x8, [x20]
1002451cc:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1002451d0:     	cmp	x8, x9
1002451d4:     	b.lo	0x100243e34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11c>
1002451d8:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
1002451dc:     	add	x0, x0, #0x4a0
1002451e0:     	bl	0x100b1051c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1002451e4:     	cmp	w8, #0x2
1002451e8:     	b.eq	0x10024522c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1514>
1002451ec:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
1002451f0:     	add	x1, x1, #0x518
1002451f4:     	mov	x0, x20
1002451f8:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1002451fc:     	strb	wzr, [x20, #0x20]
100245200:     	ldr	x8, [x20]
100245204:     	cbz	x8, 0x100244fc4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x12ac>
100245208:     	b	0x100245268 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1550>
10024520c:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245210:     	add	x3, x3, #0x6f8
100245214:     	mov	x0, #0x0                ; =0
100245218:     	mov	x1, x23
10024521c:     	mov	w2, #0x8                ; =8
100245220:     	bl	0x100b1080c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245224:     	cmp	w8, #0x2
100245228:     	b.ne	0x10024524c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1534>
10024522c:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100245230:     	add	x0, x0, #0xc18
100245234:     	bl	0x100b563dc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100245238:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
10024523c:     	add	x3, x3, #0x6b0
100245240:     	mov	x0, #0x0                ; =0
100245244:     	mov	w2, #0x8                ; =8
100245248:     	bl	0x100b1080c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
10024524c:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100245250:     	add	x1, x1, #0x518
100245254:     	mov	x0, x20
100245258:     	bl	0x100a1e21c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
10024525c:     	strb	wzr, [x20, #0x20]
100245260:     	ldr	x8, [x20]
100245264:     	cbz	x8, 0x100244f5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1244>
100245268:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
10024526c:     	add	x0, x0, #0x488
100245270:     	bl	0x100b104ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100245274:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245278:     	add	x0, x0, #0x668
10024527c:     	bl	0x100b105b0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100245280:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100245284:     	add	x2, x2, #0x800
100245288:     	mov	x0, x27
10024528c:     	mov	w1, #0x8                ; =8
100245290:     	bl	0x100b1064c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245294:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100245298:     	add	x2, x2, #0xab8
10024529c:     	mov	x0, x24
1002452a0:     	bl	0x100b1064c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
1002452a4:     	adrp	x2, 0x100f02000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x10ed0>
1002452a8:     	add	x2, x2, #0x320
1002452ac:     	mov	x0, x24
1002452b0:     	bl	0x100b1064c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
1002452b4:     	mov	w0, #0x8                ; =8
1002452b8:     	mov	w1, #0x1108             ; =4360
1002452bc:     	bl	0x100b10128 <__RNvNtCsctvjasLqLe9_5alloc5alloc18handle_alloc_error>
1002452c0:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002452c4:     	add	x2, x2, #0x6e0
1002452c8:     	mov	x0, x24
1002452cc:     	bl	0x100b1064c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
1002452d0:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002452d4:     	add	x2, x2, #0x6c8
1002452d8:     	mov	x0, x24
1002452dc:     	bl	0x100b1064c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
1002452e0:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002452e4:     	add	x2, x2, #0x698
1002452e8:     	mov	w1, #0x8                ; =8
1002452ec:     	bl	0x100b1064c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
1002452f0:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
1002452f4:     	add	x2, x2, #0x680
1002452f8:     	mov	w1, #0x8                ; =8
1002452fc:     	bl	0x100b1064c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245300:     	mov	w0, #0x8                ; =8
100245304:     	mov	w1, #0x80               ; =128
100245308:     	bl	0x100b10140 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
