; ModuleID = '/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-token-proof-r31/candidate-changing-ir-native/.perry-trace/llvm/changing_options_worker_ts.ll'
source_filename = "perry_module"
target datalayout = "e-m:o-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "arm64-apple-macosx15.0.0"

module asm ".no_dead_strip __LLVM_StackMaps"

@changing_options_worker_ts_.str.0 = private unnamed_addr constant [126 x i8] c"/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/zero-spacing-r25/changing-options-worker.ts\00"
@changing_options_worker_ts_.str.0.bytes = private unnamed_addr constant [15 x i8] c"changing-plain\00"
@changing_options_worker_ts_.str.1.bytes = private unnamed_addr constant [3 x i8] c"id\00"
@changing_options_worker_ts_.str.2.bytes = private unnamed_addr constant [7 x i8] c"length\00"
@changing_options_worker_ts_.str.3.bytes = private unnamed_addr constant [14 x i8] c"changing-zero\00"
@changing_options_worker_ts_.str.4.bytes = private unnamed_addr constant [3 x i8] c"fs\00"
@changing_options_worker_ts_.str.5.bytes = private unnamed_addr constant [13 x i8] c"readFileSync\00"
@changing_options_worker_ts_.str.6.bytes = private unnamed_addr constant [5 x i8] c"utf8\00"
@changing_options_worker_ts_.str.7.bytes = private unnamed_addr constant [2 x i8] c"0\00"
@changing_options_worker_ts_.str.8.bytes = private unnamed_addr constant [9 x i8] c"{\22data\22:\00"
@changing_options_worker_ts_.str.9.bytes = private unnamed_addr constant [2 x i8] c"}\00"
@changing_options_worker_ts_.str.10.bytes = private unnamed_addr constant [5 x i8] c"data\00"
@changing_options_worker_ts_.str.11.bytes = private unnamed_addr constant [4 x i8] c"rss\00"
@changing_options_worker_ts_.str.12.bytes = private unnamed_addr constant [7 x i8] c"RESULT\00"
@changing_options_worker_ts_.str.13.bytes = private unnamed_addr constant [5 x i8] c"user\00"
@changing_options_worker_ts_.str.14.bytes = private unnamed_addr constant [7 x i8] c"system\00"
@changing_options_worker_ts_.str.15.bytes = private unnamed_addr constant [7 x i8] c"verify\00"
@changing_options_worker_ts_.str.16.bytes = private unnamed_addr constant [7 x i8] c"VERIFY\00"
@changing_options_worker_ts_.str.17.bytes = private unnamed_addr constant [5 x i8] c"KEEP\00"
@changing_options_worker_ts_.str.1 = private unnamed_addr constant [4 x i8] c"run\00"
@changing_options_worker_ts_.str.2 = private unnamed_addr constant [566 x i8] c"function run(count: number): number {\0A    let sum = 0;\0A    if (operation === 'changing-plain') {\0A        for (let i = 0; i < count; i++) {\0A            input.id = 42 + (i % 2);\0A            const result = JSON.stringify(input);\0A            sum += result.length; last = result;\0A        }\0A    } else if (operation === 'changing-zero') {\0A        for (let i = 0; i < count; i++) {\0A            input.id = 42 + (i % 2);\0A            const result = JSON.stringify(input, null, dynamicSpacer);\0A            sum += result.length; last = result;\0A        }\0A    }\0A    return sum;\0A}\00"
@PERRY_SYMBOL_PROPERTY_IC_EPOCH = external global i64
@PERRY_GC_POLL_ARMED = external global i32
@PERRY_CLASS_FIELD_INLINE_GUARD_DISABLED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED = external global i8
@PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD = external global [65536 x i8]
@PERRY_PER_OBJECT_LAYOUTS_ANY = external global i32
@PERRY_LAYOUT_ADDR_FILTER = external global [64 x i64]
@PERRY_YOUNG_LAYOUT_RECORDS = external global i32
@PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED = external global i8
@PERRY_ARRAY_PROTO_ITERATOR_PATCHED = external global i8
@PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT = external global i32
@PERRY_HOT_TSD_KEY = external global i64
@PERRY_TA_KIND_CACHE = external global [64 x i64]
@PERRY_U8_INLINE_CACHE = external global [64 x i64]
@PERRY_TA_VIEW_GUARD = external global i64
@perry_null_guard_zero_changing_options_worker_ts = internal global i32 0
@perry_global_changing_options_worker_ts__1 = global double 0x7FFC000000000001
@perry_global_changing_options_worker_ts__2 = global double 0x7FFC000000000001
@perry_global_changing_options_worker_ts__5 = global double 0x7FFC000000000001
@perry_global_changing_options_worker_ts__6 = global double 0x7FFC000000000001
@perry_ic_changing_options_worker_ts__0 = private global ptr null
@perry_ic_changing_options_worker_ts__0_poly_tail = private global ptr null
@perry_ic_changing_options_worker_ts__2 = private global ptr null
@perry_ic_changing_options_worker_ts__3 = private global ptr null
@perry_ic_changing_options_worker_ts__3_poly_tail = private global ptr null
@perry_ic_changing_options_worker_ts__5 = private global ptr null
@perry_ic_changing_options_worker_ts__6 = private global ptr null
@perry_ic_changing_options_worker_ts__6_poly_tail = private global ptr null
@perry_ic_changing_options_worker_ts__8 = private global ptr null
@perry_ic_changing_options_worker_ts__9 = private global ptr null
@perry_ic_changing_options_worker_ts__9_poly_tail = private global ptr null
@perry_ic_changing_options_worker_ts__11 = private global ptr null
@perry_ic_changing_options_worker_ts__18 = private global ptr null
@perry_ic_changing_options_worker_ts__20 = private global ptr null
@perry_ic_changing_options_worker_ts__22 = private global ptr null
@perry_ic_changing_options_worker_ts__24 = private global ptr null
@perry_ic_changing_options_worker_ts__26 = private global ptr null
@perry_ic_changing_options_worker_ts__28 = private global ptr null
@perry_ic_changing_options_worker_ts__30 = private global ptr null
@changing_options_worker_ts_.str.0.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.1.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.2.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.3.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.4.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.5.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.6.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.7.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.8.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.9.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.10.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.11.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.12.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.13.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.14.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.15.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.16.handle = internal global double 0.000000e+00
@changing_options_worker_ts_.str.17.handle = internal global double 0.000000e+00

declare void @js_gc_init()

declare void @js_typed_feedback_maybe_dump_trace()

declare void @js_set_process_entry_path(ptr, i32)

declare void @js_stdlib_init_dispatch()

declare void @perry_app_group_init(ptr, i32)

declare void @perry_update_notify_startup(ptr, i32)

declare void @perry_macos_bundle_chdir()

declare i32 @perry_i18n_locale_index_for(i64, i32)

declare void @perry_i18n_init(ptr, ptr, i32, i32)

declare void @perry_i18n_set_currencies(ptr, i32)

declare i32 @perry_i18n_plural_category(i32, double)

declare void @js_register_function_name_static(ptr, ptr, i32)

declare void @js_register_function_name(ptr, ptr, i32)

declare void @js_register_function_source_static(ptr, ptr, i32, i32)

declare void @js_register_function_source(ptr, ptr, i32, i32)

declare void @js_console_log_dynamic(double)

declare void @js_console_log_number(double)

declare void @js_console_error_dynamic(double)

declare void @js_console_error_number(double)

declare void @js_console_warn_dynamic(double)

declare void @js_console_warn_number(double)

declare void @js_console_dir_with_options(double, double)

declare double @js_console_method_by_value(double)

declare double @js_nanbox_string(i64)

; Function Attrs: nounwind willreturn
declare double @js_nanbox_pointer(i64) #0

; Function Attrs: nounwind willreturn
declare i64 @js_nanbox_get_pointer(double) #0

declare double @js_native_handle_new_owned(i64, i64, i32, i32, ptr, ptr, i64)

declare double @js_native_handle_new_borrowed(i64, i64, i32, i32, ptr, i64)

declare i64 @js_native_handle_unwrap(double, i64, i32, i32, i32)

declare i64 @js_string_from_bytes(ptr, i32)

declare i64 @js_string_from_wtf8_bytes(ptr, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_is_truthy(double) #0

declare double @js_native_abi_check_f64(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_f64_arg_guard(double) #0

declare double @js_typed_f64_arg_to_raw(double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i32_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_guard(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_i1_arg_to_raw(double) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_string_arg_guard(double) #0

declare i64 @js_typed_string_arg_to_raw(double)

declare i32 @js_param_type_guard(double, ptr, i32)

declare float @js_native_abi_check_f32(double)

declare i8 @js_native_abi_check_i8(double)

declare i16 @js_native_abi_check_i16(double)

declare i32 @js_native_abi_check_i32(double)

declare i64 @js_native_abi_check_i64(double)

declare i8 @js_native_abi_check_u8(double)

declare i16 @js_native_abi_check_u16(double)

declare i32 @js_native_abi_check_u32(double)

declare i64 @js_native_abi_check_u64(double)

declare i64 @js_native_abi_check_usize(double)

declare i64 @js_native_abi_check_isize(double)

declare double @js_native_abi_materialize_i64(i64)

declare double @js_native_abi_materialize_u64(i64)

declare i64 @js_native_abi_check_string_ptr(double)

declare i64 @js_native_abi_check_ptr(double)

declare ptr @js_native_abi_check_buffer_data_ptr(double)

declare i64 @js_native_abi_check_buffer_byte_len(double)

declare i64 @js_native_abi_check_promise(double)

declare i64 @js_native_abi_check_pod_object(double)

declare double @js_date_now()

declare void @js_gc_register_global_root(i64)

declare i64 @js_string_concat(i64, i64)

declare double @js_string_concat_box(double, double)

declare i64 @js_jsvalue_to_string(double)

declare i64 @js_jsvalue_to_string_method(double)

declare i64 @js_jsvalue_to_string_coerce(double)

declare i64 @js_string_concat_value(i64, double)

declare double @js_string_concat_site_value(i64, i64, double)

declare i64 @js_value_concat_string(double, i64)

declare double @js_string_concat_value_box(i64, double)

declare double @js_string_add_value(double, double)

declare double @js_value_add_string(double, double)

declare i64 @js_string_concat_chain(i64, i32)

declare i64 @js_string_append_chain(i64, i32)

declare i64 @js_string_append(i64, i64)

declare i64 @js_string_append_known_heap(i64, i64)

declare i32 @js_string_index_of(i64, i64)

declare i32 @js_string_index_of_from(i64, i64, i32)

declare i32 @js_string_position_to_index(double)

declare i64 @js_string_slice(i64, i32, i32)

declare i64 @js_string_substring(i64, i32, i32)

declare i64 @js_string_substr(i64, double, double)

declare i64 @js_string_split(i64, i64)

declare i64 @js_string_split_n(i64, i64, i32)

declare double @js_string_split_part_value(i64, i64, i32)

declare double @js_string_split_part_utf16_length(i64, i64, i32)

declare double @js_string_to_upper_case_split_part_utf16_length(i64, i64, i32)

declare i32 @js_string_to_upper_case_index_of(i64, i64)

declare i64 @js_string_split_value(i64, double, double)

declare double @js_math_trunc(double)

declare double @js_math_round(double)

declare double @js_math_sign(double)

declare double @js_math_imul(double, double)

declare double @js_math_pow(double, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sqrt.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.floor.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.ceil.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.fabs.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.copysign.f64(double, double) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #2

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i16 @llvm.bswap.i16(i16) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i32 @llvm.bswap.i32(i32) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.bswap.i64(i64) #1

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.aarch64.fjcvtzs(double) #3

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr writeonly captures(none), i8, i64, i1 immarg) #4

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memmove.p0.p0.i64(ptr writeonly captures(none), ptr readonly captures(none), i64, i1 immarg) #5

declare i64 @js_json_stringify(double, i32)

declare i64 @js_map_alloc(i32)

declare i64 @js_text_encoder_encode_into_llvm(double, double)

declare i64 @js_value_typeof(double)

declare i32 @js_value_typeof_tag(double)

declare i32 @js_string_starts_with(i64, i64)

declare i32 @js_string_ends_with(i64, i64)

declare i64 @js_string_search_value_to_string(double, i32)

declare i32 @js_string_starts_with_at(i64, i64, i32)

declare i32 @js_string_ends_with_at(i64, i64, i32)

declare i64 @js_closure_alloc(ptr, i32)

declare i64 @js_closure_alloc_init(ptr, i32, ptr)

declare i64 @js_closure_alloc_singleton(ptr)

declare i64 @js_closure_alloc_with_captures_singleton(ptr, i32, ptr)

declare void @js_closure_set_capture_bits(i64, i32, i64)

declare void @js_closure_set_box_capture_ptr(i64, i32, i64)

declare i64 @js_closure_get_capture_bits(i64, i32)

declare void @js_closure_set_capture_f64(i64, i32, double)

declare double @js_closure_get_capture_f64(i64, i32)

declare void @js_register_closure_rest(ptr, i32)

declare void @js_register_closure_synthetic_arguments(ptr, i32)

declare void @js_register_closure_rest_and_arguments(ptr, i32)

declare void @js_register_closure_arity(ptr, i32)

declare void @js_register_closure_length(ptr, i32)

declare void @js_register_closure_arrow_function(ptr)

declare void @js_register_closure_trusted_direct(ptr, ptr, i32, i64)

declare void @js_register_closure_versioned_loop_direct(ptr, ptr, i32, i64)

declare ptr @js_closure_resolve_versioned_loop_direct_call(i64, i32)

declare void @js_register_closure_strict_function(ptr)

declare void @js_register_closure_async_function(ptr)

declare void @js_register_closure_generator_function(ptr)

declare void @js_register_closure_async_generator_function(ptr)

declare i64 @js_closure_unbox_callee_checked(double)

declare i64 @js_closure_unbox_callee_checked_rebind(double, double)

declare double @js_closure_call0(i64)

declare double @js_closure_call1(i64, double)

declare double @js_closure_call1_receiverless(i64, double)

declare double @js_closure_call2(i64, double, double)

declare double @js_closure_call3(i64, double, double, double)

declare ptr @js_closure_resolve_arrow_direct_call(i64, i32)

declare double @js_closure_call4(i64, double, double, double, double)

declare double @js_closure_call5(i64, double, double, double, double, double)

declare double @js_closure_call6(i64, double, double, double, double, double, double)

declare double @js_closure_call7(i64, double, double, double, double, double, double, double)

declare double @js_closure_call8(i64, double, double, double, double, double, double, double, double)

declare double @js_closure_call9(i64, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call10(i64, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call11(i64, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call12(i64, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call13(i64, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call14(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call15(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare double @js_closure_call16(i64, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double, double)

declare i64 @js_array_map(i64, i64)

declare void @js_array_map_discard(i64, i64)

declare i64 @js_array_filter(i64, i64)

declare i64 @js_array_concat(i64, i64)

declare i64 @js_array_concat_new(i64, i64)

declare i64 @js_error_new()

declare i64 @js_error_new_with_message(i64)

declare i64 @js_error_new_from_value(double)

declare i64 @js_error_new_kind_from_value(i32, double)

declare i64 @js_error_new_with_cause_from_value(double, double)

declare i64 @js_error_new_kind_with_options_from_value(i32, double, double)

declare double @js_assert_assertion_error_ctor(double)

declare double @js_assert_assert_ctor(double)

declare void @js_throw_type_error_property_access(i32, ptr, i64)

declare void @js_throw_type_error_not_a_function(ptr, i64, ptr, i64)

declare void @js_throw_error_with_code(ptr, i64, ptr, i64, i32)

declare i64 @js_map_set(i64, double, double)

declare i64 @js_map_set_string_number(i64, i64, double)

declare i64 @js_map_set_string_key(i64, i64, double)

declare i64 @js_map_set_string_i32(i64, i64, i32)

declare i64 @js_map_set_string_u32(i64, i64, i32)

declare i64 @js_map_set_string_f32(i64, i64, float)

declare i64 @js_map_set_string_bool(i64, i64, i32)

declare i64 @js_map_set_string_string(i64, i64, i64)

declare i64 @js_map_set_number_key(i64, double, double)

declare double @js_map_get(i64, double)

declare double @js_declared_map_get(double, double)

declare double @js_map_get_string_key(i64, i64)

declare double @js_map_get_number_key(i64, double)

declare i32 @js_map_has(i64, double)

declare i32 @js_map_has_string_key(i64, i64)

declare i32 @js_map_has_number_key(i64, double)

declare i32 @js_map_delete(i64, double)

declare i32 @js_map_delete_string_key(i64, i64)

declare i32 @js_map_delete_number_key(i64, double)

declare i64 @js_object_keys(i64)

declare i64 @js_object_keys_value(double)

declare i64 @js_for_in_keys_value(double)

declare i64 @js_for_in_keys_stable_value(double)

declare double @js_is_finite(double)

declare i32 @js_is_undefined_or_bare_nan(double)

declare double @js_math_min_array(i64)

declare double @js_math_max_array(i64)

declare double @js_math_min2(double, double)

declare double @js_math_max2(double, double)

declare i64 @js_string_coerce(double)

declare i64 @js_string_coerce_method_this(double, ptr, i64)

declare i64 @js_array_slice(i64, i32, i32)

declare i64 @js_array_slice_values(i64, double, double)

declare double @js_array_shift_f64(i64)

declare i64 @js_set_alloc(i32)

declare i64 @js_set_from_array(i64)

declare i64 @js_set_from_iterable(double)

declare i64 @js_map_from_array(i64)

declare i64 @js_map_from_iterable(double)

declare double @js_object_has_property(double, double)

declare double @js_in_operator(double, double)

declare double @js_private_brand_check(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_guard(double, double, i32, ptr, i32, i32, i32)

declare double @js_private_brand_add(double, i32)

declare double @js_private_field_add(double, i32, double, double)

declare double @js_class_field_add(double, double, double)

declare double @js_class_computed_field_key(double, i32, ptr, i64)

declare double @js_fs_to_unix_timestamp(double)

declare i32 @js_fs_write_file_sync(double, double)

declare i32 @js_fs_write_file_sync_options(double, double, double)

declare i32 @js_fs_append_file_sync(double, double)

declare i32 @js_fs_append_file_sync_options(double, double, double)

declare i32 @js_fs_exists_sync(double)

declare i64 @js_fs_read_file_sync(double)

declare double @js_fs_read_file_dispatch(double, double)

declare double @js_fs_open_as_blob(double, double)

declare double @js_fs_promises_read_file(double, double)

declare double @js_fs_promises_write_file(double, double, double)

declare double @js_fs_promises_append_file(double, double, double)

declare double @js_fs_promises_mkdir(double, double)

declare double @js_fs_promises_rmdir(double, double)

declare i32 @js_fs_mkdir_sync(double)

declare i32 @js_fs_mkdir_sync_options(double, double)

declare i32 @js_fs_unlink_sync(double)

declare double @js_fs_readdir_sync(double, double)

declare double @js_fs_stat_sync(double)

declare double @js_fs_stat_sync_options(double, double)

declare double @js_fs_lstat_sync(double)

declare double @js_fs_lstat_sync_options(double, double)

declare i32 @js_fs_rename_sync(double, double)

declare i32 @js_fs_copy_file_sync(double, double)

declare i32 @js_fs_copy_file_sync_flags(double, double, double)

declare i32 @js_fs_cp_sync(double, double)

declare i32 @js_fs_cp_sync_options(double, double, double)

declare i32 @js_fs_chmod_sync(double, double)

declare i32 @js_fs_chown_sync(double, double, double)

declare i32 @js_fs_lchown_sync(double, double, double)

declare i32 @js_fs_lchmod_sync(double, double)

declare i32 @js_fs_truncate_sync(double, double)

declare i32 @js_fs_ftruncate_sync(double, double)

declare i32 @js_fs_fsync_sync(double)

declare i32 @js_fs_fdatasync_sync(double)

declare i32 @js_fs_fchmod_sync(double, double)

declare i32 @js_fs_fchown_sync(double, double, double)

declare double @js_fs_fstat_sync(double)

declare double @js_fs_fstat_sync_options(double, double)

declare i32 @js_fs_utimes_sync(double, double, double)

declare i32 @js_fs_lutimes_sync(double, double, double)

declare i32 @js_fs_futimes_sync(double, double, double)

declare double @js_fs_readv_sync(double, double, double)

declare double @js_fs_writev_sync(double, double, double)

declare double @js_fs_statfs_sync(double)

declare double @js_fs_statfs_sync_options(double, double)

declare double @js_fs_opendir_sync(double)

declare double @js_fs_glob_sync(double)

declare double @js_fs_glob_sync_options(double, double)

declare i32 @js_fs_link_sync(double, double)

declare i32 @js_fs_symlink_sync(double, double)

declare double @js_fs_symlink_callback(double, double, double, double)

declare i64 @js_fs_readlink_sync(double)

declare i64 @js_fs_readlink_sync_options(double, double)

declare double @js_fs_readlink_dispatch(double, double)

declare double @js_fs_open_sync(double, double)

declare i32 @js_fs_close_sync(double)

declare double @js_fs_read_sync(double, double, double, double, double)

declare double @js_fs_read_sync_options(double, double, double)

declare double @js_fs_write_sync(double, double)

declare double @js_fs_write_string_sync_options(double, double, double)

declare double @js_fs_write_buffer_sync(double, double, double, double, double)

declare double @js_fs_write_sync_options_dispatch(double, double, double)

declare i32 @js_fs_access_sync(double)

declare i32 @js_fs_access_sync_mode(double, double)

declare double @js_fs_access_sync_throw(double)

declare double @js_fs_access_sync_throw_mode(double, double)

declare i64 @js_fs_realpath_sync(double)

declare double @js_fs_realpath_dispatch(double, double)

declare i64 @js_fs_mkdtemp_sync(double)

declare i64 @js_fs_mkdtemp_sync_options(double, double)

declare double @js_fs_mkdtemp_dispatch(double, double)

declare double @js_fs_mkdtemp_disposable_sync(double, double)

declare i32 @js_fs_rmdir_sync(double)

declare i32 @js_fs_rmdir_sync_options(double, double)

declare i32 @js_fs_rm_recursive(double)

declare i32 @js_fs_rm_recursive_options(double, double)

declare double @js_fs_create_write_stream(double, double)

declare double @js_fs_create_read_stream(double, double)

declare double @js_fs_utf8_stream_new(double)

declare double @js_fs_utf8_stream_call_without_new(double)

declare double @js_fs_utf8_stream_write(double, double)

declare double @js_fs_utf8_stream_flush(double, double)

declare double @js_fs_utf8_stream_flush_sync(double)

declare double @js_fs_utf8_stream_end(double, double)

declare double @js_fs_utf8_stream_destroy(double)

declare double @js_fs_utf8_stream_reopen(double, double)

declare double @js_fs_utf8_stream_on(double, double, double)

declare double @js_fs_utf8_stream_once(double, double, double)

declare double @js_fs_utf8_stream_off(double, double, double)

declare double @js_fs_utf8_stream_remove_all(double, double)

declare double @js_fs_utf8_stream_listener_count(double, double)

declare double @js_fs_utf8_stream_emit(double, double, double)

declare double @js_fs_read_file_callback(double, double, double)

declare double @js_fs_stats_is_file(double)

declare double @js_fs_stats_is_directory(double)

declare i64 @js_fs_read_file_binary(double)

declare double @js_number_coerce(double)

declare double @js_math_to_number(double)

declare i64 @js_set_add(i64, double)

declare i64 @js_set_add_string(i64, i64)

declare i64 @js_set_add_number(i64, double)

declare i64 @js_set_add_i32(i64, i32)

declare i64 @js_set_add_u32(i64, i32)

declare i64 @js_set_add_f32(i64, float)

declare i64 @js_set_add_bool(i64, i32)

declare i32 @js_set_has(i64, double)

declare double @js_readonly_set_has(double, double)

declare i32 @js_set_has_string(i64, i64)

declare i32 @js_set_has_number(i64, double)

declare i32 @js_set_has_i32(i64, i32)

declare i32 @js_set_has_u32(i64, i32)

declare i32 @js_set_has_f32(i64, float)

declare i32 @js_set_has_bool(i64, i32)

declare i32 @js_set_delete(i64, double)

declare i32 @js_set_delete_string(i64, i64)

declare i32 @js_set_delete_number(i64, double)

declare i32 @js_set_delete_i32(i64, i32)

declare i32 @js_set_delete_u32(i64, i32)

declare i32 @js_set_delete_f32(i64, float)

declare i32 @js_set_delete_bool(i64, i32)

declare i32 @js_set_size(i64)

declare i64 @js_set_union(i64, double)

declare i64 @js_set_intersection(i64, double)

declare i64 @js_set_difference(i64, double)

declare i64 @js_set_symmetric_difference(i64, double)

declare i32 @js_set_is_subset_of(i64, double)

declare i32 @js_set_is_superset_of(i64, double)

declare i32 @js_set_is_disjoint_from(i64, double)

declare i64 @js_string_to_lower_case(i64)

declare i64 @js_string_to_upper_case(i64)

declare i64 @js_string_to_locale_lower_case(i64, double)

declare i64 @js_string_to_locale_upper_case(i64, double)

declare void @js_string_validate_collator_args(double, double)

declare i64 @js_string_trim(i64)

declare i64 @js_string_trim_start(i64)

declare i64 @js_string_trim_end(i64)

declare i64 @js_string_big(i64)

declare i64 @js_string_blink(i64)

declare i64 @js_string_bold(i64)

declare i64 @js_string_fixed(i64)

declare i64 @js_string_italics(i64)

declare i64 @js_string_small(i64)

declare i64 @js_string_strike(i64)

declare i64 @js_string_sub(i64)

declare i64 @js_string_sup(i64)

declare i64 @js_string_anchor(i64, i64)

declare i64 @js_string_link(i64, i64)

declare i64 @js_string_fontcolor(i64, i64)

declare i64 @js_string_fontsize(i64, i64)

declare i64 @js_string_char_at(i64, i32)

declare double @js_string_index_get(i64, double)

declare double @js_string_index_get_boxed(double, double)

declare i32 @js_string_index_to_i32(double)

declare i32 @js_string_end_index_to_i32(double, i32)

declare double @js_typed_feedback_object_get_field_by_value_f64(i64, i64, double)

declare double @js_dyn_index_get(double, double)

declare double @js_packed_arraylike_index_get(double, double, ptr)

declare i32 @js_packed_arraylike_loop_guard(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_guard_live(double, double, i32, ptr)

declare i64 @js_packed_arraylike_loop_revalidate_live(double, double, i32, ptr)

declare double @js_dyn_index_set(double, double, double)

declare double @js_dyn_index_set_strict(double, double, double, i32)

declare i64 @js_string_to_char_array(i64)

declare i64 @js_string_repeat(i64, double)

declare i64 @js_string_replace_string(i64, i64, i64)

declare i64 @js_string_replace_all_string(i64, i64, i64)

declare i32 @js_string_equals(i64, i64)

declare i32 @js_string_compare(i64, i64)

declare i32 @js_jsvalue_equals(double, double)

declare i32 @js_string_compare_value(double, double)

declare i64 @js_jsvalue_to_string_radix(double, double)

declare double @js_math_random()

declare double @js_webassembly_validate(double)

declare double @js_webassembly_compile(double)

declare double @js_webassembly_module_new(double)

declare double @js_webassembly_module_exports(double)

declare double @js_webassembly_module_imports(double)

declare double @js_webassembly_module_custom_sections(double, double)

declare double @js_webassembly_instantiate(double, double)

declare double @js_wasi_emit_warning()

declare double @js_webassembly_call_export_0(double, double)

declare double @js_webassembly_call_export_1(double, double, double)

declare double @js_webassembly_call_export_2(double, double, double, double)

declare double @js_webassembly_call_export_3(double, double, double, double, double)

declare double @js_webassembly_call_export_4(double, double, double, double, double, double)

declare void @js_console_log_spread(i64)

declare void @js_console_info_spread(i64)

declare void @js_console_debug_spread(i64)

declare void @js_console_error_spread(i64)

declare void @js_console_warn_spread(i64)

declare double @js_util_format(i64)

declare double @js_util_format_with_options(double, i64)

declare double @js_util_inspect(double, double)

declare double @js_util_debuglog(double, double)

declare double @js_util_diff(double, double)

declare double @js_util_inherits(double, double)

declare double @js_util_is_deep_strict_equal(double, double)

declare double @js_util_strip_vt_control_characters(double)

declare double @js_util_style_text(double, double, double)

declare double @js_util_get_call_sites(double, double)

declare double @js_util_promisify(double)

declare double @js_util_callbackify(double)

declare double @js_util_deprecate(double, double, double)

declare double @js_util_aborted(double, double)

declare double @js_util_transferable_abort_controller()

declare double @js_util_transferable_abort_signal(double)

declare double @js_util_parse_args(double)

declare double @js_boxed_number_new(double)

declare double @js_boxed_string_new(double, i32)

declare double @js_boxed_boolean_new(double)

declare double @js_util_types_is_arguments_object(double)

declare double @js_util_types_is_promise(double)

declare double @js_util_types_is_big_int_object(double)

declare double @js_util_types_is_symbol_object(double)

declare double @js_util_types_is_array_buffer(double)

declare double @js_util_types_is_shared_array_buffer(double)

declare double @js_util_types_is_any_array_buffer(double)

declare double @js_util_types_is_array_buffer_view(double)

declare double @js_util_types_is_data_view(double)

declare double @js_util_types_is_typed_array(double)

declare double @js_util_types_is_uint8_array(double)

declare double @js_util_types_is_int8_array(double)

declare double @js_util_types_is_int16_array(double)

declare double @js_util_types_is_uint16_array(double)

declare double @js_util_types_is_int32_array(double)

declare double @js_util_types_is_uint32_array(double)

declare double @js_util_types_is_float16_array(double)

declare double @js_util_types_is_float32_array(double)

declare double @js_util_types_is_float64_array(double)

declare double @js_util_types_is_uint8_clamped_array(double)

declare double @js_util_types_is_big_int64_array(double)

declare double @js_util_types_is_big_uint64_array(double)

declare double @js_util_types_is_map(double)

declare double @js_util_types_is_weak_map(double)

declare double @js_util_types_is_set(double)

declare double @js_util_types_is_weak_set(double)

declare double @js_util_types_is_date(double)

declare double @js_util_types_is_reg_exp(double)

declare double @js_util_types_is_async_function(double)

declare double @js_util_types_is_generator_function(double)

declare double @js_util_types_is_generator_object(double)

declare double @js_util_types_is_native_error(double)

declare double @js_util_types_is_number_object(double)

declare double @js_util_types_is_string_object(double)

declare double @js_util_types_is_boolean_object(double)

declare double @js_util_types_is_boxed_primitive(double)

declare double @js_util_types_is_external(double)

declare double @js_util_types_is_module_namespace_object(double)

declare double @js_util_types_is_key_object(double)

declare double @js_util_types_is_crypto_key(double)

declare double @js_util_types_is_proxy(double)

declare double @js_util_types_is_map_iterator(double)

declare double @js_util_types_is_set_iterator(double)

declare double @js_data_view_new(double, double, double)

declare double @js_data_view_get_direct(double, double, double, i32, i32)

declare double @js_data_view_set_direct(double, double, double, double, i32, i32)

declare i64 @js_getenv(i64)

declare double @js_getenv_value(i64)

declare void @js_setenv(i64, double)

declare void @js_removeenv(i64)

declare double @js_process_exit_code_get()

declare double @js_process_exit_code_set(double)

declare void @js_console_table(double)

declare void @js_console_table_with_properties(double, double)

declare void @js_console_trace(double)

declare void @js_console_trace_spread(i64)

declare i64 @js_process_cwd()

declare i64 @js_process_argv()

declare double @js_process_pid()

declare double @js_process_ppid()

declare double @js_process_uptime()

declare i64 @js_process_version()

declare double @js_process_versions()

declare double @js_process_memory_usage()

declare double @js_bigint_as_int_n_call(double, double)

declare double @js_bigint_as_uint_n_call(double, double)

declare double @js_v8_serialize(double)

declare double @js_v8_deserialize(double)

declare double @js_v8_get_heap_statistics()

declare double @js_v8_get_heap_code_statistics()

declare double @js_v8_get_heap_space_statistics()

declare double @js_v8_cached_data_version_tag()

declare double @js_v8_get_heap_snapshot(double)

declare double @js_v8_write_heap_snapshot(double, double)

declare double @js_v8_gc_profiler_new()

declare double @js_v8_gc_profiler_start(double)

declare double @js_v8_gc_profiler_stop(double)

declare double @js_v8_gc_profiler_report()

declare double @js_v8_serializer_new(double)

declare double @js_v8_deserializer_new(double)

declare double @js_v8_noop_undefined()

declare double @js_v8_is_building_snapshot()

declare double @js_v8_namespace(ptr, i64)

declare double @js_v8_throw_not_building_snapshot()

declare double @js_v8_promise_hook_register()

declare double @js_v8_promise_hooks_on_init(double)

declare double @js_v8_promise_hooks_on_before(double)

declare double @js_v8_promise_hooks_on_after(double)

declare double @js_v8_promise_hooks_on_settled(double)

declare double @js_v8_promise_hooks_create_hook(double)

declare double @js_process_thread_cpu_usage(double)

declare double @js_process_available_memory()

declare double @js_process_constrained_memory()

declare double @js_process_source_maps_enabled()

declare double @js_process_set_source_maps_enabled(double)

declare double @js_process_has_uncaught_exception_capture_callback()

declare double @js_process_set_uncaught_exception_capture_callback(double)

declare double @js_process_add_uncaught_exception_capture_callback(double)

declare double @js_process_getuid()

declare double @js_process_geteuid()

declare double @js_process_getgid()

declare double @js_process_getegid()

declare void @js_process_emit_warning(double, double, double)

declare double @js_process_cpu_usage(double)

declare double @js_process_resource_usage()

declare double @js_process_active_resources_info()

declare double @js_process_env()

declare double @js_process_hrtime_bigint()

declare double @js_process_hrtime(double)

declare double @js_process_title()

declare void @js_process_set_title(double)

declare void @js_process_chdir(i64)

declare void @js_process_chdir_jsv(double)

declare double @js_process_kill(double, double)

declare void @js_process_exit(double)

declare void @js_process_abort()

declare double @js_process_umask()

declare double @js_process_umask_set(double)

declare double @js_process_on(i64, i64)

declare double @js_process_add_listener(i64, i64)

declare double @js_process_once(i64, i64)

declare double @js_process_prepend_listener(i64, i64)

declare double @js_process_prepend_once_listener(i64, i64)

declare double @js_process_emit(i64, i64)

declare void @js_process_emit_before_exit(double)

declare void @js_process_emit_before_exit_pending()

declare void @js_process_run_exit_sequence()

declare void @js_process_run_finalization_exit()

declare void @js_trace_events_flush_output()

declare void @js_promise_report_unhandled_rejections()

declare i32 @js_process_pending_exit_code()

declare void @js_gc_release_current_thread_collection_side_allocations()

declare double @js_process_remove_listener(i64, i64)

declare double @js_process_off(i64, i64)

declare double @js_process_remove_all_listeners(i64)

declare double @js_process_listener_count(i64, i64)

declare i64 @js_process_listeners(i64)

declare i64 @js_process_raw_listeners(i64)

declare i64 @js_process_event_names()

declare double @js_process_set_max_listeners(double)

declare double @js_process_get_max_listeners()

declare double @js_process_get_builtin_module(double)

declare double @js_process_get_builtin_module_devirt(double)

declare double @js_process_execve(double, double, double)

declare double @js_module_is_builtin(double)

declare double @js_module_find_package_json(double, double, double)

declare double @js_module_find_source_map(double)

declare double @js_module_source_map_new(double, double)

declare double @js_module_register(double, double, double)

declare double @js_module_register_hooks(double)

declare void @js_process_next_tick(i64, i64)

declare double @js_process_stdin()

declare double @js_process_stdout()

declare double @js_process_stderr()

declare double @js_readline_set_raw_mode(double)

declare void @js_readline_stdin_on(i64, i64)

declare double @js_readline_stdin_remove_listener(i64, i64)

declare double @js_readline_stdin_pause()

declare double @js_readline_stdin_resume()

declare double @js_readline_stdin_unref()

declare double @js_readline_stdin_ref()

declare double @js_readline_stdin_destroy()

declare double @js_tty_isatty(double)

declare double @js_tty_read_stream_new(double)

declare double @js_tty_write_stream_new(double)

declare double @js_wasi_constructor_call(double)

declare double @js_process_stdin_isatty()

declare double @js_process_stdout_isatty()

declare double @js_process_stderr_isatty()

declare double @js_process_stdout_columns()

declare double @js_process_stdout_rows()

declare double @js_process_stdout_on(i64, i64)

declare i64 @js_os_platform()

declare i64 @js_os_arch()

declare i64 @js_os_type()

declare i64 @js_os_release()

declare i64 @js_os_hostname()

declare i64 @js_os_eol()

declare double @js_os_available_parallelism()

declare i64 @js_os_endianness()

declare i64 @js_os_dev_null()

declare i64 @js_os_machine()

declare i64 @js_os_loadavg()

declare i64 @js_os_version()

declare i64 @js_box_alloc_bits(i64)

declare i64 @js_box_get_bits(i64)

declare i64 @js_box_get_bits_named(i64, double)

declare void @js_box_set_bits(i64, i64)

declare i64 @js_box_get_bits_trusted(i64)

declare i64 @js_box_get_bits_trusted_named(i64, double)

declare void @js_box_set_bits_trusted_no_barrier(i64, i64)

declare i64 @js_box_alloc(double)

declare double @js_box_get(i64)

declare void @js_box_set(i64, double)

declare i64 @js_i32_box_alloc(i32)

declare i32 @js_i32_box_get(i64)

declare void @js_i32_box_set(i64, i32)

declare void @js_box_release(i64)

declare void @js_i32_box_release(i64)

declare void @js_bool_box_release(i64)

declare i64 @js_bool_box_alloc(i32)

declare i32 @js_bool_box_get(i64)

declare void @js_bool_box_set(i64, i32)

declare i64 @js_arguments_object_alloc(double, double, i32)

declare void @js_arguments_object_map_index(i64, i32, i64)

declare i64 @js_array_like_to_array(double)

declare i32 @js_object_get_class_id(i64)

declare i64 @js_object_alloc_with_parent(i32, i32, i32)

declare i64 @js_object_alloc_class_with_keys(i32, i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_dynamic_parent(i32, i32, ptr, i32)

declare i64 @js_object_alloc_class_inline_keys(i32, i32, i32, i64)

declare i64 @js_object_alloc_class_inline_keys_stamped(i32, i32, i32, i64, i32)

declare i64 @js_build_class_keys_array(i32, i32, ptr, i32)

declare i32 @js_object_shape_id_for_keys(i64, i32)

declare i32 @js_gc_typed_shape_id_for_keys(i32, i64, i32, ptr, i32, ptr, i32)

declare ptr @js_inline_arena_state()

declare ptr @js_inline_arena_slow_alloc(ptr, i64, i64)

declare i32 @js_object_delete_field(i64, i64)

declare i32 @js_object_delete_field_value(double, i64)

declare i32 @js_object_delete_dynamic_value(double, double)

declare double @js_delete_result(i32, i32)

declare i64 @js_eq(i64, i64)

declare i64 @js_loose_eq(i64, i64)

declare i64 @js_number_to_fixed(double, double)

declare i64 @js_string_replace_regex(i64, i64, i64)

declare i64 @js_string_replace_all_regex(i64, i64, i64)

declare double @js_array_at(i64, double)

declare double @js_date_get_time(double)

declare double @js_date_get_full_year(double)

declare double @js_date_get_month(double)

declare double @js_date_get_date(double)

declare double @js_date_get_day(double)

declare double @js_date_get_hours(double)

declare double @js_date_get_minutes(double)

declare double @js_date_get_seconds(double)

declare double @js_date_get_milliseconds(double)

declare double @js_date_get_utc_day(double)

declare double @js_date_get_utc_full_year(double)

declare double @js_date_get_utc_month(double)

declare double @js_date_get_utc_date(double)

declare double @js_date_get_utc_hours(double)

declare double @js_date_get_utc_minutes(double)

declare double @js_date_get_utc_seconds(double)

declare double @js_date_get_utc_milliseconds(double)

declare double @js_date_value_of(double)

declare double @js_date_get_timezone_offset(double)

declare double @js_date_coerce_number(double)

declare double @js_rel_lt(double, double)

declare double @js_rel_le(double, double)

declare double @js_rel_gt(double, double)

declare double @js_rel_ge(double, double)

declare i64 @js_date_to_string(double)

declare i64 @js_date_to_iso_string(double)

declare i64 @js_date_to_iso_string_or_throw(double)

declare double @js_date_new_from_timestamp(double)

declare double @js_date_new_from_value(double)

declare i32 @js_array_indexOf_f64(i64, double)

declare i64 @js_array_indexOf_jsvalue(i64, double, double, i32)

declare i64 @js_array_last_index_of_jsvalue(i64, double, double, i32)

declare i32 @js_array_includes_f64(i64, double)

declare i32 @js_array_includes_jsvalue(i64, double, double, i32)

declare i32 @js_map_size(i64)

declare void @js_map_clear(i64)

declare void @js_set_clear(i64)

declare i64 @js_map_entries(i64)

declare i64 @js_map_keys(i64)

declare i64 @js_map_values(i64)

declare double @js_map_entry_key_at(i64, i32)

declare double @js_map_entry_value_at(i64, i32)

declare double @js_map_entry_key_raw_at(i64, i32)

declare double @js_map_entry_value_raw_at(i64, i32)

declare double @js_set_value_raw_at(i64, i32)

declare double @js_map_find_key_index(double, double)

declare double @js_set_find_value_index(double, double)

declare double @js_map_cursor_next(double, double, double)

declare double @js_map_compaction_epoch(double)

declare double @js_set_cursor_next(double, double, double)

declare double @js_set_compaction_epoch(double)

declare void @js_map_foreach(i64, double, double)

declare void @js_set_foreach(i64, double, double)

declare i64 @js_map_entries_iter_obj(i64)

declare i64 @js_map_keys_iter_obj(i64)

declare i64 @js_map_values_iter_obj(i64)

declare i64 @js_set_values_iter_obj(i64)

declare i64 @js_set_keys_iter_obj(i64)

declare i64 @js_set_entries_iter_obj(i64)

declare i64 @js_set_to_array(i64)

declare double @js_set_value_at(i64, i32)

declare i64 @js_array_splice(i64, i32, i32, ptr, i32, ptr)

declare i32 @js_array_splice_delete_count(double)

declare double @js_parse_int(i64, double)

declare double @js_parse_float(i64)

declare double @js_array_reduce(i64, i64, i32, double)

declare double @js_array_reduce_right(i64, i64, i32, double)

declare i64 @js_array_sort_default(i64)

declare i64 @js_array_reverse(i64)

declare double @js_array_reverse_value(double)

declare i64 @js_array_flat(i64)

declare i64 @js_array_flat_depth(i64, double)

declare i64 @js_array_flatMap(i64, i64)

declare i64 @js_array_sort_with_comparator(i64, i64)

declare i64 @js_validate_array_comparator(double)

declare i64 @js_validate_array_callback(double)

declare i64 @js_validate_array_map_callback(i64, double)

declare i64 @js_array_to_reversed(i64)

declare i64 @js_array_to_sorted_default(i64)

declare i64 @js_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_array_to_spliced(i64, double, double, ptr, i32)

declare i64 @js_array_with(i64, double, double)

declare i64 @js_array_copy_within(i64, double, double, i32, double)

declare double @js_array_copy_within_value(double, double, double, i32, double)

declare i64 @js_regexp_new(i64, i64)

declare i64 @js_regexp_new_site(i64, i64, i64)

declare i64 @js_regexp_new_factory_site(i64, i64, i64, i64)

declare i64 @js_regexp_site_test_new(i64, i64, i64)

declare double @js_regexp_site_factory_call_value(i64, double)

declare double @js_regexp_site_factory_call_method(i64, double, double)

declare double @js_regexp_site_test_get_method(i64, double)

declare double @js_regexp_site_test_dispatch(i64, double, double, double)

declare i64 @js_regexp_construct(double, double)

declare i64 @js_regexp_construct_call(double, double)

declare i32 @js_regexp_test(i64, i64)

declare double @js_regexp_escape(double)

declare i64 @js_get_string_pointer_unified(double)

declare i32 @js_switch_strict_equals(double, double)

declare i64 @js_value_to_str_ptr_for_ffi(double)

declare void @js_string_addref(i64)

declare void @js_string_addref_if_heap_string(double)

declare i64 @js_bigint_from_string(ptr, i32)

declare i64 @js_bigint_from_f64(double)

declare i64 @js_bigint_from_i128_parts(i64, i64)

declare i32 @js_bigint_cmp(i64, i64)

declare double @js_dynamic_add(double, double)

declare double @js_to_numeric(double)

declare double @js_numeric_step(double, i32)

declare i64 @js_box_capture_cell_ptr(i64)

declare double @js_dynamic_string_or_number_add(double, double)

declare double @js_dynamic_sub(double, double)

declare double @js_dynamic_mul(double, double)

declare double @js_dynamic_div(double, double)

declare double @js_dynamic_mod(double, double)

declare double @js_dynamic_bitand(double, double)

declare double @js_dynamic_bitor(double, double)

declare double @js_dynamic_bitxor(double, double)

declare double @js_dynamic_shl(double, double)

declare double @js_dynamic_shr(double, double)

declare double @js_dynamic_bitnot(double)

declare double @js_dynamic_pow(double, double)

declare double @js_dynamic_ushr(double, double)

declare double @js_instanceof(double, i32)

declare double @js_instanceof_dynamic(double, double)

declare double @js_instanceof_noncallable_rhs()

declare void @js_register_class_extends_error(i32)

declare void @js_register_class_extends_data_view(i32)

declare void @js_register_class_extends_typed_array(i32)

declare void @js_register_class_id(i32)

declare void @js_register_class_name(i32, ptr, i32)

declare void @js_register_class_source(i32, ptr, i32)

declare void @js_register_class_length(i32, i32)

declare void @js_register_anon_shape_class_id(i32)

declare double @js_get_global_this_builtin_value(ptr, i64)

declare double @js_promise_static_function_value(ptr, i64)

declare double @js_builtin_prototype_method_value(ptr, i64, ptr, i64)

declare void @js_register_class_parent(i32, i32)

declare void @js_register_class_generic_origin(i32, i32)

declare void @js_register_class_parent_dynamic(i32, double)

declare double @js_get_dynamic_parent_value(i32)

declare void @js_class_register_capture_values(i32, ptr, i64)

declare void @js_class_object_refresh_capture_values(double, i64, double)

declare void @js_tdz_suppress_begin()

declare void @js_tdz_suppress_end()

declare double @js_class_capture_value(i32, i32)

declare double @js_class_capture_value_for_receiver(double, i32, i32)

declare double @js_class_capture_value_or(i32, i32, double)

declare double @js_param_or_class_capture_value(double, i32, i32)

declare void @js_super_construct_apply(i32, double, double)

declare double @js_super_method_call_dynamic(i32, ptr, i64, double, ptr, i64)

declare double @js_super_method_call_dynamic_apply(i32, ptr, i64, double, double)

declare i64 @js_array_push_spread_any(i64, double)

declare i32 @js_set_function_prototype(double, double)

declare double @js_set_prototype_property(double, double, i32)

declare void @js_register_prototype_method(i32, ptr, i64, double)

declare i32 @js_register_function_prototype_method(double, ptr, i64, double)

declare double @js_new_function_construct(double, ptr, i64)

declare double @js_function_ctor_from_strings(ptr, i64)

declare double @js_new_function_construct_apply(double, double)

declare double @js_throw_not_a_constructor()

declare double @js_new_target_value()

declare double @js_get_function_prototype_method(double, ptr, i64)

declare double @js_function_prototype_value_for_read(double)

declare i64 @js_typeerror_new(i64)

declare i64 @js_rangeerror_new(i64)

declare i64 @js_syntaxerror_new(i64)

declare i64 @js_referenceerror_new(i64)

declare double @js_throw_symbol_constructor_type_error()

declare double @js_throw_bigint_constructor_type_error()

declare double @js_throw_strict_eval_arguments_syntax_error()

declare double @js_throw_eval_syntax_error(double)

declare double @js_throw_restricted_function_property_assignment()

declare double @js_throw_math_constructor_type_error()

declare double @js_throw_json_constructor_type_error()

declare double @js_webcrypto_illegal_constructor()

declare double @js_throw_type_error_const_assignment(double)

declare double @js_throw_reference_error_unresolvable_assignment(double)

declare double @js_throw_reference_error_unresolved_get()

declare double @js_with_implicit_unset()

declare double @js_with_implicit_read(double, double)

declare double @js_iterator_result_validate(double)

declare double @js_for_of_next(double)

declare double @js_segments_view_open(double, double)

declare double @js_segments_view_next(double)

declare double @js_segments_view_code_point_at(double, double)

declare double @js_segments_view_segment(double)

declare double @js_segments_view_regexp_test(double, double)

declare double @js_global_get_or_throw_unresolved(double)

declare double @js_module_ambient_require()

declare double @js_module_ambient_require_apply(double)

declare double @js_module_dynamic_import_fallback(double)

declare double @js_module_dynamic_import_deferred(double, double)

declare double @js_module_create_require_devirt(double)

declare double @js_global_get_optional(double)

declare double @js_global_update(double, double, double)

declare double @js_global_assign_existing_or_throw(double, double)

declare double @js_throw_reference_error_this_before_super()

declare double @js_throw_reference_error_super_delete()

declare double @js_throw_reference_error_unresolved_assignment()

declare i64 @js_evalerror_new(i64)

declare i64 @js_urierror_new(i64)

declare i64 @js_weakmap_new()

declare i64 @js_weakset_new()

declare double @js_weakmap_init_iterable(double, double)

declare double @js_weakset_init_iterable(double, double)

declare double @js_weakmap_set(double, double, double)

declare double @js_weakmap_get(double, double)

declare double @js_weakmap_has(double, double)

declare double @js_weakmap_delete(double, double)

declare double @js_weakset_add(double, double)

declare double @js_weakset_has(double, double)

declare double @js_weakset_delete(double, double)

declare double @js_weak_throw_primitive()

declare i64 @js_buffer_from_string(i64, i32)

declare i32 @js_encoding_tag_from_value(double)

declare i64 @js_value_to_string_with_encoding(double, i32)

declare i64 @js_value_to_string_with_encoding_or_radix(double, i32, double)

declare i64 @js_object_values(i64)

declare i64 @js_object_values_value(double)

declare i64 @js_object_entries(i64)

declare i64 @js_object_entries_value(double)

declare i64 @js_path_join(i64, i64)

declare i64 @js_path_win32_join(i64, i64)

declare i64 @js_path_win32_dirname(i64)

declare i64 @js_path_win32_basename(i64)

declare i64 @js_path_win32_basename_ext(i64, i64)

declare i64 @js_path_win32_extname(i64)

declare i32 @js_path_win32_is_absolute(i64)

declare i64 @js_path_win32_normalize(i64)

declare i64 @js_path_win32_parse(i64)

declare i64 @js_path_win32_format(double)

declare i64 @js_path_win32_relative(i64, i64)

declare i64 @js_path_win32_relative_checked(double, double)

declare i64 @js_path_win32_resolve(i64)

declare i64 @js_path_win32_resolve_join(i64, i64)

declare i64 @js_path_win32_to_namespaced_path(i64)

declare double @js_path_win32_to_namespaced_path_value(double)

declare i32 @js_path_win32_matches_glob(i64, i64)

declare i64 @js_path_win32_sep_get()

declare i64 @js_path_win32_delimiter_get()

declare i64 @js_path_dirname(i64)

declare i64 @js_path_resolve(i64)

declare i64 @js_path_relative(i64, i64)

declare i64 @js_path_relative_checked(double, double)

declare i64 @js_path_to_namespaced_path(i64)

declare double @js_path_to_namespaced_path_value(double)

declare i32 @js_path_matches_glob(i64, i64)

declare i64 @js_path_resolve_join(i64, i64)

declare i64 @js_path_arg_header(double)

declare i64 @js_path_join_value(double, double)

declare i64 @js_path_win32_join_value(double, double)

declare i64 @js_path_resolve_join_value(double, double)

declare i64 @js_path_win32_resolve_join_value(double, double)

declare i64 @js_path_basename_ext_value(double, double)

declare i64 @js_path_win32_basename_ext_value(double, double)

declare i32 @js_path_matches_glob_value(double, double)

declare i32 @js_path_win32_matches_glob_value(double, double)

declare double @js_object_from_entries(double)

declare i64 @js_string_match(i64, i64)

declare i64 @js_string_match_all(i64, i64)

declare i64 @js_string_match_all_value(i64, double)

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log2.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.log10.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.exp.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.sin.f64(double) #1

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare double @llvm.cos.f64(double) #1

declare i64 @js_path_basename(i64)

declare i64 @js_path_basename_ext(i64, i64)

declare i64 @js_path_extname(i64)

declare i64 @js_path_sep_get()

declare i64 @js_path_delimiter_get()

declare i64 @js_path_parse(i64)

declare i64 @js_json_parse(i64)

declare i64 @js_json_text_to_string(double)

declare double @js_json_raw_json(double)

declare double @js_json_is_raw_json(double)

declare i64 @js_json_parse_or_null(i64)

declare i64 @js_json_parse_typed_array(i64, i64, i32, i32)

declare i64 @js_date_to_date_string(double)

declare i64 @js_date_to_time_string(double)

declare i64 @js_date_to_utc_string(double)

declare i64 @js_date_to_locale_date_string(double)

declare i64 @js_date_to_locale_time_string(double)

declare i64 @js_date_to_json(double)

declare i64 @js_regexp_exec(i64, i64)

declare i64 @js_number_to_precision(double, double)

declare i64 @js_number_to_exponential(double, double)

declare double @js_date_new()

declare double @js_number_is_integer(double)

declare double @js_number_is_nan(double)

declare double @js_number_is_safe_integer(double)

declare double @js_date_parse(i64)

declare double @js_date_utc(ptr, i32)

declare double @js_date_new_local_components(double, double, double, double, double, double, double)

declare double @js_date_apply_setter(double, i32, i32, ptr, i32)

declare double @js_math_clz32(double)

declare double @js_math_cbrt(double)

declare double @js_math_fround(double)

declare double @js_math_f16round(double)

declare double @js_math_sinh(double)

declare double @js_math_cosh(double)

declare double @js_math_tanh(double)

declare double @js_math_asinh(double)

declare double @js_math_acosh(double)

declare double @js_math_atanh(double)

declare double @js_math_hypot(double, double)

declare double @js_object_is(double, double)

declare i64 @js_path_normalize(i64)

declare i64 @js_path_format(double)

declare i32 @js_path_is_absolute(i64)

declare i64 @js_encode_uri(double)

declare i64 @js_decode_uri(double)

declare i64 @js_encode_uri_component(double)

declare i64 @js_decode_uri_component(double)

declare i64 @js_text_encoder_new()

declare i64 @js_text_decoder_new(double, double, double)

declare i64 @js_text_encoder_encode_llvm(double)

declare i64 @js_text_decoder_decode_llvm(double, double)

declare i64 @js_text_decoder_encoding(double)

declare double @js_text_decoder_fatal(double)

declare double @js_text_decoder_ignore_bom(double)

declare void @js_queue_microtask(i64)

declare void @js_queue_next_tick(i64)

declare void @js_queue_next_tick_args(i64, ptr, i32)

declare void @js_drain_queued_microtasks()

declare i64 @js_uint8array_from_array(i64)

declare i64 @js_uint8array_alloc(i32)

declare i64 @js_uint8array_new(double)

declare i64 @js_uint8array_view(double, double, double)

declare i64 @js_typed_array_new_empty(i32, i32)

declare i64 @js_typed_array_new_from_array(i32, i64)

declare i64 @js_typed_array_new(i32, double)

declare i64 @js_typed_array_view(i32, double, double, double)

declare i32 @js_typed_array_length(i64)

declare double @js_typed_array_get(i64, i32)

declare i32 @js_typed_array_read_int32(i64, i32)

declare double @js_typed_array_read_f64(i64, i32)

declare double @js_u8_buffer_read_f64(i64, i32)

declare double @js_typed_array_index_get_dynamic(i64, double)

declare double @js_typed_array_at(i64, double)

declare void @js_typed_array_set(i64, i32, double)

declare double @js_typed_array_index_set_dynamic(i64, double, double)

declare i32 @js_uint8array_get(i64, i32)

declare double @js_uint8array_index_get_value(i64, i32)

declare void @js_uint8array_set(i64, i32, i32)

declare i64 @js_native_arena_alloc(i64)

declare i64 @js_native_arena_view(i64, i32, i64, i64)

declare i64 @js_native_pod_view(i64, i64, i64, i64, i64, i64)

declare double @js_native_pod_view_length(double)

declare ptr @js_native_abi_check_pod_view_data_ptr(double, i64)

declare i64 @js_native_abi_check_pod_view_record_count(double, i64)

declare void @js_native_arena_dispose(i64)

declare void @js_native_memory_fill_u32(i64, double)

declare void @js_native_memory_copy(i64, i64)

declare i64 @js_typed_array_to_reversed(i64)

declare i64 @js_typed_array_to_sorted_default(i64)

declare i64 @js_typed_array_to_sorted_with_comparator(i64, i64)

declare i64 @js_typed_array_with(i64, double, double)

declare double @js_typed_array_find_last(i64, i64)

declare double @js_typed_array_find_last_index(i64, i64)

declare double @js_typed_array_set_from(i64, double, double)

declare i64 @js_typed_array_subarray(i64, i32, double, i32, double)

declare double @js_object_has_own(double, double)

declare double @js_object_property_is_enumerable(double, double)

declare double @js_object_define_getter(double, double, double)

declare double @js_object_define_setter(double, double, double)

declare double @js_object_lookup_getter(double, double)

declare double @js_object_lookup_setter(double, double)

declare double @js_object_get_own_field_or_undef(double, ptr, i64)

declare double @js_unresolved_namespace_stub()

declare double @js_node_submodule_export_as_function(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace_member(ptr, i32, ptr, i32)

declare double @js_node_submodule_namespace(ptr, i32)

declare void @js_node_submod_install_vm()

declare void @js_node_submod_install_timers()

declare void @js_node_submod_install_timers_promises()

declare void @js_node_submod_install_fs_promises()

declare void @js_node_submod_install_readline_promises()

declare void @js_node_submod_install_stream_promises()

declare void @js_node_submod_install_stream_consumers()

declare void @js_node_submod_install_stream_web()

declare void @js_node_submod_install_hono_jsx_server()

declare void @js_node_submod_install_hono_jsx_streaming()

declare void @js_node_submod_install_sys()

declare void @js_node_submod_install_diagnostics_channel()

declare void @js_node_submod_install_trace_events()

declare void @js_node_submod_install_test()

declare void @js_node_submod_install_test_reporters()

declare void @js_node_submod_install_all()

declare void @js_node_submod_enable_install_all()

declare double @js_unresolved_default_call()

declare double @js_get_global_this()

declare double @js_module_top_this()

declare double @js_global_or_console_property_by_name(i64)

declare void @js_class_register_static_symbol(i32, double, double)

declare void @js_register_class_computed_method(i64, double, i64, i64, i64, i64, i64)

declare void @js_register_class_computed_accessor(i64, double, i64, i64, i64, i64)

declare void @js_class_register_static_field(i32, ptr, i64, double, ptr)

declare double @js_object_define_property(double, double, double)

declare double @js_object_define_get_accessor(double, double, double)

declare double @js_object_get_own_property_descriptor(double, double)

declare double @js_object_get_own_property_descriptors(double)

declare double @js_object_get_own_property_names(double)

declare double @js_symbol_new(double)

declare double @js_symbol_new_empty()

declare double @js_symbol_for(double)

declare double @js_symbol_computed_member(double, double)

declare double @js_symbol_key_for(double)

declare double @js_symbol_description(double)

declare i64 @js_symbol_to_string(double)

declare i32 @js_symbol_equals(double, double)

declare i32 @js_is_symbol(double)

declare i64 @js_object_get_own_property_symbols(double)

declare double @js_object_set_symbol_property(double, double, double)

declare double @js_to_property_key(double)

declare double @js_object_set_property_key(double, double, double)

declare double @js_object_get_property_key(double, double)

declare double @js_object_set_property_key_method(double, double, double)

declare double @js_object_super_get(double, double, double)

declare double @js_object_super_put_value_set(double, double, double, double, i32)

declare double @js_object_super_call(double, double, double, ptr, i64)

declare double @js_object_literal_infer_computed_function_name(double, double)

declare double @js_object_get_symbol_property(double, double)

declare double @js_object_get_symbol_property_ic_miss(double, double, ptr)

declare double @js_object_get_symbol_then_field_ic_miss(double, double, ptr, i64, ptr, ptr)

declare double @js_object_create(double)

declare double @js_object_create_with_props(double, double)

declare double @js_object_freeze(double)

declare double @js_object_seal(double)

declare double @js_object_prevent_extensions(double)

declare void @js_object_copy_own_fields(i64, double)

declare double @js_object_assign_validate_target(double)

declare double @js_object_assign_one(double, double)

declare double @js_string_at(i64, i32)

declare double @js_string_code_point_at(i64, i32)

declare i64 @js_string_from_code_point(double)

declare i64 @js_string_raw(double, double)

declare i64 @js_string_from_char_code(double)

declare i64 @js_string_from_char_code_array(double)

declare double @js_string_char_code_at(i64, i32)

declare i32 @js_string_last_index_of(i64, i64)

declare i32 @js_string_last_index_of_from(i64, i64, double, i32)

declare double @js_string_locale_compare(i64, i64)

declare double @js_string_locale_compare_opts(i64, i64, double)

declare i64 @js_string_normalize(i64, double)

declare i64 @js_string_pad_start(i64, double, i64)

declare i64 @js_string_pad_end(i64, double, i64)

declare i64 @js_string_pad_fill(double)

declare double @js_string_is_well_formed(i64)

declare i64 @js_string_to_well_formed(i64)

declare i32 @js_string_search_regex(i64, i64)

declare i32 @js_string_search_value(i64, double)

declare i64 @js_string_match_value(i64, double)

declare double @js_regexp_exec_get_index()

declare i64 @js_regexp_exec_get_groups()

declare double @js_regexp_get_last_index(i64)

declare void @js_regexp_set_last_index(i64, double)

declare i64 @js_regexp_get_source(i64)

declare i64 @js_regexp_get_flags(i64)

declare i64 @js_string_replace_regex_named(i64, i64, i64)

declare i64 @js_string_replace_all_regex_named(i64, i64, i64)

declare i64 @js_string_replace_string_fn(i64, i64, double)

declare i64 @js_string_replace_string_dyn(i64, i64, double)

declare i64 @js_string_replace_all_string_dyn(i64, i64, double)

declare i64 @js_string_replace_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_all_regex_dyn(i64, i64, double)

declare i64 @js_string_replace_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_search_dyn(i64, double, double)

declare i64 @js_string_replace_all_string_fn(i64, i64, double)

declare i64 @js_string_replace_regex_fn(i64, i64, double)

declare i64 @js_string_replace_all_regex_fn(i64, i64, double)

declare double @js_structured_clone(double)

declare double @js_structured_clone_with_options(double, double)

declare double @js_generator_attach_prototype(double, i32)

declare double @js_generator_attach_closure_prototype(double, i64)

declare i64 @js_weakref_new(double)

declare double @js_weakref_deref(double)

declare i64 @js_finreg_new(double)

declare double @js_finreg_register(double, double, double, double)

declare double @js_finreg_unregister(double, double)

declare i64 @js_atob(double)

declare i64 @js_btoa(double)

declare double @js_object_is_frozen(double)

declare double @js_object_is_sealed(double)

declare double @js_object_is_extensible(double)

declare i64 @js_aggregateerror_new(i64, i64)

declare i64 @js_error_new_with_cause(i64, double)

declare i64 @js_aggregateerror_new_full(double, i64, double)

declare i64 @js_error_new_kind_with_options(i32, i64, double)

declare double @js_error_is_error(double)

declare i64 @js_error_get_errors(i64)

declare i64 @js_crypto_sha256(i64)

declare i64 @js_crypto_sha256_bytes(i64)

declare i64 @js_crypto_md5(i64)

declare i64 @js_crypto_hmac_sha256(i64, i64)

declare i64 @js_crypto_hmac_sha256_bytes(i64, i64)

declare void @js_runtime_validate_string_arg(double, ptr, i32)

declare void @js_set_call_location(ptr, i64, i32)

declare void @js_runtime_validate_crypto_key_arg(double, ptr, i32)

declare void @js_runtime_validate_integer_arg(double, ptr, i32, double, double)

declare i64 @js_crypto_pbkdf2_bytes(i64, i64, double, double, i64)

declare double @js_crypto_pbkdf2_async_alg(i64, i64, double, double, i64, double)

declare i64 @js_crypto_argon2_sync(i64, double)

declare double @js_crypto_argon2_async(i64, double, double)

declare i64 @js_crypto_encapsulate(double)

declare double @js_crypto_encapsulate_async(double, double)

declare i64 @js_crypto_decapsulate(double, double)

declare double @js_crypto_decapsulate_async(double, double, double)

declare i64 @js_crypto_hkdf_bytes_alg(i64, i64, i64, i64, double)

declare double @js_crypto_hkdf_async_alg(i64, i64, i64, i64, double, double)

declare i64 @js_crypto_scrypt_bytes(i64, i64, double, double)

declare double @js_crypto_scrypt_async(i64, i64, double, double, double)

declare i64 @js_crypto_sign_rsa_sha256(i64, i64, double)

declare double @js_crypto_sign_async(i64, i64, double, double)

declare double @js_crypto_verify_rsa_sha256(i64, i64, double, i64)

declare double @js_crypto_verify_async(i64, i64, double, i64, double)

declare i64 @js_crypto_public_encrypt(i64, i64)

declare i64 @js_crypto_private_decrypt(i64, i64)

declare i64 @js_crypto_private_encrypt(i64, i64)

declare i64 @js_crypto_public_decrypt(i64, i64)

declare i64 @js_crypto_create_public_key(i64)

declare i64 @js_crypto_create_private_key_value(double)

declare i64 @js_crypto_create_public_key_value(double)

declare i64 @js_crypto_generate_key_pair_sync_rsa(double)

declare i64 @js_crypto_generate_key_pair_sync_ec_p256(double)

declare i64 @js_crypto_generate_key_pair_sync_ed25519(double)

declare i64 @js_crypto_generate_key_pair_sync_x25519(double)

declare double @js_crypto_generate_key_pair_async(i64, double, double)

declare i64 @js_crypto_diffie_hellman(double)

declare double @js_crypto_get_cipher_info(double, double)

declare i64 @js_crypto_get_curves()

declare i64 @js_crypto_secure_heap_used()

declare i64 @js_crypto_random_bytes_buffer(double)

declare double @js_crypto_random_bytes_async(double, double)

declare i64 @js_crypto_random_uuid(double)

declare i64 @js_crypto_random_uuidv7()

declare double @js_crypto_random_int(double, double)

declare double @js_crypto_random_int_async(double, double, double)

declare double @js_crypto_timing_safe_equal(double, double)

declare i64 @js_crypto_get_hashes()

declare i64 @js_crypto_get_ciphers()

declare double @js_crypto_generate_prime_sync(double, double)

declare double @js_crypto_generate_prime_async(double, double, double)

declare double @js_crypto_check_prime_sync(double, double)

declare double @js_crypto_check_prime_async(double, double, double)

declare i64 @js_crypto_create_secret_key(i64, i64)

declare i64 @js_crypto_generate_key_sync(i64, double)

declare double @js_crypto_generate_key_async(i64, double, double)

declare i64 @js_webcrypto_digest(double, double)

declare i64 @js_webcrypto_import_key(double, double, double, double, double)

declare i64 @js_webcrypto_export_key(double, double)

declare i64 @js_webcrypto_sign(double, double, double)

declare i64 @js_webcrypto_verify(double, double, double, double)

declare i64 @js_webcrypto_derive_bits(double, double, double)

declare i64 @js_webcrypto_derive_key(double, double, double, double, double)

declare i64 @js_webcrypto_encrypt(double, double, double)

declare i64 @js_webcrypto_decrypt(double, double, double)

declare i64 @js_webcrypto_generate_key(double, double, double)

declare i64 @js_webcrypto_wrap_key(double, double, double, double)

declare i64 @js_webcrypto_unwrap_key(double, double, double, double, double, double, double)

declare i64 @js_zlib_create_brotli_decompress(double)

declare double @js_crypto_random_fill_sync(double, double, double)

declare double @js_crypto_random_fill_async(double, double, double, double)

declare double @js_crypto_create_hash(i64)

declare double @js_crypto_create_hash_options(i64, double)

declare double @js_crypto_x509_new(i64)

declare double @js_crypto_certificate_verify_spkac(double)

declare double @js_crypto_certificate_export_public_key(double)

declare double @js_crypto_certificate_export_challenge(double)

declare double @js_crypto_create_sign(i64)

declare double @js_crypto_create_verify(i64)

declare double @js_crypto_create_ecdh(i64)

declare double @js_crypto_create_diffie_hellman(double, double, double)

declare double @js_crypto_get_diffie_hellman(double)

declare double @js_crypto_ecdh_convert_key(double, double, double, double, double)

declare double @js_crypto_create_hmac(i64, i64)

declare i64 @js_buffer_alloc(i32, i32)

declare i64 @js_buffer_alloc_fill_value(i32, double, i32)

declare i64 @js_array_buffer_new(i32)

declare i64 @js_shared_array_buffer_new(i32)

declare i64 @js_array_buffer_new_value(double)

declare i64 @js_shared_array_buffer_new_value(double)

declare i64 @js_json_stringify_full(double, double, double)

declare i64 @js_json_parse_with_reviver(i64, i64)

declare double @js_array_find(i64, i64)

declare i32 @js_array_findIndex(i64, i64)

declare double @js_array_find_last(i64, i64)

declare i32 @js_array_find_last_index(i64, i64)

declare double @js_array_some(i64, i64)

declare double @js_array_some_captureless(i64, ptr)

declare double @js_array_every(i64, i64)

declare i32 @js_promise_state(i64)

declare double @js_promise_value(i64)

declare double @js_promise_reason(i64)

declare i32 @js_value_is_promise(double)

declare double @js_assimilate_thenable(double)

declare i32 @js_promise_run_microtasks()

declare i32 @js_promise_run_microtasks_event_loop()

declare i32 @js_promise_run_microtasks_await_loop()

declare i32 @js_await_loop_tick_timers()

declare void @js_mark_entry_module_esm()

declare i32 @js_promise_run_promise_jobs()

declare void @js_run_stdlib_pump()

declare void @js_sleep_ms(double)

declare void @js_wait_for_event()

declare i32 @js_event_loop_host_driven()

declare void @js_unsettled_top_level_await_exit()

declare void @js_throw(double)

declare void @js_eh_try_push()

declare i32 @perry_eh_personality(...)

declare void @js_try_end()

declare double @js_get_exception()

declare void @js_clear_exception()

declare i32 @js_has_exception()

declare void @js_enter_finally()

declare void @js_leave_finally()

declare double @js_await_any_promise(double)

declare i64 @js_promise_new()

declare i64 @js_promise_new_with_executor(i64)

declare i32 @js_timer_tick()

declare i32 @js_timer_tick_if_refed()

declare i32 @js_callback_timer_tick()

declare i32 @js_interval_timer_tick()

declare i32 @js_timer_has_pending()

declare i32 @js_callback_timer_has_pending()

declare i32 @js_interval_timer_has_pending()

declare i32 @js_stdlib_has_active_handles()

declare i32 @js_bun_ffi_has_active_threadsafe_callbacks()

declare i32 @js_microtasks_pending()

declare i64 @js_timer_validate_callback(double, i32)

declare i64 @js_set_timeout_callback(i64, double)

declare i64 @js_set_timeout_callback_args(i64, double, ptr, i32)

declare i64 @js_set_immediate_callback(i64)

declare i64 @js_set_immediate_callback_args(i64, ptr, i32)

declare i64 @setInterval(i64, double)

declare i64 @js_set_interval_callback_args(i64, double, ptr, i32)

declare void @clearTimeout(i64)

declare void @clearInterval(i64)

declare void @clearImmediate(i64)

declare void @js_clear_timeout_value(double)

declare void @js_clear_interval_value(double)

declare void @js_clear_immediate_value(double)

declare i64 @js_buffer_from_array(i64)

declare i64 @js_buffer_from_arraybuffer_slice(i64, i32, i32)

declare i32 @js_buffer_length(i64)

declare i32 @js_buffer_get(i64, i32)

declare double @js_buffer_index_get_value(i64, i32)

declare ptr @js_native_buffer_data_ptr(double)

declare i64 @js_native_buffer_byte_len(double)

declare void @js_console_time(i64)

declare void @js_console_time_end(i64)

declare void @js_console_time_log(i64)

declare void @js_console_time_value(double)

declare void @js_console_time_end_value(double)

declare void @js_console_time_log_value(double)

declare void @js_console_time_log_spread(double, i64)

declare void @js_console_count(i64)

declare void @js_console_count_reset(i64)

declare void @js_console_count_value(double)

declare void @js_console_count_reset_value(double)

declare double @js_console_new(double)

declare double @js_console_new2(double, double)

declare void @js_console_group_begin()

declare void @js_console_group_end()

declare void @js_console_clear()

declare void @js_console_noop()

declare double @js_native_call_method(double, ptr, i64, ptr, i64)

declare double @js_native_call_method_by_id(double, i64, ptr, i64)

declare double @js_native_call_method_apply(double, ptr, i64, i64)

declare double @js_native_call_method_apply_by_id(double, i64, i64)

declare double @js_native_call_method_str_key(double, i64, ptr, i64)

declare double @js_native_call_method_value(double, double, ptr, i64)

declare double @js_native_call_method_value_apply(double, double, i64)

declare void @js_promise_resolve(i64, double)

declare void @js_promise_reject(i64, double)

declare void @js_promise_mark_internally_handled(i64)

declare i64 @js_promise_resolved(double)

declare i64 @js_async_fn_result(double)

declare i64 @js_promise_rejected(double)

declare double @js_create_namespace(i32, ptr, ptr, ptr, ptr)

declare double @js_finalize_namespace(double)

declare i64 @js_promise_then(i64, i64, i64)

declare i64 @js_promise_resolved_then(double, i64, i64)

declare i64 @js_promise_finally(i64, i64)

declare double @js_promise_then_checked(double, double, double)

declare double @js_promise_catch_checked(double, double)

declare double @js_promise_finally_checked(double, double)

declare i64 @js_promise_closure_arg(double)

declare i64 @js_promise_all(i64)

declare i64 @js_promise_race(i64)

declare i64 @js_promise_any(i64)

declare i64 @js_promise_all_settled(i64)

declare i64 @js_promise_all_iterable(double)

declare i64 @js_promise_race_iterable(double)

declare i64 @js_promise_any_iterable(double)

declare i64 @js_promise_all_settled_iterable(double)

declare i64 @js_promise_with_resolvers()

declare i64 @js_promise_try(double, i64)

declare i64 @js_array_unshift_f64(i64, double)

declare i64 @js_array_unshift_variadic(i64, ptr, i32)

declare i64 @js_array_entries(i64)

declare i64 @js_array_keys(i64)

declare i64 @js_array_values(i64)

declare i64 @js_array_entries_iter_obj(i64)

declare i64 @js_array_keys_iter_obj(i64)

declare i64 @js_array_values_iter_obj(i64)

declare double @js_response_new(i64, double, i64, double)

declare double @js_fetch_unwrap_handle(double)

declare double @js_response_body_init_reset()

declare i64 @js_response_body_init_ptr(double)

declare double @js_headers_new()

declare double @js_headers_set(double, i64, i64)

declare double @js_headers_append(double, i64, i64)

declare i64 @js_headers_get(double, i64)

declare double @js_headers_get_set_cookie(double)

declare double @js_headers_has(double, i64)

declare double @js_headers_delete(double, i64)

declare double @js_headers_for_each(double, double)

declare double @js_headers_keys(double)

declare double @js_headers_values(double)

declare double @js_headers_entries(double)

declare double @js_headers_init_from_value(double, double)

declare double @js_headers_method_value(double, i64, i64)

declare double @js_request_new(i64, i64, i64, double, i64, i64, i64, i64, i64, i64, i64, double, i64, double)

declare double @js_request_new_from_init(i64, double)

declare i64 @js_request_get_url(double)

declare i64 @js_request_input_to_url(double)

declare i64 @js_request_get_method(double)

declare double @js_request_get_body(double)

declare double @js_request_body_used(double)

declare i64 @js_request_get_destination(double)

declare i64 @js_request_get_referrer(double)

declare i64 @js_request_get_referrer_policy(double)

declare i64 @js_request_get_mode(double)

declare i64 @js_request_get_credentials(double)

declare i64 @js_request_get_cache(double)

declare i64 @js_request_get_redirect(double)

declare i64 @js_request_get_integrity(double)

declare double @js_request_get_keepalive(double)

declare i64 @js_request_get_duplex(double)

declare double @js_request_get_signal(double)

declare double @js_request_get_headers(double)

declare i64 @js_request_text(double)

declare i64 @js_request_json(double)

declare i64 @js_request_array_buffer(double)

declare i64 @js_request_blob(double)

declare i64 @js_request_bytes(double)

declare i64 @js_request_form_data(double)

declare double @js_request_clone(double)

declare double @js_fetch_response_status(double)

declare i64 @js_fetch_response_status_text(double)

declare double @js_fetch_response_ok(double)

declare i64 @js_fetch_response_type(double)

declare i64 @js_fetch_response_url(double)

declare double @js_fetch_response_redirected(double)

declare double @js_response_body_used(double)

declare i64 @js_fetch_response_text(double)

declare i64 @js_fetch_response_json(double)

declare double @js_response_get_headers(double)

declare double @js_response_clone(double)

declare i64 @js_response_array_buffer(double)

declare i64 @js_response_blob(double)

declare i64 @js_response_bytes(double)

declare i64 @js_response_form_data(double)

declare double @js_form_data_new()

declare double @js_form_data_append(double, double, double, double)

declare double @js_form_data_set(double, double, double, double)

declare double @js_form_data_delete(double, i64)

declare double @js_form_data_get(double, i64)

declare double @js_form_data_get_all(double, i64)

declare double @js_form_data_has(double, i64)

declare double @js_form_data_entries(double)

declare double @js_form_data_keys(double)

declare double @js_form_data_values(double)

declare double @js_form_data_for_each(double, double)

declare double @js_blob_size(double)

declare i64 @js_blob_type(double)

declare i64 @js_blob_array_buffer(double)

declare i64 @js_blob_bytes(double)

declare i64 @js_blob_text(double)

declare double @js_blob_slice(double, double, double, i64)

declare double @js_blob_new(double, double)

declare double @js_file_new(double, double, double, double)

declare i64 @js_file_name(double)

declare double @js_file_last_modified(double)

declare i64 @js_url_create_object_url(double)

declare void @js_url_revoke_object_url(double)

declare double @js_buffer_resolve_object_url(double)

declare double @js_response_static_json(double, double, i64, double)

declare double @js_response_static_redirect(i64, double)

declare double @js_response_static_error()

declare double @js_blob_stream(double)

declare double @js_response_body(double)

declare double @js_readable_stream_new(double, double, double, double)

declare double @js_readable_stream_new_with_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_with_strategy_and_source_type(double, double, double, double, double)

declare double @js_readable_stream_new_from_source_object(double, double)

declare double @js_readable_stream_get_reader(double)

declare double @js_readable_stream_get_reader_with_options(double, double)

declare double @js_readable_stream_get_byob_reader(double)

declare double @js_readable_stream_controller_byob_request(double)

declare double @js_readable_stream_from_iterable(double)

declare double @js_readable_stream_locked(double)

declare i64 @js_readable_stream_cancel(double, double)

declare double @js_readable_stream_tee(double)

declare i64 @js_readable_stream_pipe_to(double, double, double)

declare double @js_readable_stream_pipe_through(double, double, double)

declare double @js_readable_stream_pipe_through_validate(double, double, double, double)

declare double @js_readable_stream_controller_enqueue(double, double)

declare double @js_readable_stream_controller_close(double)

declare double @js_readable_stream_controller_error(double, double)

declare double @js_readable_stream_controller_desired_size(double)

declare i64 @js_reader_read(double)

declare i64 @js_reader_read_with_view(double, double)

declare double @js_reader_release_lock(double)

declare i64 @js_reader_closed(double)

declare i64 @js_reader_cancel(double, double)

declare double @js_writable_stream_new(double, double, double, double, double)

declare double @js_writable_stream_new_with_sink_type(double, double, double, double, double, double)

declare double @js_writable_stream_new_from_sink_object(double, double)

declare double @js_writable_stream_throw_invalid_sink()

declare double @js_writable_stream_get_writer(double)

declare double @js_writable_stream_locked(double)

declare i64 @js_writable_stream_close(double)

declare i64 @js_writable_stream_abort(double, double)

declare i64 @js_writer_write(double, double)

declare i64 @js_writer_close(double)

declare i64 @js_writer_abort(double, double)

declare double @js_writer_release_lock(double)

declare i64 @js_writer_closed(double)

declare i64 @js_writer_ready(double)

declare double @js_writer_desired_size(double)

declare double @js_transform_stream_new(double, double, double, double, double)

declare double @js_transform_stream_new_from_transformer_object(double, double, double)

declare double @js_transform_stream_readable(double)

declare double @js_transform_stream_writable(double)

declare double @js_text_encoding_stream_new()

declare double @js_text_encoder_stream_new()

declare double @js_text_decoder_stream_new()

declare double @js_stream_web_text_encoder_stream_new()

declare double @js_stream_web_text_decoder_stream_new(double, double)

declare double @js_stream_web_compression_stream_new(double)

declare double @js_stream_web_decompression_stream_new(double)

declare double @js_streams_strategy_high_water_mark(double)

declare double @js_count_queuing_strategy_new(double)

declare double @js_byte_length_queuing_strategy_new(double)

declare double @js_stream_unwrap_handle(double)

declare double @js_readable_stream_subclass_init(double, double, double, double, double)

declare double @js_writable_stream_subclass_init(double, double, double, double, double)

declare double @js_transform_stream_subclass_init(double, double, double, double)

declare double @js_request_subclass_init(double, double, double)

declare double @js_response_subclass_init(double, double, double)

declare double @js_fetch_or_value_super(double, double, ptr, i64)

declare double @js_builtin_subclass_construct(i32, ptr, i64, ptr, i64)

declare i64 @js_abort_controller_new()

declare i64 @js_abort_controller_signal(i64)

declare void @js_abort_controller_abort(i64)

declare void @js_abort_controller_abort_reason(i64, double)

declare void @js_abort_signal_add_listener(i64, double, double)

declare i64 @js_abort_signal_timeout(double)

declare i64 @js_abort_signal_abort(double)

declare i64 @js_abort_signal_any(i64)

declare double @js_abort_signal_throw_if_aborted(i64)

declare i64 @js_event_target_new()

declare i64 @js_event_new(double, double, i32)

declare double @js_event_subclass_init(double, double, double, i32, i32)

declare i64 @js_custom_event_new(double, double, i32)

declare i64 @js_dom_exception_new(double, double)

declare double @js_dom_exception_subclass_init(double, double, double)

declare void @js_event_target_add_event_listener(i64, i64, i64)

declare void @js_event_target_add_event_listener_with_options(i64, i64, i64, double)

declare void @js_event_target_remove_event_listener(i64, i64, i64)

declare void @js_event_target_remove_event_listener_with_options(i64, i64, i64, double)

declare double @js_event_target_dispatch_event(i64, double)

declare i32 @js_event_target_is_event_target(i64)

declare i64 @js_event_target_get_event_listeners(i64, i64)

declare double @js_event_target_get_max_listeners(i64)

declare i32 @js_event_target_set_max_listeners(i64, double)

declare double @js_message_channel_new()

declare double @js_message_port_constructor_error()

declare double @js_broadcast_channel_new(double)

declare i64 @js_array_alloc(i32)

declare i64 @js_tagged_template_register_raw(i64, i64)

declare i64 @js_tagged_template_get_or_init(i64, i64, i64)

declare i64 @js_template_raw(i64)

declare i64 @js_array_create()

declare i64 @js_array_constructor_single(double)

declare i64 @js_array_alloc_literal(i32)

declare i64 @js_array_from_values(ptr, i32)

declare double @js_value_from_const_descriptor(ptr, i32)

declare i64 @js_array_push_f64(i64, double)

declare i64 @js_array_push_u31_with_length(i64, i32, ptr)

declare i64 @js_array_push_f64_spec(i64, double)

declare void @js_array_push_guard(i64)

declare i64 @js_array_push_hole(i64)

declare i64 @js_array_numeric_push_f64_unboxed(i64, double)

declare i64 @js_array_push_spread_f64(i64, i64)

declare double @js_array_get_f64(i64, i32)

declare i32 @js_array_ensure_element_shape(i64)

declare double @js_array_get_index_or_string(i64, double)

declare double @js_array_numeric_get_f64_unboxed(i64, i32)

declare void @js_array_set_f64(i64, i32, double)

declare i32 @js_array_numeric_set_f64_unboxed(i64, i32, double)

declare i64 @js_array_set_f64_extend(i64, i32, double)

declare i64 @js_array_set_f64_extend_strict(i64, i32, double)

declare i64 @js_array_fill_f64_const_extend(i64, i32, double)

declare i64 @js_array_fill_f64_iota_extend(i64, i32)

declare i64 @js_array_fill_f64_const_len_extend(i64, double)

declare i64 @js_array_fill_f64_iota_len_extend(i64)

declare i64 @js_array_numeric_range_add(double, double, double, double)

declare i64 @js_array_numeric_range_add_len(double, double, double)

declare i64 @js_array_fill_range_strided_tagged(double, double, double, double, i64)

declare i64 @js_array_set_string_key(i64, i64, double)

declare i64 @js_array_set_index_or_string(i64, double, double)

declare i64 @js_array_mark_arguments_object(i64)

declare i32 @js_array_mark_numeric_f64_layout(i64)

declare i32 @js_array_is_numeric_f64_layout(i64)

declare void @js_array_clear_numeric_layout(i64)

; Function Attrs: nounwind willreturn
declare double @js_array_numeric_value_to_raw_f64(double) #0

declare double @js_array_refresh_local_head(double)

declare void @js_array_note_numeric_write(i64, i64)

declare void @js_array_declare_all_pointer_elements(i64)

declare i32 @js_array_length(i64)

declare double @js_array_is_array(double)

declare double @js_value_length_f64(double)

declare double @js_value_length_property_f64(double)

declare double @js_value_length_property_ic_f64(double, ptr)

declare nonnull ptr @js_shadow_frame_enter(i32)

declare i64 @js_shadow_frame_push(i32)

declare void @js_shadow_frame_pop(i64)

declare void @js_shadow_slot_set(i32, i64)

declare void @js_shadow_slot_bind(i32, ptr)

declare void @js_gc_write_barriers_emitted(i32)

declare i32 @js_gc_temp_root_push(i64)

declare i64 @js_gc_temp_root_get(i32)

declare void @js_gc_temp_root_set(i32, i64)

declare void @js_gc_temp_root_truncate(i32)

declare void @js_array_push_f64_temp_rooted(i32, double)

declare void @js_gc_loop_safepoint()

declare void @js_write_barrier(i64, i64)

declare void @js_write_barrier_slot(i64, i64, i64)

declare i64 @js_array_live_head(i64)

declare void @js_write_barrier_slot_validated_parent(i64, i64, i64)

declare void @js_write_barrier_root_nanbox(i64)

declare void @js_write_barrier_root_heap_word(i64)

declare void @js_gc_note_slot_layout(i64, i32, i64)

declare void @js_gc_note_slot_layout_aware(i64, i32, i64, i64)

declare void @js_gc_init_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_declare_typed_shape_layout(i64, i32, ptr, i32, ptr, i32)

declare void @js_gc_forget_object_layout(i64)

declare double @js_array_pop_f64(i64)

declare i64 @js_array_join(i64, i64)

declare i64 @js_array_join_value(i64, double)

declare void @js_array_forEach(i64, i64)

declare i64 @js_array_fill(i64, double)

declare i64 @js_array_fill_range(i64, double, double, double)

declare double @js_array_fill_generic(double, double, i32, double, i32, double)

declare i32 @js_array_delete(i64, i32)

declare void @js_array_set_length(i64, double)

declare void @js_array_set_length_strict(i64, double)

declare i64 @js_array_clone(i64)

declare i32 @js_short_packed_spread_values(double, ptr)

declare i64 @js_spread_tail_fallback_args(ptr, i64, double)

declare i64 @js_array_from_value(double)

declare i64 @js_array_from_arraylike_holey_value(double)

declare double @js_iterator_from(double)

declare i64 @js_array_from_mapped(double, double, double)

declare i64 @js_array_concat_variadic(i64, ptr, i32)

declare double @js_arraylike_forEach(double, double, double)

declare double @js_arraylike_map(double, double, double)

declare double @js_arraylike_filter(double, double, double)

declare double @js_arraylike_some(double, double, double)

declare double @js_arraylike_every(double, double, double)

declare double @js_arraylike_find(double, double, double)

declare double @js_arraylike_findIndex(double, double, double)

declare double @js_arraylike_findLast(double, double, double)

declare double @js_arraylike_findLastIndex(double, double, double)

declare double @js_arraylike_reduce(double, double, i32, double)

declare double @js_arraylike_reduceRight(double, double, i32, double)

declare double @js_arraylike_indexOf(double, double, double, i32)

declare double @js_arraylike_lastIndexOf(double, double, double, i32)

declare double @js_arraylike_includes(double, double, double, i32)

declare double @js_arraylike_at(double, double)

declare double @js_arraylike_join(double, double)

declare double @js_arraylike_flat(double, double)

declare double @js_arraylike_slice(double, double, i32, double, i32)

declare double @js_arraylike_sort(double, double)

declare double @js_arraylike_splice(double, ptr, i32)

declare double @js_arraylike_concat(double, ptr, i32)

declare double @js_arraylike_pop(double)

declare double @js_arraylike_shift(double)

declare double @js_arraylike_push(double, ptr, i32)

declare double @js_arraylike_unshift(double, ptr, i32)

declare i64 @js_array_clone_for_spread(double)

declare i64 @js_array_spread_append(i64, double)

declare i64 @js_iterator_to_array(double)

declare double @js_iterator_next_result(double)

declare double @js_iterator_close_if_not_done(double, double)

declare double @js_iterator_rest_to_array(double, double)

declare double @js_get_iterator(double)

declare double @js_get_async_iterator(double)

declare double @js_for_of_to_array(double)

declare i64 @js_object_alloc(i32, i32)

declare double @js_object_coerce(double)

declare void @js_object_mark_class(i64)

declare void @js_class_object_pin_parent(i64, i32)

declare i64 @js_object_alloc_with_shape(i32, i32, ptr, i32)

declare void @js_object_set_field(i64, i32, i64)

declare i64 @js_object_get_field(i64, i32)

declare void @js_object_set_field_by_name(i64, i64, double)

declare void @js_object_set_field_by_property_id(i64, i64, double)

declare void @js_object_set_field_by_name_nonenum(i64, i64, double)

declare void @js_error_subclass_default_init(double, double)

declare void @js_object_set_field_by_name_nonconfigurable(i64, i64, double)

declare void @js_error_apply_cause_to_object(i64, double)

declare void @js_error_subclass_capture_stack(double)

declare i32 @js_with_has_binding(double, i64)

declare double @js_with_get_binding(double, i64)

declare double @js_with_set_binding(double, i64, double, i32)

declare i32 @js_with_delete_binding(double, i64)

declare i32 @js_pod_scalar_write_compatible(double, i32)

declare void @js_typed_feedback_register_site(i64, i32, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64, ptr, i64)

declare void @js_typed_feedback_record_guard_pass(i64)

declare void @js_typed_feedback_record_guard_fail(i64)

declare void @js_typed_feedback_record_fallback_call(i64)

declare void @js_typed_feedback_observe_property_get(i64, i64, i64)

declare void @js_typed_feedback_observe_property_set(i64, i64, i64)

declare double @js_typed_feedback_object_get_field_by_name_f64(i64, i64, i64)

declare void @js_typed_feedback_object_set_field_by_name(i64, i64, i64, double)

declare void @js_typed_feedback_object_set_field_by_name_fast(i64, i64, i64, double)

declare i32 @js_typed_feedback_class_field_set_guard(i64, double, i32, i32, i64, i32, double, i32)

declare void @js_class_field_set_fallback(i64, i64, i64, double)

declare void @js_class_field_set_ic(i64, double, i32, i32, i64, i32, double, i32)

declare i32 @js_typed_feedback_class_field_get_guard(i64, double, i32, i32, i64, i32, i32)

declare double @js_class_field_get_ic(i64, double, i32, i32, i64, i32, i32)

declare double @js_typed_feedback_native_call_method(i64, double, ptr, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_by_id(i64, double, i64, ptr, i64)

declare double @js_typed_feedback_native_call_method_apply(i64, double, ptr, i64, i64)

declare double @js_typed_feedback_native_call_method_apply_by_id(i64, double, i64, i64)

declare i32 @js_typed_feedback_method_direct_call_guard(i64, double, i32, i32, ptr, i64, ptr)

declare i32 @js_method_direct_shape_guard(double, i32, i32, i32)

declare i32 @js_method_direct_shape_class(double, ptr, i32)

declare i32 @js_typed_feedback_closure_direct_call_guard(i64, double, ptr, i32, i32)

declare i64 @js_closure_exact_func_guard(double, ptr)

declare i64 @js_object_own_method_cache_miss(double, i32, i32, ptr, i64, ptr, ptr)

declare void @js_typed_feedback_object_set_unboxed_f64_field(i64, i64, i32, i64, double)

declare double @js_typed_feedback_observe_helper_return(i64, double)

declare void @js_object_set_index_polymorphic(i64, double, double)

declare double @js_object_get_index_polymorphic(i64, double)

declare double @js_object_get_field_by_name_f64(i64, i64)

declare double @js_object_get_field_by_name_boxed(double, i64)

declare double @js_object_get_field_by_property_id_f64(i64, i64)

declare double @js_native_module_property_by_name(ptr, i64, ptr, i64)

declare double @js_native_module_esm_export_value(double, double)

declare double @js_native_module_named_esm_export_value(double, double)

declare double @js_create_native_module_namespace(ptr, i64)

declare void @js_nm_install_assert()

declare void @js_nm_install_async_hooks()

declare void @js_nm_install_bigint()

declare void @js_nm_install_buffer()

declare void @js_bun_tcp_nm_install()

declare void @js_nm_install_bun()

declare void @js_nm_install_bun_ffi()

declare void @js_nm_install_child_process()

declare void @js_nm_install_cluster()

declare void @js_nm_install_console()

declare void @js_nm_install_crypto()

declare void @js_nm_install_dgram()

declare void @js_nm_install_dns()

declare void @js_nm_install_domain()

declare void @js_nm_install_events()

declare void @js_nm_install_fs()

declare void @js_nm_install_http()

declare void @js_nm_install_inspector()

declare void @js_nm_install_module()

declare void @js_nm_install_net()

declare void @js_nm_install_node_pty()

declare void @js_nm_install_os()

declare void @js_nm_install_path()

declare void @js_nm_install_perf()

declare void @js_nm_install_process()

declare void @js_nm_install_punycode()

declare void @js_nm_install_querystring()

declare void @js_nm_install_readline()

declare void @js_nm_install_repl()

declare void @js_nm_install_sea()

declare void @js_nm_install_sqlite()

declare void @js_nm_install_stream()

declare void @js_nm_install_timers()

declare void @js_nm_install_tls()

declare void @js_nm_install_tty()

declare void @js_nm_install_url()

declare void @js_nm_install_util()

declare void @js_nm_install_v8()

declare void @js_nm_install_vm()

declare void @js_nm_install_wasi()

declare void @js_nm_install_zlib()

declare void @js_nm_install_all()

declare double @js_object_get_field_ic_miss(i64, i64, ptr)

declare double @js_object_get_field_ic(i64, i64, i64, ptr)

declare i64 @js_object_rest(i64, i64)

declare double @js_require_object_coercible(double)

declare double @js_require_json_disk(double)

declare double @js_require_resolve_node_modules(double, double)

declare void @js_globalthis_seed_async_local_storage()

declare void @js_register_path_module_partial(double, double)

declare void @js_register_path_module(double, double)

declare void @js_link_path_module_parent(double)

declare void @js_run_module_init_catching(i64)

declare double @js_require_path_module(double)

declare double @js_has_path_module(double)

declare void @js_register_path_init(ptr, i64, i64)

declare i64 @js_array_alloc_with_length(i32)

declare void @js_array_set_f64_unchecked(i64, i32, double)

declare double @js_typed_feedback_array_get_f64(i64, i64, i32)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_get_guard(i64, double, i32, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_get_guard(i64, double, i32, i32) #0

declare i32 @js_typed_feedback_packed_f64_array_loop_guard(i64, double)

declare i32 @js_string_array_range_loop_guard(double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense(i64, double, i32, i32)

declare i32 @js_typed_feedback_packed_f64_range_loop_guard_dense_i32(i64, double, i32, i32)

declare i32 @js_typed_feedback_masked_window_ta_kind(i64, double, i32, i32)

declare i64 @js_typed_array_masked_window_data_ptr(double)

declare i64 @js_packed_ecs_u32_loop_guard(double, double, double, double, double, double, i32, ptr)

declare i32 @js_typed_feedback_packed_u32_array_loop_guard(i64, double)

declare double @js_typed_feedback_array_index_get_fallback_boxed(i64, double, double)

declare void @js_typed_feedback_array_set_f64(i64, i64, i32, double)

declare i64 @js_typed_feedback_array_set_f64_extend(i64, i64, i32, double)

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_plain_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_index_set_guard(i64, double, i32, double, i32) #0

; Function Attrs: nounwind willreturn
declare i32 @js_typed_feedback_numeric_array_push_guard(i64, double, double) #0

declare double @js_typed_feedback_array_index_set_fallback_boxed(i64, double, double, double, i32)

declare void @js_typed_feedback_observe_array_element(i64, i64, i32)

declare i64 @js_typed_feedback_array_set_string_key(i64, i64, i64, double)

declare i64 @js_typed_feedback_array_set_index_or_string(i64, i64, double, double, i32)

declare void @js_typed_feedback_object_set_index_polymorphic(i64, i64, double, double)

declare double @js_proxy_new(double, double)

declare double @js_proxy_revocable(double, double)

declare void @js_proxy_revoke(double)

declare i32 @js_proxy_is_revoked(double)

declare i32 @js_proxy_is_proxy(double)

declare double @js_proxy_target(double)

declare double @js_proxy_get(double, double)

declare double @js_proxy_set(double, double, double)

declare double @js_proxy_has(double, double)

declare double @js_proxy_delete(double, double)

declare double @js_proxy_apply(double, double, double)

declare double @js_proxy_construct(double, double, double)

declare double @js_reflect_construct(double, double, double)

declare double @js_reflect_get(double, double, double)

declare double @js_reflect_set(double, double, double, double)

declare double @js_put_value_set(double, double, double, double, i32)

declare i32 @js_transition_ic_spill_append(double, i64, i32, double)

declare ptr @perry_transition_cache_base()

declare void @js_transition_ic_note_hit()

declare double @js_put_value_set_dyn_ic(ptr, double, double, double, i32)

declare double @js_put_value_set_ic_miss(double, i64, double, i32, ptr, i32)

declare i32 @js_put_value_set_ic_overflow_store(double, i64, i32, double)

declare double @js_object_get_field_ic_overflow_load(i64, i64, i32, ptr)

declare double @js_put_value_set_ic_poly_tail(ptr, double, i64, double, i32)

declare i64 @js_object_array_numeric_write_guard(double, double, double, double, double, i32, i32)

declare i64 @js_object_array_numeric_write_range_guard(double, double, double, double, double, i32, i32, i32)

declare double @js_super_put_value_set(i32, double, double, double, i32)

declare double @js_super_accessor_get(i32, double, double)

declare double @js_reflect_has(double, double)

declare double @js_reflect_delete(double, double)

declare double @js_reflect_own_keys(double)

declare double @js_reflect_apply(double, double, double)

declare double @js_reflect_define_property(double, double, double)

declare double @js_reflect_get_own_property_descriptor(double, double)

declare double @js_reflect_get_prototype_of(double)

declare double @js_reflect_set_prototype_of(double, double)

declare double @js_reflect_is_extensible(double)

declare double @js_reflect_prevent_extensions(double)

declare double @js_reflect_define_metadata(double, double, double, double)

declare double @js_reflect_get_metadata(double, double, double)

declare double @js_reflect_get_own_metadata(double, double, double)

declare double @js_reflect_has_metadata(double, double, double)

declare double @js_reflect_has_own_metadata(double, double, double)

declare double @js_reflect_get_metadata_keys(double, double)

declare double @js_reflect_get_own_metadata_keys(double, double)

declare double @js_reflect_delete_metadata(double, double, double)

declare double @js_http_server_construct_with_this(double, double, double)

declare double @js_https_server_construct_with_this(double, double, double)

declare i64 @js_net_socket_set_encoding(i64, i64)

declare double @js_vm_create_context(double, double)

declare double @js_vm_create_script_branded(double, double)

declare double @js_vm_module_call()

declare double @js_vm_module_constructor_error()

declare double @js_repl_start(double)

declare double @js_repl_repl_server_new(double)

declare double @js_repl_recoverable_new(double)

declare double @js_worker_threads_worker_new(i64, double)

declare double @js_worker_threads_worker_post_message(i64, double)

declare double @js_worker_threads_worker_on(i64, double, i64)

declare double @js_worker_threads_worker_once(i64, double, i64)

declare double @js_worker_threads_worker_off(i64, double, i64)

declare double @js_worker_threads_worker_add_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_remove_event_listener(i64, double, i64)

declare double @js_worker_threads_worker_terminate(i64)

declare double @js_worker_threads_worker_ref(i64)

declare double @js_worker_threads_worker_unref(i64)

declare double @js_worker_threads_worker_get_heap_statistics(i64)

declare double @js_worker_threads_worker_cpu_usage(i64, double)

declare double @js_worker_threads_worker_get_heap_snapshot(i64, double)

declare double @js_worker_threads_worker_start_cpu_profile(i64)

declare double @js_worker_threads_worker_start_heap_profile(i64)

declare i64 @js_http_client_request_end(i64, double)

declare i64 @js_http_client_request_write(i64, double)

declare i64 @js_http_client_request_end_full(i64, double, i64, i64)

declare double @js_http_client_request_write_full(i64, double, i64, i64)

declare i64 @js_http_set_timeout_full(i64, double, i64)

declare i64 @js_http_client_request_method(i64)

declare i64 @js_http_client_request_protocol(i64)

declare i64 @js_http_client_request_host(i64)

declare i64 @js_http_client_request_path(i64)

declare double @js_http_client_request_listener_count(i64, i64)

declare double @js_http_client_request_get_header(i64, i64)

declare double @js_http_client_request_has_header(i64, i64)

declare double @js_http_client_request_remove_header(i64, i64)

declare double @js_http_client_request_get_header_names(i64)

declare double @js_http_client_request_get_headers(i64)

declare double @js_http_client_request_get_raw_header_names(i64)

declare double @js_http_client_request_abort(i64)

declare i64 @js_http_client_request_destroy(i64, double)

declare double @js_http_client_request_noop_undefined(i64, double, double)

declare double @js_http_client_request_aborted(i64)

declare double @js_http_client_request_destroyed(i64)

declare double @js_http_client_request_finished(i64)

declare double @js_http_client_request_reused_socket(i64)

declare double @js_http_client_request_max_headers_count(i64)

declare double @js_http_client_request_writable_ended(i64)

declare double @js_http_client_request_writable_finished(i64)

declare double @js_http_client_request_socket(i64)

declare i64 @js_http_get(double, i64)

declare i64 @js_http_get_overload(i64)

declare i64 @js_http_request_overload(i64)

declare i64 @js_https_get_overload(i64)

declare i64 @js_https_request_overload(i64)

declare i64 @js_http_on(i64, i64, i64)

declare i64 @js_http_once(i64, i64, i64)

declare i64 @js_http_request(double, i64)

declare i64 @js_http_request_body(i64)

declare double @js_http_request_body_length(i64)

declare i64 @js_http_request_content_type(i64)

declare double @js_http_request_has_header(i64, i64)

declare i64 @js_http_request_header(i64, i64)

declare i64 @js_http_request_headers_all(i64)

declare double @js_http_request_id(i64)

declare double @js_http_request_is_method(i64, i64)

declare i64 @js_http_request_method(i64)

declare i64 @js_http_request_path(i64)

declare i64 @js_http_request_query(i64)

declare i64 @js_http_request_query_all(i64)

declare i64 @js_http_request_query_param(i64, i64)

declare double @js_http_respond_error(i64, double, i64)

declare double @js_http_respond_html(i64, double, i64)

declare double @js_http_respond_json(i64, double, i64)

declare double @js_http_respond_not_found(i64)

declare double @js_http_respond_redirect(i64, i64, double)

declare i64 @js_http_respond_status_text(double)

declare double @js_http_respond_text(i64, double, i64)

declare double @js_http_respond_with_headers(i64, double, i64, i64)

declare double @js_http_response_headers(i64)

declare double @js_http_response_trailers(i64)

declare double @js_http_incoming_message_socket(i64)

declare double @js_http_incoming_message_req(i64)

declare i64 @js_http_incoming_message_set_encoding(i64, i64)

declare i64 @js_http_server_accept_v2(i64)

declare double @js_http_server_close(i64)

declare i64 @js_http_server_create(double)

declare i64 @js_http_set_header(i64, i64, i64)

declare i64 @js_http_set_timeout(i64, double)

declare double @js_http_status_code(i64)

declare i64 @js_http_status_message(i64)

declare i64 @js_http_agent_new(double)

declare i64 @js_https_agent_new(double)

declare i64 @js_http_agent_get_name(i64, double)

declare i64 @js_http_agent_noop_self(i64)

declare double @js_http_agent_max_sockets(i64)

declare double @js_http_agent_max_free_sockets(i64)

declare double @js_http_agent_max_total_sockets(i64)

declare double @js_http_agent_keep_alive_msecs(i64)

declare double @js_http_agent_keep_alive(i64)

declare i64 @js_http_agent_protocol(i64)

declare double @js_http_agent_default_port(i64)

declare void @js_http_agent_set_protocol(i64, i64)

declare i64 @js_http_agent_destroy(i64)

declare double @js_http_agent_destroyed(i64)

declare double @js_http_agent_sockets(i64)

declare double @js_http_agent_free_sockets(i64)

declare double @js_http_agent_requests(i64)

declare void @js_http_agent_set_max_sockets(i64, double)

declare void @js_http_agent_set_max_free_sockets(i64, double)

declare void @js_http_agent_set_max_total_sockets(i64, double)

declare void @js_http_agent_set_keep_alive(i64, double)

declare void @js_http_agent_set_keep_alive_msecs(i64, double)

declare void @js_http_agent_set_create_connection(i64, i64)

declare void @js_http_agent_set_create_socket(i64, i64)

declare i64 @js_http_agent_create_connection(i64)

declare i64 @js_http_agent_create_socket(i64)

declare i64 @js_https_get(double, i64)

declare i64 @js_https_request(double, i64)

declare i64 @js_node_http_create_server(i64)

declare i64 @js_node_http_server_listen(i64, i64)

declare void @js_node_http_server_close(i64, i64)

declare void @js_node_http_server_close_all_connections(i64)

declare void @js_node_http_server_close_idle_connections(i64)

declare i64 @js_node_http_server_address_json(i64)

declare i32 @js_node_http_server_listening(i64)

declare double @js_node_http_server_listening_value(i64)

declare double @js_node_http_server_on(i64, i64, i64)

declare i64 @js_node_http_im_method(i64)

declare i64 @js_node_http_im_url(i64)

declare i64 @js_node_http_im_http_version(i64)

declare i64 @js_node_http_im_headers_json(i64)

declare i64 @js_node_http_im_raw_headers_json(i64)

declare i64 @js_node_http_im_headers_distinct_json(i64)

declare i64 @js_node_http_im_trailers_json(i64)

declare i64 @js_node_http_im_raw_trailers_json(i64)

declare i64 @js_node_http_im_trailers_distinct_json(i64)

declare i32 @js_node_http_im_complete(i64)

declare i32 @js_node_http_im_aborted(i64)

declare i32 @js_node_http_im_destroyed(i64)

declare i64 @js_node_http_im_remote_address(i64)

declare double @js_node_http_im_remote_port(i64)

declare void @js_node_http_im_pause(i64)

declare void @js_node_http_im_resume(i64)

declare void @js_node_http_im_destroy(i64)

declare double @js_node_http_im_on(i64, i64, i64)

declare double @js_node_http_im_once(i64, i64, i64)

declare double @js_node_http_im_read(i64)

declare i64 @js_node_http_im_set_timeout(i64, double, i64)

declare void @js_node_http_res_set_status(i64, double)

declare double @js_node_http_res_get_status(i64)

declare void @js_node_http_res_set_status_message(i64, i64)

declare void @js_node_http_res_set_header(i64, i64, double)

declare i64 @js_node_http_res_set_header_self(i64, i64, double)

declare double @js_node_http_res_get_header(i64, i64)

declare void @js_node_http_res_remove_header(i64, i64)

declare i32 @js_node_http_res_has_header(i64, i64)

declare double @js_node_http_res_has_header_value(i64, i64)

declare i64 @js_node_http_res_get_headers_json(i64)

declare i64 @js_node_http_res_get_header_names_json(i64)

declare i64 @js_node_http_res_append_header(i64, i64, i64)

declare i64 @js_node_http_res_set_headers(i64, double)

declare double @js_node_http_res_get_status_message(i64)

declare i32 @js_node_http_res_headers_sent(i64)

declare i32 @js_node_http_res_writable_ended(i64)

declare i32 @js_node_http_res_writable_finished(i64)

declare i32 @js_node_http_res_finished(i64)

declare i32 @js_node_http_res_send_date(i64)

declare void @js_node_http_res_set_send_date(i64, double)

declare i32 @js_node_http_res_strict_content_length(i64)

declare void @js_node_http_res_set_strict_content_length(i64, double)

declare i64 @js_node_http_res_req_handle(i64)

declare void @js_node_http_res_write_head(i64, double, i64, i64)

declare i32 @js_node_http_res_write(i64, double)

declare double @js_node_http_res_write_full(i64, double, i64, i64)

declare void @js_node_http_res_add_trailers(i64, double)

declare void @js_node_http_res_end(i64, double)

declare void @js_node_http_res_end_full(i64, double, i64, i64)

declare void @js_node_http_res_flush_headers(i64)

declare void @js_node_http_res_cork(i64)

declare void @js_node_http_res_uncork(i64)

declare i64 @js_node_http_res_set_timeout(i64, double, i64)

declare void @js_node_http_res_write_early_hints(i64, double, i64)

declare void @js_node_http_res_write_continue(i64)

declare void @js_node_http_res_write_processing(i64)

declare double @js_node_http_res_on(i64, i64, i64)

declare i64 @js_node_https_create_server(double, i64)

declare i64 @js_node_https_server_listen(i64, i64)

declare void @js_node_https_server_close(i64, i64)

declare void @js_node_https_server_close_all_connections(i64)

declare void @js_node_https_server_close_idle_connections(i64)

declare i64 @js_node_https_server_address_json(i64)

declare double @js_node_https_server_on(i64, i64, i64)

declare double @js_node_https_server_listening_value(i64)

declare double @js_node_https_server_headers_timeout(i64)

declare double @js_node_https_server_set_headers_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout(i64)

declare double @js_node_https_server_set_keep_alive_timeout(i64, double)

declare double @js_node_https_server_keep_alive_timeout_buffer(i64)

declare double @js_node_https_server_set_keep_alive_timeout_buffer(i64, double)

declare double @js_node_https_server_request_timeout(i64)

declare double @js_node_https_server_set_request_timeout(i64, double)

declare double @js_node_https_server_idle_timeout(i64)

declare double @js_node_https_server_set_idle_timeout(i64, double)

declare double @js_node_https_server_max_headers_count(i64)

declare double @js_node_https_server_set_max_headers_count(i64, double)

declare double @js_node_https_server_max_requests_per_socket(i64)

declare double @js_node_https_server_set_max_requests_per_socket(i64, double)

declare i64 @js_node_https_server_set_timeout_method(i64, double, i64)

declare i64 @js_node_http2_create_server(double, double)

declare i64 @js_node_http2_create_secure_server(double, i64)

declare i64 @js_node_http2_connect(double, double, i64)

declare i64 @js_node_http2_server_listen(i64, i64)

declare void @js_node_http2_server_close(i64, i64)

declare i64 @js_node_http2_server_address_json(i64)

declare double @js_node_http2_server_on(i64, i64, i64)

declare i64 @js_node_http2_get_default_settings()

declare i64 @js_node_http2_get_packed_settings(i64)

declare i64 @js_node_http2_get_unpacked_settings(i64)

declare i64 @js_pg_client_connect(i64)

declare i64 @js_pg_client_end(i64)

declare i64 @js_pg_client_new(i64)

declare i64 @js_pg_client_query(i64, i64)

declare i64 @js_pg_client_query_params(i64, i64, i64)

declare i64 @js_pg_connect(i64)

declare i64 @js_pg_create_pool(i64)

declare i64 @js_pg_pool_end(i64)

declare i64 @js_pg_pool_new(i64)

declare i64 @js_pg_pool_query(i64, i64)

declare i64 @js_ioredis_connect(i64)

declare i64 @js_ioredis_decr(i64, i64)

declare i64 @js_ioredis_del(i64, i64)

declare void @js_ioredis_disconnect(i64)

declare i64 @js_ioredis_exists(i64, i64)

declare i64 @js_ioredis_expire(i64, i64, double)

declare i64 @js_ioredis_get(i64, i64)

declare i64 @js_ioredis_hdel(i64, i64, i64)

declare i64 @js_ioredis_hget(i64, i64, i64)

declare i64 @js_ioredis_hgetall(i64, i64)

declare i64 @js_ioredis_hlen(i64, i64)

declare i64 @js_ioredis_hset(i64, i64, i64, i64)

declare i64 @js_ioredis_incr(i64, i64)

declare i64 @js_ioredis_new(i64)

declare i64 @js_ioredis_ping(i64)

declare i64 @js_ioredis_quit(i64)

declare i64 @js_ioredis_set(i64, i64, i64)

declare i64 @js_ioredis_setex(i64, i64, double, i64)

declare i64 @js_mongodb_client_close(i64)

declare i64 @js_mongodb_client_connect(i64)

declare i64 @js_mongodb_client_db(i64, i64)

declare i64 @js_mongodb_client_list_databases(i64)

declare i64 @js_mongodb_client_new(i64)

declare i64 @js_mongodb_collection_count_value(i64, double)

declare i64 @js_mongodb_collection_delete_many_value(i64, double)

declare i64 @js_mongodb_collection_delete_one_value(i64, double)

declare i64 @js_mongodb_collection_find_one_value(i64, double)

declare i64 @js_mongodb_collection_find_value(i64, double)

declare i64 @js_mongodb_collection_insert_many_value(i64, double)

declare i64 @js_mongodb_collection_insert_one_value(i64, double)

declare i64 @js_mongodb_collection_update_many_value(i64, double, double)

declare i64 @js_mongodb_collection_update_one_value(i64, double, double)

declare i64 @js_mongodb_collection_count(i64, i64)

declare i64 @js_mongodb_collection_delete_many(i64, i64)

declare i64 @js_mongodb_collection_delete_one(i64, i64)

declare i64 @js_mongodb_collection_find(i64, i64)

declare i64 @js_mongodb_collection_find_one(i64, i64)

declare i64 @js_mongodb_collection_insert_many(i64, i64)

declare i64 @js_mongodb_collection_insert_one(i64, i64)

declare i64 @js_mongodb_collection_update_many(i64, i64, i64)

declare i64 @js_mongodb_collection_update_one(i64, i64, i64)

declare i64 @js_mongodb_connect(i64)

declare i64 @js_mongodb_db_collection(i64, i64)

declare i64 @js_mongodb_db_list_collections(i64)

declare void @js_sqlite_close(i64)

declare void @js_sqlite_exec(i64, i64)

declare i64 @js_sqlite_open(i64)

declare i64 @js_sqlite_pragma(i64, i64, i64)

declare i64 @js_sqlite_prepare(i64, i64)

declare i64 @js_sqlite_stmt_all(i64, i64)

declare i64 @js_sqlite_stmt_columns(i64)

declare i64 @js_sqlite_stmt_get(i64, i64)

declare i64 @js_sqlite_stmt_run(i64, i64)

declare i64 @js_sqlite_transaction(i64, i64)

declare void @js_sqlite_transaction_commit(i64)

declare void @js_sqlite_transaction_rollback(i64)

declare i64 @js_bun_sqlite_database_call(double, double)

declare i64 @js_bun_sqlite_database_new(double, double)

declare i64 @js_bun_sqlite_database_query(i64, double)

declare i64 @js_bun_sqlite_database_run(i64, double, i64)

declare i64 @js_bun_sqlite_database_filename(i64)

declare i64 @js_bun_sqlite_database_transaction(i64, double)

declare i64 @js_bun_sqlite_statement_values(i64, i64)

declare double @js_bun_sqlite_statement_safe_integers(i64, double)

declare void @js_bun_sqlite_statement_finalize(i64)

declare i64 @js_node_sqlite_backup(double, double, double)

declare i64 @js_node_sqlite_database_sync_call(double, double)

declare i64 @js_node_sqlite_database_sync_new(double, double)

declare i32 @js_node_sqlite_database_sync_open(i64)

declare i32 @js_node_sqlite_database_sync_close(i64)

declare i32 @js_node_sqlite_database_sync_dispose(i64)

declare i32 @js_node_sqlite_database_sync_exec(i64, double)

declare i64 @js_node_sqlite_database_sync_prepare(i64, double, double)

declare i32 @js_node_sqlite_database_sync_function(i64, double, double, double)

declare i32 @js_node_sqlite_database_sync_aggregate(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_defensive(i64, double)

declare i32 @js_node_sqlite_database_sync_set_authorizer(i64, double)

declare i64 @js_node_sqlite_database_sync_create_tag_store(i64, double)

declare i64 @js_node_sqlite_database_sync_create_session(i64, double)

declare double @js_node_sqlite_database_sync_apply_changeset(i64, double, double)

declare i32 @js_node_sqlite_database_sync_enable_load_extension(i64, double)

declare i32 @js_node_sqlite_database_sync_load_extension(i64, double)

declare double @js_node_sqlite_database_sync_location(i64, double)

declare double @js_node_sqlite_database_sync_is_open(i64)

declare double @js_node_sqlite_database_sync_is_transaction(i64)

declare i64 @js_node_sqlite_database_sync_limits(i64)

declare i64 @js_node_sqlite_statement_sync_call(double, double)

declare i64 @js_node_sqlite_statement_sync_new(double, double)

declare i64 @js_node_sqlite_statement_sync_run(i64, i64)

declare double @js_node_sqlite_statement_sync_get(i64, i64)

declare i64 @js_node_sqlite_statement_sync_all(i64, i64)

declare double @js_node_sqlite_statement_sync_iterate(i64, i64)

declare i64 @js_node_sqlite_statement_sync_columns(i64)

declare i32 @js_node_sqlite_statement_sync_set_read_bigints(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_return_arrays(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_bare_named_parameters(i64, double)

declare i32 @js_node_sqlite_statement_sync_set_allow_unknown_named_parameters(i64, double)

declare i64 @js_node_sqlite_statement_sync_source_sql(i64)

declare i64 @js_node_sqlite_statement_sync_expanded_sql(i64)

declare i64 @js_node_sqlite_sql_tag_store_run(i64, i64)

declare double @js_node_sqlite_sql_tag_store_get(i64, i64)

declare i64 @js_node_sqlite_sql_tag_store_all(i64, i64)

declare double @js_node_sqlite_sql_tag_store_iterate(i64, i64)

declare i32 @js_node_sqlite_sql_tag_store_clear(i64)

declare double @js_node_sqlite_sql_tag_store_size(i64)

declare double @js_node_sqlite_sql_tag_store_capacity(i64)

declare i64 @js_node_sqlite_sql_tag_store_db(i64)

declare i64 @js_node_sqlite_session_call(double, double)

declare i64 @js_node_sqlite_session_new(double, double)

declare i64 @js_node_sqlite_session_changeset(i64)

declare i64 @js_node_sqlite_session_patchset(i64)

declare i32 @js_node_sqlite_session_close(i64)

declare i32 @js_node_sqlite_session_dispose(i64)

declare i64 @js_os_cpus()

declare double @js_os_freemem()

declare i64 @js_os_homedir()

declare i64 @js_os_network_interfaces()

declare i64 @js_os_tmpdir()

declare double @js_os_totalmem()

declare double @js_os_uptime()

declare i64 @js_os_user_info()

declare i64 @js_os_user_info_buffer()

declare i64 @js_os_user_info_options(i64)

declare i64 @js_crypto_aes256_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_encrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_decrypt(i64, i64, i64)

declare i64 @js_crypto_aes256_gcm_encrypt(i64, i64, i64)

declare double @js_crypto_create_cipheriv(i64, i64, i64, double)

declare double @js_crypto_create_decipheriv(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sha256(i64, i64, i64, double)

declare i64 @js_crypto_hkdf_sync(i64, i64, i64, i64, double)

declare i64 @js_crypto_pbkdf2(i64, i64, double, double)

declare i64 @js_crypto_random_bytes_hex(double)

declare i64 @js_crypto_random_nonce()

declare i64 @js_crypto_scrypt(i64, i64, double)

declare double @js_crypto_generate_key_pair_sync(i64, i64)

declare i64 @js_crypto_scrypt_custom(i64, i64, double, double, double, double)

declare i64 @js_crypto_x25519_keypair()

declare i64 @js_crypto_x25519_shared_secret(i64, i64)

declare i64 @js_keccak256_native(i64)

declare i64 @js_keccak256_native_bytes(i64)

declare i64 @js_nanoid(double)

declare i64 @js_nanoid_custom(i64, double)

declare i64 @js_argon2_hash(i64)

declare i64 @js_argon2_hash_options(i64, i64)

declare i64 @js_argon2_verify(i64, i64)

declare i64 @js_bcrypt_compare(i64, i64)

declare double @js_bcrypt_compare_sync(i64, i64)

declare i64 @js_bcrypt_gen_salt(double)

declare i64 @js_bcrypt_hash(i64, double)

declare i64 @js_bcrypt_hash_sync(i64, double)

declare i64 @js_ads_interstitial_load(i64)

declare i64 @js_ads_interstitial_show()

declare i64 @js_ads_rewarded_load(i64)

declare i64 @js_ads_rewarded_show()

declare double @js_ads_banner_create(i64, i64)

declare void @js_ads_banner_destroy(double)

declare i64 @js_ads_request_consent()

declare i64 @js_perry_read_embedded(double)

declare i64 @js_perry_embedded_files()

declare double @js_thread_parallel_map(double, double)

declare double @js_thread_parallel_filter(double, double)

declare double @js_thread_spawn(double)

declare double @js_perry_native_i8(double)

declare double @js_perry_native_i16(double)

declare double @js_perry_native_u8(double)

declare double @js_perry_native_u16(double)

declare double @js_perry_native_i32(double)

declare double @js_perry_native_i64(double)

declare double @js_perry_native_u32(double)

declare double @js_perry_native_u64(double)

declare double @js_perry_native_usize(double)

declare double @js_perry_native_isize(double)

declare double @js_perry_native_f32(double)

declare double @js_perry_native_f64(double)

declare i64 @js_jwt_decode(i64)

declare i64 @js_jwt_sign(i64, i64, double, i64)

declare i64 @js_jwt_sign_es256(i64, i64, double, i64)

declare i64 @js_jwt_sign_rs256(i64, i64, double, i64)

declare i64 @js_jwt_verify(i64, i64)

declare i64 @js_jwt_verify_es256(i64, i64)

declare i64 @js_jwt_verify_rs256(i64, i64)

declare i64 @js_jwt_sign_dyn(i64, i64, i64, double, i64)

declare i64 @js_jwt_verify_dyn(i64, i64, i64)

declare i64 @js_jwt_sign_dyn_opts(i64, i64, double)

declare i64 @js_jwt_verify_dyn_opts(i64, i64, double)

declare double @js_axios_create(i64)

declare i64 @js_axios_delete(i64)

declare i64 @js_axios_get(i64)

declare i64 @js_axios_head(i64)

declare i64 @js_axios_options(i64)

declare i64 @js_axios_post(i64, double)

declare i64 @js_axios_put(i64, double)

declare i64 @js_axios_patch(i64, double)

declare i64 @js_axios_request(i64)

declare double @js_axios_response_status(i64)

declare i64 @js_axios_response_status_text(i64)

declare i64 @js_axios_response_data(i64)

declare double @js_axios_response_data_parsed(i64)

declare i64 @js_sharp_auto_orient(i64)

declare i64 @js_sharp_avif(i64, double)

declare i64 @js_sharp_blur(i64, double)

declare i64 @js_sharp_composite(i64, double)

declare i64 @js_sharp_extend(i64, double)

declare i64 @js_sharp_extract(i64, double)

declare i64 @js_sharp_flip(i64)

declare i64 @js_sharp_flop(i64)

declare i64 @js_sharp_from_buffer(i64, double)

declare i64 @js_sharp_from_file(i64)

declare i64 @js_sharp_from_input(i64)

declare i64 @js_sharp_grayscale(i64)

declare i64 @js_sharp_metadata(i64)

declare i64 @js_sharp_sharpen(i64)

declare i64 @js_sharp_trim(i64)

declare i64 @js_sharp_negate(i64)

declare i64 @js_sharp_quality(i64, double)

declare i64 @js_sharp_resize(i64, double, double)

declare i64 @js_sharp_rotate(i64, double)

declare i64 @js_sharp_to_buffer(i64)

declare i64 @js_sharp_to_file(i64, i64)

declare i64 @js_sharp_to_format(i64, i64)

declare void @js_cron_clear_interval(i64)

declare void @js_cron_clear_timeout(i64)

declare i64 @js_cron_describe(i64)

declare double @js_cron_job_is_running(i64)

declare i64 @js_cron_job_new(i64, i64, double)

declare void @js_cron_job_start(i64)

declare void @js_cron_job_stop(i64)

declare i64 @js_cron_next_date(i64)

declare i64 @js_cron_next_dates(i64, double)

declare i64 @js_cron_schedule(i64, i64)

declare i64 @js_cron_set_interval(double, double)

declare i64 @js_cron_set_timeout(double, double)

declare i32 @js_cron_timer_has_pending()

declare i32 @js_cron_timer_tick()

declare double @js_cron_validate(i64)

declare i64 @js_async_hooks_create_hook(double)

declare double @js_async_hooks_execution_async_id()

declare double @js_async_hooks_trigger_async_id()

declare double @js_async_hooks_execution_async_resource()

declare i64 @js_async_hook_enable(i64)

declare i64 @js_async_hook_disable(i64)

declare i64 @js_async_resource_new(double, double)

declare double @js_async_resource_subclass_init(double, double, double)

declare double @js_async_resource_async_id(i64)

declare double @js_async_resource_trigger_async_id(i64)

declare i64 @js_async_resource_emit_destroy(i64)

declare double @js_async_resource_run_in_async_scope(i64, double, double, i64)

declare i64 @js_async_resource_bind(i64, double, double)

declare i64 @js_async_resource_static_bind(i64, double)

declare void @js_async_local_storage_disable(i64)

declare void @js_async_local_storage_enter_with(i64, double)

declare double @js_async_local_storage_exit(i64, double, i64)

declare double @js_async_local_storage_get_store(i64)

declare i64 @js_async_local_storage_new()

declare double @js_async_local_storage_subclass_init(double)

declare double @js_async_local_storage_run(i64, double, double, i64)

declare i64 @js_disposable_stack_new()

declare i64 @js_async_disposable_stack_new()

declare double @js_suppressed_error_new(double, double, double)

declare i64 @js_zlib_deflate_sync(i64, double)

declare void @js_zlib_deflate(double, double)

declare i64 @js_zlib_gunzip_sync(i64)

declare void @js_zlib_gunzip(double, double)

declare i64 @js_zlib_gzip_sync(i64, double)

declare void @js_zlib_gzip(double, double)

declare i64 @js_zlib_inflate_sync(i64)

declare void @js_zlib_inflate(double, double)

declare i64 @js_zlib_deflate_raw_sync(double, double)

declare void @js_zlib_deflate_raw(double, double)

declare i64 @js_zlib_inflate_raw_sync(double)

declare void @js_zlib_inflate_raw(double, double)

declare i64 @js_zlib_unzip_sync(double)

declare void @js_zlib_unzip(double, double)

declare double @js_zlib_crc32(double, double)

declare i64 @js_zlib_brotli_compress_sync(i64)

declare i64 @js_zlib_brotli_decompress_sync(i64)

declare void @js_zlib_brotli_compress(double, double)

declare void @js_zlib_brotli_decompress(double, double)

declare i64 @js_zlib_zstd_compress_sync(double, double)

declare i64 @js_zlib_zstd_decompress_sync(double, double)

declare void @js_zlib_zstd_compress(double, double)

declare void @js_zlib_zstd_decompress(double, double)

declare i64 @js_zlib_create_gzip(double)

declare i64 @js_zlib_create_gunzip(double)

declare i64 @js_zlib_create_deflate(double)

declare i64 @js_zlib_create_inflate(double)

declare i64 @js_zlib_create_deflate_raw(double)

declare i64 @js_zlib_create_inflate_raw(double)

declare i64 @js_zlib_create_unzip(double)

declare i64 @js_zlib_create_brotli_compress(double)

declare i64 @js_zlib_create_zstd_compress(double)

declare i64 @js_zlib_create_zstd_decompress(double)

declare i64 @js_buffer_alloc_unsafe(i32)

declare i32 @js_buffer_byte_length(i64)

declare i32 @js_buffer_byte_length_value(double, double)

declare i64 @js_buffer_concat(i64)

declare i64 @js_buffer_concat_with_length(i64, double)

declare i32 @js_buffer_validate_size(double)

declare i64 @js_buffer_validate_concat_list(double)

declare i32 @js_buffer_copy(i64, i64, i32, i32, i32)

declare i32 @js_buffer_equals(i64, i64)

declare i64 @js_buffer_fill(i64, i32)

declare i64 @js_buffer_from_value(i64, i32)

declare double @js_buffer_is_ascii(double)

declare i32 @js_buffer_is_buffer(i64)

declare i32 @js_buffer_is_node_buffer(i64)

declare i32 @js_buffer_is_encoding(double)

declare double @js_buffer_is_utf8(double)

declare void @js_buffer_print(i64)

declare void @js_buffer_set(i64, i32, i32)

declare void @js_buffer_set_from(i64, i64, i32)

declare i64 @js_buffer_slice(i64, i32, i32)

declare i64 @js_buffer_to_string(i64, i32)

declare i64 @js_buffer_transcode(double, double, double)

declare i32 @js_buffer_write(i64, i64, i32, i32)

declare double @js_child_process_exec_sync(i64, i64)

declare double @js_child_process_exec(i64, double, double)

declare i64 @js_child_process_get_process_status(double)

declare i32 @js_child_process_kill_process(double)

declare i64 @js_child_process_spawn_background(double, i64, double, double)

declare i64 @js_child_process_spawn_sync(i64, i64, i64)

declare double @js_child_process_spawn_streams(i64, i64, i64)

declare double @js_pty_spawn(i64, i64, i64)

declare double @js_child_process_fork(i64, i64, i64)

declare double @js_child_process_exec_file(i64, double, double, double)

declare double @js_child_process_exec_file_sync(i64, double, double)

declare double @js_child_process_validate_command(double, ptr, i32)

declare double @js_child_process_validate_args(double)

declare double @js_child_process_validate_options(double, i32, i32)

declare double @js_child_process_validate_fork_module(double)

declare double @js_child_process_validate_spawn_args(double, i32, i32)

declare double @js_child_process_new()

declare i64 @js_cheerio_load(i64)

declare i64 @js_cheerio_load_fragment(i64)

declare i64 @js_cheerio_select(i64, i64)

declare i64 @js_cheerio_selection_attr(i64, i64)

declare i64 @js_cheerio_selection_attrs(i64, i64)

declare i64 @js_cheerio_selection_children(i64, i64)

declare i64 @js_cheerio_selection_eq(i64, double)

declare i64 @js_cheerio_selection_find(i64, i64)

declare i64 @js_cheerio_selection_first(i64)

declare double @js_cheerio_selection_has_class(i64, i64)

declare i64 @js_cheerio_selection_html(i64)

declare double @js_cheerio_selection_is(i64, i64)

declare i64 @js_cheerio_selection_last(i64)

declare double @js_cheerio_selection_length(i64)

declare i64 @js_cheerio_selection_parent(i64)

declare i64 @js_cheerio_selection_text(i64)

declare i64 @js_cheerio_selection_texts(i64)

declare i64 @js_cheerio_selection_to_array(i64)

declare double @js_url_file_url_to_path(double, double)

declare double @js_url_file_url_to_path_buffer(double, double)

declare double @js_url_get_hash(i64)

declare double @js_url_get_host(i64)

declare double @js_url_get_hostname(i64)

declare double @js_url_get_href(i64)

declare double @js_url_get_origin(i64)

declare double @js_url_get_pathname(i64)

declare double @js_url_get_port(i64)

declare double @js_url_get_protocol(i64)

declare double @js_url_get_search(i64)

declare double @js_url_get_search_params(i64)

declare i64 @js_url_new(i64)

declare i64 @js_url_new_with_base(i64, i64)

declare i64 @js_url_pattern_new(double, double)

declare double @js_url_pattern_constructor_call(double, double)

declare i32 @js_url_can_parse(i64)

declare i32 @js_url_can_parse_with_base(i64, i64)

declare i64 @js_url_parse(i64)

declare i64 @js_url_parse_with_base(i64, i64)

declare void @js_url_set_pathname(i64, double)

declare void @js_url_set_search(i64, double)

declare void @js_url_set_hash(i64, double)

declare void @js_url_set_protocol(i64, double)

declare void @js_url_set_hostname(i64, double)

declare void @js_url_set_port(i64, double)

declare void @js_url_set_username(i64, double)

declare void @js_url_set_password(i64, double)

declare void @js_url_set_href(i64, double)

declare double @js_url_search_params_has2(i64, double, double)

declare void @js_url_search_params_delete2(i64, double, double)

declare double @js_url_search_params_throw_missing_args(i32)

declare void @js_url_search_params_append(i64, double, double)

declare void @js_url_search_params_delete(i64, double)

declare i64 @js_url_search_params_get(i64, double)

declare double @js_url_search_params_get_all(i64, double)

declare double @js_url_search_params_has(i64, double)

declare i64 @js_url_search_params_new(i64)

declare i64 @js_url_search_params_new_any(double)

declare i64 @js_url_search_params_new_empty()

declare double @js_url_search_params_subclass_init(double, double)

declare void @js_url_search_params_set(i64, double, double)

declare i64 @js_url_search_params_to_string(i64)

declare i32 @js_url_search_params_size(i64)

declare double @js_url_search_params_entries_arr(i64)

declare double @js_url_search_params_keys_arr(i64)

declare double @js_url_search_params_values_arr(i64)

declare void @js_url_search_params_sort(i64)

declare void @js_url_search_params_for_each(i64, double, double)

declare i64 @js_url_coerce_string(double)

declare double @js_url_path_to_file_url(double, double)

declare double @js_url_domain_to_ascii(double)

declare double @js_url_domain_to_unicode(double)

declare double @js_url_to_http_options(double)

declare double @js_url_legacy_url_new()

declare double @js_url_format(double, double)

declare double @js_url_legacy_parse(double, double, double)

declare double @js_url_legacy_resolve(double, double)

declare double @js_url_legacy_resolve_object(double, double)

declare void @js_ws_close(i64)

declare i64 @js_ws_connect(i64)

declare double @js_ws_connect_start(double)

declare i64 @js_ws_handle_to_i64(double)

declare double @js_ws_is_open(i64)

declare double @js_ws_message_count(i64)

declare double @js_ws_ready_state(i64)

declare i64 @js_ws_on(i64, i64, i64)

declare i64 @js_ws_receive(i64)

declare void @js_ws_send(i64, i64)

declare void @js_ws_send_to_client(double, i64)

declare void @js_ws_close_client(double)

declare void @js_ws_send_client_i64(i64, i64)

declare void @js_ws_close_client_i64(i64)

declare i64 @js_ws_on_client_i64(i64, i64, i64)

declare void @js_ws_server_close(i64)

declare double @js_ws_server_clients(i64)

declare double @js_ws_server_address(i64)

declare i32 @js_ws_server_emit(i64, i64, double, double)

declare i64 @js_ws_server_new(double)

declare void @js_ws_handle_upgrade(i64, double, double, double, i64)

declare i64 @js_ws_wait_for_message(i64, double)

declare i64 @js_pdf_create_pdf(double)

declare void @js_pdf_add_text(i64, i64, double, double, double)

declare void @js_pdf_add_line(i64, double, double, double, double)

declare void @js_pdf_new_page(i64)

declare void @js_pdf_save(i64)

declare i64 @js_commander_action(i64, i64)

declare i64 @js_commander_command(i64, i64)

declare i64 @js_commander_description(i64, i64)

declare i64 @js_commander_get_option(i64, i64)

declare double @js_commander_get_option_bool(i64, i64)

declare double @js_commander_get_option_number(i64, i64)

declare i64 @js_commander_name(i64, i64)

declare i64 @js_commander_new()

declare i64 @js_commander_option(i64, i64, i64, i64)

declare i64 @js_commander_opts(i64)

declare i64 @js_commander_parse(i64, double)

declare i64 @js_commander_required_option(i64, i64, i64, i64)

declare i64 @js_commander_version(i64, i64)

declare double @js_dotenv_config()

declare double @js_dotenv_config_path(i64)

declare i64 @js_dotenv_parse(i64)

declare double @js_datefns_add_days(double, double)

declare double @js_datefns_add_months(double, double)

declare double @js_datefns_add_years(double, double)

declare double @js_datefns_difference_in_days(double, double)

declare double @js_datefns_difference_in_hours(double, double)

declare double @js_datefns_difference_in_minutes(double, double)

declare double @js_datefns_end_of_day(double)

declare i64 @js_datefns_format(double, i64)

declare double @js_datefns_is_after(double, double)

declare double @js_datefns_is_before(double, double)

declare double @js_datefns_parse_iso(i64)

declare double @js_datefns_start_of_day(double)

declare double @js_dayjs_add(i64, double, i64)

declare double @js_dayjs_date(i64)

declare double @js_dayjs_day(i64)

declare double @js_dayjs_diff(i64, i64, i64)

declare double @js_dayjs_end_of(i64, i64)

declare double @js_dayjs_factory(i64)

declare i64 @js_dayjs_format(i64, i64)

declare double @js_dayjs_from_timestamp(double)

declare double @js_dayjs_hour(i64)

declare double @js_dayjs_is_after(i64, i64)

declare double @js_dayjs_is_before(i64, i64)

declare double @js_dayjs_is_same(i64, i64)

declare double @js_dayjs_is_valid(i64)

declare double @js_dayjs_millisecond(i64)

declare double @js_dayjs_minute(i64)

declare double @js_dayjs_month(i64)

declare double @js_dayjs_now()

declare double @js_dayjs_parse(i64)

declare double @js_dayjs_second(i64)

declare double @js_dayjs_start_of(i64, i64)

declare double @js_dayjs_subtract(i64, double, i64)

declare i64 @js_dayjs_to_iso_string(i64)

declare double @js_dayjs_unix(i64)

declare double @js_dayjs_value_of(i64)

declare double @js_dayjs_year(i64)

declare double @js_moment_add(i64, double, i64)

declare double @js_moment_clone(i64)

declare double @js_moment_date(i64)

declare double @js_moment_day(i64)

declare double @js_moment_diff(i64, i64, i64)

declare double @js_moment_end_of(i64, i64)

declare double @js_moment_factory(i64)

declare i64 @js_moment_format(i64, i64)

declare i64 @js_moment_from_now(i64)

declare double @js_moment_from_timestamp(double)

declare double @js_moment_hour(i64)

declare double @js_moment_is_after(i64, i64)

declare double @js_moment_is_before(i64, i64)

declare double @js_moment_is_between(i64, i64, i64)

declare double @js_moment_is_same(i64, i64, i64)

declare double @js_moment_is_valid(i64)

declare double @js_moment_millisecond(i64)

declare double @js_moment_minute(i64)

declare double @js_moment_month(i64)

declare double @js_moment_now()

declare double @js_moment_parse(i64)

declare double @js_moment_second(i64)

declare double @js_moment_start_of(i64, i64)

declare double @js_moment_subtract(i64, double, i64)

declare double @js_moment_to_date(i64)

declare i64 @js_moment_to_iso_string(i64)

declare double @js_moment_unix(i64)

declare double @js_moment_value_of(i64)

declare double @js_moment_year(i64)

declare i64 @js_decimal_abs(i64)

declare i64 @js_decimal_ceil(i64)

declare double @js_decimal_cmp(i64, i64)

declare double @js_decimal_cmp_value(i64, double)

declare i64 @js_decimal_coerce_to_handle(double)

declare i64 @js_decimal_div(i64, i64)

declare i64 @js_decimal_div_number(i64, double)

declare i64 @js_decimal_div_value(i64, double)

declare double @js_decimal_eq(i64, i64)

declare double @js_decimal_eq_value(i64, double)

declare i64 @js_decimal_floor(i64)

declare i64 @js_decimal_from_number(double)

declare i64 @js_decimal_from_string(i64)

declare double @js_decimal_gt(i64, i64)

declare double @js_decimal_gt_value(i64, double)

declare double @js_decimal_gte(i64, i64)

declare double @js_decimal_gte_value(i64, double)

declare double @js_decimal_is_negative(i64)

declare double @js_decimal_is_positive(i64)

declare double @js_decimal_is_zero(i64)

declare double @js_decimal_lt(i64, i64)

declare double @js_decimal_lt_value(i64, double)

declare double @js_decimal_lte(i64, i64)

declare double @js_decimal_lte_value(i64, double)

declare i64 @js_decimal_minus(i64, i64)

declare i64 @js_decimal_minus_number(i64, double)

declare i64 @js_decimal_minus_value(i64, double)

declare i64 @js_decimal_mod(i64, i64)

declare i64 @js_decimal_mod_value(i64, double)

declare i64 @js_decimal_neg(i64)

declare i64 @js_decimal_plus(i64, i64)

declare i64 @js_decimal_plus_number(i64, double)

declare i64 @js_decimal_plus_value(i64, double)

declare i64 @js_decimal_pow(i64, double)

declare i64 @js_decimal_round(i64)

declare i64 @js_decimal_sqrt(i64)

declare i64 @js_decimal_times(i64, i64)

declare i64 @js_decimal_times_number(i64, double)

declare i64 @js_decimal_times_value(i64, double)

declare i64 @js_decimal_to_fixed(i64, double)

declare double @js_decimal_to_number(i64)

declare i64 @js_decimal_to_string(i64)

declare i64 @js_ethers_format_ether(i64)

declare i64 @js_ethers_format_units(i64, double)

declare i64 @js_ethers_get_address(i64)

declare i64 @js_ethers_parse_ether(i64)

declare i64 @js_ethers_parse_units(i64, double)

declare i64 @js_lodash_camel_case(i64)

declare i64 @js_lodash_capitalize(i64)

declare i64 @js_lodash_chunk(i64, double)

declare double @js_lodash_clamp(double, double, double)

declare i64 @js_lodash_compact(i64)

declare i64 @js_lodash_concat(i64, i64)

declare i64 @js_lodash_difference(i64, i64)

declare i64 @js_lodash_drop(i64, double)

declare i64 @js_lodash_drop_right(i64, double)

declare double @js_lodash_ends_with(i64, i64)

declare i64 @js_lodash_escape(i64)

declare double @js_lodash_first(i64)

declare i64 @js_lodash_flatten(i64)

declare double @js_lodash_in_range(double, double, double)

declare double @js_lodash_includes(i64, i64)

declare i64 @js_lodash_initial(i64)

declare i64 @js_lodash_kebab_case(i64)

declare double @js_lodash_last(i64)

declare i64 @js_lodash_lower_case(i64)

declare i64 @js_lodash_lower_first(i64)

declare double @js_lodash_max(i64)

declare double @js_lodash_max_by(i64, double)

declare double @js_lodash_mean(i64)

declare double @js_lodash_mean_by(i64, double)

declare double @js_lodash_min(i64)

declare double @js_lodash_min_by(i64, double)

declare i64 @js_lodash_pad(i64, double)

declare i64 @js_lodash_pad_end(i64, double)

declare i64 @js_lodash_pad_start(i64, double)

declare double @js_lodash_random(double, double)

declare i64 @js_lodash_repeat(i64, double)

declare i64 @js_lodash_replace(i64, i64, i64)

declare i64 @js_lodash_reverse(i64)

declare double @js_lodash_size(i64)

declare i64 @js_lodash_snake_case(i64)

declare i64 @js_lodash_split(i64, i64)

declare i64 @js_lodash_start_case(i64)

declare double @js_lodash_starts_with(i64, i64)

declare double @js_lodash_sum(i64)

declare double @js_lodash_sum_by(i64, double)

declare i64 @js_lodash_tail(i64)

declare i64 @js_lodash_take(i64, double)

declare i64 @js_lodash_take_right(i64, double)

declare i64 @js_lodash_trim(i64)

declare i64 @js_lodash_trim_end(i64)

declare i64 @js_lodash_trim_start(i64)

declare i64 @js_lodash_truncate(i64, double)

declare i64 @js_lodash_unescape(i64)

declare i64 @js_lodash_uniq(i64)

declare i64 @js_lodash_upper_case(i64)

declare i64 @js_lodash_upper_first(i64)

declare void @js_lru_cache_clear(i64)

declare double @js_lru_cache_delete(i64, double)

declare double @js_lru_cache_get(i64, double)

declare double @js_lru_cache_has(i64, double)

declare i64 @js_lru_cache_new(double)

declare double @js_lru_cache_peek(i64, double)

declare i64 @js_lru_cache_set(i64, double, double)

declare double @js_lru_cache_size(i64)

declare double @js_event_emitter_subclass_init(double)

declare double @js_event_emitter_async_resource_subclass_init(double, double)

declare double @js_array_subclass_init(double, double)

declare double @js_array_subclass_init_args(double, ptr, i64)

declare double @js_map_set_subclass_init(double, i32, double)

declare double @js_weak_collection_subclass_init(double, i32, double)

declare double @js_promise_subclass_init(double, double)

declare double @js_node_stream_readable_new(double)

declare double @js_node_stream_readable_subclass_init(double, double)

declare double @js_node_stream_writable_new(double)

declare double @js_node_stream_writable_subclass_init(double, double)

declare double @js_node_stream_duplex_new(double)

declare double @js_node_stream_duplex_subclass_init(double, double)

declare double @js_node_stream_transform_new(double)

declare double @js_node_stream_transform_subclass_init(double, double)

declare double @js_node_stream_passthrough_new(double)

declare double @js_node_stream_readable_from(double)

declare double @js_node_stream_readable_from_options(double, double)

declare double @js_node_stream_duplex_from_options(double, double)

declare double @js_node_stream_is_disturbed(double)

declare double @js_node_stream_is_errored(double)

declare double @js_node_stream_is_readable(double)

declare double @js_node_stream_is_writable(double)

declare double @js_node_stream_is_array_buffer_view(double)

declare double @js_node_stream_is_uint8_array(double)

declare double @js_node_stream_is_destroyed(double)

declare double @js_node_stream_uint8_array_to_buffer(double)

declare double @js_node_stream_get_default_hwm(double)

declare double @js_node_stream_set_default_hwm(double, double)

declare double @js_node_stream_add_abort_signal(double, double)

declare double @js_node_stream_compose(i64)

declare double @js_node_stream_pipeline(i64)

declare double @js_node_stream_finished(i64)

declare double @js_node_stream_duplex_pair(double)

declare double @js_node_stream_readable_to_web(double)

declare double @js_node_stream_writable_to_web(double)

declare double @js_node_stream_duplex_to_web(double)

declare double @js_node_stream_readable_from_web(double, double)

declare double @js_node_stream_writable_from_web(double, double)

declare double @js_node_stream_duplex_from_web(double, double)

declare double @js_node_stream_to_web(double)

declare double @js_node_stream_from_web(double)

declare double @js_node_stream_method_readable_aborted(i64)

declare double @js_node_stream_method_closed(i64)

declare double @js_node_stream_method_errored(i64)

declare double @js_node_stream_method_readable_did_read(i64)

declare double @js_node_stream_method_destroyed(i64)

declare double @js_node_stream_method_destroy(i64, double)

declare double @js_node_stream_method_pause(i64)

declare double @js_node_stream_method_readable(i64)

declare double @js_node_stream_method_readable_length(i64)

declare double @js_node_stream_method_readable_flowing(i64)

declare double @js_node_stream_method_readable_ended(i64)

declare double @js_node_stream_method_readable_object_mode(i64)

declare double @js_node_stream_method_pipe(i64, double, double)

declare double @js_node_stream_method_unpipe(i64, double)

declare double @js_node_stream_method_is_paused(i64)

declare double @js_node_stream_method_resume(i64)

declare double @js_node_stream_method_readable_encoding(i64)

declare double @js_node_stream_method_cork(i64)

declare double @js_node_stream_method_uncork(i64)

declare double @js_node_stream_method_writable_corked(i64)

declare double @js_node_stream_method_writable_length(i64)

declare double @js_node_stream_method_writable_need_drain(i64)

declare double @js_node_stream_method_writable(i64)

declare double @js_node_stream_method_writable_ended(i64)

declare double @js_node_stream_method_writable_finished(i64)

declare double @js_node_stream_method_allow_half_open(i64)

declare double @js_node_stream_method_set_encoding(i64, double)

declare double @js_node_stream_method_writable_object_mode(i64)

declare double @js_event_emitter_emit(i64, i64, i64)

declare double @js_event_emitter_emit0(i64, i64)

declare double @js_event_emitter_listener_count(i64, i64, i64)

declare i64 @js_event_emitter_new()

declare i64 @js_event_emitter_new_with_options(double)

declare i64 @js_event_emitter_on(i64, i64, i64)

declare i64 @js_event_emitter_once(i64, i64, i64)

declare i64 @js_event_emitter_prepend_listener(i64, i64, i64)

declare i64 @js_event_emitter_prepend_once_listener(i64, i64, i64)

declare i64 @js_event_emitter_remove_all_listeners(i64, i64)

declare i64 @js_event_emitter_remove_listener(i64, i64, i64)

declare i64 @js_event_emitter_set_max_listeners(i64, double)

declare double @js_event_emitter_get_max_listeners(i64)

declare i64 @js_event_emitter_event_names(i64)

declare i64 @js_event_emitter_listeners(i64, i64)

declare i64 @js_event_emitter_raw_listeners(i64, i64)

declare double @js_event_emitter_domain_value(i64)

declare i64 @js_event_emitter_async_resource_new(double)

declare double @js_event_emitter_async_resource_call(double)

declare double @js_event_emitter_async_resource_async_id(i64)

declare double @js_event_emitter_async_resource_trigger_async_id(i64)

declare double @js_event_emitter_async_resource_async_resource(i64)

declare double @js_event_emitter_async_resource_emit_destroy(i64)

declare i64 @js_events_once(double, i64, double)

declare i64 @js_events_on(double, i64, double)

declare i64 @js_events_add_abort_listener(double, double)

declare i64 @js_events_get_event_listeners(double, i64)

declare double @js_events_listener_count(double, i64)

declare double @js_events_get_max_listeners(double)

declare double @js_events_set_max_listeners(double, i64)

declare double @js_events_init()

declare i64 @js_domain_create()

declare i64 @js_domain_on(i64, i64, i64)

declare double @js_domain_emit(i64, i64, i64)

declare double @js_domain_run(i64, double, i64)

declare double @js_domain_bind(i64, double)

declare double @js_domain_intercept(i64, double)

declare i64 @js_domain_add(i64, double)

declare i64 @js_domain_remove(i64, double)

declare double @js_domain_enter(i64)

declare double @js_domain_exit(i64)

declare i64 @js_string_decoder_new(i64)

declare double @js_string_decoder_write(i64, double)

declare double @js_string_decoder_end(i64, double)

declare double @js_querystring_escape(double)

declare double @js_querystring_unescape(double)

declare i64 @js_querystring_unescape_buffer(double, double)

declare i64 @js_querystring_parse(double, double, double, double)

declare double @js_querystring_stringify(double, double, double, double)

declare i32 @js_fastify_add_hook(i64, i64, i64)

declare i32 @js_fastify_all(i64, i64, i64)

declare i64 @js_fastify_create()

declare i64 @js_fastify_create_with_opts(double)

declare double @js_fastify_ctx_html(i64, i64, double)

declare double @js_fastify_ctx_json(i64, double, double)

declare double @js_fastify_ctx_redirect(i64, i64, double)

declare double @js_fastify_ctx_text(i64, i64, double)

declare i32 @js_fastify_delete(i64, i64, i64)

declare i32 @js_fastify_get(i64, i64, i64)

declare i32 @js_fastify_head(i64, i64, i64)

declare void @js_fastify_listen(i64, double, i64)

declare void @js_fastify_app_close(i64)

declare i64 @js_fastify_app_server(i64)

declare void @js_fastify_app_on(i64, i64, i64)

declare i32 @js_fastify_options(i64, i64, i64)

declare i32 @js_fastify_patch(i64, i64, i64)

declare i32 @js_fastify_post(i64, i64, i64)

declare i32 @js_fastify_put(i64, i64, i64)

declare i32 @js_fastify_register(i64, i64, double)

declare i64 @js_fastify_reply_header(i64, i64, i64)

declare i32 @js_fastify_reply_send(i64, double)

declare i64 @js_fastify_reply_status(i64, double)

declare i64 @js_fastify_reply_type(i64, i64)

declare i64 @js_fastify_req_body(i64)

declare double @js_fastify_req_get_user_data(i64)

declare i64 @js_fastify_req_header(i64, i64)

declare i64 @js_fastify_req_headers(i64)

declare double @js_fastify_req_json(i64)

declare i64 @js_fastify_req_method(i64)

declare i64 @js_fastify_req_param(i64, i64)

declare i64 @js_fastify_req_params(i64)

declare i64 @js_fastify_req_query(i64)

declare double @js_fastify_req_query_object(i64)

declare void @js_fastify_req_set_user_data(i64, double)

declare i64 @js_fastify_req_url(i64)

declare i32 @js_fastify_route(i64, i64, i64, i64)

declare i32 @js_fastify_set_error_handler(i64, i64)

declare double @js_nodemailer_create_transport(i64)

declare i64 @js_nodemailer_send_mail(i64, i64)

declare i64 @js_nodemailer_verify(i64)

declare i64 @js_ratelimit_block(i64, i64, double)

declare i64 @js_ratelimit_consume(i64, i64, double)

declare i64 @js_ratelimit_create(i64)

declare i64 @js_ratelimit_delete(i64, i64)

declare i64 @js_ratelimit_get(i64, i64)

declare i64 @js_ratelimit_new_from_options(i64)

declare i64 @js_ratelimit_penalty(i64, i64, double)

declare i64 @js_ratelimit_reward(i64, i64, double)

declare double @js_validator_contains(i64, i64)

declare double @js_validator_equals(i64, i64)

declare double @js_validator_is_alpha(i64)

declare double @js_validator_is_alphanumeric(i64)

declare double @js_validator_is_email(i64)

declare double @js_validator_is_empty(i64)

declare double @js_validator_is_float(i64)

declare double @js_validator_is_hexadecimal(i64)

declare double @js_validator_is_int(i64)

declare double @js_validator_is_json(i64)

declare double @js_validator_is_length(i64, double, double)

declare double @js_validator_is_lowercase(i64)

declare double @js_validator_is_numeric(i64)

declare double @js_validator_is_uppercase(i64)

declare double @js_validator_is_url(i64)

declare double @js_validator_is_uuid(i64)

declare i64 @js_date_to_locale_string(double)

declare i64 @js_number_to_locale_string(double)

declare double @js_value_to_locale_string(double)

declare i64 @js_string_split_regex(i64, i64)

declare i32 @js_object_delete_dynamic(i64, double)

declare double @js_object_get_prototype_of(double)

declare double @js_object_set_prototype_of(double, double)

declare double @js_object_define_properties(double, double)

declare double @js_math_acos(double)

declare double @js_math_asin(double)

declare double @js_math_atan(double)

declare double @js_math_atan2(double, double)

declare double @js_math_cos(double)

declare double @js_math_expm1(double)

declare double @js_math_log(double)

declare double @js_math_log10(double)

declare double @js_math_log1p(double)

declare double @js_math_log2(double)

declare double @js_math_sin(double)

declare double @js_math_tan(double)

declare double @js_atomics_load(ptr, double, double)

declare double @js_atomics_is_lock_free(ptr, double)

declare double @js_atomics_store(ptr, double, double, double)

declare double @js_atomics_add(ptr, double, double, double)

declare double @js_atomics_sub(ptr, double, double, double)

declare double @js_atomics_and(ptr, double, double, double)

declare double @js_atomics_or(ptr, double, double, double)

declare double @js_atomics_xor(ptr, double, double, double)

declare double @js_atomics_exchange(ptr, double, double, double)

declare double @js_atomics_compare_exchange(ptr, double, double, double, double)

declare double @js_atomics_notify(ptr, double, double, double)

declare double @js_atomics_wait(ptr, double, double, double, double)

declare double @js_atomics_wait_async(ptr, double, double, double, double)

declare double @js_number_is_finite(double)

declare double @js_json_get_bool(i64, i64)

declare double @js_json_get_number(i64, i64)

declare i64 @js_json_get_string(i64, i64)

declare double @js_json_is_valid(i64)

declare i64 @js_json_stringify_bool(double)

declare i64 @js_json_stringify_null()

declare i64 @js_json_stringify_number(double)

declare i64 @js_json_stringify_string(i64)

declare void @js_set_property(double, i64, i64, double)

declare i64 @js_error_get_message(i64)

declare double @js_await_js_promise(double)

declare i64 @js_text_decoder_decode(i64)

declare i64 @js_text_encoder_encode(double)

declare double @js_call_function(i64, i64, i64, i64, i64)

declare double @js_call_method(double, i64, i64, i64, i64)

declare double @js_call_value(double, i64, i64)

declare double @js_closure_call_array(i64, ptr, i64)

declare double @js_closure_call_apply_with_spread(double, ptr, i64, i64)

declare double @js_create_callback(i64, i64, i64)

declare double @js_dynamic_neg(double)

declare double @js_dynamic_pos(double)

declare i32 @js_dynamic_string_equals(double, double)

declare double @js_is_nan(double)

declare i32 @js_jsvalue_compare(double, double)

declare i32 @js_jsvalue_loose_equals(double, double)

declare void @js_gc_collect()

declare void @js_console_assert(double, i64)

declare void @js_console_assert_spread(double, i64)

declare void @js_console_group(i64)

declare double @js_console_context(double)

declare double @js_console_create_task(double)

declare i64 @js_fetch_input_ptr(double)

declare i64 @js_fetch_get(i64)

declare i64 @js_fetch_get_with_auth(i64, i64)

declare i64 @js_fetch_post(i64, i64, i64)

declare i64 @js_fetch_post_with_auth(i64, i64, i64)

declare double @js_fetch_stream_close(double)

declare i64 @js_fetch_stream_poll(double)

declare double @js_fetch_stream_start(i64, i64, i64, i64)

declare double @js_fetch_stream_status(double)

declare i64 @js_fetch_text(i64)

declare i64 @js_fetch_with_options(i64, i64, i64, i64)

declare void @js_fetch_set_pending_signal(double)

declare i64 @js_fetch_headers_to_json(double)

declare double @js_net_create_connection(i32, i64, i64)

declare i64 @js_net_create_server(i64, i64)

declare i64 @js_ext_net_create_server(i64, i64)

declare i64 @js_ext_net_socket_connect(double, double, double)

declare double @js_net_normalize_args(double)

declare double @js_net_create_server_handle_stub(double, double, double, double, double)

declare void @js_net_validate_create_server_options(double)

declare i64 @js_net_socket_set_timeout(i64, double, i64)

declare void @js_net_server_listen(i64, double, double, double)

declare void @js_net_server_close(i64, i64)

declare i64 @js_net_server_address(i64)

declare void @js_net_server_on(i64, i64, i64)

declare double @js_net_server_get_listening(i64)

declare double @js_net_server_get_connections(i64)

declare double @js_net_server_get_max_connections(i64)

declare double @js_net_server_set_max_connections(i64, double)

declare double @js_net_server_get_drop_max_connection(i64)

declare double @js_net_server_set_drop_max_connection(i64, double)

declare i64 @js_net_block_list_new()

declare double @js_net_block_list_is_block_list(double)

declare double @js_net_block_list_add_address(i64, i64, i64)

declare double @js_net_block_list_add_range(i64, i64, i64, i64)

declare double @js_net_block_list_add_subnet(i64, i64, double, i64)

declare double @js_net_block_list_check(i64, i64, i64)

declare double @js_net_block_list_to_json(i64)

declare i64 @js_net_block_list_rules(i64)

declare double @js_net_block_list_from_json(i64, double)

declare i64 @js_net_socket_address_new(double)

declare double @js_net_socket_address_parse(i64)

declare i64 @js_net_socket_address_get_address(i64)

declare i64 @js_net_socket_address_get_family(i64)

declare double @js_net_socket_address_get_port(i64)

declare double @js_net_socket_address_get_flowlabel(i64)

declare double @js_net_socket_get_type_of_service(i64)

declare i64 @js_net_socket_set_type_of_service(i64, double)

declare i64 @js_net_socket_address(i64)

declare i64 @js_net_socket_once(i64, i64, i64)

declare i64 @js_ext_net_socket_once(i64, i64, i64)

declare void @js_ext_net_socket_on(i64, i64, i64)

declare i64 @js_ext_tls_connect(double, double, double, double)

declare i64 @js_net_socket_remove_listener(i64, i64, i64)

declare i64 @js_net_socket_remove_all_listeners(i64, i64)

declare double @js_net_socket_listener_count(i64, i64)

declare i64 @js_net_socket_event_names(i64)

declare i64 @js_net_socket_reset_and_destroy(i64)

declare i64 @js_net_server_once(i64, i64, i64)

declare i64 @js_net_server_remove_listener(i64, i64, i64)

declare i64 @js_net_server_remove_all_listeners(i64, i64)

declare double @js_net_server_listener_count(i64, i64)

declare i64 @js_net_server_event_names(i64)

declare double @js_performance_now()

declare double @js_perf_mark(double, double)

declare double @js_perf_measure(double, double, double)

declare double @js_perf_get_entries()

declare double @js_perf_get_entries_by_type(double)

declare double @js_perf_get_entries_by_name(double, double)

declare double @js_perf_clear_marks(double)

declare double @js_perf_clear_measures(double)

declare double @js_perf_event_loop_utilization(double, double)

declare double @js_perf_to_json()

declare double @js_perf_clear_resource_timings()

declare double @js_perf_set_resource_timing_buffer_size(double)

declare double @js_perf_mark_resource_timing(double, double, double, double, double, double, double, double)

declare double @js_perf_timerify(double, double)

declare double @js_perf_observer_new(double)

declare double @js_perf_observer_observe(double, double)

declare double @js_perf_observer_disconnect(double)

declare double @js_perf_observer_take_records(double)

declare double @js_perf_monitor_event_loop_delay(double)

declare double @js_perf_create_histogram(double)

declare double @js_iter_result_set(double, i32)

declare double @js_iter_result_set_f64(double, i32)

declare double @js_iter_result_set_i32(i32, i32)

declare double @js_iter_result_set_i1(i32, i32)

declare double @js_iter_result_get_value()

declare double @js_iter_result_get_value_f64()

declare i32 @js_iter_result_get_value_i32()

declare i32 @js_iter_result_get_value_i1()

declare double @js_iter_result_get_done()

declare i64 @js_async_step_chain(double, i64)

declare i64 @js_async_step_done(double, i64)

declare i64 @js_get_current_step_closure()

declare double @js_async_first_call(double)

declare double @js_async_generator_resume(double, double, double)

declare void @js_register_class_getter(i64, i64, i64, i64)

declare void @js_register_class_setter(i64, i64, i64, i64)

declare void @js_register_class_string_member_order(i64, i64, i64, i64, i64)

declare void @js_register_class_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_method_bind_length(i64, i64, i64, i64)

declare void @js_register_class_static_getter(i64, i64, i64, i64)

declare void @js_register_class_static_setter(i64, i64, i64, i64)

declare void @js_register_class_method(i64, i64, i64, i64, i64, i64, i64)

declare void @js_register_class_constructor(i64, i64, i64, i64)

declare void @js_register_class_constructor_flags(i64, i64, i64)

declare void @js_register_class_static_method(i64, i64, i64, i64, i64, i64)

declare double @js_class_static_method_call(double, i64, i64, ptr, i64)

declare double @js_class_method_bind(double, i64, i64)

declare double @js_class_method_snapshot_bind(double, i64, i64)

declare double @js_class_method_bind_by_id(double, i64)

declare double @js_class_lexical_binding_get(double)

declare double @js_class_lexical_binding_set(double, double)

declare double @js_class_prototype_method_value(double, double)

declare double @js_implicit_this_get()

declare double @js_implicit_this_get_sloppy()

declare double @js_implicit_this_set(double)

declare double @js_static_this_resolve(double)

declare void @js_static_this_arm_classref(i32)

declare void @js_static_this_arm_value(double)

declare double @js_ctor_return_override(double, double, i32)

declare double @js_new_target_get()

declare double @js_new_target_set(double)

declare void @js_derived_super_scope_push(ptr)

declare void @js_derived_super_scope_pop()

declare double @js_derived_super_bind_current()

declare double @js_derived_this_check_current()

declare double @js_get_export(i64, i64, i64)

declare double @js_get_property(double, i64, i64)

declare i64 @js_load_module(i64, i64)

declare double @js_module_dynamic_import_apply_hooks(double)

declare double @js_native_call_method_nullsafe(double, i64, i64, i64, i64)

declare double @js_native_call_value(double, i64, i64)

declare double @js_new_from_handle(double, i64, i64)

declare double @js_new_instance(i64, i64, i64, i64, i64)

declare void @js_runtime_init()

declare double @js_object_set_symbol_method(double, double, double)

declare double @js_object_set_method_by_name(double, double, double)

declare double @js_object_define_accessor(double, double, double, double)

declare double @js_object_literal_set_computed(double, double, double)

declare double @js_object_literal_to_property_key(double)

declare double @js_object_literal_set_prototype(double, double)

declare double @js_to_primitive(double, i32)

declare void @js_register_class_has_instance(i32, i64)

declare void @js_register_class_to_string_tag(i32, i64)

declare double @js_object_to_string(double)

declare double @js_object_group_by(double, double)

declare double @js_map_group_by(double, double)

declare double @js_array_from_async(double, double, double)

declare double @js_jsx(double, double)

declare double @js_jsxs(double, double)

declare i64 @js_node_http_server_ref(i64)

declare i64 @js_node_http_server_unref(i64)

declare i64 @js_node_https_server_ref(i64)

declare i64 @js_node_https_server_unref(i64)

declare double @js_http_client_request_flush_headers(i64, double, double)

declare double @js_node_http_im_http_version_major(i64)

declare double @js_node_http_im_http_version_minor(i64)

declare i64 @js_node_http_im_pause_self(i64)

declare i64 @js_node_http_im_resume_self(i64)

declare i64 @js_commander_args_array(i64)

declare i64 @js_commander_argument(i64, i64)

declare double @__ic_decl_0()

declare double @__ic_decl_2()

declare double @__ic_decl_3()

declare double @__ic_decl_5()

declare double @__ic_decl_6()

declare double @__ic_decl_8()

declare double @__ic_decl_9()

declare double @__ic_decl_11()

declare double @__ic_decl_18()

declare double @__ic_decl_20()

declare double @__ic_decl_22()

declare double @__ic_decl_24()

declare double @__ic_decl_26()

declare double @__ic_decl_28()

declare double @__ic_decl_30()

declare token @llvm.experimental.gc.statepoint.p0(i64 immarg, i32 immarg, ptr, i32 immarg, i32 immarg, ...)

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token, i32 immarg, i32 immarg) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i1 @llvm.experimental.gc.result.i1(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i8 @llvm.experimental.gc.result.i8(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i16 @llvm.experimental.gc.result.i16(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i32 @llvm.experimental.gc.result.i32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i64 @llvm.experimental.gc.result.i64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare i128 @llvm.experimental.gc.result.i128(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare float @llvm.experimental.gc.result.f32(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare double @llvm.experimental.gc.result.f64(token) #3

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(none)
declare ptr @llvm.experimental.gc.result.p0(token) #3

; Function Attrs: optsize
define internal double @"perry_fn_changing_options_worker_ts__run$spec_b"(double %arg13) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b3 = bitcast double %arg13 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r3 = load double, ptr @perry_global_changing_options_worker_ts__1, align 8
  %r4 = load double, ptr @changing_options_worker_ts_.str.0.handle, align 8
  %r5 = bitcast double %r3 to i64
  %r6 = bitcast double %r4 to i64
  %r7 = icmp eq i64 %r5, %r6
  br i1 %r7, label %streqlit.true.6, label %streqlit.tag.1

streqlit.tag.1:                                   ; preds = %entry.0
  %r8 = lshr i64 %r5, 48
  %r9 = icmp eq i64 %r8, 32767
  %r10 = and i64 %r5, 281474976710655
  %r11 = icmp ugt i64 %r10, 4095
  %r12 = and i1 %r9, %r11
  br i1 %r12, label %streqlit.len.2, label %streqlit.false.7

streqlit.len.2:                                   ; preds = %streqlit.tag.1
  %r13 = inttoptr i64 %r10 to ptr
  %r14 = getelementptr inbounds nuw i8, ptr %r13, i64 4
  %r15 = load i32, ptr %r14, align 4
  %r16 = icmp eq i32 %r15, 14
  br i1 %r16, label %streqlit.b0.3, label %streqlit.false.7

streqlit.b0.3:                                    ; preds = %streqlit.len.2
  %r17 = getelementptr inbounds nuw i8, ptr %r13, i64 20
  %r18 = load i8, ptr %r17, align 1
  %r19 = icmp eq i8 %r18, 99
  br i1 %r19, label %streqlit.bl.4, label %streqlit.false.7

streqlit.bl.4:                                    ; preds = %streqlit.b0.3
  %r20 = getelementptr inbounds nuw i8, ptr %r13, i64 33
  %r21 = load i8, ptr %r20, align 1
  %r22 = icmp eq i8 %r21, 110
  br i1 %r22, label %streqlit.slow.5, label %streqlit.false.7

streqlit.slow.5:                                  ; preds = %streqlit.bl.4
  %r23 = and i64 %r6, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r10, i64 %r23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3) ]
  %r2410 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %r25 = icmp ne i32 %r2410, 0
  br label %streqlit.merge.8

streqlit.true.6:                                  ; preds = %entry.0
  br label %streqlit.merge.8

streqlit.false.7:                                 ; preds = %streqlit.bl.4, %streqlit.b0.3, %streqlit.len.2, %streqlit.tag.1
  br label %streqlit.merge.8

streqlit.merge.8:                                 ; preds = %streqlit.false.7, %streqlit.true.6, %streqlit.slow.5
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %streqlit.true.6 ], [ %rs4gc.s3.relocated, %streqlit.slow.5 ], [ %rs4gc.s3, %streqlit.false.7 ]
  %r26 = phi i1 [ true, %streqlit.true.6 ], [ false, %streqlit.false.7 ], [ %r25, %streqlit.slow.5 ]
  %r27 = select i1 %r26, i64 9222246136947933188, i64 9222246136947933187
  %r28 = bitcast i64 %r27 to double
  %r29 = icmp eq i64 %r27, 9222246136947933188
  br i1 %r29, label %if.then.9, label %if.else.10

if.then.9:                                        ; preds = %streqlit.merge.8
  %r34.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r34.rs4o = call i64 asm "", "=r,0"(i64 %r34.rs4i) #8
  %r34 = bitcast i64 %r34.rs4o to double
  %r35 = bitcast double %r34 to i64
  %r36 = and i64 %r35, -281474976710656
  %r37 = icmp ult i64 %r36, 9221401712017801216
  %r38 = icmp ugt i64 %r36, 9223090561878065152
  %r39 = or i1 %r37, %r38
  br i1 %r39, label %for.bound_i32.number.12, label %for.bound_i32.merge.14

if.else.10:                                       ; preds = %streqlit.merge.8
  %r386 = load double, ptr @perry_global_changing_options_worker_ts__1, align 8
  %r387 = load double, ptr @changing_options_worker_ts_.str.3.handle, align 8
  %r388 = bitcast double %r386 to i64
  %r389 = bitcast double %r387 to i64
  %r390 = icmp eq i64 %r388, %r389
  br i1 %r390, label %streqlit.true.94, label %streqlit.tag.89

if.merge.11:                                      ; preds = %if.merge.99, %for.exit.20
  %r2.0 = phi double [ %r2.1, %for.exit.20 ], [ %r2.2, %if.merge.99 ]
  ret double %r2.0

for.bound_i32.number.12:                          ; preds = %if.then.9
  %r40 = fcmp oge double %r34, 0xC1E0000000000000
  %r41 = fcmp ole double %r34, 0x41DFFFFFFFC00000
  %r42 = and i1 %r40, %r41
  br i1 %r42, label %for.bound_i32.convert.13, label %for.bound_i32.merge.14

for.bound_i32.convert.13:                         ; preds = %for.bound_i32.number.12
  %r43 = fptosi double %r34 to i32
  %r44 = sitofp i32 %r43 to double
  %r45 = fcmp oeq double %r44, %r34
  br i1 %r45, label %for.counter_i32.range.15, label %for.bound_i32.merge.14

for.bound_i32.merge.14:                           ; preds = %for.counter_i32.convert.16, %for.bound_i32.convert.13, %for.bound_i32.number.12, %if.then.9
  %r33.0 = phi i32 [ %r43, %for.counter_i32.convert.16 ], [ 0, %if.then.9 ], [ %r43, %for.bound_i32.convert.13 ], [ 0, %for.bound_i32.number.12 ]
  %r32.0 = phi i1 [ true, %for.counter_i32.convert.16 ], [ false, %if.then.9 ], [ false, %for.bound_i32.convert.13 ], [ false, %for.bound_i32.number.12 ]
  br label %for.cond.17

for.counter_i32.range.15:                         ; preds = %for.bound_i32.convert.13
  br label %for.counter_i32.convert.16

for.counter_i32.convert.16:                       ; preds = %for.counter_i32.range.15
  br label %for.bound_i32.merge.14

for.cond.17:                                      ; preds = %for.update.19, %for.bound_i32.merge.14
  %.1 = phi ptr addrspace(1) [ %.0, %for.bound_i32.merge.14 ], [ %.9, %for.update.19 ]
  %r31.1 = phi i32 [ 0, %for.bound_i32.merge.14 ], [ %r385, %for.update.19 ]
  %r30.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.14 ], [ %r383, %for.update.19 ]
  %r2.1 = phi double [ 0.000000e+00, %for.bound_i32.merge.14 ], [ %r374, %for.update.19 ]
  br i1 %r32.0, label %for.cond.fast.21, label %for.cond.slow.22

for.body.18:                                      ; preds = %gcpoll.done.24, %for.cond.fast.21
  %.2 = phi ptr addrspace(1) [ %.1, %for.cond.fast.21 ], [ %.4, %gcpoll.done.24 ]
  %r65 = load double, ptr @perry_global_changing_options_worker_ts__5, align 8
  %r66 = load double, ptr @changing_options_worker_ts_.str.1.handle, align 8
  %r68 = fptosi double %r30.0 to i64
  %r70 = srem i64 %r68, 2
  %r71 = sitofp i64 %r70 to double
  %r72 = icmp eq i64 %r70, 0
  %r73 = fcmp olt double %r30.0, 0.000000e+00
  %r74 = and i1 %r72, %r73
  %r75 = fneg double %r71
  %r76 = select i1 %r74, double %r75, double %r71
  %r77 = fadd double 4.200000e+01, %r76
  %r78 = bitcast double %r65 to i64
  %r79 = bitcast double %r66 to i64
  %r80 = and i64 %r79, 281474976710655
  %r81 = and i64 %r78, 281474976710655
  %r82 = load ptr, ptr @perry_ic_changing_options_worker_ts__0, align 8
  %r83 = icmp ne ptr %r82, null
  %r84 = lshr i64 %r78, 48
  %r85 = icmp eq i64 %r84, 32765
  %r86 = icmp ugt i64 %r81, 1048575
  %r87 = and i1 %r85, %r86
  %r88 = and i1 %r87, %r83
  br i1 %r88, label %put.pic.guard.25, label %put.pic.miss.37

for.update.19:                                    ; preds = %gcpoll.done.88
  %r383 = fadd double %r30.0, 1.000000e+00
  %r385 = add i32 %r31.1, 1
  br label %for.cond.17

for.exit.20:                                      ; preds = %gcpoll.done.24, %for.cond.fast.21
  br label %if.merge.11

for.cond.fast.21:                                 ; preds = %for.cond.17
  %r56 = icmp slt i32 %r31.1, %r33.0
  br i1 %r56, label %for.body.18, label %for.exit.20

for.cond.slow.22:                                 ; preds = %for.cond.17
  %r58.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r58.rs4o = call i64 asm "", "=r,0"(i64 %r58.rs4i) #8
  %r58 = bitcast i64 %r58.rs4o to double
  %r59 = fcmp olt double %r30.0, %r58
  %r60 = select i1 %r59, i64 9222246136947933188, i64 9222246136947933187
  %r61 = bitcast i64 %r60 to double
  %r63 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r64 = icmp ne i32 %r63, 0
  br i1 %r64, label %gcpoll.23, label %gcpoll.done.24

gcpoll.23:                                        ; preds = %for.cond.slow.22
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1) ]
  %rs4gc.s3.relocated12 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 0, i32 0) ; (%.1, %.1)
  br label %gcpoll.done.24

gcpoll.done.24:                                   ; preds = %gcpoll.23, %for.cond.slow.22
  %.4 = phi ptr addrspace(1) [ %rs4gc.s3.relocated12, %gcpoll.23 ], [ %.1, %for.cond.slow.22 ]
  %r62 = icmp eq i64 %r60, 9222246136947933188
  br i1 %r62, label %for.body.18, label %for.exit.20

put.pic.guard.25:                                 ; preds = %for.body.18
  %r89 = sub nuw nsw i64 %r81, 8
  %r90 = inttoptr i64 %r89 to ptr
  %r91 = load i8, ptr %r90, align 1
  %r92 = icmp eq i8 %r91, 2
  %r93 = sub nuw nsw i64 %r81, 7
  %r94 = inttoptr i64 %r93 to ptr
  %r95 = load i8, ptr %r94, align 1
  %r96 = and i8 %r95, -128
  %r97 = icmp eq i8 %r96, 0
  %r98 = sub nuw nsw i64 %r81, 6
  %r99 = inttoptr i64 %r98 to ptr
  %r100 = load i16, ptr %r99, align 2
  %r101 = and i16 %r100, 6535
  %r102 = icmp eq i16 %r101, 0
  %r103 = add nuw nsw i64 %r81, 0
  %r104 = inttoptr i64 %r103 to ptr
  %r105 = load i32, ptr %r104, align 4
  %r106 = icmp ne i32 %r105, 0
  %r107 = icmp ne i32 %r105, -2
  %r108 = and i16 %r100, 512
  %r109 = icmp ne i16 %r108, 0
  %r110 = or i1 %r106, %r109
  %r111 = add nuw nsw i64 %r81, 4
  %r112 = inttoptr i64 %r111 to ptr
  %r113 = load i32, ptr %r112, align 4
  %r114 = add i32 %r113, -2147483648
  %r115 = icmp ult i32 %r114, 1073741824
  %r116 = zext i32 %r113 to i64
  %r117 = or i64 %r116, 4611686018427387904
  %r118 = select i1 %r115, i64 %r117, i64 0
  %r119 = getelementptr i64, ptr %r82, i64 0
  %r120 = load i64, ptr %r119, align 8
  %r121 = icmp eq i64 %r118, %r120
  %r122 = icmp ne i64 %r118, 0
  %r123 = getelementptr i64, ptr %r82, i64 1
  %r124 = load i64, ptr %r123, align 8
  %r125 = and i1 true, %r92
  %r126 = and i1 %r125, %r97
  %r127 = and i1 %r126, %r102
  %r128 = and i1 %r127, %r110
  %r129 = and i1 %r128, %r107
  %r130 = and i1 %r129, %r121
  %r131 = and i1 %r130, %r122
  br i1 %r131, label %put.pic.hit.33, label %put.pic.fallback.29

put.pic.guard2.26:                                ; preds = %put.pic.fallback.29
  %r133 = getelementptr i64, ptr %r82, i64 2
  %r134 = load i64, ptr %r133, align 8
  %r135 = getelementptr i64, ptr %r82, i64 3
  %r136 = load i64, ptr %r135, align 8
  %r137 = icmp eq i64 %r118, %r134
  %r138 = and i1 true, %r92
  %r139 = and i1 %r138, %r97
  %r140 = and i1 %r139, %r102
  %r141 = and i1 %r140, %r110
  %r142 = and i1 %r141, %r107
  %r143 = and i1 %r142, %r137
  %r144 = and i1 %r143, %r122
  br i1 %r144, label %put.pic.hit.33, label %put.pic.dispatch3.30

put.pic.guard3.27:                                ; preds = %put.pic.dispatch3.30
  %r146 = getelementptr i64, ptr %r82, i64 4
  %r147 = load i64, ptr %r146, align 8
  %r148 = getelementptr i64, ptr %r82, i64 5
  %r149 = load i64, ptr %r148, align 8
  %r150 = icmp eq i64 %r118, %r147
  %r151 = and i1 true, %r92
  %r152 = and i1 %r151, %r97
  %r153 = and i1 %r152, %r102
  %r154 = and i1 %r153, %r110
  %r155 = and i1 %r154, %r107
  %r156 = and i1 %r155, %r150
  %r157 = and i1 %r156, %r122
  br i1 %r157, label %put.pic.hit.33, label %put.pic.dispatch4.31

put.pic.guard4.28:                                ; preds = %put.pic.dispatch4.31
  %r159 = getelementptr i64, ptr %r82, i64 6
  %r160 = load i64, ptr %r159, align 8
  %r161 = getelementptr i64, ptr %r82, i64 7
  %r162 = load i64, ptr %r161, align 8
  %r163 = icmp eq i64 %r118, %r160
  %r164 = and i1 true, %r92
  %r165 = and i1 %r164, %r97
  %r166 = and i1 %r165, %r102
  %r167 = and i1 %r166, %r110
  %r168 = and i1 %r167, %r107
  %r169 = and i1 %r168, %r163
  %r170 = and i1 %r169, %r122
  br i1 %r170, label %put.pic.hit.33, label %put.pic.dispatch5.32

put.pic.fallback.29:                              ; preds = %put.pic.guard.25
  %r132 = icmp eq i64 %r120, 0
  br i1 %r132, label %put.pic.miss.37, label %put.pic.guard2.26

put.pic.dispatch3.30:                             ; preds = %put.pic.guard2.26
  %r145 = icmp eq i64 %r134, 0
  br i1 %r145, label %put.pic.miss2.38, label %put.pic.guard3.27

put.pic.dispatch4.31:                             ; preds = %put.pic.guard3.27
  %r158 = icmp eq i64 %r147, 0
  br i1 %r158, label %put.pic.miss3.39, label %put.pic.guard4.28

put.pic.dispatch5.32:                             ; preds = %put.pic.guard4.28
  %r171 = icmp eq i64 %r160, 0
  br i1 %r171, label %put.pic.miss4.40, label %put.pic.tail.41

put.pic.hit.33:                                   ; preds = %put.pic.guard4.28, %put.pic.guard3.27, %put.pic.guard2.26, %put.pic.guard.25
  %r172 = phi i64 [ %r124, %put.pic.guard.25 ], [ %r136, %put.pic.guard2.26 ], [ %r149, %put.pic.guard3.27 ], [ %r162, %put.pic.guard4.28 ]
  %r173 = and i64 %r172, 1073741824
  %r174 = icmp ne i64 %r173, 0
  br i1 %r174, label %put.pic.hit.overflow.43, label %put.pic.hit.inline.44

put.pic.hit.validate.34:                          ; preds = %put.pic.hit.inline.44
  %r184 = load double, ptr %r181, align 8
  %r185 = bitcast double %r184 to i64
  %r186 = icmp eq i64 %r185, 9222246136947933200
  br i1 %r186, label %put.pic.deleted.36, label %put.pic.hit.store.35

put.pic.hit.store.35:                             ; preds = %put.pic.hit.inline.44, %put.pic.hit.validate.34
  store double %r77, ptr %r181, align 8
  br label %put.pic.merge.42

put.pic.deleted.36:                               ; preds = %put.pic.hit.validate.34
  %statepoint_token13 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r65, i64 %r80, double %r77, i32 1, ptr @perry_ic_changing_options_worker_ts__0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r18714 = call double @llvm.experimental.gc.result.f64(token %statepoint_token13)
  %rs4gc.s3.relocated15 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token13, i32 0, i32 0) ; (%.2, %.2)
  br label %put.pic.merge.42

put.pic.miss.37:                                  ; preds = %put.pic.hit.overflow.43, %put.pic.fallback.29, %for.body.18
  %.3 = phi ptr addrspace(1) [ %rs4gc.s3.relocated36, %put.pic.hit.overflow.43 ], [ %.2, %put.pic.fallback.29 ], [ %.2, %for.body.18 ]
  %r781 = load double, ptr @changing_options_worker_ts_.str.1.handle, align 8
  %r782 = bitcast double %r781 to i64
  %r783 = and i64 %r782, 281474976710655
  %statepoint_token16 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r65, i64 %r783, double %r77, i32 1, ptr @perry_ic_changing_options_worker_ts__0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3) ]
  %r18817 = call double @llvm.experimental.gc.result.f64(token %statepoint_token16)
  %rs4gc.s3.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 0, i32 0) ; (%.3, %.3)
  br label %put.pic.merge.42

put.pic.miss2.38:                                 ; preds = %put.pic.dispatch3.30
  %statepoint_token19 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r65, i64 %r80, double %r77, i32 1, ptr @perry_ic_changing_options_worker_ts__0, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r18920 = call double @llvm.experimental.gc.result.f64(token %statepoint_token19)
  %rs4gc.s3.relocated21 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 0, i32 0) ; (%.2, %.2)
  br label %put.pic.merge.42

put.pic.miss3.39:                                 ; preds = %put.pic.dispatch4.31
  %statepoint_token22 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r65, i64 %r80, double %r77, i32 1, ptr @perry_ic_changing_options_worker_ts__0, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r19023 = call double @llvm.experimental.gc.result.f64(token %statepoint_token22)
  %rs4gc.s3.relocated24 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 0, i32 0) ; (%.2, %.2)
  br label %put.pic.merge.42

put.pic.miss4.40:                                 ; preds = %put.pic.dispatch5.32
  %statepoint_token25 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r65, i64 %r80, double %r77, i32 1, ptr @perry_ic_changing_options_worker_ts__0, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r19126 = call double @llvm.experimental.gc.result.f64(token %statepoint_token25)
  %rs4gc.s3.relocated27 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token25, i32 0, i32 0) ; (%.2, %.2)
  br label %put.pic.merge.42

put.pic.tail.41:                                  ; preds = %put.pic.dispatch5.32
  %statepoint_token28 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, i64, double, i32)) @js_put_value_set_ic_poly_tail, i32 5, i32 0, ptr @perry_ic_changing_options_worker_ts__0_poly_tail, double %r65, i64 %r80, double %r77, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r19229 = call double @llvm.experimental.gc.result.f64(token %statepoint_token28)
  %rs4gc.s3.relocated30 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 0, i32 0) ; (%.2, %.2)
  br label %put.pic.merge.42

put.pic.merge.42:                                 ; preds = %put.pic.hit.overflow.43, %put.pic.tail.41, %put.pic.miss4.40, %put.pic.miss3.39, %put.pic.miss2.38, %put.pic.miss.37, %put.pic.deleted.36, %put.pic.hit.store.35
  %.5 = phi ptr addrspace(1) [ %rs4gc.s3.relocated36, %put.pic.hit.overflow.43 ], [ %rs4gc.s3.relocated18, %put.pic.miss.37 ], [ %rs4gc.s3.relocated15, %put.pic.deleted.36 ], [ %.2, %put.pic.hit.store.35 ], [ %rs4gc.s3.relocated21, %put.pic.miss2.38 ], [ %rs4gc.s3.relocated24, %put.pic.miss3.39 ], [ %rs4gc.s3.relocated27, %put.pic.miss4.40 ], [ %rs4gc.s3.relocated30, %put.pic.tail.41 ]
  %r193 = phi double [ %r77, %put.pic.hit.store.35 ], [ %r77, %put.pic.hit.overflow.43 ], [ %r18714, %put.pic.deleted.36 ], [ %r18817, %put.pic.miss.37 ], [ %r18920, %put.pic.miss2.38 ], [ %r19023, %put.pic.miss3.39 ], [ %r19126, %put.pic.miss4.40 ], [ %r19229, %put.pic.tail.41 ]
  %r195 = load double, ptr @perry_global_changing_options_worker_ts__5, align 8
  %statepoint_token31 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r195, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5) ]
  %r19632 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token31)
  %rs4gc.s3.relocated33 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token31, i32 0, i32 0) ; (%.5, %.5)
  %r197 = bitcast i64 %r19632 to double
  %rs4gc.b4 = bitcast double %r197 to i64
  %rs4gc.s4 = inttoptr i64 %rs4gc.b4 to ptr addrspace(1)
  %r198.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s4 to i64
  %r198 = call i64 asm "", "=r,0"(i64 %r198.rs4i) #8
  %r199 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r200 = icmp ne i32 %r199, 0
  br i1 %r200, label %shadow.root.barrier.45, label %shadow.root.barrier.done.46

put.pic.hit.overflow.43:                          ; preds = %put.pic.hit.33
  %r175 = trunc i64 %r172 to i32
  %statepoint_token34 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (double, i64, i32, double)) @js_put_value_set_ic_overflow_store, i32 4, i32 0, double %r65, i64 %r118, i32 %r175, double %r77, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r17635 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token34)
  %rs4gc.s3.relocated36 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token34, i32 0, i32 0) ; (%.2, %.2)
  %r177 = icmp ne i32 %r17635, 0
  br i1 %r177, label %put.pic.merge.42, label %put.pic.miss.37

put.pic.hit.inline.44:                            ; preds = %put.pic.hit.33
  %r178 = shl i64 %r172, 3
  %r179 = add nuw nsw i64 %r81, 16
  %r180 = add i64 %r179, %r178
  %r181 = inttoptr i64 %r180 to ptr
  %r182 = and i16 %r100, 1024
  %r183 = icmp ne i16 %r182, 0
  br i1 %r183, label %put.pic.hit.validate.34, label %put.pic.hit.store.35

shadow.root.barrier.45:                           ; preds = %put.pic.merge.42
  call void @js_write_barrier_root_nanbox(i64 %r198) #8
  br label %shadow.root.barrier.done.46

shadow.root.barrier.done.46:                      ; preds = %shadow.root.barrier.45, %put.pic.merge.42
  %r202 = bitcast double %r2.1 to i64
  %rs4gc.s5 = inttoptr i64 %r202 to ptr addrspace(1)
  %r204.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s5 to i64
  %r204 = call i64 asm "", "=r,0"(i64 %r204.rs4i) #8
  %r205 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r206 = icmp ne i32 %r205, 0
  br i1 %r206, label %shadow.root.barrier.47, label %shadow.root.barrier.done.48

shadow.root.barrier.47:                           ; preds = %shadow.root.barrier.done.46
  call void @js_write_barrier_root_nanbox(i64 %r204) #8
  br label %shadow.root.barrier.done.48

shadow.root.barrier.done.48:                      ; preds = %shadow.root.barrier.47, %shadow.root.barrier.done.46
  %r207.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s4 to i64
  %r207.rs4o = call i64 asm "", "=r,0"(i64 %r207.rs4i) #8
  %r207 = bitcast i64 %r207.rs4o to double
  %r208 = bitcast double %r207 to i64
  %r209 = and i64 %r208, 281474976710655
  %r210 = lshr i64 %r208, 48
  %r211 = and i64 %r210, 65533
  %r212 = icmp eq i64 %r211, 32765
  br i1 %r212, label %pget.recv_ok.50, label %pget.recv_other.55

pget.recv_sso.49:                                 ; preds = %pget.recv_other.55
  %r351 = lshr i64 %r208, 40
  %r352 = and i64 %r351, 255
  %r353 = uitofp nneg i64 %r352 to double
  br label %pget.recv_merge.53

pget.recv_ok.50:                                  ; preds = %shadow.root.barrier.done.48
  %r219 = icmp eq i64 %r210, 32767
  br i1 %r219, label %pget.strlen_heap.54, label %pget.recv_obj.57

pget.recv_bad.51:                                 ; preds = %pget.check_class_ref.56
  %r343 = icmp eq i64 %r208, 9222246136947933185
  %r344 = icmp eq i64 %r208, 9222246136947933186
  %r345 = or i1 %r343, %r344
  br i1 %r345, label %pget.throw_nullish.80, label %pget.recv_undef_return.81

pget.recv_class_ref.52:                           ; preds = %pget.check_class_ref.56
  %r215 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r216 = bitcast double %r215 to i64
  %r217 = and i64 %r216, 281474976710655
  %statepoint_token37 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 1175166488852561921, i64 %r208, i64 %r217, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated33, ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s5) ]
  %r21838 = call double @llvm.experimental.gc.result.f64(token %statepoint_token37)
  %rs4gc.s3.relocated39 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token37, i32 0, i32 0) ; (%rs4gc.s3.relocated33, %rs4gc.s3.relocated33)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token37, i32 1, i32 1) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s5.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token37, i32 2, i32 2) ; (%rs4gc.s5, %rs4gc.s5)
  br label %pget.recv_merge.53

pget.recv_merge.53:                               ; preds = %pget.recv_undef_return.81, %pic.merge.72, %pget.strlen_heap.54, %pget.recv_class_ref.52, %pget.recv_sso.49
  %.0119 = phi ptr addrspace(1) [ %rs4gc.s5, %pget.strlen_heap.54 ], [ %.1120, %pic.merge.72 ], [ %rs4gc.s5, %pget.recv_sso.49 ], [ %rs4gc.s5.relocated, %pget.recv_class_ref.52 ], [ %rs4gc.s5.relocated55, %pget.recv_undef_return.81 ]
  %.0116 = phi ptr addrspace(1) [ %rs4gc.s4, %pget.strlen_heap.54 ], [ %.1117, %pic.merge.72 ], [ %rs4gc.s4, %pget.recv_sso.49 ], [ %rs4gc.s4.relocated, %pget.recv_class_ref.52 ], [ %rs4gc.s4.relocated54, %pget.recv_undef_return.81 ]
  %.6 = phi ptr addrspace(1) [ %rs4gc.s3.relocated33, %pget.strlen_heap.54 ], [ %.7, %pic.merge.72 ], [ %rs4gc.s3.relocated33, %pget.recv_sso.49 ], [ %rs4gc.s3.relocated39, %pget.recv_class_ref.52 ], [ %rs4gc.s3.relocated53, %pget.recv_undef_return.81 ]
  %r359 = phi double [ %r342, %pic.merge.72 ], [ %r35052, %pget.recv_undef_return.81 ], [ %r353, %pget.recv_sso.49 ], [ %r21838, %pget.recv_class_ref.52 ], [ %r358, %pget.strlen_heap.54 ]
  %r360.rs4i = ptrtoint ptr addrspace(1) %.0119 to i64
  %r360 = call i64 asm "", "=r,0"(i64 %r360.rs4i) #8
  %r361 = bitcast i64 %r360 to double
  %r362 = and i64 %r360, -281474976710656
  %r363 = icmp ult i64 %r362, 9221401712017801216
  %r364 = icmp ugt i64 %r362, 9223090561878065152
  %r365 = or i1 %r363, %r364
  %r366 = bitcast double %r359 to i64
  %r367 = and i64 %r366, -281474976710656
  %r368 = icmp ult i64 %r367, 9221401712017801216
  %r369 = icmp ugt i64 %r367, 9223090561878065152
  %r370 = or i1 %r368, %r369
  %r371 = and i1 %r365, %r370
  br i1 %r371, label %guarded_add.numeric.82, label %guarded_add.dynamic.83

pget.strlen_heap.54:                              ; preds = %pget.recv_ok.50
  %r354 = icmp ult i64 %r209, 4096
  %r355 = inttoptr i64 %r209 to ptr
  %r356 = select i1 %r354, ptr @perry_null_guard_zero_changing_options_worker_ts, ptr %r355
  %r357 = load i32, ptr %r356, align 4
  %r358 = uitofp i32 %r357 to double
  br label %pget.recv_merge.53

pget.recv_other.55:                               ; preds = %shadow.root.barrier.done.48
  %r213 = icmp eq i64 %r210, 32761
  br i1 %r213, label %pget.recv_sso.49, label %pget.check_class_ref.56

pget.check_class_ref.56:                          ; preds = %pget.recv_other.55
  %r214 = icmp eq i64 %r210, 32766
  br i1 %r214, label %pget.recv_class_ref.52, label %pget.recv_bad.51

pget.recv_obj.57:                                 ; preds = %pget.recv_ok.50
  %r220 = icmp ugt i64 %r209, 1048575
  br i1 %r220, label %pic.recv_hdr.73, label %pic.miss.cold.70

pic.hit.58:                                       ; preds = %pic.token.74
  %r245 = getelementptr i64, ptr %r230, i64 1
  %r246 = load i64, ptr %r245, align 8
  %r247 = and i64 %r246, 1073741824
  %r248 = icmp ne i64 %r247, 0
  br i1 %r248, label %pic.hit.overflow.75, label %pic.hit.inline.76

pic.hit.live.59:                                  ; preds = %pic.hit.inline.76
  br label %pic.merge.72

pic.prefix.guard.60:                              ; preds = %pic.token.74
  %r261 = getelementptr i64, ptr %r230, i64 2
  %r262 = load i64, ptr %r261, align 8
  %r263 = icmp ne i64 %r262, 0
  br i1 %r263, label %pic.prefix.meta.61, label %pic.miss.69

pic.prefix.meta.61:                               ; preds = %pic.prefix.guard.60
  %r264 = add nuw nsw i64 %r209, 8
  %r265 = inttoptr i64 %r264 to ptr
  %r266 = load i64, ptr %r265, align 8
  %r267 = icmp ne i64 %r266, 0
  br i1 %r267, label %pic.prefix.token.62, label %pic.miss.69

pic.prefix.token.62:                              ; preds = %pic.prefix.meta.61
  %r268 = inttoptr i64 %r266 to ptr
  %r269 = getelementptr i64, ptr %r268, i64 6
  %r270 = load i64, ptr %r269, align 8
  %r271 = icmp eq i64 %r270, %r262
  br i1 %r271, label %pic.prefix.hit.63, label %pic.miss.69

pic.prefix.hit.63:                                ; preds = %pic.prefix.token.62
  %r272 = getelementptr i64, ptr %r230, i64 1
  %r273 = load i64, ptr %r272, align 8
  %r274 = shl i64 %r273, 3
  %r275 = add nuw nsw i64 %r209, 16
  %r276 = add i64 %r275, %r274
  %r277 = inttoptr i64 %r276 to ptr
  %r278 = load double, ptr %r277, align 8
  br label %pic.merge.72

pic.desc.classify.64:                             ; preds = %pic.recv_hdr.73
  %r234 = and i1 %r224, %r231
  br i1 %r234, label %pic.desc.prefix.guard.65, label %pic.miss.cold.70

pic.desc.prefix.guard.65:                         ; preds = %pic.desc.classify.64
  %r279 = getelementptr i64, ptr %r230, i64 2
  %r280 = load i64, ptr %r279, align 8
  %r281 = icmp ne i64 %r280, 0
  br i1 %r281, label %pic.desc.prefix.meta.66, label %pic.miss.cold.70

pic.desc.prefix.meta.66:                          ; preds = %pic.desc.prefix.guard.65
  %r282 = add nuw nsw i64 %r209, 8
  %r283 = inttoptr i64 %r282 to ptr
  %r284 = load i64, ptr %r283, align 8
  %r285 = icmp ne i64 %r284, 0
  br i1 %r285, label %pic.desc.prefix.token.67, label %pic.miss.cold.70

pic.desc.prefix.token.67:                         ; preds = %pic.desc.prefix.meta.66
  %r286 = inttoptr i64 %r284 to ptr
  %r287 = getelementptr i64, ptr %r286, i64 6
  %r288 = load i64, ptr %r287, align 8
  %r289 = icmp eq i64 %r288, %r280
  br i1 %r289, label %pic.desc.prefix.hit.68, label %pic.miss.cold.70

pic.desc.prefix.hit.68:                           ; preds = %pic.desc.prefix.token.67
  %r290 = getelementptr i64, ptr %r230, i64 1
  %r291 = load i64, ptr %r290, align 8
  %r292 = shl i64 %r291, 3
  %r293 = add nuw nsw i64 %r209, 16
  %r294 = add i64 %r293, %r292
  %r295 = inttoptr i64 %r294 to ptr
  %r296 = load double, ptr %r295, align 8
  br label %pic.merge.72

pic.miss.69:                                      ; preds = %pic.hit.inline.76, %pic.prefix.token.62, %pic.prefix.meta.61, %pic.prefix.guard.60
  %r297 = getelementptr i64, ptr %r230, i64 3
  %r298 = load i64, ptr %r297, align 8
  %r299 = icmp sgt i64 %r298, 0
  br i1 %r299, label %pic.ways.77, label %pic.miss.call.71

pic.miss.cold.70:                                 ; preds = %pic.desc.prefix.token.67, %pic.desc.prefix.meta.66, %pic.desc.prefix.guard.65, %pic.desc.classify.64, %pget.recv_obj.57
  br label %pic.miss.call.71

pic.miss.call.71:                                 ; preds = %pic.way.load.78, %pic.ways.77, %pic.miss.cold.70, %pic.miss.69
  %r338 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r339 = bitcast double %r338 to i64
  %r340 = and i64 %r339, 281474976710655
  %statepoint_token40 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r209, i64 %r340, ptr @perry_ic_changing_options_worker_ts__2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated33, ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s5) ]
  %r34141 = call double @llvm.experimental.gc.result.f64(token %statepoint_token40)
  %rs4gc.s3.relocated42 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 0, i32 0) ; (%rs4gc.s3.relocated33, %rs4gc.s3.relocated33)
  %rs4gc.s4.relocated43 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 1, i32 1) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s5.relocated44 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 2, i32 2) ; (%rs4gc.s5, %rs4gc.s5)
  br label %pic.merge.72

pic.merge.72:                                     ; preds = %pic.way.live.79, %pic.hit.overflow.75, %pic.miss.call.71, %pic.desc.prefix.hit.68, %pic.prefix.hit.63, %pic.hit.live.59
  %.1120 = phi ptr addrspace(1) [ %rs4gc.s5.relocated49, %pic.hit.overflow.75 ], [ %rs4gc.s5.relocated44, %pic.miss.call.71 ], [ %rs4gc.s5, %pic.way.live.79 ], [ %rs4gc.s5, %pic.hit.live.59 ], [ %rs4gc.s5, %pic.prefix.hit.63 ], [ %rs4gc.s5, %pic.desc.prefix.hit.68 ]
  %.1117 = phi ptr addrspace(1) [ %rs4gc.s4.relocated48, %pic.hit.overflow.75 ], [ %rs4gc.s4.relocated43, %pic.miss.call.71 ], [ %rs4gc.s4, %pic.way.live.79 ], [ %rs4gc.s4, %pic.hit.live.59 ], [ %rs4gc.s4, %pic.prefix.hit.63 ], [ %rs4gc.s4, %pic.desc.prefix.hit.68 ]
  %.7 = phi ptr addrspace(1) [ %rs4gc.s3.relocated47, %pic.hit.overflow.75 ], [ %rs4gc.s3.relocated42, %pic.miss.call.71 ], [ %rs4gc.s3.relocated33, %pic.way.live.79 ], [ %rs4gc.s3.relocated33, %pic.hit.live.59 ], [ %rs4gc.s3.relocated33, %pic.prefix.hit.63 ], [ %rs4gc.s3.relocated33, %pic.desc.prefix.hit.68 ]
  %r342 = phi double [ %r258, %pic.hit.live.59 ], [ %r25346, %pic.hit.overflow.75 ], [ %r278, %pic.prefix.hit.63 ], [ %r296, %pic.desc.prefix.hit.68 ], [ %r335, %pic.way.live.79 ], [ %r34141, %pic.miss.call.71 ]
  br label %pget.recv_merge.53

pic.recv_hdr.73:                                  ; preds = %pget.recv_obj.57
  %r221 = sub nuw nsw i64 %r209, 8
  %r222 = inttoptr i64 %r221 to ptr
  %r223 = load i8, ptr %r222, align 1
  %r224 = icmp eq i8 %r223, 2
  %r225 = sub nuw nsw i64 %r209, 6
  %r226 = inttoptr i64 %r225 to ptr
  %r227 = load i16, ptr %r226, align 2
  %r228 = and i16 %r227, 2048
  %r229 = icmp eq i16 %r228, 0
  %r230 = load ptr, ptr @perry_ic_changing_options_worker_ts__2, align 8
  %r231 = icmp ne ptr %r230, null
  %r232 = and i1 %r224, %r229
  %r233 = and i1 %r232, %r231
  br i1 %r233, label %pic.token.74, label %pic.desc.classify.64

pic.token.74:                                     ; preds = %pic.recv_hdr.73
  %r235 = add nuw nsw i64 %r209, 4
  %r236 = inttoptr i64 %r235 to ptr
  %r237 = load i32, ptr %r236, align 4
  %r238 = zext i32 %r237 to i64
  %r239 = or i64 %r238, 4611686018427387904
  %r240 = icmp ne i32 %r237, 0
  %r241 = getelementptr i64, ptr %r230, i64 0
  %r242 = load i64, ptr %r241, align 8
  %r243 = icmp eq i64 %r239, %r242
  %r244 = and i1 %r243, %r240
  br i1 %r244, label %pic.hit.58, label %pic.prefix.guard.60

pic.hit.overflow.75:                              ; preds = %pic.hit.58
  %r249 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r250 = bitcast double %r249 to i64
  %r251 = and i64 %r250, 281474976710655
  %r252 = trunc i64 %r246 to i32
  %statepoint_token45 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r209, i64 %r251, i32 %r252, ptr @perry_ic_changing_options_worker_ts__2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated33, ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s5) ]
  %r25346 = call double @llvm.experimental.gc.result.f64(token %statepoint_token45)
  %rs4gc.s3.relocated47 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token45, i32 0, i32 0) ; (%rs4gc.s3.relocated33, %rs4gc.s3.relocated33)
  %rs4gc.s4.relocated48 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token45, i32 1, i32 1) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s5.relocated49 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token45, i32 2, i32 2) ; (%rs4gc.s5, %rs4gc.s5)
  br label %pic.merge.72

pic.hit.inline.76:                                ; preds = %pic.hit.58
  %r254 = shl i64 %r246, 3
  %r255 = add nuw nsw i64 %r209, 16
  %r256 = add i64 %r255, %r254
  %r257 = inttoptr i64 %r256 to ptr
  %r258 = load double, ptr %r257, align 8
  %r259 = bitcast double %r258 to i64
  %r260 = icmp eq i64 %r259, 9222246136947933200
  br i1 %r260, label %pic.miss.69, label %pic.hit.live.59

pic.ways.77:                                      ; preds = %pic.miss.69
  %r300 = getelementptr i64, ptr %r230, i64 4
  %r301 = load i64, ptr %r300, align 8
  %r302 = icmp eq i64 %r301, %r239
  %r303 = getelementptr i64, ptr %r230, i64 5
  %r304 = load i64, ptr %r303, align 8
  %r305 = select i1 %r302, i64 %r304, i64 0
  %r306 = getelementptr i64, ptr %r230, i64 6
  %r307 = load i64, ptr %r306, align 8
  %r308 = icmp eq i64 %r307, %r239
  %r309 = getelementptr i64, ptr %r230, i64 7
  %r310 = load i64, ptr %r309, align 8
  %r311 = select i1 %r308, i64 %r310, i64 0
  %r312 = getelementptr i64, ptr %r230, i64 8
  %r313 = load i64, ptr %r312, align 8
  %r314 = icmp eq i64 %r313, %r239
  %r315 = getelementptr i64, ptr %r230, i64 9
  %r316 = load i64, ptr %r315, align 8
  %r317 = select i1 %r314, i64 %r316, i64 0
  %r318 = getelementptr i64, ptr %r230, i64 10
  %r319 = load i64, ptr %r318, align 8
  %r320 = icmp eq i64 %r319, %r239
  %r321 = getelementptr i64, ptr %r230, i64 11
  %r322 = load i64, ptr %r321, align 8
  %r323 = select i1 %r320, i64 %r322, i64 0
  %r324 = or i1 %r302, %r308
  %r325 = select i1 %r302, i64 %r305, i64 %r311
  %r326 = or i1 %r314, %r320
  %r327 = select i1 %r314, i64 %r317, i64 %r323
  %r328 = or i1 %r324, %r326
  %r329 = select i1 %r324, i64 %r325, i64 %r327
  %r330 = and i1 %r240, %r328
  br i1 %r330, label %pic.way.load.78, label %pic.miss.call.71

pic.way.load.78:                                  ; preds = %pic.ways.77
  %r331 = shl i64 %r329, 3
  %r332 = add nuw nsw i64 %r209, 16
  %r333 = add i64 %r332, %r331
  %r334 = inttoptr i64 %r333 to ptr
  %r335 = load double, ptr %r334, align 8
  %r336 = bitcast double %r335 to i64
  %r337 = icmp eq i64 %r336, 9222246136947933200
  br i1 %r337, label %pic.miss.call.71, label %pic.way.live.79

pic.way.live.79:                                  ; preds = %pic.way.load.78
  br label %pic.merge.72

pget.throw_nullish.80:                            ; preds = %pget.recv_bad.51
  %r346 = zext i1 %r344 to i32
  %statepoint_token50 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r346, ptr @changing_options_worker_ts_.str.2.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.81:                        ; preds = %pget.recv_bad.51
  %r347 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r348 = bitcast double %r347 to i64
  %r349 = and i64 %r348, 281474976710655
  %statepoint_token51 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r208, i64 %r349, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated33, ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s5) ]
  %r35052 = call double @llvm.experimental.gc.result.f64(token %statepoint_token51)
  %rs4gc.s3.relocated53 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token51, i32 0, i32 0) ; (%rs4gc.s3.relocated33, %rs4gc.s3.relocated33)
  %rs4gc.s4.relocated54 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token51, i32 1, i32 1) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s5.relocated55 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token51, i32 2, i32 2) ; (%rs4gc.s5, %rs4gc.s5)
  br label %pget.recv_merge.53

guarded_add.numeric.82:                           ; preds = %pget.recv_merge.53
  %r372 = fadd double %r361, %r359
  br label %guarded_add.merge.84

guarded_add.dynamic.83:                           ; preds = %pget.recv_merge.53
  %statepoint_token56 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r361, double %r359, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6, ptr addrspace(1) %.0116) ]
  %r37357 = call double @llvm.experimental.gc.result.f64(token %statepoint_token56)
  %rs4gc.s3.relocated58 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token56, i32 0, i32 0) ; (%.6, %.6)
  %rs4gc.s4.relocated59 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token56, i32 1, i32 1) ; (%.0116, %.0116)
  br label %guarded_add.merge.84

guarded_add.merge.84:                             ; preds = %guarded_add.dynamic.83, %guarded_add.numeric.82
  %.2118 = phi ptr addrspace(1) [ %.0116, %guarded_add.numeric.82 ], [ %rs4gc.s4.relocated59, %guarded_add.dynamic.83 ]
  %.8 = phi ptr addrspace(1) [ %.6, %guarded_add.numeric.82 ], [ %rs4gc.s3.relocated58, %guarded_add.dynamic.83 ]
  %r374 = phi double [ %r372, %guarded_add.numeric.82 ], [ %r37357, %guarded_add.dynamic.83 ]
  %r375.rs4i = ptrtoint ptr addrspace(1) %.2118 to i64
  %r375.rs4o = call i64 asm "", "=r,0"(i64 %r375.rs4i) #8
  %r375 = bitcast i64 %r375.rs4o to double
  %r376 = bitcast double %r375 to i64
  %r377 = and i64 %r376, -281474976710656
  %r378 = icmp ne i64 %r377, 9223090561878065152
  br i1 %r378, label %str_addref.done.86, label %str_addref.call.85

str_addref.call.85:                               ; preds = %guarded_add.merge.84
  call void @js_string_addref_if_heap_string(double %r375) #8
  br label %str_addref.done.86

str_addref.done.86:                               ; preds = %str_addref.call.85, %guarded_add.merge.84
  %r780.rs4i = ptrtoint ptr addrspace(1) %.2118 to i64
  %r780.rs4o = call i64 asm "", "=r,0"(i64 %r780.rs4i) #8
  %r780 = bitcast i64 %r780.rs4o to double
  store double %r780, ptr @perry_global_changing_options_worker_ts__6, align 8
  %r779.rs4i = ptrtoint ptr addrspace(1) %.2118 to i64
  %r779.rs4o = call i64 asm "", "=r,0"(i64 %r779.rs4i) #8
  %r779 = bitcast i64 %r779.rs4o to double
  %r379 = bitcast double %r779 to i64
  %r777.rs4i = ptrtoint ptr addrspace(1) %.2118 to i64
  %r777.rs4o = call i64 asm "", "=r,0"(i64 %r777.rs4i) #8
  %r777 = bitcast i64 %r777.rs4o to double
  %r778 = bitcast double %r777 to i64
  call void @js_write_barrier_root_nanbox(i64 %r778) #8
  %r380 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r381 = icmp ne i32 %r380, 0
  br i1 %r381, label %gcpoll.87, label %gcpoll.done.88

gcpoll.87:                                        ; preds = %str_addref.done.86
  %statepoint_token60 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8) ]
  %rs4gc.s3.relocated61 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token60, i32 0, i32 0) ; (%.8, %.8)
  br label %gcpoll.done.88

gcpoll.done.88:                                   ; preds = %gcpoll.87, %str_addref.done.86
  %.9 = phi ptr addrspace(1) [ %rs4gc.s3.relocated61, %gcpoll.87 ], [ %.8, %str_addref.done.86 ]
  br label %for.update.19

streqlit.tag.89:                                  ; preds = %if.else.10
  %r391 = lshr i64 %r388, 48
  %r392 = icmp eq i64 %r391, 32767
  %r393 = and i64 %r388, 281474976710655
  %r394 = icmp ugt i64 %r393, 4095
  %r395 = and i1 %r392, %r394
  br i1 %r395, label %streqlit.len.90, label %streqlit.false.95

streqlit.len.90:                                  ; preds = %streqlit.tag.89
  %r396 = inttoptr i64 %r393 to ptr
  %r397 = getelementptr inbounds nuw i8, ptr %r396, i64 4
  %r398 = load i32, ptr %r397, align 4
  %r399 = icmp eq i32 %r398, 13
  br i1 %r399, label %streqlit.b0.91, label %streqlit.false.95

streqlit.b0.91:                                   ; preds = %streqlit.len.90
  %r400 = getelementptr inbounds nuw i8, ptr %r396, i64 20
  %r401 = load i8, ptr %r400, align 1
  %r402 = icmp eq i8 %r401, 99
  br i1 %r402, label %streqlit.bl.92, label %streqlit.false.95

streqlit.bl.92:                                   ; preds = %streqlit.b0.91
  %r403 = getelementptr inbounds nuw i8, ptr %r396, i64 32
  %r404 = load i8, ptr %r403, align 1
  %r405 = icmp eq i8 %r404, 111
  br i1 %r405, label %streqlit.slow.93, label %streqlit.false.95

streqlit.slow.93:                                 ; preds = %streqlit.bl.92
  %r406 = and i64 %r389, 281474976710655
  %statepoint_token62 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r393, i64 %r406, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r40763 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token62)
  %rs4gc.s3.relocated64 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token62, i32 0, i32 0) ; (%.0, %.0)
  %r408 = icmp ne i32 %r40763, 0
  br label %streqlit.merge.96

streqlit.true.94:                                 ; preds = %if.else.10
  br label %streqlit.merge.96

streqlit.false.95:                                ; preds = %streqlit.bl.92, %streqlit.b0.91, %streqlit.len.90, %streqlit.tag.89
  br label %streqlit.merge.96

streqlit.merge.96:                                ; preds = %streqlit.false.95, %streqlit.true.94, %streqlit.slow.93
  %.10 = phi ptr addrspace(1) [ %.0, %streqlit.true.94 ], [ %rs4gc.s3.relocated64, %streqlit.slow.93 ], [ %.0, %streqlit.false.95 ]
  %r409 = phi i1 [ true, %streqlit.true.94 ], [ false, %streqlit.false.95 ], [ %r408, %streqlit.slow.93 ]
  %r410 = select i1 %r409, i64 9222246136947933188, i64 9222246136947933187
  %r411 = bitcast i64 %r410 to double
  %r412 = icmp eq i64 %r410, 9222246136947933188
  br i1 %r412, label %if.then.97, label %if.else.98

if.then.97:                                       ; preds = %streqlit.merge.96
  %r417.rs4i = ptrtoint ptr addrspace(1) %.10 to i64
  %r417.rs4o = call i64 asm "", "=r,0"(i64 %r417.rs4i) #8
  %r417 = bitcast i64 %r417.rs4o to double
  %r418 = bitcast double %r417 to i64
  %r419 = and i64 %r418, -281474976710656
  %r420 = icmp ult i64 %r419, 9221401712017801216
  %r421 = icmp ugt i64 %r419, 9223090561878065152
  %r422 = or i1 %r420, %r421
  br i1 %r422, label %for.bound_i32.number.100, label %for.bound_i32.merge.102

if.else.98:                                       ; preds = %streqlit.merge.96
  br label %if.merge.99

if.merge.99:                                      ; preds = %for.exit.108, %if.else.98
  %r2.2 = phi double [ %r2.3, %for.exit.108 ], [ 0.000000e+00, %if.else.98 ]
  br label %if.merge.11

for.bound_i32.number.100:                         ; preds = %if.then.97
  %r423 = fcmp oge double %r417, 0xC1E0000000000000
  %r424 = fcmp ole double %r417, 0x41DFFFFFFFC00000
  %r425 = and i1 %r423, %r424
  br i1 %r425, label %for.bound_i32.convert.101, label %for.bound_i32.merge.102

for.bound_i32.convert.101:                        ; preds = %for.bound_i32.number.100
  %r426 = fptosi double %r417 to i32
  %r427 = sitofp i32 %r426 to double
  %r428 = fcmp oeq double %r427, %r417
  br i1 %r428, label %for.counter_i32.range.103, label %for.bound_i32.merge.102

for.bound_i32.merge.102:                          ; preds = %for.counter_i32.convert.104, %for.bound_i32.convert.101, %for.bound_i32.number.100, %if.then.97
  %r416.0 = phi i32 [ %r426, %for.counter_i32.convert.104 ], [ 0, %if.then.97 ], [ %r426, %for.bound_i32.convert.101 ], [ 0, %for.bound_i32.number.100 ]
  %r415.0 = phi i1 [ true, %for.counter_i32.convert.104 ], [ false, %if.then.97 ], [ false, %for.bound_i32.convert.101 ], [ false, %for.bound_i32.number.100 ]
  br label %for.cond.105

for.counter_i32.range.103:                        ; preds = %for.bound_i32.convert.101
  br label %for.counter_i32.convert.104

for.counter_i32.convert.104:                      ; preds = %for.counter_i32.range.103
  br label %for.bound_i32.merge.102

for.cond.105:                                     ; preds = %for.update.107, %for.bound_i32.merge.102
  %.11 = phi ptr addrspace(1) [ %.10, %for.bound_i32.merge.102 ], [ %.19, %for.update.107 ]
  %r414.1 = phi i32 [ 0, %for.bound_i32.merge.102 ], [ %r768, %for.update.107 ]
  %r413.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.102 ], [ %r766, %for.update.107 ]
  %r2.3 = phi double [ 0.000000e+00, %for.bound_i32.merge.102 ], [ %r757, %for.update.107 ]
  br i1 %r415.0, label %for.cond.fast.109, label %for.cond.slow.110

for.body.106:                                     ; preds = %gcpoll.done.112, %for.cond.fast.109
  %.12 = phi ptr addrspace(1) [ %.11, %for.cond.fast.109 ], [ %.14, %gcpoll.done.112 ]
  %r448 = load double, ptr @perry_global_changing_options_worker_ts__5, align 8
  %r449 = load double, ptr @changing_options_worker_ts_.str.1.handle, align 8
  %r451 = fptosi double %r413.0 to i64
  %r453 = srem i64 %r451, 2
  %r454 = sitofp i64 %r453 to double
  %r455 = icmp eq i64 %r453, 0
  %r456 = fcmp olt double %r413.0, 0.000000e+00
  %r457 = and i1 %r455, %r456
  %r458 = fneg double %r454
  %r459 = select i1 %r457, double %r458, double %r454
  %r460 = fadd double 4.200000e+01, %r459
  %r461 = bitcast double %r448 to i64
  %r462 = bitcast double %r449 to i64
  %r463 = and i64 %r462, 281474976710655
  %r464 = and i64 %r461, 281474976710655
  %r465 = load ptr, ptr @perry_ic_changing_options_worker_ts__3, align 8
  %r466 = icmp ne ptr %r465, null
  %r467 = lshr i64 %r461, 48
  %r468 = icmp eq i64 %r467, 32765
  %r469 = icmp ugt i64 %r464, 1048575
  %r470 = and i1 %r468, %r469
  %r471 = and i1 %r470, %r466
  br i1 %r471, label %put.pic.guard.113, label %put.pic.miss.125

for.update.107:                                   ; preds = %gcpoll.done.176
  %r766 = fadd double %r413.0, 1.000000e+00
  %r768 = add i32 %r414.1, 1
  br label %for.cond.105

for.exit.108:                                     ; preds = %gcpoll.done.112, %for.cond.fast.109
  br label %if.merge.99

for.cond.fast.109:                                ; preds = %for.cond.105
  %r439 = icmp slt i32 %r414.1, %r416.0
  br i1 %r439, label %for.body.106, label %for.exit.108

for.cond.slow.110:                                ; preds = %for.cond.105
  %r441.rs4i = ptrtoint ptr addrspace(1) %.11 to i64
  %r441.rs4o = call i64 asm "", "=r,0"(i64 %r441.rs4i) #8
  %r441 = bitcast i64 %r441.rs4o to double
  %r442 = fcmp olt double %r413.0, %r441
  %r443 = select i1 %r442, i64 9222246136947933188, i64 9222246136947933187
  %r444 = bitcast i64 %r443 to double
  %r446 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r447 = icmp ne i32 %r446, 0
  br i1 %r447, label %gcpoll.111, label %gcpoll.done.112

gcpoll.111:                                       ; preds = %for.cond.slow.110
  %statepoint_token65 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11) ]
  %rs4gc.s3.relocated66 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token65, i32 0, i32 0) ; (%.11, %.11)
  br label %gcpoll.done.112

gcpoll.done.112:                                  ; preds = %gcpoll.111, %for.cond.slow.110
  %.14 = phi ptr addrspace(1) [ %rs4gc.s3.relocated66, %gcpoll.111 ], [ %.11, %for.cond.slow.110 ]
  %r445 = icmp eq i64 %r443, 9222246136947933188
  br i1 %r445, label %for.body.106, label %for.exit.108

put.pic.guard.113:                                ; preds = %for.body.106
  %r472 = sub nuw nsw i64 %r464, 8
  %r473 = inttoptr i64 %r472 to ptr
  %r474 = load i8, ptr %r473, align 1
  %r475 = icmp eq i8 %r474, 2
  %r476 = sub nuw nsw i64 %r464, 7
  %r477 = inttoptr i64 %r476 to ptr
  %r478 = load i8, ptr %r477, align 1
  %r479 = and i8 %r478, -128
  %r480 = icmp eq i8 %r479, 0
  %r481 = sub nuw nsw i64 %r464, 6
  %r482 = inttoptr i64 %r481 to ptr
  %r483 = load i16, ptr %r482, align 2
  %r484 = and i16 %r483, 6535
  %r485 = icmp eq i16 %r484, 0
  %r486 = add nuw nsw i64 %r464, 0
  %r487 = inttoptr i64 %r486 to ptr
  %r488 = load i32, ptr %r487, align 4
  %r489 = icmp ne i32 %r488, 0
  %r490 = icmp ne i32 %r488, -2
  %r491 = and i16 %r483, 512
  %r492 = icmp ne i16 %r491, 0
  %r493 = or i1 %r489, %r492
  %r494 = add nuw nsw i64 %r464, 4
  %r495 = inttoptr i64 %r494 to ptr
  %r496 = load i32, ptr %r495, align 4
  %r497 = add i32 %r496, -2147483648
  %r498 = icmp ult i32 %r497, 1073741824
  %r499 = zext i32 %r496 to i64
  %r500 = or i64 %r499, 4611686018427387904
  %r501 = select i1 %r498, i64 %r500, i64 0
  %r502 = getelementptr i64, ptr %r465, i64 0
  %r503 = load i64, ptr %r502, align 8
  %r504 = icmp eq i64 %r501, %r503
  %r505 = icmp ne i64 %r501, 0
  %r506 = getelementptr i64, ptr %r465, i64 1
  %r507 = load i64, ptr %r506, align 8
  %r508 = and i1 true, %r475
  %r509 = and i1 %r508, %r480
  %r510 = and i1 %r509, %r485
  %r511 = and i1 %r510, %r493
  %r512 = and i1 %r511, %r490
  %r513 = and i1 %r512, %r504
  %r514 = and i1 %r513, %r505
  br i1 %r514, label %put.pic.hit.121, label %put.pic.fallback.117

put.pic.guard2.114:                               ; preds = %put.pic.fallback.117
  %r516 = getelementptr i64, ptr %r465, i64 2
  %r517 = load i64, ptr %r516, align 8
  %r518 = getelementptr i64, ptr %r465, i64 3
  %r519 = load i64, ptr %r518, align 8
  %r520 = icmp eq i64 %r501, %r517
  %r521 = and i1 true, %r475
  %r522 = and i1 %r521, %r480
  %r523 = and i1 %r522, %r485
  %r524 = and i1 %r523, %r493
  %r525 = and i1 %r524, %r490
  %r526 = and i1 %r525, %r520
  %r527 = and i1 %r526, %r505
  br i1 %r527, label %put.pic.hit.121, label %put.pic.dispatch3.118

put.pic.guard3.115:                               ; preds = %put.pic.dispatch3.118
  %r529 = getelementptr i64, ptr %r465, i64 4
  %r530 = load i64, ptr %r529, align 8
  %r531 = getelementptr i64, ptr %r465, i64 5
  %r532 = load i64, ptr %r531, align 8
  %r533 = icmp eq i64 %r501, %r530
  %r534 = and i1 true, %r475
  %r535 = and i1 %r534, %r480
  %r536 = and i1 %r535, %r485
  %r537 = and i1 %r536, %r493
  %r538 = and i1 %r537, %r490
  %r539 = and i1 %r538, %r533
  %r540 = and i1 %r539, %r505
  br i1 %r540, label %put.pic.hit.121, label %put.pic.dispatch4.119

put.pic.guard4.116:                               ; preds = %put.pic.dispatch4.119
  %r542 = getelementptr i64, ptr %r465, i64 6
  %r543 = load i64, ptr %r542, align 8
  %r544 = getelementptr i64, ptr %r465, i64 7
  %r545 = load i64, ptr %r544, align 8
  %r546 = icmp eq i64 %r501, %r543
  %r547 = and i1 true, %r475
  %r548 = and i1 %r547, %r480
  %r549 = and i1 %r548, %r485
  %r550 = and i1 %r549, %r493
  %r551 = and i1 %r550, %r490
  %r552 = and i1 %r551, %r546
  %r553 = and i1 %r552, %r505
  br i1 %r553, label %put.pic.hit.121, label %put.pic.dispatch5.120

put.pic.fallback.117:                             ; preds = %put.pic.guard.113
  %r515 = icmp eq i64 %r503, 0
  br i1 %r515, label %put.pic.miss.125, label %put.pic.guard2.114

put.pic.dispatch3.118:                            ; preds = %put.pic.guard2.114
  %r528 = icmp eq i64 %r517, 0
  br i1 %r528, label %put.pic.miss2.126, label %put.pic.guard3.115

put.pic.dispatch4.119:                            ; preds = %put.pic.guard3.115
  %r541 = icmp eq i64 %r530, 0
  br i1 %r541, label %put.pic.miss3.127, label %put.pic.guard4.116

put.pic.dispatch5.120:                            ; preds = %put.pic.guard4.116
  %r554 = icmp eq i64 %r543, 0
  br i1 %r554, label %put.pic.miss4.128, label %put.pic.tail.129

put.pic.hit.121:                                  ; preds = %put.pic.guard4.116, %put.pic.guard3.115, %put.pic.guard2.114, %put.pic.guard.113
  %r555 = phi i64 [ %r507, %put.pic.guard.113 ], [ %r519, %put.pic.guard2.114 ], [ %r532, %put.pic.guard3.115 ], [ %r545, %put.pic.guard4.116 ]
  %r556 = and i64 %r555, 1073741824
  %r557 = icmp ne i64 %r556, 0
  br i1 %r557, label %put.pic.hit.overflow.131, label %put.pic.hit.inline.132

put.pic.hit.validate.122:                         ; preds = %put.pic.hit.inline.132
  %r567 = load double, ptr %r564, align 8
  %r568 = bitcast double %r567 to i64
  %r569 = icmp eq i64 %r568, 9222246136947933200
  br i1 %r569, label %put.pic.deleted.124, label %put.pic.hit.store.123

put.pic.hit.store.123:                            ; preds = %put.pic.hit.inline.132, %put.pic.hit.validate.122
  store double %r460, ptr %r564, align 8
  br label %put.pic.merge.130

put.pic.deleted.124:                              ; preds = %put.pic.hit.validate.122
  %statepoint_token67 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r448, i64 %r463, double %r460, i32 1, ptr @perry_ic_changing_options_worker_ts__3, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12) ]
  %r57068 = call double @llvm.experimental.gc.result.f64(token %statepoint_token67)
  %rs4gc.s3.relocated69 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token67, i32 0, i32 0) ; (%.12, %.12)
  br label %put.pic.merge.130

put.pic.miss.125:                                 ; preds = %put.pic.hit.overflow.131, %put.pic.fallback.117, %for.body.106
  %.13 = phi ptr addrspace(1) [ %rs4gc.s3.relocated90, %put.pic.hit.overflow.131 ], [ %.12, %put.pic.fallback.117 ], [ %.12, %for.body.106 ]
  %r774 = load double, ptr @changing_options_worker_ts_.str.1.handle, align 8
  %r775 = bitcast double %r774 to i64
  %r776 = and i64 %r775, 281474976710655
  %statepoint_token70 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r448, i64 %r776, double %r460, i32 1, ptr @perry_ic_changing_options_worker_ts__3, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %r57171 = call double @llvm.experimental.gc.result.f64(token %statepoint_token70)
  %rs4gc.s3.relocated72 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token70, i32 0, i32 0) ; (%.13, %.13)
  br label %put.pic.merge.130

put.pic.miss2.126:                                ; preds = %put.pic.dispatch3.118
  %statepoint_token73 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r448, i64 %r463, double %r460, i32 1, ptr @perry_ic_changing_options_worker_ts__3, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12) ]
  %r57274 = call double @llvm.experimental.gc.result.f64(token %statepoint_token73)
  %rs4gc.s3.relocated75 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 0, i32 0) ; (%.12, %.12)
  br label %put.pic.merge.130

put.pic.miss3.127:                                ; preds = %put.pic.dispatch4.119
  %statepoint_token76 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r448, i64 %r463, double %r460, i32 1, ptr @perry_ic_changing_options_worker_ts__3, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12) ]
  %r57377 = call double @llvm.experimental.gc.result.f64(token %statepoint_token76)
  %rs4gc.s3.relocated78 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token76, i32 0, i32 0) ; (%.12, %.12)
  br label %put.pic.merge.130

put.pic.miss4.128:                                ; preds = %put.pic.dispatch5.120
  %statepoint_token79 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r448, i64 %r463, double %r460, i32 1, ptr @perry_ic_changing_options_worker_ts__3, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12) ]
  %r57480 = call double @llvm.experimental.gc.result.f64(token %statepoint_token79)
  %rs4gc.s3.relocated81 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token79, i32 0, i32 0) ; (%.12, %.12)
  br label %put.pic.merge.130

put.pic.tail.129:                                 ; preds = %put.pic.dispatch5.120
  %statepoint_token82 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, i64, double, i32)) @js_put_value_set_ic_poly_tail, i32 5, i32 0, ptr @perry_ic_changing_options_worker_ts__3_poly_tail, double %r448, i64 %r463, double %r460, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12) ]
  %r57583 = call double @llvm.experimental.gc.result.f64(token %statepoint_token82)
  %rs4gc.s3.relocated84 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token82, i32 0, i32 0) ; (%.12, %.12)
  br label %put.pic.merge.130

put.pic.merge.130:                                ; preds = %put.pic.hit.overflow.131, %put.pic.tail.129, %put.pic.miss4.128, %put.pic.miss3.127, %put.pic.miss2.126, %put.pic.miss.125, %put.pic.deleted.124, %put.pic.hit.store.123
  %.15 = phi ptr addrspace(1) [ %rs4gc.s3.relocated90, %put.pic.hit.overflow.131 ], [ %rs4gc.s3.relocated72, %put.pic.miss.125 ], [ %rs4gc.s3.relocated69, %put.pic.deleted.124 ], [ %.12, %put.pic.hit.store.123 ], [ %rs4gc.s3.relocated75, %put.pic.miss2.126 ], [ %rs4gc.s3.relocated78, %put.pic.miss3.127 ], [ %rs4gc.s3.relocated81, %put.pic.miss4.128 ], [ %rs4gc.s3.relocated84, %put.pic.tail.129 ]
  %r576 = phi double [ %r460, %put.pic.hit.store.123 ], [ %r460, %put.pic.hit.overflow.131 ], [ %r57068, %put.pic.deleted.124 ], [ %r57171, %put.pic.miss.125 ], [ %r57274, %put.pic.miss2.126 ], [ %r57377, %put.pic.miss3.127 ], [ %r57480, %put.pic.miss4.128 ], [ %r57583, %put.pic.tail.129 ]
  %r578 = load double, ptr @perry_global_changing_options_worker_ts__5, align 8
  %r579 = load double, ptr @perry_global_changing_options_worker_ts__2, align 8
  %statepoint_token85 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r578, double 0x7FFC000000000002, double %r579, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.15) ]
  %r58086 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token85)
  %rs4gc.s3.relocated87 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 0, i32 0) ; (%.15, %.15)
  %r581 = bitcast i64 %r58086 to double
  %rs4gc.b6 = bitcast double %r581 to i64
  %rs4gc.s6 = inttoptr i64 %rs4gc.b6 to ptr addrspace(1)
  %r582.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r582 = call i64 asm "", "=r,0"(i64 %r582.rs4i) #8
  %r583 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r584 = icmp ne i32 %r583, 0
  br i1 %r584, label %shadow.root.barrier.133, label %shadow.root.barrier.done.134

put.pic.hit.overflow.131:                         ; preds = %put.pic.hit.121
  %r558 = trunc i64 %r555 to i32
  %statepoint_token88 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (double, i64, i32, double)) @js_put_value_set_ic_overflow_store, i32 4, i32 0, double %r448, i64 %r501, i32 %r558, double %r460, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12) ]
  %r55989 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token88)
  %rs4gc.s3.relocated90 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token88, i32 0, i32 0) ; (%.12, %.12)
  %r560 = icmp ne i32 %r55989, 0
  br i1 %r560, label %put.pic.merge.130, label %put.pic.miss.125

put.pic.hit.inline.132:                           ; preds = %put.pic.hit.121
  %r561 = shl i64 %r555, 3
  %r562 = add nuw nsw i64 %r464, 16
  %r563 = add i64 %r562, %r561
  %r564 = inttoptr i64 %r563 to ptr
  %r565 = and i16 %r483, 1024
  %r566 = icmp ne i16 %r565, 0
  br i1 %r566, label %put.pic.hit.validate.122, label %put.pic.hit.store.123

shadow.root.barrier.133:                          ; preds = %put.pic.merge.130
  call void @js_write_barrier_root_nanbox(i64 %r582) #8
  br label %shadow.root.barrier.done.134

shadow.root.barrier.done.134:                     ; preds = %shadow.root.barrier.133, %put.pic.merge.130
  %r586 = bitcast double %r2.3 to i64
  %rs4gc.s7 = inttoptr i64 %r586 to ptr addrspace(1)
  %r587.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r587 = call i64 asm "", "=r,0"(i64 %r587.rs4i) #8
  %r588 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r589 = icmp ne i32 %r588, 0
  br i1 %r589, label %shadow.root.barrier.135, label %shadow.root.barrier.done.136

shadow.root.barrier.135:                          ; preds = %shadow.root.barrier.done.134
  call void @js_write_barrier_root_nanbox(i64 %r587) #8
  br label %shadow.root.barrier.done.136

shadow.root.barrier.done.136:                     ; preds = %shadow.root.barrier.135, %shadow.root.barrier.done.134
  %r590.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r590.rs4o = call i64 asm "", "=r,0"(i64 %r590.rs4i) #8
  %r590 = bitcast i64 %r590.rs4o to double
  %r591 = bitcast double %r590 to i64
  %r592 = and i64 %r591, 281474976710655
  %r593 = lshr i64 %r591, 48
  %r594 = and i64 %r593, 65533
  %r595 = icmp eq i64 %r594, 32765
  br i1 %r595, label %pget.recv_ok.138, label %pget.recv_other.143

pget.recv_sso.137:                                ; preds = %pget.recv_other.143
  %r734 = lshr i64 %r591, 40
  %r735 = and i64 %r734, 255
  %r736 = uitofp nneg i64 %r735 to double
  br label %pget.recv_merge.141

pget.recv_ok.138:                                 ; preds = %shadow.root.barrier.done.136
  %r602 = icmp eq i64 %r593, 32767
  br i1 %r602, label %pget.strlen_heap.142, label %pget.recv_obj.145

pget.recv_bad.139:                                ; preds = %pget.check_class_ref.144
  %r726 = icmp eq i64 %r591, 9222246136947933185
  %r727 = icmp eq i64 %r591, 9222246136947933186
  %r728 = or i1 %r726, %r727
  br i1 %r728, label %pget.throw_nullish.168, label %pget.recv_undef_return.169

pget.recv_class_ref.140:                          ; preds = %pget.check_class_ref.144
  %r598 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r599 = bitcast double %r598 to i64
  %r600 = and i64 %r599, 281474976710655
  %statepoint_token91 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 1175166488852561924, i64 %r591, i64 %r600, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated87, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r60192 = call double @llvm.experimental.gc.result.f64(token %statepoint_token91)
  %rs4gc.s3.relocated93 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 0, i32 0) ; (%rs4gc.s3.relocated87, %rs4gc.s3.relocated87)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pget.recv_merge.141

pget.recv_merge.141:                              ; preds = %pget.recv_undef_return.169, %pic.merge.160, %pget.strlen_heap.142, %pget.recv_class_ref.140, %pget.recv_sso.137
  %.0124 = phi ptr addrspace(1) [ %rs4gc.s7, %pget.strlen_heap.142 ], [ %.1125, %pic.merge.160 ], [ %rs4gc.s7, %pget.recv_sso.137 ], [ %rs4gc.s7.relocated, %pget.recv_class_ref.140 ], [ %rs4gc.s7.relocated109, %pget.recv_undef_return.169 ]
  %.0121 = phi ptr addrspace(1) [ %rs4gc.s6, %pget.strlen_heap.142 ], [ %.1122, %pic.merge.160 ], [ %rs4gc.s6, %pget.recv_sso.137 ], [ %rs4gc.s6.relocated, %pget.recv_class_ref.140 ], [ %rs4gc.s6.relocated108, %pget.recv_undef_return.169 ]
  %.16 = phi ptr addrspace(1) [ %rs4gc.s3.relocated87, %pget.strlen_heap.142 ], [ %.17, %pic.merge.160 ], [ %rs4gc.s3.relocated87, %pget.recv_sso.137 ], [ %rs4gc.s3.relocated93, %pget.recv_class_ref.140 ], [ %rs4gc.s3.relocated107, %pget.recv_undef_return.169 ]
  %r742 = phi double [ %r725, %pic.merge.160 ], [ %r733106, %pget.recv_undef_return.169 ], [ %r736, %pget.recv_sso.137 ], [ %r60192, %pget.recv_class_ref.140 ], [ %r741, %pget.strlen_heap.142 ]
  %r743.rs4i = ptrtoint ptr addrspace(1) %.0124 to i64
  %r743 = call i64 asm "", "=r,0"(i64 %r743.rs4i) #8
  %r744 = bitcast i64 %r743 to double
  %r745 = and i64 %r743, -281474976710656
  %r746 = icmp ult i64 %r745, 9221401712017801216
  %r747 = icmp ugt i64 %r745, 9223090561878065152
  %r748 = or i1 %r746, %r747
  %r749 = bitcast double %r742 to i64
  %r750 = and i64 %r749, -281474976710656
  %r751 = icmp ult i64 %r750, 9221401712017801216
  %r752 = icmp ugt i64 %r750, 9223090561878065152
  %r753 = or i1 %r751, %r752
  %r754 = and i1 %r748, %r753
  br i1 %r754, label %guarded_add.numeric.170, label %guarded_add.dynamic.171

pget.strlen_heap.142:                             ; preds = %pget.recv_ok.138
  %r737 = icmp ult i64 %r592, 4096
  %r738 = inttoptr i64 %r592 to ptr
  %r739 = select i1 %r737, ptr @perry_null_guard_zero_changing_options_worker_ts, ptr %r738
  %r740 = load i32, ptr %r739, align 4
  %r741 = uitofp i32 %r740 to double
  br label %pget.recv_merge.141

pget.recv_other.143:                              ; preds = %shadow.root.barrier.done.136
  %r596 = icmp eq i64 %r593, 32761
  br i1 %r596, label %pget.recv_sso.137, label %pget.check_class_ref.144

pget.check_class_ref.144:                         ; preds = %pget.recv_other.143
  %r597 = icmp eq i64 %r593, 32766
  br i1 %r597, label %pget.recv_class_ref.140, label %pget.recv_bad.139

pget.recv_obj.145:                                ; preds = %pget.recv_ok.138
  %r603 = icmp ugt i64 %r592, 1048575
  br i1 %r603, label %pic.recv_hdr.161, label %pic.miss.cold.158

pic.hit.146:                                      ; preds = %pic.token.162
  %r628 = getelementptr i64, ptr %r613, i64 1
  %r629 = load i64, ptr %r628, align 8
  %r630 = and i64 %r629, 1073741824
  %r631 = icmp ne i64 %r630, 0
  br i1 %r631, label %pic.hit.overflow.163, label %pic.hit.inline.164

pic.hit.live.147:                                 ; preds = %pic.hit.inline.164
  br label %pic.merge.160

pic.prefix.guard.148:                             ; preds = %pic.token.162
  %r644 = getelementptr i64, ptr %r613, i64 2
  %r645 = load i64, ptr %r644, align 8
  %r646 = icmp ne i64 %r645, 0
  br i1 %r646, label %pic.prefix.meta.149, label %pic.miss.157

pic.prefix.meta.149:                              ; preds = %pic.prefix.guard.148
  %r647 = add nuw nsw i64 %r592, 8
  %r648 = inttoptr i64 %r647 to ptr
  %r649 = load i64, ptr %r648, align 8
  %r650 = icmp ne i64 %r649, 0
  br i1 %r650, label %pic.prefix.token.150, label %pic.miss.157

pic.prefix.token.150:                             ; preds = %pic.prefix.meta.149
  %r651 = inttoptr i64 %r649 to ptr
  %r652 = getelementptr i64, ptr %r651, i64 6
  %r653 = load i64, ptr %r652, align 8
  %r654 = icmp eq i64 %r653, %r645
  br i1 %r654, label %pic.prefix.hit.151, label %pic.miss.157

pic.prefix.hit.151:                               ; preds = %pic.prefix.token.150
  %r655 = getelementptr i64, ptr %r613, i64 1
  %r656 = load i64, ptr %r655, align 8
  %r657 = shl i64 %r656, 3
  %r658 = add nuw nsw i64 %r592, 16
  %r659 = add i64 %r658, %r657
  %r660 = inttoptr i64 %r659 to ptr
  %r661 = load double, ptr %r660, align 8
  br label %pic.merge.160

pic.desc.classify.152:                            ; preds = %pic.recv_hdr.161
  %r617 = and i1 %r607, %r614
  br i1 %r617, label %pic.desc.prefix.guard.153, label %pic.miss.cold.158

pic.desc.prefix.guard.153:                        ; preds = %pic.desc.classify.152
  %r662 = getelementptr i64, ptr %r613, i64 2
  %r663 = load i64, ptr %r662, align 8
  %r664 = icmp ne i64 %r663, 0
  br i1 %r664, label %pic.desc.prefix.meta.154, label %pic.miss.cold.158

pic.desc.prefix.meta.154:                         ; preds = %pic.desc.prefix.guard.153
  %r665 = add nuw nsw i64 %r592, 8
  %r666 = inttoptr i64 %r665 to ptr
  %r667 = load i64, ptr %r666, align 8
  %r668 = icmp ne i64 %r667, 0
  br i1 %r668, label %pic.desc.prefix.token.155, label %pic.miss.cold.158

pic.desc.prefix.token.155:                        ; preds = %pic.desc.prefix.meta.154
  %r669 = inttoptr i64 %r667 to ptr
  %r670 = getelementptr i64, ptr %r669, i64 6
  %r671 = load i64, ptr %r670, align 8
  %r672 = icmp eq i64 %r671, %r663
  br i1 %r672, label %pic.desc.prefix.hit.156, label %pic.miss.cold.158

pic.desc.prefix.hit.156:                          ; preds = %pic.desc.prefix.token.155
  %r673 = getelementptr i64, ptr %r613, i64 1
  %r674 = load i64, ptr %r673, align 8
  %r675 = shl i64 %r674, 3
  %r676 = add nuw nsw i64 %r592, 16
  %r677 = add i64 %r676, %r675
  %r678 = inttoptr i64 %r677 to ptr
  %r679 = load double, ptr %r678, align 8
  br label %pic.merge.160

pic.miss.157:                                     ; preds = %pic.hit.inline.164, %pic.prefix.token.150, %pic.prefix.meta.149, %pic.prefix.guard.148
  %r680 = getelementptr i64, ptr %r613, i64 3
  %r681 = load i64, ptr %r680, align 8
  %r682 = icmp sgt i64 %r681, 0
  br i1 %r682, label %pic.ways.165, label %pic.miss.call.159

pic.miss.cold.158:                                ; preds = %pic.desc.prefix.token.155, %pic.desc.prefix.meta.154, %pic.desc.prefix.guard.153, %pic.desc.classify.152, %pget.recv_obj.145
  br label %pic.miss.call.159

pic.miss.call.159:                                ; preds = %pic.way.load.166, %pic.ways.165, %pic.miss.cold.158, %pic.miss.157
  %r721 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r722 = bitcast double %r721 to i64
  %r723 = and i64 %r722, 281474976710655
  %statepoint_token94 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r592, i64 %r723, ptr @perry_ic_changing_options_worker_ts__5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated87, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r72495 = call double @llvm.experimental.gc.result.f64(token %statepoint_token94)
  %rs4gc.s3.relocated96 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 0, i32 0) ; (%rs4gc.s3.relocated87, %rs4gc.s3.relocated87)
  %rs4gc.s6.relocated97 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated98 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pic.merge.160

pic.merge.160:                                    ; preds = %pic.way.live.167, %pic.hit.overflow.163, %pic.miss.call.159, %pic.desc.prefix.hit.156, %pic.prefix.hit.151, %pic.hit.live.147
  %.1125 = phi ptr addrspace(1) [ %rs4gc.s7.relocated103, %pic.hit.overflow.163 ], [ %rs4gc.s7.relocated98, %pic.miss.call.159 ], [ %rs4gc.s7, %pic.way.live.167 ], [ %rs4gc.s7, %pic.hit.live.147 ], [ %rs4gc.s7, %pic.prefix.hit.151 ], [ %rs4gc.s7, %pic.desc.prefix.hit.156 ]
  %.1122 = phi ptr addrspace(1) [ %rs4gc.s6.relocated102, %pic.hit.overflow.163 ], [ %rs4gc.s6.relocated97, %pic.miss.call.159 ], [ %rs4gc.s6, %pic.way.live.167 ], [ %rs4gc.s6, %pic.hit.live.147 ], [ %rs4gc.s6, %pic.prefix.hit.151 ], [ %rs4gc.s6, %pic.desc.prefix.hit.156 ]
  %.17 = phi ptr addrspace(1) [ %rs4gc.s3.relocated101, %pic.hit.overflow.163 ], [ %rs4gc.s3.relocated96, %pic.miss.call.159 ], [ %rs4gc.s3.relocated87, %pic.way.live.167 ], [ %rs4gc.s3.relocated87, %pic.hit.live.147 ], [ %rs4gc.s3.relocated87, %pic.prefix.hit.151 ], [ %rs4gc.s3.relocated87, %pic.desc.prefix.hit.156 ]
  %r725 = phi double [ %r641, %pic.hit.live.147 ], [ %r636100, %pic.hit.overflow.163 ], [ %r661, %pic.prefix.hit.151 ], [ %r679, %pic.desc.prefix.hit.156 ], [ %r718, %pic.way.live.167 ], [ %r72495, %pic.miss.call.159 ]
  br label %pget.recv_merge.141

pic.recv_hdr.161:                                 ; preds = %pget.recv_obj.145
  %r604 = sub nuw nsw i64 %r592, 8
  %r605 = inttoptr i64 %r604 to ptr
  %r606 = load i8, ptr %r605, align 1
  %r607 = icmp eq i8 %r606, 2
  %r608 = sub nuw nsw i64 %r592, 6
  %r609 = inttoptr i64 %r608 to ptr
  %r610 = load i16, ptr %r609, align 2
  %r611 = and i16 %r610, 2048
  %r612 = icmp eq i16 %r611, 0
  %r613 = load ptr, ptr @perry_ic_changing_options_worker_ts__5, align 8
  %r614 = icmp ne ptr %r613, null
  %r615 = and i1 %r607, %r612
  %r616 = and i1 %r615, %r614
  br i1 %r616, label %pic.token.162, label %pic.desc.classify.152

pic.token.162:                                    ; preds = %pic.recv_hdr.161
  %r618 = add nuw nsw i64 %r592, 4
  %r619 = inttoptr i64 %r618 to ptr
  %r620 = load i32, ptr %r619, align 4
  %r621 = zext i32 %r620 to i64
  %r622 = or i64 %r621, 4611686018427387904
  %r623 = icmp ne i32 %r620, 0
  %r624 = getelementptr i64, ptr %r613, i64 0
  %r625 = load i64, ptr %r624, align 8
  %r626 = icmp eq i64 %r622, %r625
  %r627 = and i1 %r626, %r623
  br i1 %r627, label %pic.hit.146, label %pic.prefix.guard.148

pic.hit.overflow.163:                             ; preds = %pic.hit.146
  %r632 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r633 = bitcast double %r632 to i64
  %r634 = and i64 %r633, 281474976710655
  %r635 = trunc i64 %r629 to i32
  %statepoint_token99 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r592, i64 %r634, i32 %r635, ptr @perry_ic_changing_options_worker_ts__5, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated87, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r636100 = call double @llvm.experimental.gc.result.f64(token %statepoint_token99)
  %rs4gc.s3.relocated101 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 0, i32 0) ; (%rs4gc.s3.relocated87, %rs4gc.s3.relocated87)
  %rs4gc.s6.relocated102 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token99, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pic.merge.160

pic.hit.inline.164:                               ; preds = %pic.hit.146
  %r637 = shl i64 %r629, 3
  %r638 = add nuw nsw i64 %r592, 16
  %r639 = add i64 %r638, %r637
  %r640 = inttoptr i64 %r639 to ptr
  %r641 = load double, ptr %r640, align 8
  %r642 = bitcast double %r641 to i64
  %r643 = icmp eq i64 %r642, 9222246136947933200
  br i1 %r643, label %pic.miss.157, label %pic.hit.live.147

pic.ways.165:                                     ; preds = %pic.miss.157
  %r683 = getelementptr i64, ptr %r613, i64 4
  %r684 = load i64, ptr %r683, align 8
  %r685 = icmp eq i64 %r684, %r622
  %r686 = getelementptr i64, ptr %r613, i64 5
  %r687 = load i64, ptr %r686, align 8
  %r688 = select i1 %r685, i64 %r687, i64 0
  %r689 = getelementptr i64, ptr %r613, i64 6
  %r690 = load i64, ptr %r689, align 8
  %r691 = icmp eq i64 %r690, %r622
  %r692 = getelementptr i64, ptr %r613, i64 7
  %r693 = load i64, ptr %r692, align 8
  %r694 = select i1 %r691, i64 %r693, i64 0
  %r695 = getelementptr i64, ptr %r613, i64 8
  %r696 = load i64, ptr %r695, align 8
  %r697 = icmp eq i64 %r696, %r622
  %r698 = getelementptr i64, ptr %r613, i64 9
  %r699 = load i64, ptr %r698, align 8
  %r700 = select i1 %r697, i64 %r699, i64 0
  %r701 = getelementptr i64, ptr %r613, i64 10
  %r702 = load i64, ptr %r701, align 8
  %r703 = icmp eq i64 %r702, %r622
  %r704 = getelementptr i64, ptr %r613, i64 11
  %r705 = load i64, ptr %r704, align 8
  %r706 = select i1 %r703, i64 %r705, i64 0
  %r707 = or i1 %r685, %r691
  %r708 = select i1 %r685, i64 %r688, i64 %r694
  %r709 = or i1 %r697, %r703
  %r710 = select i1 %r697, i64 %r700, i64 %r706
  %r711 = or i1 %r707, %r709
  %r712 = select i1 %r707, i64 %r708, i64 %r710
  %r713 = and i1 %r623, %r711
  br i1 %r713, label %pic.way.load.166, label %pic.miss.call.159

pic.way.load.166:                                 ; preds = %pic.ways.165
  %r714 = shl i64 %r712, 3
  %r715 = add nuw nsw i64 %r592, 16
  %r716 = add i64 %r715, %r714
  %r717 = inttoptr i64 %r716 to ptr
  %r718 = load double, ptr %r717, align 8
  %r719 = bitcast double %r718 to i64
  %r720 = icmp eq i64 %r719, 9222246136947933200
  br i1 %r720, label %pic.miss.call.159, label %pic.way.live.167

pic.way.live.167:                                 ; preds = %pic.way.load.166
  br label %pic.merge.160

pget.throw_nullish.168:                           ; preds = %pget.recv_bad.139
  %r729 = zext i1 %r727 to i32
  %statepoint_token104 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r729, ptr @changing_options_worker_ts_.str.2.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.169:                       ; preds = %pget.recv_bad.139
  %r730 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r731 = bitcast double %r730 to i64
  %r732 = and i64 %r731, 281474976710655
  %statepoint_token105 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r591, i64 %r732, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated87, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r733106 = call double @llvm.experimental.gc.result.f64(token %statepoint_token105)
  %rs4gc.s3.relocated107 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 0, i32 0) ; (%rs4gc.s3.relocated87, %rs4gc.s3.relocated87)
  %rs4gc.s6.relocated108 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated109 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pget.recv_merge.141

guarded_add.numeric.170:                          ; preds = %pget.recv_merge.141
  %r755 = fadd double %r744, %r742
  br label %guarded_add.merge.172

guarded_add.dynamic.171:                          ; preds = %pget.recv_merge.141
  %statepoint_token110 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r744, double %r742, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.16, ptr addrspace(1) %.0121) ]
  %r756111 = call double @llvm.experimental.gc.result.f64(token %statepoint_token110)
  %rs4gc.s3.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 0, i32 0) ; (%.16, %.16)
  %rs4gc.s6.relocated113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 1, i32 1) ; (%.0121, %.0121)
  br label %guarded_add.merge.172

guarded_add.merge.172:                            ; preds = %guarded_add.dynamic.171, %guarded_add.numeric.170
  %.2123 = phi ptr addrspace(1) [ %.0121, %guarded_add.numeric.170 ], [ %rs4gc.s6.relocated113, %guarded_add.dynamic.171 ]
  %.18 = phi ptr addrspace(1) [ %.16, %guarded_add.numeric.170 ], [ %rs4gc.s3.relocated112, %guarded_add.dynamic.171 ]
  %r757 = phi double [ %r755, %guarded_add.numeric.170 ], [ %r756111, %guarded_add.dynamic.171 ]
  %r758.rs4i = ptrtoint ptr addrspace(1) %.2123 to i64
  %r758.rs4o = call i64 asm "", "=r,0"(i64 %r758.rs4i) #8
  %r758 = bitcast i64 %r758.rs4o to double
  %r759 = bitcast double %r758 to i64
  %r760 = and i64 %r759, -281474976710656
  %r761 = icmp ne i64 %r760, 9223090561878065152
  br i1 %r761, label %str_addref.done.174, label %str_addref.call.173

str_addref.call.173:                              ; preds = %guarded_add.merge.172
  call void @js_string_addref_if_heap_string(double %r758) #8
  br label %str_addref.done.174

str_addref.done.174:                              ; preds = %str_addref.call.173, %guarded_add.merge.172
  %r773.rs4i = ptrtoint ptr addrspace(1) %.2123 to i64
  %r773.rs4o = call i64 asm "", "=r,0"(i64 %r773.rs4i) #8
  %r773 = bitcast i64 %r773.rs4o to double
  store double %r773, ptr @perry_global_changing_options_worker_ts__6, align 8
  %r772.rs4i = ptrtoint ptr addrspace(1) %.2123 to i64
  %r772.rs4o = call i64 asm "", "=r,0"(i64 %r772.rs4i) #8
  %r772 = bitcast i64 %r772.rs4o to double
  %r762 = bitcast double %r772 to i64
  %r770.rs4i = ptrtoint ptr addrspace(1) %.2123 to i64
  %r770.rs4o = call i64 asm "", "=r,0"(i64 %r770.rs4i) #8
  %r770 = bitcast i64 %r770.rs4o to double
  %r771 = bitcast double %r770 to i64
  call void @js_write_barrier_root_nanbox(i64 %r771) #8
  %r763 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r764 = icmp ne i32 %r763, 0
  br i1 %r764, label %gcpoll.175, label %gcpoll.done.176

gcpoll.175:                                       ; preds = %str_addref.done.174
  %statepoint_token114 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.18) ]
  %rs4gc.s3.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token114, i32 0, i32 0) ; (%.18, %.18)
  br label %gcpoll.done.176

gcpoll.done.176:                                  ; preds = %gcpoll.175, %str_addref.done.174
  %.19 = phi ptr addrspace(1) [ %rs4gc.s3.relocated115, %gcpoll.175 ], [ %.18, %str_addref.done.174 ]
  br label %for.update.107
}

; Function Attrs: optsize
define internal double @"perry_fn_changing_options_worker_ts__run$generic"(double %arg13) #6 gc "statepoint-example" {
entry.0:
  %rs4gc.b3 = bitcast double %arg13 to i64
  %rs4gc.s3 = inttoptr i64 %rs4gc.b3 to ptr addrspace(1)
  %r3 = load double, ptr @perry_global_changing_options_worker_ts__1, align 8
  %r4 = load double, ptr @changing_options_worker_ts_.str.0.handle, align 8
  %r5 = bitcast double %r3 to i64
  %r6 = bitcast double %r4 to i64
  %r7 = icmp eq i64 %r5, %r6
  br i1 %r7, label %streqlit.true.6, label %streqlit.tag.1

streqlit.tag.1:                                   ; preds = %entry.0
  %r8 = lshr i64 %r5, 48
  %r9 = icmp eq i64 %r8, 32767
  %r10 = and i64 %r5, 281474976710655
  %r11 = icmp ugt i64 %r10, 4095
  %r12 = and i1 %r9, %r11
  br i1 %r12, label %streqlit.len.2, label %streqlit.false.7

streqlit.len.2:                                   ; preds = %streqlit.tag.1
  %r13 = inttoptr i64 %r10 to ptr
  %r14 = getelementptr inbounds nuw i8, ptr %r13, i64 4
  %r15 = load i32, ptr %r14, align 4
  %r16 = icmp eq i32 %r15, 14
  br i1 %r16, label %streqlit.b0.3, label %streqlit.false.7

streqlit.b0.3:                                    ; preds = %streqlit.len.2
  %r17 = getelementptr inbounds nuw i8, ptr %r13, i64 20
  %r18 = load i8, ptr %r17, align 1
  %r19 = icmp eq i8 %r18, 99
  br i1 %r19, label %streqlit.bl.4, label %streqlit.false.7

streqlit.bl.4:                                    ; preds = %streqlit.b0.3
  %r20 = getelementptr inbounds nuw i8, ptr %r13, i64 33
  %r21 = load i8, ptr %r20, align 1
  %r22 = icmp eq i8 %r21, 110
  br i1 %r22, label %streqlit.slow.5, label %streqlit.false.7

streqlit.slow.5:                                  ; preds = %streqlit.bl.4
  %r23 = and i64 %r6, 281474976710655
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r10, i64 %r23, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3) ]
  %r2410 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token)
  %rs4gc.s3.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token, i32 0, i32 0) ; (%rs4gc.s3, %rs4gc.s3)
  %r25 = icmp ne i32 %r2410, 0
  br label %streqlit.merge.8

streqlit.true.6:                                  ; preds = %entry.0
  br label %streqlit.merge.8

streqlit.false.7:                                 ; preds = %streqlit.bl.4, %streqlit.b0.3, %streqlit.len.2, %streqlit.tag.1
  br label %streqlit.merge.8

streqlit.merge.8:                                 ; preds = %streqlit.false.7, %streqlit.true.6, %streqlit.slow.5
  %.0 = phi ptr addrspace(1) [ %rs4gc.s3, %streqlit.true.6 ], [ %rs4gc.s3.relocated, %streqlit.slow.5 ], [ %rs4gc.s3, %streqlit.false.7 ]
  %r26 = phi i1 [ true, %streqlit.true.6 ], [ false, %streqlit.false.7 ], [ %r25, %streqlit.slow.5 ]
  %r27 = select i1 %r26, i64 9222246136947933188, i64 9222246136947933187
  %r28 = bitcast i64 %r27 to double
  %r29 = icmp eq i64 %r27, 9222246136947933188
  br i1 %r29, label %if.then.9, label %if.else.10

if.then.9:                                        ; preds = %streqlit.merge.8
  %r34.rs4i = ptrtoint ptr addrspace(1) %.0 to i64
  %r34.rs4o = call i64 asm "", "=r,0"(i64 %r34.rs4i) #8
  %r34 = bitcast i64 %r34.rs4o to double
  %r35 = bitcast double %r34 to i64
  %r36 = and i64 %r35, -281474976710656
  %r37 = icmp ult i64 %r36, 9221401712017801216
  %r38 = icmp ugt i64 %r36, 9223090561878065152
  %r39 = or i1 %r37, %r38
  br i1 %r39, label %for.bound_i32.number.12, label %for.bound_i32.merge.14

if.else.10:                                       ; preds = %streqlit.merge.8
  %r415 = load double, ptr @perry_global_changing_options_worker_ts__1, align 8
  %r416 = load double, ptr @changing_options_worker_ts_.str.3.handle, align 8
  %r417 = bitcast double %r415 to i64
  %r418 = bitcast double %r416 to i64
  %r419 = icmp eq i64 %r417, %r418
  br i1 %r419, label %streqlit.true.97, label %streqlit.tag.92

if.merge.11:                                      ; preds = %if.merge.102, %for.exit.20
  %r2.0 = phi double [ %r2.1, %for.exit.20 ], [ %r2.2, %if.merge.102 ]
  ret double %r2.0

for.bound_i32.number.12:                          ; preds = %if.then.9
  %r40 = fcmp oge double %r34, 0xC1E0000000000000
  %r41 = fcmp ole double %r34, 0x41DFFFFFFFC00000
  %r42 = and i1 %r40, %r41
  br i1 %r42, label %for.bound_i32.convert.13, label %for.bound_i32.merge.14

for.bound_i32.convert.13:                         ; preds = %for.bound_i32.number.12
  %r43 = fptosi double %r34 to i32
  %r44 = sitofp i32 %r43 to double
  %r45 = fcmp oeq double %r44, %r34
  br i1 %r45, label %for.counter_i32.range.15, label %for.bound_i32.merge.14

for.bound_i32.merge.14:                           ; preds = %for.counter_i32.convert.16, %for.bound_i32.convert.13, %for.bound_i32.number.12, %if.then.9
  %r33.0 = phi i32 [ %r43, %for.counter_i32.convert.16 ], [ 0, %if.then.9 ], [ %r43, %for.bound_i32.convert.13 ], [ 0, %for.bound_i32.number.12 ]
  %r32.0 = phi i1 [ true, %for.counter_i32.convert.16 ], [ false, %if.then.9 ], [ false, %for.bound_i32.convert.13 ], [ false, %for.bound_i32.number.12 ]
  br label %for.cond.17

for.counter_i32.range.15:                         ; preds = %for.bound_i32.convert.13
  br label %for.counter_i32.convert.16

for.counter_i32.convert.16:                       ; preds = %for.counter_i32.range.15
  br label %for.bound_i32.merge.14

for.cond.17:                                      ; preds = %for.update.19, %for.bound_i32.merge.14
  %.1 = phi ptr addrspace(1) [ %.0, %for.bound_i32.merge.14 ], [ %.10, %for.update.19 ]
  %r31.1 = phi i32 [ 0, %for.bound_i32.merge.14 ], [ %r414, %for.update.19 ]
  %r30.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.14 ], [ %r412, %for.update.19 ]
  %r2.1 = phi double [ 0.000000e+00, %for.bound_i32.merge.14 ], [ %r403, %for.update.19 ]
  br i1 %r32.0, label %for.cond.fast.21, label %for.cond.slow.22

for.body.18:                                      ; preds = %gcpoll.done.27, %for.cond.fast.21
  %.2 = phi ptr addrspace(1) [ %.1, %for.cond.fast.21 ], [ %.5, %gcpoll.done.27 ]
  %r94 = load double, ptr @perry_global_changing_options_worker_ts__5, align 8
  %r95 = load double, ptr @changing_options_worker_ts_.str.1.handle, align 8
  %r97 = fptosi double %r30.0 to i64
  %r99 = srem i64 %r97, 2
  %r100 = sitofp i64 %r99 to double
  %r101 = icmp eq i64 %r99, 0
  %r102 = fcmp olt double %r30.0, 0.000000e+00
  %r103 = and i1 %r101, %r102
  %r104 = fneg double %r100
  %r105 = select i1 %r103, double %r104, double %r100
  %r106 = fadd double 4.200000e+01, %r105
  %r107 = bitcast double %r94 to i64
  %r108 = bitcast double %r95 to i64
  %r109 = and i64 %r108, 281474976710655
  %r110 = and i64 %r107, 281474976710655
  %r111 = load ptr, ptr @perry_ic_changing_options_worker_ts__6, align 8
  %r112 = icmp ne ptr %r111, null
  %r113 = lshr i64 %r107, 48
  %r114 = icmp eq i64 %r113, 32765
  %r115 = icmp ugt i64 %r110, 1048575
  %r116 = and i1 %r114, %r115
  %r117 = and i1 %r116, %r112
  br i1 %r117, label %put.pic.guard.28, label %put.pic.miss.40

for.update.19:                                    ; preds = %gcpoll.done.91
  %r412 = fadd double %r30.0, 1.000000e+00
  %r414 = add i32 %r31.1, 1
  br label %for.cond.17

for.exit.20:                                      ; preds = %gcpoll.done.27, %for.cond.fast.21
  br label %if.merge.11

for.cond.fast.21:                                 ; preds = %for.cond.17
  %r56 = icmp slt i32 %r31.1, %r33.0
  br i1 %r56, label %for.body.18, label %for.exit.20

for.cond.slow.22:                                 ; preds = %for.cond.17
  %r58.rs4i = ptrtoint ptr addrspace(1) %.1 to i64
  %r58.rs4o = call i64 asm "", "=r,0"(i64 %r58.rs4i) #8
  %r58 = bitcast i64 %r58.rs4o to double
  %r59 = bitcast double %r58 to i64
  %r60 = lshr i64 %r59, 48
  %r61 = icmp ult i64 %r60, 32761
  %r62 = icmp ugt i64 %r60, 32767
  %r63 = or i1 %r61, %r62
  %r64 = icmp eq i64 %r60, 32766
  %r65 = icmp eq i64 %r59, 9222246136947933185
  %r66 = icmp eq i64 %r59, 9222246136947933186
  %r67 = icmp eq i64 %r59, 9222246136947933187
  %r68 = icmp eq i64 %r59, 9222246136947933188
  %r69 = or i1 %r66, %r67
  %r70 = or i1 %r63, %r64
  %r71 = or i1 %r70, %r65
  %r72 = or i1 %r71, %r69
  %r73 = or i1 %r72, %r68
  br i1 %r73, label %relnum.fast.23, label %relnum.slow.24

relnum.fast.23:                                   ; preds = %for.cond.slow.22
  %r74 = trunc i64 %r59 to i32
  %r75 = sitofp i32 %r74 to double
  %r76 = select i1 %r64, double %r75, double %r58
  %r77 = select i1 %r69, double 0.000000e+00, double %r76
  %r78 = select i1 %r68, double 1.000000e+00, double %r77
  %r79 = bitcast double %r30.0 to i64
  %r80 = lshr i64 %r79, 48
  %r81 = icmp eq i64 %r80, 32766
  %r82 = trunc i64 %r79 to i32
  %r83 = sitofp i32 %r82 to double
  %r84 = select i1 %r81, double %r83, double %r30.0
  %r85 = fcmp olt double %r84, %r78
  %r86 = select i1 %r85, i64 9222246136947933188, i64 9222246136947933187
  %r87 = bitcast i64 %r86 to double
  br label %relnum.merge.25

relnum.slow.24:                                   ; preds = %for.cond.slow.22
  %statepoint_token11 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r30.0, double %r58, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1) ]
  %r8812 = call double @llvm.experimental.gc.result.f64(token %statepoint_token11)
  %rs4gc.s3.relocated13 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token11, i32 0, i32 0) ; (%.1, %.1)
  br label %relnum.merge.25

relnum.merge.25:                                  ; preds = %relnum.slow.24, %relnum.fast.23
  %.4 = phi ptr addrspace(1) [ %.1, %relnum.fast.23 ], [ %rs4gc.s3.relocated13, %relnum.slow.24 ]
  %r89 = phi double [ %r87, %relnum.fast.23 ], [ %r8812, %relnum.slow.24 ]
  %r90 = bitcast double %r89 to i64
  %r92 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r93 = icmp ne i32 %r92, 0
  br i1 %r93, label %gcpoll.26, label %gcpoll.done.27

gcpoll.26:                                        ; preds = %relnum.merge.25
  %statepoint_token14 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.4) ]
  %rs4gc.s3.relocated15 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token14, i32 0, i32 0) ; (%.4, %.4)
  br label %gcpoll.done.27

gcpoll.done.27:                                   ; preds = %gcpoll.26, %relnum.merge.25
  %.5 = phi ptr addrspace(1) [ %rs4gc.s3.relocated15, %gcpoll.26 ], [ %.4, %relnum.merge.25 ]
  %r91 = icmp eq i64 %r90, 9222246136947933188
  br i1 %r91, label %for.body.18, label %for.exit.20

put.pic.guard.28:                                 ; preds = %for.body.18
  %r118 = sub nuw nsw i64 %r110, 8
  %r119 = inttoptr i64 %r118 to ptr
  %r120 = load i8, ptr %r119, align 1
  %r121 = icmp eq i8 %r120, 2
  %r122 = sub nuw nsw i64 %r110, 7
  %r123 = inttoptr i64 %r122 to ptr
  %r124 = load i8, ptr %r123, align 1
  %r125 = and i8 %r124, -128
  %r126 = icmp eq i8 %r125, 0
  %r127 = sub nuw nsw i64 %r110, 6
  %r128 = inttoptr i64 %r127 to ptr
  %r129 = load i16, ptr %r128, align 2
  %r130 = and i16 %r129, 6535
  %r131 = icmp eq i16 %r130, 0
  %r132 = add nuw nsw i64 %r110, 0
  %r133 = inttoptr i64 %r132 to ptr
  %r134 = load i32, ptr %r133, align 4
  %r135 = icmp ne i32 %r134, 0
  %r136 = icmp ne i32 %r134, -2
  %r137 = and i16 %r129, 512
  %r138 = icmp ne i16 %r137, 0
  %r139 = or i1 %r135, %r138
  %r140 = add nuw nsw i64 %r110, 4
  %r141 = inttoptr i64 %r140 to ptr
  %r142 = load i32, ptr %r141, align 4
  %r143 = add i32 %r142, -2147483648
  %r144 = icmp ult i32 %r143, 1073741824
  %r145 = zext i32 %r142 to i64
  %r146 = or i64 %r145, 4611686018427387904
  %r147 = select i1 %r144, i64 %r146, i64 0
  %r148 = getelementptr i64, ptr %r111, i64 0
  %r149 = load i64, ptr %r148, align 8
  %r150 = icmp eq i64 %r147, %r149
  %r151 = icmp ne i64 %r147, 0
  %r152 = getelementptr i64, ptr %r111, i64 1
  %r153 = load i64, ptr %r152, align 8
  %r154 = and i1 true, %r121
  %r155 = and i1 %r154, %r126
  %r156 = and i1 %r155, %r131
  %r157 = and i1 %r156, %r139
  %r158 = and i1 %r157, %r136
  %r159 = and i1 %r158, %r150
  %r160 = and i1 %r159, %r151
  br i1 %r160, label %put.pic.hit.36, label %put.pic.fallback.32

put.pic.guard2.29:                                ; preds = %put.pic.fallback.32
  %r162 = getelementptr i64, ptr %r111, i64 2
  %r163 = load i64, ptr %r162, align 8
  %r164 = getelementptr i64, ptr %r111, i64 3
  %r165 = load i64, ptr %r164, align 8
  %r166 = icmp eq i64 %r147, %r163
  %r167 = and i1 true, %r121
  %r168 = and i1 %r167, %r126
  %r169 = and i1 %r168, %r131
  %r170 = and i1 %r169, %r139
  %r171 = and i1 %r170, %r136
  %r172 = and i1 %r171, %r166
  %r173 = and i1 %r172, %r151
  br i1 %r173, label %put.pic.hit.36, label %put.pic.dispatch3.33

put.pic.guard3.30:                                ; preds = %put.pic.dispatch3.33
  %r175 = getelementptr i64, ptr %r111, i64 4
  %r176 = load i64, ptr %r175, align 8
  %r177 = getelementptr i64, ptr %r111, i64 5
  %r178 = load i64, ptr %r177, align 8
  %r179 = icmp eq i64 %r147, %r176
  %r180 = and i1 true, %r121
  %r181 = and i1 %r180, %r126
  %r182 = and i1 %r181, %r131
  %r183 = and i1 %r182, %r139
  %r184 = and i1 %r183, %r136
  %r185 = and i1 %r184, %r179
  %r186 = and i1 %r185, %r151
  br i1 %r186, label %put.pic.hit.36, label %put.pic.dispatch4.34

put.pic.guard4.31:                                ; preds = %put.pic.dispatch4.34
  %r188 = getelementptr i64, ptr %r111, i64 6
  %r189 = load i64, ptr %r188, align 8
  %r190 = getelementptr i64, ptr %r111, i64 7
  %r191 = load i64, ptr %r190, align 8
  %r192 = icmp eq i64 %r147, %r189
  %r193 = and i1 true, %r121
  %r194 = and i1 %r193, %r126
  %r195 = and i1 %r194, %r131
  %r196 = and i1 %r195, %r139
  %r197 = and i1 %r196, %r136
  %r198 = and i1 %r197, %r192
  %r199 = and i1 %r198, %r151
  br i1 %r199, label %put.pic.hit.36, label %put.pic.dispatch5.35

put.pic.fallback.32:                              ; preds = %put.pic.guard.28
  %r161 = icmp eq i64 %r149, 0
  br i1 %r161, label %put.pic.miss.40, label %put.pic.guard2.29

put.pic.dispatch3.33:                             ; preds = %put.pic.guard2.29
  %r174 = icmp eq i64 %r163, 0
  br i1 %r174, label %put.pic.miss2.41, label %put.pic.guard3.30

put.pic.dispatch4.34:                             ; preds = %put.pic.guard3.30
  %r187 = icmp eq i64 %r176, 0
  br i1 %r187, label %put.pic.miss3.42, label %put.pic.guard4.31

put.pic.dispatch5.35:                             ; preds = %put.pic.guard4.31
  %r200 = icmp eq i64 %r189, 0
  br i1 %r200, label %put.pic.miss4.43, label %put.pic.tail.44

put.pic.hit.36:                                   ; preds = %put.pic.guard4.31, %put.pic.guard3.30, %put.pic.guard2.29, %put.pic.guard.28
  %r201 = phi i64 [ %r153, %put.pic.guard.28 ], [ %r165, %put.pic.guard2.29 ], [ %r178, %put.pic.guard3.30 ], [ %r191, %put.pic.guard4.31 ]
  %r202 = and i64 %r201, 1073741824
  %r203 = icmp ne i64 %r202, 0
  br i1 %r203, label %put.pic.hit.overflow.46, label %put.pic.hit.inline.47

put.pic.hit.validate.37:                          ; preds = %put.pic.hit.inline.47
  %r213 = load double, ptr %r210, align 8
  %r214 = bitcast double %r213 to i64
  %r215 = icmp eq i64 %r214, 9222246136947933200
  br i1 %r215, label %put.pic.deleted.39, label %put.pic.hit.store.38

put.pic.hit.store.38:                             ; preds = %put.pic.hit.inline.47, %put.pic.hit.validate.37
  store double %r106, ptr %r210, align 8
  br label %put.pic.merge.45

put.pic.deleted.39:                               ; preds = %put.pic.hit.validate.37
  %statepoint_token16 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r94, i64 %r109, double %r106, i32 1, ptr @perry_ic_changing_options_worker_ts__6, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r21617 = call double @llvm.experimental.gc.result.f64(token %statepoint_token16)
  %rs4gc.s3.relocated18 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token16, i32 0, i32 0) ; (%.2, %.2)
  br label %put.pic.merge.45

put.pic.miss.40:                                  ; preds = %put.pic.hit.overflow.46, %put.pic.fallback.32, %for.body.18
  %.3 = phi ptr addrspace(1) [ %rs4gc.s3.relocated39, %put.pic.hit.overflow.46 ], [ %.2, %put.pic.fallback.32 ], [ %.2, %for.body.18 ]
  %r839 = load double, ptr @changing_options_worker_ts_.str.1.handle, align 8
  %r840 = bitcast double %r839 to i64
  %r841 = and i64 %r840, 281474976710655
  %statepoint_token19 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r94, i64 %r841, double %r106, i32 1, ptr @perry_ic_changing_options_worker_ts__6, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3) ]
  %r21720 = call double @llvm.experimental.gc.result.f64(token %statepoint_token19)
  %rs4gc.s3.relocated21 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token19, i32 0, i32 0) ; (%.3, %.3)
  br label %put.pic.merge.45

put.pic.miss2.41:                                 ; preds = %put.pic.dispatch3.33
  %statepoint_token22 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r94, i64 %r109, double %r106, i32 1, ptr @perry_ic_changing_options_worker_ts__6, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r21823 = call double @llvm.experimental.gc.result.f64(token %statepoint_token22)
  %rs4gc.s3.relocated24 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token22, i32 0, i32 0) ; (%.2, %.2)
  br label %put.pic.merge.45

put.pic.miss3.42:                                 ; preds = %put.pic.dispatch4.34
  %statepoint_token25 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r94, i64 %r109, double %r106, i32 1, ptr @perry_ic_changing_options_worker_ts__6, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r21926 = call double @llvm.experimental.gc.result.f64(token %statepoint_token25)
  %rs4gc.s3.relocated27 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token25, i32 0, i32 0) ; (%.2, %.2)
  br label %put.pic.merge.45

put.pic.miss4.43:                                 ; preds = %put.pic.dispatch5.35
  %statepoint_token28 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r94, i64 %r109, double %r106, i32 1, ptr @perry_ic_changing_options_worker_ts__6, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r22029 = call double @llvm.experimental.gc.result.f64(token %statepoint_token28)
  %rs4gc.s3.relocated30 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token28, i32 0, i32 0) ; (%.2, %.2)
  br label %put.pic.merge.45

put.pic.tail.44:                                  ; preds = %put.pic.dispatch5.35
  %statepoint_token31 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, i64, double, i32)) @js_put_value_set_ic_poly_tail, i32 5, i32 0, ptr @perry_ic_changing_options_worker_ts__6_poly_tail, double %r94, i64 %r109, double %r106, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r22132 = call double @llvm.experimental.gc.result.f64(token %statepoint_token31)
  %rs4gc.s3.relocated33 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token31, i32 0, i32 0) ; (%.2, %.2)
  br label %put.pic.merge.45

put.pic.merge.45:                                 ; preds = %put.pic.hit.overflow.46, %put.pic.tail.44, %put.pic.miss4.43, %put.pic.miss3.42, %put.pic.miss2.41, %put.pic.miss.40, %put.pic.deleted.39, %put.pic.hit.store.38
  %.6 = phi ptr addrspace(1) [ %rs4gc.s3.relocated39, %put.pic.hit.overflow.46 ], [ %rs4gc.s3.relocated21, %put.pic.miss.40 ], [ %rs4gc.s3.relocated18, %put.pic.deleted.39 ], [ %.2, %put.pic.hit.store.38 ], [ %rs4gc.s3.relocated24, %put.pic.miss2.41 ], [ %rs4gc.s3.relocated27, %put.pic.miss3.42 ], [ %rs4gc.s3.relocated30, %put.pic.miss4.43 ], [ %rs4gc.s3.relocated33, %put.pic.tail.44 ]
  %r222 = phi double [ %r106, %put.pic.hit.store.38 ], [ %r106, %put.pic.hit.overflow.46 ], [ %r21617, %put.pic.deleted.39 ], [ %r21720, %put.pic.miss.40 ], [ %r21823, %put.pic.miss2.41 ], [ %r21926, %put.pic.miss3.42 ], [ %r22029, %put.pic.miss4.43 ], [ %r22132, %put.pic.tail.44 ]
  %r224 = load double, ptr @perry_global_changing_options_worker_ts__5, align 8
  %statepoint_token34 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r224, double 0x7FFC000000000002, double 0x7FFC000000000002, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6) ]
  %r22535 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token34)
  %rs4gc.s3.relocated36 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token34, i32 0, i32 0) ; (%.6, %.6)
  %r226 = bitcast i64 %r22535 to double
  %rs4gc.b4 = bitcast double %r226 to i64
  %rs4gc.s4 = inttoptr i64 %rs4gc.b4 to ptr addrspace(1)
  %r227.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s4 to i64
  %r227 = call i64 asm "", "=r,0"(i64 %r227.rs4i) #8
  %r228 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r229 = icmp ne i32 %r228, 0
  br i1 %r229, label %shadow.root.barrier.48, label %shadow.root.barrier.done.49

put.pic.hit.overflow.46:                          ; preds = %put.pic.hit.36
  %r204 = trunc i64 %r201 to i32
  %statepoint_token37 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (double, i64, i32, double)) @js_put_value_set_ic_overflow_store, i32 4, i32 0, double %r94, i64 %r147, i32 %r204, double %r106, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r20538 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token37)
  %rs4gc.s3.relocated39 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token37, i32 0, i32 0) ; (%.2, %.2)
  %r206 = icmp ne i32 %r20538, 0
  br i1 %r206, label %put.pic.merge.45, label %put.pic.miss.40

put.pic.hit.inline.47:                            ; preds = %put.pic.hit.36
  %r207 = shl i64 %r201, 3
  %r208 = add nuw nsw i64 %r110, 16
  %r209 = add i64 %r208, %r207
  %r210 = inttoptr i64 %r209 to ptr
  %r211 = and i16 %r129, 1024
  %r212 = icmp ne i16 %r211, 0
  br i1 %r212, label %put.pic.hit.validate.37, label %put.pic.hit.store.38

shadow.root.barrier.48:                           ; preds = %put.pic.merge.45
  call void @js_write_barrier_root_nanbox(i64 %r227) #8
  br label %shadow.root.barrier.done.49

shadow.root.barrier.done.49:                      ; preds = %shadow.root.barrier.48, %put.pic.merge.45
  %r231 = bitcast double %r2.1 to i64
  %rs4gc.s5 = inttoptr i64 %r231 to ptr addrspace(1)
  %r233.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s5 to i64
  %r233 = call i64 asm "", "=r,0"(i64 %r233.rs4i) #8
  %r234 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r235 = icmp ne i32 %r234, 0
  br i1 %r235, label %shadow.root.barrier.50, label %shadow.root.barrier.done.51

shadow.root.barrier.50:                           ; preds = %shadow.root.barrier.done.49
  call void @js_write_barrier_root_nanbox(i64 %r233) #8
  br label %shadow.root.barrier.done.51

shadow.root.barrier.done.51:                      ; preds = %shadow.root.barrier.50, %shadow.root.barrier.done.49
  %r236.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s4 to i64
  %r236.rs4o = call i64 asm "", "=r,0"(i64 %r236.rs4i) #8
  %r236 = bitcast i64 %r236.rs4o to double
  %r237 = bitcast double %r236 to i64
  %r238 = and i64 %r237, 281474976710655
  %r239 = lshr i64 %r237, 48
  %r240 = and i64 %r239, 65533
  %r241 = icmp eq i64 %r240, 32765
  br i1 %r241, label %pget.recv_ok.53, label %pget.recv_other.58

pget.recv_sso.52:                                 ; preds = %pget.recv_other.58
  %r380 = lshr i64 %r237, 40
  %r381 = and i64 %r380, 255
  %r382 = uitofp nneg i64 %r381 to double
  br label %pget.recv_merge.56

pget.recv_ok.53:                                  ; preds = %shadow.root.barrier.done.51
  %r248 = icmp eq i64 %r239, 32767
  br i1 %r248, label %pget.strlen_heap.57, label %pget.recv_obj.60

pget.recv_bad.54:                                 ; preds = %pget.check_class_ref.59
  %r372 = icmp eq i64 %r237, 9222246136947933185
  %r373 = icmp eq i64 %r237, 9222246136947933186
  %r374 = or i1 %r372, %r373
  br i1 %r374, label %pget.throw_nullish.83, label %pget.recv_undef_return.84

pget.recv_class_ref.55:                           ; preds = %pget.check_class_ref.59
  %r244 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r245 = bitcast double %r244 to i64
  %r246 = and i64 %r245, 281474976710655
  %statepoint_token40 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 1175166488852561927, i64 %r237, i64 %r246, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated36, ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s5) ]
  %r24741 = call double @llvm.experimental.gc.result.f64(token %statepoint_token40)
  %rs4gc.s3.relocated42 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 0, i32 0) ; (%rs4gc.s3.relocated36, %rs4gc.s3.relocated36)
  %rs4gc.s4.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 1, i32 1) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s5.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token40, i32 2, i32 2) ; (%rs4gc.s5, %rs4gc.s5)
  br label %pget.recv_merge.56

pget.recv_merge.56:                               ; preds = %pget.recv_undef_return.84, %pic.merge.75, %pget.strlen_heap.57, %pget.recv_class_ref.55, %pget.recv_sso.52
  %.0125 = phi ptr addrspace(1) [ %rs4gc.s5, %pget.strlen_heap.57 ], [ %.1126, %pic.merge.75 ], [ %rs4gc.s5, %pget.recv_sso.52 ], [ %rs4gc.s5.relocated, %pget.recv_class_ref.55 ], [ %rs4gc.s5.relocated58, %pget.recv_undef_return.84 ]
  %.0122 = phi ptr addrspace(1) [ %rs4gc.s4, %pget.strlen_heap.57 ], [ %.1123, %pic.merge.75 ], [ %rs4gc.s4, %pget.recv_sso.52 ], [ %rs4gc.s4.relocated, %pget.recv_class_ref.55 ], [ %rs4gc.s4.relocated57, %pget.recv_undef_return.84 ]
  %.7 = phi ptr addrspace(1) [ %rs4gc.s3.relocated36, %pget.strlen_heap.57 ], [ %.8, %pic.merge.75 ], [ %rs4gc.s3.relocated36, %pget.recv_sso.52 ], [ %rs4gc.s3.relocated42, %pget.recv_class_ref.55 ], [ %rs4gc.s3.relocated56, %pget.recv_undef_return.84 ]
  %r388 = phi double [ %r371, %pic.merge.75 ], [ %r37955, %pget.recv_undef_return.84 ], [ %r382, %pget.recv_sso.52 ], [ %r24741, %pget.recv_class_ref.55 ], [ %r387, %pget.strlen_heap.57 ]
  %r389.rs4i = ptrtoint ptr addrspace(1) %.0125 to i64
  %r389 = call i64 asm "", "=r,0"(i64 %r389.rs4i) #8
  %r390 = bitcast i64 %r389 to double
  %r391 = and i64 %r389, -281474976710656
  %r392 = icmp ult i64 %r391, 9221401712017801216
  %r393 = icmp ugt i64 %r391, 9223090561878065152
  %r394 = or i1 %r392, %r393
  %r395 = bitcast double %r388 to i64
  %r396 = and i64 %r395, -281474976710656
  %r397 = icmp ult i64 %r396, 9221401712017801216
  %r398 = icmp ugt i64 %r396, 9223090561878065152
  %r399 = or i1 %r397, %r398
  %r400 = and i1 %r394, %r399
  br i1 %r400, label %guarded_add.numeric.85, label %guarded_add.dynamic.86

pget.strlen_heap.57:                              ; preds = %pget.recv_ok.53
  %r383 = icmp ult i64 %r238, 4096
  %r384 = inttoptr i64 %r238 to ptr
  %r385 = select i1 %r383, ptr @perry_null_guard_zero_changing_options_worker_ts, ptr %r384
  %r386 = load i32, ptr %r385, align 4
  %r387 = uitofp i32 %r386 to double
  br label %pget.recv_merge.56

pget.recv_other.58:                               ; preds = %shadow.root.barrier.done.51
  %r242 = icmp eq i64 %r239, 32761
  br i1 %r242, label %pget.recv_sso.52, label %pget.check_class_ref.59

pget.check_class_ref.59:                          ; preds = %pget.recv_other.58
  %r243 = icmp eq i64 %r239, 32766
  br i1 %r243, label %pget.recv_class_ref.55, label %pget.recv_bad.54

pget.recv_obj.60:                                 ; preds = %pget.recv_ok.53
  %r249 = icmp ugt i64 %r238, 1048575
  br i1 %r249, label %pic.recv_hdr.76, label %pic.miss.cold.73

pic.hit.61:                                       ; preds = %pic.token.77
  %r274 = getelementptr i64, ptr %r259, i64 1
  %r275 = load i64, ptr %r274, align 8
  %r276 = and i64 %r275, 1073741824
  %r277 = icmp ne i64 %r276, 0
  br i1 %r277, label %pic.hit.overflow.78, label %pic.hit.inline.79

pic.hit.live.62:                                  ; preds = %pic.hit.inline.79
  br label %pic.merge.75

pic.prefix.guard.63:                              ; preds = %pic.token.77
  %r290 = getelementptr i64, ptr %r259, i64 2
  %r291 = load i64, ptr %r290, align 8
  %r292 = icmp ne i64 %r291, 0
  br i1 %r292, label %pic.prefix.meta.64, label %pic.miss.72

pic.prefix.meta.64:                               ; preds = %pic.prefix.guard.63
  %r293 = add nuw nsw i64 %r238, 8
  %r294 = inttoptr i64 %r293 to ptr
  %r295 = load i64, ptr %r294, align 8
  %r296 = icmp ne i64 %r295, 0
  br i1 %r296, label %pic.prefix.token.65, label %pic.miss.72

pic.prefix.token.65:                              ; preds = %pic.prefix.meta.64
  %r297 = inttoptr i64 %r295 to ptr
  %r298 = getelementptr i64, ptr %r297, i64 6
  %r299 = load i64, ptr %r298, align 8
  %r300 = icmp eq i64 %r299, %r291
  br i1 %r300, label %pic.prefix.hit.66, label %pic.miss.72

pic.prefix.hit.66:                                ; preds = %pic.prefix.token.65
  %r301 = getelementptr i64, ptr %r259, i64 1
  %r302 = load i64, ptr %r301, align 8
  %r303 = shl i64 %r302, 3
  %r304 = add nuw nsw i64 %r238, 16
  %r305 = add i64 %r304, %r303
  %r306 = inttoptr i64 %r305 to ptr
  %r307 = load double, ptr %r306, align 8
  br label %pic.merge.75

pic.desc.classify.67:                             ; preds = %pic.recv_hdr.76
  %r263 = and i1 %r253, %r260
  br i1 %r263, label %pic.desc.prefix.guard.68, label %pic.miss.cold.73

pic.desc.prefix.guard.68:                         ; preds = %pic.desc.classify.67
  %r308 = getelementptr i64, ptr %r259, i64 2
  %r309 = load i64, ptr %r308, align 8
  %r310 = icmp ne i64 %r309, 0
  br i1 %r310, label %pic.desc.prefix.meta.69, label %pic.miss.cold.73

pic.desc.prefix.meta.69:                          ; preds = %pic.desc.prefix.guard.68
  %r311 = add nuw nsw i64 %r238, 8
  %r312 = inttoptr i64 %r311 to ptr
  %r313 = load i64, ptr %r312, align 8
  %r314 = icmp ne i64 %r313, 0
  br i1 %r314, label %pic.desc.prefix.token.70, label %pic.miss.cold.73

pic.desc.prefix.token.70:                         ; preds = %pic.desc.prefix.meta.69
  %r315 = inttoptr i64 %r313 to ptr
  %r316 = getelementptr i64, ptr %r315, i64 6
  %r317 = load i64, ptr %r316, align 8
  %r318 = icmp eq i64 %r317, %r309
  br i1 %r318, label %pic.desc.prefix.hit.71, label %pic.miss.cold.73

pic.desc.prefix.hit.71:                           ; preds = %pic.desc.prefix.token.70
  %r319 = getelementptr i64, ptr %r259, i64 1
  %r320 = load i64, ptr %r319, align 8
  %r321 = shl i64 %r320, 3
  %r322 = add nuw nsw i64 %r238, 16
  %r323 = add i64 %r322, %r321
  %r324 = inttoptr i64 %r323 to ptr
  %r325 = load double, ptr %r324, align 8
  br label %pic.merge.75

pic.miss.72:                                      ; preds = %pic.hit.inline.79, %pic.prefix.token.65, %pic.prefix.meta.64, %pic.prefix.guard.63
  %r326 = getelementptr i64, ptr %r259, i64 3
  %r327 = load i64, ptr %r326, align 8
  %r328 = icmp sgt i64 %r327, 0
  br i1 %r328, label %pic.ways.80, label %pic.miss.call.74

pic.miss.cold.73:                                 ; preds = %pic.desc.prefix.token.70, %pic.desc.prefix.meta.69, %pic.desc.prefix.guard.68, %pic.desc.classify.67, %pget.recv_obj.60
  br label %pic.miss.call.74

pic.miss.call.74:                                 ; preds = %pic.way.load.81, %pic.ways.80, %pic.miss.cold.73, %pic.miss.72
  %r367 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r368 = bitcast double %r367 to i64
  %r369 = and i64 %r368, 281474976710655
  %statepoint_token43 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r238, i64 %r369, ptr @perry_ic_changing_options_worker_ts__8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated36, ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s5) ]
  %r37044 = call double @llvm.experimental.gc.result.f64(token %statepoint_token43)
  %rs4gc.s3.relocated45 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token43, i32 0, i32 0) ; (%rs4gc.s3.relocated36, %rs4gc.s3.relocated36)
  %rs4gc.s4.relocated46 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token43, i32 1, i32 1) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s5.relocated47 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token43, i32 2, i32 2) ; (%rs4gc.s5, %rs4gc.s5)
  br label %pic.merge.75

pic.merge.75:                                     ; preds = %pic.way.live.82, %pic.hit.overflow.78, %pic.miss.call.74, %pic.desc.prefix.hit.71, %pic.prefix.hit.66, %pic.hit.live.62
  %.1126 = phi ptr addrspace(1) [ %rs4gc.s5.relocated52, %pic.hit.overflow.78 ], [ %rs4gc.s5.relocated47, %pic.miss.call.74 ], [ %rs4gc.s5, %pic.way.live.82 ], [ %rs4gc.s5, %pic.hit.live.62 ], [ %rs4gc.s5, %pic.prefix.hit.66 ], [ %rs4gc.s5, %pic.desc.prefix.hit.71 ]
  %.1123 = phi ptr addrspace(1) [ %rs4gc.s4.relocated51, %pic.hit.overflow.78 ], [ %rs4gc.s4.relocated46, %pic.miss.call.74 ], [ %rs4gc.s4, %pic.way.live.82 ], [ %rs4gc.s4, %pic.hit.live.62 ], [ %rs4gc.s4, %pic.prefix.hit.66 ], [ %rs4gc.s4, %pic.desc.prefix.hit.71 ]
  %.8 = phi ptr addrspace(1) [ %rs4gc.s3.relocated50, %pic.hit.overflow.78 ], [ %rs4gc.s3.relocated45, %pic.miss.call.74 ], [ %rs4gc.s3.relocated36, %pic.way.live.82 ], [ %rs4gc.s3.relocated36, %pic.hit.live.62 ], [ %rs4gc.s3.relocated36, %pic.prefix.hit.66 ], [ %rs4gc.s3.relocated36, %pic.desc.prefix.hit.71 ]
  %r371 = phi double [ %r287, %pic.hit.live.62 ], [ %r28249, %pic.hit.overflow.78 ], [ %r307, %pic.prefix.hit.66 ], [ %r325, %pic.desc.prefix.hit.71 ], [ %r364, %pic.way.live.82 ], [ %r37044, %pic.miss.call.74 ]
  br label %pget.recv_merge.56

pic.recv_hdr.76:                                  ; preds = %pget.recv_obj.60
  %r250 = sub nuw nsw i64 %r238, 8
  %r251 = inttoptr i64 %r250 to ptr
  %r252 = load i8, ptr %r251, align 1
  %r253 = icmp eq i8 %r252, 2
  %r254 = sub nuw nsw i64 %r238, 6
  %r255 = inttoptr i64 %r254 to ptr
  %r256 = load i16, ptr %r255, align 2
  %r257 = and i16 %r256, 2048
  %r258 = icmp eq i16 %r257, 0
  %r259 = load ptr, ptr @perry_ic_changing_options_worker_ts__8, align 8
  %r260 = icmp ne ptr %r259, null
  %r261 = and i1 %r253, %r258
  %r262 = and i1 %r261, %r260
  br i1 %r262, label %pic.token.77, label %pic.desc.classify.67

pic.token.77:                                     ; preds = %pic.recv_hdr.76
  %r264 = add nuw nsw i64 %r238, 4
  %r265 = inttoptr i64 %r264 to ptr
  %r266 = load i32, ptr %r265, align 4
  %r267 = zext i32 %r266 to i64
  %r268 = or i64 %r267, 4611686018427387904
  %r269 = icmp ne i32 %r266, 0
  %r270 = getelementptr i64, ptr %r259, i64 0
  %r271 = load i64, ptr %r270, align 8
  %r272 = icmp eq i64 %r268, %r271
  %r273 = and i1 %r272, %r269
  br i1 %r273, label %pic.hit.61, label %pic.prefix.guard.63

pic.hit.overflow.78:                              ; preds = %pic.hit.61
  %r278 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r279 = bitcast double %r278 to i64
  %r280 = and i64 %r279, 281474976710655
  %r281 = trunc i64 %r275 to i32
  %statepoint_token48 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r238, i64 %r280, i32 %r281, ptr @perry_ic_changing_options_worker_ts__8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated36, ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s5) ]
  %r28249 = call double @llvm.experimental.gc.result.f64(token %statepoint_token48)
  %rs4gc.s3.relocated50 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token48, i32 0, i32 0) ; (%rs4gc.s3.relocated36, %rs4gc.s3.relocated36)
  %rs4gc.s4.relocated51 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token48, i32 1, i32 1) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s5.relocated52 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token48, i32 2, i32 2) ; (%rs4gc.s5, %rs4gc.s5)
  br label %pic.merge.75

pic.hit.inline.79:                                ; preds = %pic.hit.61
  %r283 = shl i64 %r275, 3
  %r284 = add nuw nsw i64 %r238, 16
  %r285 = add i64 %r284, %r283
  %r286 = inttoptr i64 %r285 to ptr
  %r287 = load double, ptr %r286, align 8
  %r288 = bitcast double %r287 to i64
  %r289 = icmp eq i64 %r288, 9222246136947933200
  br i1 %r289, label %pic.miss.72, label %pic.hit.live.62

pic.ways.80:                                      ; preds = %pic.miss.72
  %r329 = getelementptr i64, ptr %r259, i64 4
  %r330 = load i64, ptr %r329, align 8
  %r331 = icmp eq i64 %r330, %r268
  %r332 = getelementptr i64, ptr %r259, i64 5
  %r333 = load i64, ptr %r332, align 8
  %r334 = select i1 %r331, i64 %r333, i64 0
  %r335 = getelementptr i64, ptr %r259, i64 6
  %r336 = load i64, ptr %r335, align 8
  %r337 = icmp eq i64 %r336, %r268
  %r338 = getelementptr i64, ptr %r259, i64 7
  %r339 = load i64, ptr %r338, align 8
  %r340 = select i1 %r337, i64 %r339, i64 0
  %r341 = getelementptr i64, ptr %r259, i64 8
  %r342 = load i64, ptr %r341, align 8
  %r343 = icmp eq i64 %r342, %r268
  %r344 = getelementptr i64, ptr %r259, i64 9
  %r345 = load i64, ptr %r344, align 8
  %r346 = select i1 %r343, i64 %r345, i64 0
  %r347 = getelementptr i64, ptr %r259, i64 10
  %r348 = load i64, ptr %r347, align 8
  %r349 = icmp eq i64 %r348, %r268
  %r350 = getelementptr i64, ptr %r259, i64 11
  %r351 = load i64, ptr %r350, align 8
  %r352 = select i1 %r349, i64 %r351, i64 0
  %r353 = or i1 %r331, %r337
  %r354 = select i1 %r331, i64 %r334, i64 %r340
  %r355 = or i1 %r343, %r349
  %r356 = select i1 %r343, i64 %r346, i64 %r352
  %r357 = or i1 %r353, %r355
  %r358 = select i1 %r353, i64 %r354, i64 %r356
  %r359 = and i1 %r269, %r357
  br i1 %r359, label %pic.way.load.81, label %pic.miss.call.74

pic.way.load.81:                                  ; preds = %pic.ways.80
  %r360 = shl i64 %r358, 3
  %r361 = add nuw nsw i64 %r238, 16
  %r362 = add i64 %r361, %r360
  %r363 = inttoptr i64 %r362 to ptr
  %r364 = load double, ptr %r363, align 8
  %r365 = bitcast double %r364 to i64
  %r366 = icmp eq i64 %r365, 9222246136947933200
  br i1 %r366, label %pic.miss.call.74, label %pic.way.live.82

pic.way.live.82:                                  ; preds = %pic.way.load.81
  br label %pic.merge.75

pget.throw_nullish.83:                            ; preds = %pget.recv_bad.54
  %r375 = zext i1 %r373 to i32
  %statepoint_token53 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r375, ptr @changing_options_worker_ts_.str.2.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.84:                        ; preds = %pget.recv_bad.54
  %r376 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r377 = bitcast double %r376 to i64
  %r378 = and i64 %r377, 281474976710655
  %statepoint_token54 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r237, i64 %r378, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated36, ptr addrspace(1) %rs4gc.s4, ptr addrspace(1) %rs4gc.s5) ]
  %r37955 = call double @llvm.experimental.gc.result.f64(token %statepoint_token54)
  %rs4gc.s3.relocated56 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 0, i32 0) ; (%rs4gc.s3.relocated36, %rs4gc.s3.relocated36)
  %rs4gc.s4.relocated57 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 1, i32 1) ; (%rs4gc.s4, %rs4gc.s4)
  %rs4gc.s5.relocated58 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token54, i32 2, i32 2) ; (%rs4gc.s5, %rs4gc.s5)
  br label %pget.recv_merge.56

guarded_add.numeric.85:                           ; preds = %pget.recv_merge.56
  %r401 = fadd double %r390, %r388
  br label %guarded_add.merge.87

guarded_add.dynamic.86:                           ; preds = %pget.recv_merge.56
  %statepoint_token59 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r390, double %r388, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.7, ptr addrspace(1) %.0122) ]
  %r40260 = call double @llvm.experimental.gc.result.f64(token %statepoint_token59)
  %rs4gc.s3.relocated61 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 0, i32 0) ; (%.7, %.7)
  %rs4gc.s4.relocated62 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 1, i32 1) ; (%.0122, %.0122)
  br label %guarded_add.merge.87

guarded_add.merge.87:                             ; preds = %guarded_add.dynamic.86, %guarded_add.numeric.85
  %.2124 = phi ptr addrspace(1) [ %.0122, %guarded_add.numeric.85 ], [ %rs4gc.s4.relocated62, %guarded_add.dynamic.86 ]
  %.9 = phi ptr addrspace(1) [ %.7, %guarded_add.numeric.85 ], [ %rs4gc.s3.relocated61, %guarded_add.dynamic.86 ]
  %r403 = phi double [ %r401, %guarded_add.numeric.85 ], [ %r40260, %guarded_add.dynamic.86 ]
  %r404.rs4i = ptrtoint ptr addrspace(1) %.2124 to i64
  %r404.rs4o = call i64 asm "", "=r,0"(i64 %r404.rs4i) #8
  %r404 = bitcast i64 %r404.rs4o to double
  %r405 = bitcast double %r404 to i64
  %r406 = and i64 %r405, -281474976710656
  %r407 = icmp ne i64 %r406, 9223090561878065152
  br i1 %r407, label %str_addref.done.89, label %str_addref.call.88

str_addref.call.88:                               ; preds = %guarded_add.merge.87
  call void @js_string_addref_if_heap_string(double %r404) #8
  br label %str_addref.done.89

str_addref.done.89:                               ; preds = %str_addref.call.88, %guarded_add.merge.87
  %r838.rs4i = ptrtoint ptr addrspace(1) %.2124 to i64
  %r838.rs4o = call i64 asm "", "=r,0"(i64 %r838.rs4i) #8
  %r838 = bitcast i64 %r838.rs4o to double
  store double %r838, ptr @perry_global_changing_options_worker_ts__6, align 8
  %r837.rs4i = ptrtoint ptr addrspace(1) %.2124 to i64
  %r837.rs4o = call i64 asm "", "=r,0"(i64 %r837.rs4i) #8
  %r837 = bitcast i64 %r837.rs4o to double
  %r408 = bitcast double %r837 to i64
  %r835.rs4i = ptrtoint ptr addrspace(1) %.2124 to i64
  %r835.rs4o = call i64 asm "", "=r,0"(i64 %r835.rs4i) #8
  %r835 = bitcast i64 %r835.rs4o to double
  %r836 = bitcast double %r835 to i64
  call void @js_write_barrier_root_nanbox(i64 %r836) #8
  %r409 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r410 = icmp ne i32 %r409, 0
  br i1 %r410, label %gcpoll.90, label %gcpoll.done.91

gcpoll.90:                                        ; preds = %str_addref.done.89
  %statepoint_token63 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.9) ]
  %rs4gc.s3.relocated64 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token63, i32 0, i32 0) ; (%.9, %.9)
  br label %gcpoll.done.91

gcpoll.done.91:                                   ; preds = %gcpoll.90, %str_addref.done.89
  %.10 = phi ptr addrspace(1) [ %rs4gc.s3.relocated64, %gcpoll.90 ], [ %.9, %str_addref.done.89 ]
  br label %for.update.19

streqlit.tag.92:                                  ; preds = %if.else.10
  %r420 = lshr i64 %r417, 48
  %r421 = icmp eq i64 %r420, 32767
  %r422 = and i64 %r417, 281474976710655
  %r423 = icmp ugt i64 %r422, 4095
  %r424 = and i1 %r421, %r423
  br i1 %r424, label %streqlit.len.93, label %streqlit.false.98

streqlit.len.93:                                  ; preds = %streqlit.tag.92
  %r425 = inttoptr i64 %r422 to ptr
  %r426 = getelementptr inbounds nuw i8, ptr %r425, i64 4
  %r427 = load i32, ptr %r426, align 4
  %r428 = icmp eq i32 %r427, 13
  br i1 %r428, label %streqlit.b0.94, label %streqlit.false.98

streqlit.b0.94:                                   ; preds = %streqlit.len.93
  %r429 = getelementptr inbounds nuw i8, ptr %r425, i64 20
  %r430 = load i8, ptr %r429, align 1
  %r431 = icmp eq i8 %r430, 99
  br i1 %r431, label %streqlit.bl.95, label %streqlit.false.98

streqlit.bl.95:                                   ; preds = %streqlit.b0.94
  %r432 = getelementptr inbounds nuw i8, ptr %r425, i64 32
  %r433 = load i8, ptr %r432, align 1
  %r434 = icmp eq i8 %r433, 111
  br i1 %r434, label %streqlit.slow.96, label %streqlit.false.98

streqlit.slow.96:                                 ; preds = %streqlit.bl.95
  %r435 = and i64 %r418, 281474976710655
  %statepoint_token65 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r422, i64 %r435, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r43666 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token65)
  %rs4gc.s3.relocated67 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token65, i32 0, i32 0) ; (%.0, %.0)
  %r437 = icmp ne i32 %r43666, 0
  br label %streqlit.merge.99

streqlit.true.97:                                 ; preds = %if.else.10
  br label %streqlit.merge.99

streqlit.false.98:                                ; preds = %streqlit.bl.95, %streqlit.b0.94, %streqlit.len.93, %streqlit.tag.92
  br label %streqlit.merge.99

streqlit.merge.99:                                ; preds = %streqlit.false.98, %streqlit.true.97, %streqlit.slow.96
  %.11 = phi ptr addrspace(1) [ %.0, %streqlit.true.97 ], [ %rs4gc.s3.relocated67, %streqlit.slow.96 ], [ %.0, %streqlit.false.98 ]
  %r438 = phi i1 [ true, %streqlit.true.97 ], [ false, %streqlit.false.98 ], [ %r437, %streqlit.slow.96 ]
  %r439 = select i1 %r438, i64 9222246136947933188, i64 9222246136947933187
  %r440 = bitcast i64 %r439 to double
  %r441 = icmp eq i64 %r439, 9222246136947933188
  br i1 %r441, label %if.then.100, label %if.else.101

if.then.100:                                      ; preds = %streqlit.merge.99
  %r446.rs4i = ptrtoint ptr addrspace(1) %.11 to i64
  %r446.rs4o = call i64 asm "", "=r,0"(i64 %r446.rs4i) #8
  %r446 = bitcast i64 %r446.rs4o to double
  %r447 = bitcast double %r446 to i64
  %r448 = and i64 %r447, -281474976710656
  %r449 = icmp ult i64 %r448, 9221401712017801216
  %r450 = icmp ugt i64 %r448, 9223090561878065152
  %r451 = or i1 %r449, %r450
  br i1 %r451, label %for.bound_i32.number.103, label %for.bound_i32.merge.105

if.else.101:                                      ; preds = %streqlit.merge.99
  br label %if.merge.102

if.merge.102:                                     ; preds = %for.exit.111, %if.else.101
  %r2.2 = phi double [ %r2.3, %for.exit.111 ], [ 0.000000e+00, %if.else.101 ]
  br label %if.merge.11

for.bound_i32.number.103:                         ; preds = %if.then.100
  %r452 = fcmp oge double %r446, 0xC1E0000000000000
  %r453 = fcmp ole double %r446, 0x41DFFFFFFFC00000
  %r454 = and i1 %r452, %r453
  br i1 %r454, label %for.bound_i32.convert.104, label %for.bound_i32.merge.105

for.bound_i32.convert.104:                        ; preds = %for.bound_i32.number.103
  %r455 = fptosi double %r446 to i32
  %r456 = sitofp i32 %r455 to double
  %r457 = fcmp oeq double %r456, %r446
  br i1 %r457, label %for.counter_i32.range.106, label %for.bound_i32.merge.105

for.bound_i32.merge.105:                          ; preds = %for.counter_i32.convert.107, %for.bound_i32.convert.104, %for.bound_i32.number.103, %if.then.100
  %r445.0 = phi i32 [ %r455, %for.counter_i32.convert.107 ], [ 0, %if.then.100 ], [ %r455, %for.bound_i32.convert.104 ], [ 0, %for.bound_i32.number.103 ]
  %r444.0 = phi i1 [ true, %for.counter_i32.convert.107 ], [ false, %if.then.100 ], [ false, %for.bound_i32.convert.104 ], [ false, %for.bound_i32.number.103 ]
  br label %for.cond.108

for.counter_i32.range.106:                        ; preds = %for.bound_i32.convert.104
  br label %for.counter_i32.convert.107

for.counter_i32.convert.107:                      ; preds = %for.counter_i32.range.106
  br label %for.bound_i32.merge.105

for.cond.108:                                     ; preds = %for.update.110, %for.bound_i32.merge.105
  %.12 = phi ptr addrspace(1) [ %.11, %for.bound_i32.merge.105 ], [ %.21, %for.update.110 ]
  %r443.1 = phi i32 [ 0, %for.bound_i32.merge.105 ], [ %r826, %for.update.110 ]
  %r442.0 = phi double [ 0.000000e+00, %for.bound_i32.merge.105 ], [ %r824, %for.update.110 ]
  %r2.3 = phi double [ 0.000000e+00, %for.bound_i32.merge.105 ], [ %r815, %for.update.110 ]
  br i1 %r444.0, label %for.cond.fast.112, label %for.cond.slow.113

for.body.109:                                     ; preds = %gcpoll.done.118, %for.cond.fast.112
  %.13 = phi ptr addrspace(1) [ %.12, %for.cond.fast.112 ], [ %.16, %gcpoll.done.118 ]
  %r506 = load double, ptr @perry_global_changing_options_worker_ts__5, align 8
  %r507 = load double, ptr @changing_options_worker_ts_.str.1.handle, align 8
  %r509 = fptosi double %r442.0 to i64
  %r511 = srem i64 %r509, 2
  %r512 = sitofp i64 %r511 to double
  %r513 = icmp eq i64 %r511, 0
  %r514 = fcmp olt double %r442.0, 0.000000e+00
  %r515 = and i1 %r513, %r514
  %r516 = fneg double %r512
  %r517 = select i1 %r515, double %r516, double %r512
  %r518 = fadd double 4.200000e+01, %r517
  %r519 = bitcast double %r506 to i64
  %r520 = bitcast double %r507 to i64
  %r521 = and i64 %r520, 281474976710655
  %r522 = and i64 %r519, 281474976710655
  %r523 = load ptr, ptr @perry_ic_changing_options_worker_ts__9, align 8
  %r524 = icmp ne ptr %r523, null
  %r525 = lshr i64 %r519, 48
  %r526 = icmp eq i64 %r525, 32765
  %r527 = icmp ugt i64 %r522, 1048575
  %r528 = and i1 %r526, %r527
  %r529 = and i1 %r528, %r524
  br i1 %r529, label %put.pic.guard.119, label %put.pic.miss.131

for.update.110:                                   ; preds = %gcpoll.done.182
  %r824 = fadd double %r442.0, 1.000000e+00
  %r826 = add i32 %r443.1, 1
  br label %for.cond.108

for.exit.111:                                     ; preds = %gcpoll.done.118, %for.cond.fast.112
  br label %if.merge.102

for.cond.fast.112:                                ; preds = %for.cond.108
  %r468 = icmp slt i32 %r443.1, %r445.0
  br i1 %r468, label %for.body.109, label %for.exit.111

for.cond.slow.113:                                ; preds = %for.cond.108
  %r470.rs4i = ptrtoint ptr addrspace(1) %.12 to i64
  %r470.rs4o = call i64 asm "", "=r,0"(i64 %r470.rs4i) #8
  %r470 = bitcast i64 %r470.rs4o to double
  %r471 = bitcast double %r470 to i64
  %r472 = lshr i64 %r471, 48
  %r473 = icmp ult i64 %r472, 32761
  %r474 = icmp ugt i64 %r472, 32767
  %r475 = or i1 %r473, %r474
  %r476 = icmp eq i64 %r472, 32766
  %r477 = icmp eq i64 %r471, 9222246136947933185
  %r478 = icmp eq i64 %r471, 9222246136947933186
  %r479 = icmp eq i64 %r471, 9222246136947933187
  %r480 = icmp eq i64 %r471, 9222246136947933188
  %r481 = or i1 %r478, %r479
  %r482 = or i1 %r475, %r476
  %r483 = or i1 %r482, %r477
  %r484 = or i1 %r483, %r481
  %r485 = or i1 %r484, %r480
  br i1 %r485, label %relnum.fast.114, label %relnum.slow.115

relnum.fast.114:                                  ; preds = %for.cond.slow.113
  %r486 = trunc i64 %r471 to i32
  %r487 = sitofp i32 %r486 to double
  %r488 = select i1 %r476, double %r487, double %r470
  %r489 = select i1 %r481, double 0.000000e+00, double %r488
  %r490 = select i1 %r480, double 1.000000e+00, double %r489
  %r491 = bitcast double %r442.0 to i64
  %r492 = lshr i64 %r491, 48
  %r493 = icmp eq i64 %r492, 32766
  %r494 = trunc i64 %r491 to i32
  %r495 = sitofp i32 %r494 to double
  %r496 = select i1 %r493, double %r495, double %r442.0
  %r497 = fcmp olt double %r496, %r490
  %r498 = select i1 %r497, i64 9222246136947933188, i64 9222246136947933187
  %r499 = bitcast i64 %r498 to double
  br label %relnum.merge.116

relnum.slow.115:                                  ; preds = %for.cond.slow.113
  %statepoint_token68 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_rel_lt, i32 2, i32 0, double %r442.0, double %r470, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.12) ]
  %r50069 = call double @llvm.experimental.gc.result.f64(token %statepoint_token68)
  %rs4gc.s3.relocated70 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token68, i32 0, i32 0) ; (%.12, %.12)
  br label %relnum.merge.116

relnum.merge.116:                                 ; preds = %relnum.slow.115, %relnum.fast.114
  %.15 = phi ptr addrspace(1) [ %.12, %relnum.fast.114 ], [ %rs4gc.s3.relocated70, %relnum.slow.115 ]
  %r501 = phi double [ %r499, %relnum.fast.114 ], [ %r50069, %relnum.slow.115 ]
  %r502 = bitcast double %r501 to i64
  %r504 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r505 = icmp ne i32 %r504, 0
  br i1 %r505, label %gcpoll.117, label %gcpoll.done.118

gcpoll.117:                                       ; preds = %relnum.merge.116
  %statepoint_token71 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.15) ]
  %rs4gc.s3.relocated72 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token71, i32 0, i32 0) ; (%.15, %.15)
  br label %gcpoll.done.118

gcpoll.done.118:                                  ; preds = %gcpoll.117, %relnum.merge.116
  %.16 = phi ptr addrspace(1) [ %rs4gc.s3.relocated72, %gcpoll.117 ], [ %.15, %relnum.merge.116 ]
  %r503 = icmp eq i64 %r502, 9222246136947933188
  br i1 %r503, label %for.body.109, label %for.exit.111

put.pic.guard.119:                                ; preds = %for.body.109
  %r530 = sub nuw nsw i64 %r522, 8
  %r531 = inttoptr i64 %r530 to ptr
  %r532 = load i8, ptr %r531, align 1
  %r533 = icmp eq i8 %r532, 2
  %r534 = sub nuw nsw i64 %r522, 7
  %r535 = inttoptr i64 %r534 to ptr
  %r536 = load i8, ptr %r535, align 1
  %r537 = and i8 %r536, -128
  %r538 = icmp eq i8 %r537, 0
  %r539 = sub nuw nsw i64 %r522, 6
  %r540 = inttoptr i64 %r539 to ptr
  %r541 = load i16, ptr %r540, align 2
  %r542 = and i16 %r541, 6535
  %r543 = icmp eq i16 %r542, 0
  %r544 = add nuw nsw i64 %r522, 0
  %r545 = inttoptr i64 %r544 to ptr
  %r546 = load i32, ptr %r545, align 4
  %r547 = icmp ne i32 %r546, 0
  %r548 = icmp ne i32 %r546, -2
  %r549 = and i16 %r541, 512
  %r550 = icmp ne i16 %r549, 0
  %r551 = or i1 %r547, %r550
  %r552 = add nuw nsw i64 %r522, 4
  %r553 = inttoptr i64 %r552 to ptr
  %r554 = load i32, ptr %r553, align 4
  %r555 = add i32 %r554, -2147483648
  %r556 = icmp ult i32 %r555, 1073741824
  %r557 = zext i32 %r554 to i64
  %r558 = or i64 %r557, 4611686018427387904
  %r559 = select i1 %r556, i64 %r558, i64 0
  %r560 = getelementptr i64, ptr %r523, i64 0
  %r561 = load i64, ptr %r560, align 8
  %r562 = icmp eq i64 %r559, %r561
  %r563 = icmp ne i64 %r559, 0
  %r564 = getelementptr i64, ptr %r523, i64 1
  %r565 = load i64, ptr %r564, align 8
  %r566 = and i1 true, %r533
  %r567 = and i1 %r566, %r538
  %r568 = and i1 %r567, %r543
  %r569 = and i1 %r568, %r551
  %r570 = and i1 %r569, %r548
  %r571 = and i1 %r570, %r562
  %r572 = and i1 %r571, %r563
  br i1 %r572, label %put.pic.hit.127, label %put.pic.fallback.123

put.pic.guard2.120:                               ; preds = %put.pic.fallback.123
  %r574 = getelementptr i64, ptr %r523, i64 2
  %r575 = load i64, ptr %r574, align 8
  %r576 = getelementptr i64, ptr %r523, i64 3
  %r577 = load i64, ptr %r576, align 8
  %r578 = icmp eq i64 %r559, %r575
  %r579 = and i1 true, %r533
  %r580 = and i1 %r579, %r538
  %r581 = and i1 %r580, %r543
  %r582 = and i1 %r581, %r551
  %r583 = and i1 %r582, %r548
  %r584 = and i1 %r583, %r578
  %r585 = and i1 %r584, %r563
  br i1 %r585, label %put.pic.hit.127, label %put.pic.dispatch3.124

put.pic.guard3.121:                               ; preds = %put.pic.dispatch3.124
  %r587 = getelementptr i64, ptr %r523, i64 4
  %r588 = load i64, ptr %r587, align 8
  %r589 = getelementptr i64, ptr %r523, i64 5
  %r590 = load i64, ptr %r589, align 8
  %r591 = icmp eq i64 %r559, %r588
  %r592 = and i1 true, %r533
  %r593 = and i1 %r592, %r538
  %r594 = and i1 %r593, %r543
  %r595 = and i1 %r594, %r551
  %r596 = and i1 %r595, %r548
  %r597 = and i1 %r596, %r591
  %r598 = and i1 %r597, %r563
  br i1 %r598, label %put.pic.hit.127, label %put.pic.dispatch4.125

put.pic.guard4.122:                               ; preds = %put.pic.dispatch4.125
  %r600 = getelementptr i64, ptr %r523, i64 6
  %r601 = load i64, ptr %r600, align 8
  %r602 = getelementptr i64, ptr %r523, i64 7
  %r603 = load i64, ptr %r602, align 8
  %r604 = icmp eq i64 %r559, %r601
  %r605 = and i1 true, %r533
  %r606 = and i1 %r605, %r538
  %r607 = and i1 %r606, %r543
  %r608 = and i1 %r607, %r551
  %r609 = and i1 %r608, %r548
  %r610 = and i1 %r609, %r604
  %r611 = and i1 %r610, %r563
  br i1 %r611, label %put.pic.hit.127, label %put.pic.dispatch5.126

put.pic.fallback.123:                             ; preds = %put.pic.guard.119
  %r573 = icmp eq i64 %r561, 0
  br i1 %r573, label %put.pic.miss.131, label %put.pic.guard2.120

put.pic.dispatch3.124:                            ; preds = %put.pic.guard2.120
  %r586 = icmp eq i64 %r575, 0
  br i1 %r586, label %put.pic.miss2.132, label %put.pic.guard3.121

put.pic.dispatch4.125:                            ; preds = %put.pic.guard3.121
  %r599 = icmp eq i64 %r588, 0
  br i1 %r599, label %put.pic.miss3.133, label %put.pic.guard4.122

put.pic.dispatch5.126:                            ; preds = %put.pic.guard4.122
  %r612 = icmp eq i64 %r601, 0
  br i1 %r612, label %put.pic.miss4.134, label %put.pic.tail.135

put.pic.hit.127:                                  ; preds = %put.pic.guard4.122, %put.pic.guard3.121, %put.pic.guard2.120, %put.pic.guard.119
  %r613 = phi i64 [ %r565, %put.pic.guard.119 ], [ %r577, %put.pic.guard2.120 ], [ %r590, %put.pic.guard3.121 ], [ %r603, %put.pic.guard4.122 ]
  %r614 = and i64 %r613, 1073741824
  %r615 = icmp ne i64 %r614, 0
  br i1 %r615, label %put.pic.hit.overflow.137, label %put.pic.hit.inline.138

put.pic.hit.validate.128:                         ; preds = %put.pic.hit.inline.138
  %r625 = load double, ptr %r622, align 8
  %r626 = bitcast double %r625 to i64
  %r627 = icmp eq i64 %r626, 9222246136947933200
  br i1 %r627, label %put.pic.deleted.130, label %put.pic.hit.store.129

put.pic.hit.store.129:                            ; preds = %put.pic.hit.inline.138, %put.pic.hit.validate.128
  store double %r518, ptr %r622, align 8
  br label %put.pic.merge.136

put.pic.deleted.130:                              ; preds = %put.pic.hit.validate.128
  %statepoint_token73 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r506, i64 %r521, double %r518, i32 1, ptr @perry_ic_changing_options_worker_ts__9, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %r62874 = call double @llvm.experimental.gc.result.f64(token %statepoint_token73)
  %rs4gc.s3.relocated75 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token73, i32 0, i32 0) ; (%.13, %.13)
  br label %put.pic.merge.136

put.pic.miss.131:                                 ; preds = %put.pic.hit.overflow.137, %put.pic.fallback.123, %for.body.109
  %.14 = phi ptr addrspace(1) [ %rs4gc.s3.relocated96, %put.pic.hit.overflow.137 ], [ %.13, %put.pic.fallback.123 ], [ %.13, %for.body.109 ]
  %r832 = load double, ptr @changing_options_worker_ts_.str.1.handle, align 8
  %r833 = bitcast double %r832 to i64
  %r834 = and i64 %r833, 281474976710655
  %statepoint_token76 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r506, i64 %r834, double %r518, i32 1, ptr @perry_ic_changing_options_worker_ts__9, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.14) ]
  %r62977 = call double @llvm.experimental.gc.result.f64(token %statepoint_token76)
  %rs4gc.s3.relocated78 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token76, i32 0, i32 0) ; (%.14, %.14)
  br label %put.pic.merge.136

put.pic.miss2.132:                                ; preds = %put.pic.dispatch3.124
  %statepoint_token79 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r506, i64 %r521, double %r518, i32 1, ptr @perry_ic_changing_options_worker_ts__9, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %r63080 = call double @llvm.experimental.gc.result.f64(token %statepoint_token79)
  %rs4gc.s3.relocated81 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token79, i32 0, i32 0) ; (%.13, %.13)
  br label %put.pic.merge.136

put.pic.miss3.133:                                ; preds = %put.pic.dispatch4.125
  %statepoint_token82 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r506, i64 %r521, double %r518, i32 1, ptr @perry_ic_changing_options_worker_ts__9, i32 2, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %r63183 = call double @llvm.experimental.gc.result.f64(token %statepoint_token82)
  %rs4gc.s3.relocated84 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token82, i32 0, i32 0) ; (%.13, %.13)
  br label %put.pic.merge.136

put.pic.miss4.134:                                ; preds = %put.pic.dispatch5.126
  %statepoint_token85 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, i64, double, i32, ptr, i32)) @js_put_value_set_ic_miss, i32 6, i32 0, double %r506, i64 %r521, double %r518, i32 1, ptr @perry_ic_changing_options_worker_ts__9, i32 3, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %r63286 = call double @llvm.experimental.gc.result.f64(token %statepoint_token85)
  %rs4gc.s3.relocated87 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token85, i32 0, i32 0) ; (%.13, %.13)
  br label %put.pic.merge.136

put.pic.tail.135:                                 ; preds = %put.pic.dispatch5.126
  %statepoint_token88 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (ptr, double, i64, double, i32)) @js_put_value_set_ic_poly_tail, i32 5, i32 0, ptr @perry_ic_changing_options_worker_ts__9_poly_tail, double %r506, i64 %r521, double %r518, i32 1, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %r63389 = call double @llvm.experimental.gc.result.f64(token %statepoint_token88)
  %rs4gc.s3.relocated90 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token88, i32 0, i32 0) ; (%.13, %.13)
  br label %put.pic.merge.136

put.pic.merge.136:                                ; preds = %put.pic.hit.overflow.137, %put.pic.tail.135, %put.pic.miss4.134, %put.pic.miss3.133, %put.pic.miss2.132, %put.pic.miss.131, %put.pic.deleted.130, %put.pic.hit.store.129
  %.17 = phi ptr addrspace(1) [ %rs4gc.s3.relocated96, %put.pic.hit.overflow.137 ], [ %rs4gc.s3.relocated78, %put.pic.miss.131 ], [ %rs4gc.s3.relocated75, %put.pic.deleted.130 ], [ %.13, %put.pic.hit.store.129 ], [ %rs4gc.s3.relocated81, %put.pic.miss2.132 ], [ %rs4gc.s3.relocated84, %put.pic.miss3.133 ], [ %rs4gc.s3.relocated87, %put.pic.miss4.134 ], [ %rs4gc.s3.relocated90, %put.pic.tail.135 ]
  %r634 = phi double [ %r518, %put.pic.hit.store.129 ], [ %r518, %put.pic.hit.overflow.137 ], [ %r62874, %put.pic.deleted.130 ], [ %r62977, %put.pic.miss.131 ], [ %r63080, %put.pic.miss2.132 ], [ %r63183, %put.pic.miss3.133 ], [ %r63286, %put.pic.miss4.134 ], [ %r63389, %put.pic.tail.135 ]
  %r636 = load double, ptr @perry_global_changing_options_worker_ts__5, align 8
  %r637 = load double, ptr @perry_global_changing_options_worker_ts__2, align 8
  %statepoint_token91 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double, double, double)) @js_json_stringify_full, i32 3, i32 0, double %r636, double 0x7FFC000000000002, double %r637, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.17) ]
  %r63892 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token91)
  %rs4gc.s3.relocated93 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token91, i32 0, i32 0) ; (%.17, %.17)
  %r639 = bitcast i64 %r63892 to double
  %rs4gc.b6 = bitcast double %r639 to i64
  %rs4gc.s6 = inttoptr i64 %rs4gc.b6 to ptr addrspace(1)
  %r640.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r640 = call i64 asm "", "=r,0"(i64 %r640.rs4i) #8
  %r641 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r642 = icmp ne i32 %r641, 0
  br i1 %r642, label %shadow.root.barrier.139, label %shadow.root.barrier.done.140

put.pic.hit.overflow.137:                         ; preds = %put.pic.hit.127
  %r616 = trunc i64 %r613 to i32
  %statepoint_token94 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (double, i64, i32, double)) @js_put_value_set_ic_overflow_store, i32 4, i32 0, double %r506, i64 %r559, i32 %r616, double %r518, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.13) ]
  %r61795 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token94)
  %rs4gc.s3.relocated96 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token94, i32 0, i32 0) ; (%.13, %.13)
  %r618 = icmp ne i32 %r61795, 0
  br i1 %r618, label %put.pic.merge.136, label %put.pic.miss.131

put.pic.hit.inline.138:                           ; preds = %put.pic.hit.127
  %r619 = shl i64 %r613, 3
  %r620 = add nuw nsw i64 %r522, 16
  %r621 = add i64 %r620, %r619
  %r622 = inttoptr i64 %r621 to ptr
  %r623 = and i16 %r541, 1024
  %r624 = icmp ne i16 %r623, 0
  br i1 %r624, label %put.pic.hit.validate.128, label %put.pic.hit.store.129

shadow.root.barrier.139:                          ; preds = %put.pic.merge.136
  call void @js_write_barrier_root_nanbox(i64 %r640) #8
  br label %shadow.root.barrier.done.140

shadow.root.barrier.done.140:                     ; preds = %shadow.root.barrier.139, %put.pic.merge.136
  %r644 = bitcast double %r2.3 to i64
  %rs4gc.s7 = inttoptr i64 %r644 to ptr addrspace(1)
  %r645.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r645 = call i64 asm "", "=r,0"(i64 %r645.rs4i) #8
  %r646 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r647 = icmp ne i32 %r646, 0
  br i1 %r647, label %shadow.root.barrier.141, label %shadow.root.barrier.done.142

shadow.root.barrier.141:                          ; preds = %shadow.root.barrier.done.140
  call void @js_write_barrier_root_nanbox(i64 %r645) #8
  br label %shadow.root.barrier.done.142

shadow.root.barrier.done.142:                     ; preds = %shadow.root.barrier.141, %shadow.root.barrier.done.140
  %r648.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r648.rs4o = call i64 asm "", "=r,0"(i64 %r648.rs4i) #8
  %r648 = bitcast i64 %r648.rs4o to double
  %r649 = bitcast double %r648 to i64
  %r650 = and i64 %r649, 281474976710655
  %r651 = lshr i64 %r649, 48
  %r652 = and i64 %r651, 65533
  %r653 = icmp eq i64 %r652, 32765
  br i1 %r653, label %pget.recv_ok.144, label %pget.recv_other.149

pget.recv_sso.143:                                ; preds = %pget.recv_other.149
  %r792 = lshr i64 %r649, 40
  %r793 = and i64 %r792, 255
  %r794 = uitofp nneg i64 %r793 to double
  br label %pget.recv_merge.147

pget.recv_ok.144:                                 ; preds = %shadow.root.barrier.done.142
  %r660 = icmp eq i64 %r651, 32767
  br i1 %r660, label %pget.strlen_heap.148, label %pget.recv_obj.151

pget.recv_bad.145:                                ; preds = %pget.check_class_ref.150
  %r784 = icmp eq i64 %r649, 9222246136947933185
  %r785 = icmp eq i64 %r649, 9222246136947933186
  %r786 = or i1 %r784, %r785
  br i1 %r786, label %pget.throw_nullish.174, label %pget.recv_undef_return.175

pget.recv_class_ref.146:                          ; preds = %pget.check_class_ref.150
  %r656 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r657 = bitcast double %r656 to i64
  %r658 = and i64 %r657, 281474976710655
  %statepoint_token97 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 1175166488852561930, i64 %r649, i64 %r658, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated93, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r65998 = call double @llvm.experimental.gc.result.f64(token %statepoint_token97)
  %rs4gc.s3.relocated99 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token97, i32 0, i32 0) ; (%rs4gc.s3.relocated93, %rs4gc.s3.relocated93)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token97, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token97, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pget.recv_merge.147

pget.recv_merge.147:                              ; preds = %pget.recv_undef_return.175, %pic.merge.166, %pget.strlen_heap.148, %pget.recv_class_ref.146, %pget.recv_sso.143
  %.0130 = phi ptr addrspace(1) [ %rs4gc.s7, %pget.strlen_heap.148 ], [ %.1131, %pic.merge.166 ], [ %rs4gc.s7, %pget.recv_sso.143 ], [ %rs4gc.s7.relocated, %pget.recv_class_ref.146 ], [ %rs4gc.s7.relocated115, %pget.recv_undef_return.175 ]
  %.0127 = phi ptr addrspace(1) [ %rs4gc.s6, %pget.strlen_heap.148 ], [ %.1128, %pic.merge.166 ], [ %rs4gc.s6, %pget.recv_sso.143 ], [ %rs4gc.s6.relocated, %pget.recv_class_ref.146 ], [ %rs4gc.s6.relocated114, %pget.recv_undef_return.175 ]
  %.18 = phi ptr addrspace(1) [ %rs4gc.s3.relocated93, %pget.strlen_heap.148 ], [ %.19, %pic.merge.166 ], [ %rs4gc.s3.relocated93, %pget.recv_sso.143 ], [ %rs4gc.s3.relocated99, %pget.recv_class_ref.146 ], [ %rs4gc.s3.relocated113, %pget.recv_undef_return.175 ]
  %r800 = phi double [ %r783, %pic.merge.166 ], [ %r791112, %pget.recv_undef_return.175 ], [ %r794, %pget.recv_sso.143 ], [ %r65998, %pget.recv_class_ref.146 ], [ %r799, %pget.strlen_heap.148 ]
  %r801.rs4i = ptrtoint ptr addrspace(1) %.0130 to i64
  %r801 = call i64 asm "", "=r,0"(i64 %r801.rs4i) #8
  %r802 = bitcast i64 %r801 to double
  %r803 = and i64 %r801, -281474976710656
  %r804 = icmp ult i64 %r803, 9221401712017801216
  %r805 = icmp ugt i64 %r803, 9223090561878065152
  %r806 = or i1 %r804, %r805
  %r807 = bitcast double %r800 to i64
  %r808 = and i64 %r807, -281474976710656
  %r809 = icmp ult i64 %r808, 9221401712017801216
  %r810 = icmp ugt i64 %r808, 9223090561878065152
  %r811 = or i1 %r809, %r810
  %r812 = and i1 %r806, %r811
  br i1 %r812, label %guarded_add.numeric.176, label %guarded_add.dynamic.177

pget.strlen_heap.148:                             ; preds = %pget.recv_ok.144
  %r795 = icmp ult i64 %r650, 4096
  %r796 = inttoptr i64 %r650 to ptr
  %r797 = select i1 %r795, ptr @perry_null_guard_zero_changing_options_worker_ts, ptr %r796
  %r798 = load i32, ptr %r797, align 4
  %r799 = uitofp i32 %r798 to double
  br label %pget.recv_merge.147

pget.recv_other.149:                              ; preds = %shadow.root.barrier.done.142
  %r654 = icmp eq i64 %r651, 32761
  br i1 %r654, label %pget.recv_sso.143, label %pget.check_class_ref.150

pget.check_class_ref.150:                         ; preds = %pget.recv_other.149
  %r655 = icmp eq i64 %r651, 32766
  br i1 %r655, label %pget.recv_class_ref.146, label %pget.recv_bad.145

pget.recv_obj.151:                                ; preds = %pget.recv_ok.144
  %r661 = icmp ugt i64 %r650, 1048575
  br i1 %r661, label %pic.recv_hdr.167, label %pic.miss.cold.164

pic.hit.152:                                      ; preds = %pic.token.168
  %r686 = getelementptr i64, ptr %r671, i64 1
  %r687 = load i64, ptr %r686, align 8
  %r688 = and i64 %r687, 1073741824
  %r689 = icmp ne i64 %r688, 0
  br i1 %r689, label %pic.hit.overflow.169, label %pic.hit.inline.170

pic.hit.live.153:                                 ; preds = %pic.hit.inline.170
  br label %pic.merge.166

pic.prefix.guard.154:                             ; preds = %pic.token.168
  %r702 = getelementptr i64, ptr %r671, i64 2
  %r703 = load i64, ptr %r702, align 8
  %r704 = icmp ne i64 %r703, 0
  br i1 %r704, label %pic.prefix.meta.155, label %pic.miss.163

pic.prefix.meta.155:                              ; preds = %pic.prefix.guard.154
  %r705 = add nuw nsw i64 %r650, 8
  %r706 = inttoptr i64 %r705 to ptr
  %r707 = load i64, ptr %r706, align 8
  %r708 = icmp ne i64 %r707, 0
  br i1 %r708, label %pic.prefix.token.156, label %pic.miss.163

pic.prefix.token.156:                             ; preds = %pic.prefix.meta.155
  %r709 = inttoptr i64 %r707 to ptr
  %r710 = getelementptr i64, ptr %r709, i64 6
  %r711 = load i64, ptr %r710, align 8
  %r712 = icmp eq i64 %r711, %r703
  br i1 %r712, label %pic.prefix.hit.157, label %pic.miss.163

pic.prefix.hit.157:                               ; preds = %pic.prefix.token.156
  %r713 = getelementptr i64, ptr %r671, i64 1
  %r714 = load i64, ptr %r713, align 8
  %r715 = shl i64 %r714, 3
  %r716 = add nuw nsw i64 %r650, 16
  %r717 = add i64 %r716, %r715
  %r718 = inttoptr i64 %r717 to ptr
  %r719 = load double, ptr %r718, align 8
  br label %pic.merge.166

pic.desc.classify.158:                            ; preds = %pic.recv_hdr.167
  %r675 = and i1 %r665, %r672
  br i1 %r675, label %pic.desc.prefix.guard.159, label %pic.miss.cold.164

pic.desc.prefix.guard.159:                        ; preds = %pic.desc.classify.158
  %r720 = getelementptr i64, ptr %r671, i64 2
  %r721 = load i64, ptr %r720, align 8
  %r722 = icmp ne i64 %r721, 0
  br i1 %r722, label %pic.desc.prefix.meta.160, label %pic.miss.cold.164

pic.desc.prefix.meta.160:                         ; preds = %pic.desc.prefix.guard.159
  %r723 = add nuw nsw i64 %r650, 8
  %r724 = inttoptr i64 %r723 to ptr
  %r725 = load i64, ptr %r724, align 8
  %r726 = icmp ne i64 %r725, 0
  br i1 %r726, label %pic.desc.prefix.token.161, label %pic.miss.cold.164

pic.desc.prefix.token.161:                        ; preds = %pic.desc.prefix.meta.160
  %r727 = inttoptr i64 %r725 to ptr
  %r728 = getelementptr i64, ptr %r727, i64 6
  %r729 = load i64, ptr %r728, align 8
  %r730 = icmp eq i64 %r729, %r721
  br i1 %r730, label %pic.desc.prefix.hit.162, label %pic.miss.cold.164

pic.desc.prefix.hit.162:                          ; preds = %pic.desc.prefix.token.161
  %r731 = getelementptr i64, ptr %r671, i64 1
  %r732 = load i64, ptr %r731, align 8
  %r733 = shl i64 %r732, 3
  %r734 = add nuw nsw i64 %r650, 16
  %r735 = add i64 %r734, %r733
  %r736 = inttoptr i64 %r735 to ptr
  %r737 = load double, ptr %r736, align 8
  br label %pic.merge.166

pic.miss.163:                                     ; preds = %pic.hit.inline.170, %pic.prefix.token.156, %pic.prefix.meta.155, %pic.prefix.guard.154
  %r738 = getelementptr i64, ptr %r671, i64 3
  %r739 = load i64, ptr %r738, align 8
  %r740 = icmp sgt i64 %r739, 0
  br i1 %r740, label %pic.ways.171, label %pic.miss.call.165

pic.miss.cold.164:                                ; preds = %pic.desc.prefix.token.161, %pic.desc.prefix.meta.160, %pic.desc.prefix.guard.159, %pic.desc.classify.158, %pget.recv_obj.151
  br label %pic.miss.call.165

pic.miss.call.165:                                ; preds = %pic.way.load.172, %pic.ways.171, %pic.miss.cold.164, %pic.miss.163
  %r779 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r780 = bitcast double %r779 to i64
  %r781 = and i64 %r780, 281474976710655
  %statepoint_token100 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r650, i64 %r781, ptr @perry_ic_changing_options_worker_ts__11, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated93, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r782101 = call double @llvm.experimental.gc.result.f64(token %statepoint_token100)
  %rs4gc.s3.relocated102 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 0, i32 0) ; (%rs4gc.s3.relocated93, %rs4gc.s3.relocated93)
  %rs4gc.s6.relocated103 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated104 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token100, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pic.merge.166

pic.merge.166:                                    ; preds = %pic.way.live.173, %pic.hit.overflow.169, %pic.miss.call.165, %pic.desc.prefix.hit.162, %pic.prefix.hit.157, %pic.hit.live.153
  %.1131 = phi ptr addrspace(1) [ %rs4gc.s7.relocated109, %pic.hit.overflow.169 ], [ %rs4gc.s7.relocated104, %pic.miss.call.165 ], [ %rs4gc.s7, %pic.way.live.173 ], [ %rs4gc.s7, %pic.hit.live.153 ], [ %rs4gc.s7, %pic.prefix.hit.157 ], [ %rs4gc.s7, %pic.desc.prefix.hit.162 ]
  %.1128 = phi ptr addrspace(1) [ %rs4gc.s6.relocated108, %pic.hit.overflow.169 ], [ %rs4gc.s6.relocated103, %pic.miss.call.165 ], [ %rs4gc.s6, %pic.way.live.173 ], [ %rs4gc.s6, %pic.hit.live.153 ], [ %rs4gc.s6, %pic.prefix.hit.157 ], [ %rs4gc.s6, %pic.desc.prefix.hit.162 ]
  %.19 = phi ptr addrspace(1) [ %rs4gc.s3.relocated107, %pic.hit.overflow.169 ], [ %rs4gc.s3.relocated102, %pic.miss.call.165 ], [ %rs4gc.s3.relocated93, %pic.way.live.173 ], [ %rs4gc.s3.relocated93, %pic.hit.live.153 ], [ %rs4gc.s3.relocated93, %pic.prefix.hit.157 ], [ %rs4gc.s3.relocated93, %pic.desc.prefix.hit.162 ]
  %r783 = phi double [ %r699, %pic.hit.live.153 ], [ %r694106, %pic.hit.overflow.169 ], [ %r719, %pic.prefix.hit.157 ], [ %r737, %pic.desc.prefix.hit.162 ], [ %r776, %pic.way.live.173 ], [ %r782101, %pic.miss.call.165 ]
  br label %pget.recv_merge.147

pic.recv_hdr.167:                                 ; preds = %pget.recv_obj.151
  %r662 = sub nuw nsw i64 %r650, 8
  %r663 = inttoptr i64 %r662 to ptr
  %r664 = load i8, ptr %r663, align 1
  %r665 = icmp eq i8 %r664, 2
  %r666 = sub nuw nsw i64 %r650, 6
  %r667 = inttoptr i64 %r666 to ptr
  %r668 = load i16, ptr %r667, align 2
  %r669 = and i16 %r668, 2048
  %r670 = icmp eq i16 %r669, 0
  %r671 = load ptr, ptr @perry_ic_changing_options_worker_ts__11, align 8
  %r672 = icmp ne ptr %r671, null
  %r673 = and i1 %r665, %r670
  %r674 = and i1 %r673, %r672
  br i1 %r674, label %pic.token.168, label %pic.desc.classify.158

pic.token.168:                                    ; preds = %pic.recv_hdr.167
  %r676 = add nuw nsw i64 %r650, 4
  %r677 = inttoptr i64 %r676 to ptr
  %r678 = load i32, ptr %r677, align 4
  %r679 = zext i32 %r678 to i64
  %r680 = or i64 %r679, 4611686018427387904
  %r681 = icmp ne i32 %r678, 0
  %r682 = getelementptr i64, ptr %r671, i64 0
  %r683 = load i64, ptr %r682, align 8
  %r684 = icmp eq i64 %r680, %r683
  %r685 = and i1 %r684, %r681
  br i1 %r685, label %pic.hit.152, label %pic.prefix.guard.154

pic.hit.overflow.169:                             ; preds = %pic.hit.152
  %r690 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r691 = bitcast double %r690 to i64
  %r692 = and i64 %r691, 281474976710655
  %r693 = trunc i64 %r687 to i32
  %statepoint_token105 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r650, i64 %r692, i32 %r693, ptr @perry_ic_changing_options_worker_ts__11, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated93, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r694106 = call double @llvm.experimental.gc.result.f64(token %statepoint_token105)
  %rs4gc.s3.relocated107 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 0, i32 0) ; (%rs4gc.s3.relocated93, %rs4gc.s3.relocated93)
  %rs4gc.s6.relocated108 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated109 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token105, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pic.merge.166

pic.hit.inline.170:                               ; preds = %pic.hit.152
  %r695 = shl i64 %r687, 3
  %r696 = add nuw nsw i64 %r650, 16
  %r697 = add i64 %r696, %r695
  %r698 = inttoptr i64 %r697 to ptr
  %r699 = load double, ptr %r698, align 8
  %r700 = bitcast double %r699 to i64
  %r701 = icmp eq i64 %r700, 9222246136947933200
  br i1 %r701, label %pic.miss.163, label %pic.hit.live.153

pic.ways.171:                                     ; preds = %pic.miss.163
  %r741 = getelementptr i64, ptr %r671, i64 4
  %r742 = load i64, ptr %r741, align 8
  %r743 = icmp eq i64 %r742, %r680
  %r744 = getelementptr i64, ptr %r671, i64 5
  %r745 = load i64, ptr %r744, align 8
  %r746 = select i1 %r743, i64 %r745, i64 0
  %r747 = getelementptr i64, ptr %r671, i64 6
  %r748 = load i64, ptr %r747, align 8
  %r749 = icmp eq i64 %r748, %r680
  %r750 = getelementptr i64, ptr %r671, i64 7
  %r751 = load i64, ptr %r750, align 8
  %r752 = select i1 %r749, i64 %r751, i64 0
  %r753 = getelementptr i64, ptr %r671, i64 8
  %r754 = load i64, ptr %r753, align 8
  %r755 = icmp eq i64 %r754, %r680
  %r756 = getelementptr i64, ptr %r671, i64 9
  %r757 = load i64, ptr %r756, align 8
  %r758 = select i1 %r755, i64 %r757, i64 0
  %r759 = getelementptr i64, ptr %r671, i64 10
  %r760 = load i64, ptr %r759, align 8
  %r761 = icmp eq i64 %r760, %r680
  %r762 = getelementptr i64, ptr %r671, i64 11
  %r763 = load i64, ptr %r762, align 8
  %r764 = select i1 %r761, i64 %r763, i64 0
  %r765 = or i1 %r743, %r749
  %r766 = select i1 %r743, i64 %r746, i64 %r752
  %r767 = or i1 %r755, %r761
  %r768 = select i1 %r755, i64 %r758, i64 %r764
  %r769 = or i1 %r765, %r767
  %r770 = select i1 %r765, i64 %r766, i64 %r768
  %r771 = and i1 %r681, %r769
  br i1 %r771, label %pic.way.load.172, label %pic.miss.call.165

pic.way.load.172:                                 ; preds = %pic.ways.171
  %r772 = shl i64 %r770, 3
  %r773 = add nuw nsw i64 %r650, 16
  %r774 = add i64 %r773, %r772
  %r775 = inttoptr i64 %r774 to ptr
  %r776 = load double, ptr %r775, align 8
  %r777 = bitcast double %r776 to i64
  %r778 = icmp eq i64 %r777, 9222246136947933200
  br i1 %r778, label %pic.miss.call.165, label %pic.way.live.173

pic.way.live.173:                                 ; preds = %pic.way.load.172
  br label %pic.merge.166

pget.throw_nullish.174:                           ; preds = %pget.recv_bad.145
  %r787 = zext i1 %r785 to i32
  %statepoint_token110 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r787, ptr @changing_options_worker_ts_.str.2.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.175:                       ; preds = %pget.recv_bad.145
  %r788 = load double, ptr @changing_options_worker_ts_.str.2.handle, align 8
  %r789 = bitcast double %r788 to i64
  %r790 = and i64 %r789, 281474976710655
  %statepoint_token111 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r649, i64 %r790, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s3.relocated93, ptr addrspace(1) %rs4gc.s6, ptr addrspace(1) %rs4gc.s7) ]
  %r791112 = call double @llvm.experimental.gc.result.f64(token %statepoint_token111)
  %rs4gc.s3.relocated113 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token111, i32 0, i32 0) ; (%rs4gc.s3.relocated93, %rs4gc.s3.relocated93)
  %rs4gc.s6.relocated114 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token111, i32 1, i32 1) ; (%rs4gc.s6, %rs4gc.s6)
  %rs4gc.s7.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token111, i32 2, i32 2) ; (%rs4gc.s7, %rs4gc.s7)
  br label %pget.recv_merge.147

guarded_add.numeric.176:                          ; preds = %pget.recv_merge.147
  %r813 = fadd double %r802, %r800
  br label %guarded_add.merge.178

guarded_add.dynamic.177:                          ; preds = %pget.recv_merge.147
  %statepoint_token116 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r802, double %r800, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.18, ptr addrspace(1) %.0127) ]
  %r814117 = call double @llvm.experimental.gc.result.f64(token %statepoint_token116)
  %rs4gc.s3.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 0, i32 0) ; (%.18, %.18)
  %rs4gc.s6.relocated119 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 1, i32 1) ; (%.0127, %.0127)
  br label %guarded_add.merge.178

guarded_add.merge.178:                            ; preds = %guarded_add.dynamic.177, %guarded_add.numeric.176
  %.2129 = phi ptr addrspace(1) [ %.0127, %guarded_add.numeric.176 ], [ %rs4gc.s6.relocated119, %guarded_add.dynamic.177 ]
  %.20 = phi ptr addrspace(1) [ %.18, %guarded_add.numeric.176 ], [ %rs4gc.s3.relocated118, %guarded_add.dynamic.177 ]
  %r815 = phi double [ %r813, %guarded_add.numeric.176 ], [ %r814117, %guarded_add.dynamic.177 ]
  %r816.rs4i = ptrtoint ptr addrspace(1) %.2129 to i64
  %r816.rs4o = call i64 asm "", "=r,0"(i64 %r816.rs4i) #8
  %r816 = bitcast i64 %r816.rs4o to double
  %r817 = bitcast double %r816 to i64
  %r818 = and i64 %r817, -281474976710656
  %r819 = icmp ne i64 %r818, 9223090561878065152
  br i1 %r819, label %str_addref.done.180, label %str_addref.call.179

str_addref.call.179:                              ; preds = %guarded_add.merge.178
  call void @js_string_addref_if_heap_string(double %r816) #8
  br label %str_addref.done.180

str_addref.done.180:                              ; preds = %str_addref.call.179, %guarded_add.merge.178
  %r831.rs4i = ptrtoint ptr addrspace(1) %.2129 to i64
  %r831.rs4o = call i64 asm "", "=r,0"(i64 %r831.rs4i) #8
  %r831 = bitcast i64 %r831.rs4o to double
  store double %r831, ptr @perry_global_changing_options_worker_ts__6, align 8
  %r830.rs4i = ptrtoint ptr addrspace(1) %.2129 to i64
  %r830.rs4o = call i64 asm "", "=r,0"(i64 %r830.rs4i) #8
  %r830 = bitcast i64 %r830.rs4o to double
  %r820 = bitcast double %r830 to i64
  %r828.rs4i = ptrtoint ptr addrspace(1) %.2129 to i64
  %r828.rs4o = call i64 asm "", "=r,0"(i64 %r828.rs4i) #8
  %r828 = bitcast i64 %r828.rs4o to double
  %r829 = bitcast double %r828 to i64
  call void @js_write_barrier_root_nanbox(i64 %r829) #8
  %r821 = load volatile i32, ptr @PERRY_GC_POLL_ARMED, align 4
  %r822 = icmp ne i32 %r821, 0
  br i1 %r822, label %gcpoll.181, label %gcpoll.done.182

gcpoll.181:                                       ; preds = %str_addref.done.180
  %statepoint_token120 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_loop_safepoint, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.20) ]
  %rs4gc.s3.relocated121 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token120, i32 0, i32 0) ; (%.20, %.20)
  br label %gcpoll.done.182

gcpoll.done.182:                                  ; preds = %gcpoll.181, %str_addref.done.180
  %.21 = phi ptr addrspace(1) [ %rs4gc.s3.relocated121, %gcpoll.181 ], [ %.20, %str_addref.done.180 ]
  br label %for.update.110
}

; Function Attrs: noinline optsize
define double @perry_fn_changing_options_worker_ts__run(double %arg13) #7 {
entry.0:
  %r1 = bitcast double %arg13 to i64
  %r2 = lshr i64 %r1, 48
  %r3 = icmp ult i64 %r2, 32761
  %r4 = icmp ugt i64 %r2, 32767
  %r5 = or i1 %r3, %r4
  %r6 = and i64 %r1, -4294967296
  %r7 = icmp eq i64 %r6, 9222809086901354496
  %r8 = or i1 %r5, %r7
  br i1 %r8, label %spec_public.fast.1, label %spec_public.fallback.2

spec_public.fast.1:                               ; preds = %entry.0
  %r9 = call double @"perry_fn_changing_options_worker_ts__run$spec_b"(double %arg13)
  ret double %r9

spec_public.fallback.2:                           ; preds = %entry.0
  %r10 = call double @"perry_fn_changing_options_worker_ts__run$generic"(double %arg13)
  ret double %r10
}

; Function Attrs: optsize
define double @__perry_wrap_perry_fn_changing_options_worker_ts__run(i64 %this_closure, double %a0) #6 {
entry.0:
  %r1 = call double @perry_fn_changing_options_worker_ts__run(double %a0)
  ret double %r1
}

; Function Attrs: optsize
define internal double @__perry_wrap_perry_unknown_func_changing_options_worker_ts(i64 %this_closure, double %a0, double %a1, double %a2, double %a3, double %a4) #6 {
entry.0:
  ret double 0x7FFC000000000001
}

; Function Attrs: optsize
define void @changing_options_worker_ts__init() #6 {
entry.0:
  ret void
}

; Function Attrs: optsize
define i32 @main() #6 gc "statepoint-example" {
entry.0:
  %r415 = alloca [32 x double], align 8
  %statepoint_token = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (ptr, i32)) @js_set_process_entry_path, i32 2, i32 0, ptr @changing_options_worker_ts_.str.0, i32 125, i32 0, i32 0)
  %statepoint_token1 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_init, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token2 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32)) @js_gc_write_barriers_emitted, i32 1, i32 0, i32 1, i32 0, i32 0)
  %statepoint_token3 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @perry_macos_bundle_chdir, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token4 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @__perry_init_strings_changing_options_worker_ts, i32 0, i32 0, i32 0, i32 0)
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_changing_options_worker_ts__1 to i64)) #8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_changing_options_worker_ts__2 to i64)) #8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_changing_options_worker_ts__5 to i64)) #8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @perry_global_changing_options_worker_ts__6 to i64)) #8
  %statepoint_token5 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_mark_entry_module_esm, i32 0, i32 0, i32 0, i32 0)
  %r5 = load double, ptr @changing_options_worker_ts_.str.4.handle, align 8
  %r6 = load double, ptr @changing_options_worker_ts_.str.5.handle, align 8
  %statepoint_token6 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_native_module_named_esm_export_value, i32 2, i32 0, double %r5, double %r6, i32 0, i32 0)
  %statepoint_token7 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0)
  %r952 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token7)
  %r10 = or i64 %r952, 9222527611924643840
  %r11 = bitcast i64 %r10 to double
  %r12 = and i64 %r10, 281474976710655
  %r13 = lshr i64 %r10, 48
  %r14 = icmp eq i64 %r13, 32765
  %r15 = icmp ugt i64 %r12, 1048575
  %r16 = and i1 %r14, %r15
  br i1 %r16, label %arr.guard.deref.5, label %arr.fallback.2

arr.fast.1:                                       ; preds = %arr.guard.range.7
  %r75 = add i64 %r31, 24
  %r76 = inttoptr i64 %r75 to ptr
  %r77 = load double, ptr %r76, align 8
  %r78 = bitcast double %r77 to i64
  %r79 = icmp eq i64 %r78, 9222246136947933200
  %r81 = select i1 %r79, double 0x7FFC000000000001, double %r77
  br label %arr.merge.4

arr.fallback.2:                                   ; preds = %arr.guard.live.6, %arr.guard.deref.5, %entry.0
  %statepoint_token53 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 1175166488852561932, double %r11, double 2.000000e+00, i32 0, i32 0)
  %r7154 = call double @llvm.experimental.gc.result.f64(token %statepoint_token53)
  br label %arr.merge.4

arr.guard.oob.3:                                  ; preds = %arr.guard.range.7
  br label %arr.merge.4

arr.merge.4:                                      ; preds = %arr.guard.oob.3, %arr.fallback.2, %arr.fast.1
  %r82 = phi double [ %r81, %arr.fast.1 ], [ %r7154, %arr.fallback.2 ], [ 0x7FFC000000000001, %arr.guard.oob.3 ]
  %r83 = load double, ptr @changing_options_worker_ts_.str.6.handle, align 8
  %statepoint_token55 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_fs_read_file_dispatch, i32 2, i32 0, double %r82, double %r83, i32 0, i32 0)
  %r8456 = call double @llvm.experimental.gc.result.f64(token %statepoint_token55)
  %rs4gc.b6 = bitcast double %r8456 to i64
  %rs4gc.s6 = inttoptr i64 %rs4gc.b6 to ptr addrspace(1)
  %r85.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6 to i64
  %r85 = call i64 asm "", "=r,0"(i64 %r85.rs4i) #8
  %r86 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r87 = icmp ne i32 %r86, 0
  br i1 %r87, label %shadow.root.barrier.8, label %shadow.root.barrier.done.9

arr.guard.deref.5:                                ; preds = %entry.0
  %r17 = bitcast double %r11 to i64
  %r18 = and i64 %r17, 281474976710655
  %r19 = sub nsw i64 %r18, 8
  %r20 = inttoptr i64 %r19 to ptr
  %r21 = load i8, ptr %r20, align 1
  %r22 = icmp eq i8 %r21, 1
  %r23 = sub nsw i64 %r18, 7
  %r24 = inttoptr i64 %r23 to ptr
  %r25 = load i8, ptr %r24, align 1
  %r26 = and i8 %r25, -128
  %r27 = icmp ne i8 %r26, 0
  %r28 = inttoptr i64 %r18 to ptr
  %r29 = load i64, ptr %r28, align 8
  %r30 = and i1 %r22, %r27
  %r31 = select i1 %r30, i64 %r29, i64 %r18
  %r32 = lshr i64 %r31, 48
  %r33 = icmp eq i64 %r32, 0
  %r34 = icmp ugt i64 %r31, 1048575
  %r35 = and i1 %r33, %r34
  br i1 %r35, label %arr.guard.live.6, label %arr.fallback.2

arr.guard.live.6:                                 ; preds = %arr.guard.deref.5
  %r36 = sub nuw i64 %r31, 8
  %r37 = inttoptr i64 %r36 to ptr
  %r38 = load i8, ptr %r37, align 1
  %r39 = icmp eq i8 %r38, 1
  %r40 = sub nuw i64 %r31, 7
  %r41 = inttoptr i64 %r40 to ptr
  %r42 = load i8, ptr %r41, align 1
  %r43 = and i8 %r42, -128
  %r44 = icmp eq i8 %r43, 0
  %r45 = sub nuw i64 %r31, 6
  %r46 = inttoptr i64 %r45 to ptr
  %r47 = load i16, ptr %r46, align 2
  %r48 = and i16 %r47, 1024
  %r49 = icmp eq i16 %r48, 0
  %r50 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r51 = icmp eq i8 %r50, 0
  %r52 = inttoptr i64 %r31 to ptr
  %r53 = load i32, ptr %r52, align 4
  %r54 = getelementptr i8, ptr %r52, i64 4
  %r55 = load i32, ptr %r54, align 4
  %r59 = icmp ule i32 %r53, 16000000
  %r60 = icmp ule i32 %r55, 16000000
  %r61 = icmp ule i32 %r53, %r55
  %r62 = and i1 %r39, %r44
  %r63 = and i1 %r62, %r49
  %r64 = and i1 %r63, %r51
  %r66 = and i1 %r64, %r59
  %r67 = and i1 %r66, %r60
  %r68 = and i1 %r67, %r61
  br i1 %r68, label %arr.guard.range.7, label %arr.fallback.2

arr.guard.range.7:                                ; preds = %arr.guard.live.6
  %r58 = icmp ult i32 2, %r53
  br i1 %r58, label %arr.fast.1, label %arr.guard.oob.3

shadow.root.barrier.8:                            ; preds = %arr.merge.4
  call void @js_write_barrier_root_nanbox(i64 %r85) #8
  br label %shadow.root.barrier.done.9

shadow.root.barrier.done.9:                       ; preds = %shadow.root.barrier.8, %arr.merge.4
  %statepoint_token57 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6) ]
  %r8858 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token57)
  %rs4gc.s6.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token57, i32 0, i32 0) ; (%rs4gc.s6, %rs4gc.s6)
  %r89 = or i64 %r8858, 9222527611924643840
  %r90 = bitcast i64 %r89 to double
  %r91 = and i64 %r89, 281474976710655
  %r92 = lshr i64 %r89, 48
  %r93 = icmp eq i64 %r92, 32765
  %r94 = icmp ugt i64 %r91, 1048575
  %r95 = and i1 %r93, %r94
  br i1 %r95, label %arr.guard.deref.14, label %arr.fallback.11

arr.fast.10:                                      ; preds = %arr.guard.range.16
  %r154 = add i64 %r110, 32
  %r155 = inttoptr i64 %r154 to ptr
  %r156 = load double, ptr %r155, align 8
  %r157 = bitcast double %r156 to i64
  %r158 = icmp eq i64 %r157, 9222246136947933200
  %r160 = select i1 %r158, double 0x7FFC000000000001, double %r156
  br label %arr.merge.13

arr.fallback.11:                                  ; preds = %arr.guard.live.15, %arr.guard.deref.14, %shadow.root.barrier.done.9
  %statepoint_token59 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 1175166488852561933, double %r90, double 3.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated) ]
  %r15060 = call double @llvm.experimental.gc.result.f64(token %statepoint_token59)
  %rs4gc.s6.relocated61 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token59, i32 0, i32 0) ; (%rs4gc.s6.relocated, %rs4gc.s6.relocated)
  br label %arr.merge.13

arr.guard.oob.12:                                 ; preds = %arr.guard.range.16
  br label %arr.merge.13

arr.merge.13:                                     ; preds = %arr.guard.oob.12, %arr.fallback.11, %arr.fast.10
  %.0 = phi ptr addrspace(1) [ %rs4gc.s6.relocated, %arr.fast.10 ], [ %rs4gc.s6.relocated, %arr.guard.oob.12 ], [ %rs4gc.s6.relocated61, %arr.fallback.11 ]
  %r161 = phi double [ %r160, %arr.fast.10 ], [ %r15060, %arr.fallback.11 ], [ 0x7FFC000000000001, %arr.guard.oob.12 ]
  store double %r161, ptr @perry_global_changing_options_worker_ts__1, align 8
  %r162 = bitcast double %r161 to i64
  call void @js_write_barrier_root_nanbox(i64 %r162) #8
  %statepoint_token62 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0) ]
  %r16363 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token62)
  %rs4gc.s6.relocated64 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token62, i32 0, i32 0) ; (%.0, %.0)
  %r164 = or i64 %r16363, 9222527611924643840
  %r165 = bitcast i64 %r164 to double
  %r166 = and i64 %r164, 281474976710655
  %r167 = lshr i64 %r164, 48
  %r168 = icmp eq i64 %r167, 32765
  %r169 = icmp ugt i64 %r166, 1048575
  %r170 = and i1 %r168, %r169
  br i1 %r170, label %arr.guard.deref.21, label %arr.fallback.18

arr.guard.deref.14:                               ; preds = %shadow.root.barrier.done.9
  %r96 = bitcast double %r90 to i64
  %r97 = and i64 %r96, 281474976710655
  %r98 = sub nsw i64 %r97, 8
  %r99 = inttoptr i64 %r98 to ptr
  %r100 = load i8, ptr %r99, align 1
  %r101 = icmp eq i8 %r100, 1
  %r102 = sub nsw i64 %r97, 7
  %r103 = inttoptr i64 %r102 to ptr
  %r104 = load i8, ptr %r103, align 1
  %r105 = and i8 %r104, -128
  %r106 = icmp ne i8 %r105, 0
  %r107 = inttoptr i64 %r97 to ptr
  %r108 = load i64, ptr %r107, align 8
  %r109 = and i1 %r101, %r106
  %r110 = select i1 %r109, i64 %r108, i64 %r97
  %r111 = lshr i64 %r110, 48
  %r112 = icmp eq i64 %r111, 0
  %r113 = icmp ugt i64 %r110, 1048575
  %r114 = and i1 %r112, %r113
  br i1 %r114, label %arr.guard.live.15, label %arr.fallback.11

arr.guard.live.15:                                ; preds = %arr.guard.deref.14
  %r115 = sub nuw i64 %r110, 8
  %r116 = inttoptr i64 %r115 to ptr
  %r117 = load i8, ptr %r116, align 1
  %r118 = icmp eq i8 %r117, 1
  %r119 = sub nuw i64 %r110, 7
  %r120 = inttoptr i64 %r119 to ptr
  %r121 = load i8, ptr %r120, align 1
  %r122 = and i8 %r121, -128
  %r123 = icmp eq i8 %r122, 0
  %r124 = sub nuw i64 %r110, 6
  %r125 = inttoptr i64 %r124 to ptr
  %r126 = load i16, ptr %r125, align 2
  %r127 = and i16 %r126, 1024
  %r128 = icmp eq i16 %r127, 0
  %r129 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r130 = icmp eq i8 %r129, 0
  %r131 = inttoptr i64 %r110 to ptr
  %r132 = load i32, ptr %r131, align 4
  %r133 = getelementptr i8, ptr %r131, i64 4
  %r134 = load i32, ptr %r133, align 4
  %r138 = icmp ule i32 %r132, 16000000
  %r139 = icmp ule i32 %r134, 16000000
  %r140 = icmp ule i32 %r132, %r134
  %r141 = and i1 %r118, %r123
  %r142 = and i1 %r141, %r128
  %r143 = and i1 %r142, %r130
  %r145 = and i1 %r143, %r138
  %r146 = and i1 %r145, %r139
  %r147 = and i1 %r146, %r140
  br i1 %r147, label %arr.guard.range.16, label %arr.fallback.11

arr.guard.range.16:                               ; preds = %arr.guard.live.15
  %r137 = icmp ult i32 3, %r132
  br i1 %r137, label %arr.fast.10, label %arr.guard.oob.12

arr.fast.17:                                      ; preds = %arr.guard.range.23
  %r229 = add i64 %r185, 64
  %r230 = inttoptr i64 %r229 to ptr
  %r231 = load double, ptr %r230, align 8
  %r232 = bitcast double %r231 to i64
  %r233 = icmp eq i64 %r232, 9222246136947933200
  %r235 = select i1 %r233, double 0x7FFC000000000001, double %r231
  br label %arr.merge.20

arr.fallback.18:                                  ; preds = %arr.guard.live.22, %arr.guard.deref.21, %arr.merge.13
  %statepoint_token65 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 1175166488852561934, double %r165, double 7.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated64) ]
  %r22566 = call double @llvm.experimental.gc.result.f64(token %statepoint_token65)
  %rs4gc.s6.relocated67 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token65, i32 0, i32 0) ; (%rs4gc.s6.relocated64, %rs4gc.s6.relocated64)
  br label %arr.merge.20

arr.guard.oob.19:                                 ; preds = %arr.guard.range.23
  br label %arr.merge.20

arr.merge.20:                                     ; preds = %arr.guard.oob.19, %arr.fallback.18, %arr.fast.17
  %.1 = phi ptr addrspace(1) [ %rs4gc.s6.relocated64, %arr.fast.17 ], [ %rs4gc.s6.relocated64, %arr.guard.oob.19 ], [ %rs4gc.s6.relocated67, %arr.fallback.18 ]
  %r236 = phi double [ %r235, %arr.fast.17 ], [ %r22566, %arr.fallback.18 ], [ 0x7FFC000000000001, %arr.guard.oob.19 ]
  %r237 = bitcast double %r236 to i64
  %r238 = and i64 %r237, 9221120237041090560
  %r239 = icmp ne i64 %r238, 9221120237041090560
  br i1 %r239, label %truthy.num.24, label %truthy.tag.25

arr.guard.deref.21:                               ; preds = %arr.merge.13
  %r171 = bitcast double %r165 to i64
  %r172 = and i64 %r171, 281474976710655
  %r173 = sub nsw i64 %r172, 8
  %r174 = inttoptr i64 %r173 to ptr
  %r175 = load i8, ptr %r174, align 1
  %r176 = icmp eq i8 %r175, 1
  %r177 = sub nsw i64 %r172, 7
  %r178 = inttoptr i64 %r177 to ptr
  %r179 = load i8, ptr %r178, align 1
  %r180 = and i8 %r179, -128
  %r181 = icmp ne i8 %r180, 0
  %r182 = inttoptr i64 %r172 to ptr
  %r183 = load i64, ptr %r182, align 8
  %r184 = and i1 %r176, %r181
  %r185 = select i1 %r184, i64 %r183, i64 %r172
  %r186 = lshr i64 %r185, 48
  %r187 = icmp eq i64 %r186, 0
  %r188 = icmp ugt i64 %r185, 1048575
  %r189 = and i1 %r187, %r188
  br i1 %r189, label %arr.guard.live.22, label %arr.fallback.18

arr.guard.live.22:                                ; preds = %arr.guard.deref.21
  %r190 = sub nuw i64 %r185, 8
  %r191 = inttoptr i64 %r190 to ptr
  %r192 = load i8, ptr %r191, align 1
  %r193 = icmp eq i8 %r192, 1
  %r194 = sub nuw i64 %r185, 7
  %r195 = inttoptr i64 %r194 to ptr
  %r196 = load i8, ptr %r195, align 1
  %r197 = and i8 %r196, -128
  %r198 = icmp eq i8 %r197, 0
  %r199 = sub nuw i64 %r185, 6
  %r200 = inttoptr i64 %r199 to ptr
  %r201 = load i16, ptr %r200, align 2
  %r202 = and i16 %r201, 1024
  %r203 = icmp eq i16 %r202, 0
  %r204 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r205 = icmp eq i8 %r204, 0
  %r206 = inttoptr i64 %r185 to ptr
  %r207 = load i32, ptr %r206, align 4
  %r208 = getelementptr i8, ptr %r206, i64 4
  %r209 = load i32, ptr %r208, align 4
  %r213 = icmp ule i32 %r207, 16000000
  %r214 = icmp ule i32 %r209, 16000000
  %r215 = icmp ule i32 %r207, %r209
  %r216 = and i1 %r193, %r198
  %r217 = and i1 %r216, %r203
  %r218 = and i1 %r217, %r205
  %r220 = and i1 %r218, %r213
  %r221 = and i1 %r220, %r214
  %r222 = and i1 %r221, %r215
  br i1 %r222, label %arr.guard.range.23, label %arr.fallback.18

arr.guard.range.23:                               ; preds = %arr.guard.live.22
  %r212 = icmp ult i32 7, %r207
  br i1 %r212, label %arr.fast.17, label %arr.guard.oob.19

truthy.num.24:                                    ; preds = %arr.merge.20
  %r240 = fcmp one double %r236, 0.000000e+00
  br label %truthy.merge.27

truthy.tag.25:                                    ; preds = %arr.merge.20
  %r241 = icmp eq i64 %r237, 9222246136947933188
  %r242 = icmp eq i64 %r237, 9222246136947933187
  %r243 = icmp eq i64 %r237, 9222246136947933185
  %r244 = icmp eq i64 %r237, 9222246136947933186
  %r245 = or i1 %r242, %r243
  %r246 = or i1 %r245, %r244
  %r247 = or i1 %r241, %r246
  br i1 %r247, label %truthy.merge.27, label %truthy.obj.28

truthy.slow.26:                                   ; preds = %truthy.obj.28
  %r253 = call i32 @js_is_truthy(double %r236) #8
  %r254 = icmp ne i32 %r253, 0
  br label %truthy.merge.27

truthy.merge.27:                                  ; preds = %truthy.obj.28, %truthy.slow.26, %truthy.tag.25, %truthy.num.24
  %r255 = phi i1 [ %r240, %truthy.num.24 ], [ %r241, %truthy.tag.25 ], [ true, %truthy.obj.28 ], [ %r254, %truthy.slow.26 ]
  br i1 %r255, label %logical.merge.30, label %logical.then.29

truthy.obj.28:                                    ; preds = %truthy.tag.25
  %r248 = lshr i64 %r237, 48
  %r249 = icmp eq i64 %r248, 32765
  %r250 = and i64 %r237, 281474976710655
  %r251 = icmp ne i64 %r250, 0
  %r252 = and i1 %r249, %r251
  br i1 %r252, label %truthy.merge.27, label %truthy.slow.26

logical.then.29:                                  ; preds = %truthy.merge.27
  %r256 = load double, ptr @changing_options_worker_ts_.str.7.handle, align 8
  br label %logical.merge.30

logical.merge.30:                                 ; preds = %logical.then.29, %truthy.merge.27
  %r257 = phi double [ %r236, %truthy.merge.27 ], [ %r256, %logical.then.29 ]
  %statepoint_token68 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_number_coerce, i32 1, i32 0, double %r257, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1) ]
  %r25869 = call double @llvm.experimental.gc.result.f64(token %statepoint_token68)
  %rs4gc.s6.relocated70 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token68, i32 0, i32 0) ; (%.1, %.1)
  store double %r25869, ptr @perry_global_changing_options_worker_ts__2, align 8
  %r259 = bitcast double %r25869 to i64
  call void @js_write_barrier_root_nanbox(i64 %r259) #8
  %statepoint_token71 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated70) ]
  %r26172 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token71)
  %rs4gc.s6.relocated73 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token71, i32 0, i32 0) ; (%rs4gc.s6.relocated70, %rs4gc.s6.relocated70)
  %r262 = or i64 %r26172, 9222527611924643840
  %r263 = bitcast i64 %r262 to double
  %r264 = and i64 %r262, 281474976710655
  %r265 = lshr i64 %r262, 48
  %r266 = icmp eq i64 %r265, 32765
  %r267 = icmp ugt i64 %r264, 1048575
  %r268 = and i1 %r266, %r267
  br i1 %r268, label %arr.guard.deref.35, label %arr.fallback.32

arr.fast.31:                                      ; preds = %arr.guard.range.37
  %r327 = add i64 %r283, 40
  %r328 = inttoptr i64 %r327 to ptr
  %r329 = load double, ptr %r328, align 8
  %r330 = bitcast double %r329 to i64
  %r331 = icmp eq i64 %r330, 9222246136947933200
  %r333 = select i1 %r331, double 0x7FFC000000000001, double %r329
  br label %arr.merge.34

arr.fallback.32:                                  ; preds = %arr.guard.live.36, %arr.guard.deref.35, %logical.merge.30
  %statepoint_token74 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 1175166488852561935, double %r263, double 4.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated73) ]
  %r32375 = call double @llvm.experimental.gc.result.f64(token %statepoint_token74)
  %rs4gc.s6.relocated76 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token74, i32 0, i32 0) ; (%rs4gc.s6.relocated73, %rs4gc.s6.relocated73)
  br label %arr.merge.34

arr.guard.oob.33:                                 ; preds = %arr.guard.range.37
  br label %arr.merge.34

arr.merge.34:                                     ; preds = %arr.guard.oob.33, %arr.fallback.32, %arr.fast.31
  %.2 = phi ptr addrspace(1) [ %rs4gc.s6.relocated73, %arr.fast.31 ], [ %rs4gc.s6.relocated73, %arr.guard.oob.33 ], [ %rs4gc.s6.relocated76, %arr.fallback.32 ]
  %r334 = phi double [ %r333, %arr.fast.31 ], [ %r32375, %arr.fallback.32 ], [ 0x7FFC000000000001, %arr.guard.oob.33 ]
  %statepoint_token77 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_number_coerce, i32 1, i32 0, double %r334, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.2) ]
  %r33578 = call double @llvm.experimental.gc.result.f64(token %statepoint_token77)
  %rs4gc.s6.relocated79 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token77, i32 0, i32 0) ; (%.2, %.2)
  %statepoint_token80 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated79) ]
  %r33781 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token80)
  %rs4gc.s6.relocated82 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token80, i32 0, i32 0) ; (%rs4gc.s6.relocated79, %rs4gc.s6.relocated79)
  %r338 = or i64 %r33781, 9222527611924643840
  %r339 = bitcast i64 %r338 to double
  %r340 = and i64 %r338, 281474976710655
  %r341 = lshr i64 %r338, 48
  %r342 = icmp eq i64 %r341, 32765
  %r343 = icmp ugt i64 %r340, 1048575
  %r344 = and i1 %r342, %r343
  br i1 %r344, label %arr.guard.deref.42, label %arr.fallback.39

arr.guard.deref.35:                               ; preds = %logical.merge.30
  %r269 = bitcast double %r263 to i64
  %r270 = and i64 %r269, 281474976710655
  %r271 = sub nsw i64 %r270, 8
  %r272 = inttoptr i64 %r271 to ptr
  %r273 = load i8, ptr %r272, align 1
  %r274 = icmp eq i8 %r273, 1
  %r275 = sub nsw i64 %r270, 7
  %r276 = inttoptr i64 %r275 to ptr
  %r277 = load i8, ptr %r276, align 1
  %r278 = and i8 %r277, -128
  %r279 = icmp ne i8 %r278, 0
  %r280 = inttoptr i64 %r270 to ptr
  %r281 = load i64, ptr %r280, align 8
  %r282 = and i1 %r274, %r279
  %r283 = select i1 %r282, i64 %r281, i64 %r270
  %r284 = lshr i64 %r283, 48
  %r285 = icmp eq i64 %r284, 0
  %r286 = icmp ugt i64 %r283, 1048575
  %r287 = and i1 %r285, %r286
  br i1 %r287, label %arr.guard.live.36, label %arr.fallback.32

arr.guard.live.36:                                ; preds = %arr.guard.deref.35
  %r288 = sub nuw i64 %r283, 8
  %r289 = inttoptr i64 %r288 to ptr
  %r290 = load i8, ptr %r289, align 1
  %r291 = icmp eq i8 %r290, 1
  %r292 = sub nuw i64 %r283, 7
  %r293 = inttoptr i64 %r292 to ptr
  %r294 = load i8, ptr %r293, align 1
  %r295 = and i8 %r294, -128
  %r296 = icmp eq i8 %r295, 0
  %r297 = sub nuw i64 %r283, 6
  %r298 = inttoptr i64 %r297 to ptr
  %r299 = load i16, ptr %r298, align 2
  %r300 = and i16 %r299, 1024
  %r301 = icmp eq i16 %r300, 0
  %r302 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r303 = icmp eq i8 %r302, 0
  %r304 = inttoptr i64 %r283 to ptr
  %r305 = load i32, ptr %r304, align 4
  %r306 = getelementptr i8, ptr %r304, i64 4
  %r307 = load i32, ptr %r306, align 4
  %r311 = icmp ule i32 %r305, 16000000
  %r312 = icmp ule i32 %r307, 16000000
  %r313 = icmp ule i32 %r305, %r307
  %r314 = and i1 %r291, %r296
  %r315 = and i1 %r314, %r301
  %r316 = and i1 %r315, %r303
  %r318 = and i1 %r316, %r311
  %r319 = and i1 %r318, %r312
  %r320 = and i1 %r319, %r313
  br i1 %r320, label %arr.guard.range.37, label %arr.fallback.32

arr.guard.range.37:                               ; preds = %arr.guard.live.36
  %r310 = icmp ult i32 4, %r305
  br i1 %r310, label %arr.fast.31, label %arr.guard.oob.33

arr.fast.38:                                      ; preds = %arr.guard.range.44
  %r403 = add i64 %r359, 48
  %r404 = inttoptr i64 %r403 to ptr
  %r405 = load double, ptr %r404, align 8
  %r406 = bitcast double %r405 to i64
  %r407 = icmp eq i64 %r406, 9222246136947933200
  %r409 = select i1 %r407, double 0x7FFC000000000001, double %r405
  br label %arr.merge.41

arr.fallback.39:                                  ; preds = %arr.guard.live.43, %arr.guard.deref.42, %arr.merge.34
  %statepoint_token83 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 1175166488852561936, double %r339, double 5.000000e+00, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s6.relocated82) ]
  %r39984 = call double @llvm.experimental.gc.result.f64(token %statepoint_token83)
  %rs4gc.s6.relocated85 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token83, i32 0, i32 0) ; (%rs4gc.s6.relocated82, %rs4gc.s6.relocated82)
  br label %arr.merge.41

arr.guard.oob.40:                                 ; preds = %arr.guard.range.44
  br label %arr.merge.41

arr.merge.41:                                     ; preds = %arr.guard.oob.40, %arr.fallback.39, %arr.fast.38
  %.3 = phi ptr addrspace(1) [ %rs4gc.s6.relocated82, %arr.fast.38 ], [ %rs4gc.s6.relocated82, %arr.guard.oob.40 ], [ %rs4gc.s6.relocated85, %arr.fallback.39 ]
  %r410 = phi double [ %r409, %arr.fast.38 ], [ %r39984, %arr.fallback.39 ], [ 0x7FFC000000000001, %arr.guard.oob.40 ]
  %statepoint_token86 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_number_coerce, i32 1, i32 0, double %r410, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3) ]
  %r41187 = call double @llvm.experimental.gc.result.f64(token %statepoint_token86)
  %rs4gc.s6.relocated88 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token86, i32 0, i32 0) ; (%.3, %.3)
  %r412 = load double, ptr @changing_options_worker_ts_.str.8.handle, align 8
  %r413.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s6.relocated88 to i64
  %r413.rs4o = call i64 asm "", "=r,0"(i64 %r413.rs4i) #8
  %r413 = bitcast i64 %r413.rs4o to double
  %r414 = load double, ptr @changing_options_worker_ts_.str.9.handle, align 8
  %r416 = getelementptr double, ptr %r415, i64 0
  store double %r412, ptr %r416, align 8
  %r417 = getelementptr double, ptr %r415, i64 1
  store double %r413, ptr %r417, align 8
  %r418 = getelementptr double, ptr %r415, i64 2
  store double %r414, ptr %r418, align 8
  %r419 = ptrtoint ptr %r415 to i64
  %statepoint_token89 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, i32)) @js_string_concat_chain, i32 2, i32 0, i64 %r419, i32 3, i32 0, i32 0)
  %r42090 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token89)
  %r421 = or i64 %r42090, 9223090561878065152
  %r422 = bitcast i64 %r421 to double
  %statepoint_token91 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (double)) @js_json_text_to_string, i32 1, i32 0, double %r422, i32 0, i32 0)
  %r42392 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token91)
  %statepoint_token93 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64)) @js_json_parse, i32 1, i32 0, i64 %r42392, i32 0, i32 0)
  %r42494 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token93)
  %r425 = bitcast i64 %r42494 to double
  %r426 = and i64 %r42494, 281474976710655
  %r427 = lshr i64 %r42494, 48
  %r428 = and i64 %r427, 65533
  %r429 = icmp eq i64 %r428, 32765
  br i1 %r429, label %pget.recv_ok.46, label %pget.recv_other.50

arr.guard.deref.42:                               ; preds = %arr.merge.34
  %r345 = bitcast double %r339 to i64
  %r346 = and i64 %r345, 281474976710655
  %r347 = sub nsw i64 %r346, 8
  %r348 = inttoptr i64 %r347 to ptr
  %r349 = load i8, ptr %r348, align 1
  %r350 = icmp eq i8 %r349, 1
  %r351 = sub nsw i64 %r346, 7
  %r352 = inttoptr i64 %r351 to ptr
  %r353 = load i8, ptr %r352, align 1
  %r354 = and i8 %r353, -128
  %r355 = icmp ne i8 %r354, 0
  %r356 = inttoptr i64 %r346 to ptr
  %r357 = load i64, ptr %r356, align 8
  %r358 = and i1 %r350, %r355
  %r359 = select i1 %r358, i64 %r357, i64 %r346
  %r360 = lshr i64 %r359, 48
  %r361 = icmp eq i64 %r360, 0
  %r362 = icmp ugt i64 %r359, 1048575
  %r363 = and i1 %r361, %r362
  br i1 %r363, label %arr.guard.live.43, label %arr.fallback.39

arr.guard.live.43:                                ; preds = %arr.guard.deref.42
  %r364 = sub nuw i64 %r359, 8
  %r365 = inttoptr i64 %r364 to ptr
  %r366 = load i8, ptr %r365, align 1
  %r367 = icmp eq i8 %r366, 1
  %r368 = sub nuw i64 %r359, 7
  %r369 = inttoptr i64 %r368 to ptr
  %r370 = load i8, ptr %r369, align 1
  %r371 = and i8 %r370, -128
  %r372 = icmp eq i8 %r371, 0
  %r373 = sub nuw i64 %r359, 6
  %r374 = inttoptr i64 %r373 to ptr
  %r375 = load i16, ptr %r374, align 2
  %r376 = and i16 %r375, 1024
  %r377 = icmp eq i16 %r376, 0
  %r378 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r379 = icmp eq i8 %r378, 0
  %r380 = inttoptr i64 %r359 to ptr
  %r381 = load i32, ptr %r380, align 4
  %r382 = getelementptr i8, ptr %r380, i64 4
  %r383 = load i32, ptr %r382, align 4
  %r387 = icmp ule i32 %r381, 16000000
  %r388 = icmp ule i32 %r383, 16000000
  %r389 = icmp ule i32 %r381, %r383
  %r390 = and i1 %r367, %r372
  %r391 = and i1 %r390, %r377
  %r392 = and i1 %r391, %r379
  %r394 = and i1 %r392, %r387
  %r395 = and i1 %r394, %r388
  %r396 = and i1 %r395, %r389
  br i1 %r396, label %arr.guard.range.44, label %arr.fallback.39

arr.guard.range.44:                               ; preds = %arr.guard.live.43
  %r386 = icmp ult i32 5, %r381
  br i1 %r386, label %arr.fast.38, label %arr.guard.oob.40

pget.recv_sso.45:                                 ; preds = %pget.recv_other.50
  %r567 = load double, ptr @changing_options_worker_ts_.str.10.handle, align 8
  %r568 = bitcast double %r567 to i64
  %r569 = and i64 %r568, 281474976710655
  %statepoint_token95 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r42494, i64 %r569, i32 0, i32 0)
  %r57096 = call double @llvm.experimental.gc.result.f64(token %statepoint_token95)
  br label %pget.recv_merge.49

pget.recv_ok.46:                                  ; preds = %arr.merge.41
  %r436 = icmp ugt i64 %r426, 1048575
  br i1 %r436, label %pic.recv_hdr.67, label %pic.miss.cold.64

pget.recv_bad.47:                                 ; preds = %pget.check_class_ref.51
  %r559 = icmp eq i64 %r42494, 9222246136947933185
  %r560 = icmp eq i64 %r42494, 9222246136947933186
  %r561 = or i1 %r559, %r560
  br i1 %r561, label %pget.throw_nullish.74, label %pget.recv_undef_return.75

pget.recv_class_ref.48:                           ; preds = %pget.check_class_ref.51
  %r432 = load double, ptr @changing_options_worker_ts_.str.10.handle, align 8
  %r433 = bitcast double %r432 to i64
  %r434 = and i64 %r433, 281474976710655
  %statepoint_token97 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 1175166488852561937, i64 %r42494, i64 %r434, i32 0, i32 0)
  %r43598 = call double @llvm.experimental.gc.result.f64(token %statepoint_token97)
  br label %pget.recv_merge.49

pget.recv_merge.49:                               ; preds = %pget.recv_undef_return.75, %pic.merge.66, %pget.recv_class_ref.48, %pget.recv_sso.45
  %r571 = phi double [ %r558, %pic.merge.66 ], [ %r566107, %pget.recv_undef_return.75 ], [ %r57096, %pget.recv_sso.45 ], [ %r43598, %pget.recv_class_ref.48 ]
  store double %r571, ptr @perry_global_changing_options_worker_ts__5, align 8
  %r572 = bitcast double %r571 to i64
  call void @js_write_barrier_root_nanbox(i64 %r572) #8
  store double 0x7FFC000000000002, ptr @perry_global_changing_options_worker_ts__6, align 8
  call void @js_write_barrier_root_nanbox(i64 9222246136947933186) #8
  %statepoint_token99 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @"perry_fn_changing_options_worker_ts__run$spec_b", i32 1, i32 0, double %r41187, i32 0, i32 0)
  %r576100 = call double @llvm.experimental.gc.result.f64(token %statepoint_token99)
  %rs4gc.b7 = bitcast double %r576100 to i64
  %rs4gc.s7 = inttoptr i64 %rs4gc.b7 to ptr addrspace(1)
  %r577.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7 to i64
  %r577 = call i64 asm "", "=r,0"(i64 %r577.rs4i) #8
  %r578 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r579 = icmp ne i32 %r578, 0
  br i1 %r579, label %shadow.root.barrier.76, label %shadow.root.barrier.done.77

pget.recv_other.50:                               ; preds = %arr.merge.41
  %r430 = icmp eq i64 %r427, 32761
  br i1 %r430, label %pget.recv_sso.45, label %pget.check_class_ref.51

pget.check_class_ref.51:                          ; preds = %pget.recv_other.50
  %r431 = icmp eq i64 %r427, 32766
  br i1 %r431, label %pget.recv_class_ref.48, label %pget.recv_bad.47

pic.hit.52:                                       ; preds = %pic.token.68
  %r461 = getelementptr i64, ptr %r446, i64 1
  %r462 = load i64, ptr %r461, align 8
  %r463 = and i64 %r462, 1073741824
  %r464 = icmp ne i64 %r463, 0
  br i1 %r464, label %pic.hit.overflow.69, label %pic.hit.inline.70

pic.hit.live.53:                                  ; preds = %pic.hit.inline.70
  br label %pic.merge.66

pic.prefix.guard.54:                              ; preds = %pic.token.68
  %r477 = getelementptr i64, ptr %r446, i64 2
  %r478 = load i64, ptr %r477, align 8
  %r479 = icmp ne i64 %r478, 0
  br i1 %r479, label %pic.prefix.meta.55, label %pic.miss.63

pic.prefix.meta.55:                               ; preds = %pic.prefix.guard.54
  %r480 = add nuw nsw i64 %r426, 8
  %r481 = inttoptr i64 %r480 to ptr
  %r482 = load i64, ptr %r481, align 8
  %r483 = icmp ne i64 %r482, 0
  br i1 %r483, label %pic.prefix.token.56, label %pic.miss.63

pic.prefix.token.56:                              ; preds = %pic.prefix.meta.55
  %r484 = inttoptr i64 %r482 to ptr
  %r485 = getelementptr i64, ptr %r484, i64 6
  %r486 = load i64, ptr %r485, align 8
  %r487 = icmp eq i64 %r486, %r478
  br i1 %r487, label %pic.prefix.hit.57, label %pic.miss.63

pic.prefix.hit.57:                                ; preds = %pic.prefix.token.56
  %r488 = getelementptr i64, ptr %r446, i64 1
  %r489 = load i64, ptr %r488, align 8
  %r490 = shl i64 %r489, 3
  %r491 = add nuw nsw i64 %r426, 16
  %r492 = add i64 %r491, %r490
  %r493 = inttoptr i64 %r492 to ptr
  %r494 = load double, ptr %r493, align 8
  br label %pic.merge.66

pic.desc.classify.58:                             ; preds = %pic.recv_hdr.67
  %r450 = and i1 %r440, %r447
  br i1 %r450, label %pic.desc.prefix.guard.59, label %pic.miss.cold.64

pic.desc.prefix.guard.59:                         ; preds = %pic.desc.classify.58
  %r495 = getelementptr i64, ptr %r446, i64 2
  %r496 = load i64, ptr %r495, align 8
  %r497 = icmp ne i64 %r496, 0
  br i1 %r497, label %pic.desc.prefix.meta.60, label %pic.miss.cold.64

pic.desc.prefix.meta.60:                          ; preds = %pic.desc.prefix.guard.59
  %r498 = add nuw nsw i64 %r426, 8
  %r499 = inttoptr i64 %r498 to ptr
  %r500 = load i64, ptr %r499, align 8
  %r501 = icmp ne i64 %r500, 0
  br i1 %r501, label %pic.desc.prefix.token.61, label %pic.miss.cold.64

pic.desc.prefix.token.61:                         ; preds = %pic.desc.prefix.meta.60
  %r502 = inttoptr i64 %r500 to ptr
  %r503 = getelementptr i64, ptr %r502, i64 6
  %r504 = load i64, ptr %r503, align 8
  %r505 = icmp eq i64 %r504, %r496
  br i1 %r505, label %pic.desc.prefix.hit.62, label %pic.miss.cold.64

pic.desc.prefix.hit.62:                           ; preds = %pic.desc.prefix.token.61
  %r506 = getelementptr i64, ptr %r446, i64 1
  %r507 = load i64, ptr %r506, align 8
  %r508 = shl i64 %r507, 3
  %r509 = add nuw nsw i64 %r426, 16
  %r510 = add i64 %r509, %r508
  %r511 = inttoptr i64 %r510 to ptr
  %r512 = load double, ptr %r511, align 8
  br label %pic.merge.66

pic.miss.63:                                      ; preds = %pic.hit.inline.70, %pic.prefix.token.56, %pic.prefix.meta.55, %pic.prefix.guard.54
  %r513 = getelementptr i64, ptr %r446, i64 3
  %r514 = load i64, ptr %r513, align 8
  %r515 = icmp sgt i64 %r514, 0
  br i1 %r515, label %pic.ways.71, label %pic.miss.call.65

pic.miss.cold.64:                                 ; preds = %pic.desc.prefix.token.61, %pic.desc.prefix.meta.60, %pic.desc.prefix.guard.59, %pic.desc.classify.58, %pget.recv_ok.46
  br label %pic.miss.call.65

pic.miss.call.65:                                 ; preds = %pic.way.load.72, %pic.ways.71, %pic.miss.cold.64, %pic.miss.63
  %r554 = load double, ptr @changing_options_worker_ts_.str.10.handle, align 8
  %r555 = bitcast double %r554 to i64
  %r556 = and i64 %r555, 281474976710655
  %statepoint_token101 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r426, i64 %r556, ptr @perry_ic_changing_options_worker_ts__18, i32 0, i32 0)
  %r557102 = call double @llvm.experimental.gc.result.f64(token %statepoint_token101)
  br label %pic.merge.66

pic.merge.66:                                     ; preds = %pic.way.live.73, %pic.hit.overflow.69, %pic.miss.call.65, %pic.desc.prefix.hit.62, %pic.prefix.hit.57, %pic.hit.live.53
  %r558 = phi double [ %r474, %pic.hit.live.53 ], [ %r469104, %pic.hit.overflow.69 ], [ %r494, %pic.prefix.hit.57 ], [ %r512, %pic.desc.prefix.hit.62 ], [ %r551, %pic.way.live.73 ], [ %r557102, %pic.miss.call.65 ]
  br label %pget.recv_merge.49

pic.recv_hdr.67:                                  ; preds = %pget.recv_ok.46
  %r437 = sub nuw nsw i64 %r426, 8
  %r438 = inttoptr i64 %r437 to ptr
  %r439 = load i8, ptr %r438, align 1
  %r440 = icmp eq i8 %r439, 2
  %r441 = sub nuw nsw i64 %r426, 6
  %r442 = inttoptr i64 %r441 to ptr
  %r443 = load i16, ptr %r442, align 2
  %r444 = and i16 %r443, 2048
  %r445 = icmp eq i16 %r444, 0
  %r446 = load ptr, ptr @perry_ic_changing_options_worker_ts__18, align 8
  %r447 = icmp ne ptr %r446, null
  %r448 = and i1 %r440, %r445
  %r449 = and i1 %r448, %r447
  br i1 %r449, label %pic.token.68, label %pic.desc.classify.58

pic.token.68:                                     ; preds = %pic.recv_hdr.67
  %r451 = add nuw nsw i64 %r426, 4
  %r452 = inttoptr i64 %r451 to ptr
  %r453 = load i32, ptr %r452, align 4
  %r454 = zext i32 %r453 to i64
  %r455 = or i64 %r454, 4611686018427387904
  %r456 = icmp ne i32 %r453, 0
  %r457 = getelementptr i64, ptr %r446, i64 0
  %r458 = load i64, ptr %r457, align 8
  %r459 = icmp eq i64 %r455, %r458
  %r460 = and i1 %r459, %r456
  br i1 %r460, label %pic.hit.52, label %pic.prefix.guard.54

pic.hit.overflow.69:                              ; preds = %pic.hit.52
  %r465 = load double, ptr @changing_options_worker_ts_.str.10.handle, align 8
  %r466 = bitcast double %r465 to i64
  %r467 = and i64 %r466, 281474976710655
  %r468 = trunc i64 %r462 to i32
  %statepoint_token103 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r426, i64 %r467, i32 %r468, ptr @perry_ic_changing_options_worker_ts__18, i32 0, i32 0)
  %r469104 = call double @llvm.experimental.gc.result.f64(token %statepoint_token103)
  br label %pic.merge.66

pic.hit.inline.70:                                ; preds = %pic.hit.52
  %r470 = shl i64 %r462, 3
  %r471 = add nuw nsw i64 %r426, 16
  %r472 = add i64 %r471, %r470
  %r473 = inttoptr i64 %r472 to ptr
  %r474 = load double, ptr %r473, align 8
  %r475 = bitcast double %r474 to i64
  %r476 = icmp eq i64 %r475, 9222246136947933200
  br i1 %r476, label %pic.miss.63, label %pic.hit.live.53

pic.ways.71:                                      ; preds = %pic.miss.63
  %r516 = getelementptr i64, ptr %r446, i64 4
  %r517 = load i64, ptr %r516, align 8
  %r518 = icmp eq i64 %r517, %r455
  %r519 = getelementptr i64, ptr %r446, i64 5
  %r520 = load i64, ptr %r519, align 8
  %r521 = select i1 %r518, i64 %r520, i64 0
  %r522 = getelementptr i64, ptr %r446, i64 6
  %r523 = load i64, ptr %r522, align 8
  %r524 = icmp eq i64 %r523, %r455
  %r525 = getelementptr i64, ptr %r446, i64 7
  %r526 = load i64, ptr %r525, align 8
  %r527 = select i1 %r524, i64 %r526, i64 0
  %r528 = getelementptr i64, ptr %r446, i64 8
  %r529 = load i64, ptr %r528, align 8
  %r530 = icmp eq i64 %r529, %r455
  %r531 = getelementptr i64, ptr %r446, i64 9
  %r532 = load i64, ptr %r531, align 8
  %r533 = select i1 %r530, i64 %r532, i64 0
  %r534 = getelementptr i64, ptr %r446, i64 10
  %r535 = load i64, ptr %r534, align 8
  %r536 = icmp eq i64 %r535, %r455
  %r537 = getelementptr i64, ptr %r446, i64 11
  %r538 = load i64, ptr %r537, align 8
  %r539 = select i1 %r536, i64 %r538, i64 0
  %r540 = or i1 %r518, %r524
  %r541 = select i1 %r518, i64 %r521, i64 %r527
  %r542 = or i1 %r530, %r536
  %r543 = select i1 %r530, i64 %r533, i64 %r539
  %r544 = or i1 %r540, %r542
  %r545 = select i1 %r540, i64 %r541, i64 %r543
  %r546 = and i1 %r456, %r544
  br i1 %r546, label %pic.way.load.72, label %pic.miss.call.65

pic.way.load.72:                                  ; preds = %pic.ways.71
  %r547 = shl i64 %r545, 3
  %r548 = add nuw nsw i64 %r426, 16
  %r549 = add i64 %r548, %r547
  %r550 = inttoptr i64 %r549 to ptr
  %r551 = load double, ptr %r550, align 8
  %r552 = bitcast double %r551 to i64
  %r553 = icmp eq i64 %r552, 9222246136947933200
  br i1 %r553, label %pic.miss.call.65, label %pic.way.live.73

pic.way.live.73:                                  ; preds = %pic.way.load.72
  br label %pic.merge.66

pget.throw_nullish.74:                            ; preds = %pget.recv_bad.47
  %r562 = zext i1 %r560 to i32
  %statepoint_token105 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r562, ptr @changing_options_worker_ts_.str.10.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.75:                        ; preds = %pget.recv_bad.47
  %r563 = load double, ptr @changing_options_worker_ts_.str.10.handle, align 8
  %r564 = bitcast double %r563 to i64
  %r565 = and i64 %r564, 281474976710655
  %statepoint_token106 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r42494, i64 %r565, i32 0, i32 0)
  %r566107 = call double @llvm.experimental.gc.result.f64(token %statepoint_token106)
  br label %pget.recv_merge.49

shadow.root.barrier.76:                           ; preds = %pget.recv_merge.49
  call void @js_write_barrier_root_nanbox(i64 %r577) #8
  br label %shadow.root.barrier.done.77

shadow.root.barrier.done.77:                      ; preds = %shadow.root.barrier.76, %pget.recv_merge.49
  %statepoint_token108 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_process_memory_usage, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7) ]
  %r581109 = call double @llvm.experimental.gc.result.f64(token %statepoint_token108)
  %rs4gc.s7.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token108, i32 0, i32 0) ; (%rs4gc.s7, %rs4gc.s7)
  %r582 = bitcast double %r581109 to i64
  %r583 = and i64 %r582, 281474976710655
  %r584 = lshr i64 %r582, 48
  %r585 = and i64 %r584, 65533
  %r586 = icmp eq i64 %r585, 32765
  br i1 %r586, label %pget.recv_ok.79, label %pget.recv_other.83

pget.recv_sso.78:                                 ; preds = %pget.recv_other.83
  %r724 = load double, ptr @changing_options_worker_ts_.str.11.handle, align 8
  %r725 = bitcast double %r724 to i64
  %r726 = and i64 %r725, 281474976710655
  %statepoint_token110 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r582, i64 %r726, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r727111 = call double @llvm.experimental.gc.result.f64(token %statepoint_token110)
  %rs4gc.s7.relocated112 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token110, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pget.recv_merge.82

pget.recv_ok.79:                                  ; preds = %shadow.root.barrier.done.77
  %r593 = icmp ugt i64 %r583, 1048575
  br i1 %r593, label %pic.recv_hdr.100, label %pic.miss.cold.97

pget.recv_bad.80:                                 ; preds = %pget.check_class_ref.84
  %r716 = icmp eq i64 %r582, 9222246136947933185
  %r717 = icmp eq i64 %r582, 9222246136947933186
  %r718 = or i1 %r716, %r717
  br i1 %r718, label %pget.throw_nullish.107, label %pget.recv_undef_return.108

pget.recv_class_ref.81:                           ; preds = %pget.check_class_ref.84
  %r589 = load double, ptr @changing_options_worker_ts_.str.11.handle, align 8
  %r590 = bitcast double %r589 to i64
  %r591 = and i64 %r590, 281474976710655
  %statepoint_token113 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 1175166488852561939, i64 %r582, i64 %r591, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r592114 = call double @llvm.experimental.gc.result.f64(token %statepoint_token113)
  %rs4gc.s7.relocated115 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token113, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pget.recv_merge.82

pget.recv_merge.82:                               ; preds = %pget.recv_undef_return.108, %pic.merge.99, %pget.recv_class_ref.81, %pget.recv_sso.78
  %.0430 = phi ptr addrspace(1) [ %.1431, %pic.merge.99 ], [ %rs4gc.s7.relocated112, %pget.recv_sso.78 ], [ %rs4gc.s7.relocated115, %pget.recv_class_ref.81 ], [ %rs4gc.s7.relocated125, %pget.recv_undef_return.108 ]
  %r728 = phi double [ %r715, %pic.merge.99 ], [ %r723124, %pget.recv_undef_return.108 ], [ %r727111, %pget.recv_sso.78 ], [ %r592114, %pget.recv_class_ref.81 ]
  %rs4gc.b8 = bitcast double %r728 to i64
  %rs4gc.s8 = inttoptr i64 %rs4gc.b8 to ptr addrspace(1)
  %r729.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8 to i64
  %r729 = call i64 asm "", "=r,0"(i64 %r729.rs4i) #8
  %r730 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r731 = icmp ne i32 %r730, 0
  br i1 %r731, label %shadow.root.barrier.109, label %shadow.root.barrier.done.110

pget.recv_other.83:                               ; preds = %shadow.root.barrier.done.77
  %r587 = icmp eq i64 %r584, 32761
  br i1 %r587, label %pget.recv_sso.78, label %pget.check_class_ref.84

pget.check_class_ref.84:                          ; preds = %pget.recv_other.83
  %r588 = icmp eq i64 %r584, 32766
  br i1 %r588, label %pget.recv_class_ref.81, label %pget.recv_bad.80

pic.hit.85:                                       ; preds = %pic.token.101
  %r618 = getelementptr i64, ptr %r603, i64 1
  %r619 = load i64, ptr %r618, align 8
  %r620 = and i64 %r619, 1073741824
  %r621 = icmp ne i64 %r620, 0
  br i1 %r621, label %pic.hit.overflow.102, label %pic.hit.inline.103

pic.hit.live.86:                                  ; preds = %pic.hit.inline.103
  br label %pic.merge.99

pic.prefix.guard.87:                              ; preds = %pic.token.101
  %r634 = getelementptr i64, ptr %r603, i64 2
  %r635 = load i64, ptr %r634, align 8
  %r636 = icmp ne i64 %r635, 0
  br i1 %r636, label %pic.prefix.meta.88, label %pic.miss.96

pic.prefix.meta.88:                               ; preds = %pic.prefix.guard.87
  %r637 = add nuw nsw i64 %r583, 8
  %r638 = inttoptr i64 %r637 to ptr
  %r639 = load i64, ptr %r638, align 8
  %r640 = icmp ne i64 %r639, 0
  br i1 %r640, label %pic.prefix.token.89, label %pic.miss.96

pic.prefix.token.89:                              ; preds = %pic.prefix.meta.88
  %r641 = inttoptr i64 %r639 to ptr
  %r642 = getelementptr i64, ptr %r641, i64 6
  %r643 = load i64, ptr %r642, align 8
  %r644 = icmp eq i64 %r643, %r635
  br i1 %r644, label %pic.prefix.hit.90, label %pic.miss.96

pic.prefix.hit.90:                                ; preds = %pic.prefix.token.89
  %r645 = getelementptr i64, ptr %r603, i64 1
  %r646 = load i64, ptr %r645, align 8
  %r647 = shl i64 %r646, 3
  %r648 = add nuw nsw i64 %r583, 16
  %r649 = add i64 %r648, %r647
  %r650 = inttoptr i64 %r649 to ptr
  %r651 = load double, ptr %r650, align 8
  br label %pic.merge.99

pic.desc.classify.91:                             ; preds = %pic.recv_hdr.100
  %r607 = and i1 %r597, %r604
  br i1 %r607, label %pic.desc.prefix.guard.92, label %pic.miss.cold.97

pic.desc.prefix.guard.92:                         ; preds = %pic.desc.classify.91
  %r652 = getelementptr i64, ptr %r603, i64 2
  %r653 = load i64, ptr %r652, align 8
  %r654 = icmp ne i64 %r653, 0
  br i1 %r654, label %pic.desc.prefix.meta.93, label %pic.miss.cold.97

pic.desc.prefix.meta.93:                          ; preds = %pic.desc.prefix.guard.92
  %r655 = add nuw nsw i64 %r583, 8
  %r656 = inttoptr i64 %r655 to ptr
  %r657 = load i64, ptr %r656, align 8
  %r658 = icmp ne i64 %r657, 0
  br i1 %r658, label %pic.desc.prefix.token.94, label %pic.miss.cold.97

pic.desc.prefix.token.94:                         ; preds = %pic.desc.prefix.meta.93
  %r659 = inttoptr i64 %r657 to ptr
  %r660 = getelementptr i64, ptr %r659, i64 6
  %r661 = load i64, ptr %r660, align 8
  %r662 = icmp eq i64 %r661, %r653
  br i1 %r662, label %pic.desc.prefix.hit.95, label %pic.miss.cold.97

pic.desc.prefix.hit.95:                           ; preds = %pic.desc.prefix.token.94
  %r663 = getelementptr i64, ptr %r603, i64 1
  %r664 = load i64, ptr %r663, align 8
  %r665 = shl i64 %r664, 3
  %r666 = add nuw nsw i64 %r583, 16
  %r667 = add i64 %r666, %r665
  %r668 = inttoptr i64 %r667 to ptr
  %r669 = load double, ptr %r668, align 8
  br label %pic.merge.99

pic.miss.96:                                      ; preds = %pic.hit.inline.103, %pic.prefix.token.89, %pic.prefix.meta.88, %pic.prefix.guard.87
  %r670 = getelementptr i64, ptr %r603, i64 3
  %r671 = load i64, ptr %r670, align 8
  %r672 = icmp sgt i64 %r671, 0
  br i1 %r672, label %pic.ways.104, label %pic.miss.call.98

pic.miss.cold.97:                                 ; preds = %pic.desc.prefix.token.94, %pic.desc.prefix.meta.93, %pic.desc.prefix.guard.92, %pic.desc.classify.91, %pget.recv_ok.79
  br label %pic.miss.call.98

pic.miss.call.98:                                 ; preds = %pic.way.load.105, %pic.ways.104, %pic.miss.cold.97, %pic.miss.96
  %r711 = load double, ptr @changing_options_worker_ts_.str.11.handle, align 8
  %r712 = bitcast double %r711 to i64
  %r713 = and i64 %r712, 281474976710655
  %statepoint_token116 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r583, i64 %r713, ptr @perry_ic_changing_options_worker_ts__20, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r714117 = call double @llvm.experimental.gc.result.f64(token %statepoint_token116)
  %rs4gc.s7.relocated118 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token116, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pic.merge.99

pic.merge.99:                                     ; preds = %pic.way.live.106, %pic.hit.overflow.102, %pic.miss.call.98, %pic.desc.prefix.hit.95, %pic.prefix.hit.90, %pic.hit.live.86
  %.1431 = phi ptr addrspace(1) [ %rs4gc.s7.relocated121, %pic.hit.overflow.102 ], [ %rs4gc.s7.relocated118, %pic.miss.call.98 ], [ %rs4gc.s7.relocated, %pic.way.live.106 ], [ %rs4gc.s7.relocated, %pic.hit.live.86 ], [ %rs4gc.s7.relocated, %pic.prefix.hit.90 ], [ %rs4gc.s7.relocated, %pic.desc.prefix.hit.95 ]
  %r715 = phi double [ %r631, %pic.hit.live.86 ], [ %r626120, %pic.hit.overflow.102 ], [ %r651, %pic.prefix.hit.90 ], [ %r669, %pic.desc.prefix.hit.95 ], [ %r708, %pic.way.live.106 ], [ %r714117, %pic.miss.call.98 ]
  br label %pget.recv_merge.82

pic.recv_hdr.100:                                 ; preds = %pget.recv_ok.79
  %r594 = sub nuw nsw i64 %r583, 8
  %r595 = inttoptr i64 %r594 to ptr
  %r596 = load i8, ptr %r595, align 1
  %r597 = icmp eq i8 %r596, 2
  %r598 = sub nuw nsw i64 %r583, 6
  %r599 = inttoptr i64 %r598 to ptr
  %r600 = load i16, ptr %r599, align 2
  %r601 = and i16 %r600, 2048
  %r602 = icmp eq i16 %r601, 0
  %r603 = load ptr, ptr @perry_ic_changing_options_worker_ts__20, align 8
  %r604 = icmp ne ptr %r603, null
  %r605 = and i1 %r597, %r602
  %r606 = and i1 %r605, %r604
  br i1 %r606, label %pic.token.101, label %pic.desc.classify.91

pic.token.101:                                    ; preds = %pic.recv_hdr.100
  %r608 = add nuw nsw i64 %r583, 4
  %r609 = inttoptr i64 %r608 to ptr
  %r610 = load i32, ptr %r609, align 4
  %r611 = zext i32 %r610 to i64
  %r612 = or i64 %r611, 4611686018427387904
  %r613 = icmp ne i32 %r610, 0
  %r614 = getelementptr i64, ptr %r603, i64 0
  %r615 = load i64, ptr %r614, align 8
  %r616 = icmp eq i64 %r612, %r615
  %r617 = and i1 %r616, %r613
  br i1 %r617, label %pic.hit.85, label %pic.prefix.guard.87

pic.hit.overflow.102:                             ; preds = %pic.hit.85
  %r622 = load double, ptr @changing_options_worker_ts_.str.11.handle, align 8
  %r623 = bitcast double %r622 to i64
  %r624 = and i64 %r623, 281474976710655
  %r625 = trunc i64 %r619 to i32
  %statepoint_token119 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r583, i64 %r624, i32 %r625, ptr @perry_ic_changing_options_worker_ts__20, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r626120 = call double @llvm.experimental.gc.result.f64(token %statepoint_token119)
  %rs4gc.s7.relocated121 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token119, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pic.merge.99

pic.hit.inline.103:                               ; preds = %pic.hit.85
  %r627 = shl i64 %r619, 3
  %r628 = add nuw nsw i64 %r583, 16
  %r629 = add i64 %r628, %r627
  %r630 = inttoptr i64 %r629 to ptr
  %r631 = load double, ptr %r630, align 8
  %r632 = bitcast double %r631 to i64
  %r633 = icmp eq i64 %r632, 9222246136947933200
  br i1 %r633, label %pic.miss.96, label %pic.hit.live.86

pic.ways.104:                                     ; preds = %pic.miss.96
  %r673 = getelementptr i64, ptr %r603, i64 4
  %r674 = load i64, ptr %r673, align 8
  %r675 = icmp eq i64 %r674, %r612
  %r676 = getelementptr i64, ptr %r603, i64 5
  %r677 = load i64, ptr %r676, align 8
  %r678 = select i1 %r675, i64 %r677, i64 0
  %r679 = getelementptr i64, ptr %r603, i64 6
  %r680 = load i64, ptr %r679, align 8
  %r681 = icmp eq i64 %r680, %r612
  %r682 = getelementptr i64, ptr %r603, i64 7
  %r683 = load i64, ptr %r682, align 8
  %r684 = select i1 %r681, i64 %r683, i64 0
  %r685 = getelementptr i64, ptr %r603, i64 8
  %r686 = load i64, ptr %r685, align 8
  %r687 = icmp eq i64 %r686, %r612
  %r688 = getelementptr i64, ptr %r603, i64 9
  %r689 = load i64, ptr %r688, align 8
  %r690 = select i1 %r687, i64 %r689, i64 0
  %r691 = getelementptr i64, ptr %r603, i64 10
  %r692 = load i64, ptr %r691, align 8
  %r693 = icmp eq i64 %r692, %r612
  %r694 = getelementptr i64, ptr %r603, i64 11
  %r695 = load i64, ptr %r694, align 8
  %r696 = select i1 %r693, i64 %r695, i64 0
  %r697 = or i1 %r675, %r681
  %r698 = select i1 %r675, i64 %r678, i64 %r684
  %r699 = or i1 %r687, %r693
  %r700 = select i1 %r687, i64 %r690, i64 %r696
  %r701 = or i1 %r697, %r699
  %r702 = select i1 %r697, i64 %r698, i64 %r700
  %r703 = and i1 %r613, %r701
  br i1 %r703, label %pic.way.load.105, label %pic.miss.call.98

pic.way.load.105:                                 ; preds = %pic.ways.104
  %r704 = shl i64 %r702, 3
  %r705 = add nuw nsw i64 %r583, 16
  %r706 = add i64 %r705, %r704
  %r707 = inttoptr i64 %r706 to ptr
  %r708 = load double, ptr %r707, align 8
  %r709 = bitcast double %r708 to i64
  %r710 = icmp eq i64 %r709, 9222246136947933200
  br i1 %r710, label %pic.miss.call.98, label %pic.way.live.106

pic.way.live.106:                                 ; preds = %pic.way.load.105
  br label %pic.merge.99

pget.throw_nullish.107:                           ; preds = %pget.recv_bad.80
  %r719 = zext i1 %r717 to i32
  %statepoint_token122 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r719, ptr @changing_options_worker_ts_.str.11.bytes, i64 3, i32 0, i32 0)
  unreachable

pget.recv_undef_return.108:                       ; preds = %pget.recv_bad.80
  %r720 = load double, ptr @changing_options_worker_ts_.str.11.handle, align 8
  %r721 = bitcast double %r720 to i64
  %r722 = and i64 %r721, 281474976710655
  %statepoint_token123 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r582, i64 %r722, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s7.relocated) ]
  %r723124 = call double @llvm.experimental.gc.result.f64(token %statepoint_token123)
  %rs4gc.s7.relocated125 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token123, i32 0, i32 0) ; (%rs4gc.s7.relocated, %rs4gc.s7.relocated)
  br label %pget.recv_merge.82

shadow.root.barrier.109:                          ; preds = %pget.recv_merge.82
  call void @js_write_barrier_root_nanbox(i64 %r729) #8
  br label %shadow.root.barrier.done.110

shadow.root.barrier.done.110:                     ; preds = %shadow.root.barrier.109, %pget.recv_merge.82
  %statepoint_token126 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_process_cpu_usage, i32 1, i32 0, double 0x7FFC000000000001, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0430, ptr addrspace(1) %rs4gc.s8) ]
  %r733127 = call double @llvm.experimental.gc.result.f64(token %statepoint_token126)
  %rs4gc.s7.relocated128 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token126, i32 0, i32 0) ; (%.0430, %.0430)
  %rs4gc.s8.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token126, i32 1, i32 1) ; (%rs4gc.s8, %rs4gc.s8)
  %rs4gc.b9 = bitcast double %r733127 to i64
  %rs4gc.s9 = inttoptr i64 %rs4gc.b9 to ptr addrspace(1)
  %r734.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s9 to i64
  %r734 = call i64 asm "", "=r,0"(i64 %r734.rs4i) #8
  %r735 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r736 = icmp ne i32 %r735, 0
  br i1 %r736, label %shadow.root.barrier.111, label %shadow.root.barrier.done.112

shadow.root.barrier.111:                          ; preds = %shadow.root.barrier.done.110
  call void @js_write_barrier_root_nanbox(i64 %r734) #8
  br label %shadow.root.barrier.done.112

shadow.root.barrier.done.112:                     ; preds = %shadow.root.barrier.111, %shadow.root.barrier.done.110
  %statepoint_token129 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_performance_now, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated, ptr addrspace(1) %rs4gc.s9, ptr addrspace(1) %rs4gc.s7.relocated128) ]
  %r738130 = call double @llvm.experimental.gc.result.f64(token %statepoint_token129)
  %rs4gc.s8.relocated131 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 0, i32 0) ; (%rs4gc.s8.relocated, %rs4gc.s8.relocated)
  %rs4gc.s9.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 1, i32 1) ; (%rs4gc.s9, %rs4gc.s9)
  %rs4gc.s7.relocated132 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token129, i32 2, i32 2) ; (%rs4gc.s7.relocated128, %rs4gc.s7.relocated128)
  %r739.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s7.relocated132 to i64
  %r739.rs4o = call i64 asm "", "=r,0"(i64 %r739.rs4i) #8
  %r739 = bitcast i64 %r739.rs4o to double
  %r740 = bitcast double %r739 to i64
  %rs4gc.s10 = inttoptr i64 %r740 to ptr addrspace(1)
  %r742.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10 to i64
  %r742 = call i64 asm "", "=r,0"(i64 %r742.rs4i) #8
  %r743 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r744 = icmp ne i32 %r743, 0
  br i1 %r744, label %shadow.root.barrier.113, label %shadow.root.barrier.done.114

shadow.root.barrier.113:                          ; preds = %shadow.root.barrier.done.112
  call void @js_write_barrier_root_nanbox(i64 %r742) #8
  br label %shadow.root.barrier.done.114

shadow.root.barrier.done.114:                     ; preds = %shadow.root.barrier.113, %shadow.root.barrier.done.112
  %statepoint_token133 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @"perry_fn_changing_options_worker_ts__run$spec_b", i32 1, i32 0, double %r33578, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated131, ptr addrspace(1) %rs4gc.s9.relocated, ptr addrspace(1) %rs4gc.s10) ]
  %r746134 = call double @llvm.experimental.gc.result.f64(token %statepoint_token133)
  %rs4gc.s8.relocated135 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token133, i32 0, i32 0) ; (%rs4gc.s8.relocated131, %rs4gc.s8.relocated131)
  %rs4gc.s9.relocated136 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token133, i32 1, i32 1) ; (%rs4gc.s9.relocated, %rs4gc.s9.relocated)
  %rs4gc.s10.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token133, i32 2, i32 2) ; (%rs4gc.s10, %rs4gc.s10)
  %r747.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s10.relocated to i64
  %r747 = call i64 asm "", "=r,0"(i64 %r747.rs4i) #8
  %r748 = bitcast i64 %r747 to double
  %r749 = and i64 %r747, -281474976710656
  %r750 = icmp ult i64 %r749, 9221401712017801216
  %r751 = icmp ugt i64 %r749, 9223090561878065152
  %r752 = or i1 %r750, %r751
  %r753 = bitcast double %r746134 to i64
  %r754 = and i64 %r753, -281474976710656
  %r755 = icmp ult i64 %r754, 9221401712017801216
  %r756 = icmp ugt i64 %r754, 9223090561878065152
  %r757 = or i1 %r755, %r756
  %r758 = and i1 %r752, %r757
  br i1 %r758, label %guarded_add.numeric.115, label %guarded_add.dynamic.116

guarded_add.numeric.115:                          ; preds = %shadow.root.barrier.done.114
  %r759 = fadd double %r748, %r746134
  br label %guarded_add.merge.117

guarded_add.dynamic.116:                          ; preds = %shadow.root.barrier.done.114
  %statepoint_token137 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_string_or_number_add, i32 2, i32 0, double %r748, double %r746134, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s8.relocated135, ptr addrspace(1) %rs4gc.s9.relocated136) ]
  %r760138 = call double @llvm.experimental.gc.result.f64(token %statepoint_token137)
  %rs4gc.s8.relocated139 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token137, i32 0, i32 0) ; (%rs4gc.s8.relocated135, %rs4gc.s8.relocated135)
  %rs4gc.s9.relocated140 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token137, i32 1, i32 1) ; (%rs4gc.s9.relocated136, %rs4gc.s9.relocated136)
  br label %guarded_add.merge.117

guarded_add.merge.117:                            ; preds = %guarded_add.dynamic.116, %guarded_add.numeric.115
  %.0436 = phi ptr addrspace(1) [ %rs4gc.s9.relocated136, %guarded_add.numeric.115 ], [ %rs4gc.s9.relocated140, %guarded_add.dynamic.116 ]
  %.0432 = phi ptr addrspace(1) [ %rs4gc.s8.relocated135, %guarded_add.numeric.115 ], [ %rs4gc.s8.relocated139, %guarded_add.dynamic.116 ]
  %r761 = phi double [ %r759, %guarded_add.numeric.115 ], [ %r760138, %guarded_add.dynamic.116 ]
  %rs4gc.b11 = bitcast double %r761 to i64
  %rs4gc.s11 = inttoptr i64 %rs4gc.b11 to ptr addrspace(1)
  %r762.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11 to i64
  %r762 = call i64 asm "", "=r,0"(i64 %r762.rs4i) #8
  %r763 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r764 = icmp ne i32 %r763, 0
  br i1 %r764, label %shadow.root.barrier.118, label %shadow.root.barrier.done.119

shadow.root.barrier.118:                          ; preds = %guarded_add.merge.117
  call void @js_write_barrier_root_nanbox(i64 %r762) #8
  br label %shadow.root.barrier.done.119

shadow.root.barrier.done.119:                     ; preds = %shadow.root.barrier.118, %guarded_add.merge.117
  %statepoint_token141 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_performance_now, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11, ptr addrspace(1) %.0432, ptr addrspace(1) %.0436) ]
  %r766142 = call double @llvm.experimental.gc.result.f64(token %statepoint_token141)
  %rs4gc.s11.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 0, i32 0) ; (%rs4gc.s11, %rs4gc.s11)
  %rs4gc.s8.relocated143 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 1, i32 1) ; (%.0432, %.0432)
  %rs4gc.s9.relocated144 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token141, i32 2, i32 2) ; (%.0436, %.0436)
  %r768 = bitcast double %r766142 to i64
  %r769 = and i64 %r768, -281474976710656
  %r770 = icmp ult i64 %r769, 9221401712017801216
  %r771 = icmp ugt i64 %r769, 9223090561878065152
  %r772 = or i1 %r770, %r771
  %r773 = bitcast double %r738130 to i64
  %r774 = and i64 %r773, -281474976710656
  %r775 = icmp ult i64 %r774, 9221401712017801216
  %r776 = icmp ugt i64 %r774, 9223090561878065152
  %r777 = or i1 %r775, %r776
  %r778 = and i1 %r772, %r777
  br i1 %r778, label %guarded_arith.numeric.120, label %guarded_arith.dynamic.121

guarded_arith.numeric.120:                        ; preds = %shadow.root.barrier.done.119
  %r779 = fsub double %r766142, %r738130
  br label %guarded_arith.merge.122

guarded_arith.dynamic.121:                        ; preds = %shadow.root.barrier.done.119
  %statepoint_token145 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_sub, i32 2, i32 0, double %r766142, double %r738130, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated, ptr addrspace(1) %rs4gc.s8.relocated143, ptr addrspace(1) %rs4gc.s9.relocated144) ]
  %r780146 = call double @llvm.experimental.gc.result.f64(token %statepoint_token145)
  %rs4gc.s11.relocated147 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token145, i32 0, i32 0) ; (%rs4gc.s11.relocated, %rs4gc.s11.relocated)
  %rs4gc.s8.relocated148 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token145, i32 1, i32 1) ; (%rs4gc.s8.relocated143, %rs4gc.s8.relocated143)
  %rs4gc.s9.relocated149 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token145, i32 2, i32 2) ; (%rs4gc.s9.relocated144, %rs4gc.s9.relocated144)
  br label %guarded_arith.merge.122

guarded_arith.merge.122:                          ; preds = %guarded_arith.dynamic.121, %guarded_arith.numeric.120
  %.0445 = phi ptr addrspace(1) [ %rs4gc.s11.relocated, %guarded_arith.numeric.120 ], [ %rs4gc.s11.relocated147, %guarded_arith.dynamic.121 ]
  %.1437 = phi ptr addrspace(1) [ %rs4gc.s9.relocated144, %guarded_arith.numeric.120 ], [ %rs4gc.s9.relocated149, %guarded_arith.dynamic.121 ]
  %.1433 = phi ptr addrspace(1) [ %rs4gc.s8.relocated143, %guarded_arith.numeric.120 ], [ %rs4gc.s8.relocated148, %guarded_arith.dynamic.121 ]
  %r781 = phi double [ %r779, %guarded_arith.numeric.120 ], [ %r780146, %guarded_arith.dynamic.121 ]
  %statepoint_token150 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double)) @js_process_cpu_usage, i32 1, i32 0, double 0x7FFC000000000001, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.0445, ptr addrspace(1) %.1433, ptr addrspace(1) %.1437) ]
  %r783151 = call double @llvm.experimental.gc.result.f64(token %statepoint_token150)
  %rs4gc.s11.relocated152 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 0, i32 0) ; (%.0445, %.0445)
  %rs4gc.s8.relocated153 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 1, i32 1) ; (%.1433, %.1433)
  %rs4gc.s9.relocated154 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token150, i32 2, i32 2) ; (%.1437, %.1437)
  %rs4gc.b12 = bitcast double %r783151 to i64
  %rs4gc.s12 = inttoptr i64 %rs4gc.b12 to ptr addrspace(1)
  %r784.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12 to i64
  %r784 = call i64 asm "", "=r,0"(i64 %r784.rs4i) #8
  %r785 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r786 = icmp ne i32 %r785, 0
  br i1 %r786, label %shadow.root.barrier.123, label %shadow.root.barrier.done.124

shadow.root.barrier.123:                          ; preds = %guarded_arith.merge.122
  call void @js_write_barrier_root_nanbox(i64 %r784) #8
  br label %shadow.root.barrier.done.124

shadow.root.barrier.done.124:                     ; preds = %shadow.root.barrier.123, %guarded_arith.merge.122
  %statepoint_token155 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 8, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated152, ptr addrspace(1) %rs4gc.s8.relocated153, ptr addrspace(1) %rs4gc.s9.relocated154, ptr addrspace(1) %rs4gc.s12) ]
  %r787156 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token155)
  %rs4gc.s11.relocated157 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 0, i32 0) ; (%rs4gc.s11.relocated152, %rs4gc.s11.relocated152)
  %rs4gc.s8.relocated158 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 1, i32 1) ; (%rs4gc.s8.relocated153, %rs4gc.s8.relocated153)
  %rs4gc.s9.relocated159 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 2, i32 2) ; (%rs4gc.s9.relocated154, %rs4gc.s9.relocated154)
  %rs4gc.s12.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token155, i32 3, i32 3) ; (%rs4gc.s12, %rs4gc.s12)
  %rs4gc.s13 = inttoptr i64 %r787156 to ptr addrspace(1)
  %r788.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r788 = call i64 asm "", "=r,0"(i64 %r788.rs4i) #8
  %r789 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r790 = icmp ne i32 %r789, 0
  br i1 %r790, label %shadow.root.barrier.125, label %shadow.root.barrier.done.126

shadow.root.barrier.125:                          ; preds = %shadow.root.barrier.done.124
  call void @js_write_barrier_root_nanbox(i64 %r788) #8
  br label %shadow.root.barrier.done.126

shadow.root.barrier.done.126:                     ; preds = %shadow.root.barrier.125, %shadow.root.barrier.done.124
  %r791 = load double, ptr @changing_options_worker_ts_.str.12.handle, align 8
  %r792.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s13 to i64
  %r792 = call i64 asm "", "=r,0"(i64 %r792.rs4i) #8
  %statepoint_token160 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r792, double %r791, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated157, ptr addrspace(1) %rs4gc.s8.relocated158, ptr addrspace(1) %rs4gc.s9.relocated159, ptr addrspace(1) %rs4gc.s12.relocated) ]
  %r793161 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token160)
  %rs4gc.s11.relocated162 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 0, i32 0) ; (%rs4gc.s11.relocated157, %rs4gc.s11.relocated157)
  %rs4gc.s8.relocated163 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 1, i32 1) ; (%rs4gc.s8.relocated158, %rs4gc.s8.relocated158)
  %rs4gc.s9.relocated164 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 2, i32 2) ; (%rs4gc.s9.relocated159, %rs4gc.s9.relocated159)
  %rs4gc.s12.relocated165 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token160, i32 3, i32 3) ; (%rs4gc.s12.relocated, %rs4gc.s12.relocated)
  %rs4gc.s14 = inttoptr i64 %r793161 to ptr addrspace(1)
  %r794.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r794 = call i64 asm "", "=r,0"(i64 %r794.rs4i) #8
  %r795 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r796 = icmp ne i32 %r795, 0
  br i1 %r796, label %shadow.root.barrier.127, label %shadow.root.barrier.done.128

shadow.root.barrier.127:                          ; preds = %shadow.root.barrier.done.126
  call void @js_write_barrier_root_nanbox(i64 %r794) #8
  br label %shadow.root.barrier.done.128

shadow.root.barrier.done.128:                     ; preds = %shadow.root.barrier.127, %shadow.root.barrier.done.126
  %r798.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s14 to i64
  %r798 = call i64 asm "", "=r,0"(i64 %r798.rs4i) #8
  %statepoint_token166 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r798, double %r781, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated162, ptr addrspace(1) %rs4gc.s8.relocated163, ptr addrspace(1) %rs4gc.s9.relocated164, ptr addrspace(1) %rs4gc.s12.relocated165) ]
  %r799167 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token166)
  %rs4gc.s11.relocated168 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token166, i32 0, i32 0) ; (%rs4gc.s11.relocated162, %rs4gc.s11.relocated162)
  %rs4gc.s8.relocated169 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token166, i32 1, i32 1) ; (%rs4gc.s8.relocated163, %rs4gc.s8.relocated163)
  %rs4gc.s9.relocated170 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token166, i32 2, i32 2) ; (%rs4gc.s9.relocated164, %rs4gc.s9.relocated164)
  %rs4gc.s12.relocated171 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token166, i32 3, i32 3) ; (%rs4gc.s12.relocated165, %rs4gc.s12.relocated165)
  %rs4gc.s15 = inttoptr i64 %r799167 to ptr addrspace(1)
  %r800.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s15 to i64
  %r800 = call i64 asm "", "=r,0"(i64 %r800.rs4i) #8
  %r801 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r802 = icmp ne i32 %r801, 0
  br i1 %r802, label %shadow.root.barrier.129, label %shadow.root.barrier.done.130

shadow.root.barrier.129:                          ; preds = %shadow.root.barrier.done.128
  call void @js_write_barrier_root_nanbox(i64 %r800) #8
  br label %shadow.root.barrier.done.130

shadow.root.barrier.done.130:                     ; preds = %shadow.root.barrier.129, %shadow.root.barrier.done.128
  %r803.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12.relocated171 to i64
  %r803.rs4o = call i64 asm "", "=r,0"(i64 %r803.rs4i) #8
  %r803 = bitcast i64 %r803.rs4o to double
  %r804 = bitcast double %r803 to i64
  %r805 = and i64 %r804, 281474976710655
  %r806 = lshr i64 %r804, 48
  %r807 = and i64 %r806, 65533
  %r808 = icmp eq i64 %r807, 32765
  br i1 %r808, label %pget.recv_ok.132, label %pget.recv_other.136

pget.recv_sso.131:                                ; preds = %pget.recv_other.136
  %r946 = load double, ptr @changing_options_worker_ts_.str.13.handle, align 8
  %r947 = bitcast double %r946 to i64
  %r948 = and i64 %r947, 281474976710655
  %statepoint_token172 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r804, i64 %r948, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated168, ptr addrspace(1) %rs4gc.s8.relocated169, ptr addrspace(1) %rs4gc.s9.relocated170, ptr addrspace(1) %rs4gc.s12.relocated171, ptr addrspace(1) %rs4gc.s15) ]
  %r949173 = call double @llvm.experimental.gc.result.f64(token %statepoint_token172)
  %rs4gc.s11.relocated174 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 0, i32 0) ; (%rs4gc.s11.relocated168, %rs4gc.s11.relocated168)
  %rs4gc.s8.relocated175 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 1, i32 1) ; (%rs4gc.s8.relocated169, %rs4gc.s8.relocated169)
  %rs4gc.s9.relocated176 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 2, i32 2) ; (%rs4gc.s9.relocated170, %rs4gc.s9.relocated170)
  %rs4gc.s12.relocated177 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 3, i32 3) ; (%rs4gc.s12.relocated171, %rs4gc.s12.relocated171)
  %rs4gc.s15.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token172, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.135

pget.recv_ok.132:                                 ; preds = %shadow.root.barrier.done.130
  %r815 = icmp ugt i64 %r805, 1048575
  br i1 %r815, label %pic.recv_hdr.153, label %pic.miss.cold.150

pget.recv_bad.133:                                ; preds = %pget.check_class_ref.137
  %r938 = icmp eq i64 %r804, 9222246136947933185
  %r939 = icmp eq i64 %r804, 9222246136947933186
  %r940 = or i1 %r938, %r939
  br i1 %r940, label %pget.throw_nullish.160, label %pget.recv_undef_return.161

pget.recv_class_ref.134:                          ; preds = %pget.check_class_ref.137
  %r811 = load double, ptr @changing_options_worker_ts_.str.13.handle, align 8
  %r812 = bitcast double %r811 to i64
  %r813 = and i64 %r812, 281474976710655
  %statepoint_token178 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 1175166488852561941, i64 %r804, i64 %r813, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated168, ptr addrspace(1) %rs4gc.s8.relocated169, ptr addrspace(1) %rs4gc.s9.relocated170, ptr addrspace(1) %rs4gc.s12.relocated171, ptr addrspace(1) %rs4gc.s15) ]
  %r814179 = call double @llvm.experimental.gc.result.f64(token %statepoint_token178)
  %rs4gc.s11.relocated180 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 0, i32 0) ; (%rs4gc.s11.relocated168, %rs4gc.s11.relocated168)
  %rs4gc.s8.relocated181 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 1, i32 1) ; (%rs4gc.s8.relocated169, %rs4gc.s8.relocated169)
  %rs4gc.s9.relocated182 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 2, i32 2) ; (%rs4gc.s9.relocated170, %rs4gc.s9.relocated170)
  %rs4gc.s12.relocated183 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 3, i32 3) ; (%rs4gc.s12.relocated171, %rs4gc.s12.relocated171)
  %rs4gc.s15.relocated184 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token178, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.135

pget.recv_merge.135:                              ; preds = %pget.recv_undef_return.161, %pic.merge.152, %pget.recv_class_ref.134, %pget.recv_sso.131
  %.0462 = phi ptr addrspace(1) [ %.1463, %pic.merge.152 ], [ %rs4gc.s15.relocated, %pget.recv_sso.131 ], [ %rs4gc.s15.relocated184, %pget.recv_class_ref.134 ], [ %rs4gc.s15.relocated206, %pget.recv_undef_return.161 ]
  %.0457 = phi ptr addrspace(1) [ %.1458, %pic.merge.152 ], [ %rs4gc.s12.relocated177, %pget.recv_sso.131 ], [ %rs4gc.s12.relocated183, %pget.recv_class_ref.134 ], [ %rs4gc.s12.relocated205, %pget.recv_undef_return.161 ]
  %.1446 = phi ptr addrspace(1) [ %.2447, %pic.merge.152 ], [ %rs4gc.s11.relocated174, %pget.recv_sso.131 ], [ %rs4gc.s11.relocated180, %pget.recv_class_ref.134 ], [ %rs4gc.s11.relocated202, %pget.recv_undef_return.161 ]
  %.2438 = phi ptr addrspace(1) [ %.3439, %pic.merge.152 ], [ %rs4gc.s9.relocated176, %pget.recv_sso.131 ], [ %rs4gc.s9.relocated182, %pget.recv_class_ref.134 ], [ %rs4gc.s9.relocated204, %pget.recv_undef_return.161 ]
  %.2434 = phi ptr addrspace(1) [ %.3435, %pic.merge.152 ], [ %rs4gc.s8.relocated175, %pget.recv_sso.131 ], [ %rs4gc.s8.relocated181, %pget.recv_class_ref.134 ], [ %rs4gc.s8.relocated203, %pget.recv_undef_return.161 ]
  %r950 = phi double [ %r937, %pic.merge.152 ], [ %r945201, %pget.recv_undef_return.161 ], [ %r949173, %pget.recv_sso.131 ], [ %r814179, %pget.recv_class_ref.134 ]
  %r951 = bitcast double %r950 to i64
  %rs4gc.s16 = inttoptr i64 %r951 to ptr addrspace(1)
  %r953.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s16 to i64
  %r953 = call i64 asm "", "=r,0"(i64 %r953.rs4i) #8
  %r954 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r955 = icmp ne i32 %r954, 0
  br i1 %r955, label %shadow.root.barrier.162, label %shadow.root.barrier.done.163

pget.recv_other.136:                              ; preds = %shadow.root.barrier.done.130
  %r809 = icmp eq i64 %r806, 32761
  br i1 %r809, label %pget.recv_sso.131, label %pget.check_class_ref.137

pget.check_class_ref.137:                         ; preds = %pget.recv_other.136
  %r810 = icmp eq i64 %r806, 32766
  br i1 %r810, label %pget.recv_class_ref.134, label %pget.recv_bad.133

pic.hit.138:                                      ; preds = %pic.token.154
  %r840 = getelementptr i64, ptr %r825, i64 1
  %r841 = load i64, ptr %r840, align 8
  %r842 = and i64 %r841, 1073741824
  %r843 = icmp ne i64 %r842, 0
  br i1 %r843, label %pic.hit.overflow.155, label %pic.hit.inline.156

pic.hit.live.139:                                 ; preds = %pic.hit.inline.156
  br label %pic.merge.152

pic.prefix.guard.140:                             ; preds = %pic.token.154
  %r856 = getelementptr i64, ptr %r825, i64 2
  %r857 = load i64, ptr %r856, align 8
  %r858 = icmp ne i64 %r857, 0
  br i1 %r858, label %pic.prefix.meta.141, label %pic.miss.149

pic.prefix.meta.141:                              ; preds = %pic.prefix.guard.140
  %r859 = add nuw nsw i64 %r805, 8
  %r860 = inttoptr i64 %r859 to ptr
  %r861 = load i64, ptr %r860, align 8
  %r862 = icmp ne i64 %r861, 0
  br i1 %r862, label %pic.prefix.token.142, label %pic.miss.149

pic.prefix.token.142:                             ; preds = %pic.prefix.meta.141
  %r863 = inttoptr i64 %r861 to ptr
  %r864 = getelementptr i64, ptr %r863, i64 6
  %r865 = load i64, ptr %r864, align 8
  %r866 = icmp eq i64 %r865, %r857
  br i1 %r866, label %pic.prefix.hit.143, label %pic.miss.149

pic.prefix.hit.143:                               ; preds = %pic.prefix.token.142
  %r867 = getelementptr i64, ptr %r825, i64 1
  %r868 = load i64, ptr %r867, align 8
  %r869 = shl i64 %r868, 3
  %r870 = add nuw nsw i64 %r805, 16
  %r871 = add i64 %r870, %r869
  %r872 = inttoptr i64 %r871 to ptr
  %r873 = load double, ptr %r872, align 8
  br label %pic.merge.152

pic.desc.classify.144:                            ; preds = %pic.recv_hdr.153
  %r829 = and i1 %r819, %r826
  br i1 %r829, label %pic.desc.prefix.guard.145, label %pic.miss.cold.150

pic.desc.prefix.guard.145:                        ; preds = %pic.desc.classify.144
  %r874 = getelementptr i64, ptr %r825, i64 2
  %r875 = load i64, ptr %r874, align 8
  %r876 = icmp ne i64 %r875, 0
  br i1 %r876, label %pic.desc.prefix.meta.146, label %pic.miss.cold.150

pic.desc.prefix.meta.146:                         ; preds = %pic.desc.prefix.guard.145
  %r877 = add nuw nsw i64 %r805, 8
  %r878 = inttoptr i64 %r877 to ptr
  %r879 = load i64, ptr %r878, align 8
  %r880 = icmp ne i64 %r879, 0
  br i1 %r880, label %pic.desc.prefix.token.147, label %pic.miss.cold.150

pic.desc.prefix.token.147:                        ; preds = %pic.desc.prefix.meta.146
  %r881 = inttoptr i64 %r879 to ptr
  %r882 = getelementptr i64, ptr %r881, i64 6
  %r883 = load i64, ptr %r882, align 8
  %r884 = icmp eq i64 %r883, %r875
  br i1 %r884, label %pic.desc.prefix.hit.148, label %pic.miss.cold.150

pic.desc.prefix.hit.148:                          ; preds = %pic.desc.prefix.token.147
  %r885 = getelementptr i64, ptr %r825, i64 1
  %r886 = load i64, ptr %r885, align 8
  %r887 = shl i64 %r886, 3
  %r888 = add nuw nsw i64 %r805, 16
  %r889 = add i64 %r888, %r887
  %r890 = inttoptr i64 %r889 to ptr
  %r891 = load double, ptr %r890, align 8
  br label %pic.merge.152

pic.miss.149:                                     ; preds = %pic.hit.inline.156, %pic.prefix.token.142, %pic.prefix.meta.141, %pic.prefix.guard.140
  %r892 = getelementptr i64, ptr %r825, i64 3
  %r893 = load i64, ptr %r892, align 8
  %r894 = icmp sgt i64 %r893, 0
  br i1 %r894, label %pic.ways.157, label %pic.miss.call.151

pic.miss.cold.150:                                ; preds = %pic.desc.prefix.token.147, %pic.desc.prefix.meta.146, %pic.desc.prefix.guard.145, %pic.desc.classify.144, %pget.recv_ok.132
  br label %pic.miss.call.151

pic.miss.call.151:                                ; preds = %pic.way.load.158, %pic.ways.157, %pic.miss.cold.150, %pic.miss.149
  %r933 = load double, ptr @changing_options_worker_ts_.str.13.handle, align 8
  %r934 = bitcast double %r933 to i64
  %r935 = and i64 %r934, 281474976710655
  %statepoint_token185 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r805, i64 %r935, ptr @perry_ic_changing_options_worker_ts__22, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated168, ptr addrspace(1) %rs4gc.s8.relocated169, ptr addrspace(1) %rs4gc.s9.relocated170, ptr addrspace(1) %rs4gc.s12.relocated171, ptr addrspace(1) %rs4gc.s15) ]
  %r936186 = call double @llvm.experimental.gc.result.f64(token %statepoint_token185)
  %rs4gc.s11.relocated187 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token185, i32 0, i32 0) ; (%rs4gc.s11.relocated168, %rs4gc.s11.relocated168)
  %rs4gc.s8.relocated188 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token185, i32 1, i32 1) ; (%rs4gc.s8.relocated169, %rs4gc.s8.relocated169)
  %rs4gc.s9.relocated189 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token185, i32 2, i32 2) ; (%rs4gc.s9.relocated170, %rs4gc.s9.relocated170)
  %rs4gc.s12.relocated190 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token185, i32 3, i32 3) ; (%rs4gc.s12.relocated171, %rs4gc.s12.relocated171)
  %rs4gc.s15.relocated191 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token185, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pic.merge.152

pic.merge.152:                                    ; preds = %pic.way.live.159, %pic.hit.overflow.155, %pic.miss.call.151, %pic.desc.prefix.hit.148, %pic.prefix.hit.143, %pic.hit.live.139
  %.1463 = phi ptr addrspace(1) [ %rs4gc.s15.relocated198, %pic.hit.overflow.155 ], [ %rs4gc.s15.relocated191, %pic.miss.call.151 ], [ %rs4gc.s15, %pic.way.live.159 ], [ %rs4gc.s15, %pic.hit.live.139 ], [ %rs4gc.s15, %pic.prefix.hit.143 ], [ %rs4gc.s15, %pic.desc.prefix.hit.148 ]
  %.1458 = phi ptr addrspace(1) [ %rs4gc.s12.relocated197, %pic.hit.overflow.155 ], [ %rs4gc.s12.relocated190, %pic.miss.call.151 ], [ %rs4gc.s12.relocated171, %pic.way.live.159 ], [ %rs4gc.s12.relocated171, %pic.hit.live.139 ], [ %rs4gc.s12.relocated171, %pic.prefix.hit.143 ], [ %rs4gc.s12.relocated171, %pic.desc.prefix.hit.148 ]
  %.2447 = phi ptr addrspace(1) [ %rs4gc.s11.relocated194, %pic.hit.overflow.155 ], [ %rs4gc.s11.relocated187, %pic.miss.call.151 ], [ %rs4gc.s11.relocated168, %pic.way.live.159 ], [ %rs4gc.s11.relocated168, %pic.hit.live.139 ], [ %rs4gc.s11.relocated168, %pic.prefix.hit.143 ], [ %rs4gc.s11.relocated168, %pic.desc.prefix.hit.148 ]
  %.3439 = phi ptr addrspace(1) [ %rs4gc.s9.relocated196, %pic.hit.overflow.155 ], [ %rs4gc.s9.relocated189, %pic.miss.call.151 ], [ %rs4gc.s9.relocated170, %pic.way.live.159 ], [ %rs4gc.s9.relocated170, %pic.hit.live.139 ], [ %rs4gc.s9.relocated170, %pic.prefix.hit.143 ], [ %rs4gc.s9.relocated170, %pic.desc.prefix.hit.148 ]
  %.3435 = phi ptr addrspace(1) [ %rs4gc.s8.relocated195, %pic.hit.overflow.155 ], [ %rs4gc.s8.relocated188, %pic.miss.call.151 ], [ %rs4gc.s8.relocated169, %pic.way.live.159 ], [ %rs4gc.s8.relocated169, %pic.hit.live.139 ], [ %rs4gc.s8.relocated169, %pic.prefix.hit.143 ], [ %rs4gc.s8.relocated169, %pic.desc.prefix.hit.148 ]
  %r937 = phi double [ %r853, %pic.hit.live.139 ], [ %r848193, %pic.hit.overflow.155 ], [ %r873, %pic.prefix.hit.143 ], [ %r891, %pic.desc.prefix.hit.148 ], [ %r930, %pic.way.live.159 ], [ %r936186, %pic.miss.call.151 ]
  br label %pget.recv_merge.135

pic.recv_hdr.153:                                 ; preds = %pget.recv_ok.132
  %r816 = sub nuw nsw i64 %r805, 8
  %r817 = inttoptr i64 %r816 to ptr
  %r818 = load i8, ptr %r817, align 1
  %r819 = icmp eq i8 %r818, 2
  %r820 = sub nuw nsw i64 %r805, 6
  %r821 = inttoptr i64 %r820 to ptr
  %r822 = load i16, ptr %r821, align 2
  %r823 = and i16 %r822, 2048
  %r824 = icmp eq i16 %r823, 0
  %r825 = load ptr, ptr @perry_ic_changing_options_worker_ts__22, align 8
  %r826 = icmp ne ptr %r825, null
  %r827 = and i1 %r819, %r824
  %r828 = and i1 %r827, %r826
  br i1 %r828, label %pic.token.154, label %pic.desc.classify.144

pic.token.154:                                    ; preds = %pic.recv_hdr.153
  %r830 = add nuw nsw i64 %r805, 4
  %r831 = inttoptr i64 %r830 to ptr
  %r832 = load i32, ptr %r831, align 4
  %r833 = zext i32 %r832 to i64
  %r834 = or i64 %r833, 4611686018427387904
  %r835 = icmp ne i32 %r832, 0
  %r836 = getelementptr i64, ptr %r825, i64 0
  %r837 = load i64, ptr %r836, align 8
  %r838 = icmp eq i64 %r834, %r837
  %r839 = and i1 %r838, %r835
  br i1 %r839, label %pic.hit.138, label %pic.prefix.guard.140

pic.hit.overflow.155:                             ; preds = %pic.hit.138
  %r844 = load double, ptr @changing_options_worker_ts_.str.13.handle, align 8
  %r845 = bitcast double %r844 to i64
  %r846 = and i64 %r845, 281474976710655
  %r847 = trunc i64 %r841 to i32
  %statepoint_token192 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r805, i64 %r846, i32 %r847, ptr @perry_ic_changing_options_worker_ts__22, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated168, ptr addrspace(1) %rs4gc.s8.relocated169, ptr addrspace(1) %rs4gc.s9.relocated170, ptr addrspace(1) %rs4gc.s12.relocated171, ptr addrspace(1) %rs4gc.s15) ]
  %r848193 = call double @llvm.experimental.gc.result.f64(token %statepoint_token192)
  %rs4gc.s11.relocated194 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token192, i32 0, i32 0) ; (%rs4gc.s11.relocated168, %rs4gc.s11.relocated168)
  %rs4gc.s8.relocated195 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token192, i32 1, i32 1) ; (%rs4gc.s8.relocated169, %rs4gc.s8.relocated169)
  %rs4gc.s9.relocated196 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token192, i32 2, i32 2) ; (%rs4gc.s9.relocated170, %rs4gc.s9.relocated170)
  %rs4gc.s12.relocated197 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token192, i32 3, i32 3) ; (%rs4gc.s12.relocated171, %rs4gc.s12.relocated171)
  %rs4gc.s15.relocated198 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token192, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pic.merge.152

pic.hit.inline.156:                               ; preds = %pic.hit.138
  %r849 = shl i64 %r841, 3
  %r850 = add nuw nsw i64 %r805, 16
  %r851 = add i64 %r850, %r849
  %r852 = inttoptr i64 %r851 to ptr
  %r853 = load double, ptr %r852, align 8
  %r854 = bitcast double %r853 to i64
  %r855 = icmp eq i64 %r854, 9222246136947933200
  br i1 %r855, label %pic.miss.149, label %pic.hit.live.139

pic.ways.157:                                     ; preds = %pic.miss.149
  %r895 = getelementptr i64, ptr %r825, i64 4
  %r896 = load i64, ptr %r895, align 8
  %r897 = icmp eq i64 %r896, %r834
  %r898 = getelementptr i64, ptr %r825, i64 5
  %r899 = load i64, ptr %r898, align 8
  %r900 = select i1 %r897, i64 %r899, i64 0
  %r901 = getelementptr i64, ptr %r825, i64 6
  %r902 = load i64, ptr %r901, align 8
  %r903 = icmp eq i64 %r902, %r834
  %r904 = getelementptr i64, ptr %r825, i64 7
  %r905 = load i64, ptr %r904, align 8
  %r906 = select i1 %r903, i64 %r905, i64 0
  %r907 = getelementptr i64, ptr %r825, i64 8
  %r908 = load i64, ptr %r907, align 8
  %r909 = icmp eq i64 %r908, %r834
  %r910 = getelementptr i64, ptr %r825, i64 9
  %r911 = load i64, ptr %r910, align 8
  %r912 = select i1 %r909, i64 %r911, i64 0
  %r913 = getelementptr i64, ptr %r825, i64 10
  %r914 = load i64, ptr %r913, align 8
  %r915 = icmp eq i64 %r914, %r834
  %r916 = getelementptr i64, ptr %r825, i64 11
  %r917 = load i64, ptr %r916, align 8
  %r918 = select i1 %r915, i64 %r917, i64 0
  %r919 = or i1 %r897, %r903
  %r920 = select i1 %r897, i64 %r900, i64 %r906
  %r921 = or i1 %r909, %r915
  %r922 = select i1 %r909, i64 %r912, i64 %r918
  %r923 = or i1 %r919, %r921
  %r924 = select i1 %r919, i64 %r920, i64 %r922
  %r925 = and i1 %r835, %r923
  br i1 %r925, label %pic.way.load.158, label %pic.miss.call.151

pic.way.load.158:                                 ; preds = %pic.ways.157
  %r926 = shl i64 %r924, 3
  %r927 = add nuw nsw i64 %r805, 16
  %r928 = add i64 %r927, %r926
  %r929 = inttoptr i64 %r928 to ptr
  %r930 = load double, ptr %r929, align 8
  %r931 = bitcast double %r930 to i64
  %r932 = icmp eq i64 %r931, 9222246136947933200
  br i1 %r932, label %pic.miss.call.151, label %pic.way.live.159

pic.way.live.159:                                 ; preds = %pic.way.load.158
  br label %pic.merge.152

pget.throw_nullish.160:                           ; preds = %pget.recv_bad.133
  %r941 = zext i1 %r939 to i32
  %statepoint_token199 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r941, ptr @changing_options_worker_ts_.str.13.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.161:                       ; preds = %pget.recv_bad.133
  %r942 = load double, ptr @changing_options_worker_ts_.str.13.handle, align 8
  %r943 = bitcast double %r942 to i64
  %r944 = and i64 %r943, 281474976710655
  %statepoint_token200 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r804, i64 %r944, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated168, ptr addrspace(1) %rs4gc.s8.relocated169, ptr addrspace(1) %rs4gc.s9.relocated170, ptr addrspace(1) %rs4gc.s12.relocated171, ptr addrspace(1) %rs4gc.s15) ]
  %r945201 = call double @llvm.experimental.gc.result.f64(token %statepoint_token200)
  %rs4gc.s11.relocated202 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token200, i32 0, i32 0) ; (%rs4gc.s11.relocated168, %rs4gc.s11.relocated168)
  %rs4gc.s8.relocated203 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token200, i32 1, i32 1) ; (%rs4gc.s8.relocated169, %rs4gc.s8.relocated169)
  %rs4gc.s9.relocated204 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token200, i32 2, i32 2) ; (%rs4gc.s9.relocated170, %rs4gc.s9.relocated170)
  %rs4gc.s12.relocated205 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token200, i32 3, i32 3) ; (%rs4gc.s12.relocated171, %rs4gc.s12.relocated171)
  %rs4gc.s15.relocated206 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token200, i32 4, i32 4) ; (%rs4gc.s15, %rs4gc.s15)
  br label %pget.recv_merge.135

shadow.root.barrier.162:                          ; preds = %pget.recv_merge.135
  call void @js_write_barrier_root_nanbox(i64 %r953) #8
  br label %shadow.root.barrier.done.163

shadow.root.barrier.done.163:                     ; preds = %shadow.root.barrier.162, %pget.recv_merge.135
  %r956.rs4i = ptrtoint ptr addrspace(1) %.2438 to i64
  %r956.rs4o = call i64 asm "", "=r,0"(i64 %r956.rs4i) #8
  %r956 = bitcast i64 %r956.rs4o to double
  %r957 = bitcast double %r956 to i64
  %r958 = and i64 %r957, 281474976710655
  %r959 = lshr i64 %r957, 48
  %r960 = and i64 %r959, 65533
  %r961 = icmp eq i64 %r960, 32765
  br i1 %r961, label %pget.recv_ok.165, label %pget.recv_other.169

pget.recv_sso.164:                                ; preds = %pget.recv_other.169
  %r1099 = load double, ptr @changing_options_worker_ts_.str.13.handle, align 8
  %r1100 = bitcast double %r1099 to i64
  %r1101 = and i64 %r1100, 281474976710655
  %statepoint_token207 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r957, i64 %r1101, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1446, ptr addrspace(1) %.2434, ptr addrspace(1) %.2438, ptr addrspace(1) %.0457, ptr addrspace(1) %.0462, ptr addrspace(1) %rs4gc.s16) ]
  %r1102208 = call double @llvm.experimental.gc.result.f64(token %statepoint_token207)
  %rs4gc.s11.relocated209 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 0, i32 0) ; (%.1446, %.1446)
  %rs4gc.s8.relocated210 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 1, i32 1) ; (%.2434, %.2434)
  %rs4gc.s9.relocated211 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 2, i32 2) ; (%.2438, %.2438)
  %rs4gc.s12.relocated212 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 3, i32 3) ; (%.0457, %.0457)
  %rs4gc.s15.relocated213 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 4, i32 4) ; (%.0462, %.0462)
  %rs4gc.s16.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token207, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pget.recv_merge.168

pget.recv_ok.165:                                 ; preds = %shadow.root.barrier.done.163
  %r968 = icmp ugt i64 %r958, 1048575
  br i1 %r968, label %pic.recv_hdr.186, label %pic.miss.cold.183

pget.recv_bad.166:                                ; preds = %pget.check_class_ref.170
  %r1091 = icmp eq i64 %r957, 9222246136947933185
  %r1092 = icmp eq i64 %r957, 9222246136947933186
  %r1093 = or i1 %r1091, %r1092
  br i1 %r1093, label %pget.throw_nullish.193, label %pget.recv_undef_return.194

pget.recv_class_ref.167:                          ; preds = %pget.check_class_ref.170
  %r964 = load double, ptr @changing_options_worker_ts_.str.13.handle, align 8
  %r965 = bitcast double %r964 to i64
  %r966 = and i64 %r965, 281474976710655
  %statepoint_token214 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 1175166488852561943, i64 %r957, i64 %r966, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1446, ptr addrspace(1) %.2434, ptr addrspace(1) %.2438, ptr addrspace(1) %.0457, ptr addrspace(1) %.0462, ptr addrspace(1) %rs4gc.s16) ]
  %r967215 = call double @llvm.experimental.gc.result.f64(token %statepoint_token214)
  %rs4gc.s11.relocated216 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token214, i32 0, i32 0) ; (%.1446, %.1446)
  %rs4gc.s8.relocated217 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token214, i32 1, i32 1) ; (%.2434, %.2434)
  %rs4gc.s9.relocated218 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token214, i32 2, i32 2) ; (%.2438, %.2438)
  %rs4gc.s12.relocated219 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token214, i32 3, i32 3) ; (%.0457, %.0457)
  %rs4gc.s15.relocated220 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token214, i32 4, i32 4) ; (%.0462, %.0462)
  %rs4gc.s16.relocated221 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token214, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pget.recv_merge.168

pget.recv_merge.168:                              ; preds = %pget.recv_undef_return.194, %pic.merge.185, %pget.recv_class_ref.167, %pget.recv_sso.164
  %.0467 = phi ptr addrspace(1) [ %.1468, %pic.merge.185 ], [ %rs4gc.s16.relocated, %pget.recv_sso.164 ], [ %rs4gc.s16.relocated221, %pget.recv_class_ref.167 ], [ %rs4gc.s16.relocated246, %pget.recv_undef_return.194 ]
  %.2464 = phi ptr addrspace(1) [ %.3465, %pic.merge.185 ], [ %rs4gc.s15.relocated213, %pget.recv_sso.164 ], [ %rs4gc.s15.relocated220, %pget.recv_class_ref.167 ], [ %rs4gc.s15.relocated245, %pget.recv_undef_return.194 ]
  %.2459 = phi ptr addrspace(1) [ %.3460, %pic.merge.185 ], [ %rs4gc.s12.relocated212, %pget.recv_sso.164 ], [ %rs4gc.s12.relocated219, %pget.recv_class_ref.167 ], [ %rs4gc.s12.relocated244, %pget.recv_undef_return.194 ]
  %.3448 = phi ptr addrspace(1) [ %.4449, %pic.merge.185 ], [ %rs4gc.s11.relocated209, %pget.recv_sso.164 ], [ %rs4gc.s11.relocated216, %pget.recv_class_ref.167 ], [ %rs4gc.s11.relocated241, %pget.recv_undef_return.194 ]
  %.4440 = phi ptr addrspace(1) [ %.5441, %pic.merge.185 ], [ %rs4gc.s9.relocated211, %pget.recv_sso.164 ], [ %rs4gc.s9.relocated218, %pget.recv_class_ref.167 ], [ %rs4gc.s9.relocated243, %pget.recv_undef_return.194 ]
  %.4 = phi ptr addrspace(1) [ %.5, %pic.merge.185 ], [ %rs4gc.s8.relocated210, %pget.recv_sso.164 ], [ %rs4gc.s8.relocated217, %pget.recv_class_ref.167 ], [ %rs4gc.s8.relocated242, %pget.recv_undef_return.194 ]
  %r1103 = phi double [ %r1090, %pic.merge.185 ], [ %r1098240, %pget.recv_undef_return.194 ], [ %r1102208, %pget.recv_sso.164 ], [ %r967215, %pget.recv_class_ref.167 ]
  %r1104.rs4i = ptrtoint ptr addrspace(1) %.0467 to i64
  %r1104 = call i64 asm "", "=r,0"(i64 %r1104.rs4i) #8
  %r1105 = bitcast i64 %r1104 to double
  %r1106 = and i64 %r1104, -281474976710656
  %r1107 = icmp ult i64 %r1106, 9221401712017801216
  %r1108 = icmp ugt i64 %r1106, 9223090561878065152
  %r1109 = or i1 %r1107, %r1108
  %r1110 = bitcast double %r1103 to i64
  %r1111 = and i64 %r1110, -281474976710656
  %r1112 = icmp ult i64 %r1111, 9221401712017801216
  %r1113 = icmp ugt i64 %r1111, 9223090561878065152
  %r1114 = or i1 %r1112, %r1113
  %r1115 = and i1 %r1109, %r1114
  br i1 %r1115, label %guarded_arith.numeric.195, label %guarded_arith.dynamic.196

pget.recv_other.169:                              ; preds = %shadow.root.barrier.done.163
  %r962 = icmp eq i64 %r959, 32761
  br i1 %r962, label %pget.recv_sso.164, label %pget.check_class_ref.170

pget.check_class_ref.170:                         ; preds = %pget.recv_other.169
  %r963 = icmp eq i64 %r959, 32766
  br i1 %r963, label %pget.recv_class_ref.167, label %pget.recv_bad.166

pic.hit.171:                                      ; preds = %pic.token.187
  %r993 = getelementptr i64, ptr %r978, i64 1
  %r994 = load i64, ptr %r993, align 8
  %r995 = and i64 %r994, 1073741824
  %r996 = icmp ne i64 %r995, 0
  br i1 %r996, label %pic.hit.overflow.188, label %pic.hit.inline.189

pic.hit.live.172:                                 ; preds = %pic.hit.inline.189
  br label %pic.merge.185

pic.prefix.guard.173:                             ; preds = %pic.token.187
  %r1009 = getelementptr i64, ptr %r978, i64 2
  %r1010 = load i64, ptr %r1009, align 8
  %r1011 = icmp ne i64 %r1010, 0
  br i1 %r1011, label %pic.prefix.meta.174, label %pic.miss.182

pic.prefix.meta.174:                              ; preds = %pic.prefix.guard.173
  %r1012 = add nuw nsw i64 %r958, 8
  %r1013 = inttoptr i64 %r1012 to ptr
  %r1014 = load i64, ptr %r1013, align 8
  %r1015 = icmp ne i64 %r1014, 0
  br i1 %r1015, label %pic.prefix.token.175, label %pic.miss.182

pic.prefix.token.175:                             ; preds = %pic.prefix.meta.174
  %r1016 = inttoptr i64 %r1014 to ptr
  %r1017 = getelementptr i64, ptr %r1016, i64 6
  %r1018 = load i64, ptr %r1017, align 8
  %r1019 = icmp eq i64 %r1018, %r1010
  br i1 %r1019, label %pic.prefix.hit.176, label %pic.miss.182

pic.prefix.hit.176:                               ; preds = %pic.prefix.token.175
  %r1020 = getelementptr i64, ptr %r978, i64 1
  %r1021 = load i64, ptr %r1020, align 8
  %r1022 = shl i64 %r1021, 3
  %r1023 = add nuw nsw i64 %r958, 16
  %r1024 = add i64 %r1023, %r1022
  %r1025 = inttoptr i64 %r1024 to ptr
  %r1026 = load double, ptr %r1025, align 8
  br label %pic.merge.185

pic.desc.classify.177:                            ; preds = %pic.recv_hdr.186
  %r982 = and i1 %r972, %r979
  br i1 %r982, label %pic.desc.prefix.guard.178, label %pic.miss.cold.183

pic.desc.prefix.guard.178:                        ; preds = %pic.desc.classify.177
  %r1027 = getelementptr i64, ptr %r978, i64 2
  %r1028 = load i64, ptr %r1027, align 8
  %r1029 = icmp ne i64 %r1028, 0
  br i1 %r1029, label %pic.desc.prefix.meta.179, label %pic.miss.cold.183

pic.desc.prefix.meta.179:                         ; preds = %pic.desc.prefix.guard.178
  %r1030 = add nuw nsw i64 %r958, 8
  %r1031 = inttoptr i64 %r1030 to ptr
  %r1032 = load i64, ptr %r1031, align 8
  %r1033 = icmp ne i64 %r1032, 0
  br i1 %r1033, label %pic.desc.prefix.token.180, label %pic.miss.cold.183

pic.desc.prefix.token.180:                        ; preds = %pic.desc.prefix.meta.179
  %r1034 = inttoptr i64 %r1032 to ptr
  %r1035 = getelementptr i64, ptr %r1034, i64 6
  %r1036 = load i64, ptr %r1035, align 8
  %r1037 = icmp eq i64 %r1036, %r1028
  br i1 %r1037, label %pic.desc.prefix.hit.181, label %pic.miss.cold.183

pic.desc.prefix.hit.181:                          ; preds = %pic.desc.prefix.token.180
  %r1038 = getelementptr i64, ptr %r978, i64 1
  %r1039 = load i64, ptr %r1038, align 8
  %r1040 = shl i64 %r1039, 3
  %r1041 = add nuw nsw i64 %r958, 16
  %r1042 = add i64 %r1041, %r1040
  %r1043 = inttoptr i64 %r1042 to ptr
  %r1044 = load double, ptr %r1043, align 8
  br label %pic.merge.185

pic.miss.182:                                     ; preds = %pic.hit.inline.189, %pic.prefix.token.175, %pic.prefix.meta.174, %pic.prefix.guard.173
  %r1045 = getelementptr i64, ptr %r978, i64 3
  %r1046 = load i64, ptr %r1045, align 8
  %r1047 = icmp sgt i64 %r1046, 0
  br i1 %r1047, label %pic.ways.190, label %pic.miss.call.184

pic.miss.cold.183:                                ; preds = %pic.desc.prefix.token.180, %pic.desc.prefix.meta.179, %pic.desc.prefix.guard.178, %pic.desc.classify.177, %pget.recv_ok.165
  br label %pic.miss.call.184

pic.miss.call.184:                                ; preds = %pic.way.load.191, %pic.ways.190, %pic.miss.cold.183, %pic.miss.182
  %r1086 = load double, ptr @changing_options_worker_ts_.str.13.handle, align 8
  %r1087 = bitcast double %r1086 to i64
  %r1088 = and i64 %r1087, 281474976710655
  %statepoint_token222 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r958, i64 %r1088, ptr @perry_ic_changing_options_worker_ts__24, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1446, ptr addrspace(1) %.2434, ptr addrspace(1) %.2438, ptr addrspace(1) %.0457, ptr addrspace(1) %.0462, ptr addrspace(1) %rs4gc.s16) ]
  %r1089223 = call double @llvm.experimental.gc.result.f64(token %statepoint_token222)
  %rs4gc.s11.relocated224 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token222, i32 0, i32 0) ; (%.1446, %.1446)
  %rs4gc.s8.relocated225 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token222, i32 1, i32 1) ; (%.2434, %.2434)
  %rs4gc.s9.relocated226 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token222, i32 2, i32 2) ; (%.2438, %.2438)
  %rs4gc.s12.relocated227 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token222, i32 3, i32 3) ; (%.0457, %.0457)
  %rs4gc.s15.relocated228 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token222, i32 4, i32 4) ; (%.0462, %.0462)
  %rs4gc.s16.relocated229 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token222, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pic.merge.185

pic.merge.185:                                    ; preds = %pic.way.live.192, %pic.hit.overflow.188, %pic.miss.call.184, %pic.desc.prefix.hit.181, %pic.prefix.hit.176, %pic.hit.live.172
  %.1468 = phi ptr addrspace(1) [ %rs4gc.s16.relocated237, %pic.hit.overflow.188 ], [ %rs4gc.s16.relocated229, %pic.miss.call.184 ], [ %rs4gc.s16, %pic.way.live.192 ], [ %rs4gc.s16, %pic.hit.live.172 ], [ %rs4gc.s16, %pic.prefix.hit.176 ], [ %rs4gc.s16, %pic.desc.prefix.hit.181 ]
  %.3465 = phi ptr addrspace(1) [ %rs4gc.s15.relocated236, %pic.hit.overflow.188 ], [ %rs4gc.s15.relocated228, %pic.miss.call.184 ], [ %.0462, %pic.way.live.192 ], [ %.0462, %pic.hit.live.172 ], [ %.0462, %pic.prefix.hit.176 ], [ %.0462, %pic.desc.prefix.hit.181 ]
  %.3460 = phi ptr addrspace(1) [ %rs4gc.s12.relocated235, %pic.hit.overflow.188 ], [ %rs4gc.s12.relocated227, %pic.miss.call.184 ], [ %.0457, %pic.way.live.192 ], [ %.0457, %pic.hit.live.172 ], [ %.0457, %pic.prefix.hit.176 ], [ %.0457, %pic.desc.prefix.hit.181 ]
  %.4449 = phi ptr addrspace(1) [ %rs4gc.s11.relocated232, %pic.hit.overflow.188 ], [ %rs4gc.s11.relocated224, %pic.miss.call.184 ], [ %.1446, %pic.way.live.192 ], [ %.1446, %pic.hit.live.172 ], [ %.1446, %pic.prefix.hit.176 ], [ %.1446, %pic.desc.prefix.hit.181 ]
  %.5441 = phi ptr addrspace(1) [ %rs4gc.s9.relocated234, %pic.hit.overflow.188 ], [ %rs4gc.s9.relocated226, %pic.miss.call.184 ], [ %.2438, %pic.way.live.192 ], [ %.2438, %pic.hit.live.172 ], [ %.2438, %pic.prefix.hit.176 ], [ %.2438, %pic.desc.prefix.hit.181 ]
  %.5 = phi ptr addrspace(1) [ %rs4gc.s8.relocated233, %pic.hit.overflow.188 ], [ %rs4gc.s8.relocated225, %pic.miss.call.184 ], [ %.2434, %pic.way.live.192 ], [ %.2434, %pic.hit.live.172 ], [ %.2434, %pic.prefix.hit.176 ], [ %.2434, %pic.desc.prefix.hit.181 ]
  %r1090 = phi double [ %r1006, %pic.hit.live.172 ], [ %r1001231, %pic.hit.overflow.188 ], [ %r1026, %pic.prefix.hit.176 ], [ %r1044, %pic.desc.prefix.hit.181 ], [ %r1083, %pic.way.live.192 ], [ %r1089223, %pic.miss.call.184 ]
  br label %pget.recv_merge.168

pic.recv_hdr.186:                                 ; preds = %pget.recv_ok.165
  %r969 = sub nuw nsw i64 %r958, 8
  %r970 = inttoptr i64 %r969 to ptr
  %r971 = load i8, ptr %r970, align 1
  %r972 = icmp eq i8 %r971, 2
  %r973 = sub nuw nsw i64 %r958, 6
  %r974 = inttoptr i64 %r973 to ptr
  %r975 = load i16, ptr %r974, align 2
  %r976 = and i16 %r975, 2048
  %r977 = icmp eq i16 %r976, 0
  %r978 = load ptr, ptr @perry_ic_changing_options_worker_ts__24, align 8
  %r979 = icmp ne ptr %r978, null
  %r980 = and i1 %r972, %r977
  %r981 = and i1 %r980, %r979
  br i1 %r981, label %pic.token.187, label %pic.desc.classify.177

pic.token.187:                                    ; preds = %pic.recv_hdr.186
  %r983 = add nuw nsw i64 %r958, 4
  %r984 = inttoptr i64 %r983 to ptr
  %r985 = load i32, ptr %r984, align 4
  %r986 = zext i32 %r985 to i64
  %r987 = or i64 %r986, 4611686018427387904
  %r988 = icmp ne i32 %r985, 0
  %r989 = getelementptr i64, ptr %r978, i64 0
  %r990 = load i64, ptr %r989, align 8
  %r991 = icmp eq i64 %r987, %r990
  %r992 = and i1 %r991, %r988
  br i1 %r992, label %pic.hit.171, label %pic.prefix.guard.173

pic.hit.overflow.188:                             ; preds = %pic.hit.171
  %r997 = load double, ptr @changing_options_worker_ts_.str.13.handle, align 8
  %r998 = bitcast double %r997 to i64
  %r999 = and i64 %r998, 281474976710655
  %r1000 = trunc i64 %r994 to i32
  %statepoint_token230 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r958, i64 %r999, i32 %r1000, ptr @perry_ic_changing_options_worker_ts__24, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1446, ptr addrspace(1) %.2434, ptr addrspace(1) %.2438, ptr addrspace(1) %.0457, ptr addrspace(1) %.0462, ptr addrspace(1) %rs4gc.s16) ]
  %r1001231 = call double @llvm.experimental.gc.result.f64(token %statepoint_token230)
  %rs4gc.s11.relocated232 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 0, i32 0) ; (%.1446, %.1446)
  %rs4gc.s8.relocated233 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 1, i32 1) ; (%.2434, %.2434)
  %rs4gc.s9.relocated234 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 2, i32 2) ; (%.2438, %.2438)
  %rs4gc.s12.relocated235 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 3, i32 3) ; (%.0457, %.0457)
  %rs4gc.s15.relocated236 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 4, i32 4) ; (%.0462, %.0462)
  %rs4gc.s16.relocated237 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token230, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pic.merge.185

pic.hit.inline.189:                               ; preds = %pic.hit.171
  %r1002 = shl i64 %r994, 3
  %r1003 = add nuw nsw i64 %r958, 16
  %r1004 = add i64 %r1003, %r1002
  %r1005 = inttoptr i64 %r1004 to ptr
  %r1006 = load double, ptr %r1005, align 8
  %r1007 = bitcast double %r1006 to i64
  %r1008 = icmp eq i64 %r1007, 9222246136947933200
  br i1 %r1008, label %pic.miss.182, label %pic.hit.live.172

pic.ways.190:                                     ; preds = %pic.miss.182
  %r1048 = getelementptr i64, ptr %r978, i64 4
  %r1049 = load i64, ptr %r1048, align 8
  %r1050 = icmp eq i64 %r1049, %r987
  %r1051 = getelementptr i64, ptr %r978, i64 5
  %r1052 = load i64, ptr %r1051, align 8
  %r1053 = select i1 %r1050, i64 %r1052, i64 0
  %r1054 = getelementptr i64, ptr %r978, i64 6
  %r1055 = load i64, ptr %r1054, align 8
  %r1056 = icmp eq i64 %r1055, %r987
  %r1057 = getelementptr i64, ptr %r978, i64 7
  %r1058 = load i64, ptr %r1057, align 8
  %r1059 = select i1 %r1056, i64 %r1058, i64 0
  %r1060 = getelementptr i64, ptr %r978, i64 8
  %r1061 = load i64, ptr %r1060, align 8
  %r1062 = icmp eq i64 %r1061, %r987
  %r1063 = getelementptr i64, ptr %r978, i64 9
  %r1064 = load i64, ptr %r1063, align 8
  %r1065 = select i1 %r1062, i64 %r1064, i64 0
  %r1066 = getelementptr i64, ptr %r978, i64 10
  %r1067 = load i64, ptr %r1066, align 8
  %r1068 = icmp eq i64 %r1067, %r987
  %r1069 = getelementptr i64, ptr %r978, i64 11
  %r1070 = load i64, ptr %r1069, align 8
  %r1071 = select i1 %r1068, i64 %r1070, i64 0
  %r1072 = or i1 %r1050, %r1056
  %r1073 = select i1 %r1050, i64 %r1053, i64 %r1059
  %r1074 = or i1 %r1062, %r1068
  %r1075 = select i1 %r1062, i64 %r1065, i64 %r1071
  %r1076 = or i1 %r1072, %r1074
  %r1077 = select i1 %r1072, i64 %r1073, i64 %r1075
  %r1078 = and i1 %r988, %r1076
  br i1 %r1078, label %pic.way.load.191, label %pic.miss.call.184

pic.way.load.191:                                 ; preds = %pic.ways.190
  %r1079 = shl i64 %r1077, 3
  %r1080 = add nuw nsw i64 %r958, 16
  %r1081 = add i64 %r1080, %r1079
  %r1082 = inttoptr i64 %r1081 to ptr
  %r1083 = load double, ptr %r1082, align 8
  %r1084 = bitcast double %r1083 to i64
  %r1085 = icmp eq i64 %r1084, 9222246136947933200
  br i1 %r1085, label %pic.miss.call.184, label %pic.way.live.192

pic.way.live.192:                                 ; preds = %pic.way.load.191
  br label %pic.merge.185

pget.throw_nullish.193:                           ; preds = %pget.recv_bad.166
  %r1094 = zext i1 %r1092 to i32
  %statepoint_token238 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1094, ptr @changing_options_worker_ts_.str.13.bytes, i64 4, i32 0, i32 0)
  unreachable

pget.recv_undef_return.194:                       ; preds = %pget.recv_bad.166
  %r1095 = load double, ptr @changing_options_worker_ts_.str.13.handle, align 8
  %r1096 = bitcast double %r1095 to i64
  %r1097 = and i64 %r1096, 281474976710655
  %statepoint_token239 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r957, i64 %r1097, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.1446, ptr addrspace(1) %.2434, ptr addrspace(1) %.2438, ptr addrspace(1) %.0457, ptr addrspace(1) %.0462, ptr addrspace(1) %rs4gc.s16) ]
  %r1098240 = call double @llvm.experimental.gc.result.f64(token %statepoint_token239)
  %rs4gc.s11.relocated241 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token239, i32 0, i32 0) ; (%.1446, %.1446)
  %rs4gc.s8.relocated242 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token239, i32 1, i32 1) ; (%.2434, %.2434)
  %rs4gc.s9.relocated243 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token239, i32 2, i32 2) ; (%.2438, %.2438)
  %rs4gc.s12.relocated244 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token239, i32 3, i32 3) ; (%.0457, %.0457)
  %rs4gc.s15.relocated245 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token239, i32 4, i32 4) ; (%.0462, %.0462)
  %rs4gc.s16.relocated246 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token239, i32 5, i32 5) ; (%rs4gc.s16, %rs4gc.s16)
  br label %pget.recv_merge.168

guarded_arith.numeric.195:                        ; preds = %pget.recv_merge.168
  %r1116 = fsub double %r1105, %r1103
  br label %guarded_arith.merge.197

guarded_arith.dynamic.196:                        ; preds = %pget.recv_merge.168
  %statepoint_token247 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_sub, i32 2, i32 0, double %r1105, double %r1103, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.3448, ptr addrspace(1) %.4, ptr addrspace(1) %.4440, ptr addrspace(1) %.2459, ptr addrspace(1) %.2464) ]
  %r1117248 = call double @llvm.experimental.gc.result.f64(token %statepoint_token247)
  %rs4gc.s11.relocated249 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token247, i32 0, i32 0) ; (%.3448, %.3448)
  %rs4gc.s8.relocated250 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token247, i32 1, i32 1) ; (%.4, %.4)
  %rs4gc.s9.relocated251 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token247, i32 2, i32 2) ; (%.4440, %.4440)
  %rs4gc.s12.relocated252 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token247, i32 3, i32 3) ; (%.2459, %.2459)
  %rs4gc.s15.relocated253 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token247, i32 4, i32 4) ; (%.2464, %.2464)
  br label %guarded_arith.merge.197

guarded_arith.merge.197:                          ; preds = %guarded_arith.dynamic.196, %guarded_arith.numeric.195
  %.4466 = phi ptr addrspace(1) [ %.2464, %guarded_arith.numeric.195 ], [ %rs4gc.s15.relocated253, %guarded_arith.dynamic.196 ]
  %.4461 = phi ptr addrspace(1) [ %.2459, %guarded_arith.numeric.195 ], [ %rs4gc.s12.relocated252, %guarded_arith.dynamic.196 ]
  %.5450 = phi ptr addrspace(1) [ %.3448, %guarded_arith.numeric.195 ], [ %rs4gc.s11.relocated249, %guarded_arith.dynamic.196 ]
  %.6442 = phi ptr addrspace(1) [ %.4440, %guarded_arith.numeric.195 ], [ %rs4gc.s9.relocated251, %guarded_arith.dynamic.196 ]
  %.6 = phi ptr addrspace(1) [ %.4, %guarded_arith.numeric.195 ], [ %rs4gc.s8.relocated250, %guarded_arith.dynamic.196 ]
  %r1118 = phi double [ %r1116, %guarded_arith.numeric.195 ], [ %r1117248, %guarded_arith.dynamic.196 ]
  %r1119.rs4i = ptrtoint ptr addrspace(1) %.4466 to i64
  %r1119 = call i64 asm "", "=r,0"(i64 %r1119.rs4i) #8
  %statepoint_token254 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1119, double %r1118, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.5450, ptr addrspace(1) %.6, ptr addrspace(1) %.6442, ptr addrspace(1) %.4461) ]
  %r1120255 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token254)
  %rs4gc.s11.relocated256 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token254, i32 0, i32 0) ; (%.5450, %.5450)
  %rs4gc.s8.relocated257 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token254, i32 1, i32 1) ; (%.6, %.6)
  %rs4gc.s9.relocated258 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token254, i32 2, i32 2) ; (%.6442, %.6442)
  %rs4gc.s12.relocated259 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token254, i32 3, i32 3) ; (%.4461, %.4461)
  %rs4gc.s17 = inttoptr i64 %r1120255 to ptr addrspace(1)
  %r1121.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s17 to i64
  %r1121 = call i64 asm "", "=r,0"(i64 %r1121.rs4i) #8
  %r1122 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1123 = icmp ne i32 %r1122, 0
  br i1 %r1123, label %shadow.root.barrier.198, label %shadow.root.barrier.done.199

shadow.root.barrier.198:                          ; preds = %guarded_arith.merge.197
  call void @js_write_barrier_root_nanbox(i64 %r1121) #8
  br label %shadow.root.barrier.done.199

shadow.root.barrier.done.199:                     ; preds = %shadow.root.barrier.198, %guarded_arith.merge.197
  %r1124.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s12.relocated259 to i64
  %r1124.rs4o = call i64 asm "", "=r,0"(i64 %r1124.rs4i) #8
  %r1124 = bitcast i64 %r1124.rs4o to double
  %r1125 = bitcast double %r1124 to i64
  %r1126 = and i64 %r1125, 281474976710655
  %r1127 = lshr i64 %r1125, 48
  %r1128 = and i64 %r1127, 65533
  %r1129 = icmp eq i64 %r1128, 32765
  br i1 %r1129, label %pget.recv_ok.201, label %pget.recv_other.205

pget.recv_sso.200:                                ; preds = %pget.recv_other.205
  %r1267 = load double, ptr @changing_options_worker_ts_.str.14.handle, align 8
  %r1268 = bitcast double %r1267 to i64
  %r1269 = and i64 %r1268, 281474976710655
  %statepoint_token260 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1125, i64 %r1269, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated256, ptr addrspace(1) %rs4gc.s8.relocated257, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated258) ]
  %r1270261 = call double @llvm.experimental.gc.result.f64(token %statepoint_token260)
  %rs4gc.s11.relocated262 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 0, i32 0) ; (%rs4gc.s11.relocated256, %rs4gc.s11.relocated256)
  %rs4gc.s8.relocated263 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 1, i32 1) ; (%rs4gc.s8.relocated257, %rs4gc.s8.relocated257)
  %rs4gc.s17.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated264 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token260, i32 3, i32 3) ; (%rs4gc.s9.relocated258, %rs4gc.s9.relocated258)
  br label %pget.recv_merge.204

pget.recv_ok.201:                                 ; preds = %shadow.root.barrier.done.199
  %r1136 = icmp ugt i64 %r1126, 1048575
  br i1 %r1136, label %pic.recv_hdr.222, label %pic.miss.cold.219

pget.recv_bad.202:                                ; preds = %pget.check_class_ref.206
  %r1259 = icmp eq i64 %r1125, 9222246136947933185
  %r1260 = icmp eq i64 %r1125, 9222246136947933186
  %r1261 = or i1 %r1259, %r1260
  br i1 %r1261, label %pget.throw_nullish.229, label %pget.recv_undef_return.230

pget.recv_class_ref.203:                          ; preds = %pget.check_class_ref.206
  %r1132 = load double, ptr @changing_options_worker_ts_.str.14.handle, align 8
  %r1133 = bitcast double %r1132 to i64
  %r1134 = and i64 %r1133, 281474976710655
  %statepoint_token265 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 1175166488852561945, i64 %r1125, i64 %r1134, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated256, ptr addrspace(1) %rs4gc.s8.relocated257, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated258) ]
  %r1135266 = call double @llvm.experimental.gc.result.f64(token %statepoint_token265)
  %rs4gc.s11.relocated267 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token265, i32 0, i32 0) ; (%rs4gc.s11.relocated256, %rs4gc.s11.relocated256)
  %rs4gc.s8.relocated268 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token265, i32 1, i32 1) ; (%rs4gc.s8.relocated257, %rs4gc.s8.relocated257)
  %rs4gc.s17.relocated269 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token265, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated270 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token265, i32 3, i32 3) ; (%rs4gc.s9.relocated258, %rs4gc.s9.relocated258)
  br label %pget.recv_merge.204

pget.recv_merge.204:                              ; preds = %pget.recv_undef_return.230, %pic.merge.221, %pget.recv_class_ref.203, %pget.recv_sso.200
  %.0469 = phi ptr addrspace(1) [ %.1470, %pic.merge.221 ], [ %rs4gc.s17.relocated, %pget.recv_sso.200 ], [ %rs4gc.s17.relocated269, %pget.recv_class_ref.203 ], [ %rs4gc.s17.relocated288, %pget.recv_undef_return.230 ]
  %.6451 = phi ptr addrspace(1) [ %.7452, %pic.merge.221 ], [ %rs4gc.s11.relocated262, %pget.recv_sso.200 ], [ %rs4gc.s11.relocated267, %pget.recv_class_ref.203 ], [ %rs4gc.s11.relocated286, %pget.recv_undef_return.230 ]
  %.7443 = phi ptr addrspace(1) [ %.8444, %pic.merge.221 ], [ %rs4gc.s9.relocated264, %pget.recv_sso.200 ], [ %rs4gc.s9.relocated270, %pget.recv_class_ref.203 ], [ %rs4gc.s9.relocated289, %pget.recv_undef_return.230 ]
  %.7 = phi ptr addrspace(1) [ %.8, %pic.merge.221 ], [ %rs4gc.s8.relocated263, %pget.recv_sso.200 ], [ %rs4gc.s8.relocated268, %pget.recv_class_ref.203 ], [ %rs4gc.s8.relocated287, %pget.recv_undef_return.230 ]
  %r1271 = phi double [ %r1258, %pic.merge.221 ], [ %r1266285, %pget.recv_undef_return.230 ], [ %r1270261, %pget.recv_sso.200 ], [ %r1135266, %pget.recv_class_ref.203 ]
  %r1272 = bitcast double %r1271 to i64
  %rs4gc.s18 = inttoptr i64 %r1272 to ptr addrspace(1)
  %r1273.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s18 to i64
  %r1273 = call i64 asm "", "=r,0"(i64 %r1273.rs4i) #8
  %r1274 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1275 = icmp ne i32 %r1274, 0
  br i1 %r1275, label %shadow.root.barrier.231, label %shadow.root.barrier.done.232

pget.recv_other.205:                              ; preds = %shadow.root.barrier.done.199
  %r1130 = icmp eq i64 %r1127, 32761
  br i1 %r1130, label %pget.recv_sso.200, label %pget.check_class_ref.206

pget.check_class_ref.206:                         ; preds = %pget.recv_other.205
  %r1131 = icmp eq i64 %r1127, 32766
  br i1 %r1131, label %pget.recv_class_ref.203, label %pget.recv_bad.202

pic.hit.207:                                      ; preds = %pic.token.223
  %r1161 = getelementptr i64, ptr %r1146, i64 1
  %r1162 = load i64, ptr %r1161, align 8
  %r1163 = and i64 %r1162, 1073741824
  %r1164 = icmp ne i64 %r1163, 0
  br i1 %r1164, label %pic.hit.overflow.224, label %pic.hit.inline.225

pic.hit.live.208:                                 ; preds = %pic.hit.inline.225
  br label %pic.merge.221

pic.prefix.guard.209:                             ; preds = %pic.token.223
  %r1177 = getelementptr i64, ptr %r1146, i64 2
  %r1178 = load i64, ptr %r1177, align 8
  %r1179 = icmp ne i64 %r1178, 0
  br i1 %r1179, label %pic.prefix.meta.210, label %pic.miss.218

pic.prefix.meta.210:                              ; preds = %pic.prefix.guard.209
  %r1180 = add nuw nsw i64 %r1126, 8
  %r1181 = inttoptr i64 %r1180 to ptr
  %r1182 = load i64, ptr %r1181, align 8
  %r1183 = icmp ne i64 %r1182, 0
  br i1 %r1183, label %pic.prefix.token.211, label %pic.miss.218

pic.prefix.token.211:                             ; preds = %pic.prefix.meta.210
  %r1184 = inttoptr i64 %r1182 to ptr
  %r1185 = getelementptr i64, ptr %r1184, i64 6
  %r1186 = load i64, ptr %r1185, align 8
  %r1187 = icmp eq i64 %r1186, %r1178
  br i1 %r1187, label %pic.prefix.hit.212, label %pic.miss.218

pic.prefix.hit.212:                               ; preds = %pic.prefix.token.211
  %r1188 = getelementptr i64, ptr %r1146, i64 1
  %r1189 = load i64, ptr %r1188, align 8
  %r1190 = shl i64 %r1189, 3
  %r1191 = add nuw nsw i64 %r1126, 16
  %r1192 = add i64 %r1191, %r1190
  %r1193 = inttoptr i64 %r1192 to ptr
  %r1194 = load double, ptr %r1193, align 8
  br label %pic.merge.221

pic.desc.classify.213:                            ; preds = %pic.recv_hdr.222
  %r1150 = and i1 %r1140, %r1147
  br i1 %r1150, label %pic.desc.prefix.guard.214, label %pic.miss.cold.219

pic.desc.prefix.guard.214:                        ; preds = %pic.desc.classify.213
  %r1195 = getelementptr i64, ptr %r1146, i64 2
  %r1196 = load i64, ptr %r1195, align 8
  %r1197 = icmp ne i64 %r1196, 0
  br i1 %r1197, label %pic.desc.prefix.meta.215, label %pic.miss.cold.219

pic.desc.prefix.meta.215:                         ; preds = %pic.desc.prefix.guard.214
  %r1198 = add nuw nsw i64 %r1126, 8
  %r1199 = inttoptr i64 %r1198 to ptr
  %r1200 = load i64, ptr %r1199, align 8
  %r1201 = icmp ne i64 %r1200, 0
  br i1 %r1201, label %pic.desc.prefix.token.216, label %pic.miss.cold.219

pic.desc.prefix.token.216:                        ; preds = %pic.desc.prefix.meta.215
  %r1202 = inttoptr i64 %r1200 to ptr
  %r1203 = getelementptr i64, ptr %r1202, i64 6
  %r1204 = load i64, ptr %r1203, align 8
  %r1205 = icmp eq i64 %r1204, %r1196
  br i1 %r1205, label %pic.desc.prefix.hit.217, label %pic.miss.cold.219

pic.desc.prefix.hit.217:                          ; preds = %pic.desc.prefix.token.216
  %r1206 = getelementptr i64, ptr %r1146, i64 1
  %r1207 = load i64, ptr %r1206, align 8
  %r1208 = shl i64 %r1207, 3
  %r1209 = add nuw nsw i64 %r1126, 16
  %r1210 = add i64 %r1209, %r1208
  %r1211 = inttoptr i64 %r1210 to ptr
  %r1212 = load double, ptr %r1211, align 8
  br label %pic.merge.221

pic.miss.218:                                     ; preds = %pic.hit.inline.225, %pic.prefix.token.211, %pic.prefix.meta.210, %pic.prefix.guard.209
  %r1213 = getelementptr i64, ptr %r1146, i64 3
  %r1214 = load i64, ptr %r1213, align 8
  %r1215 = icmp sgt i64 %r1214, 0
  br i1 %r1215, label %pic.ways.226, label %pic.miss.call.220

pic.miss.cold.219:                                ; preds = %pic.desc.prefix.token.216, %pic.desc.prefix.meta.215, %pic.desc.prefix.guard.214, %pic.desc.classify.213, %pget.recv_ok.201
  br label %pic.miss.call.220

pic.miss.call.220:                                ; preds = %pic.way.load.227, %pic.ways.226, %pic.miss.cold.219, %pic.miss.218
  %r1254 = load double, ptr @changing_options_worker_ts_.str.14.handle, align 8
  %r1255 = bitcast double %r1254 to i64
  %r1256 = and i64 %r1255, 281474976710655
  %statepoint_token271 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1126, i64 %r1256, ptr @perry_ic_changing_options_worker_ts__26, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated256, ptr addrspace(1) %rs4gc.s8.relocated257, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated258) ]
  %r1257272 = call double @llvm.experimental.gc.result.f64(token %statepoint_token271)
  %rs4gc.s11.relocated273 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token271, i32 0, i32 0) ; (%rs4gc.s11.relocated256, %rs4gc.s11.relocated256)
  %rs4gc.s8.relocated274 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token271, i32 1, i32 1) ; (%rs4gc.s8.relocated257, %rs4gc.s8.relocated257)
  %rs4gc.s17.relocated275 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token271, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated276 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token271, i32 3, i32 3) ; (%rs4gc.s9.relocated258, %rs4gc.s9.relocated258)
  br label %pic.merge.221

pic.merge.221:                                    ; preds = %pic.way.live.228, %pic.hit.overflow.224, %pic.miss.call.220, %pic.desc.prefix.hit.217, %pic.prefix.hit.212, %pic.hit.live.208
  %.1470 = phi ptr addrspace(1) [ %rs4gc.s17.relocated281, %pic.hit.overflow.224 ], [ %rs4gc.s17.relocated275, %pic.miss.call.220 ], [ %rs4gc.s17, %pic.way.live.228 ], [ %rs4gc.s17, %pic.hit.live.208 ], [ %rs4gc.s17, %pic.prefix.hit.212 ], [ %rs4gc.s17, %pic.desc.prefix.hit.217 ]
  %.7452 = phi ptr addrspace(1) [ %rs4gc.s11.relocated279, %pic.hit.overflow.224 ], [ %rs4gc.s11.relocated273, %pic.miss.call.220 ], [ %rs4gc.s11.relocated256, %pic.way.live.228 ], [ %rs4gc.s11.relocated256, %pic.hit.live.208 ], [ %rs4gc.s11.relocated256, %pic.prefix.hit.212 ], [ %rs4gc.s11.relocated256, %pic.desc.prefix.hit.217 ]
  %.8444 = phi ptr addrspace(1) [ %rs4gc.s9.relocated282, %pic.hit.overflow.224 ], [ %rs4gc.s9.relocated276, %pic.miss.call.220 ], [ %rs4gc.s9.relocated258, %pic.way.live.228 ], [ %rs4gc.s9.relocated258, %pic.hit.live.208 ], [ %rs4gc.s9.relocated258, %pic.prefix.hit.212 ], [ %rs4gc.s9.relocated258, %pic.desc.prefix.hit.217 ]
  %.8 = phi ptr addrspace(1) [ %rs4gc.s8.relocated280, %pic.hit.overflow.224 ], [ %rs4gc.s8.relocated274, %pic.miss.call.220 ], [ %rs4gc.s8.relocated257, %pic.way.live.228 ], [ %rs4gc.s8.relocated257, %pic.hit.live.208 ], [ %rs4gc.s8.relocated257, %pic.prefix.hit.212 ], [ %rs4gc.s8.relocated257, %pic.desc.prefix.hit.217 ]
  %r1258 = phi double [ %r1174, %pic.hit.live.208 ], [ %r1169278, %pic.hit.overflow.224 ], [ %r1194, %pic.prefix.hit.212 ], [ %r1212, %pic.desc.prefix.hit.217 ], [ %r1251, %pic.way.live.228 ], [ %r1257272, %pic.miss.call.220 ]
  br label %pget.recv_merge.204

pic.recv_hdr.222:                                 ; preds = %pget.recv_ok.201
  %r1137 = sub nuw nsw i64 %r1126, 8
  %r1138 = inttoptr i64 %r1137 to ptr
  %r1139 = load i8, ptr %r1138, align 1
  %r1140 = icmp eq i8 %r1139, 2
  %r1141 = sub nuw nsw i64 %r1126, 6
  %r1142 = inttoptr i64 %r1141 to ptr
  %r1143 = load i16, ptr %r1142, align 2
  %r1144 = and i16 %r1143, 2048
  %r1145 = icmp eq i16 %r1144, 0
  %r1146 = load ptr, ptr @perry_ic_changing_options_worker_ts__26, align 8
  %r1147 = icmp ne ptr %r1146, null
  %r1148 = and i1 %r1140, %r1145
  %r1149 = and i1 %r1148, %r1147
  br i1 %r1149, label %pic.token.223, label %pic.desc.classify.213

pic.token.223:                                    ; preds = %pic.recv_hdr.222
  %r1151 = add nuw nsw i64 %r1126, 4
  %r1152 = inttoptr i64 %r1151 to ptr
  %r1153 = load i32, ptr %r1152, align 4
  %r1154 = zext i32 %r1153 to i64
  %r1155 = or i64 %r1154, 4611686018427387904
  %r1156 = icmp ne i32 %r1153, 0
  %r1157 = getelementptr i64, ptr %r1146, i64 0
  %r1158 = load i64, ptr %r1157, align 8
  %r1159 = icmp eq i64 %r1155, %r1158
  %r1160 = and i1 %r1159, %r1156
  br i1 %r1160, label %pic.hit.207, label %pic.prefix.guard.209

pic.hit.overflow.224:                             ; preds = %pic.hit.207
  %r1165 = load double, ptr @changing_options_worker_ts_.str.14.handle, align 8
  %r1166 = bitcast double %r1165 to i64
  %r1167 = and i64 %r1166, 281474976710655
  %r1168 = trunc i64 %r1162 to i32
  %statepoint_token277 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1126, i64 %r1167, i32 %r1168, ptr @perry_ic_changing_options_worker_ts__26, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated256, ptr addrspace(1) %rs4gc.s8.relocated257, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated258) ]
  %r1169278 = call double @llvm.experimental.gc.result.f64(token %statepoint_token277)
  %rs4gc.s11.relocated279 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 0, i32 0) ; (%rs4gc.s11.relocated256, %rs4gc.s11.relocated256)
  %rs4gc.s8.relocated280 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 1, i32 1) ; (%rs4gc.s8.relocated257, %rs4gc.s8.relocated257)
  %rs4gc.s17.relocated281 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated282 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token277, i32 3, i32 3) ; (%rs4gc.s9.relocated258, %rs4gc.s9.relocated258)
  br label %pic.merge.221

pic.hit.inline.225:                               ; preds = %pic.hit.207
  %r1170 = shl i64 %r1162, 3
  %r1171 = add nuw nsw i64 %r1126, 16
  %r1172 = add i64 %r1171, %r1170
  %r1173 = inttoptr i64 %r1172 to ptr
  %r1174 = load double, ptr %r1173, align 8
  %r1175 = bitcast double %r1174 to i64
  %r1176 = icmp eq i64 %r1175, 9222246136947933200
  br i1 %r1176, label %pic.miss.218, label %pic.hit.live.208

pic.ways.226:                                     ; preds = %pic.miss.218
  %r1216 = getelementptr i64, ptr %r1146, i64 4
  %r1217 = load i64, ptr %r1216, align 8
  %r1218 = icmp eq i64 %r1217, %r1155
  %r1219 = getelementptr i64, ptr %r1146, i64 5
  %r1220 = load i64, ptr %r1219, align 8
  %r1221 = select i1 %r1218, i64 %r1220, i64 0
  %r1222 = getelementptr i64, ptr %r1146, i64 6
  %r1223 = load i64, ptr %r1222, align 8
  %r1224 = icmp eq i64 %r1223, %r1155
  %r1225 = getelementptr i64, ptr %r1146, i64 7
  %r1226 = load i64, ptr %r1225, align 8
  %r1227 = select i1 %r1224, i64 %r1226, i64 0
  %r1228 = getelementptr i64, ptr %r1146, i64 8
  %r1229 = load i64, ptr %r1228, align 8
  %r1230 = icmp eq i64 %r1229, %r1155
  %r1231 = getelementptr i64, ptr %r1146, i64 9
  %r1232 = load i64, ptr %r1231, align 8
  %r1233 = select i1 %r1230, i64 %r1232, i64 0
  %r1234 = getelementptr i64, ptr %r1146, i64 10
  %r1235 = load i64, ptr %r1234, align 8
  %r1236 = icmp eq i64 %r1235, %r1155
  %r1237 = getelementptr i64, ptr %r1146, i64 11
  %r1238 = load i64, ptr %r1237, align 8
  %r1239 = select i1 %r1236, i64 %r1238, i64 0
  %r1240 = or i1 %r1218, %r1224
  %r1241 = select i1 %r1218, i64 %r1221, i64 %r1227
  %r1242 = or i1 %r1230, %r1236
  %r1243 = select i1 %r1230, i64 %r1233, i64 %r1239
  %r1244 = or i1 %r1240, %r1242
  %r1245 = select i1 %r1240, i64 %r1241, i64 %r1243
  %r1246 = and i1 %r1156, %r1244
  br i1 %r1246, label %pic.way.load.227, label %pic.miss.call.220

pic.way.load.227:                                 ; preds = %pic.ways.226
  %r1247 = shl i64 %r1245, 3
  %r1248 = add nuw nsw i64 %r1126, 16
  %r1249 = add i64 %r1248, %r1247
  %r1250 = inttoptr i64 %r1249 to ptr
  %r1251 = load double, ptr %r1250, align 8
  %r1252 = bitcast double %r1251 to i64
  %r1253 = icmp eq i64 %r1252, 9222246136947933200
  br i1 %r1253, label %pic.miss.call.220, label %pic.way.live.228

pic.way.live.228:                                 ; preds = %pic.way.load.227
  br label %pic.merge.221

pget.throw_nullish.229:                           ; preds = %pget.recv_bad.202
  %r1262 = zext i1 %r1260 to i32
  %statepoint_token283 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1262, ptr @changing_options_worker_ts_.str.14.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.230:                       ; preds = %pget.recv_bad.202
  %r1263 = load double, ptr @changing_options_worker_ts_.str.14.handle, align 8
  %r1264 = bitcast double %r1263 to i64
  %r1265 = and i64 %r1264, 281474976710655
  %statepoint_token284 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1125, i64 %r1265, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated256, ptr addrspace(1) %rs4gc.s8.relocated257, ptr addrspace(1) %rs4gc.s17, ptr addrspace(1) %rs4gc.s9.relocated258) ]
  %r1266285 = call double @llvm.experimental.gc.result.f64(token %statepoint_token284)
  %rs4gc.s11.relocated286 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 0, i32 0) ; (%rs4gc.s11.relocated256, %rs4gc.s11.relocated256)
  %rs4gc.s8.relocated287 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 1, i32 1) ; (%rs4gc.s8.relocated257, %rs4gc.s8.relocated257)
  %rs4gc.s17.relocated288 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 2, i32 2) ; (%rs4gc.s17, %rs4gc.s17)
  %rs4gc.s9.relocated289 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token284, i32 3, i32 3) ; (%rs4gc.s9.relocated258, %rs4gc.s9.relocated258)
  br label %pget.recv_merge.204

shadow.root.barrier.231:                          ; preds = %pget.recv_merge.204
  call void @js_write_barrier_root_nanbox(i64 %r1273) #8
  br label %shadow.root.barrier.done.232

shadow.root.barrier.done.232:                     ; preds = %shadow.root.barrier.231, %pget.recv_merge.204
  %r1276.rs4i = ptrtoint ptr addrspace(1) %.7443 to i64
  %r1276.rs4o = call i64 asm "", "=r,0"(i64 %r1276.rs4i) #8
  %r1276 = bitcast i64 %r1276.rs4o to double
  %r1277 = bitcast double %r1276 to i64
  %r1278 = and i64 %r1277, 281474976710655
  %r1279 = lshr i64 %r1277, 48
  %r1280 = and i64 %r1279, 65533
  %r1281 = icmp eq i64 %r1280, 32765
  br i1 %r1281, label %pget.recv_ok.234, label %pget.recv_other.238

pget.recv_sso.233:                                ; preds = %pget.recv_other.238
  %r1419 = load double, ptr @changing_options_worker_ts_.str.14.handle, align 8
  %r1420 = bitcast double %r1419 to i64
  %r1421 = and i64 %r1420, 281474976710655
  %statepoint_token290 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1277, i64 %r1421, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6451, ptr addrspace(1) %.7, ptr addrspace(1) %.0469, ptr addrspace(1) %rs4gc.s18) ]
  %r1422291 = call double @llvm.experimental.gc.result.f64(token %statepoint_token290)
  %rs4gc.s11.relocated292 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token290, i32 0, i32 0) ; (%.6451, %.6451)
  %rs4gc.s8.relocated293 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token290, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated294 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token290, i32 2, i32 2) ; (%.0469, %.0469)
  %rs4gc.s18.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token290, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pget.recv_merge.237

pget.recv_ok.234:                                 ; preds = %shadow.root.barrier.done.232
  %r1288 = icmp ugt i64 %r1278, 1048575
  br i1 %r1288, label %pic.recv_hdr.255, label %pic.miss.cold.252

pget.recv_bad.235:                                ; preds = %pget.check_class_ref.239
  %r1411 = icmp eq i64 %r1277, 9222246136947933185
  %r1412 = icmp eq i64 %r1277, 9222246136947933186
  %r1413 = or i1 %r1411, %r1412
  br i1 %r1413, label %pget.throw_nullish.262, label %pget.recv_undef_return.263

pget.recv_class_ref.236:                          ; preds = %pget.check_class_ref.239
  %r1284 = load double, ptr @changing_options_worker_ts_.str.14.handle, align 8
  %r1285 = bitcast double %r1284 to i64
  %r1286 = and i64 %r1285, 281474976710655
  %statepoint_token295 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 1175166488852561947, i64 %r1277, i64 %r1286, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6451, ptr addrspace(1) %.7, ptr addrspace(1) %.0469, ptr addrspace(1) %rs4gc.s18) ]
  %r1287296 = call double @llvm.experimental.gc.result.f64(token %statepoint_token295)
  %rs4gc.s11.relocated297 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token295, i32 0, i32 0) ; (%.6451, %.6451)
  %rs4gc.s8.relocated298 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token295, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated299 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token295, i32 2, i32 2) ; (%.0469, %.0469)
  %rs4gc.s18.relocated300 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token295, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pget.recv_merge.237

pget.recv_merge.237:                              ; preds = %pget.recv_undef_return.263, %pic.merge.254, %pget.recv_class_ref.236, %pget.recv_sso.233
  %.0474 = phi ptr addrspace(1) [ %.1475, %pic.merge.254 ], [ %rs4gc.s18.relocated, %pget.recv_sso.233 ], [ %rs4gc.s18.relocated300, %pget.recv_class_ref.236 ], [ %rs4gc.s18.relocated319, %pget.recv_undef_return.263 ]
  %.2471 = phi ptr addrspace(1) [ %.3472, %pic.merge.254 ], [ %rs4gc.s17.relocated294, %pget.recv_sso.233 ], [ %rs4gc.s17.relocated299, %pget.recv_class_ref.236 ], [ %rs4gc.s17.relocated318, %pget.recv_undef_return.263 ]
  %.8453 = phi ptr addrspace(1) [ %.9454, %pic.merge.254 ], [ %rs4gc.s11.relocated292, %pget.recv_sso.233 ], [ %rs4gc.s11.relocated297, %pget.recv_class_ref.236 ], [ %rs4gc.s11.relocated316, %pget.recv_undef_return.263 ]
  %.9 = phi ptr addrspace(1) [ %.10, %pic.merge.254 ], [ %rs4gc.s8.relocated293, %pget.recv_sso.233 ], [ %rs4gc.s8.relocated298, %pget.recv_class_ref.236 ], [ %rs4gc.s8.relocated317, %pget.recv_undef_return.263 ]
  %r1423 = phi double [ %r1410, %pic.merge.254 ], [ %r1418315, %pget.recv_undef_return.263 ], [ %r1422291, %pget.recv_sso.233 ], [ %r1287296, %pget.recv_class_ref.236 ]
  %r1424.rs4i = ptrtoint ptr addrspace(1) %.0474 to i64
  %r1424 = call i64 asm "", "=r,0"(i64 %r1424.rs4i) #8
  %r1425 = bitcast i64 %r1424 to double
  %r1426 = and i64 %r1424, -281474976710656
  %r1427 = icmp ult i64 %r1426, 9221401712017801216
  %r1428 = icmp ugt i64 %r1426, 9223090561878065152
  %r1429 = or i1 %r1427, %r1428
  %r1430 = bitcast double %r1423 to i64
  %r1431 = and i64 %r1430, -281474976710656
  %r1432 = icmp ult i64 %r1431, 9221401712017801216
  %r1433 = icmp ugt i64 %r1431, 9223090561878065152
  %r1434 = or i1 %r1432, %r1433
  %r1435 = and i1 %r1429, %r1434
  br i1 %r1435, label %guarded_arith.numeric.264, label %guarded_arith.dynamic.265

pget.recv_other.238:                              ; preds = %shadow.root.barrier.done.232
  %r1282 = icmp eq i64 %r1279, 32761
  br i1 %r1282, label %pget.recv_sso.233, label %pget.check_class_ref.239

pget.check_class_ref.239:                         ; preds = %pget.recv_other.238
  %r1283 = icmp eq i64 %r1279, 32766
  br i1 %r1283, label %pget.recv_class_ref.236, label %pget.recv_bad.235

pic.hit.240:                                      ; preds = %pic.token.256
  %r1313 = getelementptr i64, ptr %r1298, i64 1
  %r1314 = load i64, ptr %r1313, align 8
  %r1315 = and i64 %r1314, 1073741824
  %r1316 = icmp ne i64 %r1315, 0
  br i1 %r1316, label %pic.hit.overflow.257, label %pic.hit.inline.258

pic.hit.live.241:                                 ; preds = %pic.hit.inline.258
  br label %pic.merge.254

pic.prefix.guard.242:                             ; preds = %pic.token.256
  %r1329 = getelementptr i64, ptr %r1298, i64 2
  %r1330 = load i64, ptr %r1329, align 8
  %r1331 = icmp ne i64 %r1330, 0
  br i1 %r1331, label %pic.prefix.meta.243, label %pic.miss.251

pic.prefix.meta.243:                              ; preds = %pic.prefix.guard.242
  %r1332 = add nuw nsw i64 %r1278, 8
  %r1333 = inttoptr i64 %r1332 to ptr
  %r1334 = load i64, ptr %r1333, align 8
  %r1335 = icmp ne i64 %r1334, 0
  br i1 %r1335, label %pic.prefix.token.244, label %pic.miss.251

pic.prefix.token.244:                             ; preds = %pic.prefix.meta.243
  %r1336 = inttoptr i64 %r1334 to ptr
  %r1337 = getelementptr i64, ptr %r1336, i64 6
  %r1338 = load i64, ptr %r1337, align 8
  %r1339 = icmp eq i64 %r1338, %r1330
  br i1 %r1339, label %pic.prefix.hit.245, label %pic.miss.251

pic.prefix.hit.245:                               ; preds = %pic.prefix.token.244
  %r1340 = getelementptr i64, ptr %r1298, i64 1
  %r1341 = load i64, ptr %r1340, align 8
  %r1342 = shl i64 %r1341, 3
  %r1343 = add nuw nsw i64 %r1278, 16
  %r1344 = add i64 %r1343, %r1342
  %r1345 = inttoptr i64 %r1344 to ptr
  %r1346 = load double, ptr %r1345, align 8
  br label %pic.merge.254

pic.desc.classify.246:                            ; preds = %pic.recv_hdr.255
  %r1302 = and i1 %r1292, %r1299
  br i1 %r1302, label %pic.desc.prefix.guard.247, label %pic.miss.cold.252

pic.desc.prefix.guard.247:                        ; preds = %pic.desc.classify.246
  %r1347 = getelementptr i64, ptr %r1298, i64 2
  %r1348 = load i64, ptr %r1347, align 8
  %r1349 = icmp ne i64 %r1348, 0
  br i1 %r1349, label %pic.desc.prefix.meta.248, label %pic.miss.cold.252

pic.desc.prefix.meta.248:                         ; preds = %pic.desc.prefix.guard.247
  %r1350 = add nuw nsw i64 %r1278, 8
  %r1351 = inttoptr i64 %r1350 to ptr
  %r1352 = load i64, ptr %r1351, align 8
  %r1353 = icmp ne i64 %r1352, 0
  br i1 %r1353, label %pic.desc.prefix.token.249, label %pic.miss.cold.252

pic.desc.prefix.token.249:                        ; preds = %pic.desc.prefix.meta.248
  %r1354 = inttoptr i64 %r1352 to ptr
  %r1355 = getelementptr i64, ptr %r1354, i64 6
  %r1356 = load i64, ptr %r1355, align 8
  %r1357 = icmp eq i64 %r1356, %r1348
  br i1 %r1357, label %pic.desc.prefix.hit.250, label %pic.miss.cold.252

pic.desc.prefix.hit.250:                          ; preds = %pic.desc.prefix.token.249
  %r1358 = getelementptr i64, ptr %r1298, i64 1
  %r1359 = load i64, ptr %r1358, align 8
  %r1360 = shl i64 %r1359, 3
  %r1361 = add nuw nsw i64 %r1278, 16
  %r1362 = add i64 %r1361, %r1360
  %r1363 = inttoptr i64 %r1362 to ptr
  %r1364 = load double, ptr %r1363, align 8
  br label %pic.merge.254

pic.miss.251:                                     ; preds = %pic.hit.inline.258, %pic.prefix.token.244, %pic.prefix.meta.243, %pic.prefix.guard.242
  %r1365 = getelementptr i64, ptr %r1298, i64 3
  %r1366 = load i64, ptr %r1365, align 8
  %r1367 = icmp sgt i64 %r1366, 0
  br i1 %r1367, label %pic.ways.259, label %pic.miss.call.253

pic.miss.cold.252:                                ; preds = %pic.desc.prefix.token.249, %pic.desc.prefix.meta.248, %pic.desc.prefix.guard.247, %pic.desc.classify.246, %pget.recv_ok.234
  br label %pic.miss.call.253

pic.miss.call.253:                                ; preds = %pic.way.load.260, %pic.ways.259, %pic.miss.cold.252, %pic.miss.251
  %r1406 = load double, ptr @changing_options_worker_ts_.str.14.handle, align 8
  %r1407 = bitcast double %r1406 to i64
  %r1408 = and i64 %r1407, 281474976710655
  %statepoint_token301 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1278, i64 %r1408, ptr @perry_ic_changing_options_worker_ts__28, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6451, ptr addrspace(1) %.7, ptr addrspace(1) %.0469, ptr addrspace(1) %rs4gc.s18) ]
  %r1409302 = call double @llvm.experimental.gc.result.f64(token %statepoint_token301)
  %rs4gc.s11.relocated303 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token301, i32 0, i32 0) ; (%.6451, %.6451)
  %rs4gc.s8.relocated304 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token301, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated305 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token301, i32 2, i32 2) ; (%.0469, %.0469)
  %rs4gc.s18.relocated306 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token301, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pic.merge.254

pic.merge.254:                                    ; preds = %pic.way.live.261, %pic.hit.overflow.257, %pic.miss.call.253, %pic.desc.prefix.hit.250, %pic.prefix.hit.245, %pic.hit.live.241
  %.1475 = phi ptr addrspace(1) [ %rs4gc.s18.relocated312, %pic.hit.overflow.257 ], [ %rs4gc.s18.relocated306, %pic.miss.call.253 ], [ %rs4gc.s18, %pic.way.live.261 ], [ %rs4gc.s18, %pic.hit.live.241 ], [ %rs4gc.s18, %pic.prefix.hit.245 ], [ %rs4gc.s18, %pic.desc.prefix.hit.250 ]
  %.3472 = phi ptr addrspace(1) [ %rs4gc.s17.relocated311, %pic.hit.overflow.257 ], [ %rs4gc.s17.relocated305, %pic.miss.call.253 ], [ %.0469, %pic.way.live.261 ], [ %.0469, %pic.hit.live.241 ], [ %.0469, %pic.prefix.hit.245 ], [ %.0469, %pic.desc.prefix.hit.250 ]
  %.9454 = phi ptr addrspace(1) [ %rs4gc.s11.relocated309, %pic.hit.overflow.257 ], [ %rs4gc.s11.relocated303, %pic.miss.call.253 ], [ %.6451, %pic.way.live.261 ], [ %.6451, %pic.hit.live.241 ], [ %.6451, %pic.prefix.hit.245 ], [ %.6451, %pic.desc.prefix.hit.250 ]
  %.10 = phi ptr addrspace(1) [ %rs4gc.s8.relocated310, %pic.hit.overflow.257 ], [ %rs4gc.s8.relocated304, %pic.miss.call.253 ], [ %.7, %pic.way.live.261 ], [ %.7, %pic.hit.live.241 ], [ %.7, %pic.prefix.hit.245 ], [ %.7, %pic.desc.prefix.hit.250 ]
  %r1410 = phi double [ %r1326, %pic.hit.live.241 ], [ %r1321308, %pic.hit.overflow.257 ], [ %r1346, %pic.prefix.hit.245 ], [ %r1364, %pic.desc.prefix.hit.250 ], [ %r1403, %pic.way.live.261 ], [ %r1409302, %pic.miss.call.253 ]
  br label %pget.recv_merge.237

pic.recv_hdr.255:                                 ; preds = %pget.recv_ok.234
  %r1289 = sub nuw nsw i64 %r1278, 8
  %r1290 = inttoptr i64 %r1289 to ptr
  %r1291 = load i8, ptr %r1290, align 1
  %r1292 = icmp eq i8 %r1291, 2
  %r1293 = sub nuw nsw i64 %r1278, 6
  %r1294 = inttoptr i64 %r1293 to ptr
  %r1295 = load i16, ptr %r1294, align 2
  %r1296 = and i16 %r1295, 2048
  %r1297 = icmp eq i16 %r1296, 0
  %r1298 = load ptr, ptr @perry_ic_changing_options_worker_ts__28, align 8
  %r1299 = icmp ne ptr %r1298, null
  %r1300 = and i1 %r1292, %r1297
  %r1301 = and i1 %r1300, %r1299
  br i1 %r1301, label %pic.token.256, label %pic.desc.classify.246

pic.token.256:                                    ; preds = %pic.recv_hdr.255
  %r1303 = add nuw nsw i64 %r1278, 4
  %r1304 = inttoptr i64 %r1303 to ptr
  %r1305 = load i32, ptr %r1304, align 4
  %r1306 = zext i32 %r1305 to i64
  %r1307 = or i64 %r1306, 4611686018427387904
  %r1308 = icmp ne i32 %r1305, 0
  %r1309 = getelementptr i64, ptr %r1298, i64 0
  %r1310 = load i64, ptr %r1309, align 8
  %r1311 = icmp eq i64 %r1307, %r1310
  %r1312 = and i1 %r1311, %r1308
  br i1 %r1312, label %pic.hit.240, label %pic.prefix.guard.242

pic.hit.overflow.257:                             ; preds = %pic.hit.240
  %r1317 = load double, ptr @changing_options_worker_ts_.str.14.handle, align 8
  %r1318 = bitcast double %r1317 to i64
  %r1319 = and i64 %r1318, 281474976710655
  %r1320 = trunc i64 %r1314 to i32
  %statepoint_token307 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1278, i64 %r1319, i32 %r1320, ptr @perry_ic_changing_options_worker_ts__28, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6451, ptr addrspace(1) %.7, ptr addrspace(1) %.0469, ptr addrspace(1) %rs4gc.s18) ]
  %r1321308 = call double @llvm.experimental.gc.result.f64(token %statepoint_token307)
  %rs4gc.s11.relocated309 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token307, i32 0, i32 0) ; (%.6451, %.6451)
  %rs4gc.s8.relocated310 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token307, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated311 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token307, i32 2, i32 2) ; (%.0469, %.0469)
  %rs4gc.s18.relocated312 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token307, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pic.merge.254

pic.hit.inline.258:                               ; preds = %pic.hit.240
  %r1322 = shl i64 %r1314, 3
  %r1323 = add nuw nsw i64 %r1278, 16
  %r1324 = add i64 %r1323, %r1322
  %r1325 = inttoptr i64 %r1324 to ptr
  %r1326 = load double, ptr %r1325, align 8
  %r1327 = bitcast double %r1326 to i64
  %r1328 = icmp eq i64 %r1327, 9222246136947933200
  br i1 %r1328, label %pic.miss.251, label %pic.hit.live.241

pic.ways.259:                                     ; preds = %pic.miss.251
  %r1368 = getelementptr i64, ptr %r1298, i64 4
  %r1369 = load i64, ptr %r1368, align 8
  %r1370 = icmp eq i64 %r1369, %r1307
  %r1371 = getelementptr i64, ptr %r1298, i64 5
  %r1372 = load i64, ptr %r1371, align 8
  %r1373 = select i1 %r1370, i64 %r1372, i64 0
  %r1374 = getelementptr i64, ptr %r1298, i64 6
  %r1375 = load i64, ptr %r1374, align 8
  %r1376 = icmp eq i64 %r1375, %r1307
  %r1377 = getelementptr i64, ptr %r1298, i64 7
  %r1378 = load i64, ptr %r1377, align 8
  %r1379 = select i1 %r1376, i64 %r1378, i64 0
  %r1380 = getelementptr i64, ptr %r1298, i64 8
  %r1381 = load i64, ptr %r1380, align 8
  %r1382 = icmp eq i64 %r1381, %r1307
  %r1383 = getelementptr i64, ptr %r1298, i64 9
  %r1384 = load i64, ptr %r1383, align 8
  %r1385 = select i1 %r1382, i64 %r1384, i64 0
  %r1386 = getelementptr i64, ptr %r1298, i64 10
  %r1387 = load i64, ptr %r1386, align 8
  %r1388 = icmp eq i64 %r1387, %r1307
  %r1389 = getelementptr i64, ptr %r1298, i64 11
  %r1390 = load i64, ptr %r1389, align 8
  %r1391 = select i1 %r1388, i64 %r1390, i64 0
  %r1392 = or i1 %r1370, %r1376
  %r1393 = select i1 %r1370, i64 %r1373, i64 %r1379
  %r1394 = or i1 %r1382, %r1388
  %r1395 = select i1 %r1382, i64 %r1385, i64 %r1391
  %r1396 = or i1 %r1392, %r1394
  %r1397 = select i1 %r1392, i64 %r1393, i64 %r1395
  %r1398 = and i1 %r1308, %r1396
  br i1 %r1398, label %pic.way.load.260, label %pic.miss.call.253

pic.way.load.260:                                 ; preds = %pic.ways.259
  %r1399 = shl i64 %r1397, 3
  %r1400 = add nuw nsw i64 %r1278, 16
  %r1401 = add i64 %r1400, %r1399
  %r1402 = inttoptr i64 %r1401 to ptr
  %r1403 = load double, ptr %r1402, align 8
  %r1404 = bitcast double %r1403 to i64
  %r1405 = icmp eq i64 %r1404, 9222246136947933200
  br i1 %r1405, label %pic.miss.call.253, label %pic.way.live.261

pic.way.live.261:                                 ; preds = %pic.way.load.260
  br label %pic.merge.254

pget.throw_nullish.262:                           ; preds = %pget.recv_bad.235
  %r1414 = zext i1 %r1412 to i32
  %statepoint_token313 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1414, ptr @changing_options_worker_ts_.str.14.bytes, i64 6, i32 0, i32 0)
  unreachable

pget.recv_undef_return.263:                       ; preds = %pget.recv_bad.235
  %r1415 = load double, ptr @changing_options_worker_ts_.str.14.handle, align 8
  %r1416 = bitcast double %r1415 to i64
  %r1417 = and i64 %r1416, 281474976710655
  %statepoint_token314 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1277, i64 %r1417, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.6451, ptr addrspace(1) %.7, ptr addrspace(1) %.0469, ptr addrspace(1) %rs4gc.s18) ]
  %r1418315 = call double @llvm.experimental.gc.result.f64(token %statepoint_token314)
  %rs4gc.s11.relocated316 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 0, i32 0) ; (%.6451, %.6451)
  %rs4gc.s8.relocated317 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 1, i32 1) ; (%.7, %.7)
  %rs4gc.s17.relocated318 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 2, i32 2) ; (%.0469, %.0469)
  %rs4gc.s18.relocated319 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token314, i32 3, i32 3) ; (%rs4gc.s18, %rs4gc.s18)
  br label %pget.recv_merge.237

guarded_arith.numeric.264:                        ; preds = %pget.recv_merge.237
  %r1436 = fsub double %r1425, %r1423
  br label %guarded_arith.merge.266

guarded_arith.dynamic.265:                        ; preds = %pget.recv_merge.237
  %statepoint_token320 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (double, double)) @js_dynamic_sub, i32 2, i32 0, double %r1425, double %r1423, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.8453, ptr addrspace(1) %.9, ptr addrspace(1) %.2471) ]
  %r1437321 = call double @llvm.experimental.gc.result.f64(token %statepoint_token320)
  %rs4gc.s11.relocated322 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token320, i32 0, i32 0) ; (%.8453, %.8453)
  %rs4gc.s8.relocated323 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token320, i32 1, i32 1) ; (%.9, %.9)
  %rs4gc.s17.relocated324 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token320, i32 2, i32 2) ; (%.2471, %.2471)
  br label %guarded_arith.merge.266

guarded_arith.merge.266:                          ; preds = %guarded_arith.dynamic.265, %guarded_arith.numeric.264
  %.4473 = phi ptr addrspace(1) [ %.2471, %guarded_arith.numeric.264 ], [ %rs4gc.s17.relocated324, %guarded_arith.dynamic.265 ]
  %.10455 = phi ptr addrspace(1) [ %.8453, %guarded_arith.numeric.264 ], [ %rs4gc.s11.relocated322, %guarded_arith.dynamic.265 ]
  %.11 = phi ptr addrspace(1) [ %.9, %guarded_arith.numeric.264 ], [ %rs4gc.s8.relocated323, %guarded_arith.dynamic.265 ]
  %r1438 = phi double [ %r1436, %guarded_arith.numeric.264 ], [ %r1437321, %guarded_arith.dynamic.265 ]
  %r1439.rs4i = ptrtoint ptr addrspace(1) %.4473 to i64
  %r1439 = call i64 asm "", "=r,0"(i64 %r1439.rs4i) #8
  %statepoint_token325 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1439, double %r1438, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.10455, ptr addrspace(1) %.11) ]
  %r1440326 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token325)
  %rs4gc.s11.relocated327 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token325, i32 0, i32 0) ; (%.10455, %.10455)
  %rs4gc.s8.relocated328 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token325, i32 1, i32 1) ; (%.11, %.11)
  %rs4gc.s19 = inttoptr i64 %r1440326 to ptr addrspace(1)
  %r1441.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r1441 = call i64 asm "", "=r,0"(i64 %r1441.rs4i) #8
  %r1442 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1443 = icmp ne i32 %r1442, 0
  br i1 %r1443, label %shadow.root.barrier.267, label %shadow.root.barrier.done.268

shadow.root.barrier.267:                          ; preds = %guarded_arith.merge.266
  call void @js_write_barrier_root_nanbox(i64 %r1441) #8
  br label %shadow.root.barrier.done.268

shadow.root.barrier.done.268:                     ; preds = %shadow.root.barrier.267, %guarded_arith.merge.266
  %r1444.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s8.relocated328 to i64
  %r1444.rs4o = call i64 asm "", "=r,0"(i64 %r1444.rs4i) #8
  %r1444 = bitcast i64 %r1444.rs4o to double
  %r1445.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s19 to i64
  %r1445 = call i64 asm "", "=r,0"(i64 %r1445.rs4i) #8
  %statepoint_token329 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1445, double %r1444, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated327) ]
  %r1446330 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token329)
  %rs4gc.s11.relocated331 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token329, i32 0, i32 0) ; (%rs4gc.s11.relocated327, %rs4gc.s11.relocated327)
  %rs4gc.s20 = inttoptr i64 %r1446330 to ptr addrspace(1)
  %r1447.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s20 to i64
  %r1447 = call i64 asm "", "=r,0"(i64 %r1447.rs4i) #8
  %r1448 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1449 = icmp ne i32 %r1448, 0
  br i1 %r1449, label %shadow.root.barrier.269, label %shadow.root.barrier.done.270

shadow.root.barrier.269:                          ; preds = %shadow.root.barrier.done.268
  call void @js_write_barrier_root_nanbox(i64 %r1447) #8
  br label %shadow.root.barrier.done.270

shadow.root.barrier.done.270:                     ; preds = %shadow.root.barrier.269, %shadow.root.barrier.done.268
  %statepoint_token332 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double ()) @js_process_memory_usage, i32 0, i32 0, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated331, ptr addrspace(1) %rs4gc.s20) ]
  %r1450333 = call double @llvm.experimental.gc.result.f64(token %statepoint_token332)
  %rs4gc.s11.relocated334 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token332, i32 0, i32 0) ; (%rs4gc.s11.relocated331, %rs4gc.s11.relocated331)
  %rs4gc.s20.relocated = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token332, i32 1, i32 1) ; (%rs4gc.s20, %rs4gc.s20)
  %r1451 = bitcast double %r1450333 to i64
  %r1452 = and i64 %r1451, 281474976710655
  %r1453 = lshr i64 %r1451, 48
  %r1454 = and i64 %r1453, 65533
  %r1455 = icmp eq i64 %r1454, 32765
  br i1 %r1455, label %pget.recv_ok.272, label %pget.recv_other.276

pget.recv_sso.271:                                ; preds = %pget.recv_other.276
  %r1593 = load double, ptr @changing_options_worker_ts_.str.11.handle, align 8
  %r1594 = bitcast double %r1593 to i64
  %r1595 = and i64 %r1594, 281474976710655
  %statepoint_token335 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1451, i64 %r1595, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated334, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1596336 = call double @llvm.experimental.gc.result.f64(token %statepoint_token335)
  %rs4gc.s11.relocated337 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token335, i32 0, i32 0) ; (%rs4gc.s11.relocated334, %rs4gc.s11.relocated334)
  %rs4gc.s20.relocated338 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token335, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pget.recv_merge.275

pget.recv_ok.272:                                 ; preds = %shadow.root.barrier.done.270
  %r1462 = icmp ugt i64 %r1452, 1048575
  br i1 %r1462, label %pic.recv_hdr.293, label %pic.miss.cold.290

pget.recv_bad.273:                                ; preds = %pget.check_class_ref.277
  %r1585 = icmp eq i64 %r1451, 9222246136947933185
  %r1586 = icmp eq i64 %r1451, 9222246136947933186
  %r1587 = or i1 %r1585, %r1586
  br i1 %r1587, label %pget.throw_nullish.300, label %pget.recv_undef_return.301

pget.recv_class_ref.274:                          ; preds = %pget.check_class_ref.277
  %r1458 = load double, ptr @changing_options_worker_ts_.str.11.handle, align 8
  %r1459 = bitcast double %r1458 to i64
  %r1460 = and i64 %r1459, 281474976710655
  %statepoint_token339 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i64)) @js_typed_feedback_object_get_field_by_name_f64, i32 3, i32 0, i64 1175166488852561949, i64 %r1451, i64 %r1460, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated334, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1461340 = call double @llvm.experimental.gc.result.f64(token %statepoint_token339)
  %rs4gc.s11.relocated341 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token339, i32 0, i32 0) ; (%rs4gc.s11.relocated334, %rs4gc.s11.relocated334)
  %rs4gc.s20.relocated342 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token339, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pget.recv_merge.275

pget.recv_merge.275:                              ; preds = %pget.recv_undef_return.301, %pic.merge.292, %pget.recv_class_ref.274, %pget.recv_sso.271
  %.0476 = phi ptr addrspace(1) [ %.1477, %pic.merge.292 ], [ %rs4gc.s20.relocated338, %pget.recv_sso.271 ], [ %rs4gc.s20.relocated342, %pget.recv_class_ref.274 ], [ %rs4gc.s20.relocated358, %pget.recv_undef_return.301 ]
  %.11456 = phi ptr addrspace(1) [ %.12, %pic.merge.292 ], [ %rs4gc.s11.relocated337, %pget.recv_sso.271 ], [ %rs4gc.s11.relocated341, %pget.recv_class_ref.274 ], [ %rs4gc.s11.relocated357, %pget.recv_undef_return.301 ]
  %r1597 = phi double [ %r1584, %pic.merge.292 ], [ %r1592356, %pget.recv_undef_return.301 ], [ %r1596336, %pget.recv_sso.271 ], [ %r1461340, %pget.recv_class_ref.274 ]
  %r1598.rs4i = ptrtoint ptr addrspace(1) %.0476 to i64
  %r1598 = call i64 asm "", "=r,0"(i64 %r1598.rs4i) #8
  %statepoint_token343 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1598, double %r1597, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %.11456) ]
  %r1599344 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token343)
  %rs4gc.s11.relocated345 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token343, i32 0, i32 0) ; (%.11456, %.11456)
  %rs4gc.s21 = inttoptr i64 %r1599344 to ptr addrspace(1)
  %r1600.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r1600 = call i64 asm "", "=r,0"(i64 %r1600.rs4i) #8
  %r1601 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1602 = icmp ne i32 %r1601, 0
  br i1 %r1602, label %shadow.root.barrier.302, label %shadow.root.barrier.done.303

pget.recv_other.276:                              ; preds = %shadow.root.barrier.done.270
  %r1456 = icmp eq i64 %r1453, 32761
  br i1 %r1456, label %pget.recv_sso.271, label %pget.check_class_ref.277

pget.check_class_ref.277:                         ; preds = %pget.recv_other.276
  %r1457 = icmp eq i64 %r1453, 32766
  br i1 %r1457, label %pget.recv_class_ref.274, label %pget.recv_bad.273

pic.hit.278:                                      ; preds = %pic.token.294
  %r1487 = getelementptr i64, ptr %r1472, i64 1
  %r1488 = load i64, ptr %r1487, align 8
  %r1489 = and i64 %r1488, 1073741824
  %r1490 = icmp ne i64 %r1489, 0
  br i1 %r1490, label %pic.hit.overflow.295, label %pic.hit.inline.296

pic.hit.live.279:                                 ; preds = %pic.hit.inline.296
  br label %pic.merge.292

pic.prefix.guard.280:                             ; preds = %pic.token.294
  %r1503 = getelementptr i64, ptr %r1472, i64 2
  %r1504 = load i64, ptr %r1503, align 8
  %r1505 = icmp ne i64 %r1504, 0
  br i1 %r1505, label %pic.prefix.meta.281, label %pic.miss.289

pic.prefix.meta.281:                              ; preds = %pic.prefix.guard.280
  %r1506 = add nuw nsw i64 %r1452, 8
  %r1507 = inttoptr i64 %r1506 to ptr
  %r1508 = load i64, ptr %r1507, align 8
  %r1509 = icmp ne i64 %r1508, 0
  br i1 %r1509, label %pic.prefix.token.282, label %pic.miss.289

pic.prefix.token.282:                             ; preds = %pic.prefix.meta.281
  %r1510 = inttoptr i64 %r1508 to ptr
  %r1511 = getelementptr i64, ptr %r1510, i64 6
  %r1512 = load i64, ptr %r1511, align 8
  %r1513 = icmp eq i64 %r1512, %r1504
  br i1 %r1513, label %pic.prefix.hit.283, label %pic.miss.289

pic.prefix.hit.283:                               ; preds = %pic.prefix.token.282
  %r1514 = getelementptr i64, ptr %r1472, i64 1
  %r1515 = load i64, ptr %r1514, align 8
  %r1516 = shl i64 %r1515, 3
  %r1517 = add nuw nsw i64 %r1452, 16
  %r1518 = add i64 %r1517, %r1516
  %r1519 = inttoptr i64 %r1518 to ptr
  %r1520 = load double, ptr %r1519, align 8
  br label %pic.merge.292

pic.desc.classify.284:                            ; preds = %pic.recv_hdr.293
  %r1476 = and i1 %r1466, %r1473
  br i1 %r1476, label %pic.desc.prefix.guard.285, label %pic.miss.cold.290

pic.desc.prefix.guard.285:                        ; preds = %pic.desc.classify.284
  %r1521 = getelementptr i64, ptr %r1472, i64 2
  %r1522 = load i64, ptr %r1521, align 8
  %r1523 = icmp ne i64 %r1522, 0
  br i1 %r1523, label %pic.desc.prefix.meta.286, label %pic.miss.cold.290

pic.desc.prefix.meta.286:                         ; preds = %pic.desc.prefix.guard.285
  %r1524 = add nuw nsw i64 %r1452, 8
  %r1525 = inttoptr i64 %r1524 to ptr
  %r1526 = load i64, ptr %r1525, align 8
  %r1527 = icmp ne i64 %r1526, 0
  br i1 %r1527, label %pic.desc.prefix.token.287, label %pic.miss.cold.290

pic.desc.prefix.token.287:                        ; preds = %pic.desc.prefix.meta.286
  %r1528 = inttoptr i64 %r1526 to ptr
  %r1529 = getelementptr i64, ptr %r1528, i64 6
  %r1530 = load i64, ptr %r1529, align 8
  %r1531 = icmp eq i64 %r1530, %r1522
  br i1 %r1531, label %pic.desc.prefix.hit.288, label %pic.miss.cold.290

pic.desc.prefix.hit.288:                          ; preds = %pic.desc.prefix.token.287
  %r1532 = getelementptr i64, ptr %r1472, i64 1
  %r1533 = load i64, ptr %r1532, align 8
  %r1534 = shl i64 %r1533, 3
  %r1535 = add nuw nsw i64 %r1452, 16
  %r1536 = add i64 %r1535, %r1534
  %r1537 = inttoptr i64 %r1536 to ptr
  %r1538 = load double, ptr %r1537, align 8
  br label %pic.merge.292

pic.miss.289:                                     ; preds = %pic.hit.inline.296, %pic.prefix.token.282, %pic.prefix.meta.281, %pic.prefix.guard.280
  %r1539 = getelementptr i64, ptr %r1472, i64 3
  %r1540 = load i64, ptr %r1539, align 8
  %r1541 = icmp sgt i64 %r1540, 0
  br i1 %r1541, label %pic.ways.297, label %pic.miss.call.291

pic.miss.cold.290:                                ; preds = %pic.desc.prefix.token.287, %pic.desc.prefix.meta.286, %pic.desc.prefix.guard.285, %pic.desc.classify.284, %pget.recv_ok.272
  br label %pic.miss.call.291

pic.miss.call.291:                                ; preds = %pic.way.load.298, %pic.ways.297, %pic.miss.cold.290, %pic.miss.289
  %r1580 = load double, ptr @changing_options_worker_ts_.str.11.handle, align 8
  %r1581 = bitcast double %r1580 to i64
  %r1582 = and i64 %r1581, 281474976710655
  %statepoint_token346 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, ptr)) @js_object_get_field_ic_miss, i32 3, i32 0, i64 %r1452, i64 %r1582, ptr @perry_ic_changing_options_worker_ts__30, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated334, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1583347 = call double @llvm.experimental.gc.result.f64(token %statepoint_token346)
  %rs4gc.s11.relocated348 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token346, i32 0, i32 0) ; (%rs4gc.s11.relocated334, %rs4gc.s11.relocated334)
  %rs4gc.s20.relocated349 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token346, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pic.merge.292

pic.merge.292:                                    ; preds = %pic.way.live.299, %pic.hit.overflow.295, %pic.miss.call.291, %pic.desc.prefix.hit.288, %pic.prefix.hit.283, %pic.hit.live.279
  %.1477 = phi ptr addrspace(1) [ %rs4gc.s20.relocated353, %pic.hit.overflow.295 ], [ %rs4gc.s20.relocated349, %pic.miss.call.291 ], [ %rs4gc.s20.relocated, %pic.way.live.299 ], [ %rs4gc.s20.relocated, %pic.hit.live.279 ], [ %rs4gc.s20.relocated, %pic.prefix.hit.283 ], [ %rs4gc.s20.relocated, %pic.desc.prefix.hit.288 ]
  %.12 = phi ptr addrspace(1) [ %rs4gc.s11.relocated352, %pic.hit.overflow.295 ], [ %rs4gc.s11.relocated348, %pic.miss.call.291 ], [ %rs4gc.s11.relocated334, %pic.way.live.299 ], [ %rs4gc.s11.relocated334, %pic.hit.live.279 ], [ %rs4gc.s11.relocated334, %pic.prefix.hit.283 ], [ %rs4gc.s11.relocated334, %pic.desc.prefix.hit.288 ]
  %r1584 = phi double [ %r1500, %pic.hit.live.279 ], [ %r1495351, %pic.hit.overflow.295 ], [ %r1520, %pic.prefix.hit.283 ], [ %r1538, %pic.desc.prefix.hit.288 ], [ %r1577, %pic.way.live.299 ], [ %r1583347, %pic.miss.call.291 ]
  br label %pget.recv_merge.275

pic.recv_hdr.293:                                 ; preds = %pget.recv_ok.272
  %r1463 = sub nuw nsw i64 %r1452, 8
  %r1464 = inttoptr i64 %r1463 to ptr
  %r1465 = load i8, ptr %r1464, align 1
  %r1466 = icmp eq i8 %r1465, 2
  %r1467 = sub nuw nsw i64 %r1452, 6
  %r1468 = inttoptr i64 %r1467 to ptr
  %r1469 = load i16, ptr %r1468, align 2
  %r1470 = and i16 %r1469, 2048
  %r1471 = icmp eq i16 %r1470, 0
  %r1472 = load ptr, ptr @perry_ic_changing_options_worker_ts__30, align 8
  %r1473 = icmp ne ptr %r1472, null
  %r1474 = and i1 %r1466, %r1471
  %r1475 = and i1 %r1474, %r1473
  br i1 %r1475, label %pic.token.294, label %pic.desc.classify.284

pic.token.294:                                    ; preds = %pic.recv_hdr.293
  %r1477 = add nuw nsw i64 %r1452, 4
  %r1478 = inttoptr i64 %r1477 to ptr
  %r1479 = load i32, ptr %r1478, align 4
  %r1480 = zext i32 %r1479 to i64
  %r1481 = or i64 %r1480, 4611686018427387904
  %r1482 = icmp ne i32 %r1479, 0
  %r1483 = getelementptr i64, ptr %r1472, i64 0
  %r1484 = load i64, ptr %r1483, align 8
  %r1485 = icmp eq i64 %r1481, %r1484
  %r1486 = and i1 %r1485, %r1482
  br i1 %r1486, label %pic.hit.278, label %pic.prefix.guard.280

pic.hit.overflow.295:                             ; preds = %pic.hit.278
  %r1491 = load double, ptr @changing_options_worker_ts_.str.11.handle, align 8
  %r1492 = bitcast double %r1491 to i64
  %r1493 = and i64 %r1492, 281474976710655
  %r1494 = trunc i64 %r1488 to i32
  %statepoint_token350 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64, i32, ptr)) @js_object_get_field_ic_overflow_load, i32 4, i32 0, i64 %r1452, i64 %r1493, i32 %r1494, ptr @perry_ic_changing_options_worker_ts__30, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated334, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1495351 = call double @llvm.experimental.gc.result.f64(token %statepoint_token350)
  %rs4gc.s11.relocated352 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 0, i32 0) ; (%rs4gc.s11.relocated334, %rs4gc.s11.relocated334)
  %rs4gc.s20.relocated353 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token350, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pic.merge.292

pic.hit.inline.296:                               ; preds = %pic.hit.278
  %r1496 = shl i64 %r1488, 3
  %r1497 = add nuw nsw i64 %r1452, 16
  %r1498 = add i64 %r1497, %r1496
  %r1499 = inttoptr i64 %r1498 to ptr
  %r1500 = load double, ptr %r1499, align 8
  %r1501 = bitcast double %r1500 to i64
  %r1502 = icmp eq i64 %r1501, 9222246136947933200
  br i1 %r1502, label %pic.miss.289, label %pic.hit.live.279

pic.ways.297:                                     ; preds = %pic.miss.289
  %r1542 = getelementptr i64, ptr %r1472, i64 4
  %r1543 = load i64, ptr %r1542, align 8
  %r1544 = icmp eq i64 %r1543, %r1481
  %r1545 = getelementptr i64, ptr %r1472, i64 5
  %r1546 = load i64, ptr %r1545, align 8
  %r1547 = select i1 %r1544, i64 %r1546, i64 0
  %r1548 = getelementptr i64, ptr %r1472, i64 6
  %r1549 = load i64, ptr %r1548, align 8
  %r1550 = icmp eq i64 %r1549, %r1481
  %r1551 = getelementptr i64, ptr %r1472, i64 7
  %r1552 = load i64, ptr %r1551, align 8
  %r1553 = select i1 %r1550, i64 %r1552, i64 0
  %r1554 = getelementptr i64, ptr %r1472, i64 8
  %r1555 = load i64, ptr %r1554, align 8
  %r1556 = icmp eq i64 %r1555, %r1481
  %r1557 = getelementptr i64, ptr %r1472, i64 9
  %r1558 = load i64, ptr %r1557, align 8
  %r1559 = select i1 %r1556, i64 %r1558, i64 0
  %r1560 = getelementptr i64, ptr %r1472, i64 10
  %r1561 = load i64, ptr %r1560, align 8
  %r1562 = icmp eq i64 %r1561, %r1481
  %r1563 = getelementptr i64, ptr %r1472, i64 11
  %r1564 = load i64, ptr %r1563, align 8
  %r1565 = select i1 %r1562, i64 %r1564, i64 0
  %r1566 = or i1 %r1544, %r1550
  %r1567 = select i1 %r1544, i64 %r1547, i64 %r1553
  %r1568 = or i1 %r1556, %r1562
  %r1569 = select i1 %r1556, i64 %r1559, i64 %r1565
  %r1570 = or i1 %r1566, %r1568
  %r1571 = select i1 %r1566, i64 %r1567, i64 %r1569
  %r1572 = and i1 %r1482, %r1570
  br i1 %r1572, label %pic.way.load.298, label %pic.miss.call.291

pic.way.load.298:                                 ; preds = %pic.ways.297
  %r1573 = shl i64 %r1571, 3
  %r1574 = add nuw nsw i64 %r1452, 16
  %r1575 = add i64 %r1574, %r1573
  %r1576 = inttoptr i64 %r1575 to ptr
  %r1577 = load double, ptr %r1576, align 8
  %r1578 = bitcast double %r1577 to i64
  %r1579 = icmp eq i64 %r1578, 9222246136947933200
  br i1 %r1579, label %pic.miss.call.291, label %pic.way.live.299

pic.way.live.299:                                 ; preds = %pic.way.load.298
  br label %pic.merge.292

pget.throw_nullish.300:                           ; preds = %pget.recv_bad.273
  %r1588 = zext i1 %r1586 to i32
  %statepoint_token354 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i32, ptr, i64)) @js_throw_type_error_property_access, i32 3, i32 0, i32 %r1588, ptr @changing_options_worker_ts_.str.11.bytes, i64 3, i32 0, i32 0)
  unreachable

pget.recv_undef_return.301:                       ; preds = %pget.recv_bad.273
  %r1589 = load double, ptr @changing_options_worker_ts_.str.11.handle, align 8
  %r1590 = bitcast double %r1589 to i64
  %r1591 = and i64 %r1590, 281474976710655
  %statepoint_token355 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, i64)) @js_object_get_field_by_name_f64, i32 2, i32 0, i64 %r1451, i64 %r1591, i32 0, i32 0) [ "gc-live"(ptr addrspace(1) %rs4gc.s11.relocated334, ptr addrspace(1) %rs4gc.s20.relocated) ]
  %r1592356 = call double @llvm.experimental.gc.result.f64(token %statepoint_token355)
  %rs4gc.s11.relocated357 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token355, i32 0, i32 0) ; (%rs4gc.s11.relocated334, %rs4gc.s11.relocated334)
  %rs4gc.s20.relocated358 = call coldcc ptr addrspace(1) @llvm.experimental.gc.relocate.p1(token %statepoint_token355, i32 1, i32 1) ; (%rs4gc.s20.relocated, %rs4gc.s20.relocated)
  br label %pget.recv_merge.275

shadow.root.barrier.302:                          ; preds = %pget.recv_merge.275
  call void @js_write_barrier_root_nanbox(i64 %r1600) #8
  br label %shadow.root.barrier.done.303

shadow.root.barrier.done.303:                     ; preds = %shadow.root.barrier.302, %pget.recv_merge.275
  %r1603.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s11.relocated345 to i64
  %r1603.rs4o = call i64 asm "", "=r,0"(i64 %r1603.rs4i) #8
  %r1603 = bitcast i64 %r1603.rs4o to double
  %r1604.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s21 to i64
  %r1604 = call i64 asm "", "=r,0"(i64 %r1604.rs4i) #8
  %statepoint_token359 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1604, double %r1603, i32 0, i32 0)
  %r1605360 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token359)
  %rs4gc.s22 = inttoptr i64 %r1605360 to ptr addrspace(1)
  %r1606.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r1606 = call i64 asm "", "=r,0"(i64 %r1606.rs4i) #8
  %r1607 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1608 = icmp ne i32 %r1607, 0
  br i1 %r1608, label %shadow.root.barrier.304, label %shadow.root.barrier.done.305

shadow.root.barrier.304:                          ; preds = %shadow.root.barrier.done.303
  call void @js_write_barrier_root_nanbox(i64 %r1606) #8
  br label %shadow.root.barrier.done.305

shadow.root.barrier.done.305:                     ; preds = %shadow.root.barrier.304, %shadow.root.barrier.done.303
  %r1609.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s22 to i64
  %r1609 = call i64 asm "", "=r,0"(i64 %r1609.rs4i) #8
  %statepoint_token361 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1609, double 0.000000e+00, i32 0, i32 0)
  %r1610362 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token361)
  %rs4gc.s23 = inttoptr i64 %r1610362 to ptr addrspace(1)
  %r1611.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r1611 = call i64 asm "", "=r,0"(i64 %r1611.rs4i) #8
  %r1612 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1613 = icmp ne i32 %r1612, 0
  br i1 %r1613, label %shadow.root.barrier.306, label %shadow.root.barrier.done.307

shadow.root.barrier.306:                          ; preds = %shadow.root.barrier.done.305
  call void @js_write_barrier_root_nanbox(i64 %r1611) #8
  br label %shadow.root.barrier.done.307

shadow.root.barrier.done.307:                     ; preds = %shadow.root.barrier.306, %shadow.root.barrier.done.305
  %r1614.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s23 to i64
  %r1614 = call i64 asm "", "=r,0"(i64 %r1614.rs4i) #8
  %statepoint_token363 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1614, i32 0, i32 0)
  %statepoint_token364 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 ()) @js_process_argv, i32 0, i32 0, i32 0, i32 0)
  %r1615365 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token364)
  %r1616 = or i64 %r1615365, 9222527611924643840
  %r1617 = bitcast i64 %r1616 to double
  %r1618 = and i64 %r1616, 281474976710655
  %r1619 = lshr i64 %r1616, 48
  %r1620 = icmp eq i64 %r1619, 32765
  %r1621 = icmp ugt i64 %r1618, 1048575
  %r1622 = and i1 %r1620, %r1621
  br i1 %r1622, label %arr.guard.deref.312, label %arr.fallback.309

arr.fast.308:                                     ; preds = %arr.guard.range.314
  %r1681 = add i64 %r1637, 56
  %r1682 = inttoptr i64 %r1681 to ptr
  %r1683 = load double, ptr %r1682, align 8
  %r1684 = bitcast double %r1683 to i64
  %r1685 = icmp eq i64 %r1684, 9222246136947933200
  %r1687 = select i1 %r1685, double 0x7FFC000000000001, double %r1683
  br label %arr.merge.311

arr.fallback.309:                                 ; preds = %arr.guard.live.313, %arr.guard.deref.312, %shadow.root.barrier.done.307
  %statepoint_token366 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(double (i64, double, double)) @js_typed_feedback_array_index_get_fallback_boxed, i32 3, i32 0, i64 1175166488852561951, double %r1617, double 6.000000e+00, i32 0, i32 0)
  %r1677367 = call double @llvm.experimental.gc.result.f64(token %statepoint_token366)
  br label %arr.merge.311

arr.guard.oob.310:                                ; preds = %arr.guard.range.314
  br label %arr.merge.311

arr.merge.311:                                    ; preds = %arr.guard.oob.310, %arr.fallback.309, %arr.fast.308
  %r1688 = phi double [ %r1687, %arr.fast.308 ], [ %r1677367, %arr.fallback.309 ], [ 0x7FFC000000000001, %arr.guard.oob.310 ]
  %r1689 = load double, ptr @changing_options_worker_ts_.str.15.handle, align 8
  %r1690 = bitcast double %r1688 to i64
  %r1691 = bitcast double %r1689 to i64
  %r1692 = icmp eq i64 %r1690, %r1691
  br i1 %r1692, label %streqlit.true.320, label %streqlit.tag.315

arr.guard.deref.312:                              ; preds = %shadow.root.barrier.done.307
  %r1623 = bitcast double %r1617 to i64
  %r1624 = and i64 %r1623, 281474976710655
  %r1625 = sub nsw i64 %r1624, 8
  %r1626 = inttoptr i64 %r1625 to ptr
  %r1627 = load i8, ptr %r1626, align 1
  %r1628 = icmp eq i8 %r1627, 1
  %r1629 = sub nsw i64 %r1624, 7
  %r1630 = inttoptr i64 %r1629 to ptr
  %r1631 = load i8, ptr %r1630, align 1
  %r1632 = and i8 %r1631, -128
  %r1633 = icmp ne i8 %r1632, 0
  %r1634 = inttoptr i64 %r1624 to ptr
  %r1635 = load i64, ptr %r1634, align 8
  %r1636 = and i1 %r1628, %r1633
  %r1637 = select i1 %r1636, i64 %r1635, i64 %r1624
  %r1638 = lshr i64 %r1637, 48
  %r1639 = icmp eq i64 %r1638, 0
  %r1640 = icmp ugt i64 %r1637, 1048575
  %r1641 = and i1 %r1639, %r1640
  br i1 %r1641, label %arr.guard.live.313, label %arr.fallback.309

arr.guard.live.313:                               ; preds = %arr.guard.deref.312
  %r1642 = sub nuw i64 %r1637, 8
  %r1643 = inttoptr i64 %r1642 to ptr
  %r1644 = load i8, ptr %r1643, align 1
  %r1645 = icmp eq i8 %r1644, 1
  %r1646 = sub nuw i64 %r1637, 7
  %r1647 = inttoptr i64 %r1646 to ptr
  %r1648 = load i8, ptr %r1647, align 1
  %r1649 = and i8 %r1648, -128
  %r1650 = icmp eq i8 %r1649, 0
  %r1651 = sub nuw i64 %r1637, 6
  %r1652 = inttoptr i64 %r1651 to ptr
  %r1653 = load i16, ptr %r1652, align 2
  %r1654 = and i16 %r1653, 1024
  %r1655 = icmp eq i16 %r1654, 0
  %r1656 = load volatile i8, ptr @PERRY_ARRAY_INDEX_FAST_PATH_INVALIDATED, align 1
  %r1657 = icmp eq i8 %r1656, 0
  %r1658 = inttoptr i64 %r1637 to ptr
  %r1659 = load i32, ptr %r1658, align 4
  %r1660 = getelementptr i8, ptr %r1658, i64 4
  %r1661 = load i32, ptr %r1660, align 4
  %r1665 = icmp ule i32 %r1659, 16000000
  %r1666 = icmp ule i32 %r1661, 16000000
  %r1667 = icmp ule i32 %r1659, %r1661
  %r1668 = and i1 %r1645, %r1650
  %r1669 = and i1 %r1668, %r1655
  %r1670 = and i1 %r1669, %r1657
  %r1672 = and i1 %r1670, %r1665
  %r1673 = and i1 %r1672, %r1666
  %r1674 = and i1 %r1673, %r1667
  br i1 %r1674, label %arr.guard.range.314, label %arr.fallback.309

arr.guard.range.314:                              ; preds = %arr.guard.live.313
  %r1664 = icmp ult i32 6, %r1659
  br i1 %r1664, label %arr.fast.308, label %arr.guard.oob.310

streqlit.tag.315:                                 ; preds = %arr.merge.311
  %r1693 = lshr i64 %r1690, 48
  %r1694 = icmp eq i64 %r1693, 32767
  %r1695 = and i64 %r1690, 281474976710655
  %r1696 = icmp ugt i64 %r1695, 4095
  %r1697 = and i1 %r1694, %r1696
  br i1 %r1697, label %streqlit.len.316, label %streqlit.false.321

streqlit.len.316:                                 ; preds = %streqlit.tag.315
  %r1698 = inttoptr i64 %r1695 to ptr
  %r1699 = getelementptr inbounds nuw i8, ptr %r1698, i64 4
  %r1700 = load i32, ptr %r1699, align 4
  %r1701 = icmp eq i32 %r1700, 6
  br i1 %r1701, label %streqlit.b0.317, label %streqlit.false.321

streqlit.b0.317:                                  ; preds = %streqlit.len.316
  %r1702 = getelementptr inbounds nuw i8, ptr %r1698, i64 20
  %r1703 = load i8, ptr %r1702, align 1
  %r1704 = icmp eq i8 %r1703, 118
  br i1 %r1704, label %streqlit.bl.318, label %streqlit.false.321

streqlit.bl.318:                                  ; preds = %streqlit.b0.317
  %r1705 = getelementptr inbounds nuw i8, ptr %r1698, i64 25
  %r1706 = load i8, ptr %r1705, align 1
  %r1707 = icmp eq i8 %r1706, 121
  br i1 %r1707, label %streqlit.slow.319, label %streqlit.false.321

streqlit.slow.319:                                ; preds = %streqlit.bl.318
  %r1708 = and i64 %r1691, 281474976710655
  %statepoint_token368 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 (i64, i64)) @js_string_equals, i32 2, i32 0, i64 %r1695, i64 %r1708, i32 0, i32 0)
  %r1709369 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token368)
  %r1710 = icmp ne i32 %r1709369, 0
  br label %streqlit.merge.322

streqlit.true.320:                                ; preds = %arr.merge.311
  br label %streqlit.merge.322

streqlit.false.321:                               ; preds = %streqlit.bl.318, %streqlit.b0.317, %streqlit.len.316, %streqlit.tag.315
  br label %streqlit.merge.322

streqlit.merge.322:                               ; preds = %streqlit.false.321, %streqlit.true.320, %streqlit.slow.319
  %r1711 = phi i1 [ true, %streqlit.true.320 ], [ false, %streqlit.false.321 ], [ %r1710, %streqlit.slow.319 ]
  %r1712 = select i1 %r1711, i64 9222246136947933188, i64 9222246136947933187
  %r1713 = bitcast i64 %r1712 to double
  %r1714 = icmp eq i64 %r1712, 9222246136947933188
  br i1 %r1714, label %if.then.323, label %if.else.324

if.then.323:                                      ; preds = %streqlit.merge.322
  %statepoint_token370 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 2, i32 0, i32 0)
  %r1715371 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token370)
  %rs4gc.s24 = inttoptr i64 %r1715371 to ptr addrspace(1)
  %r1716.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r1716 = call i64 asm "", "=r,0"(i64 %r1716.rs4i) #8
  %r1717 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1718 = icmp ne i32 %r1717, 0
  br i1 %r1718, label %shadow.root.barrier.326, label %shadow.root.barrier.done.327

if.else.324:                                      ; preds = %streqlit.merge.322
  br label %if.merge.325

if.merge.325:                                     ; preds = %shadow.root.barrier.done.331, %if.else.324
  %statepoint_token372 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i32)) @js_array_alloc, i32 1, i32 0, i32 3, i32 0, i32 0)
  %r1732373 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token372)
  %rs4gc.s25 = inttoptr i64 %r1732373 to ptr addrspace(1)
  %r1733.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r1733 = call i64 asm "", "=r,0"(i64 %r1733.rs4i) #8
  %r1734 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1735 = icmp ne i32 %r1734, 0
  br i1 %r1735, label %shadow.root.barrier.332, label %shadow.root.barrier.done.333

shadow.root.barrier.326:                          ; preds = %if.then.323
  call void @js_write_barrier_root_nanbox(i64 %r1716) #8
  br label %shadow.root.barrier.done.327

shadow.root.barrier.done.327:                     ; preds = %shadow.root.barrier.326, %if.then.323
  %r1719 = load double, ptr @changing_options_worker_ts_.str.16.handle, align 8
  %r1720.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s24 to i64
  %r1720 = call i64 asm "", "=r,0"(i64 %r1720.rs4i) #8
  %statepoint_token374 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1720, double %r1719, i32 0, i32 0)
  %r1721375 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token374)
  %rs4gc.s26 = inttoptr i64 %r1721375 to ptr addrspace(1)
  %r1722.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r1722 = call i64 asm "", "=r,0"(i64 %r1722.rs4i) #8
  %r1723 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1724 = icmp ne i32 %r1723, 0
  br i1 %r1724, label %shadow.root.barrier.328, label %shadow.root.barrier.done.329

shadow.root.barrier.328:                          ; preds = %shadow.root.barrier.done.327
  call void @js_write_barrier_root_nanbox(i64 %r1722) #8
  br label %shadow.root.barrier.done.329

shadow.root.barrier.done.329:                     ; preds = %shadow.root.barrier.328, %shadow.root.barrier.done.327
  %r1725 = load double, ptr @perry_global_changing_options_worker_ts__6, align 8
  %r1726.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s26 to i64
  %r1726 = call i64 asm "", "=r,0"(i64 %r1726.rs4i) #8
  %statepoint_token376 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1726, double %r1725, i32 0, i32 0)
  %r1727377 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token376)
  %rs4gc.s27 = inttoptr i64 %r1727377 to ptr addrspace(1)
  %r1728.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r1728 = call i64 asm "", "=r,0"(i64 %r1728.rs4i) #8
  %r1729 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1730 = icmp ne i32 %r1729, 0
  br i1 %r1730, label %shadow.root.barrier.330, label %shadow.root.barrier.done.331

shadow.root.barrier.330:                          ; preds = %shadow.root.barrier.done.329
  call void @js_write_barrier_root_nanbox(i64 %r1728) #8
  br label %shadow.root.barrier.done.331

shadow.root.barrier.done.331:                     ; preds = %shadow.root.barrier.330, %shadow.root.barrier.done.329
  %r1731.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s27 to i64
  %r1731 = call i64 asm "", "=r,0"(i64 %r1731.rs4i) #8
  %statepoint_token378 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1731, i32 0, i32 0)
  br label %if.merge.325

shadow.root.barrier.332:                          ; preds = %if.merge.325
  call void @js_write_barrier_root_nanbox(i64 %r1733) #8
  br label %shadow.root.barrier.done.333

shadow.root.barrier.done.333:                     ; preds = %shadow.root.barrier.332, %if.merge.325
  %r1736 = load double, ptr @changing_options_worker_ts_.str.17.handle, align 8
  %r1737.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s25 to i64
  %r1737 = call i64 asm "", "=r,0"(i64 %r1737.rs4i) #8
  %statepoint_token379 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1737, double %r1736, i32 0, i32 0)
  %r1738380 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token379)
  %rs4gc.s28 = inttoptr i64 %r1738380 to ptr addrspace(1)
  %r1739.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r1739 = call i64 asm "", "=r,0"(i64 %r1739.rs4i) #8
  %r1740 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1741 = icmp ne i32 %r1740, 0
  br i1 %r1741, label %shadow.root.barrier.334, label %shadow.root.barrier.done.335

shadow.root.barrier.334:                          ; preds = %shadow.root.barrier.done.333
  call void @js_write_barrier_root_nanbox(i64 %r1739) #8
  br label %shadow.root.barrier.done.335

shadow.root.barrier.done.335:                     ; preds = %shadow.root.barrier.334, %shadow.root.barrier.done.333
  %r1742 = load double, ptr @perry_global_changing_options_worker_ts__5, align 8
  %r1743 = bitcast double %r1742 to i64
  %r1745 = icmp eq i64 %r1743, 9222246136947933186
  %r1746 = select i1 %r1745, i64 9222246136947933188, i64 9222246136947933187
  %r1747 = bitcast i64 %r1746 to double
  %r1748 = icmp eq i64 %r1746, 9222246136947933188
  br i1 %r1748, label %ternary.then.336, label %ternary.else.337

ternary.then.336:                                 ; preds = %shadow.root.barrier.done.335
  br label %ternary.merge.338

ternary.else.337:                                 ; preds = %shadow.root.barrier.done.335
  br label %ternary.merge.338

ternary.merge.338:                                ; preds = %ternary.else.337, %ternary.then.336
  %r1749 = phi double [ 0.000000e+00, %ternary.then.336 ], [ 1.000000e+00, %ternary.else.337 ]
  %r1750.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s28 to i64
  %r1750 = call i64 asm "", "=r,0"(i64 %r1750.rs4i) #8
  %statepoint_token381 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1750, double %r1749, i32 0, i32 0)
  %r1751382 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token381)
  %rs4gc.s29 = inttoptr i64 %r1751382 to ptr addrspace(1)
  %r1752.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r1752 = call i64 asm "", "=r,0"(i64 %r1752.rs4i) #8
  %r1753 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1754 = icmp ne i32 %r1753, 0
  br i1 %r1754, label %shadow.root.barrier.339, label %shadow.root.barrier.done.340

shadow.root.barrier.339:                          ; preds = %ternary.merge.338
  call void @js_write_barrier_root_nanbox(i64 %r1752) #8
  br label %shadow.root.barrier.done.340

shadow.root.barrier.done.340:                     ; preds = %shadow.root.barrier.339, %ternary.merge.338
  %r1755 = load double, ptr @perry_global_changing_options_worker_ts__6, align 8
  %r1756 = bitcast double %r1755 to i64
  %r1758 = icmp eq i64 %r1756, 9222246136947933186
  %r1759 = select i1 %r1758, i64 9222246136947933188, i64 9222246136947933187
  %r1760 = bitcast i64 %r1759 to double
  %r1761 = icmp eq i64 %r1759, 9222246136947933188
  br i1 %r1761, label %ternary.then.341, label %ternary.else.342

ternary.then.341:                                 ; preds = %shadow.root.barrier.done.340
  br label %ternary.merge.343

ternary.else.342:                                 ; preds = %shadow.root.barrier.done.340
  br label %ternary.merge.343

ternary.merge.343:                                ; preds = %ternary.else.342, %ternary.then.341
  %r1762 = phi double [ 0.000000e+00, %ternary.then.341 ], [ 1.000000e+00, %ternary.else.342 ]
  %r1763.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s29 to i64
  %r1763 = call i64 asm "", "=r,0"(i64 %r1763.rs4i) #8
  %statepoint_token383 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i64 (i64, double)) @js_array_push_f64, i32 2, i32 0, i64 %r1763, double %r1762, i32 0, i32 0)
  %r1764384 = call i64 @llvm.experimental.gc.result.i64(token %statepoint_token383)
  %rs4gc.s30 = inttoptr i64 %r1764384 to ptr addrspace(1)
  %r1765.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r1765 = call i64 asm "", "=r,0"(i64 %r1765.rs4i) #8
  %r1766 = load atomic i32, ptr @PERRY_INCREMENTAL_MARK_BARRIER_ACTIVE_COUNT monotonic, align 4
  %r1767 = icmp ne i32 %r1766, 0
  br i1 %r1767, label %shadow.root.barrier.344, label %shadow.root.barrier.done.345

shadow.root.barrier.344:                          ; preds = %ternary.merge.343
  call void @js_write_barrier_root_nanbox(i64 %r1765) #8
  br label %shadow.root.barrier.done.345

shadow.root.barrier.done.345:                     ; preds = %shadow.root.barrier.344, %ternary.merge.343
  %r1768.rs4i = ptrtoint ptr addrspace(1) %rs4gc.s30 to i64
  %r1768 = call i64 asm "", "=r,0"(i64 %r1768.rs4i) #8
  %statepoint_token385 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void (i64)) @js_console_log_spread, i32 1, i32 0, i64 %r1768, i32 0, i32 0)
  %statepoint_token386 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token387 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token388 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token389 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token390 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.346

event_loop.header.346:                            ; preds = %event_loop.body_wait.351, %event_loop.body_check.350, %shadow.root.barrier.done.345
  %statepoint_token391 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_event_loop_host_driven, i32 0, i32 0, i32 0, i32 0)
  %r1773392 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token391)
  %r1774 = icmp ne i32 %r1773392, 0
  br i1 %r1774, label %event_loop.host_return.348, label %event_loop.check_pending.347

event_loop.check_pending.347:                     ; preds = %event_loop.header.346
  %statepoint_token393 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1775394 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token393)
  %statepoint_token395 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1776396 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token395)
  %statepoint_token397 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1777398 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token397)
  %statepoint_token399 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r1778400 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token399)
  %statepoint_token401 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r1779402 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token401)
  %statepoint_token403 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r1780404 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token403)
  %r1781 = or i32 %r1775394, %r1776396
  %r1782 = or i32 %r1777398, %r1778400
  %r1783 = or i32 %r1782, %r1779402
  %r1784 = or i32 %r1781, %r1783
  %r1785 = or i32 %r1784, 0
  %r1786 = or i32 %r1785, %r1780404
  %r1787 = icmp ne i32 %r1786, 0
  br i1 %r1787, label %event_loop.body.349, label %event_loop.exit.352

event_loop.host_return.348:                       ; preds = %event_loop.header.346
  call void @js_typed_feedback_maybe_dump_trace() #8
  ret i32 0

event_loop.body.349:                              ; preds = %event_loop.check_pending.347
  %statepoint_token405 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token406 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_run_stdlib_pump, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.body_check.350

event_loop.body_check.350:                        ; preds = %event_loop.body.349
  %statepoint_token407 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1789408 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token407)
  %statepoint_token409 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_callback_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1790410 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token409)
  %statepoint_token411 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_interval_timer_has_pending, i32 0, i32 0, i32 0, i32 0)
  %r1791412 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token411)
  %statepoint_token413 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_stdlib_has_active_handles, i32 0, i32 0, i32 0, i32 0)
  %r1792414 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token413)
  %statepoint_token415 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_bun_ffi_has_active_threadsafe_callbacks, i32 0, i32 0, i32 0, i32 0)
  %r1793416 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token415)
  %statepoint_token417 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_microtasks_pending, i32 0, i32 0, i32 0, i32 0)
  %r1794418 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token417)
  %r1795 = or i32 %r1789408, %r1790410
  %r1796 = or i32 %r1791412, %r1792414
  %r1797 = or i32 %r1796, %r1793416
  %r1798 = or i32 %r1795, %r1797
  %r1799 = or i32 %r1798, 0
  %r1800 = or i32 %r1799, %r1794418
  %r1801 = icmp ne i32 %r1800, 0
  br i1 %r1801, label %event_loop.body_wait.351, label %event_loop.header.346

event_loop.body_wait.351:                         ; preds = %event_loop.body_check.350
  %statepoint_token419 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_wait_for_event, i32 0, i32 0, i32 0, i32 0)
  br label %event_loop.header.346

event_loop.exit.352:                              ; preds = %event_loop.check_pending.347
  %statepoint_token420 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_emit_before_exit_pending, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token421 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_microtasks_event_loop, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token422 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_exit_sequence, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token423 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_process_run_finalization_exit, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token424 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_promise_run_promise_jobs, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token425 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_trace_events_flush_output, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token426 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_promise_report_unhandled_rejections, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token427 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(void ()) @js_gc_release_current_thread_collection_side_allocations, i32 0, i32 0, i32 0, i32 0)
  %statepoint_token428 = call token (i64, i32, ptr, i32, i32, ...) @llvm.experimental.gc.statepoint.p0(i64 2882400000, i32 0, ptr elementtype(i32 ()) @js_process_pending_exit_code, i32 0, i32 0, i32 0, i32 0)
  %r1804429 = call i32 @llvm.experimental.gc.result.i32(token %statepoint_token428)
  call void @js_typed_feedback_maybe_dump_trace() #8
  ret i32 %r1804429
}

; Function Attrs: optsize
define void @__perry_init_strings_changing_options_worker_ts_chunk0() #6 {
entry.0:
  %r1 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.0.bytes, i32 14)
  %r2 = call double @js_nanbox_string(i64 %r1)
  store double %r2, ptr @changing_options_worker_ts_.str.0.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.0.handle to i64))
  %r4 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.1.bytes, i32 2)
  %r5 = call double @js_nanbox_string(i64 %r4)
  store double %r5, ptr @changing_options_worker_ts_.str.1.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.1.handle to i64))
  %r7 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.2.bytes, i32 6)
  %r8 = call double @js_nanbox_string(i64 %r7)
  store double %r8, ptr @changing_options_worker_ts_.str.2.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.2.handle to i64))
  %r10 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.3.bytes, i32 13)
  %r11 = call double @js_nanbox_string(i64 %r10)
  store double %r11, ptr @changing_options_worker_ts_.str.3.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.3.handle to i64))
  %r13 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.4.bytes, i32 2)
  %r14 = call double @js_nanbox_string(i64 %r13)
  store double %r14, ptr @changing_options_worker_ts_.str.4.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.4.handle to i64))
  %r16 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.5.bytes, i32 12)
  %r17 = call double @js_nanbox_string(i64 %r16)
  store double %r17, ptr @changing_options_worker_ts_.str.5.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.5.handle to i64))
  %r19 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.6.bytes, i32 4)
  %r20 = call double @js_nanbox_string(i64 %r19)
  store double %r20, ptr @changing_options_worker_ts_.str.6.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.6.handle to i64))
  %r22 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.7.bytes, i32 1)
  %r23 = call double @js_nanbox_string(i64 %r22)
  store double %r23, ptr @changing_options_worker_ts_.str.7.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.7.handle to i64))
  %r25 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.8.bytes, i32 8)
  %r26 = call double @js_nanbox_string(i64 %r25)
  store double %r26, ptr @changing_options_worker_ts_.str.8.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.8.handle to i64))
  %r28 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.9.bytes, i32 1)
  %r29 = call double @js_nanbox_string(i64 %r28)
  store double %r29, ptr @changing_options_worker_ts_.str.9.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.9.handle to i64))
  %r31 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.10.bytes, i32 4)
  %r32 = call double @js_nanbox_string(i64 %r31)
  store double %r32, ptr @changing_options_worker_ts_.str.10.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.10.handle to i64))
  %r34 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.11.bytes, i32 3)
  %r35 = call double @js_nanbox_string(i64 %r34)
  store double %r35, ptr @changing_options_worker_ts_.str.11.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.11.handle to i64))
  %r37 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.12.bytes, i32 6)
  %r38 = call double @js_nanbox_string(i64 %r37)
  store double %r38, ptr @changing_options_worker_ts_.str.12.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.12.handle to i64))
  %r40 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.13.bytes, i32 4)
  %r41 = call double @js_nanbox_string(i64 %r40)
  store double %r41, ptr @changing_options_worker_ts_.str.13.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.13.handle to i64))
  %r43 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.14.bytes, i32 6)
  %r44 = call double @js_nanbox_string(i64 %r43)
  store double %r44, ptr @changing_options_worker_ts_.str.14.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.14.handle to i64))
  %r46 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.15.bytes, i32 6)
  %r47 = call double @js_nanbox_string(i64 %r46)
  store double %r47, ptr @changing_options_worker_ts_.str.15.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.15.handle to i64))
  %r49 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.16.bytes, i32 6)
  %r50 = call double @js_nanbox_string(i64 %r49)
  store double %r50, ptr @changing_options_worker_ts_.str.16.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.16.handle to i64))
  %r52 = call i64 @js_string_from_bytes(ptr @changing_options_worker_ts_.str.17.bytes, i32 4)
  %r53 = call double @js_nanbox_string(i64 %r52)
  store double %r53, ptr @changing_options_worker_ts_.str.17.handle, align 8
  call void @js_gc_register_global_root(i64 ptrtoint (ptr @changing_options_worker_ts_.str.17.handle to i64))
  call void @js_register_function_name_static(ptr @__perry_wrap_perry_fn_changing_options_worker_ts__run, ptr @changing_options_worker_ts_.str.1, i32 3)
  call void @js_register_function_name_static(ptr @perry_fn_changing_options_worker_ts__run, ptr @changing_options_worker_ts_.str.1, i32 3)
  call void @js_register_function_source_static(ptr @__perry_wrap_perry_fn_changing_options_worker_ts__run, ptr @changing_options_worker_ts_.str.2, i32 565, i32 0)
  call void @js_register_closure_arity(ptr @__perry_wrap_perry_fn_changing_options_worker_ts__run, i32 1)
  call void @js_register_closure_length(ptr @__perry_wrap_perry_fn_changing_options_worker_ts__run, i32 1)
  call void @js_register_closure_strict_function(ptr @__perry_wrap_perry_fn_changing_options_worker_ts__run)
  ret void
}

; Function Attrs: optsize
define void @__perry_init_strings_changing_options_worker_ts() #6 {
entry.0:
  call void @__perry_init_strings_changing_options_worker_ts_chunk0()
  ret void
}

declare void @__tmp_use(...)

attributes #0 = { nounwind willreturn }
attributes #1 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(none) }
attributes #4 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { optsize "frame-pointer"="non-leaf" }
attributes #7 = { noinline optsize "frame-pointer"="non-leaf" }
attributes #8 = { "gc-leaf-function" }
