
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-token-proof-r31/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100845f40 <_js_json_stringify_full>:
100845f40:     	sub	sp, sp, #0x120
100845f44:     	stp	d9, d8, [sp, #0xb0]
100845f48:     	stp	x28, x27, [sp, #0xc0]
100845f4c:     	stp	x26, x25, [sp, #0xd0]
100845f50:     	stp	x24, x23, [sp, #0xe0]
100845f54:     	stp	x22, x21, [sp, #0xf0]
100845f58:     	stp	x20, x19, [sp, #0x100]
100845f5c:     	stp	x29, x30, [sp, #0x110]
100845f60:     	add	x29, sp, #0x110
100845f64:     	mov.16b	v9, v2
100845f68:     	mov.16b	v8, v0
100845f6c:     	fmov	x19, d8
100845f70:     	fmov	x21, d1
100845f74:     	fmov	x23, d9
100845f78:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100845f7c:     	add	x27, x21, x8
100845f80:     	add	x24, x23, x8
100845f84:     	fcmp	d2, #0.0
100845f88:     	ccmp	x24, #0x2, #0x0, ne
100845f8c:     	b.hi	0x100845f9c <_js_json_stringify_full+0x5c>
100845f90:     	cmp	x27, #0x2
100845f94:     	b.lo	0x100845fac <_js_json_stringify_full+0x6c>
100845f98:     	b	0x100846518 <_js_json_stringify_full+0x5d8>
100845f9c:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
100845fa0:     	cmp	x23, x8
100845fa4:     	ccmp	x27, #0x2, #0x2, eq
100845fa8:     	b.hs	0x100846518 <_js_json_stringify_full+0x5d8>
100845fac:     	mov	x8, #-0x2               ; =-2
100845fb0:     	movk	x8, #0x8003, lsl #48
100845fb4:     	add	x8, x19, x8
100845fb8:     	cmp	x8, #0x3
100845fbc:     	b.hs	0x100845fd0 <_js_json_stringify_full+0x90>
100845fc0:     	adrp	x9, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5430>
100845fc4:     	add	x9, x9, #0x158
100845fc8:     	ldr	x20, [x9, x8, lsl #3]
100845fcc:     	b	0x1008473e8 <_js_json_stringify_full+0x14a8>
100845fd0:     	strb	wzr, [sp, #0x4c]
100845fd4:     	str	wzr, [sp, #0x48]
100845fd8:     	and	x8, x19, #0xffff000000000000
100845fdc:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100845fe0:     	cmp	x8, x9
100845fe4:     	b.eq	0x100846058 <_js_json_stringify_full+0x118>
100845fe8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100845fec:     	cmp	x8, x9
100845ff0:     	b.ne	0x100846454 <_js_json_stringify_full+0x514>
100845ff4:     	ubfx	x10, x19, #40, #8
100845ff8:     	cbz	x10, 0x100846048 <_js_json_stringify_full+0x108>
100845ffc:     	strb	w19, [sp, #0x48]
100846000:     	cmp	x10, #0x1
100846004:     	b.eq	0x100846048 <_js_json_stringify_full+0x108>
100846008:     	lsr	x9, x19, #8
10084600c:     	strb	w9, [sp, #0x49]
100846010:     	cmp	x10, #0x2
100846014:     	b.eq	0x100846048 <_js_json_stringify_full+0x108>
100846018:     	lsr	x9, x19, #16
10084601c:     	strb	w9, [sp, #0x4a]
100846020:     	cmp	x10, #0x3
100846024:     	b.eq	0x100846048 <_js_json_stringify_full+0x108>
100846028:     	lsr	x9, x19, #24
10084602c:     	strb	w9, [sp, #0x4b]
100846030:     	cmp	x10, #0x4
100846034:     	b.eq	0x100846048 <_js_json_stringify_full+0x108>
100846038:     	lsr	x9, x19, #32
10084603c:     	strb	w9, [sp, #0x4c]
100846040:     	cmp	x10, #0x5
100846044:     	b.ne	0x100847bbc <_js_json_stringify_full+0x1c7c>
100846048:     	add	x11, sp, #0x48
10084604c:     	cmp	w10, #0x3
100846050:     	b.ls	0x100846070 <_js_json_stringify_full+0x130>
100846054:     	b	0x100846454 <_js_json_stringify_full+0x514>
100846058:     	ands	x9, x19, #0xffffffffffff
10084605c:     	b.eq	0x100846518 <_js_json_stringify_full+0x5d8>
100846060:     	add	x11, x9, #0x14
100846064:     	ldr	w10, [x9, #0x4]
100846068:     	cmp	w10, #0x3
10084606c:     	b.hi	0x100846454 <_js_json_stringify_full+0x514>
100846070:     	stur	wzr, [sp, #0x81]
100846074:     	mov	w9, #0x22               ; =34
100846078:     	strb	w9, [sp, #0x80]
10084607c:     	cbz	w10, 0x1008460b4 <_js_json_stringify_full+0x174>
100846080:     	add	x12, sp, #0x80
100846084:     	ldrb	w13, [x11]
100846088:     	sxtb	w15, w13
10084608c:     	cmp	w13, #0xb
100846090:     	b.le	0x1008460bc <_js_json_stringify_full+0x17c>
100846094:     	cmp	w13, #0x21
100846098:     	b.gt	0x1008460dc <_js_json_stringify_full+0x19c>
10084609c:     	cmp	w13, #0xc
1008460a0:     	b.eq	0x100846110 <_js_json_stringify_full+0x1d0>
1008460a4:     	cmp	w13, #0xd
1008460a8:     	b.ne	0x1008460ec <_js_json_stringify_full+0x1ac>
1008460ac:     	mov	w15, #0x72              ; =114
1008460b0:     	b	0x10084611c <_js_json_stringify_full+0x1dc>
1008460b4:     	mov	w12, #0x1               ; =1
1008460b8:     	b	0x100846144 <_js_json_stringify_full+0x204>
1008460bc:     	cmp	w13, #0x8
1008460c0:     	b.eq	0x100846108 <_js_json_stringify_full+0x1c8>
1008460c4:     	cmp	w13, #0x9
1008460c8:     	b.eq	0x100846118 <_js_json_stringify_full+0x1d8>
1008460cc:     	cmp	w13, #0xa
1008460d0:     	b.ne	0x1008460ec <_js_json_stringify_full+0x1ac>
1008460d4:     	mov	w15, #0x6e              ; =110
1008460d8:     	b	0x10084611c <_js_json_stringify_full+0x1dc>
1008460dc:     	cmp	w13, #0x22
1008460e0:     	b.eq	0x10084611c <_js_json_stringify_full+0x1dc>
1008460e4:     	cmp	w13, #0x5c
1008460e8:     	b.eq	0x10084611c <_js_json_stringify_full+0x1dc>
1008460ec:     	cmp	w15, #0x20
1008460f0:     	b.lt	0x100846454 <_js_json_stringify_full+0x514>
1008460f4:     	mov	w14, #0x0               ; =0
1008460f8:     	add	x13, x12, #0x2
1008460fc:     	mov	w12, #0x2               ; =2
100846100:     	mov	w16, #0x1               ; =1
100846104:     	b	0x100846134 <_js_json_stringify_full+0x1f4>
100846108:     	mov	w15, #0x62              ; =98
10084610c:     	b	0x10084611c <_js_json_stringify_full+0x1dc>
100846110:     	mov	w15, #0x66              ; =102
100846114:     	b	0x10084611c <_js_json_stringify_full+0x1dc>
100846118:     	mov	w15, #0x74              ; =116
10084611c:     	add	x13, x12, #0x3
100846120:     	mov	w12, #0x5c              ; =92
100846124:     	strb	w12, [sp, #0x81]
100846128:     	mov	w14, #0x1               ; =1
10084612c:     	mov	w12, #0x3               ; =3
100846130:     	mov	w16, #0x2               ; =2
100846134:     	add	x17, sp, #0x80
100846138:     	strb	w15, [x17, x16]
10084613c:     	cmp	w10, #0x1
100846140:     	b.ne	0x10084617c <_js_json_stringify_full+0x23c>
100846144:     	add	x10, sp, #0x80
100846148:     	strb	w9, [x10, x12]
10084614c:     	add	x8, x12, #0x1
100846150:     	cmp	x12, #0x3
100846154:     	b.hs	0x100846168 <_js_json_stringify_full+0x228>
100846158:     	mov	x13, #0x0               ; =0
10084615c:     	mov	x11, #0x0               ; =0
100846160:     	add	x9, sp, #0x80
100846164:     	b	0x1008463c4 <_js_json_stringify_full+0x484>
100846168:     	cmp	x12, #0xf
10084616c:     	b.hs	0x1008461ac <_js_json_stringify_full+0x26c>
100846170:     	mov	x11, #0x0               ; =0
100846174:     	mov	x13, #0x0               ; =0
100846178:     	b	0x100846320 <_js_json_stringify_full+0x3e0>
10084617c:     	ldrb	w16, [x11, #0x1]
100846180:     	sxtb	w15, w16
100846184:     	cmp	w16, #0xb
100846188:     	b.le	0x1008463f4 <_js_json_stringify_full+0x4b4>
10084618c:     	cmp	w16, #0x21
100846190:     	b.gt	0x100846414 <_js_json_stringify_full+0x4d4>
100846194:     	cmp	w16, #0xc
100846198:     	b.eq	0x100846444 <_js_json_stringify_full+0x504>
10084619c:     	cmp	w16, #0xd
1008461a0:     	b.ne	0x100846424 <_js_json_stringify_full+0x4e4>
1008461a4:     	mov	w15, #0x72              ; =114
1008461a8:     	b	0x100846450 <_js_json_stringify_full+0x510>
1008461ac:     	and	x12, x8, #0xc
1008461b0:     	and	x11, x8, #0x10
1008461b4:     	add	x13, sp, #0x80
1008461b8:     	add	x9, x13, x11
1008461bc:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6430>
1008461c0:     	ldr	q0, [x14, #0x2d0]
1008461c4:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6430>
1008461c8:     	ldr	q1, [x14, #0x2e0]
1008461cc:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6430>
1008461d0:     	ldr	q2, [x14, #0x2f0]
1008461d4:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6430>
1008461d8:     	ldr	q3, [x14, #0x300]
1008461dc:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6430>
1008461e0:     	ldr	q4, [x14, #0x310]
1008461e4:     	movi.2d	v5, #0000000000000000
1008461e8:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6430>
1008461ec:     	ldr	q6, [x14, #0x320]
1008461f0:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5430>
1008461f4:     	ldr	q7, [x14, #0x440]
1008461f8:     	mov	w14, #0x10              ; =16
1008461fc:     	movi.2d	v16, #0000000000000000
100846200:     	dup.2d	v17, x14
100846204:     	adrp	x14, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33c3a>
100846208:     	ldr	q19, [x14, #0x340]
10084620c:     	and	x14, x8, #0x10
100846210:     	movi.2d	v20, #0000000000000000
100846214:     	movi.2d	v18, #0000000000000000
100846218:     	movi.2d	v23, #0000000000000000
10084621c:     	movi.2d	v21, #0000000000000000
100846220:     	movi.2d	v24, #0000000000000000
100846224:     	movi.2d	v22, #0000000000000000
100846228:     	ldr	q25, [x13], #0x10
10084622c:     	ushll.8h	v26, v25, #0x0
100846230:     	ushll2.4s	v27, v26, #0x0
100846234:     	ushll2.2d	v28, v27, #0x0
100846238:     	ushll2.8h	v25, v25, #0x0
10084623c:     	ushll.4s	v29, v25, #0x0
100846240:     	ushll2.2d	v30, v29, #0x0
100846244:     	ushll.2d	v29, v29, #0x0
100846248:     	ushll.2d	v27, v27, #0x0
10084624c:     	ushll.4s	v26, v26, #0x0
100846250:     	ushll2.2d	v31, v26, #0x0
100846254:     	ushll2.4s	v25, v25, #0x0
100846258:     	ushll.2d	v8, v25, #0x0
10084625c:     	ushll.2d	v26, v26, #0x0
100846260:     	ushll2.2d	v25, v25, #0x0
100846264:     	shl.2d	v9, v0, #0x3
100846268:     	ushl.2d	v25, v25, v9
10084626c:     	shl.2d	v9, v19, #0x3
100846270:     	ushl.2d	v26, v26, v9
100846274:     	shl.2d	v9, v1, #0x3
100846278:     	ushl.2d	v8, v8, v9
10084627c:     	shl.2d	v9, v7, #0x3
100846280:     	ushl.2d	v31, v31, v9
100846284:     	shl.2d	v9, v6, #0x3
100846288:     	ushl.2d	v27, v27, v9
10084628c:     	shl.2d	v9, v3, #0x3
100846290:     	ushl.2d	v29, v29, v9
100846294:     	shl.2d	v9, v2, #0x3
100846298:     	ushl.2d	v30, v30, v9
10084629c:     	shl.2d	v9, v4, #0x3
1008462a0:     	ushl.2d	v28, v28, v9
1008462a4:     	orr.16b	v18, v28, v18
1008462a8:     	orr.16b	v21, v30, v21
1008462ac:     	orr.16b	v23, v29, v23
1008462b0:     	orr.16b	v20, v27, v20
1008462b4:     	orr.16b	v5, v31, v5
1008462b8:     	orr.16b	v24, v8, v24
1008462bc:     	orr.16b	v16, v26, v16
1008462c0:     	orr.16b	v22, v25, v22
1008462c4:     	add.2d	v6, v6, v17
1008462c8:     	add.2d	v7, v7, v17
1008462cc:     	add.2d	v19, v19, v17
1008462d0:     	add.2d	v4, v4, v17
1008462d4:     	add.2d	v3, v3, v17
1008462d8:     	add.2d	v2, v2, v17
1008462dc:     	add.2d	v1, v1, v17
1008462e0:     	add.2d	v0, v0, v17
1008462e4:     	subs	x14, x14, #0x10
1008462e8:     	b.ne	0x100846228 <_js_json_stringify_full+0x2e8>
1008462ec:     	orr.16b	v0, v16, v23
1008462f0:     	orr.16b	v1, v20, v24
1008462f4:     	orr.16b	v0, v0, v1
1008462f8:     	orr.16b	v1, v5, v21
1008462fc:     	orr.16b	v2, v18, v22
100846300:     	orr.16b	v1, v1, v2
100846304:     	orr.16b	v0, v0, v1
100846308:     	mov	d1, v0[1]
10084630c:     	orr.8b	v0, v0, v1
100846310:     	fmov	x13, d0
100846314:     	cmp	x8, x11
100846318:     	b.eq	0x1008463e4 <_js_json_stringify_full+0x4a4>
10084631c:     	cbz	x12, 0x1008463c4 <_js_json_stringify_full+0x484>
100846320:     	mov	x14, x11
100846324:     	and	x11, x8, #0x1c
100846328:     	add	x15, sp, #0x80
10084632c:     	add	x9, x15, x11
100846330:     	fmov	d0, x13
100846334:     	movi.2d	v1, #0000000000000000
100846338:     	dup.2d	v3, x14
10084633c:     	adrp	x12, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5430>
100846340:     	ldr	q2, [x12, #0x440]
100846344:     	orr.16b	v2, v3, v2
100846348:     	adrp	x12, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33c3a>
10084634c:     	ldr	q4, [x12, #0x340]
100846350:     	orr.16b	v3, v3, v4
100846354:     	sub	x12, x14, x11
100846358:     	add	x13, x15, x14
10084635c:     	movi.2d	v4, #0x000000000000ff
100846360:     	mov	w14, #0x4               ; =4
100846364:     	dup.2d	v5, x14
100846368:     	ldr	s6, [x13], #0x4
10084636c:     	ushll.8h	v6, v6, #0x0
100846370:     	ushll.4s	v6, v6, #0x0
100846374:     	ushll2.2d	v7, v6, #0x0
100846378:     	and.16b	v7, v7, v4
10084637c:     	ushll.2d	v6, v6, #0x0
100846380:     	and.16b	v6, v6, v4
100846384:     	shl.2d	v16, v2, #0x3
100846388:     	shl.2d	v17, v3, #0x3
10084638c:     	ushl.2d	v6, v6, v17
100846390:     	ushl.2d	v7, v7, v16
100846394:     	orr.16b	v1, v7, v1
100846398:     	orr.16b	v0, v6, v0
10084639c:     	add.2d	v2, v2, v5
1008463a0:     	add.2d	v3, v3, v5
1008463a4:     	adds	x12, x12, #0x4
1008463a8:     	b.ne	0x100846368 <_js_json_stringify_full+0x428>
1008463ac:     	orr.16b	v0, v0, v1
1008463b0:     	mov	d1, v0[1]
1008463b4:     	orr.8b	v0, v0, v1
1008463b8:     	fmov	x13, d0
1008463bc:     	cmp	x8, x11
1008463c0:     	b.eq	0x1008463e4 <_js_json_stringify_full+0x4a4>
1008463c4:     	add	x10, x10, x8
1008463c8:     	lsl	x11, x11, #3
1008463cc:     	ldrb	w12, [x9], #0x1
1008463d0:     	lsl	x12, x12, x11
1008463d4:     	orr	x13, x12, x13
1008463d8:     	add	x11, x11, #0x8
1008463dc:     	cmp	x9, x10
1008463e0:     	b.ne	0x1008463cc <_js_json_stringify_full+0x48c>
1008463e4:     	orr	x8, x13, x8, lsl #40
1008463e8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008463ec:     	orr	x20, x8, x9
1008463f0:     	b	0x1008473e8 <_js_json_stringify_full+0x14a8>
1008463f4:     	cmp	w16, #0x8
1008463f8:     	b.eq	0x10084643c <_js_json_stringify_full+0x4fc>
1008463fc:     	cmp	w16, #0x9
100846400:     	b.eq	0x10084644c <_js_json_stringify_full+0x50c>
100846404:     	cmp	w16, #0xa
100846408:     	b.ne	0x100846424 <_js_json_stringify_full+0x4e4>
10084640c:     	mov	w15, #0x6e              ; =110
100846410:     	b	0x100846450 <_js_json_stringify_full+0x510>
100846414:     	cmp	w16, #0x22
100846418:     	b.eq	0x100846450 <_js_json_stringify_full+0x510>
10084641c:     	cmp	w16, #0x5c
100846420:     	b.eq	0x100846450 <_js_json_stringify_full+0x510>
100846424:     	cmp	w15, #0x20
100846428:     	b.lt	0x100846454 <_js_json_stringify_full+0x514>
10084642c:     	add	x13, sp, #0x80
100846430:     	strb	w15, [x13, x12]
100846434:     	add	x12, x12, #0x1
100846438:     	b	0x1008469dc <_js_json_stringify_full+0xa9c>
10084643c:     	mov	w15, #0x62              ; =98
100846440:     	b	0x100846450 <_js_json_stringify_full+0x510>
100846444:     	mov	w15, #0x66              ; =102
100846448:     	b	0x100846450 <_js_json_stringify_full+0x510>
10084644c:     	mov	w15, #0x74              ; =116
100846450:     	tbz	w14, #0x0, 0x1008469c8 <_js_json_stringify_full+0xa88>
100846454:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846458:     	cmp	x8, x9
10084645c:     	b.eq	0x1008464a4 <_js_json_stringify_full+0x564>
100846460:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846464:     	cmp	x8, x9
100846468:     	b.ne	0x100846518 <_js_json_stringify_full+0x5d8>
10084646c:     	and	x8, x19, #0xffffffffffff
100846470:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
100846474:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100846478:     	movk	x10, #0xffef, lsl #16
10084647c:     	cmp	x9, x10
100846480:     	b.hi	0x100846518 <_js_json_stringify_full+0x5d8>
100846484:     	ldr	w8, [x8, #0x4]
100846488:     	cmp	w8, #0x40
10084648c:     	b.lo	0x100846518 <_js_json_stringify_full+0x5d8>
100846490:     	and	x0, x19, #0xffffffffffff
100846494:     	bl	0x1004f2ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100846498:     	cmp	x0, #0x1
10084649c:     	b.ne	0x100846518 <_js_json_stringify_full+0x5d8>
1008464a0:     	b	0x100846664 <_js_json_stringify_full+0x724>
1008464a4:     	and	x25, x19, #0xffffffffffff
1008464a8:     	and	x0, x19, #0xffffffffffff
1008464ac:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008464b0:     	cbz	x0, 0x1008464e4 <_js_json_stringify_full+0x5a4>
1008464b4:     	ldrb	w8, [x0]
1008464b8:     	cmp	w8, #0x2
1008464bc:     	b.ne	0x1008464e4 <_js_json_stringify_full+0x5a4>
1008464c0:     	ldrsb	w8, [x0, #0x1]
1008464c4:     	tbnz	w8, #0x1f, 0x1008464e4 <_js_json_stringify_full+0x5a4>
1008464c8:     	ldrh	w8, [x0, #0x2]
1008464cc:     	tbnz	w8, #0xb, 0x1008464e4 <_js_json_stringify_full+0x5a4>
1008464d0:     	ldr	w8, [x0, #0x4]
1008464d4:     	cmp	w8, #0x18
1008464d8:     	b.lo	0x1008464e4 <_js_json_stringify_full+0x5a4>
1008464dc:     	ldr	w8, [x25]
1008464e0:     	cbz	w8, 0x10084753c <_js_json_stringify_full+0x15fc>
1008464e4:     	and	x0, x19, #0xffffffffffff
1008464e8:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008464ec:     	cbz	x0, 0x100846518 <_js_json_stringify_full+0x5d8>
1008464f0:     	ldrb	w8, [x0]
1008464f4:     	cmp	w8, #0x2
1008464f8:     	b.ne	0x100846518 <_js_json_stringify_full+0x5d8>
1008464fc:     	ldrh	w8, [x0, #0x2]
100846500:     	tbnz	w8, #0xb, 0x100846518 <_js_json_stringify_full+0x5d8>
100846504:     	ldr	w8, [x0, #0x4]
100846508:     	cmp	w8, #0x18
10084650c:     	b.lo	0x100846518 <_js_json_stringify_full+0x5d8>
100846510:     	ldr	w8, [x25]
100846514:     	cbz	w8, 0x1008474e0 <_js_json_stringify_full+0x15a0>
100846518:     	mov	x20, #0x1               ; =1
10084651c:     	movk	x20, #0x7ffc, lsl #48
100846520:     	cmp	x19, x20
100846524:     	b.eq	0x1008473e8 <_js_json_stringify_full+0x14a8>
100846528:     	and	x22, x19, #0xffff000000000000
10084652c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846530:     	cmp	x22, x8
100846534:     	b.ne	0x10084656c <_js_json_stringify_full+0x62c>
100846538:     	and	x8, x19, #0xffffffffffff
10084653c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846540:     	b.lo	0x100846558 <_js_json_stringify_full+0x618>
100846544:     	ldr	w8, [x8, #0xc]
100846548:     	mov	w9, #0x4f53             ; =20307
10084654c:     	movk	w9, #0x434c, lsl #16
100846550:     	cmp	w8, w9
100846554:     	b.eq	0x1008473e8 <_js_json_stringify_full+0x14a8>
100846558:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084655c:     	cmp	x22, x8
100846560:     	b.ne	0x100846598 <_js_json_stringify_full+0x658>
100846564:     	and	x0, x19, #0xffffffffffff
100846568:     	b	0x1008465c0 <_js_json_stringify_full+0x680>
10084656c:     	lsr	x8, x19, #52
100846570:     	cbnz	x8, 0x100846648 <_js_json_stringify_full+0x708>
100846574:     	and	x8, x19, #0x7
100846578:     	cbz	x19, 0x1008465a4 <_js_json_stringify_full+0x664>
10084657c:     	cbnz	x8, 0x1008465a4 <_js_json_stringify_full+0x664>
100846580:     	mov	x0, x19
100846584:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846588:     	mov	x8, x19
10084658c:     	tbnz	w0, #0x0, 0x10084653c <_js_json_stringify_full+0x5fc>
100846590:     	mov	x8, #0x0                ; =0
100846594:     	b	0x1008465a4 <_js_json_stringify_full+0x664>
100846598:     	lsr	x8, x19, #52
10084659c:     	cbnz	x8, 0x100846648 <_js_json_stringify_full+0x708>
1008465a0:     	and	x8, x19, #0x7
1008465a4:     	cbz	x19, 0x100846648 <_js_json_stringify_full+0x708>
1008465a8:     	cbnz	x8, 0x100846648 <_js_json_stringify_full+0x708>
1008465ac:     	mov	x0, x19
1008465b0:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008465b4:     	mov	x8, x0
1008465b8:     	mov	x0, x19
1008465bc:     	tbz	w8, #0x0, 0x100846648 <_js_json_stringify_full+0x708>
1008465c0:     	cmp	x0, #0x100, lsl #12     ; =0x100000
1008465c4:     	b.lo	0x100846648 <_js_json_stringify_full+0x708>
1008465c8:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1008465cc:     	add	x8, x8, #0xfb0
1008465d0:     	ldaprb	w8, [x8]
1008465d4:     	cbz	w8, 0x100846648 <_js_json_stringify_full+0x708>
1008465d8:     	lsr	x8, x0, #3
1008465dc:     	mov	x9, #0x7c15             ; =31765
1008465e0:     	movk	x9, #0x7f4a, lsl #16
1008465e4:     	movk	x9, #0x79b9, lsl #32
1008465e8:     	movk	x9, #0x9e37, lsl #48
1008465ec:     	mul	x8, x8, x9
1008465f0:     	lsr	x10, x8, #54
1008465f4:     	lsr	x11, x8, #60
1008465f8:     	adrp	x9, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1008465fc:     	add	x9, x9, #0xf30
100846600:     	add	x11, x9, x11, lsl #3
100846604:     	ldapr	x11, [x11]
100846608:     	lsr	x10, x11, x10
10084660c:     	tbz	w10, #0x0, 0x100846648 <_js_json_stringify_full+0x708>
100846610:     	lsr	x10, x8, #44
100846614:     	ubfx	x11, x8, #50, #4
100846618:     	add	x11, x9, x11, lsl #3
10084661c:     	ldapr	x11, [x11]
100846620:     	lsr	x10, x11, x10
100846624:     	tbz	w10, #0x0, 0x100846648 <_js_json_stringify_full+0x708>
100846628:     	lsr	x10, x8, #34
10084662c:     	ubfx	x8, x8, #40, #4
100846630:     	add	x8, x9, x8, lsl #3
100846634:     	ldapr	x8, [x8]
100846638:     	lsr	x8, x8, x10
10084663c:     	tbz	w8, #0x0, 0x100846648 <_js_json_stringify_full+0x708>
100846640:     	bl	0x10034ca2c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
100846644:     	tbnz	w0, #0x0, 0x1008473e8 <_js_json_stringify_full+0x14a8>
100846648:     	cmp	x24, #0x3
10084664c:     	ccmp	x27, #0x2, #0x2, lo
100846650:     	b.hs	0x100846670 <_js_json_stringify_full+0x730>
100846654:     	mov.16b	v0, v8
100846658:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084665c:     	cmp	x0, #0x1
100846660:     	b.ne	0x100846670 <_js_json_stringify_full+0x730>
100846664:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100846668:     	bfxil	x20, x1, #0, #48
10084666c:     	b	0x1008473e8 <_js_json_stringify_full+0x14a8>
100846670:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846674:     	cmp	x22, x8
100846678:     	b.ne	0x1008466c8 <_js_json_stringify_full+0x788>
10084667c:     	ands	x22, x19, #0xffffffffffff
100846680:     	b.eq	0x1008466c8 <_js_json_stringify_full+0x788>
100846684:     	mov	x0, x22
100846688:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084668c:     	cbz	w0, 0x1008466c8 <_js_json_stringify_full+0x788>
100846690:     	ldurb	w8, [x22, #-0x8]
100846694:     	cmp	w8, #0x9
100846698:     	b.ne	0x1008466c8 <_js_json_stringify_full+0x788>
10084669c:     	ldr	w8, [x22, #0x4]
1008466a0:     	mov	w9, #0x5841             ; =22593
1008466a4:     	movk	w9, #0x4c5a, lsl #16
1008466a8:     	cmp	w8, w9
1008466ac:     	b.ne	0x1008466c8 <_js_json_stringify_full+0x788>
1008466b0:     	mov	x0, x22
1008466b4:     	bl	0x1006887e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1008466b8:     	cbz	x0, 0x1008466c8 <_js_json_stringify_full+0x788>
1008466bc:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
1008466c0:     	bfxil	x19, x0, #0, #48
1008466c4:     	fmov	d8, x19
1008466c8:     	mov	w8, #0x7ffd             ; =32765
1008466cc:     	cmp	x8, x23, lsr #48
1008466d0:     	b.ne	0x1008466e4 <_js_json_stringify_full+0x7a4>
1008466d4:     	and	x1, x23, #0xffffffffffff
1008466d8:     	cmp	x1, #0x100, lsl #12     ; =0x100000
1008466dc:     	b.hs	0x1008466f8 <_js_json_stringify_full+0x7b8>
1008466e0:     	b	0x10084674c <_js_json_stringify_full+0x80c>
1008466e4:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
1008466e8:     	mov	x9, #0xfffffff00000     ; =281474975662080
1008466ec:     	mov	x1, x23
1008466f0:     	cmp	x8, x9
1008466f4:     	b.hs	0x10084674c <_js_json_stringify_full+0x80c>
1008466f8:     	lsr	x8, x1, #47
1008466fc:     	cbnz	x8, 0x10084674c <_js_json_stringify_full+0x80c>
100846700:     	add	x0, sp, #0x80
100846704:     	bl	0x10076e5ec <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
100846708:     	ldr	w8, [sp, #0x80]
10084670c:     	tbz	w8, #0x0, 0x10084674c <_js_json_stringify_full+0x80c>
100846710:     	ldr	w8, [sp, #0x88]
100846714:     	mov	w9, #-0xff30            ; =-65328
100846718:     	cmp	w8, w9
10084671c:     	b.eq	0x100846740 <_js_json_stringify_full+0x800>
100846720:     	mov	w9, #-0xff2f            ; =-65327
100846724:     	cmp	w8, w9
100846728:     	b.ne	0x10084674c <_js_json_stringify_full+0x80c>
10084672c:     	mov.16b	v0, v9
100846730:     	bl	0x1008487fc <_js_jsvalue_to_string>
100846734:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
100846738:     	bfxil	x23, x0, #0, #48
10084673c:     	b	0x10084674c <_js_json_stringify_full+0x80c>
100846740:     	mov.16b	v0, v9
100846744:     	bl	0x10086fda0 <_js_number_coerce>
100846748:     	fmov	x23, d0
10084674c:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100846750:     	add	x8, x23, x8
100846754:     	cmp	x8, #0x3
100846758:     	b.hs	0x100846770 <_js_json_stringify_full+0x830>
10084675c:     	mov	x22, #0x0               ; =0
100846760:     	mov	w8, #0x1                ; =1
100846764:     	stp	xzr, x8, [sp, #0x10]
100846768:     	str	xzr, [sp, #0x20]
10084676c:     	b	0x100846a24 <_js_json_stringify_full+0xae4>
100846770:     	and	x8, x23, #0xffff000000000000
100846774:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100846778:     	cmp	x8, x9
10084677c:     	b.eq	0x1008467a0 <_js_json_stringify_full+0x860>
100846780:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846784:     	cmp	x8, x9
100846788:     	b.ne	0x10084682c <_js_json_stringify_full+0x8ec>
10084678c:     	and	x8, x23, #0xffffffffffff
100846790:     	cmp	x8, #0x1, lsl #12       ; =0x1000
100846794:     	b.hs	0x100846874 <_js_json_stringify_full+0x934>
100846798:     	mov	x9, #0x0                ; =0
10084679c:     	b	0x10084687c <_js_json_stringify_full+0x93c>
1008467a0:     	strb	wzr, [sp, #0x4c]
1008467a4:     	str	wzr, [sp, #0x48]
1008467a8:     	ubfx	x1, x23, #40, #8
1008467ac:     	cbz	x1, 0x1008467fc <_js_json_stringify_full+0x8bc>
1008467b0:     	strb	w23, [sp, #0x48]
1008467b4:     	cmp	x1, #0x1
1008467b8:     	b.eq	0x1008467fc <_js_json_stringify_full+0x8bc>
1008467bc:     	lsr	x8, x23, #8
1008467c0:     	strb	w8, [sp, #0x49]
1008467c4:     	cmp	x1, #0x2
1008467c8:     	b.eq	0x1008467fc <_js_json_stringify_full+0x8bc>
1008467cc:     	lsr	x8, x23, #16
1008467d0:     	strb	w8, [sp, #0x4a]
1008467d4:     	cmp	x1, #0x3
1008467d8:     	b.eq	0x1008467fc <_js_json_stringify_full+0x8bc>
1008467dc:     	lsr	x8, x23, #24
1008467e0:     	strb	w8, [sp, #0x4b]
1008467e4:     	cmp	x1, #0x4
1008467e8:     	b.eq	0x1008467fc <_js_json_stringify_full+0x8bc>
1008467ec:     	lsr	x8, x23, #32
1008467f0:     	strb	w8, [sp, #0x4c]
1008467f4:     	cmp	x1, #0x5
1008467f8:     	b.ne	0x100847bbc <_js_json_stringify_full+0x1c7c>
1008467fc:     	add	x8, sp, #0x80
100846800:     	add	x0, sp, #0x48
100846804:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100846808:     	ldr	w8, [sp, #0x80]
10084680c:     	ldp	x9, x22, [sp, #0x88]
100846810:     	cmp	w8, #0x0
100846814:     	csinc	x23, x9, xzr, eq
100846818:     	csel	x25, xzr, x22, ne
10084681c:     	tbz	x25, #0x3f, 0x10084695c <_js_json_stringify_full+0xa1c>
100846820:     	mov	x0, #0x0                ; =0
100846824:     	mov	x1, x22
100846828:     	bl	0x100b12d40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084682c:     	add	x8, x20, #0x3
100846830:     	cmp	x23, x8
100846834:     	b.eq	0x10084675c <_js_json_stringify_full+0x81c>
100846838:     	fmov	d0, x23
10084683c:     	fcvtzu	x8, d0
100846840:     	mov	w9, #0xa                ; =10
100846844:     	cmp	x8, #0xa
100846848:     	csel	x3, x8, x9, lo
10084684c:     	adrp	x1, 0x100c44000 <_PERRY_EMPTY_STRING+0x2074>
100846850:     	add	x1, x1, #0x11c
100846854:     	add	x0, sp, #0x80
100846858:     	mov	w2, #0x1                ; =1
10084685c:     	bl	0x1002305f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
100846860:     	ldr	x22, [sp, #0x90]
100846864:     	str	x22, [sp, #0x20]
100846868:     	ldr	q0, [sp, #0x80]
10084686c:     	str	q0, [sp, #0x10]
100846870:     	b	0x100846a24 <_js_json_stringify_full+0xae4>
100846874:     	ldr	w22, [x8, #0x4]
100846878:     	add	x9, x8, #0x14
10084687c:     	mov	x14, #0x0               ; =0
100846880:     	mov	x8, #0x0                ; =0
100846884:     	cmp	x9, #0x0
100846888:     	csel	x24, xzr, x22, eq
10084688c:     	csinc	x23, x9, xzr, ne
100846890:     	add	x9, x23, x24
100846894:     	mov	w10, #0x1               ; =1
100846898:     	mov	x11, x23
10084689c:     	b	0x1008468cc <_js_json_stringify_full+0x98c>
1008468a0:     	add	x12, x11, #0x2
1008468a4:     	bfi	w15, w13, #6, #5
1008468a8:     	mov	x13, x15
1008468ac:     	sub	x11, x25, x11
1008468b0:     	add	x14, x11, x12
1008468b4:     	cmp	w13, #0x10, lsl #12     ; =0x10000
1008468b8:     	cinc	x11, x10, hs
1008468bc:     	add	x8, x11, x8
1008468c0:     	mov	x11, x12
1008468c4:     	cmp	x8, #0xa
1008468c8:     	b.hi	0x100846984 <_js_json_stringify_full+0xa44>
1008468cc:     	cmp	x11, x9
1008468d0:     	b.eq	0x100846934 <_js_json_stringify_full+0x9f4>
1008468d4:     	mov	x25, x14
1008468d8:     	mov	x12, x11
1008468dc:     	ldrsb	w14, [x12], #0x1
1008468e0:     	and	w13, w14, #0xff
1008468e4:     	tbz	w14, #0x1f, 0x1008468ac <_js_json_stringify_full+0x96c>
1008468e8:     	ldrb	w12, [x11, #0x1]
1008468ec:     	and	w15, w12, #0x3f
1008468f0:     	cmp	w13, #0xe0
1008468f4:     	b.lo	0x1008468a0 <_js_json_stringify_full+0x960>
1008468f8:     	and	w14, w13, #0x1f
1008468fc:     	ldrb	w12, [x11, #0x2]
100846900:     	and	w12, w12, #0x3f
100846904:     	orr	w15, w12, w15, lsl #6
100846908:     	cmp	w13, #0xf0
10084690c:     	b.lo	0x100846928 <_js_json_stringify_full+0x9e8>
100846910:     	add	x12, x11, #0x4
100846914:     	ldrb	w13, [x11, #0x3]
100846918:     	and	w13, w13, #0x3f
10084691c:     	orr	w13, w13, w15, lsl #6
100846920:     	bfi	w13, w14, #18, #3
100846924:     	b	0x1008468ac <_js_json_stringify_full+0x96c>
100846928:     	add	x12, x11, #0x3
10084692c:     	orr	w13, w15, w14, lsl #12
100846930:     	b	0x1008468ac <_js_json_stringify_full+0x96c>
100846934:     	cbz	x24, 0x1008469b8 <_js_json_stringify_full+0xa78>
100846938:     	mov	x0, x24
10084693c:     	mov	w1, #0x1                ; =1
100846940:     	bl	0x100b5fc48 <_mi_malloc_aligned>
100846944:     	cbz	x0, 0x100847ba4 <_js_json_stringify_full+0x1c64>
100846948:     	mov	x26, x0
10084694c:     	mov	x1, x23
100846950:     	mov	x2, x24
100846954:     	bl	0x100b6286c <_writev+0x100b6286c>
100846958:     	b	0x1008469c0 <_js_json_stringify_full+0xa80>
10084695c:     	cbz	x25, 0x100846a14 <_js_json_stringify_full+0xad4>
100846960:     	mov	x0, x25
100846964:     	mov	w1, #0x1                ; =1
100846968:     	bl	0x100b5fc48 <_mi_malloc_aligned>
10084696c:     	cbz	x0, 0x100847bb0 <_js_json_stringify_full+0x1c70>
100846970:     	mov	x24, x0
100846974:     	mov	x1, x23
100846978:     	mov	x2, x25
10084697c:     	bl	0x100b6286c <_writev+0x100b6286c>
100846980:     	b	0x100846a1c <_js_json_stringify_full+0xadc>
100846984:     	cbz	x25, 0x1008469b8 <_js_json_stringify_full+0xa78>
100846988:     	cmp	x25, x24
10084698c:     	b.hs	0x100847434 <_js_json_stringify_full+0x14f4>
100846990:     	ldrsb	w8, [x23, x25]
100846994:     	cmn	w8, #0x40
100846998:     	b.ge	0x100847438 <_js_json_stringify_full+0x14f8>
10084699c:     	adrp	x4, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1008469a0:     	add	x4, x4, #0x270
1008469a4:     	mov	x0, x23
1008469a8:     	mov	x1, x24
1008469ac:     	mov	x2, #0x0                ; =0
1008469b0:     	mov	x3, x25
1008469b4:     	bl	0x100b130b8 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
1008469b8:     	mov	x22, #0x0               ; =0
1008469bc:     	mov	w26, #0x1               ; =1
1008469c0:     	stp	x22, x26, [sp, #0x10]
1008469c4:     	b	0x100846a20 <_js_json_stringify_full+0xae0>
1008469c8:     	add	x14, sp, #0x80
1008469cc:     	mov	w16, #0x5c              ; =92
1008469d0:     	strb	w16, [x14, x12]
1008469d4:     	add	x12, x12, #0x2
1008469d8:     	strb	w15, [x13, #0x1]
1008469dc:     	cmp	w10, #0x2
1008469e0:     	b.eq	0x100846144 <_js_json_stringify_full+0x204>
1008469e4:     	ldrb	w11, [x11, #0x2]
1008469e8:     	sxtb	w10, w11
1008469ec:     	cmp	w11, #0xb
1008469f0:     	b.le	0x1008474c0 <_js_json_stringify_full+0x1580>
1008469f4:     	cmp	w11, #0x21
1008469f8:     	b.gt	0x10084750c <_js_json_stringify_full+0x15cc>
1008469fc:     	cmp	w11, #0xc
100846a00:     	b.eq	0x100847598 <_js_json_stringify_full+0x1658>
100846a04:     	cmp	w11, #0xd
100846a08:     	b.ne	0x10084751c <_js_json_stringify_full+0x15dc>
100846a0c:     	mov	w10, #0x72              ; =114
100846a10:     	b	0x1008475a4 <_js_json_stringify_full+0x1664>
100846a14:     	mov	x22, #0x0               ; =0
100846a18:     	mov	w24, #0x1               ; =1
100846a1c:     	stp	x22, x24, [sp, #0x10]
100846a20:     	str	x22, [sp, #0x20]
100846a24:     	cmp	x27, #0x2
100846a28:     	b.lo	0x100846b68 <_js_json_stringify_full+0xc28>
100846a2c:     	and	x25, x21, #0xffff000000000000
100846a30:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846a34:     	cmp	x25, x8
100846a38:     	b.ne	0x100846b44 <_js_json_stringify_full+0xc04>
100846a3c:     	and	x23, x21, #0xffffffffffff
100846a40:     	cmp	x23, #0x100, lsl #12    ; =0x100000
100846a44:     	b.lo	0x100846b68 <_js_json_stringify_full+0xc28>
100846a48:     	mov	x0, x23
100846a4c:     	bl	0x10050a800 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
100846a50:     	tbnz	w0, #0x0, 0x100846b68 <_js_json_stringify_full+0xc28>
100846a54:     	lsr	x8, x23, #51
100846a58:     	cmp	x8, #0xfff
100846a5c:     	b.lo	0x100846a74 <_js_json_stringify_full+0xb34>
100846a60:     	mov	w8, #0x7ffc             ; =32764
100846a64:     	cmp	x8, x23, lsr #48
100846a68:     	b.eq	0x100846b68 <_js_json_stringify_full+0xc28>
100846a6c:     	ands	x23, x23, #0xffffffffffff
100846a70:     	b.eq	0x100846b68 <_js_json_stringify_full+0xc28>
100846a74:     	and	x8, x23, #0xfffffffffff00000
100846a78:     	lsr	x9, x23, #47
100846a7c:     	cmp	x9, #0x0
100846a80:     	ccmp	x8, #0x0, #0x4, eq
100846a84:     	b.eq	0x100846b68 <_js_json_stringify_full+0xc28>
100846a88:     	tst	x23, #0x3
100846a8c:     	ccmp	x23, #0x7, #0x0, eq
100846a90:     	b.ls	0x1008477d4 <_js_json_stringify_full+0x1894>
100846a94:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100846a98:     	ldr	x8, [x8, #0x48]
100846a9c:     	cmn	x8, #0x1
100846aa0:     	b.eq	0x100847724 <_js_json_stringify_full+0x17e4>
100846aa4:     	mrs	x9, TPIDRRO_EL0
100846aa8:     	and	x9, x9, #0xfffffffffffffff8
100846aac:     	ldr	x0, [x9, x8, lsl #3]
100846ab0:     	cbz	x0, 0x100847724 <_js_json_stringify_full+0x17e4>
100846ab4:     	lsr	x1, x23, #20
100846ab8:     	ldr	x8, [x0, #0x10]
100846abc:     	ldrb	w9, [x8]
100846ac0:     	cmp	w9, #0x2
100846ac4:     	b.ne	0x10084773c <_js_json_stringify_full+0x17fc>
100846ac8:     	ldrb	w9, [x8, #0x88]
100846acc:     	tbz	w9, #0x0, 0x100846aec <_js_json_stringify_full+0xbac>
100846ad0:     	ldr	x9, [x8, #0x80]
100846ad4:     	cmp	x9, x1
100846ad8:     	b.ne	0x100846aec <_js_json_stringify_full+0xbac>
100846adc:     	ldp	x9, x10, [x8, #0x60]
100846ae0:     	cmp	x9, x23
100846ae4:     	ccmp	x10, x23, #0x0, ls
100846ae8:     	b.hi	0x10084771c <_js_json_stringify_full+0x17dc>
100846aec:     	ldrb	w9, [x8, #0xb8]
100846af0:     	cbz	w9, 0x100846b10 <_js_json_stringify_full+0xbd0>
100846af4:     	ldr	x9, [x8, #0xb0]
100846af8:     	cmp	x9, x1
100846afc:     	b.ne	0x100846b10 <_js_json_stringify_full+0xbd0>
100846b00:     	ldp	x9, x10, [x8, #0x90]
100846b04:     	cmp	x9, x23
100846b08:     	ccmp	x10, x23, #0x0, ls
100846b0c:     	b.hi	0x1008479a4 <_js_json_stringify_full+0x1a64>
100846b10:     	ldrb	w9, [x8, #0xe8]
100846b14:     	cbz	w9, 0x10084755c <_js_json_stringify_full+0x161c>
100846b18:     	ldr	x9, [x8, #0xe0]
100846b1c:     	cmp	x9, x1
100846b20:     	b.ne	0x10084755c <_js_json_stringify_full+0x161c>
100846b24:     	ldr	x9, [x8, #0xc0]
100846b28:     	cmp	x9, x23
100846b2c:     	b.hi	0x10084755c <_js_json_stringify_full+0x161c>
100846b30:     	ldr	x9, [x8, #0xc8]
100846b34:     	cmp	x9, x23
100846b38:     	b.ls	0x10084755c <_js_json_stringify_full+0x161c>
100846b3c:     	add	x9, x8, #0xc0
100846b40:     	b	0x1008479a8 <_js_json_stringify_full+0x1a68>
100846b44:     	lsr	x8, x21, #52
100846b48:     	cbnz	x8, 0x100846b68 <_js_json_stringify_full+0xc28>
100846b4c:     	cbz	x21, 0x100846b68 <_js_json_stringify_full+0xc28>
100846b50:     	and	x8, x21, #0x7
100846b54:     	cbnz	x8, 0x100846b68 <_js_json_stringify_full+0xc28>
100846b58:     	mov	x0, x21
100846b5c:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846b60:     	mov	x23, x21
100846b64:     	cbnz	w0, 0x100846a40 <_js_json_stringify_full+0xb00>
100846b68:     	mov	x25, #-0x1              ; =-1
100846b6c:     	str	x25, [sp, #0x30]
100846b70:     	mov	w24, #0x1               ; =1
100846b74:     	cmp	x27, #0x1
100846b78:     	cset	w8, hi
100846b7c:     	tst	w8, w24
100846b80:     	b.eq	0x100846bf4 <_js_json_stringify_full+0xcb4>
100846b84:     	and	x23, x21, #0xffff000000000000
100846b88:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846b8c:     	cmp	x23, x8
100846b90:     	b.ne	0x100846bcc <_js_json_stringify_full+0xc8c>
100846b94:     	and	x8, x21, #0xffffffffffff
100846b98:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846b9c:     	b.lo	0x100846bf4 <_js_json_stringify_full+0xcb4>
100846ba0:     	ldr	w8, [x8, #0xc]
100846ba4:     	mov	w9, #0x4f53             ; =20307
100846ba8:     	movk	w9, #0x434c, lsl #16
100846bac:     	cmp	w8, w9
100846bb0:     	b.ne	0x100846bf4 <_js_json_stringify_full+0xcb4>
100846bb4:     	and	x8, x21, #0xffffffffffff
100846bb8:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846bbc:     	cmp	x23, x9
100846bc0:     	csel	x28, x8, x21, eq
100846bc4:     	mov	w27, #0x1               ; =1
100846bc8:     	b	0x100846bf8 <_js_json_stringify_full+0xcb8>
100846bcc:     	lsr	x8, x21, #52
100846bd0:     	cbnz	x8, 0x100846bf4 <_js_json_stringify_full+0xcb4>
100846bd4:     	mov	w27, #0x0               ; =0
100846bd8:     	cbz	x21, 0x100846bf8 <_js_json_stringify_full+0xcb8>
100846bdc:     	and	x8, x21, #0x7
100846be0:     	cbnz	x8, 0x100846bf8 <_js_json_stringify_full+0xcb8>
100846be4:     	mov	x0, x21
100846be8:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846bec:     	mov	x8, x21
100846bf0:     	tbnz	w0, #0x0, 0x100846b98 <_js_json_stringify_full+0xc58>
100846bf4:     	mov	w27, #0x0               ; =0
100846bf8:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846bfc:     	add	x0, x0, #0xd78
100846c00:     	ldr	x8, [x0]
100846c04:     	blr	x8
100846c08:     	mov	x21, x0
100846c0c:     	ldr	w26, [x0]
100846c10:     	add	w8, w26, #0x1
100846c14:     	str	w8, [x0]
100846c18:     	cbz	w26, 0x100846c88 <_js_json_stringify_full+0xd48>
100846c1c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846c20:     	add	x0, x0, #0xd00
100846c24:     	ldr	x8, [x0]
100846c28:     	blr	x8
100846c2c:     	ldrb	w8, [x0, #0x20]
100846c30:     	cmp	w8, #0x1
100846c34:     	b.ne	0x100847a14 <_js_json_stringify_full+0x1ad4>
100846c38:     	ldr	x8, [x0]
100846c3c:     	cbnz	x8, 0x100847a20 <_js_json_stringify_full+0x1ae0>
100846c40:     	mov	x8, #-0x1               ; =-1
100846c44:     	str	x8, [x0]
100846c48:     	ldr	x23, [x0, #0x18]
100846c4c:     	ldr	x8, [x0, #0x8]
100846c50:     	cmp	x23, x8
100846c54:     	b.eq	0x100847410 <_js_json_stringify_full+0x14d0>
100846c58:     	ldr	x8, [x0, #0x10]
100846c5c:     	mov	w9, #0x18               ; =24
100846c60:     	madd	x8, x23, x9, x8
100846c64:     	mov	w9, #0x8                ; =8
100846c68:     	stp	xzr, x9, [x8]
100846c6c:     	str	xzr, [x8, #0x10]
100846c70:     	add	x8, x23, #0x1
100846c74:     	str	x8, [x0, #0x18]
100846c78:     	ldr	x8, [x0]
100846c7c:     	add	x8, x8, #0x1
100846c80:     	str	x8, [x0]
100846c84:     	b	0x100846cf0 <_js_json_stringify_full+0xdb0>
100846c88:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846c8c:     	add	x0, x0, #0xdc0
100846c90:     	ldr	x8, [x0]
100846c94:     	blr	x8
100846c98:     	strb	wzr, [x0]
100846c9c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846ca0:     	add	x0, x0, #0xdf0
100846ca4:     	ldr	x8, [x0]
100846ca8:     	blr	x8
100846cac:     	strb	wzr, [x0]
100846cb0:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100846cb4:     	ldr	w23, [x8, #0x5a8]
100846cb8:     	cmp	w23, #0x300
100846cbc:     	b.hs	0x100847458 <_js_json_stringify_full+0x1518>
100846cc0:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100846cc4:     	ldr	x8, [x8, #0x48]
100846cc8:     	cmn	x8, #0x1
100846ccc:     	b.eq	0x100847448 <_js_json_stringify_full+0x1508>
100846cd0:     	mrs	x9, TPIDRRO_EL0
100846cd4:     	and	x9, x9, #0xfffffffffffffff8
100846cd8:     	ldr	x0, [x9, x8, lsl #3]
100846cdc:     	cbz	x0, 0x100847448 <_js_json_stringify_full+0x1508>
100846ce0:     	add	x8, x0, x23, lsl #3
100846ce4:     	ldr	x0, [x8, #0x1e8]
100846ce8:     	cbz	x0, 0x100847458 <_js_json_stringify_full+0x1518>
100846cec:     	str	xzr, [x0]
100846cf0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846cf4:     	add	x0, x0, #0xd30
100846cf8:     	ldr	x8, [x0]
100846cfc:     	blr	x8
100846d00:     	mov	x23, x0
100846d04:     	ldrb	w8, [x0, #0x18]
100846d08:     	cmp	w8, #0x1
100846d0c:     	b.ne	0x1008479c8 <_js_json_stringify_full+0x1a88>
100846d10:     	ldr	x8, [x0]
100846d14:     	mov	x9, #-0x1               ; =-1
100846d18:     	str	x9, [x0]
100846d1c:     	cmn	x8, #0x2
100846d20:     	b.eq	0x100847b50 <_js_json_stringify_full+0x1c10>
100846d24:     	cmn	x8, #0x1
100846d28:     	b.eq	0x100846dfc <_js_json_stringify_full+0xebc>
100846d2c:     	add	x9, sp, #0x48
100846d30:     	ldur	q0, [x0, #0x8]
100846d34:     	stur	q0, [x9, #0x8]
100846d38:     	str	x8, [sp, #0x48]
100846d3c:     	tbz	w24, #0x0, 0x100846e10 <_js_json_stringify_full+0xed0>
100846d40:     	tbz	w27, #0x0, 0x100846ef8 <_js_json_stringify_full+0xfb8>
100846d44:     	bl	0x10028b418 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100846d48:     	str	x0, [sp, #0x60]
100846d4c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846d50:     	stp	x28, x8, [sp, #0x88]
100846d54:     	mov	w8, #0x1                ; =1
100846d58:     	str	x8, [sp, #0x80]
100846d5c:     	add	x0, sp, #0x80
100846d60:     	bl	0x10028b520 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100846d64:     	mov	x22, x0
100846d68:     	str	x0, [sp, #0x68]
100846d6c:     	mov	w0, #0x0                ; =0
100846d70:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846d74:     	stp	xzr, xzr, [x0]
100846d78:     	str	wzr, [x0, #0x10]
100846d7c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846d80:     	bfxil	x8, x0, #0, #48
100846d84:     	fmov	d0, x8
100846d88:     	bl	0x10020b124 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
100846d8c:     	mov	x19, x0
100846d90:     	adrp	x24, 0x100f80000 <_perry_global_worker_ts__1>
100846d94:     	ldr	x8, [x24, #0x48]
100846d98:     	cmn	x8, #0x1
100846d9c:     	b.eq	0x100846f5c <_js_json_stringify_full+0x101c>
100846da0:     	mrs	x9, TPIDRRO_EL0
100846da4:     	and	x9, x9, #0xfffffffffffffff8
100846da8:     	ldr	x8, [x9, x8, lsl #3]
100846dac:     	cbz	x8, 0x100846f5c <_js_json_stringify_full+0x101c>
100846db0:     	ldr	x8, [x8, #0x19e8]
100846db4:     	cbz	x8, 0x100846f5c <_js_json_stringify_full+0x101c>
100846db8:     	ldr	x9, [x8]
100846dbc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846dc0:     	cmp	x9, x10
100846dc4:     	b.hs	0x100847a9c <_js_json_stringify_full+0x1b5c>
100846dc8:     	add	x10, x9, #0x1
100846dcc:     	str	x10, [x8]
100846dd0:     	ldr	x10, [x8, #0x18]
100846dd4:     	cmp	x19, x10
100846dd8:     	b.hs	0x100847aa8 <_js_json_stringify_full+0x1b68>
100846ddc:     	ldr	x10, [x8, #0x10]
100846de0:     	mov	w11, #0x18              ; =24
100846de4:     	madd	x10, x19, x11, x10
100846de8:     	ldr	x11, [x10]
100846dec:     	cbnz	x11, 0x100847b08 <_js_json_stringify_full+0x1bc8>
100846df0:     	ldr	x0, [x10, #0x8]
100846df4:     	str	x9, [x8]
100846df8:     	b	0x100846f64 <_js_json_stringify_full+0x1024>
100846dfc:     	mov	x8, #0x0                ; =0
100846e00:     	mov	w9, #0x1                ; =1
100846e04:     	stp	x9, xzr, [sp, #0x50]
100846e08:     	str	x8, [sp, #0x48]
100846e0c:     	tbnz	w24, #0x0, 0x100846d40 <_js_json_stringify_full+0xe00>
100846e10:     	cmp	x22, #0x0
100846e14:     	cset	w6, ne
100846e18:     	ldp	x0, x1, [sp, #0x38]
100846e1c:     	ldp	x3, x4, [sp, #0x18]
100846e20:     	add	x2, sp, #0x48
100846e24:     	mov.16b	v0, v8
100846e28:     	mov	x5, #0x0                ; =0
100846e2c:     	bl	0x100502e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
100846e30:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846e34:     	add	x0, x0, #0xd90
100846e38:     	ldr	x8, [x0]
100846e3c:     	blr	x8
100846e40:     	ldrb	w8, [x0, #0x20]
100846e44:     	cbnz	w8, 0x100847a2c <_js_json_stringify_full+0x1aec>
100846e48:     	ldr	x8, [x0]
100846e4c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100846e50:     	cmp	x8, x9
100846e54:     	b.hs	0x100847a5c <_js_json_stringify_full+0x1b1c>
100846e58:     	ldr	x9, [x0, #0x18]
100846e5c:     	cbz	x9, 0x100846e68 <_js_json_stringify_full+0xf28>
100846e60:     	cbnz	x8, 0x100847a68 <_js_json_stringify_full+0x1b28>
100846e64:     	str	xzr, [x0, #0x18]
100846e68:     	ldp	x0, x1, [sp, #0x50]
100846e6c:     	cmp	x1, #0x5
100846e70:     	b.hi	0x100846ed8 <_js_json_stringify_full+0xf98>
100846e74:     	cbz	x1, 0x1008470e8 <_js_json_stringify_full+0x11a8>
100846e78:     	ldrsb	w8, [x0]
100846e7c:     	tbnz	w8, #0x1f, 0x100846ed8 <_js_json_stringify_full+0xf98>
100846e80:     	cmp	x1, #0x1
100846e84:     	b.eq	0x100846ec0 <_js_json_stringify_full+0xf80>
100846e88:     	ldrsb	w8, [x0, #0x1]
100846e8c:     	tbnz	w8, #0x1f, 0x100846ed8 <_js_json_stringify_full+0xf98>
100846e90:     	cmp	x1, #0x2
100846e94:     	b.eq	0x100846ec0 <_js_json_stringify_full+0xf80>
100846e98:     	ldrsb	w8, [x0, #0x2]
100846e9c:     	tbnz	w8, #0x1f, 0x100846ed8 <_js_json_stringify_full+0xf98>
100846ea0:     	cmp	x1, #0x3
100846ea4:     	b.eq	0x100846ec0 <_js_json_stringify_full+0xf80>
100846ea8:     	ldrsb	w8, [x0, #0x3]
100846eac:     	tbnz	w8, #0x1f, 0x100846ed8 <_js_json_stringify_full+0xf98>
100846eb0:     	cmp	x1, #0x4
100846eb4:     	b.eq	0x100846ec0 <_js_json_stringify_full+0xf80>
100846eb8:     	ldrsb	w8, [x0, #0x4]
100846ebc:     	tbnz	w8, #0x1f, 0x100846ed8 <_js_json_stringify_full+0xf98>
100846ec0:     	cmp	x1, #0x4
100846ec4:     	b.hs	0x100847228 <_js_json_stringify_full+0x12e8>
100846ec8:     	mov	x10, #0x0               ; =0
100846ecc:     	mov	x9, #0x0                ; =0
100846ed0:     	mov	x8, x0
100846ed4:     	b	0x1008472b8 <_js_json_stringify_full+0x1378>
100846ed8:     	bl	0x100329e88 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
100846edc:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100846ee0:     	bfxil	x20, x0, #0, #48
100846ee4:     	ldp	x22, x0, [sp, #0x48]
100846ee8:     	ldrb	w8, [x23, #0x18]
100846eec:     	cmp	w8, #0x1
100846ef0:     	b.eq	0x1008472f4 <_js_json_stringify_full+0x13b4>
100846ef4:     	b	0x1008479f8 <_js_json_stringify_full+0x1ab8>
100846ef8:     	mov	w0, #0x0                ; =0
100846efc:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100846f00:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846f04:     	bfxil	x8, x0, #0, #48
100846f08:     	fmov	d1, x8
100846f0c:     	stp	xzr, xzr, [x0]
100846f10:     	str	wzr, [x0, #0x10]
100846f14:     	mov.16b	v0, v8
100846f18:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846f1c:     	mov.16b	v8, v0
100846f20:     	fmov	x24, d8
100846f24:     	cmp	x24, x20
100846f28:     	b.eq	0x100847170 <_js_json_stringify_full+0x1230>
100846f2c:     	mov	w8, #0x7ffd             ; =32765
100846f30:     	cmp	x8, x24, lsr #48
100846f34:     	b.ne	0x100847140 <_js_json_stringify_full+0x1200>
100846f38:     	and	x8, x24, #0xffffffffffff
100846f3c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846f40:     	b.lo	0x100847164 <_js_json_stringify_full+0x1224>
100846f44:     	ldr	w8, [x8, #0xc]
100846f48:     	mov	w9, #0x4f53             ; =20307
100846f4c:     	movk	w9, #0x434c, lsl #16
100846f50:     	cmp	w8, w9
100846f54:     	b.ne	0x100847164 <_js_json_stringify_full+0x1224>
100846f58:     	b	0x100847170 <_js_json_stringify_full+0x1230>
100846f5c:     	mov	x0, x19
100846f60:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100846f64:     	fmov	d1, x0
100846f68:     	mov.16b	v0, v8
100846f6c:     	bl	0x1004ff8fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100846f70:     	mov.16b	v8, v0
100846f74:     	ldr	x8, [x24, #0x48]
100846f78:     	cmn	x8, #0x1
100846f7c:     	b.eq	0x100846fe0 <_js_json_stringify_full+0x10a0>
100846f80:     	mrs	x9, TPIDRRO_EL0
100846f84:     	and	x9, x9, #0xfffffffffffffff8
100846f88:     	ldr	x8, [x9, x8, lsl #3]
100846f8c:     	cbz	x8, 0x100846fe0 <_js_json_stringify_full+0x10a0>
100846f90:     	ldr	x8, [x8, #0x19e8]
100846f94:     	cbz	x8, 0x100846fe0 <_js_json_stringify_full+0x10a0>
100846f98:     	ldr	x9, [x8]
100846f9c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100846fa0:     	cmp	x9, x10
100846fa4:     	b.hs	0x100847a9c <_js_json_stringify_full+0x1b5c>
100846fa8:     	add	x10, x9, #0x1
100846fac:     	str	x10, [x8]
100846fb0:     	ldr	x10, [x8, #0x18]
100846fb4:     	cmp	x22, x10
100846fb8:     	b.hs	0x100847aa8 <_js_json_stringify_full+0x1b68>
100846fbc:     	ldr	x10, [x8, #0x10]
100846fc0:     	mov	w11, #0x18              ; =24
100846fc4:     	madd	x10, x22, x11, x10
100846fc8:     	ldr	x11, [x10]
100846fcc:     	cmp	x11, #0x1
100846fd0:     	b.ne	0x100847b68 <_js_json_stringify_full+0x1c28>
100846fd4:     	ldr	x22, [x10, #0x8]
100846fd8:     	str	x9, [x8]
100846fdc:     	b	0x100846fec <_js_json_stringify_full+0x10ac>
100846fe0:     	mov	x0, x22
100846fe4:     	bl	0x10013c298 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100846fe8:     	mov	x22, x0
100846fec:     	ldr	x8, [x24, #0x48]
100846ff0:     	cmn	x8, #0x1
100846ff4:     	b.eq	0x100847054 <_js_json_stringify_full+0x1114>
100846ff8:     	mrs	x9, TPIDRRO_EL0
100846ffc:     	and	x9, x9, #0xfffffffffffffff8
100847000:     	ldr	x8, [x9, x8, lsl #3]
100847004:     	cbz	x8, 0x100847054 <_js_json_stringify_full+0x1114>
100847008:     	ldr	x8, [x8, #0x19e8]
10084700c:     	cbz	x8, 0x100847054 <_js_json_stringify_full+0x1114>
100847010:     	ldr	x9, [x8]
100847014:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100847018:     	cmp	x9, x10
10084701c:     	b.hs	0x100847a9c <_js_json_stringify_full+0x1b5c>
100847020:     	add	x10, x9, #0x1
100847024:     	str	x10, [x8]
100847028:     	ldr	x10, [x8, #0x18]
10084702c:     	cmp	x19, x10
100847030:     	b.hs	0x100847aa8 <_js_json_stringify_full+0x1b68>
100847034:     	ldr	x10, [x8, #0x10]
100847038:     	mov	w11, #0x18              ; =24
10084703c:     	madd	x10, x19, x11, x10
100847040:     	ldr	x11, [x10]
100847044:     	cbnz	x11, 0x100847b08 <_js_json_stringify_full+0x1bc8>
100847048:     	ldr	x0, [x10, #0x8]
10084704c:     	str	x9, [x8]
100847050:     	b	0x10084705c <_js_json_stringify_full+0x111c>
100847054:     	mov	x0, x19
100847058:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
10084705c:     	fmov	d9, x0
100847060:     	mov.16b	v0, v8
100847064:     	bl	0x1004ff434 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100847068:     	mov.16b	v2, v0
10084706c:     	mov	x0, x22
100847070:     	mov.16b	v0, v9
100847074:     	mov.16b	v1, v8
100847078:     	bl	0x1004ff714 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
10084707c:     	str	d0, [sp, #0x70]
100847080:     	fmov	x19, d0
100847084:     	cmp	x19, x20
100847088:     	b.ne	0x1008470f0 <_js_json_stringify_full+0x11b0>
10084708c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847090:     	add	x0, x0, #0xd90
100847094:     	ldr	x8, [x0]
100847098:     	blr	x8
10084709c:     	ldrb	w8, [x0, #0x20]
1008470a0:     	cbnz	w8, 0x100847b48 <_js_json_stringify_full+0x1c08>
1008470a4:     	ldr	x8, [x0]
1008470a8:     	cbnz	x8, 0x100847b98 <_js_json_stringify_full+0x1c58>
1008470ac:     	str	xzr, [x0, #0x18]
1008470b0:     	ldp	x22, x19, [sp, #0x48]
1008470b4:     	ldrb	w8, [x23, #0x18]
1008470b8:     	cmp	w8, #0x1
1008470bc:     	b.ne	0x100847ae0 <_js_json_stringify_full+0x1ba0>
1008470c0:     	ldp	x8, x0, [x23]
1008470c4:     	stp	x22, x19, [x23]
1008470c8:     	str	xzr, [x23, #0x10]
1008470cc:     	sub	x8, x8, #0x1
1008470d0:     	cmn	x8, #0x2
1008470d4:     	b.hs	0x1008470dc <_js_json_stringify_full+0x119c>
1008470d8:     	bl	0x100b5f9c0 <_mi_free>
1008470dc:     	cbz	w26, 0x10084737c <_js_json_stringify_full+0x143c>
1008470e0:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
1008470e4:     	b	0x100847380 <_js_json_stringify_full+0x1440>
1008470e8:     	mov	x10, #0x0               ; =0
1008470ec:     	b	0x1008472d8 <_js_json_stringify_full+0x1398>
1008470f0:     	add	x0, sp, #0x48
1008470f4:     	bl	0x100500470 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
1008470f8:     	tbnz	w0, #0x0, 0x100847134 <_js_json_stringify_full+0x11f4>
1008470fc:     	mov	x0, x19
100847100:     	bl	0x100327dec <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
100847104:     	cmp	x0, #0x1
100847108:     	b.ne	0x100847b5c <_js_json_stringify_full+0x1c1c>
10084710c:     	add	x8, sp, #0x78
100847110:     	add	x9, sp, #0x70
100847114:     	stp	x1, x8, [sp, #0x78]
100847118:     	str	x9, [sp, #0x88]
10084711c:     	add	x8, sp, #0x48
100847120:     	add	x9, sp, #0x10
100847124:     	stp	x8, x9, [sp, #0x90]
100847128:     	add	x0, sp, #0x68
10084712c:     	add	x1, sp, #0x80
100847130:     	bl	0x100143d90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
100847134:     	add	x0, sp, #0x60
100847138:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
10084713c:     	b	0x100846e30 <_js_json_stringify_full+0xef0>
100847140:     	lsr	x8, x24, #52
100847144:     	cbnz	x8, 0x100847164 <_js_json_stringify_full+0x1224>
100847148:     	cbz	x24, 0x100847164 <_js_json_stringify_full+0x1224>
10084714c:     	and	x8, x24, #0x7
100847150:     	cbnz	x8, 0x100847164 <_js_json_stringify_full+0x1224>
100847154:     	mov	x0, x24
100847158:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084715c:     	mov	x8, x24
100847160:     	tbnz	w0, #0x0, 0x100846f3c <_js_json_stringify_full+0xffc>
100847164:     	mov	x0, x24
100847168:     	bl	0x100509664 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
10084716c:     	tbz	w0, #0x0, 0x1008471fc <_js_json_stringify_full+0x12bc>
100847170:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847174:     	add	x0, x0, #0xd90
100847178:     	ldr	x8, [x0]
10084717c:     	blr	x8
100847180:     	ldrb	w8, [x0, #0x20]
100847184:     	cbnz	w8, 0x100847aac <_js_json_stringify_full+0x1b6c>
100847188:     	ldr	x8, [x0]
10084718c:     	cbnz	x8, 0x100847ad4 <_js_json_stringify_full+0x1b94>
100847190:     	str	xzr, [x0, #0x18]
100847194:     	ldp	x22, x19, [sp, #0x48]
100847198:     	ldrb	w8, [x23, #0x18]
10084719c:     	cmp	w8, #0x1
1008471a0:     	b.ne	0x100847a88 <_js_json_stringify_full+0x1b48>
1008471a4:     	ldp	x8, x0, [x23]
1008471a8:     	stp	x22, x19, [x23]
1008471ac:     	str	xzr, [x23, #0x10]
1008471b0:     	sub	x8, x8, #0x1
1008471b4:     	cmn	x8, #0x2
1008471b8:     	b.hs	0x1008471c0 <_js_json_stringify_full+0x1280>
1008471bc:     	bl	0x100b5f9c0 <_mi_free>
1008471c0:     	cbz	w26, 0x1008471e0 <_js_json_stringify_full+0x12a0>
1008471c4:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
1008471c8:     	ldr	w8, [x21]
1008471cc:     	sub	w8, w8, #0x1
1008471d0:     	str	w8, [x21]
1008471d4:     	cmn	x25, #0x1
1008471d8:     	b.ne	0x10084739c <_js_json_stringify_full+0x145c>
1008471dc:     	b	0x1008473d8 <_js_json_stringify_full+0x1498>
1008471e0:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
1008471e4:     	ldr	w8, [x21]
1008471e8:     	sub	w8, w8, #0x1
1008471ec:     	str	w8, [x21]
1008471f0:     	cmn	x25, #0x1
1008471f4:     	b.ne	0x10084739c <_js_json_stringify_full+0x145c>
1008471f8:     	b	0x1008473d8 <_js_json_stringify_full+0x1498>
1008471fc:     	cmp	x19, x24
100847200:     	b.eq	0x10084720c <_js_json_stringify_full+0x12cc>
100847204:     	mov.16b	v0, v8
100847208:     	bl	0x10050ea2c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
10084720c:     	cbz	x22, 0x100847468 <_js_json_stringify_full+0x1528>
100847210:     	ldp	x1, x2, [sp, #0x18]
100847214:     	add	x0, sp, #0x48
100847218:     	mov.16b	v0, v8
10084721c:     	mov	x3, #0x0                ; =0
100847220:     	bl	0x100500ee8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
100847224:     	b	0x100847478 <_js_json_stringify_full+0x1538>
100847228:     	and	x9, x1, #0x4
10084722c:     	add	x8, x0, x9
100847230:     	adrp	x10, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5430>
100847234:     	ldr	q0, [x10, #0x440]
100847238:     	adrp	x10, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33c3a>
10084723c:     	ldr	q2, [x10, #0x340]
100847240:     	movi.2d	v1, #0000000000000000
100847244:     	movi.2d	v3, #0x000000000000ff
100847248:     	mov	w10, #0x4               ; =4
10084724c:     	dup.2d	v4, x10
100847250:     	mov	x10, x0
100847254:     	and	x11, x1, #0x4
100847258:     	movi.2d	v5, #0000000000000000
10084725c:     	ldr	s6, [x10], #0x4
100847260:     	ushll.8h	v6, v6, #0x0
100847264:     	ushll.4s	v6, v6, #0x0
100847268:     	ushll2.2d	v7, v6, #0x0
10084726c:     	and.16b	v7, v7, v3
100847270:     	ushll.2d	v6, v6, #0x0
100847274:     	and.16b	v6, v6, v3
100847278:     	shl.2d	v16, v0, #0x3
10084727c:     	shl.2d	v17, v2, #0x3
100847280:     	ushl.2d	v6, v6, v17
100847284:     	ushl.2d	v7, v7, v16
100847288:     	orr.16b	v1, v7, v1
10084728c:     	orr.16b	v5, v6, v5
100847290:     	add.2d	v0, v0, v4
100847294:     	add.2d	v2, v2, v4
100847298:     	subs	x11, x11, #0x4
10084729c:     	b.ne	0x10084725c <_js_json_stringify_full+0x131c>
1008472a0:     	orr.16b	v0, v5, v1
1008472a4:     	mov	d1, v0[1]
1008472a8:     	orr.8b	v0, v0, v1
1008472ac:     	fmov	x10, d0
1008472b0:     	cmp	x1, x9
1008472b4:     	b.eq	0x1008472d8 <_js_json_stringify_full+0x1398>
1008472b8:     	add	x11, x0, x1
1008472bc:     	lsl	x9, x9, #3
1008472c0:     	ldrb	w12, [x8], #0x1
1008472c4:     	lsl	x12, x12, x9
1008472c8:     	orr	x10, x12, x10
1008472cc:     	add	x9, x9, #0x8
1008472d0:     	cmp	x8, x11
1008472d4:     	b.ne	0x1008472c0 <_js_json_stringify_full+0x1380>
1008472d8:     	orr	x8, x10, x1, lsl #40
1008472dc:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008472e0:     	orr	x20, x8, x9
1008472e4:     	ldr	x22, [sp, #0x48]
1008472e8:     	ldrb	w8, [x23, #0x18]
1008472ec:     	cmp	w8, #0x1
1008472f0:     	b.ne	0x1008479f8 <_js_json_stringify_full+0x1ab8>
1008472f4:     	ldp	x9, x8, [x23]
1008472f8:     	stp	x22, x0, [x23]
1008472fc:     	str	xzr, [x23, #0x10]
100847300:     	sub	x9, x9, #0x1
100847304:     	cmn	x9, #0x2
100847308:     	b.hs	0x100847314 <_js_json_stringify_full+0x13d4>
10084730c:     	mov	x0, x8
100847310:     	bl	0x100b5f9c0 <_mi_free>
100847314:     	cbz	w26, 0x100847334 <_js_json_stringify_full+0x13f4>
100847318:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
10084731c:     	ldr	w8, [x21]
100847320:     	sub	w8, w8, #0x1
100847324:     	str	w8, [x21]
100847328:     	cmn	x25, #0x1
10084732c:     	b.ne	0x10084734c <_js_json_stringify_full+0x140c>
100847330:     	b	0x1008473d8 <_js_json_stringify_full+0x1498>
100847334:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100847338:     	ldr	w8, [x21]
10084733c:     	sub	w8, w8, #0x1
100847340:     	str	w8, [x21]
100847344:     	cmn	x25, #0x1
100847348:     	b.eq	0x1008473d8 <_js_json_stringify_full+0x1498>
10084734c:     	ldp	x19, x21, [sp, #0x38]
100847350:     	cbz	x21, 0x1008473cc <_js_json_stringify_full+0x148c>
100847354:     	add	x22, x19, #0x8
100847358:     	b	0x100847368 <_js_json_stringify_full+0x1428>
10084735c:     	add	x22, x22, #0x18
100847360:     	subs	x21, x21, #0x1
100847364:     	b.eq	0x1008473cc <_js_json_stringify_full+0x148c>
100847368:     	ldur	x8, [x22, #-0x8]
10084736c:     	cbz	x8, 0x10084735c <_js_json_stringify_full+0x141c>
100847370:     	ldr	x0, [x22]
100847374:     	bl	0x100b5f9c0 <_mi_free>
100847378:     	b	0x10084735c <_js_json_stringify_full+0x141c>
10084737c:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100847380:     	ldr	w8, [x21]
100847384:     	sub	w8, w8, #0x1
100847388:     	str	w8, [x21]
10084738c:     	add	x0, sp, #0x60
100847390:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100847394:     	cmn	x25, #0x1
100847398:     	b.eq	0x1008473d8 <_js_json_stringify_full+0x1498>
10084739c:     	ldp	x19, x21, [sp, #0x38]
1008473a0:     	cbz	x21, 0x1008473cc <_js_json_stringify_full+0x148c>
1008473a4:     	add	x22, x19, #0x8
1008473a8:     	b	0x1008473b8 <_js_json_stringify_full+0x1478>
1008473ac:     	add	x22, x22, #0x18
1008473b0:     	subs	x21, x21, #0x1
1008473b4:     	b.eq	0x1008473cc <_js_json_stringify_full+0x148c>
1008473b8:     	ldur	x8, [x22, #-0x8]
1008473bc:     	cbz	x8, 0x1008473ac <_js_json_stringify_full+0x146c>
1008473c0:     	ldr	x0, [x22]
1008473c4:     	bl	0x100b5f9c0 <_mi_free>
1008473c8:     	b	0x1008473ac <_js_json_stringify_full+0x146c>
1008473cc:     	cbz	x25, 0x1008473d8 <_js_json_stringify_full+0x1498>
1008473d0:     	mov	x0, x19
1008473d4:     	bl	0x100b5f9c0 <_mi_free>
1008473d8:     	ldr	x8, [sp, #0x10]
1008473dc:     	cbz	x8, 0x1008473e8 <_js_json_stringify_full+0x14a8>
1008473e0:     	ldr	x0, [sp, #0x18]
1008473e4:     	bl	0x100b5f9c0 <_mi_free>
1008473e8:     	mov	x0, x20
1008473ec:     	ldp	x29, x30, [sp, #0x110]
1008473f0:     	ldp	x20, x19, [sp, #0x100]
1008473f4:     	ldp	x22, x21, [sp, #0xf0]
1008473f8:     	ldp	x24, x23, [sp, #0xe0]
1008473fc:     	ldp	x26, x25, [sp, #0xd0]
100847400:     	ldp	x28, x27, [sp, #0xc0]
100847404:     	ldp	d9, d8, [sp, #0xb0]
100847408:     	add	sp, sp, #0x120
10084740c:     	ret
100847410:     	str	x22, [sp, #0x8]
100847414:     	mov	x22, x28
100847418:     	mov	x28, x0
10084741c:     	add	x0, x0, #0x8
100847420:     	bl	0x100b3c710 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100847424:     	mov	x0, x28
100847428:     	mov	x28, x22
10084742c:     	ldr	x22, [sp, #0x8]
100847430:     	b	0x100846c58 <_js_json_stringify_full+0xd18>
100847434:     	b.ne	0x10084699c <_js_json_stringify_full+0xa5c>
100847438:     	tbz	x25, #0x3f, 0x100847490 <_js_json_stringify_full+0x1550>
10084743c:     	mov	x0, #0x0                ; =0
100847440:     	mov	x1, x25
100847444:     	bl	0x100b12d40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847448:     	bl	0x100b3fdbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084744c:     	add	x8, x0, x23, lsl #3
100847450:     	ldr	x0, [x8, #0x1e8]
100847454:     	cbnz	x0, 0x100846cec <_js_json_stringify_full+0xdac>
100847458:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084745c:     	add	x0, x0, #0x138
100847460:     	bl	0x100b3d5dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100847464:     	b	0x100846cec <_js_json_stringify_full+0xdac>
100847468:     	add	x1, sp, #0x48
10084746c:     	mov.16b	v0, v8
100847470:     	mov	w0, #0x0                ; =0
100847474:     	bl	0x10050973c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100847478:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
10084747c:     	add	x0, x0, #0xdc0
100847480:     	ldr	x8, [x0]
100847484:     	blr	x8
100847488:     	strb	wzr, [x0]
10084748c:     	b	0x100846e30 <_js_json_stringify_full+0xef0>
100847490:     	mov	x0, x25
100847494:     	mov	w1, #0x1                ; =1
100847498:     	bl	0x100b5fc48 <_mi_malloc_aligned>
10084749c:     	mov	x26, x0
1008474a0:     	mov	w0, #0x1                ; =1
1008474a4:     	cbz	x26, 0x100847440 <_js_json_stringify_full+0x1500>
1008474a8:     	mov	x0, x26
1008474ac:     	mov	x1, x23
1008474b0:     	mov	x2, x25
1008474b4:     	bl	0x100b6286c <_writev+0x100b6286c>
1008474b8:     	mov	x22, x25
1008474bc:     	b	0x1008469c0 <_js_json_stringify_full+0xa80>
1008474c0:     	cmp	w11, #0x8
1008474c4:     	b.eq	0x100847590 <_js_json_stringify_full+0x1650>
1008474c8:     	cmp	w11, #0x9
1008474cc:     	b.eq	0x1008475a0 <_js_json_stringify_full+0x1660>
1008474d0:     	cmp	w11, #0xa
1008474d4:     	b.ne	0x10084751c <_js_json_stringify_full+0x15dc>
1008474d8:     	mov	w10, #0x6e              ; =110
1008474dc:     	b	0x1008475a4 <_js_json_stringify_full+0x1664>
1008474e0:     	mov	x22, x0
1008474e4:     	and	x0, x19, #0xffffffffffff
1008474e8:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1008474ec:     	cbz	x0, 0x1008475c8 <_js_json_stringify_full+0x1688>
1008474f0:     	ldr	w20, [x0]
1008474f4:     	cmp	w20, #0x4
1008474f8:     	b.hi	0x100846518 <_js_json_stringify_full+0x5d8>
1008474fc:     	ldr	w8, [x0, #0x4]
100847500:     	cmp	w20, w8
100847504:     	b.hi	0x100846518 <_js_json_stringify_full+0x5d8>
100847508:     	b	0x1008475cc <_js_json_stringify_full+0x168c>
10084750c:     	cmp	w11, #0x22
100847510:     	b.eq	0x1008475a4 <_js_json_stringify_full+0x1664>
100847514:     	cmp	w11, #0x5c
100847518:     	b.eq	0x1008475a4 <_js_json_stringify_full+0x1664>
10084751c:     	cmp	x12, #0x3
100847520:     	mov	w11, #0x20              ; =32
100847524:     	ccmp	w10, w11, #0x8, ls
100847528:     	b.lt	0x100846454 <_js_json_stringify_full+0x514>
10084752c:     	add	x8, sp, #0x80
100847530:     	strb	w10, [x8, x12]
100847534:     	add	x12, x12, #0x1
100847538:     	b	0x100846144 <_js_json_stringify_full+0x204>
10084753c:     	mov	x1, x0
100847540:     	and	x0, x19, #0xffffffffffff
100847544:     	mov	x22, x1
100847548:     	bl	0x1004f8e00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
10084754c:     	cmp	x0, #0x1
100847550:     	b.ne	0x100847674 <_js_json_stringify_full+0x1734>
100847554:     	mov	x20, x1
100847558:     	b	0x1008473e8 <_js_json_stringify_full+0x14a8>
10084755c:     	ldrb	w9, [x8, #0x118]
100847560:     	cbz	w9, 0x10084779c <_js_json_stringify_full+0x185c>
100847564:     	ldr	x9, [x8, #0x110]
100847568:     	cmp	x9, x1
10084756c:     	b.ne	0x10084779c <_js_json_stringify_full+0x185c>
100847570:     	ldr	x9, [x8, #0xf0]
100847574:     	cmp	x9, x23
100847578:     	b.hi	0x10084779c <_js_json_stringify_full+0x185c>
10084757c:     	ldr	x9, [x8, #0xf8]
100847580:     	cmp	x9, x23
100847584:     	b.ls	0x10084779c <_js_json_stringify_full+0x185c>
100847588:     	add	x9, x8, #0xf0
10084758c:     	b	0x1008479a8 <_js_json_stringify_full+0x1a68>
100847590:     	mov	w10, #0x62              ; =98
100847594:     	b	0x1008475a4 <_js_json_stringify_full+0x1664>
100847598:     	mov	w10, #0x66              ; =102
10084759c:     	b	0x1008475a4 <_js_json_stringify_full+0x1664>
1008475a0:     	mov	w10, #0x74              ; =116
1008475a4:     	cmp	x12, #0x2
1008475a8:     	b.hi	0x100846454 <_js_json_stringify_full+0x514>
1008475ac:     	add	x8, sp, #0x80
1008475b0:     	add	x8, x8, x12
1008475b4:     	add	x12, x12, #0x2
1008475b8:     	mov	w11, #0x5c              ; =92
1008475bc:     	strb	w11, [x8]
1008475c0:     	strb	w10, [x8, #0x1]
1008475c4:     	b	0x100846144 <_js_json_stringify_full+0x204>
1008475c8:     	mov	x20, #0x0               ; =0
1008475cc:     	ldr	w8, [x22, #0x4]
1008475d0:     	lsl	x9, x20, #3
1008475d4:     	add	x9, x9, #0x18
1008475d8:     	cmp	x9, x8
1008475dc:     	b.hi	0x100846518 <_js_json_stringify_full+0x5d8>
1008475e0:     	ldr	w8, [x25, #0x4]
1008475e4:     	mov	w9, #-0x40000000        ; =-1073741824
1008475e8:     	cmp	w8, w9
1008475ec:     	csel	w8, w8, wzr, lt
1008475f0:     	mov	x22, x0
1008475f4:     	mov	x0, x8
1008475f8:     	bl	0x1005e58a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
1008475fc:     	mov	w9, #0x2                ; =2
100847600:     	cmp	w1, #0x2
100847604:     	csel	w10, w1, w9, hi
100847608:     	tst	w0, #0x1
10084760c:     	csel	x8, x10, x9, ne
100847610:     	cmp	x20, x8
100847614:     	b.hi	0x100846518 <_js_json_stringify_full+0x5d8>
100847618:     	cbz	x20, 0x1008479d8 <_js_json_stringify_full+0x1a98>
10084761c:     	mov	x0, x22
100847620:     	mov	x1, x20
100847624:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100847628:     	tbz	w0, #0x0, 0x100846518 <_js_json_stringify_full+0x5d8>
10084762c:     	cmp	x20, #0x1
100847630:     	b.eq	0x100847a74 <_js_json_stringify_full+0x1b34>
100847634:     	cmp	x20, #0x2
100847638:     	b.ne	0x100847b30 <_js_json_stringify_full+0x1bf0>
10084763c:     	mov	x22, #0x0               ; =0
100847640:     	add	x25, x25, #0x10
100847644:     	mov	w8, #0x1                ; =1
100847648:     	mov	x26, x8
10084764c:     	ldr	x1, [x25, x22, lsl #3]
100847650:     	add	x0, sp, #0x80
100847654:     	bl	0x1004efe14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
100847658:     	ldr	w8, [sp, #0x80]
10084765c:     	cmn	w8, #0x1
100847660:     	b.ne	0x100847b18 <_js_json_stringify_full+0x1bd8>
100847664:     	mov	w8, #0x0                ; =0
100847668:     	mov	w22, #0x1               ; =1
10084766c:     	tbnz	w26, #0x0, 0x100847648 <_js_json_stringify_full+0x1708>
100847670:     	b	0x100847b30 <_js_json_stringify_full+0x1bf0>
100847674:     	and	x0, x19, #0xffffffffffff
100847678:     	bl	0x100347c40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
10084767c:     	cbz	x0, 0x100847708 <_js_json_stringify_full+0x17c8>
100847680:     	ldr	w20, [x0]
100847684:     	cbz	w20, 0x100847708 <_js_json_stringify_full+0x17c8>
100847688:     	cmp	w20, #0x8
10084768c:     	b.hi	0x1008464e4 <_js_json_stringify_full+0x5a4>
100847690:     	ldr	w8, [x0, #0x4]
100847694:     	cmp	w20, w8
100847698:     	b.hi	0x1008464e4 <_js_json_stringify_full+0x5a4>
10084769c:     	ldr	w8, [x22, #0x4]
1008476a0:     	lsl	x9, x20, #3
1008476a4:     	add	x9, x9, #0x18
1008476a8:     	cmp	x9, x8
1008476ac:     	b.hi	0x1008464e4 <_js_json_stringify_full+0x5a4>
1008476b0:     	ldr	w8, [x25, #0x4]
1008476b4:     	mov	w9, #-0x40000000        ; =-1073741824
1008476b8:     	cmp	w8, w9
1008476bc:     	csel	w8, w8, wzr, lt
1008476c0:     	mov	x22, x0
1008476c4:     	mov	x0, x8
1008476c8:     	bl	0x1005e58a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
1008476cc:     	mov	w9, #0x2                ; =2
1008476d0:     	cmp	w1, #0x2
1008476d4:     	csel	w10, w1, w9, hi
1008476d8:     	tst	w0, #0x1
1008476dc:     	csel	w8, w10, w9, ne
1008476e0:     	cmp	w20, w8
1008476e4:     	b.hi	0x1008464e4 <_js_json_stringify_full+0x5a4>
1008476e8:     	mov	x0, x22
1008476ec:     	mov	x1, x20
1008476f0:     	bl	0x1004efdc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1008476f4:     	cbz	w0, 0x1008464e4 <_js_json_stringify_full+0x5a4>
1008476f8:     	and	x0, x19, #0xffffffffffff
1008476fc:     	mov	x1, x20
100847700:     	bl	0x1004f7f40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
100847704:     	b	0x100847710 <_js_json_stringify_full+0x17d0>
100847708:     	and	x0, x19, #0xffffffffffff
10084770c:     	bl	0x1004f8cc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
100847710:     	mov	x20, x1
100847714:     	tbz	w0, #0x0, 0x1008464e4 <_js_json_stringify_full+0x5a4>
100847718:     	b	0x1008473e8 <_js_json_stringify_full+0x14a8>
10084771c:     	add	x9, x8, #0x60
100847720:     	b	0x1008479a8 <_js_json_stringify_full+0x1a68>
100847724:     	bl	0x100b3fdbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100847728:     	lsr	x1, x23, #20
10084772c:     	ldr	x8, [x0, #0x10]
100847730:     	ldrb	w9, [x8]
100847734:     	cmp	w9, #0x2
100847738:     	b.eq	0x100846ac8 <_js_json_stringify_full+0xb88>
10084773c:     	ldr	x9, [x8, #0x8]
100847740:     	ldr	x10, [x8, #0x28]
100847744:     	sub	x9, x1, x9
100847748:     	cmp	x9, x10
10084774c:     	b.hs	0x100847790 <_js_json_stringify_full+0x1850>
100847750:     	ldr	x10, [x8, #0x20]
100847754:     	mov	w11, #0x28              ; =40
100847758:     	madd	x9, x9, x11, x10
10084775c:     	ldr	x10, [x9]
100847760:     	ldr	x11, [x8, #0x10]
100847764:     	cmp	x10, x11
100847768:     	b.ne	0x10084779c <_js_json_stringify_full+0x185c>
10084776c:     	ldp	x10, x11, [x9, #0x8]
100847770:     	cmp	x10, x23
100847774:     	ccmp	x11, x23, #0x0, ls
100847778:     	b.ls	0x10084779c <_js_json_stringify_full+0x185c>
10084777c:     	ldr	x10, [x8, #0x30]
100847780:     	add	x10, x10, #0x1
100847784:     	str	x10, [x8, #0x30]
100847788:     	add	x8, x9, #0x21
10084778c:     	b	0x1008479b8 <_js_json_stringify_full+0x1a78>
100847790:     	ldr	x9, [x8, #0x58]
100847794:     	add	x9, x9, #0x1
100847798:     	str	x9, [x8, #0x58]
10084779c:     	ldr	x9, [x8, #0x38]
1008477a0:     	add	x9, x9, #0x1
1008477a4:     	str	x9, [x8, #0x38]
1008477a8:     	mov	x0, x23
1008477ac:     	bl	0x10051e508 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1008477b0:     	and	w8, w0, #0xff
1008477b4:     	cbz	w8, 0x1008477d4 <_js_json_stringify_full+0x1894>
1008477b8:     	ldurb	w8, [x23, #-0x8]
1008477bc:     	ldurb	w9, [x23, #-0x7]
1008477c0:     	mov	w10, #0x82              ; =130
1008477c4:     	and	w9, w9, w10
1008477c8:     	cmp	w9, #0x2
1008477cc:     	ccmp	w8, #0x1, #0x0, eq
1008477d0:     	b.eq	0x100847868 <_js_json_stringify_full+0x1928>
1008477d4:     	mov	x0, x23
1008477d8:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008477dc:     	mov	x24, x0
1008477e0:     	cbz	x0, 0x10084780c <_js_json_stringify_full+0x18cc>
1008477e4:     	ldrb	w8, [x24]
1008477e8:     	cmp	w8, #0x1
1008477ec:     	b.ne	0x10084782c <_js_json_stringify_full+0x18ec>
1008477f0:     	ldrsb	w8, [x24, #0x1]
1008477f4:     	tbnz	w8, #0x1f, 0x100847890 <_js_json_stringify_full+0x1950>
1008477f8:     	mov	x0, x24
1008477fc:     	ldp	w9, w8, [x23]
100847800:     	cmp	w9, w8
100847804:     	b.hi	0x100847914 <_js_json_stringify_full+0x19d4>
100847808:     	b	0x10084792c <_js_json_stringify_full+0x19ec>
10084780c:     	mov	x0, x23
100847810:     	bl	0x1005893b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100847814:     	tbnz	w0, #0x0, 0x100847824 <_js_json_stringify_full+0x18e4>
100847818:     	mov	x0, x23
10084781c:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100847820:     	tbz	w0, #0x0, 0x100846b68 <_js_json_stringify_full+0xc28>
100847824:     	mov	x0, #0x0                ; =0
100847828:     	b	0x100847904 <_js_json_stringify_full+0x19c4>
10084782c:     	mov	x0, x24
100847830:     	cmp	w8, #0x1
100847834:     	b.eq	0x100847904 <_js_json_stringify_full+0x19c4>
100847838:     	cmp	w8, #0x9
10084783c:     	b.ne	0x100846b68 <_js_json_stringify_full+0xc28>
100847840:     	ldr	w8, [x23, #0x4]
100847844:     	mov	w9, #0x5841             ; =22593
100847848:     	movk	w9, #0x4c5a, lsl #16
10084784c:     	cmp	w8, w9
100847850:     	b.ne	0x100846b68 <_js_json_stringify_full+0xc28>
100847854:     	mov	x0, x23
100847858:     	bl	0x100375e50 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
10084785c:     	mov	x23, x0
100847860:     	cbnz	x0, 0x100847954 <_js_json_stringify_full+0x1a14>
100847864:     	b	0x100846b68 <_js_json_stringify_full+0xc28>
100847868:     	ldr	w8, [x23]
10084786c:     	mov	w9, #0xe100             ; =57600
100847870:     	movk	w9, #0x5f5, lsl #16
100847874:     	orr	w9, w9, #0x1
100847878:     	cmp	w8, w9
10084787c:     	b.hs	0x1008477d4 <_js_json_stringify_full+0x1894>
100847880:     	ldr	w9, [x23, #0x4]
100847884:     	cmp	w8, w9
100847888:     	b.ls	0x100847954 <_js_json_stringify_full+0x1a14>
10084788c:     	b	0x1008477d4 <_js_json_stringify_full+0x1894>
100847890:     	ldr	x23, [x24, #0x8]
100847894:     	mov	x0, x23
100847898:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084789c:     	cbz	x0, 0x100846b68 <_js_json_stringify_full+0xc28>
1008478a0:     	ldrb	w8, [x0]
1008478a4:     	cmp	w8, #0x1
1008478a8:     	b.ne	0x100846b68 <_js_json_stringify_full+0xc28>
1008478ac:     	ldrsb	w8, [x0, #0x1]
1008478b0:     	tbz	w8, #0x1f, 0x1008477fc <_js_json_stringify_full+0x18bc>
1008478b4:     	mov	w26, #0x1               ; =1
1008478b8:     	ldr	x23, [x0, #0x8]
1008478bc:     	mov	x0, x23
1008478c0:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008478c4:     	cbz	x0, 0x100846b68 <_js_json_stringify_full+0xc28>
1008478c8:     	ldrb	w8, [x0]
1008478cc:     	cmp	w8, #0x1
1008478d0:     	b.ne	0x100846b68 <_js_json_stringify_full+0xc28>
1008478d4:     	cmp	w26, #0x3f
1008478d8:     	b.hi	0x100846b68 <_js_json_stringify_full+0xc28>
1008478dc:     	add	w26, w26, #0x1
1008478e0:     	ldrsb	w8, [x0, #0x1]
1008478e4:     	tbnz	w8, #0x1f, 0x1008478b8 <_js_json_stringify_full+0x1978>
1008478e8:     	str	x23, [x24, #0x8]
1008478ec:     	ldrb	w8, [x24, #0x1]
1008478f0:     	orr	w8, w8, #0x80
1008478f4:     	strb	w8, [x24, #0x1]
1008478f8:     	ldrb	w8, [x0]
1008478fc:     	cmp	w8, #0x1
100847900:     	b.ne	0x100847838 <_js_json_stringify_full+0x18f8>
100847904:     	ldp	w9, w8, [x23]
100847908:     	cmp	w9, w8
10084790c:     	b.ls	0x10084792c <_js_json_stringify_full+0x19ec>
100847910:     	cbz	x24, 0x10084793c <_js_json_stringify_full+0x19fc>
100847914:     	ldr	w9, [x0, #0x4]
100847918:     	ubfiz	x8, x8, #3, #32
10084791c:     	add	x8, x8, #0x10
100847920:     	cmp	x8, x9
100847924:     	b.eq	0x100847954 <_js_json_stringify_full+0x1a14>
100847928:     	b	0x10084793c <_js_json_stringify_full+0x19fc>
10084792c:     	mov	w8, #0xe100             ; =57600
100847930:     	movk	w8, #0x5f5, lsl #16
100847934:     	cmp	w9, w8
100847938:     	b.ls	0x100847954 <_js_json_stringify_full+0x1a14>
10084793c:     	mov	x0, x23
100847940:     	bl	0x1005893b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100847944:     	tbnz	w0, #0x0, 0x100847954 <_js_json_stringify_full+0x1a14>
100847948:     	mov	x0, x23
10084794c:     	bl	0x1002a3f48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100847950:     	tbz	w0, #0x0, 0x100846b68 <_js_json_stringify_full+0xc28>
100847954:     	ldp	w8, w9, [x23]
100847958:     	sub	w10, w9, #0x1
10084795c:     	mov	w11, #0x270f            ; =9999
100847960:     	cmp	w10, w11
100847964:     	ccmp	w8, w9, #0x2, lo
100847968:     	b.hi	0x100846b68 <_js_json_stringify_full+0xc28>
10084796c:     	and	x8, x21, #0xffffffffffff
100847970:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100847974:     	cmp	x25, x9
100847978:     	csel	x1, x8, x21, eq
10084797c:     	add	x0, sp, #0x30
100847980:     	bl	0x1004ffc78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
100847984:     	ldr	x25, [sp, #0x30]
100847988:     	cmn	x25, #0x1
10084798c:     	cset	w24, eq
100847990:     	cmp	x27, #0x1
100847994:     	cset	w8, hi
100847998:     	tst	w8, w24
10084799c:     	b.ne	0x100846b84 <_js_json_stringify_full+0xc44>
1008479a0:     	b	0x100846bf4 <_js_json_stringify_full+0xcb4>
1008479a4:     	add	x9, x8, #0x90
1008479a8:     	ldr	x10, [x8, #0x30]
1008479ac:     	add	x10, x10, #0x1
1008479b0:     	str	x10, [x8, #0x30]
1008479b4:     	add	x8, x9, #0x19
1008479b8:     	ldrb	w8, [x8]
1008479bc:     	cmp	w8, #0xff
1008479c0:     	b.ne	0x1008477b4 <_js_json_stringify_full+0x1874>
1008479c4:     	b	0x1008477a8 <_js_json_stringify_full+0x1868>
1008479c8:     	mov	x0, x23
1008479cc:     	bl	0x100b1ef44 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008479d0:     	cbnz	x0, 0x100846d10 <_js_json_stringify_full+0xdd0>
1008479d4:     	b	0x100847b50 <_js_json_stringify_full+0x1c10>
1008479d8:     	and	x0, x19, #0xffffffffffff
1008479dc:     	bl	0x1004f7d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
1008479e0:     	mov	w0, w0
1008479e4:     	mov	x20, #0x7d7b            ; =32123
1008479e8:     	movk	x20, #0x200, lsl #32
1008479ec:     	movk	x20, #0x7ff9, lsl #48
1008479f0:     	tbz	w0, #0x0, 0x100846518 <_js_json_stringify_full+0x5d8>
1008479f4:     	b	0x1008473e8 <_js_json_stringify_full+0x14a8>
1008479f8:     	mov	x19, x0
1008479fc:     	mov	x0, x23
100847a00:     	bl	0x100b1ef44 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847a04:     	mov	x23, x0
100847a08:     	mov	x0, x19
100847a0c:     	cbnz	x23, 0x1008472f4 <_js_json_stringify_full+0x13b4>
100847a10:     	b	0x100847af0 <_js_json_stringify_full+0x1bb0>
100847a14:     	bl	0x100b1f0a4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100847a18:     	cbnz	x0, 0x100846c38 <_js_json_stringify_full+0xcf8>
100847a1c:     	b	0x100847b50 <_js_json_stringify_full+0x1c10>
100847a20:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100847a24:     	add	x0, x0, #0x440
100847a28:     	bl	0x100b130ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847a2c:     	cmp	w8, #0x1
100847a30:     	b.ne	0x100847b50 <_js_json_stringify_full+0x1c10>
100847a34:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847a38:     	add	x1, x1, #0x998
100847a3c:     	mov	x19, x0
100847a40:     	bl	0x100a20e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847a44:     	mov	x0, x19
100847a48:     	strb	wzr, [x19, #0x20]
100847a4c:     	ldr	x8, [x19]
100847a50:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100847a54:     	cmp	x8, x9
100847a58:     	b.lo	0x100846e58 <_js_json_stringify_full+0xf18>
100847a5c:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847a60:     	add	x0, x0, #0xea8
100847a64:     	bl	0x100b1311c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100847a68:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847a6c:     	add	x0, x0, #0xec0
100847a70:     	bl	0x100b130ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847a74:     	and	x0, x19, #0xffffffffffff
100847a78:     	bl	0x1004ef9c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
100847a7c:     	mov	x20, x1
100847a80:     	tbz	w0, #0x0, 0x100846518 <_js_json_stringify_full+0x5d8>
100847a84:     	b	0x1008473e8 <_js_json_stringify_full+0x14a8>
100847a88:     	mov	x0, x23
100847a8c:     	bl	0x100b1ef44 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847a90:     	mov	x23, x0
100847a94:     	cbnz	x0, 0x1008471a4 <_js_json_stringify_full+0x1264>
100847a98:     	b	0x100847af0 <_js_json_stringify_full+0x1bb0>
100847a9c:     	adrp	x0, 0x100ef7000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100847aa0:     	add	x0, x0, #0xd70
100847aa4:     	bl	0x100b1311c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100847aa8:     	bl	0x100b4c354 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
100847aac:     	cmp	w8, #0x2
100847ab0:     	b.eq	0x100847b50 <_js_json_stringify_full+0x1c10>
100847ab4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847ab8:     	add	x1, x1, #0x998
100847abc:     	mov	x19, x0
100847ac0:     	bl	0x100a20e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847ac4:     	mov	x0, x19
100847ac8:     	strb	wzr, [x19, #0x20]
100847acc:     	ldr	x8, [x19]
100847ad0:     	cbz	x8, 0x100847190 <_js_json_stringify_full+0x1250>
100847ad4:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847ad8:     	add	x0, x0, #0xe90
100847adc:     	bl	0x100b130ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847ae0:     	mov	x0, x23
100847ae4:     	bl	0x100b1ef44 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100847ae8:     	mov	x23, x0
100847aec:     	cbnz	x0, 0x1008470c0 <_js_json_stringify_full+0x1180>
100847af0:     	cbz	x22, 0x100847b50 <_js_json_stringify_full+0x1c10>
100847af4:     	mov	x0, x19
100847af8:     	bl	0x100b5f9c0 <_mi_free>
100847afc:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847b00:     	add	x0, x0, #0xc18
100847b04:     	bl	0x100b5901c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100847b08:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0x74>
100847b0c:     	add	x0, x0, #0xeb0
100847b10:     	mov	w1, #0xf                ; =15
100847b14:     	bl	0x100b4c31c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100847b18:     	and	x0, x19, #0xffffffffffff
100847b1c:     	add	x2, sp, #0x80
100847b20:     	mov	x1, x22
100847b24:     	bl	0x1004f01c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
100847b28:     	tbnz	w0, #0x0, 0x100847554 <_js_json_stringify_full+0x1614>
100847b2c:     	mov	w20, #0x2               ; =2
100847b30:     	and	x0, x19, #0xffffffffffff
100847b34:     	mov	x1, x20
100847b38:     	bl	0x1004ee840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
100847b3c:     	mov	x20, x1
100847b40:     	tbz	w0, #0x0, 0x100846518 <_js_json_stringify_full+0x5d8>
100847b44:     	b	0x1008473e8 <_js_json_stringify_full+0x14a8>
100847b48:     	cmp	w8, #0x2
100847b4c:     	b.ne	0x100847b78 <_js_json_stringify_full+0x1c38>
100847b50:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100847b54:     	add	x0, x0, #0xc18
100847b58:     	bl	0x100b5901c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100847b5c:     	adrp	x0, 0x100f2f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x1d8>
100847b60:     	add	x0, x0, #0x800
100847b64:     	bl	0x100b131b0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100847b68:     	adrp	x0, 0x100c42000 <_PERRY_EMPTY_STRING+0x74>
100847b6c:     	add	x0, x0, #0xbe7
100847b70:     	mov	w1, #0xb                ; =11
100847b74:     	bl	0x100b4c31c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100847b78:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100847b7c:     	add	x1, x1, #0x998
100847b80:     	mov	x19, x0
100847b84:     	bl	0x100a20e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100847b88:     	mov	x0, x19
100847b8c:     	strb	wzr, [x19, #0x20]
100847b90:     	ldr	x8, [x19]
100847b94:     	cbz	x8, 0x1008470ac <_js_json_stringify_full+0x116c>
100847b98:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100847b9c:     	add	x0, x0, #0xe78
100847ba0:     	bl	0x100b130ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100847ba4:     	mov	w0, #0x1                ; =1
100847ba8:     	mov	x1, x24
100847bac:     	bl	0x100b12d40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847bb0:     	mov	w0, #0x1                ; =1
100847bb4:     	mov	x1, x22
100847bb8:     	bl	0x100b12d40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847bbc:     	adrp	x2, 0x100ef8000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100847bc0:     	add	x2, x2, #0x3c8
100847bc4:     	mov	w0, #0x5                ; =5
100847bc8:     	mov	w1, #0x5                ; =5
100847bcc:     	bl	0x100b1324c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
