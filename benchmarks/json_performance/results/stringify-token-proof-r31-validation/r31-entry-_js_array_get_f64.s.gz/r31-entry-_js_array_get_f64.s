
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-token-proof-r31/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007be350 <_js_array_get_f64>:
1007be350:     	sub	sp, sp, #0x70
1007be354:     	stp	x26, x25, [sp, #0x20]
1007be358:     	stp	x24, x23, [sp, #0x30]
1007be35c:     	stp	x22, x21, [sp, #0x40]
1007be360:     	stp	x20, x19, [sp, #0x50]
1007be364:     	stp	x29, x30, [sp, #0x60]
1007be368:     	add	x29, sp, #0x60
1007be36c:     	mov	x19, x1
1007be370:     	mov	x22, x0
1007be374:     	lsr	x25, x0, #51
1007be378:     	mov	x20, x0
1007be37c:     	cmp	x25, #0xfff
1007be380:     	b.lo	0x1007be39c <_js_array_get_f64+0x4c>
1007be384:     	mov	w8, #0x7ffc             ; =32764
1007be388:     	cmp	x8, x22, lsr #48
1007be38c:     	b.ne	0x1007be398 <_js_array_get_f64+0x48>
1007be390:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007be394:     	b	0x1007bea48 <_js_array_get_f64+0x6f8>
1007be398:     	and	x20, x22, #0xffffffffffff
1007be39c:     	lsr	x8, x20, #3
1007be3a0:     	cmp	x8, #0x200
1007be3a4:     	b.ls	0x1007be3dc <_js_array_get_f64+0x8c>
1007be3a8:     	ldurb	w8, [x20, #-0x8]
1007be3ac:     	cmp	w8, #0x9
1007be3b0:     	b.ne	0x1007be3dc <_js_array_get_f64+0x8c>
1007be3b4:     	ldr	w8, [x20, #0x4]
1007be3b8:     	mov	w9, #0x5841             ; =22593
1007be3bc:     	movk	w9, #0x4c5a, lsl #16
1007be3c0:     	cmp	w8, w9
1007be3c4:     	b.ne	0x1007be3dc <_js_array_get_f64+0x8c>
1007be3c8:     	mov	x0, x20
1007be3cc:     	mov	x1, x19
1007be3d0:     	bl	0x100688384 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007be3d4:     	fmov	d0, x0
1007be3d8:     	b	0x1007bea4c <_js_array_get_f64+0x6fc>
1007be3dc:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be3e0:     	b.lo	0x1007be490 <_js_array_get_f64+0x140>
1007be3e4:     	tst	x20, #0xffff800000000000
1007be3e8:     	mov	w8, #0x1000             ; =4096
1007be3ec:     	ccmp	x20, x8, #0x0, eq
1007be3f0:     	b.lo	0x1007be490 <_js_array_get_f64+0x140>
1007be3f4:     	ldurb	w24, [x20, #-0x8]
1007be3f8:     	ldurh	w23, [x20, #-0x6]
1007be3fc:     	cmp	w24, #0xa
1007be400:     	b.gt	0x1007be5a8 <_js_array_get_f64+0x258>
1007be404:     	cmp	w24, #0x2
1007be408:     	b.eq	0x1007be630 <_js_array_get_f64+0x2e0>
1007be40c:     	cmp	w24, #0x8
1007be410:     	b.ne	0x1007be498 <_js_array_get_f64+0x148>
1007be414:     	mov	x0, x20
1007be418:     	bl	0x1003051a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007be41c:     	cbz	w0, 0x1007be6c0 <_js_array_get_f64+0x370>
1007be420:     	mov	x22, #0x1               ; =1
1007be424:     	movk	x22, #0x7ffc, lsl #48
1007be428:     	lsr	x8, x20, #51
1007be42c:     	cmp	x8, #0xfff
1007be430:     	b.lo	0x1007be444 <_js_array_get_f64+0xf4>
1007be434:     	mov	w8, #0x7ffc             ; =32764
1007be438:     	cmp	x8, x20, lsr #48
1007be43c:     	b.eq	0x1007bea48 <_js_array_get_f64+0x6f8>
1007be440:     	and	x20, x20, #0xffffffffffff
1007be444:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be448:     	b.lo	0x1007be468 <_js_array_get_f64+0x118>
1007be44c:     	tst	x20, #0xffff800000000000
1007be450:     	mov	w8, #0x1000             ; =4096
1007be454:     	ccmp	x20, x8, #0x0, eq
1007be458:     	b.lo	0x1007be468 <_js_array_get_f64+0x118>
1007be45c:     	ldurb	w8, [x20, #-0x8]
1007be460:     	cmp	w8, #0x2
1007be464:     	b.eq	0x1007bed34 <_js_array_get_f64+0x9e4>
1007be468:     	cbz	x20, 0x1007bea48 <_js_array_get_f64+0x6f8>
1007be46c:     	mov	x0, x20
1007be470:     	mov	x1, x19
1007be474:     	bl	0x100305358 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007be478:     	cmp	w0, #0x1
1007be47c:     	b.ne	0x1007bea48 <_js_array_get_f64+0x6f8>
1007be480:     	ldr	x8, [x20, #0x8]
1007be484:     	ubfiz	x9, x1, #4, #32
1007be488:     	ldr	x22, [x8, x9]
1007be48c:     	b	0x1007bea48 <_js_array_get_f64+0x6f8>
1007be490:     	mov	w23, #0x0               ; =0
1007be494:     	mov	w24, #0x0               ; =0
1007be498:     	mov	x21, x22
1007be49c:     	cmp	x25, #0xfff
1007be4a0:     	b.lo	0x1007be4b8 <_js_array_get_f64+0x168>
1007be4a4:     	mov	w8, #0x7ffc             ; =32764
1007be4a8:     	cmp	x8, x22, lsr #48
1007be4ac:     	b.eq	0x1007bea34 <_js_array_get_f64+0x6e4>
1007be4b0:     	ands	x21, x22, #0xffffffffffff
1007be4b4:     	b.eq	0x1007bea34 <_js_array_get_f64+0x6e4>
1007be4b8:     	and	x8, x21, #0xfffffffffff00000
1007be4bc:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007be4c0:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007be4c4:     	cmp	x9, x10
1007be4c8:     	ccmp	x8, #0x0, #0x4, lo
1007be4cc:     	b.eq	0x1007bea34 <_js_array_get_f64+0x6e4>
1007be4d0:     	tst	x21, #0x3
1007be4d4:     	ccmp	x21, #0x7, #0x0, eq
1007be4d8:     	b.ls	0x1007be788 <_js_array_get_f64+0x438>
1007be4dc:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be4e0:     	ldr	x8, [x8, #0x48]
1007be4e4:     	cmn	x8, #0x1
1007be4e8:     	b.eq	0x1007be6d8 <_js_array_get_f64+0x388>
1007be4ec:     	mrs	x9, TPIDRRO_EL0
1007be4f0:     	and	x9, x9, #0xfffffffffffffff8
1007be4f4:     	ldr	x0, [x9, x8, lsl #3]
1007be4f8:     	cbz	x0, 0x1007be6d8 <_js_array_get_f64+0x388>
1007be4fc:     	lsr	x1, x21, #20
1007be500:     	ldr	x8, [x0, #0x10]
1007be504:     	ldrb	w9, [x8]
1007be508:     	cmp	w9, #0x2
1007be50c:     	b.ne	0x1007be6f0 <_js_array_get_f64+0x3a0>
1007be510:     	ldrb	w9, [x8, #0x88]
1007be514:     	tbz	w9, #0x0, 0x1007be534 <_js_array_get_f64+0x1e4>
1007be518:     	ldr	x9, [x8, #0x80]
1007be51c:     	cmp	x9, x1
1007be520:     	b.ne	0x1007be534 <_js_array_get_f64+0x1e4>
1007be524:     	ldp	x9, x10, [x8, #0x60]
1007be528:     	cmp	x9, x21
1007be52c:     	ccmp	x10, x21, #0x0, ls
1007be530:     	b.hi	0x1007be6d0 <_js_array_get_f64+0x380>
1007be534:     	ldrb	w9, [x8, #0xb8]
1007be538:     	cbz	w9, 0x1007be558 <_js_array_get_f64+0x208>
1007be53c:     	ldr	x9, [x8, #0xb0]
1007be540:     	cmp	x9, x1
1007be544:     	b.ne	0x1007be558 <_js_array_get_f64+0x208>
1007be548:     	ldp	x9, x10, [x8, #0x90]
1007be54c:     	cmp	x9, x21
1007be550:     	ccmp	x10, x21, #0x0, ls
1007be554:     	b.hi	0x1007beb98 <_js_array_get_f64+0x848>
1007be558:     	ldrb	w9, [x8, #0xe8]
1007be55c:     	cbz	w9, 0x1007be57c <_js_array_get_f64+0x22c>
1007be560:     	ldr	x9, [x8, #0xe0]
1007be564:     	cmp	x9, x1
1007be568:     	b.ne	0x1007be57c <_js_array_get_f64+0x22c>
1007be56c:     	ldp	x9, x10, [x8, #0xc0]
1007be570:     	cmp	x9, x21
1007be574:     	ccmp	x10, x21, #0x0, ls
1007be578:     	b.hi	0x1007bec80 <_js_array_get_f64+0x930>
1007be57c:     	ldrb	w9, [x8, #0x118]
1007be580:     	cbz	w9, 0x1007be750 <_js_array_get_f64+0x400>
1007be584:     	ldr	x9, [x8, #0x110]
1007be588:     	cmp	x9, x1
1007be58c:     	b.ne	0x1007be750 <_js_array_get_f64+0x400>
1007be590:     	ldp	x9, x10, [x8, #0xf0]
1007be594:     	cmp	x9, x21
1007be598:     	ccmp	x10, x21, #0x0, ls
1007be59c:     	b.ls	0x1007be750 <_js_array_get_f64+0x400>
1007be5a0:     	add	x9, x8, #0xf0
1007be5a4:     	b	0x1007bec84 <_js_array_get_f64+0x934>
1007be5a8:     	cmp	w24, #0xb
1007be5ac:     	b.eq	0x1007be648 <_js_array_get_f64+0x2f8>
1007be5b0:     	cmp	w24, #0xc
1007be5b4:     	b.ne	0x1007be498 <_js_array_get_f64+0x148>
1007be5b8:     	mov	x0, x20
1007be5bc:     	bl	0x10030af38 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007be5c0:     	cbz	w0, 0x1007be6c8 <_js_array_get_f64+0x378>
1007be5c4:     	mov	x22, #0x1               ; =1
1007be5c8:     	movk	x22, #0x7ffc, lsl #48
1007be5cc:     	lsr	x8, x20, #51
1007be5d0:     	cmp	x8, #0xfff
1007be5d4:     	b.lo	0x1007be5e8 <_js_array_get_f64+0x298>
1007be5d8:     	mov	w8, #0x7ffc             ; =32764
1007be5dc:     	cmp	x8, x20, lsr #48
1007be5e0:     	b.eq	0x1007bea48 <_js_array_get_f64+0x6f8>
1007be5e4:     	and	x20, x20, #0xffffffffffff
1007be5e8:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007be5ec:     	b.lo	0x1007be60c <_js_array_get_f64+0x2bc>
1007be5f0:     	tst	x20, #0xffff800000000000
1007be5f4:     	mov	w8, #0x1000             ; =4096
1007be5f8:     	ccmp	x20, x8, #0x0, eq
1007be5fc:     	b.lo	0x1007be60c <_js_array_get_f64+0x2bc>
1007be600:     	ldurb	w8, [x20, #-0x8]
1007be604:     	cmp	w8, #0x2
1007be608:     	b.eq	0x1007bed4c <_js_array_get_f64+0x9fc>
1007be60c:     	cbz	x20, 0x1007bea48 <_js_array_get_f64+0x6f8>
1007be610:     	mov	x0, x20
1007be614:     	mov	x1, x19
1007be618:     	bl	0x10030cbb0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007be61c:     	cmp	w0, #0x1
1007be620:     	b.ne	0x1007bea48 <_js_array_get_f64+0x6f8>
1007be624:     	ldr	x8, [x20, #0x8]
1007be628:     	ldr	x22, [x8, w1, uxtw #3]
1007be62c:     	b	0x1007bea48 <_js_array_get_f64+0x6f8>
1007be630:     	mov	x0, x22
1007be634:     	mov	x1, x19
1007be638:     	bl	0x1005487cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007be63c:     	tbnz	w0, #0x0, 0x1007bea44 <_js_array_get_f64+0x6f4>
1007be640:     	mov	w24, #0x2               ; =2
1007be644:     	b	0x1007be498 <_js_array_get_f64+0x148>
1007be648:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be64c:     	add	x8, x8, #0xec0
1007be650:     	ldaprb	w8, [x8]
1007be654:     	cbz	w8, 0x1007be6b8 <_js_array_get_f64+0x368>
1007be658:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be65c:     	add	x8, x8, #0x58
1007be660:     	ldapr	x8, [x8]
1007be664:     	cmp	x20, x8
1007be668:     	b.lo	0x1007be6b8 <_js_array_get_f64+0x368>
1007be66c:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be670:     	add	x8, x8, #0x60
1007be674:     	ldapr	x8, [x8]
1007be678:     	cmp	x20, x8
1007be67c:     	b.hi	0x1007be6b8 <_js_array_get_f64+0x368>
1007be680:     	mov	x0, x20
1007be684:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be688:     	tbz	w0, #0x0, 0x1007be6b8 <_js_array_get_f64+0x368>
1007be68c:     	add	x0, sp, #0x8
1007be690:     	mov	x1, x20
1007be694:     	bl	0x1002a4aac <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007be698:     	ldr	x8, [sp, #0x8]
1007be69c:     	cbz	x8, 0x1007becc4 <_js_array_get_f64+0x974>
1007be6a0:     	cmp	x8, #0x1
1007be6a4:     	b.ne	0x1007bed08 <_js_array_get_f64+0x9b8>
1007be6a8:     	ldr	d0, [sp, #0x10]
1007be6ac:     	scvtf	d1, w19
1007be6b0:     	bl	0x10081c8f4 <_js_dyn_index_get>
1007be6b4:     	b	0x1007bea44 <_js_array_get_f64+0x6f4>
1007be6b8:     	mov	w24, #0xb               ; =11
1007be6bc:     	b	0x1007be498 <_js_array_get_f64+0x148>
1007be6c0:     	mov	w24, #0x8               ; =8
1007be6c4:     	b	0x1007be498 <_js_array_get_f64+0x148>
1007be6c8:     	mov	w24, #0xc               ; =12
1007be6cc:     	b	0x1007be498 <_js_array_get_f64+0x148>
1007be6d0:     	add	x9, x8, #0x60
1007be6d4:     	b	0x1007bec84 <_js_array_get_f64+0x934>
1007be6d8:     	bl	0x100b3fdbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007be6dc:     	lsr	x1, x21, #20
1007be6e0:     	ldr	x8, [x0, #0x10]
1007be6e4:     	ldrb	w9, [x8]
1007be6e8:     	cmp	w9, #0x2
1007be6ec:     	b.eq	0x1007be510 <_js_array_get_f64+0x1c0>
1007be6f0:     	ldr	x9, [x8, #0x8]
1007be6f4:     	ldr	x10, [x8, #0x28]
1007be6f8:     	sub	x9, x1, x9
1007be6fc:     	cmp	x9, x10
1007be700:     	b.hs	0x1007be744 <_js_array_get_f64+0x3f4>
1007be704:     	ldr	x10, [x8, #0x20]
1007be708:     	mov	w11, #0x28              ; =40
1007be70c:     	madd	x9, x9, x11, x10
1007be710:     	ldr	x10, [x9]
1007be714:     	ldr	x11, [x8, #0x10]
1007be718:     	cmp	x10, x11
1007be71c:     	b.ne	0x1007be750 <_js_array_get_f64+0x400>
1007be720:     	ldp	x10, x11, [x9, #0x8]
1007be724:     	cmp	x10, x21
1007be728:     	ccmp	x11, x21, #0x0, ls
1007be72c:     	b.ls	0x1007be750 <_js_array_get_f64+0x400>
1007be730:     	ldr	x10, [x8, #0x30]
1007be734:     	add	x10, x10, #0x1
1007be738:     	str	x10, [x8, #0x30]
1007be73c:     	add	x8, x9, #0x21
1007be740:     	b	0x1007bec94 <_js_array_get_f64+0x944>
1007be744:     	ldr	x9, [x8, #0x58]
1007be748:     	add	x9, x9, #0x1
1007be74c:     	str	x9, [x8, #0x58]
1007be750:     	ldr	x9, [x8, #0x38]
1007be754:     	add	x9, x9, #0x1
1007be758:     	str	x9, [x8, #0x38]
1007be75c:     	mov	x0, x21
1007be760:     	bl	0x10051e508 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007be764:     	and	w8, w0, #0xff
1007be768:     	cbz	w8, 0x1007be788 <_js_array_get_f64+0x438>
1007be76c:     	ldurb	w8, [x21, #-0x8]
1007be770:     	ldurb	w9, [x21, #-0x7]
1007be774:     	mov	w10, #0x82              ; =130
1007be778:     	and	w9, w9, w10
1007be77c:     	cmp	w9, #0x2
1007be780:     	ccmp	w8, #0x1, #0x0, eq
1007be784:     	b.eq	0x1007be858 <_js_array_get_f64+0x508>
1007be788:     	mov	x0, x21
1007be78c:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be790:     	cbz	x0, 0x1007be7b8 <_js_array_get_f64+0x468>
1007be794:     	ldrb	w9, [x0]
1007be798:     	cmp	w9, #0x1
1007be79c:     	b.ne	0x1007be7d4 <_js_array_get_f64+0x484>
1007be7a0:     	ldrsb	w8, [x0, #0x1]
1007be7a4:     	tbnz	w8, #0x1f, 0x1007be880 <_js_array_get_f64+0x530>
1007be7a8:     	ldp	w10, w9, [x21]
1007be7ac:     	cmp	w10, w9
1007be7b0:     	b.hi	0x1007be90c <_js_array_get_f64+0x5bc>
1007be7b4:     	b	0x1007be924 <_js_array_get_f64+0x5d4>
1007be7b8:     	mov	x25, x0
1007be7bc:     	mov	x0, x21
1007be7c0:     	bl	0x1005893b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be7c4:     	tbz	w0, #0x0, 0x1007be810 <_js_array_get_f64+0x4c0>
1007be7c8:     	mov	x0, #0x0                ; =0
1007be7cc:     	mov	x8, x25
1007be7d0:     	b	0x1007be8fc <_js_array_get_f64+0x5ac>
1007be7d4:     	mov	x8, x0
1007be7d8:     	cmp	w9, #0x1
1007be7dc:     	b.eq	0x1007be8fc <_js_array_get_f64+0x5ac>
1007be7e0:     	cmp	w9, #0x9
1007be7e4:     	b.ne	0x1007bea34 <_js_array_get_f64+0x6e4>
1007be7e8:     	ldr	w8, [x21, #0x4]
1007be7ec:     	mov	w9, #0x5841             ; =22593
1007be7f0:     	movk	w9, #0x4c5a, lsl #16
1007be7f4:     	cmp	w8, w9
1007be7f8:     	b.ne	0x1007bea34 <_js_array_get_f64+0x6e4>
1007be7fc:     	mov	x0, x21
1007be800:     	bl	0x100375e50 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007be804:     	cbz	x0, 0x1007bea34 <_js_array_get_f64+0x6e4>
1007be808:     	mov	x21, x0
1007be80c:     	b	0x1007be940 <_js_array_get_f64+0x5f0>
1007be810:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be814:     	add	x8, x8, #0xec0
1007be818:     	ldaprb	w8, [x8]
1007be81c:     	cbz	w8, 0x1007bea34 <_js_array_get_f64+0x6e4>
1007be820:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be824:     	add	x8, x8, #0x58
1007be828:     	ldapr	x8, [x8]
1007be82c:     	cmp	x8, x21
1007be830:     	b.hi	0x1007bea34 <_js_array_get_f64+0x6e4>
1007be834:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be838:     	add	x8, x8, #0x60
1007be83c:     	ldapr	x8, [x8]
1007be840:     	cmp	x8, x21
1007be844:     	b.lo	0x1007bea34 <_js_array_get_f64+0x6e4>
1007be848:     	mov	x0, x21
1007be84c:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be850:     	tbnz	w0, #0x0, 0x1007be7c8 <_js_array_get_f64+0x478>
1007be854:     	b	0x1007bea34 <_js_array_get_f64+0x6e4>
1007be858:     	ldr	w8, [x21]
1007be85c:     	mov	w9, #0xe100             ; =57600
1007be860:     	movk	w9, #0x5f5, lsl #16
1007be864:     	orr	w9, w9, #0x1
1007be868:     	cmp	w8, w9
1007be86c:     	b.hs	0x1007be788 <_js_array_get_f64+0x438>
1007be870:     	ldr	w9, [x21, #0x4]
1007be874:     	cmp	w8, w9
1007be878:     	b.ls	0x1007be940 <_js_array_get_f64+0x5f0>
1007be87c:     	b	0x1007be788 <_js_array_get_f64+0x438>
1007be880:     	mov	x25, x0
1007be884:     	ldr	x21, [x0, #0x8]
1007be888:     	mov	x0, x21
1007be88c:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be890:     	cbz	x0, 0x1007bea34 <_js_array_get_f64+0x6e4>
1007be894:     	ldrb	w8, [x0]
1007be898:     	cmp	w8, #0x1
1007be89c:     	b.ne	0x1007bea34 <_js_array_get_f64+0x6e4>
1007be8a0:     	ldrsb	w8, [x0, #0x1]
1007be8a4:     	tbz	w8, #0x1f, 0x1007be7a8 <_js_array_get_f64+0x458>
1007be8a8:     	mov	w26, #0x1               ; =1
1007be8ac:     	ldr	x21, [x0, #0x8]
1007be8b0:     	mov	x0, x21
1007be8b4:     	bl	0x10057ab80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007be8b8:     	cbz	x0, 0x1007bea34 <_js_array_get_f64+0x6e4>
1007be8bc:     	ldrb	w8, [x0]
1007be8c0:     	cmp	w8, #0x1
1007be8c4:     	b.ne	0x1007bea34 <_js_array_get_f64+0x6e4>
1007be8c8:     	cmp	w26, #0x3f
1007be8cc:     	b.hi	0x1007bea34 <_js_array_get_f64+0x6e4>
1007be8d0:     	add	w26, w26, #0x1
1007be8d4:     	ldrsb	w8, [x0, #0x1]
1007be8d8:     	tbnz	w8, #0x1f, 0x1007be8ac <_js_array_get_f64+0x55c>
1007be8dc:     	str	x21, [x25, #0x8]
1007be8e0:     	ldrb	w8, [x25, #0x1]
1007be8e4:     	orr	w9, w8, #0x80
1007be8e8:     	mov	x8, x25
1007be8ec:     	strb	w9, [x25, #0x1]
1007be8f0:     	ldrb	w9, [x0]
1007be8f4:     	cmp	w9, #0x1
1007be8f8:     	b.ne	0x1007be7e0 <_js_array_get_f64+0x490>
1007be8fc:     	ldp	w10, w9, [x21]
1007be900:     	cmp	w10, w9
1007be904:     	b.ls	0x1007be924 <_js_array_get_f64+0x5d4>
1007be908:     	cbz	x8, 0x1007be934 <_js_array_get_f64+0x5e4>
1007be90c:     	ldr	w8, [x0, #0x4]
1007be910:     	ubfiz	x9, x9, #3, #32
1007be914:     	add	x9, x9, #0x10
1007be918:     	cmp	x9, x8
1007be91c:     	b.eq	0x1007be940 <_js_array_get_f64+0x5f0>
1007be920:     	b	0x1007be934 <_js_array_get_f64+0x5e4>
1007be924:     	mov	w8, #0xe100             ; =57600
1007be928:     	movk	w8, #0x5f5, lsl #16
1007be92c:     	cmp	w10, w8
1007be930:     	b.ls	0x1007be940 <_js_array_get_f64+0x5f0>
1007be934:     	mov	x0, x21
1007be938:     	bl	0x1005893b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be93c:     	tbz	w0, #0x0, 0x1007be9f0 <_js_array_get_f64+0x6a0>
1007be940:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be944:     	add	x8, x8, #0xec0
1007be948:     	ldaprb	w8, [x8]
1007be94c:     	cbz	w8, 0x1007be994 <_js_array_get_f64+0x644>
1007be950:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be954:     	add	x8, x8, #0x58
1007be958:     	ldapr	x8, [x8]
1007be95c:     	cmp	x21, x8
1007be960:     	b.lo	0x1007be994 <_js_array_get_f64+0x644>
1007be964:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007be968:     	add	x8, x8, #0x60
1007be96c:     	ldapr	x8, [x8]
1007be970:     	cmp	x21, x8
1007be974:     	b.hi	0x1007be994 <_js_array_get_f64+0x644>
1007be978:     	mov	x0, x21
1007be97c:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007be980:     	tbz	w0, #0x0, 0x1007be994 <_js_array_get_f64+0x644>
1007be984:     	mov	x0, x21
1007be988:     	mov	x1, x19
1007be98c:     	bl	0x1008fc608 <_js_typed_array_get>
1007be990:     	b	0x1007bea44 <_js_array_get_f64+0x6f4>
1007be994:     	mov	x0, x21
1007be998:     	bl	0x1005893b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007be99c:     	tbz	w0, #0x0, 0x1007be9c4 <_js_array_get_f64+0x674>
1007be9a0:     	mov	x0, x21
1007be9a4:     	mov	x1, x19
1007be9a8:     	bl	0x1005866dc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007be9ac:     	and	w8, w1, #0xff
1007be9b0:     	ucvtf	d0, w8
1007be9b4:     	fmov	x8, d0
1007be9b8:     	tst	w0, #0x1
1007be9bc:     	csel	x22, x8, xzr, ne
1007be9c0:     	b	0x1007bea48 <_js_array_get_f64+0x6f8>
1007be9c4:     	cmp	x21, x20
1007be9c8:     	b.eq	0x1007bea70 <_js_array_get_f64+0x720>
1007be9cc:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007be9d0:     	b.lo	0x1007bea68 <_js_array_get_f64+0x718>
1007be9d4:     	tst	x21, #0xffff800000000000
1007be9d8:     	mov	w8, #0x1000             ; =4096
1007be9dc:     	ccmp	x21, x8, #0x0, eq
1007be9e0:     	b.lo	0x1007bea68 <_js_array_get_f64+0x718>
1007be9e4:     	ldurb	w24, [x21, #-0x8]
1007be9e8:     	ldurh	w23, [x21, #-0x6]
1007be9ec:     	b	0x1007bea70 <_js_array_get_f64+0x720>
1007be9f0:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007be9f4:     	add	x8, x8, #0xec0
1007be9f8:     	ldaprb	w8, [x8]
1007be9fc:     	cbz	w8, 0x1007bea34 <_js_array_get_f64+0x6e4>
1007bea00:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bea04:     	add	x8, x8, #0x58
1007bea08:     	ldapr	x8, [x8]
1007bea0c:     	cmp	x21, x8
1007bea10:     	b.lo	0x1007bea34 <_js_array_get_f64+0x6e4>
1007bea14:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bea18:     	add	x8, x8, #0x60
1007bea1c:     	ldapr	x8, [x8]
1007bea20:     	cmp	x21, x8
1007bea24:     	b.hi	0x1007bea34 <_js_array_get_f64+0x6e4>
1007bea28:     	mov	x0, x21
1007bea2c:     	bl	0x1002a4c78 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bea30:     	tbnz	w0, #0x0, 0x1007be940 <_js_array_get_f64+0x5f0>
1007bea34:     	mov	x0, x22
1007bea38:     	mov	x1, x19
1007bea3c:     	bl	0x1005487cc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bea40:     	tbz	w0, #0x0, 0x1007bed18 <_js_array_get_f64+0x9c8>
1007bea44:     	fmov	x22, d0
1007bea48:     	fmov	d0, x22
1007bea4c:     	ldp	x29, x30, [sp, #0x60]
1007bea50:     	ldp	x20, x19, [sp, #0x50]
1007bea54:     	ldp	x22, x21, [sp, #0x40]
1007bea58:     	ldp	x24, x23, [sp, #0x30]
1007bea5c:     	ldp	x26, x25, [sp, #0x20]
1007bea60:     	add	sp, sp, #0x70
1007bea64:     	ret
1007bea68:     	mov	w23, #0x0               ; =0
1007bea6c:     	mov	w24, #0x0               ; =0
1007bea70:     	cmp	w24, #0x1
1007bea74:     	b.ne	0x1007bec28 <_js_array_get_f64+0x8d8>
1007bea78:     	tbz	w23, #0xa, 0x1007bec28 <_js_array_get_f64+0x8d8>
1007bea7c:     	adrp	x8, 0x100b65000 <__RNvNtNtNtCsjgY6bXVaRmE_4core7unicode12unicode_data9lowercase17BITSET_CHUNKS_MAP+0x20>
1007bea80:     	add	x8, x8, #0x80c
1007bea84:     	cmp	w19, #0x3e8
1007bea88:     	b.lo	0x1007beb00 <_js_array_get_f64+0x7b0>
1007bea8c:     	mov	x9, #0x0                ; =0
1007bea90:     	mov	w11, #0x1759            ; =5977
1007bea94:     	movk	w11, #0xd1b7, lsl #16
1007bea98:     	mov	w12, #0x2710            ; =10000
1007bea9c:     	mov	w13, #0x147b            ; =5243
1007beaa0:     	mov	w14, #0x64              ; =100
1007beaa4:     	add	x15, sp, #0x8
1007beaa8:     	mov	w16, #0x967f            ; =38527
1007beaac:     	movk	w16, #0x98, lsl #16
1007beab0:     	mov	x10, x19
1007beab4:     	mov	x17, x10
1007beab8:     	umull	x10, w10, w11
1007beabc:     	lsr	x10, x10, #45
1007beac0:     	msub	w0, w10, w12, w17
1007beac4:     	ubfx	w1, w0, #2, #14
1007beac8:     	mul	w1, w1, w13
1007beacc:     	lsr	w1, w1, #17
1007bead0:     	msub	w0, w1, w14, w0
1007bead4:     	add	x2, x15, x9
1007bead8:     	ldrh	w1, [x8, w1, uxtw #1]
1007beadc:     	strh	w1, [x2, #0x6]
1007beae0:     	and	x0, x0, #0xffff
1007beae4:     	ldrh	w0, [x8, x0, lsl #1]
1007beae8:     	strh	w0, [x2, #0x8]
1007beaec:     	sub	x9, x9, #0x4
1007beaf0:     	cmp	w17, w16
1007beaf4:     	b.hi	0x1007beab4 <_js_array_get_f64+0x764>
1007beaf8:     	add	x9, x9, #0xa
1007beafc:     	b	0x1007beb08 <_js_array_get_f64+0x7b8>
1007beb00:     	mov	w9, #0xa                ; =10
1007beb04:     	mov	x10, x19
1007beb08:     	cmp	w10, #0x9
1007beb0c:     	b.ls	0x1007beb40 <_js_array_get_f64+0x7f0>
1007beb10:     	sub	x9, x9, #0x2
1007beb14:     	ubfx	w11, w10, #2, #14
1007beb18:     	mov	w12, #0x147b            ; =5243
1007beb1c:     	mul	w11, w11, w12
1007beb20:     	lsr	w11, w11, #17
1007beb24:     	mov	w12, #0x64              ; =100
1007beb28:     	msub	w10, w11, w12, w10
1007beb2c:     	and	x10, x10, #0xffff
1007beb30:     	ldrh	w10, [x8, x10, lsl #1]
1007beb34:     	add	x12, sp, #0x8
1007beb38:     	strh	w10, [x12, x9]
1007beb3c:     	mov	x10, x11
1007beb40:     	cbz	w19, 0x1007beb78 <_js_array_get_f64+0x828>
1007beb44:     	cbnz	w10, 0x1007beb78 <_js_array_get_f64+0x828>
1007beb48:     	cmp	x9, #0xa
1007beb4c:     	b.ne	0x1007beba0 <_js_array_get_f64+0x850>
1007beb50:     	mov	w23, #0x1               ; =1
1007beb54:     	add	x0, sp, #0x8
1007beb58:     	mov	x1, x21
1007beb5c:     	mov	w2, #0x1                ; =1
1007beb60:     	mov	x3, #0x0                ; =0
1007beb64:     	bl	0x1005b2abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007beb68:     	ldr	x8, [sp, #0x8]
1007beb6c:     	mov	w20, #0x1               ; =1
1007beb70:     	cbnz	x8, 0x1007bebf0 <_js_array_get_f64+0x8a0>
1007beb74:     	b	0x1007bec28 <_js_array_get_f64+0x8d8>
1007beb78:     	sub	x23, x9, #0x1
1007beb7c:     	ubfiz	w10, w10, #1, #4
1007beb80:     	add	x8, x8, x10
1007beb84:     	ldrb	w8, [x8, #0x1]
1007beb88:     	add	x10, sp, #0x8
1007beb8c:     	strb	w8, [x10, x23]
1007beb90:     	mov	w8, #0xb                ; =11
1007beb94:     	b	0x1007beba8 <_js_array_get_f64+0x858>
1007beb98:     	add	x9, x8, #0x90
1007beb9c:     	b	0x1007bec84 <_js_array_get_f64+0x934>
1007beba0:     	mov	w8, #0xa                ; =10
1007beba4:     	mov	x23, x9
1007beba8:     	sub	x22, x8, x9
1007bebac:     	mov	x0, x22
1007bebb0:     	mov	w1, #0x1                ; =1
1007bebb4:     	bl	0x100b5fc48 <_mi_malloc_aligned>
1007bebb8:     	cbz	x0, 0x1007bed64 <_js_array_get_f64+0xa14>
1007bebbc:     	mov	x20, x0
1007bebc0:     	add	x8, sp, #0x8
1007bebc4:     	add	x1, x8, x23
1007bebc8:     	mov	x2, x22
1007bebcc:     	bl	0x100b6286c <_writev+0x100b6286c>
1007bebd0:     	add	x0, sp, #0x8
1007bebd4:     	mov	x1, x21
1007bebd8:     	mov	x2, x20
1007bebdc:     	mov	x3, x22
1007bebe0:     	bl	0x1005b2abc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bebe4:     	ldr	w8, [sp, #0x8]
1007bebe8:     	tbz	w8, #0x0, 0x1007bec20 <_js_array_get_f64+0x8d0>
1007bebec:     	mov	w23, #0x0               ; =0
1007bebf0:     	mov	x22, #0x1               ; =1
1007bebf4:     	movk	x22, #0x7ffc, lsl #48
1007bebf8:     	ldr	x0, [sp, #0x10]
1007bebfc:     	cbz	x0, 0x1007becb4 <_js_array_get_f64+0x964>
1007bec00:     	cbz	x21, 0x1007beca4 <_js_array_get_f64+0x954>
1007bec04:     	lsr	x8, x21, #52
1007bec08:     	cmp	x8, #0x7fe
1007bec0c:     	b.hi	0x1007beca8 <_js_array_get_f64+0x958>
1007bec10:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007bec14:     	bfxil	x8, x21, #0, #48
1007bec18:     	mov	x21, x8
1007bec1c:     	b	0x1007beca8 <_js_array_get_f64+0x958>
1007bec20:     	mov	x0, x20
1007bec24:     	bl	0x100b5f9c0 <_mi_free>
1007bec28:     	ldr	w8, [x21]
1007bec2c:     	cmp	w19, w8
1007bec30:     	b.hs	0x1007bec70 <_js_array_get_f64+0x920>
1007bec34:     	ldr	w8, [x21, #0x4]
1007bec38:     	cmp	w19, w8
1007bec3c:     	b.hs	0x1007bec60 <_js_array_get_f64+0x910>
1007bec40:     	add	x8, x21, w19, uxtw #3
1007bec44:     	ldr	x22, [x8, #0x8]
1007bec48:     	mov	x8, #0x1                ; =1
1007bec4c:     	movk	x8, #0x7ffc, lsl #48
1007bec50:     	add	x8, x8, #0xf
1007bec54:     	cmp	x22, x8
1007bec58:     	b.ne	0x1007bea48 <_js_array_get_f64+0x6f8>
1007bec5c:     	b	0x1007bec70 <_js_array_get_f64+0x920>
1007bec60:     	mov	x0, x21
1007bec64:     	mov	x1, x19
1007bec68:     	bl	0x10052abc4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007bec6c:     	tbnz	w0, #0x0, 0x1007bea44 <_js_array_get_f64+0x6f4>
1007bec70:     	mov	x0, x21
1007bec74:     	mov	x1, x19
1007bec78:     	bl	0x1006c7798 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007bec7c:     	b	0x1007bea44 <_js_array_get_f64+0x6f4>
1007bec80:     	add	x9, x8, #0xc0
1007bec84:     	ldr	x10, [x8, #0x30]
1007bec88:     	add	x10, x10, #0x1
1007bec8c:     	str	x10, [x8, #0x30]
1007bec90:     	add	x8, x9, #0x19
1007bec94:     	ldrb	w8, [x8]
1007bec98:     	cmp	w8, #0xff
1007bec9c:     	b.ne	0x1007be768 <_js_array_get_f64+0x418>
1007beca0:     	b	0x1007be75c <_js_array_get_f64+0x40c>
1007beca4:     	add	x21, x22, #0x1
1007beca8:     	fmov	d0, x21
1007becac:     	bl	0x1006fd5bc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007becb0:     	mov	x22, x0
1007becb4:     	tbnz	w23, #0x0, 0x1007bea48 <_js_array_get_f64+0x6f8>
1007becb8:     	mov	x0, x20
1007becbc:     	bl	0x100b5f9c0 <_mi_free>
1007becc0:     	b	0x1007bea48 <_js_array_get_f64+0x6f8>
1007becc4:     	ldr	x20, [sp, #0x10]
1007becc8:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007beccc:     	ldr	x8, [x8, #0xed8]
1007becd0:     	cbz	x8, 0x1007bece8 <_js_array_get_f64+0x998>
1007becd4:     	mov	x0, x20
1007becd8:     	bl	0x10013cd40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007becdc:     	tbz	w0, #0x0, 0x1007bece8 <_js_array_get_f64+0x998>
1007bece0:     	mov	x0, x20
1007bece4:     	bl	0x1002bee80 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007bece8:     	tbnz	w19, #0x1f, 0x1007bed08 <_js_array_get_f64+0x9b8>
1007becec:     	ldr	w8, [x20]
1007becf0:     	cmp	w19, w8
1007becf4:     	b.hs	0x1007bed08 <_js_array_get_f64+0x9b8>
1007becf8:     	mov	w1, w19
1007becfc:     	mov	x0, x20
1007bed00:     	bl	0x1002a510c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007bed04:     	b	0x1007bea44 <_js_array_get_f64+0x6f4>
1007bed08:     	mov	x8, #0x1                ; =1
1007bed0c:     	movk	x8, #0x7ffc, lsl #48
1007bed10:     	mov	x22, x8
1007bed14:     	b	0x1007bea48 <_js_array_get_f64+0x6f8>
1007bed18:     	mov	x0, x22
1007bed1c:     	bl	0x100b48330 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007bed20:     	cmp	x0, #0x1
1007bed24:     	b.ne	0x1007be390 <_js_array_get_f64+0x40>
1007bed28:     	mov	x0, x19
1007bed2c:     	bl	0x100b48350 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007bed30:     	b	0x1007bea44 <_js_array_get_f64+0x6f4>
1007bed34:     	mov	x0, x20
1007bed38:     	mov	w1, #0x0                ; =0
1007bed3c:     	bl	0x100b4a8c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bed40:     	mov	x20, x0
1007bed44:     	cbnz	x0, 0x1007be46c <_js_array_get_f64+0x11c>
1007bed48:     	b	0x1007bea48 <_js_array_get_f64+0x6f8>
1007bed4c:     	mov	x0, x20
1007bed50:     	mov	w1, #0x1                ; =1
1007bed54:     	bl	0x100b4a8c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bed58:     	mov	x20, x0
1007bed5c:     	cbnz	x0, 0x1007be610 <_js_array_get_f64+0x2c0>
1007bed60:     	b	0x1007bea48 <_js_array_get_f64+0x6f8>
1007bed64:     	mov	w0, #0x1                ; =1
1007bed68:     	mov	x1, x22
1007bed6c:     	bl	0x100b12d40 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
