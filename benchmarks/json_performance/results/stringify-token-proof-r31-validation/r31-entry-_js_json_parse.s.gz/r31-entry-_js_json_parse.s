
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-token-proof-r31/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100844ad4 <_js_json_parse>:
100844ad4:     	stp	x29, x30, [sp, #-0x10]!
100844ad8:     	mov	x29, sp
100844adc:     	cbz	x0, 0x100844b34 <_js_json_parse+0x60>
100844ae0:     	ldr	w1, [x0, #0x4]
100844ae4:     	cmp	w1, #0x2
100844ae8:     	b.eq	0x100844af8 <_js_json_parse+0x24>
100844aec:     	cbz	w1, 0x100844b34 <_js_json_parse+0x60>
100844af0:     	ldrb	w8, [x0, #0x14]
100844af4:     	b	0x100844b18 <_js_json_parse+0x44>
100844af8:     	ldrb	w8, [x0, #0x14]
100844afc:     	cmp	w8, #0x7b
100844b00:     	b.ne	0x100844b18 <_js_json_parse+0x44>
100844b04:     	ldrb	w8, [x0, #0x15]
100844b08:     	cmp	w8, #0x7d
100844b0c:     	b.ne	0x100844b24 <_js_json_parse+0x50>
100844b10:     	ldp	x29, x30, [sp], #0x10
100844b14:     	b	0x1004ec900 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100844b18:     	orr	w8, w8, #0x20
100844b1c:     	cmp	w8, #0x7b
100844b20:     	b.ne	0x100844b2c <_js_json_parse+0x58>
100844b24:     	ldp	x29, x30, [sp], #0x10
100844b28:     	b	0x100505f48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
100844b2c:     	ldp	x29, x30, [sp], #0x10
100844b30:     	b	0x1005085c4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100844b34:     	adrp	x0, 0x100c76000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x74dc>
100844b38:     	add	x0, x0, #0x1
100844b3c:     	mov	w1, #0x1c               ; =28
100844b40:     	bl	0x1005089f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
