
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/stringify-token-proof-r31/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001008457ec <_js_json_stringify>:
1008457ec:     	sub	sp, sp, #0x80
1008457f0:     	stp	d9, d8, [sp, #0x20]
1008457f4:     	stp	x26, x25, [sp, #0x30]
1008457f8:     	stp	x24, x23, [sp, #0x40]
1008457fc:     	stp	x22, x21, [sp, #0x50]
100845800:     	stp	x20, x19, [sp, #0x60]
100845804:     	stp	x29, x30, [sp, #0x70]
100845808:     	add	x29, sp, #0x70
10084580c:     	mov	x21, x0
100845810:     	mov.16b	v8, v0
100845814:     	fmov	x19, d8
100845818:     	and	x20, x19, #0xffff000000000000
10084581c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100845820:     	cmp	x20, x8
100845824:     	b.ne	0x10084584c <_js_json_stringify+0x60>
100845828:     	and	x0, x19, #0xffffffffffff
10084582c:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
100845830:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100845834:     	movk	x9, #0xffef, lsl #16
100845838:     	cmp	x8, x9
10084583c:     	b.hi	0x10084584c <_js_json_stringify+0x60>
100845840:     	ldr	w8, [x0, #0x4]
100845844:     	cmp	w8, #0x40
100845848:     	b.hs	0x1008458bc <_js_json_stringify+0xd0>
10084584c:     	mov.16b	v0, v8
100845850:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100845854:     	tbz	w0, #0x0, 0x100845860 <_js_json_stringify+0x74>
100845858:     	mov	x23, x1
10084585c:     	b	0x100845dd0 <_js_json_stringify+0x5e4>
100845860:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845864:     	cmp	x20, x8
100845868:     	b.ne	0x1008458d0 <_js_json_stringify+0xe4>
10084586c:     	ands	x19, x19, #0xffffffffffff
100845870:     	b.eq	0x1008458d0 <_js_json_stringify+0xe4>
100845874:     	mov	x0, x19
100845878:     	bl	0x10050f2f8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084587c:     	cbz	w0, 0x1008458d0 <_js_json_stringify+0xe4>
100845880:     	ldurb	w8, [x19, #-0x8]
100845884:     	cmp	w8, #0x9
100845888:     	b.ne	0x1008458d0 <_js_json_stringify+0xe4>
10084588c:     	ldr	w8, [x19, #0x4]
100845890:     	mov	w9, #0x5841             ; =22593
100845894:     	movk	w9, #0x4c5a, lsl #16
100845898:     	cmp	w8, w9
10084589c:     	b.ne	0x1008458d0 <_js_json_stringify+0xe4>
1008458a0:     	mov	x0, x19
1008458a4:     	bl	0x1006887e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1008458a8:     	cbz	x0, 0x1008458d0 <_js_json_stringify+0xe4>
1008458ac:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008458b0:     	bfxil	x8, x0, #0, #48
1008458b4:     	fmov	d8, x8
1008458b8:     	b	0x1008458d0 <_js_json_stringify+0xe4>
1008458bc:     	bl	0x1004f2ca8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
1008458c0:     	tbnz	w0, #0x0, 0x100845858 <_js_json_stringify+0x6c>
1008458c4:     	mov.16b	v0, v8
1008458c8:     	bl	0x1004edd7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
1008458cc:     	tbnz	w0, #0x0, 0x100845858 <_js_json_stringify+0x6c>
1008458d0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008458d4:     	add	x0, x0, #0xd78
1008458d8:     	ldr	x8, [x0]
1008458dc:     	blr	x8
1008458e0:     	mov	x19, x0
1008458e4:     	ldr	w26, [x0]
1008458e8:     	add	w8, w26, #0x1
1008458ec:     	str	w8, [x0]
1008458f0:     	cbz	w26, 0x100845960 <_js_json_stringify+0x174>
1008458f4:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008458f8:     	add	x0, x0, #0xd00
1008458fc:     	ldr	x8, [x0]
100845900:     	blr	x8
100845904:     	ldrb	w8, [x0, #0x20]
100845908:     	cmp	w8, #0x1
10084590c:     	b.ne	0x100845ec4 <_js_json_stringify+0x6d8>
100845910:     	ldr	x8, [x0]
100845914:     	cbnz	x8, 0x100845ed0 <_js_json_stringify+0x6e4>
100845918:     	mov	x8, #-0x1               ; =-1
10084591c:     	str	x8, [x0]
100845920:     	ldr	x20, [x0, #0x18]
100845924:     	ldr	x8, [x0, #0x8]
100845928:     	cmp	x20, x8
10084592c:     	b.eq	0x100845df4 <_js_json_stringify+0x608>
100845930:     	ldr	x8, [x0, #0x10]
100845934:     	mov	w9, #0x18               ; =24
100845938:     	madd	x8, x20, x9, x8
10084593c:     	mov	w9, #0x8                ; =8
100845940:     	stp	xzr, x9, [x8]
100845944:     	str	xzr, [x8, #0x10]
100845948:     	add	x8, x20, #0x1
10084594c:     	str	x8, [x0, #0x18]
100845950:     	ldr	x8, [x0]
100845954:     	add	x8, x8, #0x1
100845958:     	str	x8, [x0]
10084595c:     	b	0x1008459ec <_js_json_stringify+0x200>
100845960:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845964:     	add	x0, x0, #0xdc0
100845968:     	ldr	x8, [x0]
10084596c:     	blr	x8
100845970:     	strb	wzr, [x0]
100845974:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845978:     	add	x0, x0, #0xdf0
10084597c:     	ldr	x8, [x0]
100845980:     	blr	x8
100845984:     	strb	wzr, [x0]
100845988:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
10084598c:     	ldr	w20, [x8, #0x5a8]
100845990:     	cmp	w20, #0x300
100845994:     	b.hs	0x100845e50 <_js_json_stringify+0x664>
100845998:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
10084599c:     	ldr	x8, [x8, #0x48]
1008459a0:     	cmn	x8, #0x1
1008459a4:     	b.eq	0x100845e40 <_js_json_stringify+0x654>
1008459a8:     	mrs	x9, TPIDRRO_EL0
1008459ac:     	and	x9, x9, #0xfffffffffffffff8
1008459b0:     	ldr	x0, [x9, x8, lsl #3]
1008459b4:     	cbz	x0, 0x100845e40 <_js_json_stringify+0x654>
1008459b8:     	add	x8, x0, x20, lsl #3
1008459bc:     	ldr	x0, [x8, #0x1e8]
1008459c0:     	cbz	x0, 0x100845e50 <_js_json_stringify+0x664>
1008459c4:     	str	xzr, [x0]
1008459c8:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008459cc:     	add	x0, x0, #0xd90
1008459d0:     	ldr	x8, [x0]
1008459d4:     	blr	x8
1008459d8:     	ldrb	w8, [x0, #0x20]
1008459dc:     	cbnz	w8, 0x100845edc <_js_json_stringify+0x6f0>
1008459e0:     	ldr	x8, [x0]
1008459e4:     	cbnz	x8, 0x100845f04 <_js_json_stringify+0x718>
1008459e8:     	str	xzr, [x0, #0x18]
1008459ec:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008459f0:     	add	x0, x0, #0xd30
1008459f4:     	ldr	x8, [x0]
1008459f8:     	blr	x8
1008459fc:     	mov	x20, x0
100845a00:     	ldrb	w8, [x0, #0x18]
100845a04:     	cmp	w8, #0x1
100845a08:     	b.ne	0x100845e60 <_js_json_stringify+0x674>
100845a0c:     	ldr	x8, [x0]
100845a10:     	mov	x9, #-0x1               ; =-1
100845a14:     	str	x9, [x0]
100845a18:     	cmn	x8, #0x2
100845a1c:     	b.eq	0x100845f10 <_js_json_stringify+0x724>
100845a20:     	cmn	x8, #0x1
100845a24:     	b.eq	0x100845a38 <_js_json_stringify+0x24c>
100845a28:     	add	x9, sp, #0x8
100845a2c:     	ldur	q0, [x0, #0x8]
100845a30:     	stur	q0, [x9, #0x8]
100845a34:     	b	0x100845a44 <_js_json_stringify+0x258>
100845a38:     	mov	x8, #0x0                ; =0
100845a3c:     	mov	w9, #0x1                ; =1
100845a40:     	stp	x9, xzr, [sp, #0x10]
100845a44:     	str	x8, [sp, #0x8]
100845a48:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100845a4c:     	add	x0, x0, #0xd18
100845a50:     	ldr	x8, [x0]
100845a54:     	blr	x8
100845a58:     	ldrb	w8, [x0, #0x20]
100845a5c:     	cbnz	w8, 0x100845e90 <_js_json_stringify+0x6a4>
100845a60:     	ldr	x8, [x0]
100845a64:     	cbnz	x8, 0x100845eb8 <_js_json_stringify+0x6cc>
100845a68:     	str	xzr, [x0, #0x18]
100845a6c:     	add	x1, sp, #0x8
100845a70:     	mov.16b	v0, v8
100845a74:     	mov	x0, x21
100845a78:     	bl	0x10050973c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100845a7c:     	ldp	x21, x22, [sp, #0x10]
100845a80:     	cmp	w22, #0x80, lsl #12     ; =0x80000
100845a84:     	b.hs	0x100845b44 <_js_json_stringify+0x358>
100845a88:     	cmp	x22, #0x40
100845a8c:     	b.hs	0x100845c08 <_js_json_stringify+0x41c>
100845a90:     	ands	x9, x22, #0x38
100845a94:     	b.eq	0x100845ab8 <_js_json_stringify+0x2cc>
100845a98:     	and	x8, x22, #0x38
100845a9c:     	neg	x8, x8
100845aa0:     	mov	x10, x21
100845aa4:     	ldr	x11, [x10], #0x8
100845aa8:     	tst	x11, #0x8080808080808080
100845aac:     	b.ne	0x100845b2c <_js_json_stringify+0x340>
100845ab0:     	adds	x8, x8, #0x8
100845ab4:     	b.ne	0x100845aa4 <_js_json_stringify+0x2b8>
100845ab8:     	and	x8, x22, #0x7
100845abc:     	cbz	x8, 0x100845c8c <_js_json_stringify+0x4a0>
100845ac0:     	add	x9, x21, x9
100845ac4:     	ldrsb	w10, [x9]
100845ac8:     	tbnz	w10, #0x1f, 0x100845b2c <_js_json_stringify+0x340>
100845acc:     	cmp	x8, #0x1
100845ad0:     	b.eq	0x100845c8c <_js_json_stringify+0x4a0>
100845ad4:     	ldrsb	w10, [x9, #0x1]
100845ad8:     	tbnz	w10, #0x1f, 0x100845b2c <_js_json_stringify+0x340>
100845adc:     	cmp	x8, #0x2
100845ae0:     	b.eq	0x100845c8c <_js_json_stringify+0x4a0>
100845ae4:     	ldrsb	w10, [x9, #0x2]
100845ae8:     	tbnz	w10, #0x1f, 0x100845b2c <_js_json_stringify+0x340>
100845aec:     	cmp	x8, #0x3
100845af0:     	b.eq	0x100845c8c <_js_json_stringify+0x4a0>
100845af4:     	ldrsb	w10, [x9, #0x3]
100845af8:     	tbnz	w10, #0x1f, 0x100845b2c <_js_json_stringify+0x340>
100845afc:     	cmp	x8, #0x4
100845b00:     	b.eq	0x100845c8c <_js_json_stringify+0x4a0>
100845b04:     	ldrsb	w10, [x9, #0x4]
100845b08:     	tbnz	w10, #0x1f, 0x100845b2c <_js_json_stringify+0x340>
100845b0c:     	cmp	x8, #0x5
100845b10:     	b.eq	0x100845c8c <_js_json_stringify+0x4a0>
100845b14:     	ldrsb	w10, [x9, #0x5]
100845b18:     	tbnz	w10, #0x1f, 0x100845b2c <_js_json_stringify+0x340>
100845b1c:     	cmp	x8, #0x6
100845b20:     	b.eq	0x100845c8c <_js_json_stringify+0x4a0>
100845b24:     	ldrsb	w8, [x9, #0x6]
100845b28:     	tbz	w8, #0x1f, 0x100845c8c <_js_json_stringify+0x4a0>
100845b2c:     	mov	x0, x21
100845b30:     	mov	x1, x22
100845b34:     	mov	x2, x22
100845b38:     	bl	0x1008dd1c0 <_js_string_from_bytes_with_capacity>
100845b3c:     	mov	x23, x0
100845b40:     	b	0x100845d88 <_js_json_stringify+0x59c>
100845b44:     	and	x8, x22, #0x7fffffffffffffc0
100845b48:     	add	x8, x21, x8
100845b4c:     	mov	x9, x21
100845b50:     	ldp	q0, q1, [x9]
100845b54:     	ldp	q2, q3, [x9, #0x20]
100845b58:     	orr.16b	v0, v1, v0
100845b5c:     	orr.16b	v1, v2, v3
100845b60:     	orr.16b	v0, v0, v1
100845b64:     	umaxv.16b	b0, v0
100845b68:     	fmov	w10, s0
100845b6c:     	tbnz	w10, #0x7, 0x100845bcc <_js_json_stringify+0x3e0>
100845b70:     	add	x9, x9, #0x40
100845b74:     	cmp	x9, x8
100845b78:     	b.ne	0x100845b50 <_js_json_stringify+0x364>
100845b7c:     	ands	x9, x22, #0x30
100845b80:     	b.eq	0x100845ba4 <_js_json_stringify+0x3b8>
100845b84:     	mov	x10, x9
100845b88:     	mov	x11, x8
100845b8c:     	ldr	q0, [x11], #0x10
100845b90:     	umaxv.16b	b0, v0
100845b94:     	fmov	w12, s0
100845b98:     	tbnz	w12, #0x7, 0x100845bcc <_js_json_stringify+0x3e0>
100845b9c:     	subs	x10, x10, #0x10
100845ba0:     	b.ne	0x100845b8c <_js_json_stringify+0x3a0>
100845ba4:     	and	x10, x22, #0xf
100845ba8:     	cbz	x10, 0x100845bc4 <_js_json_stringify+0x3d8>
100845bac:     	add	x8, x8, x9
100845bb0:     	ldrsb	w9, [x8]
100845bb4:     	tbnz	w9, #0x1f, 0x100845bcc <_js_json_stringify+0x3e0>
100845bb8:     	add	x8, x8, #0x1
100845bbc:     	subs	x10, x10, #0x1
100845bc0:     	b.ne	0x100845bb0 <_js_json_stringify+0x3c4>
100845bc4:     	mov	w24, w22
100845bc8:     	b	0x100845c00 <_js_json_stringify+0x414>
100845bcc:     	mov	w24, w22
100845bd0:     	cbz	x24, 0x100845c00 <_js_json_stringify+0x414>
100845bd4:     	mov	x8, x21
100845bd8:     	ands	x9, x22, #0x3
100845bdc:     	b.eq	0x100845bf8 <_js_json_stringify+0x40c>
100845be0:     	mov	x8, x21
100845be4:     	ldrsb	w10, [x8]
100845be8:     	tbnz	w10, #0x1f, 0x100845cf0 <_js_json_stringify+0x504>
100845bec:     	add	x8, x8, #0x1
100845bf0:     	subs	x9, x9, #0x1
100845bf4:     	b.ne	0x100845be4 <_js_json_stringify+0x3f8>
100845bf8:     	cmp	x24, #0x4
100845bfc:     	b.hs	0x100845cbc <_js_json_stringify+0x4d0>
100845c00:     	mov	x25, x22
100845c04:     	b	0x100845d00 <_js_json_stringify+0x514>
100845c08:     	and	x8, x22, #0x7fffffffffffffc0
100845c0c:     	and	x8, x8, #0xffffffff0007ffff
100845c10:     	add	x8, x21, x8
100845c14:     	mov	x9, x21
100845c18:     	ldp	q0, q1, [x9]
100845c1c:     	ldp	q2, q3, [x9, #0x20]
100845c20:     	orr.16b	v0, v1, v0
100845c24:     	orr.16b	v1, v2, v3
100845c28:     	orr.16b	v0, v0, v1
100845c2c:     	umaxv.16b	b0, v0
100845c30:     	fmov	w10, s0
100845c34:     	tbnz	w10, #0x7, 0x100845b2c <_js_json_stringify+0x340>
100845c38:     	add	x9, x9, #0x40
100845c3c:     	cmp	x9, x8
100845c40:     	b.ne	0x100845c18 <_js_json_stringify+0x42c>
100845c44:     	ands	x9, x22, #0x30
100845c48:     	b.eq	0x100845c6c <_js_json_stringify+0x480>
100845c4c:     	mov	x10, x9
100845c50:     	mov	x11, x8
100845c54:     	ldr	q0, [x11], #0x10
100845c58:     	umaxv.16b	b0, v0
100845c5c:     	fmov	w12, s0
100845c60:     	tbnz	w12, #0x7, 0x100845b2c <_js_json_stringify+0x340>
100845c64:     	subs	x10, x10, #0x10
100845c68:     	b.ne	0x100845c54 <_js_json_stringify+0x468>
100845c6c:     	and	x10, x22, #0xf
100845c70:     	cbz	x10, 0x100845c8c <_js_json_stringify+0x4a0>
100845c74:     	add	x8, x8, x9
100845c78:     	ldrsb	w9, [x8]
100845c7c:     	tbnz	w9, #0x1f, 0x100845b2c <_js_json_stringify+0x340>
100845c80:     	add	x8, x8, #0x1
100845c84:     	subs	x10, x10, #0x1
100845c88:     	b.ne	0x100845c78 <_js_json_stringify+0x48c>
100845c8c:     	mov	x0, x22
100845c90:     	bl	0x10034b1ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100845c94:     	mov	x23, x0
100845c98:     	stp	w22, w22, [x0]
100845c9c:     	stp	wzr, wzr, [x0, #0xc]
100845ca0:     	str	w22, [x0, #0x8]
100845ca4:     	cbz	w22, 0x100845d88 <_js_json_stringify+0x59c>
100845ca8:     	and	x2, x22, #0x7ffff
100845cac:     	mov	x0, x1
100845cb0:     	mov	x1, x21
100845cb4:     	bl	0x100b6286c <_writev+0x100b6286c>
100845cb8:     	b	0x100845d88 <_js_json_stringify+0x59c>
100845cbc:     	add	x9, x21, x24
100845cc0:     	ldrsb	w10, [x8]
100845cc4:     	tbnz	w10, #0x1f, 0x100845cf0 <_js_json_stringify+0x504>
100845cc8:     	ldrsb	w10, [x8, #0x1]
100845ccc:     	tbnz	w10, #0x1f, 0x100845cf0 <_js_json_stringify+0x504>
100845cd0:     	ldrsb	w10, [x8, #0x2]
100845cd4:     	tbnz	w10, #0x1f, 0x100845cf0 <_js_json_stringify+0x504>
100845cd8:     	ldrsb	w10, [x8, #0x3]
100845cdc:     	tbnz	w10, #0x1f, 0x100845cf0 <_js_json_stringify+0x504>
100845ce0:     	add	x8, x8, #0x4
100845ce4:     	cmp	x8, x9
100845ce8:     	b.ne	0x100845cc0 <_js_json_stringify+0x4d4>
100845cec:     	b	0x100845c00 <_js_json_stringify+0x414>
100845cf0:     	mov	w1, w22
100845cf4:     	mov	x0, x21
100845cf8:     	bl	0x1005eaae0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
100845cfc:     	mov	x25, x0
100845d00:     	bl	0x1004eff00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100845d04:     	add	x0, x24, #0x14
100845d08:     	mov	w1, #0x3                ; =3
100845d0c:     	bl	0x100458380 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
100845d10:     	mov	x23, x0
100845d14:     	stp	w25, w22, [x0]
100845d18:     	stp	wzr, wzr, [x0, #0xc]
100845d1c:     	str	w22, [x0, #0x8]
100845d20:     	add	x0, x0, #0x14
100845d24:     	mov	x1, x21
100845d28:     	mov	x2, x24
100845d2c:     	bl	0x100b6286c <_writev+0x100b6286c>
100845d30:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100845d34:     	ldr	w21, [x8, #0x590]
100845d38:     	cmp	w21, #0x300
100845d3c:     	b.hs	0x100845e18 <_js_json_stringify+0x62c>
100845d40:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100845d44:     	ldr	x8, [x8, #0x48]
100845d48:     	cmn	x8, #0x1
100845d4c:     	b.eq	0x100845e08 <_js_json_stringify+0x61c>
100845d50:     	mrs	x9, TPIDRRO_EL0
100845d54:     	and	x9, x9, #0xfffffffffffffff8
100845d58:     	ldr	x0, [x9, x8, lsl #3]
100845d5c:     	cbz	x0, 0x100845e08 <_js_json_stringify+0x61c>
100845d60:     	add	x8, x0, x21, lsl #3
100845d64:     	ldr	x0, [x8, #0x1e8]
100845d68:     	cbz	x0, 0x100845e18 <_js_json_stringify+0x62c>
100845d6c:     	ldr	x8, [x0]
100845d70:     	adds	x8, x8, x24
100845d74:     	csinv	x8, x8, xzr, lo
100845d78:     	str	x8, [x0]
100845d7c:     	lsr	x8, x8, #25
100845d80:     	cbz	x8, 0x100845d88 <_js_json_stringify+0x59c>
100845d84:     	bl	0x10045f2b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100845d88:     	ldp	x22, x21, [sp, #0x8]
100845d8c:     	ldrb	w8, [x20, #0x18]
100845d90:     	cmp	w8, #0x1
100845d94:     	b.ne	0x100845e70 <_js_json_stringify+0x684>
100845d98:     	ldp	x8, x0, [x20]
100845d9c:     	stp	x22, x21, [x20]
100845da0:     	str	xzr, [x20, #0x10]
100845da4:     	sub	x8, x8, #0x1
100845da8:     	cmn	x8, #0x2
100845dac:     	b.hs	0x100845db4 <_js_json_stringify+0x5c8>
100845db0:     	bl	0x100b5f9c0 <_mi_free>
100845db4:     	cbz	w26, 0x100845dc0 <_js_json_stringify+0x5d4>
100845db8:     	bl	0x1003280e8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100845dbc:     	b	0x100845dc4 <_js_json_stringify+0x5d8>
100845dc0:     	bl	0x100327f18 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100845dc4:     	ldr	w8, [x19]
100845dc8:     	sub	w8, w8, #0x1
100845dcc:     	str	w8, [x19]
100845dd0:     	mov	x0, x23
100845dd4:     	ldp	x29, x30, [sp, #0x70]
100845dd8:     	ldp	x20, x19, [sp, #0x60]
100845ddc:     	ldp	x22, x21, [sp, #0x50]
100845de0:     	ldp	x24, x23, [sp, #0x40]
100845de4:     	ldp	x26, x25, [sp, #0x30]
100845de8:     	ldp	d9, d8, [sp, #0x20]
100845dec:     	add	sp, sp, #0x80
100845df0:     	ret
100845df4:     	mov	x22, x0
100845df8:     	add	x0, x0, #0x8
100845dfc:     	bl	0x100b3c710 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100845e00:     	mov	x0, x22
100845e04:     	b	0x100845930 <_js_json_stringify+0x144>
100845e08:     	bl	0x100b3fdbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100845e0c:     	add	x8, x0, x21, lsl #3
100845e10:     	ldr	x0, [x8, #0x1e8]
100845e14:     	cbnz	x0, 0x100845d6c <_js_json_stringify+0x580>
100845e18:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100845e1c:     	add	x0, x0, #0x78
100845e20:     	bl	0x100b3d5dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100845e24:     	ldr	x8, [x0]
100845e28:     	adds	x8, x8, x24
100845e2c:     	csinv	x8, x8, xzr, lo
100845e30:     	str	x8, [x0]
100845e34:     	lsr	x8, x8, #25
100845e38:     	cbnz	x8, 0x100845d84 <_js_json_stringify+0x598>
100845e3c:     	b	0x100845d88 <_js_json_stringify+0x59c>
100845e40:     	bl	0x100b3fdbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100845e44:     	add	x8, x0, x20, lsl #3
100845e48:     	ldr	x0, [x8, #0x1e8]
100845e4c:     	cbnz	x0, 0x1008459c4 <_js_json_stringify+0x1d8>
100845e50:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100845e54:     	add	x0, x0, #0x138
100845e58:     	bl	0x100b3d5dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100845e5c:     	b	0x1008459c4 <_js_json_stringify+0x1d8>
100845e60:     	mov	x0, x20
100845e64:     	bl	0x100b1ef44 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100845e68:     	cbnz	x0, 0x100845a0c <_js_json_stringify+0x220>
100845e6c:     	b	0x100845f10 <_js_json_stringify+0x724>
100845e70:     	mov	x0, x20
100845e74:     	bl	0x100b1ef44 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100845e78:     	mov	x20, x0
100845e7c:     	cbnz	x0, 0x100845d98 <_js_json_stringify+0x5ac>
100845e80:     	cbz	x22, 0x100845f10 <_js_json_stringify+0x724>
100845e84:     	mov	x0, x21
100845e88:     	bl	0x100b5f9c0 <_mi_free>
100845e8c:     	b	0x100845f10 <_js_json_stringify+0x724>
100845e90:     	cmp	w8, #0x2
100845e94:     	b.eq	0x100845f10 <_js_json_stringify+0x724>
100845e98:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100845e9c:     	add	x1, x1, #0xff8
100845ea0:     	mov	x22, x0
100845ea4:     	bl	0x100a20e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845ea8:     	mov	x0, x22
100845eac:     	strb	wzr, [x22, #0x20]
100845eb0:     	ldr	x8, [x22]
100845eb4:     	cbz	x8, 0x100845a68 <_js_json_stringify+0x27c>
100845eb8:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845ebc:     	add	x0, x0, #0xdb8
100845ec0:     	bl	0x100b130ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845ec4:     	bl	0x100b1f0a4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100845ec8:     	cbnz	x0, 0x100845910 <_js_json_stringify+0x124>
100845ecc:     	b	0x100845f10 <_js_json_stringify+0x724>
100845ed0:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100845ed4:     	add	x0, x0, #0x440
100845ed8:     	bl	0x100b130ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845edc:     	cmp	w8, #0x1
100845ee0:     	b.ne	0x100845f10 <_js_json_stringify+0x724>
100845ee4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100845ee8:     	add	x1, x1, #0x998
100845eec:     	mov	x20, x0
100845ef0:     	bl	0x100a20e1c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100845ef4:     	mov	x0, x20
100845ef8:     	strb	wzr, [x20, #0x20]
100845efc:     	ldr	x8, [x20]
100845f00:     	cbz	x8, 0x1008459e8 <_js_json_stringify+0x1fc>
100845f04:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100845f08:     	add	x0, x0, #0xd88
100845f0c:     	bl	0x100b130ec <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100845f10:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100845f14:     	add	x0, x0, #0xc18
100845f18:     	bl	0x100b5901c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
