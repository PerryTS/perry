
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/isolated-json-scan-chunks-r36/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100245fec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow>:
100245fec:     	sub	sp, sp, #0xa0
100245ff0:     	stp	x28, x27, [sp, #0x40]
100245ff4:     	stp	x26, x25, [sp, #0x50]
100245ff8:     	stp	x24, x23, [sp, #0x60]
100245ffc:     	stp	x22, x21, [sp, #0x70]
100246000:     	stp	x20, x19, [sp, #0x80]
100246004:     	stp	x29, x30, [sp, #0x90]
100246008:     	add	x29, sp, #0x90
10024600c:     	ldp	x20, x22, [x1, #0x68]
100246010:     	subs	x23, x22, x2
100246014:     	b.lo	0x100246d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd5c>
100246018:     	cmp	x22, x20
10024601c:     	b.hi	0x100246d48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd5c>
100246020:     	tbz	x23, #0x3f, 0x100246034 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x48>
100246024:     	mov	x24, #0x0               ; =0
100246028:     	mov	x0, x24
10024602c:     	mov	x1, x23
100246030:     	bl	0x100b115c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100246034:     	ldr	x25, [x1, #0x60]
100246038:     	cmp	x22, x2
10024603c:     	stp	x0, x1, [sp, #0x10]
100246040:     	b.ne	0x100246054 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x68>
100246044:     	mov	w8, #0x1                ; =1
100246048:     	stp	x23, x8, [sp, #0x20]
10024604c:     	str	xzr, [sp, #0x30]
100246050:     	b	0x100246084 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x98>
100246054:     	mov	x19, x2
100246058:     	mov	w24, #0x1               ; =1
10024605c:     	mov	x0, x23
100246060:     	mov	w1, #0x1                ; =1
100246064:     	bl	0x100b5e4c8 <_mi_malloc_aligned>
100246068:     	cbz	x0, 0x100246028 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3c>
10024606c:     	stp	x23, x0, [sp, #0x20]
100246070:     	add	x1, x25, x19
100246074:     	mov	x2, x23
100246078:     	bl	0x100b610ec <_writev+0x100b610ec>
10024607c:     	str	x23, [sp, #0x30]
100246080:     	ldr	x1, [sp, #0x18]
100246084:     	mov	x26, #-0x101010101010102 ; =-72340172838076674
100246088:     	movk	x26, #0xfeff
10024608c:     	adds	x8, x22, #0x40
100246090:     	csinv	x8, x8, xzr, lo
100246094:     	cmp	x8, x20
100246098:     	csel	x19, x8, x20, lo
10024609c:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
1002460a0:     	orr	x14, x14, #0x4444444444444444
1002460a4:     	mov	x28, #-0x2020202020202021 ; =-2314885530818453537
1002460a8:     	movk	x28, #0xdfe0
1002460ac:     	mov	w8, #0xdc00             ; =56320
1002460b0:     	movk	w8, #0x370, lsl #16
1002460b4:     	sub	w8, w8, #0x100, lsl #12 ; =0x100000
1002460b8:     	str	w8, [sp, #0xc]
1002460bc:     	b	0x1002460d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xe4>
1002460c0:     	ldr	x8, [sp, #0x28]
1002460c4:     	strb	w21, [x8, x23]
1002460c8:     	add	x8, x23, #0x1
1002460cc:     	str	x8, [sp, #0x30]
1002460d0:     	cmp	x22, x19
1002460d4:     	b.lo	0x1002466b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6cc>
1002460d8:     	sub	x8, x20, x22
1002460dc:     	cmp	x8, #0x40
1002460e0:     	b.lo	0x1002466a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6b4>
1002460e4:     	ldp	x16, x19, [sp, #0x28]
1002460e8:     	b	0x100246108 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x11c>
1002460ec:     	mov	x24, #0x0               ; =0
1002460f0:     	str	x22, [x1, #0x70]
1002460f4:     	add	x19, x24, x19
1002460f8:     	str	x19, [sp, #0x30]
1002460fc:     	sub	x8, x20, x22
100246100:     	cmp	x8, #0x40
100246104:     	b.lo	0x1002466a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6b4>
100246108:     	ldr	x8, [sp, #0x20]
10024610c:     	sub	x8, x8, x19
100246110:     	cmp	x8, #0x3f
100246114:     	b.ls	0x1002466a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6b4>
100246118:     	cmn	x22, #0x35
10024611c:     	b.hi	0x1002460ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x100>
100246120:     	mov	x24, #0x0               ; =0
100246124:     	add	x21, x16, x19
100246128:     	add	x27, x22, #0x34
10024612c:     	mov	x8, x22
100246130:     	b	0x100246144 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x158>
100246134:     	mov	x22, x8
100246138:     	mov	x8, x22
10024613c:     	cmp	x22, x27
100246140:     	b.hs	0x1002460f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x104>
100246144:     	ldr	x9, [x25, x8]
100246148:     	eor	x10, x9, #0x2222222222222222
10024614c:     	eor	x11, x9, x14
100246150:     	add	x11, x11, x26
100246154:     	add	x12, x9, x28
100246158:     	orr	x11, x11, x12
10024615c:     	add	x10, x10, x26
100246160:     	orr	x10, x11, x10
100246164:     	bic	x10, x10, x9
100246168:     	and	x10, x10, #0x8080808080808080
10024616c:     	rbit	x10, x10
100246170:     	clz	x10, x10
100246174:     	lsr	x10, x10, #3
100246178:     	cbz	x10, 0x100246230 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x244>
10024617c:     	str	x9, [x21, x24]
100246180:     	add	x24, x10, x24
100246184:     	add	x8, x10, x8
100246188:     	cmp	x8, x27
10024618c:     	b.hs	0x100246698 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x6ac>
100246190:     	cmp	x10, #0x8
100246194:     	b.eq	0x100246134 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x148>
100246198:     	ldrb	w9, [x25, x8]
10024619c:     	add	x22, x8, #0x1
1002461a0:     	cmp	w9, #0x5c
1002461a4:     	b.ne	0x100246240 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x254>
1002461a8:     	ldrb	w9, [x25, x22]
1002461ac:     	add	x22, x8, #0x2
1002461b0:     	cmp	w9, #0x65
1002461b4:     	b.le	0x10024625c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x270>
1002461b8:     	cmp	w9, #0x71
1002461bc:     	b.le	0x100246294 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2a8>
1002461c0:     	cmp	w9, #0x72
1002461c4:     	b.eq	0x1002462c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2d8>
1002461c8:     	cmp	w9, #0x74
1002461cc:     	b.eq	0x1002462ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2c0>
1002461d0:     	cmp	w9, #0x75
1002461d4:     	b.ne	0x100246cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce4>
1002461d8:     	add	x10, x25, x22
1002461dc:     	ldrb	w11, [x10]
1002461e0:     	sub	w9, w11, #0x30
1002461e4:     	cmp	w9, #0xa
1002461e8:     	b.lo	0x1002461fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x210>
1002461ec:     	sub	w9, w11, #0x61
1002461f0:     	cmp	w9, #0x6
1002461f4:     	b.hs	0x1002462dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2f0>
1002461f8:     	sub	w9, w11, #0x57
1002461fc:     	ldrb	w12, [x10, #0x1]
100246200:     	sub	w11, w12, #0x30
100246204:     	cmp	w11, #0xa
100246208:     	b.hs	0x1002462fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x310>
10024620c:     	ldrb	w13, [x10, #0x2]
100246210:     	sub	w12, w13, #0x30
100246214:     	cmp	w12, #0xa
100246218:     	b.hs	0x10024631c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x330>
10024621c:     	ldrb	w10, [x10, #0x3]
100246220:     	sub	w13, w10, #0x30
100246224:     	cmp	w13, #0xa
100246228:     	b.lo	0x1002463a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3bc>
10024622c:     	b	0x100246384 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x398>
100246230:     	and	w9, w9, #0xff
100246234:     	add	x22, x8, #0x1
100246238:     	cmp	w9, #0x5c
10024623c:     	b.eq	0x1002461a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x1bc>
100246240:     	cmp	w9, #0x22
100246244:     	b.eq	0x100246cf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd0c>
100246248:     	cmp	w9, #0x20
10024624c:     	b.lo	0x100246cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce4>
100246250:     	strb	w9, [x21, x24]
100246254:     	add	x24, x24, #0x1
100246258:     	b	0x100246138 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x14c>
10024625c:     	cmp	w9, #0x5b
100246260:     	b.gt	0x10024627c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x290>
100246264:     	cmp	w9, #0x22
100246268:     	b.eq	0x1002462b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2c8>
10024626c:     	cmp	w9, #0x2f
100246270:     	b.ne	0x100246cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce4>
100246274:     	mov	w8, #0x2f               ; =47
100246278:     	b	0x1002462d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2e4>
10024627c:     	cmp	w9, #0x5c
100246280:     	b.eq	0x1002462bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2d0>
100246284:     	cmp	w9, #0x62
100246288:     	b.ne	0x100246cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce4>
10024628c:     	mov	w8, #0x8                ; =8
100246290:     	b	0x1002462d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2e4>
100246294:     	cmp	w9, #0x66
100246298:     	b.eq	0x1002462cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2e0>
10024629c:     	cmp	w9, #0x6e
1002462a0:     	b.ne	0x100246cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce4>
1002462a4:     	mov	w8, #0xa                ; =10
1002462a8:     	b	0x1002462d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2e4>
1002462ac:     	mov	w8, #0x9                ; =9
1002462b0:     	b	0x1002462d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2e4>
1002462b4:     	mov	w8, #0x22               ; =34
1002462b8:     	b	0x1002462d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2e4>
1002462bc:     	mov	w8, #0x5c               ; =92
1002462c0:     	b	0x1002462d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2e4>
1002462c4:     	mov	w8, #0xd                ; =13
1002462c8:     	b	0x1002462d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x2e4>
1002462cc:     	mov	w8, #0xc                ; =12
1002462d0:     	strb	w8, [x21, x24]
1002462d4:     	add	x24, x24, #0x1
1002462d8:     	b	0x100246138 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x14c>
1002462dc:     	sub	w9, w11, #0x41
1002462e0:     	cmp	w9, #0x6
1002462e4:     	b.hs	0x100246cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce4>
1002462e8:     	sub	w9, w11, #0x37
1002462ec:     	ldrb	w12, [x10, #0x1]
1002462f0:     	sub	w11, w12, #0x30
1002462f4:     	cmp	w11, #0xa
1002462f8:     	b.lo	0x10024620c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x220>
1002462fc:     	sub	w11, w12, #0x61
100246300:     	cmp	w11, #0x6
100246304:     	b.hs	0x100246340 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x354>
100246308:     	sub	w11, w12, #0x57
10024630c:     	ldrb	w13, [x10, #0x2]
100246310:     	sub	w12, w13, #0x30
100246314:     	cmp	w12, #0xa
100246318:     	b.lo	0x10024621c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x230>
10024631c:     	sub	w12, w13, #0x61
100246320:     	cmp	w12, #0x6
100246324:     	b.hs	0x100246364 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x378>
100246328:     	sub	w12, w13, #0x57
10024632c:     	ldrb	w10, [x10, #0x3]
100246330:     	sub	w13, w10, #0x30
100246334:     	cmp	w13, #0xa
100246338:     	b.hs	0x100246384 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x398>
10024633c:     	b	0x1002463a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3bc>
100246340:     	sub	w11, w12, #0x41
100246344:     	cmp	w11, #0x5
100246348:     	b.hi	0x100246cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce4>
10024634c:     	sub	w11, w12, #0x37
100246350:     	ldrb	w13, [x10, #0x2]
100246354:     	sub	w12, w13, #0x30
100246358:     	cmp	w12, #0xa
10024635c:     	b.hs	0x10024631c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x330>
100246360:     	b	0x10024621c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x230>
100246364:     	sub	w12, w13, #0x41
100246368:     	cmp	w12, #0x5
10024636c:     	b.hi	0x100246cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce4>
100246370:     	sub	w12, w13, #0x37
100246374:     	ldrb	w10, [x10, #0x3]
100246378:     	sub	w13, w10, #0x30
10024637c:     	cmp	w13, #0xa
100246380:     	b.lo	0x1002463a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3bc>
100246384:     	sub	w13, w10, #0x61
100246388:     	cmp	w13, #0x6
10024638c:     	b.hs	0x100246398 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3ac>
100246390:     	sub	w13, w10, #0x57
100246394:     	b	0x1002463a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3bc>
100246398:     	sub	w13, w10, #0x41
10024639c:     	cmp	w13, #0x5
1002463a0:     	b.hi	0x100246cd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce4>
1002463a4:     	sub	w13, w10, #0x37
1002463a8:     	add	x22, x8, #0x6
1002463ac:     	and	w9, w9, #0xff
1002463b0:     	and	w10, w11, #0xff
1002463b4:     	lsl	w10, w10, #4
1002463b8:     	orr	w10, w10, w9, lsl #8
1002463bc:     	and	w9, w12, #0xff
1002463c0:     	orr	w11, w10, w9
1002463c4:     	lsl	w12, w11, #4
1002463c8:     	and	w9, w13, #0xff
1002463cc:     	orr	w9, w12, w9
1002463d0:     	cmp	w10, #0xd80
1002463d4:     	b.hs	0x100246414 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x428>
1002463d8:     	str	wzr, [sp, #0x3c]
1002463dc:     	and	w8, w12, #0xffff
1002463e0:     	mov	w12, #0xd800            ; =55296
1002463e4:     	movk	w12, #0xffef, lsl #16
1002463e8:     	eor	w8, w8, w12
1002463ec:     	mov	w12, #0x800             ; =2048
1002463f0:     	movk	w12, #0xffef, lsl #16
1002463f4:     	cmp	w8, w12
1002463f8:     	b.lo	0x100246d60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd74>
1002463fc:     	mov	x28, x16
100246400:     	cmp	w11, #0x8
100246404:     	b.hs	0x100246470 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x484>
100246408:     	strb	w9, [sp, #0x3c]
10024640c:     	mov	w23, #0x1               ; =1
100246410:     	b	0x100246640 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x654>
100246414:     	cmp	w11, #0xdbf
100246418:     	b.hi	0x100246498 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4ac>
10024641c:     	cmp	x22, x20
100246420:     	b.hs	0x100246dd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xde8>
100246424:     	ldrb	w11, [x25, x22]
100246428:     	cmp	w11, #0x5c
10024642c:     	b.ne	0x100246610 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x624>
100246430:     	add	x0, x8, #0x7
100246434:     	cmp	x0, x20
100246438:     	b.hs	0x100246de8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xdfc>
10024643c:     	ldrb	w11, [x25, x0]
100246440:     	cmp	w11, #0x75
100246444:     	b.ne	0x100246610 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x624>
100246448:     	add	x12, x25, x8
10024644c:     	ldrb	w13, [x12, #0x8]
100246450:     	sub	w11, w13, #0x30
100246454:     	cmp	w11, #0xa
100246458:     	b.lo	0x1002464d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4e8>
10024645c:     	sub	w11, w13, #0x61
100246460:     	cmp	w11, #0x6
100246464:     	b.hs	0x1002464c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4d8>
100246468:     	sub	w11, w13, #0x57
10024646c:     	b	0x1002464d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4e8>
100246470:     	mov	w8, #-0x80              ; =-128
100246474:     	bfxil	w8, w9, #0, #6
100246478:     	cmp	w10, #0x80
10024647c:     	b.hs	0x1002464a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x4bc>
100246480:     	lsr	w9, w9, #6
100246484:     	orr	w9, w9, #0xc0
100246488:     	strb	w9, [sp, #0x3c]
10024648c:     	strb	w8, [sp, #0x3d]
100246490:     	mov	w23, #0x2               ; =2
100246494:     	b	0x100246640 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x654>
100246498:     	str	wzr, [sp, #0x3c]
10024649c:     	cmp	w10, #0xe00
1002464a0:     	b.hs	0x1002463dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x3f0>
1002464a4:     	b	0x100246614 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x628>
1002464a8:     	lsr	w10, w10, #8
1002464ac:     	mov	w11, #0x80              ; =128
1002464b0:     	orr	w10, w10, #0xe0
1002464b4:     	strb	w10, [sp, #0x3c]
1002464b8:     	bfxil	w11, w9, #6, #6
1002464bc:     	strb	w11, [sp, #0x3d]
1002464c0:     	b	0x100246638 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x64c>
1002464c4:     	sub	w11, w13, #0x41
1002464c8:     	cmp	w11, #0x6
1002464cc:     	b.hs	0x100246610 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x624>
1002464d0:     	sub	w11, w13, #0x37
1002464d4:     	ldrb	w14, [x12, #0x9]
1002464d8:     	sub	w13, w14, #0x30
1002464dc:     	cmp	w13, #0xa
1002464e0:     	b.lo	0x100246508 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x51c>
1002464e4:     	sub	w13, w14, #0x61
1002464e8:     	cmp	w13, #0x6
1002464ec:     	b.hs	0x1002464f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x50c>
1002464f0:     	sub	w13, w14, #0x57
1002464f4:     	b	0x100246508 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x51c>
1002464f8:     	sub	w13, w14, #0x41
1002464fc:     	cmp	w13, #0x5
100246500:     	b.hi	0x100246610 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x624>
100246504:     	sub	w13, w14, #0x37
100246508:     	ldrb	w15, [x12, #0xa]
10024650c:     	sub	w14, w15, #0x30
100246510:     	cmp	w14, #0xa
100246514:     	b.lo	0x10024653c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x550>
100246518:     	sub	w14, w15, #0x61
10024651c:     	cmp	w14, #0x6
100246520:     	b.hs	0x10024652c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x540>
100246524:     	sub	w14, w15, #0x57
100246528:     	b	0x10024653c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x550>
10024652c:     	sub	w14, w15, #0x41
100246530:     	cmp	w14, #0x5
100246534:     	b.hi	0x100246610 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x624>
100246538:     	sub	w14, w15, #0x37
10024653c:     	ldrb	w15, [x12, #0xb]
100246540:     	sub	w12, w15, #0x30
100246544:     	cmp	w12, #0xa
100246548:     	b.lo	0x100246570 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x584>
10024654c:     	sub	w12, w15, #0x61
100246550:     	cmp	w12, #0x6
100246554:     	b.hs	0x100246560 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x574>
100246558:     	sub	w12, w15, #0x57
10024655c:     	b	0x100246570 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x584>
100246560:     	sub	w12, w15, #0x41
100246564:     	cmp	w12, #0x5
100246568:     	b.hi	0x100246610 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x624>
10024656c:     	sub	w12, w15, #0x37
100246570:     	and	w11, w11, #0xff
100246574:     	and	w13, w13, #0xff
100246578:     	lsl	w13, w13, #4
10024657c:     	orr	w11, w13, w11, lsl #8
100246580:     	and	w13, w14, #0xff
100246584:     	orr	w11, w11, w13
100246588:     	and	w13, w11, #0xfc0
10024658c:     	str	wzr, [sp, #0x3c]
100246590:     	cmp	w13, #0xdc0
100246594:     	b.ne	0x100246614 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x628>
100246598:     	and	w10, w12, #0xff
10024659c:     	orr	w10, w10, w11, lsl #4
1002465a0:     	and	w9, w9, #0xffff
1002465a4:     	lsl	w9, w9, #10
1002465a8:     	add	w11, w9, w10, uxth
1002465ac:     	mov	w9, #0x2400             ; =9216
1002465b0:     	movk	w9, #0xfca0, lsl #16
1002465b4:     	add	w9, w11, w9
1002465b8:     	mov	w12, #0xd800            ; =55296
1002465bc:     	eor	w12, w9, w12
1002465c0:     	mov	w13, #0x800             ; =2048
1002465c4:     	movk	w13, #0xffef, lsl #16
1002465c8:     	add	w12, w12, w13
1002465cc:     	sub	w12, w12, #0x800
1002465d0:     	cmp	w12, w13
1002465d4:     	b.lo	0x100246d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xdb0>
1002465d8:     	mov	x28, x16
1002465dc:     	add	x22, x8, #0xc
1002465e0:     	mov	w8, #-0x80              ; =-128
1002465e4:     	bfxil	w8, w10, #0, #6
1002465e8:     	mov	w10, #-0x80             ; =-128
1002465ec:     	bfxil	w10, w9, #6, #6
1002465f0:     	ldr	w12, [sp, #0xc]
1002465f4:     	cmp	w11, w12
1002465f8:     	b.hs	0x100246670 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x684>
1002465fc:     	lsr	w9, w9, #12
100246600:     	orr	w9, w9, #0xe0
100246604:     	strb	w9, [sp, #0x3c]
100246608:     	strb	w10, [sp, #0x3d]
10024660c:     	b	0x100246638 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x64c>
100246610:     	str	wzr, [sp, #0x3c]
100246614:     	mov	x28, x16
100246618:     	lsr	w8, w10, #8
10024661c:     	orr	w8, w8, #0xe0
100246620:     	strb	w8, [sp, #0x3c]
100246624:     	mov	w8, #0x80               ; =128
100246628:     	bfxil	w8, w9, #6, #6
10024662c:     	strb	w8, [sp, #0x3d]
100246630:     	mov	w8, #0x80               ; =128
100246634:     	bfxil	w8, w9, #0, #6
100246638:     	strb	w8, [sp, #0x3e]
10024663c:     	mov	w23, #0x3               ; =3
100246640:     	add	x0, x21, x24
100246644:     	add	x1, sp, #0x3c
100246648:     	mov	x2, x23
10024664c:     	bl	0x100b610ec <_writev+0x100b610ec>
100246650:     	add	x24, x23, x24
100246654:     	ldr	x1, [sp, #0x18]
100246658:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
10024665c:     	orr	x14, x14, #0x4444444444444444
100246660:     	mov	x16, x28
100246664:     	mov	x28, #-0x2020202020202021 ; =-2314885530818453537
100246668:     	movk	x28, #0xdfe0
10024666c:     	b	0x100246138 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x14c>
100246670:     	lsr	w11, w9, #18
100246674:     	orr	w11, w11, #0xf0
100246678:     	mov	w12, #0x80              ; =128
10024667c:     	strb	w11, [sp, #0x3c]
100246680:     	bfxil	w12, w9, #12, #6
100246684:     	strb	w12, [sp, #0x3d]
100246688:     	strb	w10, [sp, #0x3e]
10024668c:     	strb	w8, [sp, #0x3f]
100246690:     	mov	w23, #0x4               ; =4
100246694:     	b	0x100246640 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x654>
100246698:     	mov	x22, x8
10024669c:     	b	0x1002460f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x104>
1002466a0:     	adds	x8, x22, #0x40
1002466a4:     	csinv	x8, x8, xzr, lo
1002466a8:     	cmp	x8, x20
1002466ac:     	csel	x19, x8, x20, lo
1002466b0:     	cmp	x22, x20
1002466b4:     	b.hs	0x100246cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce8>
1002466b8:     	mov	x8, x22
1002466bc:     	ldrb	w21, [x25, x22]
1002466c0:     	add	x22, x22, #0x1
1002466c4:     	str	x22, [x1, #0x70]
1002466c8:     	cmp	w21, #0x5c
1002466cc:     	b.eq	0x100246708 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x71c>
1002466d0:     	cmp	w21, #0x22
1002466d4:     	b.eq	0x100246d34 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd48>
1002466d8:     	cmp	w21, #0x20
1002466dc:     	b.lo	0x100246cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce8>
1002466e0:     	ldr	x23, [sp, #0x30]
1002466e4:     	ldr	x8, [sp, #0x20]
1002466e8:     	cmp	x23, x8
1002466ec:     	b.ne	0x1002460c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd4>
1002466f0:     	add	x0, sp, #0x20
1002466f4:     	bl	0x100b114a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002466f8:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
1002466fc:     	orr	x14, x14, #0x4444444444444444
100246700:     	ldr	x1, [sp, #0x18]
100246704:     	b	0x1002460c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd4>
100246708:     	cmp	x22, x20
10024670c:     	b.hs	0x100246cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce8>
100246710:     	ldrb	w9, [x25, x22]
100246714:     	add	x22, x8, #0x2
100246718:     	str	x22, [x1, #0x70]
10024671c:     	cmp	w9, #0x65
100246720:     	b.le	0x1002467a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x7b4>
100246724:     	cmp	w9, #0x71
100246728:     	b.le	0x100246828 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x83c>
10024672c:     	cmp	w9, #0x72
100246730:     	b.eq	0x1002468f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x90c>
100246734:     	cmp	w9, #0x74
100246738:     	b.eq	0x100246868 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x87c>
10024673c:     	cmp	w9, #0x75
100246740:     	b.ne	0x100246cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce8>
100246744:     	add	x23, x8, #0x6
100246748:     	cmp	x23, x20
10024674c:     	b.hi	0x100246cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce8>
100246750:     	cmp	x23, x22
100246754:     	b.lo	0x100246d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd80>
100246758:     	add	x10, x25, x22
10024675c:     	ldrb	w11, [x10]
100246760:     	sub	w9, w11, #0x30
100246764:     	cmp	w9, #0xa
100246768:     	b.lo	0x10024677c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x790>
10024676c:     	sub	w9, w11, #0x61
100246770:     	cmp	w9, #0x6
100246774:     	b.hs	0x100246964 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x978>
100246778:     	sub	w9, w11, #0x57
10024677c:     	ldrb	w12, [x10, #0x1]
100246780:     	sub	w11, w12, #0x30
100246784:     	cmp	w11, #0xa
100246788:     	b.lo	0x100246998 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x9ac>
10024678c:     	sub	w11, w12, #0x61
100246790:     	cmp	w11, #0x6
100246794:     	b.hs	0x100246988 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x99c>
100246798:     	sub	w11, w12, #0x57
10024679c:     	b	0x100246998 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x9ac>
1002467a0:     	cmp	w9, #0x5b
1002467a4:     	b.gt	0x1002467e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x7fc>
1002467a8:     	cmp	w9, #0x22
1002467ac:     	b.eq	0x100246898 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8ac>
1002467b0:     	cmp	w9, #0x2f
1002467b4:     	b.ne	0x100246cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce8>
1002467b8:     	ldr	x21, [sp, #0x30]
1002467bc:     	ldr	x8, [sp, #0x20]
1002467c0:     	cmp	x21, x8
1002467c4:     	b.ne	0x1002467dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x7f0>
1002467c8:     	add	x0, sp, #0x20
1002467cc:     	bl	0x100b114a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002467d0:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
1002467d4:     	orr	x14, x14, #0x4444444444444444
1002467d8:     	ldr	x1, [sp, #0x18]
1002467dc:     	ldr	x8, [sp, #0x28]
1002467e0:     	mov	w9, #0x2f               ; =47
1002467e4:     	b	0x100246954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x968>
1002467e8:     	cmp	w9, #0x5c
1002467ec:     	b.eq	0x1002468c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8dc>
1002467f0:     	cmp	w9, #0x62
1002467f4:     	b.ne	0x100246cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce8>
1002467f8:     	ldr	x21, [sp, #0x30]
1002467fc:     	ldr	x8, [sp, #0x20]
100246800:     	cmp	x21, x8
100246804:     	b.ne	0x10024681c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x830>
100246808:     	add	x0, sp, #0x20
10024680c:     	bl	0x100b114a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246810:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100246814:     	orr	x14, x14, #0x4444444444444444
100246818:     	ldr	x1, [sp, #0x18]
10024681c:     	ldr	x8, [sp, #0x28]
100246820:     	mov	w9, #0x8                ; =8
100246824:     	b	0x100246954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x968>
100246828:     	cmp	w9, #0x66
10024682c:     	b.eq	0x100246928 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x93c>
100246830:     	cmp	w9, #0x6e
100246834:     	b.ne	0x100246cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce8>
100246838:     	ldr	x21, [sp, #0x30]
10024683c:     	ldr	x8, [sp, #0x20]
100246840:     	cmp	x21, x8
100246844:     	b.ne	0x10024685c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x870>
100246848:     	add	x0, sp, #0x20
10024684c:     	bl	0x100b114a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246850:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100246854:     	orr	x14, x14, #0x4444444444444444
100246858:     	ldr	x1, [sp, #0x18]
10024685c:     	ldr	x8, [sp, #0x28]
100246860:     	mov	w9, #0xa                ; =10
100246864:     	b	0x100246954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x968>
100246868:     	ldr	x21, [sp, #0x30]
10024686c:     	ldr	x8, [sp, #0x20]
100246870:     	cmp	x21, x8
100246874:     	b.ne	0x10024688c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8a0>
100246878:     	add	x0, sp, #0x20
10024687c:     	bl	0x100b114a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246880:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100246884:     	orr	x14, x14, #0x4444444444444444
100246888:     	ldr	x1, [sp, #0x18]
10024688c:     	ldr	x8, [sp, #0x28]
100246890:     	mov	w9, #0x9                ; =9
100246894:     	b	0x100246954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x968>
100246898:     	ldr	x21, [sp, #0x30]
10024689c:     	ldr	x8, [sp, #0x20]
1002468a0:     	cmp	x21, x8
1002468a4:     	b.ne	0x1002468bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x8d0>
1002468a8:     	add	x0, sp, #0x20
1002468ac:     	bl	0x100b114a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002468b0:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
1002468b4:     	orr	x14, x14, #0x4444444444444444
1002468b8:     	ldr	x1, [sp, #0x18]
1002468bc:     	ldr	x8, [sp, #0x28]
1002468c0:     	mov	w9, #0x22               ; =34
1002468c4:     	b	0x100246954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x968>
1002468c8:     	ldr	x21, [sp, #0x30]
1002468cc:     	ldr	x8, [sp, #0x20]
1002468d0:     	cmp	x21, x8
1002468d4:     	b.ne	0x1002468ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x900>
1002468d8:     	add	x0, sp, #0x20
1002468dc:     	bl	0x100b114a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
1002468e0:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
1002468e4:     	orr	x14, x14, #0x4444444444444444
1002468e8:     	ldr	x1, [sp, #0x18]
1002468ec:     	ldr	x8, [sp, #0x28]
1002468f0:     	mov	w9, #0x5c               ; =92
1002468f4:     	b	0x100246954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x968>
1002468f8:     	ldr	x21, [sp, #0x30]
1002468fc:     	ldr	x8, [sp, #0x20]
100246900:     	cmp	x21, x8
100246904:     	b.ne	0x10024691c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x930>
100246908:     	add	x0, sp, #0x20
10024690c:     	bl	0x100b114a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246910:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100246914:     	orr	x14, x14, #0x4444444444444444
100246918:     	ldr	x1, [sp, #0x18]
10024691c:     	ldr	x8, [sp, #0x28]
100246920:     	mov	w9, #0xd                ; =13
100246924:     	b	0x100246954 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x968>
100246928:     	ldr	x21, [sp, #0x30]
10024692c:     	ldr	x8, [sp, #0x20]
100246930:     	cmp	x21, x8
100246934:     	b.ne	0x10024694c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x960>
100246938:     	add	x0, sp, #0x20
10024693c:     	bl	0x100b114a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246940:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100246944:     	orr	x14, x14, #0x4444444444444444
100246948:     	ldr	x1, [sp, #0x18]
10024694c:     	ldr	x8, [sp, #0x28]
100246950:     	mov	w9, #0xc                ; =12
100246954:     	strb	w9, [x8, x21]
100246958:     	add	x8, x21, #0x1
10024695c:     	str	x8, [sp, #0x30]
100246960:     	b	0x1002460d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xe4>
100246964:     	sub	w9, w11, #0x41
100246968:     	cmp	w9, #0x6
10024696c:     	b.hs	0x100246cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce8>
100246970:     	sub	w9, w11, #0x37
100246974:     	ldrb	w12, [x10, #0x1]
100246978:     	sub	w11, w12, #0x30
10024697c:     	cmp	w11, #0xa
100246980:     	b.hs	0x10024678c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x7a0>
100246984:     	b	0x100246998 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x9ac>
100246988:     	sub	w11, w12, #0x41
10024698c:     	cmp	w11, #0x5
100246990:     	b.hi	0x100246cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce8>
100246994:     	sub	w11, w12, #0x37
100246998:     	ldrb	w13, [x10, #0x2]
10024699c:     	sub	w12, w13, #0x30
1002469a0:     	cmp	w12, #0xa
1002469a4:     	b.lo	0x1002469b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x9cc>
1002469a8:     	sub	w12, w13, #0x61
1002469ac:     	cmp	w12, #0x6
1002469b0:     	b.hs	0x1002469dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x9f0>
1002469b4:     	sub	w12, w13, #0x57
1002469b8:     	ldrb	w13, [x10, #0x3]
1002469bc:     	sub	w10, w13, #0x30
1002469c0:     	cmp	w10, #0xa
1002469c4:     	b.lo	0x100246a10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa24>
1002469c8:     	sub	w10, w13, #0x61
1002469cc:     	cmp	w10, #0x6
1002469d0:     	b.hs	0x100246a00 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa14>
1002469d4:     	sub	w10, w13, #0x57
1002469d8:     	b	0x100246a10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa24>
1002469dc:     	sub	w12, w13, #0x41
1002469e0:     	cmp	w12, #0x5
1002469e4:     	b.hi	0x100246cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce8>
1002469e8:     	sub	w12, w13, #0x37
1002469ec:     	ldrb	w13, [x10, #0x3]
1002469f0:     	sub	w10, w13, #0x30
1002469f4:     	cmp	w10, #0xa
1002469f8:     	b.hs	0x1002469c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0x9dc>
1002469fc:     	b	0x100246a10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xa24>
100246a00:     	sub	w10, w13, #0x41
100246a04:     	cmp	w10, #0x5
100246a08:     	b.hi	0x100246cd4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xce8>
100246a0c:     	sub	w10, w13, #0x37
100246a10:     	and	w9, w9, #0xff
100246a14:     	and	w11, w11, #0xff
100246a18:     	lsl	w11, w11, #4
100246a1c:     	orr	w24, w11, w9, lsl #8
100246a20:     	and	w9, w12, #0xff
100246a24:     	orr	w27, w24, w9
100246a28:     	lsl	w21, w27, #4
100246a2c:     	and	w9, w10, #0xff
100246a30:     	orr	w11, w21, w9
100246a34:     	str	x23, [x1, #0x70]
100246a38:     	cmp	w24, #0xd80
100246a3c:     	b.lo	0x100246b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb34>
100246a40:     	cmp	w27, #0xdbf
100246a44:     	b.hi	0x100246b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb34>
100246a48:     	add	x22, x8, #0xc
100246a4c:     	cmp	x22, x20
100246a50:     	b.hi	0x100246b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb34>
100246a54:     	cmp	x23, x20
100246a58:     	b.hs	0x100246df8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xe0c>
100246a5c:     	ldrb	w9, [x25, x23]
100246a60:     	cmp	w9, #0x5c
100246a64:     	b.ne	0x100246b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb34>
100246a68:     	add	x0, x8, #0x7
100246a6c:     	cmp	x0, x20
100246a70:     	b.hs	0x100246e0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xe20>
100246a74:     	ldrb	w9, [x25, x0]
100246a78:     	cmp	w9, #0x75
100246a7c:     	b.ne	0x100246b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb34>
100246a80:     	str	w11, [sp, #0x8]
100246a84:     	add	x0, x8, #0x8
100246a88:     	cmp	x22, x0
100246a8c:     	b.lo	0x100246da8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xdbc>
100246a90:     	add	x0, x25, x0
100246a94:     	bl	0x1004faf38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json6parser14decode_hex_u16>
100246a98:     	ubfx	w8, w1, #10, #6
100246a9c:     	cmp	w8, #0x37
100246aa0:     	cset	w8, eq
100246aa4:     	and	w8, w0, w8
100246aa8:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100246aac:     	orr	x14, x14, #0x4444444444444444
100246ab0:     	ldr	w11, [sp, #0x8]
100246ab4:     	tbz	w8, #0x0, 0x100246b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb34>
100246ab8:     	ldr	x8, [sp, #0x18]
100246abc:     	str	x22, [x8, #0x70]
100246ac0:     	and	w8, w11, #0xffff
100246ac4:     	lsl	w8, w8, #10
100246ac8:     	add	w8, w8, w1, uxth
100246acc:     	mov	w9, #0x2400             ; =9216
100246ad0:     	movk	w9, #0xfca0, lsl #16
100246ad4:     	add	w0, w8, w9
100246ad8:     	mov	w8, #0xd800             ; =55296
100246adc:     	eor	w8, w0, w8
100246ae0:     	mov	w9, #0x800              ; =2048
100246ae4:     	movk	w9, #0xffef, lsl #16
100246ae8:     	add	w8, w8, w9
100246aec:     	sub	w8, w8, #0x800
100246af0:     	cmp	w8, w9
100246af4:     	b.lo	0x100246dbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xdd0>
100246af8:     	str	wzr, [sp, #0x3c]
100246afc:     	add	x1, sp, #0x3c
100246b00:     	bl	0x100689550 <__RNvNtNtCsjgY6bXVaRmE_4core4char7methods15encode_utf8_raw>
100246b04:     	mov	x2, x0
100246b08:     	mov	x3, x1
100246b0c:     	add	x0, sp, #0x20
100246b10:     	mov	x1, x2
100246b14:     	mov	x2, x3
100246b18:     	bl	0x100283910 <__RNvMs_NtCsctvjasLqLe9_5alloc3vecINtB4_3VechE15append_elementsCs3gRpqoBkMHm_13perry_runtime>
100246b1c:     	b	0x100246ca0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcb4>
100246b20:     	and	w8, w24, #0xf80
100246b24:     	cmp	w8, #0xd80
100246b28:     	b.ne	0x100246bec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc00>
100246b2c:     	ldr	x21, [sp, #0x30]
100246b30:     	ldr	x8, [sp, #0x20]
100246b34:     	cmp	x21, x8
100246b38:     	b.ne	0x100246b54 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xb68>
100246b3c:     	add	x0, sp, #0x20
100246b40:     	mov	x22, x11
100246b44:     	bl	0x100b114a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246b48:     	mov	x11, x22
100246b4c:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100246b50:     	orr	x14, x14, #0x4444444444444444
100246b54:     	ldr	x8, [sp, #0x28]
100246b58:     	mov	w9, #0xed               ; =237
100246b5c:     	strb	w9, [x8, x21]
100246b60:     	add	x22, x21, #0x1
100246b64:     	str	x22, [sp, #0x30]
100246b68:     	ldr	x8, [sp, #0x20]
100246b6c:     	cmp	x22, x8
100246b70:     	b.ne	0x100246b8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xba0>
100246b74:     	add	x0, sp, #0x20
100246b78:     	mov	x24, x11
100246b7c:     	bl	0x100b114a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246b80:     	mov	x11, x24
100246b84:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100246b88:     	orr	x14, x14, #0x4444444444444444
100246b8c:     	mov	w8, #-0x80              ; =-128
100246b90:     	bfxil	w8, w11, #6, #6
100246b94:     	ldr	x9, [sp, #0x28]
100246b98:     	strb	w8, [x9, x22]
100246b9c:     	add	x22, x21, #0x2
100246ba0:     	str	x22, [sp, #0x30]
100246ba4:     	ldr	x8, [sp, #0x20]
100246ba8:     	cmp	x22, x8
100246bac:     	b.ne	0x100246bc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xbdc>
100246bb0:     	add	x0, sp, #0x20
100246bb4:     	mov	x24, x11
100246bb8:     	bl	0x100b114a8 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVechE8grow_oneB7_>
100246bbc:     	mov	x11, x24
100246bc0:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100246bc4:     	orr	x14, x14, #0x4444444444444444
100246bc8:     	mov	w8, #-0x80              ; =-128
100246bcc:     	bfxil	w8, w11, #0, #6
100246bd0:     	ldr	x9, [sp, #0x28]
100246bd4:     	strb	w8, [x9, x22]
100246bd8:     	add	x8, x21, #0x3
100246bdc:     	str	x8, [sp, #0x30]
100246be0:     	mov	x22, x23
100246be4:     	ldr	x1, [sp, #0x18]
100246be8:     	b	0x1002460d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xe4>
100246bec:     	and	w8, w21, #0xffff
100246bf0:     	mov	w9, #0xd800             ; =55296
100246bf4:     	movk	w9, #0xffef, lsl #16
100246bf8:     	eor	w8, w8, w9
100246bfc:     	mov	w9, #0x800              ; =2048
100246c00:     	movk	w9, #0xffef, lsl #16
100246c04:     	cmp	w8, w9
100246c08:     	b.lo	0x100246d84 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd98>
100246c0c:     	str	wzr, [sp, #0x3c]
100246c10:     	cmp	w27, #0x8
100246c14:     	b.hs	0x100246c24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc38>
100246c18:     	strb	w11, [sp, #0x3c]
100246c1c:     	mov	w22, #0x1               ; =1
100246c20:     	b	0x100246c6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc80>
100246c24:     	mov	w8, #-0x80              ; =-128
100246c28:     	bfxil	w8, w11, #0, #6
100246c2c:     	cmp	w24, #0x80
100246c30:     	b.hs	0x100246c4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc60>
100246c34:     	lsr	w9, w11, #6
100246c38:     	orr	w9, w9, #0xc0
100246c3c:     	strb	w9, [sp, #0x3c]
100246c40:     	strb	w8, [sp, #0x3d]
100246c44:     	mov	w22, #0x2               ; =2
100246c48:     	b	0x100246c6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc80>
100246c4c:     	lsr	w9, w24, #8
100246c50:     	mov	w10, #0x80              ; =128
100246c54:     	orr	w9, w9, #0xe0
100246c58:     	strb	w9, [sp, #0x3c]
100246c5c:     	bfxil	w10, w11, #6, #6
100246c60:     	strb	w10, [sp, #0x3d]
100246c64:     	strb	w8, [sp, #0x3e]
100246c68:     	mov	w22, #0x3               ; =3
100246c6c:     	ldr	x24, [sp, #0x30]
100246c70:     	ldr	x8, [sp, #0x20]
100246c74:     	sub	x8, x8, x24
100246c78:     	cmp	x22, x8
100246c7c:     	b.hi	0x100246cb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xcc4>
100246c80:     	ldr	x8, [sp, #0x28]
100246c84:     	add	x0, x8, x24
100246c88:     	add	x1, sp, #0x3c
100246c8c:     	mov	x2, x22
100246c90:     	bl	0x100b610ec <_writev+0x100b610ec>
100246c94:     	add	x8, x24, x22
100246c98:     	str	x8, [sp, #0x30]
100246c9c:     	mov	x22, x23
100246ca0:     	ldr	x1, [sp, #0x18]
100246ca4:     	mov	x14, #0x1c1c1c1c1c1c1c1c ; =2025524839466146844
100246ca8:     	orr	x14, x14, #0x4444444444444444
100246cac:     	b	0x1002460d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xe4>
100246cb0:     	add	x0, sp, #0x20
100246cb4:     	mov	x1, x24
100246cb8:     	mov	x2, x22
100246cbc:     	mov	w3, #0x1                ; =1
100246cc0:     	mov	w4, #0x1                ; =1
100246cc4:     	bl	0x100b386d0 <__RINvNvMs2_NtCsctvjasLqLe9_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs3gRpqoBkMHm_13perry_runtime>
100246cc8:     	ldr	x24, [sp, #0x30]
100246ccc:     	b	0x100246c80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xc94>
100246cd0:     	str	x22, [x1, #0x70]
100246cd4:     	strb	wzr, [x1, #0xd4]
100246cd8:     	mov	x8, #-0x2               ; =-2
100246cdc:     	ldr	x9, [sp, #0x10]
100246ce0:     	str	x8, [x9]
100246ce4:     	ldr	x8, [sp, #0x20]
100246ce8:     	cbz	x8, 0x100246d14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd28>
100246cec:     	ldr	x0, [sp, #0x28]
100246cf0:     	bl	0x100b5e240 <_mi_free>
100246cf4:     	b	0x100246d14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd28>
100246cf8:     	str	x22, [x1, #0x70]
100246cfc:     	add	x8, x24, x19
100246d00:     	str	x8, [sp, #0x30]
100246d04:     	ldr	q0, [sp, #0x20]
100246d08:     	ldr	x9, [sp, #0x10]
100246d0c:     	str	q0, [x9]
100246d10:     	str	x8, [x9, #0x10]
100246d14:     	ldp	x29, x30, [sp, #0x90]
100246d18:     	ldp	x20, x19, [sp, #0x80]
100246d1c:     	ldp	x22, x21, [sp, #0x70]
100246d20:     	ldp	x24, x23, [sp, #0x60]
100246d24:     	ldp	x26, x25, [sp, #0x50]
100246d28:     	ldp	x28, x27, [sp, #0x40]
100246d2c:     	add	sp, sp, #0xa0
100246d30:     	ret
100246d34:     	ldr	q0, [sp, #0x20]
100246d38:     	ldr	x9, [sp, #0x10]
100246d3c:     	str	q0, [x9]
100246d40:     	ldr	x8, [sp, #0x30]
100246d44:     	b	0x100246d10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser23parse_string_bytes_slow+0xd24>
100246d48:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246d4c:     	add	x3, x3, #0x7a0
100246d50:     	mov	x0, x2
100246d54:     	mov	x1, x22
100246d58:     	mov	x2, x20
100246d5c:     	bl	0x100b11c8c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100246d60:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246d64:     	add	x0, x0, #0x348
100246d68:     	bl	0x100b11a30 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100246d6c:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246d70:     	add	x3, x3, #0x788
100246d74:     	mov	x0, x22
100246d78:     	mov	x1, x23
100246d7c:     	mov	x2, x20
100246d80:     	bl	0x100b11c8c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100246d84:     	adrp	x0, 0x100c74000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x6c5c>
100246d88:     	add	x0, x0, #0x815
100246d8c:     	adrp	x2, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100246d90:     	add	x2, x2, #0x258
100246d94:     	mov	w1, #0x2d               ; =45
100246d98:     	bl	0x100b11a00 <__RNvNtCsjgY6bXVaRmE_4core6option13expect_failed>
100246d9c:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246da0:     	add	x0, x0, #0x330
100246da4:     	bl	0x100b11a30 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100246da8:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246dac:     	add	x3, x3, #0x770
100246db0:     	mov	x1, x22
100246db4:     	mov	x2, x20
100246db8:     	bl	0x100b11c8c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100246dbc:     	adrp	x0, 0x100c45000 <_PERRY_EMPTY_STRING+0x47f4>
100246dc0:     	add	x0, x0, #0x738
100246dc4:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246dc8:     	add	x2, x2, #0x758
100246dcc:     	mov	w1, #0x22               ; =34
100246dd0:     	bl	0x100b11a00 <__RNvNtCsjgY6bXVaRmE_4core6option13expect_failed>
100246dd4:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246dd8:     	add	x2, x2, #0x300
100246ddc:     	mov	x0, x22
100246de0:     	mov	x1, x20
100246de4:     	bl	0x100b11acc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100246de8:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246dec:     	add	x2, x2, #0x318
100246df0:     	mov	x1, x20
100246df4:     	bl	0x100b11acc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100246df8:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246dfc:     	add	x2, x2, #0x728
100246e00:     	mov	x0, x23
100246e04:     	mov	x1, x20
100246e08:     	bl	0x100b11acc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100246e0c:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100246e10:     	add	x2, x2, #0x740
100246e14:     	mov	x1, x20
100246e18:     	bl	0x100b11acc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
