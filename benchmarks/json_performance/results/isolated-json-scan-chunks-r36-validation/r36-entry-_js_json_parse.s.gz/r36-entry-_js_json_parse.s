
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/isolated-json-scan-chunks-r36/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100845514 <_js_json_parse>:
100845514:     	stp	x29, x30, [sp, #-0x10]!
100845518:     	mov	x29, sp
10084551c:     	cbz	x0, 0x100845574 <_js_json_parse+0x60>
100845520:     	ldr	w1, [x0, #0x4]
100845524:     	cmp	w1, #0x2
100845528:     	b.eq	0x100845538 <_js_json_parse+0x24>
10084552c:     	cbz	w1, 0x100845574 <_js_json_parse+0x60>
100845530:     	ldrb	w8, [x0, #0x14]
100845534:     	b	0x100845558 <_js_json_parse+0x44>
100845538:     	ldrb	w8, [x0, #0x14]
10084553c:     	cmp	w8, #0x7b
100845540:     	b.ne	0x100845558 <_js_json_parse+0x44>
100845544:     	ldrb	w8, [x0, #0x15]
100845548:     	cmp	w8, #0x7d
10084554c:     	b.ne	0x100845564 <_js_json_parse+0x50>
100845550:     	ldp	x29, x30, [sp], #0x10
100845554:     	b	0x1004ed5c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_empty21allocate_empty_object>
100845558:     	orr	w8, w8, #0x20
10084555c:     	cmp	w8, #0x7b
100845560:     	b.ne	0x10084556c <_js_json_parse+0x58>
100845564:     	ldp	x29, x30, [sp], #0x10
100845568:     	b	0x100506888 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api10parse_slow>
10084556c:     	ldp	x29, x30, [sp], #0x10
100845570:     	b	0x100508f04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18parse_noncontainer>
100845574:     	adrp	x0, 0x100c76000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime10bun_compat12width_tables8EAW_WIDE+0x6a9c>
100845578:     	add	x0, x0, #0xa41
10084557c:     	mov	w1, #0x1c               ; =28
100845580:     	bl	0x100509338 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9parse_api18throw_syntax_error>
		...
