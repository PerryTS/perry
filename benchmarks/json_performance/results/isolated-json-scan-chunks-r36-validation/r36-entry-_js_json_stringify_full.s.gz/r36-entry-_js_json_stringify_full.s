
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/isolated-json-scan-chunks-r36/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100846980 <_js_json_stringify_full>:
100846980:     	sub	sp, sp, #0x120
100846984:     	stp	d9, d8, [sp, #0xb0]
100846988:     	stp	x28, x27, [sp, #0xc0]
10084698c:     	stp	x26, x25, [sp, #0xd0]
100846990:     	stp	x24, x23, [sp, #0xe0]
100846994:     	stp	x22, x21, [sp, #0xf0]
100846998:     	stp	x20, x19, [sp, #0x100]
10084699c:     	stp	x29, x30, [sp, #0x110]
1008469a0:     	add	x29, sp, #0x110
1008469a4:     	mov.16b	v9, v2
1008469a8:     	mov.16b	v8, v0
1008469ac:     	fmov	x19, d8
1008469b0:     	fmov	x21, d1
1008469b4:     	fmov	x23, d9
1008469b8:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
1008469bc:     	add	x27, x21, x8
1008469c0:     	add	x24, x23, x8
1008469c4:     	fcmp	d2, #0.0
1008469c8:     	ccmp	x24, #0x2, #0x0, ne
1008469cc:     	b.hi	0x1008469dc <_js_json_stringify_full+0x5c>
1008469d0:     	cmp	x27, #0x2
1008469d4:     	b.lo	0x1008469ec <_js_json_stringify_full+0x6c>
1008469d8:     	b	0x100846f58 <_js_json_stringify_full+0x5d8>
1008469dc:     	mov	x8, #0x7ffe000000000000 ; =9222809086901354496
1008469e0:     	cmp	x23, x8
1008469e4:     	ccmp	x27, #0x2, #0x2, eq
1008469e8:     	b.hs	0x100846f58 <_js_json_stringify_full+0x5d8>
1008469ec:     	mov	x8, #-0x2               ; =-2
1008469f0:     	movk	x8, #0x8003, lsl #48
1008469f4:     	add	x8, x19, x8
1008469f8:     	cmp	x8, #0x3
1008469fc:     	b.hs	0x100846a10 <_js_json_stringify_full+0x90>
100846a00:     	adrp	x9, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x49f0>
100846a04:     	add	x9, x9, #0xb98
100846a08:     	ldr	x20, [x9, x8, lsl #3]
100846a0c:     	b	0x100847e28 <_js_json_stringify_full+0x14a8>
100846a10:     	strb	wzr, [sp, #0x4c]
100846a14:     	str	wzr, [sp, #0x48]
100846a18:     	and	x8, x19, #0xffff000000000000
100846a1c:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846a20:     	cmp	x8, x9
100846a24:     	b.eq	0x100846a98 <_js_json_stringify_full+0x118>
100846a28:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100846a2c:     	cmp	x8, x9
100846a30:     	b.ne	0x100846e94 <_js_json_stringify_full+0x514>
100846a34:     	ubfx	x10, x19, #40, #8
100846a38:     	cbz	x10, 0x100846a88 <_js_json_stringify_full+0x108>
100846a3c:     	strb	w19, [sp, #0x48]
100846a40:     	cmp	x10, #0x1
100846a44:     	b.eq	0x100846a88 <_js_json_stringify_full+0x108>
100846a48:     	lsr	x9, x19, #8
100846a4c:     	strb	w9, [sp, #0x49]
100846a50:     	cmp	x10, #0x2
100846a54:     	b.eq	0x100846a88 <_js_json_stringify_full+0x108>
100846a58:     	lsr	x9, x19, #16
100846a5c:     	strb	w9, [sp, #0x4a]
100846a60:     	cmp	x10, #0x3
100846a64:     	b.eq	0x100846a88 <_js_json_stringify_full+0x108>
100846a68:     	lsr	x9, x19, #24
100846a6c:     	strb	w9, [sp, #0x4b]
100846a70:     	cmp	x10, #0x4
100846a74:     	b.eq	0x100846a88 <_js_json_stringify_full+0x108>
100846a78:     	lsr	x9, x19, #32
100846a7c:     	strb	w9, [sp, #0x4c]
100846a80:     	cmp	x10, #0x5
100846a84:     	b.ne	0x1008485fc <_js_json_stringify_full+0x1c7c>
100846a88:     	add	x11, sp, #0x48
100846a8c:     	cmp	w10, #0x3
100846a90:     	b.ls	0x100846ab0 <_js_json_stringify_full+0x130>
100846a94:     	b	0x100846e94 <_js_json_stringify_full+0x514>
100846a98:     	ands	x9, x19, #0xffffffffffff
100846a9c:     	b.eq	0x100846f58 <_js_json_stringify_full+0x5d8>
100846aa0:     	add	x11, x9, #0x14
100846aa4:     	ldr	w10, [x9, #0x4]
100846aa8:     	cmp	w10, #0x3
100846aac:     	b.hi	0x100846e94 <_js_json_stringify_full+0x514>
100846ab0:     	stur	wzr, [sp, #0x81]
100846ab4:     	mov	w9, #0x22               ; =34
100846ab8:     	strb	w9, [sp, #0x80]
100846abc:     	cbz	w10, 0x100846af4 <_js_json_stringify_full+0x174>
100846ac0:     	add	x12, sp, #0x80
100846ac4:     	ldrb	w13, [x11]
100846ac8:     	sxtb	w15, w13
100846acc:     	cmp	w13, #0xb
100846ad0:     	b.le	0x100846afc <_js_json_stringify_full+0x17c>
100846ad4:     	cmp	w13, #0x21
100846ad8:     	b.gt	0x100846b1c <_js_json_stringify_full+0x19c>
100846adc:     	cmp	w13, #0xc
100846ae0:     	b.eq	0x100846b50 <_js_json_stringify_full+0x1d0>
100846ae4:     	cmp	w13, #0xd
100846ae8:     	b.ne	0x100846b2c <_js_json_stringify_full+0x1ac>
100846aec:     	mov	w15, #0x72              ; =114
100846af0:     	b	0x100846b5c <_js_json_stringify_full+0x1dc>
100846af4:     	mov	w12, #0x1               ; =1
100846af8:     	b	0x100846b84 <_js_json_stringify_full+0x204>
100846afc:     	cmp	w13, #0x8
100846b00:     	b.eq	0x100846b48 <_js_json_stringify_full+0x1c8>
100846b04:     	cmp	w13, #0x9
100846b08:     	b.eq	0x100846b58 <_js_json_stringify_full+0x1d8>
100846b0c:     	cmp	w13, #0xa
100846b10:     	b.ne	0x100846b2c <_js_json_stringify_full+0x1ac>
100846b14:     	mov	w15, #0x6e              ; =110
100846b18:     	b	0x100846b5c <_js_json_stringify_full+0x1dc>
100846b1c:     	cmp	w13, #0x22
100846b20:     	b.eq	0x100846b5c <_js_json_stringify_full+0x1dc>
100846b24:     	cmp	w13, #0x5c
100846b28:     	b.eq	0x100846b5c <_js_json_stringify_full+0x1dc>
100846b2c:     	cmp	w15, #0x20
100846b30:     	b.lt	0x100846e94 <_js_json_stringify_full+0x514>
100846b34:     	mov	w14, #0x0               ; =0
100846b38:     	add	x13, x12, #0x2
100846b3c:     	mov	w12, #0x2               ; =2
100846b40:     	mov	w16, #0x1               ; =1
100846b44:     	b	0x100846b74 <_js_json_stringify_full+0x1f4>
100846b48:     	mov	w15, #0x62              ; =98
100846b4c:     	b	0x100846b5c <_js_json_stringify_full+0x1dc>
100846b50:     	mov	w15, #0x66              ; =102
100846b54:     	b	0x100846b5c <_js_json_stringify_full+0x1dc>
100846b58:     	mov	w15, #0x74              ; =116
100846b5c:     	add	x13, x12, #0x3
100846b60:     	mov	w12, #0x5c              ; =92
100846b64:     	strb	w12, [sp, #0x81]
100846b68:     	mov	w14, #0x1               ; =1
100846b6c:     	mov	w12, #0x3               ; =3
100846b70:     	mov	w16, #0x2               ; =2
100846b74:     	add	x17, sp, #0x80
100846b78:     	strb	w15, [x17, x16]
100846b7c:     	cmp	w10, #0x1
100846b80:     	b.ne	0x100846bbc <_js_json_stringify_full+0x23c>
100846b84:     	add	x10, sp, #0x80
100846b88:     	strb	w9, [x10, x12]
100846b8c:     	add	x8, x12, #0x1
100846b90:     	cmp	x12, #0x3
100846b94:     	b.hs	0x100846ba8 <_js_json_stringify_full+0x228>
100846b98:     	mov	x13, #0x0               ; =0
100846b9c:     	mov	x11, #0x0               ; =0
100846ba0:     	add	x9, sp, #0x80
100846ba4:     	b	0x100846e04 <_js_json_stringify_full+0x484>
100846ba8:     	cmp	x12, #0xf
100846bac:     	b.hs	0x100846bec <_js_json_stringify_full+0x26c>
100846bb0:     	mov	x11, #0x0               ; =0
100846bb4:     	mov	x13, #0x0               ; =0
100846bb8:     	b	0x100846d60 <_js_json_stringify_full+0x3e0>
100846bbc:     	ldrb	w16, [x11, #0x1]
100846bc0:     	sxtb	w15, w16
100846bc4:     	cmp	w16, #0xb
100846bc8:     	b.le	0x100846e34 <_js_json_stringify_full+0x4b4>
100846bcc:     	cmp	w16, #0x21
100846bd0:     	b.gt	0x100846e54 <_js_json_stringify_full+0x4d4>
100846bd4:     	cmp	w16, #0xc
100846bd8:     	b.eq	0x100846e84 <_js_json_stringify_full+0x504>
100846bdc:     	cmp	w16, #0xd
100846be0:     	b.ne	0x100846e64 <_js_json_stringify_full+0x4e4>
100846be4:     	mov	w15, #0x72              ; =114
100846be8:     	b	0x100846e90 <_js_json_stringify_full+0x510>
100846bec:     	and	x12, x8, #0xc
100846bf0:     	and	x11, x8, #0x10
100846bf4:     	add	x13, sp, #0x80
100846bf8:     	add	x9, x13, x11
100846bfc:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x59f0>
100846c00:     	ldr	q0, [x14, #0xd10]
100846c04:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x59f0>
100846c08:     	ldr	q1, [x14, #0xd20]
100846c0c:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x59f0>
100846c10:     	ldr	q2, [x14, #0xd30]
100846c14:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x59f0>
100846c18:     	ldr	q3, [x14, #0xd40]
100846c1c:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x59f0>
100846c20:     	ldr	q4, [x14, #0xd50]
100846c24:     	movi.2d	v5, #0000000000000000
100846c28:     	adrp	x14, 0x100c9b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x59f0>
100846c2c:     	ldr	q6, [x14, #0xd60]
100846c30:     	adrp	x14, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x49f0>
100846c34:     	ldr	q7, [x14, #0xe80]
100846c38:     	mov	w14, #0x10              ; =16
100846c3c:     	movi.2d	v16, #0000000000000000
100846c40:     	dup.2d	v17, x14
100846c44:     	adrp	x14, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x331fa>
100846c48:     	ldr	q19, [x14, #0xd80]
100846c4c:     	and	x14, x8, #0x10
100846c50:     	movi.2d	v20, #0000000000000000
100846c54:     	movi.2d	v18, #0000000000000000
100846c58:     	movi.2d	v23, #0000000000000000
100846c5c:     	movi.2d	v21, #0000000000000000
100846c60:     	movi.2d	v24, #0000000000000000
100846c64:     	movi.2d	v22, #0000000000000000
100846c68:     	ldr	q25, [x13], #0x10
100846c6c:     	ushll.8h	v26, v25, #0x0
100846c70:     	ushll2.4s	v27, v26, #0x0
100846c74:     	ushll2.2d	v28, v27, #0x0
100846c78:     	ushll2.8h	v25, v25, #0x0
100846c7c:     	ushll.4s	v29, v25, #0x0
100846c80:     	ushll2.2d	v30, v29, #0x0
100846c84:     	ushll.2d	v29, v29, #0x0
100846c88:     	ushll.2d	v27, v27, #0x0
100846c8c:     	ushll.4s	v26, v26, #0x0
100846c90:     	ushll2.2d	v31, v26, #0x0
100846c94:     	ushll2.4s	v25, v25, #0x0
100846c98:     	ushll.2d	v8, v25, #0x0
100846c9c:     	ushll.2d	v26, v26, #0x0
100846ca0:     	ushll2.2d	v25, v25, #0x0
100846ca4:     	shl.2d	v9, v0, #0x3
100846ca8:     	ushl.2d	v25, v25, v9
100846cac:     	shl.2d	v9, v19, #0x3
100846cb0:     	ushl.2d	v26, v26, v9
100846cb4:     	shl.2d	v9, v1, #0x3
100846cb8:     	ushl.2d	v8, v8, v9
100846cbc:     	shl.2d	v9, v7, #0x3
100846cc0:     	ushl.2d	v31, v31, v9
100846cc4:     	shl.2d	v9, v6, #0x3
100846cc8:     	ushl.2d	v27, v27, v9
100846ccc:     	shl.2d	v9, v3, #0x3
100846cd0:     	ushl.2d	v29, v29, v9
100846cd4:     	shl.2d	v9, v2, #0x3
100846cd8:     	ushl.2d	v30, v30, v9
100846cdc:     	shl.2d	v9, v4, #0x3
100846ce0:     	ushl.2d	v28, v28, v9
100846ce4:     	orr.16b	v18, v28, v18
100846ce8:     	orr.16b	v21, v30, v21
100846cec:     	orr.16b	v23, v29, v23
100846cf0:     	orr.16b	v20, v27, v20
100846cf4:     	orr.16b	v5, v31, v5
100846cf8:     	orr.16b	v24, v8, v24
100846cfc:     	orr.16b	v16, v26, v16
100846d00:     	orr.16b	v22, v25, v22
100846d04:     	add.2d	v6, v6, v17
100846d08:     	add.2d	v7, v7, v17
100846d0c:     	add.2d	v19, v19, v17
100846d10:     	add.2d	v4, v4, v17
100846d14:     	add.2d	v3, v3, v17
100846d18:     	add.2d	v2, v2, v17
100846d1c:     	add.2d	v1, v1, v17
100846d20:     	add.2d	v0, v0, v17
100846d24:     	subs	x14, x14, #0x10
100846d28:     	b.ne	0x100846c68 <_js_json_stringify_full+0x2e8>
100846d2c:     	orr.16b	v0, v16, v23
100846d30:     	orr.16b	v1, v20, v24
100846d34:     	orr.16b	v0, v0, v1
100846d38:     	orr.16b	v1, v5, v21
100846d3c:     	orr.16b	v2, v18, v22
100846d40:     	orr.16b	v1, v1, v2
100846d44:     	orr.16b	v0, v0, v1
100846d48:     	mov	d1, v0[1]
100846d4c:     	orr.8b	v0, v0, v1
100846d50:     	fmov	x13, d0
100846d54:     	cmp	x8, x11
100846d58:     	b.eq	0x100846e24 <_js_json_stringify_full+0x4a4>
100846d5c:     	cbz	x12, 0x100846e04 <_js_json_stringify_full+0x484>
100846d60:     	mov	x14, x11
100846d64:     	and	x11, x8, #0x1c
100846d68:     	add	x15, sp, #0x80
100846d6c:     	add	x9, x15, x11
100846d70:     	fmov	d0, x13
100846d74:     	movi.2d	v1, #0000000000000000
100846d78:     	dup.2d	v3, x14
100846d7c:     	adrp	x12, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x49f0>
100846d80:     	ldr	q2, [x12, #0xe80]
100846d84:     	orr.16b	v2, v3, v2
100846d88:     	adrp	x12, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x331fa>
100846d8c:     	ldr	q4, [x12, #0xd80]
100846d90:     	orr.16b	v3, v3, v4
100846d94:     	sub	x12, x14, x11
100846d98:     	add	x13, x15, x14
100846d9c:     	movi.2d	v4, #0x000000000000ff
100846da0:     	mov	w14, #0x4               ; =4
100846da4:     	dup.2d	v5, x14
100846da8:     	ldr	s6, [x13], #0x4
100846dac:     	ushll.8h	v6, v6, #0x0
100846db0:     	ushll.4s	v6, v6, #0x0
100846db4:     	ushll2.2d	v7, v6, #0x0
100846db8:     	and.16b	v7, v7, v4
100846dbc:     	ushll.2d	v6, v6, #0x0
100846dc0:     	and.16b	v6, v6, v4
100846dc4:     	shl.2d	v16, v2, #0x3
100846dc8:     	shl.2d	v17, v3, #0x3
100846dcc:     	ushl.2d	v6, v6, v17
100846dd0:     	ushl.2d	v7, v7, v16
100846dd4:     	orr.16b	v1, v7, v1
100846dd8:     	orr.16b	v0, v6, v0
100846ddc:     	add.2d	v2, v2, v5
100846de0:     	add.2d	v3, v3, v5
100846de4:     	adds	x12, x12, #0x4
100846de8:     	b.ne	0x100846da8 <_js_json_stringify_full+0x428>
100846dec:     	orr.16b	v0, v0, v1
100846df0:     	mov	d1, v0[1]
100846df4:     	orr.8b	v0, v0, v1
100846df8:     	fmov	x13, d0
100846dfc:     	cmp	x8, x11
100846e00:     	b.eq	0x100846e24 <_js_json_stringify_full+0x4a4>
100846e04:     	add	x10, x10, x8
100846e08:     	lsl	x11, x11, #3
100846e0c:     	ldrb	w12, [x9], #0x1
100846e10:     	lsl	x12, x12, x11
100846e14:     	orr	x13, x12, x13
100846e18:     	add	x11, x11, #0x8
100846e1c:     	cmp	x9, x10
100846e20:     	b.ne	0x100846e0c <_js_json_stringify_full+0x48c>
100846e24:     	orr	x8, x13, x8, lsl #40
100846e28:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100846e2c:     	orr	x20, x8, x9
100846e30:     	b	0x100847e28 <_js_json_stringify_full+0x14a8>
100846e34:     	cmp	w16, #0x8
100846e38:     	b.eq	0x100846e7c <_js_json_stringify_full+0x4fc>
100846e3c:     	cmp	w16, #0x9
100846e40:     	b.eq	0x100846e8c <_js_json_stringify_full+0x50c>
100846e44:     	cmp	w16, #0xa
100846e48:     	b.ne	0x100846e64 <_js_json_stringify_full+0x4e4>
100846e4c:     	mov	w15, #0x6e              ; =110
100846e50:     	b	0x100846e90 <_js_json_stringify_full+0x510>
100846e54:     	cmp	w16, #0x22
100846e58:     	b.eq	0x100846e90 <_js_json_stringify_full+0x510>
100846e5c:     	cmp	w16, #0x5c
100846e60:     	b.eq	0x100846e90 <_js_json_stringify_full+0x510>
100846e64:     	cmp	w15, #0x20
100846e68:     	b.lt	0x100846e94 <_js_json_stringify_full+0x514>
100846e6c:     	add	x13, sp, #0x80
100846e70:     	strb	w15, [x13, x12]
100846e74:     	add	x12, x12, #0x1
100846e78:     	b	0x10084741c <_js_json_stringify_full+0xa9c>
100846e7c:     	mov	w15, #0x62              ; =98
100846e80:     	b	0x100846e90 <_js_json_stringify_full+0x510>
100846e84:     	mov	w15, #0x66              ; =102
100846e88:     	b	0x100846e90 <_js_json_stringify_full+0x510>
100846e8c:     	mov	w15, #0x74              ; =116
100846e90:     	tbz	w14, #0x0, 0x100847408 <_js_json_stringify_full+0xa88>
100846e94:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
100846e98:     	cmp	x8, x9
100846e9c:     	b.eq	0x100846ee4 <_js_json_stringify_full+0x564>
100846ea0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100846ea4:     	cmp	x8, x9
100846ea8:     	b.ne	0x100846f58 <_js_json_stringify_full+0x5d8>
100846eac:     	and	x8, x19, #0xffffffffffff
100846eb0:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
100846eb4:     	mov	x10, #0x7fffffffffff    ; =140737488355327
100846eb8:     	movk	x10, #0xffef, lsl #16
100846ebc:     	cmp	x9, x10
100846ec0:     	b.hi	0x100846f58 <_js_json_stringify_full+0x5d8>
100846ec4:     	ldr	w8, [x8, #0x4]
100846ec8:     	cmp	w8, #0x40
100846ecc:     	b.lo	0x100846f58 <_js_json_stringify_full+0x5d8>
100846ed0:     	and	x0, x19, #0xffffffffffff
100846ed4:     	bl	0x1004f3968 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100846ed8:     	cmp	x0, #0x1
100846edc:     	b.ne	0x100846f58 <_js_json_stringify_full+0x5d8>
100846ee0:     	b	0x1008470a4 <_js_json_stringify_full+0x724>
100846ee4:     	and	x25, x19, #0xffffffffffff
100846ee8:     	and	x0, x19, #0xffffffffffff
100846eec:     	bl	0x10057b4c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100846ef0:     	cbz	x0, 0x100846f24 <_js_json_stringify_full+0x5a4>
100846ef4:     	ldrb	w8, [x0]
100846ef8:     	cmp	w8, #0x2
100846efc:     	b.ne	0x100846f24 <_js_json_stringify_full+0x5a4>
100846f00:     	ldrsb	w8, [x0, #0x1]
100846f04:     	tbnz	w8, #0x1f, 0x100846f24 <_js_json_stringify_full+0x5a4>
100846f08:     	ldrh	w8, [x0, #0x2]
100846f0c:     	tbnz	w8, #0xb, 0x100846f24 <_js_json_stringify_full+0x5a4>
100846f10:     	ldr	w8, [x0, #0x4]
100846f14:     	cmp	w8, #0x18
100846f18:     	b.lo	0x100846f24 <_js_json_stringify_full+0x5a4>
100846f1c:     	ldr	w8, [x25]
100846f20:     	cbz	w8, 0x100847f7c <_js_json_stringify_full+0x15fc>
100846f24:     	and	x0, x19, #0xffffffffffff
100846f28:     	bl	0x10057b4c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100846f2c:     	cbz	x0, 0x100846f58 <_js_json_stringify_full+0x5d8>
100846f30:     	ldrb	w8, [x0]
100846f34:     	cmp	w8, #0x2
100846f38:     	b.ne	0x100846f58 <_js_json_stringify_full+0x5d8>
100846f3c:     	ldrh	w8, [x0, #0x2]
100846f40:     	tbnz	w8, #0xb, 0x100846f58 <_js_json_stringify_full+0x5d8>
100846f44:     	ldr	w8, [x0, #0x4]
100846f48:     	cmp	w8, #0x18
100846f4c:     	b.lo	0x100846f58 <_js_json_stringify_full+0x5d8>
100846f50:     	ldr	w8, [x25]
100846f54:     	cbz	w8, 0x100847f20 <_js_json_stringify_full+0x15a0>
100846f58:     	mov	x20, #0x1               ; =1
100846f5c:     	movk	x20, #0x7ffc, lsl #48
100846f60:     	cmp	x19, x20
100846f64:     	b.eq	0x100847e28 <_js_json_stringify_full+0x14a8>
100846f68:     	and	x22, x19, #0xffff000000000000
100846f6c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846f70:     	cmp	x22, x8
100846f74:     	b.ne	0x100846fac <_js_json_stringify_full+0x62c>
100846f78:     	and	x8, x19, #0xffffffffffff
100846f7c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100846f80:     	b.lo	0x100846f98 <_js_json_stringify_full+0x618>
100846f84:     	ldr	w8, [x8, #0xc]
100846f88:     	mov	w9, #0x4f53             ; =20307
100846f8c:     	movk	w9, #0x434c, lsl #16
100846f90:     	cmp	w8, w9
100846f94:     	b.eq	0x100847e28 <_js_json_stringify_full+0x14a8>
100846f98:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100846f9c:     	cmp	x22, x8
100846fa0:     	b.ne	0x100846fd8 <_js_json_stringify_full+0x658>
100846fa4:     	and	x0, x19, #0xffffffffffff
100846fa8:     	b	0x100847000 <_js_json_stringify_full+0x680>
100846fac:     	lsr	x8, x19, #52
100846fb0:     	cbnz	x8, 0x100847088 <_js_json_stringify_full+0x708>
100846fb4:     	and	x8, x19, #0x7
100846fb8:     	cbz	x19, 0x100846fe4 <_js_json_stringify_full+0x664>
100846fbc:     	cbnz	x8, 0x100846fe4 <_js_json_stringify_full+0x664>
100846fc0:     	mov	x0, x19
100846fc4:     	bl	0x10050fc38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846fc8:     	mov	x8, x19
100846fcc:     	tbnz	w0, #0x0, 0x100846f7c <_js_json_stringify_full+0x5fc>
100846fd0:     	mov	x8, #0x0                ; =0
100846fd4:     	b	0x100846fe4 <_js_json_stringify_full+0x664>
100846fd8:     	lsr	x8, x19, #52
100846fdc:     	cbnz	x8, 0x100847088 <_js_json_stringify_full+0x708>
100846fe0:     	and	x8, x19, #0x7
100846fe4:     	cbz	x19, 0x100847088 <_js_json_stringify_full+0x708>
100846fe8:     	cbnz	x8, 0x100847088 <_js_json_stringify_full+0x708>
100846fec:     	mov	x0, x19
100846ff0:     	bl	0x10050fc38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100846ff4:     	mov	x8, x0
100846ff8:     	mov	x0, x19
100846ffc:     	tbz	w8, #0x0, 0x100847088 <_js_json_stringify_full+0x708>
100847000:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100847004:     	b.lo	0x100847088 <_js_json_stringify_full+0x708>
100847008:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084700c:     	add	x8, x8, #0xfb0
100847010:     	ldaprb	w8, [x8]
100847014:     	cbz	w8, 0x100847088 <_js_json_stringify_full+0x708>
100847018:     	lsr	x8, x0, #3
10084701c:     	mov	x9, #0x7c15             ; =31765
100847020:     	movk	x9, #0x7f4a, lsl #16
100847024:     	movk	x9, #0x79b9, lsl #32
100847028:     	movk	x9, #0x9e37, lsl #48
10084702c:     	mul	x8, x8, x9
100847030:     	lsr	x10, x8, #54
100847034:     	lsr	x11, x8, #60
100847038:     	adrp	x9, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
10084703c:     	add	x9, x9, #0xf30
100847040:     	add	x11, x9, x11, lsl #3
100847044:     	ldapr	x11, [x11]
100847048:     	lsr	x10, x11, x10
10084704c:     	tbz	w10, #0x0, 0x100847088 <_js_json_stringify_full+0x708>
100847050:     	lsr	x10, x8, #44
100847054:     	ubfx	x11, x8, #50, #4
100847058:     	add	x11, x9, x11, lsl #3
10084705c:     	ldapr	x11, [x11]
100847060:     	lsr	x10, x11, x10
100847064:     	tbz	w10, #0x0, 0x100847088 <_js_json_stringify_full+0x708>
100847068:     	lsr	x10, x8, #34
10084706c:     	ubfx	x8, x8, #40, #4
100847070:     	add	x8, x9, x8, lsl #3
100847074:     	ldapr	x8, [x8]
100847078:     	lsr	x8, x8, x10
10084707c:     	tbz	w8, #0x0, 0x100847088 <_js_json_stringify_full+0x708>
100847080:     	bl	0x10034d6ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
100847084:     	tbnz	w0, #0x0, 0x100847e28 <_js_json_stringify_full+0x14a8>
100847088:     	cmp	x24, #0x3
10084708c:     	ccmp	x27, #0x2, #0x2, lo
100847090:     	b.hs	0x1008470b0 <_js_json_stringify_full+0x730>
100847094:     	mov.16b	v0, v8
100847098:     	bl	0x1004eea3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084709c:     	cmp	x0, #0x1
1008470a0:     	b.ne	0x1008470b0 <_js_json_stringify_full+0x730>
1008470a4:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
1008470a8:     	bfxil	x20, x1, #0, #48
1008470ac:     	b	0x100847e28 <_js_json_stringify_full+0x14a8>
1008470b0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008470b4:     	cmp	x22, x8
1008470b8:     	b.ne	0x100847108 <_js_json_stringify_full+0x788>
1008470bc:     	ands	x22, x19, #0xffffffffffff
1008470c0:     	b.eq	0x100847108 <_js_json_stringify_full+0x788>
1008470c4:     	mov	x0, x22
1008470c8:     	bl	0x10050fc38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008470cc:     	cbz	w0, 0x100847108 <_js_json_stringify_full+0x788>
1008470d0:     	ldurb	w8, [x22, #-0x8]
1008470d4:     	cmp	w8, #0x9
1008470d8:     	b.ne	0x100847108 <_js_json_stringify_full+0x788>
1008470dc:     	ldr	w8, [x22, #0x4]
1008470e0:     	mov	w9, #0x5841             ; =22593
1008470e4:     	movk	w9, #0x4c5a, lsl #16
1008470e8:     	cmp	w8, w9
1008470ec:     	b.ne	0x100847108 <_js_json_stringify_full+0x788>
1008470f0:     	mov	x0, x22
1008470f4:     	bl	0x100688e64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1008470f8:     	cbz	x0, 0x100847108 <_js_json_stringify_full+0x788>
1008470fc:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100847100:     	bfxil	x19, x0, #0, #48
100847104:     	fmov	d8, x19
100847108:     	mov	w8, #0x7ffd             ; =32765
10084710c:     	cmp	x8, x23, lsr #48
100847110:     	b.ne	0x100847124 <_js_json_stringify_full+0x7a4>
100847114:     	and	x1, x23, #0xffffffffffff
100847118:     	cmp	x1, #0x100, lsl #12     ; =0x100000
10084711c:     	b.hs	0x100847138 <_js_json_stringify_full+0x7b8>
100847120:     	b	0x10084718c <_js_json_stringify_full+0x80c>
100847124:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
100847128:     	mov	x9, #0xfffffff00000     ; =281474975662080
10084712c:     	mov	x1, x23
100847130:     	cmp	x8, x9
100847134:     	b.hs	0x10084718c <_js_json_stringify_full+0x80c>
100847138:     	lsr	x8, x1, #47
10084713c:     	cbnz	x8, 0x10084718c <_js_json_stringify_full+0x80c>
100847140:     	add	x0, sp, #0x80
100847144:     	bl	0x10076f02c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
100847148:     	ldr	w8, [sp, #0x80]
10084714c:     	tbz	w8, #0x0, 0x10084718c <_js_json_stringify_full+0x80c>
100847150:     	ldr	w8, [sp, #0x88]
100847154:     	mov	w9, #-0xff30            ; =-65328
100847158:     	cmp	w8, w9
10084715c:     	b.eq	0x100847180 <_js_json_stringify_full+0x800>
100847160:     	mov	w9, #-0xff2f            ; =-65327
100847164:     	cmp	w8, w9
100847168:     	b.ne	0x10084718c <_js_json_stringify_full+0x80c>
10084716c:     	mov.16b	v0, v9
100847170:     	bl	0x10084923c <_js_jsvalue_to_string>
100847174:     	mov	x23, #0x7fff000000000000 ; =9223090561878065152
100847178:     	bfxil	x23, x0, #0, #48
10084717c:     	b	0x10084718c <_js_json_stringify_full+0x80c>
100847180:     	mov.16b	v0, v9
100847184:     	bl	0x1008707e0 <_js_number_coerce>
100847188:     	fmov	x23, d0
10084718c:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100847190:     	add	x8, x23, x8
100847194:     	cmp	x8, #0x3
100847198:     	b.hs	0x1008471b0 <_js_json_stringify_full+0x830>
10084719c:     	mov	x22, #0x0               ; =0
1008471a0:     	mov	w8, #0x1                ; =1
1008471a4:     	stp	xzr, x8, [sp, #0x10]
1008471a8:     	str	xzr, [sp, #0x20]
1008471ac:     	b	0x100847464 <_js_json_stringify_full+0xae4>
1008471b0:     	and	x8, x23, #0xffff000000000000
1008471b4:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1008471b8:     	cmp	x8, x9
1008471bc:     	b.eq	0x1008471e0 <_js_json_stringify_full+0x860>
1008471c0:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
1008471c4:     	cmp	x8, x9
1008471c8:     	b.ne	0x10084726c <_js_json_stringify_full+0x8ec>
1008471cc:     	and	x8, x23, #0xffffffffffff
1008471d0:     	cmp	x8, #0x1, lsl #12       ; =0x1000
1008471d4:     	b.hs	0x1008472b4 <_js_json_stringify_full+0x934>
1008471d8:     	mov	x9, #0x0                ; =0
1008471dc:     	b	0x1008472bc <_js_json_stringify_full+0x93c>
1008471e0:     	strb	wzr, [sp, #0x4c]
1008471e4:     	str	wzr, [sp, #0x48]
1008471e8:     	ubfx	x1, x23, #40, #8
1008471ec:     	cbz	x1, 0x10084723c <_js_json_stringify_full+0x8bc>
1008471f0:     	strb	w23, [sp, #0x48]
1008471f4:     	cmp	x1, #0x1
1008471f8:     	b.eq	0x10084723c <_js_json_stringify_full+0x8bc>
1008471fc:     	lsr	x8, x23, #8
100847200:     	strb	w8, [sp, #0x49]
100847204:     	cmp	x1, #0x2
100847208:     	b.eq	0x10084723c <_js_json_stringify_full+0x8bc>
10084720c:     	lsr	x8, x23, #16
100847210:     	strb	w8, [sp, #0x4a]
100847214:     	cmp	x1, #0x3
100847218:     	b.eq	0x10084723c <_js_json_stringify_full+0x8bc>
10084721c:     	lsr	x8, x23, #24
100847220:     	strb	w8, [sp, #0x4b]
100847224:     	cmp	x1, #0x4
100847228:     	b.eq	0x10084723c <_js_json_stringify_full+0x8bc>
10084722c:     	lsr	x8, x23, #32
100847230:     	strb	w8, [sp, #0x4c]
100847234:     	cmp	x1, #0x5
100847238:     	b.ne	0x1008485fc <_js_json_stringify_full+0x1c7c>
10084723c:     	add	x8, sp, #0x80
100847240:     	add	x0, sp, #0x48
100847244:     	bl	0x10002dd18 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100847248:     	ldr	w8, [sp, #0x80]
10084724c:     	ldp	x9, x22, [sp, #0x88]
100847250:     	cmp	w8, #0x0
100847254:     	csinc	x23, x9, xzr, eq
100847258:     	csel	x25, xzr, x22, ne
10084725c:     	tbz	x25, #0x3f, 0x10084739c <_js_json_stringify_full+0xa1c>
100847260:     	mov	x0, #0x0                ; =0
100847264:     	mov	x1, x22
100847268:     	bl	0x100b13780 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084726c:     	add	x8, x20, #0x3
100847270:     	cmp	x23, x8
100847274:     	b.eq	0x10084719c <_js_json_stringify_full+0x81c>
100847278:     	fmov	d0, x23
10084727c:     	fcvtzu	x8, d0
100847280:     	mov	w9, #0xa                ; =10
100847284:     	cmp	x8, #0xa
100847288:     	csel	x3, x8, x9, lo
10084728c:     	adrp	x1, 0x100c44000 <_PERRY_EMPTY_STRING+0x1634>
100847290:     	add	x1, x1, #0xb5c
100847294:     	add	x0, sp, #0x80
100847298:     	mov	w2, #0x1                ; =1
10084729c:     	bl	0x1002305f4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
1008472a0:     	ldr	x22, [sp, #0x90]
1008472a4:     	str	x22, [sp, #0x20]
1008472a8:     	ldr	q0, [sp, #0x80]
1008472ac:     	str	q0, [sp, #0x10]
1008472b0:     	b	0x100847464 <_js_json_stringify_full+0xae4>
1008472b4:     	ldr	w22, [x8, #0x4]
1008472b8:     	add	x9, x8, #0x14
1008472bc:     	mov	x14, #0x0               ; =0
1008472c0:     	mov	x8, #0x0                ; =0
1008472c4:     	cmp	x9, #0x0
1008472c8:     	csel	x24, xzr, x22, eq
1008472cc:     	csinc	x23, x9, xzr, ne
1008472d0:     	add	x9, x23, x24
1008472d4:     	mov	w10, #0x1               ; =1
1008472d8:     	mov	x11, x23
1008472dc:     	b	0x10084730c <_js_json_stringify_full+0x98c>
1008472e0:     	add	x12, x11, #0x2
1008472e4:     	bfi	w15, w13, #6, #5
1008472e8:     	mov	x13, x15
1008472ec:     	sub	x11, x25, x11
1008472f0:     	add	x14, x11, x12
1008472f4:     	cmp	w13, #0x10, lsl #12     ; =0x10000
1008472f8:     	cinc	x11, x10, hs
1008472fc:     	add	x8, x11, x8
100847300:     	mov	x11, x12
100847304:     	cmp	x8, #0xa
100847308:     	b.hi	0x1008473c4 <_js_json_stringify_full+0xa44>
10084730c:     	cmp	x11, x9
100847310:     	b.eq	0x100847374 <_js_json_stringify_full+0x9f4>
100847314:     	mov	x25, x14
100847318:     	mov	x12, x11
10084731c:     	ldrsb	w14, [x12], #0x1
100847320:     	and	w13, w14, #0xff
100847324:     	tbz	w14, #0x1f, 0x1008472ec <_js_json_stringify_full+0x96c>
100847328:     	ldrb	w12, [x11, #0x1]
10084732c:     	and	w15, w12, #0x3f
100847330:     	cmp	w13, #0xe0
100847334:     	b.lo	0x1008472e0 <_js_json_stringify_full+0x960>
100847338:     	and	w14, w13, #0x1f
10084733c:     	ldrb	w12, [x11, #0x2]
100847340:     	and	w12, w12, #0x3f
100847344:     	orr	w15, w12, w15, lsl #6
100847348:     	cmp	w13, #0xf0
10084734c:     	b.lo	0x100847368 <_js_json_stringify_full+0x9e8>
100847350:     	add	x12, x11, #0x4
100847354:     	ldrb	w13, [x11, #0x3]
100847358:     	and	w13, w13, #0x3f
10084735c:     	orr	w13, w13, w15, lsl #6
100847360:     	bfi	w13, w14, #18, #3
100847364:     	b	0x1008472ec <_js_json_stringify_full+0x96c>
100847368:     	add	x12, x11, #0x3
10084736c:     	orr	w13, w15, w14, lsl #12
100847370:     	b	0x1008472ec <_js_json_stringify_full+0x96c>
100847374:     	cbz	x24, 0x1008473f8 <_js_json_stringify_full+0xa78>
100847378:     	mov	x0, x24
10084737c:     	mov	w1, #0x1                ; =1
100847380:     	bl	0x100b60688 <_mi_malloc_aligned>
100847384:     	cbz	x0, 0x1008485e4 <_js_json_stringify_full+0x1c64>
100847388:     	mov	x26, x0
10084738c:     	mov	x1, x23
100847390:     	mov	x2, x24
100847394:     	bl	0x100b632ac <_writev+0x100b632ac>
100847398:     	b	0x100847400 <_js_json_stringify_full+0xa80>
10084739c:     	cbz	x25, 0x100847454 <_js_json_stringify_full+0xad4>
1008473a0:     	mov	x0, x25
1008473a4:     	mov	w1, #0x1                ; =1
1008473a8:     	bl	0x100b60688 <_mi_malloc_aligned>
1008473ac:     	cbz	x0, 0x1008485f0 <_js_json_stringify_full+0x1c70>
1008473b0:     	mov	x24, x0
1008473b4:     	mov	x1, x23
1008473b8:     	mov	x2, x25
1008473bc:     	bl	0x100b632ac <_writev+0x100b632ac>
1008473c0:     	b	0x10084745c <_js_json_stringify_full+0xadc>
1008473c4:     	cbz	x25, 0x1008473f8 <_js_json_stringify_full+0xa78>
1008473c8:     	cmp	x25, x24
1008473cc:     	b.hs	0x100847e74 <_js_json_stringify_full+0x14f4>
1008473d0:     	ldrsb	w8, [x23, x25]
1008473d4:     	cmn	w8, #0x40
1008473d8:     	b.ge	0x100847e78 <_js_json_stringify_full+0x14f8>
1008473dc:     	adrp	x4, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
1008473e0:     	add	x4, x4, #0x270
1008473e4:     	mov	x0, x23
1008473e8:     	mov	x1, x24
1008473ec:     	mov	x2, #0x0                ; =0
1008473f0:     	mov	x3, x25
1008473f4:     	bl	0x100b13af8 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
1008473f8:     	mov	x22, #0x0               ; =0
1008473fc:     	mov	w26, #0x1               ; =1
100847400:     	stp	x22, x26, [sp, #0x10]
100847404:     	b	0x100847460 <_js_json_stringify_full+0xae0>
100847408:     	add	x14, sp, #0x80
10084740c:     	mov	w16, #0x5c              ; =92
100847410:     	strb	w16, [x14, x12]
100847414:     	add	x12, x12, #0x2
100847418:     	strb	w15, [x13, #0x1]
10084741c:     	cmp	w10, #0x2
100847420:     	b.eq	0x100846b84 <_js_json_stringify_full+0x204>
100847424:     	ldrb	w11, [x11, #0x2]
100847428:     	sxtb	w10, w11
10084742c:     	cmp	w11, #0xb
100847430:     	b.le	0x100847f00 <_js_json_stringify_full+0x1580>
100847434:     	cmp	w11, #0x21
100847438:     	b.gt	0x100847f4c <_js_json_stringify_full+0x15cc>
10084743c:     	cmp	w11, #0xc
100847440:     	b.eq	0x100847fd8 <_js_json_stringify_full+0x1658>
100847444:     	cmp	w11, #0xd
100847448:     	b.ne	0x100847f5c <_js_json_stringify_full+0x15dc>
10084744c:     	mov	w10, #0x72              ; =114
100847450:     	b	0x100847fe4 <_js_json_stringify_full+0x1664>
100847454:     	mov	x22, #0x0               ; =0
100847458:     	mov	w24, #0x1               ; =1
10084745c:     	stp	x22, x24, [sp, #0x10]
100847460:     	str	x22, [sp, #0x20]
100847464:     	cmp	x27, #0x2
100847468:     	b.lo	0x1008475a8 <_js_json_stringify_full+0xc28>
10084746c:     	and	x25, x21, #0xffff000000000000
100847470:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100847474:     	cmp	x25, x8
100847478:     	b.ne	0x100847584 <_js_json_stringify_full+0xc04>
10084747c:     	and	x23, x21, #0xffffffffffff
100847480:     	cmp	x23, #0x100, lsl #12    ; =0x100000
100847484:     	b.lo	0x1008475a8 <_js_json_stringify_full+0xc28>
100847488:     	mov	x0, x23
10084748c:     	bl	0x10050b140 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
100847490:     	tbnz	w0, #0x0, 0x1008475a8 <_js_json_stringify_full+0xc28>
100847494:     	lsr	x8, x23, #51
100847498:     	cmp	x8, #0xfff
10084749c:     	b.lo	0x1008474b4 <_js_json_stringify_full+0xb34>
1008474a0:     	mov	w8, #0x7ffc             ; =32764
1008474a4:     	cmp	x8, x23, lsr #48
1008474a8:     	b.eq	0x1008475a8 <_js_json_stringify_full+0xc28>
1008474ac:     	ands	x23, x23, #0xffffffffffff
1008474b0:     	b.eq	0x1008475a8 <_js_json_stringify_full+0xc28>
1008474b4:     	and	x8, x23, #0xfffffffffff00000
1008474b8:     	lsr	x9, x23, #47
1008474bc:     	cmp	x9, #0x0
1008474c0:     	ccmp	x8, #0x0, #0x4, eq
1008474c4:     	b.eq	0x1008475a8 <_js_json_stringify_full+0xc28>
1008474c8:     	tst	x23, #0x3
1008474cc:     	ccmp	x23, #0x7, #0x0, eq
1008474d0:     	b.ls	0x100848214 <_js_json_stringify_full+0x1894>
1008474d4:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1008474d8:     	ldr	x8, [x8, #0x48]
1008474dc:     	cmn	x8, #0x1
1008474e0:     	b.eq	0x100848164 <_js_json_stringify_full+0x17e4>
1008474e4:     	mrs	x9, TPIDRRO_EL0
1008474e8:     	and	x9, x9, #0xfffffffffffffff8
1008474ec:     	ldr	x0, [x9, x8, lsl #3]
1008474f0:     	cbz	x0, 0x100848164 <_js_json_stringify_full+0x17e4>
1008474f4:     	lsr	x1, x23, #20
1008474f8:     	ldr	x8, [x0, #0x10]
1008474fc:     	ldrb	w9, [x8]
100847500:     	cmp	w9, #0x2
100847504:     	b.ne	0x10084817c <_js_json_stringify_full+0x17fc>
100847508:     	ldrb	w9, [x8, #0x88]
10084750c:     	tbz	w9, #0x0, 0x10084752c <_js_json_stringify_full+0xbac>
100847510:     	ldr	x9, [x8, #0x80]
100847514:     	cmp	x9, x1
100847518:     	b.ne	0x10084752c <_js_json_stringify_full+0xbac>
10084751c:     	ldp	x9, x10, [x8, #0x60]
100847520:     	cmp	x9, x23
100847524:     	ccmp	x10, x23, #0x0, ls
100847528:     	b.hi	0x10084815c <_js_json_stringify_full+0x17dc>
10084752c:     	ldrb	w9, [x8, #0xb8]
100847530:     	cbz	w9, 0x100847550 <_js_json_stringify_full+0xbd0>
100847534:     	ldr	x9, [x8, #0xb0]
100847538:     	cmp	x9, x1
10084753c:     	b.ne	0x100847550 <_js_json_stringify_full+0xbd0>
100847540:     	ldp	x9, x10, [x8, #0x90]
100847544:     	cmp	x9, x23
100847548:     	ccmp	x10, x23, #0x0, ls
10084754c:     	b.hi	0x1008483e4 <_js_json_stringify_full+0x1a64>
100847550:     	ldrb	w9, [x8, #0xe8]
100847554:     	cbz	w9, 0x100847f9c <_js_json_stringify_full+0x161c>
100847558:     	ldr	x9, [x8, #0xe0]
10084755c:     	cmp	x9, x1
100847560:     	b.ne	0x100847f9c <_js_json_stringify_full+0x161c>
100847564:     	ldr	x9, [x8, #0xc0]
100847568:     	cmp	x9, x23
10084756c:     	b.hi	0x100847f9c <_js_json_stringify_full+0x161c>
100847570:     	ldr	x9, [x8, #0xc8]
100847574:     	cmp	x9, x23
100847578:     	b.ls	0x100847f9c <_js_json_stringify_full+0x161c>
10084757c:     	add	x9, x8, #0xc0
100847580:     	b	0x1008483e8 <_js_json_stringify_full+0x1a68>
100847584:     	lsr	x8, x21, #52
100847588:     	cbnz	x8, 0x1008475a8 <_js_json_stringify_full+0xc28>
10084758c:     	cbz	x21, 0x1008475a8 <_js_json_stringify_full+0xc28>
100847590:     	and	x8, x21, #0x7
100847594:     	cbnz	x8, 0x1008475a8 <_js_json_stringify_full+0xc28>
100847598:     	mov	x0, x21
10084759c:     	bl	0x10050fc38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008475a0:     	mov	x23, x21
1008475a4:     	cbnz	w0, 0x100847480 <_js_json_stringify_full+0xb00>
1008475a8:     	mov	x25, #-0x1              ; =-1
1008475ac:     	str	x25, [sp, #0x30]
1008475b0:     	mov	w24, #0x1               ; =1
1008475b4:     	cmp	x27, #0x1
1008475b8:     	cset	w8, hi
1008475bc:     	tst	w8, w24
1008475c0:     	b.eq	0x100847634 <_js_json_stringify_full+0xcb4>
1008475c4:     	and	x23, x21, #0xffff000000000000
1008475c8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008475cc:     	cmp	x23, x8
1008475d0:     	b.ne	0x10084760c <_js_json_stringify_full+0xc8c>
1008475d4:     	and	x8, x21, #0xffffffffffff
1008475d8:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1008475dc:     	b.lo	0x100847634 <_js_json_stringify_full+0xcb4>
1008475e0:     	ldr	w8, [x8, #0xc]
1008475e4:     	mov	w9, #0x4f53             ; =20307
1008475e8:     	movk	w9, #0x434c, lsl #16
1008475ec:     	cmp	w8, w9
1008475f0:     	b.ne	0x100847634 <_js_json_stringify_full+0xcb4>
1008475f4:     	and	x8, x21, #0xffffffffffff
1008475f8:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008475fc:     	cmp	x23, x9
100847600:     	csel	x28, x8, x21, eq
100847604:     	mov	w27, #0x1               ; =1
100847608:     	b	0x100847638 <_js_json_stringify_full+0xcb8>
10084760c:     	lsr	x8, x21, #52
100847610:     	cbnz	x8, 0x100847634 <_js_json_stringify_full+0xcb4>
100847614:     	mov	w27, #0x0               ; =0
100847618:     	cbz	x21, 0x100847638 <_js_json_stringify_full+0xcb8>
10084761c:     	and	x8, x21, #0x7
100847620:     	cbnz	x8, 0x100847638 <_js_json_stringify_full+0xcb8>
100847624:     	mov	x0, x21
100847628:     	bl	0x10050fc38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084762c:     	mov	x8, x21
100847630:     	tbnz	w0, #0x0, 0x1008475d8 <_js_json_stringify_full+0xc58>
100847634:     	mov	w27, #0x0               ; =0
100847638:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
10084763c:     	add	x0, x0, #0xd78
100847640:     	ldr	x8, [x0]
100847644:     	blr	x8
100847648:     	mov	x21, x0
10084764c:     	ldr	w26, [x0]
100847650:     	add	w8, w26, #0x1
100847654:     	str	w8, [x0]
100847658:     	cbz	w26, 0x1008476c8 <_js_json_stringify_full+0xd48>
10084765c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847660:     	add	x0, x0, #0xd00
100847664:     	ldr	x8, [x0]
100847668:     	blr	x8
10084766c:     	ldrb	w8, [x0, #0x20]
100847670:     	cmp	w8, #0x1
100847674:     	b.ne	0x100848454 <_js_json_stringify_full+0x1ad4>
100847678:     	ldr	x8, [x0]
10084767c:     	cbnz	x8, 0x100848460 <_js_json_stringify_full+0x1ae0>
100847680:     	mov	x8, #-0x1               ; =-1
100847684:     	str	x8, [x0]
100847688:     	ldr	x23, [x0, #0x18]
10084768c:     	ldr	x8, [x0, #0x8]
100847690:     	cmp	x23, x8
100847694:     	b.eq	0x100847e50 <_js_json_stringify_full+0x14d0>
100847698:     	ldr	x8, [x0, #0x10]
10084769c:     	mov	w9, #0x18               ; =24
1008476a0:     	madd	x8, x23, x9, x8
1008476a4:     	mov	w9, #0x8                ; =8
1008476a8:     	stp	xzr, x9, [x8]
1008476ac:     	str	xzr, [x8, #0x10]
1008476b0:     	add	x8, x23, #0x1
1008476b4:     	str	x8, [x0, #0x18]
1008476b8:     	ldr	x8, [x0]
1008476bc:     	add	x8, x8, #0x1
1008476c0:     	str	x8, [x0]
1008476c4:     	b	0x100847730 <_js_json_stringify_full+0xdb0>
1008476c8:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008476cc:     	add	x0, x0, #0xdc0
1008476d0:     	ldr	x8, [x0]
1008476d4:     	blr	x8
1008476d8:     	strb	wzr, [x0]
1008476dc:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008476e0:     	add	x0, x0, #0xdf0
1008476e4:     	ldr	x8, [x0]
1008476e8:     	blr	x8
1008476ec:     	strb	wzr, [x0]
1008476f0:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
1008476f4:     	ldr	w23, [x8, #0x5a8]
1008476f8:     	cmp	w23, #0x300
1008476fc:     	b.hs	0x100847e98 <_js_json_stringify_full+0x1518>
100847700:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100847704:     	ldr	x8, [x8, #0x48]
100847708:     	cmn	x8, #0x1
10084770c:     	b.eq	0x100847e88 <_js_json_stringify_full+0x1508>
100847710:     	mrs	x9, TPIDRRO_EL0
100847714:     	and	x9, x9, #0xfffffffffffffff8
100847718:     	ldr	x0, [x9, x8, lsl #3]
10084771c:     	cbz	x0, 0x100847e88 <_js_json_stringify_full+0x1508>
100847720:     	add	x8, x0, x23, lsl #3
100847724:     	ldr	x0, [x8, #0x1e8]
100847728:     	cbz	x0, 0x100847e98 <_js_json_stringify_full+0x1518>
10084772c:     	str	xzr, [x0]
100847730:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847734:     	add	x0, x0, #0xd30
100847738:     	ldr	x8, [x0]
10084773c:     	blr	x8
100847740:     	mov	x23, x0
100847744:     	ldrb	w8, [x0, #0x18]
100847748:     	cmp	w8, #0x1
10084774c:     	b.ne	0x100848408 <_js_json_stringify_full+0x1a88>
100847750:     	ldr	x8, [x0]
100847754:     	mov	x9, #-0x1               ; =-1
100847758:     	str	x9, [x0]
10084775c:     	cmn	x8, #0x2
100847760:     	b.eq	0x100848590 <_js_json_stringify_full+0x1c10>
100847764:     	cmn	x8, #0x1
100847768:     	b.eq	0x10084783c <_js_json_stringify_full+0xebc>
10084776c:     	add	x9, sp, #0x48
100847770:     	ldur	q0, [x0, #0x8]
100847774:     	stur	q0, [x9, #0x8]
100847778:     	str	x8, [sp, #0x48]
10084777c:     	tbz	w24, #0x0, 0x100847850 <_js_json_stringify_full+0xed0>
100847780:     	tbz	w27, #0x0, 0x100847938 <_js_json_stringify_full+0xfb8>
100847784:     	bl	0x10028c0d8 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
100847788:     	str	x0, [sp, #0x60]
10084778c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100847790:     	stp	x28, x8, [sp, #0x88]
100847794:     	mov	w8, #0x1                ; =1
100847798:     	str	x8, [sp, #0x80]
10084779c:     	add	x0, sp, #0x80
1008477a0:     	bl	0x10028c1e0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
1008477a4:     	mov	x22, x0
1008477a8:     	str	x0, [sp, #0x68]
1008477ac:     	mov	w0, #0x0                ; =0
1008477b0:     	bl	0x10034be6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1008477b4:     	stp	xzr, xzr, [x0]
1008477b8:     	str	wzr, [x0, #0x10]
1008477bc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008477c0:     	bfxil	x8, x0, #0, #48
1008477c4:     	fmov	d0, x8
1008477c8:     	bl	0x10020b124 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
1008477cc:     	mov	x19, x0
1008477d0:     	adrp	x24, 0x100f80000 <_perry_global_worker_ts__1>
1008477d4:     	ldr	x8, [x24, #0x48]
1008477d8:     	cmn	x8, #0x1
1008477dc:     	b.eq	0x10084799c <_js_json_stringify_full+0x101c>
1008477e0:     	mrs	x9, TPIDRRO_EL0
1008477e4:     	and	x9, x9, #0xfffffffffffffff8
1008477e8:     	ldr	x8, [x9, x8, lsl #3]
1008477ec:     	cbz	x8, 0x10084799c <_js_json_stringify_full+0x101c>
1008477f0:     	ldr	x8, [x8, #0x19e8]
1008477f4:     	cbz	x8, 0x10084799c <_js_json_stringify_full+0x101c>
1008477f8:     	ldr	x9, [x8]
1008477fc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100847800:     	cmp	x9, x10
100847804:     	b.hs	0x1008484dc <_js_json_stringify_full+0x1b5c>
100847808:     	add	x10, x9, #0x1
10084780c:     	str	x10, [x8]
100847810:     	ldr	x10, [x8, #0x18]
100847814:     	cmp	x19, x10
100847818:     	b.hs	0x1008484e8 <_js_json_stringify_full+0x1b68>
10084781c:     	ldr	x10, [x8, #0x10]
100847820:     	mov	w11, #0x18              ; =24
100847824:     	madd	x10, x19, x11, x10
100847828:     	ldr	x11, [x10]
10084782c:     	cbnz	x11, 0x100848548 <_js_json_stringify_full+0x1bc8>
100847830:     	ldr	x0, [x10, #0x8]
100847834:     	str	x9, [x8]
100847838:     	b	0x1008479a4 <_js_json_stringify_full+0x1024>
10084783c:     	mov	x8, #0x0                ; =0
100847840:     	mov	w9, #0x1                ; =1
100847844:     	stp	x9, xzr, [sp, #0x50]
100847848:     	str	x8, [sp, #0x48]
10084784c:     	tbnz	w24, #0x0, 0x100847780 <_js_json_stringify_full+0xe00>
100847850:     	cmp	x22, #0x0
100847854:     	cset	w6, ne
100847858:     	ldp	x0, x1, [sp, #0x38]
10084785c:     	ldp	x3, x4, [sp, #0x18]
100847860:     	add	x2, sp, #0x48
100847864:     	mov.16b	v0, v8
100847868:     	mov	x5, #0x0                ; =0
10084786c:     	bl	0x100503740 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
100847870:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847874:     	add	x0, x0, #0xd90
100847878:     	ldr	x8, [x0]
10084787c:     	blr	x8
100847880:     	ldrb	w8, [x0, #0x20]
100847884:     	cbnz	w8, 0x10084846c <_js_json_stringify_full+0x1aec>
100847888:     	ldr	x8, [x0]
10084788c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100847890:     	cmp	x8, x9
100847894:     	b.hs	0x10084849c <_js_json_stringify_full+0x1b1c>
100847898:     	ldr	x9, [x0, #0x18]
10084789c:     	cbz	x9, 0x1008478a8 <_js_json_stringify_full+0xf28>
1008478a0:     	cbnz	x8, 0x1008484a8 <_js_json_stringify_full+0x1b28>
1008478a4:     	str	xzr, [x0, #0x18]
1008478a8:     	ldp	x0, x1, [sp, #0x50]
1008478ac:     	cmp	x1, #0x5
1008478b0:     	b.hi	0x100847918 <_js_json_stringify_full+0xf98>
1008478b4:     	cbz	x1, 0x100847b28 <_js_json_stringify_full+0x11a8>
1008478b8:     	ldrsb	w8, [x0]
1008478bc:     	tbnz	w8, #0x1f, 0x100847918 <_js_json_stringify_full+0xf98>
1008478c0:     	cmp	x1, #0x1
1008478c4:     	b.eq	0x100847900 <_js_json_stringify_full+0xf80>
1008478c8:     	ldrsb	w8, [x0, #0x1]
1008478cc:     	tbnz	w8, #0x1f, 0x100847918 <_js_json_stringify_full+0xf98>
1008478d0:     	cmp	x1, #0x2
1008478d4:     	b.eq	0x100847900 <_js_json_stringify_full+0xf80>
1008478d8:     	ldrsb	w8, [x0, #0x2]
1008478dc:     	tbnz	w8, #0x1f, 0x100847918 <_js_json_stringify_full+0xf98>
1008478e0:     	cmp	x1, #0x3
1008478e4:     	b.eq	0x100847900 <_js_json_stringify_full+0xf80>
1008478e8:     	ldrsb	w8, [x0, #0x3]
1008478ec:     	tbnz	w8, #0x1f, 0x100847918 <_js_json_stringify_full+0xf98>
1008478f0:     	cmp	x1, #0x4
1008478f4:     	b.eq	0x100847900 <_js_json_stringify_full+0xf80>
1008478f8:     	ldrsb	w8, [x0, #0x4]
1008478fc:     	tbnz	w8, #0x1f, 0x100847918 <_js_json_stringify_full+0xf98>
100847900:     	cmp	x1, #0x4
100847904:     	b.hs	0x100847c68 <_js_json_stringify_full+0x12e8>
100847908:     	mov	x10, #0x0               ; =0
10084790c:     	mov	x9, #0x0                ; =0
100847910:     	mov	x8, x0
100847914:     	b	0x100847cf8 <_js_json_stringify_full+0x1378>
100847918:     	bl	0x10032ab48 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
10084791c:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100847920:     	bfxil	x20, x0, #0, #48
100847924:     	ldp	x22, x0, [sp, #0x48]
100847928:     	ldrb	w8, [x23, #0x18]
10084792c:     	cmp	w8, #0x1
100847930:     	b.eq	0x100847d34 <_js_json_stringify_full+0x13b4>
100847934:     	b	0x100848438 <_js_json_stringify_full+0x1ab8>
100847938:     	mov	w0, #0x0                ; =0
10084793c:     	bl	0x10034be6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100847940:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100847944:     	bfxil	x8, x0, #0, #48
100847948:     	fmov	d1, x8
10084794c:     	stp	xzr, xzr, [x0]
100847950:     	str	wzr, [x0, #0x10]
100847954:     	mov.16b	v0, v8
100847958:     	bl	0x1006c6f50 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
10084795c:     	mov.16b	v8, v0
100847960:     	fmov	x24, d8
100847964:     	cmp	x24, x20
100847968:     	b.eq	0x100847bb0 <_js_json_stringify_full+0x1230>
10084796c:     	mov	w8, #0x7ffd             ; =32765
100847970:     	cmp	x8, x24, lsr #48
100847974:     	b.ne	0x100847b80 <_js_json_stringify_full+0x1200>
100847978:     	and	x8, x24, #0xffffffffffff
10084797c:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100847980:     	b.lo	0x100847ba4 <_js_json_stringify_full+0x1224>
100847984:     	ldr	w8, [x8, #0xc]
100847988:     	mov	w9, #0x4f53             ; =20307
10084798c:     	movk	w9, #0x434c, lsl #16
100847990:     	cmp	w8, w9
100847994:     	b.ne	0x100847ba4 <_js_json_stringify_full+0x1224>
100847998:     	b	0x100847bb0 <_js_json_stringify_full+0x1230>
10084799c:     	mov	x0, x19
1008479a0:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
1008479a4:     	fmov	d1, x0
1008479a8:     	mov.16b	v0, v8
1008479ac:     	bl	0x1006c6f50 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer6tojson19apply_to_json_keyed>
1008479b0:     	mov.16b	v8, v0
1008479b4:     	ldr	x8, [x24, #0x48]
1008479b8:     	cmn	x8, #0x1
1008479bc:     	b.eq	0x100847a20 <_js_json_stringify_full+0x10a0>
1008479c0:     	mrs	x9, TPIDRRO_EL0
1008479c4:     	and	x9, x9, #0xfffffffffffffff8
1008479c8:     	ldr	x8, [x9, x8, lsl #3]
1008479cc:     	cbz	x8, 0x100847a20 <_js_json_stringify_full+0x10a0>
1008479d0:     	ldr	x8, [x8, #0x19e8]
1008479d4:     	cbz	x8, 0x100847a20 <_js_json_stringify_full+0x10a0>
1008479d8:     	ldr	x9, [x8]
1008479dc:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1008479e0:     	cmp	x9, x10
1008479e4:     	b.hs	0x1008484dc <_js_json_stringify_full+0x1b5c>
1008479e8:     	add	x10, x9, #0x1
1008479ec:     	str	x10, [x8]
1008479f0:     	ldr	x10, [x8, #0x18]
1008479f4:     	cmp	x22, x10
1008479f8:     	b.hs	0x1008484e8 <_js_json_stringify_full+0x1b68>
1008479fc:     	ldr	x10, [x8, #0x10]
100847a00:     	mov	w11, #0x18              ; =24
100847a04:     	madd	x10, x22, x11, x10
100847a08:     	ldr	x11, [x10]
100847a0c:     	cmp	x11, #0x1
100847a10:     	b.ne	0x1008485a8 <_js_json_stringify_full+0x1c28>
100847a14:     	ldr	x22, [x10, #0x8]
100847a18:     	str	x9, [x8]
100847a1c:     	b	0x100847a2c <_js_json_stringify_full+0x10ac>
100847a20:     	mov	x0, x22
100847a24:     	bl	0x10013c298 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
100847a28:     	mov	x22, x0
100847a2c:     	ldr	x8, [x24, #0x48]
100847a30:     	cmn	x8, #0x1
100847a34:     	b.eq	0x100847a94 <_js_json_stringify_full+0x1114>
100847a38:     	mrs	x9, TPIDRRO_EL0
100847a3c:     	and	x9, x9, #0xfffffffffffffff8
100847a40:     	ldr	x8, [x9, x8, lsl #3]
100847a44:     	cbz	x8, 0x100847a94 <_js_json_stringify_full+0x1114>
100847a48:     	ldr	x8, [x8, #0x19e8]
100847a4c:     	cbz	x8, 0x100847a94 <_js_json_stringify_full+0x1114>
100847a50:     	ldr	x9, [x8]
100847a54:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100847a58:     	cmp	x9, x10
100847a5c:     	b.hs	0x1008484dc <_js_json_stringify_full+0x1b5c>
100847a60:     	add	x10, x9, #0x1
100847a64:     	str	x10, [x8]
100847a68:     	ldr	x10, [x8, #0x18]
100847a6c:     	cmp	x19, x10
100847a70:     	b.hs	0x1008484e8 <_js_json_stringify_full+0x1b68>
100847a74:     	ldr	x10, [x8, #0x10]
100847a78:     	mov	w11, #0x18              ; =24
100847a7c:     	madd	x10, x19, x11, x10
100847a80:     	ldr	x11, [x10]
100847a84:     	cbnz	x11, 0x100848548 <_js_json_stringify_full+0x1bc8>
100847a88:     	ldr	x0, [x10, #0x8]
100847a8c:     	str	x9, [x8]
100847a90:     	b	0x100847a9c <_js_json_stringify_full+0x111c>
100847a94:     	mov	x0, x19
100847a98:     	bl	0x10013c370 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100847a9c:     	fmov	d9, x0
100847aa0:     	mov.16b	v0, v8
100847aa4:     	bl	0x1005000f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100847aa8:     	mov.16b	v2, v0
100847aac:     	mov	x0, x22
100847ab0:     	mov.16b	v0, v9
100847ab4:     	mov.16b	v1, v8
100847ab8:     	bl	0x1005003d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
100847abc:     	str	d0, [sp, #0x70]
100847ac0:     	fmov	x19, d0
100847ac4:     	cmp	x19, x20
100847ac8:     	b.ne	0x100847b30 <_js_json_stringify_full+0x11b0>
100847acc:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847ad0:     	add	x0, x0, #0xd90
100847ad4:     	ldr	x8, [x0]
100847ad8:     	blr	x8
100847adc:     	ldrb	w8, [x0, #0x20]
100847ae0:     	cbnz	w8, 0x100848588 <_js_json_stringify_full+0x1c08>
100847ae4:     	ldr	x8, [x0]
100847ae8:     	cbnz	x8, 0x1008485d8 <_js_json_stringify_full+0x1c58>
100847aec:     	str	xzr, [x0, #0x18]
100847af0:     	ldp	x22, x19, [sp, #0x48]
100847af4:     	ldrb	w8, [x23, #0x18]
100847af8:     	cmp	w8, #0x1
100847afc:     	b.ne	0x100848520 <_js_json_stringify_full+0x1ba0>
100847b00:     	ldp	x8, x0, [x23]
100847b04:     	stp	x22, x19, [x23]
100847b08:     	str	xzr, [x23, #0x10]
100847b0c:     	sub	x8, x8, #0x1
100847b10:     	cmn	x8, #0x2
100847b14:     	b.hs	0x100847b1c <_js_json_stringify_full+0x119c>
100847b18:     	bl	0x100b60400 <_mi_free>
100847b1c:     	cbz	w26, 0x100847dbc <_js_json_stringify_full+0x143c>
100847b20:     	bl	0x100328da8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100847b24:     	b	0x100847dc0 <_js_json_stringify_full+0x1440>
100847b28:     	mov	x10, #0x0               ; =0
100847b2c:     	b	0x100847d18 <_js_json_stringify_full+0x1398>
100847b30:     	add	x0, sp, #0x48
100847b34:     	bl	0x100500db4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
100847b38:     	tbnz	w0, #0x0, 0x100847b74 <_js_json_stringify_full+0x11f4>
100847b3c:     	mov	x0, x19
100847b40:     	bl	0x100328aac <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
100847b44:     	cmp	x0, #0x1
100847b48:     	b.ne	0x10084859c <_js_json_stringify_full+0x1c1c>
100847b4c:     	add	x8, sp, #0x78
100847b50:     	add	x9, sp, #0x70
100847b54:     	stp	x1, x8, [sp, #0x78]
100847b58:     	str	x9, [sp, #0x88]
100847b5c:     	add	x8, sp, #0x48
100847b60:     	add	x9, sp, #0x10
100847b64:     	stp	x8, x9, [sp, #0x90]
100847b68:     	add	x0, sp, #0x68
100847b6c:     	add	x1, sp, #0x80
100847b70:     	bl	0x100143d90 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
100847b74:     	add	x0, sp, #0x60
100847b78:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100847b7c:     	b	0x100847870 <_js_json_stringify_full+0xef0>
100847b80:     	lsr	x8, x24, #52
100847b84:     	cbnz	x8, 0x100847ba4 <_js_json_stringify_full+0x1224>
100847b88:     	cbz	x24, 0x100847ba4 <_js_json_stringify_full+0x1224>
100847b8c:     	and	x8, x24, #0x7
100847b90:     	cbnz	x8, 0x100847ba4 <_js_json_stringify_full+0x1224>
100847b94:     	mov	x0, x24
100847b98:     	bl	0x10050fc38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100847b9c:     	mov	x8, x24
100847ba0:     	tbnz	w0, #0x0, 0x10084797c <_js_json_stringify_full+0xffc>
100847ba4:     	mov	x0, x24
100847ba8:     	bl	0x100509fa4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
100847bac:     	tbz	w0, #0x0, 0x100847c3c <_js_json_stringify_full+0x12bc>
100847bb0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847bb4:     	add	x0, x0, #0xd90
100847bb8:     	ldr	x8, [x0]
100847bbc:     	blr	x8
100847bc0:     	ldrb	w8, [x0, #0x20]
100847bc4:     	cbnz	w8, 0x1008484ec <_js_json_stringify_full+0x1b6c>
100847bc8:     	ldr	x8, [x0]
100847bcc:     	cbnz	x8, 0x100848514 <_js_json_stringify_full+0x1b94>
100847bd0:     	str	xzr, [x0, #0x18]
100847bd4:     	ldp	x22, x19, [sp, #0x48]
100847bd8:     	ldrb	w8, [x23, #0x18]
100847bdc:     	cmp	w8, #0x1
100847be0:     	b.ne	0x1008484c8 <_js_json_stringify_full+0x1b48>
100847be4:     	ldp	x8, x0, [x23]
100847be8:     	stp	x22, x19, [x23]
100847bec:     	str	xzr, [x23, #0x10]
100847bf0:     	sub	x8, x8, #0x1
100847bf4:     	cmn	x8, #0x2
100847bf8:     	b.hs	0x100847c00 <_js_json_stringify_full+0x1280>
100847bfc:     	bl	0x100b60400 <_mi_free>
100847c00:     	cbz	w26, 0x100847c20 <_js_json_stringify_full+0x12a0>
100847c04:     	bl	0x100328da8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100847c08:     	ldr	w8, [x21]
100847c0c:     	sub	w8, w8, #0x1
100847c10:     	str	w8, [x21]
100847c14:     	cmn	x25, #0x1
100847c18:     	b.ne	0x100847ddc <_js_json_stringify_full+0x145c>
100847c1c:     	b	0x100847e18 <_js_json_stringify_full+0x1498>
100847c20:     	bl	0x100328bd8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100847c24:     	ldr	w8, [x21]
100847c28:     	sub	w8, w8, #0x1
100847c2c:     	str	w8, [x21]
100847c30:     	cmn	x25, #0x1
100847c34:     	b.ne	0x100847ddc <_js_json_stringify_full+0x145c>
100847c38:     	b	0x100847e18 <_js_json_stringify_full+0x1498>
100847c3c:     	cmp	x19, x24
100847c40:     	b.eq	0x100847c4c <_js_json_stringify_full+0x12cc>
100847c44:     	mov.16b	v0, v8
100847c48:     	bl	0x10050f36c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
100847c4c:     	cbz	x22, 0x100847ea8 <_js_json_stringify_full+0x1528>
100847c50:     	ldp	x1, x2, [sp, #0x18]
100847c54:     	add	x0, sp, #0x48
100847c58:     	mov.16b	v0, v8
100847c5c:     	mov	x3, #0x0                ; =0
100847c60:     	bl	0x10050182c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
100847c64:     	b	0x100847eb8 <_js_json_stringify_full+0x1538>
100847c68:     	and	x9, x1, #0x4
100847c6c:     	add	x8, x0, x9
100847c70:     	adrp	x10, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x49f0>
100847c74:     	ldr	q0, [x10, #0xe80]
100847c78:     	adrp	x10, 0x100c3a000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x331fa>
100847c7c:     	ldr	q2, [x10, #0xd80]
100847c80:     	movi.2d	v1, #0000000000000000
100847c84:     	movi.2d	v3, #0x000000000000ff
100847c88:     	mov	w10, #0x4               ; =4
100847c8c:     	dup.2d	v4, x10
100847c90:     	mov	x10, x0
100847c94:     	and	x11, x1, #0x4
100847c98:     	movi.2d	v5, #0000000000000000
100847c9c:     	ldr	s6, [x10], #0x4
100847ca0:     	ushll.8h	v6, v6, #0x0
100847ca4:     	ushll.4s	v6, v6, #0x0
100847ca8:     	ushll2.2d	v7, v6, #0x0
100847cac:     	and.16b	v7, v7, v3
100847cb0:     	ushll.2d	v6, v6, #0x0
100847cb4:     	and.16b	v6, v6, v3
100847cb8:     	shl.2d	v16, v0, #0x3
100847cbc:     	shl.2d	v17, v2, #0x3
100847cc0:     	ushl.2d	v6, v6, v17
100847cc4:     	ushl.2d	v7, v7, v16
100847cc8:     	orr.16b	v1, v7, v1
100847ccc:     	orr.16b	v5, v6, v5
100847cd0:     	add.2d	v0, v0, v4
100847cd4:     	add.2d	v2, v2, v4
100847cd8:     	subs	x11, x11, #0x4
100847cdc:     	b.ne	0x100847c9c <_js_json_stringify_full+0x131c>
100847ce0:     	orr.16b	v0, v5, v1
100847ce4:     	mov	d1, v0[1]
100847ce8:     	orr.8b	v0, v0, v1
100847cec:     	fmov	x10, d0
100847cf0:     	cmp	x1, x9
100847cf4:     	b.eq	0x100847d18 <_js_json_stringify_full+0x1398>
100847cf8:     	add	x11, x0, x1
100847cfc:     	lsl	x9, x9, #3
100847d00:     	ldrb	w12, [x8], #0x1
100847d04:     	lsl	x12, x12, x9
100847d08:     	orr	x10, x12, x10
100847d0c:     	add	x9, x9, #0x8
100847d10:     	cmp	x8, x11
100847d14:     	b.ne	0x100847d00 <_js_json_stringify_full+0x1380>
100847d18:     	orr	x8, x10, x1, lsl #40
100847d1c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100847d20:     	orr	x20, x8, x9
100847d24:     	ldr	x22, [sp, #0x48]
100847d28:     	ldrb	w8, [x23, #0x18]
100847d2c:     	cmp	w8, #0x1
100847d30:     	b.ne	0x100848438 <_js_json_stringify_full+0x1ab8>
100847d34:     	ldp	x9, x8, [x23]
100847d38:     	stp	x22, x0, [x23]
100847d3c:     	str	xzr, [x23, #0x10]
100847d40:     	sub	x9, x9, #0x1
100847d44:     	cmn	x9, #0x2
100847d48:     	b.hs	0x100847d54 <_js_json_stringify_full+0x13d4>
100847d4c:     	mov	x0, x8
100847d50:     	bl	0x100b60400 <_mi_free>
100847d54:     	cbz	w26, 0x100847d74 <_js_json_stringify_full+0x13f4>
100847d58:     	bl	0x100328da8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100847d5c:     	ldr	w8, [x21]
100847d60:     	sub	w8, w8, #0x1
100847d64:     	str	w8, [x21]
100847d68:     	cmn	x25, #0x1
100847d6c:     	b.ne	0x100847d8c <_js_json_stringify_full+0x140c>
100847d70:     	b	0x100847e18 <_js_json_stringify_full+0x1498>
100847d74:     	bl	0x100328bd8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100847d78:     	ldr	w8, [x21]
100847d7c:     	sub	w8, w8, #0x1
100847d80:     	str	w8, [x21]
100847d84:     	cmn	x25, #0x1
100847d88:     	b.eq	0x100847e18 <_js_json_stringify_full+0x1498>
100847d8c:     	ldp	x19, x21, [sp, #0x38]
100847d90:     	cbz	x21, 0x100847e0c <_js_json_stringify_full+0x148c>
100847d94:     	add	x22, x19, #0x8
100847d98:     	b	0x100847da8 <_js_json_stringify_full+0x1428>
100847d9c:     	add	x22, x22, #0x18
100847da0:     	subs	x21, x21, #0x1
100847da4:     	b.eq	0x100847e0c <_js_json_stringify_full+0x148c>
100847da8:     	ldur	x8, [x22, #-0x8]
100847dac:     	cbz	x8, 0x100847d9c <_js_json_stringify_full+0x141c>
100847db0:     	ldr	x0, [x22]
100847db4:     	bl	0x100b60400 <_mi_free>
100847db8:     	b	0x100847d9c <_js_json_stringify_full+0x141c>
100847dbc:     	bl	0x100328bd8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100847dc0:     	ldr	w8, [x21]
100847dc4:     	sub	w8, w8, #0x1
100847dc8:     	str	w8, [x21]
100847dcc:     	add	x0, sp, #0x60
100847dd0:     	bl	0x100166e7c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
100847dd4:     	cmn	x25, #0x1
100847dd8:     	b.eq	0x100847e18 <_js_json_stringify_full+0x1498>
100847ddc:     	ldp	x19, x21, [sp, #0x38]
100847de0:     	cbz	x21, 0x100847e0c <_js_json_stringify_full+0x148c>
100847de4:     	add	x22, x19, #0x8
100847de8:     	b	0x100847df8 <_js_json_stringify_full+0x1478>
100847dec:     	add	x22, x22, #0x18
100847df0:     	subs	x21, x21, #0x1
100847df4:     	b.eq	0x100847e0c <_js_json_stringify_full+0x148c>
100847df8:     	ldur	x8, [x22, #-0x8]
100847dfc:     	cbz	x8, 0x100847dec <_js_json_stringify_full+0x146c>
100847e00:     	ldr	x0, [x22]
100847e04:     	bl	0x100b60400 <_mi_free>
100847e08:     	b	0x100847dec <_js_json_stringify_full+0x146c>
100847e0c:     	cbz	x25, 0x100847e18 <_js_json_stringify_full+0x1498>
100847e10:     	mov	x0, x19
100847e14:     	bl	0x100b60400 <_mi_free>
100847e18:     	ldr	x8, [sp, #0x10]
100847e1c:     	cbz	x8, 0x100847e28 <_js_json_stringify_full+0x14a8>
100847e20:     	ldr	x0, [sp, #0x18]
100847e24:     	bl	0x100b60400 <_mi_free>
100847e28:     	mov	x0, x20
100847e2c:     	ldp	x29, x30, [sp, #0x110]
100847e30:     	ldp	x20, x19, [sp, #0x100]
100847e34:     	ldp	x22, x21, [sp, #0xf0]
100847e38:     	ldp	x24, x23, [sp, #0xe0]
100847e3c:     	ldp	x26, x25, [sp, #0xd0]
100847e40:     	ldp	x28, x27, [sp, #0xc0]
100847e44:     	ldp	d9, d8, [sp, #0xb0]
100847e48:     	add	sp, sp, #0x120
100847e4c:     	ret
100847e50:     	str	x22, [sp, #0x8]
100847e54:     	mov	x22, x28
100847e58:     	mov	x28, x0
100847e5c:     	add	x0, x0, #0x8
100847e60:     	bl	0x100b3d150 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100847e64:     	mov	x0, x28
100847e68:     	mov	x28, x22
100847e6c:     	ldr	x22, [sp, #0x8]
100847e70:     	b	0x100847698 <_js_json_stringify_full+0xd18>
100847e74:     	b.ne	0x1008473dc <_js_json_stringify_full+0xa5c>
100847e78:     	tbz	x25, #0x3f, 0x100847ed0 <_js_json_stringify_full+0x1550>
100847e7c:     	mov	x0, #0x0                ; =0
100847e80:     	mov	x1, x25
100847e84:     	bl	0x100b13780 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100847e88:     	bl	0x100b407fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100847e8c:     	add	x8, x0, x23, lsl #3
100847e90:     	ldr	x0, [x8, #0x1e8]
100847e94:     	cbnz	x0, 0x10084772c <_js_json_stringify_full+0xdac>
100847e98:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100847e9c:     	add	x0, x0, #0x138
100847ea0:     	bl	0x100b3e01c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100847ea4:     	b	0x10084772c <_js_json_stringify_full+0xdac>
100847ea8:     	add	x1, sp, #0x48
100847eac:     	mov.16b	v0, v8
100847eb0:     	mov	w0, #0x0                ; =0
100847eb4:     	bl	0x10050a07c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100847eb8:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100847ebc:     	add	x0, x0, #0xdc0
100847ec0:     	ldr	x8, [x0]
100847ec4:     	blr	x8
100847ec8:     	strb	wzr, [x0]
100847ecc:     	b	0x100847870 <_js_json_stringify_full+0xef0>
100847ed0:     	mov	x0, x25
100847ed4:     	mov	w1, #0x1                ; =1
100847ed8:     	bl	0x100b60688 <_mi_malloc_aligned>
100847edc:     	mov	x26, x0
100847ee0:     	mov	w0, #0x1                ; =1
100847ee4:     	cbz	x26, 0x100847e80 <_js_json_stringify_full+0x1500>
100847ee8:     	mov	x0, x26
100847eec:     	mov	x1, x23
100847ef0:     	mov	x2, x25
100847ef4:     	bl	0x100b632ac <_writev+0x100b632ac>
100847ef8:     	mov	x22, x25
100847efc:     	b	0x100847400 <_js_json_stringify_full+0xa80>
100847f00:     	cmp	w11, #0x8
100847f04:     	b.eq	0x100847fd0 <_js_json_stringify_full+0x1650>
100847f08:     	cmp	w11, #0x9
100847f0c:     	b.eq	0x100847fe0 <_js_json_stringify_full+0x1660>
100847f10:     	cmp	w11, #0xa
100847f14:     	b.ne	0x100847f5c <_js_json_stringify_full+0x15dc>
100847f18:     	mov	w10, #0x6e              ; =110
100847f1c:     	b	0x100847fe4 <_js_json_stringify_full+0x1664>
100847f20:     	mov	x22, x0
100847f24:     	and	x0, x19, #0xffffffffffff
100847f28:     	bl	0x100348900 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
100847f2c:     	cbz	x0, 0x100848008 <_js_json_stringify_full+0x1688>
100847f30:     	ldr	w20, [x0]
100847f34:     	cmp	w20, #0x4
100847f38:     	b.hi	0x100846f58 <_js_json_stringify_full+0x5d8>
100847f3c:     	ldr	w8, [x0, #0x4]
100847f40:     	cmp	w20, w8
100847f44:     	b.hi	0x100846f58 <_js_json_stringify_full+0x5d8>
100847f48:     	b	0x10084800c <_js_json_stringify_full+0x168c>
100847f4c:     	cmp	w11, #0x22
100847f50:     	b.eq	0x100847fe4 <_js_json_stringify_full+0x1664>
100847f54:     	cmp	w11, #0x5c
100847f58:     	b.eq	0x100847fe4 <_js_json_stringify_full+0x1664>
100847f5c:     	cmp	x12, #0x3
100847f60:     	mov	w11, #0x20              ; =32
100847f64:     	ccmp	w10, w11, #0x8, ls
100847f68:     	b.lt	0x100846e94 <_js_json_stringify_full+0x514>
100847f6c:     	add	x8, sp, #0x80
100847f70:     	strb	w10, [x8, x12]
100847f74:     	add	x12, x12, #0x1
100847f78:     	b	0x100846b84 <_js_json_stringify_full+0x204>
100847f7c:     	mov	x1, x0
100847f80:     	and	x0, x19, #0xffffffffffff
100847f84:     	mov	x22, x1
100847f88:     	bl	0x1004f9ac0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
100847f8c:     	cmp	x0, #0x1
100847f90:     	b.ne	0x1008480b4 <_js_json_stringify_full+0x1734>
100847f94:     	mov	x20, x1
100847f98:     	b	0x100847e28 <_js_json_stringify_full+0x14a8>
100847f9c:     	ldrb	w9, [x8, #0x118]
100847fa0:     	cbz	w9, 0x1008481dc <_js_json_stringify_full+0x185c>
100847fa4:     	ldr	x9, [x8, #0x110]
100847fa8:     	cmp	x9, x1
100847fac:     	b.ne	0x1008481dc <_js_json_stringify_full+0x185c>
100847fb0:     	ldr	x9, [x8, #0xf0]
100847fb4:     	cmp	x9, x23
100847fb8:     	b.hi	0x1008481dc <_js_json_stringify_full+0x185c>
100847fbc:     	ldr	x9, [x8, #0xf8]
100847fc0:     	cmp	x9, x23
100847fc4:     	b.ls	0x1008481dc <_js_json_stringify_full+0x185c>
100847fc8:     	add	x9, x8, #0xf0
100847fcc:     	b	0x1008483e8 <_js_json_stringify_full+0x1a68>
100847fd0:     	mov	w10, #0x62              ; =98
100847fd4:     	b	0x100847fe4 <_js_json_stringify_full+0x1664>
100847fd8:     	mov	w10, #0x66              ; =102
100847fdc:     	b	0x100847fe4 <_js_json_stringify_full+0x1664>
100847fe0:     	mov	w10, #0x74              ; =116
100847fe4:     	cmp	x12, #0x2
100847fe8:     	b.hi	0x100846e94 <_js_json_stringify_full+0x514>
100847fec:     	add	x8, sp, #0x80
100847ff0:     	add	x8, x8, x12
100847ff4:     	add	x12, x12, #0x2
100847ff8:     	mov	w11, #0x5c              ; =92
100847ffc:     	strb	w11, [x8]
100848000:     	strb	w10, [x8, #0x1]
100848004:     	b	0x100846b84 <_js_json_stringify_full+0x204>
100848008:     	mov	x20, #0x0               ; =0
10084800c:     	ldr	w8, [x22, #0x4]
100848010:     	lsl	x9, x20, #3
100848014:     	add	x9, x9, #0x18
100848018:     	cmp	x9, x8
10084801c:     	b.hi	0x100846f58 <_js_json_stringify_full+0x5d8>
100848020:     	ldr	w8, [x25, #0x4]
100848024:     	mov	w9, #-0x40000000        ; =-1073741824
100848028:     	cmp	w8, w9
10084802c:     	csel	w8, w8, wzr, lt
100848030:     	mov	x22, x0
100848034:     	mov	x0, x8
100848038:     	bl	0x1005e61e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084803c:     	mov	w9, #0x2                ; =2
100848040:     	cmp	w1, #0x2
100848044:     	csel	w10, w1, w9, hi
100848048:     	tst	w0, #0x1
10084804c:     	csel	x8, x10, x9, ne
100848050:     	cmp	x20, x8
100848054:     	b.hi	0x100846f58 <_js_json_stringify_full+0x5d8>
100848058:     	cbz	x20, 0x100848418 <_js_json_stringify_full+0x1a98>
10084805c:     	mov	x0, x22
100848060:     	mov	x1, x20
100848064:     	bl	0x1004f0a80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100848068:     	tbz	w0, #0x0, 0x100846f58 <_js_json_stringify_full+0x5d8>
10084806c:     	cmp	x20, #0x1
100848070:     	b.eq	0x1008484b4 <_js_json_stringify_full+0x1b34>
100848074:     	cmp	x20, #0x2
100848078:     	b.ne	0x100848570 <_js_json_stringify_full+0x1bf0>
10084807c:     	mov	x22, #0x0               ; =0
100848080:     	add	x25, x25, #0x10
100848084:     	mov	w8, #0x1                ; =1
100848088:     	mov	x26, x8
10084808c:     	ldr	x1, [x25, x22, lsl #3]
100848090:     	add	x0, sp, #0x80
100848094:     	bl	0x1004f0ad4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
100848098:     	ldr	w8, [sp, #0x80]
10084809c:     	cmn	w8, #0x1
1008480a0:     	b.ne	0x100848558 <_js_json_stringify_full+0x1bd8>
1008480a4:     	mov	w8, #0x0                ; =0
1008480a8:     	mov	w22, #0x1               ; =1
1008480ac:     	tbnz	w26, #0x0, 0x100848088 <_js_json_stringify_full+0x1708>
1008480b0:     	b	0x100848570 <_js_json_stringify_full+0x1bf0>
1008480b4:     	and	x0, x19, #0xffffffffffff
1008480b8:     	bl	0x100348900 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1008480bc:     	cbz	x0, 0x100848148 <_js_json_stringify_full+0x17c8>
1008480c0:     	ldr	w20, [x0]
1008480c4:     	cbz	w20, 0x100848148 <_js_json_stringify_full+0x17c8>
1008480c8:     	cmp	w20, #0x8
1008480cc:     	b.hi	0x100846f24 <_js_json_stringify_full+0x5a4>
1008480d0:     	ldr	w8, [x0, #0x4]
1008480d4:     	cmp	w20, w8
1008480d8:     	b.hi	0x100846f24 <_js_json_stringify_full+0x5a4>
1008480dc:     	ldr	w8, [x22, #0x4]
1008480e0:     	lsl	x9, x20, #3
1008480e4:     	add	x9, x9, #0x18
1008480e8:     	cmp	x9, x8
1008480ec:     	b.hi	0x100846f24 <_js_json_stringify_full+0x5a4>
1008480f0:     	ldr	w8, [x25, #0x4]
1008480f4:     	mov	w9, #-0x40000000        ; =-1073741824
1008480f8:     	cmp	w8, w9
1008480fc:     	csel	w8, w8, wzr, lt
100848100:     	mov	x22, x0
100848104:     	mov	x0, x8
100848108:     	bl	0x1005e61e4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
10084810c:     	mov	w9, #0x2                ; =2
100848110:     	cmp	w1, #0x2
100848114:     	csel	w10, w1, w9, hi
100848118:     	tst	w0, #0x1
10084811c:     	csel	w8, w10, w9, ne
100848120:     	cmp	w20, w8
100848124:     	b.hi	0x100846f24 <_js_json_stringify_full+0x5a4>
100848128:     	mov	x0, x22
10084812c:     	mov	x1, x20
100848130:     	bl	0x1004f0a80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100848134:     	cbz	w0, 0x100846f24 <_js_json_stringify_full+0x5a4>
100848138:     	and	x0, x19, #0xffffffffffff
10084813c:     	mov	x1, x20
100848140:     	bl	0x1004f8c00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
100848144:     	b	0x100848150 <_js_json_stringify_full+0x17d0>
100848148:     	and	x0, x19, #0xffffffffffff
10084814c:     	bl	0x1004f9980 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
100848150:     	mov	x20, x1
100848154:     	tbz	w0, #0x0, 0x100846f24 <_js_json_stringify_full+0x5a4>
100848158:     	b	0x100847e28 <_js_json_stringify_full+0x14a8>
10084815c:     	add	x9, x8, #0x60
100848160:     	b	0x1008483e8 <_js_json_stringify_full+0x1a68>
100848164:     	bl	0x100b407fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100848168:     	lsr	x1, x23, #20
10084816c:     	ldr	x8, [x0, #0x10]
100848170:     	ldrb	w9, [x8]
100848174:     	cmp	w9, #0x2
100848178:     	b.eq	0x100847508 <_js_json_stringify_full+0xb88>
10084817c:     	ldr	x9, [x8, #0x8]
100848180:     	ldr	x10, [x8, #0x28]
100848184:     	sub	x9, x1, x9
100848188:     	cmp	x9, x10
10084818c:     	b.hs	0x1008481d0 <_js_json_stringify_full+0x1850>
100848190:     	ldr	x10, [x8, #0x20]
100848194:     	mov	w11, #0x28              ; =40
100848198:     	madd	x9, x9, x11, x10
10084819c:     	ldr	x10, [x9]
1008481a0:     	ldr	x11, [x8, #0x10]
1008481a4:     	cmp	x10, x11
1008481a8:     	b.ne	0x1008481dc <_js_json_stringify_full+0x185c>
1008481ac:     	ldp	x10, x11, [x9, #0x8]
1008481b0:     	cmp	x10, x23
1008481b4:     	ccmp	x11, x23, #0x0, ls
1008481b8:     	b.ls	0x1008481dc <_js_json_stringify_full+0x185c>
1008481bc:     	ldr	x10, [x8, #0x30]
1008481c0:     	add	x10, x10, #0x1
1008481c4:     	str	x10, [x8, #0x30]
1008481c8:     	add	x8, x9, #0x21
1008481cc:     	b	0x1008483f8 <_js_json_stringify_full+0x1a78>
1008481d0:     	ldr	x9, [x8, #0x58]
1008481d4:     	add	x9, x9, #0x1
1008481d8:     	str	x9, [x8, #0x58]
1008481dc:     	ldr	x9, [x8, #0x38]
1008481e0:     	add	x9, x9, #0x1
1008481e4:     	str	x9, [x8, #0x38]
1008481e8:     	mov	x0, x23
1008481ec:     	bl	0x10051ee48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1008481f0:     	and	w8, w0, #0xff
1008481f4:     	cbz	w8, 0x100848214 <_js_json_stringify_full+0x1894>
1008481f8:     	ldurb	w8, [x23, #-0x8]
1008481fc:     	ldurb	w9, [x23, #-0x7]
100848200:     	mov	w10, #0x82              ; =130
100848204:     	and	w9, w9, w10
100848208:     	cmp	w9, #0x2
10084820c:     	ccmp	w8, #0x1, #0x0, eq
100848210:     	b.eq	0x1008482a8 <_js_json_stringify_full+0x1928>
100848214:     	mov	x0, x23
100848218:     	bl	0x10057b4c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084821c:     	mov	x24, x0
100848220:     	cbz	x0, 0x10084824c <_js_json_stringify_full+0x18cc>
100848224:     	ldrb	w8, [x24]
100848228:     	cmp	w8, #0x1
10084822c:     	b.ne	0x10084826c <_js_json_stringify_full+0x18ec>
100848230:     	ldrsb	w8, [x24, #0x1]
100848234:     	tbnz	w8, #0x1f, 0x1008482d0 <_js_json_stringify_full+0x1950>
100848238:     	mov	x0, x24
10084823c:     	ldp	w9, w8, [x23]
100848240:     	cmp	w9, w8
100848244:     	b.hi	0x100848354 <_js_json_stringify_full+0x19d4>
100848248:     	b	0x10084836c <_js_json_stringify_full+0x19ec>
10084824c:     	mov	x0, x23
100848250:     	bl	0x100589cf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100848254:     	tbnz	w0, #0x0, 0x100848264 <_js_json_stringify_full+0x18e4>
100848258:     	mov	x0, x23
10084825c:     	bl	0x1002a4c08 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100848260:     	tbz	w0, #0x0, 0x1008475a8 <_js_json_stringify_full+0xc28>
100848264:     	mov	x0, #0x0                ; =0
100848268:     	b	0x100848344 <_js_json_stringify_full+0x19c4>
10084826c:     	mov	x0, x24
100848270:     	cmp	w8, #0x1
100848274:     	b.eq	0x100848344 <_js_json_stringify_full+0x19c4>
100848278:     	cmp	w8, #0x9
10084827c:     	b.ne	0x1008475a8 <_js_json_stringify_full+0xc28>
100848280:     	ldr	w8, [x23, #0x4]
100848284:     	mov	w9, #0x5841             ; =22593
100848288:     	movk	w9, #0x4c5a, lsl #16
10084828c:     	cmp	w8, w9
100848290:     	b.ne	0x1008475a8 <_js_json_stringify_full+0xc28>
100848294:     	mov	x0, x23
100848298:     	bl	0x100376b10 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
10084829c:     	mov	x23, x0
1008482a0:     	cbnz	x0, 0x100848394 <_js_json_stringify_full+0x1a14>
1008482a4:     	b	0x1008475a8 <_js_json_stringify_full+0xc28>
1008482a8:     	ldr	w8, [x23]
1008482ac:     	mov	w9, #0xe100             ; =57600
1008482b0:     	movk	w9, #0x5f5, lsl #16
1008482b4:     	orr	w9, w9, #0x1
1008482b8:     	cmp	w8, w9
1008482bc:     	b.hs	0x100848214 <_js_json_stringify_full+0x1894>
1008482c0:     	ldr	w9, [x23, #0x4]
1008482c4:     	cmp	w8, w9
1008482c8:     	b.ls	0x100848394 <_js_json_stringify_full+0x1a14>
1008482cc:     	b	0x100848214 <_js_json_stringify_full+0x1894>
1008482d0:     	ldr	x23, [x24, #0x8]
1008482d4:     	mov	x0, x23
1008482d8:     	bl	0x10057b4c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1008482dc:     	cbz	x0, 0x1008475a8 <_js_json_stringify_full+0xc28>
1008482e0:     	ldrb	w8, [x0]
1008482e4:     	cmp	w8, #0x1
1008482e8:     	b.ne	0x1008475a8 <_js_json_stringify_full+0xc28>
1008482ec:     	ldrsb	w8, [x0, #0x1]
1008482f0:     	tbz	w8, #0x1f, 0x10084823c <_js_json_stringify_full+0x18bc>
1008482f4:     	mov	w26, #0x1               ; =1
1008482f8:     	ldr	x23, [x0, #0x8]
1008482fc:     	mov	x0, x23
100848300:     	bl	0x10057b4c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100848304:     	cbz	x0, 0x1008475a8 <_js_json_stringify_full+0xc28>
100848308:     	ldrb	w8, [x0]
10084830c:     	cmp	w8, #0x1
100848310:     	b.ne	0x1008475a8 <_js_json_stringify_full+0xc28>
100848314:     	cmp	w26, #0x3f
100848318:     	b.hi	0x1008475a8 <_js_json_stringify_full+0xc28>
10084831c:     	add	w26, w26, #0x1
100848320:     	ldrsb	w8, [x0, #0x1]
100848324:     	tbnz	w8, #0x1f, 0x1008482f8 <_js_json_stringify_full+0x1978>
100848328:     	str	x23, [x24, #0x8]
10084832c:     	ldrb	w8, [x24, #0x1]
100848330:     	orr	w8, w8, #0x80
100848334:     	strb	w8, [x24, #0x1]
100848338:     	ldrb	w8, [x0]
10084833c:     	cmp	w8, #0x1
100848340:     	b.ne	0x100848278 <_js_json_stringify_full+0x18f8>
100848344:     	ldp	w9, w8, [x23]
100848348:     	cmp	w9, w8
10084834c:     	b.ls	0x10084836c <_js_json_stringify_full+0x19ec>
100848350:     	cbz	x24, 0x10084837c <_js_json_stringify_full+0x19fc>
100848354:     	ldr	w9, [x0, #0x4]
100848358:     	ubfiz	x8, x8, #3, #32
10084835c:     	add	x8, x8, #0x10
100848360:     	cmp	x8, x9
100848364:     	b.eq	0x100848394 <_js_json_stringify_full+0x1a14>
100848368:     	b	0x10084837c <_js_json_stringify_full+0x19fc>
10084836c:     	mov	w8, #0xe100             ; =57600
100848370:     	movk	w8, #0x5f5, lsl #16
100848374:     	cmp	w9, w8
100848378:     	b.ls	0x100848394 <_js_json_stringify_full+0x1a14>
10084837c:     	mov	x0, x23
100848380:     	bl	0x100589cf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100848384:     	tbnz	w0, #0x0, 0x100848394 <_js_json_stringify_full+0x1a14>
100848388:     	mov	x0, x23
10084838c:     	bl	0x1002a4c08 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100848390:     	tbz	w0, #0x0, 0x1008475a8 <_js_json_stringify_full+0xc28>
100848394:     	ldp	w8, w9, [x23]
100848398:     	sub	w10, w9, #0x1
10084839c:     	mov	w11, #0x270f            ; =9999
1008483a0:     	cmp	w10, w11
1008483a4:     	ccmp	w8, w9, #0x2, lo
1008483a8:     	b.hi	0x1008475a8 <_js_json_stringify_full+0xc28>
1008483ac:     	and	x8, x21, #0xffffffffffff
1008483b0:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008483b4:     	cmp	x25, x9
1008483b8:     	csel	x1, x8, x21, eq
1008483bc:     	add	x0, sp, #0x30
1008483c0:     	bl	0x1005005bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer20extract_string_array>
1008483c4:     	ldr	x25, [sp, #0x30]
1008483c8:     	cmn	x25, #0x1
1008483cc:     	cset	w24, eq
1008483d0:     	cmp	x27, #0x1
1008483d4:     	cset	w8, hi
1008483d8:     	tst	w8, w24
1008483dc:     	b.ne	0x1008475c4 <_js_json_stringify_full+0xc44>
1008483e0:     	b	0x100847634 <_js_json_stringify_full+0xcb4>
1008483e4:     	add	x9, x8, #0x90
1008483e8:     	ldr	x10, [x8, #0x30]
1008483ec:     	add	x10, x10, #0x1
1008483f0:     	str	x10, [x8, #0x30]
1008483f4:     	add	x8, x9, #0x19
1008483f8:     	ldrb	w8, [x8]
1008483fc:     	cmp	w8, #0xff
100848400:     	b.ne	0x1008481f4 <_js_json_stringify_full+0x1874>
100848404:     	b	0x1008481e8 <_js_json_stringify_full+0x1868>
100848408:     	mov	x0, x23
10084840c:     	bl	0x100b1f984 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100848410:     	cbnz	x0, 0x100847750 <_js_json_stringify_full+0xdd0>
100848414:     	b	0x100848590 <_js_json_stringify_full+0x1c10>
100848418:     	and	x0, x19, #0xffffffffffff
10084841c:     	bl	0x1004f8a30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
100848420:     	mov	w0, w0
100848424:     	mov	x20, #0x7d7b            ; =32123
100848428:     	movk	x20, #0x200, lsl #32
10084842c:     	movk	x20, #0x7ff9, lsl #48
100848430:     	tbz	w0, #0x0, 0x100846f58 <_js_json_stringify_full+0x5d8>
100848434:     	b	0x100847e28 <_js_json_stringify_full+0x14a8>
100848438:     	mov	x19, x0
10084843c:     	mov	x0, x23
100848440:     	bl	0x100b1f984 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100848444:     	mov	x23, x0
100848448:     	mov	x0, x19
10084844c:     	cbnz	x23, 0x100847d34 <_js_json_stringify_full+0x13b4>
100848450:     	b	0x100848530 <_js_json_stringify_full+0x1bb0>
100848454:     	bl	0x100b1fae4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100848458:     	cbnz	x0, 0x100847678 <_js_json_stringify_full+0xcf8>
10084845c:     	b	0x100848590 <_js_json_stringify_full+0x1c10>
100848460:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100848464:     	add	x0, x0, #0x440
100848468:     	bl	0x100b13b2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084846c:     	cmp	w8, #0x1
100848470:     	b.ne	0x100848590 <_js_json_stringify_full+0x1c10>
100848474:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100848478:     	add	x1, x1, #0x998
10084847c:     	mov	x19, x0
100848480:     	bl	0x100a2185c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100848484:     	mov	x0, x19
100848488:     	strb	wzr, [x19, #0x20]
10084848c:     	ldr	x8, [x19]
100848490:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100848494:     	cmp	x8, x9
100848498:     	b.lo	0x100847898 <_js_json_stringify_full+0xf18>
10084849c:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008484a0:     	add	x0, x0, #0xea8
1008484a4:     	bl	0x100b13b5c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1008484a8:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008484ac:     	add	x0, x0, #0xec0
1008484b0:     	bl	0x100b13b2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008484b4:     	and	x0, x19, #0xffffffffffff
1008484b8:     	bl	0x1004f0680 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
1008484bc:     	mov	x20, x1
1008484c0:     	tbz	w0, #0x0, 0x100846f58 <_js_json_stringify_full+0x5d8>
1008484c4:     	b	0x100847e28 <_js_json_stringify_full+0x14a8>
1008484c8:     	mov	x0, x23
1008484cc:     	bl	0x100b1f984 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008484d0:     	mov	x23, x0
1008484d4:     	cbnz	x0, 0x100847be4 <_js_json_stringify_full+0x1264>
1008484d8:     	b	0x100848530 <_js_json_stringify_full+0x1bb0>
1008484dc:     	adrp	x0, 0x100ef7000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
1008484e0:     	add	x0, x0, #0xd70
1008484e4:     	bl	0x100b13b5c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
1008484e8:     	bl	0x100b4cd94 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
1008484ec:     	cmp	w8, #0x2
1008484f0:     	b.eq	0x100848590 <_js_json_stringify_full+0x1c10>
1008484f4:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008484f8:     	add	x1, x1, #0x998
1008484fc:     	mov	x19, x0
100848500:     	bl	0x100a2185c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100848504:     	mov	x0, x19
100848508:     	strb	wzr, [x19, #0x20]
10084850c:     	ldr	x8, [x19]
100848510:     	cbz	x8, 0x100847bd0 <_js_json_stringify_full+0x1250>
100848514:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100848518:     	add	x0, x0, #0xe90
10084851c:     	bl	0x100b13b2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100848520:     	mov	x0, x23
100848524:     	bl	0x100b1f984 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100848528:     	mov	x23, x0
10084852c:     	cbnz	x0, 0x100847b00 <_js_json_stringify_full+0x1180>
100848530:     	cbz	x22, 0x100848590 <_js_json_stringify_full+0x1c10>
100848534:     	mov	x0, x19
100848538:     	bl	0x100b60400 <_mi_free>
10084853c:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100848540:     	add	x0, x0, #0xc18
100848544:     	bl	0x100b59a5c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100848548:     	adrp	x0, 0x100c43000 <_PERRY_EMPTY_STRING+0x634>
10084854c:     	add	x0, x0, #0x8f0
100848550:     	mov	w1, #0xf                ; =15
100848554:     	bl	0x100b4cd5c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100848558:     	and	x0, x19, #0xffffffffffff
10084855c:     	add	x2, sp, #0x80
100848560:     	mov	x1, x22
100848564:     	bl	0x1004f0e80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
100848568:     	tbnz	w0, #0x0, 0x100847f94 <_js_json_stringify_full+0x1614>
10084856c:     	mov	w20, #0x2               ; =2
100848570:     	and	x0, x19, #0xffffffffffff
100848574:     	mov	x1, x20
100848578:     	bl	0x1004ef500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
10084857c:     	mov	x20, x1
100848580:     	tbz	w0, #0x0, 0x100846f58 <_js_json_stringify_full+0x5d8>
100848584:     	b	0x100847e28 <_js_json_stringify_full+0x14a8>
100848588:     	cmp	w8, #0x2
10084858c:     	b.ne	0x1008485b8 <_js_json_stringify_full+0x1c38>
100848590:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100848594:     	add	x0, x0, #0xc18
100848598:     	bl	0x100b59a5c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
10084859c:     	adrp	x0, 0x100f2f000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x190>
1008485a0:     	add	x0, x0, #0x848
1008485a4:     	bl	0x100b13bf0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
1008485a8:     	adrp	x0, 0x100c43000 <_PERRY_EMPTY_STRING+0x634>
1008485ac:     	add	x0, x0, #0x627
1008485b0:     	mov	w1, #0xb                ; =11
1008485b4:     	bl	0x100b4cd5c <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
1008485b8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008485bc:     	add	x1, x1, #0x998
1008485c0:     	mov	x19, x0
1008485c4:     	bl	0x100a2185c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008485c8:     	mov	x0, x19
1008485cc:     	strb	wzr, [x19, #0x20]
1008485d0:     	ldr	x8, [x19]
1008485d4:     	cbz	x8, 0x100847aec <_js_json_stringify_full+0x116c>
1008485d8:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008485dc:     	add	x0, x0, #0xe78
1008485e0:     	bl	0x100b13b2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008485e4:     	mov	w0, #0x1                ; =1
1008485e8:     	mov	x1, x24
1008485ec:     	bl	0x100b13780 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008485f0:     	mov	w0, #0x1                ; =1
1008485f4:     	mov	x1, x22
1008485f8:     	bl	0x100b13780 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
1008485fc:     	adrp	x2, 0x100ef8000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100848600:     	add	x2, x2, #0x3c8
100848604:     	mov	w0, #0x5                ; =5
100848608:     	mov	w1, #0x5                ; =5
10084860c:     	bl	0x100b13c8c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
