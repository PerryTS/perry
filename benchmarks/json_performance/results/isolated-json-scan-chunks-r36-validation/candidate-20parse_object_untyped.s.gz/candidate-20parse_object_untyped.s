
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/isolated-json-scan-chunks-r36/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100243e38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped>:
100243e38:     	stp	d15, d14, [sp, #-0xa0]!
100243e3c:     	stp	d13, d12, [sp, #0x10]
100243e40:     	stp	d11, d10, [sp, #0x20]
100243e44:     	stp	d9, d8, [sp, #0x30]
100243e48:     	stp	x28, x27, [sp, #0x40]
100243e4c:     	stp	x26, x25, [sp, #0x50]
100243e50:     	stp	x24, x23, [sp, #0x60]
100243e54:     	stp	x22, x21, [sp, #0x70]
100243e58:     	stp	x20, x19, [sp, #0x80]
100243e5c:     	stp	x29, x30, [sp, #0x90]
100243e60:     	add	x29, sp, #0x90
100243e64:     	sub	sp, sp, #0x2e0
100243e68:     	mov	x19, x0
100243e6c:     	ldp	x8, x9, [x0, #0x68]
100243e70:     	add	x9, x9, #0x1
100243e74:     	str	x9, [x0, #0x70]
100243e78:     	cmp	x9, x8
100243e7c:     	b.hs	0x100243eb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x78>
100243e80:     	ldr	x10, [x19, #0x60]
100243e84:     	mov	x11, #0x2600            ; =9728
100243e88:     	movk	x11, #0x1, lsl #32
100243e8c:     	ldrb	w12, [x10, x9]
100243e90:     	cmp	w12, #0x20
100243e94:     	b.hi	0x100243eb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x78>
100243e98:     	lsr	x12, x11, x12
100243e9c:     	tbz	w12, #0x0, 0x100243eb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x78>
100243ea0:     	add	x9, x9, #0x1
100243ea4:     	str	x9, [x19, #0x70]
100243ea8:     	cmp	x8, x9
100243eac:     	b.ne	0x100243e8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x54>
100243eb0:     	ldrb	w8, [x19, #0xd5]
100243eb4:     	tbz	w8, #0x0, 0x100243ee0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa8>
100243eb8:     	strb	wzr, [x19, #0xd5]
100243ebc:     	ldr	x28, [x19, #0x78]
100243ec0:     	ldp	q0, q1, [x19, #0x80]
100243ec4:     	stur	q0, [sp, #0xa8]
100243ec8:     	stur	q1, [sp, #0xb8]
100243ecc:     	ldp	q0, q1, [x19, #0xa0]
100243ed0:     	stur	q0, [sp, #0xc8]
100243ed4:     	stur	q1, [sp, #0xd8]
100243ed8:     	ldr	x21, [x19, #0xc0]
100243edc:     	b	0x100243f10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd8>
100243ee0:     	str	wzr, [sp, #0x9c]
100243ee4:     	mov	x8, #0x0                ; =0
100243ee8:     	ldr	x28, [x19, #0x78]
100243eec:     	cbz	x28, 0x100245ab4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c7c>
100243ef0:     	ldr	x21, [x19, #0xc0]
100243ef4:     	cbz	x21, 0x100243f2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf4>
100243ef8:     	ldp	q0, q1, [x19, #0x80]
100243efc:     	stur	q0, [sp, #0xa8]
100243f00:     	stur	q1, [sp, #0xb8]
100243f04:     	ldp	q0, q1, [x19, #0xa0]
100243f08:     	stur	q0, [sp, #0xc8]
100243f0c:     	stur	q1, [sp, #0xd8]
100243f10:     	ldr	w8, [x19, #0xd0]
100243f14:     	stp	x28, x21, [sp, #0xe8]
100243f18:     	str	w8, [sp, #0x64]
100243f1c:     	str	w8, [sp, #0xf8]
100243f20:     	mov	w8, #0x1                ; =1
100243f24:     	mov	w9, #0x1                ; =1
100243f28:     	str	w9, [sp, #0x9c]
100243f2c:     	str	x8, [sp, #0xa0]
100243f30:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100243f34:     	add	x0, x0, #0xce8
100243f38:     	ldr	x8, [x0]
100243f3c:     	blr	x8
100243f40:     	mov	x20, x0
100243f44:     	ldrb	w8, [x0, #0x20]
100243f48:     	cbnz	w8, 0x100245d70 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1f38>
100243f4c:     	ldr	x8, [x20]
100243f50:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100243f54:     	cmp	x8, x9
100243f58:     	b.hs	0x100245d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1f64>
100243f5c:     	ldr	x27, [x20, #0x18]
100243f60:     	ldp	x23, x24, [x19, #0x68]
100243f64:     	cmp	x24, x23
100243f68:     	b.hs	0x100243f9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x164>
100243f6c:     	ldr	x8, [x19, #0x60]
100243f70:     	ldrb	w8, [x8, x24]
100243f74:     	cmp	w8, #0x7d
100243f78:     	b.ne	0x100243f9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x164>
100243f7c:     	add	x8, x24, #0x1
100243f80:     	str	x8, [x19, #0x70]
100243f84:     	ldr	x8, [x19, #0x78]
100243f88:     	cbnz	x8, 0x100245ab8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c80>
100243f8c:     	ldr	x1, [x19, #0xc0]
100243f90:     	cbz	x1, 0x100245ab8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c80>
100243f94:     	ldr	w2, [x19, #0xd0]
100243f98:     	b	0x100245ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ca0>
100243f9c:     	str	x27, [sp, #0x88]
100243fa0:     	movi.2d	v0, #0000000000000000
100243fa4:     	stp	q0, q0, [sp, #0x120]
100243fa8:     	stp	q0, q0, [sp, #0x100]
100243fac:     	adrp	x1, 0x100c9a000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6bb0>
100243fb0:     	add	x1, x1, #0xf30
100243fb4:     	add	x0, sp, #0x148
100243fb8:     	mov	w2, #0x40               ; =64
100243fbc:     	bl	0x100b61110 <_writev+0x100b61110>
100243fc0:     	mov	x14, #0x0               ; =0
100243fc4:     	mov	x22, #0x0               ; =0
100243fc8:     	mov	x8, #-0x1               ; =-1
100243fcc:     	str	x8, [sp, #0x188]
100243fd0:     	add	x8, sp, #0xa0
100243fd4:     	add	x8, x8, #0x8
100243fd8:     	stp	x8, xzr, [sp, #0x68]
100243fdc:     	adrp	x8, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4bb0>
100243fe0:     	ldr	q0, [x8, #0xce0]
100243fe4:     	str	q0, [sp, #0x40]
100243fe8:     	adrp	x8, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4bb0>
100243fec:     	ldr	q0, [x8, #0xcf0]
100243ff0:     	str	q0, [sp, #0x30]
100243ff4:     	mov	x25, #0x2600            ; =9728
100243ff8:     	movk	x25, #0x1, lsl #32
100243ffc:     	adrp	x8, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4bb0>
100244000:     	ldr	q0, [x8, #0xcd0]
100244004:     	str	q0, [sp, #0x50]
100244008:     	movi.8b	v8, #0xf0
10024400c:     	movi.8b	v9, #0xc0
100244010:     	mvni.4h	v10, #0x40
100244014:     	movi.4h	v11, #0xef
100244018:     	ldr	w8, [sp, #0x9c]
10024401c:     	mov	x27, x8
100244020:     	str	w8, [sp, #0x80]
100244024:     	str	x28, [sp, #0x90]
100244028:     	cmp	x24, x23
10024402c:     	b.hs	0x10024405c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x224>
100244030:     	ldr	x8, [x19, #0x60]
100244034:     	ldrb	w9, [x8, x24]
100244038:     	cmp	w9, #0x20
10024403c:     	b.hi	0x10024405c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x224>
100244040:     	lsr	x9, x25, x9
100244044:     	tbz	w9, #0x0, 0x10024405c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x224>
100244048:     	add	x24, x24, #0x1
10024404c:     	str	x24, [x19, #0x70]
100244050:     	cmp	x23, x24
100244054:     	b.ne	0x100244034 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1fc>
100244058:     	mov	x24, x23
10024405c:     	ldr	w8, [sp, #0x9c]
100244060:     	str	w27, [sp, #0x78]
100244064:     	cbz	w8, 0x100244120 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100244068:     	cmp	x14, x28
10024406c:     	cset	w8, lo
100244070:     	tst	w27, w8
100244074:     	b.eq	0x100244120 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100244078:     	cmp	x14, #0x8
10024407c:     	b.hs	0x100245e48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2010>
100244080:     	cmp	x24, x23
100244084:     	b.hs	0x100244120 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100244088:     	ldr	x8, [sp, #0x68]
10024408c:     	ldr	x9, [x8, x14, lsl #3]
100244090:     	cbz	x9, 0x100244120 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100244094:     	ldr	x10, [x19, #0x60]
100244098:     	ldrb	w8, [x10, x24]
10024409c:     	cmp	w8, #0x22
1002440a0:     	b.ne	0x100244120 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
1002440a4:     	add	x11, x24, #0x1
1002440a8:     	ldr	w15, [x9, #0x4]
1002440ac:     	add	x8, x11, x15
1002440b0:     	cmp	x8, x23
1002440b4:     	ccmp	x8, x24, #0x0, lo
1002440b8:     	b.ls	0x100244120 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
1002440bc:     	ldrb	w12, [x10, x8]
1002440c0:     	cmp	w12, #0x22
1002440c4:     	b.ne	0x100244120 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
1002440c8:     	add	x24, x10, x11
1002440cc:     	cbz	w15, 0x100244108 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2d0>
1002440d0:     	add	x9, x9, #0x14
1002440d4:     	mov	x10, x15
1002440d8:     	mov	x11, x24
1002440dc:     	ldrb	w12, [x11], #0x1
1002440e0:     	cmp	w12, #0x5c
1002440e4:     	b.eq	0x100244120 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
1002440e8:     	cmp	w12, #0x22
1002440ec:     	b.eq	0x100244120 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
1002440f0:     	ldrb	w13, [x9], #0x1
1002440f4:     	cmp	w12, #0x20
1002440f8:     	ccmp	w12, w13, #0x0, hs
1002440fc:     	b.ne	0x100244120 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2e8>
100244100:     	subs	x10, x10, #0x1
100244104:     	b.ne	0x1002440dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2a4>
100244108:     	mov	x27, x14
10024410c:     	add	x8, x8, #0x1
100244110:     	str	x8, [x19, #0x70]
100244114:     	mov	w23, #0x1               ; =1
100244118:     	mov	x28, #-0x1              ; =-1
10024411c:     	b	0x100244144 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x30c>
100244120:     	mov	x27, x14
100244124:     	sub	x0, x29, #0x100
100244128:     	mov	x1, x19
10024412c:     	bl	0x1002434f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
100244130:     	ldur	x28, [x29, #-0x100]
100244134:     	cmn	x28, #0x2
100244138:     	b.eq	0x1002458fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ac4>
10024413c:     	mov	w23, #0x0               ; =0
100244140:     	ldp	x24, x15, [x29, #-0xf8]
100244144:     	ldp	x9, x8, [x19, #0x68]
100244148:     	cmp	x8, x9
10024414c:     	b.hs	0x1002458e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ab0>
100244150:     	ldr	x10, [x19, #0x60]
100244154:     	ldrb	w11, [x10, x8]
100244158:     	cmp	w11, #0x3a
10024415c:     	b.hi	0x1002458e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ab0>
100244160:     	lsr	x12, x25, x11
100244164:     	tbz	w12, #0x0, 0x10024417c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x344>
100244168:     	add	x8, x8, #0x1
10024416c:     	str	x8, [x19, #0x70]
100244170:     	cmp	x9, x8
100244174:     	b.ne	0x100244154 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x31c>
100244178:     	b	0x1002458e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ab0>
10024417c:     	cmp	x11, #0x3a
100244180:     	b.ne	0x1002458e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ab0>
100244184:     	str	x15, [sp, #0x28]
100244188:     	add	x8, x8, #0x1
10024418c:     	str	x8, [x19, #0x70]
100244190:     	mov	x0, x19
100244194:     	bl	0x100242448 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser11parse_value>
100244198:     	str	x0, [sp, #0x10]
10024419c:     	ldrb	w8, [x19, #0xd4]
1002441a0:     	tbz	w8, #0x0, 0x1002458ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ab4>
1002441a4:     	ldr	x8, [sp, #0x188]
1002441a8:     	cmn	x8, #0x1
1002441ac:     	str	x24, [sp, #0x18]
1002441b0:     	b.eq	0x100244274 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x43c>
1002441b4:     	ldr	x8, [sp, #0x1b8]
1002441b8:     	ldr	x1, [sp, #0x198]
1002441bc:     	cmn	x8, #0x1
1002441c0:     	ldr	x2, [sp, #0x28]
1002441c4:     	str	x22, [sp]
1002441c8:     	b.eq	0x1002442bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x484>
1002441cc:     	mov	x26, #0x7f2d            ; =32557
1002441d0:     	movk	x26, #0x4c95, lsl #16
1002441d4:     	movk	x26, #0xf42d, lsl #32
1002441d8:     	movk	x26, #0x5851, lsl #48
1002441dc:     	ldp	x8, x11, [sp, #0x1f0]
1002441e0:     	ldr	x10, [sp, #0x200]
1002441e4:     	ldr	x9, [sp, #0x208]
1002441e8:     	eor	x11, x11, x2
1002441ec:     	mul	x12, x11, x26
1002441f0:     	umulh	x11, x11, x26
1002441f4:     	eor	x11, x11, x12
1002441f8:     	add	x11, x2, x11
1002441fc:     	mul	x11, x11, x26
100244200:     	cmp	x2, #0x8
100244204:     	b.ls	0x1002444ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6b4>
100244208:     	cmp	x2, #0x10
10024420c:     	b.ls	0x1002445d8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7a0>
100244210:     	add	x12, x24, x2
100244214:     	ldp	x12, x13, [x12, #-0x10]
100244218:     	eor	x12, x10, x12
10024421c:     	eor	x13, x13, x9
100244220:     	mul	x14, x13, x12
100244224:     	umulh	x12, x13, x12
100244228:     	eor	x12, x12, x14
10024422c:     	add	x11, x11, x8
100244230:     	eor	x11, x11, x12
100244234:     	ror	x11, x11, #0x29
100244238:     	mov	x13, x24
10024423c:     	mov	x12, x2
100244240:     	ldp	x15, x14, [x13], #0x10
100244244:     	sub	x12, x12, #0x10
100244248:     	eor	x15, x10, x15
10024424c:     	eor	x14, x14, x9
100244250:     	mul	x16, x14, x15
100244254:     	umulh	x14, x14, x15
100244258:     	eor	x14, x14, x16
10024425c:     	add	x11, x11, x8
100244260:     	eor	x11, x11, x14
100244264:     	ror	x11, x11, #0x29
100244268:     	cmp	x12, #0x10
10024426c:     	b.hi	0x100244240 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x408>
100244270:     	b	0x10024462c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7f4>
100244274:     	ldr	w8, [sp, #0x80]
100244278:     	ldr	x1, [sp, #0x28]
10024427c:     	tbz	w8, #0x0, 0x10024450c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6d4>
100244280:     	ldr	w8, [sp, #0x9c]
100244284:     	tbz	w8, #0x0, 0x100245e3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2004>
100244288:     	mov	x14, x27
10024428c:     	ldr	x8, [sp, #0x90]
100244290:     	cmp	x27, x8
100244294:     	ldr	w27, [sp, #0x78]
100244298:     	b.hs	0x1002449f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbc0>
10024429c:     	tbz	w23, #0x0, 0x1002449bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb84>
1002442a0:     	cmp	x14, #0x7
1002442a4:     	b.hi	0x100245ea8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2070>
1002442a8:     	ldr	x8, [sp, #0x68]
1002442ac:     	ldr	x10, [x8, x14, lsl #3]
1002442b0:     	add	x14, x14, #0x1
1002442b4:     	mov	w8, #0x1                ; =1
1002442b8:     	b	0x100244a14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbdc>
1002442bc:     	ldr	x23, [sp, #0x190]
1002442c0:     	cmp	x1, #0x80
1002442c4:     	mov	x26, #0x7f2d            ; =32557
1002442c8:     	movk	x26, #0x4c95, lsl #16
1002442cc:     	movk	x26, #0xf42d, lsl #32
1002442d0:     	movk	x26, #0x5851, lsl #48
1002442d4:     	b.ne	0x100244528 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6f0>
1002442d8:     	mov	w8, #0x1                ; =1
1002442dc:     	strb	w8, [x19, #0xd6]
1002442e0:     	adrp	x8, 0x10104d000 <_out_buf+0x3a48>
1002442e4:     	add	x8, x8, #0x780
1002442e8:     	ldapr	x8, [x8]
1002442ec:     	cbz	x8, 0x10024589c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a64>
1002442f0:     	ldp	x0, x22, [x8]
1002442f4:     	adrp	x8, 0x10104d000 <_out_buf+0x3a48>
1002442f8:     	add	x8, x8, #0x788
1002442fc:     	ldapr	x24, [x8]
100244300:     	cbz	x24, 0x1002458bc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a84>
100244304:     	ldr	x8, [x22, #0x18]
100244308:     	blr	x8
10024430c:     	mov	x2, x0
100244310:     	sub	x8, x29, #0x100
100244314:     	add	x8, x8, #0x38
100244318:     	add	x1, x24, #0x20
10024431c:     	mov	x0, x24
100244320:     	bl	0x100006d70 <__RNvMs1_NtCs3SoQS4yp3pP_5ahash12random_stateNtB5_11RandomState9from_keys>
100244324:     	mov	w0, #0x1108             ; =4360
100244328:     	mov	w1, #0x8                ; =8
10024432c:     	bl	0x100b5e4c8 <_mi_malloc_aligned>
100244330:     	cbz	x0, 0x100245e7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2044>
100244334:     	mov	x24, #0x0               ; =0
100244338:     	mov	x2, #0x0                ; =0
10024433c:     	movi.2d	v0, #0xffffffffffffffff
100244340:     	str	q0, [x0, #0x10f0]
100244344:     	str	q0, [x0, #0x10e0]
100244348:     	str	q0, [x0, #0x10d0]
10024434c:     	str	q0, [x0, #0x10c0]
100244350:     	str	q0, [x0, #0x10b0]
100244354:     	str	q0, [x0, #0x10a0]
100244358:     	str	q0, [x0, #0x1090]
10024435c:     	str	q0, [x0, #0x1080]
100244360:     	str	q0, [x0, #0x1070]
100244364:     	str	q0, [x0, #0x1060]
100244368:     	str	q0, [x0, #0x1050]
10024436c:     	str	q0, [x0, #0x1040]
100244370:     	str	q0, [x0, #0x1030]
100244374:     	str	q0, [x0, #0x1020]
100244378:     	str	q0, [x0, #0x1010]
10024437c:     	str	q0, [x0, #0x1000]
100244380:     	str	d0, [x0, #0x1100]
100244384:     	add	x8, x0, #0x1, lsl #12   ; =0x1000
100244388:     	stur	xzr, [x29, #-0xd0]
10024438c:     	ldr	q0, [sp, #0x50]
100244390:     	stur	q0, [x29, #-0xe0]
100244394:     	mov	w9, #0x8                ; =8
100244398:     	stp	xzr, x9, [x29, #-0x100]
10024439c:     	stp	xzr, x8, [x29, #-0xf0]
1002443a0:     	b	0x1002443fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x5c4>
1002443a4:     	ldr	w11, [x11]
1002443a8:     	ldur	w12, [x14, #-0x4]
1002443ac:     	eor	x10, x11, x10
1002443b0:     	eor	x9, x12, x9
1002443b4:     	mul	x11, x9, x10
1002443b8:     	umulh	x9, x9, x10
1002443bc:     	eor	x9, x9, x11
1002443c0:     	add	x10, x13, x8
1002443c4:     	eor	x9, x10, x9
1002443c8:     	ror	x13, x9, #0x29
1002443cc:     	add	x24, x24, #0x8
1002443d0:     	add	x22, x2, #0x1
1002443d4:     	mul	x9, x13, x8
1002443d8:     	umulh	x8, x13, x8
1002443dc:     	eor	x8, x8, x9
1002443e0:     	neg	w9, w13
1002443e4:     	ror	x1, x8, x9
1002443e8:     	sub	x0, x29, #0x100
1002443ec:     	bl	0x10028754c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
1002443f0:     	mov	x2, x22
1002443f4:     	cmp	x24, #0x400
1002443f8:     	b.eq	0x100244530 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6f8>
1002443fc:     	ldr	x8, [x23, x24]
100244400:     	add	x11, x8, #0x14
100244404:     	ldr	w12, [x8, #0x4]
100244408:     	ldp	x8, x13, [x29, #-0xc8]
10024440c:     	ldp	x10, x9, [x29, #-0xb8]
100244410:     	eor	x13, x13, x12
100244414:     	mul	x14, x13, x26
100244418:     	umulh	x13, x13, x26
10024441c:     	eor	x13, x13, x14
100244420:     	add	x13, x13, x12
100244424:     	mul	x13, x13, x26
100244428:     	cmp	w12, #0x8
10024442c:     	b.ls	0x100244494 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x65c>
100244430:     	cmp	w12, #0x10
100244434:     	b.ls	0x1002444b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x67c>
100244438:     	add	x14, x11, x12
10024443c:     	ldp	x14, x15, [x14, #-0x10]
100244440:     	eor	x14, x10, x14
100244444:     	eor	x15, x15, x9
100244448:     	mul	x16, x15, x14
10024444c:     	umulh	x14, x15, x14
100244450:     	eor	x14, x14, x16
100244454:     	add	x13, x13, x8
100244458:     	eor	x13, x13, x14
10024445c:     	ror	x13, x13, #0x29
100244460:     	ldp	x15, x14, [x11], #0x10
100244464:     	sub	x12, x12, #0x10
100244468:     	eor	x15, x10, x15
10024446c:     	eor	x14, x14, x9
100244470:     	mul	x16, x14, x15
100244474:     	umulh	x14, x14, x15
100244478:     	eor	x14, x14, x16
10024447c:     	add	x13, x13, x8
100244480:     	eor	x13, x13, x14
100244484:     	ror	x13, x13, #0x29
100244488:     	cmp	x12, #0x10
10024448c:     	b.hi	0x100244460 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x628>
100244490:     	b	0x1002443cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x594>
100244494:     	cmp	w12, #0x1
100244498:     	b.ls	0x1002444cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x694>
10024449c:     	add	x14, x11, x12
1002444a0:     	cmp	w12, #0x3
1002444a4:     	b.hi	0x1002443a4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x56c>
1002444a8:     	ldrh	w11, [x11]
1002444ac:     	ldurb	w12, [x14, #-0x1]
1002444b0:     	b	0x1002443ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x574>
1002444b4:     	ldr	x14, [x11]
1002444b8:     	add	x11, x11, x12
1002444bc:     	ldur	x11, [x11, #-0x8]
1002444c0:     	eor	x10, x14, x10
1002444c4:     	eor	x9, x11, x9
1002444c8:     	b	0x1002443b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x57c>
1002444cc:     	cmp	w12, #0x1
1002444d0:     	b.ne	0x1002444e0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x6a8>
1002444d4:     	ldrb	w11, [x11]
1002444d8:     	mov	x12, x11
1002444dc:     	b	0x1002443ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x574>
1002444e0:     	mov	x11, #0x0               ; =0
1002444e4:     	mov	x12, #0x0               ; =0
1002444e8:     	b	0x1002443ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x574>
1002444ec:     	cmp	x2, #0x1
1002444f0:     	b.ls	0x1002445e8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7b0>
1002444f4:     	add	x13, x24, x2
1002444f8:     	cmp	x2, #0x3
1002444fc:     	b.ls	0x1002445f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7c0>
100244500:     	ldr	w12, [x24]
100244504:     	ldur	w13, [x13, #-0x4]
100244508:     	b	0x10024460c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7d4>
10024450c:     	mov	x0, x24
100244510:     	bl	0x100326a7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100244514:     	mov	x10, x0
100244518:     	mov	w8, #0x0                ; =0
10024451c:     	mov	x14, x27
100244520:     	ldr	w27, [sp, #0x78]
100244524:     	b	0x100244a14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbdc>
100244528:     	str	x1, [sp, #0x20]
10024452c:     	b	0x100244dd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfa0>
100244530:     	ldur	q2, [x29, #-0xc0]
100244534:     	ldur	x8, [x29, #-0xb0]
100244538:     	str	x8, [sp, #0x260]
10024453c:     	ldp	q0, q1, [x29, #-0x100]
100244540:     	stp	q0, q1, [sp, #0x210]
100244544:     	ldp	q0, q1, [x29, #-0xe0]
100244548:     	str	q0, [sp, #0x230]
10024454c:     	stp	q1, q2, [sp, #0x240]
100244550:     	ldr	x22, [sp, #0x1b8]
100244554:     	cmn	x22, #0x1
100244558:     	ldr	x24, [sp, #0x18]
10024455c:     	ldr	x2, [sp, #0x28]
100244560:     	b.eq	0x1002445a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x768>
100244564:     	ldr	x9, [sp, #0x1d8]
100244568:     	cbz	x9, 0x100244590 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x758>
10024456c:     	lsl	x8, x9, #4
100244570:     	add	x9, x8, x9
100244574:     	cmn	x9, #0x19
100244578:     	b.eq	0x100244590 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x758>
10024457c:     	ldr	x9, [sp, #0x1d0]
100244580:     	sub	x8, x9, x8
100244584:     	sub	x0, x8, #0x10
100244588:     	bl	0x100b5e240 <_mi_free>
10024458c:     	ldr	x2, [sp, #0x28]
100244590:     	cbz	x22, 0x1002445a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x768>
100244594:     	ldr	x0, [sp, #0x1c0]
100244598:     	bl	0x100b5e240 <_mi_free>
10024459c:     	ldr	x2, [sp, #0x28]
1002445a0:     	ldr	x8, [sp, #0x260]
1002445a4:     	add	x9, sp, #0x188
1002445a8:     	stur	x8, [x9, #0x80]
1002445ac:     	ldr	q2, [sp, #0x250]
1002445b0:     	ldp	q0, q1, [sp, #0x210]
1002445b4:     	stp	q0, q1, [x9, #0x30]
1002445b8:     	ldp	q0, q1, [sp, #0x230]
1002445bc:     	stur	q0, [x9, #0x50]
1002445c0:     	stp	q1, q2, [x9, #0x60]
1002445c4:     	ldr	x8, [sp, #0x1b8]
1002445c8:     	cmn	x8, #0x1
1002445cc:     	b.eq	0x100244dd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf98>
1002445d0:     	ldr	x1, [sp, #0x198]
1002445d4:     	b	0x1002441dc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x3a4>
1002445d8:     	ldr	x12, [x24]
1002445dc:     	add	x13, x24, x2
1002445e0:     	ldur	x13, [x13, #-0x8]
1002445e4:     	b	0x10024460c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7d4>
1002445e8:     	b.ne	0x100244604 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7cc>
1002445ec:     	ldrb	w12, [x24]
1002445f0:     	mov	x13, x12
1002445f4:     	b	0x10024460c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7d4>
1002445f8:     	ldrh	w12, [x24]
1002445fc:     	ldurb	w13, [x13, #-0x1]
100244600:     	b	0x10024460c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x7d4>
100244604:     	mov	x12, #0x0               ; =0
100244608:     	mov	x13, #0x0               ; =0
10024460c:     	eor	x10, x12, x10
100244610:     	eor	x9, x13, x9
100244614:     	mul	x12, x9, x10
100244618:     	umulh	x9, x9, x10
10024461c:     	eor	x9, x9, x12
100244620:     	add	x10, x11, x8
100244624:     	eor	x9, x10, x9
100244628:     	ror	x11, x9, #0x29
10024462c:     	mul	x9, x11, x8
100244630:     	umulh	x8, x11, x8
100244634:     	eor	x8, x8, x9
100244638:     	neg	w9, w11
10024463c:     	ror	x15, x8, x9
100244640:     	ldr	x8, [sp, #0x1e8]
100244644:     	mov	x14, x27
100244648:     	str	x1, [sp, #0x20]
10024464c:     	str	x15, [sp, #0x8]
100244650:     	cbz	x8, 0x1002447c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x98c>
100244654:     	mov	x8, #0x0                ; =0
100244658:     	mov	x9, #0x7c15             ; =31765
10024465c:     	movk	x9, #0x7f4a, lsl #16
100244660:     	movk	x9, #0x79b9, lsl #32
100244664:     	movk	x9, #0x9e37, lsl #48
100244668:     	mul	x9, x15, x9
10024466c:     	eor	x11, x9, x9, lsr #32
100244670:     	lsr	x12, x9, #57
100244674:     	ldp	x10, x9, [sp, #0x1d0]
100244678:     	ldr	x23, [sp, #0x190]
10024467c:     	dup.8b	v0, w12
100244680:     	and	x11, x11, x9
100244684:     	ldr	d1, [x10, x11]
100244688:     	cmeq.8b	v2, v1, v0
10024468c:     	fmov	x12, d2
100244690:     	ands	x12, x12, #0x8080808080808080
100244694:     	b.eq	0x1002446cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x894>
100244698:     	mov	x27, x14
10024469c:     	rbit	x13, x12
1002446a0:     	clz	x13, x13
1002446a4:     	add	x13, x11, x13, lsr #3
1002446a8:     	and	x13, x13, x9
1002446ac:     	sub	x13, x10, x13, lsl #4
1002446b0:     	ldur	x14, [x13, #-0x10]
1002446b4:     	cmp	x15, x14
1002446b8:     	b.eq	0x100244700 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x8c8>
1002446bc:     	sub	x13, x12, #0x2
1002446c0:     	ands	x12, x13, x12
1002446c4:     	mov	x14, x27
1002446c8:     	b.ne	0x100244698 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x860>
1002446cc:     	movi.2d	v2, #0xffffffffffffffff
1002446d0:     	cmeq.8b	v1, v1, v2
1002446d4:     	fmov	x12, d1
1002446d8:     	cbnz	x12, 0x1002447c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x98c>
1002446dc:     	add	x8, x8, #0x8
1002446e0:     	add	x11, x11, x8
1002446e4:     	and	x11, x11, x9
1002446e8:     	ldr	d1, [x10, x11]
1002446ec:     	cmeq.8b	v2, v1, v0
1002446f0:     	fmov	x12, d2
1002446f4:     	ands	x12, x12, #0x8080808080808080
1002446f8:     	b.ne	0x100244698 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x860>
1002446fc:     	b	0x1002446cc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x894>
100244700:     	ldur	x24, [x13, #-0x8]
100244704:     	cmp	x24, x1
100244708:     	b.hs	0x100245e6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2034>
10024470c:     	mov	x14, x27
100244710:     	ldr	x8, [x23, x24, lsl #3]
100244714:     	ldr	w9, [x8, #0x4]
100244718:     	cmp	x2, x9
10024471c:     	b.ne	0x100244740 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x908>
100244720:     	add	x0, x8, #0x14
100244724:     	ldr	x1, [sp, #0x18]
100244728:     	ldr	x2, [sp, #0x28]
10024472c:     	bl	0x100b610e0 <_writev+0x100b610e0>
100244730:     	ldr	x15, [sp, #0x8]
100244734:     	ldp	x1, x2, [sp, #0x20]
100244738:     	mov	x14, x27
10024473c:     	cbz	w0, 0x1002447ac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x974>
100244740:     	ldr	x8, [sp, #0x1c8]
100244744:     	cbz	x8, 0x1002447c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x98c>
100244748:     	ldr	x9, [sp, #0x1c0]
10024474c:     	lsl	x26, x8, #4
100244750:     	add	x22, x9, #0x8
100244754:     	b	0x100244764 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x92c>
100244758:     	add	x22, x22, #0x10
10024475c:     	subs	x26, x26, #0x10
100244760:     	b.eq	0x1002447c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x98c>
100244764:     	ldur	x8, [x22, #-0x8]
100244768:     	cmp	x8, x15
10024476c:     	b.ne	0x100244758 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x920>
100244770:     	ldr	x24, [x22]
100244774:     	cmp	x24, x1
100244778:     	b.hs	0x100245e5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2024>
10024477c:     	ldr	x8, [x23, x24, lsl #3]
100244780:     	ldr	w9, [x8, #0x4]
100244784:     	cmp	x2, x9
100244788:     	b.ne	0x100244758 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x920>
10024478c:     	add	x0, x8, #0x14
100244790:     	ldr	x1, [sp, #0x18]
100244794:     	ldr	x2, [sp, #0x28]
100244798:     	bl	0x100b610e0 <_writev+0x100b610e0>
10024479c:     	ldr	x15, [sp, #0x8]
1002447a0:     	ldp	x1, x2, [sp, #0x20]
1002447a4:     	mov	x14, x27
1002447a8:     	cbnz	w0, 0x100244758 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x920>
1002447ac:     	ldr	x1, [sp, #0x1b0]
1002447b0:     	cmp	x24, x1
1002447b4:     	b.hs	0x100245e98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2060>
1002447b8:     	ldr	x26, [sp, #0x1a8]
1002447bc:     	ldr	x8, [sp, #0x10]
1002447c0:     	b	0x100244e74 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x103c>
1002447c4:     	cmn	x28, #0x1
1002447c8:     	b.eq	0x1002447f0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9b8>
1002447cc:     	mov	x27, x14
1002447d0:     	ldr	x24, [sp, #0x18]
1002447d4:     	mov	x0, x24
1002447d8:     	mov	x1, x2
1002447dc:     	bl	0x10034a030 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
1002447e0:     	ldr	x1, [sp, #0x8]
1002447e4:     	ldr	x2, [sp, #0x20]
1002447e8:     	mov	x26, x0
1002447ec:     	b	0x1002456d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1898>
1002447f0:     	cmp	x2, #0x40
1002447f4:     	b.hs	0x100244904 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xacc>
1002447f8:     	ands	x8, x2, #0x38
1002447fc:     	b.eq	0x100244820 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9e8>
100244800:     	and	x9, x2, #0x38
100244804:     	neg	x9, x9
100244808:     	ldr	x10, [sp, #0x18]
10024480c:     	ldr	x11, [x10], #0x8
100244810:     	tst	x11, #0x8080808080808080
100244814:     	b.ne	0x1002448b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244818:     	adds	x9, x9, #0x8
10024481c:     	b.ne	0x10024480c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x9d4>
100244820:     	mov	x24, x2
100244824:     	and	x9, x2, #0x7
100244828:     	cbz	x9, 0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
10024482c:     	ldr	x10, [sp, #0x18]
100244830:     	add	x8, x10, x8
100244834:     	ldrsb	w10, [x8]
100244838:     	tbnz	w10, #0x1f, 0x1002448b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
10024483c:     	mov	x24, x2
100244840:     	cmp	x9, #0x1
100244844:     	b.eq	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244848:     	ldrsb	w10, [x8, #0x1]
10024484c:     	tbnz	w10, #0x1f, 0x1002448b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244850:     	mov	x24, x2
100244854:     	cmp	x9, #0x2
100244858:     	b.eq	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
10024485c:     	ldrsb	w10, [x8, #0x2]
100244860:     	tbnz	w10, #0x1f, 0x1002448b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244864:     	mov	x24, x2
100244868:     	cmp	x9, #0x3
10024486c:     	b.eq	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244870:     	ldrsb	w10, [x8, #0x3]
100244874:     	tbnz	w10, #0x1f, 0x1002448b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244878:     	mov	x24, x2
10024487c:     	cmp	x9, #0x4
100244880:     	b.eq	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244884:     	ldrsb	w10, [x8, #0x4]
100244888:     	tbnz	w10, #0x1f, 0x1002448b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
10024488c:     	mov	x24, x2
100244890:     	cmp	x9, #0x5
100244894:     	b.eq	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244898:     	ldrsb	w10, [x8, #0x5]
10024489c:     	tbnz	w10, #0x1f, 0x1002448b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
1002448a0:     	mov	x24, x2
1002448a4:     	cmp	x9, #0x6
1002448a8:     	b.eq	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
1002448ac:     	ldrsb	w8, [x8, #0x6]
1002448b0:     	mov	x24, x2
1002448b4:     	tbz	w8, #0x1f, 0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
1002448b8:     	mov	x27, x14
1002448bc:     	cmp	x2, #0x40
1002448c0:     	b.hs	0x100244990 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb58>
1002448c4:     	sub	x8, x29, #0x100
1002448c8:     	ldr	x24, [sp, #0x18]
1002448cc:     	mov	x0, x24
1002448d0:     	mov	x1, x2
1002448d4:     	mov	x22, x2
1002448d8:     	bl	0x10002b898 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
1002448dc:     	ldur	x8, [x29, #-0x100]
1002448e0:     	cbnz	x8, 0x1002449a8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb70>
1002448e4:     	mov	x2, x22
1002448e8:     	cbz	x22, 0x100244f80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1148>
1002448ec:     	cmp	x2, #0x8
1002448f0:     	mov	x14, x27
1002448f4:     	b.hs	0x100244fa4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x116c>
1002448f8:     	mov	x8, #0x0                ; =0
1002448fc:     	mov	w24, #0x0               ; =0
100244900:     	b	0x100245354 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x151c>
100244904:     	and	x8, x2, #0x7fffffffffffffc0
100244908:     	ldr	x10, [sp, #0x18]
10024490c:     	add	x8, x10, x8
100244910:     	mov	x9, x8
100244914:     	ldp	q0, q1, [x10]
100244918:     	ldp	q2, q3, [x10, #0x20]
10024491c:     	orr.16b	v0, v1, v0
100244920:     	orr.16b	v1, v2, v3
100244924:     	orr.16b	v0, v0, v1
100244928:     	umaxv.16b	b0, v0
10024492c:     	fmov	w11, s0
100244930:     	tbnz	w11, #0x7, 0x1002448b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
100244934:     	add	x10, x10, #0x40
100244938:     	cmp	x10, x8
10024493c:     	b.ne	0x100244914 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xadc>
100244940:     	ands	x10, x2, #0x30
100244944:     	mov	x11, x10
100244948:     	b.eq	0x100244964 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb2c>
10024494c:     	ldr	q0, [x9], #0x10
100244950:     	umaxv.16b	b0, v0
100244954:     	fmov	w12, s0
100244958:     	tbnz	w12, #0x7, 0x1002448b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
10024495c:     	subs	x11, x11, #0x10
100244960:     	b.ne	0x10024494c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb14>
100244964:     	mov	x24, x2
100244968:     	and	x9, x2, #0xf
10024496c:     	cbz	x9, 0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244970:     	add	x8, x8, x10
100244974:     	ldrsb	w10, [x8]
100244978:     	tbnz	w10, #0x1f, 0x1002448b8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xa80>
10024497c:     	add	x8, x8, #0x1
100244980:     	subs	x9, x9, #0x1
100244984:     	b.ne	0x100244974 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xb3c>
100244988:     	mov	x24, x2
10024498c:     	b	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244990:     	ldr	x24, [sp, #0x18]
100244994:     	mov	x0, x24
100244998:     	mov	x1, x2
10024499c:     	mov	x22, x2
1002449a0:     	bl	0x1009f49dc <__RNvNtNtCsvoDT44C053_8simdutf814implementation7aarch6424validate_utf8_basic_neon>
1002449a4:     	tbz	w0, #0x0, 0x100244ed4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x109c>
1002449a8:     	mov	x0, x24
1002449ac:     	mov	x1, x22
1002449b0:     	bl	0x10034a030 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
1002449b4:     	mov	x26, x0
1002449b8:     	b	0x1002456c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1890>
1002449bc:     	cmp	x14, #0x8
1002449c0:     	b.hs	0x100245ebc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2084>
1002449c4:     	ldr	x8, [sp, #0x68]
1002449c8:     	ldr	x23, [x8, x14, lsl #3]
1002449cc:     	ldr	w8, [x23, #0x4]
1002449d0:     	cmp	x1, x8
1002449d4:     	b.ne	0x1002449f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xbc0>
1002449d8:     	add	x0, x23, #0x14
1002449dc:     	mov	x1, x24
1002449e0:     	ldr	x2, [sp, #0x28]
1002449e4:     	str	x14, [sp, #0x80]
1002449e8:     	bl	0x100b610e0 <_writev+0x100b610e0>
1002449ec:     	ldr	x1, [sp, #0x28]
1002449f0:     	ldr	x14, [sp, #0x80]
1002449f4:     	cbz	w0, 0x100244f9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1164>
1002449f8:     	mov	x0, x24
1002449fc:     	mov	x23, x14
100244a00:     	bl	0x100326a7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100244a04:     	mov	x14, x23
100244a08:     	mov	x10, x0
100244a0c:     	mov	w27, #0x0               ; =0
100244a10:     	mov	w8, #0x0                ; =0
100244a14:     	cmp	x14, #0x0
100244a18:     	str	w8, [sp, #0x80]
100244a1c:     	csinc	w23, w8, wzr, ne
100244a20:     	cmp	x22, #0x9
100244a24:     	b.hs	0x100245dfc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1fc4>
100244a28:     	ldr	x2, [sp, #0x28]
100244a2c:     	cbz	x22, 0x100244d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244a30:     	ldr	x8, [sp, #0x100]
100244a34:     	cmp	x8, x10
100244a38:     	b.eq	0x100244dbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf84>
100244a3c:     	tbnz	w23, #0x0, 0x100244a78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xc40>
100244a40:     	ldr	w9, [x8, #0x4]
100244a44:     	cmp	x2, x9
100244a48:     	b.ne	0x100244a78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xc40>
100244a4c:     	add	x0, x8, #0x14
100244a50:     	mov	x1, x24
100244a54:     	ldr	x2, [sp, #0x28]
100244a58:     	mov	x24, x14
100244a5c:     	str	x10, [sp, #0x78]
100244a60:     	bl	0x100b610e0 <_writev+0x100b610e0>
100244a64:     	ldr	x10, [sp, #0x78]
100244a68:     	ldr	x2, [sp, #0x28]
100244a6c:     	mov	x14, x24
100244a70:     	ldr	x24, [sp, #0x18]
100244a74:     	cbz	w0, 0x100244dbc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf84>
100244a78:     	cmp	x22, #0x1
100244a7c:     	b.eq	0x100244d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244a80:     	ldr	x9, [sp, #0x108]
100244a84:     	add	x8, sp, #0x148
100244a88:     	add	x8, x8, #0x8
100244a8c:     	cmp	x9, x10
100244a90:     	b.eq	0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244a94:     	tbnz	w23, #0x0, 0x100244ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xca0>
100244a98:     	ldr	w8, [x9, #0x4]
100244a9c:     	cmp	x2, x8
100244aa0:     	b.ne	0x100244ad8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xca0>
100244aa4:     	add	x0, x9, #0x14
100244aa8:     	mov	x1, x24
100244aac:     	ldr	x2, [sp, #0x28]
100244ab0:     	mov	x24, x14
100244ab4:     	str	x10, [sp, #0x78]
100244ab8:     	bl	0x100b610e0 <_writev+0x100b610e0>
100244abc:     	ldr	x10, [sp, #0x78]
100244ac0:     	ldr	x2, [sp, #0x28]
100244ac4:     	mov	x14, x24
100244ac8:     	ldr	x24, [sp, #0x18]
100244acc:     	add	x8, sp, #0x148
100244ad0:     	add	x8, x8, #0x8
100244ad4:     	cbz	w0, 0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244ad8:     	cmp	x22, #0x2
100244adc:     	b.eq	0x100244d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244ae0:     	ldr	x9, [sp, #0x110]
100244ae4:     	add	x8, sp, #0x148
100244ae8:     	add	x8, x8, #0x10
100244aec:     	cmp	x9, x10
100244af0:     	b.eq	0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244af4:     	tbnz	w23, #0x0, 0x100244b38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd00>
100244af8:     	ldr	w8, [x9, #0x4]
100244afc:     	cmp	x2, x8
100244b00:     	b.ne	0x100244b38 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd00>
100244b04:     	add	x0, x9, #0x14
100244b08:     	mov	x1, x24
100244b0c:     	ldr	x2, [sp, #0x28]
100244b10:     	mov	x24, x14
100244b14:     	str	x10, [sp, #0x78]
100244b18:     	bl	0x100b610e0 <_writev+0x100b610e0>
100244b1c:     	ldr	x10, [sp, #0x78]
100244b20:     	ldr	x2, [sp, #0x28]
100244b24:     	mov	x14, x24
100244b28:     	ldr	x24, [sp, #0x18]
100244b2c:     	add	x8, sp, #0x148
100244b30:     	add	x8, x8, #0x10
100244b34:     	cbz	w0, 0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244b38:     	cmp	x22, #0x3
100244b3c:     	b.eq	0x100244d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244b40:     	ldr	x9, [sp, #0x118]
100244b44:     	add	x8, sp, #0x148
100244b48:     	add	x8, x8, #0x18
100244b4c:     	cmp	x9, x10
100244b50:     	b.eq	0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244b54:     	tbnz	w23, #0x0, 0x100244b98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd60>
100244b58:     	ldr	w8, [x9, #0x4]
100244b5c:     	cmp	x2, x8
100244b60:     	b.ne	0x100244b98 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xd60>
100244b64:     	add	x0, x9, #0x14
100244b68:     	mov	x1, x24
100244b6c:     	ldr	x2, [sp, #0x28]
100244b70:     	mov	x24, x14
100244b74:     	str	x10, [sp, #0x78]
100244b78:     	bl	0x100b610e0 <_writev+0x100b610e0>
100244b7c:     	ldr	x10, [sp, #0x78]
100244b80:     	ldr	x2, [sp, #0x28]
100244b84:     	mov	x14, x24
100244b88:     	ldr	x24, [sp, #0x18]
100244b8c:     	add	x8, sp, #0x148
100244b90:     	add	x8, x8, #0x18
100244b94:     	cbz	w0, 0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244b98:     	cmp	x22, #0x4
100244b9c:     	b.eq	0x100244d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244ba0:     	ldr	x9, [sp, #0x120]
100244ba4:     	add	x8, sp, #0x148
100244ba8:     	add	x8, x8, #0x20
100244bac:     	cmp	x9, x10
100244bb0:     	b.eq	0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244bb4:     	tbnz	w23, #0x0, 0x100244bf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdc0>
100244bb8:     	ldr	w8, [x9, #0x4]
100244bbc:     	cmp	x2, x8
100244bc0:     	b.ne	0x100244bf8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xdc0>
100244bc4:     	add	x0, x9, #0x14
100244bc8:     	mov	x1, x24
100244bcc:     	ldr	x2, [sp, #0x28]
100244bd0:     	mov	x24, x14
100244bd4:     	str	x10, [sp, #0x78]
100244bd8:     	bl	0x100b610e0 <_writev+0x100b610e0>
100244bdc:     	ldr	x10, [sp, #0x78]
100244be0:     	ldr	x2, [sp, #0x28]
100244be4:     	mov	x14, x24
100244be8:     	ldr	x24, [sp, #0x18]
100244bec:     	add	x8, sp, #0x148
100244bf0:     	add	x8, x8, #0x20
100244bf4:     	cbz	w0, 0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244bf8:     	cmp	x22, #0x5
100244bfc:     	b.eq	0x100244d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244c00:     	ldr	x9, [sp, #0x128]
100244c04:     	add	x8, sp, #0x148
100244c08:     	add	x8, x8, #0x28
100244c0c:     	cmp	x9, x10
100244c10:     	b.eq	0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244c14:     	tbnz	w23, #0x0, 0x100244c58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe20>
100244c18:     	ldr	w8, [x9, #0x4]
100244c1c:     	cmp	x2, x8
100244c20:     	b.ne	0x100244c58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe20>
100244c24:     	add	x0, x9, #0x14
100244c28:     	mov	x1, x24
100244c2c:     	ldr	x2, [sp, #0x28]
100244c30:     	mov	x24, x14
100244c34:     	str	x10, [sp, #0x78]
100244c38:     	bl	0x100b610e0 <_writev+0x100b610e0>
100244c3c:     	ldr	x10, [sp, #0x78]
100244c40:     	ldr	x2, [sp, #0x28]
100244c44:     	mov	x14, x24
100244c48:     	ldr	x24, [sp, #0x18]
100244c4c:     	add	x8, sp, #0x148
100244c50:     	add	x8, x8, #0x28
100244c54:     	cbz	w0, 0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244c58:     	cmp	x22, #0x6
100244c5c:     	b.eq	0x100244d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244c60:     	ldr	x9, [sp, #0x130]
100244c64:     	add	x8, sp, #0x148
100244c68:     	add	x8, x8, #0x30
100244c6c:     	cmp	x9, x10
100244c70:     	b.eq	0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244c74:     	tbnz	w23, #0x0, 0x100244cb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe80>
100244c78:     	ldr	w8, [x9, #0x4]
100244c7c:     	cmp	x2, x8
100244c80:     	b.ne	0x100244cb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xe80>
100244c84:     	add	x0, x9, #0x14
100244c88:     	mov	x1, x24
100244c8c:     	ldr	x2, [sp, #0x28]
100244c90:     	mov	x24, x14
100244c94:     	str	x10, [sp, #0x78]
100244c98:     	bl	0x100b610e0 <_writev+0x100b610e0>
100244c9c:     	ldr	x10, [sp, #0x78]
100244ca0:     	ldr	x2, [sp, #0x28]
100244ca4:     	mov	x14, x24
100244ca8:     	ldr	x24, [sp, #0x18]
100244cac:     	add	x8, sp, #0x148
100244cb0:     	add	x8, x8, #0x30
100244cb4:     	cbz	w0, 0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244cb8:     	cmp	x22, #0x7
100244cbc:     	b.eq	0x100244d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244cc0:     	ldr	x9, [sp, #0x138]
100244cc4:     	add	x8, sp, #0x148
100244cc8:     	add	x8, x8, #0x38
100244ccc:     	cmp	x9, x10
100244cd0:     	b.eq	0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244cd4:     	tbnz	w23, #0x0, 0x100244d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xed4>
100244cd8:     	ldr	w8, [x9, #0x4]
100244cdc:     	cmp	x2, x8
100244ce0:     	b.ne	0x100244d0c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xed4>
100244ce4:     	add	x0, x9, #0x14
100244ce8:     	mov	x1, x24
100244cec:     	mov	x23, x14
100244cf0:     	str	x10, [sp, #0x78]
100244cf4:     	bl	0x100b610e0 <_writev+0x100b610e0>
100244cf8:     	ldr	x10, [sp, #0x78]
100244cfc:     	mov	x14, x23
100244d00:     	add	x8, sp, #0x148
100244d04:     	add	x8, x8, #0x38
100244d08:     	cbz	w0, 0x100244dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf88>
100244d0c:     	cmp	x22, #0x8
100244d10:     	b.ne	0x100244d9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf64>
100244d14:     	mov	x24, x10
100244d18:     	mov	x23, x14
100244d1c:     	mov	w0, #0x80               ; =128
100244d20:     	mov	w1, #0x8                ; =8
100244d24:     	bl	0x100b5e4c8 <_mi_malloc_aligned>
100244d28:     	cbz	x0, 0x100245ed0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2098>
100244d2c:     	mov	x22, x0
100244d30:     	mov	w0, #0x80               ; =128
100244d34:     	mov	w1, #0x8                ; =8
100244d38:     	bl	0x100b5e4c8 <_mi_malloc_aligned>
100244d3c:     	cbz	x0, 0x100245ed0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2098>
100244d40:     	mov	x26, x0
100244d44:     	ldp	q0, q1, [sp, #0x100]
100244d48:     	stp	q0, q1, [x22]
100244d4c:     	ldp	q0, q1, [sp, #0x120]
100244d50:     	stp	q0, q1, [x22, #0x20]
100244d54:     	add	x8, sp, #0x148
100244d58:     	ldp	q0, q1, [x8]
100244d5c:     	stp	q0, q1, [x0]
100244d60:     	ldp	q0, q1, [x8, #0x20]
100244d64:     	stp	q0, q1, [x0, #0x20]
100244d68:     	str	x24, [x22, #0x40]
100244d6c:     	ldp	x9, x24, [sp, #0x10]
100244d70:     	str	x9, [x0, #0x40]
100244d74:     	mov	w9, #0x10               ; =16
100244d78:     	stp	x9, x22, [sp, #0x188]
100244d7c:     	ldp	q0, q1, [sp, #0x30]
100244d80:     	str	q1, [x8, #0x50]
100244d84:     	str	x0, [sp, #0x1a8]
100244d88:     	mov	w1, #0x9                ; =9
100244d8c:     	mov	w22, #0x8               ; =8
100244d90:     	stur	q0, [x8, #0x68]
100244d94:     	mov	x14, x23
100244d98:     	b	0x10024572c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x18f4>
100244d9c:     	add	x8, sp, #0x100
100244da0:     	str	x10, [x8, x22, lsl #3]
100244da4:     	add	x8, sp, #0x148
100244da8:     	ldr	x9, [sp, #0x10]
100244dac:     	str	x9, [x8, x22, lsl #3]
100244db0:     	add	x22, x22, #0x1
100244db4:     	str	x22, [sp, #0x70]
100244db8:     	b	0x100244dc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf90>
100244dbc:     	add	x8, sp, #0x148
100244dc0:     	ldr	x9, [sp, #0x10]
100244dc4:     	str	x9, [x8]
100244dc8:     	ldr	x1, [sp, #0x20]
100244dcc:     	b	0x10024572c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x18f4>
100244dd0:     	ldp	x23, x8, [sp, #0x190]
100244dd4:     	str	x8, [sp, #0x20]
100244dd8:     	str	x21, [sp, #0x8]
100244ddc:     	mov	x0, x24
100244de0:     	mov	x1, x2
100244de4:     	bl	0x100326a7c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json20cached_parse_key_ptr>
100244de8:     	mov	x26, x0
100244dec:     	mov	x14, x27
100244df0:     	cmp	x27, #0x0
100244df4:     	cset	w8, eq
100244df8:     	ldr	w9, [sp, #0x80]
100244dfc:     	ldr	x11, [sp, #0x20]
100244e00:     	cbz	x11, 0x100244e88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1050>
100244e04:     	mov	x24, #0x0               ; =0
100244e08:     	orr	w22, w8, w9
100244e0c:     	lsl	x27, x11, #3
100244e10:     	b	0x100244e20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfe8>
100244e14:     	add	x24, x24, #0x1
100244e18:     	subs	x27, x27, #0x8
100244e1c:     	b.eq	0x100244e88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1050>
100244e20:     	ldr	x8, [x23, x24, lsl #3]
100244e24:     	cmp	x8, x26
100244e28:     	b.eq	0x100244e60 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1028>
100244e2c:     	tbnz	w22, #0x0, 0x100244e14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfdc>
100244e30:     	ldr	w9, [x8, #0x4]
100244e34:     	ldr	x10, [sp, #0x28]
100244e38:     	cmp	x10, x9
100244e3c:     	b.ne	0x100244e14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfdc>
100244e40:     	add	x0, x8, #0x14
100244e44:     	ldr	x1, [sp, #0x18]
100244e48:     	ldr	x2, [sp, #0x28]
100244e4c:     	mov	x21, x14
100244e50:     	bl	0x100b610e0 <_writev+0x100b610e0>
100244e54:     	ldr	x11, [sp, #0x20]
100244e58:     	mov	x14, x21
100244e5c:     	cbnz	w0, 0x100244e14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xfdc>
100244e60:     	ldr	x1, [sp, #0x1b0]
100244e64:     	cmp	x24, x1
100244e68:     	b.hs	0x100245e88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x2050>
100244e6c:     	ldr	x26, [sp, #0x1a8]
100244e70:     	ldp	x21, x8, [sp, #0x8]
100244e74:     	str	x8, [x26, x24, lsl #3]
100244e78:     	ldr	x22, [sp]
100244e7c:     	ldr	w27, [sp, #0x78]
100244e80:     	ldr	x24, [sp, #0x18]
100244e84:     	b	0x10024572c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x18f4>
100244e88:     	ldr	x8, [sp, #0x188]
100244e8c:     	cmp	x11, x8
100244e90:     	ldr	x21, [sp, #0x8]
100244e94:     	ldr	w27, [sp, #0x78]
100244e98:     	b.eq	0x100245074 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x123c>
100244e9c:     	str	x26, [x23, x11, lsl #3]
100244ea0:     	add	x8, x11, #0x1
100244ea4:     	str	x8, [sp, #0x198]
100244ea8:     	ldr	x22, [sp, #0x1b0]
100244eac:     	ldr	x8, [sp, #0x1a0]
100244eb0:     	cmp	x22, x8
100244eb4:     	b.eq	0x100245094 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x125c>
100244eb8:     	ldr	x26, [sp, #0x1a8]
100244ebc:     	ldp	x8, x24, [sp, #0x10]
100244ec0:     	str	x8, [x26, x22, lsl #3]
100244ec4:     	add	x1, x22, #0x1
100244ec8:     	str	x1, [sp, #0x1b0]
100244ecc:     	ldr	x22, [sp]
100244ed0:     	b	0x10024572c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x18f4>
100244ed4:     	mov	x8, x24
100244ed8:     	mov	w24, #0x0               ; =0
100244edc:     	add	x8, x8, #0x20
100244ee0:     	mov	x9, x22
100244ee4:     	movi.16b	v4, #0xbf
100244ee8:     	movi.16b	v5, #0x1
100244eec:     	movi.16b	v6, #0xef
100244ef0:     	mov	x2, x22
100244ef4:     	ldp	q0, q1, [x8, #-0x20]
100244ef8:     	cmgt.16b	v2, v0, v4
100244efc:     	and.16b	v2, v2, v5
100244f00:     	cmhi.16b	v0, v0, v6
100244f04:     	sub.16b	v0, v2, v0
100244f08:     	cmgt.16b	v2, v1, v4
100244f0c:     	cmhi.16b	v1, v1, v6
100244f10:     	sub.16b	v0, v0, v2
100244f14:     	sub.16b	v0, v0, v1
100244f18:     	ldp	q1, q2, [x8], #0x40
100244f1c:     	cmgt.16b	v3, v1, v4
100244f20:     	sub.16b	v0, v0, v3
100244f24:     	cmhi.16b	v1, v1, v6
100244f28:     	sub.16b	v0, v0, v1
100244f2c:     	cmgt.16b	v1, v2, v4
100244f30:     	cmhi.16b	v2, v2, v6
100244f34:     	sub.16b	v0, v0, v1
100244f38:     	sub.16b	v0, v0, v2
100244f3c:     	uaddlv.16b	h0, v0
100244f40:     	fmov	w10, s0
100244f44:     	add	w24, w10, w24
100244f48:     	sub	x9, x9, #0x40
100244f4c:     	cmp	x9, #0x3f
100244f50:     	b.hi	0x100244ef4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x10bc>
100244f54:     	and	x13, x2, #0x7fffffffffffffc0
100244f58:     	cmp	x13, x2
100244f5c:     	mov	x14, x27
100244f60:     	b.eq	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100244f64:     	ldr	x8, [sp, #0x18]
100244f68:     	add	x9, x8, x13
100244f6c:     	and	x10, x2, #0x800000000000003f
100244f70:     	cmp	x10, #0x4
100244f74:     	b.hs	0x100245064 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x122c>
100244f78:     	mov	x8, x9
100244f7c:     	b	0x10024558c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1754>
100244f80:     	mov	w24, #0x0               ; =0
100244f84:     	ldur	w8, [x19, #0x20]
100244f88:     	tbz	w8, #0x0, 0x100245694 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x185c>
100244f8c:     	mov	x14, x27
100244f90:     	mov	w9, #0x20               ; =32
100244f94:     	mov	w8, #0x14               ; =20
100244f98:     	b	0x100245684 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x184c>
100244f9c:     	mov	x10, x23
100244fa0:     	b	0x1002442b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x478>
100244fa4:     	cmp	x2, #0x10
100244fa8:     	b.hs	0x1002450b0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1278>
100244fac:     	mov	x8, #0x0                ; =0
100244fb0:     	mov	w24, #0x0               ; =0
100244fb4:     	mov	x10, x8
100244fb8:     	and	x8, x2, #0x38
100244fbc:     	movi.2d	v0, #0000000000000000
100244fc0:     	movi.2d	v1, #0000000000000000
100244fc4:     	mov.s	v1[0], w24
100244fc8:     	sub	x9, x10, x8
100244fcc:     	ldr	x11, [sp, #0x18]
100244fd0:     	add	x10, x11, x10
100244fd4:     	movi.4s	v16, #0x2
100244fd8:     	ldr	d2, [x10], #0x8
100244fdc:     	sshll.8h	v3, v2, #0x0
100244fe0:     	cmlt.8h	v3, v3, #0
100244fe4:     	sshll2.4s	v4, v3, #0x0
100244fe8:     	sshll.4s	v3, v3, #0x0
100244fec:     	cmhi.8b	v5, v8, v2
100244ff0:     	sshll.8h	v5, v5, #0x0
100244ff4:     	sshll2.4s	v6, v5, #0x0
100244ff8:     	sshll.4s	v7, v5, #0x0
100244ffc:     	bic.16b	v7, v16, v7
100245000:     	ssubw.4s	v7, v7, v5
100245004:     	bic.16b	v6, v16, v6
100245008:     	ssubw2.4s	v5, v6, v5
10024500c:     	cmgt.8b	v2, v9, v2
100245010:     	sshll.8h	v2, v2, #0x0
100245014:     	ushll.4s	v6, v2, #0x0
100245018:     	ushll2.4s	v2, v2, #0x0
10024501c:     	bic.16b	v2, v5, v2
100245020:     	bic.16b	v5, v7, v6
100245024:     	and.16b	v5, v5, v3
100245028:     	mvn.16b	v3, v3
10024502c:     	sub.4s	v3, v5, v3
100245030:     	and.16b	v2, v2, v4
100245034:     	mvn.16b	v4, v4
100245038:     	sub.4s	v2, v2, v4
10024503c:     	add.4s	v0, v2, v0
100245040:     	add.4s	v1, v3, v1
100245044:     	adds	x9, x9, #0x8
100245048:     	b.ne	0x100244fd8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x11a0>
10024504c:     	add.4s	v0, v1, v0
100245050:     	addv.4s	s0, v0
100245054:     	fmov	w24, s0
100245058:     	cmp	x2, x8
10024505c:     	b.ne	0x100245354 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x151c>
100245060:     	b	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100245064:     	cmp	x10, #0x20
100245068:     	b.hs	0x100245394 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x155c>
10024506c:     	mov	x11, #0x0               ; =0
100245070:     	b	0x100245520 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x16e8>
100245074:     	add	x0, sp, #0x188
100245078:     	mov	x21, x14
10024507c:     	bl	0x100b3af2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100245080:     	ldr	x11, [sp, #0x20]
100245084:     	mov	x14, x21
100245088:     	ldr	x21, [sp, #0x8]
10024508c:     	ldr	x23, [sp, #0x190]
100245090:     	b	0x100244e9c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1064>
100245094:     	add	x8, sp, #0x188
100245098:     	add	x0, x8, #0x18
10024509c:     	mov	x21, x14
1002450a0:     	bl	0x100b3af2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1002450a4:     	mov	x14, x21
1002450a8:     	ldr	x21, [sp, #0x8]
1002450ac:     	b	0x100244eb8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1080>
1002450b0:     	and	x8, x2, #0x30
1002450b4:     	ldp	d0, d1, [x24]
1002450b8:     	sshll.8h	v2, v0, #0x0
1002450bc:     	cmlt.8h	v2, v2, #0
1002450c0:     	sshll.4s	v3, v2, #0x0
1002450c4:     	sshll2.4s	v2, v2, #0x0
1002450c8:     	sshll.8h	v4, v1, #0x0
1002450cc:     	cmlt.8h	v4, v4, #0
1002450d0:     	sshll.4s	v5, v4, #0x0
1002450d4:     	sshll2.4s	v4, v4, #0x0
1002450d8:     	cmhi.8b	v6, v8, v0
1002450dc:     	sshll.8h	v6, v6, #0x0
1002450e0:     	sshll.4s	v7, v6, #0x0
1002450e4:     	sshll2.4s	v16, v6, #0x0
1002450e8:     	cmhi.8b	v17, v8, v1
1002450ec:     	sshll.8h	v17, v17, #0x0
1002450f0:     	sshll.4s	v18, v17, #0x0
1002450f4:     	sshll2.4s	v19, v17, #0x0
1002450f8:     	movi.4s	v24, #0x2
1002450fc:     	bic.16b	v16, v24, v16
100245100:     	ssubw2.4s	v16, v16, v6
100245104:     	bic.16b	v7, v24, v7
100245108:     	ssubw.4s	v6, v7, v6
10024510c:     	bic.16b	v7, v24, v19
100245110:     	ssubw2.4s	v7, v7, v17
100245114:     	bic.16b	v18, v24, v18
100245118:     	ssubw.4s	v17, v18, v17
10024511c:     	cmgt.8b	v0, v9, v0
100245120:     	sshll.8h	v0, v0, #0x0
100245124:     	ushll2.4s	v18, v0, #0x0
100245128:     	ushll.4s	v0, v0, #0x0
10024512c:     	cmgt.8b	v1, v9, v1
100245130:     	sshll.8h	v1, v1, #0x0
100245134:     	ushll2.4s	v19, v1, #0x0
100245138:     	ushll.4s	v20, v1, #0x0
10024513c:     	bic.16b	v1, v6, v0
100245140:     	bic.16b	v0, v16, v18
100245144:     	and.16b	v0, v0, v2
100245148:     	mvn.16b	v2, v2
10024514c:     	sub.4s	v0, v0, v2
100245150:     	and.16b	v1, v1, v3
100245154:     	mvn.16b	v2, v3
100245158:     	sub.4s	v1, v1, v2
10024515c:     	bic.16b	v3, v17, v20
100245160:     	bic.16b	v2, v7, v19
100245164:     	and.16b	v2, v2, v4
100245168:     	mvn.16b	v4, v4
10024516c:     	sub.4s	v2, v2, v4
100245170:     	and.16b	v3, v3, v5
100245174:     	mvn.16b	v4, v5
100245178:     	sub.4s	v3, v3, v4
10024517c:     	cmp	x8, #0x10
100245180:     	b.eq	0x100245334 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14fc>
100245184:     	ldp	d4, d5, [x24, #0x10]
100245188:     	sshll.8h	v6, v4, #0x0
10024518c:     	cmlt.8h	v6, v6, #0
100245190:     	sshll2.4s	v7, v6, #0x0
100245194:     	sshll.4s	v6, v6, #0x0
100245198:     	sshll.8h	v16, v5, #0x0
10024519c:     	cmlt.8h	v16, v16, #0
1002451a0:     	sshll2.4s	v17, v16, #0x0
1002451a4:     	sshll.4s	v16, v16, #0x0
1002451a8:     	cmhi.8b	v18, v8, v4
1002451ac:     	sshll.8h	v18, v18, #0x0
1002451b0:     	sshll2.4s	v19, v18, #0x0
1002451b4:     	sshll.4s	v20, v18, #0x0
1002451b8:     	cmhi.8b	v21, v8, v5
1002451bc:     	sshll.8h	v21, v21, #0x0
1002451c0:     	sshll2.4s	v22, v21, #0x0
1002451c4:     	sshll.4s	v23, v21, #0x0
1002451c8:     	bic.16b	v20, v24, v20
1002451cc:     	ssubw.4s	v20, v20, v18
1002451d0:     	bic.16b	v19, v24, v19
1002451d4:     	ssubw2.4s	v18, v19, v18
1002451d8:     	bic.16b	v19, v24, v23
1002451dc:     	ssubw.4s	v19, v19, v21
1002451e0:     	bic.16b	v22, v24, v22
1002451e4:     	ssubw2.4s	v21, v22, v21
1002451e8:     	cmgt.8b	v4, v9, v4
1002451ec:     	sshll.8h	v4, v4, #0x0
1002451f0:     	ushll.4s	v22, v4, #0x0
1002451f4:     	ushll2.4s	v4, v4, #0x0
1002451f8:     	cmgt.8b	v5, v9, v5
1002451fc:     	sshll.8h	v5, v5, #0x0
100245200:     	ushll.4s	v23, v5, #0x0
100245204:     	ushll2.4s	v5, v5, #0x0
100245208:     	bic.16b	v4, v18, v4
10024520c:     	bic.16b	v18, v20, v22
100245210:     	and.16b	v18, v18, v6
100245214:     	mvn.16b	v6, v6
100245218:     	sub.4s	v6, v18, v6
10024521c:     	and.16b	v4, v4, v7
100245220:     	mvn.16b	v7, v7
100245224:     	sub.4s	v4, v4, v7
100245228:     	bic.16b	v5, v21, v5
10024522c:     	bic.16b	v7, v19, v23
100245230:     	and.16b	v7, v7, v16
100245234:     	mvn.16b	v16, v16
100245238:     	sub.4s	v7, v7, v16
10024523c:     	and.16b	v5, v5, v17
100245240:     	mvn.16b	v16, v17
100245244:     	sub.4s	v5, v5, v16
100245248:     	add.4s	v0, v4, v0
10024524c:     	add.4s	v1, v6, v1
100245250:     	add.4s	v2, v5, v2
100245254:     	add.4s	v3, v7, v3
100245258:     	cmp	x8, #0x20
10024525c:     	b.eq	0x100245334 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x14fc>
100245260:     	ldp	d4, d5, [x24, #0x20]
100245264:     	sshll.8h	v6, v4, #0x0
100245268:     	cmlt.8h	v6, v6, #0
10024526c:     	sshll2.4s	v7, v6, #0x0
100245270:     	sshll.4s	v6, v6, #0x0
100245274:     	sshll.8h	v16, v5, #0x0
100245278:     	cmlt.8h	v16, v16, #0
10024527c:     	sshll2.4s	v17, v16, #0x0
100245280:     	sshll.4s	v16, v16, #0x0
100245284:     	cmhi.8b	v18, v8, v4
100245288:     	sshll.8h	v18, v18, #0x0
10024528c:     	sshll2.4s	v19, v18, #0x0
100245290:     	sshll.4s	v20, v18, #0x0
100245294:     	cmhi.8b	v21, v8, v5
100245298:     	sshll.8h	v21, v21, #0x0
10024529c:     	sshll2.4s	v22, v21, #0x0
1002452a0:     	sshll.4s	v23, v21, #0x0
1002452a4:     	bic.16b	v20, v24, v20
1002452a8:     	ssubw.4s	v20, v20, v18
1002452ac:     	bic.16b	v19, v24, v19
1002452b0:     	ssubw2.4s	v18, v19, v18
1002452b4:     	bic.16b	v19, v24, v23
1002452b8:     	ssubw.4s	v19, v19, v21
1002452bc:     	bic.16b	v22, v24, v22
1002452c0:     	ssubw2.4s	v21, v22, v21
1002452c4:     	cmgt.8b	v4, v9, v4
1002452c8:     	sshll.8h	v4, v4, #0x0
1002452cc:     	ushll.4s	v22, v4, #0x0
1002452d0:     	ushll2.4s	v4, v4, #0x0
1002452d4:     	cmgt.8b	v5, v9, v5
1002452d8:     	sshll.8h	v5, v5, #0x0
1002452dc:     	ushll.4s	v23, v5, #0x0
1002452e0:     	ushll2.4s	v5, v5, #0x0
1002452e4:     	bic.16b	v4, v18, v4
1002452e8:     	bic.16b	v18, v20, v22
1002452ec:     	and.16b	v18, v18, v6
1002452f0:     	mvn.16b	v6, v6
1002452f4:     	sub.4s	v6, v18, v6
1002452f8:     	and.16b	v4, v4, v7
1002452fc:     	mvn.16b	v7, v7
100245300:     	sub.4s	v4, v4, v7
100245304:     	bic.16b	v5, v21, v5
100245308:     	bic.16b	v7, v19, v23
10024530c:     	and.16b	v7, v7, v16
100245310:     	mvn.16b	v16, v16
100245314:     	sub.4s	v7, v7, v16
100245318:     	and.16b	v5, v5, v17
10024531c:     	mvn.16b	v16, v17
100245320:     	sub.4s	v5, v5, v16
100245324:     	add.4s	v0, v4, v0
100245328:     	add.4s	v1, v6, v1
10024532c:     	add.4s	v2, v5, v2
100245330:     	add.4s	v3, v7, v3
100245334:     	add.4s	v1, v3, v1
100245338:     	add.4s	v0, v2, v0
10024533c:     	add.4s	v0, v1, v0
100245340:     	addv.4s	s0, v0
100245344:     	fmov	w24, s0
100245348:     	cmp	x2, x8
10024534c:     	b.eq	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100245350:     	tbnz	w2, #0x3, 0x100244fb4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x117c>
100245354:     	sub	x9, x2, x8
100245358:     	ldr	x10, [sp, #0x18]
10024535c:     	add	x8, x10, x8
100245360:     	ldrsb	w10, [x8], #0x1
100245364:     	and	w11, w10, #0xff
100245368:     	cmp	w11, #0xf0
10024536c:     	mov	w12, #0x1               ; =1
100245370:     	cinc	w12, w12, hs
100245374:     	cmp	w11, #0xc0
100245378:     	csel	w11, wzr, w12, lo
10024537c:     	tst	w10, #0x80000000
100245380:     	csinc	w10, w11, wzr, ne
100245384:     	add	w24, w10, w24
100245388:     	subs	x9, x9, #0x1
10024538c:     	b.ne	0x100245360 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1528>
100245390:     	b	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
100245394:     	and	x12, x2, #0x1c
100245398:     	movi.2d	v0, #0000000000000000
10024539c:     	movi.2d	v1, #0000000000000000
1002453a0:     	mov.s	v1[0], w24
1002453a4:     	mov	x8, #-0x7               ; =-7
1002453a8:     	movk	x8, #0x7fff, lsl #48
1002453ac:     	add	x8, x8, #0x27
1002453b0:     	and	x11, x2, x8
1002453b4:     	add	x8, x9, x11
1002453b8:     	ldr	x14, [sp, #0x18]
1002453bc:     	add	x13, x14, x13
1002453c0:     	add	x13, x13, #0x10
1002453c4:     	mov	x14, x11
1002453c8:     	movi.2d	v3, #0000000000000000
1002453cc:     	movi.2d	v2, #0000000000000000
1002453d0:     	movi.2d	v7, #0000000000000000
1002453d4:     	movi.2d	v6, #0000000000000000
1002453d8:     	movi.2d	v4, #0000000000000000
1002453dc:     	movi.2d	v5, #0000000000000000
1002453e0:     	movi.16b	v12, #0xbf
1002453e4:     	movi.16b	v13, #0xef
1002453e8:     	movi.4s	v14, #0x1
1002453ec:     	ldp	q16, q17, [x13, #-0x10]
1002453f0:     	cmgt.16b	v18, v16, v12
1002453f4:     	ushll.8h	v19, v18, #0x0
1002453f8:     	ushll.4s	v20, v19, #0x0
1002453fc:     	and.16b	v20, v20, v14
100245400:     	ushll2.4s	v19, v19, #0x0
100245404:     	and.16b	v19, v19, v14
100245408:     	ushll2.8h	v18, v18, #0x0
10024540c:     	ushll.4s	v21, v18, #0x0
100245410:     	and.16b	v21, v21, v14
100245414:     	ushll2.4s	v18, v18, #0x0
100245418:     	and.16b	v18, v18, v14
10024541c:     	cmgt.16b	v22, v17, v12
100245420:     	ushll.8h	v23, v22, #0x0
100245424:     	ushll.4s	v24, v23, #0x0
100245428:     	and.16b	v24, v24, v14
10024542c:     	ushll2.4s	v23, v23, #0x0
100245430:     	and.16b	v23, v23, v14
100245434:     	ushll2.8h	v22, v22, #0x0
100245438:     	ushll.4s	v25, v22, #0x0
10024543c:     	and.16b	v25, v25, v14
100245440:     	ushll2.4s	v22, v22, #0x0
100245444:     	and.16b	v22, v22, v14
100245448:     	cmhi.16b	v16, v16, v13
10024544c:     	ushll2.8h	v26, v16, #0x0
100245450:     	ushll2.4s	v27, v26, #0x0
100245454:     	and.16b	v27, v27, v14
100245458:     	ushll.4s	v26, v26, #0x0
10024545c:     	and.16b	v26, v26, v14
100245460:     	ushll.8h	v16, v16, #0x0
100245464:     	ushll2.4s	v28, v16, #0x0
100245468:     	and.16b	v28, v28, v14
10024546c:     	ushll.4s	v16, v16, #0x0
100245470:     	and.16b	v16, v16, v14
100245474:     	cmhi.16b	v17, v17, v13
100245478:     	ushll2.8h	v29, v17, #0x0
10024547c:     	ushll2.4s	v30, v29, #0x0
100245480:     	and.16b	v30, v30, v14
100245484:     	ushll.4s	v29, v29, #0x0
100245488:     	and.16b	v29, v29, v14
10024548c:     	ushll.8h	v17, v17, #0x0
100245490:     	ushll2.4s	v31, v17, #0x0
100245494:     	and.16b	v31, v31, v14
100245498:     	ushll.4s	v17, v17, #0x0
10024549c:     	and.16b	v17, v17, v14
1002454a0:     	add.4s	v1, v1, v16
1002454a4:     	add.4s	v3, v3, v28
1002454a8:     	add.4s	v0, v0, v26
1002454ac:     	add.4s	v2, v2, v27
1002454b0:     	add.4s	v7, v7, v17
1002454b4:     	add.4s	v6, v6, v31
1002454b8:     	add.4s	v4, v4, v29
1002454bc:     	add.4s	v5, v5, v30
1002454c0:     	add.4s	v2, v2, v18
1002454c4:     	add.4s	v0, v0, v21
1002454c8:     	add.4s	v3, v3, v19
1002454cc:     	add.4s	v1, v1, v20
1002454d0:     	add.4s	v5, v5, v22
1002454d4:     	add.4s	v4, v4, v25
1002454d8:     	add.4s	v6, v6, v23
1002454dc:     	add	x13, x13, #0x20
1002454e0:     	add.4s	v7, v7, v24
1002454e4:     	subs	x14, x14, #0x20
1002454e8:     	b.ne	0x1002453ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x15b4>
1002454ec:     	add.4s	v3, v6, v3
1002454f0:     	add.4s	v2, v5, v2
1002454f4:     	add.4s	v1, v7, v1
1002454f8:     	add.4s	v0, v4, v0
1002454fc:     	add.4s	v0, v1, v0
100245500:     	add.4s	v1, v3, v2
100245504:     	add.4s	v0, v0, v1
100245508:     	addv.4s	s0, v0
10024550c:     	fmov	w24, s0
100245510:     	cmp	x10, x11
100245514:     	mov	x14, x27
100245518:     	b.eq	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
10024551c:     	cbz	x12, 0x10024558c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1754>
100245520:     	mov	x8, #-0x7               ; =-7
100245524:     	movk	x8, #0x7fff, lsl #48
100245528:     	add	x8, x8, #0x43
10024552c:     	and	x12, x2, x8
100245530:     	add	x8, x9, x12
100245534:     	movi.2d	v0, #0000000000000000
100245538:     	mov.s	v0[0], w24
10024553c:     	movi.4s	v3, #0x1
100245540:     	ldr	s1, [x9, x11]
100245544:     	ushll.8h	v1, v1, #0x0
100245548:     	shl.4h	v2, v1, #0x8
10024554c:     	sshr.4h	v2, v2, #0x8
100245550:     	cmgt.4h	v2, v2, v10
100245554:     	ushll.4s	v2, v2, #0x0
100245558:     	and.16b	v2, v2, v3
10024555c:     	cmhi.4h	v1, v1, v11
100245560:     	ushll.4s	v1, v1, #0x0
100245564:     	and.16b	v1, v1, v3
100245568:     	add.4s	v0, v0, v1
10024556c:     	add.4s	v0, v0, v2
100245570:     	add	x11, x11, #0x4
100245574:     	cmp	x12, x11
100245578:     	b.ne	0x100245540 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1708>
10024557c:     	addv.4s	s0, v0
100245580:     	fmov	w24, s0
100245584:     	cmp	x10, x12
100245588:     	b.eq	0x1002455b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x177c>
10024558c:     	ldr	x9, [sp, #0x18]
100245590:     	add	x9, x9, x2
100245594:     	ldrb	w10, [x8], #0x1
100245598:     	sxtb	w11, w10
10024559c:     	cmp	w10, #0xef
1002455a0:     	cinc	w10, w24, hi
1002455a4:     	cmn	w11, #0x41
1002455a8:     	cinc	w24, w10, gt
1002455ac:     	cmp	x8, x9
1002455b0:     	b.ne	0x100245594 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x175c>
1002455b4:     	lsr	w8, w2, #19
1002455b8:     	cbz	w8, 0x100245658 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1820>
1002455bc:     	mov	x27, x14
1002455c0:     	mov	w23, w2
1002455c4:     	add	x0, x23, #0x14
1002455c8:     	mov	w1, #0x3                ; =3
1002455cc:     	mov	x22, x2
1002455d0:     	bl	0x100456bc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
1002455d4:     	mov	x26, x0
1002455d8:     	stp	w24, w22, [x0]
1002455dc:     	str	w22, [x0, #0x8]
1002455e0:     	mov	x8, #0x200000000        ; =8589934592
1002455e4:     	stur	x8, [x0, #0xc]
1002455e8:     	add	x0, x0, #0x14
1002455ec:     	ldr	x24, [sp, #0x18]
1002455f0:     	mov	x1, x24
1002455f4:     	mov	x2, x22
1002455f8:     	bl	0x100b610ec <_writev+0x100b610ec>
1002455fc:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100245600:     	ldr	w22, [x8, #0x590]
100245604:     	cmp	w22, #0x300
100245608:     	b.hs	0x100245848 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a10>
10024560c:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100245610:     	ldr	x8, [x8, #0x48]
100245614:     	cmn	x8, #0x1
100245618:     	b.eq	0x100245838 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a00>
10024561c:     	mrs	x9, TPIDRRO_EL0
100245620:     	and	x9, x9, #0xfffffffffffffff8
100245624:     	ldr	x0, [x9, x8, lsl #3]
100245628:     	cbz	x0, 0x100245838 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a00>
10024562c:     	add	x8, x0, x22, lsl #3
100245630:     	ldr	x0, [x8, #0x1e8]
100245634:     	cbz	x0, 0x100245848 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a10>
100245638:     	ldr	x8, [x0]
10024563c:     	adds	x8, x8, x23
100245640:     	csinv	x8, x8, xzr, lo
100245644:     	str	x8, [x0]
100245648:     	lsr	x8, x8, #25
10024564c:     	cbz	x8, 0x1002456c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1890>
100245650:     	bl	0x10045daf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
100245654:     	b	0x1002456c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1890>
100245658:     	ldur	x8, [x19, #0x20]
10024565c:     	cbz	x8, 0x100245690 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1858>
100245660:     	cmn	x2, #0x23
100245664:     	b.hs	0x100245690 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1858>
100245668:     	add	x8, x2, #0x23
10024566c:     	mov	x9, #-0x8               ; =-8
100245670:     	movk	x9, #0xf, lsl #16
100245674:     	and	x9, x8, x9
100245678:     	cmp	x9, #0x4, lsl #12       ; =0x4000
10024567c:     	b.hi	0x100245690 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1858>
100245680:     	add	x8, x2, #0x14
100245684:     	ldr	x10, [x19, #0x30]
100245688:     	ldrb	w10, [x10]
10024568c:     	tbz	w10, #0x0, 0x1002457d0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1998>
100245690:     	mov	x27, x14
100245694:     	mov	x0, x2
100245698:     	mov	x22, x2
10024569c:     	bl	0x1003499ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1002456a0:     	mov	x26, x0
1002456a4:     	mov	x0, x1
1002456a8:     	stp	w24, w22, [x26]
1002456ac:     	str	w22, [x26, #0x8]
1002456b0:     	mov	x8, #0x200000000        ; =8589934592
1002456b4:     	stur	x8, [x26, #0xc]
1002456b8:     	ldr	x24, [sp, #0x18]
1002456bc:     	mov	x1, x24
1002456c0:     	mov	x2, x22
1002456c4:     	bl	0x100b610ec <_writev+0x100b610ec>
1002456c8:     	ldr	x2, [sp, #0x20]
1002456cc:     	ldr	x1, [sp, #0x8]
1002456d0:     	add	x8, sp, #0x188
1002456d4:     	add	x0, x8, #0x30
1002456d8:     	bl	0x10028754c <__RNvMs_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB4_17ParsedObjectIndex11insert_hash>
1002456dc:     	ldr	x22, [sp, #0x198]
1002456e0:     	ldr	x8, [sp, #0x188]
1002456e4:     	cmp	x22, x8
1002456e8:     	b.eq	0x1002457b4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x197c>
1002456ec:     	ldr	x8, [sp, #0x190]
1002456f0:     	str	x26, [x8, x22, lsl #3]
1002456f4:     	add	x8, x22, #0x1
1002456f8:     	str	x8, [sp, #0x198]
1002456fc:     	ldr	x22, [sp, #0x1b0]
100245700:     	ldr	x8, [sp, #0x1a0]
100245704:     	cmp	x22, x8
100245708:     	b.eq	0x1002457c0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1988>
10024570c:     	ldr	x26, [sp, #0x1a8]
100245710:     	ldr	x8, [sp, #0x10]
100245714:     	str	x8, [x26, x22, lsl #3]
100245718:     	add	x1, x22, #0x1
10024571c:     	str	x1, [sp, #0x1b0]
100245720:     	ldr	x22, [sp]
100245724:     	mov	x14, x27
100245728:     	ldr	w27, [sp, #0x78]
10024572c:     	ldp	x23, x8, [x19, #0x68]
100245730:     	cmp	x8, x23
100245734:     	str	x1, [sp, #0x20]
100245738:     	b.hs	0x100245768 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1930>
10024573c:     	ldr	x9, [x19, #0x60]
100245740:     	ldrb	w10, [x9, x8]
100245744:     	cmp	w10, #0x20
100245748:     	b.hi	0x100245768 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1930>
10024574c:     	lsr	x10, x25, x10
100245750:     	tbz	w10, #0x0, 0x100245768 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1930>
100245754:     	add	x8, x8, #0x1
100245758:     	str	x8, [x19, #0x70]
10024575c:     	cmp	x23, x8
100245760:     	b.ne	0x100245740 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1908>
100245764:     	b	0x100245b10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cd8>
100245768:     	cmp	x8, x23
10024576c:     	b.hs	0x100245b10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cd8>
100245770:     	ldr	x9, [x19, #0x60]
100245774:     	ldrb	w9, [x9, x8]
100245778:     	cmp	w9, #0x2c
10024577c:     	b.ne	0x100245b10 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cd8>
100245780:     	add	x24, x8, #0x1
100245784:     	str	x24, [x19, #0x70]
100245788:     	cmp	x28, #0x1
10024578c:     	ldr	x28, [sp, #0x90]
100245790:     	b.lt	0x100244028 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1f0>
100245794:     	ldr	x0, [sp, #0x18]
100245798:     	mov	x23, x21
10024579c:     	mov	x21, x14
1002457a0:     	bl	0x100b5e240 <_mi_free>
1002457a4:     	mov	x14, x21
1002457a8:     	mov	x21, x23
1002457ac:     	ldp	x23, x24, [x19, #0x68]
1002457b0:     	b	0x100244028 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1f0>
1002457b4:     	add	x0, sp, #0x188
1002457b8:     	bl	0x100b3af2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1002457bc:     	b	0x1002456ec <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x18b4>
1002457c0:     	add	x8, sp, #0x188
1002457c4:     	add	x0, x8, #0x18
1002457c8:     	bl	0x100b3af2c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecxE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
1002457cc:     	b	0x10024570c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x18d4>
1002457d0:     	ldr	x10, [x19, #0x28]
1002457d4:     	ldp	x11, x12, [x10, #0x8]
1002457d8:     	add	x11, x11, #0x7
1002457dc:     	and	x11, x11, #0xfffffffffffffff8
1002457e0:     	subs	x12, x12, x11
1002457e4:     	csel	x12, xzr, x12, lo
1002457e8:     	mov	x27, x14
1002457ec:     	cmp	x9, x12
1002457f0:     	b.hi	0x100245694 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x185c>
1002457f4:     	ldr	x12, [x10]
1002457f8:     	add	x22, x12, x11
1002457fc:     	add	x11, x11, x9
100245800:     	str	x11, [x10, #0x8]
100245804:     	mov	w10, #0x203             ; =515
100245808:     	stp	w10, w9, [x22]
10024580c:     	add	x26, x22, #0x8
100245810:     	subs	x9, x9, #0x8
100245814:     	csel	x9, xzr, x9, lo
100245818:     	subs	x10, x9, x8
10024581c:     	csel	x1, xzr, x10, lo
100245820:     	b.ls	0x10024587c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a44>
100245824:     	cmp	x1, #0x9
100245828:     	b.hs	0x100245870 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a38>
10024582c:     	add	x8, x26, x9
100245830:     	stur	xzr, [x8, #-0x8]
100245834:     	b	0x10024587c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1a44>
100245838:     	bl	0x100b3e63c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10024583c:     	add	x8, x0, x22, lsl #3
100245840:     	ldr	x0, [x8, #0x1e8]
100245844:     	cbnz	x0, 0x100245638 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1800>
100245848:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10024584c:     	add	x0, x0, #0x78
100245850:     	bl	0x100b3be5c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100245854:     	ldr	x8, [x0]
100245858:     	adds	x8, x8, x23
10024585c:     	csinv	x8, x8, xzr, lo
100245860:     	str	x8, [x0]
100245864:     	lsr	x8, x8, #25
100245868:     	cbnz	x8, 0x100245650 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1818>
10024586c:     	b	0x1002456c8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1890>
100245870:     	add	x0, x26, x8
100245874:     	bl	0x100b60c24 <_writev+0x100b60c24>
100245878:     	ldr	x2, [sp, #0x28]
10024587c:     	stp	w24, w2, [x22, #0x8]
100245880:     	str	w2, [x22, #0x10]
100245884:     	mov	x8, #0x200000000        ; =8589934592
100245888:     	stur	x8, [x22, #0x14]
10024588c:     	add	x0, x22, #0x1c
100245890:     	ldr	x24, [sp, #0x18]
100245894:     	mov	x1, x24
100245898:     	b	0x1002456c4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x188c>
10024589c:     	adrp	x0, 0x10104d000 <_out_buf+0x3a48>
1002458a0:     	add	x0, x0, #0x780
1002458a4:     	bl	0x100b20a00 <__RINvMs1_NtNtCs4KWsSNcQanT_9once_cell4race8once_boxINtB6_7OnceBoxINtNtCsctvjasLqLe9_5alloc5boxed3BoxDNtNtCs3SoQS4yp3pP_5ahash12random_state12RandomSourceNtNtCsjgY6bXVaRmE_4core6marker4SendNtB2s_4SyncEL_EE4initNtNvMs1_B6_IBN_pE11get_or_init4VoidNCINvB2_11get_or_initNCNvB1C_7get_src0E0ECs3gRpqoBkMHm_13perry_runtime>
1002458a8:     	ldp	x0, x22, [x0]
1002458ac:     	adrp	x8, 0x10104d000 <_out_buf+0x3a48>
1002458b0:     	add	x8, x8, #0x788
1002458b4:     	ldapr	x24, [x8]
1002458b8:     	cbnz	x24, 0x100244304 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x4cc>
1002458bc:     	mov	x26, x0
1002458c0:     	adrp	x0, 0x10104d000 <_out_buf+0x3a48>
1002458c4:     	add	x0, x0, #0x788
1002458c8:     	bl	0x100b20940 <__RINvMs1_NtNtCs4KWsSNcQanT_9once_cell4race8once_boxINtB6_7OnceBoxAAyj4_j2_E4initNtNvMs1_B6_IBN_pE11get_or_init4VoidNCINvB2_11get_or_initNCNvNtCs3SoQS4yp3pP_5ahash12random_state15get_fixed_seeds0E0ECs3gRpqoBkMHm_13perry_runtime>
1002458cc:     	mov	x24, x0
1002458d0:     	mov	x0, x26
1002458d4:     	mov	x26, #0x7f2d            ; =32557
1002458d8:     	movk	x26, #0x4c95, lsl #16
1002458dc:     	movk	x26, #0xf42d, lsl #32
1002458e0:     	movk	x26, #0x5851, lsl #48
1002458e4:     	b	0x100244304 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x4cc>
1002458e8:     	strb	wzr, [x19, #0xd4]
1002458ec:     	cmp	x28, #0x1
1002458f0:     	b.lt	0x1002458fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ac4>
1002458f4:     	mov	x0, x24
1002458f8:     	bl	0x100b5e240 <_mi_free>
1002458fc:     	ldr	x14, [sp, #0x90]
100245900:     	ldp	x9, x8, [x19, #0x68]
100245904:     	cmp	x8, x9
100245908:     	b.hs	0x100245990 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b58>
10024590c:     	ldr	x10, [x19, #0x60]
100245910:     	mov	x11, #0x2600            ; =9728
100245914:     	movk	x11, #0x1, lsl #32
100245918:     	ldrb	w12, [x10, x8]
10024591c:     	cmp	w12, #0x20
100245920:     	b.hi	0x100245940 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b08>
100245924:     	lsr	x13, x11, x12
100245928:     	tbz	w13, #0x0, 0x100245940 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b08>
10024592c:     	add	x8, x8, #0x1
100245930:     	str	x8, [x19, #0x70]
100245934:     	cmp	x9, x8
100245938:     	b.ne	0x100245918 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ae0>
10024593c:     	b	0x100245990 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b58>
100245940:     	cmp	w12, #0x7d
100245944:     	b.ne	0x100245990 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b58>
100245948:     	add	x8, x8, #0x1
10024594c:     	str	x8, [x19, #0x70]
100245950:     	ldr	x8, [sp, #0x188]
100245954:     	cmn	x8, #0x1
100245958:     	b.ne	0x1002459a0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b68>
10024595c:     	ldr	w8, [sp, #0x9c]
100245960:     	ldr	w9, [sp, #0x80]
100245964:     	and	w8, w8, w9
100245968:     	tbz	w8, #0x0, 0x100245a4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c14>
10024596c:     	ldr	x8, [sp, #0x70]
100245970:     	cmp	x14, x8
100245974:     	b.ne	0x100245a4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c14>
100245978:     	cmp	x27, x14
10024597c:     	b.ne	0x100245a4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c14>
100245980:     	cmp	x22, #0x9
100245984:     	ldr	w2, [sp, #0x64]
100245988:     	b.lo	0x100245b48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d10>
10024598c:     	b	0x100245a14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1bdc>
100245990:     	strb	wzr, [x19, #0xd4]
100245994:     	ldr	x8, [sp, #0x188]
100245998:     	cmn	x8, #0x1
10024599c:     	b.eq	0x10024595c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b24>
1002459a0:     	ldp	x0, x1, [sp, #0x190]
1002459a4:     	cmp	x1, #0x9
1002459a8:     	b.hs	0x100245a2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1bf4>
1002459ac:     	ldr	x8, [x19, #0x78]
1002459b0:     	cmp	x1, x8
1002459b4:     	b.ne	0x1002459d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
1002459b8:     	ldr	x21, [x19, #0xc0]
1002459bc:     	cbz	x21, 0x1002459d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
1002459c0:     	cbz	x1, 0x100245b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
1002459c4:     	ldr	x8, [x19, #0x80]
1002459c8:     	ldr	x9, [x0]
1002459cc:     	cmp	x8, x9
1002459d0:     	b.eq	0x100245b20 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ce8>
1002459d4:     	mov	x24, x0
1002459d8:     	mov	x25, x1
1002459dc:     	bl	0x10032815c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
1002459e0:     	mov	x21, x0
1002459e4:     	mov	x23, x1
1002459e8:     	str	x25, [x19, #0x78]
1002459ec:     	lsl	x2, x25, #3
1002459f0:     	add	x0, x19, #0x80
1002459f4:     	mov	x1, x24
1002459f8:     	bl	0x100b610ec <_writev+0x100b610ec>
1002459fc:     	mov	x2, x23
100245a00:     	str	x21, [x19, #0xc0]
100245a04:     	str	w23, [x19, #0xd0]
100245a08:     	cmp	x22, #0x9
100245a0c:     	ldr	x8, [sp, #0x20]
100245a10:     	b.lo	0x100245a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c0c>
100245a14:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245a18:     	add	x3, x3, #0x710
100245a1c:     	mov	x0, #0x0                ; =0
100245a20:     	mov	x1, x22
100245a24:     	mov	w2, #0x8                ; =8
100245a28:     	bl	0x100b11c8c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245a2c:     	bl	0x10032815c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100245a30:     	mov	x21, x0
100245a34:     	mov	x2, x1
100245a38:     	cmp	x22, #0x9
100245a3c:     	ldr	x8, [sp, #0x20]
100245a40:     	b.hs	0x100245a14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1bdc>
100245a44:     	mov	x22, x8
100245a48:     	b	0x100245b4c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d14>
100245a4c:     	cmp	x22, #0x9
100245a50:     	b.hs	0x100245dd0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1f98>
100245a54:     	ldr	x8, [x19, #0x78]
100245a58:     	cmp	x22, x8
100245a5c:     	b.ne	0x100245a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245a60:     	ldr	x21, [x19, #0xc0]
100245a64:     	cbz	x21, 0x100245a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245a68:     	cbz	x22, 0x100245b44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245a6c:     	ldr	x8, [x19, #0x80]
100245a70:     	ldr	x9, [sp, #0x100]
100245a74:     	cmp	x8, x9
100245a78:     	b.eq	0x100245b3c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d04>
100245a7c:     	add	x0, sp, #0x100
100245a80:     	mov	x1, x22
100245a84:     	bl	0x10032815c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100245a88:     	mov	x21, x0
100245a8c:     	mov	x23, x1
100245a90:     	str	x22, [x19, #0x78]
100245a94:     	lsl	x2, x22, #3
100245a98:     	add	x0, x19, #0x80
100245a9c:     	add	x1, sp, #0x100
100245aa0:     	bl	0x100b610ec <_writev+0x100b610ec>
100245aa4:     	mov	x2, x23
100245aa8:     	str	x21, [x19, #0xc0]
100245aac:     	str	w23, [x19, #0xd0]
100245ab0:     	b	0x100245b48 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d10>
100245ab4:     	b	0x100243f2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0xf4>
100245ab8:     	sub	x0, x29, #0xa8
100245abc:     	mov	x1, #0x0                ; =0
100245ac0:     	bl	0x10032815c <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json30parse_shape_keys_array_with_id>
100245ac4:     	mov	x2, x1
100245ac8:     	mov	x1, x0
100245acc:     	str	xzr, [x19, #0x78]
100245ad0:     	str	x0, [x19, #0xc0]
100245ad4:     	str	w2, [x19, #0xd0]
100245ad8:     	add	x0, x19, #0x20
100245adc:     	mov	w3, #0x8                ; =8
100245ae0:     	mov	x4, #0x0                ; =0
100245ae4:     	bl	0x1005bae48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100245ae8:     	mov	x19, x0
100245aec:     	ldrb	w8, [x20, #0x20]
100245af0:     	cbnz	w8, 0x100245de8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1fb0>
100245af4:     	ldr	x8, [x20]
100245af8:     	cbnz	x8, 0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ff8>
100245afc:     	ldr	x8, [x20, #0x18]
100245b00:     	cmp	x27, x8
100245b04:     	b.hi	0x100245bf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1db8>
100245b08:     	str	x27, [x20, #0x18]
100245b0c:     	b	0x100245bf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1db8>
100245b10:     	mov	x27, x14
100245b14:     	cmp	x28, #0x1
100245b18:     	b.ge	0x1002458f4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1abc>
100245b1c:     	b	0x1002458fc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ac4>
100245b20:     	cmp	x1, #0x1
100245b24:     	b.ne	0x100245c28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1df0>
100245b28:     	ldr	w2, [x19, #0xd0]
100245b2c:     	cmp	x22, #0x9
100245b30:     	ldr	x8, [sp, #0x20]
100245b34:     	b.lo	0x100245a44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c0c>
100245b38:     	b	0x100245a14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1bdc>
100245b3c:     	cmp	x22, #0x1
100245b40:     	b.ne	0x100245ccc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1e94>
100245b44:     	ldr	w2, [x19, #0xd0]
100245b48:     	add	x26, sp, #0x148
100245b4c:     	add	x0, x19, #0x20
100245b50:     	mov	x1, x21
100245b54:     	mov	x3, x26
100245b58:     	mov	x4, x22
100245b5c:     	bl	0x1005bae48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object17json_construction36object_from_json_fields_preinstalled>
100245b60:     	mov	x19, x0
100245b64:     	ldrb	w8, [x20, #0x20]
100245b68:     	ldr	x21, [sp, #0x88]
100245b6c:     	cbnz	w8, 0x100245da8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1f70>
100245b70:     	ldr	x8, [x20]
100245b74:     	cbnz	x8, 0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ff8>
100245b78:     	ldr	x8, [x20, #0x18]
100245b7c:     	cmp	x21, x8
100245b80:     	b.hi	0x100245b88 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d50>
100245b84:     	str	x21, [x20, #0x18]
100245b88:     	ldr	x8, [sp, #0x188]
100245b8c:     	cmn	x8, #0x1
100245b90:     	b.eq	0x100245bf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1db8>
100245b94:     	cbz	x8, 0x100245ba0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d68>
100245b98:     	ldr	x0, [sp, #0x190]
100245b9c:     	bl	0x100b5e240 <_mi_free>
100245ba0:     	ldr	x8, [sp, #0x1a0]
100245ba4:     	cbz	x8, 0x100245bb0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d78>
100245ba8:     	ldr	x0, [sp, #0x1a8]
100245bac:     	bl	0x100b5e240 <_mi_free>
100245bb0:     	ldr	x20, [sp, #0x1b8]
100245bb4:     	cmn	x20, #0x1
100245bb8:     	b.eq	0x100245bf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1db8>
100245bbc:     	ldr	x9, [sp, #0x1d8]
100245bc0:     	cbz	x9, 0x100245be4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1dac>
100245bc4:     	lsl	x8, x9, #4
100245bc8:     	add	x9, x8, x9
100245bcc:     	cmn	x9, #0x19
100245bd0:     	b.eq	0x100245be4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1dac>
100245bd4:     	ldr	x9, [sp, #0x1d0]
100245bd8:     	sub	x8, x9, x8
100245bdc:     	sub	x0, x8, #0x10
100245be0:     	bl	0x100b5e240 <_mi_free>
100245be4:     	cbz	x20, 0x100245bf0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1db8>
100245be8:     	ldr	x0, [sp, #0x1c0]
100245bec:     	bl	0x100b5e240 <_mi_free>
100245bf0:     	mov	x0, #0x7ffd000000000000 ; =9222527611924643840
100245bf4:     	bfxil	x0, x19, #0, #48
100245bf8:     	add	sp, sp, #0x2e0
100245bfc:     	ldp	x29, x30, [sp, #0x90]
100245c00:     	ldp	x20, x19, [sp, #0x80]
100245c04:     	ldp	x22, x21, [sp, #0x70]
100245c08:     	ldp	x24, x23, [sp, #0x60]
100245c0c:     	ldp	x26, x25, [sp, #0x50]
100245c10:     	ldp	x28, x27, [sp, #0x40]
100245c14:     	ldp	d9, d8, [sp, #0x30]
100245c18:     	ldp	d11, d10, [sp, #0x20]
100245c1c:     	ldp	d13, d12, [sp, #0x10]
100245c20:     	ldp	d15, d14, [sp], #0xa0
100245c24:     	ret
100245c28:     	ldr	x8, [x19, #0x88]
100245c2c:     	ldr	x9, [x0, #0x8]
100245c30:     	cmp	x8, x9
100245c34:     	b.ne	0x1002459d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245c38:     	cmp	x1, #0x2
100245c3c:     	b.eq	0x100245b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245c40:     	ldr	x8, [x19, #0x90]
100245c44:     	ldr	x9, [x0, #0x10]
100245c48:     	cmp	x8, x9
100245c4c:     	b.ne	0x1002459d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245c50:     	cmp	x1, #0x3
100245c54:     	b.eq	0x100245b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245c58:     	ldr	x8, [x19, #0x98]
100245c5c:     	ldr	x9, [x0, #0x18]
100245c60:     	cmp	x8, x9
100245c64:     	b.ne	0x1002459d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245c68:     	cmp	x1, #0x4
100245c6c:     	b.eq	0x100245b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245c70:     	ldr	x8, [x19, #0xa0]
100245c74:     	ldr	x9, [x0, #0x20]
100245c78:     	cmp	x8, x9
100245c7c:     	b.ne	0x1002459d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245c80:     	cmp	x1, #0x5
100245c84:     	b.eq	0x100245b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245c88:     	ldr	x8, [x19, #0xa8]
100245c8c:     	ldr	x9, [x0, #0x28]
100245c90:     	cmp	x8, x9
100245c94:     	b.ne	0x1002459d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245c98:     	cmp	x1, #0x6
100245c9c:     	b.eq	0x100245b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245ca0:     	ldr	x8, [x19, #0xb0]
100245ca4:     	ldr	x9, [x0, #0x30]
100245ca8:     	cmp	x8, x9
100245cac:     	b.ne	0x1002459d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245cb0:     	cmp	x1, #0x7
100245cb4:     	b.eq	0x100245b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245cb8:     	ldr	x8, [x19, #0xb8]
100245cbc:     	ldr	x9, [x0, #0x38]
100245cc0:     	cmp	x8, x9
100245cc4:     	b.ne	0x1002459d4 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1b9c>
100245cc8:     	b	0x100245b28 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cf0>
100245ccc:     	ldr	x8, [x19, #0x88]
100245cd0:     	ldr	x9, [sp, #0x108]
100245cd4:     	cmp	x8, x9
100245cd8:     	b.ne	0x100245a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245cdc:     	cmp	x22, #0x2
100245ce0:     	b.eq	0x100245b44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245ce4:     	ldr	x8, [x19, #0x90]
100245ce8:     	ldr	x9, [sp, #0x110]
100245cec:     	cmp	x8, x9
100245cf0:     	b.ne	0x100245a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245cf4:     	cmp	x22, #0x3
100245cf8:     	b.eq	0x100245b44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245cfc:     	ldr	x8, [x19, #0x98]
100245d00:     	ldr	x9, [sp, #0x118]
100245d04:     	cmp	x8, x9
100245d08:     	b.ne	0x100245a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245d0c:     	cmp	x22, #0x4
100245d10:     	b.eq	0x100245b44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245d14:     	ldr	x8, [x19, #0xa0]
100245d18:     	ldr	x9, [sp, #0x120]
100245d1c:     	cmp	x8, x9
100245d20:     	b.ne	0x100245a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245d24:     	cmp	x22, #0x5
100245d28:     	b.eq	0x100245b44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245d2c:     	ldr	x8, [x19, #0xa8]
100245d30:     	ldr	x9, [sp, #0x128]
100245d34:     	cmp	x8, x9
100245d38:     	b.ne	0x100245a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245d3c:     	cmp	x22, #0x6
100245d40:     	b.eq	0x100245b44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245d44:     	ldr	x8, [x19, #0xb0]
100245d48:     	ldr	x9, [sp, #0x130]
100245d4c:     	cmp	x8, x9
100245d50:     	b.ne	0x100245a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245d54:     	cmp	x22, #0x7
100245d58:     	b.eq	0x100245b44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245d5c:     	ldr	x8, [x19, #0xb8]
100245d60:     	ldr	x9, [sp, #0x138]
100245d64:     	cmp	x8, x9
100245d68:     	b.ne	0x100245a7c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1c44>
100245d6c:     	b	0x100245b44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d0c>
100245d70:     	cmp	w8, #0x1
100245d74:     	b.ne	0x100245df0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1fb8>
100245d78:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100245d7c:     	add	x1, x1, #0x518
100245d80:     	mov	x0, x20
100245d84:     	bl	0x100a1f69c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100245d88:     	strb	wzr, [x20, #0x20]
100245d8c:     	ldr	x8, [x20]
100245d90:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100245d94:     	cmp	x8, x9
100245d98:     	b.lo	0x100243f5c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x124>
100245d9c:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100245da0:     	add	x0, x0, #0x4a0
100245da4:     	bl	0x100b1199c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100245da8:     	cmp	w8, #0x2
100245dac:     	b.eq	0x100245df0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1fb8>
100245db0:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100245db4:     	add	x1, x1, #0x518
100245db8:     	mov	x0, x20
100245dbc:     	bl	0x100a1f69c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100245dc0:     	strb	wzr, [x20, #0x20]
100245dc4:     	ldr	x8, [x20]
100245dc8:     	cbz	x8, 0x100245b78 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1d40>
100245dcc:     	b	0x100245e30 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1ff8>
100245dd0:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245dd4:     	add	x3, x3, #0x6f8
100245dd8:     	mov	x0, #0x0                ; =0
100245ddc:     	mov	x1, x22
100245de0:     	mov	w2, #0x8                ; =8
100245de4:     	bl	0x100b11c8c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245de8:     	cmp	w8, #0x2
100245dec:     	b.ne	0x100245e14 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1fdc>
100245df0:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100245df4:     	add	x0, x0, #0xc18
100245df8:     	bl	0x100b5789c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100245dfc:     	adrp	x3, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245e00:     	add	x3, x3, #0x6b0
100245e04:     	mov	x0, #0x0                ; =0
100245e08:     	mov	x1, x22
100245e0c:     	mov	w2, #0x8                ; =8
100245e10:     	bl	0x100b11c8c <__RNvNtNtCsjgY6bXVaRmE_4core5slice5index16slice_index_fail>
100245e14:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtB1a_6option6OptionINtNtCsctvjasLqLe9_5alloc3vec3VecbEEEECs3gRpqoBkMHm_13perry_runtime+0xc>
100245e18:     	add	x1, x1, #0x518
100245e1c:     	mov	x0, x20
100245e20:     	bl	0x100a1f69c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100245e24:     	strb	wzr, [x20, #0x20]
100245e28:     	ldr	x8, [x20]
100245e2c:     	cbz	x8, 0x100245afc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser20parse_object_untyped+0x1cc4>
100245e30:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100245e34:     	add	x0, x0, #0x488
100245e38:     	bl	0x100b1196c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100245e3c:     	adrp	x0, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245e40:     	add	x0, x0, #0x668
100245e44:     	bl	0x100b11a30 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100245e48:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100245e4c:     	add	x2, x2, #0x800
100245e50:     	mov	x0, x14
100245e54:     	mov	w1, #0x8                ; =8
100245e58:     	bl	0x100b11acc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245e5c:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100245e60:     	add	x2, x2, #0xab8
100245e64:     	mov	x0, x24
100245e68:     	bl	0x100b11acc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245e6c:     	adrp	x2, 0x100f02000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x10ed0>
100245e70:     	add	x2, x2, #0x320
100245e74:     	mov	x0, x24
100245e78:     	bl	0x100b11acc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245e7c:     	mov	w0, #0x8                ; =8
100245e80:     	mov	w1, #0x1108             ; =4360
100245e84:     	bl	0x100b115a8 <__RNvNtCsctvjasLqLe9_5alloc5alloc18handle_alloc_error>
100245e88:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245e8c:     	add	x2, x2, #0x6e0
100245e90:     	mov	x0, x24
100245e94:     	bl	0x100b11acc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245e98:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245e9c:     	add	x2, x2, #0x6c8
100245ea0:     	mov	x0, x24
100245ea4:     	bl	0x100b11acc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245ea8:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245eac:     	add	x2, x2, #0x698
100245eb0:     	mov	x0, x14
100245eb4:     	mov	w1, #0x8                ; =8
100245eb8:     	bl	0x100b11acc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245ebc:     	adrp	x2, 0x100f01000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xfed0>
100245ec0:     	add	x2, x2, #0x680
100245ec4:     	mov	x0, x14
100245ec8:     	mov	w1, #0x8                ; =8
100245ecc:     	bl	0x100b11acc <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100245ed0:     	mov	w0, #0x8                ; =8
100245ed4:     	mov	w1, #0x80               ; =128
100245ed8:     	bl	0x100b115c0 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
