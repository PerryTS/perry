
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/isolated-json-scan-chunks-r36/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001007bed90 <_js_array_get_f64>:
1007bed90:     	sub	sp, sp, #0x70
1007bed94:     	stp	x26, x25, [sp, #0x20]
1007bed98:     	stp	x24, x23, [sp, #0x30]
1007bed9c:     	stp	x22, x21, [sp, #0x40]
1007beda0:     	stp	x20, x19, [sp, #0x50]
1007beda4:     	stp	x29, x30, [sp, #0x60]
1007beda8:     	add	x29, sp, #0x60
1007bedac:     	mov	x19, x1
1007bedb0:     	mov	x22, x0
1007bedb4:     	lsr	x25, x0, #51
1007bedb8:     	mov	x20, x0
1007bedbc:     	cmp	x25, #0xfff
1007bedc0:     	b.lo	0x1007beddc <_js_array_get_f64+0x4c>
1007bedc4:     	mov	w8, #0x7ffc             ; =32764
1007bedc8:     	cmp	x8, x22, lsr #48
1007bedcc:     	b.ne	0x1007bedd8 <_js_array_get_f64+0x48>
1007bedd0:     	mov	x22, #0x7ff8000000000000 ; =9221120237041090560
1007bedd4:     	b	0x1007bf488 <_js_array_get_f64+0x6f8>
1007bedd8:     	and	x20, x22, #0xffffffffffff
1007beddc:     	lsr	x8, x20, #3
1007bede0:     	cmp	x8, #0x200
1007bede4:     	b.ls	0x1007bee1c <_js_array_get_f64+0x8c>
1007bede8:     	ldurb	w8, [x20, #-0x8]
1007bedec:     	cmp	w8, #0x9
1007bedf0:     	b.ne	0x1007bee1c <_js_array_get_f64+0x8c>
1007bedf4:     	ldr	w8, [x20, #0x4]
1007bedf8:     	mov	w9, #0x5841             ; =22593
1007bedfc:     	movk	w9, #0x4c5a, lsl #16
1007bee00:     	cmp	w8, w9
1007bee04:     	b.ne	0x1007bee1c <_js_array_get_f64+0x8c>
1007bee08:     	mov	x0, x20
1007bee0c:     	mov	x1, x19
1007bee10:     	bl	0x100688a04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape11cached_read8lazy_get>
1007bee14:     	fmov	d0, x0
1007bee18:     	b	0x1007bf48c <_js_array_get_f64+0x6fc>
1007bee1c:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bee20:     	b.lo	0x1007beed0 <_js_array_get_f64+0x140>
1007bee24:     	tst	x20, #0xffff800000000000
1007bee28:     	mov	w8, #0x1000             ; =4096
1007bee2c:     	ccmp	x20, x8, #0x0, eq
1007bee30:     	b.lo	0x1007beed0 <_js_array_get_f64+0x140>
1007bee34:     	ldurb	w24, [x20, #-0x8]
1007bee38:     	ldurh	w23, [x20, #-0x6]
1007bee3c:     	cmp	w24, #0xa
1007bee40:     	b.gt	0x1007befe8 <_js_array_get_f64+0x258>
1007bee44:     	cmp	w24, #0x2
1007bee48:     	b.eq	0x1007bf070 <_js_array_get_f64+0x2e0>
1007bee4c:     	cmp	w24, #0x8
1007bee50:     	b.ne	0x1007beed8 <_js_array_get_f64+0x148>
1007bee54:     	mov	x0, x20
1007bee58:     	bl	0x100305e68 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17is_registered_map>
1007bee5c:     	cbz	w0, 0x1007bf100 <_js_array_get_f64+0x370>
1007bee60:     	mov	x22, #0x1               ; =1
1007bee64:     	movk	x22, #0x7ffc, lsl #48
1007bee68:     	lsr	x8, x20, #51
1007bee6c:     	cmp	x8, #0xfff
1007bee70:     	b.lo	0x1007bee84 <_js_array_get_f64+0xf4>
1007bee74:     	mov	w8, #0x7ffc             ; =32764
1007bee78:     	cmp	x8, x20, lsr #48
1007bee7c:     	b.eq	0x1007bf488 <_js_array_get_f64+0x6f8>
1007bee80:     	and	x20, x20, #0xffffffffffff
1007bee84:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bee88:     	b.lo	0x1007beea8 <_js_array_get_f64+0x118>
1007bee8c:     	tst	x20, #0xffff800000000000
1007bee90:     	mov	w8, #0x1000             ; =4096
1007bee94:     	ccmp	x20, x8, #0x0, eq
1007bee98:     	b.lo	0x1007beea8 <_js_array_get_f64+0x118>
1007bee9c:     	ldurb	w8, [x20, #-0x8]
1007beea0:     	cmp	w8, #0x2
1007beea4:     	b.eq	0x1007bf774 <_js_array_get_f64+0x9e4>
1007beea8:     	cbz	x20, 0x1007bf488 <_js_array_get_f64+0x6f8>
1007beeac:     	mov	x0, x20
1007beeb0:     	mov	x1, x19
1007beeb4:     	bl	0x100306018 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3map17live_index_to_raw>
1007beeb8:     	cmp	w0, #0x1
1007beebc:     	b.ne	0x1007bf488 <_js_array_get_f64+0x6f8>
1007beec0:     	ldr	x8, [x20, #0x8]
1007beec4:     	ubfiz	x9, x1, #4, #32
1007beec8:     	ldr	x22, [x8, x9]
1007beecc:     	b	0x1007bf488 <_js_array_get_f64+0x6f8>
1007beed0:     	mov	w23, #0x0               ; =0
1007beed4:     	mov	w24, #0x0               ; =0
1007beed8:     	mov	x21, x22
1007beedc:     	cmp	x25, #0xfff
1007beee0:     	b.lo	0x1007beef8 <_js_array_get_f64+0x168>
1007beee4:     	mov	w8, #0x7ffc             ; =32764
1007beee8:     	cmp	x8, x22, lsr #48
1007beeec:     	b.eq	0x1007bf474 <_js_array_get_f64+0x6e4>
1007beef0:     	ands	x21, x22, #0xffffffffffff
1007beef4:     	b.eq	0x1007bf474 <_js_array_get_f64+0x6e4>
1007beef8:     	and	x8, x21, #0xfffffffffff00000
1007beefc:     	sub	x9, x21, #0x1, lsl #12  ; =0x1000
1007bef00:     	mov	x10, #0x7ffffffff000    ; =140737488351232
1007bef04:     	cmp	x9, x10
1007bef08:     	ccmp	x8, #0x0, #0x4, lo
1007bef0c:     	b.eq	0x1007bf474 <_js_array_get_f64+0x6e4>
1007bef10:     	tst	x21, #0x3
1007bef14:     	ccmp	x21, #0x7, #0x0, eq
1007bef18:     	b.ls	0x1007bf1c8 <_js_array_get_f64+0x438>
1007bef1c:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bef20:     	ldr	x8, [x8, #0x48]
1007bef24:     	cmn	x8, #0x1
1007bef28:     	b.eq	0x1007bf118 <_js_array_get_f64+0x388>
1007bef2c:     	mrs	x9, TPIDRRO_EL0
1007bef30:     	and	x9, x9, #0xfffffffffffffff8
1007bef34:     	ldr	x0, [x9, x8, lsl #3]
1007bef38:     	cbz	x0, 0x1007bf118 <_js_array_get_f64+0x388>
1007bef3c:     	lsr	x1, x21, #20
1007bef40:     	ldr	x8, [x0, #0x10]
1007bef44:     	ldrb	w9, [x8]
1007bef48:     	cmp	w9, #0x2
1007bef4c:     	b.ne	0x1007bf130 <_js_array_get_f64+0x3a0>
1007bef50:     	ldrb	w9, [x8, #0x88]
1007bef54:     	tbz	w9, #0x0, 0x1007bef74 <_js_array_get_f64+0x1e4>
1007bef58:     	ldr	x9, [x8, #0x80]
1007bef5c:     	cmp	x9, x1
1007bef60:     	b.ne	0x1007bef74 <_js_array_get_f64+0x1e4>
1007bef64:     	ldp	x9, x10, [x8, #0x60]
1007bef68:     	cmp	x9, x21
1007bef6c:     	ccmp	x10, x21, #0x0, ls
1007bef70:     	b.hi	0x1007bf110 <_js_array_get_f64+0x380>
1007bef74:     	ldrb	w9, [x8, #0xb8]
1007bef78:     	cbz	w9, 0x1007bef98 <_js_array_get_f64+0x208>
1007bef7c:     	ldr	x9, [x8, #0xb0]
1007bef80:     	cmp	x9, x1
1007bef84:     	b.ne	0x1007bef98 <_js_array_get_f64+0x208>
1007bef88:     	ldp	x9, x10, [x8, #0x90]
1007bef8c:     	cmp	x9, x21
1007bef90:     	ccmp	x10, x21, #0x0, ls
1007bef94:     	b.hi	0x1007bf5d8 <_js_array_get_f64+0x848>
1007bef98:     	ldrb	w9, [x8, #0xe8]
1007bef9c:     	cbz	w9, 0x1007befbc <_js_array_get_f64+0x22c>
1007befa0:     	ldr	x9, [x8, #0xe0]
1007befa4:     	cmp	x9, x1
1007befa8:     	b.ne	0x1007befbc <_js_array_get_f64+0x22c>
1007befac:     	ldp	x9, x10, [x8, #0xc0]
1007befb0:     	cmp	x9, x21
1007befb4:     	ccmp	x10, x21, #0x0, ls
1007befb8:     	b.hi	0x1007bf6c0 <_js_array_get_f64+0x930>
1007befbc:     	ldrb	w9, [x8, #0x118]
1007befc0:     	cbz	w9, 0x1007bf190 <_js_array_get_f64+0x400>
1007befc4:     	ldr	x9, [x8, #0x110]
1007befc8:     	cmp	x9, x1
1007befcc:     	b.ne	0x1007bf190 <_js_array_get_f64+0x400>
1007befd0:     	ldp	x9, x10, [x8, #0xf0]
1007befd4:     	cmp	x9, x21
1007befd8:     	ccmp	x10, x21, #0x0, ls
1007befdc:     	b.ls	0x1007bf190 <_js_array_get_f64+0x400>
1007befe0:     	add	x9, x8, #0xf0
1007befe4:     	b	0x1007bf6c4 <_js_array_get_f64+0x934>
1007befe8:     	cmp	w24, #0xb
1007befec:     	b.eq	0x1007bf088 <_js_array_get_f64+0x2f8>
1007beff0:     	cmp	w24, #0xc
1007beff4:     	b.ne	0x1007beed8 <_js_array_get_f64+0x148>
1007beff8:     	mov	x0, x20
1007beffc:     	bl	0x10030bbf8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set17is_registered_set>
1007bf000:     	cbz	w0, 0x1007bf108 <_js_array_get_f64+0x378>
1007bf004:     	mov	x22, #0x1               ; =1
1007bf008:     	movk	x22, #0x7ffc, lsl #48
1007bf00c:     	lsr	x8, x20, #51
1007bf010:     	cmp	x8, #0xfff
1007bf014:     	b.lo	0x1007bf028 <_js_array_get_f64+0x298>
1007bf018:     	mov	w8, #0x7ffc             ; =32764
1007bf01c:     	cmp	x8, x20, lsr #48
1007bf020:     	b.eq	0x1007bf488 <_js_array_get_f64+0x6f8>
1007bf024:     	and	x20, x20, #0xffffffffffff
1007bf028:     	cmp	x20, #0x100, lsl #12    ; =0x100000
1007bf02c:     	b.lo	0x1007bf04c <_js_array_get_f64+0x2bc>
1007bf030:     	tst	x20, #0xffff800000000000
1007bf034:     	mov	w8, #0x1000             ; =4096
1007bf038:     	ccmp	x20, x8, #0x0, eq
1007bf03c:     	b.lo	0x1007bf04c <_js_array_get_f64+0x2bc>
1007bf040:     	ldurb	w8, [x20, #-0x8]
1007bf044:     	cmp	w8, #0x2
1007bf048:     	b.eq	0x1007bf78c <_js_array_get_f64+0x9fc>
1007bf04c:     	cbz	x20, 0x1007bf488 <_js_array_get_f64+0x6f8>
1007bf050:     	mov	x0, x20
1007bf054:     	mov	x1, x19
1007bf058:     	bl	0x10030d870 <__RNvNtCs3gRpqoBkMHm_13perry_runtime3set21live_index_to_raw_set>
1007bf05c:     	cmp	w0, #0x1
1007bf060:     	b.ne	0x1007bf488 <_js_array_get_f64+0x6f8>
1007bf064:     	ldr	x8, [x20, #0x8]
1007bf068:     	ldr	x22, [x8, w1, uxtw #3]
1007bf06c:     	b	0x1007bf488 <_js_array_get_f64+0x6f8>
1007bf070:     	mov	x0, x22
1007bf074:     	mov	x1, x19
1007bf078:     	bl	0x10054910c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bf07c:     	tbnz	w0, #0x0, 0x1007bf484 <_js_array_get_f64+0x6f4>
1007bf080:     	mov	w24, #0x2               ; =2
1007bf084:     	b	0x1007beed8 <_js_array_get_f64+0x148>
1007bf088:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bf08c:     	add	x8, x8, #0xec0
1007bf090:     	ldaprb	w8, [x8]
1007bf094:     	cbz	w8, 0x1007bf0f8 <_js_array_get_f64+0x368>
1007bf098:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bf09c:     	add	x8, x8, #0x58
1007bf0a0:     	ldapr	x8, [x8]
1007bf0a4:     	cmp	x20, x8
1007bf0a8:     	b.lo	0x1007bf0f8 <_js_array_get_f64+0x368>
1007bf0ac:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bf0b0:     	add	x8, x8, #0x60
1007bf0b4:     	ldapr	x8, [x8]
1007bf0b8:     	cmp	x20, x8
1007bf0bc:     	b.hi	0x1007bf0f8 <_js_array_get_f64+0x368>
1007bf0c0:     	mov	x0, x20
1007bf0c4:     	bl	0x1002a5938 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bf0c8:     	tbz	w0, #0x0, 0x1007bf0f8 <_js_array_get_f64+0x368>
1007bf0cc:     	add	x0, sp, #0x8
1007bf0d0:     	mov	x1, x20
1007bf0d4:     	bl	0x1002a576c <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray30classify_element_read_receiver>
1007bf0d8:     	ldr	x8, [sp, #0x8]
1007bf0dc:     	cbz	x8, 0x1007bf704 <_js_array_get_f64+0x974>
1007bf0e0:     	cmp	x8, #0x1
1007bf0e4:     	b.ne	0x1007bf748 <_js_array_get_f64+0x9b8>
1007bf0e8:     	ldr	d0, [sp, #0x10]
1007bf0ec:     	scvtf	d1, w19
1007bf0f0:     	bl	0x10081d334 <_js_dyn_index_get>
1007bf0f4:     	b	0x1007bf484 <_js_array_get_f64+0x6f4>
1007bf0f8:     	mov	w24, #0xb               ; =11
1007bf0fc:     	b	0x1007beed8 <_js_array_get_f64+0x148>
1007bf100:     	mov	w24, #0x8               ; =8
1007bf104:     	b	0x1007beed8 <_js_array_get_f64+0x148>
1007bf108:     	mov	w24, #0xc               ; =12
1007bf10c:     	b	0x1007beed8 <_js_array_get_f64+0x148>
1007bf110:     	add	x9, x8, #0x60
1007bf114:     	b	0x1007bf6c4 <_js_array_get_f64+0x934>
1007bf118:     	bl	0x100b407fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
1007bf11c:     	lsr	x1, x21, #20
1007bf120:     	ldr	x8, [x0, #0x10]
1007bf124:     	ldrb	w9, [x8]
1007bf128:     	cmp	w9, #0x2
1007bf12c:     	b.eq	0x1007bef50 <_js_array_get_f64+0x1c0>
1007bf130:     	ldr	x9, [x8, #0x8]
1007bf134:     	ldr	x10, [x8, #0x28]
1007bf138:     	sub	x9, x1, x9
1007bf13c:     	cmp	x9, x10
1007bf140:     	b.hs	0x1007bf184 <_js_array_get_f64+0x3f4>
1007bf144:     	ldr	x10, [x8, #0x20]
1007bf148:     	mov	w11, #0x28              ; =40
1007bf14c:     	madd	x9, x9, x11, x10
1007bf150:     	ldr	x10, [x9]
1007bf154:     	ldr	x11, [x8, #0x10]
1007bf158:     	cmp	x10, x11
1007bf15c:     	b.ne	0x1007bf190 <_js_array_get_f64+0x400>
1007bf160:     	ldp	x10, x11, [x9, #0x8]
1007bf164:     	cmp	x10, x21
1007bf168:     	ccmp	x11, x21, #0x0, ls
1007bf16c:     	b.ls	0x1007bf190 <_js_array_get_f64+0x400>
1007bf170:     	ldr	x10, [x8, #0x30]
1007bf174:     	add	x10, x10, #0x1
1007bf178:     	str	x10, [x8, #0x30]
1007bf17c:     	add	x8, x9, #0x21
1007bf180:     	b	0x1007bf6d4 <_js_array_get_f64+0x944>
1007bf184:     	ldr	x9, [x8, #0x58]
1007bf188:     	add	x9, x9, #0x1
1007bf18c:     	str	x9, [x8, #0x58]
1007bf190:     	ldr	x9, [x8, #0x38]
1007bf194:     	add	x9, x9, #0x1
1007bf198:     	str	x9, [x8, #0x38]
1007bf19c:     	mov	x0, x21
1007bf1a0:     	bl	0x10051ee48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
1007bf1a4:     	and	w8, w0, #0xff
1007bf1a8:     	cbz	w8, 0x1007bf1c8 <_js_array_get_f64+0x438>
1007bf1ac:     	ldurb	w8, [x21, #-0x8]
1007bf1b0:     	ldurb	w9, [x21, #-0x7]
1007bf1b4:     	mov	w10, #0x82              ; =130
1007bf1b8:     	and	w9, w9, w10
1007bf1bc:     	cmp	w9, #0x2
1007bf1c0:     	ccmp	w8, #0x1, #0x0, eq
1007bf1c4:     	b.eq	0x1007bf298 <_js_array_get_f64+0x508>
1007bf1c8:     	mov	x0, x21
1007bf1cc:     	bl	0x10057b4c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bf1d0:     	cbz	x0, 0x1007bf1f8 <_js_array_get_f64+0x468>
1007bf1d4:     	ldrb	w9, [x0]
1007bf1d8:     	cmp	w9, #0x1
1007bf1dc:     	b.ne	0x1007bf214 <_js_array_get_f64+0x484>
1007bf1e0:     	ldrsb	w8, [x0, #0x1]
1007bf1e4:     	tbnz	w8, #0x1f, 0x1007bf2c0 <_js_array_get_f64+0x530>
1007bf1e8:     	ldp	w10, w9, [x21]
1007bf1ec:     	cmp	w10, w9
1007bf1f0:     	b.hi	0x1007bf34c <_js_array_get_f64+0x5bc>
1007bf1f4:     	b	0x1007bf364 <_js_array_get_f64+0x5d4>
1007bf1f8:     	mov	x25, x0
1007bf1fc:     	mov	x0, x21
1007bf200:     	bl	0x100589cf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bf204:     	tbz	w0, #0x0, 0x1007bf250 <_js_array_get_f64+0x4c0>
1007bf208:     	mov	x0, #0x0                ; =0
1007bf20c:     	mov	x8, x25
1007bf210:     	b	0x1007bf33c <_js_array_get_f64+0x5ac>
1007bf214:     	mov	x8, x0
1007bf218:     	cmp	w9, #0x1
1007bf21c:     	b.eq	0x1007bf33c <_js_array_get_f64+0x5ac>
1007bf220:     	cmp	w9, #0x9
1007bf224:     	b.ne	0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf228:     	ldr	w8, [x21, #0x4]
1007bf22c:     	mov	w9, #0x5841             ; =22593
1007bf230:     	movk	w9, #0x4c5a, lsl #16
1007bf234:     	cmp	w8, w9
1007bf238:     	b.ne	0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf23c:     	mov	x0, x21
1007bf240:     	bl	0x100376b10 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
1007bf244:     	cbz	x0, 0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf248:     	mov	x21, x0
1007bf24c:     	b	0x1007bf380 <_js_array_get_f64+0x5f0>
1007bf250:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bf254:     	add	x8, x8, #0xec0
1007bf258:     	ldaprb	w8, [x8]
1007bf25c:     	cbz	w8, 0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf260:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bf264:     	add	x8, x8, #0x58
1007bf268:     	ldapr	x8, [x8]
1007bf26c:     	cmp	x8, x21
1007bf270:     	b.hi	0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf274:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bf278:     	add	x8, x8, #0x60
1007bf27c:     	ldapr	x8, [x8]
1007bf280:     	cmp	x8, x21
1007bf284:     	b.lo	0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf288:     	mov	x0, x21
1007bf28c:     	bl	0x1002a5938 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bf290:     	tbnz	w0, #0x0, 0x1007bf208 <_js_array_get_f64+0x478>
1007bf294:     	b	0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf298:     	ldr	w8, [x21]
1007bf29c:     	mov	w9, #0xe100             ; =57600
1007bf2a0:     	movk	w9, #0x5f5, lsl #16
1007bf2a4:     	orr	w9, w9, #0x1
1007bf2a8:     	cmp	w8, w9
1007bf2ac:     	b.hs	0x1007bf1c8 <_js_array_get_f64+0x438>
1007bf2b0:     	ldr	w9, [x21, #0x4]
1007bf2b4:     	cmp	w8, w9
1007bf2b8:     	b.ls	0x1007bf380 <_js_array_get_f64+0x5f0>
1007bf2bc:     	b	0x1007bf1c8 <_js_array_get_f64+0x438>
1007bf2c0:     	mov	x25, x0
1007bf2c4:     	ldr	x21, [x0, #0x8]
1007bf2c8:     	mov	x0, x21
1007bf2cc:     	bl	0x10057b4c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bf2d0:     	cbz	x0, 0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf2d4:     	ldrb	w8, [x0]
1007bf2d8:     	cmp	w8, #0x1
1007bf2dc:     	b.ne	0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf2e0:     	ldrsb	w8, [x0, #0x1]
1007bf2e4:     	tbz	w8, #0x1f, 0x1007bf1e8 <_js_array_get_f64+0x458>
1007bf2e8:     	mov	w26, #0x1               ; =1
1007bf2ec:     	ldr	x21, [x0, #0x8]
1007bf2f0:     	mov	x0, x21
1007bf2f4:     	bl	0x10057b4c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1007bf2f8:     	cbz	x0, 0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf2fc:     	ldrb	w8, [x0]
1007bf300:     	cmp	w8, #0x1
1007bf304:     	b.ne	0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf308:     	cmp	w26, #0x3f
1007bf30c:     	b.hi	0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf310:     	add	w26, w26, #0x1
1007bf314:     	ldrsb	w8, [x0, #0x1]
1007bf318:     	tbnz	w8, #0x1f, 0x1007bf2ec <_js_array_get_f64+0x55c>
1007bf31c:     	str	x21, [x25, #0x8]
1007bf320:     	ldrb	w8, [x25, #0x1]
1007bf324:     	orr	w9, w8, #0x80
1007bf328:     	mov	x8, x25
1007bf32c:     	strb	w9, [x25, #0x1]
1007bf330:     	ldrb	w9, [x0]
1007bf334:     	cmp	w9, #0x1
1007bf338:     	b.ne	0x1007bf220 <_js_array_get_f64+0x490>
1007bf33c:     	ldp	w10, w9, [x21]
1007bf340:     	cmp	w10, w9
1007bf344:     	b.ls	0x1007bf364 <_js_array_get_f64+0x5d4>
1007bf348:     	cbz	x8, 0x1007bf374 <_js_array_get_f64+0x5e4>
1007bf34c:     	ldr	w8, [x0, #0x4]
1007bf350:     	ubfiz	x9, x9, #3, #32
1007bf354:     	add	x9, x9, #0x10
1007bf358:     	cmp	x9, x8
1007bf35c:     	b.eq	0x1007bf380 <_js_array_get_f64+0x5f0>
1007bf360:     	b	0x1007bf374 <_js_array_get_f64+0x5e4>
1007bf364:     	mov	w8, #0xe100             ; =57600
1007bf368:     	movk	w8, #0x5f5, lsl #16
1007bf36c:     	cmp	w10, w8
1007bf370:     	b.ls	0x1007bf380 <_js_array_get_f64+0x5f0>
1007bf374:     	mov	x0, x21
1007bf378:     	bl	0x100589cf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bf37c:     	tbz	w0, #0x0, 0x1007bf430 <_js_array_get_f64+0x6a0>
1007bf380:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bf384:     	add	x8, x8, #0xec0
1007bf388:     	ldaprb	w8, [x8]
1007bf38c:     	cbz	w8, 0x1007bf3d4 <_js_array_get_f64+0x644>
1007bf390:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bf394:     	add	x8, x8, #0x58
1007bf398:     	ldapr	x8, [x8]
1007bf39c:     	cmp	x21, x8
1007bf3a0:     	b.lo	0x1007bf3d4 <_js_array_get_f64+0x644>
1007bf3a4:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bf3a8:     	add	x8, x8, #0x60
1007bf3ac:     	ldapr	x8, [x8]
1007bf3b0:     	cmp	x21, x8
1007bf3b4:     	b.hi	0x1007bf3d4 <_js_array_get_f64+0x644>
1007bf3b8:     	mov	x0, x21
1007bf3bc:     	bl	0x1002a5938 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bf3c0:     	tbz	w0, #0x0, 0x1007bf3d4 <_js_array_get_f64+0x644>
1007bf3c4:     	mov	x0, x21
1007bf3c8:     	mov	x1, x19
1007bf3cc:     	bl	0x1008fd048 <_js_typed_array_get>
1007bf3d0:     	b	0x1007bf484 <_js_array_get_f64+0x6f4>
1007bf3d4:     	mov	x0, x21
1007bf3d8:     	bl	0x100589cf4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1007bf3dc:     	tbz	w0, #0x0, 0x1007bf404 <_js_array_get_f64+0x674>
1007bf3e0:     	mov	x0, x21
1007bf3e4:     	mov	x1, x19
1007bf3e8:     	bl	0x10058701c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6access16read_buffer_byte>
1007bf3ec:     	and	w8, w1, #0xff
1007bf3f0:     	ucvtf	d0, w8
1007bf3f4:     	fmov	x8, d0
1007bf3f8:     	tst	w0, #0x1
1007bf3fc:     	csel	x22, x8, xzr, ne
1007bf400:     	b	0x1007bf488 <_js_array_get_f64+0x6f8>
1007bf404:     	cmp	x21, x20
1007bf408:     	b.eq	0x1007bf4b0 <_js_array_get_f64+0x720>
1007bf40c:     	cmp	x21, #0x100, lsl #12    ; =0x100000
1007bf410:     	b.lo	0x1007bf4a8 <_js_array_get_f64+0x718>
1007bf414:     	tst	x21, #0xffff800000000000
1007bf418:     	mov	w8, #0x1000             ; =4096
1007bf41c:     	ccmp	x21, x8, #0x0, eq
1007bf420:     	b.lo	0x1007bf4a8 <_js_array_get_f64+0x718>
1007bf424:     	ldurb	w24, [x21, #-0x8]
1007bf428:     	ldurh	w23, [x21, #-0x6]
1007bf42c:     	b	0x1007bf4b0 <_js_array_get_f64+0x720>
1007bf430:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bf434:     	add	x8, x8, #0xec0
1007bf438:     	ldaprb	w8, [x8]
1007bf43c:     	cbz	w8, 0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf440:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bf444:     	add	x8, x8, #0x58
1007bf448:     	ldapr	x8, [x8]
1007bf44c:     	cmp	x21, x8
1007bf450:     	b.lo	0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf454:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1007bf458:     	add	x8, x8, #0x60
1007bf45c:     	ldapr	x8, [x8]
1007bf460:     	cmp	x21, x8
1007bf464:     	b.hi	0x1007bf474 <_js_array_get_f64+0x6e4>
1007bf468:     	mov	x0, x21
1007bf46c:     	bl	0x1002a5938 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
1007bf470:     	tbnz	w0, #0x0, 0x1007bf380 <_js_array_get_f64+0x5f0>
1007bf474:     	mov	x0, x22
1007bf478:     	mov	x1, x19
1007bf47c:     	bl	0x10054910c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass33array_subclass_fast_index_get_raw>
1007bf480:     	tbz	w0, #0x0, 0x1007bf758 <_js_array_get_f64+0x9c8>
1007bf484:     	fmov	x22, d0
1007bf488:     	fmov	d0, x22
1007bf48c:     	ldp	x29, x30, [sp, #0x60]
1007bf490:     	ldp	x20, x19, [sp, #0x50]
1007bf494:     	ldp	x22, x21, [sp, #0x40]
1007bf498:     	ldp	x24, x23, [sp, #0x30]
1007bf49c:     	ldp	x26, x25, [sp, #0x20]
1007bf4a0:     	add	sp, sp, #0x70
1007bf4a4:     	ret
1007bf4a8:     	mov	w23, #0x0               ; =0
1007bf4ac:     	mov	w24, #0x0               ; =0
1007bf4b0:     	cmp	w24, #0x1
1007bf4b4:     	b.ne	0x1007bf668 <_js_array_get_f64+0x8d8>
1007bf4b8:     	tbz	w23, #0xa, 0x1007bf668 <_js_array_get_f64+0x8d8>
1007bf4bc:     	adrp	x8, 0x100b66000 <_anon.2aa35172874dc18ddd0733027929dfee.91+0x14d>
1007bf4c0:     	add	x8, x8, #0x24c
1007bf4c4:     	cmp	w19, #0x3e8
1007bf4c8:     	b.lo	0x1007bf540 <_js_array_get_f64+0x7b0>
1007bf4cc:     	mov	x9, #0x0                ; =0
1007bf4d0:     	mov	w11, #0x1759            ; =5977
1007bf4d4:     	movk	w11, #0xd1b7, lsl #16
1007bf4d8:     	mov	w12, #0x2710            ; =10000
1007bf4dc:     	mov	w13, #0x147b            ; =5243
1007bf4e0:     	mov	w14, #0x64              ; =100
1007bf4e4:     	add	x15, sp, #0x8
1007bf4e8:     	mov	w16, #0x967f            ; =38527
1007bf4ec:     	movk	w16, #0x98, lsl #16
1007bf4f0:     	mov	x10, x19
1007bf4f4:     	mov	x17, x10
1007bf4f8:     	umull	x10, w10, w11
1007bf4fc:     	lsr	x10, x10, #45
1007bf500:     	msub	w0, w10, w12, w17
1007bf504:     	ubfx	w1, w0, #2, #14
1007bf508:     	mul	w1, w1, w13
1007bf50c:     	lsr	w1, w1, #17
1007bf510:     	msub	w0, w1, w14, w0
1007bf514:     	add	x2, x15, x9
1007bf518:     	ldrh	w1, [x8, w1, uxtw #1]
1007bf51c:     	strh	w1, [x2, #0x6]
1007bf520:     	and	x0, x0, #0xffff
1007bf524:     	ldrh	w0, [x8, x0, lsl #1]
1007bf528:     	strh	w0, [x2, #0x8]
1007bf52c:     	sub	x9, x9, #0x4
1007bf530:     	cmp	w17, w16
1007bf534:     	b.hi	0x1007bf4f4 <_js_array_get_f64+0x764>
1007bf538:     	add	x9, x9, #0xa
1007bf53c:     	b	0x1007bf548 <_js_array_get_f64+0x7b8>
1007bf540:     	mov	w9, #0xa                ; =10
1007bf544:     	mov	x10, x19
1007bf548:     	cmp	w10, #0x9
1007bf54c:     	b.ls	0x1007bf580 <_js_array_get_f64+0x7f0>
1007bf550:     	sub	x9, x9, #0x2
1007bf554:     	ubfx	w11, w10, #2, #14
1007bf558:     	mov	w12, #0x147b            ; =5243
1007bf55c:     	mul	w11, w11, w12
1007bf560:     	lsr	w11, w11, #17
1007bf564:     	mov	w12, #0x64              ; =100
1007bf568:     	msub	w10, w11, w12, w10
1007bf56c:     	and	x10, x10, #0xffff
1007bf570:     	ldrh	w10, [x8, x10, lsl #1]
1007bf574:     	add	x12, sp, #0x8
1007bf578:     	strh	w10, [x12, x9]
1007bf57c:     	mov	x10, x11
1007bf580:     	cbz	w19, 0x1007bf5b8 <_js_array_get_f64+0x828>
1007bf584:     	cbnz	w10, 0x1007bf5b8 <_js_array_get_f64+0x828>
1007bf588:     	cmp	x9, #0xa
1007bf58c:     	b.ne	0x1007bf5e0 <_js_array_get_f64+0x850>
1007bf590:     	mov	w23, #0x1               ; =1
1007bf594:     	add	x0, sp, #0x8
1007bf598:     	mov	x1, x21
1007bf59c:     	mov	w2, #0x1                ; =1
1007bf5a0:     	mov	x3, #0x0                ; =0
1007bf5a4:     	bl	0x1005b33fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bf5a8:     	ldr	x8, [sp, #0x8]
1007bf5ac:     	mov	w20, #0x1               ; =1
1007bf5b0:     	cbnz	x8, 0x1007bf630 <_js_array_get_f64+0x8a0>
1007bf5b4:     	b	0x1007bf668 <_js_array_get_f64+0x8d8>
1007bf5b8:     	sub	x23, x9, #0x1
1007bf5bc:     	ubfiz	w10, w10, #1, #4
1007bf5c0:     	add	x8, x8, x10
1007bf5c4:     	ldrb	w8, [x8, #0x1]
1007bf5c8:     	add	x10, sp, #0x8
1007bf5cc:     	strb	w8, [x10, x23]
1007bf5d0:     	mov	w8, #0xb                ; =11
1007bf5d4:     	b	0x1007bf5e8 <_js_array_get_f64+0x858>
1007bf5d8:     	add	x9, x8, #0x90
1007bf5dc:     	b	0x1007bf6c4 <_js_array_get_f64+0x934>
1007bf5e0:     	mov	w8, #0xa                ; =10
1007bf5e4:     	mov	x23, x9
1007bf5e8:     	sub	x22, x8, x9
1007bf5ec:     	mov	x0, x22
1007bf5f0:     	mov	w1, #0x1                ; =1
1007bf5f4:     	bl	0x100b60688 <_mi_malloc_aligned>
1007bf5f8:     	cbz	x0, 0x1007bf7a4 <_js_array_get_f64+0xa14>
1007bf5fc:     	mov	x20, x0
1007bf600:     	add	x8, sp, #0x8
1007bf604:     	add	x1, x8, x23
1007bf608:     	mov	x2, x22
1007bf60c:     	bl	0x100b632ac <_writev+0x100b632ac>
1007bf610:     	add	x0, sp, #0x8
1007bf614:     	mov	x1, x21
1007bf618:     	mov	x2, x20
1007bf61c:     	mov	x3, x22
1007bf620:     	bl	0x1005b33fc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16descriptor_state23get_accessor_descriptor>
1007bf624:     	ldr	w8, [sp, #0x8]
1007bf628:     	tbz	w8, #0x0, 0x1007bf660 <_js_array_get_f64+0x8d0>
1007bf62c:     	mov	w23, #0x0               ; =0
1007bf630:     	mov	x22, #0x1               ; =1
1007bf634:     	movk	x22, #0x7ffc, lsl #48
1007bf638:     	ldr	x0, [sp, #0x10]
1007bf63c:     	cbz	x0, 0x1007bf6f4 <_js_array_get_f64+0x964>
1007bf640:     	cbz	x21, 0x1007bf6e4 <_js_array_get_f64+0x954>
1007bf644:     	lsr	x8, x21, #52
1007bf648:     	cmp	x8, #0x7fe
1007bf64c:     	b.hi	0x1007bf6e8 <_js_array_get_f64+0x958>
1007bf650:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1007bf654:     	bfxil	x8, x21, #0, #48
1007bf658:     	mov	x21, x8
1007bf65c:     	b	0x1007bf6e8 <_js_array_get_f64+0x958>
1007bf660:     	mov	x0, x20
1007bf664:     	bl	0x100b60400 <_mi_free>
1007bf668:     	ldr	w8, [x21]
1007bf66c:     	cmp	w19, w8
1007bf670:     	b.hs	0x1007bf6b0 <_js_array_get_f64+0x920>
1007bf674:     	ldr	w8, [x21, #0x4]
1007bf678:     	cmp	w19, w8
1007bf67c:     	b.hs	0x1007bf6a0 <_js_array_get_f64+0x910>
1007bf680:     	add	x8, x21, w19, uxtw #3
1007bf684:     	ldr	x22, [x8, #0x8]
1007bf688:     	mov	x8, #0x1                ; =1
1007bf68c:     	movk	x8, #0x7ffc, lsl #48
1007bf690:     	add	x8, x8, #0xf
1007bf694:     	cmp	x22, x8
1007bf698:     	b.ne	0x1007bf488 <_js_array_get_f64+0x6f8>
1007bf69c:     	b	0x1007bf6b0 <_js_array_get_f64+0x920>
1007bf6a0:     	mov	x0, x21
1007bf6a4:     	mov	x1, x19
1007bf6a8:     	bl	0x10052b504 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array16indexing_support31array_sparse_index_property_get>
1007bf6ac:     	tbnz	w0, #0x0, 0x1007bf484 <_js_array_get_f64+0x6f4>
1007bf6b0:     	mov	x0, x21
1007bf6b4:     	mov	x1, x19
1007bf6b8:     	bl	0x1006c81d4 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime5array8indexing11proto_chain23array_oob_prototype_get>
1007bf6bc:     	b	0x1007bf484 <_js_array_get_f64+0x6f4>
1007bf6c0:     	add	x9, x8, #0xc0
1007bf6c4:     	ldr	x10, [x8, #0x30]
1007bf6c8:     	add	x10, x10, #0x1
1007bf6cc:     	str	x10, [x8, #0x30]
1007bf6d0:     	add	x8, x9, #0x19
1007bf6d4:     	ldrb	w8, [x8]
1007bf6d8:     	cmp	w8, #0xff
1007bf6dc:     	b.ne	0x1007bf1a8 <_js_array_get_f64+0x418>
1007bf6e0:     	b	0x1007bf19c <_js_array_get_f64+0x40c>
1007bf6e4:     	add	x21, x22, #0x1
1007bf6e8:     	fmov	d0, x21
1007bf6ec:     	bl	0x1006fdffc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime6object13field_get_set9accessors22invoke_accessor_getter>
1007bf6f0:     	mov	x22, x0
1007bf6f4:     	tbnz	w23, #0x0, 0x1007bf488 <_js_array_get_f64+0x6f8>
1007bf6f8:     	mov	x0, x20
1007bf6fc:     	bl	0x100b60400 <_mi_free>
1007bf700:     	b	0x1007bf488 <_js_array_get_f64+0x6f8>
1007bf704:     	ldr	x20, [sp, #0x10]
1007bf708:     	adrp	x8, 0x101061000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf79c>
1007bf70c:     	ldr	x8, [x8, #0xed8]
1007bf710:     	cbz	x8, 0x1007bf728 <_js_array_get_f64+0x998>
1007bf714:     	mov	x0, x20
1007bf718:     	bl	0x10013cd40 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtNtBa_11collections4hash3set7HashSetjNtNtCs3gRpqoBkMHm_13perry_runtime9fast_hash9PtrHasherEEE4withNCNvNtB2g_12native_arena20is_native_typed_view0bEB2g_>
1007bf71c:     	tbz	w0, #0x0, 0x1007bf728 <_js_array_get_f64+0x998>
1007bf720:     	mov	x0, x20
1007bf724:     	bl	0x1002bfb40 <__RNvNtCs3gRpqoBkMHm_13perry_runtime12native_arena19validate_view_alive>
1007bf728:     	tbnz	w19, #0x1f, 0x1007bf748 <_js_array_get_f64+0x9b8>
1007bf72c:     	ldr	w8, [x20]
1007bf730:     	cmp	w19, w8
1007bf734:     	b.hs	0x1007bf748 <_js_array_get_f64+0x9b8>
1007bf738:     	mov	w1, w19
1007bf73c:     	mov	x0, x20
1007bf740:     	bl	0x1002a5dcc <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray7load_at>
1007bf744:     	b	0x1007bf484 <_js_array_get_f64+0x6f4>
1007bf748:     	mov	x8, #0x1                ; =1
1007bf74c:     	movk	x8, #0x7ffc, lsl #48
1007bf750:     	mov	x22, x8
1007bf754:     	b	0x1007bf488 <_js_array_get_f64+0x6f8>
1007bf758:     	mov	x0, x22
1007bf75c:     	bl	0x100b48d70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass21array_object_receiver>
1007bf760:     	cmp	x0, #0x1
1007bf764:     	b.ne	0x1007bedd0 <_js_array_get_f64+0x40>
1007bf768:     	mov	x0, x19
1007bf76c:     	bl	0x100b48d90 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5array8subclass22array_object_index_get>
1007bf770:     	b	0x1007bf484 <_js_array_get_f64+0x6f4>
1007bf774:     	mov	x0, x20
1007bf778:     	mov	w1, #0x0                ; =0
1007bf77c:     	bl	0x100b4b300 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bf780:     	mov	x20, x0
1007bf784:     	cbnz	x0, 0x1007beeac <_js_array_get_f64+0x11c>
1007bf788:     	b	0x1007bf488 <_js_array_get_f64+0x6f8>
1007bf78c:     	mov	x0, x20
1007bf790:     	mov	w1, #0x1                ; =1
1007bf794:     	bl	0x100b4b300 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object16map_set_subclass28redirect_collection_receiver>
1007bf798:     	mov	x20, x0
1007bf79c:     	cbnz	x0, 0x1007bf050 <_js_array_get_f64+0x2c0>
1007bf7a0:     	b	0x1007bf488 <_js_array_get_f64+0x6f8>
1007bf7a4:     	mov	w0, #0x1                ; =1
1007bf7a8:     	mov	x1, x22
1007bf7ac:     	bl	0x100b13780 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
