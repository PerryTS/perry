
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/isolated-json-scan-chunks-r36/candidate-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010084622c <_js_json_stringify>:
10084622c:     	sub	sp, sp, #0x80
100846230:     	stp	d9, d8, [sp, #0x20]
100846234:     	stp	x26, x25, [sp, #0x30]
100846238:     	stp	x24, x23, [sp, #0x40]
10084623c:     	stp	x22, x21, [sp, #0x50]
100846240:     	stp	x20, x19, [sp, #0x60]
100846244:     	stp	x29, x30, [sp, #0x70]
100846248:     	add	x29, sp, #0x70
10084624c:     	mov	x21, x0
100846250:     	mov.16b	v8, v0
100846254:     	fmov	x19, d8
100846258:     	and	x20, x19, #0xffff000000000000
10084625c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100846260:     	cmp	x20, x8
100846264:     	b.ne	0x10084628c <_js_json_stringify+0x60>
100846268:     	and	x0, x19, #0xffffffffffff
10084626c:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
100846270:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100846274:     	movk	x9, #0xffef, lsl #16
100846278:     	cmp	x8, x9
10084627c:     	b.hi	0x10084628c <_js_json_stringify+0x60>
100846280:     	ldr	w8, [x0, #0x4]
100846284:     	cmp	w8, #0x40
100846288:     	b.hs	0x1008462fc <_js_json_stringify+0xd0>
10084628c:     	mov.16b	v0, v8
100846290:     	bl	0x1004eea3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
100846294:     	tbz	w0, #0x0, 0x1008462a0 <_js_json_stringify+0x74>
100846298:     	mov	x23, x1
10084629c:     	b	0x100846810 <_js_json_stringify+0x5e4>
1008462a0:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008462a4:     	cmp	x20, x8
1008462a8:     	b.ne	0x100846310 <_js_json_stringify+0xe4>
1008462ac:     	ands	x19, x19, #0xffffffffffff
1008462b0:     	b.eq	0x100846310 <_js_json_stringify+0xe4>
1008462b4:     	mov	x0, x19
1008462b8:     	bl	0x10050fc38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008462bc:     	cbz	w0, 0x100846310 <_js_json_stringify+0xe4>
1008462c0:     	ldurb	w8, [x19, #-0x8]
1008462c4:     	cmp	w8, #0x9
1008462c8:     	b.ne	0x100846310 <_js_json_stringify+0xe4>
1008462cc:     	ldr	w8, [x19, #0x4]
1008462d0:     	mov	w9, #0x5841             ; =22593
1008462d4:     	movk	w9, #0x4c5a, lsl #16
1008462d8:     	cmp	w8, w9
1008462dc:     	b.ne	0x100846310 <_js_json_stringify+0xe4>
1008462e0:     	mov	x0, x19
1008462e4:     	bl	0x100688e64 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
1008462e8:     	cbz	x0, 0x100846310 <_js_json_stringify+0xe4>
1008462ec:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008462f0:     	bfxil	x8, x0, #0, #48
1008462f4:     	fmov	d8, x8
1008462f8:     	b	0x100846310 <_js_json_stringify+0xe4>
1008462fc:     	bl	0x1004f3968 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100846300:     	tbnz	w0, #0x0, 0x100846298 <_js_json_stringify+0x6c>
100846304:     	mov.16b	v0, v8
100846308:     	bl	0x1004eea3c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
10084630c:     	tbnz	w0, #0x0, 0x100846298 <_js_json_stringify+0x6c>
100846310:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846314:     	add	x0, x0, #0xd78
100846318:     	ldr	x8, [x0]
10084631c:     	blr	x8
100846320:     	mov	x19, x0
100846324:     	ldr	w26, [x0]
100846328:     	add	w8, w26, #0x1
10084632c:     	str	w8, [x0]
100846330:     	cbz	w26, 0x1008463a0 <_js_json_stringify+0x174>
100846334:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846338:     	add	x0, x0, #0xd00
10084633c:     	ldr	x8, [x0]
100846340:     	blr	x8
100846344:     	ldrb	w8, [x0, #0x20]
100846348:     	cmp	w8, #0x1
10084634c:     	b.ne	0x100846904 <_js_json_stringify+0x6d8>
100846350:     	ldr	x8, [x0]
100846354:     	cbnz	x8, 0x100846910 <_js_json_stringify+0x6e4>
100846358:     	mov	x8, #-0x1               ; =-1
10084635c:     	str	x8, [x0]
100846360:     	ldr	x20, [x0, #0x18]
100846364:     	ldr	x8, [x0, #0x8]
100846368:     	cmp	x20, x8
10084636c:     	b.eq	0x100846834 <_js_json_stringify+0x608>
100846370:     	ldr	x8, [x0, #0x10]
100846374:     	mov	w9, #0x18               ; =24
100846378:     	madd	x8, x20, x9, x8
10084637c:     	mov	w9, #0x8                ; =8
100846380:     	stp	xzr, x9, [x8]
100846384:     	str	xzr, [x8, #0x10]
100846388:     	add	x8, x20, #0x1
10084638c:     	str	x8, [x0, #0x18]
100846390:     	ldr	x8, [x0]
100846394:     	add	x8, x8, #0x1
100846398:     	str	x8, [x0]
10084639c:     	b	0x10084642c <_js_json_stringify+0x200>
1008463a0:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008463a4:     	add	x0, x0, #0xdc0
1008463a8:     	ldr	x8, [x0]
1008463ac:     	blr	x8
1008463b0:     	strb	wzr, [x0]
1008463b4:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
1008463b8:     	add	x0, x0, #0xdf0
1008463bc:     	ldr	x8, [x0]
1008463c0:     	blr	x8
1008463c4:     	strb	wzr, [x0]
1008463c8:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
1008463cc:     	ldr	w20, [x8, #0x5a8]
1008463d0:     	cmp	w20, #0x300
1008463d4:     	b.hs	0x100846890 <_js_json_stringify+0x664>
1008463d8:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
1008463dc:     	ldr	x8, [x8, #0x48]
1008463e0:     	cmn	x8, #0x1
1008463e4:     	b.eq	0x100846880 <_js_json_stringify+0x654>
1008463e8:     	mrs	x9, TPIDRRO_EL0
1008463ec:     	and	x9, x9, #0xfffffffffffffff8
1008463f0:     	ldr	x0, [x9, x8, lsl #3]
1008463f4:     	cbz	x0, 0x100846880 <_js_json_stringify+0x654>
1008463f8:     	add	x8, x0, x20, lsl #3
1008463fc:     	ldr	x0, [x8, #0x1e8]
100846400:     	cbz	x0, 0x100846890 <_js_json_stringify+0x664>
100846404:     	str	xzr, [x0]
100846408:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
10084640c:     	add	x0, x0, #0xd90
100846410:     	ldr	x8, [x0]
100846414:     	blr	x8
100846418:     	ldrb	w8, [x0, #0x20]
10084641c:     	cbnz	w8, 0x10084691c <_js_json_stringify+0x6f0>
100846420:     	ldr	x8, [x0]
100846424:     	cbnz	x8, 0x100846944 <_js_json_stringify+0x718>
100846428:     	str	xzr, [x0, #0x18]
10084642c:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
100846430:     	add	x0, x0, #0xd30
100846434:     	ldr	x8, [x0]
100846438:     	blr	x8
10084643c:     	mov	x20, x0
100846440:     	ldrb	w8, [x0, #0x18]
100846444:     	cmp	w8, #0x1
100846448:     	b.ne	0x1008468a0 <_js_json_stringify+0x674>
10084644c:     	ldr	x8, [x0]
100846450:     	mov	x9, #-0x1               ; =-1
100846454:     	str	x9, [x0]
100846458:     	cmn	x8, #0x2
10084645c:     	b.eq	0x100846950 <_js_json_stringify+0x724>
100846460:     	cmn	x8, #0x1
100846464:     	b.eq	0x100846478 <_js_json_stringify+0x24c>
100846468:     	add	x9, sp, #0x8
10084646c:     	ldur	q0, [x0, #0x8]
100846470:     	stur	q0, [x9, #0x8]
100846474:     	b	0x100846484 <_js_json_stringify+0x258>
100846478:     	mov	x8, #0x0                ; =0
10084647c:     	mov	w9, #0x1                ; =1
100846480:     	stp	x9, xzr, [sp, #0x10]
100846484:     	str	x8, [sp, #0x8]
100846488:     	adrp	x0, 0x100f87000 <_theap_main+0x1f80>
10084648c:     	add	x0, x0, #0xd18
100846490:     	ldr	x8, [x0]
100846494:     	blr	x8
100846498:     	ldrb	w8, [x0, #0x20]
10084649c:     	cbnz	w8, 0x1008468d0 <_js_json_stringify+0x6a4>
1008464a0:     	ldr	x8, [x0]
1008464a4:     	cbnz	x8, 0x1008468f8 <_js_json_stringify+0x6cc>
1008464a8:     	str	xzr, [x0, #0x18]
1008464ac:     	add	x1, sp, #0x8
1008464b0:     	mov.16b	v0, v8
1008464b4:     	mov	x0, x21
1008464b8:     	bl	0x10050a07c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
1008464bc:     	ldp	x21, x22, [sp, #0x10]
1008464c0:     	cmp	w22, #0x80, lsl #12     ; =0x80000
1008464c4:     	b.hs	0x100846584 <_js_json_stringify+0x358>
1008464c8:     	cmp	x22, #0x40
1008464cc:     	b.hs	0x100846648 <_js_json_stringify+0x41c>
1008464d0:     	ands	x9, x22, #0x38
1008464d4:     	b.eq	0x1008464f8 <_js_json_stringify+0x2cc>
1008464d8:     	and	x8, x22, #0x38
1008464dc:     	neg	x8, x8
1008464e0:     	mov	x10, x21
1008464e4:     	ldr	x11, [x10], #0x8
1008464e8:     	tst	x11, #0x8080808080808080
1008464ec:     	b.ne	0x10084656c <_js_json_stringify+0x340>
1008464f0:     	adds	x8, x8, #0x8
1008464f4:     	b.ne	0x1008464e4 <_js_json_stringify+0x2b8>
1008464f8:     	and	x8, x22, #0x7
1008464fc:     	cbz	x8, 0x1008466cc <_js_json_stringify+0x4a0>
100846500:     	add	x9, x21, x9
100846504:     	ldrsb	w10, [x9]
100846508:     	tbnz	w10, #0x1f, 0x10084656c <_js_json_stringify+0x340>
10084650c:     	cmp	x8, #0x1
100846510:     	b.eq	0x1008466cc <_js_json_stringify+0x4a0>
100846514:     	ldrsb	w10, [x9, #0x1]
100846518:     	tbnz	w10, #0x1f, 0x10084656c <_js_json_stringify+0x340>
10084651c:     	cmp	x8, #0x2
100846520:     	b.eq	0x1008466cc <_js_json_stringify+0x4a0>
100846524:     	ldrsb	w10, [x9, #0x2]
100846528:     	tbnz	w10, #0x1f, 0x10084656c <_js_json_stringify+0x340>
10084652c:     	cmp	x8, #0x3
100846530:     	b.eq	0x1008466cc <_js_json_stringify+0x4a0>
100846534:     	ldrsb	w10, [x9, #0x3]
100846538:     	tbnz	w10, #0x1f, 0x10084656c <_js_json_stringify+0x340>
10084653c:     	cmp	x8, #0x4
100846540:     	b.eq	0x1008466cc <_js_json_stringify+0x4a0>
100846544:     	ldrsb	w10, [x9, #0x4]
100846548:     	tbnz	w10, #0x1f, 0x10084656c <_js_json_stringify+0x340>
10084654c:     	cmp	x8, #0x5
100846550:     	b.eq	0x1008466cc <_js_json_stringify+0x4a0>
100846554:     	ldrsb	w10, [x9, #0x5]
100846558:     	tbnz	w10, #0x1f, 0x10084656c <_js_json_stringify+0x340>
10084655c:     	cmp	x8, #0x6
100846560:     	b.eq	0x1008466cc <_js_json_stringify+0x4a0>
100846564:     	ldrsb	w8, [x9, #0x6]
100846568:     	tbz	w8, #0x1f, 0x1008466cc <_js_json_stringify+0x4a0>
10084656c:     	mov	x0, x21
100846570:     	mov	x1, x22
100846574:     	mov	x2, x22
100846578:     	bl	0x1008ddc00 <_js_string_from_bytes_with_capacity>
10084657c:     	mov	x23, x0
100846580:     	b	0x1008467c8 <_js_json_stringify+0x59c>
100846584:     	and	x8, x22, #0x7fffffffffffffc0
100846588:     	add	x8, x21, x8
10084658c:     	mov	x9, x21
100846590:     	ldp	q0, q1, [x9]
100846594:     	ldp	q2, q3, [x9, #0x20]
100846598:     	orr.16b	v0, v1, v0
10084659c:     	orr.16b	v1, v2, v3
1008465a0:     	orr.16b	v0, v0, v1
1008465a4:     	umaxv.16b	b0, v0
1008465a8:     	fmov	w10, s0
1008465ac:     	tbnz	w10, #0x7, 0x10084660c <_js_json_stringify+0x3e0>
1008465b0:     	add	x9, x9, #0x40
1008465b4:     	cmp	x9, x8
1008465b8:     	b.ne	0x100846590 <_js_json_stringify+0x364>
1008465bc:     	ands	x9, x22, #0x30
1008465c0:     	b.eq	0x1008465e4 <_js_json_stringify+0x3b8>
1008465c4:     	mov	x10, x9
1008465c8:     	mov	x11, x8
1008465cc:     	ldr	q0, [x11], #0x10
1008465d0:     	umaxv.16b	b0, v0
1008465d4:     	fmov	w12, s0
1008465d8:     	tbnz	w12, #0x7, 0x10084660c <_js_json_stringify+0x3e0>
1008465dc:     	subs	x10, x10, #0x10
1008465e0:     	b.ne	0x1008465cc <_js_json_stringify+0x3a0>
1008465e4:     	and	x10, x22, #0xf
1008465e8:     	cbz	x10, 0x100846604 <_js_json_stringify+0x3d8>
1008465ec:     	add	x8, x8, x9
1008465f0:     	ldrsb	w9, [x8]
1008465f4:     	tbnz	w9, #0x1f, 0x10084660c <_js_json_stringify+0x3e0>
1008465f8:     	add	x8, x8, #0x1
1008465fc:     	subs	x10, x10, #0x1
100846600:     	b.ne	0x1008465f0 <_js_json_stringify+0x3c4>
100846604:     	mov	w24, w22
100846608:     	b	0x100846640 <_js_json_stringify+0x414>
10084660c:     	mov	w24, w22
100846610:     	cbz	x24, 0x100846640 <_js_json_stringify+0x414>
100846614:     	mov	x8, x21
100846618:     	ands	x9, x22, #0x3
10084661c:     	b.eq	0x100846638 <_js_json_stringify+0x40c>
100846620:     	mov	x8, x21
100846624:     	ldrsb	w10, [x8]
100846628:     	tbnz	w10, #0x1f, 0x100846730 <_js_json_stringify+0x504>
10084662c:     	add	x8, x8, #0x1
100846630:     	subs	x9, x9, #0x1
100846634:     	b.ne	0x100846624 <_js_json_stringify+0x3f8>
100846638:     	cmp	x24, #0x4
10084663c:     	b.hs	0x1008466fc <_js_json_stringify+0x4d0>
100846640:     	mov	x25, x22
100846644:     	b	0x100846740 <_js_json_stringify+0x514>
100846648:     	and	x8, x22, #0x7fffffffffffffc0
10084664c:     	and	x8, x8, #0xffffffff0007ffff
100846650:     	add	x8, x21, x8
100846654:     	mov	x9, x21
100846658:     	ldp	q0, q1, [x9]
10084665c:     	ldp	q2, q3, [x9, #0x20]
100846660:     	orr.16b	v0, v1, v0
100846664:     	orr.16b	v1, v2, v3
100846668:     	orr.16b	v0, v0, v1
10084666c:     	umaxv.16b	b0, v0
100846670:     	fmov	w10, s0
100846674:     	tbnz	w10, #0x7, 0x10084656c <_js_json_stringify+0x340>
100846678:     	add	x9, x9, #0x40
10084667c:     	cmp	x9, x8
100846680:     	b.ne	0x100846658 <_js_json_stringify+0x42c>
100846684:     	ands	x9, x22, #0x30
100846688:     	b.eq	0x1008466ac <_js_json_stringify+0x480>
10084668c:     	mov	x10, x9
100846690:     	mov	x11, x8
100846694:     	ldr	q0, [x11], #0x10
100846698:     	umaxv.16b	b0, v0
10084669c:     	fmov	w12, s0
1008466a0:     	tbnz	w12, #0x7, 0x10084656c <_js_json_stringify+0x340>
1008466a4:     	subs	x10, x10, #0x10
1008466a8:     	b.ne	0x100846694 <_js_json_stringify+0x468>
1008466ac:     	and	x10, x22, #0xf
1008466b0:     	cbz	x10, 0x1008466cc <_js_json_stringify+0x4a0>
1008466b4:     	add	x8, x8, x9
1008466b8:     	ldrsb	w9, [x8]
1008466bc:     	tbnz	w9, #0x1f, 0x10084656c <_js_json_stringify+0x340>
1008466c0:     	add	x8, x8, #0x1
1008466c4:     	subs	x10, x10, #0x1
1008466c8:     	b.ne	0x1008466b8 <_js_json_stringify+0x48c>
1008466cc:     	mov	x0, x22
1008466d0:     	bl	0x10034be6c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1008466d4:     	mov	x23, x0
1008466d8:     	stp	w22, w22, [x0]
1008466dc:     	stp	wzr, wzr, [x0, #0xc]
1008466e0:     	str	w22, [x0, #0x8]
1008466e4:     	cbz	w22, 0x1008467c8 <_js_json_stringify+0x59c>
1008466e8:     	and	x2, x22, #0x7ffff
1008466ec:     	mov	x0, x1
1008466f0:     	mov	x1, x21
1008466f4:     	bl	0x100b632ac <_writev+0x100b632ac>
1008466f8:     	b	0x1008467c8 <_js_json_stringify+0x59c>
1008466fc:     	add	x9, x21, x24
100846700:     	ldrsb	w10, [x8]
100846704:     	tbnz	w10, #0x1f, 0x100846730 <_js_json_stringify+0x504>
100846708:     	ldrsb	w10, [x8, #0x1]
10084670c:     	tbnz	w10, #0x1f, 0x100846730 <_js_json_stringify+0x504>
100846710:     	ldrsb	w10, [x8, #0x2]
100846714:     	tbnz	w10, #0x1f, 0x100846730 <_js_json_stringify+0x504>
100846718:     	ldrsb	w10, [x8, #0x3]
10084671c:     	tbnz	w10, #0x1f, 0x100846730 <_js_json_stringify+0x504>
100846720:     	add	x8, x8, #0x4
100846724:     	cmp	x8, x9
100846728:     	b.ne	0x100846700 <_js_json_stringify+0x4d4>
10084672c:     	b	0x100846640 <_js_json_stringify+0x414>
100846730:     	mov	w1, w22
100846734:     	mov	x0, x21
100846738:     	bl	0x1005eb420 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string11utf16_count11count_bytes>
10084673c:     	mov	x25, x0
100846740:     	bl	0x1004f0bc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat34service_json_output_sweep_boundary>
100846744:     	add	x0, x24, #0x14
100846748:     	mov	w1, #0x3                ; =3
10084674c:     	bl	0x100459040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6malloc9gc_malloc>
100846750:     	mov	x23, x0
100846754:     	stp	w25, w22, [x0]
100846758:     	stp	wzr, wzr, [x0, #0xc]
10084675c:     	str	w22, [x0, #0x8]
100846760:     	add	x0, x0, #0x14
100846764:     	mov	x1, x21
100846768:     	mov	x2, x24
10084676c:     	bl	0x100b632ac <_writev+0x100b632ac>
100846770:     	adrp	x8, 0x100f82000 <__MergedGlobals.1917+0xc8>
100846774:     	ldr	w21, [x8, #0x590]
100846778:     	cmp	w21, #0x300
10084677c:     	b.hs	0x100846858 <_js_json_stringify+0x62c>
100846780:     	adrp	x8, 0x100f80000 <_perry_global_worker_ts__1>
100846784:     	ldr	x8, [x8, #0x48]
100846788:     	cmn	x8, #0x1
10084678c:     	b.eq	0x100846848 <_js_json_stringify+0x61c>
100846790:     	mrs	x9, TPIDRRO_EL0
100846794:     	and	x9, x9, #0xfffffffffffffff8
100846798:     	ldr	x0, [x9, x8, lsl #3]
10084679c:     	cbz	x0, 0x100846848 <_js_json_stringify+0x61c>
1008467a0:     	add	x8, x0, x21, lsl #3
1008467a4:     	ldr	x0, [x8, #0x1e8]
1008467a8:     	cbz	x0, 0x100846858 <_js_json_stringify+0x62c>
1008467ac:     	ldr	x8, [x0]
1008467b0:     	adds	x8, x8, x24
1008467b4:     	csinv	x8, x8, xzr, lo
1008467b8:     	str	x8, [x0]
1008467bc:     	lsr	x8, x8, #25
1008467c0:     	cbz	x8, 0x1008467c8 <_js_json_stringify+0x59c>
1008467c4:     	bl	0x10045ff74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc6policy42gc_schedule_malloc_sweep_after_json_output>
1008467c8:     	ldp	x22, x21, [sp, #0x8]
1008467cc:     	ldrb	w8, [x20, #0x18]
1008467d0:     	cmp	w8, #0x1
1008467d4:     	b.ne	0x1008468b0 <_js_json_stringify+0x684>
1008467d8:     	ldp	x8, x0, [x20]
1008467dc:     	stp	x22, x21, [x20]
1008467e0:     	str	xzr, [x20, #0x10]
1008467e4:     	sub	x8, x8, #0x1
1008467e8:     	cmn	x8, #0x2
1008467ec:     	b.hs	0x1008467f4 <_js_json_stringify+0x5c8>
1008467f0:     	bl	0x100b60400 <_mi_free>
1008467f4:     	cbz	w26, 0x100846800 <_js_json_stringify+0x5d4>
1008467f8:     	bl	0x100328da8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
1008467fc:     	b	0x100846804 <_js_json_stringify+0x5d8>
100846800:     	bl	0x100328bd8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100846804:     	ldr	w8, [x19]
100846808:     	sub	w8, w8, #0x1
10084680c:     	str	w8, [x19]
100846810:     	mov	x0, x23
100846814:     	ldp	x29, x30, [sp, #0x70]
100846818:     	ldp	x20, x19, [sp, #0x60]
10084681c:     	ldp	x22, x21, [sp, #0x50]
100846820:     	ldp	x24, x23, [sp, #0x40]
100846824:     	ldp	x26, x25, [sp, #0x30]
100846828:     	ldp	d9, d8, [sp, #0x20]
10084682c:     	add	sp, sp, #0x80
100846830:     	ret
100846834:     	mov	x22, x0
100846838:     	add	x0, x0, #0x8
10084683c:     	bl	0x100b3d150 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100846840:     	mov	x0, x22
100846844:     	b	0x100846370 <_js_json_stringify+0x144>
100846848:     	bl	0x100b407fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
10084684c:     	add	x8, x0, x21, lsl #3
100846850:     	ldr	x0, [x8, #0x1e8]
100846854:     	cbnz	x0, 0x1008467ac <_js_json_stringify+0x580>
100846858:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
10084685c:     	add	x0, x0, #0x78
100846860:     	bl	0x100b3e01c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100846864:     	ldr	x8, [x0]
100846868:     	adds	x8, x8, x24
10084686c:     	csinv	x8, x8, xzr, lo
100846870:     	str	x8, [x0]
100846874:     	lsr	x8, x8, #25
100846878:     	cbnz	x8, 0x1008467c4 <_js_json_stringify+0x598>
10084687c:     	b	0x1008467c8 <_js_json_stringify+0x59c>
100846880:     	bl	0x100b407fc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100846884:     	add	x8, x0, x20, lsl #3
100846888:     	ldr	x0, [x8, #0x1e8]
10084688c:     	cbnz	x0, 0x100846404 <_js_json_stringify+0x1d8>
100846890:     	adrp	x0, 0x100f10000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE+0x48>
100846894:     	add	x0, x0, #0x138
100846898:     	bl	0x100b3e01c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
10084689c:     	b	0x100846404 <_js_json_stringify+0x1d8>
1008468a0:     	mov	x0, x20
1008468a4:     	bl	0x100b1f984 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008468a8:     	cbnz	x0, 0x10084644c <_js_json_stringify+0x220>
1008468ac:     	b	0x100846950 <_js_json_stringify+0x724>
1008468b0:     	mov	x0, x20
1008468b4:     	bl	0x100b1f984 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
1008468b8:     	mov	x20, x0
1008468bc:     	cbnz	x0, 0x1008467d8 <_js_json_stringify+0x5ac>
1008468c0:     	cbz	x22, 0x100846950 <_js_json_stringify+0x724>
1008468c4:     	mov	x0, x21
1008468c8:     	bl	0x100b60400 <_mi_free>
1008468cc:     	b	0x100846950 <_js_json_stringify+0x724>
1008468d0:     	cmp	w8, #0x2
1008468d4:     	b.eq	0x100846950 <_js_json_stringify+0x724>
1008468d8:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
1008468dc:     	add	x1, x1, #0xff8
1008468e0:     	mov	x22, x0
1008468e4:     	bl	0x100a2185c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008468e8:     	mov	x0, x22
1008468ec:     	strb	wzr, [x22, #0x20]
1008468f0:     	ldr	x8, [x22]
1008468f4:     	cbz	x8, 0x1008464a8 <_js_json_stringify+0x27c>
1008468f8:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008468fc:     	add	x0, x0, #0xdb8
100846900:     	bl	0x100b13b2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100846904:     	bl	0x100b1fae4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100846908:     	cbnz	x0, 0x100846350 <_js_json_stringify+0x124>
10084690c:     	b	0x100846950 <_js_json_stringify+0x724>
100846910:     	adrp	x0, 0x100efa000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100846914:     	add	x0, x0, #0x440
100846918:     	bl	0x100b13b2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
10084691c:     	cmp	w8, #0x1
100846920:     	b.ne	0x100846950 <_js_json_stringify+0x724>
100846924:     	adrp	x1, 0x100193000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCs3gRpqoBkMHm_13perry_runtime7tls_hot7HotCellINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtNtB1a_7promise11keyed_table17PromiseKeyedTableNtNtB2z_11combinators15PromiseAllStateEEKj1_EEB1a_+0x118>
100846928:     	add	x1, x1, #0x998
10084692c:     	mov	x20, x0
100846930:     	bl	0x100a2185c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100846934:     	mov	x0, x20
100846938:     	strb	wzr, [x20, #0x20]
10084693c:     	ldr	x8, [x20]
100846940:     	cbz	x8, 0x100846428 <_js_json_stringify+0x1fc>
100846944:     	adrp	x0, 0x100efd000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100846948:     	add	x0, x0, #0xd88
10084694c:     	bl	0x100b13b2c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100846950:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100846954:     	add	x0, x0, #0xc18
100846958:     	bl	0x100b59a5c <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
		...
