
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/isolated-json-scan-chunks-r36/candidate-rotating-worker:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100243a68 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value>:
100243a68:     	sub	sp, sp, #0x60
100243a6c:     	stp	x24, x23, [sp, #0x20]
100243a70:     	stp	x22, x21, [sp, #0x30]
100243a74:     	stp	x20, x19, [sp, #0x40]
100243a78:     	stp	x29, x30, [sp, #0x50]
100243a7c:     	add	x29, sp, #0x50
100243a80:     	mov	x21, x0
100243a84:     	ldr	x23, [x0, #0x70]
100243a88:     	ldp	x8, x9, [x0]
100243a8c:     	cmp	x8, #0x0
100243a90:     	ccmp	x9, x23, #0x0, ne
100243a94:     	b.eq	0x100243ac0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x58>
100243a98:     	add	x0, sp, #0x8
100243a9c:     	mov	x1, x21
100243aa0:     	bl	0x1002434f8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_bytes>
100243aa4:     	ldr	x22, [sp, #0x8]
100243aa8:     	cmn	x22, #0x2
100243aac:     	b.ne	0x100243ae8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x80>
100243ab0:     	strb	wzr, [x21, #0xd4]
100243ab4:     	mov	x0, #0x2                ; =2
100243ab8:     	movk	x0, #0x7ffc, lsl #48
100243abc:     	b	0x100243ad0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100243ac0:     	ldp	x8, x9, [x21, #0x10]
100243ac4:     	str	x8, [x21, #0x70]
100243ac8:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100243acc:     	bfxil	x0, x9, #0, #48
100243ad0:     	ldp	x29, x30, [sp, #0x50]
100243ad4:     	ldp	x20, x19, [sp, #0x40]
100243ad8:     	ldp	x22, x21, [sp, #0x30]
100243adc:     	ldp	x24, x23, [sp, #0x20]
100243ae0:     	add	sp, sp, #0x60
100243ae4:     	ret
100243ae8:     	ldp	x20, x19, [sp, #0x10]
100243aec:     	cmp	x19, #0x6
100243af0:     	b.hs	0x100243b80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100243af4:     	subs	x8, x19, #0x3
100243af8:     	b.lo	0x100243bac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100243afc:     	ldrb	w9, [x20]
100243b00:     	cmp	w9, #0xed
100243b04:     	b.ne	0x100243b24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xbc>
100243b08:     	ldrb	w9, [x20, #0x1]
100243b0c:     	and	w9, w9, #0xe0
100243b10:     	cmp	w9, #0xa0
100243b14:     	b.ne	0x100243b24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xbc>
100243b18:     	ldrsb	w9, [x20, #0x2]
100243b1c:     	cmn	w9, #0x40
100243b20:     	b.lt	0x100243b80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100243b24:     	cbz	x8, 0x100243bac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100243b28:     	ldrb	w9, [x20, #0x1]
100243b2c:     	cmp	w9, #0xed
100243b30:     	b.ne	0x100243b50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xe8>
100243b34:     	ldrb	w9, [x20, #0x2]
100243b38:     	and	w9, w9, #0xe0
100243b3c:     	cmp	w9, #0xa0
100243b40:     	b.ne	0x100243b50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0xe8>
100243b44:     	ldrsb	w9, [x20, #0x3]
100243b48:     	cmn	w9, #0x40
100243b4c:     	b.lt	0x100243b80 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x118>
100243b50:     	cmp	x8, #0x1
100243b54:     	b.eq	0x100243bac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100243b58:     	ldrb	w8, [x20, #0x2]
100243b5c:     	cmp	w8, #0xed
100243b60:     	b.ne	0x100243bac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100243b64:     	ldrb	w8, [x20, #0x3]
100243b68:     	and	w8, w8, #0xe0
100243b6c:     	cmp	w8, #0xa0
100243b70:     	b.ne	0x100243bac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100243b74:     	ldrsb	w8, [x20, #0x4]
100243b78:     	cmn	w8, #0x40
100243b7c:     	b.ge	0x100243bac <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x144>
100243b80:     	cmn	x22, #0x1
100243b84:     	b.eq	0x100243bc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x160>
100243b88:     	mov	x0, x20
100243b8c:     	mov	x1, x19
100243b90:     	bl	0x10034a030 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string28js_string_from_builder_bytes>
100243b94:     	mov	x8, x0
100243b98:     	mov	x0, #0x7fff000000000000 ; =9223090561878065152
100243b9c:     	bfxil	x0, x8, #0, #48
100243ba0:     	cmp	x22, #0x1
100243ba4:     	b.ge	0x100243d58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2f0>
100243ba8:     	b	0x100243ad0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100243bac:     	cbz	x19, 0x100243c8c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x224>
100243bb0:     	cmp	x19, #0x4
100243bb4:     	b.hs	0x100243c94 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x22c>
100243bb8:     	mov	x10, #0x0               ; =0
100243bbc:     	mov	x9, #0x0                ; =0
100243bc0:     	mov	x8, x20
100243bc4:     	b	0x100243d24 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2bc>
100243bc8:     	add	x0, x21, #0x20
100243bcc:     	mov	x1, x20
100243bd0:     	mov	x2, x19
100243bd4:     	bl	0x1005e9584 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6string17json_construction30string_from_scanned_json_bytes>
100243bd8:     	ldr	x22, [x21, #0x68]
100243bdc:     	cmp	x22, #0x200, lsl #12    ; =0x200000
100243be0:     	b.hi	0x100243dcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100243be4:     	cmp	x19, #0x100
100243be8:     	b.lo	0x100243dcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100243bec:     	cbz	x0, 0x100243dcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100243bf0:     	ldr	x20, [x21, #0xc8]
100243bf4:     	cbz	x20, 0x100243dcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100243bf8:     	ldr	x21, [x21, #0x70]
100243bfc:     	sub	x8, x22, x22, lsr #1
100243c00:     	cmp	x19, x8
100243c04:     	orr	x8, x21, x23
100243c08:     	and	x8, x8, #0xffffffff00000000
100243c0c:     	ccmp	x8, #0x0, #0x0, hs
100243c10:     	b.ne	0x100243dcc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x364>
100243c14:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100243c18:     	ldr	w19, [x8, #0x560]
100243c1c:     	cmp	w19, #0x300
100243c20:     	b.hs	0x100243df8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x390>
100243c24:     	adrp	x8, 0x100f7c000 <_perry_global_rotating_worker_ts__1>
100243c28:     	ldr	x8, [x8, #0x48]
100243c2c:     	cmn	x8, #0x1
100243c30:     	b.eq	0x100243ddc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x374>
100243c34:     	mrs	x9, TPIDRRO_EL0
100243c38:     	and	x9, x9, #0xfffffffffffffff8
100243c3c:     	ldr	x8, [x9, x8, lsl #3]
100243c40:     	cbz	x8, 0x100243ddc <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x374>
100243c44:     	add	x8, x8, x19, lsl #3
100243c48:     	ldr	x19, [x8, #0x1e8]
100243c4c:     	cbz	x19, 0x100243df8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x390>
100243c50:     	ldr	x8, [x19]
100243c54:     	cbnz	x8, 0x100243e18 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x3b0>
100243c58:     	mov	x8, #-0x1               ; =-1
100243c5c:     	str	x8, [x19]
100243c60:     	ldrb	w8, [x19, #0x24]
100243c64:     	cmp	w8, #0x2
100243c68:     	b.eq	0x100243d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100243c6c:     	ldr	x8, [x19, #0x8]
100243c70:     	cmp	x8, x20
100243c74:     	b.ne	0x100243d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100243c78:     	ldr	w8, [x19, #0x18]
100243c7c:     	cmp	w8, w22
100243c80:     	b.ne	0x100243d6c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x304>
100243c84:     	mov	x8, #0x0                ; =0
100243c88:     	b	0x100243dc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x360>
100243c8c:     	mov	x10, #0x0               ; =0
100243c90:     	b	0x100243d44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2dc>
100243c94:     	and	x9, x19, #0x4
100243c98:     	add	x8, x20, x9
100243c9c:     	adrp	x10, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x4bb0>
100243ca0:     	ldr	q0, [x10, #0xcc0]
100243ca4:     	adrp	x10, 0x100c38000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x333ba>
100243ca8:     	ldr	q2, [x10, #0xbc0]
100243cac:     	movi.2d	v1, #0000000000000000
100243cb0:     	movi.2d	v3, #0x000000000000ff
100243cb4:     	mov	w10, #0x4               ; =4
100243cb8:     	dup.2d	v4, x10
100243cbc:     	mov	x10, x20
100243cc0:     	and	x11, x19, #0x4
100243cc4:     	movi.2d	v5, #0000000000000000
100243cc8:     	ldr	s6, [x10], #0x4
100243ccc:     	ushll.8h	v6, v6, #0x0
100243cd0:     	ushll.4s	v6, v6, #0x0
100243cd4:     	ushll2.2d	v7, v6, #0x0
100243cd8:     	and.16b	v7, v7, v3
100243cdc:     	ushll.2d	v6, v6, #0x0
100243ce0:     	and.16b	v6, v6, v3
100243ce4:     	shl.2d	v16, v0, #0x3
100243ce8:     	shl.2d	v17, v2, #0x3
100243cec:     	ushl.2d	v6, v6, v17
100243cf0:     	ushl.2d	v7, v7, v16
100243cf4:     	orr.16b	v1, v7, v1
100243cf8:     	orr.16b	v5, v6, v5
100243cfc:     	add.2d	v0, v0, v4
100243d00:     	add.2d	v2, v2, v4
100243d04:     	subs	x11, x11, #0x4
100243d08:     	b.ne	0x100243cc8 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x260>
100243d0c:     	orr.16b	v0, v5, v1
100243d10:     	mov	d1, v0[1]
100243d14:     	orr.8b	v0, v0, v1
100243d18:     	fmov	x10, d0
100243d1c:     	cmp	x19, x9
100243d20:     	b.eq	0x100243d44 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2dc>
100243d24:     	add	x11, x20, x19
100243d28:     	lsl	x9, x9, #3
100243d2c:     	ldrb	w12, [x8], #0x1
100243d30:     	lsl	x12, x12, x9
100243d34:     	orr	x10, x12, x10
100243d38:     	add	x9, x9, #0x8
100243d3c:     	cmp	x8, x11
100243d40:     	b.ne	0x100243d2c <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x2c4>
100243d44:     	orr	x8, x10, x19, lsl #40
100243d48:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100243d4c:     	orr	x0, x8, x9
100243d50:     	cmp	x22, #0x1
100243d54:     	b.lt	0x100243ad0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100243d58:     	mov	x19, x0
100243d5c:     	mov	x0, x20
100243d60:     	bl	0x100b5e240 <_mi_free>
100243d64:     	mov	x0, x19
100243d68:     	b	0x100243ad0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100243d6c:     	stp	x20, x0, [x19, #0x8]
100243d70:     	stp	w22, w23, [x19, #0x18]
100243d74:     	str	w21, [x19, #0x20]
100243d78:     	strb	wzr, [x19, #0x24]
100243d7c:     	adrp	x21, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf85c>
100243d80:     	ldr	w8, [x21, #0x7a4]
100243d84:     	cbz	w8, 0x100243da0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x338>
100243d88:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100243d8c:     	bfxil	x8, x20, #0, #48
100243d90:     	mov	x20, x0
100243d94:     	mov	x0, x8
100243d98:     	bl	0x100474f70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
100243d9c:     	mov	x0, x20
100243da0:     	ldr	w8, [x21, #0x7a4]
100243da4:     	cbz	w8, 0x100243dc0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x358>
100243da8:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100243dac:     	bfxil	x8, x0, #0, #48
100243db0:     	mov	x20, x0
100243db4:     	mov	x0, x8
100243db8:     	bl	0x100474f70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2gc7barrier37incremental_mark_barrier_value_active>
100243dbc:     	mov	x0, x20
100243dc0:     	ldr	x8, [x19]
100243dc4:     	add	x8, x8, #0x1
100243dc8:     	str	x8, [x19]
100243dcc:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100243dd0:     	bfxil	x8, x0, #0, #48
100243dd4:     	mov	x0, x8
100243dd8:     	b	0x100243ad0 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x68>
100243ddc:     	mov	x24, x0
100243de0:     	bl	0x100b3e63c <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100243de4:     	mov	x8, x0
100243de8:     	mov	x0, x24
100243dec:     	add	x8, x8, x19, lsl #3
100243df0:     	ldr	x19, [x8, #0x1e8]
100243df4:     	cbnz	x19, 0x100243c50 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1e8>
100243df8:     	str	x0, [sp]
100243dfc:     	adrp	x0, 0x100f0b000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime2os18os_process_emitter26PROCESS_EXIT_EVENT_EMITTED+0x1eb8>
100243e00:     	add	x0, x0, #0xfa0
100243e04:     	bl	0x100b3be5c <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100243e08:     	mov	x19, x0
100243e0c:     	ldr	x0, [sp]
100243e10:     	ldr	x8, [x19]
100243e14:     	cbz	x8, 0x100243c58 <__RNvMs0_NtNtCs3gRpqoBkMHm_13perry_runtime4json6parserNtB5_12DirectParser18parse_string_value+0x1f0>
100243e18:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100243e1c:     	add	x0, x0, #0xce0
100243e20:     	bl	0x100b1196c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
		...
