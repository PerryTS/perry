
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/inert-spacer-inline-r10/candidate-options:	file format mach-o arm64

Disassembly of section __TEXT,__text:

00000001004ee840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer>:
1004ee840:     	sub	sp, sp, #0x80
1004ee844:     	stp	d9, d8, [sp, #0x40]
1004ee848:     	stp	x22, x21, [sp, #0x50]
1004ee84c:     	stp	x20, x19, [sp, #0x60]
1004ee850:     	stp	x29, x30, [sp, #0x70]
1004ee854:     	add	x29, sp, #0x70
1004ee858:     	mov	x8, #-0x8000000000000000 ; =-9223372036854775808
1004ee85c:     	cmp	x1, x8
1004ee860:     	b.eq	0x1004ee878 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x38>
1004ee864:     	mov	x8, #0x4                ; =4
1004ee868:     	movk	x8, #0x7ffc, lsl #48
1004ee86c:     	cmp	x1, x8
1004ee870:     	b.eq	0x1004ee878 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x38>
1004ee874:     	cbnz	x1, 0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004ee878:     	mov	x8, #-0x2               ; =-2
1004ee87c:     	movk	x8, #0x8003, lsl #48
1004ee880:     	add	x8, x0, x8
1004ee884:     	cmp	x8, #0x3
1004ee888:     	b.hs	0x1004ee8a0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x60>
1004ee88c:     	adrp	x9, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5460>
1004ee890:     	add	x9, x9, #0x128
1004ee894:     	ldr	x1, [x9, x8, lsl #3]
1004ee898:     	mov	w0, #0x1                ; =1
1004ee89c:     	b	0x1004eede8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a8>
1004ee8a0:     	strb	wzr, [sp, #0x38]
1004ee8a4:     	str	wzr, [sp, #0x34]
1004ee8a8:     	and	x8, x0, #0xffff000000000000
1004ee8ac:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
1004ee8b0:     	cmp	x8, x9
1004ee8b4:     	b.eq	0x1004ee928 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0xe8>
1004ee8b8:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1004ee8bc:     	cmp	x8, x9
1004ee8c0:     	b.ne	0x1004eed1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4dc>
1004ee8c4:     	ubfx	x10, x0, #40, #8
1004ee8c8:     	cbz	x10, 0x1004ee918 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0xd8>
1004ee8cc:     	strb	w0, [sp, #0x34]
1004ee8d0:     	cmp	x10, #0x1
1004ee8d4:     	b.eq	0x1004ee918 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0xd8>
1004ee8d8:     	lsr	x9, x0, #8
1004ee8dc:     	strb	w9, [sp, #0x35]
1004ee8e0:     	cmp	x10, #0x2
1004ee8e4:     	b.eq	0x1004ee918 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0xd8>
1004ee8e8:     	lsr	x9, x0, #16
1004ee8ec:     	strb	w9, [sp, #0x36]
1004ee8f0:     	cmp	x10, #0x3
1004ee8f4:     	b.eq	0x1004ee918 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0xd8>
1004ee8f8:     	lsr	x9, x0, #24
1004ee8fc:     	strb	w9, [sp, #0x37]
1004ee900:     	cmp	x10, #0x4
1004ee904:     	b.eq	0x1004ee918 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0xd8>
1004ee908:     	lsr	x9, x0, #32
1004ee90c:     	strb	w9, [sp, #0x38]
1004ee910:     	cmp	x10, #0x5
1004ee914:     	b.ne	0x1004ef0b4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x874>
1004ee918:     	add	x12, sp, #0x34
1004ee91c:     	cmp	w10, #0x3
1004ee920:     	b.ls	0x1004ee940 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x100>
1004ee924:     	b	0x1004eed1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4dc>
1004ee928:     	ands	x9, x0, #0xffffffffffff
1004ee92c:     	b.eq	0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004ee930:     	add	x12, x9, #0x14
1004ee934:     	ldr	w10, [x9, #0x4]
1004ee938:     	cmp	w10, #0x3
1004ee93c:     	b.hi	0x1004eed1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4dc>
1004ee940:     	stur	wzr, [x29, #-0x34]
1004ee944:     	mov	w9, #0x22               ; =34
1004ee948:     	sturb	w9, [x29, #-0x35]
1004ee94c:     	cbz	w10, 0x1004ee984 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x144>
1004ee950:     	sub	x11, x29, #0x35
1004ee954:     	ldrb	w13, [x12]
1004ee958:     	sxtb	w15, w13
1004ee95c:     	cmp	w13, #0xb
1004ee960:     	b.le	0x1004ee98c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x14c>
1004ee964:     	cmp	w13, #0x21
1004ee968:     	b.gt	0x1004ee9ac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x16c>
1004ee96c:     	cmp	w13, #0xc
1004ee970:     	b.eq	0x1004ee9e0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1a0>
1004ee974:     	cmp	w13, #0xd
1004ee978:     	b.ne	0x1004ee9bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x17c>
1004ee97c:     	mov	w15, #0x72              ; =114
1004ee980:     	b	0x1004ee9ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1ac>
1004ee984:     	mov	w11, #0x1               ; =1
1004ee988:     	b	0x1004eea14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1d4>
1004ee98c:     	cmp	w13, #0x8
1004ee990:     	b.eq	0x1004ee9d8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x198>
1004ee994:     	cmp	w13, #0x9
1004ee998:     	b.eq	0x1004ee9e8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1a8>
1004ee99c:     	cmp	w13, #0xa
1004ee9a0:     	b.ne	0x1004ee9bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x17c>
1004ee9a4:     	mov	w15, #0x6e              ; =110
1004ee9a8:     	b	0x1004ee9ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1ac>
1004ee9ac:     	cmp	w13, #0x22
1004ee9b0:     	b.eq	0x1004ee9ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1ac>
1004ee9b4:     	cmp	w13, #0x5c
1004ee9b8:     	b.eq	0x1004ee9ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1ac>
1004ee9bc:     	cmp	w15, #0x20
1004ee9c0:     	b.lt	0x1004eed1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4dc>
1004ee9c4:     	mov	w14, #0x0               ; =0
1004ee9c8:     	add	x13, x11, #0x2
1004ee9cc:     	mov	w11, #0x2               ; =2
1004ee9d0:     	mov	w16, #0x1               ; =1
1004ee9d4:     	b	0x1004eea04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1c4>
1004ee9d8:     	mov	w15, #0x62              ; =98
1004ee9dc:     	b	0x1004ee9ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1ac>
1004ee9e0:     	mov	w15, #0x66              ; =102
1004ee9e4:     	b	0x1004ee9ec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1ac>
1004ee9e8:     	mov	w15, #0x74              ; =116
1004ee9ec:     	add	x13, x11, #0x3
1004ee9f0:     	mov	w11, #0x5c              ; =92
1004ee9f4:     	sturb	w11, [x29, #-0x34]
1004ee9f8:     	mov	w14, #0x1               ; =1
1004ee9fc:     	mov	w11, #0x3               ; =3
1004eea00:     	mov	w16, #0x2               ; =2
1004eea04:     	sub	x17, x29, #0x35
1004eea08:     	strb	w15, [x17, x16]
1004eea0c:     	cmp	w10, #0x1
1004eea10:     	b.ne	0x1004eea54 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x214>
1004eea14:     	sub	x10, x29, #0x35
1004eea18:     	strb	w9, [x10, x11]
1004eea1c:     	add	x8, x11, #0x1
1004eea20:     	cmp	x11, #0x3
1004eea24:     	b.hs	0x1004eea38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1f8>
1004eea28:     	mov	x15, #0x0               ; =0
1004eea2c:     	mov	x11, #0x0               ; =0
1004eea30:     	sub	x9, x29, #0x35
1004eea34:     	b	0x1004eec8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x44c>
1004eea38:     	adrp	x13, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5460>
1004eea3c:     	adrp	x12, 0x100c37000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33c6a>
1004eea40:     	cmp	x11, #0xf
1004eea44:     	b.hs	0x1004eea84 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x244>
1004eea48:     	mov	x11, #0x0               ; =0
1004eea4c:     	mov	x15, #0x0               ; =0
1004eea50:     	b	0x1004eebf0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x3b0>
1004eea54:     	ldrb	w16, [x12, #0x1]
1004eea58:     	sxtb	w15, w16
1004eea5c:     	cmp	w16, #0xb
1004eea60:     	b.le	0x1004eecbc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x47c>
1004eea64:     	cmp	w16, #0x21
1004eea68:     	b.gt	0x1004eecdc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x49c>
1004eea6c:     	cmp	w16, #0xc
1004eea70:     	b.eq	0x1004eed0c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4cc>
1004eea74:     	cmp	w16, #0xd
1004eea78:     	b.ne	0x1004eecec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4ac>
1004eea7c:     	mov	w15, #0x72              ; =114
1004eea80:     	b	0x1004eed18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4d8>
1004eea84:     	and	x14, x8, #0xc
1004eea88:     	and	x11, x8, #0x10
1004eea8c:     	sub	x15, x29, #0x35
1004eea90:     	add	x9, x15, x11
1004eea94:     	adrp	x16, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6460>
1004eea98:     	ldr	q0, [x16, #0x2a0]
1004eea9c:     	adrp	x16, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6460>
1004eeaa0:     	ldr	q1, [x16, #0x2b0]
1004eeaa4:     	adrp	x16, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6460>
1004eeaa8:     	ldr	q2, [x16, #0x2c0]
1004eeaac:     	adrp	x16, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6460>
1004eeab0:     	ldr	q3, [x16, #0x2d0]
1004eeab4:     	adrp	x16, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6460>
1004eeab8:     	ldr	q4, [x16, #0x2e0]
1004eeabc:     	movi.2d	v5, #0000000000000000
1004eeac0:     	adrp	x16, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6460>
1004eeac4:     	ldr	q6, [x16, #0x2f0]
1004eeac8:     	mov	w16, #0x10              ; =16
1004eeacc:     	dup.2d	v7, x16
1004eead0:     	and	x16, x8, #0x10
1004eead4:     	movi.2d	v16, #0000000000000000
1004eead8:     	ldr	q19, [x13, #0x410]
1004eeadc:     	movi.2d	v18, #0000000000000000
1004eeae0:     	movi.2d	v17, #0000000000000000
1004eeae4:     	ldr	q23, [x12, #0x310]
1004eeae8:     	movi.2d	v22, #0000000000000000
1004eeaec:     	movi.2d	v20, #0000000000000000
1004eeaf0:     	movi.2d	v24, #0000000000000000
1004eeaf4:     	movi.2d	v21, #0000000000000000
1004eeaf8:     	ldr	q25, [x15], #0x10
1004eeafc:     	ushll.8h	v26, v25, #0x0
1004eeb00:     	ushll2.4s	v27, v26, #0x0
1004eeb04:     	ushll2.2d	v28, v27, #0x0
1004eeb08:     	ushll2.8h	v25, v25, #0x0
1004eeb0c:     	ushll.4s	v29, v25, #0x0
1004eeb10:     	ushll2.2d	v30, v29, #0x0
1004eeb14:     	ushll.2d	v29, v29, #0x0
1004eeb18:     	ushll.2d	v27, v27, #0x0
1004eeb1c:     	ushll.4s	v26, v26, #0x0
1004eeb20:     	ushll2.2d	v31, v26, #0x0
1004eeb24:     	ushll2.4s	v25, v25, #0x0
1004eeb28:     	ushll.2d	v8, v25, #0x0
1004eeb2c:     	ushll.2d	v26, v26, #0x0
1004eeb30:     	ushll2.2d	v25, v25, #0x0
1004eeb34:     	shl.2d	v9, v0, #0x3
1004eeb38:     	ushl.2d	v25, v25, v9
1004eeb3c:     	shl.2d	v9, v23, #0x3
1004eeb40:     	ushl.2d	v26, v26, v9
1004eeb44:     	shl.2d	v9, v1, #0x3
1004eeb48:     	ushl.2d	v8, v8, v9
1004eeb4c:     	shl.2d	v9, v19, #0x3
1004eeb50:     	ushl.2d	v31, v31, v9
1004eeb54:     	shl.2d	v9, v6, #0x3
1004eeb58:     	ushl.2d	v27, v27, v9
1004eeb5c:     	shl.2d	v9, v3, #0x3
1004eeb60:     	ushl.2d	v29, v29, v9
1004eeb64:     	shl.2d	v9, v2, #0x3
1004eeb68:     	ushl.2d	v30, v30, v9
1004eeb6c:     	shl.2d	v9, v4, #0x3
1004eeb70:     	ushl.2d	v28, v28, v9
1004eeb74:     	orr.16b	v17, v28, v17
1004eeb78:     	orr.16b	v20, v30, v20
1004eeb7c:     	orr.16b	v22, v29, v22
1004eeb80:     	orr.16b	v18, v27, v18
1004eeb84:     	orr.16b	v5, v31, v5
1004eeb88:     	orr.16b	v24, v8, v24
1004eeb8c:     	orr.16b	v16, v26, v16
1004eeb90:     	orr.16b	v21, v25, v21
1004eeb94:     	add.2d	v6, v6, v7
1004eeb98:     	add.2d	v19, v19, v7
1004eeb9c:     	add.2d	v23, v23, v7
1004eeba0:     	add.2d	v4, v4, v7
1004eeba4:     	add.2d	v3, v3, v7
1004eeba8:     	add.2d	v2, v2, v7
1004eebac:     	add.2d	v1, v1, v7
1004eebb0:     	add.2d	v0, v0, v7
1004eebb4:     	subs	x16, x16, #0x10
1004eebb8:     	b.ne	0x1004eeaf8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x2b8>
1004eebbc:     	orr.16b	v0, v16, v22
1004eebc0:     	orr.16b	v1, v18, v24
1004eebc4:     	orr.16b	v0, v0, v1
1004eebc8:     	orr.16b	v1, v5, v20
1004eebcc:     	orr.16b	v2, v17, v21
1004eebd0:     	orr.16b	v1, v1, v2
1004eebd4:     	orr.16b	v0, v0, v1
1004eebd8:     	mov	d1, v0[1]
1004eebdc:     	orr.8b	v0, v0, v1
1004eebe0:     	fmov	x15, d0
1004eebe4:     	cmp	x8, x11
1004eebe8:     	b.eq	0x1004eecac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x46c>
1004eebec:     	cbz	x14, 0x1004eec8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x44c>
1004eebf0:     	mov	x14, x11
1004eebf4:     	and	x11, x8, #0x1c
1004eebf8:     	sub	x16, x29, #0x35
1004eebfc:     	add	x9, x16, x11
1004eec00:     	fmov	d0, x15
1004eec04:     	movi.2d	v1, #0000000000000000
1004eec08:     	dup.2d	v3, x14
1004eec0c:     	ldr	q2, [x13, #0x410]
1004eec10:     	orr.16b	v2, v3, v2
1004eec14:     	ldr	q4, [x12, #0x310]
1004eec18:     	orr.16b	v3, v3, v4
1004eec1c:     	sub	x12, x14, x11
1004eec20:     	add	x13, x16, x14
1004eec24:     	movi.2d	v4, #0x000000000000ff
1004eec28:     	mov	w14, #0x4               ; =4
1004eec2c:     	dup.2d	v5, x14
1004eec30:     	ldr	s6, [x13], #0x4
1004eec34:     	ushll.8h	v6, v6, #0x0
1004eec38:     	ushll.4s	v6, v6, #0x0
1004eec3c:     	ushll2.2d	v7, v6, #0x0
1004eec40:     	and.16b	v7, v7, v4
1004eec44:     	ushll.2d	v6, v6, #0x0
1004eec48:     	and.16b	v6, v6, v4
1004eec4c:     	shl.2d	v16, v2, #0x3
1004eec50:     	shl.2d	v17, v3, #0x3
1004eec54:     	ushl.2d	v6, v6, v17
1004eec58:     	ushl.2d	v7, v7, v16
1004eec5c:     	orr.16b	v1, v7, v1
1004eec60:     	orr.16b	v0, v6, v0
1004eec64:     	add.2d	v2, v2, v5
1004eec68:     	add.2d	v3, v3, v5
1004eec6c:     	adds	x12, x12, #0x4
1004eec70:     	b.ne	0x1004eec30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x3f0>
1004eec74:     	orr.16b	v0, v0, v1
1004eec78:     	mov	d1, v0[1]
1004eec7c:     	orr.8b	v0, v0, v1
1004eec80:     	fmov	x15, d0
1004eec84:     	cmp	x8, x11
1004eec88:     	b.eq	0x1004eecac <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x46c>
1004eec8c:     	add	x10, x10, x8
1004eec90:     	lsl	x11, x11, #3
1004eec94:     	ldrb	w12, [x9], #0x1
1004eec98:     	lsl	x12, x12, x11
1004eec9c:     	orr	x15, x12, x15
1004eeca0:     	add	x11, x11, #0x8
1004eeca4:     	cmp	x9, x10
1004eeca8:     	b.ne	0x1004eec94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x454>
1004eecac:     	orr	x8, x15, x8, lsl #40
1004eecb0:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
1004eecb4:     	orr	x1, x8, x9
1004eecb8:     	b	0x1004ee898 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x58>
1004eecbc:     	cmp	w16, #0x8
1004eecc0:     	b.eq	0x1004eed04 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4c4>
1004eecc4:     	cmp	w16, #0x9
1004eecc8:     	b.eq	0x1004eed14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4d4>
1004eeccc:     	cmp	w16, #0xa
1004eecd0:     	b.ne	0x1004eecec <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4ac>
1004eecd4:     	mov	w15, #0x6e              ; =110
1004eecd8:     	b	0x1004eed18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4d8>
1004eecdc:     	cmp	w16, #0x22
1004eece0:     	b.eq	0x1004eed18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4d8>
1004eece4:     	cmp	w16, #0x5c
1004eece8:     	b.eq	0x1004eed18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4d8>
1004eecec:     	cmp	w15, #0x20
1004eecf0:     	b.lt	0x1004eed1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4dc>
1004eecf4:     	sub	x13, x29, #0x35
1004eecf8:     	strb	w15, [x13, x11]
1004eecfc:     	add	x11, x11, #0x1
1004eed00:     	b	0x1004eee14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5d4>
1004eed04:     	mov	w15, #0x62              ; =98
1004eed08:     	b	0x1004eed18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4d8>
1004eed0c:     	mov	w15, #0x66              ; =102
1004eed10:     	b	0x1004eed18 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4d8>
1004eed14:     	mov	w15, #0x74              ; =116
1004eed18:     	tbz	w14, #0x0, 0x1004eee00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5c0>
1004eed1c:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1004eed20:     	cmp	x8, x9
1004eed24:     	b.eq	0x1004eed70 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x530>
1004eed28:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
1004eed2c:     	cmp	x8, x9
1004eed30:     	b.ne	0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004eed34:     	and	x0, x0, #0xffffffffffff
1004eed38:     	sub	x8, x0, #0x100, lsl #12 ; =0x100000
1004eed3c:     	mov	x9, #0x7fffffffffff     ; =140737488355327
1004eed40:     	movk	x9, #0xffef, lsl #16
1004eed44:     	cmp	x8, x9
1004eed48:     	b.hi	0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004eed4c:     	ldr	w8, [x0, #0x4]
1004eed50:     	cmp	w8, #0x40
1004eed54:     	b.lo	0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004eed58:     	bl	0x1004f0c74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
1004eed5c:     	tbz	w0, #0x0, 0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004eed60:     	mov	x8, x1
1004eed64:     	mov	x1, #0x7fff000000000000 ; =9223090561878065152
1004eed68:     	bfxil	x1, x8, #0, #48
1004eed6c:     	b	0x1004ee898 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x58>
1004eed70:     	and	x19, x0, #0xffffffffffff
1004eed74:     	mov	x0, x19
1004eed78:     	bl	0x1005781c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1004eed7c:     	cbz	x0, 0x1004eedb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x570>
1004eed80:     	ldrb	w8, [x0]
1004eed84:     	cmp	w8, #0x2
1004eed88:     	b.ne	0x1004eedb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x570>
1004eed8c:     	ldrsb	w8, [x0, #0x1]
1004eed90:     	tbnz	w8, #0x1f, 0x1004eedb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x570>
1004eed94:     	ldrh	w8, [x0, #0x2]
1004eed98:     	tbnz	w8, #0xb, 0x1004eedb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x570>
1004eed9c:     	ldr	w8, [x0, #0x4]
1004eeda0:     	cmp	w8, #0x18
1004eeda4:     	b.lo	0x1004eedb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x570>
1004eeda8:     	ldr	w8, [x19]
1004eedac:     	cbz	w8, 0x1004eeec8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x688>
1004eedb0:     	mov	x0, x19
1004eedb4:     	bl	0x1005781c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
1004eedb8:     	cbz	x0, 0x1004eede8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a8>
1004eedbc:     	ldrb	w8, [x0]
1004eedc0:     	cmp	w8, #0x2
1004eedc4:     	b.ne	0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004eedc8:     	ldrh	w8, [x0, #0x2]
1004eedcc:     	tbnz	w8, #0xb, 0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004eedd0:     	ldr	w8, [x0, #0x4]
1004eedd4:     	cmp	w8, #0x18
1004eedd8:     	b.lo	0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004eeddc:     	ldr	w8, [x19]
1004eede0:     	cbz	w8, 0x1004eee6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x62c>
1004eede4:     	mov	x0, #0x0                ; =0
1004eede8:     	ldp	x29, x30, [sp, #0x70]
1004eedec:     	ldp	x20, x19, [sp, #0x60]
1004eedf0:     	ldp	x22, x21, [sp, #0x50]
1004eedf4:     	ldp	d9, d8, [sp, #0x40]
1004eedf8:     	add	sp, sp, #0x80
1004eedfc:     	ret
1004eee00:     	sub	x14, x29, #0x35
1004eee04:     	mov	w16, #0x5c              ; =92
1004eee08:     	strb	w16, [x14, x11]
1004eee0c:     	add	x11, x11, #0x2
1004eee10:     	strb	w15, [x13, #0x1]
1004eee14:     	cmp	w10, #0x2
1004eee18:     	b.eq	0x1004eea14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1d4>
1004eee1c:     	ldrb	w12, [x12, #0x2]
1004eee20:     	sxtb	w10, w12
1004eee24:     	cmp	w12, #0xb
1004eee28:     	b.le	0x1004eee4c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x60c>
1004eee2c:     	cmp	w12, #0x21
1004eee30:     	b.gt	0x1004eee98 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x658>
1004eee34:     	cmp	w12, #0xc
1004eee38:     	b.eq	0x1004eef80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x740>
1004eee3c:     	cmp	w12, #0xd
1004eee40:     	b.ne	0x1004eeea8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x668>
1004eee44:     	mov	w10, #0x72              ; =114
1004eee48:     	b	0x1004eef8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x74c>
1004eee4c:     	cmp	w12, #0x8
1004eee50:     	b.eq	0x1004eef78 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x738>
1004eee54:     	cmp	w12, #0x9
1004eee58:     	b.eq	0x1004eef88 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x748>
1004eee5c:     	cmp	w12, #0xa
1004eee60:     	b.ne	0x1004eeea8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x668>
1004eee64:     	mov	w10, #0x6e              ; =110
1004eee68:     	b	0x1004eef8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x74c>
1004eee6c:     	mov	x21, x0
1004eee70:     	mov	x0, x19
1004eee74:     	bl	0x100345380 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1004eee78:     	cbz	x0, 0x1004eefb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x770>
1004eee7c:     	ldr	w20, [x0]
1004eee80:     	cmp	w20, #0x4
1004eee84:     	b.hi	0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004eee88:     	ldr	w8, [x0, #0x4]
1004eee8c:     	cmp	w20, w8
1004eee90:     	b.hi	0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004eee94:     	b	0x1004eefb4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x774>
1004eee98:     	cmp	w12, #0x22
1004eee9c:     	b.eq	0x1004eef8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x74c>
1004eeea0:     	cmp	w12, #0x5c
1004eeea4:     	b.eq	0x1004eef8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x74c>
1004eeea8:     	cmp	x11, #0x3
1004eeeac:     	mov	w12, #0x20              ; =32
1004eeeb0:     	ccmp	w10, w12, #0x8, ls
1004eeeb4:     	b.lt	0x1004eed1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4dc>
1004eeeb8:     	sub	x8, x29, #0x35
1004eeebc:     	strb	w10, [x8, x11]
1004eeec0:     	add	x11, x11, #0x1
1004eeec4:     	b	0x1004eea14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1d4>
1004eeec8:     	mov	x1, x0
1004eeecc:     	mov	x0, x19
1004eeed0:     	mov	x21, x1
1004eeed4:     	bl	0x1004f6dc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
1004eeed8:     	cmp	x0, #0x1
1004eeedc:     	b.eq	0x1004eede8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a8>
1004eeee0:     	mov	x0, x19
1004eeee4:     	bl	0x100345380 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
1004eeee8:     	cbz	x0, 0x1004ef040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x800>
1004eeeec:     	ldr	w20, [x0]
1004eeef0:     	cbz	w20, 0x1004ef040 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x800>
1004eeef4:     	cmp	w20, #0x8
1004eeef8:     	b.hi	0x1004eedb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x570>
1004eeefc:     	ldr	w8, [x0, #0x4]
1004eef00:     	cmp	w20, w8
1004eef04:     	b.hi	0x1004eedb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x570>
1004eef08:     	ldr	w8, [x21, #0x4]
1004eef0c:     	lsl	x9, x20, #3
1004eef10:     	add	x9, x9, #0x18
1004eef14:     	cmp	x9, x8
1004eef18:     	b.hi	0x1004eedb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x570>
1004eef1c:     	ldr	w8, [x19, #0x4]
1004eef20:     	mov	w9, #-0x40000000        ; =-1073741824
1004eef24:     	cmp	w8, w9
1004eef28:     	csel	w8, w8, wzr, lt
1004eef2c:     	mov	x21, x0
1004eef30:     	mov	x0, x8
1004eef34:     	bl	0x1005e2b24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
1004eef38:     	mov	w9, #0x2                ; =2
1004eef3c:     	nop
1004eef40:     	cmp	w1, #0x2
1004eef44:     	csel	w10, w1, w9, hi
1004eef48:     	tst	w0, #0x1
1004eef4c:     	csel	w8, w10, w9, ne
1004eef50:     	cmp	w20, w8
1004eef54:     	b.hi	0x1004eedb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x570>
1004eef58:     	mov	x0, x21
1004eef5c:     	mov	x1, x20
1004eef60:     	bl	0x1004ed500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1004eef64:     	cbz	w0, 0x1004eedb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x570>
1004eef68:     	mov	x0, x19
1004eef6c:     	mov	x1, x20
1004eef70:     	bl	0x1004f5f00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
1004eef74:     	b	0x1004ef048 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x808>
1004eef78:     	mov	w10, #0x62              ; =98
1004eef7c:     	b	0x1004eef8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x74c>
1004eef80:     	mov	w10, #0x66              ; =102
1004eef84:     	b	0x1004eef8c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x74c>
1004eef88:     	mov	w10, #0x74              ; =116
1004eef8c:     	cmp	x11, #0x2
1004eef90:     	b.hi	0x1004eed1c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x4dc>
1004eef94:     	sub	x8, x29, #0x35
1004eef98:     	add	x8, x8, x11
1004eef9c:     	add	x11, x11, #0x2
1004eefa0:     	mov	w12, #0x5c              ; =92
1004eefa4:     	strb	w12, [x8]
1004eefa8:     	strb	w10, [x8, #0x1]
1004eefac:     	b	0x1004eea14 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x1d4>
1004eefb0:     	mov	x20, #0x0               ; =0
1004eefb4:     	ldr	w8, [x21, #0x4]
1004eefb8:     	lsl	x9, x20, #3
1004eefbc:     	add	x9, x9, #0x18
1004eefc0:     	cmp	x9, x8
1004eefc4:     	b.hi	0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004eefc8:     	mov	x21, x0
1004eefcc:     	ldr	w8, [x19, #0x4]
1004eefd0:     	mov	w9, #-0x40000000        ; =-1073741824
1004eefd4:     	cmp	w8, w9
1004eefd8:     	csel	w0, w8, wzr, lt
1004eefdc:     	bl	0x1005e2b24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
1004eefe0:     	mov	w8, #0x2                ; =2
1004eefe4:     	cmp	w1, #0x2
1004eefe8:     	csel	w9, w1, w8, hi
1004eefec:     	tst	w0, #0x1
1004eeff0:     	csel	x8, x9, x8, ne
1004eeff4:     	cmp	x20, x8
1004eeff8:     	b.hi	0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004eeffc:     	cbz	x20, 0x1004ef050 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x810>
1004ef000:     	mov	x0, x21
1004ef004:     	mov	x1, x20
1004ef008:     	bl	0x1004ed500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
1004ef00c:     	tbz	w0, #0x0, 0x1004eede4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a4>
1004ef010:     	cmp	x20, #0x1
1004ef014:     	b.eq	0x1004ef06c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x82c>
1004ef018:     	cmp	x20, #0x2
1004ef01c:     	b.ne	0x1004ef0a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x864>
1004ef020:     	ldr	x1, [x19, #0x10]
1004ef024:     	add	x0, sp, #0xc
1004ef028:     	bl	0x1004ed554 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
1004ef02c:     	ldr	w8, [sp, #0xc]
1004ef030:     	cmn	w8, #0x1
1004ef034:     	b.eq	0x1004ef078 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x838>
1004ef038:     	mov	x1, #0x0                ; =0
1004ef03c:     	b	0x1004ef094 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x854>
1004ef040:     	mov	x0, x19
1004ef044:     	bl	0x1004f6c80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
1004ef048:     	tbnz	w0, #0x0, 0x1004ee898 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x58>
1004ef04c:     	b	0x1004eedb0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x570>
1004ef050:     	mov	x0, x19
1004ef054:     	bl	0x1004f5d30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
1004ef058:     	mov	w0, w0
1004ef05c:     	mov	x1, #0x7d7b             ; =32123
1004ef060:     	movk	x1, #0x200, lsl #32
1004ef064:     	movk	x1, #0x7ff9, lsl #48
1004ef068:     	b	0x1004eede8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a8>
1004ef06c:     	mov	x0, x19
1004ef070:     	bl	0x1004ed100 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
1004ef074:     	b	0x1004eede8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a8>
1004ef078:     	ldr	x1, [x19, #0x18]
1004ef07c:     	add	x0, sp, #0xc
1004ef080:     	bl	0x1004ed554 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
1004ef084:     	ldr	w8, [sp, #0xc]
1004ef088:     	cmn	w8, #0x1
1004ef08c:     	b.eq	0x1004ef0a4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x864>
1004ef090:     	mov	w1, #0x1                ; =1
1004ef094:     	add	x2, sp, #0xc
1004ef098:     	mov	x0, x19
1004ef09c:     	bl	0x1004ed900 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
1004ef0a0:     	tbnz	w0, #0x0, 0x1004ee898 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x58>
1004ef0a4:     	mov	x0, x19
1004ef0a8:     	mov	x1, x20
1004ef0ac:     	bl	0x1004ebf80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
1004ef0b0:     	b	0x1004eede8 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer+0x5a8>
1004ef0b4:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
1004ef0b8:     	add	x2, x2, #0x3c8
1004ef0bc:     	mov	w0, #0x5                ; =5
1004ef0c0:     	mov	w1, #0x5                ; =5
1004ef0c4:     	bl	0x100b1028c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
