
/Users/amlug/projects/perry/json-merged-pr10022/benchmarks/json_performance/.work/inert-spacer-inline-r10/candidate-options:	file format mach-o arm64

Disassembly of section __TEXT,__text:

0000000100842fc0 <_js_json_stringify_full>:
100842fc0:     	sub	sp, sp, #0x150
100842fc4:     	stp	d9, d8, [sp, #0xe0]
100842fc8:     	stp	x28, x27, [sp, #0xf0]
100842fcc:     	stp	x26, x25, [sp, #0x100]
100842fd0:     	stp	x24, x23, [sp, #0x110]
100842fd4:     	stp	x22, x21, [sp, #0x120]
100842fd8:     	stp	x20, x19, [sp, #0x130]
100842fdc:     	stp	x29, x30, [sp, #0x140]
100842fe0:     	add	x29, sp, #0x140
100842fe4:     	mov.16b	v9, v2
100842fe8:     	mov.16b	v8, v0
100842fec:     	fmov	x19, d8
100842ff0:     	fmov	x21, d1
100842ff4:     	fmov	x22, d9
100842ff8:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100842ffc:     	add	x27, x21, x8
100843000:     	cmp	x27, #0x2
100843004:     	add	x24, x22, x8
100843008:     	ccmp	x24, #0x3, #0x2, lo
10084300c:     	cset	w23, lo
100843010:     	b.hs	0x100843580 <_js_json_stringify_full+0x5c0>
100843014:     	mov	x8, #-0x2               ; =-2
100843018:     	movk	x8, #0x8003, lsl #48
10084301c:     	add	x8, x19, x8
100843020:     	cmp	x8, #0x3
100843024:     	b.hs	0x100843038 <_js_json_stringify_full+0x78>
100843028:     	adrp	x9, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5460>
10084302c:     	add	x9, x9, #0x128
100843030:     	ldr	x20, [x9, x8, lsl #3]
100843034:     	b	0x1008449dc <_js_json_stringify_full+0x1a1c>
100843038:     	sturb	wzr, [x29, #-0x7c]
10084303c:     	stur	wzr, [x29, #-0x80]
100843040:     	and	x8, x19, #0xffff000000000000
100843044:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
100843048:     	cmp	x8, x9
10084304c:     	b.eq	0x1008430c0 <_js_json_stringify_full+0x100>
100843050:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100843054:     	cmp	x8, x9
100843058:     	b.ne	0x1008434bc <_js_json_stringify_full+0x4fc>
10084305c:     	ubfx	x10, x19, #40, #8
100843060:     	cbz	x10, 0x1008430b0 <_js_json_stringify_full+0xf0>
100843064:     	sturb	w19, [x29, #-0x80]
100843068:     	cmp	x10, #0x1
10084306c:     	b.eq	0x1008430b0 <_js_json_stringify_full+0xf0>
100843070:     	lsr	x9, x19, #8
100843074:     	sturb	w9, [x29, #-0x7f]
100843078:     	cmp	x10, #0x2
10084307c:     	b.eq	0x1008430b0 <_js_json_stringify_full+0xf0>
100843080:     	lsr	x9, x19, #16
100843084:     	sturb	w9, [x29, #-0x7e]
100843088:     	cmp	x10, #0x3
10084308c:     	b.eq	0x1008430b0 <_js_json_stringify_full+0xf0>
100843090:     	lsr	x9, x19, #24
100843094:     	sturb	w9, [x29, #-0x7d]
100843098:     	cmp	x10, #0x4
10084309c:     	b.eq	0x1008430b0 <_js_json_stringify_full+0xf0>
1008430a0:     	lsr	x9, x19, #32
1008430a4:     	sturb	w9, [x29, #-0x7c]
1008430a8:     	cmp	x10, #0x5
1008430ac:     	b.ne	0x100845444 <_js_json_stringify_full+0x2484>
1008430b0:     	sub	x11, x29, #0x80
1008430b4:     	cmp	w10, #0x3
1008430b8:     	b.ls	0x1008430d8 <_js_json_stringify_full+0x118>
1008430bc:     	b	0x1008434bc <_js_json_stringify_full+0x4fc>
1008430c0:     	ands	x9, x19, #0xffffffffffff
1008430c4:     	b.eq	0x1008435a8 <_js_json_stringify_full+0x5e8>
1008430c8:     	add	x11, x9, #0x14
1008430cc:     	ldr	w10, [x9, #0x4]
1008430d0:     	cmp	w10, #0x3
1008430d4:     	b.hi	0x1008434bc <_js_json_stringify_full+0x4fc>
1008430d8:     	stur	wzr, [sp, #0x61]
1008430dc:     	mov	w9, #0x22               ; =34
1008430e0:     	strb	w9, [sp, #0x60]
1008430e4:     	cbz	w10, 0x10084311c <_js_json_stringify_full+0x15c>
1008430e8:     	add	x12, sp, #0x60
1008430ec:     	ldrb	w13, [x11]
1008430f0:     	sxtb	w15, w13
1008430f4:     	cmp	w13, #0xb
1008430f8:     	b.le	0x100843124 <_js_json_stringify_full+0x164>
1008430fc:     	cmp	w13, #0x21
100843100:     	b.gt	0x100843144 <_js_json_stringify_full+0x184>
100843104:     	cmp	w13, #0xc
100843108:     	b.eq	0x100843178 <_js_json_stringify_full+0x1b8>
10084310c:     	cmp	w13, #0xd
100843110:     	b.ne	0x100843154 <_js_json_stringify_full+0x194>
100843114:     	mov	w15, #0x72              ; =114
100843118:     	b	0x100843184 <_js_json_stringify_full+0x1c4>
10084311c:     	mov	w12, #0x1               ; =1
100843120:     	b	0x1008431ac <_js_json_stringify_full+0x1ec>
100843124:     	cmp	w13, #0x8
100843128:     	b.eq	0x100843170 <_js_json_stringify_full+0x1b0>
10084312c:     	cmp	w13, #0x9
100843130:     	b.eq	0x100843180 <_js_json_stringify_full+0x1c0>
100843134:     	cmp	w13, #0xa
100843138:     	b.ne	0x100843154 <_js_json_stringify_full+0x194>
10084313c:     	mov	w15, #0x6e              ; =110
100843140:     	b	0x100843184 <_js_json_stringify_full+0x1c4>
100843144:     	cmp	w13, #0x22
100843148:     	b.eq	0x100843184 <_js_json_stringify_full+0x1c4>
10084314c:     	cmp	w13, #0x5c
100843150:     	b.eq	0x100843184 <_js_json_stringify_full+0x1c4>
100843154:     	cmp	w15, #0x20
100843158:     	b.lt	0x1008434bc <_js_json_stringify_full+0x4fc>
10084315c:     	mov	w14, #0x0               ; =0
100843160:     	add	x13, x12, #0x2
100843164:     	mov	w12, #0x2               ; =2
100843168:     	mov	w16, #0x1               ; =1
10084316c:     	b	0x10084319c <_js_json_stringify_full+0x1dc>
100843170:     	mov	w15, #0x62              ; =98
100843174:     	b	0x100843184 <_js_json_stringify_full+0x1c4>
100843178:     	mov	w15, #0x66              ; =102
10084317c:     	b	0x100843184 <_js_json_stringify_full+0x1c4>
100843180:     	mov	w15, #0x74              ; =116
100843184:     	add	x13, x12, #0x3
100843188:     	mov	w12, #0x5c              ; =92
10084318c:     	strb	w12, [sp, #0x61]
100843190:     	mov	w14, #0x1               ; =1
100843194:     	mov	w12, #0x3               ; =3
100843198:     	mov	w16, #0x2               ; =2
10084319c:     	add	x17, sp, #0x60
1008431a0:     	strb	w15, [x17, x16]
1008431a4:     	cmp	w10, #0x1
1008431a8:     	b.ne	0x1008431e4 <_js_json_stringify_full+0x224>
1008431ac:     	add	x10, sp, #0x60
1008431b0:     	strb	w9, [x10, x12]
1008431b4:     	add	x8, x12, #0x1
1008431b8:     	cmp	x12, #0x3
1008431bc:     	b.hs	0x1008431d0 <_js_json_stringify_full+0x210>
1008431c0:     	mov	x13, #0x0               ; =0
1008431c4:     	mov	x11, #0x0               ; =0
1008431c8:     	add	x9, sp, #0x60
1008431cc:     	b	0x10084342c <_js_json_stringify_full+0x46c>
1008431d0:     	cmp	x12, #0xf
1008431d4:     	b.hs	0x100843214 <_js_json_stringify_full+0x254>
1008431d8:     	mov	x11, #0x0               ; =0
1008431dc:     	mov	x13, #0x0               ; =0
1008431e0:     	b	0x100843388 <_js_json_stringify_full+0x3c8>
1008431e4:     	ldrb	w16, [x11, #0x1]
1008431e8:     	sxtb	w15, w16
1008431ec:     	cmp	w16, #0xb
1008431f0:     	b.le	0x10084345c <_js_json_stringify_full+0x49c>
1008431f4:     	cmp	w16, #0x21
1008431f8:     	b.gt	0x10084347c <_js_json_stringify_full+0x4bc>
1008431fc:     	cmp	w16, #0xc
100843200:     	b.eq	0x1008434ac <_js_json_stringify_full+0x4ec>
100843204:     	cmp	w16, #0xd
100843208:     	b.ne	0x10084348c <_js_json_stringify_full+0x4cc>
10084320c:     	mov	w15, #0x72              ; =114
100843210:     	b	0x1008434b8 <_js_json_stringify_full+0x4f8>
100843214:     	and	x12, x8, #0xc
100843218:     	and	x11, x8, #0x10
10084321c:     	add	x13, sp, #0x60
100843220:     	add	x9, x13, x11
100843224:     	adrp	x14, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6460>
100843228:     	ldr	q0, [x14, #0x2a0]
10084322c:     	adrp	x14, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6460>
100843230:     	ldr	q1, [x14, #0x2b0]
100843234:     	adrp	x14, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6460>
100843238:     	ldr	q2, [x14, #0x2c0]
10084323c:     	adrp	x14, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6460>
100843240:     	ldr	q3, [x14, #0x2d0]
100843244:     	adrp	x14, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6460>
100843248:     	ldr	q4, [x14, #0x2e0]
10084324c:     	movi.2d	v5, #0000000000000000
100843250:     	adrp	x14, 0x100c98000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x6460>
100843254:     	ldr	q6, [x14, #0x2f0]
100843258:     	adrp	x14, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5460>
10084325c:     	ldr	q7, [x14, #0x410]
100843260:     	mov	w14, #0x10              ; =16
100843264:     	movi.2d	v16, #0000000000000000
100843268:     	dup.2d	v17, x14
10084326c:     	adrp	x14, 0x100c37000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33c6a>
100843270:     	ldr	q19, [x14, #0x310]
100843274:     	and	x14, x8, #0x10
100843278:     	movi.2d	v20, #0000000000000000
10084327c:     	movi.2d	v18, #0000000000000000
100843280:     	movi.2d	v23, #0000000000000000
100843284:     	movi.2d	v21, #0000000000000000
100843288:     	movi.2d	v24, #0000000000000000
10084328c:     	movi.2d	v22, #0000000000000000
100843290:     	ldr	q25, [x13], #0x10
100843294:     	ushll.8h	v26, v25, #0x0
100843298:     	ushll2.4s	v27, v26, #0x0
10084329c:     	ushll2.2d	v28, v27, #0x0
1008432a0:     	ushll2.8h	v25, v25, #0x0
1008432a4:     	ushll.4s	v29, v25, #0x0
1008432a8:     	ushll2.2d	v30, v29, #0x0
1008432ac:     	ushll.2d	v29, v29, #0x0
1008432b0:     	ushll.2d	v27, v27, #0x0
1008432b4:     	ushll.4s	v26, v26, #0x0
1008432b8:     	ushll2.2d	v31, v26, #0x0
1008432bc:     	ushll2.4s	v25, v25, #0x0
1008432c0:     	ushll.2d	v8, v25, #0x0
1008432c4:     	ushll.2d	v26, v26, #0x0
1008432c8:     	ushll2.2d	v25, v25, #0x0
1008432cc:     	shl.2d	v9, v0, #0x3
1008432d0:     	ushl.2d	v25, v25, v9
1008432d4:     	shl.2d	v9, v19, #0x3
1008432d8:     	ushl.2d	v26, v26, v9
1008432dc:     	shl.2d	v9, v1, #0x3
1008432e0:     	ushl.2d	v8, v8, v9
1008432e4:     	shl.2d	v9, v7, #0x3
1008432e8:     	ushl.2d	v31, v31, v9
1008432ec:     	shl.2d	v9, v6, #0x3
1008432f0:     	ushl.2d	v27, v27, v9
1008432f4:     	shl.2d	v9, v3, #0x3
1008432f8:     	ushl.2d	v29, v29, v9
1008432fc:     	shl.2d	v9, v2, #0x3
100843300:     	ushl.2d	v30, v30, v9
100843304:     	shl.2d	v9, v4, #0x3
100843308:     	ushl.2d	v28, v28, v9
10084330c:     	orr.16b	v18, v28, v18
100843310:     	orr.16b	v21, v30, v21
100843314:     	orr.16b	v23, v29, v23
100843318:     	orr.16b	v20, v27, v20
10084331c:     	orr.16b	v5, v31, v5
100843320:     	orr.16b	v24, v8, v24
100843324:     	orr.16b	v16, v26, v16
100843328:     	orr.16b	v22, v25, v22
10084332c:     	add.2d	v6, v6, v17
100843330:     	add.2d	v7, v7, v17
100843334:     	add.2d	v19, v19, v17
100843338:     	add.2d	v4, v4, v17
10084333c:     	add.2d	v3, v3, v17
100843340:     	add.2d	v2, v2, v17
100843344:     	add.2d	v1, v1, v17
100843348:     	add.2d	v0, v0, v17
10084334c:     	subs	x14, x14, #0x10
100843350:     	b.ne	0x100843290 <_js_json_stringify_full+0x2d0>
100843354:     	orr.16b	v0, v16, v23
100843358:     	orr.16b	v1, v20, v24
10084335c:     	orr.16b	v0, v0, v1
100843360:     	orr.16b	v1, v5, v21
100843364:     	orr.16b	v2, v18, v22
100843368:     	orr.16b	v1, v1, v2
10084336c:     	orr.16b	v0, v0, v1
100843370:     	mov	d1, v0[1]
100843374:     	orr.8b	v0, v0, v1
100843378:     	fmov	x13, d0
10084337c:     	cmp	x8, x11
100843380:     	b.eq	0x10084344c <_js_json_stringify_full+0x48c>
100843384:     	cbz	x12, 0x10084342c <_js_json_stringify_full+0x46c>
100843388:     	mov	x14, x11
10084338c:     	and	x11, x8, #0x1c
100843390:     	add	x15, sp, #0x60
100843394:     	add	x9, x15, x11
100843398:     	fmov	d0, x13
10084339c:     	movi.2d	v1, #0000000000000000
1008433a0:     	dup.2d	v3, x14
1008433a4:     	adrp	x12, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5460>
1008433a8:     	ldr	q2, [x12, #0x410]
1008433ac:     	orr.16b	v2, v3, v2
1008433b0:     	adrp	x12, 0x100c37000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33c6a>
1008433b4:     	ldr	q4, [x12, #0x310]
1008433b8:     	orr.16b	v3, v3, v4
1008433bc:     	sub	x12, x14, x11
1008433c0:     	add	x13, x15, x14
1008433c4:     	movi.2d	v4, #0x000000000000ff
1008433c8:     	mov	w14, #0x4               ; =4
1008433cc:     	dup.2d	v5, x14
1008433d0:     	ldr	s6, [x13], #0x4
1008433d4:     	ushll.8h	v6, v6, #0x0
1008433d8:     	ushll.4s	v6, v6, #0x0
1008433dc:     	ushll2.2d	v7, v6, #0x0
1008433e0:     	and.16b	v7, v7, v4
1008433e4:     	ushll.2d	v6, v6, #0x0
1008433e8:     	and.16b	v6, v6, v4
1008433ec:     	shl.2d	v16, v2, #0x3
1008433f0:     	shl.2d	v17, v3, #0x3
1008433f4:     	ushl.2d	v6, v6, v17
1008433f8:     	ushl.2d	v7, v7, v16
1008433fc:     	orr.16b	v1, v7, v1
100843400:     	orr.16b	v0, v6, v0
100843404:     	add.2d	v2, v2, v5
100843408:     	add.2d	v3, v3, v5
10084340c:     	adds	x12, x12, #0x4
100843410:     	b.ne	0x1008433d0 <_js_json_stringify_full+0x410>
100843414:     	orr.16b	v0, v0, v1
100843418:     	mov	d1, v0[1]
10084341c:     	orr.8b	v0, v0, v1
100843420:     	fmov	x13, d0
100843424:     	cmp	x8, x11
100843428:     	b.eq	0x10084344c <_js_json_stringify_full+0x48c>
10084342c:     	add	x10, x10, x8
100843430:     	lsl	x11, x11, #3
100843434:     	ldrb	w12, [x9], #0x1
100843438:     	lsl	x12, x12, x11
10084343c:     	orr	x13, x12, x13
100843440:     	add	x11, x11, #0x8
100843444:     	cmp	x9, x10
100843448:     	b.ne	0x100843434 <_js_json_stringify_full+0x474>
10084344c:     	orr	x8, x13, x8, lsl #40
100843450:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100843454:     	orr	x20, x8, x9
100843458:     	b	0x1008449dc <_js_json_stringify_full+0x1a1c>
10084345c:     	cmp	w16, #0x8
100843460:     	b.eq	0x1008434a4 <_js_json_stringify_full+0x4e4>
100843464:     	cmp	w16, #0x9
100843468:     	b.eq	0x1008434b4 <_js_json_stringify_full+0x4f4>
10084346c:     	cmp	w16, #0xa
100843470:     	b.ne	0x10084348c <_js_json_stringify_full+0x4cc>
100843474:     	mov	w15, #0x6e              ; =110
100843478:     	b	0x1008434b8 <_js_json_stringify_full+0x4f8>
10084347c:     	cmp	w16, #0x22
100843480:     	b.eq	0x1008434b8 <_js_json_stringify_full+0x4f8>
100843484:     	cmp	w16, #0x5c
100843488:     	b.eq	0x1008434b8 <_js_json_stringify_full+0x4f8>
10084348c:     	cmp	w15, #0x20
100843490:     	b.lt	0x1008434bc <_js_json_stringify_full+0x4fc>
100843494:     	add	x13, sp, #0x60
100843498:     	strb	w15, [x13, x12]
10084349c:     	add	x12, x12, #0x1
1008434a0:     	b	0x1008437dc <_js_json_stringify_full+0x81c>
1008434a4:     	mov	w15, #0x62              ; =98
1008434a8:     	b	0x1008434b8 <_js_json_stringify_full+0x4f8>
1008434ac:     	mov	w15, #0x66              ; =102
1008434b0:     	b	0x1008434b8 <_js_json_stringify_full+0x4f8>
1008434b4:     	mov	w15, #0x74              ; =116
1008434b8:     	tbz	w14, #0x0, 0x1008437c8 <_js_json_stringify_full+0x808>
1008434bc:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008434c0:     	cmp	x8, x9
1008434c4:     	b.eq	0x10084350c <_js_json_stringify_full+0x54c>
1008434c8:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
1008434cc:     	cmp	x8, x9
1008434d0:     	b.ne	0x100843580 <_js_json_stringify_full+0x5c0>
1008434d4:     	and	x8, x19, #0xffffffffffff
1008434d8:     	sub	x9, x8, #0x100, lsl #12 ; =0x100000
1008434dc:     	mov	x10, #0x7fffffffffff    ; =140737488355327
1008434e0:     	movk	x10, #0xffef, lsl #16
1008434e4:     	cmp	x9, x10
1008434e8:     	b.hi	0x100843580 <_js_json_stringify_full+0x5c0>
1008434ec:     	ldr	w8, [x8, #0x4]
1008434f0:     	cmp	w8, #0x40
1008434f4:     	b.lo	0x100843580 <_js_json_stringify_full+0x5c0>
1008434f8:     	and	x0, x19, #0xffffffffffff
1008434fc:     	bl	0x1004f0c74 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json16stringify_string17quote_heap_string>
100843500:     	cmp	x0, #0x1
100843504:     	b.ne	0x100843580 <_js_json_stringify_full+0x5c0>
100843508:     	b	0x1008436ec <_js_json_stringify_full+0x72c>
10084350c:     	and	x25, x19, #0xffffffffffff
100843510:     	and	x0, x19, #0xffffffffffff
100843514:     	bl	0x1005781c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100843518:     	cbz	x0, 0x10084354c <_js_json_stringify_full+0x58c>
10084351c:     	ldrb	w8, [x0]
100843520:     	cmp	w8, #0x2
100843524:     	b.ne	0x10084354c <_js_json_stringify_full+0x58c>
100843528:     	ldrsb	w8, [x0, #0x1]
10084352c:     	tbnz	w8, #0x1f, 0x10084354c <_js_json_stringify_full+0x58c>
100843530:     	ldrh	w8, [x0, #0x2]
100843534:     	tbnz	w8, #0xb, 0x10084354c <_js_json_stringify_full+0x58c>
100843538:     	ldr	w8, [x0, #0x4]
10084353c:     	cmp	w8, #0x18
100843540:     	b.lo	0x10084354c <_js_json_stringify_full+0x58c>
100843544:     	ldr	w8, [x25]
100843548:     	cbz	w8, 0x100843cd0 <_js_json_stringify_full+0xd10>
10084354c:     	and	x0, x19, #0xffffffffffff
100843550:     	bl	0x1005781c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100843554:     	cbz	x0, 0x100843580 <_js_json_stringify_full+0x5c0>
100843558:     	ldrb	w8, [x0]
10084355c:     	cmp	w8, #0x2
100843560:     	b.ne	0x100843580 <_js_json_stringify_full+0x5c0>
100843564:     	ldrh	w8, [x0, #0x2]
100843568:     	tbnz	w8, #0xb, 0x100843580 <_js_json_stringify_full+0x5c0>
10084356c:     	ldr	w8, [x0, #0x4]
100843570:     	cmp	w8, #0x18
100843574:     	b.lo	0x100843580 <_js_json_stringify_full+0x5c0>
100843578:     	ldr	w8, [x25]
10084357c:     	cbz	w8, 0x100843c74 <_js_json_stringify_full+0xcb4>
100843580:     	cmp	x27, #0x1
100843584:     	ccmp	x24, #0x3, #0x0, ls
100843588:     	b.lo	0x1008435a8 <_js_json_stringify_full+0x5e8>
10084358c:     	mov	x0, x19
100843590:     	mov	x1, x22
100843594:     	bl	0x1004ee840 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json15stringify_small16try_inert_spacer>
100843598:     	cmp	x0, #0x1
10084359c:     	b.ne	0x1008435a8 <_js_json_stringify_full+0x5e8>
1008435a0:     	mov	x20, x1
1008435a4:     	b	0x1008449dc <_js_json_stringify_full+0x1a1c>
1008435a8:     	mov	x20, #0x1               ; =1
1008435ac:     	movk	x20, #0x7ffc, lsl #48
1008435b0:     	cmp	x19, x20
1008435b4:     	b.eq	0x1008449dc <_js_json_stringify_full+0x1a1c>
1008435b8:     	and	x24, x19, #0xffff000000000000
1008435bc:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008435c0:     	cmp	x24, x8
1008435c4:     	b.ne	0x1008435fc <_js_json_stringify_full+0x63c>
1008435c8:     	and	x8, x19, #0xffffffffffff
1008435cc:     	cmp	x8, #0x100, lsl #12     ; =0x100000
1008435d0:     	b.lo	0x1008435e8 <_js_json_stringify_full+0x628>
1008435d4:     	ldr	w8, [x8, #0xc]
1008435d8:     	mov	w9, #0x4f53             ; =20307
1008435dc:     	movk	w9, #0x434c, lsl #16
1008435e0:     	cmp	w8, w9
1008435e4:     	b.eq	0x1008449dc <_js_json_stringify_full+0x1a1c>
1008435e8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008435ec:     	cmp	x24, x8
1008435f0:     	b.ne	0x100843628 <_js_json_stringify_full+0x668>
1008435f4:     	and	x0, x19, #0xffffffffffff
1008435f8:     	b	0x100843650 <_js_json_stringify_full+0x690>
1008435fc:     	lsr	x8, x19, #52
100843600:     	cbnz	x8, 0x1008436d8 <_js_json_stringify_full+0x718>
100843604:     	and	x8, x19, #0x7
100843608:     	cbz	x19, 0x100843634 <_js_json_stringify_full+0x674>
10084360c:     	cbnz	x8, 0x100843634 <_js_json_stringify_full+0x674>
100843610:     	mov	x0, x19
100843614:     	bl	0x10050c938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100843618:     	mov	x8, x19
10084361c:     	tbnz	w0, #0x0, 0x1008435cc <_js_json_stringify_full+0x60c>
100843620:     	mov	x8, #0x0                ; =0
100843624:     	b	0x100843634 <_js_json_stringify_full+0x674>
100843628:     	lsr	x8, x19, #52
10084362c:     	cbnz	x8, 0x1008436d8 <_js_json_stringify_full+0x718>
100843630:     	and	x8, x19, #0x7
100843634:     	cbz	x19, 0x1008436d8 <_js_json_stringify_full+0x718>
100843638:     	cbnz	x8, 0x1008436d8 <_js_json_stringify_full+0x718>
10084363c:     	mov	x0, x19
100843640:     	bl	0x10050c938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100843644:     	mov	x8, x0
100843648:     	mov	x0, x19
10084364c:     	tbz	w8, #0x0, 0x1008436d8 <_js_json_stringify_full+0x718>
100843650:     	cmp	x0, #0x100, lsl #12     ; =0x100000
100843654:     	b.lo	0x1008436d8 <_js_json_stringify_full+0x718>
100843658:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
10084365c:     	add	x8, x8, #0xf70
100843660:     	ldaprb	w8, [x8]
100843664:     	cbz	w8, 0x1008436d8 <_js_json_stringify_full+0x718>
100843668:     	lsr	x8, x0, #3
10084366c:     	mov	x9, #0x7c15             ; =31765
100843670:     	movk	x9, #0x7f4a, lsl #16
100843674:     	movk	x9, #0x79b9, lsl #32
100843678:     	movk	x9, #0x9e37, lsl #48
10084367c:     	mul	x8, x8, x9
100843680:     	lsr	x10, x8, #54
100843684:     	lsr	x11, x8, #60
100843688:     	adrp	x9, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
10084368c:     	add	x9, x9, #0xef0
100843690:     	add	x11, x9, x11, lsl #3
100843694:     	ldapr	x11, [x11]
100843698:     	lsr	x10, x11, x10
10084369c:     	tbz	w10, #0x0, 0x1008436d8 <_js_json_stringify_full+0x718>
1008436a0:     	lsr	x10, x8, #44
1008436a4:     	ubfx	x11, x8, #50, #4
1008436a8:     	add	x11, x9, x11, lsl #3
1008436ac:     	ldapr	x11, [x11]
1008436b0:     	lsr	x10, x11, x10
1008436b4:     	tbz	w10, #0x0, 0x1008436d8 <_js_json_stringify_full+0x718>
1008436b8:     	lsr	x10, x8, #34
1008436bc:     	ubfx	x8, x8, #40, #4
1008436c0:     	add	x8, x9, x8, lsl #3
1008436c4:     	ldapr	x8, [x8]
1008436c8:     	lsr	x8, x8, x10
1008436cc:     	tbz	w8, #0x0, 0x1008436d8 <_js_json_stringify_full+0x718>
1008436d0:     	bl	0x10034a16c <__RNvNtCs3gRpqoBkMHm_13perry_runtime6symbol25is_registered_symbol_slow>
1008436d4:     	tbnz	w0, #0x0, 0x1008449dc <_js_json_stringify_full+0x1a1c>
1008436d8:     	tbz	w23, #0x0, 0x1008436f8 <_js_json_stringify_full+0x738>
1008436dc:     	mov.16b	v0, v8
1008436e0:     	bl	0x1004eb4bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json13stringify_api24try_stringify_lazy_array>
1008436e4:     	cmp	x0, #0x1
1008436e8:     	b.ne	0x1008436f8 <_js_json_stringify_full+0x738>
1008436ec:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
1008436f0:     	bfxil	x20, x1, #0, #48
1008436f4:     	b	0x1008449dc <_js_json_stringify_full+0x1a1c>
1008436f8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008436fc:     	cmp	x24, x8
100843700:     	b.ne	0x100843750 <_js_json_stringify_full+0x790>
100843704:     	ands	x23, x19, #0xffffffffffff
100843708:     	b.eq	0x100843750 <_js_json_stringify_full+0x790>
10084370c:     	mov	x0, x23
100843710:     	bl	0x10050c938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100843714:     	cbz	w0, 0x100843750 <_js_json_stringify_full+0x790>
100843718:     	ldurb	w8, [x23, #-0x8]
10084371c:     	cmp	w8, #0x9
100843720:     	b.ne	0x100843750 <_js_json_stringify_full+0x790>
100843724:     	ldr	w8, [x23, #0x4]
100843728:     	mov	w9, #0x5841             ; =22593
10084372c:     	movk	w9, #0x4c5a, lsl #16
100843730:     	cmp	w8, w9
100843734:     	b.ne	0x100843750 <_js_json_stringify_full+0x790>
100843738:     	mov	x0, x23
10084373c:     	bl	0x10068569c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime9json_tape8mutation26resolve_materialized_array>
100843740:     	cbz	x0, 0x100843750 <_js_json_stringify_full+0x790>
100843744:     	mov	x19, #0x7ffd000000000000 ; =9222527611924643840
100843748:     	bfxil	x19, x0, #0, #48
10084374c:     	fmov	d8, x19
100843750:     	mov	w8, #0x7ffd             ; =32765
100843754:     	cmp	x8, x22, lsr #48
100843758:     	b.ne	0x10084376c <_js_json_stringify_full+0x7ac>
10084375c:     	and	x1, x22, #0xffffffffffff
100843760:     	cmp	x1, #0x100, lsl #12     ; =0x100000
100843764:     	b.hs	0x100843780 <_js_json_stringify_full+0x7c0>
100843768:     	b	0x100843820 <_js_json_stringify_full+0x860>
10084376c:     	sub	x8, x22, #0x100, lsl #12 ; =0x100000
100843770:     	mov	x9, #0xfffffff00000     ; =281474975662080
100843774:     	mov	x1, x22
100843778:     	cmp	x8, x9
10084377c:     	b.hs	0x100843820 <_js_json_stringify_full+0x860>
100843780:     	lsr	x8, x1, #47
100843784:     	cbnz	x8, 0x100843820 <_js_json_stringify_full+0x860>
100843788:     	add	x0, sp, #0x60
10084378c:     	bl	0x10076b4ac <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
100843790:     	ldr	w8, [sp, #0x60]
100843794:     	tbz	w8, #0x0, 0x100843820 <_js_json_stringify_full+0x860>
100843798:     	ldr	w8, [sp, #0x68]
10084379c:     	mov	w9, #-0xff30            ; =-65328
1008437a0:     	cmp	w8, w9
1008437a4:     	b.eq	0x100843814 <_js_json_stringify_full+0x854>
1008437a8:     	mov	w9, #-0xff2f            ; =-65327
1008437ac:     	cmp	w8, w9
1008437b0:     	b.ne	0x100843820 <_js_json_stringify_full+0x860>
1008437b4:     	mov.16b	v0, v9
1008437b8:     	bl	0x1008460bc <_js_jsvalue_to_string>
1008437bc:     	mov	x22, #0x7fff000000000000 ; =9223090561878065152
1008437c0:     	bfxil	x22, x0, #0, #48
1008437c4:     	b	0x100843820 <_js_json_stringify_full+0x860>
1008437c8:     	add	x14, sp, #0x60
1008437cc:     	mov	w16, #0x5c              ; =92
1008437d0:     	strb	w16, [x14, x12]
1008437d4:     	add	x12, x12, #0x2
1008437d8:     	strb	w15, [x13, #0x1]
1008437dc:     	cmp	w10, #0x2
1008437e0:     	b.eq	0x1008431ac <_js_json_stringify_full+0x1ec>
1008437e4:     	ldrb	w11, [x11, #0x2]
1008437e8:     	sxtb	w10, w11
1008437ec:     	cmp	w11, #0xb
1008437f0:     	b.le	0x100843c24 <_js_json_stringify_full+0xc64>
1008437f4:     	cmp	w11, #0x21
1008437f8:     	b.gt	0x100843ca0 <_js_json_stringify_full+0xce0>
1008437fc:     	cmp	w11, #0xc
100843800:     	b.eq	0x100843d84 <_js_json_stringify_full+0xdc4>
100843804:     	cmp	w11, #0xd
100843808:     	b.ne	0x100843cb0 <_js_json_stringify_full+0xcf0>
10084380c:     	mov	w10, #0x72              ; =114
100843810:     	b	0x100843d90 <_js_json_stringify_full+0xdd0>
100843814:     	mov.16b	v0, v9
100843818:     	bl	0x10086d660 <_js_number_coerce>
10084381c:     	fmov	x22, d0
100843820:     	mov	x8, #-0x7ffc000000000001 ; =-9222246136947933185
100843824:     	add	x8, x22, x8
100843828:     	cmp	x8, #0x3
10084382c:     	b.hs	0x100843858 <_js_json_stringify_full+0x898>
100843830:     	mov	x22, #0x0               ; =0
100843834:     	mov	w8, #0x1                ; =1
100843838:     	stp	xzr, x8, [sp, #0x30]
10084383c:     	str	xzr, [sp, #0x40]
100843840:     	cmp	x27, #0x2
100843844:     	b.hs	0x100843888 <_js_json_stringify_full+0x8c8>
100843848:     	mov	w24, #0x0               ; =0
10084384c:     	mov	x27, #-0x1              ; =-1
100843850:     	mov	w26, #0x1               ; =1
100843854:     	b	0x100844294 <_js_json_stringify_full+0x12d4>
100843858:     	and	x8, x22, #0xffff000000000000
10084385c:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100843860:     	cmp	x8, x9
100843864:     	b.eq	0x1008439d0 <_js_json_stringify_full+0xa10>
100843868:     	mov	x9, #0x7fff000000000000 ; =9223090561878065152
10084386c:     	cmp	x8, x9
100843870:     	b.ne	0x100843a5c <_js_json_stringify_full+0xa9c>
100843874:     	and	x8, x22, #0xffffffffffff
100843878:     	cmp	x8, #0x1, lsl #12       ; =0x1000
10084387c:     	b.hs	0x100843aa4 <_js_json_stringify_full+0xae4>
100843880:     	mov	x9, #0x0                ; =0
100843884:     	b	0x100843aac <_js_json_stringify_full+0xaec>
100843888:     	and	x27, x21, #0xffff000000000000
10084388c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100843890:     	cmp	x27, x8
100843894:     	b.ne	0x1008439a8 <_js_json_stringify_full+0x9e8>
100843898:     	and	x25, x21, #0xffffffffffff
10084389c:     	cmp	x25, #0x100, lsl #12    ; =0x100000
1008438a0:     	b.lo	0x100844268 <_js_json_stringify_full+0x12a8>
1008438a4:     	mov	x0, x25
1008438a8:     	bl	0x100507e40 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify17is_object_pointer>
1008438ac:     	tbnz	w0, #0x0, 0x100844268 <_js_json_stringify_full+0x12a8>
1008438b0:     	lsr	x8, x25, #51
1008438b4:     	cmp	x8, #0xfff
1008438b8:     	b.lo	0x1008438d8 <_js_json_stringify_full+0x918>
1008438bc:     	mov	x28, x22
1008438c0:     	mov	w8, #0x7ffc             ; =32764
1008438c4:     	cmp	x8, x25, lsr #48
1008438c8:     	b.eq	0x100844048 <_js_json_stringify_full+0x1088>
1008438cc:     	ands	x25, x25, #0xffffffffffff
1008438d0:     	b.eq	0x100844048 <_js_json_stringify_full+0x1088>
1008438d4:     	mov	x22, x28
1008438d8:     	and	x8, x25, #0xfffffffffff00000
1008438dc:     	lsr	x9, x25, #47
1008438e0:     	cmp	x9, #0x0
1008438e4:     	ccmp	x8, #0x0, #0x4, eq
1008438e8:     	b.eq	0x100844268 <_js_json_stringify_full+0x12a8>
1008438ec:     	tst	x25, #0x3
1008438f0:     	ccmp	x25, #0x7, #0x0, eq
1008438f4:     	b.ls	0x100843f48 <_js_json_stringify_full+0xf88>
1008438f8:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
1008438fc:     	ldr	x8, [x8, #0x48]
100843900:     	cmn	x8, #0x1
100843904:     	b.eq	0x100843e98 <_js_json_stringify_full+0xed8>
100843908:     	mrs	x9, TPIDRRO_EL0
10084390c:     	and	x9, x9, #0xfffffffffffffff8
100843910:     	ldr	x0, [x9, x8, lsl #3]
100843914:     	cbz	x0, 0x100843e98 <_js_json_stringify_full+0xed8>
100843918:     	lsr	x1, x25, #20
10084391c:     	ldr	x8, [x0, #0x10]
100843920:     	ldrb	w9, [x8]
100843924:     	cmp	w9, #0x2
100843928:     	b.ne	0x100843eb0 <_js_json_stringify_full+0xef0>
10084392c:     	ldrb	w9, [x8, #0x88]
100843930:     	tbz	w9, #0x0, 0x100843950 <_js_json_stringify_full+0x990>
100843934:     	ldr	x9, [x8, #0x80]
100843938:     	cmp	x9, x1
10084393c:     	b.ne	0x100843950 <_js_json_stringify_full+0x990>
100843940:     	ldp	x9, x10, [x8, #0x60]
100843944:     	cmp	x9, x25
100843948:     	ccmp	x10, x25, #0x0, ls
10084394c:     	b.hi	0x100843e90 <_js_json_stringify_full+0xed0>
100843950:     	ldrb	w9, [x8, #0xb8]
100843954:     	cbz	w9, 0x100843974 <_js_json_stringify_full+0x9b4>
100843958:     	ldr	x9, [x8, #0xb0]
10084395c:     	cmp	x9, x1
100843960:     	b.ne	0x100843974 <_js_json_stringify_full+0x9b4>
100843964:     	ldp	x9, x10, [x8, #0x90]
100843968:     	cmp	x9, x25
10084396c:     	ccmp	x10, x25, #0x0, ls
100843970:     	b.hi	0x1008440e4 <_js_json_stringify_full+0x1124>
100843974:     	ldrb	w9, [x8, #0xe8]
100843978:     	cbz	w9, 0x100843e48 <_js_json_stringify_full+0xe88>
10084397c:     	ldr	x9, [x8, #0xe0]
100843980:     	cmp	x9, x1
100843984:     	b.ne	0x100843e48 <_js_json_stringify_full+0xe88>
100843988:     	ldr	x9, [x8, #0xc0]
10084398c:     	cmp	x9, x25
100843990:     	b.hi	0x100843e48 <_js_json_stringify_full+0xe88>
100843994:     	ldr	x9, [x8, #0xc8]
100843998:     	cmp	x9, x25
10084399c:     	b.ls	0x100843e48 <_js_json_stringify_full+0xe88>
1008439a0:     	add	x9, x8, #0xc0
1008439a4:     	b	0x1008440e8 <_js_json_stringify_full+0x1128>
1008439a8:     	lsr	x8, x21, #52
1008439ac:     	cbnz	x8, 0x100843848 <_js_json_stringify_full+0x888>
1008439b0:     	cbz	x21, 0x100844060 <_js_json_stringify_full+0x10a0>
1008439b4:     	and	x8, x21, #0x7
1008439b8:     	cbnz	x8, 0x100844060 <_js_json_stringify_full+0x10a0>
1008439bc:     	mov	x0, x21
1008439c0:     	bl	0x10050c938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
1008439c4:     	mov	x25, x21
1008439c8:     	cbnz	w0, 0x10084389c <_js_json_stringify_full+0x8dc>
1008439cc:     	b	0x100844060 <_js_json_stringify_full+0x10a0>
1008439d0:     	sturb	wzr, [x29, #-0x7c]
1008439d4:     	stur	wzr, [x29, #-0x80]
1008439d8:     	ubfx	x1, x22, #40, #8
1008439dc:     	cbz	x1, 0x100843a2c <_js_json_stringify_full+0xa6c>
1008439e0:     	sturb	w22, [x29, #-0x80]
1008439e4:     	cmp	x1, #0x1
1008439e8:     	b.eq	0x100843a2c <_js_json_stringify_full+0xa6c>
1008439ec:     	lsr	x8, x22, #8
1008439f0:     	sturb	w8, [x29, #-0x7f]
1008439f4:     	cmp	x1, #0x2
1008439f8:     	b.eq	0x100843a2c <_js_json_stringify_full+0xa6c>
1008439fc:     	lsr	x8, x22, #16
100843a00:     	sturb	w8, [x29, #-0x7e]
100843a04:     	cmp	x1, #0x3
100843a08:     	b.eq	0x100843a2c <_js_json_stringify_full+0xa6c>
100843a0c:     	lsr	x8, x22, #24
100843a10:     	sturb	w8, [x29, #-0x7d]
100843a14:     	cmp	x1, #0x4
100843a18:     	b.eq	0x100843a2c <_js_json_stringify_full+0xa6c>
100843a1c:     	lsr	x8, x22, #32
100843a20:     	sturb	w8, [x29, #-0x7c]
100843a24:     	cmp	x1, #0x5
100843a28:     	b.ne	0x100845444 <_js_json_stringify_full+0x2484>
100843a2c:     	add	x8, sp, #0x60
100843a30:     	sub	x0, x29, #0x80
100843a34:     	bl	0x10002b398 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100843a38:     	ldr	w8, [sp, #0x60]
100843a3c:     	ldp	x9, x22, [sp, #0x68]
100843a40:     	cmp	w8, #0x0
100843a44:     	csinc	x23, x9, xzr, eq
100843a48:     	csel	x25, xzr, x22, ne
100843a4c:     	tbz	x25, #0x3f, 0x100843b8c <_js_json_stringify_full+0xbcc>
100843a50:     	mov	x0, #0x0                ; =0
100843a54:     	mov	x1, x22
100843a58:     	bl	0x100b0fd80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100843a5c:     	add	x8, x20, #0x3
100843a60:     	cmp	x22, x8
100843a64:     	b.eq	0x100843830 <_js_json_stringify_full+0x870>
100843a68:     	fmov	d0, x22
100843a6c:     	fcvtzu	x8, d0
100843a70:     	mov	w9, #0xa                ; =10
100843a74:     	cmp	x8, #0xa
100843a78:     	csel	x3, x8, x9, lo
100843a7c:     	adrp	x1, 0x100c41000 <_PERRY_EMPTY_STRING+0x20a4>
100843a80:     	add	x1, x1, #0xec
100843a84:     	add	x0, sp, #0x60
100843a88:     	mov	w2, #0x1                ; =1
100843a8c:     	bl	0x10022dcb4 <__RNvMNtCsctvjasLqLe9_5alloc5sliceSh6repeatCs3gRpqoBkMHm_13perry_runtime>
100843a90:     	ldr	x22, [sp, #0x70]
100843a94:     	str	x22, [sp, #0x40]
100843a98:     	ldr	q0, [sp, #0x60]
100843a9c:     	str	q0, [sp, #0x30]
100843aa0:     	b	0x100843840 <_js_json_stringify_full+0x880>
100843aa4:     	ldr	w22, [x8, #0x4]
100843aa8:     	add	x9, x8, #0x14
100843aac:     	mov	x14, #0x0               ; =0
100843ab0:     	mov	x8, #0x0                ; =0
100843ab4:     	cmp	x9, #0x0
100843ab8:     	csel	x24, xzr, x22, eq
100843abc:     	csinc	x23, x9, xzr, ne
100843ac0:     	add	x9, x23, x24
100843ac4:     	mov	w10, #0x1               ; =1
100843ac8:     	mov	x11, x23
100843acc:     	b	0x100843afc <_js_json_stringify_full+0xb3c>
100843ad0:     	add	x12, x11, #0x2
100843ad4:     	bfi	w15, w13, #6, #5
100843ad8:     	mov	x13, x15
100843adc:     	sub	x11, x25, x11
100843ae0:     	add	x14, x11, x12
100843ae4:     	cmp	w13, #0x10, lsl #12     ; =0x10000
100843ae8:     	cinc	x11, x10, hs
100843aec:     	add	x8, x11, x8
100843af0:     	mov	x11, x12
100843af4:     	cmp	x8, #0xa
100843af8:     	b.hi	0x100843bb4 <_js_json_stringify_full+0xbf4>
100843afc:     	cmp	x11, x9
100843b00:     	b.eq	0x100843b64 <_js_json_stringify_full+0xba4>
100843b04:     	mov	x25, x14
100843b08:     	mov	x12, x11
100843b0c:     	ldrsb	w14, [x12], #0x1
100843b10:     	and	w13, w14, #0xff
100843b14:     	tbz	w14, #0x1f, 0x100843adc <_js_json_stringify_full+0xb1c>
100843b18:     	ldrb	w12, [x11, #0x1]
100843b1c:     	and	w15, w12, #0x3f
100843b20:     	cmp	w13, #0xe0
100843b24:     	b.lo	0x100843ad0 <_js_json_stringify_full+0xb10>
100843b28:     	and	w14, w13, #0x1f
100843b2c:     	ldrb	w12, [x11, #0x2]
100843b30:     	and	w12, w12, #0x3f
100843b34:     	orr	w15, w12, w15, lsl #6
100843b38:     	cmp	w13, #0xf0
100843b3c:     	b.lo	0x100843b58 <_js_json_stringify_full+0xb98>
100843b40:     	add	x12, x11, #0x4
100843b44:     	ldrb	w13, [x11, #0x3]
100843b48:     	and	w13, w13, #0x3f
100843b4c:     	orr	w13, w13, w15, lsl #6
100843b50:     	bfi	w13, w14, #18, #3
100843b54:     	b	0x100843adc <_js_json_stringify_full+0xb1c>
100843b58:     	add	x12, x11, #0x3
100843b5c:     	orr	w13, w15, w14, lsl #12
100843b60:     	b	0x100843adc <_js_json_stringify_full+0xb1c>
100843b64:     	cbz	x24, 0x100843be8 <_js_json_stringify_full+0xc28>
100843b68:     	mov	x0, x24
100843b6c:     	mov	w1, #0x1                ; =1
100843b70:     	bl	0x100b5cc08 <_mi_malloc_aligned>
100843b74:     	cbz	x0, 0x10084542c <_js_json_stringify_full+0x246c>
100843b78:     	mov	x26, x0
100843b7c:     	mov	x1, x23
100843b80:     	mov	x2, x24
100843b84:     	bl	0x100b5f82c <_writev+0x100b5f82c>
100843b88:     	b	0x100843bf0 <_js_json_stringify_full+0xc30>
100843b8c:     	cbz	x25, 0x100843bfc <_js_json_stringify_full+0xc3c>
100843b90:     	mov	x0, x25
100843b94:     	mov	w1, #0x1                ; =1
100843b98:     	bl	0x100b5cc08 <_mi_malloc_aligned>
100843b9c:     	cbz	x0, 0x100845438 <_js_json_stringify_full+0x2478>
100843ba0:     	mov	x24, x0
100843ba4:     	mov	x1, x23
100843ba8:     	mov	x2, x25
100843bac:     	bl	0x100b5f82c <_writev+0x100b5f82c>
100843bb0:     	b	0x100843c04 <_js_json_stringify_full+0xc44>
100843bb4:     	cbz	x25, 0x100843be8 <_js_json_stringify_full+0xc28>
100843bb8:     	cmp	x25, x24
100843bbc:     	b.hs	0x100843c10 <_js_json_stringify_full+0xc50>
100843bc0:     	ldrsb	w8, [x23, x25]
100843bc4:     	cmn	w8, #0x40
100843bc8:     	b.ge	0x100843c14 <_js_json_stringify_full+0xc54>
100843bcc:     	adrp	x4, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
100843bd0:     	add	x4, x4, #0x2b8
100843bd4:     	mov	x0, x23
100843bd8:     	mov	x1, x24
100843bdc:     	mov	x2, #0x0                ; =0
100843be0:     	mov	x3, x25
100843be4:     	bl	0x100b100f8 <__RNvNtCsjgY6bXVaRmE_4core3str16slice_error_fail>
100843be8:     	mov	x22, #0x0               ; =0
100843bec:     	mov	w26, #0x1               ; =1
100843bf0:     	stp	x22, x26, [sp, #0x30]
100843bf4:     	str	x22, [sp, #0x40]
100843bf8:     	b	0x100843840 <_js_json_stringify_full+0x880>
100843bfc:     	mov	x22, #0x0               ; =0
100843c00:     	mov	w24, #0x1               ; =1
100843c04:     	stp	x22, x24, [sp, #0x30]
100843c08:     	str	x22, [sp, #0x40]
100843c0c:     	b	0x100843840 <_js_json_stringify_full+0x880>
100843c10:     	b.ne	0x100843bcc <_js_json_stringify_full+0xc0c>
100843c14:     	tbz	x25, #0x3f, 0x100843c44 <_js_json_stringify_full+0xc84>
100843c18:     	mov	x0, #0x0                ; =0
100843c1c:     	mov	x1, x25
100843c20:     	bl	0x100b0fd80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100843c24:     	cmp	w11, #0x8
100843c28:     	b.eq	0x100843d7c <_js_json_stringify_full+0xdbc>
100843c2c:     	cmp	w11, #0x9
100843c30:     	b.eq	0x100843d8c <_js_json_stringify_full+0xdcc>
100843c34:     	cmp	w11, #0xa
100843c38:     	b.ne	0x100843cb0 <_js_json_stringify_full+0xcf0>
100843c3c:     	mov	w10, #0x6e              ; =110
100843c40:     	b	0x100843d90 <_js_json_stringify_full+0xdd0>
100843c44:     	mov	x0, x25
100843c48:     	mov	w1, #0x1                ; =1
100843c4c:     	bl	0x100b5cc08 <_mi_malloc_aligned>
100843c50:     	mov	x26, x0
100843c54:     	mov	w0, #0x1                ; =1
100843c58:     	cbz	x26, 0x100843c1c <_js_json_stringify_full+0xc5c>
100843c5c:     	mov	x0, x26
100843c60:     	mov	x1, x23
100843c64:     	mov	x2, x25
100843c68:     	bl	0x100b5f82c <_writev+0x100b5f82c>
100843c6c:     	mov	x22, x25
100843c70:     	b	0x100843bf0 <_js_json_stringify_full+0xc30>
100843c74:     	mov	x26, x0
100843c78:     	and	x0, x19, #0xffffffffffff
100843c7c:     	bl	0x100345380 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
100843c80:     	cbz	x0, 0x100843db4 <_js_json_stringify_full+0xdf4>
100843c84:     	ldr	w20, [x0]
100843c88:     	cmp	w20, #0x4
100843c8c:     	b.hi	0x100843580 <_js_json_stringify_full+0x5c0>
100843c90:     	ldr	w8, [x0, #0x4]
100843c94:     	cmp	w20, w8
100843c98:     	b.hi	0x100843580 <_js_json_stringify_full+0x5c0>
100843c9c:     	b	0x100843db8 <_js_json_stringify_full+0xdf8>
100843ca0:     	cmp	w11, #0x22
100843ca4:     	b.eq	0x100843d90 <_js_json_stringify_full+0xdd0>
100843ca8:     	cmp	w11, #0x5c
100843cac:     	b.eq	0x100843d90 <_js_json_stringify_full+0xdd0>
100843cb0:     	cmp	x12, #0x3
100843cb4:     	mov	w11, #0x20              ; =32
100843cb8:     	ccmp	w10, w11, #0x8, ls
100843cbc:     	b.lt	0x1008434bc <_js_json_stringify_full+0x4fc>
100843cc0:     	add	x8, sp, #0x60
100843cc4:     	strb	w10, [x8, x12]
100843cc8:     	add	x12, x12, #0x1
100843ccc:     	b	0x1008431ac <_js_json_stringify_full+0x1ec>
100843cd0:     	mov	x1, x0
100843cd4:     	and	x0, x19, #0xffffffffffff
100843cd8:     	mov	x26, x1
100843cdc:     	bl	0x1004f6dc0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output20emit_repeated_output>
100843ce0:     	cmp	x0, #0x1
100843ce4:     	b.eq	0x1008435a0 <_js_json_stringify_full+0x5e0>
100843ce8:     	and	x0, x19, #0xffffffffffff
100843cec:     	bl	0x100345380 <__RNvNtCs3gRpqoBkMHm_13perry_runtime6object17object_keys_array>
100843cf0:     	cbz	x0, 0x100843e7c <_js_json_stringify_full+0xebc>
100843cf4:     	ldr	w20, [x0]
100843cf8:     	cbz	w20, 0x100843e7c <_js_json_stringify_full+0xebc>
100843cfc:     	cmp	w20, #0x8
100843d00:     	b.hi	0x10084354c <_js_json_stringify_full+0x58c>
100843d04:     	ldr	w8, [x0, #0x4]
100843d08:     	cmp	w20, w8
100843d0c:     	b.hi	0x10084354c <_js_json_stringify_full+0x58c>
100843d10:     	ldr	w8, [x26, #0x4]
100843d14:     	lsl	x9, x20, #3
100843d18:     	add	x9, x9, #0x18
100843d1c:     	cmp	x9, x8
100843d20:     	b.hi	0x10084354c <_js_json_stringify_full+0x58c>
100843d24:     	ldr	w8, [x25, #0x4]
100843d28:     	mov	w9, #-0x40000000        ; =-1073741824
100843d2c:     	cmp	w8, w9
100843d30:     	csel	w8, w8, wzr, lt
100843d34:     	mov	x26, x0
100843d38:     	mov	x0, x8
100843d3c:     	bl	0x1005e2b24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100843d40:     	mov	w9, #0x2                ; =2
100843d44:     	cmp	w1, #0x2
100843d48:     	csel	w10, w1, w9, hi
100843d4c:     	tst	w0, #0x1
100843d50:     	csel	w8, w10, w9, ne
100843d54:     	cmp	w20, w8
100843d58:     	b.hi	0x10084354c <_js_json_stringify_full+0x58c>
100843d5c:     	mov	x0, x26
100843d60:     	mov	x1, x20
100843d64:     	bl	0x1004ed500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100843d68:     	cbz	w0, 0x10084354c <_js_json_stringify_full+0x58c>
100843d6c:     	and	x0, x19, #0xffffffffffff
100843d70:     	mov	x1, x20
100843d74:     	bl	0x1004f5f00 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output11emit_record>
100843d78:     	b	0x100843e84 <_js_json_stringify_full+0xec4>
100843d7c:     	mov	w10, #0x62              ; =98
100843d80:     	b	0x100843d90 <_js_json_stringify_full+0xdd0>
100843d84:     	mov	w10, #0x66              ; =102
100843d88:     	b	0x100843d90 <_js_json_stringify_full+0xdd0>
100843d8c:     	mov	w10, #0x74              ; =116
100843d90:     	cmp	x12, #0x2
100843d94:     	b.hi	0x1008434bc <_js_json_stringify_full+0x4fc>
100843d98:     	add	x8, sp, #0x60
100843d9c:     	add	x8, x8, x12
100843da0:     	add	x12, x12, #0x2
100843da4:     	mov	w11, #0x5c              ; =92
100843da8:     	strb	w11, [x8]
100843dac:     	strb	w10, [x8, #0x1]
100843db0:     	b	0x1008431ac <_js_json_stringify_full+0x1ec>
100843db4:     	mov	x20, #0x0               ; =0
100843db8:     	ldr	w8, [x26, #0x4]
100843dbc:     	lsl	x9, x20, #3
100843dc0:     	add	x9, x9, #0x18
100843dc4:     	cmp	x9, x8
100843dc8:     	b.hi	0x100843580 <_js_json_stringify_full+0x5c0>
100843dcc:     	ldr	w8, [x25, #0x4]
100843dd0:     	mov	w9, #-0x40000000        ; =-1073741824
100843dd4:     	cmp	w8, w9
100843dd8:     	csel	w8, w8, wzr, lt
100843ddc:     	mov	x26, x0
100843de0:     	mov	x0, x8
100843de4:     	bl	0x1005e2b24 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6object6shapes34shape_live_inline_slot_count_by_id>
100843de8:     	mov	w9, #0x2                ; =2
100843dec:     	cmp	w1, #0x2
100843df0:     	csel	w10, w1, w9, hi
100843df4:     	tst	w0, #0x1
100843df8:     	csel	x8, x10, x9, ne
100843dfc:     	cmp	x20, x8
100843e00:     	b.hi	0x100843580 <_js_json_stringify_full+0x5c0>
100843e04:     	cbz	x20, 0x100844108 <_js_json_stringify_full+0x1148>
100843e08:     	mov	x0, x26
100843e0c:     	mov	x1, x20
100843e10:     	bl	0x1004ed500 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat22bounded_keys_are_dense>
100843e14:     	tbz	w0, #0x0, 0x100843580 <_js_json_stringify_full+0x5c0>
100843e18:     	cmp	x20, #0x1
100843e1c:     	b.eq	0x100844e38 <_js_json_stringify_full+0x1e78>
100843e20:     	cmp	x20, #0x2
100843e24:     	b.ne	0x100844e44 <_js_json_stringify_full+0x1e84>
100843e28:     	ldr	x1, [x25, #0x10]
100843e2c:     	add	x0, sp, #0x80
100843e30:     	bl	0x1004ed554 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
100843e34:     	ldr	w8, [sp, #0x80]
100843e38:     	cmn	w8, #0x1
100843e3c:     	b.eq	0x100844ec4 <_js_json_stringify_full+0x1f04>
100843e40:     	mov	x1, #0x0                ; =0
100843e44:     	b	0x100844ee0 <_js_json_stringify_full+0x1f20>
100843e48:     	ldrb	w9, [x8, #0x118]
100843e4c:     	cbz	w9, 0x100843f10 <_js_json_stringify_full+0xf50>
100843e50:     	ldr	x9, [x8, #0x110]
100843e54:     	cmp	x9, x1
100843e58:     	b.ne	0x100843f10 <_js_json_stringify_full+0xf50>
100843e5c:     	ldr	x9, [x8, #0xf0]
100843e60:     	cmp	x9, x25
100843e64:     	b.hi	0x100843f10 <_js_json_stringify_full+0xf50>
100843e68:     	ldr	x9, [x8, #0xf8]
100843e6c:     	cmp	x9, x25
100843e70:     	b.ls	0x100843f10 <_js_json_stringify_full+0xf50>
100843e74:     	add	x9, x8, #0xf0
100843e78:     	b	0x1008440e8 <_js_json_stringify_full+0x1128>
100843e7c:     	and	x0, x19, #0xffffffffffff
100843e80:     	bl	0x1004f6c80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json23stringify_record_output17emit_empty_object>
100843e84:     	mov	x20, x1
100843e88:     	tbz	w0, #0x0, 0x10084354c <_js_json_stringify_full+0x58c>
100843e8c:     	b	0x1008449dc <_js_json_stringify_full+0x1a1c>
100843e90:     	add	x9, x8, #0x60
100843e94:     	b	0x1008440e8 <_js_json_stringify_full+0x1128>
100843e98:     	bl	0x100b3cdbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100843e9c:     	lsr	x1, x25, #20
100843ea0:     	ldr	x8, [x0, #0x10]
100843ea4:     	ldrb	w9, [x8]
100843ea8:     	cmp	w9, #0x2
100843eac:     	b.eq	0x10084392c <_js_json_stringify_full+0x96c>
100843eb0:     	ldr	x9, [x8, #0x8]
100843eb4:     	ldr	x10, [x8, #0x28]
100843eb8:     	sub	x9, x1, x9
100843ebc:     	cmp	x9, x10
100843ec0:     	b.hs	0x100843f04 <_js_json_stringify_full+0xf44>
100843ec4:     	ldr	x10, [x8, #0x20]
100843ec8:     	mov	w11, #0x28              ; =40
100843ecc:     	madd	x9, x9, x11, x10
100843ed0:     	ldr	x10, [x9]
100843ed4:     	ldr	x11, [x8, #0x10]
100843ed8:     	cmp	x10, x11
100843edc:     	b.ne	0x100843f10 <_js_json_stringify_full+0xf50>
100843ee0:     	ldp	x10, x11, [x9, #0x8]
100843ee4:     	cmp	x10, x25
100843ee8:     	ccmp	x11, x25, #0x0, ls
100843eec:     	b.ls	0x100843f10 <_js_json_stringify_full+0xf50>
100843ef0:     	ldr	x10, [x8, #0x30]
100843ef4:     	add	x10, x10, #0x1
100843ef8:     	str	x10, [x8, #0x30]
100843efc:     	add	x8, x9, #0x21
100843f00:     	b	0x1008440f8 <_js_json_stringify_full+0x1138>
100843f04:     	ldr	x9, [x8, #0x58]
100843f08:     	add	x9, x9, #0x1
100843f0c:     	str	x9, [x8, #0x58]
100843f10:     	ldr	x9, [x8, #0x38]
100843f14:     	add	x9, x9, #0x1
100843f18:     	str	x9, [x8, #0x38]
100843f1c:     	mov	x0, x25
100843f20:     	bl	0x10051bb48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100843f24:     	and	w8, w0, #0xff
100843f28:     	cbz	w8, 0x100843f48 <_js_json_stringify_full+0xf88>
100843f2c:     	ldurb	w8, [x25, #-0x8]
100843f30:     	ldurb	w9, [x25, #-0x7]
100843f34:     	mov	w10, #0x82              ; =130
100843f38:     	and	w9, w9, w10
100843f3c:     	cmp	w9, #0x2
100843f40:     	ccmp	w8, #0x1, #0x0, eq
100843f44:     	b.eq	0x100843fe4 <_js_json_stringify_full+0x1024>
100843f48:     	mov	x0, x25
100843f4c:     	bl	0x1005781c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100843f50:     	mov	x26, x0
100843f54:     	cbz	x0, 0x100843f80 <_js_json_stringify_full+0xfc0>
100843f58:     	ldrb	w8, [x26]
100843f5c:     	cmp	w8, #0x1
100843f60:     	b.ne	0x100843fa0 <_js_json_stringify_full+0xfe0>
100843f64:     	ldrsb	w8, [x26, #0x1]
100843f68:     	tbnz	w8, #0x1f, 0x10084400c <_js_json_stringify_full+0x104c>
100843f6c:     	mov	x0, x26
100843f70:     	ldp	w9, w8, [x25]
100843f74:     	cmp	w9, w8
100843f78:     	b.ls	0x1008441a0 <_js_json_stringify_full+0x11e0>
100843f7c:     	b	0x100844188 <_js_json_stringify_full+0x11c8>
100843f80:     	mov	x0, x25
100843f84:     	bl	0x100586634 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100843f88:     	tbnz	w0, #0x0, 0x100843f98 <_js_json_stringify_full+0xfd8>
100843f8c:     	mov	x0, x25
100843f90:     	bl	0x1002a1608 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
100843f94:     	tbz	w0, #0x0, 0x100844268 <_js_json_stringify_full+0x12a8>
100843f98:     	mov	x0, #0x0                ; =0
100843f9c:     	b	0x100844178 <_js_json_stringify_full+0x11b8>
100843fa0:     	mov	x0, x26
100843fa4:     	cmp	w8, #0x1
100843fa8:     	b.eq	0x100844178 <_js_json_stringify_full+0x11b8>
100843fac:     	mov	x28, x22
100843fb0:     	cmp	w8, #0x9
100843fb4:     	b.ne	0x100844048 <_js_json_stringify_full+0x1088>
100843fb8:     	ldr	w8, [x25, #0x4]
100843fbc:     	mov	w9, #0x5841             ; =22593
100843fc0:     	movk	w9, #0x4c5a, lsl #16
100843fc4:     	cmp	w8, w9
100843fc8:     	b.ne	0x100844048 <_js_json_stringify_full+0x1088>
100843fcc:     	mov	x0, x25
100843fd0:     	bl	0x1003730f0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100843fd4:     	mov	x25, x0
100843fd8:     	mov	x22, x28
100843fdc:     	cbnz	x0, 0x1008441c8 <_js_json_stringify_full+0x1208>
100843fe0:     	b	0x100844048 <_js_json_stringify_full+0x1088>
100843fe4:     	ldr	w8, [x25]
100843fe8:     	mov	w9, #0xe100             ; =57600
100843fec:     	movk	w9, #0x5f5, lsl #16
100843ff0:     	orr	w9, w9, #0x1
100843ff4:     	cmp	w8, w9
100843ff8:     	b.hs	0x100843f48 <_js_json_stringify_full+0xf88>
100843ffc:     	ldr	w9, [x25, #0x4]
100844000:     	cmp	w8, w9
100844004:     	b.ls	0x1008441c8 <_js_json_stringify_full+0x1208>
100844008:     	b	0x100843f48 <_js_json_stringify_full+0xf88>
10084400c:     	mov	x28, x22
100844010:     	ldr	x25, [x26, #0x8]
100844014:     	mov	x0, x25
100844018:     	bl	0x1005781c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
10084401c:     	cbz	x0, 0x100844048 <_js_json_stringify_full+0x1088>
100844020:     	ldrb	w8, [x0]
100844024:     	cmp	w8, #0x1
100844028:     	b.ne	0x100844048 <_js_json_stringify_full+0x1088>
10084402c:     	ldrsb	w8, [x0, #0x1]
100844030:     	tbnz	w8, #0x1f, 0x100844124 <_js_json_stringify_full+0x1164>
100844034:     	mov	x22, x28
100844038:     	ldp	w9, w8, [x25]
10084403c:     	cmp	w9, w8
100844040:     	b.hi	0x100844188 <_js_json_stringify_full+0x11c8>
100844044:     	b	0x1008441a0 <_js_json_stringify_full+0x11e0>
100844048:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
10084404c:     	cmp	x27, x8
100844050:     	b.eq	0x100844278 <_js_json_stringify_full+0x12b8>
100844054:     	lsr	x8, x21, #52
100844058:     	mov	x22, x28
10084405c:     	cbnz	x8, 0x100844288 <_js_json_stringify_full+0x12c8>
100844060:     	mov	w24, #0x0               ; =0
100844064:     	mov	w26, #0x1               ; =1
100844068:     	cbz	x21, 0x1008440d0 <_js_json_stringify_full+0x1110>
10084406c:     	and	x8, x21, #0x7
100844070:     	cbnz	x8, 0x1008440d0 <_js_json_stringify_full+0x1110>
100844074:     	mov	x0, x21
100844078:     	bl	0x10050c938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
10084407c:     	tbz	w0, #0x0, 0x1008440d8 <_js_json_stringify_full+0x1118>
100844080:     	mov	x8, x21
100844084:     	cmp	x21, #0x100, lsl #12    ; =0x100000
100844088:     	b.lo	0x100844288 <_js_json_stringify_full+0x12c8>
10084408c:     	mov	x9, #-0x1               ; =-1
100844090:     	ldr	w8, [x8, #0xc]
100844094:     	mov	w10, #0x4f53            ; =20307
100844098:     	movk	w10, #0x434c, lsl #16
10084409c:     	and	x11, x21, #0xffffffffffff
1008440a0:     	mov	x12, #0x7ffd000000000000 ; =9222527611924643840
1008440a4:     	cmp	x27, x12
1008440a8:     	csel	x11, x11, x21, eq
1008440ac:     	mov	x12, #-0x1              ; =-1
1008440b0:     	mov	w13, #0x1               ; =1
1008440b4:     	cmp	w8, w10
1008440b8:     	csinc	w26, w13, wzr, eq
1008440bc:     	csel	x27, x9, x12, ne
1008440c0:     	cset	w24, eq
1008440c4:     	csel	x8, x8, x11, ne
1008440c8:     	str	x8, [sp, #0x20]
1008440cc:     	b	0x100844294 <_js_json_stringify_full+0x12d4>
1008440d0:     	mov	x27, #-0x1              ; =-1
1008440d4:     	b	0x100844294 <_js_json_stringify_full+0x12d4>
1008440d8:     	mov	w24, #0x0               ; =0
1008440dc:     	mov	x27, #-0x1              ; =-1
1008440e0:     	b	0x100844294 <_js_json_stringify_full+0x12d4>
1008440e4:     	add	x9, x8, #0x90
1008440e8:     	ldr	x10, [x8, #0x30]
1008440ec:     	add	x10, x10, #0x1
1008440f0:     	str	x10, [x8, #0x30]
1008440f4:     	add	x8, x9, #0x19
1008440f8:     	ldrb	w8, [x8]
1008440fc:     	cmp	w8, #0xff
100844100:     	b.ne	0x100843f28 <_js_json_stringify_full+0xf68>
100844104:     	b	0x100843f1c <_js_json_stringify_full+0xf5c>
100844108:     	and	x0, x19, #0xffffffffffff
10084410c:     	bl	0x1004f5d30 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json22stringify_tojson_probe36to_json_definitely_absent_without_gc>
100844110:     	tbz	w0, #0x0, 0x100843580 <_js_json_stringify_full+0x5c0>
100844114:     	mov	x20, #0x7d7b            ; =32123
100844118:     	movk	x20, #0x200, lsl #32
10084411c:     	movk	x20, #0x7ff9, lsl #48
100844120:     	b	0x1008449dc <_js_json_stringify_full+0x1a1c>
100844124:     	mov	w22, #0x1               ; =1
100844128:     	ldr	x25, [x0, #0x8]
10084412c:     	mov	x0, x25
100844130:     	bl	0x1005781c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100844134:     	cbz	x0, 0x10084426c <_js_json_stringify_full+0x12ac>
100844138:     	ldrb	w8, [x0]
10084413c:     	cmp	w8, #0x1
100844140:     	b.ne	0x10084426c <_js_json_stringify_full+0x12ac>
100844144:     	cmp	w22, #0x3f
100844148:     	b.hi	0x10084426c <_js_json_stringify_full+0x12ac>
10084414c:     	add	w22, w22, #0x1
100844150:     	ldrsb	w8, [x0, #0x1]
100844154:     	tbnz	w8, #0x1f, 0x100844128 <_js_json_stringify_full+0x1168>
100844158:     	str	x25, [x26, #0x8]
10084415c:     	ldrb	w8, [x26, #0x1]
100844160:     	orr	w8, w8, #0x80
100844164:     	strb	w8, [x26, #0x1]
100844168:     	ldrb	w8, [x0]
10084416c:     	mov	x22, x28
100844170:     	cmp	w8, #0x1
100844174:     	b.ne	0x100843fac <_js_json_stringify_full+0xfec>
100844178:     	ldp	w9, w8, [x25]
10084417c:     	cmp	w9, w8
100844180:     	b.ls	0x1008441a0 <_js_json_stringify_full+0x11e0>
100844184:     	cbz	x26, 0x1008441b0 <_js_json_stringify_full+0x11f0>
100844188:     	ldr	w9, [x0, #0x4]
10084418c:     	ubfiz	x8, x8, #3, #32
100844190:     	add	x8, x8, #0x10
100844194:     	cmp	x8, x9
100844198:     	b.eq	0x1008441c8 <_js_json_stringify_full+0x1208>
10084419c:     	b	0x1008441b0 <_js_json_stringify_full+0x11f0>
1008441a0:     	mov	w8, #0xe100             ; =57600
1008441a4:     	movk	w8, #0x5f5, lsl #16
1008441a8:     	cmp	w9, w8
1008441ac:     	b.ls	0x1008441c8 <_js_json_stringify_full+0x1208>
1008441b0:     	mov	x0, x25
1008441b4:     	bl	0x100586634 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
1008441b8:     	tbnz	w0, #0x0, 0x1008441c8 <_js_json_stringify_full+0x1208>
1008441bc:     	mov	x0, x25
1008441c0:     	bl	0x1002a1608 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray23lookup_typed_array_kind>
1008441c4:     	tbz	w0, #0x0, 0x100844268 <_js_json_stringify_full+0x12a8>
1008441c8:     	ldp	w8, w9, [x25]
1008441cc:     	sub	w10, w9, #0x1
1008441d0:     	mov	w11, #0x270e            ; =9998
1008441d4:     	cmp	w10, w11
1008441d8:     	ccmp	w8, w9, #0x2, ls
1008441dc:     	b.hi	0x100844268 <_js_json_stringify_full+0x12a8>
1008441e0:     	and	x8, x21, #0xffffffffffff
1008441e4:     	mov	x9, #0x7ffd000000000000 ; =9222527611924643840
1008441e8:     	cmp	x27, x9
1008441ec:     	csel	x23, x8, x21, eq
1008441f0:     	lsr	x9, x23, #51
1008441f4:     	cmp	x9, #0xfff
1008441f8:     	b.lo	0x100844214 <_js_json_stringify_full+0x1254>
1008441fc:     	lsr	x9, x23, #48
100844200:     	mov	w10, #0x7ffc            ; =32764
100844204:     	cmp	x9, x10
100844208:     	ccmp	x8, #0x0, #0x4, ne
10084420c:     	and	x23, x21, #0xffffffffffff
100844210:     	b.eq	0x10084501c <_js_json_stringify_full+0x205c>
100844214:     	sub	x8, x23, #0x100, lsl #12 ; =0x100000
100844218:     	mov	x9, #0x7fffffffffff     ; =140737488355327
10084421c:     	movk	x9, #0xffef, lsl #16
100844220:     	cmp	x8, x9
100844224:     	b.hi	0x10084501c <_js_json_stringify_full+0x205c>
100844228:     	tst	x23, #0x3
10084422c:     	b.eq	0x100844aac <_js_json_stringify_full+0x1aec>
100844230:     	mov	x0, x23
100844234:     	bl	0x1005781c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100844238:     	str	x22, [sp, #0x10]
10084423c:     	cbz	x0, 0x100844b3c <_js_json_stringify_full+0x1b7c>
100844240:     	ldrb	w8, [x0]
100844244:     	cmp	w8, #0x1
100844248:     	b.ne	0x100844b58 <_js_json_stringify_full+0x1b98>
10084424c:     	ldrsb	w8, [x0, #0x1]
100844250:     	tbnz	w8, #0x1f, 0x100844c9c <_js_json_stringify_full+0x1cdc>
100844254:     	ldp	w9, w8, [x23]
100844258:     	cmp	w9, w8
10084425c:     	ldr	x22, [sp, #0x10]
100844260:     	b.hi	0x100844d4c <_js_json_stringify_full+0x1d8c>
100844264:     	b	0x100844d88 <_js_json_stringify_full+0x1dc8>
100844268:     	mov	x28, x22
10084426c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100844270:     	cmp	x27, x8
100844274:     	b.ne	0x100844054 <_js_json_stringify_full+0x1094>
100844278:     	and	x8, x21, #0xffffffffffff
10084427c:     	mov	x22, x28
100844280:     	cmp	x8, #0x100, lsl #12     ; =0x100000
100844284:     	b.hs	0x10084408c <_js_json_stringify_full+0x10cc>
100844288:     	mov	w24, #0x0               ; =0
10084428c:     	mov	x27, #-0x1              ; =-1
100844290:     	mov	w26, #0x1               ; =1
100844294:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100844298:     	add	x0, x0, #0xd78
10084429c:     	ldr	x8, [x0]
1008442a0:     	blr	x8
1008442a4:     	mov	x21, x0
1008442a8:     	ldr	w28, [x0]
1008442ac:     	add	w8, w28, #0x1
1008442b0:     	str	w8, [x0]
1008442b4:     	cbz	w28, 0x100844324 <_js_json_stringify_full+0x1364>
1008442b8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008442bc:     	add	x0, x0, #0xd00
1008442c0:     	ldr	x8, [x0]
1008442c4:     	blr	x8
1008442c8:     	ldrb	w8, [x0, #0x20]
1008442cc:     	cmp	w8, #0x1
1008442d0:     	b.ne	0x100844c84 <_js_json_stringify_full+0x1cc4>
1008442d4:     	ldr	x8, [x0]
1008442d8:     	cbnz	x8, 0x100844c90 <_js_json_stringify_full+0x1cd0>
1008442dc:     	mov	x8, #-0x1               ; =-1
1008442e0:     	str	x8, [x0]
1008442e4:     	ldr	x25, [x0, #0x18]
1008442e8:     	ldr	x8, [x0, #0x8]
1008442ec:     	cmp	x25, x8
1008442f0:     	b.eq	0x100844a04 <_js_json_stringify_full+0x1a44>
1008442f4:     	ldr	x8, [x0, #0x10]
1008442f8:     	mov	w9, #0x18               ; =24
1008442fc:     	madd	x8, x25, x9, x8
100844300:     	mov	w9, #0x8                ; =8
100844304:     	stp	xzr, x9, [x8]
100844308:     	str	xzr, [x8, #0x10]
10084430c:     	add	x8, x25, #0x1
100844310:     	str	x8, [x0, #0x18]
100844314:     	ldr	x8, [x0]
100844318:     	add	x8, x8, #0x1
10084431c:     	str	x8, [x0]
100844320:     	b	0x10084438c <_js_json_stringify_full+0x13cc>
100844324:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100844328:     	add	x0, x0, #0xdc0
10084432c:     	ldr	x8, [x0]
100844330:     	blr	x8
100844334:     	strb	wzr, [x0]
100844338:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
10084433c:     	add	x0, x0, #0xdf0
100844340:     	ldr	x8, [x0]
100844344:     	blr	x8
100844348:     	strb	wzr, [x0]
10084434c:     	adrp	x8, 0x100f7e000 <__MergedGlobals.1917+0xc8>
100844350:     	ldr	w25, [x8, #0x5a8]
100844354:     	cmp	w25, #0x300
100844358:     	b.hs	0x100844a74 <_js_json_stringify_full+0x1ab4>
10084435c:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100844360:     	ldr	x8, [x8, #0x48]
100844364:     	cmn	x8, #0x1
100844368:     	b.eq	0x100844a64 <_js_json_stringify_full+0x1aa4>
10084436c:     	mrs	x9, TPIDRRO_EL0
100844370:     	and	x9, x9, #0xfffffffffffffff8
100844374:     	ldr	x0, [x9, x8, lsl #3]
100844378:     	cbz	x0, 0x100844a64 <_js_json_stringify_full+0x1aa4>
10084437c:     	add	x8, x0, x25, lsl #3
100844380:     	ldr	x0, [x8, #0x1e8]
100844384:     	cbz	x0, 0x100844a74 <_js_json_stringify_full+0x1ab4>
100844388:     	str	xzr, [x0]
10084438c:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100844390:     	add	x0, x0, #0xd30
100844394:     	ldr	x8, [x0]
100844398:     	blr	x8
10084439c:     	mov	x25, x0
1008443a0:     	ldrb	w8, [x0, #0x18]
1008443a4:     	cmp	w8, #0x1
1008443a8:     	b.ne	0x100844ba4 <_js_json_stringify_full+0x1be4>
1008443ac:     	ldr	x8, [x0]
1008443b0:     	mov	x9, #-0x1               ; =-1
1008443b4:     	str	x9, [x0]
1008443b8:     	cmn	x8, #0x2
1008443bc:     	b.eq	0x100844e90 <_js_json_stringify_full+0x1ed0>
1008443c0:     	cmn	x8, #0x1
1008443c4:     	b.eq	0x10084449c <_js_json_stringify_full+0x14dc>
1008443c8:     	sub	x9, x29, #0x80
1008443cc:     	ldur	q0, [x0, #0x8]
1008443d0:     	stur	q0, [x9, #0x8]
1008443d4:     	stur	x8, [x29, #-0x80]
1008443d8:     	tbz	w26, #0x0, 0x1008444b0 <_js_json_stringify_full+0x14f0>
1008443dc:     	tbz	w24, #0x0, 0x1008445a0 <_js_json_stringify_full+0x15e0>
1008443e0:     	bl	0x100288ad8 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope3new>
1008443e4:     	str	x0, [sp, #0x48]
1008443e8:     	mov	x10, #0x7ffd000000000000 ; =9222527611924643840
1008443ec:     	mov	w8, #0x1                ; =1
1008443f0:     	ldr	x9, [sp, #0x20]
1008443f4:     	stp	x9, x10, [sp, #0x68]
1008443f8:     	str	x8, [sp, #0x60]
1008443fc:     	add	x0, sp, #0x60
100844400:     	bl	0x100288be0 <__RNvMs_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB4_18RuntimeHandleScope4push>
100844404:     	mov	x22, x0
100844408:     	str	x0, [sp, #0x50]
10084440c:     	mov	w0, #0x0                ; =0
100844410:     	bl	0x1003488ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
100844414:     	stp	xzr, xzr, [x0]
100844418:     	str	wzr, [x0, #0x10]
10084441c:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100844420:     	bfxil	x8, x0, #0, #48
100844424:     	fmov	d0, x8
100844428:     	bl	0x1002087e4 <__RNCINvNtNtCs3gRpqoBkMHm_13perry_runtime11async_hooks6scopes23run_provider_completionNCNvNtNtB8_15node_submodules4blob25blob_reader_promise_value0Es0_0B8_>
10084442c:     	mov	x19, x0
100844430:     	adrp	x24, 0x100f7c000 <_perry_global_options_worker_ts__1>
100844434:     	ldr	x8, [x24, #0x48]
100844438:     	cmn	x8, #0x1
10084443c:     	b.eq	0x100844660 <_js_json_stringify_full+0x16a0>
100844440:     	mrs	x9, TPIDRRO_EL0
100844444:     	and	x9, x9, #0xfffffffffffffff8
100844448:     	ldr	x8, [x9, x8, lsl #3]
10084444c:     	cbz	x8, 0x100844660 <_js_json_stringify_full+0x16a0>
100844450:     	ldr	x8, [x8, #0x19e8]
100844454:     	cbz	x8, 0x100844660 <_js_json_stringify_full+0x16a0>
100844458:     	ldr	x9, [x8]
10084445c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100844460:     	cmp	x9, x10
100844464:     	b.hs	0x100844e78 <_js_json_stringify_full+0x1eb8>
100844468:     	add	x10, x9, #0x1
10084446c:     	str	x10, [x8]
100844470:     	ldr	x10, [x8, #0x18]
100844474:     	cmp	x19, x10
100844478:     	b.hs	0x100844e84 <_js_json_stringify_full+0x1ec4>
10084447c:     	ldr	x10, [x8, #0x10]
100844480:     	mov	w11, #0x18              ; =24
100844484:     	madd	x10, x19, x11, x10
100844488:     	ldr	x11, [x10]
10084448c:     	cbnz	x11, 0x100844e9c <_js_json_stringify_full+0x1edc>
100844490:     	ldr	x0, [x10, #0x8]
100844494:     	str	x9, [x8]
100844498:     	b	0x100844668 <_js_json_stringify_full+0x16a8>
10084449c:     	mov	x8, #0x0                ; =0
1008444a0:     	mov	w9, #0x1                ; =1
1008444a4:     	stp	x9, xzr, [x29, #-0x78]
1008444a8:     	stur	x8, [x29, #-0x80]
1008444ac:     	tbnz	w26, #0x0, 0x1008443dc <_js_json_stringify_full+0x141c>
1008444b0:     	cmp	x22, #0x0
1008444b4:     	cset	w6, ne
1008444b8:     	ldp	x3, x4, [sp, #0x38]
1008444bc:     	sub	x2, x29, #0x80
1008444c0:     	mov.16b	v0, v8
1008444c4:     	ldr	x24, [sp, #0x28]
1008444c8:     	mov	x0, x24
1008444cc:     	mov	x1, x23
1008444d0:     	mov	x5, #0x0                ; =0
1008444d4:     	bl	0x100500680 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer35stringify_value_with_array_replacer>
1008444d8:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008444dc:     	add	x0, x0, #0xd90
1008444e0:     	ldr	x8, [x0]
1008444e4:     	blr	x8
1008444e8:     	ldrb	w8, [x0, #0x20]
1008444ec:     	cbnz	w8, 0x100844dec <_js_json_stringify_full+0x1e2c>
1008444f0:     	ldr	x8, [x0]
1008444f4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
1008444f8:     	cmp	x8, x9
1008444fc:     	b.hs	0x100844e20 <_js_json_stringify_full+0x1e60>
100844500:     	ldr	x9, [x0, #0x18]
100844504:     	cbz	x9, 0x100844510 <_js_json_stringify_full+0x1550>
100844508:     	cbnz	x8, 0x100844e2c <_js_json_stringify_full+0x1e6c>
10084450c:     	str	xzr, [x0, #0x18]
100844510:     	ldp	x0, x1, [x29, #-0x78]
100844514:     	cmp	x1, #0x5
100844518:     	b.hi	0x100844580 <_js_json_stringify_full+0x15c0>
10084451c:     	cbz	x1, 0x100844800 <_js_json_stringify_full+0x1840>
100844520:     	ldrsb	w8, [x0]
100844524:     	tbnz	w8, #0x1f, 0x100844580 <_js_json_stringify_full+0x15c0>
100844528:     	cmp	x1, #0x1
10084452c:     	b.eq	0x100844568 <_js_json_stringify_full+0x15a8>
100844530:     	ldrsb	w8, [x0, #0x1]
100844534:     	tbnz	w8, #0x1f, 0x100844580 <_js_json_stringify_full+0x15c0>
100844538:     	cmp	x1, #0x2
10084453c:     	b.eq	0x100844568 <_js_json_stringify_full+0x15a8>
100844540:     	ldrsb	w8, [x0, #0x2]
100844544:     	tbnz	w8, #0x1f, 0x100844580 <_js_json_stringify_full+0x15c0>
100844548:     	cmp	x1, #0x3
10084454c:     	b.eq	0x100844568 <_js_json_stringify_full+0x15a8>
100844550:     	ldrsb	w8, [x0, #0x3]
100844554:     	tbnz	w8, #0x1f, 0x100844580 <_js_json_stringify_full+0x15c0>
100844558:     	cmp	x1, #0x4
10084455c:     	b.eq	0x100844568 <_js_json_stringify_full+0x15a8>
100844560:     	ldrsb	w8, [x0, #0x4]
100844564:     	tbnz	w8, #0x1f, 0x100844580 <_js_json_stringify_full+0x15c0>
100844568:     	cmp	x1, #0x4
10084456c:     	b.hs	0x100844870 <_js_json_stringify_full+0x18b0>
100844570:     	mov	x10, #0x0               ; =0
100844574:     	mov	x9, #0x0                ; =0
100844578:     	mov	x8, x0
10084457c:     	b	0x100844900 <_js_json_stringify_full+0x1940>
100844580:     	bl	0x1003275d0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json36json_string_from_native_output_bytes>
100844584:     	mov	x20, #0x7fff000000000000 ; =9223090561878065152
100844588:     	bfxil	x20, x0, #0, #48
10084458c:     	ldp	x22, x0, [x29, #-0x80]
100844590:     	ldrb	w8, [x25, #0x18]
100844594:     	cmp	w8, #0x1
100844598:     	b.eq	0x10084493c <_js_json_stringify_full+0x197c>
10084459c:     	b	0x100844c30 <_js_json_stringify_full+0x1c70>
1008445a0:     	mov	w0, #0x0                ; =0
1008445a4:     	bl	0x1003488ec <__RNvNtCs3gRpqoBkMHm_13perry_runtime6string20string_storage_alloc>
1008445a8:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008445ac:     	bfxil	x8, x0, #0, #48
1008445b0:     	fmov	d1, x8
1008445b4:     	stp	xzr, xzr, [x0]
1008445b8:     	str	wzr, [x0, #0x10]
1008445bc:     	mov.16b	v0, v8
1008445c0:     	bl	0x1004fd8bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
1008445c4:     	mov.16b	v8, v0
1008445c8:     	fmov	x26, d8
1008445cc:     	cmp	x26, x20
1008445d0:     	b.eq	0x1008445ec <_js_json_stringify_full+0x162c>
1008445d4:     	mov	x0, x26
1008445d8:     	bl	0x100507a7c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify16is_closure_value>
1008445dc:     	tbnz	w0, #0x0, 0x1008445ec <_js_json_stringify_full+0x162c>
1008445e0:     	mov	x0, x26
1008445e4:     	bl	0x100506c94 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15is_symbol_value>
1008445e8:     	tbz	w0, #0x0, 0x100844a34 <_js_json_stringify_full+0x1a74>
1008445ec:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
1008445f0:     	add	x0, x0, #0xd90
1008445f4:     	ldr	x8, [x0]
1008445f8:     	blr	x8
1008445fc:     	ldrb	w8, [x0, #0x20]
100844600:     	ldr	x24, [sp, #0x28]
100844604:     	cbnz	w8, 0x100844e88 <_js_json_stringify_full+0x1ec8>
100844608:     	ldr	x8, [x0]
10084460c:     	cbnz	x8, 0x1008453ec <_js_json_stringify_full+0x242c>
100844610:     	str	xzr, [x0, #0x18]
100844614:     	ldp	x22, x19, [x29, #-0x80]
100844618:     	ldrb	w8, [x25, #0x18]
10084461c:     	cmp	w8, #0x1
100844620:     	b.ne	0x100844e50 <_js_json_stringify_full+0x1e90>
100844624:     	ldp	x8, x0, [x25]
100844628:     	stp	x22, x19, [x25]
10084462c:     	str	xzr, [x25, #0x10]
100844630:     	sub	x8, x8, #0x1
100844634:     	cmn	x8, #0x2
100844638:     	b.hs	0x100844640 <_js_json_stringify_full+0x1680>
10084463c:     	bl	0x100b5c980 <_mi_free>
100844640:     	cbz	w28, 0x100844808 <_js_json_stringify_full+0x1848>
100844644:     	bl	0x1003257a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100844648:     	ldr	w8, [x21]
10084464c:     	sub	w8, w8, #0x1
100844650:     	str	w8, [x21]
100844654:     	cmn	x27, #0x1
100844658:     	b.ne	0x100844844 <_js_json_stringify_full+0x1884>
10084465c:     	b	0x1008449cc <_js_json_stringify_full+0x1a0c>
100844660:     	mov	x0, x19
100844664:     	bl	0x1001399f0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100844668:     	fmov	d1, x0
10084466c:     	mov.16b	v0, v8
100844670:     	bl	0x1004fd8bc <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer19apply_to_json_keyed>
100844674:     	mov.16b	v8, v0
100844678:     	ldr	x8, [x24, #0x48]
10084467c:     	cmn	x8, #0x1
100844680:     	b.eq	0x1008446e4 <_js_json_stringify_full+0x1724>
100844684:     	mrs	x9, TPIDRRO_EL0
100844688:     	and	x9, x9, #0xfffffffffffffff8
10084468c:     	ldr	x8, [x9, x8, lsl #3]
100844690:     	cbz	x8, 0x1008446e4 <_js_json_stringify_full+0x1724>
100844694:     	ldr	x8, [x8, #0x19e8]
100844698:     	cbz	x8, 0x1008446e4 <_js_json_stringify_full+0x1724>
10084469c:     	ldr	x9, [x8]
1008446a0:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
1008446a4:     	cmp	x9, x10
1008446a8:     	b.hs	0x100844e78 <_js_json_stringify_full+0x1eb8>
1008446ac:     	add	x10, x9, #0x1
1008446b0:     	str	x10, [x8]
1008446b4:     	ldr	x10, [x8, #0x18]
1008446b8:     	cmp	x22, x10
1008446bc:     	b.hs	0x100844e84 <_js_json_stringify_full+0x1ec4>
1008446c0:     	ldr	x10, [x8, #0x10]
1008446c4:     	mov	w11, #0x18              ; =24
1008446c8:     	madd	x10, x22, x11, x10
1008446cc:     	ldr	x11, [x10]
1008446d0:     	cmp	x11, #0x1
1008446d4:     	b.ne	0x100845404 <_js_json_stringify_full+0x2444>
1008446d8:     	ldr	x22, [x10, #0x8]
1008446dc:     	str	x9, [x8]
1008446e0:     	b	0x1008446f0 <_js_json_stringify_full+0x1730>
1008446e4:     	mov	x0, x22
1008446e8:     	bl	0x100139918 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotONtNtB28_3map9MapHeaderNCINvB3g_15get_raw_mut_ptrB4d_E0E0B4c_EB28_>
1008446ec:     	mov	x22, x0
1008446f0:     	ldr	x8, [x24, #0x48]
1008446f4:     	cmn	x8, #0x1
1008446f8:     	b.eq	0x10084475c <_js_json_stringify_full+0x179c>
1008446fc:     	mrs	x9, TPIDRRO_EL0
100844700:     	and	x9, x9, #0xfffffffffffffff8
100844704:     	ldr	x8, [x9, x8, lsl #3]
100844708:     	cbz	x8, 0x10084475c <_js_json_stringify_full+0x179c>
10084470c:     	ldr	x8, [x8, #0x19e8]
100844710:     	ldr	x24, [sp, #0x28]
100844714:     	cbz	x8, 0x100844a28 <_js_json_stringify_full+0x1a68>
100844718:     	ldr	x9, [x8]
10084471c:     	mov	x10, #0x7fffffffffffffff ; =9223372036854775807
100844720:     	cmp	x9, x10
100844724:     	b.hs	0x100844e78 <_js_json_stringify_full+0x1eb8>
100844728:     	add	x10, x9, #0x1
10084472c:     	str	x10, [x8]
100844730:     	ldr	x10, [x8, #0x18]
100844734:     	cmp	x19, x10
100844738:     	b.hs	0x100844e84 <_js_json_stringify_full+0x1ec4>
10084473c:     	ldr	x10, [x8, #0x10]
100844740:     	mov	w11, #0x18              ; =24
100844744:     	madd	x10, x19, x11, x10
100844748:     	ldr	x11, [x10]
10084474c:     	cbnz	x11, 0x100844e9c <_js_json_stringify_full+0x1edc>
100844750:     	ldr	x0, [x10, #0x8]
100844754:     	str	x9, [x8]
100844758:     	b	0x100844768 <_js_json_stringify_full+0x17a8>
10084475c:     	mov	x0, x19
100844760:     	bl	0x1001399f0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100844764:     	ldr	x24, [sp, #0x28]
100844768:     	fmov	d9, x0
10084476c:     	mov.16b	v0, v8
100844770:     	bl	0x1004fd3f4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer11root_holder>
100844774:     	mov.16b	v2, v0
100844778:     	mov	x0, x22
10084477c:     	mov.16b	v0, v9
100844780:     	mov.16b	v1, v8
100844784:     	bl	0x1004fd6d4 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer13call_replacer>
100844788:     	str	d0, [sp, #0x58]
10084478c:     	fmov	x19, d0
100844790:     	cmp	x19, x20
100844794:     	b.ne	0x1008447b0 <_js_json_stringify_full+0x17f0>
100844798:     	bl	0x100139d0c <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecjEEE4withNCNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22js_json_stringify_fulls1_0uEB2j_>
10084479c:     	ldp	x0, x1, [x29, #-0x80]
1008447a0:     	bl	0x100326e54 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json21restore_stringify_buf>
1008447a4:     	cbz	w28, 0x100844824 <_js_json_stringify_full+0x1864>
1008447a8:     	bl	0x1003257a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
1008447ac:     	b	0x100844828 <_js_json_stringify_full+0x1868>
1008447b0:     	sub	x0, x29, #0x80
1008447b4:     	bl	0x1004fdc38 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer21write_replaced_scalar>
1008447b8:     	tbnz	w0, #0x0, 0x1008447f4 <_js_json_stringify_full+0x1834>
1008447bc:     	mov	x0, x19
1008447c0:     	bl	0x1003254ac <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json15extract_pointer>
1008447c4:     	cmp	x0, #0x1
1008447c8:     	b.ne	0x1008453f8 <_js_json_stringify_full+0x2438>
1008447cc:     	stur	x1, [x29, #-0x98]
1008447d0:     	sub	x8, x29, #0x98
1008447d4:     	add	x9, sp, #0x58
1008447d8:     	stp	x8, x9, [sp, #0x60]
1008447dc:     	sub	x8, x29, #0x80
1008447e0:     	add	x9, sp, #0x30
1008447e4:     	stp	x8, x9, [sp, #0x70]
1008447e8:     	add	x0, sp, #0x50
1008447ec:     	add	x1, sp, #0x60
1008447f0:     	bl	0x100141450 <__RINvMs2_NtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handlesNtB6_13RuntimeHandle14with_const_ptrNtNtNtBc_7closure5alloc13ClosureHeaderuNCNvNtNtBc_4json8replacer22js_json_stringify_fulls3_0EBc_>
1008447f4:     	add	x0, sp, #0x48
1008447f8:     	bl	0x10016453c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
1008447fc:     	b	0x1008444d8 <_js_json_stringify_full+0x1518>
100844800:     	mov	x10, #0x0               ; =0
100844804:     	b	0x100844920 <_js_json_stringify_full+0x1960>
100844808:     	bl	0x1003255d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
10084480c:     	ldr	w8, [x21]
100844810:     	sub	w8, w8, #0x1
100844814:     	str	w8, [x21]
100844818:     	cmn	x27, #0x1
10084481c:     	b.ne	0x100844844 <_js_json_stringify_full+0x1884>
100844820:     	b	0x1008449cc <_js_json_stringify_full+0x1a0c>
100844824:     	bl	0x1003255d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100844828:     	ldr	w8, [x21]
10084482c:     	sub	w8, w8, #0x1
100844830:     	str	w8, [x21]
100844834:     	add	x0, sp, #0x48
100844838:     	bl	0x10016453c <__RINvNtCsjgY6bXVaRmE_4core3ptr9drop_glueNtNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles18RuntimeHandleScopeEBJ_>
10084483c:     	cmn	x27, #0x1
100844840:     	b.eq	0x1008449cc <_js_json_stringify_full+0x1a0c>
100844844:     	cbz	x23, 0x1008449c0 <_js_json_stringify_full+0x1a00>
100844848:     	add	x19, x24, #0x8
10084484c:     	b	0x10084485c <_js_json_stringify_full+0x189c>
100844850:     	add	x19, x19, #0x18
100844854:     	subs	x23, x23, #0x1
100844858:     	b.eq	0x1008449c0 <_js_json_stringify_full+0x1a00>
10084485c:     	ldur	x8, [x19, #-0x8]
100844860:     	cbz	x8, 0x100844850 <_js_json_stringify_full+0x1890>
100844864:     	ldr	x0, [x19]
100844868:     	bl	0x100b5c980 <_mi_free>
10084486c:     	b	0x100844850 <_js_json_stringify_full+0x1890>
100844870:     	and	x9, x1, #0x4
100844874:     	add	x8, x0, x9
100844878:     	adrp	x10, 0x100c97000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime6string6format13fmt_fixed_int5POW10+0x5460>
10084487c:     	ldr	q0, [x10, #0x410]
100844880:     	adrp	x10, 0x100c37000 <__RNvCs8xF4iOrs9m2_4itoa13DECIMAL_PAIRS+0x33c6a>
100844884:     	ldr	q2, [x10, #0x310]
100844888:     	movi.2d	v1, #0000000000000000
10084488c:     	movi.2d	v3, #0x000000000000ff
100844890:     	mov	w10, #0x4               ; =4
100844894:     	dup.2d	v4, x10
100844898:     	mov	x10, x0
10084489c:     	and	x11, x1, #0x4
1008448a0:     	movi.2d	v5, #0000000000000000
1008448a4:     	ldr	s6, [x10], #0x4
1008448a8:     	ushll.8h	v6, v6, #0x0
1008448ac:     	ushll.4s	v6, v6, #0x0
1008448b0:     	ushll2.2d	v7, v6, #0x0
1008448b4:     	and.16b	v7, v7, v3
1008448b8:     	ushll.2d	v6, v6, #0x0
1008448bc:     	and.16b	v6, v6, v3
1008448c0:     	shl.2d	v16, v0, #0x3
1008448c4:     	shl.2d	v17, v2, #0x3
1008448c8:     	ushl.2d	v6, v6, v17
1008448cc:     	ushl.2d	v7, v7, v16
1008448d0:     	orr.16b	v1, v7, v1
1008448d4:     	orr.16b	v5, v6, v5
1008448d8:     	add.2d	v0, v0, v4
1008448dc:     	add.2d	v2, v2, v4
1008448e0:     	subs	x11, x11, #0x4
1008448e4:     	b.ne	0x1008448a4 <_js_json_stringify_full+0x18e4>
1008448e8:     	orr.16b	v0, v5, v1
1008448ec:     	mov	d1, v0[1]
1008448f0:     	orr.8b	v0, v0, v1
1008448f4:     	fmov	x10, d0
1008448f8:     	cmp	x1, x9
1008448fc:     	b.eq	0x100844920 <_js_json_stringify_full+0x1960>
100844900:     	add	x11, x0, x1
100844904:     	lsl	x9, x9, #3
100844908:     	ldrb	w12, [x8], #0x1
10084490c:     	lsl	x12, x12, x9
100844910:     	orr	x10, x12, x10
100844914:     	add	x9, x9, #0x8
100844918:     	cmp	x8, x11
10084491c:     	b.ne	0x100844908 <_js_json_stringify_full+0x1948>
100844920:     	orr	x8, x10, x1, lsl #40
100844924:     	mov	x9, #0x7ff9000000000000 ; =9221401712017801216
100844928:     	orr	x20, x8, x9
10084492c:     	ldur	x22, [x29, #-0x80]
100844930:     	ldrb	w8, [x25, #0x18]
100844934:     	cmp	w8, #0x1
100844938:     	b.ne	0x100844c30 <_js_json_stringify_full+0x1c70>
10084493c:     	ldp	x9, x8, [x25]
100844940:     	stp	x22, x0, [x25]
100844944:     	str	xzr, [x25, #0x10]
100844948:     	sub	x9, x9, #0x1
10084494c:     	cmn	x9, #0x2
100844950:     	b.hs	0x10084495c <_js_json_stringify_full+0x199c>
100844954:     	mov	x0, x8
100844958:     	bl	0x100b5c980 <_mi_free>
10084495c:     	cbz	w28, 0x10084497c <_js_json_stringify_full+0x19bc>
100844960:     	bl	0x1003257a8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json19restore_shape_cache>
100844964:     	ldr	w8, [x21]
100844968:     	sub	w8, w8, #0x1
10084496c:     	str	w8, [x21]
100844970:     	cmn	x27, #0x1
100844974:     	b.ne	0x100844994 <_js_json_stringify_full+0x19d4>
100844978:     	b	0x1008449cc <_js_json_stringify_full+0x1a0c>
10084497c:     	bl	0x1003255d8 <__RNvNtCs3gRpqoBkMHm_13perry_runtime4json17clear_shape_cache>
100844980:     	ldr	w8, [x21]
100844984:     	sub	w8, w8, #0x1
100844988:     	str	w8, [x21]
10084498c:     	cmn	x27, #0x1
100844990:     	b.eq	0x1008449cc <_js_json_stringify_full+0x1a0c>
100844994:     	cbz	x23, 0x1008449c0 <_js_json_stringify_full+0x1a00>
100844998:     	add	x19, x24, #0x8
10084499c:     	b	0x1008449ac <_js_json_stringify_full+0x19ec>
1008449a0:     	add	x19, x19, #0x18
1008449a4:     	subs	x23, x23, #0x1
1008449a8:     	b.eq	0x1008449c0 <_js_json_stringify_full+0x1a00>
1008449ac:     	ldur	x8, [x19, #-0x8]
1008449b0:     	cbz	x8, 0x1008449a0 <_js_json_stringify_full+0x19e0>
1008449b4:     	ldr	x0, [x19]
1008449b8:     	bl	0x100b5c980 <_mi_free>
1008449bc:     	b	0x1008449a0 <_js_json_stringify_full+0x19e0>
1008449c0:     	cbz	x27, 0x1008449cc <_js_json_stringify_full+0x1a0c>
1008449c4:     	mov	x0, x24
1008449c8:     	bl	0x100b5c980 <_mi_free>
1008449cc:     	ldr	x8, [sp, #0x30]
1008449d0:     	cbz	x8, 0x1008449dc <_js_json_stringify_full+0x1a1c>
1008449d4:     	ldr	x0, [sp, #0x38]
1008449d8:     	bl	0x100b5c980 <_mi_free>
1008449dc:     	mov	x0, x20
1008449e0:     	ldp	x29, x30, [sp, #0x140]
1008449e4:     	ldp	x20, x19, [sp, #0x130]
1008449e8:     	ldp	x22, x21, [sp, #0x120]
1008449ec:     	ldp	x24, x23, [sp, #0x110]
1008449f0:     	ldp	x26, x25, [sp, #0x100]
1008449f4:     	ldp	x28, x27, [sp, #0xf0]
1008449f8:     	ldp	d9, d8, [sp, #0xe0]
1008449fc:     	add	sp, sp, #0x150
100844a00:     	ret
100844a04:     	str	x27, [sp, #0x18]
100844a08:     	mov	x27, x22
100844a0c:     	mov	x22, x0
100844a10:     	add	x0, x0, #0x8
100844a14:     	bl	0x100b39710 <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecTyyNtNtCseUPtmYZaE8V_5gimli6common13EhFrameOffsetEE8grow_oneCs3gRpqoBkMHm_13perry_runtime>
100844a18:     	mov	x0, x22
100844a1c:     	mov	x22, x27
100844a20:     	ldr	x27, [sp, #0x18]
100844a24:     	b	0x1008442f4 <_js_json_stringify_full+0x1334>
100844a28:     	mov	x0, x19
100844a2c:     	bl	0x1001399f0 <__RINvMs2_NtNtCs8BpVhDwHqJW_3std6thread5localINtB6_8LocalKeyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots17RuntimeHandleSlotEEE4withNCINvMs2_NtB24_15runtime_handlesNtB3k_13RuntimeHandle9with_slotyNCNvB3g_14get_nanbox_u640E0yEB28_>
100844a30:     	b	0x100844768 <_js_json_stringify_full+0x17a8>
100844a34:     	cmp	x19, x26
100844a38:     	ldr	x24, [sp, #0x28]
100844a3c:     	b.eq	0x100844a48 <_js_json_stringify_full+0x1a88>
100844a40:     	mov.16b	v0, v8
100844a44:     	bl	0x10050c06c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify24arm_to_json_result_guard>
100844a48:     	cbz	x22, 0x100844a84 <_js_json_stringify_full+0x1ac4>
100844a4c:     	ldp	x1, x2, [sp, #0x38]
100844a50:     	sub	x0, x29, #0x80
100844a54:     	mov.16b	v0, v8
100844a58:     	mov	x3, #0x0                ; =0
100844a5c:     	bl	0x1004fe728 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json8replacer22stringify_value_pretty>
100844a60:     	b	0x100844a94 <_js_json_stringify_full+0x1ad4>
100844a64:     	bl	0x100b3cdbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100844a68:     	add	x8, x0, x25, lsl #3
100844a6c:     	ldr	x0, [x8, #0x1e8]
100844a70:     	cbnz	x0, 0x100844388 <_js_json_stringify_full+0x13c8>
100844a74:     	adrp	x0, 0x100f0c000 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json11parse_reuse21PARSE_OBJECT_TEMPLATE>
100844a78:     	add	x0, x0, #0x180
100844a7c:     	bl	0x100b3a5dc <__RNvMs5_NtCs3gRpqoBkMHm_13perry_runtime7tls_hotINtB5_6HotKeyNtNtNtB7_7closure8registry14DispatchRecentE8get_slowB7_>
100844a80:     	b	0x100844388 <_js_json_stringify_full+0x13c8>
100844a84:     	sub	x1, x29, #0x80
100844a88:     	mov.16b	v0, v8
100844a8c:     	mov	w0, #0x0                ; =0
100844a90:     	bl	0x100506d6c <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify15stringify_value>
100844a94:     	adrp	x0, 0x100f83000 <_theap_main+0x1f80>
100844a98:     	add	x0, x0, #0xdc0
100844a9c:     	ldr	x8, [x0]
100844aa0:     	blr	x8
100844aa4:     	strb	wzr, [x0]
100844aa8:     	b	0x1008444d8 <_js_json_stringify_full+0x1518>
100844aac:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100844ab0:     	ldr	x8, [x8, #0x48]
100844ab4:     	cmn	x8, #0x1
100844ab8:     	b.eq	0x100844f08 <_js_json_stringify_full+0x1f48>
100844abc:     	mrs	x9, TPIDRRO_EL0
100844ac0:     	and	x9, x9, #0xfffffffffffffff8
100844ac4:     	ldr	x0, [x9, x8, lsl #3]
100844ac8:     	cbz	x0, 0x100844f08 <_js_json_stringify_full+0x1f48>
100844acc:     	lsr	x1, x23, #20
100844ad0:     	ldr	x8, [x0, #0x10]
100844ad4:     	ldrb	w9, [x8]
100844ad8:     	cmp	w9, #0x2
100844adc:     	b.ne	0x100844f20 <_js_json_stringify_full+0x1f60>
100844ae0:     	mov	x11, x23
100844ae4:     	ldrb	w9, [x8, #0x88]
100844ae8:     	tbz	w9, #0x0, 0x100844b08 <_js_json_stringify_full+0x1b48>
100844aec:     	ldr	x9, [x8, #0x80]
100844af0:     	cmp	x9, x1
100844af4:     	b.ne	0x100844b08 <_js_json_stringify_full+0x1b48>
100844af8:     	ldp	x9, x10, [x8, #0x60]
100844afc:     	cmp	x9, x11
100844b00:     	ccmp	x10, x11, #0x0, ls
100844b04:     	b.hi	0x100844eac <_js_json_stringify_full+0x1eec>
100844b08:     	ldrb	w9, [x8, #0xb8]
100844b0c:     	cbz	w9, 0x100844bfc <_js_json_stringify_full+0x1c3c>
100844b10:     	ldr	x9, [x8, #0xb0]
100844b14:     	cmp	x9, x1
100844b18:     	b.ne	0x100844bfc <_js_json_stringify_full+0x1c3c>
100844b1c:     	ldr	x9, [x8, #0x90]
100844b20:     	cmp	x9, x11
100844b24:     	b.hi	0x100844bfc <_js_json_stringify_full+0x1c3c>
100844b28:     	ldr	x9, [x8, #0x98]
100844b2c:     	cmp	x9, x11
100844b30:     	b.ls	0x100844bfc <_js_json_stringify_full+0x1c3c>
100844b34:     	add	x9, x8, #0x90
100844b38:     	b	0x100844eb0 <_js_json_stringify_full+0x1ef0>
100844b3c:     	mov	x24, x0
100844b40:     	mov	x0, x23
100844b44:     	bl	0x100586634 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100844b48:     	str	x24, [sp, #0x18]
100844b4c:     	tbz	w0, #0x0, 0x100844bb4 <_js_json_stringify_full+0x1bf4>
100844b50:     	mov	x0, #0x0                ; =0
100844b54:     	b	0x100844d38 <_js_json_stringify_full+0x1d78>
100844b58:     	mov	x28, x23
100844b5c:     	str	x0, [sp, #0x18]
100844b60:     	cmp	w8, #0x1
100844b64:     	b.eq	0x100844d34 <_js_json_stringify_full+0x1d74>
100844b68:     	cmp	w8, #0x9
100844b6c:     	b.ne	0x100844d64 <_js_json_stringify_full+0x1da4>
100844b70:     	ldr	w8, [x28, #0x4]
100844b74:     	mov	w9, #0x5841             ; =22593
100844b78:     	movk	w9, #0x4c5a, lsl #16
100844b7c:     	cmp	w8, w9
100844b80:     	b.ne	0x100844d64 <_js_json_stringify_full+0x1da4>
100844b84:     	mov	x0, x28
100844b88:     	bl	0x1003730f0 <__RNvNtCs3gRpqoBkMHm_13perry_runtime9json_tape22force_materialize_lazy>
100844b8c:     	mov	x23, x0
100844b90:     	ldr	x22, [sp, #0x10]
100844b94:     	cbnz	x0, 0x100844ff0 <_js_json_stringify_full+0x2030>
100844b98:     	mov	w26, #0x0               ; =0
100844b9c:     	mov	x27, #0x0               ; =0
100844ba0:     	b	0x100845028 <_js_json_stringify_full+0x2068>
100844ba4:     	mov	x0, x25
100844ba8:     	bl	0x100b1bf84 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100844bac:     	cbnz	x0, 0x1008443ac <_js_json_stringify_full+0x13ec>
100844bb0:     	b	0x100844e90 <_js_json_stringify_full+0x1ed0>
100844bb4:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100844bb8:     	add	x8, x8, #0xe80
100844bbc:     	ldaprb	w8, [x8]
100844bc0:     	cbz	w8, 0x100844d64 <_js_json_stringify_full+0x1da4>
100844bc4:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100844bc8:     	add	x8, x8, #0x58
100844bcc:     	ldapr	x8, [x8]
100844bd0:     	cmp	x8, x23
100844bd4:     	b.hi	0x100844d64 <_js_json_stringify_full+0x1da4>
100844bd8:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100844bdc:     	add	x8, x8, #0x60
100844be0:     	ldapr	x8, [x8]
100844be4:     	cmp	x8, x23
100844be8:     	b.lo	0x100844d64 <_js_json_stringify_full+0x1da4>
100844bec:     	mov	x0, x23
100844bf0:     	bl	0x1002a2338 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
100844bf4:     	tbnz	w0, #0x0, 0x100844b50 <_js_json_stringify_full+0x1b90>
100844bf8:     	b	0x100844d64 <_js_json_stringify_full+0x1da4>
100844bfc:     	ldrb	w9, [x8, #0xe8]
100844c00:     	cbz	w9, 0x100844c4c <_js_json_stringify_full+0x1c8c>
100844c04:     	ldr	x9, [x8, #0xe0]
100844c08:     	cmp	x9, x1
100844c0c:     	b.ne	0x100844c4c <_js_json_stringify_full+0x1c8c>
100844c10:     	ldr	x9, [x8, #0xc0]
100844c14:     	cmp	x9, x11
100844c18:     	b.hi	0x100844c4c <_js_json_stringify_full+0x1c8c>
100844c1c:     	ldr	x9, [x8, #0xc8]
100844c20:     	cmp	x9, x11
100844c24:     	b.ls	0x100844c4c <_js_json_stringify_full+0x1c8c>
100844c28:     	add	x9, x8, #0xc0
100844c2c:     	b	0x100844eb0 <_js_json_stringify_full+0x1ef0>
100844c30:     	mov	x19, x0
100844c34:     	mov	x0, x25
100844c38:     	bl	0x100b1bf84 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100844c3c:     	mov	x25, x0
100844c40:     	mov	x0, x19
100844c44:     	cbnz	x25, 0x10084493c <_js_json_stringify_full+0x197c>
100844c48:     	b	0x100844e60 <_js_json_stringify_full+0x1ea0>
100844c4c:     	ldrb	w9, [x8, #0x118]
100844c50:     	mov	x23, x11
100844c54:     	cbz	w9, 0x100844f94 <_js_json_stringify_full+0x1fd4>
100844c58:     	ldr	x9, [x8, #0x110]
100844c5c:     	cmp	x9, x1
100844c60:     	b.ne	0x100844f94 <_js_json_stringify_full+0x1fd4>
100844c64:     	ldr	x9, [x8, #0xf0]
100844c68:     	cmp	x9, x23
100844c6c:     	b.hi	0x100844f94 <_js_json_stringify_full+0x1fd4>
100844c70:     	ldr	x9, [x8, #0xf8]
100844c74:     	cmp	x9, x23
100844c78:     	b.ls	0x100844f94 <_js_json_stringify_full+0x1fd4>
100844c7c:     	add	x9, x8, #0xf0
100844c80:     	b	0x100844eb0 <_js_json_stringify_full+0x1ef0>
100844c84:     	bl	0x100b1c0e4 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecIB1Q_INtNtB1U_5boxed3BoxNtNtNtCs3gRpqoBkMHm_13perry_runtime4json24stringify_shape_template13ShapeTemplateEEEEuE16get_or_init_slowNvNvB2O_11SHAPE_CACHE27___rust_std_internal_init_fnEB2Q_>
100844c88:     	cbnz	x0, 0x1008442d4 <_js_json_stringify_full+0x1314>
100844c8c:     	b	0x100844e90 <_js_json_stringify_full+0x1ed0>
100844c90:     	adrp	x0, 0x100ef6000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x4ed0>
100844c94:     	add	x0, x0, #0x440
100844c98:     	bl	0x100b1012c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100844c9c:     	str	x0, [sp, #0x18]
100844ca0:     	ldr	x0, [x0, #0x8]
100844ca4:     	mov	x23, x0
100844ca8:     	bl	0x1005781c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100844cac:     	cbz	x0, 0x100844d64 <_js_json_stringify_full+0x1da4>
100844cb0:     	ldrb	w8, [x0]
100844cb4:     	cmp	w8, #0x1
100844cb8:     	b.ne	0x100844d64 <_js_json_stringify_full+0x1da4>
100844cbc:     	ldrsb	w8, [x0, #0x1]
100844cc0:     	tbz	w8, #0x1f, 0x100844254 <_js_json_stringify_full+0x1294>
100844cc4:     	mov	w25, #0x1               ; =1
100844cc8:     	mov	w8, #0x8                ; =8
100844ccc:     	str	x8, [sp, #0x28]
100844cd0:     	ldr	x0, [x0, #0x8]
100844cd4:     	mov	x28, x0
100844cd8:     	bl	0x1005781c0 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5value10addr_class26try_read_tracked_gc_header>
100844cdc:     	cbz	x0, 0x100845414 <_js_json_stringify_full+0x2454>
100844ce0:     	mov	x27, #0x0               ; =0
100844ce4:     	mov	w26, #0x0               ; =0
100844ce8:     	ldrb	w8, [x0]
100844cec:     	mov	x23, #0x0               ; =0
100844cf0:     	mov	w24, #0x0               ; =0
100844cf4:     	cmp	w8, #0x1
100844cf8:     	b.ne	0x100845424 <_js_json_stringify_full+0x2464>
100844cfc:     	cmp	w25, #0x3f
100844d00:     	ldr	x22, [sp, #0x10]
100844d04:     	b.hi	0x100844294 <_js_json_stringify_full+0x12d4>
100844d08:     	add	w25, w25, #0x1
100844d0c:     	ldrsb	w8, [x0, #0x1]
100844d10:     	tbnz	w8, #0x1f, 0x100844cd0 <_js_json_stringify_full+0x1d10>
100844d14:     	ldr	x9, [sp, #0x18]
100844d18:     	str	x28, [x9, #0x8]
100844d1c:     	ldrb	w8, [x9, #0x1]
100844d20:     	orr	w8, w8, #0x80
100844d24:     	strb	w8, [x9, #0x1]
100844d28:     	ldrb	w8, [x0]
100844d2c:     	cmp	w8, #0x1
100844d30:     	b.ne	0x100844b68 <_js_json_stringify_full+0x1ba8>
100844d34:     	mov	x23, x28
100844d38:     	ldp	w9, w8, [x23]
100844d3c:     	cmp	w9, w8
100844d40:     	b.ls	0x100844d84 <_js_json_stringify_full+0x1dc4>
100844d44:     	ldp	x22, x9, [sp, #0x10]
100844d48:     	cbz	x9, 0x100844d98 <_js_json_stringify_full+0x1dd8>
100844d4c:     	ldr	w9, [x0, #0x4]
100844d50:     	ubfiz	x8, x8, #3, #32
100844d54:     	add	x8, x8, #0x10
100844d58:     	cmp	x8, x9
100844d5c:     	b.ne	0x100844d98 <_js_json_stringify_full+0x1dd8>
100844d60:     	b	0x100844ff0 <_js_json_stringify_full+0x2030>
100844d64:     	mov	w26, #0x0               ; =0
100844d68:     	mov	x27, #0x0               ; =0
100844d6c:     	mov	x23, #0x0               ; =0
100844d70:     	mov	w24, #0x0               ; =0
100844d74:     	mov	w8, #0x8                ; =8
100844d78:     	str	x8, [sp, #0x28]
100844d7c:     	ldr	x22, [sp, #0x10]
100844d80:     	b	0x100844294 <_js_json_stringify_full+0x12d4>
100844d84:     	ldr	x22, [sp, #0x10]
100844d88:     	mov	w8, #0xe100             ; =57600
100844d8c:     	movk	w8, #0x5f5, lsl #16
100844d90:     	cmp	w9, w8
100844d94:     	b.ls	0x100844ff0 <_js_json_stringify_full+0x2030>
100844d98:     	mov	x0, x23
100844d9c:     	bl	0x100586634 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime6buffer6header20is_registered_buffer>
100844da0:     	tbnz	w0, #0x0, 0x100844ff0 <_js_json_stringify_full+0x2030>
100844da4:     	adrp	x8, 0x10105d000 <_PERRY_CLASS_PROTOTYPE_FAST_GUARDS_INVALIDATED_BY_METHOD+0xf7dc>
100844da8:     	add	x8, x8, #0xe80
100844dac:     	ldaprb	w8, [x8]
100844db0:     	cbz	w8, 0x10084501c <_js_json_stringify_full+0x205c>
100844db4:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100844db8:     	add	x8, x8, #0x58
100844dbc:     	ldapr	x8, [x8]
100844dc0:     	cmp	x8, x23
100844dc4:     	b.hi	0x10084501c <_js_json_stringify_full+0x205c>
100844dc8:     	adrp	x8, 0x100f7c000 <_perry_global_options_worker_ts__1>
100844dcc:     	add	x8, x8, #0x60
100844dd0:     	ldapr	x8, [x8]
100844dd4:     	cmp	x8, x23
100844dd8:     	b.lo	0x10084501c <_js_json_stringify_full+0x205c>
100844ddc:     	mov	x0, x23
100844de0:     	bl	0x1002a2338 <__RNvNtCs3gRpqoBkMHm_13perry_runtime10typedarray34lookup_registered_typed_array_kind>
100844de4:     	tbnz	w0, #0x0, 0x100844ff0 <_js_json_stringify_full+0x2030>
100844de8:     	b	0x10084501c <_js_json_stringify_full+0x205c>
100844dec:     	cmp	w8, #0x1
100844df0:     	b.ne	0x100844e90 <_js_json_stringify_full+0x1ed0>
100844df4:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
100844df8:     	add	x1, x1, #0x58
100844dfc:     	mov	x19, x0
100844e00:     	bl	0x100a1de5c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
100844e04:     	mov	x0, x19
100844e08:     	strb	wzr, [x19, #0x20]
100844e0c:     	ldr	x24, [sp, #0x28]
100844e10:     	ldr	x8, [x19]
100844e14:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
100844e18:     	cmp	x8, x9
100844e1c:     	b.lo	0x100844500 <_js_json_stringify_full+0x1540>
100844e20:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100844e24:     	add	x0, x0, #0xea8
100844e28:     	bl	0x100b1015c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100844e2c:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
100844e30:     	add	x0, x0, #0xec0
100844e34:     	bl	0x100b1012c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
100844e38:     	and	x0, x19, #0xffffffffffff
100844e3c:     	bl	0x1004ed100 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat21emit_one_field_object>
100844e40:     	b	0x100844efc <_js_json_stringify_full+0x1f3c>
100844e44:     	and	x0, x19, #0xffffffffffff
100844e48:     	mov	x1, x20
100844e4c:     	b	0x100844ef8 <_js_json_stringify_full+0x1f38>
100844e50:     	mov	x0, x25
100844e54:     	bl	0x100b1bf84 <__RINvMs0_NtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native4lazyINtB6_7StorageINtNtCsjgY6bXVaRmE_4core4cell4CellINtNtB1j_6option6OptionNtNtCsctvjasLqLe9_5alloc6string6StringEEuE16get_or_init_slowNvNvNtCs3gRpqoBkMHm_13perry_runtime4json13STRINGIFY_BUF27___rust_std_internal_init_fnEB3d_>
100844e58:     	mov	x25, x0
100844e5c:     	cbnz	x0, 0x100844624 <_js_json_stringify_full+0x1664>
100844e60:     	cbz	x22, 0x100844e90 <_js_json_stringify_full+0x1ed0>
100844e64:     	mov	x0, x19
100844e68:     	bl	0x100b5c980 <_mi_free>
100844e6c:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100844e70:     	add	x0, x0, #0xc18
100844e74:     	bl	0x100b55fdc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100844e78:     	adrp	x0, 0x100ef3000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x1ed0>
100844e7c:     	add	x0, x0, #0xd70
100844e80:     	bl	0x100b1015c <__RNvNtCsjgY6bXVaRmE_4core4cell30panic_already_mutably_borrowed>
100844e84:     	bl	0x100b49314 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles23handle_used_after_scope>
100844e88:     	cmp	w8, #0x2
100844e8c:     	b.ne	0x1008453c8 <_js_json_stringify_full+0x2408>
100844e90:     	adrp	x0, 0x100ef2000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0xed0>
100844e94:     	add	x0, x0, #0xc18
100844e98:     	bl	0x100b55fdc <__RNvNtNtCs8BpVhDwHqJW_3std6thread5local18panic_access_error>
100844e9c:     	adrp	x0, 0x100c3f000 <_PERRY_EMPTY_STRING+0xa4>
100844ea0:     	add	x0, x0, #0xe80
100844ea4:     	mov	w1, #0xf                ; =15
100844ea8:     	bl	0x100b492dc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100844eac:     	add	x9, x8, #0x60
100844eb0:     	ldr	x10, [x8, #0x30]
100844eb4:     	add	x10, x10, #0x1
100844eb8:     	str	x10, [x8, #0x30]
100844ebc:     	add	x8, x9, #0x19
100844ec0:     	b	0x100844f74 <_js_json_stringify_full+0x1fb4>
100844ec4:     	ldr	x1, [x25, #0x18]
100844ec8:     	add	x0, sp, #0x80
100844ecc:     	bl	0x1004ed554 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat25parsed_plain_string_piece>
100844ed0:     	ldr	w8, [sp, #0x80]
100844ed4:     	cmn	w8, #0x1
100844ed8:     	b.eq	0x100844ef0 <_js_json_stringify_full+0x1f30>
100844edc:     	mov	w1, #0x1                ; =1
100844ee0:     	and	x0, x19, #0xffffffffffff
100844ee4:     	add	x2, sp, #0x80
100844ee8:     	bl	0x1004ed900 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat35emit_two_field_parsed_string_object>
100844eec:     	tbnz	w0, #0x0, 0x1008435a0 <_js_json_stringify_full+0x5e0>
100844ef0:     	and	x0, x19, #0xffffffffffff
100844ef4:     	mov	w1, #0x2                ; =2
100844ef8:     	bl	0x1004ebf80 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json14stringify_flat11emit_object>
100844efc:     	mov	x20, x1
100844f00:     	tbz	w0, #0x0, 0x100843580 <_js_json_stringify_full+0x5c0>
100844f04:     	b	0x1008449dc <_js_json_stringify_full+0x1a1c>
100844f08:     	bl	0x100b3cdbc <__RNvNtCs3gRpqoBkMHm_13perry_runtime7tls_hot12hot_uncached>
100844f0c:     	lsr	x1, x23, #20
100844f10:     	ldr	x8, [x0, #0x10]
100844f14:     	ldrb	w9, [x8]
100844f18:     	cmp	w9, #0x2
100844f1c:     	b.eq	0x100844ae0 <_js_json_stringify_full+0x1b20>
100844f20:     	ldr	x9, [x8, #0x8]
100844f24:     	ldr	x10, [x8, #0x28]
100844f28:     	sub	x9, x1, x9
100844f2c:     	cmp	x9, x10
100844f30:     	b.hs	0x100844f88 <_js_json_stringify_full+0x1fc8>
100844f34:     	ldr	x10, [x8, #0x20]
100844f38:     	mov	w11, #0x28              ; =40
100844f3c:     	madd	x9, x9, x11, x10
100844f40:     	ldr	x10, [x9]
100844f44:     	ldr	x11, [x8, #0x10]
100844f48:     	cmp	x10, x11
100844f4c:     	b.ne	0x100844f94 <_js_json_stringify_full+0x1fd4>
100844f50:     	ldp	x10, x11, [x9, #0x8]
100844f54:     	cmp	x10, x23
100844f58:     	ccmp	x11, x23, #0x0, ls
100844f5c:     	b.ls	0x100844f94 <_js_json_stringify_full+0x1fd4>
100844f60:     	mov	x11, x23
100844f64:     	ldr	x10, [x8, #0x30]
100844f68:     	add	x10, x10, #0x1
100844f6c:     	str	x10, [x8, #0x30]
100844f70:     	add	x8, x9, #0x21
100844f74:     	ldrb	w8, [x8]
100844f78:     	cmp	w8, #0xff
100844f7c:     	mov	x23, x11
100844f80:     	b.ne	0x100844fac <_js_json_stringify_full+0x1fec>
100844f84:     	b	0x100844fa0 <_js_json_stringify_full+0x1fe0>
100844f88:     	ldr	x9, [x8, #0x58]
100844f8c:     	add	x9, x9, #0x1
100844f90:     	str	x9, [x8, #0x58]
100844f94:     	ldr	x9, [x8, #0x38]
100844f98:     	add	x9, x9, #0x1
100844f9c:     	str	x9, [x8, #0x38]
100844fa0:     	mov	x0, x23
100844fa4:     	bl	0x10051bb48 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime5arena9page_meta33classify_heap_generation_uncached>
100844fa8:     	and	w8, w0, #0xff
100844fac:     	cbz	w8, 0x100844230 <_js_json_stringify_full+0x1270>
100844fb0:     	ldurb	w8, [x23, #-0x8]
100844fb4:     	ldurb	w9, [x23, #-0x7]
100844fb8:     	mov	w10, #0x82              ; =130
100844fbc:     	and	w9, w9, w10
100844fc0:     	cmp	w9, #0x2
100844fc4:     	ccmp	w8, #0x1, #0x0, eq
100844fc8:     	b.ne	0x100844230 <_js_json_stringify_full+0x1270>
100844fcc:     	ldr	w8, [x23]
100844fd0:     	mov	w9, #0xe100             ; =57600
100844fd4:     	movk	w9, #0x5f5, lsl #16
100844fd8:     	orr	w9, w9, #0x1
100844fdc:     	cmp	w8, w9
100844fe0:     	b.hs	0x100844230 <_js_json_stringify_full+0x1270>
100844fe4:     	ldr	w9, [x23, #0x4]
100844fe8:     	cmp	w8, w9
100844fec:     	b.hi	0x100844230 <_js_json_stringify_full+0x1270>
100844ff0:     	ldr	w9, [x23], #0x8
100844ff4:     	mov	w8, #0x8                ; =8
100844ff8:     	stp	xzr, x8, [x29, #-0x98]
100844ffc:     	stur	xzr, [x29, #-0x88]
100845000:     	str	x9, [sp, #0x28]
100845004:     	cbz	w9, 0x10084501c <_js_json_stringify_full+0x205c>
100845008:     	mov	x28, x22
10084500c:     	mov	x25, #0x0               ; =0
100845010:     	mov	x24, #0x7ff9000000000000 ; =9221401712017801216
100845014:     	str	x23, [sp, #0x8]
100845018:     	b	0x10084506c <_js_json_stringify_full+0x20ac>
10084501c:     	mov	w26, #0x0               ; =0
100845020:     	mov	x27, #0x0               ; =0
100845024:     	mov	x23, #0x0               ; =0
100845028:     	mov	w24, #0x0               ; =0
10084502c:     	mov	w8, #0x8                ; =8
100845030:     	str	x8, [sp, #0x28]
100845034:     	b	0x100844294 <_js_json_stringify_full+0x12d4>
100845038:     	mov	w8, #0x18               ; =24
10084503c:     	madd	x8, x22, x8, x25
100845040:     	ldp	x9, x25, [sp, #0x18]
100845044:     	stp	x9, x27, [x8]
100845048:     	str	x24, [x8, #0x10]
10084504c:     	add	x8, x22, #0x1
100845050:     	stur	x8, [x29, #-0x88]
100845054:     	ldr	x23, [sp, #0x8]
100845058:     	mov	x24, #0x7ff9000000000000 ; =9221401712017801216
10084505c:     	add	x25, x25, #0x1
100845060:     	ldr	x8, [sp, #0x28]
100845064:     	cmp	x25, x8
100845068:     	b.eq	0x10084538c <_js_json_stringify_full+0x23cc>
10084506c:     	ldr	d9, [x23, x25, lsl #3]
100845070:     	fmov	x26, d9
100845074:     	and	x22, x26, #0xffff000000000000
100845078:     	cmp	x22, x24
10084507c:     	b.eq	0x1008450c0 <_js_json_stringify_full+0x2100>
100845080:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
100845084:     	cmp	x22, x8
100845088:     	b.ne	0x10084513c <_js_json_stringify_full+0x217c>
10084508c:     	and	x22, x26, #0xffffffffffff
100845090:     	cmp	x22, #0x1, lsl #12      ; =0x1000
100845094:     	b.lo	0x10084505c <_js_json_stringify_full+0x209c>
100845098:     	ldr	w24, [x22, #0x4]
10084509c:     	str	x25, [sp, #0x20]
1008450a0:     	cbz	w24, 0x100845228 <_js_json_stringify_full+0x2268>
1008450a4:     	mov	x0, x24
1008450a8:     	mov	w1, #0x1                ; =1
1008450ac:     	bl	0x100b5cc08 <_mi_malloc_aligned>
1008450b0:     	cbz	x0, 0x10084542c <_js_json_stringify_full+0x246c>
1008450b4:     	mov	x27, x0
1008450b8:     	add	x1, x22, #0x14
1008450bc:     	b	0x1008451f8 <_js_json_stringify_full+0x2238>
1008450c0:     	strb	wzr, [sp, #0x5c]
1008450c4:     	str	wzr, [sp, #0x58]
1008450c8:     	ubfx	x1, x26, #40, #8
1008450cc:     	cbz	x1, 0x10084511c <_js_json_stringify_full+0x215c>
1008450d0:     	strb	w26, [sp, #0x58]
1008450d4:     	cmp	x1, #0x1
1008450d8:     	b.eq	0x10084511c <_js_json_stringify_full+0x215c>
1008450dc:     	lsr	x8, x26, #8
1008450e0:     	strb	w8, [sp, #0x59]
1008450e4:     	cmp	x1, #0x2
1008450e8:     	b.eq	0x10084511c <_js_json_stringify_full+0x215c>
1008450ec:     	lsr	x8, x26, #16
1008450f0:     	strb	w8, [sp, #0x5a]
1008450f4:     	cmp	x1, #0x3
1008450f8:     	b.eq	0x10084511c <_js_json_stringify_full+0x215c>
1008450fc:     	lsr	x8, x26, #24
100845100:     	strb	w8, [sp, #0x5b]
100845104:     	cmp	x1, #0x4
100845108:     	b.eq	0x10084511c <_js_json_stringify_full+0x215c>
10084510c:     	lsr	x8, x26, #32
100845110:     	strb	w8, [sp, #0x5c]
100845114:     	cmp	x1, #0x5
100845118:     	b.ne	0x100845444 <_js_json_stringify_full+0x2484>
10084511c:     	add	x8, sp, #0x60
100845120:     	add	x0, sp, #0x58
100845124:     	bl	0x10002b398 <__RNvNtNtCsjgY6bXVaRmE_4core3str8converts9from_utf8>
100845128:     	ldr	x8, [sp, #0x60]
10084512c:     	cbz	x8, 0x100845174 <_js_json_stringify_full+0x21b4>
100845130:     	mov	x22, #-0x1              ; =-1
100845134:     	stur	x22, [x29, #-0x80]
100845138:     	b	0x1008452b4 <_js_json_stringify_full+0x22f4>
10084513c:     	lsr	x8, x26, #52
100845140:     	cmp	x8, #0x0
100845144:     	and	x8, x26, #0x7
100845148:     	ccmp	x26, #0x0, #0x4, eq
10084514c:     	ccmp	x8, #0x0, #0x0, ne
100845150:     	b.eq	0x100845208 <_js_json_stringify_full+0x2248>
100845154:     	mov	w8, #0x7ffe0000         ; =2147352576
100845158:     	cmp	x8, x26, lsr #32
10084515c:     	b.ne	0x1008451b0 <_js_json_stringify_full+0x21f0>
100845160:     	sub	x0, x29, #0x80
100845164:     	mov	x1, x26
100845168:     	bl	0x100787800 <__RNvXs1K_NtCsctvjasLqLe9_5alloc6stringlNtB6_12SpecToString14spec_to_string>
10084516c:     	ldur	x22, [x29, #-0x80]
100845170:     	b	0x1008452b4 <_js_json_stringify_full+0x22f4>
100845174:     	ldr	x22, [sp, #0x70]
100845178:     	tbnz	x22, #0x3f, 0x100845380 <_js_json_stringify_full+0x23c0>
10084517c:     	cbz	x22, 0x1008452a0 <_js_json_stringify_full+0x22e0>
100845180:     	ldr	x27, [sp, #0x68]
100845184:     	mov	x0, x22
100845188:     	mov	w1, #0x1                ; =1
10084518c:     	bl	0x100b5cc08 <_mi_malloc_aligned>
100845190:     	mov	x24, x0
100845194:     	mov	w0, #0x1                ; =1
100845198:     	cbz	x24, 0x10084543c <_js_json_stringify_full+0x247c>
10084519c:     	mov	x0, x24
1008451a0:     	mov	x1, x27
1008451a4:     	mov	x2, x22
1008451a8:     	bl	0x100b5f82c <_writev+0x100b5f82c>
1008451ac:     	b	0x1008452a4 <_js_json_stringify_full+0x22e4>
1008451b0:     	mov	x8, #0x7fff000000000000 ; =9223090561878065152
1008451b4:     	cmp	x22, x8
1008451b8:     	ccmp	x26, x24, #0x0, ls
1008451bc:     	b.hs	0x10084523c <_js_json_stringify_full+0x227c>
1008451c0:     	mov.16b	v0, v9
1008451c4:     	bl	0x10086f66c <_js_number_to_string>
1008451c8:     	cmp	x0, #0x1, lsl #12       ; =0x1000
1008451cc:     	b.lo	0x10084505c <_js_json_stringify_full+0x209c>
1008451d0:     	mov	x26, x0
1008451d4:     	str	x25, [sp, #0x20]
1008451d8:     	ldr	w24, [x0, #0x4]
1008451dc:     	cbz	w24, 0x100845228 <_js_json_stringify_full+0x2268>
1008451e0:     	mov	x0, x24
1008451e4:     	mov	w1, #0x1                ; =1
1008451e8:     	bl	0x100b5cc08 <_mi_malloc_aligned>
1008451ec:     	cbz	x0, 0x10084542c <_js_json_stringify_full+0x246c>
1008451f0:     	mov	x27, x0
1008451f4:     	add	x1, x26, #0x14
1008451f8:     	mov	x0, x27
1008451fc:     	mov	x2, x24
100845200:     	bl	0x100b5f82c <_writev+0x100b5f82c>
100845204:     	b	0x10084522c <_js_json_stringify_full+0x226c>
100845208:     	mov	x0, x26
10084520c:     	bl	0x10050c938 <__RNvNtNtCs3gRpqoBkMHm_13perry_runtime4json9stringify26ptr_is_tracked_heap_object>
100845210:     	tbz	w0, #0x0, 0x100845154 <_js_json_stringify_full+0x2194>
100845214:     	cmp	x26, #0x1, lsl #12      ; =0x1000
100845218:     	b.lo	0x10084505c <_js_json_stringify_full+0x209c>
10084521c:     	str	x25, [sp, #0x20]
100845220:     	ldr	w24, [x26, #0x4]
100845224:     	cbnz	w24, 0x1008451e0 <_js_json_stringify_full+0x2220>
100845228:     	mov	w27, #0x1               ; =1
10084522c:     	stp	x24, x27, [x29, #-0x80]
100845230:     	str	x24, [sp, #0x18]
100845234:     	stur	x24, [x29, #-0x70]
100845238:     	b	0x1008452c4 <_js_json_stringify_full+0x2304>
10084523c:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
100845240:     	cmp	x22, x8
100845244:     	b.ne	0x10084505c <_js_json_stringify_full+0x209c>
100845248:     	and	x1, x26, #0xffffffffffff
10084524c:     	sub	x8, x1, #0x100, lsl #12 ; =0x100000
100845250:     	mov	x9, #0x7fffffffffff     ; =140737488355327
100845254:     	movk	x9, #0xffef, lsl #16
100845258:     	cmp	x8, x9
10084525c:     	b.hi	0x10084505c <_js_json_stringify_full+0x209c>
100845260:     	add	x0, sp, #0x60
100845264:     	bl	0x10076b4ac <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime8builtins10formatting16boxed_primitives34boxed_primitive_payload_for_object>
100845268:     	ldr	w8, [sp, #0x60]
10084526c:     	tbz	w8, #0x0, 0x10084505c <_js_json_stringify_full+0x209c>
100845270:     	ldr	w8, [sp, #0x68]
100845274:     	mov	w9, #0x8068             ; =32872
100845278:     	movk	w9, #0x7fff, lsl #16
10084527c:     	cmp	w9, w8, lsr #1
100845280:     	b.ne	0x10084505c <_js_json_stringify_full+0x209c>
100845284:     	mov.16b	v0, v9
100845288:     	bl	0x1008460bc <_js_jsvalue_to_string>
10084528c:     	cmp	x0, #0x1, lsl #12       ; =0x1000
100845290:     	b.hs	0x100845340 <_js_json_stringify_full+0x2380>
100845294:     	mov	x22, #-0x1              ; =-1
100845298:     	stur	x22, [x29, #-0x80]
10084529c:     	b	0x1008452ac <_js_json_stringify_full+0x22ec>
1008452a0:     	mov	w24, #0x1               ; =1
1008452a4:     	stp	x22, x24, [x29, #-0x80]
1008452a8:     	stur	x22, [x29, #-0x70]
1008452ac:     	ldr	x23, [sp, #0x8]
1008452b0:     	mov	x24, #0x7ff9000000000000 ; =9221401712017801216
1008452b4:     	cmn	x22, #0x1
1008452b8:     	b.eq	0x10084505c <_js_json_stringify_full+0x209c>
1008452bc:     	stp	x22, x25, [sp, #0x18]
1008452c0:     	ldp	x27, x24, [x29, #-0x78]
1008452c4:     	ldp	x25, x22, [x29, #-0x90]
1008452c8:     	cbz	x22, 0x100845324 <_js_json_stringify_full+0x2364>
1008452cc:     	add	x8, x22, x22, lsl #1
1008452d0:     	lsl	x26, x8, #3
1008452d4:     	add	x23, x25, #0x10
1008452d8:     	b	0x1008452e8 <_js_json_stringify_full+0x2328>
1008452dc:     	add	x23, x23, #0x18
1008452e0:     	subs	x26, x26, #0x18
1008452e4:     	b.eq	0x100845324 <_js_json_stringify_full+0x2364>
1008452e8:     	ldr	x8, [x23]
1008452ec:     	cmp	x8, x24
1008452f0:     	b.ne	0x1008452dc <_js_json_stringify_full+0x231c>
1008452f4:     	ldur	x0, [x23, #-0x8]
1008452f8:     	mov	x1, x27
1008452fc:     	mov	x2, x24
100845300:     	bl	0x100b5f820 <_writev+0x100b5f820>
100845304:     	cbnz	w0, 0x1008452dc <_js_json_stringify_full+0x231c>
100845308:     	ldr	x23, [sp, #0x8]
10084530c:     	ldp	x8, x25, [sp, #0x18]
100845310:     	mov	x24, #0x7ff9000000000000 ; =9221401712017801216
100845314:     	cbz	x8, 0x10084505c <_js_json_stringify_full+0x209c>
100845318:     	mov	x0, x27
10084531c:     	bl	0x100b5c980 <_mi_free>
100845320:     	b	0x10084505c <_js_json_stringify_full+0x209c>
100845324:     	ldur	x8, [x29, #-0x98]
100845328:     	cmp	x22, x8
10084532c:     	b.ne	0x100845038 <_js_json_stringify_full+0x2078>
100845330:     	sub	x0, x29, #0x98
100845334:     	bl	0x100b5599c <__RNvMs4_NtCsctvjasLqLe9_5alloc7raw_vecINtB5_6RawVecNtNtNtCs8BpVhDwHqJW_3std3ffi6os_str8OsStringE8grow_oneBS_>
100845338:     	ldur	x25, [x29, #-0x90]
10084533c:     	b	0x100845038 <_js_json_stringify_full+0x2078>
100845340:     	mov	x24, x0
100845344:     	ldr	w8, [x0, #0x4]
100845348:     	mov	x22, x8
10084534c:     	cbz	w8, 0x100845374 <_js_json_stringify_full+0x23b4>
100845350:     	mov	x0, x22
100845354:     	mov	w1, #0x1                ; =1
100845358:     	bl	0x100b5cc08 <_mi_malloc_aligned>
10084535c:     	cbz	x0, 0x100845458 <_js_json_stringify_full+0x2498>
100845360:     	mov	x27, x0
100845364:     	add	x1, x24, #0x14
100845368:     	mov	x2, x22
10084536c:     	bl	0x100b5f82c <_writev+0x100b5f82c>
100845370:     	b	0x100845378 <_js_json_stringify_full+0x23b8>
100845374:     	mov	w27, #0x1               ; =1
100845378:     	stp	x22, x27, [x29, #-0x80]
10084537c:     	b	0x1008452a8 <_js_json_stringify_full+0x22e8>
100845380:     	mov	x0, #0x0                ; =0
100845384:     	mov	x1, x22
100845388:     	bl	0x100b0fd80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
10084538c:     	ldp	x8, x9, [x29, #-0x98]
100845390:     	str	x9, [sp, #0x28]
100845394:     	ldur	x23, [x29, #-0x88]
100845398:     	cmn	x8, #0x1
10084539c:     	b.eq	0x1008453b4 <_js_json_stringify_full+0x23f4>
1008453a0:     	mov	x27, x8
1008453a4:     	mov	w26, #0x0               ; =0
1008453a8:     	mov	w24, #0x0               ; =0
1008453ac:     	mov	x22, x28
1008453b0:     	b	0x100844294 <_js_json_stringify_full+0x12d4>
1008453b4:     	and	x27, x21, #0xffff000000000000
1008453b8:     	mov	x8, #0x7ffd000000000000 ; =9222527611924643840
1008453bc:     	cmp	x27, x8
1008453c0:     	b.eq	0x100844278 <_js_json_stringify_full+0x12b8>
1008453c4:     	b	0x100844054 <_js_json_stringify_full+0x1094>
1008453c8:     	adrp	x1, 0x100191000 <__RINvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local6native5eager7destroyINtNtCsjgY6bXVaRmE_4core4cell7RefCellINtNtCsctvjasLqLe9_5alloc3vec3VecNtNtCs3gRpqoBkMHm_13perry_runtime4json20ParseShapeCacheEntryEEEB2h_+0x20>
1008453cc:     	add	x1, x1, #0x58
1008453d0:     	mov	x19, x0
1008453d4:     	bl	0x100a1de5c <__RNvNtNtNtNtCs8BpVhDwHqJW_3std3sys12thread_local11destructors4list8register>
1008453d8:     	mov	x0, x19
1008453dc:     	strb	wzr, [x19, #0x20]
1008453e0:     	ldr	x24, [sp, #0x28]
1008453e4:     	ldr	x8, [x19]
1008453e8:     	cbz	x8, 0x100844610 <_js_json_stringify_full+0x1650>
1008453ec:     	adrp	x0, 0x100ef9000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x7ed0>
1008453f0:     	add	x0, x0, #0xe90
1008453f4:     	bl	0x100b1012c <__RNvNtCsjgY6bXVaRmE_4core4cell22panic_already_borrowed>
1008453f8:     	adrp	x0, 0x100f2b000 <__RNvNvNtNtCs3gRpqoBkMHm_13perry_runtime8dyn_eval6interp23ensure_thunk_registered10REGISTERED+0x190>
1008453fc:     	add	x0, x0, #0x848
100845400:     	bl	0x100b101f0 <__RNvNtCsjgY6bXVaRmE_4core6option13unwrap_failed>
100845404:     	adrp	x0, 0x100c3f000 <_PERRY_EMPTY_STRING+0xa4>
100845408:     	add	x0, x0, #0xbb7
10084540c:     	mov	w1, #0xb                ; =11
100845410:     	bl	0x100b492dc <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime2gc5roots15runtime_handles20handle_kind_mismatch>
100845414:     	mov	w26, #0x0               ; =0
100845418:     	mov	x27, #0x0               ; =0
10084541c:     	mov	x23, #0x0               ; =0
100845420:     	mov	w24, #0x0               ; =0
100845424:     	ldr	x22, [sp, #0x10]
100845428:     	b	0x100844294 <_js_json_stringify_full+0x12d4>
10084542c:     	mov	w0, #0x1                ; =1
100845430:     	mov	x1, x24
100845434:     	bl	0x100b0fd80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100845438:     	mov	w0, #0x1                ; =1
10084543c:     	mov	x1, x22
100845440:     	bl	0x100b0fd80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
100845444:     	adrp	x2, 0x100ef4000 <__RNvNtNtNtCs3gRpqoBkMHm_13perry_runtime7closure8dispatch5bound21KEEP_JS_FUNCTION_BIND+0x2ed0>
100845448:     	add	x2, x2, #0x3c8
10084544c:     	mov	w0, #0x5                ; =5
100845450:     	mov	w1, #0x5                ; =5
100845454:     	bl	0x100b1028c <__RNvNtCsjgY6bXVaRmE_4core9panicking18panic_bounds_check>
100845458:     	mov	w0, #0x1                ; =1
10084545c:     	mov	x1, x22
100845460:     	bl	0x100b0fd80 <__RNvNtCsctvjasLqLe9_5alloc7raw_vec12handle_error>
		...
